# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""
Maestro — AI-orchestrated multi-agent coding for Claude Code.

Version: 4.3.8
Repository: https://github.com/tavisbasing/Maestro
"""

__version__ = "4.3.8"
__title__ = "Maestro"

__all__ = ["__version__", "__title__"]
