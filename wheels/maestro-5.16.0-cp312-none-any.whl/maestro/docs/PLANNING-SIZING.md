# Planning Story Sizing — Hard Ceilings

> **Applies to:** PLN / NAV role (Planner / Navigator)

## Why sizing ceilings exist

An unbounded BLD iteration produces no progress signal while it runs, no recovery
checkpoint if it crashes, and a timeout that fires too late to be informative. Capping
what one iteration may attempt keeps each crew turn observable and restartable.

## The ceilings

| Dimension | Hard ceiling per BLD iteration | Why this value |
|-----------|-------------------------------|----------------|
| Files changed | ≤ 30 | Typical BLD inference on 30 files completes in 20–40 minutes, well within the crew timeout with headroom for retries. |
| Net lines of code changed | ≤ 2 000 | Correlates roughly with 30 files of average 65 lines each. Also the point at which context pressure starts degrading BLD output quality. |
| Edit / Write tool calls | ≤ 50 | Each Edit/Write call takes 1–5 seconds of real time; 50 calls ≈ 5–15 minutes of tool-call overhead, leaving ample room in the iteration budget. |

**Any single BLD iteration that would exceed any ceiling MUST be decomposed into
sub-stories before dispatch.**

## Sub-story decomposition

When a story exceeds a ceiling, PLN decomposes it into a dependency chain of sub-stories,
each named by appending a lowercase letter suffix to the parent order ID:

```
FTR-ACME-2026-0001a  →  FTR-ACME-2026-0001b  →  FTR-ACME-2026-0001c
```

Each sub-story must independently satisfy all three ceilings.

## Sizing justification in handoff docs

Every PLN→BLD (NAV→SHP) handoff document MUST include a `## Sizing Justification` section:

```markdown
## Sizing Justification
- Estimated files changed: 12 (ceiling: 30)
- Estimated LoC changed: 450 (ceiling: 2000)
- Estimated Edit/Write tool calls: 20 (ceiling: 50)
- Why this is one story and not several: only touches the auth module's public API
```

The act of writing this section forces PLN to confront sizing before BLD runs. If PLN
cannot write a convincing one-sentence justification for why this is one story, split it.

## Dispatcher behaviour (soft gate)

When NAV/PLN completes and the dispatcher advances the order to BLD/SHP, it calls
`check_plan_sizing()`, which parses the handoff file for the three declared estimates. If
any ceiling is exceeded, the dispatcher emits an `OVERSIZED_STORY` lifecycle event visible
in `mso status`:

```
OVERSIZED_STORY | FTR-ACME-2026-0001 plan estimates 90 files
                  changed (ceiling: 30) — PLN must decompose
```

**This is a warning only — BLD dispatch is not blocked.** A future release may hard-gate
on this event; operators can opt in via `.mso/config/gates.json` when that option ships.

## Related

- `maestro/roles/PLN.md` — PLN role definition (canonical sizing rules)
- `maestro/personas/nautical/roles/NAV.md` — nautical overlay (same rules)
- `maestro/core/fleet_runner.py:check_plan_sizing` — dispatcher soft gate
- `maestro/core/fleet_runner.py:parse_plan_sizing` — handoff file parser
