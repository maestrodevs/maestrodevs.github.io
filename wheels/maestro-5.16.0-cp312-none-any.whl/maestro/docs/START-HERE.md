# Start here — which path is mine?

Maestro has four licence tiers: **community** (free, no licence), **pro**, **team**, and
**enterprise**. Only one of them needs nothing at all before you begin. This page routes you to
the right guide in under a minute — it does not replace any of them.

## Where to start

Every guide Maestro ships, grouped by the task in front of you. Each one is also readable
offline with `mso docs <topic>`, where the topic is the filename in lower case — `mso docs quickstart`,
`mso docs when-a-voyage-is-stuck`. The rest of this page is the tier-specific setup path.

| Reading path | Best for |
|---|---|
| **Install and first run** — [QUICKSTART.md](QUICKSTART.md) · [GETTING-STARTED.md](GETTING-STARTED.md) · [SETUP.md](SETUP.md) · [INSTALL-UPGRADE-UNINSTALL.md](INSTALL-UPGRADE-UNINSTALL.md) · [LICENCE.md](LICENCE.md) | Your first hour — installing, activating a licence if you have one, and getting a workspace configured |
| **Day-to-day operating** — [ORDERS-AND-VOYAGES.md](ORDERS-AND-VOYAGES.md) · [CLI-REFERENCE.md](CLI-REFERENCE.md) · [OPERATOR-GUIDE.md](OPERATOR-GUIDE.md) · [PATROL.md](PATROL.md) · [LEAD.md](LEAD.md) | Operators with a fleet already running — defining work, dispatching it, and checking fleet health |
| **When something is wrong** — [TROUBLESHOOTING.md](TROUBLESHOOTING.md) · [WHEN-A-VOYAGE-IS-STUCK.md](WHEN-A-VOYAGE-IS-STUCK.md) · [CLI-ERRORS.md](CLI-ERRORS.md) · [SUPPORT.md](SUPPORT.md) | A command failed, a crew died, or a voyage has stopped moving |
| **Understanding the model** — [CAPABILITIES.md](CAPABILITIES.md) · [ARCHITECTURE-OVERVIEW.md](ARCHITECTURE-OVERVIEW.md) · [CHAIN-OF-COMMAND.md](CHAIN-OF-COMMAND.md) · [ROLES-GUIDE.md](ROLES-GUIDE.md) | Evaluators and security reviewers deciding whether Maestro fits, and anyone who has to explain how it works |
| **Tailoring it** — [PERSONAS.md](PERSONAS.md) · [DIVISION-PACKS.md](DIVISION-PACKS.md) · [ROLE-OVERLAYS.md](ROLE-OVERLAYS.md) · [CONFIG-MODELS.md](CONFIG-MODELS.md) · [SETTINGS.md](SETTINGS.md) · [HUMAN-REVIEW-GATES.md](HUMAN-REVIEW-GATES.md) · [PLANNING-SIZING.md](PLANNING-SIZING.md) · [PLAN-DECOMPOSITION.md](PLAN-DECOMPOSITION.md) · [CHARTS.md](CHARTS.md) · [PR-BODY-TEMPLATES.md](PR-BODY-TEMPLATES.md) | Teams whose vocabulary, roles, models, or review gates differ from the defaults |
| **Scaling and integrating** — [ENTERPRISE-QUICKSTART.md](ENTERPRISE-QUICKSTART.md) · [ENTERPRISE-SETUP.md](ENTERPRISE-SETUP.md) · [ENTERPRISE-ADMIN-GUIDE.md](ENTERPRISE-ADMIN-GUIDE.md) · [GOVERNANCE-TRUST-BOUNDARY.md](GOVERNANCE-TRUST-BOUNDARY.md) · [HUB.md](HUB.md) · [MULTI-REPO.md](MULTI-REPO.md) · [ARTEFACT-REPO.md](ARTEFACT-REPO.md) · [PROVIDERS.md](PROVIDERS.md) · [MODEL-BACKENDS.md](MODEL-BACKENDS.md) · [bridge-setup-guide.md](bridge-setup-guide.md) · [AIR-GAPPED.md](AIR-GAPPED.md) | Connecting Maestro to your git host, CI, chat, and governance policy — and running it across more than one engineer, machine, or repo |

## Which tier am I?

If you already have a licence key, its tier is whatever Polar issued it as. If you don't, you're
**community** — that's not a placeholder or a trial, it's a real, permanent, free tier.

Not sure? Ask the CLI:

```bash
mso licence status
```

No licence activated prints `No licence activated — running at community tier (this is not an
error).` — you're free to build. A licence activated prints your `Tier:` line directly.

## Which tier needs a licence at all?

| Tier | Needs a licence key? |
|---|---|
| **community** | **No.** Never asked for one, never mentions one. |
| **pro** | Yes |
| **team** | Yes |
| **enterprise** | Yes |

If you're evaluating Maestro and haven't decided whether to pay for anything yet, start at
community — `mso setup` will never prompt you for a licence, warn that you don't have one, or
suggest upgrading. Activate later with `mso licence activate <KEY>` whenever you're ready; nothing
about your workspace changes until you do.

## The four paths

### Community — three commands, nothing to activate

```bash
pip install maestro-fleet
mso quickstart
```

`mso quickstart` scaffolds a demo workspace and dispatches a real (if small) three-order fleet —
the fastest way to see Maestro work. When you're ready to point it at your own project:

```bash
cd /path/to/your/repo
mso setup
```

Full walkthrough: **[QUICKSTART.md](QUICKSTART.md)** (5-minute guide) or
**[GETTING-STARTED.md](GETTING-STARTED.md)** (full walkthrough, more depth).

### Pro — one extra command

```bash
pip install maestro-fleet
mso licence activate <YOUR-KEY>
mso quickstart
```

Same wizard, same workspace shape as community — `mso setup` now also offers a `[LICENCE]` step
showing your tier and expiry, and (optionally) looks for an org enrolment profile if you're
working under one.

Guide: **[QUICKSTART.md](QUICKSTART.md)**.

### Team / Enterprise — the profile path

An admin authors and signs an **enrolment profile** once for the whole organisation (or hands you
a `mso setup` invocation with no profile — both are supported). Your side of it:

```bash
pip install maestro-fleet
mso licence activate <YOUR-KEY>               # or pre-activated via MAESTRO_LICENCE_KEY by your IT team
cd /path/to/your/product/repo
mso setup                                     # detects the org profile, applies governance,
                                               # pins trusted keys, seeds identity, configures
                                               # secrets, applies the pinned division pack
```

If no enrolment profile resolves, `mso setup` still completes the full core wizard — you get a
pointer to [ENTERPRISE-SETUP.md](ENTERPRISE-SETUP.md), never a half-configured governance state.

Guides: **[ENTERPRISE-QUICKSTART.md](ENTERPRISE-QUICKSTART.md)** (your side, five commands) and
**[ENTERPRISE-ADMIN-GUIDE.md](ENTERPRISE-ADMIN-GUIDE.md)** (the admin's side — authoring and
signing the profile and the org policy bundle, unattended imaging, key rotation).

## What actually changes per tier

`mso setup` resolves your tier once, at the start, and reads it — it never sets or infers one.
That single value decides which optional steps are even attempted:

| | community | pro | team | enterprise |
|---|---|---|---|---|
| `[LICENCE]` step shown | never | if licensed | if licensed | if licensed |
| Enrolment-profile lookup | never (not even a filesystem check) | optional | optional | optional (warns if none found) |
| Division-pack step | `sdlc` only; other five packs are **named**, not hidden | same as community — `sdlc` only | full list, or profile-pinned | full list, or profile-pinned |
| Governance / secrets / identity onboarding | never appended | never appended | appended when a profile resolves | appended when a profile resolves |
| `mso hub start` (separate command, not a wizard step) | refuses (Team/Enterprise licence required) | refuses | works | works |

Seven wizard steps run identically, in the same order, at every tier: persona, prerequisite
checks, project analysis, workspace configuration, division-pack selection, requirement templates,
and the next-steps cheatsheet. A community run of `mso setup` never prints the words "licence",
"profile", "enrolment", "trial", or "upgrade" — that's a tested guarantee, not a convention. Full
step-by-step detail: [SETUP.md § Tier-aware step registry](SETUP.md#tier-aware-step-registry).

## See also

- [QUICKSTART.md](QUICKSTART.md) — 5-minute guide (community/pro)
- [ENTERPRISE-QUICKSTART.md](ENTERPRISE-QUICKSTART.md) — the team/enterprise path
- [GETTING-STARTED.md](GETTING-STARTED.md) — full walkthrough
- [ENTERPRISE-ADMIN-GUIDE.md](ENTERPRISE-ADMIN-GUIDE.md) — authoring the org policy bundle and enrolment profile
- [SETUP.md](SETUP.md) — everything `mso setup` does, step by step
- [LICENCE.md](LICENCE.md) — activation, status, offline grace, recovery
