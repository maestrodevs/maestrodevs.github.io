# Human Review Gates

> "Put a human review checkpoint between planning and implementation. Catching a wrong assumption in a three-line impact map costs far less than catching it in a pull request."
> — Captain directive 2026-05-10 (Harness Engineering framing)

## Why this exists

The Maestro dispatcher auto-advances orders through the role chain: PLN plans, BLD implements, TST tests. Until v2.7.0, the Captain saw the work at the PR stage — **after** BLD had already spent $0.40–2.00 implementing whatever PLN planned, right or wrong.

The human review gate inserts a **structure-in, structure-out checkpoint** at the cheapest moment: immediately after PLN produces its plan, before BLD starts a single line of code.

### The ROI case

| Event | Cost |
|-------|------|
| Operator reads PLN plan (~30 seconds) | ~$0.00 |
| Operator spots wrong assumption, runs `mso review revise` | ~$0.05 (PLN re-run) |
| BLD implements a wrong-direction plan | $0.40–2.00 |
| TST + DOC artefacts from a wrong run | Additional $0.20–0.50 |

A 30-second review of a three-line Repository Impact Map can prevent a $2.00+ wasted run. At scale, this compounds quickly. Operator review time is recorded in `mso usage` so you can see the harness-engineering ROI with receipts.

### Structure-in, structure-out principle

PLN produces a machine-readable **Repository Impact Map** alongside the free-form plan. This compresses the operator's review surface: instead of reading a full planning document, you scan:

1. Which files will change and why
2. What PLN assumed about the codebase
3. Whether the assumptions match your knowledge

If they do — approve. If one assumption is wrong — revise with a note. If the whole direction is wrong — reject and save the full BLD budget.

---

## Quick start

### 1. Enable the gate for your workspace

Create or edit `.mso/config/gates.json`:

```json
{
  "post_nav_review": {
    "enabled": true,
    "exempt_priorities": ["LOW"],
    "auto_approve_after_hours": 0
  }
}
```

Set `"enabled": true`. The gate is **off by default** — existing workspaces are unaffected until you opt in.

### 2. Dispatch as normal

```bash
mso dispatch
```

PLN runs as usual. When it completes, instead of auto-advancing to BLD, the order moves to `.mso/queues/review/` and a `NAV_REVIEW_PENDING` event fires. If you have the Slack bridge running, you'll receive a notification.

### 3. Check what's waiting for review

```bash
mso review queue
```

Output example:

```
ORDER ID              TITLE                              VOYAGE              AGE     ROLE
FTR-ACME-2026-0001    Plan schema for the review gate    VOY-ACME-2026-0003  12 min  PLN→BLD
FTR-ACME-2026-0002    Add export endpoint                VOY-ACME-2026-0004  4 hr    PLN→BLD
```

### 4. Inspect the plan

```bash
mso review show FTR-ACME-2026-0001
```

Opens the plan in `$EDITOR` (or prints to stdout if `$EDITOR` is unset). Focus on the **Repository Impact Map** and **Assumptions made** sections.

### 5. Approve, revise, or reject

```bash
# Looks good — advance to BLD
mso review approve FTR-ACME-2026-0001

# One assumption is wrong — send back to PLN with a note
mso review revise FTR-ACME-2026-0001 --notes "The auth module is in maestro/auth.py not maestro/core/auth.py — check imports"

# Completely wrong direction — halt the order
mso review reject FTR-ACME-2026-0001 --notes "This feature is already covered by FTR-ACME-2026-0002, closing as duplicate"
```

---

## Workspace configuration

Gate behaviour is controlled by `.mso/config/gates.json`. This file is created by `mso init` using `maestro/templates/gates.json.j2`. If the file is absent, all gates default to **off**.

### Full schema

```json
{
  "post_nav_review": {
    "enabled": false,
    "exempt_priorities": ["LOW"],
    "auto_approve_after_hours": 0
  }
}
```

### Key reference

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `post_nav_review.enabled` | boolean | `false` | Master switch for the PLN→BLD human review gate. Set to `true` to pause all orders after PLN completes. |
| `post_nav_review.exempt_priorities` | string[] | `["LOW"]` | Orders with these priority values skip the gate entirely and auto-advance to BLD. Use `[]` to gate everything. |
| `post_nav_review.auto_approve_after_hours` | number | `0` | If non-zero, orders in the review queue are automatically approved after this many hours with no operator action. `0` (default) disables auto-approve: the dispatcher waits indefinitely. |

### Tuning auto-approve

`auto_approve_after_hours: 0` is the recommended default for most workspaces. The gate exists because the operator's attention is valuable — disabling it eliminates the value.

However, for high-throughput workspaces or overnight runs where a human can't realistically review every plan, set a reasonable timeout:

```json
"auto_approve_after_hours": 8
```

This unblocks the dispatcher after a full working day without requiring operator action on every order. You'll still see `NAV_REVIEW_AUTO_APPROVED` events in the log and `mso usage` will record the review time as the full timeout duration, which accurately reflects the cost of unreviewed runs.

---

## Per-order override

The workspace default can be overridden on individual orders by adding a `gates` field to the order JSON.

### Force the gate on (even when workspace default is off)

```json
{
  "orderId": "FTR-ACME-2026-0001",
  "gates": ["nav_human_review"],
  ...
}
```

Use this when a specific order is high-stakes and you want to review PLN's plan regardless of workspace policy.

### Skip the gate (even when workspace default is on)

```json
{
  "orderId": "FTR-ACME-2026-0002",
  "gates": ["skip_nav_human_review"],
  ...
}
```

Use this for routine, well-understood orders where PLN has no meaningful scope ambiguity (e.g. a typo-fix order, a test-only order).

### Priority exemption

Orders with `priority: LOW` (or any value listed in `exempt_priorities`) skip the gate automatically. You don't need to add a `gates` override for these.

---

## CLI reference

All review commands operate on orders in `.mso/queues/review/`.

### `mso review queue`

List all orders awaiting operator review.

```bash
mso review queue
```

Columns: `ORDER ID`, `TITLE`, `VOYAGE`, `AGE`, `ROLE` (the role pair, e.g. `PLN→BLD`).

---

### `mso review show <ORDER-ID>`

Open the PLN plan for an order in your editor.

```bash
mso review show FTR-ACME-2026-0001
```

Opens `.mso/plans/PLAN-FTR-ACME-2026-0001.md` in `$EDITOR`. If `$EDITOR` is not set, prints the plan to stdout. Use `--editor vim` to override.

Focus on:
- **Repository Impact Map → Files to modify** — is the file list plausible?
- **Repository Impact Map → Symbols touched** — create/modify/delete — does that match your intent?
- **Assumptions made** — are any assumptions incorrect or outdated?

---

### `mso review approve <ORDER-ID>`

Approve the plan and advance the order to BLD.

```bash
mso review approve FTR-ACME-2026-0001
```

What happens:
1. Order moves from `.mso/queues/review/` to `.mso/queues/orders/`, with `role` set to `BLD`.
2. `NAV_REVIEW_APPROVED` lifecycle event fires.
3. `reviewedAt` and `reviewedBy` timestamps written to the order JSON.
4. `reviewTimeSeconds` written to `.mso/usage/orders/FTR-ACME-2026-0001.json`.
5. Next `mso dispatch` cycle picks up the order for BLD.

---

### `mso review revise <ORDER-ID> --notes "..."`

Send the order back to PLN with operator notes.

```bash
mso review revise FTR-ACME-2026-0001 \
  --notes "auth module is at maestro/auth.py — check all import paths in the plan"
```

What happens:
1. Notes are appended to the order's `description` field so PLN sees them on re-run.
2. Order role is reset to `PLN` and re-queued in `.mso/queues/orders/`.
3. `NAV_REVIEW_REVISED` lifecycle event fires.
4. `reviewedAt` and `reviewedBy` timestamps written to the order JSON.
5. Next dispatch cycle re-runs PLN, which produces a revised plan.
6. When PLN completes again, the gate fires again — you'll review the updated plan.

There is no limit to the number of revise cycles. Each cycle is visible in the lifecycle log and `mso usage`.

---

### `mso review reject <ORDER-ID> --notes "..."`

Reject the order permanently.

```bash
mso review reject FTR-ACME-2026-0001 \
  --notes "Duplicate of FTR-0099 — closing"
```

What happens:
1. Notes are written to the order JSON under `rejectionReason`.
2. Order moves to `.mso/orders/failed/`.
3. `NAV_REVIEW_REJECTED` lifecycle event fires.
4. `reviewedAt` and `reviewedBy` timestamps written to the order JSON.
5. The order **never re-dispatches**. If you want to re-open the work, create a new order.

---

## Lifecycle events

These events appear in `.mso/logs/`, `mso status`, and the Slack bridge.

| Event | Trigger | Recommended action |
|-------|---------|-------------------|
| `NAV_REVIEW_PENDING` | PLN completed, gate is active, order moved to review queue | Run `mso review queue` to see what's waiting |
| `NAV_REVIEW_APPROVED` | Operator ran `mso review approve` | No action needed — BLD will pick up the order on next dispatch |
| `NAV_REVIEW_REVISED` | Operator ran `mso review revise` | No action needed — PLN will re-run on next dispatch |
| `NAV_REVIEW_REJECTED` | Operator ran `mso review reject` | Order is closed — create a new order if the work is still needed |
| `NAV_REVIEW_AUTO_APPROVED` | `auto_approve_after_hours` timeout fired | No action required, but worth reviewing the plan retrospectively to tune the threshold |
| `NAV_PLAN_SCHEMA_WARN` | PLN plan is missing `Repository Impact Map` or `Assumptions made` sections | The plan still advances (warn-only in v2.7.0) — consider `mso review revise` if the missing structure makes the plan hard to evaluate |

### Silencing Slack noise

If `NAV_REVIEW_PENDING` notifications are too frequent, use the bridge filter rules in `.mso/config/bridge-settings.json` to silence or route the event class:

```json
{
  "filters": {
    "suppress_events": ["NAV_REVIEW_AUTO_APPROVED"]
  }
}
```

See [bridge-setup-guide.md](bridge-setup-guide.md) for the full filter reference.

---

## PLN plan schema

Starting in v2.7.0, PLN crews are expected to produce plans with two machine-readable sections. The gate parser checks for these sections when evaluating whether a plan is review-ready.

### Required sections

```markdown
## Repository Impact Map

### Files to modify
- `maestro/core/gates.py:1-80` — new gate config module

### Symbols touched
- `gate_check_post_nav()` (create)
- `dispatch_crew()` (modify) — add gate consultation after PLN completes

### Patterns to follow
- Follow the config-loading pattern in `maestro/core/fleet_runner.py` (see `load_workspace_config()`)

## Assumptions made (spot-check before BLD runs)
- The `.mso/config/gates.json` file may not exist in all workspaces — default config should be used when absent
- `dispatch_crew()` is called once per order, synchronously — no concurrent gate checks needed
```

### v2.7.0 behaviour: warn-only

In v2.7.0, if a PLN plan is missing either required section, the dispatcher emits `NAV_PLAN_SCHEMA_WARN` and **continues normally** — the plan is not blocked. This conservative rollout lets the new schema requirement propagate across all PLN crews before enforcement begins.

If you see `NAV_PLAN_SCHEMA_WARN` frequently, inspect the plan with `mso review show` — the free-form plan may still be sufficient for your review even without the structured sections.

### v2.8.0 roadmap: promote to block

After PLN crews have reliably emitted the structured sections for an observation period, v2.8.0 will promote `NAV_PLAN_SCHEMA_WARN` to `NAV_PLAN_SCHEMA_FAIL`, which marks the order as `FAILED` and requires a manual PLN re-run with a corrected prompt.

No action is required from operators today — this is documented so you understand the trajectory.

---

## Operator workflow: a typical day

### Morning check

```bash
mso review queue
```

Scan the queue. Most days it's empty or has one or two orders. Each entry takes 30–60 seconds to review.

### Review an order

```bash
mso review show FTR-ACME-2026-0002
```

Read the **Assumptions made** section first — that's where PLN is most likely to have made a mistake. Then scan **Files to modify** to confirm the blast radius is what you expected.

If everything looks right:
```bash
mso review approve FTR-ACME-2026-0002
```

If one assumption is wrong:
```bash
mso review revise FTR-ACME-2026-0002 --notes "The config loader is in maestro/config.py line 45, not utils.py"
```

If the whole direction is wrong:
```bash
mso review reject FTR-ACME-2026-0002 --notes "Scope changed — the requirement is being re-planned under a new order"
```

### Check review time in usage reports

```bash
mso usage --voyage VOY-ACME-2026-0003
```

Output includes:

```
Operator review time:  4 min 12 sec  (across 8 orders)
Total token cost:      $3.41
```

This is your harness-engineering dashboard: operator time invested vs. autonomous cost avoided.

---

## Edge cases

### Auto-approve timeout

When `auto_approve_after_hours` is non-zero and the operator takes no action, the dispatcher automatically approves the order and emits `NAV_REVIEW_AUTO_APPROVED`. The order advances to BLD as if the operator had approved it. The review time recorded in `mso usage` reflects the full wait duration.

**Default is 0 (disabled).** Enable only if you understand that automatic advancement without review defeats the purpose of the gate for those orders.

### Revised orders re-running PLN

When you run `mso review revise`, the order returns to PLN with your notes appended. PLN produces a new plan. The gate fires again when PLN completes — you will see another `NAV_REVIEW_PENDING` event and the order will appear in `mso review queue` again.

There is no loop prevention: if PLN continues to make the same mistake, you can keep revising. Each cycle costs the PLN token budget. After two or three revision cycles with no improvement, it may be more efficient to `reject` and manually write a more prescriptive order description.

### Rejected orders never re-dispatch

`mso review reject` moves an order to `.mso/orders/failed/` permanently. The dispatcher will not pick it up again. If the work is still needed:

1. Create a new order with a clearer description.
2. Reference the rejected order's `orderId` in the new order's `description` so PLN has the full context.

### Gate active, but no `.mso/config/gates.json`

If the file is absent, the gate defaults to **off** (`enabled: false`). The dispatcher behaves as it did before v2.7.0. This ensures backward compatibility for workspaces that haven't been updated since v2.6.x.

### Priority exemption

Orders with `priority` matching any value in `exempt_priorities` (default: `["LOW"]`) skip the gate and advance directly to BLD. This covers routine, low-stakes orders where operator review adds no value. To gate low-priority orders as well, set `"exempt_priorities": []`.

---

## Review time tracking and `mso usage`

Every review action is timestamped. When an order is approved (manually or auto), the dispatcher calculates:

```
reviewTimeSeconds = approvedAt - reviewPendingAt
```

This value is written to `.mso/usage/orders/<ORDER-ID>.json`:

```json
{
  "orderId": "FTR-ACME-2026-0001",
  "tokenCost": 0.38,
  "reviewTimeSeconds": 47,
  "reviewedBy": "captain",
  "reviewedAt": "2026-05-12T10:14:33Z"
}
```

Aggregated across a voyage:

```bash
mso usage --voyage VOY-ACME-2026-0003
```

```
VOY-ACME-2026-0003 — Human review gate PLN→BLD
  Orders completed:    6
  Total token cost:    $3.41
  Operator review:     4 min 12 sec
  Avg review/order:    42 sec
```

Use this data to tune the gate: if average review time climbs above 2–3 minutes per order, consider whether PLN's plans need a more prescriptive template or whether some order types should be exempted.

---

## See also

- [CLI-REFERENCE.md](CLI-REFERENCE.md) — full `adm` CLI reference
- [OPERATOR-GUIDE.md](OPERATOR-GUIDE.md) — day-to-day fleet operations
- [ROLES-GUIDE.md](ROLES-GUIDE.md) — role definitions (PLN, BLD, TST, DOC, SEC, REL)
- [bridge-setup-guide.md](bridge-setup-guide.md) — Slack bridge and event filtering
- BRANCH-DISCIPLINE.md — branch guard and `voyageBranch` enforcement
