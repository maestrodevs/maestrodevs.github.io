"""Worktree lifecycle primitives for parallel voyage isolation.

Provides prepare/cleanup/prune operations for git worktrees scoped to the
runtime worktree home under .mso/worktrees/<voyage_id>/ (FTR-MSO-2026-0364).

Per-crew isolation (BUG-MSO-2026-0240)
---------------------------------------
FTR-ADM-2026-0149 introduced a single shared worktree per voyage, which
caused concurrent crews of the same voyage to clobber each other's files
and git index. The fix gives every dispatched crew its OWN worktree on a
per-crew branch:

  .mso/worktrees/<voyage_id>/crew<N>   ← crew N works here
  .mso/worktrees/<voyage_id>/admin     ← voyage admin worktree
                                          (convergence merges only)

When a crew completes, its crew branch is merged back into the voyage branch
via merge_crew_branch_into_voyage() and the crew worktree is cleaned up.
Cross-voyage parallelism (different voyages → different voyage dirs) is
unaffected.

Worktree relocation (FTR-MSO-2026-0364, Captain ruling PLAN-PLN-MSO-2026-0358
§0a #6): worktrees used to live INSIDE voyages/active/<voyage_id>/ next to
durable JSON, polluting the artefact tree (GKT counted 55,857 files there,
nearly all node_modules). They now live under the gitignored runtime home
.mso/worktrees/. LEGACY worktrees at voyages/active/<VID>/.worktree[-crewN]
are still honoured for in-flight voyages: the path resolvers return the
legacy location while it exists on disk (so running work is never stranded),
and the cleanup/prune sweeps cover both homes so legacy worktrees are pruned
when their voyage completes. New voyages always create under .mso/worktrees/.
"""

from __future__ import annotations

import itertools
import json
import os
import re
import shutil
import subprocess
from maestro.core.proc import run_hidden, popen_hidden  # FTR-MSO-2026-0408: windowless subprocess
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

# FTR-MSO-2026-0362: the artefact dir name is never hand-spelled in this module;
# prefix tuples and pathspecs below build from the canonical constant.
from maestro.workspace import MSO_DIR_NAME

# BUG-MSO-2026-0306: monotonic counter for unique scratch-worktree paths within
# a process. Combined with the pid it guarantees `git worktree add` never
# collides with a leftover dir, even if a prior teardown failed on Windows.
_SCRATCH_SEQ = itertools.count()

# BUG-MSO-2026-0308: dispatcher CONTROL-PLANE paths — the dispatcher (voyage
# side) is authoritative for these; a crew branch only ever carries a STALE
# copy, so a convergence conflict here is auto-resolved in favour of the
# voyage. Crew DELIVERABLE paths under .mso (reports/, handoffs/, plans/,
# prompts/) are deliberately NOT here — they merge normally.
_CONTROL_PLANE_PREFIXES = tuple(
    f"{MSO_DIR_NAME}/{d}/" for d in ("queues", "orders", "voyages", "state", "usage")
)

# BUG-MSO-2026-0342: per-crew TELEMETRY paths — scratch the CREW writes as it
# works (progress.md etc.). In workspaces that track .mso/crews/ in git (this
# repo gitignores it; consumer workspaces like PSG may not), the crew branch
# carries the LATEST copy and the voyage side a stale one, so a convergence
# conflict here is auto-resolved in favour of the CREW. Never a reason to
# AUTO_SERIALIZE-requeue a completed role.
_CREW_TELEMETRY_PREFIXES = (
    f"{MSO_DIR_NAME}/crews/",
)

# BUG-MSO-2026-0501: ROOT-LEVEL crew bookkeeping filenames. A relative-path bug
# (fixed alongside this — see maestro/hooks/path_guard.py own_mso_crew_dir)
# let crews fall back to writing "progress.md" bare, landing at the repo ROOT
# instead of under .mso/crews/crew{N}/. That root-level copy is NOT covered by
# .mso/-prefixed .gitignore rules, so it got committed — and every crew wrote
# DIFFERENT content, so convergence hit a genuine-looking content conflict on
# a file whose contents are pure noise (four failed convergences on
# FTR-MSO-2026-0478 before this was diagnosed). This extends the BUG-0308
# auto-resolve mechanism beyond .mso/ so any branch still carrying a stray
# root-level copy (from before the write-path fix) still converges cleanly.
#
# Deliberately a narrow FILENAME allowlist, not "any file the crew authored" —
# a broad rule risks silently discarding a genuine source conflict that
# happens to share a common name. Matched only when the path has NO directory
# component (i.e. it truly sits at the repo root); a nested file that happens
# to be named "progress.md" (e.g. inside a test fixture) is unaffected.
# Winner is the VOYAGE side (--ours), same rule as the control-plane class —
# unlike .mso/crews/ telemetry, a stray root-level copy is not a legitimate
# per-crew scratch file worth preserving; either side's content is discardable
# noise, and matching the control-plane resolution direction keeps this one
# rule to explain instead of a third distinct convention.
_ROOT_LEVEL_BOOKKEEPING_FILENAMES = frozenset({"progress.md"})


def _bookkeeping_machinery_active() -> bool:
    """FTR-MSO-2026-0366: is the control-plane conflict machinery needed?

    The auto-resolve/flush/clean machinery below exists because EMBEDDED mode
    carries ``.mso`` inside the product repo, so dispatcher bookkeeping rides
    crew/voyage branches and collides at convergence (BUG-0305/0308/0342/0343).
    In solo/shared artefact-repo mode the product repos carry no ``.mso`` at
    all — crew→voyage merges are SOURCE ONLY — so the machinery is switched
    off cleanly rather than ported (plan PLAN-PLN-MSO-2026-0358 §3.4). Any
    leftover ``.mso`` conflict in a product repo then escalates as a genuine
    source conflict, which is the honest signal (it means migration hygiene
    failed, not that the dispatcher should paper over it).

    Fail-open to True (embedded behaviour) — full back-compat.
    """
    try:
        from maestro.workspace import get_artefact_mode
        return get_artefact_mode() == "embedded"
    except Exception:
        return True


def _is_control_plane_path(path: str) -> bool:
    """True if *path* (a git-relative path, forward-slashed) is dispatcher
    control-plane bookkeeping (BUG-MSO-2026-0308)."""
    p = path.strip().strip('"').replace("\\", "/")
    return any(p.startswith(prefix) for prefix in _CONTROL_PLANE_PREFIXES)


def _is_crew_telemetry_path(path: str) -> bool:
    """True if *path* (a git-relative path, forward-slashed) is per-crew
    telemetry/scratch (BUG-MSO-2026-0342)."""
    p = path.strip().strip('"').replace("\\", "/")
    return any(p.startswith(prefix) for prefix in _CREW_TELEMETRY_PREFIXES)


def _is_root_level_bookkeeping_path(path: str) -> bool:
    """True if *path* is a bare top-level crew-bookkeeping filename mistakenly
    written to the repo ROOT (BUG-MSO-2026-0501) rather than under
    .mso/crews/crew{N}/. Requires NO directory component — a path with any
    "/" is left to the normal .mso/-prefixed classification above."""
    p = path.strip().strip('"').replace("\\", "/")
    return "/" not in p and p in _ROOT_LEVEL_BOOKKEEPING_FILENAMES


def _autoresolve_bookkeeping_conflicts(run, conflict_files):
    """BUG-MSO-2026-0308 / BUG-MSO-2026-0342: auto-resolve a merge conflict that
    is confined to Maestro bookkeeping/telemetry paths, inside an in-progress
    (conflicted) merge.

    Control-plane paths keep the VOYAGE (dispatcher) copy (``--ours``);
    per-crew telemetry paths keep the CREW copy (``--theirs``). Neither class
    is ever a genuine content conflict — requeuing a completed role over them
    costs a full re-run (the PSG VOY-PSG-2026-0358 false-positives).

    ``run`` executes a git argv list in the merge worktree and returns a
    CompletedProcess. Returns ``(status, files)``:

    - ``("resolved", resolutions)`` — every conflict was bookkeeping/telemetry;
      the merge is committed and the caller proceeds to push. ``resolutions``
      lists ``"path (voyage)"`` / ``"path (crew)"`` for the lifecycle event.
    - ``("commit_failed", [detail])`` — auto-resolve could not commit; caller
      must ``git merge --abort`` and raise ``WorktreeError``.
    - ``("source", src_conflicts)`` — genuine source conflicts remain (or the
      conflict list was empty); caller must ``git merge --abort`` and escalate,
      reporting ONLY ``src_conflicts`` (telemetry noise filtered out).

    FTR-MSO-2026-0366: in solo/shared artefact-repo mode the ``.mso``-prefixed
    machinery is switched off — a conflict on a ``.mso/...`` path is treated as
    a genuine source conflict (product-repo merges must not contain ``.mso``
    paths at all). BUG-MSO-2026-0501: the ROOT-LEVEL filename check below is
    intentionally NOT gated by this — a stray top-level ``progress.md`` is
    never legitimate product source in EITHER mode (it is always residue of
    the write-path bug fixed alongside this in path_guard.py), so it keeps
    auto-resolving even in solo/shared workspaces where the rest of this
    machinery is off.
    """
    machinery_active = _bookkeeping_machinery_active()

    def _is_bookkeeping(f):
        if _is_root_level_bookkeeping_path(f):
            return True
        return machinery_active and (_is_control_plane_path(f) or _is_crew_telemetry_path(f))

    src_conflicts = [f for f in conflict_files if not _is_bookkeeping(f)]
    if not conflict_files or src_conflicts:
        return "source", src_conflicts
    resolutions = []
    for f in conflict_files:
        if _is_root_level_bookkeeping_path(f) or _is_control_plane_path(f):
            side, winner = "--ours", "voyage"
        else:
            side, winner = "--theirs", "crew"
        run(["git", "checkout", side, "--", f])
        run(["git", "add", "--", f])
        resolutions.append(f"{f} ({winner})")
    commit_r = run(["git", "commit", "--no-edit"])
    if commit_r.returncode != 0:
        return "commit_failed", [commit_r.stderr.strip()]
    return "resolved", resolutions


# BUG-MSO-2026-0343: git refuses to START a merge when UNTRACKED working-tree
# files would be overwritten by it — no index conflict entries exist yet, so
# `git diff --diff-filter=U` is empty and the old error said "Conflicting
# files: unknown". The blocking paths are only available in git's own output.
_UNTRACKED_OVERWRITE_RE = re.compile(
    r"untracked working tree files would be (?:overwritten|removed) by "
    r"(?:merge|checkout):\s*\n((?:[ \t]+[^\n]*\n?)+)",
    re.IGNORECASE,
)


def _parse_untracked_overwrite_paths(git_output: str) -> list:
    """Extract the paths git lists under 'error: The following untracked
    working tree files would be overwritten by merge:' (BUG-MSO-2026-0343).

    Returns [] when the output does not contain that error."""
    paths = []
    for m in _UNTRACKED_OVERWRITE_RE.finditer(git_output or ""):
        for line in m.group(1).splitlines():
            p = line.strip().strip('"')
            if p:
                paths.append(p)
    return paths


def _clean_untracked_bookkeeping(run) -> list:
    """BUG-MSO-2026-0343: remove UNTRACKED files under Maestro bookkeeping/
    telemetry prefixes from the convergence worktree before merging.

    `git reset --hard origin/<voyage>` syncs TRACKED state only — telemetry a
    prior convergence attempt wrote into the voyage worktree (the PSG case:
    .mso/usage/orders/<order>.json) stays behind untracked and makes every
    subsequent merge of a crew branch that tracks the same path fail with
    "untracked working tree files would be overwritten by merge", stranding
    the order CONVERGENCE_FAILED. The branch/origin copy is authoritative for
    all of these paths, so deleting the local leftovers is always safe.

    Only non-gitignored untracked files are removed (gitignored files never
    block a merge). Returns the list of paths removed (possibly empty).

    FTR-MSO-2026-0366: the ``.mso``-prefixed part is a no-op in solo/shared
    artefact-repo mode — product-repo worktrees carry no Maestro bookkeeping to
    clean there. BUG-MSO-2026-0501: the root-level filenames are cleaned
    regardless of mode, same rationale as `_is_root_level_bookkeeping_path`."""
    pathspecs = list(_ROOT_LEVEL_BOOKKEEPING_FILENAMES)
    if _bookkeeping_machinery_active():
        pathspecs += list(_CONTROL_PLANE_PREFIXES + _CREW_TELEMETRY_PREFIXES)
    if not pathspecs:
        return []
    ls_r = run(["git", "ls-files", "--others", "--exclude-standard", "--"] + pathspecs)
    if ls_r.returncode != 0:
        return []
    untracked = [ln.strip().strip('"') for ln in ls_r.stdout.splitlines() if ln.strip()]
    if not untracked:
        return []
    run(["git", "clean", "-fdq", "--"] + pathspecs)
    return untracked


from maestro.workspace import resolve_artefact_dir as _resolve_artefact_dir

from maestro.core import fleet_runner as _fleet_runner
from maestro.core.fleet_runner import _robust_rmtree

# Module-level lock to serialize concurrent prepare calls for the same worktree
_prepare_lock = threading.Lock()

# Serialize convergence merges to avoid concurrent pushes to the same voyage branch
_merge_lock = threading.Lock()


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class WorktreeError(Exception):
    """Base class for worktree lifecycle errors."""


class WorktreeBranchConflict(WorktreeError):
    """Branch is already checked out in another worktree."""


class WorktreeDirExists(WorktreeError):
    """Worktree directory exists but is not registered with git."""


class WorktreeMissingBranch(WorktreeError):
    """The requested branch does not exist and cannot be created."""


class WorktreeBranchDrift(WorktreeError):
    """A worktree that should be on its expected branch is checked out elsewhere.

    BUG-MSO-2026-0544: disk existence + `git worktree list` registration are
    NOT proof a worktree is on the branch dispatch expects. PSG voyage
    VOY-PSG-2026-0421's crew3 worktree was found checked out to `master` with
    a pre-voyage HEAD -- the crew (and the auto-commit safety net) worked
    against stale content, producing two silent-corruption defects (#367,
    #368) with a green run. Raised when a mismatch is detected and cannot be
    repaired inline; callers that can repair (remove + recreate) do so instead
    of raising.

    Attributes:
        actual_branch: the branch actually checked out (None if undeterminable).
        expected_branch: the branch dispatch expected.
    """

    def __init__(self, message: str, actual_branch: Optional[str], expected_branch: str):
        super().__init__(message)
        self.actual_branch = actual_branch
        self.expected_branch = expected_branch


class WorktreeContentConflict(WorktreeError):
    """Merge failed due to a genuine content/add-add conflict (FTR-MSO-2026-0267).

    Raised instead of generic WorktreeError when `git merge` exits non-zero AND
    there are conflicting files (--diff-filter=U).  Distinguished from REF_MISSING
    (crew branch not found) and push failures so the dispatcher can auto-serialize
    the loser order instead of immediately escalating to CONVERGENCE_FAILED.

    Attributes:
        conflict_files: list of relative paths that conflicted.
    """

    def __init__(self, message: str, conflict_files: list):
        super().__init__(message)
        self.conflict_files = conflict_files


class ConvergenceNetworkError(WorktreeError):
    """Convergence failed due to a transient network/timeout condition (BUG-MSO-2026-0268).

    Raised when a git network op (voyage fetch, crew fetch, voyage push) times out
    or fails for a reason that indicates a transient infrastructure problem rather
    than a real content conflict or missing ref.

    Unlike WorktreeContentConflict (real merge conflict — may need operator) or
    REF_MISSING (crew branch absent — work is truly lost), this error class means
    the work is intact and convergence can be retried without re-running the role.
    The dispatcher re-queues the order for a convergence-only retry.
    """


# ---------------------------------------------------------------------------
# Convergence retry config
# ---------------------------------------------------------------------------

# Exponential backoff delays (seconds) for convergence network ops (BUG-MSO-2026-0268).
# 3 attempts: immediate, then 1 s, then 3 s before giving up.
# BUG-MSO-2026-0272: inner x outer retry budget.
# This inner loop (3 attempts) is independent of the outer convergence-retry loop in
# fleet_runner._CONVERGENCE_RETRY_CAP (also 3).  Combined with re-queue-as-PENDING
# between outer attempts, a persistently broken network will attempt each net op up to
# 3 x 3 = 9 times (with 2 full role re-executions between outer retries) before the
# order is marked CONVERGENCE_FAILED.  See fleet_runner._CONVERGENCE_RETRY_CAP.
_CONVERGENCE_RETRY_DELAYS = (0, 1, 3)


def _retry_git_network_op(cmd: list, *, cwd: str, timeout: int) -> subprocess.CompletedProcess:
    """Run a git network command with exponential-backoff retry (BUG-MSO-2026-0268).

    Attempts the command up to len(_CONVERGENCE_RETRY_DELAYS) times. Between
    attempts it sleeps for the delay specified in _CONVERGENCE_RETRY_DELAYS.
    A subprocess.TimeoutExpired on the LAST attempt is re-raised as
    ConvergenceNetworkError so callers can distinguish transient from terminal.

    Returns the CompletedProcess from the first successful attempt (returncode==0).
    Raises ConvergenceNetworkError if all attempts fail or time out.
    """
    last_exc: Optional[Exception] = None
    last_result: Optional[subprocess.CompletedProcess] = None

    for attempt, delay in enumerate(_CONVERGENCE_RETRY_DELAYS):
        if delay > 0:
            time.sleep(delay)
        try:
            result = run_hidden(cmd, capture_output=True, text=True,
                                    cwd=cwd, timeout=timeout)
            last_result = result
            if result.returncode == 0:
                return result
            # Non-zero return on a network op may be transient (temporary
            # connectivity loss) or permanent (auth failure, missing ref).
            # Re-raise after retries as ConvergenceNetworkError; the caller
            # can inspect stderr to further classify if needed.
            last_exc = None
        except subprocess.TimeoutExpired as exc:
            last_exc = exc
            last_result = None

    # All retries exhausted
    detail = ""
    if last_exc is not None:
        detail = f"timed out after {timeout}s (command: {' '.join(cmd)})"
    elif last_result is not None:
        stderr = (last_result.stderr or "").strip()
        stdout = (last_result.stdout or "").strip()
        detail = f"returncode={last_result.returncode} stderr={stderr!r} stdout={stdout!r}"
    raise ConvergenceNetworkError(
        f"Git network op failed after {len(_CONVERGENCE_RETRY_DELAYS)} attempts: {detail}"
    )


# ---------------------------------------------------------------------------
# Worktree-add retry config (BUG-MSO-2026-0345)
# ---------------------------------------------------------------------------

# Short backoff for `git worktree add` on the transient dir-collision class.
# On Windows, a just-killed crew process can hold its previous worktree dir
# open (process cwd, AV scan) for a few seconds after teardown, so the orphan
# sweep leaves the dir behind and git refuses with "fatal: '<dir>' already
# exists". PSG observed the condition clear within ONE second (2-for-2 on
# consecutive same-crew re-dispatches, VOY-PSG-2026-0358). 3 attempts:
# immediate, then 1 s, then 3 s.
_WORKTREE_ADD_RETRY_DELAYS = (0, 1, 3)


def _flatten_git_output(text: Optional[str]) -> str:
    """Collapse multi-line git output onto one line for lifecycle.log.

    BUG-MSO-2026-0345: `git worktree add` prints "Preparing worktree (...)"
    followed by the actual "fatal: ..." reason on a later line. lifecycle.log
    is a one-line-per-event format, so an embedded newline silently drops the
    fatal detail (PSG saw the message truncate after 'Preparing worktree').
    """
    return "; ".join(
        ln.strip() for ln in (text or "").strip().splitlines() if ln.strip()
    )


def _is_transient_worktree_add_failure(stderr: Optional[str]) -> bool:
    """True when a failed `git worktree add` is worth retrying (BUG-MSO-2026-0345).

    Structural failures (branch checked out elsewhere, already-registered
    path, missing refs) are excluded — retrying those cannot help and the
    callers classify them into typed exceptions instead.
    """
    s = (stderr or "").lower()
    if "already checked out" in s or "already used by worktree" in s:
        return False  # WorktreeBranchConflict — structural
    if "already registered" in s:
        return False  # caller's idempotency check handles this
    return (
        "already exists" in s          # leftover dir (Windows lock latency)
        or "permission denied" in s    # lingering NTFS handle
        or "resource busy" in s
        or "unable to create" in s
    )


def _worktree_add_with_retry(build_cmd, wt_path: Path, orphan_label: str,
                             cwd: Optional[Path] = None):
    """Run `git worktree add` with short-backoff retries (BUG-MSO-2026-0345).

    ``build_cmd`` is a zero-arg callable returning the argv list — rebuilt per
    attempt because branch existence can change between attempts (e.g. a
    partially-failed ``-b`` attempt that did create the branch).

    Between attempts the stale dir that blocked the previous attempt is
    re-swept (orphan rmtree + ``git worktree prune``), giving the Windows
    file lock time to clear.

    ``cwd`` (FTR-MSO-2026-0377) selects the product repo the worktree is added
    to / pruned from; ``None`` keeps the single-repo behaviour (dispatcher's
    own repo). ``build_cmd`` must itself target ``cwd`` for the actual add.

    Returns ``(result, failed_attempts, last_error)`` where ``result`` is the
    final CompletedProcess, ``failed_attempts`` counts attempts that failed
    before it, and ``last_error`` is the flattened stderr of the most recent
    failure ("" when the first attempt succeeded).
    """
    _git_cwd = str(cwd) if cwd else None
    result = None
    failed_attempts = 0
    last_error = ""
    for delay in _WORKTREE_ADD_RETRY_DELAYS:
        if failed_attempts:
            if delay:
                time.sleep(delay)
            if wt_path.exists() and wt_path.resolve(strict=False) not in _registered_worktrees(cwd):
                _robust_rmtree(wt_path, label=orphan_label)
            run_hidden(["git", "worktree", "prune"], capture_output=True, cwd=_git_cwd)
        result = run_hidden(build_cmd(), capture_output=True, text=True, cwd=_git_cwd)
        if result.returncode == 0:
            return result, failed_attempts, last_error
        last_error = _flatten_git_output(result.stderr)
        if not _is_transient_worktree_add_failure(result.stderr):
            return result, failed_attempts, last_error
        failed_attempts += 1
    return result, failed_attempts, last_error


def _warn_worktree_add_recovered(what: str, failed_attempts: int,
                                 last_error: str) -> None:
    """Emit a WARN lifecycle event for a self-recovered worktree add.

    BUG-MSO-2026-0345: the pre-retry behaviour surfaced this transient class
    as an error-level WORKTREE_FAIL, which reads as fatal and can page an
    operator even though the very next dispatch tick succeeded.
    """
    try:
        from maestro.core.fleet_runner import write_lifecycle_event
        write_lifecycle_event(
            "WARN",
            f"transient worktree add failure self-recovered for {what} after "
            f"{failed_attempts} failed attempt(s) — last git error: "
            f"{last_error} — retried with backoff, no operator action needed "
            f"(BUG-0345)"
        )
    except Exception:
        pass


def _identify_worktree_lock_holder(path: Path) -> str:
    """Best-effort identification of the process still holding *path* open
    (BUG-MSO-2026-0460, GitHub #314).

    Windows refuses to delete a directory (or any file within it) while a
    process has it open — most often a stranded crew child process whose
    working directory was the worktree, left behind when the dispatcher's
    kill/wait loop failed to fully reap it. Two strategies, in order:

      1. Sysinternals `handle.exe` / `handle64.exe`, if present on PATH — the
         canonical tool for exactly this question; reports PID + image name
         for every handle open under *path*.
      2. A PowerShell scan of live processes' CommandLine (Win32_Process) for
         the worktree path — catches the common case (the offending process
         was launched with the worktree path as an argument or cwd hint)
         without requiring the operator to install anything.

    Returns a short human-readable string for a STALLED reason so the
    operator knows what to kill instead of guessing. Never raises — this is
    best-effort diagnostics and must never block the escalation it feeds;
    both "not applicable" and "nothing found" return a descriptive sentence
    rather than an empty string.
    """
    if os.name != "nt":
        return "not determined (lock-holder detection is Windows-only)"
    try:
        exe = shutil.which("handle") or shutil.which("handle64")
        if exe:
            result = run_hidden(
                [exe, "-accepteula", "-u", str(path)],
                capture_output=True, text=True, timeout=15,
            )
            hits = [
                ln.strip() for ln in (result.stdout or "").splitlines()
                if ln.strip() and "pid:" in ln.lower()
            ]
            if hits:
                return "; ".join(hits[:5])
    except Exception:
        pass
    try:
        escaped = str(path).replace("'", "''")
        ps_cmd = (
            "Get-CimInstance Win32_Process | "
            f"Where-Object {{ $_.CommandLine -like '*{escaped}*' }} | "
            "Select-Object -First 5 ProcessId,Name | ForEach-Object "
            '{ "PID $($_.ProcessId) ($($_.Name))" }'
        )
        result = run_hidden(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command", ps_cmd],
            capture_output=True, text=True, timeout=15,
        )
        hits = [ln.strip() for ln in (result.stdout or "").splitlines() if ln.strip()]
        if hits:
            return "; ".join(hits)
    except Exception:
        pass
    return ("could not be determined automatically — inspect with Process "
            "Explorer or `handle <path>` (Sysinternals)")


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _repo_root() -> Path:
    """Return the product-repo root for worktree git operations.

    Reconciliation contract (FTR-MSO-2026-0362, plan PLAN-PLN-MSO-2026-0358
    §2.1): this is the module's SINGLE product-repo derivation, and in
    embedded mode it equals ``maestro.workspace.get_product_repo()`` by
    construction — the dispatcher runs at the product-repo root, whose
    ``.mso`` parent IS the git toplevel. It deliberately derives from
    ``git rev-parse --show-toplevel`` (cwd truth) rather than the env-first
    resolver: worktree primitives operate on the repo the calling process is
    standing in, and callers (tests included) drive them from scratch repos
    that have no resolvable workspace — while ``MAESTRO_DIR`` may
    legitimately point at an isolated workspace (the pytest autouse guard,
    BUG-MSO-2026-0327). Phase 4 (plan §4.3.5) replaces the *call sites* with
    ``get_product_repo(order.targetRepo)`` and retires this helper; do not
    add new callers.
    """
    result = run_hidden(
        ["git", "rev-parse", "--show-toplevel"],
        capture_output=True, text=True
    )
    if result.returncode != 0:
        raise WorktreeError(f"Not inside a git repository: {result.stderr.strip()}")
    return Path(result.stdout.strip())


def _registered_worktrees(cwd: Optional[Path] = None) -> set[Path]:
    """Return the set of resolved paths currently registered with git worktree.

    ``cwd`` (FTR-MSO-2026-0377) selects the product repo the worktree list is
    read from — ``None`` (default) means the dispatcher's own repo, keeping the
    single-repo path byte-identical; a per-repo checkout is passed in multi-repo
    dispatch so each repo's worktrees are resolved independently.
    """
    result = run_hidden(
        ["git", "worktree", "list", "--porcelain"],
        capture_output=True, text=True,
        cwd=str(cwd) if cwd else None,
    )
    paths = set()
    for line in result.stdout.splitlines():
        if line.startswith("worktree "):
            raw = line[len("worktree "):].strip()
            # Canonicalise so comparisons are robust across path representations
            # (relative/absolute, slashes, symlinks, Windows case) — the callers
            # resolve() their side too before membership-testing (Copilot, PR #187).
            paths.add(Path(raw).resolve(strict=False))
    return paths


def _branch_exists_local(branch: str, cwd: Optional[Path] = None) -> bool:
    """Check whether ``refs/heads/<branch>`` exists in the local repo.

    ``cwd`` (FTR-MSO-2026-0377) selects the product repo; ``None`` keeps the
    single-repo behaviour (dispatcher's own repo)."""
    result = run_hidden(
        ["git", "rev-parse", "--verify", f"refs/heads/{branch}"],
        capture_output=True,
        cwd=str(cwd) if cwd else None,
    )
    return result.returncode == 0


def _branch_exists_remote(branch: str, remote: str = "origin",
                          cwd: Optional[Path] = None) -> bool:
    """Check whether ``refs/remotes/<remote>/<branch>`` exists in the local repo.

    Returns True if the remote-tracking ref is present locally. Does not call
    ``git fetch`` — use :func:`_fetch_remote_branch` first if you need to
    refresh the local view of the remote. ``cwd`` (FTR-MSO-2026-0377) selects
    the product repo; ``None`` keeps single-repo behaviour.
    """
    result = run_hidden(
        ["git", "rev-parse", "--verify", f"refs/remotes/{remote}/{branch}"],
        capture_output=True,
        cwd=str(cwd) if cwd else None,
    )
    return result.returncode == 0


def _fetch_remote_branch(branch: str, remote: str = "origin",
                         cwd: Optional[Path] = None) -> bool:
    """Fetch a single branch from *remote* into the matching remote-tracking ref.

    BUG-MSO-2026-0027: the dispatcher creates voyage branches via ``gh api``,
    which only touches the GitHub remote — the local repo has no record of
    the new ref until something fetches. Without this, ``git worktree add``
    fails because ``refs/heads/<branch>`` doesn't exist. ``cwd``
    (FTR-MSO-2026-0377) selects the product repo; ``None`` keeps single-repo
    behaviour.
    """
    result = run_hidden(
        ["git", "fetch", remote, f"{branch}:refs/remotes/{remote}/{branch}"],
        capture_output=True, text=True, timeout=30,
        cwd=str(cwd) if cwd else None,
    )
    return result.returncode == 0


def worktree_head_branch(path: Path, timeout: int = 10) -> Optional[str]:
    """Return the branch currently checked out AT ``path``, or ``None``.

    BUG-MSO-2026-0544: the one cheap check that was missing everywhere a
    worktree was handed to a crew as "ready" -- existence on disk and
    registration in ``git worktree list`` both say nothing about which
    branch is actually checked out. PSG's crew3 worktree was fully registered
    and present, yet ``git -C <path> status -sb`` read ``## master...origin/
    master`` with a HEAD that predated the voyage. This runs directly inside
    the worktree (its own independent ``.git`` file), not against ``cwd`` /
    repo_root.

    Returns ``None`` (never raises) on a detached HEAD or any git/timeout
    failure -- callers must treat ``None`` as "not proven to be the expected
    branch" (fail closed), not as "assume fine".
    """
    try:
        result = run_hidden(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True, text=True, timeout=timeout, cwd=str(path),
        )
    except Exception:
        return None
    if result.returncode != 0:
        return None
    branch = result.stdout.strip()
    return branch if branch and branch != "HEAD" else None


_WORKTREE_CONFLICT_PATH_RE = re.compile(
    r"already (?:used by worktree|checked out) at '([^']+)'")


def _crew_worktree_leaf_names(crew_num: int, repo_name: str = "") -> set:
    """Leaf directory names a valid crew worktree for (crew_num, repo_name)
    could be known by, across the canonical new home and the legacy one.
    Multi-repo (*repo_name* set) worktrees have no legacy home (FTR-0377)."""
    if repo_name:
        return {f"crew{crew_num}-{repo_name}"}
    return {f"crew{crew_num}", f".worktree-crew{crew_num}"}


def _voyage_worktree_leaf_names(repo_name: str = "") -> set:
    """Leaf directory names a valid voyage/admin worktree could be known by."""
    if repo_name:
        return {f"admin-{repo_name}"}
    return {"admin", ".worktree"}


def _reusable_worktree_from_conflict(stderr: str, expected_branch: str,
                                     voyage_id: str, valid_leaf_names: set,
                                     cwd: Optional[Path] = None) -> Optional[Path]:
    """Return a pre-existing worktree named in a conflict error, if it is safe to
    REUSE (BUG-MSO-2026-0568).

    A ``git worktree add <new-path> <branch>`` conflict names the path
    already holding *branch* directly in its stderr (git's own message —
    ``already used by worktree at '<path>'`` on modern git, ``already checked
    out at '<path>'`` on older). Historically this was always treated as an
    unrecoverable conflict, but the ordinary cause is exactly the class this
    bug fixes: a prior dispatch invocation resolved the artefact root
    differently (a different cwd resolved a different — but equally valid —
    location before this fix), created the worktree there, and a later
    invocation now resolves the CORRECT canonical path and finds it empty,
    while the branch is legitimately already checked out at the OLD one.
    That is completed work, not a conflict — burning requeues and stalling it
    (GitHub #376) is the wrong outcome.

    This must NOT reuse an arbitrary path merely because it happens to carry
    the expected branch — that IS a genuine conflict (e.g. a manual checkout,
    or the primary workspace checkout itself; see the pre-existing
    ``test_branch_conflict_raises`` / ``test_*_structural_conflict*``
    regression suite, which this helper is deliberately scoped to keep
    passing). It is scoped to look like THIS voyage/crew's own worktree
    relocated: the candidate's immediate parent directory must be named
    *voyage_id* (true of both the canonical ``<root>/worktrees/<VID>/...``
    home and the legacy ``voyages/active/<VID>/...`` home, regardless of
    which artefact root anchors ``<root>``) and its leaf name must be one of
    *valid_leaf_names* (the exact crew/admin naming this call is for — see
    ``_crew_worktree_leaf_names`` / ``_voyage_worktree_leaf_names``).

    Also requires ``fleet_runner._MAESTRO_DIR_OVERRIDE`` to be set at call
    time (BUG-MSO-2026-0601): the reuse this function grants is for a caller
    that KNOWS which workspace it targets (an explicit override — e.g.
    ``workspace_scope()``) but finds a stale/relocated worktree from an
    earlier resolution of that SAME intentional target. A caller with no
    override at all is resolving via ambient cwd — the "which workspace did
    you mean" question was never actually answered — and silently handing
    back a worktree that happens to share a voyage id/branch would paper over
    exactly the inconsistent-scoping bug BUG-MSO-2026-0601 exists to surface
    (``test_gh_376_inconsistent_scoping_collides_with_existing_worktree``):
    that case must still raise WorktreeBranchConflict so the caller fixes its
    scoping rather than being silently bridged across two different targets.

    Even then, the existing path must be verifiably safe to hand back: it
    must exist, be registered with git, and (per BUG-MSO-2026-0544) have the
    EXACT expected branch actually checked out — never trust path/branch-name
    matching alone.
    """
    if _fleet_runner._MAESTRO_DIR_OVERRIDE is None:
        return None
    match = _WORKTREE_CONFLICT_PATH_RE.search(stderr or "")
    if not match:
        return None
    candidate = Path(match.group(1))
    if candidate.name not in valid_leaf_names:
        return None
    if candidate.parent.name != voyage_id:
        return None
    if not candidate.exists():
        return None
    if candidate.resolve(strict=False) not in _registered_worktrees(cwd):
        return None
    if worktree_head_branch(candidate) != expected_branch:
        return None
    return candidate


def _warn_worktree_reused(what: str, path: Path, branch: str) -> None:
    """Emit a lifecycle note when a pre-existing worktree is reused instead of
    treated as an unrecoverable conflict (BUG-MSO-2026-0568)."""
    try:
        from maestro.core.fleet_runner import write_lifecycle_event
        write_lifecycle_event(
            "WARN",
            f"{what}: reused pre-existing worktree at {path} (already on the "
            f"expected branch `{branch}`) instead of failing WORKTREE_REQUIRED "
            "on a directory-location disagreement (BUG-MSO-2026-0568)."
        )
    except Exception:
        pass


def _warn_worktree_branch_drift(what: str, path: Path, expected: str,
                                actual: Optional[str]) -> None:
    """Emit a loud BRANCH_MISMATCH lifecycle event for a detected drift.

    BUG-MSO-2026-0544: unlike BUG-0345's transient-lock WARN (a routine,
    expected recovery), a worktree found on the wrong branch means a crew was
    one call away from running against stale/foreign content. The caller
    removes the corrupted worktree and refuses this dispatch attempt (a
    WORKTREE_FAIL follows from the fleet_runner exception handler); this
    event captures the drift itself — which branch, expected vs actual —
    before that detail is gone. Reuses the existing BRANCH_MISMATCH event
    name (order acceptance criterion) — no new lifecycle vocabulary.
    """
    try:
        from maestro.core.fleet_runner import write_lifecycle_event
        write_lifecycle_event(
            "BRANCH_MISMATCH",
            f"{what}: found on branch `{actual or '<unknown/detached>'}`, "
            f"expected `{expected}` at {path} — removing and refusing this "
            "dispatch (BUG-MSO-2026-0544)."
        )
    except Exception:
        pass


def _force_remove_worktree(path: Path, cwd: Optional[Path] = None,
                           label: str = "") -> None:
    """Forcibly detach ``path`` from git's worktree admin store and delete it.

    BUG-MSO-2026-0544: used to discard a worktree caught on the wrong branch
    before recreating it fresh. ``git worktree remove --force`` first, so the
    admin entry is cleared and a subsequent ``git worktree add`` at the same
    path is never itself misclassified as "already registered"; falls back to
    a plain ``_robust_rmtree`` (the directory may already be off the admin
    store, e.g. the exact orphaned-but-present state PSG hit) followed by
    ``git worktree prune`` either way.
    """
    _git_cwd = str(cwd) if cwd else None
    run_hidden(["git", "worktree", "remove", "--force", str(path)],
              capture_output=True, cwd=_git_cwd)
    if path.exists():
        _robust_rmtree(path, label=label or f"branch-drift {path.name}")
    run_hidden(["git", "worktree", "prune"], capture_output=True, cwd=_git_cwd)


# Backward-compat alias; new callers should use the explicit local/remote form.
def _branch_exists(branch: str) -> bool:
    return _branch_exists_local(branch)


# BUG-MSO-2026-0347: branch names treated as a remote default branch even when
# refs/remotes/origin/HEAD is not resolvable locally (it is only populated by
# `git clone` / `git remote set-head`, so many dispatcher checkouts lack it).
_COMMON_DEFAULT_BRANCHES = ("master", "main")


def _resolve_origin_default_branch(repo_dir=None) -> str:
    """Best-effort LOCAL resolution of origin's default branch (no network).

    Reads ``refs/remotes/origin/HEAD``; returns the bare branch name (e.g.
    ``master``) or ``""`` when the symref is absent/unreadable.
    """
    try:
        result = run_hidden(
            ["git", "symbolic-ref", "--short", "refs/remotes/origin/HEAD"],
            capture_output=True, text=True, timeout=10,
            cwd=str(repo_dir) if repo_dir else None,
        )
        if result.returncode == 0:
            ref = result.stdout.strip()
            return ref[len("origin/"):] if ref.startswith("origin/") else ref
    except Exception:
        pass
    return ""


def is_default_branch(branch: str, repo_dir=None) -> bool:
    """True when *branch* is (or is conventionally named as) the remote default
    branch — the ref the dispatcher must never auto-push (BUG-MSO-2026-0347)."""
    b = (branch or "").strip().replace("refs/heads/", "")
    if not b:
        return False
    if b in _COMMON_DEFAULT_BRANCHES:
        return True
    resolved = _resolve_origin_default_branch(repo_dir)
    return bool(resolved) and b == resolved


def _default_branch_push_opted_in() -> bool:
    """BUG-MSO-2026-0347: ``lifecycle.allowDefaultBranchPush`` in workspace.json
    (default OFF — pushing the remote default branch is opt-in)."""
    try:
        import json
        # BUG-MSO-2026-0425: workspace.json is ARTEFACT config → artefact root.
        from maestro.workspace import get_artefact_root
        cfg = json.loads(
            (get_artefact_root() / "config" / "workspace.json").read_text(encoding="utf-8"))
        return bool((cfg.get("lifecycle") or {}).get("allowDefaultBranchPush", False))
    except Exception:
        return False


def default_branch_push_guard(branch: str, context: str, repo_dir=None) -> bool:
    """Return True when pushing *branch* to origin is permitted.

    BUG-MSO-2026-0347: on PSG, dispatcher bookkeeping (``lifecycle: advance/
    archive`` + salvage commits) was pushed straight to origin/master because a
    voyage branch resolved to the repo's default branch — bypassing the
    project's PR-only policy. Every dispatcher-side ``git push origin
    <computed-branch>`` must pass this guard: the remote default branch is
    never auto-pushed unless the operator opts in via
    ``lifecycle.allowDefaultBranchPush`` in workspace.json. Blocked pushes emit
    a WARN lifecycle event; bookkeeping stays local for the operator's sweep PR.
    """
    if not is_default_branch(branch, repo_dir):
        return True
    if _default_branch_push_opted_in():
        try:
            from maestro.core.fleet_runner import write_lifecycle_event
            write_lifecycle_event(
                "WARN",
                f"{context}: pushing remote default branch '{branch}' — permitted "
                f"by lifecycle.allowDefaultBranchPush=true (BUG-0347)")
        except Exception:
            pass
        return True
    try:
        from maestro.core.fleet_runner import write_lifecycle_event
        write_lifecycle_event(
            "WARN",
            f"{context}: push to remote default branch '{branch}' REFUSED — "
            f"lifecycle/salvage bookkeeping stays local; reconcile via a sweep "
            f"PR, point the voyage at a dedicated voyage/* branch, or set "
            f"lifecycle.allowDefaultBranchPush=true in workspace.json to opt "
            f"in (BUG-0347)")
    except Exception:
        pass
    return False


def _find_worktree_for_branch(branch: str,
                              cwd: Optional[Path] = None) -> Optional[Path]:
    """Return the worktree path where *branch* is currently checked out, or None.

    ``cwd`` (FTR-MSO-2026-0378) selects the product repo whose worktree list is
    queried; ``None`` keeps the single-repo behaviour (dispatcher's own repo).
    """
    result = run_hidden(
        ["git", "worktree", "list", "--porcelain"],
        capture_output=True, text=True,
        cwd=str(cwd) if cwd else None,
    )
    current_wt: Optional[Path] = None
    for line in result.stdout.splitlines():
        if line.startswith("worktree "):
            current_wt = Path(line[len("worktree "):].strip())
        elif line.startswith("branch ") and line.split()[-1] == f"refs/heads/{branch}":
            return current_wt
    return None


def _primary_worktree_path(cwd: Optional[Path] = None) -> Optional[Path]:
    """The PRIMARY repo checkout — first entry of `git worktree list --porcelain`.

    ``cwd`` (FTR-MSO-2026-0378) selects the product repo; ``None`` keeps the
    single-repo behaviour.
    """
    result = run_hidden(
        ["git", "worktree", "list", "--porcelain"],
        capture_output=True, text=True,
        cwd=str(cwd) if cwd else None,
    )
    for line in result.stdout.splitlines():
        if line.startswith("worktree "):
            return Path(line[len("worktree "):].strip())
    return None


def _is_primary_worktree(path, cwd: Optional[Path] = None) -> bool:
    """True when *path* is the primary repo checkout (the live workspace).

    BUG-MSO-2026-0295: convergence must NEVER run `git reset --hard` /
    `git merge` in the primary checkout — that is where the dispatcher's
    uncommitted `.mso` lifecycle state lives, and resetting it resurrects
    completed orders as PENDING (the PSG VOY-PSG-2026-0344 mechanism).

    ``cwd`` (FTR-MSO-2026-0378) selects the product repo whose primary checkout
    is compared against; ``None`` keeps the single-repo behaviour.
    """
    primary = _primary_worktree_path(cwd)
    if primary is None:
        return False
    try:
        return Path(path).resolve() == primary.resolve()
    except OSError:
        return False


def resolve_convergence_worktree(voyage_id: str, voyage_branch: str,
                                 repo_root: Optional[Path] = None,
                                 repo_name: str = ""):
    """Resolve a worktree for convergence git operations — NEVER the primary checkout.

    Returns ``(worktree_path, on_branch)``:
      - ``on_branch=True``  — the worktree has *voyage_branch* checked out;
        push with ``git push origin <branch>``.
      - ``on_branch=False`` — a DETACHED scratch worktree (the branch is
        checked out in the primary workspace checkout, which is off-limits);
        push with ``git push origin HEAD:refs/heads/<branch>``.

    BUG-MSO-2026-0295: the old fallback (`_find_worktree_for_branch`) could
    hand back the primary checkout, and the caller's `git reset --hard`
    then destroyed live dispatcher state. This resolver makes the primary
    checkout structurally unreachable from convergence code.

    FTR-MSO-2026-0378 (plan §4.3.5): *repo_root* / *repo_name* run the whole
    resolution (admin worktree prep, primary-checkout comparison, detached
    scratch worktree add) against the ORDER's product-repo checkout. Defaults
    keep the single-repo path byte-identical.

    Raises WorktreeError when no safe worktree can be produced.
    """
    try:
        return prepare_voyage_worktree(
            voyage_id, voyage_branch, repo_root=repo_root, repo_name=repo_name), True
    except WorktreeBranchConflict:
        existing = _find_worktree_for_branch(voyage_branch, cwd=repo_root)
        if existing is not None and not _is_primary_worktree(existing, cwd=repo_root):
            return existing, True

        # The voyage branch is checked out in the PRIMARY workspace checkout.
        # Use a detached scratch worktree instead of touching it.
        try:
            from maestro.core.fleet_runner import write_lifecycle_event
            write_lifecycle_event(
                "CONVERGENCE_PRIMARY_PROTECTED",
                f"'{voyage_branch}' is checked out in the primary workspace "
                f"checkout — converging via detached scratch worktree instead "
                f"of resetting live state (BUG-0295)"
            )
        except Exception:
            pass

        # BUG-MSO-2026-0306: UNIQUE path per convergence. The pre-0306 fixed
        # path (convergence-<voyage_id>) was never torn down after use, so the
        # 2nd convergence failed `git worktree add ... already exists` and the
        # role's work stranded on a salvage branch (PSG v4.7.3 regression). A
        # unique suffix makes a collision impossible even if a prior teardown
        # failed on Windows; the caller removes it after use (try/finally) and
        # _prune_orphan_convergence_worktrees() sweeps any crash-left dirs.
        # FTR-MSO-2026-0364: scratch worktrees live in the runtime worktree
        # home (.mso/worktrees/<VID>/) alongside crew/admin worktrees; the
        # legacy .mso/temp/convergence-* location is still swept by
        # _prune_orphan_convergence_worktrees for pre-relocation leftovers.
        # FTR-MSO-2026-0378: run the scratch add against the order's repo
        # checkout (repo_root) and namespace the dir per-repo so a voyage's
        # per-repo branches (identically named) never collide on one path.
        _rr = repo_root if repo_root is not None else _repo_root()
        _prune_orphan_convergence_worktrees(voyage_id, repo_root=repo_root)
        scratch_dir = worktrees_root() / voyage_id
        scratch_dir.mkdir(parents=True, exist_ok=True)
        _slug = f"-{repo_name}" if repo_name else ""
        tmp = scratch_dir / f"convergence-{voyage_id}{_slug}-{os.getpid()}-{next(_SCRATCH_SEQ)}"
        add_r = run_hidden(
            ["git", "worktree", "add", "--detach", str(tmp), voyage_branch],
            capture_output=True, text=True, cwd=str(_rr),
        )
        if add_r.returncode != 0:
            raise WorktreeError(
                f"CONVERGENCE_REFUSED_PRIMARY: '{voyage_branch}' is checked out in "
                f"the primary workspace checkout and a detached scratch worktree "
                f"could not be created: {add_r.stderr.strip()}"
            )
        return tmp, False


def _prune_orphan_convergence_worktrees(voyage_id: Optional[str] = None,
                                        repo_root: Optional[Path] = None) -> int:
    """BUG-MSO-2026-0306: remove leftover convergence scratch worktrees.

    Sweeps scratch dirs (optionally scoped to *voyage_id*) that a crashed or
    pre-0306 run left behind, so they neither accumulate nor block a fresh
    convergence. FTR-MSO-2026-0364: scratch worktrees live under
    ``.mso/worktrees/<VID>/convergence-*``; the legacy
    ``.mso/temp/convergence-*`` home is swept too for pre-relocation
    leftovers. Best-effort / fail-open. Returns the count removed.

    FTR-MSO-2026-0378: *repo_root* selects the product repo the ``git worktree``
    ops (unregister/prune) run against; ``None`` keeps the dispatcher's own
    repo (single-repo). The scratch-dir prefix stays voyage-scoped so a
    per-repo prefix (``convergence-<VID>-<repoName>-``) is still matched by the
    voyage-only ``convergence-<VID>-`` prefix.
    """
    removed = 0
    try:
        repo_root = repo_root if repo_root is not None else _repo_root()
        prefix = f"convergence-{voyage_id}-" if voyage_id else "convergence-"

        candidates = []
        temp_dir = _resolve_artefact_dir(repo_root) / "temp"
        if temp_dir.exists():
            candidates.extend(temp_dir.glob(f"{prefix}*"))
        wt_root = worktrees_root()
        if wt_root.exists():
            scopes = [wt_root / voyage_id] if voyage_id else [
                d for d in wt_root.iterdir() if d.is_dir()]
            for scope in scopes:
                if scope.is_dir():
                    candidates.extend(scope.glob(f"{prefix}*"))

        for d in candidates:
            if not d.is_dir():
                continue
            run_hidden(["git", "worktree", "remove", "--force", str(d)],
                           capture_output=True, text=True, cwd=str(repo_root))
            if d.exists():
                _robust_rmtree(d, label=f"orphan convergence worktree {d.name}")
            removed += 1
        if removed:
            run_hidden(["git", "worktree", "prune"],
                           capture_output=True, cwd=str(repo_root))
    except Exception:
        pass
    return removed


def cleanup_convergence_worktree(path, repo_root: Optional[Path] = None) -> None:
    """BUG-MSO-2026-0306: remove a scratch convergence worktree after use.

    Callers invoke this in a `finally` so a successful convergence never leaves
    a scratch worktree behind (the pre-0306 bug). Best-effort / fail-open.

    FTR-MSO-2026-0378: *repo_root* selects the product repo the ``git worktree
    remove/prune`` ops run against; ``None`` keeps single-repo behaviour.
    """
    try:
        path = Path(path)
        repo_root = repo_root if repo_root is not None else _repo_root()
        run_hidden(["git", "worktree", "remove", "--force", str(path)],
                       capture_output=True, text=True, cwd=str(repo_root))
        if path.exists():
            _robust_rmtree(path, label=f"convergence worktree {path.name}")
        run_hidden(["git", "worktree", "prune"],
                       capture_output=True, cwd=str(repo_root))
        # FTR-MSO-2026-0364: scratch worktrees live under worktrees/<VID>/ —
        # tidy the voyage dir when this was its last occupant.
        _rmdir_if_empty(path.parent)
    except Exception:
        pass


def safe_ff_primary_checkout(voyage_branch: str,
                             repo_root: Optional[Path] = None) -> bool:
    """Fast-forward a CLEAN primary checkout holding *voyage_branch* to origin.

    BUG-MSO-2026-0295: when convergence merges via the detached scratch
    worktree (the branch is held by the primary checkout), the LOCAL branch
    ref is left behind origin. Crew worktree prep resolves branches
    local-first (BUG-0253), so a stale local ref would hand dependent crews
    an old voyage tip. If the primary tree is clean, `merge --ff-only` is a
    safe catch-up (no reset, no content loss possible — ff refuses anything
    but a strict descendant). A DIRTY primary tree is left untouched: origin
    holds the truth, the next convergence merges both lineages, and we warn.

    FTR-MSO-2026-0378: *repo_root* selects the product repo whose primary
    checkout is fast-forwarded; ``None`` keeps single-repo behaviour.
    """
    wt = _find_worktree_for_branch(voyage_branch, cwd=repo_root)
    if wt is None or not _is_primary_worktree(wt, cwd=repo_root):
        return False
    # Untracked files never block an ff merge (git refuses on its own if one
    # would be overwritten) — only tracked modifications make the tree dirty.
    status_r = run_hidden(["git", "status", "--porcelain", "--untracked-files=no"],
                              capture_output=True, text=True, cwd=str(wt))
    if status_r.returncode != 0 or status_r.stdout.strip():
        try:
            from maestro.core.fleet_runner import write_lifecycle_event
            write_lifecycle_event(
                "WARN",
                f"primary checkout on '{voyage_branch}' has uncommitted changes — "
                f"local ref left behind origin after scratch-worktree convergence "
                f"(catch up manually with `git pull --ff-only`) (BUG-0295)"
            )
        except Exception:
            pass
        return False
    ff_r = run_hidden(
        ["git", "merge", "--ff-only", f"origin/{voyage_branch}"],
        capture_output=True, text=True, cwd=str(wt))
    return ff_r.returncode == 0


# Dispatcher artefact files that legitimately live git-tracked in the primary
# checkout (queue/order/voyage JSONs). Committing these before convergence keeps
# the primary tree clean so safe_ff can fast-forward (BUG-MSO-2026-0305).
_ARTEFACT_PATHSPECS = tuple(
    f"{MSO_DIR_NAME}/{d}" for d in ("queues", "orders", "voyages", "usage")
)


def commit_and_push_primary_artefacts(voyage_branch: str,
                                      convergence_timeout: int = 60,
                                      repo_root: Optional[Path] = None) -> bool:
    """BUG-MSO-2026-0305: flush the dispatcher's tracked .mso artefact writes to
    origin BEFORE convergence, so the primary checkout doesn't strand behind.

    When *voyage_branch* is checked out in the primary workspace and that tree
    has dirty TRACKED .mso artefact files (order status, voyage manifests), the
    scratch-worktree convergence (BUG-0295) would later leave the primary local
    ref behind origin (safe_ff refuses a dirty tree). Committing + pushing those
    artefacts here means the scratch convergence builds ON TOP of them and the
    primary fast-forwards cleanly afterward — topologically sound (primary
    commits X -> origin X; scratch resets to origin, merges crew -> Y, pushes;
    primary ff X->Y).

    Only commits the artefact pathspecs (never src or other files), so a crew's
    own uncommitted work elsewhere is untouched. Best-effort / fail-open: any
    error leaves the pre-0305 behaviour (safe_ff WARN) as the fallback.
    Returns True if a commit+push happened.

    FTR-MSO-2026-0366: no-op in solo/shared artefact-repo mode — dispatcher
    artefact writes are committed to the ARTEFACT repo by
    fleet_runner._commit_lifecycle_transition; the product repo's primary
    checkout has no tracked ``.mso`` artefacts to flush.

    FTR-MSO-2026-0378: *repo_root* selects the product repo whose primary
    checkout is inspected; ``None`` keeps single-repo behaviour.
    """
    if not _bookkeeping_machinery_active():
        return False
    wt = _find_worktree_for_branch(voyage_branch, cwd=repo_root)
    if wt is None or not _is_primary_worktree(wt, cwd=repo_root):
        return False
    # BUG-MSO-2026-0347: when the primary checkout sits on the remote DEFAULT
    # branch (PSG: master), this flush would push accumulated lifecycle/salvage
    # bookkeeping straight to origin/master, bypassing PR-only policy. Keep the
    # commits local (the operator's sweep PR reconciles them) unless opted in.
    if not default_branch_push_guard(
            voyage_branch, "pre-convergence artefact flush (BUG-0305)",
            repo_dir=wt):
        return False
    try:
        # Restrict to artefact pathspecs that are actually tracked — a bare
        # `git add -- <dir>` fails (exit 128) on a pathspec matching no tracked
        # files, so only pass the ones git knows about.
        present = []
        for spec in _ARTEFACT_PATHSPECS:
            ls = run_hidden(["git", "ls-files", "--", spec],
                                capture_output=True, text=True, cwd=str(wt), timeout=15)
            if (ls.stdout or "").strip():
                present.append(spec)
        if not present:
            return False
        # Anything dirty (tracked) under the present artefact pathspecs?
        status_r = run_hidden(
            ["git", "status", "--porcelain", "--untracked-files=no", "--"] + present,
            capture_output=True, text=True, cwd=str(wt), timeout=15)
        if status_r.returncode != 0 or not status_r.stdout.strip():
            return False

        add_r = run_hidden(["git", "add", "--"] + present,
                               capture_output=True, text=True, cwd=str(wt), timeout=15)
        if add_r.returncode != 0:
            return False
        commit_r = run_hidden(
            ["git",
             "-c", "user.name=Maestro Dispatcher",
             "-c", "user.email=dispatcher@maestro.local",
             "commit", "-m",
             f"lifecycle: flush dispatcher artefacts before convergence ({voyage_branch}) (BUG-0305)",
             "--"] + present,
            capture_output=True, text=True, cwd=str(wt), timeout=15)
        if commit_r.returncode != 0:
            return False  # nothing staged / commit refused — leave as-is
        # _retry_git_network_op returns only on returncode==0, else raises
        # (ConvergenceNetworkError) — caught by the outer except as fail-open.
        _retry_git_network_op(
            ["git", "push", "origin", voyage_branch],
            cwd=str(wt), timeout=2 * convergence_timeout)
        try:
            from maestro.core.fleet_runner import write_lifecycle_event
            write_lifecycle_event(
                "DISPATCH",
                f"flushed dispatcher artefacts to origin/{voyage_branch} before "
                f"convergence (primary stays in sync, BUG-0305)")
        except Exception:
            pass
        return True
    except Exception:
        return False


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def _worktrees_artefact_root() -> Path:
    """Resolve the artefact root every worktree path is anchored to (GH #376 /
    BUG-MSO-2026-0568 / BUG-MSO-2026-0601).

    Every function in this module that scans or creates worktrees ultimately
    derives its root from here rather than deriving ``_repo_root()`` (cwd's
    git toplevel) directly. The previous cwd-based derivation agreed with
    itself only when every invocation shared a cwd — false for the real
    ``mso dispatch`` subprocess, whose cwd is incidental per-invocation. A
    worktree CREATED by one invocation could not be RESOLVED by the next:
    ``git worktree add`` refused with "already used by worktree at <the other
    root>" and the order stalled on already-completed work (GitHub #376's
    reproduction; BUG-MSO-2026-0568 covers the resulting reuse-vs-conflict
    handling elsewhere in this module).

    Two tiers:

    1. ``fleet_runner._MAESTRO_DIR_OVERRIDE``, when set — the SAME process
       global ``mso dispatch --maestro-dir`` sets once at startup and
       ``order_retry.workspace_scope()`` sets/restores around a scoped call.
       A caller that has entered ``workspace_scope(mso)`` (the LEAD daemon's
       ``worktree.prune`` band, the Hub's per-workspace poll, a multi-
       workspace CLI scan) gets THAT workspace's ``.mso/worktrees/`` —
       deterministically, regardless of the process's actual cwd
       (BUG-MSO-2026-0601).
    2. Falling back to the legacy cwd-derived
       ``_resolve_artefact_dir(_repo_root())`` — the single-workspace-per-
       process default every existing caller (a plain ``mso dispatch`` run,
       a test) keeps getting byte-identically. Kept cwd-based (rather than
       falling through to the env-var-aware
       ``maestro.workspace.get_artefact_root()``) deliberately: pytest's
       autouse test-isolation fixture (BUG-MSO-2026-0327) sets ``MAESTRO_DIR``
       for every test regardless of what that test is actually exercising,
       so preferring it here would silently redirect every worktree-primitive
       test at an unrelated isolated workspace instead of the scratch repo
       the test built.

    This is the fix BUG-MSO-2026-0389 needed but didn't quite reach: that fix
    pinned the git-operation ``cwd`` (the ``repo_root`` param below) for
    solo/shared mode, but left the DURABLE-PLANE scan root — this function,
    and therefore :func:`worktrees_root` and the ``voyages/active|complete``
    scan inside :func:`prune_stale_worktrees` — still deriving from
    ``_repo_root()`` (the PRODUCT repo, per that function's own docstring)
    even in solo/shared mode, where the real artefact plane lives elsewhere.
    Routing every caller through this one resolver makes the path
    deterministic across processes instead of merely per-process.
    """
    override = _fleet_runner._MAESTRO_DIR_OVERRIDE
    if override is not None:
        return override
    return _resolve_artefact_dir(_repo_root())


def worktrees_root() -> Path:
    """Return the runtime worktree home ``.mso/worktrees/`` (FTR-MSO-2026-0364).

    Gitignored, machine-local. All Maestro-managed worktrees (crew, voyage
    admin, convergence scratch) live under ``<root>/<voyage_id>/``. Paths are
    kept shallow deliberately (Windows long-path / junction risk — plan
    PLAN-PLN-MSO-2026-0358 §6).
    """
    return _worktrees_artefact_root() / "worktrees"


def _legacy_voyage_dir(voyage_id: str) -> Path:
    """Pre-FTR-0364 voyage dir that used to host worktrees next to durable JSON."""
    return _worktrees_artefact_root() / "voyages" / "active" / voyage_id


def legacy_worktree_path_for(voyage_id: str) -> Path:
    """Pre-FTR-0364 voyage admin worktree location (no I/O)."""
    return _legacy_voyage_dir(voyage_id) / ".worktree"


def legacy_crew_worktree_path_for(voyage_id: str, crew_num: int) -> Path:
    """Pre-FTR-0364 per-crew worktree location (no I/O)."""
    return _legacy_voyage_dir(voyage_id) / f".worktree-crew{crew_num}"


def worktree_path_for(voyage_id: str, repo_name: str = "") -> Path:
    """Return the voyage admin worktree path.

    This worktree is used exclusively for convergence merges. Crew work
    happens in crew_worktree_path_for() worktrees (BUG-MSO-2026-0240).

    FTR-MSO-2026-0364: canonical home is ``.mso/worktrees/<voyage_id>/admin``.
    Legacy-aware: while a pre-relocation worktree dir still exists at
    ``voyages/active/<voyage_id>/.worktree`` (an in-flight voyage dispatched
    by an older version), that path is returned so running work is never
    stranded; the legacy dir is pruned at voyage completion.

    FTR-MSO-2026-0378 (multi-repo convergence, plan §4.3-4.4): a voyage spans
    N product repos, each with its own branch of the SAME name
    (``voyage/<VID>-<slug>``). Two same-named branches cannot share one admin
    worktree path, so *repo_name* gives each repo its own admin worktree at
    ``.mso/worktrees/<voyage_id>/admin-<repoName>``. The default ``repo_name=""``
    keeps the single-repo path (and legacy-home compat) byte-identical.
    """
    if repo_name:
        return worktrees_root() / voyage_id / f"admin-{repo_name}"
    legacy = legacy_worktree_path_for(voyage_id)
    if legacy.exists():
        return legacy
    return worktrees_root() / voyage_id / "admin"


def crew_worktree_path_for(voyage_id: str, crew_num: int,
                           repo_name: str = "") -> Path:
    """Return the per-crew worktree path for (voyage_id, crew_num).

    FTR-MSO-2026-0364: canonical home is ``.mso/worktrees/<voyage_id>/crew<N>``;
    a still-existing legacy ``voyages/active/<VID>/.worktree-crew<N>`` dir wins
    while it exists (in-flight voyage compat — see worktree_path_for).

    FTR-MSO-2026-0377 (multi-repo, plan §4.3.3): when *repo_name* is given, the
    worktree lands at ``.mso/worktrees/<voyage_id>/crew<N>-<repoName>`` so an
    order targeting each product repo gets its own checkout. The legacy
    single-repo home is bypassed for per-repo worktrees (a new-feature path with
    no legacy dirs). The default ``repo_name=""`` keeps the single-repo path
    byte-identical.
    """
    if repo_name:
        return worktrees_root() / voyage_id / f"crew{crew_num}-{repo_name}"
    legacy = legacy_crew_worktree_path_for(voyage_id, crew_num)
    if legacy.exists():
        return legacy
    return worktrees_root() / voyage_id / f"crew{crew_num}"


def _rmdir_if_empty(path: Path) -> None:
    """Remove *path* if it is an empty dir (used to tidy ``worktrees/<VID>/``
    after the last worktree of a voyage is cleaned up). Best-effort."""
    try:
        if path.is_dir() and not any(path.iterdir()):
            path.rmdir()
    except OSError:
        pass


def crew_branch_name(voyage_id: str, crew_num: int) -> str:
    """Return the per-crew git branch name, e.g. ``crew/VOY-MSO-2026-0056-1``."""
    return f"crew/{voyage_id}-{crew_num}"


class _CommitOutcome:
    """Internal result of a commit attempt — richer than the plain bool the
    public `commit_crew_worktree_if_dirty()` returns, so BUG-MSO-2026-0580's
    salvage path can tell a REFUSAL apart from a clean/no-op tree without
    re-deriving git state a second time."""
    __slots__ = ("committed", "had_changes", "refused", "reason")

    def __init__(self, committed: bool = False, had_changes: bool = False,
                 refused: bool = False, reason: str = ""):
        self.committed = committed
        self.had_changes = had_changes
        self.refused = refused
        self.reason = reason


def _commit_crew_worktree_impl(voyage_id: str, crew_num: int,
                               order_id: Optional[str] = None,
                               repo_name: str = "",
                               voyage_branch: Optional[str] = None,
                               emit_refusal_warning: bool = True) -> _CommitOutcome:
    """Shared implementation behind `commit_crew_worktree_if_dirty()` (bool)
    and `commit_or_salvage_crew_worktree()` (BUG-MSO-2026-0580 salvage-aware
    wrapper). See `commit_crew_worktree_if_dirty()`'s docstring for the full
    behavioural contract (BUG-0284 auto-commit, BUG-0545 ancestry gate) — this
    function's git logic is byte-identical to the pre-0580 implementation,
    only the return shape changed (bool -> _CommitOutcome) so a caller can
    distinguish "refused" from "nothing to do".
    """
    wt = crew_worktree_path_for(voyage_id, crew_num, repo_name)
    if not wt.exists():
        return _CommitOutcome()
    expected_branch = crew_branch_name(voyage_id, crew_num)

    def _git(args, timeout: int = 30) -> subprocess.CompletedProcess:
        return run_hidden(["git", *args], capture_output=True, text=True,
                              cwd=str(wt), timeout=timeout)

    def _refuse(why: str) -> _CommitOutcome:
        if emit_refusal_warning:
            try:
                from maestro.core.fleet_runner import write_lifecycle_event
                write_lifecycle_event(
                    "WARN",
                    f"{order_id or voyage_id}: auto-commit refused for Crew {crew_num} "
                    f"({why}, BUG-MSO-2026-0545) — uncommitted worktree changes were "
                    f"NOT captured; only what the crew branch already had committed "
                    f"will converge."
                )
            except Exception:
                pass
        return _CommitOutcome(had_changes=True, refused=True, reason=why)

    try:
        status = _git(["status", "--porcelain"])
        if status.returncode != 0 or not status.stdout.strip():
            return _CommitOutcome()  # clean (or unreadable) — nothing to commit

        head = _git(["rev-parse", "--abbrev-ref", "HEAD"])
        actual = head.stdout.strip() if head.returncode == 0 else ""
        if actual != expected_branch:
            # Safety: never auto-commit onto an unexpected branch (e.g. main /
            # the voyage branch).
            return _refuse(f"HEAD is `{actual or '<unknown>'}`, expected crew branch "
                           f"`{expected_branch}`")

        if voyage_branch:
            branch_ref = voyage_branch.replace("refs/heads/", "")
            # Best-effort fetch so the ancestry check reflects the branch's true
            # current tip, not a stale local remote-tracking ref from before
            # this iteration's convergence activity.
            _git(["fetch", "origin", branch_ref], timeout=60)
            tip = ""
            for ref in (f"refs/remotes/origin/{branch_ref}", f"refs/heads/{branch_ref}"):
                r = _git(["rev-parse", "--verify", "--quiet", ref])
                if r.returncode == 0 and r.stdout.strip():
                    tip = r.stdout.strip()
                    break
            if not tip:
                # Can't establish ground truth (no remote, branch unresolvable,
                # fetch failed) — fail safe: refuse rather than guess.
                return _refuse(f"voyage tip for `{branch_ref}` could not be resolved")
            if _git(["merge-base", "--is-ancestor", tip, "HEAD"]).returncode != 0:
                return _refuse(f"HEAD is not a descendant of voyage tip {tip[:8]} on "
                               f"`{branch_ref}`")

        if _git(["add", "-A"]).returncode != 0:
            return _CommitOutcome(had_changes=True)
        msg = (f"[fleet] auto-commit uncommitted crew artefacts for "
               f"{order_id or voyage_id} (Crew {crew_num}, BUG-MSO-2026-0284)")
        # Make the commit self-sufficient in headless/dispatcher environments:
        # never sign (no key/agent in automated runs) and supply a fallback
        # committer identity ONLY when none is configured — otherwise the commit
        # fails silently and the safety net is defeated (Copilot review of PR #139).
        commit_cfg = ["-c", "commit.gpgsign=false"]
        if not _git(["config", "user.email"]).stdout.strip():
            commit_cfg += ["-c", "user.email=fleet@maestro.local",
                           "-c", "user.name=Maestro Fleet"]
        ok = _git([*commit_cfg, "commit", "-m", msg]).returncode == 0
        return _CommitOutcome(committed=ok, had_changes=True)
    except Exception:
        return _CommitOutcome()


def commit_crew_worktree_if_dirty(voyage_id: str, crew_num: int,
                                  order_id: Optional[str] = None,
                                  repo_name: str = "",
                                  voyage_branch: Optional[str] = None) -> bool:
    """BUG-MSO-2026-0284: auto-commit a crew's uncommitted worktree changes.

    Convergence (``merge_crew_branch_into_voyage``) merges the crew BRANCH and
    assumes the crew committed its work. A crew that writes artefacts (e.g. a PLN
    plan) but never runs ``git commit`` would otherwise have its work SILENTLY
    LOST: the dispatcher pre-creates the crew branch, so an empty crew branch
    merges as a no-op and the order advances "success" with nothing persisted.
    (The legacy ``verify_and_push_crew_work`` was meant to cover this but is dead
    code wired to the pre-worktree ``crews/N/repo`` path — see BUG-0284.)

    Call this in finalize BEFORE convergence. It runs as dispatcher code (not via
    Claude's Bash tool), so the branch_guard pretool hook does NOT intercept it —
    hence the explicit branch-safety check: only commit when HEAD is the crew's
    OWN branch, never some other ref (mirrors BUG-MSO-2026-0241's intent).

    BUG-MSO-2026-0545: a verbatim ``git add -A`` capture of whatever this
    worktree's tree happens to contain is about to become a real commit on
    ``expected_branch`` that ``merge_crew_branch_into_voyage()`` will merge into
    the voyage branch. That is only safe when this worktree's own branch already
    contains everything the voyage tip has converged so far — otherwise the
    capture can include stale/reverted file content that silently overwrites
    already-merged work when it converges back in. This is not hypothetical: on
    PSG voyage VOY-PSG-2026-0421 an auto-commit from a stale crew 3 worktree
    reverted a feature crew 2 had just converged AND, collaterally, an unrelated
    order that had already converged and was marked COMPLETE (GitHub #367) —
    whole-file capture doesn't know which lines belong to which order, it only
    knows what the tree looks like right now. When *voyage_branch* is given, the
    commit is additionally gated on ``git merge-base --is-ancestor <voyage tip>
    HEAD`` — the crew branch must be a descendant of the voyage tip it is about
    to converge into, not merely on the right branch name. A stale worktree on
    the CORRECT branch is refused exactly like a wrong-branch one; this is
    defense in depth alongside BUG-MSO-2026-0544 (which prevents the wrong-branch
    worktree from existing at all) — it must hold even when 0544 is bypassed or
    a worktree is merely stale, not wrong-branch. A refusal is escalated via a
    lifecycle WARN so it is never silently invisible; the caller's uncommitted
    changes are simply left uncommitted (never captured), which only means this
    particular safety-net capture is skipped — it does not touch whatever the
    crew branch already had legitimately committed. Callers with no voyage
    branch to hand keep the pre-0545 behaviour (branch-identity check only).

    Returns True iff a commit was created. Fail-safe: returns False on a clean
    tree, a missing worktree, an unexpected HEAD, an ancestry check that cannot
    be established or fails, or ANY git error — this is a best-effort safety net
    and must never break finalization.

    FTR-MSO-2026-0378: *repo_name* resolves the per-repo crew worktree
    (``crew<N>-<repoName>``) in multi-repo dispatch; git ops run in that
    worktree (its own repo), so no repo_root is needed. ``""`` keeps the
    single-repo path byte-identical.
    """
    return _commit_crew_worktree_impl(voyage_id, crew_num, order_id,
                                      repo_name, voyage_branch).committed


def commit_or_salvage_crew_worktree(voyage_id: str, crew_num: int,
                                    order_id: Optional[str] = None,
                                    repo_root: Optional[Path] = None,
                                    repo_name: str = "",
                                    voyage_branch: Optional[str] = None) -> dict:
    """BUG-MSO-2026-0580: when the BUG-0545 ancestry gate refuses an auto-commit,
    preserve the refused work instead of silently discarding it.

    `commit_crew_worktree_if_dirty()` is correct to REFUSE a capture when this
    crew's HEAD is not a descendant of the voyage tip (BUG-0545) — committing it
    as-is and letting it converge could revert already-merged work. But the
    refusal itself used to be the end of the story: the caller (finalize, in
    the crew-COMPLETE path) simply continued on to convergence as if nothing
    had happened, using whatever the crew branch already had committed — which,
    per the BUG-0580 incident, can be nothing at all, while the crew's handoff
    confidently describes a finished implementation that was never captured.

    This wraps the same refusal check and, on refusal, ROUTES the uncommitted
    changes into the EXISTING BUG-0285 salvage mechanism instead of inventing a
    second one:
      1. Re-run the commit WITHOUT the ancestry gate (``voyage_branch=None``) —
         only the branch-identity check applies, so the refused changes land on
         the crew's OWN branch. This is safe specifically because that commit is
         about to be renamed away from the crew-branch namespace, never merged
         into the voyage.
      2. Call `preserve_failed_crew_branch()` — the same rename-to-``salvage/*``
         used by the timeout/crash (BUG-0285) and STALLED (BUG-0298) paths — to
         capture it durably and free the crew slot.

    Returns a dict:
      ``committed``     — True iff the ancestry check passed; the changes are
                           safely on the crew branch, ready for a normal
                           convergence merge. ``refused`` is False in this case.
      ``refused``        — True iff the BUG-0545 gate fired. The caller MUST NOT
                           proceed to a normal convergence/advance — the crew
                           branch has just been renamed away (see below) and no
                           longer exists at ``crew_branch_name()``.
      ``salvageBranch``  — the ref the refused work now lives on (or None if it
                           could not be captured/renamed — e.g. no local crew
                           branch at all).
      ``strandedSha``    — the durable commit handle, valid even if the rename
                           itself failed.
      ``reason``          — the human-readable refusal reason (mirrors the WARN
                           `commit_crew_worktree_if_dirty()` already logs).

    A caller with nothing to commit (clean tree) gets
    ``{"committed": False, "refused": False, ...}`` — a true no-op, same as
    the plain bool function returning False for a clean tree.
    """
    outcome = _commit_crew_worktree_impl(voyage_id, crew_num, order_id,
                                         repo_name, voyage_branch)
    if not outcome.refused:
        return {"committed": outcome.committed, "refused": False,
                "salvageBranch": None, "strandedSha": None, "reason": outcome.reason}

    # Refused — capture the refused changes onto the crew's OWN branch without
    # the ancestry gate (no voyage_branch), then reuse BUG-0285's salvage
    # rename. `emit_refusal_warning=False` avoids a second, misleading WARN
    # (the crew-identity check almost never fires here since the first call
    # already established HEAD == expected_branch to even reach this point).
    _commit_crew_worktree_impl(voyage_id, crew_num, order_id, repo_name,
                               voyage_branch=None, emit_refusal_warning=False)
    salvage = preserve_failed_crew_branch(voyage_id, crew_num, order_id,
                                          repo_root=repo_root, repo_name=repo_name)
    return {
        "committed": False,
        "refused": True,
        "salvageBranch": (salvage or {}).get("salvageBranch"),
        "strandedSha": (salvage or {}).get("strandedSha"),
        "reason": outcome.reason,
    }


def prepare_voyage_worktree(voyage_id: str, voyage_branch: str,
                            repo_root: Optional[Path] = None,
                            repo_name: str = "") -> Path:
    """Create (or reuse) the git worktree for a voyage.

    Idempotent: if the worktree already exists and is registered, returns its path.
    Handles orphaned dirs from crashed PREPARING state by removing and recreating.

    FTR-MSO-2026-0378 (multi-repo convergence, plan §4.3.5): *repo_root* pins the
    product-repo checkout every git op runs against (``cwd``) and *repo_name*
    suffixes the admin worktree dir so a voyage's per-repo branches (all named
    identically) each get their own admin worktree. The defaults (``None`` /
    ``""``) leave single-repo behaviour byte-identical.

    BUG-MSO-2026-0568: a conflict where the SAME branch is already checked
    out elsewhere is reused rather than raised, when that existing worktree
    is provably on the expected branch — see ``_reusable_worktree_from_conflict``.
    This is the ordinary shape of a directory-location disagreement between
    two dispatch invocations (worktree relocated), not a real conflict.

    Raises:
        WorktreeBranchConflict: branch is checked out elsewhere and that
            worktree could not be verified as safe to reuse.
        WorktreeMissingBranch: branch does not exist.
        WorktreeError: git worktree add failed for another reason.
    """
    with _prepare_lock:
        worktree_path = worktree_path_for(voyage_id, repo_name)
        registered = _registered_worktrees(repo_root)

        # Happy path: already ready — but only if its checked-out branch
        # actually matches (BUG-MSO-2026-0544). Existence + registration were
        # previously trusted as proof; PSG found the admin worktree class
        # vulnerable to the same drift as crew worktrees (see
        # prepare_crew_worktree for the incident this class was named for).
        #
        # On a mismatch: repair (remove the corrupted worktree) but still
        # REFUSE this dispatch attempt rather than silently handing back a
        # freshly-recreated one in the same call ("Do NOT dispatch and hope"
        # — the order's own words). The caller holds/requeues; the next
        # attempt hits the orphaned-dir branch below and recreates cleanly.
        if worktree_path.exists() and worktree_path in registered:
            actual = worktree_head_branch(worktree_path)
            if actual == voyage_branch:
                return worktree_path
            _warn_worktree_branch_drift(
                f"voyage worktree ({voyage_id})", worktree_path, voyage_branch, actual)
            _force_remove_worktree(worktree_path, cwd=repo_root,
                                   label=f"branch-drift worktree {voyage_id}")
            raise WorktreeBranchDrift(
                f"Voyage worktree for {voyage_id} was found on branch "
                f"`{actual or '<unknown/detached>'}`, not `{voyage_branch}` — "
                "removed. Refusing this dispatch (BUG-MSO-2026-0544); the "
                "next attempt creates a fresh worktree.",
                actual_branch=actual, expected_branch=voyage_branch,
            )

        # Orphaned dir (PREPARING crash): remove and recreate
        if worktree_path.exists() and worktree_path not in registered:
            _robust_rmtree(worktree_path, label=f"worktree orphan {voyage_id}")
            # FTR-MSO-2026-0364: a removed LEGACY orphan must not be recreated
            # in the legacy home — re-resolve so recreation lands under
            # .mso/worktrees/ (new voyages/dispatches always use the new home).
            worktree_path = worktree_path_for(voyage_id, repo_name)

        # BUG-MSO-2026-0027: the dispatcher creates voyage branches via
        # ``gh api`` (remote-only). Resolve in three tiers:
        #   1. Local branch ref present → standard ``git worktree add <path> <branch>``.
        #   2. Remote-tracking ref already present → fetch is unnecessary; create
        #      the local branch via ``git worktree add -b <branch> <path> origin/<branch>``.
        #   3. Neither present → ``git fetch`` the specific branch from origin
        #      and retry the tracking-branch worktree add.
        # Fail loudly with WorktreeMissingBranch only if all three fail.
        local_branch = _branch_exists_local(voyage_branch, repo_root)
        if not local_branch:
            if not _branch_exists_remote(voyage_branch, cwd=repo_root):
                _fetch_remote_branch(voyage_branch, cwd=repo_root)
            if not _branch_exists_remote(voyage_branch, cwd=repo_root):
                raise WorktreeMissingBranch(
                    f"Branch '{voyage_branch}' does not exist locally or on origin. "
                    "Create it before calling prepare_voyage_worktree()."
                )

        worktree_path.parent.mkdir(parents=True, exist_ok=True)

        def _build_cmd() -> list:
            if _branch_exists_local(voyage_branch, repo_root):
                return ["git", "worktree", "add", str(worktree_path), voyage_branch]
            # Create local branch tracking origin/<branch> in the same step.
            return [
                "git", "worktree", "add",
                "-b", voyage_branch,
                str(worktree_path),
                f"origin/{voyage_branch}",
            ]

        # BUG-MSO-2026-0345: retry with short backoff — a leftover dir a
        # Windows file lock kept the orphan sweep from removing clears within
        # seconds; don't surface a transient blip as WORKTREE_FAIL.
        result, failed_attempts, last_error = _worktree_add_with_retry(
            _build_cmd, worktree_path, f"worktree orphan {voyage_id}", cwd=repo_root)

        if result.returncode == 0:
            if failed_attempts:
                _warn_worktree_add_recovered(
                    f"voyage worktree '{voyage_branch}' ({voyage_id})",
                    failed_attempts, last_error)
            return worktree_path

        stderr = _flatten_git_output(result.stderr)

        if "already checked out" in stderr or "already used by worktree" in stderr:
            reusable = _reusable_worktree_from_conflict(
                stderr, voyage_branch, voyage_id,
                _voyage_worktree_leaf_names(repo_name), cwd=repo_root)
            if reusable is not None:
                _warn_worktree_reused(f"voyage worktree ({voyage_id})", reusable, voyage_branch)
                return reusable
            raise WorktreeBranchConflict(
                f"Branch '{voyage_branch}' is already checked out in another worktree. "
                f"git error: {stderr}"
            )

        if "No space left" in stderr or "disk full" in stderr.lower():
            raise WorktreeError(f"Disk full while creating worktree: {stderr}")

        # Already registered (e.g. path comparison miss in concurrent scenario)
        # — but BUG-MSO-2026-0544: existence alone is not proof it is USABLE.
        # An existing directory that failed a fresh `git worktree add` can
        # still be sitting on a foreign branch; verify before trusting it.
        if "already registered" in stderr and worktree_path.exists():
            actual = worktree_head_branch(worktree_path)
            if actual == voyage_branch:
                return worktree_path
            raise WorktreeBranchDrift(
                f"git worktree add failed for voyage {voyage_id} ('{stderr}') "
                f"and the existing directory at {worktree_path} is on branch "
                f"`{actual or '<unknown/detached>'}`, not `{voyage_branch}` — "
                "refusing to hand a mismatched worktree back (BUG-MSO-2026-0544).",
                actual_branch=actual, expected_branch=voyage_branch,
            )

        raise WorktreeError(f"git worktree add failed: {stderr}")


def prepare_crew_worktree(voyage_id: str, crew_num: int, voyage_branch: str,
                          repo_root: Optional[Path] = None,
                          repo_name: str = "") -> Path:
    """Create (or reuse) an isolated per-crew git worktree on a per-crew branch.

    Each crew of the same voyage gets its own worktree at
    .mso/worktrees/<voyage_id>/crew<crew_num> on branch
    crew/<voyage_id>-<crew_num>, branched from voyage_branch (a legacy
    voyages/active/<voyage_id>/.worktree-crew<crew_num> worktree is reused
    while it exists — FTR-MSO-2026-0364).

    On re-dispatch (crew timed out and was requeued): if the crew branch already
    exists locally, the worktree is recreated on that same branch so the crew
    can continue from where it left off.

    The MAESTRO_SPRINT_BRANCH injected into the crew process must be the crew
    branch name (from crew_branch_name()) so the branch guard allows mutations
    on the crew branch rather than the voyage branch.

    FTR-MSO-2026-0377 (multi-repo dispatch, plan §4.3): *repo_root* pins the
    product-repo checkout the worktree + branch operations run against (git
    ``cwd``), and *repo_name* suffixes the worktree dir (``crew<N>-<repoName>``)
    so one order per product repo gets an isolated checkout. The defaults
    (``None`` / ``""``) leave the single-repo behaviour byte-identical — every
    git op runs in the dispatcher's own repo and the worktree keeps its legacy
    path.

    BUG-MSO-2026-0568: a conflict where the crew branch is already checked
    out elsewhere is reused rather than raised when that existing worktree is
    provably on the expected crew branch — see
    ``_reusable_worktree_from_conflict``. This is the ordinary shape of a
    directory-location disagreement between two dispatch invocations
    (worktree relocated), not a real conflict — completed work must not be
    stalled over it.

    Raises:
        WorktreeMissingBranch: voyage_branch does not exist locally or on origin.
        WorktreeBranchConflict: crew branch checked out elsewhere and that
            worktree could not be verified as safe to reuse.
        WorktreeError: git worktree add failed for another reason.
    """
    with _prepare_lock:
        wt_path = crew_worktree_path_for(voyage_id, crew_num, repo_name)
        c_branch = crew_branch_name(voyage_id, crew_num)
        registered = _registered_worktrees(repo_root)

        # Happy path: already ready (idempotent on re-call) — but only if its
        # checked-out branch actually matches (BUG-MSO-2026-0544). PSG's
        # crew3 worktree was fully present AND registered, yet checked out to
        # `master` with a pre-voyage HEAD; a crew ran against that stale tree
        # and reported success (GitHub #367, #368). Existence + registration
        # were previously trusted as proof of readiness — verify instead.
        #
        # On a mismatch: repair (remove the corrupted worktree) but still
        # REFUSE this dispatch attempt rather than silently handing back a
        # freshly-recreated one in the same call ("Do NOT dispatch and hope"
        # — the order's own words). The caller holds/requeues; the next
        # attempt hits the orphaned-dir branch below and recreates cleanly.
        if wt_path.exists() and wt_path in registered:
            actual = worktree_head_branch(wt_path)
            if actual == c_branch:
                return wt_path
            _warn_worktree_branch_drift(
                f"crew {crew_num} worktree ({voyage_id})", wt_path, c_branch, actual)
            _force_remove_worktree(wt_path, cwd=repo_root,
                                   label=f"branch-drift crew worktree {voyage_id}-{crew_num}")
            raise WorktreeBranchDrift(
                f"Crew {crew_num} worktree for {voyage_id} was found on "
                f"branch `{actual or '<unknown/detached>'}`, not `{c_branch}` "
                "— removed. Refusing this dispatch (BUG-MSO-2026-0544); the "
                "next attempt creates a fresh worktree.",
                actual_branch=actual, expected_branch=c_branch,
            )

        # Orphaned dir (PREPARING crash): remove and recreate
        if wt_path.exists() and wt_path not in registered:
            _robust_rmtree(wt_path, label=f"crew worktree orphan {voyage_id}-{crew_num}")
            # FTR-MSO-2026-0364: re-resolve after removing a LEGACY orphan so
            # recreation lands under .mso/worktrees/, never the legacy home.
            wt_path = crew_worktree_path_for(voyage_id, crew_num, repo_name)

        # Resolve the voyage branch start-point using the same three-tier strategy
        # as prepare_voyage_worktree (BUG-MSO-2026-0027).
        local_voy = _branch_exists_local(voyage_branch, repo_root)
        if not local_voy:
            if not _branch_exists_remote(voyage_branch, cwd=repo_root):
                _fetch_remote_branch(voyage_branch, cwd=repo_root)
            if not _branch_exists_remote(voyage_branch, cwd=repo_root):
                raise WorktreeMissingBranch(
                    f"Voyage branch '{voyage_branch}' does not exist locally or on origin."
                )
        start_point = voyage_branch if local_voy else f"origin/{voyage_branch}"

        wt_path.parent.mkdir(parents=True, exist_ok=True)

        def _build_cmd() -> list:
            # Re-dispatch: crew branch already exists — reuse it (don't re-branch
            # from voyage tip). Re-checked per retry attempt (BUG-MSO-2026-0345).
            if _branch_exists_local(c_branch, repo_root):
                return ["git", "worktree", "add", str(wt_path), c_branch]
            # Fresh crew: create crew branch from the current voyage branch tip
            return ["git", "worktree", "add", "-b", c_branch, str(wt_path), start_point]

        # BUG-MSO-2026-0345: same-crew re-dispatch can hit "fatal:
        # '.worktree-crew<N>' already exists" — Windows holds the just-killed
        # crew's dir (process cwd / AV handle) so the orphan sweep above left
        # it behind. The lock clears within seconds (PSG: the next dispatch
        # tick ONE second later succeeded, 2-for-2). Retry with short backoff,
        # re-sweeping between attempts, before surfacing WORKTREE_FAIL.
        result, failed_attempts, last_error = _worktree_add_with_retry(
            _build_cmd, wt_path, f"crew worktree orphan {voyage_id}-{crew_num}",
            cwd=repo_root)

        if result.returncode == 0:
            if failed_attempts:
                _warn_worktree_add_recovered(
                    f"crew {crew_num} worktree '{c_branch}' ({voyage_id})",
                    failed_attempts, last_error)
            return wt_path

        stderr = _flatten_git_output(result.stderr)

        if "already checked out" in stderr or "already used by worktree" in stderr:
            reusable = _reusable_worktree_from_conflict(
                stderr, c_branch, voyage_id,
                _crew_worktree_leaf_names(crew_num, repo_name), cwd=repo_root)
            if reusable is not None:
                _warn_worktree_reused(
                    f"crew {crew_num} worktree ({voyage_id})", reusable, c_branch)
                return reusable
            raise WorktreeBranchConflict(
                f"Crew branch '{c_branch}' is already checked out in another worktree. "
                f"git error: {stderr}"
            )

        # BUG-MSO-2026-0544: as above — existence is not proof of usability.
        if "already registered" in stderr and wt_path.exists():
            actual = worktree_head_branch(wt_path)
            if actual == c_branch:
                return wt_path
            raise WorktreeBranchDrift(
                f"git worktree add failed for crew {crew_num} ('{stderr}') and "
                f"the existing directory at {wt_path} is on branch "
                f"`{actual or '<unknown/detached>'}`, not `{c_branch}` — "
                "refusing to hand a mismatched worktree to a crew (BUG-MSO-2026-0544).",
                actual_branch=actual, expected_branch=c_branch,
            )

        if "No space left" in stderr or "disk full" in stderr.lower():
            raise WorktreeError(f"Disk full while creating crew worktree: {stderr}")

        raise WorktreeError(f"git worktree add failed for crew {crew_num}: {stderr}")


def merge_crew_branch_into_voyage(voyage_id: str, crew_num: int, voyage_branch: str,
                                  order_id: Optional[str] = None,
                                  convergence_timeout: int = 60,
                                  repo_root: Optional[Path] = None,
                                  repo_name: str = "") -> bool:
    """Merge a completed crew's branch into the voyage branch (convergence step).

    Uses the voyage admin worktree (worktrees/<VID>/admin) as a scratch pad:
      1. Sync to origin/<voyage_branch> (reset --hard to handle any prior failed merge)
      2. Fetch origin/<crew_branch>
      3. Merge --no-ff to preserve crew history
      4. Push to origin/<voyage_branch>

    The _merge_lock serializes concurrent convergence merges so two crews
    finishing simultaneously don't produce a push race on the same branch.

    `order_id` (BUG-MSO-2026-0244) is woven into the convergence commit message so
    `git log` on the voyage branch reflects the order actually being merged rather
    than a hardcoded bug id.

    `convergence_timeout` (BUG-MSO-2026-0268) is the per-op timeout in seconds for
    git network operations (voyage fetch, crew fetch, voyage push). Each op is retried
    with exponential backoff before raising ConvergenceNetworkError. Default: 60 s.

    FTR-MSO-2026-0378 (multi-repo convergence, plan §4.3.5): *repo_root* pins the
    ORDER's product-repo checkout that the admin/scratch worktree, primary-checkout
    protection, and default-branch guard all run against; *repo_name* namespaces
    the admin worktree so a voyage's per-repo branches (identically named) don't
    collide. The defaults (``None`` / ``""``) leave single-repo convergence
    byte-identical. The crew branch's local ref lives in the SAME repo's shared
    ref store as the admin worktree, so the local-first crew-branch resolution is
    unchanged — it just resolves in the right repo now.

    Returns True on clean merge+push.
    Raises ConvergenceNetworkError on transient network/timeout failures (retryable).
    Raises WorktreeError on merge conflict or push failure. On a merge conflict the
    error message lists the conflicting files (BUG-MSO-2026-0244) so finalization can
    record them for recovery.
    """
    c_branch = crew_branch_name(voyage_id, crew_num)

    with _merge_lock:
        # BUG-MSO-2026-0347: convergence ends in `git push origin <voyage_branch>`.
        # If the voyage branch resolved to the remote DEFAULT branch, that push
        # would land dispatcher bookkeeping (and crew work) directly on e.g.
        # origin/master, bypassing PR-only policy. Refuse up front — the caller's
        # failure handling preserves the crew's work on a salvage branch.
        if not default_branch_push_guard(
                voyage_branch, f"convergence of {c_branch}", repo_dir=repo_root):
            raise WorktreeError(
                f"Convergence of '{c_branch}' refused: voyage branch "
                f"'{voyage_branch}' is the remote default branch — Maestro never "
                f"auto-pushes the default branch (BUG-MSO-2026-0347). Point the "
                f"voyage at a dedicated voyage/* branch, or set "
                f"lifecycle.allowDefaultBranchPush=true in workspace.json to opt in."
            )
        # BUG-MSO-2026-0305: if the voyage branch is checked out in the primary
        # workspace with dirty tracked .mso artefacts, flush them to origin first
        # so this convergence builds on top of them and the primary fast-forwards
        # cleanly afterward (instead of being left behind origin).
        try:
            commit_and_push_primary_artefacts(
                voyage_branch, convergence_timeout, repo_root=repo_root)
        except Exception:
            pass
        # Resolve a worktree on the voyage branch for convergence merges.
        # Preference: voyage admin worktree; fall back to another
        # non-primary checkout of the branch. BUG-MSO-2026-0295: NEVER the
        # primary workspace checkout — resetting it destroys live dispatcher
        # state. When the branch is checked out in the primary tree, a
        # detached scratch worktree is used (on_branch=False → push HEAD:ref).
        try:
            admin_wt, on_branch = resolve_convergence_worktree(
                voyage_id, voyage_branch, repo_root=repo_root, repo_name=repo_name)
        except WorktreeError:
            raise
        except Exception as exc:
            raise WorktreeError(
                f"Cannot prepare voyage admin worktree for convergence: {exc}"
            ) from exc

        def _run(cmd: list, *, timeout: int = 60) -> subprocess.CompletedProcess:
            return run_hidden(cmd, capture_output=True, text=True,
                                  cwd=str(admin_wt), timeout=timeout)

        def _run_net(cmd: list, *, timeout: Optional[int] = None) -> subprocess.CompletedProcess:
            """Network op with retry/backoff; raises ConvergenceNetworkError on failure."""
            return _retry_git_network_op(cmd, cwd=str(admin_wt),
                                         timeout=timeout or convergence_timeout)

        def _has_ref(ref: str) -> bool:
            return _run(["git", "rev-parse", "--verify", "--quiet", ref]).returncode == 0

        _scratch_wt = admin_wt if not on_branch else None
        try:
            # Sync origin/<voyage_branch> so the admin worktree has the latest voyage
            # state to merge onto. BUG-MSO-2026-0268: use retry helper (was single-shot,
            # ignoring returncode). ConvergenceNetworkError propagates to the dispatcher
            # as a RETRYABLE failure rather than terminal CONVERGENCE_FAILED.
            _run_net(["git", "fetch", "origin",
                      f"{voyage_branch}:refs/remotes/origin/{voyage_branch}"])

            # BUG-MSO-2026-0253: resolve the crew-branch merge target LOCAL-first.
            # In normal dispatch the crew commits to its branch inside a per-crew worktree
            # and never pushes it to origin; because all worktrees of this repo share one
            # ref store, that branch is visible here as a local ref. The old code merged
            # origin/<c_branch> unconditionally, which failed with "not something we can
            # merge" and stranded EVERY successful build whose crew branch was unpushed
            # (the existing test masked this by manually pushing the crew branch). Prefer
            # the local ref; fall back to origin only for the rare pre-pushed case; raise
            # a clear REF_MISSING error if neither exists.
            if _has_ref(f"refs/heads/{c_branch}"):
                merge_target = c_branch
            else:
                # BUG-MSO-2026-0268: use retry helper for crew-branch fetch too.
                # Raises ConvergenceNetworkError on timeout/transient; swallow and
                # fall through to REF_MISSING check only on "couldn't find remote ref".
                try:
                    fetch_r = _run_net(["git", "fetch", "origin",
                                        f"{c_branch}:refs/remotes/origin/{c_branch}"])
                except ConvergenceNetworkError as _net_exc:
                    # Distinguish "ref genuinely absent" (REF_MISSING) from transient
                    # network failure. _run_net only raises if returncode != 0 on all
                    # retries or if every attempt timed out. Check the last result's
                    # output for the canonical "couldn't find remote ref" marker.
                    # BUG-MSO-2026-0272: match only specific git phrases for a genuinely
                    # missing ref.  The bare substring 'remote ref' is too broad — it
                    # appears in timeout/command echoes and many transient error messages
                    # (auth failures, DNS issues, 5xx) and would misclassify them as
                    # REF_MISSING (terminal) instead of retryable.
                    _net_msg = str(_net_exc).lower()
                    _is_ref_missing = (
                        "couldn't find remote ref" in _net_msg
                        or "remote ref does not exist" in _net_msg
                        or "unknown revision" in _net_msg
                        or bool(re.search(r"refspec .* does not match any", _net_msg))
                    )
                    if _is_ref_missing:
                        raise WorktreeError(
                            f"Convergence target missing: crew branch '{c_branch}' was not "
                            f"found locally or on origin — the crew's work cannot be located "
                            f"(REF_MISSING). This usually means the crew produced no commit."
                        )
                    raise  # propagate as ConvergenceNetworkError (retryable)
                if _has_ref(f"refs/remotes/origin/{c_branch}"):
                    merge_target = f"origin/{c_branch}"
                else:
                    raise WorktreeError(
                        f"Convergence target missing: crew branch '{c_branch}' was not "
                        f"found locally or on origin — the crew's work cannot be located "
                        f"(REF_MISSING). This usually means the crew produced no commit."
                    )

            # Sync admin worktree to latest origin/voyage_branch (handles prior failed pushes)
            reset_r = _run(["git", "reset", "--hard", f"origin/{voyage_branch}"])
            if reset_r.returncode != 0:
                raise WorktreeError(
                    f"git reset --hard origin/{voyage_branch} failed: {reset_r.stderr.strip()}"
                )

            # BUG-MSO-2026-0343: reset --hard leaves UNTRACKED files behind —
            # telemetry a prior convergence attempt wrote into this worktree
            # (e.g. .mso/usage/orders/<order>.json) would make the merge refuse
            # with "untracked working tree files would be overwritten by merge"
            # and strand the order CONVERGENCE_FAILED. Clean bookkeeping/
            # telemetry leftovers before merging; branch state is authoritative.
            _swept = _clean_untracked_bookkeeping(_run)
            if _swept:
                try:
                    from maestro.core.fleet_runner import write_lifecycle_event
                    write_lifecycle_event(
                        "CONVERGENCE_UNTRACKED_CLEANED",
                        f"convergence of {c_branch}: removed untracked bookkeeping/"
                        f"telemetry leftover(s) from the voyage worktree before "
                        f"merge: {', '.join(_swept)} — BUG-0343"
                    )
                except Exception:
                    pass

            # Merge crew branch; --no-ff keeps crew history readable.
            # BUG-MSO-2026-0244: reference the order actually being merged, not a hardcoded bug id.
            _ref = order_id or c_branch
            merge_r = _run([
                "git", "merge", "--no-ff", merge_target,
                "-m",
                f"convergence: merge crew {crew_num} ({c_branch}) into {voyage_branch} ({_ref})",
            ])
            if merge_r.returncode != 0:
                # BUG-MSO-2026-0244: capture the conflicting files BEFORE aborting (abort
                # clears the conflicted index). Conflict detail lands on git's stdout, not
                # stderr, so include both streams in the raised error.
                conflicts_r = _run(["git", "diff", "--name-only", "--diff-filter=U"])
                conflict_files = [f for f in conflicts_r.stdout.splitlines() if f.strip()]
                _detail = (merge_r.stdout.strip() + " " + merge_r.stderr.strip()).strip()

                # BUG-MSO-2026-0308 (PSG v4.7.4): a conflict confined to dispatcher
                # CONTROL-PLANE bookkeeping (.mso/queues|orders|voyages|state|usage)
                # is NOT a real failure — the voyage side is authoritative for those
                # files (BUG-0305 flushed the dispatcher's current order JSON to
                # origin/voyage; the crew branch only carries a STALE copy). The 3rd
                # version of this class (progress.md in 4.7.2, order JSON in 4.7.4).
                # BUG-MSO-2026-0342 (PSG v5.0.3) extends the class to per-crew
                # TELEMETRY (.mso/crews/, crew authoritative). Auto-resolve and
                # COMPLETE the merge so the crew's SOURCE changes still land; only
                # genuine source conflicts escalate.
                _status, _resolved = _autoresolve_bookkeeping_conflicts(
                    _run, conflict_files)
                if _status == "resolved":
                    try:
                        from maestro.core.fleet_runner import write_lifecycle_event
                        write_lifecycle_event(
                            "CONVERGENCE_BOOKKEEPING_AUTORESOLVED",
                            f"convergence of {c_branch} auto-resolved bookkeeping/"
                            f"telemetry conflict(s): {', '.join(_resolved)} — "
                            f"control-plane kept the voyage (dispatcher) copy, crew "
                            f"telemetry kept the crew copy — BUG-0308/BUG-0342"
                        )
                    except Exception:
                        pass
                    # fall through to the push step below (merge completed)
                elif _status == "commit_failed":
                    _run(["git", "merge", "--abort"])
                    raise WorktreeError(
                        f"Merge of {c_branch} into {voyage_branch}: bookkeeping "
                        f"auto-resolve failed to commit. git: "
                        f"{_resolved[0] if _resolved else ''}"
                    )
                else:
                    _run(["git", "merge", "--abort"])
                    # BUG-MSO-2026-0343: with no index conflicts, the failure is
                    # usually git refusing to start because UNTRACKED working-tree
                    # files would be overwritten. Name the actual blocking paths
                    # (parsed from git's own output) instead of "unknown".
                    if not conflict_files:
                        _untracked = _parse_untracked_overwrite_paths(_detail)
                        if _untracked:
                            raise WorktreeError(
                                f"Merge of {c_branch} into {voyage_branch} blocked by "
                                f"untracked files in the voyage worktree: "
                                f"{', '.join(_untracked)}. Remove them (or re-dispatch — "
                                f"convergence now cleans .mso bookkeeping leftovers "
                                f"automatically) and retry. git: {_detail}"
                            )
                    # BUG-MSO-2026-0342: escalate with ONLY the genuine source
                    # conflicts — bookkeeping/telemetry paths are noise and must
                    # not be blamed in AUTO_SERIALIZE requeue messages.
                    report_files = _resolved or conflict_files
                    _files = ", ".join(report_files) if report_files else "unknown"
                    if conflict_files:
                        # FTR-MSO-2026-0267: real SOURCE content/add-add conflict — raise
                        # typed exception so the dispatcher can auto-serialize the loser.
                        raise WorktreeContentConflict(
                            f"Merge of {c_branch} into {voyage_branch} failed (content conflict). "
                            f"Conflicting files: {_files}. git: {_detail}",
                            conflict_files=report_files,
                        )
                    raise WorktreeError(
                        f"Merge of {c_branch} into {voyage_branch} failed (conflict). "
                        f"Conflicting files: {_files}. git: {_detail}"
                    )

            # Push merged voyage branch. BUG-MSO-2026-0268: use retry helper.
            # BUG-MSO-2026-0272: pushes upload pack data and need a longer ceiling than
            # fetches; use 2x convergence_timeout to restore pre-PR-122 behaviour.
            # ConvergenceNetworkError propagates to dispatcher as RETRYABLE.
            # BUG-MSO-2026-0295: a detached scratch worktree (branch held by the
            # primary checkout) pushes its merged HEAD to the branch ref directly,
            # then fast-forwards the primary checkout if (and only if) it is clean.
            push_ref = voyage_branch if on_branch else f"HEAD:refs/heads/{voyage_branch}"
            _run_net(["git", "push", "origin", push_ref],
                     timeout=2 * convergence_timeout)
            if not on_branch:
                _run(["git", "fetch", "origin",
                      f"{voyage_branch}:refs/remotes/origin/{voyage_branch}"])
                safe_ff_primary_checkout(voyage_branch, repo_root=repo_root)

            return True
        finally:
            # BUG-MSO-2026-0306: always tear down the scratch worktree so the
            # NEXT convergence (next role) does not collide with a leftover dir.
            if _scratch_wt is not None:
                cleanup_convergence_worktree(_scratch_wt, repo_root=repo_root)


def cleanup_crew_worktree(voyage_id: str, crew_num: int,
                          repo_root: Optional[Path] = None,
                          repo_name: str = "") -> bool:
    """Remove the per-crew worktree (and optionally its crew branch).

    FTR-MSO-2026-0364: removes the worktree from BOTH homes (canonical
    ``.mso/worktrees/<VID>/crew<N>`` and legacy
    ``voyages/active/<VID>/.worktree-crew<N>``) so a relocation transition
    never strands a legacy dir.

    FTR-MSO-2026-0378: *repo_root* pins the product repo the ``git worktree``
    / branch ops run against, and *repo_name* resolves the per-repo crew
    worktree (``crew<N>-<repoName>``). Defaults keep single-repo behaviour
    byte-identical.

    Returns True on clean removal, False if the worktree didn't exist.
    """
    _gc = str(repo_root) if repo_root else None
    c_branch = crew_branch_name(voyage_id, crew_num)
    _per_repo = [worktrees_root() / voyage_id / f"crew{crew_num}-{repo_name}"] if repo_name else []
    candidates = [
        p for p in (
            *_per_repo,
            legacy_crew_worktree_path_for(voyage_id, crew_num),
            worktrees_root() / voyage_id / f"crew{crew_num}",
        ) if p.exists()
    ]

    if not candidates:
        run_hidden(["git", "worktree", "prune"], capture_output=True, cwd=_gc)
        return False

    removed = True
    for wt_path in candidates:
        result = run_hidden(
            ["git", "worktree", "remove", "--force", str(wt_path)],
            capture_output=True, text=True, cwd=_gc,
        )
        if result.returncode != 0:
            removed = _robust_rmtree(
                wt_path, label=f"crew worktree cleanup {voyage_id}-{crew_num}") and removed
            run_hidden(["git", "worktree", "prune"], capture_output=True, cwd=_gc)
        elif wt_path.exists():
            _robust_rmtree(wt_path, label=f"crew worktree cleanup {voyage_id}-{crew_num}")
    _rmdir_if_empty(worktrees_root() / voyage_id)

    # Delete the ephemeral crew branch (it has been merged; keep remote clean).
    # `git branch -d` is the SAFE delete: it refuses to drop a branch whose commits
    # are not reachable from its upstream/HEAD. So if convergence failed (branch is
    # unmerged) this is a no-op and the stranded work survives — see
    # preserve_failed_crew_branch() for the recovery-preserving path.
    if _branch_exists_local(c_branch, repo_root):
        run_hidden(
            ["git", "branch", "-d", c_branch],
            capture_output=True, cwd=_gc,
        )

    # BUG-MSO-2026-0249: also delete the REMOTE crew branch. The branch name is
    # deterministic per (voyage, crew_num), so a leftover origin/crew/<voyage>-<N>
    # would be re-fetched/merged when the same slot is reused for a later order,
    # leaking the prior order's work onto the new crew branch. Best-effort + only
    # when an 'origin' remote exists; never fail cleanup over it.
    _delete_remote_crew_branch(c_branch, repo_root)

    return removed


def _delete_remote_crew_branch(c_branch: str,
                               repo_root: Optional[Path] = None) -> None:
    """Best-effort delete of origin/<c_branch> so a reused crew slot can't merge it
    (BUG-MSO-2026-0249). Silent no-op when there's no origin or the ref is gone.

    FTR-MSO-2026-0378: *repo_root* selects the product repo; ``None`` keeps
    single-repo behaviour."""
    _gc = str(repo_root) if repo_root else None
    try:
        has_origin = run_hidden(
            ["git", "remote", "get-url", "origin"], capture_output=True, text=True,
            cwd=_gc,
        ).returncode == 0
        if not has_origin:
            return
        # Check the REAL remote state, not the local remote-tracking ref. A crew
        # typically pushes its branch without the dispatcher's main repo ever
        # fetching it, so refs/remotes/origin/<branch> may not exist locally even
        # though the branch is live on origin (Copilot PR #110). ls-remote queries
        # origin directly.
        ls = run_hidden(
            ["git", "ls-remote", "--heads", "origin", c_branch],
            capture_output=True, text=True, timeout=60, cwd=_gc,
        )
        if ls.returncode != 0 or not ls.stdout.strip():
            return  # branch not present on the remote
        run_hidden(
            ["git", "push", "origin", "--delete", c_branch],
            capture_output=True, text=True, timeout=60, cwd=_gc,
        )
    except Exception:
        pass


def preserve_failed_crew_branch(voyage_id: str, crew_num: int,
                                order_id: Optional[str] = None,
                                repo_root: Optional[Path] = None,
                                repo_name: str = "") -> Optional[dict]:
    """Preserve a crew branch whose convergence merge FAILED, and free its slot.

    BUG-MSO-2026-0244 / BUG-MSO-2026-0243. When merge_crew_branch_into_voyage()
    raises, the crew's work is stranded on crew/<voyage>-<N>. We must:
      1. Record the stranded commit SHA so it can be cherry-picked during recovery
         even after the crew slot is reused.
      2. Remove the crew worktree dir and RENAME the crew branch out of the way
         (crew/<voyage>-<N> -> salvage/<order>-<sha8>) so the next dispatch of the
         same crew slot starts from a fresh branch off the voyage tip — never
         building on top of the stranded order's work.

    Returns {"salvageBranch": ..., "strandedSha": ...} where salvageBranch is the
    ref that ACTUALLY holds the work (the renamed salvage ref on success, or the
    original crew branch if the rename didn't happen), or None if there was no local
    crew branch to preserve. strandedSha is the durable handle regardless. Best-effort:
    git failures are swallowed so this can never wedge finalization.

    FTR-MSO-2026-0378: *repo_root* pins the product repo the branch ops run
    against; *repo_name* resolves the per-repo crew worktree removed before the
    rename. Defaults keep single-repo behaviour byte-identical.
    """
    _gc = str(repo_root) if repo_root else None
    c_branch = crew_branch_name(voyage_id, crew_num)
    if not _branch_exists_local(c_branch, repo_root):
        return None

    sha = "unknown"
    try:
        sha_r = run_hidden(["git", "rev-parse", c_branch],
                               capture_output=True, text=True, cwd=_gc)
        if sha_r.returncode == 0 and sha_r.stdout.strip():
            sha = sha_r.stdout.strip()
    except Exception:
        pass

    sha8 = sha[:8] if sha != "unknown" else "unknown"
    # Sanitize the label into a git-ref-safe token so an unusual order_id can't make
    # `git branch -M` fail (which would otherwise leave the slot occupied).
    raw_label = order_id or c_branch
    label = re.sub(r"[^A-Za-z0-9._-]", "-", raw_label).strip("-") or "crew"
    salvage = f"salvage/{label}-{sha8}"

    # Remove the worktree first — a checked-out branch cannot be renamed.
    try:
        cleanup_crew_worktree(voyage_id, crew_num,
                              repo_root=repo_root, repo_name=repo_name)
    except Exception:
        pass

    # Rename the (still-unmerged) crew branch out of the slot's namespace so the
    # slot frees for a fresh crew branch on next dispatch. -M forces past an
    # existing salvage ref.
    salvage_ok = False
    if _branch_exists_local(c_branch, repo_root):
        try:
            r = run_hidden(["git", "branch", "-M", c_branch, salvage],
                               capture_output=True, text=True, cwd=_gc)
            salvage_ok = (r.returncode == 0) and _branch_exists_local(salvage, repo_root)
        except Exception:
            salvage_ok = False

    # Report the ref that actually holds the work — never a salvage name that may
    # not exist. If the rename failed, the work still lives on the crew branch (and
    # the SHA is always a valid handle for recovery).
    if salvage_ok:
        preserved_ref = salvage
    elif _branch_exists_local(c_branch, repo_root):
        preserved_ref = c_branch
    elif _branch_exists_local(salvage, repo_root):
        preserved_ref = salvage
    else:
        preserved_ref = None

    return {"salvageBranch": preserved_ref, "strandedSha": sha}


def cleanup_all_crew_worktrees(voyage_id: str,
                               repo_root: Optional[Path] = None) -> int:
    """Remove all per-crew worktrees for a voyage (called from sweep_decks).

    FTR-MSO-2026-0364: sweeps BOTH homes — canonical
    ``.mso/worktrees/<VID>/crew*`` and legacy
    ``voyages/active/<VID>/.worktree-crew*``.

    BUG-MSO-2026-0389: *repo_root* pins the product repo the ``git worktree``
    ops run against (git ``cwd``). ``None`` keeps the single-repo/embedded
    behaviour (dispatcher's own repo); solo/shared mode MUST pass the product
    repo, because the crew worktrees are registered there, not in the artefact
    repo the dispatcher stands in.

    Returns count removed.
    """
    _gc = str(repo_root) if repo_root else None
    candidates = []
    voyage_dir = _legacy_voyage_dir(voyage_id)
    if voyage_dir.exists():
        candidates.extend(
            c for c in voyage_dir.iterdir()
            if c.name.startswith(".worktree-crew") and c.is_dir()
        )
    new_home = worktrees_root() / voyage_id
    if new_home.exists():
        candidates.extend(
            c for c in new_home.iterdir()
            if c.name.startswith("crew") and c.is_dir()
        )

    removed = 0
    for candidate in candidates:
        result = run_hidden(
            ["git", "worktree", "remove", "--force", str(candidate)],
            capture_output=True, cwd=_gc,
        )
        if result.returncode != 0:
            _robust_rmtree(candidate, label=f"crew worktree sweep {voyage_id}")
        else:
            if candidate.exists():
                _robust_rmtree(candidate, label=f"crew worktree sweep {voyage_id}")
        removed += 1

    if removed:
        run_hidden(["git", "worktree", "prune"], capture_output=True, cwd=_gc)
    _rmdir_if_empty(new_home)

    return removed


def cleanup_voyage_worktree(voyage_id: str,
                            repo_root: Optional[Path] = None) -> bool:
    """Remove the admin worktree for a voyage.

    FTR-MSO-2026-0364: removes it from BOTH homes (canonical
    ``.mso/worktrees/<VID>/admin`` and legacy
    ``voyages/active/<VID>/.worktree``).

    BUG-MSO-2026-0389: *repo_root* pins the product repo the ``git worktree``
    ops run against (git ``cwd``). ``None`` keeps single-repo/embedded
    behaviour; solo/shared mode MUST pass the product repo (the admin worktree
    is registered there, not in the artefact repo).

    Returns True on clean removal, False if removal failed (caller should log).
    No-op (returns False) if the worktree directory does not exist.
    """
    _gc = str(repo_root) if repo_root else None
    candidates = [
        p for p in (
            legacy_worktree_path_for(voyage_id),
            worktrees_root() / voyage_id / "admin",
        ) if p.exists()
    ]

    if not candidates:
        # Still prune in case git has stale refs
        run_hidden(["git", "worktree", "prune"], capture_output=True, cwd=_gc)
        return False

    ok = True
    for worktree_path in candidates:
        result = run_hidden(
            ["git", "worktree", "remove", "--force", str(worktree_path)],
            capture_output=True, text=True, cwd=_gc,
        )
        if result.returncode != 0:
            # Fall back to manual removal + prune
            ok = _robust_rmtree(
                worktree_path, label=f"worktree cleanup {voyage_id}") and ok
            run_hidden(["git", "worktree", "prune"], capture_output=True, cwd=_gc)
        elif worktree_path.exists():
            # Belt-and-suspenders: remove any lingering dir
            _robust_rmtree(worktree_path, label=f"worktree cleanup {voyage_id}")
    _rmdir_if_empty(worktrees_root() / voyage_id)

    return ok


# BUG-MSO-2026-0633: per-crew worktree leaf-name patterns, canonical
# (``crew{N}`` / ``crew{N}-{repoName}``) and legacy (``.worktree-crew{N}``).
# Used to correlate a worktree.prune candidate back to the crew slot number
# whose LIVE occupancy must be re-checked before it is ever removed.
_LEGACY_CREW_WT_RE = re.compile(r"^\.worktree-crew(\d+)$")
_CANON_CREW_WT_RE = re.compile(r"^crew(\d+)(?:-.+)?$")


def _crew_number_from_worktree_leaf(name: str) -> Optional[int]:
    """Extract the crew slot number from a worktree directory's leaf name.

    Matches the canonical home's ``crew{N}`` (``crew{N}-{repoName}`` in
    multi-repo dispatch) and the legacy home's ``.worktree-crew{N}``.
    Returns ``None`` for anything else (``admin``, ``.worktree``, a
    ``convergence-*`` scratch dir) — those are not per-crew worktrees and
    have no crew PID to correlate against.
    """
    m = _LEGACY_CREW_WT_RE.match(name) or _CANON_CREW_WT_RE.match(name)
    return int(m.group(1)) if m else None


def _crew_worktree_occupied(crew_number: int, voyage_id: str) -> Optional[str]:
    """BUG-MSO-2026-0633/0636/0640: hard, execution-time occupancy re-check.

    The `hygiene.stale-worktrees` finding a `worktree.prune` action is
    dispatched for — and even the `voyages/complete/<VID>.json` record that
    makes a voyage look archived at all — can both be true when a patrol
    pass computes them and false (or simply no longer relevant) by the time
    the action actually runs later that tick, or on a later tick entirely:
    the order can be retried and a fresh crew dispatched into exactly this
    worktree in between. This is why a worktree with a LIVE crew PID must
    never be pruned on the strength of a precondition computed earlier —
    everything here is re-derived from the crew's own ``state.json``/
    ``pid.txt`` plus a real OS process-liveness probe on every call, never
    from anything computed earlier in the same tick or carried over from a
    previous one.

    BUG-MSO-2026-0636 (F1, INCOMPLETE) tried to make pid.txt a FALLBACK for
    when state.json has no pid at all. BUG-MSO-2026-0640 (F1, round 3) found
    that fallback never fires in the exact case it exists for: a CRASHED
    dispatcher leaves a crew slot's state.json holding a now-dead pid (it
    never resets the slot to idle), and that stale-but-perfectly-parseable
    ``pid`` key short-circuits past pid.txt even when pid.txt names a live,
    freshly-relaunched crew for the same slot. A chain (state.json, else
    pid.txt) can never be safe when state.json can be STALE rather than
    merely absent — only a UNION is: occupied if EITHER source currently
    names a live process, full stop. Neither source is authoritative alone
    (state.json can be stale; pid.txt can be missing or lag behind a crash-
    relaunch), and when NEITHER can be read at all, occupancy is refused
    rather than assumed free.

    pid.txt carries no ``orderId`` of its own, so the cross-voyage exemption
    (a live crew demonstrably working a DIFFERENT voyage's order) is only
    ever granted using state.json's OWN order_id for state.json's OWN pid,
    or for pid.txt's pid when it is corroborated by state.json recording
    that exact same pid — never by borrowing a stale state.json record's
    order_id to excuse a DIFFERENT, live pid.txt pid. That borrow is exactly
    the F1 crash-then-relaunch shape: the old dead pid's order tells you
    nothing about what the new live process is actually doing.

    BUG-MSO-2026-0671 (F4): a bare ``is_process_alive(pid)`` check, on its
    own, disagreed with the adjacent ``_worktree_busy_reason()`` function's
    (BUG-MSO-2026-0668 F2) stronger identity guard — verified by reading
    both functions side by side in this file. A recycled pid.txt/state.json
    PID (routine on Windows after a dispatcher crash) then reads as "still
    occupied" forever, since nothing but the ORIGINAL crew process's own
    exit ever changes those files' recorded pid — permanently unprunable,
    the same class BUG-MSO-2026-0668 F2 closed for the busy marker. Both
    ``state_pid_live`` and ``pidtxt_pid_live`` now also corroborate the
    recorded ``pidCreateTime`` (state.json) / pid.txt's ``<pid>:<createTime>``
    suffix against the CURRENT process's creation time via
    ``maestro.proc_identity.process_create_time`` — a recycled PID whose live
    process started at a different time no longer counts as occupying.

    Returns a human-readable reason string when occupied, or when occupancy
    could not be determined (a hard refusal in both situations); ``None``
    only when the worktree is verified safe to remove.
    """
    from maestro.core import fleet_runner as _fr

    state_file = _fr.get_crew_dir(crew_number) / "state.json"
    state: Optional[dict] = None
    state_readable = False
    if state_file.exists():
        try:
            parsed = json.loads(state_file.read_text(encoding="utf-8"))
            # BUG-MSO-2026-0674 (F5): valid JSON that is not an object (e.g.
            # `null` or `[]`) used to satisfy this try block and set
            # state_readable=True with a non-dict `state`, so the very next
            # `.get()` call below raised an uncaught AttributeError — not the
            # (OSError, ValueError) this except clause catches — aborting
            # the ENTIRE prune pass instead of producing the designed hard
            # refusal. Treat a non-dict parse the same as a parse failure.
            if isinstance(parsed, dict):
                state = parsed
                state_readable = True
        except (OSError, ValueError):
            state = None
    # A file that EXISTS but failed to parse (or parsed to a non-dict) is
    # real corruption/a torn read — distinct from a file that was simply
    # never written, which carries no signal either way and must not, by
    # itself, force a refusal (see the "neither source recorded anything"
    # free case below).
    state_unreadable = state_file.exists() and not state_readable

    state_pid = state.get("pid") if state_readable else None
    state_pid_create_time = state.get("pidCreateTime") if state_readable else None
    order_id = (state.get("orderId") or "") if state_readable else ""

    pid_file = _fr.get_crew_dir(crew_number) / "pid.txt"
    pidtxt_pid = _fr.read_crew_pid(crew_number)
    pidtxt_pid_create_time = _fr.read_crew_pid_create_time(crew_number)
    pidtxt_unreadable = pid_file.exists() and pidtxt_pid is None

    def _order_names_other_voyage(oid: str) -> bool:
        if not oid:
            return False
        order_voyage = _fr._get_voyage_id_for_order(oid)
        return bool(order_voyage and order_voyage != voyage_id)

    def _pid_identity_confirmed(pid: Optional[int], recorded_create_time: Optional[int]) -> bool:
        # BUG-MSO-2026-0671 (F4): the same (pid, createTime) identity guard
        # _worktree_busy_reason() applies to the busy marker
        # (BUG-MSO-2026-0668 F2) — a bare live-PID match is not proof this is
        # the SAME process that recorded it; PID reuse is routine on
        # Windows. A recycled pid whose CURRENT process started at a
        # different time no longer counts as "the crew that wrote this
        # pid". `recorded_create_time` of None means no identity token was
        # captured (state.json/pid.txt written before this fix) — trusted
        # as before rather than treated as a mismatch, matching
        # _worktree_busy_reason()'s own "no identity to corroborate
        # against" fallback.
        if recorded_create_time is None:
            return True
        from maestro import proc_identity as _proc_identity
        current_ct = _proc_identity.process_create_time(pid)
        if current_ct is None:
            # BUG-MSO-2026-0674 (F2): an unresolvable creation-time lookup on
            # a LIVE pid (already confirmed alive by is_process_alive() at
            # the call site below) means "I cannot confirm this is a
            # different process" — never "this is a different process".
            # Treating it as a mismatch made a marker WITH a recorded
            # createTime lose ALL protection instantly, while one with NO
            # createTime at all kept 4 hours of it — the exact inversion
            # this fix removes. Confirm identity here so this can never give
            # LESS protection than the bare is_process_alive() check already
            # gave before BUG-MSO-2026-0671 — the failure mode this guards
            # against (Windows cross-elevation/cross-user OpenProcess
            # denial, POSIX `hidepid` mounts, containerised /proc) is
            # reachable on both platforms and previously deleted a RUNNING
            # crew's worktree along with its uncommitted work.
            return True
        return current_ct == recorded_create_time

    state_pid_live = (
        bool(state_pid) and _fr.is_process_alive(state_pid)
        and _pid_identity_confirmed(state_pid, state_pid_create_time)
    )
    pidtxt_pid_live = (
        bool(pidtxt_pid) and _fr.is_process_alive(pidtxt_pid)
        and _pid_identity_confirmed(pidtxt_pid, pidtxt_pid_create_time)
    )

    if state_pid_live and not _order_names_other_voyage(order_id):
        detail = f" on order {order_id}" if order_id else " with no recorded order"
        return (
            f"crew{crew_number} has a live process (pid={state_pid}, source=state.json)"
            f"{detail} — refusing to remove its worktree"
        )

    if pidtxt_pid_live:
        # pid.txt has no order info of its own. Only excuse it as
        # cross-voyage when a READABLE state.json corroborates that this
        # SAME pid is the one it recorded — otherwise (state.json silent,
        # or naming a DIFFERENT, e.g. stale-and-dead, pid) it is trusted on
        # its own: occupied.
        corroborated_other_voyage = (
            state_readable and pidtxt_pid == state_pid
            and _order_names_other_voyage(order_id)
        )
        if not corroborated_other_voyage:
            return (
                f"crew{crew_number} has a live process (pid={pidtxt_pid}, source=pid.txt)"
                " — refusing to remove its worktree"
            )

    # No live pid from either source. BUG-MSO-2026-0640: if EITHER source
    # exists but could not be parsed, occupancy cannot be ruled out — refuse
    # rather than treat corruption as proof of vacancy. Both sources simply
    # ABSENT (never written at all) is the genuinely-never-occupied case.
    #
    # BUG-MSO-2026-0680 (F5): that refusal used to be PERMANENT and
    # unbounded — nothing but a FRESH crew dispatch into this exact
    # (crew_number) slot ever rewrites state.json/pid.txt, so a corrupt or
    # 0-byte pid.txt left behind by a crashed crew wedged this slot's
    # worktrees un-prunable forever, once the slot's voyage had archived and
    # no new crew would ever be dispatched into it again to overwrite the
    # file. `_worktree_busy_reason()`'s own busy marker was DELIBERATELY
    # age-bounded (`_WORKTREE_BUSY_MARKER_MAX_AGE_SECONDS`) in this same PR
    # to avoid exactly this permanent-block shape — apply the identical
    # bound here: an unreadable file only blocks pruning while it is recent
    # enough to plausibly still describe a live crew; past that age it falls
    # through to the ordinary not-occupied result below. An `OSError` on the
    # `stat()` itself (the file vanished between the existence check above
    # and here) is treated as "recent" — fail toward the existing refusal,
    # never toward a new gap.
    if state_unreadable or pidtxt_unreadable:
        now = time.time()

        def _unreadable_still_recent(path: Path) -> bool:
            try:
                age = now - path.stat().st_mtime
            except OSError:
                return True
            return age <= _WORKTREE_BUSY_MARKER_MAX_AGE_SECONDS

        if (state_unreadable and _unreadable_still_recent(state_file)) or (
            pidtxt_unreadable and _unreadable_still_recent(pid_file)
        ):
            return (
                f"crew{crew_number}'s occupancy could not be determined "
                f"(state.json {'unreadable' if state_unreadable else 'ok'}, "
                f"pid.txt {'unreadable' if pidtxt_unreadable else 'ok'})"
                " — refusing to remove its worktree"
            )

    return None


# BUG-MSO-2026-0636 (F3): a convergence-* scratch worktree's own name embeds
# the PID of the process that created it (resolve_convergence_worktree()'s
# `f"convergence-{voyage_id}{_slug}-{os.getpid()}-{next(_SCRATCH_SEQ)}"` —
# see worktrees.py's own docstring on that function). The trailing two
# hyphen-separated tokens are always digits (pid, then a monotonic sequence
# number) regardless of what voyage_id or repo-name slug precedes them, so
# matching from the END is robust without needing to know either.
_CONVERGENCE_SCRATCH_PID_RE = re.compile(r"^convergence-.+-(\d+)-\d+$")


def _convergence_scratch_pid(name: str) -> Optional[int]:
    """Extract the creating process's PID from a convergence-* scratch
    worktree's directory name, or ``None`` if *name* doesn't match."""
    m = _CONVERGENCE_SCRATCH_PID_RE.match(name)
    if not m:
        return None
    try:
        return int(m.group(1))
    except ValueError:
        return None


# ---------------------------------------------------------------------------
# Per-worktree busy markers (BUG-MSO-2026-0644, F4).
#
# BUG-MSO-2026-0640 (F4) OR'd `_foreign_live_dispatcher_reason()` — "some
# dispatcher, anywhere in this workspace, is alive right now" — into every
# CREW worktree's occupancy check, to close the gap where a dead crew PID
# proves only the crew is gone, not that the dispatcher is done using its
# worktree (the verify gate and convergence both run there, in the
# DISPATCHER's own process, after the crew has already exited). That signal
# is correct for admin/convergence-* worktrees (there is no finer-grained way
# to know which voyage a foreign dispatcher is converging — see
# `_admin_worktree_occupied`), but for a CREW worktree it is workspace-wide
# where the truth is per-worktree: "a dispatcher is running somewhere" is the
# fleet's ordinary healthy state, true almost always, and OR-ing it in made
# `worktree.prune` refuse EVERY crew worktree in the workspace on EVERY tick
# whenever any dispatcher was up — permanently inert, not merely occasionally
# cautious (this is what made Captain ruling 2026-09-06 move worktree.prune
# to observe-only).
#
# The fix: a marker file naming the ACTUAL worktree in use, written by
# `process_crew_completion()` (fleet_runner.py) for the exact window it
# spends on a specific crew's worktree after that crew's own process exits
# (auto-commit/salvage, the verify gate, convergence, cleanup), and cleared
# in a `finally` so a crash never leaves a permanent false-busy marker beyond
# the marked process's own lifetime (the liveness check below is the
# backstop for exactly that case). Stored under the artefact root's
# runtime `state/` dir — never inside the worktree itself, so the marker
# survives (and correctly still refuses) even if a git operation mid-window
# temporarily makes the worktree directory inconsistent.
# ---------------------------------------------------------------------------

def _worktree_busy_dir() -> Path:
    return _worktrees_artefact_root() / "state" / "worktree-busy"


def _worktree_busy_key(voyage_id: str, worktree_name: str) -> str:
    # Both inputs are already filesystem-safe (voyage ids and worktree leaf
    # names never contain path separators), so a plain join is sufficient —
    # no escaping needed beyond keeping the two components visually distinct.
    return f"{voyage_id}__{worktree_name}"


def _worktree_busy_marker_path(voyage_id: str, worktree_name: str) -> Path:
    return _worktree_busy_dir() / f"{_worktree_busy_key(voyage_id, worktree_name)}.json"


_MARK_WORKTREE_BUSY_MAX_ATTEMPTS = 5
_MARK_WORKTREE_BUSY_RETRY_DELAY_SECONDS = 0.05

# BUG-MSO-2026-0668 (F2): fallback ceiling for a busy marker with no
# corroborating `createTime` (written before this fix, or a `createTime`
# lookup that itself returned `None`) — used ONLY when identity cannot be
# checked, never when it can. Deliberately generous: a genuine busy window
# spans a crew's verify gate (`verifyTimeoutMinutes`, default 20) PLUS
# convergence PLUS salvage, all potentially chained in one dispatcher tick,
# so anything close to those durations would risk pruning a worktree that is
# still legitimately in use. This exists only to bound the "PID reuse makes
# it permanently unprunable" failure mode for markers this fix cannot
# identity-check — not to police how long a legitimate busy window may run.
_WORKTREE_BUSY_MARKER_MAX_AGE_SECONDS = 4 * 60 * 60


def mark_worktree_busy(voyage_id: str, worktree_name: str, reason: str = "") -> None:
    """Record that THIS process is actively using (voyage_id, worktree_name)
    right now. Idempotent — a second call simply refreshes the marker
    (same pid, same file). Best-effort: a failure to write must never crash
    the finalize path that is using the worktree for real work — but as of
    BUG-MSO-2026-0660 (F1) the failure is LOGGED rather than silently
    swallowed. A swallowed failure here left the busy window it exists to
    protect with NO marker at all — indistinguishable from a worktree that
    was never busy — and nothing told the operator that protection was
    absent for exactly the window a concurrent prune could destroy it in.

    BUG-MSO-2026-0665 (F5): retries the tmp-write + ``os.replace`` up to
    ``_MARK_WORKTREE_BUSY_MAX_ATTEMPTS`` times, matching the 5-attempt /
    50ms retry loop ``crew.py``'s ``write_state()`` already uses for the
    identical failure mode — a concurrent reader briefly holding the file
    open causing a Windows sharing violation on ``tmp.replace``
    (BUG-MSO-2026-0640 F2). Without a retry, ONE such collision left the
    ENTIRE convergence/salvage window with no marker at all, with only a
    WARN to show for it — a proven, already-remedied failure mode, just
    not yet applied here.

    BUG-MSO-2026-0668 (F2): records ``createTime`` alongside the pid, via
    :func:`maestro.proc_identity.process_create_time` — the same identity
    token ``mso lead``'s own liveness check
    (:func:`maestro.proc_identity.is_running`) uses so a recycled PID reads
    as "not running" rather than "our process". Without it,
    :func:`_worktree_busy_reason` validated occupancy with a bare
    ``is_process_alive(pid)`` and no age bound — a dispatcher killed mid-
    window plus PID reuse (routine on Windows) left a marker that read
    "alive" forever, since nothing but the creating process's own
    ``clear_worktree_busy()`` ever deletes it. ``None`` (lookup failure, or a
    platform where it cannot be determined) is a legitimate value here — the
    reader falls back to an age bound in that case rather than refusing to
    write the marker at all.

    BUG-MSO-2026-0671 (F3): ``path.parent.mkdir(...)`` used to sit BEFORE the
    retry loop below, outside its ``except OSError`` guard entirely. An
    ``OSError`` there (verified by reading this function before the fix —
    the bare ``mkdir()`` call had no surrounding try/except of its own,
    unlike everything after it) propagated straight out of this "best-effort"
    function into its three fleet_runner.py callers
    (``process_crew_completion``, ``archive_stalled_order``,
    ``recover_orphaned_order``), each of which wraps its convergence attempt
    in a broad ``except Exception`` that holds the order ``CONVERGENCE_FAILED``
    — meaning a directory-creation hiccup on a best-effort marker could
    strand an otherwise-healthy order WITHOUT THE MERGE EVER BEING ATTEMPTED.
    The mkdir now sits inside the same try/except OSError as the write+replace
    below, so it gets the identical retry-then-WARN treatment instead of ever
    escaping this function.
    """
    path = _worktree_busy_marker_path(voyage_id, worktree_name)
    from maestro import proc_identity as _proc_identity

    payload = json.dumps({
        "pid": os.getpid(),
        "createTime": _proc_identity.process_create_time(os.getpid()),
        "voyageId": voyage_id,
        "worktree": worktree_name,
        "reason": reason,
        "markedAt": time.time(),
    })
    # BUG-MSO-2026-0680 (F3): a bare `path.with_suffix(".tmp")` shares the
    # SAME fixed `<key>.tmp` path across every process that marks this
    # worktree busy. Two dispatchers racing to mark the same worktree can
    # publish a TORN marker — one process's write_text() truncating the
    # shared tmp file between the other's write_text() and its replace() —
    # which `_worktree_busy_reason()` then reads as corrupt JSON and unlinks
    # as "not-occupied" (BUG-MSO-2026-0660 F4's own by-design handling of
    # corruption), reopening the exact BUG-MSO-2026-0633 live-worktree
    # destruction path this marker exists to prevent. This is the THIRD time
    # in this bug family that destruction path has been reopened
    # (BUG-MSO-2026-0665 F1, BUG-MSO-2026-0674 F1/F2). Suffixing the tmp
    # name with this process's own pid — exactly the fix BUG-MSO-2026-0674
    # F3 applied to crew.py's and fleet_runner.py's state.json writers for
    # the identical shared-tmp-path race — makes every writer's tmp path
    # unique across processes, so two independent write_text()+replace()
    # sequences can only ever produce "last os.replace() wins" on the real
    # marker file — never a torn read of a tmp file shared between them.
    tmp = path.with_name(f"{path.stem}.{os.getpid()}.tmp")
    last_exc: Optional[OSError] = None
    for attempt in range(_MARK_WORKTREE_BUSY_MAX_ATTEMPTS):
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            tmp.write_text(payload, encoding="utf-8")
            tmp.replace(path)
            return
        except OSError as exc:
            last_exc = exc
            if attempt < _MARK_WORKTREE_BUSY_MAX_ATTEMPTS - 1:
                time.sleep(_MARK_WORKTREE_BUSY_RETRY_DELAY_SECONDS)
    try:
        from maestro.core.fleet_runner import write_lifecycle_event
        write_lifecycle_event(
            "WARN",
            f"mark_worktree_busy FAILED for {voyage_id}/{worktree_name} after "
            f"{_MARK_WORKTREE_BUSY_MAX_ATTEMPTS} attempts ({last_exc}) — this "
            "worktree has NO busy protection for the current window; a "
            "concurrent worktree.prune could remove it "
            "(BUG-MSO-2026-0660 F1 / BUG-MSO-2026-0665 F5)"
        )
    except Exception:
        pass
    try:
        tmp.unlink()
    except OSError:
        pass


def clear_worktree_busy(voyage_id: str, worktree_name: str) -> None:
    """Remove the busy marker set by :func:`mark_worktree_busy`. Best-effort
    and safe to call even when no marker exists (the common case for a crew
    worktree that never entered a busy window, or one already cleared)."""
    try:
        _worktree_busy_marker_path(voyage_id, worktree_name).unlink()
    except OSError:
        pass


def _worktree_busy_reason(voyage_id: str, worktree_name: str) -> Optional[str]:
    """The per-worktree replacement for the workspace-wide
    `_foreign_live_dispatcher_reason()` check on CREW worktrees. Returns a
    refusal reason only when a marker exists AND names a still-live process
    that is not this one — a marker left behind by a crashed dispatcher
    (dead pid) is stale and does not block removal, the same "trust a live
    PID, not a file's mere existence" rule every other occupancy check in
    this module already follows.
    """
    path = _worktree_busy_marker_path(voyage_id, worktree_name)
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        # BUG-MSO-2026-0668 (F1): FileNotFoundError IS an OSError, but it does
        # not mean "I could not READ the marker" the way every other OSError
        # here does — it means the marker is GONE. This is the ordinary,
        # expected race between this function's own `path.exists()` check
        # above and the owner's `clear_worktree_busy()` deleting the file a
        # moment later (or `mark_worktree_busy`'s own tmp.replace briefly
        # making the target vanish-then-reappear) — not a transient read
        # failure on a marker that is still there. BUG-MSO-2026-0665's F1 fix
        # made EVERY OSError here fail closed to stop a real destruction path
        # (a PermissionError/sharing-violation misread as corruption,
        # unlinking a live dispatcher's own protection marker), but it swept
        # ENOENT up with it — turning this routine race into a spurious
        # refusal-plus-WARN for a worktree that is legitimately free. Treat
        # "no marker" as "not occupied", exactly like the `not path.exists()`
        # check above already does; every OTHER OSError still falls through
        # to the fail-closed branch below unchanged.
        return None
    except OSError as exc:
        # BUG-MSO-2026-0665 (F1): an OSError here means "I could not READ the
        # marker" — not "the marker is corrupt" and CERTAINLY not "there is
        # no marker". A transient Windows sharing violation / PermissionError
        # on read_text (mark_worktree_busy's own concurrent tmp.replace,
        # antivirus, the search indexer) used to be caught together with
        # ValueError below and treated as corruption — which UNLINKED the
        # live dispatcher's own protection marker and returned "not
        # occupied", handing worktree.prune permission to force-remove a
        # worktree a dispatcher is actively converging in. That is exactly
        # the BUG-MSO-2026-0633 destruction this whole marker mechanism
        # exists to prevent, reopened by BUG-MSO-2026-0660's own F4 fix. Fail
        # closed instead: refuse, and never unlink a marker we could not even
        # read — only a marker we successfully parsed and found genuinely
        # stale (dead pid) or corrupt (bad JSON, see ValueError below) is
        # safe to clear. FileNotFoundError is excepted separately above —
        # this branch is every OTHER OSError (PermissionError, sharing
        # violations, etc.), where "could not read" genuinely does mean
        # "could not read", not "does not exist".
        try:
            from maestro.core.fleet_runner import write_lifecycle_event
            write_lifecycle_event(
                "WARN",
                f"worktree busy marker for {voyage_id}/{worktree_name} could "
                f"not be read ({exc}) — refusing to remove this worktree "
                "(fail closed) rather than treating a transient read error "
                "as corruption (BUG-MSO-2026-0665 F1)"
            )
        except Exception:
            pass
        return (
            f"the worktree busy marker could not be read ({exc}) — "
            "refusing to remove it (fail closed; BUG-MSO-2026-0665 F1)"
        )
    except ValueError:
        # BUG-MSO-2026-0660 (F4): an unreadable/corrupt-JSON marker carries no
        # pid to validate liveness against, so refusing on its mere existence
        # broke the "trust a live PID, not a file's mere existence" rule every
        # other occupancy check in this module follows (the rule
        # BUG-MSO-2026-0640's own F1 established). Nothing but the creating
        # process's own `finally` ever deletes a marker, and a corrupt file
        # can never run that `finally` — so the old refusal here was a
        # PERMANENT, unclearable block with no operator route out. Treat it
        # as not-occupied instead, log loudly so the corruption is visible,
        # and best-effort remove the file so it does not keep tripping this
        # WARN on every future check. Unlike the OSError branch above, the
        # bytes here WERE read successfully — a ValueError means the content
        # itself is malformed JSON, genuine corruption rather than a
        # transient read failure, so unlinking is safe.
        try:
            from maestro.core.fleet_runner import write_lifecycle_event
            write_lifecycle_event(
                "WARN",
                f"worktree busy marker for {voyage_id}/{worktree_name} is "
                "unreadable/corrupt — treating as not-occupied rather than "
                "a permanent refusal (BUG-MSO-2026-0660 F4)"
            )
        except Exception:
            pass
        try:
            path.unlink()
        except OSError:
            pass
        return None
    if not isinstance(data, dict):
        # BUG-MSO-2026-0680 (F2): valid JSON that is not an object (e.g.
        # `null` or `[]`) used to reach `data.get("pid")` below with a
        # non-dict `data` — an uncaught AttributeError that ABORTED THE
        # WHOLE prune_stale_worktrees_ex() PASS, not just this one
        # worktree's check. BUG-MSO-2026-0674 (F5) added the identical
        # `isinstance(parsed, dict)` guard to the sibling
        # `_crew_worktree_occupied()` above but not here — same file, same
        # review round, same defect shape. Treated the same way this
        # function's own ValueError branch (BUG-MSO-2026-0660 F4) already
        # treats corrupt JSON: not-occupied, logged loudly, best-effort
        # unlink — never a fail-closed refusal, since nothing but the
        # marker's own creator ever clears it and a non-dict marker has no
        # legitimate owner left to do so.
        try:
            from maestro.core.fleet_runner import write_lifecycle_event
            write_lifecycle_event(
                "WARN",
                f"worktree busy marker for {voyage_id}/{worktree_name} is "
                "not a JSON object — treating as not-occupied rather than "
                "a permanent refusal (BUG-MSO-2026-0680 F2)"
            )
        except Exception:
            pass
        try:
            path.unlink()
        except OSError:
            pass
        return None
    pid = data.get("pid")
    if not isinstance(pid, int):
        return None
    if pid == os.getpid():
        return None
    from maestro.core import fleet_runner as _fr

    if not _fr.is_process_alive(pid):
        return None

    # BUG-MSO-2026-0668 (F2): a bare live-PID match is not proof of IDENTITY.
    # PID reuse — routine on Windows — means SOME live process now holds
    # `pid`, but not necessarily the one that wrote this marker; nothing but
    # the ORIGINAL process's own `clear_worktree_busy()` ever deletes it, and
    # that process is long gone. Left unchecked, a dispatcher killed mid-
    # busy-window plus a later, unrelated process recycling its pid makes
    # this worktree permanently unprunable — the same class BUG-MSO-2026-0660
    # F4 already closed for corrupt markers. Corroborate with creation-time
    # the same way `mso lead`'s own liveness check does
    # (`maestro.proc_identity.is_running`): a recycled PID whose CURRENT
    # process started at a different time no longer counts as "the same
    # process that marked this worktree busy".
    from maestro import proc_identity as _proc_identity

    recorded_ct = data.get("createTime")
    current_ct = _proc_identity.process_create_time(pid) if recorded_ct is not None else None
    if recorded_ct is not None and current_ct is not None:
        if current_ct != recorded_ct:
            return None
    else:
        # No identity to corroborate against — either no createTime was
        # recorded (a marker written before this fix, or `process_create_time`
        # itself returned `None` at mark-time), OR a createTime WAS recorded
        # but the CURRENT lookup for this still-live pid failed (BUG-MSO-2026-
        # 0674 F1: Windows cross-elevation/cross-user OpenProcess denial,
        # POSIX `hidepid` mounts, containerised /proc — all reachable on a
        # perfectly live process). A lookup failure means "I cannot confirm
        # this is a different process", never "this is a different process"
        # — treating it as proof-of-mismatch was an inversion that gave a
        # marker WITH a createTime LESS protection than one with none at all,
        # instantly losing the fail-closed refusal below and reopening the
        # exact BUG-MSO-2026-0633 destruction this marker exists to prevent.
        # Fall back to the same age bound the no-createTime case already
        # uses, so this state is protected like a live PID match but still
        # cannot become a permanent, unclearable block.
        marked_at = data.get("markedAt")
        if (
            not isinstance(marked_at, (int, float))
            or (time.time() - marked_at) > _WORKTREE_BUSY_MARKER_MAX_AGE_SECONDS
        ):
            return None

    detail = data.get("reason") or "in use by the dispatcher"
    return (
        f"a live dispatcher process (pid={pid}) is currently using this "
        f"worktree ({detail}) — refusing to remove it"
    )


def _foreign_live_dispatcher_reason() -> Optional[str]:
    """BUG-MSO-2026-0636 (F3): this workspace's ``dispatcher.pid``, when it
    names a DIFFERENT live process than the one calling this function,
    proves a dispatcher is running RIGHT NOW and could be mid-convergence on
    ANY admin/admin-{repo}/convergence-* worktree in this workspace — those
    have no crew number to correlate a specific occupant against (see
    :func:`_admin_worktree_occupied`, the only caller left), so a workspace-
    wide "is any dispatcher alive" signal is the best available proof for
    them. Not provably safe, so refused.

    Scoped to admin/convergence worktrees ONLY as of BUG-MSO-2026-0644 (F4).
    BUG-MSO-2026-0640 (F4) previously OR'd this same workspace-wide check
    into every CREW worktree's occupancy check too, on the correct premise
    that a dead crew pid proves only the CREW is gone, not that the
    dispatcher is done with the worktree it left behind (``run_verify_gate``
    runs with ``cwd=<crew worktree>`` for up to ``verifyTimeoutMinutes``, and
    convergence/salvage follow in the same worktree afterwards). But "some
    dispatcher is alive somewhere in this workspace" is true almost always —
    it is the fleet's ordinary healthy state — so OR-ing it into every crew
    worktree candidate refused ALL of them on every tick whenever any
    dispatcher was running, making ``worktree.prune`` permanently inert
    rather than occasionally cautious (the finding that made Captain ruling
    2026-09-06 move the action to observe-only). Crew worktrees now use
    :func:`_worktree_busy_reason` instead — a marker naming the SPECIFIC
    worktree a dispatcher is using right now, written by
    ``process_crew_completion()`` for exactly that window.

    Excluding our OWN pid is deliberate: the dispatcher's own startup call to
    ``prune_stale_worktrees_ex()`` (fleet_runner.py) runs with
    ``dispatcher.pid`` already pointing at itself (written before the prune
    call), and always BEFORE it ever performs a convergence in that run —
    without this exclusion, guard (2) would refuse every admin/convergence
    worktree on every single startup, defeating the reason this function
    exists. A caller in a genuinely DIFFERENT process (the LEAD daemon's own
    ``worktree.prune`` action) has no such exclusion — a live foreign
    ``dispatcher.pid`` there is real evidence.
    """
    from maestro.core import fleet_runner as _fr

    dispatcher_lock = _worktrees_artefact_root() / "dispatcher.pid"
    if dispatcher_lock.exists():
        try:
            disp_pid = int(dispatcher_lock.read_text(encoding="utf-8").strip())
        except (OSError, ValueError):
            disp_pid = None
        if disp_pid and disp_pid != os.getpid() and _fr.is_process_alive(disp_pid):
            return (
                f"a dispatcher (pid={disp_pid}) is currently running for this "
                f"workspace and may still be using this worktree (verify gate, "
                f"convergence, or salvage can all run here after a crew's own "
                f"process has already exited) — refusing to remove it"
            )
    return None


def _admin_worktree_occupied(candidate_name: str) -> Optional[str]:
    """BUG-MSO-2026-0636 (F3): admin / admin-{repo} / convergence-* worktrees
    have no crew number to correlate against :func:`_crew_worktree_occupied`
    — pre-fix, they skipped occupancy re-validation entirely and went
    straight to ``git worktree remove --force``. They are not liveness-free
    though: :func:`resolve_convergence_worktree` (fleet_runner.py's SOLE
    caller) is the only code that ever creates or mutates them, always from
    within a running dispatcher process. Two checks, either a hard refusal:

      1. A convergence-* scratch dir's name embeds the PID of the process
         that created it. If that PID is still alive, it may still be using
         this exact worktree (its own try/finally teardown hasn't run yet).
      2. :func:`_foreign_live_dispatcher_reason` — a live, foreign
         dispatcher.pid proves a dispatcher could be mid-convergence on ANY
         admin/admin-{repo}/convergence-* worktree in this workspace right
         now.
    """
    from maestro.core import fleet_runner as _fr

    scratch_pid = _convergence_scratch_pid(candidate_name)
    if scratch_pid and _fr.is_process_alive(scratch_pid):
        return (
            f"convergence scratch worktree has a live creating process "
            f"(pid={scratch_pid}) — refusing to remove it"
        )

    return _foreign_live_dispatcher_reason()


def _warn_worktree_prune_refused(voyage_id: str, worktree_name: str, reason: str) -> None:
    """BUG-MSO-2026-0633: a worktree.prune candidate was refused because a
    precondition true at finding time ('voyage archived', 'worktree
    unoccupied') no longer holds at execution time. Always logged — D7's
    'act never means quietly' applies to a refusal exactly as much as to an
    execution; the LEAD's own worktree.prune action turns this same fact
    into a LEAD_ACTION outcome=refused (maestro/lead/bands.py)."""
    try:
        from maestro.core.fleet_runner import write_lifecycle_event
        write_lifecycle_event(
            "WARN",
            f"worktree.prune REFUSED {voyage_id}/{worktree_name}: {reason} "
            "(BUG-MSO-2026-0633 — precondition re-validated at execution time)"
        )
    except Exception:
        pass


class WorktreeRepoRootUnresolved(RuntimeError):
    """BUG-MSO-2026-0692 (F1): :func:`resolve_worktree_prune_root` could not
    name the product repo a ``git worktree`` operation must run in.

    Raised INSTEAD of returning ``None`` (which every caller would then have
    to remember to translate into "don't pass a cwd" — i.e. straight back to
    the ambient-cwd hazard this exists to close) and instead of silently
    falling back to the artefact checkout, which is
    :func:`maestro.core.fleet_runner.solo_worktree_repo_root`'s own
    documented contract: "Raises when the product repo cannot be resolved in
    solo/shared mode - callers translate that into HOLDING the order (never a
    silent fallback to the artefact checkout)."
    """


def resolve_worktree_prune_root(
    workspace: Optional[Path] = None, artefact_root: Optional[Path] = None,
) -> Path:
    """The SINGLE resolution point for the git ``cwd`` a worktree
    prune/remove runs in. Every non-dispatcher caller routes through here.

    BUG-MSO-2026-0692 (F1). ``mso worktree prune`` (``cli.cmd_worktree``) and
    the LEAD daemon's ``worktree.prune`` action (``maestro/lead/bands.py``)
    held two DIFFERENT answers to the same question — the CLI's was fixed by
    BUG-MSO-2026-0689 (F2), the LEAD's was not — so the LEAD kept running
    ``git worktree remove``/``prune`` against the ARTEFACT repo in solo/
    shared mode (BUG-MSO-2026-0389's exact distinction) and, when its
    ``workspace`` was ``None``, against whatever the daemon's ambient cwd
    happened to be. ``maestro/lead/bands.py``'s module docstring claims both
    paths "execute the identical code path"; extracting the resolution to one
    function and calling it from BOTH is what makes that claim true, rather
    than duplicating the same four lines a third time and hoping the next
    change reaches every copy — seven consecutive review rounds on PR #406
    have been one fix landing at some call sites and not all of them.

    Resolution order. All three tiers are EXPLICIT; the ambient process cwd
    is never a tier:

    1. :func:`maestro.core.fleet_runner.solo_worktree_repo_root` — the
       configured PRODUCT repo in solo/shared artefact-repo mode. Its raising
       means solo/shared mode is active but the product repo is unresolvable;
       that becomes :class:`WorktreeRepoRootUnresolved`, never a fallback to
       the artefact checkout.
    2. *workspace* — embedded mode, where the workspace root IS the product
       repo (``find_workspace()``'s embedded contract).
       ``solo_worktree_repo_root()`` returns ``None`` here on the documented
       assumption that "the dispatcher's cwd IS the product repo", which
       holds ONLY for the dispatcher's own startup call (always launched with
       ``cwd=ws``); an operator's shell, and a detached daemon, carry no such
       guarantee.
    3. *artefact_root*'s parent, when *artefact_root* is a ``.mso``
       directory — the embedded-mode derivation of the product repo from the
       artefact plane (``<product-repo>/.mso``). This is what lets the LEAD
       daemon resolve EXPLICITLY when it was handed no ``workspace`` at all,
       instead of leaving git to the daemon's cwd.

    Nothing resolvable → :class:`WorktreeRepoRootUnresolved`. A refusal is
    always correct here; a guess never is.
    """
    from maestro.core.fleet_runner import solo_worktree_repo_root

    try:
        resolved = solo_worktree_repo_root()
    except Exception as exc:  # noqa: BLE001 - translated, never swallowed
        raise WorktreeRepoRootUnresolved(
            "solo/shared artefact-repo mode is active but the PRODUCT repo "
            f"could not be resolved ({type(exc).__name__}: {exc}). Refusing "
            "rather than falling back to the artefact checkout "
            "(BUG-MSO-2026-0389) or to whatever `git worktree` finds at the "
            "caller's ambient cwd."
        ) from exc
    if resolved is not None:
        return Path(resolved)
    if workspace is not None:
        return Path(workspace)
    if artefact_root is not None and Path(artefact_root).name == MSO_DIR_NAME:
        return Path(artefact_root).parent
    raise WorktreeRepoRootUnresolved(
        "embedded mode with no workspace root supplied and no `.mso` artefact "
        f"root to derive one from (workspace={workspace!r}, "
        f"artefact_root={artefact_root!r}) - refusing rather than letting "
        "`git worktree` resolve the repo from the caller's ambient cwd."
    )


def _worktree_registration_dir(path: Path) -> Optional[Path]:
    """git's own ``<main-git-dir>/worktrees/<name>`` admin directory for the
    worktree at *path*, read from the ``gitdir:`` pointer in its ``.git``
    FILE.

    BUG-MSO-2026-0692 (F2): this is how :func:`_remove_worktree` learns which
    repo a worktree is ACTUALLY registered in, independent of whichever
    ``git_cwd`` its caller resolved — the fact its compensating ``git
    worktree prune`` needs and previously did not have. It MUST be read
    BEFORE the directory is deleted: :func:`_robust_rmtree` destroys the
    pointer file along with everything else, after which the registration is
    only discoverable by guessing.

    ``None`` when *path* is not a git worktree at all — no ``.git`` entry, a
    real ``.git`` DIRECTORY (an ordinary clone, not a worktree), or an
    unreadable/garbled pointer. A leftover directory that was never ``git
    worktree add``-ed has no registration to reap and leaves no orphan
    behind, which is exactly why a failed ``git worktree remove`` against one
    is ordinary cruft cleanup rather than a wedge (see
    :func:`_remove_worktree`).
    """
    try:
        dotgit = Path(path) / ".git"
        if not dotgit.is_file():
            return None
        text = dotgit.read_text(encoding="utf-8", errors="replace").strip()
    except OSError:
        return None
    if not text.lower().startswith("gitdir:"):
        return None
    # split(":", 1) - the FIRST colon ends the "gitdir" key; a Windows drive
    # letter's colon is the second one and stays with the path.
    target = text.split(":", 1)[1].strip()
    if not target:
        return None
    try:
        reg = Path(target)
        if not reg.is_absolute():
            reg = Path(path) / reg
        return Path(os.path.normpath(str(reg)))
    except (OSError, ValueError):
        return None


def _remove_worktree(
    path: Path, git_cwd: Optional[str], voyage_id: str, worktree_label: str,
) -> Optional[str]:
    """Remove one worktree. Returns ``None`` when the worktree is genuinely
    gone (git registration included), or a refusal reason string when it is
    not — the caller records that in ``refused`` and does NOT count it as
    pruned.

    BUG-MSO-2026-0689 (F2): run ``git worktree remove --force`` and stop
    silently discarding its return code. Every call site used to run ``git
    worktree remove`` and immediately follow it with an unconditional
    :func:`_robust_rmtree` regardless of whether the removal succeeded — so a
    removal that failed (e.g. because it ran against the WRONG repo: ``mso
    worktree prune`` passed the artefact-repo root instead of
    :func:`maestro.core.fleet_runner.solo_worktree_repo_root` in solo/shared
    mode, so git in that repo had no record of this worktree at all —
    BUG-MSO-2026-0389's exact distinction) still deleted the on-disk
    directory, leaving git's OWN ``.git/worktrees/<name>`` metadata entry (in
    whichever repo the worktree actually IS registered in) pointing at a path
    that no longer exists. That orphaned entry is what wedges the next ``git
    worktree add`` at that path.

    BUG-MSO-2026-0692 (F2) closes the two halves 0689 left open:

    * **The compensating prune ran in the wrong repo.** It reran ``git
      worktree prune`` in the SAME ``git_cwd`` whose ``git worktree remove``
      had just failed, so in precisely the wrong-repo case it was aimed at a
      repo with no record of the worktree and could not reap anything —
      despite the docstring claiming it closed the window "in the correct
      repo". It now targets the repo the worktree is REGISTERED in, resolved
      from the worktree's own ``gitdir:`` pointer
      (:func:`_worktree_registration_dir`, read before the directory is
      deleted), via an explicit ``git --git-dir=<main-git-dir> worktree
      prune`` that needs no cwd at all.
    * **A failed removal reported success.** ``pruned += 1`` fired
      unconditionally and nothing landed in ``refused``, so ``mso worktree
      prune`` printed "N worktree(s) removed" while leaving the exact orphan
      that wedges the next ``git worktree add``. A silent false success is
      worse than a reported failure.

    The on-disk directory is still removed unconditionally — that part of the
    pre-existing best-effort hygiene contract is deliberately unchanged (a
    leftover directory that was never registered as a worktree at all must
    not survive purely because ``git worktree remove`` had nothing to act
    on). What determines success is now the fact the caller actually cares
    about: whether a dangling registration survives. Three outcomes:

    1. ``git worktree remove`` succeeded → pruned.
    2. It failed, but no registration survives — either there never was one
       (ordinary cruft: :func:`_worktree_registration_dir` returned ``None``)
       or the compensating prune in the correct repo reaped it → the worktree
       IS gone and nothing can be wedged by it, so it still counts as pruned.
       The failure is surfaced via :func:`_warn_worktree_prune_refused`
       either way, never silently discarded.
    3. It failed AND the registration survived the compensating prune → a
       refusal reason is returned. This is the wedge case, and it is now
       reported to the operator instead of counted as a success.
    """
    registration = _worktree_registration_dir(path)
    result = run_hidden(
        ["git", "worktree", "remove", "--force", str(path)],
        capture_output=True, text=True, cwd=git_cwd,
    )
    label = f"prune stale worktree {voyage_id}/{worktree_label}"
    if result.returncode == 0:
        _robust_rmtree(path, label=label)
        return None

    stderr = (result.stderr or "").strip()
    detail = f": {stderr[:200]}" if stderr else ""
    _robust_rmtree(path, label=label)

    if registration is not None:
        # `--git-dir` names the repo the worktree is REGISTERED in
        # explicitly - no cwd at all, so nothing about the caller's ambient
        # location can redirect it (BUG-MSO-2026-0692 F2).
        run_hidden(
            ["git", "--git-dir", str(registration.parent.parent),
             "worktree", "prune"],
            capture_output=True,
        )
    else:
        # No registration pointer to read: nothing is registered anywhere for
        # this path, so there is no orphan to reap. The caller-resolved repo
        # is still swept for good measure - it is the only repo we can name.
        run_hidden(["git", "worktree", "prune"], capture_output=True, cwd=git_cwd)

    orphaned = registration is not None and registration.exists()
    if not orphaned:
        _warn_worktree_prune_refused(
            voyage_id, worktree_label,
            f"git worktree remove failed (rc={result.returncode}){detail} - "
            "the directory was removed and NO dangling registration survives "
            + (
                f"(reaped in {registration.parent.parent})"
                if registration is not None
                else "(this path was never registered as a git worktree)"
            )
            + ", so the worktree is genuinely gone and this candidate still "
            "counts as pruned",
        )
        return None

    reason = (
        f"git worktree remove failed (rc={result.returncode}){detail} AND the "
        f"dangling git registration at {registration} survived the "
        "compensating `git worktree prune` - the next `git worktree add` at "
        f"{path} will be wedged by it. NOT counted as a successful prune "
        "(BUG-MSO-2026-0692 F2)"
    )
    _warn_worktree_prune_refused(voyage_id, worktree_label, reason)
    return reason


@dataclass(frozen=True)
class WorktreePruneResult:
    """BUG-MSO-2026-0633: :func:`prune_stale_worktrees`'s int-count return
    cannot distinguish "nothing was stale" from "something was stale but
    refused at execution time" — the LEAD's ``worktree.prune`` action needs
    the second case to surface as a loud ``LEAD_ACTION outcome=refused``,
    never a silent skip. ``removed`` preserves the pre-existing int contract
    (see :func:`prune_stale_worktrees`); ``refused`` is additive, one entry
    per worktree whose occupancy check refused removal.
    """

    removed: int
    refused: "tuple[str, ...]" = ()


def prune_stale_worktrees_ex(repo_root: Optional[Path] = None) -> WorktreePruneResult:
    """Remove worktrees whose voyage has moved to voyages/complete/.

    FTR-MSO-2026-0364: sweeps BOTH homes — legacy worktrees inside
    ``voyages/active/<VID>/`` (pre-relocation dispatches) and the canonical
    ``.mso/worktrees/<VID>/`` runtime home — so a voyage that ran with a
    legacy worktree still has it pruned at completion.

    Also runs `git worktree prune` to clean broken git refs.

    BUG-MSO-2026-0389: *repo_root* pins the product repo the ``git worktree``
    prune/remove ops run against (git ``cwd``) — independent of the durable-
    plane scan root below. ``None`` keeps single-repo/embedded behaviour — the
    git ops resolve from the process's own cwd. In solo/shared mode the
    caller passes the product repo so the worktrees registered there are
    actually found and pruned.

    The durable-plane scan (voyages/active|complete, and the canonical
    ``.mso/worktrees/`` home) resolves via :func:`_worktrees_artefact_root`
    (BUG-MSO-2026-0568) — the artefact root, honouring
    ``fleet_runner._MAESTRO_DIR_OVERRIDE`` when a caller has entered
    ``workspace_scope()`` — not a bare ``_repo_root()`` call. That plane
    genuinely lives in the artefact repo regardless of which repo the calling
    process's cwd happens to be, but before BUG-MSO-2026-0601 the lookup
    itself never consulted the override, so a caller that scoped itself to a
    non-default workspace (the LEAD daemon, the Hub, a multi-workspace CLI
    scan) still silently scanned whatever repo the process cwd happened to
    sit in.

    BUG-MSO-2026-0633: a completed-voyage classification and a worktree's
    occupancy are BOTH re-validated fresh, right here, immediately before
    any removal — never trusted from a patrol finding computed earlier, no
    matter how recently. Two independent guards, either one a hard refusal:

      1. A ``voyages/active/<VID>.json`` record beats a stale
         ``voyages/complete/<VID>.json`` — the voyage is not archived if it
         is demonstrably still active right now, regardless of what a
         leftover complete-side file (e.g. from a voyage-reopen recovery
         that never cleaned up its old archive copy) claims.
      2. A worktree with a LIVE crew PID recorded against it (union of
         state.json and pid.txt — see :func:`_crew_worktree_occupied`), OR
         still in use by the dispatcher after its crew's own process has
         exited (verify gate / convergence / salvage — a crew worktree via
         its own per-worktree busy marker, :func:`_worktree_busy_reason`,
         BUG-MSO-2026-0644 F4; an admin/convergence-* worktree via the
         workspace-wide :func:`_foreign_live_dispatcher_reason`), is never
         removed, full stop.

    Returns a :class:`WorktreePruneResult` (removed count + refused-worktree
    detail); :func:`prune_stale_worktrees` is the pre-existing int-returning
    wrapper kept for callers that only need the count.
    """
    _gc = str(repo_root) if repo_root else None
    run_hidden(["git", "worktree", "prune"], capture_output=True, cwd=_gc)

    artefact_dir = _worktrees_artefact_root()
    active_dir = artefact_dir / "voyages" / "active"
    complete_dir = artefact_dir / "voyages" / "complete"

    # BUG-MSO-2026-0594: voyages/complete/ holds "<VID>.json" files, not
    # directories named after the voyage id — comparing p.name ("VOY-X.json")
    # against a bare directory name ("VOY-X") could never match, so neither
    # prune loop below ever pruned anything. p.stem strips the extension;
    # glob("*.json") mirrors patrol/checks/hygiene.py's own (correct) scan.
    completed_voyage_ids = (
        {p.stem for p in complete_dir.glob("*.json")} if complete_dir.exists() else set()
    )
    # BUG-MSO-2026-0633: an active-side record is fresh, authoritative proof
    # the voyage is NOT archived, even when a stale complete-side copy also
    # exists — see the class docstring's guard (1). `mso order retry` only
    # ever rewrites the ORDER file, never the voyage record, so a voyage
    # reopened by retrying one of its stranded orders can legitimately have
    # both files present at once. Checked per-candidate below (not
    # subtracted from `completed_voyage_ids` up front) so the contradiction
    # produces a LOUD refusal entry — never a silent "wasn't eligible" skip
    # indistinguishable from an ordinary still-active voyage.
    active_voyage_ids = (
        {p.stem for p in active_dir.glob("*.json")} if active_dir.exists() else set()
    )

    # BUG-MSO-2026-0636 (F2): `active_voyage_ids` above never actually fires
    # for the retried-order repro it was written for — `order_retry.py`
    # (maestro/core/order_retry.py) resets the ORDER's own file back to
    # PENDING in `queues/orders/<id>.json` (or, for an already-archived
    # order, `orders/active/`) and NEVER writes anything under `voyages/` at
    # all. So a voyage reopened purely by retrying one of its stranded
    # orders never gets a `voyages/active/<VID>.json` record, and this guard
    # was inert for exactly the scenario its own docstring describes. The
    # REAL, reachable signal is an order — anywhere the dispatcher's own
    # scan looks for live work — whose `voyageId` still names this (allegedly
    # archived) voyage. Scanned ONCE here (not per-candidate) for the same
    # reason `active_voyage_ids` is: cheap, and every worktree candidate
    # queries the same precomputed set.
    # BUG-MSO-2026-0640 (F3): the scan above had NO status filter — it took
    # voyageId from EVERY order file, including BACKLOG/DRAFT/PAUSED ones the
    # operator deliberately parked (see fleet_runner.py's own
    # _AUTO_RELEASE_STATUSES comment: BACKLOG/DRAFT/PAUSED mean "operator
    # parked this on purpose", never "still active"), and terminal-ish holds
    # like STALLED/CONVERGENCE_FAILED/VERIFY_FAILED that stay dormant until
    # an operator explicitly retries them. A BACKLOG order naming an archived
    # voyage made that voyage's worktrees permanently unprunable — reachable
    # on the live MSO plane today via VOY-MSO-2026-0090/0153. The dispatcher
    # itself only ever treats PENDING (scan_all_queues' generic queue check)
    # and OPEN (the "defects" tier's own status vocabulary) as immediately
    # dispatchable, and IN_PROGRESS (orders/active/'s v8.5 fallback) as
    # currently being worked — so those, and only those, are "live work" here
    # too. BUG-MSO-2026-0644 (F2) adds NAV_REVIEW_PENDING: every file that
    # ever lands in queues/review/ carries exactly that status (see
    # _maybe_hold_transition_for_review / _check_verdict_fail_at_role_
    # completion / chart_routing._route_to_human_gate, the three writers —
    # none of them ever write any other status there) and is, by
    # construction, an order paused for a human decision, not archived or
    # abandoned. `mso review approve/revise/reject` is the only way it ever
    # leaves that directory, so its mere presence there is itself the "live
    # work" signal, same as PENDING/IN_PROGRESS/OPEN elsewhere.
    _LIVE_ORDER_STATUSES = {"PENDING", "IN_PROGRESS", "OPEN", "NAV_REVIEW_PENDING"}
    reopened_order_voyage_ids: "set[str]" = set()
    # BUG-MSO-2026-0665 (F6): both call sites below only ever consult
    # `reopened_order_voyage_ids` for a candidate whose `voyage_id` is
    # already `in completed_voyage_ids` — with that set empty, nothing is
    # eligible for pruning at all, so the set built here can never be
    # queried. Skip the ~15-directory order-file scan entirely in that case
    # rather than paying its cost on every prune call that finds nothing to
    # prune (the common case on a quiet workspace).
    if completed_voyage_ids:
        # BUG-MSO-2026-0668 (F5): the base queue-subdir set + the
        # queues/requests/* walk used to be hand-copied here as a literal
        # tuple — the SAME drift BUG-MSO-2026-0644 (F2) already had to patch
        # by hand once (adding requests/* support after
        # fleet_runner._iter_queue_order_files() grew it there first). Reuse
        # that shared source instead, so this scan cannot silently fall
        # behind scan_all_queues()/promote_ready_dependents() a third time.
        from maestro.core import fleet_runner as _fr
        _order_files = list(_fr._iter_queue_order_files(artefact_dir))
        # queues/review/ is deliberately NOT part of _iter_queue_order_files'
        # set (it is a human-review HOLD directory, not a live dispatch
        # queue — see _find_order_json_file's own docstring), but every file
        # there carries NAV_REVIEW_PENDING (BUG-MSO-2026-0644 F2) and must
        # still count as live work here, so it is scanned as an addition on
        # top of the shared set, not folded into it.
        _review_dir = artefact_dir / "queues" / "review"
        if _review_dir.exists():
            _order_files.extend(_review_dir.glob("*.json"))
        _active_orders_dir = artefact_dir / "orders" / "active"
        if _active_orders_dir.exists():
            _order_files.extend(_active_orders_dir.glob("*.json"))
        for _jf in _order_files:
            try:
                _od = json.loads(_jf.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                continue
            if _od.get("status", "PENDING") not in _LIVE_ORDER_STATUSES:
                continue
            _vid = _od.get("voyageId")
            if _vid:
                reopened_order_voyage_ids.add(_vid)

    def _stale_archive_reason(voyage_id: str) -> Optional[str]:
        """Guard (1): a fresh active-side record, OR a live order still
        naming this voyage, beats a stale complete-side one. Checked per-
        CANDIDATE below (never once per voyage up front) so a legacy home
        with nothing actually in it never produces a spurious refusal entry
        — only a real worktree candidate does."""
        if voyage_id in active_voyage_ids:
            return (
                f"voyages/active/{voyage_id}.json exists — voyage is not "
                "archived, despite a voyages/complete/ record also present "
                "(likely a reopened/retried voyage whose old archive copy was "
                "never cleaned up)"
            )
        if voyage_id in reopened_order_voyage_ids:
            return (
                f"an order whose voyageId is {voyage_id} is back in an "
                "active queue (queues/* or orders/active/) — voyage is "
                "effectively reopened even though mso order retry never "
                "recreates voyages/active/<VID>.json (order_retry.py only "
                "ever rewrites the order file itself)"
            )
        return None

    pruned = 0
    refused: "list[str]" = []
    if active_dir.exists():
        for voyage_dir in active_dir.iterdir():
            if not voyage_dir.is_dir():
                continue
            voyage_id = voyage_dir.name
            if voyage_id not in completed_voyage_ids:
                continue
            # Prune legacy voyage admin worktree
            worktree_path = voyage_dir / ".worktree"
            if worktree_path.exists():
                stale_reason = _stale_archive_reason(voyage_id)
                occupied_reason = None if stale_reason is not None else _admin_worktree_occupied(".worktree")
                if stale_reason is not None:
                    _warn_worktree_prune_refused(voyage_id, "admin (legacy)", stale_reason)
                    refused.append(f"{voyage_id}/admin (legacy): {stale_reason}")
                    # BUG-MSO-2026-0660 (F2): `continue` — not fall-through —
                    # exactly like the unsalvageable branch below. Without it,
                    # this voyage's admin worktree being refused (not
                    # archived / possibly mid-convergence) never stopped the
                    # sibling per-crew loop from still force-removing that
                    # SAME voyage's crew worktrees, and the per-crew loop
                    # recomputes this identical stale_reason again per
                    # candidate, producing duplicate refusal entries for the
                    # one underlying fact.
                    continue
                elif occupied_reason is not None:
                    _warn_worktree_prune_refused(voyage_id, "admin (legacy)", occupied_reason)
                    refused.append(f"{voyage_id}/admin (legacy): {occupied_reason}")
                    # BUG-MSO-2026-0665 (F3): NO `continue` here (unlike the
                    # stale_reason and unsalvageable-dirty branches above/
                    # below). BUG-MSO-2026-0660 (F2) added one, reasoning that
                    # a live/foreign dispatcher possibly mid-convergence "says
                    # nothing crew-specific, so it must hold for the whole
                    # voyage's worktree set" — but `occupied_reason` here comes
                    # from `_admin_worktree_occupied()` ->
                    # `_foreign_live_dispatcher_reason()`, the WORKSPACE-WIDE
                    # "is any dispatcher alive" signal that is true almost
                    # always (the fleet's normal healthy state) — exactly the
                    # signal BUG-MSO-2026-0640/0644 already proved makes crew
                    # worktree pruning permanently inert when applied to crew
                    # candidates, which is why the per-crew loop below uses
                    # the per-worktree `_worktree_busy_reason()` marker
                    # instead. Propagating this `continue` here reinstated
                    # that exact permanently-inert behaviour for the LEGACY
                    # home: it skipped the sibling per-crew loop just below
                    # (both live directly in this same `for voyage_dir`
                    # iteration, so `continue` jumps over it) EVERY time any
                    # dispatcher was running anywhere in the workspace,
                    # meaning legacy-home crew worktrees were never even
                    # evaluated. The admin worktree itself is still correctly
                    # refused (logged above) — only the unrelated sibling
                    # per-crew loop must not be gated by it.
                elif _salvage_worktree_if_dirty(worktree_path, voyage_id, "admin") == "failed":
                    # BUG-MSO-2026-0298 / restored by BUG-MSO-2026-0636 (F6):
                    # `continue` — not `pass` — skips the REST of this
                    # voyage_dir iteration entirely, including the sibling
                    # per-crew loop below. A BUG-MSO-2026-0633 refactor
                    # silently narrowed this to `pass`, which let a legacy
                    # voyage's CLEAN per-crew worktrees be pruned in the same
                    # pass even though its admin worktree could not be
                    # salvaged — the opposite of BUG-0298's "never destroy
                    # unsalvaged work" intent, which left the WHOLE voyage
                    # directory for operator inspection. Reverted: an
                    # unsalvageable admin worktree means an operator needs to
                    # look at this voyage's worktrees as a set, not have the
                    # rest of them quietly disappear underneath the one that
                    # needed attention.
                    #
                    # BUG-MSO-2026-0668 (F3): this `continue` used to bypass
                    # the `refused` accounting entirely, so a tick that held
                    # work back this way reported `outcome=executed, "0
                    # worktree(s) removed"` — indistinguishable from "nothing
                    # was stale" even though this candidate was genuinely
                    # held. Record it exactly like the stale/occupied
                    # refusals above so the LEAD's `worktree.prune` action
                    # surfaces a loud `outcome=refused`, never a silent skip.
                    _salvage_failed_reason = (
                        "worktree has unsalvageable uncommitted changes "
                        "(BUG-0298 salvage failed) — held back, not removed"
                    )
                    _warn_worktree_prune_refused(voyage_id, "admin (legacy)", _salvage_failed_reason)
                    refused.append(f"{voyage_id}/admin (legacy): {_salvage_failed_reason}")
                    continue
                else:
                    # BUG-MSO-2026-0692 (F2): a non-None return means the
                    # worktree is NOT gone - a dangling git registration
                    # survived. Record it; never count it as pruned.
                    _remove_failure = _remove_worktree(
                        worktree_path, _gc, voyage_id, "admin (legacy)")
                    if _remove_failure is not None:
                        refused.append(f"{voyage_id}/admin (legacy): {_remove_failure}")
                    else:
                        pruned += 1
            # BUG-MSO-2026-0240: also prune any lingering per-crew worktrees
            for candidate in voyage_dir.iterdir():
                if candidate.name.startswith(".worktree-crew") and candidate.is_dir():
                    stale_reason = _stale_archive_reason(voyage_id)
                    if stale_reason is not None:
                        _warn_worktree_prune_refused(voyage_id, candidate.name, stale_reason)
                        refused.append(f"{voyage_id}/{candidate.name}: {stale_reason}")
                        continue
                    crew_num = _crew_number_from_worktree_leaf(candidate.name)
                    if crew_num is not None:
                        # BUG-MSO-2026-0640 (F4, superseded by BUG-MSO-2026-0644
                        # F4): a dead crew PID proves only that the CREW is
                        # gone, not that the dispatcher is done with the
                        # worktree it left behind (verify gate/convergence/
                        # salvage run here afterwards). BUG-0640 closed that
                        # gap with the workspace-wide
                        # `_foreign_live_dispatcher_reason()` — "some
                        # dispatcher is alive somewhere" — which refused EVERY
                        # crew worktree in the workspace whenever any
                        # dispatcher was running (the fleet's normal state).
                        # `_worktree_busy_reason()` is the per-worktree
                        # replacement: it only refuses THIS candidate when a
                        # marker names a live process actually using it.
                        occupied_reason = (
                            _crew_worktree_occupied(crew_num, voyage_id)
                            or _worktree_busy_reason(voyage_id, candidate.name)
                        )
                    else:
                        # BUG-MSO-2026-0665 (F4): `candidate.name.startswith(
                        # ".worktree-crew")` above is broader than
                        # `_LEGACY_CREW_WT_RE`'s anchored `^\.worktree-crew
                        # (\d+)$` — e.g. a directory left over from a rename
                        # or a manual experiment — so `crew_num` can be
                        # `None` here. The canonical-home loop below already
                        # has a fallback (`else: _admin_worktree_occupied(...)`)
                        # for exactly this "matched the broad name filter but
                        # has no crew number" case; this loop had none, so
                        # such a directory went straight to force-remove with
                        # ZERO re-validation — the one thing this entire
                        # order family forbids. Match the canonical loop.
                        occupied_reason = _admin_worktree_occupied(candidate.name)
                    if occupied_reason is not None:
                        _warn_worktree_prune_refused(voyage_id, candidate.name, occupied_reason)
                        refused.append(f"{voyage_id}/{candidate.name}: {occupied_reason}")
                        continue
                    if _salvage_worktree_if_dirty(candidate, voyage_id, candidate.name) == "failed":
                        # BUG-MSO-2026-0668 (F3): record this held-back
                        # candidate in `refused` too — see the matching note
                        # on the legacy admin salvage-failed branch above.
                        _salvage_failed_reason = (
                            "worktree has unsalvageable uncommitted changes "
                            "(BUG-0298 salvage failed) — held back, not removed"
                        )
                        _warn_worktree_prune_refused(voyage_id, candidate.name, _salvage_failed_reason)
                        refused.append(f"{voyage_id}/{candidate.name}: {_salvage_failed_reason}")
                        continue  # BUG-0298: skip unsalvageable dirty tree
                    # BUG-MSO-2026-0692 (F2): see the legacy admin branch above.
                    _remove_failure = _remove_worktree(
                        candidate, _gc, voyage_id, candidate.name)
                    if _remove_failure is not None:
                        refused.append(f"{voyage_id}/{candidate.name}: {_remove_failure}")
                    else:
                        pruned += 1

    # FTR-MSO-2026-0364: canonical runtime home — everything under
    # worktrees/<VID>/ (admin, crew*, convergence scratch) goes when the
    # voyage completes.
    wt_root = worktrees_root()
    if wt_root.exists():
        for voyage_home in wt_root.iterdir():
            if not voyage_home.is_dir():
                continue
            voyage_id = voyage_home.name
            if voyage_id not in completed_voyage_ids:
                continue
            for candidate in voyage_home.iterdir():
                if not candidate.is_dir():
                    continue
                stale_reason = _stale_archive_reason(voyage_id)
                if stale_reason is not None:
                    _warn_worktree_prune_refused(voyage_id, candidate.name, stale_reason)
                    refused.append(f"{voyage_id}/{candidate.name}: {stale_reason}")
                    continue
                crew_num = _crew_number_from_worktree_leaf(candidate.name)
                if crew_num is not None:
                    # BUG-MSO-2026-0644 (F4): see the matching comment in the
                    # legacy-home loop above — a dead crew PID does not mean
                    # the dispatcher is done with this worktree, but the
                    # workspace-wide dispatcher-alive check is the wrong tool
                    # for that; `_worktree_busy_reason` is scoped to THIS
                    # candidate specifically.
                    occupied_reason = (
                        _crew_worktree_occupied(crew_num, voyage_id)
                        or _worktree_busy_reason(voyage_id, candidate.name)
                    )
                else:
                    # BUG-MSO-2026-0636 (F3): admin / admin-{repo} /
                    # convergence-* — no crew number to correlate, but not
                    # liveness-free either. See _admin_worktree_occupied.
                    occupied_reason = _admin_worktree_occupied(candidate.name)
                if occupied_reason is not None:
                    _warn_worktree_prune_refused(voyage_id, candidate.name, occupied_reason)
                    refused.append(f"{voyage_id}/{candidate.name}: {occupied_reason}")
                    continue
                if _salvage_worktree_if_dirty(candidate, voyage_id, candidate.name) == "failed":
                    # BUG-MSO-2026-0668 (F3): record this held-back candidate
                    # in `refused` too — see the matching note on the legacy
                    # admin salvage-failed branch above.
                    _salvage_failed_reason = (
                        "worktree has unsalvageable uncommitted changes "
                        "(BUG-0298 salvage failed) — held back, not removed"
                    )
                    _warn_worktree_prune_refused(voyage_id, candidate.name, _salvage_failed_reason)
                    refused.append(f"{voyage_id}/{candidate.name}: {_salvage_failed_reason}")
                    continue  # BUG-0298: skip unsalvageable dirty tree
                # BUG-MSO-2026-0692 (F2): see the legacy admin branch above.
                _remove_failure = _remove_worktree(
                    candidate, _gc, voyage_id, candidate.name)
                if _remove_failure is not None:
                    refused.append(f"{voyage_id}/{candidate.name}: {_remove_failure}")
                else:
                    pruned += 1
            _rmdir_if_empty(voyage_home)

    return WorktreePruneResult(removed=pruned, refused=tuple(refused))


def prune_stale_worktrees(repo_root: Optional[Path] = None) -> int:
    """Back-compat int-returning wrapper around :func:`prune_stale_worktrees_ex`.

    Every pre-existing caller (dispatcher startup) only ever needed the
    removed count; the LEAD's ``worktree.prune`` action (BUG-MSO-2026-0633)
    calls :func:`prune_stale_worktrees_ex` directly instead, so it can log a
    loud ``outcome=refused`` rather than a silent skip when a worktree's
    occupancy check refuses removal.
    """
    return prune_stale_worktrees_ex(repo_root=repo_root).removed


def _salvage_worktree_if_dirty(wt_path, voyage_id: str, label: str) -> str:
    """BUG-MSO-2026-0298 (GKT F4): never force-remove a dirty worktree unsalvaged.

    A voyage can be (falsely or legitimately) archived while a worktree still
    holds uncommitted work — the GKT loss vector was exactly this prune. If the
    tree has tracked modifications, commit them and pin the commit on a
    `salvage/prune-<voyage>-<label>-<sha>` branch before removal.

    Returns "clean" (nothing to save), "salvaged" (branch created), or
    "failed" — and on "failed" the caller must SKIP removal: an unsalvaged
    dirty worktree is never destroyed; the WARN tells the operator where it is.
    """
    try:
        status_r = run_hidden(
            ["git", "status", "--porcelain", "--untracked-files=no"],
            capture_output=True, text=True, cwd=str(wt_path))
        if status_r.returncode != 0 or not status_r.stdout.strip():
            return "clean"
        run_hidden(["git", "add", "-A"], capture_output=True, cwd=str(wt_path))
        commit_r = run_hidden(
            ["git",
             "-c", "user.name=Maestro Salvage",
             "-c", "user.email=salvage@maestro.local",
             "commit", "-m",
             f"salvage: uncommitted work in {label} worktree of {voyage_id} at prune (BUG-0298)"],
            capture_output=True, text=True, cwd=str(wt_path))
        if commit_r.returncode != 0:
            raise RuntimeError(f"salvage commit failed: {commit_r.stderr.strip()[:200]}")
        sha_r = run_hidden(["git", "rev-parse", "--short", "HEAD"],
                               capture_output=True, text=True, cwd=str(wt_path))
        sha = sha_r.stdout.strip() or "unknown"
        branch = f"salvage/prune-{voyage_id}-{label}-{sha}"
        run_hidden(["git", "branch", branch, "HEAD"],
                       capture_output=True, cwd=str(wt_path))
        try:
            from maestro.core.fleet_runner import write_lifecycle_event
            write_lifecycle_event(
                "SALVAGE",
                f"{voyage_id}: dirty {label} worktree preserved on {branch} "
                f"before prune (BUG-0298)")
        except Exception:
            pass
        return "salvaged"
    except Exception as exc:
        try:
            from maestro.core.fleet_runner import write_lifecycle_event
            write_lifecycle_event(
                "WARN",
                f"{voyage_id}: prune salvage of {label} worktree FAILED ({exc}) — "
                f"worktree LEFT IN PLACE at {wt_path}; inspect and salvage manually (BUG-0298)")
        except Exception:
            pass
        return "failed"
