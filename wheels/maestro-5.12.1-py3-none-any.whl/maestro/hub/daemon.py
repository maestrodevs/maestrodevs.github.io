# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Hub daemon PID management (mirrors maestro/bridge.py pattern exactly).

The hub is a GLOBAL daemon (not per-workspace) — PID file at ~/.maestro/hub.pid.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import time
import webbrowser
from pathlib import Path

# FTR-MSO-2026-0536 promoted this to maestro/proc_identity.py so the LEAD
# daemon and the Hub daemon share ONE identity implementation. Imported
# under the original private name so existing tests that monkeypatch
# `daemon._process_create_time` keep working unchanged.
from maestro.proc_identity import (
    process_create_time as _process_create_time,
    read_identity_record as _read_record,
    write_identity_record as _write_record,
)
from typing import Optional, Tuple

from maestro.launch.sandbox import spawn as _spawn
from maestro.workspace import get_maestro_home

DEFAULT_PORT = 3847


def _hub_pid_file() -> Path:
    """Global Hub PID file, resolved live so MAESTRO_HOME redirects it
    (BUG-MSO-2026-0387). Default ``~/.maestro/hub.pid``."""
    return get_maestro_home() / "hub.pid"


# ---------------------------------------------------------------------------
# Process-identity helpers (BUG-MSO-2026-0424)
#
# A bare PID is NOT a stable process identity — operating systems recycle PIDs,
# so after the hub dies uncleanly the recorded number can be reassigned to
# unrelated software. We therefore record the process CREATION TIME alongside
# the PID and treat a record as "our hub" only when a process with that PID
# exists AND its creation time matches. A recycled PID always has a later start
# time, so the check is decisive and needs no third-party dependency.
# ---------------------------------------------------------------------------

def _read_pid(pid_file: Path) -> Optional[int]:
    """Backwards-compatible PID accessor (identity NOT verified)."""
    rec = _read_record(pid_file)
    return rec[0] if rec else None


def _is_process_alive(pid: int) -> bool:
    """Bare liveness — does SOME process hold *pid*? Kept for callers that only
    need existence; the hub lifecycle uses :func:`_is_hub_running` instead,
    which also verifies process identity."""
    return _process_create_time(pid) is not None


def _is_hub_running(pid_file: Path) -> Tuple[bool, Optional[int]]:
    """Identity-verified hub liveness.

    Returns ``(running, pid)``. ``running`` is ``True`` only when the recorded
    PID belongs to a live process whose creation time matches the recorded
    identity. A recycled PID (same number, different — later — process) or a
    legacy record with no recorded identity is classified as NOT running, so no
    termination signal is ever sent to an unrelated process.
    """
    rec = _read_record(pid_file)
    if rec is None:
        return (False, None)
    pid, recorded_ct = rec
    if not pid or pid <= 0 or recorded_ct is None:
        return (False, pid or None)
    current_ct = _process_create_time(pid)
    if current_ct is None or current_ct != recorded_ct:
        return (False, pid)
    return (True, pid)


# ---------------------------------------------------------------------------
# Dep check
# ---------------------------------------------------------------------------

def _ensure_hub_deps() -> None:
    try:
        import fastapi  # noqa: F401
        import uvicorn  # noqa: F401
    except ImportError:
        print(
            "[Hub] FastAPI/uvicorn not installed.\n"
            "      Install the hub extra:  pip install 'maestro-fleet[hub]'",
            file=sys.stderr,
        )
        sys.exit(1)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def _hub_entry_point() -> Path:
    """Absolute path to ``maestro/hub/__main__.py`` (BUG-MSO-2026-0516).

    ``python -m maestro.hub`` puts the SUBPROCESS'S OWN cwd at ``sys.path[0]``.
    Since the single most likely place an operator runs ``mso hub start`` from
    is a Maestro source checkout, that checkout's own (bundle-less) ``maestro/``
    package silently shadows the installed wheel — the daemon comes up
    correctly, but serving from the wrong package tree, with no built UI
    bundle to mount, so it degrades to the API-only payload while looking
    identical to the real thing.

    Launching by this RESOLVED FILE PATH instead sidesteps the trap entirely:
    running ``python <script>.py`` puts the script's own directory at
    ``sys.path[0]``, never the cwd. Because that directory is derived from
    ``__file__`` of THIS already-imported module — the same import that
    resolved the currently-running ``mso`` process's own ``maestro`` package —
    the spawned daemon is guaranteed to import that exact same package,
    regardless of what the operator's cwd happens to be. This makes cwd
    irrelevant to package resolution rather than merely picking a "safer" cwd
    (a plain ``cwd=`` override would still leave any *other* cwd-sensitive
    code path — see the sibling BUG-MSO-2026-0515 — exposed).
    """
    return Path(__file__).resolve().parent / "__main__.py"


def start_hub(port: int = DEFAULT_PORT, open_browser: bool = False, force: bool = False) -> None:
    hub_pid = _hub_pid_file()
    running, existing_pid = _is_hub_running(hub_pid)
    if running and not force:
        print(f"[Hub] Already running (PID: {existing_pid}) on http://127.0.0.1:{port}")
        if open_browser:
            webbrowser.open(f"http://127.0.0.1:{port}")
        return
    if not running and hub_pid.exists():
        # Stale / recycled-PID / legacy record — clear it and start clean.
        # NB: no signal is ever sent here; the old PID may now belong to
        # unrelated software (BUG-MSO-2026-0424).
        hub_pid.unlink()

    _ensure_hub_deps()

    cmd = [sys.executable, str(_hub_entry_point()), "--port", str(port)]
    hub_pid.parent.mkdir(parents=True, exist_ok=True)

    if os.name == "nt":
        DETACHED_PROCESS = 0x00000008
        CREATE_NEW_PROCESS_GROUP = 0x00000200
        flags = DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
        proc = _spawn(
            cmd,
            identity="hub",
            creationflags=flags,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    else:
        proc = _spawn(
            cmd,
            identity="hub",
            start_new_session=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

    _write_record(hub_pid, proc.pid, _process_create_time(proc.pid))
    print(f"[Hub] Started on http://127.0.0.1:{port} (PID {proc.pid})")
    if open_browser:
        webbrowser.open(f"http://127.0.0.1:{port}")


def stop_hub(*, timeout: float = 10.0, poll_interval: float = 0.5) -> bool:
    """Stop the Hub daemon and BLOCK until it has actually exited.

    BUG-MSO-2026-0516: the previous implementation printed "Stop signal sent"
    on the strength of having SENT a signal — never confirming the process
    actually died — so ``mso hub stop`` could report success while the daemon
    (and its hold on the port) lived on. This version waits for the
    identity-verified record to go not-running, escalates to a force-kill if
    the graceful signal doesn't land within ``timeout`` seconds, and returns
    ``False`` (with a truthful failure message) if the process still could not
    be stopped — "signal sent" is never printed as though it meant "stopped".

    Returns ``True`` once the daemon is confirmed gone (or was never running).
    """
    hub_pid = _hub_pid_file()
    running, pid = _is_hub_running(hub_pid)
    if not running:
        # Not our hub (dead, recycled PID, or legacy record). Send NO signal —
        # the recorded PID may now belong to unrelated software
        # (BUG-MSO-2026-0424) — and always clear the stale record.
        print("[Hub] Not running")
        if hub_pid.exists():
            hub_pid.unlink()
        return True

    def _signal(force: bool) -> None:
        try:
            if os.name == "nt":
                cmd = ["taskkill", "/PID", str(pid)]
                if force:
                    cmd.append("/F")
                subprocess.run(cmd, capture_output=True, timeout=10)
            else:
                os.kill(pid, 9 if force else 15)  # SIGKILL : SIGTERM
        except Exception as exc:
            kind = "force-kill" if force else "stop"
            print(f"[Hub] Failed to send {kind} signal: {exc}", file=sys.stderr)

    def _wait_for_exit(budget_seconds: float) -> bool:
        iterations = max(1, int(budget_seconds / poll_interval))
        for _ in range(iterations):
            if not _is_hub_running(hub_pid)[0]:
                return True
            time.sleep(poll_interval)
        return not _is_hub_running(hub_pid)[0]

    def _confirm_stopped(note: str = "") -> bool:
        if hub_pid.exists():
            hub_pid.unlink()
        print(f"[Hub] Stopped (PID: {pid}){note}")
        return True

    _signal(force=False)
    if _wait_for_exit(timeout):
        return _confirm_stopped()

    print(
        f"[Hub] PID {pid} still running after {timeout:.0f}s — escalating to force-kill",
        file=sys.stderr,
    )
    _signal(force=True)
    if _wait_for_exit(5.0):
        return _confirm_stopped(", required force-kill")

    print(
        f"[Hub] Failed to stop (PID: {pid} still running after stop signal + force-kill)",
        file=sys.stderr,
    )
    return False


def _installed_version() -> Optional[str]:
    """This reader's own fresh import — used ONLY as a fallback when the
    live Hub process can't be reached to ask it about itself (see
    ``hub_status`` below). Mirrors ``maestro.lead.daemon._installed_version``.
    """
    try:
        import maestro
        return getattr(maestro, "__version__", None)
    except Exception:
        return None


def _fetch_health(port: int, timeout: float = 2.0) -> Optional[dict]:
    """Best-effort GET of the running Hub's own /api/v1/health.

    BUG-MSO-2026-0627: `/api/v1/health` is exempt from the bearer-token gate
    (see `hub/server.py`'s auth guard — `/health` and `/ping` stay open for
    liveness probes), so no token handling is needed here. The health
    response already carries `version` (this process's pinned code version)
    and `installedVersion`/`versionMismatch` (a live self-check computed
    fresh on every call via `importlib.metadata`, so it reflects a `pip
    install --upgrade` done after this daemon started, without needing a
    restart) — `hub_status()` below just relays what the live process
    already knows about itself. Returns ``None`` on any failure (backend not
    responding on this port, connection refused, timeout, bad JSON): a
    version-unknown Hub is reported honestly, never guessed.
    """
    import json as _json
    import urllib.request

    try:
        with urllib.request.urlopen(
            f"http://127.0.0.1:{port}/api/v1/health", timeout=timeout
        ) as resp:
            return _json.loads(resp.read().decode("utf-8"))
    except Exception:
        return None


def hub_status(port: int = DEFAULT_PORT) -> dict:
    running, pid = _is_hub_running(_hub_pid_file())
    health = _fetch_health(port) if running else None
    if health:
        running_version = health.get("version")
        installed_version = health.get("installedVersion") or _installed_version()
        version_mismatch = bool(health.get("versionMismatch"))
    else:
        # Backend unreachable (wrong port, unresponsive, or genuinely not
        # running) — report what we honestly know: nothing about the running
        # process, only this reader's own fresh import as a best-effort
        # installed-version hint.
        running_version = None
        installed_version = _installed_version()
        version_mismatch = False
    return {
        "running": running,
        "pid": pid if running else None,
        "port": port,
        "runningVersion": running_version,
        "installedVersion": installed_version,
        "versionMismatch": version_mismatch,
    }


def print_status(port: int = DEFAULT_PORT) -> None:
    s = hub_status(port=port)
    print("\n  MAESTRO HUB — STATUS")
    print("  " + "-" * 40)
    if s["running"]:
        print(f"  Status:  RUNNING (PID: {s['pid']})")
        print(f"  URL:     http://127.0.0.1:{s['port']}")
        version_line = f"  Running version: {s.get('runningVersion') or '(unknown — health check unreachable)'}"
        if s.get("versionMismatch"):
            version_line += f"  [STALE — installed is {s.get('installedVersion')}]"
        print(version_line)
    else:
        print("  Status:  STOPPED")
    print("  " + "-" * 40)
    print()
