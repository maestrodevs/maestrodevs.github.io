#!/usr/bin/env python3
"""
Fleet PostToolUse Hook v8.1 — Activity Tracking, Heartbeat, and File Counter.

Combined PostToolUse hook that fires after every tool call for crew sessions.
Provides real-time visibility into what each crew is doing.

Three responsibilities:
  1. HEARTBEAT — writes ISO timestamp to heartbeat.txt on every tool call
  2. ACTIVITY — writes human-readable text to activity.txt + appends to activity.jsonl
  3. FILE COUNTER — tracks unique files modified in files_modified.json, updates state.json

IMPORTANT: This hook ONLY activates for crew sessions (MAESTRO_CREW env set).
The Captain's interactive sessions are NEVER affected.

Input:  JSON on stdin (from Claude Code hook system)
Output: Exit 0 always (observation-only, never blocks)
"""

import json
import os
import sys
from datetime import datetime
from pathlib import Path


def write_atomic(file_path: Path, content: str):
    """Write file atomically (write to temp, rename)."""
    tmp_path = file_path.with_suffix('.tmp')
    try:
        tmp_path.write_text(content, encoding='utf-8')
        tmp_path.replace(file_path)
    except Exception:
        try:
            file_path.write_text(content, encoding='utf-8')
        except Exception:
            pass


def extract_display_info(tool_name: str, tool_input: dict) -> tuple:
    """Extract human-readable action and target from tool call.

    Returns (action, target) tuple for activity display.
    """
    if tool_name in ("Edit", "MultiEdit"):
        file_path = tool_input.get("file_path") or tool_input.get("filePath") or ""
        return "Edited", Path(file_path).name if file_path else "file"

    if tool_name == "Write":
        file_path = tool_input.get("file_path") or tool_input.get("filePath") or ""
        return "Created", Path(file_path).name if file_path else "file"

    if tool_name == "Read":
        file_path = tool_input.get("file_path") or tool_input.get("filePath") or ""
        return "Read", Path(file_path).name if file_path else "file"

    if tool_name == "Bash":
        command = tool_input.get("command", "")
        # Truncate long commands, show first meaningful part
        cmd_display = command.strip()[:60]
        if len(command.strip()) > 60:
            cmd_display += "..."
        return "Ran", cmd_display

    if tool_name == "Grep":
        pattern = tool_input.get("pattern", "")
        return "Searched", pattern[:40] if pattern else "code"

    if tool_name == "Glob":
        pattern = tool_input.get("pattern", "")
        return "Found files", pattern[:40] if pattern else "pattern"

    if tool_name == "Task":
        desc = tool_input.get("description", "")
        return "Launched", desc[:40] if desc else "subagent"

    return "Used", tool_name


def get_file_path(tool_name: str, tool_input: dict) -> str:
    """Extract the file path from a write tool call (for file counting)."""
    if tool_name in ("Edit", "MultiEdit", "Write"):
        return tool_input.get("file_path") or tool_input.get("filePath") or ""
    return ""


def main():
    try:
        # ===================================================================
        # STEP 1: Read hook input from stdin
        # ===================================================================
        raw_input = sys.stdin.read()
        hook_input = json.loads(raw_input) if raw_input.strip() else {}
    except Exception:
        sys.exit(0)

    # ===================================================================
    # STEP 2: Check if this is a crew session
    # ===================================================================
    crew_str = os.environ.get("MAESTRO_CREW")
    if not crew_str:
        sys.exit(0)  # Captain's session — never interfere

    try:
        crew_number = int(crew_str)
    except ValueError:
        sys.exit(0)

    # ===================================================================
    # STEP 3: Resolve crew directory
    # ===================================================================
    cwd = hook_input.get("cwd", os.getcwd())
    from maestro.hooks import find_mso_root
    workspace = find_mso_root(cwd)
    if workspace is None:
        sys.exit(0)  # Not an Admiralty workspace — no-op
    from maestro.workspace import resolve_artefact_dir
    mso_root = resolve_artefact_dir(workspace)
    crew_dir = mso_root / "crews" / f"crew{crew_number}"
    if not crew_dir.exists():
        crew_dir.mkdir(parents=True, exist_ok=True)

    tool_name = hook_input.get("tool_name", "")
    tool_input = hook_input.get("tool_input", {})
    now = datetime.now()

    # ===================================================================
    # STEP 4: HEARTBEAT — update on every tool call
    # ===================================================================
    heartbeat_file = crew_dir / "heartbeat.txt"
    write_atomic(heartbeat_file, now.isoformat())

    # ===================================================================
    # STEP 5: ACTIVITY TRACKER
    # ===================================================================
    action, target = extract_display_info(tool_name, tool_input)
    activity_text = f"{action} {target}"

    # Write simple activity.txt for fast monitor reads
    write_atomic(crew_dir / "activity.txt", activity_text)

    # Append structured entry to activity.jsonl
    entry = {
        "timestamp": now.isoformat(),
        "tool": tool_name,
        "action": action,
        "target": target
    }
    try:
        with open(crew_dir / "activity.jsonl", "a", encoding="utf-8") as f:
            f.write(json.dumps(entry) + "\n")
    except Exception:
        pass

    # ===================================================================
    # STEP 6: FILE COUNTER (Edit/Write/MultiEdit only)
    # ===================================================================
    file_path = get_file_path(tool_name, tool_input)
    if file_path:
        files_set_path = crew_dir / "files_modified.json"
        state_file = crew_dir / "state.json"

        # Load existing set of modified files
        files_set = set()
        if files_set_path.exists():
            try:
                files_set = set(json.loads(files_set_path.read_text(encoding='utf-8')))
            except Exception:
                files_set = set()

        # Add new file path (normalized)
        norm_path = file_path.replace("\\", "/")
        if norm_path not in files_set:
            files_set.add(norm_path)
            write_atomic(files_set_path, json.dumps(sorted(files_set)))

        # Update filesChangedTotal in state.json
        if state_file.exists():
            try:
                state = json.loads(state_file.read_text(encoding='utf-8'))
                state["filesChangedTotal"] = len(files_set)
                write_atomic(state_file, json.dumps(state, indent=2))
            except Exception:
                pass

    # ===================================================================
    # STEP 7: OWASP SECURITY SCANNER (LKT role only)
    # ===================================================================
    role = os.environ.get("MAESTRO_ROLE", "")
    if role == "LKT" and file_path:
        _run_owasp_scan(file_path, crew_dir, mso_root)

    sys.exit(0)


def _run_owasp_scan(file_path: str, crew_dir: Path, mso_root: Path) -> None:
    """Scan a modified file for OWASP/CWE vulnerabilities and append findings to the security report.

    Activates only when MAESTRO_ROLE=LKT. Writes SEC-{ORDER-ID}.json and .md.
    Fail-open: any exception is silently swallowed so crew work is never blocked.
    """
    import signal
    import threading

    order_id = os.environ.get("MAESTRO_ORDER", "UNKNOWN")

    try:
        from maestro.security.owasp_patterns import OWASPScanner
    except ImportError:
        return  # Scanner not available — fail-open

    # Only scan Python source files
    if not file_path.endswith(".py"):
        return

    from pathlib import Path as _Path
    abs_path = _Path(file_path)
    if not abs_path.exists():
        return

    # Run scan with a 30-second cap using a thread timeout
    findings = []

    def _do_scan():
        try:
            scanner = OWASPScanner(language="python")
            findings.extend(scanner.scan_file(str(abs_path)))
        except Exception:
            pass  # Fail-open: scanner crashes must not break the pipeline

    t = threading.Thread(target=_do_scan, daemon=True)
    t.start()
    t.join(timeout=30)
    if t.is_alive():
        return  # Timeout — fail-open

    if not findings:
        return

    # Resolve report paths
    reports_dir = mso_root / "reports" / "security"
    reports_dir.mkdir(parents=True, exist_ok=True)
    json_report = reports_dir / f"SEC-{order_id}.json"
    md_report = reports_dir / f"SEC-{order_id}.md"

    # Load, merge, and write reports. Wrap the whole block in a broad try/except
    # so that a malformed pre-existing report (or any unexpected I/O failure) cannot
    # break the posttool hook — fail-open is the contract.
    try:
        report = {}
        if json_report.exists():
            try:
                loaded = json.loads(json_report.read_text(encoding="utf-8"))
            except Exception:
                loaded = None
            # Defend against structurally-valid-but-unexpected JSON (e.g. a list).
            if isinstance(loaded, dict) and isinstance(loaded.get("findings"), list) and isinstance(loaded.get("summary"), dict):
                report = loaded

        if not report:
            report = {
                "orderId": order_id,
                "generatedAt": datetime.now().isoformat(),
                "findings": [],
                "summary": {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0, "INFO": 0},
            }

        # Merge new findings (deduplicate by id+file+line)
        existing_keys = {
            (f["id"], f["file"], f["line"]) for f in report.get("findings", [])
        }
        for finding in findings:
            key = (finding.id, finding.file, finding.line)
            if key not in existing_keys:
                report["findings"].append(finding.to_dict())
                sev = finding.severity.value
                report["summary"][sev] = report["summary"].get(sev, 0) + 1
                existing_keys.add(key)

        report["updatedAt"] = datetime.now().isoformat()
        write_atomic(json_report, json.dumps(report, indent=2))
        _write_md_report(md_report, report)
    except Exception:
        return  # Fail-open


def _write_md_report(md_path: Path, report: dict) -> None:
    """Write a human-readable Markdown security report from the JSON report data."""
    order_id = report.get("orderId", "UNKNOWN")
    summary = report.get("summary", {})
    findings = report.get("findings", [])
    updated = report.get("updatedAt", report.get("generatedAt", ""))[:19].replace("T", " ")

    lines = [
        f"# Security Report — {order_id}",
        f"",
        f"**Last updated:** {updated}  ",
        f"**Findings:** {len(findings)}",
        f"",
        f"## Summary",
        f"",
        f"| Severity | Count |",
        f"|----------|-------|",
    ]
    for sev in ("CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"):
        count = summary.get(sev, 0)
        if count:
            lines.append(f"| {sev} | {count} |")

    if findings:
        lines += ["", "## Findings", ""]
        for i, f in enumerate(findings, 1):
            waiver_note = ""
            if f.get("waived"):
                waiver_note = f" *(waived: {f.get('waiverReason', '')})*"
            lines += [
                f"### {i}. [{f['severity']}] {f['title']}{waiver_note}",
                f"- **CWE:** {f['cwe']}",
                f"- **File:** `{f['file']}` line {f['line']}",
                f"- **Snippet:** `{f['snippet']}`",
                f"- **Remediation:** {f['remediation']}",
                f"",
            ]

    try:
        write_atomic(md_path, "\n".join(lines) + "\n")
    except Exception:
        pass


if __name__ == "__main__":
    try:
        main()
    except Exception:
        sys.exit(0)  # Fail-open: never block crew work
