# maestro.hooks — Claude Code hooks

from pathlib import Path


def find_mso_root(start_dir: str) -> "Path | None":
    """Walk up from start_dir to find a Maestro workspace root.

    Checks ``.mso/config/`` (v4.0).
    ``.maestro/config/`` (v1.x). Returns the workspace root, or None.
    """
    path = Path(start_dir).resolve()
    for p in [path, *path.parents]:
        for name in (".mso",):
            if (p / name / "config").is_dir():
                return p
    return None
