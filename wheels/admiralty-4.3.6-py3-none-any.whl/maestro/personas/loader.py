"""JSON loader for Maestro persona configs with schema validation."""

import json
import logging
from pathlib import Path
from typing import Union

import jsonschema

from .models import Persona, PersonaSchemaError

logger = logging.getLogger(__name__)

_SCHEMA_PATH = Path(__file__).parent / "_schema.json"
_BUILTIN_DIR = Path(__file__).parent

_schema: dict = None


def _get_schema() -> dict:
    global _schema
    if _schema is None:
        _schema = json.loads(_SCHEMA_PATH.read_text(encoding="utf-8"))
    return _schema


def load_persona_from_dict(data: dict, source: str = "<dict>") -> "Persona":
    """Validate *data* against the persona schema and return a Persona instance."""
    try:
        jsonschema.validate(data, _get_schema())
    except jsonschema.ValidationError as exc:
        raise PersonaSchemaError(
            f"Persona schema validation failed ({source}): {exc.message}"
        ) from exc
    return Persona(
        id=data["id"],
        display_name=data["displayName"],
        vocabulary=data["vocabulary"],
        role_display=data["roleDisplay"],
        squad_names_list=data.get("squadNames", [f"Squad {i}" for i in range(1, 6)]),
        output_templates=data.get("outputTemplates", {}),
    )


def load_persona_from_file(path: Union[str, Path]) -> "Persona":
    """Load and validate a persona JSON file. Raises PersonaSchemaError on failure."""
    path = Path(path)
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise PersonaSchemaError(f"Malformed JSON in {path}: {exc}") from exc
    return load_persona_from_dict(data, source=str(path))


def load_builtin(name: str) -> "Persona":
    """Load a built-in persona by id. Raises PersonaSchemaError if not found/invalid."""
    persona_path = _BUILTIN_DIR / name / "persona.json"
    if not persona_path.exists():
        raise PersonaSchemaError(f"Built-in persona '{name}' not found at {persona_path}")
    return load_persona_from_file(persona_path)


def builtin_names() -> list:
    """Return the list of available built-in persona ids."""
    return sorted(
        d.name
        for d in _BUILTIN_DIR.iterdir()
        if d.is_dir() and (d / "persona.json").exists()
    )
