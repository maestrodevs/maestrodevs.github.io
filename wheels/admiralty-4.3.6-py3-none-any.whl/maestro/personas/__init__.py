"""maestro.personas — public surface for persona loading and resolution."""

from .loader import PersonaSchemaError, load_builtin, load_persona_from_dict, load_persona_from_file
from .models import Persona
from .resolver import reset as reset_persona_cache
from .resolver import resolve


def current_persona() -> Persona:
    """Return the active Persona following the 4-step resolution order."""
    return resolve()


def load_persona(name: str) -> Persona:
    """Load a built-in persona by id."""
    return load_builtin(name)


__all__ = [
    "Persona",
    "PersonaSchemaError",
    "current_persona",
    "load_persona",
    "load_persona_from_dict",
    "load_persona_from_file",
    "reset_persona_cache",
]
