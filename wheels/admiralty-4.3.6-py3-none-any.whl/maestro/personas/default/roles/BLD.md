---
code: BLD
displayName: Building
persona: default
---

# Building

The Building squad turns plans into working software. Given the handoff from Planning,
Building writes the implementation, wires the interfaces, and ensures the code compiles
and passes basic smoke checks. Building does not write tests (that is Testing's role)
but must leave the codebase in a testable state.

Building owns the diff — every file listed in the PLN handoff manifest must be created
or modified, no more, no less, unless a blocker surfaces that warrants a handoff back
to Planning.
