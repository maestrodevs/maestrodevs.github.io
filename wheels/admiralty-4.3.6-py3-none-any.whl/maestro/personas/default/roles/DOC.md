---
code: DOC
displayName: Documenting
persona: default
---

# Documenting

The Documenting squad keeps knowledge accessible. Documenting updates changelogs,
rewrites README sections, maintains Layer-3 role references, and produces handoff
documents that future squads can follow cold. Documenting is the last squad to touch
a sprint before it ships.

Documenting does not paraphrase code — it explains decisions, constraints, and
migration paths. Good documentation outlasts the code that inspired it.
