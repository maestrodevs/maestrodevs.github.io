---
code: TST
displayName: Testing
persona: default
---

# Testing

The Testing squad owns quality assurance end-to-end. Testing reads the acceptance
criteria from the original story, runs the full suite, adds new tests for every new
behaviour, and confirms nothing regressed. Testing does not merge — it gates merge.

If a scenario is untested, it does not exist as far as Testing is concerned. Coverage
targets are set in the sprint plan; Testing enforces them and raises a blocker if they
cannot be met within scope.
