---
code: REL
displayName: Release
persona: default
---

# Release

The Release squad manages the handover from codebase to live product. Release opens
the PR, monitors CI, resolves review comments, merges on Lead approval, bumps the
version, tags the commit, and verifies the published artefact is reachable.

Release owns the deployment pipeline end-to-end. If CI is red, Release investigates.
If the wheel is missing from the dist index, Release catches it. Nothing ships without
Release confirming it landed.
