"""
OWASP/CWE Pattern Scanner for Static Analysis

Implements detection patterns for 8 OWASP/CWE vulnerability categories:
1. SQL Injection (CWE-89)
2. XSS (CWE-79)
3. Path Traversal (CWE-22)
4. Hardcoded Credentials (CWE-798)
5. Insecure Deserialization (CWE-502)
6. Command Injection (CWE-78)
7. Weak Cryptography (CWE-327/330)
8. Missing Auth Decorators (CWE-306)

Severity levels: INFO, LOW, MEDIUM, HIGH, CRITICAL
Languages: Python (implemented); JS/TS/C# (future)
"""

import ast
import re
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Optional, List


class Severity(str, Enum):
    """Severity levels for findings."""
    INFO = "INFO"
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


@dataclass
class OwaspPattern:
    """Schema for an OWASP vulnerability pattern."""
    id: str
    cwe: str
    owasp_category: str
    title: str
    severity: Severity
    languages: List[str]
    description: str
    regex: List[str]
    # Reserved for future AST-based checks. Currently unused — `scan_file()` is
    # regex-only. When AST integration ships, this string will name a checker in
    # _AST_CHECKERS and be invoked alongside the regex pass.
    ast_check: Optional[str] = None
    remediation: str = ""
    references: List[str] = field(default_factory=list)
    false_positive_notes: str = ""


@dataclass
class Finding:
    """A security finding from pattern matching."""
    id: str
    cwe: str
    owasp_category: str
    title: str
    severity: Severity
    file: str
    line: int
    column: int
    snippet: str
    remediation: str
    base_severity: Severity = field(init=False)
    adjusted_severity: Severity = field(init=False)
    waived: bool = False
    waiver_reason: Optional[str] = None

    def __post_init__(self):
        self.base_severity = self.severity
        self.adjusted_severity = self.severity

    def to_dict(self):
        """Convert to JSON-serializable dict."""
        return {
            "id": self.id,
            "cwe": self.cwe,
            "owaspCategory": self.owasp_category,
            "title": self.title,
            "severity": self.severity.value,
            "baseSeverity": self.base_severity.value,
            "adjustedSeverity": self.adjusted_severity.value,
            "file": self.file,
            "line": self.line,
            "column": self.column,
            "snippet": self.snippet,
            "remediation": self.remediation,
            "waived": self.waived,
            "waiverReason": self.waiver_reason,
        }


# ==============================================================================
# BUILTIN CREDENTIAL STUBS (fallback for VOY-0022 secret_patterns.py)
# ==============================================================================

_BUILTIN_CREDENTIAL_STUBS = [
    OwaspPattern(
        id="OWASP-A07-CRED-001",
        cwe="CWE-798",
        owasp_category="A07:2021 Identification and Authentication Failures",
        title="Hardcoded password variable",
        severity=Severity.CRITICAL,
        languages=["python"],
        description="Variable assigned with string literal that appears to be a password",
        regex=[
            r"(?i)(password|passwd|pwd)\s*=\s*['\"][\w\W]{1,}\b['\"]",
        ],
        remediation="Move credentials to environment variables or secure secrets store",
        false_positive_notes="May match test fixtures; review context",
    ),
    OwaspPattern(
        id="OWASP-A07-CRED-002",
        cwe="CWE-798",
        owasp_category="A07:2021 Identification and Authentication Failures",
        title="Hardcoded API key or token",
        severity=Severity.CRITICAL,
        languages=["python"],
        description="Variable assigned with string literal that appears to be an API key or token",
        regex=[
            r"(?i)(api_?key|apikey|token|secret|auth_?token)\s*=\s*['\"][\w\W]{10,}['\"]",
        ],
        remediation="Move credentials to environment variables or secure secrets store",
        false_positive_notes="May match test fixtures; review context",
    ),
    OwaspPattern(
        id="OWASP-A07-CRED-003",
        cwe="CWE-798",
        owasp_category="A07:2021 Identification and Authentication Failures",
        title="Hardcoded connection string",
        severity=Severity.HIGH,
        languages=["python"],
        description="Likely database or service connection string with credentials embedded",
        regex=[
            r"(?i)(database_?url|db_?url|connection_?string|connection_str)\s*=\s*['\"][^'\"]*://[^@]+@",
        ],
        remediation="Move connection strings to environment variables or configuration files",
        false_positive_notes="Common in test and local development configs",
    ),
]


# ==============================================================================
# PATTERN DEFINITIONS (All 8 Categories)
# ==============================================================================

_PATTERNS = [
    # ========== Category 1: SQL Injection (CWE-89, OWASP A03) ==========
    OwaspPattern(
        id="OWASP-A03-SQL-001",
        cwe="CWE-89",
        owasp_category="A03:2021 Injection",
        title="SQL Injection via string concatenation",
        severity=Severity.HIGH,
        languages=["python"],
        description="String concatenation or f-string used inside .execute() or similar DB call",
        regex=[
            r"\.execute\s*\(\s*['\"].*['\\\"].*\s*\+",
            r"\.execute\s*\(\s*f['\"]",
            r"\.raw\s*\(\s*['\"].*['\\\"].*\s*\+",
            r"\.raw\s*\(\s*f['\"]",
            r"cursor\.execute\s*\(\s*['\"].*['\\\"].*\s*\+",
            r"cursor\.execute\s*\(\s*f['\"]",
        ],
        ast_check="check_sql_injection",
        remediation="Use parameterised queries with bound parameters",
        references=["https://cheatsheetseries.owasp.org/cheatsheets/SQL_Injection_Prevention_Cheat_Sheet.html"],
    ),
    OwaspPattern(
        id="OWASP-A03-SQL-002",
        cwe="CWE-89",
        owasp_category="A03:2021 Injection",
        title="SQL Injection via string formatting",
        severity=Severity.HIGH,
        languages=["python"],
        description=".format() or % operator applied to a SQL string literal",
        regex=[
            r"['\"]SELECT\s.*['\"]\.format\s*\(",
            r"['\"]INSERT\s.*['\"]\.format\s*\(",
            r"['\"]UPDATE\s.*['\"]\.format\s*\(",
            r"['\"]DELETE\s.*['\"]\.format\s*\(",
            r"['\"]SELECT\s.*['\"](\s*%\s*\()",
        ],
        remediation="Use parameterised queries instead of string formatting",
        references=["https://cheatsheetseries.owasp.org/cheatsheets/SQL_Injection_Prevention_Cheat_Sheet.html"],
    ),

    # ========== Category 2: XSS (CWE-79, OWASP A03) ==========
    OwaspPattern(
        id="OWASP-A03-XSS-001",
        cwe="CWE-79",
        owasp_category="A03:2021 Injection",
        title="Unsafe HTML mark_safe with variable",
        severity=Severity.HIGH,
        languages=["python"],
        description="mark_safe() or Markup() wrapping a variable (not a string literal)",
        regex=[
            r"(?:mark_safe|Markup)\s*\(\s*(?![\'\"])[a-zA-Z_]",
        ],
        remediation="Ensure all user input is escaped before passing to mark_safe/Markup, or use auto-escaping",
        references=["https://cheatsheetseries.owasp.org/cheatsheets/Cross_Site_Scripting_Prevention_Cheat_Sheet.html"],
    ),
    OwaspPattern(
        id="OWASP-A03-XSS-002",
        cwe="CWE-79",
        owasp_category="A03:2021 Injection",
        title="Template rendering with user-controlled string",
        severity=Severity.HIGH,
        languages=["python"],
        description="render_template_string() with a variable argument (not hardcoded template)",
        regex=[
            r"render_template_string\s*\(\s*(?![\'\"])[a-zA-Z_]",
        ],
        remediation="Use render_template with a template file instead, or use auto-escaping",
        references=["https://cheatsheetseries.owasp.org/cheatsheets/Cross_Site_Scripting_Prevention_Cheat_Sheet.html"],
    ),
    OwaspPattern(
        id="OWASP-A03-XSS-003",
        cwe="CWE-79",
        owasp_category="A03:2021 Injection",
        title="Unescaped output in Jinja/Mako template",
        severity=Severity.MEDIUM,
        languages=["python"],
        description="innerHTML assignment or .write() in Jinja/Mako without |e filter",
        regex=[
            r"innerHTML\s*=\s*\{\{\s*[^|]*\s*\}\}",
            r"\.write\s*\(\s*\{\{\s*[^|]*\s*\}\}",
        ],
        remediation="Use the |e (escape) filter in templates: {{ var|e }}",
        references=["https://cheatsheetseries.owasp.org/cheatsheets/Cross_Site_Scripting_Prevention_Cheat_Sheet.html"],
    ),

    # ========== Category 3: Path Traversal (CWE-22, OWASP A01) ==========
    OwaspPattern(
        id="OWASP-A01-PATH-001",
        cwe="CWE-22",
        owasp_category="A01:2021 Broken Access Control",
        title="User input passed to file operations",
        severity=Severity.HIGH,
        languages=["python"],
        description="User-controlled variable passed directly to os.path.join, open, or Path constructor",
        regex=[
            r"os\.path\.join\s*\([^)]*(?:request\.|user_|input[^)]*)",
            r"(?:open|Path|pathlib\.Path)\s*\([^)]*(?:request\.|user_|input[^)]*)",
        ],
        remediation="Validate and sanitize input; use os.path.basename() or pathlib.resolve()",
        references=["https://cheatsheetseries.owasp.org/cheatsheets/Path_Traversal.html"],
    ),
    OwaspPattern(
        id="OWASP-A01-PATH-002",
        cwe="CWE-22",
        owasp_category="A01:2021 Broken Access Control",
        title="Literal path traversal sequence in string",
        severity=Severity.HIGH,
        languages=["python"],
        description="Hardcoded .. or ../ found in path construction",
        regex=[
            r"['\"][^'\"]*\.\./?[^'\"]*['\"]",
        ],
        remediation="Avoid hardcoded path traversal; use absolute paths and whitelist allowed directories",
        references=["https://cheatsheetseries.owasp.org/cheatsheets/Path_Traversal.html"],
    ),
    OwaspPattern(
        id="OWASP-A01-PATH-003",
        cwe="CWE-22",
        owasp_category="A01:2021 Broken Access Control",
        title="Request data directly to filesystem API",
        severity=Severity.CRITICAL,
        languages=["python"],
        description="request.args, request.form, or request.json feeding into open/os.path.join without validation",
        regex=[
            r"(?:open|os\.path\.join|Path)\s*\([^)]*request\.(?:args|form|json)\[?[^)]*\)",
        ],
        remediation="Always validate and sanitize; use os.path.basename() and check against whitelist",
        references=["https://cheatsheetseries.owasp.org/cheatsheets/Path_Traversal.html"],
    ),

    # ========== Category 4: Hardcoded Credentials (CWE-798, OWASP A07) ==========
    # NOTE: These are stubs; full patterns come from secret_patterns.py (VOY-0022)
    # See fallback _BUILTIN_CREDENTIAL_STUBS above

    # ========== Category 5: Insecure Deserialization (CWE-502, OWASP A08) ==========
    OwaspPattern(
        id="OWASP-A08-DESER-001",
        cwe="CWE-502",
        owasp_category="A08:2021 Software and Data Integrity Failures",
        title="Insecure pickle.loads on untrusted data",
        severity=Severity.CRITICAL,
        languages=["python"],
        description="pickle.loads() called on data from network, file, or user input",
        regex=[
            r"pickle\.loads\s*\(",
        ],
        ast_check="check_pickle_loads",
        remediation="Use safer serialization formats (JSON, MessagePack); if pickle required, sign and verify data",
        references=["https://docs.python.org/3/library/pickle.html#what-can-pickle-do"],
    ),
    OwaspPattern(
        id="OWASP-A08-DESER-002",
        cwe="CWE-502",
        owasp_category="A08:2021 Software and Data Integrity Failures",
        title="Insecure pickle.load on untrusted file",
        severity=Severity.CRITICAL,
        languages=["python"],
        description="pickle.load() reading from file, socket, or other untrusted source",
        regex=[
            r"pickle\.load\s*\(",
        ],
        remediation="Use safer serialization formats (JSON); if pickle required, validate file source",
        references=["https://docs.python.org/3/library/pickle.html#what-can-pickle-do"],
    ),
    OwaspPattern(
        id="OWASP-A08-DESER-003",
        cwe="CWE-502",
        owasp_category="A08:2021 Software and Data Integrity Failures",
        title="yaml.load() without SafeLoader",
        severity=Severity.HIGH,
        languages=["python"],
        description="yaml.load() called without Loader=yaml.SafeLoader",
        regex=[
            r"yaml\.load\s*\([^)]*?\)",
        ],
        ast_check="check_yaml_load",
        remediation="Use yaml.safe_load() or pass Loader=yaml.SafeLoader",
        references=["https://pyyaml.org/wiki/PyYAMLDocumentation"],
    ),
    OwaspPattern(
        id="OWASP-A08-DESER-004",
        cwe="CWE-502",
        owasp_category="A08:2021 Software and Data Integrity Failures",
        title="eval() on non-literal argument",
        severity=Severity.CRITICAL,
        languages=["python"],
        description="eval() called with a variable or user input, not a string literal",
        regex=[
            r"eval\s*\(\s*(?![\'\"])[a-zA-Z_]",
        ],
        ast_check="check_eval",
        remediation="Avoid eval(); use safer alternatives like ast.literal_eval for data parsing",
        references=["https://cheatsheetseries.owasp.org/cheatsheets/Deserialization_Cheat_Sheet.html"],
    ),
    OwaspPattern(
        id="OWASP-A08-DESER-005",
        cwe="CWE-502",
        owasp_category="A08:2021 Software and Data Integrity Failures",
        title="exec() on non-literal argument",
        severity=Severity.CRITICAL,
        languages=["python"],
        description="exec() called with variable or user input, not hardcoded code",
        regex=[
            r"exec\s*\(\s*(?![\'\"])[a-zA-Z_]",
        ],
        remediation="Avoid exec(); use safer alternatives or refactor to use functions/modules",
        references=["https://cheatsheetseries.owasp.org/cheatsheets/Deserialization_Cheat_Sheet.html"],
    ),
    OwaspPattern(
        id="OWASP-A08-DESER-006",
        cwe="CWE-502",
        owasp_category="A08:2021 Software and Data Integrity Failures",
        title="jsonpickle.decode() on untrusted data",
        severity=Severity.HIGH,
        languages=["python"],
        description="jsonpickle.decode() called on user input or network data",
        regex=[
            r"jsonpickle\.decode\s*\(",
        ],
        remediation="Use json.loads() instead; if jsonpickle required, sign and verify data",
        references=["https://jsonpickle.github.io/"],
    ),

    # ========== Category 6: Command Injection (CWE-78, OWASP A03) ==========
    OwaspPattern(
        id="OWASP-A03-CMD-001",
        cwe="CWE-78",
        owasp_category="A03:2021 Injection",
        title="Subprocess with shell=True and variable argument",
        severity=Severity.CRITICAL,
        languages=["python"],
        description="subprocess.run/call/Popen with shell=True and a variable or user input in command",
        regex=[
            r"subprocess\.(?:run|call|Popen)\s*\([^)]*shell\s*=\s*True",
        ],
        ast_check="check_subprocess_shell",
        remediation="Use subprocess without shell=True; pass command as list of strings",
        references=["https://cheatsheetseries.owasp.org/cheatsheets/OS_Command_Injection.html"],
    ),
    OwaspPattern(
        id="OWASP-A03-CMD-002",
        cwe="CWE-78",
        owasp_category="A03:2021 Injection",
        title="os.system() with non-literal argument",
        severity=Severity.CRITICAL,
        languages=["python"],
        description="os.system() called with a variable or user input, not a string literal",
        regex=[
            r"os\.system\s*\(\s*(?![\'\"])[a-zA-Z_]",
        ],
        remediation="Use subprocess module instead of os.system",
        references=["https://cheatsheetseries.owasp.org/cheatsheets/OS_Command_Injection.html"],
    ),
    OwaspPattern(
        id="OWASP-A03-CMD-003",
        cwe="CWE-78",
        owasp_category="A03:2021 Injection",
        title="os.popen() with non-literal argument",
        severity=Severity.HIGH,
        languages=["python"],
        description="os.popen() called with variable or user input",
        regex=[
            r"os\.popen\s*\(\s*(?![\'\"])[a-zA-Z_]",
        ],
        remediation="Use subprocess module; avoid os.popen()",
        references=["https://cheatsheetseries.owasp.org/cheatsheets/OS_Command_Injection.html"],
    ),

    # ========== Category 7: Weak Cryptography (CWE-327/330, OWASP A02) ==========
    OwaspPattern(
        id="OWASP-A02-CRYPTO-001",
        cwe="CWE-327",
        owasp_category="A02:2021 Cryptographic Failures",
        title="MD5 or SHA1 used for non-security checksum",
        severity=Severity.HIGH,
        languages=["python"],
        description="hashlib.md5() or hashlib.sha1() used outside security context",
        regex=[
            r"hashlib\.(?:md5|sha1)\s*\(",
        ],
        ast_check="check_weak_crypto",
        remediation="Use SHA-256 or stronger; reserve MD5/SHA1 for non-security checksums only",
        references=["https://cheatsheetseries.owasp.org/cheatsheets/Cryptographic_Storage_Cheat_Sheet.html"],
    ),
    OwaspPattern(
        id="OWASP-A02-CRYPTO-002",
        cwe="CWE-327",
        owasp_category="A02:2021 Cryptographic Failures",
        title="MD5/SHA1 in password or auth context",
        severity=Severity.CRITICAL,
        languages=["python"],
        description="MD5 or SHA1 used inside password, auth, or token function",
        regex=[
            r"def\s+(?:password|auth|token|hash)[^(]*\(.*hashlib\.(?:md5|sha1)",
        ],
        remediation="Use bcrypt, scrypt, or argon2 for password hashing",
        references=["https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html"],
    ),
    OwaspPattern(
        id="OWASP-A02-CRYPTO-003",
        cwe="CWE-330",
        owasp_category="A02:2021 Cryptographic Failures",
        title="Hardcoded IV in encryption",
        severity=Severity.HIGH,
        languages=["python"],
        description="Byte literal like b'\\x00' * 16 assigned to iv or nonce variable",
        regex=[
            r"(?:iv|nonce)\s*=\s*b['\"]?\\x00['\"]",
        ],
        remediation="Generate IVs/nonces randomly for each encryption operation",
        references=["https://cheatsheetseries.owasp.org/cheatsheets/Cryptographic_Storage_Cheat_Sheet.html"],
    ),
    OwaspPattern(
        id="OWASP-A02-CRYPTO-004",
        cwe="CWE-327",
        owasp_category="A02:2021 Cryptographic Failures",
        title="Weak cipher algorithm (DES, RC4, Blowfish)",
        severity=Severity.HIGH,
        languages=["python"],
        description="DES, RC4, or Blowfish cipher imported or instantiated",
        regex=[
            r"(?:from\s+Crypto|from\s+cryptography).*(?:DES|RC4|Blowfish)",
            r"(?:DES|RC4|Blowfish)\s*\(",
        ],
        remediation="Use AES-256 or other modern NIST-approved ciphers",
        references=["https://cheatsheetseries.owasp.org/cheatsheets/Cryptographic_Storage_Cheat_Sheet.html"],
    ),

    # ========== Category 8: Missing Auth Decorators (CWE-306, OWASP A01) ==========
    OwaspPattern(
        id="OWASP-A01-AUTH-001",
        cwe="CWE-306",
        owasp_category="A01:2021 Broken Access Control",
        title="Flask route without authentication",
        severity=Severity.HIGH,
        languages=["python"],
        description="Flask @app.route or @blueprint.route without @login_required or security decorator",
        regex=[
            r"@(?:app|blueprint)\.route\s*\(",
        ],
        ast_check="check_flask_auth",
        remediation="Add @login_required or custom authorization decorator to protect the route",
        references=["https://flask-login.readthedocs.io/"],
    ),
    OwaspPattern(
        id="OWASP-A01-AUTH-002",
        cwe="CWE-306",
        owasp_category="A01:2021 Broken Access Control",
        title="FastAPI route without authentication",
        severity=Severity.HIGH,
        languages=["python"],
        description="FastAPI route function without Depends(get_current_user) or security dependency",
        regex=[
            r"@(?:router|app)\.(?:get|post|put|delete|patch)\s*\(",
        ],
        ast_check="check_fastapi_auth",
        remediation="Add a Depends() with authentication/authorization dependency to the route",
        references=["https://fastapi.tiangolo.com/tutorial/security/"],
    ),
    OwaspPattern(
        id="OWASP-A01-AUTH-003",
        cwe="CWE-306",
        owasp_category="A01:2021 Broken Access Control",
        title="Django view without login requirement",
        severity=Severity.MEDIUM,
        languages=["python"],
        description="Django class-based view without LoginRequiredMixin or @method_decorator(login_required)",
        regex=[
            r"class\s+\w+\((?:View|CreateView|UpdateView|DeleteView)[^)]*\):",
        ],
        ast_check="check_django_auth",
        remediation="Add LoginRequiredMixin to class or @method_decorator(login_required) to dispatch",
        references=["https://docs.djangoproject.com/en/stable/topics/auth/"],
    ),
]


# ==============================================================================
# SEVERITY MAPPING FOR CREDENTIAL PATTERNS (VOY-0022)
# ==============================================================================

_CREDENTIAL_SEVERITY_MAP = {
    Severity.HIGH: Severity.CRITICAL,
    Severity.MEDIUM: Severity.HIGH,
    Severity.LOW: Severity.MEDIUM,
}


# ==============================================================================
# AST CHECKER STUBS (To be implemented in future iterations)
# ==============================================================================

def _check_sql_injection(node: ast.AST) -> bool:
    """Check AST node for SQL injection patterns."""
    # TODO: Implement AST-based SQL injection detection
    return False


def _check_pickle_loads(node: ast.AST) -> bool:
    """Check if pickle.loads is called on non-literal data."""
    # TODO: Implement pickle.loads argument validation
    return False


def _check_yaml_load(node: ast.AST) -> bool:
    """Check if yaml.load lacks SafeLoader."""
    # TODO: Implement yaml.load SafeLoader check
    return False


def _check_eval(node: ast.AST) -> bool:
    """Check if eval() receives non-literal argument."""
    # TODO: Implement eval argument validation
    return False


def _check_subprocess_shell(node: ast.AST) -> bool:
    """Check if subprocess has shell=True with variable command."""
    # TODO: Implement subprocess shell check
    return False


def _check_weak_crypto(node: ast.AST) -> bool:
    """Check context to determine if MD5/SHA1 is for security purpose."""
    # TODO: Implement context-aware weak crypto detection
    return False


def _check_flask_auth(node: ast.AST) -> bool:
    """Check if Flask route has auth decorator."""
    # TODO: Implement Flask auth decorator check
    return False


def _check_fastapi_auth(node: ast.AST) -> bool:
    """Check if FastAPI route has security dependency."""
    # TODO: Implement FastAPI security dependency check
    return False


def _check_django_auth(node: ast.AST) -> bool:
    """Check if Django view has LoginRequiredMixin."""
    # TODO: Implement Django auth check
    return False


_AST_CHECKERS = {
    "check_sql_injection": _check_sql_injection,
    "check_pickle_loads": _check_pickle_loads,
    "check_yaml_load": _check_yaml_load,
    "check_eval": _check_eval,
    "check_subprocess_shell": _check_subprocess_shell,
    "check_weak_crypto": _check_weak_crypto,
    "check_flask_auth": _check_flask_auth,
    "check_fastapi_auth": _check_fastapi_auth,
    "check_django_auth": _check_django_auth,
}


# ==============================================================================
# PATTERN LOADING AND CREDENTIAL PATTERN REUSE
# ==============================================================================

def _load_credential_patterns() -> List[OwaspPattern]:
    """Load credential patterns from secret_patterns.py or use builtin stubs."""
    try:
        from maestro.security.secret_patterns import SECRET_PATTERNS
        # Map severity levels to OWASP standards
        mapped_patterns = []
        for pattern in SECRET_PATTERNS:
            # Adjust severity for credential patterns
            new_severity = _CREDENTIAL_SEVERITY_MAP.get(pattern.severity, Severity.HIGH)
            mapped_patterns.append(
                OwaspPattern(
                    id=pattern.id.replace("SECRET", "OWASP-A07-CRED") if hasattr(pattern, "id") else "OWASP-A07-CRED-999",
                    cwe="CWE-798",
                    owasp_category="A07:2021 Identification and Authentication Failures",
                    title=pattern.title if hasattr(pattern, "title") else "Hardcoded credential",
                    severity=new_severity,
                    languages=["python"],
                    description=pattern.description if hasattr(pattern, "description") else "",
                    regex=pattern.regex if hasattr(pattern, "regex") else [],
                    remediation=pattern.remediation if hasattr(pattern, "remediation") else "",
                    references=pattern.references if hasattr(pattern, "references") else [],
                )
            )
        return mapped_patterns
    except ImportError:
        # Fallback to builtin stubs if VOY-0022 not yet shipped
        return _BUILTIN_CREDENTIAL_STUBS


def get_patterns(language: str = "python") -> List[OwaspPattern]:
    """Get all patterns for a given language."""
    credential_patterns = _load_credential_patterns()
    all_patterns = _PATTERNS + credential_patterns
    return [p for p in all_patterns if language in p.languages]


# ==============================================================================
# SCANNER CLASS
# ==============================================================================

class OWASPScanner:
    """Scanner for OWASP/CWE patterns in source code."""

    def __init__(self, language: str = "python"):
        self.language = language
        self.patterns = get_patterns(language)
        self._compiled_regexes = {}
        self._compile_patterns()

    def _compile_patterns(self):
        """Pre-compile regex patterns for efficiency."""
        for pattern in self.patterns:
            for regex_str in pattern.regex:
                try:
                    self._compiled_regexes[regex_str] = re.compile(regex_str, re.MULTILINE)
                except Exception:
                    pass

    def scan_file(self, file_path: str) -> List[Finding]:
        """Scan a single file for vulnerabilities."""
        findings = []
        try:
            with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
            lines = content.split("\n")
        except Exception:
            return findings

        # Scan each pattern
        for pattern in self.patterns:
            for regex_str in pattern.regex:
                regex = self._compiled_regexes.get(regex_str)
                if not regex:
                    continue

                for match in regex.finditer(content):
                    # Calculate line number from match position
                    line_num = content[:match.start()].count("\n") + 1
                    col = match.start() - content.rfind("\n", 0, match.start())

                    # Extract snippet — for credential patterns the matched value
                    # often IS the secret, so we redact rather than write it into
                    # SEC-*.json / SEC-*.md reports that may be read by other tools.
                    line_content = lines[line_num - 1] if line_num <= len(lines) else ""
                    if pattern.id.startswith("OWASP-A07-CRED-"):
                        snippet = f"[REDACTED — credential pattern {pattern.id} matched on line {line_num}]"
                    else:
                        snippet = line_content[:120]

                    finding = Finding(
                        id=pattern.id,
                        cwe=pattern.cwe,
                        owasp_category=pattern.owasp_category,
                        title=pattern.title,
                        severity=pattern.severity,
                        file=file_path,
                        line=line_num,
                        column=col,
                        snippet=snippet,
                        remediation=pattern.remediation,
                    )
                    findings.append(finding)

        return findings

    def scan_files(self, file_paths: List[str]) -> List[Finding]:
        """Scan multiple files and return all findings."""
        all_findings = []
        for file_path in file_paths:
            all_findings.extend(self.scan_file(file_path))
        return all_findings
