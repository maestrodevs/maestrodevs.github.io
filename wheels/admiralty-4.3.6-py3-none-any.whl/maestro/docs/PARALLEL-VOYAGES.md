# Parallel Voyages — Operator Reference

> **v2.6.0+** — Introduced by VOY-ADM-2026-0039 (closes BUG-ADM-2026-0011).

## Why parallel voyages exist

Before v2.6.0, every crew dispatch switched the dispatcher's parent shell to the voyage branch. When two voyages were in-flight simultaneously, the shell swaps raced: voyage X's crew could find the dispatcher's branch set to voyage Y's branch, silently writing commits to the wrong place.

The Captain surfaced this as BUG-0011:

> *"All voyages, orders, bugs etc should be able to run in parallel to other voyages, orders or bugs without the code changes being applied to the incorrect branches."*

The root cause was a shared mutable resource — the dispatcher's parent shell branch — being used as a per-voyage identity signal. The fix is **git worktrees**: each active voyage gets its own isolated working directory, linked to the shared `.git/` database but checked out on its own branch. The dispatcher's parent shell branch is now irrelevant to crew dispatch.

A second race was also closed: the `sweep_decks()` function previously fired as soon as a crew's ralph-state changed to `COMPLETE`, even if the subprocess was still flushing writes to disk. A configurable drain window now holds the sweep until each crew process has fully exited.

---

## Worktree layout

For every active voyage, Maestro maintains one git worktree at:

```
.mso/voyages/active/<VOYAGE_ID>/.worktree/
```

Examples with three concurrent voyages:

```
.mso/voyages/active/
├── VOY-ADM-2026-0037/
│   ├── voyage.json
│   └── .worktree/          ← checked out on voyage/VOY-ADM-2026-0037-...
├── VOY-ADM-2026-0038/
│   ├── voyage.json
│   └── .worktree/          ← checked out on voyage/VOY-ADM-2026-0038-...
└── VOY-ADM-2026-0039/
    ├── voyage.json
    └── .worktree/          ← checked out on voyage/VOY-ADM-2026-0039-...
```

Each worktree is a full working copy of the repo's tracked files (no extra `.git/` — they all share the parent repo's object store). The crew's `MAESTRO_REPO_PATH` env var is set to the worktree path, so every Claude Code session boots directly into the correct branch without touching the parent shell.

The `.mso/` directory is **not** inside the worktree — it stays in the main checkout and is shared across all voyages. This is intentional: order state, voyage JSON, lifecycle logs, and crew dirs are shared resources managed by the dispatcher, not per-branch artefacts.

---

## Worktree state machine

### States

| State | Meaning | Filesystem artefact |
|---|---|---|
| **NONE** | No worktree created yet | No `.mso/voyages/active/VOY-X/.worktree/` |
| **PREPARING** | `git worktree add` executing (transient) | Dir created but git link not yet established |
| **READY** | Worktree fully initialised, no crew running | `.worktree/` exists and appears in `git worktree list` |
| **IN_USE** | ≥1 crew subprocess has the worktree as `MAESTRO_REPO_PATH` | `ACTIVE_PROCESSES` entry exists for the voyage |
| **CLEANING** | `cleanup_voyage_worktree()` executing (transient) | Dir still present, git removing link |
| **REMOVED** | Voyage complete, worktree gone | No `.worktree/` dir |

### Transitions

```
                     [dispatcher start]
                           │
                           ▼
NONE ──prepare_voyage_worktree()──► PREPARING ──success──► READY
                                         │                    │
                                   branch conflict       dispatch_crew()
                                   / disk full                │
                                         │                    ▼
                                   [error path]           IN_USE
                                   return None               │
                                                     [all crews drain]
                                                             │
                                                 cleanup_voyage_worktree()
                                                             │
                                                         CLEANING
                                                             │
                                                         REMOVED
                                             (prune_stale_worktrees
                                              also arrives here for
                                              orphaned worktrees)
```

### Which function drives which transition

| Function | Transition | Module |
|---|---|---|
| `prepare_voyage_worktree(voyage_id, branch)` | NONE → PREPARING → READY | `maestro/core/worktrees.py` |
| `dispatch_crew()` | READY → IN_USE | `maestro/core/fleet_runner.py` |
| `cleanup_voyage_worktree(voyage_id)` | IN_USE → CLEANING → REMOVED | `maestro/core/worktrees.py` |
| `prune_stale_worktrees()` | orphan READY/PREPARING → REMOVED | `maestro/core/worktrees.py` |
| `sweep_decks()` | calls `cleanup_voyage_worktree` when archiving | `maestro/core/fleet_runner.py` |

---

## Drain semantics

When a crew's ralph-state changes to `COMPLETE`, Maestro does not immediately remove the crew from tracking. Instead it enters a **drain window**:

1. The crew is moved from `ACTIVE_PROCESSES` to `DRAINING_PROCESSES`.
2. A `DRAIN_START` lifecycle event is emitted.
3. Each dispatcher loop tick checks: has the process exited AND has at least `MAESTRO_CREW_DRAIN_SECONDS` elapsed since the transition?
4. When both conditions hold, the crew is cleared from `DRAINING_PROCESSES` and a `DRAIN_COMPLETE` event is emitted.

`sweep_decks()` only fires when **both** `ACTIVE_PROCESSES` and `DRAINING_PROCESSES` are empty (plus the existing queue-drained condition). This eliminates the race where a voyage was swept while its last crew was still flushing commits.

### Tuning the drain window

| Variable | Default | Notes |
|---|---|---|
| `MAESTRO_CREW_DRAIN_SECONDS` | `5` | Set to `0` to restore immediate-archive behaviour (useful in CI / integration tests) |

```bash
# Faster testing — no drain wait
MAESTRO_CREW_DRAIN_SECONDS=0 mso dispatch

# Slower machines or large repos — give git more flush time
MAESTRO_CREW_DRAIN_SECONDS=15 mso dispatch
```

Drain is per-crew, not serial. If five crews complete near-simultaneously, the total wall-clock drain is `max(crew_drain_times)`, not the sum.

---

## Operator commands

### Inspect current worktree state

```bash
# Show all worktrees — main checkout plus one per active voyage
git worktree list

# Example output:
# C:/Repos/Maestro                                  a6f70ac [main]
# C:/Repos/Maestro/.mso/voyages/active/VOY-ADM-2026-0037/.worktree  1234abc [voyage/VOY-ADM-2026-0037-...]
# C:/Repos/Maestro/.mso/voyages/active/VOY-ADM-2026-0038/.worktree  5678def [voyage/VOY-ADM-2026-0038-...]
```

```bash
# Check a specific worktree's branch
git -C .mso/voyages/active/VOY-ADM-2026-0037/.worktree rev-parse --abbrev-ref HEAD

# See the diff between the worktree and its upstream
git -C .mso/voyages/active/VOY-ADM-2026-0037/.worktree log origin/$(git -C .mso/voyages/active/VOY-ADM-2026-0037/.worktree rev-parse --abbrev-ref HEAD)..HEAD --oneline
```

### Repair orphan worktrees

If the dispatcher was killed mid-flight, some worktrees may be stale. On the next `mso dispatch`, `prune_stale_worktrees()` runs automatically at startup. To repair manually:

```bash
# Step 1 — let git clean up broken worktree links
git worktree prune

# Step 2 — verify which worktrees remain registered
git worktree list

# Step 3 — for any directory that appears in .mso/voyages/active/ but not in git worktree list,
#           remove it by hand (it's an orphaned PREPARING crash residue)
Remove-Item -Recurse -Force .mso/voyages/active/VOY-ADM-2026-XXXX/.worktree   # PowerShell
# or
rm -rf .mso/voyages/active/VOY-ADM-2026-XXXX/.worktree                        # bash
```

The dispatcher will recreate the worktree on next dispatch for any voyage with PENDING orders.

### Force-remove a worktree for a completed voyage

```bash
# Remove git's worktree registration (--force handles locked files on Windows)
git worktree remove .mso/voyages/active/VOY-ADM-2026-XXXX/.worktree --force

# If git worktree remove fails (e.g. Windows file locks still held), run prune then rmdir
git worktree prune
Remove-Item -Recurse -Force .mso/voyages/active/VOY-ADM-2026-XXXX/.worktree   # PowerShell
```

### Check dispatcher drain state

The dispatcher lifecycle log captures drain events. To check:

```bash
# Tail the fleet log for drain events (adjust log path as needed)
Select-String "DRAIN_" .mso/logs/fleet-runner.log | Select-Object -Last 30   # PowerShell
grep "DRAIN_" .mso/logs/fleet-runner.log | tail -30                           # bash
```

---

## Lifecycle events

The following lifecycle events are emitted to the fleet log for observability. All follow the existing `write_lifecycle_event` schema.

| Event | Emitted when |
|---|---|
| `WORKTREE_CREATED` | `prepare_voyage_worktree` successfully creates a new worktree |
| `WORKTREE_REMOVED` | `cleanup_voyage_worktree` finishes removing a worktree |
| `WORKTREE_CREATE_FAILED` | `git worktree add` exits non-zero (disk full, permission error, etc.) |
| `WORKTREE_BRANCH_CONFLICT` | Branch is already checked out in another worktree or developer's manual checkout |
| `WORKTREE_MISSING` | `prepare_voyage_worktree` returned a path but it doesn't exist on disk when `dispatch_crew` checks |
| `ORPHAN_WORKTREE_PRUNED` | `prune_stale_worktrees` removes a stale worktree directory |
| `DRAIN_START` | Crew ralph-state → COMPLETE; crew moved to `DRAINING_PROCESSES` |
| `DRAIN_COMPLETE` | Drain window elapsed and process exited; crew cleared from tracking |
| `LEGACY_CREW_CLONE` | Deprecated `prepare_crew_repo()` was invoked for a legacy queue entry |

---

## Edge-case operator playbook

### EC-1: Worktree manually deleted while a voyage is active

**Symptom**: Crew process exits immediately after launch; lifecycle log shows `WORKTREE_MISSING`.

**Fix**: Do nothing — on the next dispatcher tick, `dispatch_crew` will call `prepare_voyage_worktree` again, which will create a fresh worktree (NONE → READY). The order is re-queued as PENDING and retried automatically.

If the issue recurs, check disk space and antivirus exclusions on `.mso/voyages/`.

### EC-2: Parent shell on a stale or unrelated branch

**Symptom**: You ran `mso dispatch` from a branch other than `main`.

**Impact**: None. The dispatcher's parent shell branch is no longer used for crew dispatch. Each crew operates in its own worktree on the correct voyage branch regardless of where the parent shell is.

**Note**: Operator-direct `git` commands in the parent shell still operate on whatever branch the shell is on — take care when running manual `git commit`/`git push` outside the dispatcher.

### EC-3: Orphan worktrees after a dispatcher crash

**Symptom**: `git worktree list` shows entries whose corresponding voyage is complete or whose crew processes are no longer alive.

**Fix**:
1. `mso dispatch` — on startup, `prune_stale_worktrees()` runs automatically and cleans up orphans.
2. To clean manually: `git worktree prune` followed by `rm -rf .mso/voyages/active/VOY-XXXX/.worktree` for any stale directories.

Each pruned orphan emits `ORPHAN_WORKTREE_PRUNED` to the lifecycle log.

### EC-4: Disk full during worktree creation

**Symptom**: Lifecycle log shows `WORKTREE_CREATE_FAILED` with "No space left on device" in the stderr capture.

**Fix**:
1. Free disk space (clear `.mso/logs/`, old crew dirs, or other large files).
2. The order remains PENDING and is retried on the next dispatcher tick.
3. No manual cleanup needed — `prepare_voyage_worktree` removes any partial directory before emitting the failure event.

**Prevention**: Each active voyage worktree is a full working copy of tracked files with no extra `.git/` object store. For a typical ~100 MB repo, five concurrent voyages consume ~500 MB. Ensure the host has at least `repo_size × (max_concurrent_voyages + 1)` free disk space.

### EC-5: Branch already checked out in a conflicting worktree

**Symptom**: Lifecycle log shows `WORKTREE_BRANCH_CONFLICT`. Dispatcher log includes a message like: `"Branch voyage/VOY-ADM-2026-XXXX-... is already checked out — either by a worktree in this repo or by a developer's manual checkout. Run 'git worktree list' to inspect."`

**Fix**:
1. Run `git worktree list` to identify which worktree holds the branch.
2. If it is an orphan (voyage complete but worktree not cleaned up): `git worktree remove <path> --force` + `git worktree prune`.
3. If it is a developer's manual checkout in another clone or worktree: switch that checkout away from the voyage branch.
4. The order remains PENDING and retries automatically once the conflict is resolved.

### EC-6: Concurrent crews from the same voyage

**By design, this is safe.** A git worktree is a normal directory — multiple read-only subprocesses can operate in it simultaneously. Mutating operations (commit, push) are serialised by the existing role sequence gate (`check_role_sequence_gate`), which prevents two roles from the same voyage running concurrently unless explicitly allowed.

`.mso/` writes (order JSON, lifecycle log) are atomic-rename or append-only patterns and remain safe since `.mso/` is in the main checkout, not the worktree.

### EC-7: Dispatcher killed mid-flight, restart with half-built worktrees

**Symptom**: Some `.mso/voyages/active/VOY-XXXX/.worktree/` directories exist but are not in `git worktree list` (crash during `PREPARING` state).

**Fix**:
1. `mso dispatch` — `prune_stale_worktrees()` at startup detects directories not registered in `git worktree list`, removes them, and re-creates on next dispatch.
2. `reset_orphaned_in_progress_orders` (also runs at startup) flips any `IN_PROGRESS` orders back to `PENDING` so they re-enter the queue.

### EC-8: Voyage branch deleted from origin while worktree is still active locally

**Symptom**: Crew's `git push` fails with "branch not found" on origin.

**Fix**:
1. Recreate the branch on origin: `git push -u origin <voyage-branch>`.
2. The crew order will have been marked `FAILED` by the push failure. Re-queue manually or re-dispatch.
3. The local worktree remains valid — the branch exists locally even if origin deleted it.

---

## Disk usage note

Each active voyage's worktree is a separate working copy of the repository's tracked files. The shared `.git/` object store is **not** duplicated — only the file tree is.

| Repo size | Concurrent voyages | Estimated disk for worktrees |
|---|---|---|
| 50 MB | 3 | ~150 MB |
| 100 MB | 5 | ~500 MB |
| 200 MB | 10 | ~2 GB |

Worktrees are removed automatically when a voyage completes. Stale worktrees from crashed dispatchers are pruned at next startup. Monitor `.mso/voyages/active/` directory size if running many concurrent voyages on a constrained host.

---

## Legacy dispatcher branch check (removed in v4.0)

The legacy dispatcher branch-check function was removed in v4.0 (FTR-MSO-2026-0177). In prior versions it was a no-op shim that emitted a `LEGACY_DISPATCHER_BRANCH_CHECK` lifecycle warning. Before v2.6.0 it switched the dispatcher's parent shell to the correct voyage branch before each crew launch; worktrees made that irrelevant.

`prepare_crew_repo()` (which used to clone the repo per voyage) is deprecated. It emits `LEGACY_CREW_CLONE` if invoked and is kept callable for any pre-v2.6.0 order queue entries. New dispatch paths use `prepare_voyage_worktree()` exclusively.

See [docs/BRANCH-DISCIPLINE.md](BRANCH-DISCIPLINE.md) for the full branch-discipline reference.

---

## Quick reference

```bash
# Inspect
git worktree list                              # all active worktrees

# Prune (safe to run anytime)
git worktree prune                             # clean broken git-level links

# Remove a specific worktree
git worktree remove .mso/voyages/active/VOY-ADM-2026-XXXX/.worktree --force

# Drain window tuning
MAESTRO_CREW_DRAIN_SECONDS=0  mso dispatch  # no drain (CI)
MAESTRO_CREW_DRAIN_SECONDS=15 mso dispatch  # slower machines

# Find drain events in the lifecycle log
grep "DRAIN_" .mso/logs/fleet-runner.log | tail -20

# Find worktree events in the lifecycle log
grep "WORKTREE_" .mso/logs/fleet-runner.log | tail -20
```
