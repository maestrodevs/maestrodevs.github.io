# Maestro Maestro — Security Questionnaire Pre-fill

> **Purpose:** Sales-engineer reference for SIG Lite, CAIQ Lite, and vendor-specific security questionnaires.
> Copy rows into the customer's template; adjust wording for their question phrasing.
> All evidence links point to checked-in documentation.
>
> **Effective date:** 2026-04-28 · **Product version:** v2.0.0 (v3.0.0 roadmap noted where relevant)

---

## Where does your data go?

Point a CISO here first. Maestro is a CLI on your machine — nothing leaves your environment unless you configure an external API.

```mermaid
flowchart LR
    subgraph Customer["Customer Infrastructure (your environment)"]
        direction TB
        DEV["Your laptop / CI pipeline"]
        GIT["Self-hosted Git\nor GitHub / GitLab"]
        LLM_LOCAL["On-prem LLM\n(air-gap mode)"]
        ARTEFACTS[".mso/ workspace\norders · plans · audit log\nAll artefacts stored here"]
    end

    subgraph Maestro["Maestro Framework (pip package)"]
        direction TB
        CLI["mso CLI"]
        NOTE["No Maestro-operated servers\nNo telemetry · No phone-home\nNo data leaves without your config"]
    end

    subgraph External["Optional External Services (opt-out available)"]
        direction TB
        ANTHROPIC["Anthropic API\nTLS encrypted · prompts only\nOpt-out: use local LLM"]
        GITHUB["GitHub API\nTLS encrypted · repo operations\nOpt-out: self-hosted Git"]
        SLACK["Slack\nTLS encrypted · notifications\nOpt-out: disable bridge"]
    end

    Customer <--> Maestro
    Maestro -.->|"configurable —\nopt-out available"| External

    classDef customerStyle fill:#27ae60,color:#fff,stroke:#1e8449
    classDef maestroStyle fill:#2980b9,color:#fff,stroke:#1a5276
    classDef externalStyle fill:#7f8c8d,color:#fff,stroke:#636e72
```

**Key takeaway:** Maestro is a CLI on your machine. Nothing leaves your environment unless you configure an external API. Air-gap mode removes all external dependencies.

---

## 1. Authentication & Access Control

| # | Question | Answer | Evidence |
|---|----------|--------|----------|
| 1.1 | How does the product authenticate users? | Maestro runs entirely inside the customer's environment. CLI operators authenticate via their existing machine credentials and GitHub token. No Maestro-managed user accounts or passwords exist. | [ENTERPRISE-SECURITY.md §1 — Identity model + ACL](ENTERPRISE-SECURITY.md#1-identity-model--acl) |
| 1.2 | Does the product support role-based access control (RBAC)? | Yes. Enterprise mode enforces a capability-based ACL (`roles.yaml`). Each identity (human or crew) carries a scoped permission set; the integrity guard (FTR-0067) rejects any attempt to bypass the declared role matrix. | [ENTERPRISE-SECURITY.md §1 — ACL](ENTERPRISE-SECURITY.md#acl--capability-based) |
| 1.3 | Is multi-factor authentication (MFA) supported or required? | MFA is delegated to the customer's identity provider (GitHub SSO, Entra ID, etc.). Maestro itself does not issue credentials and therefore cannot enforce MFA independently. | [ENTERPRISE-SECURITY.md §1 — Authentication](ENTERPRISE-SECURITY.md#authentication) |
| 1.4 | How is privileged access controlled? | Operator-level CLI access is restricted to the machine running the fleet. Crew sessions run as ephemeral sub-processes with environment variables scrubbed (FTR-0069) before each invocation. | [ENTERPRISE-SECURITY.md §3 — Subprocess env scrub](ENTERPRISE-SECURITY.md#subprocess-env-scrub-ftr-0069), [ENTERPRISE-SECURITY.md §5 — Operator separation](ENTERPRISE-SECURITY.md#5-operator-separation) |

---

## 2. Data Residency

| # | Question | Answer | Evidence |
|---|----------|--------|----------|
| 2.1 | Where is customer data stored? | All artefacts (orders, plans, code, audit logs) are written to the customer's own file system and Git repository. Nothing is stored on Maestro-operated servers. | [ARCHITECTURE.md §5 — Data residency](ARCHITECTURE.md#data-residency), [ENTERPRISE-SECURITY.md §4 — Data-residency controls](ENTERPRISE-SECURITY.md#4-data-residency-controls) |
| 2.2 | Can data residency be restricted to a specific region or jurisdiction? | Yes. Because all storage is local (or self-hosted Git), the customer fully controls geography. Egress to third-party AI providers can be disabled (air-gapped mode) to enforce strict residency. | [ENTERPRISE-SECURITY.md §4 — Modes](ENTERPRISE-SECURITY.md#modes-ftr-0061--ftr-0070), [ARCHITECTURE.md §4 — Air-Gapped Deployment Guide](ARCHITECTURE.md#4-air-gapped-deployment-guide) |
| 2.3 | Does any data leave the customer's environment? | Only the prompts sent to the configured AI provider (Anthropic/OpenAI/etc.) leave the environment during crew execution. GitHub API calls and (if enabled) Slack bridge traffic also egress. Full egress inventory is published. | [ARCHITECTURE.md §3 — Egress Inventory](ARCHITECTURE.md#3-egress-inventory), [TRUST.md §2 — Data Flow Guarantees](TRUST.md#2-data-flow-guarantees) |
| 2.4 | Is a data processing agreement (DPA) available? | Maestro itself does not process customer data on its servers. For AI-provider sub-processing, customers execute DPAs directly with their chosen provider (Anthropic, OpenAI, etc.). See Sub-processors section. | [TRUST.md §5 — Subprocessors](TRUST.md#5-subprocessors) |

---

## 3. Encryption

| # | Question | Answer | Evidence |
|---|----------|--------|----------|
| 3.1 | Is data encrypted at rest? | Encryption at rest is the customer's responsibility, applied at the OS/disk or Git-hosting layer. Maestro does not implement its own at-rest encryption; it stores plaintext artefacts in the designated workspace. Optional GDPR identity encryption is available for identity records (FTR-0066). | [ENTERPRISE-SECURITY.md §6 — Identity privacy + GDPR](ENTERPRISE-SECURITY.md#6-identity-privacy--gdpr) |
| 3.2 | Is data encrypted in transit? | All network egress (AI provider APIs, GitHub API, Slack) uses HTTPS/TLS 1.2+. No Maestro-controlled servers accept inbound connections. | [ARCHITECTURE.md §3 — Egress Inventory](ARCHITECTURE.md#3-egress-inventory) |
| 3.3 | Do you support Bring Your Own Key (BYOK)? | Yes, for AI provider calls. Customers supply their own API keys, which are stored in the customer's secret store (environment variable, HashiCorp Vault, AWS Secrets Manager, or Azure Key Vault). Maestro never persists these keys. | [ENTERPRISE-SECURITY.md §3 — Secrets management](ENTERPRISE-SECURITY.md#3-secrets-management), [TRUST.md §2 — Data Flow Guarantees](TRUST.md#2-data-flow-guarantees) |
| 3.4 | How are secrets managed within the product? | Secrets are resolved at runtime from the customer's chosen provider (env var, Vault, ASM, AKV) via the secrets matrix. They are injected ephemerally and scrubbed from sub-process environments after each crew run. | [ENTERPRISE-SECURITY.md §3 — Provider matrix](ENTERPRISE-SECURITY.md#provider-matrix) |

---

## 4. Audit Logging

| # | Question | Answer | Evidence |
|---|----------|--------|----------|
| 4.1 | Does the product produce audit logs? | Yes. Every fleet event is appended to an immutable, append-only audit trail (`.mso/audit/log.jsonl`). Entries include timestamp, actor identity, action, and result. | [ENTERPRISE-SECURITY.md §2 — Immutable audit trail](ENTERPRISE-SECURITY.md#2-immutable-audit-trail) |
| 4.2 | What events are logged? | Order dispatch, crew start/stop, hook invocations, secret access attempts, ACL checks, and all CLI commands. | [ENTERPRISE-SECURITY.md §2 — Entry shape](ENTERPRISE-SECURITY.md#entry-shape) |
| 4.3 | Can audit logs be exported to a SIEM or external system? | Enterprise mode supports external anchoring (hash chaining to an external log store — FTR-0068). Direct SIEM connectors are on the v3.0.0 roadmap. | [ENTERPRISE-SECURITY.md §2 — External anchoring](ENTERPRISE-SECURITY.md#external-anchoring-mandatory-in-enterprise-mode--ftr-0068) |
| 4.4 | How long are audit logs retained? | Logs are retained on the customer's infrastructure with no automatic deletion. Retention period is set by the customer's own data-management policy. | [ENTERPRISE-SECURITY.md §2 — Immutable audit trail](ENTERPRISE-SECURITY.md#2-immutable-audit-trail) |

---

## 5. Secret Scanning

| # | Question | Answer | Evidence |
|---|----------|--------|----------|
| 5.1 | Does the product scan for accidentally committed secrets? | Yes. A pre-commit secret-detection hook (shipping in v2.3.0, VOY-ADM-2026-0022) scans staged files for credentials before any commit is pushed. Detected secrets trigger a hook-level block and are flagged in the audit log. | [TRUST.md §8 — Secret detection](TRUST.md#secret-detection-v230--voy-adm-2026-0022) |
| 5.2 | What tool is used for secret scanning? | The implementation references industry-standard pattern libraries (details in the linked section). The hook runs in the customer's environment against their codebase only. | [TRUST.md §8 — Secret detection](TRUST.md#secret-detection-v230--voy-adm-2026-0022) |

---

## 6. Vulnerability Scanning

| # | Question | Answer | Evidence |
|---|----------|--------|----------|
| 6.1 | Is the product's code base scanned for vulnerabilities? | Yes. OWASP/CWE static analysis is planned for v2.3.0 (VOY-ADM-2026-0024). Dependency scanning and MCP server risk classification are also part of that milestone. | [TRUST.md §8 — OWASP / CWE scanning](TRUST.md#owasp--cwe-scanning-v230--voy-adm-2026-0024), [TRUST.md §8 — MCP server risk levels](TRUST.md#mcp-server-risk-levels-v230--voy-adm-2026-0023) |
| 6.2 | How are open security findings tracked and disclosed? | Open findings are published in TRUST.md with severity, description, and planned fix version. CRITICAL/HIGH findings that block release are explicitly called out. | [TRUST.md §3 — Open findings](TRUST.md#open-findings-that-block-v300-production-use), [ENTERPRISE-SECURITY.md §7 — Open findings](ENTERPRISE-SECURITY.md#open-criticalhigh-findings-block-v300-release) |
| 6.3 | What is the patch SLA for critical vulnerabilities? | The vulnerability disclosure policy commits to confirming critical reports within 7 days and publishing a fix or documented mitigation before public disclosure. | [TRUST.md §6 — Vulnerability Disclosure Policy](TRUST.md#6-vulnerability-disclosure-policy) |

---

## 7. Incident Response

| # | Question | Answer | Evidence |
|---|----------|--------|----------|
| 7.1 | How do I report a security vulnerability? | Email **maestro@tech127.com** with a reproducible description. PGP key available on request. Do not open a public GitHub issue for vulnerabilities. | [TRUST.md §6 — How to report](TRUST.md#how-to-report) |
| 7.2 | What is the incident response SLA? | Acknowledgement within 7 business days; status update within 30 days; coordinated disclosure timeline agreed with the reporter before public release. | [TRUST.md §6 — What to expect](TRUST.md#what-to-expect) |
| 7.3 | Is there a published incident response plan? | The vulnerability disclosure policy is published in TRUST.md. A formal IR playbook is on the v3.0.0 roadmap. | [TRUST.md §6 — Vulnerability Disclosure Policy](TRUST.md#6-vulnerability-disclosure-policy) |

---

## 8. Sub-processors

| # | Question | Answer | Evidence |
|---|----------|--------|----------|
| 8.1 | What third-party sub-processors does the product use? | Sub-processors are determined entirely by the customer's configuration: AI provider (Anthropic, OpenAI, Azure OpenAI, or local), Git host (GitHub, GitLab, self-hosted), and optionally Slack. Maestro itself is not a sub-processor. | [TRUST.md §5 — Subprocessors](TRUST.md#5-subprocessors) |
| 8.2 | Can the product run without any external sub-processors? | Yes. Air-gapped mode with a locally-hosted LLM and self-hosted Git removes all external sub-processors. | [ARCHITECTURE.md §4 — True air-gapped mode](ARCHITECTURE.md#true-air-gapped-mode), [TRUST.md §7 — Air-Gapped Operation](TRUST.md#7-air-gapped-operation) |

---

## 9. Certifications & Compliance Posture

| # | Question | Answer | Evidence |
|---|----------|--------|----------|
| 9.1 | Is the product SOC 2 certified? | No SOC 2 report exists at this time. The compliance mapping documents the controls in place relative to SOC 2 Common Criteria as a readiness reference. A formal audit is planned for v3.0.0. | [COMPLIANCE-MAPPING.md — SOC2 Common Criteria](COMPLIANCE-MAPPING.md#soc2-common-criteria-tsp-2017), [TRUST.md §4 — Compliance Posture](TRUST.md#4-compliance-posture) |
| 9.2 | Is the product ISO 27001 certified? | No ISO 27001 certificate exists. The compliance mapping covers ISO/IEC 27001:2022 Annex A controls as a gap-analysis baseline. | [COMPLIANCE-MAPPING.md — ISO/IEC 27001:2022 Annex A](COMPLIANCE-MAPPING.md#isoiec-270012022-annex-a) |
| 9.3 | Is the product GDPR-compliant? | Maestro provides tooling to support the customer's GDPR obligations (identity encryption, data-subject rights CLI, data-classification annotations). Because all data is held by the customer, the customer is the data controller. | [ENTERPRISE-SECURITY.md §6 — Identity privacy + GDPR](ENTERPRISE-SECURITY.md#6-identity-privacy--gdpr) |
| 9.4 | Does the product support HIPAA workloads? | Not formally certified. Customers running HIPAA workloads should use air-gapped mode with a HIPAA-eligible AI provider and apply their own BAA with that provider. | [TRUST.md §4 — Compliance Posture](TRUST.md#4-compliance-posture) |

---

## 10. Data Retention & Deletion

| # | Question | Answer | Evidence |
|---|----------|--------|----------|
| 10.1 | What is the data retention policy? | Maestro imposes no automatic retention or deletion schedule. All artefacts live in the customer's Git repository and file system; the customer sets retention policy. | [ENTERPRISE-SECURITY.md §6 — Data-subject-rights tooling](ENTERPRISE-SECURITY.md#data-subject-rights-tooling) |
| 10.2 | Can customer data be deleted on request? | Yes. The `mso purge` tooling (v3.0.0 roadmap) provides data-subject-rights deletion. In the current release, operators delete artefacts directly from the workspace Git repository. Because Maestro holds no copies, deletion from the customer's repo is complete and immediate. | [ENTERPRISE-SECURITY.md §6 — Data-subject-rights tooling](ENTERPRISE-SECURITY.md#data-subject-rights-tooling) |
| 10.3 | Does Maestro retain backups of customer data? | No. Maestro does not operate servers or backup infrastructure. Backup and restore tooling (`mso backup` / `mso restore`) runs locally and writes to the customer's own storage. | [ENTERPRISE-SECURITY.md §4 — Data-residency controls](ENTERPRISE-SECURITY.md#4-data-residency-controls) |

---

## 11. Network & Infrastructure Security

| # | Question | Answer | Evidence |
|---|----------|--------|----------|
| 11.1 | What network ports does the product open? | Maestro opens no inbound ports. The Slack bridge (if configured) makes outbound WebSocket connections only. | [ARCHITECTURE.md §3 — Egress Inventory](ARCHITECTURE.md#3-egress-inventory) |
| 11.2 | Does the product support network egress restrictions? | Yes. A minimal egress allowlist is documented; operators can configure firewall rules to restrict outbound traffic to only the required hostnames. Full air-gap is also supported. | [ARCHITECTURE.md §4 — Minimal egress allowlist](ARCHITECTURE.md#minimal-egress-allowlist-restrictive-mode) |

---

## 12. Open-Source & Supply Chain

| # | Question | Answer | Evidence |
|---|----------|--------|----------|
| 12.1 | Is the product open source? | The core framework is published on GitHub. Customers can audit all code before installation. | [TRUST.md §8 — Open-Source Security Tooling](TRUST.md#8-open-source-security-tooling) |
| 12.2 | How are third-party dependencies managed? | Dependencies are declared in `pyproject.toml` and pinned at install time. Dependency scanning is planned for v2.3.0 (VOY-ADM-2026-0024). | [TRUST.md §8 — OWASP / CWE scanning](TRUST.md#owasp--cwe-scanning-v230--voy-adm-2026-0024) |
| 12.3 | How are MCP server plugins assessed for risk? | MCP servers are classified by risk level (LOW / MEDIUM / HIGH) using a defined matrix (v2.3.0). High-risk servers require operator sign-off before a crew may invoke them. | [TRUST.md §8 — MCP server risk levels](TRUST.md#mcp-server-risk-levels-v230--voy-adm-2026-0023) |

---

*For questions not covered here, contact **maestro@tech127.com** or open a private discussion with your Maestro account contact.*
