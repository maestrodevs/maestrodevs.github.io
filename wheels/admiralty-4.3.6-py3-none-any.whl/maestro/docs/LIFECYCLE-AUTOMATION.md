# Maestro — Lifecycle Automation

Covers two post-dispatch automation features introduced in v4.3.3:

- **Idle-watchdog** — shuts the dispatcher down cleanly when all work is drained and all crews are idle for a configurable period
- **Archive-on-merge** — automatically archives voyages (and their orders) once the voyage PR is merged, via `mso voyage reconcile`

Both are controlled by the `completion` block in `.mso/config/workspace.json`.

---

## Contents

- [Completion config block](#completion-config-block)
- [Idle-watchdog](#idle-watchdog)
- [Archive-on-merge](#archive-on-merge)
- [mso voyage reconcile](#mso-voyage-reconcile)
- [Release chain stays manual](#release-chain-stays-manual)
- [Per-org configuration guidance](#per-org-configuration-guidance)

---

## Completion config block

Add or edit the `completion` key in `.mso/config/workspace.json`:

```json
{
  "completion": {
    "idleWatchdog": {
      "enabled": true,
      "idleMinutes": 30,
      "action": "cleanup"
    },
    "onVoyageComplete": {
      "archiveVoyageOnMerge": true,
      "archiveOrders": true,
      "autoRelease": false
    }
  }
}
```

Omitting the `completion` block entirely is safe — all fields fall back to the defaults shown above, preserving behaviour from versions before v4.3.3.

---

## Idle-watchdog

### What it does

The idle-watchdog fires when **all** of the following conditions hold simultaneously:

1. No crew slot has a RUNNING process
2. No orders are in PENDING state
3. The above has been true for longer than `idleMinutes` (default: 30)

When the threshold is reached, the watchdog takes the action specified by the `action` field.

### Safety guarantee

The watchdog **never** fires while any crew slot has an active process. The idle timer resets the instant a crew transitions to RUNNING.

### Actions

| Action | Behaviour |
|--------|-----------|
| `"cleanup"` | (default) Run `mso cleanup` (rogue-process kill + stale-state clear), then exit the dispatcher. Emits `IDLE_REAP` lifecycle event. |
| `"warn"` | Emit `IDLE_TIMEOUT` lifecycle event and continue. The dispatcher keeps running; useful when you expect new orders to arrive. |
| `"none"` | No action. The dispatcher runs indefinitely regardless of idle time. |

### Lifecycle events

| Event | When it fires |
|-------|--------------|
| `IDLE_TIMEOUT` | `action=warn` path: idle threshold exceeded but dispatcher continues. |
| `IDLE_REAP` | `action=cleanup` path: idle threshold exceeded, cleanup run, dispatcher exiting. |

### Config reference

| Field | Default | Description |
|-------|---------|-------------|
| `enabled` | `true` | Set `false` to disable the watchdog entirely. |
| `idleMinutes` | `30` | Minutes of all-crews-idle + no-pending-work before action fires. |
| `action` | `"cleanup"` | One of `"cleanup"`, `"warn"`, `"none"`. |

---

## Archive-on-merge

### What it does

When `archiveVoyageOnMerge: true`, `mso voyage reconcile` detects that a voyage's PR has been merged into main and automatically:

1. Moves the voyage JSON from `voyages/active/` to `voyages/complete/`, adding merge metadata (merged-at timestamp, PR number)
2. If `archiveOrders: true`, also moves the voyage's order JSONs from `queues/*/` or `orders/active/` to `orders/complete/`, and sweeps prompt files to `prompts/complete/`

### What merge metadata is added

```json
{
  "status": "COMPLETE",
  "mergedAt": "2026-05-23T14:22:00Z",
  "mergedPR": 102,
  "mergedBy": "tavisbasing"
}
```

### Config reference

| Field | Default | Description |
|-------|---------|-------------|
| `archiveVoyageOnMerge` | `true` | Move voyage JSON to `voyages/complete/` when PR is merged. |
| `archiveOrders` | `true` | Also archive the voyage's orders and prompt files. |
| `autoRelease` | `false` | Not implemented — wired to `false`. See [Release chain stays manual](#release-chain-stays-manual). |

---

## mso voyage reconcile

`mso voyage reconcile` is the command that performs the archive-on-merge sweep. It runs automatically at dispatcher startup (as of v4.3.3) and is also available as a standalone command.

```bash
# Archive all merged voyages
mso voyage reconcile

# Preview without mutating any files
mso voyage reconcile --dry-run

# Target a single voyage
mso voyage reconcile --voyage VOY-MSO-2026-0049
```

### How it works

For each voyage in `voyages/active/`, the reconciler:

1. Looks up the voyage's `prNumber` field (set when the PR was created)
2. Calls the GitHub API to check whether the PR is merged
3. If merged and `archiveVoyageOnMerge: true` — archives the voyage (and orders if `archiveOrders: true`)
4. Writes a summary to the lifecycle log

### When to run manually

- After merging a voyage PR outside of a live dispatcher session
- To clean up multiple stale voyages at once
- Before running `mso status` so the dashboard reflects the current state

---

## Release chain stays manual

`autoRelease` exists in the config schema but is **not implemented** and defaults to `false`.

The publish-to-PyPI release chain requires human sign-off at every step:

1. Captain reviews and approves the feature/fix PR
2. Captain explicitly authorises the version bump and release PR
3. Captain confirms the tag push (`git push origin v<N>`)
4. Wheel publish is triggered by the tag via CI, not by Maestro

This gate is intentional. Automated releases without human review would make it trivially easy to ship a broken or insecure wheel to all operator workstations. Even when `autoRelease` is eventually implemented, it will require an explicit opt-in with additional safeguards (branch protection checks, mandatory QA gate pass, Captain confirmation webhook).

**Operator action required:** Do not set `autoRelease: true` — it has no effect and will log a warning.

---

## Per-org configuration guidance

### Continuous-dispatcher orgs

If your team runs the dispatcher 24/7 and expects new orders to arrive at any time, disable the idle-watchdog or set `action: "warn"` to avoid unexpected dispatcher termination:

```json
{
  "completion": {
    "idleWatchdog": {
      "enabled": false
    }
  }
}
```

Or, if you want visibility into idle periods without termination:

```json
{
  "completion": {
    "idleWatchdog": {
      "enabled": true,
      "idleMinutes": 60,
      "action": "warn"
    }
  }
}
```

### CI environments

In CI, you typically want the dispatcher to exit as soon as all work is drained. A short idle timeout ensures the dispatcher exits promptly after the last crew finishes:

```json
{
  "completion": {
    "idleWatchdog": {
      "enabled": true,
      "idleMinutes": 5,
      "action": "cleanup"
    }
  }
}
```

### Archive-on-merge in monorepos

If your team manages multiple projects in one Maestro workspace, `mso voyage reconcile` checks each active voyage's `prNumber` independently. There is no cross-project interference — each voyage archives only when its own PR is merged.

---

*See also: [OPERATOR-GUIDE.md](OPERATOR-GUIDE.md) | [CREW-INVOCATION.md](CREW-INVOCATION.md) | [TROUBLESHOOTING.md](TROUBLESHOOTING.md)*
