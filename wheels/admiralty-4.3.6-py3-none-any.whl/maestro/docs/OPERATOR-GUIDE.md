# Maestro — Operator Guide

> For teams running Maestro in production. Covers day-to-day operations, scaling, cost control, failure handling, notifications, and reporting. For initial setup, see [GETTING-STARTED.md](GETTING-STARTED.md).

> **Version scope:** This guide covers features through **v2.0.0**. Commands and flags marked with a version tag (e.g., `--retry-failed` in a planned release, `mso replay/export/notify` in a planned release) are not yet available in the current release. Sections describing future features are included so operators can plan ahead.

---

## Contents

1. [Daily Operations](#1-daily-operations)
2. [Scaling Crews](#2-scaling-crews)
3. [Cost Management](#3-cost-management)
4. [Handling Failures](#4-handling-failures)
5. [Backup Strategy](#5-backup-strategy)
6. [Notification Setup](#6-notification-setup)
7. [Multi-Project Operations](#7-multi-project-operations)
8. [Performance Tuning](#8-performance-tuning)
9. [Team Workflows](#9-team-workflows)
10. [Reporting](#10-reporting)

---

## 1. Daily Operations

### Morning checklist

Start each day by reviewing the current fleet state:

```bash
# Check overall fleet status
mso status --once

# Check pending orders
mso status --once --compact

# Review token usage since yesterday
mso usage --summary
```

### Dispatching work

Queue orders for the day, then launch the dispatcher:

```bash
# Standard launch — up to 3 concurrent crews
mso dispatch --max-crews 3

# Clean up any stale state from previous runs first
mso dispatch --cleanup --max-crews 3
```

The dispatcher runs until all queued orders are processed or the session is interrupted. Leave it running in a dedicated terminal; it manages itself.

### Monitoring running crews

```bash
# Live dashboard (auto-refreshes)
mso status

# Watch a specific crew
mso crew --crew 1 --watch

# One-shot snapshot (for scripting)
mso status --once
```

The **APPROVALS** panel appears in the dashboard when items are waiting for your sign-off — voyages, plans, or requirements with `AWAITING_APPROVAL` status. Review these promptly; crews may be blocked waiting for your decision.

The **ESCALATIONS** panel appears when a crew has raised a blocking issue it cannot resolve autonomously. Check `.maestro/queues/escalations/` for details and take the indicated action.

### End-of-day shutdown

The dispatcher will stop itself when all queues are drained. If you need to stop it early:

```bash
# Check whether dispatcher is still running
mso status --once

# If crews are stalled, clean up
mso cleanup
```

`mso cleanup` creates an automatic backup before removing stale state — your work is safe.

### Checking completed work

```bash
# List completed orders
ls .maestro/orders/complete/

# Review a specific order
cat .maestro/orders/complete/FTR-MYPROJ-2026-0001.json

# Check what changed (crews commit to voyage branches)
git log --oneline voyage/VOY-MYPROJ-2026-0001
```

---

## 2. Scaling Crews

### Concurrency limits

Maestro supports 1–5 concurrent crews. The right number depends on your API tier and the nature of the work:

| Crew count | Suitable for |
|-----------|-------------|
| 1–2 | Exploratory work, tight budget, sequential dependencies |
| 3 | Standard daily operations — balances throughput and rate pressure |
| 4–5 | Large voyages with independent parallel orders; high-tier API access |

```bash
# Run 5 crews in parallel
mso dispatch --max-crews 5

# Conservative: 2 crews for sensitive or high-cost orders
mso dispatch --max-crews 2
```

### Stagger delay

When launching multiple crews, Maestro staggers crew starts to reduce API rate pressure. The default is 30 seconds between crew launches:

```bash
# Slower stagger for large crews or shared API keys
mso dispatch --max-crews 5 --stagger-delay 60

# Faster stagger if you have a high rate limit
mso dispatch --max-crews 5 --stagger-delay 15
```

### Per-crew timeouts

The default crew timeout is 90 minutes. Complex orders (large features, full test suites) may need more:

```bash
# Allow 3 hours per crew for complex orders
mso dispatch --max-crews 3 --timeout 180

# Shorter timeout for documentation or investigation orders
mso dispatch --max-crews 5 --timeout 45
```

When a crew exceeds its timeout, it is marked failed and the order is moved to the retry queue. Automatic retry behavior is determined by the dispatcher; failed orders are retried until they succeed or are manually removed from the queue.

> **Planned:** The `--retry-failed N` flag will allow bounding automatic retries:
> ```bash
> mso dispatch --max-crews 3 --retry-failed 2
> ```

### Queue priority

The dispatcher processes queues in priority order. If you need work done urgently, place the order in a higher-priority queue:

| Queue | Priority | Use for |
|-------|---------|---------|
| `queues/explicit/` | Highest | Captain-directed urgent work |
| `queues/security/` | High | Security findings |
| `queues/bugs/` | High | Production bugs |
| `queues/requests/` | Medium-High | User-facing requests |
| `queues/orders/` | Medium | Standard feature work |
| `queues/defects/` | Medium-Low | Non-critical defects |
| `queues/breakdown/` | Low | Sub-tasks broken down from higher-level work |
| `queues/high-level/` | Lowest | High-level work awaiting breakdown |

```bash
# Place an order in the explicit queue for immediate pickup
cp .maestro/queues/orders/BUG-MYPROJ-2026-0042.json .maestro/queues/explicit/
```

### Horizontal scaling considerations

Each crew runs as an independent `claude` subprocess. On a shared machine, ensure:

- Sufficient RAM: each crew session consumes ~500MB–1GB
- Your API key has sufficient rate limits for your crew count
- Use `--stagger-delay` to spread API calls in time

---

## 3. Cost Management

### Understanding billing modes

Maestro supports two billing modes, configured in `.maestro/config/fleet-settings.json`:

| Mode | How cost is counted | Use when |
|------|-------------------|---------|
| `api` | USD cost based on token pricing | Paying per-token via Anthropic API |
| `max` | Token count against a daily cap | On a Claude Max subscription with token limits |

### Checking costs

```bash
# Overall usage summary
mso usage --summary

# Breakdown by voyage
mso usage --voyage VOY-MYPROJ-2026-0001

# Token detail for a specific order
mso usage --order FTR-MYPROJ-2026-0001

# Full usage report to file
mso usage --report --output .maestro/reports/usage-$(date +%Y-%m-%d).md
```

### Setting budget limits

Configure a daily budget in `.maestro/config/fleet-settings.json`:

```json
{
  "billingMode": "api",
  "budget": 50.00,
  "dailyTokenCap": 0
}
```

When usage reaches 80% of the budget, a `budget-warning` notification fires. At 100%, a `budget-exceeded` notification fires. See [Notification Setup](#6-notification-setup) for how to receive these alerts.

For `max` billing mode:

```json
{
  "billingMode": "max",
  "budget": 0,
  "dailyTokenCap": 5000000
}
```

### Cost-efficient order design

- **Scope orders tightly.** A single focused order (one endpoint, one component) is faster and cheaper than a broad order.
- **Use lower-complexity roles for lower-complexity work.** Lookout (Haiku) is significantly cheaper than Navigator or Shipwright (Sonnet) for investigation tasks.
- **Group documentation orders.** `DOC` orders are cheap; batch them together in one voyage rather than dispatching individually.
- **Set `--timeout` appropriately.** Long timeouts allow crews to explore when they're stuck; short timeouts force faster completion or escalation.
- **Review `export roi`.** The ROI export shows which order types deliver the most value per dollar spent. Use this to guide your backlog priorities.

### Exporting cost data

```bash
# Export all order costs to CSV
mso export orders --format csv --output orders-cost.csv

# ROI analysis for the last month
mso export roi --hourly-rate 150 --from 2026-04-01 --to 2026-04-30 --output roi-april.csv

# Usage breakdown by day
mso export usage --format csv --output usage.csv
```

---

## 4. Handling Failures

### Types of failure

| Failure type | Symptom | Action |
|-------------|---------|--------|
| Crew crash | Crew status shows CRASHED | Run `mso cleanup`, then `mso dispatch` |
| Order timeout | Order marked FAILED after timeout | Replay with `mso replay` |
| Dependency block | Order shows QUEUED but not picked up | Check `dependsOn` fields; ensure prerequisites are complete |
| API error | Crew exits with API error in activity | Check API key, rate limits; retry after a pause |
| Escalation | ESCALATIONS panel appears in dashboard | Read escalation file, take indicated action, re-dispatch |

### Checking what went wrong

```bash
# Check crew activity for a specific crew
cat .maestro/crews/crew2/activity.txt

# Check crew progress log
cat .maestro/crews/crew2/progress.md

# List failed orders
ls .maestro/orders/failed/

# Inspect a failed order
cat .maestro/orders/failed/FTR-MYPROJ-2026-0001.json

# Check escalations
ls .maestro/queues/escalations/
cat .maestro/queues/escalations/ESC-MYPROJ-2026-0001.json
```

### Replaying a failed order

Use `mso replay` to re-queue a failed or stalled order for another attempt:

```bash
# Re-queue a single order
mso replay FTR-MYPROJ-2026-0001

# Replay with a different role (e.g. escalate to Coxswain for integration issues)
mso replay FTR-MYPROJ-2026-0001 --role COX

# Replay all failed orders from a voyage
mso replay --voyage VOY-MYPROJ-2026-0001 --failed-only

# Replay ALL orders from a voyage (re-run the whole voyage)
mso replay --voyage VOY-MYPROJ-2026-0001
```

The original order is preserved in `.maestro/orders/failed/` before re-queuing. A `retryCount` field is incremented on each replay.

### Automatic retry limits

When dispatching, use `--retry-failed` to cap how many times a crashing order is automatically retried:

```bash
# Orders that crash more than 3 times are permanently failed
mso dispatch --max-crews 3 --retry-failed 3
```

Without `--retry-failed`, crashed orders are retried indefinitely. Setting a limit prevents a bad order from consuming repeated compute budget.

### Handling stale state

After an unexpected interruption (machine restart, OOM kill, network loss), clean up before re-dispatching:

```bash
mso cleanup
mso dispatch --max-crews 3
```

`cleanup` will:
1. Create a full backup snapshot
2. Terminate any orphaned crew processes
3. Remove stale lock files
4. Reset idle crew state

---

## 5. Backup Strategy

### What gets backed up

The `mso backup` command archives:

- All orders (active, complete, failed)
- All voyages (active, complete)
- Plans, handoffs, and requirements
- Usage records
- Workspace configuration

Framework scripts (`.maestro/core/`) are excluded — they are provided by pip or the submodule and do not need backup.

### Recommended backup schedule

| Frequency | Command | Rationale |
|-----------|---------|-----------|
| Before each cleanup | Automatic | `mso cleanup` creates a backup automatically |
| End of each voyage | Manual | Capture the complete voyage state |
| Weekly | Cron / scheduled | Safety net for continuous workspaces |
| Before framework upgrades | Manual | Preserve state before upgrading Maestro |

### Creating backups

```bash
# Full workspace backup
mso backup

# Single project (multi-project workspaces)
mso backup --project OTM

# Custom output directory
mso backup --output /mnt/backups/maestro/

# List existing backups
mso backup --list
```

Backups are ZIP archives named with the scope and timestamp:
```
maestro-backups/maestro-backup-all-2026-04-01-090000.zip
```

### Restoring from backup

Always preview before restoring into an active workspace:

```bash
# Preview what would be restored
mso restore maestro-backup-all-2026-04-01-090000.zip --dry-run

# Restore, skipping files that already exist (default — safe)
mso restore maestro-backup-all-2026-04-01-090000.zip

# Restore only one project from a full backup
mso restore maestro-backup-all-2026-04-01-090000.zip --project OTM

# Overwrite existing files unconditionally (use for clean slate restore)
mso restore maestro-backup-all-2026-04-01-090000.zip --force

# Keep the newer file when conflicts occur (use for merging two workspaces)
mso restore maestro-backup-all-2026-04-01-090000.zip --merge
```

### Offsite backup strategy

Maestro backups are local ZIP files. For durable offsite backup:

```bash
# After backup, copy to S3 (example)
mso backup --output /tmp/maestro-backups/
aws s3 cp /tmp/maestro-backups/ s3://your-bucket/maestro/ --recursive

# Or to a mounted network drive
mso backup --output /mnt/nas/backups/maestro/
```

For git-tracked workspaces, commit the backup archive to a separate branch or push to a private storage repo.

---

## 6. Notification Setup

### Overview

Maestro can send webhook notifications when significant fleet events occur. Supported platforms: Slack, Microsoft Teams, Discord, and any service that accepts HTTP POST with a JSON body.

### Adding a webhook

```bash
# Subscribe to all events
mso notify add --name my-webhook --url https://hooks.example.com/abc123

# Subscribe to specific events only
mso notify add --name slack-ops --url https://hooks.slack.com/services/... \
  --events voyage-complete,crew-crash,budget-warning

# Teams webhook
mso notify add --name teams-alerts \
  --url https://yourorg.webhook.office.com/webhookb2/... \
  --events order-failed,budget-exceeded,dispatch-complete
```

### Available events

| Event | Fires when |
|-------|-----------|
| `order-complete` | A crew completes an order successfully |
| `order-failed` | An order is permanently failed or stalled |
| `crew-crash` | A crew process crashes unexpectedly |
| `voyage-complete` | All orders in a voyage are complete |
| `budget-warning` | Usage reaches 80% of the configured budget |
| `budget-exceeded` | Usage reaches 100% of the configured budget |
| `approval-needed` | A plan or voyage is awaiting captain sign-off |
| `dispatch-complete` | All queues are drained and all crews are idle |

Omit `--events` to subscribe to all events.

### Listing and testing webhooks

```bash
# List all configured webhooks
mso notify list

# Send a test payload to verify connectivity
mso notify test slack-ops
```

The test command sends a synthetic payload to confirm the URL is reachable. No real fleet event is generated.

### Removing a webhook

```bash
mso notify remove slack-ops
```

### Webhook payload format

All webhook payloads share a common envelope:

```json
{
  "event": "voyage-complete",
  "timestamp": "2026-04-01T09:15:00Z",
  "maestroVersion": "2.0.0",
  "data": {
    "voyageId": "VOY-MYPROJ-2026-0001",
    "title": "Sprint 1 features",
    "ordersComplete": 5,
    "totalTokens": 450000,
    "totalCostUSD": 3.20,
    "billingMode": "api",
    "totalDurationMinutes": 87
  }
}
```

For Slack, Teams, and Discord URLs, the payload is automatically adapted to include a human-readable summary line in the platform's native format. Generic webhook URLs receive the raw Maestro JSON payload unchanged.

### Configuration file

Webhook configuration is stored in `.maestro/config/webhooks.json`. You can edit this file directly to manage multiple webhooks:

```json
{
  "webhooks": [
    {
      "name": "slack-ops",
      "url": "https://hooks.slack.com/services/T.../B.../xxx",
      "events": ["voyage-complete", "crew-crash", "budget-warning"]
    },
    {
      "name": "teams-alerts",
      "url": "https://yourorg.webhook.office.com/webhookb2/...",
      "events": []
    }
  ]
}
```

An empty `events` list subscribes the webhook to all events.

---

## 7. Multi-Project Operations

### Workspace structure for multiple projects

A single Maestro workspace can manage multiple projects simultaneously. Each project has its own:

- Configuration: `.maestro/config/projects/{ACRONYM}.json`
- Orders: prefixed `{TYPE}-{ACRONYM}-{YEAR}-{SEQ}`
- Voyages: prefixed `VOY-{ACRONYM}-{YEAR}-{SEQ}`
- Repository clone: managed in the directory specified by `projects.json`

### Registering a new project

Edit `.maestro/config/projects.json` to add the project:

```json
{
  "projects": {
    "PROJ1": {
      "name": "Project One",
      "acronym": "PROJ1",
      "directory": "proj1",
      "repo": "your-org/proj1",
      "org": "your-org",
      "defaultBranch": "main",
      "voyageBranchPattern": "voyage/{VOYAGE-ID}"
    },
    "PROJ2": {
      "name": "Project Two",
      "acronym": "PROJ2",
      "directory": "proj2",
      "repo": "your-org/proj2",
      "org": "your-org",
      "defaultBranch": "main",
      "voyageBranchPattern": "voyage/{VOYAGE-ID}"
    }
  }
}
```

Create a per-project role configuration at `.maestro/config/projects/PROJ2.json`.

### Dispatching across projects

The dispatcher picks up orders from all projects simultaneously. Orders carry a `project` field that routes them to the correct repo and configuration:

```bash
# Dispatch work across all projects
mso dispatch --max-crews 5
```

Crews are assigned to orders from any project. If you need to limit work to a specific project, place only that project's orders in the queues.

### Per-project usage tracking

```bash
# Usage for a specific voyage (project-scoped by voyage ID convention)
mso usage --voyage VOY-PROJ1-2026-0001

# Export all orders for PROJ1
mso export orders --format csv --output proj1-orders.csv
# Then filter by the "project" column in the CSV
```

### Per-project backups

```bash
# Back up only PROJ1 (leaves PROJ2 data out of the archive)
mso backup --project PROJ1

# Restore PROJ1 to a new workspace
mso restore maestro-backup-PROJ1-2026-04-01-090000.zip --project PROJ1
```

### Coordination patterns for multi-project work

**Sequential cross-project dependency:** If work in PROJ2 depends on a completed order in PROJ1, use the `dependsOn` field in the PROJ2 order to reference the PROJ1 order ID. The dispatcher will hold the PROJ2 order until the dependency is complete.

**Dedicated voyage per project:** Keep voyages project-scoped (a single voyage covers only one project). This makes progress tracking, backup scoping, and usage reporting cleaner.

**Role allocation:** If PROJ1 work is all Shipwright orders and PROJ2 work is all Navigator orders, they can run concurrently without role contention.

---

## 8. Performance Tuning

### Dispatcher configuration

The key levers for dispatcher performance are `--max-crews`, `--stagger-delay`, and `--timeout`. See [Scaling Crews](#2-scaling-crews) for guidance on values.

For workspaces with many small orders, increase `--max-crews` and decrease `--stagger-delay`. For workspaces with few large orders, a smaller crew count with a longer timeout is more appropriate.

### Dependency graph design

Orders with `dependsOn` dependencies are held until all prerequisites complete. Poor dependency design creates bottlenecks:

- **Avoid fan-in from many orders to one.** If 10 orders all feed into a single integration order, the integration order cannot start until all 10 finish. Restructure to allow incremental integration.
- **Favour parallel voyages.** Group independent work into separate voyages. The dispatcher picks up work from all voyages simultaneously.
- **Reserve the explicit queue** for unblocking stalled work, not for routine prioritisation.

### Model selection

Each role uses a default model. The models differ significantly in cost and capability:

| Role | Model | Relative cost |
|------|-------|--------------|
| Lookout (LKT) | Haiku 4.5 | Low |
| Navigator (NAV) | Sonnet 4.6 | Medium |
| Shipwright (SHP) | Sonnet 4.6 | Medium |
| Bosun (BOS) | Sonnet 4.6 | Medium |
| Scribe (SCR) | Sonnet 4.6 | Medium |
| Coxswain (COX) | Opus 4.7 | High |

Route investigation and triage work to Lookout to minimise cost. Reserve Coxswain for integration and deployment work that genuinely benefits from Opus-class capability.

### Order scoping for throughput

Well-scoped orders complete faster and cheaper than broad ones. General guidance:

- **One concern per order.** An order to "implement the cart service" is too broad. Break it into: create data model, implement service layer, add API endpoints, write tests.
- **Reference target files explicitly.** Orders with `targetFiles` set allow crews to navigate the codebase faster.
- **Write precise acceptance criteria.** Vague acceptance criteria cause crews to over-explore. Each criterion should be independently verifiable.

### Cache-aware API usage

The Anthropic API caches prompt prefixes, reducing cost and latency for repeated context. Maestro benefits from this when:

- Your workspace `CLAUDE.md` is stable (cached across all crew sessions)
- Orders within a voyage share large context blocks (project config, role paths)

Avoid changing `CLAUDE.md` or role config files mid-voyage; doing so invalidates the cache and increases per-crew token cost.

---

## 9. Team Workflows

### Captain / operator responsibilities

The **Captain** (human operator) is responsible for:

- Approving voyages, plans, and requirements before crews proceed
- Reviewing escalations and providing direction to unblocked crews
- Merging completed voyage branches back to main
- Monitoring daily usage and cost
- Running `mso cleanup` and `mso dispatch` to keep the fleet moving

### Handling approvals

When the **APPROVALS** panel appears in the dashboard:

1. Identify the item (voyage, plan, or requirement) listed
2. Read the relevant file in `.maestro/plans/` or `.maestro/voyages/active/`
3. Update the `status` field to `APPROVED` or `REJECTED` with a note
4. Crews waiting on the approval will resume automatically on the next dispatch

```bash
# Find files awaiting approval
grep -r "AWAITING_APPROVAL" .maestro/plans/ .maestro/voyages/
```

### Code review workflow

Crew output is committed to voyage branches. Typical review flow:

1. `mso verify --voyage VOY-MYPROJ-2026-0001` — run build and tests
2. `git log --oneline voyage/VOY-MYPROJ-2026-0001` — review commits
3. Open a pull request from the voyage branch to `main`
4. Review and merge via standard PR process

### Shared workspace (team of operators)

If multiple operators share a single Maestro workspace:

- Only one operator should run `mso dispatch` at a time
- Coordinate on which orders are in which queues before dispatching
- Use the notification system to alert the team when a voyage completes or when approvals are needed (see [Notification Setup](#6-notification-setup))
- Back up the workspace at the end of each operator's session

### Escalation handling protocol

When a crew raises an escalation:

1. The ESCALATIONS panel appears in the dashboard (red)
2. Read the escalation file: `.maestro/queues/escalations/{ESC-ID}.json`
3. Determine the blocking issue (dependency, ambiguity, permissions, etc.)
4. Take the action indicated: update an order, provide a missing credential, clarify requirements
5. Remove the escalation file once resolved
6. Re-dispatch: `mso dispatch --max-crews 3`

---

## 10. Reporting

### Usage reports

```bash
# Console summary (daily use)
mso usage --summary

# Per-voyage breakdown
mso usage --voyage VOY-MYPROJ-2026-0001

# Full report to markdown (weekly use)
mso usage --report --output .maestro/reports/usage-$(date +%Y-%m-%d).md
```

### Exporting data for external tools

Use `mso export` to produce CSV or JSON data suitable for spreadsheets, BI tools, or management reports.

**All completed orders:**
```bash
mso export orders --format csv --output orders.csv
```

CSV columns: `orderId, project, type, role, title, status, startedAt, completedAt, tokensInput, tokensOutput, costUSD, hoursEquivalent`

**All voyages with aggregate stats:**
```bash
mso export voyages --format csv --output voyages.csv
```

CSV columns: `voyageId, project, title, status, ordersTotal, ordersComplete, ordersStalled, startedAt, completedAt, totalTokens, totalCostUSD, hoursEquivalent`

**Daily token usage breakdown:**
```bash
mso export usage --format csv --output usage.csv
```

CSV columns: `date, orderId, crewNumber, totalTokens, tokensInput, tokensOutput, cacheCreationTokens, cacheReadTokens, costUSD`

**ROI summary for management reporting:**
```bash
# Monthly ROI at $150/hr developer rate
mso export roi --hourly-rate 150 --format csv --output roi-summary.csv

# Specific date range
mso export roi --hourly-rate 150 --from 2026-04-01 --to 2026-04-30 --output roi-april.csv
```

CSV columns: `month, ordersCompleted, apiCostUSD, hoursEquivalent, hoursSaved, valueSavedUSD, roiMultiple`

`roiMultiple` expresses value saved divided by API cost — a `roiMultiple` of 30 means the fleet delivered 30x return on its API spend.

### Date filtering

All export commands accept `--from` and `--to` date filters (inclusive, format `YYYY-MM-DD`):

```bash
# Last quarter
mso export orders --from 2026-01-01 --to 2026-03-31 --output q1-orders.csv

# This week
mso export usage --from 2026-04-01 --to 2026-04-07 --output this-week.csv
```

### JSON output

All export commands support `--format json` for programmatic consumption:

```bash
mso export orders --format json --output orders.json
mso export roi --hourly-rate 150 --format json
```

JSON output is an array of flat objects using the same field names as the CSV columns.

### Lifecycle and audit log

The fleet writes lifecycle events to `.maestro/logs/lifecycle.log` (crew starts, completions, role transitions, failures). This log provides an audit trail of all fleet activity.

```bash
# Recent lifecycle events
tail -50 .maestro/logs/lifecycle.log

# Filter for failures
grep FAILED .maestro/logs/lifecycle.log
```

---

*Maestro Maestro v2.0.0 — For licensing enquiries, contact [tavisbasing](https://github.com/tavisbasing).*
