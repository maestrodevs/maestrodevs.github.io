# Maestro Security Overview

> One-page security summary for procurement + risk teams.
> For technical depth see [ENTERPRISE-SECURITY.md](ENTERPRISE-SECURITY.md) and [COMPLIANCE-MAPPING.md](COMPLIANCE-MAPPING.md).

---

## What Maestro is, security-wise

- A CLI Python package installed on your operators' machines
- No Maestro-operated servers — nothing leaves your environment unless you configure an external API
- Your code, your AI provider, your audit log — all stored on your infrastructure

---

## How your data flows

```mermaid
flowchart LR
    subgraph Customer["Customer Infrastructure (your environment)"]
        direction TB
        DEV["Your laptop / CI pipeline"]
        GIT["Self-hosted Git\nor GitHub / GitLab"]
        LLM_LOCAL["On-prem LLM\n(air-gap mode)"]
        ARTEFACTS[".mso/ workspace\norders · plans · audit log\nAll artefacts stored here"]
    end

    subgraph Maestro["Maestro Framework (pip package)"]
        direction TB
        CLI["mso CLI"]
        NOTE["No Maestro-operated servers\nNo telemetry · No phone-home\nNo data leaves without your config"]
    end

    subgraph External["Optional External Services (opt-out available)"]
        direction TB
        ANTHROPIC["Anthropic API\nTLS encrypted · prompts only\nOpt-out: use local LLM"]
        GITHUB["GitHub API\nTLS encrypted · repo operations\nOpt-out: self-hosted Git"]
        SLACK["Slack\nTLS encrypted · notifications\nOpt-out: disable bridge"]
    end

    Customer <--> Maestro
    Maestro -.->|"configurable —\nopt-out available"| External

    classDef customerStyle fill:#27ae60,color:#fff,stroke:#1e8449
    classDef maestroStyle fill:#2980b9,color:#fff,stroke:#1a5276
    classDef externalStyle fill:#7f8c8d,color:#fff,stroke:#636e72
```

---

## How Maestro protects you (the 60-second version)

| Threat | Maestro's answer |
|--------|-----------------|
| Stolen operator credentials | Identity + ACL (§1) — every action attributable + capability-gated |
| Insider tampering with audit trail | Cryptographic hash chain + external anchoring (§2) |
| Accidental secret exfiltration | Lazy-loaded secret refs + central scrub + subprocess env-strip (§3) |
| Unintended data egress | Egress filter with allowlist + air-gap mode (§4) |
| Over-privileged staff | Operator role separation: Captain / Fleet Operator / Contributor / Auditor (§5) |
| GDPR Art. 15 / 17 / 18 requests | Built-in `mso identity rights` CLI (§6) |

---

## Compliance posture (one-line summary)

Maestro does not hold certifications today, but its features support the controls in SOC2 Common Criteria and ISO/IEC 27001:2022 Annex A — see [COMPLIANCE-MAPPING.md](COMPLIANCE-MAPPING.md) for the per-control mapping. Customers run their own audits on their own deployment.

---

## Known open findings

We publish what is broken. The post-implementation security review (SEC-FTR-ADM-2026-0064) identified **2 CRITICAL + 2 HIGH** open findings that block production use until patched in the v3.0.x voyage:

| ID | Severity | Summary | Workaround until patched |
|----|----------|---------|--------------------------|
| 2.2 | CRITICAL | Audit log truncation not detected by `verify_chain` | Frequent external anchoring; treat local log as append-detectable but not truncation-detectable |
| 3.1 (a) | CRITICAL | `print()` and subprocess stdout bypass the central secrets scrub | Avoid `print()` for any value derived from secrets |
| 3.1 (b) | HIGH | Logging exfil paths not exhaustively covered | Same as above |
| 4.1 | HIGH | Egress filter doesn't intercept raw socket / subprocess network | Combine with network-layer controls (firewall, egress proxy) |

**We do not recommend production enterprise deployment until the v3.0.x patch closes these findings.** The workarounds above reduce risk materially in the interim.

---

## How to report a vulnerability

**Do not open a public GitHub issue for security vulnerabilities.**

Email **maestro@tech127.com** with a reproducible description. PGP key available on request.

See [TRUST.md §6](TRUST.md#6-vulnerability-disclosure-policy) for the full disclosure policy — acknowledgement within 7 business days, status update within 30 days, coordinated disclosure timeline agreed before public release.

---

## Where to go next

| Audience | Document |
|----------|----------|
| Procurement / risk | [SECURITY-QUESTIONNAIRE.md](SECURITY-QUESTIONNAIRE.md) — SIG Lite / CAIQ Lite pre-filled |
| Audit | [COMPLIANCE-MAPPING.md](COMPLIANCE-MAPPING.md) — SOC2 + ISO27001 control mapping |
| Engineering / operators | [ENTERPRISE-SECURITY.md](ENTERPRISE-SECURITY.md) — technical detail for all 6 control areas |
| Architecture | [ARCHITECTURE.md](ARCHITECTURE.md) — system design + data flow |
