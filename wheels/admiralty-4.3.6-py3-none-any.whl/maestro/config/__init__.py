# maestro.config — Maestro default configuration
