from __future__ import annotations

import json
from pathlib import Path


class AuditPolicyError(Exception):
    """Raised when enterprise audit policy requirements are not met."""


_FS_PROVIDERS = {"fs", "filesystem"}

_PRIVILEGED_PREFIXES = (
    "fleet.",
    "dispatch.",
    "secret.",
    "identity.",
    "bridge.",
    "voyage.",
    "order.",
    "backup.",
)


def is_privileged_action(action: str) -> bool:
    return any(action.startswith(p) for p in _PRIVILEGED_PREFIXES)


def check_enterprise_anchor_policy(workspace: Path) -> None:
    """Raise AuditPolicyError if enterprise mode requires an anchor provider but none is configured.

    Emits a stderr warning when the configured provider is filesystem-only (not tamper-proof).
    """
    from maestro.workspace import resolve_artefact_dir
    ws_cfg = resolve_artefact_dir(workspace) / "config" / "workspace.json"
    if not ws_cfg.exists():
        return
    try:
        data = json.loads(ws_cfg.read_text(encoding="utf-8"))
    except Exception:
        return

    enterprise = data.get("enterprise", False)
    if isinstance(enterprise, dict):
        enterprise = True
    if not enterprise:
        return

    audit_cfg = data.get("audit", {}) if isinstance(data.get("audit"), dict) else {}
    provider = audit_cfg.get("anchorProvider")
    if not provider:
        raise AuditPolicyError(
            "enterprise: true requires audit.anchorProvider in workspace.json. "
            "Run 'mso init --enterprise' to configure one, or add:\n"
            '  "audit": {"anchorProvider": "fs"}\n'
            "to workspace.json (filesystem provider satisfies the check for dev/CI "
            "but is not tamper-proof in production)."
        )

    if provider in _FS_PROVIDERS:
        import sys
        print(
            "[Audit] WARNING: filesystem anchor provider satisfies the enterprise policy check "
            "but is NOT tamper-proof — an attacker with filesystem access can rewrite anchors. "
            "Configure an object-lock backend (s3, azure, s3-compat) for production.",
            file=sys.stderr,
        )
