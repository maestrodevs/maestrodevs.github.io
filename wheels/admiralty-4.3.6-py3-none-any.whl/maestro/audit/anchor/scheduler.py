from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from maestro.workspace import resolve_artefact_dir

_DEFAULT_MAX_AGE_MINUTES = 60


def _state_path(workspace: Path) -> Path:
    return resolve_artefact_dir(workspace) / "audit" / "anchor-state.json"


def _load_max_age(workspace: Path) -> int:
    ws_cfg = resolve_artefact_dir(workspace) / "config" / "workspace.json"
    try:
        data = json.loads(ws_cfg.read_text(encoding="utf-8"))
        return int(data.get("audit", {}).get("maxAnchorAgeMinutes", _DEFAULT_MAX_AGE_MINUTES))
    except Exception:
        return _DEFAULT_MAX_AGE_MINUTES


def record_anchor(workspace: Path) -> None:
    """Record current UTC time as the last successful anchor timestamp."""
    sp = _state_path(workspace)
    sp.parent.mkdir(parents=True, exist_ok=True)
    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
    try:
        existing: dict = {}
        if sp.exists():
            existing = json.loads(sp.read_text(encoding="utf-8"))
        existing["lastAnchorAt"] = now
        sp.write_text(json.dumps(existing, indent=2), encoding="utf-8")
    except Exception:
        pass


def check_anchor_freshness(workspace: Path) -> tuple[bool, float]:
    """Return (is_fresh, elapsed_minutes).

    is_fresh is True when the last anchor is within audit.maxAnchorAgeMinutes,
    or when no anchor has been recorded yet (nothing to be stale against).
    """
    sp = _state_path(workspace)
    if not sp.exists():
        return True, 0.0
    try:
        state = json.loads(sp.read_text(encoding="utf-8"))
        last_at = state.get("lastAnchorAt")
        if not last_at:
            return True, 0.0
        last_dt = datetime.fromisoformat(last_at.replace("Z", "+00:00"))
        elapsed = (datetime.now(timezone.utc) - last_dt).total_seconds() / 60.0
        max_age = _load_max_age(workspace)
        return elapsed <= max_age, elapsed
    except Exception:
        return True, 0.0
