from __future__ import annotations

import abc
from dataclasses import dataclass, field
from typing import Any


@dataclass
class AnchorReceipt:
    provider: str
    root_hash: str
    timestamp: str
    location: str  # provider-specific URI / path / ARN / URL
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "provider": self.provider,
            "rootHash": self.root_hash,
            "timestamp": self.timestamp,
            "location": self.location,
            "metadata": self.metadata,
        }


class Anchor(abc.ABC):
    """Abstract base for external audit-log anchoring providers."""

    @abc.abstractmethod
    def anchor(self, root_hash: str, metadata: dict[str, Any] | None = None) -> AnchorReceipt:
        """Write root_hash to immutable external storage and return a receipt."""
        ...

    @classmethod
    @abc.abstractmethod
    def from_env(cls) -> "Anchor":
        """Construct provider from environment variables (with deprecation warning)."""
        ...
