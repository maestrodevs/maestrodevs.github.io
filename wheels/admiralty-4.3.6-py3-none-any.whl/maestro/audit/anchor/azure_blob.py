from __future__ import annotations

import json
import os
import warnings
from datetime import datetime, timezone, timedelta
from typing import Any

from .base import Anchor, AnchorReceipt


class AzureBlobAnchor(Anchor):
    """
    Anchors root hashes to Azure Blob Storage with Immutable Blob policy
    (time-based retention or legal hold).

    Requires azure-storage-blob.
    """

    PROVIDER = "azure_blob"

    def __init__(
        self,
        connection_string: str,
        container: str,
        blob_prefix: str = "audit-anchors/",
        retain_days: int = 2557,  # ~7 years
    ) -> None:
        self._conn_str = connection_string
        self._container = container
        self._prefix = blob_prefix.rstrip("/") + "/"
        self._retain_days = retain_days

    def anchor(self, root_hash: str, metadata: dict[str, Any] | None = None) -> AnchorReceipt:
        try:
            from azure.storage.blob import BlobServiceClient, ImmutabilityPolicy, BlobImmutabilityPolicyMode
        except ImportError as exc:
            raise RuntimeError(
                "azure-storage-blob is required for the Azure Blob anchor provider"
            ) from exc

        ts = datetime.now(timezone.utc)
        ts_str = ts.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
        safe_ts = ts_str.replace(":", "-").replace(".", "-")
        blob_name = f"{self._prefix}anchor-{safe_ts}-{root_hash[:16]}.json"

        payload = {
            "provider": self.PROVIDER,
            "rootHash": root_hash,
            "timestamp": ts_str,
            "location": f"https://<account>.blob.core.windows.net/{self._container}/{blob_name}",
            "metadata": metadata or {},
        }

        expiry = ts + timedelta(days=self._retain_days)
        policy = ImmutabilityPolicy(
            expiry_time=expiry,
            policy_mode=BlobImmutabilityPolicyMode.LOCKED,
        )

        try:
            service = BlobServiceClient.from_connection_string(self._conn_str)
            container_client = service.get_container_client(self._container)
            blob_client = container_client.get_blob_client(blob_name)
            blob_client.upload_blob(
                json.dumps(payload, indent=2).encode(),
                content_settings=None,
                immutability_policy=policy,
            )
            url = blob_client.url
        except Exception as exc:
            raise RuntimeError(f"Azure Blob anchor failed: {exc}") from exc

        payload["location"] = url
        return AnchorReceipt(
            provider=self.PROVIDER,
            root_hash=root_hash,
            timestamp=ts_str,
            location=url,
            metadata=metadata or {},
        )

    @classmethod
    def from_env(cls) -> "AzureBlobAnchor":
        warnings.warn(
            "Azure Blob anchor configured via environment variables is deprecated; "
            "use a secrets reference in anchor config instead.",
            DeprecationWarning,
            stacklevel=3,
        )
        conn_str = os.environ.get("ADM_ANCHOR_AZURE_CONN_STR", "")
        if not conn_str:
            raise ValueError("ADM_ANCHOR_AZURE_CONN_STR environment variable is required")
        return cls(
            connection_string=conn_str,
            container=os.environ.get("ADM_ANCHOR_AZURE_CONTAINER", "maestro-audit"),
            blob_prefix=os.environ.get("ADM_ANCHOR_AZURE_BLOB_PREFIX", "audit-anchors/"),
            retain_days=int(os.environ.get("ADM_ANCHOR_AZURE_RETAIN_DAYS", "2557")),
        )
