"""
Maestro global project registry.

Manages ~/.maestro/projects.json so that `mso` commands can resolve
project workspaces by acronym from any directory using @PRJ syntax.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

REGISTRY_FILE = Path.home() / ".maestro" / "projects.json"


def _load() -> dict:
    if REGISTRY_FILE.exists():
        try:
            return json.loads(REGISTRY_FILE.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return {}
    return {}


def _save(registry: dict) -> None:
    REGISTRY_FILE.parent.mkdir(parents=True, exist_ok=True)
    REGISTRY_FILE.write_text(json.dumps(registry, indent=2), encoding="utf-8")


def register_project(acronym: str, path: Path) -> None:
    """Add or update a project entry in the global registry."""
    registry = _load()
    registry.setdefault("projects", {})
    registry["projects"][acronym.upper()] = {
        "path": str(path.resolve()),
        "registered": datetime.now(timezone.utc).isoformat(),
    }
    _save(registry)


def unregister_project(acronym: str) -> bool:
    """Remove a project from the registry. Returns True if it existed."""
    registry = _load()
    projects = registry.get("projects", {})
    key = acronym.upper()
    if key in projects:
        del projects[key]
        registry["projects"] = projects
        _save(registry)
        return True
    return False


def get_project_path(acronym: str) -> Path | None:
    """Return the registered workspace path for the given acronym, or None."""
    registry = _load()
    entry = registry.get("projects", {}).get(acronym.upper())
    if entry and "path" in entry:
        p = Path(entry["path"])
        if p.exists():
            return p
    return None


def list_projects() -> dict:
    """Return all registered projects as a dict keyed by acronym."""
    return _load().get("projects", {})
