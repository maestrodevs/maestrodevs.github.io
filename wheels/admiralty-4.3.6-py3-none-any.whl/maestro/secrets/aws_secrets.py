from __future__ import annotations

import json

from .base import SecretsProvider


class AwsSecretsManagerProvider(SecretsProvider):
    """
    AWS Secrets Manager backend.

    config options:
      region   — AWS region (default: us-east-1)
      prefix   — namespace prefix prepended to all keys (default: "maestro/")

    Authentication uses the standard boto3 credential chain
    (env vars, ~/.aws/credentials, IAM role, etc.).
    Requires: pip install maestro[aws-secrets]
    """

    def __init__(self, config: dict | None = None) -> None:
        try:
            import boto3
        except ImportError as exc:
            raise RuntimeError(
                "AWS Secrets Manager provider requires boto3. "
                "Install it with: pip install maestro[aws-secrets]"
            ) from exc

        cfg = config or {}
        region = cfg.get("region", "us-east-1")
        self._prefix = cfg.get("prefix", "maestro/")
        self._client = boto3.client("secretsmanager", region_name=region)

    def _secret_id(self, key: str) -> str:
        return f"{self._prefix}{key}"

    def get(self, key: str) -> str | None:
        try:
            resp = self._client.get_secret_value(SecretId=self._secret_id(key))
            return resp.get("SecretString")
        except Exception:
            return None

    def set(self, key: str, value: str) -> None:
        secret_id = self._secret_id(key)
        try:
            self._client.put_secret_value(SecretId=secret_id, SecretString=value)
        except self._client.exceptions.ResourceNotFoundException:
            self._client.create_secret(Name=secret_id, SecretString=value)

    def delete(self, key: str) -> None:
        try:
            self._client.delete_secret(
                SecretId=self._secret_id(key),
                ForceDeleteWithoutRecovery=True,
            )
        except Exception:
            pass

    def list(self) -> list[str]:
        prefix = self._prefix
        keys: list[str] = []
        paginator = self._client.get_paginator("list_secrets")
        for page in paginator.paginate():
            for secret in page.get("SecretList", []):
                name = secret.get("Name", "")
                if name.startswith(prefix):
                    keys.append(name[len(prefix):])
        return keys
