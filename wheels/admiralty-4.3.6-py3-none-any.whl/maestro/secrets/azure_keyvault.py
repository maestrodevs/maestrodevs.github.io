from __future__ import annotations

from .base import SecretsProvider


class AzureKeyVaultSecretsProvider(SecretsProvider):
    """
    Azure Key Vault secrets backend.

    config options:
      vault_url  — Key Vault URI, e.g. https://my-vault.vault.azure.net/
      prefix     — optional key prefix (default: "")

    Authentication uses DefaultAzureCredential (env vars, managed identity, CLI, etc.).
    Requires: pip install maestro[azure-secrets]
    """

    def __init__(self, config: dict | None = None) -> None:
        try:
            from azure.keyvault.secrets import SecretClient
            from azure.identity import DefaultAzureCredential
        except ImportError as exc:
            raise RuntimeError(
                "Azure Key Vault provider requires the Azure SDK. "
                "Install it with: pip install maestro[azure-secrets]"
            ) from exc

        cfg = config or {}
        vault_url = cfg.get("vault_url") or cfg.get("vaultUrl")
        if not vault_url:
            raise ValueError("AzureKeyVaultSecretsProvider requires config['vault_url']")

        self._prefix = cfg.get("prefix", "")
        credential = DefaultAzureCredential()
        self._client = SecretClient(vault_url=vault_url, credential=credential)

    def _secret_name(self, key: str) -> str:
        # Key Vault names must be alphanumeric + hyphens; replace underscores
        name = f"{self._prefix}{key}".replace("_", "-")
        return name

    def get(self, key: str) -> str | None:
        try:
            secret = self._client.get_secret(self._secret_name(key))
            return secret.value
        except Exception:
            return None

    def set(self, key: str, value: str) -> None:
        self._client.set_secret(self._secret_name(key), value)

    def delete(self, key: str) -> None:
        try:
            self._client.begin_delete_secret(self._secret_name(key))
        except Exception:
            pass

    def list(self) -> list[str]:
        prefix = self._prefix
        names = []
        for prop in self._client.list_properties_of_secrets():
            name = prop.name or ""
            if prefix and name.startswith(prefix):
                name = name[len(prefix):]
            names.append(name.replace("-", "_"))
        return names
