from __future__ import annotations

import json
import urllib.request
import urllib.error

from .base import SecretsProvider


class OnePasswordConnectProvider(SecretsProvider):
    """
    1Password Connect HTTP API backend.

    Uses stdlib urllib — no third-party dependencies required.

    config options:
      connect_url — 1Password Connect server URL, e.g. http://localhost:8080
      token       — Connect API token (OP_CONNECT_TOKEN env var used as fallback)
      vault_id    — Target vault UUID or name (required)
    """

    def __init__(self, config: dict | None = None) -> None:
        import os

        cfg = config or {}
        self._url = (cfg.get("connect_url") or os.environ.get("OP_CONNECT_HOST", "")).rstrip("/")
        self._token = cfg.get("token") or os.environ.get("OP_CONNECT_TOKEN", "")
        self._vault_id = cfg.get("vault_id") or os.environ.get("OP_VAULT", "")

        if not self._url:
            raise ValueError("OnePasswordConnectProvider requires config['connect_url'] or OP_CONNECT_HOST env var")
        if not self._vault_id:
            raise ValueError("OnePasswordConnectProvider requires config['vault_id'] or OP_VAULT env var")

    # ------------------------------------------------------------------
    # Internal HTTP helpers
    # ------------------------------------------------------------------

    def _headers(self) -> dict:
        return {
            "Authorization": f"Bearer {self._token}",
            "Content-Type": "application/json",
        }

    def _request(self, method: str, path: str, body: dict | None = None) -> dict | list | None:
        url = f"{self._url}{path}"
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(url, data=data, headers=self._headers(), method=method)
        try:
            with urllib.request.urlopen(req) as resp:
                raw = resp.read()
                return json.loads(raw) if raw else {}
        except urllib.error.HTTPError as exc:
            if exc.code == 404:
                return None
            raise

    def _vault_path(self) -> str:
        return f"/v1/vaults/{self._vault_id}/items"

    def _find_item(self, title: str) -> dict | None:
        """Return the first item matching title, or None."""
        # URL-encode the filter so titles containing spaces, quotes, or
        # other special characters don't break the query string.
        from urllib.parse import urlencode
        query = urlencode({"filter": f'title eq "{title}"'})
        items = self._request("GET", f"{self._vault_path()}?{query}")
        if isinstance(items, list) and items:
            return items[0]
        return None

    # ------------------------------------------------------------------
    # SecretsProvider interface
    # ------------------------------------------------------------------

    def get(self, key: str) -> str | None:
        item = self._find_item(key)
        if not item:
            return None
        item_id = item.get("id")
        detail = self._request("GET", f"{self._vault_path()}/{item_id}")
        if not detail:
            return None
        for field in (detail.get("fields") or []):
            if field.get("purpose") == "PASSWORD" or field.get("id") == "password":
                return field.get("value")
        return None

    def set(self, key: str, value: str) -> None:
        existing = self._find_item(key)
        item_body = {
            "vault": {"id": self._vault_id},
            "title": key,
            "category": "LOGIN",
            "fields": [
                {
                    "id": "password",
                    "type": "CONCEALED",
                    "purpose": "PASSWORD",
                    "label": "password",
                    "value": value,
                }
            ],
        }
        if existing:
            item_id = existing["id"]
            self._request("PUT", f"{self._vault_path()}/{item_id}", item_body)
        else:
            self._request("POST", self._vault_path(), item_body)

    def delete(self, key: str) -> None:
        existing = self._find_item(key)
        if existing:
            item_id = existing["id"]
            self._request("DELETE", f"{self._vault_path()}/{item_id}")

    def list(self) -> list[str]:
        items = self._request("GET", self._vault_path())
        if not isinstance(items, list):
            return []
        return [item.get("title", "") for item in items if item.get("title")]
