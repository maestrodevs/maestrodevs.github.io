"""Polar.sh product configuration for the Admiralty licence backend.

These IDs are pinned to the live Polar org `tech127`. They identify
*our* products — the customer never enters them. Test-mode and live-
mode have different IDs; for now the constants below are populated
with **test-mode** IDs so the v2.5.0 first-customer install runs
against Polar's sandbox without billing real money.

Switching to live mode is a single PR — replace the test-mode IDs
with the live-mode IDs (Polar dashboard → switch top-right toggle →
Products → copy ID).

Env-var overrides (mostly for our own integration tests; not for
customer use):

  MAESTRO_LICENCE_API_BASE      — point at a non-default Polar API
                                    base (default: https://api.polar.sh/v1)
  MAESTRO_POLAR_ORG_SLUG        — override org slug (default: tech127)
  MAESTRO_POLAR_PRODUCT_PRO     — override Pro product ID
  MAESTRO_POLAR_PRODUCT_TEAM    — override Team Pro product ID
  MAESTRO_POLAR_PRODUCT_ENT     — override Enterprise product ID
  MAESTRO_POLAR_PORTAL_URL      — override customer-portal redirect URL
"""

from __future__ import annotations

import os


# Polar org. The dashboard URL is https://polar.sh/dashboard/<slug>;
# the customer-facing portal lives at https://polar.sh/<slug>.
POLAR_ORG_SLUG: str = os.environ.get("MAESTRO_POLAR_ORG_SLUG") or "tech127"


# Live Polar API base. Overridable for staging/test rigs.
POLAR_API_BASE: str = (
    os.environ.get("MAESTRO_LICENCE_API_BASE")
    or "https://api.polar.sh/v1"
)


# Product IDs — TEST MODE (Polar sandbox).
# Provided by Captain on 2026-05-07; flip to live IDs when launch goes paid.
POLAR_PRODUCT_PRO: str = (
    os.environ.get("MAESTRO_POLAR_PRODUCT_PRO")
    or "a07f287e-b734-4b51-ad3c-522523933c4d"
)

POLAR_PRODUCT_TEAM: str = (
    os.environ.get("MAESTRO_POLAR_PRODUCT_TEAM")
    or "996f10b8-48bd-4f19-ae14-3de5a5e04d21"
)

# Enterprise product TBD — sales-led at v2.5.0 launch; create the Polar
# product when the first enterprise customer is signing up.
POLAR_PRODUCT_ENTERPRISE: str = (
    os.environ.get("MAESTRO_POLAR_PRODUCT_ENT")
    or ""
)


# Customer self-service portal — Polar's hosted billing surface.
# Override via env var or via .mso/config/workspace.json's `licence.portalUrl`
# once we land that schema field.
POLAR_PORTAL_URL: str = (
    os.environ.get("MAESTRO_POLAR_PORTAL_URL")
    or f"https://polar.sh/{POLAR_ORG_SLUG}/portal"
)


# Mode introspection — useful for `adm licence status --json`.
# Test-mode product IDs are the ones we shipped with on 2026-05-07.
_TEST_MODE_PRO_DEFAULT = "a07f287e-b734-4b51-ad3c-522523933c4d"
_TEST_MODE_TEAM_DEFAULT = "996f10b8-48bd-4f19-ae14-3de5a5e04d21"


def is_test_mode() -> bool:
    """True if the active product IDs are the test-mode defaults.

    Used to surface a "TEST MODE" banner in `adm licence status` and to
    avoid customer confusion if a sandbox install accidentally talks
    to a live key (or vice-versa).
    """
    return (
        POLAR_PRODUCT_PRO == _TEST_MODE_PRO_DEFAULT
        and POLAR_PRODUCT_TEAM == _TEST_MODE_TEAM_DEFAULT
    )


def product_id_to_tier(product_id: str) -> str:
    """Map a Polar product ID back to the human-readable tier name.

    Returns "" for unknown IDs — the caller decides whether to default
    to "pro" or surface a friendly error.
    """
    if product_id == POLAR_PRODUCT_PRO:
        return "pro"
    if product_id == POLAR_PRODUCT_TEAM:
        return "team"
    if POLAR_PRODUCT_ENTERPRISE and product_id == POLAR_PRODUCT_ENTERPRISE:
        return "enterprise"
    return ""
