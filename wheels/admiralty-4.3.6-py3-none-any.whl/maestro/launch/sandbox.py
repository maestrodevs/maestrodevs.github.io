"""
Subprocess sandbox — builds a minimal env for every framework process launch.

When workspace.json enterprise: true, all subprocess.Popen calls MUST go through
spawn() so that the parent shell's secrets are never inherited by crew sessions,
bridge processes, or MCP servers.

When enterprise: false, spawn() passes through the full os.environ unchanged
(backwards-compatible behaviour for solo/dev users).
"""
from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path
from typing import Sequence

# ---------------------------------------------------------------------------
# Allowlist — env vars always forwarded to child processes
# ---------------------------------------------------------------------------

_ALWAYS_ALLOWED: frozenset[str] = frozenset({
    "PATH", "HOME", "USER", "USERPROFILE",
    "TEMP", "TMP", "TMPDIR",
    "LANG", "TERM",
    "SYSTEMROOT", "SYSTEMDRIVE", "WINDIR",   # Windows runtime needs
    "COMSPEC",                                # cmd.exe location on Windows
    "PATHEXT",                                # Windows executable extensions
    "NUMBER_OF_PROCESSORS", "PROCESSOR_ARCHITECTURE",  # innocuous Windows vars
})

_ALLOWED_PREFIXES: tuple[str, ...] = (
    "MAESTRO_",
    "CLAUDE_",
    "LC_",
    "ANTHROPIC_",   # API key is the one secret crews legitimately need
)


def _is_allowed(key: str) -> bool:
    if key in _ALWAYS_ALLOWED:
        return True
    return any(key.startswith(prefix) for prefix in _ALLOWED_PREFIXES)


def _build_minimal_env(
    requested_secrets: list[str] | None,
    workspace: Path,
    identity: str,
    source_env: dict[str, str] | None = None,
) -> dict[str, str]:
    """Return a scrubbed env dict plus any explicitly requested secrets.

    When source_env is provided it is used as the source (allowing callers that
    build their own env dict to have it scrubbed rather than os.environ).
    """
    source = source_env if source_env is not None else os.environ
    env: dict[str, str] = {k: v for k, v in source.items() if _is_allowed(k)}

    if not requested_secrets:
        return env

    # Resolve requested secret://... refs via ACL-gated provider
    for ref in requested_secrets:
        key = ref.removeprefix("secret://") if ref.startswith("secret://") else ref
        try:
            from maestro.secrets.secrets import Secrets
            value = Secrets(workspace).provider.get(key)
            if value is not None:
                env[key] = value
        except Exception:
            pass  # fail-open: unavailable secret is simply absent

    return env


def _load_enterprise_flag(workspace: Path | None) -> bool:
    if workspace is None:
        return False
    from maestro.workspace import resolve_artefact_dir
    ws_cfg = resolve_artefact_dir(workspace) / "config" / "workspace.json"
    if not ws_cfg.exists():
        return False
    try:
        data = json.loads(ws_cfg.read_text(encoding="utf-8"))
        flag = data.get("enterprise", False)
        if isinstance(flag, bool):
            return flag
        if isinstance(flag, dict):
            return True
        return bool(flag)
    except Exception:
        return False


def _audit_spawn(
    workspace: Path | None,
    cmd: Sequence[str],
    identity: str,
    requested_secrets: list[str] | None,
) -> None:
    """Write a process.spawn audit entry (cmd[0] only — never args)."""
    if workspace is None:
        return
    try:
        from maestro.audit import get_audit_log
        binary = os.path.basename(cmd[0]) if cmd else "unknown"
        secret_keys = [
            (r.removeprefix("secret://") if r.startswith("secret://") else r)
            for r in (requested_secrets or [])
        ]
        get_audit_log(workspace).append(
            action="process.spawn",
            target=binary,
            result="ok",
            metadata={"identity": identity, "requested_secret_keys": secret_keys},
        )
    except Exception:
        pass


def spawn(
    cmd: Sequence[str],
    *,
    identity: str,
    workspace: Path | None = None,
    requested_secrets: list[str] | None = None,
    **popen_kwargs,
) -> subprocess.Popen:
    """
    Launch a subprocess through the environment sandbox.

    Args:
        cmd: Command and arguments (same as subprocess.Popen's first arg).
        identity: Caller identity label used for ACL checks and audit entries.
        workspace: Path to the workspace root (the dir that contains .mso/).
                   If None, enterprise mode is assumed off and full env is passed.
        requested_secrets: List of secret keys (or ``secret://key`` refs) whose
                           values should be injected into the child env after
                           ACL-gated lookup.  Never the values themselves.
        **popen_kwargs: Forwarded verbatim to subprocess.Popen.

    Returns:
        The subprocess.Popen object.
    """
    enterprise = _load_enterprise_flag(workspace)

    if enterprise:
        source_env: dict[str, str] | None = popen_kwargs.get("env")
        env = _build_minimal_env(
            requested_secrets,
            workspace,  # type: ignore[arg-type]
            identity,
            source_env=source_env,
        )
        popen_kwargs["env"] = env
    # else: no env= kwarg → child inherits full os.environ (backwards compat)

    _audit_spawn(workspace, cmd, identity, requested_secrets)

    return subprocess.Popen(cmd, **popen_kwargs)
