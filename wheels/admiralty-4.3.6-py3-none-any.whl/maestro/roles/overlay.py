"""maestro.roles.overlay — merge a user overlay onto a core role definition.

Implements the 4-axis × 3-directive merge matrix from SEC-0185 Part D:

  Section types:   bulleted_list | table | prose | subsections
  Directives:      extend | override | replace

  - extend:   append user content after core (lists/tables) or after first para (prose)
  - override: for tables, match by first column and replace matched rows; add new rows
  - replace:  discard core body, use user body verbatim
"""

from __future__ import annotations

import copy
import re
import warnings
from dataclasses import dataclass, field
from typing import Any

from maestro.roles.loader import RoleDefinition, SectionContent, VALID_MERGE_DIRECTIVES


# ---------------------------------------------------------------------------
# Section-type detection
# ---------------------------------------------------------------------------


def _detect_section_type(body: str) -> str:
    """Classify a section body as 'bulleted_list', 'table', 'prose', or 'subsections'."""
    if not body.strip():
        return "prose"
    lines = body.strip().splitlines()
    # Sub-sections: contains H3 headings
    if any(re.match(r"^###\s", line) for line in lines):
        return "subsections"
    # Table: contains | characters forming a table row
    table_lines = [l for l in lines if l.strip().startswith("|")]
    if len(table_lines) >= 2:
        return "table"
    # Bulleted list: starts with - / * / numbered
    bullet_lines = [l for l in lines if re.match(r"^\s*[-*+]\s|\s*\d+\.\s", l)]
    if len(bullet_lines) / max(len(lines), 1) >= 0.4:
        return "bulleted_list"
    return "prose"


# ---------------------------------------------------------------------------
# Merge strategies
# ---------------------------------------------------------------------------


def _merge_bulleted_list(core_body: str, user_body: str, directive: str) -> str:
    if directive == "replace":
        return user_body
    if directive in ("extend", "override"):
        # For both extend and override on lists, append user bullets
        if not core_body.strip():
            return user_body
        if not user_body.strip():
            return core_body
        return core_body.rstrip() + "\n" + user_body.lstrip()
    return core_body


def _parse_table_rows(body: str) -> list[str]:
    """Return non-separator table rows."""
    rows = []
    for line in body.splitlines():
        stripped = line.strip()
        if stripped.startswith("|") and not re.match(r"^\|[-| :]+\|$", stripped):
            rows.append(line)
    return rows


def _get_separator(body: str) -> str:
    for line in body.splitlines():
        stripped = line.strip()
        if re.match(r"^\|[-| :]+\|$", stripped):
            return line
    return "| --- | --- |"


def _merge_table(core_body: str, user_body: str, directive: str) -> str:
    if directive == "replace":
        return user_body
    if directive == "extend":
        if not core_body.strip():
            return user_body
        if not user_body.strip():
            return core_body
        # Append user rows (skip header + separator of user table)
        user_rows = _parse_table_rows(user_body)
        # Skip the header row (first row) of the user table when extending
        data_rows = user_rows[1:] if len(user_rows) > 1 else user_rows
        if not data_rows:
            return core_body
        return core_body.rstrip() + "\n" + "\n".join(data_rows)
    if directive == "override":
        # Match by first column value; replace matched rows, append new ones
        core_rows = _parse_table_rows(core_body)
        user_rows = _parse_table_rows(user_body)
        if not core_rows:
            return user_body

        def _first_col(row: str) -> str:
            cols = [c.strip() for c in row.split("|")]
            return cols[1] if len(cols) > 1 else ""

        header = core_rows[0] if core_rows else ""
        sep = _get_separator(core_body)
        core_data = core_rows[1:] if len(core_rows) > 1 else []
        user_data = user_rows[1:] if len(user_rows) > 1 else user_rows

        # Index core data by first column
        core_index: dict[str, str] = {_first_col(r): r for r in core_data}
        for user_row in user_data:
            key = _first_col(user_row)
            core_index[key] = user_row  # override or append

        merged_data = list(core_index.values())
        return "\n".join([header, sep] + merged_data)
    return core_body


def _merge_prose(core_body: str, user_body: str, directive: str) -> str:
    if directive == "replace":
        return user_body
    if directive == "extend":
        if not core_body.strip():
            return user_body
        if not user_body.strip():
            return core_body
        return core_body.rstrip() + "\n\n" + user_body.lstrip()
    if directive == "override":
        return user_body
    return core_body


def _merge_subsections(core_body: str, user_body: str, directive: str) -> str:
    if directive == "replace":
        return user_body
    if directive in ("extend", "override"):
        if not core_body.strip():
            return user_body
        if not user_body.strip():
            return core_body
        return core_body.rstrip() + "\n\n" + user_body.lstrip()
    return core_body


_STRATEGY = {
    "bulleted_list": _merge_bulleted_list,
    "table": _merge_table,
    "prose": _merge_prose,
    "subsections": _merge_subsections,
}


# ---------------------------------------------------------------------------
# Frontmatter merge
# ---------------------------------------------------------------------------


def _merge_frontmatter(core_fm: dict[str, Any], overlay_fm: dict[str, Any]) -> dict[str, Any]:
    merged = copy.deepcopy(core_fm)
    # tools: extend (union, preserving order)
    if "tools" in overlay_fm:
        core_tools = merged.get("tools", [])
        extra = [t for t in overlay_fm["tools"] if t not in core_tools]
        merged["tools"] = core_tools + extra
    # model: override
    if "model" in overlay_fm:
        merged["model"] = overlay_fm["model"]
    # test_categories: override
    if "test_categories" in overlay_fm:
        merged["test_categories"] = copy.deepcopy(overlay_fm["test_categories"])
    # role_name: override (allows per-org renaming)
    if "role_name" in overlay_fm:
        merged["role_name"] = overlay_fm["role_name"]
    # sections directives: merge into merged frontmatter (informational)
    if "sections" in overlay_fm:
        merged["sections"] = copy.deepcopy(overlay_fm["sections"])
    # Preserve overlay-only fields
    for k, v in overlay_fm.items():
        if k not in merged:
            merged[k] = copy.deepcopy(v)
    return merged


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def merge_overlay(core: RoleDefinition, overlay: RoleDefinition) -> RoleDefinition:
    """Merge *overlay* onto *core* and return a new effective RoleDefinition.

    For each section in overlay.frontmatter['sections']:
      - Apply declared merge directive (extend / override / replace)
    Sections in core but not in overlay['sections'] → kept verbatim.
    Sections in overlay['sections'] but with no body in overlay → warn, use core.
    """
    section_directives: dict[str, str] = overlay.frontmatter.get("sections", {})

    new_sections = copy.deepcopy(core.sections)

    for sec_key, directive in section_directives.items():
        if directive not in VALID_MERGE_DIRECTIVES:
            warnings.warn(
                f"[Maestro overlay] Unknown directive '{directive}' for section "
                f"'{sec_key}'; defaulting to 'extend'",
                UserWarning,
                stacklevel=2,
            )
            directive = "extend"

        user_sec = overlay.sections.get(sec_key)
        if user_sec is None or not user_sec.body.strip():
            warnings.warn(
                f"[Maestro overlay] Section '{sec_key}' declared in overlay "
                f"frontmatter but has no content body in {overlay.path}; skipping.",
                UserWarning,
                stacklevel=2,
            )
            continue

        core_sec = new_sections.get(sec_key)
        core_body = core_sec.body if core_sec else ""
        user_body = user_sec.body

        section_type = _detect_section_type(core_body or user_body)
        strategy = _STRATEGY[section_type]
        merged_body = strategy(core_body, user_body, directive)

        heading = core_sec.heading if core_sec else user_sec.heading
        new_sections[sec_key] = SectionContent(
            name=sec_key, heading=heading, body=merged_body
        )

    # Sections present in overlay but not declared in frontmatter['sections']
    # → treat as extend (default)
    for sec_key, user_sec in overlay.sections.items():
        if sec_key in section_directives:
            continue  # already handled above
        if sec_key not in new_sections:
            # Brand-new section contributed by overlay — append
            new_sections[sec_key] = copy.deepcopy(user_sec)
        # else: not declared, not new → keep core verbatim (default extend would be noisy)

    merged_fm = _merge_frontmatter(core.frontmatter, overlay.frontmatter)

    from maestro.roles.loader import RoleDefinition as _RD
    return _RD(
        frontmatter=merged_fm,
        sections=new_sections,
        path=overlay.path,
        is_core=False,
    )
