# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""
Proxy-mode configuration for the Admiralty egress filter.

When workspace.json: dataResidency.proxy is set, all outbound HTTP is routed
through the configured proxy.  The egress filter checks the INTENDED destination
(the original request URL) against allowedDestinations — NOT the proxy's host —
so operators can allowlist their real destinations without allowlisting the proxy.

Audit log entry: egress.proxied { intended_destination, proxy_url }
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Optional
from urllib.parse import urlparse


@dataclass
class ProxyConfig:
    """Parsed proxy configuration from workspace.json: dataResidency.proxy."""

    url: str
    authentication: Dict[str, Any] = field(default_factory=dict)
    # If True, attempt to extract the real destination from a
    # X-Forwarded-Host / CONNECT target header returned by the proxy.
    # Left False in most deployments — the egress filter already knows the
    # intended destination from the original request URL.
    decrypt_destination_from_header: bool = False

    @property
    def host(self) -> str:
        """Hostname of the proxy (for display / logging)."""
        return urlparse(self.url).hostname or self.url

    @property
    def proxies_dict(self) -> Dict[str, str]:
        """Return a proxies dict compatible with requests.Session.proxies."""
        return {"http": self.url, "https": self.url}


def parse_proxy_config(dr: Dict[str, Any]) -> Optional[ProxyConfig]:
    """
    Parse dataResidency.proxy from workspace.json.

    Returns None when no proxy is configured.
    """
    raw = dr.get("proxy")
    if not raw:
        return None

    url = raw.get("url", "").strip()
    if not url:
        return None

    return ProxyConfig(
        url=url,
        authentication=raw.get("authentication", {}),
        decrypt_destination_from_header=raw.get(
            "decryptDestinationHostFromProxyHeader", False
        ),
    )
