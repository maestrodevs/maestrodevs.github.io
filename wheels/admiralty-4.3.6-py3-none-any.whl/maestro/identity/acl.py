from __future__ import annotations

from pathlib import Path

from .loader import load_acl, load_group
from .types import Capability, Scope


def _scope_matches(entry_scope: str, requested_scope: str) -> bool:
    """Entry scope '*' matches anything; otherwise exact string match."""
    if entry_scope == "*":
        return True
    return entry_scope == requested_scope


def _capability_matches(entry_cap: str, requested_cap: str) -> bool:
    """Entry capability '*' grants everything; otherwise exact match."""
    if entry_cap == "*":
        return True
    return entry_cap == requested_cap


def resolve_capability(
    actor: str,
    capability: Capability,
    scope: Scope,
    acl_path: Path,
    groups_dir: Path,
) -> bool:
    """
    Return True if actor holds capability in scope.

    Checks direct user entries first, then group membership.
    A wildcard capability '*' grants everything.
    A wildcard scope '*' matches any requested scope.
    """
    entries = load_acl(acl_path)

    # actor is expected as "user:<email>"
    email = actor.removeprefix("user:") if actor.startswith("user:") else actor

    for entry in entries:
        if not _capability_matches(entry.capability, capability):
            continue
        if not _scope_matches(entry.scope, scope):
            continue

        principal = entry.principal
        if principal == f"user:{email}":
            return True

        if principal.startswith("group:"):
            group_name = principal.removeprefix("group:")
            group = load_group(groups_dir, group_name)
            if group and email in group.members:
                return True

    return False


def effective_capabilities(
    actor: str,
    acl_path: Path,
    groups_dir: Path,
) -> list[tuple[str, str]]:
    """Return list of (capability, scope) pairs the actor holds."""
    from .types import ALL_CAPABILITIES

    entries = load_acl(acl_path)
    email = actor.removeprefix("user:") if actor.startswith("user:") else actor

    results: list[tuple[str, str]] = []
    seen: set[tuple[str, str]] = set()

    for entry in entries:
        principal = entry.principal
        matched = False

        if principal == f"user:{email}":
            matched = True
        elif principal.startswith("group:"):
            group_name = principal.removeprefix("group:")
            group = load_group(groups_dir, group_name)
            if group and email in group.members:
                matched = True

        if not matched:
            continue

        if entry.capability == "*":
            for cap in ALL_CAPABILITIES:
                key = (cap, entry.scope)
                if key not in seen:
                    seen.add(key)
                    results.append(key)
        else:
            key = (entry.capability, entry.scope)
            if key not in seen:
                seen.add(key)
                results.append(key)

    return results
