"""
Identity file integrity guard — FTR-ADM-2026-0067 / LKT finding T-1.4 / T-5.1.

Every identity file must be either:
  1. Committed to git with no uncommitted modifications, OR
  2. Present in .mso/identity/integrity.json with a matching SHA-256 hash.

Failing both checks raises IdentityIntegrityError, blocking identity load entirely.
"""
from __future__ import annotations

import hashlib
import json
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path


INTEGRITY_MANIFEST = "integrity.json"


class IdentityIntegrityError(RuntimeError):
    """Raised when an identity file fails both git-committed and hash-manifest checks."""

    def __init__(self, path: Path, reason: str) -> None:
        self.path = path
        self.reason = reason
        super().__init__(
            f"[Identity] Integrity check failed for {path}: {reason}. "
            "Refusing to load identity — fix by committing the file or running "
            "'adm identity' mutations to update the integrity manifest."
        )


@dataclass
class IntegrityResult:
    path: Path
    passed: bool
    method: str  # "git-committed" | "hash-manifest" | "failed"
    reason: str


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    h.update(path.read_bytes())
    return h.hexdigest()


def _is_git_committed(path: Path, repo_root: Path) -> bool:
    """Return True if path is tracked by git and has no uncommitted changes."""
    try:
        rel = path.relative_to(repo_root).as_posix()
    except ValueError:
        return False

    # Check that the file is tracked (exits 0) and not modified/staged
    r1 = subprocess.run(
        ["git", "ls-files", "--error-unmatch", rel],
        capture_output=True,
        cwd=str(repo_root),
    )
    if r1.returncode != 0:
        return False

    r2 = subprocess.run(
        ["git", "status", "--porcelain", rel],
        capture_output=True,
        text=True,
        cwd=str(repo_root),
    )
    return r2.returncode == 0 and r2.stdout.strip() == ""


def _load_manifest(identity_dir: Path) -> dict[str, str]:
    manifest_path = identity_dir / INTEGRITY_MANIFEST
    if not manifest_path.exists():
        return {}
    try:
        return json.loads(manifest_path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def verify_integrity(path: Path, repo_root: Path, identity_dir: Path) -> IntegrityResult:
    """
    Verify that *path* is either git-committed (clean) or matches the hash manifest.

    Raises IdentityIntegrityError if both checks fail.
    Returns IntegrityResult describing which check passed.
    """
    if not path.exists():
        # Non-existent files trivially pass (load_* returns None anyway)
        return IntegrityResult(path=path, passed=True, method="not-found", reason="file does not exist")

    # Check 1: committed to git with no modifications
    if _is_git_committed(path, repo_root):
        return IntegrityResult(path=path, passed=True, method="git-committed", reason="tracked and clean")

    # Check 2: hash manifest
    manifest = _load_manifest(identity_dir)
    try:
        rel_key = path.relative_to(identity_dir).as_posix()
    except ValueError:
        rel_key = path.name

    recorded = manifest.get(rel_key)
    if recorded is not None:
        actual = _sha256(path)
        if actual == recorded:
            return IntegrityResult(path=path, passed=True, method="hash-manifest", reason="hash matches manifest")
        raise IdentityIntegrityError(
            path,
            f"SHA-256 mismatch (manifest={recorded[:12]}… actual={actual[:12]}…) — file may have been tampered",
        )

    # Neither check passed
    raise IdentityIntegrityError(
        path,
        "file is not committed to git and has no entry in integrity.json",
    )


# ---------------------------------------------------------------------------
# Manifest management (called by adm identity mutations)
# ---------------------------------------------------------------------------

def update_manifest(path: Path, identity_dir: Path) -> None:
    """Recompute the hash for *path* and write it into integrity.json atomically."""
    manifest_path = identity_dir / INTEGRITY_MANIFEST
    manifest: dict[str, str] = {}
    if manifest_path.exists():
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        except Exception:
            manifest = {}

    try:
        rel_key = path.relative_to(identity_dir).as_posix()
    except ValueError:
        rel_key = path.name

    manifest[rel_key] = _sha256(path)
    _write_atomically(manifest_path, json.dumps(manifest, indent=2, sort_keys=True))


def remove_from_manifest(path: Path, identity_dir: Path) -> None:
    """Remove *path*'s entry from integrity.json (called on delete mutations)."""
    manifest_path = identity_dir / INTEGRITY_MANIFEST
    if not manifest_path.exists():
        return
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except Exception:
        return

    try:
        rel_key = path.relative_to(identity_dir).as_posix()
    except ValueError:
        rel_key = path.name

    manifest.pop(rel_key, None)
    _write_atomically(manifest_path, json.dumps(manifest, indent=2, sort_keys=True))


def _write_atomically(dest: Path, content: str) -> None:
    """Write *content* to *dest* via a temp file to avoid partial writes."""
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = tempfile.NamedTemporaryFile(
        mode="w", encoding="utf-8", dir=dest.parent, delete=False, suffix=".tmp"
    )
    try:
        tmp.write(content)
        tmp.flush()
        tmp.close()
        Path(tmp.name).replace(dest)
    except Exception:
        Path(tmp.name).unlink(missing_ok=True)
        raise


# ---------------------------------------------------------------------------
# Migration helper
# ---------------------------------------------------------------------------

def build_initial_manifest(identity_dir: Path, repo_root: Path) -> None:
    """
    First-time migration: build integrity.json from all current identity files.

    All files must be committed to git; uncommitted files cause refusal (raise
    IdentityIntegrityError).  Only call this when integrity.json does not yet exist.
    """
    manifest_path = identity_dir / INTEGRITY_MANIFEST
    if manifest_path.exists():
        return  # Already initialised — do nothing.

    identity_files = [
        p for p in identity_dir.rglob("*.json")
        if p.name != INTEGRITY_MANIFEST
    ]

    for f in identity_files:
        if not _is_git_committed(f, repo_root):
            raise IdentityIntegrityError(
                f,
                "integrity.json does not exist yet (first-time migration) and this file "
                "is not committed to git — commit all identity files before running adm",
            )

    manifest: dict[str, str] = {}
    for f in identity_files:
        try:
            rel_key = f.relative_to(identity_dir).as_posix()
        except ValueError:
            rel_key = f.name
        manifest[rel_key] = _sha256(f)

    _write_atomically(manifest_path, json.dumps(manifest, indent=2, sort_keys=True))
    print(f"[Identity] Integrity manifest initialised with {len(manifest)} file(s).")
