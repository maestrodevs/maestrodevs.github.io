"""maestro.identity — Multi-tenancy, RBAC, and CLI gating (V6 Enterprise)."""

from .types import UserRecord, GroupRecord, AclEntry, Capability, Scope, ALL_CAPABILITIES
from .acl import resolve_capability, effective_capabilities
from .gate import CapabilityDenied, require_capability
from .auth import resolve_caller
from .loader import (
    load_user, load_group, load_acl,
    save_user, save_group, save_acl,
    list_users, list_groups,
)
from .integrity import (
    IdentityIntegrityError,
    verify_integrity,
    update_manifest,
    remove_from_manifest,
    build_initial_manifest,
)
from .encryption import (
    encryption_tool, is_encryption_enabled,
    encryption_init_wizard, add_gitattributes,
)
from .rights import (
    rights_export, rights_forget, rights_restrict,
    is_restricted, export_classification_csv,
)

__all__ = [
    "UserRecord", "GroupRecord", "AclEntry", "Capability", "Scope", "ALL_CAPABILITIES",
    "resolve_capability", "effective_capabilities",
    "CapabilityDenied", "require_capability",
    "resolve_caller",
    "load_user", "load_group", "load_acl",
    "save_user", "save_group", "save_acl",
    "list_users", "list_groups",
    "IdentityIntegrityError", "verify_integrity",
    "update_manifest", "remove_from_manifest", "build_initial_manifest",
    "encryption_tool", "is_encryption_enabled",
    "encryption_init_wizard", "add_gitattributes",
    "rights_export", "rights_forget", "rights_restrict",
    "is_restricted", "export_classification_csv",
]
