from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

Scope = str  # "*" | "voyage:<id>" | "project:<acronym>" | "role:<code>"

Capability = Literal[
    "voyage.create", "voyage.view", "voyage.approve",
    "order.create", "order.view", "order.dispatch",
    "fleet.dispatch", "fleet.view",
    "config.modify", "config.view",
    "bridge.start", "bridge.stop", "bridge.view",
    "backup.create", "backup.restore",
    "audit.read", "audit.export", "audit.anchor",
    "secrets.read", "secrets.write", "secrets.delete", "secrets.list",
    "identity.write", "identity.read",
    "*",
]

ALL_CAPABILITIES: tuple[str, ...] = (
    "voyage.create", "voyage.view", "voyage.approve",
    "order.create", "order.view", "order.dispatch",
    "fleet.dispatch", "fleet.view",
    "config.modify", "config.view",
    "bridge.start", "bridge.stop", "bridge.view",
    "backup.create", "backup.restore",
    "audit.read", "audit.export", "audit.anchor",
    "secrets.read", "secrets.write", "secrets.delete", "secrets.list",
    "identity.write", "identity.read",
)


@dataclass
class UserRecord:
    email: str
    display_name: str
    groups: list[str]
    providers: dict[str, str] = field(default_factory=dict)
    public_key: str | None = None
    enrolled_at: str | None = None
    last_seen_at: str | None = None


@dataclass
class GroupRecord:
    name: str
    members: list[str]
    description: str | None = None


@dataclass
class AclEntry:
    principal: str       # "user:<email>" | "group:<name>"
    capability: str      # Capability
    scope: Scope
