#!/usr/bin/env python3
# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
"""
Mobile Command Bridge — Inbound Poller v1.0

Polls a GitHub Gist for commands sent by the Captain from mobile (via Slack),
executes them locally, and writes results back to the gist.

Flow:
  1. Captain sends command via Slack → Slack bot writes to GitHub Gist
  2. BridgePoller polls the gist on a configurable interval (default 30s)
  3. Unprocessed commands are validated, executed, and results written back
  4. Slack bot reads results from gist and relays to Captain

Daemon management:
  - PID file at .mso/bridge/poller.pid
  - Windows-compatible process detection (ctypes OpenProcess)
  - Clean shutdown via --stop flag or PID file removal

Security:
  - Command whitelist enforced before execution
  - JSON schema validation on all inbound commands
  - Tokens never logged or exposed in output
"""

import argparse
import json
import logging
import os
import re
import subprocess
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

try:
    from maestro.egress.filter import EgressDenied, install_egress_filter
    _EGRESS_AVAILABLE = True
except ImportError:
    _EGRESS_AVAILABLE = False
    # Define a dedicated dummy type — aliasing to Exception would make any
    # later `except EgressDenied:` clause swallow unrelated errors and
    # mis-report them as egress denials.
    class EgressDenied(Exception):  # type: ignore[no-redef]
        pass


# =============================================================================
# CONSTANTS
# =============================================================================

ALLOWED_COMMANDS = frozenset([
    "approve", "reject", "dispatch", "status", "cleanup",
    "crew", "usage", "verify", "order", "acknowledge",
    "voyage_create", "voyage_list", "voyage_status", "bug_create", "qm_response",
])

COMMAND_EXPIRY_HOURS = 24

REQUIRED_COMMAND_FIELDS = {"id", "project", "command", "timestamp", "processed"}

PID_SUBDIR = "bridge"
PID_FILENAME = "poller.pid"
LOG_FILENAME = "bridge.log"

DEFAULT_POLL_INTERVAL = 30  # seconds


# =============================================================================
# LOGGING
# =============================================================================

def _setup_logger(admiralty_dir: Path) -> logging.Logger:
    """Configure bridge logger with file output."""
    log_dir = admiralty_dir / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)

    logger = logging.getLogger("bridge_poller")
    logger.setLevel(logging.DEBUG)

    if not logger.handlers:
        handler = logging.FileHandler(log_dir / LOG_FILENAME, encoding="utf-8")
        handler.setFormatter(logging.Formatter(
            "%(asctime)s [%(levelname)s] %(message)s", datefmt="%Y-%m-%d %H:%M:%S"
        ))
        logger.addHandler(handler)

    return logger


# =============================================================================
# PROCESS HELPERS
# =============================================================================

def is_process_alive(pid: int) -> bool:
    """Check if a process with the given PID is still running.

    Uses ctypes OpenProcess on Windows for reliability (works from cmd.exe AND Git Bash).
    """
    if not pid or pid <= 0:
        return False
    try:
        if os.name == "nt":
            import ctypes
            PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            STILL_ACTIVE = 259
            kernel32 = ctypes.windll.kernel32
            handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
            if handle == 0:
                return False
            try:
                exit_code = ctypes.c_ulong()
                if kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code)):
                    return exit_code.value == STILL_ACTIVE
                return False
            finally:
                kernel32.CloseHandle(handle)
        else:
            os.kill(pid, 0)
            return True
    except (ProcessLookupError, PermissionError, OSError):
        return False


# =============================================================================
# BRIDGE POLLER
# =============================================================================

class BridgePoller:
    """Polls a GitHub Gist for inbound commands and executes them locally."""

    def __init__(self, admiralty_dir: Path) -> None:
        self.admiralty_dir = admiralty_dir.resolve()
        self.logger = _setup_logger(self.admiralty_dir)

        # Load settings
        settings_path = self.admiralty_dir / "config" / "bridge-settings.json"
        if not settings_path.exists():
            raise FileNotFoundError(
                f"Bridge settings not found: {settings_path}\n"
                "Create .mso/config/bridge-settings.json with gist_id and token fields."
            )

        with open(settings_path, "r", encoding="utf-8") as f:
            raw_settings = json.load(f)

        self.settings = self._resolve_env_vars(raw_settings)
        try:
            from maestro.secrets.refs import resolve_secret_refs, install_log_scrub
            install_log_scrub()
            self.settings = resolve_secret_refs(self.settings, self.admiralty_dir.parent)
        except Exception:
            pass
        bridge = self.settings.get("bridge", {})
        queue_cfg = bridge.get("queue", {})
        self.gist_id: str = queue_cfg.get("gistId", "")
        self.token: str = queue_cfg.get("githubToken", "")
        self.poll_interval: int = int(queue_cfg.get("pollIntervalSeconds", DEFAULT_POLL_INTERVAL))

        if not self.gist_id:
            raise ValueError("bridge-settings.json: bridge.queue.gistId is required (or set MAESTRO_BRIDGE_GIST_ID).")
        if not self.token:
            raise ValueError("bridge-settings.json: bridge.queue.githubToken is required (or set MAESTRO_GITHUB_TOKEN).")

        self.logger.info("BridgePoller initialized (gist_id=...%s, interval=%ds)",
                         self.gist_id[-6:], self.poll_interval)

        # Install egress filter (no-op in permissive/non-enterprise mode)
        if _EGRESS_AVAILABLE:
            try:
                install_egress_filter(self.admiralty_dir.parent)
            except Exception:
                pass

    # -------------------------------------------------------------------------
    # Settings helpers
    # -------------------------------------------------------------------------

    @staticmethod
    def _resolve_env_vars(obj: Any) -> Any:
        """Recursively resolve ${VAR_NAME} references in settings values."""
        if isinstance(obj, str):
            def _replace(match: re.Match) -> str:
                var_name = match.group(1)
                return os.environ.get(var_name, match.group(0))
            return re.sub(r"\$\{(\w+)}", _replace, obj)
        if isinstance(obj, dict):
            return {k: BridgePoller._resolve_env_vars(v) for k, v in obj.items()}
        if isinstance(obj, list):
            return [BridgePoller._resolve_env_vars(v) for v in obj]
        return obj

    # -------------------------------------------------------------------------
    # Gist interaction
    # -------------------------------------------------------------------------

    def _gist_url(self) -> str:
        return f"https://api.github.com/gists/{self.gist_id}"

    def _make_request(self, method: str = "GET", data: Optional[bytes] = None,
                      extra_headers: Optional[Dict[str, str]] = None) -> tuple:
        """Make an authenticated GitHub API request to the gist endpoint.

        Returns (body_dict, etag_str).
        """
        req = urllib.request.Request(self._gist_url(), data=data, method=method)
        req.add_header("Authorization", f"token {self.token}")
        req.add_header("Accept", "application/vnd.github.v3+json")
        if data:
            req.add_header("Content-Type", "application/json")
        if extra_headers:
            for k, v in extra_headers.items():
                req.add_header(k, v)

        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                etag = resp.headers.get("ETag", "")
                return json.loads(resp.read().decode("utf-8")), etag
        except EgressDenied:
            raise urllib.error.URLError("Egress denied for GitHub API by allowlist")

    def _fetch_commands(self, project: Optional[str] = None) -> tuple:
        """Fetch unprocessed commands from the gist, grouped by project file.

        Returns: (dict mapping filename -> list of command dicts, etag).
        """
        gist, etag = self._make_request("GET")
        files = gist.get("files", {})
        result: Dict[str, List[dict]] = {}

        for filename, file_info in files.items():
            if not filename.startswith("commands-") or not filename.endswith(".json"):
                continue
            file_project = filename.replace("commands-", "").replace(".json", "")
            if project and file_project != project:
                continue

            content = file_info.get("content", "[]")
            try:
                commands = json.loads(content)
                if isinstance(commands, list):
                    result[filename] = commands
            except json.JSONDecodeError:
                self.logger.warning("Invalid JSON in gist file %s — skipping", filename)

        return result, etag

    def _update_gist_file(self, filename: str, commands: List[dict],
                          etag: str = "") -> None:
        """PATCH the gist to update a single commands file.

        Uses If-Match ETag header for optimistic concurrency.
        """
        payload = json.dumps({
            "files": {
                filename: {
                    "content": json.dumps(commands, indent=2)
                }
            }
        }).encode("utf-8")
        extra = {"If-Match": etag} if etag else None
        self._make_request("PATCH", data=payload, extra_headers=extra)

    # -------------------------------------------------------------------------
    # Command validation
    # -------------------------------------------------------------------------

    @staticmethod
    def _validate_command(cmd: dict) -> Optional[str]:
        """Validate a command dict. Returns error string or None if valid."""
        if not isinstance(cmd, dict):
            return "Command is not a dict"

        missing = REQUIRED_COMMAND_FIELDS - set(cmd.keys())
        if missing:
            return f"Missing fields: {', '.join(sorted(missing))}"

        if cmd.get("command") not in ALLOWED_COMMANDS:
            return f"Command '{cmd.get('command')}' not in whitelist"

        # Validate timestamp is parseable
        try:
            datetime.fromisoformat(cmd["timestamp"].replace("Z", "+00:00"))
        except (ValueError, TypeError, AttributeError):
            return f"Invalid timestamp: {cmd.get('timestamp')}"

        return None

    @staticmethod
    def _is_expired(cmd: dict) -> bool:
        """Check if a command is older than COMMAND_EXPIRY_HOURS."""
        try:
            ts = datetime.fromisoformat(cmd["timestamp"].replace("Z", "+00:00"))
            if ts.tzinfo is None:
                ts = ts.replace(tzinfo=timezone.utc)
            cutoff = datetime.now(timezone.utc) - timedelta(hours=COMMAND_EXPIRY_HOURS)
            return ts < cutoff
        except (ValueError, KeyError, TypeError):
            return True

    # -------------------------------------------------------------------------
    # Command execution
    # -------------------------------------------------------------------------

    def _execute_command(self, cmd: dict) -> dict:
        """Execute a single validated command. Returns result dict."""
        command = cmd["command"]
        project = cmd.get("project", "ADM")
        args = cmd.get("args", {})

        self.logger.info("Executing: %s (project=%s, id=%s)", command, project, cmd.get("id"))

        try:
            if command in ("approve", "reject"):
                return self._handle_approval(command, project, args)
            elif command == "acknowledge":
                return self._handle_acknowledge(project, args)
            elif command == "order":
                return self._handle_order(project, args)
            elif command == "voyage_create":
                return self._handle_voyage_create(project, args)
            elif command == "voyage_list":
                return self._handle_voyage_list(project, args)
            elif command == "voyage_status":
                return self._handle_voyage_status(project, args)
            elif command == "bug_create":
                return self._handle_bug_create(project, args)
            elif command == "qm_response":
                return self._handle_qm_response(project, args)
            else:
                return self._handle_cli_command(command, project, args)
        except Exception as exc:
            self.logger.error("Command %s failed: %s", cmd.get("id"), exc)
            return {"status": "error", "message": str(exc)}

    def _handle_approval(self, action: str, project: str, args: dict) -> dict:
        """Handle approve/reject by updating the target JSON file's status field."""
        target = args.get("target") or args.get("item_id", "")  # accept both field names
        if not target:
            return {"status": "error", "message": "No target specified for approval"}

        # Search voyages/active and plans for matching files
        search_dirs = [
            self.admiralty_dir / "voyages" / "active",
            self.admiralty_dir / "plans",
        ]

        found_path: Optional[Path] = None
        for search_dir in search_dirs:
            if not search_dir.exists():
                continue
            for candidate in search_dir.iterdir():
                if candidate.is_file() and candidate.suffix == ".json":
                    if target in candidate.name:
                        found_path = candidate
                        break
            if found_path:
                break

        if not found_path:
            return {"status": "error", "message": f"Target not found: {target}"}

        try:
            with open(found_path, "r", encoding="utf-8") as f:
                data = json.load(f)

            new_status = "APPROVED" if action == "approve" else "REJECTED"
            data["status"] = new_status
            data["statusUpdatedBy"] = "bridge-poller"
            data["statusUpdatedAt"] = datetime.now(timezone.utc).isoformat()

            with open(found_path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)

            self.logger.info("%s %s -> %s", action.upper(), found_path.name, new_status)
            return {"status": "ok", "message": f"{found_path.name} → {new_status}"}
        except Exception as exc:
            return {"status": "error", "message": f"Failed to update {found_path.name}: {exc}"}

    def _handle_acknowledge(self, project: str, args: dict) -> dict:
        """Handle escalation acknowledgment by updating the escalation JSON status."""
        esc_id = args.get("escalation_id", "")
        if not esc_id:
            return {"status": "error", "message": "No escalation_id specified"}

        esc_dir = self.admiralty_dir / "queues" / "escalations"
        if not esc_dir.exists():
            return {"status": "error", "message": "No escalations directory found"}

        for candidate in esc_dir.glob("*.json"):
            try:
                data = json.loads(candidate.read_text(encoding="utf-8"))
                if data.get("id") == esc_id:
                    data["status"] = "ACKNOWLEDGED"
                    data["acknowledgedBy"] = "bridge-poller"
                    data["acknowledgedAt"] = datetime.now(timezone.utc).isoformat()
                    candidate.write_text(json.dumps(data, indent=2), encoding="utf-8")
                    self.logger.info("ACKNOWLEDGED escalation %s", esc_id)
                    return {"status": "ok", "message": f"Escalation {esc_id} acknowledged"}
            except Exception:
                continue

        return {"status": "error", "message": f"Escalation not found: {esc_id}"}

    def _handle_order(self, project: str, args: dict) -> dict:
        """Handle order creation by writing a new order JSON to the orders queue."""
        description = args.get("description", "")
        if not description:
            return {"status": "error", "message": "No description provided for order"}

        priority = args.get("priority", "MEDIUM").upper()
        if priority not in ("CRITICAL", "HIGH", "MEDIUM", "LOW"):
            priority = "MEDIUM"

        # Generate order ID
        now = datetime.now(timezone.utc)
        year = now.strftime("%Y")
        orders_dir = self.admiralty_dir / "queues" / "orders"
        orders_dir.mkdir(parents=True, exist_ok=True)

        # Find next sequence number
        existing = list(orders_dir.glob(f"FTR-{project}-{year}-*.json"))
        seq = len(existing) + 1
        order_id = f"FTR-{project}-{year}-{seq:04d}"

        order = {
            "orderId": order_id,
            "type": "FTR",
            "project": project,
            "title": description,
            "priority": priority,
            "status": "PENDING",
            "createdBy": "bridge-poller",
            "createdAt": now.isoformat(),
            "targetRole": "NAV",
            "roleSequence": ["NAV", "SHP", "BOS", "SCR", "LKT"],
            "acceptanceCriteria": [],
            "acResults": [],
        }

        order_path = orders_dir / f"{order_id}.json"
        order_path.write_text(json.dumps(order, indent=2), encoding="utf-8")
        self.logger.info("Created order %s: %s", order_id, description[:60])
        return {"status": "ok", "message": f"Order created: {order_id}", "orderId": order_id}

    def _handle_voyage_create(self, project: str, args: dict) -> dict:
        """Create a new voyage: write JSON, create git branch."""
        title = args.get("title", "")
        if not title:
            return {"status": "error", "message": "No title provided for voyage_create"}

        now = datetime.now(timezone.utc)
        year = now.strftime("%Y")
        voyages_dir = self.admiralty_dir / "voyages" / "active"
        voyages_dir.mkdir(parents=True, exist_ok=True)

        existing = list(voyages_dir.glob(f"VOY-{project}-{year}-*.json"))
        seq = len(existing) + 1
        voyage_id = f"VOY-{project}-{year}-{seq:04d}"

        voyage = {
            "voyageId": voyage_id,
            "project": project,
            "title": title,
            "status": "PLANNED",
            "orders": [],
            "createdBy": "bridge-poller",
            "createdAt": now.isoformat(),
        }

        voyage_path = voyages_dir / f"{voyage_id}.json"
        voyage_path.write_text(json.dumps(voyage, indent=2), encoding="utf-8")
        self.logger.info("Created voyage %s: %s", voyage_id, title[:60])

        # Create git branch
        branch = f"voyage/{voyage_id}"
        repo_root = str(self.admiralty_dir.parent)
        try:
            subprocess.run(
                ["git", "checkout", "-b", branch],
                capture_output=True, text=True, cwd=repo_root, timeout=30,
            )
        except Exception as exc:
            self.logger.warning("Failed to create branch %s: %s", branch, exc)

        return {"status": "ok", "message": f"Voyage created: {voyage_id}", "voyageId": voyage_id}

    def _handle_voyage_list(self, project: str, args: dict) -> dict:
        """List voyages for a project."""
        voyages_dir = self.admiralty_dir / "voyages" / "active"
        if not voyages_dir.exists():
            return {"status": "ok", "voyages": [], "message": "No voyages found"}

        voyages = []
        for candidate in sorted(voyages_dir.glob("*.json")):
            try:
                data = json.loads(candidate.read_text(encoding="utf-8"))
                if data.get("project") != project:
                    continue
                voyages.append({
                    "id": data.get("voyageId", candidate.stem),
                    "title": data.get("title", ""),
                    "status": data.get("status", ""),
                    "orderCount": len(data.get("orders", [])),
                })
            except Exception:
                continue

        lines = [f"{v['id']} | {v['status']} | orders={v['orderCount']} | {v['title']}" for v in voyages]
        return {"status": "ok", "voyages": voyages, "message": "\n".join(lines) if lines else "No voyages found"}

    def _handle_voyage_status(self, project: str, args: dict) -> dict:
        """Return status summary for a specific voyage."""
        voyage_id = args.get("voyage_id", "") or args.get("id", "")
        if not voyage_id:
            return {"status": "error", "message": "No voyage_id specified"}

        voyages_dir = self.admiralty_dir / "voyages" / "active"
        if voyages_dir.exists():
            for candidate in voyages_dir.glob("*.json"):
                if voyage_id in candidate.name:
                    try:
                        data = json.loads(candidate.read_text(encoding="utf-8"))
                        summary = (
                            f"Voyage: {data.get('voyageId')}\n"
                            f"Title: {data.get('title')}\n"
                            f"Status: {data.get('status')}\n"
                            f"Orders: {len(data.get('orders', []))}\n"
                            f"Created: {data.get('createdAt', '')}"
                        )
                        return {"status": "ok", "message": summary, "voyage": data}
                    except Exception as exc:
                        return {"status": "error", "message": f"Failed to read voyage: {exc}"}

        return {"status": "error", "message": f"Voyage not found: {voyage_id}"}

    def _handle_bug_create(self, project: str, args: dict) -> dict:
        """Create a BUG order and write it to the orders queue."""
        description = args.get("description", "")
        if not description:
            return {"status": "error", "message": "No description provided for bug_create"}

        now = datetime.now(timezone.utc)
        year = now.strftime("%Y")
        orders_dir = self.admiralty_dir / "queues" / "orders"
        orders_dir.mkdir(parents=True, exist_ok=True)

        existing = list(orders_dir.glob(f"BUG-{project}-{year}-*.json"))
        seq = len(existing) + 1
        bug_id = f"BUG-{project}-{year}-{seq:04d}"

        order = {
            "orderId": bug_id,
            "type": "BUG",
            "project": project,
            "title": description,
            "priority": args.get("priority", "HIGH").upper(),
            "status": "PENDING",
            "createdBy": "bridge-poller",
            "createdAt": now.isoformat(),
            "targetRole": "SHP",
            "roleSequence": ["SHP", "BOS"],
            "acceptanceCriteria": [],
            "acResults": [],
        }

        order_path = orders_dir / f"{bug_id}.json"
        order_path.write_text(json.dumps(order, indent=2), encoding="utf-8")
        self.logger.info("Created bug order %s: %s", bug_id, description[:60])
        return {"status": "ok", "message": f"Bug order created: {bug_id}", "orderId": bug_id}

    def _handle_qm_response(self, project: str, args: dict) -> dict:
        """Write Captain's reply to qm-response.json for the local QM hook to pick up."""
        response_text = args.get("response", "") or args.get("text", "")
        if not response_text:
            return {"status": "error", "message": "No response text provided"}

        bridge_dir = self.admiralty_dir / "bridge"
        bridge_dir.mkdir(parents=True, exist_ok=True)

        payload = {
            "project": project,
            "response": response_text,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "source": "bridge-poller",
        }

        response_path = bridge_dir / "qm-response.json"
        response_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        self.logger.info("QM response written for project %s", project)
        return {"status": "ok", "message": "Captain's response delivered to QM"}

    def _handle_cli_command(self, command: str, project: str, args: dict) -> dict:
        """Execute a Maestro CLI command via subprocess."""
        cli_args = [sys.executable, "-m", "maestro.cli", command]

        # Map common args
        for key, value in args.items():
            if isinstance(value, bool):
                if value:
                    cli_args.append(f"--{key}")
            else:
                cli_args.extend([f"--{key}", str(value)])

        # Inject project context
        env = os.environ.copy()
        env["MAESTRO_PROJECT"] = project

        try:
            result = subprocess.run(
                cli_args,
                capture_output=True,
                text=True,
                timeout=120,
                cwd=str(self.admiralty_dir.parent),
                env=env,
            )
            output = result.stdout.strip() or result.stderr.strip()
            # Truncate long output for gist storage
            if len(output) > 2000:
                output = output[:1997] + "..."

            status = "ok" if result.returncode == 0 else "error"
            self.logger.info("CLI %s exited %d (%d chars output)", command, result.returncode, len(output))
            return {"status": status, "returncode": result.returncode, "output": output}
        except subprocess.TimeoutExpired:
            self.logger.warning("CLI %s timed out after 120s", command)
            return {"status": "error", "message": "Command timed out (120s)"}
        except Exception as exc:
            return {"status": "error", "message": str(exc)}

    # -------------------------------------------------------------------------
    # Poll cycle
    # -------------------------------------------------------------------------

    def poll_once(self) -> int:
        """Fetch gist, process unprocessed commands, write results back.

        Returns the number of commands processed.
        """
        processed_count = 0

        try:
            all_commands, etag = self._fetch_commands()
        except urllib.error.HTTPError as exc:
            self.logger.error("Gist fetch failed: HTTP %d", exc.code)
            return 0
        except Exception as exc:
            self.logger.error("Gist fetch failed: %s", exc)
            return 0

        for filename, commands in all_commands.items():
            dirty = False

            for cmd in commands:
                if cmd.get("processed", False):
                    continue

                # Validate
                error = self._validate_command(cmd)
                if error:
                    self.logger.warning("Invalid command %s: %s", cmd.get("id", "?"), error)
                    cmd["processed"] = True
                    cmd["result"] = {"status": "error", "message": f"Validation failed: {error}"}
                    dirty = True
                    processed_count += 1
                    continue

                # Check expiry
                if self._is_expired(cmd):
                    self.logger.info("Expired command %s (ts=%s)", cmd.get("id"), cmd.get("timestamp"))
                    cmd["processed"] = True
                    cmd["result"] = {"status": "expired", "message": "Command older than 24h"}
                    dirty = True
                    processed_count += 1
                    continue

                # Execute
                result = self._execute_command(cmd)
                cmd["processed"] = True
                cmd["result"] = result
                cmd["processedAt"] = datetime.now(timezone.utc).isoformat()
                dirty = True
                processed_count += 1

            if dirty:
                try:
                    self._update_gist_file(filename, commands, etag)
                    self.logger.info("Updated gist file %s", filename)
                except urllib.error.HTTPError as exc:
                    if exc.code == 412:
                        self.logger.warning("Gist conflict on %s — will retry next cycle", filename)
                    else:
                        self.logger.error("Failed to update gist file %s: HTTP %d", filename, exc.code)
                except Exception as exc:
                    self.logger.error("Failed to update gist file %s: %s", filename, exc)

        return processed_count

    # -------------------------------------------------------------------------
    # Daemon management
    # -------------------------------------------------------------------------

    def _pid_dir(self) -> Path:
        return self.admiralty_dir / PID_SUBDIR

    def _pid_file(self) -> Path:
        return self._pid_dir() / PID_FILENAME

    def _write_pid(self) -> None:
        """Write current PID to the PID file."""
        pid_dir = self._pid_dir()
        pid_dir.mkdir(parents=True, exist_ok=True)
        self._pid_file().write_text(str(os.getpid()), encoding="utf-8")

    def _remove_pid(self) -> None:
        """Remove the PID file."""
        try:
            self._pid_file().unlink(missing_ok=True)
        except OSError:
            pass

    def _check_existing_daemon(self) -> Optional[int]:
        """Check if a daemon is already running. Returns PID or None."""
        pid_file = self._pid_file()
        if not pid_file.exists():
            return None
        try:
            pid = int(pid_file.read_text(encoding="utf-8").strip())
            if is_process_alive(pid):
                return pid
            # Stale PID file
            self.logger.info("Removing stale PID file (pid=%d)", pid)
            pid_file.unlink(missing_ok=True)
            return None
        except (ValueError, OSError):
            return None

    def run_daemon(self) -> None:
        """Start the polling daemon loop."""
        existing = self._check_existing_daemon()
        if existing:
            print(f"Bridge poller already running (PID {existing}). Use --stop first.")
            return

        self._write_pid()
        self.logger.info("Bridge poller daemon started (PID %d, interval %ds)",
                         os.getpid(), self.poll_interval)
        print(f"Bridge poller started (PID {os.getpid()}, interval {self.poll_interval}s)")
        print("Polling gist for inbound commands... (Ctrl+C to stop)")

        try:
            while True:
                count = self.poll_once()
                if count > 0:
                    self.logger.info("Poll cycle: %d command(s) processed", count)

                # Check if PID file was removed (external stop signal)
                if not self._pid_file().exists():
                    self.logger.info("PID file removed — shutting down")
                    break

                time.sleep(self.poll_interval)
        except KeyboardInterrupt:
            self.logger.info("Keyboard interrupt — shutting down")
            print("\nBridge poller stopped.")
        finally:
            self._remove_pid()
            self.logger.info("Bridge poller daemon stopped")

    @classmethod
    def stop_daemon(cls, admiralty_dir: Path) -> bool:
        """Stop a running poller by removing its PID file.

        Returns True if a daemon was found and signaled, False otherwise.
        """
        pid_file = admiralty_dir / PID_SUBDIR / PID_FILENAME
        if not pid_file.exists():
            print("No bridge poller PID file found — not running.")
            return False

        try:
            pid = int(pid_file.read_text(encoding="utf-8").strip())
        except (ValueError, OSError):
            print("Invalid PID file — removing.")
            pid_file.unlink(missing_ok=True)
            return False

        if not is_process_alive(pid):
            print(f"Bridge poller (PID {pid}) is not running — removing stale PID file.")
            pid_file.unlink(missing_ok=True)
            return False

        # Remove PID file — daemon checks this each cycle and exits cleanly
        pid_file.unlink(missing_ok=True)
        print(f"Stop signal sent to bridge poller (PID {pid}). "
              f"It will exit after the current poll cycle.")
        return True


# =============================================================================
# MAIN
# =============================================================================

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Mobile Command Bridge — Inbound Poller",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  python bridge_poller.py              # Start daemon (polls every 30s)\n"
            "  python bridge_poller.py --once        # Single poll cycle\n"
            "  python bridge_poller.py --stop        # Stop running daemon\n"
        ),
    )
    parser.add_argument("--once", action="store_true", help="Run a single poll cycle and exit")
    parser.add_argument("--stop", action="store_true", help="Stop a running poller daemon")
    parser.add_argument("--maestro-dir", type=str, default=None,
                        help="Path to .mso directory (auto-detected if omitted)")

    args = parser.parse_args()

    # Resolve workspace artefact directory
    if args.maestro_dir:
        admiralty_dir = Path(args.maestro_dir).resolve()
    else:
        from maestro.workspace import resolve_artefact_dir
        admiralty_dir = resolve_artefact_dir(Path.cwd())

    if not (admiralty_dir / "config").is_dir():
        print(f"Error: {admiralty_dir} does not appear to be a valid .mso directory.")
        sys.exit(1)

    if args.stop:
        BridgePoller.stop_daemon(admiralty_dir)
        return

    poller = BridgePoller(admiralty_dir)

    if args.once:
        count = poller.poll_once()
        print(f"Poll complete: {count} command(s) processed.")
    else:
        poller.run_daemon()


if __name__ == "__main__":
    main()
