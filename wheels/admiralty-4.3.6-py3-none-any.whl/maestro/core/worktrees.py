"""Worktree lifecycle primitives for parallel voyage isolation.

Provides prepare/cleanup/prune operations for git worktrees scoped to
voyage working directories under .mso/voyages/active/<voyage_id>/.worktree/.

Per-crew isolation (BUG-MSO-2026-0240)
---------------------------------------
FTR-ADM-2026-0149 introduced a single shared worktree per voyage, which
caused concurrent crews of the same voyage to clobber each other's files
and git index. The fix gives every dispatched crew its OWN worktree on a
per-crew branch:

  .mso/voyages/active/<voyage_id>/.worktree-crew<N>   ← crew N works here
  .mso/voyages/active/<voyage_id>/.worktree            ← voyage admin worktree
                                                          (convergence merges only)

When a crew completes, its crew branch is merged back into the voyage branch
via merge_crew_branch_into_voyage() and the crew worktree is cleaned up.
Cross-voyage parallelism (different voyages → different voyage dirs) is
unaffected.
"""

from __future__ import annotations

import re
import subprocess
import threading
from pathlib import Path
from typing import Optional

from maestro.workspace import resolve_artefact_dir as _resolve_artefact_dir

from maestro.core.fleet_runner import _robust_rmtree

# Module-level lock to serialize concurrent prepare calls for the same worktree
_prepare_lock = threading.Lock()

# Serialize convergence merges to avoid concurrent pushes to the same voyage branch
_merge_lock = threading.Lock()


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class WorktreeError(Exception):
    """Base class for worktree lifecycle errors."""


class WorktreeBranchConflict(WorktreeError):
    """Branch is already checked out in another worktree."""


class WorktreeDirExists(WorktreeError):
    """Worktree directory exists but is not registered with git."""


class WorktreeMissingBranch(WorktreeError):
    """The requested branch does not exist and cannot be created."""


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _repo_root() -> Path:
    """Return the root of the git repository."""
    result = subprocess.run(
        ["git", "rev-parse", "--show-toplevel"],
        capture_output=True, text=True
    )
    if result.returncode != 0:
        raise WorktreeError(f"Not inside a git repository: {result.stderr.strip()}")
    return Path(result.stdout.strip())


def _registered_worktrees() -> set[Path]:
    """Return the set of resolved paths currently registered with git worktree."""
    result = subprocess.run(
        ["git", "worktree", "list", "--porcelain"],
        capture_output=True, text=True
    )
    paths = set()
    for line in result.stdout.splitlines():
        if line.startswith("worktree "):
            raw = line[len("worktree "):].strip()
            # Use Path to normalise slashes; resolve() canonicalises on real FS
            p = Path(raw)
            paths.add(p)
    return paths


def _branch_exists_local(branch: str) -> bool:
    """Check whether ``refs/heads/<branch>`` exists in the local repo."""
    result = subprocess.run(
        ["git", "rev-parse", "--verify", f"refs/heads/{branch}"],
        capture_output=True
    )
    return result.returncode == 0


def _branch_exists_remote(branch: str, remote: str = "origin") -> bool:
    """Check whether ``refs/remotes/<remote>/<branch>`` exists in the local repo.

    Returns True if the remote-tracking ref is present locally. Does not call
    ``git fetch`` — use :func:`_fetch_remote_branch` first if you need to
    refresh the local view of the remote.
    """
    result = subprocess.run(
        ["git", "rev-parse", "--verify", f"refs/remotes/{remote}/{branch}"],
        capture_output=True
    )
    return result.returncode == 0


def _fetch_remote_branch(branch: str, remote: str = "origin") -> bool:
    """Fetch a single branch from *remote* into the matching remote-tracking ref.

    BUG-MSO-2026-0027: the dispatcher creates voyage branches via ``gh api``,
    which only touches the GitHub remote — the local repo has no record of
    the new ref until something fetches. Without this, ``git worktree add``
    fails because ``refs/heads/<branch>`` doesn't exist.
    """
    result = subprocess.run(
        ["git", "fetch", remote, f"{branch}:refs/remotes/{remote}/{branch}"],
        capture_output=True, text=True, timeout=30
    )
    return result.returncode == 0


# Backward-compat alias; new callers should use the explicit local/remote form.
def _branch_exists(branch: str) -> bool:
    return _branch_exists_local(branch)


def _find_worktree_for_branch(branch: str) -> Optional[Path]:
    """Return the worktree path where *branch* is currently checked out, or None."""
    result = subprocess.run(
        ["git", "worktree", "list", "--porcelain"],
        capture_output=True, text=True,
    )
    current_wt: Optional[Path] = None
    for line in result.stdout.splitlines():
        if line.startswith("worktree "):
            current_wt = Path(line[len("worktree "):].strip())
        elif line.startswith("branch ") and line.split()[-1] == f"refs/heads/{branch}":
            return current_wt
    return None


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def worktree_path_for(voyage_id: str) -> Path:
    """Return the canonical voyage admin worktree path (no I/O).

    This worktree is used exclusively for convergence merges. Crew work
    happens in crew_worktree_path_for() worktrees (BUG-MSO-2026-0240).
    """
    return _resolve_artefact_dir(_repo_root()) / "voyages" / "active" / voyage_id / ".worktree"


def crew_worktree_path_for(voyage_id: str, crew_num: int) -> Path:
    """Return the per-crew worktree path for (voyage_id, crew_num) (no I/O)."""
    return (
        _resolve_artefact_dir(_repo_root())
        / "voyages" / "active" / voyage_id
        / f".worktree-crew{crew_num}"
    )


def crew_branch_name(voyage_id: str, crew_num: int) -> str:
    """Return the per-crew git branch name, e.g. ``crew/VOY-MSO-2026-0056-1``."""
    return f"crew/{voyage_id}-{crew_num}"


def prepare_voyage_worktree(voyage_id: str, voyage_branch: str) -> Path:
    """Create (or reuse) the git worktree for a voyage.

    Idempotent: if the worktree already exists and is registered, returns its path.
    Handles orphaned dirs from crashed PREPARING state by removing and recreating.

    Raises:
        WorktreeBranchConflict: branch is checked out in another worktree.
        WorktreeMissingBranch: branch does not exist.
        WorktreeError: git worktree add failed for another reason.
    """
    with _prepare_lock:
        worktree_path = worktree_path_for(voyage_id)
        registered = _registered_worktrees()

        # Happy path: already ready
        if worktree_path.exists() and worktree_path in registered:
            return worktree_path

        # Orphaned dir (PREPARING crash): remove and recreate
        if worktree_path.exists() and worktree_path not in registered:
            _robust_rmtree(worktree_path, label=f"worktree orphan {voyage_id}")

        # BUG-MSO-2026-0027: the dispatcher creates voyage branches via
        # ``gh api`` (remote-only). Resolve in three tiers:
        #   1. Local branch ref present → standard ``git worktree add <path> <branch>``.
        #   2. Remote-tracking ref already present → fetch is unnecessary; create
        #      the local branch via ``git worktree add -b <branch> <path> origin/<branch>``.
        #   3. Neither present → ``git fetch`` the specific branch from origin
        #      and retry the tracking-branch worktree add.
        # Fail loudly with WorktreeMissingBranch only if all three fail.
        local_branch = _branch_exists_local(voyage_branch)
        if not local_branch:
            if not _branch_exists_remote(voyage_branch):
                _fetch_remote_branch(voyage_branch)
            if not _branch_exists_remote(voyage_branch):
                raise WorktreeMissingBranch(
                    f"Branch '{voyage_branch}' does not exist locally or on origin. "
                    "Create it before calling prepare_voyage_worktree()."
                )

        worktree_path.parent.mkdir(parents=True, exist_ok=True)

        if local_branch:
            cmd = ["git", "worktree", "add", str(worktree_path), voyage_branch]
        else:
            # Create local branch tracking origin/<branch> in the same step.
            cmd = [
                "git", "worktree", "add",
                "-b", voyage_branch,
                str(worktree_path),
                f"origin/{voyage_branch}",
            ]

        result = subprocess.run(cmd, capture_output=True, text=True)

        if result.returncode == 0:
            return worktree_path

        stderr = result.stderr.strip()

        if "already checked out" in stderr or "already used by worktree" in stderr:
            raise WorktreeBranchConflict(
                f"Branch '{voyage_branch}' is already checked out in another worktree. "
                f"git error: {stderr}"
            )

        if "No space left" in stderr or "disk full" in stderr.lower():
            raise WorktreeError(f"Disk full while creating worktree: {stderr}")

        # Already registered (e.g. path comparison miss in concurrent scenario)
        if "already registered" in stderr and worktree_path.exists():
            return worktree_path

        raise WorktreeError(f"git worktree add failed: {stderr}")


def prepare_crew_worktree(voyage_id: str, crew_num: int, voyage_branch: str) -> Path:
    """Create (or reuse) an isolated per-crew git worktree on a per-crew branch.

    Each crew of the same voyage gets its own worktree at
    .mso/voyages/active/<voyage_id>/.worktree-crew<crew_num> on branch
    crew/<voyage_id>-<crew_num>, branched from voyage_branch.

    On re-dispatch (crew timed out and was requeued): if the crew branch already
    exists locally, the worktree is recreated on that same branch so the crew
    can continue from where it left off.

    The MAESTRO_SPRINT_BRANCH injected into the crew process must be the crew
    branch name (from crew_branch_name()) so the branch guard allows mutations
    on the crew branch rather than the voyage branch.

    Raises:
        WorktreeMissingBranch: voyage_branch does not exist locally or on origin.
        WorktreeBranchConflict: crew branch already checked out in another worktree.
        WorktreeError: git worktree add failed for another reason.
    """
    with _prepare_lock:
        wt_path = crew_worktree_path_for(voyage_id, crew_num)
        c_branch = crew_branch_name(voyage_id, crew_num)
        registered = _registered_worktrees()

        # Happy path: already ready (idempotent on re-call)
        if wt_path.exists() and wt_path in registered:
            return wt_path

        # Orphaned dir (PREPARING crash): remove and recreate
        if wt_path.exists() and wt_path not in registered:
            _robust_rmtree(wt_path, label=f"crew worktree orphan {voyage_id}-{crew_num}")

        # Resolve the voyage branch start-point using the same three-tier strategy
        # as prepare_voyage_worktree (BUG-MSO-2026-0027).
        local_voy = _branch_exists_local(voyage_branch)
        if not local_voy:
            if not _branch_exists_remote(voyage_branch):
                _fetch_remote_branch(voyage_branch)
            if not _branch_exists_remote(voyage_branch):
                raise WorktreeMissingBranch(
                    f"Voyage branch '{voyage_branch}' does not exist locally or on origin."
                )
        start_point = voyage_branch if local_voy else f"origin/{voyage_branch}"

        wt_path.parent.mkdir(parents=True, exist_ok=True)

        # Re-dispatch: crew branch already exists — reuse it (don't re-branch from voyage tip)
        if _branch_exists_local(c_branch):
            cmd = ["git", "worktree", "add", str(wt_path), c_branch]
        else:
            # Fresh crew: create crew branch from the current voyage branch tip
            cmd = ["git", "worktree", "add", "-b", c_branch, str(wt_path), start_point]

        result = subprocess.run(cmd, capture_output=True, text=True)

        if result.returncode == 0:
            return wt_path

        stderr = result.stderr.strip()

        if "already checked out" in stderr or "already used by worktree" in stderr:
            raise WorktreeBranchConflict(
                f"Crew branch '{c_branch}' is already checked out in another worktree. "
                f"git error: {stderr}"
            )

        if "already registered" in stderr and wt_path.exists():
            return wt_path

        if "No space left" in stderr or "disk full" in stderr.lower():
            raise WorktreeError(f"Disk full while creating crew worktree: {stderr}")

        raise WorktreeError(f"git worktree add failed for crew {crew_num}: {stderr}")


def merge_crew_branch_into_voyage(voyage_id: str, crew_num: int, voyage_branch: str,
                                  order_id: Optional[str] = None) -> bool:
    """Merge a completed crew's branch into the voyage branch (convergence step).

    Uses the voyage admin worktree (.worktree) as a scratch pad:
      1. Sync to origin/<voyage_branch> (reset --hard to handle any prior failed merge)
      2. Fetch origin/<crew_branch>
      3. Merge --no-ff to preserve crew history
      4. Push to origin/<voyage_branch>

    The _merge_lock serializes concurrent convergence merges so two crews
    finishing simultaneously don't produce a push race on the same branch.

    `order_id` (BUG-MSO-2026-0244) is woven into the convergence commit message so
    `git log` on the voyage branch reflects the order actually being merged rather
    than a hardcoded bug id.

    Returns True on clean merge+push.
    Raises WorktreeError on merge conflict or push failure. On a merge conflict the
    error message lists the conflicting files (BUG-MSO-2026-0244) so finalization can
    record them for recovery.
    """
    c_branch = crew_branch_name(voyage_id, crew_num)

    with _merge_lock:
        # Resolve a worktree on the voyage branch for convergence merges.
        # Preference: voyage admin worktree (.worktree); fall back to any
        # existing checkout of the branch (e.g. the main worktree when an
        # operator is on the voyage branch locally — common in tests).
        try:
            admin_wt = prepare_voyage_worktree(voyage_id, voyage_branch)
        except WorktreeBranchConflict:
            admin_wt = _find_worktree_for_branch(voyage_branch)
            if admin_wt is None:
                raise WorktreeError(
                    f"Branch '{voyage_branch}' is already checked out but its "
                    "worktree path could not be located via `git worktree list`."
                )
        except Exception as exc:
            raise WorktreeError(
                f"Cannot prepare voyage admin worktree for convergence: {exc}"
            ) from exc

        def _run(cmd: list, *, timeout: int = 60) -> subprocess.CompletedProcess:
            return subprocess.run(cmd, capture_output=True, text=True,
                                  cwd=str(admin_wt), timeout=timeout)

        # Fetch everything we need in one round-trip
        _run(["git", "fetch", "origin",
              f"{voyage_branch}:refs/remotes/origin/{voyage_branch}",
              f"{c_branch}:refs/remotes/origin/{c_branch}"])

        # Sync admin worktree to latest origin/voyage_branch (handles prior failed pushes)
        reset_r = _run(["git", "reset", "--hard", f"origin/{voyage_branch}"])
        if reset_r.returncode != 0:
            raise WorktreeError(
                f"git reset --hard origin/{voyage_branch} failed: {reset_r.stderr.strip()}"
            )

        # Merge crew branch; --no-ff keeps crew history readable.
        # BUG-MSO-2026-0244: reference the order actually being merged, not a hardcoded bug id.
        _ref = order_id or c_branch
        merge_r = _run([
            "git", "merge", "--no-ff", f"origin/{c_branch}",
            "-m",
            f"convergence: merge crew {crew_num} ({c_branch}) into {voyage_branch} ({_ref})",
        ])
        if merge_r.returncode != 0:
            # BUG-MSO-2026-0244: capture the conflicting files BEFORE aborting (abort
            # clears the conflicted index). Conflict detail lands on git's stdout, not
            # stderr, so include both streams in the raised error.
            conflicts_r = _run(["git", "diff", "--name-only", "--diff-filter=U"])
            conflict_files = [f for f in conflicts_r.stdout.splitlines() if f.strip()]
            _run(["git", "merge", "--abort"])
            _detail = (merge_r.stdout.strip() + " " + merge_r.stderr.strip()).strip()
            _files = ", ".join(conflict_files) if conflict_files else "unknown"
            raise WorktreeError(
                f"Merge of {c_branch} into {voyage_branch} failed (conflict). "
                f"Conflicting files: {_files}. git: {_detail}"
            )

        # Push merged voyage branch
        push_r = _run(["git", "push", "origin", voyage_branch], timeout=120)
        if push_r.returncode != 0:
            raise WorktreeError(
                f"Push of {voyage_branch} after crew {crew_num} merge failed: "
                f"{push_r.stderr.strip()}"
            )

        return True


def cleanup_crew_worktree(voyage_id: str, crew_num: int) -> bool:
    """Remove the per-crew worktree (and optionally its crew branch).

    Returns True on clean removal, False if the worktree didn't exist.
    """
    wt_path = crew_worktree_path_for(voyage_id, crew_num)
    c_branch = crew_branch_name(voyage_id, crew_num)

    if not wt_path.exists():
        subprocess.run(["git", "worktree", "prune"], capture_output=True)
        return False

    result = subprocess.run(
        ["git", "worktree", "remove", "--force", str(wt_path)],
        capture_output=True, text=True,
    )

    if result.returncode != 0:
        removed = _robust_rmtree(wt_path, label=f"crew worktree cleanup {voyage_id}-{crew_num}")
        subprocess.run(["git", "worktree", "prune"], capture_output=True)
    else:
        if wt_path.exists():
            _robust_rmtree(wt_path, label=f"crew worktree cleanup {voyage_id}-{crew_num}")
        removed = True

    # Delete the ephemeral crew branch (it has been merged; keep remote clean).
    # `git branch -d` is the SAFE delete: it refuses to drop a branch whose commits
    # are not reachable from its upstream/HEAD. So if convergence failed (branch is
    # unmerged) this is a no-op and the stranded work survives — see
    # preserve_failed_crew_branch() for the recovery-preserving path.
    if _branch_exists_local(c_branch):
        subprocess.run(
            ["git", "branch", "-d", c_branch],
            capture_output=True,
        )

    # BUG-MSO-2026-0249: also delete the REMOTE crew branch. The branch name is
    # deterministic per (voyage, crew_num), so a leftover origin/crew/<voyage>-<N>
    # would be re-fetched/merged when the same slot is reused for a later order,
    # leaking the prior order's work onto the new crew branch. Best-effort + only
    # when an 'origin' remote exists; never fail cleanup over it.
    _delete_remote_crew_branch(c_branch)

    return removed


def _delete_remote_crew_branch(c_branch: str) -> None:
    """Best-effort delete of origin/<c_branch> so a reused crew slot can't merge it
    (BUG-MSO-2026-0249). Silent no-op when there's no origin or the ref is gone."""
    try:
        has_origin = subprocess.run(
            ["git", "remote", "get-url", "origin"], capture_output=True, text=True
        ).returncode == 0
        if not has_origin:
            return
        # Check the REAL remote state, not the local remote-tracking ref. A crew
        # typically pushes its branch without the dispatcher's main repo ever
        # fetching it, so refs/remotes/origin/<branch> may not exist locally even
        # though the branch is live on origin (Copilot PR #110). ls-remote queries
        # origin directly.
        ls = subprocess.run(
            ["git", "ls-remote", "--heads", "origin", c_branch],
            capture_output=True, text=True, timeout=60,
        )
        if ls.returncode != 0 or not ls.stdout.strip():
            return  # branch not present on the remote
        subprocess.run(
            ["git", "push", "origin", "--delete", c_branch],
            capture_output=True, text=True, timeout=60,
        )
    except Exception:
        pass


def preserve_failed_crew_branch(voyage_id: str, crew_num: int,
                                order_id: Optional[str] = None) -> Optional[dict]:
    """Preserve a crew branch whose convergence merge FAILED, and free its slot.

    BUG-MSO-2026-0244 / BUG-MSO-2026-0243. When merge_crew_branch_into_voyage()
    raises, the crew's work is stranded on crew/<voyage>-<N>. We must:
      1. Record the stranded commit SHA so it can be cherry-picked during recovery
         even after the crew slot is reused.
      2. Remove the crew worktree dir and RENAME the crew branch out of the way
         (crew/<voyage>-<N> -> salvage/<order>-<sha8>) so the next dispatch of the
         same crew slot starts from a fresh branch off the voyage tip — never
         building on top of the stranded order's work.

    Returns {"salvageBranch": ..., "strandedSha": ...} where salvageBranch is the
    ref that ACTUALLY holds the work (the renamed salvage ref on success, or the
    original crew branch if the rename didn't happen), or None if there was no local
    crew branch to preserve. strandedSha is the durable handle regardless. Best-effort:
    git failures are swallowed so this can never wedge finalization.
    """
    c_branch = crew_branch_name(voyage_id, crew_num)
    if not _branch_exists_local(c_branch):
        return None

    sha = "unknown"
    try:
        sha_r = subprocess.run(["git", "rev-parse", c_branch],
                               capture_output=True, text=True)
        if sha_r.returncode == 0 and sha_r.stdout.strip():
            sha = sha_r.stdout.strip()
    except Exception:
        pass

    sha8 = sha[:8] if sha != "unknown" else "unknown"
    # Sanitize the label into a git-ref-safe token so an unusual order_id can't make
    # `git branch -M` fail (which would otherwise leave the slot occupied).
    raw_label = order_id or c_branch
    label = re.sub(r"[^A-Za-z0-9._-]", "-", raw_label).strip("-") or "crew"
    salvage = f"salvage/{label}-{sha8}"

    # Remove the worktree first — a checked-out branch cannot be renamed.
    try:
        cleanup_crew_worktree(voyage_id, crew_num)
    except Exception:
        pass

    # Rename the (still-unmerged) crew branch out of the slot's namespace so the
    # slot frees for a fresh crew branch on next dispatch. -M forces past an
    # existing salvage ref.
    salvage_ok = False
    if _branch_exists_local(c_branch):
        try:
            r = subprocess.run(["git", "branch", "-M", c_branch, salvage],
                               capture_output=True, text=True)
            salvage_ok = (r.returncode == 0) and _branch_exists_local(salvage)
        except Exception:
            salvage_ok = False

    # Report the ref that actually holds the work — never a salvage name that may
    # not exist. If the rename failed, the work still lives on the crew branch (and
    # the SHA is always a valid handle for recovery).
    if salvage_ok:
        preserved_ref = salvage
    elif _branch_exists_local(c_branch):
        preserved_ref = c_branch
    elif _branch_exists_local(salvage):
        preserved_ref = salvage
    else:
        preserved_ref = None

    return {"salvageBranch": preserved_ref, "strandedSha": sha}


def cleanup_all_crew_worktrees(voyage_id: str) -> int:
    """Remove all per-crew worktrees for a voyage (called from sweep_decks).

    Returns count removed.
    """
    repo_root = _repo_root()
    artefact_dir = _resolve_artefact_dir(repo_root)
    voyage_dir = artefact_dir / "voyages" / "active" / voyage_id
    if not voyage_dir.exists():
        return 0

    removed = 0
    for candidate in voyage_dir.iterdir():
        if candidate.name.startswith(".worktree-crew") and candidate.is_dir():
            result = subprocess.run(
                ["git", "worktree", "remove", "--force", str(candidate)],
                capture_output=True,
            )
            if result.returncode != 0:
                _robust_rmtree(candidate, label=f"crew worktree sweep {voyage_id}")
            else:
                if candidate.exists():
                    _robust_rmtree(candidate, label=f"crew worktree sweep {voyage_id}")
            removed += 1

    if removed:
        subprocess.run(["git", "worktree", "prune"], capture_output=True)

    return removed


def cleanup_voyage_worktree(voyage_id: str) -> bool:
    """Remove the worktree for a voyage.

    Returns True on clean removal, False if removal failed (caller should log).
    No-op (returns False) if the worktree directory does not exist.
    """
    worktree_path = worktree_path_for(voyage_id)

    if not worktree_path.exists():
        # Still prune in case git has stale refs
        subprocess.run(["git", "worktree", "prune"], capture_output=True)
        return False

    result = subprocess.run(
        ["git", "worktree", "remove", "--force", str(worktree_path)],
        capture_output=True, text=True
    )

    if result.returncode != 0:
        # Fall back to manual removal + prune
        removed = _robust_rmtree(worktree_path, label=f"worktree cleanup {voyage_id}")
        subprocess.run(["git", "worktree", "prune"], capture_output=True)
        return removed

    # Belt-and-suspenders: remove any lingering dir
    if worktree_path.exists():
        _robust_rmtree(worktree_path, label=f"worktree cleanup {voyage_id}")

    return True


def prune_stale_worktrees() -> int:
    """Remove worktrees whose voyage has moved to voyages/complete/.

    Also runs `git worktree prune` to clean broken git refs.
    Returns the count of worktrees pruned.
    """
    subprocess.run(["git", "worktree", "prune"], capture_output=True)

    repo_root = _repo_root()
    artefact_dir = _resolve_artefact_dir(repo_root)
    active_dir = artefact_dir / "voyages" / "active"
    complete_dir = artefact_dir / "voyages" / "complete"

    if not active_dir.exists():
        return 0

    completed_voyage_ids = {p.name for p in complete_dir.iterdir()} if complete_dir.exists() else set()

    pruned = 0
    for voyage_dir in active_dir.iterdir():
        if not voyage_dir.is_dir():
            continue
        voyage_id = voyage_dir.name
        if voyage_id not in completed_voyage_ids:
            continue
        # Prune voyage admin worktree
        worktree_path = voyage_dir / ".worktree"
        if worktree_path.exists():
            subprocess.run(
                ["git", "worktree", "remove", "--force", str(worktree_path)],
                capture_output=True
            )
            _robust_rmtree(worktree_path, label=f"prune stale worktree {voyage_id}")
            pruned += 1
        # BUG-MSO-2026-0240: also prune any lingering per-crew worktrees
        for candidate in voyage_dir.iterdir():
            if candidate.name.startswith(".worktree-crew") and candidate.is_dir():
                subprocess.run(
                    ["git", "worktree", "remove", "--force", str(candidate)],
                    capture_output=True,
                )
                _robust_rmtree(candidate, label=f"prune stale crew worktree {voyage_id}")
                pruned += 1

    return pruned
