"""
maestro/project_analysis.py — Fingerprint-based project detection.

All detection uses top-level + 1-deep file-presence checks only.
No os.walk, no recursive glob — keeps analyse_project() under 50ms.
"""

from __future__ import annotations

import json
import os
import subprocess
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path


@dataclass
class ProjectAnalysis:
    primary_language: str = "Unknown"
    secondary_languages: list[str] = field(default_factory=list)
    framework: str = "Unknown"
    source_root: str = "."
    test_layouts: list[str] = field(default_factory=list)
    has_readme: bool = False
    has_docs_dir: bool = False
    has_ci: bool = False
    ci_systems: list[str] = field(default_factory=list)
    recent_activity: str = "unknown"
    branch_model: str = "unknown"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _top_level(cwd: Path) -> set[str]:
    try:
        return set(os.listdir(cwd))
    except OSError:
        return set()


def _one_deep(cwd: Path, subdir: str) -> set[str]:
    try:
        return set(os.listdir(cwd / subdir))
    except OSError:
        return set()


def _file_contains(path: Path, text: str) -> bool:
    try:
        return text in path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return False


def _run(cmd: list[str], cwd: Path, timeout: int = 2) -> str:
    try:
        result = subprocess.run(
            cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout
        )
        return result.stdout.strip()
    except Exception:
        return ""


# ---------------------------------------------------------------------------
# Detectors
# ---------------------------------------------------------------------------

def detect_language(cwd: Path) -> tuple[str, list[str]]:
    """Returns (primary_language, secondary_languages)."""
    top = _top_level(cwd)
    detected: list[str] = []

    # Python
    if top & {"pyproject.toml", "setup.py", "setup.cfg", "requirements.txt"}:
        detected.append("Python")
    elif any(f.endswith(".py") for f in top):
        detected.append("Python")

    # TypeScript vs JavaScript
    if "tsconfig.json" in top:
        detected.append("TypeScript")
    elif "package.json" in top:
        pkg_path = cwd / "package.json"
        try:
            pkg = json.loads(pkg_path.read_text(encoding="utf-8", errors="ignore"))
            deps = {
                **pkg.get("dependencies", {}),
                **pkg.get("devDependencies", {}),
            }
            if "typescript" in deps:
                detected.append("TypeScript")
            else:
                detected.append("JavaScript")
        except Exception:
            detected.append("JavaScript")
    elif any(f.endswith((".ts", ".tsx")) for f in top):
        detected.append("TypeScript")
    elif any(f.endswith((".js", ".jsx")) for f in top):
        detected.append("JavaScript")

    # Go
    if "go.mod" in top or any(f.endswith(".go") for f in top):
        detected.append("Go")

    # Rust
    if "Cargo.toml" in top:
        detected.append("Rust")

    # C#
    if any(f.endswith((".csproj", ".sln", ".fsproj")) for f in top) or any(
        f.endswith(".cs") for f in top
    ):
        detected.append("C#")

    # Java
    if top & {"pom.xml", "build.gradle", "build.gradle.kts"}:
        detected.append("Java")

    if not detected:
        return "Unknown", []
    return detected[0], detected[1:]


def detect_framework(cwd: Path, language: str) -> str:
    top = _top_level(cwd)

    # Next.js
    if top & {"next.config.js", "next.config.ts", "next.config.mjs"}:
        return "Next.js"

    # React (no Next)
    if "package.json" in top:
        pkg_path = cwd / "package.json"
        try:
            pkg = json.loads(pkg_path.read_text(encoding="utf-8", errors="ignore"))
            deps = {
                **pkg.get("dependencies", {}),
                **pkg.get("devDependencies", {}),
            }
            if "react" in deps and not top & {"next.config.js", "next.config.ts", "next.config.mjs"}:
                return "React"
            if "express" in deps:
                return "Express"
            if "@nestjs/core" in deps:
                return "NestJS"
        except Exception:
            pass

    # Django
    if "manage.py" in top:
        one_deep_files = set()
        for d in top:
            if (cwd / d).is_dir():
                one_deep_files |= _one_deep(cwd, d)
        if "settings.py" in top or "settings.py" in one_deep_files:
            return "Django"

    # FastAPI / Flask (check requirements or pyproject)
    for fname in ("requirements.txt", "pyproject.toml"):
        if fname in top:
            content = (cwd / fname).read_text(encoding="utf-8", errors="ignore")
            if "fastapi" in content.lower():
                return "FastAPI"
            if "flask" in content.lower():
                return "Flask"

    # .NET / ASP.NET
    for f in top:
        if f.endswith(".csproj"):
            if _file_contains(cwd / f, "Microsoft.AspNetCore"):
                return "ASP.NET"

    return "Unknown"


def detect_source_root(cwd: Path) -> str:
    top = _top_level(cwd)
    for candidate in ("src", "lib", "packages"):
        if candidate in top and (cwd / candidate).is_dir():
            return candidate + "/"
    # app only if it's a directory (not app.py)
    if "app" in top and (cwd / "app").is_dir():
        return "app/"
    return "."


def detect_test_layout(cwd: Path) -> list[str]:
    top = _top_level(cwd)
    layouts: list[str] = []
    for d in ("tests", "test", "__tests__", "spec"):
        if d in top and (cwd / d).is_dir():
            layouts.append(d + "/")
    if any(f.endswith(("_test.go",)) for f in top):
        layouts.append("*_test.go")
    if any(
        f.endswith((".test.ts", ".test.js", ".test.py", ".test.tsx"))
        for f in top
    ):
        layouts.append("*.test.*")
    return layouts


def detect_docs(cwd: Path) -> dict:
    top = _top_level(cwd)
    return {
        "has_readme": "README.md" in top or "readme.md" in {f.lower() for f in top},
        "has_docs_dir": any(
            d in top and (cwd / d).is_dir() for d in ("docs", "_docs")
        ),
        "has_mkdocs": "mkdocs.yml" in top,
        "has_docusaurus": "docusaurus.config.js" in top,
    }


def detect_git_history(cwd: Path) -> dict:
    top = _top_level(cwd)

    # CI presence
    ci_systems: list[str] = []
    if ".github" in top and _one_deep(cwd, ".github"):
        wf_path = cwd / ".github" / "workflows"
        if wf_path.is_dir():
            ci_systems.append("GitHub Actions")
    if ".gitlab-ci.yml" in top:
        ci_systems.append("GitLab CI")
    if "Jenkinsfile" in top:
        ci_systems.append("Jenkins")
    if ".circleci" in top:
        ci_systems.append("CircleCI")

    # Recent activity
    log_out = _run(
        ["git", "log", "--oneline", "-10", "--format=%ai"], cwd, timeout=2
    )
    recent_activity = "unknown"
    if log_out:
        lines = [l.strip() for l in log_out.splitlines() if l.strip()]
        if lines:
            try:
                latest = datetime.fromisoformat(lines[0].split()[0])
                now = datetime.now(tz=timezone.utc)
                # Make latest timezone-aware if naive
                if latest.tzinfo is None:
                    latest = latest.replace(tzinfo=timezone.utc)
                days = (now - latest).days
                if days <= 30:
                    recent_activity = "active"
                elif days <= 180:
                    recent_activity = "stale"
                else:
                    recent_activity = "dormant"
            except Exception:
                recent_activity = "unknown"

    # Branch model
    branch_out = _run(
        ["git", "branch", "-r", "--format=%(refname:short)"], cwd, timeout=2
    )
    branch_model = "unknown"
    if branch_out:
        branches = [b.strip() for b in branch_out.splitlines() if b.strip()]
        names = " ".join(branches).lower()
        if "release" in names or "develop" in names:
            branch_model = "gitflow"
        elif len(branches) > 1:
            branch_model = "feature-branches"
        elif branches:
            branch_model = "trunk"

    return {
        "ci_systems": ci_systems,
        "has_ci": bool(ci_systems),
        "recent_activity": recent_activity,
        "branch_model": branch_model,
    }


# ---------------------------------------------------------------------------
# Aggregate
# ---------------------------------------------------------------------------

def analyse_project(cwd: Path | None = None) -> ProjectAnalysis:
    if cwd is None:
        cwd = Path.cwd()
    cwd = Path(cwd)

    primary_language, secondary_languages = detect_language(cwd)
    framework = detect_framework(cwd, primary_language)
    source_root = detect_source_root(cwd)
    test_layouts = detect_test_layout(cwd)
    docs = detect_docs(cwd)
    git = detect_git_history(cwd)

    return ProjectAnalysis(
        primary_language=primary_language,
        secondary_languages=secondary_languages,
        framework=framework,
        source_root=source_root,
        test_layouts=test_layouts,
        has_readme=docs["has_readme"],
        has_docs_dir=docs["has_docs_dir"],
        has_ci=git["has_ci"],
        ci_systems=git["ci_systems"],
        recent_activity=git["recent_activity"],
        branch_model=git["branch_model"],
    )


# Alias for callers that prefer analyze (American spelling)
analyze = analyse_project
