# Maestro Hub

**New in v5.0.0.** The Maestro Hub is a real-time, multi-workspace fleet
dashboard. Where `mso status` shows one workspace in one terminal, the Hub gives
you a single pane of glass across **every registered project** — live voyages,
orders, crews, queue depth, token usage, the human-review queue, and the
streaming lifecycle log.

The Hub has two pieces:

| Piece | Ships in | What it is |
|-------|----------|------------|
| **Backend** | the `maestro` pip package (`maestro.hub`) | A FastAPI service exposing a versioned REST API (`/api/v1/...`) + a lifecycle WebSocket. Aggregates state from every workspace in the global registry. |
| **Frontend** | the `maestro-hub/` source app | A Next.js dashboard that reads the backend API. Run from source with `npm run dev`. |

---

## Quick start

### 1. Start the backend

There are two ways to run the backend.

**`mso hub start` — managed daemon (Team / Enterprise licence).**

```bash
mso hub start                 # background daemon on http://127.0.0.1:3847
mso hub start --port 4000 --open   # custom port + open a browser
mso hub status                # is it running? (PID + URL)
mso hub stop                  # stop the daemon
```

`mso hub start` is gated to **Team / Enterprise** licences (the Hub aggregates
multiple workspaces, a fleet-scale feature). FastAPI / uvicorn are installed on
first run if missing — or pre-install them with the `hub` extra:

```bash
pip install 'maestro[hub]' --extra-index-url https://maestrodevs.github.io/simple/
```

**`python -m maestro.hub` — direct, ungated (single-operator / dev).**

```bash
python -m maestro.hub --port 3847
```

This runs the same FastAPI app in the foreground with no licence gate — handy for
local development or a single-operator setup. (The write-control endpoints —
dispatch / hold — are still tier-gated at the HTTP layer; see
[Tier gating](#tier-gating).)

### 2. Start the frontend

The dashboard UI lives in the `maestro-hub/` source directory.

```bash
cd maestro-hub
npm install
NEXT_PUBLIC_HUB_URL=http://localhost:3847 npm run dev   # → http://localhost:3000
```

Open <http://localhost:3000>. The frontend polls the backend every few seconds
and subscribes to the lifecycle WebSocket for live updates.

---

## What the Hub shows

- **Workspace overview** — one card per registered project: dispatcher
  running/stopped, active crews, active voyages, queued orders, pending reviews.
- **Voyage view** — voyages grouped into **Active / Proposed / Completed**
  accordions, each with a role-pipeline (PLN → BLD → TST → …) chip strip, the
  repo + worktree path, and a dependency-graph (DAG) of the orders.
- **Crew panels** — per-slot status, current order, iteration, activity age, PID.
- **Token usage** — per-workspace token totals, estimated cost, and a per-day
  history chart aggregated from `.mso/usage/orders/`.
- **Review queue** — every order paused at a human-review gate, across all
  workspaces, with approve / revise / reject actions.
- **Live lifecycle stream** — the dispatcher's `lifecycle.log` events as they
  happen, scopeable to a single workspace.
- **Dispatch / Hold controls** — start or stop a workspace's dispatcher from the
  UI (tier-gated; see below).

---

## How workspaces appear in the Hub

The Hub reads the **global project registry** at `~/.maestro/projects.json`. Any
workspace registered there shows up automatically. Workspaces are registered when
you run `mso init` / `mso dispatch` in them, or you can manage the list with:

```bash
mso projects list             # show registered workspaces
mso projects remove <ACRONYM> # drop one from the registry
```

If the Hub shows a workspace you no longer use (or is missing one you do), prune
or re-register it via `mso projects`.

---

## Tier gating

| Action | Gate |
|--------|------|
| Read-only API (`GET /api/v1/...`), lifecycle stream | Ungated on the direct `python -m maestro.hub` entry point. |
| `mso hub start` (managed daemon) | **Team / Enterprise** licence (`auth.require_tier`). |
| `POST .../dispatch`, `POST .../stop` (Dispatch / Hold) | **Team / Enterprise** at the HTTP layer → `403` otherwise. |

Setting `MAESTRO_SKIP_AUTH=1` bypasses both the licence check and the tier gate
(used by CI and local single-operator development).

---

## REST API reference

Base URL: `http://127.0.0.1:3847` (default port). All routes are under `/api/v1`.

| Method | Path | Returns |
|--------|------|---------|
| `GET` | `/health` | Service status, version, workspace count. |
| `GET` | `/workspaces` | Array of workspace summaries (the overview cards). |
| `GET` | `/workspaces/{id}` | Full workspace detail — voyages, orders, crews, queue summary, usage, config, repos. |
| `GET` | `/workspaces/{id}/crews` | Per-crew live state for one workspace. |
| `POST` | `/workspaces/{id}/dispatch` | Start the workspace's dispatcher (tier-gated). |
| `POST` | `/workspaces/{id}/stop` | Stop the workspace's dispatcher (tier-gated). |
| `GET` | `/review/queue` | Cross-workspace human-review queue (bare array). |
| `GET` | `/review/{order_id}/plan` | The plan markdown for an order awaiting review. |
| `POST` | `/review/{order_id}/approve` | Approve a paused order. |
| `POST` | `/review/{order_id}/revise` | Send an order back with feedback. |
| `POST` | `/review/{order_id}/reject` | Reject a paused order. |
| `WS` | `/lifecycle/stream` | Live lifecycle events. Add `?workspace_id=<id>` to scope to one workspace. |

The JSON shapes are defined by the Pydantic models in `maestro/hub/models.py`
and serialize exactly to the frontend TypeScript interfaces in
`maestro-hub/app/types/index.ts` (the authoritative data contract).

---

## Configuration

| Setting | Where | Default |
|---------|-------|---------|
| Backend port | `--port` on `mso hub start` / `python -m maestro.hub` | `3847` |
| Frontend → backend URL | `NEXT_PUBLIC_HUB_URL` env (frontend) | `http://localhost:3847` |
| Workspace registry | `~/.maestro/projects.json` | — |

Per-workspace dispatch defaults shown in the Hub's settings drawer
(`maxIterations`, `maxTurns`, `timeoutMinutes`, `autoDispatch`,
`requirePlanReview`, `tokenDailyCap`, `roleTimeouts`) live in each workspace's
`.mso/config/workspace.json`.

---

## Troubleshooting

- **Frontend shows "backend unreachable" / no live data** — confirm the backend
  is up (`mso hub status` or `curl http://127.0.0.1:3847/api/v1/health`) and that
  `NEXT_PUBLIC_HUB_URL` points at the right port.
- **`mso hub start` refuses with a tier error** — `mso hub` requires a Team /
  Enterprise licence. For single-operator/dev use, run the backend directly with
  `python -m maestro.hub --port 3847`.
- **A workspace is missing or stale** — check `mso projects list`; register with
  `mso init` / `mso dispatch` in the workspace, or remove with
  `mso projects remove <ACRONYM>`.
- **Dispatch / Hold buttons return 403** — those endpoints are tier-gated; use a
  Team / Enterprise licence or set `MAESTRO_SKIP_AUTH=1` for local development.
