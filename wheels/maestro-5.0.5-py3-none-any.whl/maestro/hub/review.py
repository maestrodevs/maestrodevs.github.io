# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Hub review module — parameterised review action handlers.

Mirrors the logic in maestro/review.py but:
  - accepts explicit workspace_path arguments (no find_workspace() call)
  - uses atomic writes (temp-file + rename) for all JSON mutations
  - raises exceptions instead of calling sys.exit() (caller maps to HTTP status)

Exception contract:
  FileNotFoundError  → 404 (order not in review queue for this workspace)
  ValueError         → 409 (order exists but is not in NAV_REVIEW_PENDING state)
"""

from __future__ import annotations

import json
import os
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Optional


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _get_mso_dir(workspace_path: Path) -> Path:
    from maestro.workspace import resolve_artefact_dir
    return resolve_artefact_dir(workspace_path)


def _write_atomic(path: Path, data: dict) -> None:
    """Write JSON to a temp file then rename — avoids partial writes."""
    content = json.dumps(data, indent=2)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(content, encoding="utf-8")
    tmp.replace(path)


def _write_lifecycle(mso: Path, event_type: str, message: str) -> None:
    log_dir = mso / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / "lifecycle.log"
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"{timestamp} | {event_type:<10} | {message}\n"
    try:
        with open(str(log_file), "a", encoding="utf-8") as f:
            f.write(line)
    except OSError:
        pass


def _reviewer() -> str:
    """Best-effort reviewer identity (git user or env fallback)."""
    try:
        result = subprocess.run(
            ["git", "config", "user.email"],
            capture_output=True, text=True, timeout=5,
        )
        email = result.stdout.strip()
        if email:
            return email
    except Exception:
        pass
    return os.environ.get("USER", os.environ.get("USERNAME", "hub-api"))


def _load_review_order(review_dir: Path, order_id: str) -> tuple[Path, dict]:
    """Load order from review queue; raise FileNotFoundError if absent."""
    order_file = review_dir / f"{order_id}.json"
    if not order_file.exists():
        raise FileNotFoundError(f"Order {order_id!r} not found in review queue")
    data = json.loads(order_file.read_text(encoding="utf-8"))
    return order_file, data


def _assert_nav_review_pending(order_id: str, data: dict) -> None:
    """Raise ValueError if order is not in an actionable review state."""
    status = (data.get("status") or "").upper()
    if status and status != "NAV_REVIEW_PENDING":
        raise ValueError(
            f"Order {order_id!r} has status {status!r}; expected NAV_REVIEW_PENDING"
        )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def find_review_pending_orders(workspace_path: Path) -> list[dict]:
    """Return all orders from queues/review/ (NAV_REVIEW_PENDING and unlabelled).

    Each dict contains the raw order JSON.  Callers use workspace_id from the
    outer registry loop — this function does not add it.
    """
    mso = _get_mso_dir(workspace_path)
    review_dir = mso / "queues" / "review"
    if not review_dir.exists():
        return []

    results: list[dict] = []
    for f in sorted(review_dir.glob("*.json")):
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
            results.append(data)
        except Exception:
            pass
    return results


def get_plan_content(workspace_path: Path, order_id: str) -> tuple[Optional[str], bool, Optional[dict]]:
    """Return (plan_markdown, has_plan_file, order_data).

    plan_markdown is the plan file content when has_plan_file=True, or the
    order's description field when False.  Returns (None, False, None) when
    the order is not found in the review queue.
    """
    mso = _get_mso_dir(workspace_path)
    review_dir = mso / "queues" / "review"
    order_file = review_dir / f"{order_id}.json"

    if not order_file.exists():
        return None, False, None

    try:
        data = json.loads(order_file.read_text(encoding="utf-8"))
    except Exception:
        return None, False, None

    plan_file = mso / "plans" / f"PLAN-{order_id}.md"
    if plan_file.exists():
        try:
            return plan_file.read_text(encoding="utf-8"), True, data
        except Exception:
            pass

    # Fallback: order description
    return (data.get("description") or ""), False, data


def approve_order(workspace_path: Path, order_id: str) -> dict:
    """Approve a NAV_REVIEW_PENDING order — mirrors mso review approve.

    Intra-order: sets status→PENDING, moves to queues/orders/.
    Plan-approval-only: sets status→COMPLETE, archives to orders/complete/.

    Returns {"new_status": <str>}.
    Raises FileNotFoundError (404) or ValueError (409).
    """
    mso = _get_mso_dir(workspace_path)
    review_dir = mso / "queues" / "review"
    order_file, data = _load_review_order(review_dir, order_id)
    _assert_nav_review_pending(order_id, data)

    now = datetime.now().isoformat()
    reviewer = _reviewer()
    data["reviewedAt"] = now
    data["reviewedBy"] = reviewer
    data.pop("navReviewPausedAt", None)

    if data.get("planApprovalOnly"):
        data["status"] = "COMPLETE"
        data["completedAt"] = now
        data.pop("planApprovalOnly", None)
        archive_dir = mso / "orders" / "complete"
        archive_dir.mkdir(parents=True, exist_ok=True)
        dest = archive_dir / order_file.name
        _write_atomic(dest, data)
        order_file.unlink()
        _write_lifecycle(
            mso, "NAV_REVIEW_APPROVED",
            f"{order_id} plan approved by {reviewer} -> COMPLETE (hub)",
        )
        return {"new_status": "COMPLETE"}

    next_role = data.get("targetRole", "BLD")
    data["status"] = "PENDING"
    orders_dir = mso / "queues" / "orders"
    orders_dir.mkdir(parents=True, exist_ok=True)
    dest = orders_dir / order_file.name
    _write_atomic(dest, data)
    order_file.unlink()
    _write_lifecycle(
        mso, "NAV_REVIEW_APPROVED",
        f"{order_id} approved by {reviewer} -> {next_role} (hub)",
    )
    return {"new_status": "PENDING"}


def revise_order(workspace_path: Path, order_id: str, feedback: str) -> dict:
    """Request revision — writes feedback, sets REVISION_REQUESTED, stays in review queue.

    Returns {"new_status": "REVISION_REQUESTED"}.
    Raises FileNotFoundError (404) or ValueError (409).
    """
    mso = _get_mso_dir(workspace_path)
    review_dir = mso / "queues" / "review"
    order_file, data = _load_review_order(review_dir, order_id)
    _assert_nav_review_pending(order_id, data)

    now = datetime.now().isoformat()
    reviewer = _reviewer()
    data["status"] = "REVISION_REQUESTED"
    data["reviewFeedback"] = feedback
    data["reviewedAt"] = now
    data["reviewedBy"] = reviewer

    _write_atomic(order_file, data)
    _write_lifecycle(
        mso, "NAV_REVIEW_REVISED",
        f"{order_id} revision requested by {reviewer}: {feedback[:80]} (hub)",
    )
    return {"new_status": "REVISION_REQUESTED"}


def reject_order(workspace_path: Path, order_id: str, reason: str) -> dict:
    """Reject an order — marks REJECTED, moves to queues/review/rejected/.

    Returns {"new_status": "REJECTED"}.
    Raises FileNotFoundError (404) or ValueError (409).
    """
    mso = _get_mso_dir(workspace_path)
    review_dir = mso / "queues" / "review"
    order_file, data = _load_review_order(review_dir, order_id)
    _assert_nav_review_pending(order_id, data)

    now = datetime.now().isoformat()
    reviewer = _reviewer()
    data["status"] = "REJECTED"
    data["rejectionReason"] = reason
    data["reviewedAt"] = now
    data["reviewedBy"] = reviewer

    rejected_dir = review_dir / "rejected"
    rejected_dir.mkdir(parents=True, exist_ok=True)
    dest = rejected_dir / order_file.name
    _write_atomic(dest, data)
    order_file.unlink()
    _write_lifecycle(
        mso, "NAV_REVIEW_REJECTED",
        f"{order_id} rejected by {reviewer}: {reason[:80]} (hub)",
    )
    return {"new_status": "REJECTED"}
