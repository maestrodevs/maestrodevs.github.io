# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Pydantic models for the Maestro Hub API (all phases in one module).

Field names here are chosen to serialize to JSON that matches the frontend
TypeScript interfaces in `maestro-hub/app/types/index.ts` EXACTLY (the
authoritative data contract). Top-level entity fields are snake_case to match
the TS interfaces; the WorkspaceConfig sub-object intentionally keeps camelCase
keys (maxCrews, completion.idleWatchdog...) because the frontend reads them
straight from .mso/config/workspace.json shapes.
"""

from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, Field


# ---- Phase 1 ----------------------------------------------------------------

class HealthResponse(BaseModel):
    status: str = "ok"
    version: str
    workspaces: int = 0


class WorkspaceSummary(BaseModel):
    id: str
    name: str
    path: str
    online: bool = True
    dispatcher_running: bool = False
    active_voyage_count: int = 0
    pending_order_count: int = 0
    active_crew_count: int = 0
    review_pending_count: int = 0
    # Frontend Workspace interface uses `pending_review_count`; mirror it so the
    # overview cards can read either name. (Kept additive — review_pending_count
    # above is preserved so existing consumers/tests don't break.)
    pending_review_count: int = 0


# ---- Phase 2 ----------------------------------------------------------------

class Order(BaseModel):
    """Matches the frontend `Order` interface (app/types/index.ts)."""
    id: str
    title: str = ""
    description: Optional[str] = None
    status: str = "PENDING"
    role: str = ""
    target_role: Optional[str] = None
    voyage_id: Optional[str] = None
    workspace_id: str = ""
    priority: Optional[str] = None  # 'high' | 'normal' | 'low'
    created_at: str = ""
    updated_at: Optional[str] = None
    started_at: Optional[str] = None
    completed_at: Optional[str] = None
    depends_on: Optional[list[str]] = None
    role_sequence: list[str] = Field(default_factory=list)
    timeout_minutes: Optional[int] = None
    iteration: Optional[int] = None
    max_iterations: Optional[int] = None
    target_repo: Optional[str] = None


class VoyageOrderRollup(BaseModel):
    """Effective member-order counts backing the derived voyage phase
    (FTR-MSO-2026-0351). Keys are camelCase by contract (order spec)."""
    total: int = 0
    complete: int = 0
    blocked: int = 0
    inProgress: int = 0
    pending: int = 0
    held: int = 0


class Voyage(BaseModel):
    """Matches the frontend `Voyage` interface."""
    id: str
    title: str = ""
    status: str = "PLANNED"
    branch: str = ""
    order_count: int = 0
    complete_count: int = 0
    orders: Optional[list[Order]] = None
    created_at: str = ""
    pr_url: Optional[str] = None
    workspace_id: str = ""
    repo: str = ""
    worktree: str = ""
    # FTR-MSO-2026-0351: derived lifecycle phase from ledger + archive + PR
    # state (the stored `status` above is kept as-is for back-compat).
    phase: str = "backlog"
    phaseReason: str = ""
    rollup: VoyageOrderRollup = Field(default_factory=VoyageOrderRollup)


class CrewState(BaseModel):
    """Matches the frontend `CrewState` interface."""
    slot: int
    name: str = ""
    status: str = "IDLE"
    role: Optional[str] = None
    current_order_id: Optional[str] = None
    current_order_title: Optional[str] = None
    iteration: Optional[int] = None
    max_iterations: Optional[int] = None
    activity_age_seconds: Optional[int] = None
    pid: Optional[int] = None
    session_id: Optional[str] = None
    maestro_session_id: Optional[str] = None


class Repo(BaseModel):
    """Matches the frontend `Repo` interface."""
    id: str
    name: str
    path: str
    default_branch: str = "main"


class IdleWatchdogConfig(BaseModel):
    enabled: bool = False
    idleMinutes: int = 30
    action: str = "none"


class OnVoyageCompleteConfig(BaseModel):
    archiveVoyageOnMerge: bool = True
    archiveOrders: bool = True
    autoRelease: bool = False


class CompletionConfig(BaseModel):
    idleWatchdog: Optional[IdleWatchdogConfig] = None
    onVoyageComplete: Optional[OnVoyageCompleteConfig] = None
    roleTimeouts: Optional[dict[str, int]] = None


class WorkspaceConfig(BaseModel):
    """Matches the frontend `WorkspaceConfig` interface (camelCase preserved)."""
    persona: Optional[str] = None
    project: Optional[str] = None
    maxCrews: Optional[int] = None
    completion: Optional[CompletionConfig] = None
    # FTR-MSO-2026-0328: per-workspace dispatch defaults (null = not configured)
    maxIterations: Optional[int] = None
    maxTurns: Optional[int] = None
    timeoutMinutes: Optional[int] = None
    autoDispatch: Optional[bool] = None
    requirePlanReview: Optional[bool] = None
    tokenDailyCap: Optional[int] = None


class UsagePoint(BaseModel):
    """One data point in a workspace token-usage history series."""
    date: str          # ISO date string (YYYY-MM-DD)
    tokens: int = 0
    cost_usd: float = 0.0


class WorkspaceUsage(BaseModel):
    """Aggregated token-usage metrics for a workspace (FTR-MSO-2026-0330)."""
    total_tokens: int = 0
    estimated_cost_usd: float = 0.0
    order_count: int = 0                        # number of orders with usage data
    history: list[UsagePoint] = Field(default_factory=list)  # per-day series (newest last)


class WorkspaceDetail(BaseModel):
    """Matches the frontend `WorkspaceDetail` (extends Workspace) interface."""
    id: str
    name: str
    path: str
    dispatcher_running: bool = False
    active_crew_count: int = 0
    active_voyage_count: int = 0
    pending_review_count: int = 0
    pending_order_count: int = 0
    persona: Optional[str] = None
    project: Optional[str] = None
    config: WorkspaceConfig = Field(default_factory=WorkspaceConfig)
    voyages: list[Voyage] = Field(default_factory=list)
    crews: list[CrewState] = Field(default_factory=list)
    queue_summary: dict[str, int] = Field(default_factory=dict)
    orders: list[Order] = Field(default_factory=list)
    repos: list[Repo] = Field(default_factory=list)
    usage: Optional[WorkspaceUsage] = None


class LifecycleEvent(BaseModel):
    """Matches the frontend `LifecycleEvent` interface (WebSocket stream)."""
    workspace_id: str
    workspace_name: str
    line: str = ""              # raw log line (kept for backward-compat)
    message: str = ""           # parsed message — frontend contract field
    timestamp: str = ""
    event_type: str = ""
    order_id: Optional[str] = None
    crew_slot: Optional[int] = None
    role: Optional[str] = None
    subtype: Optional[str] = None


# ---- Phase 3 ----------------------------------------------------------------

class ReviewItem(BaseModel):
    """Matches the frontend `ReviewItem` interface (BARE-ARRAY endpoint)."""
    order_id: str
    workspace_id: str
    workspace_name: str = ""
    order_title: str = ""
    role: str = ""
    voyage_id: Optional[str] = None
    plan_markdown: Optional[str] = None
    created_at: str = ""
    paused_at: Optional[str] = None
    priority: Optional[str] = None


class PlanResponse(BaseModel):
    workspace_id: str
    order_id: str
    plan_markdown: str = ""
    has_plan_file: bool = False
    order: dict


class ReviseRequest(BaseModel):
    feedback: str


class RejectRequest(BaseModel):
    reason: str


class ActionResult(BaseModel):
    ok: bool
    order_id: str
    new_status: str = ""
    message: str = ""


class ControlResult(BaseModel):
    """Result of a workspace dispatch/stop control action (Feature B)."""
    ok: bool
    workspace_id: str
    action: str = ""   # 'dispatch' | 'stop'
    message: str = ""
