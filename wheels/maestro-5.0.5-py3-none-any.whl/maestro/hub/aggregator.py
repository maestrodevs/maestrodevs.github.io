# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Hub aggregator — path-parameterised workspace state reader.

Pure read functions: no globals, no get_workspace_dir(). Designed for
the WorkspacePoller which calls these on arbitrary registered workspace roots.
"""

from __future__ import annotations

import json
import os
import time
from pathlib import Path
from typing import Optional

from maestro.hub.models import (
    CompletionConfig,
    CrewState,
    IdleWatchdogConfig,
    OnVoyageCompleteConfig,
    Order,
    Repo,
    UsagePoint,
    Voyage,
    VoyageOrderRollup,
    WorkspaceConfig,
    WorkspaceDetail,
    WorkspaceSummary,
    WorkspaceUsage,
)


# Crew display codenames by slot (data contract — frontend mock pins these).
# Falls back to the persona squad name (then "Crew<slot>") for slots beyond 5.
CREW_CODENAMES = {1: "Lion", 2: "Leopard", 3: "Cheetah", 4: "Hyena", 5: "Wild Dog"}


def _crew_name(slot: int) -> str:
    name = CREW_CODENAMES.get(slot)
    if name:
        return name
    try:
        from maestro import core_constants
        return core_constants.get_squad_name(slot) or f"Crew{slot}"
    except Exception:
        return f"Crew{slot}"


# Map raw order priority strings (HIGH/MEDIUM/LOW/etc) to the contract enum.
def _norm_priority(raw) -> Optional[str]:
    if not raw:
        return None
    p = str(raw).strip().lower()
    if p in ("high", "urgent", "critical"):
        return "high"
    if p in ("low",):
        return "low"
    if p in ("normal", "medium", "med", "default"):
        return "normal"
    return "normal"


# ---------------------------------------------------------------------------
# Low-level helpers (mirrored from fleet_monitor, parameterised by path)
# ---------------------------------------------------------------------------

def _load_json_safe(path: Path) -> Optional[dict]:
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def _is_process_alive(pid: int) -> bool:
    if not pid or pid <= 0:
        return False
    try:
        if os.name == "nt":
            import ctypes
            PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            STILL_ACTIVE = 259
            kernel32 = ctypes.windll.kernel32
            handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
            if handle == 0:
                return False
            try:
                exit_code = ctypes.c_ulong()
                if kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code)):
                    return exit_code.value == STILL_ACTIVE
                return False
            finally:
                kernel32.CloseHandle(handle)
        else:
            os.kill(pid, 0)
            return True
    except (ProcessLookupError, PermissionError, OSError):
        return False


# ---------------------------------------------------------------------------
# Workspace state readers (summary-level — Phase 1)
# ---------------------------------------------------------------------------

def _get_mso_dir(ws_root: Path) -> Path:
    from maestro.workspace import resolve_artefact_dir
    return resolve_artefact_dir(ws_root)


def _dispatcher_running(mso: Path) -> bool:
    pid_file = mso / "dispatcher.pid"
    if not pid_file.exists():
        return False
    try:
        pid = int(pid_file.read_text(encoding="utf-8").strip())
        return _is_process_alive(pid)
    except Exception:
        return False


def _count_active_voyages(mso: Path) -> int:
    voyages_dir = mso / "voyages" / "active"
    if not voyages_dir.exists():
        return 0
    count = 0
    for f in voyages_dir.glob("*.json"):
        data = _load_json_safe(f)
        if data and (data.get("status") or "").upper() not in ("AWAITING_APPROVAL", "COMPLETE"):
            count += 1
    return count


def _count_pending_orders(mso: Path) -> int:
    orders_dir = mso / "queues" / "orders"
    if not orders_dir.exists():
        return 0
    count = 0
    for f in orders_dir.glob("*.json"):
        data = _load_json_safe(f)
        if data:
            if data.get("status", "PENDING") == "PENDING":
                count += 1
        else:
            count += 1  # unreadable → treat as pending (mirrors fleet_monitor)
    return count


def _count_active_crews(mso: Path, max_crews: int = 5) -> int:
    count = 0
    for i in range(1, max_crews + 1):
        state = _load_json_safe(mso / "crews" / f"crew{i}" / "state.json")
        if state:
            status = (state.get("status") or "").upper()
            if status in ("RUNNING", "ACTIVE"):
                count += 1
    return count


def _count_review_pending(mso: Path) -> int:
    review_dir = mso / "queues" / "review"
    if not review_dir.exists():
        return 0
    return len(list(review_dir.glob("*.json")))


def _get_max_crews(mso: Path) -> int:
    settings = _load_json_safe(mso / "config" / "fleet-settings.json") or {}
    return int(settings.get("maxCrews", 5))


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def read_workspace_snapshot(ws_root: Path, id: str) -> WorkspaceSummary:
    """Read a summary-level snapshot of one registered workspace.

    Phase 1: returns WorkspaceSummary (counts only).
    Phase 2 will return full WorkspaceDetail.
    """
    mso = _get_mso_dir(ws_root)
    if not mso.is_dir():
        return offline_summary(id, str(ws_root))

    max_crews = _get_max_crews(mso)
    review_pending = _count_review_pending(mso)
    return WorkspaceSummary(
        id=id,
        name=id,
        path=str(ws_root),
        online=True,
        dispatcher_running=_dispatcher_running(mso),
        active_voyage_count=_count_active_voyages(mso),
        pending_order_count=_count_pending_orders(mso),
        active_crew_count=_count_active_crews(mso, max_crews),
        review_pending_count=review_pending,
        pending_review_count=review_pending,
    )


def offline_summary(acronym: str, path: str) -> WorkspaceSummary:
    """Return a WorkspaceSummary for an unreadable or missing workspace."""
    return WorkspaceSummary(
        id=acronym,
        name=acronym,
        path=path,
        online=False,
    )


# ---------------------------------------------------------------------------
# Phase 2 helpers — detail-level readers (contract-aligned)
# ---------------------------------------------------------------------------

# Maestro's on-disk order vocabulary is richer than the Hub's OrderStatus
# contract (app/types/index.ts). Map the extra statuses onto the contract set so
# the frontend renders them — without this, e.g. a running order (IN_PROGRESS)
# matched none of the frontend's RUNNING/PENDING filters and vanished from view.
_ORDER_STATUS_MAP = {
    "IN_PROGRESS": "RUNNING",
    "CLAIMED": "RUNNING",
    "DISPATCHED": "RUNNING",
    "COMPLETE_PENDING_STAGING": "COMPLETE",
    "COMPLETE_WITH_CONDITIONS": "COMPLETE",
    "RELEASE_APPROVED": "COMPLETE",
    "COMPLETED": "COMPLETE",
    "REQUEUE": "PENDING",
    "REOPENED": "PENDING",
}


def _norm_order_status(raw: Optional[str]) -> str:
    """Normalise a raw .mso order status onto the frontend OrderStatus contract."""
    s = (raw or "PENDING").strip()
    return _ORDER_STATUS_MAP.get(s.upper(), s)


def _derive_voyage_status(stored: Optional[str], member_orders: list) -> str:
    """Reflect live member-order state in the voyage status.

    The on-disk voyage `status` is often stale — e.g. PSG voyages stay at PLANNED
    after a crew starts work, so the dashboard showed an in-flight voyage as
    PLANNED even with a RUNNING order. When the stored status isn't terminal,
    surface ACTIVE if any member order is running. Completion stays owned by the
    dispatcher's gating — we never force COMPLETE here.
    """
    s = (stored or "").upper()
    if s in ("COMPLETE", "IN_REVIEW"):
        return s
    statuses = [(o.status or "").upper() for o in member_orders]
    # All members done → leave completion to the stored status / archival gating.
    if statuses and all(st == "COMPLETE" for st in statuses):
        return s or "PLANNED"
    # PLANNED means "not started". A voyage is started — and therefore ACTIVE —
    # once any member order has moved past the queue (running, complete, stalled,
    # etc.), not only while one is literally RUNNING (order files churn fast).
    not_started = {"", "PENDING", "BACKLOG", "PROPOSED", "NAV_REVIEW_PENDING"}
    started = any(st not in not_started for st in statuses)
    if started:
        return "ACTIVE"
    return s or "PLANNED"


def _apply_running_crew_voyage_status(voyages: list, crews: list) -> None:
    """Mark a voyage ACTIVE in-place when a running crew is on one of its orders.

    The crew state is the authoritative live signal: on a busy fleet the order
    files churn (IN_PROGRESS -> COMPLETE per role-phase while the crew advances)
    and the voyage JSON's stored status is often stale at PLANNED. Terminal
    statuses (COMPLETE / IN_REVIEW) are never downgraded.
    """
    running_ids = {
        c.current_order_id
        for c in crews
        if (getattr(c, "status", "") or "").upper() == "RUNNING" and c.current_order_id
    }
    if not running_ids:
        return
    for v in voyages:
        if (v.status or "").upper() in ("COMPLETE", "IN_REVIEW"):
            continue
        member_ids = {o.id for o in (v.orders or []) if o.id}
        if member_ids & running_ids:
            v.status = "ACTIVE"


def _map_order(data: dict, workspace_id: str) -> Order:
    """Map a raw .mso order JSON (camelCase) → contract Order (snake_case)."""
    oid = data.get("orderId") or data.get("id") or ""
    role = data.get("role") or data.get("targetRole") or ""
    target_role = data.get("targetRole")
    depends_on = data.get("dependsOn")
    if isinstance(depends_on, list):
        depends_on = [str(d) for d in depends_on] or None
    else:
        depends_on = None
    timeout = data.get("timeoutMinutes")
    iteration = data.get("iteration")
    max_iterations = data.get("maxIterations") or data.get("maxIters")
    return Order(
        id=oid,
        title=data.get("title", "") or "",
        description=data.get("description"),
        status=_norm_order_status(data.get("status")),
        role=role,
        target_role=target_role,
        voyage_id=data.get("voyageId"),
        workspace_id=workspace_id,
        priority=_norm_priority(data.get("priority")),
        created_at=data.get("createdAt", "") or "",
        updated_at=data.get("updatedAt"),
        started_at=data.get("startedAt"),
        completed_at=data.get("completedAt"),
        depends_on=depends_on,
        role_sequence=data.get("roleSequence", []) or [],
        timeout_minutes=int(timeout) if isinstance(timeout, (int, float)) else None,
        iteration=int(iteration) if isinstance(iteration, (int, float)) else None,
        max_iterations=int(max_iterations) if isinstance(max_iterations, (int, float)) else None,
        target_repo=data.get("targetRepo"),
    )


def _build_order_index(mso: Path, workspace_id: str) -> dict[str, Order]:
    """Index every discoverable order JSON by id (queues + active + complete).

    Live queue/active copies win over archived complete copies when ids collide.
    """
    index: dict[str, Order] = {}
    # complete first (lowest precedence), then active, then live queues (highest)
    search_dirs = [
        mso / "orders" / "complete",
        mso / "orders" / "active",
        mso / "queues" / "orders",
        mso / "queues" / "bugs",
        mso / "queues" / "security",
        mso / "queues" / "review",
        mso / "queues" / "requests",
        mso / "queues" / "escalations",
    ]
    for d in search_dirs:
        if not d.exists():
            continue
        for f in d.glob("*.json"):
            data = _load_json_safe(f)
            if not data:
                continue
            order = _map_order(data, workspace_id)
            if order.id:
                index[order.id] = order
    return index


def _queue_orders(mso: Path, workspace_id: str) -> list[Order]:
    """Orders currently sitting in the live queue dirs (the workspace's worklist)."""
    out: list[Order] = []
    for d in ["orders", "bugs", "security", "review", "requests", "escalations"]:
        qd = mso / "queues" / d
        if not qd.exists():
            continue
        for f in sorted(qd.glob("*.json")):
            data = _load_json_safe(f)
            if not data:
                continue
            order = _map_order(data, workspace_id)
            if order.id:
                out.append(order)
    return out


def _read_voyages(mso: Path, workspace_id: str, order_index: dict[str, Order]) -> list[Voyage]:
    """Read active + complete voyage JSONs → contract Voyage list."""
    from maestro.hub import phase as phase_mod

    # FTR-MSO-2026-0351: authoritative per-order state for the derived voyage
    # phase — loaded once per workspace read, shared across all voyages.
    ledger_view = phase_mod.load_ledger_view(mso)
    archive_statuses = phase_mod.read_archive_statuses(mso)

    def _dep_status(oid: str) -> str:
        fallback = order_index.get(oid)
        return phase_mod.effective_order_status(
            oid, fallback.status if fallback else None,
            ledger_view, archive_statuses)

    results: list[Voyage] = []
    for state, default_status in (("active", "ACTIVE"), ("complete", "COMPLETE")):
        voyages_dir = mso / "voyages" / state
        if not voyages_dir.exists():
            continue
        for f in sorted(voyages_dir.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True):
            data = _load_json_safe(f)
            if not data:
                continue
            if (data.get("status") or "").upper() == "AWAITING_APPROVAL":
                continue

            voyage_id = data.get("voyageId") or data.get("id") or f.stem
            raw_orders = data.get("orders") or []
            statuses = data.get("orderStatuses") or {}

            member_orders: list[Order] = []
            for o in raw_orders:
                if isinstance(o, dict):
                    oid = o.get("orderId") or o.get("id") or ""
                    resolved = order_index.get(oid)
                    if resolved is not None:
                        member_orders.append(resolved)
                    elif oid:
                        member = _map_order(o, workspace_id)
                        member.voyage_id = member.voyage_id or voyage_id
                        member_orders.append(member)
                else:
                    oid = str(o)
                    resolved = order_index.get(oid)
                    if resolved is not None:
                        member_orders.append(resolved)
                    else:
                        member_orders.append(Order(
                            id=oid,
                            status=(statuses.get(oid) or "PENDING"),
                            voyage_id=voyage_id,
                            workspace_id=workspace_id,
                        ))

            complete = sum(1 for o in member_orders if (o.status or "").upper() == "COMPLETE")
            status = _derive_voyage_status(data.get("status") or default_status, member_orders)

            # Feature A: repo = most common non-empty target_repo among members
            # (they share one); worktree = conventional active-voyage worktree path.
            from collections import Counter
            repo_counts = Counter(
                (o.target_repo or "").strip()
                for o in member_orders
                if (o.target_repo or "").strip()
            )
            repo = repo_counts.most_common(1)[0][0] if repo_counts else ""

            worktree = ""
            if status == "ACTIVE":
                wt_path = mso / "voyages" / "active" / voyage_id / ".worktree"
                worktree = wt_path.as_posix()

            # FTR-MSO-2026-0351: derived phase from ledger + archive + PR state
            # — never from the stored voyage `status` (static/stale).
            pr_merged = bool(
                data.get("mergedPR") or data.get("mergedAt")
                or data.get("prMerged") or data.get("mergeCommit")
            )
            member_states = [
                phase_mod.MemberState(
                    order_id=o.id,
                    status=phase_mod.effective_order_status(
                        o.id, o.status, ledger_view, archive_statuses),
                    role=o.target_role or o.role or "",
                    depends_on=list(o.depends_on or []),
                )
                for o in member_orders
            ]
            derived = phase_mod.compute_voyage_phase(
                member_states,
                pr_merged=pr_merged,
                voyage_archived=(state == "complete"),
                dep_status=_dep_status,
            )

            results.append(Voyage(
                id=voyage_id,
                title=data.get("title", "") or "",
                status=status,
                branch=data.get("branch") or data.get("voyageBranch") or "",
                order_count=len(member_orders),
                complete_count=complete,
                orders=member_orders or None,
                created_at=data.get("createdAt", "") or "",
                pr_url=data.get("prUrl") or data.get("pr_url"),
                workspace_id=workspace_id,
                repo=repo,
                worktree=worktree,
                phase=derived.phase,
                phaseReason=derived.reason,
                rollup=VoyageOrderRollup(**derived.rollup),
            ))
    return results


def _read_one_crew(mso: Path, slot: int) -> CrewState:
    """Read state.json for one crew slot; returns IDLE CrewState if missing."""
    name = _crew_name(slot)
    state_file = mso / "crews" / f"crew{slot}" / "state.json"
    data = _load_json_safe(state_file)
    if not data:
        return CrewState(slot=slot, name=name, status="IDLE")

    activity_age: Optional[int] = None
    activity_file = mso / "crews" / f"crew{slot}" / "activity.txt"
    if activity_file.exists():
        try:
            if activity_file.read_text(encoding="utf-8").strip():
                activity_age = int(time.time() - activity_file.stat().st_mtime)
        except Exception:
            pass

    def _int_or_none(v):
        return int(v) if isinstance(v, (int, float)) else None

    return CrewState(
        slot=slot,
        name=name,
        status=data.get("status", "IDLE") or "IDLE",
        role=data.get("role") or None,
        current_order_id=data.get("orderId") or data.get("currentOrderId") or None,
        current_order_title=data.get("orderTitle") or data.get("currentOrderTitle") or None,
        iteration=_int_or_none(data.get("iteration")),
        max_iterations=_int_or_none(data.get("maxIterations")),
        activity_age_seconds=activity_age,
        pid=_int_or_none(data.get("pid")),
        session_id=data.get("claudeSessionId") or data.get("sessionId") or None,
        maestro_session_id=data.get("maestroSessionId") or None,
    )


def _read_crews(mso: Path, max_crews: int = 5) -> list[CrewState]:
    """Read crew state for all slots (1..max_crews)."""
    return [_read_one_crew(mso, i) for i in range(1, max_crews + 1)]


def _read_queue_summary(mso: Path) -> dict[str, int]:
    """Counts per queue dir (Record<string,number> for the frontend)."""
    queues = mso / "queues"
    summary: dict[str, int] = {}
    if not queues.exists():
        return summary
    for d in sorted(p for p in queues.iterdir() if p.is_dir()):
        n = len(list(d.glob("*.json")))
        if n:
            summary[d.name] = n
    return summary


def _read_config(mso: Path, workspace_id: str) -> tuple[WorkspaceConfig, Optional[str], Optional[str]]:
    """Read workspace.json + gates.json → (WorkspaceConfig, persona, project).

    FTR-MSO-2026-0328: exposes all per-workspace dispatch defaults so the Hub
    drawer can show real values instead of hardcoded mocks.  Fields absent from
    workspace.json are returned as None (frontend renders "using default").
    """
    ws = _load_json_safe(mso / "config" / "workspace.json") or {}

    persona = ws.get("persona") or "nautical"
    project = ws.get("project") or workspace_id

    max_crews = ws.get("maxCrews")
    if max_crews is None:
        # fall back to fleet-settings.json if present (legacy)
        fleet = _load_json_safe(mso / "config" / "fleet-settings.json") or {}
        max_crews = fleet.get("maxCrews")
    max_crews = int(max_crews) if isinstance(max_crews, (int, float)) else None

    def _int_opt(v) -> Optional[int]:
        return int(v) if isinstance(v, (int, float)) else None

    completion_cfg = None
    raw_completion = ws.get("completion")
    role_timeouts: Optional[dict[str, int]] = None
    if isinstance(raw_completion, dict):
        idle = raw_completion.get("idleWatchdog")
        ovc = raw_completion.get("onVoyageComplete")
        rt = raw_completion.get("roleTimeouts")
        if isinstance(rt, dict):
            role_timeouts = {str(k): int(v) for k, v in rt.items() if isinstance(v, (int, float))}
        completion_cfg = CompletionConfig(
            idleWatchdog=IdleWatchdogConfig(
                enabled=bool(idle.get("enabled", False)),
                idleMinutes=int(idle.get("idleMinutes", 30)),
                action=str(idle.get("action", "none")),
            ) if isinstance(idle, dict) else None,
            onVoyageComplete=OnVoyageCompleteConfig(
                archiveVoyageOnMerge=bool(ovc.get("archiveVoyageOnMerge", True)),
                archiveOrders=bool(ovc.get("archiveOrders", True)),
                autoRelease=bool(ovc.get("autoRelease", False)),
            ) if isinstance(ovc, dict) else None,
            roleTimeouts=role_timeouts,
        )

    # Workspace-level dispatch defaults (all optional; absent → None → "using default" in UI)
    max_iterations = _int_opt(ws.get("maxIterations"))
    max_turns = _int_opt(ws.get("maxTurns"))
    timeout_minutes = _int_opt(ws.get("timeoutMinutes"))
    auto_dispatch_raw = ws.get("autoDispatch")
    auto_dispatch = bool(auto_dispatch_raw) if auto_dispatch_raw is not None else None
    token_daily_cap = _int_opt(ws.get("tokenDailyCap"))

    # requirePlanReview: read from gates.json post_nav_review.enabled
    require_plan_review: Optional[bool] = None
    gates = _load_json_safe(mso / "config" / "gates.json") or {}
    post_nav = gates.get("post_nav_review")
    if isinstance(post_nav, dict):
        require_plan_review = bool(post_nav.get("enabled", False))

    config = WorkspaceConfig(
        persona=persona,
        project=project,
        maxCrews=max_crews,
        completion=completion_cfg,
        maxIterations=max_iterations,
        maxTurns=max_turns,
        timeoutMinutes=timeout_minutes,
        autoDispatch=auto_dispatch,
        requirePlanReview=require_plan_review,
        tokenDailyCap=token_daily_cap,
    )
    return config, persona, project


def _read_repos(mso: Path, ws_root: Path, workspace_id: str) -> list[Repo]:
    """Read managed repos from workspace config, else a sensible default."""
    ws = _load_json_safe(mso / "config" / "workspace.json") or {}
    raw = ws.get("managedRepos") or ws.get("repos") or []
    repos: list[Repo] = []
    if isinstance(raw, list):
        for r in raw:
            if isinstance(r, dict):
                name = r.get("name") or r.get("id") or ""
                path = r.get("path") or ""
                repos.append(Repo(
                    id=r.get("id") or name or path,
                    name=name or (Path(path).name if path else workspace_id),
                    path=path or str(ws_root),
                    default_branch=r.get("defaultBranch") or r.get("default_branch") or "main",
                ))
            elif isinstance(r, str):
                repos.append(Repo(id=r, name=Path(r).name, path=r, default_branch="main"))
    return repos


def _max_crews(mso: Path) -> int:
    ws = _load_json_safe(mso / "config" / "workspace.json") or {}
    mc = ws.get("maxCrews")
    if isinstance(mc, (int, float)):
        return int(mc)
    return _get_max_crews(mso)


def _dispatcher_pid(mso: Path) -> Optional[int]:
    pid_file = mso / "dispatcher.pid"
    if not pid_file.exists():
        return None
    try:
        return int(pid_file.read_text(encoding="utf-8").strip())
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Usage aggregation (FTR-MSO-2026-0330)
# ---------------------------------------------------------------------------

def _read_usage_stats(mso: Path, history_days: int = 14) -> WorkspaceUsage:
    """Aggregate token usage from .mso/usage/orders/*.json.

    Builds a daily history series (newest-last, up to history_days entries)
    suitable for the frontend sparkline.  Returns a zero WorkspaceUsage when
    the usage directory is absent or unreadable.
    """
    usage_dir = mso / "usage" / "orders"
    if not usage_dir.is_dir():
        return WorkspaceUsage()

    total_tokens: int = 0
    total_cost: float = 0.0
    order_count: int = 0
    # bucket: date-string → (tokens, cost)
    buckets: dict[str, tuple[int, float]] = {}

    for f in usage_dir.glob("*.json"):
        data = _load_json_safe(f)
        if not data:
            continue
        tokens = data.get("total_tokens") or 0
        cost = data.get("estimated_cost_usd") or 0.0
        if not isinstance(tokens, (int, float)):
            tokens = 0
        if not isinstance(cost, (int, float)):
            cost = 0.0
        tokens = int(tokens)
        cost = float(cost)

        total_tokens += tokens
        total_cost += cost
        order_count += 1

        ts = data.get("timestamp") or ""
        date_key = ts[:10] if len(ts) >= 10 else "unknown"
        prev_t, prev_c = buckets.get(date_key, (0, 0.0))
        buckets[date_key] = (prev_t + tokens, prev_c + cost)

    # Build sorted history series, capped to history_days (skipping "unknown")
    sorted_dates = sorted(
        (d for d in buckets if d != "unknown"),
        reverse=False,
    )[-history_days:]
    history = [
        UsagePoint(date=d, tokens=buckets[d][0], cost_usd=round(buckets[d][1], 4))
        for d in sorted_dates
    ]

    return WorkspaceUsage(
        total_tokens=total_tokens,
        estimated_cost_usd=round(total_cost, 4),
        order_count=order_count,
        history=history,
    )


# ---------------------------------------------------------------------------
# Phase 2 public API
# ---------------------------------------------------------------------------

def build_workspace_detail(ws_root: Path, workspace_id: str) -> WorkspaceDetail:
    """Build a full WorkspaceDetail matching the frontend contract.

    Returns an offline detail (no 500) when .mso/ is missing or unreadable.
    """
    try:
        mso = _get_mso_dir(ws_root)
        if not mso.is_dir():
            return offline_detail(workspace_id, str(ws_root))

        max_crews = _max_crews(mso)
        disp_pid = _dispatcher_pid(mso)
        config, persona, project = _read_config(mso, workspace_id)
        order_index = _build_order_index(mso, workspace_id)
        voyages = _read_voyages(mso, workspace_id, order_index)
        crews = _read_crews(mso, max_crews)
        orders = _queue_orders(mso, workspace_id)
        queue_summary = _read_queue_summary(mso)
        usage = _read_usage_stats(mso)

        # A voyage with a live crew running one of its orders is ACTIVE — the
        # crew state is the authoritative "in-flight" signal. On a busy fleet the
        # order FILES churn (an order flips IN_PROGRESS -> COMPLETE per role-phase
        # while the crew advances to the next role), and the voyage JSON's own
        # status is often left stale at PLANNED. Reconcile against running crews.
        _apply_running_crew_voyage_status(voyages, crews)

        return WorkspaceDetail(
            id=workspace_id,
            name=workspace_id,
            path=str(ws_root),
            dispatcher_running=_is_process_alive(disp_pid) if disp_pid else False,
            active_crew_count=_count_active_crews(mso, max_crews),
            active_voyage_count=_count_active_voyages(mso),
            pending_review_count=_count_review_pending(mso),
            pending_order_count=_count_pending_orders(mso),
            persona=persona,
            project=project,
            config=config,
            voyages=voyages,
            crews=crews,
            queue_summary=queue_summary,
            orders=orders,
            repos=_read_repos(mso, ws_root, workspace_id),
            usage=usage,
        )
    except Exception:
        return offline_detail(workspace_id, str(ws_root))


def build_crew_list(ws_root: Path, workspace_id: str) -> list[CrewState]:
    """Build a bare CrewState[] (always max_crews slots, IDLE for non-running)."""
    try:
        mso = _get_mso_dir(ws_root)
        if mso.is_dir():
            return _read_crews(mso, _max_crews(mso))
    except Exception:
        pass
    return [CrewState(slot=i, name=_crew_name(i)) for i in range(1, 6)]


def offline_detail(workspace_id: str, path: str) -> WorkspaceDetail:
    """Return a WorkspaceDetail for an unreadable or missing workspace."""
    return WorkspaceDetail(
        id=workspace_id,
        name=workspace_id,
        path=path,
        config=WorkspaceConfig(project=workspace_id),
        crews=[CrewState(slot=i, name=_crew_name(i)) for i in range(1, 6)],
    )
