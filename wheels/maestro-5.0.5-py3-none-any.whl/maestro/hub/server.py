# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Maestro Hub FastAPI application.

FastAPI and uvicorn are imported lazily inside create_app() so that
`import maestro.hub.server` never fails when the [hub] extra is absent.
"""

# Poll interval (seconds) for the WebSocket lifecycle stream. Patchable in tests.
_WS_POLL_INTERVAL: float = 2.0


def create_app():
    """Build and return the FastAPI application."""
    from contextlib import asynccontextmanager

    import fastapi
    from fastapi.middleware.cors import CORSMiddleware

    import maestro
    from maestro.hub.models import (
        ActionResult,
        ControlResult,
        CrewState,
        HealthResponse,
        PlanResponse,
        RejectRequest,
        ReviewItem,
        ReviseRequest,
        WorkspaceDetail,
        WorkspaceSummary,
    )
    from maestro.hub.poller import WorkspacePoller

    @asynccontextmanager
    async def lifespan(app: fastapi.FastAPI):
        poller = WorkspacePoller(interval=5.0)
        poller.start()
        app.state.poller = poller
        try:
            yield
        finally:
            poller.stop()

    import os
    import re

    app = fastapi.FastAPI(
        title="Maestro Hub",
        version=maestro.__version__,
        lifespan=lifespan,
    )

    # --- Security configuration (audit findings H4/H5/H6) -------------------
    # The Hub binds to 127.0.0.1, but a wildcard CORS policy + no Host/Origin
    # validation previously made it a browser-reachable, DNS-rebindable control
    # plane. We now: (1) allow only explicit localhost origins for CORS, (2)
    # validate the Host header to defeat DNS rebinding, and (3) enforce a bearer
    # token when one is configured (env MAESTRO_HUB_TOKEN or ~/.maestro/hub.token).
    # The token is opt-in so the existing localhost frontend keeps working; it is
    # strongly recommended on shared/multi-user hosts (see docs/security).
    def _configured_origins():
        raw = os.environ.get("MAESTRO_HUB_ALLOWED_ORIGINS", "").strip()
        if raw:
            return [o.strip() for o in raw.split(",") if o.strip()]
        return [
            "http://localhost:3000", "http://127.0.0.1:3000",
            "http://localhost:3847", "http://127.0.0.1:3847",
        ]

    def _allowed_hosts():
        # localhost forms + the Starlette TestClient sentinel ("testserver").
        # A DNS-rebinding attacker uses their OWN hostname (which resolves to
        # 127.0.0.1), so it is still blocked; "testserver" is never a real host.
        base = {"127.0.0.1", "localhost", "::1", "[::1]", "testserver", ""}
        raw = os.environ.get("MAESTRO_HUB_ALLOWED_HOSTS", "").strip()
        if raw:
            base |= {h.strip() for h in raw.split(",") if h.strip()}
        return base

    def _expected_token():
        tok = os.environ.get("MAESTRO_HUB_TOKEN", "").strip()
        if tok:
            return tok
        try:
            from pathlib import Path as _P
            p = _P.home() / ".maestro" / "hub.token"
            if p.exists():
                return p.read_text(encoding="utf-8").strip() or None
        except Exception:
            pass
        return None

    _ORIGINS = _configured_origins()

    app.add_middleware(
        CORSMiddleware,
        allow_origins=_ORIGINS,
        allow_credentials=False,
        allow_methods=["GET", "POST", "OPTIONS"],
        allow_headers=["Authorization", "Content-Type"],
    )

    @app.middleware("http")
    async def _host_and_auth_guard(request, call_next):
        # Host-header allowlist — defeats DNS rebinding against the localhost bind.
        host = (request.headers.get("host") or "").rsplit(":", 1)[0].strip("[]")
        if host and host not in {h.strip("[]") for h in _allowed_hosts()}:
            return fastapi.responses.JSONResponse(
                status_code=403, content={"detail": f"Host '{host}' not allowed"})
        # Bearer token — enforced only when configured; /health stays open for liveness.
        token = _expected_token()
        if token and request.url.path.startswith("/api/") and request.url.path != "/api/v1/health":
            auth = request.headers.get("authorization", "")
            presented = auth[7:].strip() if auth.lower().startswith("bearer ") else ""
            import hmac as _hmac
            if not presented or not _hmac.compare_digest(presented, token):
                return fastapi.responses.JSONResponse(
                    status_code=401, content={"detail": "missing or invalid bearer token"})
        return await call_next(request)

    _ORDER_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,64}$")

    def _validate_order_id(order_id: str):
        """Reject order ids that could escape the review directory (H-M path traversal)."""
        if not order_id or ".." in order_id or "/" in order_id or "\\" in order_id \
                or not _ORDER_ID_RE.match(order_id):
            raise fastapi.HTTPException(status_code=400, detail="invalid order id")

    @app.get("/api/v1/health", response_model=HealthResponse)
    async def health():
        poller: WorkspacePoller = app.state.poller
        summaries = poller.summaries()
        return HealthResponse(
            status="ok",
            version=maestro.__version__,
            workspaces=len(summaries),
        )

    @app.get("/api/v1/workspaces", response_model=list[WorkspaceSummary])
    async def list_workspaces():
        poller: WorkspacePoller = app.state.poller
        return poller.summaries()

    @app.get("/api/v1/workspaces/{workspace_id}", response_model=WorkspaceDetail)
    async def get_workspace_detail(workspace_id: str):
        poller: WorkspacePoller = app.state.poller
        detail = poller.detail(workspace_id)
        if detail is None:
            raise fastapi.HTTPException(status_code=404, detail=f"Workspace '{workspace_id}' not found")
        return detail

    @app.get("/api/v1/workspaces/{workspace_id}/crews", response_model=list[CrewState])
    async def get_workspace_crews(workspace_id: str):
        import maestro.registry as registry
        from pathlib import Path
        from maestro.hub import aggregator

        projects = registry.list_projects()
        if workspace_id not in projects:
            raise fastapi.HTTPException(status_code=404, detail=f"Workspace '{workspace_id}' not found")
        ws_root = Path(projects[workspace_id]["path"])
        return aggregator.build_crew_list(ws_root, workspace_id)

    # -----------------------------------------------------------------------
    # Dispatch control endpoints (Feature B) — localhost-only by binding
    # -----------------------------------------------------------------------

    def _resolve_workspace_root(workspace_id: str):
        """Return the workspace root Path or raise 404."""
        import maestro.registry as registry
        from pathlib import Path
        projects = registry.list_projects()
        if workspace_id not in projects:
            raise fastapi.HTTPException(
                status_code=404, detail=f"Workspace '{workspace_id}' not found")
        return Path(projects[workspace_id]["path"])

    def _require_control_tier():
        """Tier gate matching the CLI `hub` command — Team/Enterprise only.

        Uses auth.has_tier (non-exiting) so an HTTP 403 is returned instead of
        the CLI's sys.exit. has_tier returns True when MAESTRO_SKIP_AUTH=1.
        """
        from maestro import auth
        if not auth.has_tier(auth.HUB_TIERS):
            raise fastapi.HTTPException(
                status_code=403,
                detail="Maestro Hub dispatch control requires a Team or Enterprise licence.",
            )

    @app.post("/api/v1/workspaces/{workspace_id}/dispatch", response_model=ControlResult)
    async def dispatch_workspace(workspace_id: str):
        """Start the dispatcher for a workspace as a detached background process."""
        import os
        import subprocess
        import sys
        from pathlib import Path
        from maestro.hub import aggregator

        _require_control_tier()
        ws_root = _resolve_workspace_root(workspace_id)
        mso = ws_root / ".mso"

        # Don't spawn a duplicate if one is already running.
        try:
            if aggregator._dispatcher_running(mso):
                return ControlResult(
                    ok=True, workspace_id=workspace_id, action="dispatch",
                    message="Dispatcher already running",
                )
        except Exception:
            pass

        env = {**os.environ, "MAESTRO_DIR": str(mso)}
        cmd = [sys.executable, "-m", "maestro.cli", "dispatch", "--max-crews", "5"]
        kwargs = dict(
            cwd=str(ws_root),
            env=env,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        if os.name == "nt":
            DETACHED_PROCESS = 0x00000008
            CREATE_NEW_PROCESS_GROUP = 0x00000200
            kwargs["creationflags"] = DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
            kwargs["close_fds"] = True
        else:
            kwargs["start_new_session"] = True
        subprocess.Popen(cmd, **kwargs)
        return ControlResult(
            ok=True, workspace_id=workspace_id, action="dispatch",
            message="Dispatcher starting",
        )

    @app.post("/api/v1/workspaces/{workspace_id}/stop", response_model=ControlResult)
    async def stop_workspace(workspace_id: str):
        """Stop (hold) the dispatcher + crews for a workspace via scoped cleanup."""
        import os
        import subprocess
        import sys

        _require_control_tier()
        ws_root = _resolve_workspace_root(workspace_id)
        mso = ws_root / ".mso"

        env = {**os.environ, "MAESTRO_DIR": str(mso)}
        try:
            subprocess.run(
                [sys.executable, "-m", "maestro.cli", "cleanup", "--no-backup"],
                cwd=str(ws_root),
                env=env,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=60,
            )
        except subprocess.TimeoutExpired:
            return ControlResult(
                ok=False, workspace_id=workspace_id, action="stop",
                message="Cleanup timed out",
            )
        return ControlResult(
            ok=True, workspace_id=workspace_id, action="stop",
            message="Dispatcher stopped",
        )

    # -----------------------------------------------------------------------
    # Phase 3 — Review queue endpoints
    # -----------------------------------------------------------------------

    def _iter_workspaces():
        """Yield (workspace_id, Path) for every registered workspace."""
        import maestro.registry as registry
        from pathlib import Path
        for ws_id, entry in registry.list_projects().items():
            yield ws_id, Path(entry["path"])

    def _find_order_workspace(order_id: str):
        """Return (workspace_id, workspace_path) for an order in any review queue.

        Raises HTTPException 404 if not found in any registered workspace.
        """
        _validate_order_id(order_id)
        from maestro.hub.review import _get_mso_dir
        for ws_id, ws_root in _iter_workspaces():
            try:
                mso = _get_mso_dir(ws_root)
                if (mso / "queues" / "review" / f"{order_id}.json").exists():
                    return ws_id, ws_root
            except Exception:
                pass
        raise fastapi.HTTPException(status_code=404, detail=f"Order '{order_id}' not found in any review queue")

    @app.get("/api/v1/review/queue", response_model=list[ReviewItem])
    async def review_queue():
        """List all NAV_REVIEW_PENDING orders across all registered workspaces.

        Returns a BARE ARRAY of ReviewItem (frontend api.ts contract).
        """
        from maestro.hub.review import find_review_pending_orders
        items: list[ReviewItem] = []
        for ws_id, ws_root in _iter_workspaces():
            try:
                orders = find_review_pending_orders(ws_root)
            except Exception:
                continue
            for data in orders:
                order_id = data.get("id") or data.get("orderId") or ""
                role = "PLN" if data.get("planApprovalOnly") else (data.get("targetRole") or data.get("role") or "")
                priority = (str(data.get("priority")).lower() if data.get("priority") else None)
                if priority in ("medium", "med", "default"):
                    priority = "normal"
                elif priority in ("urgent", "critical"):
                    priority = "high"
                items.append(ReviewItem(
                    order_id=order_id,
                    workspace_id=ws_id,
                    workspace_name=ws_id,
                    order_title=data.get("title", "") or "",
                    role=role,
                    voyage_id=data.get("voyageId") or None,
                    created_at=data.get("createdAt", "") or "",
                    paused_at=data.get("navReviewPausedAt") or None,
                    priority=priority if priority in ("high", "normal", "low") else None,
                ))
        return items

    @app.get("/api/v1/review/{order_id}/plan", response_model=PlanResponse)
    async def review_get_plan(order_id: str):
        """Return plan markdown (or order description as fallback) plus order JSON."""
        from maestro.hub.review import get_plan_content
        ws_id, ws_root = _find_order_workspace(order_id)
        plan_md, has_plan, order_data = get_plan_content(ws_root, order_id)
        if order_data is None:
            raise fastapi.HTTPException(status_code=404, detail=f"Order '{order_id}' not found")
        return PlanResponse(
            workspace_id=ws_id,
            order_id=order_id,
            plan_markdown=plan_md or "",
            has_plan_file=has_plan,
            order=order_data,
        )

    @app.post("/api/v1/review/{order_id}/approve", response_model=ActionResult)
    async def review_approve(order_id: str):
        """Approve a NAV_REVIEW_PENDING order — moves to queues/orders/ with status PENDING."""
        _require_control_tier()
        from maestro.hub.review import approve_order
        ws_id, ws_root = _find_order_workspace(order_id)
        try:
            result = approve_order(ws_root, order_id)
        except FileNotFoundError as exc:
            raise fastapi.HTTPException(status_code=404, detail=str(exc))
        except ValueError as exc:
            raise fastapi.HTTPException(status_code=409, detail=str(exc))
        return ActionResult(ok=True, order_id=order_id, new_status=result["new_status"],
                            message=f"Order {order_id} approved")

    @app.post("/api/v1/review/{order_id}/revise", response_model=ActionResult)
    async def review_revise(order_id: str, body: ReviseRequest):
        """Request revision — writes feedback to order, leaves in review queue."""
        _require_control_tier()
        from maestro.hub.review import revise_order
        ws_id, ws_root = _find_order_workspace(order_id)
        try:
            result = revise_order(ws_root, order_id, body.feedback)
        except FileNotFoundError as exc:
            raise fastapi.HTTPException(status_code=404, detail=str(exc))
        except ValueError as exc:
            raise fastapi.HTTPException(status_code=409, detail=str(exc))
        return ActionResult(ok=True, order_id=order_id, new_status=result["new_status"],
                            message=f"Order {order_id} sent for revision")

    @app.post("/api/v1/review/{order_id}/reject", response_model=ActionResult)
    async def review_reject(order_id: str, body: RejectRequest):
        """Reject an order — marks REJECTED, moves to queues/review/rejected/."""
        _require_control_tier()
        from maestro.hub.review import reject_order
        ws_id, ws_root = _find_order_workspace(order_id)
        try:
            result = reject_order(ws_root, order_id, body.reason)
        except FileNotFoundError as exc:
            raise fastapi.HTTPException(status_code=404, detail=str(exc))
        except ValueError as exc:
            raise fastapi.HTTPException(status_code=409, detail=str(exc))
        return ActionResult(ok=True, order_id=order_id, new_status=result["new_status"],
                            message=f"Order {order_id} rejected")

    @app.websocket("/api/v1/lifecycle/stream")
    async def lifecycle_stream(websocket: fastapi.WebSocket):
        import asyncio
        import maestro.registry as registry
        import maestro.hub.server as _server_mod
        from pathlib import Path
        from maestro.hub.lifecycle_tail import (
            LifecycleTail, _parse_event_type, _parse_timestamp, _parse_message,
            _parse_order_id, _parse_role, _parse_crew_slot, _parse_subtype,
        )
        from maestro.hub.models import LifecycleEvent

        def _build_event(ws_id: str, ws_name: str, line: str) -> LifecycleEvent:
            return LifecycleEvent(
                workspace_id=ws_id,
                workspace_name=ws_name,
                line=line,
                message=_parse_message(line),
                timestamp=_parse_timestamp(line),
                event_type=_parse_event_type(line),
                order_id=_parse_order_id(line),
                crew_slot=_parse_crew_slot(line),
                role=_parse_role(line),
                subtype=_parse_subtype(line),
            )

        # Audit finding H6: WebSockets bypass CORS, so validate the Origin
        # against the allowlist and enforce the bearer token (query param) BEFORE
        # accepting — otherwise any web page could open ws:// to the localhost
        # Hub and live-tail every workspace's lifecycle log.
        origin = websocket.headers.get("origin")
        if origin and origin not in _ORIGINS:
            await websocket.close(code=1008)
            return
        _tok = _expected_token()
        if _tok:
            import hmac as _hmac
            presented = websocket.query_params.get("token", "")
            if not presented or not _hmac.compare_digest(presented, _tok):
                await websocket.close(code=1008)
                return

        await websocket.accept()
        try:
            projects = registry.list_projects()
            # Optional ?workspace_id=<ID> scopes the stream to one workspace
            # (the detail page passes it); absent → stream all (overview page).
            only = websocket.query_params.get("workspace_id")
            if only:
                projects = {k: v for k, v in projects.items() if k == only}
            tails: dict[str, tuple[str, LifecycleTail]] = {
                ws_id: (ws_id, LifecycleTail(Path(entry["path"])))
                for ws_id, entry in projects.items()
            }

            # Backfill: send last 20 lines per workspace on connect
            for ws_id, (ws_name, tail) in tails.items():
                for line in tail.read_last_n(20):
                    await websocket.send_json(_build_event(ws_id, ws_name, line).model_dump())
                tail.seek_to_end()

            # Poll loop: push new lines every _WS_POLL_INTERVAL seconds
            while True:
                await asyncio.sleep(_server_mod._WS_POLL_INTERVAL)
                for ws_id, (ws_name, tail) in tails.items():
                    for line in tail.read_new_lines():
                        await websocket.send_json(_build_event(ws_id, ws_name, line).model_dump())
        except Exception:
            pass  # client disconnected or connection error

    return app
