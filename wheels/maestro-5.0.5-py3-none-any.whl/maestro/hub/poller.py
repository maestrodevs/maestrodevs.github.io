# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""WorkspacePoller — background thread that owns all workspace disk I/O.

Single background thread polls all registered workspaces on a fixed interval,
maintaining a thread-safe in-memory snapshot. Request handlers read the cached
snapshot without blocking on I/O.
"""

from __future__ import annotations

import threading
from pathlib import Path
from typing import Dict, List, Optional

from maestro.hub.models import WorkspaceDetail, WorkspaceSummary


class WorkspacePoller:
    """Poll all registered workspaces and maintain a thread-safe snapshot cache."""

    def __init__(self, interval: float = 5.0) -> None:
        self.interval = interval
        self._cache: Dict[str, WorkspaceSummary] = {}
        self._detail_cache: Dict[str, WorkspaceDetail] = {}
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        """Spawn the background poll thread (daemon so it dies with the process).

        Does the first poll synchronously before spawning the thread so the
        snapshot is populated immediately (important for TestClient and fast
        request paths after startup).
        """
        self._stop.clear()
        self._poll_once()  # synchronous initial fill
        self._thread = threading.Thread(target=self._loop, daemon=True, name="hub-poller")
        self._thread.start()

    def stop(self) -> None:
        """Signal the poll thread to stop and wait for it to exit."""
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=self.interval + 2)
            self._thread = None

    def snapshot(self) -> Dict[str, WorkspaceSummary]:
        """Return a thread-safe shallow copy of the current workspace cache."""
        with self._lock:
            return dict(self._cache)

    def summaries(self) -> List[WorkspaceSummary]:
        """Return a list of WorkspaceSummary objects from the current snapshot."""
        with self._lock:
            return list(self._cache.values())

    def detail(self, workspace_id: str) -> Optional[WorkspaceDetail]:
        """Return the cached WorkspaceDetail for one workspace, or None if unknown."""
        with self._lock:
            return self._detail_cache.get(workspace_id)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _loop(self) -> None:
        # The initial poll was already done synchronously in start(); just run
        # the wait-then-poll cycle from here.
        while not self._stop.wait(self.interval):
            self._poll_once()

    def _poll_once(self) -> None:
        from maestro import registry
        from maestro.hub import aggregator

        projects = registry.list_projects()
        new_summaries: Dict[str, WorkspaceSummary] = {}
        new_details: Dict[str, WorkspaceDetail] = {}
        for acronym, entry in projects.items():
            try:
                ws_root = Path(entry["path"])
                new_summaries[acronym] = aggregator.read_workspace_snapshot(ws_root, id=acronym)
                new_details[acronym] = aggregator.build_workspace_detail(ws_root, acronym)
            except Exception:
                path = entry.get("path", "")
                new_summaries[acronym] = aggregator.offline_summary(acronym, path)
                new_details[acronym] = aggregator.offline_detail(acronym, path)

        with self._lock:
            self._cache = new_summaries
            self._detail_cache = new_details
