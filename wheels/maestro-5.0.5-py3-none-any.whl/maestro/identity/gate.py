from __future__ import annotations

import json
import sys
from pathlib import Path

from .types import Capability, Scope


class CapabilityDenied(RuntimeError):
    """Raised when the resolved caller lacks a required capability."""

    def __init__(self, actor: str, capability: str, scope: str, reason: str) -> None:
        self.actor = actor
        self.capability = capability
        self.scope = scope
        self.reason = reason
        super().__init__(f"permission denied: {actor} lacks {capability} (scope: {scope})")


def _load_enterprise_flag(workspace: Path) -> bool:
    """Read workspace.json and return whether enterprise mode is enabled."""
    from maestro.workspace import resolve_artefact_dir
    ws_cfg = resolve_artefact_dir(workspace) / "config" / "workspace.json"
    if not ws_cfg.exists():
        return False
    try:
        data = json.loads(ws_cfg.read_text(encoding="utf-8"))
        flag = data.get("enterprise", False)
        # Support both bool and nested dict (future-proofing)
        if isinstance(flag, bool):
            return flag
        if isinstance(flag, dict):
            return True  # presence of the object implies enterprise
        return bool(flag)
    except Exception:
        return False


def require_capability(
    capability: Capability,
    scope: Scope = "*",
    *,
    workspace: Path | None = None,
) -> None:
    """
    Resolve the caller, check the ACL, and raise CapabilityDenied if check fails.
    No-op when enterprise mode is disabled.

    Args:
        capability: The capability required for the operation.
        scope: The scope for the check (e.g. '*', 'project:PSG').
        workspace: Workspace root. Detected from cwd if not provided.
    """
    if workspace is None:
        # Walk up from cwd looking for any workspace artefact dir
        from pathlib import Path as _Path
        cwd = _Path.cwd()
        for p in [cwd, *cwd.parents]:
            if any((p / name / "config").is_dir() for name in (".mso",)):
                workspace = p
                break
        else:
            workspace = cwd

    if not _load_enterprise_flag(workspace):
        return  # non-enterprise: pass-through

    from maestro.workspace import resolve_artefact_dir
    identity_dir = resolve_artefact_dir(workspace) / "identity"
    acl_path = identity_dir / "access.json"
    groups_dir = identity_dir / "groups"

    from .auth import resolve_caller
    actor = resolve_caller(workspace, enterprise=True)

    if actor == "anonymous":
        _deny(actor, capability, scope, "anonymous callers are not permitted in enterprise mode")

    from .acl import resolve_capability as _resolve
    allowed = _resolve(
        actor=actor,
        capability=capability,
        scope=scope,
        acl_path=acl_path,
        groups_dir=groups_dir,
    )

    if not allowed:
        _deny(
            actor,
            capability,
            scope,
            "caller is not in a group with this capability",
        )

    # Check restriction flag (Article 18 — right to restriction)
    email = actor.removeprefix("user:")
    from .rights import is_restricted
    if is_restricted(email, workspace):
        _deny(actor, capability, scope, "identity is restricted (GDPR Article 18)")


def _deny(actor: str, capability: str, scope: str, reason: str) -> None:
    print(
        f"\nError: permission denied\n"
        f"  Caller  : {actor}\n"
        f"  Requires: {capability} (scope: {scope})\n"
        f"  Reason  : {reason}\n"
        f"  Fix     : ask a Captain to grant {capability} in .mso/identity/access.json\n",
        file=sys.stderr,
    )
    raise SystemExit(1)
