from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path


def _load_identity_config(workspace: Path) -> dict:
    """Return the ``identity`` block of workspace.json (empty on any error)."""
    try:
        from maestro.workspace import resolve_artefact_dir
        cfg = resolve_artefact_dir(workspace) / "config" / "workspace.json"
        if not cfg.exists():
            return {}
        data = json.loads(cfg.read_text(encoding="utf-8"))
        block = data.get("identity", {})
        return block if isinstance(block, dict) else {}
    except Exception:
        return {}


def _enterprise_enabled(workspace: Path) -> bool:
    try:
        from maestro.workspace import resolve_artefact_dir
        cfg = resolve_artefact_dir(workspace) / "config" / "workspace.json"
        if not cfg.exists():
            return False
        data = json.loads(cfg.read_text(encoding="utf-8"))
        flag = data.get("enterprise", False)
        return bool(flag) if not isinstance(flag, dict) else True
    except Exception:
        return False


def _gh_verified_email() -> str | None:
    """Return the GitHub-token-backed email, or None.

    This is the one identity source that requires possession of a real
    credential (a valid ``gh`` token), so it is the trust root when
    ``identity.requireVerifiedIdentity`` is enabled.
    """
    try:
        result = subprocess.run(
            ["gh", "api", "user", "--jq", ".email"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            email = result.stdout.strip()
            if email and "@" in email and email != "null":
                return email
    except Exception:
        pass
    return None


def resolve_caller(workspace: Path, *, enterprise: bool | None = None) -> str:
    """
    Resolve the caller's identity as 'user:<email>' or 'anonymous'.

    Resolution order (highest priority first):
    1. ADM_USER env var        (see verification note below)
    2. OIDC: ADM_OIDC_TOKEN    (trusted ONLY when its signature verifies)
    3. GitHub CLI: gh api user --jq .email   (credential-backed / verified)
    4. Git config: git config user.email     (weak; skipped when verification required)
    5. OS username (low-trust; warns)         (skipped when verification required)
    6. anonymous

    Security (audit findings H1/H2):
      - ``ADM_USER`` and an OIDC token are *unauthenticated inputs*. When
        enterprise mode is on and ``identity.requireVerifiedIdentity`` is true,
        ``ADM_USER`` is accepted only if it matches the GitHub-verified email,
        and an unverified OIDC token is rejected — closing the spoofing path
        into the capability gate. The default (flag off) preserves the legacy
        operator-hint behaviour but warns when a trusted identity is derived
        from an unauthenticated source in enterprise mode.
      - The OIDC token is now *verify-or-reject*: it yields a trusted identity
        only when ``identity.oidc.publicKey``/``hmacSecret`` is configured and
        the JWT signature validates. An unverified token is never trusted.
    """
    if enterprise is None:
        enterprise = _enterprise_enabled(workspace)
    id_cfg = _load_identity_config(workspace)
    require_verified = enterprise and bool(id_cfg.get("requireVerifiedIdentity", False))

    # 1. ADM_USER (unauthenticated operator hint)
    adm_user = os.environ.get("ADM_USER", "").strip()
    if adm_user:
        if require_verified:
            verified = _gh_verified_email()
            if verified and verified == adm_user:
                return f"user:{adm_user}"
            print(
                f"[Maestro] SECURITY: ignoring unverified ADM_USER='{adm_user}' "
                "(identity.requireVerifiedIdentity is on and it does not match the "
                "GitHub-verified identity). Falling back to a verified source.",
                file=sys.stderr,
            )
            # fall through — do NOT trust the unverified claim
        else:
            if enterprise:
                print(
                    f"[Maestro] WARNING: trusting unverified ADM_USER='{adm_user}' in "
                    "enterprise mode. Enable identity.requireVerifiedIdentity to require "
                    "a credential-backed identity.",
                    file=sys.stderr,
                )
            return f"user:{adm_user}"

    # 2. OIDC token — verify-or-reject (H2)
    oidc_token = os.environ.get("ADM_OIDC_TOKEN", "").strip()
    if oidc_token:
        email = _verify_oidc_email(oidc_token, id_cfg)
        if email:
            return f"user:{email}"
        # Unverified/forged token: NOT trusted (previously it was — the bug).
        print(
            "[Maestro] SECURITY: ignoring ADM_OIDC_TOKEN — its signature could not "
            "be verified (configure identity.oidc.publicKey or identity.oidc.hmacSecret).",
            file=sys.stderr,
        )

    # 3. GitHub CLI (credential-backed / verified)
    verified = _gh_verified_email()
    if verified:
        return f"user:{verified}"

    if require_verified:
        # No credential-backed identity available and verification is required.
        return "anonymous"

    # 4. Git config (weak — anyone can set it)
    try:
        result = subprocess.run(
            ["git", "config", "user.email"],
            capture_output=True,
            text=True,
            cwd=str(workspace),
            timeout=5,
        )
        if result.returncode == 0:
            email = result.stdout.strip()
            if email and "@" in email:
                return f"user:{email}"
    except Exception:
        pass

    # 5. OS username (low-trust)
    import getpass
    try:
        username = getpass.getuser()
        if username:
            print(
                f"[Maestro] WARNING: identity unverified — using OS username '{username}'. "
                "Set ADM_USER=<email> for verified identity.",
                file=sys.stderr,
            )
            return f"user:{username}"
    except Exception:
        pass

    # 6. Anonymous
    return "anonymous"


def _decode_jwt_payload(token: str) -> dict | None:
    """Return the decoded JWT payload dict, or None. Does NOT verify signature."""
    try:
        import base64
        parts = token.split(".")
        if len(parts) != 3:
            return None
        payload_b64 = parts[1]
        payload_b64 += "=" * ((-len(payload_b64)) % 4)
        return json.loads(base64.urlsafe_b64decode(payload_b64).decode("utf-8"))
    except Exception:
        return None


def _verify_oidc_email(token: str, id_cfg: dict) -> str | None:
    """Return the email claim ONLY when the JWT signature verifies.

    Supports two operator-configured verification modes under
    ``identity.oidc`` in workspace.json:
      - ``hmacSecret``: HS256 shared secret (symmetric).
      - ``publicKey``:  RS256/ES256 PEM public key (asymmetric), if PyJWT is
        installed.
    When neither is configured, verification is impossible and the token is
    rejected (returns None) — an unverified JWT is never trusted (H2).
    """
    oidc = id_cfg.get("oidc", {}) if isinstance(id_cfg.get("oidc", {}), dict) else {}
    hmac_secret = oidc.get("hmacSecret")
    public_key = oidc.get("publicKey")
    if not hmac_secret and not public_key:
        return None

    parts = token.split(".")
    if len(parts) != 3:
        return None

    verified = False
    try:
        if hmac_secret:
            import base64
            import hashlib
            import hmac as _hmac
            signing_input = f"{parts[0]}.{parts[1]}".encode("ascii")
            sig = parts[2] + "=" * ((-len(parts[2])) % 4)
            provided = base64.urlsafe_b64decode(sig)
            expected = _hmac.new(
                hmac_secret.encode("utf-8"), signing_input, hashlib.sha256
            ).digest()
            verified = _hmac.compare_digest(provided, expected)
        elif public_key:
            try:
                import jwt as _pyjwt  # PyJWT, optional dependency
                _pyjwt.decode(
                    token,
                    public_key,
                    algorithms=["RS256", "ES256"],
                    options={"verify_aud": False},
                )
                verified = True
            except Exception:
                verified = False
    except Exception:
        verified = False

    if not verified:
        return None

    payload = _decode_jwt_payload(token)
    if not payload:
        return None
    # Reject expired tokens when exp is present.
    try:
        import time
        exp = payload.get("exp")
        if exp is not None and float(exp) < time.time():
            return None
    except Exception:
        pass
    email = payload.get("email") or payload.get("sub")
    if email and "@" in str(email):
        return str(email)
    return None
