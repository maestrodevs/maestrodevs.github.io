#!/usr/bin/env python3
"""
Maestro - Crew Execution Engine v2.0.0 (Python)

Role-aware autonomous execution engine for crew members with self-organizing capabilities.
Spawns a Claude Code CLI instance per order with role-based model selection and
hook-based iteration control (Ralph Wiggum pattern).

v2.0.5 Feature:
  - MULTI-PROJECT SUPPORT: Project acronym injected via MAESTRO_PROJECT env var.
    Crews resolve project-specific config at runtime from config/projects/{acronym}.json.

v2.0.1 Feature:
  - MANAGED REPO CWD: When MAESTRO_REPO_PATH is set by fleet-runner, crew.py uses
    the pre-cloned repo as the Claude CLI working directory. Falls back to workspace
    root if the path doesn't exist (crew self-manages).

v8.3 Feature:
  - ROLE-BASED MODEL SELECTION: Each role gets the optimal Claude model.
    COX → Opus 4.7 (critical review), NAV/SHP/BOS/SCR → Sonnet 4.6, LKT → Haiku 4.5
    Configured via ROLE_MODELS dict. Logged at invocation time.

v8.2 Fix:
  - TIMEOUT-COMPLETE RACE: When subprocess times out due to lingering background
    bash processes, check ralph-state before declaring TIMEOUT. If stop hook already
    detected <promise>COMPLETE</promise>, honour COMPLETE status instead of re-queuing.

v8.0 Features:
  - PYTHON FOR-LOOP ITERATION CONTROL: run_crew() calls Claude once per iteration.
    MAESTRO_ITER_MANAGED=1 is injected so the stop hook exits cleanly instead of
    trying to re-feed via {decision: block} (which silently fails on Windows in a
    DETACHED_PROCESS/CREATE_NO_WINDOW context — BUG-MSO-2026-0029).
  - Per-crew ralph-state.md updated at each boundary for fleet_monitor visibility
  - CREW_ITER_BOUNDARY lifecycle events emitted for every iteration start/end
  - Environment variables (MAESTRO_CREW, MAESTRO_ORDER, etc.) isolate crew sessions
  - Captain's interactive sessions are NEVER affected (stop hook checks MAESTRO_CREW)

v7.3 Features:
  - TIMEOUT BRIEFING: On timeout, captures iteration count, artifacts, partial output
  - Brief stored in crew state, appended to order JSON on re-queue
  - Next crew sees "Previous Attempts" section in prompt

v6.0 Features:
  - NO CLI LOCK: Crews run as fully detached independent processes (no mutex needed)
  - Launched by fleet-runner with DETACHED_PROCESS + CREATE_NEW_PROCESS_GROUP
  - Restores 5-crew concurrent capability

v5.0-5.1 Features:
  - Self-organizing crews: Can create bugs, requests, and breakdowns
  - Role permissions: Each role has specific creation/request permissions
  - Queue integration: Work items placed in .mso/queues/
  - PLANNING REQUESTS: LKT can request NAV to plan based on investigation findings

Usage:
    python crew.py --crew 1 --role LKT --order INV-2026-0001 --prompt path/to/prompt.md

    # Status & cleanup
    python crew.py --crew 1 --status
    python crew.py --crew 1 --cleanup
"""

import argparse
import io
import json
import os
import re
import subprocess
import sys
import threading
import time
import uuid
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, Any

# Fix Windows console encoding and buffering
if sys.platform == 'win32':
    # Set UTF-8 mode for stdout/stderr with line buffering for immediate output
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace', line_buffering=True)
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace', line_buffering=True)


def log(msg: str):
    """Print with immediate flush for visibility in subprocess."""
    print(msg, flush=True)

# ============================================================================
# CONFIGURATION
# ============================================================================

# v2.0.5: Multi-project support — project acronym from fleet-runner env injection
PROJECT_ACRONYM = os.environ.get("MAESTRO_PROJECT", "OTM")

# Squad names and role-model IDs are persona-driven — see maestro/core_constants.py
from maestro.workspace import get_workspace_dir  # noqa: E402
from maestro.core_constants import (  # noqa: E402
    get_squad_name,
    get_role_model_id,
    get_role_context_window,
    get_role_effort,
    DEFAULT_ROLE_MODEL_IDS as _CANONICAL_ROLE_MODELS,
    VALID_CONTEXT_WINDOWS,
    VALID_EFFORTS_CREW,
    VALID_EFFORTS_ALL,
    OPUS_ONLY_EFFORTS,
    MILLION_CONTEXT_MODEL_IDS,
    OPUS_MODEL_IDS,
)

ROLE_MODELS: dict[str, str] = dict(_CANONICAL_ROLE_MODELS)

# FTR-MSO-2026-0194 (Part C): Per-role tool scoping.
# Under --dangerously-skip-permissions, bare-name --disallowedTools removes
# a tool entirely (scoped rules like "Bash(rm:*)" are ignored).
# Empty list = unrestricted (BLD, TST, DOC, LEAD get all tools).
ROLE_DISALLOWED_TOOLS: dict[str, list[str]] = {
    "PLN":  ["NotebookEdit"],
    "BLD":  [],
    "TST":  [],
    "DOC":  [],
    "SEC":  ["Write", "Edit", "NotebookEdit"],
    "REL":  ["NotebookEdit"],
    "LEAD": [],
}

ROLE_INFO = {
    "PLN": {"name": "Planner", "focus": "Planning & Architecture"},
    "BLD": {"name": "Builder", "focus": "Development & Implementation"},
    "TST": {"name": "Tester", "focus": "Quality Assurance & Testing"},
    "DOC": {"name": "Docs Writer", "focus": "Documentation"},
    "SEC": {"name": "Security Reviewer", "focus": "Security & Investigation"},
    "REL": {"name": "Releaser", "focus": "Integration & Deployment"},
    "LEAD": {"name": "Lead", "focus": "Interactive Partner"},
}

def _role_info(role: str) -> dict:
    """Lookup role info by canonical role code."""
    return ROLE_INFO.get(role, {})

def _role_permissions(role: str) -> dict:
    """Lookup role permissions by canonical role code."""
    return ROLE_PERMISSIONS.get(role, {})

# v7.0: Role Permissions Matrix - Self-Organizing Crews
# NOTE: All roles can escalate (Captain's directive) — no permission check needed for escalations
# v8.4: repo_write controls which repos each role may create/modify files in.
#   "target"  = the service/API repo specified by the order's targetRepo
#   "docs"    = documentation repo
#   "maestro" = .mso/ directory (reports, handoffs, queues) — always allowed
ROLE_PERMISSIONS = {
    "PLN": {
        "can_create": ["orders", "bugs"],
        "can_request": ["investigation", "qa"],
        "can_breakdown": True,
        "repo_write": ["target", "docs"]
    },
    "BLD": {
        "can_create": ["bugs"],
        "can_request": ["investigation", "qa"],
        "can_breakdown": False,
        "repo_write": ["target"]
    },
    "TST": {
        "can_create": ["bugs", "defects"],
        "can_request": ["investigation"],
        "can_breakdown": False,
        "repo_write": ["target"]
    },
    "DOC": {
        "can_create": ["bugs"],
        "can_request": ["investigation", "qa"],
        "can_breakdown": False,
        "repo_write": ["docs"]
    },
    "SEC": {
        "can_create": ["bugs", "orders", "security"],
        "can_request": ["planning"],
        "can_breakdown": True,
        "repo_write": ["docs"]
    },
    "REL": {
        "can_create": ["bugs", "orders"],
        "can_request": ["investigation"],
        "can_breakdown": True,
        "repo_write": ["target", "docs"]
    }
}

# v8.3 / FTR-MSO-2026-0168: Role-model IDs moved to maestro/core_constants.py
# (DEFAULT_ROLE_MODEL_IDS). resolve_model_for() uses get_role_model_id() as
# the built-in default layer so canonical + legacy codes are both handled.
DEFAULT_MODEL = "claude-sonnet-4-6"

# v2.5.6 (FTR-ADM-2026-0129): set of model IDs Admiralty has cost-tracking
# pricing for. Used to validate operator overrides — unknown IDs raise so a
# typo doesn't silently dispatch against a model the usage tracker can't price.
SUPPORTED_MODELS = {
    "claude-fable-5",
    "claude-opus-4-8",
    "claude-opus-4-7",
    "claude-opus-4-6",
    "claude-sonnet-5",
    "claude-sonnet-4-6",
    "claude-haiku-4-5-20251001",
}


def _load_workspace_role_models() -> dict:
    """Read .mso/config/role-models.json if present.

    Schema: {"models": {"SHP": "claude-opus-4-7", ...}}
    Returns {} if missing/unreadable.
    """
    try:
        cfg = get_workspace_dir() / "config" / "role-models.json"
        if not cfg.exists():
            return {}
        data = json.loads(cfg.read_text(encoding="utf-8"))
        return data.get("models", {}) if isinstance(data, dict) else {}
    except Exception:
        return {}


def _validate_model_id(model_id: str, source: str) -> str:
    """Reject unknown model IDs with a clear error pointing at the supported list.

    FTR-MSO-2026-0281: strips the '[1m]' context-window suffix before checking
    SUPPORTED_MODELS, so 'claude-opus-4-5[1m]' validates the same as
    'claude-opus-4-5'. Returns the bare model ID (without any '[1m]' suffix).
    """
    bare_id = model_id.removesuffix("[1m]")
    if bare_id not in SUPPORTED_MODELS:
        supported = ", ".join(sorted(SUPPORTED_MODELS))
        raise ValueError(
            f"Unknown model '{bare_id}' (from {source}). "
            f"Admiralty does not have cost-tracking pricing for this ID and refuses "
            f"to dispatch against it. Supported: {supported}. "
            f"To add a new model, update SUPPORTED_MODELS + PRICING in maestro/core/."
        )
    return bare_id


def _validate_effort(effort: str, source: str, model: str = "", for_crew: bool = True) -> str:
    """Validate an effort value against the known effort tiers.

    FTR-MSO-2026-0281: raises ValueError for unknown values; demotes xhigh to
    high when the resolved model is not an Opus-class model; rejects max/ultracode
    for crew dispatch (reserved for interactive LEAD sessions).
    """
    if effort not in VALID_EFFORTS_ALL:
        valid = ", ".join(sorted(VALID_EFFORTS_ALL))
        raise ValueError(
            f"Unknown effort '{effort}' (from {source}). Valid values: {valid}."
        )
    if for_crew and effort in ("max", "ultracode"):
        raise ValueError(
            f"Effort '{effort}' (from {source}) is reserved for interactive LEAD sessions. "
            f"Crew dispatch allows: {', '.join(sorted(VALID_EFFORTS_CREW))}."
        )
    if effort in OPUS_ONLY_EFFORTS and model:
        bare_model = model.removesuffix("[1m]")
        if bare_model not in OPUS_MODEL_IDS:
            log(
                f"  [WARN] Effort '{effort}' requires an Opus-class model "
                f"(got '{bare_model}' from {source}); downgrading effort to 'high'."
            )
            return "high"
    return effort


def _validate_context_window(cw: str, source: str, model: str = "") -> str:
    """Validate a context-window value against the known tiers.

    FTR-MSO-2026-0281: raises ValueError for unknown values; downgrades '1m' to
    'standard' when the resolved model does not support a 1M-token context window.
    """
    if cw not in VALID_CONTEXT_WINDOWS:
        valid = ", ".join(sorted(VALID_CONTEXT_WINDOWS))
        raise ValueError(
            f"Unknown context window '{cw}' (from {source}). Valid values: {valid}."
        )
    if cw == "1m" and model:
        bare_model = model.removesuffix("[1m]")
        if bare_model not in MILLION_CONTEXT_MODEL_IDS:
            log(
                f"  [WARN] Context window '1m' requested (from {source}) but model "
                f"'{bare_model}' does not support 1M context; downgrading to 'standard'."
            )
            return "standard"
    return cw


def _load_order_data_for(order_id: str) -> dict:
    """Look up an order's JSON across all known queue + active locations.

    FTR-0129: needed so resolve_model_for() can apply per-order `model`
    overrides from anywhere a dispatcher hands the crew an order_id.
    Returns {} when not found or unreadable.

    Copilot review: covers every queue scanned by fleet_runner.scan_all_queues
    plus orders/active|complete|failed. A malformed JSON in one location
    doesn't end the search — the next candidate still gets a chance.
    """
    if not order_id:
        return {}
    try:
        adm = get_workspace_dir()
    except Exception:
        return {}
    queues = (
        "orders", "explicit", "bugs", "security",
        "defects", "requests", "breakdown", "high-level",
        "escalations", "proposed",
    )
    candidates = [adm / "queues" / q / f"{order_id}.json" for q in queues]
    candidates.extend([
        adm / "orders" / "active" / f"{order_id}.json",
        adm / "orders" / "complete" / f"{order_id}.json",
        adm / "orders" / "failed" / f"{order_id}.json",
    ])
    for path in candidates:
        if path.exists():
            try:
                return json.loads(path.read_text(encoding="utf-8"))
            except Exception:
                # Malformed copy in one location — keep scanning. Same order
                # may exist verifiably in another queue.
                continue
    return {}


def resolve_model_for(role: str, order_data: dict | None = None) -> str:
    """Resolve the Claude model for a (role, order) pair.

    FTR-ADM-2026-0129 (+ FTR-0186 overlay layer): override chain, highest priority first:
      1. Per-order override        — order JSON `model` field
      2. Workspace config          — .mso/config/role-models.json
      3. Env var                   — MAESTRO_MODEL_<ROLE> (uppercase)
      4. Role overlay model        — .mso/config/roles/<CODE>.md frontmatter `model`
      5. Built-in ROLE_MODELS dict — falls back to DEFAULT_MODEL

    Unknown model IDs at any layer raise ValueError. Operators see the
    misconfiguration immediately rather than dispatching against a model
    the usage tracker can't price.
    """
    # 1. Per-order override
    if order_data:
        order_model = order_data.get("model", "")
        if order_model:
            return _validate_model_id(order_model, f"order.model for {role}")

    # 2. Workspace config
    workspace_models = _load_workspace_role_models()
    if role in workspace_models and workspace_models[role]:
        ws_val = workspace_models[role]
        ws_model = ws_val.get("model") if isinstance(ws_val, dict) else ws_val
        if ws_model:
            return _validate_model_id(
                ws_model,
                f".mso/config/role-models.json[{role}]",
            )

    # 3. Env var (case-insensitive role lookup, uppercase env name)
    env_var = f"MAESTRO_MODEL_{role.upper()}"
    env_model = os.environ.get(env_var, "")
    if env_model:
        return _validate_model_id(env_model, f"${env_var}")

    # 4. Role overlay model (FTR-0186) — lets orgs override Sonnet→Opus via overlay
    try:
        from maestro.roles.loader import load_effective_role
        ws = get_workspace_dir()
        role_def = load_effective_role(role.upper(), ws)
        if role_def.model:
            return _validate_model_id(role_def.model, f"role overlay model for {role}")
    except Exception:
        pass

    # 5. Built-in default
    return get_role_model_id(role)


def resolve_context_window_for(role: str, order_data: dict | None = None) -> str:
    """Resolve the context-window tier for a (role, order) pair.

    FTR-MSO-2026-0281: same 5-layer override chain as resolve_model_for.
    NOTE: recommendedContextWindow on the order is NOT read here — it is an
    advisory hint for the planner, not a dispatch directive.

    Override chain (highest priority first):
      1. Per-order override        — order JSON `contextWindow` field
      2. Workspace config          — .mso/config/role-models.json (object form)
      3. Env var                   — MAESTRO_CONTEXT_<ROLE> (uppercase)
      4. Role overlay              — .mso/config/roles/<CODE>.md frontmatter `context_window`
      5. Built-in default          — get_role_context_window(role)
    """
    # Best-effort model resolution for the xhigh/1m guard — ignore errors.
    try:
        _model_hint = resolve_model_for(role, order_data)
    except Exception:
        _model_hint = ""

    # 1. Per-order override
    if order_data:
        cw = order_data.get("contextWindow", "")
        if cw:
            return _validate_context_window(cw, f"order.contextWindow for {role}", _model_hint)

    # 2. Workspace config (object form)
    workspace_models = _load_workspace_role_models()
    if role in workspace_models and workspace_models[role]:
        ws_val = workspace_models[role]
        if isinstance(ws_val, dict):
            cw = ws_val.get("contextWindow", "")
            if cw:
                return _validate_context_window(
                    cw,
                    f".mso/config/role-models.json[{role}].contextWindow",
                    ws_val.get("model", ""),
                )

    # 3. Env var
    env_var = f"MAESTRO_CONTEXT_{role.upper()}"
    env_cw = os.environ.get(env_var, "")
    if env_cw:
        return _validate_context_window(env_cw, f"${env_var}", _model_hint)

    # 4. Role overlay
    try:
        from maestro.roles.loader import load_effective_role
        ws = get_workspace_dir()
        role_def = load_effective_role(role.upper(), ws)
        if role_def.context_window:
            return _validate_context_window(
                role_def.context_window,
                f"role overlay context_window for {role}",
                _model_hint,
            )
    except Exception:
        pass

    # 5. Built-in default
    return get_role_context_window(role)


def resolve_effort_for(role: str, order_data: dict | None = None) -> str:
    """Resolve the effort tier for a (role, order) pair.

    FTR-MSO-2026-0281: same 5-layer override chain as resolve_model_for.
    NOTE: recommendedEffort on the order is NOT read here — it is an advisory
    hint for the planner, not a dispatch directive.
    Crew dispatch rejects max/ultracode (reserved for interactive LEAD sessions).

    Override chain (highest priority first):
      1. Per-order override        — order JSON `effort` field
      2. Workspace config          — .mso/config/role-models.json (object form)
      3. Env var                   — MAESTRO_EFFORT_<ROLE> (uppercase)
      4. Role overlay              — .mso/config/roles/<CODE>.md frontmatter `effort`
      5. Built-in default          — get_role_effort(role)
    """
    # Best-effort model resolution for the xhigh guard — ignore errors.
    resolved_model = ""
    try:
        resolved_model = resolve_model_for(role, order_data)
    except Exception:
        pass

    # 1. Per-order override
    if order_data:
        effort = order_data.get("effort", "")
        if effort:
            return _validate_effort(effort, f"order.effort for {role}", resolved_model, for_crew=True)

    # 2. Workspace config (object form)
    workspace_models = _load_workspace_role_models()
    if role in workspace_models and workspace_models[role]:
        ws_val = workspace_models[role]
        if isinstance(ws_val, dict):
            effort = ws_val.get("effort", "")
            if effort:
                return _validate_effort(
                    effort,
                    f".mso/config/role-models.json[{role}].effort",
                    ws_val.get("model", ""),
                    for_crew=True,
                )

    # 3. Env var
    env_var = f"MAESTRO_EFFORT_{role.upper()}"
    env_effort = os.environ.get(env_var, "")
    if env_effort:
        return _validate_effort(env_effort, f"${env_var}", resolved_model, for_crew=True)

    # 4. Role overlay
    try:
        from maestro.roles.loader import load_effective_role
        ws = get_workspace_dir()
        role_def = load_effective_role(role.upper(), ws)
        if role_def.effort:
            return _validate_effort(
                role_def.effort,
                f"role overlay effort for {role}",
                resolved_model,
                for_crew=True,
            )
    except Exception:
        pass

    # 5. Built-in default
    return get_role_effort(role)


# v7.0: Queue depth limits to prevent runaway queue growth
MAX_QUEUE_DEPTH = {
    "bugs": 50,
    "defects": 20,
    "security": 10,
    "breakdown": 30,
    "escalations": 20
}

# v7.0: Per-crew creation rate limit — max items a single crew can create per order execution
MAX_CREW_ITEMS_PER_ORDER = 10

# ============================================================================
# PATH HELPERS
# ============================================================================

# ============================================================================
# SESSION ID (FTR-MSO-2026-0195)
# ============================================================================

# UUIDv5 namespace for Maestro session IDs.
_SESSION_NS = uuid.UUID("6ba7b810-9dad-11d1-80b4-00c04fd430c8")


def make_session_id(crew_number: int, order_id: str, iteration: int,
                    run_nonce: str = "") -> str:
    """Return a UUIDv5 for a (crew, order, iteration[, run_nonce]) tuple.

    BUG-MSO-2026-0220: a purely deterministic (crew, order, iteration) id
    collides with the Claude CLI's persisted session on RE-dispatch — the Ralph
    model restarts a re-queued order at iteration 1, so the retry reused the same
    id and Claude rejected it ('Session ID ... is already in use'), making any
    killed/timed-out order unrecoverable. `run_nonce` is a per-crew-run salt
    (generated once per crew.py launch) so each dispatch attempt gets a fresh,
    non-colliding session id while remaining stable across the iterations of a
    single run. Stored as maestroSessionId in state.json + lifecycle for tracing.
    """
    seed = f"maestro:crew{crew_number}:{order_id}:iter{iteration}"
    if run_nonce:
        seed += f":run{run_nonce}"
    return str(uuid.uuid5(_SESSION_NS, seed))


def get_base_dir() -> Path:
    """Get the project base directory."""
    return get_workspace_dir().parent

def get_crew_dir(crew_number: int) -> Path:
    """Get the crew's working directory."""
    suffix = "" if crew_number == 1 else str(crew_number)
    return get_workspace_dir() / f"crews/crew{crew_number}"

def ensure_crew_dir(crew_number: int) -> Path:
    """Ensure crew directory exists and return it."""
    crew_dir = get_crew_dir(crew_number)
    crew_dir.mkdir(parents=True, exist_ok=True)
    return crew_dir

# ============================================================================
# STATE MANAGEMENT
# ============================================================================

def read_state(crew_number: int) -> Optional[Dict[str, Any]]:
    """Read crew state from state.json."""
    state_file = get_crew_dir(crew_number) / "state.json"
    if state_file.exists():
        try:
            return json.loads(state_file.read_text(encoding='utf-8'))
        except:
            return None
    return None

def write_state(crew_number: int, state: Dict[str, Any]):
    """Write crew state to state.json."""
    crew_dir = ensure_crew_dir(crew_number)
    state_file = crew_dir / "state.json"
    state_file.write_text(json.dumps(state, indent=2), encoding='utf-8')

def update_heartbeat(crew_number: int, phase: str = "", role: str = ""):
    """Update heartbeat file with current timestamp."""
    crew_dir = ensure_crew_dir(crew_number)
    heartbeat_file = crew_dir / "heartbeat.txt"
    heartbeat_file.write_text(datetime.now().isoformat(), encoding='utf-8')


# ============================================================================
# RALPH STATE (v8.0 Stop Hook Integration)
# ============================================================================

def create_ralph_state(crew_number: int, order_id: str, role: str,
                       max_iterations: int = 25,
                       completion_promise: str = "COMPLETE"):
    """Create the per-crew ralph-state.md file before the iteration loop.

    The Python for-loop advances this file at each iteration boundary via
    advance_ralph_state(). The stop hook is disabled (MAESTRO_ITER_MANAGED=1)
    so it no longer updates this file. YAML frontmatter + iteration log body.
    """
    crew_dir = ensure_crew_dir(crew_number)
    state_file = crew_dir / "ralph-state.md"
    now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    content = (
        f"---\n"
        f"crew: {crew_number}\n"
        f'order: "{order_id}"\n'
        f'role: "{role}"\n'
        f"iteration: 1\n"
        f"max_iterations: {max_iterations}\n"
        f'completion_promise: "{completion_promise}"\n'
        f'status: "RUNNING"\n'
        f'created: "{now}"\n'
        f'last_iteration: "{now}"\n'
        f"---\n"
        f"\n"
        f"# Iteration Log\n"
        f"\n"
        f"## Initialization ({now})\n"
        f"Ralph state created. Python for-loop manages iterations (MAESTRO_ITER_MANAGED).\n"
    )

    # Atomic write
    tmp_path = state_file.with_suffix('.tmp')
    try:
        tmp_path.write_text(content, encoding='utf-8')
        tmp_path.replace(state_file)
    except Exception:
        state_file.write_text(content, encoding='utf-8')

    log(f"  Ralph state created: {state_file.relative_to(get_base_dir())}")


def advance_ralph_state(crew_number: int, iteration: int, status: str = "RUNNING"):
    """Update ralph-state.md iteration counter from the Python for-loop.

    Called at each iteration boundary so fleet_monitor and operators can see
    real-time progress without relying on the stop hook (which is disabled via
    MAESTRO_ITER_MANAGED when the for-loop owns iteration control).
    """
    crew_dir = get_crew_dir(crew_number)
    state_file = crew_dir / "ralph-state.md"
    if not state_file.exists():
        return
    now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    try:
        content = state_file.read_text(encoding='utf-8')
        # Replace iteration: N and status/last_iteration in frontmatter
        content = re.sub(r'^iteration: \d+', f'iteration: {iteration}', content, flags=re.MULTILINE)
        content = re.sub(r'^status: ".*?"', f'status: "{status}"', content, flags=re.MULTILINE)
        content = re.sub(r'^last_iteration: ".*?"', f'last_iteration: "{now}"', content, flags=re.MULTILINE)
        content += f"\n## Iteration {iteration} ({now})\nPython for-loop advanced to iteration {iteration}. Status: {status}.\n"
        tmp_path = state_file.with_suffix('.tmp')
        tmp_path.write_text(content, encoding='utf-8')
        tmp_path.replace(state_file)
    except Exception:
        pass  # Non-fatal: ralph-state is for observability only


def write_crew_lifecycle_event(event_type: str, message: str):
    """Write a lifecycle event to the fleet lifecycle log from crew.py.

    Mirrors fleet_runner.write_lifecycle_event without importing fleet_runner.
    Used to emit CREW_ITER_BOUNDARY events observable via mso status.
    """
    try:
        log_dir = get_workspace_dir() / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        log_file = log_dir / "lifecycle.log"
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        line = f"{timestamp} | {event_type:<18} | {message}\n"
        with open(str(log_file), 'a', encoding='utf-8') as f:
            f.write(line)
    except Exception:
        pass  # Non-fatal: lifecycle logging is best-effort


def read_ralph_state(crew_number: int) -> dict:
    """Read the final ralph-state.md after Claude exits.

    v8.0: Returns parsed YAML frontmatter as a dict with keys:
    iteration, max_iterations, status, completion_promise, etc.
    """
    crew_dir = get_crew_dir(crew_number)
    state_file = crew_dir / "ralph-state.md"

    if not state_file.exists():
        return {}

    try:
        content = state_file.read_text(encoding='utf-8')
    except Exception:
        return {}

    # Parse YAML frontmatter (between --- delimiters)
    match = re.match(r'^---\s*\n(.*?)\n---\s*\n', content, re.DOTALL)
    if not match:
        return {}

    frontmatter = {}
    for line in match.group(1).strip().split('\n'):
        line = line.strip()
        if ':' in line:
            key, _, value = line.partition(':')
            key = key.strip()
            value = value.strip()
            # Strip surrounding quotes
            if value.startswith('"') and value.endswith('"'):
                value = value[1:-1]
            elif value.startswith("'") and value.endswith("'"):
                value = value[1:-1]
            # Convert numeric values
            if value.isdigit():
                value = int(value)
            elif value == 'true':
                value = True
            elif value == 'false':
                value = False
            elif value == 'null':
                value = None
            frontmatter[key] = value

    return frontmatter


def check_lock(crew_number: int) -> bool:
    """Check if crew is locked (already running).

    v6.0: Also checks if the PID in the lock is actually alive.
    This prevents stale locks from blocking new crew launches.
    """
    lock_file = get_crew_dir(crew_number) / "crew.lock"
    if not lock_file.exists():
        return False

    # Check if the PID in the lock is still alive
    try:
        lock_data = json.loads(lock_file.read_text(encoding='utf-8'))
        lock_pid = lock_data.get("pid", 0)
        if lock_pid and not _is_pid_alive(lock_pid):
            return False  # Process is dead - stale lock
    except:
        pass

    # Fallback: Check if lock is stale (older than 5 minutes with no heartbeat)
    heartbeat_file = get_crew_dir(crew_number) / "heartbeat.txt"
    if heartbeat_file.exists():
        try:
            heartbeat_time = datetime.fromisoformat(heartbeat_file.read_text().strip())
            age = (datetime.now() - heartbeat_time).total_seconds()
            if age > 300:  # 5 minutes
                return False  # Stale lock
        except:
            pass
    return True


def _is_pid_alive(pid: int) -> bool:
    """Check if a process is alive (used by lock check)."""
    if pid <= 0:
        return False
    try:
        if os.name == 'nt':
            import ctypes
            kernel32 = ctypes.windll.kernel32
            handle = kernel32.OpenProcess(0x1000, False, pid)
            if handle == 0:
                return False
            try:
                exit_code = ctypes.c_ulong()
                if kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code)):
                    return exit_code.value == 259
                return False
            finally:
                kernel32.CloseHandle(handle)
        else:
            os.kill(pid, 0)
            return True
    except:
        return False

def set_lock(crew_number: int, order_id: str, role: str):
    """Set crew lock."""
    crew_dir = ensure_crew_dir(crew_number)
    lock_file = crew_dir / "crew.lock"
    lock_data = {
        "pid": os.getpid(),
        "orderId": order_id,
        "role": role,
        "startTime": datetime.now().isoformat()
    }
    lock_file.write_text(json.dumps(lock_data, indent=2), encoding='utf-8')
    update_heartbeat(crew_number)

def clear_lock(crew_number: int):
    """Clear crew lock and related files."""
    crew_dir = get_crew_dir(crew_number)
    for filename in ["crew.lock", "heartbeat.txt", "pid.txt"]:
        lock_file = crew_dir / filename
        if lock_file.exists():
            lock_file.unlink()

# ============================================================================
# PROGRESS TRACKING
# ============================================================================

def init_progress(crew_number: int, order_id: str, role: str):
    """Initialize progress file."""
    crew_dir = ensure_crew_dir(crew_number)
    progress_file = crew_dir / "progress.md"

    role_name = _role_info(role).get("name", role)
    start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    content = f"""# Progress: Order {order_id}

## Role: {role} ({role_name})
## Started: {start_time}

## Tasks
- [ ] Review task and understand requirements
- [ ] Begin execution

## Files Changed
(none yet)

## Notes
"""
    progress_file.write_text(content, encoding='utf-8')

    # v8.1: Clear hook data files for fresh start
    for filename in ["activity.jsonl", "activity.txt", "files_modified.json", "notifications.log"]:
        filepath = crew_dir / filename
        if filepath.exists():
            try:
                filepath.unlink()
            except Exception:
                pass

def read_progress(crew_number: int) -> str:
    """Read current progress."""
    progress_file = get_crew_dir(crew_number) / "progress.md"
    if progress_file.exists():
        return progress_file.read_text(encoding='utf-8')
    return "No progress yet."

# ============================================================================
# v5.0: QUEUE ITEM CREATION (Self-Organizing Crews)
# ============================================================================

def get_queue_dir() -> Path:
    """Get the queue directory."""
    return get_workspace_dir() / "queues"

def generate_queue_id(prefix: str) -> str:
    """Generate a unique queue item ID."""
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    import random
    suffix = random.randint(100, 999)
    return f"{prefix}-{timestamp}-{suffix}"

def can_create_item(role: str, item_type: str) -> bool:
    """Check if a role can create a specific item type."""
    permissions = _role_permissions(role)
    return item_type in permissions.get("can_create", [])

def can_request_service(role: str, service_type: str) -> bool:
    """Check if a role can request a specific service."""
    permissions = _role_permissions(role)
    return service_type in permissions.get("can_request", [])

def can_breakdown_orders(role: str) -> bool:
    """Check if a role can break down high-level orders."""
    permissions = _role_permissions(role)
    return permissions.get("can_breakdown", False)

def check_queue_depth(queue_name: str) -> bool:
    """Check if a queue is under its depth limit (v7.0). Returns True if item can be added."""
    limit = MAX_QUEUE_DEPTH.get(queue_name)
    if limit is None:
        return True  # No limit configured for this queue
    queue_path = get_queue_dir() / queue_name
    if not queue_path.exists():
        return True
    count = len([f for f in queue_path.iterdir() if f.suffix == '.json'])
    if count >= limit:
        log(f"QUEUE DEPTH LIMIT: {queue_name} has {count}/{limit} items - rejecting new item")
        return False
    return True

def check_crew_rate_limit(crew_number: int, order_id: str) -> bool:
    """Check if a crew has exceeded its per-order item creation limit (v7.0).
    Prevents a single crew from flooding queues during one order execution.
    Returns True if crew can create more items, False if rate limited.
    """
    queues_dir = get_queue_dir()
    count = 0
    # Scan all queue directories for items created by this crew on this order
    for queue_name in ["bugs", "defects", "security", "breakdown", "escalations"]:
        queue_path = queues_dir / queue_name
        if not queue_path.exists():
            continue
        for json_file in queue_path.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                created_by = data.get("createdBy", {})
                if created_by.get("crew") == crew_number and created_by.get("order") == order_id:
                    count += 1
            except Exception:
                continue
    # Also scan request subdirectories
    requests_dir = queues_dir / "requests"
    if requests_dir.exists():
        for subdir in ["investigation", "qa", "planning", "documentation"]:
            subpath = requests_dir / subdir
            if not subpath.exists():
                continue
            for json_file in subpath.glob("*.json"):
                try:
                    data = json.loads(json_file.read_text(encoding='utf-8'))
                    created_by = data.get("createdBy", {})
                    if created_by.get("crew") == crew_number and created_by.get("order") == order_id:
                        count += 1
                except Exception:
                    continue

    if count >= MAX_CREW_ITEMS_PER_ORDER:
        log(f"CREW RATE LIMIT: Crew {crew_number} has created {count}/{MAX_CREW_ITEMS_PER_ORDER} items for order {order_id} - rejecting")
        return False
    return True

def create_bug_report(crew_number: int, role: str, order_id: str,
                      title: str, description: str, priority: str = "NORMAL") -> Optional[str]:
    """
    Create a bug report in the queue (v5.0).
    Returns the bug ID if successful, None if not permitted.
    """
    if not can_create_item(role, "bugs"):
        log(f"PERMISSION DENIED: Role {role} cannot create bugs")
        return None
    if not check_queue_depth("bugs"):
        return None
    if not check_crew_rate_limit(crew_number, order_id):
        return None

    bug_id = generate_queue_id("BUG")
    queue_item = {
        "id": bug_id,
        "type": "BUG",
        "priority": priority,
        "status": "PENDING",
        "createdBy": {
            "crew": crew_number,
            "role": role,
            "order": order_id
        },
        "createdAt": datetime.now().isoformat(),
        "title": title,
        "description": description,
        "targetRole": "SHP"
    }

    queue_file = get_queue_dir() / "bugs" / f"{bug_id}.json"
    queue_file.parent.mkdir(parents=True, exist_ok=True)
    queue_file.write_text(json.dumps(queue_item, indent=2), encoding='utf-8')

    log(f"BUG CREATED: {bug_id} - {title}")
    return bug_id

def create_defect_report(crew_number: int, role: str, order_id: str,
                         title: str, description: str, severity: str = "NORMAL") -> Optional[str]:
    """
    Create a defect report in the queue (v5.0 - BOS only).
    Returns the defect ID if successful, None if not permitted.
    """
    if not can_create_item(role, "defects"):
        log(f"PERMISSION DENIED: Role {role} cannot create defects")
        return None
    if not check_queue_depth("defects"):
        return None
    if not check_crew_rate_limit(crew_number, order_id):
        return None

    defect_id = generate_queue_id("DEF")
    queue_item = {
        "id": defect_id,
        "type": "DEFECT",
        "priority": "NORMAL+" if severity == "HIGH" else "NORMAL",
        "status": "PENDING",
        "createdBy": {
            "crew": crew_number,
            "role": role,
            "order": order_id
        },
        "createdAt": datetime.now().isoformat(),
        "title": title,
        "description": description,
        "severity": severity,
        "targetRole": "SHP"
    }

    queue_file = get_queue_dir() / "defects" / f"{defect_id}.json"
    queue_file.parent.mkdir(parents=True, exist_ok=True)
    queue_file.write_text(json.dumps(queue_item, indent=2), encoding='utf-8')

    log(f"DEFECT CREATED: {defect_id} - {title}")
    return defect_id

def create_security_issue(crew_number: int, role: str, order_id: str,
                          title: str, description: str, severity: str = "HIGH") -> Optional[str]:
    """
    Create a security issue in the queue (v5.0 - LKT only).
    Returns the security issue ID if successful, None if not permitted.
    """
    if not can_create_item(role, "security"):
        log(f"PERMISSION DENIED: Role {role} cannot create security issues")
        return None
    if not check_queue_depth("security"):
        return None
    if not check_crew_rate_limit(crew_number, order_id):
        return None

    sec_id = generate_queue_id("SEC")
    queue_item = {
        "id": sec_id,
        "type": "SECURITY",
        "priority": "HIGH" if severity == "CRITICAL" else "NORMAL+",
        "status": "PENDING",
        "createdBy": {
            "crew": crew_number,
            "role": role,
            "order": order_id
        },
        "createdAt": datetime.now().isoformat(),
        "title": title,
        "description": description,
        "severity": severity,
        "targetRole": "SHP"
    }

    queue_file = get_queue_dir() / "security" / f"{sec_id}.json"
    queue_file.parent.mkdir(parents=True, exist_ok=True)
    queue_file.write_text(json.dumps(queue_item, indent=2), encoding='utf-8')

    log(f"SECURITY ISSUE CREATED: {sec_id} - {title}")
    return sec_id

def request_investigation(crew_number: int, role: str, order_id: str,
                          title: str, description: str) -> Optional[str]:
    """
    Request an investigation from LKT (v5.0).
    Returns the request ID if successful, None if not permitted.
    """
    if not can_request_service(role, "investigation"):
        log(f"PERMISSION DENIED: Role {role} cannot request investigations")
        return None
    if not check_crew_rate_limit(crew_number, order_id):
        return None

    req_id = generate_queue_id("REQ-INV")
    queue_item = {
        "id": req_id,
        "type": "REQUEST",
        "requestType": "INVESTIGATION",
        "priority": "HIGH",
        "status": "PENDING",
        "createdBy": {
            "crew": crew_number,
            "role": role,
            "order": order_id
        },
        "createdAt": datetime.now().isoformat(),
        "title": title,
        "description": description,
        "targetRole": "LKT"
    }

    queue_file = get_queue_dir() / "requests" / "investigation" / f"{req_id}.json"
    queue_file.parent.mkdir(parents=True, exist_ok=True)
    queue_file.write_text(json.dumps(queue_item, indent=2), encoding='utf-8')

    log(f"INVESTIGATION REQUESTED: {req_id} - {title}")
    return req_id

def request_qa(crew_number: int, role: str, order_id: str,
               title: str, description: str) -> Optional[str]:
    """
    Request QA from BOS (v5.0).
    Returns the request ID if successful, None if not permitted.
    """
    if not can_request_service(role, "qa"):
        log(f"PERMISSION DENIED: Role {role} cannot request QA")
        return None
    if not check_crew_rate_limit(crew_number, order_id):
        return None

    req_id = generate_queue_id("REQ-QA")
    queue_item = {
        "id": req_id,
        "type": "REQUEST",
        "requestType": "QA",
        "priority": "HIGH",
        "status": "PENDING",
        "createdBy": {
            "crew": crew_number,
            "role": role,
            "order": order_id
        },
        "createdAt": datetime.now().isoformat(),
        "title": title,
        "description": description,
        "targetRole": "BOS"
    }

    queue_file = get_queue_dir() / "requests" / "qa" / f"{req_id}.json"
    queue_file.parent.mkdir(parents=True, exist_ok=True)
    queue_file.write_text(json.dumps(queue_item, indent=2), encoding='utf-8')

    log(f"QA REQUESTED: {req_id} - {title}")
    return req_id


def request_planning(crew_number: int, role: str, order_id: str,
                     title: str, description: str, report_path: str) -> Optional[str]:
    """
    Request planning/breakdown from NAV based on investigation findings (v5.0).
    Used by LKT after completing an investigation with findings.
    Returns the request ID if successful, None if not permitted.
    """
    if not can_request_service(role, "planning"):
        log(f"PERMISSION DENIED: Role {role} cannot request planning")
        return None
    if not check_crew_rate_limit(crew_number, order_id):
        return None

    req_id = generate_queue_id("REQ-PLAN")
    queue_item = {
        "id": req_id,
        "type": "REQUEST",
        "requestType": "PLANNING",
        "priority": "HIGH",
        "status": "PENDING",
        "createdBy": {
            "crew": crew_number,
            "role": role,
            "order": order_id
        },
        "createdAt": datetime.now().isoformat(),
        "title": title,
        "description": description,
        "reportPath": report_path,  # Path to LKT investigation report
        "targetRole": "NAV"
    }

    queue_file = get_queue_dir() / "requests" / "planning" / f"{req_id}.json"
    queue_file.parent.mkdir(parents=True, exist_ok=True)
    queue_file.write_text(json.dumps(queue_item, indent=2), encoding='utf-8')

    log(f"PLANNING REQUESTED: {req_id} - {title}")
    log(f"  Report: {report_path}")
    return req_id

def create_breakdown_order(crew_number: int, role: str, parent_order_id: str,
                           title: str, description: str, target_role: str) -> Optional[str]:
    """
    Create a breakdown sub-order from a high-level order (v5.0).
    Only NAV, LKT, COX can break down orders.
    Returns the order ID if successful, None if not permitted.
    """
    if not can_breakdown_orders(role):
        log(f"PERMISSION DENIED: Role {role} cannot break down orders")
        return None
    if not check_queue_depth("breakdown"):
        return None
    if not check_crew_rate_limit(crew_number, parent_order_id):
        return None

    order_id = generate_queue_id("SUB")
    queue_item = {
        "id": order_id,
        "type": "ORDER",
        "orderType": "BREAKDOWN",
        "priority": "LOW",
        "status": "PENDING",
        "createdBy": {
            "crew": crew_number,
            "role": role,
            "order": parent_order_id
        },
        "parentOrder": parent_order_id,
        "createdAt": datetime.now().isoformat(),
        "title": title,
        "description": description,
        "targetRole": target_role
    }

    queue_file = get_queue_dir() / "breakdown" / f"{order_id}.json"
    queue_file.parent.mkdir(parents=True, exist_ok=True)
    queue_file.write_text(json.dumps(queue_item, indent=2), encoding='utf-8')

    log(f"BREAKDOWN ORDER CREATED: {order_id} - {title} (target: {target_role})")
    return order_id

def create_escalation(crew_number: int, role: str, order_id: str,
                      title: str, description: str, decision_needed: str,
                      blocking: bool = False, voyage_id: str = None) -> Optional[str]:
    """
    Create an escalation requiring Captain/QM decision (v7.0).
    Any role can escalate — no permission check needed.
    If blocking=True, dispatcher holds all orders for the same voyageId.
    Returns the escalation ID if successful, None if queue is full.
    """
    if not check_queue_depth("escalations"):
        return None
    if not check_crew_rate_limit(crew_number, order_id):
        return None

    esc_id = generate_queue_id("ESC")
    queue_item = {
        "id": esc_id,
        "type": "ESCALATION",
        "status": "PENDING",
        "blocking": blocking,
        "createdBy": {
            "crew": crew_number,
            "role": role,
            "order": order_id
        },
        "createdAt": datetime.now().isoformat(),
        "title": title,
        "description": description,
        "decisionNeeded": decision_needed,
        "voyageId": voyage_id,
        "resolution": None
    }

    queue_file = get_queue_dir() / "escalations" / f"{esc_id}.json"
    queue_file.parent.mkdir(parents=True, exist_ok=True)
    queue_file.write_text(json.dumps(queue_item, indent=2), encoding='utf-8')

    block_str = " [BLOCKING]" if blocking else ""
    log(f"ESCALATION CREATED{block_str}: {esc_id} - {title}")
    log(f"  Decision needed: {decision_needed}")
    return esc_id

# ============================================================================
# PROMPT BUILDING
# ============================================================================

def load_role_template(role: str, minimal: bool = True) -> str:
    """Load role definition via the overlay loader (SEC-0185 / FTR-0186).

    Resolution order:
      1. Effective merged role from maestro.roles.loader (core + optional overlay)
      2. Legacy workspace template files (prompts/templates/{role}-minimal.md etc.)
      3. Bare "# Role: {role}" fallback

    The overlay loader is attempted first so per-org overlays automatically
    propagate to crew sessions.
    """
    try:
        from maestro.roles.loader import load_effective_role
        ws = get_workspace_dir()
        role_def = load_effective_role(role.upper(), ws)
        return role_def.to_markdown()
    except Exception:
        pass

    # Legacy fallback: workspace template files
    if minimal:
        minimal_file = get_workspace_dir() / f"prompts/templates/{role}-minimal.md"
        if minimal_file.exists():
            return minimal_file.read_text(encoding='utf-8')

    template_file = get_workspace_dir() / f"prompts/templates/{role}-template.md"
    if template_file.exists():
        return template_file.read_text(encoding='utf-8')
    return f"# Role: {role}"

def build_prompt(crew_number: int, iteration: int, max_iterations: int,
                 role: str, order_id: str, task_prompt: str,
                 completion_promise: str = "COMPLETE") -> str:
    """Build a focused prompt for Claude - optimized for performance."""

    role_injection = load_role_template(role, minimal=True)

    # Only include progress on subsequent iterations
    progress_section = ""
    if iteration > 1:
        progress = read_progress(crew_number)
        progress_section = f"\n## CURRENT PROGRESS\n\n{progress}\n"

    prompt = f"""# CREW {crew_number} | ITERATION {iteration}/{max_iterations} | {role} | {order_id}

{role_injection}

## ORDER

{task_prompt}
{progress_section}
## INSTRUCTIONS

Execute the next step. Update `.mso/crews/crew{crew_number}/progress.md`.

When complete: `<promise>{completion_promise}</promise>`
If blocked: `<promise>BLOCKED</promise>`
"""
    # Warn if prompt is large - queue mode recommended for reliability
    if len(prompt) > 3000:
        log(f"  [WARN] Prompt is {len(prompt)} bytes - large prompts may be slow")

    return prompt

# ============================================================================
# CLAUDE EXECUTION
# ============================================================================

# FTR-MSO-2026-0281: module-level cache for the located CLI path and its
# probed capabilities, so the filesystem walk and --help invocation happen
# at most once per process lifetime.
_CLI_PATH: Optional[str] = None
_CLI_CAPS: Optional[dict] = None


def _probe_cli_caps(cli_path: str) -> None:
    """Probe the CLI binary for optional feature flags and cache the result.

    FTR-MSO-2026-0281: runs `<cli> --help` once and records which flags are
    advertised.  Populates the module-level _CLI_CAPS dict so invoke_claude
    can conditionally add --effort without crashing on older CLI versions.
    """
    global _CLI_CAPS
    try:
        result = subprocess.run(
            [cli_path, "--help"],
            capture_output=True,
            text=True,
            timeout=15,
            encoding="utf-8",
            errors="replace",
        )
        help_text = result.stdout + result.stderr
        _CLI_CAPS = {
            "effort": "--effort" in help_text,
            "settings": "--settings" in help_text,
        }
        log(f"  [DEBUG] CLI caps probed: effort={_CLI_CAPS['effort']} settings={_CLI_CAPS['settings']}")
    except Exception as exc:
        _CLI_CAPS = {"effort": False, "settings": False}
        log(f"  [WARN] CLI capability probe failed ({exc}); assuming no optional flags.")


def find_claude_cli() -> Optional[str]:
    """Find the Claude CLI executable."""
    global _CLI_PATH
    if _CLI_PATH is not None:
        return _CLI_PATH

    # Try common locations
    possible_paths = [
        "claude",  # In PATH
        "claude.cmd",  # Windows
        os.path.expanduser("~/.npm-global/bin/claude"),
        os.path.expanduser("~/AppData/Roaming/npm/claude.cmd"),
    ]

    for path in possible_paths:
        try:
            result = subprocess.run(
                [path, "--version"],
                capture_output=True,
                text=True,
                timeout=10
            )
            if result.returncode == 0:
                _CLI_PATH = path
                _probe_cli_caps(path)
                return _CLI_PATH
        except:
            continue

    return None


def compute_iteration_timeout(timeout_minutes: int) -> int:
    """Seconds a single agent iteration (one `claude --print` call) may run.

    Captain directive 2026-05-20: `timeout_minutes` is the direct per-iteration
    cap, not a total budget divided across iterations. Previously this was
    `max(600, min(1800, (timeout_minutes * 60) // max_iterations))`, which
    contradicted the --timeout flag's own help ("Timeout per iteration in
    minutes") and let a single agent run up to 30 minutes. With the default
    of 25, one iteration now gets exactly 25 minutes and no more.
    """
    return max(1, timeout_minutes) * 60


def parse_crew_result(stdout: str) -> dict:
    """Parse the structured JSON result from `claude --output-format json`.

    FTR-MSO-2026-0193 / Part A: replaces stdout string-grepping with
    deterministic structured result parsing.

    On malformed/empty output (e.g. wall-clock kill mid-stream) returns a
    safe sentinel dict with is_error=True — never classified as COMPLETE.
    """
    stdout = stdout.strip()
    if not stdout:
        return {
            "subtype": "timeout_killed",
            "is_error": True,
            "result": "",
            "total_cost_usd": 0.0,
            "num_turns": 0,
            "session_id": "",
            "terminal_reason": "timeout_killed",
            "errors": ["No output captured (process killed before completion)"],
        }
    try:
        return json.loads(stdout)
    except json.JSONDecodeError:
        return {
            "subtype": "parse_error",
            "is_error": True,
            "result": stdout[:2000],
            "total_cost_usd": 0.0,
            "num_turns": 0,
            "session_id": "",
            "terminal_reason": "parse_error",
            "errors": ["JSON parse failed — truncated or malformed output"],
        }


def _salvage_truncated_result(raw_stdout: str, assistant_turns: int) -> Optional[dict]:
    """BUG-MSO-2026-0279: best-effort recovery of a truncated stream-json result.

    The terminal ``{"type":"result", ...}`` event embeds the full assistant
    transcript in its ``result`` field, which on a large TST/BLD iteration can
    exceed the ~700-900 KB at which the captured stdout gets truncated. When that
    happens the result line is cut off mid-string and ``json.loads`` fails for it,
    so the reverse scan finds no parseable result event.

    Rather than discarding everything as ``parse_error`` (which REQUEUEs and
    wastes a crew that may well have succeeded), extract whatever scalar fields
    survived. The CLI serialises ``subtype``/``is_error``/``num_turns`` BEFORE the
    huge ``result`` string, so the verdict is usually recoverable even when
    ``session_id``/``total_cost_usd`` (which come after) are lost.

    Returns a result-shaped dict (with ``salvaged_from_truncation=True``), or
    None if no result-event fragment is present at all.
    """
    idx = raw_stdout.rfind('{"type":"result"')
    if idx == -1:
        idx = raw_stdout.rfind('{"type": "result"')
    if idx == -1:
        return None
    fragment = raw_stdout[idx:]

    def _grab_str(key: str) -> Optional[str]:
        m = re.search(r'"%s"\s*:\s*"([^"\\]*)"' % key, fragment)
        return m.group(1) if m else None

    def _grab_num(key: str):
        m = re.search(r'"%s"\s*:\s*(-?[0-9]+(?:\.[0-9]+)?)' % key, fragment)
        return float(m.group(1)) if m else None

    def _grab_bool(key: str):
        m = re.search(r'"%s"\s*:\s*(true|false)' % key, fragment)
        return (m.group(1) == "true") if m else None

    subtype = _grab_str("subtype")
    is_error = _grab_bool("is_error")
    session_id = _grab_str("session_id") or ""
    cost = _grab_num("total_cost_usd")
    num_turns_recovered = _grab_num("num_turns")
    num_turns = int(num_turns_recovered) if num_turns_recovered is not None else int(assistant_turns)

    if subtype is None and is_error is None:
        # Couldn't recover the verdict — not safe to call it success. Fall back to
        # an error-flavoured sentinel that still carries the salvaged turns/session
        # so the REQUEUE path + BUG-0023 commit-detection can rescue committed work
        # (and lifecycle telemetry is better than a blind parse_error).
        return {
            "subtype": "parse_error",
            "is_error": True,
            "result": fragment[:2000],
            "total_cost_usd": cost if cost is not None else 0.0,
            "num_turns": num_turns,
            "session_id": session_id,
            "terminal_reason": "parse_error",
            "errors": ["Result event truncated; verdict unrecoverable — salvaged turns/session only"],
            "salvaged_from_truncation": True,
        }

    # Verdict recovered — trust the CLI's own classification (it had already decided
    # success/error before the transcript blob that got truncated).
    resolved_subtype = subtype or ("error" if is_error else "success")
    if is_error is not None:
        resolved_is_error = bool(is_error)
    else:
        # is_error truncated away but subtype survived: ONLY an explicit success
        # subtype is non-error. Anything else (error_during_execution, ...) must
        # classify as an error — never silently fall through to COMPLETE.
        resolved_is_error = resolved_subtype != "success"
    return {
        "subtype": resolved_subtype,
        "is_error": resolved_is_error,
        "result": fragment[:2000],
        "total_cost_usd": cost if cost is not None else 0.0,
        "num_turns": num_turns,
        "session_id": session_id,
        "terminal_reason": resolved_subtype,
        "salvaged_from_truncation": True,
    }


def parse_stream_result(raw_stdout: str) -> dict:
    """Extract the terminal result dict from `--output-format stream-json` output.

    FTR-MSO-2026-0227: stream-json emits one JSON object per line. The final
    event with ``"type": "result"`` is the terminal result object — same shape
    as the single blob produced by ``--output-format json``, so it is fully
    compatible with parse_crew_result / classify_json_terminal downstream.

    Scans lines in reverse so we find the result event without scanning the
    entire (potentially large) stream on every call.
    """
    raw_stdout = raw_stdout.strip()
    if not raw_stdout:
        return parse_crew_result("")  # reuse the timeout_killed sentinel

    lines = raw_stdout.splitlines()
    for line in reversed(lines):
        line = line.strip()
        if not line:
            continue
        try:
            obj = json.loads(line)
        except json.JSONDecodeError:
            continue
        if obj.get("type") == "result":
            return obj

    # No complete result event found — the terminal event may have been truncated
    # mid-line by a large transcript (BUG-MSO-2026-0279). Attempt to salvage the
    # verdict + session_id/turns/cost from the fragment before giving up on it.
    assistant_turns, _ = count_stream_events(raw_stdout)
    salvaged = _salvage_truncated_result(raw_stdout, assistant_turns)
    if salvaged is not None:
        return salvaged

    # Nothing recoverable — treat as parse_error (same sentinel as json mode).
    return parse_crew_result(raw_stdout)


def count_stream_events(raw_stdout: str) -> tuple[int, int]:
    """Count assistant turns and Agent/Task subagent spawns in stream-json output.

    FTR-MSO-2026-0227: returns (turn_count, subagent_count) for state.json.
    - turn_count: number of ``type=assistant`` events (one per Claude turn)
    - subagent_count: number of ``type=tool_use`` events with name in {Agent, Task}

    Safe to call with empty or malformed output; returns (0, 0) in that case.
    """
    turns = 0
    subagents = 0
    for line in raw_stdout.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            obj = json.loads(line)
        except json.JSONDecodeError:
            continue
        ev_type = obj.get("type", "")
        if ev_type == "assistant":
            turns += 1
        elif ev_type == "tool_use" and obj.get("name") in ("Agent", "Task"):
            subagents += 1
    return turns, subagents


def _supervision_stall_seconds() -> int:
    """FTR-MSO-2026-0299: activity-watchdog threshold from workspace config.

    `completion.supervision.stallMinutes` (default 10; 0 disables the
    watchdog). A crew with NO stream output for this long is HUNG and is
    killed + salvaged + requeued — while a crew that keeps streaming turns
    is never killed before the (now generous) wall-clock ceiling.
    """
    try:
        from maestro.workspace import get_workspace_dir
        cfg = json.loads((get_workspace_dir() / "config" / "workspace.json")
                         .read_text(encoding="utf-8"))
        minutes = ((cfg.get("completion") or {}).get("supervision") or {}).get("stallMinutes", 10)
        return max(0, int(minutes)) * 60
    except Exception:
        return 10 * 60


def _describe_tool_event(name: str, inp: dict) -> str:
    """FTR-MSO-2026-0310: render a tool_use event as a short operator-readable
    action string (e.g. 'Editing crew.py', 'Running: pytest -q')."""
    inp = inp or {}

    def _base(p: str) -> str:
        p = (p or "").replace("\\", "/").rstrip("/")
        return p.rsplit("/", 1)[-1] if p else ""

    if name in ("Edit", "Write", "MultiEdit"):
        f = _base(inp.get("file_path", ""))
        return f"Editing {f}" if f else "Editing"
    if name == "NotebookEdit":
        f = _base(inp.get("notebook_path", ""))
        return f"Editing {f}" if f else "Editing notebook"
    if name == "Read":
        f = _base(inp.get("file_path", ""))
        return f"Reading {f}" if f else "Reading"
    if name == "Bash":
        cmd = " ".join((inp.get("command", "") or "").split())
        return f"Running: {cmd[:48]}" if cmd else "Running command"
    if name in ("Grep", "Glob"):
        pat = inp.get("pattern") or inp.get("query") or ""
        return f"Searching: {pat[:40]}" if pat else "Searching"
    if name in ("Agent", "Task"):
        desc = inp.get("description") or inp.get("subagent_type") or ""
        return f"Spawning agent: {desc[:40]}" if desc else "Spawning agent"
    if name:
        return name
    return ""


def _describe_stream_event(obj: dict) -> str:
    """FTR-MSO-2026-0310: derive a human-readable 'what is the crew doing now'
    string from a single stream-json event. Returns '' for events with no
    meaningful action (so the caller keeps the previous activity)."""
    et = obj.get("type", "")
    if et == "tool_use":
        return _describe_tool_event(obj.get("name", ""), obj.get("input", {}))
    if et == "assistant":
        # An assistant turn may carry text and/or embedded tool_use blocks.
        # Prefer the most recent actionable block; fall back to a text snippet.
        content = (obj.get("message", {}) or {}).get("content", []) or []
        text_snip = ""
        for block in reversed(content):
            if not isinstance(block, dict):
                continue
            bt = block.get("type")
            if bt == "tool_use":
                return _describe_tool_event(block.get("name", ""), block.get("input", {}))
            if bt == "text" and not text_snip:
                text_snip = " ".join((block.get("text", "") or "").split())
        if text_snip:
            return text_snip[:60]
    return ""


def _read_stream_lines(
    stdout_pipe,
    lines_out: list,
    live_state: list,
    on_live_update,
    activity: list = None,
    activity_text: list = None,
) -> None:
    """Background thread: read stream-json lines, update live counters.

    FTR-MSO-2026-0227: runs in a daemon thread alongside the Claude subprocess.
    live_state is a two-element list [turn_count, subagent_count] shared with
    the main thread (GIL makes int writes atomic on CPython).
    on_live_update(turns, subagents) is called after each counter change.
    FTR-MSO-2026-0299: activity is a one-element [monotonic_ts] list stamped
    on EVERY line read — the watchdog's liveness signal.
    FTR-MSO-2026-0310: activity_text is a one-element [str] list holding the
    latest operator-readable action; updated before on_live_update fires so the
    callback can persist it to state.json. The 2-arg on_live_update contract is
    unchanged — activity flows through the shared list, not the call signature.
    """
    turns = 0
    subagents = 0
    for raw_line in stdout_pipe:
        if activity is not None:
            activity[0] = time.monotonic()
        lines_out.append(raw_line)
        line = raw_line.strip()
        if not line:
            continue
        try:
            obj = json.loads(line)
        except json.JSONDecodeError:
            continue
        ev_type = obj.get("type", "")
        if activity_text is not None:
            desc = _describe_stream_event(obj)
            if desc:
                activity_text[0] = desc
        changed = False
        if ev_type == "assistant":
            turns += 1
            changed = True
        elif ev_type == "tool_use" and obj.get("name") in ("Agent", "Task"):
            subagents += 1
            changed = True
        if changed:
            live_state[0] = turns
            live_state[1] = subagents
            if on_live_update is not None:
                try:
                    on_live_update(turns, subagents)
                except Exception:
                    pass


def classify_json_terminal(json_result: dict) -> str:
    """Classify a parsed JSON result into a terminal state.

    FTR-MSO-2026-0193 / Part B: primary classification from structured
    result, NOT stdout string-grep.

    Returns: 'COMPLETE' | 'ERROR' | 'MAX_TURNS'
    """
    subtype = json_result.get("subtype", "")
    if subtype == "error_max_turns":
        return "MAX_TURNS"
    if json_result.get("is_error", False):
        return "ERROR"
    return "COMPLETE"


def _kill_process_tree(pid: int) -> None:
    """Force-kill a process AND all its descendants (BUG-MSO-2026-0206).

    `subprocess.run(timeout=)` / `Popen.kill()` only terminate the DIRECT child.
    `claude --print` spawns grandchildren (node / MCP servers) that keep the stdout
    pipe handle open, so the post-timeout cleanup `communicate()` blocks forever and
    the iteration never reaps — orders stalled RUNNING ~1h in VOY-MSO-2026-0054.
    Killing the whole tree closes the pipe so the drain returns.
    """
    try:
        if os.name == "nt":
            subprocess.run(
                ["taskkill", "/F", "/T", "/PID", str(pid)],
                capture_output=True, timeout=15,
            )
        else:
            import signal as _signal
            try:
                os.killpg(os.getpgid(pid), _signal.SIGKILL)
            except Exception:
                os.kill(pid, _signal.SIGKILL)
    except Exception:
        pass


def invoke_claude(prompt: str, timeout_seconds: int = 1500,
                  crew_number: int = 0, order_id: str = "",
                  max_iterations: int = 25, completion_promise: str = "COMPLETE",
                  role: str = "", max_turns: int = 25,
                  session_id: str = "",
                  on_live_update=None, live_activity=None) -> Dict[str, Any]:
    """Invoke Claude CLI with the given prompt in --print --output-format stream-json mode.

    FTR-MSO-2026-0193: switched from raw stdout to structured JSON result.
    FTR-MSO-2026-0227: switched from --output-format json to stream-json so live
    turn counts and subagent spawns can be tracked while the process runs.
    Adds --output-format stream-json and --max-turns N to the claude invocation.
    The structured JSON result is parsed from the stream and returned under
    result["json_result"]. The terminal result shape is identical to json mode.

    on_live_update: optional callable(turns: int, subagents: int) invoked from a
    background thread on each assistant turn or Agent/Task spawn. Use this to
    write live progress to state.json without blocking the subprocess.

    v8.3: Role-based model selection. Each role gets the optimal model:
      COX → Opus (critical review), NAV/SHP/BOS/SCR → Sonnet, LKT → Haiku (fast scan)

    Injects MAESTRO_ITER_MANAGED=1 so the stop hook exits cleanly rather than
    trying to re-feed prompts via {decision: block}. That mechanism silently
    fails on Windows with CREATE_NO_WINDOW in a DETACHED_PROCESS context
    (BUG-MSO-2026-0029). Iteration control belongs to run_crew()'s for-loop.

    v6.0: No CLI lock needed. Each crew runs as a fully detached independent
    process (launched by fleet-runner v6.0 with DETACHED_PROCESS flags).
    Concurrent API calls are safe when processes are truly independent.
    """
    result = {
        "success": False,
        "output": "",
        "error": None,
        "timed_out": False,
        "lock_failed": False,
        "json_result": {},
    }

    claude_cli = find_claude_cli()
    if not claude_cli:
        result["error"] = "Claude CLI not found. Install with: npm install -g @anthropic-ai/claude-code"
        return result

    try:
        # Run Claude with the prompt (use UTF-8 encoding explicitly)
        # CREATE_NO_WINDOW (0x08000000) prevents console window popup in background mode
        run_kwargs = {}
        if os.name == 'nt':
            run_kwargs['creationflags'] = 0x08000000  # CREATE_NO_WINDOW
        else:
            # BUG-MSO-2026-0206: put the crew in its own process group so a timeout
            # can kill the whole tree (claude + node + MCP grandchildren) via killpg.
            run_kwargs['start_new_session'] = True

        # v8.0: Set environment variables for the fleet stop hook
        # The hook reads MAESTRO_CREW to find the crew's ralph-state.md
        # If MAESTRO_CREW is not set (Captain's session), the hook exits immediately
        env = os.environ.copy()

        # v8.5: Inject NUGET_AUTH_TOKEN for GitHub Packages authentication
        # Crews need this to restore EML.* packages from the private feed.
        # Sources (in priority order): existing env var, gh CLI token
        if not env.get("NUGET_AUTH_TOKEN"):
            try:
                gh_token = subprocess.run(
                    ["gh", "auth", "token"],
                    capture_output=True, text=True, timeout=10
                )
                if gh_token.returncode == 0 and gh_token.stdout.strip():
                    env["NUGET_AUTH_TOKEN"] = gh_token.stdout.strip()
                    log("  NuGet auth: injected from gh CLI")
            except Exception:
                log("  NuGet auth: gh CLI not available, NUGET_AUTH_TOKEN not set")

        # v8.14: Centralized temp directory for crew artifacts
        # Prevents crews scattering .local-nuget, build outputs, etc. across the workspace
        maestro_root = Path(__file__).resolve().parent.parent
        _temp_val = str(maestro_root / "temp")
        env["MAESTRO_TEMP"] = _temp_val

        if crew_number > 0:
            env["MAESTRO_CREW"] = str(crew_number)
            env["MAESTRO_ORDER"] = order_id
            env["MAESTRO_MAX_ITERATIONS"] = str(max_iterations)
            env["MAESTRO_COMPLETION_PROMISE"] = completion_promise
            # v8.4: Force headless mode for Playwright tests run by fleet crews
            # Prevents browser windows popping up on the Captain's desktop
            env["K2_TEST_HEADLESS"] = "true"
            # BUG-MSO-2026-0029: The stop hook fires in --print mode and returns
            # {"decision": "block"} to re-feed prompts. On Windows with
            # CREATE_NO_WINDOW in a DETACHED_PROCESS context, this re-feed
            # silently fails and Claude exits with 0-byte stdout, causing every
            # iter to produce empty output. Setting MAESTRO_ITER_MANAGED tells
            # the stop hook that the Python for-loop owns iteration control and
            # it should exit cleanly without blocking.
            env["MAESTRO_ITER_MANAGED"] = "1"

        # v8.3 / v2.5.6 (FTR-0129): Resolve model with full override chain
        # (per-order → workspace config → env var → ROLE_MODELS default).
        # Look up the order JSON from disk so per-order `model` overrides apply.
        # FTR-MSO-2026-0281: also resolve context window and effort tiers.
        order_data = _load_order_data_for(order_id) if order_id else {}
        try:
            model = resolve_model_for(role, order_data)
        except ValueError as model_err:
            log(f"  Model resolution failed: {model_err}")
            raise
        context_window = "standard"
        effort = "high"
        try:
            context_window = resolve_context_window_for(role, order_data)
            effort = resolve_effort_for(role, order_data)
        except ValueError as ce:
            log(f"  [WARN] Context/effort resolution failed: {ce}. Using defaults.")
        model_arg = model + "[1m]" if context_window == "1m" else model
        log(f"  Model: {model_arg} | context: {context_window} | effort: {effort} (role={role or 'default'})")

        # Use worktree path as working directory when available (injected via MAESTRO_REPO_PATH).
        work_dir = get_base_dir()
        repo_path = env.get("MAESTRO_REPO_PATH", "")
        if repo_path:
            repo_dir = Path(repo_path)
            if repo_dir.exists() and (repo_dir / ".git").exists():
                work_dir = repo_dir
                log(f"  Working dir: {repo_dir} (managed repo)")
            else:
                log(f"  Working dir: {work_dir} (managed repo not found, using workspace root)")

        # FTR-MSO-2026-0193: add --output-format stream-json (structured stream) and
        # --max-turns N (turn-count cap enforced by Claude Code internally).
        # FTR-MSO-2026-0227: stream-json replaces json so we can parse live turn count
        # and subagent spawns while the process runs. The terminal result event is
        # identical in shape to the json-mode blob — all downstream classifiers work
        # unchanged (MAX_TURNS / COMPLETE / ERROR).
        # Both compose with the wall-clock timeout= cap above:
        #   wall-clock fires first → thread join timeout → timed_out=True
        #   max-turns fires first → exit code 1, subtype=error_max_turns → MAX_TURNS
        # BUG-MSO-2026-0250: the Claude CLI requires --verbose whenever
        # `--print --output-format stream-json` is used; without it the CLI exits
        # immediately with "When using --print, --output-format=stream-json requires
        # --verbose" (subtype=cli_error, turns=0) and NO crew can run. --verbose
        # only adds more JSONL events; the terminal {"type":"result"} event that
        # parse_stream_result keys on is unchanged.
        cmd = [
            claude_cli, "--print", "--dangerously-skip-permissions",
            "--model", model_arg,
            "--output-format", "stream-json", "--verbose",
            "--max-turns", str(max_turns),
        ]
        if session_id:
            cmd += ["--session-id", session_id]
        disallowed = ROLE_DISALLOWED_TOOLS.get(role or "", [])
        if disallowed:
            cmd += ["--disallowedTools", ",".join(disallowed)]
        cli_caps = _CLI_CAPS or {}
        if cli_caps.get("effort") and effort:
            cmd += ["--effort", effort]
        elif not cli_caps.get("effort") and effort not in ("high", ""):
            log(f"  [WARN] CLI lacks --effort support; running at model default (requested: {effort})")

        # BUG-MSO-2026-0206: use Popen with threaded line reading instead of
        # subprocess.run(timeout=). FTR-MSO-2026-0227: stream-json requires
        # line-by-line reading anyway, so we combine both concerns here.
        # A background thread drains stdout (parsing events and calling
        # on_live_update after each turn/agent event). The main thread joins
        # the reader with a wall-clock timeout; on expiry it kills the whole
        # process tree so grandchild pipe handles are released quickly.
        proc = subprocess.Popen(
            cmd,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding='utf-8',
            errors='replace',
            cwd=str(work_dir),
            env=env,
            **run_kwargs
        )

        # Write prompt to stdin and close immediately so Claude starts processing.
        try:
            proc.stdin.write(prompt)
            proc.stdin.close()
        except (BrokenPipeError, OSError):
            pass

        # Start background threads to drain both pipes concurrently.
        lines_out: list = []
        live_state = [0, 0]  # [turn_count, subagent_count] — shared with reader thread
        activity = [time.monotonic()]  # FTR-0299: stamped on every stream line
        stdout_reader = threading.Thread(
            target=_read_stream_lines,
            args=(proc.stdout, lines_out, live_state, on_live_update, activity,
                  live_activity),
            daemon=True,
        )
        stderr_lines: list = []
        stderr_reader = threading.Thread(
            target=lambda: stderr_lines.extend(proc.stderr),
            daemon=True,
        )
        stdout_reader.start()
        stderr_reader.start()

        # FTR-MSO-2026-0299 (GKT): activity-based supervision replaces the
        # single wall-clock join. A wall-clock timeout cannot distinguish
        # slow-but-working from hung — GKT's BLD crew was killed 3x while
        # doing real work. Now: kill as HUNG only when the stream has been
        # SILENT for stallMinutes; the wall-clock timeout remains as a
        # generous absolute ceiling (default 60 minutes; was 25 pre-FTR-0299).
        stall_seconds = _supervision_stall_seconds()
        start_mono = time.monotonic()
        timed_out = False
        hung = False
        while stdout_reader.is_alive():
            # Adaptive poll: cap the wait at 5s for responsive stall checks, but
            # never overshoot the wall-clock ceiling — a short timeout_seconds
            # (incl. 0) must fire promptly, not get rounded up to the poll
            # interval (BUG-MSO-2026-0303 follow-up to FTR-0299).
            _remaining = timeout_seconds - (time.monotonic() - start_mono)
            _poll = min(5.0, max(0.0, _remaining))
            stdout_reader.join(timeout=_poll)
            if not stdout_reader.is_alive():
                break
            now = time.monotonic()
            if now - start_mono >= timeout_seconds:
                timed_out = True
                break
            if stall_seconds and now - activity[0] >= stall_seconds:
                timed_out = True
                hung = True
                break
        if timed_out:
            # Kill the whole process tree so grandchildren release their pipe
            # handles, then give the drain threads a moment to flush.
            _kill_process_tree(proc.pid)
            stdout_reader.join(timeout=15)

        stderr_reader.join(timeout=5)
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            try:
                proc.kill()
            except Exception:
                pass

        raw_stdout = "".join(lines_out)
        raw_stderr = "".join(stderr_lines)

        if timed_out:
            result["timed_out"] = True
            result["hung"] = hung
            if hung:
                result["error"] = (
                    f"HUNG: no stream activity for {stall_seconds // 60} minutes "
                    f"(activity watchdog, FTR-0299) — killed and recovered via the "
                    f"timeout path (work salvaged, order requeued)"
                )
            else:
                result["error"] = f"Timed out after {timeout_seconds} seconds (hard ceiling)"
            result["output"] = raw_stdout
            if raw_stderr:
                result["output"] = (raw_stdout + "\n" + raw_stderr).strip()
            result["json_result"] = parse_stream_result(raw_stdout)
            return result

        # With --output-format stream-json, stdout is a sequence of newline-delimited
        # JSON events. The terminal result event has type="result" — same shape as
        # the single blob from json mode. stderr is diagnostic-only.
        raw_stdout = raw_stdout or ""
        result["output"] = raw_stdout
        if raw_stderr:
            result["output"] += "\n" + raw_stderr

        # Parse structured result from stream: find the type="result" event.
        # FTR-MSO-2026-0227: parse_stream_result scans the newline-delimited
        # stream for the terminal result event — same shape as json-mode output.
        json_result = parse_stream_result(raw_stdout)

        # BUG-MSO-2026-0220 (PSG fix #4): a process that exited on its own (NOT a
        # wall-clock timeout — that path is handled above) with empty/garbage stdout
        # and a non-zero code is a CLI ERROR (e.g. "Session ID ... is already in use"),
        # not a timeout. Reclassify so it isn't mislabeled `timeout_killed`, and surface
        # the real stderr reason instead of masking it behind a fake timeout.
        if (json_result.get("subtype") in ("timeout_killed", "parse_error")
                and proc.returncode not in (0, None)):
            stderr_reason = (raw_stderr or "").strip()
            if stderr_reason:
                json_result = {
                    **json_result,
                    "subtype": "cli_error",
                    "terminal_reason": "cli_error",
                    "errors": [stderr_reason[:500]],
                    "result": stderr_reason[:2000],
                }
                result["error"] = stderr_reason[:500]

        result["json_result"] = json_result
        # success = not an error AND not max-turns-hit (both exit with code 1).
        # Preserve raw returncode check as a secondary signal: if returncode==0
        # and json says not-error, it's success. If json says is_error, always failure.
        result["success"] = (proc.returncode == 0 and not json_result.get("is_error", False))

    except Exception as e:
        result["error"] = str(e)

    return result

# ============================================================================
# PREFLIGHT CHECK (FTR-MSO-2026-0194 / PLN Part E)
# ============================================================================

def run_preflight_check(claude_cli: str | None = None, timeout: int = 30) -> dict:
    """Smoke-test the Claude CLI by running a trivial --print invocation.

    Returns {"ok": bool, "exit_code": int, "output": str, "error": str}.

    `claude doctor` is TTY-interactive and cannot be used headlessly (Spike 5).
    This function is the scriptable alternative: it sends a trivial prompt and
    checks for a well-formed success response.

    Set MAESTRO_SKIP_AUTH=1 to bypass (CI environments without a Claude account).
    """
    if os.environ.get("MAESTRO_SKIP_AUTH"):
        return {"ok": True, "exit_code": 0, "output": "(skipped — MAESTRO_SKIP_AUTH)", "error": ""}

    if claude_cli is None:
        claude_cli = find_claude_cli()
    if not claude_cli:
        return {
            "ok": False, "exit_code": -1, "output": "",
            "error": "Claude CLI not found. Install with: npm install -g @anthropic-ai/claude-code",
        }

    try:
        proc = subprocess.run(
            [claude_cli, "--print", "--dangerously-skip-permissions",
             "--output-format", "json", "--max-turns", "1"],
            input="Reply with the single word: OK",
            capture_output=True, text=True, timeout=timeout,
            encoding="utf-8", errors="replace",
        )
        if proc.returncode != 0:
            return {
                "ok": False, "exit_code": proc.returncode,
                "output": proc.stdout, "error": proc.stderr or proc.stdout,
            }
        obj = json.loads(proc.stdout)
        if obj.get("subtype") == "success" and not obj.get("is_error"):
            return {"ok": True, "exit_code": 0, "output": proc.stdout, "error": ""}
        return {
            "ok": False, "exit_code": proc.returncode, "output": proc.stdout,
            "error": str(obj.get("result", "Preflight response indicates error")),
        }
    except subprocess.TimeoutExpired:
        return {"ok": False, "exit_code": -1, "output": "", "error": f"Preflight timed out after {timeout}s"}
    except json.JSONDecodeError as exc:
        return {"ok": False, "exit_code": -1, "output": "", "error": f"Preflight returned non-JSON: {exc}"}
    except Exception as exc:
        return {"ok": False, "exit_code": -1, "output": "", "error": str(exc)}


# ============================================================================
# TIMEOUT BRIEFING (v7.3)
# ============================================================================

def generate_timeout_brief(crew_number: int, order_id: str, role: str,
                           iteration: int, max_iterations: int,
                           last_result: Dict[str, Any]) -> str:
    """Generate a brief summarizing work done before timeout.

    v7.3: Called when a crew times out. Captures iteration progress,
    artifacts produced, and partial output from the timed-out iteration.
    The brief is stored in crew state and appended to the order on re-queue.
    """
    crew_dir = get_crew_dir(crew_number)
    lines = []

    lines.append(f"### Timeout Brief — {order_id}")
    lines.append(f"- **Crew:** {crew_number} ({get_squad_name(crew_number)})")
    lines.append(f"- **Role:** {role}")
    lines.append(f"- **Timed out at:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    lines.append(f"- **Iteration:** {iteration} of {max_iterations}")
    lines.append("")

    # List output files from completed iterations
    output_files = sorted(crew_dir.glob("output_*.txt"))
    if output_files:
        lines.append("**Completed iteration outputs:**")
        for f in output_files:
            size = f.stat().st_size
            lines.append(f"- `{f.name}` ({size:,} bytes)")
        lines.append("")

    # Capture partial output from the timed-out iteration
    partial_output = last_result.get("output", "").strip()
    if partial_output:
        # Truncate to last 2000 chars to keep brief manageable
        if len(partial_output) > 2000:
            partial_output = "...(truncated)...\n" + partial_output[-2000:]
        lines.append("**Partial output (timed-out iteration):**")
        lines.append("```")
        lines.append(partial_output)
        lines.append("```")
        lines.append("")
    else:
        lines.append("**Partial output:** None captured (subprocess killed before output flushed)")
        lines.append("")

    # Check state for files changed
    state = read_state(crew_number) or {}
    files_changed = state.get("filesChangedTotal", 0)
    if files_changed > 0:
        lines.append(f"**Files modified during session:** {files_changed}")
        lines.append("")

    return "\n".join(lines)


# ============================================================================
# MAIN EXECUTION (v8.0 — Stop Hook Iteration Control)
# ============================================================================

def run_crew(crew_number: int, role: str, order_id: str, prompt_file: str,
             max_iterations: int = 25, completion_promise: str = "COMPLETE",
             circuit_breaker: int = 3, timeout_minutes: int = 60,
             max_turns: int = 25):
    """Run the crew with Python for-loop iteration control (BUG-MSO-2026-0029 fix).

    FTR-MSO-2026-0193: Each iteration uses --output-format json + --max-turns N.
    Primary completion/error classification comes from the structured JSON result,
    NOT from stdout string-grepping. MAX_TURNS is a distinct terminal state.

    Each iteration calls invoke_claude() once. MAESTRO_ITER_MANAGED=1 is set
    so the stop hook exits cleanly instead of fighting the loop with {decision: block}.
    ralph-state.md is updated at each boundary for fleet_monitor visibility.

    Flow:
      1. Create ralph-state.md (observability — updated by for-loop, not stop hook)
      2. For each iteration: build prompt, call invoke_claude, classify JSON result
      3. On COMPLETE / MAX_TURNS / BLOCKED / error / timeout: exit with appropriate status
    """

    log(f"""
+----------------------------------------------------------+
|  FLEET COMMAND SYSTEM - CREW EXECUTION ENGINE v8.0 (Py)  |
+----------------------------------------------------------+

  Crew:      {crew_number} ({get_squad_name(crew_number)})
  Role:      {role} ({_role_info(role).get('name', 'Unknown')})
  Order:     {order_id}
  Focus:     {_role_info(role).get('focus', 'Unknown')}
  Max Iter:  {max_iterations}
  Max Turns: {max_turns}
  Timeout:   {timeout_minutes} min
  Engine:    Stop Hook (Ralph Wiggum pattern)
""")

    # Check for existing lock
    if check_lock(crew_number):
        log("ERROR: Crew is already running.")
        log("Use --cleanup to force stop, or --status to check.")
        return 1

    # Load task prompt
    prompt_path = get_base_dir() / prompt_file
    if not prompt_path.exists():
        log(f"ERROR: Prompt file not found: {prompt_file}")
        return 1

    task_prompt = prompt_path.read_text(encoding='utf-8')

    # Set lock
    set_lock(crew_number, order_id, role)

    # Initialize state.json (kept for backward compat with fleet-runner/monitor)
    state = {
        "crewNumber": crew_number,
        "role": role,
        "orderId": order_id,
        "status": "RUNNING",
        "iteration": 1,
        "maxIterations": max_iterations,
        "maxTurns": max_turns,       # FTR-MSO-2026-0227: configured turn budget
        "liveTurn": 0,               # FTR-MSO-2026-0227: live turn counter (stream-json)
        "subagentCount": 0,          # FTR-MSO-2026-0227: Agent/Task spawns this session
        "filesChangedTotal": 0,
        "promptFile": prompt_file,
        "startTime": datetime.now().isoformat(),
        "pid": os.getpid()
    }
    write_state(crew_number, state)

    # Initialize progress
    init_progress(crew_number, order_id, role)

    # v8.0: Create ralph state file for stop hook
    create_ralph_state(crew_number, order_id, role, max_iterations, completion_promise)

    # Build prompt once (iteration 1 — hook handles subsequent iterations)
    full_prompt = build_prompt(
        crew_number, 1, max_iterations,
        role, order_id, task_prompt, completion_promise
    )

    # Save prompt for debugging
    current_prompt_file = get_crew_dir(crew_number) / "current_prompt.md"
    current_prompt_file.write_text(full_prompt, encoding='utf-8')

    # v6.0: Initial startup delay - stagger first API call per crew
    startup_delay = 10 * crew_number
    log(f"[{datetime.now().strftime('%H:%M:%S')}] Startup delay ({startup_delay}s, crew {crew_number} offset)...")
    time.sleep(startup_delay)

    final_status = "UNKNOWN"
    iter_timeout = compute_iteration_timeout(timeout_minutes)

    # BUG-MSO-2026-0220: per-crew-run nonce so re-dispatched orders get fresh
    # session ids (the Claude CLI rejects a previously-used --session-id). One
    # nonce per crew.py launch keeps ids stable across this run's iterations but
    # distinct from any prior (killed/timed-out) attempt's burned sessions.
    run_nonce = uuid.uuid4().hex

    try:
        # --print mode: the stop hook fires but MAESTRO_ITER_MANAGED=1 (set in
        # invoke_claude) tells it to exit cleanly so it doesn't try to re-feed
        # prompts via {"decision": "block"} — that fails silently on Windows in
        # a DETACHED_PROCESS context. The Python for-loop here is the single
        # source of truth for iteration control.
        for iteration in range(1, max_iterations + 1):
            state["iteration"] = iteration
            write_state(crew_number, state)

            # Advance ralph-state.md so fleet_monitor shows real-time progress
            advance_ralph_state(crew_number, iteration, "RUNNING")
            write_crew_lifecycle_event(
                "CREW_ITER_BOUNDARY",
                f"crew{crew_number} | {order_id} | iter {iteration}/{max_iterations} | role={role} | STARTING"
            )

            iter_prompt = build_prompt(
                crew_number, iteration, max_iterations,
                role, order_id, task_prompt, completion_promise
            )

            # FTR-MSO-2026-0195 + BUG-MSO-2026-0220: session id per (crew, order,
            # iteration), salted with the per-run nonce so re-dispatch never collides.
            maestro_sid = make_session_id(crew_number, order_id, iteration, run_nonce)
            state["maestroSessionId"] = maestro_sid
            write_state(crew_number, state)

            log(f"[{datetime.now().strftime('%H:%M:%S')}] Invoking Claude (iteration {iteration}/{max_iterations}, maestroSessionId={maestro_sid})...")
            update_heartbeat(crew_number, f"iteration-{iteration}", role)

            # FTR-MSO-2026-0227: reset live counters at the start of each iteration.
            state["liveTurn"] = 0
            state["subagentCount"] = 0
            state["activity"] = ""
            write_state(crew_number, state)

            # FTR-MSO-2026-0310: shared 1-element list holding the latest
            # operator-readable action; the reader thread writes it, the
            # callback persists it to state.json for the live monitor.
            live_activity = [""]

            def _on_live_update(turns: int, subagents: int, _state=state, _cn=crew_number,
                                _act=live_activity) -> None:
                """Called from background reader thread on each streamed event."""
                _state["liveTurn"] = turns
                _state["subagentCount"] = subagents
                _state["activity"] = _act[0]
                write_state(_cn, _state)

            result = invoke_claude(
                iter_prompt, iter_timeout,
                crew_number, order_id, max_iterations, completion_promise,
                role=role, max_turns=max_turns,
                session_id=maestro_sid,
                on_live_update=_on_live_update,
                live_activity=live_activity,
            )

            output = result.get("output", "")
            json_result = result.get("json_result", {})

            # FTR-MSO-2026-0193: extract structured fields for state + lifecycle.
            # FTR-MSO-2026-0195: store both IDs: maestroSessionId (ours) and claudeSessionId (Claude's).
            claude_session_id = json_result.get("session_id", "")
            num_turns = json_result.get("num_turns", 0)
            cost_usd = json_result.get("total_cost_usd", 0.0)

            # Update state with structured fields from this iteration.
            state["claudeSessionId"] = claude_session_id
            state["numTurns"] = num_turns
            state["totalCostUsd"] = round(float(cost_usd), 6)
            write_state(crew_number, state)

            # Save per-iteration output
            out_file = get_crew_dir(crew_number) / f"output_{iteration:02d}.txt"
            out_file.write_text(output, encoding='utf-8')

            log(f"[{datetime.now().strftime('%H:%M:%S')}] Iteration {iteration} complete.")
            # BUG-MSO-2026-0220 (PSG fix #5): on a failed iteration, surface the real
            # reason (stderr / error text) into the lifecycle line so operators don't
            # have to spelunk per-crew output_final.txt to learn why a crew died.
            _reason = ""
            if json_result.get("is_error"):
                _errs = json_result.get("errors") or []
                _reason = (_errs[0] if _errs else json_result.get("result", "")) or ""
                _reason = " | reason=" + " ".join(str(_reason).split())[:200]
            write_crew_lifecycle_event(
                "CREW_ITER_BOUNDARY",
                f"crew{crew_number} | {order_id} | iter {iteration}/{max_iterations} | role={role} | DONE"
                f" subtype={json_result.get('subtype', 'unknown')}"
                f" cost=${cost_usd:.4f} turns={num_turns}"
                f" maestroSession={maestro_sid} claudeSession={claude_session_id}"
                f"{_reason}"
            )

            if result["timed_out"]:
                log(f"[{datetime.now().strftime('%H:%M:%S')}] TIMEOUT on iteration {iteration}")
                brief = generate_timeout_brief(
                    crew_number, order_id, role, iteration, max_iterations, result
                )
                state["timeoutBrief"] = brief
                brief_file = get_crew_dir(crew_number) / f"timeout_brief_{order_id}.md"
                brief_file.write_text(brief, encoding='utf-8')
                final_status = "TIMEOUT"
                break

            if result["error"]:
                log(f"[{datetime.now().strftime('%H:%M:%S')}] ERROR: {result['error']}")
                error_lower = result["error"].lower()
                final_status = "AUTH_ERROR" if "authentication" in error_lower else "ERROR"
                break

            # FTR-MSO-2026-0193: PRIMARY classification from structured JSON result.
            # MAX_TURNS is a distinct terminal state (not COMPLETE, not generic ERROR).
            json_terminal = classify_json_terminal(json_result)
            if json_terminal == "MAX_TURNS":
                log(f"\n[{datetime.now().strftime('%H:%M:%S')}] MAX_TURNS hit (iteration {iteration}) — turn cap reached")
                final_status = "MAX_TURNS"
                break

            # Copilot review (PR #87): a structured error (is_error=True — incl.
            # subtype=parse_error / timeout_killed, where the raw/truncated stdout is
            # stored in json_result["result"]) MUST be classified as failure BEFORE the
            # promise-tag check below. Otherwise a malformed/truncated output that happens
            # to contain "<promise>COMPLETE</promise>" would be misread as COMPLETE —
            # defeating the exact BUG-MSO-2026-0023 silent-completion guard this order ships.
            if json_terminal == "ERROR":
                reason = json_result.get("terminal_reason") or json_result.get("subtype") or "json_error"
                log(f"\n[{datetime.now().strftime('%H:%M:%S')}] JSON result is_error ({reason}) — classifying as failure, not COMPLETE")
                final_status = "ERROR"
                break

            # SECONDARY signal: <promise> tags inside the assistant's result text.
            # These remain load-bearing for roles that emit them; the JSON primary
            # classification catches the case where no promise tag appears.
            result_text = json_result.get("result", output)
            if f"<promise>{completion_promise}</promise>" in result_text:
                log(f"\n[{datetime.now().strftime('%H:%M:%S')}] COMPLETION detected (iteration {iteration})!")
                final_status = "COMPLETE"
                break

            if "<promise>BLOCKED</promise>" in result_text:
                log(f"\n[{datetime.now().strftime('%H:%M:%S')}] BLOCKED detected (iteration {iteration})!")
                final_status = "BLOCKED"
                break

            # BUG-MSO-2026-0280 (defect A): JSON primary — subtype=success means the
            # crew is DONE. Break immediately instead of looping to a next iteration
            # that could emit BLOCKED and mislabel a successful completion.
            if json_terminal == "COMPLETE":
                log(f"\n[{datetime.now().strftime('%H:%M:%S')}] JSON result: success — order complete (BUG-0280)")
                final_status = "COMPLETE"
                break

            log(f"[{datetime.now().strftime('%H:%M:%S')}] Not complete — continuing to next iteration...")

        else:
            log(f"[{datetime.now().strftime('%H:%M:%S')}] Max iterations ({max_iterations}) reached")
            final_status = "MAX_ITERATIONS"

        # Copy last output to canonical file
        last_out = get_crew_dir(crew_number) / f"output_{state['iteration']:02d}.txt"
        if last_out.exists():
            (get_crew_dir(crew_number) / "output_final.txt").write_text(
                last_out.read_text(encoding='utf-8'), encoding='utf-8'
            )

    except KeyboardInterrupt:
        log("\n\nInterrupted by user.")
        final_status = "INTERRUPTED"
    except Exception as e:
        log(f"\nError: {e}")
        final_status = "ERROR"
    finally:
        # Update final state
        state["status"] = final_status
        state["endTime"] = datetime.now().isoformat()

        # v2.0.6: Load token usage captured by stop hook
        try:
            usage_file = get_workspace_dir() / "usage" / "orders" / f"{order_id}.json"
            if usage_file.exists():
                with open(usage_file, encoding="utf-8") as uf:
                    usage_data = json.load(uf)
                state["usage"] = {
                    "total_tokens": usage_data.get("total_tokens", 0),
                    "estimated_cost_usd": usage_data.get("estimated_cost_usd", 0),
                    "models": usage_data.get("models", {}),
                }
                log(f"[{datetime.now().strftime('%H:%M:%S')}] Token usage: {state['usage']['total_tokens']:,} tokens, ${state['usage']['estimated_cost_usd']:.2f}")
        except Exception:
            pass  # Fail-open: never block for usage tracking

        write_state(crew_number, state)

        # Clear lock
        clear_lock(crew_number)

    log(f"""
===========================================================
  VOYAGE {final_status}
===========================================================

Final Status: {final_status}
Iterations:   {state.get('iteration', 0)}
""")

    return 0 if final_status == "COMPLETE" else 1

# ============================================================================
# STATUS & CLEANUP
# ============================================================================

def show_status(crew_number: int):
    """Show crew status."""
    state = read_state(crew_number)

    print(f"""
+----------------------------------------------------------+
|  CREW {crew_number} ({get_squad_name(crew_number)}) STATUS
+----------------------------------------------------------+
""")

    if not state:
        print("  Status: INACTIVE (no state file)")
        return

    role = state.get('role', 'Unknown')
    role_name = _role_info(role).get('name', '')

    print(f"  Status:     {state.get('status', 'Unknown')}")
    print(f"  Role:       {role} ({role_name})")
    print(f"  Order:      {state.get('orderId', 'None')}")
    print(f"  Iteration:  {state.get('iteration', 0)} / {state.get('maxIterations', 0)}")
    print(f"  Started:    {state.get('startTime', 'Unknown')}")
    print(f"  PID:        {state.get('pid', 'Unknown')}")

    # Check heartbeat
    heartbeat_file = get_crew_dir(crew_number) / "heartbeat.txt"
    if heartbeat_file.exists():
        try:
            heartbeat_time = datetime.fromisoformat(heartbeat_file.read_text().strip())
            age = int((datetime.now() - heartbeat_time).total_seconds())
            print(f"  Heartbeat:  {age}s ago")
        except:
            pass

def watch_crew(crew_number: int, interval: int = 5):
    """Watch crew progress in real-time."""
    print(f"Watching Crew {crew_number} (Ctrl+C to stop)...\n")

    last_progress = ""
    last_iteration = 0

    try:
        while True:
            # Clear screen (works on Windows and Unix)
            os.system('cls' if sys.platform == 'win32' else 'clear')

            # Show status header
            state = read_state(crew_number)
            crew_name = get_squad_name(crew_number)

            print(f"+----------------------------------------------------------+")
            print(f"|  CREW {crew_number} ({crew_name}) - LIVE MONITOR")
            print(f"+----------------------------------------------------------+")
            print(f"  Time: {datetime.now().strftime('%H:%M:%S')}")
            print()

            if not state:
                print("  Status: INACTIVE")
                print("\n  Waiting for crew to start...")
            else:
                role = state.get('role', '?')
                role_name = _role_info(role).get('name', '')
                status = state.get('status', 'Unknown')
                iteration = state.get('iteration', 0)
                max_iter = state.get('maxIterations', 0)

                # Status color indicator
                status_indicator = {
                    'RUNNING': '[*]',
                    'COMPLETE': '[+]',
                    'BLOCKED': '[!]',
                    'ERROR': '[X]'
                }.get(status, '[ ]')

                print(f"  {status_indicator} Status:    {status}")
                print(f"      Role:      {role} ({role_name})")
                print(f"      Order:     {state.get('orderId', 'None')}")
                print(f"      Progress:  {iteration} / {max_iter} iterations")

                # Heartbeat
                heartbeat_file = get_crew_dir(crew_number) / "heartbeat.txt"
                if heartbeat_file.exists():
                    try:
                        hb_time = datetime.fromisoformat(heartbeat_file.read_text().strip())
                        age = int((datetime.now() - hb_time).total_seconds())
                        hb_status = "OK" if age < 120 else "STALE" if age < 300 else "DEAD"
                        print(f"      Heartbeat: {age}s ago ({hb_status})")
                    except:
                        pass

                # Show progress file content
                progress_file = get_crew_dir(crew_number) / "progress.md"
                if progress_file.exists():
                    progress = progress_file.read_text(encoding='utf-8')
                    print("\n  --- PROGRESS ---")
                    # Show last 20 lines of progress
                    lines = progress.strip().split('\n')
                    for line in lines[-20:]:
                        print(f"  {line}")

                # Check if completed
                if status in ['COMPLETE', 'BLOCKED', 'ERROR', 'MAX_ITERATIONS']:
                    print(f"\n  >>> Voyage ended with status: {status}")
                    break

            print(f"\n  (Refreshing every {interval}s - Ctrl+C to stop)")
            time.sleep(interval)

    except KeyboardInterrupt:
        print("\n\nStopped watching.")

def cleanup_crew(crew_number: int):
    """Cleanup crew processes and locks."""
    print(f"Cleaning up Crew {crew_number}...")

    state = read_state(crew_number)
    if state and state.get('pid'):
        pid = state['pid']
        try:
            # Try to kill the process
            if sys.platform == 'win32':
                subprocess.run(['taskkill', '/F', '/PID', str(pid)],
                             capture_output=True)
            else:
                subprocess.run(['kill', '-9', str(pid)], capture_output=True)
            print(f"  Killed process {pid}")
        except:
            pass

    clear_lock(crew_number)

    # v8.1: Clean hook data files
    crew_dir = get_crew_dir(crew_number)
    for filename in ["activity.jsonl", "activity.txt", "files_modified.json", "notifications.log"]:
        filepath = crew_dir / filename
        if filepath.exists():
            try:
                filepath.unlink()
            except Exception:
                pass

    print("Cleanup complete.")

# ============================================================================
# MAIN
# ============================================================================

def build_crew_parser() -> argparse.ArgumentParser:
    """Build the crew CLI argument parser (extracted from main() for testability — Copilot PR #87)."""
    parser = argparse.ArgumentParser(
        description="Maestro - Crew Execution Engine"
    )
    parser.add_argument("--crew", "-c", type=int, default=1, choices=[1,2,3,4,5],
                       help="Crew number (1-5)")
    # Accept both canonical (PLN/BLD/TST/DOC/SEC/REL/LEAD) and legacy nautical
    # codes (NAV/SHP/BOS/SCR/LKT/COX) for backward compat. Internal lookups
    # normalise via _role_info() / _role_permissions() so no conversion needed here.
    _ALL_ROLE_CHOICES = list(ROLE_INFO.keys())
    parser.add_argument("--role", "-r", type=str, choices=_ALL_ROLE_CHOICES,
                       help="Role code: PLN/BLD/TST/DOC/SEC/REL/LEAD")
    parser.add_argument("--order", "-o", type=str,
                       help="Order ID")
    parser.add_argument("--prompt", "-p", type=str,
                       help="Path to prompt file (relative to project root)")
    parser.add_argument("--max-iterations", "-m", type=int, default=20,
                       help="Maximum iterations (default: 20)")
    parser.add_argument("--timeout", "-t", type=int, default=60,
                       help="Per-iteration wall-clock CEILING in minutes (default: 60). The FTR-0299 activity watchdog (completion.supervision.stallMinutes) is the primary hang control.")
    parser.add_argument("--max-turns", type=int, default=25,
                       help="Max Claude turns per iteration (default: 25)")
    parser.add_argument("--spawn-marker", type=str, default="",
                       help="Inert workspace marker so cleanup's orphan sweep can find this process tree (BUG-MSO-2026-0302)")
    parser.add_argument("--circuit-breaker", type=int, default=3,
                       help="Iterations with no progress before stopping (default: 3)")
    parser.add_argument("--status", "-s", action="store_true",
                       help="Show crew status")
    parser.add_argument("--watch", "-w", action="store_true",
                       help="Watch crew progress in real-time")
    parser.add_argument("--watch-interval", type=int, default=5,
                       help="Watch refresh interval in seconds (default: 5)")
    parser.add_argument("--cleanup", action="store_true",
                       help="Cleanup crew processes and locks")
    return parser


def main():
    parser = build_crew_parser()
    args = parser.parse_args()

    if args.watch:
        watch_crew(args.crew, args.watch_interval)
        return 0

    if args.status:
        show_status(args.crew)
        return 0

    if args.cleanup:
        cleanup_crew(args.crew)
        return 0

    # Validate required args
    if not args.role:
        parser.error("--role is required for running")
    if not args.order:
        parser.error("--order is required for running")
    if not args.prompt:
        parser.error("--prompt is required for running")

    return run_crew(
        crew_number=args.crew,
        role=args.role,
        order_id=args.order,
        prompt_file=args.prompt,
        max_iterations=args.max_iterations,
        timeout_minutes=args.timeout,
        circuit_breaker=args.circuit_breaker,
        max_turns=args.max_turns
    )

if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as e:
        # Log error to file for debugging
        error_log = get_workspace_dir() / "logs" / "crew-errors.log"
        error_log.parent.mkdir(parents=True, exist_ok=True)
        with open(error_log, "a", encoding="utf-8") as f:
            f.write(f"\n[{datetime.now().isoformat()}] CREW CRASH\n")
            f.write(f"Error: {e}\n")
            import traceback
            f.write(traceback.format_exc())
            f.write("\n")

        print(f"\n\n*** CREW CRASHED ***")
        print(f"Error: {e}")
        print(f"See {error_log} for details")
        print("\nPress Enter to close...")
        try:
            input()
        except:
            pass
        sys.exit(1)


# ---------------------------------------------------------------------------
# Rebrand vocabulary (FTR-MSO-2026-0155) — new canonical names
# ---------------------------------------------------------------------------

class Squad:
    """Namespace sentinel for a crew/squad execution unit."""


# Legacy alias — kept through v3.x, removed in v4.0
Crew = Squad  # legacy alias (v3.x); removed v4.0
