from __future__ import annotations

import json
import urllib.request
import urllib.error
from urllib.parse import urljoin

from .base import SecretsProvider


class HashiCorpVaultProvider(SecretsProvider):
    """
    HashiCorp Vault secrets backend (KV v1 and v2).

    Uses stdlib urllib — no third-party dependencies required.

    config options:
      address    — Vault address, e.g. http://127.0.0.1:8200
      token      — Vault token (VAULT_TOKEN env var used as fallback)
      mount      — KV mount path (default: "secret")
      kv_version — 1 or 2 (default: 2)
      path       — sub-path within mount for all keys (default: "admiralty")
    """

    def __init__(self, config: dict | None = None) -> None:
        import os

        cfg = config or {}
        self._address = (cfg.get("address") or os.environ.get("VAULT_ADDR", "http://127.0.0.1:8200")).rstrip("/")
        self._token = cfg.get("token") or os.environ.get("VAULT_TOKEN", "")
        self._mount = cfg.get("mount", "secret")
        self._kv_version = int(cfg.get("kv_version", 2))
        self._path = cfg.get("path", "admiralty").strip("/")

    # ------------------------------------------------------------------
    # Internal HTTP helpers
    # ------------------------------------------------------------------

    def _headers(self) -> dict:
        return {"X-Vault-Token": self._token, "Content-Type": "application/json"}

    def _request(self, method: str, url: str, body: dict | None = None) -> dict:
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(url, data=data, headers=self._headers(), method=method)
        try:
            with urllib.request.urlopen(req) as resp:
                raw = resp.read()
                return json.loads(raw) if raw else {}
        except urllib.error.HTTPError as exc:
            if exc.code == 404:
                return {}
            raise

    # ------------------------------------------------------------------
    # URL helpers for KV v1 vs v2
    # ------------------------------------------------------------------

    def _data_url(self, key: str) -> str:
        if self._kv_version == 2:
            return f"{self._address}/v1/{self._mount}/data/{self._path}/{key}"
        return f"{self._address}/v1/{self._mount}/{self._path}/{key}"

    def _metadata_url(self, key: str) -> str:
        return f"{self._address}/v1/{self._mount}/metadata/{self._path}/{key}"

    def _list_url(self) -> str:
        if self._kv_version == 2:
            return f"{self._address}/v1/{self._mount}/metadata/{self._path}"
        return f"{self._address}/v1/{self._mount}/{self._path}"

    # ------------------------------------------------------------------
    # SecretsProvider interface
    # ------------------------------------------------------------------

    def get(self, key: str) -> str | None:
        resp = self._request("GET", self._data_url(key))
        if not resp:
            return None
        if self._kv_version == 2:
            return (resp.get("data") or {}).get("data", {}).get("value")
        return (resp.get("data") or {}).get("value")

    def set(self, key: str, value: str) -> None:
        if self._kv_version == 2:
            body = {"data": {"value": value}}
        else:
            body = {"value": value}
        self._request("POST", self._data_url(key), body)

    def delete(self, key: str) -> None:
        if self._kv_version == 2:
            self._request("DELETE", self._metadata_url(key))
        else:
            self._request("DELETE", self._data_url(key))

    def list(self) -> list[str]:
        url = self._list_url() + "?list=true"
        resp = self._request("GET", url)
        if not resp:
            return []
        if self._kv_version == 2:
            return (resp.get("data") or {}).get("keys", [])
        return (resp.get("data") or {}).get("keys", [])
