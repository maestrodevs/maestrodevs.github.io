# Orders and Voyages

Orders and voyages are how you define and organise work in Admiralty.

- An **order** is a discrete unit of work assigned to a single role.
- A **voyage** is a collection of related orders — the equivalent of a sprint or a feature release.

---

## Contents

- [Orders](#orders)
  - [Order Format](#order-format)
  - [Order ID Convention](#order-id-convention)
  - [Order Types](#order-types)
  - [Order Lifecycle](#order-lifecycle)
  - [Creating an Order](#creating-an-order)
  - [Dependencies](#dependencies)
- [Voyages](#voyages)
  - [Voyage Format](#voyage-format)
  - [Voyage ID Convention](#voyage-id-convention)
  - [Voyage Lifecycle](#voyage-lifecycle)
  - [Creating a Voyage](#creating-a-voyage)
- [Queue Tiers](#queue-tiers)
- [Escalations](#escalations)
- [Checking Status](#checking-status)

---

## Orders

### Order Format

An order is a JSON file. Here is the full format:

```json
{
  "orderId": "FTR-MYPROJ-2026-0001",
  "project": "MYPROJ",
  "type": "FTR",
  "role": "SHP",
  "title": "Add user authentication",
  "description": "Implement JWT-based login and registration. Use the existing User model in src/Models/User.cs. Endpoints: POST /auth/login returns a JWT; POST /auth/register creates a user. Return 401 on invalid credentials.",
  "acceptanceCriteria": [
    {
      "id": "ac-01",
      "description": "POST /auth/login returns 200 with a valid JWT on correct credentials",
      "validationType": "command",
      "command": "curl -s -o /dev/null -w '%{http_code}' -X POST http://localhost:5000/auth/login",
      "severity": "blocking"
    },
    {
      "id": "ac-02",
      "description": "POST /auth/register creates user and returns 201",
      "validationType": "manual",
      "severity": "blocking"
    },
    {
      "id": "ac-03",
      "description": "No changes to the User model schema",
      "validationType": "manual",
      "severity": "advisory"
    }
  ],

  "dependsOn": [],
  "voyageId": "VOY-MYPROJ-2026-0001",
  "targetFiles": [
    "my-project/src/Controllers/AuthController.cs",
    "my-project/src/Services/AuthService.cs"
  ],
  "status": "QUEUED",
  "maxIterations": 25
}
```

**Field reference:**

| Field | Required | Type | Description |
|-------|----------|------|-------------|
| `orderId` | Yes | string | Unique ID following the naming convention below. |
| `project` | Yes | string | Project acronym matching your `projects.json` registration. |
| `type` | Yes | string | Order type code (FTR, BUG, DOC, INT, SEC, etc.). |
| `role` | Yes | string | Role code: `NAV`, `SHP`, `BOS`, `SCR`, `LKT`, or `COX`. |
| `title` | Yes | string | Short human-readable title. |
| `description` | Yes | string | Full description of the work. Be specific — this is the crew's primary instruction. |
| `acceptanceCriteria` | No | array of objects | What "done" looks like. Each object has `id`, `description`, `validationType` (`manual`\|`command`\|`file-exists`), optional `command` or `path`, and `severity` (`blocking`\|`advisory`). Orders without `acceptanceCriteria` are supported for backwards compatibility — BOS falls back to informal sign-off and COX treats the order as ungated. See [Acceptance Criteria](#acceptance-criteria) below. |
| `dependsOn` | No | array of strings | Order IDs that must reach `COMPLETE` before this order dispatches. |
| `voyageId` | No | string | The voyage this order belongs to. |
| `targetFiles` | No | array of strings | Suggested files the crew should focus on. |
| `status` | Yes | string | Initial status. Always set to `"QUEUED"` when creating. |
| `maxIterations` | No | integer | Override the default 25 iteration limit for this order. |

### Order ID Convention

```
{TYPE}-{PROJECT}-{YEAR}-{SEQUENCE}
```

Examples:
- `FTR-MYPROJ-2026-0001` — first feature order for MYPROJ in 2026
- `BUG-MYPROJ-2026-0015` — fifteenth bug order
- `DOC-MYPROJ-2026-0003` — third documentation order

Keep sequences zero-padded to four digits.

### Order Types

| Type | Description |
|------|-------------|
| `FTR` | New feature |
| `BUG` | Bug fix |
| `DOC` | Documentation |
| `INT` | Integration or deployment |
| `SEC` | Security fix or audit |
| `QA` | Quality assurance / test coverage |
| `REF` | Refactoring |

You can use any type code that is meaningful to your project — the dispatcher does not validate type codes against an enumeration.

### Order Lifecycle

Orders move through these states:

```
QUEUED  →  ACTIVE  →  COMPLETE
                  ↘  FAILED
```

| State | Location | Description |
|-------|---------|-------------|
| `QUEUED` | `.admiralty/queues/{tier}/` | Awaiting dispatch. |
| `ACTIVE` | `.admiralty/orders/active/` | Currently being worked by a crew. |
| `COMPLETE` | `.admiralty/orders/complete/` | Crew signalled completion and order was verified. |
| `FAILED` | `.admiralty/orders/failed/` | Crew failed or timed out. |

The dispatcher moves files between these directories automatically. You should not move them manually while a dispatch session is running.

### Creating an Order

1. Write the order JSON using the format above.
2. Save it to the appropriate queue directory (usually `.admiralty/queues/orders/`).
3. Run `admiralty dispatch` — the Fleet Admiral will pick it up.

**Example:**

```bash
# Create the order file
cat > .admiralty/queues/orders/FTR-MYPROJ-2026-0001.json << 'EOF'
{
  "orderId": "FTR-MYPROJ-2026-0001",
  "project": "MYPROJ",
  "type": "FTR",
  "role": "SHP",
  "title": "Add CSV export endpoint",
  "description": "Add GET /api/reports/export that returns the current report data as a CSV file. Use the existing ReportService to fetch data. Set Content-Disposition: attachment; filename=report.csv.",
  "acceptanceCriteria": [
    {
      "id": "ac-01",
      "description": "GET /api/reports/export returns a valid CSV with correct column headers",
      "validationType": "manual",
      "severity": "blocking"
    },
    {
      "id": "ac-02",
      "description": "Response has Content-Type: text/csv and Content-Disposition: attachment",
      "validationType": "manual",
      "severity": "blocking"
    },
    {
      "id": "ac-03",
      "description": "Empty result set returns a CSV with headers only (no 500 error)",
      "validationType": "manual",
      "severity": "advisory"
    }
  ],
  "dependsOn": [],
  "voyageId": "VOY-MYPROJ-2026-0002",
  "status": "QUEUED"
}
EOF

# Dispatch
admiralty dispatch --max-crews 3
```

### Dependencies

Use `dependsOn` to ensure orders run in the right sequence. The dispatcher will not assign an order to a crew until all orders in its `dependsOn` array are `COMPLETE`.

```json
{
  "orderId": "BUG-MYPROJ-2026-0002",
  "dependsOn": ["FTR-MYPROJ-2026-0001"]
}
```

**Common patterns:**

Sequential feature + test:
```json
// SHP order
{ "orderId": "FTR-MYPROJ-2026-0005", "role": "SHP", "dependsOn": [] }

// BOS order waits for SHP
{ "orderId": "FTR-MYPROJ-2026-0006", "role": "BOS", "dependsOn": ["FTR-MYPROJ-2026-0005"] }
```

Plan-first workflow:
```json
// NAV plans first
{ "orderId": "FTR-MYPROJ-2026-0010", "role": "NAV", "dependsOn": [] }

// SHP waits for the plan
{ "orderId": "FTR-MYPROJ-2026-0011", "role": "SHP", "dependsOn": ["FTR-MYPROJ-2026-0010"] }
```

---

## Acceptance Criteria

Every order should include an `acceptanceCriteria` array. BOS validates each criterion after completing its work and records results in `acResults`. COX reads `acResults` and applies gate logic before promoting the order.

### Schema

Each criterion is an object with the following fields:

| Field | Type | Required | Notes |
|-------|------|----------|-------|
| `id` | string | Yes | Unique within the order, e.g. `ac-01` |
| `description` | string | Yes | Human-readable criterion |
| `validationType` | enum | Yes | `manual`, `command`, or `file-exists` |
| `command` | string | if `command` | Shell command run at workspace root; passes when exit code is 0 |
| `path` | string | if `file-exists` | Path relative to workspace root; passes if the file/directory exists |
| `severity` | enum | No | `blocking` (default) or `advisory` |

### Validation types

**`manual`** — BOS inspects the work product using its own judgement. No automated check.

**`command`** — BOS runs the specified shell command. Exit code 0 = pass; any non-zero = fail. stdout/stderr are captured in `acResults`.

**`file-exists`** — BOS checks that the file or directory at `path` exists after the work is done. Content is not inspected.

### Severity

**`blocking`** — A `FAIL` result causes COX to hard-stop and move the order to `failed/`.

**`advisory`** — A `FAIL` result is logged as a warning; COX continues.

### `acResults` field

BOS writes results back into the order JSON as a companion `acResults` array:

```json
"acResults": [
  {
    "id": "ac-01",
    "status": "PASS",
    "checkedAt": "2026-04-17T14:23:00Z",
    "notes": "pytest: 42 passed in 3.1s"
  },
  {
    "id": "ac-02",
    "status": "FAIL",
    "checkedAt": "2026-04-17T14:23:05Z",
    "notes": "File not found at expected path"
  }
]
```

`status` values: `PASS`, `FAIL`, `SKIP` (used when the check cannot run, e.g. command not found).

### Full example with AC

```json
{
  "orderId": "FTR-MYPROJ-2026-0001",
  "project": "MYPROJ",
  "type": "FTR",
  "role": "SHP",
  "title": "Add CSV export endpoint",
  "description": "Add GET /api/reports/export that returns current report data as CSV.",
  "acceptanceCriteria": [
    {
      "id": "ac-01",
      "description": "adm update --dry-run runs without error",
      "validationType": "command",
      "command": "adm update --dry-run",
      "severity": "blocking"
    },
    {
      "id": "ac-02",
      "description": "Export controller file exists",
      "validationType": "file-exists",
      "path": "src/Controllers/ExportController.cs",
      "severity": "blocking"
    },
    {
      "id": "ac-03",
      "description": "No regressions in existing API tests",
      "validationType": "manual",
      "severity": "blocking"
    },
    {
      "id": "ac-04",
      "description": "CHANGELOG updated",
      "validationType": "manual",
      "severity": "advisory"
    }
  ],
  "dependsOn": [],
  "status": "QUEUED"
}
```

### Backwards compatibility

Orders without `acceptanceCriteria` (or with an empty array) continue to work unchanged. BOS skips the AC phase; COX skips gate checks. New order templates scaffold `"acceptanceCriteria": []` so authors are prompted to fill it in, but leaving it empty is valid.

---

## Voyages

### Voyage Format

```json
{
  "voyageId": "VOY-MYPROJ-2026-0001",
  "project": "MYPROJ",
  "title": "Authentication feature",
  "description": "Implement login, registration, and JWT token management.",
  "orders": [
    "FTR-MYPROJ-2026-0001",
    "FTR-MYPROJ-2026-0002",
    "FTR-MYPROJ-2026-0003"
  ],
  "branch": "voyage/VOY-MYPROJ-2026-0001",
  "status": "ACTIVE",
  "createdAt": "2026-03-30"
}
```

**Field reference:**

| Field | Required | Type | Description |
|-------|----------|------|-------------|
| `voyageId` | Yes | string | Unique ID following the naming convention. |
| `project` | Yes | string | Project acronym. |
| `title` | Yes | string | Short description of the voyage goal. |
| `description` | No | string | Full description of the voyage scope. |
| `orders` | Yes | array of strings | All order IDs that belong to this voyage. |
| `branch` | No | string | The git branch crews commit to during this voyage. |
| `status` | Yes | string | `ACTIVE` or `COMPLETE`. |
| `createdAt` | No | string | ISO date string. |

### Voyage ID Convention

```
VOY-{PROJECT}-{YEAR}-{SEQUENCE}
```

Examples:
- `VOY-MYPROJ-2026-0001`
- `VOY-MYPROJ-2026-0002`

### Voyage Lifecycle

```
ACTIVE  →  COMPLETE
```

| State | Location |
|-------|---------|
| `ACTIVE` | `.admiralty/voyages/active/` |
| `COMPLETE` | `.admiralty/voyages/complete/` |

A voyage is complete when all its orders have reached `COMPLETE`. You can run `admiralty verify` to confirm the build and tests pass before marking the voyage complete.

### Creating a Voyage

1. Create the voyage JSON and save it to `.admiralty/voyages/active/`.
2. Create all associated orders and save them to the appropriate queues.
3. Dispatch the fleet.

**Tip:** Create orders and voyages in a batch before dispatching. The dispatcher handles ordering and dependency resolution automatically.

---

## Queue Tiers

Place an order in a specific queue directory to control its dispatch priority.

| Directory | Priority | Use For |
|-----------|----------|---------|
| `queues/explicit/` | Highest | Emergency or manually-forced dispatch |
| `queues/security/` | High | Security vulnerabilities and fixes |
| `queues/bugs/` | High | Bug fixes |
| `queues/requests/` | Medium-High | Crew-generated requests for follow-on work |
| `queues/orders/` | Medium | Normal feature work (default) |
| `queues/defects/` | Medium-Low | Defects identified in QA |
| `queues/breakdown/` | Low | Sub-tasks broken down from higher-level orders |
| `queues/high-level/` | Lowest | NAV planning tasks and high-level requirements |
| `queues/escalations/` | Not dispatched | Requires Captain/QM review before proceeding |

For most orders, `queues/orders/` is the right choice.

---

## Escalations

A crew that encounters a blocking issue it cannot resolve will write an escalation to `.admiralty/queues/escalations/`. Escalations with `"blocking": true` halt all subsequent orders in the same voyage until the Captain or Quartermaster resolves them.

**To resolve an escalation:**

1. Read the escalation JSON in `.admiralty/queues/escalations/`
2. Investigate the issue described
3. Set `"status": "RESOLVED"` and add a `"resolution"` string explaining what to do
4. Save the file — the dispatcher will unblock the voyage automatically on the next run

```json
{
  "escalationId": "ESC-MYPROJ-2026-0001",
  "orderId": "FTR-MYPROJ-2026-0005",
  "blocking": true,
  "issue": "Cannot find the User model at the path specified in the order. src/Models/User.cs does not exist.",
  "status": "RESOLVED",
  "resolution": "User model is at src/Domain/User.cs — update targetFiles in the order and re-queue."
}
```

---

## Checking Status

**Fleet-wide status:**
```bash
admiralty status --once
```

**Token usage per voyage:**
```bash
admiralty usage --voyage VOY-MYPROJ-2026-0001
```

**View completed orders:**
```bash
ls .admiralty/orders/complete/
```

**View failed orders:**
```bash
ls .admiralty/orders/failed/
```

**View an individual crew's progress:**
```bash
cat .admiralty/crews/crew1/progress.md
```

---

*Admiralty Fleet Command System v2.0.0 — For licensing enquiries, contact [tavisbasing](https://github.com/tavisbasing).*
