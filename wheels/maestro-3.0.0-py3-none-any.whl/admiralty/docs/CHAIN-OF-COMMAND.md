# Chain of Command — Admiralty v2.0.0

## Naval Hierarchy (Self-Organizing Crews)

The Fleet Command System operates under a naval hierarchy with **self-organizing crews** and **queue-based dispatch**.

Key capabilities by version:
- **v2.0.0** — Project-Admiralty separation: pip-only core, `.adm/` project artefacts, dual CLI (`adm`/`admiralty`), global project registry, CLAUDE.md layering
- **v1.x (legacy 9.x)** — Token usage tracking, multi-project support, managed repo lifecycle, hook system, queue-based dispatch

```
                              ┌─────────────────┐
                              │     CAPTAIN     │
                              │  (Human Owner)  │
                              └────────┬────────┘
                                       │
                              ┌────────▼────────┐
                              │  QUARTERMASTER  │
                              │ (Claude - QM)   │
                              └────────┬────────┘
                                       │
                              ┌────────▼────────┐
                              │  FLEET ADMIRAL  │
                              │(fleet-runner.py)│
                              └────────┬────────┘
                                       │
             ┌─────────┬───────────────┼───────────────┬─────────┐
             │         │               │               │         │
          ┌──▼──┐   ┌──▼──┐        ┌──▼──┐        ┌──▼──┐   ┌──▼──┐
          │Crew1│   │Crew2│        │Crew3│        │Crew4│   │Crew5│
          │Vang-│   │Stri-│        │Burs-│        │Rigg-│   │Harb-│
          │uard │   │ker  │        │ar   │        │er   │   │or   │
          └─────┘   └─────┘        └─────┘        └─────┘   └─────┘
```

Crews are dispatched from queues based on priority and dependency ordering — up to 5 concurrent crews with staggered launches.

---

## Rank Definitions

### Captain (Human Stakeholder)

**Authority Level:** SUPREME

The Captain is the ultimate authority. All strategic decisions, requirement approvals, and final sign-offs require the Captain's explicit authorization.

**Responsibilities:**
- Define strategic direction and project objectives
- Approve requirements at INCEPTION stage
- Resolve escalated blockers and escalations
- Provide final SIGNOFF on completed work
- Override any decision in the chain

**Powers:**
- Create, modify, or cancel any order
- Promote or demote priority
- Waive gates (with documentation)
- Reassign crews
- Halt operations
- Resolve blocking escalations

---

### Quartermaster (Claude - Interactive Session)

**Authority Level:** EXECUTIVE

The Quartermaster is second-in-command, responsible for translating the Captain's vision into actionable plans and tracking all requirements through the lifecycle.

**Responsibilities:**
- Planning voyages and defining order sequences
- Creating orders with correct `dependsOn` chains
- Maintaining the requirement ledger and backlog
- Process control and documentation
- High-level coordination and oversight
- Inspecting requirements for completeness
- Escalating blockers to Captain
- Resolving non-blocking escalations from crews

**Powers:**
- Create orders from approved requirements
- Assign orders to voyages with dependency chains
- Advance requirements through stages (G0–G5)
- Request Captain sign-off (G6)
- Adjust crew role assignments
- Resolve crew escalations

**Gate Responsibilities:**
- G0 (Inception): Reviews requirement capture
- G1 (Inspection): Validates acceptance criteria completeness
- G5 (QA): Reviews QA reports before sign-off request

---

### Fleet Admiral (fleet-runner.py v2.0.0 - Automated)

**Authority Level:** OPERATIONAL

The Fleet Admiral is the automated orchestrator that dispatches crews from queues, monitors fleet status, and manages the repo lifecycle. Dispatch is queue-based with dependency precedence across all 8 queue tiers.

**Responsibilities:**
- Dispatch crews from priority queues with dependency checking
- Clone target repos into crew working directories
- Monitor crew heartbeats and progress
- Handle automatic retries and restarts
- Enforce role conflict rules
- Create PRs per crew on completion
- Archive completed orders
- Post-voyage matrix update and PR creation

**Powers:**
- Start/stop crew processes
- Reassign idle crews to next queued order
- Trigger circuit breakers
- Mark orders COMPLETE, BLOCKED, or FAILED
- Hold orders with unsatisfied dependencies
- Detect and skip circular dependencies

---

### Crew (crew.py v2.0.0 - Self-Organizing Agent)

**Authority Level:** TACTICAL

Crews are autonomous agents with self-organizing capabilities. They execute tasks, create work items for other crews, and escalate decisions to Captain/QM. The Ralph Wiggum stop hook pattern provides multi-pass iterations within a single Claude invocation.

**Crew Roster:**

| Crew | Codename | Directory |
|------|----------|-----------|
| 1 | Vanguard | `.adm/crews/crew1/` |
| 2 | Striker | `.adm/crews/crew2/` |
| 3 | Bursar | `.adm/crews/crew3/` |
| 4 | Rigger | `.adm/crews/crew4/` |
| 5 | Harbormaster | `.adm/crews/crew5/` |

**Role-Based Model Selection:**

| Role | Code | Model | Focus |
|------|------|-------|-------|
| Navigator | NAV | Sonnet 4.6 | Planning & architecture |
| Shipwright | SHP | Sonnet 4.6 | Development & implementation |
| Bosun | BOS | Sonnet 4.6 | Quality assurance & testing |
| Scribe | SCR | Sonnet 4.6 | Documentation |
| Lookout | LKT | Haiku 4.5 | Security & investigation |
| Coxswain | COX | Opus 4.7 | Integration & deployment |

**Role Permissions:**

| Role | Can Create | Can Request | Can Breakdown | Can Escalate |
|------|-----------|-------------|---------------|-------------|
| NAV | Orders, Bugs | Investigation, QA | Yes | Yes |
| SHP | Bugs | Investigation, QA | No | Yes |
| BOS | Bugs, Defects | Investigation | No | Yes |
| SCR | Bugs | Investigation, QA | No | Yes |
| LKT | Bugs, Orders, Security | Planning | Yes | Yes |
| COX | Bugs, Orders | Investigation | Yes | Yes |

**Safeguards:**
- Queue depth limits: bugs(50), defects(20), security(10), breakdown(30), escalations(20)
- Per-crew rate limit: max 10 items per crew per order across all queues
- Blocking escalations halt entire voyage dispatch until Captain/QM resolves

---

## Escalation Protocol

### Level 0: Crew Self-Recovery
- Crew retries automatically (up to 3 attempts)

### Level 1: Admiral Intervention
- Triggered: After 3 crew failures
- Action: Admiral restarts crew with fresh session

### Level 2: Crew Escalation
- Triggered: Crew encounters decision requiring human input
- Action: Crew creates escalation in `queues/escalations/`
- **Non-blocking:** Informational only, other work continues
- **Blocking:** Halts ALL orders for same voyageId until resolved
- Stale alert: Dispatcher warns after 60 minutes pending

### Level 3: Quartermaster Alert
- Triggered: After 2 Admiral restarts fail, or crew escalation requires QM
- Action: QM reviews, resolves escalation or adjusts parameters

### Level 4: Captain Decision
- Triggered: QM cannot resolve OR blocker requires business decision
- Action: Captain resolves escalation JSON, dispatcher automatically unblocks

---

## Queue Priority (Dispatcher)

| Tier | Queue | Priority | Default Role |
|------|-------|----------|-------------|
| T0 | `explicit/` | Highest | from order |
| T1 | `security/` | High | SHP |
| T2 | `bugs/` | High | SHP |
| T3 | `requests/` | Medium-High | varies |
| T4 | `orders/` | Medium | varies |
| T5 | `defects/` | Medium-Low | SHP |
| T6 | `breakdown/` | Low | varies |
| T7 | `high-level/` | Lowest | NAV |
| -- | `escalations/` | NOT dispatched | Captain/QM review |

Dependency filtering applied to ALL tiers. Items with unsatisfied `dependsOn` are held regardless of priority.

---

## Hook System

Hooks provide real-time crew observability, enforcement, and usage tracking without modifying core scripts.

### Hook Architecture

| Hook | Script | Event | Purpose |
|------|--------|-------|---------|
| **Stop** | `fleet-stop-hook.py` | Claude exit | Multi-pass iterations (Ralph Wiggum) + token usage capture |
| **PostToolUse** | `fleet-posttool-hook.py` | After tool call | Activity tracking + heartbeat + file counter |
| **PreToolUse** | `fleet-pretool-hook.py` | Before write | Role permission enforcement |
| **Notification** | `fleet-notification-hook.py` | On warnings | Error/warning capture |

### Safety Design

- All hooks check `ADMIRALTY_CREW` env var first — **Captain's sessions are NEVER affected**
- All hooks fail-open: wrapped in try/except, exit(0) on any error
- All hooks use atomic writes (temp + rename) to prevent corruption
- Hook timeout: 10s (PostToolUse, PreToolUse, Notification), 30s (Stop)

### Token Usage Tracking

On crew session end (COMPLETE, BLOCKED, or MAX_ITERATIONS), the stop hook:

1. Parses the Claude Code transcript JSONL for API usage data per model
2. Calculates cost using per-model pricing (input, output, cache_creation, cache_read tokens)
3. Saves usage to `.adm/usage/orders/{ORDER-ID}.json`
4. crew.py loads usage data into order completion metadata

**Usage data per order includes:**
- Per-model token breakdown (input, output, cache_creation, cache_read)
- Message count per model
- Total tokens across all models
- Estimated cost in USD

**Aggregation and reporting:**
- `adm usage --summary` — scan all project transcripts
- `adm usage --voyage VOY-ID` — aggregate per-voyage usage

**QM-Captain Interactive Sessions:**

The stop hook only fires for crew sessions (requires `ADMIRALTY_CREW` env var). QM-Captain interactive sessions are tracked via `adm usage --summary`, which scans `~/.claude/projects/` transcript JSONL files to capture all session usage — including interactive QM-Captain conversations. This provides a complete picture of total project token expenditure across both automated crews and human-directed sessions.

**API Pricing (per million tokens):**

| Model | Input | Output | Cache Create | Cache Read |
|-------|------:|-------:|-------------:|-----------:|
| Opus 4.7 | $15.00 | $75.00 | $18.75 | $1.50 |
| Sonnet 4.6 | $3.00 | $15.00 | $3.75 | $0.30 |
| Haiku 4.5 | $0.80 | $4.00 | $1.00 | $0.08 |

### Per-Crew Runtime Files (written by hooks)

| File | Writer | Reader | Purpose |
|------|--------|--------|---------|
| `activity.txt` | PostToolUse | Fleet Monitor | Human-readable last action |
| `activity.jsonl` | PostToolUse | Debug/audit | Structured tool history |
| `heartbeat.txt` | PostToolUse | Fleet Monitor | ISO timestamp of last tool call |
| `files_modified.json` | PostToolUse | PostToolUse (dedup) | Unique files changed set |
| `ralph-state.md` | Stop hook | Fleet Monitor | Iteration count and status |
| `notifications.log` | Notification | Debug/audit | Captured warnings/errors |

### Role Permission Enforcement

- Config: `.adm/config/role-paths.json` (prohibited + allowed patterns per role)
- `allowed` overrides `prohibited` (e.g., BOS can write to `.Tests.` projects despite broad src/ prohibition)
- Uses `fnmatch` with forward-slash normalized paths
- Always-allowed: `.adm/crews/*`, `.adm/handoffs/*`, `.adm/queues/*`, `.adm/orders/*`

---

## Managed Repo Lifecycle (v2.0.0+)

The Fleet Admiral manages target repository clones for each crew:

1. **Pre-dispatch:** Clone target repo into `crews/crewN/repo/`, checkout voyage branch
2. **During execution:** Crew works in cloned repo via `ADMIRALTY_REPO_PATH` env var
3. **Post-completion:** Verify commits pushed, create/update PR for crew's work
4. **Cleanup:** Wipe crew repo clones at `--cleanup`

**Multi-repo support:** Each order can target a different repo. The dispatcher tracks per-repo voyage branches in `_SESSION_REPO_BRANCHES`.

**Multi-project support:** Project acronym injected via `ADMIRALTY_PROJECT` env var, enabling crews to resolve project-specific config at runtime.

**Environment variables injected into crew processes:**

| Variable | Purpose |
|----------|---------|
| `ADMIRALTY_CREW` | Crew instance number (1–5); activates hooks |
| `ADMIRALTY_ORDER` | Current order ID |
| `ADMIRALTY_REPO_PATH` | Managed repo clone path; crew's CWD |
| `ADMIRALTY_TEMP` | Centralized temp directory |
| `ADMIRALTY_VOYAGE_BRANCH` | Voyage branch name |
| `ADMIRALTY_MAX_ITERATIONS` | Max stop-hook iterations (default: 25) |
| `ADMIRALTY_COMPLETION_PROMISE` | Promise tag to signal task completion |

---

## Acceptance Criteria for Fleet Command Changes

Any modification to the Admiralty Fleet Command System **must** meet the following criteria before being considered complete:

### Standard Criteria
1. **Token tracking preserved** — Changes must not break the token usage capture pipeline (stop hook → usage JSON → crew.py metadata → aggregation reports)
2. **Usage data validated** — New features that add crew sessions or change session lifecycle must verify that `.adm/usage/orders/{ORDER-ID}.json` is correctly generated on session end
3. **Cost calculation accuracy** — If model assignments or pricing change, update the pricing tables in `fleet-stop-hook.py`
4. **Documentation updated** — Version bumps, new features, and behavioural changes must be reflected in CHAIN-OF-COMMAND.md and root `CLAUDE.md`
5. **Fail-open guarantee** — Token tracking must never block crew execution; all usage code must be wrapped in try/except with fail-open behaviour
6. **Captain session safety** — All hooks must check `ADMIRALTY_CREW` env var and never interfere with Captain/QM interactive sessions

### Version Bump Checklist
When bumping the Fleet Command version:
- [ ] `CHAIN-OF-COMMAND.md` header and capability timeline
- [ ] `.adm/claude.md` header and component version table
- [ ] Root `CLAUDE.md` Fleet Command System version
- [ ] `.adm/config/workspace.json` notes field
- [ ] Core script headers (`crew.py`, `fleet_runner.py`)

---

## Summary

Clear chain of command ensures:
- **Accountability**: Every action has an owner
- **Traceability**: Every decision is documented
- **Efficiency**: No confusion about authority
- **Quality**: Gates enforce standards at every level
- **Safety**: Safeguards prevent runaway queue growth
- **Dependency Ordering**: Work dispatches in correct sequence
- **Observability**: Real-time crew activity via hooks
