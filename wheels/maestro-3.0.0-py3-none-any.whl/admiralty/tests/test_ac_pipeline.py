"""
Tests for the Acceptance Criteria (AC) pipeline and adm update command.

QA order: FTR-ADM-2026-0037
Branch: admiralty/quality-gates-ac

Covers:
AC Pipeline:
1. Test order with all three validationTypes (manual, command, file-exists)
2. SHP self-check records presence in handoff doc
3. BOS validation — each AC gets explicit PASS/FAIL in acResults
4. Deliberate FAIL — BOS must NOT mark complete, must produce escalation
5. Fix failure — BOS re-validates, PASS flows to COX
6. COX gate — blocks on missing/failed AC, approves on all PASS
7. Order with NO acceptanceCriteria — backwards-compatible, no crash

adm update command:
1. Dry-run reports delta without writing
2. Apply update — role-paths.json, settings.json, claude.md updated
3. workspace.json schemaVersion bumped to 2.1.0
4. orders/, voyages/, plans/ NOT touched
5. Re-run on already-current workspace — no-op
6. --force overwrites locally-modified files
"""

from __future__ import annotations

import json
import sys
import textwrap
from io import StringIO
from pathlib import Path
from unittest import mock

import pytest

# ---------------------------------------------------------------------------
# Helpers / fixtures
# ---------------------------------------------------------------------------

def _make_workspace(tmp_path: Path, schema_version: str = "2.0.0") -> Path:
    """Scaffold a minimal .adm workspace at tmp_path."""
    adm = tmp_path / ".adm"
    (adm / "config").mkdir(parents=True)
    (adm / "orders" / "active").mkdir(parents=True)
    (adm / "orders" / "complete").mkdir(parents=True)
    (adm / "voyages" / "active").mkdir(parents=True)
    (adm / "plans").mkdir(parents=True)

    ws_json = {
        "schemaVersion": schema_version,
        "project": "TST",
        "created": "2026-01-01T00:00:00Z",
    }
    (adm / "config" / "workspace.json").write_text(
        json.dumps(ws_json, indent=2), encoding="utf-8"
    )
    return tmp_path


def _make_order(tmp_path: Path, order_id: str, acceptance_criteria=None) -> dict:
    """Create a minimal order JSON file and return the dict."""
    order = {
        "id": order_id,
        "type": "FTR",
        "title": "Test order",
        "status": "active",
    }
    if acceptance_criteria is not None:
        order["acceptanceCriteria"] = acceptance_criteria
    path = tmp_path / ".adm" / "orders" / "active" / f"{order_id}.json"
    path.write_text(json.dumps(order, indent=2), encoding="utf-8")
    return order


def _write_order(tmp_path: Path, order_id: str, order: dict, directory: str = "active") -> None:
    path = tmp_path / ".adm" / "orders" / directory / f"{order_id}.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(order, indent=2), encoding="utf-8")


def _read_order(tmp_path: Path, order_id: str, directory: str = "active") -> dict:
    path = tmp_path / ".adm" / "orders" / directory / f"{order_id}.json"
    return json.loads(path.read_text(encoding="utf-8"))


# ---------------------------------------------------------------------------
# AC Schema Tests
# ---------------------------------------------------------------------------

class TestACSchema:
    """Validate the acceptanceCriteria JSON schema and field semantics."""

    def test_all_three_validation_types_recognised(self, tmp_path):
        """An order may contain manual, command, and file-exists AC items."""
        _make_workspace(tmp_path)
        criteria = [
            {
                "id": "ac-01",
                "description": "A manual check",
                "validationType": "manual",
                "blocking": True,
            },
            {
                "id": "ac-02",
                "description": "A command check",
                "validationType": "command",
                "command": "echo hello",
                "blocking": True,
            },
            {
                "id": "ac-03",
                "description": "A file-exists check",
                "validationType": "file-exists",
                "path": ".adm/config/workspace.json",
                "blocking": False,
            },
        ]
        order = _make_order(tmp_path, "FTR-TST-0001", criteria)
        assert len(order["acceptanceCriteria"]) == 3
        types = {ac["validationType"] for ac in order["acceptanceCriteria"]}
        assert types == {"manual", "command", "file-exists"}

    def test_blocking_flag_defaults(self, tmp_path):
        """Verify blocking field is present and boolean."""
        _make_workspace(tmp_path)
        criteria = [
            {"id": "ac-01", "description": "x", "validationType": "manual", "blocking": True},
            {"id": "ac-02", "description": "y", "validationType": "manual", "blocking": False},
        ]
        order = _make_order(tmp_path, "FTR-TST-0002", criteria)
        flags = [ac["blocking"] for ac in order["acceptanceCriteria"]]
        assert flags == [True, False]

    def test_order_without_ac_field(self, tmp_path):
        """Order with no acceptanceCriteria should be well-formed."""
        _make_workspace(tmp_path)
        order = _make_order(tmp_path, "FTR-TST-0003")  # no AC
        assert "acceptanceCriteria" not in order


# ---------------------------------------------------------------------------
# BOS Validation Logic Tests
# ---------------------------------------------------------------------------

class BosValidator:
    """
    Lightweight BOS AC validation engine extracted for unit testing.
    Mirrors the logic described in admiralty/roles/bosun.md.
    """

    def __init__(self, workspace_root: Path):
        self.workspace_root = workspace_root
        self.escalations: list[str] = []

    def validate(self, order: dict) -> dict:
        """
        Run AC validation on an order dict.
        Returns the order dict with acResults populated.
        Does NOT mark order COMPLETE if any blocking criterion FAILs.
        """
        import subprocess
        import datetime

        criteria = order.get("acceptanceCriteria")
        if not criteria:
            # Backwards-compatible path: no AC field, no crash.
            return order

        results = []
        for ac in criteria:
            ac_id = ac["id"]
            vtype = ac["validationType"]
            blocking = ac.get("blocking", True)
            now = datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"

            if vtype == "file-exists":
                target = self.workspace_root / ac["path"]
                status = "PASS" if target.exists() else "FAIL"
                notes = f"{'exists' if status == 'PASS' else 'missing'}: {ac['path']}"

            elif vtype == "command":
                try:
                    result = subprocess.run(
                        ac["command"],
                        shell=True,
                        cwd=self.workspace_root,
                        capture_output=True,
                        timeout=30,
                    )
                    status = "PASS" if result.returncode == 0 else "FAIL"
                    output = (result.stdout or b"").decode(errors="replace").strip()
                    notes = output[:200] if output else f"exit={result.returncode}"
                except Exception as exc:
                    status = "SKIP"
                    notes = f"error running command: {exc}"

            elif vtype == "manual":
                # In test context, manual checks must be supplied via ac["_test_result"]
                status = ac.get("_test_result", "SKIP")
                notes = ac.get("_test_notes", "manual — BOS judgement")

            else:
                status = "SKIP"
                notes = f"unknown validationType: {vtype}"

            results.append({
                "id": ac_id,
                "status": status,
                "checkedAt": now,
                "notes": notes,
                "blocking": blocking,
            })

        order["acResults"] = results

        # Gate evaluation
        blocking_failures = [
            r for r in results if r["blocking"] and r["status"] == "FAIL"
        ]
        if blocking_failures:
            ids = ", ".join(r["id"] for r in blocking_failures)
            self.escalations.append(
                f"BLOCKING AC FAILURE(S): {ids} — order must NOT be marked COMPLETE"
            )

        return order

    @property
    def gate_passed(self) -> bool:
        return len(self.escalations) == 0


class TestBOSValidation:
    """BOS acceptance criteria validation logic."""

    def test_file_exists_pass(self, tmp_path):
        """file-exists AC PASS when target path exists."""
        _make_workspace(tmp_path)
        # workspace.json is created by _make_workspace
        criteria = [
            {
                "id": "ac-01",
                "description": "workspace.json exists",
                "validationType": "file-exists",
                "path": ".adm/config/workspace.json",
                "blocking": True,
            }
        ]
        order = {"id": "FTR-TST-0010", "acceptanceCriteria": criteria}
        validator = BosValidator(tmp_path)
        result = validator.validate(order)
        assert result["acResults"][0]["status"] == "PASS"
        assert validator.gate_passed

    def test_file_exists_fail(self, tmp_path):
        """file-exists AC FAIL when target path is absent."""
        _make_workspace(tmp_path)
        criteria = [
            {
                "id": "ac-01",
                "description": "missing file",
                "validationType": "file-exists",
                "path": ".adm/nonexistent.json",
                "blocking": True,
            }
        ]
        order = {"id": "FTR-TST-0011", "acceptanceCriteria": criteria}
        validator = BosValidator(tmp_path)
        result = validator.validate(order)
        assert result["acResults"][0]["status"] == "FAIL"
        assert not validator.gate_passed
        assert "BLOCKING AC FAILURE" in validator.escalations[0]

    def test_command_pass(self, tmp_path):
        """command AC PASS when command exits 0."""
        _make_workspace(tmp_path)
        criteria = [
            {
                "id": "ac-02",
                "description": "echo exits 0",
                "validationType": "command",
                "command": "python -c \"import sys; sys.exit(0)\"",
                "blocking": True,
            }
        ]
        order = {"id": "FTR-TST-0012", "acceptanceCriteria": criteria}
        validator = BosValidator(tmp_path)
        result = validator.validate(order)
        assert result["acResults"][0]["status"] == "PASS"
        assert validator.gate_passed

    def test_command_fail(self, tmp_path):
        """command AC FAIL when command exits non-zero."""
        _make_workspace(tmp_path)
        criteria = [
            {
                "id": "ac-02",
                "description": "exits 1",
                "validationType": "command",
                "command": "python -c \"import sys; sys.exit(1)\"",
                "blocking": True,
            }
        ]
        order = {"id": "FTR-TST-0013", "acceptanceCriteria": criteria}
        validator = BosValidator(tmp_path)
        result = validator.validate(order)
        assert result["acResults"][0]["status"] == "FAIL"
        assert not validator.gate_passed

    def test_manual_pass(self, tmp_path):
        """manual AC PASS when _test_result is injected."""
        _make_workspace(tmp_path)
        criteria = [
            {
                "id": "ac-03",
                "description": "manual review",
                "validationType": "manual",
                "blocking": True,
                "_test_result": "PASS",
                "_test_notes": "reviewed — looks good",
            }
        ]
        order = {"id": "FTR-TST-0014", "acceptanceCriteria": criteria}
        validator = BosValidator(tmp_path)
        result = validator.validate(order)
        assert result["acResults"][0]["status"] == "PASS"
        assert validator.gate_passed

    def test_all_three_types_pass(self, tmp_path):
        """All three validationTypes passing in one order."""
        _make_workspace(tmp_path)
        criteria = [
            {
                "id": "ac-01",
                "description": "manual check",
                "validationType": "manual",
                "blocking": True,
                "_test_result": "PASS",
                "_test_notes": "manually verified",
            },
            {
                "id": "ac-02",
                "description": "command check",
                "validationType": "command",
                "command": "python -c \"import sys; sys.exit(0)\"",
                "blocking": True,
            },
            {
                "id": "ac-03",
                "description": "file-exists check",
                "validationType": "file-exists",
                "path": ".adm/config/workspace.json",
                "blocking": True,
            },
        ]
        order = {"id": "FTR-TST-0015", "acceptanceCriteria": criteria}
        validator = BosValidator(tmp_path)
        result = validator.validate(order)
        statuses = [r["status"] for r in result["acResults"]]
        assert statuses == ["PASS", "PASS", "PASS"]
        assert validator.gate_passed

    def test_blocking_fail_prevents_completion(self, tmp_path):
        """Blocking FAIL must produce escalation and prevent COMPLETE."""
        _make_workspace(tmp_path)
        criteria = [
            {
                "id": "ac-01",
                "description": "will fail",
                "validationType": "file-exists",
                "path": ".adm/GHOST_FILE.json",
                "blocking": True,
            }
        ]
        order = {
            "id": "FTR-TST-0016",
            "status": "active",
            "acceptanceCriteria": criteria,
        }
        validator = BosValidator(tmp_path)
        result = validator.validate(order)

        assert result["acResults"][0]["status"] == "FAIL"
        assert not validator.gate_passed
        assert len(validator.escalations) == 1
        # Order status must NOT be changed to COMPLETE by BOS
        assert result.get("status") != "COMPLETE"

    def test_fix_and_revalidate(self, tmp_path):
        """After fixing the underlying issue, re-validation should PASS."""
        _make_workspace(tmp_path)
        ghost = tmp_path / ".adm" / "ghost.json"

        criteria = [
            {
                "id": "ac-01",
                "description": "ghost file must exist",
                "validationType": "file-exists",
                "path": ".adm/ghost.json",
                "blocking": True,
            }
        ]
        order = {"id": "FTR-TST-0017", "acceptanceCriteria": criteria}

        # First pass — FAIL
        validator = BosValidator(tmp_path)
        result = validator.validate(order)
        assert result["acResults"][0]["status"] == "FAIL"
        assert not validator.gate_passed

        # Fix the issue
        ghost.write_text("{}", encoding="utf-8")

        # Re-validate — PASS
        validator2 = BosValidator(tmp_path)
        result2 = validator2.validate(result)
        assert result2["acResults"][0]["status"] == "PASS"
        assert validator2.gate_passed

    def test_advisory_fail_does_not_block(self, tmp_path):
        """advisory (blocking=False) FAIL should NOT produce escalation."""
        _make_workspace(tmp_path)
        criteria = [
            {
                "id": "ac-advisory",
                "description": "optional check",
                "validationType": "file-exists",
                "path": ".adm/DOES_NOT_EXIST",
                "blocking": False,
            }
        ]
        order = {"id": "FTR-TST-0018", "acceptanceCriteria": criteria}
        validator = BosValidator(tmp_path)
        result = validator.validate(order)
        assert result["acResults"][0]["status"] == "FAIL"
        # No escalations because not blocking
        assert validator.gate_passed

    def test_no_ac_field_backwards_compatible(self, tmp_path):
        """Order with no acceptanceCriteria field: BOS returns order unchanged."""
        _make_workspace(tmp_path)
        order = {
            "id": "FTR-TST-0019",
            "status": "active",
        }
        validator = BosValidator(tmp_path)
        result = validator.validate(order)
        assert "acResults" not in result
        assert validator.gate_passed  # No escalations

    def test_empty_ac_array_backwards_compatible(self, tmp_path):
        """Order with empty acceptanceCriteria array: treated as no AC."""
        _make_workspace(tmp_path)
        order = {
            "id": "FTR-TST-0020",
            "status": "active",
            "acceptanceCriteria": [],
        }
        validator = BosValidator(tmp_path)
        result = validator.validate(order)
        # Empty list is falsy — no results written
        assert "acResults" not in result
        assert validator.gate_passed

    def test_ac_results_have_required_fields(self, tmp_path):
        """Each acResults entry must have id, status, checkedAt, notes."""
        _make_workspace(tmp_path)
        criteria = [
            {
                "id": "ac-01",
                "description": "check",
                "validationType": "manual",
                "blocking": True,
                "_test_result": "PASS",
                "_test_notes": "ok",
            }
        ]
        order = {"id": "FTR-TST-0021", "acceptanceCriteria": criteria}
        validator = BosValidator(tmp_path)
        result = validator.validate(order)
        entry = result["acResults"][0]
        assert "id" in entry
        assert "status" in entry
        assert "checkedAt" in entry
        assert "notes" in entry


# ---------------------------------------------------------------------------
# COX Gate Tests
# ---------------------------------------------------------------------------

class CoxGate:
    """
    Lightweight COX AC gate — mirrors the logic in admiralty/roles/coxswain.md.
    COX does NOT re-run checks. It trusts BOS-recorded acResults.
    """

    def __init__(self):
        self.blocks: list[str] = []
        self.warnings: list[str] = []

    def evaluate(self, order: dict) -> str:
        """
        Returns 'APPROVE' or 'BLOCK'.
        """
        ac_criteria = order.get("acceptanceCriteria")
        ac_results = order.get("acResults")

        if not ac_results:
            if not ac_criteria:
                # No acceptanceCriteria declared → ungated, backwards-compatible
                self.warnings.append("order is ungated (no acceptanceCriteria) — proceeding")
                return "APPROVE"
            # Criteria were declared but BOS did not record results → hard stop
            self.blocks.append("Hard stop: acceptanceCriteria declared but acResults missing/empty")
            return "BLOCK"

        blocking_failures = [
            r for r in ac_results if r.get("blocking", True) and r["status"] == "FAIL"
        ]
        if blocking_failures:
            ids = ", ".join(r["id"] for r in blocking_failures)
            self.blocks.append(f"Hard stop: blocking AC failures: {ids}")
            return "BLOCK"

        blocking_skips = [
            r for r in ac_results if r.get("blocking", True) and r["status"] == "SKIP"
        ]
        for r in blocking_skips:
            self.warnings.append(f"SKIP on blocking criterion {r['id']} — proceeding with warning")

        advisory_failures = [
            r for r in ac_results if not r.get("blocking", True) and r["status"] == "FAIL"
        ]
        for r in advisory_failures:
            self.warnings.append(f"Advisory FAIL on {r['id']} — logged, not blocking")

        return "APPROVE"


class TestCOXGate:
    """COX AC gate logic."""

    def _make_ac_result(self, ac_id: str, status: str, blocking: bool = True) -> dict:
        return {
            "id": ac_id,
            "status": status,
            "checkedAt": "2026-04-17T10:00:00Z",
            "notes": "test",
            "blocking": blocking,
        }

    def test_all_pass_approves(self):
        order = {
            "acResults": [
                self._make_ac_result("ac-01", "PASS"),
                self._make_ac_result("ac-02", "PASS"),
            ]
        }
        gate = CoxGate()
        assert gate.evaluate(order) == "APPROVE"

    def test_blocking_fail_blocks(self):
        order = {
            "acResults": [
                self._make_ac_result("ac-01", "PASS"),
                self._make_ac_result("ac-02", "FAIL", blocking=True),
            ]
        }
        gate = CoxGate()
        assert gate.evaluate(order) == "BLOCK"
        assert "ac-02" in gate.blocks[0]

    def test_advisory_fail_approves_with_warning(self):
        order = {
            "acResults": [
                self._make_ac_result("ac-01", "PASS"),
                self._make_ac_result("ac-02", "FAIL", blocking=False),
            ]
        }
        gate = CoxGate()
        assert gate.evaluate(order) == "APPROVE"
        assert any("Advisory" in w for w in gate.warnings)

    def test_blocking_skip_approves_with_warning(self):
        order = {
            "acResults": [
                self._make_ac_result("ac-01", "SKIP", blocking=True),
            ]
        }
        gate = CoxGate()
        assert gate.evaluate(order) == "APPROVE"
        assert any("SKIP" in w for w in gate.warnings)

    def test_missing_ac_results_on_ungated_order_approves(self):
        """Backwards-compatible: order without acceptanceCriteria → warn but do not block."""
        gate = CoxGate()
        assert gate.evaluate({}) == "APPROVE"
        assert gate.warnings

    def test_empty_ac_results_on_ungated_order_approves(self):
        gate = CoxGate()
        assert gate.evaluate({"acResults": []}) == "APPROVE"

    def test_missing_ac_results_on_gated_order_blocks(self):
        """Regression: order declares acceptanceCriteria but BOS did not record results → BLOCK."""
        order = {
            "acceptanceCriteria": [
                {"id": "ac-01", "description": "x", "validationType": "manual", "severity": "blocking"}
            ]
        }
        gate = CoxGate()
        assert gate.evaluate(order) == "BLOCK"
        assert gate.blocks

    def test_empty_ac_results_on_gated_order_blocks(self):
        """Regression: acceptanceCriteria declared but acResults is [] → BLOCK."""
        order = {
            "acceptanceCriteria": [
                {"id": "ac-01", "description": "x", "validationType": "manual", "severity": "blocking"}
            ],
            "acResults": [],
        }
        gate = CoxGate()
        assert gate.evaluate(order) == "BLOCK"
        assert gate.blocks


# ---------------------------------------------------------------------------
# adm update command tests
# ---------------------------------------------------------------------------

class TestAdmUpdate:
    """Tests for admiralty.update.update_workspace()."""

    def _scaffold_v200(self, tmp_path: Path) -> Path:
        """Create a v2.0.0 workspace to simulate pre-update state."""
        workspace = _make_workspace(tmp_path, schema_version="2.0.0")
        # Add some user data that must NOT be touched
        orders_dir = workspace / ".adm" / "orders" / "active"
        (orders_dir / "FTR-USR-0001.json").write_text(
            json.dumps({"id": "FTR-USR-0001", "status": "active"}), encoding="utf-8"
        )
        voyages_dir = workspace / ".adm" / "voyages" / "active"
        (voyages_dir / "VOY-USR-0001.json").write_text(
            json.dumps({"id": "VOY-USR-0001"}), encoding="utf-8"
        )
        plans_dir = workspace / ".adm" / "plans"
        (plans_dir / "NAV-USR-0001.md").write_text("# Plan", encoding="utf-8")
        return workspace

    def test_no_adm_dir_raises(self, tmp_path):
        """update_workspace raises SystemExit when no .adm/ directory exists."""
        from admiralty.update import update_workspace
        with pytest.raises(SystemExit):
            update_workspace(tmp_path)

    def test_dry_run_no_write(self, tmp_path):
        """Dry-run reports changes without writing any files."""
        workspace = self._scaffold_v200(tmp_path)
        ws_json_path = workspace / ".adm" / "config" / "workspace.json"
        original_content = ws_json_path.read_text(encoding="utf-8")

        from admiralty.update import update_workspace
        captured = StringIO()
        with mock.patch("sys.stdout", captured):
            update_workspace(workspace, dry_run=True)

        output = captured.getvalue()
        assert "Dry-run" in output or "WOULD" in output or "dry-run" in output.lower()
        # workspace.json must not be modified
        assert ws_json_path.read_text(encoding="utf-8") == original_content

    def test_dry_run_does_not_bump_version(self, tmp_path):
        """Dry-run must not change schemaVersion in workspace.json."""
        workspace = self._scaffold_v200(tmp_path)
        ws_json_path = workspace / ".adm" / "config" / "workspace.json"

        from admiralty.update import update_workspace
        with mock.patch("sys.stdout", StringIO()):
            update_workspace(workspace, dry_run=True)

        data = json.loads(ws_json_path.read_text(encoding="utf-8"))
        assert data["schemaVersion"] == "2.0.0"

    def test_apply_bumps_schema_version(self, tmp_path):
        """After update, workspace.json schemaVersion == package version."""
        from admiralty import __version__
        workspace = self._scaffold_v200(tmp_path)

        from admiralty.update import update_workspace
        with mock.patch("sys.stdout", StringIO()):
            update_workspace(workspace)

        ws_json_path = workspace / ".adm" / "config" / "workspace.json"
        data = json.loads(ws_json_path.read_text(encoding="utf-8"))
        assert data["schemaVersion"] == __version__

    def test_user_data_not_touched(self, tmp_path):
        """orders/, voyages/, plans/ content must survive update."""
        workspace = self._scaffold_v200(tmp_path)

        order_content = (workspace / ".adm" / "orders" / "active" / "FTR-USR-0001.json").read_text(encoding="utf-8")
        voyage_content = (workspace / ".adm" / "voyages" / "active" / "VOY-USR-0001.json").read_text(encoding="utf-8")
        plan_content = (workspace / ".adm" / "plans" / "NAV-USR-0001.md").read_text(encoding="utf-8")

        from admiralty.update import update_workspace
        with mock.patch("sys.stdout", StringIO()):
            update_workspace(workspace)

        assert (workspace / ".adm" / "orders" / "active" / "FTR-USR-0001.json").read_text(encoding="utf-8") == order_content
        assert (workspace / ".adm" / "voyages" / "active" / "VOY-USR-0001.json").read_text(encoding="utf-8") == voyage_content
        assert (workspace / ".adm" / "plans" / "NAV-USR-0001.md").read_text(encoding="utf-8") == plan_content

    def test_noop_when_already_current(self, tmp_path):
        """Re-running update on a current workspace is a no-op."""
        from admiralty import __version__
        workspace = _make_workspace(tmp_path, schema_version=__version__)

        from admiralty.update import update_workspace
        captured = StringIO()
        with mock.patch("sys.stdout", captured):
            update_workspace(workspace)

        output = captured.getvalue()
        assert "up to date" in output.lower() or "no change" in output.lower() or "Already" in output

    def test_settings_json_hooks_added(self, tmp_path):
        """update adds Admiralty hooks to .claude/settings.json."""
        workspace = self._scaffold_v200(tmp_path)
        settings_path = workspace / ".claude" / "settings.json"
        settings_path.parent.mkdir(parents=True, exist_ok=True)
        settings_path.write_text(json.dumps({}), encoding="utf-8")

        from admiralty.update import update_workspace
        with mock.patch("sys.stdout", StringIO()):
            update_workspace(workspace)

        settings = json.loads(settings_path.read_text(encoding="utf-8"))
        assert "hooks" in settings
        assert "Stop" in settings["hooks"] or "PreToolUse" in settings["hooks"]

    def test_hooks_not_duplicated_on_re_run(self, tmp_path):
        """Running update twice does not duplicate hook entries."""
        from admiralty import __version__
        workspace = self._scaffold_v200(tmp_path)
        settings_path = workspace / ".claude" / "settings.json"
        settings_path.parent.mkdir(parents=True, exist_ok=True)
        settings_path.write_text(json.dumps({}), encoding="utf-8")

        from admiralty.update import update_workspace

        # First run
        with mock.patch("sys.stdout", StringIO()):
            update_workspace(workspace)

        settings_after_first = json.loads(settings_path.read_text(encoding="utf-8"))

        # Bump workspace back so second run triggers (version already current, so
        # only hook check runs — we test idempotency of hook section)
        ws_json = workspace / ".adm" / "config" / "workspace.json"
        data = json.loads(ws_json.read_text(encoding="utf-8"))
        data["schemaVersion"] = "2.0.0"
        ws_json.write_text(json.dumps(data, indent=2), encoding="utf-8")

        with mock.patch("sys.stdout", StringIO()):
            update_workspace(workspace)

        settings_after_second = json.loads(settings_path.read_text(encoding="utf-8"))

        # Hook entry count must be identical
        for event in settings_after_first.get("hooks", {}):
            count_first = len(settings_after_first["hooks"][event])
            count_second = len(settings_after_second["hooks"][event])
            assert count_first == count_second, (
                f"Hook entries duplicated for event {event}: {count_first} -> {count_second}"
            )

    def test_force_overwrites_customised_claude_md(self, tmp_path):
        """--force overwrites .adm/claude.md even when no generated markers present."""
        workspace = self._scaffold_v200(tmp_path)
        claude_md = workspace / ".adm" / "claude.md"
        claude_md.write_text("# Fully custom content — no markers\n", encoding="utf-8")

        from admiralty.update import update_workspace
        with mock.patch("sys.stdout", StringIO()):
            update_workspace(workspace, force=True)

        new_content = claude_md.read_text(encoding="utf-8")
        # Content should have changed (template was applied)
        assert new_content != "# Fully custom content — no markers\n"

    def test_without_force_skips_customised_claude_md(self, tmp_path):
        """Without --force, .adm/claude.md with no markers is skipped."""
        workspace = self._scaffold_v200(tmp_path)
        claude_md = workspace / ".adm" / "claude.md"
        original = "# Fully custom content — no markers\n"
        claude_md.write_text(original, encoding="utf-8")

        from admiralty.update import update_workspace
        with mock.patch("sys.stdout", StringIO()):
            update_workspace(workspace)

        assert claude_md.read_text(encoding="utf-8") == original

    def test_role_paths_json_gets_missing_keys(self, tmp_path):
        """update adds missing keys to role-paths.json without overwriting existing."""
        workspace = self._scaffold_v200(tmp_path)
        role_paths_path = workspace / ".adm" / "config" / "role-paths.json"
        # Write a minimal role-paths file with one custom key
        existing = {"custom_key": "custom_value"}
        role_paths_path.write_text(json.dumps(existing, indent=2), encoding="utf-8")

        from admiralty.update import update_workspace, _load_default_role_paths
        defaults = _load_default_role_paths()
        if defaults is None:
            pytest.skip("No bundled role-paths-default.json — skip")

        with mock.patch("sys.stdout", StringIO()):
            update_workspace(workspace)

        updated = json.loads(role_paths_path.read_text(encoding="utf-8"))
        # Custom key preserved
        assert updated.get("custom_key") == "custom_value"
        # At least one default key added
        default_keys = set(defaults.keys())
        assert default_keys.intersection(updated.keys())
