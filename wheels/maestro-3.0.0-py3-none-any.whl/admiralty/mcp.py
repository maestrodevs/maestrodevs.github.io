"""
Admiralty MCP Registry — loader, validator, and lookup.

Provides:
  load_registry(workspace)         → dict
  validate_registry(data)          → raises McpSchemaError on invalid
  get_servers_for_role(role, ws)   → list[dict]
  validate_mcp_permissions(role, workspace) → str | None  (None = OK)
  get_active_mcp_servers(workspace)         → list[str]
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any


# ---------------------------------------------------------------------------
# Typed errors
# ---------------------------------------------------------------------------

class McpRegistryError(Exception):
    """Base for MCP registry errors."""


class McpMissingServerError(McpRegistryError):
    """Active MCP server is not in the registry."""


class McpRoleNotAllowedError(McpRegistryError):
    """Role is not permitted to use the requested server."""


class McpSchemaError(McpRegistryError):
    """Registry JSON does not match the schema."""


class McpMissingEnvError(McpRegistryError):
    """A required environment variable is not set."""


# ---------------------------------------------------------------------------
# Schema path
# ---------------------------------------------------------------------------

def _schema_path() -> Path:
    try:
        import importlib.resources as pkg_resources
        ref = pkg_resources.files("admiralty") / "config" / "mcp-servers.schema.json"
        p = Path(str(ref))
        if p.exists():
            return p
    except Exception:
        pass
    return Path(__file__).parent / "config" / "mcp-servers.schema.json"


# ---------------------------------------------------------------------------
# Registry loading
# ---------------------------------------------------------------------------

def _registry_path(workspace: Path) -> Path:
    adm_dir = workspace / ".adm" if (workspace / ".adm").is_dir() else workspace / ".admiralty"
    return adm_dir / "config" / "mcp-servers.json"


def load_registry(workspace: Path) -> dict | None:
    """
    Load the MCP registry from .adm/config/mcp-servers.json.
    Returns None if the file does not exist (permissive mode).
    Raises McpSchemaError if JSON is malformed or not a JSON object at the top
    level (downstream callers like validate_mcp_permissions assume a dict).
    """
    path = _registry_path(workspace)
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        raise McpSchemaError(f"mcp-servers.json is not valid JSON: {e}") from e
    if not isinstance(data, dict):
        raise McpSchemaError(
            "mcp-servers.json must contain a JSON object at the top level "
            f"(got {type(data).__name__})"
        )
    try:
        from admiralty.secrets.refs import resolve_secret_refs, install_log_scrub
        install_log_scrub()
        data = resolve_secret_refs(data, workspace)
    except Exception:
        pass
    return data


def validate_registry(data: dict) -> None:
    """
    Validate registry dict against mcp-servers.schema.json.
    Raises McpSchemaError with a descriptive message on failure.
    Uses jsonschema if available, falls back to manual checks.
    """
    try:
        import jsonschema  # type: ignore
        schema_path = _schema_path()
        if schema_path.exists():
            schema = json.loads(schema_path.read_text(encoding="utf-8"))
            try:
                jsonschema.validate(instance=data, schema=schema)
            except jsonschema.ValidationError as e:
                raise McpSchemaError(f"Schema validation failed: {e.message}") from e
            _check_admission_rules(data.get("servers", []))
            return
    except ImportError:
        pass

    # Manual fallback validation
    if "schemaVersion" not in data:
        raise McpSchemaError("Missing required field: schemaVersion")
    if data.get("schemaVersion") != "1.0":
        raise McpSchemaError(f"Unsupported schemaVersion: {data.get('schemaVersion')!r}")
    if "servers" not in data:
        raise McpSchemaError("Missing required field: servers")
    if not isinstance(data["servers"], list):
        raise McpSchemaError("'servers' must be an array")

    valid_roles = {"NAV", "SHP", "BOS", "SCR", "LKT", "COX", "QM"}
    valid_risks = {"low", "medium", "high", "critical"}

    for i, server in enumerate(data["servers"]):
        for field in ("name", "command", "allowed_roles"):
            if field not in server:
                raise McpSchemaError(f"Server[{i}] missing required field: {field}")
        if not server.get("name"):
            raise McpSchemaError(f"Server[{i}] 'name' must be non-empty")
        if not server.get("command"):
            raise McpSchemaError(f"Server[{i}] 'command' must be non-empty")
        ar = server["allowed_roles"]
        if ar != "*":
            if not isinstance(ar, list) or not ar:
                raise McpSchemaError(f"Server '{server['name']}' allowed_roles must be '*' or a non-empty array")
            for role in ar:
                if role not in valid_roles:
                    raise McpSchemaError(f"Server '{server['name']}' has unknown role: {role!r}")
        risk = server.get("risk_level", "medium")
        if risk not in valid_risks:
            raise McpSchemaError(f"Server '{server['name']}' has invalid risk_level: {risk!r}")

    # Enforce server-name uniqueness explicitly. JSON Schema's uniqueItems can
    # only check whole-object equality, which would let two entries with the
    # same `name` but different metadata both pass and produce ambiguous
    # lookups in get_server() / validate_mcp_permissions().
    seen_names: set[str] = set()
    for server in data["servers"]:
        name = server.get("name")
        if name in seen_names:
            raise McpSchemaError(f"Duplicate server name in registry: {name!r}")
        seen_names.add(name)

    _check_admission_rules(data["servers"])


def _check_admission_rules(servers: list[dict]) -> None:
    """Enforce risk-level admission rules from the plan (§4)."""
    for s in servers:
        name = s.get("name", "?")
        risk = s.get("risk_level", "medium")
        ar = s.get("allowed_roles", [])
        if risk == "critical":
            if not s.get("env_required"):
                raise McpSchemaError(
                    f"Server '{name}' is 'critical' but has no env_required — add required credentials"
                )
            if ar == "*":
                raise McpSchemaError(
                    f"Server '{name}' is 'critical' — allowed_roles '*' is forbidden; enumerate roles explicitly"
                )
        if risk in ("critical", "high"):
            if not s.get("description"):
                raise McpSchemaError(f"Server '{name}' is '{risk}' — 'description' is required")
            if not s.get("notes"):
                raise McpSchemaError(f"Server '{name}' is '{risk}' — 'notes' is required")


# ---------------------------------------------------------------------------
# Lookup helpers
# ---------------------------------------------------------------------------

def get_server(registry: dict, name: str) -> dict | None:
    """Return a server entry by name, or None."""
    for s in registry.get("servers", []):
        if s.get("name") == name:
            return s
    return None


def get_servers_for_role(role: str, workspace: Path) -> list[dict]:
    """Return all servers the given role is permitted to use."""
    registry = load_registry(workspace)
    if registry is None:
        return []
    return [
        s for s in registry.get("servers", [])
        if _role_allowed(role, s.get("allowed_roles", []))
    ]


def _role_allowed(role: str, allowed_roles: Any) -> bool:
    if allowed_roles == "*":
        return True
    return role in allowed_roles


# ---------------------------------------------------------------------------
# Active servers from .claude/settings.json
# ---------------------------------------------------------------------------

def get_active_mcp_servers(workspace: Path) -> list[str]:
    """Return the list of MCP server names active in .claude/settings.json."""
    settings_path = workspace / ".claude" / "settings.json"
    if not settings_path.exists():
        return []
    try:
        settings = json.loads(settings_path.read_text(encoding="utf-8"))
        return list(settings.get("mcpServers", {}).keys())
    except Exception:
        return []


# ---------------------------------------------------------------------------
# Fleet Admiral enforcement gate
# ---------------------------------------------------------------------------

def validate_mcp_permissions(
    role: str,
    workspace: Path,
    server_names: list[str] | None = None,
) -> str | None:
    """
    Returns None if the role may launch (or registry absent = permissive mode).
    Returns an error string describing the violation if blocked.

    If server_names is provided (from order mcpServers field) those are validated
    instead of the workspace-active servers from .claude/settings.json.

    Defends against malformed inputs: a registry that isn't a dict, an entry
    where allowed_roles or env_required isn't a list of strings, or a
    server_names argument that isn't list[str] all return a clear error rather
    than crash or silently bypass enforcement.
    """
    registry = load_registry(workspace)
    if registry is None:
        return None  # permissive mode — caller should log a warning
    if not isinstance(registry, dict):
        return f"mcp-servers.json is not a JSON object (got {type(registry).__name__})"

    if server_names is not None:
        if not isinstance(server_names, list) or not all(isinstance(s, str) for s in server_names):
            return "Order mcpServers must be a list of strings"
        active = server_names
    else:
        active = get_active_mcp_servers(workspace)
    if not active:
        return None

    for server_name in active:
        entry = get_server(registry, server_name)
        if entry is None:
            return f"Server '{server_name}' is active but not registered in mcp-servers.json"
        allowed = entry.get("allowed_roles", [])
        # allowed_roles may be the wildcard string "*" or a list[str]
        if not (allowed == "*" or (isinstance(allowed, list) and all(isinstance(r, str) for r in allowed))):
            return f"Server '{server_name}' has malformed allowed_roles in registry"
        if not _role_allowed(role, allowed):
            allowed_str = ", ".join(allowed) if isinstance(allowed, list) else str(allowed)
            return (
                f"Role '{role}' is not permitted to use server '{server_name}' "
                f"(allowed: {allowed_str})"
            )
        env_required = entry.get("env_required", [])
        if not (isinstance(env_required, list) and all(isinstance(v, str) for v in env_required)):
            return f"Server '{server_name}' has malformed env_required in registry"
        for env_var in env_required:
            if env_var not in os.environ:
                return (
                    f"Server '{server_name}' requires env var '{env_var}' which is not set"
                )

    return None


# ---------------------------------------------------------------------------
# Registry mutation helpers (used by CLI)
# ---------------------------------------------------------------------------

def _write_registry(workspace: Path, data: dict) -> None:
    path = _registry_path(workspace)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


def add_server(workspace: Path, entry: dict) -> None:
    """Add a server entry to the registry. Validates before writing."""
    registry = load_registry(workspace)
    if registry is None:
        registry = {
            "schemaVersion": "1.0",
            "description": "MCP server allowlist",
            "servers": [],
        }
    existing_names = {s.get("name") for s in registry.get("servers", [])}
    if entry["name"] in existing_names:
        raise McpRegistryError(f"Server '{entry['name']}' already exists. Use 'adm mcp remove' first.")
    registry.setdefault("servers", []).append(entry)
    validate_registry(registry)
    _write_registry(workspace, registry)


def remove_server(workspace: Path, name: str) -> dict:
    """Remove a server by name. Returns the removed entry."""
    registry = load_registry(workspace)
    if registry is None:
        raise McpMissingServerError(f"Registry not found — no server '{name}' to remove")
    servers = registry.get("servers", [])
    for i, s in enumerate(servers):
        if s.get("name") == name:
            removed = servers.pop(i)
            _write_registry(workspace, registry)
            return removed
    raise McpMissingServerError(f"Server '{name}' not found in registry")
