# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""
Admiralty Egress Filter — central outbound HTTP allowlist enforcement.

Enterprise feature (workspace.json: enterprise: true).
Default mode is permissive — solo users see no behavior change.

Modes:
  permissive  — no restrictions (default)
  restrictive — allowlist via dataResidency.allowedDestinations
  air-gapped  — deny all outbound except localhost / 127.0.0.1 / ::1 / Unix sockets

Usage:
    from admiralty.egress import install_egress_filter, get_session, EgressDenied
    install_egress_filter(workspace_path)   # once at startup
    session = get_session()                 # requests-compatible session
"""

from admiralty.egress.filter import (
    EgressDenied,
    EgressFilter,
    install_egress_filter,
    get_session,
    is_host_allowed,
)
from admiralty.egress.airgap import is_local, LOCAL_HOSTS
from admiralty.egress.proxy import ProxyConfig, parse_proxy_config

__all__ = [
    "EgressDenied",
    "EgressFilter",
    "install_egress_filter",
    "get_session",
    "is_host_allowed",
    "is_local",
    "LOCAL_HOSTS",
    "ProxyConfig",
    "parse_proxy_config",
]
