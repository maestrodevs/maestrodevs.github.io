"""
Identity file loader — FTR-ADM-2026-0054 / FTR-ADM-2026-0067.

FTR-ADM-2026-0067 (LKT T-1.4 / T-5.1): every identity file is verified against
the commit-based integrity guard before its contents are trusted.  Verification
is skipped when enterprise mode is disabled (workspace.json enterprise: false/absent).
"""
from __future__ import annotations

import json
from pathlib import Path

from .types import UserRecord, GroupRecord, AclEntry


def _integrity_check(path: Path, identity_dir: Path, workspace: Path) -> None:
    """Run verify_integrity when enterprise mode is active; no-op otherwise."""
    from .gate import _load_enterprise_flag
    if not _load_enterprise_flag(workspace):
        return

    # Resolve repo root (walk up to find .git)
    repo_root = workspace
    for candidate in [workspace, *workspace.parents]:
        if (candidate / ".git").exists():
            repo_root = candidate
            break

    from .integrity import verify_integrity, build_initial_manifest
    # First-time migration: build the manifest if it doesn't exist yet.
    manifest_path = identity_dir / "integrity.json"
    if not manifest_path.exists():
        build_initial_manifest(identity_dir, repo_root)

    verify_integrity(path, repo_root, identity_dir)


def _resolve_workspace(users_or_groups_dir: Path) -> tuple[Path, Path]:
    """Return (identity_dir, workspace) given a users/ or groups/ dir."""
    identity_dir = users_or_groups_dir.parent
    workspace = identity_dir.parent.parent  # .adm/identity -> .adm -> workspace
    return identity_dir, workspace


def load_user(users_dir: Path, email: str) -> UserRecord | None:
    path = users_dir / f"{email}.json"
    if not path.exists():
        return None
    identity_dir, workspace = _resolve_workspace(users_dir)
    _integrity_check(path, identity_dir, workspace)
    data = json.loads(path.read_text(encoding="utf-8"))
    return UserRecord(
        email=data["email"],
        display_name=data["displayName"],
        groups=data.get("groups", []),
        providers=data.get("providers", {}),
        public_key=data.get("publicKey"),
        enrolled_at=data.get("enrolledAt"),
        last_seen_at=data.get("lastSeenAt"),
    )


def load_group(groups_dir: Path, name: str) -> GroupRecord | None:
    path = groups_dir / f"{name}.json"
    if not path.exists():
        return None
    identity_dir, workspace = _resolve_workspace(groups_dir)
    _integrity_check(path, identity_dir, workspace)
    data = json.loads(path.read_text(encoding="utf-8"))
    return GroupRecord(
        name=data["name"],
        members=data.get("members", []),
        description=data.get("description"),
    )


def load_acl(acl_path: Path) -> list[AclEntry]:
    if not acl_path.exists():
        return []
    # acl_path is identity_dir/access.json
    identity_dir = acl_path.parent
    workspace = identity_dir.parent.parent
    _integrity_check(acl_path, identity_dir, workspace)
    data = json.loads(acl_path.read_text(encoding="utf-8"))
    return [
        AclEntry(
            principal=e["principal"],
            capability=e["capability"],
            scope=e["scope"],
        )
        for e in data.get("entries", [])
    ]


def save_user(users_dir: Path, record: UserRecord) -> None:
    users_dir.mkdir(parents=True, exist_ok=True)
    # Preserve existing _meta (restricted flag, custom dataClassification, etc.)
    existing_meta: dict = {}
    existing_path = users_dir / f"{record.email}.json"
    if existing_path.exists():
        try:
            existing_meta = json.loads(existing_path.read_text(encoding="utf-8")).get("_meta", {})
        except Exception:
            pass
    data: dict = {
        "email": record.email,
        "displayName": record.display_name,
        "groups": record.groups,
    }
    if record.providers:
        data["providers"] = record.providers
    if record.public_key:
        data["publicKey"] = record.public_key
    if record.enrolled_at:
        data["enrolledAt"] = record.enrolled_at
    if record.last_seen_at:
        data["lastSeenAt"] = record.last_seen_at
    # Always write _meta with dataClassification for GDPR compliance
    existing_meta.setdefault("dataClassification", ["email", "displayName"])
    data["_meta"] = existing_meta
    path = users_dir / f"{record.email}.json"
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    _update_manifest_if_enterprise(path, identity_dir=users_dir.parent, workspace=users_dir.parent.parent)


def save_group(groups_dir: Path, record: GroupRecord) -> None:
    groups_dir.mkdir(parents=True, exist_ok=True)
    data: dict = {"name": record.name, "members": record.members}
    if record.description:
        data["description"] = record.description
    path = groups_dir / f"{record.name}.json"
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    _update_manifest_if_enterprise(path, identity_dir=groups_dir.parent, workspace=groups_dir.parent.parent)


def save_acl(acl_path: Path, entries: list[AclEntry]) -> None:
    acl_path.parent.mkdir(parents=True, exist_ok=True)
    data = {
        "entries": [
            {"principal": e.principal, "capability": e.capability, "scope": e.scope}
            for e in entries
        ]
    }
    acl_path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    identity_dir = acl_path.parent
    _update_manifest_if_enterprise(acl_path, identity_dir=identity_dir, workspace=identity_dir.parent.parent)


def _update_manifest_if_enterprise(path: Path, identity_dir: Path, workspace: Path) -> None:
    """After a save, update the integrity manifest when enterprise mode is active."""
    from .gate import _load_enterprise_flag
    if not _load_enterprise_flag(workspace):
        return
    from .integrity import update_manifest
    update_manifest(path, identity_dir)


def list_users(users_dir: Path) -> list[UserRecord]:
    if not users_dir.exists():
        return []
    records = []
    for path in sorted(users_dir.glob("*.json")):
        try:
            identity_dir, workspace = _resolve_workspace(users_dir)
            _integrity_check(path, identity_dir, workspace)
            data = json.loads(path.read_text(encoding="utf-8"))
            records.append(UserRecord(
                email=data["email"],
                display_name=data["displayName"],
                groups=data.get("groups", []),
                providers=data.get("providers", {}),
                public_key=data.get("publicKey"),
                enrolled_at=data.get("enrolledAt"),
            ))
        except Exception:
            continue
    return records


def list_groups(groups_dir: Path) -> list[GroupRecord]:
    if not groups_dir.exists():
        return []
    records = []
    for path in sorted(groups_dir.glob("*.json")):
        try:
            identity_dir, workspace = _resolve_workspace(groups_dir)
            _integrity_check(path, identity_dir, workspace)
            data = json.loads(path.read_text(encoding="utf-8"))
            records.append(GroupRecord(
                name=data["name"],
                members=data.get("members", []),
                description=data.get("description"),
            ))
        except Exception:
            continue
    return records
