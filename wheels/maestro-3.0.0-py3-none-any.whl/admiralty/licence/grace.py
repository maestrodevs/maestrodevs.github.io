"""Pure datetime functions for offline-grace logic.

Kept separate from storage / network so it can be tested without any
filesystem or HTTP. All inputs are timezone-aware; `now` always comes
from the caller (testable).
"""

from __future__ import annotations

import os
from datetime import datetime, timedelta, timezone


GRACE_DEFAULT_DAYS = 14


def parse_iso(value: str) -> datetime:
    """Parse an ISO-8601 / RFC3339 timestamp into a timezone-aware datetime.

    `datetime.fromisoformat` rejects the trailing-`Z` form on Python 3.9
    and 3.10, but Polar (and many other APIs) emit `2027-04-29T10:00:00Z`.
    Normalise to `+00:00` before delegating; coerce naive timestamps to UTC.
    """
    if not value:
        raise ValueError("empty timestamp")
    s = value.strip()
    if s.endswith("Z") or s.endswith("z"):
        s = s[:-1] + "+00:00"
    dt = datetime.fromisoformat(s)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt


def grace_days() -> int:
    """How many days of offline grace we grant after each successful online
    validation. Read from ADMIRALTY_LICENCE_GRACE_DAYS for tests; defaults
    to 14 in production.
    """
    raw = os.environ.get("ADMIRALTY_LICENCE_GRACE_DAYS")
    if raw and raw.isdigit():
        return int(raw)
    return GRACE_DEFAULT_DAYS


def next_grace_until(now: datetime) -> datetime:
    """now + grace_days(), in UTC."""
    if now.tzinfo is None:
        now = now.replace(tzinfo=timezone.utc)
    return now + timedelta(days=grace_days())


def in_grace_window(now: datetime, grace_until_iso: str) -> bool:
    """True if `now` is at or before the recorded grace deadline."""
    if now.tzinfo is None:
        now = now.replace(tzinfo=timezone.utc)
    return now <= parse_iso(grace_until_iso)


def grace_remaining_days(now: datetime, grace_until_iso: str) -> int:
    """Days remaining (rounded down). Negative if past deadline."""
    if now.tzinfo is None:
        now = now.replace(tzinfo=timezone.utc)
    return int((parse_iso(grace_until_iso) - now).total_seconds() // 86400)
