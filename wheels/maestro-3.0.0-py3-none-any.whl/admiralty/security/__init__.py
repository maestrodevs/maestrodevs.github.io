"""
Admiralty Security Scanning — OWASP/CWE Pattern Library

Provides static analysis patterns for common security vulnerabilities,
integrated into the LKT crew session via posttool.py hook.
"""

from admiralty.security.owasp_patterns import (
    OwaspPattern,
    Finding,
    OWASPScanner,
    get_patterns,
)

__all__ = [
    "OwaspPattern",
    "Finding",
    "OWASPScanner",
    "get_patterns",
]
