#!/usr/bin/env python3
"""
Post-Voyage Verification Script
================================
Runs after all crews complete a voyage and PRs are merged to main.

1. Builds and tests all repos (or specified repos) with TRX output
2. Runs the Requirements Traceability Scanner
3. Cross-references test results with requirements
4. Generates a verification report

Usage:
    python post_voyage_verify.py                          # All repos
    python post_voyage_verify.py --repos repo-a repo-b    # Specific repos
    python post_voyage_verify.py --voyage VOY-2026-0990   # Repos touched by voyage
    python post_voyage_verify.py --skip-tests             # Scanner only (reuse existing TRX)
"""

import argparse
import glob
import json
import os
import subprocess
import sys
import xml.etree.ElementTree as ET
from collections import defaultdict
from datetime import datetime


WORKSPACE_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))


def _get_adm_dir() -> str:
    """Return .adm/ path with backward compat fallback to .admiralty/."""
    adm = os.path.join(WORKSPACE_ROOT, '.adm')
    if os.path.isdir(adm):
        return adm
    legacy = os.path.join(WORKSPACE_ROOT, '.admiralty')
    if os.path.isdir(legacy):
        import sys
        print(
            "[Admiralty] WARNING: Found legacy .admiralty/ directory. "
            "Migrate with: adm init --project <PRJ>",
            file=sys.stderr,
        )
        return legacy
    return adm


RESULTS_DIR = os.path.join(WORKSPACE_ROOT, '.adm', 'logs', 'verification')
DOCS_REPORT_DIR = os.path.join(WORKSPACE_ROOT, '.adm', 'reports')


def _load_project_registry():
    """Load the project registry for multi-project path resolution."""
    projects_file = os.path.join(_get_adm_dir(), 'config', 'projects.json')
    if os.path.exists(projects_file):
        with open(projects_file, encoding='utf-8') as f:
            return json.load(f)
    return None


def _get_repos_dir():
    """Get the repos directory, checking project registry first."""
    # Environment override
    env_repos = os.environ.get("ADMIRALTY_REPOS_DIR")
    if env_repos and os.path.isdir(env_repos):
        return env_repos
    # Default
    return os.path.join(WORKSPACE_ROOT, 'repos')


def _get_scanner_project():
    """Get the RequirementsScanner project path from project config or defaults."""
    registry = _load_project_registry()
    if registry:
        default_project = registry.get("defaultProject", "OTM")
        project_info = registry.get("projects", {}).get(default_project, {})
        config_file_rel = project_info.get("configFile", f"config/projects/{default_project}.json")
        config_path = os.path.join(_get_adm_dir(), config_file_rel)
        if os.path.exists(config_path):
            with open(config_path, encoding='utf-8') as f:
                project_config = json.load(f)
            scanner_rel = project_config.get("scannerProject")
            if scanner_rel:
                return os.path.join(WORKSPACE_ROOT, scanner_rel)
    # Fallback: legacy tools directory
    return os.path.join(WORKSPACE_ROOT, 'tools', 'RequirementsScanner')


# Resolved paths (computed once at module load)
REPOS_DIR = _get_repos_dir()
TOOLS_DIR = os.path.join(WORKSPACE_ROOT, 'tools')
SCANNER_PROJECT = _get_scanner_project()


def find_repos_with_tests(repos_dir, repo_filter=None):
    """Find all repos that have test projects."""
    repos = []
    for entry in sorted(os.listdir(repos_dir)):
        repo_path = os.path.join(repos_dir, entry)
        if not os.path.isdir(repo_path):
            continue
        if repo_filter and entry not in repo_filter:
            continue

        has_tests = False
        for root, dirs, files in os.walk(repo_path):
            depth = root.replace(repo_path, '').count(os.sep)
            if depth > 3:
                dirs.clear()
                continue
            for f in files:
                if f.endswith('.csproj') and '.Tests' in f and '.Tests.UI' not in f:
                    has_tests = True
                    break
            if has_tests:
                break

        if has_tests:
            repos.append((entry, repo_path))
    return repos


def run_tests(repos, results_dir):
    """Run dotnet test on all repos with TRX output."""
    os.makedirs(results_dir, exist_ok=True)
    results = []

    for name, path in repos:
        print(f'  Testing {name}...', end=' ', flush=True)
        try:
            result = subprocess.run(
                ['dotnet', 'test', path,
                 '--filter', 'FullyQualifiedName!~Tests.UI&FullyQualifiedName!~Tests.Integration',
                 '--logger', f'trx;LogFileName={name}.trx',
                 '--results-directory', results_dir,
                 '-v', 'q',
                 '--configuration', 'Release'],
                capture_output=True, text=True, timeout=300, cwd=path
            )

            output = result.stdout + result.stderr
            passed = failed = skipped = 0
            for line in output.split('\n'):
                if 'Passed:' in line:
                    for part in line.split(','):
                        part = part.strip()
                        if part.startswith('Passed:'):
                            passed = int(part.split(':')[1].strip())
                        elif part.startswith('Failed:'):
                            failed = int(part.split(':')[1].strip())
                        elif part.startswith('Skipped:'):
                            skipped = int(part.split(':')[1].strip())

            status = 'PASS' if result.returncode == 0 else 'FAIL'
            print(f'{status} ({passed} passed, {failed} failed)')
            results.append({
                'repo': name, 'status': status,
                'passed': passed, 'failed': failed, 'skipped': skipped
            })
        except subprocess.TimeoutExpired:
            print('TIMEOUT')
            results.append({'repo': name, 'status': 'TIMEOUT', 'passed': 0, 'failed': 0, 'skipped': 0})
        except Exception as e:
            print(f'ERROR: {e}')
            results.append({'repo': name, 'status': 'ERROR', 'passed': 0, 'failed': 0, 'skipped': 0})

    return results


def run_scanner(workspace_root, results_dir):
    """Run the Requirements Traceability Scanner."""
    json_path = os.path.join(results_dir, 'traceability.json')
    print(f'\n  Running scanner...', flush=True)

    result = subprocess.run(
        ['dotnet', 'run', '--project', SCANNER_PROJECT, '--',
         '--scan-path', os.path.join(workspace_root, 'repos'),
         '--report',
         '--json', json_path,
         '--verbose'],
        capture_output=True, text=True, timeout=600,
        cwd=workspace_root
    )

    if os.path.exists(json_path):
        print(f'  Scanner complete. JSON at: {json_path}')
        return json_path
    else:
        print(f'  Scanner failed: {result.stderr[-500:]}')
        return None


def parse_trx_files(results_dir):
    """Parse all TRX files into a test results dictionary."""
    test_results = {}
    for trx_file in glob.glob(os.path.join(results_dir, '*.trx')):
        repo = os.path.basename(trx_file).replace('.trx', '')
        try:
            tree = ET.parse(trx_file)
            root = tree.getroot()
            ns = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
            for result in root.findall('.//t:UnitTestResult', ns):
                name = result.get('testName', '')
                outcome = result.get('outcome', 'Unknown')
                test_results[f'{repo}::{name}'] = {
                    'outcome': outcome, 'repo': repo, 'name': name
                }
        except Exception:
            pass
    return test_results


def build_cross_reference(scanner_json_path, test_results):
    """Cross-reference scanner requirements with TRX test results."""
    scanner = json.load(open(scanner_json_path, encoding='utf-8'))
    req_map = {}

    for req in scanner['requirements']:
        req_id = req['id']
        tests = []
        for test_type in ['unitTests', 'integrationTests', 'acceptanceTests',
                          'uiTests', 'performanceTests', 'securityTests']:
            for test in req.get(test_type, []):
                tests.append({
                    'type': test_type,
                    'method': test.get('method', ''),
                    'class': test.get('class', ''),
                    'file': test.get('file', '')
                })

        # Match with TRX results
        matched = 0
        for t in tests:
            method = t.get('method', '')
            for key, result in test_results.items():
                if method and method in result['name']:
                    t['outcome'] = result['outcome']
                    matched += 1
                    break

        req_map[req_id] = {
            'id': req_id,
            'title': req.get('title', ''),
            'status': req.get('status', ''),
            'gates': req.get('gates', {}),
            'impl_count': len(req.get('implementations', [])),
            'test_count': len(tests),
            'tests': tests,
            'matched_count': matched
        }

    return {
        'generatedAt': datetime.now().isoformat(),
        'scannerSummary': scanner['summary'],
        'requirements': req_map
    }


def generate_report(cross_ref, test_run_results, output_path):
    """Generate markdown verification report."""
    reqs = cross_ref['requirements']
    summary = cross_ref['scannerSummary']

    by_status = defaultdict(list)
    for req_id, req in reqs.items():
        by_status[req['status']].append(req)

    by_domain = defaultdict(list)
    for req_id, req in reqs.items():
        parts = req_id.split('-')
        domain = '-'.join(parts[:2]) if len(parts) >= 2 else req_id
        by_domain[domain].append(req)

    total_passed = sum(r['passed'] for r in test_run_results)
    total_failed = sum(r['failed'] for r in test_run_results)
    repos_green = sum(1 for r in test_run_results if r['status'] == 'PASS')
    repos_total = len(test_run_results)

    lines = [
        '# Fleet Traceability and Test Verification Report',
        '',
        f'**Generated:** {datetime.now().strftime("%Y-%m-%d %H:%M")}',
        '**Branch:** main (all repos)',
        '',
        '## Test Execution Summary',
        '',
        '| Metric | Count |',
        '|--------|------:|',
        f'| Repos Tested | {repos_total} |',
        f'| Repos All-Green | {repos_green} |',
        f'| Total Tests Passed | {total_passed} |',
        f'| Total Tests Failed | {total_failed} |',
        '',
        '## Requirements Traceability',
        '',
        '| Metric | Count |',
        '|--------|------:|',
        f'| Total Requirements | {summary["totalRequirements"]} |',
        f'| With Implementation | {summary["withImplementation"]} |',
        f'| With Unit Tests | {summary["withUnitTest"]} |',
        f'| With Acceptance Tests | {summary["withAcceptanceTest"]} |',
        '',
        '## Status Breakdown',
        '',
        '| Status | Count |',
        '|--------|------:|',
    ]
    for status in sorted(by_status.keys()):
        lines.append(f'| {status} | {len(by_status[status])} |')

    lines.extend([
        '',
        '## Domain Coverage',
        '',
        '| Domain | Reqs | Impl | Tested | Coverage |',
        '|--------|:----:|:----:|:------:|:--------:|',
    ])
    for domain in sorted(by_domain.keys()):
        items = by_domain[domain]
        total = len(items)
        impl = sum(1 for r in items if r['impl_count'] > 0)
        tested = sum(1 for r in items if r['test_count'] > 0)
        pct = f'{tested/total*100:.0f}%' if total > 0 else 'N/A'
        lines.append(f'| {domain} | {total} | {impl} | {tested} | {pct} |')

    # Untested requirements
    untested = [(rid, r) for rid, r in reqs.items() if r['test_count'] == 0]
    with_tests = sum(1 for _, r in reqs.items() if r['test_count'] > 0)
    lines.extend([
        '',
        f'## Requirements Without Tests ({len(untested)} of {len(reqs)})',
        '',
        '| Requirement | Status | Implementations |',
        '|-------------|--------|:--------------:|',
    ])
    for req_id, req in sorted(untested, key=lambda x: x[0]):
        lines.append(f'| {req_id} | {req["status"]} | {req["impl_count"]} |')

    lines.extend(['', '---', '*Generated by post-voyage-verify.py*'])

    output = '\n'.join(lines)
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(output)

    return output_path


def main():
    parser = argparse.ArgumentParser(description='Post-Voyage Verification')
    parser.add_argument('--repos', nargs='*', help='Specific repos to test')
    parser.add_argument('--voyage', help='Voyage ID to find touched repos')
    parser.add_argument('--skip-tests', action='store_true', help='Skip test run, reuse existing TRX')
    parser.add_argument('--output', help='Report output path')
    args = parser.parse_args()

    os.makedirs(RESULTS_DIR, exist_ok=True)

    print('=' * 60)
    print('POST-VOYAGE VERIFICATION')
    print('=' * 60)

    # Step 1: Find repos
    repo_filter = set(args.repos) if args.repos else None
    repos = find_repos_with_tests(REPOS_DIR, repo_filter)
    print(f'\nFound {len(repos)} repos with tests')

    # Step 2: Run tests
    if not args.skip_tests:
        print('\n--- Running Tests ---')
        test_run_results = run_tests(repos, RESULTS_DIR)
    else:
        print('\n--- Skipping tests (reusing existing TRX) ---')
        test_run_results = [{'repo': name, 'status': 'SKIPPED', 'passed': 0, 'failed': 0, 'skipped': 0}
                            for name, _ in repos]

    # Step 3: Run scanner
    print('\n--- Running Traceability Scanner ---')
    scanner_json = run_scanner(WORKSPACE_ROOT, RESULTS_DIR)
    if not scanner_json:
        print('ERROR: Scanner failed. Aborting.')
        sys.exit(1)

    # Step 4: Parse TRX and cross-reference
    print('\n--- Building Cross-Reference ---')
    test_results = parse_trx_files(RESULTS_DIR)
    print(f'  Parsed {len(test_results)} test results from TRX files')
    cross_ref = build_cross_reference(scanner_json, test_results)

    # Step 5: Generate report
    print('\n--- Generating Report ---')
    report_path = args.output or os.path.join(DOCS_REPORT_DIR, 'FLEET-TEST-VERIFICATION-REPORT.md')
    generate_report(cross_ref, test_run_results, report_path)
    print(f'  Report: {report_path}')

    # Save JSON for programmatic use
    json_path = os.path.join(RESULTS_DIR, 'verification-result.json')
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump({
            'generatedAt': datetime.now().isoformat(),
            'testRun': test_run_results,
            'crossReference': cross_ref
        }, f, indent=2, ensure_ascii=True)
    print(f'  JSON:   {json_path}')

    # Summary
    total_passed = sum(r['passed'] for r in test_run_results)
    total_failed = sum(r['failed'] for r in test_run_results)
    reqs_tested = sum(1 for r in cross_ref['requirements'].values() if r['test_count'] > 0)
    reqs_total = len(cross_ref['requirements'])

    print('\n' + '=' * 60)
    print('VERIFICATION COMPLETE')
    print(f'  Tests:        {total_passed} passed, {total_failed} failed')
    print(f'  Requirements: {reqs_total} total, {reqs_tested} with tests ({reqs_tested/reqs_total*100:.1f}%)')
    print(f'  Implemented:  {cross_ref["scannerSummary"]["withImplementation"]}')
    print('=' * 60)


if __name__ == '__main__':
    main()
