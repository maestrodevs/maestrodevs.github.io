"""maestro.cli — primary entry point for mso / adm / admiralty CLI aliases."""
from __future__ import annotations

import sys
from pathlib import Path


def main() -> None:
    invoke_name = Path(sys.argv[0]).stem
    if invoke_name in ("adm", "admiralty"):
        print(
            f"[maestro] Deprecated: `{invoke_name}` is a legacy alias — use `mso` instead. "
            "This alias will be removed in v4.0.",
            file=sys.stderr,
        )
    from admiralty.cli import main as _main
    _main()
