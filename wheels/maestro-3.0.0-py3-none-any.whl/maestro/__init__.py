"""maestro — AI-orchestrated multi-agent coding for Claude Code (primary package)."""
from admiralty import __version__, __title__

__all__ = ["__version__", "__title__"]
