# Human Review Gates

> "Put a human review checkpoint between planning and implementation. Catching a wrong assumption in a three-line impact map costs far less than catching it in a pull request."
> — Captain directive 2026-05-10 (Harness Engineering framing)

## Why this exists

The Maestro dispatcher auto-advances orders through the role chain: NAV plans, SHP implements, BOS tests. Until v2.7.0, the Captain saw the work at the PR stage — **after** SHP had already spent $0.40–2.00 implementing whatever NAV planned, right or wrong.

The human review gate inserts a **structure-in, structure-out checkpoint** at the cheapest moment: immediately after NAV produces its plan, before SHP starts a single line of code.

### The ROI case

| Event | Cost |
|-------|------|
| Operator reads NAV plan (~30 seconds) | ~$0.00 |
| Operator spots wrong assumption, runs `adm review revise` | ~$0.05 (NAV re-run) |
| SHP implements a wrong-direction plan | $0.40–2.00 |
| BOS + SCR artefacts from a wrong run | Additional $0.20–0.50 |

A 30-second review of a three-line Repository Impact Map can prevent a $2.00+ wasted run. At scale, this compounds quickly. Operator review time is recorded in `adm usage` so you can see the harness-engineering ROI with receipts.

### Structure-in, structure-out principle

NAV produces a machine-readable **Repository Impact Map** alongside the free-form plan. This compresses the operator's review surface: instead of reading a full planning document, you scan:

1. Which files will change and why
2. What NAV assumed about the codebase
3. Whether the assumptions match your knowledge

If they do — approve. If one assumption is wrong — revise with a note. If the whole direction is wrong — reject and save the full SHP budget.

---

## Quick start

### 1. Enable the gate for your workspace

Create or edit `.adm/config/gates.json`:

```json
{
  "post_nav_review": {
    "enabled": true,
    "exempt_priorities": ["LOW"],
    "auto_approve_after_hours": 0
  }
}
```

Set `"enabled": true`. The gate is **off by default** — existing workspaces are unaffected until you opt in.

### 2. Dispatch as normal

```bash
adm dispatch
```

NAV runs as usual. When it completes, instead of auto-advancing to SHP, the order moves to `.adm/queues/review/` and a `NAV_REVIEW_PENDING` event fires. If you have the Slack bridge running, you'll receive a notification.

### 3. Check what's waiting for review

```bash
adm review queue
```

Output example:

```
ORDER ID              TITLE                              VOYAGE              AGE     ROLE
FTR-ADM-2026-0141     NAV plan schema — plans.py         VOY-ADM-2026-0038   12 min  NAV→SHP
FTR-ADM-2026-0099     Add export endpoint                VOY-ADM-2026-0031   4 hr    NAV→SHP
```

### 4. Inspect the plan

```bash
adm review show FTR-ADM-2026-0141
```

Opens the plan in `$EDITOR` (or prints to stdout if `$EDITOR` is unset). Focus on the **Repository Impact Map** and **Assumptions made** sections.

### 5. Approve, revise, or reject

```bash
# Looks good — advance to SHP
adm review approve FTR-ADM-2026-0141

# One assumption is wrong — send back to NAV with a note
adm review revise FTR-ADM-2026-0141 --notes "The auth module is in admiralty/auth.py not admiralty/core/auth.py — check imports"

# Completely wrong direction — halt the order
adm review reject FTR-ADM-2026-0141 --notes "This feature is already covered by FTR-0099, closing as duplicate"
```

---

## Workspace configuration

Gate behaviour is controlled by `.adm/config/gates.json`. This file is created by `adm init` using `admiralty/templates/gates.json.j2`. If the file is absent, all gates default to **off**.

### Full schema

```json
{
  "post_nav_review": {
    "enabled": false,
    "exempt_priorities": ["LOW"],
    "auto_approve_after_hours": 0
  }
}
```

### Key reference

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `post_nav_review.enabled` | boolean | `false` | Master switch for the NAV→SHP human review gate. Set to `true` to pause all orders after NAV completes. |
| `post_nav_review.exempt_priorities` | string[] | `["LOW"]` | Orders with these priority values skip the gate entirely and auto-advance to SHP. Use `[]` to gate everything. |
| `post_nav_review.auto_approve_after_hours` | number | `0` | If non-zero, orders in the review queue are automatically approved after this many hours with no operator action. `0` (default) disables auto-approve: the dispatcher waits indefinitely. |

### Tuning auto-approve

`auto_approve_after_hours: 0` is the recommended default for most workspaces. The gate exists because the operator's attention is valuable — disabling it eliminates the value.

However, for high-throughput workspaces or overnight runs where a human can't realistically review every plan, set a reasonable timeout:

```json
"auto_approve_after_hours": 8
```

This unblocks the dispatcher after a full working day without requiring operator action on every order. You'll still see `NAV_REVIEW_AUTO_APPROVED` events in the log and `adm usage` will record the review time as the full timeout duration, which accurately reflects the cost of unreviewed runs.

---

## Per-order override

The workspace default can be overridden on individual orders by adding a `gates` field to the order JSON.

### Force the gate on (even when workspace default is off)

```json
{
  "orderId": "FTR-ADM-2026-0141",
  "gates": ["nav_human_review"],
  ...
}
```

Use this when a specific order is high-stakes and you want to review NAV's plan regardless of workspace policy.

### Skip the gate (even when workspace default is on)

```json
{
  "orderId": "FTR-ADM-2026-0099",
  "gates": ["skip_nav_human_review"],
  ...
}
```

Use this for routine, well-understood orders where NAV has no meaningful scope ambiguity (e.g. a typo-fix order, a test-only order).

### Priority exemption

Orders with `priority: LOW` (or any value listed in `exempt_priorities`) skip the gate automatically. You don't need to add a `gates` override for these.

---

## CLI reference

All review commands operate on orders in `.adm/queues/review/`.

### `adm review queue`

List all orders awaiting operator review.

```bash
adm review queue
```

Columns: `ORDER ID`, `TITLE`, `VOYAGE`, `AGE`, `ROLE` (the role pair, e.g. `NAV→SHP`).

---

### `adm review show <ORDER-ID>`

Open the NAV plan for an order in your editor.

```bash
adm review show FTR-ADM-2026-0141
```

Opens `.adm/plans/PLAN-FTR-ADM-2026-0141.md` in `$EDITOR`. If `$EDITOR` is not set, prints the plan to stdout. Use `--editor vim` to override.

Focus on:
- **Repository Impact Map → Files to modify** — is the file list plausible?
- **Repository Impact Map → Symbols touched** — create/modify/delete — does that match your intent?
- **Assumptions made** — are any assumptions incorrect or outdated?

---

### `adm review approve <ORDER-ID>`

Approve the plan and advance the order to SHP.

```bash
adm review approve FTR-ADM-2026-0141
```

What happens:
1. Order moves from `.adm/queues/review/` to `.adm/queues/orders/`, with `role` set to `SHP`.
2. `NAV_REVIEW_APPROVED` lifecycle event fires.
3. `reviewedAt` and `reviewedBy` timestamps written to the order JSON.
4. `reviewTimeSeconds` written to `.adm/usage/orders/FTR-ADM-2026-0141.json`.
5. Next `adm dispatch` cycle picks up the order for SHP.

---

### `adm review revise <ORDER-ID> --notes "..."`

Send the order back to NAV with operator notes.

```bash
adm review revise FTR-ADM-2026-0141 \
  --notes "auth module is at admiralty/auth.py — check all import paths in the plan"
```

What happens:
1. Notes are appended to the order's `description` field so NAV sees them on re-run.
2. Order role is reset to `NAV` and re-queued in `.adm/queues/orders/`.
3. `NAV_REVIEW_REVISED` lifecycle event fires.
4. `reviewedAt` and `reviewedBy` timestamps written to the order JSON.
5. Next dispatch cycle re-runs NAV, which produces a revised plan.
6. When NAV completes again, the gate fires again — you'll review the updated plan.

There is no limit to the number of revise cycles. Each cycle is visible in the lifecycle log and `adm usage`.

---

### `adm review reject <ORDER-ID> --notes "..."`

Reject the order permanently.

```bash
adm review reject FTR-ADM-2026-0141 \
  --notes "Duplicate of FTR-0099 — closing"
```

What happens:
1. Notes are written to the order JSON under `rejectionReason`.
2. Order moves to `.adm/orders/failed/`.
3. `NAV_REVIEW_REJECTED` lifecycle event fires.
4. `reviewedAt` and `reviewedBy` timestamps written to the order JSON.
5. The order **never re-dispatches**. If you want to re-open the work, create a new order.

---

## Lifecycle events

These events appear in `.adm/logs/`, `adm status`, and the Slack bridge.

| Event | Trigger | Recommended action |
|-------|---------|-------------------|
| `NAV_REVIEW_PENDING` | NAV completed, gate is active, order moved to review queue | Run `adm review queue` to see what's waiting |
| `NAV_REVIEW_APPROVED` | Operator ran `adm review approve` | No action needed — SHP will pick up the order on next dispatch |
| `NAV_REVIEW_REVISED` | Operator ran `adm review revise` | No action needed — NAV will re-run on next dispatch |
| `NAV_REVIEW_REJECTED` | Operator ran `adm review reject` | Order is closed — create a new order if the work is still needed |
| `NAV_REVIEW_AUTO_APPROVED` | `auto_approve_after_hours` timeout fired | No action required, but worth reviewing the plan retrospectively to tune the threshold |
| `NAV_PLAN_SCHEMA_WARN` | NAV plan is missing `Repository Impact Map` or `Assumptions made` sections | The plan still advances (warn-only in v2.7.0) — consider `adm review revise` if the missing structure makes the plan hard to evaluate |

### Silencing Slack noise

If `NAV_REVIEW_PENDING` notifications are too frequent, use the bridge filter rules in `.adm/config/bridge-settings.json` to silence or route the event class:

```json
{
  "filters": {
    "suppress_events": ["NAV_REVIEW_AUTO_APPROVED"]
  }
}
```

See [bridge-setup-guide.md](bridge-setup-guide.md) for the full filter reference.

---

## NAV plan schema

Starting in v2.7.0, NAV crews are expected to produce plans with two machine-readable sections. The gate parser checks for these sections when evaluating whether a plan is review-ready.

### Required sections

```markdown
## Repository Impact Map

### Files to modify
- `admiralty/core/gates.py:1-80` — new gate config module

### Symbols touched
- `gate_check_post_nav()` (create)
- `dispatch_crew()` (modify) — add gate consultation after NAV completes

### Patterns to follow
- Follow the pattern in `admiralty/core/fleet_runner.py:_verify_dispatcher_branch` for config loading

## Assumptions made (spot-check before SHP runs)
- The `.adm/config/gates.json` file may not exist in all workspaces — default config should be used when absent
- `dispatch_crew()` is called once per order, synchronously — no concurrent gate checks needed
```

### v2.7.0 behaviour: warn-only

In v2.7.0, if a NAV plan is missing either required section, the dispatcher emits `NAV_PLAN_SCHEMA_WARN` and **continues normally** — the plan is not blocked. This conservative rollout lets the new schema requirement propagate across all NAV crews before enforcement begins.

If you see `NAV_PLAN_SCHEMA_WARN` frequently, inspect the plan with `adm review show` — the free-form plan may still be sufficient for your review even without the structured sections.

### v2.8.0 roadmap: promote to block

After NAV crews have reliably emitted the structured sections for an observation period, v2.8.0 will promote `NAV_PLAN_SCHEMA_WARN` to `NAV_PLAN_SCHEMA_FAIL`, which marks the order as `FAILED` and requires a manual NAV re-run with a corrected prompt.

No action is required from operators today — this is documented so you understand the trajectory.

---

## Operator workflow: a typical day

### Morning check

```bash
adm review queue
```

Scan the queue. Most days it's empty or has one or two orders. Each entry takes 30–60 seconds to review.

### Review an order

```bash
adm review show FTR-ADM-2026-0099
```

Read the **Assumptions made** section first — that's where NAV is most likely to have made a mistake. Then scan **Files to modify** to confirm the blast radius is what you expected.

If everything looks right:
```bash
adm review approve FTR-ADM-2026-0099
```

If one assumption is wrong:
```bash
adm review revise FTR-ADM-2026-0099 --notes "The config loader is in admiralty/config.py line 45, not utils.py"
```

If the whole direction is wrong:
```bash
adm review reject FTR-ADM-2026-0099 --notes "Scope changed — see updated requirements in .adm/requirements/REQ-099.md"
```

### Check review time in usage reports

```bash
adm usage --voyage VOY-ADM-2026-0038
```

Output includes:

```
Operator review time:  4 min 12 sec  (across 8 orders)
Total token cost:      $3.41
```

This is your harness-engineering dashboard: operator time invested vs. autonomous cost avoided.

---

## Edge cases

### Auto-approve timeout

When `auto_approve_after_hours` is non-zero and the operator takes no action, the dispatcher automatically approves the order and emits `NAV_REVIEW_AUTO_APPROVED`. The order advances to SHP as if the operator had approved it. The review time recorded in `adm usage` reflects the full wait duration.

**Default is 0 (disabled).** Enable only if you understand that automatic advancement without review defeats the purpose of the gate for those orders.

### Revised orders re-running NAV

When you run `adm review revise`, the order returns to NAV with your notes appended. NAV produces a new plan. The gate fires again when NAV completes — you will see another `NAV_REVIEW_PENDING` event and the order will appear in `adm review queue` again.

There is no loop prevention: if NAV continues to make the same mistake, you can keep revising. Each cycle costs the NAV token budget. After two or three revision cycles with no improvement, it may be more efficient to `reject` and manually write a more prescriptive order description.

### Rejected orders never re-dispatch

`adm review reject` moves an order to `.adm/orders/failed/` permanently. The dispatcher will not pick it up again. If the work is still needed:

1. Create a new order with a clearer description.
2. Reference the rejected order's `orderId` in the new order's `description` so NAV has the full context.

### Gate active, but no `.adm/config/gates.json`

If the file is absent, the gate defaults to **off** (`enabled: false`). The dispatcher behaves as it did before v2.7.0. This ensures backward compatibility for workspaces that haven't been updated since v2.6.x.

### Priority exemption

Orders with `priority` matching any value in `exempt_priorities` (default: `["LOW"]`) skip the gate and advance directly to SHP. This covers routine, low-stakes orders where operator review adds no value. To gate low-priority orders as well, set `"exempt_priorities": []`.

---

## Review time tracking and `adm usage`

Every review action is timestamped. When an order is approved (manually or auto), the dispatcher calculates:

```
reviewTimeSeconds = approvedAt - reviewPendingAt
```

This value is written to `.adm/usage/orders/<ORDER-ID>.json`:

```json
{
  "orderId": "FTR-ADM-2026-0141",
  "tokenCost": 0.38,
  "reviewTimeSeconds": 47,
  "reviewedBy": "captain",
  "reviewedAt": "2026-05-12T10:14:33Z"
}
```

Aggregated across a voyage:

```bash
adm usage --voyage VOY-ADM-2026-0038
```

```
VOY-ADM-2026-0038 — Human review gate NAV→SHP
  Orders completed:    6
  Total token cost:    $3.41
  Operator review:     4 min 12 sec
  Avg review/order:    42 sec
```

Use this data to tune the gate: if average review time climbs above 2–3 minutes per order, consider whether NAV's plans need a more prescriptive template or whether some order types should be exempted.

---

## See also

- [CLI-REFERENCE.md](CLI-REFERENCE.md) — full `adm` CLI reference
- [OPERATOR-GUIDE.md](OPERATOR-GUIDE.md) — day-to-day fleet operations
- [ROLES-GUIDE.md](ROLES-GUIDE.md) — role definitions (NAV, SHP, BOS, SCR, LKT, COX)
- [bridge-setup-guide.md](bridge-setup-guide.md) — Slack bridge and event filtering
- [BRANCH-DISCIPLINE.md](BRANCH-DISCIPLINE.md) — branch guard and `voyageBranch` enforcement
