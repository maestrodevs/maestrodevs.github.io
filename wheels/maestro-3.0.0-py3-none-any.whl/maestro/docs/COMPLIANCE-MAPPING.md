# Maestro — Compliance Control Mapping

> **Scope:** Maps Maestro 3.0+ enterprise features to **SOC2 Common Criteria** and **ISO/IEC 27001:2022 Annex A** controls. This document **describes** which controls each Maestro feature *supports*; it is **not** a certification, attestation, or audit opinion. Certification is the customer's responsibility on their own audit.

> **Reading guide:** "Supports" = the feature is materially relevant to satisfying the control. "Partially supports" = the feature contributes one piece of a larger control objective; the customer must add operational evidence (policies, training, vendor management) to satisfy the control fully. "Not in scope" = the control is owned entirely by the customer or another vendor in their stack.

> **Open findings caveat:** Some V6 controls have unpatched CRITICAL/HIGH findings ([SEC-FTR-ADM-2026-0064.md](../.adm/reports/security/SEC-FTR-ADM-2026-0064.md) — see the per-row caveat column). Customers should treat affected controls as "supported once patched" until the v3.0.x patch voyage ships.

---

## SOC2 Common Criteria (TSP 2017)

### CC1 — Control Environment

| Control | Name | Maestro feature | Caveat |
|---------|------|-------------------|--------|
| CC1.1 | Demonstrates commitment to integrity and ethical values | Identity model (Part 1) — every privileged action is attributable to a named human principal | Customer responsible for HR onboarding, code-of-conduct training |
| CC1.4 | Demonstrates commitment to attract, develop, and retain competent individuals | Operator separation (Part 5) — Captain / Fleet Operator / Contributor / Auditor roles enforce least-privilege staffing | Customer responsible for staff competency assessment |

### CC2 — Communication and Information

| Control | Name | Maestro feature | Caveat |
|---------|------|-------------------|--------|
| CC2.1 | Internal communication of objectives and responsibilities | Role definitions in `admiralty/roles/*.md` + ACL `access.json` make responsibility allocation explicit | — |
| CC2.2 | Internal communication of information | Audit log (Part 2) provides verifiable record of internal information flows | Open finding 2.2: truncation undetected — affects completeness claim |
| CC2.3 | External communication | `adm data-flow diagram` (Part 4) makes external communication paths explicit and auditable | — |

### CC3 — Risk Assessment

| Control | Name | Maestro feature | Caveat |
|---------|------|-------------------|--------|
| CC3.1 | Specifies suitable objectives | Threat models in [SEC-FTR-ADM-2026-0053.md](../.adm/reports/security/SEC-FTR-ADM-2026-0053.md) and [SEC-FTR-ADM-2026-0064.md](../.adm/reports/security/SEC-FTR-ADM-2026-0064.md) document risk objectives per V6 part | — |
| CC3.4 | Identifies and analyses changes that could significantly impact the system | Voyage planning artefacts (`PLAN-VOY-*.md`) + audit log of `voyage.approve` provide change-tracking | Customer responsible for change-management policy |

### CC4 — Monitoring Activities

| Control | Name | Maestro feature | Caveat |
|---------|------|-------------------|--------|
| CC4.1 | Selects, develops, and performs ongoing/separate evaluations | LKT pen-test pattern (FTR-0064 style) — built-in security review role; `adm security scan` (v2.3.0) | — |

### CC5 — Control Activities

| Control | Name | Maestro feature | Caveat |
|---------|------|-------------------|--------|
| CC5.1 | Selects and develops control activities to mitigate risks | Multi-layer controls: ACL gating, audit log, secrets scrub, egress filter | — |
| CC5.2 | Selects and develops general controls over technology | Identity integrity guard (FTR-0067), mandatory anchoring (FTR-0068), subprocess scrub (FTR-0069) | — |
| CC5.3 | Deploys control activities through policies and procedures | Operator role defaults (FTR-0062) + ACL templates | Customer responsible for organisation-specific policy |

### CC6 — Logical and Physical Access Controls

| Control | Name | Maestro feature | Caveat |
|---------|------|-------------------|--------|
| CC6.1 | Implements logical access controls | ACL capability check on every privileged `adm` command | — |
| CC6.2 | Authorises access | Identity → group → capability resolver | — |
| CC6.3 | Manages user identities | `adm identity user/group` CLI; integrity-checked storage | — |
| CC6.4 | Restricts physical access | **Not in scope** — customer infrastructure |
| CC6.5 | Removes access for terminated users | `adm identity rights restrict EMAIL` (Article 18 alignment) | Manual git-history rewrite required for full erasure |
| CC6.6 | Controls external connections | Data-residency egress filter (Part 4) | Open finding 4.1: raw socket / subprocess bypass |
| CC6.7 | Restricts and monitors data movement | Egress filter + `adm data-flow diagram` + audit log of `egress.proxied` | Open finding 4.1 |
| CC6.8 | Controls malicious code | Pre-tool secret detection (v2.3.0 VOY-0022) + OWASP scanner (v2.3.0 VOY-0024) | — |

### CC7 — System Operations

| Control | Name | Maestro feature | Caveat |
|---------|------|-------------------|--------|
| CC7.1 | Detects and monitors system components for anomalies | Audit log + `adm audit verify` | Open finding 2.2: truncation undetected |
| CC7.2 | Monitors system components | Fleet Monitor (`adm status`) + lifecycle log | — |
| CC7.3 | Evaluates security events | LKT role + `adm security scan` + audit `verify` | — |
| CC7.4 | Responds to security incidents | `adm identity rights restrict` + ACL revocation procedure | Customer responsible for IR playbook |
| CC7.5 | Recovers from security incidents | `adm backup` + `adm restore` + audit-log replay | Customer responsible for RTO/RPO targets |

### CC8 — Change Management

| Control | Name | Maestro feature | Caveat |
|---------|------|-------------------|--------|
| CC8.1 | Authorises, designs, develops, configures, documents, tests, approves, and implements changes | Voyage / order workflow + COX merge gate + audit log of `voyage.approve` and `config.modify` | — |

### CC9 — Risk Mitigation

| Control | Name | Maestro feature | Caveat |
|---------|------|-------------------|--------|
| CC9.1 | Identifies, selects, and develops risk-mitigation activities | LKT pre-implementation review pattern (FTR-0053) + post-implementation pen-test (FTR-0064) — built into voyage workflow | — |
| CC9.2 | Assesses and manages risks associated with vendors and business partners | MCP server registry (v2.3.0 VOY-0023) provides vendor-server allowlist with risk levels | Customer responsible for vendor risk assessment policy |

---

## ISO/IEC 27001:2022 Annex A

### A.5 — Organizational controls

| Control | Name | Maestro feature | Caveat |
|---------|------|-------------------|--------|
| A.5.1 | Policies for information security | **Not in scope** — customer-owned policy artefacts |
| A.5.15 | Access control | ACL `access.json` + capability gating | — |
| A.5.16 | Identity management | `adm identity` CLI + integrity-checked storage | — |
| A.5.17 | Authentication information | Secrets management (Part 3) + reference scheme | Open finding 3.1: print/subprocess scrub gaps |
| A.5.18 | Access rights | ACL granted via `adm identity assign`; revoked via `rights restrict` | — |
| A.5.34 | Privacy and protection of PII | Identity privacy (Part 6) — encryption, classification annotations, rights tooling | Customer responsible for data-residency notices, DPIA |

### A.8 — Technological controls

| Control | Name | Maestro feature | Caveat |
|---------|------|-------------------|--------|
| A.8.2 | Privileged access rights | Captain / Fleet Operator role separation | — |
| A.8.3 | Information access restriction | ACL scope (`*` / `voyage:` / `project:`) | — |
| A.8.4 | Access to source code | **Not in scope** — git server controls |
| A.8.5 | Secure authentication | Authentication delegated to attached VCS / OIDC | — |
| A.8.6 | Capacity management | **Partially supports** — `adm status` reports crew capacity; customer responsible for forecasting |
| A.8.7 | Protection against malware | Pre-tool secret detection + OWASP scanner | — |
| A.8.8 | Management of technical vulnerabilities | OWASP scanner (v2.3.0 VOY-0024) + COX security gate | Open finding 4.1 affects egress-related vulnerabilities |
| A.8.9 | Configuration management | Versioned `.adm/config/`; integrity-checked identity files | — |
| A.8.12 | Data leakage prevention | Egress filter + secrets scrub + subprocess env scrub | Open findings 3.1 + 4.1 — partial coverage until patched |
| A.8.15 | Logging | Audit log (Part 2) + lifecycle log + activity log | Open finding 2.2: truncation undetected |
| A.8.16 | Monitoring activities | Fleet Monitor + lifecycle log + `adm audit tail` | — |
| A.8.17 | Clock synchronization | **Not in scope** — relies on host OS NTP |
| A.8.20 | Network security | Data-residency egress filter | Open finding 4.1 |
| A.8.21 | Security of network services | Egress allowlist + proxy mode + air-gap mode | — |
| A.8.22 | Segregation of networks | Air-gap mode (Part 4) | — |
| A.8.23 | Web filtering | `dataResidency.allowedDestinations` glob patterns | — |
| A.8.24 | Use of cryptography | SHA-256 hash chain + HMAC signatures (audit) + provider-side encryption (secrets) | — |
| A.8.28 | Secure coding | Pre-tool secret detection + OWASP/CWE scanning + LKT review | — |
| A.8.31 | Separation of development, test, and production environments | Per-project `.adm/` workspaces + ACL `project:<acronym>` scopes | Customer responsible for environment isolation |
| A.8.32 | Change management | Voyage workflow + COX gate + audit log | — |
| A.8.33 | Test information | Test fixtures isolated under `tests/fixtures/`; secret allowlist for fixtures | — |
| A.8.34 | Protection of information systems during audit testing | LKT role isolated; audit log of `audit.read` calls | — |

### A.9 — Access control (legacy 2013 mapping)

| Control | Name | Maestro feature |
|---------|------|-------------------|
| A.9.2 | User access management | `adm identity` CLI + ACL |
| A.9.4 | System and application access control | Capability resolver |

### A.12.4 — Logging and monitoring (legacy 2013 mapping)

| Control | Name | Maestro feature | Caveat |
|---------|------|-------------------|--------|
| A.12.4.1 | Event logging | Audit log entry shape (seq, timestamp, actor, action, target, result, metadata) | Open finding 2.2 |
| A.12.4.2 | Protection of log information | Hash chain + signed entries + external anchoring | Open finding 2.2 |
| A.12.4.3 | Administrator and operator logs | Identity-attributed audit entries for all privileged actions | — |
| A.12.4.4 | Clock synchronisation | **Not in scope** — host OS NTP |

---

## How to use this document

- **Pre-procurement:** match this guide against your auditor's framework checklist; identify which controls are fully supported, partially supported, or out of scope (and therefore your responsibility).
- **During audit:** point auditors at the linked artefacts (`SEC-FTR-*.md` reports, `PLAN-VOY-*.md` documents, `audit/log.jsonl`) as direct evidence of the supporting feature.
- **Open findings:** the v3.0.x patch voyage closes the listed CRITICAL/HIGH findings. Until then, document them as known limitations in your audit narrative and apply the documented mitigations (frequent external anchoring; avoid `print()` for secret-derived values; combine egress filter with network-layer controls).
- **External review:** Maestro supports controls but does not perform certification. Engage an independent SOC2 / ISO27001 assessor.
