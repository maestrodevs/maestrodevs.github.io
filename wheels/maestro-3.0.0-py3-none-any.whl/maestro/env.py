"""maestro.env — canonical env-var reader with ADMIRALTY_* legacy fallback.

All env-var reads for MAESTRO_* names route through _env().
Legacy ADMIRALTY_* names are read as a fallback during the v3.x transition
and emit a one-time deprecation warning. Both forms will be removed in v4.0.
"""

from __future__ import annotations

import logging
import os

logger = logging.getLogger(__name__)

# Tracks which legacy-var warnings have already been emitted this process.
_warned: set[str] = set()


def warn_once(message: str) -> None:
    """Emit a deprecation warning at most once per process."""
    if message not in _warned:
        _warned.add(message)
        logger.warning(message)


def _env(name: str, legacy: str | None = None, default: str = "") -> str:
    """Read an env var, falling back to a legacy name with a deprecation warning.

    Priority:
      1. ``name``   (MAESTRO_* canonical)
      2. ``legacy`` (ADMIRALTY_* deprecated) — warns once if used
      3. ``default``
    """
    v = os.environ.get(name)
    if v is not None:
        return v
    if legacy:
        v = os.environ.get(legacy)
        if v is not None:
            warn_once(f"{legacy} is deprecated — use {name} instead (removed in v4.0)")
            return v
    return default


# ---------------------------------------------------------------------------
# Named accessors for every MAESTRO_* variable in the v3.x surface.
# Using these keeps the mapping in one place so callers don't inline the
# legacy name strings.
# ---------------------------------------------------------------------------

def sprint_branch(default: str = "") -> str:
    return _env("MAESTRO_SPRINT_BRANCH", "ADMIRALTY_VOYAGE_BRANCH", default)


def branch_guard_bypass() -> bool:
    return _env("MAESTRO_BRANCH_GUARD_BYPASS", "ADMIRALTY_BRANCH_GUARD_BYPASS") == "1"


def squad_drain_seconds(default: str = "5") -> str:
    return _env("MAESTRO_SQUAD_DRAIN_SECONDS", "ADMIRALTY_CREW_DRAIN_SECONDS", default)


def skip_auth() -> bool:
    return _env("MAESTRO_SKIP_AUTH", "ADMIRALTY_SKIP_AUTH") == "1"


def repo_path(default: str = "") -> str:
    return _env("MAESTRO_REPO_PATH", "ADMIRALTY_REPO_PATH", default)


def temp_dir(default: str = "") -> str:
    return _env("MAESTRO_TEMP", "ADMIRALTY_TEMP", default)


def slack_bot_token(default: str = "") -> str:
    return _env("MAESTRO_SLACK_BOT_TOKEN", "ADMIRALTY_SLACK_BOT_TOKEN", default)


def slack_app_token(default: str = "") -> str:
    return _env("MAESTRO_SLACK_APP_TOKEN", "ADMIRALTY_SLACK_APP_TOKEN", default)


def bridge_gist_id(default: str = "") -> str:
    return _env("MAESTRO_BRIDGE_GIST_ID", "ADMIRALTY_BRIDGE_GIST_ID", default)


def github_token(default: str = "") -> str:
    return _env("MAESTRO_GITHUB_TOKEN", "ADMIRALTY_GITHUB_TOKEN", default)
