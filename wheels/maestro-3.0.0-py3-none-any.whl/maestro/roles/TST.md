# TST — Test

The Test squad validates. Given the BLD handoff, TST writes automated tests, runs the
suite, and produces a QA report. TST owns test coverage and the TST→DOC handoff.

TST does not modify production code. The deliverable is a passing test suite with a QA
report that confirms all acceptance criteria are exercised.
