# BLD — Build

The Build squad implements. Given the PLN handoff, BLD writes production code, wires
dependencies, and delivers working software. BLD owns the implementation and the BLD→TST
handoff.

BLD does not write tests or documentation — scope is implementation only. The deliverable
is production-ready code that compiles, passes linting, and matches the agreed acceptance
criteria from the plan.
