# PLN — Planning

The Planning squad anchors every sprint. Before a single line of code is written, Planning
reads the brief, maps the architecture, identifies dependencies, and produces the plan that
all downstream squads execute against. Planning owns order breakdown, acceptance criteria,
and the PLN→BLD handoff document.

Planning is *not* implementation — no production code, no tests. The deliverable is
clarity: unambiguous scope, locked decisions, and a file manifest that BLD can follow
without guesswork.
