# SEC — Security

The Security squad audits. SEC reviews code, configuration, and dependencies for
vulnerabilities, misconfigurations, and policy violations. SEC owns security reports and
the SEC→REL handoff.

SEC does not modify production code. The deliverable is a security report with findings
ranked by severity and recommended remediations.
