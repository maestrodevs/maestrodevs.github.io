# DOC — Documentation

The Documentation squad captures knowledge. Given the completed implementation, DOC writes
user-facing docs, API references, changelogs, and in-code docstrings where needed. DOC owns
the documentation and the DOC→SEC handoff.

DOC does not modify production code or tests. The deliverable is accurate, current
documentation that reflects what was built.
