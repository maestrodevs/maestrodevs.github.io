"""maestro.workspace — workspace directory resolution with .maestro/ preferred, .adm/ fallback."""

from __future__ import annotations

import warnings
from pathlib import Path

_WARNED: set[str] = set()

_RUNTIME_DIRS = frozenset({"crews", "logs", "bridge", "temp"})

_MIGRATE_DIRS = (
    "config",
    "orders",
    "voyages",
    "plans",
    "queues",
    "handoffs",
    "reports",
    "requirements",
)


def find_workspace_dir(start: Path | None = None) -> Path | None:
    """Walk up from *start* (default: cwd) looking for a workspace dir.

    Checks for ``.maestro/config/`` first; falls back to ``.adm/config/``.
    Emits a one-time :class:`DeprecationWarning` when falling back to ``.adm/``.
    Returns the workspace directory (``.maestro/`` or ``.adm/``) or ``None``.
    """
    root = Path(start) if start is not None else Path.cwd()
    for path in [root, *root.parents]:
        maestro = path / ".maestro"
        if (maestro / "config").is_dir():
            return maestro
        adm = path / ".adm"
        if (adm / "config").is_dir():
            key = str(adm)
            if key not in _WARNED:
                _WARNED.add(key)
                warnings.warn(
                    f"Workspace found at '{adm}' (.adm/ directory). "
                    "Run `mso migrate` to upgrade to .maestro/. "
                    ".adm/ support will be removed in a future version.",
                    DeprecationWarning,
                    stacklevel=2,
                )
            return adm
    return None


def migrate_workspace(source: Path | None = None, target: Path | None = None) -> dict[str, list[str]]:
    """Copy ``.adm/`` contents to ``.maestro/``, skipping runtime dirs.

    Returns a report dict with keys ``copied``, ``skipped``, ``errors``.
    Idempotent — files already present in target are overwritten only if source
    is newer; directories are created as needed.
    """
    import shutil

    if source is None:
        ws = find_workspace_dir()
        if ws is None:
            raise FileNotFoundError("No .adm/ workspace found in current directory or any parent.")
        if ws.name != ".adm":
            raise ValueError(f"Source workspace is already .maestro/: {ws}")
        source = ws
    elif source.name != ".adm":
        raise ValueError(f"Source workspace is already .maestro/: {source}")

    if target is None:
        target = source.parent / ".maestro"

    report: dict[str, list[str]] = {"copied": [], "skipped": [], "errors": []}

    for subdir in _MIGRATE_DIRS:
        src_sub = source / subdir
        if not src_sub.exists():
            report["skipped"].append(f"{subdir}/ (not in source)")
            continue

        tgt_sub = target / subdir
        tgt_sub.mkdir(parents=True, exist_ok=True)

        for src_file in src_sub.rglob("*"):
            if not src_file.is_file():
                continue
            rel = src_file.relative_to(source)
            tgt_file = target / rel
            tgt_file.parent.mkdir(parents=True, exist_ok=True)
            try:
                shutil.copy2(src_file, tgt_file)
                report["copied"].append(str(rel))
            except Exception as exc:
                report["errors"].append(f"{rel}: {exc}")

    return report


# Legacy alias kept for callers that imported from here before the rename.
_find_adm_dir = find_workspace_dir
