#!/usr/bin/env python3
"""
Fleet PreToolUse Hook v8.1 — Role Permission Enforcement.

Prevents crews from writing files outside their role permissions.
Reads the crew's role from state.json and checks file paths against
the prohibited patterns in role-paths.json.

IMPORTANT: This hook ONLY activates for crew sessions (MAESTRO_CREW env set).
The Captain's interactive sessions are NEVER affected.

Fail-open: If role-paths.json or state.json can't be read, the operation is allowed.

Input:  JSON on stdin (from Claude Code hook system)
Output: JSON on stdout with {"decision": "deny", "reason": "..."} to block
        OR exit 0 with no output to allow
"""

import fnmatch
import json
import logging
import os
import sys
from pathlib import Path

from maestro.workspace import MSO_DIR_NAME

logger = logging.getLogger("maestro.secret_scan")


# Paths that ALL roles are allowed to write to (bypass enforcement).
# FTR-MSO-2026-0362: built from the canonical artefact-dir constant. The old
# v3.x legacy block duplicated the v4.0 entries verbatim (post-cutover both
# eras use .mso), so the list carries each pattern once.
ALWAYS_ALLOWED = [
    # v4.0 canonical (.mso — also covers v3.x post-cutover workspaces)
    *(f"{MSO_DIR_NAME}/{d}/*" for d in ("crews", "handoffs", "queues", "orders")),
    # v1.x legacy
    ".maestro/crews/*",
    ".maestro/handoffs/*",
    ".maestro/queues/*",
    ".maestro/orders/*",
]


def normalize_path(file_path: str, cwd: str) -> str:
    """Normalize a file path to forward slashes relative to project root."""
    path = file_path.replace("\\", "/")

    # Make relative to project root if absolute
    cwd_normalized = cwd.replace("\\", "/").rstrip("/")
    if path.startswith(cwd_normalized):
        path = path[len(cwd_normalized):].lstrip("/")

    return path


def is_always_allowed(rel_path: str) -> bool:
    """Check if path is in the always-allowed list."""
    for pattern in ALWAYS_ALLOWED:
        if fnmatch.fnmatch(rel_path, pattern):
            return True
    return False


def matches_pattern_list(rel_path: str, patterns: list) -> bool:
    """Check if path matches any pattern in a list."""
    for pattern in patterns:
        pattern = pattern.replace("\\", "/")
        if fnmatch.fnmatch(rel_path, pattern):
            return True
    return False


def _log_governance_event(
    workspace, crew_number: int, event: str,
    *, tool: str = "", rule: str = "", detail: str = "",
) -> None:
    """Append a governance lifecycle event to .mso/logs/lifecycle.log.

    FTR-MSO-2026-0392: makes policy denials/warnings visible in logs (AC #1).
    Best-effort — never raises, never blocks the hook. The reason string may
    include a rule id and severity but NEVER any secret payload.
    """
    try:
        if workspace is None:
            return
        from maestro.workspace import resolve_artefact_dir
        import datetime as _dt
        mso_dir = resolve_artefact_dir(Path(workspace))
        log_dir = mso_dir / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        ts = _dt.datetime.now(_dt.timezone.utc).isoformat()
        line = (
            f"{ts} | {event} | crew={crew_number} tool={tool} "
            f"rule={rule} {detail}".rstrip() + "\n"
        )
        with open(log_dir / "lifecycle.log", "a", encoding="utf-8") as lf:
            lf.write(line)
    except Exception:
        pass  # Logging must never break the guard.


def main():
    try:
        # ===================================================================
        # STEP 1: Read hook input from stdin
        # ===================================================================
        raw_input = sys.stdin.read()
        hook_input = json.loads(raw_input) if raw_input.strip() else {}
    except Exception:
        sys.exit(0)  # Can't parse — allow

    # ===================================================================
    # STEP 2: Check if this is a crew session
    # ===================================================================
    crew_str = os.environ.get("MAESTRO_CREW")
    if not crew_str:
        sys.exit(0)  # Captain's session — always allow everything

    try:
        crew_number = int(crew_str)
    except ValueError:
        sys.exit(0)

    # ===================================================================
    # STEP 1 (governance): Framework-level policy gate — FTR-MSO-2026-0392
    # ===================================================================
    # Evaluated BEFORE all existing guards. Only active in governed mode
    # (MAESTRO_GOVERNED=1 in the crew env, or governance.governedMode in
    # workspace.json). When inactive this is a no-op and every downstream
    # guard behaves exactly as before.
    #
    # FAIL-CLOSED contract (plan item (e)): in governed 'enforce' mode any
    # error while loading/evaluating policy DENIES mutating tools rather than
    # silently allowing them (unlike the legacy fail-open guards below).
    _gov_governed = False
    try:
        from maestro.governance import (
            resolve_governed_mode,
            evaluate_action,
            GovernanceError,
        )
        from maestro.governance.context import MUTATING_TOOLS as _GOV_MUTATING

        _gov_cwd = hook_input.get("cwd", os.getcwd())
        try:
            from maestro.hooks import find_mso_root
            _gov_ws = find_mso_root(_gov_cwd)
        except Exception:
            _gov_ws = None

        _gov_mode = resolve_governed_mode(_gov_ws, os.environ)
        _gov_governed = _gov_mode in ("enforce", "warn")

        if _gov_governed:
            _gov_tool = hook_input.get("tool_name", "")
            try:
                decision = evaluate_action(hook_input, _gov_ws, os.environ)
            except GovernanceError as _ge:
                # Load/integrity/schema failure. Fail CLOSED for mutating tools
                # in enforce mode; warn mode degrades to logging + allow.
                if _gov_mode == "enforce" and _gov_tool in _GOV_MUTATING:
                    _log_governance_event(
                        _gov_ws, crew_number, "POLICY_FAILCLOSED",
                        tool=_gov_tool, rule="load-error", detail=str(_ge)[:160],
                    )
                    print(json.dumps({"decision": "deny", "reason": (
                        "GOVERNANCE FAIL-CLOSED: policy could not be loaded/verified in "
                        f"governed enforce mode ({type(_ge).__name__}: {str(_ge)[:160]}). "
                        "Mutating tools are denied until the policy bundle is restored."
                    )}))
                    sys.exit(0)
                _log_governance_event(
                    _gov_ws, crew_number, "POLICY_LOAD_WARN",
                    tool=_gov_tool, rule="load-error", detail=str(_ge)[:160],
                )
            else:
                if not decision.allowed:
                    _log_governance_event(
                        _gov_ws, crew_number, "POLICY_DENY",
                        tool=_gov_tool, rule=decision.rule_id or "default",
                        detail=f"severity={decision.severity} tier={decision.tier}",
                    )
                    print(json.dumps({"decision": "deny", "reason": (
                        f"GOVERNANCE DENY [{decision.rule_id or 'default'}]: {decision.reason} "
                        f"(severity={decision.severity}). This is an org-level policy "
                        "enforced at the framework level and cannot be relaxed by local config."
                    )}))
                    sys.exit(0)
                if decision.action == "warn":
                    _log_governance_event(
                        _gov_ws, crew_number, "POLICY_WARN",
                        tool=_gov_tool, rule=decision.rule_id,
                        detail=decision.reason[:160],
                    )
    except SystemExit:
        raise
    except Exception as _gov_err:
        # An UNEXPECTED error in the gate itself (import failure, bug). Fail
        # closed for mutating tools when we already know we're governed.
        if _gov_governed:
            _tool = hook_input.get("tool_name", "")
            try:
                from maestro.governance.context import MUTATING_TOOLS as _GOV_MUTATING2
            except Exception:
                _GOV_MUTATING2 = {"Bash", "Edit", "MultiEdit", "Write", "NotebookEdit"}
            if _tool in _GOV_MUTATING2:
                print(json.dumps({"decision": "deny", "reason": (
                    "GOVERNANCE FAIL-CLOSED: governance gate errored in governed mode "
                    f"({type(_gov_err).__name__}: {str(_gov_err)[:160]}). Denying mutating tool."
                )}))
                sys.exit(0)

    # ===================================================================
    # STEP 2.5: Branch discipline (BUG-ADM-2026-0004)
    # ===================================================================
    # For Bash tool calls, refuse git/gh mutations whose target branch
    # disagrees with the order's voyageBranch. Runs before the file-path
    # check because this is a more fundamental discipline violation.
    try:
        from maestro.hooks.branch_guard import check_branch
        tool_name = hook_input.get("tool_name", "")
        tool_input = hook_input.get("tool_input", {})
        bash_command = tool_input.get("command", "") if tool_name == "Bash" else ""
        if bash_command:
            # FTR-MSO-2026-0368: pass the hook cwd so the branch guard can resolve
            # which repo (artefact vs product) a git/gh mutation targets in solo mode.
            allow, reason = check_branch(tool_name, bash_command, hook_input.get("cwd"))
            if not allow:
                print(json.dumps({"decision": "deny", "reason": reason}))
                sys.exit(0)
    except SystemExit:
        raise
    except Exception as _bg_err:
        # Audit finding M2: fail CLOSED in crew context. A guard that errors
        # while evaluating a crew's command must not silently allow it — deny
        # with a recoverable reason. Interactive/non-crew sessions (no crew env)
        # keep the belt-and-braces fail-open behaviour; worktrees remain the
        # primary isolation layer.
        if os.environ.get("MAESTRO_CREW") or os.environ.get("MAESTRO_REPO_PATH"):
            print(json.dumps({"decision": "deny", "reason": (
                "Branch guard errored while evaluating this command; denying to "
                "fail closed. Set MAESTRO_BRANCH_GUARD_BYPASS=1 in the parent "
                "shell for manual recovery. Detail: " + str(_bg_err)[:200]
            )}))
            sys.exit(0)

    # ===================================================================
    # STEP 2.6: Worktree path confinement (BUG-MSO-2026-0282)
    # ===================================================================
    # branch_guard only sees git/gh mutations; this denies Edit/Write/Bash file
    # writes whose target lands in another working tree of the same repo (the
    # main checkout or a sibling voyage worktree) instead of the crew's own
    # MAESTRO_REPO_PATH worktree. Fail-open; worktrees remain primary isolation.
    try:
        from maestro.hooks.path_guard import check_path_confinement
        tool_name = hook_input.get("tool_name", "")
        tool_input = hook_input.get("tool_input", {})
        # Pass the hook cwd so relative write targets resolve against the crew's
        # ACTUAL working directory (it may have cd'd out of its worktree), closing
        # the relative-path branch of the contamination gap.
        allow, reason = check_path_confinement(
            tool_name, tool_input, hook_input.get("cwd")
        )
        if not allow:
            print(json.dumps({"decision": "deny", "reason": reason}))
            sys.exit(0)
    except SystemExit:
        raise
    except Exception as _pg_err:
        # Audit finding M2: fail CLOSED in crew context (see branch-guard note).
        if os.environ.get("MAESTRO_CREW") or os.environ.get("MAESTRO_REPO_PATH"):
            print(json.dumps({"decision": "deny", "reason": (
                "Path guard errored while evaluating this write; denying to fail "
                "closed. Set MAESTRO_PATH_GUARD_BYPASS=1 in the parent shell for "
                "manual recovery. Detail: " + str(_pg_err)[:200]
            )}))
            sys.exit(0)

    # ===================================================================
    # STEP 2.7: Security PR gate (enterprise workspaces only)
    # Blocks gh pr create / gh pr merge when CRITICAL or HIGH scan findings
    # are present. Gated on enterprise:true in workspace.json so solo
    # workspaces are unaffected.
    # ===================================================================
    try:
        _tool_name_pr = hook_input.get("tool_name", "")
        _bash_cmd_pr = hook_input.get("tool_input", {}).get("command", "") if _tool_name_pr == "Bash" else ""
        _is_pr_op = _bash_cmd_pr and (
            "gh pr create" in _bash_cmd_pr or "gh pr merge" in _bash_cmd_pr
        )
        if _is_pr_op:
            # Check enterprise flag in workspace.json
            _enterprise_enabled = False
            try:
                from maestro.workspace import resolve_artefact_dir
                _ws_cfg = resolve_artefact_dir(Path(hook_input.get("cwd", os.getcwd()))) / ".." / "config" / "workspace.json"
                if _ws_cfg.exists():
                    _ws_data = json.loads(_ws_cfg.read_text(encoding="utf-8"))
                    _enterprise_enabled = bool(_ws_data.get("enterprise", False))
            except Exception:
                pass

            if _enterprise_enabled:
                from maestro.security.owasp_patterns import OWASPScanner, Severity
                _scan_ws = Path(hook_input.get("cwd", os.getcwd()))
                _py_files = [str(p) for p in _scan_ws.rglob("*.py") if p.exists()]
                if _py_files:
                    _scanner = OWASPScanner(language="python")
                    _findings = _scanner.scan_files(_py_files)
                    _critical_high = [
                        f for f in _findings
                        if f.severity.value in ("CRITICAL", "HIGH")
                    ]
                    if _critical_high:
                        _finding_summary = "; ".join(
                            f"{f.severity.value}: {f.title} ({f.file}:{f.line})"
                            for f in _critical_high[:5]
                        )
                        print(json.dumps({
                            "decision": "deny",
                            "reason": (
                                f"SECURITY PR GATE: {len(_critical_high)} CRITICAL/HIGH finding(s) block this PR operation. "
                                f"Run 'mso security review' for details. "
                                f"Findings: {_finding_summary}"
                            ),
                        }))
                        sys.exit(0)
                    elif any(f.severity.value in ("MEDIUM", "LOW") for f in _findings):
                        # Emit lifecycle event for medium/low — permit but log
                        try:
                            from maestro.workspace import resolve_artefact_dir as _rad
                            _adm = _rad(Path(hook_input.get("cwd", os.getcwd())))
                            _log_dir = _adm / ".." / "logs"
                            _log_dir.mkdir(parents=True, exist_ok=True)
                            import datetime as _dt_mod
                            _ts = _dt_mod.datetime.now(_dt_mod.timezone.utc).isoformat()
                            _med_count = sum(1 for f in _findings if f.severity.value in ("MEDIUM", "LOW"))
                            with open(_log_dir / "lifecycle.log", "a", encoding="utf-8") as _lf:
                                _lf.write(
                                    f"{_ts} | SECURITY_FINDINGS_LOW_MED | crew={crew_number} "
                                    f"medium_low_count={_med_count} op='{_bash_cmd_pr[:80]}'\n"
                                )
                        except Exception:
                            pass
    except SystemExit:
        raise
    except Exception:
        pass  # Fail-open on gate errors

    # ===================================================================
    # STEP 3: Get the target file path
    # ===================================================================
    tool_input = hook_input.get("tool_input", {})
    # NotebookEdit uses `notebook_path` rather than `file_path`.
    file_path = (
        tool_input.get("file_path")
        or tool_input.get("filePath")
        or tool_input.get("notebook_path")
        or ""
    )

    if not file_path:
        sys.exit(0)  # No file path — allow

    # ===================================================================
    # STEP 4: Normalize path and check always-allowed
    # ===================================================================
    cwd = hook_input.get("cwd", os.getcwd())
    from maestro.hooks import find_mso_root
    workspace = find_mso_root(cwd)
    if workspace is None:
        sys.exit(0)  # Not an Admiralty workspace — no-op
    cwd = str(workspace)
    rel_path = normalize_path(file_path, cwd)

    # ===================================================================
    # STEP 3.5: Secret scan (runs for all paths, including always-allowed)
    # ===================================================================
    try:
        from maestro.hooks.secret_patterns import Scanner

        def _extract_write_content(tname: str, tinput: dict) -> list[tuple[str, str]]:
            if tname == "Write":
                content = tinput.get("content", "")
                return [("content", content)] if content else []
            if tname == "Edit":
                new_str = tinput.get("new_string", "")
                return [("new_string", new_str)] if new_str else []
            if tname == "MultiEdit":
                results = []
                for i, edit in enumerate(tinput.get("edits", [])):
                    ns = edit.get("new_string", "")
                    if ns:
                        results.append((f"edits[{i}].new_string", ns))
                return results
            if tname == "NotebookEdit":
                # Claude Code NotebookEdit input shape:
                #   {notebook_path, cell_id, new_source, cell_type, edit_mode}
                # The cell payload is `new_source`. Older clients sometimes send
                # `cell_source` — accept either to be safe.
                new_source = tinput.get("new_source") or tinput.get("cell_source") or ""
                return [("new_source", new_source)] if new_source else []
            return []

        tool_name = hook_input.get("tool_name", "")
        write_contents = _extract_write_content(tool_name, tool_input)
        if write_contents:
            scanner = Scanner(workspace_root=workspace)
            for field_label, content in write_contents:
                matches = scanner.scan(content, field_label=field_label, rel_path=rel_path, stop_on_first=True)
                if matches:
                    hit = matches[0]
                    logger.warning(
                        "Secret scan: pattern=%s severity=%s file=%s crew=%s field=%s",
                        hit.pattern_name, hit.severity, rel_path, crew_number, field_label,
                    )
                    decision = {
                        "decision": "deny",
                        "reason": (
                            f"SECRET DETECTED: Pattern '{hit.pattern_name}' matched in "
                            f"{field_label} of {tool_name} → '{rel_path}'. "
                            f"Severity: {hit.severity}. "
                            f"The matched value has NOT been logged. "
                            f"Remove the secret and retry, or add to allowlist if this is a test fixture."
                        ),
                    }
                    print(json.dumps(decision))
                    sys.exit(0)
    except SystemExit:
        raise
    except Exception as exc:
        # Log full traceback so this fail-closed branch is diagnosable.
        # logger.exception() includes the traceback. We deliberately log only
        # the tool name, file path and crew — never any payload that could
        # contain the matched (and unredacted) secret value.
        logger.exception(
            "Secret scanner crashed (fail-closed): tool=%s file=%s crew=%s error=%s",
            hook_input.get("tool_name", "?"), rel_path, crew_number, type(exc).__name__,
        )
        decision = {
            "decision": "deny",
            "reason": (
                f"SECRET SCANNER CRASH: failing closed. "
                f"Error type: {type(exc).__name__}. Check fleet logs."
            ),
        }
        print(json.dumps(decision))
        sys.exit(0)

    if is_always_allowed(rel_path):
        sys.exit(0)  # Always-allowed path — bypass role enforcement

    # ===================================================================
    # STEP 5: Get crew's role from state.json
    # ===================================================================
    from maestro.workspace import resolve_artefact_dir
    _mso_root = resolve_artefact_dir(Path(cwd))
    crew_dir = _mso_root / "crews" / f"crew{crew_number}"
    state_file = crew_dir / "state.json"

    if not state_file.exists():
        sys.exit(0)  # No state — fail-open

    try:
        state = json.loads(state_file.read_text(encoding='utf-8'))
    except Exception:
        sys.exit(0)  # Can't read state — fail-open

    role = state.get("role", "")
    if not role:
        sys.exit(0)  # No role — fail-open

    # ===================================================================
    # STEP 6: Load role-paths.json and get prohibited patterns
    # ===================================================================
    role_paths_file = _mso_root / "config" / "role-paths.json"

    if not role_paths_file.exists():
        sys.exit(0)  # No config — fail-open

    try:
        config = json.loads(role_paths_file.read_text(encoding='utf-8'))
    except Exception:
        sys.exit(0)  # Can't parse config — fail-open

    role_config = config.get("roles", {}).get(role, {})
    prohibited = role_config.get("prohibited", {})
    prohibited_paths = prohibited.get("paths", [])
    prohibited_reason = prohibited.get("reason", "Permission denied by role")

    if not prohibited_paths:
        sys.exit(0)  # No prohibitions — allow

    # ===================================================================
    # STEP 6b: Load allowed override patterns (allowed wins over prohibited)
    # ===================================================================
    allowed = role_config.get("allowed", {})
    allowed_paths = allowed.get("paths", [])

    # ===================================================================
    # STEP 7: Check file against prohibited patterns (with allowed override)
    # ===================================================================
    if matches_pattern_list(rel_path, prohibited_paths):
        # Check if an allowed pattern overrides the prohibition
        if matches_pattern_list(rel_path, allowed_paths):
            sys.exit(0)  # Allowed override — permit despite prohibition
        role_name = role_config.get("roleName", role)
        filename = Path(file_path).name
        decision = {
            "decision": "deny",
            "reason": (
                f"ROLE ENFORCEMENT: {role} ({role_name}) cannot write to '{filename}'. "
                f"{prohibited_reason}. "
                f"Matched prohibited pattern for path: {rel_path}"
            )
        }
        print(json.dumps(decision))
        sys.exit(0)

    # Allowed
    sys.exit(0)


if __name__ == "__main__":
    try:
        main()
    except Exception:
        sys.exit(0)  # Fail-open: never block on hook errors
