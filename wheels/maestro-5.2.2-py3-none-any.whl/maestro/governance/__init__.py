"""
maestro.governance — framework-level policy enforcement (governed mode).

FTR-MSO-2026-0392 (PLAN-PLN-MSO-2026-0372 Phase 1).

Public API:
  * ``evaluate``            — pure engine ``(policy, context) -> Decision``
  * ``load_policy``         — discover + integrity-verify + merge bundles
  * ``build_context``       — build an EvalContext from a hook payload
  * ``evaluate_action``     — high-level convenience used by the pretool hook
  * ``is_governed`` / ``resolve_governed_mode`` — activation helpers
  * ``GovernanceError``     — fail-closed signal for governed mode
  * ``Decision`` / ``MergedPolicy`` / ``EvalContext`` — data types

Design invariants (see PLAN-PLN-MSO-2026-0372 "Notes for Builder"):
  * The engine is deterministic and side-effect-free (CI-reusable, Phase 5).
  * In governed ``enforce`` mode, any governance-eval error FAILS CLOSED —
    mutating tools are denied, never silently allowed.
  * Governance is OFF by default; when inactive, existing guards are unchanged.
"""
from __future__ import annotations

import json
import os
from pathlib import Path

from maestro.governance.schema import (
    GovernanceError,
    PolicyBundle,
    PolicyRule,
    validate_bundle_dict,
)
from maestro.governance.context import (
    EvalContext,
    MUTATING_TOOLS,
    build_context,
)
from maestro.governance.engine import (
    Decision,
    MergedPolicy,
    evaluate,
)
from maestro.governance.loader import (
    build_library_manifest,
    load_bundles,
    load_builtin_bundles,
    load_policy,
)

__all__ = [
    "GovernanceError",
    "PolicyBundle",
    "PolicyRule",
    "validate_bundle_dict",
    "EvalContext",
    "MUTATING_TOOLS",
    "build_context",
    "Decision",
    "MergedPolicy",
    "evaluate",
    "load_policy",
    "load_bundles",
    "load_builtin_bundles",
    "build_library_manifest",
    "evaluate_action",
    "is_governed",
    "resolve_governed_mode",
    "GOVERNED_ENV",
]

# The env var the dispatcher stamps into a governed crew subprocess. Its
# presence (value "1") is the primary fail-closed contract the pretool hook
# keys on. (Plan item (e).)
GOVERNED_ENV = "MAESTRO_GOVERNED"


def resolve_governed_mode(workspace: Path | None, env: dict | None = None) -> str:
    """Resolve the effective governed mode: "enforce" | "warn" | "off".

    Resolution order:
      1. ``MAESTRO_GOVERNED`` env var — "1"/"enforce" => enforce, "warn" => warn,
         "0"/"off"/unset => defer to config.
      2. ``workspace.json`` ``governance.governedMode`` (default "off").

    The env var is authoritative when it forces governance ON (the dispatcher
    sets it for governed crews); it never silently turns governance OFF when the
    config asks for enforcement.
    """
    env = env if env is not None else os.environ
    raw = (env.get(GOVERNED_ENV) or "").strip().lower()
    if raw in ("1", "enforce", "true", "yes"):
        return "enforce"
    if raw == "warn":
        return "warn"

    # Fall back to workspace config. `workspace` may be the repo root (holding
    # a `.mso/` dir) or the `.mso` artefact dir itself — accept either.
    if workspace is not None:
        ws = Path(workspace)
        candidates = [
            ws / ".mso" / "config" / "workspace.json",
            ws / "config" / "workspace.json",
        ]
        cfg_path = next((c for c in candidates if c.exists()), None)
        try:
            if cfg_path is not None:
                data = json.loads(cfg_path.read_text(encoding="utf-8"))
                mode = (data.get("governance", {}) or {}).get("governedMode", "off")
                if mode in ("enforce", "warn", "off"):
                    return mode
        except Exception:
            # A broken workspace.json must not silently disable governance when
            # the env var already forced it on (handled above). Here the env var
            # did NOT force it on, so defaulting to "off" preserves the
            # "inactive => existing behaviour unchanged" acceptance criterion.
            return "off"
    return "off"


def is_governed(workspace: Path | None = None, env: dict | None = None) -> bool:
    """True when governed mode is enforce or warn (i.e. STEP 1 should run)."""
    return resolve_governed_mode(workspace, env) != "off"


def evaluate_action(
    hook_input: dict,
    workspace: Path | None = None,
    env: dict | None = None,
    *,
    verify: bool = True,
) -> Decision:
    """High-level: build context, load+verify policy, evaluate. Raises on load failure.

    The pretool hook wraps this in fail-closed handling: a GovernanceError (or
    any exception) in governed mode denies mutating tools rather than allowing.
    """
    env = env if env is not None else os.environ
    ctx = build_context(hook_input, env)
    policy = load_policy(workspace, verify=verify)
    return evaluate(policy, ctx)
