#!/usr/bin/env python3
"""
Maestro - Parallel Fleet Runner v2.0.0

Features:
- Pre-flight checks (clean state before starting)
- Rogue process detection and cleanup
- Stale state file cleanup
- Robust process tracking via PID files (no parent-child handles)
- Graceful shutdown handling
- WAVE SEQUENCING - Auto-promotes through waves when crews complete
- Bell ringing on voyage completion
- v5.0: Compatible with self-organizing crews and queue system
- v5.1: STAGGERED CREW LAUNCHES - configurable delay between crew starts
- v5.2: AUTO-DISPATCHER - Watches queues and auto-dispatches idle crews
        Priority: requests first, then orders. Never exceeds max concurrent crews.
- v6.0: INDEPENDENT PROCESS LAUNCH - Crews launch as fully detached processes
        (CREATE_NEW_CONSOLE | CREATE_NEW_PROCESS_GROUP).
        No CLI lock needed. Restores 5-crew concurrent capability.
- v7.0: DEPENDENCY-AWARE DISPATCH - 8-tier priority queues, escalation handling
- v7.3: TIMEOUT BRIEFING - captures iteration state on timeout, re-feeds to next crew
- v8.0: STOP HOOK ITERATION CONTROL - crew.py uses python -m admiralty.hooks.stop (Ralph Wiggum
        pattern) for multi-pass iterations. Single Claude invocation per order.
        Hook intercepts Claude's natural exit and re-feeds prompts.
        Per-crew ralph-state.md tracks iteration count and status.
- v8.2: ROLE SEQUENCE GATES - Automatic enforcement of role ordering per voyage.
        Reads roleSequence from order templates, checks voyage-level completion
        status before dispatching. Quality gates (BOS/QA) can never be skipped.
        Usage: python fleet-runner.py --validate-sequences (dry-run check)
- v8.3: REQUIREMENTS TRACEABILITY GATE - QM can run scanner pre-flight or post-voyage.
        Usage: python fleet-runner.py --validate-traceability
        Runs: dotnet run --project Uplifted/Tools/RequirementsScanner -- --gate --min-coverage 80
- v8.6: DISPATCH LOG FIXES + POST-VOYAGE MATRIX UPDATE
        Fixed: priority showing '?' (wrong field name sort_priority→priority)
        Fixed: order title showing 'Unknown' (queue JSONs use orderId, no title field)
        Fixed: order ID resolution (orderId→id→filename fallback chain)
        Added: Post-voyage auto-refresh of REQUIREMENTS-MATRIX.md via update-matrix.py
- v8.13: POST-VOYAGE AUTO-PR CREATION
        Scans completed orders at Eight Bells, collects unique targetRepo values,
        creates PRs from voyage branch to main for each repo that had work done.
        Usage: automatic at Eight Bells, or manual: python fleet-runner.py --create-prs
- v2.0.0: MANAGED REPO LIFECYCLE
        Pre-dispatch: clone target repo into crews/crewN/repo/, checkout voyage branch.
        Post-completion: verify commits pushed, auto-commit uncommitted changes.
        Per-crew PR: create/update PR immediately when each crew completes.
        Cleanup: wipe crew repo clones, reset repos/ to main at Eight Bells.
        Env vars: ADMIRALTY_REPO_PATH injected into crew processes.
"""

import argparse
import atexit
import json
import os
import re
import shutil
import signal
import subprocess
from admiralty.launch.sandbox import spawn as _spawn
from admiralty.core.gates import load_gate_config, gate_check_post_nav, should_auto_approve
from maestro.personas import current_persona
import sys
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, Any, Optional, List

# Windows-specific process creation flags
if os.name == 'nt':
    CREATE_NEW_CONSOLE = 0x00000010
    DETACHED_PROCESS = 0x00000008
    CREATE_NEW_PROCESS_GROUP = 0x00000200

# Enable Windows console colors and UTF-8 output
if os.name == 'nt':
    os.system('chcp 65001 >nul 2>&1')
    os.system('')
    # Fix Python stdout/stderr encoding for Windows consoles (prevents charmap errors)
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    if hasattr(sys.stderr, 'reconfigure'):
        sys.stderr.reconfigure(encoding='utf-8', errors='replace')

CREW_NAMES = {1: "Vanguard", 2: "Striker", 3: "Bursar", 4: "Rigger", 5: "Harbormaster"}

# v8.7: Role-model mapping (mirrors crew.py ROLE_MODELS) for dispatcher display
ROLE_MODELS = {
    "COX": "Opus", "NAV": "Sonnet", "SHP": "Sonnet",
    "BOS": "Sonnet", "SCR": "Sonnet", "LKT": "Haiku",
}

# v2.1: Canonical role codes (PLN/BLD/TST/DOC/SEC/REL/LEAD).
# Legacy nautical codes still accepted through v3.x — resolved here with a one-time WARN.
LEGACY_ROLE_ALIASES: Dict[str, str] = {
    "NAV": "PLN",
    "SHP": "BLD",
    "BOS": "TST",
    "SCR": "DOC",
    "LKT": "SEC",
    "COX": "REL",
    "QM":  "LEAD",
}
_LEGACY_ROLE_WARN_EMITTED: set = set()


def resolve_role_code(role: str) -> str:
    """Resolve a legacy nautical role code to its canonical equivalent.

    Returns the canonical code unchanged if already canonical; emits a
    deprecation WARN on first use of each legacy code.
    """
    canonical = LEGACY_ROLE_ALIASES.get(role)
    if canonical is None:
        return role
    if role not in _LEGACY_ROLE_WARN_EMITTED:
        _LEGACY_ROLE_WARN_EMITTED.add(role)
        print(f"[{current_persona().term('product')}] WARN: role code '{role}' is deprecated — use '{canonical}' (legacy alias supported through v3.x)")
    return canonical

# Active voyage branch — set from ADMIRALTY_VOYAGE_BRANCH env var
# Injected into all crew process environments so crews know where to push commits.
ACTIVE_VOYAGE_BRANCH: str = os.environ.get("ADMIRALTY_VOYAGE_BRANCH", "")

# Guard flag: emit LEGACY_DISPATCHER_BRANCH_CHECK only once per dispatcher run
_LEGACY_BRANCH_CHECK_EMITTED: bool = False

# v8.13: Track target repos dispatched during this session (for post-voyage PR creation)
_SESSION_TARGET_REPOS: Dict[str, list] = {}  # repo -> [order titles]
# v2.0.2: Track voyage branch per repo (for per-repo PR creation)
_SESSION_REPO_BRANCHES: Dict[str, str] = {}  # repo -> voyage branch

# v7.1: Comprehensive terminal states — any state a crew can exit with that means "done"
# This must match ALL possible final_status values from crew.py
TERMINAL_STATES = {
    "COMPLETE", "BLOCKED", "ERROR", "MAX_ITERATIONS", "CRASHED",
    "CIRCUIT_BREAKER", "TIMEOUT", "AUTH_ERROR", "INTERRUPTED"
}

class C:
    """ANSI color codes."""
    RESET = '\033[0m'
    BOLD = '\033[1m'
    DIM = '\033[2m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    RED = '\033[91m'
    WHITE = '\033[97m'
    MAGENTA = '\033[95m'

# Global state
ACTIVE_PROCESSES: Dict[int, int] = {}  # crew_number -> PID (file-based monitoring, no process handles)
DRAINING_PROCESSES: Dict[int, Dict[str, Any]] = {}  # crew_number -> {pid, voyage_id, drained_at}
ORDERS_IN_TRANSITION: set = set()  # order IDs advanced to next role but not yet dispatched (BUG-MSO-2026-0017)
_CREW_LOG_HANDLES: Dict[int, Any] = {}  # crew_number -> file handle (for background mode log files)
FLEET_STATE_FILE: Optional[Path] = None
SHUTDOWN_REQUESTED = False
_ADMIRALTY_DIR_OVERRIDE: Optional[Path] = None


def get_base_dir() -> Path:
    if _ADMIRALTY_DIR_OVERRIDE is not None:
        return _ADMIRALTY_DIR_OVERRIDE.parent
    return Path(__file__).parent.parent.parent.resolve()

def get_admiralty_dir() -> Path:
    if _ADMIRALTY_DIR_OVERRIDE is not None:
        return _ADMIRALTY_DIR_OVERRIDE
    # Walk up from cwd looking for .adm/ or .admiralty/
    cwd = Path.cwd()
    for path in [cwd, *cwd.parents]:
        if (path / ".adm" / "config").is_dir():
            return path / ".adm"
        if (path / ".admiralty" / "config").is_dir():
            import sys as _sys
            print(
                f"[{current_persona().term('product')}] WARNING: Found legacy .admiralty/ directory. "
                "Migrate with: adm init --project <PRJ>",
                file=_sys.stderr,
            )
            return path / ".admiralty"
    # Fallback to script-relative resolution
    base = Path(__file__).parent.parent.parent.resolve()
    adm = base / ".adm"
    if adm.exists():
        return adm
    return adm

def get_crew_dir(crew_number: int) -> Path:
    return get_admiralty_dir() / f"crews/crew{crew_number}"


def load_project_config(project_acronym=None):
    """Load project config from the project registry."""
    admiralty_dir = get_admiralty_dir()
    projects_file = admiralty_dir / "config" / "projects.json"

    if not projects_file.exists():
        return None

    with open(projects_file, encoding='utf-8') as f:
        registry = json.load(f)

    if not project_acronym:
        project_acronym = registry.get("defaultProject", "OTM")

    project_info = registry.get("projects", {}).get(project_acronym)
    if not project_info:
        return None

    # Load per-project config if available
    config_file_rel = project_info.get("configFile", f"config/projects/{project_acronym}.json")
    config_file = admiralty_dir / config_file_rel

    if config_file.exists():
        with open(config_file, encoding='utf-8') as f:
            project_config = json.load(f)
        project_info["_config"] = project_config

    return project_info

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def print_header(title: str):
    """Print a section header."""
    print(f"\n  {C.CYAN}{C.BOLD}{'='*70}")
    print(f"  {title}")
    print(f"  {'='*70}{C.RESET}\n")

def print_ok(msg: str):
    print(f"  {C.GREEN}[OK]{C.RESET} {msg}")

def print_warn(msg: str):
    print(f"  {C.YELLOW}[!!]{C.RESET} {msg}")

def print_error(msg: str):
    print(f"  {C.RED}[XX]{C.RESET} {msg}")

def print_info(msg: str):
    print(f"  {C.DIM}[..]{C.RESET} {msg}")


def write_lifecycle_event(event_type: str, message: str):
    """Append a timestamped lifecycle event to the log file.

    Used by the unified Maestro Monitor v3.0 to display recent events.
    Format: YYYY-MM-DD HH:MM:SS | EVENT_TYPE | message
    Auto-rotates when log exceeds 1000 lines.
    """
    log_dir = get_admiralty_dir() / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / "lifecycle.log"

    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    line = f"{timestamp} | {event_type:<10} | {message}\n"

    try:
        with open(str(log_file), 'a', encoding='utf-8') as f:
            f.write(line)

        # Rotate if too large
        if log_file.stat().st_size > 100000:  # ~1000 lines
            lines = log_file.read_text(encoding='utf-8').split('\n')
            # Keep last 500 lines
            log_file.write_text('\n'.join(lines[-500:]), encoding='utf-8')
    except:
        pass


# =============================================================================
# PRE-FLIGHT CHECKS
# =============================================================================

def preflight_kill_rogue_processes() -> int:
    """Kill rogue crew.py and fleet-runner.py processes from previous runs.

    Uses PID-based approach (fast, reliable) from pid.txt files and fleet state.
    Does NOT use wmic commandline matching (slow, can hang on Git Bash).
    IMPORTANT: Does NOT kill the CURRENT fleet-runner process.
    """
    killed = 0
    my_pid = os.getpid()

    if os.name == 'nt':
        # 1. Kill old dispatcher by PID lock
        dispatcher_lock = get_admiralty_dir() / "dispatcher.pid"
        if dispatcher_lock.exists():
            try:
                pid = int(dispatcher_lock.read_text(encoding='utf-8').strip())
                if pid != my_pid:
                    subprocess.run(['taskkill', '/F', '/T', '/PID', str(pid)],
                                 capture_output=True, timeout=5)
                    killed += 1
                dispatcher_lock.unlink()
            except:
                pass

        # 2. Clean stale monitor PID lock
        monitor_lock = get_admiralty_dir() / "monitor.pid"
        if monitor_lock.exists():
            try:
                mpid = int(monitor_lock.read_text(encoding='utf-8').strip())
                if not is_process_alive(mpid):
                    monitor_lock.unlink()
            except:
                pass

        # 3. Kill by PID files in crew directories
        for crew_num in range(1, 6):
            pid = read_crew_pid(crew_num)
            if pid and pid != my_pid:
                try:
                    subprocess.run(['taskkill', '/F', '/T', '/PID', str(pid)],
                                 capture_output=True, timeout=5)
                    killed += 1
                except:
                    pass

        # 4. Kill by fleet state file (catches tracked crews)
        fleet_state = get_admiralty_dir() / "fleet-runner-state.json"
        if fleet_state.exists():
            try:
                state = json.loads(fleet_state.read_text(encoding='utf-8'))
                for crew_num, pid in state.get("pids", {}).items():
                    if int(pid) != my_pid:
                        try:
                            subprocess.run(['taskkill', '/F', '/T', '/PID', str(pid)],
                                         capture_output=True, timeout=5)
                            killed += 1
                        except:
                            pass
            except:
                pass

    return killed

def preflight_clear_stale_states(preserve_complete: bool = False) -> int:
    """Clear stale state files from crew directories.

    Args:
        preserve_complete: If True, don't clear COMPLETE status states (for --continue mode)
    """
    cleared = 0

    for crew_num in range(1, 6):
        crew_dir = get_crew_dir(crew_num)
        if crew_dir.exists():
            # Clear state.json
            state_file = crew_dir / "state.json"
            if state_file.exists():
                should_clear = True

                # In continue mode, preserve COMPLETE states
                if preserve_complete:
                    try:
                        state = json.loads(state_file.read_text(encoding='utf-8'))
                        if state.get("status") == "COMPLETE":
                            should_clear = False
                            print_info(f"Preserving Crew {crew_num} COMPLETE state")
                    except:
                        pass

                if should_clear:
                    try:
                        state_file.unlink()
                        cleared += 1
                    except:
                        pass

            # v8.9: Clear ralph-state.md (prevents stale COMPLETE detection on re-dispatch)
            ralph_file = crew_dir / "ralph-state.md"
            if ralph_file.exists():
                should_clear_ralph = True
                if preserve_complete:
                    try:
                        content = ralph_file.read_text(encoding='utf-8')
                        if "status: \"COMPLETE\"" in content:
                            should_clear_ralph = False
                    except:
                        pass
                if should_clear_ralph:
                    try:
                        ralph_file.unlink()
                        cleared += 1
                    except:
                        pass

            # Clear any lock files
            for lock_file in crew_dir.glob("*.lock"):
                try:
                    lock_file.unlink()
                except:
                    pass

    # Clear fleet state file
    fleet_state = get_admiralty_dir() / "fleet-runner-state.json"
    if fleet_state.exists():
        try:
            fleet_state.unlink()
            cleared += 1
        except:
            pass

    return cleared


def reset_orphaned_in_progress_orders() -> int:
    """Reset orphaned IN_PROGRESS orders back to PENDING (v8.2).

    After cleanup kills crew processes, orders they were working on remain
    stuck as IN_PROGRESS in the queues. This scans all queue directories
    and resets any IN_PROGRESS order whose assigned crew is no longer alive.
    """
    reset_count = 0
    queues_dir = get_queues_dir()

    if not queues_dir.exists():
        return 0

    for queue_subdir in queues_dir.iterdir():
        if not queue_subdir.is_dir():
            continue
        for json_file in queue_subdir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                if data.get("status") != "IN_PROGRESS":
                    continue

                # Check if assigned crew is still alive
                assigned = data.get("assignedTo", {})
                crew_num = assigned.get("crew")
                crew_alive = False

                if crew_num:
                    # Module-level tracking is authoritative — includes draining crews
                    # whose process may already be dead but whose order is still valid
                    if crew_num in ACTIVE_PROCESSES or crew_num in DRAINING_PROCESSES:
                        crew_alive = True
                    else:
                        pid = read_crew_pid(crew_num)
                        if pid and is_process_alive(pid):
                            crew_alive = True

                if not crew_alive:
                    # Reset to PENDING — remove assignment fields
                    data["status"] = "PENDING"
                    data.pop("assignedTo", None)
                    data.pop("startedAt", None)

                    # Atomic write: temp file + rename
                    tmp_file = json_file.with_suffix('.tmp')
                    tmp_file.write_text(
                        json.dumps(data, indent=2, ensure_ascii=False),
                        encoding='utf-8'
                    )
                    tmp_file.replace(json_file)

                    order_id = data.get("id", json_file.stem)
                    print_info(f"Reset orphaned order {order_id} -> PENDING")
                    reset_count += 1
            except Exception:
                pass

    return reset_count


def _reclaim_inflight_from_crew_state() -> int:
    """BUG-MSO-2026-0018: Reconstruct ACTIVE_PROCESSES from crew state.json on startup.

    Scans .adm/crews/crewN/state.json for crews whose status is a non-terminal
    running state and whose PID is still alive.  Repopulates ACTIVE_PROCESSES so
    the first dispatcher tick does not re-dispatch orders that are already owned
    by a live crew.

    Dead-PID crews are skipped — their orders remain eligible for fresh dispatch
    via the normal reset_orphaned_in_progress_orders() path.

    Returns the number of crews reclaimed.
    """
    reclaimed = 0
    crews_dir = get_admiralty_dir() / "crews"
    if not crews_dir.exists():
        return 0

    for crew_dir in sorted(crews_dir.iterdir()):
        if not crew_dir.is_dir() or not crew_dir.name.startswith("crew"):
            continue
        state_file = crew_dir / "state.json"
        if not state_file.exists():
            continue
        try:
            state = json.loads(state_file.read_text(encoding="utf-8"))
        except Exception:
            continue

        crew_num = state.get("crewNumber")
        pid = state.get("pid")
        status = state.get("status", "")
        order_id = state.get("orderId", "")

        if crew_num is None or pid is None:
            continue
        if status in TERMINAL_STATES:
            continue
        if not is_process_alive(pid):
            continue

        # Live crew with non-terminal status — reclaim it
        ACTIVE_PROCESSES[crew_num] = pid
        print_info(f"[reclaim] Crew {crew_num} (PID {pid}) reclaimed for {order_id} ({status})")
        reclaimed += 1

    return reclaimed


def preflight_verify_crew_dirs():
    """Ensure crew directories exist."""
    for crew_num in range(1, 6):
        crew_dir = get_crew_dir(crew_num)
        crew_dir.mkdir(parents=True, exist_ok=True)

# Legacy manifest mode removed in v2.0.4 — use --dispatch (queue-based) instead


# =============================================================================
# VOYAGE BRANCH MANAGEMENT
# =============================================================================

# Track which repos we've already verified/created branches for (avoid repeated API calls)
_VERIFIED_VOYAGE_BRANCHES: set = set()

# BUG-ADM-2026-0007: per-(repo,branch) failure cache so a missing-default-branch
# or auth-failure doesn't trigger a `gh api` storm on every dispatcher loop.
# Maps cache_key -> last_error_message for diagnostics.
_FAILED_VOYAGE_BRANCHES: dict = {}


def _resolve_full_repo_slug(target_repo: str, org: str) -> str:
    """Return a full `org/repo` slug regardless of whether `target_repo` is
    bare ("Admiralty") or already-qualified ("PlaneSales/Planes-Sales-Global-AI").

    BUG-ADM-2026-0007 (Copilot review): orders + project registry entries
    use BOTH conventions, and unconditionally prepending `org/` produced
    `repos/PlaneSales/PlaneSales/Planes-Sales-Global-AI/...` paths that
    404'd permanently and got cached as failures.
    """
    if "/" in target_repo:
        return target_repo
    return f"{org}/{target_repo}"


def _get_default_branch_for_repo(target_repo: str, project_acronym: str = "") -> str:
    """Resolve the default branch for a given target repo.

    BUG-ADM-2026-0013: PR-creation paths used to hardcode `main`, which 404s
    on repos like PSG (Planes-Sales-Global-AI) whose defaultBranch is `master`.
    This helper reads `defaultBranch` from `.adm/config/projects.json`.

    Resolution order:
      1. If project_acronym given → look it up directly
      2. Else if target_repo given → scan registry for a project whose
         `repo` matches (handles both bare "Admiralty" and qualified
         "tavisbasing/Admiralty" forms)
      3. Fall back to `main`

    Same pattern as BUG-0007's fix in `ensure_voyage_branch_exists`.
    """
    # Path 1: explicit project acronym
    try:
        if project_acronym:
            project_info = load_project_config(project_acronym)
            if project_info:
                branch = project_info.get("defaultBranch") or ""
                if branch:
                    return branch
    except Exception:
        pass

    # Path 2: reverse lookup by target_repo
    try:
        if target_repo:
            admiralty_dir = get_admiralty_dir()
            projects_file = admiralty_dir / "config" / "projects.json"
            if projects_file.exists():
                registry = json.loads(projects_file.read_text(encoding='utf-8'))
                for _acronym, info in (registry.get("projects") or {}).items():
                    repo_value = info.get("repo", "")
                    # Match both bare and qualified slug forms
                    if repo_value == target_repo:
                        branch = info.get("defaultBranch") or ""
                        if branch:
                            return branch
                    # Tail of slug match (e.g. registry has "PlaneSales/PSG-AI",
                    # target_repo is just "PSG-AI")
                    if "/" in repo_value and repo_value.split("/", 1)[-1] == target_repo:
                        branch = info.get("defaultBranch") or ""
                        if branch:
                            return branch
    except Exception:
        pass

    # Path 3: fall back
    return "main"


def _load_workspace_org(project_acronym: str = None) -> str:
    """Load the GitHub org name from workspace.json or project registry.

    v2.0.5: In multi-project mode, resolves org from the project registry.
    Falls back to workspace.json 'org' field, then to default.
    """
    ws_file = get_admiralty_dir() / "config" / "workspace.json"
    try:
        data = json.loads(ws_file.read_text(encoding='utf-8'))
        mode = data.get("mode", "single-project")
    except Exception:
        data = {}
        mode = "single-project"

    # In multi-project mode, check project registry first
    if mode == "multi-project":
        project_info = load_project_config(project_acronym)
        if project_info and project_info.get("org"):
            return project_info["org"]

    return data.get("org", "eml-ProductDevelopment")


def ensure_voyage_branch_exists(
    target_repo: str,
    voyage_branch: str,
    project_acronym: str = "",
) -> bool:
    """Ensure the voyage branch exists on the remote for the target repo.

    v8.12: Auto-creates voyage branches before crew dispatch.
    BUG-ADM-2026-0007 (v2.5.5): reads `defaultBranch` from the project
    registry (e.g. 'master' for PSG) instead of hardcoding 'main'. Caches
    failures so a missing default branch doesn't storm `gh api` on every
    dispatcher loop. Logs structured lifecycle events for every failure.

    Uses `gh api` to check and create branches — no local clone needed.

    Returns True if the branch exists (or was created), False on error.
    """
    if not target_repo or not voyage_branch:
        return True  # Nothing to do

    cache_key = f"{target_repo}:{voyage_branch}"
    if cache_key in _VERIFIED_VOYAGE_BRANCHES:
        return True  # Already verified this session
    if cache_key in _FAILED_VOYAGE_BRANCHES:
        # BUG-ADM-2026-0007: don't re-attempt failed branch ops every dispatcher
        # tick. The cached error gives the human operator something to act on.
        return False

    # BUG-ADM-2026-0007: resolve org + defaultBranch from the project registry
    # so single-project workspaces with non-main default branches (e.g. PSG on
    # 'master') don't 404 when looking up the default branch SHA.
    org = _load_workspace_org(project_acronym)
    default_branch = "main"
    try:
        project_info = load_project_config(project_acronym) if project_acronym else None
        if project_info:
            default_branch = project_info.get("defaultBranch") or "main"
            if not org or org == "eml-ProductDevelopment":
                org = project_info.get("org") or org
    except Exception:
        pass  # Best-effort — fall back to defaults

    full_repo = _resolve_full_repo_slug(target_repo, org)
    branch_ref = voyage_branch.replace("refs/heads/", "")

    def _record_failure(detail: str) -> bool:
        """Cache + log a structured failure so the operator can diagnose."""
        _FAILED_VOYAGE_BRANCHES[cache_key] = detail
        print_warn(
            f"Branch ensure failed for {full_repo}@{branch_ref}: {detail}\n"
            f"  This failure is cached — re-attempts are suppressed until restart.\n"
            f"  Resolve manually (push the branch, fix gh auth, fix project config) and restart the dispatcher."
        )
        try:
            write_lifecycle_event(
                "BRANCH_FAIL",
                f"{full_repo}@{branch_ref} (project={project_acronym or 'unknown'}, "
                f"default={default_branch}): {detail}"
            )
        except Exception:
            pass
        return False

    try:
        # Check if branch already exists
        result = subprocess.run(
            ["gh", "api", f"repos/{full_repo}/branches/{branch_ref}",
             "--jq", ".name"],
            capture_output=True, text=True, timeout=30
        )

        if result.returncode == 0 and result.stdout.strip():
            _VERIFIED_VOYAGE_BRANCHES.add(cache_key)
            return True

        # Branch doesn't exist — get the SHA of the project's default branch
        sha_result = subprocess.run(
            ["gh", "api", f"repos/{full_repo}/git/refs/heads/{default_branch}",
             "--jq", ".object.sha"],
            capture_output=True, text=True, timeout=30
        )

        if sha_result.returncode != 0 or not sha_result.stdout.strip():
            stderr = sha_result.stderr.strip() or "no SHA returned"
            return _record_failure(
                f"could not resolve default branch '{default_branch}' SHA — {stderr[:200]}"
            )

        default_sha = sha_result.stdout.strip()

        # Create the branch
        create_result = subprocess.run(
            ["gh", "api", f"repos/{full_repo}/git/refs",
             "-f", f"ref=refs/heads/{branch_ref}",
             "-f", f"sha={default_sha}"],
            capture_output=True, text=True, timeout=30
        )

        if create_result.returncode == 0:
            print_ok(f"Created voyage branch '{branch_ref}' on {target_repo} (from {default_branch})")
            try:
                write_lifecycle_event(
                    "BRANCH_CREATE",
                    f"{full_repo}@{branch_ref} created from {default_branch} "
                    f"(project={project_acronym or 'unknown'})"
                )
            except Exception:
                pass
            _VERIFIED_VOYAGE_BRANCHES.add(cache_key)
            return True
        else:
            return _record_failure(
                f"branch creation failed — {create_result.stderr.strip()[:200]}"
            )

    except subprocess.TimeoutExpired:
        return _record_failure("timeout calling gh api (network or auth issue)")
    except Exception as e:
        return _record_failure(f"unexpected error — {type(e).__name__}: {e}")


# =============================================================================
# v2.0.0: MANAGED REPO LIFECYCLE
# =============================================================================

def _robust_rmtree(path: Path, label: str = "", retries: int = 3, backoff: float = 2.0) -> bool:
    """Remove a directory tree robustly on Windows.

    v2.0.1: Handles Windows-specific issues:
    - Git marks .git/objects/ files read-only — clear the flag before removal
    - NTFS file handles linger after process kill — retry with exponential backoff
    - Falls back to 'rd /s /q' as a last resort on Windows
    Returns True if directory was removed, False otherwise.
    """
    import shutil as _shutil
    import stat

    if not path.exists():
        return True

    def _on_rm_error(func, fpath, exc_info):
        """Error handler: clear read-only flag and retry."""
        try:
            os.chmod(fpath, stat.S_IWRITE)
            func(fpath)
        except Exception:
            pass

    for attempt in range(retries):
        _shutil.rmtree(str(path), onerror=_on_rm_error)
        if not path.exists():
            return True
        wait = backoff * (attempt + 1)
        if label:
            print_info(f"{label}: Retry {attempt + 1}/{retries} — waiting {wait:.0f}s for NTFS handles...")
        time.sleep(wait)

    # Last resort on Windows: rd /s /q handles more edge cases than Python
    if os.name == 'nt' and path.exists():
        try:
            subprocess.run(
                ['cmd', '/c', 'rd', '/s', '/q', str(path)],
                capture_output=True, timeout=30
            )
        except Exception:
            pass

    return not path.exists()


def prepare_crew_repo(crew_num: int, target_repo: str, voyage_branch: str) -> Optional[Path]:
    """DEPRECATED (FTR-ADM-2026-0149): use prepare_voyage_worktree() instead.

    Kept functional for backwards compatibility with legacy callers (custom
    dispatchers, third-party scripts). Emits LEGACY_CREW_CLONE lifecycle event
    when invoked so operators can migrate.

    Returns Path to crew repo dir, or None on failure (crew self-manages as fallback).
    """
    try:
        write_lifecycle_event(
            "LEGACY_CREW_CLONE",
            f"prepare_crew_repo() called for crew {crew_num} / {target_repo} — "
            "this function is deprecated. Use prepare_voyage_worktree() instead."
        )
    except Exception:
        pass
    if not target_repo:
        return None

    crew_dir = get_crew_dir(crew_num)
    repo_dir = crew_dir / "repo"
    org = _load_workspace_org()

    # Load clone protocol from workspace config
    ws_file = get_admiralty_dir() / "config" / "workspace.json"
    try:
        ws_data = json.loads(ws_file.read_text(encoding='utf-8'))
        protocol = ws_data.get("cloneProtocol", "ssh")
    except Exception:
        protocol = "ssh"

    if protocol == "ssh":
        clone_url = f"git@github.com:{org}/{target_repo}.git"
    else:
        clone_url = f"https://github.com/{org}/{target_repo}.git"

    branch_ref = voyage_branch.replace("refs/heads/", "")

    try:
        # Step 1: Clean existing repo if present
        if repo_dir.exists():
            print_info(f"Crew {crew_num}: Cleaning existing repo clone...")
            if not _robust_rmtree(repo_dir, label=f"Crew {crew_num}"):
                print_warn(f"Crew {crew_num}: Could not remove {repo_dir} — file locks?")
                return None

        # Step 2: Clone directly onto the voyage branch
        print_info(f"Crew {crew_num}: Cloning {target_repo} (branch: {branch_ref})...")
        clone_result = subprocess.run(
            ["git", "clone", "--branch", branch_ref, "--single-branch",
             clone_url, str(repo_dir)],
            capture_output=True, text=True, timeout=120
        )

        if clone_result.returncode != 0:
            # Voyage branch may have no commits yet — clone main, then checkout
            print_info(f"Crew {crew_num}: Direct branch clone failed, trying main + checkout...")
            clone_result = subprocess.run(
                ["git", "clone", clone_url, str(repo_dir)],
                capture_output=True, text=True, timeout=120
            )
            if clone_result.returncode != 0:
                print_warn(f"Crew {crew_num}: Clone failed: {clone_result.stderr.strip()[:200]}")
                return None

            # Checkout voyage branch (tracking remote)
            checkout_result = subprocess.run(
                ["git", "checkout", "-B", branch_ref, f"origin/{branch_ref}"],
                capture_output=True, text=True, timeout=30,
                cwd=str(repo_dir)
            )
            if checkout_result.returncode != 0:
                # Branch exists remote but no tracking — create local from current HEAD
                subprocess.run(
                    ["git", "checkout", "-b", branch_ref],
                    capture_output=True, text=True, timeout=30,
                    cwd=str(repo_dir)
                )

        # Step 3: Verify correct branch
        branch_check = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True, text=True, timeout=10,
            cwd=str(repo_dir)
        )
        current_branch = branch_check.stdout.strip()
        if current_branch != branch_ref:
            print_warn(f"Crew {crew_num}: Expected branch '{branch_ref}', got '{current_branch}'")

        print_ok(f"Crew {crew_num}: Repo ready at crews/crew{crew_num}/repo/ (branch: {current_branch})")
        write_lifecycle_event("REPO", f"Crew {crew_num}: {target_repo} cloned on {branch_ref}")
        return repo_dir

    except subprocess.TimeoutExpired:
        print_warn(f"Crew {crew_num}: Clone timed out for {target_repo}")
        return None
    except Exception as e:
        print_warn(f"Crew {crew_num}: Repo preparation failed: {e}")
        return None


def verify_and_push_crew_work(crew_num: int, target_repo: str, voyage_branch: str) -> Dict[str, Any]:
    """Post-completion: verify commits were pushed, commit+push any uncommitted work.

    v2.0.0: Runs after crew process exits. Returns verification report.
    """
    repo_dir = get_crew_dir(crew_num) / "repo"
    report = {"pushed": False, "commits_ahead": 0,
              "uncommitted_committed": False, "error": None}

    if not repo_dir.exists() or not (repo_dir / ".git").exists():
        report["error"] = f"No repo found at {repo_dir}"
        return report

    branch_ref = voyage_branch.replace("refs/heads/", "")

    try:
        # Step 1: Check for uncommitted changes
        status = subprocess.run(
            ["git", "status", "--porcelain"],
            capture_output=True, text=True, timeout=30,
            cwd=str(repo_dir)
        )

        if status.stdout.strip():
            print_info(f"Crew {crew_num}: Found uncommitted changes, auto-committing...")
            subprocess.run(
                ["git", "add", "-A"],
                capture_output=True, text=True, timeout=30,
                cwd=str(repo_dir)
            )
            commit_result = subprocess.run(
                ["git", "commit", "-m",
                 f"[fleet] Auto-commit uncommitted work from Crew {crew_num}"],
                capture_output=True, text=True, timeout=30,
                cwd=str(repo_dir)
            )
            if commit_result.returncode == 0:
                report["uncommitted_committed"] = True
                print_ok(f"Crew {crew_num}: Uncommitted changes committed")

        # Step 2: Fetch remote state and check for unpushed commits
        subprocess.run(
            ["git", "fetch", "origin", branch_ref],
            capture_output=True, text=True, timeout=60,
            cwd=str(repo_dir)
        )

        ahead = subprocess.run(
            ["git", "rev-list", "--count", f"origin/{branch_ref}..HEAD"],
            capture_output=True, text=True, timeout=15,
            cwd=str(repo_dir)
        )

        commits_ahead = 0
        if ahead.returncode == 0:
            try:
                commits_ahead = int(ahead.stdout.strip())
            except ValueError:
                pass

        report["commits_ahead"] = commits_ahead

        if commits_ahead > 0:
            print_info(f"Crew {crew_num}: {commits_ahead} unpushed commit(s), pushing...")
            push_result = subprocess.run(
                ["git", "push", "origin", branch_ref],
                capture_output=True, text=True, timeout=120,
                cwd=str(repo_dir)
            )
            if push_result.returncode == 0:
                report["pushed"] = True
                print_ok(f"Crew {crew_num}: Pushed {commits_ahead} commit(s) to {target_repo}/{branch_ref}")
                write_lifecycle_event("REPO",
                    f"Crew {crew_num}: Pushed {commits_ahead} commit(s) to {target_repo}/{branch_ref}")
            else:
                report["error"] = f"Push failed: {push_result.stderr.strip()[:200]}"
                print_warn(f"Crew {crew_num}: {report['error']}")
        else:
            report["pushed"] = True  # Nothing to push = success

        return report

    except subprocess.TimeoutExpired:
        report["error"] = "Git operation timed out"
        return report
    except Exception as e:
        report["error"] = str(e)
        return report


def create_pr_for_crew(crew_num: int, target_repo: str, voyage_branch: str,
                       order_id: str, order_title: str,
                       project_acronym: str = "") -> Optional[str]:
    """Create or update a PR for the crew's completed work.

    v2.0.0: Called immediately when each crew completes.
    If PR already exists, adds a comment. Otherwise creates a new PR.
    Returns PR URL on success, None on failure.

    BUG-ADM-2026-0013: project_acronym threaded through so the base branch
    can be resolved from the project registry (`master` for PSG, `main` for
    framework). Falls back to `main` if registry missing.
    """
    if not target_repo or not voyage_branch:
        return None

    org = _load_workspace_org(project_acronym)
    full_repo = _resolve_full_repo_slug(target_repo, org)
    branch_ref = voyage_branch.replace("refs/heads/", "")
    default_branch = _get_default_branch_for_repo(target_repo, project_acronym)

    try:
        # Check if branch has commits ahead of the project's default branch
        compare = subprocess.run(
            ["gh", "api", f"repos/{full_repo}/compare/{default_branch}...{branch_ref}",
             "--jq", ".ahead_by"],
            capture_output=True, text=True, timeout=30
        )

        ahead_by = 0
        if compare.returncode == 0:
            try:
                ahead_by = int(compare.stdout.strip())
            except ValueError:
                pass

        if ahead_by == 0:
            print_info(f"Crew {crew_num}: No commits ahead of {default_branch} on {target_repo} — no PR needed")
            return None

        # Check for existing open PR
        pr_check = subprocess.run(
            ["gh", "pr", "list", "--repo", full_repo,
             "--head", branch_ref, "--state", "open",
             "--json", "number,url"],
            capture_output=True, text=True, timeout=30
        )

        if pr_check.returncode == 0 and pr_check.stdout.strip() not in ("", "[]"):
            prs = json.loads(pr_check.stdout)
            if prs:
                pr_number = prs[0]["number"]
                pr_url = prs[0]["url"]
                codename = CREW_NAMES.get(crew_num, f"Crew{crew_num}")
                comment_body = f"Crew {crew_num} ({codename}) completed order `{order_id}`: {order_title}"
                subprocess.run(
                    ["gh", "pr", "comment", str(pr_number),
                     "--repo", full_repo, "--body", comment_body],
                    capture_output=True, text=True, timeout=30
                )
                print_ok(f"Crew {crew_num}: Commented on existing PR #{pr_number} for {target_repo}")
                return pr_url

        # No existing PR — create one
        orders = _SESSION_TARGET_REPOS.get(target_repo, [])
        body_lines = ["## Summary", ""]
        body_lines.append(f"Voyage branch `{branch_ref}` with {ahead_by} commit(s).")
        body_lines.append("")
        body_lines.append("### Orders Completed")
        for t in orders[:20]:
            body_lines.append(f"- {t}")
        body_lines.append("")
        body_lines.append("## Test plan")
        body_lines.append("- [ ] CI checks pass")
        body_lines.append("- [ ] Code review completed")

        pr_title = f"[{branch_ref}] {target_repo}"
        pr_body = "\n".join(body_lines)

        pr_result = subprocess.run(
            ["gh", "pr", "create",
             "--repo", full_repo,
             "--base", default_branch,
             "--head", branch_ref,
             "--title", pr_title,
             "--body", pr_body],
            capture_output=True, text=True, timeout=60
        )

        if pr_result.returncode == 0:
            pr_url = pr_result.stdout.strip()
            print_ok(f"Crew {crew_num}: PR created for {target_repo} -> {pr_url}")
            write_lifecycle_event("PR", f"Crew {crew_num}: PR created for {target_repo}: {pr_url}")
            return pr_url
        else:
            err = pr_result.stderr.strip()[:200]
            print_warn(f"Crew {crew_num}: PR creation failed for {target_repo}: {err}")
            return None

    except subprocess.TimeoutExpired:
        print_warn(f"Crew {crew_num}: PR creation timed out for {target_repo}")
        return None
    except Exception as e:
        print_warn(f"Crew {crew_num}: PR creation error for {target_repo}: {e}")
        return None


def cleanup_crew_repo(crew_num: int):
    """Remove the crew's ephemeral repo clone after completion.

    v2.0.0: Only removes crews/crewN/repo/, preserving other crew artifacts.
    v2.0.1: Uses _robust_rmtree for reliable Windows cleanup.
    """
    repo_dir = get_crew_dir(crew_num) / "repo"
    if repo_dir.exists():
        if _robust_rmtree(repo_dir, label=f"Crew {crew_num}"):
            print_info(f"Crew {crew_num}: Cleaned up ephemeral repo clone")
        else:
            print_warn(f"Crew {crew_num}: Failed to clean repo dir — will retry on next dispatch")


def reset_developer_repos():
    """Reset any repos/ checkouts back to their project's default branch.

    v2.0.0: Called at Eight Bells. Scans repos/ directory for any
    repos left on voyage branches and resets them to the resolved
    default branch (e.g. `master` for PSG, `main` for the framework).

    BUG-MSO-2026-0016 (v2.8.2): each repo's default branch is now
    resolved via `_get_default_branch_for_repo()` rather than hardcoded
    to `main`. Repos with a non-`main` default (PSG/master, anyone on
    develop/trunk) now reset to the correct branch.
    """
    repos_dir = get_base_dir() / "repos"
    if not repos_dir.exists():
        return

    reset_count = 0
    for repo_path in sorted(repos_dir.iterdir()):
        if not repo_path.is_dir() or not (repo_path / ".git").exists():
            continue

        try:
            branch = subprocess.run(
                ["git", "rev-parse", "--abbrev-ref", "HEAD"],
                capture_output=True, text=True, timeout=10,
                cwd=str(repo_path)
            )
            current = branch.stdout.strip()

            if current.startswith("voyage/"):
                # Check for uncommitted changes first
                status = subprocess.run(
                    ["git", "status", "--porcelain"],
                    capture_output=True, text=True, timeout=10,
                    cwd=str(repo_path)
                )
                if status.stdout.strip():
                    # Discard local changes (crew work should be in ephemeral clone)
                    subprocess.run(
                        ["git", "checkout", "--", "."],
                        capture_output=True, text=True, timeout=15,
                        cwd=str(repo_path)
                    )
                    subprocess.run(
                        ["git", "clean", "-fd"],
                        capture_output=True, text=True, timeout=15,
                        cwd=str(repo_path)
                    )

                repo_default_branch = _get_default_branch_for_repo(repo_path.name)
                result = subprocess.run(
                    ["git", "checkout", repo_default_branch],
                    capture_output=True, text=True, timeout=30,
                    cwd=str(repo_path)
                )
                if result.returncode == 0:
                    subprocess.run(
                        ["git", "pull", "--ff-only"],
                        capture_output=True, text=True, timeout=60,
                        cwd=str(repo_path)
                    )
                    reset_count += 1
        except Exception:
            continue

    if reset_count > 0:
        print_ok(f"Reset {reset_count} repo(s) in repos/ back to their default branch")


def _resolve_target_repo_from_project(data: dict) -> str:
    """Resolve targetRepo from order's project field via the project registry.

    v2.0.5: If an order has a 'project' field but no 'targetRepo', look up the
    repo name from the project registry.
    """
    project = data.get("project", "")
    if not project:
        return ""
    project_info = load_project_config(project)
    if project_info:
        return project_info.get("repo", "")
    return ""


def _get_target_repo_for_order(order_id: str) -> str:
    """Look up the targetRepo for an order from session tracking or queue files."""
    # Fast path: check session tracking (in-memory)
    for repo, orders in _SESSION_TARGET_REPOS.items():
        if any(order_id in o for o in orders):
            return repo

    # Fallback: scan queue files
    queues_dir = get_queues_dir()
    queue_names = ["orders", "explicit", "bugs", "security", "breakdown", "defects", "high-level"]
    for queue_name in queue_names:
        queue_dir = queues_dir / queue_name
        if not queue_dir.exists():
            continue
        for json_file in queue_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                file_id = data.get("orderId") or data.get("id") or json_file.stem
                if file_id == order_id:
                    repo = data.get("targetRepo", "")
                    # v2.0.5: Resolve from project field if targetRepo is missing
                    if not repo:
                        repo = _resolve_target_repo_from_project(data)
                    return repo
            except Exception:
                continue

    # Also check active orders
    active_dir = get_admiralty_dir() / "orders" / "active"
    if active_dir.exists():
        for json_file in active_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                file_id = data.get("orderId") or data.get("id") or json_file.stem
                if file_id == order_id:
                    repo = data.get("targetRepo", "")
                    # v2.0.5: Resolve from project field if targetRepo is missing
                    if not repo:
                        repo = _resolve_target_repo_from_project(data)
                    return repo
            except Exception:
                continue

    return ""


def _get_project_for_order(order_id: str) -> str:
    """Look up an order's project acronym from queue files.

    BUG-ADM-2026-0013: PR-creation needs the project to resolve the
    default branch (PSG → master, ADM → main). Same scan pattern as
    _get_target_repo_for_order.
    """
    if not order_id:
        return ""
    queues_dir = get_queues_dir()
    queue_names = ["orders", "explicit", "bugs", "security",
                   "breakdown", "defects", "high-level", "proposed"]
    for queue_name in queue_names:
        queue_dir = queues_dir / queue_name
        if not queue_dir.exists():
            continue
        for json_file in queue_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                file_id = data.get("orderId") or data.get("id") or json_file.stem
                if file_id == order_id:
                    return data.get("project", "")
            except Exception:
                continue
    for sub in ("orders/active", "orders/complete", "orders/failed"):
        d = get_admiralty_dir() / sub
        if not d.exists():
            continue
        for json_file in d.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                file_id = data.get("orderId") or data.get("id") or json_file.stem
                if file_id == order_id:
                    return data.get("project", "")
            except Exception:
                continue
    return ""


def _get_voyage_branch_for_order(order_id: str) -> str:
    """Look up the voyage branch for an order from its voyageId field.

    v2.0.1: Per-order voyage branch resolution. Converts voyageId (e.g. 'VOY-2026-0304')
    to a branch name (e.g. 'voyage/VOY-2026-0304'). Falls back to ACTIVE_VOYAGE_BRANCH
    if the order has no voyageId.
    """
    # Scan queue files and active orders for the voyageId
    search_dirs = []
    queues_dir = get_queues_dir()
    for queue_name in ["orders", "explicit", "bugs", "security", "breakdown", "defects", "high-level"]:
        qd = queues_dir / queue_name
        if qd.exists():
            search_dirs.append(qd)
    active_dir = get_admiralty_dir() / "orders" / "active"
    if active_dir.exists():
        search_dirs.append(active_dir)
    # v2.0.2: Also search completed orders (order may already be archived)
    complete_dir = get_admiralty_dir() / "orders" / "complete"
    if complete_dir.exists():
        search_dirs.append(complete_dir)

    for search_dir in search_dirs:
        for json_file in search_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                file_id = data.get("orderId") or data.get("id") or json_file.stem
                if file_id == order_id:
                    # v2.0.3: Check voyageBranch (full branch name) first, then voyageId
                    voyage_branch = data.get("voyageBranch", "")
                    if voyage_branch:
                        return voyage_branch
                    voyage_id = data.get("voyageId", "")
                    if voyage_id:
                        # Convert voyageId to branch name if not already prefixed
                        if voyage_id.startswith("voyage/"):
                            return voyage_id
                        return f"voyage/{voyage_id}"
            except Exception:
                continue

    return ""


def _get_order_title(order_id: str) -> str:
    """Look up order title from queue files."""
    queues_dir = get_queues_dir()
    for queue_name in ["orders", "explicit", "bugs", "security", "breakdown", "defects", "high-level"]:
        queue_dir = queues_dir / queue_name
        if not queue_dir.exists():
            continue
        for json_file in queue_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                file_id = data.get("orderId") or data.get("id") or json_file.stem
                if file_id == order_id:
                    return data.get("title", order_id)
            except Exception:
                continue
    return order_id


# =============================================================================
# PROCESS MANAGEMENT
# =============================================================================

def _verify_dispatcher_branch(voyage_branch: str) -> bool:
    """DEPRECATED (FTR-ADM-2026-0149): no-op since crews now run in per-voyage
    git worktrees and branch isolation is handled by prepare_voyage_worktree().

    Always returns True. Emits LEGACY_DISPATCHER_BRANCH_CHECK lifecycle event
    on the first call per dispatcher run to alert operators using legacy paths.
    """
    global _LEGACY_BRANCH_CHECK_EMITTED
    if not _LEGACY_BRANCH_CHECK_EMITTED:
        _LEGACY_BRANCH_CHECK_EMITTED = True
        try:
            write_lifecycle_event(
                "LEGACY_DISPATCHER_BRANCH_CHECK",
                "_verify_dispatcher_branch() called — this function is deprecated. "
                "Crews now run in per-voyage git worktrees. Remove the call."
            )
        except Exception:
            pass
    return True


def start_crew_process(crew_number: int, role: str, order_id: str,
                       prompt_file: str, max_iterations: int,
                       timeout: int, voyage_branch: str = "",
                       repo_path: str = "",
                       project_acronym: str = "",
                       worktree_path: str = "") -> Optional[int]:
    """Start a crew process as a fully detached independent process.

    v6.0: Mimics Ralph's Start-Process + Dispose() pattern.
    Each crew gets its own process group and console - no parent-child
    handle inheritance. This allows 5 crews to call Claude API
    concurrently without session-level rate limiting.

    Returns PID (int) or None on failure.
    """
    # Resolve crew.py: prefer script-relative (pip package), fall back to .adm/core/
    crew_py = Path(__file__).resolve().parent / "crew.py"
    if not crew_py.exists():
        crew_py = get_admiralty_dir() / "core" / "crew.py"

    if not crew_py.exists():
        print_error(f"crew.py not found at {crew_py}")
        return None

    # BUG-ADM-2026-0004: enforce voyage-branch identity before crew launch.
    # Refuses to dispatch if the dispatcher's parent shell can't be brought
    # onto the order's voyageBranch.
    if not _verify_dispatcher_branch(voyage_branch):
        print_error(
            f"Branch guard refused crew launch for {order_id} "
            f"(voyageBranch={voyage_branch or 'unset'}). Fix the branch state "
            "and re-dispatch."
        )
        return None

    # Build the crew command
    crew_cmd = [
        sys.executable, str(crew_py),
        "--crew", str(crew_number),
        "--role", role,
        "--order", order_id,
        "--prompt", prompt_file,
        "--max-iterations", str(max_iterations),
        "--timeout", str(timeout)
    ]

    try:
        # Build crew environment — inherit parent env, inject voyage branch if set.
        #
        # v3.0.0 rebrand: each value is injected under BOTH the canonical
        # MAESTRO_* name (read by maestro.env._env()) AND the legacy ADMIRALTY_*
        # name. Crews running v3.x code read MAESTRO_* first; crews/prompts that
        # still reference the legacy names keep working through the v3.x
        # back-compat window. Both forms are dropped in v4.0.
        crew_env = os.environ.copy()
        # Inject the workspace .adm path so crew.py uses the correct project dir
        # rather than resolving relative to the pip-installed package location.
        _adm_dir = str(get_admiralty_dir())
        crew_env["ADMIRALTY_DIR"] = _adm_dir
        crew_env["MAESTRO_DIR"] = _adm_dir
        _branch = voyage_branch or ACTIVE_VOYAGE_BRANCH
        if _branch:
            crew_env["ADMIRALTY_VOYAGE_BRANCH"] = _branch
            crew_env["MAESTRO_SPRINT_BRANCH"] = _branch

        # v2.0.0 / FTR-0149: Inject managed repo path so Claude CLI knows where to work.
        # worktree_path takes precedence — it is the per-voyage git worktree.
        # repo_path is the legacy clone path kept for backwards compat.
        _repo = worktree_path or repo_path
        if _repo:
            crew_env["ADMIRALTY_REPO_PATH"] = _repo
            crew_env["MAESTRO_REPO_PATH"] = _repo

        # v2.0.5: Inject project acronym for multi-project awareness
        # Resolved from order data's 'project' field, falling back to default
        _project = project_acronym or os.environ.get("MAESTRO_PROJECT") or os.environ.get("ADMIRALTY_PROJECT", "OTM")
        crew_env["ADMIRALTY_PROJECT"] = _project
        crew_env["MAESTRO_PROJECT"] = _project

        # Merge crew-specific env vars into the scrubbed env by passing them
        # as ADMIRALTY_* vars (all of which are on the allowlist) — the rest
        # of crew_env is redundant because sandbox already includes them.
        # We pass crew_env explicitly via env= so that the existing ADMIRALTY_*
        # injections (ADMIRALTY_DIR, ADMIRALTY_VOYAGE_BRANCH, etc.) are forwarded.
        # FTR-0149: use worktree_path as cwd when available (crew boots inside its
        # dedicated worktree); fall back to base dir for legacy/no-worktree paths.
        crew_cwd = worktree_path if worktree_path else str(get_base_dir())

        if os.name == 'nt':
            # v6.0: Background mode - no visible console window
            # DETACHED_PROCESS: No console allocated (runs silently)
            # CREATE_NEW_PROCESS_GROUP: Own process group (Ctrl+C isolation)
            # Monitor fleet via fleet_monitor.py instead of crew windows
            # Crew log: .admiralty/crews/crewN/crew.log (stdout/stderr)
            # Crew output: .admiralty/crews/crewN/output_N.txt (from Claude)
            flags = DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP

            # Open log file for crew stdout/stderr (stays open via inherited handle)
            log_path = get_crew_dir(crew_number) / "crew.log"
            log_path.parent.mkdir(parents=True, exist_ok=True)
            log_fh = open(str(log_path), 'w', encoding='utf-8')

            proc = _spawn(
                crew_cmd,
                identity="fleet_runner",
                workspace=get_base_dir(),
                creationflags=flags,
                stdout=log_fh,
                stderr=subprocess.STDOUT,
                stdin=subprocess.DEVNULL,
                cwd=crew_cwd,
                env=crew_env,
            )
            # Don't close log_fh yet - the child process inherits the fd
            # Store it so we can close after confirming launch
            _CREW_LOG_HANDLES[crew_number] = log_fh
        else:
            proc = _spawn(
                crew_cmd,
                identity="fleet_runner",
                workspace=get_base_dir(),
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                cwd=crew_cwd,
                start_new_session=True,  # Unix equivalent: own process group
                env=crew_env,
            )

        pid = proc.pid

        # Save PID to file for cleanup capability
        pid_file = get_crew_dir(crew_number) / "pid.txt"
        pid_file.parent.mkdir(parents=True, exist_ok=True)
        pid_file.write_text(str(pid), encoding='utf-8')

        # CRITICAL: Release the Popen object immediately (like Ralph's $proc.Dispose())
        # This severs the parent-child relationship
        del proc

        # Give it a moment to start
        time.sleep(1)

        # Verify it's running via PID check (not proc.poll())
        if not is_process_alive(pid):
            print_error(f"Crew {crew_number} process exited immediately")
            # Close log handle on failure
            if crew_number in _CREW_LOG_HANDLES:
                try: _CREW_LOG_HANDLES.pop(crew_number).close()
                except: pass
            return None

        # Close parent's copy of log handle - child has its own inherited copy
        if crew_number in _CREW_LOG_HANDLES:
            try: _CREW_LOG_HANDLES.pop(crew_number).close()
            except: pass

        return pid

    except Exception as e:
        print_error(f"Failed to start Crew {crew_number}: {e}")
        if crew_number in _CREW_LOG_HANDLES:
            try: _CREW_LOG_HANDLES.pop(crew_number).close()
            except: pass
        return None

def is_process_alive(pid: int) -> bool:
    """Check if a process with the given PID is still running.

    Uses ctypes OpenProcess on Windows for reliability (works from cmd.exe AND Git Bash).
    The old tasklist /FI approach fails from Git Bash because it translates /FI to a path.
    Falls back to os.kill(0) on other platforms.
    """
    if pid <= 0:
        return False
    try:
        if os.name == 'nt':
            import ctypes
            PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            STILL_ACTIVE = 259
            kernel32 = ctypes.windll.kernel32
            handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
            if handle == 0:
                return False  # Can't open = doesn't exist or no access
            try:
                exit_code = ctypes.c_ulong()
                if kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code)):
                    return exit_code.value == STILL_ACTIVE
                return False
            finally:
                kernel32.CloseHandle(handle)
        else:
            os.kill(pid, 0)  # Signal 0 = existence check
            return True
    except (ProcessLookupError, PermissionError, OSError):
        return False


def read_crew_pid(crew_number: int) -> Optional[int]:
    """Read crew PID from pid.txt file."""
    pid_file = get_crew_dir(crew_number) / "pid.txt"
    if pid_file.exists():
        try:
            return int(pid_file.read_text(encoding='utf-8').strip())
        except (ValueError, IOError):
            return None
    return None


def save_fleet_state():
    """Save current fleet state for crash recovery."""
    global FLEET_STATE_FILE

    if not FLEET_STATE_FILE:
        FLEET_STATE_FILE = get_admiralty_dir() / "fleet-runner-state.json"

    state = {
        "pids": {},
        "timestamp": datetime.now().isoformat(),
        "status": "RUNNING"
    }

    # Collect PIDs from active tracking and pid.txt files
    for crew_num in range(1, 6):
        pid = ACTIVE_PROCESSES.get(crew_num)
        if not pid:
            pid = read_crew_pid(crew_num)
        if pid and is_process_alive(pid):
            state["pids"][str(crew_num)] = pid

    try:
        FLEET_STATE_FILE.write_text(json.dumps(state, indent=2), encoding='utf-8')
    except:
        pass

def cleanup_fleet(reason: str = "shutdown"):
    """Clean up all fleet processes."""
    global SHUTDOWN_REQUESTED
    SHUTDOWN_REQUESTED = True

    print(f"\n  {C.YELLOW}Cleaning up fleet ({reason})...{C.RESET}")

    # Kill by tracked PIDs
    for crew_num, pid in list(ACTIVE_PROCESSES.items()):
        if pid and is_process_alive(pid):
            try:
                if os.name == 'nt':
                    subprocess.run(
                        ['taskkill', '/F', '/T', '/PID', str(pid)],
                        capture_output=True, timeout=5
                    )
                else:
                    os.kill(pid, 9)
                print_info(f"Stopped Crew {crew_num} (PID {pid})")
            except:
                pass

    # Also check pid.txt files for any crews not in ACTIVE_PROCESSES
    for crew_num in range(1, 6):
        if crew_num not in ACTIVE_PROCESSES:
            pid = read_crew_pid(crew_num)
            if pid and is_process_alive(pid):
                try:
                    if os.name == 'nt':
                        subprocess.run(
                            ['taskkill', '/F', '/T', '/PID', str(pid)],
                            capture_output=True, timeout=5
                        )
                    print_info(f"Stopped orphaned Crew {crew_num} (PID {pid})")
                except:
                    pass

    ACTIVE_PROCESSES.clear()

    # Clear fleet state file
    if FLEET_STATE_FILE and FLEET_STATE_FILE.exists():
        try:
            FLEET_STATE_FILE.unlink()
        except:
            pass

    print(f"  {C.GREEN}Cleanup complete.{C.RESET}\n")

def signal_handler(signum, frame):
    """Handle interrupt signals."""
    cleanup_fleet("user interrupt")
    sys.exit(0)


# =============================================================================
# STATUS DISPLAY
# =============================================================================

def read_crew_state(crew_number: int) -> Optional[Dict[str, Any]]:
    """Read crew state from file."""
    state_file = get_crew_dir(crew_number) / "state.json"
    if state_file.exists():
        try:
            return json.loads(state_file.read_text(encoding='utf-8'))
        except:
            return None
    return None

    # Legacy manifest-mode print_status_board removed in v2.0.4


# =============================================================================
# WAVE SEQUENCING v4.0
# =============================================================================

def ring_bell():
    """Ring the bell - voyage complete!"""
    print()
    print(f"  {C.GREEN}{C.BOLD}{'='*70}")
    print(f"  🔔🔔🔔  {current_persona().term('sprint').upper()} COMPLETE!  🔔🔔🔔")
    print(f"  {'='*70}{C.RESET}")
    print()
    try:
        import winsound
        # Three ascending bell tones for voyage complete
        winsound.Beep(800, 300)
        winsound.Beep(1000, 300)
        winsound.Beep(1200, 500)
    except Exception:
        pass


def ring_crew_bell(crew_num: int, order_id: str):
    """Ring a single bell - crew order complete!"""
    crew_name = CREW_NAMES.get(crew_num, f"Crew {crew_num}")
    print(f"  {C.GREEN}🔔 BELL - {crew_name} completed {order_id}{C.RESET}")
    try:
        import winsound
        winsound.Beep(1000, 200)
    except Exception:
        pass


def run_post_voyage_matrix_update():
    """v8.6: Post-voyage — refresh REQUIREMENTS-MATRIX.md from current data.

    Runs .admiralty/tools/update-matrix.py to sync the matrix with
    _INDEX.md (specifications) and TRACEABILITY-REPORT.md (scanner counts).
    Non-blocking: logs warning on failure but does not halt the dispatcher.
    """
    update_script = get_admiralty_dir() / "tools" / "update-matrix.py"
    if not update_script.exists():
        print_warn("Post-voyage matrix update skipped — update-matrix.py not found")
        return

    print_info("Post-voyage: Refreshing REQUIREMENTS-MATRIX.md...")
    try:
        result = subprocess.run(
            [sys.executable, str(update_script)],
            capture_output=True, text=True, timeout=60,
            cwd=str(get_admiralty_dir().parent)
        )
        if result.returncode == 0:
            print_ok("Requirements matrix updated successfully")
            write_lifecycle_event("POST-VOYAGE", "REQUIREMENTS-MATRIX.md refreshed by update-matrix.py")
        else:
            print_warn(f"Matrix update exited with code {result.returncode}")
            if result.stderr:
                print_warn(f"  {result.stderr.strip()[:200]}")
    except subprocess.TimeoutExpired:
        print_warn("Matrix update timed out (60s) — skipping")
    except Exception as e:
        print_warn(f"Matrix update failed: {e}")


def run_post_voyage_pr_creation():
    """v8.13: Post-voyage -- auto-create PRs from voyage branch to main.

    Uses _SESSION_TARGET_REPOS (populated during dispatch) to know which repos
    had orders dispatched this session. Only checks those repos for commits
    ahead of the project's resolved default branch (e.g. `master` for PSG,
    `main` for the framework), avoiding API rate limits from scanning all
    historical orders.

    BUG-MSO-2026-0016 (v2.8.2): both the COMPARE check and the `gh pr create`
    call now resolve the base via `_get_default_branch_for_repo()` rather
    than hardcoded `main`. Operators on non-main-default repos (PSG) get
    PRs opened against the correct base.

    v2.0.2: Uses per-repo voyage branches from _SESSION_REPO_BRANCHES instead of
    the global ACTIVE_VOYAGE_BRANCH, supporting mixed-voyage dispatch sessions.

    Non-blocking: logs warning on failure but does not halt the dispatcher.
    Skips repos where no voyage branch exists or where a PR already exists.
    """
    # v2.0.2: Check if we have any per-repo branches OR a global branch
    if not ACTIVE_VOYAGE_BRANCH and not _SESSION_REPO_BRANCHES:
        print_warn("Post-voyage PR creation skipped -- no voyage branch set")
        return

    org = _load_workspace_org()

    # Use session-tracked repos (populated during dispatch_crew)
    if not _SESSION_TARGET_REPOS:
        print_info("Post-voyage PR creation: no repos dispatched this session")
        return

    order_summaries = _SESSION_TARGET_REPOS
    target_repos = set(order_summaries.keys())

    print_info(f"Post-voyage: Checking {len(target_repos)} repo(s) dispatched this session for PRs...")

    created = 0
    skipped = 0
    failed = 0

    for repo in sorted(target_repos):
        full_repo = f"{org}/{repo}"
        # v2.0.2: Per-repo voyage branch resolution
        repo_branch = _SESSION_REPO_BRANCHES.get(repo, ACTIVE_VOYAGE_BRANCH)
        if not repo_branch:
            print_info(f"  {repo}: no voyage branch known -- skipping")
            skipped += 1
            continue
        branch_ref = repo_branch.replace("refs/heads/", "")

        try:
            # v8.13: Small delay between repos to avoid GitHub secondary rate limits
            time.sleep(1)

            # Check if voyage branch exists on this repo
            check = subprocess.run(
                ["gh", "api", f"repos/{full_repo}/branches/{branch_ref}",
                 "--jq", ".name"],
                capture_output=True, text=True, timeout=30
            )
            if check.returncode != 0 or not check.stdout.strip():
                print_info(f"  {repo}: no voyage branch -- skipping")
                skipped += 1
                continue

            # Check if PR already exists for this branch
            pr_check = subprocess.run(
                ["gh", "pr", "list", "--repo", full_repo,
                 "--head", branch_ref, "--state", "open", "--json", "number"],
                capture_output=True, text=True, timeout=30
            )
            if pr_check.returncode == 0 and pr_check.stdout.strip() not in ("", "[]"):
                print_info(f"  {repo}: PR already exists -- skipping")
                skipped += 1
                continue

            # BUG-ADM-2026-0013: resolve base branch from project registry —
            # PSG uses `master`, framework uses `main`. Hardcoded `main` here
            # silently 404'd on PSG, so PRs never got opened.
            default_branch = _get_default_branch_for_repo(repo)

            # Check if branch has commits ahead of the project's default branch
            compare = subprocess.run(
                ["gh", "api", f"repos/{full_repo}/compare/{default_branch}...{branch_ref}",
                 "--jq", ".ahead_by"],
                capture_output=True, text=True, timeout=30
            )
            ahead_by = 0
            if compare.returncode == 0:
                try:
                    ahead_by = int(compare.stdout.strip())
                except ValueError:
                    pass
            else:
                print_warn(f"  {repo}: compare API failed against {default_branch} (rc={compare.returncode}) -- {compare.stderr.strip()[:100]}")

            if ahead_by == 0:
                print_info(f"  {repo}: no commits ahead of {default_branch} -- skipping")
                skipped += 1
                continue

            # v8.13.1: Check actual file diff to avoid empty PRs
            # (ahead_by can be > 0 for commits already merged via previous voyage)
            diff_check = subprocess.run(
                ["gh", "api", f"repos/{full_repo}/compare/{default_branch}...{branch_ref}",
                 "--jq", ".files | length"],
                capture_output=True, text=True, timeout=30
            )
            changed_files = 0
            if diff_check.returncode == 0:
                try:
                    changed_files = int(diff_check.stdout.strip())
                except ValueError:
                    pass

            if changed_files == 0:
                print_info(f"  {repo}: {ahead_by} commit(s) but 0 changed files -- skipping (already merged)")
                skipped += 1
                continue

            # Build PR body from order summaries
            orders = order_summaries.get(repo, [])
            body_lines = [f"## Summary", ""]
            body_lines.append(f"Voyage branch `{branch_ref}` with {ahead_by} commit(s).")
            body_lines.append("")
            body_lines.append("### Orders Completed")
            for t in orders[:20]:  # Cap at 20 to avoid huge PR bodies
                body_lines.append(f"- {t}")
            body_lines.append("")
            body_lines.append("## Test plan")
            body_lines.append("- [ ] CI checks pass")
            body_lines.append("- [ ] Code review completed")
            body_lines.append("")

            pr_body = "\n".join(body_lines)
            pr_title = f"[{branch_ref}] {repo} ({len(orders)} order(s))"
            if len(pr_title) > 70:
                pr_title = f"[{branch_ref}] {repo}"

            # Create the PR
            pr_result = subprocess.run(
                ["gh", "pr", "create",
                 "--repo", full_repo,
                 "--base", default_branch,
                 "--head", branch_ref,
                 "--title", pr_title,
                 "--body", pr_body],
                capture_output=True, text=True, timeout=60
            )

            if pr_result.returncode == 0:
                pr_url = pr_result.stdout.strip()
                print_ok(f"  {repo}: PR created -> {pr_url}")
                write_lifecycle_event("POST-VOYAGE", f"PR created for {repo}: {pr_url}")
                created += 1
            else:
                err = pr_result.stderr.strip()[:200]
                print_warn(f"  {repo}: PR creation failed -- {err}")
                failed += 1

        except subprocess.TimeoutExpired:
            print_warn(f"  {repo}: timeout -- skipping")
            failed += 1
        except Exception as e:
            print_warn(f"  {repo}: error -- {e}")
            failed += 1

    print_info(f"Post-voyage PRs: {created} created, {skipped} skipped, {failed} failed")
    write_lifecycle_event("POST-VOYAGE", f"Auto-PR: {created} created, {skipped} skipped, {failed} failed")


    # Legacy manifest-mode wave functions removed in v2.0.4


# =============================================================================
# AUTO-DISPATCHER v5.2
# =============================================================================

def get_queues_dir() -> Path:
    """Get the queues directory."""
    return get_admiralty_dir() / "queues"


def scan_requests_queue() -> List[Dict[str, Any]]:
    """Scan requests queue for pending items. Returns list sorted by priority."""
    requests = []
    requests_dir = get_queues_dir() / "requests"

    # Priority order for request types
    request_priority = {
        "planning": 1,      # NAV planning - highest priority
        "investigation": 2, # LKT investigation
        "qa": 3,            # BOS QA
        "security-scan": 4, # LKT security
        "documentation": 5  # SCR documentation
    }

    # Role mapping for request types
    request_roles = {
        "planning": "NAV",
        "investigation": "LKT",
        "qa": "BOS",
        "security-scan": "LKT",
        "documentation": "SCR"
    }

    if not requests_dir.exists():
        return []

    for subdir in requests_dir.iterdir():
        if subdir.is_dir():
            req_type = subdir.name
            for json_file in subdir.glob("*.json"):
                try:
                    data = json.loads(json_file.read_text(encoding='utf-8'))
                    status = data.get("status", "PENDING")
                    if status == "PENDING":
                        # v8.6: Resolve ID and title consistently
                        req_id = data.get("orderId") or data.get("id") or json_file.stem
                        req_title = data.get("title") or data.get("description", "")
                        if not req_title:
                            parts = req_id.split("-", 1)
                            req_title = parts[1] if len(parts) > 1 else req_id

                        requests.append({
                            "type": "REQUEST",
                            "subtype": req_type,
                            "id": req_id,
                            "title": req_title,
                            "priority": request_priority.get(req_type, 10),
                            "role": request_roles.get(req_type, "NAV"),
                            "path": str(json_file),
                            "data": data
                        })
                except Exception as e:
                    print_warn(f"Error reading {json_file}: {e}")

    # Sort by priority (lower = higher priority)
    return sorted(requests, key=lambda x: x["priority"])


def scan_orders_queue() -> List[Dict[str, Any]]:
    """Scan orders queue for pending items. Returns list sorted by priority."""
    orders = []
    orders_dir = get_queues_dir() / "orders"

    # Priority mapping
    priority_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "NORMAL": 2}

    # Order type to role mapping (default role)
    order_roles = {
        "FIX": "SHP",
        "BUG": "SHP",
        "TEST": "SHP",  # Writing tests is SHP work
        "SEC": "LKT",   # Security starts with LKT
        "FTR": "NAV",   # Features start with NAV planning
        "RFT": "SHP",   # Refactor is SHP work
        "DOC": "SCR",   # Documentation is SCR work
        "INV": "LKT"    # Investigation is LKT work
    }

    if not orders_dir.exists():
        return []

    for json_file in orders_dir.glob("*.json"):
        try:
            data = json.loads(json_file.read_text(encoding='utf-8'))
            status = data.get("status", "PENDING")
            if status == "PENDING":
                # v8.6.1: Backwards-compat — check both "orderType" and "type" fields
                order_type = data.get("orderType") or data.get("type", "FIX")
                # Normalize: if "type" was "ORDER", it's not a valid orderType — use "FIX"
                if order_type == "ORDER":
                    order_type = data.get("orderType", "FIX")
                priority_str = data.get("priority", "MEDIUM")
                # v8.8: Check targetRole, role, roleSequence[0], then infer from orderType
                target_role = data.get("targetRole") or data.get("role") or ""
                if not target_role:
                    seq = data.get("roleSequence", [])
                    target_role = seq[0] if seq else order_roles.get(order_type, "SHP")

                # v8.6: Resolve ID and title consistently
                item_id = data.get("orderId") or data.get("id") or json_file.stem
                item_title = data.get("title") or data.get("description", "")
                if not item_title:
                    parts = item_id.split("-", 1)
                    item_title = parts[1] if len(parts) > 1 else item_id

                orders.append({
                    "type": "ORDER",
                    "subtype": order_type,
                    "id": item_id,
                    "title": item_title,
                    "priority": priority_order.get(priority_str, 2),
                    "role": target_role,
                    "path": str(json_file),
                    "data": data
                })
        except Exception as e:
            print_warn(f"Error reading {json_file}: {e}")

    # Sort by priority (lower = higher priority)
    return sorted(orders, key=lambda x: x["priority"])


# =============================================================================
# v8.2: Role Sequence Gate Enforcement
# =============================================================================

# Loaded from order templates at startup — maps orderType to roleSequence
ROLE_SEQUENCES: Dict[str, List[str]] = {}


def load_role_sequences():
    """Load roleSequence from all order templates (v8.2).

    Populates ROLE_SEQUENCES dict: {"FTR": ["NAV","SHP","BOS","SCR","LKT","COX"], ...}
    Called once at dispatcher startup.
    """
    global ROLE_SEQUENCES
    templates_dir = get_admiralty_dir() / "orders" / "templates"
    if not templates_dir.exists():
        return
    for f in templates_dir.glob("*-template.json"):
        try:
            data = json.loads(f.read_text(encoding='utf-8'))
            meta = data.get("_meta", {})
            order_type = meta.get("orderType", "")
            sequence = meta.get("roleSequence", [])
            if order_type and sequence:
                ROLE_SEQUENCES[order_type] = sequence
        except Exception:
            pass


def resolve_order_fields(data: Dict[str, Any]) -> tuple:
    """v8.6.1: Resolve targetRole and orderType from order data with backwards-compat fallback.

    Orders may use "targetRole" or "role", and "orderType" or "type".
    This helper normalizes both to avoid role misassignment.

    Returns: (target_role: str, order_type: str)
    """
    order_type = data.get("orderType") or data.get("type", "")
    if order_type == "ORDER":
        order_type = data.get("orderType", "")
    target_role = resolve_role_code(data.get("targetRole") or data.get("role", ""))
    return target_role, order_type


def build_voyage_role_status() -> Dict[str, Dict[str, str]]:
    """Build per-voyage map of role completion status (v8.2).

    Scans complete archive and active queues to determine, for each voyage,
    which roles have COMPLETE, IN_PROGRESS, or PENDING orders.

    Returns: {voyageId: {role: "COMPLETE"|"IN_PROGRESS"|"PENDING"}}
    Best status wins: COMPLETE > IN_PROGRESS > PENDING.
    Also tracks the primary orderType per voyage for sequence lookup.
    """
    STATUS_RANK = {"COMPLETE": 3, "IN_PROGRESS": 2, "PENDING": 1}
    voyage_roles: Dict[str, Dict[str, str]] = {}  # {voyageId: {role: status}}
    voyage_types: Dict[str, str] = {}  # {voyageId: primary orderType}

    def update_voyage(voyage_id: str, role: str, status: str, order_type: str):
        if not voyage_id or not role:
            return
        if voyage_id not in voyage_roles:
            voyage_roles[voyage_id] = {}
        current = voyage_roles[voyage_id].get(role, "")
        if STATUS_RANK.get(status, 0) > STATUS_RANK.get(current, 0):
            voyage_roles[voyage_id][role] = status
        # Track primary order type (template-defined types take precedence)
        if order_type in ROLE_SEQUENCES:
            voyage_types[voyage_id] = order_type

    admiralty = get_admiralty_dir()

    # Scan completed orders archive
    complete_dir = admiralty / "orders" / "complete"
    if complete_dir.exists():
        for f in complete_dir.glob("*.json"):
            try:
                data = json.loads(f.read_text(encoding='utf-8'))
                vid = data.get("voyageId", "")
                role, otype = resolve_order_fields(data)
                status = data.get("status", "COMPLETE")
                update_voyage(vid, role, status, otype)
            except Exception:
                pass

    # Scan all active queue directories
    queues_dir = get_queues_dir()
    queue_dirs = ["explicit", "security", "bugs", "orders", "defects",
                  "breakdown", "high-level"]
    for qname in queue_dirs:
        qpath = queues_dir / qname
        if not qpath.exists():
            continue
        for f in qpath.glob("*.json"):
            try:
                data = json.loads(f.read_text(encoding='utf-8'))
                vid = data.get("voyageId", "")
                role, otype = resolve_order_fields(data)
                status = data.get("status", "PENDING")
                update_voyage(vid, role, status, otype)
            except Exception:
                pass

    # Scan requests subdirectories
    requests_dir = queues_dir / "requests"
    if requests_dir.exists():
        for subdir in requests_dir.iterdir():
            if not subdir.is_dir():
                continue
            for f in subdir.glob("*.json"):
                try:
                    data = json.loads(f.read_text(encoding='utf-8'))
                    vid = data.get("voyageId", "")
                    role, otype = resolve_order_fields(data)
                    status = data.get("status", "PENDING")
                    update_voyage(vid, role, status, otype)
                except Exception:
                    pass

    # Scan orders/active/ directory (orders tracked but may not be in queues yet)
    active_dir = admiralty / "orders" / "active"
    if active_dir.exists():
        for f in active_dir.glob("*.json"):
            try:
                data = json.loads(f.read_text(encoding='utf-8'))
                vid = data.get("voyageId", "")
                role, otype = resolve_order_fields(data)
                status = data.get("status", "PENDING")
                update_voyage(vid, role, status, otype)
            except Exception:
                pass

    # Attach primary type to each voyage's role map (under special key)
    for vid, ptype in voyage_types.items():
        if vid in voyage_roles:
            voyage_roles[vid]["__primaryType__"] = ptype

    return voyage_roles


def check_role_sequence_gate(order_data: Dict[str, Any],
                             voyage_roles: Dict[str, str]) -> tuple:
    """Check if prior roles in the sequence have completed for this voyage (v8.3.1).

    Returns (passed: bool, missing_roles: List[str])

    Pass-through cases (always pass):
    - No voyageId on the order
    - No roleSequence found for this order type
    - Single-role sequence (INV, DOC)
    - targetRole is the FIRST role in the sequence

    v8.3.1: Only enforce gate on roles that have orders in the voyage.
    If a prior role has no orders at all (not in voyage_roles), it is
    treated as not applicable and skipped. This prevents voyages without
    SCR/LKT orders from blocking COX dispatch.
    """
    # v8.6.1: Use resolve helper for backwards-compat
    target_role, resolved_type = resolve_order_fields(order_data)
    if not target_role:
        return True, []

    # Determine the role sequence to enforce
    # First try the order's own _meta, then fall back to template via orderType,
    # then fall back to the voyage's primary type
    sequence = None
    meta = order_data.get("_meta", {})
    if meta.get("roleSequence"):
        sequence = meta["roleSequence"]
    else:
        order_type = resolved_type
        if order_type in ROLE_SEQUENCES:
            sequence = ROLE_SEQUENCES[order_type]
        else:
            # Look up from voyage's primary type
            primary_type = voyage_roles.get("__primaryType__", "")
            if primary_type in ROLE_SEQUENCES:
                sequence = ROLE_SEQUENCES[primary_type]

    if not sequence or len(sequence) <= 1:
        return True, []  # Single-role or unknown — pass through

    # Find target role position in sequence
    if target_role not in sequence:
        return True, []  # Role not in known sequence — pass through

    role_index = sequence.index(target_role)
    if role_index == 0:
        return True, []  # First role in sequence — no prior roles to check

    # v8.9: If this order has already been advanced past the first role,
    # prior roles have already completed FOR THIS ORDER — pass through.
    # Checking voyage-wide role status would incorrectly block orders that
    # are mid-sequence when other orders in the same voyage are still at
    # earlier roles (e.g., FTR-0139 at SHP blocking BUG-0141 at BOS).
    first_role = sequence[0]
    if target_role != first_role:
        return True, []  # Already advanced — prior roles implicitly complete

    # Check PRIOR roles in the sequence that have orders in this voyage
    # v8.3.1: Roles with no orders (not in voyage_roles) are skipped —
    # only block on roles that exist but aren't COMPLETE yet
    missing = []
    for i in range(role_index):
        prior_role = sequence[i]
        prior_status = voyage_roles.get(prior_role, "")
        if not prior_status:
            continue  # No orders for this role in voyage — not applicable
        if prior_status != "COMPLETE":
            missing.append(f"{prior_role} ({prior_status})")

    return len(missing) == 0, missing


# =============================================================================
# v7.0: Dependency-Aware Dispatch
# =============================================================================

def check_dependencies_satisfied(order_data: Dict[str, Any]) -> tuple:
    """Check if all dependencies for an order are satisfied (v7.0, v8.7).

    Returns (satisfied: bool, waiting_on: List[str])
    An order is dispatchable only when ALL dependencies are archived.

    v8.7: Accept COMPLETE or STALLED as satisfying a dependency.
    STALLED means the crew hit MAX_ITERATIONS but produced partial work.
    The QM wired the dependency chain deliberately, so downstream orders
    should proceed — they can build on or remediate the partial output.
    """
    depends_on = order_data.get("dependsOn", [])
    if not depends_on:
        return True, []

    # v8.7: Statuses that satisfy a dependency (order is in archive and did work)
    SATISFYING_STATUSES = {"COMPLETE", "STALLED", "MAX_ITERATIONS"}

    archive_dir = get_admiralty_dir() / "orders" / "complete"
    waiting_on = []

    for dep_id in depends_on:
        satisfied = False
        # Check in completed orders archive
        dep_file = archive_dir / f"{dep_id}.json"
        if dep_file.exists():
            try:
                dep_data = json.loads(dep_file.read_text(encoding='utf-8'))
                if dep_data.get("status") in SATISFYING_STATUSES:
                    satisfied = True
            except Exception:
                pass
        if not satisfied:
            waiting_on.append(dep_id)

    return len(waiting_on) == 0, waiting_on


def detect_circular_dependencies(items: List[Dict[str, Any]]) -> List[List[str]]:
    """Detect circular dependency chains among pending items (v7.0).

    Uses iterative DFS. Returns list of cycles found.
    """
    # Build adjacency map
    dep_graph = {}
    for item in items:
        item_id = item.get("id", "")
        deps = item.get("data", {}).get("dependsOn", [])
        if deps:
            dep_graph[item_id] = deps

    if not dep_graph:
        return []

    cycles = []
    visited = set()
    rec_stack = set()

    for start_node in list(dep_graph.keys()):
        if start_node in visited:
            continue

        stack = [(start_node, iter(dep_graph.get(start_node, [])))]
        path = [start_node]
        rec_stack.add(start_node)

        while stack:
            node, neighbors = stack[-1]
            try:
                neighbor = next(neighbors)
                if neighbor in rec_stack:
                    # Found cycle
                    if neighbor in path:
                        cycle_start = path.index(neighbor)
                        cycles.append(path[cycle_start:] + [neighbor])
                elif neighbor not in visited and neighbor in dep_graph:
                    rec_stack.add(neighbor)
                    path.append(neighbor)
                    stack.append((neighbor, iter(dep_graph.get(neighbor, []))))
            except StopIteration:
                rec_stack.discard(node)
                if path:
                    path.pop()
                stack.pop()
                visited.add(node)

    return cycles


# v7.0: Track items waiting on dependencies (for display, not dispatched)
WAITING_ON_DEPS: Dict[str, List[str]] = {}


def scan_all_queues() -> List[Dict[str, Any]]:
    """Scan ALL queue directories with tiered priority (v7.0).

    Priority tiers (lower = higher priority):
    T0: explicit/     (0)   - Captain's direct orders
    T1: security/     (100) - Security issues (LKT-generated)
    T2: bugs/         (200) - Bug reports (any crew)
    T3: requests/     (300) - Service requests
    T4: orders/       (400) - Standard orders
    T5: defects/      (500) - QA findings (BOS-generated)
    T6: breakdown/    (600) - Sub-orders from breakdown
    T7: high-level/   (700) - Needs NAV breakdown first
    """
    global WAITING_ON_DEPS
    WAITING_ON_DEPS = {}
    all_items = []
    queues_dir = get_queues_dir()

    # Priority sub-sort within tier
    priority_sub = {"CRITICAL": 0, "HIGH": 10, "MEDIUM": 20, "NORMAL": 20, "LOW": 30}

    # Order type to default role mapping
    order_roles = {
        "FIX": "SHP", "BUG": "SHP", "TEST": "SHP", "SEC": "LKT",
        "FTR": "NAV", "RFT": "SHP", "DOC": "SCR", "INV": "LKT"
    }

    # Tier definitions: (queue_name, tier_offset, item_type, default_role_override)
    tier_configs = [
        ("explicit",   0,   "EXPLICIT",   None),
        ("security",   100, "SECURITY",   "SHP"),
        ("bugs",       200, "BUG",        "SHP"),
        ("orders",     400, "ORDER",      None),
        ("defects",    500, "DEFECT",     "SHP"),
        ("breakdown",  600, "BREAKDOWN",  None),
        ("high-level", 700, "HIGH-LEVEL", "NAV"),
    ]

    for queue_name, tier_offset, item_type, default_role in tier_configs:
        queue_path = queues_dir / queue_name
        if not queue_path.exists():
            continue
        for json_file in queue_path.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                # v2.0.3: Normalize defect fields to standard order fields
                status = data.get("status", "PENDING")
                if queue_name == "defects":
                    # Defects use OPEN/CLOSED; treat OPEN as dispatchable
                    if status not in ("OPEN", "PENDING"):
                        continue
                    # Map defect-specific fields to standard order fields
                    if "defectId" in data and "orderId" not in data:
                        data["orderId"] = data["defectId"]
                    if "affectedRepo" in data and "targetRepo" not in data:
                        data["targetRepo"] = data["affectedRepo"]
                    if "affectedBranch" in data and "voyageBranch" not in data:
                        data["voyageBranch"] = data["affectedBranch"]
                    if "severity" in data and "priority" not in data:
                        data["priority"] = data["severity"]
                else:
                    if status != "PENDING":
                        continue

                priority_str = data.get("priority", "MEDIUM")
                sub_pri = priority_sub.get(priority_str, 20)
                # v8.6.1: Use resolve helper for backwards-compat
                resolved_role, resolved_type = resolve_order_fields(data)
                order_type = resolved_type or "FIX"

                # default_role is a fallback, not an override — order's own targetRole/role wins
                target_role = resolved_role or default_role or order_roles.get(order_type, "SHP")

                # v8.6: Resolve ID from orderId or id or filename stem
                item_id = data.get("orderId") or data.get("id") or json_file.stem
                # v8.6: Derive title from data or order ID
                item_title = data.get("title") or data.get("description", "")
                if not item_title:
                    # Derive readable title from order ID (e.g. SHP-LOCK-091A → LOCK-091A)
                    parts = item_id.split("-", 1)
                    item_title = parts[1] if len(parts) > 1 else item_id

                all_items.append({
                    "type": item_type,
                    "subtype": order_type,
                    "id": item_id,
                    "title": item_title,
                    "priority": tier_offset + sub_pri,
                    "role": target_role,
                    "path": str(json_file),
                    "data": data,
                    "queue": queue_name,
                })
            except Exception as e:
                print_warn(f"Error reading {json_file}: {e}")

    # Scan requests subdirectories (tier 300)
    requests_dir = queues_dir / "requests"
    request_roles = {
        "planning": "NAV", "investigation": "LKT", "qa": "BOS",
        "security-scan": "LKT", "documentation": "SCR"
    }
    if requests_dir.exists():
        for subdir_name, role in request_roles.items():
            subdir = requests_dir / subdir_name
            if not subdir.exists():
                continue
            for json_file in subdir.glob("*.json"):
                try:
                    data = json.loads(json_file.read_text(encoding='utf-8'))
                    if data.get("status", "PENDING") != "PENDING":
                        continue
                    priority_str = data.get("priority", "MEDIUM")
                    sub_pri = priority_sub.get(priority_str, 20)
                    # v8.6: Resolve ID and title consistently
                    req_id = data.get("orderId") or data.get("id") or json_file.stem
                    req_title = data.get("title") or data.get("description", "")
                    if not req_title:
                        parts = req_id.split("-", 1)
                        req_title = parts[1] if len(parts) > 1 else req_id

                    resolved_role, _ = resolve_order_fields(data)
                    all_items.append({
                        "type": "REQUEST",
                        "subtype": subdir_name.upper(),
                        "id": req_id,
                        "title": req_title,
                        "priority": 300 + sub_pri,
                        "role": resolved_role or role,
                        "path": str(json_file),
                        "data": data,
                        "queue": f"requests/{subdir_name}",
                    })
                except Exception as e:
                    print_warn(f"Error reading {json_file}: {e}")

    # Check for circular dependencies
    cycles = detect_circular_dependencies(all_items)
    circular_ids = set()
    for cycle in cycles:
        cycle_str = " -> ".join(cycle)
        print_error(f"CIRCULAR DEPENDENCY: {cycle_str}")
        write_lifecycle_event("ERROR", f"Circular dependency: {cycle_str}")
        circular_ids.update(cycle[:-1])  # Exclude the repeated last element

    # Filter: dependency check + escalation blocking + role sequence gates
    _, blocking_voyages = scan_escalations()

    # v8.2: Build voyage role status for gate enforcement
    voyage_role_status = build_voyage_role_status() if ROLE_SEQUENCES else {}

    dispatchable = []
    for item in all_items:
        item_id = item["id"]

        # Skip circular dependency items
        if item_id in circular_ids:
            continue

        # Skip items blocked by escalation
        voyage_id = item["data"].get("voyageId", "")
        if voyage_id and voyage_id in blocking_voyages:
            WAITING_ON_DEPS[item_id] = [f"ESCALATION (voyage {voyage_id} blocked)"]
            continue

        # Check dependencies
        satisfied, waiting_on = check_dependencies_satisfied(item["data"])
        if not satisfied:
            WAITING_ON_DEPS[item_id] = waiting_on
            continue

        # v8.5: Explicit dependencies take precedence over role sequence gate.
        # If an order has dependsOn and all deps are satisfied (checked above),
        # the QM's planned execution order is authoritative — skip the generic
        # template-based role gate. This prevents deadlocks when the dependency
        # chain order differs from the template role sequence (e.g., COX before SCR).
        has_explicit_deps = bool(item["data"].get("dependsOn"))

        # v8.2: Role sequence gate — ensure prior roles completed in this voyage
        # Only enforced for orders WITHOUT explicit dependencies.
        if not has_explicit_deps and voyage_id and voyage_id in voyage_role_status:
            gate_passed, missing = check_role_sequence_gate(
                item["data"], voyage_role_status[voyage_id]
            )
            if not gate_passed:
                WAITING_ON_DEPS[item_id] = [f"ROLE GATE: {r}" for r in missing]
                continue

        dispatchable.append(item)

    return sorted(dispatchable, key=lambda x: x["priority"])


# v7.0: Stale escalation threshold (minutes) — warn Captain if escalation pending too long
ESCALATION_STALE_MINUTES = 60

def scan_escalations() -> tuple:
    """Scan escalation queue (v7.0). Returns (pending_count, blocking_voyage_ids).

    Escalations are NOT dispatched - they need human (Captain/QM) review.
    Blocking escalations hold all orders for the same voyageId.
    Stale escalations (> ESCALATION_STALE_MINUTES) are logged as warnings.
    """
    esc_dir = get_queues_dir() / "escalations"
    if not esc_dir.exists():
        return 0, set()

    pending_count = 0
    blocking_voyages = set()
    now = datetime.now()

    for json_file in esc_dir.glob("*.json"):
        try:
            data = json.loads(json_file.read_text(encoding='utf-8'))
            if data.get("status") == "PENDING":
                pending_count += 1
                esc_id = data.get("id", json_file.stem)

                # Check for stale escalation
                created_at = data.get("createdAt", "")
                if created_at:
                    try:
                        created_time = datetime.fromisoformat(created_at)
                        age_minutes = (now - created_time).total_seconds() / 60
                        if age_minutes > ESCALATION_STALE_MINUTES:
                            block_tag = " [BLOCKING]" if data.get("blocking") else ""
                            _ep = current_persona()
                            print_warn(f"STALE ESCALATION{block_tag}: {esc_id} pending for {int(age_minutes)} minutes — requires {_ep.term('userTitle')}/{_ep.term('leadTitle')} resolution!")
                            write_lifecycle_event("ESCALATION", f"STALE: {esc_id} pending {int(age_minutes)}min{block_tag}")
                    except (ValueError, TypeError):
                        pass

                if data.get("blocking") and data.get("voyageId"):
                    blocking_voyages.add(data["voyageId"])
        except Exception:
            pass

    return pending_count, blocking_voyages


def get_available_crews(max_crews: int = 2) -> List[int]:
    """Get list of available crew numbers (not currently active).

    v7.1: If a crew is in ACTIVE_PROCESSES with a dead PID and unprocessed state,
    process completion first before marking as available. This prevents orphaning orders.
    """
    available = []

    for crew_num in range(1, 6):
        # Check if there's an active process
        pid = ACTIVE_PROCESSES.get(crew_num)
        if not pid:
            pid = read_crew_pid(crew_num)
        if pid and is_process_alive(pid):
            continue  # Still running

        # v7.1 FIX: If crew is tracked in ACTIVE_PROCESSES with a dead PID,
        # ensure completion is processed before making it available
        if crew_num in ACTIVE_PROCESSES:
            state = read_crew_state(crew_num)
            status = state.get("status", "") if state else ""
            if status and status != "RUNNING":
                # Dead PID with non-RUNNING state — process completion now
                if status not in TERMINAL_STATES:
                    print_warn(f"Crew {crew_num} dead with state '{status}' in get_available_crews - treating as CRASHED")
                    write_lifecycle_event("WARN", f"Crew {crew_num} dead with state '{status}' - forced CRASHED in get_available_crews")
                process_crew_completion(crew_num)
                del ACTIVE_PROCESSES[crew_num]
            else:
                continue  # State is RUNNING or unknown — not safe to reuse yet

        # Check state file
        state = read_crew_state(crew_num)
        if state:
            status = state.get("status", "")
            if status == "RUNNING":
                continue  # State says running

        available.append(crew_num)

        # Stop once we have enough candidates
        if len(available) >= max_crews:
            break

    return available


def mark_work_item_in_progress(item: Dict[str, Any], crew_num: int):
    """Mark a work item as IN_PROGRESS."""
    try:
        path = Path(item["path"])
        data = item["data"]
        data["status"] = "IN_PROGRESS"
        data["assignedTo"] = {"crew": crew_num, "role": item["role"]}
        data["startedAt"] = datetime.now().isoformat()
        path.write_text(json.dumps(data, indent=2), encoding='utf-8')
    except Exception as e:
        print_warn(f"Could not update status for {item['id']}: {e}")


def mark_work_item_failed(item: Dict[str, Any], reason: str = "") -> None:
    """Mark a work item as FAILED so the dispatcher loop stops re-attempting it.

    BUG-ADM-2026-0008 (v2.5.5): added so dispatch_crew can fail-fast on
    misconfigured orders (e.g. SHP/BOS without a resolvable targetRepo)
    rather than spinning the queue.
    """
    try:
        path = Path(item["path"])
        data = item["data"]
        data["status"] = "FAILED"
        data["failedAt"] = datetime.now().isoformat()
        if reason:
            data["failureReason"] = reason
        path.write_text(json.dumps(data, indent=2), encoding='utf-8')
    except Exception as e:
        print_warn(f"Could not mark {item.get('id', '?')} FAILED: {e}")


def _build_repo_routing_rules(role: str, target_repo: str, docs_repo: str = "") -> str:
    """Build repo routing rules section for crew prompts (v8.10/v2.0.6).

    Enforces which repos each role can write to:
    - LKT/SCR: Reports and docs go to docs_repo ONLY (if configured), else target repo docs/
    - SHP/BOS: Code and tests go to the target service repo ONLY
    - NAV/COX: May write to both (plans touch docs, reviews touch code)
    - ALL roles: May always write to .admiralty/ (reports, handoffs, queues)

    docs_repo: optional separate documentation repo (e.g. "eml-documentation").
               If empty, SCR/LKT write to docs/ within the target repo.
    """
    # BUG-ADM-2026-0008: the previous fallback ("the target service repo") looked
    # like an unrendered placeholder and caused Sonnet 4.6 SHP crews to exit in
    # 1 iteration with no commits. The new fallback is unambiguously diagnostic
    # so an operator can see at a glance that the order is misconfigured.
    target_label = (
        f"repos/{target_repo}/" if target_repo
        else "<TARGET-REPO-NOT-RESOLVED — fix the order's `targetRepo` field "
             "or the project registry's `repo` entry>"
    )
    has_docs_repo = bool(docs_repo)
    docs_label = f"repos/{docs_repo}/" if has_docs_repo else f"{target_label}docs/"

    if has_docs_repo:
        lkt_rule = (
            f"You are a Lookout. Write ALL reports and investigation artifacts to "
            f"repos/{docs_repo}/ (following the existing folder structure). "
            f"You must NEVER create, modify, or add files to the target service repo. "
            f"You may read the target repo for investigation but must not write to it."
        )
        scr_rule = (
            f"You are a Scribe. Write ALL documentation to repos/{docs_repo}/ "
            f"(following the existing folder structure). "
            f"You must NEVER create or modify files in target service repos."
        )
        lkt_cannot = ["target"]
        scr_cannot = ["target"]
        shp_cannot = [docs_repo]
        bos_cannot = [docs_repo]
    else:
        lkt_rule = (
            f"You are a Lookout. Write ALL reports and investigation artifacts to "
            f"the docs/ directory within the target repo (`{target_label}docs/`). "
            f"You may read all files in the target repo for investigation."
        )
        scr_rule = (
            f"You are a Scribe. Write ALL documentation to the target repo (`{target_label}`). "
            f"Use the docs/ subdirectory for documentation files unless the order specifies otherwise."
        )
        lkt_cannot = []
        scr_cannot = []
        shp_cannot = []
        bos_cannot = []

    ROLE_REPO_RULES = {
        "LKT": {
            "rule": lkt_rule,
            "cannot_write_labels": [f"`{target_label}`"] if lkt_cannot else [],
        },
        "SCR": {
            "rule": scr_rule,
            "cannot_write_labels": [f"`{target_label}`"] if scr_cannot else [],
        },
        "SHP": {
            "rule": (
                f"You are a Shipwright. Write ALL code changes to the target service repo. "
                + (f"You must NEVER create or modify files in repos/{docs_repo}/. " if has_docs_repo else "")
                + "Documentation changes are the Scribe's responsibility."
            ),
            "cannot_write_labels": [f"`repos/{docs_repo}/`"] if shp_cannot else [],
        },
        "BOS": {
            "rule": (
                f"You are a Bosun. Write ALL test code and QA artifacts to the target service repo. "
                + (f"You must NEVER create or modify files in repos/{docs_repo}/." if has_docs_repo else "")
            ),
            "cannot_write_labels": [f"`repos/{docs_repo}/`"] if bos_cannot else [],
        },
        "NAV": {
            "rule": (
                f"You are a Navigator. You may write plans to the target repo"
                + (f" and repos/{docs_repo}/ as needed. Prefer documentation repo for "
                   f"architecture documents and the target repo for implementation plans."
                   if has_docs_repo else ".")
            ),
            "cannot_write_labels": [],
        },
        "COX": {
            "rule": (
                f"You are a Coxswain. You may write review artifacts to the target repo"
                + (f" and repos/{docs_repo}/ as needed." if has_docs_repo else ".")
            ),
            "cannot_write_labels": [],
        },
    }

    rules = ROLE_REPO_RULES.get(role, {})
    if not rules:
        return ""

    section = "\n## Repo Routing Rules (MANDATORY)\n\n"
    section += f"**Target Repo:** `{target_label}`\n"
    if has_docs_repo:
        section += f"**Documentation Repo:** `repos/{docs_repo}/`\n\n"
    else:
        section += f"**Documentation Repo:** `{target_label}docs/` (within target repo)\n\n"
    section += f"**YOUR RULE:** {rules['rule']}\n\n"

    if rules["cannot_write_labels"]:
        section += f"**DO NOT WRITE TO:** {', '.join(rules['cannot_write_labels'])}\n\n"

    section += "**Always allowed:** `.adm/` directory (reports, handoffs, queues, logs)\n"

    return section


def generate_prompt_for_item(item: Dict[str, Any]) -> str:
    """Generate a prompt file path for the work item.

    v8.8: Enhanced to inject all order metadata (references, tables, deliverables,
    requirementIds) into the active prompt so crews have full context.
    v8.10: Repo routing rules injected per role — enforces write boundaries.
    """
    prompts_dir = get_admiralty_dir() / "prompts" / "active"
    prompts_dir.mkdir(parents=True, exist_ok=True)

    prompt_file = prompts_dir / f"{item['id']}-{item['role']}.md"

    # Generate prompt with full order context
    role = item["role"]
    item_id = item["id"]
    item_type = item["type"]
    subtype = item.get("subtype", "")
    title = item["title"]
    data = item["data"]
    description = data.get("description", "")

    # Get acceptance criteria if available
    # Supports both legacy string arrays and structured AC objects (PLAN-AC-SCHEMA)
    criteria = data.get("acceptanceCriteria", [])
    def _format_ac(c):
        if isinstance(c, dict):
            sev = f" [{c.get('severity', 'blocking')}]" if c.get('severity') else ""
            return f"- {c.get('description', str(c))}{sev}"
        return f"- {c}"
    criteria_text = "\n".join(_format_ac(c) for c in criteria) if criteria else "- Complete the task as described"

    # Get files if available
    files = data.get("files", [])
    files_text = "\n".join(f"- {f}" for f in files) if files else "- Determine relevant files"

    # v8.8: Requirement IDs
    req_ids = data.get("requirementIds", [])
    req_section = ""
    if req_ids:
        req_section = "\n## Requirement IDs\n"
        req_section += "\n".join(f"- `{r}`" for r in req_ids)
        req_section += "\n"

    # v8.8: References (reference implementations, target paths, etc.)
    references = data.get("references", {})
    ref_section = ""
    if references:
        ref_section = "\n## References\n"
        if isinstance(references, list):
            ref_section += "\n".join(f"- `{r}`" for r in references) + "\n"
        else:
            ref_section += "\n| Key | Path |\n|-----|------|\n"
            for key, val in references.items():
                ref_section += f"| {key} | `{val}` |\n"

    # v8.8: Oracle tables (domain-specific but critical for data persistence orders)
    oracle_tables = data.get("oracleTables", [])
    oracle_section = ""
    if oracle_tables:
        oracle_section = "\n## Oracle Tables\n"
        oracle_section += "\n| Table | Schema | Access | Notes |\n|-------|--------|--------|-------|\n"
        for t in oracle_tables:
            table = t.get("table", "?")
            schema = t.get("schema", "?")
            access = t.get("access", "?")
            note = t.get("note", "")
            oracle_section += f"| {table} | {schema} | {access} | {note} |\n"

    # v8.8: SQL Server database name
    sql_db = data.get("sqlServerDatabase", "")
    sql_section = ""
    if sql_db:
        sql_section = f"\n## SQL Server Database\n- `{sql_db}`\n"

    # v8.8: Deliverables checklist
    deliverables = data.get("deliverables", [])
    deliv_section = ""
    if deliverables:
        deliv_section = "\n## Expected Deliverables\n"
        deliv_section += "\n".join(f"- [ ] {d}" for d in deliverables)
        deliv_section += "\n"

    # v8.8: Depends-on (dependency tracking)
    depends_on = data.get("dependsOn", [])
    dep_section = ""
    if depends_on:
        dep_section = "\n## Dependencies\n"
        dep_section += "\n".join(f"- `{d}`" for d in depends_on)
        dep_section += "\n"

    # v8.9: Prior role deliverables (plan + handoffs) for downstream phases
    nav_plan = data.get("navPlan", "")
    nav_handoff = data.get("navHandoff", "")
    shp_handoff = data.get("shpHandoff", "")
    nav_section = ""
    if nav_plan or nav_handoff or shp_handoff:
        nav_section = "\n## Prior Role Deliverables\n"
        nav_section += "**READ THESE FIRST** — previous roles have explored and implemented. Review their handoffs before starting.\n\n"
        if shp_handoff:
            nav_section += f"- **Shipwright Handoff (what was built):** `{shp_handoff}`\n"
        if nav_handoff:
            nav_section += f"- **Navigator Handoff (original instructions):** `{nav_handoff}`\n"
        if nav_plan:
            nav_section += f"- **Navigator Plan (full detail):** `{nav_plan}`\n"
        nav_section += "\nThe handoffs contain file lists, warnings, and traceability requirements.\n"

    # v7.3: Include previous timeout briefs so next crew knows what was tried
    timeout_briefs = data.get("timeoutBriefs", [])
    briefs_section = ""
    if timeout_briefs:
        briefs_section = "\n## Previous Attempts (Timed Out)\n"
        briefs_section += "The following crews attempted this order but timed out. Review their briefs to avoid repeating work:\n\n"
        for tb in timeout_briefs:
            briefs_section += f"**{tb.get('timestamp', 'unknown')} — Crew {tb.get('crew', '?')} ({tb.get('crewName', '?')}) — {tb.get('reason', 'TIMEOUT')}**\n"
            briefs_section += tb.get("brief", "(no brief captured)") + "\n\n"

    # v8.10: Repo routing rules — enforce which repos each role can write to
    # v2.0.6: docs_repo is optional; absent = SCR/LKT write to target repo's docs/ dir
    # BUG-ADM-2026-0008 (v2.5.5): if targetRepo is omitted on the order, resolve
    # from the project registry. Previously the prompt fell through to the
    # literal fallback string "the target service repo", which Sonnet 4.6
    # interpreted as a placeholder and exited in 1 iteration with no commits.
    target_repo = data.get("targetRepo", "")
    if not target_repo:
        target_repo = _resolve_target_repo_from_project(data)
    docs_repo = data.get("documentationRepo", "")
    repo_rules = _build_repo_routing_rules(role, target_repo, docs_repo)

    # v2.0.0: Managed repo instructions
    # v2.0.1: Per-order voyage branch — prefer explicit voyageBranch, then voyageId, then global env var
    voyage_branch = data.get("voyageBranch", "")
    voyage_id = data.get("voyageId", "")
    if voyage_branch:
        order_branch = voyage_branch
    elif voyage_id:
        order_branch = f"voyage/{voyage_id}" if not voyage_id.startswith("voyage/") else voyage_id
    else:
        order_branch = ""
    branch_ref = (order_branch or ACTIVE_VOYAGE_BRANCH).replace("refs/heads/", "")
    managed_repo_section = ""
    if target_repo and branch_ref:
        managed_repo_section = f"""
## Working Directory (Managed Repo)

Your target repo `{target_repo}` has been **pre-cloned** to your crew working directory.
- **Path:** Available via `$ADMIRALTY_REPO_PATH` env var (resolves to `.adm/crews/crewN/repo/`)
- **Branch:** `{branch_ref}` (already checked out — DO NOT create or switch branches)
- **DO NOT** clone the repo yourself — it is already ready
- **DO** commit and push your changes to `{branch_ref}` when complete
- **DO NOT** create temp directories (`.local-nuget/`, etc.) outside `$ADMIRALTY_TEMP`
- Use `$ADMIRALTY_TEMP/nuget-local/` for any local NuGet package workarounds
"""

    prompt_content = f"""# {item_type}: {item_id}

## Role: {role}
## Title: {title}

## Description
{description}
{req_section}{ref_section}{oracle_section}{sql_section}{nav_section}{deliv_section}{dep_section}
## Target Files
{files_text}

## Acceptance Criteria
{criteria_text}
{briefs_section}{managed_repo_section}{repo_rules}
## Instructions
Complete this {subtype or item_type} order following the established patterns in the codebase.
When complete, commit and push your changes, then update the order status and signal completion.
"""

    prompt_file.write_text(prompt_content, encoding='utf-8')
    return str(prompt_file)


def recover_orphaned_order(order_id: str, crew_num: int, reason: str):
    """Reset an orphaned IN_PROGRESS order back to PENDING for re-dispatch.

    v7.3: Reads timeout brief from crew state and appends it to the order's
    timeoutBriefs array before re-queuing. This preserves a record of what
    was attempted so the next crew can pick up where the previous one left off.
    """
    # v7.3: Read timeout brief from crew state before re-queuing
    crew_state = read_crew_state(crew_num)
    timeout_brief = None
    if crew_state:
        timeout_brief = crew_state.get("timeoutBrief")

    # v7.0: Search ALL queue directories, not just orders/
    queues_dir = get_queues_dir()
    search_dirs = [
        queues_dir / "orders", queues_dir / "explicit", queues_dir / "high-level",
        queues_dir / "bugs", queues_dir / "defects", queues_dir / "security",
        queues_dir / "breakdown",
    ]
    requests_dir = queues_dir / "requests"
    if requests_dir.exists():
        for sub in requests_dir.iterdir():
            if sub.is_dir():
                search_dirs.append(sub)

    for search_dir in search_dirs:
        if not search_dir.exists():
            continue
        for json_file in search_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                file_order_id = data.get("orderId") or data.get("id") or json_file.stem
                if file_order_id == order_id and data.get("status") == "IN_PROGRESS":
                    data["status"] = "PENDING"
                    if "assignedTo" in data:
                        del data["assignedTo"]
                    if "startedAt" in data:
                        del data["startedAt"]

                    # v7.3: Append timeout brief to order history
                    if timeout_brief:
                        if "timeoutBriefs" not in data:
                            data["timeoutBriefs"] = []
                        data["timeoutBriefs"].append({
                            "crew": crew_num,
                            "crewName": CREW_NAMES.get(crew_num, f"Crew{crew_num}"),
                            "reason": reason,
                            "timestamp": datetime.now().isoformat(),
                            "brief": timeout_brief
                        })
                        print_info(f"  Timeout brief attached to {order_id}")

                    json_file.write_text(json.dumps(data, indent=2), encoding='utf-8')
                    print_warn(f"Re-queued orphaned order {order_id} (Crew {crew_num} {reason})")
                    write_lifecycle_event("REQUEUE", f"{order_id} re-queued (Crew {crew_num} {reason})")
                    return
            except Exception as e:
                # v7.1 FIX: Log errors instead of silently swallowing them
                print_warn(f"Error reading queue file {json_file}: {e}")

    # v7.1 FIX: Log when order not found — this indicates a potential orphan
    print_warn(f"Could not find IN_PROGRESS order {order_id} in any queue for re-queue (Crew {crew_num} {reason})")
    write_lifecycle_event("WARN", f"Order {order_id} not found as IN_PROGRESS in queues - may be orphaned (Crew {crew_num} {reason})")


def complete_order(order_id: str, crew_num: int, crew_state: Dict[str, Any]):
    """Mark an order as COMPLETE and archive it out of the active queue.

    Lifecycle: PENDING -> IN_PROGRESS -> COMPLETE (archived)
    Searches queue directories first, then falls back to orders/active/.
    v8.5: Also archives from orders/active/ to fix dependency resolution
    when queue file is missing (e.g., cleaned up or pipe-hang scenario).
    """
    queues_dir = get_queues_dir()
    admiralty_dir = get_admiralty_dir()
    archive_dir = admiralty_dir / "orders" / "complete"
    archive_dir.mkdir(parents=True, exist_ok=True)

    completion_metadata = {
        "status": "COMPLETE",
        "completedAt": datetime.now().isoformat(),
        "completedBy": {
            "crew": crew_num,
            "role": crew_state.get("role", "UNK"),
            "iterations": crew_state.get("iteration", 0),
            "startTime": crew_state.get("startTime", ""),
            "endTime": crew_state.get("endTime", "")
        }
    }

    # v7.0: Search ALL queue directories
    search_dirs = [
        queues_dir / "orders", queues_dir / "explicit", queues_dir / "high-level",
        queues_dir / "bugs", queues_dir / "defects", queues_dir / "security",
        queues_dir / "breakdown",
    ]
    # Also search all request subdirectories
    requests_dir = queues_dir / "requests"
    if requests_dir.exists():
        for sub in requests_dir.iterdir():
            if sub.is_dir():
                search_dirs.append(sub)

    found_in_queue = False
    for search_dir in search_dirs:
        if not search_dir.exists():
            continue
        for json_file in search_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                file_order_id = data.get("orderId") or data.get("id") or json_file.stem
                if file_order_id != order_id:
                    continue

                # v8.9: If the queue file already has status=COMPLETE, it was
                # written by the crew but not yet moved to archive (e.g. due to
                # timing or a prior unlink failure). Sweep it straight to archive.
                if data.get("status") == "COMPLETE":
                    data.update(completion_metadata)
                    archive_file = archive_dir / json_file.name
                    archive_file.write_text(json.dumps(data, indent=2), encoding='utf-8')
                    json_file.unlink()
                    found_in_queue = True
                    print_ok(f"Order {order_id} already COMPLETE in queue -> swept to archive")
                    write_lifecycle_event("COMPLETE", f"{order_id} swept to archive from queue (Crew {crew_num})")
                    ring_crew_bell(crew_num, order_id)
                    break

                # Found the order in queue — check role sequence before archiving
                completed_role = crew_state.get("role", "")

                # Idempotency guard: if the order was already advanced (status=PENDING
                # and targetRole != completed_role), a second call for the same crew
                # completion must not advance again (BUG-MSO-2026-0015 double-ADVANCE)
                if data.get("status") == "PENDING" and data.get("targetRole") and data.get("targetRole") != completed_role:
                    print_info(f"Order {order_id} already advanced past {completed_role} -> {data['targetRole']} (skipping duplicate completion)")
                    write_lifecycle_event("WARN", f"{order_id} duplicate complete_order call for {completed_role} ignored — already at {data['targetRole']}")
                    found_in_queue = True
                    break

                meta = data.get("_meta", {})
                order_type = data.get("orderType") or data.get("type", "")
                sequence = (
                    data.get("roleSequence")
                    or meta.get("roleSequence")
                    or ROLE_SEQUENCES.get(order_type, [])
                )
                next_role = None
                if sequence and completed_role in sequence:
                    idx = sequence.index(completed_role)
                    if idx + 1 < len(sequence):
                        next_role = sequence[idx + 1]

                if next_role:
                    # Post-NAV human review gate
                    if completed_role == "NAV":
                        gate_cfg = load_gate_config(get_admiralty_dir())
                        decision = gate_check_post_nav(data, gate_cfg)
                        if decision == "pause":
                            review_dir = get_admiralty_dir() / "queues" / "review"
                            review_dir.mkdir(parents=True, exist_ok=True)
                            data["status"] = "NAV_REVIEW_PENDING"
                            data["targetRole"] = next_role
                            data["navReviewPausedAt"] = datetime.now().isoformat()
                            data.pop("assignedTo", None)
                            data.pop("startedAt", None)
                            review_file = review_dir / json_file.name
                            review_file.write_text(json.dumps(data, indent=2), encoding='utf-8')
                            json_file.unlink()
                            found_in_queue = True
                            print_ok(f"Order {order_id} NAV complete -> paused for human review")
                            write_lifecycle_event("NAV_REVIEW_PENDING", f"{order_id} NAV complete -> queues/review/ (Crew {crew_num})")
                            ring_crew_bell(crew_num, order_id)
                            break

                    # Not the final role — advance to next role and re-queue
                    data["status"] = "PENDING"
                    data["targetRole"] = next_role
                    data.pop("assignedTo", None)
                    data.pop("startedAt", None)
                    json_file.write_text(json.dumps(data, indent=2), encoding='utf-8')
                    found_in_queue = True
                    ORDERS_IN_TRANSITION.add(order_id)
                    print_ok(f"Order {order_id} {completed_role} complete -> advancing to {next_role}")
                    write_lifecycle_event("ADVANCE", f"{order_id} {completed_role} complete -> {next_role} (Crew {crew_num})")
                    ring_crew_bell(crew_num, order_id)
                else:
                    # Final role — archive as COMPLETE
                    data.update(completion_metadata)
                    archive_file = archive_dir / json_file.name
                    archive_file.write_text(json.dumps(data, indent=2), encoding='utf-8')
                    json_file.unlink()
                    found_in_queue = True
                    print_ok(f"Order {order_id} COMPLETE -> archived to orders/complete/")
                    write_lifecycle_event("COMPLETE", f"{order_id} COMPLETE -> archived (Crew {crew_num})")
                    ring_crew_bell(crew_num, order_id)
                break

            except Exception as e:
                print_warn(f"Error processing {json_file}: {e}")
        if found_in_queue:
            break

    # v8.5: Also archive from orders/active/ to orders/complete/
    # This ensures dependency resolution works even if the queue file was
    # already cleaned up (pipe-hang scenario, manual cleanup, etc.)
    active_dir = admiralty_dir / "orders" / "active"
    active_file = active_dir / f"{order_id}.json"
    if active_file.exists():
        try:
            data = json.loads(active_file.read_text(encoding='utf-8'))
            if not found_in_queue:
                # Apply same advance-vs-archive logic as queue path
                completed_role = crew_state.get("role", "")
                meta = data.get("_meta", {})
                order_type = data.get("orderType") or data.get("type", "")
                sequence = (
                    data.get("roleSequence")
                    or meta.get("roleSequence")
                    or ROLE_SEQUENCES.get(order_type, [])
                )
                next_role = None
                if sequence and completed_role in sequence:
                    idx = sequence.index(completed_role)
                    if idx + 1 < len(sequence):
                        next_role = sequence[idx + 1]

                if next_role:
                    # Post-NAV human review gate (v8.5 fallback path)
                    if completed_role == "NAV":
                        gate_cfg = load_gate_config(admiralty_dir)
                        decision = gate_check_post_nav(data, gate_cfg)
                        if decision == "pause":
                            review_dir = admiralty_dir / "queues" / "review"
                            review_dir.mkdir(parents=True, exist_ok=True)
                            data["status"] = "NAV_REVIEW_PENDING"
                            data["targetRole"] = next_role
                            data["navReviewPausedAt"] = datetime.now().isoformat()
                            data.pop("assignedTo", None)
                            data.pop("startedAt", None)
                            review_file = review_dir / active_file.name
                            review_file.write_text(json.dumps(data, indent=2), encoding='utf-8')
                            active_file.unlink()
                            print_ok(f"Order {order_id} NAV complete -> paused for human review (v8.5 fallback)")
                            write_lifecycle_event("NAV_REVIEW_PENDING", f"{order_id} NAV complete -> queues/review/ from active (Crew {crew_num}, v8.5)")
                            ring_crew_bell(crew_num, order_id)
                            return True

                    # Not the final role — move back to queue at next role
                    queue_dir = admiralty_dir / "queues" / "orders"
                    queue_dir.mkdir(parents=True, exist_ok=True)
                    data["status"] = "PENDING"
                    data["targetRole"] = next_role
                    data.pop("assignedTo", None)
                    data.pop("startedAt", None)
                    queue_file = queue_dir / active_file.name
                    queue_file.write_text(json.dumps(data, indent=2), encoding='utf-8')
                    active_file.unlink()
                    ORDERS_IN_TRANSITION.add(order_id)
                    print_ok(f"Order {order_id} {completed_role} complete -> advancing to {next_role} (v8.5 fallback)")
                    write_lifecycle_event("ADVANCE", f"{order_id} {completed_role} -> {next_role} from active (Crew {crew_num}, v8.5)")
                    ring_crew_bell(crew_num, order_id)
                else:
                    data.update(completion_metadata)
                    archive_file = archive_dir / active_file.name
                    archive_file.write_text(json.dumps(data, indent=2), encoding='utf-8')
                    active_file.unlink()
                    print_ok(f"Order {order_id} COMPLETE -> archived from orders/active/ (v8.5 fallback)")
                    write_lifecycle_event("COMPLETE", f"{order_id} COMPLETE -> archived from active (Crew {crew_num}, v8.5)")
                    ring_crew_bell(crew_num, order_id)
            else:
                # Queue path already handled it — just clean up active copy if present
                active_file.unlink(missing_ok=True)
        except Exception as e:
            print_warn(f"Error archiving {order_id} from active: {e}")
        return True

    if found_in_queue:
        return True

    # v8.7: Check if already archived (e.g., pipe-hang fix already processed it)
    archive_check = archive_dir / f"{order_id}.json"
    if archive_check.exists():
        return True

    # v8.5: Log warning when order not found anywhere
    print_warn(f"Order {order_id} not found in queues or active — creating archive entry from crew state")
    write_lifecycle_event("WARN", f"Order {order_id} not found in queues/active — synthesized archive entry (Crew {crew_num}, v8.5)")
    # Last resort: create a minimal archive entry so dependencies resolve
    archive_file = archive_dir / f"{order_id}.json"
    if not archive_file.exists():
        minimal_data = {"orderId": order_id, "id": order_id}
        minimal_data.update(completion_metadata)
        archive_file.write_text(json.dumps(minimal_data, indent=2), encoding='utf-8')
    ring_crew_bell(crew_num, order_id)
    return True


def process_crew_completion(crew_num: int):
    """Process a crew that has finished (COMPLETE, BLOCKED, ERROR, CRASHED, etc).

    v7.1: Handles ALL terminal states including AUTH_ERROR and INTERRUPTED.
    v2.0.0: Added post-completion repo verification, per-crew PR creation, and cleanup.

    Handles the full lifecycle:
    - COMPLETE: Verify+push, create PR, archive the order
    - CRASHED/ERROR/TIMEOUT/AUTH_ERROR/INTERRUPTED: Verify+push, re-queue for retry
    - BLOCKED/MAX_ITERATIONS/CIRCUIT_BREAKER: Verify+push, archive with failure status
    """
    state = read_crew_state(crew_num)
    if not state:
        return

    status = state.get("status", "")
    order_id = state.get("orderId", "")
    if not order_id:
        return

    # v2.0.0: Post-completion repo verification (for ALL terminal states)
    target_repo = _get_target_repo_for_order(order_id)
    # v2.0.1: Per-order voyage branch resolution
    voyage_branch = _get_voyage_branch_for_order(order_id) or ACTIVE_VOYAGE_BRANCH

    if target_repo and voyage_branch:
        repo_report = verify_and_push_crew_work(crew_num, target_repo, voyage_branch)
        if repo_report.get("error"):
            write_lifecycle_event("WARN",
                f"Crew {crew_num} repo verification: {repo_report['error']}")

        # Create/update PR on successful completion
        # BUG-ADM-2026-0013: pass project_acronym so create_pr_for_crew can
        # resolve the base branch from project registry (PSG → master).
        if status == "COMPLETE":
            order_title = _get_order_title(order_id)
            project_acronym = state.get("project") or _get_project_for_order(order_id) or ""
            create_pr_for_crew(crew_num, target_repo, voyage_branch, order_id,
                               order_title, project_acronym=project_acronym)

    if status == "COMPLETE":
        # Success - archive the order
        complete_order(order_id, crew_num, state)
        # v2.0.5: Auto-queue dependent orders whose dependencies are now satisfied
        auto_queue_unblocked_orders(order_id)

    elif status in ["CRASHED", "ERROR", "TIMEOUT", "AUTH_ERROR", "INTERRUPTED"]:
        # v7.1: Added AUTH_ERROR + INTERRUPTED — re-queue for retry
        recover_orphaned_order(order_id, crew_num, status)

    elif status in ["BLOCKED", "MAX_ITERATIONS", "CIRCUIT_BREAKER"]:
        # Stalled - archive with failure status so it doesn't clog the queue
        archive_stalled_order(order_id, crew_num, state, status)

    else:
        # v7.1: Unknown status — treat as crash, re-queue
        print_warn(f"Crew {crew_num} has unknown status '{status}' for {order_id} — re-queuing")
        write_lifecycle_event("WARN", f"Crew {crew_num} unknown status '{status}' for {order_id} — re-queuing")
        recover_orphaned_order(order_id, crew_num, f"UNKNOWN({status})")

    # v2.0.0: Cleanup ephemeral crew repo clone
    cleanup_crew_repo(crew_num)


def archive_stalled_order(order_id: str, crew_num: int, crew_state: Dict[str, Any], reason: str):
    """Archive a stalled order (BLOCKED, MAX_ITERATIONS, CIRCUIT_BREAKER).

    These orders need human review - they go to orders/complete/ with a STALLED status
    so they don't sit in the active queue forever.
    """
    queues_dir = get_queues_dir()
    archive_dir = get_admiralty_dir() / "orders" / "complete"
    archive_dir.mkdir(parents=True, exist_ok=True)

    # v7.0: Search ALL queue directories
    search_dirs = [
        queues_dir / "orders", queues_dir / "explicit", queues_dir / "high-level",
        queues_dir / "bugs", queues_dir / "defects", queues_dir / "security",
        queues_dir / "breakdown",
    ]
    requests_dir = queues_dir / "requests"
    if requests_dir.exists():
        for sub in requests_dir.iterdir():
            if sub.is_dir():
                search_dirs.append(sub)

    for search_dir in search_dirs:
        if not search_dir.exists():
            continue
        for json_file in search_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                file_order_id = data.get("orderId") or data.get("id") or json_file.stem
                if file_order_id != order_id:
                    continue

                data["status"] = "STALLED"
                data["stalledAt"] = datetime.now().isoformat()
                data["stalledReason"] = reason
                data["stalledBy"] = {
                    "crew": crew_num,
                    "role": crew_state.get("role", "UNK"),
                    "iterations": crew_state.get("iteration", 0),
                    "startTime": crew_state.get("startTime", ""),
                    "endTime": crew_state.get("endTime", "")
                }

                archive_file = archive_dir / json_file.name
                archive_file.write_text(json.dumps(data, indent=2), encoding='utf-8')
                json_file.unlink()

                print_warn(f"Order {order_id} STALLED ({reason}) -> archived for review")
                write_lifecycle_event("STALLED", f"{order_id} STALLED ({reason}) -> archived (Crew {crew_num})")
                return True

            except Exception as e:
                print_warn(f"Error processing {json_file}: {e}")

    return False


def archive_all_completed_orders() -> int:
    """Manual sweep: archive terminal-status orders from queues.

    CONSERVATIVE: Only archives orders with confirmed terminal status:
    - COMPLETE, PROCESSED -> archived as-is
    - IN_PROGRESS -> only if crew state confirms COMPLETE (enriches metadata)
    - PENDING, RUNNING -> always skipped (still active work)

    Matches crew state files to add completion metadata.
    Used via --archive-completed CLI command.
    """
    archived = 0
    queues_dir = get_queues_dir()
    archive_dir = get_admiralty_dir() / "orders" / "complete"
    archive_dir.mkdir(parents=True, exist_ok=True)

    # Build a lookup of crew states by orderId for metadata enrichment
    crew_states = {}
    for crew_num in range(1, 6):
        state = read_crew_state(crew_num)
        if state and state.get("orderId"):
            crew_states[state["orderId"]] = state

    # Collect all queue directories to scan
    search_dirs = [queues_dir / "orders"]
    requests_dir = queues_dir / "requests"
    if requests_dir.exists():
        for sub in requests_dir.iterdir():
            if sub.is_dir():
                search_dirs.append(sub)

    for search_dir in search_dirs:
        if not search_dir.exists():
            continue
        for json_file in search_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                status = data.get("status", "PENDING")
                order_id = data.get("id", json_file.stem)

                # Only archive confirmed terminal statuses
                should_archive = False

                if status in ["COMPLETE", "PROCESSED"]:
                    # Already marked complete - safe to archive
                    should_archive = True

                elif status == "IN_PROGRESS":
                    # Check crew state - only archive if crew confirms COMPLETE
                    crew_state = crew_states.get(order_id, {})
                    crew_status = crew_state.get("status", "") if crew_state else ""

                    if crew_status == "COMPLETE":
                        # Crew finished - enrich and archive
                        data["status"] = "COMPLETE"
                        data["completedAt"] = datetime.now().isoformat()
                        data["completedBy"] = {
                            "crew": crew_state.get("crewNumber"),
                            "role": crew_state.get("role", "UNK"),
                            "iterations": crew_state.get("iteration", 0),
                            "startTime": crew_state.get("startTime", ""),
                            "endTime": crew_state.get("endTime", "")
                        }
                        should_archive = True
                    else:
                        # Crew still working, crashed, or reassigned - leave in queue
                        print_info(f"{order_id} IN_PROGRESS (crew: {crew_status or 'unknown'}) -> skipped")

                # PENDING, RUNNING, and unconfirmed IN_PROGRESS are always skipped

                if not should_archive:
                    continue

                # Archive it
                data["archivedAt"] = datetime.now().isoformat()
                archive_file = archive_dir / json_file.name
                archive_file.write_text(json.dumps(data, indent=2), encoding='utf-8')
                json_file.unlink()

                print_ok(f"{order_id} ({data['status']}) -> archived")
                archived += 1

            except Exception as e:
                print_warn(f"Error processing {json_file}: {e}")

    return archived


def auto_queue_unblocked_orders(completed_order_id: str):
    """v2.0.5: When an order completes, auto-queue any orders from orders/active/
    whose dependencies are now satisfied.

    This closes the critical gap where orders sat in orders/active/ but never
    made it into queues/orders/ because no one copied them there.

    Logic:
    1. Scan orders/active/ for orders with a 'dependencies' field
    2. For each, check if ALL dependencies exist in orders/complete/
    3. If satisfied and not already in a queue, copy to queues/orders/
    """
    admiralty_dir = get_admiralty_dir()
    active_dir = admiralty_dir / "orders" / "active"
    complete_dir = admiralty_dir / "orders" / "complete"
    queue_dir = get_queues_dir() / "orders"
    queue_dir.mkdir(parents=True, exist_ok=True)

    if not active_dir.exists():
        return

    # Build set of completed order IDs for fast lookup
    completed_ids = set()
    if complete_dir.exists():
        for f in complete_dir.glob("*.json"):
            completed_ids.add(f.stem)

    # Statuses that mean "this order is finished — do not re-queue it"
    # Defends against complete/ lagging behind active/ across branches
    # (BUG-ADM-2026-0002): the rename from active/ to complete/ might not
    # have landed on the current branch yet, so the complete/ glob above
    # wouldn't catch it. In that case, the order's own status field is the
    # authoritative signal — include every terminal outcome that fleet_runner
    # treats as archived/complete elsewhere so all stalled-but-finished
    # variants are skipped consistently.
    TERMINAL_STATUSES = {
        "COMPLETE",
        "FAILED",
        "CANCELLED",
        "BLOCKED",
        "STALLED",
        "MAX_ITERATIONS",
        "PROCESSED",
    }

    queued_count = 0
    for order_file in list(active_dir.glob("*.json")):
        try:
            data = json.loads(order_file.read_text(encoding='utf-8'))
            order_id = data.get("orderId", order_file.stem)

            # Skip if already in a queue
            if (queue_dir / order_file.name).exists():
                continue

            # Skip if already completed (archive present)
            if order_id in completed_ids:
                continue

            # Skip if the order's own status says it's finished, even when
            # the archive isn't on this branch yet (BUG-ADM-2026-0002).
            if data.get("status", "").upper() in TERMINAL_STATUSES:
                continue

            # Check dependencies - support both 'dependencies' and 'dependsOn' fields
            deps = data.get("dependencies", data.get("dependsOn", []))
            if not deps:
                # No dependencies — queue immediately
                queue_file = queue_dir / order_file.name
                queue_file.write_text(order_file.read_text(encoding='utf-8'), encoding='utf-8')
                queued_count += 1
                print_ok(f"Auto-queued {order_id} (no dependencies)")
                write_lifecycle_event("AUTOQUEUE", f"{order_id} auto-queued (no dependencies)")
                continue

            # Check if all dependencies are satisfied
            all_satisfied = True
            for dep_id in deps:
                if dep_id not in completed_ids:
                    all_satisfied = False
                    break

            if all_satisfied:
                queue_file = queue_dir / order_file.name
                queue_file.write_text(order_file.read_text(encoding='utf-8'), encoding='utf-8')
                queued_count += 1
                print_ok(f"Auto-queued {order_id} (dependency {completed_order_id} satisfied)")
                write_lifecycle_event("AUTOQUEUE",
                    f"{order_id} auto-queued after {completed_order_id} completed")

        except Exception as e:
            print_warn(f"Error checking {order_file.name} for auto-queue: {e}")

    if queued_count > 0:
        print_ok(f"Auto-queued {queued_count} order(s) after {completed_order_id} completed")


def sweep_decks() -> dict:
    """Automatic deck sweep: clean stale orders and complete finished voyages.

    v2.0.5: Called at Eight Bells and via --sweep-decks CLI command.

    Actions:
    1. Remove stale duplicates from orders/active/ that already exist in orders/complete/
    2. Archive prompts/active/ files for completed orders to prompts/complete/
    3. Check all active voyages - if all orders are COMPLETE, mark voyage COMPLETE
       and move from voyages/active/ to voyages/complete/

    Returns a summary dict with counts of actions taken.
    """
    admiralty_dir = get_admiralty_dir()
    active_orders_dir = admiralty_dir / "orders" / "active"
    complete_orders_dir = admiralty_dir / "orders" / "complete"
    active_voyages_dir = admiralty_dir / "voyages" / "active"
    complete_voyages_dir = admiralty_dir / "voyages" / "complete"
    complete_voyages_dir.mkdir(parents=True, exist_ok=True)

    summary = {"stale_orders_removed": 0, "prompts_archived": 0, "voyages_completed": 0, "errors": []}

    # --- Step 1: Remove stale active orders that have completed copies ---
    if active_orders_dir.exists() and complete_orders_dir.exists():
        completed_ids = {f.stem for f in complete_orders_dir.glob("*.json")}
        for order_file in list(active_orders_dir.glob("*.json")):
            if order_file.stem in completed_ids:
                try:
                    order_file.unlink()
                    summary["stale_orders_removed"] += 1
                    print_ok(f"Swept stale active order: {order_file.stem}")
                except Exception as e:
                    summary["errors"].append(f"Failed to remove {order_file.stem}: {e}")

    # --- Step 2: Archive prompts for completed orders ---
    active_prompts_dir = admiralty_dir / "prompts" / "active"
    complete_prompts_dir = admiralty_dir / "prompts" / "complete"
    if active_prompts_dir.exists() and complete_orders_dir.exists():
        complete_prompts_dir.mkdir(parents=True, exist_ok=True)
        completed_ids = {f.stem for f in complete_orders_dir.glob("*.json")}
        for prompt_file in list(active_prompts_dir.glob("*.md")):
            # Prompt files are named {ORDER-ID}-{ROLE}.md — extract order ID
            parts = prompt_file.stem.rsplit("-", 1)
            order_id = parts[0] if len(parts) == 2 else prompt_file.stem
            if order_id in completed_ids:
                try:
                    dest = complete_prompts_dir / prompt_file.name
                    prompt_file.rename(dest)
                    summary["prompts_archived"] += 1
                except Exception as e:
                    summary["errors"].append(f"Failed to archive prompt {prompt_file.name}: {e}")

    # --- Step 3: Complete finished voyages ---
    if active_voyages_dir.exists():
        for voyage_file in list(active_voyages_dir.glob("VOY-*.json")):
            try:
                voyage = json.loads(voyage_file.read_text(encoding='utf-8'))
                voyage_id = voyage.get("voyageId", voyage_file.stem)
                orders = voyage.get("orders", [])

                # BUG-ADM-2026-0012: only sweep ACTIVE voyages. The guard is
                # strict — any status that is not exactly "ACTIVE" (and not
                # None) is skipped. That covers HELD, PROPOSED, DRAFT,
                # PAUSED, PLANNED, APPROVED, COMPLETE, FAILED, ABANDONED,
                # and any custom workspace status. Operators relying on
                # non-ACTIVE statuses to pause / queue / hold a voyage need
                # the sweep to leave it alone. Legacy voyages without a
                # status field at all (status=None) fall through and remain
                # eligible for sweep — backwards compat for pre-status
                # voyage manifests.
                voyage_status = voyage.get("status")
                if voyage_status is not None and voyage_status != "ACTIVE":
                    continue

                if not orders:
                    continue

                # Check if ALL orders in this voyage have completed copies.
                # BUG-ADM-2026-0010: file presence alone is not enough — the
                # completed order must also be owned by THIS voyage. Without
                # this check, an order ID that happens to exist in
                # orders/complete/ from a prior voyage (cross-voyage ID
                # reuse, manual residue, fix-and-revert cycle) will falsely
                # mark the new voyage COMPLETE before its crews ever ran.
                all_complete = True
                for order_entry in orders:
                    # orders field may be a list of strings or a list of dicts
                    if isinstance(order_entry, str):
                        order_id = order_entry
                    else:
                        # BUG-ADM-2026-0012: schemas use both `orderId` and
                        # `id` in the wild (PSG manifests use `id`; framework
                        # manifests use `orderId`). Accept either — falling
                        # back to "" if neither is present.
                        order_id = (
                            order_entry.get("orderId")
                            or order_entry.get("id")
                            or ""
                        )
                    if not order_id:
                        # BUG-ADM-2026-0012: pre-fix this silently skipped an
                        # unidentifiable order entry. That left all_complete
                        # True for voyages with no recognisable order keys —
                        # they'd auto-archive without any crew ever running.
                        # Now: treat as not-complete (operator must fix the
                        # voyage manifest before sweep advances).
                        # Copilot review on PR #62: write_lifecycle_event
                        # already swallows exceptions internally, so the
                        # outer try/except is redundant.
                        all_complete = False
                        write_lifecycle_event(
                            "SWEEP_UNREADABLE_ORDER",
                            f"Voyage {voyage_id}: order entry has neither "
                            f"`orderId` nor `id` field — refusing to sweep. "
                            "Fix the voyage manifest's orders[] schema."
                        )
                        break
                    completed_file = complete_orders_dir / f"{order_id}.json"
                    if not completed_file.exists():
                        all_complete = False
                        break

                    # BUG-ADM-2026-0010: ownership verification.
                    # Copilot review on PR #60: catch UnicodeDecodeError too
                    # (Path.read_text with explicit encoding raises it on
                    # invalid UTF-8). Without it, the error bubbles to the
                    # outer except Exception and aborts voyage processing
                    # rather than just refusing the sweep. Also record the
                    # specific blocker in summary + lifecycle log so
                    # operators can find the offending file.
                    try:
                        order_data = json.loads(completed_file.read_text(encoding='utf-8'))
                    except (OSError, json.JSONDecodeError, UnicodeDecodeError) as exc:
                        all_complete = False
                        err_msg = (
                            f"Voyage {voyage_id}: cannot read completed order "
                            f"{order_id} ({type(exc).__name__}: {str(exc)[:100]}) — "
                            "treating as not-complete (sweep refused)."
                        )
                        summary["errors"].append(err_msg)
                        try:
                            write_lifecycle_event("SWEEP_READ_ERROR", err_msg)
                        except Exception:
                            pass
                        break
                    completed_voyage_id = order_data.get("voyageId") or ""
                    if completed_voyage_id and completed_voyage_id != voyage_id:
                        all_complete = False
                        try:
                            write_lifecycle_event(
                                "SWEEP_OWNERSHIP_MISMATCH",
                                f"Voyage {voyage_id} references {order_id}, "
                                f"but the completed order is owned by "
                                f"{completed_voyage_id}. Refusing to sweep "
                                f"{voyage_id} as COMPLETE — fix the voyage's "
                                "orders[] reference or re-run the order under "
                                f"{voyage_id}."
                            )
                        except Exception:
                            pass
                        break

                if not all_complete:
                    continue

                # All orders complete - update voyage status and move to complete
                voyage["status"] = "COMPLETE"
                if not voyage.get("startedDate"):
                    voyage["startedDate"] = voyage.get("createdDate",
                        datetime.now().strftime("%Y-%m-%d"))
                if not voyage.get("completedDate"):
                    voyage["completedDate"] = datetime.now().strftime("%Y-%m-%d")

                for o in voyage.get("orders", []):
                    if isinstance(o, dict):
                        o["status"] = "COMPLETE"
                for p in voyage.get("phases", []):
                    p["status"] = "COMPLETE"
                for ac in voyage.get("acceptanceCriteria", []):
                    if ac.get("status") == "PENDING":
                        ac["status"] = "VERIFIED"
                for g in voyage.get("gates", {}).values():
                    if g.get("status") == "PENDING":
                        g["status"] = "PASSED"
                        if not g.get("verifiedAt"):
                            g["verifiedAt"] = voyage["completedDate"]

                dest = complete_voyages_dir / voyage_file.name
                dest.write_text(json.dumps(voyage, indent=2), encoding='utf-8')
                voyage_file.unlink()

                summary["voyages_completed"] += 1
                print_ok(f"Voyage {voyage_id} COMPLETE -> moved to voyages/complete/")
                write_lifecycle_event("SWEEP",
                    f"Voyage {voyage_id} auto-completed (all orders done)")

                # FTR-0149: clean up the voyage worktree now that the voyage is archived
                try:
                    from admiralty.core.worktrees import cleanup_voyage_worktree
                    cleanup_voyage_worktree(voyage_id)
                except Exception as wt_exc:
                    print_warn(f"Worktree cleanup for {voyage_id} failed: {wt_exc}")

            except Exception as e:
                summary["errors"].append(f"Error processing voyage {voyage_file.name}: {e}")

    # Log summary
    total_actions = summary["stale_orders_removed"] + summary["prompts_archived"] + summary["voyages_completed"]
    if total_actions > 0:
        print_ok(f"Deck sweep: {summary['stale_orders_removed']} stale orders removed, "
                 f"{summary['prompts_archived']} prompts archived, "
                 f"{summary['voyages_completed']} voyages completed")
        write_lifecycle_event("SWEEP", f"Deck sweep: {summary['stale_orders_removed']} orders, "
                              f"{summary['prompts_archived']} prompts, "
                              f"{summary['voyages_completed']} voyages")
    else:
        print_info("Deck sweep: all clear, nothing to clean")

    if summary["errors"]:
        for err in summary["errors"]:
            print_warn(f"Sweep error: {err}")

    return summary


def _validate_mcp_before_launch(item: Dict[str, Any], order_data: Dict[str, Any]) -> None:
    """
    Validate MCP server permissions before launching a crew.
    Raises RuntimeError (caught by dispatch_crew) with lifecycle log entry on
    violation. Logs a warning and continues in permissive mode when no registry
    is present.
    """
    try:
        from admiralty.mcp import validate_mcp_permissions, load_registry
    except ImportError:
        return  # mcp module not available — skip silently

    role: str = item.get("role", "")
    workspace = Path(get_admiralty_dir()).parent

    # Per-order override: order.data.mcpServers lists required server names.
    # order_data is untyped runtime data so the field could legally be any JSON
    # type; treat anything other than a list[str] as a schema error rather than
    # iterate characters of a string into validate_mcp_permissions.
    raw_order_mcp_servers = order_data.get("mcpServers")
    order_mcp_servers: Optional[List[str]]
    if raw_order_mcp_servers is None:
        order_mcp_servers = None
    elif (
        isinstance(raw_order_mcp_servers, list)
        and all(isinstance(s, str) for s in raw_order_mcp_servers)
    ):
        order_mcp_servers = raw_order_mcp_servers
    else:
        order_id = item.get("id", "?")
        error = "Invalid order schema: 'mcpServers' must be a list of strings"
        print_error(f"MCP validation failed for {order_id} ({role}): {error}")
        write_lifecycle_event(
            "MCP_BLOCK",
            f"Crew blocked — {order_id} ({role}): {error}",
        )
        raise RuntimeError(f"MCP validation failed: {error}")

    # Permissive-mode check: no registry → warn and allow
    registry = load_registry(workspace)
    if registry is None:
        print_warn(
            f"MCP registry not found (.adm/config/mcp-servers.json) — "
            f"running in permissive mode for {item.get('id', '?')}"
        )
        write_lifecycle_event(
            "MCP_WARN",
            f"No MCP registry — permissive mode for {item.get('id', '?')} ({role})",
        )
        return

    error = validate_mcp_permissions(role, workspace, server_names=order_mcp_servers)
    if error:
        order_id = item.get("id", "?")
        print_error(f"MCP validation failed for {order_id} ({role}): {error}")
        write_lifecycle_event(
            "MCP_BLOCK",
            f"Crew blocked — {order_id} ({role}): {error}",
        )
        raise RuntimeError(f"MCP validation failed: {error}")


_REQUIRES_TARGET_REPO_ROLES = {"SHP", "BOS", "BLD", "TST"}


def _load_voyage_by_id(voyage_id: str) -> Dict[str, Any]:
    """Look up a voyage's JSON across active and complete locations.

    BUG-ADM-2026-0009: needed by resolve_voyage_branch_for_order so an
    order without explicit voyageBranch can inherit from its parent voyage.
    Returns {} when not found.
    """
    if not voyage_id:
        return {}
    try:
        adm = get_admiralty_dir()
    except Exception:
        return {}
    for sub in ("voyages/active", "voyages/complete"):
        path = adm / sub / f"{voyage_id}.json"
        if path.exists():
            try:
                return json.loads(path.read_text(encoding="utf-8"))
            except Exception:
                continue
    return {}


def resolve_voyage_branch_for_order(order_data: Dict[str, Any]) -> str:
    """Resolve voyageBranch for an order, walking the propagation chain:

      1. order.voyageBranch              (explicit on the order)
      2. parent_voyage.branch            (inherited from voyage)
      3. ADMIRALTY_VOYAGE_BRANCH env     (operator-level, current shell)
      4. ""                              (loose — caller must refuse)

    BUG-ADM-2026-0009: this is the single source of truth for an order's
    branch identity. dispatch_crew calls it, persists the resolved value
    back to the order JSON if it came from layers 2 or 3, so every
    subsequent role in the order's roleSequence sees the same branch
    without re-resolving.

    Also emits a BRANCH_MISMATCH lifecycle event (defence-in-depth) when
    the order has an explicit voyageBranch that disagrees with its parent
    voyage's branch — operator-edited drift is the most likely cause.
    """
    if not isinstance(order_data, dict):
        return os.environ.get("ADMIRALTY_VOYAGE_BRANCH", "").strip()

    explicit = (order_data.get("voyageBranch") or "").strip()
    voyage_id = order_data.get("voyageId") or ""
    voyage_branch = ""
    if voyage_id:
        voyage = _load_voyage_by_id(voyage_id)
        voyage_branch = (voyage.get("branch") or voyage.get("voyageBranch") or "").strip()

    if explicit:
        if voyage_branch and voyage_branch != explicit:
            try:
                write_lifecycle_event(
                    "BRANCH_MISMATCH",
                    f"{order_data.get('orderId', '?')}: order.voyageBranch="
                    f"`{explicit}` but voyage {voyage_id}.branch=`{voyage_branch}` "
                    "— honouring the order. Reconcile by hand if this drift is "
                    "unintentional."
                )
            except Exception:
                pass
        return explicit

    if voyage_branch:
        return voyage_branch

    return os.environ.get("ADMIRALTY_VOYAGE_BRANCH", "").strip()


def _persist_voyage_branch_to_order(item: Dict[str, Any], voyage_branch: str) -> None:
    """Write the resolved voyageBranch back to the order JSON on disk.

    BUG-ADM-2026-0009: when resolve_voyage_branch_for_order pulls the
    branch from the parent voyage or the env var, persist it onto the
    order so the next role in roleSequence reads it directly. Single
    source of truth from this point onward — no re-resolution races.
    """
    try:
        path = Path(item["path"])
        data = item.get("data", {})
        if data.get("voyageBranch") == voyage_branch:
            return  # already up to date
        data["voyageBranch"] = voyage_branch
        path.write_text(json.dumps(data, indent=2), encoding="utf-8")
        item["data"] = data
    except Exception as exc:
        print_warn(
            f"Could not persist voyageBranch={voyage_branch} to {item.get('id', '?')}: {exc}"
        )


def dispatch_squad(crew_num: int, item: Dict[str, Any], max_iterations: int = 25,
                   timeout_minutes: int = 90, voyage_branch: str = "") -> Optional[int]:
    """Dispatch a crew to work on a queue item. Returns PID or None."""
    codename = CREW_NAMES.get(crew_num, f"Crew{crew_num}")

    print_info(f"Dispatching Crew {crew_num} ({codename}) as {item['role']} for {item['id']}...")

    order_data = item.get("data", {})
    role = resolve_role_code(item.get("role", ""))

    # BUG-ADM-2026-0009: resolve voyageBranch via the order/voyage/env chain.
    # The chain takes precedence over the dispatcher's `voyage_branch`
    # parameter — callers (run_dispatcher) compute that argument from
    # voyageId pattern matching (e.g. `voyage/<id>`) which can disagree
    # with the voyage JSON's actual `branch` field (Copilot review on
    # PR #58). The order/voyage entry wins; the parameter is a fallback
    # used only when the chain returns empty.
    resolved_branch = resolve_voyage_branch_for_order(order_data)
    if resolved_branch:
        effective_branch = resolved_branch
        # If the caller passed an explicit voyage_branch argument that
        # disagrees with the resolved value, log it — the resolved value
        # wins but the drift might be intentional (operator one-shot).
        if voyage_branch and voyage_branch != resolved_branch:
            try:
                write_lifecycle_event(
                    "BRANCH_MISMATCH",
                    f"{item.get('id', '?')}: dispatch arg voyage_branch="
                    f"`{voyage_branch}` overridden by resolved value "
                    f"`{resolved_branch}` (order/voyage wins)."
                )
            except Exception:
                pass
    else:
        effective_branch = voyage_branch or ACTIVE_VOYAGE_BRANCH

    # Persist the resolved value back to the order JSON so the next role in
    # roleSequence sees it directly and downstream handoffs can carry it.
    if effective_branch and effective_branch != order_data.get("voyageBranch"):
        _persist_voyage_branch_to_order(item, effective_branch)
        order_data = item.get("data", order_data)

    target_repo = order_data.get("targetRepo", "")
    project_acronym = order_data.get("project", "")
    if not target_repo:
        target_repo = _resolve_target_repo_from_project(order_data)

    # BUG-ADM-2026-0008 + BUG-ADM-2026-0009: combined dispatch guard.
    #   - All roles need a resolvable voyageBranch (BUG-0009 — every role
    #     writes some artefact and silent misrouting hits all of them)
    #   - SHP/BOS additionally need a resolvable targetRepo (BUG-0008 —
    #     code/test crews otherwise dispatch against a placeholder string
    #     and exit 1-iteration with no commits, burning ~$0.40 each)
    missing: list[str] = []
    if not effective_branch:
        missing.append("voyageBranch")
    if role in _REQUIRES_TARGET_REPO_ROLES and not target_repo:
        missing.append("targetRepo")

    if missing:
        msg = (
            f"Refusing to dispatch {role} for {item['id']}: "
            f"{', '.join(missing)} not resolvable "
            f"(project={project_acronym or 'unknown'}). "
            "Set order.voyageBranch (or voyage.branch on the parent voyage), "
            "and 'repo' under projects.json[<project>] for SHP/BOS roles."
        )
        print_error(msg)
        try:
            write_lifecycle_event("DISPATCH_BLOCK", msg)
        except Exception:
            pass
        try:
            mark_work_item_failed(item, reason=f"{', '.join(missing)} not resolved")
        except Exception:
            pass
        return None

    # Generate prompt
    prompt_file = generate_prompt_for_item(item)

    # Mark item as in progress
    mark_work_item_in_progress(item, crew_num)

    if effective_branch and target_repo:
        ensure_voyage_branch_exists(target_repo, effective_branch, project_acronym=project_acronym)

    # v8.13: Track dispatched repos for post-voyage PR creation
    if target_repo:
        title = item.get("title", item.get("id", ""))
        _SESSION_TARGET_REPOS.setdefault(target_repo, []).append(f"{item['id']}: {title}")
        # v2.0.2: Track voyage branch per repo
        if effective_branch:
            _SESSION_REPO_BRANCHES[target_repo] = effective_branch

    # FTR-0149: Use per-voyage git worktree instead of per-crew clone.
    # All crews of the same voyage share one worktree (idempotent prepare).
    voyage_id = order_data.get("voyageId", "")
    worktree_path = None
    if effective_branch and voyage_id:
        try:
            from admiralty.core.worktrees import prepare_voyage_worktree
            wt = prepare_voyage_worktree(voyage_id, effective_branch)
            worktree_path = str(wt)
            write_lifecycle_event(
                "DISPATCH",
                f"Crew {crew_num}: worktree ready at {wt} (voyage={voyage_id})"
            )
        except Exception as wt_exc:
            print_warn(f"Crew {crew_num}: Worktree prepare failed ({wt_exc}) — crew will self-manage")

    # Legacy fallback: per-crew repo clone (deprecated, kept for repos with no voyageId)
    repo_path = None
    if not worktree_path and effective_branch and target_repo:
        repo_path = prepare_crew_repo(crew_num, target_repo, effective_branch)
        if not repo_path:
            print_warn(f"Crew {crew_num}: Repo prep failed — crew will self-manage")

    # MCP registry validation — refuse if role is not permitted to use required servers
    try:
        _validate_mcp_before_launch(item, order_data)
    except RuntimeError:
        return None

    # v2.0.6.1: Clear stale ralph-state.md before dispatch.
    # Prevents v8.4 early-completion detection from reading the previous crew's
    # COMPLETE state in the same monitoring tick as the new dispatch, which caused
    # new orders to be immediately archived before the crew could do any work.
    ralph_file = get_crew_dir(crew_num) / "ralph-state.md"
    try:
        ralph_file.unlink(missing_ok=True)
    except OSError as e:
        # If we fail to unlink, log and fall back to truncating/overwriting the file
        print_warn(f"Crew {crew_num}: Failed to remove stale ralph-state.md at {ralph_file}: {e}. Falling back to truncate.")
        try:
            # Truncate/overwrite so that stale COMPLETE state cannot be read
            with open(ralph_file, "w", encoding="utf-8") as f:
                f.write("")
        except OSError as e2:
            print_warn(f"Crew {crew_num}: Failed to truncate ralph-state.md at {ralph_file}: {e2}. Stale state may persist.")

    # Start the crew (returns PID, fully detached).
    # BUG-ADM-2026-0009 (Copilot review on PR #58): pass `effective_branch`
    # — the resolved value from order/voyage/env — rather than the raw
    # parameter. Otherwise _verify_dispatcher_branch sees empty even when
    # the order has a resolvable branch, and ADMIRALTY_VOYAGE_BRANCH
    # injected into the crew env would be wrong, disabling branch_guard.
    pid = start_crew_process(
        crew_number=crew_num,
        role=role,
        order_id=item["id"],
        prompt_file=prompt_file,
        max_iterations=max_iterations,
        timeout=timeout_minutes,
        voyage_branch=effective_branch,
        repo_path=str(repo_path) if repo_path else "",
        project_acronym=project_acronym,
        worktree_path=worktree_path or "",
    )

    if pid:
        ACTIVE_PROCESSES[crew_num] = pid
        ORDERS_IN_TRANSITION.discard(item["id"])  # BUG-MSO-2026-0017: clear transition gate on dispatch
        print_ok(f"Crew {crew_num} ({codename}) dispatched - PID {pid}")
        print_info(f"  > {item['type']}: {item['id']} - {item['title'][:50]}")
        write_lifecycle_event("DISPATCH", f"Crew {crew_num} ({codename}) dispatched as {item['role']} for {item['id']}")
    else:
        print_error(f"Failed to dispatch Crew {crew_num}")
        write_lifecycle_event("ERROR", f"Crew {crew_num} failed to start for {item['id']}")

    return pid


def print_dispatcher_status(start_time: datetime, max_crews: int,
                           all_work: List[Dict]) -> int:
    """Print dispatcher status board (v7.0). Returns count of active crews."""
    clear_screen()

    elapsed = datetime.now() - start_time
    elapsed_str = str(elapsed).split('.')[0]

    _p = current_persona()
    print()
    print(f"  {C.CYAN}{C.BOLD}+=========================================================================+")
    print(f"  |           {_p.term('product').upper()} DISPATCHER (Auto-Dispatch Mode){' ' * (33 - len(_p.term('product')))}|")
    print(f"  +=========================================================================+{C.RESET}")
    print()

    # v7.0: Escalation banner
    esc_count, blocking_voyages = scan_escalations()
    if esc_count > 0:
        print(f"  {C.RED}{C.BOLD}!!! ESCALATIONS: {esc_count} pending (requires {_p.term('userTitle')}/{_p.term('leadTitle')} review) !!!{C.RESET}")
        if blocking_voyages:
            print(f"  {C.RED}    Blocking {_p.term('sprint').lower()}s: {', '.join(blocking_voyages)}{C.RESET}")
        print()

    print(f"  {C.WHITE}Max Concurrent {_p.term('squad').title()}s:{C.RESET} {max_crews}")
    print(f"  {C.WHITE}Started:{C.RESET}  {start_time.strftime('%Y-%m-%d %H:%M:%S')}  {C.DIM}(Elapsed: {elapsed_str}){C.RESET}")
    print()

    # Count active crews
    active_count = 0
    _squad_col = _p.term("squad").upper()
    print(f"  {C.BOLD}{_squad_col:<18} {'PID':<8} {'STATUS':<12} {'ROLE':<6} {'MODEL':<8} {'ORDER':<22}{C.RESET}")
    print(f"  {C.DIM}{'-'*75}{C.RESET}")

    for crew_num in range(1, 6):
        codename = CREW_NAMES.get(crew_num, f"Crew{crew_num}")
        pid = ACTIVE_PROCESSES.get(crew_num)
        if not pid:
            pid = read_crew_pid(crew_num)
        proc_alive = pid and is_process_alive(pid)
        pid_str = str(pid) if proc_alive else "-"

        state = read_crew_state(crew_num)

        if state:
            status = state.get("status", "UNKNOWN")
            role = state.get("role", "-")
            order_id = state.get("orderId", "-")[:20]

            if not proc_alive and status == "RUNNING":
                status = "CRASHED"
        else:
            status = "IDLE"
            role = "-"
            order_id = "-"

        # v8.7: Resolve model label from role
        model_label = ROLE_MODELS.get(role, "Sonnet") if status != "IDLE" else "-"

        # Determine display
        if status == "COMPLETE":
            icon = f"{C.GREEN}[DONE]{C.RESET}"
            status_color = C.GREEN
        elif status == "RUNNING":
            icon = f"{C.YELLOW}[>>>>]{C.RESET}"
            status_color = C.YELLOW
            active_count += 1
        elif status in ["BLOCKED", "ERROR", "CRASHED"]:
            icon = f"{C.RED}[FAIL]{C.RESET}"
            status_color = C.RED
        else:
            icon = f"{C.DIM}[IDLE]{C.RESET}"
            status_color = C.DIM

        crew_label = f"{crew_num}. {codename}"
        print(f"  {icon} {crew_label:<11} {C.CYAN}{pid_str:<8}{C.RESET} "
              f"{status_color}{status:<12}{C.RESET} {role:<6} {model_label:<8} {C.DIM}{order_id}{C.RESET}")

    print(f"  {C.DIM}{'-'*70}{C.RESET}")
    print()

    # v7.0: Unified queue status
    print(f"  {C.BOLD}QUEUE STATUS{C.RESET}")
    print(f"  {C.GREEN}Dispatchable:{C.RESET} {len(all_work)} items")
    for item in all_work[:5]:
        queue_tag = item.get("queue", "orders")
        print(f"    {C.DIM}> [{queue_tag}] {item['id']}: {item['title'][:40]} ({item['role']}){C.RESET}")
    if len(all_work) > 5:
        print(f"    {C.DIM}... and {len(all_work)-5} more{C.RESET}")

    # v7.0 + v8.2: Dependency-waiting and gate-blocked items
    if WAITING_ON_DEPS:
        # Separate gate blocks from dependency waits
        gate_items = {k: v for k, v in WAITING_ON_DEPS.items()
                      if any("ROLE GATE:" in d for d in v)}
        dep_items = {k: v for k, v in WAITING_ON_DEPS.items()
                     if not any("ROLE GATE:" in d for d in v)}

        if gate_items:
            print(f"  {C.RED}Role sequence gates:{C.RESET} {len(gate_items)} blocked")
            for item_id, deps in list(gate_items.items())[:3]:
                deps_str = ", ".join(deps[:2])
                print(f"    {C.RED}[GATE]{C.RESET} {item_id} -> {deps_str}")
            if len(gate_items) > 3:
                print(f"    {C.DIM}... and {len(gate_items)-3} more gated{C.RESET}")

        if dep_items:
            print(f"  {C.YELLOW}Waiting on deps:{C.RESET} {len(dep_items)} items")
            for item_id, deps in list(dep_items.items())[:3]:
                deps_str = ", ".join(deps[:3])
                if len(deps) > 3:
                    deps_str += f" +{len(deps)-3} more"
                print(f"    {C.DIM}[WAIT] {item_id} -> {deps_str}{C.RESET}")
            if len(dep_items) > 3:
                print(f"    {C.DIM}... and {len(dep_items)-3} more waiting{C.RESET}")

    print()
    print(f"  {C.WHITE}Active:{C.RESET} {C.YELLOW}{active_count}{C.RESET} | "
          f"{C.WHITE}Available:{C.RESET} {C.GREEN}{max_crews - active_count}{C.RESET} | "
          f"{C.WHITE}Dispatchable:{C.RESET} {len(all_work)} | "
          f"{C.WHITE}Waiting:{C.RESET} {len(WAITING_ON_DEPS)}")
    print()
    print(f"  {C.DIM}Press Ctrl+C to stop dispatcher.{C.RESET}")
    print()

    return active_count


def _tick_nav_review_auto_approve() -> None:
    """Promote orders in queues/review/ that have exceeded auto_approve_after_hours."""
    admiralty_dir = get_admiralty_dir()
    review_dir = admiralty_dir / "queues" / "review"
    if not review_dir.exists():
        return
    try:
        gate_cfg = load_gate_config(admiralty_dir)
    except Exception:
        return
    orders_dir = admiralty_dir / "queues" / "orders"
    orders_dir.mkdir(parents=True, exist_ok=True)
    for json_file in list(review_dir.glob("*.json")):
        try:
            data = json.loads(json_file.read_text(encoding="utf-8"))
            paused_at = data.get("navReviewPausedAt", "")
            if not should_auto_approve(data, gate_cfg, paused_at):
                continue
            order_id = data.get("orderId") or data.get("id") or json_file.stem
            data["status"] = "PENDING"
            data.pop("navReviewPausedAt", None)
            dest = orders_dir / json_file.name
            dest.write_text(json.dumps(data, indent=2), encoding="utf-8")
            json_file.unlink()
            print_ok(f"Order {order_id} auto-approved after timeout -> advancing to {data.get('targetRole', '?')}")
            write_lifecycle_event("NAV_REVIEW_AUTO_APPROVED", f"{order_id} auto-approved after timeout -> {data.get('targetRole', '?')}")
        except Exception as e:
            print_warn(f"Auto-approve tick error for {json_file}: {e}")


def run_dispatcher(max_crews: int = 2, stagger_delay: int = 120,
                   max_iterations: int = 25, timeout_minutes: int = 90):
    """Run the auto-dispatcher loop.

    Voyage branch comes from the ADMIRALTY_VOYAGE_BRANCH environment variable
    set before launching fleet-runner (typically via Launch-FleetCommand.bat).
    """
    global SHUTDOWN_REQUESTED

    # Dispatcher PID lock - prevent duplicate dispatchers
    dispatcher_lock = get_admiralty_dir() / "dispatcher.pid"
    if dispatcher_lock.exists():
        try:
            old_pid = int(dispatcher_lock.read_text(encoding='utf-8').strip())
            if is_process_alive(old_pid):
                print_error(f"Another dispatcher is already running (PID {old_pid})")
                print_info("Kill it first: taskkill /F /PID " + str(old_pid))
                return
        except:
            pass
    dispatcher_lock.write_text(str(os.getpid()), encoding='utf-8')

    # v8.2: Load role sequences from templates for gate enforcement
    load_role_sequences()

    print_header("AUTO-DISPATCHER v8.7 — ROLE SEQUENCE GATES")
    print_info(f"Max concurrent crews: {max_crews}")
    print_info(f"Stagger delay: {stagger_delay}s")
    print_info(f"Dispatcher PID: {os.getpid()}")
    print_info("Priority: Explicit > Security > Bugs > Requests > Orders > Defects > Breakdown > High-Level")
    print_info("Dependency checking: ENABLED")
    print_info("Escalation blocking: ENABLED")
    print_info(f"Role sequence gates: ENABLED ({len(ROLE_SEQUENCES)} sequences loaded)")
    print_info("Watching all queues...")
    print()
    write_lifecycle_event("DISPATCH", f"Dispatcher started (PID {os.getpid()}, max-crews={max_crews})")

    # BUG-MSO-2026-0018: Reconstruct in-flight claim table from crew state before first tick.
    # Prevents re-dispatching orders that already have a live crew after a dispatcher restart.
    reclaimed = _reclaim_inflight_from_crew_state()
    if reclaimed:
        print_info(f"Reclaimed {reclaimed} in-flight crew(s) from prior run — skipping their orders")
        write_lifecycle_event("DISPATCH", f"Reclaimed {reclaimed} in-flight crew(s) on startup")

    # FTR-0149: prune stale worktrees from prior runs before accepting new work
    try:
        from admiralty.core.worktrees import prune_stale_worktrees
        pruned = prune_stale_worktrees()
        if pruned:
            print_info(f"Pruned {pruned} stale worktree(s) from prior runs")
            write_lifecycle_event("DISPATCH", f"Pruned {pruned} stale worktree(s) at startup")
    except Exception as prune_exc:
        print_warn(f"Worktree prune at startup failed: {prune_exc}")

    # Setup signal handlers
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    def cleanup_dispatcher():
        cleanup_fleet("dispatcher exit")
        try: dispatcher_lock.unlink()
        except: pass

    atexit.register(cleanup_dispatcher)

    start_time = datetime.now()
    last_dispatch_time = datetime.min
    voyage_bell_rung = False  # Only ring voyage bell once when all work completes

    try:
        while not SHUTDOWN_REQUESTED:
            # v7.0: Unified queue scan (all 8 queue types, dependency-aware, escalation-aware)
            all_work = scan_all_queues()

            # Check if unified monitor is handling display
            monitor_pid_file = get_admiralty_dir() / "monitor.pid"
            monitor_running = False
            if monitor_pid_file.exists():
                try:
                    mpid = int(monitor_pid_file.read_text(encoding='utf-8').strip())
                    monitor_running = is_process_alive(mpid)
                except:
                    pass

            if not monitor_running:
                # No monitor - show status in this console
                active_count = print_dispatcher_status(start_time, max_crews, all_work)
            else:
                # Monitor is handling display - just count active crews silently
                active_count = 0
                for cn in range(1, 6):
                    pid = ACTIVE_PROCESSES.get(cn) or read_crew_pid(cn)
                    if pid and is_process_alive(pid):
                        active_count += 1

            # Check if we can dispatch more crews
            available_slots = max_crews - active_count

            if available_slots > 0:
                # Check stagger delay
                time_since_last = (datetime.now() - last_dispatch_time).total_seconds()
                if time_since_last < stagger_delay and last_dispatch_time != datetime.min:
                    remaining = int(stagger_delay - time_since_last)
                    print_info(f"Stagger delay: {remaining}s until next dispatch...")
                else:
                    # Get available crew numbers
                    available_crews = get_available_crews(max_crews)

                    if available_crews:
                        # v7.0: Unified priority — all_work is pre-sorted by tier + priority
                        work_item = all_work[0] if all_work else None

                        if work_item:
                            queue_tag = work_item.get("queue", "orders")
                            print_info(f"Picking [{queue_tag}]: {work_item['id']} (priority {work_item.get('priority', '?')})")

                            crew_num = available_crews[0]
                            # v2.0.1: Per-order voyage branch — read from order's voyageId,
                            # fall back to ACTIVE_VOYAGE_BRANCH for backwards compatibility
                            # v2.0.3: Also check inline voyageBranch (set by defect normalization)
                            order_voyage_branch = (
                                work_item.get("data", {}).get("voyageBranch", "")
                                or _get_voyage_branch_for_order(work_item["id"])
                            )
                            effective_voyage_branch = order_voyage_branch or ACTIVE_VOYAGE_BRANCH
                            pid = dispatch_squad(crew_num, work_item,
                                                max_iterations, timeout_minutes,
                                                voyage_branch=effective_voyage_branch)
                            if pid:
                                last_dispatch_time = datetime.now()
                                save_fleet_state()

            # v8.4: Early completion detection via ralph-state.md
            # Fixes: crew.py subprocess.run() hangs on open pipes (background bash)
            # even after Claude exits. ralph-state shows COMPLETE but state.json
            # still shows RUNNING because crew.py hasn't returned yet.
            for crew_num in list(ACTIVE_PROCESSES.keys()):
                pid = ACTIVE_PROCESSES[crew_num]
                if pid and is_process_alive(pid):
                    ralph_file = get_crew_dir(crew_num) / "ralph-state.md"
                    if ralph_file.exists():
                        try:
                            content = ralph_file.read_text(encoding='utf-8')
                            match = re.search(r'^status:\s*["\']?(\w+)', content, re.MULTILINE)
                            if match:
                                ralph_status = match.group(1)
                                if ralph_status in TERMINAL_STATES:
                                    print_info(f"Crew {crew_num} ralph-state={ralph_status} but process alive (pipe hang) — draining")
                                    write_lifecycle_event("DRAIN_START", f"Crew {crew_num} ralph-state={ralph_status}, pipe-hang detected — entering drain window")
                                    # Update state.json so process_crew_completion reads correct status
                                    state = read_crew_state(crew_num)
                                    if state:
                                        state["status"] = ralph_status
                                        state_file = get_crew_dir(crew_num) / "state.json"
                                        state_file.write_text(json.dumps(state, indent=2), encoding='utf-8')
                                    # Move to draining — process_crew_completion called after drain window
                                    crew_state = read_crew_state(crew_num)
                                    voyage_id = crew_state.get("voyageId", "") if crew_state else ""
                                    DRAINING_PROCESSES[crew_num] = {"pid": pid, "voyage_id": voyage_id, "drained_at": datetime.now()}
                                    del ACTIVE_PROCESSES[crew_num]
                                    # Kill the hung process (stuck on pipes)
                                    try:
                                        os.kill(pid, signal.SIGTERM)
                                    except OSError:
                                        pass
                                    continue
                        except Exception as e:
                            print_warn(f"Crew {crew_num} ralph-state read error: {e}")

            # v7.1: Clean up completed crews - full order lifecycle management
            for crew_num in list(ACTIVE_PROCESSES.keys()):
                pid = ACTIVE_PROCESSES[crew_num]
                if not pid or not is_process_alive(pid):
                    state = read_crew_state(crew_num)
                    status = state.get("status", "") if state else ""
                    if status in TERMINAL_STATES:
                        process_crew_completion(crew_num)
                        del ACTIVE_PROCESSES[crew_num]
                        # Reset to IDLE immediately so the orphaned-state scan below
                        # doesn't re-process this crew in the same dispatcher tick (BUG-MSO-2026-0015)
                        _idle = {"crewNumber": crew_num, "status": "IDLE", "role": "-", "orderId": "-"}
                        (get_crew_dir(crew_num) / "state.json").write_text(json.dumps(_idle, indent=2), encoding='utf-8')
                    elif status and status != "RUNNING":
                        # v7.1 FIX: Dead crew with unrecognized non-RUNNING state
                        # Treat as CRASHED to prevent orphaning orders
                        print_warn(f"Crew {crew_num} dead with unrecognized state '{status}' - treating as CRASHED")
                        write_lifecycle_event("WARN", f"Crew {crew_num} dead with unrecognized state '{status}' - treating as CRASHED")
                        if state:
                            state["status"] = "CRASHED"
                            state_file = get_crew_dir(crew_num) / "state.json"
                        state_file.write_text(json.dumps(state, indent=2), encoding='utf-8')
                        process_crew_completion(crew_num)
                        del ACTIVE_PROCESSES[crew_num]
                        # Reset to IDLE immediately (BUG-MSO-2026-0015)
                        _idle = {"crewNumber": crew_num, "status": "IDLE", "role": "-", "orderId": "-"}
                        (get_crew_dir(crew_num) / "state.json").write_text(json.dumps(_idle, indent=2), encoding='utf-8')

            # v7.1: Clean up orphaned crew states not tracked in ACTIVE_PROCESSES
            # (e.g. from previous dispatcher runs that left stale TIMEOUT/CRASHED states)
            for crew_num in range(1, max_crews + 1):
                if crew_num in ACTIVE_PROCESSES:
                    continue  # Already tracked
                if crew_num in DRAINING_PROCESSES:
                    continue  # In drain window — completion handled by drain-check below
                state = read_crew_state(crew_num)
                if not state:
                    continue
                status = state.get("status", "")
                if status in TERMINAL_STATES or (status and status not in ("RUNNING", "IDLE", "")):
                    pid = state.get("pid")
                    if not pid or not is_process_alive(pid):
                        # Dead crew with terminal/unexpected state - process and reset
                        if status not in TERMINAL_STATES:
                            print_warn(f"Orphaned Crew {crew_num} with unrecognized state '{status}' - treating as CRASHED")
                            write_lifecycle_event("WARN", f"Orphaned Crew {crew_num} state '{status}' - treating as CRASHED")
                            state["status"] = "CRASHED"
                            sf = get_crew_dir(crew_num) / "state.json"
                            sf.write_text(json.dumps(state, indent=2), encoding='utf-8')
                        process_crew_completion(crew_num)
                        # Reset state to IDLE so monitor shows clean
                        state_file = get_crew_dir(crew_num) / "state.json"
                        idle_state = {"crewNumber": crew_num, "status": "IDLE", "role": "-", "orderId": "-"}
                        state_file.write_text(json.dumps(idle_state, indent=2), encoding='utf-8')

            # Drain-check: complete crews that have exited AND waited out the drain window
            drain_window = int(os.environ.get("ADMIRALTY_CREW_DRAIN_SECONDS", "5"))
            _drain_now = datetime.now()
            for crew_num in list(DRAINING_PROCESSES.keys()):
                entry = DRAINING_PROCESSES[crew_num]
                elapsed = (_drain_now - entry["drained_at"]).total_seconds()
                if not is_process_alive(entry["pid"]) and elapsed >= drain_window:
                    write_lifecycle_event("DRAIN_COMPLETE", f"Crew {crew_num} drained after {drain_window}s")
                    process_crew_completion(crew_num)
                    del DRAINING_PROCESSES[crew_num]
                    # Reset to IDLE so orphan scan next tick doesn't re-process (BUG-MSO-2026-0015)
                    _idle = {"crewNumber": crew_num, "status": "IDLE", "role": "-", "orderId": "-"}
                    (get_crew_dir(crew_num) / "state.json").write_text(json.dumps(_idle, indent=2), encoding='utf-8')

            # Post-NAV auto-approve: promote orders that have waited long enough in review
            _tick_nav_review_auto_approve()

            # v8.7: Periodic orphan reset — detect IN_PROGRESS orders with no live crew
            # (Fixes: orders stuck as IN_PROGRESS when crew dies between dispatch and launch)
            reset = reset_orphaned_in_progress_orders()
            if reset > 0:
                write_lifecycle_event("DISPATCH", f"Reset {reset} orphaned IN_PROGRESS order(s) -> PENDING (v8.7 periodic check)")

            # Check if all work is done (no active crews, no pending items in any queue)
            if not ACTIVE_PROCESSES and not DRAINING_PROCESSES and not ORDERS_IN_TRANSITION and not all_work and not voyage_bell_rung:
                ring_bell()
                write_lifecycle_event("COMPLETE", "All queued work complete - Eight Bells!")
                if WAITING_ON_DEPS:
                    print_info(f"All dispatchable work complete. {len(WAITING_ON_DEPS)} item(s) waiting on dependencies.")
                else:
                    print_info("All work dispatched and completed. Dispatcher idle - watching for new orders...")

                # v2.0.5: Sweep decks — clean stale orders and complete finished voyages
                sweep_decks()

                # v8.6: Post-voyage — refresh requirements matrix from current data
                run_post_voyage_matrix_update()

                # v8.13: Post-voyage — auto-create PRs for repos with completed work
                # v2.0.0: Now a safety net — per-crew PR creation handles most cases
                run_post_voyage_pr_creation()

                # v2.0.0: Reset developer repos back to main
                reset_developer_repos()

                voyage_bell_rung = True
            elif all_work:
                # New work arrived - reset bell so it rings again when next batch completes
                voyage_bell_rung = False

            # Sleep before next check
            for _ in range(10):  # 10 second check interval
                if SHUTDOWN_REQUESTED:
                    break
                time.sleep(1)

    except KeyboardInterrupt:
        pass

    cleanup_fleet("dispatcher stopped")
    write_lifecycle_event("DISPATCH", "Dispatcher stopped")
    print(f"\n  {C.GREEN}Dispatcher stopped.{C.RESET}\n")


# =============================================================================
# MAIN FLEET RUNNER
# =============================================================================

# Legacy manifest-mode run_fleet() removed in v2.0.4 — use --dispatch instead


def _find_window_by_title(title: str) -> bool:
    """Check if a window with the given title exists (Windows only)."""
    if os.name != 'nt':
        return False
    try:
        import ctypes
        hwnd = ctypes.windll.user32.FindWindowW(None, title)
        return hwnd != 0
    except Exception:
        return False


def auto_launch_monitor():
    """Launch the unified Maestro Monitor v3.0 in a visible window.

    Checks monitor.pid AND window title to avoid launching duplicates.
    The monitor handles all status display, so the dispatcher can run silently.
    """
    monitor_title = "Maestro Monitor v3.0"

    # Check 1: PID file — is the monitor process alive?
    monitor_pid_file = get_admiralty_dir() / "monitor.pid"
    if monitor_pid_file.exists():
        try:
            mpid = int(monitor_pid_file.read_text(encoding='utf-8').strip())
            if is_process_alive(mpid):
                print_ok("Maestro Monitor already running")
                return
        except:
            pass

    # Check 2: Window title — is there already a visible monitor window?
    if _find_window_by_title(monitor_title):
        print_ok("Maestro Monitor window already exists")
        return

    monitor_py = Path(__file__).resolve().parent / "fleet_monitor.py"
    if not monitor_py.exists():
        monitor_py = get_admiralty_dir() / "core" / "fleet_monitor.py"
    if not monitor_py.exists():
        print_warn("fleet_monitor.py not found - skipping monitor launch")
        return

    try:
        print(f"\n  {C.CYAN}Launching Maestro Monitor v3.0...{C.RESET}")
        if os.name == 'nt':
            # Quote paths to handle spaces (e.g. C:\Program Files\Python313\python.exe)
            py_exe = f'"{sys.executable}"'
            mon_script = f'"{monitor_py}"'
            base = f'"{get_base_dir()}"'
            cmd = f'start "{monitor_title}" cmd /c "cd /d {base} && {py_exe} {mon_script}"'
            _spawn(cmd, identity="fleet_runner", workspace=get_base_dir(), shell=True)
        else:
            _spawn(
                [sys.executable, str(monitor_py)],
                identity="fleet_runner",
                workspace=get_base_dir(),
                start_new_session=True,
            )
        time.sleep(1)
        print_ok("Maestro Monitor launched")
        write_lifecycle_event("MONITOR", "Maestro Monitor v3.0 launched")
    except Exception as e:
        print_warn(f"Could not launch monitor: {e}")


def main():
    parser = argparse.ArgumentParser(
        description="Maestro v2.0.5 - Queue-Based Dispatch with Dependency Precedence",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s --dispatch --max-crews 5
  %(prog)s --cleanup
  %(prog)s --archive-completed
        """
    )
    parser.add_argument("--admiralty-dir", type=str, default=None,
                       help="Path to .adm directory (auto-detected from cwd if omitted)")
    parser.add_argument("--cleanup", action="store_true",
                       help="Clean up rogue processes and stale states, then exit")
    # v5.2 Auto-Dispatcher arguments
    parser.add_argument("--dispatch", action="store_true",
                       help="Run in auto-dispatch mode - watches queues and dispatches crews automatically")
    parser.add_argument("--max-crews", type=int, default=5,
                       help="Maximum concurrent crews for dispatch mode (default: 5)")
    parser.add_argument("--stagger-delay", type=int, default=30,
                       help="Seconds between crew dispatches (default: 30)")
    parser.add_argument("--max-iterations", type=int, default=25,
                       help="Max iterations per dispatched crew (default: 25)")
    parser.add_argument("--timeout", type=int, default=90,
                       help="Timeout in minutes per dispatched crew (default: 90)")
    # v6.0 Lifecycle management
    parser.add_argument("--archive-completed", action="store_true",
                       help="Archive completed/stalled orders from queues to orders/complete/")
    # v2.0.5 Deck sweep + auto-queue
    parser.add_argument("--sweep-decks", action="store_true",
                       help="Sweep decks: remove stale active orders, complete finished voyages")
    parser.add_argument("--auto-queue", action="store_true",
                       help="Auto-queue orders from orders/active/ whose dependencies are satisfied")
    # v8.2 Role sequence validation
    parser.add_argument("--validate-sequences", action="store_true",
                       help="Validate role sequence gates for all active orders (dry-run)")
    # v8.3 Requirements traceability validation
    parser.add_argument("--validate-traceability", action="store_true",
                       help="Run Requirements Scanner gate check (min 80%% coverage)")

    args = parser.parse_args()

    global _ADMIRALTY_DIR_OVERRIDE
    if args.admiralty_dir:
        _ADMIRALTY_DIR_OVERRIDE = Path(args.admiralty_dir).resolve()

    print()
    try:
        from admiralty import __version__ as _adm_version
    except ImportError:
        _adm_version = "unknown"
    print(f"  {C.CYAN}{C.BOLD}Maestro v{_adm_version}{C.RESET}")
    print(f"  {C.DIM}Queue-Based Dispatch + Dependency Precedence + Role Gates | {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}{C.RESET}")

    if args.cleanup:
        print_header("CLEANUP MODE")
        killed = preflight_kill_rogue_processes()
        print_ok(f"Killed {killed} rogue process(es)")
        cleared = preflight_clear_stale_states()
        print_ok(f"Cleared {cleared} stale state file(s)")
        reset = reset_orphaned_in_progress_orders()
        if reset > 0:
            print_ok(f"Reset {reset} orphaned IN_PROGRESS order(s) -> PENDING")
        else:
            print_ok("No orphaned orders found")
        # v2.0.1: Clean ephemeral crew repo clones (robust Windows removal)
        crew_repos_cleaned = 0
        crew_repos_failed = 0
        for cn in range(1, 6):
            repo_dir = get_crew_dir(cn) / "repo"
            if repo_dir.exists():
                if _robust_rmtree(repo_dir, label=f"Crew {cn}"):
                    crew_repos_cleaned += 1
                else:
                    crew_repos_failed += 1
                    print_warn(f"Crew {cn}: Could not remove {repo_dir} — manual cleanup needed")
        if crew_repos_cleaned > 0:
            print_ok(f"Cleaned {crew_repos_cleaned} ephemeral crew repo clone(s)")
        if crew_repos_failed > 0:
            print_warn(f"{crew_repos_failed} crew repo(s) could not be removed")
        elif crew_repos_cleaned == 0:
            print_ok("No crew repo clones to clean")
        # v8.14: Clean temp working directory
        temp_dir = get_admiralty_dir() / "temp"
        if temp_dir.exists():
            temp_cleared = 0
            for sub in ("nuget-local", "build-artifacts", "scratch"):
                sub_dir = temp_dir / sub
                if sub_dir.exists():
                    for item in sub_dir.iterdir():
                        if item.name == ".gitkeep":
                            continue
                        if item.is_dir():
                            import shutil
                            shutil.rmtree(item, ignore_errors=True)
                        else:
                            item.unlink(missing_ok=True)
                        temp_cleared += 1
            if temp_cleared > 0:
                print_ok(f"Cleared {temp_cleared} temp artifact(s) from .adm/temp/")
            else:
                print_ok("Temp directory already clean")
        print(f"\n  {C.GREEN}Cleanup complete.{C.RESET}\n")
        return 0

    # v6.0: Archive completed orders
    if args.archive_completed:
        print_header("ARCHIVE COMPLETED ORDERS")
        archived = archive_all_completed_orders()
        if archived == 0:
            print_info("No completed orders found in queues")
        else:
            print_ok(f"Archived {archived} completed order(s) to orders/complete/")
        print(f"\n  {C.GREEN}Archive complete.{C.RESET}\n")
        return 0

    # v2.0.5: Sweep decks
    if args.sweep_decks:
        print_header("SWEEP DECKS (v2.0.5)")
        result = sweep_decks()
        total = result["stale_orders_removed"] + result["voyages_completed"]
        if total == 0:
            print_info("Decks are clean - nothing to sweep")
        print(f"\n  {C.GREEN}Sweep complete.{C.RESET}\n")
        return 0

    # v2.0.5: Auto-queue unblocked orders
    if args.auto_queue:
        print_header("AUTO-QUEUE UNBLOCKED ORDERS (v2.0.5)")
        auto_queue_unblocked_orders("MANUAL")
        print(f"\n  {C.GREEN}Auto-queue complete.{C.RESET}\n")
        return 0

    # v8.2: Validate role sequences (dry-run)
    if args.validate_sequences:
        print_header("ROLE SEQUENCE VALIDATION (v8.2)")
        load_role_sequences()
        if not ROLE_SEQUENCES:
            print_error("No role sequences loaded from templates")
            return 1
        print_ok(f"Loaded {len(ROLE_SEQUENCES)} role sequence(s): {', '.join(ROLE_SEQUENCES.keys())}")
        for otype, seq in sorted(ROLE_SEQUENCES.items()):
            print_info(f"  {otype}: {' -> '.join(seq)}")
        print()

        voyage_status = build_voyage_role_status()
        if not voyage_status:
            print_info("No voyages found with active orders")
            return 0

        # Scan all active orders and check gates (queues + orders/active)
        gate_failures = 0
        gate_passes = 0
        scan_dirs = []

        # Queue directories
        queues_dir = get_queues_dir()
        for qname in ["explicit", "security", "bugs", "orders", "defects",
                       "breakdown", "high-level"]:
            qpath = queues_dir / qname
            if qpath.exists():
                scan_dirs.append(qpath)

        # orders/active directory
        active_dir = get_admiralty_dir() / "orders" / "active"
        if active_dir.exists():
            scan_dirs.append(active_dir)

        for scan_path in scan_dirs:
            for json_file in scan_path.glob("*.json"):
                try:
                    data = json.loads(json_file.read_text(encoding='utf-8'))
                    vid = data.get("voyageId", "")
                    order_id = data.get("id", json_file.stem)
                    target_role, _ = resolve_order_fields(data)
                    if not vid or vid not in voyage_status:
                        continue
                    passed, missing = check_role_sequence_gate(data, voyage_status[vid])
                    if not passed:
                        gate_failures += 1
                        missing_str = ", ".join(missing)
                        print_warn(f"  GATE BLOCK: {order_id} ({target_role}) in {vid}")
                        print_warn(f"    Prior roles not complete: {missing_str}")
                    else:
                        gate_passes += 1
                except Exception:
                    pass

        print()
        if gate_failures == 0:
            print_ok(f"All role sequence gates PASS ({gate_passes} orders checked across {len(voyage_status)} voyages)")
        else:
            print_error(f"{gate_failures} order(s) BLOCKED by role sequence gates ({gate_passes} pass)")
        print()
        return 0

    # v8.3: Validate requirements traceability
    if args.validate_traceability:
        print_header("REQUIREMENTS TRACEABILITY GATE (v8.3)")
        # v2.0.5: Resolve scanner path from project config, fallback to legacy path
        scanner_project = None
        project_info = load_project_config()
        if project_info and "_config" in project_info:
            scanner_rel = project_info["_config"].get("scannerProject")
            if scanner_rel:
                scanner_project = get_admiralty_dir().parent / scanner_rel
        if not scanner_project:
            # TODO: Remove legacy fallback once all projects define scannerProject in config
            scanner_project = get_admiralty_dir().parent / "Uplifted" / "Tools" / "RequirementsScanner"
        if not scanner_project.exists():
            print_error(f"Scanner project not found: {scanner_project}")
            return 1
        print_info("Running Requirements Scanner gate check (--gate --min-coverage 80)...")
        print()
        try:
            result = subprocess.run(
                ["dotnet", "run", "--project", str(scanner_project), "--", "--gate", "--min-coverage", "80"],
                capture_output=False,
                timeout=300,
                cwd=str(get_admiralty_dir().parent)
            )
            print()
            if result.returncode == 0:
                print_ok("Requirements traceability gate: PASS")
            else:
                print_error(f"Requirements traceability gate: FAIL (exit code {result.returncode})")
            return result.returncode
        except subprocess.TimeoutExpired:
            print_error("Scanner timed out after 300 seconds")
            return 1
        except FileNotFoundError:
            print_error("dotnet command not found - ensure .NET SDK is installed")
            return 1

    # v5.2: Auto-Dispatch mode
    if args.dispatch:
        # Light pre-flight for dispatch mode
        print_header("PRE-FLIGHT CHECKS (Dispatch Mode)")
        print_info("Checking for rogue processes...")
        killed = preflight_kill_rogue_processes()
        if killed > 0:
            print_warn(f"Killed {killed} rogue process(es)")
        else:
            print_ok("No rogue processes found")

        print_info("Verifying crew directories...")
        preflight_verify_crew_dirs()
        print_ok("Crew directories ready")

        print_info("Verifying queue directories (v7.0 - all queues)...")
        queues_dir = get_queues_dir()
        for qdir in ["explicit", "high-level", "orders", "bugs", "defects",
                      "security", "breakdown", "escalations",
                      "requests/planning", "requests/investigation",
                      "requests/qa", "requests/documentation"]:
            (queues_dir / qdir).mkdir(parents=True, exist_ok=True)
        print_ok("All queue directories ready (8 types + 4 request subtypes)")

        print_info("Checking for orphaned IN_PROGRESS orders...")
        reset = reset_orphaned_in_progress_orders()
        if reset > 0:
            print_warn(f"Reset {reset} orphaned order(s) -> PENDING")
        else:
            print_ok("No orphaned orders found")

        print(f"\n  {C.GREEN}{C.BOLD}Pre-flight checks PASSED{C.RESET}\n")
        time.sleep(1)

        # Auto-launch the unified Maestro Monitor
        auto_launch_monitor()

        # Run dispatcher
        try:
            run_dispatcher(
                max_crews=args.max_crews,
                stagger_delay=args.stagger_delay,
                max_iterations=args.max_iterations,
                timeout_minutes=args.timeout
            )
            return 0
        except Exception as e:
            print(f"\n  {C.RED}Dispatcher error: {e}{C.RESET}\n")
            cleanup_fleet("error")
            return 1

    parser.error("Please specify --dispatch, --cleanup, or --archive-completed")


if __name__ == "__main__":
    sys.exit(main())


# ---------------------------------------------------------------------------
# Rebrand vocabulary (FTR-MSO-2026-0155) — new canonical names
# ---------------------------------------------------------------------------

class TeamRunner:
    """Namespace sentinel for the fleet-runner dispatch subsystem."""


class Sprint:
    """Namespace sentinel representing a voyage/sprint unit of work."""


class Squad:
    """Namespace sentinel representing a crew/squad unit of work."""


# Legacy aliases — kept through v3.x, removed in v4.0
FleetRunner = TeamRunner  # legacy alias (v3.x); removed v4.0
Voyage = Sprint           # legacy alias (v3.x); removed v4.0
Crew = Squad              # legacy alias (v3.x); removed v4.0
dispatch_crew = dispatch_squad  # legacy alias (v3.x); removed v4.0
