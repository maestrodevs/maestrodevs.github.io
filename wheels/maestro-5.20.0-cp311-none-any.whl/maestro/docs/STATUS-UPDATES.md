# Project status updates

While Maestro is dispatching a project, it writes a short progress summary
every few minutes: what moved since the last one, what is stuck, and the
command that clears it. You read them in the Hub, or from the terminal with
`mso status-updates`. They answer "what is this project doing right now?"
without opening the log.

Status updates are **on by default**. They work on every licence tier.

- [What a status update is](#what-a-status-update-is)
- [When one is written](#when-one-is-written)
- [Quiet and idle periods](#quiet-and-idle-periods)
- [Settings](#settings)
- [In the Hub](#in-the-hub)
- [`mso status-updates`](#mso-status-updates)
- [How long they are kept](#how-long-they-are-kept)
- [Lifecycle log lines](#lifecycle-log-lines)

---

## What a status update is

An update is plain text built from what Maestro already knows: your orders,
voyages and the lifecycle log. **No model is called to write it**, so it costs
no tokens, and every order and voyage id in it is a real one.

Each update starts with a one-line **verdict**, for example
`2 voyages progressing, 1 order blocked`. Under the verdict come:

- **A line per active voyage**: how many orders are complete, which are in
  progress (and at which role), how many are pending, which are stalled, and
  the voyage's PR number once it has one.
- **What happened since the last update**: orders completed, advanced to the
  next role, retried or recovered.
- **What is stuck, and the command that clears it**: a blocked order with its
  cause, a verify failure, an order waiting at a human review gate. Each names
  the `mso` command to run, for example `mso order retry BUG-MSO-2026-0001`
  or `mso review approve|revise|reject FTR-MSO-2026-0002`.
- **Crews**: how many are busy and free, and which crew is on which order.
- **Spend** in the window, per order. Records that could not be priced are
  counted separately, never added in as zero.

The ids in the Hub are links; see [In the Hub](#in-the-hub).

---

## When one is written

Updates are written **only while the project is being dispatched**. Maestro
does not need the resident LEAD daemon for this.

| When | What is written |
|------|-----------------|
| The dispatcher starts | One start update: `Dispatched: 4 pending`, or `Dispatched: 4 pending, 1 blocked`. |
| Every `statusUpdates.intervalMinutes` while it runs | A regular update. |
| The fleet pauses (`mso pause`) | One final update: `Paused: 3 left (2 pending, 1 in progress)`, or `Paused: nothing left`. |
| The dispatcher exits for any other reason | One final update: `Stopped: 1 left (1 pending)`, or `Stopped: nothing left`. |

The final update says **what was left**, so the history never ends on a stale
"in progress".

Things worth knowing:

- **Nothing is written while the fleet is paused or draining**, and nothing is
  written after the final update, until the dispatcher starts again.
- **Nothing is written when updates are turned off** for the project.
- **A hard kill writes no final update.** If the dispatcher is killed outright
  (power loss, the process manager), the history simply stops at the last
  regular update. The Hub shows such a project as **Stopped**.
- **"N pending" counts orders that belong to an active voyage.** An order that
  is not attached to a voyage is not in that count.
- **A failed write never stops dispatch.** The dispatcher logs a warning
  (see [Lifecycle log lines](#lifecycle-log-lines)) and carries on.
- **A workspace that dispatches several projects writes one history per
  project**, each on its own settings.

---

## Quiet and idle periods

Most of the time nothing changes, and a screen full of "nothing happened" helps
nobody. So an empty window is **one line**, and repeats collapse into a single
entry:

| Situation | The line |
|-----------|----------|
| Nothing changed in the window, but work is still pending, running or blocked | `No change since 14:05`, which becomes `No change for 45 min` as more quiet intervals pile onto the same entry. |
| The dispatcher is running with nothing to do at all | `Idle, nothing pending`. |

A collapsed entry shows how many updates it stands for (`x3` in the terminal,
`3 updates` in the Hub). Heartbeats and similar housekeeping lines in the
lifecycle log do not count as a change.

A start or final update is never collapsed into a quiet entry.

---

## Settings

Two settings, both **per project**, both usable on every tier:

| Key | Type | Default | What it does |
|-----|------|---------|--------------|
| `statusUpdates.enabled` | bool | `true` | Write status updates for this project while it is dispatched. |
| `statusUpdates.intervalMinutes` | int, 5 to 240 | `15` | Minutes between regular updates. |

A value outside 5 to 240 is **refused, never clamped**:

```
$ mso settings set statusUpdates.intervalMinutes 4
statusUpdates.intervalMinutes must be between 5 and 240, got 4
```

A change takes effect within about a minute, with **no restart**.

### Which project a value belongs to

- A workspace with **one project** (or none registered) has a single pair of
  values; `mso settings set statusUpdates.enabled false` changes it.
- A workspace that dispatches **two or more projects** keeps a separate pair for
  each. Name the project with `--project`:

```bash
mso settings --project PSG set statusUpdates.intervalMinutes 30
mso settings --project PSG get statusUpdates.intervalMinutes
mso settings --project PSG unset statusUpdates.intervalMinutes
```

`--project` is not case-sensitive and accepts a leading `@` (`--project @psg`).
With no `--project`, the workspace's default project is used. A `set` or
`unset` that names an unknown project, or that names none when a multi-project
workspace has no default, is refused (the message lists the workspace's
projects). A `get` or `list` never fails on it and shows the workspace-wide value.

A project's own value wins; if it has none, the workspace-wide value applies;
if that is not set either, the default does. See [SETTINGS.md](SETTINGS.md) for
how settings resolve in general.

---

## In the Hub

### Home dashboard: "Project status"

A **Project status** panel sits directly above **Token usage · cross-project**.
It has one row per project:

- the project's name;
- a **state chip**;
- the latest update's verdict, and how long ago it was written;
- **More / Less**, which expands the rest of that update and the three updates
  before it.

| Chip | Meaning |
|------|---------|
| **Live** | The dispatcher is running, so updates are being written. |
| **Paused** | The fleet is pausing or paused. Updates stop until it resumes. |
| **Stopped** | No dispatcher is running. This also covers a dispatcher that is stuck or unresponsive. |
| **Off** | Status updates are turned off for this project (`statusUpdates.enabled` is `false`). The row says so instead of showing updates. |

Order and voyage ids in an update link to that order or voyage on the project's
page. `PR #N` links to the voyage's pull request when the Hub knows its URL.

### Project page: "Status updates"

The project's own page has a **Status updates** panel: the project's history,
the newest 50 entries, newest first. It shows the interval (`every 15 min`) and
the same state chip.

### Settings

In the workspace Settings drawer there is a **Status updates** group with both
keys. An interval outside 5 to 240 is flagged in the form and refused on save
with the message above. In a workspace that dispatches several projects, the
drawer on a project's page edits that project's values. See
[HUB.md](HUB.md#settings-workspace-and-device).

---

## `mso status-updates`

```
mso status-updates [--project @PRJ] [--last N] [--json]
```

| Flag | What it does |
|------|--------------|
| `--project @PRJ` | The registered project to show. Default: this workspace's project. |
| `--last N` | How many of the newest updates to show. Default `10`, at most `200`. Above 200 the header says `capped at 200`. `0` (or less) is an error. |
| `--json` | One JSON record per line, the same records the Hub shows, oldest first. |

Output is **oldest first**, so the newest update is the last thing on screen.
Each entry is its local time, how long ago it was, the verdict, then its detail
lines indented under it:

```
MSO: last 2 status updates (oldest first)
2026-10-30 14:05  25 min ago  Dispatched: 4 pending
2026-10-30 14:20  10 min ago  1 voyage progressing, 1 order blocked
    VOY-MSO-2026-0100 (PR #41): 1/4 complete; in progress BLD-MSO-2026-0102 (BLD); 1 pending; stalled FTR-MSO-2026-0103
    BLD-MSO-2026-0102 completed
    FTR-MSO-2026-0103 blocked at TST (verify failed) — clear with `mso order retry FTR-MSO-2026-0103`
    Crews: 1 busy, 1 free
```

When a project has no history yet it prints `<PROJECT>: no status updates yet.`

When updates are **off** for the project the command still prints whatever
history exists, and adds a note on stderr:

```
Status updates are off for this project (mso settings --project MSO set statusUpdates.enabled true).
```

With `--json` that note is not printed, so the output stays machine-readable.

The command is read-only and is not tied to a licence tier, so it works on a
machine with no Hub.

---

## How long they are kept

Status updates are **stored on the machine that runs the dispatcher** and are
never committed to git, so they do not appear in your repository history, and a
second machine does not see them. Maestro keeps about **the last 14 days** and
drops older entries on its own. There is nothing to configure.

---

## Lifecycle log lines

Each update also leaves one line in the lifecycle log, which `mso doctor` and
the log triage commands read:

| Event | Meaning |
|-------|---------|
| `STATUS_UPDATE` | An update was written. The line names the project and the verdict, for example `MSO: Dispatched: 4 pending (kind=update phase=start, record SU-…)`. A collapsed quiet entry shows `x2`, `x3`, and so on. |
| `STATUS_UPDATE_FAILED` | An update could not be written. The line starts with `WARN`, so `grep -E '\| (WARN\|ERROR) '` finds it. **Dispatch continues.** The next attempt is one interval later, not on the next pass. A bad value in a hand-edited config is reported once. |

Neither line counts as a change for the purpose of [quiet
periods](#quiet-and-idle-periods).

If you see `STATUS_UPDATE_FAILED`, fix the cause named in the line (most often
a full disk, a read-only folder, or an out-of-range value typed straight into
`workspace.json`). Nothing else needs doing; the next interval retries.
