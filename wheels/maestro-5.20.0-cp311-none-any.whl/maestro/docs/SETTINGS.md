# Settings

Maestro has **one list of settings**, **two files** that hold them, and **one
rule** for deciding which value wins. `mso settings`, the Hub's workspace
settings drawer and the Hub's **Settings** page all read and write through that
same list, so a value set in one place is exactly what the other two show.

```bash
mso settings list                    # every key: effective value + where it came from
mso settings get dispatch.maxCrews   # one key: value, source, default, scope, lock
mso settings set verifyTimeoutMinutes 30
mso settings unset verifyTimeoutMinutes
mso settings set --device spawnMonitor false
```

Every value is always shown **with its source**, e.g.
`false  (env: $MAESTRO_SPAWN_MONITOR)`. You never see "on" while an environment
variable is actually forcing "off".

---

## The rule: which value wins

For every key, the first source that has a value decides:

1. **Environment variable**, but only for keys that declare one (see the tables below).
2. **Signed policy bundle** (Enterprise). A bundle-pinned key is **locked**: it
   cannot be changed from the CLI or the Hub, and the lock reason names the bundle.
3. **Workspace file**: `<artefact root>/config/workspace.json`.
4. **Device file**: `~/.maestro/config/settings.json`.
5. **Built-in default.**

A key's **scope** decides which of the two files may hold it:

| Scope | Lives in | Meaning |
|-------|----------|---------|
| `device` | device file only | A property of this machine. Applies to every project on it. |
| `workspace` | workspace file only | A property of the project. It travels with the project's artefact plane. |
| `both` | either | A device default that one project can override. The workspace value wins. |

Three kinds of key keep their own existing storage and precedence. They are
listed under [Keys with their own storage](#keys-with-their-own-storage) below.

---

## The two files

| File | Holds | Committed? |
|------|-------|------------|
| `<artefact root>/config/workspace.json` | `workspace` and `both` keys for one project | Travels with the artefact plane: the `.mso/` directory in embedded mode, or the artefact repo in solo/shared mode ([ARTEFACT-REPO.md](ARTEFACT-REPO.md)). |
| `~/.maestro/config/settings.json` | `device` and `both` keys for this machine | Never. It is device-local. `$MAESTRO_HOME` moves it. |

Both files are ordinary JSON. Dotted keys are nested objects: `completion.voyagePr.draft`
is stored as `{"completion": {"voyagePr": {"draft": ...}}}`.

**A write changes only the key you name.** Every other key in the file is kept,
including keys that are not in the settings list. A file that exists but cannot
be parsed is **refused rather than overwritten**. Fix or remove it, then retry.

> **Keys outside the list still work.** Settings such as `completion.roleTimeouts`,
> `completion.supervision.*`, `completion.roleRejection.*`, `verify.*` and `charts`
> are honoured when you edit `workspace.json` by hand. `mso settings` and the Hub
> neither show nor write them yet.

---

## Every key

`Restart` means the value is read when a process starts. A running dispatcher
(or, for `persona`, any running `mso` process) keeps its old value until it is
restarted.

### Device

| Key | Type | Default | Env | Restart | What it does |
|-----|------|---------|-----|---------|--------------|
| `spawnMonitor` | bool | `true` | `MAESTRO_SPAWN_MONITOR` | | Open the terminal Maestro Monitor window when a dispatcher starts. With the env var, anything except `0`/`false`/`no`/`off` means on. |

### Device or workspace (`both`)

| Key | Type | Default | Env | Restart | What it does |
|-----|------|---------|-----|---------|--------------|
| `persona` | enum | `default` | `MAESTRO_PERSONA` | yes | Persona vocabulary for the CLI, the Hub and crew prompts. One of the built-in persona ids (`mso settings get persona` lists them). See [PERSONAS.md](PERSONAS.md). |
| `dispatch.maxCrews` | int ≥ 1 | `5` | | yes | Concurrent crews a dispatcher launches. The community tier is capped at 2 whatever this says. |
| `dispatch.maxTurns` | int ≥ 1 | `200` | | yes | Claude turn cap per crew iteration. |
| `dispatch.timeoutMinutes` | int ≥ 1 | `60` | | yes | Wall-clock ceiling per crew iteration. The activity watchdog (`completion.supervision.stallMinutes`) is the primary hang control; this is the backstop. |

**How `dispatch.*` is applied.** `mso dispatch` and the Hub's **Dispatch** button
resolve each limit the same way:

1. an explicit flag (`--max-crews`, `--max-turns`, `--timeout`);
2. the effective `dispatch.*` setting;
3. for crews only, a legacy `maxCrews` in `<artefact root>/config/fleet-settings.json`;
4. the built-in default.

The community crew cap applies last. A per-order `timeoutMinutes`, or
`completion.roleTimeouts`, still overrides the timeout for that order or role.

### Workspace

| Key | Type | Default | Restart | What it does |
|-----|------|---------|---------|--------------|
| `defaultGitHubOrg` | str or null | `null` | | GitHub organisation voyage branches and PRs are created in. |
| `verifyCommand` | str | `""` | | Command run in the crew worktree before a convergence push. Empty disables the local verify gate. |
| `verifyTimeoutMinutes` | int ≥ 1 | `20` | | Wall-clock cap for `verifyCommand`. |
| `completion.voyagePr.draft` | bool | `true` | | Open the voyage PR as a draft, so intermediate pushes do not run CI. |
| `completion.voyagePr.promoteOnFinalisation` | bool | `true` | | Mark the voyage PR ready for review when its last order completes. |
| `completion.voyageRel.enabled` | bool | `false` | | File one voyage-level REL order when a voyage's last order completes. |
| `completion.idleWatchdog.enabled` | bool | `true` | yes | Act when every crew is idle and no work is pending. |
| `completion.idleWatchdog.idleMinutes` | int ≥ 1 | `30` | yes | Minutes of all-crews-idle before the watchdog acts. |
| `completion.idleWatchdog.action` | enum | `cleanup` | yes | `cleanup` clears stale state and exits; `warn` logs `IDLE_TIMEOUT`; `none` does nothing. |
| `budget.maxUsd` | number ≥ 0.01, or null | `null` (no cap) | | Spend ceiling for this workspace, in US dollars. Checked between crew iterations, so it can be overshot by what crews already running go on to spend. See [Spend cap](#spend-cap-budget). |
| `budget.onReach` | enum | `pause` | | `pause` holds new dispatch and drains the dispatcher; `warn` logs `BUDGET_REACHED` once and keeps dispatching. Applies to an unpriced window in the same way. |
| `budget.windowDays` | int ≥ 1, or null | `null` (all time) | | Count only the last N days of spend against `budget.maxUsd`. Records older than the window are not counted, priced or unpriced. |
| `lead.enabled` | bool | `true` | | Whether the resident LEAD agent is enabled for this workspace. |
| `lead.tokenCeiling.dailyTokens` | int ≥ 1 | `200000` | | Daily token ceiling for the LEAD daemon. It is an abnormal backstop, not a routine limit. |
| `schedules.enabled` | bool | `false` | | Master switch for scheduled tasks. Schedules fire only while the resident LEAD daemon is running (Pro+). See [SCHEDULES.md](SCHEDULES.md). |
| `schedules.defaultTimezone` | str | `UTC` | | Timezone for a new schedule that names none: an IANA name, `UTC` or `+HH:MM`. An IANA name must load when the schedule is created; it never falls back to UTC. |
| `schedules.missedGraceMinutes` | int ≥ 1 | `60` | | How late a due occurrence may still fire. Older occurrences are recorded `MISSED` and never backfilled. |
| `schedules.maxOpenRunsDefault` | int ≥ 1 | `1` | | `maxOpenRuns` given to a new schedule. |
| `schedules.maxFiresPerTick` | int ≥ 1 | `3` | | At most this many orders filed by schedules per LEAD tick; the rest wait for the next tick. |
| `schedules.offlinePolicy` | enum | `file-local` | | While offline: `file-local` files the order locally; `skip` records `SKIPPED` and files nothing. |
| `reasoning.enabled` | bool | `true` | | Record each crew's model reasoning (secret-redacted), tool calls and Maestro steps under `<artefact root>/reasoning/<order>/`. `false` launches crews without `--thinking-display` and writes nothing. Takes effect at the next crew iteration. See [REASONING.md](REASONING.md). |
| `reasoning.storage` | enum | `local` | | `local`: reasoning is gitignored and stays on this machine; you delete it. `repo`: committed to the repository holding the artefact root once per crew run. **Repo storage is permanent in git history**: switching back or deleting the files does not remove what was committed. See [REASONING.md](REASONING.md#where-it-is-stored-local-or-repo). |
| `statusUpdates.enabled` | bool | `true` | | Write a short project status update while the dispatcher runs: one at start, one every `statusUpdates.intervalMinutes`, one when it stops or pauses. Nothing is written while the fleet is paused or draining. **Per project.** See [STATUS-UPDATES.md](STATUS-UPDATES.md). |
| `statusUpdates.intervalMinutes` | int 5 to 240 | `15` | | Minutes between status updates. A value outside 5 to 240 is refused, not clamped. Takes effect within about a minute, with no restart. **Per project.** |
| `providers.scm` / `.ci` / `.issues` / `.deploy` | object or null | none | | The SDLC provider for each kind. See [Keys with their own storage](#keys-with-their-own-storage). |
| `providers.model` | object or null | `anthropic` | | The backend every crew's Claude session runs against. See [MODEL-BACKENDS.md](MODEL-BACKENDS.md). |
| `crew.customHeaders` | object or null | `null` (none) | | Extra HTTP headers every Claude-model crew sends, for a corporate gateway or proxy: `{header name: value}`, where a credential header's value must be an `env:NAME` or `secret://…` reference. Never sent to an open-weights endpoint. The Hub shows it read-only. See [MODEL-BACKENDS.md § Gateway and proxy headers](MODEL-BACKENDS.md#gateway-and-proxy-headers-crewcustomheaders). |
| `models.<ROLE>.model` | model id | the role's default | | Claude model the role's crews run on. |
| `models.<ROLE>.contextWindow` | enum | `standard` | | `standard` or `1m`. |
| `models.<ROLE>.effort` | enum | the role's default | | `low`, `medium`, `high` or `xhigh`. |

`<ROLE>` is one of `PLN`, `BLD`, `TST`, `DOC`, `SEC`, `REL`, `LEAD`: 21 model keys in all.
Built-in defaults for the current release (`mso settings get models.<ROLE>.model` prints
what your own install resolves):

| Role | `model` | `contextWindow` | `effort` |
|------|---------|-----------------|----------|
| PLN | `claude-opus-5-5` | `standard` | `medium` |
| BLD | `claude-sonnet-5-5` | `standard` | `high` |
| TST | `claude-sonnet-5-5` | `standard` | `high` |
| DOC | `claude-sonnet-5-5` | `standard` | `high` |
| SEC | `claude-sonnet-5-5` | `standard` | `high` |
| REL | `claude-opus-5-5` | `standard` | `medium` |
| LEAD | `claude-opus-5-5` | `standard` | `medium` |

---

## Spend cap (`budget.*`)

`budget.maxUsd` puts one ceiling on what a workspace spends on crews. It is
**off by default**. Set it in the wizard (`mso setup`, step 3b) or directly:

```bash
mso settings set budget.maxUsd 25        # cap this workspace at $25
mso settings get budget.maxUsd           # effective value and the file it came from
mso settings set budget.windowDays 30    # optional: count only the last 30 days
mso settings set budget.onReach pause    # the default; `warn` reports and keeps going
mso settings unset budget.maxUsd         # remove the cap
```

**What counts as spend.** Maestro records each crew iteration's token usage and
prices it at Anthropic's published list rates, or at your own rates if the
model backend sets `pricingOverrides` ([MODEL-BACKENDS.md](MODEL-BACKENDS.md)).
`mso usage --summary` shows the same figures. It is an **estimate**, not your
invoice. With `budget.windowDays` unset, every iteration ever recorded in the
workspace counts.

**What happens at the ceiling** (`budget.onReach`):

| `onReach` | New dispatch | Running crews | Logged |
|-----------|--------------|---------------|--------|
| `pause` (default) | Held. The dispatcher drains and exits, the same way `mso pause` does. | Left to finish. Nothing is killed. | `BUDGET_REACHED`, with the spend and the ceiling |
| `warn` | Continues | Untouched | `BUDGET_REACHED`, once |

To carry on after a `pause`, raise the ceiling (or unset it), then run
`mso resume` or `mso dispatch`. A dispatcher started while the spend is still
over the ceiling holds and drains again straight away. The same applies to
`mso resume` while the dispatcher is still draining. It withdraws the pause,
but if the budget still holds, the dispatcher requests the pause again on its
next tick and logs why. To change the outcome, change the budget, not the pause.

**Three things the cap does not do.** Plan around them:

1. **It is not exact.** The check runs **between crew iterations**, never in the
   middle of one. A crew that is already running when the ceiling is crossed
   finishes its iteration. The worst case is therefore the ceiling **plus**
   whatever the crews in flight go on to spend. With several crews running,
   set the ceiling below your real limit.
2. **It never passes on spend it cannot price without saying so.** Some
   backends (for example AWS Bedrock without `pricingOverrides`) record usage
   as **unpriced**. If the counted window holds any unpriced record, the cap
   cannot prove you are under it, and `BUDGET_BASIS_UNPRICED` is always logged.
   `budget.onReach` then decides, exactly as it does at the ceiling. With
   `pause`, new dispatch is held and the dispatcher drains and exits. With
   `warn`, the event is logged once and dispatch continues. Records older than
   `budget.windowDays` are never counted, so they never hold dispatch. With no
   window set, every record counts. To dispatch again under `pause`, add
   `pricingOverrides` for the backend, narrow `budget.windowDays` past the
   unpriced records, set `budget.onReach` to `warn`, or unset `budget.maxUsd`.
3. **It is per workspace only.** There is no per-voyage or per-order cap.

A value that is not a dollar amount (a hand-edited `workspace.json`, say) also
holds dispatch, and logs `BUDGET_CONFIG_INVALID` until it is fixed or unset.

The invalid-value hold does not stop the dispatcher. It keeps running, holds
new dispatch, and resumes by itself once the value is fixed, logging
`BUDGET_HOLD_LIFTED`. An unpriced hold under `pause` drains the dispatcher like
the ceiling does, so relaunch it once the cause is fixed.

Every event above is written to `.mso/logs/lifecycle.log`. **The Hub cannot
edit number settings yet**, so set `budget.maxUsd` with `mso settings` or the
wizard.

---

## What `mso setup` writes

The wizard writes through the same settings list, so anything it sets reads
back with `mso settings get`. Three of its steps exist only to set a switch
that is otherwise easy to miss. Each one is skippable: a blank answer keeps the
current value and writes nothing. Each step also prints the file it wrote.

| Step | Question | Writes | Scope |
|------|----------|--------|-------|
| 3b — Spend cap | A ceiling in US dollars. Blank means no cap (or keeps an existing one). `none` removes it. | `budget.maxUsd` | workspace |
| 3c — Plan-review gate | *"Do you want a human to approve plans before building starts?"* | `post_nav_review.enabled` in `<artefact root>/config/gates.json` | workspace |
| 3d — Monitor window | Open the terminal monitor window each time `mso dispatch` starts? | `spawnMonitor` in `~/.maestro/config/settings.json` | **device**: every workspace on this machine |

- **Plan-review gate on:** a finished plan parks in `queues/review/` and nothing
  is built until you run `mso review approve <ORDER-ID>`
  ([HUMAN-REVIEW-GATES.md](HUMAN-REVIEW-GATES.md)). Off (the default): building
  starts as soon as the plan is written. `gates.json` is not part of the
  settings list, so `mso settings` does not show this switch. Re-run the step,
  or edit the file. If `gates.json` also has a `transitions["PLN->BLD"]` entry,
  that entry wins, and the step warns you that it exists.
- **Monitor window:** `$MAESTRO_SPAWN_MONITOR` still overrides the file. The step
  runs without a workspace. Change it later with
  `mso settings set --device spawnMonitor false`.

**Unattended runs.** `mso setup --non-interactive --answers FILE` reads the same
three answers from `key=value` lines:

```
budget.maxUsd=25
gates.post_nav_review.enabled=yes
spawnMonitor=no
```

A switch accepts `y`/`yes`/`1`/`true`/`on` or `n`/`no`/`0`/`false`/`off`. A key
you leave out keeps its current value. A malformed value makes the run exit `1`
and writes nothing for that step.
[FIRST-HOUR.md](FIRST-HOUR.md#unattended-the-same-setup-from-an-answers-file)
has a complete answers file.

**Changing one answer later.** Re-run just that step: `mso setup --only budget`,
`mso setup --only review_gate` or `mso setup --only monitor_window` (add `--gui`
to answer in your browser). `mso settings set` works too for the keys in the
settings list.

**The setup record is not a setting.** Each wizard run also writes
`config/setup-state.json` (workspace steps; commit it) and
`~/.maestro/setup-state.json` (device steps). They record which steps were
done, declined or left unanswered — **never the answers themselves**, which live
only in the files in the table above. `mso settings` does not read or write
them. See [SETUP.md § The setup record](SETUP.md#the-setup-record).

---

## Keys with their own storage

These keys keep the files and precedence they already had. `mso settings` writes
them into those same files, so nothing about how they are honoured has changed.

### `persona`

The persona is **not** stored in `workspace.json` or `settings.json`. It lives
in the persona files the persona resolver has always read:

| Scope | File |
|-------|------|
| workspace | `<product repo>/.maestro/config/persona.json` |
| device | `~/.maestro/config/persona.json` |

`mso settings set persona nautical` writes the pointer form `{"id": "nautical"}`.
The resolver's order is unchanged: `MAESTRO_PERSONA` > workspace file > device
file > built-in `default`.

If a persona file holds a **full custom persona definition** rather than a
pointer, Maestro refuses to overwrite or remove it. Move it aside by hand first.

A `persona` key inside `workspace.json` is **not read** by anything.

### `models.<ROLE>.*`

Role models live in `<artefact root>/config/role-models.json`, the same file
`mso config models` reports on ([CONFIG-MODELS.md](CONFIG-MODELS.md)). A write
preserves the file's `_comment` and every other entry. The value and source
shown are the ones the crew resolver itself produces. Their precedence is the
resolver's own:

1. a `model` field on the order itself;
2. `role-models.json` (source `workspace`);
3. `MAESTRO_MODEL_<ROLE>`, `MAESTRO_CONTEXT_<ROLE>` or `MAESTRO_EFFORT_<ROLE>` (source `env`);
4. a role overlay in `.mso/config/roles/<CODE>.md` (source `overlay`);
5. the built-in default.

**Only current-generation models may be chosen.** The model list is taken from
the models this Maestro version supports. The newest model of each family counts
as current, and `claude-opus-5-5` (the LEAD default) is offered first.

Previous-generation ids such as `claude-opus-4-8` and `claude-sonnet-4-6` are
still **supported**. A pin that already names one keeps working, and is shown
flagged `previous generation`. They are **not offered** as a new choice:
`mso settings set models.PLN.model claude-opus-4-8` is refused, with the list of
current ids.

A bare model id is required. To use the 1M context window, set
`models.<ROLE>.contextWindow` to `1m` rather than appending `[1m]` to the id.

### `providers.<kind>`

Provider settings are written by the provider configuration code, into the
`providers` block of `workspace.json`. The value is an object:

```bash
mso settings set providers.ci '{"id": "jenkins", "config": {"url": "https://ci.example.com"}}'
```

A provider locked by a signed policy bundle is reported as locked, and cannot be
changed. In the Hub these keys appear in the **SDLC Providers** section, not in
the generic settings form. See [PROVIDERS.md](PROVIDERS.md).

`providers.model` is stored the same way and resolves by the same rules, but it
is not an SDLC capability — it selects the backend every crew's Claude session
runs against. Unlike the other four kinds it never resolves to `none`: absent,
it resolves to `anthropic`, the direct Anthropic API, which is byte-for-byte the
behaviour of a workspace that has never configured a backend. Prefer
`mso providers set model <id> --config KEY=VALUE` or `mso setup`'s **Model
backend** step over writing the object by hand — both go through the same
credential guard. See [MODEL-BACKENDS.md](MODEL-BACKENDS.md).

---

## `mso settings`

```
mso settings [--project ACRONYM] list  [--device] [--json]
mso settings [--project ACRONYM] get   KEY [--device] [--json]
mso settings [--project ACRONYM] set   KEY VALUE [--device]
mso settings [--project ACRONYM] unset KEY [--device]
```

| Action | What it does |
|--------|--------------|
| `list` | Every key with its effective value and source. Inside a workspace this is every key; with `--device` it is only the `device` and `both` keys, resolved without a workspace. |
| `get KEY` | One key: value, source, default, scope, and whether it needs a restart or is locked. |
| `set KEY VALUE` | Write the key. By default a `device` key goes to the device file and every other key to the workspace file. `--device` writes a `both` key to the device file instead. |
| `unset KEY` | Remove the key from that file, so the next source in the rule applies. |

`--project ACRONYM` picks a registered workspace when you are not inside one.
For the **per-project** keys (`statusUpdates.*`) it also picks which project's
value is read or written when the workspace dispatches two or more projects:
the acronym is not case-sensitive and may start with `@`, and with no
`--project` the workspace's default project is used. A `set` or `unset` naming an
unknown project, or naming none when a multi-project workspace has no default, is
refused; reads fall back to the workspace-wide value. A workspace with one project
keeps a single top-level value. See [STATUS-UPDATES.md](STATUS-UPDATES.md#settings).

**Values** are parsed by type:
- bool: `true`/`false`, `yes`/`no`, `on`/`off`, `1`/`0`;
- int: a whole number;
- nullable key: `null`;
- object: JSON.

**After a write** the command prints the effective value read back from disk.
If a higher source still wins, for example an environment variable, the output
says so. A write to a restart key reminds you to restart.

**Errors** exit `1` with a reason and, where there is one, a hint. The errors are:
- an unknown key;
- a value of the wrong type or out of range;
- a `workspace` key with `--device`;
- a `device` key without `--device`;
- a locked key;
- a file Maestro refuses to overwrite.

In a **governed** workspace, writing a workspace setting also requires the
`settings.write` identity capability.

---

## In the Hub

- **Workspace settings drawer** (a workspace's **Settings** button). It shows every
  `workspace` and `both` key for that project and saves to its workspace file.
- **Settings page** (sidebar → **Settings**, headed *Applies to every project on
  this device*). It shows the `device` and `both` keys and saves to the device file.

Both screens are generated from the settings list. A key appears in the Hub
only if Maestro knows which code honours it.

What you will see:

- **A source badge on every field**: `workspace`, `device`, `env`, `bundle`,
  `overlay` or `default`. A workspace value overrides a device value.
- **Read-only fields, with the reason shown.** A field whose value comes from an
  environment variable or a policy bundle, or that is locked, cannot be edited
  in the Hub. Change the environment variable or the bundle instead.
- **A `restart` chip** on keys that take effect at the next dispatcher start.
- **Save sends only the keys you changed**, one request per key, then re-reads.
  If some writes fail, the message names the keys that were not written.
- **Repositories are read-only.** Change a workspace's repositories with
  `mso migrate import-workspace` ([MULTI-REPO.md](MULTI-REPO.md)).

Saving from the Hub requires a **Pro, Team or Enterprise** licence. Save is
also unavailable in an observe-only (containerised) Hub. The reason is shown on
the control before you click. Reading settings is never gated. Endpoints and
capability fields: [HUB.md](HUB.md#settings-workspace-and-device).

The drawer no longer shows `maxIterations`, `autoDispatch` or `tokenDailyCap`.
Nothing in Maestro ever read them. Use `dispatch.maxCrews`, `dispatch.maxTurns`
and `dispatch.timeoutMinutes` for dispatch limits.
