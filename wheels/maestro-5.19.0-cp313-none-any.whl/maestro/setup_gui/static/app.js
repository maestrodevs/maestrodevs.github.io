/* mso setup --gui — the browser half (FTR-MSO-2026-1040).
 *
 * Build-free vanilla JS. Every string from the server is rendered with
 * textContent, never innerHTML: the transcript is the wizard's own output and
 * is treated as untrusted text.
 *
 * The one-time key arrives in the URL fragment (#t=...), which browsers never
 * send to a server. It is moved to sessionStorage and the fragment is cleared
 * at once, so it does not linger in the address bar or history. Every API call
 * sends it as X-Maestro-Setup-Token, plus the claim this tab was given as
 * X-Maestro-Setup-Claim.
 *
 * FTR-MSO-2026-1041: the page lists the steps this run takes (all of them,
 * only the pending ones for --new, or exactly --only's), ends on the same
 * rows `mso setup --check --json` prints, and offers the run's answers as a
 * file `mso setup --non-interactive --answers` replays.
 */
(function () {
  "use strict";

  var TOKEN_KEY = "maestro.setup.token";
  var CLAIM_KEY = "maestro.setup.claim";
  var TERMINAL = { done: true, failed: true, cancelled: true };

  var $ = function (id) { return document.getElementById(id); };

  var token = takeToken();
  var claim = sessionStorage.getItem(CLAIM_KEY);
  var since = 0;
  var version = null;
  var shownQuestion = null;
  var finished = false;
  var failures = 0;
  var planShown = false;

  function takeToken() {
    var match = /(?:^#|&)t=([A-Za-z0-9_-]+)/.exec(window.location.hash || "");
    if (match) {
      sessionStorage.setItem(TOKEN_KEY, match[1]);
      history.replaceState(null, "", window.location.pathname);
    }
    return sessionStorage.getItem(TOKEN_KEY);
  }

  function api(method, path, body) {
    var headers = { "X-Maestro-Setup-Token": token || "" };
    if (claim) { headers["X-Maestro-Setup-Claim"] = claim; }
    var init = { method: method, headers: headers, cache: "no-store",
                 credentials: "same-origin", referrerPolicy: "no-referrer" };
    if (method === "POST") {
      headers["Content-Type"] = "application/json";
      init.body = JSON.stringify(body || {});
    }
    return fetch(path, init).then(function (res) {
      return res.json().catch(function () { return {}; }).then(function (data) {
        return { status: res.status, data: data };
      });
    });
  }

  function notice(text, kind) {
    var box = $("notice");
    box.textContent = text;
    box.className = "notice" + (kind ? " " + kind : "");
    box.hidden = !text;
  }

  function stop(text) {
    finished = true;
    $("cancel").hidden = true;
    $("question").hidden = true;
    notice(text, "error");
  }

  // -- rendering -----------------------------------------------------------
  function render(data) {
    if (data.persona && data.persona.product) {
      $("title").textContent = data.persona.product + " setup";
      document.title = data.persona.product + " setup";
    }
    renderPlan(data.run, data.step, data.state);
    renderStep(data.step);
    appendTranscript(data.transcript || []);
    since = typeof data.next === "number" ? data.next : since;
    version = data.version;
    if (TERMINAL[data.state]) {
      renderResult(data);
      return;
    }
    $("cancel").hidden = false;
    renderQuestion(data.question);
  }

  function renderStep(step) {
    if (!step) { return; }
    $("progress").hidden = false;
    $("step-label").textContent = "Step " + step.index + " of " + step.total + " — " + step.title;
    var pct = step.total ? Math.round((100 * (step.index - 1)) / step.total) : 0;
    $("meter-fill").style.width = pct + "%";
  }

  var PLAN_TITLES = {
    full: "This run takes every setup step",
    "new": "This run takes only the pending steps",
    only: "This run takes only the steps you named"
  };

  function renderPlan(run, step, state) {
    if (!run || !run.steps) { return; }
    var list = $("plan-steps");
    if (!planShown) {
      planShown = true;
      $("plan-title").textContent = PLAN_TITLES[run.mode] || PLAN_TITLES.full;
      run.steps.forEach(function (s) {
        var li = document.createElement("li");
        li.textContent = s.title;
        li.setAttribute("data-key", s.key);
        list.appendChild(li);
      });
      $("plan").hidden = false;
    }
    var current = step ? step.index : 0;
    var items = list.children;
    for (var i = 0; i < items.length; i += 1) {
      var n = i + 1;
      var over = state === "done" || n < current;
      items[i].className = over ? "done" : (n === current ? "current" : "");
    }
  }

  function appendTranscript(lines) {
    if (!lines.length) { return; }
    var pre = $("transcript");
    var atBottom = pre.scrollTop + pre.clientHeight >= pre.scrollHeight - 8;
    pre.appendChild(document.createTextNode(lines.join("\n") + "\n"));
    if (atBottom) { pre.scrollTop = pre.scrollHeight; }
  }

  function button(label, cls, onClick) {
    var b = document.createElement("button");
    b.type = "button";
    b.className = cls;
    b.textContent = label;
    b.addEventListener("click", onClick);
    return b;
  }

  function renderQuestion(q) {
    var card = $("question");
    if (!q) {
      card.hidden = true;
      shownQuestion = null;
      return;
    }
    if (shownQuestion === q.id) { return; }  // keep what the operator is typing
    shownQuestion = q.id;
    card.hidden = false;
    $("question-prompt").textContent = q.prompt;
    $("question-error").hidden = true;
    var controls = $("question-controls");
    while (controls.firstChild) { controls.removeChild(controls.firstChild); }
    var form = $("question-form");
    form.onsubmit = function (ev) { ev.preventDefault(); };

    if (q.kind === "yes_no") {
      var yes = button("Yes", q.default ? "primary" : "secondary", function () { send(q, true); });
      var no = button("No", q.default ? "secondary" : "primary", function () { send(q, false); });
      controls.appendChild(yes);
      controls.appendChild(no);
      (q.default ? yes : no).focus();
      return;
    }

    if (q.kind === "choice" && q.choices && q.choices.length) {
      q.choices.forEach(function (choice) {
        var cls = choice === q.default ? "primary" : "secondary";
        controls.appendChild(button(choice, cls, function () { send(q, choice); }));
      });
      var keepLabel = q.default ? "Keep default (" + q.default + ")" : "Skip";
      controls.appendChild(button(keepLabel, "link", function () { send(q, ""); }));
      return;
    }

    var input = document.createElement("input");
    input.type = q.secret ? "password" : "text";
    input.id = "answer";
    input.autocomplete = "off";
    input.spellcheck = false;
    if (q.default) { input.placeholder = "Leave blank to keep: " + q.default; }
    var submit = document.createElement("button");
    submit.type = "submit";  // the form's onsubmit sends — no click handler, or it sends twice
    submit.className = "primary";
    submit.textContent = "Continue";
    form.onsubmit = function (ev) { ev.preventDefault(); send(q, input.value); };
    controls.appendChild(input);
    controls.appendChild(submit);
    input.focus();
  }

  function renderResult(data) {
    finished = true;
    $("cancel").hidden = true;
    $("question").hidden = true;
    var box = $("result");
    box.hidden = false;
    var title = { done: "Setup finished", failed: "Setup did not complete",
                  cancelled: "Setup stopped" }[data.state];
    $("result-title").textContent = title;
    var summary;
    if (data.state === "done") {
      summary = data.exitCode === 0
        ? "Every check passed — a dispatch would start."
        : "Setup finished, but some checks need fixing before a dispatch would start (exit code " + data.exitCode + ").";
    } else if (data.state === "cancelled") {
      summary = (data.cancelReason === "idle" ? "Stopped after the idle timeout." : "Cancelled.") +
        " The step it was on stays pending — re-run mso setup --gui to continue.";
    } else {
      summary = "The transcript below shows why (exit code " + data.exitCode + ").";
    }
    $("result-summary").textContent = summary;
    renderChecks(data.checks);
    renderCheckSummary(data.checkSummary);
    if (data.state === "done" && data.answersFile) { loadAnswers(); }
  }

  function renderCheckSummary(doc) {
    if (!doc || !doc.summary) { return; }
    var s = doc.summary;
    var line = s.checks + " checks: " + s.ok + " OK, " + s.warn + " WARN, " + s.fail + " FAIL. " +
      (s.wouldStart ? "A dispatch would start." : "A dispatch would not start yet.");
    if (!s.smoke) { line += " Claude sign-in was not verified (mso setup --check --smoke does)."; }
    var p = $("checks-summary");
    p.textContent = line;
    p.hidden = false;
    var commands = doc.nextCommands || [];
    if (commands.length) {
      $("next-commands-list").textContent = commands.join("\n");
      $("next-commands").hidden = false;
    }
  }

  function loadAnswers() {
    var headers = { "X-Maestro-Setup-Token": token || "", "X-Maestro-Setup-Claim": claim || "" };
    fetch("/api/answers-file", { method: "GET", headers: headers, cache: "no-store",
                                 credentials: "same-origin", referrerPolicy: "no-referrer" })
      .then(function (res) { return res.ok ? res.text() : null; })
      .then(function (text) {
        if (text === null) { return; }
        $("answers-text").textContent = text;
        var replay = /^#\s+(mso setup --non-interactive[^\n]*)$/m.exec(text);
        $("answers-replay").textContent = replay ? replay[1] : "mso setup --non-interactive --answers <file>";
        $("answers-download").onclick = function () { download(text); };
        $("answers").hidden = false;
      })
      .catch(function () { /* the server has gone; the transcript still shows the run */ });
  }

  function download(text) {
    var url = URL.createObjectURL(new Blob([text], { type: "text/plain" }));
    var a = document.createElement("a");
    a.href = url;
    a.download = "mso-setup-answers.txt";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
  }

  function renderChecks(rows) {
    if (!rows || !rows.length) { return; }
    var body = $("checks-body");
    while (body.firstChild) { body.removeChild(body.firstChild); }
    rows.forEach(function (row) {
      var tr = document.createElement("tr");
      tr.className = "status-" + String(row.status).toLowerCase();
      [row.name, row.status, row.message, row.remediation].forEach(function (text) {
        var td = document.createElement("td");
        td.textContent = text == null ? "" : String(text);
        tr.appendChild(td);
      });
      body.appendChild(tr);
    });
    $("checks").hidden = false;
  }

  // -- actions -------------------------------------------------------------
  function send(q, value) {
    $("question-error").hidden = true;
    api("POST", "/api/answer", { questionId: q.id, value: value }).then(function (res) {
      if (res.status === 200) {
        $("question").hidden = true;
        return;
      }
      if (res.status === 400) {
        var err = $("question-error");
        err.textContent = (res.data && res.data.error) || "That answer was not accepted.";
        err.hidden = false;
        return;
      }
      // 409: the question moved on; the next poll shows the current one.
    }).catch(function () { /* the poll loop reports a lost server */ });
  }

  $("cancel").addEventListener("click", function () {
    if (!window.confirm("Cancel setup? The step you are on stays pending.")) { return; }
    api("POST", "/api/cancel", {}).catch(function () {});
  });

  // -- the loop --------------------------------------------------------------
  function poll() {
    if (finished) { return; }
    var path = "/api/session?since=" + since + (version === null ? "" : "&v=" + version);
    api("GET", path).then(function (res) {
      failures = 0;
      if (res.status === 401) { return stop("This setup link is no longer valid. Run mso setup --gui again."); }
      if (res.status === 409) { return stop("This setup is already open in another tab."); }
      if (res.status !== 200) { return stop("The setup server refused the request (" + res.status + ")."); }
      notice("");
      render(res.data);
      if (!finished) { poll(); }
    }).catch(function () {
      failures += 1;
      if (failures >= 3) {
        return stop("The setup server has stopped. The terminal that ran mso setup --gui shows the result.");
      }
      window.setTimeout(poll, 1000);
    });
  }

  function start() {
    if (!token) {
      return stop("Open the full address printed by mso setup --gui — it carries a one-time key.");
    }
    if (claim) { return poll(); }
    api("POST", "/api/claim", {}).then(function (res) {
      if (res.status === 200 && res.data.claim) {
        claim = res.data.claim;
        sessionStorage.setItem(CLAIM_KEY, claim);
        return poll();
      }
      if (res.status === 409) { return stop("This setup is already open in another tab."); }
      if (res.status === 401) { return stop("This setup link is no longer valid. Run mso setup --gui again."); }
      return stop("The setup server refused the request (" + res.status + ").");
    }).catch(function () {
      stop("Could not reach the setup server. Is mso setup --gui still running?");
    });
  }

  start();
})();
