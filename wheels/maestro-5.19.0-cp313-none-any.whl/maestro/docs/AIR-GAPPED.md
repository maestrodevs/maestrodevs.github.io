# Air-gapped operation

> Running Maestro on a machine that has no internet egress.

> **Working offline for a while rather than permanently?** Use offline mode (`mso offline on`): voyage branches and convergence run locally, every remote step is recorded in an outbox, and `mso outbox replay` publishes it safely when you are back. See [OFFLINE.md](OFFLINE.md). On a machine that is *always* offline, set `mso settings set offline.mode on` so the fleet never tries the network.

## What works air-gapped

- Every `mso` command except activation.
- Crew dispatch, voyage management, status monitoring, all role workflows.
- Anthropic API access via your own outbound proxy / corporate egress.
- Custom MCP servers running on the same machine or LAN.

## What needs the internet at least once

- **First activation** (`mso licence activate <KEY>`) — the CLI must reach `api.polar.sh` to confirm the key is granted and obtain the per-customer signing secret. **There is no offline activation flow** — Polar's licence model is online-first by design.
- **Periodic re-validation** — every 24 hours of CLI use, the next `mso` invocation refreshes against Polar. If the connection fails, you get up to **14 days of offline grace** before the CLI refuses to start.

## Recommended pattern for fully air-gapped machines

1. **Activate on a network-connected staging machine first.**
   ```bash
   mso licence activate <KEY>
   mso licence status   # confirm tier + expires_at
   ```

2. **Export a transferable bundle.** *(Coming in v2.5.x — for now, copy the files manually as below.)*

   Manual transfer: copy `~/.maestro/licence.json` to the air-gapped machine, then re-export the keychain entry. On macOS:
   ```bash
   security find-generic-password -s maestro-licence -a <customer_id> -w
   ```
   Set the same value on the air-gapped machine via:
   ```bash
   security add-generic-password -s maestro-licence -a <customer_id> -w "<the value>"
   ```
   Linux/libsecret: use `secret-tool` with the same service/account pair. Windows: use Credential Manager export.

3. **Refresh every 14 days.** The air-gapped machine doesn't know its own grace deadline expired until you next try to run `mso`. Keep a calendar reminder; 14 days before grace runs out, repeat the process from step 1 on the staging machine and copy the refreshed `licence.json` across.

## What if I never reconnect?

`mso` refuses to start past day 14 of the grace window. The recovery path is:
- Reconnect the staging machine.
- Run `mso licence revalidate` on staging.
- Copy the refreshed `licence.json` to the air-gapped machine.

This isn't an enforcement choice we love, but it's the licensing model's contract. An `MSO1.` token licence avoids it: it is verified on the machine with no network call and runs until its expiry date (see [OFFLINE.md § Licence advice](OFFLINE.md#licence-advice-for-offline-use)). If you have a hard requirement for indefinite air-gapped operation, open a [GitHub Issue](https://github.com/Maestrodevs) — we may be able to issue a long-lived licence variant for your environment.

## Egress allowlist (when "air-gapped" means "egress-restricted")

If your machine has restrictive egress rather than zero egress, allowlist exactly:

| Host | Purpose | Frequency |
|---|---|---|
| `api.anthropic.com` | Model inference (your own API key) | Per crew tool call |
| `api.polar.sh` | Licence validation | At activation + every ~24h thereafter |
| `api.github.com` | (Only during the install / upgrade flow) | One-off |
| Your MCP server hosts | Whatever your `.mso/config/mcp-servers.json` lists | Per MCP tool call |

That's the entire egress surface for the CLI. The Slack bridge and Gist integrations are opt-in (see `docs/TRUST.md`).

## Running models without the internet

To keep model inference on your own machine, serve an open-weights model locally and route roles to it — see [LOCAL-MODELS.md](LOCAL-MODELS.md), including its [Offline scope](LOCAL-MODELS.md#offline-scope) section for what a fleet still needs the network for.
