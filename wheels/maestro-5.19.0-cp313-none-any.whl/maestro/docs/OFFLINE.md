# Offline mode

> Doing a voyage's work with no network, and publishing it safely when the network comes back.

Offline mode is something you switch on. Maestro does not enter it by guessing that the network is down. While it is on, voyage branches, crew worktrees and convergence all run on your machine. Every remote step Maestro could not take (creating the branch on the remote, pushing it, opening the draft PR, pushing the artefact plane) is recorded in an **outbox**. When you are back online, you publish the outbox with one command. That command shows you a dry run first, only ever fast-forwards, and never force-pushes.

Offline mode, the outbox and `mso outbox replay` are available on **every tier**. Automatic replay by the resident LEAD needs Pro or above, because the resident LEAD itself does.

Related: [AIR-GAPPED.md](AIR-GAPPED.md) (machines that never have internet egress), [LICENCE.md](LICENCE.md), [CLI-REFERENCE.md](CLI-REFERENCE.md#mso-offline).

---

## Contents

- [Before you go offline](#before-you-go-offline)
- [Going offline](#going-offline)
- [What works offline](#what-works-offline)
- [What is held or refused](#what-is-held-or-refused)
- [Watching an offline fleet](#watching-an-offline-fleet)
- [The outbox](#the-outbox)
- [Coming back online](#coming-back-online)
- [When replay stops on a branch](#when-replay-stops-on-a-branch)
- [Resolving divergence](#resolving-divergence)
- [Licence advice for offline use](#licence-advice-for-offline-use)
- [The data-egress guarantee](#the-data-egress-guarantee)
- [Known limitations](#known-limitations)

---

## Before you go offline

Run through this list while you still have a connection.

| Check | Why |
|---|---|
| **A local model backend is configured.** | Orders on a hosted model (Anthropic, Bedrock) are held while offline, because they cannot reach their model. If no local backend is configured, offline mode holds **every** order, and `mso offline on` warns you about this. |
| **Your licence will last the trip.** | A `MSO1.` token licence is verified offline and works until it expires. A legacy (v1) licence has a 14-day offline grace, after which the fleet stops. See [Licence advice](#licence-advice-for-offline-use). Pass `--for` to `mso offline on` and Maestro warns you if the grace ends before you are back. |
| **The workspace is not in shared artefact mode.** | `mso offline on` refuses in `artefacts.mode: shared`. Shared mode needs an accepted push to claim an order and to reserve order IDs, so two offline machines could claim the same order or mint the same IDs. Switch this device to **solo** mode for the offline period instead. |
| **Your local view of the remote is fresh.** | Run `git fetch` in the product repo. Offline mode records the remote-tracking refs you have at that moment and cuts new voyage branches from your local `origin/<default branch>`. |
| **Decide about push-on-reconnect.** | If the resident LEAD should publish this session's work by itself when the network returns, say so now with `--push-on-reconnect`. You cannot add that consent later in the same session. |

---

## Going offline

```bash
mso offline on --reason "travelling" --for 3d
mso offline on --push-on-reconnect           # also let the resident LEAD publish on reconnect
```

`mso offline on` opens an **offline session**:

- It records a session id, who entered it and why, and whether you gave push-on-reconnect consent.
- It records a **baseline**: the remote URL of each repo and the remote-tracking refs you currently have. This is read from your local clone and needs no network. When you come back, replay checks your pushes against this baseline.
- It prints warnings: no local model backend configured, or a licence grace that ends before the `--for` period does.

Running it again while a session is live changes nothing. To change the push-on-reconnect consent, run `mso offline off`, then `mso offline on` again.

`--for` takes `90m`, `36h`, `3d` or `2w`. A bare number means days. The value is only used for the licence warning and is not stored.

### A workspace that is always offline

For an air-gapped install, use the setting instead of a session:

```bash
mso settings set offline.mode on
```

| `offline.mode` | Meaning |
|---|---|
| `off` (default) | Online, as normal. Use `mso offline on` / `off` for temporary offline periods. |
| `on` | This workspace is always offline. `mso offline off` refuses until you run `mso settings set offline.mode off`. |

The setting is refused in `artefacts.mode: shared`, for the same reason as `mso offline on`. A workspace that is offline only through the setting has no session baseline. Run `mso offline on` once to record one. Entries recorded under the setting are never covered by push-on-reconnect consent.

### Leaving offline mode

```bash
mso offline off
```

This closes the session and the dispatcher starts using the network again. **It does not publish anything.** The outbox keeps its entries until you replay them. See [Coming back online](#coming-back-online).

Turning offline mode on or off requires the `fleet.dispatch` capability in a governed workspace, and both actions are written to the audit log.

---

## What works offline

| Capability | Offline behaviour |
|---|---|
| Dispatch of orders on a **local** model backend | Works. The backend is probed before each launch. If it is down, the order is held (`local backend … unavailable`). |
| New voyage branch | Created **locally**, with the same name it will have on the remote (`voyage/VOY-…`), from your local `origin/<default branch>`. If the voyage already started online, the local branch is taken from `origin/voyage/VOY-…`. |
| Crew worktrees, crew commits, salvage branches | Work as normal. All of these are local. |
| Convergence | Each crew is merged into the **local** voyage branch with a merge commit. Maestro does not fetch, does not reset to origin, and does not push. |
| The verify gate (`verifyCommand`) | Runs as normal. |
| Draft voyage PR, PR body refresh | **Deferred** to the outbox. |
| Artefact plane (solo mode) | Lifecycle commits happen locally, and the push is deferred to the outbox. Maestro does not report a diverged plane for a deliberate offline period. |
| Order and voyage creation (solo or embedded) | Works, using local ID allocation. |
| `mso status`, `mso doctor`, `mso offline status`, `mso outbox list` / `show` | Work, and need no network. |
| Licence (`MSO1.` token) | Verified offline, so it works until it expires. |

Crews launched while offline mode is on cannot use `WebFetch` or `WebSearch`, so they fail fast instead of hanging on a tool that cannot work. They also run with Claude Code's non-essential traffic switched off.

---

## What is held or refused

**Held** means the order stays queued. It is not launched and spends none of its retry budget, and it runs once you are back online. **Refused** means the command exits with status `2` and a message naming offline mode and the command to run later.

| Capability | Offline behaviour |
|---|---|
| Orders on a hosted model (Anthropic, Bedrock) | **Held** before launch: `HELD offline (hosted model <model>)`. |
| REL orders | **Held**: `HELD offline (requires the SCM remote)`. REL's work is PR and CI work against the remote. |
| An order whose model cannot be resolved | **Held** (`model could not be resolved`). |
| PR draft→ready | **Deferred**, and never run by replay, because marking a PR ready starts CI. See [Coming back online](#coming-back-online). |
| `mso pr status / checks / ci-log / threads / reply / resolve`, `mso pr merge` | **Refused.** |
| Voyage reconcile (archive on merge) | **Degraded**: archives nothing while offline. A branch you have not pushed must never be read as "merged". |
| `mso licence revalidate` | **Refused** while any workspace on this machine is offline. `mso licence status` still works. |
| `mso runtime update`, the Hub's update check | **Refused** / switched off. |
| Slack bridge | **Suppressed**, with a one-line notice. Host notifications and the status banner still work. |
| Remote packs, governance bundle pulls, enrolment, Vault and 1Password secrets | **Refused, and they fail closed.** A policy or secret that cannot be fetched is never treated as "there is none". |
| `mso doctor` checks that need the network | **Skipped**, with the reason `offline-mode`. |

---

## Watching an offline fleet

```bash
mso offline status            # session, held orders, outbox, plane, remote reachability
mso offline status --json
mso status                    # the DISPATCHER line shows the offline segment
mso doctor                    # offline checks (below)
```

**`mso offline status`** shows the session (id, start time, operator, reason, push-on-reconnect), the baseline per repo, held orders grouped by reason, the outbox by kind and branch, any blocked branches with the command that resolves them, and how many commits the artefact plane is ahead of its remote. Once offline mode is off and the outbox still has entries, it also says whether the remote is reachable.

**`mso status`** shows one of these on the DISPATCHER line:

| Situation | Segment |
|---|---|
| Offline mode on | `OFFLINE MODE (since 14:02, 3h) — outbox 7` |
| Back online, outbox not yet published | `OUTBOX 7 PENDING — remote reachable — mso outbox replay` |
| A branch replay could not publish | `OUTBOX BLOCKED 1 (diverged: voyage/VOY-…)` |

While offline mode is on, its segment replaces the older `OFFLINE — dispatch held` segment, which belongs to the automatic outage gate. The two are never shown together. Held orders show `HELD offline (…)` on their own row.

**`mso doctor`** adds these checks:

| Check | Severity | Fires when |
|---|---|---|
| `offline.mode-active` | low | Offline mode is on. |
| `offline.licence-horizon` | high | Offline, and a v1 licence's offline grace ends within 3 days. |
| `offline.outbox-replayable` | high | Offline mode is off, the outbox has entries, and the remote answers. |
| `offline.outbox-blocked` | critical | A branch needs your decision (see [When replay stops on a branch](#when-replay-stops-on-a-branch)), or an outbox file has been edited outside Maestro. |
| `artefacts.unpushed` | medium | The artefact plane has commits that have not been pushed for 30 minutes or more. |

**The Hub** shows the same offline segment on the workspace, an **Outbox** panel listing the live entries, and a **Replay** button. Replay from the Hub is a dry run until you confirm it, and it has the same tier and capability gates as other fleet controls.

---

## The outbox

The outbox records what Maestro *would have done* on the remote. It does not store commands. There is one file per repo, plus one for the artefact plane. These files are device-local and never committed.

| Kind | Recorded when | Replay does |
|---|---|---|
| `create_remote_branch` | A voyage branch was created locally | Creates the branch on the remote |
| `push_ref` | A convergence moved the local voyage branch (one entry per branch, however many convergences) | Pushes the branch's **current** local tip as a fast-forward |
| `open_pr` | The dispatcher would have opened the voyage PR | Opens it as a **draft**, with the title and body rendered fresh |
| `refresh_pr_body` | The dispatcher would have refreshed the PR body | Refreshes it, rendered fresh |
| `promote_pr_ready` | The dispatcher would have marked the PR ready | **Nothing.** It is listed, and left to you or to the LEAD's `pr.promote-draft` action |
| `artefact_plane_push` | The artefact plane has unpushed commits (one entry) | Pushes the plane |

The outbox holds no credentials, tokens, URLs with passwords, or commit messages. Replay uses whatever `git` and `gh` credentials you have at the time you run it. Branch names are checked: only voyage branches are accepted, never your default branch.

Each file is **tamper-evident**. If one is edited, truncated or reordered outside Maestro, `mso outbox list` reports `CHAIN BROKEN` and automatic replay refuses that repo.

```bash
mso outbox list               # live entries per repo, with chain status
mso outbox list --all         # include done, superseded and abandoned entries
mso outbox show 3f9a          # one entry and its status history (id or 4+ char prefix)
```

---

## Coming back online

```bash
mso offline off               # stop deferring
mso outbox replay             # DRY RUN: lists every action, publishes nothing
mso outbox replay --yes       # publish
```

**Dry run is the default.** Without `--yes`, replay asks the remote read-only questions and lists every action, marked `PUSH`, `OPEN PR`, `REFRESH`, `DONE`, `WAIT`, `BLOCKED` or `NOT RUN`. It pushes nothing and writes nothing.

**With `--yes`**, for each repo, replay:

1. Checks that the outbox file is intact and that the repo's remote is still the one recorded.
2. Publishes, in this order: create branch → push branch → open draft PR → refresh PR body → push artefact plane.
3. Re-checks every entry against git before acting. A branch that is already on the remote at the right commit is marked done without a push. Running replay twice is safe, and the second run changes nothing on the remote.
4. Pushes only **fast-forwards**. It never force-pushes, never pushes your default branch, and never marks a PR ready.

With `--yes`, `mso outbox replay` exits `1` if anything was left blocked, failed or waiting, so a script cannot mistake "nothing was published" for success. A `promote_pr_ready` entry that was listed but not run does not count as a failure.

Every executed replay, resolve and rebind is written to the audit log.

**Marking the PR ready** starts CI, so replay never does it. Mark the PR ready in your SCM yourself when you are ready, or let the resident LEAD's `pr.promote-draft` action do it, within whatever band you have given that action.

**Your default branch moved while you were away.** This is the common case, and it is not a problem. Your voyage branch still fast-forwards onto its own remote, and the PR shows as behind or conflicting in your SCM, just as it would online. Replay does not merge the default branch into voyage branches for you.

**Turning offline mode off is not the same as publishing.** After `mso offline off`, any branch that still has outbox entries stays under the outbox's control. The dispatcher does not create it on the remote from the *current* default branch, which would leave your local branch diverged from its own remote. The branch is published only by replay.

### Letting the resident LEAD replay for you (Pro+)

If you entered offline mode with `--push-on-reconnect` and the resident LEAD is running, the LEAD notices when the remote is reachable again and replays **that session's entries** by itself, within the same safety rules. It writes one `LEAD_ACTION` line per entry. Everything else waits for you:

- entries from a session without that consent, or recorded under the `offline.mode: on` setting;
- any branch that diverged, was deleted on the remote, or whose PR closed;
- a repo whose remote changed, or whose outbox file is broken.

Without consent, the LEAD only proposes the replay, and you run `mso outbox replay`. The LEAD never replays while offline mode is on. If your LEAD `must_not` list includes "push", the LEAD never replays unattended, whatever consent was given.

---

## When replay stops on a branch

Replay works through one branch at a time. When something is wrong with a branch, replay stops that branch, keeps going with the others, and tells you what to do.

| What you see | What happened | What to do |
|---|---|---|
| `OUTBOX_DIVERGED` | Someone pushed to the voyage branch on the remote while you were offline. Your branch and theirs both have new commits. | [Resolve the divergence](#resolving-divergence). |
| `OUTBOX_REMOTE_REF_DELETED` | The voyage branch existed on the remote when you went offline and has since been deleted. Someone did that on purpose. | Find out why. Then use `mso outbox resolve <branch> --push-aside` or `--abandon`. |
| `OUTBOX_PR_CLOSED` | The voyage PR was merged or closed while you were offline. Maestro never pushes onto a branch whose PR has merged. | Your decision: start a new voyage for the remaining work, or use `--push-aside` / `--abandon`. |
| `OUTBOX_REMOTE_CHANGED` | The repo's `origin` URL or slug is not the one the entries were recorded against (re-pointed, renamed or transferred). The whole repo is blocked. | Check the new remote. If it is right: `mso outbox rebind <repo> --to-current`. |
| `OUTBOX_REF_BUSY` | A crew is running on that voyage. Pushing would move the branch under it. | Wait for the crew to finish, then replay again. |
| `OUTBOX_LOCAL_REF_MISSING` | The local voyage branch was deleted or reset, so it no longer contains the work that was recorded. | Look for a `salvage/` branch, restore the local branch, then replay again. |
| `OUTBOX_CHAIN_BROKEN` | The repo's outbox file was changed outside Maestro. | Read `mso outbox list` and check what it will do. Then `mso outbox replay --accept-broken-chain --yes`. Only you can do this. The LEAD never will. |
| `failed` (e.g. authentication) | The push or PR call failed for a reason that may be temporary: expired credentials, branch protection. | Fix the cause (for example `gh auth login`), then replay again. Failed entries are retried. |
| `WAIT` | The entry depends on something that has not happened yet, such as a push for the same branch that is blocked. | Clear the blocker, then replay again. |

---

## Resolving divergence

When a voyage branch has diverged, you choose what happens. Maestro never rebases and never force-pushes.

```bash
mso outbox resolve voyage/VOY-ACME-2026-0042 --merge          # default
mso outbox resolve voyage/VOY-ACME-2026-0042 --merge --verify # also run verifyCommand on the merge
mso outbox resolve voyage/VOY-ACME-2026-0042 --push-aside
mso outbox resolve voyage/VOY-ACME-2026-0042 --abandon
```

| Option | What it does | Use it when |
|---|---|---|
| `--merge` (default) | Merges the remote branch into your local branch with a **merge commit**, in a temporary worktree. On a clean merge, the branch is unblocked and the next `mso outbox replay --yes` pushes the merge. On a **conflict**, your local branch is left exactly as it was, the conflicting files are listed, and the branch stays blocked. Resolve the conflict by hand, then run `--merge` again. | Both sets of work belong on the voyage. |
| `--push-aside` | Pushes your local tip to a **new** remote branch, `offline/<VOY>-<sha8>`, and stops replaying the original branch. Nothing on the remote is overwritten. | You want a human to reconcile the two lines of work in your SCM. |
| `--abandon` | Keeps your local branch, pins it as `salvage/<branch>-offline-<sha8>` so nothing is lost, and marks the branch's outbox entries abandoned. | The remote's version wins, and you will deal with your offline work separately. |

Your offline commits are never rebased. Crew commits are referenced by salvage branches, order history and handoffs, and rebasing would change their ids.

`mso outbox resolve` exits `1` when it did not resolve the branch, for example on a merge conflict.

---

## Licence advice for offline use

| Licence | Offline |
|---|---|
| **`MSO1.` token** (v2) | Verified on your machine, with no network call. It works until its expiry date, plus the paid-tier grace. **This is the licence to hold if you work offline regularly.** |
| **Legacy key** (v1) | It needs an online check every 24 hours. Offline, it runs on a **14-day grace**, and the fleet stops when the grace runs out. `mso licence revalidate` is refused while offline. |

If you are on a v1 licence:

- run `mso licence revalidate` just before you go offline, so the grace starts at its full 14 days;
- pass `--for` to `mso offline on`, so Maestro warns you if the grace ends before you are back;
- watch for the `offline.licence-horizon` doctor finding, which fires 3 days before the grace ends.

To move to an `MSO1.` token, see [LICENCE.md](LICENCE.md) or contact support.

---

## The data-egress guarantee

With **only local model backends** configured and offline mode on:

> No Maestro process (dispatcher, resident LEAD, Hub, CLI) opens a network connection to any host other than loopback and the hosts your local model backends name. Crews are launched with no tool that fetches from the web.

Maestro enforces this in two ways. Its own network calls are restricted to those hosts. Every `git` or `gh` command that would reach a remote is either deferred to the outbox or refused. `mso data-flow --mode offline` draws the allowed destinations. It is also the default view while the workspace is offline.

If a **hosted** model backend is configured, the guarantee is narrower: orders on a hosted backend are not dispatched, so no prompt or code leaves the machine through Maestro. Network traffic that the Claude CLI makes on its own behalf is outside what Maestro can promise.

---

## Known limitations

- **Shared artefact mode cannot go offline.** Switch the device to solo mode for the offline period. Merging an offline solo plane back into a shared one is not supported yet.
- **Order IDs on a multi-machine solo plane.** Offline, order IDs are allocated from this machine's local view only. If another machine allocates from the same plane while you are offline, the two can mint the same ID. This is the existing solo-mode contract.
- **Plane push ordering.** In a solo workspace, replay can currently push the artefact plane *before* it opens the voyage PR, so the plane may be published without the new PR's number. Nothing is lost: the next normal plane push brings it up to date.
- **No local backend, no work.** Until a local model backend is configured, offline mode holds every order. That is the honest answer: none of them can reach their model.
- **Offline is per device.** The session, the outbox and the held-order list belong to the machine you ran `mso offline on` on.
