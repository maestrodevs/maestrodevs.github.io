# Open-weights models on a local endpoint

> **Status: experimental.** This feature ships labelled *experimental*, and
> `mso providers show local_model` says so. How well a 30B-class open-weights
> model does agentic coding work inside Claude Code has not yet been measured
> against Claude on Maestro's own orders. The label comes off when that
> benchmark has run and passed. Until then, use it for the low-risk roles this
> page recommends, and read every PR it produces with that in mind.

Every crew Maestro launches is a Claude Code session. Normally that session
talks to Claude, either directly or through AWS Bedrock (see
[MODEL-BACKENDS.md](MODEL-BACKENDS.md)). This page covers the other option:
pointing some roles, orders or voyages at an **open-weights model** that you
serve yourself, on your own machine or private network, through an
Anthropic-Messages-compatible endpoint.

The reference model is **Muse Glimmer 30B** (`muse-glimmer-30b`) served by
**Ollama**. llama.cpp, vLLM, SGLang and LM Studio work the same way.

---

## Contents

1. [What an open-weights route is](#what-an-open-weights-route-is)
2. [Which roles may use one](#which-roles-may-use-one)
3. [Licence tier](#licence-tier)
4. [Check your hardware](#check-your-hardware)
5. [Choose a runtime](#choose-a-runtime)
6. [Install the runtime and get the weights](#install-the-runtime-and-get-the-weights)
7. [Start the server and smoke-test it](#start-the-server-and-smoke-test-it)
8. [Tell Maestro about the endpoint](#tell-maestro-about-the-endpoint)
9. [Choosing a model per order, voyage and role](#choosing-a-model-per-order-voyage-and-role)
10. [Long-running orders](#long-running-orders)
11. [What a crew on an open-weights route does differently](#what-a-crew-on-an-open-weights-route-does-differently)
12. [When a local run fails](#when-a-local-run-fails)
13. [Cost and usage](#cost-and-usage)
14. [Offline scope](#offline-scope)
15. [Remote routers: every prompt leaves the machine](#remote-routers-every-prompt-leaves-the-machine)
16. [Health checks](#health-checks)
17. [Troubleshooting](#troubleshooting)
18. [Licences](#licences)
19. [Appendix A: alternate runtimes](#appendix-a-alternate-runtimes)
20. [Appendix B: Llama-family models](#appendix-b-llama-family-models)

---

## What an open-weights route is

```
crew (Claude Code) ──Anthropic Messages API──▶ your runtime (e.g. Ollama) ──▶ model weights on your disk
```

A workspace can have **one Claude backend plus one open-weights endpoint** at
the same time. Nothing about the Claude side changes when you add the endpoint.

**The model id decides which one a crew uses.** There is no separate "backend"
field to set:

- a `claude-…` id runs on your Claude backend, exactly as before;
- an id from the open-weights catalogue (for example `muse-glimmer-30b`) runs
  on your open-weights endpoint.

So a mixed voyage is just a set of model choices. PLN and SEC can stay on
Claude while BLD and DOC run on Muse Glimmer, and each crew launch picks its
own route from the model it resolves to.

### The catalogue

Maestro ships one open-weights entry:

| Id | Label | Context | Licence | Runtime name (Ollama) |
|----|-------|---------|---------|-----------------------|
| `muse-glimmer-30b` | Muse Glimmer 30B | 131,072 tokens | Apache-2.0 | `muse-glimmer:30b` |

You can override its fields or add other models under
`providers.local_model.config.models` (see
[Declaring other models](#declaring-other-models)).

Three rules hold for every open-weights id:

- **The id is the same everywhere.** You write `muse-glimmer-30b` in an order,
  a voyage, `role-models.json`, an env var or a role overlay, and that is what
  usage records, `mso status` and the Hub show. The runtime's own name (such
  as `muse-glimmer:30b`) lives only in the endpoint config.
- **Ids starting `claude-` are reserved** and are refused as open-weights ids.
- **An open-weights id is refused until an endpoint is configured.** Every
  place you can pin a model gives the same answer:

  ```
  muse-glimmer-30b is an open-weights model; configure an endpoint first:
  mso providers set local_model endpoint --config baseUrl=...
  ```

No shipped role default is ever an open-weights model. You opt in, explicitly,
every time.

---

## Which roles may use one

Maestro enforces this policy itself. It is not advice.

| Role | Open-weights allowed? | Why |
|------|-----------------------|-----|
| DOC | Yes | Low blast radius; the PR is reviewed by a human |
| BLD | Yes | The verify gate and the TST role check the work independently |
| TST | Yes, **with a warning** if BLD on the same order is also open-weights | A weak tester can pass weak code. The warning is logged once and `mso doctor` reports the pairing |
| INV | Yes | Read-mostly |
| PLN | **Refused** unless listed in `allowRoles` | Planning errors compound, and the human review gate trusts the plan |
| SEC | **Refused** unless listed in `allowRoles` | Nothing catches what a security review *misses* |
| REL | **Refused** unless listed in `allowRoles` | Its READY verdict is what you read before merging |
| LEAD | **Always refused** | Interactive and human-facing; `allowRoles` cannot list it |

A refused pin is refused **everywhere it can be written**: `mso settings set`,
`mso voyage create --role-model`, and at crew launch (for configuration you
copied in by hand). The refusal names the key to change:
`providers.local_model.config.allowRoles`.

To opt a refused role in anyway:

```bash
mso providers set local_model endpoint \
  --config baseUrl=http://127.0.0.1:11434 \
  --config allowRoles=SEC
```

**Every gate still applies, whatever the model.** The verify gate, QA
rejection laps, the SEC-artefact check, the budget gate and the human review
gates all judge the work and the crew's exit state, never the model that
produced them. Per-role tool restrictions and Maestro's hooks are enforced by
Claude Code itself, so they apply to an open-weights crew exactly as they do
to a Claude crew.

---

## Licence tier

The open-weights endpoint needs a **Pro, Team or Enterprise** licence. At
Community tier, `mso setup` does not offer it, and a configured endpoint reports
itself unavailable with the tier as the reason. The direct Anthropic API stays
available at every tier.

---

## Check your hardware

Muse Glimmer is a ~30B dense model. **It needs a GPU or Apple-silicon unified
memory.** CPU-only inference is far too slow for agentic coding.

| Quantisation | File size | Memory you need | Notes |
|---|---|---|---|
| 4-bit (Meta's `K-Quant-17GB`, ≈ Q4_K_M) | 16.8 GB | **24 GB** VRAM or unified memory | Recommended starting point |
| 4-bit dynamic (Meta's `K-Quant-Dynamic`) | 19.7 GB | 32 GB | Slightly higher quality |
| 8-bit | ~34 GB | ~40 GB+ | Workstation or 64 GB Mac |
| BF16 (full precision) | ~58 GB | ~64 GB+ | Servers |

Meta's quantisation page puts the 4-bit text model plus the vision projector
plus the KV cache **at the full 131,072-token context** at **19.0 GiB**, which
"fits a 24 GiB card with headroom". The model's attention design keeps the KV
cache small, but leave headroom anyway: Claude Code sends a large system prompt
and tool list on every turn. Measure on your own runtime (`ollama ps`) rather
than trusting the table.

Published decode speeds, from the model card (with Meta's DFlash speculative
decoding unless noted):

| Hardware | Decode speed |
|---|---|
| NVIDIA RTX 5090 | 74.9 tok/s plain, 233 tok/s with DFlash |
| Apple M4 Max | 37.8 tok/s |
| Apple M5 Max | 50.2 tok/s |
| Laptop CPU only | ~1.6 tok/s (third-party report) |

**What was checked, and when.** The model facts on this page (size,
modalities, context, licence, tool use, quantised file sizes and the 19.0 GiB
figure) were re-checked on **2026-10-20** against
<https://dev.meta.ai/docs/muse-glimmer>,
<https://dev.meta.ai/docs/muse-glimmer/quantization> and the Hugging Face model
card <https://huggingface.co/meta-models/Muse-Glimmer-30B>. On that date:

- dev.meta.ai describes Muse Glimmer as a 30-billion-parameter, dense,
  decoder-only multimodal transformer with a built-in vision encoder. It takes
  text and image input, produces text, has a default 128K context window, and
  its weights are released under Apache-2.0.
- The Hugging Face card gives ~29.6B parameters in total, including a ~1.8B
  vision encoder, 131,072+ tokens of context, and states that the model
  supports tool use and function calling. It dates the release to August 2026.
- The dev.meta.ai overview page itself does not state tool-calling support;
  the Hugging Face card does.

The 8-bit and BF16 rows and the decode speeds come from the model card and the
GGUF card (`meta-models/Muse-Glimmer-30B-GGUF`) as recorded on 2026-10-14 and
were not re-checked. Vendor numbers change; check them before you buy hardware.

---

## Choose a runtime

| OS | Primary | Why | Alternates |
|---|---|---|---|
| **Windows** (NVIDIA) | **Ollama** | Native installer, official `muse-glimmer` tag, documented Claude Code setup | LM Studio (GUI); llama.cpp `llama-server` (most control) |
| **macOS** (Apple silicon) | **Ollama** (`muse-glimmer:30b-mlx`) | MLX-optimised tag, same commands as the other OSes | LM Studio (MLX); llama.cpp (Metal) |
| **Linux** (NVIDIA) | **Ollama** for one user; **vLLM** for several concurrent crews | vLLM batches parallel requests far better | SGLang; llama.cpp |

Ollama is the primary path here because it is the same install and the same
commands on all three operating systems, and its Claude Code integration is
documented by the vendor: <https://docs.ollama.com/integrations/claude-code>.
The alternates are in [Appendix A](#appendix-a-alternate-runtimes).

All of these serve the **Anthropic Messages API** (`/v1/messages`) natively,
so you need no translation proxy. If you run a proxy anyway (for example LiteLLM
in front of a server that only speaks the OpenAI API), Maestro treats it as one
more endpoint URL.

**Maestro never installs, downloads, starts or stops a model or a model
server.** You own the runtime. Maestro checks that it is reachable and tells you
the exact command to run when it is not.

---

## Install the runtime and get the weights

Do this once, while you are online.

### Install Ollama

- Windows / macOS: install from <https://ollama.com/download>.
- Linux: use your distribution's package or the official install script from
  the same page. Read the script before you run it.

```
ollama --version     # your version must support Muse Glimmer and the Anthropic-compatible API
```

### Option A: the Ollama library (simplest)

```
ollama pull muse-glimmer:30b          # Apple silicon: muse-glimmer:30b-mlx
ollama list                           # note the ID (digest) shown for the tag
ollama show muse-glimmer:30b          # confirm: context 128K; capabilities include "tools"
```

**Pin what you pulled.** An Ollama tag can be re-pointed upstream. Write down the
digest that `ollama list` shows: that digest is your pinned version. On an
offline machine, compare it again before you trust a copied model store.

### Option B: a pinned, checksum-verified Hugging Face file (for air-gapped transfer)

1. Pick the **commit SHA** of the revision you want from the "Files and
   versions" history on <https://huggingface.co/meta-models/Muse-Glimmer-30B-GGUF>.
   Never use the floating `main` branch.
2. Download that exact revision:

   ```
   pip install -U huggingface_hub
   hf download meta-models/Muse-Glimmer-30B-GGUF <file>.gguf --revision <commit-sha> --local-dir ./muse-glimmer
   ```

3. Check the file against the SHA-256 shown on its Hugging Face file page:

   ```
   # Linux/macOS
   sha256sum ./muse-glimmer/<file>.gguf
   # Windows PowerShell
   Get-FileHash .\muse-glimmer\<file>.gguf -Algorithm SHA256
   ```

   **If the hashes differ, stop.**
4. Import the file into Ollama with a one-line `Modelfile`:

   ```
   FROM ./muse-glimmer/<file>.gguf
   ```

   ```
   ollama create muse-glimmer-local -f Modelfile
   ollama show muse-glimmer-local       # "tools" must be listed under capabilities
   ```

   If **tools** is not listed, the chat template did not carry over and tool
   calls will fail. Use Option A instead. (An imported model has a different
   runtime name, so declare it as shown in
   [Declaring other models](#declaring-other-models).)

### Supply-chain rules

- Only use weights from the publisher you intend to trust. A community
  re-quantisation is a different publisher.
- Pin a revision (Option B) or record a digest (Option A). Never trust a
  floating tag or branch for a machine that will run unattended.
- Prefer GGUF or safetensors files.
- Never enable "trust remote code" options in any loader.

---

## Start the server and smoke-test it

### Start with enough context

Ollama's default context is small, and it **silently drops** what does not fit.
Set it explicitly before you start the server. Ollama's Claude Code guide asks
for 64K or more.

```
# Linux/macOS
OLLAMA_CONTEXT_LENGTH=65536 ollama serve
# Windows PowerShell
$env:OLLAMA_CONTEXT_LENGTH = "65536"; ollama serve
```

The server listens on `http://127.0.0.1:11434`. **Keep it bound to localhost.**
Do not expose it on a LAN interface without authentication in front of it.

```
ollama ps          # the loaded model, and how much of it is on GPU vs CPU
```

**If any of the model is on CPU, reduce the context or use a smaller
quantisation.**

If you serve less than the catalogue's 131,072 tokens (as in the example
above), tell Maestro by overriding `contextTokens` (see
[Declaring other models](#declaring-other-models)). Claude Code otherwise
believes it has more room than the server gives it, and the server truncates.
`mso doctor` flags the mismatch when the runtime reports its served context.

### Smoke-test the endpoint with curl

Ollama's Anthropic-compatible API is documented at
<https://docs.ollama.com/api/anthropic-compatibility>.

**Plain message**

```
curl -s http://127.0.0.1:11434/v1/messages \
  -H "content-type: application/json" -H "x-api-key: ollama" -H "anthropic-version: 2023-06-01" \
  -d '{"model":"muse-glimmer:30b","max_tokens":64,
       "messages":[{"role":"user","content":"Reply with exactly: hello"}]}'
```

Expect a JSON `message` with a `content[0].text` and a `usage` block.

**Tool-call round trip.** Turn 1: the model should answer with a `tool_use`
block.

```
curl -s http://127.0.0.1:11434/v1/messages \
  -H "content-type: application/json" -H "x-api-key: ollama" -H "anthropic-version: 2023-06-01" \
  -d '{"model":"muse-glimmer:30b","max_tokens":256,
       "tools":[{"name":"get_time","description":"Get the current time in a city",
                 "input_schema":{"type":"object","properties":{"city":{"type":"string"}},"required":["city"]}}],
       "messages":[{"role":"user","content":"What time is it in Paris? Use the tool."}]}'
```

Expect `"stop_reason":"tool_use"` and a content item
`{"type":"tool_use","id":"…","name":"get_time","input":{"city":"Paris"}}`.

Turn 2: send the result back, reusing the `id` from turn 1:

```
  ... "messages":[
       {"role":"user","content":"What time is it in Paris? Use the tool."},
       {"role":"assistant","content":[{"type":"tool_use","id":"<id>","name":"get_time","input":{"city":"Paris"}}]},
       {"role":"user","content":[{"type":"tool_result","tool_use_id":"<id>","content":"14:05"}]}]
```

Expect a text answer that mentions 14:05. **If turn 1 returns the tool call as
plain text instead of a `tool_use` block, the tool template is not working. Do
not go further until it is.**

> **Do not** point a Maestro fleet at the endpoint by exporting
> `ANTHROPIC_BASE_URL` in the shell that runs `mso dispatch`. Maestro would then
> record the runs as a Claude model with an invented cost, send your real
> Anthropic credentials to the endpoint, and test the wrong service for
> health. Configure the endpoint as below instead: Maestro sets the crew's
> environment itself, only for crews on an open-weights route.

---

## Tell Maestro about the endpoint

### The guided way: `mso setup`

At Pro, Team or Enterprise tier, the model-backend step (`[STEP 2b]`) ends
with:

```
Also use an open-weights model on a local endpoint? [y/N]
```

Answering **y** asks for:

- the **base URL** (default `http://127.0.0.1:11434`);
- an optional **token reference**, such as `env:MAESTRO_LOCAL_MODEL_TOKEN`. A
  literal token is refused.

The wizard then checks the endpoint once and prints the models it serves, with
each one's context window when the runtime reports it. It also says which
catalogue models are loaded, and how to declare one that is not in the
catalogue.

| What the wizard finds | What happens |
|---|---|
| You answer **N** (the default) | Nothing is written |
| The URL or token fails validation | The reason is printed; nothing is written |
| Nothing answers at the URL | It prints "start your model server first (e.g. `ollama serve`)"; nothing is written |
| The endpoint answers but cannot list its models (a 401, a redirect, an unexpected body) | It asks "Write the configuration anyway? [Y/n]" |
| The endpoint lists its models | The configuration is written |
| The answers match what is already configured | Nothing is written |

Re-running `mso setup` keeps any `models`, `allowRoles`, `maxConcurrentCrews`
or other keys you already set; the wizard only writes the URL and token.

For a scripted setup, the non-interactive answer keys are
`providers.local_model.baseUrl` and `providers.local_model.authToken`.

### The direct way: `mso providers set`

```bash
mso providers set local_model endpoint --config baseUrl=http://127.0.0.1:11434
mso providers show local_model     # read it back, with availability
mso providers test local_model     # check it right now
mso providers unset local_model    # remove the endpoint
```

`mso providers set` **replaces the whole block** each time, so pass every key
you want to keep in one command.

`mso providers show local_model` prints the status (`experimental`), the
endpoint as `host:port` only, the token **reference name** (never its value),
and the models it serves. With no token configured it shows that a fixed,
non-secret placeholder (`maestro-local`) is sent, because Claude Code requires
some token.

### Configuration reference

Every key lives under `providers.local_model.config` in
`.mso/config/workspace.json`. Only `baseUrl` is required. An unknown key is
refused.

| Key | Default | Meaning |
|-----|---------|---------|
| `baseUrl` | *(required)* | The endpoint, `http://` or `https://`. Must be a loopback, private (RFC 1918, IPv6 ULA), link-local or `*.local` host, unless `allowRemoteEndpoint` is set. No `user:password@`, query or fragment. |
| `authToken` | *(unset)* | An `env:NAME` or `secret://…` **reference**. A literal value is refused. Unset sends the non-secret placeholder `maestro-local`. |
| `allowRemoteEndpoint` | `false` | Allow a non-private host. Also requires `https` and your workspace's egress allowlist. See [Remote routers](#remote-routers-every-prompt-leaves-the-machine). |
| `maxConcurrentCrews` | `1` | How many crews may use this endpoint at once (≥ 1). |
| `stallMinutes` | `20` | The activity-watchdog threshold for crews on this endpoint (≥ 0). See [Long-running orders](#long-running-orders). |
| `allowRoles` | *(empty)* | PLN, SEC or REL to opt in (a list, or a comma-separated string). LEAD cannot be listed. |
| `allowWebTools` | `false` | Let open-weights crews use WebFetch and WebSearch (denied by default). |
| `models` | *(the built-in catalogue)* | Per-model overrides and additions. See below. |
| `pricingOverrides` | *(unset)* | Your own rates, if you want a cost figure. See [Cost and usage](#cost-and-usage). |

Hostnames such as `localhost` and `*.local` are trusted **by name**; Maestro does
no DNS lookup. `0.0.0.0` and unusual IP spellings are treated as remote and
refused.

### Declaring other models

Override a built-in entry, or add a model the catalogue does not carry:

```bash
mso providers set local_model endpoint \
  --config baseUrl=http://127.0.0.1:11434 \
  --config models.muse-glimmer-30b.contextTokens=65536 \
  --config models.qwen3-coder-30b.native=qwen3-coder:30b \
  --config models.qwen3-coder-30b.contextTokens=65536
```

The same thing as JSON:

```jsonc
"providers": {
  "local_model": { "id": "endpoint", "config": {
    "baseUrl": "http://127.0.0.1:11434",
    "models": {
      "muse-glimmer-30b": { "contextTokens": 65536 },
      "qwen3-coder-30b":  { "native": "qwen3-coder:30b", "contextTokens": 65536 }
    }
  } }
}
```

| Field | Required? | Meaning |
|-------|-----------|---------|
| *(the id)* | | Lowercase letters, digits, `.` and `-`, 2–63 characters; must not start with `claude-` |
| `native` | No (the id itself) | The name your runtime serves the model under |
| `contextTokens` | **Yes** for a new id | The context window to tell Claude Code, 16,384 to 10,000,000. Keep it equal to what the server really serves |
| `maxOutputTokens` | No (8,192, or the context if smaller) | Output cap per response |
| `thinkingSupported` | No (`false`) | Leave `false` unless your runtime accepts the extended-thinking parameter |
| `effortSupported` | No (`false`) | Whether the runtime accepts an effort setting |
| `label` | No | Display name |

The `[1m]` context selector does not apply to open-weights ids and is refused.
The context window is `contextTokens`.

---

## Choosing a model per order, voyage and role

Selection is always explicit. Nothing moves an order to an open-weights model
unless you wrote the choice down.

The full resolution chain (the first layer that sets a model wins) is:

```
fallback > per-order > voyage > workspace > env > role overlay > built-in default
```

See [CONFIG-MODELS.md](CONFIG-MODELS.md#how-a-roles-model-is-resolved) for the
layers that also apply to Claude models.

**Per order.** Set `model` in the order JSON:

```json
{ "orderId": "FTR-PSG-2026-0042", "role": "BLD", "model": "muse-glimmer-30b" }
```

**Per voyage.** Pin roles for every order in a voyage when you create it:

```bash
mso voyage create "Docs refresh" --project PSG \
  --role-model BLD=muse-glimmer-30b \
  --role-model DOC=muse-glimmer-30b
```

This writes `roleModels` into the voyage. It is read each time a crew launches
(it is not copied into the orders), so editing the voyage's `roleModels` later
changes every order that has not set its own `model`. The pins are validated at
create time: an unknown role or model, an open-weights model with no endpoint,
or a role the policy refuses is rejected, and no voyage is created.

**Per role.** Pin it for the whole workspace:

```bash
mso settings set models.DOC.model muse-glimmer-30b
```

`mso config models` shows the outcome for every role:

```
  Role   Model                            Context    Effort   Backend                Endpoint               Source
  DOC    muse-glimmer-30b                 standard   high     local_model/endpoint   127.0.0.1:11434        .mso/config/role-models.json
```

A role the policy refuses is flagged `(OPEN-WEIGHTS ROLE REFUSED!)`, and an
open-weights pin with no endpoint `(OPEN-WEIGHTS MODEL, NO ENDPOINT!)`; either
makes the command exit 1. The token is never shown.

The Hub settings page lists open-weights models in their own
**Open-weights (local)** group, only when an endpoint is configured. A crew card
on an open-weights route shows a `local · muse-glimmer-30b` badge.

---

## Long-running orders

Open-weights models are slower than Claude per token, and a long prompt can take
a while to process before the first output appears. Three settings matter:

- **`timeoutMinutes` on the order.** The wall-clock ceiling for one crew
  iteration. To route one long order locally, set both `model` and
  `timeoutMinutes` on it:

  ```json
  { "orderId": "FTR-PSG-2026-0043", "model": "muse-glimmer-30b", "timeoutMinutes": 180 }
  ```

- **`stallMinutes` on the endpoint (default 20).** The activity watchdog kills a
  crew that has produced no output for this long. For crews on the endpoint,
  Maestro uses the larger of this and the workspace's
  `completion.supervision.stallMinutes`. It never shortens the workspace value,
  and a workspace value of `0` (watchdog off) stays off.
- **`maxConcurrentCrews` on the endpoint (default 1).** One GPU serving several
  crews at once can slow them all past their timeouts. Orders above the cap wait
  for a free slot while Claude orders keep dispatching. Raise it only when your
  runtime batches parallel requests well (vLLM does).

There is no rule that sends "every long order" to a local model automatically.
That choice stays with you, order by order.

---

## What a crew on an open-weights route does differently

- **Your Anthropic and cloud credentials are removed** from that crew's
  environment before it starts, so your real API key is never sent to the
  endpoint. Maestro then points Claude Code at the endpoint and maps the
  model, including the background "small model" slot, to your runtime's name.
- **WebFetch and WebSearch are denied** unless `allowWebTools` is `true`. Web
  content is the main prompt-injection route, and WebFetch also needs to reach
  Anthropic's servers.
- **No effort setting is passed**, because the runtime does not support one.
- **Claude Code's non-essential traffic is turned off**, and so is extended
  thinking when the model does not support it.

What is **not** removed: other credentials in the dispatcher's environment,
such as `GH_TOKEN` or AWS keys, remain visible to the crew's own shell tool, as
they are on a Claude route. Claude Code's own `settings.json` (for example an
`env` block or an API-key helper) can also put a key back. Keep secrets you do
not want a crew to see out of the environment you start `mso dispatch` from.

---

## When a local run fails

Maestro recognises the ways an open-weights run typically goes wrong:

| What you see | What it means | What happens next |
|---|---|---|
| `BACKEND_UNREACHABLE` | The endpoint did not answer (server stopped, machine asleep) | The order goes back to PENDING **without spending a retry**, up to 5 times, then STALLs. Other orders routed to the endpoint are held until it answers again |
| `BACKEND_ERROR` | The endpoint rejected a request (an HTTP 400, a malformed tool call) | A normal, budgeted retry |
| `TOOL_LOOP` | The crew made the same tool call, with the same input, 8 times in a row | The crew is stopped, its work salvaged, and the order retried (budgeted) |
| `MAX_TURNS` / a watchdog stall | The model did not finish in the turns or time allowed | As on any route |

A dead endpoint is never mistaken for an internet outage, so it does not pause
your Claude orders. `MODEL_BACKEND_UNAVAILABLE backend=local_model/endpoint` in
`lifecycle.log` marks the hold, and `MODEL_BACKEND_RESTORED` marks its end.

The tool-loop limit applies to every route and is set by
`completion.supervision.toolLoopRepeats` (default 8; `0` turns it off).

### Optional fallback to Claude

By default a failed local order is **never** switched to Claude behind your back.
When it runs out of retries it STALLs, and the operator note names the fix: edit
the order's `model`, then `mso order retry <ID>`.

If you would rather fall back automatically, set it on the order or the voyage
JSON (there is no CLI flag):

```json
{ "model": "muse-glimmer-30b", "modelFallback": "claude-sonnet-5-5", "modelFallbackAfter": 1 }
```

- `modelFallback` must be a Claude model id.
- `modelFallbackAfter` (default 1) is how many failed local runs to allow first.
  The failures counted are `MAX_TURNS`, `TOOL_LOOP`, a watchdog stall and
  `BACKEND_ERROR`. `BACKEND_UNREACHABLE` and a plain wall-clock timeout do not
  count.
- The switch is logged as `MODEL_FALLBACK`, naming both models and the reason,
  and recorded in the order's `modelHistory`. The fallback run is ordinary Claude
  spend and counts against your budget.
- Local attempts and the fallback share the order's normal retry budget.
- `mso order retry` starts the order fresh on its own model again; the history
  is kept.

---

## Cost and usage

- A run on a loopback or private endpoint is recorded with cost basis
  **`local`** and a cost of **$0.00**. That is a stated fact, not a blank.
- If you want a figure (say, electricity), supply rates in USD per million
  tokens. All four keys are required per model; a partial entry leaves the
  model `unpriced` and the reason names the missing key:

  ```bash
  mso providers set local_model endpoint \
    --config baseUrl=http://127.0.0.1:11434 \
    --config pricingOverrides.muse-glimmer-30b.input=0.05 \
    --config pricingOverrides.muse-glimmer-30b.output=0.20 \
    --config pricingOverrides.muse-glimmer-30b.cache_creation=0.05 \
    --config pricingOverrides.muse-glimmer-30b.cache_read=0.01
  ```

  The record's basis is then `workspace-override`.
- A **remote** endpoint with no overrides is `unpriced`, because someone is
  billing you per token and Maestro does not know the rate.
- Records carry the canonical id (`muse-glimmer-30b`), never the runtime's name,
  and `backend: endpoint`. A record mixing Claude and open-weights usage reads
  `anthropic+endpoint`.
- The cost that Claude Code itself reports for a non-Claude model is not real,
  and Maestro ignores it.
- When records with different bases are added up, the weakest basis wins:
  `unpriced`, then `workspace-override`, then `local`, then `first-party-list`.

```bash
mso usage --by-backend            # tokens and cost per backend and model family
mso usage --by-backend --days 7
```

Cost cells read `$0.00 local`, `ovr` or `unpriced`. `--by-backend` cannot be
combined with `--by-effort`. It prices records against your **current**
configuration, so changing `pricingOverrides` changes past rows in this view.

---

## Offline scope

**Inference itself needs no network.** Once the weights are on disk, the
model's answers never leave the machine.

**Maestro still needs the internet for a fleet to run**, even when every order
is on a local model. Until Maestro's offline mode ships:

- the dispatcher creates each voyage's branch on your git host at first
  dispatch, and pushes to it;
- pull requests are opened on your git host;
- the licence is revalidated about every 24 hours (with up to 14 days of grace;
  see [AIR-GAPPED.md](AIR-GAPPED.md));
- the dispatcher's own internet check still decides whether new crews launch,
  so losing the internet pauses dispatch for local orders too;
- WebFetch and WebSearch need the internet (they are denied on local routes by
  default anyway).

What **is** in place: a stopped or unreachable model server is reported as its
own problem, holds only the orders routed to it, and is never treated as an
internet outage.

To prove the endpoint itself works with no network, outside Maestro:

1. With the server running, disconnect the network (Windows: flight mode;
   macOS: Wi-Fi off and Ethernet unplugged; Linux: `nmcli networking off`).
2. Check that you are really offline: `curl -sS --max-time 5 https://example.com`
   must fail.
3. Re-run the two curl smoke tests above. Both must succeed.
4. Reconnect.

---

## Remote routers: every prompt leaves the machine

You can point the endpoint at a hosted service (Fireworks AI, Together AI,
OpenRouter and similar) by setting `allowRemoteEndpoint: true`. It must use
`https`, and the host must be in your workspace's egress allowlist
(`dataResidency.allowedDestinations`; see
[PROVIDERS.md](PROVIDERS.md#egress-self-hosted-providers)).

**Be clear about what that means: every prompt, every file the crew reads and
all of your code are sent to that provider, under its terms.** It is not
local, it is not offline, and it is not private to your network. Remote runs
are recorded as `unpriced` unless you set `pricingOverrides`, and a remote
endpoint counts as needing the internet.

It is off by default for that reason.

---

## Health checks

`mso providers show local_model` and `mso doctor` report the endpoint's state
and the command to fix it. `mso doctor` adds three checks, all silent when no
endpoint is configured:

| Check | Severity | Reports |
|---|---|---|
| `model.local-endpoint` | high | The endpoint is unreachable or misconfigured; a pinned or declared model is not loaded (with the `ollama pull …` fix); the served context is smaller than `contextTokens` |
| `model.local-role-policy` | medium | PLN, SEC or REL pinned to an open-weights model without `allowRoles`; LEAD pinned to one; TST and BLD both on open weights |
| `model.local-concurrency` | low | `maxConcurrentCrews` is at or above your crew-slot count, so every crew could land on one endpoint |

Findings name the endpoint as `host:port` and the token by its reference name
only.

The Claude CLI preflight (the last step of `mso setup`, `mso setup --check
--smoke`, and `mso dispatch` when `preflight_check` is on) runs once per
configured backend. For the endpoint it also sends one request shaped like the
ones Claude Code sends, so a runtime that rejects them fails loudly up front
instead of on a crew's first turn.

---

## Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| `local model endpoint at … is not reachable` | The server is not running | Start it (e.g. `ollama serve`). Orders on the endpoint resume within about a minute |
| `… is not loaded` | The runtime does not serve that model name | `ollama pull muse-glimmer:30b`, or correct `native` |
| `muse-glimmer-30b is an open-weights model; configure an endpoint first` | No endpoint is configured | `mso providers set local_model endpoint --config baseUrl=…` |
| A pin is refused naming `allowRoles` | PLN, SEC or REL pinned to an open-weights model | Pin a Claude model for that role, or add the role to `allowRoles` |
| A remote URL is refused | The host is not private | Use a local server, or set `allowRemoteEndpoint` with `https` (read [the warning](#remote-routers-every-prompt-leaves-the-machine)) |
| Unavailable, with the licence tier as the reason | Below Pro | `mso licence status` |
| **HTTP 400 on the first turn mentioning `role` or `system`** | Claude Code sends some conversation entries with the role `system` inside the message list, and the runtime accepts only `user` and `assistant` there | Upgrade the runtime; report it to the runtime project; a translating proxy can fold those entries into the system prompt. Preflight reports this up front |
| HTTP 400 mentioning thinking, effort or context management | The runtime rejects newer request fields | Upgrade the runtime. Keep `thinkingSupported` `false` for the model |
| Tool calls appear as raw JSON text | The chat template is missing (custom GGUF import) or the runtime is too old | Use the library tag; upgrade the runtime; llama.cpp needs `--jinja` |
| The crew forgets earlier files; answers are cut short | The runtime serves less context than Maestro was told | Raise `OLLAMA_CONTEXT_LENGTH`, or lower `contextTokens` to match |
| Very slow first response each turn | A long prompt being re-processed; part of the model on CPU | `ollama ps`; shorter context; smaller quantisation |
| Repeated `TOOL_LOOP` | The model keeps calling the same tool | Move that order to a Claude model, or set a `modelFallback` |
| Crews on the endpoint time out together | Too many crews sharing one GPU | Lower `maxConcurrentCrews` |

---

## Licences

- **Muse Glimmer** weights are **Apache-2.0**. Downloading and using them
  yourself creates no obligation toward Maestro. If you **redistribute** the
  weights, include the Apache-2.0 licence text and any NOTICE file.
- **Llama-family models** use the **Llama Community Licence**, not Apache-2.0.
  It carries attribution requirements, an acceptable-use policy and other
  conditions. **Have it reviewed by your legal team before you deploy one.**
- Any other model you declare comes with its own licence. Maestro does not
  check it.

---

## Appendix A: alternate runtimes

Each serves the Anthropic Messages API. Point `baseUrl` at it and set `native`
to the name it serves the model under.

**llama.cpp `llama-server`**
(<https://huggingface.co/blog/ggml-org/anthropic-messages-api-in-llamacpp>):

- needs a build new enough for Muse Glimmer (the model card named b10353 or
  newer at investigation time);
- start it with `--jinja` so the model's tool template is used;
- it also serves token counting, which gives Claude Code exact context sizes.

```
llama-server -m ./muse-glimmer/<file>.gguf --jinja -c 65536 --host 127.0.0.1 --port 8080
mso providers set local_model endpoint --config baseUrl=http://127.0.0.1:8080 \
  --config models.muse-glimmer-30b.native=<served name> --config models.muse-glimmer-30b.contextTokens=65536
```

**vLLM** (Linux; best for several concurrent crews):
<https://docs.vllm.ai/en/latest/serving/integrations/claude_code/>

- serve with `--enable-auto-tool-choice --tool-call-parser <the parser named on the model card>`;
- use `--served-model-name muse-glimmer`, because model names containing `/` do
  not work with Claude Code;
- raise `maxConcurrentCrews` to match what your GPU can batch.

**LM Studio** (GUI, version 0.4.1 or later):
<https://lmstudio.ai/docs/developer/anthropic-compat>. Load the model, start the
local server, and use `baseUrl=http://localhost:1234`.

**SGLang**: <https://docs.sglang.io/docs/basic_usage/anthropic_api>. The
Anthropic API is enabled on every server automatically.

---

## Appendix B: Llama-family models

The same steps apply: declare the model under `models` with its runtime name
and context. Check three things first:

1. **Size.** Llama 4 Scout and Maverick are mixture-of-experts models. All of
   their weights must fit in memory, which puts them beyond a single consumer
   GPU. Neither is in the built-in catalogue.
2. **Tool format.** They emit a Python-style tool-call format the runtime must
   convert. In vLLM, use the `llama4_pythonic` tool parser.
3. **Licence.** See [Licences](#licences): legal review first.

---

## See also

- [MODEL-BACKENDS.md](MODEL-BACKENDS.md): the Claude backends, and how the
  open-weights endpoint sits beside them
- [CONFIG-MODELS.md](CONFIG-MODELS.md): choosing a model per role, order and
  voyage
- [PROVIDERS.md](PROVIDERS.md): the provider settings and how credentials are
  handled
- [AIR-GAPPED.md](AIR-GAPPED.md): licence activation and egress on restricted
  machines
- [PATROL.md](PATROL.md): `mso doctor` checks
