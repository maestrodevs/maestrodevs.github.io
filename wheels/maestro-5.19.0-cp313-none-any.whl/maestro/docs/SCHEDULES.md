# Scheduled Tasks

A **schedule** files the same order for you on a recurring cadence: a weekly
dependency audit, a daily triage sweep, a monthly licence review. When a schedule
comes due, Maestro files an ordinary order on a voyage, exactly as if you had run
`mso order create --voyage …` yourself. The dispatcher then runs it through the
usual crews, review gates, verify gate and PR.

A schedule **only files work**. It never dispatches, merges, waives a gate or
runs git. Every order it files passes every gate a hand-filed order passes.

## Before you start: the resident LEAD must be running

**Schedules fire only while the resident LEAD daemon is running.** No other
process fires them, and in particular the dispatcher does not. So:

- **You need a Pro, Team or Enterprise licence.** The resident LEAD is Pro+. See
  [LICENCE.md](LICENCE.md).
- **You must start the daemon yourself.** It does not run by default:

  ```bash
  mso lead start          # start the resident LEAD daemon
  mso lead status         # confirm it is running and not stood down
  ```

- **You must switch schedules on.** They are off by default:

  ```bash
  mso settings set schedules.enabled true
  ```

A stood-down LEAD (`mso lead stand-down`) fires nothing until you run
`mso lead resume`. If the daemon is stopped or stood down while a schedule is
enabled, `mso doctor` reports `schedules.daemon-not-running` (high) and names the
command that fixes it. See [Health checks](#health-checks). The daemon is
described in [LEAD.md](LEAD.md).

Firing a schedule spends **no model tokens**. It is a file write, so it does not
count against the LEAD's daily token ceiling (`lead.tokenCeiling.dailyTokens`),
and a tripped ceiling does not stop a due schedule. The orders it files cost
whatever their crews cost, like any other order. See
[Budget](#budget-and-spend).

## Quick start

```bash
mso schedule create --title "Weekly dependency audit" --type INV --project ACME \
    --every week --day mon --at 06:00 --tz Europe/London \
    --role-sequence PLN,SEC \
    --order-title "Dependency audit {occurrence:%Y-%m-%d}"

mso schedule list
mso schedule show SCH-ACME-2026-0042     # next 3 fire times + projected cost
mso schedule history SCH-ACME-2026-0042  # what each occurrence did
```

Every Monday at 06:00 London time this files an `INV` order titled, for
example, `Dependency audit 2026-11-02`, on a new voyage of its own.

Schedules are stored as JSON files under `.mso/schedules/` (`SCH-{PRJ}-{YEAR}-{SEQ}.json`).
They are tracked in git like orders and voyages. SCH ids share the sequence space
that orders and voyages use. Create and change schedules through `mso schedule` or
the Hub, not by hand: Maestro re-checks every schedule before each fire, and a
hand-edited file that fails the check files nothing.

## Cadence

The vocabulary is deliberately small. Cron strings are not accepted, and nothing
runs more often than once a day.

| Field | Values | Notes |
|---|---|---|
| `every` (`--every`) | `day` · `week` · `month` | The minimum cadence is daily. |
| `at` (`--at`) | `HH:MM`, 24-hour | The local time in the schedule's timezone. |
| `dayOfWeek` (`--day` with `--every week`) | `mon` … `sun` | Weekly only. |
| `dayOfMonth` (`--day` with `--every month`) | `1`–`28`, or `last` | Monthly only. **29, 30 and 31 are refused**: use `last` for "the last day of every month". |
| `timezone` (`--tz`) | an IANA name (`Europe/London`), `UTC`, or a fixed offset `+HH:MM` / `-HH:MM` (up to ±14:00) | Defaults to `schedules.defaultTimezone` (`UTC`). See [Timezones](#timezones). |

Restricting the day of the month to 1–28 or `last` means that short months, leap
years and week 53 never need special handling.

### Daylight saving time

A schedule fires **exactly once per occurrence**, including on the two days a
year when local clocks change:

| Day | What happens |
|---|---|
| **Spring forward**: the local `at` time does not exist that day (e.g. 01:30 in London on the last Sunday of March) | Fires once, at the first valid moment after the gap. **The day is never skipped.** |
| **Fall back**: the local `at` time happens twice (e.g. 01:30 in London on the last Sunday of October) | Fires once, at the **first** of the two instants. It does not fire again an hour later. |
| You change a schedule's timezone | The next occurrence is worked out in the new zone. Occurrences that already fired under the old zone are unaffected. |

Worked examples:

| Zone | Local `at` | Day | Fires at (UTC) |
|---|---|---|---|
| Europe/London | 01:30 | spring forward | 01:00Z |
| Europe/London | 01:30 | fall back | 00:30Z |
| America/New_York | 02:30 | spring forward | 07:00Z |
| America/New_York | 01:30 | fall back | 05:30Z |

Restarting the daemon, adjusting the system clock, or two LEAD ticks within the
same minute never fire an occurrence twice.

## Timezones

IANA zone names such as `Europe/London` or `Australia/Brisbane` are fully
supported. They need a timezone database that Python can load, and Maestro is
strict about that:

1. **A zone must load when you create the schedule.** If Python on this machine
   cannot load the zone you name, `mso schedule create` (and `edit`, and the Hub
   form) **refuses** it. The error tells you to install `tzdata`.
2. **Maestro never falls back to UTC.** A schedule is never quietly run at the
   wrong hour. If its zone stops loading later (for example, a virtualenv is
   rebuilt without `tzdata`), the schedule **does not fire**. Each due occurrence
   is recorded as `SKIPPED (timezone-unloadable)`, and `mso doctor` reports
   `schedules.timezone-unloadable` (high).
3. `UTC` and fixed offsets (`+10:00`) always load and need nothing installed.

`tzdata` is a dependency of Maestro, so a **fresh** install includes it. An
**upgraded** install may not have it. The upgrade command
`pip install --force-reinstall --no-deps maestro==<version> …` deliberately
installs no new dependencies. On Windows, and on any machine without a system
timezone database, install it once:

```bash
pip install tzdata
```

Air-gapped mirrors need `tzdata` added to the mirror.

## Templates: what each run files

The schedule's **template** describes the order each occurrence files. It is a
closed list: these fields, and no others, are accepted.

| Field | CLI flag | Notes |
|---|---|---|
| `type` | `--type` | `FTR`, `BUG`, `INV`, `SEC`, `PLN`, `DOC`, … |
| `project` | `--project` | The project acronym of the filed orders. |
| `priority` | `--priority` | `CRITICAL` · `HIGH` · `MEDIUM` · `LOW` |
| `title` | `--order-title` | Defaults to the schedule title. May use `{occurrence:…}`. |
| `description` | `--description` | May use `{occurrence:…}`. |
| `roleSequence` | `--role-sequence PLN,SEC` | The role chain each order runs. A "small chain" of work is a role sequence. For several orders with dependencies, use [Charts](CHARTS.md). |
| `acceptanceCriteria` | `--acceptance` (repeatable) | |
| `targetRepo` | `--target-repo` | For multi-repo workspaces. |
| `model` | `--model` | Optional. Default (empty) is the role's normal model. |
| `effort` | `--effort` | Optional. Default is the role's normal effort. |
| `contextWindow` | `--context-window` | Optional. |

Anything else is refused by name when you create or edit the schedule, and again
before every fire. That includes `gates`, `status`, `queue`, `voyageId`,
`voyageBranch`, `dependsOn`, `decomposesPlan`, `assignedTo`, `rolePosition`,
`roleHistory` and any `convergenceRetry…` field. A schedule therefore cannot
file an order that skips a review gate, starts in a non-`PENDING` state, or
claims to be part of another order's plan. Each filed order starts `PENDING`.

### Model and effort

A template can pin `model`, `effort` and `contextWindow`. A recurring audit on a
cheaper model at `medium` effort is the obvious use. The model id is checked by
the same validator the dispatcher uses, so a schedule accepts exactly the models
a hand-filed order accepts. Leave the fields empty to get the same model a
hand-filed order would get: your role pins, then Maestro's defaults. See
[CONFIG-MODELS.md](CONFIG-MODELS.md).

### `{occurrence:…}` in titles

`{occurrence:<format>}` is replaced by the occurrence's local date and time. It
works in the order title, the order description and the voyage title only.

- Allowed format directives: `%Y %m %d %H %M %a %b %j %U %V %G %u`.
- Allowed literal characters: letters, digits, space and `, . : / -`.
- At most 64 characters per format.
- Day and month names are always English, whatever the machine's locale.
- Anything else is refused when the schedule is saved. That includes a bare
  `{occurrence}`, any other directive, `%%`, `.attr`, `[i]` and `!r`.

Examples: `{occurrence:%Y-%m-%d}` → `2026-11-02`; `{occurrence:%a %d %b}` →
`Mon 02 Nov`; `{occurrence:%G-W%V}` → `2026-W45`.

### Where the order goes: voyage strategy

| Mode | Flag | Behaviour |
|---|---|---|
| **New voyage per run** (default) | `--new-voyage`, optionally `--voyage-title "… {occurrence:%Y-%m-%d}"` | Each occurrence gets its own voyage, and so its own branch and PR. |
| **Attach to a standing voyage** | `--voyage VOY-ID` | Each occurrence's order is added to that voyage. |

Attach mode has a catch. A voyage is archived when its PR merges, and an archived
voyage accepts no new orders. When that happens the schedule **pauses itself**
with the reason `voyage-archived`, rather than failing every day. Re-point it:

```bash
mso schedule edit SCH-ACME-2026-0042 --new-voyage        # or --voyage VOY-<new>
mso schedule resume SCH-ACME-2026-0042
```

## File or propose: `onDue`

| `onDue` | Flag | When due |
|---|---|---|
| **`file`** (default) | `--on-due file` | Files the order immediately. |
| `propose` | `--on-due propose` | Posts a proposal in Captain Chat. Nothing is filed until you confirm it. |

`file` is the default. Writing the schedule is itself the authorisation, so
Maestro does not ask again for each run.

With `propose`:

- The LEAD posts a proposal to the Captain Chat thread when the occurrence is
  due. You confirm it in the Hub's Captain Chat panel. There is no CLI confirm.
  See [HUB.md](HUB.md) and [LEAD.md](LEAD.md#captain-chat).
- Confirming files exactly that occurrence's order. Confirming twice still files
  one order.
- If the proposal is not confirmed within `lead.chat.proposalTtlMinutes`
  (default 60; `0` means it never expires), it **expires**. Nothing is filed and
  that occurrence is not retried. The next occurrence proposes as normal.
- A stood-down LEAD neither posts nor carries out proposals. A confirm made
  while stood down fails, and the proposal cannot be confirmed again after you
  resume.
- Confirming needs the `schedule.run` capability when access control is on.

## Guards: when a due run is skipped

Before filing, every due occurrence passes through these guards. A guard that
declines records the occurrence as **SKIPPED** with its reason, logs it, and
files nothing. A skipped occurrence is never retried: the schedule simply waits
for its next occurrence.

| Reason | Guard | Default |
|---|---|---|
| `budget` | The workspace spend cap would stop the dispatcher starting new work. See [Budget](#budget-and-spend). | — |
| `offline` | The workspace is offline and `schedules.offlinePolicy` is `skip`. See [Offline](#offline). | policy `file-local` (no skip) |
| `max-open-runs` | This many of the schedule's earlier orders are still unfinished (`maxOpenRuns`, `--max-open-runs`). | `1` (from `schedules.maxOpenRunsDefault`) |
| `previous-incomplete` | The schedule's last order has not completed (`skipIfPreviousIncomplete`, `--[no-]skip-if-previous-incomplete`). A `STALLED` or `FAILED` last run also counts as not completed, until you retry it to completion or cancel it. | on |
| `window-cap` | The schedule has already filed `maxRunsPerWindow` orders in the budget window (`budget.windowDays`, or 30 days if unset). | no cap |
| `timezone-unloadable` | The schedule's zone no longer loads. See [Timezones](#timezones). | — |

The guards are checked in the order shown, and the first one that declines
names the skip. With the defaults (`maxOpenRuns 1`), an unfinished previous run
is reported as `max-open-runs`.

There is also a workspace-wide cap: at most `schedules.maxFiresPerTick` (default
3) orders are filed per LEAD tick across all schedules. Any further due
occurrences wait for the next tick. They are not skipped.

### Missed occurrences are never backfilled

An occurrence can still fire up to `schedules.missedGraceMinutes` (default 60)
after its due time. That covers a daemon that was briefly restarting. Anything
older is recorded once as **MISSED**, with a count, and is **never filed**. No
backfill happens, ever.

So if the machine was asleep for a week, a daily schedule files nothing for
that week. It logs one `MISSED` record with a count of 7 and fires on time at
its next occurrence. A weekly task that missed its slot waits for next week.
`mso doctor` reports the gap as `schedules.overdue`.

Creating, editing or resuming a schedule never fires an occurrence that has
already gone by. To run one now, use `run-now`.

### Running a schedule now

```bash
mso schedule run-now SCH-ACME-2026-0042            # honours every guard except the cadence
mso schedule run-now SCH-ACME-2026-0042 --force    # also ignores maxOpenRuns / skipIfPreviousIncomplete
```

`run-now` files one order immediately. It still respects the budget, the
offline policy, the window cap, stand-down and shared mode. `--force` overrides
only the two pile-up guards. It refuses while `schedules.enabled` is false,
below Pro, or when the `schedules.*` settings are invalid. It exits 1 if the run
was not filed (for example `SKIPPED (max-open-runs)`).

### Failures and automatic pause

If filing an order fails, the occurrence is recorded **FAILED** with a reason
and retried on the next tick. After **3 consecutive failures** the schedule
pauses itself with the reason `failing`, and `mso doctor` reports
`schedules.failing` (high). Read `mso schedule history <ID>`, fix the cause,
then run `mso schedule resume <ID>`.

The usual causes are a hand-edited schedule file that no longer passes the check
(`template-invalid`, `schedule-invalid`), a missing voyage (`voyage-not-found`),
or a permission the daemon's identity lacks (`capability-denied`, see
[Access control](#access-control)).

## Offline

Filing an order is a local file write, so a schedule works offline.

| `schedules.offlinePolicy` | While offline |
|---|---|
| **`file-local`** (default) | Fires as normal and files the order locally. The order is marked `scheduleOfflineAtFire: true`. Whether it **runs** offline is the dispatcher's decision, the same as for any order: an order on a hosted model waits until you reconnect, and one on a reachable local model runs. |
| `skip` | Records `SKIPPED (offline)` and files nothing. |

"Offline" means you switched on offline mode (`mso offline on`). A schedule
never makes a network call to decide whether it is offline.

With the defaults, a long gap stays small. If the LEAD keeps running through
two weeks without network, a daily schedule files **one** order. That order
waits for the network, and every later occurrence is skipped because the
previous run is unfinished. You come back to one order and thirteen logged
skips, not fourteen orders. If the machine was off instead, you get one
`MISSED` record (see above). Reconnecting does nothing special: the waiting
order dispatches through the normal path.

## Budget and spend

If you set a workspace spend cap (`budget.maxUsd`, see
[SETTINGS.md § Spend cap](SETTINGS.md#spend-cap-budget)), schedules respect it:

- When the cap would stop the dispatcher starting new work, every due occurrence
  is **SKIPPED (budget)**. That covers the cap being reached, or spend being
  unpriced, under `budget.onReach: pause`. A schedule stops filing at the same
  moment the dispatcher stops starting work, so it can never be what quietly
  drains the cap.
- Under `budget.onReach: warn` nothing is skipped. The fire's log line carries
  `budget=warn`.
- `maxRunsPerWindow` caps a single schedule by **count** of runs per budget
  window. Maestro has no per-order or per-schedule dollar cap.
- `mso schedule show` prints a **projected cost per run**: the mean and maximum
  of the schedule's last few filed orders, with the cost basis named. A schedule
  with no history says so. Maestro does not estimate a cost it has not seen.

## Shared artefact mode is not supported yet

In **shared** artefact-repo mode (`artefacts.mode: shared`, where several machines
write one artefact plane), schedules **do not fire**. Two machines could each fire
the same occurrence, and Maestro does not yet have a fail-closed way to prevent
that. The LEAD logs `SCHEDULE_SHARED_UNSUPPORTED` once, and `mso doctor` reports
`schedules.shared-mode-held` (medium). Solo and embedded modes are fully
supported. See [ARTEFACT-REPO.md](ARTEFACT-REPO.md).

## Tiers

| What | Tier |
|---|---|
| `mso schedule list`, `show`, `history`, and reading schedules in the Hub | **Every tier**, including community |
| `create`, `edit`, `pause`, `resume`, `delete`, `run-now` | **Pro, Team, Enterprise** |
| Firing, done by the resident LEAD | **Pro, Team, Enterprise** |
| Hub schedule controls (create, edit, run, delete) | **Team, Enterprise** (the Hub's control tier) |

Below Pro, `schedules.enabled: true` behaves as off, and the LEAD logs
`SCHEDULE_TIER_DENIED` once.

## Access control

With identity and access control on (Enterprise, see
[ENTERPRISE-ADMIN-GUIDE.md](ENTERPRISE-ADMIN-GUIDE.md)), there are two schedule
capabilities:

| Capability | Covers |
|---|---|
| `schedule.manage` | create, edit, pause, resume, delete |
| `schedule.run` | `run-now`, and confirming a propose-mode proposal |

Creating, editing or resuming a schedule also needs the capabilities that filing
the same order directly would need: `order.create`, plus `voyage.create` unless
the schedule attaches to an existing voyage (`--voyage`). Nobody can schedule
work they could not file themselves. `pause` and `delete` need only
`schedule.manage`.

The shipped `fleet_operator` group holds `schedule.manage` and `schedule.run`
but not `order.create` / `voyage.create`. Out of the box it can therefore pause,
delete and run schedules but not create, edit or resume them. The `captain`
group holds everything.

The fire itself runs as **whoever started the LEAD daemon**. If that identity
lacks `order.create` / `voyage.create`, each fire records
`FAILED (capability-denied)`, and the schedule pauses itself after three
failures. Nothing is filed. Start the daemon as an identity that can file
orders.

A missing capability prints the standard `Error: permission denied … Requires:
<capability>` message, and the command exits 1. Each schedule records who
created it (`createdByIdentity`) and who last edited or resumed it
(`updatedByIdentity`). Both are `null` when access control is off. On Enterprise,
creating, editing, deleting, pausing, resuming, running, proposing, firing and
skipping are written to the audit log.

Crews cannot write to the `schedules/` directory. Only you, through the CLI or
Hub, author schedules.

## The CLI: `mso schedule`

```text
mso schedule create   [fields…] | --from-file sched.json  [--disabled] [--json]
mso schedule list     [--json]
mso schedule show     <SCH-ID> [--json]
mso schedule edit     <SCH-ID> [fields…] [--from-file updates.json] [--enable|--disable] [--json]
mso schedule pause    <SCH-ID> [--reason TEXT]
mso schedule resume   <SCH-ID>
mso schedule delete   <SCH-ID>
mso schedule run-now  <SCH-ID> [--force] [--json]
mso schedule history  <SCH-ID> [--limit N] [--json]
```

Field flags for `create` and `edit`:

| Group | Flags |
|---|---|
| Schedule | `--title` |
| Cadence | `--every day\|week\|month`, `--at HH:MM`, `--day mon..sun \| 1-28 \| last`, `--tz ZONE` |
| Template | `--type`, `--project`, `--order-title`, `--description`, `--priority`, `--role-sequence`, `--acceptance` (repeatable), `--target-repo`, `--model`, `--effort`, `--context-window` |
| Voyage | `--voyage VOY-ID` or `--new-voyage`, `--voyage-title` |
| Guards | `--max-open-runs N`, `--[no-]skip-if-previous-incomplete`, `--max-runs-per-window N` |
| Mode | `--on-due file\|propose` |

Notes:

- On `edit`, the cadence flags **replace the cadence as a whole**: give `--every`
  and `--at`, plus `--day` where it applies. `--tz` keeps the current zone if
  you leave it out.
- `create --from-file` accepts a schedule object, including the `.schedule`
  part of another schedule's `show --json`, so you can clone a schedule.
  Unknown keys are refused. Identity and provenance fields are ignored.
- `show` prints the next 3 fire times and the projected cost. A schedule file
  that fails the check shows as `INVALID`.
- `pause` with no `--reason` records the reason `operator`. Pausing an
  already-paused schedule without the same `--reason` replaces its reason with
  `operator`.
- `delete` removes the schedule but keeps its history: `history` still works
  afterwards.
- `run-now` shows `FIRED` or `PROPOSED` on success and exits 1 for any other
  outcome.
- `mso schedule --help` and `mso schedule <action> --help` list everything.

Exit codes: **0** success. **1** licence refusal, permission refusal, a declined
`run-now`, or a refusal such as shared mode. **2** usage error, such as an
unknown id, an invalid cadence or schedule, a bad `--from-file`, or `edit` with
nothing to change.

## The Hub

The workspace drawer has a **Scheduled tasks** panel. From it you can:

- list schedules, with each one's next fire time, last outcome and pause reason
- create and edit a schedule with a form
- pause, resume, run now, or delete (delete asks for a second click)
- read a schedule's history

Each control is enabled by its own capability field (`scheduleCreate`,
`scheduleEdit`, `scheduleRun`, `scheduleDelete`). When a control is unavailable,
it shows why: the licence is below the Hub's control tier, or the artefact plane
is read-only. A Hub-authored schedule is identical to a CLI-authored one apart
from its provenance. A schedule created in the Hub files into that workspace's
project; a template naming a different project is refused.

The `schedules.*` settings appear in the Hub settings form under **Scheduled
tasks**. The workspace strip shows the same one-line summary as `mso status`
(below).

For scripted use, the Hub exposes the same operations under
`/api/v1/workspaces/{id}/schedules`:

| Method and path | Operation |
|---|---|
| `GET …/schedules` · `POST …/schedules` | list · create |
| `GET` · `PATCH` · `DELETE …/schedules/{sid}` | show · edit · delete |
| `POST …/schedules/{sid}/pause` · `/resume` · `/run` | pause · resume · run now |
| `GET …/schedules/{sid}/history` | history |

Errors: `400` invalid input, `403` tier or permission, `404` unknown schedule,
`409` refused (for example shared mode or stand-down), `422` malformed request,
`503` artefact plane not writable. A `run` that a guard declines returns `200`
with `ok: false` and the reason, because it was evaluated and recorded.

## Health checks

`mso doctor` (and the resident LEAD's patrol) includes six schedule checks. All
six are silent while `schedules.enabled` is false.

| Check | Severity | Fires when | Suggested command |
|---|---|---|---|
| `schedules.daemon-not-running` | high | Schedules are enabled, but the LEAD daemon is not running or is stood down, so **nothing will fire** | `mso lead start` / `mso lead resume` |
| `schedules.overdue` | medium | An occurrence is past due plus grace with no record | `mso lead status` |
| `schedules.piling-up` | medium | 3 or more consecutive skips for open or incomplete runs | `mso schedule history <ID>` |
| `schedules.failing` | high | 3 or more consecutive failures, or the schedule paused itself | `mso schedule history <ID>`, or `mso schedule edit <ID> --new-voyage` for `voyage-archived` |
| `schedules.timezone-unloadable` | high | A schedule's zone does not load on this machine | `pip install tzdata` |
| `schedules.shared-mode-held` | medium | Shared artefact mode with schedules enabled | `mso settings set schedules.enabled false` |

`mso doctor` exits non-zero while a high-severity schedule finding is present.
Each check lists at most five schedules, then summarises the rest. Thresholds
can be tuned per check: see [PATROL.md](PATROL.md).

`mso status` shows one line:

```text
Schedules: 3 active · 1 paused · next SCH-ACME-2026-0042 2026-11-02 06:00 Europe/London · ⚠ 1 overdue
```

With schedules off but some defined, it says
`Schedules: off · N defined (schedules.enabled is false)`. With none defined, it
shows nothing.

## Lifecycle log

Every evaluated occurrence writes one line to `.mso/logs/lifecycle.log`.
Anything other than a clean fire or proposal starts with `WARN` (or `ERROR`), so
the usual triage grep finds it:

```bash
grep -E '\| (WARN|ERROR) ' .mso/logs/lifecycle.log | grep SCHEDULE_
```

| Event | Meaning |
|---|---|
| `SCHEDULE_FIRED` | An occurrence filed an order. Names the schedule, order and voyage, plus `offline=…` or `budget=warn` when they apply. |
| `SCHEDULE_PROPOSED` | Propose mode posted a proposal. Nothing is filed until you confirm. |
| `SCHEDULE_PROPOSAL_EXPIRED` | A proposal was not confirmed in time. Nothing was filed. |
| `SCHEDULE_SKIPPED` | A guard declined. `reason=` is one of `budget`, `offline`, `max-open-runs`, `previous-incomplete`, `window-cap`, `timezone-unloadable`. |
| `SCHEDULE_MISSED` | Occurrences went by beyond the grace window. Gives a count. Not backfilled. |
| `SCHEDULE_FAILED` | Filing failed. Retried next tick. |
| `SCHEDULE_PAUSED` | The schedule paused itself (`voyage-archived` or `failing`). The line names the fix. |
| `SCHEDULE_SHARED_UNSUPPORTED` | Shared artefact mode: nothing fires. Logged once. |
| `SCHEDULE_TIER_DENIED` | Schedules are enabled but the licence is below Pro: nothing fires. Logged once. |
| `SCHEDULE_REFUSED` | The LEAD's own rules refuse firing, for example a `must_not` item in your LEAD overlay that mentions "schedule". Nothing fires. Logged once. |
| `SCHEDULE_ERROR` | The schedule pass itself hit an error, or the `schedules.*` settings are invalid. The rest of the LEAD tick (patrol, findings, chat) carries on. Logged once per distinct error. |

> A `must_not` item in your LEAD overlay that contains the word "schedule"
> (including "reschedule") stops **every** schedule from firing. Word such items
> carefully.

A corrupt `workspace.json` also stops all schedules. Every fire is held, and
stand-down is treated as on. Fix the file and the next tick picks up. In that
case the visible reason can read `disabled` rather than `config-invalid`.

## Settings

All six are workspace-scoped and can be set with `mso settings set` or in the Hub
settings form. See [SETTINGS.md](SETTINGS.md).

| Key | Default | Meaning |
|---|---|---|
| `schedules.enabled` | `false` | Master switch. Off means nothing fires and nothing changes. |
| `schedules.defaultTimezone` | `UTC` | Zone for a new schedule that names none. An IANA name must load when the schedule is created. |
| `schedules.missedGraceMinutes` | `60` | How late a due occurrence may still fire. Older ones are `MISSED`. |
| `schedules.maxOpenRunsDefault` | `1` | `maxOpenRuns` given to a new schedule. |
| `schedules.maxFiresPerTick` | `3` | At most this many orders filed by schedules per LEAD tick. |
| `schedules.offlinePolicy` | `file-local` | `file-local` or `skip`. See [Offline](#offline). |

Related: `lead.chat.proposalTtlMinutes` (propose-mode expiry, default 60),
`budget.maxUsd` / `budget.onReach` / `budget.windowDays` (spend cap and the
`maxRunsPerWindow` window).

## See also

- [LEAD.md](LEAD.md): the resident LEAD daemon that fires schedules
- [ORDERS-AND-VOYAGES.md](ORDERS-AND-VOYAGES.md): what a filed order goes through
- [CHARTS.md](CHARTS.md): multi-order work with dependencies
- [PATROL.md](PATROL.md): `mso doctor` and check thresholds
- [SETTINGS.md](SETTINGS.md): the settings registry, including the spend cap
- [CLI-REFERENCE.md](CLI-REFERENCE.md): every command
