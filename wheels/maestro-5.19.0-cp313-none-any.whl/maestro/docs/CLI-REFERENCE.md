# Maestro CLI Reference

Detailed reference for the core `mso` commands. For the **complete, canonical command list** (including `roles`, `security`, `mcp`, `bridge`, `identity`, `audit`, `secrets`, `data-flow`, `config`, `quickstart`, `projects`, `review`, `sprint`, `bug`, `update`, `hooks`), see the [public CLI reference](https://github.com/Maestrodevs) or run `mso --help` / `mso <command> --help`.

> All commands use the `mso` prefix (the `adm` alias was removed in v4.0). `crew`/`voyage` are legacy aliases for `squad`/`sprint`.

---

## Contents

- [mso dispatch](#mso-dispatch)
- [mso pause](#mso-pause)
- [mso resume](#mso-resume)
- [mso offline](#mso-offline)
- [mso outbox](#mso-outbox)
- [mso cleanup](#mso-cleanup)
- [mso status](#mso-status)
- [mso demo](#mso-demo)
- [mso usage](#mso-usage)
- [mso squad / mso crew](#mso-squad--mso-crew)
- [mso verify](#mso-verify)
- [mso voyage reconcile](#mso-voyage-reconcile)
- [mso order](#mso-order)
- [mso order why / mso voyage why](#mso-order-why--mso-voyage-why)
- [mso schedule](#mso-schedule)
- [mso reasoning](#mso-reasoning)
- [mso backup](#mso-backup)
- [mso restore](#mso-restore)
- [mso migrate](#mso-migrate)
- [mso init](#mso-init)
- [mso packs](#mso-packs)
- [mso policy](#mso-policy)
- [mso release](#mso-release)
- [mso settings](#mso-settings)
- [mso setup](#mso-setup)
- [mso projects](#mso-projects)
- [mso licence](#mso-licence)
- [mso version](#mso-version)
- [Exit Codes](#exit-codes)
- [Environment Variables](#environment-variables)

---

## mso dispatch

Launch fleet crews from the dispatch queues.

```
mso dispatch [--max-crews N] [--cleanup] [--stagger-delay S] [--timeout M] [--retry-failed N]
```

### Flags

| Flag | Type | Default | Description |
|------|------|---------|-------------|
| `--max-crews N` | integer | `5` | Maximum number of crews to run concurrently. Valid range: 1–5. **Community tier is clamped to 2** regardless of what you request here — the clamp is enforced in the dispatcher itself (not this flag), so it also applies to the Hub's dispatch endpoint. See [LICENCE.md](LICENCE.md#tier-limits-enforced-in-code-not-just-advertised). |
| `--cleanup` | flag | `false` | Run cleanup before dispatching. Stops orphaned processes and resets stale lock files. |
| `--stagger-delay S` | integer | `30` | Seconds to wait between launching successive crew sessions. Reduces API rate pressure. |
| `--timeout M` | integer | `60` | Per-iteration wall-clock CEILING in minutes (a backstop, not the primary hang control). The primary hang control is the activity watchdog (`completion.supervision.stallMinutes`, default 10): a crew with no output for that long is killed as HUNG and its work salvaged + requeued, while a crew that keeps producing output is never killed before the ceiling. Both `--timeout` and `--max-turns` remain active simultaneously. |
| `--max-turns N` | integer | `200` | Claude Code internal turn cap per iteration. When hit, Claude Code exits with `subtype=error_max_turns` (terminal state: `MAX_TURNS`). Order is requeued with fresh context. Increase for complex orders that need more reasoning steps. |
| `--retry-failed N` | integer | `0` | **planned** — Auto-retry crashed orders up to N times. When 0 (default), crashed orders are retried indefinitely. |

The defaults above apply only when nothing else sets a limit. An omitted
`--max-crews`, `--max-turns` or `--timeout` falls back, in order, to:
1. the effective `dispatch.maxCrews` / `dispatch.maxTurns` /
   `dispatch.timeoutMinutes` setting ([SETTINGS.md](SETTINGS.md));
2. for crews only, a legacy `maxCrews` in `config/fleet-settings.json`;
3. the default in the table.

The Hub's Dispatch button resolves the limits the same way.

### How dispatch works

1. Scans all queue directories in priority order (see [Queue Priority](#queue-priority) below)
2. Filters out orders with unsatisfied `dependsOn` dependencies
3. Assigns available orders to crew slots (crew1 through crew5)
4. Launches a Claude Code subprocess for each crew with the role, order, and project context injected
5. Monitors each crew through multiple iterations via the stop hook

### Queue priority

| Queue | Priority |
|-------|---------|
| `queues/explicit/` | Highest |
| `queues/security/` | High |
| `queues/bugs/` | High |
| `queues/requests/` | Medium-High |
| `queues/orders/` | Medium |
| `queues/defects/` | Medium-Low |
| `queues/breakdown/` | Low |
| `queues/high-level/` | Lowest |
| `queues/escalations/` | Not dispatched — requires manual review |

### Examples

```bash
# Launch up to 3 crews
mso dispatch --max-crews 3

# Clean stale state first, then dispatch
mso dispatch --cleanup --max-crews 5

# Slower stagger for large crews to reduce rate limiting
mso dispatch --max-crews 5 --stagger-delay 60

# Raise the wall-clock ceiling for unusually long iterations (default 60)
mso dispatch --max-crews 3 --timeout 120

# Auto-retry crashed orders up to 2 times before permanently failing them
mso dispatch --max-crews 3 --retry-failed 2
```

---

## mso pause

Drain the fleet cleanly: the dispatcher stops claiming new work, lets every running crew finish, then stops. Nothing is killed, nothing is salvaged, and nothing needs retrying afterwards. Use it before a runtime upgrade, a machine restart, or any change you want to make with the fleet idle.

```
mso pause [--wait] [--project @PRJ]
```

### Flags

| Flag | Description |
|------|-------------|
| `--wait` | Block until the fleet reports PAUSED. Exits `1` if the dispatcher stops before the drain completes. Ctrl+C stops waiting, not the drain. |
| `--project @PRJ` | Registered project acronym. |

With no dispatcher running, `mso pause` says so and changes nothing — a stopped fleet is not a paused one. It is not licence-tier-gated: turning a fleet off always works.

### Pause (drain) vs cleanup (stop now)

| | `mso pause` | Stop the dispatcher, then `mso cleanup` |
|---|---|---|
| Running crews | Finish their current work normally | Killed |
| In-flight work | Converges through the normal pipeline | Preserved on `salvage/*` branches and requeued |
| How long it takes | Until the longest-running crew finishes (see below) | Seconds |
| Restarting | `mso resume` — no cleanup, no retries | `mso dispatch`; stranded orders may need `mso order retry` |

### How long a drain can take

A drain ends when the last running crew reaches its own end. The bound for each crew is:

```
crew start time + its timeout ceiling (--timeout, or the order's timeoutMinutes)
               + verifyTimeoutMinutes (default 20) for the verify gate at convergence
```

A cold frontend dependency install at convergence can add up to `verify.frontendInstallTimeoutMinutes` (default 30). With default settings the worst case is roughly **80–110 minutes**; most drains are much shorter. A crew that goes silent is still stopped by the activity watchdog (`completion.supervision.stallMinutes`, default 10), so a hung crew cannot hold a drain open. `mso pause` prints each running crew's latest possible finish time.

### What you see

| State | `mso status` footer | Hub `dispatcher_state` |
|---|---|---|
| Draining | `◐ pausing · 2 crew(s) draining, est. by 14:30` | `PAUSING` (`dispatcher_running` stays true) |
| Drained | `‖ paused · paused since 2026-09-15 14:22; 3 order(s) pending — resume with mso resume` | `PAUSED` |
| Dispatcher died mid-drain | `○ stopped · pause interrupted — dispatcher exited before drain completed; normal recovery applies` | `STOPPED` |

No crew is ever shown as running once the fleet is paused. If the dispatcher is killed or the machine loses power during a drain, recovery is exactly what it is for any unclean stop — the next `mso dispatch` (or `mso resume`) discards the unfinished pause request.

### Example

```bash
mso pause --wait          # drain, and block until PAUSED
# ... upgrade, restart, etc. ...
mso resume                # relaunch with the same settings
```

---

## mso resume

Resume a paused fleet, or cancel a pause that is still draining.

```
mso resume [--max-crews N] [--stagger-delay S] [--timeout M] [--max-turns N] [--project @PRJ]
```

| Fleet state | What `mso resume` does |
|---|---|
| PAUSING (still draining) | Cancels the pause. The running dispatcher resumes claiming work on its next tick — no restart. |
| PAUSED | Relaunches the dispatcher with the settings it was paused with. Any flag you pass overrides the recorded value. |
| Pause interrupted (dispatcher died mid-drain) | Relaunches the dispatcher; normal startup recovery applies. |
| Running, not pausing — or never paused | Says so and changes nothing. Start a stopped fleet with `mso dispatch`. |

A plain `mso dispatch` on a paused fleet works too, and clears the pause. Neither path needs `mso cleanup` or `mso order retry`.

---

## mso offline

Turn offline mode on or off, or show it. Offline mode is something you switch on deliberately to work with no network. Voyage branches and convergence run locally, and remote steps are recorded in the [outbox](#mso-outbox) for later. The full guide is in [OFFLINE.md](OFFLINE.md).

```
mso offline on [--push-on-reconnect] [--reason TEXT] [--for DURATION] [--project @PRJ]
mso offline off [--project @PRJ]
mso offline status [--json] [--project @PRJ]
```

| Action | What it does |
|---|---|
| `on` | Opens an offline session. It records a session id, the operator and reason, and a **baseline** of each repo's remote URL and remote-tracking refs, read locally with no network. It warns if no local model backend is configured (every order will be held), and if a v1 licence's offline grace ends before `--for` does. If a session is already live, it changes nothing. **Refused in `artefacts.mode: shared`** (exit non-zero, naming claim-by-commit); switch the device to solo mode first. |
| `off` | Closes the session. It **does not publish anything**: run `mso outbox replay` for that. Refused while the `offline.mode` setting is `on`. |
| `status` | Shows the session, the baseline, held orders by reason, the outbox by kind and branch, blocked branches with the command that resolves each one, and how far the artefact plane is ahead of its remote. Once the mode is off and the outbox still has entries, it also shows whether the remote is reachable. |

### Flags

| Flag | Description |
|------|-------------|
| `--push-on-reconnect` | `on` only. Records your consent for the resident LEAD (Pro+) to replay **this session's** outbox entries by itself when the network returns. Default: no consent. Fixed for the session: to change it, run `off`, then `on` again. |
| `--reason TEXT` | `on` only. Why you are going offline. It is shown in `status` and in the lifecycle log. |
| `--for DURATION` | `on` only. How long you expect to be offline: `90m`, `36h`, `3d`, `2w` (a bare number means days). Used only to warn when a v1 licence's grace ends sooner. Not stored. |
| `--json` | `status` only. Machine-readable output. |
| `--project @PRJ` | Registered project acronym. |

The standing form is the `offline.mode` setting (`off` \| `on`, default `off`). Set it with `mso settings set offline.mode on` for a workspace that is always offline, such as an air-gapped install. It is refused in shared artefact mode.

`on` and `off` need the `fleet.dispatch` capability in a governed workspace, and both are written to the audit log. Offline mode is not tier-gated.

### Examples

```bash
mso offline on --reason "on the train" --for 6h
mso offline on --push-on-reconnect        # let the resident LEAD publish on reconnect
mso offline status
mso offline off                           # then: mso outbox replay
```

---

## mso outbox

List, inspect and publish the remote actions that offline mode deferred. See [OFFLINE.md § Coming back online](OFFLINE.md#coming-back-online).

```
mso outbox [--project @PRJ] <action> ...

mso outbox list [--repo KEY] [--all] [--json]
mso outbox show <ID> [--json]
mso outbox replay [--yes] [--accept-broken-chain] [--repo KEY] [--json]
mso outbox resolve <BRANCH> [--merge | --abandon | --push-aside] [--verify] [--accept-broken-chain] [--json]
mso outbox rebind <REPO> --to-current [--json]
```

| Action | What it does |
|---|---|
| `list` | Live entries per repo, with counts (pending, blocked, failed) and whether the repo's outbox file is intact (`chain OK` / `CHAIN BROKEN`). `--all` includes done, superseded and abandoned entries. `--repo` limits it to one repo key. |
| `show <ID>` | One entry and its status history. It takes the full id or a unique prefix of 4 or more characters. |
| `replay` | **A dry run by default.** It lists every action replay would take, and pushes and writes nothing. With `--yes`, it publishes per repo in this order: create branch → push branch → open **draft** PR → refresh PR body → push artefact plane. Every entry is re-checked against git first. Pushes are fast-forward only, never forced, and never to the default branch. Marking a PR ready (which starts CI) is listed but **never run**. |
| `resolve <BRANCH>` | Settles a voyage branch that replay blocked as diverged (or deleted, or with a closed PR). `--merge` (default) merges the remote branch into your local one with a merge commit, in a temporary worktree. On a conflict, the branch is left untouched and the conflicting paths are listed. It never rebases. `--verify` also runs `verifyCommand` on the merge. `--abandon` pins your local branch as `salvage/<branch>-offline-<sha8>` and stops replaying it. `--push-aside` pushes your local tip to a **new** remote branch `offline/<VOY>-<sha8>` and stops replaying the original. |
| `rebind <REPO> --to-current` | Accepts the repo's **current** `origin` after it changed while offline, which replay reports as `OUTBOX_REMOTE_CHANGED`. `--to-current` is required, as your confirmation that you checked the new remote. |

`--accept-broken-chain` lets `replay` or `resolve` act on a repo whose outbox file was edited outside Maestro. Read `mso outbox list` first. The resident LEAD never uses it.

**Exit status:** `replay --yes` exits `1` when any entry was left blocked, failed or waiting. A ready-promotion that was listed but not run does not count. `resolve` exits `1` when the branch was not resolved, for example on a merge conflict. Executed `replay`, and every `resolve` and `rebind`, are written to the audit log. `replay`, `resolve` and `rebind` need the `fleet.dispatch` capability in a governed workspace. The outbox is not tier-gated.

### Examples

```bash
mso outbox list
mso outbox replay                                        # dry run
mso outbox replay --yes                                  # publish
mso outbox resolve voyage/VOY-ACME-2026-0042 --merge --verify
mso outbox rebind default --to-current
```

---

## mso cleanup

Stop orphaned crew processes and reset stale crew state.

```
mso cleanup [--force] [--no-backup]
```

### What cleanup does

- Terminates any crew processes whose PID files no longer match a running process
- Reaps orphaned descendant processes of dead crews — not just the crew process itself, but anything it spawned (a filesystem search, a build command, a compiler process, a shell), however deep, that outlived it
- Removes stale `crew.lock` files
- Resets `state.json` for idle crew slots

Safe to run at any time — does not affect orders that are actively in progress. Descendant reaping only ever terminates processes traceable to a specific crew slot, never an unrelated process on the same machine.

**Refuses outright if a dispatcher is currently running** (exits non-zero) — the full routine above would sabotage that dispatcher's live crews and reset their orders to PENDING while the dispatcher itself survived to immediately re-dispatch into the wreckage. See [`--force`](#flags) below for the one case where you want to proceed anyway, and [TROUBLESHOOTING.md E31](TROUBLESHOOTING.md#e31--mso-cleanup-refuses-a-live-dispatcher-is-running) for the full recovery walkthrough.

### Flags

| Flag | Description |
|------|-------------|
| `--force` | Proceed even though a live dispatcher is running. Only for a **WEDGED** dispatcher (process alive, but not ticking — `mso doctor`'s `dispatcher.heartbeat` check reports this) — not a general override for a healthy one, which will keep working on its own. Still force-kills crews and resets their orders to PENDING. It never kills a dispatcher process it can positively confirm is real: a genuinely alive (merely wedged) dispatcher is left running — you must kill that PID yourself before re-dispatching. The one case `--force` clears fully on its own is a `dispatcher.pid`/`demo.pid` lock that only *looks* alive because its PID was recycled by an unrelated OS process (no way to disprove it, e.g. a pre-upgrade lock with no identity sidecar) — there, the lock is cleared and a subsequent `mso dispatch` succeeds with no manual kill needed. |
| `--no-backup` | Skip the automatic pre-cleanup backup (fast recovery path). |

### Example

```bash
mso cleanup

# dispatcher is WEDGED (mso doctor flagged dispatcher.heartbeat) — recover:
mso cleanup --force
mso dispatch --max-crews 5
# if that still refuses with "Another dispatcher is already running (PID N)",
# --force cleared the crews/state but could not positively confirm the lock
# was safe to drop on its own (the common case for a genuinely wedged
# dispatcher) — kill exactly the PID it names, then retry:
taskkill /F /PID <PID>        # Windows
kill -9 <PID>                 # Linux/macOS
mso dispatch --max-crews 5
```

---

## mso status

Display the fleet status dashboard.

```
mso status [--once] [--compact]
```

### Flags

| Flag | Type | Default | Description |
|------|------|---------|-------------|
| `--once` | flag | `false` | Print status once and exit (pipe-friendly plain output). When omitted, the dashboard refreshes on a loop in the terminal's alternate buffer — exiting restores your scrollback. |
| `--compact` | flag | `false` | One-line-per-crew layout for narrow terminals or tmux panes. |

### Examples

```bash
# Live dashboard (loops, press Ctrl+C to exit)
mso status

# One-shot summary
mso status --once

# One-shot, compact view
mso status --once --compact
```

### Dashboard output

The status dashboard is the Squad Monitor v5.0 — a truecolor, indentation-based layout (no box-drawing characters; Unicode block bars `█░` and status dots `●○`). Colors degrade automatically on 256-color and legacy terminals, and output piped to a file is plain text. Sections, top to bottom:

**Header** — Persona product name, Maestro version (resolved dynamically from the installed package), and current timestamp.

**Voyage block** — Each active voyage with a progress bar, completed/total order counts, and an estimated time to completion. The first voyage gets a full block; additional parallel voyages render as condensed one-liners. On API billing, a SPEND line shows workspace cost against budget (from `.mso/usage/orders/`).

**ESCALATIONS** — Shown only when crews have raised blocking issues that require Captain/QM intervention.

**PENDING REVIEW** — Appears only when items require Captain sign-off: voyages/plans/requirements marked `AWAITING_APPROVAL`, plus orders paused at a human review gate. Hidden entirely when nothing is pending.

**Crews** — For each crew slot (persona-named):
- Status dot (ember = running, green = done, yellow = needs attention, red = failed, dim = idle)
- Role (PLN / BLD / TST / DOC / SEC / REL), model (Opus / Sonnet / Haiku), and assigned order ID
- Running crews: iteration progress bar, live turn counter, files changed, token spend, elapsed time, and a heuristic ETA (average iteration time × remaining iterations)
- Latest activity line with age (e.g. `> Edit maestro/cli.py (12s ago)`)

**QUEUE** — Pending order count with per-role breakdown (e.g. `BLD:3 TST:1`) and other queue tallies.

**LIFECYCLE** — Recent fleet lifecycle events (crew starts, completions, role transitions). Omitted in `--compact`.

**Footer** — Dispatcher status (active/stopped, PID, uptime), bridge status, aggregate crew counts, queue depth, and refresh interval.

---

## mso hub

**New in v5.0.0.** Manage the **Maestro Hub** — a real-time, multi-workspace
dashboard. Where `mso status` shows one workspace in one terminal, the Hub
aggregates live state across **every registered project**. In the default
**local mode** one daemon serves both the REST API +
lifecycle WebSocket **and** the Next.js dashboard UI on a single port — **no
Docker, no Node.** The UI ships as a static export inside the wheel
(`maestro/hub/static/`); the backend serves it same-origin.

```bash
mso hub setup                      # local mode (default): validate registry + UI bundle, print start command
mso hub setup --mode docker        # generate device-local Docker deployment config
mso hub setup --mode docker --dry-run   # preview the generated files, write nothing
mso hub setup --mode docker --force     # regenerate over existing files
mso hub start                      # background daemon (backend + dashboard UI) on http://127.0.0.1:3847
mso hub start --port 4000 --open   # custom port; open a browser
mso hub status                     # running? PID + URL
mso hub stop                       # stop the daemon
```

`mso hub setup` provisions the Hub from your own `~/.maestro` registry (no
hand-edited config). **Local mode** (the default) validates the registry, confirms
the wheel-shipped UI bundle is present, and prints the start command — the native
backend reads `~/.maestro` directly, so it writes nothing. **Docker mode**
generates two device-local, gitignored files —
`docker/maestro-home/projects.json` (container registry with every host path
rewritten to `/repos/<basename>`) and `docker/docker-compose.local.yml` (the
Compose overlay) — then prints the `docker compose … up -d --build` command.
`--output-dir` overrides the target (default: the repo `docker/` dir, else
`MAESTRO_HOME/hub-docker/`); existing generated files are refused without
`--force`. Full walk-through: [HUB.md](HUB.md#provisioning-mso-hub-setup).

`mso hub setup` and `mso hub start` are gated to **Team / Enterprise** licences;
`mso hub stop` / `status` are not. For single-operator or development use, run the
backend ungated in the foreground (it still serves the bundled UI same-origin):

```bash
python -m maestro.hub --port 3847      # open http://127.0.0.1:3847
```

You only need the `maestro-hub/` source app when **developing** the dashboard —
local mode already serves the built UI. The dev server runs on its own port and
points back at the backend:

```bash
cd maestro-hub && NEXT_PUBLIC_HUB_URL=http://localhost:3847 npm run dev   # :3000
```

Prefer **Docker** only for a shared/multi-operator server (frontend and backend
in separate containers) — it is an option, not a prerequisite. A source checkout
with no built UI bundle degrades to API-only with a message at `/`.

Full guide — endpoints, tier gating, configuration, troubleshooting:
[HUB.md](HUB.md).

---

## mso demo

Run the Squad Monitor PVT — a simulated 6-order fleet that exercises every dashboard metric, then reports and cleans up after itself.

```
mso demo [--headless] [--fast] [--keep] [--project @PRJ]
```

The demo creates a demo voyage with 6 demo orders (2× 20s, 2× 40s, 2× 60s) and drives them through 3 simulated crew slots on a staggered schedule, writing the same workspace state files a real fleet writes. At order pickup only the order's queue JSON and a lifecycle event are written; crew state.json, activity.txt, and usage files are written at COMPLETE. Without `--headless`, the live dashboard also renders in-process while it runs, driven by an additional per-tick RUNNING snapshot write to those same crew state.json/activity.txt/usage files, showing: voyage progress draining 0/6 → 6/6 with ETA, RUNNING crews with iteration bars / turn counters / token spend / heuristic ETAs, a mid-run escalation that resolves, a pending-review item that clears, queue drain with role breakdown, lifecycle events, and the SPEND line. `--headless` skips that per-tick write (no dashboard is watching it) — only the pickup/COMPLETE writes happen, and the PVT report's "RUNNING metrics" coverage line is only ticked when the per-tick write actually ran.

**No Claude invocations and no token spend** — the crews are simulated. While they run, the demo gathers *real* local findings for the final report: an OWASP pattern scan of the project's Python files, an outstanding-backlog review, a last-activity summary, and recommended next tasks.

The run ends with a PVT verdict (per-order timing tolerance ±35%, coverage checklist) written to `.mso/reports/demo/DEMO-PVT-<timestamp>.md`. Everything else the demo created is removed; pre-existing crew state files are restored byte-for-byte.

### Flags

| Flag | Type | Default | Description |
|------|------|---------|-------------|
| `--headless` | flag | `false` | Skip the live dashboard; run the simulation and print the report (CI / PVT mode). |
| `--fast` | flag | `false` | Scale all timings to 10% — full run in ~15s instead of ~100s. |
| `--keep` | flag | `false` | Keep the demo orders/voyage after the run for inspection. Crew state files are still restored. |
| `--project @PRJ` | string | — | Project alias if not run from inside a workspace. |

### Safety

`mso demo` refuses to run while the dispatcher is alive or any of crew slots 1–3 is RUNNING with a live process — it writes to the same crew state files a real fleet uses. Stale RUNNING states (dead PIDs) do not block it. The Slack bridge notifier is disabled for the duration so the synthetic escalation never pages anyone.

### Examples

```bash
# Full show — watch the dashboard drive itself for ~100 seconds
mso demo

# Quick smoke test (~15s, no dashboard) — exit code 0 on PVT PASS
mso demo --fast --headless
```

---

## mso usage

Report token usage and estimated API cost.

```
mso usage [--voyage VOY-ID | --order ORDER-ID | --summary | --report [--output PATH]
           | --by-effort [--by-role] [--days N]]
```

### Flags

| Flag | Type | Description |
|------|------|-------------|
| *(none)* | — | Print overall summary across all projects |
| `--summary` | flag | Print overall summary (explicit form) |
| `--voyage VOY-ID` | string | Breakdown by order for a specific voyage |
| `--order ORDER-ID` | string | Token detail for a specific order |
| `--report` | flag | Generate full markdown usage report |
| `--by-effort` | flag | Cost table grouped by model x reasoning-effort tier, read from the durable per-iteration records |
| `--by-role` | flag | Add the role dimension to `--by-effort` (model x effort x role) |
| `--days N` | int | Restrict `--by-effort` to the last N days (e.g. 7, 15, 30). Must be a positive integer. |
| `--output PATH` | string | File path for `--report` output. Defaults to stdout. |
| `--project ACRONYM` | string | Disambiguate when multiple Claude project directories match the workspace (e.g. `--project MSO` or `--project @MSO`). Can also be set via `MAESTRO_PROJECT=MSO`. |

### Examples

```bash
# Overall summary
mso usage --summary

# Voyage-level breakdown
mso usage --voyage VOY-MYPROJ-2026-0001

# Single order detail
mso usage --order FTR-MYPROJ-2026-0001

# Generate full report to a file
mso usage --report --output .mso/reports/usage-report.md

# What did each reasoning-effort tier cost over the last 7 days?
mso usage --by-effort --days 7

# Same, split by role as well (is BLD at xhigh worth it over high?)
mso usage --by-effort --by-role --days 30
```

### Usage data source

Token counts are captured automatically at the end of each crew session by the stop hook. Two files are written per order:

| File | Unit | Contents |
|------|------|----------|
| `.mso/usage/orders/{ORDER-ID}.json` | whole order | Accumulated totals across every iteration, plus `roles` / `efforts` **presence lists** (see below) |
| `.mso/usage/orders/{ORDER-ID}.jsonl` | one crew iteration per line | `orderId`, `role`, `iteration`, `crewNumber`, `timestamp`, per-model token counts, `total_tokens`, `estimated_cost_usd`, `effort`, `effortSource` |

The `.jsonl` is the join key for any analysis; `--by-effort`, `--voyage` and the Hub's role rollup all read it.

### Effort attribution (`effort` / `effortSource`)

`effort` is the reasoning-effort tier **as applied** to that invocation — not merely the tier the
override chain resolved. When the installed Claude CLI has no `--effort` flag, the resolved tier is
never handed to the model, so the record stores `effort: null` with `effortSource:
"cli-unsupported"` rather than a tier that did not run. `effortSource` names the layer the value
came from: `order.effort`, `role-models.json`, `env:MAESTRO_EFFORT_<ROLE>`, `role-overlay` or
`builtin-default` — suffixed `(downgraded from xhigh)` when an Opus-only tier was demoted because
the resolved model was not Opus-class.

`--by-effort` buckets a missing, null or empty `effort` (or `role`) under the literal label
`unknown`, footnoted whenever it is non-empty. Rows are never dropped and a tier is never
invented, so totals across all buckets always equal the totals of the records read. Everything
recorded before this shipped falls in `unknown`; it was genuinely never captured and is not
backfilled.

The accumulated `.json` carries `roles` and `efforts` as sorted unique **lists**, never scalars —
an order's roleSequence means its iterations may span several roles and tiers, and a scalar there
would be a fabricated attribution. An iteration with no known value contributes the literal
`"unknown"` to the list, so a partly-known order cannot read as fully known.

### Cost on a backend without a rate card (`unpriced`)

On a workspace whose model backend does not bill at Anthropic's first-party list rates (AWS
Bedrock without `providers.model.bedrock.config.pricingOverrides`), token counts are recorded and
reported exactly as on the direct API, but the cost reads **`unpriced`** — never `$0.00` and never
blank. `--voyage`, `--summary` and `--report` all render it that way. Model ids in the output are
Maestro's canonical ids (`claude-sonnet-5`), never the backend's native ids (`au.…`, `apac.…`,
`global.…`). See [MODEL-BACKENDS.md § Cost is reported honestly, or not at all](MODEL-BACKENDS.md#cost-is-reported-honestly-or-not-at-all).

### When a run produced no model responses

If every reply a crew received was a backend API error — the model id was rejected, the
credentials were refused, the region does not serve the model — the run used no tokens, and
reporting it as zero tokens at `$0.00` would read as "this was free". Instead `mso usage` names it:

```
  No model responses: 1 order(s) -- no model responses recorded - see BUG-MSO-2026-1198 (every reply was a backend API error; run 'mso doctor' and see reports/backend-errors/)
```

| Form | What you see |
|------|--------------|
| `--voyage` | The line above, counted in `order(s)`. Those orders are left out of the `Orders:` count and of the token and cost totals. |
| `--summary` | The same line, counted in `session(s)`. `Sessions:` counts only sessions that had a real response. |
| `--report` | A `**No model responses:**` line in the report header, counted in `session(s)`. |
| `--order` | The line after the record's JSON, when that order is one. |

When **every** order (or session) in the view is like this, there is no cost to state, so the cost
value itself is the label: `Token cost:` (`--voyage`), `Est. Cost:` (`--summary`) and
`**Estimated Cost:**` (`--report`) read `no model responses recorded - see BUG-MSO-2026-1198 (…)`,
and the report's Total row carries the label in its cost cell.

**What to do:** run `mso doctor` and read its `model.backend-error` finding, then open the
diagnostic files under `reports/backend-errors/` in the workspace's artefact root — they record
what the backend actually returned. Fix the cause (usually the model mapping, the region or the
credentials), then retry the order (`mso order retry <ORDER-ID>` if it has stalled).

A run that mixed real responses with errors is not one of these: its real tokens and cost are
reported as usual.

The order's `.json` usage record carries the count as `syntheticMessageCount` (an integer, present
only when non-zero). No `.jsonl` row is written for an iteration that had no real response.

---

## mso squad / mso crew

Inspect or operate an individual squad (aka crew). `squad` is the primary command; `crew` is an alias — both work identically.

```
mso squad --crew N [--status | --watch | --cleanup]
mso crew  --crew N [--status | --watch | --cleanup]
```

### Flags

| Flag | Type | Required | Description |
|------|------|----------|-------------|
| `--crew N` | integer | Yes | Crew number. Valid range: 1–5. |
| `--status` | flag | No | Print crew status and last known state. |
| `--watch` | flag | No | Stream crew progress live from `progress.md`. |
| `--cleanup` | flag | No | Stop this specific crew's process and reset its state. |

### Examples

```bash
# Check squad 1 status
mso squad --crew 1 --status

# Watch squad 2 live
mso squad --crew 2 --watch

# Stop and reset squad 3 (crew alias also works)
mso crew --crew 3 --cleanup
```

---

## mso verify

Run post-voyage build and test verification.

```
mso verify [--voyage VOY-ID] [--skip-tests]
```

### Flags

| Flag | Type | Description |
|------|------|-------------|
| `--voyage VOY-ID` | string | Voyage ID to verify. Verifies all orders in the voyage. |
| `--skip-tests` | flag | Skip test execution; reuse existing test results from the build output. |

### Examples

```bash
# Verify a completed voyage
mso verify --voyage VOY-MYPROJ-2026-0001

# Verify but skip test re-run
mso verify --voyage VOY-MYPROJ-2026-0001 --skip-tests
```

### What verify checks

- Runs the configured build command for each project in the voyage
- Runs the configured test command
- Produces a verification report in `.mso/reports/voyage/`

---

## mso voyage reconcile

Housekeeping: check every voyage's pull-request state, archive the ones whose PR
has merged, and report what was left alone and why. Also available as the broom
button in the [Maestro Hub](HUB.md#housekeeping-sweep) — both run the same code.

```
mso voyage reconcile [--dry-run] [--json] [--voyage VOY-ID] [--repo REPO-SLUG]
```

`sprint reconcile` is the same command (`voyage` is the legacy alias for
`sprint`).

### Why you need it

In practice a human reviews and merges the voyage PR — often long after the
dispatcher that produced it has exited. Maestro therefore never *observes* the
merge, and the voyage sits in `voyages/active/` (and in the Hub's **Final
Review** column) indefinitely. Housekeeping is **pull-based**: you trigger it,
and it needs no running dispatcher. It also runs automatically at dispatcher
startup when `completion.onVoyageComplete.archiveVoyageOnMerge` is enabled.

### Flags

| Flag | Type | Description |
|------|------|-------------|
| `--dry-run` | flag | Report what *would* change without writing anything. Recommended first — reconcile mutates artefact state. |
| `--json` | flag | Emit the report as JSON instead of prose (see below). |
| `--voyage VOY-ID` | string | Reconcile only this voyage. |
| `--repo REPO-SLUG` | string | In a [multi-repo workspace](MULTI-REPO.md), only consider this repo's PR state. |

### What it does

For each voyage it can see:

1. **Resolves merge state** — see [How merge is detected](#how-merge-is-detected).
2. **Archives merged voyages** — voyage JSON moves from `voyages/active/` to
   `voyages/complete/` with merge metadata (`mergedAt`, `mergedPR`,
   `mergeDetectedBy`); its orders and prompts follow if
   `completion.onVoyageComplete.archiveOrders` is set.
3. **Backfills merge metadata** onto voyages already in `voyages/complete/`
   whose PR merged *after* they were finalised.
4. **Flags orders that are archived but not `COMPLETE`** — a stranded order is
   reported, never quietly treated as done.
5. **Reports every refusal with a reason** — an open PR, a voyage with no PR, a
   PR closed without merging, or a merge state it could not determine.

### Example output

```bash
$ mso voyage reconcile --dry-run
[Voyage] dry-run complete — 1 voyage(s) would be archived, 0 completed voyage(s) would be annotated with merge metadata
  [would archive] VOY-ACME-2026-0001: PR is merged (detected via pr)
[Voyage] 4 item(s) left untouched:
  [skipped] VOY-ACME-2026-0002: PR #181 is OPEN — refused to archive an unmerged voyage
  [skipped] VOY-ACME-2026-0003: no PR found for branch 'voyage/…' and the voyage is not finalisable
  [skipped] VOY-ACME-2026-0004: PR #285 is OPEN — refused to archive an unmerged voyage
  [skipped] VOY-ACME-2026-0005: already archived, but PR #218 is not merged — no merge metadata written
```

An earlier release printed only `0 voyage(s) archived`, which gave you nothing
to act on. Every decision now carries its reason.

### `--json` report shape

```json
{
  "dryRun": true,
  "archived": 1,
  "annotated": 0,
  "changes": [
    { "voyage": "VOY-ACME-2026-0001", "action": "archived",
      "reason": "PR is merged (detected via pr)", "prNumber": 284,
      "mergedAt": "2026-07-30T02:14:11Z" }
  ],
  "refusals": [
    { "voyage": "VOY-ACME-2026-0002", "action": "skipped",
      "reason": "PR #181 is OPEN — refused to archive an unmerged voyage",
      "prNumber": 181 }
  ],
  "entries": [ "… changes and refusals, in the order they were decided …" ]
}
```

| Field | Meaning |
|-------|---------|
| `dryRun` | Whether this run wrote anything. |
| `archived` / `annotated` | Counts of voyages archived and of completed voyages given merge metadata. |
| `changes` | Entries whose `action` is `archived`, `annotated` or `linked`. |
| `refusals` | Everything else — `skipped` and `flagged`. |
| `entries` | Both lists combined, in decision order. |

Every entry carries `voyage`, `action` and a human-readable `reason`, plus
`prNumber`, `mergedAt`, `order`, `orderStatus` or `repos` where relevant.

### How merge is detected

**The GitHub PR record is authoritative.** When a voyage records a `prNumber`,
Maestro looks that PR up **by number** and reads its `merged` field.

- Looking up by number (not by head branch) matters because GitHub deletes the
  head branch on merge — a branch-keyed lookup finds nothing precisely when the
  answer is "yes, merged".
- Reading `merged` (not `state`) matters because a merged PR reports
  `state: closed, merged: true`.
- `merged` is blind to merge strategy, so **squash, rebase and merge-commit all
  resolve correctly**. Squash was the case that used to fail: it lands one new
  commit on the base branch, so the voyage branch's own commits never become
  ancestors of the base and any ancestry-based check reported "unmerged"
  forever.

**Raw-git detection is the fallback** — used for voyages with no PR, and when
`gh` is unavailable, unauthenticated or offline. If neither path can decide, the
verdict is *unknown* and the voyage is left alone. Reconcile never reports a
merge it could not confirm, so an offline run degrades to doing less, never to
archiving unshipped work.

The `mergeDetectedBy` field on the archived voyage manifest records which path
decided: `"pr"` or `"git"`.

### When to run manually

- After you merged a voyage PR yourself (the common case)
- When the Hub still shows voyages in **Final Review** whose PRs are merged
- To clean up several stale voyages at once
- Before `mso status`, so the dashboard reflects current state

---

## mso order

Recover, hide, or inspect individual orders — the operator escape hatch for
the BUG-0294 ledger veto and the skip list.

```
mso order why ORDER-ID [--json]
mso order retry ORDER-ID [--role ROLE] [--reason TEXT] [--force] [--no-salvage]
mso order skip ORDER-ID [--reason TEXT]
mso order remove ORDER-ID --from-voyage VOY-ID
mso order unskip ORDER-ID
mso order list
```

`why` is documented in [its own section below](#mso-order-why--mso-voyage-why);
if you are staring at a stuck voyage right now, start with
[WHEN-A-VOYAGE-IS-STUCK.md](WHEN-A-VOYAGE-IS-STUCK.md)
(`mso docs when-a-voyage-is-stuck`) instead.

Also available in the [Maestro Hub](HUB.md#voyage-inspection--retry) as a
**Retry** button on any order the board tags **Needs Attention** — both
surfaces call the same `maestro/core/order_retry.py` implementation.

### `mso order retry`

Reopens an archived `STALLED`/`FAILED` order, or resets a stranded queued
order (`CONVERGENCE_FAILED` / `VERIFY_FAILED` / `BLOCKED` / …) to `PENDING`,
so the next `mso dispatch` picks it up again.

| Flag | Type | Description |
|------|------|-------------|
| `--role ROLE` | string | Role to retry at. Default: the role the order stalled in. |
| `--reason TEXT` | string | Why the order is being retried (recorded on the ledger `REOPENED` event). |
| `--force` | flag | Required to retry an order archived as `COMPLETE`, or a queued `IN_PROGRESS` order. |
| `--no-salvage` | flag | Re-run the role from scratch instead of fast-converging the newest `salvage/*` branch. |
| `--force-salvage` | flag | Arm the salvage fast path even if the staleness check below flags it as risky. |

What it does:

1. Clears the ledger's `TERMINAL` verdict and any lingering claim, and writes a
   `REOPENED` ledger event.
2. Moves an archived order back to `queues/orders/` as `PENDING` (a stranded
   queued order is reset in place) and fires the `RETRY` lifecycle event.
3. Arms the salvage fast path by default — the newest `salvage/<order>-<sha>`
   branch is fast-converged instead of the role re-running from a blank
   worktree — **but only after a staleness check** (see below). `--no-salvage`
   opts out of the fast path entirely.
4. Removes the order from the skip list, if present.

```bash
mso order retry BUG-ACME-2026-0006                # reopen a STALLED order (uses salvage fast path)
mso order retry BUG-ACME-2026-0006 --role BLD --reason "timeout cap raised"
mso order retry FTR-ACME-2026-0007 --force        # a COMPLETE order — needs --force
mso order retry BUG-ACME-2026-0006 --force-salvage  # arm a fast path the staleness check flagged
```

**Salvage staleness check.** Before arming the fast path, `check_salvage_staleness()`
compares the salvage branch against the voyage branch's CURRENT tip — not merely how old the salvage
is. A salvage is only treated as stale when **both** hold: the voyage tip has genuinely advanced past
the salvage's own fork point (commits landed on the branch after the salvage was taken), and those
commits overlap the salvage's own files in a way that would lose work — either a raw merge conflicts,
or replaying the salvage would net more deletions than insertions against what's now on the tip. A
tip that only gained unrelated bookkeeping commits since the fork is **not** stale. When the check
does flag staleness, the retry falls back to `--no-salvage` behaviour automatically (an ordinary
from-scratch re-run) rather than deleting the newer work — the shape this guards against is a
salvage taken before a sibling crew's work converged, which replaying blindly would revert.
Pass `--force-salvage` to arm the fast path anyway once you've
independently confirmed the salvage is safe to replay; the retry then proceeds with a loud warning
note recorded alongside it rather than silently overriding the check.

**Governed/enterprise workspaces:** retry calls
`require_capability("order.dispatch")`. It is a no-op on other tiers; on a governed
workspace, a caller lacking the capability is refused. The Hub's retry
endpoint enforces the identical gate (403 on refusal) but — unlike Dispatch/
Sweep — cannot yet show it as a disabled button with a reason before the
click, because `/api/v1/capabilities` is workspace-independent and retry's
availability is not; the 403 is a real backstop here, not just defence in
depth, until a future order widens that contract per workspace.

### `mso order skip` / `remove` / `unskip` / `list`

| Command | Effect |
|---------|--------|
| `mso order skip ORDER-ID [--reason TEXT]` | Adds the order to the persistent skip list (`.mso/config/skipped-orders.json`). Honoured by `scan_all_queues()` (no re-dispatch, no WARN) and the housekeeping sweep (treated as satisfied). Survives dispatcher write cycles. |
| `mso order remove ORDER-ID --from-voyage VOY-ID` | Strips the order from a voyage's manifest **and** adds it to the skip list. |
| `mso order unskip ORDER-ID` | Removes the order from the skip list. Also reachable from the Hub's `/review` page **Skipped** tab. |
| `mso order list` | Shows every order currently in the skip list. |

---

## mso order why / mso voyage why

Answer "why is this not moving, and what can I do about it" for one order or
one voyage — the cause in plain English, the files that prove it, and an
ordered list of options with the cost of each stated up front.

```
mso order why ORDER-ID [--json]
mso voyage why VOY-ID  [--json]
```

Both are read-only. Neither changes an order, a voyage or the queue; they only
report, and every command they suggest is one you run yourself.

### What it tells you

Nine things can hold an order up, and the answer names which one:

| | |
|---|---|
| **skipped** | An operator parked it. The dispatcher will never pick it up until it is un-skipped. |
| **waiting for review** | Paused at a review gate for a human decision. Nothing is wrong with it. |
| **the verify gate could not run** | The tooling the verify command needs is missing, so the code was never actually checked. |
| **the verify gate failed** | The verify command ran and the code failed it, so the work was held rather than pushed. |
| **convergence failed** | The crew finished, but merging its work into the voyage branch failed. The work exists and is preserved. |
| **auto-serialised** | A real conflict with another crew's work took the order out of the voyage; its changes are on a salvage branch. |
| **stalled** | The fleet gave up after using its retry budget. Only you can move it. |
| **timed out and re-queued** | The fleet is already retrying by itself. Usually the right answer is to leave it alone. |
| **held on a dependency** | Waiting on another order. The options act on the *root* of the chain, not on the order you asked about — acting here would change nothing. |

A voyage answer adds one more: **deadlocked** — every remaining order is held
behind one that cannot resolve on its own.

### What you get back

```
$ mso order why FTR-ACME-2026-0008

  FTR-ACME-2026-0008 is stuck: the verify gate failed
  ----------------------------------------------------------------------------
  The verify gate RAN and the code failed it, so the work was held and never
  pushed. verifyCommand exit 1: 3 tests failed

  Kind:     VERIFY_FAILED
  Severity: high
  Since:    2026-09-08T14:22:10+00:00  (2 days)
  Voyage:   VOY-ACME-2026-0009
  Role:     BLD

  Evidence:
    - Verify log (full stdout+stderr)
      <workspace>/.mso/reports/verify/VERIFY-FTR-ACME-2026-0008-20260908.log

  Options:
    1. Retry from salvage ca7cdb66 (18 files, +864/-12, BLD)   [recommended]
       mso order retry FTR-ACME-2026-0008 --salvage salvage/FTR-ACME-2026-0008-ca7cdb66
    2. Retry fresh (discard preserved work)
       mso order retry FTR-ACME-2026-0008 --no-salvage
       risk: Discards 18 file(s) of preserved work.
```

Every evidence path and every command is printed on a line of its own and
unwrapped, so you can copy it straight out of the terminal.

A voyage answer also carries a **Blocked by** block — each blocking order with
its *own* diagnosis, because "held on FTR-ACME-2026-0010" is not an answer and
"held on FTR-ACME-2026-0010, which stalled after two retries at TST" is.

### Nothing wrong is a successful answer

Both verbs exit **0** when the subject is not blocked, printing a plain
sentence:

```
$ mso order why FTR-ACME-2026-0011
FTR-ACME-2026-0011 is not blocked (PENDING).
```

An id that does not exist is the only error case (exit 2).

### Flags

| Flag | Description |
|------|-------------|
| `--json` | Emit the record as JSON instead of text. A blocked subject emits the full record; an unblocked one emits `{"subjectId": ..., "blocked": false, "status": ...}`. Same shape the Maestro Hub serves, so a script can consume either surface. |

### Where else this appears

The same diagnosis — the same words, computed once — drives the one-line
verdict on `mso status`'s MISSION block for a voyage that is not progressing,
the Hub's order panel, and `mso doctor`'s stuck-order finding. If two surfaces
ever disagreed about why something was stuck, that is the problem this shares
one answer to avoid.

> **A fuller walkthrough** — every cause in operator language, what each one
> does *not* mean, the Hub panel and banner, and what to do next — is
> [WHEN-A-VOYAGE-IS-STUCK.md](WHEN-A-VOYAGE-IS-STUCK.md)
> (`mso docs when-a-voyage-is-stuck`). Start there when you have a stuck
> voyage in front of you; this section is the flag-and-output reference.

---

## mso schedule

Create and manage scheduled tasks: orders filed for you on a recurring daily,
weekly or monthly cadence. Schedules fire only while the resident LEAD daemon is
running (`mso lead start`, Pro+) and `schedules.enabled` is true. Full guide:
[SCHEDULES.md](SCHEDULES.md).

```
mso schedule create   [fields…] | --from-file sched.json  [--disabled] [--json]
mso schedule list     [--json]
mso schedule show     <SCH-ID> [--json]
mso schedule edit     <SCH-ID> [fields…] [--from-file updates.json] [--enable|--disable] [--json]
mso schedule pause    <SCH-ID> [--reason TEXT]
mso schedule resume   <SCH-ID>
mso schedule delete   <SCH-ID>
mso schedule run-now  <SCH-ID> [--force] [--json]
mso schedule history  <SCH-ID> [--limit N] [--json]
```

| Action | Tier | What it does |
|--------|------|--------------|
| `list` / `show` / `history` | every tier | Read schedules. `show` prints the next 3 fire times and the projected cost per run. |
| `create` / `edit` | Pro+ | Cadence `--every day\|week\|month --at HH:MM [--day …] [--tz …]`, plus the order template, voyage and guard flags. On `edit` the cadence flags replace the cadence as a whole. |
| `pause` / `resume` | Pro+ | Resuming never fires an occurrence that has already gone by. |
| `delete` | Pro+ | Removes the schedule. Its history is kept. |
| `run-now` | Pro+ | Files one run immediately, honouring every guard except the cadence. `--force` overrides `maxOpenRuns` / `skipIfPreviousIncomplete` only. |

Exit codes: `0` success; `1` licence or permission refusal, a declined `run-now`,
or a refusal such as shared artefact mode; `2` usage error (unknown id, invalid
cadence or schedule, bad `--from-file`, `edit` with nothing to change).

### Example

```bash
mso schedule create --title "Weekly dependency audit" --type INV --project ACME \
    --every week --day mon --at 06:00 --tz Europe/London --role-sequence PLN,SEC
```

---

## mso reasoning

Read what crews recorded about their reasoning: the model's own summarised
reasoning, its tool calls and Maestro's steps, per order. Capture is on by
default (`reasoning.enabled`). Read-only apart from `import`, which only adds
reasoning files. Every tier. Full guide: [REASONING.md](REASONING.md).

```
mso reasoning tail   <ORDER|crewN> [-f] [-n N] [--digest] [--json] [--project @PRJ]
mso reasoning show   <ORDER> [--role R] [--format text|md|json] [--digest] [--project @PRJ]
mso reasoning import [--order ORDER] [--dry-run] [--json] [--project @PRJ]
```

| Action | What it does |
|--------|--------------|
| `tail` | The newest records of an order (every role and iteration), or of what crew slot `crewN` is working on now. `-f` follows; on a crew slot it follows the crew to its next iteration, role or order. `-n N` sets how many existing records to show first (default 20); use N above 0, since `-n 0` currently prints every record. |
| `show` | Everything recorded for one order, oldest first, grouped by role, lap and iteration, with **Model reasoning** and **Activity** (Maestro steps and tool calls) kept separate. `--role` is not case-sensitive. Timestamps are UTC. |
| `import` | Best-effort back-fill from crews' old `output_*.txt` files. Most hold empty thinking blocks, so expect little. Safe to re-run. Refused while `reasoning.enabled` is `false`. |

`--digest` prints Maestro's one-line digest of each record instead of the full
text. Model reasoning is always printed quoted and labelled as the model's, and
tool calls and Maestro steps as `[tool   ]` / `[maestro]` lines.

Exit codes: `0` success; `2` an id that is neither an order nor a crew slot that
exists, or `import` while capture is off.

### Example

```bash
mso reasoning tail crew2 -f --digest
mso reasoning show FTR-MSO-2026-0001 --role BLD --format md > bld-reasoning.md
```

---

## mso backup

Create a ZIP archive of workspace project state, or list available backups.

```
mso backup [--project ACRONYM] [--output PATH] [--list]
```

### Flags

| Flag | Type | Default | Description |
|------|------|---------|-------------|
| `--project ACRONYM` | string | all projects | Only include files for this project acronym (e.g. `OTM`). Files for other projects are excluded. |
| `--output PATH` | string | `./maestro-backups/` | Directory to write the backup archive. Created if it does not exist. |
| `--list` | flag | `false` | List available backups in the output directory instead of creating a new one. |

### What gets backed up

The following `\.mso/` subdirectories are included:

| Directory | Contents |
|-----------|---------|
| `orders/active/`, `orders/complete/`, `orders/failed/` | All order JSON files |
| `voyages/active/`, `voyages/complete/` | All voyage JSON files |
| `prompts/active/` | Active crew prompt files |
| `plans/` | Navigator planning documents |
| `handoffs/` | Inter-role handoff files |
| `requirements/` | Project requirements |
| `reports/` | Generated reports |
| `usage/orders/` | Token usage records |
| `config/` | `workspace.json`, `projects.json`, per-project configs |

Root workspace files also included: `CLAUDE.md`, `.mso/BACKLOG.md`, `.mso/VOYAGE-STATUS.md`.

The following directories are **excluded** (runtime/framework state — not project state):

| Excluded | Reason |
|---------|--------|
| `.mso/core/` | Framework scripts — provided by pip/submodule |
| `.mso/hooks/` | Framework hooks |
| `.mso/crews/` | Ephemeral crew runtime state |
| `.mso/logs/` | Ephemeral logs |
| `.mso/temp/` | Temp files |
| `.mso/queues/` | Regenerated by the dispatcher at runtime |

### Backup file format

Backups are ZIP archives named:

```
maestro-backup-{PROJECT_OR_ALL}-{YYYY-MM-DD-HHMMSS}.zip
```

For example: `maestro-backup-all-2026-03-30-143000.zip` or `maestro-backup-OTM-2026-03-30-143000.zip`.

Every archive contains a `manifest.json` at its root:

```json
{
  "version": 1,
  "created_at": "2026-03-30T14:30:00.000000",
  "workspace": "/path/to/workspace",
  "projects_included": ["OTM"],
  "maestro_version": "2.0.0",
  "file_count": 42
}
```

| Field | Description |
|-------|-------------|
| `version` | Backup format version (currently `1`) |
| `created_at` | ISO 8601 local timestamp |
| `workspace` | Absolute path to the workspace root at backup time |
| `projects_included` | List of project acronyms included (uppercase), or `["ALL"]` for a full backup |
| `maestro_version` | Maestro version that created the archive |
| `file_count` | Number of files in the archive (excluding `manifest.json`) |

### Per-project filtering

When `--project ACRONYM` is passed, only files whose names contain `-{ACRONYM}-` or start with `{ACRONYM}.` are included. Workspace-level files (`workspace.json`, `projects.json`, `CLAUDE.md`, etc.) are always included regardless of filter.

This is designed for multi-project workspaces where you want to extract or share the state of a single project without including others.

### Auto-backup before cleanup

`mso cleanup` automatically creates a full workspace backup before removing stale state. The backup path is printed so you know exactly where the snapshot was saved:

```
[Maestro] Auto-backup created: /workspace/maestro-backups/maestro-backup-all-2026-03-30-143000.zip
```

### Examples

```bash
# Full workspace backup (all projects)
mso backup

# Back up only the OTM project files
mso backup --project OTM

# Write backup to a custom directory
mso backup --output /mnt/backups/maestro/

# Back up OTM project to custom directory
mso backup --project OTM --output /mnt/backups/maestro/

# List available backups
mso backup --list

# List backups in a custom directory
mso backup --list --output /mnt/backups/maestro/
```

### Example --list output

```
[Maestro] Backups in /workspace/maestro-backups/:

  maestro-backup-all-2026-03-30-143000.zip
    Created:   2026-03-30T14:30:00+00:00
    Projects:  all
    Version:   2.0.0
    Files:     87

  maestro-backup-OTM-2026-03-29-090000.zip
    Created:   2026-03-29T09:00:00+00:00
    Projects:  OTM
    Version:   2.0.0
    Files:     34
```

---

## mso restore

Restore workspace project state from a backup archive.

```
mso restore BACKUP_FILE [--project ACRONYM] [--force] [--merge] [--dry-run]
```

### Flags

| Flag | Type | Default | Description |
|------|------|---------|-------------|
| `BACKUP_FILE` | positional | *(required)* | Path to the backup ZIP archive to restore from. |
| `--project ACRONYM` | string | all | Only restore files for this project acronym. Applies the same filename filter as `mso backup --project`. |
| `--force` | flag | `false` | Overwrite existing files unconditionally. |
| `--merge` | flag | `false` | Keep whichever copy has the later modification time. Skips the file if the destination is newer. |
| `--dry-run` | flag | `false` | Print what would be written without writing anything. |

### Conflict resolution

When a file from the archive already exists at the destination, the behaviour depends on the flags used:

| Mode | Flag | Behaviour |
|------|------|-----------|
| **Skip** | *(default, no flags)* | Leave the existing file untouched. Print `[SKIP] <file>`. |
| **Force** | `--force` | Overwrite the existing file unconditionally. |
| **Merge** | `--merge` | Compare modification times. Keep whichever copy is newer. Skip if the destination file is newer. |
| **Dry run** | `--dry-run` | Show the action for each file without writing anything. Summary line is prefixed `[DRY RUN]`. |

**Use-case guidance:**

- **Default (skip):** Safe for adding files from an older backup without touching anything already in place. Use when restoring into an active workspace where some state is current.
- **`--force`:** Use when restoring a clean snapshot to a fresh workspace, or when you want the backup to fully replace current state.
- **`--merge`:** Use when merging state from two separate workspaces (e.g. transferring project state to a new machine while keeping locally-modified orders).
- **`--dry-run`:** Always run `--dry-run` first when restoring into a workspace with active work to preview exactly what would change.

### Examples

```bash
# Restore from a backup (skip existing files by default)
mso restore maestro-backup-all-2026-03-30-143000.zip

# Preview what would be restored without writing anything
mso restore maestro-backup-all-2026-03-30-143000.zip --dry-run

# Restore only OTM project files from a full backup
mso restore maestro-backup-all-2026-03-30-143000.zip --project OTM

# Overwrite existing files unconditionally
mso restore maestro-backup-all-2026-03-30-143000.zip --force

# Keep the newer file when conflicts occur
mso restore maestro-backup-all-2026-03-30-143000.zip --merge

# Full path to archive
mso restore /mnt/backups/maestro/maestro-backup-OTM-2026-03-29-090000.zip --project OTM
```

### Example output

```
[Maestro] Restoring from: maestro-backup-all-2026-03-30-143000.zip
  Backup created: 2026-03-30T14:30:00+00:00
  Projects: all
  Maestro version: 2.0.0
  Files in archive: 87

[Maestro] Restore complete — extracted: 85, overwritten: 0, skipped: 2
```

---

## mso migrate

One-off, consentful, backed-up rewrites of workspace state. Every action takes a mandatory backup before its first write, refuses while a dispatcher owns the workspace, and supports `--dry-run`.

```
mso migrate <action> [flags]
```

### Actions

| Action | What it does |
|--------|--------------|
| `artefact-repo` | Move the durable artefact plane into a dedicated artefact repo (solo mode): copy-fresh, pre-flight cleanup gate, manifest hash-diff verify, registry + `workspace.json` rewire. Supports `--rollback`. |
| `import-workspace` | Amalgamate an existing workspace into a target's artefact repo, renaming imported IDs with a sub-acronym prefix (`<SOURCE>-*` → `<TARGET>-<SUB>-*`) and rewriting every cross-reference. |
| `model-pins` | Upgrade **operator** model pins one step forward inside a model family. Documented in full below. |

```bash
mso migrate artefact-repo --dry-run
mso migrate import-workspace C:/Repos/GKT-Portal --into C:/Repos/GKT-Platform --sub-acronym POR
mso migrate model-pins --dry-run
```

### mso migrate model-pins

Upgrade the model pins **in your workspace** by an exact-id map: `claude-opus-5` → `claude-opus-5-5` and `claude-sonnet-5` → `claude-sonnet-5-5`. Nothing else moves — a pin to a previous-generation id, or to a current model in another family, is reported `UNCHANGED` and left exactly as it is. It never edits the installed package — shipped role defaults change by release, not by a command.

```
mso migrate model-pins [--dry-run] [--only ROLE[,ROLE]] [--exclude ROLE[,ROLE]]
                       [--orders | --no-orders] [--yes] [--project ACR]
```

| Flag | Meaning |
|------|---------|
| `--dry-run` | Print the full report; write nothing. **Do this first.** |
| `--only ROLE[,ROLE]` | Limit to these role codes (`PLN,BLD,TST,DOC,SEC,REL,LEAD`) |
| `--exclude ROLE[,ROLE]` | Skip these role codes |
| `--orders` / `--no-orders` | Include live order-JSON pins (default: included) |
| `--yes` | Skip the interactive confirm. The mandatory backup still runs. |
| `--project ACR` | Locate the workspace when run from outside one |

An unknown role code in either flag is an error, not a silent no-op.

**`--exclude` takes precedence over `--only`: a role named in both is skipped.** A deny-list losing to an allow-list would mean a typo silently *widened* a mutating command, so the conservative reading wins.

**The role filters are role-scoped — they do not reach order pins.** `--only` / `--exclude` narrow role pins, overlays and the env-var report. A live order carries its own `model` and may run several roles, so it is not attributable to one role code; `--no-orders` is the order-scoped control. `mso migrate model-pins --only PLN` still upgrades every eligible live order pin unless you also pass `--no-orders`.

There is deliberately **no `--force`**: the preflight refusal (a live dispatcher or a live crew) cannot be overridden, because a mid-voyage model change would put a later role of the same voyage on a different model than the one that ran.

**Scope.** Upgrades `.mso/config/role-models.json`, role overlays at `.mso/config/roles/<CODE>.md`, and live order JSON in `queues/**` + `orders/active/`. Never writes `orders/complete/`, `orders/failed/` or `usage/**`, and never writes an order whose `status` is `COMPLETE` / `FAILED` / `CANCELLED` wherever it sits.

**What the diffs look like.** A role overlay is edited surgically — one token inside the frontmatter — so the file is otherwise byte-identical. `role-models.json` and any live order JSON are **re-serialised at two-space indentation** with a trailing newline (`role-models.json` goes through the same writer as any `mso settings set`, so that is its normal shape). Line endings and the trailing-newline convention are preserved in every case. If you hand-wrote an order JSON at four-space or compact indentation, expect its whole body to reformat.

**Report.** One line per pin, grouped `CHANGE` (`WOULD CHANGE` under `--dry-run`) / `UNCHANGED` / `SKIPPED (historical)` / `SKIPPED (held)` / `REFUSED` / `INFO`, then a count line. Every `REFUSED` line names the command that resolves it.

**Opting a pin out.** `"holdModel": true` beside the pin in `role-models.json` (or `"hold_model": true` in an overlay's frontmatter) marks it deliberate: it is reported `SKIPPED (held)` and never changed.

**Undo.** The backup zip path is printed before the first write, and the final line names `mso restore "<zip>"`. There is no `--rollback` for this action. Running it twice reports `0 changes`.

Full guide, including the Bedrock refusal case and the `pricingOverrides` note: [CONFIG-MODELS.md](CONFIG-MODELS.md#upgrading-pins-when-a-new-model-ships).

```bash
$ mso migrate model-pins --dry-run

PLANNED MODEL-PIN CHANGES (dry-run — nothing mutated)
  ----------------------------------------------------------------------
  WOULD CHANGE          config/role-models.json  [PLN]  claude-opus-5 -> claude-opus-5-5
  WOULD CHANGE          config/role-models.json  [BLD]  claude-opus-5 -> claude-opus-5-5
  SKIPPED (held)        config/role-models.json  [SEC]  claude-opus-5
                        └─ holdModel is true — this pin is deliberate; reported, never changed.
  UNCHANGED             config/role-models.json  [DOC]  claude-haiku-4-5
                        └─ not an in-family upgrade target
  SKIPPED (historical)  orders/complete/FTR-MSO-2026-0100.json  [FTR-MSO-2026-0100]  claude-opus-5
                        └─ historical record (orders/complete|failed) — never written.
  2 pin(s) would change (0 order pin(s)), 1 unchanged, 1 skipped (historical), 1 skipped (held), 0 refused, 0 informational.
  ----------------------------------------------------------------------

  Nothing was written. Re-run without --dry-run to apply 2 change(s).
```

---

## mso init

Scaffold a new Maestro workspace.

```
mso init --project ACRONYM [--directory PATH] [--force] [--pack NAME]
```

### Flags

| Flag | Type | Required | Default | Description |
|------|------|----------|---------|-------------|
| `--project ACRONYM` | string | Yes | — | Project acronym (2–8 uppercase letters, e.g. `OTM`, `MYPROJ`). |
| `--directory PATH` | string | No | current directory | Target directory for the workspace. Created if it does not exist. |
| `--force` | flag | No | `false` | Overwrite an existing `\.mso/` directory. Without this flag, init will not run if `\.mso/` already exists. |
| `--pack NAME` | string | No | `sdlc` | Division pack to scaffold — `sdlc`, `test-engineering`, `secops`, `tech-ba`, `devops`, or `ops-bpa`. Omit for the default SDLC workspace — `mso init` and `mso init --pack sdlc` are byte-identical. Non-`free` packs (every division pack except `sdlc`) require a matching licence tier (or `MAESTRO_SKIP_AUTH=1`). See [mso packs](#mso-packs) and [DIVISION-PACKS.md](DIVISION-PACKS.md). |

> **Community tier is limited to 1 registered project.** The gate is on *registering* a new, distinct project acronym — re-running `mso init --project ACRONYM` for an already-registered acronym (e.g. after moving the workspace) is always allowed. A second `--project` acronym is refused with a licence message rather than silently accepted and then unable to dispatch. See [LICENCE.md](LICENCE.md#tier-limits-enforced-in-code-not-just-advertised).

### Examples

```bash
# Scaffold in the current directory
mso init --project MYPROJ

# Scaffold in a specific directory
mso init --project MYPROJ --directory /path/to/my-workspace

# Re-scaffold (overwrite existing config)
mso init --project MYPROJ --force

# Scaffold with a division pack (Team/Enterprise tier)
mso init --project QA1 --pack test-engineering
```

### What init creates

| Path | Purpose |
|------|---------|
| `.mso/config/workspace.json` | Workspace-level settings |
| `.mso/config/projects.json` | Project registry |
| `.mso/config/projects/MYPROJ.json` | Per-project role path configuration |
| `.mso/orders/active/`, `complete/`, `failed/` | Order lifecycle directories |
| `.mso/voyages/active/`, `complete/` | Voyage lifecycle directories |
| `.mso/queues/orders/` and other queue tiers | Dispatch queues |
| `.mso/crews/crew1/` through `crew5/` | Per-crew working directories |
| `.mso/plans/`, `.mso/handoffs/` | Navigator artifacts |
| `CLAUDE.md` | Quartermaster configuration |
| `.gitignore` | Standard exclusions for crew runtime files |

---

## mso packs

Discover and inspect division packs — templated persona + role + order-type sets for non-SDLC
teams (`test-engineering`, `secops`, `tech-ba`, `devops`, `ops-bpa`, plus the built-in `sdlc`
pack). Full guide: **[DIVISION-PACKS.md](DIVISION-PACKS.md)**.

```
mso packs list
mso packs show PACK [--json]
mso packs validate [PACK] [--path DIR]
```

### Subcommands

| Subcommand | Description |
|------------|-------------|
| `list` | List built-in packs with tier and access ("yes" / "upgrade") badges. |
| `show PACK` | Print a pack's manifest, order types (`roleSequence` per type), and anatomy (which optional assets it ships). |
| `show PACK --json` | Print the raw `pack.json` manifest. |
| `validate [PACK]` | Validate a pack's manifest, role overlays, persona, order templates, gates, and workspace defaults. Validates every built-in pack if `PACK` is omitted. Exit `0` if all clean, `1` if any invalid (CI-usable). |
| `validate --path DIR` | Validate an arbitrary pack directory not on the built-in search path — useful while authoring a new pack before it ships. |

Role overlay files inside a pack are validated through the exact same code path as
`mso roles validate` (`maestro.roles.loader.parse_role_file`), so the two commands never drift
apart.

### Examples

```bash
mso packs list
mso packs show sdlc
mso packs show test-engineering --json
mso packs validate
mso packs validate test-engineering
mso packs validate --path ./my-pack
```

To scaffold a workspace with a pack applied, see `--pack` under [mso init](#mso-init).

---

## mso policy

Governance policy tooling. Two families of work share the `policy` group:

- **Signed bundles (Phase 2, enterprise):** `pull` / `verify` / `show` — distribute and verify
  Ed25519-signed policy bundles so an org can ship guardrails a local engineer cannot silently relax.
- **CI enforcement backstop (Phase 5):** `verify --ci` — re-evaluate a committed diff against the
  governed packs on infrastructure the engineer does not own. This is where governed-mode policy
  becomes **binding**: a rule bypassed on a developer's machine still fails the merge.

```
mso policy pull [--url URL]
mso policy verify [--bundle PATH]          # verify a signed bundle's signature (read-only)
mso policy verify --ci [options]           # CI backstop — evaluate a diff, fail on any violation
mso policy show
```

### `mso policy verify --ci`

Reuses the *same* pure engine the client-side pretool hook uses, so verdicts match. Every added line
of the diff is evaluated as a candidate command (Bash context) and each changed file's added content
as a candidate write (Write context); any `deny` rule that fires is a violation and the command exits
non-zero. Removed lines are never evaluated — they cannot execute.

| Flag | Description |
|------|-------------|
| `--ci` | Select CI diff-evaluation mode (vs. the default signed-bundle signature check). |
| `--base REF` / `--against REF` | Diff base for `base...HEAD` (default `origin/main`). |
| `--head REF` | Diff head (default `HEAD`). |
| `--staged` | Evaluate `git diff --staged` instead of a branch diff. |
| `--diff-file PATH` | Read a pre-computed unified diff (`-` = stdin). |
| `--repo PATH` | Repository directory to run git in (default: CWD). |
| `--exclude GLOB` | Skip paths matching GLOB (repeatable; **adds to** the defaults). |
| `--include GLOB` | Restrict evaluation to matching paths (repeatable). |
| `--no-default-excludes` | Scan everything — drop the built-in doc/pack exclude set. |
| `--warn-only` | Report violations but exit `0` (roll-out / observe mode). |
| `--json` | Emit a machine-readable report. |

**Default excludes** (authoring surfaces that legitimately contain trigger strings):
`*.md docs/* maestro/docs/* maestro/governance/library/* CHANGELOG* LICENSE*`. Note that `.github/*`
and `tests/*` are **scanned by default** (they execute in CI) — narrow with a targeted `--exclude`
only if your own workflows/fixtures embed trigger strings on purpose.

**Exit codes:** `0` clean (or `--warn-only`); `1` at least one governed-pack violation (**CI must
fail**); `2` operational error — bad diff source, git failure, tampered/unverifiable packs, or a
non-empty diff that did not parse cleanly (fail-closed).

```bash
mso policy verify --ci                                  # diff origin/main...HEAD
mso policy verify --ci --base origin/main --json        # machine-readable
git diff origin/main...HEAD | mso policy verify --ci --diff-file -
mso policy verify --ci --exclude 'tests/fixtures/*'     # narrow, documented exclude
```

A reusable composite GitHub Action ships at `.github/actions/policy-verify`, wired into this repo's
own `.github/workflows/policy-verify.yml` as a live example. Full trust-boundary model, the drop-in
snippet, and the client-vs-CI rationale: **[GOVERNANCE-TRUST-BOUNDARY.md](GOVERNANCE-TRUST-BOUNDARY.md)**
(`mso docs governance-trust-boundary`).

---

## mso release

Release-readiness report and version-bump helper. `preflight` is read-only. `cut` stops before
the tag: it bumps the version files, tries to open the release PR, and prints the rest of the
chain (merge, tag, push, publish) as text for you to run. Neither action ever tags, pushes tags,
creates a release, or publishes a package.

```
mso release preflight [--json] [--timeout SECONDS] [--skip-build] [--only CHECK]
mso release cut VERSION [--execute] [--json]
```

Run both from inside the repo being released. The repo root is found by walking up from the current
directory.

### `mso release preflight`

Runs these checks, in this order:

| Check | What it verifies |
|-------|------------------|
| `version-lockstep` | `maestro/__init__.py`, `pyproject.toml` and the top `CHANGELOG.md` section name the same version |
| `doc-pins` | No stale `maestro==<version>` / `maestro-<version>-` pins in the install docs |
| `pypi-readme-safe` | The public PyPI README test passes (`SKIPPED` if the test file is absent) |
| `docs-model-names` | The model-names drift test passes (`SKIPPED` if the test file is absent) |
| `build` | `python -m build` + `twine check` succeed on a temporary copy of the working tree |
| `keyring-trap` | Warns, without blocking, when the installed package is a repo-tree install |

**It takes a few minutes, and it says so as it goes.** A full run takes about five minutes on a
typical machine, because `pypi-readme-safe` and `build` each build a real sdist and wheel. A line is
printed as each check starts and ends, with its elapsed time, and a `still running: <check> (N s)`
line is printed every 30 seconds while a check is still going:

```
[3/6] pypi-readme-safe: running ...
      still running: pypi-readme-safe (30 s)
      ...
[3/6] pypi-readme-safe: PASS (155.5s)
```

**It is read-only.** It writes no version file, makes no git commit, tag or push, and leaves nothing
inside the repo. The build runs in a temporary directory, which is deleted afterwards, and the test
runs write no cache or bytecode. It builds what is in your working tree, uncommitted edits included,
so it can check a version bump before you commit it.

#### Flags

| Flag | Default | Description |
|------|---------|-------------|
| `--json` | off | Print a machine-readable report on stdout. Progress lines go to stderr, so stdout stays valid JSON |
| `--timeout SECONDS` | 600 per test file, 1020 for the build | Ceiling for each check. A check that reaches it is stopped and reported as `TIMEOUT` |
| `--skip-build` | off | Skip the `build` check |
| `--only CHECK` | all checks | Run only the named check. Repeat the flag or comma-separate the names for more than one |

A check left out by `--only` or `--skip-build` is still listed, as `SKIPPED` with the reason. A run
that left checks out ends with `READY (partial run ...)` and reports `"partial": true` in JSON. A
partial run is never a release-ready verdict.

#### Exit codes

| Code | Meaning |
|------|---------|
| `0` | Every check that ran passed |
| `1` | At least one check failed. The summary line names them: `NOT READY: check(s) failed: ...` |
| `4` | No check failed, but at least one timed out: `NOT READY: check(s) timed out: ...`. Re-run with a larger `--timeout` |
| `2` | Bad arguments, such as an unknown `--only` name or a non-positive `--timeout` |

#### `--json` report shape

```json
{
  "ok": true,
  "partial": false,
  "selected": ["version-lockstep", "doc-pins", "pypi-readme-safe", "docs-model-names", "build", "keyring-trap"],
  "failed": [],
  "timedOut": [],
  "durationSeconds": 314.9,
  "findings": [
    {"id": "build", "ok": true, "skipped": false, "timedOut": false, "durationSeconds": 146.6,
     "detail": "build + twine check passed (2 artifact(s): ...)"}
  ]
}
```

#### Examples

```bash
mso release preflight                                  # full report, about five minutes
mso release preflight --json > preflight.json          # progress on stderr, report on stdout
mso release preflight --skip-build                     # quicker look; a partial run
mso release preflight --only version-lockstep,doc-pins # a few seconds
mso release preflight --timeout 1800                   # slow machine: allow 30 minutes per check
```

### `mso release cut`

`mso release cut VERSION` previews the version bump. Add `--execute` to write `maestro/__init__.py`
and `pyproject.toml` and try to open the release PR. It never tags or publishes. The remaining
commands are printed for you to run after review.

---

## mso settings

Read and write Maestro settings: workspace and device.

```
mso settings [--project ACRONYM] list  [--device] [--json]
mso settings [--project ACRONYM] get   KEY [--device] [--json]
mso settings [--project ACRONYM] set   KEY VALUE [--device]
mso settings [--project ACRONYM] unset KEY [--device]
```

Every value is printed with its source. Precedence: env var (for keys that
declare one) > signed policy bundle > `workspace.json` >
`~/.maestro/config/settings.json` > built-in default. `--device` reads and
writes the device file only. Refusals exit `1`.

The full key list and the two files are documented in [SETTINGS.md](SETTINGS.md).

```bash
mso settings list
mso settings set dispatch.maxCrews 3
mso settings set models.BLD.model claude-opus-5
mso settings set --device spawnMonitor false
```

---

## mso setup

Run the interactive setup wizard, or perform a headless prerequisite check.

```
mso setup [--check [--smoke] [--json]] [--repair] [--show SECTION]
          [--list-steps [--json]] [--new | --only KEY[,KEY]]
          [--gui [--no-browser] [--port N]]
          [--profile PATH_OR_URL] [--non-interactive] [--answers FILE]
```

The setup wizard runs three phases:

1. **Prerequisites** — Python version, Claude Code CLI, `ANTHROPIC_API_KEY`, Git, network reachability
2. **Project analysis** — scans the registered project for language, structure, CI config, and existing tooling
3. **Tailored suggestions** — prints recommended starting requirements and voyages based on your project

`setup` bypasses the standard auth check so new users can run it before activating a licence.

### Flags

| Flag | Type | Default | Description |
|------|------|---------|-------------|
| `--check` | flag | `false` | Run Phase 1 only. Exits `0` if all checks pass, `1` if any fail. No interactive output. Makes no model call and needs no Claude credentials. |
| `--smoke` | flag | `false` | With `--check`: also verify Claude sign-in with one short live Claude call. It uses your Claude credentials and counts as usage. |
| `--json` | flag | `false` | JSON output, with `--check` or `--list-steps`. |
| `--repair` | flag | `false` | Detect and automatically repair repairable issues. |
| `--show SECTION` | string | — | Read-only view of one section: `prereqs`, `project`, `workspace`, `templates`, `persona`. |
| `--list-steps` | flag | `false` | Read-only: every setup step that applies to this workspace, whether it is recorded or pending, and why. Writes nothing. Exits `0` even with pending steps; `1` outside a workspace or on an unreadable setup record. |
| `--new` | flag | `false` | Run only the pending steps (new since your last setup, revised, newly applicable, never answered, or — team/enterprise — enrolment profile changed), plus the prerequisite checks and next steps. |
| `--only KEY[,KEY]` | string, repeatable | — | Run exactly the named steps (keys as shown by `--list-steps`). An unknown key, or one that does not apply to this workspace, exits `2` naming the valid keys. Cannot be combined with `--new`. |
| `--gui` | flag | `false` | Run the same wizard in your browser, on a one-time page served on `127.0.0.1` only. Needs no extra install. A completed run exits with `--check`'s code; cancel or Ctrl+C exits `130`; the 15-minute idle timeout exits `124`. Cannot be combined with `--non-interactive` / `--answers` (exit `2`). |
| `--no-browser` | flag | `false` | With `--gui`: print the one-time link instead of opening a browser. |
| `--port N` | integer | free port | With `--gui`: listen on `127.0.0.1:N` (1–65535), e.g. for an `ssh -L` forward. `--no-browser` / `--port` without `--gui` exit `2`. |
| `--profile PATH_OR_URL` | string | — | Explicit enrolment profile (highest precedence; ignored at community). |
| `--non-interactive` | flag | `false` | Never prompt; fail naming the missing key instead of asking. |
| `--answers FILE` | string | — | Flat `KEY=VALUE` answers file for `--non-interactive`. |

`--new`, `--only` and `--gui` combine with each other as described in
[SETUP.md § Running setup again](SETUP.md#running-setup-again) and
[§ Setup in your browser](SETUP.md#setup-in-your-browser---gui). Each run records which steps it
went through — outcomes only, never your answers — in the setup record described in
[SETUP.md § The setup record](SETUP.md#the-setup-record).

### Examples

```bash
# Full interactive wizard
mso setup

# Headless prerequisite check (CI/CD, scripting)
mso setup --check

# What has this workspace been through, and what is pending?
mso setup --list-steps

# After an upgrade: run only the new / revised / never-answered steps
mso setup --new

# Change one answer
mso setup --only budget

# The same wizard in a browser; over SSH, print the link and forward a fixed port
mso setup --gui
mso setup --gui --no-browser --port 8765
```

### Phase 1 — Prerequisite checks

| Check | Pass condition |
|-------|---------------|
| Python | 3.9 or later |
| Claude Code | `claude` on PATH and responds to `--version` |
| API key | `ANTHROPIC_API_KEY` set and non-empty |
| Git | `git` on PATH |
| Network | Can reach `api.anthropic.com` (optional — warns if offline) |

---

## mso projects

List or remove projects. Two different lists share the word "project":

- the **home registry** — the *workspaces* on this machine, added by `mso init`;
- a workspace's **`config/projects.json`** — the *repositories* that one workspace dispatches to,
  added in the `[PROJECTS]` step of `mso setup`.

```
mso projects list
mso projects remove ACRONYM
mso projects remove --from-workspace PROJECT [--new-default PROJECT]
```

| Action / flag | Description |
|---|---|
| `list` | Show every registered workspace on this machine, with its path. |
| `remove ACRONYM` | Unregister a workspace from this machine. Deletes nothing on disk, and prints what remains (`<workspace>/.mso`) for you to delete yourself. Refused while that workspace's dispatcher is running. |
| `remove --from-workspace PROJECT` | Remove `PROJECT` from **this** workspace's `config/projects.json`. |
| `--new-default PROJECT` | With `--from-workspace`: the project that becomes the default when you remove the default project. Required in that case; the last project cannot be removed. |

**`--from-workspace` is refused while the project has live work**, naming every reason:
`live-dispatcher` (the workspace's dispatcher is running), `live-order` (an order for the project
is pending, open, awaiting review or in progress), `active-voyage`, or `worktree` (one of its
voyages' worktrees is still on disk). Tidy up with `mso pause --wait`, `mso voyage reconcile` or
`mso cleanup`, then retry. There is no `--force`.

**Neither removal deletes history.** `--from-workspace` removes only the project's two config
entries (`projects.<P>` in `config/projects.json` and `config/projects/<P>.json`); orders,
voyages, reports, usage records and worktrees stay. Full detail:
[SETUP.md § Workspace projects](SETUP.md#workspace-projects).

```bash
mso projects list
mso projects remove PSG
mso projects remove --from-workspace PSG
mso projects remove --from-workspace MSO --new-default PSG
```

---

## mso licence

Manage the Maestro licence key for this machine.

```
mso licence <subcommand> [KEY]
```

### Subcommands

| Subcommand | Description |
|-----------|-------------|
| `activate <KEY>` | Parse, validate, and save a licence key to `~/.mso/licence.json`. |
| `status` | Show current licence mode: licence key, GitHub collaborator, or trial. |
| `deactivate` | Remove the stored licence key and free this machine's seat. |

This command is always available regardless of licence state — including after trial expiry.

`mso licence revalidate` (an online re-check) is refused with exit `2` while any workspace on this machine is in offline mode; `mso licence status` stays available. See [OFFLINE.md § Licence advice](OFFLINE.md#licence-advice-for-offline-use).

### mso licence activate

```bash
mso licence activate ADM-TEAM-a1b2c3d4-20270331-x9y8z7
```

Validates the key format and HMAC checksum locally (no server call). On success, saves the key to `~/.mso/licence.json`. For Team and Enterprise keys, registers this machine as a seat.

**Output (Team tier):**

```
[Maestro] Licence activated.
  Tier:         Team
  Expires:      2027-03-31 (365 days)
  Max crews:    5
  Max projects: Unlimited
  Features:     dispatch, status, usage, backup, estimate, approve, roi-reporting, priority-support
  Seat:         Registered (machine: abc123def456)
```

### mso licence status

```bash
mso licence status
```

**Output (licence key active — Team tier):**

```
[Maestro Licence]
  Mode:           Licence key
  Tier:           Team
  Expires:        2027-03-31 (365 days)
  Max crews:      5
  Max projects:   Unlimited
  Features:       dispatch, status, usage, backup, estimate, approve, roi-reporting, priority-support
  Seat:           Registered (machine: abc123def456, since 2026-04-01)
  Last validated: 2026-04-01
```

**Output (Enterprise tier):** Includes an additional SSO line:

```
  SSO:            Placeholder (open a GitHub Issue to configure)
```

**Output (GitHub collaborator):**

```
[Maestro Licence]
  Mode:    GitHub collaborator
  User:    your-github-username
  Access:  Contributor (unlimited)
  Note:    Licence key recommended for commercial use
```

**Output (trial mode):**

```
[Maestro Trial]
  Days remaining: 11/14
  Max crews:      3
  Max projects:   1
  To upgrade:     https://maestroai.com/pricing
```

### mso licence deactivate

```bash
mso licence deactivate
```

Removes `~/.mso/licence.json`. The machine will fall back to trial mode (or GitHub auth) on the next command.

**Output:**

```
[Maestro] Licence deactivated. Seat freed.
Machine will enter trial mode (or GitHub auth) on next command.
```

### Key format

Licence keys follow the format:

```
ADM-{TIER}-{ORG_HASH}-{EXPIRY}-{CHECKSUM}
```

| Component | Description |
|-----------|-------------|
| `TIER` | `TRIAL`, `SOLO`, `TEAM`, or `ENT` |
| `ORG_HASH` | 8 hex characters (organisation identifier, or `00000000` for Solo) |
| `EXPIRY` | `YYYYMMDD` — key expiry date |
| `CHECKSUM` | 6 alphanumeric characters (HMAC-SHA256 local validation) |

Example: `ADM-TEAM-a1b2c3d4-20270331-x9y8z7`

Validation is performed locally using an embedded HMAC — no network call is required.

---

## mso version

Print the installed Maestro version.

```
mso version
```

### Example

```bash
mso version
# Maestro Maestro v2.0.0
```

---

## Global Flags

These flags are accepted by every `mso` subcommand.

| Flag | Description |
|------|-------------|
| `--debug` | Show full tracebacks on unexpected errors. Also sets `MAESTRO_DEBUG=1` in child processes. Equivalent to running with `MAESTRO_DEBUG=1 mso ...`. |

---

## Exit Codes

| Code | Meaning |
|------|---------|
| `0` | Success |
| `1` | General error — configuration problem, licence issue, or unexpected runtime error |
| `2` | Usage / argument error — mistyped subcommand, wrong flags, ambiguous input. Also: a network-only command refused because offline mode is on (`mso pr …`, `mso runtime update`, `mso licence revalidate`) — see [OFFLINE.md](OFFLINE.md) |
| `3` | No work — command ran cleanly but nothing to do (empty queue, no matching data) |
| `4` | `mso release preflight` only: no check failed, but one timed out |
| `130` | Interrupted — `Ctrl+C` at the top-level `mso` process |

For the full error taxonomy, debug mode reference, and did-you-mean behaviour, see [CLI-ERRORS.md](CLI-ERRORS.md).

---

## Environment Variables

These variables are injected by the Fleet Admiral into crew subprocesses. They are documented here for reference when debugging.

| Variable | Description |
|----------|-------------|
| `ANTHROPIC_API_KEY` | Required. Your Anthropic API key. Set in your shell profile. |
| `MAESTRO_LICENCE_KEY` | Licence key override. When set, takes precedence over `~/.mso/licence.json`. Suitable for CI/CD deployments. |
| `MAESTRO_CREW` | Crew number (1–5). Activates hook behaviour. Must not be set in interactive sessions. |
| `MAESTRO_ORDER` | Current order ID. |
| `MAESTRO_PROJECT` | Project acronym (e.g. `MYPROJ`, `ADM`). |
| `MAESTRO_REPO_PATH` | Managed repo clone path — the crew's working directory. |
| `MAESTRO_TEMP` | Centralized temp directory for crew-generated artifacts. |
| `MAESTRO_VOYAGE_BRANCH` | Voyage branch name used when committing crew output. |
| `MAESTRO_MAX_ITERATIONS` | Maximum stop-hook iterations before a crew is forcefully completed. Default: `25`. |
| `MAESTRO_COMPLETION_PROMISE` | Promise tag pattern the crew uses to signal task completion. |
| `MAESTRO_DEBUG` | Set to `1` to enable full traceback output for unexpected errors. Equivalent to passing `--debug`. Propagated to child processes by the CLI. |

---

*Maestro Maestro v2.0.0 — For licensing enquiries, contact [tavisbasing](https://github.com/tavisbasing).*
