# Your first hour — from `pip install` to the first dispatch

This page takes you from an empty machine to a fleet working on **your own
repository**, at whichever licence tier you are on. It is one path with six
steps. Where a step differs by tier, the difference is called out in place.

Want to watch Maestro work before pointing it at your code? `mso quickstart`
runs a throwaway demo instead ([QUICKSTART.md](QUICKSTART.md)). Come back here
when you want the real thing.

| Step | Command | Community | Pro | Team | Enterprise |
|------|---------|:---------:|:---:|:----:|:----------:|
| 1. Install | `pip install maestro-fleet` | ✓ | ✓ | ✓ | ✓ |
| 2. Activate a licence | `mso licence activate <KEY>` | **skip** | ✓ | ✓ | ✓ |
| 3. Scaffold the workspace | `mso init --project ACR` | ✓ | ✓ | ✓ | ✓ |
| 4. Run the wizard | `mso setup` (or `mso setup --gui`) | ✓ | ✓ + extra steps | ✓ + extra steps | ✓ + extra steps |
| 5. Confirm a dispatch would start | `mso setup --check` | ✓ | ✓ | ✓ | ✓ |
| 6. Queue work and dispatch | `mso order create …` then `mso dispatch` | ✓ | ✓ | ✓ | ✓ |

Not sure which tier you are on? If you have no licence key, you are on
**community**: free, permanent, and not a trial. [START-HERE.md](START-HERE.md)
explains the tiers.

---

## Before you start

You need these on the machine, at every tier:

| Need | Check it with |
|------|---------------|
| Python 3.11 or newer | `python --version` |
| git | `git --version` |
| Claude Code CLI | `claude --version` |
| GitHub CLI, logged in | `gh auth status` |
| A git repository for your project, with an `origin` on GitHub | `git remote -v` |

Crews call Claude through Claude Code. Either sign Claude Code in to your
subscription, or set an API key from
[console.anthropic.com](https://console.anthropic.com/settings/keys):

```bash
export ANTHROPIC_API_KEY=sk-ant-...          # macOS / Linux / WSL
```

```powershell
$env:ANTHROPIC_API_KEY = "sk-ant-..."        # Windows PowerShell
```

You do not have to get any of this right first time. Step 4 checks every item
and tells you what is missing.

---

## 1. Install

```bash
pip install maestro-fleet
mso version
```

`mso version` prints `Maestro vX.Y.Z`. If the shell cannot find `mso`, see
[QUICKSTART.md § Troubleshooting](QUICKSTART.md#troubleshooting).
[INSTALL-UPGRADE-UNINSTALL.md](INSTALL-UPGRADE-UNINSTALL.md) covers virtual
environments, upgrades and air-gapped installs.

---

## 2. Activate a licence — pro, team and enterprise only

**Community: skip this step.** Nothing in Maestro asks you for a licence, and
`mso licence status` says so:

```text
No licence activated — running at community tier (this is not an error).
```

**Pro, team, enterprise:**

```bash
mso licence activate <KEY>
mso licence status
```

`mso licence status` should print your tier on its `Tier:` line. Activation
needs the internet once. It is held in **this user account's** OS keychain. On
a second machine, or under another user account, run `mso licence activate`
there as well. A copied licence file is refused.
Full reference: [LICENCE.md](LICENCE.md).

---

## 3. Scaffold the workspace

From the root of your project's repository:

```bash
cd path/to/your-repo
mso init --project ACR
```

`ACR` stands for your project's acronym: a short upper-case name. It prefixes
every order and voyage id, so `FTR-ACR-2026-0002` is a feature order in project
`ACR`. Use the same acronym in every command that follows.

`mso init` creates a `.mso/` directory and a `CLAUDE.md`, and registers the
project on this machine. When it finishes, it prints:

- **Next steps.** Step 1 is `mso setup`, which is the next section here.
- **The exact undo**: `mso projects remove ACR`, followed by the files and
  directory to delete. Keep that text if you are only trying Maestro out.

**Community** registers **one** project. A second, different acronym is
refused. Re-running `init` for the same acronym is always allowed.

---

## 4. Run the wizard

```bash
mso setup
```

The wizard checks the machine, looks at your repository, and then asks
questions. Every answer is written into the workspace for you, and none of them
needs a hand edit afterwards. Wherever it offers a default, pressing Enter
accepts it.

**Prefer a browser?** `mso setup --gui` runs the same wizard — the same steps
and questions — on a one-time local page (`127.0.0.1` only) and opens it for
you. Over SSH, add `--no-browser --port 8765` and it prints the link and the
`ssh -L` forward to use. See [SETUP.md § Setup in your browser](SETUP.md#setup-in-your-browser---gui).

### Steps every tier sees

| Step | What it does |
|------|--------------|
| 0 — Persona | Picks the vocabulary the CLI uses. Under the default persona the product is called "Maestro". The docs and website always say "Maestro", whatever you choose. See [PERSONAS.md](PERSONAS.md). |
| 1 — Prerequisite checks | The table in [Before you start](#before-you-start), plus your workspace and repository settings. |
| 2 — Project analysis | Language, tests, CI and docs it found. The analysis feeds the suggestions in step 5. |
| 2a — SDLC providers | Your git host, CI and issue tracker. See [PROVIDERS.md](PROVIDERS.md). |
| 2b — Model backend | Where crews' Claude sessions run. The direct Anthropic API is the default. |
| 2c — Source repository | The `org/repo` crews push to. It is checked against your `origin`, and the wizard **asks** before creating anything. |
| 3 — Workspace configuration | Writes the organisation and repository into the workspace, then checks that nothing is left as a placeholder. Until this passes, `mso dispatch` refuses to start. |
| 3a — Division pack | The delivery process. `sdlc`, the default, is right for most software projects. See [DIVISION-PACKS.md](DIVISION-PACKS.md). |
| 3b — Spend cap | An optional ceiling in US dollars on what this workspace spends on crews. Blank means no cap. See [the caveats below](#a-word-on-the-spend-cap). |
| 3c — Plan-review gate | *"Do you want a human to approve plans before building starts?"* Yes means a finished plan waits for `mso review approve <ORDER-ID>` before anything is built. |
| 3d — Monitor window | Whether `mso dispatch` opens a terminal monitor window. This is a setting for **this machine**, so it applies to every workspace on it. |
| Projects | The repositories this workspace dispatches to. Add, edit or remove one, or press Enter to keep them as they are. See [SETUP.md § Workspace projects](SETUP.md#workspace-projects). |
| 4 — Requirement templates | Starter orders. Templates that need roles your workspace does not run are not offered. |
| 5 — Suggested next steps | What to do next, based on the analysis in step 2. |

[SETTINGS.md § What `mso setup` writes](SETTINGS.md#what-mso-setup-writes)
lists the file each of steps 3b, 3c and 3d writes, and how to change your
answer later.

### Extra steps by tier

**Community.** The wizard shows one more section, **What this workspace runs**:

```text
This workspace runs up to 2 concurrent crews, 1 registered project, and the roles PLN, BLD, TST.
```

It also sets `dispatch.maxCrews` to `2`. The Hub step says it is skipped, and
`mso status` shows the same fleet in the terminal.

**Pro** adds:

| Section | What it does |
|---------|--------------|
| Licence | Your tier and expiry, and the `mso licence activate <key>` line for another machine. |
| Resident LEAD | A background agent that watches the workspace between your sessions. The wizard **does not start it**. That is your decision, and you make it with `mso lead start`. |
| Chart authoring | `mso chart new --from-voyage <VOY-ID>` turns a voyage into a schedulable graph. See [CHARTS.md](CHARTS.md). |
| Enrolment profile | Reports whether your organisation has supplied a setup profile. Without one, this is core setup only. |

**Team** adds everything pro has, plus:

| Section | What it does |
|---------|--------------|
| Maestro Hub | The web dashboard. When you want it, run `mso hub setup` and then `mso hub start`, which serves `http://127.0.0.1:3847`. See [HUB.md](HUB.md). |
| Artefact plane | Where orders, plans and reports live: `embedded` (in `.mso/`, the default), `solo` or `shared`. **If more than one machine writes the plane, it must be `shared`.** Preview a move with `mso migrate artefact-repo --dry-run`. See [ARTEFACT-REPO.md](ARTEFACT-REPO.md). |

**Enterprise** adds everything team has, plus:

| Section | What it does |
|---------|--------------|
| Model backend (step 2b) | AWS Bedrock is offered alongside the direct API. Below enterprise, step 2b says that Bedrock is not available. See [MODEL-BACKENDS.md](MODEL-BACKENDS.md). |
| Governance mode | Without an enrolment profile the device is **ungoverned**, and the wizard says so. It names the commands that change that: `mso policy pull` and `mso policy enable --mode warn` (or `--mode enforce`). See [GOVERNANCE-TRUST-BOUNDARY.md](GOVERNANCE-TRUST-BOUNDARY.md). |
| Identity bootstrap | Initialises the workspace's identity store. Add people with `mso identity add-user --email <email> --display-name <name>`. |
| Audit anchor provider | Where the audit log's root hash is copied, so that tampering is detectable. See [ENTERPRISE-SETUP.md](ENTERPRISE-SETUP.md). |

The wizard does **not** write a signed enrolment profile. Your organisation's
admin does that; see [ENTERPRISE-ADMIN-GUIDE.md](ENTERPRISE-ADMIN-GUIDE.md).

### Unattended: the same setup from an answers file

For CI or a scripted machine image, put the answers in a file and run without
prompts. Replace the organisation, repository and acronym with your own:

```text
# answers.txt — one key=value per line
workspace.project=ACR
workspace.defaultGitHubOrg=acme
workspace.repo=acme/acme-app
workspace.defaultBranch=main
providers.scm=github
providers.ci=none
providers.issues=none
providers.model=anthropic
budget.maxUsd=25
gates.post_nav_review.enabled=yes
spawnMonitor=no
```

```bash
mso setup --non-interactive --answers answers.txt
```

The first eight keys are all that a workspace needs, at any tier, for step 5
to pass. The last three are optional. If you leave a key out, its current value
is kept. A malformed value makes the run exit `1` and names the key.

A step none of whose keys are in the file is recorded as *never answered* and
stays pending, so `mso setup --list-steps` and `mso doctor` keep reminding you
of it. A browser run (`mso setup --gui`) offers its answers as a file you can
replay this way.

### Running the wizard again

Re-running `mso setup` with the same answers changes nothing. You rarely need
the whole wizard again, though:

```bash
mso setup --list-steps     # every step, done or pending, and why
mso setup --new            # only the pending ones (e.g. new in a release you just installed)
mso setup --only budget    # exactly one step, to change one answer
```

`mso update` tells you when a release adds setup steps, and `mso doctor`
reports them too. Neither runs the wizard for you. See
[SETUP.md § Running setup again](SETUP.md#running-setup-again).

---

## 5. Confirm a dispatch would start

```bash
mso setup --check
```

This check costs nothing and starts nothing. It makes no model call, writes no
file, and does not need your Claude credentials. That also means it does not
prove that Claude is signed in. To check that as well, add `--smoke`:

```bash
mso setup --check --smoke
```

`--smoke` makes one short live Claude call. It uses your Claude credentials and
counts as usage. Without it, the `claude_smoke` row says that sign-in was not
verified. On success a plain `--check` ends with:

```text
[Maestro] setup --check: 13 check(s) passed — a dispatch would start once Claude is signed in (not verified; add --smoke to check).
  Next:
    1. mso order create "<what to build>" --type FTR --project ACR
    2. mso dispatch --max-crews 2
    3. mso status
```

The suggested `--max-crews` is your workspace's own limit: `2` on community and
`5` otherwise. The exit code is `0` when everything passes, `1` when something
fails, and `2` when there are only warnings. On a non-zero exit it prints only
what to fix. Fix it, or re-run `mso setup`, and check again.

---

## 6. Queue work and dispatch

Work is organised as **orders** (one piece of work) grouped into a **voyage**
(one branch and one pull request). Create a voyage, then an order in it:

```bash
mso voyage create "First voyage" --project ACR
mso order create "Add a health-check endpoint" --type FTR --project ACR --voyage VOY-ACR-2026-0001 --role-sequence PLN,BLD,TST
```

Use the voyage id that `mso voyage create` printed. `VOY-ACR-2026-0001` is the
id of the first voyage in a new workspace. `--role-sequence PLN,BLD,TST` means
the order is planned, then built, then tested. That sequence runs at every
tier. On community, keep to those three roles, because `SEC`, `DOC` and `REL`
are not available there. See [ROLES-GUIDE.md](ROLES-GUIDE.md).

Then start the fleet and watch it:

```bash
mso dispatch --max-crews 2
mso status
```

**`mso dispatch` is the first command that spends money.** From this point on,
crews call Claude. If you set a spend cap in step 3b, it is now active.

If you switched the plan-review gate on in step 3c, the order stops after
planning and waits for you:

```bash
mso review queue
mso review approve <ORDER-ID>
```

The dispatcher opens a draft pull request for the voyage. When the voyage's
last order completes, it marks the PR ready for review. You review and merge it. [ORDERS-AND-VOYAGES.md](ORDERS-AND-VOYAGES.md) covers
the rest of the lifecycle.

---

## A word on the spend cap

If you set `budget.maxUsd`, know what it promises before you rely on it.
[SETTINGS.md § Spend cap](SETTINGS.md#spend-cap-budget) has the details:

- **It is checked between crew iterations, never in the middle of one.** When
  the ceiling is crossed, no new crew starts, and crews already running finish.
  You can therefore end up over the ceiling by what those crews spend. Nothing
  is killed.
- **It never guesses silently.** On a backend whose usage Maestro cannot
  price (for example Bedrock without your own rates), the cap logs
  `BUDGET_BASIS_UNPRICED`. With `budget.onReach` at `pause` (the default), it
  then holds dispatch and drains. With `warn`, it keeps dispatching.
- **It is one ceiling per workspace.** There is no per-voyage or per-order cap.

`mso usage --summary` shows the estimated spend so far.

---

## If something goes wrong

| Symptom | Do this |
|---------|---------|
| `mso setup --check` exits non-zero | Read what it printed, because it lists only what to fix. Fix it, or re-run `mso setup`. |
| `mso dispatch` refuses to start | It names the reason. `mso setup --check` usually names the same one first. |
| A crew is not making progress | `mso status`, then [WHEN-A-VOYAGE-IS-STUCK.md](WHEN-A-VOYAGE-IS-STUCK.md). |
| You want a health check of the whole fleet | `mso doctor`. Findings about the machine rather than this workspace are listed under their own *machine-wide (not this workspace)* heading. |
| You want to stop safely | `mso pause` lets running crews finish and then stops. `mso resume` starts again. |
| You want to undo the whole thing | Run the undo that `mso init` printed: `mso projects remove ACR`, then delete what it lists. |
| `mso projects remove` is refused | Work is still live: a running dispatcher, an open order, an active voyage or a leftover worktree. It names which. Finish or tidy that up first (`mso pause --wait`, `mso voyage reconcile`, `mso cleanup`). Removal never deletes orders, voyages or reports. |
| `mso doctor` reports `config.setup-steps-pending` | A release added or revised a setup step, or one was never answered. `mso setup --new` runs just those. |

More help: [TROUBLESHOOTING.md](TROUBLESHOOTING.md) · [SETUP.md](SETUP.md) ·
[CLI-REFERENCE.md](CLI-REFERENCE.md) · [SUPPORT.md](SUPPORT.md)
