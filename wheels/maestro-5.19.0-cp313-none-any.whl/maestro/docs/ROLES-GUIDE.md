# Roles Guide

Maestro assigns each unit of work to a **role**. The role determines which Claude model runs, what files the crew can read and write, and what commands it can execute.

Understanding roles helps you assign orders correctly and get consistent, high-quality output from your fleet.

---

## Contents

- [Role Overview](#role-overview)
- [Customising for your organisation](#customising-for-your-organisation)
- [Navigator / Planner (NAV / PLN)](#navigator-nav)
- [Shipwright / Builder (SHP / BLD)](#shipwright-shp)
- [Bosun / Tester (BOS / TST)](#bosun-bos)
- [Scribe / Documenter (SCR / DOC)](#scribe-scr)
- [Lookout / Security Auditor (LKT / SEC)](#lookout-lkt)
- [Coxswain / Releaser (COX / REL)](#coxswain-cox)
- [Choosing the Right Role](#choosing-the-right-role)
- [Role Handoffs](#role-handoffs)

---

## Role Overview

| Role | Canonical code | Nautical alias | Default model | Responsibility |
|------|---------------|---------------|---------------|---------------|
| Planner | PLN | NAV (Navigator) | Opus 5.5 | Planning & architecture |
| Builder | BLD | SHP (Shipwright) | Sonnet 5.5 | Development & implementation |
| Tester | TST | BOS (Bosun) | Sonnet 5.5 | QA & testing |
| Documenter | DOC | SCR (Scribe) | Sonnet 5.5 | Documentation |
| Security Auditor | SEC | LKT (Lookout) | Sonnet 5.5 | Security & investigation |
| Releaser | REL | COX (Coxswain) | Opus 5.5 | Integration & deployment |

Both the canonical codes (`PLN`, `BLD`, `TST`, `DOC`, `SEC`, `REL`) and the nautical aliases (`NAV`, `SHP`, `BOS`, `SCR`, `LKT`, `COX`) are accepted wherever a role code is used.

**Model rationale:** high-stakes × low-volume gets Opus. The Planner and Releaser run on Opus 5.5 — they run infrequently, but a plan or a release decision propagates to everything downstream. Sonnet 5.5 handles the high-volume production roles (BLD, TST, DOC) and the Security Auditor (SEC).

**Available models:** Fable 5.1, Fable 5, Opus 5.5, Opus 5, Sonnet 5.5, Sonnet 5 and Haiku 5.5, plus the previous generation, still supported (Opus 4.8, Opus 4.7, Opus 4.6, Sonnet 4.6, Haiku 4.5). Every role's model is a default, not a fixed assignment — override it per order (the order's `model` field) or per role (a role overlay); see [CONFIG-MODELS.md](CONFIG-MODELS.md).

**Community tier:** dispatching an order is limited to Investigator, Planner, Builder and Tester (`INV`/`PLN`/`BLD`/`TST`). Documenter, Security Auditor and Releaser (`DOC`/`SEC`/`REL`) require a Pro, Team or Enterprise licence — an order whose role sequence includes one of these is refused with a licence message naming the tier, before any crew work is spent on it. See [LICENCE.md](LICENCE.md#tier-limits-enforced-in-code-not-just-advertised) for the full set of enforced tier limits.

---

## Customising for your organisation

All 7 roles can be customised per-organisation without forking the core definitions. See [ROLE-OVERLAYS.md](ROLE-OVERLAYS.md) for the full guide.

Quick reference:

- `mso roles list` — see all roles and which have overlays applied
- `mso roles show TST` — see the effective merged config for a role
- Edit `.mso/config/roles/{CODE}.md` to layer org-specific extensions
- `mso roles validate` to check your overlay parses correctly
- `mso roles diff TST` to preview exactly what your overlay changed

---

## Navigator (NAV)

**What it does:** The Navigator analyses the codebase and order requirements, then produces a structured implementation plan. It does not write production code — its output is a plan document that guides the Shipwright.

**When to use it:** Before any significant development order. Use a NAV order when:

- The implementation path is not obvious
- Multiple approaches are possible and trade-offs need documenting
- You want the Shipwright to follow a pre-approved plan rather than improvise
- The order spans multiple files or subsystems

**What it reads:** Full codebase, active orders, existing plans, requirements

**What it writes:** Plan documents (`.maestro/plans/`), handoff documents (`.maestro/handoffs/{ORDER-ID}/`)

**What it cannot write:** Source code, tests, documentation files, production directories

**Example order types:** `DOC-MYPROJ-2026-0001` with `"role": "NAV"` to plan a feature before implementation

---

## Shipwright (SHP)

**What it does:** The Shipwright implements the production code. It reads the Navigator's plan (if one exists) or works directly from the order description, then writes source code.

**When to use it:** Any order that involves writing or modifying production source code — new features, bug fixes, refactoring.

**What it reads:** Navigator handoffs and plans, source code, documentation, solution/project files

**What it writes:** Production source code

**What it cannot write:** Test files, documentation, plans, reports

**Example order types:** `FTR-MYPROJ-2026-0001` with `"role": "SHP"` to implement a new feature

---

## Bosun (BOS)

**What it does:** The Bosun writes and runs tests to verify that the Shipwright's code meets the order's acceptance criteria. It reads the implementation and produces test coverage.

**When to use it:** After a Shipwright order, when the order requires test coverage. You can also use the Bosun for standalone testing work — adding missing coverage to existing features, or writing regression tests for known issues.

**What it reads:** Shipwright handoffs, source code, existing tests, solution files

**What it writes:** Test code (in the project's `tests/` directory), QA reports

**What it cannot write:** Production source code, documentation, plans

**Commands it runs:** Build and test commands (e.g. `dotnet test`)

**Example order types:** `FTR-MYPROJ-2026-0002` with `"role": "BOS"` that `dependsOn` the Shipwright order

---

## Scribe (SCR)

**What it does:** The Scribe writes and updates documentation. This includes user guides, API references, architecture documents, changelogs, and any other markdown or documentation content.

**When to use it:** Any order that involves creating or updating documentation — whether for users, developers, or internal stakeholders.

**What it reads:** Handoffs and plans, source code (for understanding what to document), existing documentation

**What it writes:** Documentation files (in the project's `docs/` directory and root markdown files)

**What it cannot write:** Source code, tests, plans, reports

**Example order types:** `DOC-MYPROJ-2026-0001` with `"role": "SCR"` to write a getting started guide

---

## Lookout (LKT)

**What it does:** The Lookout investigates and reports — on security vulnerabilities, dependency issues, code patterns, or anything requiring analysis without code changes. It produces structured investigation and security reports.

**When to use it:** Security audits, dependency scanning, code investigation, root-cause analysis on complex bugs where you want a written report before committing to a fix.

**What it reads:** Full codebase, source code, configuration files, authentication and security subsystems, controllers and middleware, existing reports

**What it writes:** Security reports (`.maestro/reports/security/`), investigation reports (`.maestro/reports/investigation/`)

**What it cannot write:** Source code, tests, documentation, plans

**Commands it runs:** Package vulnerability scans

**Why Sonnet 5.5:** Lookout tasks are read-heavy and produce structured reports. Lookout moved from Haiku 4.5 to Sonnet 5.5 as a capability choice, and it is a cost increase — Sonnet 5.5 is twice Haiku 4.5's per-token price. No benchmark has compared the two for security review. For a cost-sensitive fleet, or to keep the reviewer on a different model from the Shipwright, pin Lookout to Haiku 5.5, the current cheap option: `mso settings set models.SEC.model claude-haiku-5-5`. No benchmark has compared Haiku 5.5 with Sonnet 5.5 for security review either, and Haiku 5.5's price depends on prompt length (from $0.10 / $0.50 per MTok input/output; $0.50 / $2.50 when the prompt is over 100K tokens, cache reads and writes included) — read [CONFIG-MODELS.md](CONFIG-MODELS.md#haiku-55-the-current-cheap-option) before you pin it. Haiku 4.5 is still a valid pin, as a previous-generation model.

**Example order types:** `SEC-MYPROJ-2026-0001` with `"role": "LKT"` to audit authentication endpoints

---

## Coxswain (COX)

**What it does:** The Coxswain is the voyage's completion gate — scoped to the
**whole voyage**, not just the order that invokes it. It gathers every prior
role's handoffs and reports across every order in the voyage, resolves the
voyage's pull/merge request, triages failing CI checks and review threads,
runs the governance and security gates, performs a whole-voyage diff review
(the one class of cross-order defect a per-order test pass can't see), and
produces one completion report ending in a merge **recommendation** — it
never merges, tags, or publishes anything itself. It has the broadest read
access and runs the most commands of any role.

**Provider-neutral by design.** The Coxswain never talks to `gh` or any git
host's API directly — it goes through whichever `scm`/`ci`/`issues`
providers your workspace is configured for (GitHub, or Bitbucket Cloud/Data
Center; GitHub Actions, or Jenkins; GitHub Issues, or Jira), via a small
`mso pr status|checks|ci-log|threads|reply|resolve` command set. The same
completion pass runs unchanged whichever stack you use — configure it with
`mso providers`, `mso setup`, or the Hub's Providers section; see
[PROVIDERS.md](PROVIDERS.md). A capability that isn't configured or isn't
reachable degrades to a named, visible skip in the report — never a silent
pass.

**When to use it:** End-of-voyage integration and completion, or any order
that requires a holistic view of all recent crew work. Two shapes: as the
tail role of an individual order's own role sequence (the default for
feature/bug/security orders), or as a dedicated voyage-level order that the
dispatcher can auto-file once every other order in the voyage completes
(`completion.voyageRel.enabled`) — either way, its scope is every order in
the voyage manifest, not only the one that invoked it.

**What it reads:** Full codebase, all reports, all handoffs, active order
state across the voyage, solution files

**What it writes:** The voyage completion report, order status updates, a
handoff back to the Lead

**What it cannot write:** Source code, tests, documentation, plans

**Commands it runs:** Build/test verification, `mso pr` (provider-backed PR
status/checks/threads/reply/resolve), `mso policy verify --ci`, `mso security
review`, `mso release preflight` (read-only)

**What always stays the Captain's, regardless of provider or how much the
Coxswain automates:**

| Still the Captain's | Never the Coxswain's job |
|---|---|
| Reading the merge recommendation and deciding | The Coxswain writes `READY`/`NOT READY` — it never merges |
| Performing the merge | It records the merge command/URL as text, never executes it |
| Closing review threads opened by a human | Only automated-reviewer threads are the Coxswain's to resolve |
| Deciding when to cut a release, and the tag/publish steps | It may run a read-only release-readiness check, nothing more |
| Moving a linked ticket (GitHub Issues, Jira, etc.) | It reports an issue's state, read-only, never transitions it |

That boundary is structural, not a promise in prose: no provider Maestro
ships exposes a merge, tag, or release method at all, on any git host or CI
system.

**Why Opus 5.5:** Integration and completion are high-stakes and run once per
voyage. The Coxswain uses an Opus-tier model to minimise the risk of missing
a critical issue during final verification. For an exceptionally high-stakes
release you can move it to Fable 5.1 with a role overlay — see
[CONFIG-MODELS.md](CONFIG-MODELS.md).

**Example order types:** `FTR-MYPROJ-2026-0001` with `"role": "COX"` as the
final role in its sequence, or a dedicated voyage-level completion order once
`completion.voyageRel.enabled` is set

---

## Choosing the Right Role

| You want to... | Use role |
|----------------|---------|
| Plan a complex feature before building it | NAV |
| Implement a feature or fix a bug | SHP |
| Write or update tests | BOS |
| Write documentation | SCR |
| Audit for security issues | LKT |
| Investigate a complex bug (report only) | LKT |
| Integrate and verify a completed voyage | COX |
| Deploy to staging or production | COX |

### Common multi-role sequences

**Standard feature development:**
```
NAV (plan)  →  SHP (implement)  →  BOS (test)
```

**Feature with documentation:**
```
NAV (plan)  →  SHP (implement)  →  BOS (test)  →  SCR (docs)
```

**Security-first feature:**
```
LKT (audit existing code)  →  SHP (fix issues)  →  BOS (test fixes)
```

**Voyage close-out:**
```
... (feature orders)  →  COX (integrate + verify)
```

Use the `dependsOn` field in your order JSON to enforce the sequence. See [ORDERS-AND-VOYAGES.md](ORDERS-AND-VOYAGES.md) for details.

---

## Role Handoffs

When one role completes and another role needs to continue the work, the first role leaves a handoff document in `.maestro/handoffs/{ORDER-ID}/`. The naming convention is `{FROM-ROLE}-to-{TO-ROLE}.md` — for example, `NAV-to-SHP.md`.

The downstream role reads this handoff as its primary input, picking up exactly where the previous role left off.

**Handoff content typically includes:**

- Summary of what was done
- Key decisions made and rationale
- What the next role needs to do
- Any risks or open questions

Handoff documents are written automatically by crews when they complete their portion of the work. You do not need to author them manually.

---

*Maestro Maestro v2.0.0 — For licensing enquiries, contact [tavisbasing](https://github.com/tavisbasing).*
