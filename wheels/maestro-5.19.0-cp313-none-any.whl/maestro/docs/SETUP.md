# Maestro — `mso setup` deeper wizard

> The heavier configurator behind `mso quickstart`. Run `mso quickstart` for the friendly first-run; run `mso setup` when you want deeper control — prerequisite validation across 8 checks, fingerprint-based project analysis, 8 built-in requirement templates, contextual next-steps cheatsheet, and a non-interactive `--check` (or full `--non-interactive`) mode for CI and unattended imaging.
>
> **`mso setup` is tier-aware.** It resolves your licence tier once, at the start, and reads it —
> it never sets one. See [START-HERE.md](START-HERE.md) if you're not sure which tier you're on,
> or [§ Tier-aware step registry](#tier-aware-step-registry) below for exactly what changes per
> tier.

## When to use `mso quickstart` vs `mso setup`

| | `mso quickstart` | `mso setup` |
|---|---|---|
| **Audience** | First-time operator on a new machine | Anyone with an existing workspace |
| **Mode** | Demo voyage + dispatch | Audit + configure + analyse |
| **Touches** | Creates demo voyage + orders | Reads/repairs `.mso/config/workspace.json` |
| **CI-friendly** | No | Yes — `mso setup --check` exits 0/1/2/3 |

If you ran `mso quickstart` once already, run `mso setup` next.

## Modes

| Command | Purpose |
|---------|---------|
| `mso setup` | Interactive wizard — step-through prompts; configures `.mso/config/workspace.json` |
| `mso setup --gui` | The same wizard in your browser, on a one-time local page. See [§ Setup in your browser](#setup-in-your-browser---gui). |
| `mso setup --list-steps [--json]` | Read-only: every setup step that applies to this workspace, whether it has been done, and why a step is pending. See [§ Running setup again](#running-setup-again). |
| `mso setup --new` | Run only the pending steps — new since your last setup, revised, newly applicable, or never answered. |
| `mso setup --only KEY[,KEY]` | Run exactly the named step(s), e.g. `mso setup --only budget`. |
| `mso setup --check` | Non-interactive audit — exit 0/1/2/3, no prompts, no model call, no Claude credentials needed |
| `mso setup --check --smoke` | The same audit, plus one short live Claude call to verify sign-in. It uses your Claude credentials and counts as usage. |
| `mso setup --check --json` | Machine-readable JSON output for CI parsing |
| `mso setup --repair` | Auto-fix repairable conditions (workspace.json regen, git init, etc.) |
| `mso setup --show <section>` | Read-only view of one section (`prereqs`, `project`, `workspace`, `templates`, `persona`) |
| `mso setup --non-interactive [--profile P] [--answers FILE]` | Zero prompts — every answer comes from an enrolment profile, an answers file, or a silent default. Fails naming the missing key rather than hanging on stdin. See [ENTERPRISE-ADMIN-GUIDE.md § unattended runbook](ENTERPRISE-ADMIN-GUIDE.md#part-c--unattended--imaging-runbook). |
| `mso setup --profile <PATH_OR_URL>` | Force resolution of a specific enrolment profile, overriding the normal precedence chain (highest precedence — team/enterprise/pro only; ignored at community). |

## 8 prerequisite validators

| # | Validator | What it checks | OK → | WARN → | FAIL → |
|---|-----------|---------------|------|--------|--------|
| 1 | `check_python_version` | `sys.version_info >= (3, 9)` | Python 3.9+ | — | < 3.9 |
| 2 | `check_claude_cli` | `claude --version` responds | found + responsive | found but slow | not found / errored |
| 3 | `check_git` | `git --version` + cwd is a repo | installed + repo | installed, no repo | not installed |
| 4 | `check_gh_cli` | `gh auth status` ok | authenticated | not authenticated | not installed |
| 5 | `check_anthropic_auth` | `ANTHROPIC_API_KEY` env OR `claude` responsive | set / subscription | placeholder-looking | neither |
| 6 | `check_workspace_scaffold` | `.mso/` + valid `workspace.json` | scaffolded + valid | exists but malformed | not scaffolded |
| 7 | `check_repo_config` | `workspace.json` / `projects.json` don't look like unfilled placeholders | looks real (or no workspace yet) | placeholder values left in | — (never fails; worst case is a WARN) |
| 8 | `check_unsigned_acl_manifest` | In a **governed, enforce-mode** workspace with identity records already present, is the manifest a signed envelope? | not governed, or no identity records yet, or manifest is signed | — (never warns) | governed + records exist + manifest missing/unsigned |

All validators have a 10-second timeout to avoid hanging the wizard on broken tools. Validator 8
is a structural shape check only (it does not perform cryptographic verification) and — by
construction — can never fire at community or pro, or in an ungoverned team workspace: it needs
`governedMode == "enforce"` to even run.

### Repairable conditions

`mso setup --repair` will automatically fix:
- `.mso/config/workspace.json` missing or invalid → regenerate from defaults
- `.mso/` directory partially scaffolded → fill in missing dirs

Non-repairable (`--repair` prints remediation only):
- Python < 3.9 — requires system intervention
- Claude Code / Git / `gh` not installed — requires installer
- `ANTHROPIC_API_KEY` env var unset — must be set in parent shell

## Tier-aware step registry

`mso setup` resolves your licence tier exactly once, at entry — read-only; nothing in the wizard
sets, caches, or infers a tier (that's `mso licence activate`'s job alone). Every step is an entry
in an ordered registry with a tier predicate; a step whose predicate excludes your tier simply
never runs, with no partial output and no runtime branch to notice:

| Header | Step | Runs at | What it does |
|---|---|---|---|
| `[STEP 0]` | Persona | every tier | Workstation persona selection. |
| `[STEP 1]` | Prerequisite checks | every tier | The 8 validators above. |
| `[LICENCE]` | Licence | pro / team / enterprise | Shows resolved tier, expiry, and any warning. **Never appears at community** — not shown, not mentioned as absent. |
| `[STEP 2]` | Project analysis | every tier | Language/framework/source-root/test-layout/CI fingerprinting (below). |
| `[STEP 3]` | Workspace configuration | every tier | Can now *write* `workspace.json` (project acronym, default GitHub org) — it used to only offer "go edit it yourself". |
| `[STEP 3a]` | Division pack selection | every tier, **including community** | Selectable packs are the free ones (`sdlc`) plus, at team/enterprise, the five Team-gated packs too — **pro sees the same selectable list as community** (`sdlc` only), since pack gating checks the Team/Enterprise tier set, not "any paid tier". Withheld packs are always *named* ("Also available on Team/Enterprise"), never just dropped. Defaults to `sdlc`, which is byte-identical to a plain `mso init` — a no-op at the default answer for every tier. See [DIVISION-PACKS.md](DIVISION-PACKS.md). |
| `[PROFILE]` | Enrolment profile lookup | pro / team / enterprise | Detects (and, at pro, only detects) an enrolment profile. **Community performs no filesystem or env probe at all** — the precedence chain isn't even consulted. |
| `[ENTERPRISE]` | Enterprise security onboarding | team / enterprise | Only runs anything if a profile actually resolved in the step above — applies workspace/governance/trusted-key settings, configures secrets (+ `mso secrets doctor`), seeds identity if requested. An absent profile means **zero** `governance.*` keys are ever written — never a half-configured state. |
| `[PROJECTS]` | Workspace projects | every tier | Lists the repositories this workspace dispatches to and lets you add, edit or remove one. See [§ Workspace projects](#workspace-projects). |
| `[STEP 4]` | Requirement templates | every tier | Offer to generate a starter order from a template. |
| `[STEP 5]` | Next steps | every tier | Contextual cheatsheet (below). |

**The community guarantee is tested, not conventional:** a community run of `mso setup` (or `mso
setup --non-interactive`) produces **zero** occurrences of the words "licence", "license",
"profile", "enrolment", "trial", or "upgrade" anywhere in its output, and performs no enrolment
lookup of any kind. Full per-tier detail: [START-HERE.md](START-HERE.md#what-actually-changes-per-tier).

Detailed field reference for what an enrolment profile actually contains and how it's authored:
[ENTERPRISE-ADMIN-GUIDE.md § Part B](ENTERPRISE-ADMIN-GUIDE.md#part-b--the-enrolment-profile).

## Running setup again

Re-running `mso setup` is safe. Run again with the same answers, it changes no config file's
content — only the timestamps in the setup record (below) move. You do not have to re-run the
whole wizard, though: after an upgrade, a tier change, or to change one answer, run only the
steps you need.

### See where you stand — `mso setup --list-steps`

```bash
mso setup --list-steps
```

```text
Setup steps: 18 apply to this workspace, 2 pending.

  STEP              SCOPE      STATE       WHY
  persona           device     done
  prereqs           device     done
  ...
  budget            workspace  declined
  projects          workspace  pending     new in 5.18.0
  hub               device     pending     newly applicable to this workspace

Run `mso setup` to go through them.
```

It lists every step that applies to this workspace, whether each is **device** or **workspace**
scope, its recorded state (`done`, `declined`, or `pending`), and why a pending step is pending:

| Reason | Meaning |
|---|---|
| `not yet run` | No run of `mso setup` has recorded this step for this workspace. |
| `never answered` | An unattended run reached the step but had no answer for it (see below). |
| `revised` | A release changed the step's questions enough that you should see it again. |
| `new in X.Y.Z` | The step arrived in release X.Y.Z, after your last setup. |
| `newly applicable to this workspace` | The step did not apply before — for example after a licence upgrade. |
| `enrolment profile changed` | Your organisation's enrolment profile changed since it was applied. Reformatting the profile or reordering its keys is not a change; changing any value is. |

A pending step that was settled before shows `(last: done)` or `(last: declined)` after its
reason. `declined` — you were offered something and said no — counts as settled; it is not
pending.

`--list-steps` writes nothing and exits `0` even when steps are pending. It exits `1` outside a
workspace, or when the setup record cannot be read. `--json` prints the same information as a
stable document (`schemaVersion` `1`) with a `summary` (`applicable`, `pending`) and one entry per
step (`key`, `title`, `scope`, `since`, `revision`, `recorded`, `pending`, `why`).

### Run only what is pending — `mso setup --new`

```bash
mso setup --new
```

Runs the pending steps, plus the prerequisite checks and the next-steps list, which always run.
It prints `Running N pending setup step(s): …` first, or `No setup steps are pending.` A step is
pending when it has never been recorded, its revision was bumped, it was never answered, it
became applicable after a tier change, or (team / enterprise) your enrolment profile changed. A
release that only re-dates a step does **not** re-ask a step you already settled.

### Run exactly one step — `mso setup --only KEY`

```bash
mso setup --only budget
mso setup --only budget,review_gate      # or: --only budget --only review_gate
```

Runs exactly the named steps, in the wizard's normal order, and nothing else (no prerequisite
checks, no next-steps list). This is the easy way to change one answer later. The keys are the
`STEP` column of `--list-steps`. An unknown key, or a step that does not apply to this workspace,
exits `2` before anything runs and lists the keys that do apply.

`--new` and `--only` cannot be combined. Both work with `--non-interactive --answers FILE` and with
`--gui`.

> **Known limitation.** After an `--only` run, a step that is still pending may show its reason as
> `not yet run` rather than `new in X.Y.Z`. Whether it is pending is unaffected.

### The setup record

Each run of the wizard records which steps it went through, in two small files:

| File | Holds | Commit it? |
|---|---|---|
| `.mso/config/setup-state.json` (in your artefact repo if you use one) | **workspace** steps — repository, workspace configuration, budget, review gate, packs, providers, projects, … | **Yes** — commit it with the rest of `config/`, so a teammate who clones the workspace sees which configuration it has been taken through. |
| `~/.maestro/setup-state.json` (`$MAESTRO_HOME`) | **device** steps — persona, prerequisites, Hub, monitor window, … — one entry per workspace on this machine | No — device steps must be run on each machine. |

**The record stores outcomes, never answers.** Each step entry holds only its revision, the
release that introduced it, the outcome (`done`, `declined` or `unanswered`), the Maestro version
that recorded it, and when. Your answers live only in the config files they configure — a second
copy could drift, and could hold something sensitive. The record also notes how the run was made
(`cli`, `gui`, or `baseline` — see `mso update` below).

`mso setup --check` and `mso setup --list-steps` never write the record. A failure to write the
record prints a warning; it never fails setup.

**Unattended runs.** With `--non-interactive --answers FILE`, a step whose answer keys are all
absent from the file is recorded `unanswered` and **stays pending** — so a later `mso setup --new`
or `mso doctor` still tells you about it. An `unanswered` run never overwrites a step you had
already settled.

### How you hear about new setup steps

- **`mso update`** — after a schema update, prints a read-only notice such as
  `3 new setup steps since your last setup: hub, projects, budget - run: mso setup --new`, or
  `This workspace has no setup record yet - run: mso setup`. It never prompts and never starts the
  wizard itself (updates often run unattended).
- **Workspaces set up before the record existed.** On its next schema update, `mso update` seeds a
  *baseline* record for a workspace that has no record and no leftover `mso init` placeholders: the
  steps that existed at the workspace's previous version are recorded `done`, and only newer steps
  show as pending. `--dry-run` shows `WOULD SEED`. If placeholders remain, it prints
  `SKIP setup baseline` — that workspace was never fully set up, and a full `mso setup` is the
  right answer.
- **`mso doctor`** — the low-severity check `config.setup-steps-pending` names every pending step
  and suggests `mso setup --new`. See [PATROL.md](PATROL.md).
- **Dispatch is never blocked** by pending setup steps.

> Until `mso update` has baselined a workspace (on the next schema update after you upgrade),
> `mso doctor` reports `config.setup-steps-pending` on every workspace without a setup record —
> including ones you set up completely before the record existed. `mso setup --new` (or a full
> `mso setup`) clears it.

## Setup in your browser (`--gui`)

```bash
mso setup --gui
```

`--gui` runs **the same wizard** — the same steps, in the same order, with the same validation —
in a local page in your browser instead of the terminal. It needs nothing extra installed, at any
tier.

- **Local and one-time.** The page is served on `127.0.0.1` only (there is no option to listen on
  another address), on a free port. The link that opens carries a one-time key, so only that exact
  link works.
- **One tab.** A second tab opened on the same link sees "already open in another tab". Reloading
  the tab you are using is fine.
- **Lifetime.** The page stops when setup finishes, when you press **Cancel**, when you press
  Ctrl+C in the terminal, or after **15 minutes** with no activity.
- **No licence key in the browser.** The page never asks for a licence key. Activate one in the
  terminal with `mso licence activate <KEY>`.

| Flag | Meaning |
|---|---|
| `--no-browser` | Print the link instead of opening a browser. |
| `--port N` | Listen on `127.0.0.1:N` (1–65535) instead of a free port. |
| `--new` / `--only KEY[,KEY]` / `--profile FILE` | As in the terminal wizard. The page lists the steps this run will take first. |

`--gui` is interactive, so it cannot be combined with `--non-interactive` or `--answers` (exit
`2`). `--no-browser` and `--port` without `--gui` also exit `2`.

**Over SSH.** When you are connected over SSH, no browser is opened. The command prints the
forward to run on your own machine, for example:

```bash
ssh -N -L 8765:127.0.0.1:8765 you@build-host
```

Then open the printed link locally. The forward must use the **same local port number** as the
remote one, so pick a port with `--port` if you want a predictable one:
`mso setup --gui --no-browser --port 8765`.

**The final screen** shows the same rows as `mso setup --check --json` — each check, its status,
its detail and how to fix it — plus the summary line and the next commands.

**Exit codes.** A completed run exits with `mso setup --check`'s code (`0` / `1` / `2`, or `3` if
the checks themselves could not run). Cancel or Ctrl+C exits `130`. The idle timeout exits `124`.
A wizard that crashes exits `3`.

### Replaying a browser run unattended — the answers file

When a browser run finishes, the page shows the run's answers and offers them as a download,
`mso-setup-answers.txt`. Replay it on another machine, or in CI, with:

```bash
mso setup --non-interactive --answers mso-setup-answers.txt
```

For a `--new` or `--only` run, the replay line printed in the file adds `--only <steps>`. The file:

- contains only questions that have an `--answers` key;
- **never** contains a secret answer;
- lists questions that have no key (persona, packs, "Fix them now?", the starter order) as
  comments — they are not replayed;
- is available only after a successful run.

A replayed answers file does not settle the `projects` step; put `projects.*` keys in the file
yourself (see below).

## Workspace projects

Two different lists share the word "project". Keep them apart:

| | The workspaces on this machine | The projects one workspace dispatches to |
|---|---|---|
| **What it is** | The home registry: every workspace `mso init` has created on this machine. | The workspace's `config/projects.json`: the repositories this workspace sends crews to. |
| **See it** | `mso projects list` | the `[PROJECTS]` step of `mso setup` |
| **Add** | `mso init --project ACR` | `mso setup --only projects` (or the full wizard) |
| **Remove** | `mso projects remove ACR` | `mso projects remove --from-workspace ACR`, or the `[PROJECTS]` step |

### The `[PROJECTS]` wizard step

Runs at every tier. It lists the repositories this workspace dispatches to and lets you **add**
one (acronym, repository, default branch, project root), **edit** one, or **remove** one, until
you answer blank (done). Adding or editing changes only that project's entries; every other key
in your config files is left exactly as it was.

Unattended, use these `--answers` keys:

```text
projects.add=WEB
projects.add.repo=acme/acme-web
projects.add.defaultBranch=main
projects.add.projectRoot=.
# projects.edit=P with the same .repo / .defaultBranch / .projectRoot sub-keys
# projects.remove=P, plus projects.remove.newDefault=Q when P is the default
```

A refused change fails the run. To say "keep my projects as they are" in an answers file, write
`projects.add=` with no value. With no `projects.*` key at all, the step is recorded as never
answered, stays pending, and `mso doctor` reports `config.setup-steps-pending`.

### Removing a project

```bash
mso projects remove --from-workspace WEB
mso projects remove --from-workspace ACR --new-default WEB    # ACR is the default project
```

**Removal is refused while the project has live work.** Each reason is named:

| Reason | What it means | Tidy up with |
|---|---|---|
| `live-dispatcher` | The workspace's dispatcher is running (or its PID file cannot be read). | `mso pause --wait` |
| `live-order` | An order for the project is pending, open, waiting for review, or in progress. | finish, skip or remove it (`mso order …`) |
| `active-voyage` | A voyage for the project (or targeting its repository) is still active. | `mso voyage reconcile` |
| `worktree` | A worktree for one of the project's voyages is still on disk. | `mso cleanup` |

There is no `--force`: removing a project with live work is how orders get orphaned.

**Removal deletes configuration only.** A successful removal deletes the project's entry in
`config/projects.json` and its `config/projects/<P>.json` file — nothing else. **Orders, voyages,
reports, usage records and worktrees are never deleted**, so the project's history stays readable.

**The default project.** Removing the workspace's default project needs `--new-default Q`, naming
the project that takes over (it also becomes the workspace's `project`, and its organisation the
`defaultGitHubOrg`). The last remaining project cannot be removed.

**Unregistering a whole workspace** (`mso projects remove ACR`, without `--from-workspace`) is
likewise refused while that workspace's dispatcher is running. It removes the workspace from this
machine's registry only and prints what remains on disk (`<workspace>/.mso`) for you to delete
yourself.

## Project analysis matrix

`mso setup` runs `maestro/project_analysis.py:analyze()` against the current directory. **Fingerprint-only — no recursive scan** — completes in <100ms even on large repos.

| Detector | Signals |
|----------|---------|
| **Language** | `pyproject.toml`/`setup.py`/`requirements.txt` → Python; `tsconfig.json`/`package.json`+TS → TypeScript; `go.mod` → Go; `Cargo.toml` → Rust; `*.csproj`/`*.sln` → C#; `pom.xml`/`build.gradle` → Java |
| **Framework** | `next.config.*` → Next.js; `manage.py` → Django; `fastapi` in deps → FastAPI; `flask` in deps → Flask; `Microsoft.AspNetCore` in `*.csproj` → ASP.NET |
| **Source root** | `src/` > `lib/` > `app/` > `packages/` > `.` (flat) |
| **Test layout** | `tests/`, `test/`, `__tests__/`, `*.test.*`, `*_test.go`, `spec/` |
| **Docs** | `README.md`, `docs/`, `mkdocs.yml`, `docusaurus.config.js`, `_docs/` |
| **Git history** | recent commit timestamp, branch count, CI presence (`.github/workflows/`, `.gitlab-ci.yml`, `Jenkinsfile`, `.circleci/`) |

Result is a `ProjectAnalysis` dataclass with `primary_language`, `secondary_languages`, `framework`, `source_root`, `test_layouts`, `has_readme`, `has_docs_dir`, `has_ci`, `ci_systems`, `recent_activity`, `branch_model`.

## 8 built-in requirement templates

Each template is a Jinja2 markdown file at `maestro/templates/requirements/*.md.j2`. Rendered output is a starter order JSON that operators can dispatch.

| Template | Purpose | Key sections |
|----------|---------|--------------|
| `new-feature` | Propose a new feature | Goal, User story, Acceptance criteria, Out of scope |
| `project-setup` | Initial project configuration | Stack, CI target, Branching strategy, Deployment target |
| `security-review` | Security audit | Threat model, OWASP concerns, Sensitive files, Auth mechanisms |
| `test-coverage` | Test gap analysis | Current coverage, Target %, Untested paths, Test strategy |
| `doc-audit` | Documentation review | Existing docs, Gaps, Target audience, Format |
| `bug-report` | Bug reproduction + fix | Steps to reproduce, Expected vs actual, Environment, Logs |
| `performance` | Performance investigation | Observed latency, Profiling baseline, Hotspot hypothesis, Target |
| `refactor` | Refactoring scope | Current pain points, Target structure, Risk surface, Rollback plan |

Variables injected at render time: `{{ project }}`, `{{ language }}`, `{{ framework }}`, `{{ source_root }}`, `{{ date }}`.

### Custom templates

Drop `.md.j2` files in `.mso/templates/requirements/` to extend the catalogue. Custom templates override built-ins with the same filename. List all available with:

```bash
mso setup --show templates
```

## Contextual cheatsheet (`mso setup` step 5)

After analysis + workspace config, `mso setup` runs `maestro/setup_cheatsheet.py:generate_cheatsheet()` and prints contextual next-steps. Rules include:

- No test layout → suggest `test-coverage` template
- No README + no docs/ → suggest `doc-audit` template
- No CI workflow → suggest scaffolding `.github/workflows/`
- Dormant repo (>180 days quiet) → suggest `project-setup` template
- `gh` not authenticated → walk through `gh auth login`
- Missing `ANTHROPIC_API_KEY` → environment-variable instructions
- Next.js detected → suggest `performance` template if you have measured slowness
- FastAPI detected → suggest `security-review` template early
- Django detected → confirm `manage.py check` + `migrate` in CI

10+ rules total. Heuristic, not exhaustive — treat suggestions as starting points.

## `--check` mode for CI/CD

Designed to be pipeline-friendly:

```bash
mso setup --check || exit 1
```

### Exit codes

| Code | Meaning |
|------|---------|
| 0 | All prereqs OK |
| 1 | Any FAIL |
| 2 | Only WARNs |
| 3 | Internal error (reserved) |

### JSON output

```bash
mso setup --check --json
```

Returns a stable JSON schema:

```json
{
  "prereqs": [
    {"name": "python_version", "status": "OK", "message": "Python 3.11 OK", "remediation": ""},
    {"name": "gh_cli", "status": "WARN", "message": "`gh` installed but not authenticated", "remediation": "Run `gh auth login`."}
  ],
  "exit_code": 2
}
```

### Sample GitHub Actions step

```yaml
- name: Validate Maestro setup
  run: |
    pip install maestro-fleet
    mso setup --check
```

## Operator workflow — typical day

```bash
# Day-1 onboarding to an existing repo
cd <repo>
mso setup                            # interactive wizard — see the tier-aware step registry above

# After config drifts (e.g. workspace.json hand-edited)
mso setup --check                    # quick audit
mso setup --repair                   # auto-fix anything fixable

# Generating starter orders from templates
mso setup                            # prompts you through template selection in step 4

# CI integration
mso setup --check --json | jq .      # parse status programmatically
```
