# Crew reasoning

Maestro can record **why** a crew did what it did. Each crew turn produces a
short note from the model explaining its next step. Maestro stores that note
next to the crew's tool calls and Maestro's own steps, keyed by order. You can
watch it live while the crew works, or read it back after the order is done.

Reasoning capture is **on by default**. It works on every licence tier.

- [What is recorded](#what-is-recorded)
- [It is a summary, not the raw chain of thought](#it-is-a-summary-not-the-raw-chain-of-thought)
- [Requirements](#requirements)
- [Settings](#settings)
- [Where it is stored: `local` or `repo`](#where-it-is-stored-local-or-repo)
- [Redaction and sensitivity](#redaction-and-sensitivity)
- [Reading it from the CLI](#reading-it-from-the-cli)
- [Reading it in the Hub](#reading-it-in-the-hub)
- [Erasure and data-subject requests](#erasure-and-data-subject-requests)
- [Lifecycle log lines](#lifecycle-log-lines)

---

## What is recorded

Every crew iteration writes one file:

```
<artefact root>/reasoning/<ORDER-ID>/<ROLE>-iter<NN>.jsonl
```

The artefact root is the `.mso/` directory in embedded mode, or the artefact
repo in solo/shared mode ([ARTEFACT-REPO.md](ARTEFACT-REPO.md)). Each line in
the file is one JSON record:

| Field | Meaning |
|-------|---------|
| `ts` | When it was recorded, in UTC (`…Z`). |
| `crew` | Crew slot number. |
| `role` | Role code, for example `BLD`. |
| `iteration` | Iteration number within that role's run. |
| `turn` | The model turn the record belongs to. `0` is Maestro's start-of-iteration marker. |
| `source` | Who the record is about. See below. |
| `text` | The text, with secrets redacted. |
| `digest` | A one-line summary of `text`. See below. |
| `imported` | Present only on records added by `mso reasoning import`. Names the old output file the record came from. |

`source` is always one of these three values, and every Maestro view keeps them
apart:

| `source` | What it is | How it is shown |
|----------|------------|-----------------|
| `model` | The model's own reasoning, in its own words. | Quoted, under **Model reasoning**. |
| `tool` | A one-line description of a tool call the crew made, such as `Running: pytest -q` or `Editing cli.py`. Long commands and search patterns are shortened. | Under **Activity**, labelled as a tool call. |
| `maestro` | A step Maestro took, such as "Iteration 2 started: BLD on claude-sonnet-5-5." or "Iteration 2 ended (exit code 0)." | Under **Activity**, labelled as Maestro. |

Model reasoning is never shown as if it were a Maestro step or a tool call, and
the reverse is also true.

**The digest** is made by Maestro, not by the model. It is the first sentence
or clause of the text, cut to 160 characters. It costs nothing and does not call
the model. The same text always gives the same digest.

**Size limits.** A single record's text is cut at 16,000 characters, and the
text then ends with `[... truncated by Maestro]`. One iteration's file stops
growing at 8 MB. Maestro writes a final `maestro` record saying the cap was
reached, and stores nothing more for that iteration.

**Durability.** Each record is written and flushed as soon as it arrives. A crew
that is killed part-way through an iteration leaves every completed line in
place. A re-run of the same iteration adds lines to the file and never truncates
it.

## It is a summary, not the raw chain of thought

The text in a `model` record is what the Claude API returns as **summarised
thinking**. It is a short, first-person account of the model's decisions, for
example "That file isn't there, so I need to search for where the setting is
read." It is **not** the model's complete internal reasoning, and Maestro has no
way to get that.

Maestro stores the summary exactly as the API returns it, apart from
[redaction](#redaction-and-sensitivity). There is one version only: the stored
`text` is the full record, and the `digest` is a shortened view of it.

A summary arrives once per model turn, just before the tool call it explains.
Live views show it as soon as that turn finishes. That can take a few seconds or
up to about a minute.

In Maestro's tests, recording the summary made no measurable difference to cost
or output size.

## Requirements

- **A Claude CLI that accepts `--thinking-display`.** Maestro passes
  `--thinking-display summarized` to each crew. Without that flag the API
  returns thinking blocks with no text. Maestro checks the installed CLI before
  it uses the flag, so an older CLI never gets an option it does not know. Crews
  still run on an older CLI. Their tool calls and Maestro's steps are still
  recorded, but there is almost no model reasoning, and each crew launch logs
  `CLI lacks --thinking-display; crew reasoning text will be mostly empty`.
  Upgrade the Claude CLI to fix it. Verified on CLI 2.1.310 with Opus 5.5 and
  Sonnet 5.5.
- **Claude models only.** A crew that runs on an open-weights endpoint
  ([LOCAL-MODELS.md](LOCAL-MODELS.md)) is not given the flag. Its file holds tool
  calls and Maestro steps, and normally no model reasoning.
- **Amazon Bedrock** uses the same path as the direct Anthropic API, with no
  separate setting and no separate view. Maestro expects Bedrock to return
  reasoning in the same way as the direct API, but this has not yet been checked
  against a live Bedrock model.

## Settings

Both keys are workspace settings ([SETTINGS.md](SETTINGS.md)). Change them with
`mso settings set` or the Hub's settings form.

| Key | Values | Default | What it does |
|-----|--------|---------|--------------|
| `reasoning.enabled` | `true` / `false` | `true` | `false` launches crews without `--thinking-display` and writes no reasoning files. Records already written are kept and can still be read. Takes effect at the next crew iteration. |
| `reasoning.storage` | `local` / `repo` | `local` | Where the files live. See the next section. |

```bash
mso settings set reasoning.enabled false   # stop recording
mso settings set reasoning.storage repo    # commit reasoning to git
```

There are **no retention settings**. Maestro never deletes reasoning files on a
timer. Under `local` storage you delete them yourself. Under `repo` storage
they follow your repository's own policy.

## Where it is stored: `local` or `repo`

| | `local` (default) | `repo` |
|---|---|---|
| In git? | No. `reasoning/` is gitignored. | Yes. Committed to the repository that holds your artefact root. |
| Who can read it | Anyone with access to this machine's workspace folder. | Anyone who can clone that repository. |
| When it is written to git | Never. | Once when each crew run of the order ends, as one commit. Never once per line. In solo/shared mode the commit is pushed with the artefact repo's other bookkeeping. |
| How to delete it | Delete the files or folders under `<artefact root>/reasoning/`. | Deleting the files removes them from the working tree only. **They stay in git history.** See below. |

### `repo` storage is permanent

> **Anything committed under `reasoning.storage: repo` stays in git history.**
> Switching back to `local`, or deleting the files later, does not remove what
> was committed and pushed. Only a rewrite of the repository's history removes
> it, for example with `git filter-repo` or BFG, followed by a force-push and a
> fresh clone on every machine. Maestro never rewrites history for you.

Choose `repo` only if everyone who can clone that repository may read every
crew's reasoning, and keep in mind that [redaction](#redaction-and-sensitivity)
is best-effort.

### How the setting is applied

- With `repo`, Maestro writes a small block to `<artefact root>/.gitignore` that
  lets git see `reasoning/`. It contains `!reasoning/` between two
  `# Maestro reasoning storage` marker lines. Leave the block alone: Maestro adds
  and removes it to match the setting. Your own lines in that file are never
  touched. The file is updated when the dispatcher starts and again when each
  crew run ends.
- The reasoning commit uses the same mechanism as Maestro's other order
  bookkeeping commits. If you set `lifecycle.commitTransitions: false`, reasoning
  is not committed either.
- Each commit names only that order's reasoning folder, so a file another crew
  is still writing for a different order is never included.

### Switching from `repo` back to `local`

Maestro removes the `.gitignore` block, so new reasoning files are ignored
again. Files that were **already committed stay tracked**: git keeps tracking a
file once it has been committed, whatever `.gitignore` says. To stop tracking
them, run this in the repository that holds your artefact root and commit the
result:

```bash
git rm -r --cached reasoning/      # embedded mode: git rm -r --cached .mso/reasoning/
git commit -m "Stop tracking crew reasoning"
```

This only stops tracking the files. Everything committed earlier is still in
history.

### Upgrading an existing workspace

New and updated workspaces get `.mso/reasoning/` in Maestro's gitignore block
from `mso init` / `mso update`. In solo or shared artefact mode the dispatcher
also refreshes that block in the artefact repo when it starts. After you upgrade
Maestro, restart the dispatcher (or run `mso update`) **before** any crew runs.
Until then, avoid committing the artefact repo with a broad `git add`, because
new reasoning files are not yet ignored.

## Redaction and sensitivity

Before any record is written, Maestro replaces every secret it recognises with
`[REDACTED:<kind>]`. Examples are GitHub tokens, Anthropic API keys, AWS access
keys, JWTs, private-key blocks, credentials in URLs (`https://user:pass@host`)
and password assignments (`DB_PASSWORD=…`). It uses the same pattern library as
the secret-scanning hooks. Tool-call descriptions are redacted before they are
shortened, so in anything recorded by 5.19.0 or later a token cannot survive by
being cut in half. Every reader (`mso reasoning`, the Hub) redacts the text
**again** as it reads it. That second pass also covers files written by an
older Maestro version or edited by hand.

**Activity logs from before 5.19.0.** `mso reasoning show` and the Hub order
**Reasoning** tab also join tool calls from the crews' activity logs, including
older ones under `crews/crewN/history/`. Entries written before 5.19.0 were
shortened before they were redacted, so they can still hold a fragment of a
secret that no longer matches any pattern. If that matters to you, delete the
old activity logs.

**Redaction is best-effort.** It only catches secrets in shapes the pattern
library knows. A password, a private hostname, customer data or a token in an
unfamiliar format can still appear in the text. Treat reasoning files as
**sensitive**, in the same way as crew logs:

- Under `local` storage, restrict access to the workspace folder.
- Choose `repo` storage only for a repository with the right audience
  ([above](#repo-storage-is-permanent)).
- Do not paste reasoning into tickets or chat without reading it first.

**The crew's raw output files are not redacted.** Each crew also keeps the raw
stream of its session in `crews/crewN/output_NN.txt` (and under
`crews/crewN/history/`). With reasoning capture on, those files contain the same
reasoning text as it came from the API, **before redaction**. They are runtime
files: gitignored, never committed, not included in `mso backup`, and kept on
this machine only. Delete them when you no longer need them. When
`reasoning.enabled` is `false`, the raw stream carries almost no reasoning text,
because without `--thinking-display` the API returns nearly every thinking block
empty.

**Treat stored reasoning as untrusted text.** A crew may read files, web pages
or issue text that contain instructions or HTML, and the model's summary can
repeat them. Maestro's own views show reasoning as plain text. If you feed
reasoning files into another tool, a script or a model, treat the contents as
data and never as instructions, and escape them before you render them as HTML.
This includes the Markdown that `mso reasoning show --format md` writes, which
quotes the model's text as it is.

## Reading it from the CLI

All three commands are read-only, apart from `import`, which only adds
reasoning files. They work on every tier and accept `--project @PRJ`. See
[CLI-REFERENCE.md](CLI-REFERENCE.md#mso-reasoning).

### `mso reasoning tail`

```
mso reasoning tail <ORDER|crewN> [-f] [-n N] [--digest] [--json]
```

Shows the most recent records. `-f` keeps following them.

- **An order** (`FTR-MSO-2026-0001`) shows every role and iteration of that
  order. Each line starts with its role and iteration.
- **A crew slot** (`crew3`) shows whatever that crew is working on now. With
  `-f` it follows the crew to its next iteration, role or order, and prints a
  header line each time the target changes (`-- FTR-… BLD iter 02 crew 3 --`).
- `-n N` sets how many existing records to show first (default 20). Use a
  number above 0. `-n 0` currently prints every existing record rather than
  none.
- `--digest` prints the one-line digest instead of the full text. `--json`
  prints one record per line.

Model reasoning is printed quoted and labelled as the model's:

```
14:02:11  BLD iter 01  Model reasoning (turn 3):
    > The test imports the old helper, so I'll update the import before running it.
14:02:12  BLD iter 01  [tool   ] Editing test_cli.py
14:05:40  BLD iter 01  [maestro] Iteration 1 ended (exit code 0).
```

### `mso reasoning show`

```
mso reasoning show <ORDER> [--role R] [--format text|md|json] [--digest]
```

Shows everything recorded for one order, oldest first, grouped by **role, lap
and iteration**. `--role` narrows the output to one role and is not
case-sensitive. `--format md` writes Markdown, and `--format json` writes the
same data the Hub uses. Timestamps are UTC.

- A **lap** is one turn of a role on the order, for example the second BLD
  run after a QA rejection. A requeued role starts again at iteration 1, so the
  lap is what tells two runs apart. "lap unknown" means the order has no role
  history, or the record is older than the role's first recorded turn.
- Each group has two parts. **Model reasoning** quotes the model's turns.
  **Activity** lists Maestro steps and tool calls.
- If a group has no tool calls recorded with the reasoning (for example an
  imported or older run), Maestro fills its Activity part from that crew slot's
  activity log, matched **by time**. That log does not record the order, so the
  match is approximate. The output says "(tool calls joined from
  activity.jsonl)" when it does this. A group shows at most 2,000 activity
  entries ("activity cut at 2000 entries").
- At most the newest 10,000 records of an order are shown. A note says so when
  older ones were left out.

### `mso reasoning import`

```
mso reasoning import [--order ORDER] [--dry-run] [--json]
```

Fills in reasoning for runs from **before** capture existed, using the old
`crews/crewN/output_*.txt` files that are still on this machine. Expect little.
Before capture, the CLI returned thinking blocks with no text, so most old files
contain nothing to import.

- Imported records go through the same redaction as live ones and are marked
  `[imported]` in the CLI and "· imported" in the Hub.
- It is safe to run more than once. Nothing is imported twice, and a run that
  was already captured live is skipped. `output_final.txt` is never read.
- It refuses to run while `reasoning.enabled` is `false`.
- Under `repo` storage, imported files are committed at the end of the order's
  next crew run. For an order that is already complete, commit them yourself.

## Reading it in the Hub

Any Hub user can view reasoning. It is not gated by licence tier.

- **Crew drawer → Reasoning.** This shows a running crew live, in two lanes.
  **Model reasoning** shows the digest of each turn, and **Show full text**
  expands a turn. **Activity — Maestro steps and tool calls** is the other lane.
  The view follows the crew from one iteration, role or order to the next. A
  notice is shown when capture is off for the workspace.
- **Order drawer → Reasoning tab.** This is the same review as
  `mso reasoning show`. Each role / lap / iteration group can be collapsed, and
  only the newest is open at first. A role filter appears when the order has
  more than one role. Notices tell you when capture is off, when the order file
  could not be found (so laps cannot be told apart), when records were
  truncated, and when an Activity list was cut short.

REST: `GET /api/v1/orders/{id}/reasoning?role=R` (the order tab), and the
`/api/v1/workspaces/{id}/crews/{slot}/reasoning/stream` WebSocket (the crew
drawer). See [HUB.md](HUB.md#rest-api-reference).

## Erasure and data-subject requests

Reasoning can mention people, for example a name in a ticket the crew read.
Plan for erasure requests before you choose a storage mode.

- **`mso identity rights export` and `mso identity rights forget` do not search
  reasoning files** or the crews' raw output files. To find a data subject,
  search them yourself:

  ```bash
  grep -rl "alice@example.com" <artefact root>/reasoning/ <artefact root>/crews/
  ```

- **`local` storage:** delete the matching reasoning files and the matching
  `crews/crewN/output_*.txt` files (including those under `history/`). `mso
  backup` does not include either, so nothing else holds a copy unless you
  copied the files yourself or a machine-level backup includes the workspace
  folder.
- **`repo` storage:** deleting the files is not enough, because they remain in
  git history on every clone. Erasure needs a **manual history rewrite** of that
  repository (`git filter-repo` or BFG), a force-push, and a fresh clone on every
  machine. This is the same manual step that `mso identity rights forget` lists
  for identity data. It is disruptive, and your git host's policy may block it.
  If you might ever need to erase reasoning, use `local` storage.

## Lifecycle log lines

These appear in `.mso/logs/lifecycle.log`. All of them are fail-open: a
reasoning problem never holds a crew, an order or the fleet.

| Line | Meaning |
|------|---------|
| `DISPATCH … reasoning storage gitignore synced to <path>` | At dispatcher startup, the `.gitignore` block was added or removed to match `reasoning.storage`. |
| `WARN … reasoning storage gitignore sync failed (fail-open…)` | That update failed, often because of an invalid `reasoning.storage` value. Fix the setting. Crews still run. |
| `WARN <ORDER> reasoning not committed (fail-open…)` | Under `repo` storage, the order's reasoning could not be committed when its crew run ended. The files are still on disk. They are committed when the order's next crew run ends, or you can commit them yourself. |

Two messages appear in the crew log, not the lifecycle log.
`Reasoning capture off for this iteration: …` means the settings or the order
id could not be used; the crew runs without capture.
`CLI lacks --thinking-display …` is the [requirement](#requirements) above.
