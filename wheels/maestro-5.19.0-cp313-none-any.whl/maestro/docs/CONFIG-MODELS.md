# Configuring per-role models

Maestro assigns a Claude model to each role based on what the role does:

| Role | Default model | Default effort | Why |
|------|---------------|----------------|-----|
| **PLN** — Planner (NAV) | `claude-opus-5-5` | `medium` | Planning & architecture — high-leverage, low-volume; a better plan prevents downstream rework |
| **BLD** — Builder (SHP) | `claude-sonnet-5-5` | `high` | Implementation — highest-volume role; Sonnet is strong here. Promote individual hard orders via the per-order `model` override |
| **TST** — Tester (BOS) | `claude-sonnet-5-5` | `high` | QA, testing |
| **DOC** — Docs writer (SCR) | `claude-sonnet-5-5` | `high` | Documentation |
| **SEC** — Security (LKT) | `claude-sonnet-5-5` | `high` | Investigation, scanning — independent adversarial reviewer. A cheaper model can be pinned (see below) |
| **REL** — Releaser (COX) | `claude-opus-5-5` | `medium` | Integration review + release — last role in the chain; best judgement matters most |
| **LEAD** | `claude-opus-5-5` | `medium` | Interactive orchestration & judgement |

In short: **PLN/REL/LEAD Opus 5.5, BLD/TST/DOC/SEC Sonnet 5.5.** These values are `DEFAULT_ROLE_MODEL_IDS` and `DEFAULT_ROLE_EFFORT` in `maestro/core_constants.py`; `mso config models` prints what your workspace actually resolves.

Selection principle: **high-stakes × low-volume → Opus**. PLN/REL/LEAD run infrequently but their decisions propagate, so they get Opus; the high-volume production roles (BLD/TST/DOC) and SEC run on Sonnet.

## Available models

Every model below can be selected for any role or any order. No role defaults to Fable.

| Model | ID | Notes |
|-------|----|-------|
| Fable 5.1 | `claude-fable-5-1` | Highest-capability tier. Reserve for individual hard orders — see [Choosing Fable 5.1](#choosing-fable-51-for-an-order-or-a-role) |
| Fable 5 | `claude-fable-5` | |
| Opus 5.5 | `claude-opus-5-5` | Default for PLN / REL / LEAD. Successor to Opus 5 at a lower list price ($4/$20 per MTok, cache reads $0.20 — 0.05x base input). |
| Opus 5 | `claude-opus-5` | Previous Opus default, still supported and pinnable |
| Sonnet 5.5 | `claude-sonnet-5-5` | Default for BLD / TST / DOC / SEC. Successor to Sonnet 5 at the **same list price** ($2/$10 per MTok) and faster; cache reads are **$0.10** — 0.05x base input, half Sonnet 5's $0.20. Effort levels are **recalibrated** — `high` on Sonnet 5.5 is not `high` on Sonnet 5; re-sweep rather than carrying an effort setting over. |
| Sonnet 5 | `claude-sonnet-5` | Previous Sonnet default, still supported and pinnable |
| Haiku 5.5 | `claude-haiku-5-5` | Current Haiku and the current cheap option. Supported and pinnable; no role defaults to it. Priced in **two tiers by prompt length**: from $0.10 / $0.50 per MTok input/output; $0.50 / $2.50 when the prompt is over 100K tokens (prompt length includes cache reads and writes). Supports `xhigh` effort; 1M context is its default. **Not a drop-in for Haiku 4.5** — see [Haiku 5.5](#haiku-55-the-current-cheap-option). |
| Haiku 4.5 | `claude-haiku-4-5` | Previous Haiku generation, still supported and pinnable, at one flat rate ($1/$5 per MTok, half Sonnet 5.5's per-token price). Does not support effort levels. The dated snapshot id `claude-haiku-4-5-20251001` is still accepted where it is already pinned. |
| Opus 4.8 / 4.7 / 4.6 | `claude-opus-4-8`, `claude-opus-4-7`, `claude-opus-4-6` | Previous generation, still supported (historical pricing and transcripts resolve) |
| Sonnet 4.6 | `claude-sonnet-4-6` | Previous generation, still supported |

This set is `SUPPORTED_MODELS` in `maestro/core/crew.py`. Maestro refuses to dispatch against a model ID it can't price (no `PRICING` entry in `maestro/core/fleet_usage_tracker.py`) — an unknown ID at any override layer raises an error naming the supported set, rather than silently dispatching. Adding a new model means updating both `SUPPORTED_MODELS` and `PRICING` in the framework — file an FTR if you need one Maestro doesn't have.

A model ID may carry the `[1m]` context-window suffix (e.g. `claude-opus-5[1m]`); it is stripped before validation. See [Context window](#context-window) below.

### These IDs are the same on every backend

If your workspace runs its crews against a non-default **model backend** — AWS Bedrock, say — the IDs above do not change. `claude-opus-5-5` is still what you write in an order's `model` field, in `role-models.json`, in a role overlay and in an env var, and it is still what appears in usage records, `mso status`, the Hub and your plans. The backend-native ID is derived at dispatch time and appears only on the crew's `--model` argument and its `Model:` log line.

That is deliberate: the same order dispatches unedited on a Bedrock workspace and on a direct-API one. A model a backend cannot serve **refuses the launch**, naming the configuration key to map it — it is never silently swapped for a different model. See [MODEL-BACKENDS.md](MODEL-BACKENDS.md).

### Open-weights models (experimental)

A workspace that has configured an open-weights endpoint (`providers.local_model`) can also pin a role, a voyage or an order to an **open-weights** model. These ids form a separate group: they are not Claude models, have no generations, are never a role's built-in default, and are accepted only once an endpoint is configured.

| Model | ID | Notes |
|-------|----|-------|
| Muse Glimmer 30B | `muse-glimmer-30b` | Apache-2.0, 131,072-token context. Served by your own runtime (e.g. Ollama's `muse-glimmer:30b`) |

You can declare further open-weights ids in the endpoint's config. With no endpoint configured, a pin to one of these ids is refused everywhere with the fix: `mso providers set local_model endpoint --config baseUrl=...`.

- **The model id picks the backend.** A `claude-…` id runs on your Claude backend; an open-weights id runs on the endpoint. There is no separate backend field.
- **Role policy.** DOC, BLD, TST and INV may use an open-weights model. PLN, SEC and REL are refused unless listed in the endpoint's `allowRoles`; LEAD never runs on one. A refused pin is refused at `mso settings set`, at `mso voyage create`, and at launch.
- **Effort and `[1m]` do not apply.** No effort is passed to an open-weights crew, and the `[1m]` suffix is refused; the context window comes from the endpoint's catalogue.
- **`mso settings` and the Hub** list these ids in their own `open-weights` / **Open-weights (local)** group, only when an endpoint is configured.
- **`mso migrate model-pins`** never rewrites an open-weights pin.

Setup, hardware, the role policy in full and troubleshooting: [LOCAL-MODELS.md](LOCAL-MODELS.md).

## How a role's model is resolved

Five layers apply to every role, evaluated from highest to lowest priority — the first one that sets a model wins. A dispatched order can add two more: a **voyage** layer, between the per-order and workspace layers, and an opt-in **fallback** layer above all of them. The full chain, as `mso config models` prints it, is:

```
fallback > per-order > voyage roleModels > workspace config > env var > role overlay > built-in default
```

1. **Per-order** — order JSON `model` field (one-off, for a hard order)
   - **Voyage** — the voyage's `roleModels[ROLE]`, set with `mso voyage create --role-model ROLE=MODEL` (applies to every order in the voyage that does not set its own `model`; see [Per-voyage pins](#per-voyage-pins))
2. **Workspace config** — `.mso/config/role-models.json` (per-project, persistent)
3. **Env var** — `MAESTRO_MODEL_<ROLE>` (per-shell, fastest to test)
4. **Role overlay** — `model` in `.mso/config/roles/<CODE>.md` frontmatter (per-project, travels with the role's other customisations)
5. **Built-in default** — the table at the top of this page

The **fallback** layer is off unless you set `modelFallback` (a Claude id) on an order or a voyage. It arms only after an order's open-weights runs fail (`modelFallbackAfter` times, default 1), resolves with source `fallback`, and is logged as `MODEL_FALLBACK`. A model is never switched without it. See [LOCAL-MODELS.md](LOCAL-MODELS.md#optional-fallback-to-claude).

### Why the Opus roles default to `medium` effort

PLN/REL/LEAD default to **`claude-opus-5-5` at `medium` effort**, not to the top of the effort ladder. Maestro's recommendation, for the Opus roles specifically:

- **Prefer the newer model at the same effort.** Moving an Opus role forward a generation while holding effort constant is cheaper per order, not dearer — the newer model reaches the same answer in fewer tokens.
- **The effort ladder is steep on cost and flat on quality.** Stepping `low` → `medium` → `high` → `xhigh` on an Opus role roughly doubles the cost of an order without reliably improving what it produces.
- **Raising effort cancels the saving.** On the previous generation, Opus 5 at `high` cost meaningfully more than Opus 5 at `medium`, and at `xhigh` roughly twice as much, for no dependable quality gain. `medium` is also Opus 5.5's own API default. **The economy win comes from dropping effort, not merely from switching model. Do NOT reflexively raise effort on Opus 5.5.**

Treat the direction as reliable and the magnitude as approximate — your own orders are the measurement that matters, and `mso usage --by-effort` will show you the cost-by-effort split for your workspace. Every one of these defaults is a default, not a policy: change them per role via `role-models.json`, or per order via the `model` / `effort` fields.

**This guidance covers the Opus roles only.** BLD/TST/DOC default to Sonnet 5.5 at `high` — a generation refresh from Sonnet 5 at the same list price (only cache reads are cheaper, $0.10 vs $0.20), so it buys mostly capability and speed, not money. Sonnet 5.5's effort levels are recalibrated and Anthropic's own guidance for agentic coding is to start at `medium`; Maestro has not changed the effort default, so measure before you lower it. Opus has not been shown to beat Sonnet in the high-volume production roles.

**SEC moved from Haiku 4.5 to Sonnet 5.5.** This is a capability choice and a **cost increase**: Sonnet 5.5 is 2× Haiku 4.5's price on input, output and cache writes ($2/$10 vs $1/$5 per MTok input/output); cache reads cost the same ($0.10). No benchmark has compared the two for security review, so do not read it as a measured quality win. It also means SEC now runs the same model as BLD/TST — if you value the independent reviewer being a *different* model from the builder, pin SEC to Haiku 5.5 (the current cheap option) or Opus 5.5: `mso settings set models.SEC.model claude-haiku-5-5`. **No benchmark has compared Haiku 5.5 with Sonnet 5.5 for security review either** — a Haiku 5.5 pin is a cost choice, not a measured quality-equivalent one; read [Haiku 5.5](#haiku-55-the-current-cheap-option) before you make it. Haiku 4.5 is still a valid pin, but it is now previous-generation, and `mso settings set` warns that Haiku 5.5 supersedes it (the pin is still written). A SEC `xhigh` effort or `1m` context setting that Haiku 4.5 downgrades is honoured on Sonnet 5.5 and on Haiku 5.5.

### Haiku 5.5: the current cheap option

`claude-haiku-5-5` is the current Haiku. No role defaults to it, and `mso migrate model-pins` does not move a Haiku 4.5 pin onto it (see [Upgrading pins](#upgrading-pins-when-a-new-model-ships)). Pin it per role or per order if you want it.

**Its price depends on prompt length — there is no single Haiku 5.5 price.** Each request is priced on its own:

| Prompt length of the request | Input | Output | Cache write (5m) | Cache read |
|------------------------------|-------|--------|------------------|------------|
| Up to 100,000 tokens (inclusive) | $0.10 | $0.50 | $0.125 | $0.01 |
| Over 100,000 tokens | $0.50 | $2.50 | $0.625 | $0.05 |

Per million tokens, Anthropic first-party list prices. A request's prompt length counts **all** of its input tokens, **including cache reads and cache writes**, so a request whose prompt is mostly a cache hit can still be over the threshold; a request over it pays the higher rate on every token type, output included. Crew prompts usually pass 100K after a few turns once cache reads are counted, so plan on the higher tier for real crew work. Even there it is 4× cheaper than Sonnet 5.5 on input and output ($0.50/$2.50 vs $2/$10). Maestro's usage pricer applies the tier request by request, so `mso usage` reflects the split. No other model Maestro supports has a prompt-length surcharge.

**It is not a drop-in replacement for Haiku 4.5** — before you swap a pin, know that:

- Thinking is on by default, so a request produces more output tokens than the same request on Haiku 4.5.
- The same text costs about 30% more tokens (a newer tokenizer).
- Non-default sampling parameters (`temperature`, `top_p`, `top_k`) and assistant prefill return a 400 error. This matters only to your own tooling that sets them.
- On Amazon Bedrock, Haiku 5.5 is granted per account (Haiku 4.5 is open to every Bedrock customer), and structured outputs are not available for it. See [MODEL-BACKENDS.md](MODEL-BACKENDS.md#the-shipped-translation-table).

**Effort.** Maestro passes `--effort` on every crew launch (whenever the installed Claude CLI has the flag), so a Haiku 5.5 role runs at **the role's effort** — `high` for BLD/TST/DOC/SEC by default — not at the model's API default of `medium`. Anthropic advises starting Haiku 5.5 at `medium` for most work, including agentic coding, and `high` for longer agent tasks and strict instruction-following. If you pin Haiku 5.5, consider setting effort with it:

```json
{"models": {"DOC": {"model": "claude-haiku-5-5", "effort": "medium"}}}
```

Haiku 4.5 does not support effort at all, so there is no Haiku 4.5 effort setting to carry over.

These defaults are tuned for the typical AU/NZ price-and-quality envelope.

## Inspecting the active configuration

```bash
mso config models
```

Prints a table showing the resolved model for each role and the source that decided it, plus the **Backend** each model routes to (e.g. `model/anthropic`, `model/bedrock`, `local_model/endpoint`) and, for an open-weights route, its **Endpoint** as `host:port`. The per-order, voyage and fallback layers can't be displayed in a static table (they depend on the order being dispatched), so this command shows the layers below them.

## Layer 1 — Per-order override

Add a `model` field to an order JSON. Highest priority — beats every other layer.

```json
{
  "orderId": "FTR-PSG-2026-0042",
  "type": "FTR",
  "role": "BLD",
  "title": "Refactor the auth flow",
  "model": "claude-opus-5-5"
}
```

Use this when one specific order needs a different model — e.g. a particularly thorny BLD refactor that benefits from Opus, while the rest of the fleet stays on Sonnet for cost.

## Per-voyage pins

Pin a role's model for every order in one voyage when you create it:

```bash
mso voyage create "Docs refresh" --project PSG --role-model DOC=claude-opus-5-5
```

`--role-model ROLE=MODEL` is repeatable and writes the voyage's `roleModels`. It sits between the per-order layer and the workspace config: an order's own `model` still wins, and the voyage pin beats `role-models.json`. Crews report the source as `voyage`.

- The voyage is read when each crew launches; the pin is **not** copied into the orders, so editing `roleModels` later applies to every order that has not set its own `model`.
- The pins are validated at create time — an unknown role or model, an open-weights model with no endpoint, or a role the open-weights policy refuses is rejected, and no voyage is created. Legacy role codes are accepted and stored as canonical codes.
- A mixed voyage (some roles on Claude, some on an open-weights model) is just a set of these pins; see [LOCAL-MODELS.md](LOCAL-MODELS.md#choosing-a-model-per-order-voyage-and-role).

## Layer 2 — Workspace config

Create `.mso/config/role-models.json` in your workspace:

```json
{
  "models": {
    "BLD": "claude-opus-5-5",
    "TST": "claude-opus-5-5"
  }
}
```

Only the roles you list are overridden — everything else falls through to the lower layers. Survives across shells, runs, and dispatcher restarts. Per-project: each project workspace can have its own.

## Layer 3 — Env var

```powershell
# PowerShell
$env:MAESTRO_MODEL_BLD = "claude-opus-5-5"
```

```bash
# bash / WSL
export MAESTRO_MODEL_BLD=claude-opus-5-5
```

Lives only in the shell that set it — useful for one-off testing or CI where you want different routing without touching files. Linux/macOS env vars are case-sensitive (must be uppercase `MAESTRO_MODEL_BLD`); Windows is case-insensitive at the OS level.

## Layer 4 — Role overlay

Set `model` in the role's overlay frontmatter at `.mso/config/roles/<CODE>.md`. Useful when the model choice belongs with the other customisations you've made to that role. See [ROLE-OVERLAYS.md](ROLE-OVERLAYS.md) for the full overlay format.

```markdown
---
{
  "role_code": "REL",
  "role_name": "Releaser",
  "extends": "core",
  "model": "claude-opus-5-5"
}
---
```

An overlay's `model` sits **below** the workspace config and env var layers, so a `role-models.json` entry or `MAESTRO_MODEL_<ROLE>` for the same role still wins.

## Choosing Fable 5.1 for an order or a role

`claude-fable-5-1` (Fable 5.1) is the highest-capability model Maestro supports. It lists at **$10 / $50 per MTok** (input / output) against Opus 5.5's $4 / $20 (`PRICING` in `maestro/core/fleet_usage_tracker.py`), and no role defaults to it. It is best reserved for individual hard orders — architecture-level design, a hard concurrency bug — not used as a role-wide default.

**For one order** (recommended) — add the per-order `model` field:

```json
{
  "orderId": "PLN-PSG-2026-0107",
  "type": "PLN",
  "role": "PLN",
  "title": "Design the multi-region replication architecture",
  "model": "claude-fable-5-1"
}
```

**For every order a role runs, via a role overlay** — create `.mso/config/roles/PLN.md`:

```markdown
---
{
  "role_code": "PLN",
  "role_name": "Planner",
  "extends": "core",
  "model": "claude-fable-5-1"
}
---
```

Then check that it took effect:

```bash
mso roles validate            # overlay parses and the model ID is recognised
mso config models             # PLN now resolves to claude-fable-5-1
```

**For every order a role runs, via workspace config** — `.mso/config/role-models.json`, which beats an overlay:

```json
{
  "models": {
    "PLN": {"model": "claude-fable-5-1", "effort": "medium"}
  }
}
```

Fable accepts the same effort values as Opus, including `xhigh`, so the effort guidance below applies to it too.

## Context window & reasoning effort

Maestro supports two additional per-role/per-order dispatch parameters.

### Context window

| Value | Meaning |
|-------|------|
| `standard` (default) | Normal context — no extra cost |
| `1m` | 1M context window — higher input token volume. On Haiku 5.5, 1M is already the default and the selector is a no-op, but a request whose prompt passes 100K tokens is billed at its higher price tier (see [Haiku 5.5](#haiku-55-the-current-cheap-option)) |

The `1m` selector appends as a suffix to `--model` (e.g. `claude-opus-5[1m]`), never as a separate flag. Use `1m` ONLY when many files must be held resident simultaneously.

### Reasoning effort

| Value | When to use |
|-------|------|
| `low` | Trivial/mechanical tasks |
| `medium` | Simple single-file tasks — and the default for the Opus roles (PLN/REL/LEAD) |
| `high` | Normal stories — the default for BLD/TST/DOC/SEC |
| `xhigh` | Opus, Fable, Sonnet 5 / 5.5 and Haiku 5.5 (any other model, including Haiku 4.5, is downgraded to `high`); complex long-horizon/high-risk work |
| `max` | **Interactive LEAD only** — rejected for crew dispatch |
| `ultracode` | **Interactive LEAD only** — rejected for crew dispatch |

### Object-form workspace config

```json
{
  "models": {
    "PLN": {"model": "claude-opus-5-5", "contextWindow": "1m", "effort": "xhigh"},
    "BLD": {"model": "claude-sonnet-5-5", "effort": "high"},
    "TST": "claude-sonnet-5-5"
  }
}
```

Bare-string values remain fully supported.

### Env vars

```bash
export MAESTRO_CONTEXT_PLN=1m
export MAESTRO_EFFORT_PLN=xhigh
```

### Cost guardrails

- Built-in defaults: contextWindow=standard for all roles; effort=`medium` for PLN/REL/LEAD and `high` for BLD/TST/DOC/SEC.
- Crew dispatch rejects effort=max and effort=ultracode (reserved for interactive LEAD).
- `1m` raises input token VOLUME; `xhigh` raises output+thinking tokens.

## Upgrading pins when a new model ships

When Anthropic ships a successor inside a model family, your existing pins keep working — a superseded model is *previous generation*, not retired, and it dispatches normally. Nothing here is on a deprecation clock. But a pin you set deliberately a year ago now names an older model than you would choose today, and finding every one of them by hand means grepping `role-models.json`, every role overlay, and every queued order.

`mso migrate model-pins` does that for you, and it is deliberately conservative:

```bash
mso migrate model-pins --dry-run     # ALWAYS do this first — writes nothing
mso migrate model-pins               # confirms, backs up, then applies
```

It moves a pin **one step forward inside its own family**, by an exact-id map:

| From | To |
|------|----|
| `claude-opus-5` | `claude-opus-5-5` |
| `claude-sonnet-5` | `claude-sonnet-5-5` |

Nothing else. A pin to any other model is reported as `UNCHANGED` and left exactly as it is — whether it names a previous-generation id (`claude-opus-4-8`, `claude-sonnet-4-6`) or a model in another family (`claude-fable-5`, `claude-haiku-4-5`). The map is literal rather than a "newest in this family" rule, so the command's meaning does not change under you the next time a model launches.

**`claude-haiku-4-5` stays `UNCHANGED` even though Haiku 5.5 now exists.** That is deliberate: Haiku 5.5 is not a drop-in replacement. It thinks by default, spends about 30% more tokens on the same text, rejects non-default sampling parameters and prefill, and on Bedrock needs per-account access that Haiku 4.5 does not. A rewritten pin could turn a working fleet — a Bedrock fleet in particular — into one that refuses to launch. Move a Haiku pin by hand once you have checked those points (see [Haiku 5.5](#haiku-55-the-current-cheap-option)).

### What it touches, and what it never touches

| Touched | Not touched |
|---------|-------------|
| `.mso/config/role-models.json` (both the bare-string and object forms) | Shipped defaults in the installed package — those move by **release**, never by a command |
| `.mso/config/roles/<CODE>.md` overlay frontmatter `model` | `orders/complete/`, `orders/failed/` — historical records, excluded by path |
| Live order JSON in `queues/**` and `orders/active/` | Any order whose `status` is `COMPLETE` / `FAILED` / `CANCELLED`, wherever it sits |
| — | `usage/**` — the usage ledger is a record of what *did* run |
| — | `MAESTRO_MODEL_<ROLE>` env vars (reported, but a shell variable is not a file) |

### The report is the output

Every pin gets one line, grouped by verdict: `CHANGE` (or `WOULD CHANGE` under `--dry-run`), `UNCHANGED`, `SKIPPED (historical)`, `SKIPPED (held)`, `REFUSED`, `INFO`, then a count line. On a mature workspace most of the report is skip lines — that is the point. You should be able to read off exactly which pins moved, which were declined, and why.

A `REFUSED` line always names the command that resolves it. The commonest cause is a model backend (`providers.model`) whose model map has no entry for the successor: rather than rewrite the pin into one that refuses every dispatch, the command leaves it alone and tells you the key to set.

### Holding a pin you chose deliberately

If a role is on an older model on purpose, say so next to the pin and the command will report it and never change it:

```json
{
  "models": {
    "SEC": {"model": "claude-opus-5", "holdModel": true},
    "BLD": {"model": "claude-opus-5"}
  }
}
```

`SEC` is reported `SKIPPED (held)`; `BLD` upgrades. In a role overlay the same marker is spelled `hold_model` (snake_case, matching `context_window`):

```markdown
---
{
  "role_code": "SEC",
  "role_name": "Security",
  "model": "claude-opus-5",
  "hold_model": true
}
---
```

`holdModel` / `hold_model` is read only by this command — nothing in dispatch consults it, so adding it changes no behaviour. An absent marker simply means "upgradeable". You can also set it with `mso settings set models.SEC.holdModel true`.

### Scope flags

| Flag | Effect |
|------|--------|
| `--dry-run` | Print the full report, write nothing |
| `--only ROLE[,ROLE]` | Limit to these role codes |
| `--exclude ROLE[,ROLE]` | Skip these role codes — **`--exclude` wins** where a role is named in both |
| `--no-orders` | Role pins and overlays only; leave live order pins alone (`--orders` is the default) |
| `--yes` | Skip the interactive confirm — the mandatory backup still runs |

Two things about the role filters that are easy to guess wrong:

- **`--exclude` beats `--only`.** `--only PLN --exclude PLN` changes nothing. The deny-list is the conservative reading: if the allow-list won, a typo in `--exclude` would silently *widen* a command that writes files.
- **They are role-scoped, and a live order is not.** `--only` / `--exclude` narrow role pins, overlays and the env-var report. An order carries its own `model` pin and may run several roles, so there is no role to attribute it to — `--no-orders` is the control for those. `--only PLN` on its own still upgrades every eligible live order pin.

An unknown role code is rejected with the list of canonical codes, rather than quietly matching nothing.

### How the files are rewritten

A role overlay is edited **surgically**: the one `model` token inside the frontmatter is replaced and the rest of the file — body, `sections`, `tools`, even its line endings — comes back byte-identical.

`role-models.json` and live order JSON are **re-serialised at two-space indentation** with a trailing newline. Every key survives, in its original order, including `_comment` and `$schema`; the file's own line-ending convention is preserved. For `role-models.json` that is simply its normal shape — the upgrade writes through the same path as `mso settings set`. For an order JSON you hand-wrote at four-space or compact indentation, expect the whole body to reformat, so review the diff with that in mind rather than reading it as unintended churn.

### Safety, and how to undo it

- **A backup is taken before the first write, and there is no flag to skip it.** The zip path is printed before anything is mutated, and the final line of the run names the exact undo: `mso restore "<path to the zip>"`. There is no `--rollback` for this action — re-inverting the map would not restore a pin the step refused, nor a key another path has touched since, so the backup is the honest recovery.
- **It refuses while the fleet is live** — a running dispatcher or a running crew. There is no `--force`: a mid-voyage model change would mean a voyage's TST crew ran on a different model than its BLD crew, with nothing in the record saying so. Let the fleet drain (`mso pause --wait`), then run it.
- **It is idempotent.** A second run reports `0 changes`.
- **The predecessor stays pinnable.** After an upgrade, `mso settings set models.PLN.model claude-opus-5` still works (with a "previous generation" warning). Going back is always available.

### `mso update` reports, and never rewrites

`mso update` is schema propagation, run casually and often, so it will tell you when pins are superseded and stop there:

```
[mso update] 7 model pins name a superseded model; run `mso migrate model-pins --dry-run` to see them.
```

That line is read-only. `mso migrate model-pins` is the only thing that changes a pin.

## Cost trade-offs

List prices per million tokens, input / output, from `PRICING` in `maestro/core/fleet_usage_tracker.py`. **These are Anthropic's first-party list prices.** On a workspace configured for a different model backend they are not your bill, so Maestro reports cost as `unpriced` rather than computing a figure from the wrong rate card — supply your own rates via `pricingOverrides` to get real numbers. An override is applied as one flat rate card — Maestro does not apply Haiku 5.5's prompt-length tier to it. Token counts are accurate on every backend. See [MODEL-BACKENDS.md](MODEL-BACKENDS.md#cost-is-reported-honestly-or-not-at-all).


| Tier | Models | Input | Output |
|------|--------|-------|--------|
| Fable | Fable 5.1, Fable 5 | $10.00 | $50.00 |
| Opus | Opus 5.5 | $4.00 | $20.00 |
| Opus | Opus 5 (and the previous-generation Opus 4.x IDs) | $5.00 | $25.00 |
| Sonnet | Sonnet 5.5, Sonnet 5 | $2.00 | $10.00 |
| Sonnet | Sonnet 4.6 (previous generation) | $3.00 | $15.00 |
| Haiku | Haiku 5.5 | from $0.10; $0.50 when the prompt is over 100K tokens | from $0.50; $2.50 when the prompt is over 100K tokens |
| Haiku | Haiku 4.5 (previous generation) | $1.00 | $5.00 |

Haiku 5.5 is the one model with two prices: each request whose prompt (cache reads and writes included) is over 100K tokens pays the higher tier on every token type — see [Haiku 5.5](#haiku-55-the-current-cheap-option).

Opus 5.5 costs 2× Sonnet 5.5 per token, Fable 5.1 2.5× Opus 5.5, and Haiku 4.5 half of Sonnet 5.5. Haiku 5.5 is the current cheap option: 20× cheaper than Sonnet 5.5 on input and output for a request up to 100K tokens of prompt, and 4× cheaper over it — and since crew prompts usually pass 100K once cache reads count, 4× is the figure to plan on. The defaults already exploit this asymmetry — Opus is reserved for the high-leverage, low-volume roles (PLN/REL/LEAD) where a mistake is costliest and the role runs infrequently, while the high-volume production roles (BLD/TST/DOC) and SEC run on Sonnet. Pinning SEC to Haiku 5.5 cuts its per-token price several-fold, but no benchmark has compared Haiku 5.5 with Sonnet 5.5 for security review, so treat it as a cost choice and measure the results on your own orders. Haiku 4.5 (previous generation) still halves Sonnet 5.5's per-token price if you already pin it. Most workspaces never need to override; for a one-off hard build, set a per-order `model` rather than moving BLD to Opus globally.

If your operators are seeing budget pressure, the cheapest first move is to drop the Opus roles back to Sonnet for non-critical projects — e.g. `.mso/config/role-models.json` with `{"models": {"PLN": "claude-sonnet-5-5", "REL": "claude-sonnet-5-5"}}`. That reclaims the Opus premium while keeping Sonnet's strong planning/coding quality. Run `mso usage --voyage <ID>` after a voyage to see whether the change paid off.
