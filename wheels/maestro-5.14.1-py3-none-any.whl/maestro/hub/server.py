# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Maestro Hub FastAPI application.

FastAPI and uvicorn are imported lazily inside create_app() so that
`import maestro.hub.server` never fails when the [hub] extra is absent.
"""

# Poll interval (seconds) for the WebSocket lifecycle stream. Patchable in tests.
_WS_POLL_INTERVAL: float = 2.0

# BUG-MSO-2026-0395 — dispatch guard messages (kept as module constants so the
# backend and its tests share one source of truth).
OBSERVE_ONLY_MESSAGE = (
    "This Hub is an observe-only deployment — it cannot launch a usable "
    "dispatcher here. Dispatch from a host session (`mso dispatch`) or run the "
    "Hub natively (`mso hub start`)."
)
STALE_MOUNT_MESSAGE = (
    "Workspace registry is temporarily unreadable (stale mount / I/O error). "
    "Restart the Hub containers (e.g. `docker compose restart`) and retry."
)
# BUG-MSO-2026-0440 — housekeeping (broom) has its OWN capability requirement,
# which is not the dispatcher's. See _sweep_unavailable_reason().
SWEEP_UNAVAILABLE_MESSAGE = (
    "Housekeeping needs the GitHub CLI (`gh`) to read authoritative PR merge "
    "state, and `gh` is not available in this Hub deployment. Run "
    "`mso voyage reconcile` from a host session instead — it is the same code "
    "path and needs no dispatcher."
)
# FTR-MSO-2026-0489: single source of truth for the licence-tier gate shared by
# every mutating control endpoint (dispatch/stop/sweep/review) AND by
# /api/v1/capabilities — the 403 an operator meets after clicking and the
# reason /capabilities showed before the click must be the same sentence.
CONTROL_TIER_MESSAGE = (
    "Maestro Hub dispatch control requires a Team or Enterprise licence."
)

# BUG-MSO-2026-0793 — the two ways a VOYAGE's rollback (because the planning
# order it was created with could not be filed) can be INCOMPLETE. Different
# facts, different remedies, never collapsed into one message: "still on this
# disk" is fixed with a delete, "gone here but still on the shared plane" is
# fixed on the artefact repo and is the one an operator has no way to
# discover from the response otherwise. Module constants for the same reason
# CONTROL_TIER_MESSAGE is — the tests assert the behaviour against these, not
# against a copy of the literal. (Order rollback itself is now entirely
# voyage_core.create_order_on_voyage's concern — BUG-MSO-2026-0754 closed the
# private per-endpoint copy this file used to carry.)
_VOYAGE_ROLLBACK_LOCAL_FAILED = (
    "AND the voyage manifest could not be removed ({path}: {error}). It exists "
    "with no orders, so nothing will ever run from it; delete it by hand."
)
_VOYAGE_ROLLBACK_REMOTE_FAILED = (
    "The rollback could not be published to the SHARED artefact plane "
    "({reason}: {detail}) - so {voyage_id}'s reservation commit is still on "
    "origin and every other device still sees an empty voyage. Commit the "
    "deletion of {path} in the artefact repo and push it (or revert the "
    "reservation commit there), then retry."
)


# ---------------------------------------------------------------------------
# Authoring-surface refusals (FTR-MSO-2026-0617, PLAN-PLN-MSO-2026-0556 §4.3/§7)
#
# BUG-MSO-2026-0555: the Hub's "New voyage" button reported `Voyage {id}
# created` and created nothing — a client-side id, a success toast, and no
# request. PLAN-PLN-MSO-2026-0556 §6.1 found the same defect in four more
# controls and made it a rule rather than five fixes: *no control may report
# success it cannot verify, and no control may exist whose endpoint does not.*
#
# These constants are the second half of that rule. A control whose endpoint
# does not exist yet is DISABLED with the reason served here, and the reason
# names the CLI verb that does work today — so the operator is told what to
# do instead, not merely refused. They are module constants for the same
# reason CONTROL_TIER_MESSAGE is: when the endpoints land (Orders 3/5/6) each
# one's 409/403 raises the SAME string this map showed before the click, so
# the pre-click explanation and the post-click refusal can never disagree.
# ---------------------------------------------------------------------------
# The four authoring "not yet available" reasons are DEFINED in
# maestro/hub/models.py (FTR-MSO-2026-0617) so the CapabilityMap field defaults
# can carry them, and re-exported here so every existing reference — including
# get_capabilities() below and tests/test_ftr_0617_honest_actions.py — keeps
# importing them from their historical home. One string per action, one home.
from maestro.hub.models import (  # noqa: E402
    FLEET_PAUSE_UNAVAILABLE_MESSAGE,
    FLEET_RESUME_UNAVAILABLE_MESSAGE,
    LEAD_START_UNAVAILABLE_MESSAGE,
    SPAWN_MONITOR_WRITE_UNAVAILABLE_MESSAGE,
    ORDER_CREATE_UNAVAILABLE_MESSAGE,
    ORDER_EDIT_UNAVAILABLE_MESSAGE,
    ORDER_SKIP_UNAVAILABLE_MESSAGE,
    VOYAGE_CREATE_UNAVAILABLE_MESSAGE,
)
# A read-only artefact plane is a REAL deployment (a container mounting the
# plane `:ro`, an NFS export gone read-only, a permissions change). PLAN §4.3:
# artefact-plane writes are not process spawns, so they are deliberately NOT
# gated on _is_observe_only() the way dispatch is — but "not blocked by
# container mode" is not the same as "writable", and the difference must be
# declared BEFORE the click rather than discovered as an OSError after it.
PLANE_READONLY_MESSAGE = (
    "The artefact plane is not writable from this Hub deployment (read-only "
    "mount or insufficient permissions) — creating or editing artefacts needs "
    "write access to the workspace's `voyages/` and `queues/` directories. "
    "Use the `mso` CLI from a host session that can write the plane."
)


def _env_truthy(name: str) -> bool:
    """True when env var *name* is set to a truthy value (1/true/yes/on)."""
    import os
    return os.environ.get(name, "").strip().lower() in ("1", "true", "yes", "on")


def _in_container() -> bool:
    """Best-effort container detection (the Docker runtime drops /.dockerenv)."""
    import os
    try:
        return os.path.exists("/.dockerenv")
    except OSError:
        return False


def _is_observe_only() -> bool:
    """Return True when this backend cannot spawn a usable host dispatcher.

    Primary signal: the ``MAESTRO_HUB_CONTAINERIZED`` env flag, set in
    ``docker/hub/Dockerfile.backend`` — a containerized backend has no Claude
    CLI and only sees container-registry paths, so a spawned dispatcher is a
    silent no-op (BUG-MSO-2026-0395). Fallback heuristic: running inside a
    container with no ``claude`` on PATH. The heuristic is gated on container
    detection so a native host that merely lacks ``claude`` on PATH (e.g. CI)
    is NOT misclassified as observe-only.
    """
    import shutil
    if _env_truthy("MAESTRO_HUB_CONTAINERIZED"):
        return True
    if _in_container() and shutil.which("claude") is None:
        return True
    return False


def _live_installed_version():
    """Freshly resolve the version actually installed on disk right now.

    BUG-MSO-2026-0627: `maestro.__version__` is cached in ``sys.modules`` at
    first import and stays FROZEN for the rest of the process's life — a
    long-running Hub daemon can serve stale code for days after a `pip
    install --upgrade` and have no way to notice on its own. `importlib.
    metadata.version()` reads the installed distribution's metadata straight
    off disk on every call (it is not part of the frozen module cache), so it
    picks up a reinstall without needing this process to restart — the same
    property that lets ``pip list --outdated``-style tooling work inside a
    long-lived interpreter. Tries both the private-channel distribution name
    (``maestro``) and the public PyPI one (``maestro-fleet``, see CLAUDE.md's
    install section) since either could be the one actually installed.
    Returns ``None`` (never raises) if neither distribution is found — a
    dev checkout with no installed distribution metadata is not an error.
    """
    import importlib.metadata as _metadata

    for dist_name in ("maestro", "maestro-fleet"):
        try:
            return _metadata.version(dist_name)
        except _metadata.PackageNotFoundError:
            continue
        except Exception:
            continue
    return None


def _sweep_unavailable_reason():
    """Why housekeeping cannot run in this deployment, or None if it can.

    BUG-MSO-2026-0440: the sweep endpoint was gated on ``_is_observe_only()``,
    which answers a DIFFERENT question — "can this backend spawn a usable
    dispatcher?" — and answers it by probing for the Claude CLI. Housekeeping
    needs neither a dispatcher nor the Claude CLI; FTR-MSO-2026-0426 is explicit
    that it is pull-based precisely so it works without one. Gating it on the
    dispatcher check refused the broom button for the wrong reason and returned
    OBSERVE_ONLY_MESSAGE, which tells the operator to run ``mso dispatch`` —
    advice that has nothing to do with housekeeping and cannot resolve it.

    What sweep actually needs is ``gh``: FTR-MSO-2026-0426 made the GitHub PR
    record AUTHORITATIVE for merge detection (raw-git ancestry is only the
    offline fallback, and deliberately degrades to "unknown" rather than risk a
    false "merged"). Without ``gh`` a sweep would still run but could not resolve
    any PR-backed voyage, so refusing remains correct — the fix is to refuse for
    the TRUE reason and to name the action that actually works.
    """
    import shutil
    if shutil.which("gh") is None:
        return SWEEP_UNAVAILABLE_MESSAGE
    return None


def _plane_writable_reason():
    """Why this deployment cannot WRITE the artefact plane, or None if it can.

    PLAN-PLN-MSO-2026-0556 §4.3, third rule. Artefact-plane writes are not
    process spawns, so authoring is deliberately NOT gated on
    ``_is_observe_only()`` the way dispatch is — ``review`` and ``orderRetry``
    already declare ``available=True`` on exactly that reasoning (PLAN-0468
    §4.1). But "not blocked by container mode" is not the same as "writable":
    a plane mounted read-only, or one whose permissions changed underneath a
    long-lived Hub, is a real deployment in which every authoring endpoint
    will fail. Declaring it here means the operator meets a disabled button
    with a reason instead of an ``OSError`` after the click.

    Workspace-independence is preserved deliberately: ``/api/v1/capabilities``
    answers a question about THIS BACKEND, not about one workspace, and is
    cheap enough to consult before rendering every control. So the probe is
    "can this backend write ANY registered workspace's plane?" and it reports
    unavailable only when it can write NONE of them. The alternative — refuse
    globally because one unrelated workspace's mount is read-only — would
    disable creation for workspaces that are perfectly writable, which is the
    same class of dishonesty (a reason that does not apply to what was
    clicked) this whole order exists to remove. The per-workspace refusal is
    the endpoint's job once one exists; this is the deployment-wide one.

    An EMPTY registry returns ``None``, not a reason. No workspace is not
    evidence of a read-only plane, and claiming it would be inventing a
    blocker — the honest refusal for "no workspaces" belongs to whatever
    control needs a workspace, not to this probe.

    Never raises: a registry that cannot be read, or a path that cannot be
    stat'd, is treated as unwritable (fail-closed for a MUTATION), because
    the only alternative is to enable a button on the strength of an error.
    """
    import os

    try:
        import maestro.registry as registry
        from maestro.workspace import artefact_parent_for_entry, resolve_artefact_dir
        projects = registry.list_projects()
    except Exception:
        return PLANE_READONLY_MESSAGE

    if not projects:
        return None

    for entry in projects.values():
        try:
            mso_dir = resolve_artefact_dir(artefact_parent_for_entry(entry))
        except Exception:
            continue
        # The two directories every authoring verb writes: a voyage manifest
        # lands in voyages/active/, an order lands in queues/*/. Probing the
        # plane root alone would pass on a deployment that mounts the root
        # read-write and these two read-only.
        for sub in ("voyages", "queues"):
            target = mso_dir / sub
            # Fall back to the plane root for a workspace that has not been
            # scaffolded yet — an absent subdirectory is a scaffolding gap,
            # not a writability verdict, and W_OK on a missing path is always
            # False, which would misreport every fresh workspace as read-only.
            probe = target if target.is_dir() else mso_dir
            try:
                if not os.access(probe, os.W_OK):
                    break
            except OSError:
                break
        else:
            return None  # this workspace's plane is writable — that is enough

    return PLANE_READONLY_MESSAGE


# ---------------------------------------------------------------------------
# Capability resolution (FTR-MSO-2026-0721, PLAN-FTR-MSO-2026-0700 §5.2)
# ---------------------------------------------------------------------------

#: Hub actions whose endpoint SPAWNS A HOST PROCESS rather than editing the
#: file plane. Only these are refused by an observe-only deployment: review /
#: orderRetry / orderSkip edit order JSON and ``config/skipped-orders.json``,
#: which work perfectly inside a container (PLAN-PLN-MSO-2026-0468 §4.1), and
#: disabling them there would hide the only remedies such a deployment HAS.
DISPATCH_CLASS_ACTIONS = frozenset({"dispatch"})


def _settings_write_blocked_reason(observe_only=None):
    """Why a Hub settings PUT would be refused here, or ``None`` if it would not.

    FTR-MSO-2026-0801: the ONE answer shared by ``build_capability_map`` and
    both settings PUT endpoints, in the endpoints' gate order — licence tier
    (D2: ``auth.LEAD_AGENT_TIERS``, Pro/Team/Enterprise) first, then the
    observe-only deployment probe the providers write uses.
    """
    from maestro import auth
    from maestro.hub.models import SETTINGS_WRITE_TIER_MESSAGE

    if not auth.has_tier(auth.LEAD_AGENT_TIERS):
        return SETTINGS_WRITE_TIER_MESSAGE
    if observe_only is None:
        observe_only = _is_observe_only()
    if observe_only:
        return OBSERVE_ONLY_MESSAGE
    return None


def build_capability_map():
    """The one construction of ``CapabilityMap``, shared by every caller.

    ``GET /api/v1/capabilities`` returns this verbatim, and the blockage
    endpoints resolve each ``Option`` against it. Two constructions would let
    a button's pre-click reason drift from the map the frontend polls - the
    exact class of disagreement FTR-MSO-2026-0489 introduced this map to end.

    FTR-MSO-2026-0617/0619/0621/0622: the authoring actions (voyageCreate /
    orderCreate / orderEdit / orderSkip) all back real endpoints, and each is
    available exactly when :func:`_plane_writable_reason` finds a writable
    plane - the SAME probe the endpoints fail on, never asserted separately.
    The blockage model's ``orderSkip`` options resolve against that same key.
    """
    from maestro import auth
    from maestro.hub.models import CapabilityInfo, CapabilityMap, TierCapability

    dispatch_blocked = _is_observe_only()
    sweep_blocked = _sweep_unavailable_reason()
    plane_blocked = _plane_writable_reason()
    control_ok = auth.has_tier(auth.HUB_TIERS)

    def _plane_capability():
        return CapabilityInfo(available=plane_blocked is None, reason=plane_blocked)

    # FTR-MSO-2026-0767 (D8): gated the same way dispatch is, not by
    # plane-writability — see PROVIDERS_WRITE_UNAVAILABLE_MESSAGE's docstring
    # in models.py for why the config write follows the observe-only probe.
    providers_write_blocked = dispatch_blocked

    # FTR-MSO-2026-0801 (PLAN-0792 D2): settings writes are Pro+, so their
    # capability carries the tier itself rather than deferring to
    # `tier.control` (Team+). The reason order matches the PUT endpoints' own
    # gate order — tier 403 first, then the observe-only 409.
    settings_write_reason = _settings_write_blocked_reason(dispatch_blocked)

    return CapabilityMap(
        dispatch=CapabilityInfo(
            available=not dispatch_blocked,
            reason=OBSERVE_ONLY_MESSAGE if dispatch_blocked else None,
        ),
        sweep=CapabilityInfo(available=sweep_blocked is None, reason=sweep_blocked),
        # Reads and mutations of order JSON (approve/decline/request-change/
        # retry) are file-plane, not process-spawn - they work in a container
        # today (PLAN-0468 section 4.1). Licence gating is reported separately
        # via `tier`, uniformly, for every mutating action.
        review=CapabilityInfo(available=True),
        orderRetry=CapabilityInfo(available=True),
        # A read-only plane refuses every authoring action; that refusal is
        # the durable, actionable one, which is why it is the reason given.
        voyageCreate=_plane_capability(),
        orderCreate=_plane_capability(),
        orderEdit=_plane_capability(),
        orderSkip=_plane_capability(),
        # BUG-MSO-2026-0794: POST /orders/{id}/attach writes the order JSON
        # and the voyage manifest — file-plane, the same probe as the others.
        orderAttach=_plane_capability(),
        providersWrite=CapabilityInfo(
            available=not providers_write_blocked,
            reason=OBSERVE_ONLY_MESSAGE if providers_write_blocked else None,
        ),
        settingsWrite=CapabilityInfo(
            available=settings_write_reason is None, reason=settings_write_reason,
        ),
        deviceSettingsWrite=CapabilityInfo(
            available=settings_write_reason is None, reason=settings_write_reason,
        ),
        # FTR-MSO-2026-0786: start (and restart) launch a detached host
        # process, so they follow the observe-only probe exactly as dispatch
        # does. Stop has no deployment gate — it is always offered, as it is
        # on the CLI. Tier is reported separately via `tier`, and only
        # start/restart consult it.
        leadStart=CapabilityInfo(
            available=not dispatch_blocked,
            reason=LEAD_START_UNAVAILABLE_MESSAGE if dispatch_blocked else None,
        ),
        leadStop=CapabilityInfo(available=True),
        # FTR-MSO-2026-0635: the machine-level spawnMonitor write. Follows the
        # observe-only probe — a containerised Hub's ~/.maestro is not the
        # host's, so its write would change nothing a host dispatch reads.
        spawnMonitorWrite=CapabilityInfo(
            available=not dispatch_blocked,
            reason=SPAWN_MONITOR_WRITE_UNAVAILABLE_MESSAGE if dispatch_blocked else None,
        ),
        # FTR-MSO-2026-0789: pause must name the live dispatcher by PID +
        # create time and resume may relaunch one, so both follow the
        # observe-only probe exactly as dispatch does. Tier via `tier`.
        fleetPause=CapabilityInfo(
            available=not dispatch_blocked,
            reason=FLEET_PAUSE_UNAVAILABLE_MESSAGE if dispatch_blocked else None,
        ),
        fleetResume=CapabilityInfo(
            available=not dispatch_blocked,
            reason=FLEET_RESUME_UNAVAILABLE_MESSAGE if dispatch_blocked else None,
        ),
        tier=TierCapability(
            control=control_ok,
            reason=None if control_ok else CONTROL_TIER_MESSAGE,
        ),
    )


def resolve_option_availability(option: dict, caps) -> tuple:
    """``(available, unavailable_reason)`` for one ``blockage.Option`` dict.

    PLAN-FTR-MSO-2026-0700 §5.2, applying FTR-MSO-2026-0617's honesty rule: an
    option that cannot work HERE is rendered disabled WITH ITS REASON, never
    hidden and never a 409 discovered after the click. The reason strings come
    straight off *caps*, which is built from the same module constants the
    endpoints' 403/409s raise, so the explanation before the click and the
    refusal after it cannot disagree.

    Three rules, in order:

    1. **No ``hubAction`` means CLI-only** — available. The command is real and
       an operator can run it in a terminal; it simply has no button. Marking
       a working remedy unavailable is the same failure as hiding it.
    2. **Tier gates everything mutating.** Every control endpoint calls
       ``_require_control_tier()`` as its FIRST statement, so the tier refusal
       is the one an operator actually meets; reporting the deployment reason
       ahead of it would name a blocker they would never reach.
    3. **Then the action's own capability**, looked up on the map by the
       option's ``capability`` key (falling back to ``hubAction``). An
       unrecognised key resolves to available — the model may name a
       capability a future map adds, and refusing an option this server simply
       does not recognise would invent a blocker rather than report one.
    """
    from maestro.hub.models import CapabilityInfo

    hub_action = (option.get("hubAction") or "").strip()
    if not hub_action:
        return True, None

    if not caps.tier.control:
        return False, caps.tier.reason or CONTROL_TIER_MESSAGE

    key = (option.get("capability") or hub_action).strip()
    info = getattr(caps, key, None)
    if isinstance(info, CapabilityInfo) and not info.available:
        return False, info.reason
    return True, None


def resolve_blockage_options(blockage_dict: dict, caps) -> dict:
    """Stamp ``available``/``unavailableReason`` onto every option in place.

    Returns the same dict so a caller can write
    ``BlockageResponse(blocked=True, **resolve_blockage_options(b.to_dict(), caps))``
    — the wire shape stays ``Blockage.to_dict()`` plus exactly those two
    server-resolved keys per option, with nothing about the model restated
    here.
    """
    for option in blockage_dict.get("options") or []:
        available, reason = resolve_option_availability(option, caps)
        option["available"] = available
        option["unavailableReason"] = reason
    return blockage_dict


# BUG-MSO-2026-0670 F1: bound for the LEAD Run endpoint's pre-flight
# condition re-check, run as a killable subprocess (see
# _run_single_check_subprocess below). Matches run_verbs.py's own
# _VOYAGE_RECONCILE_TIMEOUT_SECONDS deliberately: the one check that costs
# real time — voyages.merged-not-archived — runs the EXACT SAME gh-backed
# dry-run sweep the real reconcile handler this pre-check gates also runs.
# A shorter bound would spuriously refuse a click the real action would
# have completed within its own 300s budget. Every other check
# (dispatcher.heartbeat, voyages.stalled-order-deadlock, ...) is a pure
# on-disk read and returns in well under a second regardless of this
# ceiling — the cost of this bound is paid only in the gh-backed case.
_PRE_CHECK_TIMEOUT_SECONDS = 300


def _run_single_check_subprocess(mso, check_id: str, subject_id: str, product_repo):
    """Re-run exactly ONE patrol check as a killable OS subprocess and report
    whether *subject_id* is still open.

    This is the out-of-process replacement for calling ``maestro.patrol.
    run_single_check()`` directly on the request thread, which is what the
    LEAD Run endpoint's pre-flight re-check (BUG-MSO-2026-0662 F1) did until
    now. That direct call is CORRECT to keep — re-confirming a finding's
    condition immediately before acting on it is what stops a stale
    ``dispatcher.heartbeat`` finding from firing ``mso cleanup`` against a
    now-healthy dispatcher and killing live crews — but running it IN-PROCESS
    was the expensive way, and for a gh-backed check
    (``voyages.merged-not-archived``, which itself runs a full
    ``run_housekeeping_sweep(dry_run=True)``) that meant:

      * entering ``order_retry.workspace_scope()`` and holding the
        PROCESS-GLOBAL ``_SCOPE_LOCK`` — on THIS Hub process — for the full
        duration of a gh round trip. Every other concurrent
        ``workspace_scope()`` acquirer (another Run click, an order-retry
        POST) blocked on an UNBOUNDED lock for as long as gh took to answer;
      * no timeout at all — the exact in-process-sweep hazard
        ``run_verbs.py``'s own BUG-MSO-2026-0648 F1 note forbids for the
        Hub's real action handlers, just not (until this fix) for this
        pre-check;
      * restoring, in effect, the double-gh-sweep-per-click cost
        BUG-MSO-2026-0643 F3 removed from the action path — one gh sweep for
        the pre-check, another for the action itself, and this one blocking
        the whole Hub while it ran.

    A subprocess is a genuinely separate OS process — its own
    ``_SCOPE_LOCK``, its own ``_MAESTRO_DIR_OVERRIDE`` — and
    ``subprocess.run``'s own timeout handling actually KILLS it
    (``process.kill()``) rather than merely giving up waiting on it, exactly
    like ``run_verbs._handle_voyage_reconcile`` already does for the real
    action. Delegates to ``mso doctor --single-check`` (see
    ``maestro.cli.cmd_doctor``), which wraps ``run_single_check()`` and never
    touches ``patrol-state.json`` or the LEAD daemon's own ``state.json`` —
    same guarantee the in-process call had, so this remains safe to call
    concurrently with a running LEAD daemon.

    WORSE, and how it's bounded: this call can now take up to
    ``_PRE_CHECK_TIMEOUT_SECONDS`` (300s) by itself for a gh-backed check, on
    top of Python subprocess start-up (well under a second — negligible next
    to a gh round trip). A Run click against such a finding can therefore
    take up to 300s for the pre-check plus up to another 300s for the
    action's own bound (``run_verbs._VOYAGE_RECONCILE_TIMEOUT_SECONDS``)
    before the operator sees a result — worse, for THAT ONE CLICK, than the
    old in-process call usually was. That cost is paid only by the requester
    who clicked Run and is fully bounded/killable; it is never paid by any
    OTHER concurrent Hub caller, which is the actual outage this fixes. If
    the subprocess cannot complete within its bound, this returns
    ``verified=False`` — the caller (the Run endpoint) already fails CLOSED
    on that, refusing the action rather than proceeding on unconfirmed state.

    BUG-MSO-2026-0686 F2: spawned via ``Popen`` (never ``subprocess.run``),
    with a timeout that kills the WHOLE process tree via
    ``_kill_process_tree`` on expiry — identical to the fix applied to
    ``run_verbs._handle_voyage_reconcile`` (F1) and to the pre-existing
    ``run_verbs._handle_dispatcher_cleanup``. A plain
    ``subprocess.run(timeout=)`` only kills the DIRECT child — the gh/git
    GRANDCHILD `mso doctor --single-check` can be stuck on (for the same
    ``voyages.merged-not-archived`` check `_handle_voyage_reconcile` itself
    runs) survives it, so the 300s ceiling was not a real bound: every
    refused-then-retried Run leaked another orphaned gh process.
    """
    import json as _json
    import os
    import subprocess
    import sys

    from maestro.core.crew import _kill_process_tree
    from maestro.core.proc import popen_hidden
    from maestro.patrol import SingleCheckResult

    cmd = [
        sys.executable, "-m", "maestro.cli", "doctor",
        "--single-check", check_id, "--subject-id", subject_id or "",
        "--maestro-dir", str(mso),
    ]
    # cwd prefers the product repo (needed for the pack/bundle policy tiers
    # of the resolved patrol definition, same as run_patrol's own
    # `workspace=` parameter) but falls back to the artefact root itself
    # when no product-repo checkout is registered. BUG-MSO-2026-0672 F1:
    # this comment used to claim "find_workspace() in the subprocess still
    # resolves the right .mso either way via MAESTRO_DIR below" — false, the
    # sixth false justification found in this PR family. `cmd_doctor`'s
    # normal path resolves via `find_workspace()`, which deliberately
    # IGNORES MAESTRO_DIR (BUG-MSO-2026-0425) and instead walks up from cwd
    # — so an absent `.mso/config` above cwd made every LEAD Run permanently
    # refused, and a stale/foreign one let this safety gate be satisfied by
    # another fleet's state, regardless of the `env=` MAESTRO_DIR below.
    # `--maestro-dir` above is the real fix: `cmd_doctor`'s `--single-check`
    # branch reads that ARGV VALUE directly (never inferred from cwd, and
    # never from ambient environment, which is silently subject to whatever
    # else in the process environment happens to set MAESTRO_DIR — e.g. this
    # very Hub process's own). The `env=` MAESTRO_DIR kwarg below is kept as
    # a harmless secondary signal for anything else in the subprocess that
    # might read it ambiently; it is no longer what makes this resolve
    # correctly.
    cwd = str(product_repo) if product_repo is not None else str(mso)
    popen_kwargs: dict = dict(
        cwd=cwd,
        env={**os.environ, "MAESTRO_DIR": str(mso)},
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )
    if os.name != "nt":
        popen_kwargs["start_new_session"] = True
    try:
        proc = popen_hidden(cmd, **popen_kwargs)
    except OSError as exc:
        # Same class of failure as run_verbs.py's BUG-MSO-2026-0643 F4 — a
        # moved/deleted product-repo checkout since the registry entry was
        # last written.
        return SingleCheckResult(
            verified=False, still_open=True,
            reason=f"Pre-check subprocess could not start: {exc}",
        )

    try:
        stdout, _ = proc.communicate(timeout=_PRE_CHECK_TIMEOUT_SECONDS)
    except subprocess.TimeoutExpired:
        # The naive `proc.kill()` subprocess.run would have done here only
        # reaches the direct `mso doctor` child — the gh/git grandchild it's
        # stuck on survives it. Kill the WHOLE tree instead. "Could not
        # confirm" to the caller, same as run_single_check()'s own
        # unconfirmable-check contract.
        _kill_process_tree(proc.pid)
        try:
            # Drain the now-closed pipe so this process doesn't leak a
            # zombie/handle; the tree is already dead, so this returns fast.
            proc.communicate(timeout=15)
        except Exception:
            pass
        return SingleCheckResult(
            verified=False, still_open=True,
            reason=(
                f"Pre-check subprocess timed out after "
                f"{_PRE_CHECK_TIMEOUT_SECONDS}s — the process tree was killed."
            ),
        )

    if proc.returncode != 0:
        detail = (stdout or "").strip()[-500:]
        return SingleCheckResult(
            verified=False, still_open=True,
            reason=f"Pre-check subprocess failed: {detail or 'unknown error'}",
        )

    try:
        out = stdout or ""
        payload = _json.loads(out[out.index("{"):])
    except (ValueError, _json.JSONDecodeError):
        return SingleCheckResult(
            verified=False, still_open=True,
            reason="Pre-check subprocess produced no readable result.",
        )

    return SingleCheckResult(
        verified=bool(payload.get("verified", False)),
        still_open=bool(payload.get("stillOpen", True)),
        reason=str(payload.get("reason", "")),
    )


def create_app():
    """Build and return the FastAPI application."""
    from contextlib import asynccontextmanager

    from typing import Optional

    import fastapi
    from fastapi.middleware.cors import CORSMiddleware

    import maestro
    from maestro.hub.models import (
        AckRequest,
        ActionResult,
        ArtefactContent,
        BlockageResponse,
        CapabilityMap,
        ChartResponse,
        ControlResult,
        SweepResult,
        CrewDetail,
        CrewState,
        HealthResponse,
        LeadDetail,
        LeadStatus,
        OrderArtefacts,
        OrderEditRequest,
        OrderEditResult,
        OrderAttachRequest,
        OrderAttachResult,
        OrderSkipRequest,
        OrderSkipResult,
        OrderUsageDetail,
        CreateOrderRequest,
        CreateVoyageRequest,
        OrderCreated,
        OrderDefaults,
        OrderTypeDefault,
        ProviderResolvedInfo,
        ProviderTestRequest,
        ProviderTestResult,
        ProviderWriteRequest,
        ProviderWriteResult,
        SettingWriteRequest,
        SettingWriteResult,
        SettingsListResponse,
        ProvidersListResponse,
        SpawnMonitorSetting,
        SpawnMonitorWriteRequest,
        VoyageCreated,
        PlanResponse,
        PollerStatus,
        RejectRequest,
        RetryResult,
        ReviewItem,
        SalvageCandidateModel,
        SalvageCandidates,
        ReviseRequest,
        RunResult,
        UsageRollup,
        WorkspaceDetail,
        WorkspaceSummary,
    )
    from maestro.hub.poller import WorkspacePoller

    @asynccontextmanager
    async def lifespan(app: fastapi.FastAPI):
        poller = WorkspacePoller(interval=5.0)
        poller.start()
        app.state.poller = poller
        try:
            yield
        finally:
            poller.stop()

    import os
    import re
    import time as _time
    from datetime import datetime as _datetime, timezone as _timezone

    # BUG-MSO-2026-0712: when this backend process came up. Wall-clock for the
    # display stamp, monotonic for the elapsed measurement — a system clock
    # adjustment must never make a Hub that has been up for hours report a
    # negative or wildly wrong uptime, which is precisely the kind of nonsense
    # that teaches an operator to stop trusting the header line.
    _process_started_monotonic = _time.monotonic()
    _process_started_at = _datetime.now(_timezone.utc).isoformat()

    def app_started_at_and_uptime():
        return _process_started_at, round(_time.monotonic() - _process_started_monotonic, 3)

    app = fastapi.FastAPI(
        title="Maestro Hub",
        version=maestro.__version__,
        lifespan=lifespan,
    )

    # --- Security configuration (audit findings H4/H5/H6) -------------------
    # The Hub binds to 127.0.0.1, but a wildcard CORS policy + no Host/Origin
    # validation previously made it a browser-reachable, DNS-rebindable control
    # plane. We now: (1) allow only explicit localhost origins for CORS, (2)
    # validate the Host header to defeat DNS rebinding, and (3) enforce a bearer
    # token when one is configured (env MAESTRO_HUB_TOKEN or ~/.maestro/hub.token).
    # The token is opt-in so the existing localhost frontend keeps working; it is
    # strongly recommended on shared/multi-user hosts (see docs/security).
    def _configured_origins():
        raw = os.environ.get("MAESTRO_HUB_ALLOWED_ORIGINS", "").strip()
        if raw:
            return [o.strip() for o in raw.split(",") if o.strip()]
        return [
            "http://localhost:3000", "http://127.0.0.1:3000",
            "http://localhost:3847", "http://127.0.0.1:3847",
        ]

    def _allowed_hosts():
        # localhost forms + the Starlette TestClient sentinel ("testserver").
        # A DNS-rebinding attacker uses their OWN hostname (which resolves to
        # 127.0.0.1), so it is still blocked; "testserver" is never a real host.
        base = {"127.0.0.1", "localhost", "::1", "[::1]", "testserver", ""}
        raw = os.environ.get("MAESTRO_HUB_ALLOWED_HOSTS", "").strip()
        if raw:
            base |= {h.strip() for h in raw.split(",") if h.strip()}
        return base

    def _expected_token():
        tok = os.environ.get("MAESTRO_HUB_TOKEN", "").strip()
        if tok:
            return tok
        try:
            from maestro.workspace import get_maestro_home
            p = get_maestro_home() / "hub.token"
            if p.exists():
                return p.read_text(encoding="utf-8").strip() or None
        except Exception:
            pass
        return None

    _ORIGINS = _configured_origins()

    @app.middleware("http")
    async def _host_and_auth_guard(request, call_next):
        # Host-header allowlist — defeats DNS rebinding against the localhost bind.
        host = (request.headers.get("host") or "").rsplit(":", 1)[0].strip("[]")
        if host and host not in {h.strip("[]") for h in _allowed_hosts()}:
            return fastapi.responses.JSONResponse(
                status_code=403, content={"detail": f"Host '{host}' not allowed"})
        # Bearer token — enforced only when configured; /health and /ping stay
        # open for liveness (the container healthcheck presents no token).
        token = _expected_token()
        if token and request.url.path.startswith("/api/") \
                and request.url.path not in ("/api/v1/health", "/api/v1/ping"):
            auth = request.headers.get("authorization", "")
            presented = auth[7:].strip() if auth.lower().startswith("bearer ") else ""
            import hmac as _hmac
            if not presented or not _hmac.compare_digest(presented, token):
                return fastapi.responses.JSONResponse(
                    status_code=401, content={"detail": "missing or invalid bearer token"})
        return await call_next(request)

    # BUG-MSO-2026-0798 DEF-001: CORS MUST be registered AFTER the guard above.
    # Starlette's add_middleware/@app.middleware both insert at index 0, so the
    # LAST registration is the OUTERMOST layer. With CORS outermost: (1) a
    # browser preflight — which by spec never carries Authorization — is
    # answered by CORSMiddleware before the token gate can 401 it; (2) the
    # guard's 401/403 flows back out through CORSMiddleware and gains
    # Access-Control-Allow-Origin, so the UI can read the 401 and prompt for a
    # token. Only an allowed origin's preflight is answered; the real request
    # still hits the Host allowlist and token gate. Do not reorder.
    app.add_middleware(
        CORSMiddleware,
        allow_origins=_ORIGINS,
        allow_credentials=False,
        # BUG-MSO-2026-0798: the UI sends PUT (providers) and PATCH (order edit);
        # with GET/POST only, every cross-origin write (Docker frontend, `npm run
        # dev` on :3000) failed preflight. Origins above are deliberately unchanged.
        allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
        allow_headers=["Authorization", "Content-Type"],
    )

    _ORDER_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,64}$")

    def _validate_order_id(order_id: str):
        """Reject order ids that could escape the review directory (H-M path traversal)."""
        if not order_id or ".." in order_id or "/" in order_id or "\\" in order_id \
                or not _ORDER_ID_RE.match(order_id):
            raise fastapi.HTTPException(status_code=400, detail="invalid order id")

    # maestro.patrol.state.fingerprint() always produces a sha256 hex digest —
    # a fixed-shape identifier with no filesystem meaning, but validated the
    # same defensive way as _ORDER_ID_RE since it flows straight into a
    # dict-key lookup against JSON read from disk.
    _FINGERPRINT_RE = re.compile(r"^[A-Za-z0-9]{8,128}$")

    def _validate_fingerprint(fp: str):
        if not fp or not _FINGERPRINT_RE.match(fp):
            raise fastapi.HTTPException(status_code=400, detail="invalid fingerprint")

    @app.get("/api/v1/ping")
    async def ping():
        """Cheap liveness probe — touches no registry, filesystem, or poller.

        Used by the container healthcheck (docker/docker-compose.yml) so that a
        heavy workspace scan behind /api/v1/health can never flag the container
        unhealthy while it is serving traffic (BUG-MSO-2026-0390).
        """
        return {"ok": True}

    @app.get("/api/v1/health", response_model=HealthResponse)
    async def health():
        poller: WorkspacePoller = app.state.poller
        summaries = poller.summaries()
        running_version = maestro.__version__
        installed_version = _live_installed_version()
        # BUG-MSO-2026-0712: this process's OWN start time, measured by the
        # process about itself at app construction — never read back from the
        # PID record, which a crashed-and-restarted daemon may not have
        # rewritten and which a reader cannot verify belongs to whoever is
        # actually answering this request.
        started_at, uptime = app_started_at_and_uptime()
        return HealthResponse(
            status="ok",
            version=running_version,
            workspaces=len(summaries),
            poller_ready=poller.is_ready(),
            installedVersion=installed_version,
            versionMismatch=bool(installed_version) and installed_version != running_version,
            startedAt=started_at,
            uptimeSeconds=uptime,
        )

    @app.get("/api/v1/workspaces/status", response_model=PollerStatus)
    async def workspaces_status():
        """Poller readiness (BUG-MSO-2026-0467).

        The UI polls this alongside GET /workspaces so an empty/partial list
        during the cold-start window renders as "connecting" rather than as
        an empty fleet — ``state == "initialising"`` while the first pass is
        still scanning, ``"ready"`` once every registered workspace has been
        scanned at least once.
        """
        poller: WorkspacePoller = app.state.poller
        return PollerStatus(**poller.status())

    @app.get("/api/v1/workspaces", response_model=list[WorkspaceSummary])
    async def list_workspaces():
        poller: WorkspacePoller = app.state.poller
        return poller.summaries()

    @app.get("/api/v1/workspaces/{workspace_id}", response_model=WorkspaceDetail)
    async def get_workspace_detail(workspace_id: str):
        poller: WorkspacePoller = app.state.poller
        detail = poller.detail(workspace_id)
        if detail is not None:
            return detail
        # BUG-MSO-2026-0467: not yet in the cache. That's ambiguous — either
        # the id is genuinely unknown (real 404), or it's registered but the
        # poller hasn't scanned it yet (the poll pass runs sequentially, so a
        # workspace late in the registry order can lag behind /crews below,
        # which always resolves live and never consulted this cache at all).
        # Resolve the registry directly to tell the two apart, and when it IS
        # known, compute the detail on demand — the same live path /crews
        # already takes — so the two endpoints can never disagree about
        # whether a workspace exists.
        import maestro.registry as registry
        projects = registry.list_projects()
        entry = projects.get(workspace_id)
        if entry is None:
            raise fastapi.HTTPException(status_code=404, detail=f"Workspace '{workspace_id}' not found")
        from maestro.hub import aggregator
        from maestro.workspace import artefact_parent_for_entry, product_repo_for_entry
        ws_root = artefact_parent_for_entry(entry)
        product_repo = product_repo_for_entry(entry)
        return aggregator.build_workspace_detail(ws_root, workspace_id, product_repo=product_repo)

    @app.get("/api/v1/workspaces/{workspace_id}/crews", response_model=list[CrewState])
    async def get_workspace_crews(workspace_id: str):
        from maestro.hub import aggregator
        from maestro.workspace import artefact_parent_for_entry

        entry = _resolve_workspace_entry(workspace_id)
        ws_root = artefact_parent_for_entry(entry)
        return aggregator.build_crew_list(ws_root, workspace_id)

    @app.get("/api/v1/workspaces/{workspace_id}/crews/{slot}/detail", response_model=CrewDetail)
    async def get_crew_detail(workspace_id: str, slot: int):
        """One crew slot's read-only detail (FTR-MSO-2026-0577) — current
        order/role, a bounded newest-first activity.jsonl tail, the current
        activity line, progress.md, and files_modified.json. Never the raw
        output_01.txt/output_final.txt transcript. A slot outside
        maxCrews, or one with no crew directory on disk, is a clean 404.
        """
        from maestro.hub import aggregator
        from maestro.workspace import artefact_parent_for_entry

        entry = _resolve_workspace_entry(workspace_id)
        ws_root = artefact_parent_for_entry(entry)
        detail = aggregator.build_crew_detail(ws_root, workspace_id, slot)
        if detail is None:
            raise fastapi.HTTPException(
                status_code=404, detail=f"Crew slot {slot} not found")
        return detail

    @app.get("/api/v1/workspaces/{workspace_id}/lead", response_model=LeadStatus)
    async def get_workspace_lead(workspace_id: str):
        """LEAD sub-agent status (FTR-MSO-2026-0539, PLAN-PLN-MSO-2026-0504 §13).

        ``available``/``reason`` gate the strip/pip render for a community or
        non-Pro workspace — greyed with the reason as the upgrade affordance
        — rather than a 403, mirroring ``GET /api/v1/capabilities`` (declare
        up front, never a post-hoc-only 403). The underlying data is still
        returned even when ``available`` is False, same as `mso lead status`
        itself being ungated on the CLI side (cli.py:cmd_lead) — a licence
        check gates ACTING, never READING.
        """
        from maestro.hub import aggregator
        from maestro.workspace import artefact_parent_for_entry

        entry = _resolve_workspace_entry(workspace_id)
        ws_root = artefact_parent_for_entry(entry)
        return aggregator.build_lead_status(ws_root, workspace_id)

    @app.get("/api/v1/workspaces/{workspace_id}/lead/detail", response_model=LeadDetail)
    async def get_workspace_lead_detail(workspace_id: str):
        """LEAD finding detail + audit tail (FTR-MSO-2026-0577).

        ``findings`` come from the SAME persisted tick ``GET .../lead``'s
        counts reflect — reading ``.mso/lead/state.json`` only, never
        triggering a fresh ``mso doctor`` pass (see
        ``aggregator.build_lead_detail`` / ``models.LeadDetail`` docstrings).
        ``available``/``reason`` mirror ``LeadStatus``'s shape, same as the
        sibling endpoint above.
        """
        from maestro.hub import aggregator
        from maestro.workspace import artefact_parent_for_entry

        entry = _resolve_workspace_entry(workspace_id)
        ws_root = artefact_parent_for_entry(entry)
        return aggregator.build_lead_detail(ws_root, workspace_id)

    @app.post("/api/v1/workspaces/{workspace_id}/lead/stand-down", response_model=ControlResult)
    async def stand_down_lead(workspace_id: str):
        """Stand the LEAD daemon down for a workspace (PLAN-PLN-MSO-2026-0584
        Dimension A). Deliberately UNGATED by tier — turning LEAD OFF must
        always be possible on a community-tier workspace, mirroring `mso
        lead stop`'s ungated shape (only turning it back ON, via `resume`
        below, is gated). Writes `lead.standDown: true` into workspace.json
        — durable, so it survives a daemon restart — and is a no-op if the
        daemon is not currently running: the next time it IS started, the
        first tick reads the flag and skips.
        """
        from maestro.lead.agent import set_stand_down
        from maestro.workspace import artefact_parent_for_entry, resolve_artefact_dir

        entry = _resolve_workspace_entry(workspace_id)
        mso = resolve_artefact_dir(artefact_parent_for_entry(entry))
        set_stand_down(mso, True)
        return ControlResult(
            ok=True, workspace_id=workspace_id, action="lead.stand-down",
            message="LEAD standing down — ticks will be skipped until resumed.",
        )

    @app.post("/api/v1/workspaces/{workspace_id}/lead/resume", response_model=ControlResult)
    async def resume_lead(workspace_id: str):
        """Resume a stood-down LEAD daemon. Gated (turning LEAD back ON,
        unlike stand-down) — on an insufficient tier this returns the SAME
        structured 409 `GET .../lead`'s `reason` already shows, never a bare
        403 (PLAN-PLN-MSO-2026-0584 Dimension A: 'the stand-down endpoints
        gate on auth.LEAD_AGENT_TIERS and return a structured 409 carrying
        the same sentence /capabilities shows')."""
        from maestro import auth
        from maestro.hub.aggregator import _LEAD_TIER_MESSAGE
        from maestro.lead.agent import set_stand_down
        from maestro.workspace import artefact_parent_for_entry, resolve_artefact_dir

        if not auth.has_tier(auth.LEAD_AGENT_TIERS):
            raise fastapi.HTTPException(status_code=409, detail=_LEAD_TIER_MESSAGE)

        entry = _resolve_workspace_entry(workspace_id)
        mso = resolve_artefact_dir(artefact_parent_for_entry(entry))
        set_stand_down(mso, False)
        return ControlResult(
            ok=True, workspace_id=workspace_id, action="lead.resume",
            message="LEAD resumed — ticks will run again.",
        )

    # ---- LEAD daemon lifecycle (FTR-MSO-2026-0786) --------------------------
    #
    # Same maestro.lead.control core `mso lead start|stop|restart` calls. Sync
    # `def`, not `async def`: the core holds order_retry.workspace_scope, and a
    # confirmed stop can wait several seconds for the process to exit — both
    # belong in the threadpool, never on the event loop.

    def _lead_control_response(workspace_id: str, result) -> ControlResult:
        if not result.ok:
            raise fastapi.HTTPException(status_code=500, detail=result.summary)
        return ControlResult(
            ok=True, workspace_id=workspace_id,
            action=f"lead.{result.action}", message=result.summary,
        )

    def _require_lead_launch_allowed() -> None:
        """start/restart gates, in the order an operator meets them: the Hub
        control tier (403, CONTROL_TIER_MESSAGE — the sentence
        /capabilities' `tier.reason` shows), the LEAD agent tier `mso lead
        start` itself requires, then the deployment (409 — a detached daemon
        launched from a container is not a host daemon)."""
        from maestro import auth
        from maestro.hub.aggregator import _LEAD_TIER_MESSAGE

        _require_control_tier()
        if not auth.has_tier(auth.LEAD_AGENT_TIERS):
            raise fastapi.HTTPException(status_code=403, detail=_LEAD_TIER_MESSAGE)
        if _is_observe_only():
            raise fastapi.HTTPException(status_code=409, detail=LEAD_START_UNAVAILABLE_MESSAGE)

    @app.post("/api/v1/workspaces/{workspace_id}/lead/start", response_model=ControlResult)
    def start_lead_daemon(workspace_id: str):
        """Start the resident LEAD daemon — ``mso lead start`` over HTTP.
        Idempotent: a live daemon is a 200 whose message says so."""
        from maestro.lead import control as _control

        _require_lead_launch_allowed()
        entry = _resolve_workspace_entry(workspace_id)
        artefact_root, workspace_root = _control.lead_paths_for_entry(entry)
        return _lead_control_response(
            workspace_id,
            _control.start_lead(artefact_root, workspace_root, actor=_control.ACTOR_HUB),
        )

    @app.post("/api/v1/workspaces/{workspace_id}/lead/stop", response_model=ControlResult)
    def stop_lead_daemon(workspace_id: str):
        """Stop the resident LEAD daemon — ``mso lead stop`` over HTTP. NEVER
        tier-gated, mirroring the CLI and `stand-down`: turning LEAD off must
        always be possible. Idempotent: a stopped daemon is a 200 whose
        message says so. A stop that could not be confirmed is a 500."""
        from maestro.lead import control as _control

        entry = _resolve_workspace_entry(workspace_id)
        artefact_root, _workspace_root = _control.lead_paths_for_entry(entry)
        return _lead_control_response(
            workspace_id, _control.stop_lead(artefact_root, actor=_control.ACTOR_HUB),
        )

    @app.post("/api/v1/workspaces/{workspace_id}/lead/restart", response_model=ControlResult)
    def restart_lead_daemon(workspace_id: str):
        """Restart the resident LEAD daemon — ``mso lead restart`` over HTTP.
        Gated like start. No replacement is launched unless the old daemon
        was confirmed stopped (500 otherwise)."""
        from maestro.lead import control as _control

        _require_lead_launch_allowed()
        entry = _resolve_workspace_entry(workspace_id)
        artefact_root, workspace_root = _control.lead_paths_for_entry(entry)
        return _lead_control_response(
            workspace_id,
            _control.restart_lead(artefact_root, workspace_root, actor=_control.ACTOR_HUB),
        )

    @app.post(
        "/api/v1/workspaces/{workspace_id}/lead/findings/{fingerprint}/ack",
        response_model=ControlResult,
    )
    async def ack_lead_finding(workspace_id: str, fingerprint: str, body: Optional[AckRequest] = None):
        """Acknowledge one open LEAD finding (PLAN-PLN-MSO-2026-0584 Dimension D).

        Deliberately UNGATED by tier, mirroring `stand-down` — acknowledging a
        finding the operator can already see is an observability action, not
        a resource-spending one. `body.days` is optional; when omitted it
        resolves to `maestro.patrol.state.ACK_TTL_DAYS_DEFAULT` (7) — there is
        no way to request a non-expiring ack through this endpoint, by design.
        A fingerprint with no matching open finding is a 404, not a silent
        no-op acknowledgement of nothing.
        """
        from maestro.patrol.state import UnknownFindingError, acknowledge_finding
        from maestro.workspace import artefact_parent_for_entry, resolve_artefact_dir

        _validate_fingerprint(fingerprint)
        entry = _resolve_workspace_entry(workspace_id)
        mso = resolve_artefact_dir(artefact_parent_for_entry(entry))
        body = body or AckRequest()
        try:
            ack = acknowledge_finding(
                mso, fingerprint, by=body.by or "hub", note=body.note or "",
                **({"ttl_days": body.days} if body.days else {}),
            )
        except UnknownFindingError as exc:
            raise fastapi.HTTPException(status_code=404, detail=str(exc))
        except ValueError as exc:
            raise fastapi.HTTPException(status_code=400, detail=str(exc))
        return ControlResult(
            ok=True, workspace_id=workspace_id, action="lead.ack",
            message=f"Acknowledged at severity={ack['severity']} — expires {ack['expiresAt']}.",
        )

    @app.post(
        "/api/v1/workspaces/{workspace_id}/lead/findings/{fingerprint}/unack",
        response_model=ControlResult,
    )
    async def unack_lead_finding(workspace_id: str, fingerprint: str):
        """Clear an acknowledgement early. Deliberately UNGATED, same reasoning
        as ``ack_lead_finding`` above. A no-op (not an error) when there was
        nothing to clear — `ok` still reports True, `message` says so."""
        from maestro.patrol.state import unacknowledge_finding
        from maestro.workspace import artefact_parent_for_entry, resolve_artefact_dir

        _validate_fingerprint(fingerprint)
        entry = _resolve_workspace_entry(workspace_id)
        mso = resolve_artefact_dir(artefact_parent_for_entry(entry))
        existed = unacknowledge_finding(mso, fingerprint)
        return ControlResult(
            ok=True, workspace_id=workspace_id, action="lead.unack",
            message="Un-acknowledged." if existed else "No acknowledgement found — nothing to do.",
        )

    @app.post(
        "/api/v1/workspaces/{workspace_id}/lead/findings/{fingerprint}/run",
        response_model=RunResult,
    )
    def run_lead_finding(workspace_id: str, fingerprint: str):
        """Run the mapped action behind a LEAD finding's suggested command
        (FTR-MSO-2026-0631) — the Hub's "Run" button.

        NOT a command executor: ``maestro.lead.run_verbs.parse_verb()``
        matches the finding's persisted ``suggestedCommand`` against a
        closed, enumerated list of regex patterns; a command that doesn't
        match is refused with a 400 here (the frontend never renders Run for
        one — this is the defence-in-depth backstop, matching the
        capabilities-gate pattern every other mutating control uses). Each
        matched verb's handler calls the SAME function or CLI invocation an
        existing tier-gated endpoint already uses — see run_verbs.py's
        module docstring for the map.

        Tier-gated exactly like dispatch/stop/sweep/review (`_require_control_
        tier()`) — the frontend is expected to have already consulted
        `GET /api/v1/capabilities`'s `tier`/`sweep`/`orderRetry` shape before
        rendering Run as enabled; this call is the backstop, not the primary
        gate. The D6 must_not ceiling is a SEPARATE, unconditional check
        (`run_verbs.is_forbidden`) — refused there is reported as outcome
        "refused" in a 200 response (an expected, renderable business
        outcome), never a bare exception.

        BUG-MSO-2026-0634 F1/F2: re-evaluation calls ``maestro.patrol.
        run_single_check()`` for ONLY the check that produced this finding —
        never ``maestro.lead.agent.run_once()`` (a full LEAD tick). A full
        tick dispatches D7 act-and-inform actions (actively dangerous per
        BUG-MSO-2026-0633, which is why LEAD is stood down on this very
        workspace) and does an unlocked read-modify-write of
        patrol-state.json / the LEAD daemon's own state.json concurrently
        with a possibly-running daemon. ``run_single_check`` touches neither
        file and dispatches nothing. A check that cannot be confirmed
        (unknown/disabled/raising) reports ``verified=False`` and this
        endpoint FAILS CLOSED — "ran, could not confirm" — never the old
        swallowed-exception path that silently reported "condition cleared"
        for a re-evaluation that verified nothing.

        BUG-MSO-2026-0662 F1: the SAME check-re-run PRINCIPLE also runs ONCE
        MORE, before the handler, as a pre-flight condition check — a
        persisted finding is only as fresh as the ``state.json`` it was read
        from, which nothing refreshes while the LEAD daemon is stood down
        (this workspace's normal state) or simply hasn't ticked recently.
        Without it, a stale ``dispatcher.heartbeat`` finding could survive
        long past the real dispatcher recovering on its own, and clicking
        Run would fire ``mso cleanup`` against a NOW-HEALTHY dispatcher —
        killing whatever crews it has live — with the post-hoc reevaluate
        below then honestly reporting "condition cleared" only because the
        action itself just cleared it by destroying the healthy thing it
        found. The pre-check fails CLOSED identically to the post-hoc one:
        unconfirmable or already-cleared both refuse rather than run.

        BUG-MSO-2026-0670 F1: the pre-flight check itself runs via
        ``_run_single_check_subprocess`` — a KILLABLE OS SUBPROCESS bounded
        by a timeout — NOT the ``run_single_check`` primitive directly on
        this request thread the way it first shipped. The gh-backed check
        behind ``voyage.reconcile`` findings otherwise held the
        process-global ``order_retry._SCOPE_LOCK`` for an unbounded gh round
        trip, blocking every other concurrent Run click and order-retry POST
        on this Hub for as long as gh took to answer.

        BUG-MSO-2026-0686 F5: the post-hoc reevaluate below is NOT unaffected
        — the claim that the one gh-backed check "always short-circuits via
        precomputed from the handler's own real work and never falls through
        to it" was false whenever the finding's own ``subjectId`` is empty or
        missing: ``_handle_voyage_reconcile`` only sets ``still_open``/
        ``verified`` (and therefore ``precomputed``) when ``_subject_id`` is
        non-empty, so an empty subject fell through to this branch and called
        ``run_single_check`` DIRECTLY on the request thread — re-holding
        ``_SCOPE_LOCK`` across an unbounded gh round trip, exactly the hazard
        BUG-MSO-2026-0670 F1 was filed to close. This branch therefore now
        routes through the SAME bounded ``_run_single_check_subprocess`` the
        pre-flight check uses, never the raw ``run_single_check`` primitive,
        for every check this endpoint re-evaluates.

        Sync ``def``, not ``async def`` — order.retry's handler enters
        ``order_retry.workspace_scope()``, which (per that module's own
        docstring) must run in FastAPI's threadpool, not the event loop.
        """
        _validate_fingerprint(fingerprint)
        _require_control_tier()

        from maestro.lead import run_verbs
        from maestro.lead.agent import _write_lifecycle_event
        from maestro.lead.agent import load_state as _load_lead_state
        from maestro.workspace import (
            artefact_parent_for_entry, product_repo_for_entry, resolve_artefact_dir,
        )

        entry = _resolve_workspace_entry(workspace_id)
        try:
            ws_root = artefact_parent_for_entry(entry)
            mso = resolve_artefact_dir(ws_root)
            product_repo = product_repo_for_entry(entry)
        except OSError:
            raise fastapi.HTTPException(status_code=503, detail=STALE_MOUNT_MESSAGE)

        state = _load_lead_state(mso)
        found = next(
            (
                e for e in (state.get("lastFindingsDetail") or [])
                if isinstance(e, dict) and e.get("fingerprint") == fingerprint
            ),
            None,
        )
        if found is None:
            raise fastapi.HTTPException(
                status_code=404,
                detail="No open LEAD finding with this fingerprint — it may already be resolved.",
            )

        command = found.get("suggestedCommand")
        match = run_verbs.parse_verb(command) if command else None
        if match is None:
            raise fastapi.HTTPException(
                status_code=400,
                detail="This finding's suggested command is not a runnable action — copy it and run it yourself.",
            )

        action_id = match.spec.id

        try:
            from maestro.identity.auth import resolve_caller
            who = resolve_caller(ws_root)
        except Exception:
            who = "hub"

        def _finish(
            *, outcome: str, message: str, ok: bool, reevaluate: bool,
            precomputed: "Optional[tuple]" = None,
        ) -> RunResult:
            _write_lifecycle_event(
                mso, "LEAD_ACTION",
                f"action={action_id} trigger=human-run outcome={outcome} who={who} "
                f"finding={fingerprint} detail={message}",
            )
            try:
                from maestro.audit import get_audit_log
                get_audit_log(ws_root).append(
                    action=f"lead.run.{action_id}",
                    target=fingerprint,
                    result=outcome,
                    metadata={"checkId": found.get("checkId", ""), "command": command},
                    actor=who,
                )
            except Exception:
                pass

            # BUG-MSO-2026-0648 F2: verified starts FALSE, not True — a
            # refused/failed outcome (reevaluate=False, precomputed=None)
            # falls through both branches below untouched, and no check has
            # actually run for it. The old True default meant EVERY refused
            # or failed response claimed verified=true/stillOpen=true —
            # a confirmed re-check that never happened — contradicting
            # RunResult's own documented contract and BUG-MSO-2026-0634 F2's
            # fail-closed principle. still_open stays True (unknown/unchanged,
            # never optimistically cleared); only precomputed or an actual
            # reevaluate run may set verified=True below.
            still_open, condition_cleared, verified = True, False, False
            if precomputed is not None:
                # BUG-MSO-2026-0643 F3: the handler already knows this from
                # the REAL work it just did (see run_verbs.RunOutcome's
                # still_open/verified docstring) — use it directly rather
                # than spending a second re-evaluation call. Load-bearing for
                # voyage.reconcile, whose re-evaluation check
                # (voyages.merged-not-archived) is itself gh-backed: without
                # this, one Run click fired the gh-backed sweep twice.
                still_open, verified = precomputed
                condition_cleared = bool(verified) and not still_open
            elif reevaluate:
                # BUG-MSO-2026-0686 F5: routed through the same BOUNDED,
                # KILLABLE subprocess the pre-flight check uses — never
                # ``run_single_check`` directly on this request thread. An
                # empty/missing subjectId (this handler's defensive
                # fallback) used to fall through here for the gh-backed
                # ``voyages.merged-not-archived`` check, re-holding
                # ``order_retry._SCOPE_LOCK`` across an unbounded gh round
                # trip — exactly what BUG-MSO-2026-0670 F1 was filed to stop.
                check_id = found.get("checkId") or ""
                subject_id = found.get("subjectId") or ""
                if not check_id:
                    verified = False
                else:
                    single = _run_single_check_subprocess(mso, check_id, subject_id, product_repo)
                    verified = single.verified
                    if verified:
                        still_open = single.still_open
                        condition_cleared = not still_open
                    # verified is False: leave still_open=True,
                    # condition_cleared=False — fail CLOSED, never an
                    # optimistic "cleared" for a check that couldn't confirm.

            return RunResult(
                ok=ok, action=action_id, outcome=outcome, message=message,
                conditionCleared=condition_cleared, stillOpen=still_open,
                verified=verified,
            )

        if run_verbs.is_forbidden(match.spec, product_repo):
            return _finish(
                outcome="refused",
                message=(
                    f"'{action_id}' is on the LEAD's must_not list — this "
                    "requires explicit Captain approval and cannot be run "
                    "from the Hub."
                ),
                ok=False, reevaluate=False,
            )

        if action_id == "voyage.reconcile":
            blocked = _sweep_unavailable_reason()
            if blocked:
                return _finish(outcome="refused", message=blocked, ok=False, reevaluate=False)

        # BUG-MSO-2026-0634 F4: dispatcher.cleanup needs the SAME
        # observe-only gate `dispatch_workspace` already applies — a
        # containerized/observe-only Hub has no usable host process and
        # would run cleanup against the mounted `.mso` while crews are still
        # live on the HOST (BUG-MSO-2026-0395's failure mode). voyage.
        # reconcile was already gated (above); dispatcher.cleanup was not.
        if action_id == "dispatcher.cleanup":
            if _is_observe_only():
                return _finish(outcome="refused", message=OBSERVE_ONLY_MESSAGE, ok=False, reevaluate=False)

        # BUG-MSO-2026-0662 F1: re-confirm the finding's condition BEFORE
        # running the handler, not only after. A LEAD finding is only as
        # fresh as the state.json it was read from, and that file is
        # refreshed exclusively by daemon ticks — while the daemon is stood
        # down (this workspace's normal state; see LEAD_STAND_DOWN) or has
        # simply not ticked recently, a persisted finding can describe a
        # condition that no longer holds. Concretely: a stale
        # dispatcher.heartbeat finding sits in state.json; the dispatcher
        # recovers on its own; an operator clicks Run; without this check
        # `mso cleanup` would fire against a NOW-HEALTHY dispatcher and kill
        # live crews, and the post-hoc reevaluate below would then honestly
        # report "condition cleared" — because the action itself cleared it
        # by destroying the healthy thing it found. Re-running the SAME
        # check (never a full LEAD tick — see the module docstring above on
        # why that would be actively dangerous here too) before the mutation
        # is the only way "condition cleared" is ever a meaningful claim.
        #
        # Fails CLOSED on an unconfirmable check (unknown/disabled/raising —
        # same semantics as the post-hoc reevaluate branch below): if the
        # pre-check cannot positively confirm the condition still holds, the
        # safer default is to refuse, not to proceed on stale trust.
        #
        # BUG-MSO-2026-0670 F1: run via ``_run_single_check_subprocess`` — a
        # KILLABLE OS SUBPROCESS bounded by ``_PRE_CHECK_TIMEOUT_SECONDS`` —
        # never ``run_single_check()`` called directly here on the request
        # thread. The direct call was fine for the cheap, disk-only checks
        # (dispatcher.heartbeat, voyages.stalled-order-deadlock) but for the
        # one gh-backed check reachable through this endpoint
        # (voyages.merged-not-archived, which runs a full
        # ``run_housekeeping_sweep(dry_run=True)``) it held the
        # PROCESS-GLOBAL ``order_retry._SCOPE_LOCK`` — on THIS Hub process —
        # for an unbounded gh round trip, blocking every concurrent Run click
        # and order-retry POST for as long as gh took to answer. See
        # ``_run_single_check_subprocess``'s own docstring for the full
        # before/after trace and the latency this fix deliberately trades
        # for it (bounded to this one click, never to any other caller).
        pre_check_id = found.get("checkId") or ""
        pre_subject_id = found.get("subjectId") or ""
        pre_check = None
        if pre_check_id:
            try:
                pre_check = _run_single_check_subprocess(
                    mso, pre_check_id, pre_subject_id, product_repo,
                )
            except Exception:  # noqa: BLE001 — fail closed, never crash the endpoint
                pre_check = None
        if pre_check is None or not pre_check.verified:
            # BUG-MSO-2026-0672 F2: `pre_check.reason` used to be computed by
            # `_run_single_check_subprocess` (or `run_single_check` before
            # it) and then discarded here — every refusal on this branch
            # returned the SAME fixed generic sentence regardless of why the
            # pre-check couldn't confirm. That made "the check genuinely
            # could not confirm the condition" (e.g. it raised, or is
            # disabled) indistinguishable from "the subprocess cannot start
            # on this deployment at all" (BUG-MSO-2026-0672 F1(a)) — an
            # operator hitting F1(a) saw a refusal that told them nothing
            # about why. Surface the real reason when one was captured; the
            # `except Exception` branch above still leaves `pre_check` as
            # `None`, with no reason to report, so the generic sentence
            # remains the fallback for a truly unexpected failure.
            reason = (pre_check.reason if pre_check is not None else "").strip()
            detail = f" ({reason})" if reason else ""
            return _finish(
                outcome="refused",
                message=(
                    "Could not re-confirm this finding's condition just before "
                    "running it — refusing for safety rather than acting on "
                    f"possibly-stale state{detail}. Re-check the fleet and try again."
                ),
                ok=False, reevaluate=False,
            )
        if not pre_check.still_open:
            return _finish(
                outcome="refused",
                message=(
                    "This finding's condition is no longer present — nothing "
                    "to do. The board will catch up on the next patrol tick."
                ),
                ok=False, reevaluate=False,
                precomputed=(False, True),
            )

        # BUG-MSO-2026-0643 F3: pass the finding's own subject_id through so a
        # handler that can determine the post-run condition from its OWN real
        # work (voyage.reconcile — see run_verbs._handle_voyage_reconcile) can
        # do so without a second, redundant re-evaluation call. Every other
        # handler ignores an unrecognised dict key.
        handler_args = dict(match.args)
        handler_args["_subject_id"] = pre_subject_id

        try:
            result = match.spec.handler(handler_args, mso, product_repo)
        except Exception as exc:  # noqa: BLE001 — must report, never crash the endpoint
            return _finish(
                outcome="failed", message=f"{type(exc).__name__}: {exc}",
                ok=False, reevaluate=False,
            )

        precomputed = (
            (result.still_open, result.verified) if result.verified is not None else None
        )
        return _finish(
            outcome="accepted" if result.ok else "failed",
            message=result.message, ok=result.ok, reevaluate=result.ok,
            precomputed=precomputed,
        )

    # -----------------------------------------------------------------------
    # Capabilities (FTR-MSO-2026-0489) — declare BEFORE the click, never 409
    # -----------------------------------------------------------------------

    @app.get("/api/v1/capabilities", response_model=CapabilityMap)
    async def get_capabilities():
        """Declare which mutating actions this Hub deployment can perform.

        PLAN-PLN-MSO-2026-0468 §4.5, generalising the BUG-MSO-2026-0440 sweep
        fix: an action that cannot work here must be disabled WITH ITS REASON
        before the click, never discovered as a post-hoc 409. This endpoint is
        deliberately workspace-independent (dispatch/sweep availability is a
        property of THIS BACKEND's deployment, not of any one workspace) and
        does not touch the poller, so it is cheap enough to consult before
        rendering every control button.

        The server-side 409s on dispatch/stop/sweep/review remain as a
        defence-in-depth backstop — this endpoint is the primary mechanism,
        not a replacement for it. Reason strings are the SAME module constants
        those 409s raise, so the explanation shown before the click and the
        one raised if it happens anyway can never disagree.

        FTR-MSO-2026-0617 (PLAN-PLN-MSO-2026-0556 §4.3) extends the map to the
        AUTHORING actions — voyageCreate / orderCreate / orderEdit / orderSkip.
        That is the whole mechanism behind §7's interim posture for
        BUG-MSO-2026-0555: a control whose endpoint does not exist stays
        visible, stops claiming to create anything, and names the CLI verb that
        works — and when the endpoint lands, only this function changes.

        FTR-MSO-2026-0622 is that promise being kept for two of the four.
        ``orderEdit`` and ``orderSkip`` now back real endpoints (PLAN Order 6:
        ``PATCH /orders/{id}``, ``POST /orders/{id}/skip|unskip``) and report
        available on a writable plane; ``voyageCreate`` and ``orderCreate``
        still do not exist and still say so. The frontend needed no change for
        the flip, which is the property §7 chose this mechanism for.
        FTR-MSO-2026-0721: the construction itself lives in the module-level
        :func:`build_capability_map`, because the blockage endpoints resolve
        each of their options against the SAME map. A second construction here
        would be a second answer to "can I do this", which is precisely what
        this endpoint exists to make impossible.
        """
        return build_capability_map()

    # Charts — read-only graph X-ray (FTR-MSO-2026-0496, PLAN-VOY-MSO-2026-0143
    # Phase 1 part 2). Community tier: visualization must work without a
    # licence (ruling 0a#3), gated through auth.has_tier and nothing else —
    # never touches token validation directly (ruling §6).
    # -----------------------------------------------------------------------

    def _require_chart_tier():
        from maestro import auth
        if not auth.has_tier(auth.CHART_VIEW_TIERS):
            raise fastapi.HTTPException(
                status_code=403,
                detail="Maestro chart visualization is unavailable for this licence state.",
            )

    @app.get("/api/v1/workspaces/{workspace_id}/voyages/{voyage_id}/chart", response_model=ChartResponse)
    async def get_voyage_chart(workspace_id: str, voyage_id: str):
        """Compiled chart for one voyage — same compiler and wire shape as
        `mso chart show --format json` (maestro.core.charts.Chart.to_dict()),
        so the CLI and this read-only Hub view can never disagree."""
        _require_chart_tier()
        _validate_order_id(voyage_id)
        from maestro.core import charts as _charts
        from maestro.workspace import artefact_parent_for_entry, resolve_artefact_dir

        entry = _resolve_workspace_entry(workspace_id)
        mso_dir = resolve_artefact_dir(artefact_parent_for_entry(entry))
        chart = _charts.compile_voyage_chart(voyage_id, workspace_dir=mso_dir)
        return ChartResponse(**chart.to_dict())

    # -----------------------------------------------------------------------
    # Dispatch control endpoints (Feature B) — localhost-only by binding
    # -----------------------------------------------------------------------

    def _resolve_workspace_entry(workspace_id: str) -> dict:
        """Return the raw registry v2 entry for *workspace_id* or raise 404.

        Callers derive paths via ``maestro.workspace.artefact_parent_for_entry``
        (artefacts: voyages/orders/queues/review/usage/logs) and
        ``product_repo_for_entry`` (dispatch/stop subprocess cwd, branch/PR
        context) — never read ``entry["path"]`` directly (FTR-MSO-2026-0369).
        """
        import maestro.registry as registry
        projects = registry.list_projects()
        if workspace_id not in projects:
            raise fastapi.HTTPException(
                status_code=404, detail=f"Workspace '{workspace_id}' not found")
        return projects[workspace_id]

    def _require_control_tier():
        """Tier gate matching the CLI `hub` command — Team/Enterprise only.

        Uses auth.has_tier (non-exiting) so an HTTP 403 is returned instead of
        the CLI's sys.exit. has_tier returns True when MAESTRO_SKIP_AUTH=1.
        """
        from maestro import auth
        if not auth.has_tier(auth.HUB_TIERS):
            raise fastapi.HTTPException(status_code=403, detail=CONTROL_TIER_MESSAGE)

    @app.post("/api/v1/workspaces/{workspace_id}/dispatch", response_model=ControlResult)
    async def dispatch_workspace(workspace_id: str):
        """Start the dispatcher for a workspace as a detached background process."""
        from maestro.hub import aggregator
        from maestro.workspace import (
            artefact_parent_for_entry, product_repo_for_entry, resolve_artefact_dir,
        )

        _require_control_tier()
        # Observe-only (containerized) backends cannot launch a usable host
        # dispatcher — fail loudly with a structured 409 the UI surfaces,
        # instead of spawning a no-op dispatcher inside the container and
        # returning a misleading "starting" (BUG-MSO-2026-0395).
        if _is_observe_only():
            raise fastapi.HTTPException(status_code=409, detail=OBSERVE_ONLY_MESSAGE)
        # Registry/workspace reads can raise a raw OSError (e.g. Errno 5 on a
        # stale Docker bind-mount after a Docker Desktop restart). Degrade to a
        # 503 with a "restart containers" hint rather than leaking a traceback.
        try:
            entry = _resolve_workspace_entry(workspace_id)
            ws_root = artefact_parent_for_entry(entry)
            mso = resolve_artefact_dir(ws_root)
            # The dispatch subprocess's cwd must be the PRODUCT repo — in
            # solo/shared artefact mode ws_root/mso are the artefact repo, which
            # carries no source checkout for git worktree/branch operations to
            # run against (FTR-MSO-2026-0369). MAESTRO_DIR below still points the
            # dispatcher at the correct artefact plane regardless of cwd.
            product_repo = product_repo_for_entry(entry)
        except OSError:
            raise fastapi.HTTPException(status_code=503, detail=STALE_MOUNT_MESSAGE)

        # Don't spawn a duplicate if one is already running.
        try:
            if aggregator._dispatcher_running(mso):
                return ControlResult(
                    ok=True, workspace_id=workspace_id, action="dispatch",
                    message="Dispatcher already running",
                )
        except Exception:
            pass

        # BUG-MSO-2026-0800: this used to be a literal `--max-crews 5`, so the
        # Hub's Dispatch ignored every configured value. Resolve with the same
        # rule `mso dispatch` uses; the community cap still applies inside
        # run_dispatcher().
        from maestro.core.dispatch_settings import resolve_dispatch_limits

        limits = resolve_dispatch_limits(mso)
        _spawn_dispatcher(mso, product_repo, limits.argv())
        return ControlResult(
            ok=True, workspace_id=workspace_id, action="dispatch",
            message="Dispatcher starting",
        )

    def _spawn_dispatcher(mso, product_repo, dispatch_argv):
        """Launch ``mso dispatch <dispatch_argv>`` as a detached host process.

        The ONE spawn used by both the dispatch endpoint and resume's relaunch
        (FTR-MSO-2026-0789), so a Hub resume starts the dispatcher exactly the
        way Dispatch does. Callers own the tier + observe-only gates AND their
        own argv — dispatch resolves live settings (BUG-MSO-2026-0800), resume
        passes the paused run's own recorded args back verbatim (FTR-0789),
        and this function must not override either with its own opinion.
        """
        import os
        import subprocess
        import sys

        env = {**os.environ, "MAESTRO_DIR": str(mso)}
        cmd = [sys.executable, "-m", "maestro.cli", "dispatch", *dispatch_argv]
        kwargs = dict(
            cwd=str(product_repo),
            env=env,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        if os.name == "nt":
            DETACHED_PROCESS = 0x00000008
            CREATE_NEW_PROCESS_GROUP = 0x00000200
            kwargs["creationflags"] = DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
            kwargs["close_fds"] = True
        else:
            kwargs["start_new_session"] = True
        subprocess.Popen(cmd, **kwargs)

    def _resolve_pause_workspace(workspace_id: str):
        """``(ws_root, mso, product_repo)`` for a pause/resume call, or 404/503."""
        from maestro.workspace import (
            artefact_parent_for_entry, product_repo_for_entry, resolve_artefact_dir,
        )
        try:
            entry = _resolve_workspace_entry(workspace_id)
            ws_root = artefact_parent_for_entry(entry)
            return ws_root, resolve_artefact_dir(ws_root), product_repo_for_entry(entry)
        except OSError:
            raise fastapi.HTTPException(status_code=503, detail=STALE_MOUNT_MESSAGE)

    def _require_fleet_capability(ws_root) -> None:
        """`fleet.dispatch` identity gate — the same capability `mso pause` /
        `mso resume` require. A no-op outside governed workspaces."""
        from maestro.identity.gate import CapabilityDenied, require_capability
        try:
            require_capability("fleet.dispatch", workspace=ws_root)
        except CapabilityDenied as exc:
            raise fastapi.HTTPException(status_code=403, detail=str(exc))

    def _audit_fleet(ws_root, action: str, target: str, metadata: dict) -> None:
        """Best-effort audit record mirroring the CLI's; never fails the call."""
        try:
            from maestro.audit import get_audit_log
            get_audit_log(ws_root).append(action, target=target, metadata=metadata)
        except Exception:
            pass

    @app.post("/api/v1/workspaces/{workspace_id}/pause", response_model=ControlResult)
    async def pause_workspace(workspace_id: str):
        """Drain the fleet — ``mso pause`` over HTTP (FTR-MSO-2026-0789).

        Claims no new work; running crews finish untouched and the dispatcher
        exits once drained. DRAIN, not freeze: Stop is the kill-and-salvage
        verb. Writes through the SAME ``fleet_pause.request_pause`` core the
        CLI uses. Gated like dispatch/stop: tier 403, observe-only 409 (the
        request must name the live dispatcher's PID + create time, which a
        containerised Hub cannot see). Idempotent; no live dispatcher is a 200
        whose message says nothing was paused.
        """
        from maestro.core import fleet_pause

        _require_control_tier()
        if _is_observe_only():
            raise fastapi.HTTPException(status_code=409, detail=FLEET_PAUSE_UNAVAILABLE_MESSAGE)
        ws_root, mso, _product_repo = _resolve_pause_workspace(workspace_id)
        _require_fleet_capability(ws_root)

        live = fleet_pause.live_dispatcher(mso)
        if live is None:
            existing = fleet_pause.read_pause(mso)
            message = "No dispatcher running — nothing to pause"
            if existing and existing.get("status") == fleet_pause.PAUSED:
                message += f"; the fleet is already {fleet_pause.describe_paused(existing)}"
            return ControlResult(ok=True, workspace_id=workspace_id, action="pause",
                                 message=message)
        pid, create_time = live

        try:
            _record, newly = fleet_pause.request_pause(mso, pid, create_time, actor="hub")
        except fleet_pause.PauseStateError as exc:
            raise fastapi.HTTPException(
                status_code=500, detail=f"Could not record the pause request: {exc}")

        if newly:
            fleet_pause.write_event(
                mso, fleet_pause.EVENT_PAUSE_REQUESTED,
                f"Pause requested for dispatcher PID {pid} by hub — claiming no new work, "
                f"running crews finish untouched (FTR-MSO-2026-0498)",
            )
            _audit_fleet(ws_root, "fleet.pause", workspace_id, {"dispatcher_pid": pid})
            lead = f"Pause requested — dispatcher PID {pid} claims no new work"
        else:
            lead = f"Pause already requested for dispatcher PID {pid}"
        return ControlResult(
            ok=True, workspace_id=workspace_id, action="pause",
            message=f"{lead}; {fleet_pause.describe_pausing(mso)}",
        )

    @app.post("/api/v1/workspaces/{workspace_id}/resume", response_model=ControlResult)
    async def resume_workspace(workspace_id: str):
        """Resume a paused fleet — ``mso resume`` over HTTP (FTR-MSO-2026-0789).

        PAUSING + live dispatcher: the request is withdrawn
        (``fleet_pause.cancel_pause``) and that dispatcher resumes claiming on
        its next tick, no restart. PAUSED (or a pause whose dispatcher died
        mid-drain): the dispatcher is relaunched through the dispatch
        endpoint's own spawn with the recorded ``dispatchArgs``; its startup
        clears the pause file and emits FLEET_RESUMED. Gated like dispatch:
        tier 403, observe-only 409.
        """
        from maestro.core import fleet_pause

        _require_control_tier()
        if _is_observe_only():
            raise fastapi.HTTPException(status_code=409, detail=FLEET_RESUME_UNAVAILABLE_MESSAGE)
        ws_root, mso, product_repo = _resolve_pause_workspace(workspace_id)
        _require_fleet_capability(ws_root)

        record, error = fleet_pause.read_pause_state(mso)
        live = fleet_pause.live_dispatcher(mso)

        if live is not None:
            if (record and record.get("status") == fleet_pause.PAUSING
                    and fleet_pause.cancel_pause(mso)):
                fleet_pause.write_event(
                    mso, fleet_pause.EVENT_PAUSE_CANCELLED,
                    f"Pause for dispatcher PID {live[0]} cancelled by hub — dispatch "
                    f"resumes on its next tick, no restart (FTR-MSO-2026-0498)",
                )
                _audit_fleet(ws_root, "fleet.resume", workspace_id,
                             {"mode": "cancel", "dispatcher_pid": live[0]})
                return ControlResult(
                    ok=True, workspace_id=workspace_id, action="resume",
                    message=f"Pause cancelled — dispatcher PID {live[0]} resumes "
                            f"claiming work on its next tick",
                )
            return ControlResult(
                ok=True, workspace_id=workspace_id, action="resume",
                message=f"Dispatcher PID {live[0]} is running and not pausing — nothing to resume",
            )

        if record is None:
            message = "Nothing is paused — start the fleet with Dispatch"
            if error:
                message = f"Ignoring an unusable pause file ({error}). {message}"
            return ControlResult(ok=True, workspace_id=workspace_id, action="resume",
                                 message=message)

        merged = fleet_pause.resolve_dispatch_args(record)
        _audit_fleet(ws_root, "fleet.resume", workspace_id, {"mode": "relaunch", **merged})
        _spawn_dispatcher(mso, product_repo, [
            "--max-crews", str(merged["maxCrews"]),
            "--stagger-delay", str(merged["staggerDelay"]),
            "--timeout", str(merged["timeout"]),
            "--max-turns", str(merged["maxTurns"]),
        ])
        if record.get("status") == fleet_pause.PAUSED:
            message = f"Resuming — {fleet_pause.describe_paused(record).split(' — ')[0]}; dispatcher starting"
        else:
            message = ("The pause was interrupted (dispatcher exited mid-drain) — "
                       "relaunching; normal recovery applies")
        return ControlResult(ok=True, workspace_id=workspace_id, action="resume",
                             message=message)

    @app.post("/api/v1/workspaces/{workspace_id}/stop", response_model=ControlResult)
    async def stop_workspace(workspace_id: str):
        """Stop (hold) the dispatcher + crews for a workspace via scoped cleanup."""
        import os
        import subprocess
        import sys
        from maestro.workspace import (
            artefact_parent_for_entry, product_repo_for_entry, resolve_artefact_dir,
        )

        _require_control_tier()
        try:
            entry = _resolve_workspace_entry(workspace_id)
            ws_root = artefact_parent_for_entry(entry)
            mso = resolve_artefact_dir(ws_root)
            product_repo = product_repo_for_entry(entry)
        except OSError:
            raise fastapi.HTTPException(status_code=503, detail=STALE_MOUNT_MESSAGE)

        env = {**os.environ, "MAESTRO_DIR": str(mso)}
        try:
            # BUG-MSO-2026-0682 F2: `--maestro-dir` must be an explicit argv
            # value, not just the `MAESTRO_DIR` env kwarg below — `cmd_cleanup`
            # resolves via `find_workspace()`, which deliberately IGNORES
            # `MAESTRO_DIR` (BUG-MSO-2026-0425) and instead walks up from cwd.
            # `run_verbs._handle_dispatcher_cleanup` already fixed this exact
            # gap for the LEAD Run button (BUG-MSO-2026-0675 F1); this endpoint
            # (the Hub's Stop button) spawns the identical command and was
            # left behind. `env=` MAESTRO_DIR is kept as a harmless secondary
            # signal for anything else in the subprocess that reads it
            # ambiently — it is not what makes this resolve correctly.
            subprocess.run(
                [sys.executable, "-m", "maestro.cli", "cleanup", "--no-backup",
                 "--maestro-dir", str(mso)],
                cwd=str(product_repo),
                env=env,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=60,
            )
        except subprocess.TimeoutExpired:
            return ControlResult(
                ok=False, workspace_id=workspace_id, action="stop",
                message="Cleanup timed out",
            )
        return ControlResult(
            ok=True, workspace_id=workspace_id, action="stop",
            message="Dispatcher stopped",
        )

    @app.post("/api/v1/workspaces/{workspace_id}/sweep", response_model=SweepResult)
    async def sweep_workspace(workspace_id: str, dry_run: bool = False):
        """Run the housekeeping reconcile for a workspace (FTR-MSO-2026-0426).

        The human approves and merges the voyage PR most of the time, so
        Maestro never observes the merge event — housekeeping has to be
        PULL-based. This is that pull: validate every voyage's PR state,
        archive the merged ones, annotate merge metadata, reconcile
        archived-but-not-COMPLETE orders, and report what was REFUSED and why.

        Runs ``mso voyage reconcile --json`` as a subprocess so the button and
        the CLI execute literally the same code path (``run_housekeeping_sweep``)
        and cannot drift. Does NOT require a running dispatcher.

        Same protections as the other control endpoints: Team/Enterprise tier
        gate, the shared CORS/origin allow-list, the observe-only 409 (merge
        detection needs git + gh against the product repo, which a containerized
        observe-only backend does not have) and the stale-mount 503.
        """
        import json as _json
        import os
        import subprocess
        import sys
        from maestro.workspace import (
            artefact_parent_for_entry, product_repo_for_entry, resolve_artefact_dir,
        )

        _require_control_tier()
        # BUG-MSO-2026-0440: gate on what HOUSEKEEPING needs (gh), not on
        # whether a dispatcher could be spawned (Claude CLI).
        _sweep_blocked = _sweep_unavailable_reason()
        if _sweep_blocked:
            raise fastapi.HTTPException(status_code=409, detail=_sweep_blocked)
        try:
            entry = _resolve_workspace_entry(workspace_id)
            ws_root = artefact_parent_for_entry(entry)
            mso = resolve_artefact_dir(ws_root)
            # cwd must be the PRODUCT repo: merge detection probes git refs and
            # resolves `gh` against the product remote. In solo/shared artefact
            # mode the artefact repo has neither.
            product_repo = product_repo_for_entry(entry)
        except OSError:
            raise fastapi.HTTPException(status_code=503, detail=STALE_MOUNT_MESSAGE)

        # BUG-MSO-2026-0682 F2: `--maestro-dir` must be an explicit argv
        # value — `cmd_voyage`'s `reconcile` action resolves via
        # `find_workspace()`, which deliberately IGNORES `MAESTRO_DIR`
        # (BUG-MSO-2026-0425) and instead walks up from cwd.
        # `run_verbs._handle_voyage_reconcile` already fixed this exact gap
        # for the LEAD Run button (BUG-MSO-2026-0675 F1); this endpoint (the
        # Hub's sweep/broom button) spawns the identical command and was left
        # behind. `env=` MAESTRO_DIR below is kept as a harmless secondary
        # signal for anything else in the subprocess that reads it ambiently
        # — it is not what makes this resolve correctly.
        cmd = [sys.executable, "-m", "maestro.cli", "voyage", "reconcile", "--json",
               "--maestro-dir", str(mso)]
        if dry_run:
            cmd.append("--dry-run")
        try:
            proc = subprocess.run(
                cmd,
                cwd=str(product_repo),
                env={**os.environ, "MAESTRO_DIR": str(mso)},
                stdin=subprocess.DEVNULL,
                capture_output=True,
                text=True,
                timeout=300,
            )
        except subprocess.TimeoutExpired:
            raise fastapi.HTTPException(
                status_code=504,
                detail="Housekeeping sweep timed out after 5 minutes (a PR "
                       "lookup may be hanging). No changes were reported.")

        if proc.returncode != 0:
            detail = (proc.stderr or proc.stdout or "").strip()[-500:]
            raise fastapi.HTTPException(
                status_code=500,
                detail=f"Housekeeping sweep failed: {detail or 'unknown error'}")
        try:
            # The CLI prints the JSON report last; tolerate any leading output.
            out = proc.stdout or ""
            payload = _json.loads(out[out.index("{"):])
        except (ValueError, _json.JSONDecodeError):
            raise fastapi.HTTPException(
                status_code=500,
                detail="Housekeeping sweep produced no readable report.")

        archived = payload.get("archived", 0)
        annotated = payload.get("annotated", 0)
        refusals = payload.get("refusals", []) or []
        verb = "would be " if dry_run else ""
        parts = [f"{archived} voyage(s) {verb}archived",
                 f"{annotated} {verb}annotated"]
        if refusals:
            parts.append(f"{len(refusals)} left untouched")
        return SweepResult(
            ok=True,
            workspace_id=workspace_id,
            action="sweep",
            message=("Dry run — " if dry_run else "") + ", ".join(parts),
            dryRun=bool(payload.get("dryRun", dry_run)),
            archived=archived,
            annotated=annotated,
            changes=payload.get("changes", []) or [],
            refusals=refusals,
        )

    # -----------------------------------------------------------------------
    # Voyage creation (FTR-MSO-2026-0619, PLAN-PLN-MSO-2026-0556 Order 3)
    #
    # THE ENDPOINT BUG-MSO-2026-0555 REPORTED SUCCESS WITHOUT.
    #
    # Sync `def`, not `async def`, for the same reason the retry/edit/skip
    # endpoints are: `voyage_core.create_voyage` enters
    # `order_retry.workspace_scope` and `order_ids.lock_for_allocation`, both
    # of which hold locks for their duration. FastAPI runs a sync path
    # operation in its threadpool, so the locks only block other threadpool
    # work; an `async def` would hold them on the event loop and stall every
    # request the Hub serves.
    # -----------------------------------------------------------------------

    @app.post("/api/v1/workspaces/{workspace_id}/voyages", response_model=VoyageCreated)
    def create_voyage_endpoint(workspace_id: str, body: CreateVoyageRequest):
        """Create a voyage in *workspace_id* and report what actually landed.

        WHAT MAKES THIS RESPONSE HONEST is not that it is careful — it is
        that `voyage_core.create_voyage()` re-reads the manifest off disk
        before returning, and every field below is copied from that read.
        Nothing here is echoed from the request, and no id is composed
        anywhere in this process. That is the whole difference between "we
        wrote this" and "we intended to write this", and the second is
        exactly what the Hub shipped before this order (PLAN §2.3/§6.2).

        Not a second implementation of anything. The id is minted by
        `order_ids.allocate_*` under `lock_for_allocation`, inside the same
        `with` block as the write; the workspace override is guarded by
        `order_retry.workspace_scope`; the capability gate lives in the core,
        so the CLI, the Slack bridge and this endpoint inherit one
        `require_capability("voyage.create")` between them. `review_core.py`'s
        docstring is the record of what the alternative costs.

        NO GIT RUNS HERE (§3.4 / Captain decision D4). `create_branch`
        defaults to False and this endpoint never overrides it: an HTTP
        handler that switches the operator's working tree from a background
        daemon is the sharpest form of the `CONVERGENCE_PRIMARY_PROTECTED`
        bug class. The manifest records the branch NAME; the dispatcher
        creates it on the remote via `gh api` at first crew dispatch.

        THE ONE DELIBERATE SIDE EFFECT IS AN ORDER (BUG-MSO-2026-0793). With
        a non-empty description and ``createPlanningOrder`` (default true), a
        PENDING PLN order carrying the description is filed and attached to
        the new voyage in the same request, via
        ``voyage_core.create_order_on_voyage`` — the same core the order
        endpoint below calls, so there is no second create-and-attach
        implementation for this file to drift. Opt out with
        ``createPlanningOrder: false``; the message then says nothing will run.
        If the planning order cannot be filed, the voyage is rolled back too.

        Refusals: 403 tier / capability, 400 validation, 409 id collision,
        503 stale mount or a read-only plane. Every one of them leaves NO
        artefact behind — there is no partial-success 200 (§6.2's backend
        half).
        """
        from maestro.core import voyage_core
        from maestro.core.order_ids import OrderValidationError
        from maestro.identity.gate import CapabilityDenied
        from maestro.workspace import artefact_parent_for_entry, resolve_artefact_dir

        _require_control_tier()

        # Declared by /api/v1/capabilities BEFORE the click; raised here as
        # the same constant if the click happens anyway (a plane can go
        # read-only between the two). Pre-click reason and post-click refusal
        # cannot disagree because they are one string.
        plane_blocked = _plane_writable_reason()
        if plane_blocked:
            raise fastapi.HTTPException(status_code=503, detail=plane_blocked)

        try:
            entry = _resolve_workspace_entry(workspace_id)
            mso = resolve_artefact_dir(artefact_parent_for_entry(entry))
        except OSError:
            raise fastapi.HTTPException(status_code=503, detail=STALE_MOUNT_MESSAGE)

        # The project acronym is a property of the WORKSPACE, resolved
        # server-side exactly as `aggregator._read_config` resolves it for
        # every read model (workspace.json's `project`, else the registry
        # key). Taking it from the request body would let the browser choose
        # which sequence space a manifest is minted into — the same class of
        # defect as letting it choose the id.
        from maestro.hub.aggregator import _read_config
        try:
            _, _, project = _read_config(mso, workspace_id)
        except OSError:
            raise fastapi.HTTPException(status_code=503, detail=STALE_MOUNT_MESSAGE)

        try:
            created = voyage_core.create_voyage(
                mso,
                project=project or workspace_id,
                title=body.title,
                description=body.description,
                created_by="hub",
                # D4, stated at the call site as well as the default, so a
                # future edit has to argue with it: no git from HTTP.
                create_branch=False,
                plan_order=body.planOrder or "",
            )
        except CapabilityDenied as exc:
            raise fastapi.HTTPException(status_code=403, detail=str(exc))
        except voyage_core.VoyageIdCollision as exc:
            raise fastapi.HTTPException(status_code=409, detail=str(exc))
        except voyage_core.VoyageNotFound as exc:
            # BUG-MSO-2026-0775: the plan order names a voyage that is gone.
            raise fastapi.HTTPException(status_code=404, detail=str(exc))
        except OrderValidationError as exc:
            raise fastapi.HTTPException(status_code=400, detail=str(exc))
        except OSError:
            raise fastapi.HTTPException(status_code=503, detail=STALE_MOUNT_MESSAGE)

        # Belt and braces on the read-back. `create_voyage` falls back to the
        # dict it INTENDED to write if the re-read fails, which is right for
        # a CLI (the operator is standing there and the file is on their own
        # disk) and not right for an HTTP 200 that an operator will read as
        # proof. If the manifest is not on disk now, this call did not create
        # a voyage, whatever else happened.
        if not created.path.exists():
            raise fastapi.HTTPException(
                status_code=500,
                detail=f"Voyage {created.voyage_id} reported created but no "
                       f"manifest is present at {created.path} — nothing was "
                       "created. Check the artefact plane's permissions.")

        voyage = created.voyage
        # Read back from the manifest, with the returned id as the fallback —
        # never from anything the caller sent.
        voyage_id = str(voyage.get("id") or voyage.get("voyageId")
                        or created.voyage_id)
        voyage_branch = str(voyage.get("branch") or created.branch or "")

        # ---- BUG-MSO-2026-0793: the planning order ------------------------
        # VOY-MSO-2026-0791 was created here with a full planning brief as its
        # description and an empty `orders` manifest — nothing for the
        # dispatcher to find, so nothing ever ran. With a description and the
        # (default) flag, file a PENDING PLN order carrying it and attach it,
        # through the SAME create-and-attach path the order endpoint uses.
        planning = None
        voyage_description = str(voyage.get("description") or body.description or "")
        if body.createPlanningOrder and voyage_description.strip():
            from maestro.core.order_ids import MAX_DESCRIPTION_LENGTH

            # The composed title must pass `validate_description` like any
            # other; trim the voyage-title part rather than skip validation.
            prefix = f"Plan voyage {voyage_id}: "
            voyage_title = str(voyage.get("title") or body.title or "").strip()
            budget = MAX_DESCRIPTION_LENGTH - len(prefix)
            if len(voyage_title) > budget:
                voyage_title = voyage_title[: budget - 1].rstrip() + "…"
            from maestro.core.order_ids import OrderValidationError
            from maestro.identity.gate import CapabilityDenied

            def _rollback_voyage_and_raise(status_code: int, reason: str) -> None:
                # No partial-success 200: a voyage that exists while the order
                # the operator asked for does not is VOY-0791's stranded shape
                # reported as success. create_order_on_voyage has already
                # rolled back its own order on an attach failure; roll the
                # voyage back too (solo unlink / shared release — the branch
                # was never created, so no git to undo).
                undo_failed = _rollback_created_artefact(
                    mso, created.path, voyage_id,
                    local_failed=_VOYAGE_ROLLBACK_LOCAL_FAILED,
                    remote_failed=_VOYAGE_ROLLBACK_REMOTE_FAILED)
                if undo_failed:
                    detail = (f"Voyage {voyage_id}'s planning order could not "
                              f"be filed — {reason} {undo_failed}")
                else:
                    detail = (f"Voyage {voyage_id} was not created: its planning "
                              f"order could not be filed — {reason}")
                raise fastapi.HTTPException(status_code=status_code, detail=detail)

            # Same exception-to-status mapping as create_order_endpoint below —
            # both call the one core. A truly unanticipated exception is left
            # to propagate to FastAPI's own 500 handler, same as that endpoint.
            try:
                planning_result = voyage_core.create_order_on_voyage(
                    mso,
                    voyage_id=voyage_id,
                    voyage_branch=voyage_branch,
                    order_type="PLN",
                    project=project or workspace_id,
                    title=prefix + voyage_title,
                    description=voyage_description,
                    created_by="hub",
                )
                planning = planning_result.created
            except CapabilityDenied as exc:
                _rollback_voyage_and_raise(403, str(exc))
            except voyage_core.VoyageAttachFailed as exc:
                cause = exc.cause
                if cause is None:
                    status_code = 500
                elif isinstance(cause, FileNotFoundError):
                    status_code = 404
                elif isinstance(cause, OSError):
                    status_code = 503
                else:
                    status_code = 409
                _rollback_voyage_and_raise(status_code, str(exc))
            except voyage_core.OrderNotWritten as exc:
                _rollback_voyage_and_raise(500, str(exc))
            except voyage_core.VoyageNotFound as exc:
                _rollback_voyage_and_raise(404, str(exc))
            except voyage_core.VoyageArchived as exc:
                _rollback_voyage_and_raise(409, str(exc))
            except OrderValidationError as exc:
                _rollback_voyage_and_raise(400, str(exc))
            except OSError:
                _rollback_voyage_and_raise(503, STALE_MOUNT_MESSAGE)
            except Exception as exc:   # noqa: BLE001 - re-raised as a 500 below
                # Unlike the order endpoint, this call follows a voyage WRITE
                # that already landed — an unanticipated exception here must
                # still roll that voyage back, not just propagate uncaught.
                _rollback_voyage_and_raise(500, str(exc))

        if planning is not None:
            order = planning.order
            planning_id = str(order.get("orderId") or planning.order_id)
            message = (f"Voyage {voyage_id} created with planning order "
                       f"{planning_id} ({order.get('status') or 'PENDING'}) — "
                       "it will run on the next dispatch")
        else:
            planning_id = ""
            message = (f"Voyage {voyage_id} created with no orders — nothing "
                       "will run until an order is filed into it")

        return VoyageCreated(
            ok=True,
            workspace_id=workspace_id,
            voyage_id=voyage_id,
            title=str(voyage.get("title") or ""),
            status=str(voyage.get("status") or ""),
            branch=voyage_branch,
            path=str(created.path),
            planningOrderId=planning_id,
            planningOrderPath=str(planning.path) if planning is not None else "",
            message=message,
            planOrder=str(voyage.get("planOrder") or ""),
            planVoyage=str(voyage.get("planVoyage") or ""),
            planLinkError=created.plan_link_error,
        )

    # -----------------------------------------------------------------------
    # Order creation (FTR-MSO-2026-0621, PLAN-PLN-MSO-2026-0556 Order 5)
    # -----------------------------------------------------------------------

    def _order_workspace_plane(workspace_id: str):
        """Resolve (artefact dir, project acronym) for *workspace_id*.

        Shared by the create endpoint and the defaults endpoint so the two
        cannot resolve a workspace differently - a picker populated from one
        plane and a create landing on another is the drift this whole plan is
        about, expressed as two helpers instead of one.

        The project acronym comes from ``aggregator._read_config`` - the
        workspace's own ``config/workspace.json``, falling back to the registry
        key - exactly as every read model resolves it, and never from a request
        body.
        """
        from maestro.hub.aggregator import _read_config
        from maestro.workspace import artefact_parent_for_entry, resolve_artefact_dir

        try:
            entry = _resolve_workspace_entry(workspace_id)
            mso = resolve_artefact_dir(artefact_parent_for_entry(entry))
            _, _, project = _read_config(mso, workspace_id)
        except OSError:
            raise fastapi.HTTPException(status_code=503, detail=STALE_MOUNT_MESSAGE)
        return mso, (project or workspace_id)

    def _rollback_created_artefact(mso, path, item_id, *,
                                   local_failed: str, remote_failed: str) -> str:
        """Undo a just-created artefact (order or voyage) by unlinking it,
        or, in shared mode, releasing its id reservation.

        This is a ROLLBACK, not a deletion of anyone's work: the file has
        existed for microseconds and nothing has read it. Solo/embedded mode:
        the create only ever wrote a file, so unlinking it is the whole
        rollback. ``artefacts.mode: shared``: the create went through
        ``artefact_sync.push_id_reservation``, which COMMITS the file and
        PUSHES it — the push is the reservation, so deleting the local file
        undoes nothing anyone else can see. This goes through
        ``release_id_reservation`` instead, which commits the deletion and
        pushes it too. ``release_id_reservation`` is keyed on (path, id), not
        on artefact type, so the same body serves both an order rollback
        (BUG-MSO-2026-0744/0754) and a voyage rollback (BUG-MSO-2026-0793).

        A rollback that is INCOMPLETE - either half - returns a sentence
        saying which half, naming the path, built from the caller's own two
        templates. Returns "" when both halves succeeded.
        """
        from maestro.core import artefact_sync

        try:
            shared = artefact_sync.get_mode(mso) == "shared"
        except Exception:   # noqa: BLE001 - an unreadable config is not shared
            shared = False

        if not shared:
            try:
                path.unlink()
                return ""
            except OSError as exc:
                return local_failed.format(path=path, error=exc)

        try:
            outcome = artefact_sync.release_id_reservation(mso, path, item_id)
        except Exception as exc:    # noqa: BLE001 - never raise from a rollback
            return local_failed.format(path=path, error=exc)

        remote = "" if outcome.remote_clean else remote_failed.format(
            order_id=item_id, voyage_id=item_id, path=path,
            reason=outcome.reason, detail=outcome.detail or "no detail from git")
        if outcome.released:
            return remote
        # Both halves failed: the file is still on this disk AND still on the
        # plane. Two facts, two remedies, both said - collapsing them would
        # leave whichever one the operator was not told about.
        local = local_failed.format(
            path=path, error=outcome.detail or outcome.reason)
        return (local + " " + remote).strip() if remote else local

    @app.post("/api/v1/workspaces/{workspace_id}/orders", response_model=OrderCreated)
    def create_order_endpoint(workspace_id: str, body: CreateOrderRequest):
        """Create an order in *workspace_id*, attach it to its voyage, report both.

        TWO WRITES, ONE OUTCOME, AND NO ORPHAN BETWEEN THEM. An order that
        names a ``voyageId`` its voyage's manifest does not list is invisible
        to that voyage, and invisible is worse than absent - it looks filed.
        Three things close that window, in order:

        1. **The voyage is resolved BEFORE anything is allocated.** A missing
           (404) or archived (409) voyage writes nothing at all and burns no
           order id. The cheap, overwhelmingly common case.
        2. **``voyageBranch`` is derived from the manifest**, never from the
           request - the request model has no field for it (422 if sent). A
           branch that disagrees with its voyage is how an order strands
           (BUG-ADM-2026-0004).
        3. **A failed attach REMOVES the order it just wrote** and raises -
           and in ``artefacts.mode: shared`` that removal reaches the REMOTE
           too, because the create already committed and pushed the order to
           reserve its id (BUG-MSO-2026-0744). See
           ``voyage_core.rollback_created_order``.

        ONE IMPLEMENTATION (BUG-MSO-2026-0754, closed for real by BUG-MSO-2026-0804
        after this exact endpoint's own fix landed only half of it). The
        resolve / derive-branch / verify / attach / rollback sequence lives in
        ``voyage_core.create_order_on_voyage``, which ``mso order create
        --voyage`` calls too - so the CLI and the Hub cannot disagree about
        what creating an order in a voyage means. This endpoint only maps its
        typed errors to HTTP. ``create_order``'s own contract ("record
        ``voyageId``, do not resolve it") is untouched.

        Refusals: 403 tier/capability, 400 validation, 404 unknown voyage,
        409 archived voyage, 422 unmodelled field, 503 stale mount or
        read-only plane. Every one of them leaves NO artefact behind.
        """
        from maestro.core import voyage_core
        from maestro.core.order_ids import OrderValidationError
        from maestro.identity.gate import CapabilityDenied

        _require_control_tier()

        # Declared by /api/v1/capabilities BEFORE the click and raised here as
        # the same constant if the click happens anyway. One string, so the
        # pre-click reason and the post-click refusal cannot disagree.
        plane_blocked = _plane_writable_reason()
        if plane_blocked:
            raise fastapi.HTTPException(status_code=503, detail=plane_blocked)

        mso, project = _order_workspace_plane(workspace_id)

        try:
            result = voyage_core.create_order_on_voyage(
                mso,
                voyage_id=body.voyageId or "",
                order_type=body.type,
                project=project,
                title=body.title,
                description=body.description or "",
                priority=body.priority,
                target_role=body.targetRole,
                role_sequence=body.roleSequence,
                acceptance_criteria=body.acceptanceCriteria,
                depends_on=body.dependsOn,
                target_repo=body.targetRepo or "",
                status=body.status,
                created_by="hub",
                plan_order=body.planOrder or "",
            )
        except CapabilityDenied as exc:
            raise fastapi.HTTPException(status_code=403, detail=str(exc))
        except voyage_core.VoyageAttachFailed as exc:
            # The order was created and rolled back. Map by what the attach
            # raised: VoyageNotFound subclasses FileNotFoundError, so a voyage
            # deleted mid-call reads as 404, and FileNotFoundError is checked
            # FIRST because it is itself an OSError - the order of these arms
            # is load-bearing. Any other OSError is the plane going away (503),
            # anything else a business refusal (409), and an attach that
            # returned without listing the order is never a 200 (500).
            cause = exc.cause
            if cause is None:
                status = 500
            elif isinstance(cause, FileNotFoundError):
                status = 404
            elif isinstance(cause, OSError):
                status = 503
            else:
                status = 409
            raise fastapi.HTTPException(status_code=status, detail=str(exc))
        except voyage_core.OrderNotWritten as exc:
            raise fastapi.HTTPException(status_code=500, detail=str(exc))
        except voyage_core.VoyageNotFound as exc:
            raise fastapi.HTTPException(status_code=404, detail=str(exc))
        except voyage_core.VoyageArchived as exc:
            raise fastapi.HTTPException(status_code=409, detail=str(exc))
        except OrderValidationError as exc:
            raise fastapi.HTTPException(status_code=400, detail=str(exc))
        except OSError:
            raise fastapi.HTTPException(status_code=503, detail=STALE_MOUNT_MESSAGE)

        created = result.created
        attached = result.attached
        voyage_id = result.voyage_id
        voyage_order_ids = list(result.voyage_order_ids)

        order = created.order
        message = "Order {} created".format(created.order_id)
        if attached:
            message += " and attached to {}".format(voyage_id)
        return OrderCreated(
            ok=True,
            workspace_id=workspace_id,
            # Read back from the file, with the returned id as the fallback -
            # never from anything the caller sent.
            order_id=str(order.get("orderId") or created.order_id),
            type=str(order.get("type") or ""),
            title=str(order.get("title") or ""),
            status=str(order.get("status") or ""),
            priority=str(order.get("priority") or ""),
            targetRole=str(order.get("targetRole") or ""),
            roleSequence=list(order.get("roleSequence") or []),
            voyageId=str(order.get("voyageId") or ""),
            voyageBranch=str(order.get("voyageBranch") or ""),
            attached=attached,
            voyageOrderIds=voyage_order_ids,
            path=str(created.path),
            message=message,
            planOrder=str(order.get("planOrder") or ""),
            planLinkError=result.plan_link_error,
        )

    @app.get("/api/v1/workspaces/{workspace_id}/order-defaults",
             response_model=OrderDefaults)
    def get_order_defaults(workspace_id: str):
        """The vocabulary a create form must be built from - types, roles,
        priorities, statuses, and what each type defaults to.

        A READ endpoint, and deliberately NOT tier-gated: a licence gates
        ACTING, never READING - the position ``GET .../lead`` already takes.

        It exists because PLAN §5.2/§5.4 require a CONSTRAINED role picker
        "over the workspace's configured sequences, never free-form", and the
        frontend cannot know those without either this endpoint or a second
        copy of the vocabulary in TypeScript. A second copy is exactly the
        drift §5.4 exists to prevent - and the drawer's four hard-coded types
        are the proof: one of them, ``HANDOFF``, is not an order type at all.
        Everything here resolves through the same ``order_create`` functions
        ``create_order`` itself calls, so every (type, role) pair a picker
        built on this can produce is one the create path accepts.
        """
        from maestro.core import order_create

        mso, project = _order_workspace_plane(workspace_id)
        try:
            types = order_create.known_order_types(mso)
            entries = [OrderTypeDefault(**order_create.order_type_defaults(mso, t))
                       for t in types]
        except OSError:
            raise fastapi.HTTPException(status_code=503, detail=STALE_MOUNT_MESSAGE)

        return OrderDefaults(
            workspace_id=workspace_id,
            project=project,
            types=entries,
            roles=list(order_create.DISPATCHABLE_ROLES),
            priorities=["CRITICAL", "HIGH", "MEDIUM", "LOW"],
            statuses=sorted(order_create.CREATABLE_STATUSES),
            defaultStatus=order_create.DEFAULT_ORDER_STATUS,
        )

    # -----------------------------------------------------------------------
    # Phase 3 — Review queue endpoints
    # -----------------------------------------------------------------------

    def _iter_workspaces():
        """Yield (workspace_id, artefact_root_parent) for every registered workspace."""
        import maestro.registry as registry
        from maestro.workspace import artefact_parent_for_entry
        for ws_id, entry in registry.list_projects().items():
            yield ws_id, artefact_parent_for_entry(entry)

    def _find_order_workspace(order_id: str):
        """Return (workspace_id, workspace_path) for an order in any review queue.

        Raises HTTPException 404 if not found in any registered workspace.
        """
        _validate_order_id(order_id)
        from maestro.hub.review import _get_mso_dir
        for ws_id, ws_root in _iter_workspaces():
            try:
                mso = _get_mso_dir(ws_root)
                if (mso / "queues" / "review" / f"{order_id}.json").exists():
                    return ws_id, ws_root
            except Exception:
                pass
        raise fastapi.HTTPException(status_code=404, detail=f"Order '{order_id}' not found in any review queue")

    @app.get("/api/v1/review/queue", response_model=list[ReviewItem])
    async def review_queue():
        """List all NAV_REVIEW_PENDING orders across all registered workspaces.

        Returns a BARE ARRAY of ReviewItem (frontend api.ts contract).
        """
        from maestro.hub.review import find_review_pending_orders
        items: list[ReviewItem] = []
        for ws_id, ws_root in _iter_workspaces():
            try:
                orders = find_review_pending_orders(ws_root)
            except Exception:
                continue
            for data in orders:
                order_id = data.get("id") or data.get("orderId") or ""
                role = "PLN" if data.get("planApprovalOnly") else (data.get("targetRole") or data.get("role") or "")
                # BUG-MSO-2026-0711: "critical" survives normalisation here too —
                # the review list must not report a tier-overriding order as HIGH.
                priority = (str(data.get("priority")).lower() if data.get("priority") else None)
                if priority in ("medium", "med", "default"):
                    priority = "normal"
                elif priority == "urgent":
                    priority = "high"
                items.append(ReviewItem(
                    order_id=order_id,
                    workspace_id=ws_id,
                    workspace_name=ws_id,
                    order_title=data.get("title", "") or "",
                    role=role,
                    voyage_id=data.get("voyageId") or None,
                    created_at=data.get("createdAt", "") or "",
                    paused_at=data.get("navReviewPausedAt") or None,
                    priority=priority if priority in ("critical", "high", "normal", "low") else None,
                ))
        return items

    @app.get("/api/v1/review/{order_id}/plan", response_model=PlanResponse)
    async def review_get_plan(order_id: str):
        """Return plan markdown (or order description as fallback) plus order JSON."""
        from maestro.hub.review import get_plan_content
        ws_id, ws_root = _find_order_workspace(order_id)
        plan_md, has_plan, order_data = get_plan_content(ws_root, order_id)
        if order_data is None:
            raise fastapi.HTTPException(status_code=404, detail=f"Order '{order_id}' not found")
        return PlanResponse(
            workspace_id=ws_id,
            order_id=order_id,
            plan_markdown=plan_md or "",
            has_plan_file=has_plan,
            order=order_data,
        )

    @app.post("/api/v1/review/{order_id}/approve", response_model=ActionResult)
    async def review_approve(order_id: str):
        """Approve a NAV_REVIEW_PENDING order — moves to queues/orders/ with status PENDING."""
        _require_control_tier()
        from maestro.hub.review import approve_order
        ws_id, ws_root = _find_order_workspace(order_id)
        try:
            result = approve_order(ws_root, order_id)
        except FileNotFoundError as exc:
            raise fastapi.HTTPException(status_code=404, detail=str(exc))
        except ValueError as exc:
            raise fastapi.HTTPException(status_code=409, detail=str(exc))
        except PermissionError as exc:
            raise fastapi.HTTPException(status_code=403, detail=str(exc))
        # BUG-MSO-2026-0476: a plan approved with no dependent orders filed
        # gets a loud, distinct message instead of the generic one — the
        # operator needs to know a voyage now has no path to completion.
        message = f"Order {order_id} approved"
        if result.get("warning"):
            message = f"Order {order_id} approved — WARNING: {result['warning']}"
        return ActionResult(ok=True, order_id=order_id, new_status=result["new_status"],
                            message=message)

    @app.post("/api/v1/review/{order_id}/revise", response_model=ActionResult)
    async def review_revise(order_id: str, body: ReviseRequest):
        """Request revision — re-queues the order to the gated role (BUG-MSO-2026-0486 D2:
        previously left it stranded, unlabelled, in the review queue)."""
        _require_control_tier()
        from maestro.hub.review import revise_order
        ws_id, ws_root = _find_order_workspace(order_id)
        try:
            result = revise_order(ws_root, order_id, body.feedback)
        except FileNotFoundError as exc:
            raise fastapi.HTTPException(status_code=404, detail=str(exc))
        except ValueError as exc:
            raise fastapi.HTTPException(status_code=409, detail=str(exc))
        except PermissionError as exc:
            raise fastapi.HTTPException(status_code=403, detail=str(exc))
        return ActionResult(ok=True, order_id=order_id, new_status=result["new_status"],
                            message=f"Order {order_id} sent for revision")

    @app.post("/api/v1/review/{order_id}/reject", response_model=ActionResult)
    async def review_reject(order_id: str, body: RejectRequest):
        """Reject an order — marks FAILED, moves to orders/failed/ (BUG-MSO-2026-0486 D3:
        previously a Hub-only REJECTED/queues/review/rejected/ vocabulary that
        nothing else in the system scanned)."""
        _require_control_tier()
        from maestro.hub.review import reject_order
        ws_id, ws_root = _find_order_workspace(order_id)
        try:
            result = reject_order(ws_root, order_id, body.reason)
        except FileNotFoundError as exc:
            raise fastapi.HTTPException(status_code=404, detail=str(exc))
        except ValueError as exc:
            raise fastapi.HTTPException(status_code=409, detail=str(exc))
        except PermissionError as exc:
            raise fastapi.HTTPException(status_code=403, detail=str(exc))
        return ActionResult(ok=True, order_id=order_id, new_status=result["new_status"],
                            message=f"Order {order_id} rejected")

    # -----------------------------------------------------------------------
    # Order artefacts + retry (FTR-MSO-2026-0492) — voyage inspection/recovery
    # -----------------------------------------------------------------------

    def _find_order_workspace_any(order_id: str):
        """Return (workspace_id, workspace_path) for an order ANYWHERE — archived
        complete/failed, or live in any queue — not just queues/review/.

        Sibling to `_find_order_workspace()` (review-scoped) rather than a
        widening of it: BUG-MSO-2026-0486 rewrites `hub/review.py` and the
        review endpoints and is unmerged (PLAN-FTR-MSO-2026-0492 §4.5) — a
        conflict on an authorisation code path is exactly how a security fix
        gets silently dropped in merge resolution.
        """
        _validate_order_id(order_id)
        from maestro.hub.artefacts import find_order_file
        from maestro.hub.review import _get_mso_dir
        for ws_id, ws_root in _iter_workspaces():
            try:
                mso = _get_mso_dir(ws_root)
                if find_order_file(mso, order_id) is not None:
                    return ws_id, ws_root
            except Exception:
                pass
        raise fastapi.HTTPException(
            status_code=404, detail=f"Order '{order_id}' not found in any workspace")

    @app.get("/api/v1/orders/{order_id}/artefacts", response_model=OrderArtefacts)
    async def get_order_artefacts(order_id: str):
        """Discover every artefact belonging to *order_id* — manifest only, no
        content (§4.2). Read-only, ungated — matches `/review/{id}/plan`."""
        from maestro.hub import artefacts as _artefacts
        from maestro.hub.review import _get_mso_dir

        ws_id, ws_root = _find_order_workspace_any(order_id)
        mso = _get_mso_dir(ws_root)
        refs = _artefacts.discover_artefacts(mso, order_id)
        return OrderArtefacts(order_id=order_id, workspace_id=ws_id, artefacts=refs)

    @app.get("/api/v1/orders/{order_id}/artefacts/{key:path}", response_model=ArtefactContent)
    async def get_order_artefact_content(order_id: str, key: str):
        """Read one artefact's content, bounded at 512 KB (§5.5).

        *key* is re-validated by re-running discovery and matching — never by
        joining the client-supplied string onto a path (§4.2 / Builder note 4).
        A forged key (path traversal, an absolute path, a real file outside the
        manifest) matches nothing discovery finds and 404s, never leaks content.
        """
        from maestro.hub import artefacts as _artefacts
        from maestro.hub.review import _get_mso_dir

        _validate_order_id(order_id)
        ws_id, ws_root = _find_order_workspace_any(order_id)
        mso = _get_mso_dir(ws_root)
        try:
            return _artefacts.read_artefact(mso, order_id, key)
        except _artefacts.ArtefactNotFound as exc:
            raise fastapi.HTTPException(status_code=404, detail=str(exc))

    @app.get("/api/v1/orders/{order_id}/salvage-candidates",
             response_model=SalvageCandidates)
    def order_salvage_candidates(order_id: str):
        """Every salvage branch a retry could arm, and which one it would pick.

        BUG-MSO-2026-0696 AC-4: read-only preview of the SAME core selection
        the CLI and `POST .../retry` use — `salvage_record.salvage_candidates()`
        plus `select_salvage()`. Nothing here re-derives candidates, so the Hub
        cannot drift into showing a different set from the CLI's.

        Ungated: this reads order JSON and decides nothing. `ambiguous` carries
        the reason a bare retry would REFUSE, so a UI can require a selection
        up front instead of surfacing a 409 after the operator has committed.
        """
        import json as _json

        from maestro.core import salvage_record
        from maestro.hub.artefacts import find_order_file
        from maestro.hub.review import _get_mso_dir

        _validate_order_id(order_id)
        ws_id, ws_root = _find_order_workspace_any(order_id)
        mso = _get_mso_dir(ws_root)
        order_file = find_order_file(mso, order_id)
        if order_file is None:
            raise fastapi.HTTPException(
                status_code=404, detail=f"Order {order_id} not found in {ws_id}.")
        try:
            data = _json.loads(order_file.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            raise fastapi.HTTPException(
                status_code=503, detail=f"Cannot read {order_file}: {exc}")
        candidates = salvage_record.salvage_candidates(data)
        sel = salvage_record.select_salvage(candidates)
        return SalvageCandidates(
            order_id=order_id,
            candidates=[SalvageCandidateModel(**c.to_dict()) for c in candidates],
            would_arm=sel.chosen.branch if sel.chosen else None,
            ambiguous=sel.ambiguous,
        )

    @app.post("/api/v1/orders/{order_id}/retry", response_model=RetryResult)
    def retry_order_endpoint(
        order_id: str,
        salvage: str | None = fastapi.Query(default=None),
        no_salvage: bool = fastapi.Query(default=False),
        force_salvage: bool = fastapi.Query(default=False),
    ):
        """Reopen a stranded/terminal order — `mso order retry` over HTTP.

        PLAN-FTR-MSO-2026-0492 §4.1: this MUST be a sync `def`, not `async def`.
        `order_retry.retry_order()` holds `order_retry._SCOPE_LOCK` for its
        duration to guard `fleet_runner`'s process-global artefact-root
        override; FastAPI runs a sync path operation in its threadpool, so the
        lock only ever blocks other threadpool work. An `async def` would hold
        the lock on the event loop itself and stall every other request —
        correctness, not style.

        BUG-MSO-2026-0696 AC-4: `salvage` / `no_salvage` / `force_salvage` are
        the same three selectors the CLI exposes, passed straight through to the
        shared core. An ambiguous salvage choice raises `SalvageAmbiguous` — a
        `RetryRefused` subclass, so it already maps to the 409 below, and its
        message carries the full candidate listing rather than a bare refusal.
        """
        _require_control_tier()
        _validate_order_id(order_id)
        from maestro.core import order_retry
        from maestro.hub.review import _get_mso_dir
        from maestro.identity.gate import CapabilityDenied

        ws_id, ws_root = _find_order_workspace_any(order_id)
        mso = _get_mso_dir(ws_root)
        try:
            outcome = order_retry.retry_order(
                mso, order_id, reason="operator retry (hub)",
                salvage=salvage, no_salvage=no_salvage,
                force_salvage=force_salvage)
        except order_retry.OrderNotFound as exc:
            raise fastapi.HTTPException(status_code=404, detail=str(exc))
        except order_retry.RetryRefused as exc:
            raise fastapi.HTTPException(status_code=409, detail=str(exc))
        except CapabilityDenied as exc:
            raise fastapi.HTTPException(status_code=403, detail=str(exc))
        except OSError:
            raise fastapi.HTTPException(status_code=503, detail=STALE_MOUNT_MESSAGE)

        return RetryResult(
            ok=True,
            order_id=order_id,
            new_status=outcome.new_status,
            target_role=outcome.target_role,
            salvage_branch=outcome.salvage_branch,
            salvage_candidates=[SalvageCandidateModel(**c)
                                for c in outcome.salvage_candidates],
            salvage_explicit=outcome.salvage_explicit,
            message=f"Order {order_id} reopened: "
                    f"{outcome.new_status}@{outcome.target_role}{outcome.salvage_note}",
        )

    # -----------------------------------------------------------------------
    # Blockage — "why is this stuck, and what are my options?"
    # FTR-MSO-2026-0721 / PLAN-FTR-MSO-2026-0700 §5.2
    # -----------------------------------------------------------------------

    def _find_voyage_workspace_any(voyage_id: str):
        """Return (workspace_id, workspace_path) for a voyage, active or complete.

        Sibling to :func:`_find_order_workspace_any`. Deliberately NOT reusing
        ``get_voyage_usage``'s inline scan: that one returns a zero rollup for
        an unknown voyage (correct for usage — "no spend recorded" is a real
        answer), whereas an unknown voyage here must 404, because "this voyage
        is not blocked" and "this voyage does not exist" are different answers
        and only one of them should stop an operator looking.
        """
        _validate_order_id(voyage_id)
        from maestro.hub.review import _get_mso_dir
        for ws_id, ws_root in _iter_workspaces():
            try:
                mso = _get_mso_dir(ws_root)
            except Exception:
                continue
            for sub in ("active", "complete"):
                try:
                    if (mso / "voyages" / sub / f"{voyage_id}.json").exists():
                        return ws_id, ws_root
                except OSError:
                    continue
        raise fastapi.HTTPException(
            status_code=404, detail=f"Voyage '{voyage_id}' not found in any workspace")

    @app.get("/api/v1/orders/{order_id}/blockage", response_model=BlockageResponse)
    def get_order_blockage(order_id: str):
        """Why this order is not moving, and what the operator can do about it.

        The body is ``maestro.core.blockage.classify_order_blockage(...)``'s
        own ``to_dict()`` — nothing is re-derived here, so this endpoint, the
        ``mso order why`` verb, ``mso doctor`` and the LEAD's findings cannot
        say different things about the same order. The ONLY additions are
        ``blocked`` and, per option, the ``available``/``unavailableReason``
        pair this deployment resolves (§5.2).

        Ungated read, matching ``/salvage-candidates`` and ``/artefacts``: it
        decides nothing and mutates nothing. The OPTIONS it returns name gated
        endpoints, and each says so in its own resolution — which is the
        point: an operator on a community tier should still be able to SEE
        what the remedy would be, and the CLI commands stay runnable for them
        regardless.

        Sync ``def`` (not ``async``): ``BlockageContext.load()`` reads the
        ledger, the archive and the queues off disk. On the event loop that
        would stall every other request for the duration; in FastAPI's
        threadpool it does not.
        """
        from maestro.core.blockage import BlockageContext, classify_order_blockage
        from maestro.hub.review import _get_mso_dir

        _validate_order_id(order_id)
        ws_id, ws_root = _find_order_workspace_any(order_id)
        try:
            mso = _get_mso_dir(ws_root)
        except OSError:
            raise fastapi.HTTPException(status_code=503, detail=STALE_MOUNT_MESSAGE)

        ctx = BlockageContext.load(mso)
        blockage = classify_order_blockage(order_id, ctx)
        if blockage is None:
            # Not a 404 and not an empty body: "nothing is wrong with it" is a
            # successful, useful answer (PLAN §5.1's rule for the CLI verb,
            # applied to the wire). The subject echoes back so a caller
            # rendering a panel has something to key on.
            return BlockageResponse(blocked=False, subjectId=order_id,
                                    subjectKind="order", workspace_id=ws_id)
        payload = resolve_blockage_options(blockage.to_dict(), build_capability_map())
        return BlockageResponse(blocked=True, workspace_id=ws_id, **payload)

    @app.get("/api/v1/voyages/{voyage_id}/blockage", response_model=BlockageResponse)
    def get_voyage_blockage(voyage_id: str):
        """Why this voyage is not moving — the voyage-level record.

        Same contract as the order endpoint above, over
        ``classify_voyage_blockage``. A DEADLOCKED voyage's ``summary`` is
        ``deadlock.VoyageDeadlock.summary()`` passed through verbatim, so this
        banner and the ``mso status`` MISSION line stay byte-identical
        (BUG-MSO-2026-0699's string, not a second one).
        """
        from maestro.core.blockage import BlockageContext, classify_voyage_blockage
        from maestro.hub.review import _get_mso_dir

        _validate_order_id(voyage_id)
        ws_id, ws_root = _find_voyage_workspace_any(voyage_id)
        try:
            mso = _get_mso_dir(ws_root)
        except OSError:
            raise fastapi.HTTPException(status_code=503, detail=STALE_MOUNT_MESSAGE)

        ctx = BlockageContext.load(mso)
        blockage = classify_voyage_blockage(voyage_id, ctx)
        if blockage is None:
            return BlockageResponse(blocked=False, subjectId=voyage_id,
                                    subjectKind="voyage", workspace_id=ws_id)
        payload = resolve_blockage_options(blockage.to_dict(), build_capability_map())
        return BlockageResponse(blocked=True, workspace_id=ws_id, **payload)

    # -----------------------------------------------------------------------
    # Order edit + skip / unskip (FTR-MSO-2026-0622, PLAN-PLN-MSO-2026-0556
    # Order 6) — the endpoints behind OrderDrawer's Save and Remove.
    #
    # Both go through a SHARED core (`order_create.edit_order`,
    # `fleet_runner.add_skipped_order`) rather than a Hub-private
    # reimplementation. review_core.py's docstring is the record of what the
    # alternative costs: five silent drifts between the Hub's private copy of
    # the review logic and the CLI's, two of them order-destroying.
    #
    # Both are sync `def`, not `async def`, for the same reason the retry
    # endpoint above is: they enter `order_retry.workspace_scope`, which holds
    # a process-wide lock for its duration. FastAPI runs a sync path operation
    # in its threadpool, so the lock only blocks other threadpool work; an
    # `async def` would hold it on the event loop and stall every request.
    # -----------------------------------------------------------------------

    @app.patch("/api/v1/orders/{order_id}", response_model=OrderEditResult)
    def edit_order_endpoint(order_id: str, body: OrderEditRequest):
        """Edit a not-yet-in-flight order — the Save half of PLAN Order 6.

        THE STATUS RULE IS ENFORCED HERE, SERVER-SIDE, and the client's copy
        of it is a courtesy. `OrderDrawer` disables its form for
        LOCKED_STATUSES/`isReviewGated`, which is good UX and no guarantee at
        all: a client check is advice to a browser. The rule that MATTERS is
        `order_create.EDITABLE_STATUSES` — PENDING / BACKLOG / PROPOSED — and
        it lives in the core both the CLI and this endpoint call, so the two
        surfaces cannot drift into disagreeing about what "in flight" means.
        Editing a RUNNING order therefore returns 409 and mutates NOTHING:
        the refusal is raised before the file is opened for writing.

        The response reports `changed_fields` READ BACK from the order the
        core wrote, never echoed from the request (PLAN §6.2's backend half:
        no partial-success 200, and never a client-computed answer). A
        `targetRole` the core re-anchored on its own initiative is named
        separately in `reanchored_role` and in the message, since
        `changed_fields` cannot distinguish that from a field the caller sent
        (BUG-MSO-2026-0742).
        """
        _require_control_tier()
        _validate_order_id(order_id)
        from maestro.core import order_create
        from maestro.core.order_ids import OrderValidationError
        from maestro.hub.review import _get_mso_dir
        from maestro.identity.gate import CapabilityDenied

        updates = body.updates()
        if not updates:
            raise fastapi.HTTPException(
                status_code=400,
                detail="No fields to edit — send at least one changed field.")

        ws_id, ws_root = _find_order_workspace_any(order_id)
        mso = _get_mso_dir(ws_root)
        try:
            outcome = order_create.edit_order(
                mso, order_id, updates, edited_by="hub")
        except order_create.OrderNotFound as exc:
            raise fastapi.HTTPException(status_code=404, detail=str(exc))
        except order_create.OrderEditRefused as exc:
            raise fastapi.HTTPException(status_code=409, detail=str(exc))
        except OrderValidationError as exc:
            raise fastapi.HTTPException(status_code=400, detail=str(exc))
        except CapabilityDenied as exc:
            raise fastapi.HTTPException(status_code=403, detail=str(exc))
        except OSError:
            raise fastapi.HTTPException(status_code=503, detail=STALE_MOUNT_MESSAGE)

        changed = list(outcome.changed_fields)
        message = (
            f"Order {order_id} updated ({', '.join(changed)})" if changed
            else f"Order {order_id} unchanged — the values sent already matched"
        )
        # BUG-MSO-2026-0742: a re-anchor is a change the caller did not ask
        # for, so it is said out loud rather than left to be inferred from
        # `targetRole` appearing in `changed_fields`.
        if outcome.reanchored_role:
            message += (
                f" — targetRole was re-anchored to {outcome.reanchored_role}, "
                "the first role of the order's roleSequence, because the "
                "previous one was no longer in it"
            )
        return OrderEditResult(
            ok=True,
            order_id=order_id,
            status=str(outcome.order.get("status") or ""),
            changed_fields=changed,
            reanchored_role=outcome.reanchored_role,
            message=message,
        )

    def _skip_order(order_id: str, *, skip: bool, reason: str = "") -> OrderSkipResult:
        """Shared body for skip and unskip — one workspace scope, one read-back.

        `fleet_runner.add_skipped_order` / `remove_skipped_order` resolve the
        skip-list path from `fleet_runner._MAESTRO_DIR_OVERRIDE`, a module
        global (neither takes a workspace argument). The Hub serves N
        workspaces from one process, so both calls MUST run inside
        `order_retry.workspace_scope(mso)` — the guard that exists for exactly
        this failure, and the reason a bare set/restore here would let a
        concurrent poller tick write into a different workspace's plane.

        The `skipped` field is read back from the persisted list inside the
        same scope rather than inferred from the verb, so the response
        describes what is on disk and not what was intended.
        """
        _require_control_tier()
        _validate_order_id(order_id)
        from maestro.core import fleet_runner
        from maestro.core.order_retry import workspace_scope
        from maestro.core.skip_list import read_skipped_order_ids
        from maestro.hub.review import _get_mso_dir

        ws_id, ws_root = _find_order_workspace_any(order_id)
        mso = _get_mso_dir(ws_root)
        try:
            with workspace_scope(mso):
                was_skipped = order_id in read_skipped_order_ids(mso)
                if skip:
                    fleet_runner.add_skipped_order(
                        order_id, reason=reason, skipped_by="hub")
                else:
                    fleet_runner.remove_skipped_order(order_id)
                now_skipped = order_id in read_skipped_order_ids(mso)
        except OSError:
            raise fastapi.HTTPException(status_code=503, detail=STALE_MOUNT_MESSAGE)

        if now_skipped is not skip:
            # The write reported no error and the list still disagrees. Never
            # a 200: an operator told "skipped" about an order the dispatcher
            # will pick up on its next tick is the BUG-MSO-2026-0555 shape.
            raise fastapi.HTTPException(
                status_code=500,
                detail=f"Skip list did not record {order_id} — check "
                       f"{mso / 'config' / 'skipped-orders.json'}")

        changed = was_skipped is not now_skipped
        if skip:
            message = (
                f"Order {order_id} skipped — the dispatcher will not pick it up"
                if changed else f"Order {order_id} was already skipped")
        else:
            message = (
                f"Order {order_id} restored to the queue" if changed
                else f"Order {order_id} was not skipped")
        return OrderSkipResult(
            ok=True, order_id=order_id, skipped=now_skipped,
            changed=changed, message=message,
        )

    @app.post("/api/v1/orders/{order_id}/skip", response_model=OrderSkipResult)
    def skip_order_endpoint(
        order_id: str,
        body: Optional[OrderSkipRequest] = None,
        reason: str = fastapi.Query(default=""),
    ):
        """Withhold an order from dispatch — `mso order skip` over HTTP.

        This is what OrderDrawer's Remove does, and the drawer says so: an
        order is NOT deleted. Its file stays where it is, the skip list
        (`config/skipped-orders.json`) is what changes, and `scan_all_queues`
        drops it from every dispatch tick thereafter. Reversible via /unskip.

        Deletion is deliberately not offered (PLAN §5.3): removing an order
        from a voyage manifest without skipping it strands it, which is why
        `mso order remove --from-voyage` couples the two — a Hub verb that
        did half of that is a stranding generator.
        """
        # FTR-MSO-2026-0721: a blockage Option POSTs its server-named
        # `hubPath` verbatim with no body, so a `?reason=` query is honoured
        # too. The body wins when both are sent.
        return _skip_order(order_id, skip=True,
                           reason=((body.reason if body else "") or reason))

    @app.post("/api/v1/orders/{order_id}/unskip", response_model=OrderSkipResult)
    def unskip_order_endpoint(order_id: str):
        """Return a skipped order to dispatch — `mso order unskip` over HTTP."""
        return _skip_order(order_id, skip=False)

    @app.post("/api/v1/orders/{order_id}/attach", response_model=OrderAttachResult)
    def attach_order_endpoint(order_id: str, body: OrderAttachRequest):
        """Attach an existing order to a voyage — `mso order attach` over HTTP.

        BUG-MSO-2026-0794. Writes the order's `voyageId`/`voyageBranch` AND the
        voyage manifest's `orders[]` through `order_attach.attach_order_to_voyage`
        — the one implementation the CLI calls too — or neither: a failed
        manifest write restores the order file's original bytes. This is why
        `voyageId`/`voyageBranch` are not PATCH fields.

        The voyage is resolved against the ORDER's own workspace plane, so a
        voyage belonging to another workspace is simply 404. `voyageBranch`
        comes from the manifest, never from the request.

        `attached` is read back from the manifest after the write; the endpoint
        never returns 200 with it False (BUG-MSO-2026-0555).
        """
        _require_control_tier()
        _validate_order_id(order_id)
        from maestro.core import order_attach, order_create, voyage_core
        from maestro.core.order_ids import OrderValidationError
        from maestro.hub.review import _get_mso_dir
        from maestro.identity.gate import CapabilityDenied

        plane_blocked = _plane_writable_reason()
        if plane_blocked:
            raise fastapi.HTTPException(status_code=503, detail=plane_blocked)

        ws_id, ws_root = _find_order_workspace_any(order_id)
        mso = _get_mso_dir(ws_root)
        try:
            outcome = order_attach.attach_order_to_voyage(
                mso, order_id, body.voyageId, attached_by="hub")
        except CapabilityDenied as exc:
            raise fastapi.HTTPException(status_code=403, detail=str(exc))
        except (order_create.OrderNotFound, voyage_core.VoyageNotFound) as exc:
            raise fastapi.HTTPException(status_code=404, detail=str(exc))
        except (voyage_core.VoyageOrderRefused, order_attach.OrderAttachRefused,
                order_create.OrderEditRefused) as exc:
            raise fastapi.HTTPException(status_code=409, detail=str(exc))
        except OrderValidationError as exc:
            raise fastapi.HTTPException(status_code=400, detail=str(exc))
        except FileNotFoundError as exc:
            raise fastapi.HTTPException(status_code=404, detail=str(exc))
        except OSError:
            raise fastapi.HTTPException(status_code=503, detail=STALE_MOUNT_MESSAGE)

        attached = outcome.order_id in outcome.voyage_order_ids
        if not attached:
            raise fastapi.HTTPException(
                status_code=500,
                detail=f"Voyage manifest {outcome.voyage_path} does not list "
                       f"{outcome.order_id} after attaching — check it by hand.")

        if outcome.changed:
            message = f"Order {outcome.order_id} attached to {outcome.voyage_id}"
            if outcome.voyage_branch:
                message += f" (branch {outcome.voyage_branch})"
        else:
            message = (f"Order {outcome.order_id} was already attached to "
                       f"{outcome.voyage_id}")
        return OrderAttachResult(
            ok=True,
            order_id=outcome.order_id,
            voyage_id=outcome.voyage_id,
            voyage_branch=outcome.voyage_branch,
            attached=attached,
            voyage_order_ids=list(outcome.voyage_order_ids),
            changed=outcome.changed,
            message=message,
        )

    # -----------------------------------------------------------------------
    # SDLC provider configuration (FTR-MSO-2026-0767, PLAN-PLN-MSO-2026-0747
    # Order 10a, D8) — the Hub's FIRST configuration write (Finding C).
    #
    # Every write goes through `maestro.providers.config` — the ONE writer
    # Order 8 established — never through a second read/write of
    # workspace.json here. GET/PUT are workspace-scoped (a `providers` block
    # lives in that workspace's own `config/workspace.json`); `test` is the
    # same `resolve_explain()` call `mso doctor --explain` and
    # `mso providers test` already make, so there is no second answer to "is
    # this provider working".
    # -----------------------------------------------------------------------

    def _providers_mso_dir(workspace_id: str):
        """Return the PRODUCT ROOT for *workspace_id* — never the already-
        resolved ``.mso`` dir.

        ``providers.config``'s functions (``list_providers``/``set_provider``/
        ``unset_provider``/``test_provider``) each resolve ``.mso`` themselves
        via ``resolve_artefact_dir()`` internally, exactly mirroring
        ``maestro.cli.find_workspace()``'s callers (``cmd_providers``). Passing
        an already-resolved ``.mso`` here double-appends it, landing every Hub
        provider read/write at ``<root>/.mso/.mso/...`` — a phantom file
        nothing else reads (DEF-001, FTR-MSO-2026-0767).
        """
        from maestro.workspace import artefact_parent_for_entry

        entry = _resolve_workspace_entry(workspace_id)
        return artefact_parent_for_entry(entry)

    @app.get(
        "/api/v1/workspaces/{workspace_id}/providers",
        response_model=ProvidersListResponse,
    )
    async def list_workspace_providers(workspace_id: str):
        """Every provider kind: installed ids, the configured entry (if any,
        verbatim — credential references are never resolved here) and any
        signed-bundle lock. Read-only; ungated by tier (mirrors `review` /
        `orderRetry` above — reading configuration is not the action D8
        gates)."""
        from maestro.providers import config as providers_config

        try:
            mso = _providers_mso_dir(workspace_id)
            payload = providers_config.list_providers(mso)
        except OSError:
            raise fastapi.HTTPException(status_code=503, detail=STALE_MOUNT_MESSAGE)
        return ProvidersListResponse(providers=payload)

    @app.put(
        "/api/v1/workspaces/{workspace_id}/providers",
        response_model=ProviderWriteResult,
    )
    async def set_workspace_provider(workspace_id: str, body: ProviderWriteRequest):
        """Set (or, with ``id=None``, unset) one provider kind.

        AC1: a body naming any key outside ``kind``/``id``/``config`` never
        reaches here — FastAPI's own validation (``ProviderWriteRequest``'s
        ``extra="forbid"``) rejects it as a 422 first, so the file is
        provably untouched. AC2: gated exactly like the Hub's other acting
        endpoints — Team/Enterprise tier, then the observe-only 409 (D8; see
        ``PROVIDERS_WRITE_UNAVAILABLE_MESSAGE``'s docstring for why this is
        the observe-only probe rather than the plane-writability one every
        order-authoring endpoint uses). AC4: the only write is the call to
        ``providers.config`` below — no second writer.
        """
        _require_control_tier()
        if _is_observe_only():
            raise fastapi.HTTPException(status_code=409, detail=OBSERVE_ONLY_MESSAGE)

        from maestro.providers import config as providers_config

        try:
            mso = _providers_mso_dir(workspace_id)
            if body.id is None:
                result = providers_config.unset_provider(mso, body.kind)
                message = (
                    f"{body.kind} unset — reverts to the shipped default"
                    if result["removed"]
                    else f"{body.kind} was not configured — nothing to unset"
                )
                return ProviderWriteResult(
                    ok=True, kind=result["kind"], removed=result["removed"],
                    message=message,
                )
            result = providers_config.set_provider(
                mso, body.kind, body.id, body.config or {})
            return ProviderWriteResult(
                ok=True, kind=result["kind"], id=result["id"], config=result["config"],
                message=f"{result['kind']} set to {result['id']}",
            )
        except providers_config.ProviderLockedError as exc:
            raise fastapi.HTTPException(status_code=409, detail=str(exc))
        except providers_config.ProviderConfigError as exc:
            raise fastapi.HTTPException(status_code=400, detail=str(exc))
        except OSError:
            raise fastapi.HTTPException(status_code=503, detail=STALE_MOUNT_MESSAGE)

    # -----------------------------------------------------------------------
    # Status-monitor auto-spawn preference (FTR-MSO-2026-0635)
    #
    # MACHINE-level, not workspace-scoped: the route carries no workspace id
    # because the value has none. `maestro.core.spawn_monitor` is the one
    # resolver/writer — the same call `fleet_runner._spawn_monitor_enabled`
    # makes — so what this reports is what the next dispatch does.
    # -----------------------------------------------------------------------

    def _spawn_monitor_payload(resolution, message: str = "") -> "SpawnMonitorSetting":
        return SpawnMonitorSetting(
            effective=resolution.effective,
            source=resolution.source,
            envValue=resolution.env_value,
            savedValue=resolution.saved_value,
            settingsPath=str(resolution.settings_path),
            settingsError=resolution.settings_error,
            observeOnly=_is_observe_only(),
            message=message,
        )

    @app.get("/api/v1/machine/spawn-monitor", response_model=SpawnMonitorSetting)
    async def get_spawn_monitor_setting():
        """Effective status-monitor preference and every input to it. Read-only,
        ungated — reading configuration is not the action the tier gates."""
        from maestro.core import spawn_monitor

        return _spawn_monitor_payload(spawn_monitor.resolve())

    @app.put("/api/v1/machine/spawn-monitor", response_model=SpawnMonitorSetting)
    async def set_spawn_monitor_setting(body: SpawnMonitorWriteRequest):
        """Save (true/false) or clear (null) the machine preference.

        Gated like the Hub's other acting endpoints — Team/Enterprise tier,
        then the observe-only 409 with the SAME string
        ``capabilities.spawnMonitorWrite`` declares before the click. The
        response is read back after the write, so an environment override that
        makes the save ineffective is reported, not hidden.
        """
        _require_control_tier()
        if _is_observe_only():
            raise fastapi.HTTPException(
                status_code=409, detail=SPAWN_MONITOR_WRITE_UNAVAILABLE_MESSAGE)

        from maestro.core import spawn_monitor

        try:
            resolution = spawn_monitor.set_spawn_monitor(body.spawnMonitor)
        except spawn_monitor.SpawnMonitorSettingError as exc:
            raise fastapi.HTTPException(status_code=409, detail=str(exc))
        except OSError as exc:
            raise fastapi.HTTPException(
                status_code=500,
                detail=f"Could not write the machine settings file: {exc}")

        on_off = "on" if resolution.effective else "off"
        if body.spawnMonitor is None:
            message = "Saved preference cleared for every project on this device"
        else:
            saved = "on" if body.spawnMonitor else "off"
            message = f"Status monitor saved as {saved} for every project on this device"
        if resolution.source == spawn_monitor.SOURCE_ENV:
            message += (
                f" — but {spawn_monitor.ENV_VAR}={resolution.env_value} in the Hub's "
                f"environment overrides it, so the next dispatch is still {on_off}")
        else:
            message += f"; the next dispatch is {on_off}"
        return _spawn_monitor_payload(resolution, message=message)

    @app.post(
        "/api/v1/workspaces/{workspace_id}/providers/test",
        response_model=ProviderTestResult,
    )
    async def test_workspace_provider(workspace_id: str, body: ProviderTestRequest):
        """Resolve one kind's effective provider — the SAME
        ``providers.config.test_provider`` (→ ``resolve_explain``) call `mso
        providers test` and `mso doctor --explain` make. Read-only; ungated
        by tier (testing a resolution is not the write D8 gates), gated only
        by whether the kind is recognised."""
        from maestro.providers import config as providers_config

        try:
            mso = _providers_mso_dir(workspace_id)
            resolved = providers_config.test_provider(mso, body.kind)
        except providers_config.ProviderConfigError as exc:
            raise fastapi.HTTPException(status_code=400, detail=str(exc))
        except OSError:
            raise fastapi.HTTPException(status_code=503, detail=STALE_MOUNT_MESSAGE)

        return ProviderTestResult(
            ok=resolved.available,
            kind=resolved.kind,
            resolved=ProviderResolvedInfo(
                providerId=resolved.provider_id, tier=resolved.tier,
                available=resolved.available, reason=resolved.reason,
            ),
        )

    # -----------------------------------------------------------------------
    # Settings (FTR-MSO-2026-0801, PLAN-PLN-MSO-2026-0792 §5 / Order 5a).
    #
    # A thin projection of `maestro.core.settings_core` — the ONE writer of
    # settings — over HTTP. Nothing here reads or writes a settings file:
    # the list is `settings_core.effective()` per registry key, a write is
    # `set_setting` / `unset_setting`, and the response is what that core
    # read back off disk. Workspace routes pass the workspace's `.mso`
    # artefact dir (settings_core's contract, unlike providers.config which
    # takes the product root); device routes pass `None`.
    #
    # Gates, in order, on PUT only (reads are ungated, like providers GET):
    # D2 tier (Pro+) 403 → observe-only 409 → the core's own typed refusals
    # (unknown key / validation 400, bundle lock / unwritable file 409,
    # `settings.write` identity capability 403).
    # -----------------------------------------------------------------------

    def _settings_mso_dir(workspace_id: str):
        from maestro.workspace import artefact_parent_for_entry, resolve_artefact_dir

        entry = _resolve_workspace_entry(workspace_id)
        return resolve_artefact_dir(artefact_parent_for_entry(entry))

    def _setting_entry(eff):
        from maestro.core import settings_core
        from maestro.hub.models import SettingEntry

        spec = settings_core.get_spec(eff.key).to_dict()
        data = eff.to_dict()
        return SettingEntry(
            key=eff.key, value=data["value"], source=data["source"],
            sourceDetail=data["sourceDetail"], default=data["default"],
            scope=data["scope"], type=data["type"],
            description=spec["description"], env=spec["env"],
            choices=spec["choices"], minimum=spec["minimum"],
            nullable=spec["nullable"], restartRequired=data["restartRequired"],
            locked=data["locked"], lockedReason=data["lockedReason"],
            installed=data.get("installed"), generation=data.get("generation"),
            error=data.get("error"),
        )

    def _settings_error_detail(exc) -> str:
        hint = getattr(exc, "hint", None)
        return f"{exc} — {hint}" if hint else str(exc)

    def _require_settings_write_allowed():
        """D2 tier (403) then observe-only (409) — the same reason the
        capability map declared before the click."""
        from maestro.hub.models import SETTINGS_WRITE_TIER_MESSAGE

        reason = _settings_write_blocked_reason()
        if reason == SETTINGS_WRITE_TIER_MESSAGE:
            raise fastapi.HTTPException(status_code=403, detail=reason)
        if reason is not None:
            raise fastapi.HTTPException(status_code=409, detail=reason)

    def _audit_settings_write(mso, result, *, unset: bool) -> None:
        """Governed mode records who changed which setting (the audit-line
        contract PLAN-0792 §5 inherits). Best-effort, exactly like the LEAD
        run endpoint's audit append: a failed audit write never turns a
        completed settings write into an error response. The value is not
        recorded — only the key, scope and what disk now says the source is."""
        ws_root = mso.parent
        try:
            from maestro.governance import is_governed

            if not is_governed(mso):
                return
            try:
                from maestro.identity.auth import resolve_caller
                who = resolve_caller(ws_root)
            except Exception:
                who = "hub"
            from maestro.audit import get_audit_log
            get_audit_log(ws_root).append(
                action="settings.unset" if unset else "settings.set",
                target=result.key,
                result="ok",
                metadata={
                    "scope": result.extra.get("writtenScope"),
                    "changed": bool(result.extra.get("changed")),
                    "source": result.source,
                    "via": "hub",
                },
                actor=who,
            )
        except Exception:
            pass

    def _write_setting(mso, body: SettingWriteRequest, scope: str) -> SettingWriteResult:
        from maestro.core import settings_core
        from maestro.identity.gate import CapabilityDenied

        value_sent = "value" in body.model_fields_set
        if body.unset and value_sent:
            raise fastapi.HTTPException(
                status_code=400,
                detail="send either {key, value} or {key, unset: true}, not both")
        if not body.unset and not value_sent:
            raise fastapi.HTTPException(
                status_code=400,
                detail="a settings write needs {key, value} or {key, unset: true}")
        try:
            if body.unset:
                result = settings_core.unset_setting(mso, body.key, scope=scope)
            else:
                result = settings_core.set_setting(mso, body.key, body.value, scope=scope)
        except settings_core.SettingsError as exc:
            raise fastapi.HTTPException(
                status_code=exc.http_status, detail=_settings_error_detail(exc))
        except CapabilityDenied as exc:
            raise fastapi.HTTPException(status_code=403, detail=str(exc))
        except OSError:
            raise fastapi.HTTPException(status_code=503, detail=STALE_MOUNT_MESSAGE)

        if mso is not None:
            _audit_settings_write(mso, result, unset=body.unset)

        changed = bool(result.extra.get("changed"))
        verb = "unset" if body.unset else "set"
        message = (
            f"{body.key} {verb} ({scope}) — effective value now from {result.source}"
            if changed else f"{body.key} unchanged — nothing to {verb} in the {scope} file"
        )
        return SettingWriteResult(
            ok=True, setting=_setting_entry(result), changed=changed,
            writtenScope=result.extra.get("writtenScope") or scope, message=message,
        )

    def _list_settings(mso, scope: str) -> SettingsListResponse:
        from maestro.core import settings_core

        try:
            specs = settings_core.list_specs(scope=scope)
            entries = [_setting_entry(settings_core.effective(mso, s.key)) for s in specs]
        except settings_core.SettingsError as exc:
            raise fastapi.HTTPException(
                status_code=exc.http_status, detail=_settings_error_detail(exc))
        except OSError:
            raise fastapi.HTTPException(status_code=503, detail=STALE_MOUNT_MESSAGE)
        models = settings_core.model_vocabulary() if scope == settings_core.SCOPE_WORKSPACE else []
        return SettingsListResponse(scope=scope, settings=entries, models=models)

    @app.get(
        "/api/v1/workspaces/{workspace_id}/settings",
        response_model=SettingsListResponse,
    )
    async def list_workspace_settings(workspace_id: str):
        """Every registry key a workspace file may hold (``workspace`` and
        ``both`` scope): effective value, source, default, type,
        restartRequired, locked + reason. Read-only; ungated by tier."""
        try:
            mso = _settings_mso_dir(workspace_id)
        except OSError:
            raise fastapi.HTTPException(status_code=503, detail=STALE_MOUNT_MESSAGE)
        return _list_settings(mso, "workspace")

    @app.put(
        "/api/v1/workspaces/{workspace_id}/settings",
        response_model=SettingWriteResult,
    )
    async def set_workspace_setting(workspace_id: str, body: SettingWriteRequest):
        """Set (``{key, value}``) or unset (``{key, unset: true}``) one key in
        the workspace's ``config/workspace.json`` (or the delegated persona /
        role-models / providers store). A device-only key is a 400 here —
        use ``PUT /api/v1/settings``."""
        _require_settings_write_allowed()
        try:
            mso = _settings_mso_dir(workspace_id)
        except OSError:
            raise fastapi.HTTPException(status_code=503, detail=STALE_MOUNT_MESSAGE)
        return _write_setting(mso, body, "workspace")

    @app.get("/api/v1/settings", response_model=SettingsListResponse)
    async def list_device_settings():
        """Every registry key the device file may hold (``device`` and
        ``both`` scope), resolved with no workspace. Read-only; ungated."""
        return _list_settings(None, "device")

    @app.put("/api/v1/settings", response_model=SettingWriteResult)
    async def set_device_setting(body: SettingWriteRequest):
        """Set or unset one key in ``<MAESTRO_HOME>/config/settings.json`` (or
        the device persona file). A workspace-only key is a 400 here."""
        _require_settings_write_allowed()
        return _write_setting(None, body, "device")

    # -----------------------------------------------------------------------
    # Usage aggregation endpoints (FTR-MSO-2026-0333) — read-only, ungated
    # -----------------------------------------------------------------------

    @app.get("/api/v1/usage", response_model=UsageRollup)
    async def get_usage_rollup(
        from_: str | None = fastapi.Query(default=None, alias="from"),
        to: str | None = fastapi.Query(default=None),
        group_by: str = fastapi.Query(default="project"),
    ):
        """Cross-workspace usage rollup, optionally filtered by date range.

        group_by: 'project' | 'voyage' | 'order' | 'role'
        from / to: inclusive date range in YYYY-MM-DD format
        """
        from maestro.hub.aggregator import aggregate_usage_cross_workspace
        if group_by not in ("project", "voyage", "order", "role"):
            raise fastapi.HTTPException(
                status_code=400,
                detail=f"Invalid group_by '{group_by}'. Must be one of: project, voyage, order, role",
            )
        return aggregate_usage_cross_workspace(
            from_date=from_,
            to_date=to,
            group_by=group_by,
        )

    @app.get("/api/v1/usage/projects/{project_id}", response_model=UsageRollup)
    async def get_project_usage(
        project_id: str,
        from_: str | None = fastapi.Query(default=None, alias="from"),
        to: str | None = fastapi.Query(default=None),
    ):
        """Per-project usage with voyage/order breakdown."""
        import maestro.registry as registry
        from maestro.hub.aggregator import aggregate_usage_for_project
        from maestro.workspace import artefact_parent_for_entry

        projects = registry.list_projects()
        if project_id not in projects:
            raise fastapi.HTTPException(status_code=404, detail=f"Project '{project_id}' not found")
        ws_root = artefact_parent_for_entry(projects[project_id])
        return aggregate_usage_for_project(project_id, ws_root, from_date=from_, to_date=to)

    @app.get("/api/v1/usage/voyages/{voyage_id}", response_model=UsageRollup)
    async def get_voyage_usage(
        voyage_id: str,
        from_: str | None = fastapi.Query(default=None, alias="from"),
        to: str | None = fastapi.Query(default=None),
    ):
        """Per-voyage usage: orders breakdown (+ role breakdown if FTR-0332 data present)."""
        import maestro.registry as registry
        from maestro.hub.aggregator import aggregate_usage_for_voyage, _get_mso_dir
        from maestro.workspace import artefact_parent_for_entry

        projects = registry.list_projects()
        for ws_id, entry in projects.items():
            ws_root = artefact_parent_for_entry(entry)
            try:
                mso = _get_mso_dir(ws_root)
            except Exception:
                continue
            for sub in ("active", "complete"):
                if (mso / "voyages" / sub / f"{voyage_id}.json").exists():
                    return aggregate_usage_for_voyage(voyage_id, ws_root, from_date=from_, to_date=to)
        # No workspace claims the voyage — return a zero rollup (not an error)
        return UsageRollup(from_date=from_, to_date=to, group_by="order")

    @app.get("/api/v1/usage/orders/{order_id}", response_model=OrderUsageDetail)
    async def get_order_usage(order_id: str):
        """Per-order usage: roles/iterations/models breakdown."""
        from maestro.hub.aggregator import _find_order_usage_dir, get_order_usage_detail

        usage_dir = _find_order_usage_dir(order_id)
        if usage_dir is None:
            # Order not found in any workspace — return a zero detail (not an error)
            return OrderUsageDetail(order_id=order_id)
        return get_order_usage_detail(order_id, usage_dir)

    # -----------------------------------------------------------------------
    # Report endpoints (FTR-MSO-2026-0729) — read-only, ungated
    # -----------------------------------------------------------------------
    # Registered from `maestro/hub/reports_api.py`, which is handed THIS
    # function's own `_validate_order_id` and `_iter_workspaces` closures rather
    # than growing copies of them: a hardening change to that id regex then
    # cannot leave a report route behind. The call ADDS routes and modifies
    # none — PLAN-PLN-MSO-2026-0726 §4 lists every pre-existing route, and in
    # particular the two artefact routes above, as DO-NOT-MODIFY.
    from maestro.hub.reports_api import register_report_routes

    register_report_routes(
        app,
        validate_order_id=_validate_order_id,
        iter_workspaces=_iter_workspaces,
    )

    @app.websocket("/api/v1/lifecycle/stream")
    async def lifecycle_stream(websocket: fastapi.WebSocket):
        import asyncio
        import maestro.registry as registry
        import maestro.hub.server as _server_mod
        from maestro.hub.lifecycle_tail import (
            LifecycleTail, _parse_event_type, _parse_timestamp, _parse_message,
            _parse_order_id, _parse_role, _parse_crew_slot, _parse_subtype,
        )
        from maestro.hub.models import LifecycleEvent
        from maestro.workspace import artefact_parent_for_entry

        def _build_event(ws_id: str, ws_name: str, line: str) -> LifecycleEvent:
            return LifecycleEvent(
                workspace_id=ws_id,
                workspace_name=ws_name,
                line=line,
                message=_parse_message(line),
                timestamp=_parse_timestamp(line),
                event_type=_parse_event_type(line),
                order_id=_parse_order_id(line),
                crew_slot=_parse_crew_slot(line),
                role=_parse_role(line),
                subtype=_parse_subtype(line),
            )

        # Audit finding H6: WebSockets bypass CORS, so validate the Origin
        # against the allowlist and enforce the bearer token (query param) BEFORE
        # accepting — otherwise any web page could open ws:// to the localhost
        # Hub and live-tail every workspace's lifecycle log.
        origin = websocket.headers.get("origin")
        if origin and origin not in _ORIGINS:
            await websocket.close(code=1008)
            return
        _tok = _expected_token()
        if _tok:
            import hmac as _hmac
            presented = websocket.query_params.get("token", "")
            if not presented or not _hmac.compare_digest(presented, _tok):
                await websocket.close(code=1008)
                return

        await websocket.accept()
        try:
            projects = registry.list_projects()
            # Optional ?workspace_id=<ID> scopes the stream to one workspace
            # (the detail page passes it); absent → stream all (overview page).
            only = websocket.query_params.get("workspace_id")
            if only:
                projects = {k: v for k, v in projects.items() if k == only}
            tails: dict[str, tuple[str, LifecycleTail]] = {
                ws_id: (ws_id, LifecycleTail(artefact_parent_for_entry(entry)))
                for ws_id, entry in projects.items()
            }

            # Backfill: send last 20 lines per workspace on connect
            for ws_id, (ws_name, tail) in tails.items():
                for line in tail.read_last_n(20):
                    await websocket.send_json(_build_event(ws_id, ws_name, line).model_dump())
                tail.seek_to_end()

            # Poll loop: push new lines every _WS_POLL_INTERVAL seconds
            while True:
                await asyncio.sleep(_server_mod._WS_POLL_INTERVAL)
                for ws_id, (ws_name, tail) in tails.items():
                    for line in tail.read_new_lines():
                        await websocket.send_json(_build_event(ws_id, ws_name, line).model_dump())
        except Exception:
            pass  # client disconnected or connection error

    # -----------------------------------------------------------------------
    # API namespace 404 fallback (BUG-MSO-2026-0627)
    # -----------------------------------------------------------------------
    # Registered AFTER every other /api/... route above and BEFORE the static
    # UI mount below — route order is match order in Starlette, so this only
    # ever catches a path under /api that nothing more specific matched.
    #
    # Without this, an unmatched /api/... request falls all the way through
    # FastAPI's routing and is served by the StaticFiles("/") mount at the
    # bottom of this function as the SPA's OWN 404 page — a ~20KB HTML
    # document (markup, script tags, inline CSS) delivered with a 200-shaped
    # body to a caller that expected JSON. That HTML then propagates raw
    # through the frontend's error-handling chain (apiFetch -> Error message
    # -> drawer/toast) because nothing along that chain expected non-JSON.
    # The reported case: the LEAD drawer calling a route (`/lead/detail`)
    # that a stale, not-yet-restarted Hub process didn't have yet.
    #
    # The static mount is correct for UI routes and wrong for the /api
    # namespace; this route draws that boundary explicitly instead of
    # relying on route-registration order to (accidentally) get it right.
    @app.api_route(
        "/api/{full_path:path}",
        methods=["GET", "POST", "PUT", "PATCH", "DELETE"],
        include_in_schema=False,
    )
    async def _api_route_not_found(full_path: str):
        raise fastapi.HTTPException(
            status_code=404, detail=f"API route not found: /api/{full_path}")

    # --- Static UI bundle (FTR-MSO-2026-0421) -------------------------------
    # The LOCAL, no-Docker Hub serves the statically-exported frontend from the
    # backend on the SAME origin/port — no Node, no second daemon. The bundle is
    # shipped in the wheel at `maestro/hub/static/` (package-data; the publish
    # workflow runs `npm run build` and copies `maestro-hub/out/` there before
    # the wheel build). Mounted at "/" AFTER every API route, so the explicit
    # `/api/...` routes still match first and the mount is the SPA fallback.
    #
    # A source checkout with no built bundle degrades gracefully: the mount is
    # skipped and "/" returns a clear, machine-readable message pointing at the
    # build step — the API stays fully available under /api/v1/.
    from pathlib import Path as _Path

    _static_dir = _Path(__file__).resolve().parent / "static"
    if (_static_dir / "index.html").is_file():
        from fastapi.staticfiles import StaticFiles

        app.mount("/", StaticFiles(directory=str(_static_dir), html=True), name="hub-ui")
    else:
        # BUG-MSO-2026-0516: name the resolved path checked. Without it, an
        # operator has no way to tell "genuinely installed wheel missing its
        # bundle" apart from "this is a source checkout, which never ships one
        # by design" — both looked identical before this fix, and the latter
        # is the far more common case (it's exactly what running `mso hub
        # start` from inside a Maestro checkout produces).
        _UI_MISSING_MESSAGE = (
            "Maestro Hub API is running, but the web UI bundle is not built. "
            f"Checked for a built bundle at: {_static_dir} — if that path is "
            "inside a Maestro source checkout rather than an installed wheel's "
            "site-packages, this is expected: checkouts never carry a built "
            "bundle (it's produced by CI at publish time). The API is fully "
            "available under /api/v1/. To serve the UI, either install a "
            "released wheel (which ships the built bundle at "
            "maestro/hub/static/), run `npm ci && npm run build` in maestro-hub/ "
            "and copy the resulting out/ to maestro/hub/static/, or use the "
            "Docker frontend container."
        )

        @app.get("/", include_in_schema=False)
        async def _ui_bundle_missing():
            return fastapi.responses.JSONResponse(
                status_code=200,
                content={"ui": "unavailable", "message": _UI_MISSING_MESSAGE},
            )

    return app
