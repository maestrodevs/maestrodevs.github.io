# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Pydantic models for the Maestro Hub API (all phases in one module).

Field names here are chosen to serialize to JSON that matches the frontend
TypeScript interfaces in `maestro-hub/app/types/index.ts` EXACTLY (the
authoritative data contract). Top-level entity fields are snake_case to match
the TS interfaces; the WorkspaceConfig sub-object intentionally keeps camelCase
keys (maxCrews, completion.idleWatchdog...) because the frontend reads them
straight from .mso/config/workspace.json shapes.
"""

from __future__ import annotations

from typing import Any, List, Optional

from pydantic import BaseModel, ConfigDict, Field


# ---- Phase 1 ----------------------------------------------------------------

class HealthResponse(BaseModel):
    status: str = "ok"
    version: str
    workspaces: int = 0
    # BUG-MSO-2026-0467: was the poller's first full scan pass complete when
    # this response was built? False during the cold-start window — lets a
    # caller distinguish "workspaces: 0, still scanning" from "workspaces: 0,
    # genuinely nothing registered" without a second endpoint round-trip.
    poller_ready: bool = True
    # BUG-MSO-2026-0627: `version` above is `maestro.__version__` as PINNED at
    # process start (Python caches the import for the process lifetime) — the
    # code this Hub process is actually RUNNING, which can silently fall
    # behind after a `pip install --upgrade` if the daemon isn't restarted
    # (the FTR-MSO-2026-0577/0578 route-table gap this order traces to).
    # `installedVersion` is read FRESH on every request via
    # `importlib.metadata` (never cached in `sys.modules`), so it reflects
    # what's on disk right now even without a restart — the same
    # runningVersion/installedVersion split FTR-MSO-2026-0588 gave the LEAD
    # daemon, done here as a live self-check since the Hub has no per-tick
    # state file to persist a reader-independent snapshot into.
    installedVersion: Optional[str] = None
    versionMismatch: bool = False
    # BUG-MSO-2026-0712: when THIS backend process started, and how long it has
    # been up. Measured by the process about itself (a module-level stamp taken
    # at `create_app()`), not read back from the PID record — so a restart is
    # visible in the dashboard header the moment the new process answers,
    # without the reader having to trust a file some other process wrote. The
    # 2026-09-09 death was noticed only because a human opened the dashboard;
    # an uptime that resets to seconds is what makes the NEXT one self-evident.
    startedAt: Optional[str] = None
    uptimeSeconds: Optional[float] = None


class PollerStatus(BaseModel):
    """Poller readiness — the authoritative source for the initialising-vs-empty
    distinction (BUG-MSO-2026-0467). See WorkspacePoller.status()."""
    state: str = "ready"   # "initialising" | "ready"
    ready: bool = True
    scanned: int = 0
    total: int = 0


class AttentionBreakdown(BaseModel):
    """Per-workspace rollup of BUG-MSO-2026-0451's held/dispatchable taxonomy,
    computed workspace-by-workspace by ``maestro.hub.attention``
    (FTR-MSO-2026-0487 / PLAN-PLN-MSO-2026-0468 §2 — reuses the four category
    NAMES ``get_held_breakdown()`` already established; this is not a second,
    competing taxonomy).

    Bucket mapping (§2): review_gated -> "In Review" (a human decision),
    stranded -> "Needs Attention" (a recovery), dep_held -> "Blocked"
    (resolves itself), skipped -> "Skipped" (operator-intended invisibility).
    """
    review_gated: int = 0
    stranded: int = 0
    dep_held: int = 0
    skipped: int = 0
    # needs_you = review_gated + stranded — the two buckets a human must act
    # on. Excludes dep_held (self-resolving) and skipped (operator-intended),
    # matching §2's ruling that both merge only at this summary level, never
    # in the per-bucket lists.
    needs_you: int = 0


class WorkspaceSummary(BaseModel):
    id: str
    name: str
    path: str
    online: bool = True
    dispatcher_running: bool = False
    # FTR-MSO-2026-0498: "RUNNING" | "WEDGED" | "STOPPED" | "PAUSING" | "PAUSED"
    # ("" when unknown). A plain str, not a Literal, so a future state can
    # never fail response validation. dispatcher_running stays the bool.
    dispatcher_state: str = ""
    dispatcher_pause_detail: str = ""
    active_voyage_count: int = 0
    pending_order_count: int = 0
    active_crew_count: int = 0
    review_pending_count: int = 0
    # Frontend Workspace interface uses `pending_review_count`; mirror it so the
    # overview cards can read either name. (Kept additive — review_pending_count
    # above is preserved so existing consumers/tests don't break.)
    pending_review_count: int = 0
    # BUG-MSO-2026-0451: orders excluded from pending_order_count because the
    # dispatcher is holding them (dep-held or operator-skipped) — the Hub-card
    # counterpart of `mso status`'s "N held" figure, so a fixed pending count
    # doesn't just make skipped/dep-held work silently vanish from the card.
    held_order_count: int = 0
    # FTR-MSO-2026-0487: the named breakdown behind held_order_count, plus the
    # review-gated + stranded categories held_order_count never counted (it
    # only ever covered dep-held + skipped). This is the one figure the
    # workspace card needs for "Needs you: N".
    attention: AttentionBreakdown = Field(default_factory=AttentionBreakdown)
    # FTR-MSO-2026-0539: forward-referenced (LeadPip is defined further down
    # this module, alongside LeadStatus) — `from __future__ import
    # annotations` at the top of this file makes the forward reference safe.
    lead: Optional["LeadPip"] = None


# ---- Phase 2 ----------------------------------------------------------------

class ClaimedBy(BaseModel):
    """The FTR-MSO-2026-0374 shared-mode claim-by-commit stamp.

    Matches the frontend `ClaimedBy` interface. Mirrors the shape
    `_stamp_claim()` (maestro/core/artefact_sync.py) writes onto the durable
    order JSON — engineer identity, host, pid, and claim timestamp.
    """
    engineer: str = ""
    host: str = ""
    pid: Optional[int] = None
    at: str = ""


class Order(BaseModel):
    """Matches the frontend `Order` interface (app/types/index.ts)."""
    id: str
    title: str = ""
    description: Optional[str] = None
    status: str = "PENDING"
    role: str = ""
    target_role: Optional[str] = None
    voyage_id: Optional[str] = None
    workspace_id: str = ""
    # BUG-MSO-2026-0711: 'critical' is its own value, not folded into 'high' —
    # it is the priority that overrides the queue tier.
    priority: Optional[str] = None  # 'critical' | 'high' | 'normal' | 'low'
    created_at: str = ""
    updated_at: Optional[str] = None
    started_at: Optional[str] = None
    completed_at: Optional[str] = None
    depends_on: Optional[list[str]] = None
    role_sequence: list[str] = Field(default_factory=list)
    # FTR-MSO-2026-0622: the order's acceptance criteria, carried through to
    # the frontend RAW (only the id/description shape is normalised — see
    # aggregator._map_order). The `Order` contract never carried this field,
    # so the Hub's OrderDrawer rendered an EMPTY acceptance-criteria list for
    # every order, including the 551 live ones that have criteria — a false
    # impression of an order's own definition, and (once Save became real)
    # the shape that would have let an edit overwrite criteria the operator
    # was never shown.
    #
    # Untyped `list` on purpose. Live artefacts carry two shapes (bare strings
    # AND dicts) and the dicts carry keys the Hub does not model
    # (`validationType`, `command`, `status`, `verifiedBy`, `note`). Modelling
    # a subset here would silently drop the rest on the round trip through an
    # edit, so the entries pass through unchanged and the drawer merges by id.
    acceptance_criteria: Optional[list] = None
    timeout_minutes: Optional[int] = None
    iteration: Optional[int] = None
    max_iterations: Optional[int] = None
    # BUG-MSO-2026-0805: `target_repo` is the order's OWN value when it carries
    # one (`targetRepo`, or a defect's `affectedRepo`), otherwise the repo
    # dispatch resolves from the project registry
    # (`fleet_runner._resolve_target_repo_from_project` — the same function).
    # Most live orders never carry `targetRepo`, so without the fallback a
    # RUNNING order showed "no repo" while running against a real one.
    # `target_repo_source` says which: "order" | "project-default" | None. The
    # drawer must never PATCH a "project-default" value back onto the order.
    target_repo: Optional[str] = None
    target_repo_source: Optional[str] = None
    # BUG-MSO-2026-0805: the order JSON's own `model` pin, verbatim (None when
    # unpinned — the common case).
    model: Optional[str] = None
    # BUG-MSO-2026-0805: what dispatch resolves for the order's current role,
    # via `crew.resolve_model_detail` against THIS workspace's artefact root,
    # and which layer decided: "order" | "workspace" | "overlay" | "default",
    # or "invalid" for an unknown pinned/configured id (dispatch would refuse).
    # The env layer (MAESTRO_MODEL_<ROLE>) is deliberately EXCLUDED: the Hub
    # process's environment is not the dispatcher's, so reading it here would
    # describe a host that dispatches nothing. The drawer says so.
    effective_model: Optional[str] = None
    model_source: Optional[str] = None
    # FTR-MSO-2026-0376: shared-mode multi-engineer visibility. Field names
    # are camelCase by order spec (mirrors Voyage.phaseReason above); absent
    # in embedded/solo mode where the order was never claimed-by-commit.
    claimedBy: Optional[ClaimedBy] = None
    claimedAt: Optional[str] = None
    # FTR-MSO-2026-0487: BUG-MSO-2026-0451 taxonomy tag — one of
    # 'review_gated' | 'stranded' | 'dep_held' | 'skipped', or None when the
    # order is plainly dispatchable/running/complete. Computed per workspace
    # by maestro.hub.attention.classify_orders (never re-derived client-side —
    # PLAN-PLN-MSO-2026-0468 §3.3's "reuse, don't copy the category list").
    attention: Optional[str] = None
    # Human-readable detail for the tag above — e.g. the blocking order id(s)
    # for a dep_held order. Empty/None for categories with no extra detail.
    # BUG-MSO-2026-0703: for a `stranded` order this carries the dispatcher's
    # `operatorNote` — the salvage branch, its diff-stat, the ancestry found,
    # and the exact recovery command — so the Hub shows the NEXT STEP rather
    # than the bare status a stranded order used to be reduced to.
    attention_reason: Optional[str] = None
    # BUG-MSO-2026-0703: the order JSON's `operatorNote` verbatim, whatever the
    # attention category (a stranded order sets it, but so does a STALLED
    # archival — BUG-MSO-2026-0301/0445). None when the order carries none.
    operator_note: Optional[str] = None
    # BUG-MSO-2026-0705: the fleet's OWN QA verdict when this order's stall was
    # a role REJECTION — "rejected by TST: DEF-001 (HIGH) <summary>" — plus the
    # command that resumes it. Mapped straight off the order JSON's `rejection`
    # block (parsed once, at archival, by maestro.core.role_rejection), so the
    # Hub board can show WHY an order is stranded and what to do about it
    # instead of a bare STALLED. None for every order nothing rejected.
    rejection_headline: Optional[str] = None
    rejection_command: Optional[str] = None
    # BUG-MSO-2026-0743: whether this order is on the operator skip list
    # (`.mso/config/skipped-orders.json` — `mso order skip`). Deliberately its
    # OWN field rather than `attention == 'skipped'`: the attention tag is
    # single-valued, and stranded/dep_held/review_gated legitimately overwrite
    # the skipped tag for the same order — so the tag answers "no" for exactly
    # the orders an operator most often skips (a stranded one). Reading skip
    # state off the tag made the Hub's Restore (unskip) control unreachable for
    # every skipped CONVERGENCE_FAILED / BLOCKED / AUTO_SERIALIZE / dep-held
    # order, leaving a second Remove button in its place. Stamped by
    # maestro.hub.attention.apply_skip_state straight from
    # maestro.core.skip_list — the one shared reader — never re-derived.
    is_skipped: bool = False
    # The operator's `--reason` for the skip, when they gave one. Decoration
    # only: a skip with no reason is still a skip, so this being None never
    # implies `is_skipped is False`.
    skip_reason: Optional[str] = None


class VoyagePrEntry(BaseModel):
    """One repo's PR linkage within a voyage's ``prUrls`` map (FTR-MSO-2026-0380).

    Mirrors the per-repo entry ``_apply_pr_linkage``/``_reconcile_multi_repo_voyage``
    write onto ``voyage["prUrls"][repo_slug]`` (maestro/core/fleet_runner.py).
    Field names are camelCase to match the manifest verbatim (same convention
    as Voyage.phaseReason / Order.claimedBy above).
    """
    prNumber: Optional[int] = None
    prUrl: Optional[str] = None
    state: Optional[str] = None
    mergeCommit: Optional[str] = None
    mergedAt: Optional[str] = None
    # BUG-MSO-2026-0637: this repo's work shipped under prNumber/prUrl, which
    # SUPERSEDED the original PR named here (closed unmerged). None otherwise.
    supersededPrNumber: Optional[int] = None
    supersededPrUrl: Optional[str] = None


class VoyageOrderRollup(BaseModel):
    """Effective member-order counts backing the derived voyage phase
    (FTR-MSO-2026-0351). Keys are camelCase by contract (order spec)."""
    total: int = 0
    complete: int = 0
    blocked: int = 0
    inProgress: int = 0
    pending: int = 0
    held: int = 0


class Voyage(BaseModel):
    """Matches the frontend `Voyage` interface."""
    id: str
    title: str = ""
    status: str = "PLANNED"
    branch: str = ""
    order_count: int = 0
    complete_count: int = 0
    orders: Optional[list[Order]] = None
    created_at: str = ""
    pr_url: Optional[str] = None
    # BUG-MSO-2026-0394: sibling flat field to pr_url — the manifest's
    # flat prNumber (written by ``_apply_pr_linkage``), or the single
    # entry's prNumber when the manifest only ever wrote a prUrls map.
    # Ambiguous (left None) for a genuine multi-repo voyage with >1 PR
    # linked — per-repo numbers are available via prUrls in that case.
    pr_number: Optional[int] = None
    workspace_id: str = ""
    repo: str = ""
    worktree: str = ""
    # FTR-MSO-2026-0351: derived lifecycle phase from ledger + archive + PR
    # state (the stored `status` above is kept as-is for back-compat).
    phase: str = "backlog"
    phaseReason: str = ""
    rollup: VoyageOrderRollup = Field(default_factory=VoyageOrderRollup)
    # FTR-MSO-2026-0380: multi-repo voyage reality (FTR-0379 manifest shape).
    # `repo`/`pr_url` above remain the back-compat flat fields (unchanged
    # derivation — most-common targetRepo / best-effort last-recorded PR);
    # these carry the REAL per-repo set so the Hub can render one pill per
    # repo instead of collapsing to a single value. Empty for a legacy/
    # single-repo voyage that never wrote targetRepos/prUrls. camelCase by
    # order spec (mirrors phaseReason/claimedBy — matches the manifest keys
    # verbatim).
    targetRepos: list[str] = Field(default_factory=list)
    prUrls: dict[str, VoyagePrEntry] = Field(default_factory=dict)
    # BUG-MSO-2026-0637: the voyage's work shipped under pr_number/pr_url,
    # which SUPERSEDED the original PR named here (closed unmerged after a
    # merge-resolution order delivered the result on another branch). Carried
    # so an operator looking for the original PR can see where it went —
    # the number is never silently swapped. None when nothing was superseded.
    supersededPrNumber: Optional[int] = None
    supersededPrUrl: Optional[str] = None
    supersessionNote: Optional[str] = None
    # BUG-MSO-2026-0775: planning voyage <-> build voyage links
    # (maestro.core.plan_links, read in BOTH directions). A build voyage names
    # the plan order it was cut from and its planning voyage; a planning
    # voyage lists the voyages its plan was cut into, each with its own phase
    # and PR so "approved, nothing built" can never be the only reading.
    planOrder: Optional[str] = None
    planVoyage: Optional["VoyageLink"] = None
    buildVoyages: list["VoyageLink"] = Field(default_factory=list)


class VoyageLink(BaseModel):
    """Another voyage, summarised for a plan link (BUG-MSO-2026-0775).

    ``found`` is False when the manifest names a voyage the Hub cannot read
    (deleted, or awaiting approval) — the id is still shown, never dropped.
    """
    id: str
    title: str = ""
    status: str = ""
    phase: str = ""
    pr_url: Optional[str] = None
    pr_number: Optional[int] = None
    found: bool = True


Voyage.model_rebuild()


class CrewState(BaseModel):
    """Matches the frontend `CrewState` interface."""
    slot: int
    name: str = ""
    status: str = "IDLE"
    role: Optional[str] = None
    current_order_id: Optional[str] = None
    current_order_title: Optional[str] = None
    iteration: Optional[int] = None
    max_iterations: Optional[int] = None
    # FTR-MSO-2026-0632: same state.json keys fleet_monitor.py already reads
    # (liveTurn/maxTurns, FTR-MSO-2026-0227) — turns are the activity signal
    # that actually moves within an iteration; None (not 0) when the crew's
    # state predates these fields or carries no live state at all.
    live_turn: Optional[int] = None
    max_turns: Optional[int] = None
    # BUG-MSO-2026-0698: the crew's RESOLVED wall-clock ceiling (minutes).
    # Turn and iteration counters say how far through its budget a crew is on
    # two axes but not on the third, which is the one that actually kills it.
    # None when the crew's state predates the field (or carries no live state).
    timeout_minutes: Optional[int] = None
    # FTR-MSO-2026-0796: the model this crew is dispatched against (bare id,
    # resolved by crew.py via resolve_model_for — never re-derived here) and
    # its short label (core_constants.get_model_label, the same helper
    # `mso status` uses). None when the crew's state predates the field.
    model: Optional[str] = None
    model_label: Optional[str] = None
    # FTR-MSO-2026-0796: running token total for THIS crew run (all
    # iterations), from the live stream. Not the per-order usage rollup.
    # None (not 0) when the crew's state predates the field.
    total_tokens: Optional[int] = None
    activity_age_seconds: Optional[int] = None
    pid: Optional[int] = None
    session_id: Optional[str] = None
    maestro_session_id: Optional[str] = None
    # BUG-MSO-2026-0639: set only when status == "STALE" — the state.json
    # claimed a live crew but its recorded pid is dead (or was reused). The
    # order the dead record named moves HERE, off current_order_id, because a
    # dead slot must never attribute an order to itself: that order may since
    # have been run to COMPLETE by another crew (BUG-MSO-2026-0657 F4).
    # Turn/iteration counters are cleared for the same reason — they would
    # report motion where there is none.
    stale_order_id: Optional[str] = None
    stale_reason: Optional[str] = None


class CrewActivityEntry(BaseModel):
    """One structured entry from a crew's ``activity.jsonl`` (FTR-MSO-2026-0577).

    Mirrors what ``maestro/hooks/posttool.py`` appends on every tool call.
    ``target`` is redacted via ``maestro.hooks.secret_patterns.redact_text``
    before this model is constructed — it can carry a Bash command or a file
    path a crew read/echoed.
    """
    timestamp: str = ""
    tool: str = ""
    action: str = ""
    target: str = ""


class CrewDetail(BaseModel):
    """``GET /api/v1/workspaces/{id}/crews/{slot}/detail`` — FTR-MSO-2026-0577.

    The read-only "what is this crew busy with" view the Hub's crew-drawer
    needs. Deliberately never carries ``output_01.txt``/``output_final.txt``
    (raw Claude transcript — 639 KB+ and unbounded on a real fleet);
    ``activity`` is the structured record of the same work and bounded by
    the aggregator. ``activity_line``/``progress_markdown``/``target`` on
    each ``activity`` entry are all redacted before this model is built.

    An IDLE slot (a crew directory that exists but has no live state) still
    returns a well-formed record with empty/default fields — never an error.
    A slot with no directory at all resolves to ``None`` in the aggregator,
    which the endpoint turns into a 404.
    """
    slot: int
    name: str = ""
    status: str = "IDLE"
    role: Optional[str] = None
    current_order_id: Optional[str] = None
    current_order_title: Optional[str] = None
    iteration: Optional[int] = None
    max_iterations: Optional[int] = None
    # FTR-MSO-2026-0632: see CrewState.live_turn/max_turns above.
    live_turn: Optional[int] = None
    max_turns: Optional[int] = None
    # FTR-MSO-2026-0796: see CrewState.model/model_label/total_tokens above.
    model: Optional[str] = None
    model_label: Optional[str] = None
    total_tokens: Optional[int] = None
    activity_line: str = ""
    activity: list[CrewActivityEntry] = Field(default_factory=list)
    progress_markdown: str = ""
    files_modified: list[str] = Field(default_factory=list)
    # BUG-MSO-2026-0713: where the slot's PREVIOUS run was retained. Every
    # field above describes the run currently in the slot; when a crew has
    # died and been replaced, that is precisely the run an operator does not
    # need. `previous_run_path` names the directory the prior run's
    # output_*.txt / activity.jsonl were moved to at re-dispatch, so the
    # drawer can point at evidence that used to be truncated in place. It is
    # a PATH, not content — the drawer never inlines a raw transcript, for the
    # same reason this model never carries output_01.txt.
    previous_run_path: Optional[str] = None
    previous_run_order_id: Optional[str] = None
    previous_run_role: Optional[str] = None
    previous_run_retained_at: Optional[str] = None
    # BUG-MSO-2026-0639: see CrewState.stale_order_id/stale_reason above.
    stale_order_id: Optional[str] = None
    stale_reason: Optional[str] = None


class Repo(BaseModel):
    """Matches the frontend `Repo` interface."""
    id: str
    name: str
    path: str
    default_branch: str = "main"


class IdleWatchdogConfig(BaseModel):
    enabled: bool = False
    idleMinutes: int = 30
    action: str = "none"


class OnVoyageCompleteConfig(BaseModel):
    archiveVoyageOnMerge: bool = True
    archiveOrders: bool = True
    autoRelease: bool = False


class CompletionConfig(BaseModel):
    idleWatchdog: Optional[IdleWatchdogConfig] = None
    onVoyageComplete: Optional[OnVoyageCompleteConfig] = None
    roleTimeouts: Optional[dict[str, int]] = None


class WorkspaceConfig(BaseModel):
    """Matches the frontend `WorkspaceConfig` interface (camelCase preserved)."""
    persona: Optional[str] = None
    project: Optional[str] = None
    maxCrews: Optional[int] = None
    completion: Optional[CompletionConfig] = None
    # FTR-MSO-2026-0328: per-workspace dispatch defaults (null = not configured)
    # BUG-MSO-2026-0800: maxIterations, autoDispatch and tokenDailyCap were removed —
    # no engine code ever read them, so the drawer showed settings with no effect.
    maxTurns: Optional[int] = None
    timeoutMinutes: Optional[int] = None
    requirePlanReview: Optional[bool] = None


class UsagePoint(BaseModel):
    """One data point in a workspace token-usage history series."""
    date: str          # ISO date string (YYYY-MM-DD)
    tokens: int = 0
    cost_usd: float = 0.0


class WorkspaceUsage(BaseModel):
    """Aggregated token-usage metrics for a workspace (FTR-MSO-2026-0330)."""
    total_tokens: int = 0
    estimated_cost_usd: float = 0.0
    order_count: int = 0                        # number of orders with usage data
    history: list[UsagePoint] = Field(default_factory=list)  # per-day series (newest last)


class WorkspaceDetail(BaseModel):
    """Matches the frontend `WorkspaceDetail` (extends Workspace) interface."""
    id: str
    name: str
    path: str
    dispatcher_running: bool = False
    # FTR-MSO-2026-0498: see WorkspaceSummary.dispatcher_state.
    dispatcher_state: str = ""
    dispatcher_pause_detail: str = ""
    active_crew_count: int = 0
    active_voyage_count: int = 0
    pending_review_count: int = 0
    pending_order_count: int = 0
    held_order_count: int = 0  # BUG-MSO-2026-0451: dep-held + operator-skipped
    # FTR-MSO-2026-0487: see WorkspaceSummary.attention — same rollup, full detail view.
    attention: AttentionBreakdown = Field(default_factory=AttentionBreakdown)
    persona: Optional[str] = None
    project: Optional[str] = None
    config: WorkspaceConfig = Field(default_factory=WorkspaceConfig)
    voyages: list[Voyage] = Field(default_factory=list)
    crews: list[CrewState] = Field(default_factory=list)
    queue_summary: dict[str, int] = Field(default_factory=dict)
    orders: list[Order] = Field(default_factory=list)
    repos: list[Repo] = Field(default_factory=list)
    usage: Optional[WorkspaceUsage] = None
    # FTR-MSO-2026-0376: 'embedded' | 'solo' | 'shared' (maestro.workspace
    # ARTEFACT_MODES) — lets the frontend show a SHARED indicator without
    # inferring it from claimedBy presence alone. camelCase by order spec.
    artefactMode: str = "embedded"
    # FTR-MSO-2026-0492 §4.4: the exact `mso dispatch` command for a backlog
    # voyage, computed server-side from the PRODUCT repo path (never `path`
    # above, which is the artefact parent in solo/shared mode) — a
    # frontend-assembled `cd {path}` would print a command that fails on the
    # operator's machine. Empty when unknown (e.g. offline_detail()).
    dispatchCommand: str = ""


class LifecycleEvent(BaseModel):
    """Matches the frontend `LifecycleEvent` interface (WebSocket stream)."""
    workspace_id: str
    workspace_name: str
    line: str = ""              # raw log line (kept for backward-compat)
    message: str = ""           # parsed message — frontend contract field
    timestamp: str = ""
    event_type: str = ""
    order_id: Optional[str] = None
    crew_slot: Optional[int] = None
    role: Optional[str] = None
    subtype: Optional[str] = None


# ---- Phase 3 ----------------------------------------------------------------

class ReviewItem(BaseModel):
    """Matches the frontend `ReviewItem` interface (BARE-ARRAY endpoint)."""
    order_id: str
    workspace_id: str
    workspace_name: str = ""
    order_title: str = ""
    role: str = ""
    voyage_id: Optional[str] = None
    plan_markdown: Optional[str] = None
    created_at: str = ""
    paused_at: Optional[str] = None
    priority: Optional[str] = None


class PlanResponse(BaseModel):
    workspace_id: str
    order_id: str
    plan_markdown: str = ""
    has_plan_file: bool = False
    order: dict


class ReviseRequest(BaseModel):
    feedback: str


class RejectRequest(BaseModel):
    reason: str


class AckRequest(BaseModel):
    """Body for ``POST .../lead/findings/{fingerprint}/ack`` (PLAN-PLN-MSO-2026-0584
    Dimension D). ``by`` is optional — an unauthenticated Hub deployment has
    no operator identity to read, so it defaults to ``"hub"`` server-side
    rather than requiring the frontend to invent one. ``days`` is optional
    and, when omitted, resolves to ``maestro.patrol.state.ACK_TTL_DAYS_DEFAULT``
    (7) — there is deliberately no way to request a non-expiring ack."""
    note: str = ""
    by: Optional[str] = None
    days: Optional[int] = None


class ActionResult(BaseModel):
    ok: bool
    order_id: str
    new_status: str = ""
    message: str = ""


# ---- Artefacts + Retry (FTR-MSO-2026-0492) ----------------------------------

class ArtefactRef(BaseModel):
    """One discovered artefact's manifest entry — no content.

    ``key`` is an opaque, server-issued token (``discover_artefacts``'s
    ``{kind}:{name}`` form); a client cannot construct one that resolves to a
    file discovery did not itself find (maestro/hub/artefacts.py §4.2).
    """
    key: str
    kind: str
    name: str
    size: int = 0
    modified: str = ""


class OrderArtefacts(BaseModel):
    """Response for ``GET /orders/{id}/artefacts`` — manifest only, no content."""
    order_id: str
    workspace_id: str
    artefacts: list[ArtefactRef] = Field(default_factory=list)


class ArtefactContent(BaseModel):
    """Response for ``GET /orders/{id}/artefacts/{key}`` — one artefact's body.

    Bounded at ``artefacts.MAX_ARTEFACT_BYTES`` (512 KB, §5.5); ``truncated``
    is set and ``size`` still carries the true on-disk size when the read was
    capped.
    """
    key: str
    kind: str
    name: str
    content: str = ""
    truncated: bool = False
    size: int = 0


class SalvageCandidateModel(BaseModel):
    """One salvage branch ``mso order retry`` could arm (BUG-MSO-2026-0696).

    Mirrors ``maestro.core.salvage_record.SalvageCandidate.to_dict()`` field for
    field. The Hub and the CLI read the SAME candidate list from the SAME core
    function — AC-4's no-drift requirement is structural here, not a convention
    to remember: neither surface computes candidates of its own.
    """
    branch: str
    sha: Optional[str] = None
    reason: str = ""
    crew: Optional[int] = None
    role: str = ""
    timestamp: str = ""
    diff_stat: Optional[dict] = Field(default=None, alias="diffStat")
    source: str = "salvageBranches"
    index: Optional[int] = None
    summary: str = ""

    model_config = {"populate_by_name": True}


class SalvageCandidates(BaseModel):
    """Response for ``GET /orders/{id}/salvage-candidates`` (BUG-MSO-2026-0696).

    Read-only preview of what a retry WOULD arm — so an operator (or the Hub
    UI) can see the choice, and the ambiguity verdict, before spending one.
    """
    order_id: str
    candidates: List[SalvageCandidateModel] = Field(default_factory=list)
    would_arm: Optional[str] = None
    ambiguous: str = ""


class RetryResult(BaseModel):
    """Response for ``POST /orders/{id}/retry``."""
    ok: bool
    order_id: str
    new_status: str = ""
    target_role: str = ""
    salvage_branch: Optional[str] = None
    # BUG-MSO-2026-0696 (AC-4): the same candidate list the CLI prints, so the
    # Hub can never show a narrower view of what was available than the CLI.
    salvage_candidates: List[SalvageCandidateModel] = Field(default_factory=list)
    salvage_explicit: bool = False
    message: str = ""


# ---- Order edit + skip (FTR-MSO-2026-0622, PLAN-PLN-MSO-2026-0556 Order 6) --

class OrderEditRequest(BaseModel):
    """Body for ``PATCH /orders/{id}`` — every field optional, none defaulted.

    Field names are the ORDER JSON's own camelCase keys, not the snake_case
    read models above, because they are handed STRAIGHT to
    ``order_create.edit_order``'s ``updates`` mapping, whose keys are checked
    against :data:`maestro.core.order_create.EDITABLE_FIELDS` — the artefact's
    vocabulary. Translating them here would create a second name table to keep
    in step with that allowlist, which is the drift this plan exists to close.

    ``None`` means UNSET, never "clear this field": a PATCH carries only what
    the operator changed, and a body that omitted ``dependsOn`` must not wipe
    an order's dependencies. Callers read :meth:`updates`, which drops unset
    keys via ``exclude_unset`` rather than by testing for ``None`` — so an
    explicit ``"description": ""`` (a real clear) still reaches the core,
    while an absent key never does.
    """
    # `extra="forbid"` so a field name this endpoint does not offer is a 422
    # naming it, never a silently ignored key that returns "no fields to edit"
    # and leaves the operator guessing which half of their body landed.
    model_config = ConfigDict(extra="forbid")

    title: Optional[str] = None
    description: Optional[str] = None
    priority: Optional[str] = None
    targetRole: Optional[str] = None
    roleSequence: Optional[list] = None
    acceptanceCriteria: Optional[list] = None
    dependsOn: Optional[list] = None
    targetRepo: Optional[str] = None
    timeoutMinutes: Optional[int] = None
    model: Optional[str] = None
    status: Optional[str] = None

    # DELIBERATELY ABSENT, though ``order_create.EDITABLE_FIELDS`` allows them
    # to the CLI: ``voyageId`` and ``voyageBranch``. They are the two fields
    # that STRAND an order when they disagree — ``voyageBranch`` is
    # load-bearing for the whole branch discipline (BUG-ADM-2026-0004; the
    # pretool guard denies any mutation targeting another branch), and setting
    # a ``voyageId`` without the manifest entry that goes with it is the
    # detach-without-skip failure PLAN §5.3 defers item 12 over. Voyage
    # attachment is its own action, ``POST /orders/{id}/attach``
    # (BUG-MSO-2026-0794), backed by ``order_attach.attach_order_to_voyage``,
    # which writes BOTH sides or neither. A PATCH field could only be half.

    def updates(self) -> dict:
        """The fields the caller actually sent, as ``edit_order`` updates.

        No filtering of values, only of presence — validation belongs to the
        core (one implementation), and a request model that quietly dropped a
        value it disliked would refuse an edit without saying so.
        """
        return self.model_dump(exclude_unset=True)


class OrderEditResult(BaseModel):
    """Response for ``PATCH /orders/{id}``.

    ``changed_fields`` is read back from the order the core WROTE, not from
    the request — PLAN §6.2's backend half: the response reports what landed
    on disk, never what was asked for. An edit whose values all matched the
    existing order returns ``ok=True`` with an empty list, which is the honest
    answer (nothing changed) rather than a manufactured success.

    ``reanchored_role`` names a ``targetRole`` the CORE changed on its own
    initiative — because the edit left the previous one outside the resolved
    ``roleSequence`` — and is empty otherwise. ``changed_fields`` cannot say
    this on its own: it lists ``targetRole`` identically whether the caller
    asked for it or the re-anchor supplied it, and an edit that silently moves
    the role an order starts at is exactly what BUG-MSO-2026-0742 was about.
    """
    ok: bool
    order_id: str
    status: str = ""
    changed_fields: list[str] = Field(default_factory=list)
    reanchored_role: str = ""
    message: str = ""


class OrderSkipRequest(BaseModel):
    """Body for ``POST /orders/{id}/skip`` — an optional operator reason.

    Recorded verbatim in ``config/skipped-orders.json`` alongside the id, the
    same field ``mso order skip --reason`` writes.
    """
    reason: str = ""


class OrderSkipResult(BaseModel):
    """Response for ``POST /orders/{id}/skip`` and ``/unskip``.

    ``skipped`` is the order's state AFTER the call (True after skip, False
    after unskip) — read back from the persisted list, not assumed from the
    verb. ``changed`` says whether this call was the one that moved it: an
    unskip of an order that was never skipped is ``ok=True, changed=False``,
    because refusing an already-correct state as an error would be a lie in
    the other direction.
    """
    ok: bool
    order_id: str
    skipped: bool
    changed: bool = True
    message: str = ""


class OrderAttachRequest(BaseModel):
    """Body for ``POST /orders/{id}/attach`` (BUG-MSO-2026-0794).

    One field. There is no ``voyageBranch``: the branch is read from the
    voyage manifest, never from the request, so a caller cannot attach an
    order to a voyage under a branch that voyage does not own.
    """
    model_config = ConfigDict(extra="forbid")

    voyageId: str


class OrderAttachResult(BaseModel):
    """Response for ``POST /orders/{id}/attach``.

    ``voyage_branch`` and ``voyage_order_ids`` are read back from the order
    file and the manifest AFTER the write. ``attached`` is whether the manifest
    read back lists the order — the endpoint never returns 200 with it False.
    ``changed`` is False for a re-attach that found both sides already agreeing.
    """
    ok: bool
    order_id: str
    voyage_id: str
    voyage_branch: str = ""
    attached: bool = False
    voyage_order_ids: List[str] = Field(default_factory=list)
    changed: bool = True
    message: str = ""


# ---- SDLC provider configuration (FTR-MSO-2026-0767, PLAN-PLN-MSO-2026-0747
# Order 10a, D8) -------------------------------------------------------------
#
# `maestro.providers.config` (Order 8) is the ONE writer of workspace.json's
# `providers` block; these models only shape the wire request/response for
# the Hub's GET/PUT/POST endpoints, which call it — never write the file
# themselves (AC4: "no second writer").

class ProviderWriteRequest(BaseModel):
    """Body for ``PUT /workspaces/{id}/providers`` — the ONLY schema this
    endpoint accepts. ``extra="forbid"`` means a body naming any key outside
    ``kind``/``id``/``config`` is a 422 raised by FastAPI's own validation,
    BEFORE the handler — and therefore before ``providers.config`` — ever
    runs, so the file is provably untouched (Order 10a AC1).

    ``id=None`` unsets the kind's configured provider (reverting to the
    shipped default), the same shape ``mso providers unset`` /
    ``providers.config.unset_provider`` uses. Credential-shaped fields inside
    ``config`` are validated by ``providers.config.set_provider`` itself
    (D9: ``env:``/``secret://`` references only) — this model does not
    duplicate that check, it only fixes what keys may be sent.
    """
    model_config = ConfigDict(extra="forbid")

    kind: str
    id: Optional[str] = None
    config: Optional[dict] = None


class ProviderConfiguredEntry(BaseModel):
    """One kind's configured entry, verbatim from ``workspace.json`` —
    references are never resolved here (``providers.config.list_providers``'s
    own contract)."""
    id: str
    config: dict = Field(default_factory=dict)


class ProviderKindStatus(BaseModel):
    """One kind's installed ids, configured entry (if any) and bundle lock —
    ``providers.config.list_providers()``'s per-kind shape, unchanged."""
    installed: list[str] = Field(default_factory=list)
    configured: Optional[ProviderConfiguredEntry] = None
    lockedBy: Optional[str] = None


class ProvidersListResponse(BaseModel):
    """Response for ``GET /workspaces/{id}/providers`` — every provider kind
    keyed by name, straight from ``providers.config.list_providers()``."""
    providers: dict[str, ProviderKindStatus] = Field(default_factory=dict)


class ProviderResolvedInfo(BaseModel):
    """The resolved outcome for one kind — same shape ``mso providers test
    --json`` and ``mso doctor --explain`` already print (AC6-equivalent
    consistency), never a second reporting path."""
    providerId: str = ""
    tier: str = ""
    available: bool = False
    reason: str = ""


class ProviderWriteResult(BaseModel):
    """Response for ``PUT /workspaces/{id}/providers``.

    ``removed`` is only meaningful when the request set ``id=None`` (an
    unset); it is read back from ``providers.config.unset_provider``'s own
    return, not inferred from the request, mirroring ``OrderSkipResult``'s
    ``changed`` field one section up.
    """
    ok: bool
    kind: str
    id: Optional[str] = None
    config: dict = Field(default_factory=dict)
    removed: bool = False
    message: str = ""


class ProviderTestRequest(BaseModel):
    """Body for ``POST /workspaces/{id}/providers/test``."""
    model_config = ConfigDict(extra="forbid")

    kind: str


class ProviderTestResult(BaseModel):
    """Response for ``POST /workspaces/{id}/providers/test`` — wraps
    ``providers.config.test_provider()``'s ``ResolvedProvider`` (its
    ``.provider`` instance is never serialised — only the reporting fields
    ``mso providers test`` itself prints)."""
    ok: bool
    kind: str
    resolved: ProviderResolvedInfo


# ---- Settings (FTR-MSO-2026-0801, PLAN-PLN-MSO-2026-0792 Order 5a) ----------
#
# A thin projection of `maestro.core.settings_core` — the ONE writer. Every
# field below is read off `settings_core.Effective` / `SettingSpec`; nothing is
# computed here, so the Hub cannot report a value, source or lock the CLI's
# `mso settings get` would not.

class SettingEntry(BaseModel):
    """One registry key: its effective value, where that came from, and what
    a control needs to render it honestly (§5 contract 3)."""
    key: str
    value: Any = None
    source: str                       # env | bundle | workspace | device | overlay | default
    sourceDetail: str = ""
    default: Any = None
    scope: str                        # device | workspace | both
    type: str                         # bool | int | str | enum | model | object
    description: str = ""
    env: Optional[str] = None
    choices: list = Field(default_factory=list)
    minimum: Optional[int] = None
    nullable: bool = False
    restartRequired: bool = False
    locked: bool = False
    lockedReason: Optional[str] = None
    # Storage-specific extras `settings_core.Effective.extra` may carry.
    installed: Optional[list[str]] = None   # providers.<kind>
    generation: Optional[str] = None        # models.<ROLE>.model
    error: Optional[str] = None             # an unsupported stored model id


class ModelVocabularyEntry(BaseModel):
    """`settings_core.model_vocabulary()` — derived from core_constants, never
    hand-typed in the Hub. Only ``current`` ids may be chosen as a new pin."""
    id: str
    label: str
    generation: str


class SettingsListResponse(BaseModel):
    """Response for ``GET /workspaces/{id}/settings`` and ``GET /settings``."""
    scope: str                        # workspace | device
    settings: list[SettingEntry] = Field(default_factory=list)
    models: list[ModelVocabularyEntry] = Field(default_factory=list)


class SettingWriteRequest(BaseModel):
    """Body for ``PUT /workspaces/{id}/settings`` and ``PUT /settings``:
    ``{key, value}`` sets, ``{key, unset: true}`` removes. ``extra="forbid"``
    makes any other key a 422 before the handler runs. Whether ``value`` was
    SENT is read from ``model_fields_set``, so ``{"value": null}`` (a legal
    write for a nullable key) is distinct from an omitted value."""
    model_config = ConfigDict(extra="forbid")

    key: str
    value: Any = None
    unset: bool = False


class SettingWriteResult(BaseModel):
    """Response for a settings PUT — the setting as read back off disk.

    ``setting.value`` may still come from a higher-precedence source (an env
    var, a bundle) than the file just written; ``setting.source`` says so."""
    ok: bool
    setting: SettingEntry
    changed: bool = False
    writtenScope: str
    message: str


# ---- Status-monitor auto-spawn preference (FTR-MSO-2026-0635) ---------------
#
# `maestro.core.spawn_monitor` is the ONE resolver and writer; these models
# only shape the wire. Machine-level by design (see that module's docstring for
# the scope decision), so the route is not workspace-scoped and the response
# says so in `scope` rather than leaving the UI to assume.

class SpawnMonitorWriteRequest(BaseModel):
    """Body for ``PUT /api/v1/machine/spawn-monitor``. ``spawnMonitor=None``
    clears the saved preference (reverting to the shipped default, True)."""
    model_config = ConfigDict(extra="forbid")

    spawnMonitor: Optional[bool] = None


class SpawnMonitorSetting(BaseModel):
    """The effective preference AND every input to it.

    ``effective`` is resolved in the Hub PROCESS's environment — the
    environment a Hub-started dispatch inherits. ``source`` names the layer
    that decided it (``env`` / ``settings`` / ``default``); ``envValue`` is set
    whenever ``MAESTRO_SPAWN_MONITOR`` is, so a UI never shows the saved value
    as if it were in force while the environment overrides it.
    """
    scope: str = "machine"
    effective: bool = True
    source: str = "default"
    envVar: str = "MAESTRO_SPAWN_MONITOR"
    envValue: Optional[str] = None
    savedValue: Optional[bool] = None
    settingsPath: str = ""
    settingsError: Optional[str] = None
    observeOnly: bool = False
    message: str = ""


# ---- Voyage creation (FTR-MSO-2026-0619, PLAN-PLN-MSO-2026-0556 Order 3) ----

class CreateVoyageRequest(BaseModel):
    """Body for ``POST /workspaces/{id}/voyages``.

    NOTE WHAT IS *NOT* HERE, because the absences are the order:

    * **No ``id``.** BUG-MSO-2026-0555's toast named an id the browser had
      computed by regexing ``max()+1`` over the voyages it happened to hold —
      a snapshot that cannot see ``voyages/complete/``, cannot lock, and is
      already stale by one poll interval (PLAN §2.1, refuted outright). The id
      is minted server-side under ``order_ids.lock_for_allocation`` and comes
      back in the response. A field here would be a way to ask for one.
    * **No ``project``.** The acronym is resolved from the workspace's own
      ``config/workspace.json`` (falling back to the registry key, exactly as
      ``aggregator._read_config`` already does for every read model). A
      client-supplied acronym is the same class of defect as a
      client-supplied id: it lets the browser decide which sequence space a
      manifest is minted into.
    * **No ``status``.** Captain decision D3. ``voyage.status`` gates no
      dispatch anywhere in the engine (PLAN §1.1 traced every consumer), so a
      Planned/Active choice changed nothing — a second inert control on the
      button that prompted this plan. Every voyage is created ``PLANNED``,
      byte-identical to what ``mso voyage create`` writes.
    * **No ``branch``.** ``voyage_core._COMPUTED_FIELDS`` contains it: the
      manifest's branch is always ``voyage/{id}``, and since the id is not
      knowable before the call the branch is not either. The dispatcher
      creates that branch on the remote at first crew dispatch
      (``ensure_voyage_branch_exists``) — no git runs here (§3.4 / D4).

    AND WHAT *IS* HERE THAT WAS NOT (BUG-MSO-2026-0793):

    * **``createPlanningOrder``, default true.** VOY-MSO-2026-0791 was created
      with a full planning brief as its description and nothing else — an
      empty ``orders`` manifest, so the dispatcher had nothing to find and the
      voyage sat inert until the Captain asked why. With this flag set (the
      default) and a non-empty description, the endpoint files a ``PENDING``
      PLN order carrying the description and attaches it to the new voyage in
      the same request. ``false`` is the explicit opt-out; the response message
      then says plainly that nothing will run until an order is filed. It is an
      ORDER side effect only — no git runs either way (D4 still holds).
    """
    model_config = ConfigDict(extra="forbid")

    title: str
    description: str = ""
    createPlanningOrder: bool = True
    #: BUG-MSO-2026-0775: the plan order this BUILD voyage is cut from. The
    #: planning voyage is resolved server-side from that order's own
    #: ``voyageId`` and linked in both directions; an unknown plan order is a
    #: 400 that writes nothing.
    planOrder: str = ""


class VoyageCreated(BaseModel):
    """Response for ``POST /workspaces/{id}/voyages``.

    Every field is READ BACK FROM THE MANIFEST ON DISK, never echoed from the
    request. That distinction is the whole order: it is the difference between
    "we wrote this" and "we intended to write this", and the latter is
    precisely BUG-MSO-2026-0555. ``voyage_core.create_voyage`` re-reads the
    file it wrote before returning (its own §2.3 rule), and this model carries
    that record outward unchanged.

    ``path`` is included because an operator who is told a voyage exists
    should be able to go and look at it without guessing which of
    ``voyages/active`` or an artefact-repo mount it landed in.

    ``planningOrderId`` / ``planningOrderPath`` (BUG-MSO-2026-0793) are read
    back from the planning order file the same request wrote, and are empty
    when no planning order was filed (opt-out, or no description).
    """
    ok: bool
    workspace_id: str
    voyage_id: str
    title: str = ""
    status: str = ""
    branch: str = ""
    path: str = ""
    planningOrderId: str = ""
    planningOrderPath: str = ""
    message: str = ""
    #: BUG-MSO-2026-0775, read back from the manifest.
    planOrder: str = ""
    planVoyage: str = ""
    #: Non-empty when the planning voyage's ``buildVoyages`` could not be
    #: written; this voyage still names its plan.
    planLinkError: str = ""


# ---- Order creation (FTR-MSO-2026-0621, PLAN-PLN-MSO-2026-0556 Order 5) ----

class CreateOrderRequest(BaseModel):
    """Body for ``POST /workspaces/{id}/orders``.

    As with :class:`CreateVoyageRequest`, the ABSENCES carry the design:

    * **No ``id``.** ``CreateItemDrawer`` used to render one from
      ``nextId()`` — ``max()+1`` regexed over the orders the browser happened
      to hold, blind to ``orders/complete/``, unlockable, with the year
      hard-coded. Ids are minted server-side under
      ``order_ids.lock_for_allocation`` and returned read back off the file.
    * **No ``project``.** Resolved from the workspace's own config, exactly as
      the voyage endpoint does. A client-chosen acronym picks which sequence
      space a file is minted into.
    * **No ``voyageBranch``.** ``extra="forbid"`` makes sending it a 422. The
      branch is DERIVED from the target voyage's manifest — a ``voyageBranch``
      that disagrees with its voyage is precisely how an order strands
      (BUG-ADM-2026-0004), and letting a browser supply one is the shape of
      that bug with a network hop in front of it.

    ``voyageId`` IS accepted, and is the only field here that causes a second
    write: the endpoint attaches the created order to that voyage's manifest
    via ``voyage_core.attach_order``. An order naming a voyage whose manifest
    does not list it is invisible to that voyage — ``voyages_outstanding_work``
    and the BUG-MSO-2026-0303 completion guard both read the MANIFEST, never
    the order's own claim of membership.
    """
    model_config = ConfigDict(extra="forbid")

    type: str
    title: str
    description: str = ""
    priority: Optional[str] = None
    targetRole: Optional[str] = None
    roleSequence: Optional[list[str]] = None
    acceptanceCriteria: Optional[list[Any]] = None
    dependsOn: Optional[list[str]] = None
    targetRepo: str = ""
    voyageId: str = ""
    #: One of ``order_create.CREATABLE_STATUSES``. Omitted ⇒ PENDING.
    status: Optional[str] = None
    #: BUG-MSO-2026-0775: the plan order this order is cut from. Recorded as
    #: ``planOrder``; when ``voyageId`` is not the plan's own voyage, the two
    #: voyages are linked in both directions. Unknown plan order ⇒ 400.
    planOrder: str = ""


class OrderCreated(BaseModel):
    """Response for ``POST /workspaces/{id}/orders``.

    Every field is READ BACK from the order file the server wrote, and
    ``attached``/``voyageOrderIds`` are read back from the MANIFEST after the
    attach — never echoed from the request, and never inferred from "the call
    did not raise". The distinction is the whole plan: BUG-MSO-2026-0555 was a
    response describing an intention.

    ``attached`` is reported separately from ``ok`` because they answer
    different questions. ``ok`` means the order exists; ``attached`` means its
    voyage can see it.
    """
    ok: bool
    workspace_id: str
    order_id: str
    type: str = ""
    title: str = ""
    status: str = ""
    priority: str = ""
    targetRole: str = ""
    roleSequence: list[str] = Field(default_factory=list)
    voyageId: str = ""
    voyageBranch: str = ""
    #: True when this order is now in its voyage's ``orders[]``. False when no
    #: voyage was named — never True on the strength of the call not raising.
    attached: bool = False
    voyageOrderIds: list[str] = Field(default_factory=list)
    #: Where the order JSON actually landed, so "it exists" is checkable.
    path: str = ""
    message: str = ""
    #: BUG-MSO-2026-0775, read back from the order file.
    planOrder: str = ""
    #: Non-empty when the voyage link to the plan's voyage could not be written.
    planLinkError: str = ""


class OrderTypeDefault(BaseModel):
    """One order type, with what creating it would default to.

    Served by ``GET /workspaces/{id}/order-defaults`` and resolved through the
    same ``order_create`` functions ``create_order`` itself calls, so a picker
    built on this cannot offer something the create path refuses.
    """
    type: str
    roleSequence: list[str] = Field(default_factory=list)
    priority: str = ""
    queue: str = ""
    #: ``"template"`` when a division pack's order template supplied the
    #: sequence, else ``"builtin"``.
    source: str = "builtin"


class OrderDefaults(BaseModel):
    """Response for ``GET /workspaces/{id}/order-defaults``.

    A READ endpoint, and deliberately not tier-gated: a licence gates ACTING,
    never READING — the position ``GET .../lead`` already takes. Refusing to
    describe the vocabulary would leave a frontend with no honest choice but
    to hard-code its own copy, which is the drift PLAN §5.4 exists to prevent.
    """
    workspace_id: str
    project: str = ""
    types: list[OrderTypeDefault] = Field(default_factory=list)
    #: Every dispatchable canonical role — the constrained role picker's
    #: vocabulary (``LEAD`` is excluded: it is never dispatched).
    roles: list[str] = Field(default_factory=list)
    priorities: list[str] = Field(default_factory=list)
    #: ``order_create.CREATABLE_STATUSES``, sorted.
    statuses: list[str] = Field(default_factory=list)
    defaultStatus: str = ""


class ControlResult(BaseModel):
    """Result of a workspace dispatch/stop control action (Feature B)."""
    ok: bool
    workspace_id: str
    action: str = ""   # 'dispatch' | 'stop' | 'pause' | 'resume' | 'lead.*'
    message: str = ""


class RunResult(BaseModel):
    """Result of ``POST .../lead/findings/{fingerprint}/run`` (FTR-MSO-2026-0631).

    Mirrors ``ControlResult``'s ``ok``/``action``/``message`` shape rather than
    inventing an unrelated one. ``outcome`` is the honest three-way verdict the
    order requires — never an optimistic success:

      * ``"accepted"`` — the mapped verb ran and its underlying call succeeded.
      * ``"refused"``  — never attempted: blocked by the D6 must_not ceiling,
                          a licence-tier gate, a deployment capability gate
                          (e.g. sweep needs `gh`, which this Hub lacks), or
                          (BUG-MSO-2026-0662 F1) a PRE-flight re-check of the
                          finding's own condition that could not confirm it
                          — or confirmed it no longer holds.
      * ``"failed"``   — attempted, but the underlying call raised or reported
                          a business refusal (e.g. `RetryRefused`).

    ``conditionCleared``/``stillOpen`` normally report the POST-action
    RE-EVALUATION verdict, not the action's own success — reusing
    ``maestro.patrol.run_single_check`` to re-run ONLY the check that
    produced the finding (never a full LEAD tick — BUG-MSO-2026-0634 F1/F2)
    rather than optimistically assuming an accepted action fixed anything.
    Re-evaluation only runs after an "accepted" outcome; a "failed" run
    leaves `stillOpen=True` without spending one (nothing changed). The one
    exception is a "refused" outcome caused by BUG-MSO-2026-0662 F1's
    PRE-flight check itself finding the condition already cleared — that
    refusal DOES carry `conditionCleared=True`/`stillOpen=False`/
    `verified=True`, since a real check genuinely ran and confirmed it
    before anything else happened; every OTHER "refused" reason (D6/licence/
    capability gates, or the pre-check being unable to confirm anything at
    all) leaves `stillOpen=True` exactly as before.

    ``verified`` (BUG-MSO-2026-0634 F2) is the fail-closed half: it is False
    when re-evaluation could not actually confirm anything (an unknown/
    disabled/raising check) — in that case `conditionCleared` is always False
    and `stillOpen` is always True regardless of what the check last said,
    and the frontend renders a distinct "ran, could not confirm" tone rather
    than the optimistic "condition cleared" a swallowed failure used to imply.
    """
    ok: bool
    action: str = ""            # verb id, e.g. "order.retry"
    outcome: str = "failed"     # "accepted" | "refused" | "failed"
    message: str = ""
    conditionCleared: bool = False
    stillOpen: bool = True
    verified: bool = False


class SweepEntry(BaseModel):
    """One housekeeping decision — what was done, or refused, and why.

    FTR-MSO-2026-0426. Mirrors an entry produced by
    ``fleet_runner._sweep_note``.
    """
    voyage: str = ""
    action: str = ""      # archived | annotated | linked | skipped | flagged
    reason: str = ""
    prNumber: Optional[int] = None
    mergedAt: Optional[str] = None
    order: Optional[str] = None
    orderStatus: Optional[str] = None
    repos: Optional[list[str]] = None


class SweepResult(BaseModel):
    """Result of a workspace housekeeping sweep (FTR-MSO-2026-0426).

    Carries the same report ``mso voyage reconcile --json`` prints, so the Hub
    button and the CLI surface identical results.
    """
    ok: bool
    workspace_id: str
    action: str = "sweep"
    message: str = ""
    dryRun: bool = False
    archived: int = 0
    annotated: int = 0
    changes: list[SweepEntry] = Field(default_factory=list)
    refusals: list[SweepEntry] = Field(default_factory=list)


# ---- Capabilities (FTR-MSO-2026-0489) ---------------------------------------

# The authoring surface's "not yet available" reasons live HERE, not in
# server.py, so that the CapabilityMap field defaults below can carry them
# (FTR-MSO-2026-0617). server.py imports these names and re-exports them, so
# every existing reference keeps working and there remains exactly one string
# per action. Putting them in server.py and defaulting `reason=None` would have
# left the zero-configuration posture saying "unavailable" with no "why" — the
# precise half-truth this order exists to remove.
# FTR-MSO-2026-0619 (PLAN Order 3) shipped
# `POST /workspaces/{id}/voyages`, so this string stopped meaning "not yet
# built" and now means "not available HERE" — the fallback a deployment that
# cannot write the plane (and the zero-config default below) still needs. Same
# treatment FTR-MSO-2026-0622 gave the two below, for the same reason: the name
# is unchanged so every existing import keeps resolving, and the word "yet" is
# gone because telling an operator to wait for a feature that shipped is the
# same class of false statement this plan exists to remove, just inverted.
VOYAGE_CREATE_UNAVAILABLE_MESSAGE = (
    "Creating a voyage is unavailable from this Hub deployment — run "
    "`mso voyage create \"<title>\" --project <ACR>` from a host session."
)
# FTR-MSO-2026-0621 (PLAN Order 5) shipped `POST /workspaces/{id}/orders`, so
# this string stopped meaning "not yet built" and now means "not available
# HERE" — the fallback a deployment that cannot write the plane (and the
# zero-config default below) still needs. Same treatment, and for the same
# reason, as the three siblings: the name is unchanged so every existing import
# keeps resolving, and the word "yet" is gone because telling an operator to
# wait for a feature that shipped is the same class of false statement this
# plan exists to remove, just inverted. With this one the set is complete —
# all four authoring actions now back real endpoints.
ORDER_CREATE_UNAVAILABLE_MESSAGE = (
    "Creating an order is unavailable from this Hub deployment — run "
    "`mso order create \"<title>\" --type FTR --project <ACR>` (or "
    "`mso bug \"<description>\"`) from a host session."
)
# FTR-MSO-2026-0622 (PLAN Order 6) shipped the endpoints these two describe,
# so they stopped meaning "not yet built" and now mean "not available HERE" —
# the fallback a deployment that cannot write the plane (and the zero-config
# default below) still needs. The names are unchanged: one string per action,
# one home, and every existing import keeps resolving. The word "yet" is gone
# deliberately — telling an operator to wait for a feature that shipped is the
# same class of false statement this plan exists to remove, just inverted.
ORDER_EDIT_UNAVAILABLE_MESSAGE = (
    "Editing an order is unavailable from this Hub deployment — edit the "
    "order's JSON under `queues/` from a host session."
)
ORDER_SKIP_UNAVAILABLE_MESSAGE = (
    "Skipping an order is unavailable from this Hub deployment — run "
    "`mso order skip <ORDER-ID>` from a host session."
)
# BUG-MSO-2026-0794: attaching an existing order to a voyage. Same "not
# available HERE" meaning as the siblings above, naming the CLI twin.
ORDER_ATTACH_UNAVAILABLE_MESSAGE = (
    "Attaching an order to a voyage is unavailable from this Hub deployment — "
    "run `mso order attach <ORDER-ID> --voyage <VOY-ID>` from a host session."
)
# FTR-MSO-2026-0767 (PLAN-PLN-MSO-2026-0747 Order 10a, D8): the Providers
# section is the Hub's FIRST configuration write (Finding C). D8 gates it
# like the Hub's other ACTING endpoints — observe-only deployment, not a
# plane-writability probe — because `providers.config` writes
# `config/workspace.json`, not a voyage/order artefact; a containerized
# backend with no host dispatcher has no reason a config write would fail on
# its own, but the plan's recommendation is to gate this identically to
# dispatch/stop for one reason: workspace.json changes are meant to take
# effect on the NEXT host-side crew/dispatch, and an observe-only deployment
# has no host session to apply them to. Reused verbatim by
# `get_capabilities()`'s `providersWrite` field and by the PUT/POST provider
# endpoints' 409, so the pre-click reason and the post-click refusal cannot
# disagree (the same discipline the other three UNAVAILABLE strings above
# follow).
# Deliberately the SAME TEXT as `maestro.hub.server.OBSERVE_ONLY_MESSAGE` —
# not an import (server.py imports FROM this module, so the reverse would be
# circular). `server.build_capability_map()` passes this exact string, never
# a re-typed copy, keeping the default here and the live gate in step.
PROVIDERS_WRITE_UNAVAILABLE_MESSAGE = (
    "This Hub is an observe-only deployment — it cannot launch a usable "
    "dispatcher here. Dispatch from a host session (`mso dispatch`) or run the "
    "Hub natively (`mso hub start`)."
)
# FTR-MSO-2026-0801 (PLAN-PLN-MSO-2026-0792 Order 5a, D2): settings writes are
# Pro/Team/Enterprise (`auth.LEAD_AGENT_TIERS`) — one tier BELOW the Hub's other
# acting endpoints, because a Pro seat's settings are its own machine. That is
# why settingsWrite/deviceSettingsWrite carry their own tier reason instead of
# leaning on `tier.control` (Team/Enterprise), which would refuse a Pro seat a
# write the endpoint actually accepts. Served by the capability map AND raised
# by the PUT endpoints' 403 — one sentence before and after the click.
SETTINGS_WRITE_TIER_MESSAGE = (
    "Changing settings from the Hub requires a Pro, Team or Enterprise licence. "
    "Run `mso settings set <key> <value>` from a host session instead."
)
# The zero-configuration defaults for the two capability fields — what a map
# nobody populated claims. The live map replaces them with the observe-only or
# tier reason the endpoint would actually raise.
SETTINGS_WRITE_UNAVAILABLE_MESSAGE = (
    "Changing workspace settings is unavailable from this Hub deployment — run "
    "`mso settings set <key> <value>` from a host session."
)
DEVICE_SETTINGS_WRITE_UNAVAILABLE_MESSAGE = (
    "Changing device settings is unavailable from this Hub deployment — run "
    "`mso settings set --device <key> <value>` from a host session."
)

# FTR-MSO-2026-0786: the resident LEAD daemon's Hub lifecycle controls. Start
# (and restart) spawn a DETACHED host process — from an observe-only
# (containerised) backend that process would live inside the container, not on
# the host whose fleet it is meant to watch, so the capability is refused
# there with this reason, and `POST .../lead/start|restart` raises the same
# string as its 409. Also the CapabilityMap field default, so an unpopulated
# map never offers a Start button.
LEAD_START_UNAVAILABLE_MESSAGE = (
    "This Hub is an observe-only deployment — it cannot launch the resident "
    "LEAD daemon here (a detached daemon started from a container is not a "
    "host daemon). Start it from a host session (`mso lead start`) or run the "
    "Hub natively (`mso hub start`)."
)
# FTR-MSO-2026-0635: the machine-level `spawnMonitor` preference. The write
# lands in the Hub PROCESS's `~/.maestro/config/settings.json`; from an
# observe-only (containerised) backend that is the container's home, which no
# host dispatch ever reads — so the write is refused there with this reason,
# `PUT /api/v1/machine/spawn-monitor` raises the same string as its 409, and
# it is the CapabilityMap default so an unpopulated map never offers the
# toggle.
SPAWN_MONITOR_WRITE_UNAVAILABLE_MESSAGE = (
    "This Hub is an observe-only deployment — its settings file is not the "
    "host's, so changing the status-monitor preference here would not affect "
    "any host dispatch. Set `spawnMonitor` in `~/.maestro/config/settings.json` "
    "on the host, or run the Hub natively (`mso hub start`)."
)

# Only ever the zero-configuration default: a live Hub always reports stop
# available, mirroring `mso lead stop` being ungated.
LEAD_STOP_UNAVAILABLE_MESSAGE = (
    "This Hub has not declared whether it can stop the resident LEAD daemon. "
    "Stop it from a host session (`mso lead stop`)."
)
# FTR-MSO-2026-0789 (PLAN-FTR-MSO-2026-0498 D7): fleet pause / resume. Both
# follow the observe-only probe, and each string is BOTH the CapabilityMap
# field default (an unpopulated map never offers the button) and the 409 the
# endpoint raises. Pause is a file-plane write, but it must name the LIVE
# dispatcher process (PID + create time) — which a containerised Hub cannot
# see — and resume's relaunch spawns a host dispatcher exactly as dispatch does.
FLEET_PAUSE_UNAVAILABLE_MESSAGE = (
    "This Hub is an observe-only deployment — it cannot see the dispatcher's "
    "process from here, so it cannot ask it to drain. Pause from a host "
    "session (`mso pause`) or run the Hub natively (`mso hub start`)."
)
FLEET_RESUME_UNAVAILABLE_MESSAGE = (
    "This Hub is an observe-only deployment — it cannot see or relaunch the "
    "dispatcher from here. Resume from a host session (`mso resume`) or run "
    "the Hub natively (`mso hub start`)."
)


class CapabilityInfo(BaseModel):
    """Whether one mutating action is available in THIS deployment, and why not.

    PLAN-PLN-MSO-2026-0468 §4.5 / BUG-MSO-2026-0440: the reason a caller cannot
    act is declared here, before any click, so the frontend renders a disabled
    control with its reason instead of discovering a 409 after the fact.
    ``reason`` is populated only when ``available`` is False and is always the
    same server-side constant the corresponding endpoint's 409 uses.
    """
    available: bool = True
    reason: Optional[str] = None


class TierCapability(BaseModel):
    """Licence-tier gate shared by every mutating control action.

    Distinct from ``CapabilityInfo`` above: a deployment can be fully CAPABLE
    of an action (e.g. dispatch on a host session) and still be refused it for
    lacking a Team/Enterprise licence — two independent reasons to disable a
    button, both declared up front.
    """
    control: bool = False
    reason: Optional[str] = None


class CapabilityMap(BaseModel):
    """Response for ``GET /api/v1/capabilities`` — poller-independent, cheap.

    Declares, up front, which mutating actions this Hub deployment can
    actually perform, so the frontend disables a button WITH ITS REASON
    before the click rather than rendering it enabled-and-hopeful.
    """
    dispatch: CapabilityInfo = Field(default_factory=CapabilityInfo)
    sweep: CapabilityInfo = Field(default_factory=CapabilityInfo)
    review: CapabilityInfo = Field(default_factory=CapabilityInfo)
    orderRetry: CapabilityInfo = Field(default_factory=CapabilityInfo)

    # ---- Authoring surface (FTR-MSO-2026-0617, PLAN-PLN-MSO-2026-0556 §4.3) --
    #
    # These four declare the AUTHORING actions the Hub does not yet perform.
    # Unlike every field above, they default to ``available=False`` — an
    # authoring control has no backing endpoint until this plan's Orders 3/5/6
    # land, and the whole point of BUG-MSO-2026-0555 is that a control with no
    # endpoint must never render enabled. The default here is what makes the
    # honest posture the ZERO-CONFIGURATION one: a field that is never
    # populated reports "unavailable, and here is why", not "go ahead".
    #
    # When the endpoint lands, the server flips ``available`` to True in
    # ``get_capabilities()`` and NO frontend change is required (§7) — the
    # button already consumes this field through the LOADING_REASON path.
    # FTR-MSO-2026-0622 note: orderEdit and orderSkip now HAVE endpoints
    # (PLAN Order 6), and get_capabilities() reports them available on a
    # writable plane. Their DEFAULT here stays False on purpose — the default
    # answers "what does a map nobody populated claim?", and the safe answer
    # to that never changes with what shipped.
    voyageCreate: CapabilityInfo = Field(
        default_factory=lambda: CapabilityInfo(
            available=False, reason=VOYAGE_CREATE_UNAVAILABLE_MESSAGE))
    orderCreate: CapabilityInfo = Field(
        default_factory=lambda: CapabilityInfo(
            available=False, reason=ORDER_CREATE_UNAVAILABLE_MESSAGE))
    orderEdit: CapabilityInfo = Field(
        default_factory=lambda: CapabilityInfo(
            available=False, reason=ORDER_EDIT_UNAVAILABLE_MESSAGE))
    orderSkip: CapabilityInfo = Field(
        default_factory=lambda: CapabilityInfo(
            available=False, reason=ORDER_SKIP_UNAVAILABLE_MESSAGE))
    # BUG-MSO-2026-0794: POST /orders/{id}/attach. Same safe zero-config
    # default; get_capabilities() flips it on a writable plane.
    orderAttach: CapabilityInfo = Field(
        default_factory=lambda: CapabilityInfo(
            available=False, reason=ORDER_ATTACH_UNAVAILABLE_MESSAGE))
    # FTR-MSO-2026-0767 (PLAN Order 10a): the Hub's providers config write.
    # Same "default False, safe zero-config answer" contract as the four
    # authoring fields above — a deployment that never populates this map
    # must never report the write available. `get_capabilities()` flips it to
    # True/None on a non-observe-only backend (D8's gate; see
    # `PROVIDERS_WRITE_UNAVAILABLE_MESSAGE` above for why observe-only, not
    # plane-writability, is the probe here).
    providersWrite: CapabilityInfo = Field(
        default_factory=lambda: CapabilityInfo(
            available=False, reason=PROVIDERS_WRITE_UNAVAILABLE_MESSAGE))
    # FTR-MSO-2026-0801 (PLAN-0792 Order 5a): `PUT .../workspaces/{id}/settings`
    # and `PUT /api/v1/settings`. Same "default False, with a reason" contract.
    # Unlike providersWrite, the LIVE value folds in the licence tier as well
    # (D2: Pro+, not `tier.control`'s Team+) — see SETTINGS_WRITE_TIER_MESSAGE.
    settingsWrite: CapabilityInfo = Field(
        default_factory=lambda: CapabilityInfo(
            available=False, reason=SETTINGS_WRITE_UNAVAILABLE_MESSAGE))
    deviceSettingsWrite: CapabilityInfo = Field(
        default_factory=lambda: CapabilityInfo(
            available=False, reason=DEVICE_SETTINGS_WRITE_UNAVAILABLE_MESSAGE))
    # FTR-MSO-2026-0786: the resident LEAD daemon's start (covers restart) and
    # stop controls. Same "default False, safe zero-config answer" contract;
    # `build_capability_map()` populates both on every live Hub.
    leadStart: CapabilityInfo = Field(
        default_factory=lambda: CapabilityInfo(
            available=False, reason=LEAD_START_UNAVAILABLE_MESSAGE))
    leadStop: CapabilityInfo = Field(
        default_factory=lambda: CapabilityInfo(
            available=False, reason=LEAD_STOP_UNAVAILABLE_MESSAGE))
    # FTR-MSO-2026-0635: the machine-level spawnMonitor preference write.
    # Same "default False, safe zero-config answer" contract.
    spawnMonitorWrite: CapabilityInfo = Field(
        default_factory=lambda: CapabilityInfo(
            available=False, reason=SPAWN_MONITOR_WRITE_UNAVAILABLE_MESSAGE))
    # FTR-MSO-2026-0789: fleet pause (drain) and resume. Same "default False,
    # safe zero-config answer" contract; `build_capability_map()` populates
    # both from the observe-only probe.
    fleetPause: CapabilityInfo = Field(
        default_factory=lambda: CapabilityInfo(
            available=False, reason=FLEET_PAUSE_UNAVAILABLE_MESSAGE))
    fleetResume: CapabilityInfo = Field(
        default_factory=lambda: CapabilityInfo(
            available=False, reason=FLEET_RESUME_UNAVAILABLE_MESSAGE))

    tier: TierCapability = Field(default_factory=TierCapability)


# ---- Blockage (FTR-MSO-2026-0721, PLAN-FTR-MSO-2026-0700 §5.2) --------------
#
# These models mirror ``maestro.core.blockage``'s ``to_dict()`` EXACTLY, field
# for field and name for name, so an endpoint can be written as
# ``BlockageResponse(blocked=True, **blockage.to_dict())`` rather than by
# re-listing the shape here. That is deliberate: a hand-copied wire shape is a
# second definition of the model that drifts from the first, which is the
# whole failure PLAN-FTR-MSO-2026-0700 exists to remove one level up.

class EvidenceModel(BaseModel):
    """One artefact that PROVES the cause — ``blockage.Evidence.to_dict()``.

    ``detail`` is passed through untouched: an unmeasurable diff-stat arrives
    here as ``"diff-stat unknown"`` and must be rendered as that, never
    normalised to ``"0 files"`` (BUG-MSO-2026-0696's honesty rule).
    ``artefactKey``, when non-empty, is a key
    ``GET /orders/{id}/artefacts/{key}`` will serve.
    """
    kind: str = ""
    label: str = ""
    path: str = ""
    branch: str = ""
    detail: str = ""
    artefactKey: str = ""


class OptionModel(BaseModel):
    """One thing the operator can do — ``blockage.Option.to_dict()`` plus the
    server's capability resolution.

    ``available`` / ``unavailableReason`` are NOT on the core dataclass: the
    core has no idea which deployment it is being rendered in. The server
    stamps them from the same values ``GET /api/v1/capabilities`` reports, so
    the reason shown before the click is the sentence the endpoint's 403/409
    would raise after it (FTR-MSO-2026-0617's honesty rule, PLAN §5.2).

    An option with an empty ``hubAction`` is CLI-only. It is reported
    ``available: true`` — the command is real and an operator can run it in a
    terminal; it simply has no button. Reporting it unavailable would be a
    lie about a working remedy.
    """
    label: str = ""
    command: str = ""
    hubAction: str = ""
    hubMethod: str = ""
    hubPath: str = ""
    capability: str = ""
    riskNote: str = ""
    recommended: bool = False
    available: bool = True
    unavailableReason: Optional[str] = None


class BlockerRefModel(BaseModel):
    """An order the subject waits on, carrying its OWN diagnosis —
    ``blockage.BlockerRef.to_dict()``."""
    orderId: str = ""
    status: str = ""
    kind: str = ""
    cause: str = ""


class BlockageResponse(BaseModel):
    """``GET /orders/{id}/blockage`` and ``GET /voyages/{id}/blockage``.

    ``blocked`` is the only field this adds to ``Blockage.to_dict()``. When it
    is False the subject is fine and every other field stays at its default —
    a "nothing is wrong" answer is a successful answer, not a 404 and not an
    empty body the caller has to guess at (PLAN §5.1's rule for the CLI verb,
    applied to the wire).
    """
    blocked: bool = False
    subjectId: str = ""
    subjectKind: str = ""
    kind: str = ""
    cause: str = ""
    since: str = ""
    severity: str = ""
    detail: str = ""
    title: str = ""
    summary: str = ""
    suggestedCommand: str = ""
    evidence: list[EvidenceModel] = Field(default_factory=list)
    blockers: list[BlockerRefModel] = Field(default_factory=list)
    options: list[OptionModel] = Field(default_factory=list)
    voyageId: str = ""
    role: str = ""
    progressing: bool = False
    workspace_id: str = ""


# ---- LEAD sub-agent (FTR-MSO-2026-0539, PLAN-PLN-MSO-2026-0504 §13) --------

class LeadFindingsBySeverity(BaseModel):
    """Open patrol findings for this workspace, tallied by severity.

    Sourced from the LEAD daemon's own persisted state (written once per
    heartbeat tick by ``maestro.lead.agent.run_once`` — the daemon is the
    only place ``mso doctor`` actually runs, per PLAN-PLN-MSO-2026-0504 §6's
    noise-control design), never re-derived by the Hub itself.
    """
    critical: int = 0
    high: int = 0
    medium: int = 0
    low: int = 0


class LeadAction(BaseModel):
    """Most recent ``LEAD_ACTION`` lifecycle event, if any.

    PLAN-PLN-MSO-2026-0504 §3.4 defines the act-and-inform band;
    PLAN-PLN-MSO-2026-0584 Dimension C (the finding-to-action mapping in
    ``maestro.lead.bands.dispatch_actions_for_findings``, wired into
    ``agent.run_once``) is what actually calls ``execute_action`` and
    produces ``LEAD_ACTION`` events in production. ``lastAction`` still
    resolves to ``None`` for a workspace whose daemon has never had a
    NEW/ESCALATED finding mapped to a D7 action — that is a correct "nothing
    to act on yet", not a missing wire-up.
    """
    type: str = ""
    detail: str = ""
    at: str = ""


class LeadStatus(BaseModel):
    """``GET /api/v1/workspaces/{id}/lead`` — PLAN-PLN-MSO-2026-0504 §13.

    ``available``/``reason`` mirror ``TierCapability``'s shape rather than a
    plain 403: a card pip and a workspace-detail strip both need SOMETHING
    to render for a community/non-Pro workspace (greyed, with ``reason`` as
    the upgrade affordance) — a raised HTTP exception gives neither surface
    anything to work with, matching the ``GET /api/v1/capabilities`` pattern
    at ``hub/server.py`` (declare availability up front, never a post-hoc
    403 as the only signal).
    """
    available: bool = False
    reason: Optional[str] = None
    state: str = "stopped"  # "running" | "stopped"
    # BUG-MSO-2026-0541 / PLAN-PLN-MSO-2026-0504 §4.1's lesson: a dead
    # dispatcher hid behind a boolean liveness flag for three ticks. Exposed
    # here as a NUMBER (seconds), never a boolean, for the same reason —
    # None only when the daemon has never completed a single tick.
    heartbeatAgeSeconds: Optional[float] = None
    findings: LeadFindingsBySeverity = Field(default_factory=LeadFindingsBySeverity)
    lastAction: Optional[LeadAction] = None
    # PLAN-PLN-MSO-2026-0584 Dimension A: extends (never replaces) the
    # states above — `state` stays exactly "running"/"stopped"; `standDown`
    # is an ORTHOGONAL fact so a stood-down daemon (state="running",
    # standDown=True — a live process deliberately doing no work) never
    # renders identically to a dead one (state="stopped"). Read from the
    # durable `lead.standDown` config, not state.json, so a toggle is
    # reflected immediately rather than after the daemon's next tick.
    standDown: bool = False
    # RC-5: the version the RUNNING daemon is actually executing (pinned at
    # process start — a `pip install` mid-run never reaches it), vs. the
    # version THIS Hub backend has installed right now. `versionMismatch`
    # is the pre-computed comparison so the frontend never has to string-
    # compare two optional fields itself.
    #
    # BUG-MSO-2026-0724: `runningVersion` and `versionMismatch` are now
    # `None`/`False` whenever `state != "running"` — a stopped daemon runs no
    # version, and the strip rendering "Running stale code (v5.12.1)" over a
    # STOPPED pill is what hid the 2026-09-10 PSG daemon death. What the last
    # tick wrote survives under `lastRanVersion`, which is populated whether
    # or not the daemon is up, so the strip can say "stopped — last ran
    # v5.12.1" instead.
    runningVersion: Optional[str] = None
    lastRanVersion: Optional[str] = None
    installedVersion: Optional[str] = None
    versionMismatch: bool = False


class LeadFindingDetail(BaseModel):
    """One persisted LEAD patrol finding (FTR-MSO-2026-0577).

    Mirrors the bounded shape ``maestro.lead.agent.run_once()`` persists into
    ``lastFindingsDetail`` in ``.mso/lead/state.json`` — the SAME tick
    ``LeadStatus.findings``'s counts were computed from (see ``LeadDetail``
    below for why that matters). ``title``/``detail``/``suggestedCommand``
    are redacted via ``maestro.hooks.secret_patterns.redact_text`` before
    this model is constructed.
    """
    checkId: str = ""
    subjectId: str = ""
    severity: str = "low"
    title: str = ""
    detail: str = ""
    firstSeenAt: str = ""
    suggestedCommand: Optional[str] = None
    scope: str = "workspace"
    # PLAN-PLN-MSO-2026-0584 Dimension D: the stable fingerprint the drawer's
    # ack/unack controls target — never derived client-side (it depends on
    # the check's fixed BASE severity, which the client never sees; only the
    # server, via maestro.patrol.state.fingerprint(), computes it correctly).
    fingerprint: Optional[str] = None
    # True only for a LIVE, unpierced acknowledgement (expiry + escalation-
    # pierce already applied server-side — maestro.patrol.state.is_acknowledged).
    # Suppresses delivery only; this finding is still counted in
    # LeadStatus.findings and still listed here regardless of this flag
    # (count-preserving suppression, PLAN Dimension D guard 3).
    acknowledged: bool = False
    acknowledgedBy: Optional[str] = None
    acknowledgedNote: Optional[str] = None
    acknowledgedExpiresAt: Optional[str] = None
    # FTR-MSO-2026-0631: computed server-side from the RAW (pre-redaction)
    # suggestedCommand via maestro.lead.run_verbs.parse_verb() — the closed
    # verb list lives entirely server-side, so the client never has to guess
    # whether a command is runnable. `runVerb` names which verb matched
    # (e.g. "order.retry") so the drawer can pick the right CapabilityInfo
    # from GET /api/v1/capabilities before rendering Run as enabled; `None`
    # whenever `runnable` is False.
    runnable: bool = False
    runVerb: Optional[str] = None


class LeadAuditEvent(BaseModel):
    """One LEAD-related lifecycle.log line, parsed via
    ``maestro.hub.lifecycle_tail`` — no second log parser.

    ``type`` is one of LEAD_TICK / LEAD_ACTION / LEAD_FINDING / LEAD_REPORTED
    / LEAD_CEILING_HIT.
    """
    type: str = ""
    message: str = ""
    at: str = ""


class LeadDetail(BaseModel):
    """``GET /api/v1/workspaces/{id}/lead/detail`` — FTR-MSO-2026-0577.

    ``available``/``reason`` mirror ``LeadStatus``'s shape (never a bare
    403), for the same reason: a drawer for a community/non-Pro workspace
    still needs something to render (greyed, with ``reason`` as the upgrade
    affordance).

    ``findings`` is read from the SAME persisted tick ``LeadStatus.findings``
    is computed from — never a fresh ``mso doctor`` pass triggered by opening
    the drawer. Running the patrol on drawer-open would let the drawer show
    (say) 17 findings under a strip that still says 19 from its last poll,
    with no explanation for the mismatch — worse than showing nothing,
    because it teaches the operator the numbers can't be trusted. One tick,
    one set of findings, one source, both surfaces.

    ``hasTicked``/``lastTickAt`` let a never-ticked daemon and a stopped one
    both render as an honest "here is what I know", not an empty list that
    reads as "nothing found" and not a spinner that never resolves.
    """
    available: bool = False
    reason: Optional[str] = None
    state: str = "stopped"  # "running" | "stopped"
    hasTicked: bool = False
    lastTickAt: Optional[str] = None
    findings: list[LeadFindingDetail] = Field(default_factory=list)
    # True total findings this tick found, and whether `findings` above (capped
    # at maestro.lead.agent.MAX_PERSISTED_FINDINGS) is a subset of it — lets
    # the drawer say "showing X of Y" instead of implying X is everything.
    findingsTotal: int = 0
    findingsTruncated: bool = False
    auditTail: list[LeadAuditEvent] = Field(default_factory=list)


class LeadPip(BaseModel):
    """Lightweight LEAD indicator embedded in ``WorkspaceSummary`` for the
    overview page's per-card pip (PLAN §13: "so one glance covers every
    fleet"). Deliberately NOT a full ``LeadStatus`` — the overview page
    polls every registered workspace on a short interval, so this carries
    only what the pip renders, sourced from the same cheap daemon-state read
    as ``LeadStatus`` (never a fresh patrol pass per card, per tick).
    """
    available: bool = False
    state: str = "stopped"  # "running" | "stopped"
    findings: LeadFindingsBySeverity = Field(default_factory=LeadFindingsBySeverity)


# ---- Charts (FTR-MSO-2026-0496, PLAN-VOY-MSO-2026-0143 Phase 1 part 2) ------
# Field names mirror maestro.core.charts.Waypoint/Leg/Chart.to_dict() exactly
# (the same shape `mso chart show --format json` prints) so the CLI and the
# Hub's read-only graph view can never disagree about the wire format.

class ChartWaypoint(BaseModel):
    """One compiled chart node — matches Waypoint.to_dict()."""
    order: str
    role: str
    state: str = "NOT_STARTED"
    humanGate: bool = False


class ChartLeg(BaseModel):
    """One compiled chart edge — matches Leg.to_dict(). ``from`` is a Python
    keyword, so the field is named ``from_`` with an alias; construct via
    ``ChartLeg(**leg.to_dict())`` (dict key ``"from"`` resolves via the alias)."""
    model_config = {"populate_by_name": True}

    from_: str = Field(alias="from")
    to: str
    type: str
    humanGate: bool = False


class ChartResponse(BaseModel):
    """A compiled voyage or order chart — matches Chart.to_dict()."""
    chartId: str
    voyage: str = ""
    nodes: dict[str, ChartWaypoint] = Field(default_factory=dict)
    edges: list[ChartLeg] = Field(default_factory=list)


# ---- Usage aggregation (FTR-MSO-2026-0333) ----------------------------------

class UsageBucket(BaseModel):
    """A single bucket in a grouped usage rollup.

    Matches the frontend UsageBucket interface in app/types/index.ts.
    """
    key: str                    # project_id / voyage_id / order_id / role code
    label: str = ""             # human-readable label (same as key when not set)
    total_tokens: int = 0
    estimated_cost_usd: float = 0.0
    order_count: int = 0        # number of distinct orders contributing to this bucket


class UsageSeriesPoint(BaseModel):
    """One point in a date-keyed time series.

    Matches the frontend UsageSeriesPoint interface in app/types/index.ts.
    Extends UsagePoint semantics but kept separate so UsagePoint (workspace
    sparkline) stays backward-compatible.
    """
    date: str           # YYYY-MM-DD
    tokens: int = 0
    cost_usd: float = 0.0


class UsageRollup(BaseModel):
    """Top-level response for grouped usage aggregation endpoints.

    Matches the frontend UsageRollup interface in app/types/index.ts.
    """
    from_date: Optional[str] = None     # inclusive date filter applied (YYYY-MM-DD)
    to_date: Optional[str] = None       # inclusive date filter applied (YYYY-MM-DD)
    group_by: str = "project"           # 'project' | 'voyage' | 'order' | 'role'
    total_tokens: int = 0
    estimated_cost_usd: float = 0.0
    buckets: list[UsageBucket] = Field(default_factory=list)
    series: list[UsageSeriesPoint] = Field(default_factory=list)  # per-day totals


class ModelUsage(BaseModel):
    """Per-model token breakdown for an order.

    Matches the frontend ModelUsage interface in app/types/index.ts.
    """
    input_tokens: int = 0
    output_tokens: int = 0
    cache_creation_input_tokens: int = 0
    cache_read_input_tokens: int = 0
    message_count: int = 0


class IterationUsage(BaseModel):
    """Usage record for one crew iteration (from per-iteration *.jsonl files).

    Matches the frontend IterationUsage interface in app/types/index.ts.
    """
    iteration: int = 0
    role: str = ""
    crew_number: int = 0
    total_tokens: int = 0
    estimated_cost_usd: float = 0.0
    timestamp: str = ""
    models: dict[str, ModelUsage] = Field(default_factory=dict)


class OrderUsageDetail(BaseModel):
    """Full usage breakdown for a single order (JSON + JSONL combined).

    Matches the frontend OrderUsageDetail interface in app/types/index.ts.
    """
    order_id: str
    voyage_id: Optional[str] = None
    total_tokens: int = 0
    estimated_cost_usd: float = 0.0
    models: dict[str, ModelUsage] = Field(default_factory=dict)
    role_buckets: list[UsageBucket] = Field(default_factory=list)   # from JSONL (empty if absent)
    iterations: list[IterationUsage] = Field(default_factory=list)  # from JSONL (empty if absent)
    timestamp: Optional[str] = None


# ---- Reports (FTR-MSO-2026-0729, PLAN-PLN-MSO-2026-0726 §5 Order A2) --------
# The wire shape for `maestro.reports`' framework-agnostic records.
#
# Every field name below mirrors the corresponding dataclass `to_dict()` key in
# `maestro/reports/models.py` EXACTLY, so a response is built as
# `QAReportModel(**summary.to_dict())` and the two shapes cannot drift: there is
# no hand-written field mapping to fall out of date. That direction is
# deliberate and is the plan's "one core model, many surfaces" rule (§4) — the
# core dataclasses know nothing about Pydantic, and the Hub adapts to them.
#
# These keys are camelCase, unlike the snake_case usage models above, because
# they mirror the core `to_dict()` rather than a hand-written TS interface. The
# same precedent already exists in this module for ChartWaypoint/ChartLeg, which
# mirror `maestro.core.charts`' own `to_dict()`.
#
# THE HONESTY RULE (plan §7) is structural here, not a convention:
#   * every count is Optional — `tests: None` ("no parseable count") is a
#     different claim from `tests: 0` ("the fleet ran no tests"), and a model
#     that defaulted them to 0 would erase that distinction on the wire;
#   * `verdict` carries UNDETERMINED and `status` carries NOT RECORDED as
#     first-class values (Captain decisions D3/D4) — never folded into a pass;
#   * `parseNotes` travels with every record so a surface can caveat what could
#     not be read instead of presenting a partial parse as a complete one.

class ParseCoverageModel(BaseModel):
    """How much of a report set actually parsed — the D3 parser-drift alarm.

    `undetermined` is reported as its own figure and is never subtracted away:
    a heading-contract drift shows up as a falling `parsed` against a steady
    `total`, which is exactly the signal a silent parser degradation otherwise
    hides. Mirrors `maestro.reports.models.ParseCoverage.to_dict()`.
    """
    total: int = 0
    parsed: int = 0
    undetermined: int = 0


class QAACRowModel(BaseModel):
    """One row of a QA report's `## Acceptance Criteria Verification` table.

    Mirrors `ACCriterionRow.to_dict()`. `met` is carried explicitly rather than
    left for a client to derive from `status`, so no surface can reinvent the
    D4 rule ("only an affirmative recorded PASS is met") and get it wrong.
    """
    id: str = ""
    criterion: str = ""
    status: str = "NOT RECORDED"
    rawStatus: str = ""
    validation: str = ""
    notes: str = ""
    evidence: str = ""
    provenance: str = "not recorded"
    met: bool = False


class QADefectModel(BaseModel):
    """One row of `## Defects Found` — mirrors `role_rejection.Defect.to_dict()`.

    Field names are that dataclass's verbatim, so the Hub's defect shape and the
    dispatcher's own lap-routing defect shape can never diverge.
    """
    id: str = ""
    severity: str = ""
    summary: str = ""
    file: str = ""
    line: str = ""
    blocking: bool = False


class QATestCategoryModel(BaseModel):
    """One `### <category> Tests` subsection's counts. All figures Optional."""
    name: str = ""
    tests: Optional[int] = None
    passed: Optional[int] = None
    failed: Optional[int] = None


class QATestCountsModel(BaseModel):
    """A report's `## Test Summary` rollup — mirrors `TestCounts.to_dict()`.

    `recorded` says whether ANY figure was parseable, so a client can render
    "not recorded" without having to test three Optionals itself.
    """
    tests: Optional[int] = None
    passed: Optional[int] = None
    failed: Optional[int] = None
    recorded: bool = False
    categories: list[QATestCategoryModel] = Field(default_factory=list)


class QAReportModel(BaseModel):
    """One QA report's machine-readable record — mirrors `QAReportSummary.to_dict()`.

    `reportRel` is relative to the artefact root and `reportName` is a bare
    filename: neither is ever an absolute path, because an absolute path on a
    wire response leaks the operator's filesystem layout (the same rule the
    artefact routes already follow).

    `nodeVerdict` is a CORROBORATING HINT ONLY (Captain decision D3) — the
    dispatcher rewrites that front-matter field to CONSUMED once routing acts on
    it, so it is a routing token with a lifecycle, not a report field.
    `nodeVerdictCorroborates` is tri-state (`None` = nothing to compare), so a
    surface can flag a disagreement rather than silently preferring one source.
    """
    orderId: str
    verdict: str = "UNDETERMINED"
    rawVerdict: str = ""
    verdictSource: str = ""
    nodeVerdict: Optional[str] = None
    nodeVerdictCorroborates: Optional[bool] = None
    decided: bool = False
    acRows: list[QAACRowModel] = Field(default_factory=list)
    acMet: int = 0
    acNotRecorded: int = 0
    defects: list[QADefectModel] = Field(default_factory=list)
    blockingDefectCount: int = 0
    testCounts: QATestCountsModel = Field(default_factory=QATestCountsModel)
    reportName: str = ""
    reportRel: str = ""
    modified: str = ""
    size: int = 0
    truncated: bool = False
    parseNotes: list[str] = Field(default_factory=list)
    #: Which registered workspace this report was read from. Added by the Hub
    #: (the core record is workspace-agnostic), so a cross-workspace list stays
    #: attributable row by row.
    workspaceId: str = ""


class QAReportList(BaseModel):
    """`GET /api/v1/reports/qa` — a bounded list plus its parse coverage.

    `limit` / `returned` / `available` are all reported because a truncated list
    that did not say so would be indistinguishable from a complete one:
    `available` is how many QA reports the scanned workspaces actually hold,
    `returned` is how many are in this response.

    `coverage` describes exactly the records in `reports` — never a larger set
    the caller did not receive.
    """
    reports: list[QAReportModel] = Field(default_factory=list)
    parseCoverage: ParseCoverageModel = Field(default_factory=ParseCoverageModel)
    workspaceId: Optional[str] = None   # the filter applied, when one was
    limit: int = 0
    returned: int = 0
    available: int = 0
    #: Workspaces that were scanned for this response, so a caller can tell an
    #: empty list caused by "nothing registered" from one caused by a filter.
    workspaces: list[str] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Acceptance-criteria report models (FTR-MSO-2026-0734 — PLAN-PLN-MSO-2026-0726 §5 B2)
# ---------------------------------------------------------------------------
# Mirrors of `maestro.reports.models.ACConflict` / `ACOrderRollup` /
# `ACCoverage` `to_dict()`, camelCase for the same reason as the QA models
# above. Every figure was computed by `maestro.reports.ac_reader`; nothing here
# re-derives a count.
#
# THE HEADLINE IS COVERAGE, NOT A PASS RATE (Captain decision D4). `covered` of
# `ordersWithCriteria` is the figure a surface leads with; `met` / `partial` /
# `outstanding` sum to `covered` and are computed over covered orders only, and
# `notCovered` is its own bucket, never folded into any of them.

class ACConflictModel(BaseModel):
    """One criterion the order JSON and the QA report recorded differently.

    Both sides verbatim — mirrors `ACConflict.to_dict()`. Shown side by side,
    never resolved by preferring one source.
    """
    id: str = ""
    orderStatus: str = ""
    orderRawStatus: str = ""
    qaStatus: str = ""
    qaRawStatus: str = ""


class ACOrderRollupModel(BaseModel):
    """One order's AC verification record — mirrors `ACOrderRollup.to_dict()`.

    `rows` reuse `QAACRowModel`: the core emits the same `ACCriterionRow` shape
    from either source, told apart by each row's `provenance` (`order.acResults`
    / `QA report` / `not recorded`). `coverageBucket` is one of `met`,
    `partial`, `outstanding`, `not-covered`, `no-criteria`.
    """
    orderId: str
    title: str = ""
    coverageBucket: str = "not-covered"
    voyageId: str = ""
    rows: list[QAACRowModel] = Field(default_factory=list)
    sources: list[str] = Field(default_factory=list)
    conflicts: list[str] = Field(default_factory=list)
    conflictDetails: list[ACConflictModel] = Field(default_factory=list)
    total: int = 0
    recorded: int = 0
    met: int = 0
    failed: int = 0
    partial: int = 0
    notRecorded: int = 0
    conflicted: int = 0
    covered: bool = False
    hasCriteria: bool = False
    hasOrderResults: bool = False
    qaReportPresent: bool = False
    evidencePresent: bool = False
    qaReportRel: str = ""
    parseNotes: list[str] = Field(default_factory=list)
    #: Added by the Hub, like `QAReportModel.workspaceId`.
    workspaceId: str = ""


class ACCoverageModel(BaseModel):
    """The AC page's headline — mirrors `ACCoverage.to_dict()`.

    `resultsWithoutCriteria` sits outside the denominator (results for criteria
    that were never written down) and is reported rather than dropped.
    """
    ordersWithCriteria: int = 0
    covered: int = 0
    notCovered: int = 0
    coveredByOrderResults: int = 0
    coveredByQaReport: int = 0
    evidencePresent: int = 0
    ordersWithConflicts: int = 0
    resultsWithoutCriteria: int = 0
    met: int = 0
    partial: int = 0
    outstanding: int = 0
    coveredCriteriaStatus: dict[str, int] = Field(default_factory=dict)


class ACReportList(BaseModel):
    """`GET /api/v1/reports/ac` — the coverage headline plus a bounded order list.

    UNLIKE `QAReportList.parseCoverage`, `coverage` here is computed over EVERY
    order in the scanned workspaces, not over the returned page: the headline
    "N of M orders with criteria have a recorded verification" is a fleet figure,
    and computing it over a bounded, filtered page would state a different,
    smaller claim under the same words. `considered` is how many AC records that
    covered; `available` is how many matched `bucket`; `returned` is how many are
    in `rollups`.
    """
    coverage: ACCoverageModel = Field(default_factory=ACCoverageModel)
    rollups: list[ACOrderRollupModel] = Field(default_factory=list)
    workspaceId: Optional[str] = None
    bucket: Optional[str] = None
    limit: int = 0
    returned: int = 0
    available: int = 0
    considered: int = 0
    workspaces: list[str] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Security report models (FTR-MSO-2026-0736 — PLAN-PLN-MSO-2026-0726 §5 B4)
# ---------------------------------------------------------------------------
# Mirrors of `maestro.reports.models.SecurityReportSummary` / `ScannerRun` /
# `ReportedFinding` `to_dict()`. Every value was computed by
# `maestro.reports.security_reader`; nothing here re-derives one.
#
# TWO FAMILIES, TWO RESPONSES, NEVER ONE NUMBER (plan §1.4, §7). A SEC crew's
# verdict is a judgement about one order's diff; a `REVIEW-*` scanner run's
# counts are regex matches over every file the scanner walked, and are known
# to be wrong by orders of magnitude (312 CRITICAL / 4539 HIGH on a run whose
# sampled HIGH was the `...` in a print statement). So the two families travel
# on SEPARATE routes with separate list models, and neither list model carries
# a severity total: there is no field here a surface could render as the
# fleet's risk posture, by construction.

class SecurityFindingModel(BaseModel):
    """One finding as a report wrote it — mirrors `ReportedFinding.to_dict()`.

    Field names are `maestro.security.owasp_patterns.Finding.to_dict()`'s
    verbatim, so the Hub's security shape and the scanner's own JSON can never
    diverge. Every field is Optional: a hand-written `### F1 - MEDIUM: …`
    heading states an id, a severity and a title and nothing else, and a
    default of `0` / `False` would be inventing what the report never said.
    """
    id: Optional[str] = None
    cwe: Optional[str] = None
    owaspCategory: Optional[str] = None
    title: Optional[str] = None
    severity: Optional[str] = None
    baseSeverity: Optional[str] = None
    adjustedSeverity: Optional[str] = None
    file: Optional[str] = None
    line: Optional[int] = None
    column: Optional[int] = None
    snippet: Optional[str] = None
    remediation: Optional[str] = None
    waived: Optional[bool] = None
    waiverReason: Optional[str] = None


class SecurityReportModel(BaseModel):
    """One `SEC-{ORDER-ID}[-VARIANT]` document — mirrors `SecurityReportSummary`.

    `verdict` carries UNDETERMINED as a first-class value: SEC reports have no
    front-matter and no enforced heading contract, so for a real fraction of
    them UNDETERMINED is the honest answer, and it is never a pass. `variant`
    keeps several documents for one order (a crew's review and an independent
    LEAD review) distinguishable instead of one silently winning.

    `verdictBasis` names the reader path that decided `verdict`: `front-matter`
    (the `secVerdict` field SEC reports carry since FTR-MSO-2026-0779),
    `heuristic` (the heading cascade for older reports), `json`, or `""` when
    the report could not be read.
    """
    orderId: str
    verdict: str = "UNDETERMINED"
    rawVerdict: str = ""
    verdictSource: str = ""
    verdictBasis: str = ""
    decided: bool = False
    findings: list[SecurityFindingModel] = Field(default_factory=list)
    reportName: str = ""
    reportRel: str = ""
    modified: str = ""
    variant: str = ""
    size: int = 0
    truncated: bool = False
    parseNotes: list[str] = Field(default_factory=list)
    #: Added by the Hub, like `QAReportModel.workspaceId`.
    workspaceId: str = ""


# Voyage report models (FTR-MSO-2026-0737 — PLAN-PLN-MSO-2026-0726 §5 B5)
# ---------------------------------------------------------------------------
# Mirrors of `maestro.reports.models.VoyageReportSummary` and its parts'
# `to_dict()`. The voyage report is COMPOSED ON READ (Captain decision D2):
# every figure was computed by `maestro.reports.voyage_reader` from the voyage
# manifest, the member orders' QA / AC / SEC records and the usage aggregator.
#
# Spend is Optional all the way down. `usage.status` is `recorded`,
# `not-recorded` or `unavailable`, and `totalTokens` is `None` unless it is
# `recorded` — a voyage with no usage record must reach a client as "not
# recorded", never as 0 tokens.

class VoyageUsageShareModel(BaseModel):
    """One role's or one crew slot's share of a voyage's spend."""
    key: str = ""
    label: str = ""
    totalTokens: int = 0
    estimatedCostUsd: float = 0.0
    orderCount: int = 0
    iterations: int = 0


class VoyageUsageModel(BaseModel):
    """A voyage's spend — mirrors `VoyageUsage.to_dict()`.

    `ordersWithIterationData` against `ordersWithUsage` says how much of the
    total the role / crew split covers; `note` says so in words when it is not
    all of it.
    """
    status: str = "not-recorded"
    totalTokens: Optional[int] = None
    estimatedCostUsd: Optional[float] = None
    ordersWithUsage: int = 0
    ordersWithIterationData: int = 0
    roles: list[VoyageUsageShareModel] = Field(default_factory=list)
    crews: list[VoyageUsageShareModel] = Field(default_factory=list)
    note: str = ""


class VoyageSecurityVerdictModel(BaseModel):
    """One SEC document's verdict for a member order."""
    verdict: str = "UNDETERMINED"
    decided: bool = False
    variant: str = ""
    reportRel: str = ""


class VoyageOrderEntryModel(BaseModel):
    """One member order's composed row — mirrors `VoyageOrderEntry.to_dict()`.

    `qaVerdict: None` is "no QA report exists", distinct from `UNDETERMINED`;
    `acBucket: None` is "no criteria and no results"; `usageTokens: None` is
    "no usage record", never zero spend.
    """
    orderId: str
    title: str = ""
    orderType: str = ""
    location: str = ""
    found: bool = False
    status: str = ""
    statusSource: str = ""
    qaReportPresent: bool = False
    qaVerdict: Optional[str] = None
    qaDecided: bool = False
    qaReportRel: str = ""
    qaBlockingDefects: int = 0
    acBucket: Optional[str] = None
    acTotal: int = 0
    acRecorded: int = 0
    acMet: int = 0
    acNotRecorded: int = 0
    acConflicted: int = 0
    security: list[VoyageSecurityVerdictModel] = Field(default_factory=list)
    usageTokens: Optional[int] = None
    usageCostUsd: Optional[float] = None


class VoyageNarrativeModel(BaseModel):
    """A free-form `reports/voyage/*` document — LINKED by name, never parsed."""
    name: str = ""
    reportRel: str = ""
    matchedBy: str = ""
    orderId: str = ""


class VoyageReportModel(BaseModel):
    """One voyage report — mirrors `VoyageReportSummary.to_dict()`.

    `composed: false` marks an INDEX entry: the manifest was read and nothing
    else, so its empty `orders` and `null` `usage` mean "not read", not "none".
    Only a `composed: true` record (the detail route) makes absence a finding.
    """
    voyageId: str
    title: str = ""
    branch: str = ""
    status: str = ""
    prNumber: Optional[int] = None
    merged: Optional[bool] = None
    startedDate: str = ""
    completedDate: str = ""
    orderIds: list[str] = Field(default_factory=list)
    qaSummaries: list[QAReportModel] = Field(default_factory=list)
    acRollups: list[ACOrderRollupModel] = Field(default_factory=list)
    usage: Optional[VoyageUsageModel] = None
    parseNotes: list[str] = Field(default_factory=list)
    project: str = ""
    location: str = ""
    prUrl: str = ""
    mergedAt: str = ""
    createdAt: str = ""
    manifestRel: str = ""
    composed: bool = False
    orders: list[VoyageOrderEntryModel] = Field(default_factory=list)
    narratives: list[VoyageNarrativeModel] = Field(default_factory=list)
    qaVerdictCounts: dict[str, int] = Field(default_factory=dict)
    acBucketCounts: dict[str, int] = Field(default_factory=dict)
    #: Added by the Hub, like `QAReportModel.workspaceId`.
    workspaceId: str = ""


class SecurityOtherDocumentModel(BaseModel):
    """A one-off document under `reports/security/` that is not a report type.

    `SECURITY-AUDIT-*.md`, `THREAT-MODEL-*.md`: named so a surface can say they
    exist, and deliberately not parsed — there is no shape to parse.
    """
    name: str
    workspaceId: str = ""


class SecurityReportList(BaseModel):
    """`GET /api/v1/reports/security` — per-order SEC verdicts, bounded.

    `parseCoverage` and `verdictCounts` describe exactly the documents in
    `reports` (never a larger set the caller did not receive), and count
    DOCUMENTS, not orders — an order can carry several. `available` is how many
    SEC documents the scanned workspaces hold.

    Scanner runs are NOT here, and nothing here is computed from them: see
    `ScannerRunList`.
    """
    reports: list[SecurityReportModel] = Field(default_factory=list)
    parseCoverage: ParseCoverageModel = Field(default_factory=ParseCoverageModel)
    #: Verdict token -> number of returned documents carrying it, UNDETERMINED
    #: included under its own key.
    verdictCounts: dict[str, int] = Field(default_factory=dict)
    otherDocuments: list[SecurityOtherDocumentModel] = Field(default_factory=list)
    workspaceId: Optional[str] = None
    limit: int = 0
    returned: int = 0
    available: int = 0
    workspaces: list[str] = Field(default_factory=list)


class SecurityOrderReports(BaseModel):
    """`GET /api/v1/reports/security/{order_id}` — every SEC document for one order.

    A list, not a single record, and never reduced to a winner: when a crew's
    review and an independent review disagree, both are shown.
    """
    orderId: str
    reports: list[SecurityReportModel] = Field(default_factory=list)


class ScannerRunModel(BaseModel):
    """One `REVIEW-{timestamp}.md` scanner run — mirrors `ScannerRun.to_dict()`.

    A RUN RECORD, never a risk posture. `countsTrustworthy` is always False and
    `trust` has no "trusted" value (`KNOWN-UNTRUSTED` / `UNVERIFIED`);
    `untrustedReasons` names the false-positive evidence read from the run's
    own findings. `scannerDecision` is the scanner's mechanical status line
    (any CRITICAL/HIGH => REJECTED) and is NOT a security review verdict.
    """
    runId: str
    ranAt: str = ""
    filesScanned: Optional[int] = None
    countsBySeverity: dict[str, int] = Field(default_factory=dict)
    reportName: str = ""
    reportRel: str = ""
    countsTrustworthy: bool = False
    caveat: str = ""
    trust: str = "UNVERIFIED"
    untrustedReasons: list[str] = Field(default_factory=list)
    diffTarget: str = ""
    scannerDecision: str = ""
    sampleFindings: list[SecurityFindingModel] = Field(default_factory=list)
    modified: str = ""
    size: int = 0
    truncated: bool = False
    parseNotes: list[str] = Field(default_factory=list)
    workspaceId: str = ""


class ScannerRunList(BaseModel):
    """`GET /api/v1/reports/security/scanner-runs` — runs, newest first, bounded.

    Deliberately carries NO severity total, no latest-run posture and no
    average: every count on every run is known to be unreliable, and an
    aggregate would launder that into a headline. `trustCounts` tallies runs by
    `trust` — a count of runs, not of findings.
    """
    runs: list[ScannerRunModel] = Field(default_factory=list)
    trustCounts: dict[str, int] = Field(default_factory=dict)
    workspaceId: Optional[str] = None
    limit: int = 0
    returned: int = 0
    available: int = 0
    workspaces: list[str] = Field(default_factory=list)


class VoyageReportList(BaseModel):
    """`GET /api/v1/reports/voyage` — the voyage index, newest first, bounded.

    Every entry is `composed: false` (manifest only). `available` is how many
    voyages the scanned workspaces hold; `returned` how many are in `voyages`.
    """
    voyages: list[VoyageReportModel] = Field(default_factory=list)
    workspaceId: Optional[str] = None
    limit: int = 0
    returned: int = 0
    available: int = 0
    workspaces: list[str] = Field(default_factory=list)
