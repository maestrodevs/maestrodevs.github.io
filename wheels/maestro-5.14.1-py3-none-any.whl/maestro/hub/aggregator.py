# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Hub aggregator — path-parameterised workspace state reader.

Pure read functions: no globals, no get_workspace_dir(). Designed for
the WorkspacePoller which calls these on arbitrary registered workspace roots.
"""

from __future__ import annotations

import json
import os
import subprocess
import time
from pathlib import Path
from typing import Optional, Iterable

from maestro.core.dispatcher_heartbeat import (
    dispatcher_heartbeat_age_seconds as _shared_dispatcher_heartbeat_age_seconds,
)
from maestro.hub.models import (
    ClaimedBy,
    CompletionConfig,
    CrewActivityEntry,
    CrewDetail,
    CrewState,
    IdleWatchdogConfig,
    IterationUsage,
    LeadAction,
    LeadAuditEvent,
    LeadDetail,
    LeadFindingDetail,
    LeadFindingsBySeverity,
    LeadPip,
    LeadStatus,
    ModelUsage,
    OnVoyageCompleteConfig,
    Order,
    OrderUsageDetail,
    Repo,
    UsageBucket,
    UsagePoint,
    UsageRollup,
    UsageSeriesPoint,
    Voyage,
    VoyageLink,
    VoyageOrderRollup,
    VoyagePrEntry,
    WorkspaceConfig,
    WorkspaceDetail,
    WorkspaceSummary,
    WorkspaceUsage,
)


# Crew display codenames by slot (data contract — frontend mock pins these).
# Falls back to the persona squad name (then "Crew<slot>") for slots beyond 5.
CREW_CODENAMES = {1: "Lion", 2: "Leopard", 3: "Cheetah", 4: "Hyena", 5: "Wild Dog"}


def _crew_name(slot: int) -> str:
    name = CREW_CODENAMES.get(slot)
    if name:
        return name
    try:
        from maestro import core_constants
        return core_constants.get_squad_name(slot) or f"Crew{slot}"
    except Exception:
        return f"Crew{slot}"


# Map raw order priority strings (HIGH/MEDIUM/LOW/etc) to the contract enum.
#
# BUG-MSO-2026-0711: "critical" is PRESERVED rather than collapsed into "high".
# It is the one value that overrides the queue tier, so folding it away made the
# drawer answer "HIGH" to an operator who had just set CRITICAL — the exact
# lever-says-one-thing/system-does-another failure this order exists to remove.
def _norm_priority(raw) -> Optional[str]:
    if not raw:
        return None
    p = str(raw).strip().lower()
    if p == "critical":
        return "critical"
    if p in ("high", "urgent"):
        return "high"
    if p in ("low",):
        return "low"
    if p in ("normal", "medium", "med", "default"):
        return "normal"
    return "normal"


# ---------------------------------------------------------------------------
# Low-level helpers (mirrored from fleet_monitor, parameterised by path)
# ---------------------------------------------------------------------------

def _load_json_safe(path: Path) -> Optional[dict]:
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


# ---------------------------------------------------------------------------
# BUG-MSO-2026-0360: PR-link fallback (backfill tolerance)
# ---------------------------------------------------------------------------
# Historical voyage manifests predate the dispatcher writing prNumber/prUrl at
# PR-creation time, so the Final Review bucket rendered without its PR link.
# When an ACTIVE voyage in final_review lacks prUrl, look the open PR up via
# gh — cached per (workspace, branch) with a TTL for hits AND misses, and
# offline-safe: any failure degrades to None (negative-cached) so the
# dashboard render is never blocked repeatedly. This is the one sanctioned
# non-filesystem read in this module.

_PR_FALLBACK_TTL_SECONDS = 600.0
_PR_FALLBACK_CACHE: dict[tuple[str, str], tuple[float, Optional[str]]] = {}
_PR_FALLBACK_GH_MISSING = False


def _pr_url_fallback(mso: Path, branch: str, product_repo: Optional[Path] = None) -> Optional[str]:
    """Open-PR URL for *branch* via gh, cached; None on any failure/offline.

    ``gh`` must run with cwd inside the PRODUCT repo checkout (that's where the
    git remote/branch actually live) — in solo/shared artefact mode ``mso`` is
    the artefact repo and NOT a valid git-remote-bearing checkout for this
    branch (FTR-MSO-2026-0369). *product_repo* defaults to ``mso.parent``
    (embedded mode: byte-identical to the pre-0369 behaviour).
    """
    global _PR_FALLBACK_GH_MISSING
    branch = (branch or "").replace("refs/heads/", "")
    if _PR_FALLBACK_GH_MISSING or not branch:
        return None
    key = (str(mso), branch)
    now = time.time()
    hit = _PR_FALLBACK_CACHE.get(key)
    if hit is not None and (now - hit[0]) < _PR_FALLBACK_TTL_SECONDS:
        return hit[1]
    url: Optional[str] = None
    try:
        r = subprocess.run(
            ["gh", "pr", "list", "--head", branch,
             "--state", "open", "--json", "number,url"],
            capture_output=True, text=True, timeout=5,
            cwd=str(product_repo or mso.parent))
        if r.returncode == 0 and r.stdout.strip() not in ("", "[]"):
            prs = json.loads(r.stdout)
            if prs:
                url = prs[0].get("url") or None
    except FileNotFoundError:
        _PR_FALLBACK_GH_MISSING = True  # gh not installed — stop trying
    except Exception:
        url = None
    _PR_FALLBACK_CACHE[key] = (now, url)
    return url


def _is_process_alive(pid: int) -> bool:
    if not pid or pid <= 0:
        return False
    try:
        if os.name == "nt":
            import ctypes
            PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            STILL_ACTIVE = 259
            kernel32 = ctypes.windll.kernel32
            handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
            if handle == 0:
                return False
            try:
                exit_code = ctypes.c_ulong()
                if kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code)):
                    return exit_code.value == STILL_ACTIVE
                return False
            finally:
                kernel32.CloseHandle(handle)
        else:
            os.kill(pid, 0)
            return True
    except (ProcessLookupError, PermissionError, OSError):
        return False


# BUG-MSO-2026-0639: crew statuses that claim a live process. A state.json
# carrying one is only as honest as the process it names — a crew killed
# mid-run, or one that died at launch, never writes a final state and leaves
# its last RUNNING record behind. BUG-MSO-2026-0541 taught this for the
# dispatcher (check the process, not a file someone may have stopped
# updating); crews are more numerous and far likelier to die mid-write.
_CREW_LIVE_STATUSES = frozenset({"RUNNING", "ACTIVE", "HUNG"})

# What a dead crew's record renders as. Never RUNNING (it is not), and never
# IDLE — the slot was not cleanly released, and an operator should be able to
# see that something died rather than read it as a free slot.
CREW_STALE_STATUS = "STALE"


def _hub_in_container() -> bool:
    """The same two signals ``server._is_observe_only`` reads. Inside the
    Hub's container a crew's HOST pid is invisible (BUG-MSO-2026-0405), so a
    pid check there would call every live crew dead. Duplicated rather than
    imported: ``server`` pulls in FastAPI, and this module is also read by
    callers that never install the ``[hub]`` extra."""
    if os.environ.get("MAESTRO_HUB_CONTAINERIZED", "").strip().lower() in ("1", "true", "yes", "on"):
        return True
    try:
        return os.path.exists("/.dockerenv")
    except OSError:
        return False


def _crew_pid_liveness(state: dict) -> tuple[str, Optional[str]]:
    """``("alive" | "dead" | "unverifiable", reason)`` for a crew's state.json.

    ``dead`` needs positive evidence: the recorded pid is not running, or it
    is running but its creation time differs from the ``pidCreateTime`` the
    crew recorded at launch (BUG-MSO-2026-0671) — a recycled pid, the same
    (pid, createTime) identity ``maestro.proc_identity`` gives the LEAD
    daemon and the Hub daemon. Everything the check cannot establish is
    ``unverifiable`` or ``alive``, and the caller keeps trusting the file:

      - no pid recorded, or the Hub runs in a container  -> unverifiable
      - live pid, no ``pidCreateTime`` (pre-0671 record) -> alive
      - live pid, creation time unreadable               -> alive (the
        BUG-MSO-2026-0674 F2 rule: "cannot confirm it is a different
        process" is never "it is a different process")
    """
    pid = state.get("pid")
    if isinstance(pid, float):
        pid = int(pid)
    if isinstance(pid, bool) or not isinstance(pid, int) or pid <= 0:
        return ("unverifiable", None)
    if _hub_in_container():
        return ("unverifiable", None)
    if not _is_process_alive(pid):
        return ("dead", f"recorded pid {pid} is not running")
    recorded_ct = state.get("pidCreateTime")
    if recorded_ct is None or isinstance(recorded_ct, bool):
        return ("alive", None)
    try:
        recorded_ct = int(recorded_ct)
    except (TypeError, ValueError):
        return ("alive", None)
    from maestro import proc_identity
    current_ct = proc_identity.process_create_time(pid)
    if current_ct is None or current_ct == recorded_ct:
        return ("alive", None)
    return ("dead", f"recorded pid {pid} now belongs to a different process (pid reused)")


def _classify_crew_state(state: dict) -> tuple[str, Optional[str]]:
    """``(status, stale_reason)`` — the recorded status, unless it claims a
    live process whose pid is dead, in which case ``CREW_STALE_STATUS`` and
    why. The ONE classification every crew reader here uses, so the card,
    the drawer and the crew count cannot disagree about the same slot."""
    status = state.get("status", "IDLE") or "IDLE"
    if str(status).upper() in _CREW_LIVE_STATUSES:
        liveness, reason = _crew_pid_liveness(state)
        if liveness == "dead":
            return (CREW_STALE_STATUS, reason)
    return (status, None)


# ---------------------------------------------------------------------------
# Workspace state readers (summary-level — Phase 1)
# ---------------------------------------------------------------------------

def _get_mso_dir(ws_root: Path) -> Path:
    from maestro.workspace import resolve_artefact_dir
    return resolve_artefact_dir(ws_root)


# Dispatcher heartbeat staleness ceiling (seconds). Both signals
# _dispatcher_heartbeat_age_seconds() combines are content-derived (a JSON
# field, a log line's own timestamp) rather than file mtime — see that
# function and maestro.core.dispatcher_heartbeat for why (BUG-MSO-2026-0595).
# Content survives the container PID-namespace boundary the same way an
# mtime did, which is what makes the containerized Hub reliable
# (BUG-MSO-2026-0405).
_HEARTBEAT_STALENESS_SECONDS = 360


def _dispatcher_heartbeat_age_seconds(mso: Path) -> Optional[float]:
    """Age in seconds of the freshest dispatcher heartbeat signal, or ``None``
    if neither signal is available.

    BUG-MSO-2026-0541: exposed as a NUMBER rather than being folded straight
    into a fresh/stale bool, so ``_dispatcher_state`` can distinguish "no
    heartbeat data yet" (a dispatcher that just started) from "heartbeat data
    exists and is stale" (a dispatcher whose tick loop has stalled) — only
    the latter is WEDGED.

    BUG-MSO-2026-0595: this used to derive BOTH signals from file MTIME,
    including ``logs/lifecycle.log``'s — but that log is MULTI-WRITER (crews,
    `mso voyage reconcile`, the Hub's own sweep, and the resident LEAD daemon
    all append to it), so its mtime stays permanently fresh regardless of
    whether the DISPATCHER itself is ticking, and the Hub could never observe
    a WEDGED dispatcher that ``mso status`` correctly flagged (the same
    multi-writer flaw BUG-MSO-2026-0581 fixed in
    ``maestro.core.fleet_monitor``, but only there). This is now a thin
    forwarder onto ``maestro.core.dispatcher_heartbeat`` — the ONE shared
    implementation the CLI monitor and the Hub both call, so the two surfaces
    cannot disagree about the same dispatcher's state again.
    """
    return _shared_dispatcher_heartbeat_age_seconds(mso)


def _dispatcher_heartbeat_fresh(
    mso: Path, threshold: float = _HEARTBEAT_STALENESS_SECONDS
) -> bool:
    """True when a dispatcher heartbeat signal is fresher than *threshold*.

    The dispatcher rewrites ``.mso/fleet-runner-state.json``'s ``"timestamp"``
    field on every crew-assignment change and appends a ``HEARTBEAT`` line to
    ``logs/lifecycle.log`` on a fixed cadence regardless of activity
    (BUG-MSO-2026-0595) — both signals are visible across the container
    PID-namespace boundary where the host PID is not, so a fresh heartbeat
    proves a live host dispatcher even when its PID is invisible in-container.
    Note: ``dispatcher.pid``'s mtime is NOT usable — it is written once at
    startup and goes stale while the dispatcher runs.
    """
    age = _dispatcher_heartbeat_age_seconds(mso)
    return age is not None and age <= threshold


def _dispatcher_state(mso: Path) -> str:
    """One of ``"RUNNING"``, ``"WEDGED"``, or ``"STOPPED"`` for this workspace.

    BUG-MSO-2026-0541: the previous ``_dispatcher_running`` OR'd pid-liveness
    with heartbeat-freshness — the wrong operator for a dispatcher whose
    process is alive but whose tick loop has stalled. That combination read
    as healthy (``True``) for three ticks on 2026-08-17 before anyone
    noticed. It is now its own state:

      - pid alive, heartbeat file exists AND is stale  -> WEDGED (the
        "alive but stuck" case this bug exists to catch)
      - pid alive, heartbeat fresh or not written yet   -> RUNNING (a brand
        new dispatcher hasn't ticked once yet; that is not the failure
        being guarded against, and flagging it would just be a false alarm)
      - pid dead/absent, heartbeat fresh                -> RUNNING (the
        container-safe fallback from BUG-MSO-2026-0405 — a host pid can be
        invisible inside the Hub's container PID namespace)
      - pid dead/absent, heartbeat stale or absent       -> STOPPED
      - no ``dispatcher.pid`` file at all                -> STOPPED

    FTR-MSO-2026-0498: the pause overlay then applies on top — ``"PAUSING"``
    (a live dispatcher draining for `mso pause`) and ``"PAUSED"`` (drained and
    exited). See :func:`_dispatcher_state_detail`.
    """
    return _dispatcher_state_detail(mso)[0]


def _dispatcher_state_detail(mso: Path) -> "tuple[str, str]":
    """``(state, detail)`` — :func:`_dispatcher_state` plus the pause detail.

    FTR-MSO-2026-0498: the base RUNNING/WEDGED/STOPPED verdict is overlaid
    through ``fleet_pause.overlay_dispatcher_state`` — the SAME function
    ``mso status`` calls — so the two surfaces cannot disagree about a pause.
    """
    pid_file = mso / "dispatcher.pid"
    pid = 0
    pid_alive = False
    if not pid_file.exists():
        base = "STOPPED"
    else:
        try:
            pid = int(pid_file.read_text(encoding="utf-8").strip())
        except Exception:
            pid = 0
        pid_alive = bool(pid) and _is_process_alive(pid)

        age = _dispatcher_heartbeat_age_seconds(mso)
        heartbeat_fresh = age is not None and age <= _HEARTBEAT_STALENESS_SECONDS

        if pid_alive:
            base = "WEDGED" if (age is not None and not heartbeat_fresh) else "RUNNING"
        else:
            base = "RUNNING" if heartbeat_fresh else "STOPPED"

    try:
        from maestro.core import fleet_pause
        return fleet_pause.overlay_dispatcher_state(
            base, pid_alive, mso, dispatcher_pid=pid or None)
    except Exception:
        return base, ""


def _dispatcher_running(mso: Path) -> bool:
    """Whether a dispatcher is live (RUNNING) for this workspace (container-safe).

    The Hub backend frequently runs in Docker, where ``.mso/dispatcher.pid``
    holds a HOST pid that is invisible inside the container's PID namespace — so
    a pid-liveness check alone false-negatives and hides the whole workspace in
    the UI (BUG-MSO-2026-0405). See ``_dispatcher_state`` for the full
    RUNNING / WEDGED / STOPPED breakdown this collapses to a bool.

    BUG-MSO-2026-0541: a WEDGED dispatcher now reads False here — it holds
    its PID but its tick loop is stalled, so it must not read as healthy to
    a caller that only wants a yes/no answer.

    FTR-MSO-2026-0498: a PAUSING dispatcher is alive and ticking, so it reads
    True (the dispatch endpoint must still refuse to spawn a duplicate);
    PAUSED reads False.
    """
    return _dispatcher_state(mso) in ("RUNNING", "PAUSING")


def _dispatcher_state_fields(mso: Path) -> dict:
    """``dispatcher_state`` / ``dispatcher_pause_detail`` model fields (FTR-MSO-2026-0498)."""
    try:
        state, detail = _dispatcher_state_detail(mso)
    except Exception:
        state, detail = "", ""
    return {"dispatcher_state": state, "dispatcher_pause_detail": detail}


def _count_active_voyages(mso: Path) -> int:
    voyages_dir = mso / "voyages" / "active"
    if not voyages_dir.exists():
        return 0
    count = 0
    for f in voyages_dir.glob("*.json"):
        data = _load_json_safe(f)
        if data and (data.get("status") or "").upper() not in ("AWAITING_APPROVAL", "COMPLETE"):
            count += 1
    return count


def _held_order_ids(mso: Path) -> set[str]:
    """Order IDs the dispatcher is holding (dep-held or operator-skipped).

    BUG-MSO-2026-0451: `_count_pending_orders` used to count every
    status=="PENDING" file with no exclusions at all — the same conflation
    `mso status` had (GitHub #202), just without even the dep-held carve-out
    fleet_monitor got in BUG-0349. Reuses the SAME snapshot/reader the
    dispatcher and `mso status` use — not a re-derived rule — so the Hub can
    never drift from either.
    """
    from maestro.core.dep_holds import read_dep_holds
    from maestro.core.skip_list import read_skipped_order_ids
    ids: set[str] = set()
    try:
        ids |= set(read_dep_holds(mso).keys())
    except Exception:
        pass
    try:
        ids |= read_skipped_order_ids(mso)
    except Exception:
        pass
    return ids


def _count_pending_orders(mso: Path) -> int:
    orders_dir = mso / "queues" / "orders"
    if not orders_dir.exists():
        return 0
    held_ids = _held_order_ids(mso)
    count = 0
    for f in orders_dir.glob("*.json"):
        data = _load_json_safe(f)
        if data:
            if data.get("status", "PENDING") != "PENDING":
                continue
            order_id = data.get("id") or data.get("orderId") or f.stem
            if order_id in held_ids:
                continue
            count += 1
        else:
            count += 1  # unreadable → treat as pending (mirrors fleet_monitor)
    return count


def _count_held_orders(mso: Path) -> int:
    """Orders excluded from `_count_pending_orders` because the dispatcher is
    holding them (dep-held or operator-skipped) — the Hub-card counterpart of
    fleet_monitor's `held` total (BUG-MSO-2026-0451)."""
    orders_dir = mso / "queues" / "orders"
    if not orders_dir.exists():
        return 0
    held_ids = _held_order_ids(mso)
    if not held_ids:
        return 0
    count = 0
    for f in orders_dir.glob("*.json"):
        data = _load_json_safe(f)
        if not data or data.get("status", "PENDING") != "PENDING":
            continue
        order_id = data.get("id") or data.get("orderId") or f.stem
        if order_id in held_ids:
            count += 1
    return count


def _count_active_crews(mso: Path, max_crews: int = 5) -> int:
    count = 0
    for i in range(1, max_crews + 1):
        state = _load_json_safe(mso / "crews" / f"crew{i}" / "state.json")
        if isinstance(state, dict) and state:
            # BUG-MSO-2026-0639: a dead crew's leftover RUNNING record is not
            # an active crew — this count must agree with the dispatcher's
            # heartbeat crews_busy, which was right all along.
            status, _reason = _classify_crew_state(state)
            if str(status).upper() in ("RUNNING", "ACTIVE"):
                count += 1
    return count


def _count_review_pending(mso: Path) -> int:
    review_dir = mso / "queues" / "review"
    if not review_dir.exists():
        return 0
    return len(list(review_dir.glob("*.json")))


def _get_max_crews(mso: Path) -> int:
    settings = _load_json_safe(mso / "config" / "fleet-settings.json") or {}
    return int(settings.get("maxCrews", 5))


def _compute_attention_breakdown(mso: Path, workspace_id: str):
    """FTR-MSO-2026-0487: workspace-parameterised attention rollup for *mso*.

    Builds the same cached order index ``build_workspace_detail`` uses
    (BUG-0422 — cheap on repeat polls) purely to classify order status; the
    result is discarded here (the summary card only needs the counts, not
    each Order object). Never raises — an unreadable workspace degrades to an
    all-zero breakdown, same as the other summary counters in this module.
    """
    from maestro.hub import attention
    try:
        order_index = _build_order_index(mso, workspace_id)
        return attention.compute_attention(mso, order_index)
    except Exception:
        from maestro.hub.models import AttentionBreakdown
        return AttentionBreakdown()


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def read_workspace_snapshot(ws_root: Path, id: str) -> WorkspaceSummary:
    """Read a summary-level snapshot of one registered workspace.

    Phase 1: returns WorkspaceSummary (counts only).
    Phase 2 will return full WorkspaceDetail.
    """
    mso = _get_mso_dir(ws_root)
    if not mso.is_dir():
        return offline_summary(id, str(ws_root))

    max_crews = _get_max_crews(mso)
    review_pending = _count_review_pending(mso)
    return WorkspaceSummary(
        id=id,
        name=id,
        path=str(ws_root),
        online=True,
        dispatcher_running=_dispatcher_running(mso),
        **_dispatcher_state_fields(mso),
        active_voyage_count=_count_active_voyages(mso),
        pending_order_count=_count_pending_orders(mso),
        active_crew_count=_count_active_crews(mso, max_crews),
        review_pending_count=review_pending,
        pending_review_count=review_pending,
        held_order_count=_count_held_orders(mso),
        attention=_compute_attention_breakdown(mso, id),
        lead=_lead_pip(mso),
    )


def offline_summary(acronym: str, path: str) -> WorkspaceSummary:
    """Return a WorkspaceSummary for an unreadable or missing workspace."""
    return WorkspaceSummary(
        id=acronym,
        name=acronym,
        path=path,
        online=False,
    )


# ---------------------------------------------------------------------------
# Phase 2 helpers — detail-level readers (contract-aligned)
# ---------------------------------------------------------------------------

# Maestro's on-disk order vocabulary is richer than the Hub's OrderStatus
# contract (app/types/index.ts). Map the extra statuses onto the contract set so
# the frontend renders them — without this, e.g. a running order (IN_PROGRESS)
# matched none of the frontend's RUNNING/PENDING filters and vanished from view.
_ORDER_STATUS_MAP = {
    "IN_PROGRESS": "RUNNING",
    "CLAIMED": "RUNNING",
    "DISPATCHED": "RUNNING",
    "COMPLETE_PENDING_STAGING": "COMPLETE",
    "COMPLETE_WITH_CONDITIONS": "COMPLETE",
    "RELEASE_APPROVED": "COMPLETE",
    "COMPLETED": "COMPLETE",
    "REQUEUE": "PENDING",
    "REOPENED": "PENDING",
}


def _norm_order_status(raw: Optional[str]) -> str:
    """Normalise a raw .mso order status onto the frontend OrderStatus contract."""
    s = (raw or "PENDING").strip()
    return _ORDER_STATUS_MAP.get(s.upper(), s)


def _derive_voyage_status(stored: Optional[str], member_orders: list) -> str:
    """Reflect live member-order state in the voyage status.

    The on-disk voyage `status` is often stale — e.g. PSG voyages stay at PLANNED
    after a crew starts work, so the dashboard showed an in-flight voyage as
    PLANNED even with a RUNNING order. When the stored status isn't terminal,
    surface ACTIVE if any member order is running. Completion stays owned by the
    dispatcher's gating — we never force COMPLETE here.
    """
    s = (stored or "").upper()
    if s in ("COMPLETE", "IN_REVIEW"):
        return s
    statuses = [(o.status or "").upper() for o in member_orders]
    # All members done → leave completion to the stored status / archival gating.
    if statuses and all(st == "COMPLETE" for st in statuses):
        return s or "PLANNED"
    # PLANNED means "not started". A voyage is started — and therefore ACTIVE —
    # once any member order has moved past the queue (running, complete, stalled,
    # etc.), not only while one is literally RUNNING (order files churn fast).
    not_started = {"", "PENDING", "BACKLOG", "PROPOSED", "NAV_REVIEW_PENDING"}
    started = any(st not in not_started for st in statuses)
    if started:
        return "ACTIVE"
    return s or "PLANNED"


def _apply_running_crew_voyage_status(voyages: list, crews: list) -> None:
    """Mark a voyage ACTIVE in-place when a running crew is on one of its orders.

    The crew state is the authoritative live signal: on a busy fleet the order
    files churn (IN_PROGRESS -> COMPLETE per role-phase while the crew advances)
    and the voyage JSON's stored status is often stale at PLANNED. Terminal
    statuses (COMPLETE / IN_REVIEW) are never downgraded.
    """
    running_ids = {
        c.current_order_id
        for c in crews
        if (getattr(c, "status", "") or "").upper() == "RUNNING" and c.current_order_id
    }
    if not running_ids:
        return
    for v in voyages:
        if (v.status or "").upper() in ("COMPLETE", "IN_REVIEW"):
            continue
        member_ids = {o.id for o in (v.orders or []) if o.id}
        if member_ids & running_ids:
            v.status = "ACTIVE"


def _normalise_acceptance_criteria(raw) -> list | None:
    """Give every acceptance criterion an id and a description, keeping the rest.

    FTR-MSO-2026-0622. Live artefacts carry BOTH shapes — measured across this
    workspace's own orders: 1551 bare strings and 551 dicts, the dicts also
    carrying `validationType`, `command`, `status`, `verifiedBy` and `note`.
    The frontend needs `id` + `description` to render and to merge an edit;
    every other key is none of the Hub's business and is passed through
    untouched, so an edit that round-trips a criterion cannot drop a field
    nobody modelled.

    A bare string becomes `{id, description}` — the only shape change, and an
    additive one. It happens on READ, so it reaches disk only if an operator
    actually edits that order's criteria.
    """
    if not isinstance(raw, list) or not raw:
        return None
    out = []
    for i, entry in enumerate(raw):
        if isinstance(entry, str):
            out.append({"id": f"ac-{i + 1}", "description": entry})
        elif isinstance(entry, dict):
            item = dict(entry)
            # Not setdefault(): a key that is PRESENT but empty or non-string
            # (`{"id": ""}`, `{"id": None}`) is as unusable to the drawer's
            # merge-by-id as an absent one, so replace it rather than keep it.
            cid = item.get("id")
            if not isinstance(cid, str) or not cid.strip():
                item["id"] = f"ac-{i + 1}"
            desc = item.get("description")
            if not isinstance(desc, str):
                item["description"] = "" if desc is None else str(desc)
            out.append(item)
        # Anything else (a number, a nested list) is not a criterion any
        # consumer can render — dropped rather than passed through as a shape
        # that would break the frontend's `.description` read.
    return out or None


def _derive_model_fields(data: dict, role: str, mso: Optional[Path]) -> tuple:
    """BUG-MSO-2026-0805: ``(effective_model, model_source)`` for an order.

    Delegates to ``crew.resolve_model_detail`` — the one implementation the
    dispatcher's ``resolve_model_for`` wraps — against THIS workspace's root
    and without the env layer (the Hub's env is not the dispatcher's). An
    unknown id yields ``(<the pinned id>, "invalid")``; any other failure
    yields ``(None, None)`` so one bad order never breaks the poll.

    Mapped orders are cached by file signature (_ORDER_ENTRY_CACHE), so a
    role-models.json edit reaches a LIVE order the next time its file changes
    and an archived order keeps the value first computed — acceptable, since an
    archived order's model is historical anyway.
    """
    if mso is None or not role:
        return None, None
    try:
        from maestro.core.crew import resolve_model_detail
        return resolve_model_detail(role, data, artefact_root=mso, include_env=False)
    except ValueError:
        pinned = data.get("model")
        return (pinned if isinstance(pinned, str) and pinned else None), "invalid"
    except Exception:
        return None, None


def _derive_target_repo(data: dict, mso: Optional[Path]) -> tuple:
    """BUG-MSO-2026-0805: ``(target_repo, target_repo_source)`` for an order.

    The order's own ``targetRepo`` (or a defect's ``affectedRepo``, mirroring
    the dispatcher's defect mapping) is ``"order"``. Otherwise the repo dispatch
    resolves from the project registry, via the dispatcher's own
    ``_resolve_target_repo_from_project``, is ``"project-default"``. The value
    is DERIVED for display only and is never written back onto the order.
    """
    own = data.get("targetRepo") or data.get("affectedRepo")
    if isinstance(own, str) and own:
        return own, "order"
    if mso is None:
        return None, None
    try:
        from maestro.core.fleet_runner import _resolve_target_repo_from_project
        derived = _resolve_target_repo_from_project(data, artefact_root=mso)
    except Exception:
        derived = ""
    if isinstance(derived, str) and derived:
        return derived, "project-default"
    return None, None


def _map_order(data: dict, workspace_id: str, mso: Optional[Path] = None) -> Order:
    """Map a raw .mso order JSON (camelCase) → contract Order (snake_case).

    ``mso`` (BUG-MSO-2026-0805) is the workspace's artefact root. It is optional
    so existing callers keep working; without it the derived model / target-repo
    provenance fields are left unset rather than resolved against the wrong
    (process-global) workspace.
    """
    oid = data.get("orderId") or data.get("id") or ""
    role = data.get("role") or data.get("targetRole") or ""
    target_role = data.get("targetRole")
    # BUG-MSO-2026-0741: accept the legacy `dependencies` spelling too. Every
    # dependency reader in the engine honours both (fleet_runner.
    # promote_ready_dependents, plan_dependents._depends_on, core.
    # undispatchable.order_depends_on); the Hub read only the modern key, so an
    # order gated by the legacy one showed NO dependencies in the drawer and
    # fed an empty dep list into the derived voyage phase. It also made such an
    # order indistinguishable from a genuinely dependency-free one, which is
    # precisely the distinction the undispatchable tag below now rests on.
    depends_on = data.get("dependsOn")
    if depends_on is None:
        depends_on = data.get("dependencies")
    if isinstance(depends_on, list):
        depends_on = [str(d) for d in depends_on] or None
    else:
        depends_on = None
    timeout = data.get("timeoutMinutes")
    iteration = data.get("iteration")
    max_iterations = data.get("maxIterations") or data.get("maxIters")
    # FTR-MSO-2026-0376: shared-mode claim-by-commit stamp (FTR-0374's
    # `_stamp_claim`). Absent in embedded/solo mode or an unclaimed order.
    raw_claimed_by = data.get("claimedBy")
    claimed_by = ClaimedBy(**raw_claimed_by) if isinstance(raw_claimed_by, dict) else None
    claimed_at = data.get("claimedAt")
    claimed_at = claimed_at if isinstance(claimed_at, str) else None
    # BUG-MSO-2026-0705: carry the rejection verdict onto the contract Order so
    # `attention.classify_orders` can name WHY a stranded order is stranded
    # without a second read of the same file (that module's own docstring rules
    # out extra per-order I/O, and this mapper has the data in hand already).
    rejection_headline = None
    rejection_command = None
    try:
        from maestro.core import role_rejection
        rejection_headline = role_rejection.describe_rejection(data)
        if rejection_headline:
            rejection_command = role_rejection.retry_command(oid, data)
    except Exception:
        rejection_headline = None
        rejection_command = None
    target_repo, target_repo_source = _derive_target_repo(data, mso)
    effective_model, model_source = _derive_model_fields(data, target_role or role, mso)
    pinned_model = data.get("model")
    return Order(
        id=oid,
        title=data.get("title", "") or "",
        description=data.get("description"),
        status=_norm_order_status(data.get("status")),
        role=role,
        target_role=target_role,
        voyage_id=data.get("voyageId"),
        workspace_id=workspace_id,
        priority=_norm_priority(data.get("priority")),
        created_at=data.get("createdAt", "") or "",
        updated_at=data.get("updatedAt"),
        started_at=data.get("startedAt"),
        completed_at=data.get("completedAt"),
        depends_on=depends_on,
        role_sequence=data.get("roleSequence", []) or [],
        acceptance_criteria=_normalise_acceptance_criteria(
            data.get("acceptanceCriteria")),
        timeout_minutes=int(timeout) if isinstance(timeout, (int, float)) else None,
        iteration=int(iteration) if isinstance(iteration, (int, float)) else None,
        max_iterations=int(max_iterations) if isinstance(max_iterations, (int, float)) else None,
        target_repo=target_repo,
        target_repo_source=target_repo_source,
        model=pinned_model if isinstance(pinned_model, str) and pinned_model else None,
        effective_model=effective_model,
        model_source=model_source,
        claimedBy=claimed_by,
        claimedAt=claimed_at,
        # BUG-MSO-2026-0703: carried through so `attention.classify_orders` can
        # surface the recovery step on a stranded order without re-reading the
        # JSON it just parsed.
        operator_note=(data.get("operatorNote")
                       if isinstance(data.get("operatorNote"), str) else None),
        rejection_headline=rejection_headline,
        rejection_command=rejection_command,
    )


# BUG-MSO-2026-0422: parsed-order cache keyed by absolute path -> ((mtime_ns,
# size), mapped Order). The poller rebuilds the order index on every tick, and a
# mature workspace is overwhelmingly ARCHIVE: MSO carries 416 files in
# orders/complete against 7 live queue files. Re-reading and re-parsing all of
# them each tick made a single poll take minutes over a Docker bind-mount, so the
# Hub's snapshot ran ~10+ minutes stale and short-lived crews never appeared at
# all. Stat-ing via os.scandir (dirent-backed, far cheaper than read+parse) and
# reusing unchanged entries collapses the steady-state cost.
#
# Correctness: the key includes size AND nanosecond mtime, so any in-place edit
# to a live order (PENDING -> IN_PROGRESS) invalidates its entry. Entries are
# keyed by path, so a file's cache line is simply replaced when it changes.
_ORDER_ENTRY_CACHE: dict[str, tuple[tuple[int, int], Order]] = {}
_ORDER_ENTRY_CACHE_MAX = 20000

# Tier-1 archive cache: absolute orders/complete path -> ((dir mtime_ns, entry
# count), that directory's contribution to the order index). Lets a poll skip
# per-file stats entirely for the append-only archive. See the comment in
# _build_order_index for why this is NOT applied to the live queue directories.
_ARCHIVE_DIR_CACHE: dict[str, tuple[tuple[int, int], dict[str, Order], float]] = {}
_ARCHIVE_CACHE_TTL_SECONDS = 300.0


def _prune_order_entry_cache() -> None:
    """Drop the cache wholesale if it exceeds the ceiling (cheap, rare)."""
    if len(_ORDER_ENTRY_CACHE) > _ORDER_ENTRY_CACHE_MAX:
        _ORDER_ENTRY_CACHE.clear()


def _build_order_index(mso: Path, workspace_id: str) -> dict[str, Order]:
    """Index every discoverable order JSON by id (queues + active + complete).

    Live queue/active copies win over archived complete copies when ids collide.
    """
    _prune_order_entry_cache()
    index: dict[str, Order] = {}
    # complete first (lowest precedence), then active, then live queues (highest)
    search_dirs = [
        mso / "orders" / "complete",
        mso / "orders" / "active",
        mso / "queues" / "orders",
        mso / "queues" / "bugs",
        mso / "queues" / "security",
        mso / "queues" / "review",
        mso / "queues" / "requests",
        mso / "queues" / "escalations",
    ]
    for d in search_dirs:
        # Tier 1 — archive short-circuit. orders/complete is the bulk of the index
        # (MSO: 416 of 423) and is append-only: the dispatcher MOVES a file in at
        # archival, which bumps the directory's own mtime. So when (dir mtime,
        # entry count) is unchanged we reuse the whole directory's contribution
        # without a single per-file stat. Deliberately NOT applied to the live
        # queue dirs: an in-place status rewrite (PENDING -> IN_PROGRESS) does not
        # change the parent directory's mtime, and those are exactly the edits the
        # dashboard must show immediately. They are small (MSO: 7 files), so they
        # are fully re-stat-ed every tick.
        is_archive = d.name == "complete"
        dir_sig = None
        if is_archive:
            try:
                dstat = os.stat(d)
                dir_sig = (dstat.st_mtime_ns, len(os.listdir(d)))
            except OSError:
                dir_sig = None
            if dir_sig is not None:
                hit = _ARCHIVE_DIR_CACHE.get(str(d))
                # TTL bounds the one tier-1 blind spot: an in-place rewrite of a
                # file that STAYS in complete/ leaves the directory mtime
                # untouched. Every sanctioned path that resurrects an archived
                # order MOVES the file (mso order retry, the BUG-0294 ledger
                # self-heal), which does bump the mtime — but a full rescan at
                # least every _ARCHIVE_CACHE_TTL_SECONDS caps worst-case staleness
                # instead of trusting that invariant forever.
                if (hit is not None and hit[0] == dir_sig
                        and (time.time() - hit[2]) < _ARCHIVE_CACHE_TTL_SECONDS):
                    index.update(hit[1])
                    continue

        try:
            entries = list(os.scandir(d))
        except OSError:
            continue  # missing/unreadable dir — same as the old .exists() guard
        dir_index: dict[str, Order] = {}
        for entry in entries:
            if not entry.name.endswith(".json") or not entry.is_file():
                continue
            # Reuse the previously mapped Order when the file is byte-identical
            # by (mtime_ns, size). Archived orders never change, so on a mature
            # workspace this skips read+parse for ~98% of the index every poll
            # (BUG-MSO-2026-0422).
            try:
                st = entry.stat()
                sig = (st.st_mtime_ns, st.st_size)
            except OSError:
                sig = None
            cached = _ORDER_ENTRY_CACHE.get(entry.path)
            if sig is not None and cached is not None and cached[0] == sig:
                order = cached[1]
            else:
                data = _load_json_safe(Path(entry.path))
                if not data:
                    continue
                order = _map_order(data, workspace_id, mso)
                if sig is not None:
                    _ORDER_ENTRY_CACHE[entry.path] = (sig, order)
            if order.id:
                index[order.id] = order
                dir_index[order.id] = order
        if is_archive and dir_sig is not None:
            _ARCHIVE_DIR_CACHE[str(d)] = (dir_sig, dir_index, time.time())
    return index


def _queue_orders(mso: Path, workspace_id: str) -> list[Order]:
    """Orders currently sitting in the live queue dirs (the workspace's worklist)."""
    out: list[Order] = []
    for d in ["orders", "bugs", "security", "review", "requests", "escalations"]:
        qd = mso / "queues" / d
        if not qd.exists():
            continue
        for f in sorted(qd.glob("*.json")):
            data = _load_json_safe(f)
            if not data:
                continue
            order = _map_order(data, workspace_id, mso)
            if order.id:
                out.append(order)
    return out


def _voyage_target_repos(data: dict, member_orders: list[Order]) -> list[str]:
    """Ordered, de-duplicated real repo set for a voyage (FTR-MSO-2026-0380).

    Mirrors ``_voyage_repo_slugs`` (maestro/core/fleet_runner.py): prefers the
    manifest's authoritative ``targetRepos`` list (written incrementally as
    each repo's PR is recorded), falls back to the keys of a ``prUrls`` map,
    and finally derives from the member orders' ``target_repo`` set for a
    voyage dispatched before either was written. ``[]`` for a legacy/
    single-repo voyage that carries none of the three — callers keep using
    the flat ``repo``/``pr_url`` fields for those.
    """
    repos: list[str] = []
    seen: set[str] = set()
    for repo in (data.get("targetRepos") or []):
        if isinstance(repo, str) and repo and repo not in seen:
            seen.add(repo)
            repos.append(repo)
    prurls = data.get("prUrls")
    if isinstance(prurls, dict):
        for repo in prurls:
            if isinstance(repo, str) and repo and repo not in seen:
                seen.add(repo)
                repos.append(repo)
    if not repos:
        for o in member_orders:
            # BUG-MSO-2026-0805: a "project-default" repo is a registry SLUG
            # derived for display, not a repos-map key the order carries —
            # never let it masquerade as a voyage's real per-repo set.
            if o.target_repo_source == "project-default":
                continue
            repo = (o.target_repo or "").strip()
            if repo and repo not in seen:
                seen.add(repo)
                repos.append(repo)
    return repos


def _voyage_pr_urls(data: dict) -> dict[str, VoyagePrEntry]:
    """Parse the manifest's ``prUrls`` map into contract entries, tolerating
    malformed/partial data (FTR-MSO-2026-0380).

    BUG-MSO-2026-0637: an entry whose work shipped under a superseding PR
    reports that PR as ``prNumber``/``prUrl`` and the original as
    ``supersededPrNumber``/``supersededPrUrl``. A single-entry map inherits the
    voyage's flat supersession (the hand-corrected manifests re-pointed only
    the flat fields). This READS the recorded fact; it derives no merge state.
    """
    from maestro.core.pr_supersession import supersession_of

    prurls = data.get("prUrls")
    if not isinstance(prurls, dict):
        return {}
    flat_sup = supersession_of(data) if len(prurls) == 1 else None
    out: dict[str, VoyagePrEntry] = {}
    for repo, entry in prurls.items():
        if isinstance(repo, str) and repo and isinstance(entry, dict):
            pr_number = entry.get("prNumber") if isinstance(entry.get("prNumber"), int) else None
            pr_url = entry.get("prUrl") if isinstance(entry.get("prUrl"), str) else None
            sup = supersession_of(entry)
            if sup is None and flat_sup is not None and pr_number in (
                    None, flat_sup["originalPrNumber"], flat_sup["supersedingPrNumber"]):
                sup = flat_sup
            if sup is not None:
                pr_number = sup["supersedingPrNumber"]
                pr_url = sup["supersedingPrUrl"] or pr_url
            out[repo] = VoyagePrEntry(
                prNumber=pr_number,
                prUrl=pr_url,
                state=entry.get("state") if isinstance(entry.get("state"), str) else None,
                mergeCommit=entry.get("mergeCommit") if isinstance(entry.get("mergeCommit"), str) else None,
                mergedAt=entry.get("mergedAt") if isinstance(entry.get("mergedAt"), str) else None,
                supersededPrNumber=sup["originalPrNumber"] if sup else None,
                supersededPrUrl=sup["originalPrUrl"] if sup else None,
            )
    return out


def _read_voyages(mso: Path, workspace_id: str, order_index: dict[str, Order],
                   product_repo: Optional[Path] = None) -> list[Voyage]:
    """Read active + complete voyage JSONs → contract Voyage list."""
    from maestro.hub import phase as phase_mod

    # FTR-MSO-2026-0351: authoritative per-order state for the derived voyage
    # phase — loaded once per workspace read, shared across all voyages.
    ledger_view = phase_mod.load_ledger_view(mso)
    archive_statuses = phase_mod.read_archive_statuses(mso)
    # BUG-MSO-2026-0699: read once per workspace, shared across all voyages.
    try:
        from maestro.core.skip_list import read_skipped_order_ids
        _skipped_ids = read_skipped_order_ids(mso)
    except Exception:
        _skipped_ids = set()

    def _dep_status(oid: str) -> str:
        fallback = order_index.get(oid)
        return phase_mod.effective_order_status(
            oid, fallback.status if fallback else None,
            ledger_view, archive_statuses)

    results: list[Voyage] = []
    # BUG-MSO-2026-0775: raw manifest + phase inputs per voyage, so the plan
    # link pass below can re-derive a planning voyage's phase once every build
    # voyage's own phase is known.
    raw_manifests: dict[str, dict] = {}
    phase_inputs: dict[str, tuple] = {}
    for state, default_status in (("active", "ACTIVE"), ("complete", "COMPLETE")):
        voyages_dir = mso / "voyages" / state
        if not voyages_dir.exists():
            continue
        for f in sorted(voyages_dir.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True):
            data = _load_json_safe(f)
            if not data:
                continue
            if (data.get("status") or "").upper() == "AWAITING_APPROVAL":
                continue

            voyage_id = data.get("voyageId") or data.get("id") or f.stem
            raw_orders = data.get("orders") or []
            statuses = data.get("orderStatuses") or {}

            member_orders: list[Order] = []
            for o in raw_orders:
                if isinstance(o, dict):
                    oid = o.get("orderId") or o.get("id") or ""
                    resolved = order_index.get(oid)
                    if resolved is not None:
                        member_orders.append(resolved)
                    elif oid:
                        member = _map_order(o, workspace_id, mso)
                        member.voyage_id = member.voyage_id or voyage_id
                        member_orders.append(member)
                else:
                    oid = str(o)
                    resolved = order_index.get(oid)
                    if resolved is not None:
                        member_orders.append(resolved)
                    else:
                        member_orders.append(Order(
                            id=oid,
                            status=(statuses.get(oid) or "PENDING"),
                            voyage_id=voyage_id,
                            workspace_id=workspace_id,
                        ))

            complete = sum(1 for o in member_orders if (o.status or "").upper() == "COMPLETE")
            status = _derive_voyage_status(data.get("status") or default_status, member_orders)

            # Feature A: repo = most common non-empty target_repo among members
            # (they share one) — kept verbatim as the back-compat flat field
            # (single-repo voyages are byte-identical). FTR-MSO-2026-0380:
            # target_repos below carries the REAL per-repo set instead of
            # collapsing a multi-repo voyage to one most-common guess.
            from collections import Counter
            # BUG-MSO-2026-0805: count only repos the orders themselves carry —
            # a derived project-default is display-only, and counting it would
            # change this flat field for every single-repo voyage.
            repo_counts = Counter(
                (o.target_repo or "").strip()
                for o in member_orders
                if (o.target_repo or "").strip()
                and o.target_repo_source != "project-default"
            )
            repo = repo_counts.most_common(1)[0][0] if repo_counts else ""
            target_repos = _voyage_target_repos(data, member_orders)
            pr_urls = _voyage_pr_urls(data)
            # BUG-MSO-2026-0637: recorded PR supersession (read, not derived).
            from maestro.core.pr_supersession import supersession_of
            voyage_sup = supersession_of(data)

            worktree = ""
            if status == "ACTIVE":
                # FTR-MSO-2026-0364: worktrees live under .mso/worktrees/<VID>/;
                # a legacy in-voyage .worktree dir wins while it still exists
                # (in-flight voyages dispatched pre-relocation). FTR-0380: this
                # is the voyage's worktree HOME, not a single checkout — a
                # multi-repo voyage (plan §4.3) nests its per-repo/per-crew
                # worktrees under it (crew<N>-<repoName>, admin-<repoName>),
                # so the fabricated path already honours that layout as-is.
                legacy_wt = mso / "voyages" / "active" / voyage_id / ".worktree"
                wt_path = legacy_wt if legacy_wt.exists() else mso / "worktrees" / voyage_id
                worktree = wt_path.as_posix()

            # FTR-MSO-2026-0351: derived phase from ledger + archive + PR state
            # — never from the stored voyage `status` (static/stale).
            # BUG-MSO-2026-0569: route through merge_metadata_trustworthy()
            # instead of an inline OR — a record claiming merged (`merged`/
            # `mergedPR`/`prMerged`/`mergeCommit` truthy) but carrying an
            # empty `mergedAt` is internally inconsistent (a real merge always
            # has a timestamp) and must not be trusted as "merged" here.
            pr_merged = phase_mod.merge_metadata_trustworthy(data)
            # BUG-MSO-2026-0394: a PR recorded on the manifest (flat fields or
            # a non-empty prUrls map) even without merge metadata — lets the
            # phase deriver tell "archived because all orders finished, PR
            # still open" apart from "archived because it actually merged".
            pr_linked = bool(
                data.get("prUrl") or data.get("pr_url") or data.get("prNumber")
                or (isinstance(pr_urls, dict) and pr_urls)
            )
            member_states = [
                phase_mod.MemberState(
                    order_id=o.id,
                    status=phase_mod.effective_order_status(
                        o.id, o.status, ledger_view, archive_statuses),
                    role=o.target_role or o.role or "",
                    depends_on=list(o.depends_on or []),
                    role_sequence=list(o.role_sequence or []),
                )
                for o in member_orders
            ]
            phase_kwargs = dict(
                pr_merged=pr_merged,
                voyage_archived=(state == "complete"),
                dep_status=_dep_status,
                # FTR-MSO-2026-0373: reconcile flags a PR closed-without-merge on
                # the manifest — surface it as needs_attention for the operator.
                closed_without_merge=bool(data.get("closedWithoutMerge")),
                pr_linked=pr_linked,
                # BUG-MSO-2026-0471: reconcile settled a closed-without-merge PR
                # as a planning-only voyage with no code deliverable — treat it
                # as merged, not stuck in final_review.
                closed_no_code_deliverable=bool(data.get("closedNoCodeDeliverable")),
                # BUG-MSO-2026-0471: an operator's hand-recorded manual
                # completion signal (mergeDetectedBy: "manual") was written but
                # never read — honour it the same as an automated PR merge.
                manually_resolved=(str(data.get("mergeDetectedBy") or "").lower() == "manual"),
                # BUG-MSO-2026-0637: name both PRs in a merged reason.
                superseded_pr=((voyage_sup["originalPrNumber"],
                                voyage_sup["supersedingPrNumber"])
                               if voyage_sup else None),
                # BUG-MSO-2026-0699: the shared deadlock classifier needs the
                # voyage id (for the reason text) and the operator skip list
                # (a skipped order never dispatches again, so it blocks its
                # dependents exactly like a STALLED one).
                voyage_id=voyage_id,
                skipped_ids=_skipped_ids,
            )
            derived = phase_mod.compute_voyage_phase(member_states, **phase_kwargs)
            raw_manifests.setdefault(voyage_id, data)
            phase_inputs.setdefault(voyage_id, (member_states, phase_kwargs))

            # BUG-MSO-2026-0360: manifests written before the dispatcher
            # recorded PR linkage lack prUrl — fall back to a cached gh
            # lookup, but only where the link is load-bearing (an active
            # voyage sitting in Final Review awaiting its PR review/merge).
            voyage_pr_url = data.get("prUrl") or data.get("pr_url")
            if voyage_sup and voyage_sup.get("supersedingPrUrl"):
                # A hand-repointed prNumber often leaves prUrl on the original.
                voyage_pr_url = voyage_sup["supersedingPrUrl"]
            if (not voyage_pr_url and state == "active"
                    and derived.phase == phase_mod.PHASE_FINAL_REVIEW):
                voyage_pr_url = _pr_url_fallback(
                    mso, data.get("branch") or data.get("voyageBranch") or "",
                    product_repo)

            # BUG-MSO-2026-0394: flat sibling to pr_url. Ambiguous (left None)
            # for a genuine multi-repo voyage with >1 PR linked via prUrls —
            # only a single-repo prUrls-only manifest gets the fallback below.
            voyage_pr_number = data.get("prNumber")
            if not isinstance(voyage_pr_number, int):
                raw_pr_number = data.get("pr_number")
                voyage_pr_number = raw_pr_number if isinstance(raw_pr_number, int) else None
            if voyage_pr_number is None and len(pr_urls) == 1:
                (_only_pr_entry,) = pr_urls.values()
                voyage_pr_number = _only_pr_entry.prNumber
            if voyage_sup:
                voyage_pr_number = voyage_sup["supersedingPrNumber"]

            results.append(Voyage(
                id=voyage_id,
                title=data.get("title", "") or "",
                status=status,
                branch=data.get("branch") or data.get("voyageBranch") or "",
                order_count=len(member_orders),
                complete_count=complete,
                orders=member_orders or None,
                created_at=data.get("createdAt", "") or "",
                pr_url=voyage_pr_url,
                pr_number=voyage_pr_number,
                workspace_id=workspace_id,
                repo=repo,
                worktree=worktree,
                phase=derived.phase,
                phaseReason=derived.reason,
                rollup=VoyageOrderRollup(**derived.rollup),
                targetRepos=target_repos,
                prUrls=pr_urls,
                supersededPrNumber=voyage_sup["originalPrNumber"] if voyage_sup else None,
                supersededPrUrl=voyage_sup["originalPrUrl"] if voyage_sup else None,
                supersessionNote=voyage_sup["note"] if voyage_sup else None,
            ))
    _apply_plan_links(results, raw_manifests, phase_inputs, order_index)
    return results


def _crew_model_fields(data: dict) -> tuple[Optional[str], Optional[str]]:
    """``(model, model_label)`` from a crew's state.json — FTR-MSO-2026-0796.

    The model id is whatever crew.py resolved and wrote; the Hub never
    re-derives it. The label comes from ``core_constants.get_model_label``,
    the same helper ``mso status`` uses. A missing, empty, non-string or
    ``"-"`` (the IDLE-reset placeholder) value is ``None`` — never ``""``.
    """
    raw = data.get("model")
    if not isinstance(raw, str):
        return None, None
    model = raw.strip()
    if not model or model == "-":
        return None, None
    try:
        from maestro.core_constants import get_model_label
        label = get_model_label(model) or None
    except Exception:
        label = None
    return model, label


def _apply_plan_links(results: list[Voyage], raw_manifests: dict[str, dict],
                      phase_inputs: dict[str, tuple],
                      order_index: dict[str, Order]) -> None:
    """Fill planOrder / planVoyage / buildVoyages and re-derive planning phases.

    BUG-MSO-2026-0775. Links are read in BOTH directions through the one
    shared reader, ``plan_links.plan_link_index``. A build voyage that names
    only ``planOrder`` (the plan order carried no voyage when it was written by
    hand) still resolves its planning voyage from that order's ``voyageId``.
    A planning voyage's phase is recomputed with its build voyages' phases, so
    one whose plan is still being built reads ``underway`` rather than
    "archived" or "no build orders were filed". Best-effort: a failure here
    leaves the voyages exactly as the main pass derived them.
    """
    from maestro.core import plan_links
    from maestro.hub import phase as phase_mod

    try:
        by_id = {v.id: v for v in results}
        index = plan_links.plan_link_index(raw_manifests)

        def _link(vid: str) -> VoyageLink:
            v = by_id.get(vid)
            if v is None:
                return VoyageLink(id=vid, found=False)
            return VoyageLink(id=v.id, title=v.title, status=v.status,
                              phase=v.phase, pr_url=v.pr_url,
                              pr_number=v.pr_number)

        base_phase = {v.id: v.phase for v in results}
        for v in results:
            data = raw_manifests.get(v.id) or {}
            plan_order = str(data.get(plan_links.PLAN_ORDER_FIELD) or "").strip()
            v.planOrder = plan_order or None
            plan_vid = plan_links.plan_voyage_of(v.id, raw_manifests, index)
            if not plan_vid and plan_order:
                plan_ord = order_index.get(plan_order)
                plan_vid = (plan_ord.voyage_id or "") if plan_ord else ""
            if plan_vid and plan_vid != v.id:
                v.planVoyage = _link(plan_vid)

        for v in results:
            build_ids = index.get(v.id) or []
            if not build_ids:
                continue
            v.buildVoyages = [_link(bid) for bid in build_ids]
            inputs = phase_inputs.get(v.id)
            builds = plan_links.build_voyage_phases(build_ids, base_phase)
            if inputs is None or not builds:
                continue
            member_states, kwargs = inputs
            derived = phase_mod.compute_voyage_phase(
                member_states, build_voyages=builds, **kwargs)
            v.phase = derived.phase
            v.phaseReason = derived.reason
    except Exception:   # noqa: BLE001 - decoration must never break the board
        return


def _read_one_crew(mso: Path, slot: int) -> CrewState:
    """Read state.json for one crew slot; returns IDLE CrewState if missing."""
    name = _crew_name(slot)
    state_file = mso / "crews" / f"crew{slot}" / "state.json"
    data = _load_json_safe(state_file)
    if not data:
        return CrewState(slot=slot, name=name, status="IDLE")

    activity_age: Optional[int] = None
    activity_file = mso / "crews" / f"crew{slot}" / "activity.txt"
    if activity_file.exists():
        try:
            if activity_file.read_text(encoding="utf-8").strip():
                activity_age = int(time.time() - activity_file.stat().st_mtime)
        except Exception:
            pass

    def _int_or_none(v):
        return int(v) if isinstance(v, (int, float)) else None

    model, model_label = _crew_model_fields(data)
    recorded_order_id = data.get("orderId") or data.get("currentOrderId") or None
    status, stale_reason = _classify_crew_state(data)
    if status == CREW_STALE_STATUS:
        # BUG-MSO-2026-0639: the process this record names is dead. Nothing
        # in it describes current work — not the order (which another crew
        # may since have finished, BUG-MSO-2026-0657 F4), not the role, and
        # not the turn/iteration/timeout counters, which would report motion
        # where there is none. activity_age_seconds stays: it truthfully says
        # how long ago the slot last did anything.
        return CrewState(
            slot=slot,
            name=name,
            status=status,
            activity_age_seconds=activity_age,
            pid=_int_or_none(data.get("pid")),
            session_id=data.get("claudeSessionId") or data.get("sessionId") or None,
            maestro_session_id=data.get("maestroSessionId") or None,
            stale_order_id=recorded_order_id,
            stale_reason=stale_reason,
        )

    return CrewState(
        slot=slot,
        name=name,
        status=status,
        role=data.get("role") or None,
        current_order_id=recorded_order_id,
        current_order_title=data.get("orderTitle") or data.get("currentOrderTitle") or None,
        iteration=_int_or_none(data.get("iteration")),
        max_iterations=_int_or_none(data.get("maxIterations")),
        live_turn=_int_or_none(data.get("liveTurn")),
        max_turns=_int_or_none(data.get("maxTurns")),
        timeout_minutes=_int_or_none(data.get("timeoutMinutes")),  # BUG-MSO-2026-0698
        model=model,                                                # FTR-MSO-2026-0796
        model_label=model_label,
        total_tokens=_int_or_none(data.get("totalTokens")),
        activity_age_seconds=activity_age,
        pid=_int_or_none(data.get("pid")),
        session_id=data.get("claudeSessionId") or data.get("sessionId") or None,
        maestro_session_id=data.get("maestroSessionId") or None,
    )


def _read_crews(mso: Path, max_crews: int = 5) -> list[CrewState]:
    """Read crew state for all slots (1..max_crews)."""
    return [_read_one_crew(mso, i) for i in range(1, max_crews + 1)]


def _read_queue_summary(mso: Path) -> dict[str, int]:
    """Counts per queue dir (Record<string,number> for the frontend)."""
    queues = mso / "queues"
    summary: dict[str, int] = {}
    if not queues.exists():
        return summary
    for d in sorted(p for p in queues.iterdir() if p.is_dir()):
        n = len(list(d.glob("*.json")))
        if n:
            summary[d.name] = n
    return summary


def _resolve_persona_id(mso: Path) -> str:
    """The persona id the engine will use for this workspace (PLAN-0792 S7).

    FTR-MSO-2026-0801: this used to read ``workspace.json``'s ``persona`` key,
    which no engine code reads, and fall back to ``"nautical"``, which is not
    the resolver's default either. It now runs the persona resolver itself,
    against the workspace persona file ``settings_core`` writes (the path
    ``mso settings set persona`` targets, product root in solo/shared mode).
    Uncached and cwd-free, so one Hub process serves every workspace correctly.
    """
    try:
        from maestro.core import settings_core
        from maestro.personas import resolver

        ws_file = settings_core._persona_path(mso, settings_core.SCOPE_WORKSPACE)
        return resolver.resolve_with_workspace_file(ws_file).id
    except Exception:
        return "default"


def _read_config(mso: Path, workspace_id: str) -> tuple[WorkspaceConfig, Optional[str], Optional[str]]:
    """Read workspace.json + gates.json → (WorkspaceConfig, persona, project).

    FTR-MSO-2026-0328: exposes all per-workspace dispatch defaults so the Hub
    drawer can show real values instead of hardcoded mocks.  Fields absent from
    workspace.json are returned as None (frontend renders "using default").
    """
    ws = _load_json_safe(mso / "config" / "workspace.json") or {}

    persona = _resolve_persona_id(mso)
    project = ws.get("project") or workspace_id

    # BUG-MSO-2026-0800: the dispatch.* keys are what `mso dispatch` and the Hub's
    # Dispatch honour; they win over the older top-level keys shown here before.
    dispatch_cfg = ws.get("dispatch") if isinstance(ws.get("dispatch"), dict) else {}

    max_crews = dispatch_cfg.get("maxCrews", ws.get("maxCrews"))
    if max_crews is None:
        # fall back to fleet-settings.json if present (legacy)
        fleet = _load_json_safe(mso / "config" / "fleet-settings.json") or {}
        max_crews = fleet.get("maxCrews")
    max_crews = int(max_crews) if isinstance(max_crews, (int, float)) else None

    def _int_opt(v) -> Optional[int]:
        return int(v) if isinstance(v, (int, float)) else None

    completion_cfg = None
    raw_completion = ws.get("completion")
    role_timeouts: Optional[dict[str, int]] = None
    if isinstance(raw_completion, dict):
        idle = raw_completion.get("idleWatchdog")
        ovc = raw_completion.get("onVoyageComplete")
        rt = raw_completion.get("roleTimeouts")
        if isinstance(rt, dict):
            role_timeouts = {str(k): int(v) for k, v in rt.items() if isinstance(v, (int, float))}
        completion_cfg = CompletionConfig(
            idleWatchdog=IdleWatchdogConfig(
                enabled=bool(idle.get("enabled", False)),
                idleMinutes=int(idle.get("idleMinutes", 30)),
                action=str(idle.get("action", "none")),
            ) if isinstance(idle, dict) else None,
            onVoyageComplete=OnVoyageCompleteConfig(
                archiveVoyageOnMerge=bool(ovc.get("archiveVoyageOnMerge", True)),
                archiveOrders=bool(ovc.get("archiveOrders", True)),
                autoRelease=bool(ovc.get("autoRelease", False)),
            ) if isinstance(ovc, dict) else None,
            roleTimeouts=role_timeouts,
        )

    # Workspace-level dispatch defaults (all optional; absent → None → "using default" in UI).
    # maxIterations / autoDispatch / tokenDailyCap are no longer read: no engine
    # reader ever existed for them (BUG-MSO-2026-0800).
    max_turns = _int_opt(dispatch_cfg.get("maxTurns", ws.get("maxTurns")))
    timeout_minutes = _int_opt(dispatch_cfg.get("timeoutMinutes", ws.get("timeoutMinutes")))

    # requirePlanReview: is the planning-exit gate on? FTR-MSO-2026-0427 — resolve
    # through the gate engine so a workspace that configures the planning gate the
    # v2 way (transitions: {"PLN->BLD": ...}) reports it too, not just the v1
    # post_nav_review key. Stays None when no gate governs that transition at all.
    require_plan_review: Optional[bool] = None
    gates = _load_json_safe(mso / "config" / "gates.json") or {}
    try:
        from maestro.core.gates import resolve_transition_gate

        _matched, plan_gate = resolve_transition_gate(gates, "PLN", "BLD")
    except Exception:
        plan_gate = gates.get("post_nav_review")
    if isinstance(plan_gate, dict):
        require_plan_review = bool(plan_gate.get("enabled", False))

    config = WorkspaceConfig(
        persona=persona,
        project=project,
        maxCrews=max_crews,
        completion=completion_cfg,
        maxTurns=max_turns,
        timeoutMinutes=timeout_minutes,
        requirePlanReview=require_plan_review,
    )
    return config, persona, project


def _read_repos(mso: Path, product_repo: Path, workspace_id: str) -> list[Repo]:
    """Read managed repos from workspace config, else a sensible default.

    The fallback path is the PRODUCT repo (where source code actually lives),
    never the artefact root — in solo/shared mode those are different repos.
    """
    ws = _load_json_safe(mso / "config" / "workspace.json") or {}
    raw = ws.get("managedRepos") or ws.get("repos") or []
    repos: list[Repo] = []
    if isinstance(raw, list):
        for r in raw:
            if isinstance(r, dict):
                name = r.get("name") or r.get("id") or ""
                path = r.get("path") or ""
                repos.append(Repo(
                    id=r.get("id") or name or path,
                    name=name or (Path(path).name if path else workspace_id),
                    path=path or str(product_repo),
                    default_branch=r.get("defaultBranch") or r.get("default_branch") or "main",
                ))
            elif isinstance(r, str):
                repos.append(Repo(id=r, name=Path(r).name, path=r, default_branch="main"))
    return repos


def _max_crews(mso: Path) -> int:
    ws = _load_json_safe(mso / "config" / "workspace.json") or {}
    mc = ws.get("maxCrews")
    if isinstance(mc, (int, float)):
        return int(mc)
    return _get_max_crews(mso)


def _artefact_mode(mso: Path) -> str:
    """Workspace artefact mode: 'embedded' | 'solo' | 'shared' (FTR-MSO-2026-0376).

    Reads workspace.json's `artefacts.mode` key directly from *mso* rather
    than calling `maestro.workspace.get_artefact_mode()`, which resolves via
    `MAESTRO_DIR`/cwd and would be wrong when the Hub aggregates several
    workspaces in one process (this module stays path-parameterised — see
    module docstring). Mirrors `maestro.workspace.ARTEFACT_MODES` semantics:
    absent/unreadable/unrecognised all mean "embedded".
    """
    ws = _load_json_safe(mso / "config" / "workspace.json") or {}
    block = ws.get("artefacts")
    mode = block.get("mode") if isinstance(block, dict) else None
    return mode if mode in ("solo", "shared") else "embedded"


def _dispatch_command(product_repo: Path, max_crews: int) -> str:
    """The exact `mso dispatch` command for *product_repo* (FTR-MSO-2026-0492 §4.4).

    Built from the same *product_repo* the poller already resolved via
    `product_repo_for_entry` (the checkout that owns branches/PRs) — NOT
    `ws_root`/`WorkspaceDetail.path`, which is the artefact parent and, in
    solo mode, an artefact repo with no source checkout to `cd` into. The
    frontend renders this verbatim and never assembles it itself.
    """
    return f"cd {product_repo}\nmso dispatch --max-crews {max_crews}"


def _dispatcher_pid(mso: Path) -> Optional[int]:
    pid_file = mso / "dispatcher.pid"
    if not pid_file.exists():
        return None
    try:
        return int(pid_file.read_text(encoding="utf-8").strip())
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Usage aggregation (FTR-MSO-2026-0330)
# ---------------------------------------------------------------------------

def _read_usage_stats(mso: Path, history_days: int = 14) -> WorkspaceUsage:
    """Aggregate token usage from .mso/usage/orders/*.json.

    Builds a daily history series (newest-last, up to history_days entries)
    suitable for the frontend sparkline.  Returns a zero WorkspaceUsage when
    the usage directory is absent or unreadable.
    """
    usage_dir = mso / "usage" / "orders"
    if not usage_dir.is_dir():
        return WorkspaceUsage()

    total_tokens: int = 0
    total_cost: float = 0.0
    order_count: int = 0
    # bucket: date-string → (tokens, cost)
    buckets: dict[str, tuple[int, float]] = {}

    for f in usage_dir.glob("*.json"):
        data = _load_json_safe(f)
        if not data:
            continue
        tokens = data.get("total_tokens") or 0
        cost = data.get("estimated_cost_usd") or 0.0
        if not isinstance(tokens, (int, float)):
            tokens = 0
        if not isinstance(cost, (int, float)):
            cost = 0.0
        tokens = int(tokens)
        cost = float(cost)

        total_tokens += tokens
        total_cost += cost
        order_count += 1

        ts = data.get("timestamp") or ""
        date_key = ts[:10] if len(ts) >= 10 else "unknown"
        prev_t, prev_c = buckets.get(date_key, (0, 0.0))
        buckets[date_key] = (prev_t + tokens, prev_c + cost)

    # Build sorted history series, capped to history_days (skipping "unknown")
    sorted_dates = sorted(
        (d for d in buckets if d != "unknown"),
        reverse=False,
    )[-history_days:]
    history = [
        UsagePoint(date=d, tokens=buckets[d][0], cost_usd=round(buckets[d][1], 4))
        for d in sorted_dates
    ]

    return WorkspaceUsage(
        total_tokens=total_tokens,
        estimated_cost_usd=round(total_cost, 4),
        order_count=order_count,
        history=history,
    )


# ---------------------------------------------------------------------------
# Phase 2 public API
# ---------------------------------------------------------------------------

def build_workspace_detail(ws_root: Path, workspace_id: str,
                            product_repo: Optional[Path] = None) -> WorkspaceDetail:
    """Build a full WorkspaceDetail matching the frontend contract.

    *ws_root* is the artefact root's parent (already resolved via
    ``workspace.artefact_parent_for_entry`` by the caller — this module stays
    path-parameterised and never reads the registry itself for this call).
    *product_repo* is the checkout that owns branches/PRs; defaults to
    *ws_root* (embedded mode: the two are the same directory).

    Returns an offline detail (no 500) when .mso/ is missing or unreadable.
    """
    product_repo = product_repo or ws_root
    try:
        mso = _get_mso_dir(ws_root)
        if not mso.is_dir():
            return offline_detail(workspace_id, str(ws_root))

        max_crews = _max_crews(mso)
        config, persona, project = _read_config(mso, workspace_id)
        order_index = _build_order_index(mso, workspace_id)
        voyages = _read_voyages(mso, workspace_id, order_index, product_repo)
        crews = _read_crews(mso, max_crews)
        orders = _queue_orders(mso, workspace_id)
        queue_summary = _read_queue_summary(mso)
        usage = _read_usage_stats(mso)

        # FTR-MSO-2026-0487: classify once from the order index, then stamp
        # BOTH Order collections built from this workspace's data — order_index
        # (feeds voyages' member orders, above) and orders (the live-queue
        # worklist, above) are independently-built Order objects for the same
        # underlying files, so each needs its own tagging pass.
        from maestro.hub import attention
        # BUG-MSO-2026-0743: read the skip list ONCE and use it for both the
        # (single-valued, overwritable) attention tag and the orthogonal
        # is_skipped fact — two reads of the same file per poll cycle is not
        # the way to fix a bug about two derivations disagreeing.
        skip_records = attention.read_skip_records(mso)
        attention_tags = attention.classify_orders(mso, order_index, skipped=skip_records)
        attention.apply_attention(order_index.values(), attention_tags)
        attention.apply_attention(orders, attention_tags)
        attention.apply_skip_state(order_index.values(), skip_records)
        attention.apply_skip_state(orders, skip_records)
        attention_breakdown = attention.breakdown_from_tags(attention_tags)

        # A voyage with a live crew running one of its orders is ACTIVE — the
        # crew state is the authoritative "in-flight" signal. On a busy fleet the
        # order FILES churn (an order flips IN_PROGRESS -> COMPLETE per role-phase
        # while the crew advances to the next role), and the voyage JSON's own
        # status is often left stale at PLANNED. Reconcile against running crews.
        _apply_running_crew_voyage_status(voyages, crews)

        return WorkspaceDetail(
            id=workspace_id,
            name=workspace_id,
            path=str(ws_root),
            dispatcher_running=_dispatcher_running(mso),
            **_dispatcher_state_fields(mso),
            active_crew_count=_count_active_crews(mso, max_crews),
            active_voyage_count=_count_active_voyages(mso),
            pending_review_count=_count_review_pending(mso),
            pending_order_count=_count_pending_orders(mso),
            held_order_count=_count_held_orders(mso),
            attention=attention_breakdown,
            persona=persona,
            project=project,
            config=config,
            voyages=voyages,
            crews=crews,
            queue_summary=queue_summary,
            orders=orders,
            repos=_read_repos(mso, product_repo, workspace_id),
            usage=usage,
            artefactMode=_artefact_mode(mso),
            dispatchCommand=_dispatch_command(product_repo, max_crews),
        )
    except Exception:
        return offline_detail(workspace_id, str(ws_root))


def build_crew_list(ws_root: Path, workspace_id: str) -> list[CrewState]:
    """Build a bare CrewState[] (always max_crews slots, IDLE for non-running)."""
    try:
        mso = _get_mso_dir(ws_root)
        if mso.is_dir():
            return _read_crews(mso, _max_crews(mso))
    except Exception:
        pass
    return [CrewState(slot=i, name=_crew_name(i)) for i in range(1, 6)]


# ---------------------------------------------------------------------------
# LEAD sub-agent surfaces (FTR-MSO-2026-0539, PLAN-PLN-MSO-2026-0504 §13)
# ---------------------------------------------------------------------------

# Mirrors the "requires a {tiers} licence" phrasing `auth.require_tier` and
# `hub/server.py`'s CONTROL_TIER_MESSAGE already use, so an operator sees the
# same sentence shape everywhere a tier gate refuses them. LEAD_AGENT_TIERS
# is one tier lower than HUB_TIERS (Pro included), so the message is not
# reused verbatim from CONTROL_TIER_MESSAGE.
_LEAD_TIER_MESSAGE = "The resident LEAD agent requires a Pro, Team or Enterprise licence."


def _findings_from_state(raw: Optional[dict]) -> LeadFindingsBySeverity:
    """Build a LeadFindingsBySeverity from the daemon state's persisted
    ``lastFindingsBySeverity`` dict — absent (daemon never ticked) or
    malformed both degrade to all-zero, never an exception."""
    raw = raw or {}
    return LeadFindingsBySeverity(
        critical=int(raw.get("critical", 0) or 0),
        high=int(raw.get("high", 0) or 0),
        medium=int(raw.get("medium", 0) or 0),
        low=int(raw.get("low", 0) or 0),
    )


def _lead_pip(mso: Path) -> LeadPip:
    """Cheap LEAD indicator for the overview page's per-card pip.

    Reads only the LEAD daemon's own persisted state (a PID stat + one small
    JSON read) — deliberately NEVER a fresh patrol pass. ``WorkspacePoller``
    calls ``read_workspace_snapshot`` for EVERY registered workspace on
    every poll tick; running a patrol pass here would be a second,
    uncontrolled cadence competing with the daemon's own heartbeat, exactly
    the duplication PLAN-PLN-MSO-2026-0504 §6's noise-control design exists
    to prevent (the daemon is the ONLY place `mso doctor` runs).
    """
    from maestro import auth
    available = auth.has_tier(auth.LEAD_AGENT_TIERS)
    try:
        from maestro.lead import daemon as _lead_daemon
        d = _lead_daemon.status(mso)
    except Exception:
        return LeadPip(available=available)
    return LeadPip(
        available=available,
        state="running" if d.get("running") else "stopped",
        findings=_findings_from_state(d.get("lastFindingsBySeverity")),
    )


def _read_last_lead_action(mso: Path) -> Optional[LeadAction]:
    """Most recent ``LEAD_ACTION`` lifecycle event, if any.

    PLAN-PLN-MSO-2026-0584 Dimension C wires the daemon's tick to
    ``execute_action`` (via ``maestro.lead.bands.dispatch_actions_for_findings``),
    so a workspace whose daemon has acted at least once now has a real line
    to find here. ``None`` still means exactly what it always meant — see
    ``LeadAction``'s docstring in ``hub/models.py``.
    """
    log = mso / "logs" / "lifecycle.log"
    if not log.exists():
        return None
    try:
        from maestro.hub.lifecycle_tail import _parse_event_type, _parse_message, _parse_timestamp
        lines = [line for line in log.read_text(encoding="utf-8").splitlines() if line.strip()]
    except Exception:
        return None
    # Bounded scan — a LEAD_ACTION line, if present at all, is recent; there
    # is no need to walk an entire multi-thousand-line log for it.
    for line in reversed(lines[-500:]):
        if _parse_event_type(line) == "LEAD_ACTION":
            return LeadAction(
                type=_parse_event_type(line),
                detail=_parse_message(line),
                at=_parse_timestamp(line),
            )
    return None


def build_lead_status(ws_root: Path, workspace_id: str) -> LeadStatus:
    """``GET /api/v1/workspaces/{id}/lead`` — PLAN-PLN-MSO-2026-0504 §13.

    ``state``/``heartbeatAgeSeconds``/``findings`` all come from the LEAD
    daemon's own persisted record (``maestro.lead.daemon.status`` /
    ``maestro.lead.agent.run_once``'s ``state.json``) — never a fresh patrol
    pass from the Hub itself (see ``_lead_pip`` above for why). A daemon
    that has never completed a tick reports ``state="stopped"`` (or
    "running" if the process is up but hasn't ticked yet),
    ``heartbeatAgeSeconds=None``, and all-zero findings — never a crash.
    """
    from maestro import auth
    from maestro.lead import daemon as _lead_daemon

    mso = _get_mso_dir(ws_root)
    available = auth.has_tier(auth.LEAD_AGENT_TIERS)
    reason = None if available else _LEAD_TIER_MESSAGE

    try:
        d = _lead_daemon.status(mso)
    except Exception:
        d = {"running": False, "lastTickAt": None, "lastFindingsBySeverity": None}

    heartbeat_age: Optional[float] = None
    last_tick_at = d.get("lastTickAt")
    if last_tick_at:
        try:
            from datetime import datetime, timezone
            tick_dt = datetime.fromisoformat(last_tick_at)
            if tick_dt.tzinfo is None:
                tick_dt = tick_dt.replace(tzinfo=timezone.utc)
            heartbeat_age = max(0.0, (datetime.now(timezone.utc) - tick_dt).total_seconds())
        except Exception:
            heartbeat_age = None

    return LeadStatus(
        available=available,
        reason=reason,
        state="running" if d.get("running") else "stopped",
        heartbeatAgeSeconds=heartbeat_age,
        findings=_findings_from_state(d.get("lastFindingsBySeverity")),
        lastAction=_read_last_lead_action(mso),
        # PLAN-PLN-MSO-2026-0584 Dimension A: all sourced from
        # maestro.lead.daemon.status(), which already resolves standDown
        # from the durable config and runningVersion/installedVersion from
        # state.json / this backend's own installed maestro.__version__.
        standDown=bool(d.get("standDown", False)),
        runningVersion=d.get("runningVersion"),
        # BUG-MSO-2026-0724: what the last tick ran, alive or not — see
        # LeadStatus.lastRanVersion and maestro.lead.daemon.status().
        lastRanVersion=d.get("lastRanVersion"),
        installedVersion=d.get("installedVersion"),
        versionMismatch=bool(d.get("versionMismatch", False)),
    )


# ---------------------------------------------------------------------------
# LEAD finding detail + crew detail (FTR-MSO-2026-0577)
# ---------------------------------------------------------------------------

# LEAD_TICK / LEAD_ACTION / LEAD_FINDING / LEAD_REPORTED / LEAD_CEILING_HIT —
# exactly the event types PLAN-PLN-MSO-2026-0504 §13's audit tail names.
_LEAD_AUDIT_EVENT_TYPES = {
    "LEAD_TICK", "LEAD_ACTION", "LEAD_FINDING", "LEAD_REPORTED", "LEAD_CEILING_HIT",
    # FTR-MSO-2026-0786: daemon lifecycle lines written by maestro.lead.control
    # — each names its actor (cli / hub), so the drawer shows who started or
    # stopped the LEAD.
    "LEAD_STARTED", "LEAD_STOPPED", "LEAD_STOP_FAILED",
}


def _lead_findings_from_state(raw: Optional[list]) -> list[LeadFindingDetail]:
    """Build the drawer's finding list from ``lastFindingsDetail`` (persisted
    by ``maestro.lead.agent.run_once`` — see ``MAX_PERSISTED_FINDINGS``).

    Free-text fields are redacted here, once, at construction — never on a
    field mutated after the model exists.
    """
    from maestro.hooks.secret_patterns import redact_text
    from maestro.lead.run_verbs import verb_id_for

    out: list[LeadFindingDetail] = []
    for entry in (raw or []):
        if not isinstance(entry, dict):
            continue
        suggested = entry.get("suggestedCommand")
        note = entry.get("acknowledgedNote")
        # FTR-MSO-2026-0631: parsed against the RAW command, before
        # redact_text() below — the closed verb list is an exact-match regex
        # against real command text, never against a redacted approximation.
        # BUG-MSO-2026-0634 F8: verb_id_for() itself now guards against a
        # non-string suggestedCommand, but this try/except is the per-finding
        # backstop — a malformed entry degrades ITS OWN runnable/runVerb to
        # False/None rather than 500ing the whole detail endpoint for every
        # other finding.
        try:
            run_verb = verb_id_for(suggested) if suggested else None
        except Exception:
            run_verb = None
        out.append(LeadFindingDetail(
            checkId=entry.get("checkId") or "",
            subjectId=entry.get("subjectId") or "",
            severity=entry.get("severity") or "low",
            title=redact_text(str(entry.get("title") or "")),
            detail=redact_text(str(entry.get("detail") or "")),
            firstSeenAt=entry.get("firstSeenAt") or "",
            suggestedCommand=redact_text(str(suggested)) if suggested else None,
            scope=entry.get("scope") or "workspace",
            runnable=run_verb is not None,
            runVerb=run_verb,
            # PLAN-PLN-MSO-2026-0584 Dimension D: written by
            # maestro.lead.agent._apply_acknowledgement_detail every tick —
            # never recomputed here (same "one tick, one source" rule the
            # rest of this function already follows).
            fingerprint=entry.get("fingerprint"),
            acknowledged=bool(entry.get("acknowledged", False)),
            acknowledgedBy=entry.get("acknowledgedBy"),
            acknowledgedNote=redact_text(str(note)) if note else None,
            acknowledgedExpiresAt=entry.get("acknowledgedExpiresAt"),
        ))
    return out


def _lead_audit_tail(mso: Path, n: int = 20) -> list[LeadAuditEvent]:
    """Last *n* LEAD_* lifecycle events, newest first — parsed via the
    existing ``maestro.hub.lifecycle_tail`` helpers (no second log parser),
    mirroring ``_read_last_lead_action`` above."""
    log = mso / "logs" / "lifecycle.log"
    if not log.exists():
        return []
    try:
        from maestro.hooks.secret_patterns import redact_text
        from maestro.hub.lifecycle_tail import _parse_event_type, _parse_message, _parse_timestamp
        lines = [line for line in log.read_text(encoding="utf-8").splitlines() if line.strip()]
    except Exception:
        return []
    out: list[LeadAuditEvent] = []
    # Bounded scan from the tail — LEAD events fire at least once per
    # heartbeat, so the last few thousand lines always contain n of them
    # without walking the whole log.
    for line in reversed(lines[-5000:]):
        et = _parse_event_type(line)
        if et in _LEAD_AUDIT_EVENT_TYPES:
            out.append(LeadAuditEvent(
                type=et,
                message=redact_text(_parse_message(line)),
                at=_parse_timestamp(line),
            ))
            if len(out) >= n:
                break
    return out


def build_lead_detail(ws_root: Path, workspace_id: str, audit_limit: int = 20) -> LeadDetail:
    """``GET /api/v1/workspaces/{id}/lead/detail`` — FTR-MSO-2026-0577.

    Reads only what ``maestro.lead.agent.run_once`` already persisted to
    ``.mso/lead/state.json`` — deliberately NEVER a fresh ``mso doctor``
    pass (see ``LeadDetail``'s docstring for why: the drawer's findings must
    come from the exact same tick as the strip's counts, or the two numbers
    can silently disagree).
    """
    from maestro import auth
    from maestro.lead import daemon as _lead_daemon

    mso = _get_mso_dir(ws_root)
    available = auth.has_tier(auth.LEAD_AGENT_TIERS)
    reason = None if available else _LEAD_TIER_MESSAGE

    try:
        d = _lead_daemon.status(mso)
    except Exception:
        d = {"running": False, "lastTickAt": None}

    state = _load_json_safe(mso / "lead" / "state.json") or {}
    findings = _lead_findings_from_state(state.get("lastFindingsDetail"))

    last_tick_at = d.get("lastTickAt")
    return LeadDetail(
        available=available,
        reason=reason,
        state="running" if d.get("running") else "stopped",
        hasTicked=bool(last_tick_at),
        lastTickAt=last_tick_at,
        findings=findings,
        findingsTotal=int(state.get("lastFindingsTotal", len(findings)) or 0),
        findingsTruncated=bool(state.get("lastFindingsTruncated", False)),
        auditTail=_lead_audit_tail(mso, audit_limit),
    )


# Bound on how many activity.jsonl lines build_crew_detail reads (newest
# first). activity.jsonl grows one entry per tool call across an entire
# order's iterations — unbounded in principle, same class of risk as the
# lead findings list, so it is capped the same way.
_CREW_ACTIVITY_TAIL_LIMIT = 200

# progress.md is free text a crew appends to across iterations. Bounded by
# byte count (tail, not head — the freshest narrative is what a Captain
# opening the drawer wants) rather than line count, since crews don't write
# it in a fixed-width format.
_CREW_PROGRESS_MAX_CHARS = 100_000

# files_modified.json is written by the crew itself and has no inherent size
# limit — bounded the same way as activity.jsonl (SEC-FTR-MSO-2026-0577
# Finding 2, LOW/CWE-400) to avoid an unbounded parse/response on a
# corrupt or runaway file.
_CREW_FILES_MODIFIED_LIMIT = 500


def build_crew_detail(ws_root: Path, workspace_id: str, slot: int) -> Optional[CrewDetail]:
    """``GET /api/v1/workspaces/{id}/crews/{slot}/detail`` — FTR-MSO-2026-0577.

    Returns ``None`` when *slot* is out of the workspace's configured
    ``maxCrews`` range, or has no ``crews/crew{slot}`` directory on disk at
    all — the endpoint turns that into a clean 404. A slot that DOES have a
    directory (has run before, may be idle now) always returns a well-formed
    ``CrewDetail``, defaulting to IDLE.

    Deliberately never reads ``output_01.txt``/``output_final.txt`` (raw
    Claude transcript — unbounded, 639 KB+ on a real fleet); ``activity``
    is the structured record of the same work, bounded, newest first. Every
    free-text field is redacted via ``maestro.hooks.secret_patterns`` before
    the response model is built.
    """
    from maestro.hooks.secret_patterns import redact_text

    try:
        mso = _get_mso_dir(ws_root)
    except Exception:
        return None
    if not mso.is_dir():
        return None

    max_crews = _max_crews(mso)
    if slot < 1 or slot > max_crews:
        return None

    crew_dir = mso / "crews" / f"crew{slot}"
    if not crew_dir.is_dir():
        return None

    state = _load_json_safe(crew_dir / "state.json") or {}

    def _int_or_none(v):
        return int(v) if isinstance(v, (int, float)) else None

    activity_line = ""
    activity_txt = crew_dir / "activity.txt"
    if activity_txt.exists():
        try:
            activity_line = activity_txt.read_text(encoding="utf-8").strip()
        except Exception:
            activity_line = ""

    activity: list[CrewActivityEntry] = []
    activity_jsonl = crew_dir / "activity.jsonl"
    if activity_jsonl.exists():
        try:
            lines = [ln for ln in activity_jsonl.read_text(encoding="utf-8").splitlines() if ln.strip()]
        except Exception:
            lines = []
        for line in reversed(lines[-_CREW_ACTIVITY_TAIL_LIMIT:]):
            try:
                rec = json.loads(line)
            except Exception:
                continue
            if not isinstance(rec, dict):
                continue
            activity.append(CrewActivityEntry(
                timestamp=str(rec.get("timestamp") or ""),
                tool=str(rec.get("tool") or ""),
                action=str(rec.get("action") or ""),
                target=redact_text(str(rec.get("target") or "")),
            ))

    progress_markdown = ""
    progress_file = crew_dir / "progress.md"
    if progress_file.exists():
        try:
            raw_progress = progress_file.read_text(encoding="utf-8")
        except Exception:
            raw_progress = ""
        if len(raw_progress) > _CREW_PROGRESS_MAX_CHARS:
            raw_progress = raw_progress[-_CREW_PROGRESS_MAX_CHARS:]
        progress_markdown = redact_text(raw_progress)

    files_modified: list[str] = []
    files_modified_file = crew_dir / "files_modified.json"
    if files_modified_file.exists():
        try:
            raw_files = json.loads(files_modified_file.read_text(encoding="utf-8"))
            if isinstance(raw_files, list):
                # A file PATH can itself carry a secret (e.g. a dumped
                # `.env` or a token embedded in a filename), so this list
                # is redacted the same as every other free-text field this
                # endpoint returns (SEC-FTR-MSO-2026-0577 Finding 1, MEDIUM/
                # CWE-532) — not exempt just because it looks structured.
                files_modified = [
                    redact_text(str(x)) for x in raw_files[:_CREW_FILES_MODIFIED_LIMIT]
                ]
        except Exception:
            files_modified = []

    order_title = state.get("orderTitle") or state.get("currentOrderTitle") or ""
    model, model_label = _crew_model_fields(state)  # FTR-MSO-2026-0796
    recorded_order_id = state.get("orderId") or state.get("currentOrderId") or None

    # BUG-MSO-2026-0639: the same classification the crew card and crew count
    # use. A dead record's order, role and counters are not current work, so
    # they are withheld; the activity/progress history below stays, because
    # it is a record of what the slot did, not a claim that it is doing it.
    status, stale_reason = _classify_crew_state(state)
    stale = status == CREW_STALE_STATUS

    # BUG-MSO-2026-0713: the previous run's retained evidence directory, via the
    # ONE read-side implementation `mso doctor`'s crew check also calls, so the
    # two surfaces can never disagree about where it is.
    prev: dict = {}
    try:
        from maestro.core import crew_history
        prev = crew_history.latest_run_summary(slot, workspace_dir=mso) or {}
    except Exception:
        prev = {}

    return CrewDetail(
        slot=slot,
        name=_crew_name(slot),
        status=status,
        role=None if stale else (state.get("role") or None),
        current_order_id=None if stale else recorded_order_id,
        current_order_title=None if stale else (redact_text(order_title) or None),
        iteration=None if stale else _int_or_none(state.get("iteration")),
        max_iterations=None if stale else _int_or_none(state.get("maxIterations")),
        live_turn=None if stale else _int_or_none(state.get("liveTurn")),
        max_turns=None if stale else _int_or_none(state.get("maxTurns")),
        model=None if stale else model,                             # FTR-MSO-2026-0796
        model_label=None if stale else model_label,
        total_tokens=None if stale else _int_or_none(state.get("totalTokens")),
        stale_order_id=recorded_order_id if stale else None,
        stale_reason=stale_reason,
        activity_line=redact_text(activity_line),
        activity=activity,
        progress_markdown=progress_markdown,
        files_modified=files_modified,
        previous_run_path=(str(prev["path"]) if prev.get("path") else None),
        previous_run_order_id=(str(prev["orderId"]) if prev.get("orderId") else None),
        previous_run_role=(str(prev["role"]) if prev.get("role") else None),
        previous_run_retained_at=(
            str(prev["retainedAt"]) if prev.get("retainedAt") else None),
    )


def offline_detail(workspace_id: str, path: str) -> WorkspaceDetail:
    """Return a WorkspaceDetail for an unreadable or missing workspace."""
    return WorkspaceDetail(
        id=workspace_id,
        name=workspace_id,
        path=path,
        config=WorkspaceConfig(project=workspace_id),
        crews=[CrewState(slot=i, name=_crew_name(i)) for i in range(1, 6)],
    )


# ---------------------------------------------------------------------------
# Usage aggregation (FTR-MSO-2026-0333) — path-parameterised, no globals
# ---------------------------------------------------------------------------

def _in_date_range(timestamp: str, from_date: Optional[str], to_date: Optional[str]) -> bool:
    """Return True when the record's date falls within [from_date, to_date] (inclusive, day granularity)."""
    date = timestamp[:10] if len(timestamp) >= 10 else ""
    if not date:
        return True  # undated records always pass the filter
    if from_date and date < from_date:
        return False
    if to_date and date > to_date:
        return False
    return True


def _iter_order_usage_json(
    usage_dir: Path,
    from_date: Optional[str] = None,
    to_date: Optional[str] = None,
):
    """Yield parsed JSON usage records from *.json files, date-filtered."""
    if not usage_dir.is_dir():
        return
    for f in usage_dir.glob("*.json"):
        data = _load_json_safe(f)
        if not data:
            continue
        ts = data.get("timestamp") or ""
        if not _in_date_range(ts, from_date, to_date):
            continue
        yield data


def _iter_order_usage_jsonl(
    usage_dir: Path,
    from_date: Optional[str] = None,
    to_date: Optional[str] = None,
):
    """Yield individual JSONL usage records from *.jsonl files, date-filtered."""
    if not usage_dir.is_dir():
        return
    for f in usage_dir.glob("*.jsonl"):
        try:
            for line in f.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if not line:
                    continue
                try:
                    data = json.loads(line)
                except json.JSONDecodeError:
                    continue
                ts = data.get("timestamp") or ""
                if not _in_date_range(ts, from_date, to_date):
                    continue
                yield data
        except Exception:
            continue


def _accumulate_series(
    buckets: dict,
    timestamp: str,
    tokens: int,
    cost: float,
) -> None:
    """Accumulate tokens/cost into a date-keyed series dict."""
    date = timestamp[:10] if len(timestamp) >= 10 else ""
    if not date:
        return
    prev_t, prev_c = buckets.get(date, (0, 0.0))
    buckets[date] = (prev_t + tokens, prev_c + cost)


def _build_series(date_buckets: dict) -> list[UsageSeriesPoint]:
    """Convert a {date: (tokens, cost)} dict into a sorted UsageSeriesPoint list."""
    return [
        UsageSeriesPoint(date=d, tokens=date_buckets[d][0], cost_usd=round(date_buckets[d][1], 4))
        for d in sorted(date_buckets)
    ]


def aggregate_usage_for_workspace(
    ws_root: Path,
    workspace_id: str,
    from_date: Optional[str] = None,
    to_date: Optional[str] = None,
    group_by: str = "order",
) -> UsageRollup:
    """Aggregate usage for a single workspace.

    group_by in {'voyage', 'order', 'role'}.  The 'role' dimension reads
    per-iteration JSONL records (from FTR-0332); degrades to empty buckets
    when none are present.
    """
    try:
        mso = _get_mso_dir(ws_root)
    except Exception:
        mso = _get_mso_dir(ws_root)

    usage_dir = mso / "usage" / "orders"

    # bucket_map: key → (total_tokens, total_cost, order_set)
    bucket_map: dict[str, list] = {}
    series_map: dict[str, tuple[int, float]] = {}
    grand_tokens = 0
    grand_cost = 0.0

    if group_by == "role":
        # Role dimension: read JSONL per-iteration records
        for rec in _iter_order_usage_jsonl(usage_dir, from_date, to_date):
            role = (rec.get("role") or "").strip() or "UNKNOWN"
            tokens = int(rec.get("total_tokens") or 0)
            cost = float(rec.get("estimated_cost_usd") or 0.0)
            ts = rec.get("timestamp") or ""
            order_id = rec.get("orderId") or ""
            if role not in bucket_map:
                bucket_map[role] = [0, 0.0, set()]
            bucket_map[role][0] += tokens
            bucket_map[role][1] += cost
            if order_id:
                bucket_map[role][2].add(order_id)
            grand_tokens += tokens
            grand_cost += cost
            _accumulate_series(series_map, ts, tokens, cost)
    else:
        # voyage and order dimensions: read JSON summary files
        for rec in _iter_order_usage_json(usage_dir, from_date, to_date):
            order_id = rec.get("orderId") or ""
            voyage_id = rec.get("voyageId") or ""
            tokens = int(rec.get("total_tokens") or 0)
            cost = float(rec.get("estimated_cost_usd") or 0.0)
            ts = rec.get("timestamp") or ""

            key = voyage_id if group_by == "voyage" else order_id
            if not key:
                key = order_id or "unknown"
            if key not in bucket_map:
                bucket_map[key] = [0, 0.0, set()]
            bucket_map[key][0] += tokens
            bucket_map[key][1] += cost
            if order_id:
                bucket_map[key][2].add(order_id)
            grand_tokens += tokens
            grand_cost += cost
            _accumulate_series(series_map, ts, tokens, cost)

    buckets = [
        UsageBucket(
            key=k,
            label=k,
            total_tokens=v[0],
            estimated_cost_usd=round(v[1], 4),
            order_count=len(v[2]) if isinstance(v[2], set) else v[0],
        )
        for k, v in sorted(bucket_map.items(), key=lambda x: -x[1][0])
    ]

    return UsageRollup(
        from_date=from_date,
        to_date=to_date,
        group_by=group_by,
        total_tokens=grand_tokens,
        estimated_cost_usd=round(grand_cost, 4),
        buckets=buckets,
        series=_build_series(series_map),
    )


def aggregate_usage_cross_workspace(
    from_date: Optional[str] = None,
    to_date: Optional[str] = None,
    group_by: str = "project",
) -> UsageRollup:
    """Cross-workspace usage rollup using the global project registry.

    group_by in {'project', 'voyage', 'order', 'role'}.
    A project/voyage/order with no data returns a zero bucket (not an error).
    """
    import maestro.registry as registry
    from maestro.workspace import artefact_parent_for_entry

    projects = registry.list_projects()

    if group_by == "project":
        # One bucket per registered workspace
        buckets: list[UsageBucket] = []
        series_map: dict[str, tuple[int, float]] = {}
        grand_tokens = 0
        grand_cost = 0.0

        for ws_id, entry in projects.items():
            ws_root = artefact_parent_for_entry(entry)
            rollup = aggregate_usage_for_workspace(ws_root, ws_id, from_date, to_date, "order")
            buckets.append(UsageBucket(
                key=ws_id,
                label=ws_id,
                total_tokens=rollup.total_tokens,
                estimated_cost_usd=rollup.estimated_cost_usd,
                order_count=len(rollup.buckets),
            ))
            grand_tokens += rollup.total_tokens
            grand_cost += rollup.estimated_cost_usd
            for pt in rollup.series:
                prev_t, prev_c = series_map.get(pt.date, (0, 0.0))
                series_map[pt.date] = (prev_t + pt.tokens, prev_c + pt.cost_usd)

        buckets.sort(key=lambda b: -b.total_tokens)
        return UsageRollup(
            from_date=from_date,
            to_date=to_date,
            group_by="project",
            total_tokens=grand_tokens,
            estimated_cost_usd=round(grand_cost, 4),
            buckets=buckets,
            series=_build_series(series_map),
        )
    else:
        # For voyage/order/role: aggregate across all workspaces, merge by key
        merged_buckets: dict[str, list] = {}
        series_map2: dict[str, tuple[int, float]] = {}
        grand_tokens2 = 0
        grand_cost2 = 0.0

        for ws_id, entry in projects.items():
            ws_root = artefact_parent_for_entry(entry)
            rollup = aggregate_usage_for_workspace(ws_root, ws_id, from_date, to_date, group_by)
            grand_tokens2 += rollup.total_tokens
            grand_cost2 += rollup.estimated_cost_usd
            for b in rollup.buckets:
                if b.key not in merged_buckets:
                    merged_buckets[b.key] = [0, 0.0, 0]
                merged_buckets[b.key][0] += b.total_tokens
                merged_buckets[b.key][1] += b.estimated_cost_usd
                merged_buckets[b.key][2] += b.order_count
            for pt in rollup.series:
                prev_t, prev_c = series_map2.get(pt.date, (0, 0.0))
                series_map2[pt.date] = (prev_t + pt.tokens, prev_c + pt.cost_usd)

        final_buckets = [
            UsageBucket(
                key=k, label=k,
                total_tokens=v[0],
                estimated_cost_usd=round(v[1], 4),
                order_count=v[2],
            )
            for k, v in sorted(merged_buckets.items(), key=lambda x: -x[1][0])
        ]
        return UsageRollup(
            from_date=from_date,
            to_date=to_date,
            group_by=group_by,
            total_tokens=grand_tokens2,
            estimated_cost_usd=round(grand_cost2, 4),
            buckets=final_buckets,
            series=_build_series(series_map2),
        )


def aggregate_usage_for_project(
    workspace_id: str,
    ws_root: Path,
    from_date: Optional[str] = None,
    to_date: Optional[str] = None,
) -> UsageRollup:
    """Per-project usage with voyage/order breakdown."""
    return aggregate_usage_for_workspace(ws_root, workspace_id, from_date, to_date, "voyage")


def aggregate_usage_for_voyage(
    voyage_id: str,
    ws_root: Path,
    from_date: Optional[str] = None,
    to_date: Optional[str] = None,
    order_ids: Optional[Iterable[str]] = None,
) -> UsageRollup:
    """Per-voyage usage: orders → roles (if JSONL data available).

    Filters the workspace's usage/orders/*.json files to those stamped with
    this voyageId (or belonging to the voyage's order list as a fallback).

    *order_ids*, when given, is merged into that member list. The manifest is
    only reloaded from ``voyages/{active,complete}/{voyage_id}.json``; a caller
    that found the voyage another way (a manifest under a different filename)
    passes the members it already holds so unstamped usage records still count.
    """
    try:
        mso = _get_mso_dir(ws_root)
    except Exception:
        mso = _get_mso_dir(ws_root)

    usage_dir = mso / "usage" / "orders"

    # Build the set of order IDs belonging to this voyage for fallback matching
    voyage_order_ids: set[str] = set()
    for sub in ("active", "complete"):
        vf = mso / "voyages" / sub / f"{voyage_id}.json"
        vdata = _load_json_safe(vf)
        if vdata:
            for o in vdata.get("orders") or []:
                if isinstance(o, dict):
                    oid = o.get("orderId") or o.get("id") or ""
                elif isinstance(o, str):
                    oid = o
                else:
                    oid = ""
                if oid:
                    voyage_order_ids.add(oid)
    for oid in order_ids or ():
        if oid:
            voyage_order_ids.add(str(oid))

    # Collect per-order totals for this voyage
    order_buckets: dict[str, list] = {}
    series_map: dict[str, tuple[int, float]] = {}
    grand_tokens = 0
    grand_cost = 0.0

    for rec in _iter_order_usage_json(usage_dir, from_date, to_date):
        order_id = rec.get("orderId") or ""
        file_voyage = rec.get("voyageId") or ""
        if file_voyage != voyage_id:
            if order_id not in voyage_order_ids:
                continue
        tokens = int(rec.get("total_tokens") or 0)
        cost = float(rec.get("estimated_cost_usd") or 0.0)
        ts = rec.get("timestamp") or ""
        if order_id not in order_buckets:
            order_buckets[order_id] = [0, 0.0]
        order_buckets[order_id][0] += tokens
        order_buckets[order_id][1] += cost
        grand_tokens += tokens
        grand_cost += cost
        _accumulate_series(series_map, ts, tokens, cost)

    buckets = [
        UsageBucket(
            key=k, label=k,
            total_tokens=v[0],
            estimated_cost_usd=round(v[1], 4),
            order_count=1,
        )
        for k, v in sorted(order_buckets.items(), key=lambda x: -x[1][0])
    ]

    return UsageRollup(
        from_date=from_date,
        to_date=to_date,
        group_by="order",
        total_tokens=grand_tokens,
        estimated_cost_usd=round(grand_cost, 4),
        buckets=buckets,
        series=_build_series(series_map),
    )


def get_order_usage_detail(
    order_id: str,
    usage_dir: Path,
) -> OrderUsageDetail:
    """Full usage breakdown for a single order (JSON + JSONL combined).

    Reads {order_id}.json for the base total + models breakdown.
    Reads {order_id}.jsonl for per-role/per-iteration detail (FTR-0332 data).
    Degrades gracefully when JSONL is absent.
    """
    detail = OrderUsageDetail(order_id=order_id)

    # Base JSON record
    json_file = usage_dir / f"{order_id}.json"
    base = _load_json_safe(json_file)
    if base:
        detail.total_tokens = int(base.get("total_tokens") or 0)
        detail.estimated_cost_usd = round(float(base.get("estimated_cost_usd") or 0.0), 4)
        detail.voyage_id = base.get("voyageId") or None
        detail.timestamp = base.get("timestamp") or None
        raw_models = base.get("models") or {}
        for model_name, mu in raw_models.items():
            if isinstance(mu, dict):
                detail.models[model_name] = ModelUsage(
                    input_tokens=int(mu.get("input_tokens") or 0),
                    output_tokens=int(mu.get("output_tokens") or 0),
                    cache_creation_input_tokens=int(mu.get("cache_creation_input_tokens") or 0),
                    cache_read_input_tokens=int(mu.get("cache_read_input_tokens") or 0),
                    message_count=int(mu.get("message_count") or 0),
                )

    # Per-iteration JSONL (FTR-0332 data) — role dimension + iterations list
    jsonl_file = usage_dir / f"{order_id}.jsonl"
    role_map: dict[str, list] = {}
    iterations: list[IterationUsage] = []

    if jsonl_file.exists():
        try:
            for line in jsonl_file.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if not line:
                    continue
                try:
                    rec = json.loads(line)
                except json.JSONDecodeError:
                    continue
                role = (rec.get("role") or "").strip() or "UNKNOWN"
                tokens = int(rec.get("total_tokens") or 0)
                cost = float(rec.get("estimated_cost_usd") or 0.0)
                ts = rec.get("timestamp") or ""
                crew = int(rec.get("crewNumber") or 0)
                iteration = int(rec.get("iteration") or 0)
                raw_models = rec.get("models") or {}

                model_usage = {
                    m: ModelUsage(
                        input_tokens=int(v.get("input_tokens") or 0),
                        output_tokens=int(v.get("output_tokens") or 0),
                        cache_creation_input_tokens=int(v.get("cache_creation_input_tokens") or 0),
                        cache_read_input_tokens=int(v.get("cache_read_input_tokens") or 0),
                        message_count=int(v.get("message_count") or 0),
                    )
                    for m, v in raw_models.items()
                    if isinstance(v, dict)
                }

                iterations.append(IterationUsage(
                    iteration=iteration,
                    role=role,
                    crew_number=crew,
                    total_tokens=tokens,
                    estimated_cost_usd=round(cost, 4),
                    timestamp=ts,
                    models=model_usage,
                ))

                if role not in role_map:
                    role_map[role] = [0, 0.0, set()]
                role_map[role][0] += tokens
                role_map[role][1] += cost
        except Exception:
            pass

    detail.iterations = iterations
    detail.role_buckets = [
        UsageBucket(
            key=r, label=r,
            total_tokens=v[0],
            estimated_cost_usd=round(v[1], 4),
            order_count=1,
        )
        for r, v in sorted(role_map.items(), key=lambda x: -x[1][0])
    ]

    return detail


def _find_order_usage_dir(order_id: str) -> Optional[Path]:
    """Search registered workspaces for an order's usage directory.

    Returns the usage/orders dir of the first workspace that has
    a usage file ({order_id}.json or {order_id}.jsonl) for this order.
    Returns None if not found in any workspace.
    """
    import maestro.registry as registry
    from maestro.workspace import artefact_parent_for_entry

    for ws_id, entry in registry.list_projects().items():
        ws_root = artefact_parent_for_entry(entry)
        try:
            mso = _get_mso_dir(ws_root)
        except Exception:
            mso = _get_mso_dir(ws_root)
        usage_dir = mso / "usage" / "orders"
        if (usage_dir / f"{order_id}.json").exists() or (usage_dir / f"{order_id}.jsonl").exists():
            return usage_dir
    return None
