#!/usr/bin/env python3
"""
Maestro - Crew Execution Engine v2.0.0 (Python)

Role-aware autonomous execution engine for crew members with self-organizing capabilities.
Spawns a Claude Code CLI instance per order with role-based model selection and
hook-based iteration control (Ralph Wiggum pattern).

v2.0.5 Feature:
  - MULTI-PROJECT SUPPORT: Project acronym injected via MAESTRO_PROJECT env var.
    Crews resolve project-specific config at runtime from config/projects/{acronym}.json.

v2.0.1 Feature:
  - MANAGED REPO CWD: When MAESTRO_REPO_PATH is set by fleet-runner, crew.py uses
    the pre-cloned repo as the Claude CLI working directory. Falls back to workspace
    root if the path doesn't exist (crew self-manages).

v8.3 Feature:
  - ROLE-BASED MODEL SELECTION: Each role gets the optimal Claude model.
    COX → Opus 4.7 (critical review), NAV/SHP/BOS/SCR → Sonnet 4.6, LKT → Haiku 4.5
    Configured via ROLE_MODELS dict. Logged at invocation time.

v8.2 Fix:
  - TIMEOUT-COMPLETE RACE: When subprocess times out due to lingering background
    bash processes, check ralph-state before declaring TIMEOUT. If stop hook already
    detected <promise>COMPLETE</promise>, honour COMPLETE status instead of re-queuing.

v8.0 Features:
  - PYTHON FOR-LOOP ITERATION CONTROL: run_crew() calls Claude once per iteration.
    MAESTRO_ITER_MANAGED=1 is injected so the stop hook exits cleanly instead of
    trying to re-feed via {decision: block} (which silently fails on Windows in a
    DETACHED_PROCESS/CREATE_NO_WINDOW context — BUG-MSO-2026-0029).
  - Per-crew ralph-state.md updated at each boundary for fleet_monitor visibility
  - CREW_ITER_BOUNDARY lifecycle events emitted for every iteration start/end
  - Environment variables (MAESTRO_CREW, MAESTRO_ORDER, etc.) isolate crew sessions
  - Captain's interactive sessions are NEVER affected (stop hook checks MAESTRO_CREW)

v7.3 Features:
  - TIMEOUT BRIEFING: On timeout, captures iteration count, artifacts, partial output
  - Brief stored in crew state, appended to order JSON on re-queue
  - Next crew sees "Previous Attempts" section in prompt

v6.0 Features:
  - NO CLI LOCK: Crews run as fully detached independent processes (no mutex needed)
  - Launched by fleet-runner with DETACHED_PROCESS + CREATE_NEW_PROCESS_GROUP
  - Restores 5-crew concurrent capability

v5.0-5.1 Features:
  - Self-organizing crews: Can create bugs, requests, and breakdowns
  - Role permissions: Each role has specific creation/request permissions
  - Queue integration: Work items placed in .mso/queues/
  - PLANNING REQUESTS: LKT can request NAV to plan based on investigation findings

Usage:
    python crew.py --crew 1 --role LKT --order INV-2026-0001 --prompt path/to/prompt.md

    # Status & cleanup
    python crew.py --crew 1 --status
    python crew.py --crew 1 --cleanup
"""

import argparse
import collections
import io
import json
import os
import re
import subprocess
from maestro.core.proc import run_hidden, popen_hidden, clear_console, init_console  # FTR-MSO-2026-0408: windowless subprocess + in-process console
from maestro.core import descendant_reaper  # BUG-MSO-2026-0500: reap orphaned crew descendants
from maestro.core.temp_paths import resolve_temp_dir, ensure_temp_dir  # BUG-MSO-2026-0701: $MAESTRO_TEMP defaults under the artefact root, never inside site-packages
import sys
import threading
import time
import uuid
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, Any, Callable

# Fix Windows console encoding and buffering
if sys.platform == 'win32':
    # Set UTF-8 mode for stdout/stderr with line buffering for immediate output
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace', line_buffering=True)
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace', line_buffering=True)


def log(msg: str):
    """Print with immediate flush for visibility in subprocess."""
    print(msg, flush=True)

# ============================================================================
# CONFIGURATION
# ============================================================================

# v2.0.5: Multi-project support — project acronym from fleet-runner env injection
PROJECT_ACRONYM = os.environ.get("MAESTRO_PROJECT", "OTM")

# Squad names and role-model IDs are persona-driven — see maestro/core_constants.py
from maestro.workspace import get_workspace_dir, MSO_DIR_NAME  # noqa: E402
from maestro.core_constants import (  # noqa: E402
    get_squad_name,
    get_role_model_id,
    get_role_context_window,
    get_role_effort,
    DEFAULT_ROLE_MODEL_IDS as _CANONICAL_ROLE_MODELS,
    SUPPORTED_MODEL_IDS as _SUPPORTED_MODEL_IDS,
    VALID_CONTEXT_WINDOWS,
    VALID_EFFORTS_CREW,
    VALID_EFFORTS_ALL,
    OPUS_ONLY_EFFORTS,
    MILLION_CONTEXT_MODEL_IDS,
    OPUS_MODEL_IDS,
)
# BUG-MSO-2026-0714: the launcher's accepted role vocabulary comes from the
# SAME module the filing-time and scan-time gates validate against, so a role
# that passes validation is always a role the launcher will start.
from maestro.roles.validation import (  # noqa: E402
    DISPATCHABLE_ROLE_CODES as _DISPATCHABLE_ROLE_CODES,
    normalise_role as _normalise_role,
)

ROLE_MODELS: dict[str, str] = dict(_CANONICAL_ROLE_MODELS)

# FTR-MSO-2026-0194 (Part C): Per-role tool scoping.
# Under --dangerously-skip-permissions, bare-name --disallowedTools removes
# a tool entirely (scoped rules like "Bash(rm:*)" are ignored).
# Empty list = unrestricted (BLD, TST, DOC, LEAD get all tools).
ROLE_DISALLOWED_TOOLS: dict[str, list[str]] = {
    "PLN":  ["NotebookEdit"],
    "BLD":  [],
    "TST":  [],
    "DOC":  [],
    # BUG-MSO-2026-0459: SEC needs Write to produce its sanctioned deliverables
    # (SEC-{ORDER-ID}.md report + handoff) — the pretool hook's SEC_WRITE_ALLOWED
    # scope (maestro/hooks/pretool.py) confines that Write to reports/handoffs/
    # progress only, so SEC still cannot touch source code, tests, or docs.
    # Edit/NotebookEdit stay disallowed — SEC only ever creates new report files,
    # never edits existing ones.
    "SEC":  ["Edit", "NotebookEdit"],
    "REL":  ["NotebookEdit"],
    "LEAD": [],
}

ROLE_INFO = {
    "PLN": {"name": "Planner", "focus": "Planning & Architecture"},
    "BLD": {"name": "Builder", "focus": "Development & Implementation"},
    "TST": {"name": "Tester", "focus": "Quality Assurance & Testing"},
    "DOC": {"name": "Docs Writer", "focus": "Documentation"},
    "SEC": {"name": "Security Reviewer", "focus": "Security & Investigation"},
    "REL": {"name": "Releaser", "focus": "Integration & Deployment"},
    "LEAD": {"name": "Lead", "focus": "Interactive Partner"},
}

def _role_info(role: str) -> dict:
    """Lookup role info by canonical role code."""
    return ROLE_INFO.get(role, {})

def _role_permissions(role: str) -> dict:
    """Lookup role permissions by canonical role code."""
    return ROLE_PERMISSIONS.get(role, {})

# v7.0: Role Permissions Matrix - Self-Organizing Crews
# NOTE: All roles can escalate (Captain's directive) — no permission check needed for escalations
# v8.4: repo_write controls which repos each role may create/modify files in.
#   "target"  = the service/API repo specified by the order's targetRepo
#   "docs"    = documentation repo
#   "maestro" = .mso/ directory (reports, handoffs, queues) — always allowed
ROLE_PERMISSIONS = {
    "PLN": {
        "can_create": ["orders", "bugs"],
        "can_request": ["investigation", "qa"],
        "can_breakdown": True,
        "repo_write": ["target", "docs"]
    },
    "BLD": {
        "can_create": ["bugs"],
        "can_request": ["investigation", "qa"],
        "can_breakdown": False,
        "repo_write": ["target"]
    },
    "TST": {
        "can_create": ["bugs", "defects"],
        "can_request": ["investigation"],
        "can_breakdown": False,
        "repo_write": ["target"]
    },
    "DOC": {
        "can_create": ["bugs"],
        "can_request": ["investigation", "qa"],
        "can_breakdown": False,
        "repo_write": ["docs"]
    },
    "SEC": {
        "can_create": ["bugs", "orders", "security"],
        "can_request": ["planning"],
        "can_breakdown": True,
        "repo_write": ["docs"]
    },
    "REL": {
        "can_create": ["bugs", "orders"],
        "can_request": ["investigation"],
        "can_breakdown": True,
        "repo_write": ["target", "docs"]
    }
}

# v8.3 / FTR-MSO-2026-0168: Role-model IDs moved to maestro/core_constants.py
# (DEFAULT_ROLE_MODEL_IDS). resolve_model_for() uses get_role_model_id() as
# the built-in default layer so canonical + legacy codes are both handled.
DEFAULT_MODEL = "claude-sonnet-5"

# v2.5.6 (FTR-ADM-2026-0129): set of model IDs Admiralty has cost-tracking
# pricing for. Used to validate operator overrides — unknown IDs raise so a
# typo doesn't silently dispatch against a model the usage tracker can't price.
# BUG-MSO-2026-0718: derived from core_constants.SUPPORTED_MODEL_IDS, the single
# source of truth shared with roles.loader.KNOWN_MODELS and the docs drift test.
SUPPORTED_MODELS = set(_SUPPORTED_MODEL_IDS)


def _load_workspace_role_models(artefact_root: Path | None = None) -> dict:
    """Read .mso/config/role-models.json if present.

    Schema: {"models": {"SHP": "claude-opus-4-7", ...}}
    Returns {} if missing/unreadable.

    BUG-MSO-2026-0805: ``artefact_root`` lets a multi-workspace caller (the
    Hub) name the workspace explicitly instead of inheriting the process-global
    ``get_artefact_root()``. An explicit-root read is cached per
    ``(path, mtime_ns, size)`` — the Hub maps hundreds of orders per poll, and an
    edit to the file still invalidates. The implicit (dispatcher) path is
    deliberately left uncached so its behaviour is unchanged.
    """
    try:
        root = artefact_root if artefact_root is not None else get_artefact_root()
        cfg = root / "config" / "role-models.json"
        if not cfg.exists():
            return {}
        if artefact_root is None:
            data = json.loads(cfg.read_text(encoding="utf-8"))
            return data.get("models", {}) if isinstance(data, dict) else {}
        st = cfg.stat()
        sig = (st.st_mtime_ns, st.st_size)
        key = str(cfg)
        hit = _ROLE_MODELS_CACHE.get(key)
        if hit is not None and hit[0] == sig:
            return hit[1]
        data = json.loads(cfg.read_text(encoding="utf-8"))
        models = data.get("models", {}) if isinstance(data, dict) else {}
        if not isinstance(models, dict):
            models = {}
        _ROLE_MODELS_CACHE[key] = (sig, models)
        return models
    except Exception:
        return {}


# BUG-MSO-2026-0805: explicit-root role-models.json cache (see above).
_ROLE_MODELS_CACHE: dict[str, tuple[tuple[int, int], dict]] = {}


def _validate_model_id(model_id: str, source: str) -> str:
    """Reject unknown model IDs with a clear error pointing at the supported list.

    FTR-MSO-2026-0281: strips the '[1m]' context-window suffix before checking
    SUPPORTED_MODELS, so 'claude-opus-4-5[1m]' validates the same as
    'claude-opus-4-5'. Returns the bare model ID (without any '[1m]' suffix).
    """
    bare_id = model_id.removesuffix("[1m]")
    if bare_id not in SUPPORTED_MODELS:
        supported = ", ".join(sorted(SUPPORTED_MODELS))
        raise ValueError(
            f"Unknown model '{bare_id}' (from {source}). "
            f"Admiralty does not have cost-tracking pricing for this ID and refuses "
            f"to dispatch against it. Supported: {supported}. "
            f"To add a new model, update SUPPORTED_MODELS + PRICING in maestro/core/."
        )
    return bare_id


def _validate_effort(effort: str, source: str, model: str = "", for_crew: bool = True) -> str:
    """Validate an effort value against the known effort tiers.

    FTR-MSO-2026-0281: raises ValueError for unknown values; demotes xhigh to
    high when the resolved model is not an Opus-class model; rejects max/ultracode
    for crew dispatch (reserved for interactive LEAD sessions).
    """
    if effort not in VALID_EFFORTS_ALL:
        valid = ", ".join(sorted(VALID_EFFORTS_ALL))
        raise ValueError(
            f"Unknown effort '{effort}' (from {source}). Valid values: {valid}."
        )
    if for_crew and effort in ("max", "ultracode"):
        raise ValueError(
            f"Effort '{effort}' (from {source}) is reserved for interactive LEAD sessions. "
            f"Crew dispatch allows: {', '.join(sorted(VALID_EFFORTS_CREW))}."
        )
    if effort in OPUS_ONLY_EFFORTS and model:
        bare_model = model.removesuffix("[1m]")
        if bare_model not in OPUS_MODEL_IDS:
            log(
                f"  [WARN] Effort '{effort}' requires an Opus-class model "
                f"(got '{bare_model}' from {source}); downgrading effort to 'high'."
            )
            return "high"
    return effort


def _validate_context_window(cw: str, source: str, model: str = "") -> str:
    """Validate a context-window value against the known tiers.

    FTR-MSO-2026-0281: raises ValueError for unknown values; downgrades '1m' to
    'standard' when the resolved model does not support a 1M-token context window.
    """
    if cw not in VALID_CONTEXT_WINDOWS:
        valid = ", ".join(sorted(VALID_CONTEXT_WINDOWS))
        raise ValueError(
            f"Unknown context window '{cw}' (from {source}). Valid values: {valid}."
        )
    if cw == "1m" and model:
        bare_model = model.removesuffix("[1m]")
        if bare_model not in MILLION_CONTEXT_MODEL_IDS:
            log(
                f"  [WARN] Context window '1m' requested (from {source}) but model "
                f"'{bare_model}' does not support 1M context; downgrading to 'standard'."
            )
            return "standard"
    return cw


def _load_order_data_for(order_id: str) -> dict:
    """Look up an order's JSON across all known queue + active locations.

    FTR-0129: needed so resolve_model_for() can apply per-order `model`
    overrides from anywhere a dispatcher hands the crew an order_id.
    Returns {} when not found or unreadable.

    Copilot review: covers every queue scanned by fleet_runner.scan_all_queues
    plus orders/active|complete|failed. A malformed JSON in one location
    doesn't end the search — the next candidate still gets a chance.
    """
    if not order_id:
        return {}
    try:
        adm = get_artefact_root()
    except Exception:
        return {}
    queues = (
        "orders", "explicit", "bugs", "security",
        "defects", "requests", "breakdown", "high-level",
        "escalations", "proposed",
    )
    candidates = [adm / "queues" / q / f"{order_id}.json" for q in queues]
    candidates.extend([
        adm / "orders" / "active" / f"{order_id}.json",
        adm / "orders" / "complete" / f"{order_id}.json",
        adm / "orders" / "failed" / f"{order_id}.json",
    ])
    for path in candidates:
        if path.exists():
            try:
                return json.loads(path.read_text(encoding="utf-8"))
            except Exception:
                # Malformed copy in one location — keep scanning. Same order
                # may exist verifiably in another queue.
                continue
    return {}


def resolve_model_for(role: str, order_data: dict | None = None) -> str:
    """Resolve the Claude model for a (role, order) pair.

    FTR-ADM-2026-0129 (+ FTR-0186 overlay layer): override chain, highest priority first:
      1. Per-order override        — order JSON `model` field
      2. Workspace config          — .mso/config/role-models.json
      3. Env var                   — MAESTRO_MODEL_<ROLE> (uppercase)
      4. Role overlay model        — .mso/config/roles/<CODE>.md frontmatter `model`
      5. Built-in ROLE_MODELS dict — falls back to DEFAULT_MODEL

    Unknown model IDs at any layer raise ValueError. Operators see the
    misconfiguration immediately rather than dispatching against a model
    the usage tracker can't price.

    BUG-MSO-2026-0805: a thin wrapper over ``resolve_model_detail`` — the ONE
    implementation of the chain, which the Hub also calls to show an order's
    model. Behaviour here is unchanged.
    """
    return resolve_model_detail(role, order_data)[0]


def resolve_model_detail(
    role: str,
    order_data: dict | None = None,
    artefact_root: Path | None = None,
    *,
    include_env: bool = True,
) -> tuple[str, str]:
    """Resolve ``(model_id, source)`` for a (role, order) pair.

    BUG-MSO-2026-0805. The 5-layer chain documented on ``resolve_model_for``,
    additionally reporting WHICH layer decided: ``source`` is one of
    ``"order" | "workspace" | "env" | "overlay" | "default"``.

    ``artefact_root`` names the workspace explicitly. The Hub serves many
    workspaces from one process, so the process-global ``get_artefact_root()``
    would read the wrong workspace's ``role-models.json`` / role overlays; the
    dispatcher leaves it ``None`` and keeps the process-global resolution.

    ``include_env=False`` skips layer 3. The Hub's environment is not the
    dispatcher's, so a ``MAESTRO_MODEL_<ROLE>`` read in the Hub process would
    describe a host that never dispatches anything. The Hub says so in the UI
    rather than guessing.

    Unknown model IDs raise ValueError exactly as ``resolve_model_for`` does.
    """
    # 1. Per-order override
    if order_data:
        order_model = order_data.get("model", "")
        if order_model:
            return (
                _validate_model_id(order_model, f"order.model for {role}"),
                "order",
            )

    # 2. Workspace config
    if artefact_root is None:
        workspace_models = _load_workspace_role_models()
    else:
        workspace_models = _load_workspace_role_models(artefact_root)
    if role in workspace_models and workspace_models[role]:
        ws_val = workspace_models[role]
        ws_model = ws_val.get("model") if isinstance(ws_val, dict) else ws_val
        if ws_model:
            return (
                _validate_model_id(
                    ws_model,
                    f"{MSO_DIR_NAME}/config/role-models.json[{role}]",
                ),
                "workspace",
            )

    # 3. Env var (case-insensitive role lookup, uppercase env name)
    if include_env:
        env_var = f"MAESTRO_MODEL_{role.upper()}"
        env_model = os.environ.get(env_var, "")
        if env_model:
            return _validate_model_id(env_model, f"${env_var}"), "env"

    # 4. Role overlay model (FTR-0186) — lets orgs override Sonnet→Opus via overlay
    try:
        from maestro.roles.loader import load_effective_role
        ws = artefact_root if artefact_root is not None else get_artefact_root()
        role_def = load_effective_role(role.upper(), ws)
        if role_def.model:
            model_id = _validate_model_id(role_def.model, f"role overlay model for {role}")
            # The effective role carries the CORE role file's model when no
            # overlay sets one, so only call it "overlay" when an overlay file
            # actually declares a model. Labelling only — the id is unchanged.
            source = "default"
            try:
                from maestro.roles.loader import load_overlay
                overlay = load_overlay(role.upper(), ws)
                if overlay is not None and overlay.model:
                    source = "overlay"
            except Exception:
                pass
            return model_id, source
    except Exception:
        pass

    # 5. Built-in default
    return get_role_model_id(role), "default"


def resolve_context_window_for(role: str, order_data: dict | None = None) -> str:
    """Resolve the context-window tier for a (role, order) pair.

    FTR-MSO-2026-0281: same 5-layer override chain as resolve_model_for.
    NOTE: recommendedContextWindow on the order is NOT read here — it is an
    advisory hint for the planner, not a dispatch directive.

    Override chain (highest priority first):
      1. Per-order override        — order JSON `contextWindow` field
      2. Workspace config          — .mso/config/role-models.json (object form)
      3. Env var                   — MAESTRO_CONTEXT_<ROLE> (uppercase)
      4. Role overlay              — .mso/config/roles/<CODE>.md frontmatter `context_window`
      5. Built-in default          — get_role_context_window(role)
    """
    # Best-effort model resolution for the xhigh/1m guard — ignore errors.
    try:
        _model_hint = resolve_model_for(role, order_data)
    except Exception:
        _model_hint = ""

    # 1. Per-order override
    if order_data:
        cw = order_data.get("contextWindow", "")
        if cw:
            return _validate_context_window(cw, f"order.contextWindow for {role}", _model_hint)

    # 2. Workspace config (object form)
    workspace_models = _load_workspace_role_models()
    if role in workspace_models and workspace_models[role]:
        ws_val = workspace_models[role]
        if isinstance(ws_val, dict):
            cw = ws_val.get("contextWindow", "")
            if cw:
                return _validate_context_window(
                    cw,
                    f"{MSO_DIR_NAME}/config/role-models.json[{role}].contextWindow",
                    ws_val.get("model", ""),
                )

    # 3. Env var
    env_var = f"MAESTRO_CONTEXT_{role.upper()}"
    env_cw = os.environ.get(env_var, "")
    if env_cw:
        return _validate_context_window(env_cw, f"${env_var}", _model_hint)

    # 4. Role overlay
    try:
        from maestro.roles.loader import load_effective_role
        ws = get_artefact_root()
        role_def = load_effective_role(role.upper(), ws)
        if role_def.context_window:
            return _validate_context_window(
                role_def.context_window,
                f"role overlay context_window for {role}",
                _model_hint,
            )
    except Exception:
        pass

    # 5. Built-in default
    return get_role_context_window(role)


def _resolve_state_model(role: str, order_id: str) -> "tuple[Optional[str], Optional[str]]":
    """Resolve ``(model_id, context_window)`` for the crew's live state.json.

    FTR-MSO-2026-0796: the Hub crew card/drawer shows which model a crew runs.
    Uses the SAME pair ``fleet_monitor._effective_role_model_label`` uses
    (``_load_order_data_for`` + ``resolve_model_for``) — never a second
    resolution chain. The model id is stored BARE (no ``[1m]`` suffix; that is
    a CLI-argument detail, see ``invoke_claude``) with the context window as a
    separate value.

    Fail-open to ``(None, None)``: ``invoke_claude`` keeps its own raise/log
    path for a genuinely bad model id, so the state write must never be the
    thing that crashes ``run_crew``.
    """
    try:
        order_data = _load_order_data_for(order_id)
        model = resolve_model_for(role, order_data)
        model = (model or "").removesuffix("[1m]") or None
    except Exception:
        return None, None
    try:
        context_window = resolve_context_window_for(role, order_data) or None
    except Exception:
        context_window = None
    return model, context_window


def resolve_effort_for(role: str, order_data: dict | None = None) -> str:
    """Resolve the effort tier for a (role, order) pair.

    FTR-MSO-2026-0281: same 5-layer override chain as resolve_model_for.
    NOTE: recommendedEffort on the order is NOT read here — it is an advisory
    hint for the planner, not a dispatch directive.
    Crew dispatch rejects max/ultracode (reserved for interactive LEAD sessions).

    Override chain (highest priority first):
      1. Per-order override        — order JSON `effort` field
      2. Workspace config          — .mso/config/role-models.json (object form)
      3. Env var                   — MAESTRO_EFFORT_<ROLE> (uppercase)
      4. Role overlay              — .mso/config/roles/<CODE>.md frontmatter `effort`
      5. Built-in default          — get_role_effort(role)
    """
    # Best-effort model resolution for the xhigh guard — ignore errors.
    resolved_model = ""
    try:
        resolved_model = resolve_model_for(role, order_data)
    except Exception:
        pass

    # 1. Per-order override
    if order_data:
        effort = order_data.get("effort", "")
        if effort:
            return _validate_effort(effort, f"order.effort for {role}", resolved_model, for_crew=True)

    # 2. Workspace config (object form)
    workspace_models = _load_workspace_role_models()
    if role in workspace_models and workspace_models[role]:
        ws_val = workspace_models[role]
        if isinstance(ws_val, dict):
            effort = ws_val.get("effort", "")
            if effort:
                return _validate_effort(
                    effort,
                    f"{MSO_DIR_NAME}/config/role-models.json[{role}].effort",
                    ws_val.get("model", ""),
                    for_crew=True,
                )

    # 3. Env var
    env_var = f"MAESTRO_EFFORT_{role.upper()}"
    env_effort = os.environ.get(env_var, "")
    if env_effort:
        return _validate_effort(env_effort, f"${env_var}", resolved_model, for_crew=True)

    # 4. Role overlay
    try:
        from maestro.roles.loader import load_effective_role
        ws = get_artefact_root()
        role_def = load_effective_role(role.upper(), ws)
        if role_def.effort:
            return _validate_effort(
                role_def.effort,
                f"role overlay effort for {role}",
                resolved_model,
                for_crew=True,
            )
    except Exception:
        pass

    # 5. Built-in default
    return get_role_effort(role)


# v7.0: Queue depth limits to prevent runaway queue growth
MAX_QUEUE_DEPTH = {
    "bugs": 50,
    "defects": 20,
    "security": 10,
    "breakdown": 30,
    "escalations": 20
}

# v7.0: Per-crew creation rate limit — max items a single crew can create per order execution
MAX_CREW_ITEMS_PER_ORDER = 10

# ============================================================================
# PATH HELPERS
# ============================================================================

# ============================================================================
# SESSION ID (FTR-MSO-2026-0195)
# ============================================================================

# UUIDv5 namespace for Maestro session IDs.
_SESSION_NS = uuid.UUID("6ba7b810-9dad-11d1-80b4-00c04fd430c8")


def make_session_id(crew_number: int, order_id: str, iteration: int,
                    run_nonce: str = "") -> str:
    """Return a UUIDv5 for a (crew, order, iteration[, run_nonce]) tuple.

    BUG-MSO-2026-0220: a purely deterministic (crew, order, iteration) id
    collides with the Claude CLI's persisted session on RE-dispatch — the Ralph
    model restarts a re-queued order at iteration 1, so the retry reused the same
    id and Claude rejected it ('Session ID ... is already in use'), making any
    killed/timed-out order unrecoverable. `run_nonce` is a per-crew-run salt
    (generated once per crew.py launch) so each dispatch attempt gets a fresh,
    non-colliding session id while remaining stable across the iterations of a
    single run. Stored as maestroSessionId in state.json + lifecycle for tracing.
    """
    seed = f"maestro:crew{crew_number}:{order_id}:iter{iteration}"
    if run_nonce:
        seed += f":run{run_nonce}"
    return str(uuid.uuid5(_SESSION_NS, seed))


def get_artefact_root() -> Path:
    """Artefact root (the workspace dir holding queues/orders/crews/logs).

    Central resolver (FTR-MSO-2026-0361): every artefact-plane path in this
    module resolves through here. Reads the module-global ``get_workspace_dir``
    at call time so tests that monkeypatch ``crew.get_workspace_dir`` keep
    working. Phase 2+ retargets maestro.workspace.get_artefact_root() to the
    artefact repo without call-site changes here.

    BUG-MSO-2026-0425 audit: this legitimately resolves via get_workspace_dir
    (MAESTRO_DIR first) because the dispatcher ALWAYS launches crews with
    MAESTRO_DIR=get_artefact_root() (fleet_runner ``crew_env``), so in solo/shared
    mode MAESTRO_DIR already points at the artefact plane — no walk-up occurs.
    """
    return get_workspace_dir()

def get_product_repo(target_repo: Optional[str] = None) -> Path:
    """Product repository root (FTR-MSO-2026-0361).

    Today (embedded mode) this is the parent of the artefact root; *target_repo*
    is accepted for the Phase-4 signature (repos-map resolution) and is unused.
    """
    return get_artefact_root().parent

def get_base_dir() -> Path:
    """Get the project base directory."""
    return get_product_repo()

def get_crew_dir(crew_number: int) -> Path:
    """Get the crew's working directory."""
    return get_artefact_root() / f"crews/crew{crew_number}"

def ensure_crew_dir(crew_number: int) -> Path:
    """Ensure crew directory exists and return it."""
    crew_dir = get_crew_dir(crew_number)
    crew_dir.mkdir(parents=True, exist_ok=True)
    return crew_dir

# ============================================================================
# STATE MANAGEMENT
# ============================================================================

def read_state(crew_number: int) -> Optional[Dict[str, Any]]:
    """Read crew state from state.json."""
    state_file = get_crew_dir(crew_number) / "state.json"
    if state_file.exists():
        try:
            return json.loads(state_file.read_text(encoding='utf-8'))
        except:
            return None
    return None

_WRITE_STATE_MAX_ATTEMPTS = 5
_WRITE_STATE_RETRY_DELAY_SECONDS = 0.05

# BUG-MSO-2026-0660 (F3): a TERMINAL status write (run_crew()'s own `finally`
# block, publishing status=COMPLETE/ERROR/BLOCKED/etc right before the crew
# process exits) has no "next cycle" to retry on — unlike a heartbeat write,
# there is no later write_state() call that will correct a dropped one. A
# much larger retry budget makes abandonment astronomically less likely
# against the routine, brief Windows file-handle collision this retry loop
# exists for in the first place.
_WRITE_STATE_TERMINAL_MAX_ATTEMPTS = 50
_WRITE_STATE_TERMINAL_RETRY_DELAY_SECONDS = 0.1

# BUG-MSO-2026-0644 (F3): one lock per crew NUMBER, guarding the tmp-write +
# replace sequence below. `run_crew()`'s main thread and its own
# `_on_live_update` background stdout-reader-thread callback (invoke_claude's
# daemon reader, which can still be alive up to `stdout_reader.join(timeout=
# 15)` expiring — a bounded join, not a guaranteed one) both call
# `write_state()` for the SAME crew_number concurrently. Both writers used a
# single FIXED `state.tmp` path with no coordination between them: writer B
# truncating that shared tmp file with its own `write_text()` between writer
# A's `write_text()` and `tmp_path.replace()` publishes whichever content
# writer A's `replace()` picks up — partial or, worse, entirely writer B's
# half-written bytes — the exact torn read this function's own docstring
# claims is now impossible. A per-crew-number lock is sufficient (not a
# unique-tmp-per-call scheme) to serialize the two THREADS of this crew's own
# process. `defaultdict` avoids a startup-order dependency on which crew
# numbers exist. Test-verified under genuine thread concurrency, not a
# serialized fixture:
# tests/test_crew.py::test_write_state_serializes_genuinely_concurrent_writer_threads.
#
# BUG-MSO-2026-0668 (F4): a second PROCESS does write this file — the
# dispatcher (fleet_runner.py) resets a dead/completed crew's state.json to
# IDLE (and force-sets CRASHED for an unrecognized dead status) at several
# reconciliation points, and one of those — the pipe-hang drain path — fires
# while `is_process_alive(pid)` for THIS crew is still `True`, i.e. while this
# very lock could be protecting a genuinely concurrent write from this crew's
# own threads. This in-process lock was never able to cover that second
# process — no `threading.Lock` can — so the comment's old claim ("no second
# process ever writes this file") was false, and the terminal fallback below
# leaned on that same false claim. The gap is closed on the OTHER side
# instead: every dispatcher-side write goes through
# `fleet_runner._write_crew_state_atomic()`, the same tmp-then-`os.replace`
# pattern used here, so a reader in EITHER process only ever observes a
# fully-valid write from one side or the other, never a torn one —
# regardless of which process wrote last.
_WRITE_STATE_LOCKS: "Dict[int, threading.Lock]" = collections.defaultdict(threading.Lock)


def write_state(crew_number: int, state: Dict[str, Any], terminal: bool = False,
                 mutate: Optional[Callable[[Dict[str, Any]], None]] = None):
    """Write crew state to state.json.

    BUG-MSO-2026-0636 (F1): atomic write (tmp + os.replace), matching the
    pattern already used by create_ralph_state()/advance_ralph_state(). A
    plain write_text() can be read mid-write by a concurrent
    worktrees._crew_worktree_occupied() liveness check — a torn read either
    raises (json.JSONDecodeError) or, worse, parses to a truncated-but-valid
    partial object. Either way a live worktree must never be read as "free"
    because its state.json was caught mid-write; os.replace() is atomic on
    both POSIX and Windows, so a reader only ever sees the old complete
    content or the new complete content, never a partial one.

    BUG-MSO-2026-0640 (F2): the F1 fix above silently DEGRADED on Windows.
    ``os.replace()`` over a file a concurrent reader currently has open
    raises ``PermissionError [WinError 5]`` there — CPython's default
    ``open()`` does not request ``FILE_SHARE_DELETE``, and this is a ROUTINE
    collision, not a rare race: this function is called on every streamed
    turn while ``worktrees._crew_worktree_occupied()``, the monitor, and
    ``mso status`` all poll state.json concurrently. The bare
    ``except Exception`` then fell through to exactly the truncate-then-
    write this function exists to eliminate, with no retry and no logging,
    and orphaned ``state.tmp`` behind. Retrying gives the (brief) reader
    handle time to close; if every attempt still fails, the write is
    ABANDONED loudly rather than degraded silently — state.json keeps its
    previous, fully-valid content rather than being torn or truncated, and
    the orphaned tmp file is cleaned up. Losing one state update (heartbeats
    / status fields refresh on the very next cycle moments later) is far
    cheaper than a reader observing a corrupt or falsely-vacated state.json.

    BUG-MSO-2026-0644 (F3): the tmp+replace sequence itself is now guarded by
    a per-crew-number lock (see ``_WRITE_STATE_LOCKS``) — the F1/F2 fixes
    above made a SINGLE writer's own write/replace atomic against an outside
    READER, but never serialized this function against the SECOND WRITER
    that ``run_crew()``'s background stdout-reader thread also is. Without
    the lock, two threads sharing the one fixed ``state.tmp`` name could
    interleave their own ``write_text``/``replace`` calls and publish a torn
    or fully-wrong-writer's payload — the lock makes each call's write+replace
    indivisible from the other writer's perspective.

    BUG-MSO-2026-0660 (F5): ``json.dumps(state, ...)`` now runs INSIDE the
    lock, not before it. ``state`` is shared BY REFERENCE with the
    background reader thread's ``_on_live_update`` callback, which also
    calls this function on the very same dict. Serializing outside the lock
    let one thread's ``json.dumps`` iterate the dict while the other thread
    concurrently added a new key to it — ``RuntimeError: dictionary changed
    size during iteration`` — which ``invoke_claude``'s stream loop swallows,
    silently stopping the live turn/activity counters
    (FTR-MSO-2026-0632) with no error surfaced anywhere. Both writers now
    take the SAME per-crew lock before serializing, so the two ``json.dumps``
    calls can never overlap with each other.

    BUG-MSO-2026-0660 (F3): pass ``terminal=True`` for the ONE write that
    publishes a crew's final status (``run_crew()``'s own ``finally`` block,
    right before the process exits). That write has no "next cycle" to
    retry on — the F2 abandon-after-5-attempts path is correct for a
    heartbeat (the next iteration's write corrects it moments later) and
    wrong for a terminal one: an abandoned terminal write leaves state.json
    at its previous status — almost always RUNNING — which the dispatcher
    then reads against a now-dead pid, rewrites to CRASHED, and
    salvages/requeues an order that had actually completed. A terminal write
    gets a far larger retry budget, and if every attempt still fails, a
    final non-atomic ``write_text`` fallback ensures the write is never
    silently abandoned outright.

    BUG-MSO-2026-0668 (F4): this fallback's original justification —
    "no other writer exists this late in a crew's lifecycle" — was not true;
    see ``_WRITE_STATE_LOCKS``'s comment above for the dispatcher-side writes
    that disprove it. The corrected justification: by the time every retry of
    the atomic path has failed, this crew's own worker is one non-atomic
    write away from exiting, so a torn read here is a narrow, brief-window
    risk, and it is strictly smaller than the RUNNING-on-dead-pid misread an
    outright-abandoned terminal write would cause. The dispatcher's own
    writes no longer widen that window regardless — they went through
    ``fleet_runner._write_crew_state_atomic()`` (the same tmp-then-replace
    pattern) since the same fix, so they can race this fallback's write for
    "last writer wins" but can never produce a torn read of their own.

    BUG-MSO-2026-0660 (F5)'s claim did not hold: BUG-MSO-2026-0671 (F2).
    F5 above serializes only the two ``json.dumps`` calls against each other.
    It does not cover the SAME shared ``state`` dict being MUTATED outside
    this lock by two different threads — ``run_crew``'s foreground code
    (``state["claudeSessionId"] = ...`` / ``numTurns`` / ``totalCostUsd``,
    right before its own ``write_state`` call) and the background stdout-
    reader thread's ``_on_live_update`` callback (``_state["liveTurn"] = ...``
    etc., right before ITS ``write_state`` call). Verified by reading
    ``invoke_claude``'s join sequence: on a timed-out iteration the reader
    thread is only ``join(timeout=15)``-ed, not waited on to actual
    completion, so it can still be alive — and still calling
    ``on_live_update`` — after ``invoke_claude`` returns and the foreground
    code resumes mutating the same dict. Two concurrent ``json.dumps`` calls
    can never race each other (the lock already prevents that), but a
    mutation happening OUTSIDE the lock while the OTHER thread is inside the
    lock serializing is exactly the ``RuntimeError: dictionary changed size
    during iteration`` F5 claimed to have already fixed. The ``mutate``
    parameter closes this: a caller passes its field assignments as a
    callback invoked HERE, inside the same critical section as
    ``json.dumps``, instead of mutating ``state`` beforehand — so every
    mutation-then-serialize sequence for a given crew is now indivisible
    from the other writer's perspective, matching F5's original (until now
    unmet) intent.
    """
    crew_dir = ensure_crew_dir(crew_number)
    state_file = crew_dir / "state.json"
    # BUG-MSO-2026-0674 (F3): a bare `with_suffix('.tmp')` shares the SAME
    # fixed `state.tmp` path with fleet_runner.py's own
    # `_write_crew_state_atomic()`, which runs in a DIFFERENT process (the
    # dispatcher, not this crew). The per-crew `_WRITE_STATE_LOCKS` lock
    # above only serializes writers WITHIN this process — it cannot
    # serialize against a lock some other process's Python interpreter
    # holds. In the pipe-hang drain window this docstring's own BUG-MSO-
    # 2026-0668 (F4) entry names — where the crew is still alive and
    # writing every turn while the dispatcher reconciles the same
    # state.json — one side's write_text() truncating the shared tmp file
    # between the other side's write_text() and its replace() publishes a
    # 0-byte or torn state.json, or silently drops whichever write loses
    # the race (the BUG-MSO-2026-0266/0015 spurious-second-convergence
    # regression). Suffixing the tmp name with this process's own pid makes
    # every writer's tmp path unique ACROSS processes, so two independent
    # write_text()+replace() sequences can only ever produce "last
    # os.replace() wins" on state_file itself — never a torn read of a tmp
    # file shared between them. Verified by reading
    # fleet_runner._write_crew_state_atomic(), which uses the identical
    # per-pid pattern for the same reason.
    tmp_path = state_file.with_name(f"{state_file.stem}.{os.getpid()}.tmp")
    last_exc: Optional[Exception] = None
    lock = _WRITE_STATE_LOCKS[crew_number]
    max_attempts = _WRITE_STATE_TERMINAL_MAX_ATTEMPTS if terminal else _WRITE_STATE_MAX_ATTEMPTS
    retry_delay = _WRITE_STATE_TERMINAL_RETRY_DELAY_SECONDS if terminal else _WRITE_STATE_RETRY_DELAY_SECONDS
    with lock:
        if mutate is not None:
            mutate(state)
        payload = json.dumps(state, indent=2)
        for attempt in range(max_attempts):
            try:
                tmp_path.write_text(payload, encoding='utf-8')
                tmp_path.replace(state_file)
                return
            except OSError as exc:
                last_exc = exc
                if attempt < max_attempts - 1:
                    time.sleep(retry_delay)

        if terminal:
            try:
                state_file.write_text(payload, encoding='utf-8')
                write_crew_lifecycle_event(
                    "WARN",
                    f"crew{crew_number} write_state: os.replace failed after "
                    f"{max_attempts} attempts ({last_exc}) for a TERMINAL "
                    "status write — fell back to a non-atomic write so the "
                    "terminal status is never silently dropped "
                    "(BUG-MSO-2026-0660 F3)"
                )
            except OSError as exc2:
                write_crew_lifecycle_event(
                    "ERROR",
                    f"crew{crew_number} write_state: TERMINAL status write "
                    f"FAILED even after the non-atomic fallback ({exc2}) — "
                    "state.json left at its previous content "
                    "(BUG-MSO-2026-0660 F3)"
                )
            try:
                tmp_path.unlink()
            except OSError:
                pass
            return

        write_crew_lifecycle_event(
            "WARN",
            f"crew{crew_number} write_state: os.replace failed after "
            f"{max_attempts} attempts ({last_exc}) — state.json "
            "left at its PREVIOUS content this cycle rather than torn/truncated "
            "(BUG-MSO-2026-0640 F2)"
        )
        try:
            tmp_path.unlink()
        except OSError:
            pass

def update_heartbeat(crew_number: int, phase: str = "", role: str = ""):
    """Update heartbeat file with current timestamp."""
    crew_dir = ensure_crew_dir(crew_number)
    heartbeat_file = crew_dir / "heartbeat.txt"
    heartbeat_file.write_text(datetime.now().isoformat(), encoding='utf-8')


# ============================================================================
# RALPH STATE (v8.0 Stop Hook Integration)
# ============================================================================

def create_ralph_state(crew_number: int, order_id: str, role: str,
                       max_iterations: int = 25,
                       completion_promise: str = "COMPLETE"):
    """Create the per-crew ralph-state.md file before the iteration loop.

    The Python for-loop advances this file at each iteration boundary via
    advance_ralph_state(). The stop hook is disabled (MAESTRO_ITER_MANAGED=1)
    so it no longer updates this file. YAML frontmatter + iteration log body.
    """
    crew_dir = ensure_crew_dir(crew_number)
    state_file = crew_dir / "ralph-state.md"
    now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    content = (
        f"---\n"
        f"crew: {crew_number}\n"
        f'order: "{order_id}"\n'
        f'role: "{role}"\n'
        f"iteration: 1\n"
        f"max_iterations: {max_iterations}\n"
        f'completion_promise: "{completion_promise}"\n'
        f'status: "RUNNING"\n'
        f'created: "{now}"\n'
        f'last_iteration: "{now}"\n'
        f"---\n"
        f"\n"
        f"# Iteration Log\n"
        f"\n"
        f"## Initialization ({now})\n"
        f"Ralph state created. Python for-loop manages iterations (MAESTRO_ITER_MANAGED).\n"
    )

    # Atomic write
    tmp_path = state_file.with_suffix('.tmp')
    try:
        tmp_path.write_text(content, encoding='utf-8')
        tmp_path.replace(state_file)
    except Exception:
        state_file.write_text(content, encoding='utf-8')

    log(f"  Ralph state created: {state_file.relative_to(get_base_dir())}")


def advance_ralph_state(crew_number: int, iteration: int, status: str = "RUNNING"):
    """Update ralph-state.md iteration counter from the Python for-loop.

    Called at each iteration boundary so fleet_monitor and operators can see
    real-time progress without relying on the stop hook (which is disabled via
    MAESTRO_ITER_MANAGED when the for-loop owns iteration control).
    """
    crew_dir = get_crew_dir(crew_number)
    state_file = crew_dir / "ralph-state.md"
    if not state_file.exists():
        return
    now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    try:
        content = state_file.read_text(encoding='utf-8')
        # Replace iteration: N and status/last_iteration in frontmatter
        content = re.sub(r'^iteration: \d+', f'iteration: {iteration}', content, flags=re.MULTILINE)
        content = re.sub(r'^status: ".*?"', f'status: "{status}"', content, flags=re.MULTILINE)
        content = re.sub(r'^last_iteration: ".*?"', f'last_iteration: "{now}"', content, flags=re.MULTILINE)
        content += f"\n## Iteration {iteration} ({now})\nPython for-loop advanced to iteration {iteration}. Status: {status}.\n"
        tmp_path = state_file.with_suffix('.tmp')
        tmp_path.write_text(content, encoding='utf-8')
        tmp_path.replace(state_file)
    except Exception:
        pass  # Non-fatal: ralph-state is for observability only


def write_crew_lifecycle_event(event_type: str, message: str):
    """Write a lifecycle event to the fleet lifecycle log from crew.py.

    Mirrors fleet_runner.write_lifecycle_event without importing fleet_runner.
    Used to emit CREW_ITER_BOUNDARY events observable via mso status.
    """
    try:
        log_dir = get_artefact_root() / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        log_file = log_dir / "lifecycle.log"
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        line = f"{timestamp} | {event_type:<18} | {message}\n"
        with open(str(log_file), 'a', encoding='utf-8') as f:
            f.write(line)
    except Exception:
        pass  # Non-fatal: lifecycle logging is best-effort


def read_ralph_state(crew_number: int) -> dict:
    """Read the final ralph-state.md after Claude exits.

    v8.0: Returns parsed YAML frontmatter as a dict with keys:
    iteration, max_iterations, status, completion_promise, etc.
    """
    crew_dir = get_crew_dir(crew_number)
    state_file = crew_dir / "ralph-state.md"

    if not state_file.exists():
        return {}

    try:
        content = state_file.read_text(encoding='utf-8')
    except Exception:
        return {}

    # Parse YAML frontmatter (between --- delimiters)
    match = re.match(r'^---\s*\n(.*?)\n---\s*\n', content, re.DOTALL)
    if not match:
        return {}

    frontmatter = {}
    for line in match.group(1).strip().split('\n'):
        line = line.strip()
        if ':' in line:
            key, _, value = line.partition(':')
            key = key.strip()
            value = value.strip()
            # Strip surrounding quotes
            if value.startswith('"') and value.endswith('"'):
                value = value[1:-1]
            elif value.startswith("'") and value.endswith("'"):
                value = value[1:-1]
            # Convert numeric values
            if value.isdigit():
                value = int(value)
            elif value == 'true':
                value = True
            elif value == 'false':
                value = False
            elif value == 'null':
                value = None
            frontmatter[key] = value

    return frontmatter


def check_lock(crew_number: int) -> bool:
    """Check if crew is locked (already running).

    v6.0: Also checks if the PID in the lock is actually alive.
    This prevents stale locks from blocking new crew launches.
    """
    lock_file = get_crew_dir(crew_number) / "crew.lock"
    if not lock_file.exists():
        return False

    # Check if the PID in the lock is still alive
    try:
        lock_data = json.loads(lock_file.read_text(encoding='utf-8'))
        lock_pid = lock_data.get("pid", 0)
        if lock_pid and not _is_pid_alive(lock_pid):
            return False  # Process is dead - stale lock
    except:
        pass

    # Fallback: Check if lock is stale (older than 5 minutes with no heartbeat)
    heartbeat_file = get_crew_dir(crew_number) / "heartbeat.txt"
    if heartbeat_file.exists():
        try:
            heartbeat_time = datetime.fromisoformat(heartbeat_file.read_text().strip())
            age = (datetime.now() - heartbeat_time).total_seconds()
            if age > 300:  # 5 minutes
                return False  # Stale lock
        except:
            pass
    return True


def _is_pid_alive(pid: int) -> bool:
    """Check if a process is alive (used by lock check)."""
    if pid <= 0:
        return False
    try:
        if os.name == 'nt':
            import ctypes
            kernel32 = ctypes.windll.kernel32
            handle = kernel32.OpenProcess(0x1000, False, pid)
            if handle == 0:
                return False
            try:
                exit_code = ctypes.c_ulong()
                if kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code)):
                    return exit_code.value == 259
                return False
            finally:
                kernel32.CloseHandle(handle)
        else:
            os.kill(pid, 0)
            return True
    except:
        return False

def set_lock(crew_number: int, order_id: str, role: str):
    """Set crew lock."""
    crew_dir = ensure_crew_dir(crew_number)
    lock_file = crew_dir / "crew.lock"
    lock_data = {
        "pid": os.getpid(),
        "orderId": order_id,
        "role": role,
        "startTime": datetime.now().isoformat()
    }
    lock_file.write_text(json.dumps(lock_data, indent=2), encoding='utf-8')
    update_heartbeat(crew_number)

def clear_lock(crew_number: int):
    """Clear crew lock and related files."""
    crew_dir = get_crew_dir(crew_number)
    for filename in ["crew.lock", "heartbeat.txt", "pid.txt"]:
        lock_file = crew_dir / filename
        if lock_file.exists():
            lock_file.unlink()

# ============================================================================
# PROGRESS TRACKING
# ============================================================================

def init_progress(crew_number: int, order_id: str, role: str):
    """Initialize progress file."""
    crew_dir = ensure_crew_dir(crew_number)
    progress_file = crew_dir / "progress.md"

    role_name = _role_info(role).get("name", role)
    start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    content = f"""# Progress: Order {order_id}

## Role: {role} ({role_name})
## Started: {start_time}

## Tasks
- [ ] Review task and understand requirements
- [ ] Begin execution

## Files Changed
(none yet)

## Notes
"""
    # BUG-MSO-2026-0713: retain whatever the slot still holds before this
    # function overwrites progress.md and unlinks the hook files below. The
    # dispatcher normally rotated at _reset_crew_tracking moments earlier, so
    # this is usually a no-op; it matters for a crew started outside that path
    # (a manual `mso squad` run). crew.log is excluded — this process's own
    # stdout is being written to it right now.
    try:
        from maestro.core import crew_history
        crew_history.rotate_crew_run(
            crew_number, order_id=order_id, role=role, include_crew_log=False
        )
    except Exception:
        pass

    progress_file.write_text(content, encoding='utf-8')

    # v8.1: Clear hook data files for fresh start
    for filename in ["activity.jsonl", "activity.txt", "files_modified.json", "notifications.log"]:
        filepath = crew_dir / filename
        if filepath.exists():
            try:
                filepath.unlink()
            except Exception:
                pass

def read_progress(crew_number: int) -> str:
    """Read current progress."""
    progress_file = get_crew_dir(crew_number) / "progress.md"
    if progress_file.exists():
        return progress_file.read_text(encoding='utf-8')
    return "No progress yet."

# ============================================================================
# v5.0: QUEUE ITEM CREATION (Self-Organizing Crews)
# ============================================================================

def get_queue_dir() -> Path:
    """Get the queue directory."""
    return get_artefact_root() / "queues"

def generate_queue_id(prefix: str) -> str:
    """Generate a unique queue item ID."""
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    import random
    suffix = random.randint(100, 999)
    return f"{prefix}-{timestamp}-{suffix}"

def can_create_item(role: str, item_type: str) -> bool:
    """Check if a role can create a specific item type."""
    permissions = _role_permissions(role)
    return item_type in permissions.get("can_create", [])

def can_request_service(role: str, service_type: str) -> bool:
    """Check if a role can request a specific service."""
    permissions = _role_permissions(role)
    return service_type in permissions.get("can_request", [])

def can_breakdown_orders(role: str) -> bool:
    """Check if a role can break down high-level orders."""
    permissions = _role_permissions(role)
    return permissions.get("can_breakdown", False)

def check_queue_depth(queue_name: str) -> bool:
    """Check if a queue is under its depth limit (v7.0). Returns True if item can be added."""
    limit = MAX_QUEUE_DEPTH.get(queue_name)
    if limit is None:
        return True  # No limit configured for this queue
    queue_path = get_queue_dir() / queue_name
    if not queue_path.exists():
        return True
    count = len([f for f in queue_path.iterdir() if f.suffix == '.json'])
    if count >= limit:
        log(f"QUEUE DEPTH LIMIT: {queue_name} has {count}/{limit} items - rejecting new item")
        return False
    return True

def check_crew_rate_limit(crew_number: int, order_id: str) -> bool:
    """Check if a crew has exceeded its per-order item creation limit (v7.0).
    Prevents a single crew from flooding queues during one order execution.
    Returns True if crew can create more items, False if rate limited.
    """
    queues_dir = get_queue_dir()
    count = 0
    # Scan all queue directories for items created by this crew on this order
    for queue_name in ["bugs", "defects", "security", "breakdown", "escalations"]:
        queue_path = queues_dir / queue_name
        if not queue_path.exists():
            continue
        for json_file in queue_path.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                created_by = data.get("createdBy", {})
                if created_by.get("crew") == crew_number and created_by.get("order") == order_id:
                    count += 1
            except Exception:
                continue
    # Also scan request subdirectories
    requests_dir = queues_dir / "requests"
    if requests_dir.exists():
        for subdir in ["investigation", "qa", "planning", "documentation"]:
            subpath = requests_dir / subdir
            if not subpath.exists():
                continue
            for json_file in subpath.glob("*.json"):
                try:
                    data = json.loads(json_file.read_text(encoding='utf-8'))
                    created_by = data.get("createdBy", {})
                    if created_by.get("crew") == crew_number and created_by.get("order") == order_id:
                        count += 1
                except Exception:
                    continue

    if count >= MAX_CREW_ITEMS_PER_ORDER:
        log(f"CREW RATE LIMIT: Crew {crew_number} has created {count}/{MAX_CREW_ITEMS_PER_ORDER} items for order {order_id} - rejecting")
        return False
    return True

def create_bug_report(crew_number: int, role: str, order_id: str,
                      title: str, description: str, priority: str = "NORMAL") -> Optional[str]:
    """
    Create a bug report in the queue (v5.0).
    Returns the bug ID if successful, None if not permitted.
    """
    if not can_create_item(role, "bugs"):
        log(f"PERMISSION DENIED: Role {role} cannot create bugs")
        return None
    if not check_queue_depth("bugs"):
        return None
    if not check_crew_rate_limit(crew_number, order_id):
        return None

    bug_id = generate_queue_id("BUG")
    queue_item = {
        "id": bug_id,
        "type": "BUG",
        "priority": priority,
        "status": "PENDING",
        "createdBy": {
            "crew": crew_number,
            "role": role,
            "order": order_id
        },
        "createdAt": datetime.now().isoformat(),
        "title": title,
        "description": description,
        "targetRole": "SHP"
    }

    queue_file = get_queue_dir() / "bugs" / f"{bug_id}.json"
    queue_file.parent.mkdir(parents=True, exist_ok=True)
    queue_file.write_text(json.dumps(queue_item, indent=2), encoding='utf-8')

    log(f"BUG CREATED: {bug_id} - {title}")
    return bug_id

def create_defect_report(crew_number: int, role: str, order_id: str,
                         title: str, description: str, severity: str = "NORMAL") -> Optional[str]:
    """
    Create a defect report in the queue (v5.0 - BOS only).
    Returns the defect ID if successful, None if not permitted.
    """
    if not can_create_item(role, "defects"):
        log(f"PERMISSION DENIED: Role {role} cannot create defects")
        return None
    if not check_queue_depth("defects"):
        return None
    if not check_crew_rate_limit(crew_number, order_id):
        return None

    defect_id = generate_queue_id("DEF")
    queue_item = {
        "id": defect_id,
        "type": "DEFECT",
        "priority": "NORMAL+" if severity == "HIGH" else "NORMAL",
        "status": "PENDING",
        "createdBy": {
            "crew": crew_number,
            "role": role,
            "order": order_id
        },
        "createdAt": datetime.now().isoformat(),
        "title": title,
        "description": description,
        "severity": severity,
        "targetRole": "SHP"
    }

    queue_file = get_queue_dir() / "defects" / f"{defect_id}.json"
    queue_file.parent.mkdir(parents=True, exist_ok=True)
    queue_file.write_text(json.dumps(queue_item, indent=2), encoding='utf-8')

    log(f"DEFECT CREATED: {defect_id} - {title}")
    return defect_id

def create_security_issue(crew_number: int, role: str, order_id: str,
                          title: str, description: str, severity: str = "HIGH") -> Optional[str]:
    """
    Create a security issue in the queue (v5.0 - LKT only).
    Returns the security issue ID if successful, None if not permitted.
    """
    if not can_create_item(role, "security"):
        log(f"PERMISSION DENIED: Role {role} cannot create security issues")
        return None
    if not check_queue_depth("security"):
        return None
    if not check_crew_rate_limit(crew_number, order_id):
        return None

    sec_id = generate_queue_id("SEC")
    queue_item = {
        "id": sec_id,
        "type": "SECURITY",
        "priority": "HIGH" if severity == "CRITICAL" else "NORMAL+",
        "status": "PENDING",
        "createdBy": {
            "crew": crew_number,
            "role": role,
            "order": order_id
        },
        "createdAt": datetime.now().isoformat(),
        "title": title,
        "description": description,
        "severity": severity,
        "targetRole": "SHP"
    }

    queue_file = get_queue_dir() / "security" / f"{sec_id}.json"
    queue_file.parent.mkdir(parents=True, exist_ok=True)
    queue_file.write_text(json.dumps(queue_item, indent=2), encoding='utf-8')

    log(f"SECURITY ISSUE CREATED: {sec_id} - {title}")
    return sec_id

def request_investigation(crew_number: int, role: str, order_id: str,
                          title: str, description: str) -> Optional[str]:
    """
    Request an investigation from LKT (v5.0).
    Returns the request ID if successful, None if not permitted.
    """
    if not can_request_service(role, "investigation"):
        log(f"PERMISSION DENIED: Role {role} cannot request investigations")
        return None
    if not check_crew_rate_limit(crew_number, order_id):
        return None

    req_id = generate_queue_id("REQ-INV")
    queue_item = {
        "id": req_id,
        "type": "REQUEST",
        "requestType": "INVESTIGATION",
        "priority": "HIGH",
        "status": "PENDING",
        "createdBy": {
            "crew": crew_number,
            "role": role,
            "order": order_id
        },
        "createdAt": datetime.now().isoformat(),
        "title": title,
        "description": description,
        "targetRole": "LKT"
    }

    queue_file = get_queue_dir() / "requests" / "investigation" / f"{req_id}.json"
    queue_file.parent.mkdir(parents=True, exist_ok=True)
    queue_file.write_text(json.dumps(queue_item, indent=2), encoding='utf-8')

    log(f"INVESTIGATION REQUESTED: {req_id} - {title}")
    return req_id

def request_qa(crew_number: int, role: str, order_id: str,
               title: str, description: str) -> Optional[str]:
    """
    Request QA from BOS (v5.0).
    Returns the request ID if successful, None if not permitted.
    """
    if not can_request_service(role, "qa"):
        log(f"PERMISSION DENIED: Role {role} cannot request QA")
        return None
    if not check_crew_rate_limit(crew_number, order_id):
        return None

    req_id = generate_queue_id("REQ-QA")
    queue_item = {
        "id": req_id,
        "type": "REQUEST",
        "requestType": "QA",
        "priority": "HIGH",
        "status": "PENDING",
        "createdBy": {
            "crew": crew_number,
            "role": role,
            "order": order_id
        },
        "createdAt": datetime.now().isoformat(),
        "title": title,
        "description": description,
        "targetRole": "BOS"
    }

    queue_file = get_queue_dir() / "requests" / "qa" / f"{req_id}.json"
    queue_file.parent.mkdir(parents=True, exist_ok=True)
    queue_file.write_text(json.dumps(queue_item, indent=2), encoding='utf-8')

    log(f"QA REQUESTED: {req_id} - {title}")
    return req_id


def request_planning(crew_number: int, role: str, order_id: str,
                     title: str, description: str, report_path: str) -> Optional[str]:
    """
    Request planning/breakdown from NAV based on investigation findings (v5.0).
    Used by LKT after completing an investigation with findings.
    Returns the request ID if successful, None if not permitted.
    """
    if not can_request_service(role, "planning"):
        log(f"PERMISSION DENIED: Role {role} cannot request planning")
        return None
    if not check_crew_rate_limit(crew_number, order_id):
        return None

    req_id = generate_queue_id("REQ-PLAN")
    queue_item = {
        "id": req_id,
        "type": "REQUEST",
        "requestType": "PLANNING",
        "priority": "HIGH",
        "status": "PENDING",
        "createdBy": {
            "crew": crew_number,
            "role": role,
            "order": order_id
        },
        "createdAt": datetime.now().isoformat(),
        "title": title,
        "description": description,
        "reportPath": report_path,  # Path to LKT investigation report
        "targetRole": "NAV"
    }

    queue_file = get_queue_dir() / "requests" / "planning" / f"{req_id}.json"
    queue_file.parent.mkdir(parents=True, exist_ok=True)
    queue_file.write_text(json.dumps(queue_item, indent=2), encoding='utf-8')

    log(f"PLANNING REQUESTED: {req_id} - {title}")
    log(f"  Report: {report_path}")
    return req_id

def create_breakdown_order(crew_number: int, role: str, parent_order_id: str,
                           title: str, description: str, target_role: str) -> Optional[str]:
    """
    Create a breakdown sub-order from a high-level order (v5.0).
    Only NAV, LKT, COX can break down orders.
    Returns the order ID if successful, None if not permitted.
    """
    if not can_breakdown_orders(role):
        log(f"PERMISSION DENIED: Role {role} cannot break down orders")
        return None
    if not check_queue_depth("breakdown"):
        return None
    if not check_crew_rate_limit(crew_number, parent_order_id):
        return None

    order_id = generate_queue_id("SUB")
    queue_item = {
        "id": order_id,
        "type": "ORDER",
        "orderType": "BREAKDOWN",
        "priority": "LOW",
        "status": "PENDING",
        "createdBy": {
            "crew": crew_number,
            "role": role,
            "order": parent_order_id
        },
        "parentOrder": parent_order_id,
        "createdAt": datetime.now().isoformat(),
        "title": title,
        "description": description,
        "targetRole": target_role
    }

    queue_file = get_queue_dir() / "breakdown" / f"{order_id}.json"
    queue_file.parent.mkdir(parents=True, exist_ok=True)
    queue_file.write_text(json.dumps(queue_item, indent=2), encoding='utf-8')

    log(f"BREAKDOWN ORDER CREATED: {order_id} - {title} (target: {target_role})")
    return order_id

def create_escalation(crew_number: int, role: str, order_id: str,
                      title: str, description: str, decision_needed: str,
                      blocking: bool = False, voyage_id: str = None) -> Optional[str]:
    """
    Create an escalation requiring Captain/QM decision (v7.0).
    Any role can escalate — no permission check needed.
    If blocking=True, dispatcher holds all orders for the same voyageId.
    Returns the escalation ID if successful, None if queue is full.
    """
    if not check_queue_depth("escalations"):
        return None
    if not check_crew_rate_limit(crew_number, order_id):
        return None

    esc_id = generate_queue_id("ESC")
    queue_item = {
        "id": esc_id,
        "type": "ESCALATION",
        "status": "PENDING",
        "blocking": blocking,
        "createdBy": {
            "crew": crew_number,
            "role": role,
            "order": order_id
        },
        "createdAt": datetime.now().isoformat(),
        "title": title,
        "description": description,
        "decisionNeeded": decision_needed,
        "voyageId": voyage_id,
        "resolution": None
    }

    queue_file = get_queue_dir() / "escalations" / f"{esc_id}.json"
    queue_file.parent.mkdir(parents=True, exist_ok=True)
    queue_file.write_text(json.dumps(queue_item, indent=2), encoding='utf-8')

    block_str = " [BLOCKING]" if blocking else ""
    log(f"ESCALATION CREATED{block_str}: {esc_id} - {title}")
    log(f"  Decision needed: {decision_needed}")
    return esc_id

# ============================================================================
# PROMPT BUILDING
# ============================================================================

def load_role_template(role: str, minimal: bool = True) -> str:
    """Load role definition via the overlay loader (SEC-0185 / FTR-0186).

    Resolution order:
      1. Effective merged role from maestro.roles.loader (core + optional overlay)
      2. Legacy workspace template files (prompts/templates/{role}-minimal.md etc.)
      3. Bare "# Role: {role}" fallback

    The overlay loader is attempted first so per-org overlays automatically
    propagate to crew sessions.
    """
    try:
        from maestro.roles.loader import load_effective_role
        ws = get_artefact_root()
        role_def = load_effective_role(role.upper(), ws)
        return role_def.to_markdown()
    except Exception:
        pass

    # Legacy fallback: workspace template files
    if minimal:
        minimal_file = get_artefact_root() / f"prompts/templates/{role}-minimal.md"
        if minimal_file.exists():
            return minimal_file.read_text(encoding='utf-8')

    template_file = get_artefact_root() / f"prompts/templates/{role}-template.md"
    if template_file.exists():
        return template_file.read_text(encoding='utf-8')
    return f"# Role: {role}"

def build_prompt(crew_number: int, iteration: int, max_iterations: int,
                 role: str, order_id: str, task_prompt: str,
                 completion_promise: str = "COMPLETE",
                 timeout_minutes: Optional[int] = None) -> str:
    """Build a focused prompt for Claude - optimized for performance.

    *timeout_minutes* (BUG-MSO-2026-0698) is the crew's resolved wall-clock
    ceiling, surfaced to roles that need to budget against it. Optional so
    every existing caller keeps working unchanged.
    """

    role_injection = load_role_template(role, minimal=True)

    # Only include progress on subsequent iterations
    progress_section = ""
    if iteration > 1:
        progress = read_progress(crew_number)
        progress_section = f"\n## CURRENT PROGRESS\n\n{progress}\n"

    # BUG-MSO-2026-0423 (secondary): on Windows fleets the crew's default shell is
    # PowerShell, where bash-style loop syntax (`for f in ...; do ... done`) is a
    # PARSER error that kills the whole iteration (exit 0xFFFFFFFF). Steer crews to
    # portable syntax so this deterministic class of failure stops recurring.
    shell_note = ""
    if os.name == "nt":
        shell_note = (
            "\n## SHELL SYNTAX (Windows)\n\n"
            "Your Bash tool runs POSIX sh; other shell calls may hit **PowerShell**. "
            "Do NOT assume bash. Avoid bash-only constructs (`for f in ...; do ... done`, "
            "backtick `$(...)` in a PowerShell context, `&&` chaining on legacy hosts). "
            "Prefer the dedicated Glob/Grep/Read/Edit tools over shell loops, or write a "
            "`.py` helper and run it with `python`. A shell/parser syntax error kills the "
            "whole iteration.\n"
        )

    # BUG-MSO-2026-0583: hand every crew the RESOLVED absolute artefact root
    # directly in the prompt, instead of relying solely on each role doc's own
    # $MAESTRO_ARTEFACT_ROOT note (several role docs lacked one) plus the crew
    # reading the env var itself. Fixes the class of "relative .mso/... write
    # denied by the BUG-MSO-2026-0465 path guard" bugs at the source, not just
    # the docs. Best-effort: a resolution failure here must never break prompt
    # building, so it silently degrades to no note (the role doc's own text,
    # where present, still applies).
    artefact_root_note = ""
    try:
        _root = get_artefact_root()
        artefact_root_note = (
            "\n## ARTEFACT ROOT\n\n"
            f"Durable artefacts (handoffs, reports, plans) MUST be written under the "
            f"ABSOLUTE path `{_root}` — never a relative `.mso/...` path. Your working "
            f"directory is a per-crew git worktree carrying its own throwaway `.mso/` "
            f"mirror; a relative path resolves THERE and is lost when the worktree is "
            f"pruned (BUG-MSO-2026-0465). Example: `{_root}/handoffs/{order_id}/...`. "
            f"The one exception is `.mso/crews/crew{crew_number}/progress.md`, which is "
            f"always fine relative (BUG-MSO-2026-0501).\n"
        )
    except Exception:
        pass

    # BUG-MSO-2026-0698 AC-3: TST is the one role whose scope is decided by a
    # command the WORKSPACE owns (the verify gate) and whose ceiling is
    # therefore not budgetable without knowing what that command does. Hand it
    # those facts instead of letting it infer them.
    tst_note = ""
    if (role or "").upper() in ("TST", "BOS"):
        try:
            tst_note = build_tst_guidance(order_id, timeout_minutes)
        except Exception:
            tst_note = ""

    # PLAN-PLN-MSO-2026-0747 Order 4: REL is the voyage-completion gate and
    # needs the same kind of role-scoped steering TST already gets — the
    # absolute artefact-root report path (BUG-MSO-2026-0583's naming trap),
    # the provider-verb-only outward path, and the refusals that make the
    # merge/tag/publish/issue boundary load-bearing in the prompt, not only
    # in maestro/roles/REL.md.
    rel_note = ""
    if (role or "").upper() in ("REL", "COX"):
        try:
            rel_note = build_rel_guidance(order_id, timeout_minutes)
        except Exception:
            rel_note = ""

    # FTR-MSO-2026-0779 (Captain ruling NB-02 option 3): every SEC report opens
    # with a machine-readable `secVerdict` front-matter field, mandated in the
    # prompt as FTR-MSO-2026-0738 mandated `nodeVerdict` for TST.
    sec_note = ""
    if (role or "").upper() in ("SEC", "LKT"):
        try:
            sec_note = build_sec_guidance(order_id)
        except Exception:
            sec_note = ""

    prompt = f"""# CREW {crew_number} | ITERATION {iteration}/{max_iterations} | {role} | {order_id}

{role_injection}

## ORDER

{task_prompt}
{progress_section}{shell_note}{artefact_root_note}{tst_note}{rel_note}{sec_note}
## INSTRUCTIONS

Execute the next step.

**Update `.mso/crews/crew{crew_number}/progress.md` AS YOU GO — not only at the
start, and not only at the end.** Append to it after every step that takes real
time (a test run, a build, a multi-file edit, a commit) with what you just did
and what is left. If you are killed at the wall clock, that file plus your
committed work is the ONLY thing the next crew inherits: a progress.md still
holding the empty template means the next crew starts from zero and burns the
same time again (BUG-MSO-2026-0698). Write the durable deliverables your role
owes — report, handoff — as soon as you have the content for them, not in a
final flourish that a timeout can eat.

When complete: `<promise>{completion_promise}</promise>`
If blocked: `<promise>BLOCKED</promise>`
"""
    # Warn if prompt is large - queue mode recommended for reliability
    if len(prompt) > 3000:
        log(f"  [WARN] Prompt is {len(prompt)} bytes - large prompts may be slow")

    return prompt

# ============================================================================
# CLAUDE EXECUTION
# ============================================================================

# FTR-MSO-2026-0281: module-level cache for the located CLI path and its
# probed capabilities, so the filesystem walk and --help invocation happen
# at most once per process lifetime.
_CLI_PATH: Optional[str] = None
_CLI_CAPS: Optional[dict] = None


def _probe_cli_caps(cli_path: str) -> None:
    """Probe the CLI binary for optional feature flags and cache the result.

    FTR-MSO-2026-0281: runs `<cli> --help` once and records which flags are
    advertised.  Populates the module-level _CLI_CAPS dict so invoke_claude
    can conditionally add --effort without crashing on older CLI versions.
    """
    global _CLI_CAPS
    try:
        result = run_hidden(
            [cli_path, "--help"],
            capture_output=True,
            text=True,
            timeout=15,
            encoding="utf-8",
            errors="replace",
        )
        help_text = result.stdout + result.stderr
        _CLI_CAPS = {
            "effort": "--effort" in help_text,
            "settings": "--settings" in help_text,
        }
        log(f"  [DEBUG] CLI caps probed: effort={_CLI_CAPS['effort']} settings={_CLI_CAPS['settings']}")
    except Exception as exc:
        _CLI_CAPS = {"effort": False, "settings": False}
        log(f"  [WARN] CLI capability probe failed ({exc}); assuming no optional flags.")


def find_claude_cli() -> Optional[str]:
    """Find the Claude CLI executable."""
    global _CLI_PATH
    if _CLI_PATH is not None:
        return _CLI_PATH

    # Try common locations
    possible_paths = [
        "claude",  # In PATH
        "claude.cmd",  # Windows
        os.path.expanduser("~/.npm-global/bin/claude"),
        os.path.expanduser("~/AppData/Roaming/npm/claude.cmd"),
    ]

    for path in possible_paths:
        try:
            result = run_hidden(
                [path, "--version"],
                capture_output=True,
                text=True,
                timeout=10
            )
            if result.returncode == 0:
                _CLI_PATH = path
                _probe_cli_caps(path)
                return _CLI_PATH
        except:
            continue

    return None


def compute_iteration_timeout(timeout_minutes: int) -> int:
    """Seconds a single agent iteration (one `claude --print` call) may run.

    Captain directive 2026-05-20: `timeout_minutes` is the direct per-iteration
    cap, not a total budget divided across iterations. Previously this was
    `max(600, min(1800, (timeout_minutes * 60) // max_iterations))`, which
    contradicted the --timeout flag's own help ("Timeout per iteration in
    minutes") and let a single agent run up to 30 minutes. With the default
    of 25, one iteration now gets exactly 25 minutes and no more.
    """
    return max(1, timeout_minutes) * 60


def parse_crew_result(stdout: str) -> dict:
    """Parse the structured JSON result from `claude --output-format json`.

    FTR-MSO-2026-0193 / Part A: replaces stdout string-grepping with
    deterministic structured result parsing.

    On malformed/empty output (e.g. wall-clock kill mid-stream) returns a
    safe sentinel dict with is_error=True — never classified as COMPLETE.
    """
    stdout = stdout.strip()
    if not stdout:
        return {
            "subtype": "timeout_killed",
            "is_error": True,
            "result": "",
            "total_cost_usd": 0.0,
            "num_turns": 0,
            "session_id": "",
            "terminal_reason": "timeout_killed",
            "errors": ["No output captured (process killed before completion)"],
            # BUG-MSO-2026-0435: cost/turns above are placeholders, not measured
            # values — nothing was ever parsed. Callers must report them as
            # UNKNOWN rather than $0.0000/0 as though the iteration truly cost
            # nothing.
            "metrics_unknown": True,
        }
    try:
        return json.loads(stdout)
    except json.JSONDecodeError:
        return {
            "subtype": "parse_error",
            "is_error": True,
            "result": stdout[:2000],
            "total_cost_usd": 0.0,
            "num_turns": 0,
            "session_id": "",
            "terminal_reason": "parse_error",
            "errors": ["JSON parse failed — truncated or malformed output"],
            # BUG-MSO-2026-0435: see note above — the JSON was unparseable, so
            # these are placeholders, not measured values.
            "metrics_unknown": True,
        }


def _salvage_truncated_result(raw_stdout: str, assistant_turns: int) -> Optional[dict]:
    """BUG-MSO-2026-0279: best-effort recovery of a truncated stream-json result.

    The terminal ``{"type":"result", ...}`` event embeds the full assistant
    transcript in its ``result`` field, which on a large TST/BLD iteration can
    exceed the ~700-900 KB at which the captured stdout gets truncated. When that
    happens the result line is cut off mid-string and ``json.loads`` fails for it,
    so the reverse scan finds no parseable result event.

    Rather than discarding everything as ``parse_error`` (which REQUEUEs and
    wastes a crew that may well have succeeded), extract whatever scalar fields
    survived. The CLI serialises ``subtype``/``is_error``/``num_turns`` BEFORE the
    huge ``result`` string, so the verdict is usually recoverable even when
    ``session_id``/``total_cost_usd`` (which come after) are lost.

    Returns a result-shaped dict (with ``salvaged_from_truncation=True``), or
    None if no result-event fragment is present at all.
    """
    idx = raw_stdout.rfind('{"type":"result"')
    if idx == -1:
        idx = raw_stdout.rfind('{"type": "result"')
    if idx == -1:
        return None
    fragment = raw_stdout[idx:]

    def _grab_str(key: str) -> Optional[str]:
        m = re.search(r'"%s"\s*:\s*"([^"\\]*)"' % key, fragment)
        return m.group(1) if m else None

    def _grab_num(key: str):
        m = re.search(r'"%s"\s*:\s*(-?[0-9]+(?:\.[0-9]+)?)' % key, fragment)
        return float(m.group(1)) if m else None

    def _grab_bool(key: str):
        m = re.search(r'"%s"\s*:\s*(true|false)' % key, fragment)
        return (m.group(1) == "true") if m else None

    subtype = _grab_str("subtype")
    is_error = _grab_bool("is_error")
    session_id = _grab_str("session_id") or ""
    cost = _grab_num("total_cost_usd")
    num_turns_recovered = _grab_num("num_turns")
    num_turns = int(num_turns_recovered) if num_turns_recovered is not None else int(assistant_turns)

    if subtype is None and is_error is None:
        # Couldn't recover the verdict — not safe to call it success. Fall back to
        # an error-flavoured sentinel that still carries the salvaged turns/session
        # so the REQUEUE path + BUG-0023 commit-detection can rescue committed work
        # (and lifecycle telemetry is better than a blind parse_error).
        return {
            "subtype": "parse_error",
            "is_error": True,
            "result": fragment[:2000],
            "total_cost_usd": cost if cost is not None else 0.0,
            "num_turns": num_turns,
            "session_id": session_id,
            "terminal_reason": "parse_error",
            "errors": ["Result event truncated; verdict unrecoverable — salvaged turns/session only"],
            "salvaged_from_truncation": True,
        }

    # Verdict recovered — trust the CLI's own classification (it had already decided
    # success/error before the transcript blob that got truncated).
    resolved_subtype = subtype or ("error" if is_error else "success")
    if is_error is not None:
        resolved_is_error = bool(is_error)
    else:
        # is_error truncated away but subtype survived: ONLY an explicit success
        # subtype is non-error. Anything else (error_during_execution, ...) must
        # classify as an error — never silently fall through to COMPLETE.
        resolved_is_error = resolved_subtype != "success"
    return {
        "subtype": resolved_subtype,
        "is_error": resolved_is_error,
        "result": fragment[:2000],
        "total_cost_usd": cost if cost is not None else 0.0,
        "num_turns": num_turns,
        "session_id": session_id,
        "terminal_reason": resolved_subtype,
        "salvaged_from_truncation": True,
    }


def parse_stream_result(raw_stdout: str) -> dict:
    """Extract the terminal result dict from `--output-format stream-json` output.

    FTR-MSO-2026-0227: stream-json emits one JSON object per line. The final
    event with ``"type": "result"`` is the terminal result object — same shape
    as the single blob produced by ``--output-format json``, so it is fully
    compatible with parse_crew_result / classify_json_terminal downstream.

    Scans lines in reverse so we find the result event without scanning the
    entire (potentially large) stream on every call.
    """
    raw_stdout = raw_stdout.strip()
    if not raw_stdout:
        return parse_crew_result("")  # reuse the timeout_killed sentinel

    lines = raw_stdout.splitlines()
    for line in reversed(lines):
        line = line.strip()
        if not line:
            continue
        try:
            obj = json.loads(line)
        except json.JSONDecodeError:
            continue
        if obj.get("type") == "result":
            return obj

    # No complete result event found — the terminal event may have been truncated
    # mid-line by a large transcript (BUG-MSO-2026-0279). Attempt to salvage the
    # verdict + session_id/turns/cost from the fragment before giving up on it.
    assistant_turns, _ = count_stream_events(raw_stdout)
    salvaged = _salvage_truncated_result(raw_stdout, assistant_turns)
    if salvaged is not None:
        return salvaged

    # Nothing recoverable — treat as parse_error (same sentinel as json mode).
    return parse_crew_result(raw_stdout)


def count_stream_events(raw_stdout: str) -> tuple[int, int]:
    """Count assistant turns and Agent/Task subagent spawns in stream-json output.

    FTR-MSO-2026-0227: returns (turn_count, subagent_count) for state.json.
    - turn_count: number of ``type=assistant`` events (one per Claude turn)
    - subagent_count: number of ``type=tool_use`` events with name in {Agent, Task}

    Safe to call with empty or malformed output; returns (0, 0) in that case.
    """
    turns = 0
    subagents = 0
    for line in raw_stdout.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            obj = json.loads(line)
        except json.JSONDecodeError:
            continue
        ev_type = obj.get("type", "")
        if ev_type == "assistant":
            turns += 1
        elif ev_type == "tool_use" and obj.get("name") in ("Agent", "Task"):
            subagents += 1
    return turns, subagents


def _supervision_stall_seconds() -> int:
    """FTR-MSO-2026-0299: activity-watchdog threshold from workspace config.

    `completion.supervision.stallMinutes` (default 10; 0 disables the
    watchdog). A crew with NO stream output for this long is HUNG and is
    killed + salvaged + requeued — while a crew that keeps streaming turns
    is never killed before the (now generous) wall-clock ceiling.
    """
    try:
        from maestro.workspace import get_artefact_root as _gar
        cfg = json.loads((_gar() / "config" / "workspace.json")
                         .read_text(encoding="utf-8"))
        minutes = ((cfg.get("completion") or {}).get("supervision") or {}).get("stallMinutes", 10)
        return max(0, int(minutes)) * 60
    except Exception:
        return 10 * 60


def _workspace_config() -> Dict[str, Any]:
    """The workspace config block, or {} when unreadable (BUG-MSO-2026-0698)."""
    try:
        from maestro.workspace import get_artefact_root as _gar
        return json.loads((_gar() / "config" / "workspace.json")
                          .read_text(encoding="utf-8"))
    except Exception:
        return {}


def tst_prompt_facts() -> Dict[str, Any]:
    """The verify-gate + full-suite facts TST needs BEFORE it plans its turn
    (BUG-MSO-2026-0698 AC-3).

    Returns ``{"verifyCommand": str, "verifyTimeoutMinutes": int,
    "fullSuiteMinutes": Optional[int]}``.

    ``verifyCommand`` is the load-bearing one. A TST crew that does not know
    what the workspace's verify gate runs has no way to tell whether the full
    suite is its job or the gate's, so it assumes the worst and runs
    everything - which is how FTR-MSO-2026-0618's crew spent two hours on a
    45-minute suite it was never responsible for. On this very workspace the
    gate is ``python -m compileall -q maestro``, deliberately NOT the suite,
    and nothing in the crew's prompt ever said so.

    ``tst.fullSuiteMinutes`` is an optional operator hint: roughly how long a
    full run takes here. It is surfaced only so a crew can decide whether a
    full run FITS in its remaining ceiling - never as an instruction to
    attempt one.
    """
    cfg = _workspace_config()
    try:
        verify_timeout = int(cfg.get("verifyTimeoutMinutes", 20))
    except (TypeError, ValueError):
        verify_timeout = 20
    full_suite = (cfg.get("tst") or {}).get("fullSuiteMinutes")
    try:
        full_suite = int(full_suite) if full_suite is not None else None
        if full_suite is not None and full_suite <= 0:
            full_suite = None
    except (TypeError, ValueError):
        full_suite = None
    return {
        "verifyCommand": (cfg.get("verifyCommand") or "").strip(),
        "verifyTimeoutMinutes": verify_timeout,
        "fullSuiteMinutes": full_suite,
    }


def build_tst_guidance(order_id: str, timeout_minutes: Optional[int] = None) -> str:
    """The TST-only prompt section (BUG-MSO-2026-0698 AC-3).

    Four rules, each traceable to a way a real TST crew burned its ceiling:

    1. **The verify gate owns the full suite.** The dispatcher runs
       ``verifyCommand`` in the crew worktree before every convergence push
       (FTR-MSO-2026-0287) - so on a workspace whose gate runs the suite, the
       suite IS run, by the dispatcher, whatever the crew does.
    2. **Test what this order changed.** FTR-MSO-2026-0618's crew went
       further and tried to TRIAGE ~30 pre-existing environmental failures by
       re-running the suite at the parent commit in a throwaway worktree.
       Those failures are not the order's, and diagnosing them is not what a
       TST turn is for.
    3. **Never pipe pytest through ``tail``/``head``.** That crew's own
       report: a piped run shows zero output under the 120s tool limit and
       reads as a hang - "cost crews 2 and 3 their iterations". Redirect to a
       file and read the file; a run that is writing to a file is visibly
       alive.
    4. **Budget against the ceiling.** State the numbers rather than leaving
       the crew to guess them.
    5. **Every QA report opens with ``nodeVerdict`` front-matter**
       (FTR-MSO-2026-0738, PLAN-PLN-MSO-2026-0726 D3's forward half): ``PASS``
       for APPROVED/CONDITIONAL, ``FAIL`` for REJECTED. A corroborating hint
       for the report readers - the ``## QA Decision`` heading stays the
       primary contract. ``PASS`` is inert for routing: every routing consumer
       acts on ``FAIL`` alone.
    """
    facts = tst_prompt_facts()
    verify_cmd = facts["verifyCommand"]
    lines = [
        "\n## TEST SCOPE + TIME BUDGET (TST)\n",
        "**The local verify gate is the authority for the full suite — not you.**",
    ]
    if verify_cmd:
        lines.append(
            f"This workspace's gate runs `{verify_cmd}` "
            f"(cap {facts['verifyTimeoutMinutes']}m) in your worktree before "
            f"convergence pushes, every time."
        )
        lines.append(
            "Read that command. If it does NOT run the full test suite, the full "
            "suite is NOT your job and you must not spend your ceiling on it."
        )
    else:
        lines.append(
            "This workspace configures NO verify command, so nothing runs a full "
            "suite automatically. Still scope your own run to this order."
        )
    lines.extend([
        "",
        f"**Run only the tests relevant to {order_id}** — the files this order's "
        "voyage touched, plus the tests you write for it — unless the order text "
        "explicitly tells you to run the whole suite.",
        "",
        "**Pre-existing failures are not yours.** If unrelated tests are already "
        "red, record them in your QA report as pre-existing and move on. Do NOT "
        "re-run the suite at a parent commit or in a throwaway worktree to triage "
        "them; that is a separate investigation order, not part of this turn.",
        "",
        "**Redirect pytest output to a file — never pipe it through `tail`/`head`.** "
        "A piped run produces no output until it finishes, which under the tool "
        "time limit is indistinguishable from a hang and has cost real crews their "
        "iterations. Use:",
        "```",
        "python -m pytest tests/test_relevant.py -q > $MAESTRO_TEMP/pytest.log 2>&1",
        "```",
        "then read the log file. Check it while the run is in flight if you need "
        "to see progress.",
        "",
        "**Open EVERY QA report with a `nodeVerdict` front-matter block, whatever "
        "the decision.** The first three lines of "
        f"`QA-{order_id}.md` are `---`, then `nodeVerdict: PASS` (QA Decision "
        "APPROVED or CONDITIONAL) or `nodeVerdict: FAIL` (REJECTED only), then "
        "`---`. No other value — `CONSUMED` is the dispatcher's own stamp, never "
        "yours. The block must agree with your `## QA Decision` status, which "
        "remains the authoritative verdict: report readers parse the headings "
        "first and use the block only to corroborate them, so keep "
        "`## QA Decision`, `## Acceptance Criteria Verification`, "
        "`## Defects Found` and `## Test Summary` exactly as the TST template "
        "names them.",
    ])
    if timeout_minutes:
        lines.extend([
            "",
            f"**Your wall-clock ceiling is {timeout_minutes} minutes for this "
            f"iteration.** Work backwards from it: leave time to write your QA "
            f"report, your handoff, and `acResults` — those are your "
            f"deliverables, and a turn that runs tests until the ceiling and "
            f"writes none of them has produced nothing.",
        ])
    if facts["fullSuiteMinutes"]:
        lines.extend([
            "",
            f"**Operator hint:** a FULL suite run takes about "
            f"{facts['fullSuiteMinutes']} minutes here "
            f"(`tst.fullSuiteMinutes`). Budget a full run ONLY if the verify "
            f"command above actually runs the suite, or the order asks for one, "
            f"AND it fits inside your ceiling with room to spare.",
        ])
    lines.append("")
    return "\n".join(lines)


def sec_report_name(order_id: str) -> str:
    """``SEC-{ORDER-ID}.md``, without doubling a prefix the id already carries.

    A SEC-type order's id already starts with ``SEC-`` — its report is
    ``SEC-MSO-2026-0461.md``, never ``SEC-SEC-MSO-2026-0461.md``
    (BUG-MSO-2026-0465; the contract the ``SEC_ARTEFACT_MISSING`` gate matches).
    """
    oid = (order_id or "").strip()
    return f"{oid}.md" if oid.upper().startswith("SEC-") else f"SEC-{oid}.md"


def build_sec_guidance(order_id: str) -> str:
    """The SEC-only prompt section (FTR-MSO-2026-0779, Captain ruling NB-02 option 3).

    SEC reports carried no machine-readable verdict, so the security report
    reader had to infer one from prose — and free prose (``Subject to F1…``,
    ``contingent on…``) read APPROVED. The fix is at the producer: every SEC
    report, whatever its decision, opens with a ``secVerdict`` front-matter
    field that ``maestro/reports/security_reader.py`` treats as authoritative.
    Restated here, in the prompt, for the reason ``build_tst_guidance`` restates
    FTR-MSO-2026-0738's ``nodeVerdict`` rule: a role doc a crew has loaded is not
    the same as the fact placed in front of it at the moment it writes.

    The Charts contract is unchanged: a REJECTED report still carries
    ``nodeVerdict: FAIL`` — in the same block.
    """
    root = get_artefact_root()
    report_path = f"{root}/reports/security/{sec_report_name(order_id)}"
    lines = [
        "\n## SECURITY REPORT VERDICT FIELD (SEC)\n",
        f"**Your security report is `{report_path}`.**",
        "",
        "**Open EVERY security report with a `secVerdict` front-matter block, "
        "whatever the decision — APPROVED, CONDITIONAL and REJECTED alike.** The "
        "report's first lines are `---`, then `secVerdict: <DECISION>`, then `---`, "
        "BEFORE the `# Security Review` heading:",
        "```",
        "---",
        "secVerdict: APPROVED",
        "---",
        "```",
        "For a REJECTED report the Charts `nodeVerdict: FAIL` line goes in the SAME "
        "block — one block, both keys:",
        "```",
        "---",
        "secVerdict: REJECTED",
        "nodeVerdict: FAIL",
        "---",
        "```",
        "`nodeVerdict` appears ONLY on REJECTED, and `CONSUMED` is the dispatcher's "
        "own stamp, never yours.",
        "",
        "**The value is exactly one of `APPROVED`, `CONDITIONAL`, `REJECTED` — "
        "uppercase, nothing else on the line.** Anything else (a lowercase word, a "
        "trailing aside, the template's `APPROVED | CONDITIONAL | REJECTED`) is "
        "malformed and the report reads UNDETERMINED.",
        "",
        "**It must agree with `## Security Decision` `**Status**`.** The field is "
        "authoritative, and the body is cross-checked against it: a report whose "
        "field and body declare different verdicts reads UNDETERMINED — as does one "
        "whose `## SEC Sign-off` denies or rejects what its decision approved.",
        "",
        "**A qualified approval is `CONDITIONAL`, never `APPROVED` with a caveat in "
        "prose.** If the approval is subject to, contingent on, or blocked behind "
        "anything, the field says `CONDITIONAL` and the conditions are listed under "
        "`## Security Decision`.",
        "",
    ]
    return "\n".join(lines)


def build_rel_guidance(order_id: str, timeout_minutes: Optional[int] = None) -> str:
    """The REL-only prompt section (PLAN-PLN-MSO-2026-0747 Order 4).

    ``maestro/roles/REL.md`` already carries the full checklist, report
    template and ``must_not`` refusals; this section restates the four facts
    a REL crew most needs BEFORE it starts, in the prompt itself, mirroring
    why ``build_tst_guidance`` exists — a role doc a crew has already loaded
    is not the same as a fact placed directly in front of it at the moment
    it acts:

    1. **The exact absolute report path** (BUG-MSO-2026-0583) — REL's ONLY
       deliverable, keyed by the invoking order's id, not the voyage id.
    2. **Every outward step goes through ``mso pr`` verbs**, never a raw
       ``gh``/``curl``/provider REST call — the provider-neutral seam is the
       whole point of PLAN-PLN-MSO-2026-0747.
    3. **The absolute refusals** — never merge, tag, publish, or close/
       transition/re-assign a linked issue — restated here because they are
       the one thing in this prompt a Captain-approval mixup can never
       recover from.
    4. **The degraded-CI wording rule** — a recommendation made with a
       skipped step must never abbreviate to a bare ``READY``.
    """
    root = get_artefact_root()
    report_path = f"{root}/reports/voyage/VOYAGE-{order_id}.md"
    lines = [
        "\n## VOYAGE COMPLETION GUIDANCE (REL)\n",
        "**Your only deliverable is the voyage completion report, at the "
        "ABSOLUTE artefact-root path, named by THIS order's id — never the "
        "voyage id:**",
        f"`{report_path}`",
        "The naming pattern is `VOYAGE-{ORDER-ID}.md`. Writing "
        "`VOYAGE-{VOY-ID}.md` instead leaves the engine's deliverable gate "
        "blind and holds/requeues this order at the LAST role in the "
        "sequence, after every prior role's work is already done "
        "(BUG-MSO-2026-0583). Put the voyage id inside the report, under "
        "`## Voyage`, not in the filename.",
        "",
        "**Every outward step goes through the `mso pr` verbs — never a raw "
        "`gh`/`curl`/provider REST or GraphQL call:**",
        "```",
        "mso pr status | checks | ci-log <check> | threads | "
        "reply <thread> | resolve <thread>",
        "```",
        "This is what makes your checklist run the same way on GitHub, "
        "Bitbucket Cloud, or Bitbucket Data Center — the verb resolves the "
        "configured provider; you never name one directly.",
        "",
        "**Absolute refusals — on every provider, with no exception:**",
        "- Never merge a pull request (`gh pr merge`, a merge REST/GraphQL "
        "call, or a fast-forwarding push). The merge decision is the "
        "Captain's alone; your job ends at a merge RECOMMENDATION written "
        "as text.",
        "- Never tag a release (`git tag`, `git push --tags`, "
        "`git push origin v<anything>`, `gh release create`, or a "
        "provider's release/tag API) and never publish (`twine upload`, "
        "`npm publish`, or triggering a deploy/release job in any CI "
        "system).",
        "- Never close, transition, or re-assign a linked issue or ticket "
        "in GitHub Issues, Jira, or any issues provider — read and report "
        "its state only.",
        "",
        "**Whole-voyage diff review — the one gap no headless tool covers "
        "(checklist step 10):** read the changed hunks across every order "
        "in the voyage looking specifically for the defect classes a "
        "per-order TST pass structurally cannot see — two orders editing "
        "one function, an interface changed by one order and called by "
        "another, or a config key added by one order and defaulted by "
        "another.",
        "",
        "**Degradation is loud, never a pass.** If a provider step is "
        "unavailable, record it `SKIPPED — <reason>` and reflect that in "
        "the recommendation — a skipped CI check means the strongest you "
        "may write is `READY (CI not verified: <reason>)`. Never abbreviate "
        "that to a bare `READY`.",
    ]
    if timeout_minutes:
        lines.extend([
            "",
            f"**Your wall-clock ceiling is {timeout_minutes} minutes for "
            f"this iteration.** CI triage can involve waiting on a check to "
            f"finish — budget for that, and if the ceiling is close, write "
            f"the report with what you have (`SKIPPED — ran out of time`) "
            f"rather than leaving no report at all.",
        ])
    lines.append("")
    return "\n".join(lines)


def _describe_tool_event(name: str, inp: dict) -> str:
    """FTR-MSO-2026-0310: render a tool_use event as a short operator-readable
    action string (e.g. 'Editing crew.py', 'Running: pytest -q')."""
    inp = inp or {}

    def _base(p: str) -> str:
        p = (p or "").replace("\\", "/").rstrip("/")
        return p.rsplit("/", 1)[-1] if p else ""

    if name in ("Edit", "Write", "MultiEdit"):
        f = _base(inp.get("file_path", ""))
        return f"Editing {f}" if f else "Editing"
    if name == "NotebookEdit":
        f = _base(inp.get("notebook_path", ""))
        return f"Editing {f}" if f else "Editing notebook"
    if name == "Read":
        f = _base(inp.get("file_path", ""))
        return f"Reading {f}" if f else "Reading"
    if name == "Bash":
        cmd = " ".join((inp.get("command", "") or "").split())
        return f"Running: {cmd[:48]}" if cmd else "Running command"
    if name in ("Grep", "Glob"):
        pat = inp.get("pattern") or inp.get("query") or ""
        return f"Searching: {pat[:40]}" if pat else "Searching"
    if name in ("Agent", "Task"):
        desc = inp.get("description") or inp.get("subagent_type") or ""
        return f"Spawning agent: {desc[:40]}" if desc else "Spawning agent"
    if name:
        return name
    return ""


def _describe_stream_event(obj: dict) -> str:
    """FTR-MSO-2026-0310: derive a human-readable 'what is the crew doing now'
    string from a single stream-json event. Returns '' for events with no
    meaningful action (so the caller keeps the previous activity)."""
    et = obj.get("type", "")
    if et == "tool_use":
        return _describe_tool_event(obj.get("name", ""), obj.get("input", {}))
    if et == "assistant":
        # An assistant turn may carry text and/or embedded tool_use blocks.
        # Prefer the most recent actionable block; fall back to a text snippet.
        content = (obj.get("message", {}) or {}).get("content", []) or []
        text_snip = ""
        for block in reversed(content):
            if not isinstance(block, dict):
                continue
            bt = block.get("type")
            if bt == "tool_use":
                return _describe_tool_event(block.get("name", ""), block.get("input", {}))
            if bt == "text" and not text_snip:
                text_snip = " ".join((block.get("text", "") or "").split())
        if text_snip:
            return text_snip[:60]
    return ""


def _read_stream_lines(
    stdout_pipe,
    lines_out: list,
    live_state: list,
    on_live_update,
    activity: list = None,
    activity_text: list = None,
    net_distress: list = None,
    live_tokens: list = None,
) -> None:
    """Background thread: read stream-json lines, update live counters.

    FTR-MSO-2026-0227: runs in a daemon thread alongside the Claude subprocess.
    live_state is a two-element list [turn_count, subagent_count] shared with
    the main thread (GIL makes int writes atomic on CPython).
    on_live_update(turns, subagents) is called after each counter change.
    FTR-MSO-2026-0299: activity is a one-element [monotonic_ts] list stamped
    on every PRODUCTIVE line read — the watchdog's liveness signal.
    FTR-MSO-2026-0310: activity_text is a one-element [str] list holding the
    latest operator-readable action; updated before on_live_update fires so the
    callback can persist it to state.json. The 2-arg on_live_update contract is
    unchanged — activity flows through the shared list, not the call signature.
    FTR-MSO-2026-0359: net_distress is a two-element list
    [api_retry_count, last_event_was_api_retry]. The CLI emits
    ``{"type":"system","subtype":"api_retry",...}`` events while it retries an
    unreachable API (up to 10 attempts with exponential backoff — ~30+ minutes).
    Those events are network DISTRESS, not progress: they must NOT refresh the
    activity stamp, or an offline crew looks alive to the stall watchdog for
    the CLI's entire retry window (the 2026-07-14 31-minute silent kill —
    stallMinutes=10 never fired because api_retry lines kept feeding it).
    FTR-MSO-2026-0796: live_tokens is a one-element [int] list accumulating
    ``message.usage`` from each ``assistant`` event — the SAME four-key sum
    (input + output + cache_creation_input + cache_read_input), with the same
    ``<synthetic>``/``unknown``/empty-model skip, as
    ``maestro.hooks.stop.extract_usage_from_transcript``, so the Hub's live
    figure and the usage plane agree. Updated BEFORE on_live_update fires, the
    same shared-list channel as activity_text.
    """
    turns = 0
    subagents = 0
    for raw_line in stdout_pipe:
        lines_out.append(raw_line)
        line = raw_line.strip()
        obj = None
        if line:
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                obj = None
        # FTR-MSO-2026-0359: api_retry = network distress. Count it, flag it,
        # and skip the activity stamp so the stall watchdog reaps a crew whose
        # only sign of life is the CLI retrying an unreachable API.
        if obj is not None and obj.get("type") == "system" \
                and obj.get("subtype") == "api_retry":
            if net_distress is not None:
                net_distress[0] += 1
                net_distress[1] = 1
            continue
        if activity is not None:
            activity[0] = time.monotonic()
        if obj is None:
            continue
        if net_distress is not None:
            net_distress[1] = 0
        ev_type = obj.get("type", "")
        if activity_text is not None:
            desc = _describe_stream_event(obj)
            if desc:
                activity_text[0] = desc
        changed = False
        if ev_type == "assistant":
            turns += 1
            changed = True
            if live_tokens is not None:
                try:
                    msg = obj.get("message") or {}
                    if isinstance(msg, dict):
                        ev_model = msg.get("model", "")
                        if ev_model and ev_model not in ("<synthetic>", "unknown"):
                            usage = msg.get("usage") or {}
                            if isinstance(usage, dict):
                                live_tokens[0] += sum(
                                    int(usage.get(k) or 0)
                                    for k in ("input_tokens", "output_tokens",
                                              "cache_creation_input_tokens",
                                              "cache_read_input_tokens")
                                )
                except (TypeError, ValueError):
                    pass
        elif ev_type == "tool_use" and obj.get("name") in ("Agent", "Task"):
            subagents += 1
            changed = True
        if changed:
            live_state[0] = turns
            live_state[1] = subagents
            if on_live_update is not None:
                try:
                    on_live_update(turns, subagents)
                except Exception:
                    pass


def classify_json_terminal(json_result: dict) -> str:
    """Classify a parsed JSON result into a terminal state.

    FTR-MSO-2026-0193 / Part B: primary classification from structured
    result, NOT stdout string-grep.

    Returns: 'COMPLETE' | 'ERROR' | 'MAX_TURNS'
    """
    subtype = json_result.get("subtype", "")
    if subtype == "error_max_turns":
        return "MAX_TURNS"
    if json_result.get("is_error", False):
        return "ERROR"
    return "COMPLETE"


# FTR-MSO-2026-0359: transport-level error markers surfaced by the CLI / git
# when the network is down (DNS, connect, reset, TLS). Matched case-insensitively
# against the failed result's error/result text.
NETWORK_ERROR_MARKERS = (
    "enotfound", "eai_again", "econnrefused", "econnreset", "etimedout",
    "epipe", "getaddrinfo", "fetch failed", "could not resolve host",
    "could not resolve hostname", "network is unreachable",
    "connection timed out", "connection refused", "socket hang up",
    "tls handshake", "ssl: ", "temporary failure in name resolution",
)

# BUG-MSO-2026-0423: interpreter parse/syntax signatures. A crew that dies with a
# generic abnormal-exit code (-1 / 0xFFFFFFFF / 4294967295) whose stderr carries
# one of these crashed on a DETERMINISTIC code/shell fault — e.g. a bash-style
# `for f in ...; do ... done` loop executed on a PowerShell host — NOT a transient
# outage. Such a fault must classify as CODE (consuming the normal MAX_REQUEUES
# budget), never NETWORK (whose FTR-0359 retry track is budget-exempt); otherwise
# a genuine syntax bug silently burns ~5 crew iterations without ever tripping the
# failure ceiling that exists to stop exactly that. Matched case-insensitively.
CODE_FAULT_MARKERS = (
    # PowerShell parser + command-resolution errors
    "missing variable name after",
    "the correct form is:",
    "parsererror",
    "is not recognized as the name of a cmdlet",
    "is not recognized as an internal or external command",  # cmd.exe
    "unexpected token",
    # POSIX shell (bash/sh) syntax errors
    "syntax error near unexpected token",
    "syntax error: unexpected",
    "unexpected end of file",
    "command not found",
    # Python
    "syntaxerror",
    "indentationerror",
    "taberror",
    "invalid syntax",
)


def _failure_text(json_result: dict) -> str:
    """Lowercased error+result text of a failed iteration.

    Shared by the network + code-fault classifiers so they inspect exactly the
    same surface (the CLI's ``errors`` list plus a bounded slice of ``result``,
    which is where reclassified stderr lands — see the cli_error reclassification
    in ``invoke_claude``).
    """
    errs = json_result.get("errors") or []
    text = " ".join(str(e) for e in errs)
    text = text + " " + str(json_result.get("result", ""))[:2000]
    return text.lower()


def code_fault_signature(json_result: dict) -> Optional[str]:
    """BUG-MSO-2026-0423: the interpreter parse/syntax marker present in a failed
    iteration's stderr/result text, or None.

    A non-None result means the crew crashed on a DETERMINISTIC code/shell fault
    (PowerShell/bash/cmd/python parse or syntax error) rather than a connectivity
    blip — classify it as CODE, not NETWORK, so the normal requeue budget applies.
    """
    if not json_result:
        return None
    text = _failure_text(json_result)
    for marker in CODE_FAULT_MARKERS:
        if marker in text:
            return marker
    return None


def is_code_fault(json_result: dict) -> bool:
    """True if the failed iteration carries an interpreter parse/syntax signature."""
    return code_fault_signature(json_result) is not None


def code_fault_offending_line(json_result: dict, marker: str) -> str:
    """The offending stderr/result line containing `marker`, trimmed for a
    lifecycle event (BUG-MSO-2026-0423 AC-3 — cause visible without crew logs)."""
    candidates = [str(e) for e in (json_result.get("errors") or [])]
    candidates.append(str(json_result.get("result", "")))
    for c in candidates:
        for line in c.splitlines():
            if marker in line.lower():
                return " ".join(line.split())[:200]
    # Marker only matched across the joined text — surface the first error line.
    for c in candidates:
        s = " ".join(c.split())
        if s:
            return s[:200]
    return "(no stderr captured)"


# BUG-MSO-2026-0435: fraction of the iteration's wall-clock ceiling at which
# elapsed time is treated as "the watchdog killed it at the ceiling", not
# "it died offline in seconds". A crew force-killed by the wall-clock timeout
# never gets to emit its --output-format result, so it produces the IDENTICAL
# turns==0/cost==0/no-session signature as a genuine instant offline dropout —
# elapsed time is the only available discriminator between the two. 90% is
# generous enough to absorb scheduler/poll jitter and the process-tree-kill
# drain (stdout_reader.join(timeout=15) etc. in invoke_claude) while staying
# unambiguously far from a dropout that dies in seconds, not tens of minutes.
NETWORK_SIGNAL3_CEILING_RATIO = 0.90


def is_network_failure(json_result: dict, api_retries: int = 0,
                       distress_at_end: bool = False,
                       elapsed_seconds: Optional[float] = None,
                       timeout_seconds: Optional[float] = None) -> bool:
    """FTR-MSO-2026-0359: is this FAILED iteration a network/offline failure?

    Only meaningful on a failure path — callers must not consult it for a
    successful iteration (a crew that rode out a blip via CLI api_retry and
    then finished is a success, not a network failure).

    BUG-MSO-2026-0423: a deterministic interpreter parse/syntax crash is never a
    connectivity failure — it wins over EVERY network signal below (including the
    empty-session parse_error signature it would otherwise trip), so a syntax bug
    is routed down the CODE path (normal requeue budget) instead of the
    budget-exempt NETWORK track.

    Signals, strongest first:
    1. The stream DIED in api_retry distress (last event before the kill/EOF
       was ``system/api_retry``) — the CLI was actively failing to reach the
       API when the iteration ended. Catches mid-work dropouts (turns > 0).
    2. api_retry events observed AND the iteration produced nothing
       (turns == 0) — offline from the start.
    3. The recorded 2026-07-14 dropout signature: parse_error/cli_error/
       timeout_killed with turns == 0, cost == 0 and an empty session id —
       the CLI never completed a single exchange with the API. BUG-MSO-2026-0435:
       a crew killed at its wall-clock ceiling produces this exact same
       signature (the killed process never emits its final result), so this
       signal is suppressed when `elapsed_seconds` is at/near `timeout_seconds`
       (see NETWORK_SIGNAL3_CEILING_RATIO) — the caller classifies that case as
       TIMEOUT instead. Signals 1/2/4 are unaffected: they carry positive
       evidence of connectivity distress independent of how long the iteration
       ran.
    4. Explicit transport error text (DNS/connect/reset/TLS) in the result.
    """
    if not json_result:
        return False
    # BUG-MSO-2026-0423: deterministic code/shell fault — never a network failure.
    if is_code_fault(json_result):
        return False
    if distress_at_end:
        return True
    num_turns = int(json_result.get("num_turns") or 0)
    if api_retries > 0 and num_turns == 0:
        return True
    subtype = json_result.get("subtype", "")
    if (subtype in ("parse_error", "cli_error", "timeout_killed")
            and num_turns == 0
            and not float(json_result.get("total_cost_usd") or 0.0)
            and not json_result.get("session_id", "")):
        near_ceiling = (
            elapsed_seconds is not None
            and timeout_seconds is not None
            and timeout_seconds > 0
            and elapsed_seconds >= NETWORK_SIGNAL3_CEILING_RATIO * timeout_seconds
        )
        if not near_ceiling:
            return True
    return any(marker in _failure_text(json_result) for marker in NETWORK_ERROR_MARKERS)


def _kill_process_tree(pid: int) -> None:
    """Force-kill a process AND all its descendants (BUG-MSO-2026-0206).

    `run_hidden(timeout=)` / `Popen.kill()` only terminate the DIRECT child.
    `claude --print` spawns grandchildren (node / MCP servers) that keep the stdout
    pipe handle open, so the post-timeout cleanup `communicate()` blocks forever and
    the iteration never reaps — orders stalled RUNNING ~1h in VOY-MSO-2026-0054.
    Killing the whole tree closes the pipe so the drain returns.

    BUG-MSO-2026-0661: `os.getpgid(pid)` resolves to whatever process group `pid`
    is actually IN — for a target spawned without `start_new_session=True` (or
    `preexec_fn=os.setsid`), that is the CALLER's own group, inherited from the
    parent. `killpg` on that group kills every process in it, including this
    caller — a helper contracted to "kill this subtree" must never be able to
    kill the process that invoked it. Every real production call site already
    spawns its target with `start_new_session=True` (crew.py, fleet_runner.py,
    run_verbs.py), so this guard never fires there; it exists purely so a future
    caller (or test) that forgets to isolate its process group degrades to a
    no-op instead of destroying its own process tree.
    """
    try:
        if os.name == "nt":
            run_hidden(
                ["taskkill", "/F", "/T", "/PID", str(pid)],
                capture_output=True, timeout=15,
            )
        else:
            import signal as _signal
            try:
                target_pgid = os.getpgid(pid)
                if target_pgid == os.getpgrp():
                    print(
                        f"_kill_process_tree: refusing to killpg group {target_pgid} — "
                        f"it is the caller's own process group (pid {pid} was never given "
                        "its own session); falling back to os.kill(pid) only"
                    )
                    os.kill(pid, _signal.SIGKILL)
                else:
                    os.killpg(target_pgid, _signal.SIGKILL)
            except Exception:
                os.kill(pid, _signal.SIGKILL)
    except Exception:
        pass


def invoke_claude(prompt: str, timeout_seconds: int = 1500,
                  crew_number: int = 0, order_id: str = "",
                  max_iterations: int = 25, completion_promise: str = "COMPLETE",
                  role: str = "", max_turns: int = 25,
                  session_id: str = "", iteration: int = 0,
                  on_live_update=None, live_activity=None,
                  live_tokens=None) -> Dict[str, Any]:
    """Invoke Claude CLI with the given prompt in --print --output-format stream-json mode.

    FTR-MSO-2026-0193: switched from raw stdout to structured JSON result.
    FTR-MSO-2026-0227: switched from --output-format json to stream-json so live
    turn counts and subagent spawns can be tracked while the process runs.
    Adds --output-format stream-json and --max-turns N to the claude invocation.
    The structured JSON result is parsed from the stream and returned under
    result["json_result"]. The terminal result shape is identical to json mode.

    on_live_update: optional callable(turns: int, subagents: int) invoked from a
    background thread on each assistant turn or Agent/Task spawn. Use this to
    write live progress to state.json without blocking the subprocess.

    v8.3: Role-based model selection. Each role gets the optimal model:
      COX → Opus (critical review), NAV/SHP/BOS/SCR → Sonnet, LKT → Haiku (fast scan)

    Injects MAESTRO_ITER_MANAGED=1 so the stop hook exits cleanly rather than
    trying to re-feed prompts via {decision: block}. That mechanism silently
    fails on Windows with CREATE_NO_WINDOW in a DETACHED_PROCESS context
    (BUG-MSO-2026-0029). Iteration control belongs to run_crew()'s for-loop.

    v6.0: No CLI lock needed. Each crew runs as a fully detached independent
    process (launched by fleet-runner v6.0 with DETACHED_PROCESS flags).
    Concurrent API calls are safe when processes are truly independent.
    """
    result = {
        "success": False,
        "output": "",
        "error": None,
        "timed_out": False,
        "lock_failed": False,
        "json_result": {},
    }

    claude_cli = find_claude_cli()
    if not claude_cli:
        result["error"] = "Claude CLI not found. Install with: npm install -g @anthropic-ai/claude-code"
        return result

    try:
        # Run Claude with the prompt (use UTF-8 encoding explicitly)
        # CREATE_NO_WINDOW (0x08000000) prevents console window popup in background mode
        run_kwargs = {}
        if os.name == 'nt':
            run_kwargs['creationflags'] = 0x08000000  # CREATE_NO_WINDOW
        else:
            # BUG-MSO-2026-0206: put the crew in its own process group so a timeout
            # can kill the whole tree (claude + node + MCP grandchildren) via killpg.
            run_kwargs['start_new_session'] = True

        # v8.0: Set environment variables for the fleet stop hook
        # The hook reads MAESTRO_CREW to find the crew's ralph-state.md
        # If MAESTRO_CREW is not set (Captain's session), the hook exits immediately
        env = os.environ.copy()

        # v8.5: Inject NUGET_AUTH_TOKEN for GitHub Packages authentication
        # Crews need this to restore EML.* packages from the private feed.
        # Sources (in priority order): existing env var, gh CLI token
        if not env.get("NUGET_AUTH_TOKEN"):
            try:
                gh_token = run_hidden(
                    ["gh", "auth", "token"],
                    capture_output=True, text=True, timeout=10
                )
                if gh_token.returncode == 0 and gh_token.stdout.strip():
                    env["NUGET_AUTH_TOKEN"] = gh_token.stdout.strip()
                    log("  NuGet auth: injected from gh CLI")
            except Exception:
                log("  NuGet auth: gh CLI not available, NUGET_AUTH_TOKEN not set")

        # v8.14: Centralized temp directory for crew artifacts
        # Prevents crews scattering .local-nuget, build outputs, etc. across the workspace
        #
        # BUG-MSO-2026-0701: this used to be `<installed package dir>/temp`, i.e.
        # INSIDE site-packages — the exact shape of the 136MB shadowing incident
        # and BUG-MSO-2026-0614's 110MB repeat, which made
        # `machine.package-integrity` raise a permanently-unactionable CRITICAL
        # on every LEAD tick (and let one crew's test run put 1.2 GB inside the
        # Python environment overnight). It now defaults to the artefact root's
        # gitignored runtime plane — correct in embedded, solo and shared modes
        # — while an explicit MAESTRO_TEMP in the environment still wins.
        # No try/except around get_artefact_root(): it would be dead weight
        # (BUG-MSO-2026-0701 DEF-004). Later unguarded calls in this same
        # function (`_load_order_data_for`) resolve it too, so a machine where
        # it raises never reaches Popen regardless — and resolve_temp_dir()
        # already owns the no-workspace case via its tier-3 system-temp
        # fallback, which is reachable from every other caller and covered.
        env["MAESTRO_TEMP"] = str(
            ensure_temp_dir(resolve_temp_dir(get_artefact_root(), env)))

        if crew_number > 0:
            env["MAESTRO_CREW"] = str(crew_number)
            env["MAESTRO_ORDER"] = order_id
            env["MAESTRO_MAX_ITERATIONS"] = str(max_iterations)
            env["MAESTRO_COMPLETION_PROMISE"] = completion_promise
            # FTR-MSO-2026-0332: role + iteration for per-iteration JSONL usage records.
            env["MAESTRO_ROLE"] = role or ""
            if iteration > 0:
                env["MAESTRO_ITERATION"] = str(iteration)
            # v8.4: Force headless mode for Playwright tests run by fleet crews
            # Prevents browser windows popping up on the Captain's desktop
            env["K2_TEST_HEADLESS"] = "true"
            # BUG-MSO-2026-0029: The stop hook fires in --print mode and returns
            # {"decision": "block"} to re-feed prompts. On Windows with
            # CREATE_NO_WINDOW in a DETACHED_PROCESS context, this re-feed
            # silently fails and Claude exits with 0-byte stdout, causing every
            # iter to produce empty output. Setting MAESTRO_ITER_MANAGED tells
            # the stop hook that the Python for-loop owns iteration control and
            # it should exit cleanly without blocking.
            env["MAESTRO_ITER_MANAGED"] = "1"

            # FTR-MSO-2026-0392: governed-mode env contract. When the workspace
            # enables governance (governance.governedMode = enforce|warn in
            # workspace.json), stamp MAESTRO_GOVERNED into the crew subprocess so
            # the pretool STEP-1 gate fails CLOSED on any policy-eval error
            # instead of the legacy fail-open behaviour. Off by default — a
            # non-governed workspace never sets this and behaves exactly as before.
            try:
                from maestro.governance import resolve_governed_mode
                _gov_ws = None
                try:
                    # Artefact root holds .mso/config/workspace.json (solo mode
                    # keeps it in the platform repo, not the product repo).
                    _gov_ws = get_artefact_root()
                except Exception:
                    _gov_ws = None
                _gov_mode = resolve_governed_mode(_gov_ws, env)
                if _gov_mode in ("enforce", "warn"):
                    env["MAESTRO_GOVERNED"] = "1" if _gov_mode == "enforce" else "warn"
            except Exception:
                # Governance resolution must never block dispatch; a broken
                # config just leaves governance inactive for this crew.
                pass

        # v8.3 / v2.5.6 (FTR-0129): Resolve model with full override chain
        # (per-order → workspace config → env var → ROLE_MODELS default).
        # Look up the order JSON from disk so per-order `model` overrides apply.
        # FTR-MSO-2026-0281: also resolve context window and effort tiers.
        order_data = _load_order_data_for(order_id) if order_id else {}
        try:
            model = resolve_model_for(role, order_data)
        except ValueError as model_err:
            log(f"  Model resolution failed: {model_err}")
            raise
        context_window = "standard"
        effort = "high"
        try:
            context_window = resolve_context_window_for(role, order_data)
            effort = resolve_effort_for(role, order_data)
        except ValueError as ce:
            log(f"  [WARN] Context/effort resolution failed: {ce}. Using defaults.")
        model_arg = model + "[1m]" if context_window == "1m" else model
        log(f"  Model: {model_arg} | context: {context_window} | effort: {effort} (role={role or 'default'})")

        # Use worktree path as working directory when available (injected via MAESTRO_REPO_PATH).
        work_dir = get_base_dir()
        repo_path = env.get("MAESTRO_REPO_PATH", "")
        if repo_path:
            repo_dir = Path(repo_path)
            if repo_dir.exists() and (repo_dir / ".git").exists():
                work_dir = repo_dir
                log(f"  Working dir: {repo_dir} (managed repo)")
            else:
                log(f"  Working dir: {work_dir} (managed repo not found, using workspace root)")

        # FTR-MSO-2026-0193: add --output-format stream-json (structured stream) and
        # --max-turns N (turn-count cap enforced by Claude Code internally).
        # FTR-MSO-2026-0227: stream-json replaces json so we can parse live turn count
        # and subagent spawns while the process runs. The terminal result event is
        # identical in shape to the json-mode blob — all downstream classifiers work
        # unchanged (MAX_TURNS / COMPLETE / ERROR).
        # Both compose with the wall-clock timeout= cap above:
        #   wall-clock fires first → thread join timeout → timed_out=True
        #   max-turns fires first → exit code 1, subtype=error_max_turns → MAX_TURNS
        # BUG-MSO-2026-0250: the Claude CLI requires --verbose whenever
        # `--print --output-format stream-json` is used; without it the CLI exits
        # immediately with "When using --print, --output-format=stream-json requires
        # --verbose" (subtype=cli_error, turns=0) and NO crew can run. --verbose
        # only adds more JSONL events; the terminal {"type":"result"} event that
        # parse_stream_result keys on is unchanged.
        cmd = [
            claude_cli, "--print", "--dangerously-skip-permissions",
            "--model", model_arg,
            "--output-format", "stream-json", "--verbose",
            "--max-turns", str(max_turns),
        ]
        if session_id:
            cmd += ["--session-id", session_id]
        disallowed = ROLE_DISALLOWED_TOOLS.get(role or "", [])
        if disallowed:
            cmd += ["--disallowedTools", ",".join(disallowed)]
        cli_caps = _CLI_CAPS or {}
        if cli_caps.get("effort") and effort:
            cmd += ["--effort", effort]
        elif not cli_caps.get("effort") and effort not in ("high", ""):
            log(f"  [WARN] CLI lacks --effort support; running at model default (requested: {effort})")

        # BUG-MSO-2026-0206: use Popen with threaded line reading instead of
        # run_hidden(timeout=). FTR-MSO-2026-0227: stream-json requires
        # line-by-line reading anyway, so we combine both concerns here.
        # A background thread drains stdout (parsing events and calling
        # on_live_update after each turn/agent event). The main thread joins
        # the reader with a wall-clock timeout; on expiry it kills the whole
        # process tree so grandchild pipe handles are released quickly.
        proc = popen_hidden(
            cmd,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding='utf-8',
            errors='replace',
            cwd=str(work_dir),
            env=env,
            **run_kwargs
        )

        # BUG-MSO-2026-0500: track this Claude subprocess (and, transitively,
        # every descendant it spawns — bash, find, MSBuild, VBCSCompiler,
        # ...) so the whole tree can be reaped as a unit regardless of how it
        # gets reparented or how the crew itself eventually dies.
        if crew_number > 0:
            try:
                _reap_marker = descendant_reaper.workspace_marker(get_artefact_root())
                descendant_reaper.track_spawn(crew_number, get_crew_dir(crew_number), proc.pid, marker=_reap_marker)
            except Exception:
                pass

        # Write prompt to stdin and close immediately so Claude starts processing.
        try:
            proc.stdin.write(prompt)
            proc.stdin.close()
        except (BrokenPipeError, OSError):
            pass

        # Start background threads to drain both pipes concurrently.
        lines_out: list = []
        live_state = [0, 0]  # [turn_count, subagent_count] — shared with reader thread
        activity = [time.monotonic()]  # FTR-0299: stamped on every productive stream line
        # FTR-0359: [api_retry_count, last_event_was_api_retry] — network distress
        net_distress = [0, 0]
        stdout_reader = threading.Thread(
            target=_read_stream_lines,
            args=(proc.stdout, lines_out, live_state, on_live_update, activity,
                  live_activity, net_distress, live_tokens),  # FTR-0796: live_tokens
            daemon=True,
        )
        stderr_lines: list = []
        stderr_reader = threading.Thread(
            target=lambda: stderr_lines.extend(proc.stderr),
            daemon=True,
        )
        stdout_reader.start()
        stderr_reader.start()

        # FTR-MSO-2026-0299 (GKT): activity-based supervision replaces the
        # single wall-clock join. A wall-clock timeout cannot distinguish
        # slow-but-working from hung — GKT's BLD crew was killed 3x while
        # doing real work. Now: kill as HUNG only when the stream has been
        # SILENT for stallMinutes; the wall-clock timeout remains as a
        # generous absolute ceiling (default 60 minutes; was 25 pre-FTR-0299).
        stall_seconds = _supervision_stall_seconds()
        start_mono = time.monotonic()
        timed_out = False
        hung = False
        while stdout_reader.is_alive():
            # Adaptive poll: cap the wait at 5s for responsive stall checks, but
            # never overshoot the wall-clock ceiling — a short timeout_seconds
            # (incl. 0) must fire promptly, not get rounded up to the poll
            # interval (BUG-MSO-2026-0303 follow-up to FTR-0299).
            _remaining = timeout_seconds - (time.monotonic() - start_mono)
            _poll = min(5.0, max(0.0, _remaining))
            stdout_reader.join(timeout=_poll)
            if not stdout_reader.is_alive():
                break
            now = time.monotonic()
            if now - start_mono >= timeout_seconds:
                timed_out = True
                break
            if stall_seconds and now - activity[0] >= stall_seconds:
                timed_out = True
                hung = True
                break
        if timed_out:
            # Kill the whole process tree so grandchildren release their pipe
            # handles, then give the drain threads a moment to flush.
            _kill_process_tree(proc.pid)
            # BUG-MSO-2026-0500: taskkill /T only reaches processes still
            # LIVE-linked to proc.pid at this instant — reap_crew kills by
            # job/pgid membership instead, which also catches anything that
            # already got reparented out of that tree (e.g. an MSYS quirk).
            if crew_number > 0:
                try:
                    descendant_reaper.reap_crew(crew_number, get_crew_dir(crew_number))
                except Exception:
                    pass
            stdout_reader.join(timeout=15)

        stderr_reader.join(timeout=5)
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            try:
                proc.kill()
            except Exception:
                pass

        raw_stdout = "".join(lines_out)
        raw_stderr = "".join(stderr_lines)

        # FTR-MSO-2026-0359: surface network-distress telemetry from the stream
        # so run_crew can classify an offline death as NETWORK, not TIMEOUT/ERROR.
        result["apiRetries"] = net_distress[0]
        result["netDistressAtEnd"] = bool(net_distress[1])
        # BUG-MSO-2026-0435: elapsed wall-clock time + the configured ceiling —
        # the discriminator is_network_failure needs to tell a genuine ceiling
        # kill apart from an instant offline dropout that shares the same
        # turns==0/cost==0/no-session signature.
        result["elapsed_seconds"] = round(time.monotonic() - start_mono, 1)
        result["timeout_seconds"] = timeout_seconds

        if timed_out:
            result["timed_out"] = True
            result["hung"] = hung
            if hung:
                result["error"] = (
                    f"HUNG: no stream activity for {stall_seconds // 60} minutes "
                    f"(activity watchdog, FTR-0299) — killed and recovered via the "
                    f"timeout path (work salvaged, order requeued)"
                )
            else:
                result["error"] = f"Timed out after {timeout_seconds} seconds (hard ceiling)"
            result["output"] = raw_stdout
            if raw_stderr:
                result["output"] = (raw_stdout + "\n" + raw_stderr).strip()
            result["json_result"] = parse_stream_result(raw_stdout)
            return result

        # With --output-format stream-json, stdout is a sequence of newline-delimited
        # JSON events. The terminal result event has type="result" — same shape as
        # the single blob from json mode. stderr is diagnostic-only.
        raw_stdout = raw_stdout or ""
        result["output"] = raw_stdout
        if raw_stderr:
            result["output"] += "\n" + raw_stderr

        # Parse structured result from stream: find the type="result" event.
        # FTR-MSO-2026-0227: parse_stream_result scans the newline-delimited
        # stream for the terminal result event — same shape as json-mode output.
        json_result = parse_stream_result(raw_stdout)

        # BUG-MSO-2026-0220 (PSG fix #4): a process that exited on its own (NOT a
        # wall-clock timeout — that path is handled above) with empty/garbage stdout
        # and a non-zero code is a CLI ERROR (e.g. "Session ID ... is already in use"),
        # not a timeout. Reclassify so it isn't mislabeled `timeout_killed`, and surface
        # the real stderr reason instead of masking it behind a fake timeout.
        if (json_result.get("subtype") in ("timeout_killed", "parse_error")
                and proc.returncode not in (0, None)):
            stderr_reason = (raw_stderr or "").strip()
            if stderr_reason:
                json_result = {
                    **json_result,
                    "subtype": "cli_error",
                    "terminal_reason": "cli_error",
                    "errors": [stderr_reason[:500]],
                    "result": stderr_reason[:2000],
                }
                result["error"] = stderr_reason[:500]

        result["json_result"] = json_result
        # success = not an error AND not max-turns-hit (both exit with code 1).
        # Preserve raw returncode check as a secondary signal: if returncode==0
        # and json says not-error, it's success. If json says is_error, always failure.
        result["success"] = (proc.returncode == 0 and not json_result.get("is_error", False))

    except Exception as e:
        result["error"] = str(e)

    return result

# ============================================================================
# PREFLIGHT CHECK (FTR-MSO-2026-0194 / PLN Part E)
# ============================================================================

def run_preflight_check(claude_cli: str | None = None, timeout: int = 30) -> dict:
    """Smoke-test the Claude CLI by running a trivial --print invocation.

    Returns {"ok": bool, "exit_code": int, "output": str, "error": str}.

    `claude doctor` is TTY-interactive and cannot be used headlessly (Spike 5).
    This function is the scriptable alternative: it sends a trivial prompt and
    checks for a well-formed success response.

    Set MAESTRO_SKIP_AUTH=1 to bypass (CI environments without a Claude account).
    """
    if os.environ.get("MAESTRO_SKIP_AUTH"):
        return {"ok": True, "exit_code": 0, "output": "(skipped — MAESTRO_SKIP_AUTH)", "error": ""}

    if claude_cli is None:
        claude_cli = find_claude_cli()
    if not claude_cli:
        return {
            "ok": False, "exit_code": -1, "output": "",
            "error": "Claude CLI not found. Install with: npm install -g @anthropic-ai/claude-code",
        }

    try:
        proc = run_hidden(
            [claude_cli, "--print", "--dangerously-skip-permissions",
             "--output-format", "json", "--max-turns", "1"],
            input="Reply with the single word: OK",
            capture_output=True, text=True, timeout=timeout,
            encoding="utf-8", errors="replace",
        )
        if proc.returncode != 0:
            return {
                "ok": False, "exit_code": proc.returncode,
                "output": proc.stdout, "error": proc.stderr or proc.stdout,
            }
        obj = json.loads(proc.stdout)
        if obj.get("subtype") == "success" and not obj.get("is_error"):
            return {"ok": True, "exit_code": 0, "output": proc.stdout, "error": ""}
        return {
            "ok": False, "exit_code": proc.returncode, "output": proc.stdout,
            "error": str(obj.get("result", "Preflight response indicates error")),
        }
    except subprocess.TimeoutExpired:
        return {"ok": False, "exit_code": -1, "output": "", "error": f"Preflight timed out after {timeout}s"}
    except json.JSONDecodeError as exc:
        return {"ok": False, "exit_code": -1, "output": "", "error": f"Preflight returned non-JSON: {exc}"}
    except Exception as exc:
        return {"ok": False, "exit_code": -1, "output": "", "error": str(exc)}


# ============================================================================
# TIMEOUT BRIEFING (v7.3)
# ============================================================================

def generate_timeout_brief(crew_number: int, order_id: str, role: str,
                           iteration: int, max_iterations: int,
                           last_result: Dict[str, Any]) -> str:
    """Generate a brief summarizing work done before timeout.

    v7.3: Called when a crew times out. Captures iteration progress,
    artifacts produced, and partial output from the timed-out iteration.
    The brief is stored in crew state and appended to the order on re-queue.
    """
    crew_dir = get_crew_dir(crew_number)
    lines = []

    lines.append(f"### Timeout Brief — {order_id}")
    lines.append(f"- **Crew:** {crew_number} ({get_squad_name(crew_number)})")
    lines.append(f"- **Role:** {role}")
    lines.append(f"- **Timed out at:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    lines.append(f"- **Iteration:** {iteration} of {max_iterations}")
    lines.append("")

    # List output files from completed iterations
    output_files = sorted(crew_dir.glob("output_*.txt"))
    if output_files:
        lines.append("**Completed iteration outputs:**")
        for f in output_files:
            size = f.stat().st_size
            lines.append(f"- `{f.name}` ({size:,} bytes)")
        lines.append("")

    # Capture partial output from the timed-out iteration
    partial_output = last_result.get("output", "").strip()
    if partial_output:
        # Truncate to last 2000 chars to keep brief manageable
        if len(partial_output) > 2000:
            partial_output = "...(truncated)...\n" + partial_output[-2000:]
        lines.append("**Partial output (timed-out iteration):**")
        lines.append("```")
        lines.append(partial_output)
        lines.append("```")
        lines.append("")
    else:
        lines.append("**Partial output:** None captured (subprocess killed before output flushed)")
        lines.append("")

    # Check state for files changed
    state = read_state(crew_number) or {}
    files_changed = state.get("filesChangedTotal", 0)
    if files_changed > 0:
        lines.append(f"**Files modified during session:** {files_changed}")
        lines.append("")

    return "\n".join(lines)


# ============================================================================
# MAIN EXECUTION (v8.0 — Stop Hook Iteration Control)
# ============================================================================

def run_crew(crew_number: int, role: str, order_id: str, prompt_file: str,
             max_iterations: int = 25, completion_promise: str = "COMPLETE",
             circuit_breaker: int = 3, timeout_minutes: int = 60,
             max_turns: int = 25):
    """Run the crew with Python for-loop iteration control (BUG-MSO-2026-0029 fix).

    FTR-MSO-2026-0193: Each iteration uses --output-format json + --max-turns N.
    Primary completion/error classification comes from the structured JSON result,
    NOT from stdout string-grepping. MAX_TURNS is a distinct terminal state.

    Each iteration calls invoke_claude() once. MAESTRO_ITER_MANAGED=1 is set
    so the stop hook exits cleanly instead of fighting the loop with {decision: block}.
    ralph-state.md is updated at each boundary for fleet_monitor visibility.

    Flow:
      1. Create ralph-state.md (observability — updated by for-loop, not stop hook)
      2. For each iteration: build prompt, call invoke_claude, classify JSON result
      3. On COMPLETE / MAX_TURNS / BLOCKED / error / timeout: exit with appropriate status
    """

    log(f"""
+----------------------------------------------------------+
|  FLEET COMMAND SYSTEM - CREW EXECUTION ENGINE v8.0 (Py)  |
+----------------------------------------------------------+

  Crew:      {crew_number} ({get_squad_name(crew_number)})
  Role:      {role} ({_role_info(role).get('name', 'Unknown')})
  Order:     {order_id}
  Focus:     {_role_info(role).get('focus', 'Unknown')}
  Max Iter:  {max_iterations}
  Max Turns: {max_turns}
  Timeout:   {timeout_minutes} min
  Engine:    Stop Hook (Ralph Wiggum pattern)
""")

    # Check for existing lock
    if check_lock(crew_number):
        log("ERROR: Crew is already running.")
        log("Use --cleanup to force stop, or --status to check.")
        return 1

    # Load task prompt
    prompt_path = get_base_dir() / prompt_file
    if not prompt_path.exists():
        log(f"ERROR: Prompt file not found: {prompt_file}")
        return 1

    task_prompt = prompt_path.read_text(encoding='utf-8')

    # Set lock
    set_lock(crew_number, order_id, role)

    # Initialize state.json (kept for backward compat with fleet-runner/monitor)
    # BUG-MSO-2026-0671 (F4): pidCreateTime lets a reader (e.g.
    # worktrees._crew_worktree_occupied()) corroborate that a live process
    # holding this pid is actually THIS process, not an unrelated one that
    # later reused the same pid — the same identity guard
    # BUG-MSO-2026-0668 (F2) already added to the worktree busy marker.
    from maestro import proc_identity as _proc_identity
    # FTR-MSO-2026-0796: the model this crew runs, for the Hub crew card and
    # drawer. Fail-open (None) — invoke_claude owns the bad-model-id error.
    _state_model, _state_cw = _resolve_state_model(role, order_id)
    state = {
        "crewNumber": crew_number,
        "role": role,
        "orderId": order_id,
        "status": "RUNNING",
        "iteration": 1,
        "maxIterations": max_iterations,
        "maxTurns": max_turns,       # FTR-MSO-2026-0227: configured turn budget
        # BUG-MSO-2026-0698: the RESOLVED wall-clock ceiling for this crew, so
        # the Hub crew card can show it. Without it, an operator watching a
        # crew approach its limit has no way to know what the limit is, or
        # which of the three knobs (order / roleTimeouts / --timeout) set it.
        "timeoutMinutes": timeout_minutes,
        # FTR-MSO-2026-0796: the resolved model (bare id) + context window, and
        # a running token total for THIS crew run (all iterations) from the
        # live stream. Not the per-order usage rollup (usage/orders/*.json).
        "model": _state_model,
        "contextWindow": _state_cw,
        "totalTokens": 0,
        "liveTurn": 0,               # FTR-MSO-2026-0227: live turn counter (stream-json)
        "subagentCount": 0,          # FTR-MSO-2026-0227: Agent/Task spawns this session
        "filesChangedTotal": 0,
        "promptFile": prompt_file,
        "startTime": datetime.now().isoformat(),
        "pid": os.getpid(),
        "pidCreateTime": _proc_identity.process_create_time(os.getpid()),
    }
    write_state(crew_number, state)

    # Initialize progress
    init_progress(crew_number, order_id, role)

    # v8.0: Create ralph state file for stop hook
    create_ralph_state(crew_number, order_id, role, max_iterations, completion_promise)

    # Build prompt once (iteration 1 — hook handles subsequent iterations)
    full_prompt = build_prompt(
        crew_number, 1, max_iterations,
        role, order_id, task_prompt, completion_promise,
        timeout_minutes=timeout_minutes,   # BUG-MSO-2026-0698
    )

    # Save prompt for debugging
    current_prompt_file = get_crew_dir(crew_number) / "current_prompt.md"
    current_prompt_file.write_text(full_prompt, encoding='utf-8')

    # v6.0: Initial startup delay - stagger first API call per crew
    startup_delay = 10 * crew_number
    log(f"[{datetime.now().strftime('%H:%M:%S')}] Startup delay ({startup_delay}s, crew {crew_number} offset)...")
    time.sleep(startup_delay)

    final_status = "UNKNOWN"
    iter_timeout = compute_iteration_timeout(timeout_minutes)

    # BUG-MSO-2026-0220: per-crew-run nonce so re-dispatched orders get fresh
    # session ids (the Claude CLI rejects a previously-used --session-id). One
    # nonce per crew.py launch keeps ids stable across this run's iterations but
    # distinct from any prior (killed/timed-out) attempt's burned sessions.
    run_nonce = uuid.uuid4().hex

    # FTR-MSO-2026-0796: tokens consumed by this run's COMPLETED iterations.
    # A foreground local only — never mutated from the reader thread; the
    # state.json key is only ever set inside a write_state mutate callback.
    run_tokens_base = 0

    try:
        # --print mode: the stop hook fires but MAESTRO_ITER_MANAGED=1 (set in
        # invoke_claude) tells it to exit cleanly so it doesn't try to re-feed
        # prompts via {"decision": "block"} — that fails silently on Windows in
        # a DETACHED_PROCESS context. The Python for-loop here is the single
        # source of truth for iteration control.
        for iteration in range(1, max_iterations + 1):
            # BUG-MSO-2026-0674 (F4): applied via the `mutate` callback, INSIDE
            # write_state's per-crew lock, like every other mutation site in
            # this function — a direct `state["iteration"] = iteration`
            # assignment here ran OUTSIDE the lock while the background
            # reader thread from a still-draining prior iteration (join is
            # only best-effort, `join(timeout=15)`) could be inside the lock
            # serializing its own `_on_live_update` mutate+dumps, reopening
            # the exact `RuntimeError: dictionary changed size during
            # iteration` BUG-MSO-2026-0671 (F2) closed for the OTHER
            # mutation sites.
            # FTR-MSO-2026-0796: invoke_claude re-resolves the model every
            # iteration, so state.json must show what the NEXT invocation runs.
            # Only overwrite on a successful resolution, so a transient
            # order-file read failure never blanks a known model.
            _iter_model, _iter_cw = _resolve_state_model(role, order_id)

            def _apply_iteration_start(s: Dict[str, Any], _iter=iteration,
                                       _m=_iter_model, _cw=_iter_cw) -> None:
                s["iteration"] = _iter
                if _m:
                    s["model"] = _m
                    s["contextWindow"] = _cw
            write_state(crew_number, state, mutate=_apply_iteration_start)

            # Advance ralph-state.md so fleet_monitor shows real-time progress
            advance_ralph_state(crew_number, iteration, "RUNNING")
            write_crew_lifecycle_event(
                "CREW_ITER_BOUNDARY",
                f"crew{crew_number} | {order_id} | iter {iteration}/{max_iterations} | role={role} | STARTING"
            )

            iter_prompt = build_prompt(
                crew_number, iteration, max_iterations,
                role, order_id, task_prompt, completion_promise,
                # BUG-MSO-2026-0698: the ceiling applies to EVERY iteration,
                # not just the first — a TST crew on iteration 4 needs to
                # budget against it exactly as much as one on iteration 1.
                timeout_minutes=timeout_minutes,
            )

            # FTR-MSO-2026-0195 + BUG-MSO-2026-0220: session id per (crew, order,
            # iteration), salted with the per-run nonce so re-dispatch never collides.
            maestro_sid = make_session_id(crew_number, order_id, iteration, run_nonce)

            # BUG-MSO-2026-0674 (F4): mutate-under-lock, same reasoning as
            # _apply_iteration_start above.
            def _apply_session_id(s: Dict[str, Any], _sid=maestro_sid) -> None:
                s["maestroSessionId"] = _sid
            write_state(crew_number, state, mutate=_apply_session_id)

            log(f"[{datetime.now().strftime('%H:%M:%S')}] Invoking Claude (iteration {iteration}/{max_iterations}, maestroSessionId={maestro_sid})...")
            update_heartbeat(crew_number, f"iteration-{iteration}", role)

            # FTR-MSO-2026-0227: reset live counters at the start of each
            # iteration. BUG-MSO-2026-0674 (F4): mutate-under-lock, same
            # reasoning as _apply_iteration_start above.
            def _apply_iteration_reset(s: Dict[str, Any]) -> None:
                s["liveTurn"] = 0
                s["subagentCount"] = 0
                s["activity"] = ""
            write_state(crew_number, state, mutate=_apply_iteration_reset)

            # FTR-MSO-2026-0310: shared 1-element list holding the latest
            # operator-readable action; the reader thread writes it, the
            # callback persists it to state.json for the live monitor.
            live_activity = [""]
            # FTR-MSO-2026-0796: tokens streamed in THIS iteration; the reader
            # thread accumulates, the callback persists base + this.
            live_tokens = [0]

            def _on_live_update(turns: int, subagents: int, _state=state, _cn=crew_number,
                                _act=live_activity, _base=run_tokens_base,
                                _tok=live_tokens) -> None:
                """Called from background reader thread on each streamed event.

                BUG-MSO-2026-0671 (F2): the field assignments are passed as a
                ``mutate`` callback rather than applied here directly, so they
                run INSIDE write_state's per-crew lock — the same critical
                section run_crew's own foreground ``write_state`` call (after
                invoke_claude returns) also uses. This is the fix for the
                dumps-vs-mutation race: two ``json.dumps`` calls could never
                overlap under the pre-existing lock, but a mutation on one
                thread outside the lock while the other thread's json.dumps
                was iterating the same dict still could.
                """
                def _apply(s: Dict[str, Any]) -> None:
                    s["liveTurn"] = turns
                    s["subagentCount"] = subagents
                    s["activity"] = _act[0]
                    s["totalTokens"] = _base + _tok[0]  # FTR-MSO-2026-0796
                write_state(_cn, _state, mutate=_apply)

            result = invoke_claude(
                iter_prompt, iter_timeout,
                crew_number, order_id, max_iterations, completion_promise,
                role=role, max_turns=max_turns,
                session_id=maestro_sid,
                iteration=iteration,
                on_live_update=_on_live_update,
                live_activity=live_activity,
                live_tokens=live_tokens,
            )

            # FTR-MSO-2026-0796: fold this iteration's streamed tokens into the
            # run total (cumulative across iterations — NOT reset per iteration).
            run_tokens_base += live_tokens[0]

            output = result.get("output", "")
            json_result = result.get("json_result", {})

            # FTR-MSO-2026-0193: extract structured fields for state + lifecycle.
            # FTR-MSO-2026-0195: store both IDs: maestroSessionId (ours) and claudeSessionId (Claude's).
            claude_session_id = json_result.get("session_id", "")
            num_turns = json_result.get("num_turns", 0)
            cost_usd = json_result.get("total_cost_usd", 0.0)

            # Update state with structured fields from this iteration.
            # BUG-MSO-2026-0671 (F2): applied via the `mutate` callback (see
            # _on_live_update's docstring above) so this assignment runs
            # inside write_state's lock — the background reader thread from
            # THIS iteration can still be alive here (invoke_claude only
            # join(timeout=15)s it on a timeout) and calling _on_live_update
            # concurrently with this code.
            def _apply_iter_result(s: Dict[str, Any], _run_tokens=run_tokens_base) -> None:
                s["claudeSessionId"] = claude_session_id
                s["numTurns"] = num_turns
                s["totalCostUsd"] = round(float(cost_usd), 6)
                # FTR-MSO-2026-0796: pin the final per-iteration figure even
                # if the last streamed event didn't trigger a live write.
                s["totalTokens"] = _run_tokens
            write_state(crew_number, state, mutate=_apply_iter_result)

            # Save per-iteration output
            out_file = get_crew_dir(crew_number) / f"output_{iteration:02d}.txt"
            out_file.write_text(output, encoding='utf-8')

            log(f"[{datetime.now().strftime('%H:%M:%S')}] Iteration {iteration} complete.")
            # BUG-MSO-2026-0220 (PSG fix #5): on a failed iteration, surface the real
            # reason (stderr / error text) into the lifecycle line so operators don't
            # have to spelunk per-crew output_final.txt to learn why a crew died.
            _reason = ""
            if json_result.get("is_error"):
                _errs = json_result.get("errors") or []
                _reason = (_errs[0] if _errs else json_result.get("result", "")) or ""
                _reason = " | reason=" + " ".join(str(_reason).split())[:200]
            # FTR-MSO-2026-0359: surface API-retry distress in the boundary event
            # so post-mortems can spot network trouble even on survived blips.
            _net_tel = ""
            if result.get("apiRetries", 0):
                _net_tel = (f" apiRetries={result.get('apiRetries', 0)}"
                            f" netDistressAtEnd={int(bool(result.get('netDistressAtEnd')))}")
            # BUG-MSO-2026-0435: a killed iteration with unparseable output never
            # had cost/turns measured — report UNKNOWN instead of printing the
            # sentinel $0.0000/0 placeholders as though they were observed values.
            if json_result.get("metrics_unknown"):
                _cost_str, _turns_str = "UNKNOWN", "UNKNOWN"
            else:
                _cost_str, _turns_str = f"${cost_usd:.4f}", str(num_turns)
            write_crew_lifecycle_event(
                "CREW_ITER_BOUNDARY",
                f"crew{crew_number} | {order_id} | iter {iteration}/{max_iterations} | role={role} | DONE"
                f" subtype={json_result.get('subtype', 'unknown')}"
                f" cost={_cost_str} turns={_turns_str}"
                f" maestroSession={maestro_sid} claudeSession={claude_session_id}"
                f"{_net_tel}{_reason}"
            )

            # FTR-MSO-2026-0359: NETWORK classification — consulted only on
            # failure paths below. A crew that rode out a blip (api_retry events
            # but ultimately succeeded) is never reclassified.
            # BUG-MSO-2026-0435: elapsed/timeout_seconds let signal 3 tell a
            # genuine wall-clock ceiling kill apart from an instant offline death.
            _network_failed = is_network_failure(
                json_result,
                api_retries=result.get("apiRetries", 0),
                distress_at_end=result.get("netDistressAtEnd", False),
                elapsed_seconds=result.get("elapsed_seconds"),
                timeout_seconds=result.get("timeout_seconds", iter_timeout),
            )
            # BUG-MSO-2026-0423: deterministic interpreter parse/syntax crash
            # (e.g. bash loop syntax on a PowerShell host). Takes precedence over
            # NETWORK so the failure consumes the normal MAX_REQUEUES budget.
            _code_fault_sig = code_fault_signature(json_result)

            def _classify_code_fault(_reason_kind: str) -> None:
                """Set CODE status + surface the offending stderr line (AC-3)."""
                _offending = code_fault_offending_line(json_result, _code_fault_sig)
                log(f"[{datetime.now().strftime('%H:%M:%S')}] CODE fault "
                    f"({_code_fault_sig!r}) via {_reason_kind} — classifying as CODE, "
                    f"not NETWORK (deterministic syntax/shell fault, BUG-0423)")
                write_crew_lifecycle_event(
                    "CODE_FAULT",
                    f"crew{crew_number} | {order_id} | iter {iteration}/{max_iterations} | "
                    f"role={role} | deterministic {_code_fault_sig!r} fault — CODE "
                    f"(normal requeue budget); stderr: {_offending}"
                )

            if result["timed_out"]:
                log(f"[{datetime.now().strftime('%H:%M:%S')}] TIMEOUT on iteration {iteration}")
                brief = generate_timeout_brief(
                    crew_number, order_id, role, iteration, max_iterations, result
                )
                # BUG-MSO-2026-0674 (F4): mutate-under-lock, same reasoning as
                # _apply_iteration_start above — the background reader thread
                # from this very iteration can still be alive here (invoke_
                # claude only join(timeout=15)s it) and calling
                # _on_live_update concurrently.
                def _apply_timeout_brief(s: Dict[str, Any], _brief=brief) -> None:
                    s["timeoutBrief"] = _brief
                write_state(crew_number, state, mutate=_apply_timeout_brief)
                brief_file = get_crew_dir(crew_number) / f"timeout_brief_{order_id}.md"
                brief_file.write_text(brief, encoding='utf-8')
                if _network_failed:
                    log(f"[{datetime.now().strftime('%H:%M:%S')}] Network dropout signature "
                        f"(apiRetries={result.get('apiRetries', 0)}) — classifying as NETWORK, not TIMEOUT")
                    final_status = "NETWORK"
                else:
                    final_status = "TIMEOUT"
                    # BUG-MSO-2026-0435: explicit event naming the ceiling and
                    # elapsed time — an operator must be able to tell a genuine
                    # wall-clock timeout apart from a NETWORK dropout by reading
                    # lifecycle.log alone, without cross-referencing crew output.
                    _elapsed = result.get("elapsed_seconds")
                    _ceiling = result.get("timeout_seconds", iter_timeout)
                    _pct = f"{(_elapsed / _ceiling * 100):.0f}%" if _elapsed is not None and _ceiling else "?"
                    write_crew_lifecycle_event(
                        "TIMEOUT",
                        f"crew{crew_number} | {order_id} | iter {iteration}/{max_iterations} | "
                        f"role={role} | wall-clock kill at {_elapsed}s of {_ceiling}s ceiling "
                        f"({_pct}) — classified TIMEOUT, not NETWORK (BUG-0435); "
                        f"consumes normal MAX_REQUEUES budget"
                    )
                break

            if result["error"]:
                log(f"[{datetime.now().strftime('%H:%M:%S')}] ERROR: {result['error']}")
                error_lower = result["error"].lower()
                if _code_fault_sig:
                    _classify_code_fault("error text")
                    final_status = "CODE"
                elif _network_failed:
                    final_status = "NETWORK"
                elif "authentication" in error_lower:
                    final_status = "AUTH_ERROR"
                else:
                    final_status = "ERROR"
                break

            # FTR-MSO-2026-0193: PRIMARY classification from structured JSON result.
            # MAX_TURNS is a distinct terminal state (not COMPLETE, not generic ERROR).
            json_terminal = classify_json_terminal(json_result)
            if json_terminal == "MAX_TURNS":
                log(f"\n[{datetime.now().strftime('%H:%M:%S')}] MAX_TURNS hit (iteration {iteration}) — turn cap reached")
                final_status = "MAX_TURNS"
                break

            # Copilot review (PR #87): a structured error (is_error=True — incl.
            # subtype=parse_error / timeout_killed, where the raw/truncated stdout is
            # stored in json_result["result"]) MUST be classified as failure BEFORE the
            # promise-tag check below. Otherwise a malformed/truncated output that happens
            # to contain "<promise>COMPLETE</promise>" would be misread as COMPLETE —
            # defeating the exact BUG-MSO-2026-0023 silent-completion guard this order ships.
            if json_terminal == "ERROR":
                reason = json_result.get("terminal_reason") or json_result.get("subtype") or "json_error"
                if _code_fault_sig:
                    _classify_code_fault(f"json_error/{reason}")
                    final_status = "CODE"
                    break
                if _network_failed:
                    log(f"\n[{datetime.now().strftime('%H:%M:%S')}] JSON result is_error ({reason}) with "
                        f"network dropout signature — classifying as NETWORK (FTR-0359)")
                    final_status = "NETWORK"
                    break
                log(f"\n[{datetime.now().strftime('%H:%M:%S')}] JSON result is_error ({reason}) — classifying as failure, not COMPLETE")
                final_status = "ERROR"
                break

            # SECONDARY signal: <promise> tags inside the assistant's result text.
            # These remain load-bearing for roles that emit them; the JSON primary
            # classification catches the case where no promise tag appears.
            result_text = json_result.get("result", output)
            if f"<promise>{completion_promise}</promise>" in result_text:
                log(f"\n[{datetime.now().strftime('%H:%M:%S')}] COMPLETION detected (iteration {iteration})!")
                final_status = "COMPLETE"
                break

            if "<promise>BLOCKED</promise>" in result_text:
                log(f"\n[{datetime.now().strftime('%H:%M:%S')}] BLOCKED detected (iteration {iteration})!")
                final_status = "BLOCKED"
                break

            # BUG-MSO-2026-0280 (defect A): JSON primary — subtype=success means the
            # crew is DONE. Break immediately instead of looping to a next iteration
            # that could emit BLOCKED and mislabel a successful completion.
            if json_terminal == "COMPLETE":
                log(f"\n[{datetime.now().strftime('%H:%M:%S')}] JSON result: success — order complete (BUG-0280)")
                final_status = "COMPLETE"
                break

            # BUG-MSO-2026-0438: UNREACHABLE — kept as a defensive terminator, not
            # as a continuation. classify_json_terminal() returns exactly one of
            # COMPLETE / ERROR / MAX_TURNS and every one of them breaks above, as do
            # the timeout, lock-failure, error-text and BLOCKED paths. There is no
            # route to a second iteration, so the old
            # "Not complete — continuing to next iteration..." log and the loop's
            # `else: final_status = MAX_ITERATIONS` clause could never execute.
            #
            # Under MAESTRO_ITER_MANAGED this is the CORRECT model, not a defect:
            # the Python for-loop owns iteration and each invoke_claude() runs a
            # full Claude session to its own completion, so one invocation IS the
            # unit of work. Retries happen by re-dispatch with fresh context (the
            # Ralph model), not by looping inside a single crew process.
            #
            # If classification ever grows a genuine not-complete outcome, this
            # branch is where continuation would go — but it must then be a
            # deliberate design change, not an accident. Until then, falling
            # through here means classification returned something unhandled;
            # terminate rather than silently spin.
            # ERROR, not `final_status or ...`: every path that assigns
            # final_status also breaks, so reaching here means it is still the
            # "UNKNOWN" sentinel — which fleet_runner's TERMINAL_STATUSES does not
            # recognise, and an unrecognised status is worse than an honest error.
            log(f"[{datetime.now().strftime('%H:%M:%S')}] Unclassified result — terminating iteration")
            final_status = "ERROR"
            break

        # Copy last output to canonical file
        last_out = get_crew_dir(crew_number) / f"output_{state['iteration']:02d}.txt"
        if last_out.exists():
            (get_crew_dir(crew_number) / "output_final.txt").write_text(
                last_out.read_text(encoding='utf-8'), encoding='utf-8'
            )

    except KeyboardInterrupt:
        log("\n\nInterrupted by user.")
        final_status = "INTERRUPTED"
    except Exception as e:
        log(f"\nError: {e}")
        final_status = "ERROR"
    finally:
        # BUG-MSO-2026-0674 (F4): status/endTime/usage are computed here but
        # applied via the `mutate` callback below, INSIDE write_state's lock
        # — not assigned onto the shared `state` dict directly, which ran
        # OUTSIDE the lock and could interleave with a still-alive background
        # reader thread's own locked `_on_live_update` mutate+dumps (invoke_
        # claude only join(timeout=15)s that thread on a timeout, so it can
        # still be running here), reopening the exact `RuntimeError:
        # dictionary changed size during iteration` BUG-MSO-2026-0671 (F2)
        # closed for every OTHER mutation site in this function.
        final_end_time = datetime.now().isoformat()

        # v2.0.6: Load token usage captured by stop hook
        usage_payload: Optional[Dict[str, Any]] = None
        try:
            usage_file = get_artefact_root() / "usage" / "orders" / f"{order_id}.json"
            if usage_file.exists():
                with open(usage_file, encoding="utf-8") as uf:
                    usage_data = json.load(uf)
                usage_payload = {
                    "total_tokens": usage_data.get("total_tokens", 0),
                    "estimated_cost_usd": usage_data.get("estimated_cost_usd", 0),
                    "models": usage_data.get("models", {}),
                }
                log(f"[{datetime.now().strftime('%H:%M:%S')}] Token usage: {usage_payload['total_tokens']:,} tokens, ${usage_payload['estimated_cost_usd']:.2f}")
        except Exception:
            pass  # Fail-open: never block for usage tracking

        def _apply_terminal_state(s: Dict[str, Any]) -> None:
            s["status"] = final_status
            s["endTime"] = final_end_time
            if usage_payload is not None:
                s["usage"] = usage_payload

        # BUG-MSO-2026-0660 (F3): terminal=True — this write has no "next
        # cycle" to retry on, unlike every other write_state() call above.
        write_state(crew_number, state, terminal=True, mutate=_apply_terminal_state)

        # BUG-MSO-2026-0500: the crew's own lifecycle is ending (COMPLETE,
        # ERROR, INTERRUPTED, or iterations exhausted) — kill anything still
        # tracked under this crew's descendant group so no find/MSBuild/
        # VBCSCompiler/shell survives past the crew that spawned it.
        try:
            reaped = descendant_reaper.reap_crew(crew_number, get_crew_dir(crew_number))
            if reaped:
                log(f"[{datetime.now().strftime('%H:%M:%S')}] Reaped {len(reaped)} descendant process(es) at crew shutdown: {reaped}")
        except Exception:
            pass

        # Clear lock
        clear_lock(crew_number)

    log(f"""
===========================================================
  VOYAGE {final_status}
===========================================================

Final Status: {final_status}
Iterations:   {state.get('iteration', 0)}
""")

    return 0 if final_status == "COMPLETE" else 1

# ============================================================================
# STATUS & CLEANUP
# ============================================================================

def show_status(crew_number: int):
    """Show crew status."""
    state = read_state(crew_number)

    print(f"""
+----------------------------------------------------------+
|  CREW {crew_number} ({get_squad_name(crew_number)}) STATUS
+----------------------------------------------------------+
""")

    if not state:
        print("  Status: INACTIVE (no state file)")
        return

    role = state.get('role', 'Unknown')
    role_name = _role_info(role).get('name', '')

    print(f"  Status:     {state.get('status', 'Unknown')}")
    print(f"  Role:       {role} ({role_name})")
    print(f"  Order:      {state.get('orderId', 'None')}")
    print(f"  Iteration:  {state.get('iteration', 0)} / {state.get('maxIterations', 0)}")
    print(f"  Started:    {state.get('startTime', 'Unknown')}")
    print(f"  PID:        {state.get('pid', 'Unknown')}")

    # Check heartbeat
    heartbeat_file = get_crew_dir(crew_number) / "heartbeat.txt"
    if heartbeat_file.exists():
        try:
            heartbeat_time = datetime.fromisoformat(heartbeat_file.read_text().strip())
            age = int((datetime.now() - heartbeat_time).total_seconds())
            print(f"  Heartbeat:  {age}s ago")
        except:
            pass

def watch_crew(crew_number: int, interval: int = 5):
    """Watch crew progress in real-time."""
    # FTR-MSO-2026-0408: enable in-process VT/ANSI + UTF-8 once so the ANSI
    # clear_console() below renders on legacy Windows conhost (the old
    # os.system('cls') needed no VT). No-ops when detached / non-Windows.
    init_console()
    print(f"Watching Crew {crew_number} (Ctrl+C to stop)...\n")

    last_progress = ""
    last_iteration = 0

    try:
        while True:
            # Clear screen (works on Windows and Unix).
            # FTR-MSO-2026-0408: was os.system('cls'/'clear') — each spawned a
            # shell (a console flash when the crew runs detached). In-process
            # ANSI clear that no-ops when no console is attached.
            clear_console()

            # Show status header
            state = read_state(crew_number)
            crew_name = get_squad_name(crew_number)

            print(f"+----------------------------------------------------------+")
            print(f"|  CREW {crew_number} ({crew_name}) - LIVE MONITOR")
            print(f"+----------------------------------------------------------+")
            print(f"  Time: {datetime.now().strftime('%H:%M:%S')}")
            print()

            if not state:
                print("  Status: INACTIVE")
                print("\n  Waiting for crew to start...")
            else:
                role = state.get('role', '?')
                role_name = _role_info(role).get('name', '')
                status = state.get('status', 'Unknown')
                iteration = state.get('iteration', 0)
                max_iter = state.get('maxIterations', 0)

                # Status color indicator
                status_indicator = {
                    'RUNNING': '[*]',
                    'COMPLETE': '[+]',
                    'BLOCKED': '[!]',
                    'ERROR': '[X]'
                }.get(status, '[ ]')

                print(f"  {status_indicator} Status:    {status}")
                print(f"      Role:      {role} ({role_name})")
                print(f"      Order:     {state.get('orderId', 'None')}")
                print(f"      Progress:  {iteration} / {max_iter} iterations")

                # Heartbeat
                heartbeat_file = get_crew_dir(crew_number) / "heartbeat.txt"
                if heartbeat_file.exists():
                    try:
                        hb_time = datetime.fromisoformat(heartbeat_file.read_text().strip())
                        age = int((datetime.now() - hb_time).total_seconds())
                        hb_status = "OK" if age < 120 else "STALE" if age < 300 else "DEAD"
                        print(f"      Heartbeat: {age}s ago ({hb_status})")
                    except:
                        pass

                # Show progress file content
                progress_file = get_crew_dir(crew_number) / "progress.md"
                if progress_file.exists():
                    progress = progress_file.read_text(encoding='utf-8')
                    print("\n  --- PROGRESS ---")
                    # Show last 20 lines of progress
                    lines = progress.strip().split('\n')
                    for line in lines[-20:]:
                        print(f"  {line}")

                # Check if completed
                if status in ['COMPLETE', 'BLOCKED', 'ERROR', 'MAX_ITERATIONS']:
                    print(f"\n  >>> Voyage ended with status: {status}")
                    break

            print(f"\n  (Refreshing every {interval}s - Ctrl+C to stop)")
            time.sleep(interval)

    except KeyboardInterrupt:
        print("\n\nStopped watching.")

def cleanup_crew(crew_number: int):
    """Cleanup crew processes and locks."""
    print(f"Cleaning up Crew {crew_number}...")

    state = read_state(crew_number)
    if state and state.get('pid'):
        pid = state['pid']
        try:
            # Try to kill the process
            if sys.platform == 'win32':
                run_hidden(['taskkill', '/F', '/PID', str(pid)],
                             capture_output=True)
            else:
                run_hidden(['kill', '-9', str(pid)], capture_output=True)
            print(f"  Killed process {pid}")
        except:
            pass

    clear_lock(crew_number)

    # BUG-MSO-2026-0500: reap this crew's descendant group even though this
    # `--cleanup` invocation is a FRESH process, not the one that spawned the
    # tree — reopen by name (Windows) / read the persisted pgid (POSIX).
    try:
        crew_dir_for_reap = get_crew_dir(crew_number)
        marker = descendant_reaper.workspace_marker(get_artefact_root())
        reaped = descendant_reaper.reap_crew_by_name(crew_number, crew_dir_for_reap, marker)
        if reaped:
            print(f"  Reaped {len(reaped)} descendant process(es): {reaped}")
    except Exception:
        pass

    # v8.1: Clean hook data files
    crew_dir = get_crew_dir(crew_number)
    # BUG-MSO-2026-0713: `mso squad --cleanup` / `mso cleanup` runs on a crew
    # that has just died — often the exact run an operator will need to explain.
    # Retain it before unlinking. Fails open; cleanup proceeds either way.
    try:
        from maestro.core import crew_history
        retained = crew_history.rotate_crew_run(crew_number)
        if retained is not None:
            print(f"  Previous run retained at {retained}")
    except Exception:
        pass
    for filename in ["activity.jsonl", "activity.txt", "files_modified.json", "notifications.log"]:
        filepath = crew_dir / filename
        if filepath.exists():
            try:
                filepath.unlink()
            except Exception:
                pass

    print("Cleanup complete.")

# ============================================================================
# MAIN
# ============================================================================

def _canonical_role_arg(value: str) -> str:
    """argparse ``type`` for ``--role``: fold a legacy nautical alias to its
    canonical code, leave anything else untouched so argparse's own ``choices``
    check produces the ordinary "invalid choice" message (BUG-MSO-2026-0714)."""
    return _normalise_role(value) or (value or "").strip().upper()


def build_crew_parser() -> argparse.ArgumentParser:
    """Build the crew CLI argument parser (extracted from main() for testability — Copilot PR #87)."""
    parser = argparse.ArgumentParser(
        description="Maestro - Crew Execution Engine"
    )
    parser.add_argument("--crew", "-c", type=int, default=1, choices=[1,2,3,4,5],
                       help="Crew number (1-5)")
    # Accept both canonical (PLN/BLD/TST/DOC/SEC/REL/LEAD) and legacy nautical
    # codes (NAV/SHP/BOS/SCR/LKT/COX/QM) for backward compat.
    #
    # BUG-MSO-2026-0714: this comment was here already and was NOT TRUE — the
    # choices list was `list(ROLE_INFO.keys())`, the seven canonical codes
    # only, so `crew.py --role SHP` died with argparse exit 2 exactly the way
    # `--role INV` did. That matters because `mso bug` writes
    # `targetRole: "SHP"` / `roleSequence: ["SHP", "BOS"]` to this day, and
    # CLAUDE.md documents the legacy codes as valid order content. The
    # vocabulary now comes from maestro.roles.validation, the same module the
    # filing-time and scan-time gates consult, so the launcher and the
    # validators cannot drift apart again — that drift is the bug.
    #
    # `type=_canonical_role_arg` folds the accepted value to its canonical
    # code before anything downstream sees it, so ROLE_INFO / ROLE_PERMISSIONS
    # / ROLE_DISALLOWED_TOOLS lookups (all canonical-keyed) resolve for a
    # legacy spelling instead of silently returning {}.
    parser.add_argument("--role", "-r", type=_canonical_role_arg,
                       choices=list(_DISPATCHABLE_ROLE_CODES),
                       help="Role code: PLN/BLD/TST/DOC/SEC/REL/LEAD "
                            "(legacy NAV/SHP/BOS/SCR/LKT/COX/QM accepted)")
    parser.add_argument("--order", "-o", type=str,
                       help="Order ID")
    parser.add_argument("--prompt", "-p", type=str,
                       help="Path to prompt file (relative to project root)")
    parser.add_argument("--max-iterations", "-m", type=int, default=20,
                       help="Maximum iterations (default: 20)")
    parser.add_argument("--timeout", "-t", type=int, default=60,
                       help="Per-iteration wall-clock CEILING in minutes (default: 60). The FTR-0299 activity watchdog (completion.supervision.stallMinutes) is the primary hang control.")
    parser.add_argument("--max-turns", type=int, default=25,
                       help="Max Claude turns per iteration (default: 25)")
    parser.add_argument("--spawn-marker", type=str, default="",
                       help="Inert workspace marker so cleanup's orphan sweep can find this process tree (BUG-MSO-2026-0302)")
    parser.add_argument("--circuit-breaker", type=int, default=3,
                       help="Iterations with no progress before stopping (default: 3)")
    parser.add_argument("--status", "-s", action="store_true",
                       help="Show crew status")
    parser.add_argument("--watch", "-w", action="store_true",
                       help="Watch crew progress in real-time")
    parser.add_argument("--watch-interval", type=int, default=5,
                       help="Watch refresh interval in seconds (default: 5)")
    parser.add_argument("--cleanup", action="store_true",
                       help="Cleanup crew processes and locks")
    return parser


def main():
    parser = build_crew_parser()
    args = parser.parse_args()

    if args.watch:
        watch_crew(args.crew, args.watch_interval)
        return 0

    if args.status:
        show_status(args.crew)
        return 0

    if args.cleanup:
        cleanup_crew(args.crew)
        return 0

    # Validate required args
    if not args.role:
        parser.error("--role is required for running")
    if not args.order:
        parser.error("--order is required for running")
    if not args.prompt:
        parser.error("--prompt is required for running")

    return run_crew(
        crew_number=args.crew,
        role=args.role,
        order_id=args.order,
        prompt_file=args.prompt,
        max_iterations=args.max_iterations,
        timeout_minutes=args.timeout,
        circuit_breaker=args.circuit_breaker,
        max_turns=args.max_turns
    )

if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as e:
        # Log error to file for debugging
        error_log = get_artefact_root() / "logs" / "crew-errors.log"
        error_log.parent.mkdir(parents=True, exist_ok=True)
        with open(error_log, "a", encoding="utf-8") as f:
            f.write(f"\n[{datetime.now().isoformat()}] CREW CRASH\n")
            f.write(f"Error: {e}\n")
            import traceback
            f.write(traceback.format_exc())
            f.write("\n")

        print(f"\n\n*** CREW CRASHED ***")
        print(f"Error: {e}")
        print(f"See {error_log} for details")
        print("\nPress Enter to close...")
        try:
            input()
        except:
            pass
        sys.exit(1)


# ---------------------------------------------------------------------------
# Rebrand vocabulary (FTR-MSO-2026-0155) — new canonical names
# ---------------------------------------------------------------------------

class Squad:
    """Namespace sentinel for a crew/squad execution unit."""


# Legacy alias — kept through v3.x, removed in v4.0
Crew = Squad  # legacy alias (v3.x); removed v4.0
