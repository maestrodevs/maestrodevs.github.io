# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Attach an EXISTING order to a voyage — two writes, one outcome (BUG-MSO-2026-0794).

Voyage membership is recorded in TWO places, and the engine reads both:

* the order's own ``voyageId`` / ``voyageBranch`` — ``voyageBranch`` is
  load-bearing for branch discipline (BUG-ADM-2026-0004; the pretool guard
  denies any git mutation targeting another branch), and
* the voyage manifest's ``orders[]`` — which ``voyages_outstanding_work`` and
  the BUG-MSO-2026-0303 completion guard read, and the order's own claim of
  membership is not.

Writing one without the other strands the order: an order naming a voyage whose
manifest does not list it is invisible to that voyage's completion guard and
produces a false finish later. Before this module no verb on ANY surface wrote
both for an order that already existed — ``voyage_core.attach_order`` writes
only the manifest, ``order_create.edit_order`` only the order, and recovery was a
LEAD hand-editing two JSON files (BUG-MSO-2026-0787/0791). That is why the
Hub's ``OrderEditRequest`` deliberately refuses ``voyageId``/``voyageBranch``:
a PATCH field could only ever be half of this.

:func:`attach_order_to_voyage` is the one implementation. ``mso order attach``
and ``POST /api/v1/orders/{id}/attach`` both call it, and nothing else writes
either side on their behalf.

**Ordering and rollback.** Every refusal is decided before any write. Then the
order is written (through ``edit_order``, so the status rule, the
``editedBy``/``editedAt`` stamp and the atomic tmp+replace are not duplicated),
then the manifest. If the manifest write raises, or returns without listing the
order, the order file is restored to its ORIGINAL BYTES and the failure is
re-raised. If even the restore fails, the error names both facts — what the
order now says and which manifest does not list it — because that is the one
state an operator cannot recover from the response otherwise.

Module contract — the one ``maestro/core/order_retry.py`` states, not re-derived:

* **Explicit ``mso: Path`` throughout. No ``find_workspace()``, no CWD.**
* **Typed exceptions, no printing, no ``sys.exit``.**
  ``OrderValidationError`` -> 400; ``OrderNotFound`` / ``VoyageNotFound`` ->
  404; ``OrderAttachRefused`` / ``VoyageOrderRefused`` / ``OrderEditRefused``
  -> 409; ``CapabilityDenied`` -> 403.
* **Every mutation runs inside ``order_retry.workspace_scope(mso)``.**
* ``require_capability("order.create")`` is enforced here, the same gate
  ``edit_order`` uses — one gate for "author an order".

No git side effect and no push: this inherits whatever the plane's normal
commit/push path does, exactly as edit and skip do.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List

from maestro.core import order_create, voyage_core
from maestro.core.order_ids import OrderValidationError
from maestro.core.order_retry import workspace_scope


class OrderAttachRefused(Exception):
    """The attach could not be applied as asked. Maps to HTTP 409."""

    def __init__(self, order_id: str, message: str, hint: str = "") -> None:
        self.order_id = order_id
        self.hint = hint
        super().__init__(message)


@dataclass
class AttachedOrder:
    """Result of :func:`attach_order_to_voyage` — every field read back from disk."""

    order_id: str
    voyage_id: str
    voyage_branch: str
    order_path: Path
    voyage_path: Path
    order: Dict[str, Any]
    voyage_order_ids: List[str] = field(default_factory=list)
    #: False when the order AND the manifest already agreed — nothing written.
    changed: bool = True


def _read_json(path: Path) -> Dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise OrderValidationError(f"{path} does not contain a JSON object")
    return data


def _restore_bytes(path: Path, original: bytes) -> str:
    """Put *original* back at *path* atomically. Returns "" or the error."""
    try:
        tmp = path.with_suffix(".attach-rollback.tmp")
        tmp.write_bytes(original)
        tmp.replace(path)
        return ""
    except OSError as exc:
        return str(exc)


def attach_order_to_voyage(mso: Path, order_id: str, voyage_id: str, *,
                           attached_by: str = "cli") -> AttachedOrder:
    """Attach queued order *order_id* to active voyage *voyage_id*, both sides.

    Refuses (nothing written) when the voyage is unknown or archived, the order
    is unknown, the order is in flight or terminal (outside
    ``order_create.EDITABLE_STATUSES``), or the order already belongs to a
    DIFFERENT voyage — moving between voyages is detach + attach, and detach
    couples to the skip list (``mso order remove --from-voyage``).

    ``voyageBranch`` comes from the manifest's ``branch``, never from a caller.
    A manifest with no ``branch`` leaves the order's ``voyageBranch`` untouched
    for the dispatcher to resolve, rather than inventing a name.

    Idempotent: an order whose ``voyageId`` and ``voyageBranch`` already match
    and which the manifest already lists returns ``changed=False`` and rewrites
    nothing.
    """
    from maestro.identity.gate import require_capability

    mso = Path(mso)
    order_id = (order_id or "").strip()
    voyage_id = (voyage_id or "").strip()
    if not order_id:
        raise OrderValidationError("Order ID is required")
    if not voyage_id:
        raise OrderValidationError("Voyage ID is required")

    require_capability("order.create", workspace=mso.parent)

    with workspace_scope(mso):
        # ---- Resolve both sides; refuse before any write ------------------
        loaded = voyage_core.load_voyage(mso, voyage_id)
        if loaded.archived:
            raise voyage_core.VoyageOrderRefused(
                loaded.voyage_id, order_id,
                f"Voyage {loaded.voyage_id} is archived — its manifest is a "
                "completion record, not a work queue.",
                hint="Create a new voyage for further work.",
            )
        target_voyage = loaded.voyage_id
        branch = str(loaded.voyage.get("branch") or "")

        path = order_create.find_order_file(mso, order_id)
        if path is None:
            raise order_create.OrderNotFound(order_id)
        try:
            original = path.read_bytes()
            order = json.loads(original.decode("utf-8"))
        except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise OrderValidationError(f"Cannot read order file {path}: {exc}")
        if not isinstance(order, dict):
            raise OrderValidationError(f"Order file {path} does not contain a JSON object")

        status = str(order.get("status") or "").upper()
        if status not in order_create.EDITABLE_STATUSES:
            raise OrderAttachRefused(
                order_id,
                f"Order {order_id} is {status or 'UNKNOWN'} — only "
                f"{', '.join(sorted(order_create.EDITABLE_STATUSES))} orders can "
                "be attached to a voyage. Attaching an in-flight or finished "
                "order rewrites the premise a crew already worked from.",
                hint=f"A stranded order can be reopened first: mso order retry {order_id}",
            )

        current_voyage = str(order.get("voyageId") or "").strip()
        if current_voyage and current_voyage != target_voyage:
            raise OrderAttachRefused(
                order_id,
                f"Order {order_id} already belongs to voyage {current_voyage} — "
                f"attaching it to {target_voyage} would leave it listed in two "
                "manifests.",
                hint=(f"Detach it first: mso order remove {order_id} "
                      f"--from-voyage {current_voyage} (this also skips it; "
                      f"mso order unskip {order_id} after attaching)"),
            )

        listed = order_id in voyage_core.voyage_order_ids(loaded.voyage)
        branch_ok = (not branch) or str(order.get("voyageBranch") or "") == branch
        if current_voyage == target_voyage and listed and branch_ok:
            return AttachedOrder(
                order_id=order_id, voyage_id=target_voyage,
                voyage_branch=str(order.get("voyageBranch") or ""),
                order_path=path, voyage_path=loaded.path, order=order,
                voyage_order_ids=voyage_core.voyage_order_ids(loaded.voyage),
                changed=False,
            )

        # ---- Write 1: the order ------------------------------------------
        updates: Dict[str, Any] = {"voyageId": target_voyage}
        if branch:
            updates["voyageBranch"] = branch
        edited = order_create.edit_order(mso, order_id, updates, edited_by=attached_by)
        order_changed = bool(edited.changed_fields)

        # ---- Write 2: the manifest, or roll write 1 back -----------------
        def _rollback_and_describe(reason: str) -> str:
            if not order_changed:
                return reason
            restore_error = _restore_bytes(path, original)
            if not restore_error:
                return reason
            return (
                f"{reason} The order file could NOT be restored ({restore_error}): "
                f"{path} now says voyageId={target_voyage}, and the manifest "
                f"{loaded.path} does not list {order_id}. Fix one side by hand."
            )

        try:
            updated = voyage_core.attach_order(
                mso, target_voyage, order_id,
                title=str(edited.order.get("title") or ""))
        except Exception as exc:
            detail = _rollback_and_describe("")
            if detail:
                raise OrderAttachRefused(
                    order_id,
                    f"Attaching {order_id} to {target_voyage}'s manifest failed "
                    f"({exc}).{detail}") from exc
            raise

        if order_id not in updated.order_ids:
            raise OrderAttachRefused(
                order_id,
                _rollback_and_describe(
                    f"The manifest {loaded.path} did not record {order_id} after "
                    "attaching — the order was not changed."),
            )

        # ---- Read both back; report what is on disk, not what was intended
        final_order = _read_json(path)
        final_voyage = _read_json(loaded.path)
        return AttachedOrder(
            order_id=order_id,
            voyage_id=target_voyage,
            voyage_branch=str(final_order.get("voyageBranch") or ""),
            order_path=path,
            voyage_path=loaded.path,
            order=final_order,
            voyage_order_ids=voyage_core.voyage_order_ids(final_voyage),
            changed=order_changed or updated.changed,
        )
