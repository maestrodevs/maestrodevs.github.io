# Maestro — Owner & Developer Guide

> For framework owners and maintainers. If you're a commercial user looking to get started, see [GETTING-STARTED.md](GETTING-STARTED.md).

---

## Contents

1. [Repository Overview](#1-repository-overview)
2. [Branch Strategy](#2-branch-strategy)
3. [Development Workflow](#3-development-workflow)
4. [Versioning](#4-versioning)
5. [Cutting a Release](#5-cutting-a-release)
6. [Adding a New Project](#6-adding-a-new-project)
7. [Managing Project State](#7-managing-project-state)
   - [7.5 Captain Review Workflow (AWAITING_APPROVAL)](#75-captain-review-workflow-awaiting_approval)
   - [7.6 Budget Enforcement and Billing Mode](#76-budget-enforcement-and-billing-mode)
8. [Commercial Licensing Strategy](#8-commercial-licensing-strategy)
9. [Maintenance Workflows](#9-maintenance-workflows)
10. [Workspace Backup Strategy](#10-workspace-backup-strategy)
11. [CLI Reference](#11-cli-reference)
12. [Collaborator Access Management](#12-collaborator-access-management)

---

## 1. Repository Overview

```
tavisbasing/Maestro/
├── .maestro/                  # Maestro (runtime + config)
│   ├── core/                    # fleet-runner.py, crew.py, fleet_monitor.py, etc.
│   ├── config/                  # workspace.json, projects.json, role-paths.json
│   │   └── projects/            # Per-project config files ({ACRONYM}.json)
│   ├── hooks/                   # Claude Code hooks (stop, pretool, posttool, notification)
│   ├── orders/                  # ADM order tracking (active, complete, failed)
│   ├── voyages/                 # ADM voyage tracking
│   ├── queues/                  # Dispatch queues (orders, bugs, security, etc.)
│   ├── plans/                   # Navigator planning documents
│   ├── crews/                   # Per-crew runtime state
│   └── CHAIN-OF-COMMAND.md      # Technical specification
├── maestro/                   # Python package (pip-installable CLI)
│   ├── __init__.py              # Version + title
│   ├── cli.py                   # Entry points for all mso commands
│   └── init.py                  # `mso init` scaffold logic
├── docs/                        # End-user and owner documentation
├── pyproject.toml               # pip package definition
├── README.md                    # GitHub-facing project overview
└── CLAUDE.md                    # Quartermaster instructions (this workspace)
```

**Key principle:** The Maestro repo is both the framework source and the pip package. The `maestro/` Python package is the canonical source. No duplication of logic.

---

## 2. Branch Strategy

### Branch Types

| Branch Pattern | Purpose | Who Uses It |
|----------------|---------|-------------|
| `main` | Clean framework. No project state. The installable package. | Everyone |
| `maestro/{description}` | Framework changes: core scripts, CLI, hooks, config | Owner/QM |
| `project/{ACRONYM}` | Project-specific state: orders, voyages, prompts, plans | Per-project |

### Rules

- **`main` is always clean.** No project state (`orders/`, `voyages/`, `prompts/`, crew runtime files) on `main`.
- **Framework changes** (`maestro/`, `pyproject.toml`, `docs/`) go on `maestro/` branches, then PR to `main`.
- **Project state** for a given project lives on `project/{ACRONYM}` branches. These branches layer project state on top of `main`.
- **Never** bundle framework changes with project state in the same branch or PR.

### Example Flows

**Developing a framework feature:**
```bash
git checkout main
git pull
git checkout -b maestro/new-feature
# ... make changes ...
git push -u origin maestro/new-feature
# Open PR → main
```

**Managing ADM (Maestro self-development) project state:**
```bash
# The Maestro repo uses main branch for its own ADM project state
# since this workspace IS the framework repo
git checkout main
# Orders, voyages, etc. are committed directly to main for ADM work
```

---

## 3. Development Workflow

### Prerequisites

- Python 3.9+
- [Claude Code](https://claude.ai/code) CLI installed and authenticated
- Anthropic API key with access to Sonnet 4.6, Haiku 4.5, and Opus 4.7
- `pip install -e .` from the Maestro repo root

### Local Development Setup

```bash
# Clone the repo
git clone https://github.com/tavisbasing/Maestro
cd Maestro

# Install in editable mode (development)
pip install -e .

# Verify
mso version
```

With editable install, changes to `maestro/` take effect immediately without reinstalling. Changes to `.maestro/core/*.py` scripts also take effect immediately since the CLI delegates via subprocess.

### Making Framework Changes

1. **Create a branch:** `git checkout -b maestro/{description}`
2. **Make changes** to core scripts, CLI, hooks, or docs
3. **Test locally** — run against a real workspace with crews
4. **Update version** if warranted (see [Versioning](#4-versioning))
5. **Update documentation** — CHAIN-OF-COMMAND.md, .maestro/CLAUDE.md, root CLAUDE.md
6. **Open PR** to `main`

### Testing Changes

There is currently no automated test suite. Validation is manual:

```bash
# Test pip CLI
mso version
mso init --project TEST --directory /tmp/test-workspace

# Test dispatch (from a workspace with queued orders)
mso dispatch --max-crews 2

# Test monitor
mso status --once

# Test cleanup
mso cleanup
```

For major changes to the hook system or dispatcher, validate token tracking is preserved:
```bash
# After a crew completes, check usage file exists
ls .maestro/usage/orders/
mso usage --summary
```

---

## 4. Versioning

### Version Number Format

`{major}.{minor}.{patch}` — currently `2.0.0`.

The major.minor tracks the Maestro version (v2.0) Patch increments for bug fixes.

### Files to Update on Version Bump

When bumping the Maestro version, update **all** of these:

| File | What to Change |
|------|---------------|
| `pyproject.toml` | `version = "X.Y.Z"` |
| `maestro/__init__.py` | `__version__ = "X.Y.Z"` |
| `.maestro/CHAIN-OF-COMMAND.md` | Header line and capability timeline entry |
| `.maestro/CLAUDE.md` | Header and component version table |
| `CLAUDE.md` (root) | "Maestro vX.Y" reference |
| `.maestro/config/workspace.json` | `notes` field |
| Core script headers | `crew.py`, `fleet-runner.py`, `fleet-stop-hook.py` inline comments |

### Version Bump Checklist

```
- [ ] pyproject.toml version field
- [ ] maestro/__init__.py __version__
- [ ] CHAIN-OF-COMMAND.md header + timeline
- [ ] .maestro/CLAUDE.md header + component table
- [ ] Root CLAUDE.md version reference
- [ ] .maestro/config/workspace.json notes
- [ ] Core script headers (crew.py, fleet-runner.py, fleet-stop-hook.py)
```

---

## 5. Cutting a Release

### Step-by-Step Release Process

#### 1. Prepare the release branch

```bash
git checkout main
git pull
git checkout -b maestro/vX.Y.Z-release
```

#### 2. Update version numbers

Update all files listed in the [Version Bump Checklist](#version-bump-checklist) above.

#### 3. Update documentation

- Review and update `docs/` for any new features or changed behaviour
- Update `README.md` if the feature set or installation instructions changed
- Update `CHAIN-OF-COMMAND.md` with the version capability entry

#### 4. Commit and PR

```bash
git add pyproject.toml maestro/__init__.py .maestro/CHAIN-OF-COMMAND.md ...
git commit -m "chore: bump version to vX.Y.Z"
git push -u origin maestro/vX.Y.Z-release
# Open PR → main, get approval
```

#### 5. Merge to main

```bash
# After PR approval
gh pr merge --squash
```

#### 5b. (Optional) Verify obfuscated build locally

Before tagging, confirm the obfuscated package builds cleanly:

```bash
pip install pyarmor==8.* build
python .maestro/build/build-dist.py --output-dir dist/
# Inspect dist/ for *.whl and *.tar.gz
```

See [Section 5.1 — Obfuscated Build](#51-obfuscated-build) for details.

#### 6. Tag the release

```bash
git checkout main
git pull
git tag vX.Y.Z -m "Maestro vX.Y.Z"
git push origin vX.Y.Z
```

#### 7. Create GitHub Release

```bash
gh release create vX.Y.Z \
  --title "Maestro vX.Y.Z — Maestro" \
  --notes "$(cat <<'EOF'
## What's New
- Feature 1
- Feature 2

## Breaking Changes
- None

## Installation
\`\`\`bash
pip install git+https://github.com/tavisbasing/Maestro.git@vX.Y.Z
\`\`\`
EOF
)"
```

#### 8. Publish to package registry

Publishing is automated via GitHub Actions when you push a `v*` tag (step 6 above). The workflow at `.github/workflows/publish.yml` will:

1. Build the obfuscated package using `.maestro/build/build-dist.py`
2. Publish the resulting `.whl` and `.tar.gz` to the GitHub Package Registry

**Monitor the publish run:**
```bash
gh run list --workflow publish.yml
gh run view <run-id>
```

**Manual publish (if needed):**
```bash
pip install pyarmor==8.* build twine
python .maestro/build/build-dist.py --output-dir dist/
twine upload --repository github dist/*
```

**Private PyPI:**
```bash
python .maestro/build/build-dist.py --output-dir dist/
twine upload --repository-url https://your-registry/ dist/*
```

See [Section 5.1 — Obfuscated Build](#51-obfuscated-build) and [Commercial Licensing Strategy](#8-commercial-licensing-strategy) for details.

---

## 5.1 Obfuscated Build

The distributed pip package is obfuscated using [PyArmor](https://pyarmor.readthedocs.io/) to protect IP in the CLI layer.

### What is obfuscated

| File | Obfuscated | Reason |
|------|-----------|--------|
| `maestro/__init__.py` | Yes | Version + startup code |
| `maestro/cli.py` | Yes | CLI entry points |
| `maestro/init.py` | Yes | Workspace scaffold logic |

### What is NOT obfuscated

| Path | Reason |
|------|--------|
| `.maestro/core/*.py` | Crews read and execute these at runtime — must remain plain Python |
| `.maestro/hooks/*.py` | Same — hooks are injected into live Claude Code sessions |
| Everything else in `\.maestro/` | Config, orders, voyages — not packaged |

### Running the build locally

```bash
# Install prerequisites (once)
pip install pyarmor==8.* build

# Run the build script from the repo root
python .maestro/build/build-dist.py

# Artifacts appear in dist/
ls dist/
# maestro-4.3.5-py3-none-any.whl
# maestro-4.3.5.tar.gz
```

Override the output directory:
```bash
python .maestro/build/build-dist.py --output-dir /tmp/maestro-test/
```

### GitHub Actions auto-publish

Pushing a `v*` tag triggers `.github/workflows/publish.yml` which:
1. Installs `pyarmor==8.*`, `build`, and `twine`
2. Runs `build-dist.py` to produce the obfuscated package
3. Publishes to the GitHub Package Registry using `GITHUB_TOKEN`

No secrets need to be configured — the workflow uses the Actions-provided `GITHUB_TOKEN` with `packages: write` permission.

### PyArmor licensing

PyArmor Community Edition supports up to 1000 files per run. The Maestro CLI package has 3 files — no commercial PyArmor license is required for the current codebase.

---

## 6. Adding a New Project

### Overview

A "project" in Maestro is a codebase that crews work on. The framework itself (`ADM`) is registered as a project. Additional projects (e.g. `OTM`, `PSG`) are registered in the same workspace.

### Step 1 — Register in projects.json

Edit `.maestro/config/projects.json`:

```json
{
  "projects": {
    "MYPROJ": {
      "name": "My Project",
      "acronym": "MYPROJ",
      "directory": "my-project",
      "repo": "your-org/my-project",
      "org": "your-org",
      "defaultBranch": "main",
      "voyageBranchPattern": "voyage/{VOYAGE-ID}",
      "cloneProtocol": "https",
      "configFile": "config/projects/MYPROJ.json"
    }
  }
}
```

`directory` is the local path relative to the workspace root where the project repo lives (or will be cloned).

### Step 2 — Create per-project config

Create `.maestro/config/projects/MYPROJ.json`:

```json
{
  "$schema": "Maestro — Project Configuration",
  "lastUpdated": "YYYY-MM-DD",

  "common": {
    "projectRoot": "my-project",
    "maestroRoot": ".mso",
    "sourceRoot": "my-project/src",
    "documentationRoot": "my-project/docs"
  },

  "roles": {
    "NAV": {
      "inputs": {
        "fullCodebase": "my-project/**/*",
        "requirements": ".maestro/requirements/",
        "activeOrders": ".maestro/orders/active/"
      },
      "outputs": {
        "plans": ".maestro/plans/",
        "handoffs": ".maestro/handoffs/{ORDER-ID}/",
        "progress": ".maestro/crews/crew{N}/progress.md"
      }
    },
    "SHP": {
      "inputs": { "sourceCode": "my-project/src/**" },
      "outputs": { "sourceCode": "my-project/src/" }
    }
  }
}
```

Adjust `inputs` and `outputs` for each role to match your project's directory structure.

### Step 3 — Clone the project repo

```bash
git clone https://github.com/your-org/my-project my-project
```

Or let the Fleet Admiral manage the repo automatically. The dispatcher creates a git worktree at `.mso/voyages/active/VOY-X/.worktree/` for each voyage, giving each crew an isolated working tree on the correct branch.

### Step 4 — Update CLAUDE.md

Add a row to the Active Projects table in the root `CLAUDE.md`:

```markdown
| **MYPROJ** | My Project | `my-project/` | `your-org/my-project` |
```

### Step 5 — Create a project branch (optional)

For projects where you want to track state separately from `main`:

```bash
git checkout -b project/MYPROJ
# Commit project-specific orders, voyages, prompts
```

### Step 6 — Add to .gitignore (if local clone)

If the project repo is a separate git repository cloned into the workspace, add it to `.gitignore`:

```
my-project/
```

### Order Naming Convention

Orders for the new project follow the pattern `{TYPE}-{ACRONYM}-{YEAR}-{SEQ}`:

```
FTR-MYPROJ-2026-0001   # Feature order
BUG-MYPROJ-2026-0001   # Bug order
DOC-MYPROJ-2026-0001   # Documentation order
INT-MYPROJ-2026-0001   # Integration/deployment order
```

---

## 7. Managing Project State

### Order Lifecycle

Orders move through three directories:

```
.maestro/queues/orders/    # Awaiting dispatch (queued)
.maestro/orders/active/    # Currently being worked (in-flight)
.maestro/orders/complete/  # Done
.maestro/orders/failed/    # Failed
```

**Creating an order:** Drop a JSON file in `.maestro/queues/orders/`. The dispatcher picks it up and moves it to `orders/active/` when a crew starts working on it.

**Order JSON format:**
```json
{
  "orderId": "FTR-MYPROJ-2026-0001",
  "project": "MYPROJ",
  "type": "FTR",
  "role": "SHP",
  "title": "Add login feature",
  "description": "Implement user authentication...",
  "acceptanceCriteria": ["...", "..."],
  "dependsOn": [],
  "voyageId": "VOY-MYPROJ-2026-0001",
  "targetFiles": ["src/Auth/LoginController.cs"],
  "status": "QUEUED"
}
```

### Voyage Lifecycle

Voyages group related orders. Voyage state files live in:

```
.maestro/voyages/active/     # Voyage in progress
.maestro/voyages/complete/   # Voyage complete
```

### Queue Tiers

Orders can be placed in different queue tiers for priority control:

| Queue Directory | Priority | Use For |
|-----------------|----------|---------|
| `queues/explicit/` | Highest | Urgent/manual dispatch |
| `queues/security/` | High | Security fixes |
| `queues/bugs/` | High | Bug fixes |
| `queues/requests/` | Medium-High | Crew-generated requests |
| `queues/orders/` | Medium | Normal feature work |
| `queues/defects/` | Medium-Low | Defects from QA |
| `queues/breakdown/` | Low | Breakdown sub-tasks |
| `queues/high-level/` | Lowest | Planning/NAV tasks |
| `queues/escalations/` | Not dispatched | Requires Captain/QM review |

### Dependency Management

The `dependsOn` field in an order JSON accepts an array of order IDs that must be complete before this order dispatches:

```json
{
  "dependsOn": ["FTR-MYPROJ-2026-0001", "FTR-MYPROJ-2026-0002"]
}
```

The dispatcher checks all queues and holds orders with unsatisfied dependencies regardless of queue tier.

---

## 7.5 Captain Review Workflow (AWAITING_APPROVAL)

The Maestro Monitor v4.0 includes an **APPROVALS** panel that surfaces voyages, plans, and requirements that require Captain sign-off before work proceeds. This gives you a single place to see everything awaiting your decision, visible at the top of the dashboard.

### Overview

Any of the following artifact types can be placed in a "waiting for Captain" state:

| Artifact | Location | How status is set |
|----------|----------|-------------------|
| Voyage | `.maestro/voyages/active/*.json` | Set `"status": "AWAITING_APPROVAL"` in the JSON |
| Plan | `.maestro/plans/*.md` | Add YAML frontmatter with `status: awaiting-approval` |
| Requirement | `.maestro/requirements/*.md` | Add YAML frontmatter with `status: awaiting-approval` |

When any of these are in `AWAITING_APPROVAL` state, the dashboard shows a yellow **APPROVALS — AWAITING CAPTAIN REVIEW** section immediately after the dispatcher block.

### Marking a Voyage for Review

Edit the voyage JSON in `.maestro/voyages/active/`:

```json
{
  "id": "VOY-OTM-2026-0005",
  "project": "OTM",
  "title": "Operation Horizon",
  "status": "AWAITING_APPROVAL",
  "approvalNote": "Scope includes external API integration — approve before dispatch"
}
```

The `approvalNote` field is optional but recommended. It appears in the dashboard below the voyage ID so you know what decision is needed.

### Marking a Plan or Requirement for Review

Plans (`.maestro/plans/*.md`) and requirements (`.maestro/requirements/*.md`) use YAML-style frontmatter at the top of the file:

```markdown
---
status: awaiting-approval
approvalNote: "Architecture decision required: see Section 3"
project: OTM
title: "Navigation Module Redesign"
---

# PLAN-FTR-OTM-2026-0005 — Navigation Module Redesign

...rest of plan...
```

**Required frontmatter fields:**

| Field | Required | Description |
|-------|----------|-------------|
| `status` | Yes | Set to `awaiting-approval` (case-insensitive) to appear in APPROVALS panel |
| `project` | Yes | Project acronym (e.g. `OTM`, `ADM`). Used for grouping in the dashboard. |
| `title` | No | Short description shown in the dashboard alongside the filename. |
| `approvalNote` | No | Brief note on what decision or action is needed from the Captain. |

The frontmatter block must be the **first content in the file**, enclosed by `---` markers. The monitor reads the first 15 lines only, so keep the frontmatter compact.

### Approving an Item

Approval is a manual step — edit the file to change its status:

**Voyage:** Change `"status": "AWAITING_APPROVAL"` back to `"ACTIVE"` (or `"PENDING"` if not yet dispatched) and remove or update `approvalNote`.

**Plan or Requirement:** Change `status: awaiting-approval` to `status: active` in the frontmatter, or remove the frontmatter block entirely.

Once the status is no longer `awaiting-approval` / `AWAITING_APPROVAL`, the item disappears from the APPROVALS panel on the next dashboard refresh (every 5 seconds).

### Rejecting or Blocking

If you decide not to approve, you have several options depending on severity:

- **Minor revision needed:** Update the `approvalNote` to describe what changes are required, leave status as `AWAITING_APPROVAL`.
- **Blocking:** Move the voyage JSON to a different state (e.g. set `"status": "BLOCKED"`) and raise an escalation in `.maestro/queues/escalations/` so the dispatcher holds all orders for that voyage.
- **Cancel:** Move the order or voyage to `.maestro/orders/failed/` or `.maestro/voyages/complete/` with an appropriate status.

### Dashboard Display

The APPROVALS section is shown in **yellow** to distinguish it from the red ESCALATIONS section. It appears only when there are pending items — if no voyages, plans, or requirements are in `AWAITING_APPROVAL` state, the section is hidden entirely.

Items are grouped by project acronym. Each item shows:
- Type (`[VOYAGE]`, `[PLAN]`, or `[REQ]`)
- Item ID or filename
- Project acronym
- Title (if set)
- Approval note (if set)
- Workspace-relative file path (clickable in VS Code terminal)

---

## 7.6 Budget Enforcement and Billing Mode

> **Planned** — Billing modes and budget enforcement are not yet implemented. The configuration schema below is the target design; the runtime does not currently consume these fields.

Maestro v2.0.0 adds configurable billing modes and budget enforcement. These settings are stored in `.maestro/config/workspace.json` and apply across all projects in the workspace.

### Billing configuration

Add a `billing` block to `workspace.json`:

```json
{
  "billing": {
    "mode": "track",
    "currency": "USD",
    "budgetPerVoyage": null,
    "budgetTotal": null,
    "alertThreshold": 0.8
  }
}
```

| Field | Type | Description |
|-------|------|-------------|
| `mode` | string | Billing enforcement mode — see table below. |
| `currency` | string | Display currency for cost estimates (`USD`, `GBP`, `EUR`). Pricing is always in USD internally; display conversion is informational. |
| `budgetPerVoyage` | number or null | Maximum spend per voyage. `null` means no limit. |
| `budgetTotal` | number or null | Maximum cumulative spend across all voyages in the workspace. `null` means no limit. |
| `alertThreshold` | float (0–1) | Fraction of budget at which a dashboard warning is shown. Default: `0.8`. |

### Billing modes

| Mode | Behaviour |
|------|-----------|
| `track` *(default)* | Token usage is recorded and reported. No enforcement or dispatch blocking. |
| `enforce` | Dispatch is halted when `budgetPerVoyage` or `budgetTotal` is exceeded. Crews already running are not interrupted. |
| `estimate-first` | `mso dispatch` presents a pre-dispatch cost estimate and requires Captain confirmation before launching crews. |

### Approval workflow integration

The `mso approve` and `mso reject` commands provide CLI-level control over items in the APPROVALS panel, replacing the manual file-edit workflow documented in [7.5](#75-captain-review-workflow-awaiting_approval):

```bash
# Approve a voyage
mso approve --voyage VOY-MYPROJ-2026-0001 --note "Confirmed with stakeholders"

# Reject a voyage (moves to BLOCKED, creates escalation)
mso reject --voyage VOY-MYPROJ-2026-0001 --reason "Scope too broad — split required"

# Approve a plan
mso approve --plan .maestro/plans/NAV-FTR-MYPROJ-2026-0001.md
```

Both commands update the artifact file in-place and refresh the dashboard state without requiring a dispatcher restart.

### Fleet pause and resume

Use `mso pause` and `mso resume` to temporarily hold fleet activity — for example, while reviewing an approval or investigating unexpected cost growth:

```bash
# Pause all running crews
mso pause --all

# Review usage mid-voyage
mso usage --voyage VOY-MYPROJ-2026-0001

# Resume when ready
mso resume --all
```

Paused crews retain their state and continue from where they left off after `resume`.

### Budget enforcement workflow

Typical enforce-mode workflow:

1. Set `mode: "enforce"` and `budgetPerVoyage: 5.00` in `workspace.json`.
2. Before dispatching, estimate cost: `mso estimate --voyage VOY-MYPROJ-2026-0001`.
3. If the estimate exceeds the budget, reduce scope or adjust `budgetPerVoyage` before proceeding.
4. Dispatch: `mso dispatch --max-crews 3`.
5. If a voyage breaches the budget mid-run, the dispatcher halts new crew assignments. Active crews complete their current iteration.
6. Review usage: `mso usage --voyage VOY-MYPROJ-2026-0001`.
7. Adjust budget or voyage scope, then resume: `mso resume --all`.

---

## 8. Commercial Licensing Strategy

### Current State

Maestro distributes via a **public-wheel + runtime-licence** model:

1. **Public wheel index** at [`maestrodevs/maestrodevs.github.io`](https://github.com/maestrodevs/maestrodevs.github.io) (GitHub Pages). Anyone can `pip install maestro --extra-index-url https://maestrodevs.github.io/simple/` without GitHub credentials.
2. **Runtime licence enforcement** via Polar.sh-issued keys. The CLI's `auth.check()` runs on every startup; without a valid `~/.maestro/licence.json` (signed, keychain-bound) the CLI refuses to do anything beyond `mso version` and `mso licence activate`.

The wheel itself is openly downloadable; the licence check is the gate. The proprietary [LICENSE](../LICENSE) covers the legal layer (no redistribution, no reuse).

### Distribution Options Considered (history)

The current model came out of [VOY-ADM-2026-0036's option comparison](../.mso/plans/PLAN-VOY-ADM-2026-0036.md). Options ranked:

| Option | Why it lost or won |
|---|---|
| **Public wheel index + runtime licence** ✅ | **Winner.** Zero recurring infra cost; same shape as `aws-cli` / `databricks-cli` / `snowflake-connector-python`. Runtime licence is the gate. |
| Hosted private PyPI (Gemfury / JFrog / AWS CodeArtifact) | $50–200/mo recurring; licence-key auth doesn't reuse. Possible v2 upgrade path. |
| GitHub Packages (Python) | Ties customer onboarding to GitHub identity; fights the trust pillar. |
| Public PyPI + Cython/Nuitka compile | "Closed-source" claim isn't honest; role prompts must stay readable. |
| Private repo + customer PATs | Operationally awful past ~10 customers. |
| **Self-hosted simple PyPI on Fly licence-backend** (v2 plan) | **Future upgrade.** Same secret end-to-end (install + activate + validate). Triggered when ARR justifies the ops cost. |

### Licence backend (shipped in v2.5.0)

Polar.sh as merchant-of-record (selected for AU GST + EU VAT + US sales tax MoR coverage and OSS alignment vs Lemon Squeezy / Paddle / Keygen-self-host). **Single integration point** — the CLI talks to `api.polar.sh` directly via [`maestro/licence/client.py`](../maestro/licence/client.py); Maestro operates no licence-server infrastructure. Polar handles subscription billing, key issuance, key state (granted / revoked / expired), and the customer-facing portal. (A webhook receiver was specced and removed 2026-05-07 per Captain direction — none of its features were launch-day requirements.)

Key activation flow (see [docs/LICENCE.md](LICENCE.md) for the customer view):

```python
# maestro/licence/__init__.py — public API
activate(key)         # online verify + persist; raises LicenceInvalid on bad key
validate(strict=False) # cached-OK fast path within 24h; online refresh past that
                       # 14-day offline grace for network failure
deactivate()          # drop ~/.maestro/licence.json + keychain entry
status()              # read-only inspection
```

Non-interactive activation in CI: `MAESTRO_LICENCE_KEY=adm_lic_xxx adm <cmd>` (UK spelling — note `LICENCE` not `LICENSE`).

### Versioning for Commercial Deployment

Tag every release:

```bash
git tag v2.5.0 -m "Maestro v2.5.0"
git push origin v2.5.0
```

The tag fires the [`publish.yml`](../.github/workflows/publish.yml) workflow, which builds a wheel, pushes it to `maestrodevs.github.io`, regenerates the PEP 503 simple/ index, and creates a GitHub Release.

Customers can pin to a specific version:

```bash
pip install maestro==2.5.0 --extra-index-url https://maestrodevs.github.io/simple/
```

### Roadmap

| Phase | What | Status |
|---|---|---|
| **Shipped (v2.5.0)** | Public wheel index + Polar-backed licence keys | ✅ Live at [maestroai.com](https://maestroai.com) |
| **Shipped (v2.5.0)** | `MAESTRO_LICENCE_KEY` env var for non-interactive activation | ✅ |
| **Shipped (v2.5.0)** | 14-day offline grace + tamper detection (HMAC + keychain) | ✅ |
| **Next (post-launch)** | Self-hosted simple PyPI on Fly licence-backend (one secret end-to-end) | Triggered by ARR — see VOY-0036 §3 |
| **Future** | Hosted SaaS option for customers who don't want to BYOK | Open question |
| **Future** | Sigstore / cosign wheel signing | Captured in LKT review (FTR-0125) |

---

## 9. Maintenance Workflows

### Updating Core Scripts

Core scripts live in `.maestro/core/`. They are part of both the pip package (via submodule in user workspaces) and the framework repo.

```bash
git checkout -b maestro/fix-{description}
# Edit .maestro/core/fleet-runner.py or crew.py etc.
# Test manually
git commit -m "fix: ..."
git push -u origin maestro/fix-{description}
# PR → main
```

When updating core scripts, preserve these invariants:
- Token tracking pipeline must not break (stop hook → usage JSON → crew.py → aggregation)
- All hooks must remain fail-open (wrapped in `try/except`, `exit(0)` on error)
- Captain session safety: all hooks check `MAESTRO_CREW` env var before acting
- `MAESTRO_CREW` env var remains the single gate for hook activation

### Updating Hooks

Hooks live in `.maestro/hooks/`. They are injected into Claude Code sessions via `.claude/settings.json` in the user's workspace.

Hook files:
- `fleet-stop-hook.py` — multi-pass iterations (Ralph Wiggum) + token usage capture
- `fleet-pretool-hook.py` — role permission enforcement at write/edit time
- `fleet-posttool-hook.py` — activity tracking, heartbeat, file counter
- `fleet-notification-hook.py` — error/warning capture

When updating hooks:
1. Test with a live crew session to confirm hooks fire and fail gracefully
2. Verify `MAESTRO_CREW` check is present and correct
3. Verify fail-open: introduce a deliberate error and confirm crew continues

### Adding a New Role

1. Add role definition to `.maestro/config/role-paths.json` with `prohibited` and `outputs`
2. Add role entry to `CHAIN-OF-COMMAND.md` Role-Based Model Selection table
3. Add to `.maestro/CLAUDE.md` component table
4. Add per-project override in `config/projects/{ACRONYM}.json` if needed
5. Update `crew.py` role-to-model mapping if the new role uses a non-default model

### Monitoring Fleet Health

```bash
# Live dashboard
mso status

# One-shot status
mso status --once

# Compact view (one line per crew)
mso status --once --compact

# Token usage summary
mso usage --summary

# Usage for a specific voyage
mso usage --voyage VOY-ADM-2026-0001

# Full usage report
mso usage --report --output .maestro/reports/usage-report.md
```

### Cleanup After a Voyage

```bash
# Stop rogue processes and reset stale crew state
mso cleanup

# Or with dispatch (cleanup then launch)
mso dispatch --cleanup --max-crews 5
```

Cleanup removes:
- Stale `crew.lock` files
- Orphaned crew processes (by PID)
- Resets `state.json` for idle crews

### Handling Blocked Orders

When an order is stuck or a crew is blocked:

1. Check the escalation queue: `.maestro/queues/escalations/`
2. Review the crew's progress: `.maestro/crews/crewN/progress.md`
3. Review the crew's activity: `.maestro/crews/crewN/activity.txt`
4. Resolve the escalation JSON (set `status: "RESOLVED"`, add `resolution`)
5. The dispatcher automatically unblocks when the escalation is resolved

For blocking escalations (those with `"blocking": true`), all orders for the same voyage are halted until the Captain/QM resolves the escalation.

### Managing Crew Iterations

Each crew runs up to `MAESTRO_MAX_ITERATIONS` iterations (default: 25) via the Ralph Wiggum stop hook pattern. The hook reads the crew's `ralph-state.md` to determine whether to re-invoke Claude or declare completion.

To adjust the limit per-order, set `maxIterations` in the order JSON:
```json
{
  "maxIterations": 10
}
```

### Post-Voyage Verification

After a voyage completes, run verification to confirm builds and tests pass:

```bash
mso verify --voyage VOY-ADM-2026-0001
```

To skip re-running tests and reuse existing results:
```bash
mso verify --voyage VOY-ADM-2026-0001 --skip-tests
```

---

## 10. Workspace Backup Strategy

`mso backup` and `mso restore` let you snapshot and recover all project state (orders, voyages, plans, usage records, config) from a single ZIP archive. As a framework owner managing ADM self-development work, use backups at the natural checkpoints described below.

### Before every cleanup

`mso cleanup` automatically creates a full backup before it runs — no manual step required. The backup path is printed to stdout:

```
[Maestro] Auto-backup created: /workspace/maestro-backups/maestro-backup-all-2026-03-30-143000.zip
```

Backups accumulate in `./maestro-backups/`. Prune old archives periodically if disk space is a concern:

```bash
# List to inspect before deleting
mso backup --list

# Remove backups older than 30 days (example — adjust to taste)
find ./maestro-backups/ -name "*.zip" -mtime +30 -delete
```

### Before cutting a release

Take a snapshot of project state before any release-prep steps that might touch orders or voyages:

```bash
mso backup
```

This gives you a recovery point if you need to roll back the workspace to its pre-release state.

### Before a migration or machine transfer

To transfer project state to a new machine or workspace:

1. On the source machine:
   ```bash
   mso backup --output /tmp/transfer/
   ```
2. Copy the ZIP to the target machine.
3. On the target machine, after running `mso init`:
   ```bash
   mso restore /tmp/transfer/maestro-backup-all-2026-03-30-143000.zip
   ```

### Per-project backups in a multi-project workspace

When you want to share a project's state with a collaborator without exposing other projects:

```bash
mso backup --project OTM --output /tmp/otm-handoff/
```

Only files associated with `OTM` are included. The collaborator restores with:

```bash
mso restore /tmp/otm-handoff/maestro-backup-OTM-2026-03-30-143000.zip --project OTM
```

### Disaster recovery

If workspace state is accidentally deleted or corrupted:

```bash
# Preview first
mso restore maestro-backup-all-2026-03-30-143000.zip --dry-run

# Restore, skipping any files already in place
mso restore maestro-backup-all-2026-03-30-143000.zip

# Or overwrite everything from the snapshot
mso restore maestro-backup-all-2026-03-30-143000.zip --force
```

The `--merge` flag is useful when recovering partial damage — it keeps whichever copy of each file is newer, so undamaged files are not overwritten:

```bash
mso restore maestro-backup-all-2026-03-30-143000.zip --merge
```

### What is and is not in a backup

**Included** (project state — changes with usage):
- All orders (`active/`, `complete/`, `failed/`)
- All voyages (`active/`, `complete/`)
- Active prompts, plans, handoffs, requirements, reports
- Token usage records (`usage/orders/`)
- All config files (`config/workspace.json`, `config/projects.json`, `config/projects/*.json`)
- `CLAUDE.md`, `BACKLOG.md`, `VOYAGE-STATUS.md`

**Excluded** (runtime / framework — not project state):
- `.maestro/core/` — framework scripts (provided by pip or submodule)
- `.maestro/hooks/` — framework hooks
- `.maestro/crews/` — ephemeral crew runtime state
- `.maestro/logs/`, `.maestro/temp/` — ephemeral artifacts
- `.maestro/queues/` — regenerated by the dispatcher at runtime

See [CLI-REFERENCE.md — mso backup](CLI-REFERENCE.md#mso-backup) for the complete flag reference.

---

## 11. CLI Reference

### `mso dispatch`

Launch fleet crews from the dispatch queue.

```
mso dispatch [--max-crews N] [--cleanup] [--stagger-delay S] [--timeout M]
```

| Flag | Default | Description |
|------|---------|-------------|
| `--max-crews N` | 5 | Maximum concurrent crews |
| `--cleanup` | false | Run cleanup before dispatching |
| `--stagger-delay S` | 30 | Seconds between crew launches |
| `--timeout M` | 90 | Per-crew timeout in minutes |

### `mso cleanup`

Stop rogue processes and reset stale crew state.

```
mso cleanup
```

### `mso status`

Display fleet status dashboard.

```
mso status [--once] [--compact]
```

| Flag | Default | Description |
|------|---------|-------------|
| `--once` | false | One-shot display (no loop); when omitted, the dashboard loops |
| `--compact` | false | One-line summary per crew |

### `mso usage`

Report token usage and estimated cost.

```
mso usage [--voyage VOY-ID | --order ORDER-ID | --report [--output PATH]]
```

| Flag | Description |
|------|-------------|
| *(none)* | Print overall summary |
| `--voyage VOY-ID` | Per-voyage token breakdown |
| `--order ORDER-ID` | Per-order token breakdown |
| `--report` | Generate full markdown report |
| `--output PATH` | Output path for `--report` |

### `mso crew`

Operate an individual crew instance.

```
mso crew --crew {1-5} [--status | --watch | --cleanup]
```

| Flag | Description |
|------|-------------|
| `--crew N` | Crew number (1–5, required) |
| `--status` | Show crew status |
| `--watch` | Watch crew progress live |
| `--cleanup` | Stop this crew's process |

### `mso verify`

Run post-voyage build and test verification.

```
mso verify [--voyage VOY-ID] [--skip-tests]
```

| Flag | Description |
|------|-------------|
| `--voyage VOY-ID` | Voyage ID to verify |
| `--skip-tests` | Reuse existing test results |

### `mso backup`

Create or list project state backups.

```
mso backup [--project ACRONYM] [--output PATH] [--list]
```

| Flag | Default | Description |
|------|---------|-------------|
| `--project ACRONYM` | all | Only include files for this project acronym |
| `--output PATH` | `./maestro-backups/` | Output directory |
| `--list` | false | List available backups instead of creating one |

### `mso restore`

Restore project state from a backup archive.

```
mso restore BACKUP_FILE [--project ACRONYM] [--force] [--merge] [--dry-run]
```

| Flag | Default | Description |
|------|---------|-------------|
| `BACKUP_FILE` | *(required)* | Path to the backup ZIP |
| `--project ACRONYM` | all | Only restore files for this project acronym |
| `--force` | false | Overwrite existing files |
| `--merge` | false | Keep the newer file by mtime |
| `--dry-run` | false | Preview without writing |

### `mso init`

Scaffold a new Maestro workspace.

```
mso init --project ACRONYM [--directory PATH] [--force]
```

| Flag | Default | Description |
|------|---------|-------------|
| `--project ACRONYM` | *(required)* | Project acronym (e.g. `OTM`, `PSG`) |
| `--directory PATH` | current dir | Workspace directory |
| `--force` | false | Overwrite existing `\.maestro/` |

Creates:
- Full `\.maestro/` directory structure with all queue/order/voyage directories
- `config/workspace.json`, `config/projects.json`, `config/projects/{ACRONYM}.json`
- `CLAUDE.md` with Quartermaster persona
- `.gitignore` with standard exclusions

### `mso version`

Print the installed Maestro version.

```
mso version
```

---

## Environment Variables (Crew Sessions)

These are injected by the Fleet Admiral into crew subprocesses. Documented here for completeness when debugging or extending the system.

| Variable | Purpose |
|----------|---------|
| `MAESTRO_CREW` | Crew number (1–5). Activates hooks. Must not be set in Captain sessions. |
| `MAESTRO_ORDER` | Current order ID |
| `MAESTRO_PROJECT` | Project acronym (e.g. `ADM`, `OTM`) |
| `MAESTRO_REPO_PATH` | Managed repo clone path — crew's working directory |
| `MAESTRO_TEMP` | Centralized temp directory |
| `MAESTRO_VOYAGE_BRANCH` | Voyage branch name |
| `MAESTRO_MAX_ITERATIONS` | Max stop-hook iterations (default: 25) |
| `MAESTRO_COMPLETION_PROMISE` | Promise tag crews use to signal task completion |

---

## 12. Collaborator Access Management

Maestro v2.0.0 enforces collaborator-based licence validation on CLI startup. Users must be listed as GitHub collaborators on `tavisbasing/Maestro` to run any CLI command (except `mso version` and `mso init`).

### How It Works

1. On first run, the user is prompted for a GitHub Personal Access Token (PAT) with `repo` scope.
2. The token and username are cached in `~/.maestro/auth.json` (mode 0600).
3. On every subsequent CLI invocation, the GitHub API is called to confirm collaborator status.
4. If validation fails, the CLI exits with a licensing message.
5. If the network is unavailable, a grace period of 7 days (configurable) is applied.

### Adding a Collaborator (Granting Access)

```bash
# Via GitHub web UI
# Settings → Collaborators → Add people → enter GitHub username

# Via GitHub CLI
gh api repos/tavisbasing/Maestro/collaborators/{username} -X PUT -f permission=pull
```

The user will be emailed an invitation. They must accept it before the collaborator check passes.

### Removing a Collaborator (Revoking Access)

```bash
# Via GitHub web UI
# Settings → Collaborators → remove user

# Via GitHub CLI
gh api repos/tavisbasing/Maestro/collaborators/{username} -X DELETE
```

Revocation takes effect on the user's next CLI invocation (after their cached grace period expires, if network is unavailable).

### Environment Variables

| Variable | Purpose |
|----------|---------|
| `MAESTRO_SKIP_AUTH=1` | Bypass auth check entirely (for CI/CD pipelines) |
| `MAESTRO_*OFFLINE_GRACE_DAYS=N` | Days offline before grace period expires (default: 7) |

### Cache File

The auth cache is stored at `~/.maestro/auth.json`:

```json
{
  "token": "ghp_...",
  "username": "octocat",
  "last_verified": "2026-03-30T12:00:00Z"
}
```

The file is created with mode `0600` (owner read/write only). To reset auth (e.g. after changing PAT), delete this file:

```bash
rm ~/.maestro/auth.json
```

> **Note (Windows):** Python's `os.chmod` has limited effect on Windows. Ensure the `~/.maestro/` directory is appropriately restricted via NTFS permissions or keep the machine user-isolated.

> **CI/CD:** Always set `MAESTRO_SKIP_AUTH=1` in automated pipelines. Without it, the CLI will hang waiting for PAT input.

---

*Maestro Maestro — v2.0.0 — For licensing enquiries, contact [tavisbasing](https://github.com/tavisbasing).*
