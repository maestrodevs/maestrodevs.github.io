#!/usr/bin/env python3
# Maestro Monitor v4.0
"""
Maestro Monitor v4.0 - Unified Dashboard

Replaces both the old Live Monitor v2.7 and the Dispatcher status window.
Single window shows: dispatcher status, crew status, queue depth, lifecycle events.

Features:
- PID lock prevents duplicate instances (.mso/monitor.pid)
- Auto-detects dispatcher via .mso/dispatcher.pid
- Reads lifecycle events from .mso/logs/lifecycle.log
- ctypes-based process checking (works from cmd.exe AND Git Bash)
- Orphan detection: marks RUNNING crews as CRASHED if PID is dead
- ANSI color output for clear status visibility
- v3.1: MODEL column shows role-based model selection (Opus/Sonnet/Haiku)
- v4.0: Dynamic version resolution from maestro package
"""

import argparse
import atexit
import json
import os
import re
import sys
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from maestro.personas import current_persona  # noqa: E402 — must follow stdlib imports

# Fix Windows console encoding
if sys.platform == 'win32':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except:
        pass

# Enable Windows console ANSI colors
if os.name == 'nt':
    os.system('chcp 65001 >nul 2>&1')
    os.system('')

# ANSI color codes
class C:
    RESET = '\033[0m'
    BOLD = '\033[1m'
    DIM = '\033[2m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    RED = '\033[91m'
    WHITE = '\033[97m'
    MAGENTA = '\033[95m'

# Defaults
DEFAULT_MAX_CREWS = 5
DEFAULT_ITERATION_TIMEOUT_MINUTES = 30

DEFAULT_MODEL_LABEL = "Sonnet"

# Squad names and role-model labels are persona-driven — see maestro/core_constants.py
from maestro.core_constants import get_squad_name, get_role_model  # noqa: E402
from maestro.workspace import get_workspace_dir  # noqa: E402
from maestro.errors import run_cli  # noqa: E402


# =============================================================================
# CORE HELPERS
# =============================================================================

def resolve_version() -> str:
    """Resolve the package version from the installed maestro package or __init__.py."""
    try:
        import maestro
        return maestro.__version__
    except ImportError:
        pass

    script_path = Path(__file__).resolve()
    for candidate in [
        script_path.parent.parent.parent / "maestro" / "__init__.py",
        script_path.parent.parent / "maestro" / "__init__.py",
    ]:
        if candidate.exists():
            try:
                content = candidate.read_text(encoding="utf-8")
                m = re.search(r'^__version__\s*=\s*["\']([^"\']+)["\']', content, re.MULTILINE)
                if m:
                    return m.group(1)
            except Exception:
                pass

    return "unknown"


def get_base_dir() -> Path:
    return get_workspace_dir().parent


def load_json_safe(path: Path) -> Optional[Dict]:
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except:
        return None


def get_settings() -> Dict:
    config_file = get_workspace_dir() / "config" / "fleet-settings.json"
    settings = load_json_safe(config_file) or {}
    return {
        "maxCrews": settings.get("maxCrews", DEFAULT_MAX_CREWS),
        "iterationTimeoutMinutes": settings.get("iterationTimeoutMinutes", DEFAULT_ITERATION_TIMEOUT_MINUTES)
    }


def format_duration(seconds: float) -> str:
    if seconds < 0:
        return "--:--"
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = int(seconds % 60)
    if hours > 0:
        return f"{hours:02d}:{minutes:02d}:{secs:02d}"
    return f"{minutes:02d}:{secs:02d}"


def get_elapsed_seconds(start_time_str: str) -> float:
    try:
        if 'T' in start_time_str:
            start = datetime.fromisoformat(start_time_str.replace('Z', '+00:00'))
        else:
            start = datetime.strptime(start_time_str, '%Y-%m-%d')
        elapsed = datetime.now() - start.replace(tzinfo=None)
        return elapsed.total_seconds()
    except:
        return 0


def get_progress_bar(current: int, total: int, width: int = 15) -> str:
    if total == 0:
        return "[" + "-" * width + "]   0%"
    filled = int((current / total) * width)
    empty = width - filled
    percent = int((current / total) * 100)
    return f"[{'#' * filled}{'-' * empty}] {percent:3d}%"


# =============================================================================
# PROCESS DETECTION (ctypes - reliable on Windows)
# =============================================================================

def is_process_alive(pid: int) -> bool:
    """Check if a process with the given PID is still running.

    Uses ctypes OpenProcess on Windows for reliability (works from cmd.exe AND Git Bash).
    """
    if not pid or pid <= 0:
        return False
    try:
        if os.name == 'nt':
            import ctypes
            PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            STILL_ACTIVE = 259
            kernel32 = ctypes.windll.kernel32
            handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
            if handle == 0:
                return False
            try:
                exit_code = ctypes.c_ulong()
                if kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code)):
                    return exit_code.value == STILL_ACTIVE
                return False
            finally:
                kernel32.CloseHandle(handle)
        else:
            os.kill(pid, 0)
            return True
    except (ProcessLookupError, PermissionError, OSError):
        return False


# =============================================================================
# MONITOR PID LOCK
# =============================================================================

def check_monitor_lock() -> bool:
    """Check if another monitor instance is running. Returns True if lock acquired."""
    lock_file = get_workspace_dir() / "monitor.pid"
    if lock_file.exists():
        try:
            old_pid = int(lock_file.read_text(encoding='utf-8').strip())
            if is_process_alive(old_pid) and old_pid != os.getpid():
                return False  # Another monitor is running
        except:
            pass  # Stale/corrupt file, proceed

    # Acquire lock
    lock_file.parent.mkdir(parents=True, exist_ok=True)
    lock_file.write_text(str(os.getpid()), encoding='utf-8')
    return True


def release_monitor_lock():
    """Release the monitor PID lock."""
    lock_file = get_workspace_dir() / "monitor.pid"
    try:
        if lock_file.exists():
            stored_pid = int(lock_file.read_text(encoding='utf-8').strip())
            if stored_pid == os.getpid():
                lock_file.unlink()
    except:
        pass


# =============================================================================
# DATA GATHERING
# =============================================================================

def get_dispatcher_status() -> Dict:
    """Get dispatcher status from PID file and fleet state."""
    result = {"running": False, "pid": None, "startTime": "", "maxCrews": 5, "staggerDelay": 30}

    pid_file = get_workspace_dir() / "dispatcher.pid"
    if pid_file.exists():
        try:
            pid = int(pid_file.read_text(encoding='utf-8').strip())
            if is_process_alive(pid):
                result["running"] = True
                result["pid"] = pid
        except:
            pass

    # Read fleet state for additional info
    state_file = get_workspace_dir() / "fleet-runner-state.json"
    state = load_json_safe(state_file)
    if state:
        result["startTime"] = state.get("startTime", "")

    return result


def get_crew_activity(crew_num: int) -> Dict:
    """Get detailed crew activity info from state and progress files."""
    crews_dir = get_workspace_dir() / "crews" / f"crew{crew_num}"
    state_file = crews_dir / "state.json"
    progress_file = crews_dir / "progress.md"

    state = load_json_safe(state_file)
    if not state:
        return {"status": "IDLE", "activity": "-", "pid": None, "role": "-", "order": "-"}

    # v8.1: Read activity from hook-written files (priority order)
    activity = "Working..."
    activity_file = crews_dir / "activity.txt"
    activity_jsonl = crews_dir / "activity.jsonl"

    if activity_file.exists():
        try:
            raw = activity_file.read_text(encoding='utf-8').strip()
            if raw:
                # Calculate time since last activity from file mtime
                mtime = activity_file.stat().st_mtime
                age_secs = int(time.time() - mtime)
                if age_secs < 60:
                    age_str = f"{age_secs}s"
                elif age_secs < 3600:
                    age_str = f"{age_secs // 60}m"
                else:
                    age_str = f"{age_secs // 3600}h"
                activity = f"{raw} ({age_str} ago)"
                if len(activity) > 50:
                    activity = activity[:47] + "..."
        except Exception:
            pass
    elif activity_jsonl.exists():
        try:
            content = activity_jsonl.read_text(encoding='utf-8').strip()
            lines = content.split('\n')
            if lines:
                last = json.loads(lines[-1])
                action = last.get("action", "Working")
                target = last.get("target", "")
                activity = f"{action} {target}"
                if len(activity) > 50:
                    activity = activity[:47] + "..."
        except Exception:
            pass
    elif progress_file.exists():
        # Legacy fallback: read progress.md
        try:
            content = progress_file.read_text(encoding='utf-8')
            plines = content.split('\n')
            for line in reversed(plines):
                line = line.strip()
                if line and not line.startswith('#') and not line.startswith('<') and len(line) > 3:
                    if line.startswith('- ['):
                        line = line[6:]
                    activity = line[:50] + "..." if len(line) > 50 else line
                    break
        except Exception:
            pass

    # v8.0: Read ralph-state.md for live iteration count (updated by stop hook)
    # Falls back to state.json iteration if ralph-state.md doesn't exist (pre-v8.0)
    iteration = state.get("iteration", 0)
    ralph_status = None
    ralph_state_file = crews_dir / "ralph-state.md"
    if ralph_state_file.exists():
        try:
            ralph_content = ralph_state_file.read_text(encoding='utf-8')
            iter_match = re.search(r'^iteration:\s*(\d+)', ralph_content, re.MULTILINE)
            if iter_match:
                iteration = int(iter_match.group(1))
            status_match = re.search(r'^status:\s*"?(\w+)"?', ralph_content, re.MULTILINE)
            if status_match:
                ralph_status = status_match.group(1)
        except Exception:
            pass

    return {
        "status": state.get("status", "UNKNOWN"),
        "role": state.get("role", "-"),
        "order": state.get("orderId", "-"),
        "iteration": iteration,
        "maxIterations": state.get("maxIterations", 0),
        "liveTurn": state.get("liveTurn", 0),       # FTR-MSO-2026-0227
        "maxTurns": state.get("maxTurns", 0),        # FTR-MSO-2026-0227
        "subagentCount": state.get("subagentCount", 0),  # FTR-MSO-2026-0227
        "startTime": state.get("startTime", ""),
        "endTime": state.get("endTime", ""),
        "activity": activity,
        "filesChanged": state.get("filesChangedTotal", 0),
        "pid": state.get("pid"),
        "timeout": state.get("timeoutMinutes", DEFAULT_ITERATION_TIMEOUT_MINUTES),
        "ralphStatus": ralph_status
    }


def get_queue_counts() -> Dict[str, Dict]:
    """Get counts of items in each queue."""
    queues_dir = get_workspace_dir() / "queues"

    queue_info = {
        "requests": {"count": 0, "path": "requests", "details": {}},
        "orders": {"count": 0, "path": "orders", "details": {}},
        "explicit": {"count": 0, "path": "explicit", "details": {}},
        "high-level": {"count": 0, "path": "high-level", "details": {}},
        "defects": {"count": 0, "path": "defects", "details": {}},
        "security": {"count": 0, "path": "security", "details": {}},
        "bugs": {"count": 0, "path": "bugs", "details": {}},
        "breakdown": {"count": 0, "path": "breakdown", "details": {}},
        "escalations": {"count": 0, "path": "escalations", "details": {}},
    }

    for queue_name, info in queue_info.items():
        queue_path = queues_dir / info["path"]
        if queue_path.exists():
            if queue_name == "requests":
                for subdir in ["investigation", "qa", "documentation", "security-scan", "planning"]:
                    subpath = queue_path / subdir
                    if subpath.exists():
                        count = len(list(subpath.glob("*.json")))
                        if count > 0:
                            info["details"][subdir] = count
                            info["count"] += count
            elif queue_name == "orders":
                # Count only PENDING orders (not IN_PROGRESS which are already dispatched)
                for json_file in queue_path.glob("*.json"):
                    try:
                        data = json.loads(json_file.read_text(encoding='utf-8'))
                        status = data.get("status", "PENDING")
                        if status == "PENDING":
                            info["count"] += 1
                            # v8.8: Resolve role from targetRole, role, or roleSequence[0]
                            otype = data.get("targetRole") or data.get("role") or ""
                            if not otype:
                                seq = data.get("roleSequence", [])
                                otype = seq[0] if seq else "UNK"
                            info["details"][otype] = info["details"].get(otype, 0) + 1
                    except:
                        info["count"] += 1  # Count unreadable files as pending
            else:
                info["count"] = len(list(queue_path.glob("*.json")))

    return queue_info


def get_lifecycle_log(max_lines: int = 10) -> List[str]:
    """Read recent lifecycle events from the log file."""
    log_file = get_workspace_dir() / "logs" / "lifecycle.log"
    if not log_file.exists():
        return []
    try:
        lines = log_file.read_text(encoding='utf-8').strip().split('\n')
        # Return last N non-empty lines
        return [l for l in lines if l.strip()][-max_lines:]
    except:
        return []


def _read_md_frontmatter(path: Path) -> dict:
    """Read YAML-style frontmatter from the first 15 lines of a .md file.

    Looks for content between --- markers at the top of the file.
    Returns a dict of key-value pairs, or {} if no frontmatter found.
    """
    result = {}
    try:
        lines = path.read_text(encoding='utf-8').splitlines()[:15]
        if not lines or lines[0].strip() != '---':
            return result
        for line in lines[1:]:
            stripped = line.strip()
            if stripped == '---':
                break
            if ':' in stripped:
                key, _, value = stripped.partition(':')
                result[key.strip()] = value.strip().strip('"\'')
    except Exception:
        pass
    return result


def get_pending_review_items() -> list:
    """Scan .mso/queues/review/ for orders awaiting human review.

    Returns a list of dicts: { order_id, voyage_id, age }
    """
    admiralty_dir = get_workspace_dir()
    items = []
    review_dir = admiralty_dir / "queues" / "review"
    if not review_dir.exists():
        return items
    for json_file in sorted(review_dir.glob("*.json")):
        try:
            data = json.loads(json_file.read_text(encoding='utf-8'))
            paused_at = data.get("navReviewPausedAt", "")
            age_str = "--"
            if paused_at:
                age_secs = get_elapsed_seconds(paused_at)
                if age_secs > 0:
                    age_str = format_duration(age_secs)
            items.append({
                "order_id": data.get("id", json_file.stem),
                "voyage_id": data.get("voyageId", "?"),
                "age": age_str,
            })
        except Exception:
            pass
    return items


def get_approval_items() -> list:
    """Scan voyages/active, plans, and requirements for awaiting-approval items.

    Returns a list of dicts:
      { type: 'VOYAGE'|'PLAN'|'REQ', id, project, title, note, path }
    """
    admiralty_dir = get_workspace_dir()
    base_dir = get_base_dir()
    items = []

    # Voyages
    voyages_dir = admiralty_dir / "voyages" / "active"
    if voyages_dir.exists():
        for json_file in sorted(voyages_dir.glob("*.json")):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                if data.get("status") == "AWAITING_APPROVAL":
                    rel_path = json_file.relative_to(base_dir).as_posix()
                    items.append({
                        "type": "VOYAGE",
                        "id": data.get("id", json_file.stem),
                        "project": data.get("project", "?"),
                        "title": data.get("title", data.get("name", "")),
                        "note": data.get("approvalNote", ""),
                        "path": rel_path,
                    })
            except Exception:
                pass

    # Plans
    plans_dir = admiralty_dir / "plans"
    if plans_dir.exists():
        for md_file in sorted(plans_dir.glob("*.md")):
            fm = _read_md_frontmatter(md_file)
            if fm.get("status", "").lower() == "awaiting-approval":
                try:
                    rel_path = md_file.relative_to(base_dir).as_posix()
                except ValueError:
                    rel_path = str(md_file)
                items.append({
                    "type": "PLAN",
                    "id": md_file.name,
                    "project": fm.get("project", "?"),
                    "title": fm.get("title", ""),
                    "note": fm.get("approvalNote", ""),
                    "path": rel_path,
                })

    # Requirements
    reqs_dir = admiralty_dir / "requirements"
    if reqs_dir.exists():
        for md_file in sorted(reqs_dir.glob("*.md")):
            fm = _read_md_frontmatter(md_file)
            if fm.get("status", "").lower() == "awaiting-approval":
                try:
                    rel_path = md_file.relative_to(base_dir).as_posix()
                except ValueError:
                    rel_path = str(md_file)
                items.append({
                    "type": "REQ",
                    "id": md_file.name,
                    "project": fm.get("project", "?"),
                    "title": fm.get("title", ""),
                    "note": fm.get("approvalNote", ""),
                    "path": rel_path,
                })

    # Sort by project acronym, then by type
    items.sort(key=lambda x: (x["project"], x["type"], x["id"]))
    return items


def cleanup_orphaned_crew(crew_num: int):
    """Mark a RUNNING crew as CRASHED if its process is dead."""
    state_file = get_workspace_dir() / "crews" / f"crew{crew_num}" / "state.json"
    try:
        state = load_json_safe(state_file)
        if state:
            state["status"] = "CRASHED"
            state_file.write_text(json.dumps(state, indent=2), encoding='utf-8')
    except:
        pass


# =============================================================================
# DASHBOARD DISPLAY
# =============================================================================

def _get_bridge_notifier():
    """Lazy-load the BridgeNotifier singleton (None if unavailable)."""
    if not hasattr(_get_bridge_notifier, "_instance"):
        try:
            from bridge_notifier import BridgeNotifier
            _get_bridge_notifier._instance = BridgeNotifier(get_workspace_dir())
        except Exception:
            _get_bridge_notifier._instance = None
    return _get_bridge_notifier._instance


def print_dashboard(settings: Dict):
    """Print the unified Maestro Monitor dashboard."""
    os.system('cls' if os.name == 'nt' else 'clear')

    now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    max_crews = settings["maxCrews"]
    W = 74  # Dashboard width

    # Gather crew data
    crews_data = []
    active_crews = 0
    complete_crews = 0
    failed_crews = 0

    for i in range(1, max_crews + 1):
        crew = get_crew_activity(i)
        crews_data.append(crew)

        if crew["status"] in ["RUNNING", "ACTIVE"]:
            # Check for orphaned process
            if crew["pid"] and not is_process_alive(crew["pid"]):
                cleanup_orphaned_crew(i)
                crew["status"] = "CRASHED"
                failed_crews += 1
            else:
                active_crews += 1
        elif crew["status"] == "COMPLETE":
            complete_crews += 1
        elif crew["status"] in ["FAILED", "CRASHED", "BLOCKED", "ERROR"]:
            failed_crews += 1

    # Get dispatcher and queue info
    dispatcher = get_dispatcher_status()
    queues = get_queue_counts()
    total_queue = sum(q["count"] for q in queues.values())

    # ===================== HEADER =====================
    _p = current_persona()
    _product = _p.term("product").upper()
    _version = resolve_version()
    print()
    print(f"  {C.CYAN}{C.BOLD}+{'=' * W}+")
    print(f"  |{(_product + ' MONITOR v' + _version):^{W}}|")
    print(f"  |{now:^{W}}|")
    print(f"  +{'=' * W}+{C.RESET}")
    print()

    # ===================== DISPATCHER =====================
    if dispatcher["running"]:
        disp_label = f"{C.GREEN}[ACTIVE]{C.RESET} PID:{dispatcher['pid']}"
    else:
        disp_label = f"{C.DIM}[STOPPED]{C.RESET}"

    print(f"  {C.BOLD}DISPATCHER{C.RESET}  {disp_label}")
    print(f"  {C.DIM}{'-' * W}{C.RESET}")

    if dispatcher["running"]:
        uptime_str = "--:--"
        if dispatcher["startTime"]:
            uptime_secs = get_elapsed_seconds(dispatcher["startTime"])
            uptime_str = format_duration(uptime_secs) if uptime_secs > 0 else "--:--"
        print(f"    Mode: Auto-Dispatch | Max {_p.term('squad').title()}s: {max_crews} | Uptime: {uptime_str}")
    else:
        print(f"    {C.DIM}No dispatcher running - {_p.term('squad').lower()}s idle{C.RESET}")
    print()

    # ===================== BRIDGE NOTIFICATIONS =====================
    approval_items = get_approval_items()
    notifier = _get_bridge_notifier()
    if notifier and notifier.enabled:
        # Gather escalation items for the notifier
        esc_items = []
        esc_path = get_workspace_dir() / "queues" / "escalations"
        if esc_path.exists():
            for esc_file in esc_path.glob("*.json"):
                try:
                    esc_data = json.loads(esc_file.read_text(encoding="utf-8"))
                    if esc_data.get("status") == "PENDING":
                        esc_items.append(esc_data)
                except Exception:
                    pass
        # Run in background thread to avoid stalling the dashboard refresh
        def _notify():
            try:
                notifier.check_and_notify(approval_items, esc_items)
            except Exception:
                pass
        threading.Thread(target=_notify, daemon=True).start()

    # ===================== APPROVALS =====================
    if approval_items:
        print(f"  {C.YELLOW}{C.BOLD}APPROVALS — AWAITING {_p.term('userTitle').upper()} REVIEW{C.RESET}")
        print(f"  {C.YELLOW}{'-' * W}{C.RESET}")
        current_project = None
        for item in approval_items:
            if item["project"] != current_project:
                current_project = item["project"]
            itype = f"[{item['type']:<6}]"
            id_str = item["id"]
            title_str = f"  {item['title']}" if item["title"] else ""
            print(f"  {C.YELLOW}{itype}  {id_str}  {item['project']}{title_str}{C.RESET}")
            if item["note"]:
                print(f"  {C.YELLOW}          Note: {item['note']}{C.RESET}")
            print(f"  {C.YELLOW}          Path: {item['path']}{C.RESET}")
            print()
        print()

    # ===================== PENDING REVIEW =====================
    review_items = get_pending_review_items()
    if review_items:
        print(f"  {C.MAGENTA}{C.BOLD}PENDING REVIEW — AWAITING {_p.term('userTitle').upper()} APPROVAL{C.RESET}")
        print(f"  {C.MAGENTA}{'-' * W}{C.RESET}")
        print(f"  {C.BOLD}{'STORY':<24} {_p.term('sprint').upper():<26} {'AGE':<10}{C.RESET}")
        for item in review_items:
            print(f"  {C.MAGENTA}{item['order_id']:<24} {item['voyage_id']:<26} {item['age']:<10}{C.RESET}")
        print()

    # ===================== SQUAD STATUS =====================
    _squad_label = _p.term("squad").upper()
    print(f"  {C.BOLD}{_squad_label} STATUS{C.RESET}")
    print(f"  {C.DIM}{'-' * W}{C.RESET}")
    print(f"  {C.BOLD}{_squad_label:<18} {'PID':<8} {'STATUS':<12} {'STEPS':<8} {'ITER':<8} {'ROLE':<6} {'MODEL':<8} {'ORDER':<20}{C.RESET}")
    print(f"  {C.DIM}{'-' * W}{C.RESET}")

    for i, crew in enumerate(crews_data, 1):
        codename = get_squad_name(i)
        crew_label = f"{i}. {codename}"
        role = crew.get("role", "-")
        order = crew.get("order", "-")
        if order and len(order) > 18:
            order = order[:18]
        pid = crew.get("pid")
        pid_str = str(pid) if pid and is_process_alive(pid) else "-"

        status = crew["status"]
        iteration = crew.get("iteration", 0)
        max_iter = crew.get("maxIterations", 0)
        iter_str = f"{iteration}/{max_iter}" if status not in ["IDLE"] else "-"

        # FTR-MSO-2026-0227: live step counter from stream-json state.
        # (Column labelled "STEPS" — each step is one model turn in the crew's agentic loop.)
        live_turn = crew.get("liveTurn", 0)
        max_turns = crew.get("maxTurns", 0)
        if status in ["RUNNING", "ACTIVE"] and max_turns:
            turn_str = f"{live_turn}/{max_turns}"
        elif status not in ["IDLE"]:
            turn_str = str(live_turn) if live_turn else "-"
        else:
            turn_str = "-"

        # v3.1: Resolve model from role
        model_label = get_role_model(role) if status not in ["IDLE"] else "-"

        # Status icon and color
        if status in ["RUNNING", "ACTIVE"]:
            icon = f"{C.YELLOW}[>>>>]{C.RESET}"
            status_color = C.YELLOW
            status_display = "RUNNING"
        elif status == "COMPLETE":
            icon = f"{C.GREEN}[DONE]{C.RESET}"
            status_color = C.GREEN
            status_display = "COMPLETE"
        elif status in ["BLOCKED", "ERROR", "CRASHED", "TIMEOUT"]:
            icon = f"{C.RED}[FAIL]{C.RESET}"
            status_color = C.RED
            status_display = status
        elif status in ["MAX_ITERATIONS", "CIRCUIT_BREAKER"]:
            icon = f"{C.MAGENTA}[MAX ]{C.RESET}"
            status_color = C.MAGENTA
            status_display = "MAX_ITER"
        else:
            icon = f"{C.DIM}[IDLE]{C.RESET}"
            status_color = C.DIM
            status_display = "IDLE"

        print(f"  {icon} {crew_label:<11} {C.CYAN}{pid_str:<8}{C.RESET} "
              f"{status_color}{status_display:<12}{C.RESET} {turn_str:<8} "
              f"{iter_str:<8} {role:<6} {model_label:<8} {C.DIM}{order}{C.RESET}")

        # Detail line for active crews
        if status in ["RUNNING", "ACTIVE"]:
            elapsed_secs = get_elapsed_seconds(crew.get("startTime", ""))
            elapsed_str = format_duration(elapsed_secs)
            activity = crew.get("activity", "Working...")
            files_changed = crew.get("filesChanged", 0)
            files_str = f"  Files: {files_changed}" if files_changed > 0 else ""
            if len(activity) > 43:
                activity = activity[:40] + "..."
            print(f"         {C.DIM}> {activity:<43} Elapsed: {elapsed_str}{files_str}{C.RESET}")

        # Detail line for completed crews
        elif status == "COMPLETE":
            total_str = "--:--"
            if crew.get("endTime") and crew.get("startTime"):
                try:
                    start = datetime.fromisoformat(crew["startTime"])
                    end = datetime.fromisoformat(crew["endTime"])
                    total_secs = (end - start).total_seconds()
                    total_str = format_duration(total_secs)
                except:
                    pass
            activity = crew.get("activity", "")
            if activity and activity != "Working..." and activity != "-":
                if len(activity) > 45:
                    activity = activity[:45] + "..."
                print(f"         {C.DIM}> {activity:<50} Total: {total_str}{C.RESET}")
            else:
                print(f"         {C.DIM}{'':51} Total: {total_str}{C.RESET}")

    print(f"  {C.DIM}{'-' * W}{C.RESET}")
    print()

    # ===================== ESCALATIONS (v7.0) =====================
    esc_info = queues.get("escalations", {"count": 0, "details": {}})
    if esc_info["count"] > 0:
        _ep = current_persona()
        print(f"  {C.RED}{C.BOLD}!! ESCALATIONS: {esc_info['count']} pending (requires {_ep.term('userTitle')}/{_ep.term('leadTitle')} review) !!{C.RESET}")
        # Show escalation details
        esc_path = get_workspace_dir() / "queues" / "escalations"
        if esc_path.exists():
            for esc_file in sorted(esc_path.glob("*.json"))[:3]:
                try:
                    esc_data = json.loads(esc_file.read_text(encoding='utf-8'))
                    if esc_data.get("status") == "PENDING":
                        block_tag = f" {C.RED}[BLOCKING]{C.RESET}" if esc_data.get("blocking") else ""
                        print(f"    {C.YELLOW}> {esc_data.get('id', '?')}: {esc_data.get('title', '?')[:40]}{block_tag}{C.RESET}")
                except:
                    pass
        print()

    # ===================== QUEUES =====================
    print(f"  {C.BOLD}QUEUES{C.RESET}")
    print(f"  {C.DIM}{'-' * W}{C.RESET}")

    req_info = queues.get("requests", {"count": 0, "details": {}})
    ord_info = queues.get("orders", {"count": 0, "details": {}})

    if total_queue > 0:
        # Requests line
        if req_info["count"] > 0:
            detail_parts = [f"{k}:{v}" for k, v in req_info["details"].items()]
            detail_str = f"  [{' '.join(detail_parts)}]" if detail_parts else ""
            print(f"    {C.MAGENTA}Requests:{C.RESET} {req_info['count']} pending{detail_str}")

        # Orders line
        if ord_info["count"] > 0:
            detail_parts = [f"{k}:{v}" for k, v in ord_info["details"].items()]
            detail_str = f"  [{' '.join(detail_parts)}]" if detail_parts else ""
            print(f"    {C.BLUE}Orders:{C.RESET}   {ord_info['count']} pending{detail_str}")

        # Other queues
        other_count = total_queue - req_info["count"] - ord_info["count"]
        if other_count > 0:
            other_parts = []
            for name, info in queues.items():
                if name not in ["requests", "orders"] and info["count"] > 0:
                    other_parts.append(f"{name}:{info['count']}")
            if other_parts:
                print(f"    {C.DIM}Other:    {' '.join(other_parts)}{C.RESET}")
    else:
        print(f"    {C.DIM}All queues empty{C.RESET}")
    print()

    # ===================== LIFECYCLE LOG =====================
    events = get_lifecycle_log(8)
    if events:
        print(f"  {C.BOLD}LIFECYCLE LOG{C.RESET}")
        print(f"  {C.DIM}{'-' * W}{C.RESET}")
        for event in reversed(events):  # Most recent first
            print(f"    {C.DIM}{event}{C.RESET}")
        print()

    # ===================== FOOTER =====================
    # Bridge status indicator
    bridge_str = ""
    if notifier and notifier.enabled:
        bs = notifier.get_status()
        if bs["connected"]:
            pending = bs["pending_notifications"]
            pend_str = f" ({pending} pending)" if pending > 0 else ""
            bridge_str = f" {C.DIM}|{C.RESET} {C.GREEN}Bridge: ON{pend_str}{C.RESET}"
        else:
            bridge_str = f" {C.DIM}|{C.RESET} {C.RED}Bridge: NO TOKEN{C.RESET}"

    print(f"  {C.CYAN}{C.BOLD}+{'=' * W}+{C.RESET}")
    print(f"  {C.WHITE}  Active: {C.YELLOW}{active_crews}{C.RESET}"
          f" {C.DIM}|{C.RESET} {C.WHITE}Done: {C.GREEN}{complete_crews}{C.RESET}"
          f" {C.DIM}|{C.RESET} {C.WHITE}Failed: {C.RED}{failed_crews}{C.RESET}"
          f" {C.DIM}|{C.RESET} {C.WHITE}Queue: {total_queue}{C.RESET}"
          f" {C.DIM}|{C.RESET} {C.WHITE}Max: {max_crews}{C.RESET}"
          f"{bridge_str}"
          f" {C.DIM}| Refresh: 5s | Ctrl+C to exit{C.RESET}")
    print(f"  {C.CYAN}{C.BOLD}+{'=' * W}+{C.RESET}")
    print()


def print_compact(settings: Dict):
    """Print a one-line compact status summary."""
    max_crews = settings["maxCrews"]
    active = 0
    complete = 0
    failed = 0

    for i in range(1, max_crews + 1):
        crew = get_crew_activity(i)
        if crew["status"] in ["RUNNING", "ACTIVE"]:
            if crew["pid"] and is_process_alive(crew["pid"]):
                active += 1
            else:
                failed += 1
        elif crew["status"] == "COMPLETE":
            complete += 1
        elif crew["status"] in ["FAILED", "CRASHED", "BLOCKED", "ERROR"]:
            failed += 1

    queues = get_queue_counts()
    total_queue = sum(q["count"] for q in queues.values())
    dispatcher = get_dispatcher_status()
    disp_str = f"DISP:ON(PID:{dispatcher['pid']})" if dispatcher["running"] else "DISP:OFF"

    now = datetime.now().strftime('%H:%M:%S')
    print(f"[{now}] {disp_str} | Crews: {active} active, {complete} done, {failed} fail | Queue: {total_queue}")


# =============================================================================
# MAIN
# =============================================================================

def run_monitor(refresh_seconds: int = 5, once: bool = False, compact: bool = False):
    """Run the monitor loop."""
    settings = get_settings()

    if once:
        if compact:
            print_compact(settings)
        else:
            print_dashboard(settings)
        return

    try:
        while True:
            if compact:
                print_compact(settings)
            else:
                print_dashboard(settings)
            time.sleep(refresh_seconds)
    except KeyboardInterrupt:
        print(f"\n\n  {C.CYAN}{current_persona().term('product')} Monitor stopped.{C.RESET}\n")


def main():
    parser = argparse.ArgumentParser(
        description=f"Maestro Monitor v{resolve_version()} - Unified Dashboard",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s                     # Default: 5s refresh, full dashboard
  %(prog)s --refresh 10        # Custom refresh interval
  %(prog)s --once              # One-shot display, then exit
  %(prog)s --compact           # One-line summary mode
        """
    )
    parser.add_argument("--refresh", type=int, default=5,
                       help="Refresh interval in seconds (default: 5)")
    parser.add_argument("--once", action="store_true",
                       help="Display once and exit (no loop)")
    parser.add_argument("--compact", action="store_true",
                       help="One-line compact status summary")
    # Legacy positional argument support (old: python fleet_monitor.py 5)
    parser.add_argument("refresh_legacy", nargs="?", type=int, default=None,
                       help=argparse.SUPPRESS)

    args = parser.parse_args()

    # Support legacy positional refresh argument
    refresh = args.refresh
    if args.refresh_legacy is not None:
        refresh = args.refresh_legacy
        if refresh == 0:
            args.once = True

    # PID lock - prevent duplicate instances
    if not args.once and not args.compact:
        if not check_monitor_lock():
            print(f"\n  {C.YELLOW}Maestro Monitor is already running in another window.{C.RESET}")
            print(f"  {C.DIM}Kill the existing instance first, or check .mso/monitor.pid{C.RESET}\n")
            return 1
        atexit.register(release_monitor_lock)

    run_monitor(refresh_seconds=refresh, once=args.once, compact=args.compact)
    return 0


if __name__ == "__main__":
    run_cli(main, command="mso status")


# ---------------------------------------------------------------------------
# Rebrand vocabulary (FTR-MSO-2026-0155) — new canonical names
# ---------------------------------------------------------------------------

class TeamMonitor:
    """Namespace sentinel for the fleet/team monitor subsystem."""


# Legacy alias — kept through v3.x, removed in v4.0
FleetMonitor = TeamMonitor  # legacy alias (v3.x); removed v4.0
