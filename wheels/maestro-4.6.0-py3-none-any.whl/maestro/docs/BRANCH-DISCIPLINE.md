# Branch discipline — voyage-branch identity is enforced

> Operator reference. Background: [BUG-ADM-2026-0004](../.mso/queues/bugs/complete/BUG-ADM-2026-0004.json). Plan: [.mso/plans/PLAN-BUG-ADM-2026-0004.md](../.mso/plans/PLAN-BUG-ADM-2026-0004.md).

## What changed

The `voyageBranch` field on every order used to be advisory — it described which branch the order *should* run on, but nothing verified that crews actually operated there. Cross-voyage contamination from running dispatchers (most visibly during the VOY-0028 / VOY-0030 batch1 split, PR #30 → PR #31 + #32) was the symptom.

`voyageBranch` is now **load-bearing**:

| Layer | What it does |
|---|---|
| **Dispatcher** ([maestro/core/fleet_runner.py](../maestro/core/fleet_runner.py)) | Each crew runs in its own git worktree on the correct voyage branch. The dispatcher does not switch the parent shell branch. |
| **Pretool branch guard** ([maestro/hooks/branch_guard.py](../maestro/hooks/branch_guard.py)) | Inspects every `Bash` tool call for `git`/`gh` mutations (commit, push, checkout, switch, merge, rebase, reset, tag, am, cherry-pick, branch -D, gh pr create / merge / close, gh release create, gh api graphql). If `MAESTRO_VOYAGE_BRANCH` is set and HEAD doesn't match, the tool call is denied with a structured `decision: deny` reason that names both the actual and expected branches. |
| **Pretool path-confinement guard** ([maestro/hooks/path_guard.py](../maestro/hooks/path_guard.py)) | **BUG-MSO-2026-0282**: the branch guard only sees `git`/`gh` mutations — it never sees plain `Edit`/`Write`/`NotebookEdit` or `Bash` file writes (redirections, `tee`) whose target **path** lands in a different working tree. This guard denies any crew file mutation resolving into the **danger zone**: under the main repo root but OUTSIDE the crew's own `MAESTRO_REPO_PATH` worktree (the main checkout or a sibling voyage worktree). Scratch writes elsewhere (`/tmp`, …) and in-worktree writes are unaffected. This is *path*-confinement, complementing the *branch*-name confinement above. |
| **Role prompts** ([maestro/roles/*.md](../maestro/roles/)) | Every role prompt template now includes a "## Branch discipline" section instructing the crew to run `git rev-parse --abbrev-ref HEAD` before any git mutation. COX gets an additional sub-section pinning `gh pr create --head $MAESTRO_VOYAGE_BRANCH --base main`. |

> **v4.0+**: The dispatcher's parent shell branch does not affect crew dispatch — worktrees provide isolation (see [PARALLEL-VOYAGES.md](PARALLEL-VOYAGES.md)). Operators may keep their parent shell on any branch without affecting voyages. The branch_guard hook (BUG-ADM-2026-0009) still applies inside each worktree.

## Environment variables

| Variable | Set by | Purpose |
|---|---|---|
| `MAESTRO_VOYAGE_BRANCH` | Dispatcher (per crew launch) | The branch the crew must operate on. Read by both the role prompt and the pretool guard. **Empty / unset = guard refuses mutating `git`/`gh` operations** (BUG-ADM-2026-0009, v2.5.7). Read-only commands stay free. |
| `MAESTRO_BRANCH_GUARD_BYPASS` | **Operator only — explicit** | When set to `1`, the pretool branch guard fails open — and (since BUG-MSO-2026-0282) the path-confinement guard too. Use **only** for QM manual-recovery sessions; never set it inside crew sessions or in `.mso/config/*`. |
| `MAESTRO_PATH_GUARD_BYPASS` | **Operator only — explicit** | **BUG-MSO-2026-0282**: when set to `1`, the path-confinement guard alone fails open (the branch guard still applies). For QM manual-recovery sessions that need to write across trees. |
| `MAESTRO_REPO_PATH` | Dispatcher (per crew launch) | The crew's worktree path. The path-confinement guard treats writes outside this (but inside the repo) as cross-tree contamination and denies them. |

## Read-only commands are unaffected

`git status`, `git log`, `git diff`, `git fetch`, `git ls-files`, `git rev-parse`, etc. are not gated. Branch discipline cares about state mutations only.

## Common scenarios

### A crew tries to push to the wrong branch

```text
[BLOCKED] Branch guard: refusing `git push origin main` because current branch
is `main` but this order's voyageBranch is `voyage/VOY-ADM-2026-0031-licence-backend`.
Switch to `voyage/VOY-ADM-2026-0031-licence-backend` before mutating git state.
```

The crew's tool call is denied; the crew sees the reason and can self-correct.

### A crew tries `gh pr create --head voyage/wrong`

```text
[BLOCKED] Branch guard: `gh pr create --head voyage/wrong` does not match the
order's voyageBranch `voyage/VOY-ADM-2026-0031-licence-backend`.
```

### Manual QM recovery from the wrong branch

If you're rebuilding state by hand and need to mutate git outside a voyage branch's identity (e.g. cherry-picking across voyages during a split — see the batch1 split history), set the bypass in your shell:

```bash
MAESTRO_BRANCH_GUARD_BYPASS=1 git push origin some-recovery-branch
```

Don't put the bypass in `.mso/config/*` — it must come from the parent shell so it can't be silently inherited by a crew session.

## When the dispatcher refuses to launch

If you see this in the dispatcher log:

```text
[ERROR] Branch guard refused crew launch for FTR-ADM-2026-XXXX
(voyageBranch=voyage/...). Fix the branch state and re-dispatch.
```

The dispatcher couldn't bring its parent shell onto the right branch. Most likely causes:

1. The voyage branch doesn't exist locally **or** on `origin`. Push the branch first (`git push -u origin <voyage-branch>`).
2. There's a merge conflict against `main`. Resolve it on the branch, then re-dispatch.
3. Filesystem lock on `.git/index.lock`. Another git process is in flight; wait for it to release.

## BUG-ADM-2026-0009 (v2.5.7) — strict refuse + propagation chain

Pre-v2.5.7, two fail-open hatches let a crew without `voyageBranch` push to whatever branch the dispatcher's shell happened to be on:

- `branch_guard.py` allowed every `git`/`gh` mutation when `MAESTRO_VOYAGE_BRANCH` was unset
- the dispatcher's branch check was a no-op (the "legacy loose-order path")

Captain's PSG retest of v2.5.6 hit this: a crew checked out `restructure/flatten-structure` from a prior session, made 3 commits, and pushed. The voyage branch silently missed the work.

### Strict refuse (every role, every git/gh mutation)

From v2.5.7 the dispatcher refuses to launch any role when `voyageBranch` is unresolvable. The branch-guard pretool hook denies any `git`/`gh` mutation without an active voyage branch. Both emit clear errors that name the bypass.

| Role | Without `voyageBranch` |
|------|------------------------|
| NAV / SHP / BOS / SCR / LKT / COX | Refused. Order marked `FAILED` with `failureReason="voyageBranch not resolved"` and a `DISPATCH_BLOCK` lifecycle event. |
| Read-only `git status` / `git diff` / `git log` | Still allowed — non-mutating commands stay free. |

### Propagation chain (single source of truth)

Branch identity now flows from voyage → order → role:

1. **`order.voyageBranch`** — explicit on the order (highest priority)
2. **`voyage.branch`** — inherited from the parent voyage when the order omits it
3. **`MAESTRO_VOYAGE_BRANCH` env var** — operator shell, current dispatcher run
4. *empty* — refuse

When the resolver pulls from layer 2 or 3, the dispatcher writes the resolved value back to the order JSON on disk. So once a single role resolves the branch, every subsequent role in the order's `roleSequence` reads it directly without re-resolving.

### `BRANCH_MISMATCH` defence in depth

If an order has an explicit `voyageBranch` that disagrees with its parent voyage's `branch`, the order-level value wins (operator's edit is intentional) but the dispatcher logs a `BRANCH_MISMATCH` lifecycle event so the drift is visible. Reconcile by hand if it was accidental.

### Recovery from misrouted commits

If you discover a crew committed to the wrong branch (the BUG-0009 scenario):

```bash
# 1. Identify the misrouted commits
git log origin/<wrong-branch> --since="<dispatch-time>" --author="<crew-author>" --oneline

# 2. Cherry-pick onto the correct voyage branch
git checkout <correct-voyage-branch>
git cherry-pick <sha1> <sha2> <sha3>
git push

# 3. (Optional) reset the polluted branch if no other work depends on those commits
git push origin +<correct-voyage-branch-prior-sha>:refs/heads/<wrong-branch>
```

If the polluted branch is shared, prefer cherry-pick + leave the duplicates rather than force-resetting someone else's history.

## Tests

The behaviour is locked in by [tests/test_branch_guard.py](../tests/test_branch_guard.py) covering: denial cases, approval cases, bypass mode, Captain-direct mode, dispatcher checkout creation, both forms of the `gh pr create --head` flag (space, equals, quoted), explicit cross-branch targets (`git checkout` / `switch` / `push origin <other-branch>` while on the voyage branch), and credential redaction in deny reasons. Run `pytest tests/test_branch_guard.py -v` to see the full matrix.
