# Maestro — Enterprise Setup Guide

This guide covers deploying Maestro for multi-team enterprise use: network requirements, data residency, compliance notes, and SSO configuration.

> For individual and small-team setup, see [GETTING-STARTED.md](GETTING-STARTED.md).
> For pricing and tier comparison, see [PRICING.md](PRICING.md).
>
> **Version scope:** This guide targets **v2.5.0** enterprise features (licence keys via `mso licence activate`, `MAESTRO_LICENCE_KEY` for non-interactive). The legacy GitHub-collaborator PAT path is retained as a transitional fallback only.

---

## Contents

1. [Overview](#1-overview)
2. [Network Requirements](#2-network-requirements)
3. [Multi-Team Deployment](#3-multi-team-deployment)
4. [Data Residency](#4-data-residency)
5. [Compliance Notes](#5-compliance-notes)
6. [SSO (Enterprise IdP)](#6-sso-enterprise-idp)
7. [Licence Key Management](#7-licence-key-management)
8. [Air-Gap and Restricted Networks](#8-air-gap-and-restricted-networks)
9. [Deployment Checklist](#9-deployment-checklist)

---

## 1. Overview

Maestro is a local orchestration framework. The core system runs entirely on the developer's machine or CI host — there is no Maestro application server, no data sent to Maestro infrastructure, and no persistent cloud state.

**What runs locally:**
- `fleet-runner.py` (dispatcher)
- `fleet_monitor.py` (dashboard)
- All crew Claude Code sessions
- All workspace state (orders, voyages, plans, usage records)

**What leaves the local machine:**
- Claude Code API calls to Anthropic (via `ANTHROPIC_API_KEY`)
- Git operations (push/pull to your own source repositories)
- Licence key validation (local HMAC check — no server call by default; see [Section 8](#8-air-gap-and-restricted-networks))

Enterprise deployments typically involve:
- One Maestro workspace per team or department
- Shared source repositories accessed via crew managed clones
- Centralised API key management
- Workspace backup to a shared store

---

## 2. Network Requirements

### Outbound connections required

| Destination | Port | Purpose | Required |
|-------------|------|---------|---------|
| `api.anthropic.com` | 443 (HTTPS) | Claude Code API (crew sessions) | Yes |
| `github.com` (or your Git host) | 443 / 22 | Repo clone and push for crew work | Yes |
| `pypi.org` / GitHub | 443 | pip install (install time only) | Install only |

### Optional / non-mandatory

| Destination | Port | Purpose |
|-------------|------|---------|
| `github.com` API | 443 | GitHub collaborator auth fallback (not needed if using licence key) |

### Firewall configuration

At minimum, ensure outbound HTTPS to `api.anthropic.com` is permitted from the host(s) running Maestro. All Claude Code API traffic uses HTTPS (TLS 1.2 or later).

If your organisation uses a TLS-inspection proxy, ensure the proxy CA certificate is trusted on the Maestro host. Claude Code uses the system certificate store.

### Proxy support

Set standard proxy environment variables before running Maestro commands:

```bash
export HTTPS_PROXY=https://proxy.your-org.internal:8080
export HTTP_PROXY=http://proxy.your-org.internal:8080
export NO_PROXY=localhost,127.0.0.1,your-internal-git-host
```

These are inherited by all crew Claude Code subprocesses automatically.

---

## 3. Multi-Team Deployment

### One workspace per team (recommended)

Each team maintains its own Maestro workspace containing that team's projects, orders, and voyages. This provides clear ownership boundaries and prevents cross-team order interference.

```
/workspaces/
├── team-frontend/          # Frontend team workspace
│   ├── .maestro/
│   └── ...
├── team-backend/           # Backend team workspace
│   ├── .maestro/
│   └── ...
└── team-platform/          # Platform team workspace
    ├── .maestro/
    └── ...
```

### Shared source repositories

Each workspace references one or more source repositories via `projects.json`. Multiple teams can reference the same source repository — each workspace maintains its own voyage branch namespace to avoid conflicts.

Configure different `voyageBranchPattern` values per team to avoid branch collisions:

```json
{
  "projects": {
    "FRONTEND": {
      "repo": "your-org/frontend",
      "voyageBranchPattern": "voyage/frontend/{VOYAGE-ID}"
    }
  }
}
```

### CI/CD integration

Maestro can run in CI for automated order dispatch. Set the following in your CI environment:

```bash
# Required
export ANTHROPIC_API_KEY=<your-key>

# Legacy auth (transitional): GitHub collaborator PAT — kept as fallback
export MAESTRO_GITHUB_PAT=ghp_<your-pat>

# v2.5.0+: Licence-key auth (now the primary path)
# export MAESTRO_LICENCE_KEY=ADM-ENT-<hash>-<expiry>-<checksum>

# Recommended for CI
export MAESTRO_SKIP_AUTH=1    # Bypass auth for CI runs (if using trusted internal key)
```

The `MAESTRO_SKIP_AUTH=1` bypass is for trusted internal environments where auth has been handled upstream. Do not use this in publicly accessible environments.

### Resource limits

Each crew runs a Claude Code subprocess. Plan for:

| Teams | Max concurrent crews per team | Concurrent Claude sessions (worst case) |
|-------|-------------------------------|-----------------------------------------|
| 1 | 5 | 5 |
| 3 | 5 each | 15 |
| 5 | 5 each | 25 |

Anthropic API rate limits apply per API key. For large multi-team deployments, consider separate API keys per team or per workspace to distribute rate limits.

---

## 4. Data Residency

### Where workspace data lives

All Maestro workspace data is local to the machine or file server where the workspace is stored. Maestro does not transmit workspace content to any Maestro-operated service.

| Data type | Location | Leaves the machine? |
|-----------|----------|---------------------|
| Orders, voyages, plans | `\.maestro/` directories | No (unless you back up to cloud storage) |
| Crew prompts and context | `.maestro/crews/crewN/` | No |
| Token usage records | `.maestro/usage/` | No |
| Licence key | `~/.maestro/licence.json` | No |
| Source code changes | Your Git repositories | Yes (pushed to your Git host) |
| Claude API requests | Sent to `api.anthropic.com` | Yes — see below |

### Claude API data handling

Crew sessions send prompts (including order content and code context) to the Anthropic API. Anthropic's data handling policies apply. Review [Anthropic's privacy policy](https://www.anthropic.com/privacy) for details on:

- Data retention for API requests
- Training data opt-out (Enterprise API agreements)
- Data residency options (where available)

For workspaces containing sensitive code or data, review what context is included in crew prompts. Orders, file reads, and code snippets are sent as part of crew sessions.

### Backup data residency

`mso backup` creates ZIP archives in a local directory by default. If you copy these to cloud storage (S3, Azure Blob, etc.), the residency of backup data is governed by your cloud storage configuration — not by Maestro.

---

## 5. Compliance Notes

### Source code and IP

Maestro crews read and write source code in managed clones. All output is committed to your own Git repositories. No source code is retained by Maestro beyond the local crew working directories (which are wiped by `mso cleanup`).

### Audit trail

Maestro maintains the following audit-relevant records locally:

| Record | Location | Contents |
|--------|----------|---------|
| Order lifecycle | `.maestro/orders/` | Status, timestamps, completion metadata |
| Voyage history | `.maestro/voyages/` | Voyage ID, orders, completion status |
| Crew activity | `.maestro/crews/crewN/activity.jsonl` | Per-tool-call structured log |
| Token usage | `.maestro/usage/orders/` | Per-order token breakdown and cost |
| Lifecycle log | Fleet monitor output | Crew starts, completions, role transitions |

Enterprise tier includes **audit export** — a structured export of the above records for compliance tooling. See `mso usage --report` for token and cost reporting.

### Secrets and credentials

Maestro itself does not store secrets. The `ANTHROPIC_API_KEY` is passed as an environment variable to crew subprocesses. Do not commit your API key to workspace files or orders.

Crew sessions are configured via Claude Code's permissions system. Review `.claude/settings.json` to restrict what commands and file paths crew sessions may access.

### GDPR and PII

If your orders or source code contain personal data, ensure your Anthropic API usage agreement covers the relevant data categories. Maestro does not process or store PII independently — any PII in prompts is subject to Anthropic's API data handling terms.

---

## 6. SSO (Enterprise IdP)

> **Status:** Enterprise SSO integration is planned for a future release. Full IdP configuration is currently in rollout.

Enterprise licence holders can configure SSO authentication via their organisation's identity provider. When configured, crew session authentication is delegated to your IdP rather than the default local licence check.

### Supported IdP protocols (planned)

- SAML 2.0
- OIDC / OAuth 2.0

### Configuration placeholder

SSO configuration will be added to the per-workspace config when the integration is available. The `mso licence status` output shows the SSO placeholder note for Enterprise tier:

```
[Maestro Licence]
  Mode:    Licence key
  Tier:    Enterprise
  ...
  SSO:     Placeholder (contact maestro@tech127.com to configure)
```

### How to proceed

To configure SSO for your Enterprise licence:

1. Contact [maestro@tech127.com](mailto:maestro@tech127.com) with your licence key and IdP type
2. You will receive SSO configuration instructions specific to your IdP
3. Once configured, SSO replaces the local licence key check for all crew sessions in the workspace

---

## 7. Licence Key Management

### Activating an Enterprise key

```bash
mso licence activate ADM-ENT-<org_hash>-<expiry>-<checksum>
```

The key is stored in `~/.maestro/licence.json` on the activating machine. For multi-machine deployments, each machine must activate separately — seat registration is per-machine.

### Deploying via environment variable

For CI/CD or shared host deployments where writing `~/.maestro/licence.json` is not practical, set the key as an environment variable:

```bash
export MAESTRO_LICENCE_KEY=ADM-ENT-a1b2c3d4-20270331-x9y8z7
```

This takes precedence over `~/.maestro/licence.json`. Suitable for ephemeral CI containers.

### Key rotation

When you receive a renewed key:

```bash
# Deactivate the old key
mso licence deactivate

# Activate the new key
mso licence activate ADM-ENT-<new-key>
```

The 30-day offline grace period means a brief gap between expiry and renewal does not immediately interrupt operations.

### Viewing licence status

```bash
mso licence status
```

Sample output for an Enterprise key:

```
[Maestro Licence]
  Mode:           Licence key
  Tier:           Enterprise
  Expires:        2027-03-31 (365 days)
  Max crews:      5
  Max projects:   Unlimited
  Features:       dispatch, status, usage, backup, estimate, approve, roi-reporting,
                  priority-support, sso-placeholder, audit-export, custom-sla
  Seat:           Registered (machine: abc123def456, since 2026-04-01)
  Last validated: 2026-04-01
  SSO:            Placeholder (contact maestro@tech127.com to configure)
```

---

## 8. Air-Gap and Restricted Networks

Maestro's licence validation is local and offline-safe by design.

### Licence key validation

Licence key checksums are verified using an embedded HMAC — no server call is made for validation. The 30-day offline grace period means the licence remains active after the last successful network operation, even with no internet access.

### Fully air-gapped operation

For workspaces that cannot reach `api.anthropic.com`, crew sessions cannot run (Claude Code requires API access). However, all workspace management commands (`mso status`, `mso backup`, `mso restore`, `mso usage`) work offline.

If your network blocks `api.anthropic.com` but allows access via an internal proxy, configure the proxy as described in [Section 2](#2-network-requirements).

### Git in restricted networks

Crews clone source repositories using the `cloneProtocol` configured in `projects.json`. For internal Git hosts:

```json
{
  "projects": {
    "MYPROJ": {
      "repo": "your-internal-git.corp/my-project",
      "cloneProtocol": "https"
    }
  }
}
```

Ensure the Maestro host can reach your Git host on the configured protocol. SSH keys or Git credential helpers apply as normal.

---

## 9. Deployment Checklist

Use this checklist when setting up an Enterprise workspace.

### Pre-deployment

- [ ] Python 3.9+ installed on all Maestro hosts
- [ ] Claude Code installed and on PATH (`claude --version`)
- [ ] `ANTHROPIC_API_KEY` set (or confirmed via enterprise key agreement)
- [ ] Outbound HTTPS to `api.anthropic.com` permitted
- [ ] Git host accessible from Maestro hosts
- [ ] Enterprise licence key received from [maestro@tech127.com](mailto:maestro@tech127.com)

### Workspace setup

- [ ] `pip install maestro-fleet` run on each host
- [ ] `mso licence activate <key>` run on each machine
- [ ] `mso licence status` confirms Enterprise tier and correct expiry
- [ ] `mso init --project <ACRONYM>` run for each project
- [ ] `projects.json` updated with correct repo URLs and protocols
- [ ] Voyage branch patterns configured per team to avoid collision
- [ ] `.gitignore` reviewed — crew runtime files should not be committed

### Security baseline

- [ ] `ANTHROPIC_API_KEY` stored in secrets manager, not in workspace files
- [ ] `.claude/settings.json` reviewed for permitted commands and file paths
- [ ] Backup destination confirmed (local path or mounted share)
- [ ] `mso backup` tested and restore verified on staging

### Go-live

- [ ] Test order dispatched and completed successfully
- [ ] `mso status --once` shows correct crew slot and dispatcher state
- [ ] `mso usage --summary` returns expected output
- [ ] Token usage and cost within expected range for test order

---

*Maestro Maestro v2.5.0 — For Enterprise support and SSO configuration, contact [maestro@tech127.com](mailto:maestro@tech127.com).*
