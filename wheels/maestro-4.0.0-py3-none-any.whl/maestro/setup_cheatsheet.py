# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential.

"""
admiralty/setup_cheatsheet.py — contextual next-steps for `adm setup`.

Given a ProjectAnalysis (FTR-0108) + prereq results (FTR-0107),
returns operator-readable suggestions. Rules-based; no Claude calls.

Plan: .adm/plans/PLAN-VOY-ADM-2026-0035.md §6
Order: FTR-ADM-2026-0110
"""

from __future__ import annotations

from typing import Optional

from maestro.personas import current_persona


def _bullet(text: str) -> str:
    return f"  - {text}"


def generate_cheatsheet(analysis, prereq_results) -> str:
    """Return contextual next-steps as markdown.

    `analysis` may be None when project_analysis is unavailable.
    `prereq_results` is the list[PrereqCheck] from maestro.setup.
    """
    rules: list[str] = []

    # --- Rules from prereq results -----------------------------------------
    by_name = {r.name: r for r in (prereq_results or [])}

    gh = by_name.get("gh_cli")
    if gh and gh.status == "WARN" and "not authenticated" in gh.message.lower():
        rules.append("Run `gh auth login` so the dispatcher can open PRs + use the GitHub API.")

    # BUG fixed via Copilot review on PR #67: the prereq names produced by
    # admiralty.setup.run_all_checks() are `anthropic_auth` and
    # `workspace_scaffold` (not `api_key` / `adm_scaffold`). Align lookups
    # so cheatsheet rules actually fire on real `adm setup` runs.
    key = by_name.get("anthropic_auth")
    if key and key.status == "FAIL":
        rules.append("Set `ANTHROPIC_API_KEY` in your shell, or sign into Claude Code, before dispatching crews.")
    elif key and key.status == "WARN":
        rules.append("Your API key looks like a placeholder — replace with a real `sk-ant-...` value.")

    scaffold = by_name.get("workspace_scaffold")
    if scaffold and scaffold.status != "OK":
        rules.append("Run `adm setup --repair` to fix `.adm/config/workspace.json`.")

    # --- Rules from project analysis ---------------------------------------
    if analysis is not None:
        # No tests detected → suggest the test-coverage template
        if not getattr(analysis, "test_layouts", None):
            rules.append("No test layout detected — start with the `test-coverage` requirement template.")

        # No docs → suggest doc-audit
        if not getattr(analysis, "has_readme", True) and not getattr(analysis, "has_docs_dir", True):
            rules.append("No README.md or docs/ — start with the `doc-audit` requirement template.")
        elif not getattr(analysis, "has_readme", True):
            rules.append("README.md missing — add one before any external customer sees the repo.")

        # No CI
        if not getattr(analysis, "has_ci", True):
            rules.append("No CI workflow detected — scaffold one in `.github/workflows/` so PRs run tests.")

        # Stale or dormant project
        activity = getattr(analysis, "recent_activity", "")
        if activity == "stale":
            rules.append("Repo has been quiet for 30-180 days — consider a `refactor` voyage to revive momentum.")
        elif activity == "dormant":
            rules.append("Repo has been dormant (>180 days) — onboarding a new contributor? Use the `project-setup` template.")

        # Python project without pyproject.toml (only requirements.txt) — modernise
        primary = getattr(analysis, "primary_language", "") or ""
        if primary.lower() == "python":
            # crude check — analysis doesn't track per-manifest, but cheatsheet
            # rules are intentionally suggestive, not authoritative
            rules.append("Python project — confirm `pyproject.toml` is the source of truth for deps + entry points.")

        # Multiple secondary languages → mention monorepo-shape suggestions
        secondaries = getattr(analysis, "secondary_languages", []) or []
        if len(secondaries) >= 2:
            rules.append(
                f"Multi-language repo ({', '.join([primary] + list(secondaries))[:80]}) — consider a `project-setup` "
                "template to formalise per-language conventions."
            )

        # Framework-specific suggestions
        framework = (getattr(analysis, "framework", "") or "").lower()
        if framework == "next.js":
            rules.append("Next.js detected — `performance` template is a good first voyage if you have measured slowness.")
        elif framework == "fastapi":
            rules.append("FastAPI detected — `security-review` template is recommended early to lock in auth + CORS.")
        elif framework == "django":
            rules.append("Django detected — confirm `manage.py check` + `migrate` are in your CI pipeline.")

    # If no rules fired from prereqs/analysis, fall through to the
    # "everything looks set up" path. Otherwise close with the
    # always-applicable nudge toward `adm dispatch`.
    _p = current_persona()
    _engine_cmd = _p.term("engineCommand")
    _team = _p.term("team").lower()
    _squad_plural = _p.term("squad").lower() + "s"

    if not rules:
        return f"\n  No specific suggestions — your project looks set up. Run `adm {_engine_cmd}` to begin.\n"

    rules.append(f"Run `adm status` to see your {_team}, then `adm {_engine_cmd} --max-{_squad_plural} 3` to begin work.")
    return "\n  Next steps:\n" + "\n".join(_bullet(r) for r in rules) + "\n"
