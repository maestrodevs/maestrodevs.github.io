"""maestro.cli — primary entry point for mso / adm / admiralty CLI aliases."""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from maestro.launch.sandbox import spawn as _spawn
from datetime import datetime, timezone
from pathlib import Path

from maestro.personas import current_persona


# ---------------------------------------------------------------------------
# Deprecation warning helpers (for adm / admiralty invocation names)
# ---------------------------------------------------------------------------

_CLI_MARKER = ".deprecation-shown-cli"

_CLI_WARNING = (
    "[deprecation] The 'adm' / 'admiralty' commands will be removed in Maestro v4.0.\n"
    "              Use 'mso' instead.  This warning is shown once per workspace."
)


def _find_adm_dir() -> Path | None:
    """Walk up from cwd to find the .adm/ directory."""
    for path in [Path.cwd(), *Path.cwd().parents]:
        candidate = path / ".adm"
        if candidate.is_dir():
            return candidate
    return None


def _warn_once(marker_name: str, message: str) -> None:
    """Print message to stderr and create marker; skip if marker already exists."""
    adm = _find_adm_dir()
    if adm is None:
        print(message, file=sys.stderr)
        return
    marker = adm / marker_name
    if marker.exists():
        return
    print(message, file=sys.stderr)
    try:
        marker.touch()
    except OSError:
        pass


def _check_env_deprecation(invoke_name: str) -> None:
    """Error and exit if any ADMIRALTY_* env vars are detected (v4.0+)."""
    admiralty_vars = sorted(k for k in os.environ if k.startswith("ADMIRALTY_"))
    if not admiralty_vars:
        return
    _RENAME = {
        "ADMIRALTY_DIR": "MAESTRO_DIR",
        "ADMIRALTY_VOYAGE_BRANCH": "MAESTRO_SPRINT_BRANCH",
        "ADMIRALTY_REPO_PATH": "MAESTRO_REPO_PATH",
        "ADMIRALTY_TEMP": "MAESTRO_TEMP",
        "ADMIRALTY_PROJECT": "MAESTRO_PROJECT",
        "ADMIRALTY_CREW": "MAESTRO_CREW",
        "ADMIRALTY_ORDER": "MAESTRO_ORDER",
        "ADMIRALTY_ROLE": "MAESTRO_ROLE",
        "ADMIRALTY_MAX_ITERATIONS": "MAESTRO_MAX_ITERATIONS",
        "ADMIRALTY_COMPLETION_PROMISE": "MAESTRO_COMPLETION_PROMISE",
        "ADMIRALTY_SKIP_AUTH": "MAESTRO_SKIP_AUTH",
        "ADMIRALTY_BRANCH_GUARD_BYPASS": "MAESTRO_BRANCH_GUARD_BYPASS",
        "ADMIRALTY_CREW_DRAIN_SECONDS": "MAESTRO_SQUAD_DRAIN_SECONDS",
        "ADMIRALTY_LICENCE_KEY": "MAESTRO_LICENCE_KEY",
        "ADMIRALTY_LICENCE_FAKE_ACTIVATION": "MAESTRO_LICENCE_FAKE_ACTIVATION",
        "ADMIRALTY_LICENCE_TEST_FLAGS": "MAESTRO_LICENCE_TEST_FLAGS",
        "ADMIRALTY_LICENCE_API_BASE": "MAESTRO_LICENCE_API_BASE",
        "ADMIRALTY_LICENCE_GRACE_DAYS": "MAESTRO_LICENCE_GRACE_DAYS",
        "ADMIRALTY_OFFLINE_GRACE_DAYS": "MAESTRO_OFFLINE_GRACE_DAYS",
        "ADMIRALTY_SLACK_BOT_TOKEN": "MAESTRO_SLACK_BOT_TOKEN",
        "ADMIRALTY_SLACK_APP_TOKEN": "MAESTRO_SLACK_APP_TOKEN",
        "ADMIRALTY_BRIDGE_GIST_ID": "MAESTRO_BRIDGE_GIST_ID",
        "ADMIRALTY_GITHUB_TOKEN": "MAESTRO_GITHUB_TOKEN",
        "ADMIRALTY_REQUIRE_API_KEY": "MAESTRO_REQUIRE_API_KEY",
        "ADMIRALTY_REPOS_DIR": "MAESTRO_REPOS_DIR",
        "ADMIRALTY_POLAR_ORG_SLUG": "MAESTRO_POLAR_ORG_SLUG",
        "ADMIRALTY_POLAR_PRODUCT_PRO": "MAESTRO_POLAR_PRODUCT_PRO",
        "ADMIRALTY_POLAR_PRODUCT_TEAM": "MAESTRO_POLAR_PRODUCT_TEAM",
        "ADMIRALTY_POLAR_PRODUCT_ENT": "MAESTRO_POLAR_PRODUCT_ENT",
        "ADMIRALTY_POLAR_PORTAL_URL": "MAESTRO_POLAR_PORTAL_URL",
        "ADMIRALTY_KEYRING_INDEX": "MAESTRO_KEYRING_INDEX",
    }
    lines = ["[maestro] Error: ADMIRALTY_* env vars are no longer supported in v4.0+."]
    lines.append("  Rename the following variables and re-run:\n")
    for var in admiralty_vars:
        new = _RENAME.get(var)
        if not new:
            if var.startswith("ADMIRALTY_MODEL_"):
                new = var.replace("ADMIRALTY_MODEL_", "MAESTRO_MODEL_", 1)
            elif var.startswith("ADMIRALTY_SECRET_"):
                new = var.replace("ADMIRALTY_SECRET_", "MAESTRO_SECRET_", 1)
            else:
                new = var.replace("ADMIRALTY_", "MAESTRO_", 1)
        lines.append(f"    {var} → {new}")
    lines.append("\n  See MIGRATION-v4.md for the full mapping.")
    print("\n".join(lines), file=sys.stderr)
    sys.exit(1)


# ---------------------------------------------------------------------------
# Workspace resolution
# ---------------------------------------------------------------------------

def find_workspace(project: str | None = None) -> Path:
    """
    Locate an Admiralty workspace root.

    Resolution order:
      1. Walk up from cwd looking for .adm/config/ (v2.0) or .admiralty/config/ (v1.x).
      2. If a @PRJ argument is provided, look it up in the global registry.

    Returns the workspace root path.
    Raises SystemExit with a helpful message if not found.
    """
    # 1. Local detection (walk up from cwd)
    cwd = Path.cwd()
    for path in [cwd, *cwd.parents]:
        if (path / ".adm" / "config").is_dir():
            return path
        if (path / ".admiralty" / "config").is_dir():
            import sys as _sys
            _prod = current_persona().term("product")
            print(
                f"[{_prod}] WARNING: Found legacy .admiralty/ directory. "
                "Migrate with: adm init --project <PRJ>",
                file=_sys.stderr,
            )
            return path

    # 2. Global registry lookup via @PRJ
    if project:
        acronym = project.lstrip("@").upper()
        from maestro.registry import get_project_path
        ws = get_project_path(acronym)
        if ws:
            return ws
        _prod = current_persona().term("product")
        raise SystemExit(
            f"\n[{_prod}] Project '{acronym}' not found in global registry.\n"
            "Run 'adm projects list' to see registered projects.\n"
        )

    _prod = current_persona().term("product")
    raise SystemExit(
        f"\n[{_prod}] Could not find a {_prod} workspace in this directory or any parent.\n"
        "\nOptions:\n"
        "  1. Run this command from your workspace root (where .adm/ lives).\n"
        "  2. Use @PRJ to reference a registered project: adm status --project @ADM\n"
        "  3. Scaffold a new workspace:\n"
        "       adm init --project MYPROJECT\n"
        "\nSee: https://github.com/tavisbasing/Maestro\n"
    )


def _run(script: str, extra_args: list[str], workspace: Path) -> None:
    """Run a Maestro core script via the current Python interpreter.

    Resolution order:
      1. admiralty/core/<script> within the workspace (dev/submodule installs)
      2. The pip package's admiralty/core/<script> (standard pip installs)
      3. Legacy .admiralty/core/<script> (v1.x fallback)
    """
    # 1. Workspace-local (dev mode / submodule)
    local = workspace / "admiralty" / "core" / script
    if local.exists():
        script_path = local
    else:
        # 2. Pip-installed package
        try:
            import importlib.resources as pkg_resources
            ref = pkg_resources.files("admiralty") / "core" / script
            # Materialise to a real path if possible
            import contextlib
            with contextlib.suppress(Exception):
                script_path = Path(str(ref))
                if not script_path.exists():
                    raise FileNotFoundError
        except Exception:
            # 3. Legacy .admiralty/core/ fallback
            script_path = workspace / ".admiralty" / "core" / script

    if not script_path.exists():
        raise SystemExit(
            f"\n[Admiralty] Script not found: {script}\n"
            "Ensure the admiralty pip package is installed:\n"
            "  pip install admiralty --extra-index-url https://tavisbasing.github.io/admiralty-dist/simple/\n"
        )
    result = subprocess.run(
        [sys.executable, str(script_path)] + extra_args,
        cwd=workspace,
    )
    sys.exit(result.returncode)


def _resolve_script_path(script: str, workspace: Path) -> Path:
    """Resolve a Maestro core script path (same resolution order as _run)."""
    local = workspace / "admiralty" / "core" / script
    if local.exists():
        return local
    try:
        import importlib.resources as pkg_resources
        import contextlib
        ref = pkg_resources.files("admiralty") / "core" / script
        with contextlib.suppress(Exception):
            p = Path(str(ref))
            if p.exists():
                return p
    except Exception:
        pass
    return workspace / ".admiralty" / "core" / script


def _run_detached(script: str, extra_args: list[str], workspace: Path) -> None:
    """Launch a Maestro script as a fully detached background process.

    The process is independent of this CLI session — it survives after `adm dispatch`
    returns. Used for the dispatcher so it keeps running even when called from a
    non-interactive session (IDE terminal, CI, Claude Code bash tool).

    On Windows uses DETACHED_PROCESS + CREATE_NEW_PROCESS_GROUP.
    On POSIX uses start_new_session=True.
    """
    import os

    script_path = _resolve_script_path(script, workspace)
    if not script_path.exists():
        raise SystemExit(
            f"\n[Admiralty] Script not found: {script}\n"
            "Ensure the admiralty pip package is installed:\n"
            "  pip install admiralty --extra-index-url https://tavisbasing.github.io/admiralty-dist/simple/\n"
        )

    cmd = [sys.executable, str(script_path)] + extra_args

    if os.name == "nt":
        DETACHED_PROCESS = 0x00000008
        CREATE_NEW_PROCESS_GROUP = 0x00000200
        proc = _spawn(
            cmd,
            identity="cli_dispatch",
            workspace=workspace,
            cwd=str(workspace),
            creationflags=DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP,
            close_fds=True,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    else:
        proc = _spawn(
            cmd,
            identity="cli_dispatch",
            workspace=workspace,
            cwd=str(workspace),
            start_new_session=True,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

    print(f"\n  [Admiralty] Dispatcher launched (PID {proc.pid}) — running in background.")
    print(f"  Monitor with: adm status\n")


# ---------------------------------------------------------------------------
# Command implementations
# ---------------------------------------------------------------------------

def cmd_dispatch(args: argparse.Namespace) -> None:
    """Launch fleet crews from the dispatch queue."""
    ws = find_workspace(getattr(args, "project", None))
    from maestro.identity.gate import require_capability
    require_capability("fleet.dispatch", workspace=ws)
    admiralty_dir = ws / ".adm" if (ws / ".adm").is_dir() else ws / ".admiralty"
    extra: list[str] = ["--admiralty-dir", str(admiralty_dir)]
    if args.cleanup:
        extra.append("--cleanup")
    extra += ["--dispatch", "--max-crews", str(args.max_crews)]
    if args.stagger_delay != 30:
        extra += ["--stagger-delay", str(args.stagger_delay)]
    if args.timeout != 90:
        extra += ["--timeout", str(args.timeout)]
    from maestro.audit import get_audit_log
    get_audit_log(ws).append(
        "fleet.dispatch",
        target=str(args.project or ws.name),
        metadata={"max_crews": args.max_crews},
    )
    # Launch dispatcher as a detached background process so it survives after
    # this CLI call returns (critical for IDE terminals, Claude Code, and CI).
    _run_detached("fleet_runner.py", extra, ws)


def cmd_cleanup(args: argparse.Namespace) -> None:
    """Clean up rogue processes and stale crew state."""
    ws = find_workspace(getattr(args, "project", None))
    admiralty_dir = ws / ".adm" if (ws / ".adm").is_dir() else ws / ".admiralty"
    from maestro import backup as _backup
    path = _backup.backup(workspace=ws)
    print(f"[Admiralty] Auto-backup created: {path}")
    _run("fleet_runner.py", ["--admiralty-dir", str(admiralty_dir), "--cleanup"], ws)


def cmd_backup(args: argparse.Namespace) -> None:
    """Create a backup of project state, or list existing backups."""
    ws = find_workspace(getattr(args, "project", None))
    from maestro import backup as _backup
    from maestro.identity.gate import require_capability
    if not args.list:
        require_capability("backup.create", workspace=ws)
    if args.list:
        backup_dir = Path(args.output) if args.output else ws / "admiralty-backups"
        entries = _backup.list_backups(backup_dir)
        if not entries:
            print(f"[Admiralty] No backups found in {backup_dir}")
            return
        for e in entries:
            if "error" in e:
                print(f"  {e['file'].name}  [unreadable: {e['error']}]")
            else:
                print(
                    f"  {e['file'].name}  |  {e['created_at']}  |  "
                    f"{e['file_count']} files  |  v{e['admiralty_version']}"
                )
        return
    path = _backup.backup(
        workspace=ws,
        project=args.project,
        output_dir=Path(args.output) if args.output else None,
    )
    print(f"[Admiralty] Backup created: {path}")


def cmd_restore(args: argparse.Namespace) -> None:
    """Restore project state from a backup ZIP."""
    ws = find_workspace(getattr(args, "project", None))
    from maestro import backup as _backup
    from maestro.identity.gate import require_capability
    require_capability("backup.restore", workspace=ws)
    _backup.restore(
        backup_file=Path(args.backup_file),
        workspace=ws,
        project=args.project,
        force=args.force,
        merge=args.merge,
        dry_run=args.dry_run,
    )


def cmd_status(args: argparse.Namespace) -> None:
    """Display fleet status dashboard."""
    ws = find_workspace(getattr(args, "project", None))
    extra = ["--once"] if args.once else []
    if args.compact:
        extra.append("--compact")
    _run("fleet_monitor.py", extra, ws)


def cmd_usage(args: argparse.Namespace) -> None:
    """Report token usage and estimated cost."""
    ws = find_workspace(getattr(args, "project", None))
    extra: list[str] = []
    if args.voyage:
        extra += ["--voyage", args.voyage]
    elif args.order:
        extra += ["--order", args.order]
    elif args.report:
        extra.append("--report")
        if args.output:
            extra += ["--output", args.output]
    else:
        extra.append("--summary")
    _run("fleet_usage_tracker.py", extra, ws)


def cmd_crew(args: argparse.Namespace) -> None:
    """Operate an individual crew instance."""
    if getattr(args, "_noun_deprecated", None):
        print(
            f"WARN: '{args._noun_deprecated}' is a deprecated alias for 'squad' — "
            "use `mso squad` instead (removed in v4.0)"
        )
    ws = find_workspace(getattr(args, "project", None))
    extra = ["--crew", str(args.crew)]
    if args.status:
        extra.append("--status")
    if args.watch:
        extra.append("--watch")
    if args.cleanup:
        extra.append("--cleanup")
    _run("crew.py", extra, ws)


def cmd_verify(args: argparse.Namespace) -> None:
    """Run post-voyage build and test verification."""
    ws = find_workspace(getattr(args, "project", None))
    extra: list[str] = []
    if args.voyage:
        extra += ["--voyage", args.voyage]
    if args.skip_tests:
        extra.append("--skip-tests")
    _run("post_voyage_verify.py", extra, ws)


def cmd_bridge(args: argparse.Namespace) -> None:
    """Manage the Mobile Command Bridge."""
    ws = find_workspace()
    from maestro import bridge as _bridge
    from maestro.identity.gate import require_capability
    from maestro.audit import get_audit_log

    action = args.bridge_action
    _audit = get_audit_log(ws)

    if action == "start":
        require_capability("bridge.start", workspace=ws)
        _bridge.start_poller(ws)
        _bridge.start_bot(ws)
        _audit.append("bridge.command", target="bridge", metadata={"action": "start"})
    elif action == "stop":
        require_capability("bridge.stop", workspace=ws)
        _bridge.stop_poller(ws)
        _bridge.stop_bot(ws)
        _audit.append("bridge.command", target="bridge", metadata={"action": "stop"})
    elif action == "status":
        _bridge.print_status(ws)
    elif action == "test":
        if not args.project:
            raise SystemExit("[Bridge] --project required for test (e.g. admiralty bridge test --project ADM)")
        _bridge.send_test(ws, args.project)
    elif action == "poller-start":
        _bridge.start_poller(ws)
        _audit.append("bridge.command", target="bridge", metadata={"action": "poller-start"})
    elif action == "poller-stop":
        _bridge.stop_poller(ws)
        _audit.append("bridge.command", target="bridge", metadata={"action": "poller-stop"})
    elif action == "bot-start":
        _bridge.start_bot(ws)
        _audit.append("bridge.command", target="bridge", metadata={"action": "bot-start"})
    elif action == "bot-stop":
        _bridge.stop_bot(ws)
        _audit.append("bridge.command", target="bridge", metadata={"action": "bot-stop"})
    elif action == "restart":
        require_capability("bridge.start", workspace=ws)
        require_capability("bridge.stop", workspace=ws)
        _bridge.restart(ws)
        _audit.append("bridge.command", target="bridge", metadata={"action": "restart"})
    elif action == "setup":
        require_capability("bridge.start", workspace=ws)
        _bridge.setup_wizard(ws)
        _audit.append("bridge.command", target="bridge", metadata={"action": "setup"})


def cmd_voyage(args: argparse.Namespace) -> None:
    """Manage sprints / voyages."""
    if getattr(args, "_noun_deprecated", None):
        print(
            f"WARN: '{args._noun_deprecated}' is a deprecated alias for 'sprint' — "
            "use `mso sprint` instead (removed in v4.0)"
        )
    ws = find_workspace(getattr(args, "project", None))
    admiralty_dir = ws / ".adm" if (ws / ".adm").is_dir() else ws / ".admiralty"
    now = datetime.now(timezone.utc)
    year = now.strftime("%Y")

    if args.voyage_action == "create":
        from maestro.identity.gate import require_capability as _rq
        _rq("voyage.create", workspace=ws)
        if not args.project:
            raise SystemExit("[Voyage] --project required for 'voyage create'")
        title = " ".join(args.title)
        if not title:
            raise SystemExit("[Voyage] <title> required for 'voyage create'")

        voyages_dir = admiralty_dir / "voyages" / "active"
        voyages_dir.mkdir(parents=True, exist_ok=True)
        existing = list(voyages_dir.glob(f"VOY-{args.project}-{year}-*.json"))
        seq = len(existing) + 1
        voyage_id = f"VOY-{args.project}-{year}-{seq:04d}"
        branch = f"voyage/{voyage_id}"

        voyage = {
            "id": voyage_id,
            "title": title,
            "status": "PLANNED",
            "priority": "MEDIUM",
            "branch": branch,
            "project": args.project,
            "orders": [],
            "createdBy": "cli",
            "createdAt": now.isoformat(),
        }
        voyage_path = voyages_dir / f"{voyage_id}.json"
        voyage_path.write_text(json.dumps(voyage, indent=2), encoding="utf-8")

        # Create git branch
        result = subprocess.run(
            ["git", "checkout", "-b", branch],
            cwd=ws,
            capture_output=True,
            text=True,
        )
        if result.returncode == 0:
            print(f"[Voyage] Created {voyage_id} — branch: {branch}")
        else:
            print(f"[Voyage] Created {voyage_id} (branch already exists or git error: {result.stderr.strip()})")

    elif args.voyage_action == "list":
        voyages_dir = admiralty_dir / "voyages" / "active"
        if not voyages_dir.exists():
            print("[Voyage] No active voyages found")
            return
        entries = sorted(voyages_dir.glob("*.json"))
        if not entries:
            print("[Voyage] No active voyages found")
            return
        for f in entries:
            try:
                v = json.loads(f.read_text(encoding="utf-8"))
                if args.project and v.get("project") != args.project:
                    continue
                order_count = len(v.get("orders", []))
                print(f"  {v['id']}  |  {v.get('status', '?'):8s}  |  {order_count} orders  |  {v.get('title', '')}")
            except Exception:
                continue

    elif args.voyage_action == "status":
        voyage_id = args.voyage_id
        voyages_dir = admiralty_dir / "voyages" / "active"
        voyage_path = voyages_dir / f"{voyage_id}.json"
        if not voyage_path.exists():
            raise SystemExit(f"[Voyage] Not found: {voyage_id}")
        v = json.loads(voyage_path.read_text(encoding="utf-8"))
        print(f"\n  VOYAGE: {v['id']}")
        print(f"  Title:   {v.get('title', '')}")
        print(f"  Status:  {v.get('status', '')}")
        print(f"  Branch:  {v.get('branch', '')}")
        print(f"  Project: {v.get('project', '')}")
        orders = v.get("orders", [])
        if orders:
            print(f"  Orders ({len(orders)}):")
            for o in orders:
                print(f"    - {o.get('orderId', '?')}: {o.get('title', '')}")
        print()


def cmd_bug(args: argparse.Namespace) -> None:
    """Create a BUG order."""
    ws = find_workspace(getattr(args, "project", None))
    admiralty_dir = ws / ".adm" if (ws / ".adm").is_dir() else ws / ".admiralty"
    if not args.project:
        raise SystemExit("[Bug] --project required (e.g. admiralty bug 'Title' --project ADM)")
    title = " ".join(args.title)
    if not title:
        raise SystemExit("[Bug] <title> required")

    now = datetime.now(timezone.utc)
    year = now.strftime("%Y")
    orders_dir = admiralty_dir / "queues" / "orders"
    orders_dir.mkdir(parents=True, exist_ok=True)

    existing = list(orders_dir.glob(f"BUG-{args.project}-{year}-*.json"))
    seq = len(existing) + 1
    bug_id = f"BUG-{args.project}-{year}-{seq:04d}"

    order = {
        "orderId": bug_id,
        "type": "BUG",
        "project": args.project,
        "title": title,
        "priority": "HIGH",
        "status": "PENDING",
        "targetRole": "SHP",
        "roleSequence": ["SHP", "BOS"],
        "acceptanceCriteria": [],
        "acResults": [],
        "createdBy": "cli",
        "createdAt": now.isoformat(),
    }
    order_path = orders_dir / f"{bug_id}.json"
    order_path.write_text(json.dumps(order, indent=2), encoding="utf-8")
    print(f"[Bug] Created {bug_id}: {title}")


def cmd_security(args: argparse.Namespace) -> None:
    """Run the OWASP/CWE security scanner manually."""
    import glob as _glob

    ws = find_workspace(getattr(args, "project", None))
    adm_root = ws / ".adm" if (ws / ".adm").is_dir() else ws / ".admiralty"
    reports_dir = adm_root / "reports" / "security"

    try:
        from maestro.security.owasp_patterns import OWASPScanner, Severity
    except ImportError:
        raise SystemExit(
            "[Security] OWASP scanner not found. Ensure admiralty is installed:\n"
            "  pip install admiralty --extra-index-url https://tavisbasing.github.io/admiralty-dist/simple/"
        )

    # Resolve files to scan
    files_to_scan: list[Path] = []

    if args.order:
        # Scan files recorded as modified for this order
        crew_dirs = list((adm_root / "crews").glob("crew*")) if (adm_root / "crews").exists() else []
        for cd in crew_dirs:
            fmod = cd / "files_modified.json"
            if fmod.exists():
                try:
                    paths = json.loads(fmod.read_text(encoding="utf-8"))
                    files_to_scan.extend(Path(p) for p in paths)
                except Exception:
                    pass
    elif args.voyage:
        # Scan based on voyage's orders' modified files
        voyage_files = list((adm_root / "voyages").rglob(f"{args.voyage}.json"))
        order_ids: set[str] = set()
        for vf in voyage_files:
            try:
                vdata = json.loads(vf.read_text(encoding="utf-8"))
                for order in vdata.get("orders", []):
                    order_id = order.get("orderId") or order.get("id")
                    if order_id:
                        order_ids.add(order_id)
            except Exception:
                pass
        # Fall back to scanning all modified files tracked in crews
        crew_dirs = list((adm_root / "crews").glob("crew*")) if (adm_root / "crews").exists() else []
        for cd in crew_dirs:
            fmod = cd / "files_modified.json"
            if fmod.exists():
                try:
                    paths = json.loads(fmod.read_text(encoding="utf-8"))
                    files_to_scan.extend(Path(p) for p in paths)
                except Exception:
                    pass
    elif args.since:
        # Find .py files modified since date
        from datetime import datetime as _dt
        try:
            since_ts = _dt.fromisoformat(args.since).timestamp()
        except ValueError:
            raise SystemExit(f"[Security] Invalid --since date: {args.since}. Use ISO format: YYYY-MM-DD")
        for py_file in ws.rglob("*.py"):
            try:
                if py_file.stat().st_mtime >= since_ts:
                    files_to_scan.append(py_file)
            except Exception:
                pass
    else:
        # Default: scan entire workspace Python files
        files_to_scan = list(ws.rglob("*.py"))

    # Deduplicate and filter to existing .py files
    seen: set[str] = set()
    unique_files: list[str] = []
    for f in files_to_scan:
        p = Path(f)
        if not p.suffix == ".py":
            continue
        key = str(p.resolve())
        if key in seen:
            continue
        seen.add(key)
        if p.exists():
            unique_files.append(str(p))

    if not unique_files:
        print("[Security] No Python files found to scan.")
        return

    print(f"[Security] Scanning {len(unique_files)} file(s)...")
    scanner = OWASPScanner(language="python")
    all_findings = scanner.scan_files(unique_files)

    # Apply severity threshold filter
    severity_order = ["INFO", "LOW", "MEDIUM", "HIGH", "CRITICAL"]
    threshold = (args.severity_threshold or "INFO").upper()
    if threshold not in severity_order:
        raise SystemExit(f"[Security] Invalid --severity-threshold: {threshold}")
    min_idx = severity_order.index(threshold)
    filtered = [f for f in all_findings if severity_order.index(f.severity.value) >= min_idx]

    if args.json:
        summary = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0, "INFO": 0}
        for f in filtered:
            summary[f.severity.value] = summary.get(f.severity.value, 0) + 1
        output = {
            "scannedFiles": len(unique_files),
            "totalFindings": len(filtered),
            "summary": summary,
            "findings": [f.to_dict() for f in filtered],
        }
        print(json.dumps(output, indent=2))
        return

    # Human-readable output
    if not filtered:
        print("[Security] No findings above threshold.")
        return

    summary: dict[str, int] = {}
    for f in filtered:
        summary[f.severity.value] = summary.get(f.severity.value, 0) + 1

    print(f"\n  Findings: {len(filtered)}")
    for sev in ("CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"):
        if summary.get(sev):
            print(f"    {sev}: {summary[sev]}")

    print()
    for i, f in enumerate(filtered, 1):
        print(f"  {i}. [{f.severity.value}] {f.title}")
        print(f"     CWE: {f.cwe}  File: {f.file}:{f.line}")
        print(f"     Snippet: {f.snippet[:80]}")
        print(f"     Fix: {f.remediation}")
        print()

    # Optionally write report to .adm/reports/security/
    if args.order:
        reports_dir.mkdir(parents=True, exist_ok=True)
        from maestro.hooks.posttool import _write_md_report
        report_data = {
            "orderId": args.order,
            "generatedAt": datetime.now(timezone.utc).isoformat(),
            "findings": [f.to_dict() for f in filtered],
            "summary": summary,
        }
        json_path = reports_dir / f"SEC-{args.order}.json"
        json_path.write_text(json.dumps(report_data, indent=2), encoding="utf-8")
        md_path = reports_dir / f"SEC-{args.order}.md"
        _write_md_report(md_path, report_data)
        print(f"  Report written: {json_path}")
        print(f"  Report written: {md_path}")


def cmd_projects(args: argparse.Namespace) -> None:
    """List or manage registered projects in the global registry."""
    from maestro.registry import list_projects, unregister_project

    action = args.projects_action

    if action == "list":
        projects = list_projects()
        if not projects:
            print("[Admiralty] No projects registered. Run 'adm init --project ACRONYM' to register one.")
            return
        print(f"{'ACRONYM':<12}  {'PATH':<60}  REGISTERED")
        print("-" * 90)
        for acronym, entry in sorted(projects.items()):
            path = entry.get("path", "?")
            registered = entry.get("registered", "?")[:19].replace("T", " ")
            print(f"{acronym:<12}  {path:<60}  {registered}")

    elif action == "remove":
        acronym = args.acronym.upper()
        if unregister_project(acronym):
            print(f"[Admiralty] Removed '{acronym}' from global registry.")
        else:
            print(f"[Admiralty] Project '{acronym}' not found in registry.")


def cmd_init(args: argparse.Namespace) -> None:
    """Scaffold a new Admiralty workspace. (Auth check bypassed — see auth.py.)"""
    from maestro.init import scaffold_workspace
    scaffold_workspace(
        project=args.project,
        directory=Path(args.directory) if args.directory else Path.cwd(),
        force=args.force,
        enterprise=getattr(args, "enterprise", False),
    )


def cmd_quickstart(args: argparse.Namespace) -> None:
    """Run the guided first-run experience."""
    from maestro.quickstart import run_quickstart
    run_quickstart(args)


def cmd_setup(args: argparse.Namespace) -> None:
    """Prerequisite validation and interactive setup wizard."""
    from maestro.setup import (
        run_all_checks,
        format_check_report,
        check_mode_exit_code,
        interactive_setup,
    )

    check = getattr(args, "check", False)
    repair = getattr(args, "repair", False)
    show = getattr(args, "show", None)

    if show:
        # BUG fixed via Copilot review on PR #67: previously each section just
        # printed a static hint string ("Run `adm setup --check` to see ...").
        # Now `--show <section>` returns the actual data for that section.
        valid = {"prereqs", "project", "workspace", "templates", "persona"}
        if show not in valid:
            print(f"Unknown section '{show}'. Valid sections: {', '.join(sorted(valid))}")
            sys.exit(2)

        if show == "prereqs":
            results = run_all_checks()
            print(format_check_report(results, verbose=True))
            return

        if show == "project":
            try:
                from maestro.project_analysis import analyse_project
                analysis = analyse_project(Path.cwd())
                print(f"  Language    : {analysis.primary_language}")
                if analysis.secondary_languages:
                    print(f"  Also uses   : {', '.join(analysis.secondary_languages)}")
                print(f"  Framework   : {analysis.framework}")
                print(f"  Source root : {analysis.source_root}")
                print(f"  Test layout : {', '.join(analysis.test_layouts) or 'none detected'}")
                print(f"  README      : {'yes' if analysis.has_readme else 'no'}")
                print(f"  docs/       : {'yes' if analysis.has_docs_dir else 'no'}")
                print(f"  CI          : {', '.join(analysis.ci_systems) if analysis.ci_systems else 'none detected'}")
                print(f"  Activity    : {analysis.recent_activity}")
                print(f"  Branches    : {analysis.branch_model}")
            except Exception as exc:
                print(f"  ⚠ Project analysis failed: {exc}")
            return

        if show == "workspace":
            import json as _json
            from maestro.setup import _find_adm_dir
            adm_dir = _find_adm_dir()
            if adm_dir is None:
                print("  No .adm/ workspace found in current directory or any parent.")
                print("  Run `adm init --project <PRJ>` to scaffold one.")
                return
            ws_path = adm_dir / "config" / "workspace.json"
            print(f"  Workspace root : {adm_dir.parent}")
            print(f"  Config dir     : {adm_dir / 'config'}")
            if ws_path.exists():
                try:
                    ws = _json.loads(ws_path.read_text(encoding="utf-8"))
                    print(f"  workspace.json : {ws_path}")
                    for key, val in ws.items():
                        print(f"    {key}: {val}")
                except Exception as exc:
                    print(f"  ⚠ workspace.json present but unreadable: {exc}")
            else:
                print(f"  workspace.json : MISSING — run `adm init --project <PRJ>`")
            return

        if show == "templates":
            from maestro.templates_loader import (
                list_builtin_templates,
                list_custom_templates,
            )
            from maestro.setup import _find_adm_dir
            adm_dir = _find_adm_dir()
            builtins = list_builtin_templates()
            print("  Built-in templates:")
            for name in builtins:
                print(f"    • {name}")
            if adm_dir is not None:
                custom = list_custom_templates(adm_dir)
                if custom:
                    print("  Custom templates:")
                    for name in custom:
                        marker = " (overrides built-in)" if name in builtins else ""
                        print(f"    • {name}{marker}")
                else:
                    print("  Custom templates: (none)")
            else:
                print("  Custom templates: (no .adm/ workspace found)")
            return

        if show == "persona":
            from maestro.personas import current_persona, reset_persona_cache
            from maestro.personas.resolver import _find_workspace_config
            import os
            reset_persona_cache()
            p = current_persona()
            env_id = os.environ.get("MAESTRO_PERSONA", "").strip()
            if env_id:
                source = f"MAESTRO_PERSONA env var ('{env_id}')"
            else:
                ws_path = _find_workspace_config()
                if ws_path:
                    source = f"workspace config ({ws_path})"
                else:
                    from pathlib import Path as _Path
                    user_path = _Path.home() / ".maestro" / "config" / "persona.json"
                    if user_path.exists():
                        source = f"user-global config ({user_path})"
                    else:
                        source = "built-in default"
            print(f"  Persona  : {p.id}")
            print(f"  Title    : {p.vocabulary.get('userTitle', p.id)}")
            print(f"  Source   : {source}")
            return

    if check:
        results = run_all_checks()
        if getattr(args, "json", False):
            import json as _json
            payload = {
                "prereqs": [
                    {"name": r.name, "status": r.status, "message": r.message,
                     "remediation": r.remediation}
                    for r in results
                ],
                "exit_code": check_mode_exit_code(results),
            }
            print(_json.dumps(payload, indent=2))
        else:
            print(format_check_report(results, verbose=True))
        sys.exit(check_mode_exit_code(results))

    if repair:
        from maestro.setup import PrereqCheck
        results = run_all_checks()
        print(format_check_report(results, verbose=True))
        repaired = 0
        for r in results:
            if r.status in ("FAIL", "WARN") and r.repair_fn:
                print(f"\n  Repairing '{r.name}'...")
                try:
                    r.repair_fn()
                    repaired += 1
                    print(f"  ✓ Done")
                except Exception as exc:
                    print(f"  ✗ Failed: {exc}")
        if repaired:
            print(f"\n  {repaired} repair(s) attempted. Re-run `adm setup --check` to verify.")
        else:
            print("\n  Nothing to repair.")
        return

    interactive_setup()


def cmd_update(args: argparse.Namespace) -> None:
    """Propagate Admiralty schema updates to an existing workspace."""
    from maestro.update import update_workspace
    update_workspace(
        workspace=Path(args.directory) if args.directory else Path.cwd(),
        dry_run=args.dry_run,
        force=args.force,
    )


def cmd_hooks(args: argparse.Namespace) -> None:
    """Install or uninstall global Admiralty hooks in ~/.claude/settings.json."""
    import copy

    settings_path = Path.home() / ".claude" / "settings.json"

    # The hook entries Admiralty manages (keyed by a sentinel command for idempotency)
    MAESTRO_HOOKS: dict = {
        "PreToolUse": [
            {
                "matcher": "Edit|MultiEdit|Write",
                "hooks": [
                    {
                        "type": "command",
                        "command": "python -m admiralty.hooks.pretool",
                        "timeout": 10,
                    }
                ],
            },
            {
                "matcher": "AskUserQuestion",
                "hooks": [
                    {
                        "type": "command",
                        "command": "python -m admiralty.hooks.bridge_question",
                        "timeout": 10,
                    }
                ],
            },
        ],
        "PostToolUse": [
            {
                "matcher": "Edit|MultiEdit|Write|Bash|Read|Glob|Grep|Task",
                "hooks": [
                    {
                        "type": "command",
                        "command": "python -m admiralty.hooks.posttool",
                        "timeout": 10,
                    }
                ],
            }
        ],
        "Stop": [
            {
                "matcher": "",
                "hooks": [
                    {
                        "type": "command",
                        "command": "python -m admiralty.hooks.stop",
                        "timeout": 30,
                    }
                ],
            }
        ],
        "Notification": [
            {
                "matcher": "",
                "hooks": [
                    {
                        "type": "command",
                        "command": "python -m admiralty.hooks.notification",
                        "timeout": 10,
                    }
                ],
            }
        ],
    }

    # Collect all admiralty module commands for lookup
    def _admiralty_commands() -> set:
        cmds: set = set()
        for entries in MAESTRO_HOOKS.values():
            for entry in entries:
                for h in entry.get("hooks", []):
                    cmds.add(h.get("command", ""))
        return cmds

    def _entry_key(entry: dict) -> str:
        """Stable identity key for a hook group entry (matcher + first command)."""
        hooks = entry.get("hooks", [])
        first_cmd = hooks[0].get("command", "") if hooks else ""
        return f"{entry.get('matcher', '')}|{first_cmd}"

    # Load existing settings
    settings: dict = {}
    if settings_path.exists():
        try:
            settings = json.loads(settings_path.read_text(encoding="utf-8"))
        except Exception:
            settings = {}

    if args.hooks_action == "install":
        merged = copy.deepcopy(settings)
        merged.setdefault("hooks", {})
        admiralty_cmds = _admiralty_commands()

        for event, new_entries in MAESTRO_HOOKS.items():
            existing_entries: list = merged["hooks"].setdefault(event, [])
            existing_keys = {_entry_key(e) for e in existing_entries}

            for new_entry in new_entries:
                key = _entry_key(new_entry)
                if key not in existing_keys:
                    existing_entries.append(copy.deepcopy(new_entry))

        settings_path.parent.mkdir(parents=True, exist_ok=True)
        settings_path.write_text(json.dumps(merged, indent=2), encoding="utf-8")
        print(f"[Admiralty] Hooks installed in {settings_path}")
        print("  Restart Claude Code to activate.")

    elif args.hooks_action == "uninstall":
        if not settings_path.exists():
            print("[Admiralty] No ~/.claude/settings.json found — nothing to uninstall.")
            return

        admiralty_cmds = _admiralty_commands()
        modified = copy.deepcopy(settings)
        hooks_section: dict = modified.get("hooks", {})

        for event in list(hooks_section.keys()):
            kept = []
            for entry in hooks_section[event]:
                entry_cmds = {h.get("command", "") for h in entry.get("hooks", [])}
                if entry_cmds & admiralty_cmds:
                    continue  # Drop this entry
                kept.append(entry)
            if kept:
                hooks_section[event] = kept
            else:
                del hooks_section[event]

        settings_path.write_text(json.dumps(modified, indent=2), encoding="utf-8")
        print(f"[Admiralty] Hooks removed from {settings_path}")


def cmd_mcp(args: argparse.Namespace) -> None:
    """Manage the MCP server registry."""
    import os
    from maestro.mcp import (
        load_registry, validate_registry, get_active_mcp_servers,
        add_server, remove_server, get_server,
        McpSchemaError, McpMissingServerError, McpRegistryError,
    )

    ws = find_workspace(getattr(args, "project", None))
    action = args.mcp_action

    if action == "list":
        registry = load_registry(ws)
        if registry is None:
            print("[MCP] No registry found at .adm/config/mcp-servers.json")
            print("      Run 'adm mcp add' to add a server, or 'adm init' to scaffold one.")
            return
        servers = registry.get("servers", [])
        if not servers:
            print("[MCP] Registry is empty — no servers registered.")
            return
        fmt = f"{'NAME':<20}  {'RISK':<10}  {'ALLOWED ROLES':<30}  ENV REQUIRED"
        print(fmt)
        print("-" * 85)
        for s in servers:
            name = s.get("name", "?")
            risk = s.get("risk_level", "medium")
            ar = s.get("allowed_roles", [])
            roles_str = "*" if ar == "*" else ", ".join(ar)
            envs = s.get("env_required", [])
            env_str = ", ".join(envs) if envs else "—"
            print(f"{name:<20}  {risk:<10}  {roles_str:<30}  {env_str}")

    elif action == "show":
        registry = load_registry(ws)
        if registry is None:
            raise SystemExit("[MCP] No registry found at .adm/config/mcp-servers.json")
        entry = get_server(registry, args.name)
        if entry is None:
            raise SystemExit(f"[MCP] Server '{args.name}' not found in registry")
        print(json.dumps(entry, indent=2))

    elif action == "add":
        if args.json:
            import pathlib
            raw = pathlib.Path(args.json).read_text(encoding="utf-8")
            entry = json.loads(raw)
        else:
            if not args.name:
                raise SystemExit("[MCP] --name is required")
            if not args.command:
                raise SystemExit("[MCP] --command is required")
            if not args.allowed_roles:
                raise SystemExit("[MCP] --allowed-roles is required")
            ar_raw = args.allowed_roles
            if ar_raw == "*":
                allowed_roles: str | list = "*"
            else:
                # Strip and drop empty items so "BOS," doesn't yield ['BOS', '']
                # which then fails schema validation with a confusing
                # "unknown role ''" error.
                allowed_roles = [r.strip() for r in ar_raw.split(",") if r.strip()]
            entry = {
                "name": args.name,
                "command": args.command,
                "allowed_roles": allowed_roles,
            }
            if args.args:
                entry["args"] = args.args
            if args.risk_level:
                entry["risk_level"] = args.risk_level
            if args.env_required:
                entry["env_required"] = args.env_required
            if args.description:
                entry["description"] = args.description
            if args.notes:
                entry["notes"] = args.notes

        try:
            add_server(ws, entry)
            print(f"[MCP] Added server '{entry['name']}' to registry.")
        except (McpSchemaError, McpRegistryError) as e:
            raise SystemExit(f"[MCP] Error: {e}")

    elif action == "remove":
        active = get_active_mcp_servers(ws)
        if args.name in active:
            print(
                f"[MCP] WARNING: '{args.name}' is still present in .claude/settings.json mcpServers. "
                "Remove it manually — Admiralty does not modify .claude/settings.json."
            )
        try:
            remove_server(ws, args.name)
            print(f"[MCP] Removed server '{args.name}' from registry.")
        except McpMissingServerError as e:
            raise SystemExit(f"[MCP] {e}")

    elif action == "validate":
        registry = load_registry(ws)
        if registry is None:
            print("[MCP] WARNING: No registry at .adm/config/mcp-servers.json — permissive mode.")
            print("      Run 'adm mcp add' or 'adm init' to create one.")
            sys.exit(0)

        errors: list[str] = []

        # Schema validation
        try:
            validate_registry(registry)
        except McpSchemaError as e:
            errors.append(f"Schema error: {e}")

        # Env var checks
        if not errors:
            for s in registry.get("servers", []):
                for env_var in s.get("env_required", []):
                    if env_var not in os.environ:
                        errors.append(
                            f"Server '{s['name']}' requires env var '{env_var}' (not set)"
                        )

        # Informational: active servers not in registry
        active = get_active_mcp_servers(ws)
        reg_names = {s.get("name") for s in registry.get("servers", [])}
        unregistered = [n for n in active if n not in reg_names]
        if unregistered:
            print("[MCP] INFO: Active servers not in registry (will be blocked at dispatch):")
            for n in unregistered:
                print(f"  - {n}")

        if errors:
            print("[MCP] Validation FAILED:")
            for e in errors:
                print(f"  ✗ {e}")
            sys.exit(1)
        else:
            print("[MCP] Registry is valid.")
            sys.exit(0)


def cmd_identity(args: argparse.Namespace) -> None:
    """Manage enterprise identity, groups, and ACL."""
    ws = find_workspace(getattr(args, "project", None))
    identity_dir = ws / ".adm" / "identity"
    users_dir = identity_dir / "users"
    groups_dir = identity_dir / "groups"
    acl_path = identity_dir / "access.json"

    from maestro.identity.gate import require_capability
    from maestro.identity import (
        UserRecord, GroupRecord, AclEntry,
        load_user, load_acl, load_group,
        save_user, save_group, save_acl,
        list_users, list_groups,
        resolve_caller, effective_capabilities,
    )

    action = args.identity_action

    if action == "init":
        require_capability("identity.write", workspace=ws)
        _identity_init(identity_dir, users_dir, groups_dir, acl_path)
        encryption = getattr(args, "encryption", None)
        if encryption and encryption != "none":
            from maestro.identity.encryption import encryption_init_wizard
            encryption_init_wizard(ws, identity_dir, encryption)

    elif action == "rights":
        _identity_rights(args, ws, identity_dir)

    elif action == "add-user":
        require_capability("identity.write", workspace=ws)
        from datetime import datetime, timezone
        email = args.email
        display_name = args.display_name
        groups = args.group or []
        public_key: str | None = None
        if args.public_key:
            pk_path = Path(args.public_key)
            if not pk_path.exists():
                raise SystemExit(f"[Identity] Public key file not found: {pk_path}")
            public_key = pk_path.read_text(encoding="utf-8").strip()

        existing = load_user(users_dir, email)
        if existing:
            raise SystemExit(f"[Identity] User already exists: {email}. Use set-group to modify.")

        record = UserRecord(
            email=email,
            display_name=display_name,
            groups=list(groups),
            public_key=public_key,
            enrolled_at=datetime.now(timezone.utc).isoformat(),
        )
        save_user(users_dir, record)

        # Add user to requested groups
        for grp_name in groups:
            grp = load_group(groups_dir, grp_name)
            if grp is None:
                grp = GroupRecord(name=grp_name, members=[])
            if email not in grp.members:
                grp.members.append(email)
            save_group(groups_dir, grp)

        print(f"[Identity] Added user: {email} (groups: {', '.join(groups) or 'none'})")

    elif action == "add-group":
        require_capability("identity.write", workspace=ws)
        name = args.name
        if load_group(groups_dir, name):
            raise SystemExit(f"[Identity] Group already exists: {name}")
        record = GroupRecord(name=name, members=[])
        save_group(groups_dir, record)
        print(f"[Identity] Added group: {name}")

    elif action == "set-group":
        require_capability("identity.write", workspace=ws)
        email = args.email
        grp_name = args.group
        user = load_user(users_dir, email)
        if user is None:
            raise SystemExit(f"[Identity] User not found: {email}")
        grp = load_group(groups_dir, grp_name)
        if grp is None:
            grp = GroupRecord(name=grp_name, members=[])
        if email not in grp.members:
            grp.members.append(email)
        if grp_name not in user.groups:
            user.groups.append(grp_name)
        save_group(groups_dir, grp)
        save_user(users_dir, user)
        print(f"[Identity] Added {email} to group {grp_name}")

    elif action == "remove-user":
        require_capability("identity.write", workspace=ws)
        email = args.email
        path = users_dir / f"{email}.json"
        if not path.exists():
            raise SystemExit(f"[Identity] User not found: {email}")
        # Remove from all groups
        for grp in list_groups(groups_dir):
            if email in grp.members:
                grp.members.remove(email)
                save_group(groups_dir, grp)
        path.unlink()
        from maestro.identity.integrity import remove_from_manifest
        remove_from_manifest(path, identity_dir)
        print(f"[Identity] Removed user: {email}")

    elif action == "show":
        require_capability("identity.read", workspace=ws)
        if args.email:
            email = args.email
        else:
            actor = resolve_caller(ws)
            email = actor.removeprefix("user:")
        caps = effective_capabilities(f"user:{email}", acl_path, groups_dir)
        print(f"\n  User: {email}")
        if not caps:
            print("  No capabilities granted.")
        else:
            print(f"  {'CAPABILITY':<30}  SCOPE")
            print("  " + "-" * 50)
            for cap, scope in sorted(caps):
                print(f"  {cap:<30}  {scope}")
        print()

    elif action == "acl":
        _identity_acl(args, ws, acl_path, require_capability, load_acl, save_acl, AclEntry)

    elif action == "user":
        _identity_user(args, ws, users_dir, groups_dir, require_capability,
                       UserRecord, GroupRecord, load_user, load_group,
                       save_user, save_group, list_users)

    elif action == "group":
        _identity_group(args, ws, groups_dir, acl_path, require_capability,
                        GroupRecord, AclEntry, load_group, load_acl,
                        save_group, save_acl, list_groups)

    elif action == "assign":
        require_capability("identity.write", workspace=ws)
        email = args.email
        grp_name = args.to_group
        user = load_user(users_dir, email)
        if user is None:
            raise SystemExit(f"[Identity] User not found: {email}")
        grp = load_group(groups_dir, grp_name)
        if grp is None:
            grp = GroupRecord(name=grp_name, members=[])
        if email not in grp.members:
            grp.members.append(email)
        if grp_name not in user.groups:
            user.groups.append(grp_name)
        save_group(groups_dir, grp)
        save_user(users_dir, user)
        print(f"[Identity] Assigned {email} to group {grp_name}")


def _identity_user(
    args: argparse.Namespace,
    ws: Path,
    users_dir: Path,
    groups_dir: Path,
    require_capability,
    UserRecord,
    GroupRecord,
    load_user,
    load_group,
    save_user,
    save_group,
    list_users,
) -> None:
    from datetime import datetime, timezone

    user_action = args.user_action

    if user_action == "add":
        require_capability("identity.write", workspace=ws)
        email = args.email
        display_name = args.display_name
        public_key: str | None = None
        if getattr(args, "public_key", None):
            pk_path = Path(args.public_key)
            if not pk_path.exists():
                raise SystemExit(f"[Identity] Public key file not found: {pk_path}")
            public_key = pk_path.read_text(encoding="utf-8").strip()

        existing = load_user(users_dir, email)
        if existing:
            raise SystemExit(f"[Identity] User already exists: {email}. Use 'identity assign' to modify groups.")

        record = UserRecord(
            email=email,
            display_name=display_name,
            groups=[],
            public_key=public_key,
            enrolled_at=datetime.now(timezone.utc).isoformat(),
        )
        save_user(users_dir, record)
        print(f"[Identity] Added user: {email}")

    elif user_action == "remove":
        require_capability("identity.write", workspace=ws)
        email = args.email
        path = users_dir / f"{email}.json"
        if not path.exists():
            raise SystemExit(f"[Identity] User not found: {email}")
        from maestro.identity import list_groups as _list_groups, save_group as _save_group
        for grp in _list_groups(groups_dir):
            if email in grp.members:
                grp.members.remove(email)
                _save_group(groups_dir, grp)
        path.unlink()
        from maestro.identity.integrity import remove_from_manifest
        remove_from_manifest(path, users_dir.parent)
        print(f"[Identity] Removed user: {email}")

    elif user_action == "list":
        require_capability("identity.read", workspace=ws)
        users = list_users(users_dir)
        if not users:
            print("[Identity] No users enrolled.")
            return
        print(f"  {'EMAIL':<40}  {'DISPLAY NAME':<30}  GROUPS")
        print("  " + "-" * 90)
        for u in users:
            print(f"  {u.email:<40}  {u.display_name:<30}  {', '.join(u.groups) or '—'}")


def _identity_group(
    args: argparse.Namespace,
    ws: Path,
    groups_dir: Path,
    acl_path: Path,
    require_capability,
    GroupRecord,
    AclEntry,
    load_group,
    load_acl,
    save_group,
    save_acl,
    list_groups,
) -> None:
    group_action = args.group_action

    if group_action == "add":
        require_capability("identity.write", workspace=ws)
        name = args.name
        if load_group(groups_dir, name):
            raise SystemExit(f"[Identity] Group already exists: {name}")
        record = GroupRecord(name=name, members=[])
        save_group(groups_dir, record)

        caps_raw = getattr(args, "capabilities", None)
        scope = getattr(args, "scope", "*") or "*"
        if caps_raw:
            entries = load_acl(acl_path)
            for cap in [c.strip() for c in caps_raw.split(",") if c.strip()]:
                new_entry = AclEntry(f"group:{name}", cap, scope)
                if not any(e.principal == new_entry.principal and e.capability == new_entry.capability and e.scope == new_entry.scope for e in entries):
                    entries.append(new_entry)
            save_acl(acl_path, entries)
            print(f"[Identity] Added group: {name} (capabilities: {caps_raw}, scope: {scope})")
        else:
            print(f"[Identity] Added group: {name}")

    elif group_action == "remove":
        require_capability("identity.write", workspace=ws)
        name = args.name
        path = groups_dir / f"{name}.json"
        if not path.exists():
            raise SystemExit(f"[Identity] Group not found: {name}")
        path.unlink()
        from maestro.identity.integrity import remove_from_manifest
        remove_from_manifest(path, groups_dir.parent)
        entries = load_acl(acl_path)
        before = len(entries)
        entries = [e for e in entries if e.principal != f"group:{name}"]
        if len(entries) < before:
            save_acl(acl_path, entries)
        print(f"[Identity] Removed group: {name}")

    elif group_action == "list":
        require_capability("identity.read", workspace=ws)
        groups = list_groups(groups_dir)
        if not groups:
            print("[Identity] No groups defined.")
            return
        print(f"  {'GROUP':<30}  {'MEMBERS':<6}  DESCRIPTION")
        print("  " + "-" * 70)
        for g in groups:
            desc = g.description or "—"
            print(f"  {g.name:<30}  {len(g.members):<6}  {desc}")


def _identity_init(
    identity_dir: Path,
    users_dir: Path,
    groups_dir: Path,
    acl_path: Path,
) -> None:
    from maestro.identity import GroupRecord, AclEntry, save_group, save_acl
    import secrets as _secrets
    import os

    users_dir.mkdir(parents=True, exist_ok=True)
    groups_dir.mkdir(parents=True, exist_ok=True)

    default_groups = ["captains", "fleet_operators", "contributors", "auditors"]
    for gname in default_groups:
        grp_path = groups_dir / f"{gname}.json"
        if not grp_path.exists():
            save_group(groups_dir, GroupRecord(name=gname, members=[]))

    if not acl_path.exists():
        entries = [
            AclEntry("group:captains",        "*",               "*"),
            AclEntry("group:fleet_operators", "fleet.dispatch",  "*"),
            AclEntry("group:fleet_operators", "bridge.start",    "*"),
            AclEntry("group:fleet_operators", "bridge.stop",     "*"),
            AclEntry("group:fleet_operators", "backup.create",   "*"),
            AclEntry("group:fleet_operators", "audit.read",      "*"),
            AclEntry("group:contributors",    "order.create",    "*"),
            AclEntry("group:contributors",    "voyage.view",     "*"),
            AclEntry("group:contributors",    "audit.read",      "*"),
            AclEntry("group:auditors",        "audit.read",      "*"),
            AclEntry("group:auditors",        "audit.export",    "*"),
            AclEntry("group:auditors",        "audit.anchor",    "*"),
        ]
        save_acl(acl_path, entries)

    # Generate workspace signing key (gitignored)
    signing_key_path = identity_dir / "workspace-signing.key"
    if not signing_key_path.exists():
        key_bytes = _secrets.token_bytes(32)
        import base64
        signing_key_path.write_text(
            base64.b64encode(key_bytes).decode("ascii") + "\n",
            encoding="utf-8",
        )
        try:
            os.chmod(signing_key_path, 0o600)
        except Exception:
            pass

    print("[Identity] Initialised .adm/identity/ with default groups and access.json")
    print(f"  Groups created: {', '.join(default_groups)}")
    print(f"  ACL seeded: {acl_path}")
    print(f"  Signing key: {signing_key_path}")
    print("  Add users with: adm identity add-user --email <email> --display-name <name>")


def _identity_rights(args: argparse.Namespace, ws: Path, identity_dir: Path) -> None:
    from maestro.identity.gate import require_capability
    from maestro.identity.rights import (
        rights_export, rights_forget, rights_restrict, export_classification_csv,
    )

    rights_action = args.rights_action
    require_capability("identity.read", workspace=ws)

    if rights_action == "export":
        report = rights_export(args.email, ws)
        print(json.dumps(report, indent=2))

    elif rights_action == "forget":
        require_capability("identity.write", workspace=ws)
        dry_run = not getattr(args, "execute", False)
        plan = rights_forget(args.email, ws, dry_run=dry_run)
        print(json.dumps(plan, indent=2))
        if dry_run:
            print("\n[Identity] Dry-run complete. Pass --execute to perform identity-layer deletions.")
            print("  NOTE: git history rewrite requires manual steps (see plan.manual_steps).")

    elif rights_action == "restrict":
        require_capability("identity.write", workspace=ws)
        result = rights_restrict(args.email, ws)
        print(json.dumps(result, indent=2))

    elif rights_action == "export-classification":
        csv_output = export_classification_csv(ws)
        print(csv_output)


def _identity_acl(
    args: argparse.Namespace,
    ws: Path,
    acl_path: Path,
    require_capability,
    load_acl,
    save_acl,
    AclEntry,
) -> None:
    acl_action = args.acl_action

    if acl_action in ("list", "show"):
        require_capability("identity.read", workspace=ws)
        entries = load_acl(acl_path)
        if not entries:
            print("[Identity] No ACL entries.")
            return
        if args.principal:
            entries = [e for e in entries if e.principal == args.principal]
        print(f"  {'PRINCIPAL':<40}  {'CAPABILITY':<25}  SCOPE")
        print("  " + "-" * 80)
        for e in entries:
            print(f"  {e.principal:<40}  {e.capability:<25}  {e.scope}")

    elif acl_action == "set":
        require_capability("identity.write", workspace=ws)
        entries = load_acl(acl_path)
        new_entry = AclEntry(args.principal, args.capability, args.scope)
        # Avoid duplicates
        for e in entries:
            if e.principal == new_entry.principal and e.capability == new_entry.capability and e.scope == new_entry.scope:
                print(f"[Identity] Entry already exists.")
                return
        entries.append(new_entry)
        save_acl(acl_path, entries)
        from maestro.audit import get_audit_log
        get_audit_log(ws).append(
            "config.modify",
            target="identity/access.json",
            metadata={"op": "acl.set", "principal": args.principal, "capability": args.capability, "scope": args.scope},
        )
        print(f"[Identity] ACL entry added: {args.principal} → {args.capability} ({args.scope})")

    elif acl_action == "remove":
        require_capability("identity.write", workspace=ws)
        entries = load_acl(acl_path)
        before = len(entries)
        entries = [
            e for e in entries
            if not (e.principal == args.principal and e.capability == args.capability and e.scope == args.scope)
        ]
        if len(entries) == before:
            print("[Identity] No matching entry found.")
            return
        save_acl(acl_path, entries)
        from maestro.audit import get_audit_log
        get_audit_log(ws).append(
            "config.modify",
            target="identity/access.json",
            metadata={"op": "acl.remove", "principal": args.principal, "capability": args.capability, "scope": args.scope},
        )
        print(f"[Identity] ACL entry removed: {args.principal} → {args.capability} ({args.scope})")


def cmd_secrets(args: argparse.Namespace) -> None:
    """Secrets operator tooling: doctor, rotate, scrub, list."""
    action = args.secrets_action
    ws = find_workspace(getattr(args, "project", None))

    try:
        from maestro.secrets.registry import get_provider, _load_enterprise_flag
    except ImportError:
        raise SystemExit("[Secrets] Secrets module not available. Ensure admiralty is installed.")

    if action == "doctor":
        _secrets_doctor(ws)
    elif action == "rotate":
        _secrets_rotate(ws, args.key)
    elif action == "scrub":
        _secrets_scrub(ws)
    elif action == "list":
        _secrets_list(ws)
    else:
        raise SystemExit(f"[Secrets] Unknown action: {action}")


def _secrets_doctor(ws: Path) -> None:
    """Verify every secret:// reference in workspace config resolves cleanly."""
    import re as _re

    try:
        from maestro.secrets.registry import get_provider
        from maestro.secrets.refs import parse_ref
    except ImportError:
        raise SystemExit("[Secrets] Secrets module not available.")

    config_dir = ws / ".adm" / "config"
    if not config_dir.is_dir():
        print("[Secrets] No .adm/config/ directory found.")
        raise SystemExit(2)

    ref_pattern = _re.compile(r"secret://[^\s\"']+")
    findings: list[tuple[str, str, str]] = []  # (ref, status, detail)

    for cfg_file in sorted(config_dir.glob("*.json")):
        try:
            text = cfg_file.read_text(encoding="utf-8", errors="replace")
        except Exception as exc:
            print(f"[Secrets] Could not read {cfg_file}: {exc}")
            continue
        for match in ref_pattern.finditer(text):
            ref_str = match.group(0)
            ref = parse_ref(ref_str)
            if ref is None:
                findings.append((ref_str, "invalid", str(cfg_file)))
                continue
            try:
                provider = get_provider(ws)
                value = provider.get(ref.key)
                if value is None:
                    findings.append((ref_str, "missing", str(cfg_file)))
                else:
                    findings.append((ref_str, "resolved", str(cfg_file)))
            except PermissionError:
                findings.append((ref_str, "permission-denied", str(cfg_file)))
            except OSError as exc:
                findings.append((ref_str, "network-error", str(exc)))
            except Exception as exc:
                findings.append((ref_str, "error", str(exc)))

    if not findings:
        print("[Secrets] No secret:// references found in workspace config.")
        raise SystemExit(0)

    failures = [f for f in findings if f[1] != "resolved"]
    for ref_str, status, detail in findings:
        icon = "✓" if status == "resolved" else "✗"
        print(f"  {icon} [{status:17s}] {ref_str}")
        if status != "resolved":
            print(f"              → {detail}")

    if failures:
        print(f"\n[Secrets] doctor: {len(failures)} reference(s) failed to resolve.")
        raise SystemExit(1)

    print(f"\n[Secrets] doctor: all {len(findings)} reference(s) resolved cleanly.")
    raise SystemExit(0)


def _secrets_rotate(ws: Path, key: str | None) -> None:
    """Kick a rotation workflow for the given key."""
    if not key:
        print("[Secrets] --key KEY is required for rotate.")
        raise SystemExit(2)

    try:
        from maestro.secrets.registry import get_provider
    except ImportError:
        raise SystemExit("[Secrets] Secrets module not available.")

    try:
        provider = get_provider(ws)
    except Exception as exc:
        print(f"[Secrets] Config error: {exc}")
        raise SystemExit(2)

    provider_type = type(provider).__name__
    rotate_hook = getattr(provider, "rotate_hook", None)
    if callable(rotate_hook):
        try:
            rotate_hook(key)
            print(f"[Secrets] Rotation hook completed for key: {key}")
            raise SystemExit(0)
        except SystemExit:
            raise
        except Exception as exc:
            print(f"[Secrets] Rotation hook failed: {exc}")
            raise SystemExit(1)

    # No hook — print provider-specific documented steps
    steps = {
        "EnvSecretsProvider": [
            f"1. Generate a new value for the secret.",
            f"2. Update the environment variable: export {key}=<new-value>",
            f"3. Restart any services that consume this variable.",
            f"4. Invalidate the old value in your secrets store.",
        ],
        "OsKeyringSecretsProvider": [
            f"1. Generate a new value for the secret.",
            f"2. Run: python -c \"import keyring; keyring.set_password('admiralty', '{key}', '<new-value>')\"",
            f"3. Restart any processes that loaded the old value.",
        ],
        "AzureKeyVaultSecretsProvider": [
            f"1. In Azure Portal → Key Vault → Secrets, select '{key}'.",
            f"2. Click 'New Version' and enter the new secret value.",
            f"3. Update any consumers to use the new version or rely on 'latest'.",
            f"4. Disable/delete the old version after a soak period.",
        ],
        "AwsSecretsManagerProvider": [
            f"1. Run: aws secretsmanager put-secret-value --secret-id {key} --secret-string <new-value>",
            f"2. AWS Secrets Manager automatically versions; update rotation schedule if needed.",
            f"3. Verify consumers pick up the new version.",
        ],
        "HashiCorpVaultProvider": [
            f"1. Run: vault kv put <mount>/<path>/{key} value=<new-value>",
            f"2. Vault creates a new secret version automatically.",
            f"3. Update lease TTLs or rotation policies as needed.",
        ],
        "OnePasswordConnectProvider": [
            f"1. Open 1Password and locate the item containing '{key}'.",
            f"2. Edit the field and save a new value.",
            f"3. The Connect API will return the updated value on next request.",
        ],
    }
    provider_steps = steps.get(provider_type, [
        f"1. Generate a new value for '{key}' in your secrets provider ({provider_type}).",
        f"2. Update the value in the provider's management interface.",
        f"3. Restart any consumers that loaded the old value.",
    ])

    print(f"[Secrets] Manual rotation steps for '{key}' (provider: {provider_type}):")
    for step in provider_steps:
        print(f"  {step}")
    raise SystemExit(0)


def _secrets_scrub(ws: Path) -> None:
    """Scan config and log files for likely cleartext secrets."""
    try:
        from maestro.hooks.secret_patterns import Scanner
    except ImportError:
        raise SystemExit("[Secrets] secret_patterns module not available.")

    scan_targets: list[Path] = []

    config_dir = ws / ".adm" / "config"
    if config_dir.is_dir():
        scan_targets.extend(sorted(config_dir.glob("*.json")))

    claude_settings = ws / ".claude" / "settings.json"
    if claude_settings.exists():
        scan_targets.append(claude_settings)

    log_dir = ws / ".adm" / "logs"
    if log_dir.is_dir():
        scan_targets.extend(sorted(log_dir.glob("*.log")))

    if not scan_targets:
        print("[Secrets] No files found to scrub.")
        raise SystemExit(0)

    scanner = Scanner(workspace_root=ws)
    all_findings: list[tuple[Path, object]] = []

    for path in scan_targets:
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except Exception as exc:
            print(f"[Secrets] Could not read {path}: {exc}")
            continue
        rel = path.relative_to(ws) if path.is_relative_to(ws) else path
        matches = scanner.scan(text, field_label=str(rel), rel_path=str(rel))
        for m in matches:
            all_findings.append((path, m))

    if not all_findings:
        print(f"[Secrets] scrub: {len(scan_targets)} file(s) scanned — no findings.")
        raise SystemExit(0)

    print(f"[Secrets] scrub: {len(scan_targets)} file(s) scanned, {len(all_findings)} finding(s):\n")
    for path, m in all_findings:
        rel = path.relative_to(ws) if path.is_relative_to(ws) else path
        print(f"  [{m.severity:8s}] {rel}")
        print(f"           pattern: {m.pattern_name}")
        print(f"           fix:     replace value with a secret:// reference in workspace.json secretsProvider")
        print()

    raise SystemExit(1)


def _secrets_list(ws: Path) -> None:
    """List keys (never values) exposed by the active provider — gated by ACL secrets.list."""
    try:
        from maestro.secrets.registry import get_provider, _load_enterprise_flag
    except ImportError:
        raise SystemExit("[Secrets] Secrets module not available.")

    if not _load_enterprise_flag(ws):
        print("[Secrets] list requires enterprise mode. Set enterprise: true in workspace.json.")
        raise SystemExit(2)

    try:
        from maestro.identity.gate import require_capability
        require_capability("secrets.list", workspace=ws)
    except ImportError:
        pass  # identity gate not available — allow
    except Exception as exc:
        print(f"[Secrets] Access denied: {exc}")
        raise SystemExit(1)

    try:
        provider = get_provider(ws)
        keys = provider.list()
    except Exception as exc:
        print(f"[Secrets] Provider error: {exc}")
        raise SystemExit(1)

    if not keys:
        print("[Secrets] No keys found in active provider.")
        raise SystemExit(0)

    print(f"[Secrets] {len(keys)} key(s) in active provider:\n")
    for k in sorted(keys):
        print(f"  {k}")
    raise SystemExit(0)


def cmd_audit(args: argparse.Namespace) -> None:
    """Audit log operations: tail, verify, export."""
    ws = find_workspace(getattr(args, "project", None))
    from maestro.identity.gate import require_capability
    from maestro.audit import get_audit_log

    action = args.audit_action
    require_capability("audit.read", workspace=ws)

    log = get_audit_log(ws)

    if action == "tail":
        import time
        log_path = ws / ".adm" / "audit" / "log.jsonl"
        if not log_path.exists():
            print("[Audit] No audit log found at", log_path)
            return
        n = getattr(args, "lines", 20)
        lines: list[str] = []
        with open(log_path, encoding="utf-8") as fh:
            for line in fh:
                lines.append(line)
        for line in lines[-n:]:
            line = line.strip()
            if line:
                _print_audit_line(line)
        if not getattr(args, "no_follow", False):
            print("[Audit] Following log (Ctrl-C to stop)...")
            with open(log_path, encoding="utf-8") as fh:
                fh.seek(0, 2)
                try:
                    while True:
                        line = fh.readline()
                        if line:
                            line = line.strip()
                            if line:
                                _print_audit_line(line)
                        else:
                            time.sleep(0.5)
                except KeyboardInterrupt:
                    pass

    elif action == "verify":
        ok, errors = log.verify_chain()
        if ok:
            print("[Audit] Chain verified — no tampering detected.")
            raise SystemExit(0)
        else:
            print(f"[Audit] Chain FAILED verification ({len(errors)} error(s)):")
            for e in errors:
                print(f"  ✗ {e}")
            raise SystemExit(1)

    elif action == "export":
        import csv as _csv
        import io

        since = None
        if args.since:
            try:
                from datetime import datetime, timezone
                since = datetime.fromisoformat(args.since).replace(tzinfo=timezone.utc)
            except Exception:
                raise SystemExit(f"[Audit] Invalid --since date: {args.since}  (use YYYY-MM-DD)")

        entries = list(log.iterate(since=since))
        fmt = getattr(args, "format", "jsonl")

        if fmt == "jsonl":
            for entry in entries:
                print(json.dumps(entry.to_dict(), separators=(",", ":")))
        elif fmt == "json":
            print(json.dumps([e.to_dict() for e in entries], indent=2))
        elif fmt == "csv":
            out = io.StringIO()
            writer = _csv.writer(out)
            writer.writerow(["seq", "timestamp", "actor", "action", "target", "result", "prevHash", "hash"])
            for e in entries:
                writer.writerow([e.seq, e.timestamp, e.actor, e.action, e.target, e.result, e.prev_hash, e.hash])
            print(out.getvalue(), end="")
        else:
            raise SystemExit(f"[Audit] Unknown format: {fmt}")

    elif action == "anchor":
        from maestro.audit.anchor import load_provider
        from maestro.audit.anchor.scheduler import record_anchor
        from pathlib import Path as _Path

        require_capability("audit.anchor", workspace=ws)

        auto_mode = getattr(args, "auto", False)

        if auto_mode:
            # Read provider and config path from workspace.json
            try:
                _ws_data = json.loads((ws / ".adm" / "config" / "workspace.json").read_text(encoding="utf-8"))
                _audit_cfg = _ws_data.get("audit", {})
                provider_name = _audit_cfg.get("anchorProvider", "fs")
                _cfg_path = _audit_cfg.get("anchorConfig")
                config_file = _Path(_cfg_path) if _cfg_path else None
            except Exception as exc:
                raise SystemExit(f"[Audit] Cannot read workspace.json for --auto mode: {exc}")
        else:
            provider_name = getattr(args, "provider", "fs")
            config_file = None
            if getattr(args, "config", None):
                config_file = _Path(args.config)
                if not config_file.exists():
                    raise SystemExit(f"[Audit] Config file not found: {config_file}")

        if config_file is not None and not config_file.exists():
            raise SystemExit(f"[Audit] Anchor config file not found: {config_file}")

        try:
            provider = load_provider(provider_name, config_file)
        except ValueError as exc:
            raise SystemExit(f"[Audit] {exc}")

        # Get current root hash (last entry's hash)
        last_entry = None
        for last_entry in log.iterate():
            pass
        if last_entry is None:
            raise SystemExit("[Audit] No audit log entries found — nothing to anchor.")

        root_hash = last_entry.hash
        print(f"[Audit] Anchoring root hash {root_hash[:24]}… via {provider_name}")

        try:
            receipt = provider.anchor(root_hash, metadata={"seq": last_entry.seq})
        except RuntimeError as exc:
            raise SystemExit(f"[Audit] Anchor failed: {exc}")

        # Record anchor time before writing the audit entry (unblocks freshness gate)
        record_anchor(ws)

        # Write receipt back into the audit log
        log.append(
            action="audit.anchor",
            target=receipt.location,
            result="ok",
            metadata=receipt.to_dict(),
        )

        print(f"[Audit] Anchor receipt stored at: {receipt.location}")
        print(f"[Audit] Anchor event written to audit log.")


def _print_audit_line(line: str) -> None:
    try:
        d = json.loads(line)
        print(
            f"  [{d.get('seq', '?'):>6}]  {d.get('timestamp', '')}  "
            f"{d.get('actor', ''):<35}  {d.get('action', ''):<25}  "
            f"{d.get('target', ''):<20}  {d.get('result', '')}"
        )
    except Exception:
        print(line)


def cmd_migrate_workspace(args: argparse.Namespace) -> None:
    """mso migrate-workspace — interactive .adm/ → .mso/ migration with --dry-run / --resolve / --force."""
    from maestro.workspace import migrate_workspace as _migrate

    dry_run: bool = getattr(args, "dry_run", False)
    force: bool = getattr(args, "force", False)
    resolve: bool = getattr(args, "resolve", False)

    try:
        report = _migrate(dry_run=dry_run, force=force, resolve=resolve)
    except FileNotFoundError as exc:
        print(f"  ✗ {exc}")
        sys.exit(1)
    except RuntimeError as exc:
        print(f"  ✗ {exc}")
        sys.exit(1)

    errors = report.get("errors", [])
    if errors:
        print(f"  Errors  : {len(errors)}")
        for e in errors:
            print(f"    ✗ {e}")
        sys.exit(1)


def cmd_version(args: argparse.Namespace) -> None:
    """Print Admiralty version. (Auth check bypassed — see auth.py.)"""
    from maestro import __version__, __title__
    print(f"{__title__} v{__version__}")


def cmd_config_models(args: argparse.Namespace) -> None:
    """`adm config models` — show the resolved model for each role with the
    override source that decided it (FTR-ADM-2026-0129).

    Resolution order: per-order → workspace config → env var → built-in.
    The per-order layer can't be displayed in a static table (it depends on
    the order being dispatched), so this command shows the next three.

    Copilot review: derives the role list dynamically (from ROLE_MODELS +
    workspace + env vars) so future roles or unfamiliar workspace overrides
    show up automatically. Exits 1 if any displayed value is unsupported,
    so scripts can rely on `adm config models` as a config doctor.
    """
    import os as _os
    import sys as _sys
    from maestro.core.crew import (
        ROLE_MODELS, DEFAULT_MODEL, SUPPORTED_MODELS,
        _load_workspace_role_models,
    )

    workspace = _load_workspace_role_models()

    # Build role list dynamically: built-in defaults ∪ workspace overrides ∪
    # any role that has a MAESTRO_MODEL_* env var set. This way custom
    # roles or roles only seen in config still appear without a doc-update lag.
    env_roles = {
        var.removeprefix("MAESTRO_MODEL_")
        for var in _os.environ
        if var.startswith("MAESTRO_MODEL_")
    }
    roles = sorted(set(ROLE_MODELS.keys()) | set(workspace.keys()) | env_roles)

    print("\nAdmiralty role-model resolution (FTR-ADM-2026-0129)")
    print("Order: per-order > workspace config > env var > built-in default\n")
    print(f"  {'Role':<6} {'Model':<40} Source")
    print(f"  {'----':<6} {'-----':<40} ------")
    has_unknown = False
    for role in roles:
        env_var = f"MAESTRO_MODEL_{role}"
        env_val = _os.environ.get(env_var, "")
        ws_val = workspace.get(role, "")
        if ws_val:
            model, source = ws_val, ".adm/config/role-models.json"
        elif env_val:
            model, source = env_val, f"${env_var}"
        else:
            model, source = ROLE_MODELS.get(role, DEFAULT_MODEL), "built-in default"
        if model in SUPPORTED_MODELS:
            valid = ""
        else:
            valid = "  (UNKNOWN MODEL!)"
            has_unknown = True
        print(f"  {role:<6} {model:<40} {source}{valid}")

    print(
        f"\nSupported model IDs: {', '.join(sorted(SUPPORTED_MODELS))}\n"
        f"To override:\n"
        f"  - Env var:    set MAESTRO_MODEL_SHP=claude-opus-4-7\n"
        f"  - Workspace:  edit .adm/config/role-models.json {{\"models\": {{\"SHP\": \"claude-opus-4-7\"}}}}\n"
        f"  - Per-order:  add a `model` field to the order JSON\n"
    )

    # Copilot review: exit non-zero if any displayed model is unsupported so
    # scripts (CI doctors, dispatcher pre-flight) can rely on a clean exit.
    if has_unknown:
        print(
            "ERROR: One or more roles resolve to an unsupported model. "
            "Dispatch will refuse to launch crews against these models — "
            "fix the override source shown above before running `adm dispatch`.",
            file=_sys.stderr,
        )
        _sys.exit(1)


def cmd_licence(args: argparse.Namespace) -> None:
    """`adm licence <activate|status|deactivate|revalidate>` — VOY-0031."""
    import json as _json
    import os as _os
    from maestro import licence as _licence
    from maestro.licence.errors import (
        LicenceError, LicenceMissing, LicenceInvalid, LicenceRevoked,
        LicenceExpired, LicenceTampered,
    )
    from maestro.licence.client import PolarError

    sub = args.licence_cmd

    if sub == "activate":
        key = args.key or _os.environ.get("MAESTRO_LICENCE_KEY", "")
        if not key:
            print(
                "Error: provide a key as `adm licence activate <KEY>` "
                "or set MAESTRO_LICENCE_KEY.",
                file=sys.stderr,
            )
            sys.exit(1)
        try:
            rec = _licence.activate(key)
        except LicenceInvalid as exc:
            print(f"Activation refused: {exc}", file=sys.stderr)
            sys.exit(1)
        except PolarError as exc:
            if exc.status == 0:
                print(
                    f"Couldn't reach the licence backend: {exc.reason}\n"
                    "Activation requires online verification — try again with a live network.",
                    file=sys.stderr,
                )
                sys.exit(2)
            print(f"Polar API error {exc.status}: {exc.reason}", file=sys.stderr)
            sys.exit(1)
        print(f"Licence activated  ({rec.tier} tier, expires {rec.expires_at})")
        return

    if sub == "status":
        from maestro.licence import config as _licence_config
        rec = _licence.status()
        if rec is None:
            print("No licence activated. Run `adm licence activate <KEY>` to start.")
            sys.exit(1)
        test_mode = _licence_config.is_test_mode()
        fake_active = _os.environ.get("MAESTRO_LICENCE_FAKE_ACTIVATION") == "1"
        is_fake_record = rec.customer_id.startswith("cust_FAKE_")
        if args.json:
            print(_json.dumps({
                "tier": rec.tier,
                "customer_id": rec.customer_id,
                "issued_at": rec.issued_at,
                "expires_at": rec.expires_at,
                "last_validated_at": rec.last_validated_at,
                "offline_grace_until": rec.offline_grace_until,
                "polar_org_slug": _licence_config.POLAR_ORG_SLUG,
                "polar_test_mode": test_mode,
                "fake_activation_active": fake_active,
                "fake_record": is_fake_record,
            }, indent=2))
        else:
            if is_fake_record:
                print("[FAKE ACTIVATION] Synthetic licence — Polar bypass; not for production.")
            elif test_mode:
                print("[TEST MODE] Polar sandbox — no real billing.")
            print(f"Tier:               {rec.tier}")
            print(f"Customer:           {rec.customer_id}")
            print(f"Issued:             {rec.issued_at}")
            print(f"Expires:            {rec.expires_at}")
            print(f"Last validated:     {rec.last_validated_at}")
            print(f"Offline grace ends: {rec.offline_grace_until}")
            print(f"Manage subscription: {_licence_config.POLAR_PORTAL_URL}")
        return

    if sub == "deactivate":
        from maestro.licence import config as _licence_config
        _licence.deactivate()
        print(
            "Licence record removed (Polar subscription unaffected — manage at "
            f"{_licence_config.POLAR_PORTAL_URL})."
        )
        return

    if sub == "revalidate":
        # FTR-0120 — test-only flag. Rewind last_validated_at to force the
        # next CLI invocation through the offline-grace path. Requires the
        # operator to opt in via MAESTRO_LICENCE_TEST_FLAGS=1 in the
        # parent shell so it can't be set inside a crew session or by a
        # customer who happened to read --help output.
        if getattr(args, "offline_mark_stale", False):
            if _os.environ.get("MAESTRO_LICENCE_TEST_FLAGS") != "1":
                print(
                    "Refused: --offline-mark-stale is a test-only flag. Set "
                    "MAESTRO_LICENCE_TEST_FLAGS=1 in the operator shell "
                    "before running this.",
                    file=sys.stderr,
                )
                sys.exit(1)
            from maestro.licence import storage as _storage
            from datetime import datetime as _dt, timedelta as _td, timezone as _tz
            try:
                rec = _storage.load_record()
            except LicenceMissing:
                print("No licence to mark stale. Run `adm licence activate <KEY>` first.", file=sys.stderr)
                sys.exit(1)
            except LicenceTampered as exc:
                print(f"Licence tampered: {exc}", file=sys.stderr)
                sys.exit(1)
            stale = (_dt.now(_tz.utc) - _td(hours=25)).isoformat()
            rec.last_validated_at = stale
            _storage.save_record(rec)
            print(
                f"Marked licence record stale (last_validated_at={stale}). "
                "The next `adm` run will hit the offline-grace path."
            )
            return
        try:
            rec = _licence.validate(strict=True)
        except LicenceMissing:
            print("No licence to revalidate. Run `adm licence activate <KEY>` first.", file=sys.stderr)
            sys.exit(1)
        except LicenceTampered as exc:
            print(f"Licence tampered: {exc}", file=sys.stderr)
            sys.exit(1)
        except (LicenceRevoked, LicenceExpired) as exc:
            print(f"Licence rejected: {exc}", file=sys.stderr)
            sys.exit(1)
        except LicenceError as exc:
            print(f"Licence error: {exc}", file=sys.stderr)
            sys.exit(1)
        if getattr(rec, "used_grace", False):
            remaining = getattr(rec, "grace_remaining_days", 0)
            print(
                f"⚠  Couldn't reach the licence backend; running on offline grace "
                f"({remaining} days remaining). Reconnect to revalidate.",
                file=sys.stderr,
            )
        print(f"Licence still valid ({rec.tier} tier, expires {rec.expires_at})")
        return


def _cmd_review(action: str, args: argparse.Namespace) -> None:
    """Dispatch to the appropriate review handler."""
    from maestro import review as _review
    handler = {
        "queue": _review.cmd_review_queue,
        "show": _review.cmd_review_show,
        "approve": _review.cmd_review_approve,
        "revise": _review.cmd_review_revise,
        "reject": _review.cmd_review_reject,
    }[action]
    handler(args)


def cmd_data_flow(args: argparse.Namespace) -> None:
    """Generate a data-flow diagram of all outbound destinations."""
    from maestro.egress.diagram import generate_diagram

    workspace = find_workspace(getattr(args, "project", None))
    fmt = getattr(args, "format", "mermaid") or "mermaid"
    mode = getattr(args, "mode", None) or None
    output_path = None
    if getattr(args, "output", None):
        output_path = Path(args.output)

    diagram = generate_diagram(workspace, fmt=fmt, output=output_path, mode=mode)

    if output_path:
        print(f"[Admiralty] Data-flow diagram written to: {output_path}")
    else:
        print(diagram)


# ---------------------------------------------------------------------------
# CLI definition
# ---------------------------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="admiralty",
        description="Maestro — AI-powered multi-agent Claude Code orchestration",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
commands:
  dispatch    Launch fleet crews from the dispatch queue
  cleanup     Stop rogue processes and reset stale state (auto-backup)
  status      Show fleet status dashboard
  usage       Token usage and cost reporting
  crew        Operate an individual crew
  verify      Post-voyage build/test verification
  bridge      Manage the Mobile Command Bridge (Slack + poller)
  voyage      Create and manage voyages
  bug         Create a BUG order
  backup      Create or list project state backups
  restore     Restore project state from a backup ZIP
  init        Scaffold a new Admiralty workspace
  update      Propagate schema updates to an existing workspace
  projects    List or manage registered projects
  version     Print version

examples:
  admiralty dispatch --max-crews 3
  admiralty status --once
  admiralty usage --voyage VOY-OTM-2026-0700
  admiralty bridge restart
  admiralty voyage create "My new voyage" --project ADM
  admiralty voyage list --project ADM
  admiralty voyage status VOY-ADM-2026-0001
  admiralty bug "Login crashes on mobile" --project ADM
  admiralty backup --project OTM
  admiralty backup --list
  admiralty restore admiralty-backups/admiralty-backup-all-2026-03-30-120000.zip --dry-run
  admiralty init --project MYPROJECT --directory ./my-workspace
  admiralty update
  admiralty update --dry-run
  admiralty projects list
  admiralty projects remove PSG
        """,
    )

    sub = parser.add_subparsers(dest="command", metavar="<command>")
    sub.required = True

    # -- dispatch --
    p = sub.add_parser("dispatch", help="Launch fleet crews")
    p.add_argument("--max-crews", type=int, default=5, metavar="N",
                   help="Maximum concurrent crews (default: 5)")
    p.add_argument("--cleanup", action="store_true",
                   help="Run cleanup before dispatching")
    p.add_argument("--stagger-delay", type=int, default=30,
                   help="Seconds between crew launches (default: 30)")
    p.add_argument("--timeout", type=int, default=90,
                   help="Per-crew timeout in minutes (default: 90)")
    p.add_argument("--project", metavar="@PRJ",
                   help="Registered project acronym (e.g. @ADM)")
    p.set_defaults(func=cmd_dispatch)

    # -- cleanup --
    p = sub.add_parser("cleanup", help="Stop rogue processes and reset stale state")
    p.add_argument("--project", metavar="@PRJ",
                   help="Registered project acronym (e.g. @ADM)")
    p.set_defaults(func=cmd_cleanup)

    # -- status --
    p = sub.add_parser("status", help="Show fleet status dashboard")
    p.add_argument("--once", action="store_true", default=False,
                   help="One-shot display (no loop; default is live-updating)")
    p.add_argument("--compact", action="store_true",
                   help="One-line summary per crew")
    p.add_argument("--project", metavar="@PRJ",
                   help="Registered project acronym (e.g. @ADM)")
    p.set_defaults(func=cmd_status)

    # -- usage --
    p = sub.add_parser("usage", help="Token usage and cost reporting")
    grp = p.add_mutually_exclusive_group()
    grp.add_argument("--summary", action="store_true",
                     help="Workspace-wide summary (also the default when no flag is given)")
    grp.add_argument("--voyage", metavar="VOY-ID",
                     help="Per-voyage breakdown")
    grp.add_argument("--order", metavar="ORDER-ID",
                     help="Per-order breakdown")
    grp.add_argument("--report", action="store_true",
                     help="Generate full markdown report")
    p.add_argument("--output", metavar="PATH",
                   help="Output path for --report")
    p.add_argument("--project", metavar="@PRJ",
                   help="Registered project acronym (e.g. @ADM)")
    p.set_defaults(func=cmd_usage)

    # -- crew --
    p = sub.add_parser("squad", help="Operate an individual squad (crew)")
    p.add_argument("--crew", type=int, required=True, choices=range(1, 6),
                   metavar="{1-5}", help="Squad number")
    p.add_argument("--status", action="store_true", help="Show squad status")
    p.add_argument("--watch", action="store_true", help="Watch squad progress live")
    p.add_argument("--cleanup", action="store_true", help="Stop this squad's process")
    p.add_argument("--project", metavar="@PRJ",
                   help="Registered project acronym (e.g. @ADM)")
    p.set_defaults(func=cmd_crew)

    p = sub.add_parser("crew", help="[deprecated: use 'squad'] Operate an individual crew")
    p.add_argument("--crew", type=int, required=True, choices=range(1, 6),
                   metavar="{1-5}", help="Crew number")
    p.add_argument("--status", action="store_true", help="Show crew status")
    p.add_argument("--watch", action="store_true", help="Watch crew progress live")
    p.add_argument("--cleanup", action="store_true", help="Stop this crew's process")
    p.add_argument("--project", metavar="@PRJ",
                   help="Registered project acronym (e.g. @ADM)")
    p.set_defaults(func=cmd_crew, _noun_deprecated="crew")

    # -- verify --
    p = sub.add_parser("verify", help="Post-voyage build/test verification")
    p.add_argument("--voyage", metavar="VOY-ID",
                   help="Voyage ID to verify")
    p.add_argument("--skip-tests", action="store_true",
                   help="Reuse existing test results")
    p.add_argument("--project", metavar="@PRJ",
                   help="Registered project acronym (e.g. @ADM)")
    p.set_defaults(func=cmd_verify)

    # -- init --
    p = sub.add_parser("init", help="Scaffold a new Admiralty workspace")
    p.add_argument("--project", metavar="ACRONYM", required=True,
                   help="Project acronym (e.g. OTM, PSG)")
    p.add_argument("--directory", metavar="PATH",
                   help="Workspace directory (default: current directory)")
    p.add_argument("--force", action="store_true",
                   help="Overwrite existing .adm/ if present")
    p.add_argument("--enterprise", action="store_true",
                   help="Enable enterprise mode — walks through anchor provider configuration")
    p.set_defaults(func=cmd_init)

    # -- quickstart --
    p = sub.add_parser(
        "quickstart",
        help="Run the guided first-run experience",
        description="Verify environment, scaffold a workspace, and dispatch a demo voyage.",
    )
    p.add_argument("--project", default="DEMO", metavar="ACRONYM",
                   help="Project acronym for the demo workspace (default: DEMO)")
    p.add_argument("--no-demo", action="store_true",
                   help="Skip demo voyage; only verify environment and init workspace")
    p.add_argument("--crews", type=int, default=1, metavar="N",
                   help="Number of crews to dispatch (default: 1)")
    p.add_argument("--skip-checks", action="store_true",
                   help="Skip pre-flight checks (for CI use)")
    p.add_argument("--repo", metavar="ORG/NAME",
                   help="Link demo to a GitHub repo (mode B — explicit)")
    p.add_argument("--no-link-repo", action="store_true",
                   help="Run in local-only mode without linking a GitHub repo (mode C)")
    p.add_argument("--force", action="store_true",
                   help="Overwrite existing repo config in projects.json")
    p.set_defaults(func=cmd_quickstart)

    # -- setup --
    p = sub.add_parser(
        "setup",
        help="Prerequisite validation and interactive setup wizard",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
examples:
  adm setup                  Interactive wizard (default)
  adm setup --check          Non-interactive audit; exits non-zero on WARN/FAIL
  adm setup --repair         Auto-fix repairable issues
  adm setup --show prereqs   Read-only view of prerequisite status
  mso setup --show persona   Show active persona and resolution source
        """,
    )
    p.add_argument(
        "--check", action="store_true",
        help="Non-interactive: run checks and exit with code (0=OK, 1=FAIL, 2=WARN)",
    )
    p.add_argument(
        "--repair", action="store_true",
        help="Detect and automatically repair repairable issues",
    )
    p.add_argument(
        "--show", metavar="SECTION",
        choices=["prereqs", "project", "workspace", "templates", "persona"],
        help="Read-only inspection of one config section",
    )
    p.add_argument(
        "--json", action="store_true",
        help="JSON output (use with --check for CI parsing)",
    )
    p.set_defaults(func=cmd_setup)

    # -- bridge --
    p = sub.add_parser("bridge", help="Manage the Mobile Command Bridge",
                       formatter_class=argparse.RawDescriptionHelpFormatter,
                       epilog="""
actions:
  setup         Interactive setup wizard — creates bridge-settings.json
  start         Start both poller and Slack bot
  stop          Stop both poller and Slack bot
  restart       Stop then start both poller and Slack bot
  status        Show bridge component status
  test          Send a test Slack notification
  poller-start  Start only the command poller
  poller-stop   Stop only the command poller
  bot-start     Start only the Slack bot
  bot-stop      Stop only the Slack bot

examples:
  admiralty bridge setup
  admiralty bridge start
  admiralty bridge restart
  admiralty bridge status
  admiralty bridge test --project ADM
        """)
    p.add_argument("bridge_action", metavar="<action>",
                   choices=["setup", "start", "stop", "restart", "status", "test",
                            "poller-start", "poller-stop",
                            "bot-start", "bot-stop"],
                   help="Bridge action to perform")
    p.add_argument("--project", metavar="ACRONYM",
                   help="Project acronym (required for 'test')")
    p.set_defaults(func=cmd_bridge)

    # -- backup --
    p = sub.add_parser("backup", help="Create or list project state backups")
    p.add_argument("--project", metavar="ACRONYM",
                   help="Filter to a specific project acronym (default: all)")
    p.add_argument("--output", metavar="PATH",
                   help="Output directory (default: ./admiralty-backups/)")
    p.add_argument("--list", action="store_true",
                   help="List available backups instead of creating one")
    p.set_defaults(func=cmd_backup)

    # -- restore --
    p = sub.add_parser("restore", help="Restore project state from a backup ZIP")
    p.add_argument("backup_file", metavar="BACKUP_FILE",
                   help="Path to the backup ZIP file")
    p.add_argument("--project", metavar="ACRONYM",
                   help="Restore only files for a specific project")
    p.add_argument("--force", action="store_true",
                   help="Overwrite existing files")
    p.add_argument("--merge", action="store_true",
                   help="Keep the newer file by modification time")
    p.add_argument("--dry-run", action="store_true",
                   help="Print what would be written without writing anything")
    p.set_defaults(func=cmd_restore)

    # -- sprint (canonical) / voyage (deprecated alias) --
    def _add_sprint_subparsers(p):
        sprint_sub = p.add_subparsers(dest="voyage_action", metavar="<action>")
        sprint_sub.required = True
        vp = sprint_sub.add_parser("create", help="Create a new sprint")
        vp.add_argument("title", nargs="+", help="Sprint title")
        vp.add_argument("--project", metavar="ACRONYM", required=True,
                        help="Project acronym (e.g. ADM, OTM)")
        vp = sprint_sub.add_parser("list", help="List active sprints")
        vp.add_argument("--project", metavar="ACRONYM", help="Filter by project acronym")
        vp = sprint_sub.add_parser("status", help="Show sprint details")
        vp.add_argument("voyage_id", metavar="VOY-ID", help="Sprint ID")

    p = sub.add_parser("sprint", help="Manage sprints",
                       formatter_class=argparse.RawDescriptionHelpFormatter,
                       epilog="""
actions:
  create  Create a new sprint and git branch
  list    List active sprints
  status  Show sprint details
        """)
    _add_sprint_subparsers(p)
    p.set_defaults(func=cmd_voyage)

    # -- voyage (deprecated alias for sprint) --
    p = sub.add_parser("voyage", help="[deprecated: use 'sprint'] Manage voyages",
                       formatter_class=argparse.RawDescriptionHelpFormatter,
                       epilog="""
actions:
  create  Create a new voyage and git branch
  list    List active voyages
  status  Show voyage details

examples:
  admiralty voyage create "Bridge v2 overhaul" --project ADM
  admiralty voyage list --project ADM
  admiralty voyage status VOY-ADM-2026-0001
        """)
    voyage_sub = p.add_subparsers(dest="voyage_action", metavar="<action>")
    voyage_sub.required = True

    vp = voyage_sub.add_parser("create", help="Create a new voyage")
    vp.add_argument("title", nargs="+", help="Voyage title")
    vp.add_argument("--project", metavar="ACRONYM", required=True,
                    help="Project acronym (e.g. ADM, OTM)")

    vp = voyage_sub.add_parser("list", help="List active voyages")
    vp.add_argument("--project", metavar="ACRONYM",
                    help="Filter by project acronym")

    vp = voyage_sub.add_parser("status", help="Show voyage details")
    vp.add_argument("voyage_id", metavar="VOY-ID", help="Voyage ID")

    p.set_defaults(func=cmd_voyage, _noun_deprecated="voyage")

    # -- bug --
    p = sub.add_parser("bug", help="Create a BUG order",
                       formatter_class=argparse.RawDescriptionHelpFormatter,
                       epilog="""
examples:
  admiralty bug "Login page crashes on mobile" --project ADM
        """)
    p.add_argument("title", nargs="+", help="Bug title")
    p.add_argument("--project", metavar="ACRONYM", required=True,
                   help="Project acronym (e.g. ADM, OTM)")
    p.set_defaults(func=cmd_bug)

    # -- security --
    p = sub.add_parser("security", help="Run OWASP/CWE security scanner",
                       formatter_class=argparse.RawDescriptionHelpFormatter,
                       epilog="""
subcommands:
  scan    Run the OWASP/CWE static analysis scanner

examples:
  admiralty security scan --order FTR-ADM-2026-0046
  admiralty security scan --voyage VOY-ADM-2026-0024
  admiralty security scan --since 2026-04-01
  admiralty security scan --json
  admiralty security scan --severity-threshold HIGH
        """)
    security_sub = p.add_subparsers(dest="security_action", metavar="<subcommand>")
    security_sub.required = True

    sp = security_sub.add_parser("scan", help="Scan files for OWASP/CWE vulnerabilities")
    sp.add_argument("--order", metavar="ORDER-ID",
                    help="Tag the resulting SEC-*.json report with this order ID. "
                         "Note: scans all crew-tracked modified files (per-order file tagging is not yet implemented).")
    sp.add_argument("--voyage", metavar="VOY-ID",
                    help="Tag the resulting report with this voyage ID. "
                         "Same caveat as --order — scans all crew-tracked modified files.")
    sp.add_argument("--since", metavar="DATE",
                    help="Scan files modified since this date (ISO format: YYYY-MM-DD)")
    sp.add_argument("--severity-threshold", metavar="LEVEL", default="INFO",
                    choices=["INFO", "LOW", "MEDIUM", "HIGH", "CRITICAL"],
                    help="Minimum severity to report (default: INFO)")
    sp.add_argument("--json", action="store_true",
                    help="Output results as JSON")
    sp.add_argument("--project", metavar="ACRONYM",
                    help="Workspace project acronym for registry lookup")

    p.set_defaults(func=cmd_security)

    # -- projects --
    p = sub.add_parser("projects", help="List or manage registered projects",
                       formatter_class=argparse.RawDescriptionHelpFormatter,
                       epilog="""
actions:
  list    Show all registered projects with paths
  remove  Unregister a project by acronym

examples:
  admiralty projects list
  admiralty projects remove PSG
        """)
    projects_sub = p.add_subparsers(dest="projects_action", metavar="<action>")
    projects_sub.required = True

    pp = projects_sub.add_parser("list", help="Show all registered projects")

    pp = projects_sub.add_parser("remove", help="Unregister a project")
    pp.add_argument("acronym", metavar="ACRONYM", help="Project acronym to remove (e.g. PSG)")

    p.set_defaults(func=cmd_projects)

    # -- update --
    p = sub.add_parser("update", help="Propagate schema updates to an existing workspace")
    p.add_argument("--dry-run", action="store_true",
                   help="Show changes without applying them")
    p.add_argument("--force", action="store_true",
                   help="Overwrite files that would otherwise be skipped")
    p.add_argument("--directory", metavar="PATH",
                   help="Workspace directory (default: current directory)")
    p.set_defaults(func=cmd_update)

    # -- hooks --
    p = sub.add_parser("hooks", help="Install or uninstall global Admiralty hooks",
                       formatter_class=argparse.RawDescriptionHelpFormatter,
                       epilog="""
actions:
  install    Write hook entries to ~/.claude/settings.json (idempotent)
  uninstall  Remove Admiralty hook entries from ~/.claude/settings.json

examples:
  admiralty hooks install
  admiralty hooks uninstall
        """)
    p.add_argument("hooks_action", metavar="<action>", choices=["install", "uninstall"],
                   help="Action to perform")
    p.set_defaults(func=cmd_hooks)

    # -- mcp --
    p = sub.add_parser("mcp", help="Manage the MCP server registry",
                       formatter_class=argparse.RawDescriptionHelpFormatter,
                       epilog="""
actions:
  list      List all registered servers with risk level and allowed roles
  show      Pretty-print full entry for one server
  add       Add a server entry (interactive flags or --json <file>)
  remove    Remove a server from the registry
  validate  Validate registry against JSON Schema and check env vars

examples:
  admiralty mcp list
  admiralty mcp show filesystem
  admiralty mcp add --name filesystem --command npx --allowed-roles "*" --risk-level low
  admiralty mcp add --name github --command npx --allowed-roles COX,QM --risk-level high --env-required GITHUB_TOKEN --description "GitHub API" --notes "COX/QM only"
  admiralty mcp add --json my-server.json
  admiralty mcp remove github
  admiralty mcp validate
    """)
    mcp_sub = p.add_subparsers(dest="mcp_action", metavar="<action>")
    mcp_sub.required = True

    mp = mcp_sub.add_parser("list", help="List all registered servers")
    mp.add_argument("--project", metavar="@PRJ", help="Registered project acronym")

    mp = mcp_sub.add_parser("show", help="Show full entry for one server")
    mp.add_argument("name", metavar="NAME", help="Server name")
    mp.add_argument("--project", metavar="@PRJ", help="Registered project acronym")

    mp = mcp_sub.add_parser("add", help="Add a server to the registry")
    mp.add_argument("--name", help="Server name (must match .claude/settings.json key)")
    mp.add_argument("--command", help="Executable name or full command")
    mp.add_argument("--args", action="append", metavar="ARG", help="CLI arg (repeatable)")
    mp.add_argument("--allowed-roles", metavar="ROLES", help="Comma-separated role codes or '*'")
    mp.add_argument("--risk-level", choices=["low", "medium", "high", "critical"],
                    help="Risk level (default: medium)")
    mp.add_argument("--env-required", action="append", metavar="VAR",
                    help="Required env var name (repeatable)")
    mp.add_argument("--description", help="Human-readable purpose")
    mp.add_argument("--notes", help="Operator notes or audit trail")
    mp.add_argument("--json", metavar="FILE", help="Import entry from a JSON file")
    mp.add_argument("--project", metavar="@PRJ", help="Registered project acronym")

    mp = mcp_sub.add_parser("remove", help="Remove a server from the registry")
    mp.add_argument("name", metavar="NAME", help="Server name to remove")
    mp.add_argument("--project", metavar="@PRJ", help="Registered project acronym")

    mp = mcp_sub.add_parser("validate", help="Validate registry and check env vars")
    mp.add_argument("--project", metavar="@PRJ", help="Registered project acronym")

    p.set_defaults(func=cmd_mcp)

    # -- identity --
    p = sub.add_parser("identity", help="Manage enterprise identity, groups, and ACL",
                       formatter_class=argparse.RawDescriptionHelpFormatter,
                       epilog="""
actions:
  init                     Seed .adm/identity/ with default groups and access.json
  add-user                 Enrol a new user
  add-group                Create a new group
  set-group                Add a user to a group
  remove-user              Remove a user from the identity store
  show                     Show effective capabilities for a user
  rights export EMAIL      Article 15 — export all data for a subject
  rights forget EMAIL      Article 17 — erasure dry-run plan (add --execute to apply)
  rights restrict EMAIL    Article 18 — restrict processing for a subject
  rights export-classification  Dump data-classification CSV for compliance audit
  acl list                 List ACL entries
  acl set                  Add an ACL entry
  acl remove               Remove an ACL entry

examples:
  admiralty identity init
  admiralty identity init --encryption git-crypt
  admiralty identity add-user --email alice@acme.com --display-name "Alice" --group captains
  admiralty identity add-group --name auditors
  admiralty identity set-group --email alice@acme.com --group fleet_operators
  admiralty identity show --email alice@acme.com
  admiralty identity rights export alice@acme.com
  admiralty identity rights forget alice@acme.com --dry-run
  admiralty identity rights restrict alice@acme.com
  admiralty identity acl list
  admiralty identity acl set --principal group:contributors --capability voyage.create --scope "*"
  admiralty identity acl remove --principal group:contributors --capability voyage.create --scope "*"
        """)
    p.add_argument("--project", metavar="@PRJ", help="Registered project acronym")
    id_sub = p.add_subparsers(dest="identity_action", metavar="<action>")
    id_sub.required = True

    ip = id_sub.add_parser("init", help="Seed identity store with defaults")
    ip.add_argument(
        "--encryption",
        choices=["git-crypt", "sops", "none"],
        default="none",
        help="Optional at-rest encryption for identity files (default: none)",
    )

    ip = id_sub.add_parser("rights", help="GDPR data-subject-rights tooling")
    rights_sub = ip.add_subparsers(dest="rights_action", metavar="<action>")
    rights_sub.required = True

    rp = rights_sub.add_parser("export", help="Article 15 — export all data for a subject")
    rp.add_argument("email", metavar="EMAIL", help="Data subject email address")

    rp = rights_sub.add_parser("forget", help="Article 17 — erasure plan (dry-run by default)")
    rp.add_argument("email", metavar="EMAIL", help="Data subject email address")
    rp.add_argument("--execute", action="store_true",
                    help="Execute identity-layer deletions (git history rewrite is still manual)")

    rp = rights_sub.add_parser("restrict", help="Article 18 — restrict processing for a subject")
    rp.add_argument("email", metavar="EMAIL", help="Data subject email address")

    rp = rights_sub.add_parser("export-classification", help="Export data-classification CSV for all user records")

    ip = id_sub.add_parser("add-user", help="Enrol a new user")
    ip.add_argument("--email", required=True, help="User email address")
    ip.add_argument("--display-name", required=True, dest="display_name", help="Display name")
    ip.add_argument("--group", action="append", metavar="GROUP", help="Group to add user to (repeatable)")
    ip.add_argument("--public-key", dest="public_key", metavar="PATH", help="Path to SSH Ed25519 public key file")

    ip = id_sub.add_parser("add-group", help="Create a new group")
    ip.add_argument("--name", required=True, help="Group name")

    ip = id_sub.add_parser("set-group", help="Add a user to a group")
    ip.add_argument("--email", required=True, help="User email address")
    ip.add_argument("--group", required=True, help="Group name")

    ip = id_sub.add_parser("remove-user", help="Remove a user")
    ip.add_argument("--email", required=True, help="User email address")

    ip = id_sub.add_parser("show", help="Show effective capabilities for a user")
    ip.add_argument("--email", help="User email (default: current caller)")

    ip = id_sub.add_parser("acl", help="Manage ACL entries")
    acl_sub = ip.add_subparsers(dest="acl_action", metavar="<action>")
    acl_sub.required = True

    ap = acl_sub.add_parser("list", help="List ACL entries")
    ap.add_argument("--principal", help="Filter by principal (e.g. group:captains)")

    ap = acl_sub.add_parser("set", help="Add an ACL entry")
    ap.add_argument("--principal", required=True, help="Principal (user:<email> or group:<name>)")
    ap.add_argument("--capability", required=True, help="Capability name")
    ap.add_argument("--scope", required=True, help="Scope (* | project:<acronym> | voyage:<id> | role:<code>)")

    ap = acl_sub.add_parser("remove", help="Remove an ACL entry")
    ap.add_argument("--principal", required=True, help="Principal")
    ap.add_argument("--capability", required=True, help="Capability name")
    ap.add_argument("--scope", required=True, help="Scope")

    ap = acl_sub.add_parser("show", help="Show the full effective ACL (alias for list)")
    ap.add_argument("--principal", help="Filter by principal (e.g. group:captains)")

    # -- identity user --
    ip = id_sub.add_parser("user", help="User management (add / remove / list)")
    user_sub = ip.add_subparsers(dest="user_action", metavar="<action>")
    user_sub.required = True

    up = user_sub.add_parser("add", help="Enrol a new user")
    up.add_argument("email", help="User email address")
    up.add_argument("--display-name", required=True, dest="display_name", help="Display name")
    up.add_argument("--public-key", dest="public_key", metavar="PATH", help="Path to SSH Ed25519 public key file")

    up = user_sub.add_parser("remove", help="Remove a user")
    up.add_argument("email", help="User email address")

    up = user_sub.add_parser("list", help="List all enrolled users")

    # -- identity group --
    ip = id_sub.add_parser("group", help="Group management (add / remove / list)")
    group_sub = ip.add_subparsers(dest="group_action", metavar="<action>")
    group_sub.required = True

    gp = group_sub.add_parser("add", help="Create a new group")
    gp.add_argument("name", help="Group name")
    gp.add_argument("--capabilities", metavar="CAP1,CAP2", help="Comma-separated capabilities to grant")
    gp.add_argument("--scope", default="*", help="Scope for the capability grants (default: *)")

    gp = group_sub.add_parser("remove", help="Remove a group and its ACL entries")
    gp.add_argument("name", help="Group name")

    gp = group_sub.add_parser("list", help="List all groups")

    # -- identity assign --
    ip = id_sub.add_parser("assign", help="Assign a user to a group")
    ip.add_argument("email", help="User email address")
    ip.add_argument("--to-group", required=True, dest="to_group", help="Target group name")

    p.set_defaults(func=cmd_identity)

    # -- audit --
    p = sub.add_parser("audit", help="Audit log operations",
                       formatter_class=argparse.RawDescriptionHelpFormatter,
                       epilog="""
actions:
  tail      Live-tail the audit log (default: last 20 lines then follow)
  verify    Walk the hash chain and return non-zero on tamper detection
  export    Dump entries to stdout in json, jsonl, or csv format
  anchor    Write current root hash to external immutable storage (enterprise only)

examples:
  admiralty audit tail
  admiralty audit tail --lines 50 --no-follow
  admiralty audit verify
  admiralty audit export --format csv --since 2026-01-01
  admiralty audit anchor --provider fs
  admiralty audit anchor --provider s3 --config /etc/adm/anchor-s3.json

scheduled anchoring (systemd):
  ExecStart=admiralty audit anchor --provider s3 --config /etc/adm/anchor-s3.json
  (add to a .timer unit — see admiralty docs anchor)
        """)
    p.add_argument("--project", metavar="@PRJ", help="Registered project acronym")
    audit_sub = p.add_subparsers(dest="audit_action", metavar="<action>")
    audit_sub.required = True

    ap = audit_sub.add_parser("tail", help="Live-tail the audit log")
    ap.add_argument("--lines", "-n", type=int, default=20, help="Lines to show before following (default: 20)")
    ap.add_argument("--no-follow", action="store_true", dest="no_follow", help="Print tail and exit (no follow)")

    ap = audit_sub.add_parser("verify", help="Verify the hash chain")

    ap = audit_sub.add_parser("export", help="Export audit entries")
    ap.add_argument("--since", metavar="DATE", help="Start date (ISO: YYYY-MM-DD)")
    ap.add_argument("--format", choices=["json", "jsonl", "csv"], default="jsonl",
                    help="Output format (default: jsonl)")

    ap = audit_sub.add_parser("anchor", help="Anchor current root hash to external immutable storage")
    ap.add_argument(
        "--provider", "-p",
        choices=["s3", "azure", "s3-compat", "fs"],
        default="fs",
        help="Anchor provider (default: fs — filesystem, dev/test only)",
    )
    ap.add_argument(
        "--config", metavar="FILE",
        help="JSON config file for provider (alternative to env vars)",
    )
    ap.add_argument(
        "--auto", action="store_true",
        help="Read provider and config from workspace.json audit settings (for cron/Task Scheduler use)",
    )

    p.set_defaults(func=cmd_audit)

    # -- data-flow --
    p = sub.add_parser("data-flow", help="Generate egress data-flow diagram (Mermaid or Graphviz)",
                       formatter_class=argparse.RawDescriptionHelpFormatter,
                       epilog="""
Generate a diagram of all outbound HTTP destinations this workspace calls.

Enterprise workspaces with dataResidency.allowedDestinations configured will
show only the allowlisted hosts.  Solo (permissive) workspaces show all
known static destinations (GitHub API, Slack, etc.).

workspace.json enterprise egress config example:
  {
    "enterprise": true,
    "dataResidency": {
      "mode": "restrictive",
      "allowedDestinations": ["api.github.com", "slack.com", "*.azure.com"]
    }
  }

examples:
  admiralty data-flow
  admiralty data-flow --format graphviz
  admiralty data-flow --output egress.md
  admiralty data-flow --project @ADM --output docs/data-flow.mmd
    """)
    p.add_argument("--format", choices=["mermaid", "graphviz"], default="mermaid",
                   help="Diagram format (default: mermaid)")
    p.add_argument("--mode", choices=["permissive", "restrictive", "air-gapped"],
                   metavar="MODE",
                   help="Override egress mode for rendering: permissive, restrictive, air-gapped")
    p.add_argument("--output", metavar="PATH",
                   help="Write diagram to this file (default: stdout)")
    p.add_argument("--project", metavar="@PRJ",
                   help="Registered project acronym (e.g. @ADM)")
    p.set_defaults(func=cmd_data_flow)

    # -- secrets --
    p = sub.add_parser("secrets", help="Secrets operator tooling",
                       formatter_class=argparse.RawDescriptionHelpFormatter,
                       epilog="""
actions:
  doctor  Verify every secret:// reference in workspace config resolves cleanly
  rotate  Kick a rotation workflow for a named key
  scrub   Scan config and logs for likely cleartext secrets
  list    List keys (never values) exposed by the active provider

exit codes:
  0  clean / success
  1  at least one finding or failure
  2  config error / missing argument

examples:
  admiralty secrets doctor
  admiralty secrets rotate --key MY_API_KEY
  admiralty secrets scrub
  admiralty secrets list
    """)
    secrets_sub = p.add_subparsers(dest="secrets_action", metavar="<action>")
    secrets_sub.required = True

    sp = secrets_sub.add_parser("doctor", help="Verify all secret:// refs resolve")
    sp.add_argument("--project", metavar="@PRJ", help="Registered project acronym")
    sp.set_defaults(func=cmd_secrets)

    sp = secrets_sub.add_parser("rotate", help="Kick rotation workflow for a key")
    sp.add_argument("--key", metavar="KEY", help="Secret key to rotate")
    sp.add_argument("--project", metavar="@PRJ", help="Registered project acronym")
    sp.set_defaults(func=cmd_secrets)

    sp = secrets_sub.add_parser("scrub", help="Scan for cleartext secrets in config and logs")
    sp.add_argument("--project", metavar="@PRJ", help="Registered project acronym")
    sp.set_defaults(func=cmd_secrets)

    sp = secrets_sub.add_parser("list", help="List secret keys (never values)")
    sp.add_argument("--project", metavar="@PRJ", help="Registered project acronym")
    sp.set_defaults(func=cmd_secrets)

    # -- licence --
    p = sub.add_parser(
        "licence",
        aliases=["license"],
        help="Manage your Admiralty licence (activate / status / deactivate)",
    )
    licence_sub = p.add_subparsers(dest="licence_cmd", metavar="<licence-cmd>", required=True)

    lp = licence_sub.add_parser("activate", help="Activate a licence key against Polar")
    lp.add_argument("key", nargs="?", help="Licence key (or set MAESTRO_LICENCE_KEY)")

    lp = licence_sub.add_parser("status", help="Show the locally-cached licence state")
    lp.add_argument("--json", action="store_true", help="Emit JSON instead of human text")

    lp = licence_sub.add_parser("deactivate", help="Drop the local licence record + keychain entry")

    lp = licence_sub.add_parser("revalidate", help="Force an online re-check now (ignore the 24h fast path)")
    lp.add_argument(
        "--offline-mark-stale",
        action="store_true",
        help=(
            "TEST ONLY: rewind last_validated_at to >24h ago so the next "
            "`adm` run exercises the offline-grace path. Refuses to run "
            "unless MAESTRO_LICENCE_TEST_FLAGS=1 is set in the operator "
            "shell. Used for FTR-0123 step 7 of the live-test plan."
        ),
    )

    p.set_defaults(func=cmd_licence)

    # -- config -- (FTR-ADM-2026-0129)
    p = sub.add_parser("config", help="Inspect Admiralty configuration (FTR-0129)")
    config_sub = p.add_subparsers(dest="config_action", required=True)

    cm = config_sub.add_parser(
        "models",
        help="Show the model assigned to each role (with override source)",
    )
    cm.set_defaults(func=cmd_config_models)

    # -- review --
    p = sub.add_parser(
        "review",
        help="Human review queue for NAV-paused orders",
        description=(
            "Manage orders paused for human review after NAV completes.\n"
            "Orders sit in .adm/queues/review/ until approved, revised, or rejected."
        ),
    )
    p.add_argument("--project", metavar="@PRJ", help="Registered project acronym")
    review_sub = p.add_subparsers(dest="review_action", metavar="<action>", required=True)

    rp = review_sub.add_parser("queue", help="List orders awaiting review")
    rp.set_defaults(func=lambda a: _cmd_review("queue", a))

    rp = review_sub.add_parser("show", help="Open the NAV plan in $EDITOR (or print to stdout)")
    rp.add_argument("order_id", metavar="ORDER-ID", help="Order to show")
    rp.add_argument("--editor", metavar="CMD", help="Editor command (overrides $EDITOR)")
    rp.set_defaults(func=lambda a: _cmd_review("show", a))

    rp = review_sub.add_parser("approve", help="Approve order and advance to next role")
    rp.add_argument("order_id", metavar="ORDER-ID", help="Order to approve")
    rp.set_defaults(func=lambda a: _cmd_review("approve", a))

    rp = review_sub.add_parser("revise", help="Send order back to NAV with revision notes")
    rp.add_argument("order_id", metavar="ORDER-ID", help="Order to revise")
    rp.add_argument("--notes", metavar="TEXT", help="Revision notes (required)")
    rp.set_defaults(func=lambda a: _cmd_review("revise", a))

    rp = review_sub.add_parser("reject", help="Reject order and archive as FAILED")
    rp.add_argument("order_id", metavar="ORDER-ID", help="Order to reject")
    rp.add_argument("--notes", metavar="TEXT", help="Rejection reason (required)")
    rp.set_defaults(func=lambda a: _cmd_review("reject", a))

    # -- version --
    p = sub.add_parser("version", help="Print version")
    p.set_defaults(func=cmd_version)

    # -- migrate-workspace --
    p = sub.add_parser(
        "migrate-workspace",
        help="Migrate .adm/ workspace to .mso/ (interactive, --dry-run, --resolve, --force)",
    )
    p.add_argument(
        "--dry-run",
        action="store_true",
        default=False,
        help="Show the migration plan without making any changes (exit 0)",
    )
    p.add_argument(
        "--force",
        action="store_true",
        default=False,
        help="Skip confirmation prompt (for scripted upgrades)",
    )
    p.add_argument(
        "--resolve",
        action="store_true",
        default=False,
        help="Handle split-brain: merge .adm/ into .mso/ with conflict skipping",
    )
    p.set_defaults(func=cmd_migrate_workspace)

    return parser


def main() -> None:
    invoke_name = Path(sys.argv[0]).stem
    if invoke_name in ("adm", "admiralty"):
        _warn_once(_CLI_MARKER, _CLI_WARNING)
    _check_env_deprecation(invoke_name)

    parser = build_parser()
    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
