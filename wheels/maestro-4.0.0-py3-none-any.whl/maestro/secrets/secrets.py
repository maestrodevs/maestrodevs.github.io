from __future__ import annotations

from pathlib import Path

from .base import SecretsProvider
from .registry import get_provider


def _audit(workspace: Path, action: str, key: str, result: str = "ok") -> None:
    """Fire-and-forget audit entry. Never raises."""
    try:
        from maestro.audit import get_audit_log
        get_audit_log(workspace).append(action=action, target=key, result=result)
    except Exception:
        pass


class Secrets:
    """
    ACL-gated, audit-logged facade over a SecretsProvider.

    Feature-gated behind workspace.json enterprise: true.
    When enterprise is false, ACL checks are skipped (pass-through).
    """

    def __init__(self, workspace: Path | None = None) -> None:
        if workspace is None:
            cwd = Path.cwd()
            for p in [cwd, *cwd.parents]:
                if (p / ".adm" / "config").is_dir():
                    workspace = p
                    break
            else:
                workspace = cwd
        self._workspace = workspace
        self._provider: SecretsProvider | None = None

    @property
    def provider(self) -> SecretsProvider:
        if self._provider is None:
            self._provider = get_provider(self._workspace)
        return self._provider

    def _gate(self, capability: str) -> None:
        from maestro.identity.gate import require_capability
        require_capability(capability, workspace=self._workspace)  # type: ignore[arg-type]

    def get(self, key: str) -> str | None:
        self._gate("secrets.read")
        value = self.provider.get(key)
        _audit(self._workspace, "secret.read", key)
        return value

    def set(self, key: str, value: str) -> None:
        self._gate("secrets.write")
        self.provider.set(key, value)
        _audit(self._workspace, "secret.write", key)

    def delete(self, key: str) -> None:
        self._gate("secrets.delete")
        self.provider.delete(key)
        _audit(self._workspace, "secret.delete", key)

    def list(self) -> list[str]:
        self._gate("secrets.list")
        keys = self.provider.list()
        _audit(self._workspace, "secret.list", "*")
        return keys
