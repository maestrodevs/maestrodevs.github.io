from __future__ import annotations

import json
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator

from .types import AuditEntry, GENESIS_HASH
from .signer import compute_hash, sign_entry, verify_signature
from .policy import AuditPolicyError, check_enterprise_anchor_policy, is_privileged_action


_DEFAULT_LOG_PATH = Path(".adm") / "audit" / "log.jsonl"

_lock = threading.Lock()


def _load_enterprise_flag(workspace: Path) -> bool:
    ws_cfg = workspace / ".adm" / "config" / "workspace.json"
    if not ws_cfg.exists():
        return False
    try:
        data = json.loads(ws_cfg.read_text(encoding="utf-8"))
        flag = data.get("enterprise", False)
        if isinstance(flag, bool):
            return flag
        if isinstance(flag, dict):
            return True
        return bool(flag)
    except Exception:
        return False


def _resolve_actor(workspace: Path) -> str:
    try:
        from maestro.identity.auth import resolve_caller
        return resolve_caller(workspace)
    except Exception:
        return "anonymous"


class AuditLog:
    """
    Hash-chained append-only audit log backed by a JSONL file.

    Feature-gated: when enterprise=false in workspace.json all writes
    are silently skipped (fail-open).
    """

    def __init__(self, workspace: Path, log_path: Path | None = None) -> None:
        self._workspace = workspace
        self._log_path = log_path or (workspace / _DEFAULT_LOG_PATH)
        # Raises AuditPolicyError when enterprise=true but no anchorProvider configured.
        check_enterprise_anchor_policy(workspace)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def append(
        self,
        action: str,
        target: str,
        result: str = "ok",
        metadata: dict[str, Any] | None = None,
        actor: str | None = None,
    ) -> AuditEntry | None:
        if not _load_enterprise_flag(self._workspace):
            return None
        try:
            self._check_anchor_freshness_gate(action)
            return self._append_locked(action, target, result, metadata or {}, actor)
        except AuditPolicyError:
            raise
        except Exception:
            return None

    def iterate(self, since: datetime | None = None) -> Iterator[AuditEntry]:
        if not self._log_path.exists():
            return
        with open(self._log_path, encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    entry = AuditEntry.from_dict(json.loads(line))
                except Exception:
                    continue
                if since is not None:
                    try:
                        ts = datetime.fromisoformat(entry.timestamp.replace("Z", "+00:00"))
                        if ts < since:
                            continue
                    except Exception:
                        pass
                yield entry

    def verify_chain(self) -> tuple[bool, list[str]]:
        """
        Walk the entire chain and verify hashes and (when possible) signatures.
        Returns (ok, errors).  errors is empty on success.
        """
        errors: list[str] = []
        prev_hash = GENESIS_HASH
        expected_seq = 1

        for entry in self.iterate():
            # Sequence continuity
            if entry.seq != expected_seq:
                errors.append(f"seq gap: expected {expected_seq}, got {entry.seq}")
            expected_seq = entry.seq + 1

            # prevHash linkage
            if entry.prev_hash != prev_hash:
                errors.append(
                    f"seq {entry.seq}: prevHash mismatch "
                    f"(expected {prev_hash[:16]}…, got {entry.prev_hash[:16]}…)"
                )

            # Recompute hash
            body = entry.to_dict()
            expected_hash = compute_hash(body)
            if entry.hash != expected_hash:
                errors.append(
                    f"seq {entry.seq}: hash mismatch — entry has been tampered with"
                )

            # Signature
            if not verify_signature(body, entry.signature, self._workspace):
                errors.append(f"seq {entry.seq}: signature invalid")

            prev_hash = entry.hash

        return (len(errors) == 0, errors)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _check_anchor_freshness_gate(self, action: str) -> None:
        """Write ANCHOR_OVERDUE to the lifecycle log and block privileged actions when the SLA is exceeded."""
        from .anchor.scheduler import check_anchor_freshness
        is_fresh, elapsed = check_anchor_freshness(self._workspace)
        if is_fresh:
            return
        # Write a single warning entry (guarded to avoid infinite recursion)
        if action != "audit.anchor_overdue":
            try:
                self._append_locked(
                    "audit.anchor_overdue",
                    "lifecycle",
                    "warning",
                    {"elapsedMinutes": round(elapsed, 1)},
                    "system",
                )
            except Exception:
                pass
        if is_privileged_action(action):
            raise AuditPolicyError(
                f"Anchor SLA exceeded ({elapsed:.0f} min since last anchor). "
                "Run 'adm audit anchor --auto' to resume privileged operations."
            )

    def _append_locked(
        self,
        action: str,
        target: str,
        result: str,
        metadata: dict[str, Any],
        actor: str | None,
    ) -> AuditEntry:
        with _lock:
            self._log_path.parent.mkdir(parents=True, exist_ok=True)

            prev_hash, seq = self._tail_state()

            if actor is None:
                actor = _resolve_actor(self._workspace)

            entry = AuditEntry(
                seq=seq,
                timestamp=datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z",
                actor=actor,
                action=action,
                target=target,
                result=result,
                metadata=metadata,
                prev_hash=prev_hash,
            )

            body = entry.to_dict()
            entry.hash = compute_hash(body)
            body["hash"] = entry.hash
            entry.signature = sign_entry(body, self._workspace)
            body["signature"] = entry.signature

            with open(self._log_path, "a", encoding="utf-8") as fh:
                fh.write(json.dumps(body, separators=(",", ":")) + "\n")

            return entry

    def _tail_state(self) -> tuple[str, int]:
        """Return (last_hash, next_seq) by reading the last line of the log."""
        if not self._log_path.exists():
            return GENESIS_HASH, 1
        last_line = ""
        with open(self._log_path, "rb") as fh:
            fh.seek(0, 2)
            size = fh.tell()
            if size == 0:
                return GENESIS_HASH, 1
            # scan backwards for last non-empty line
            pos = size - 1
            buf = b""
            while pos >= 0:
                fh.seek(pos)
                ch = fh.read(1)
                if ch == b"\n" and buf:
                    break
                buf = ch + buf
                pos -= 1
            last_line = buf.decode("utf-8", errors="replace").strip()

        if not last_line:
            return GENESIS_HASH, 1

        try:
            d = json.loads(last_line)
            return d.get("hash", GENESIS_HASH), d.get("seq", 0) + 1
        except Exception:
            return GENESIS_HASH, 1


def get_audit_log(workspace: Path) -> AuditLog:
    return AuditLog(workspace)
