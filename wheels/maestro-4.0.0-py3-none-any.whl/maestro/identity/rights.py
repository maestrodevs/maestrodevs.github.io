"""
Data-subject-rights tooling — FTR-ADM-2026-0071 (V6 LKT HIGH GDPR).

Implements GDPR Articles 15, 16, 17, 18 tooling:
  - export  (Art. 15 — right of access)
  - forget  (Art. 17 — right to erasure, dry-run plan only; history rewrite is manual)
  - restrict (Art. 18 — right to restriction)

All three operations write audit entries and are gated behind enterprise mode.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def rights_export(email: str, workspace: Path) -> dict:
    """
    Article 15 — right of access.
    Returns a JSON-serialisable dict of every reference to *email* across:
      .adm/identity/users/  .adm/identity/groups/  .adm/audit/log.jsonl
      .adm/orders/  .adm/voyages/
    """
    identity_dir = workspace / ".adm" / "identity"
    report: dict = {
        "subject": email,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "gdpr_basis": "Article 15 — Right of Access",
        "identity_record": None,
        "group_memberships": [],
        "audit_entries": [],
        "order_references": [],
        "voyage_references": [],
    }

    # Identity record
    user_path = identity_dir / "users" / f"{email}.json"
    if user_path.exists():
        try:
            report["identity_record"] = json.loads(user_path.read_text(encoding="utf-8"))
        except Exception:
            pass

    # Group memberships
    groups_dir = identity_dir / "groups"
    if groups_dir.exists():
        for p in sorted(groups_dir.glob("*.json")):
            try:
                grp = json.loads(p.read_text(encoding="utf-8"))
                if email in grp.get("members", []):
                    report["group_memberships"].append(grp.get("name", p.stem))
            except Exception:
                continue

    # Audit entries referencing the email
    audit_log = workspace / ".adm" / "audit" / "log.jsonl"
    if audit_log.exists():
        try:
            with audit_log.open(encoding="utf-8") as fh:
                for line in fh:
                    line = line.strip()
                    if not line:
                        continue
                    if email not in line:
                        continue
                    try:
                        entry = json.loads(line)
                        report["audit_entries"].append(entry)
                    except Exception:
                        continue
        except Exception:
            pass

    # Orders referencing the email
    for order_root in [workspace / ".adm" / "orders" / sub for sub in ("active", "complete", "failed")]:
        if not order_root.exists():
            continue
        for p in sorted(order_root.glob("*.json")):
            try:
                text = p.read_text(encoding="utf-8")
                if email in text:
                    report["order_references"].append(str(p.relative_to(workspace)))
            except Exception:
                continue

    # Voyages referencing the email
    for voy_root in [workspace / ".adm" / "voyages" / sub for sub in ("active", "complete")]:
        if not voy_root.exists():
            continue
        for p in sorted(voy_root.glob("*.json")):
            try:
                text = p.read_text(encoding="utf-8")
                if email in text:
                    report["voyage_references"].append(str(p.relative_to(workspace)))
            except Exception:
                continue

    _append_rights_audit(workspace, "identity.rights.export", email, "ok", {})
    return report


def rights_forget(email: str, workspace: Path, dry_run: bool = True) -> dict:
    """
    Article 17 — right to erasure.
    When dry_run=True (default): returns a deletion plan without modifying anything.
    When dry_run=False: executes identity-layer deletion only.

    NOTE: git history rewrite (BFG / git filter-repo) is NOT automated.
    The plan includes documented manual steps.
    """
    identity_dir = workspace / ".adm" / "identity"
    plan: dict = {
        "subject": email,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "gdpr_basis": "Article 17 — Right to Erasure",
        "dry_run": dry_run,
        "identity_deletions": [],
        "group_modifications": [],
        "audit_redactions": [],
        "manual_steps": [],
        "warnings": [],
        "executed": False,
    }

    # Identity file
    user_path = identity_dir / "users" / f"{email}.json"
    if user_path.exists():
        plan["identity_deletions"].append(str(user_path.relative_to(workspace)))

    # Group membership removals
    groups_dir = identity_dir / "groups"
    if groups_dir.exists():
        for p in sorted(groups_dir.glob("*.json")):
            try:
                grp = json.loads(p.read_text(encoding="utf-8"))
                if email in grp.get("members", []):
                    plan["group_modifications"].append({
                        "file": str(p.relative_to(workspace)),
                        "action": f"remove {email!r} from members list",
                    })
            except Exception:
                continue

    # Audit log redactions (plan only — never modifies the chain)
    audit_log = workspace / ".adm" / "audit" / "log.jsonl"
    if audit_log.exists():
        try:
            with audit_log.open(encoding="utf-8") as fh:
                for line in fh:
                    line = line.strip()
                    if email in line:
                        try:
                            entry = json.loads(line)
                            plan["audit_redactions"].append({
                                "seq": entry.get("seq"),
                                "action": entry.get("action"),
                                "note": (
                                    "Replace actor field with tombstone hash; "
                                    "re-sign; verify_chain must still pass. "
                                    "New entry type: identity.forget"
                                ),
                            })
                        except Exception:
                            continue
        except Exception:
            pass

    # Manual steps for complete erasure
    plan["manual_steps"] = [
        "1. Run: adm identity rights forget <email>  (without --dry-run) to remove identity files.",
        "2. Redact audit entries manually as documented in audit_redactions above.",
        "3. To remove the email from git history use one of:",
        "   a. BFG Repo Cleaner: bfg --replace-text replacements.txt <repo.git>",
        "   b. git filter-repo: git filter-repo --replace-text replacements.txt",
        "   NOTE: Both require re-cloning by all team members and are irreversible.",
        "4. Force-push the rewritten history (requires enterprise git admin privileges).",
        "5. Notify all repo cloners to delete and re-clone.",
    ]
    plan["warnings"].append(
        "Git history rewrite is disruptive and often blocked by enterprise git policy. "
        "Consider pseudonymisation (replace with a UUID) as an alternative to full erasure."
    )

    if not dry_run:
        # Execute identity-layer deletions
        if user_path.exists():
            user_path.unlink()
            from .integrity import remove_from_manifest
            remove_from_manifest(user_path, identity_dir)

        # Remove from groups
        for mod in plan["group_modifications"]:
            p = workspace / mod["file"]
            try:
                grp = json.loads(p.read_text(encoding="utf-8"))
                grp["members"] = [m for m in grp.get("members", []) if m != email]
                p.write_text(json.dumps(grp, indent=2), encoding="utf-8")
                from .integrity import update_manifest
                update_manifest(p, identity_dir)
            except Exception:
                pass

        plan["executed"] = True
        _append_rights_audit(workspace, "identity.rights.forget", email, "ok", {"dry_run": False})
    else:
        _append_rights_audit(workspace, "identity.rights.forget", email, "ok", {"dry_run": True})

    return plan


def rights_restrict(email: str, workspace: Path) -> dict:
    """
    Article 18 — right to restriction.
    Flags the user as restricted in their identity record.
    The capability resolver (gate.py) will refuse any new operations for this identity.
    Historical audit entries remain readable.
    """
    identity_dir = workspace / ".adm" / "identity"
    users_dir = identity_dir / "users"
    user_path = users_dir / f"{email}.json"

    if not user_path.exists():
        return {
            "subject": email,
            "result": "not_found",
            "message": f"No identity record found for {email!r}.",
        }

    data = json.loads(user_path.read_text(encoding="utf-8"))
    data.setdefault("_meta", {})
    data["_meta"]["restricted"] = True
    data["_meta"]["restricted_at"] = datetime.now(timezone.utc).isoformat()
    user_path.write_text(json.dumps(data, indent=2), encoding="utf-8")

    from .integrity import update_manifest
    update_manifest(user_path, identity_dir)

    _append_rights_audit(workspace, "identity.rights.restrict", email, "ok", {})
    return {
        "subject": email,
        "result": "restricted",
        "message": f"User {email!r} is now restricted. The capability resolver will deny all new operations.",
    }


def is_restricted(email: str, workspace: Path) -> bool:
    """Return True if the user has been flagged as restricted."""
    user_path = workspace / ".adm" / "identity" / "users" / f"{email}.json"
    if not user_path.exists():
        return False
    try:
        data = json.loads(user_path.read_text(encoding="utf-8"))
        return bool(data.get("_meta", {}).get("restricted", False))
    except Exception:
        return False


# ---------------------------------------------------------------------------
# Data-classification helpers
# ---------------------------------------------------------------------------

DEFAULT_PERSONAL_DATA_FIELDS = ["email", "displayName"]


def personal_data_fields(record: dict) -> list[str]:
    """Return the list of personal-data fields from a user record's _meta, or the default."""
    return record.get("_meta", {}).get("dataClassification", DEFAULT_PERSONAL_DATA_FIELDS)


def export_classification_csv(workspace: Path) -> str:
    """Return a CSV of (file, field, classification) for all user records."""
    identity_dir = workspace / ".adm" / "identity" / "users"
    rows = ["file,field,classification"]
    if not identity_dir.exists():
        return "\n".join(rows)
    for p in sorted(identity_dir.glob("*.json")):
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
            personal = personal_data_fields(data)
            rel = str(p.relative_to(workspace))
            for field in data:
                if field.startswith("_"):
                    continue
                cls = "personal_data" if field in personal else "operational"
                rows.append(f"{rel},{field},{cls}")
        except Exception:
            continue
    return "\n".join(rows)


# ---------------------------------------------------------------------------
# Internal audit helper
# ---------------------------------------------------------------------------

def _append_rights_audit(workspace: Path, action: str, target_email: str, result: str, metadata: dict) -> None:
    try:
        from maestro.audit import get_audit_log
        get_audit_log(workspace).append(action, target=f"identity/users/{target_email}", result=result, metadata=metadata)
    except Exception:
        pass
