# Chain of Command — Maestro

> **v4.0 note:** The chain of command was previously described in a 4-layer nautical model (Captain → Quartermaster → Fleet Admiral → Crews). This document reflects the current 3-layer model using role-neutral terminology, with a nautical-persona callout section for operators using the built-in nautical theme.

---

## The 3-Layer Chain

```
Human (You)  →  LEAD (Claude, interactive)  →  Dispatcher (mso dispatch)  →  Squads
```

| Layer | Who | What they do |
|-------|-----|-------------|
| **Human** | You, the operator | Sets direction, approves PRs, makes go/no-go decisions |
| **LEAD** | Claude (interactive session) | Your AI partner in the main session — plans work, delegates to squads, reviews output |
| **Dispatcher** | `mso dispatch` | Automation layer that launches and manages squad lifecycle |
| **Squads** | Autonomous Claude agents | Execute individual orders (tasks) in isolated sessions |

### Roles (Canonical)

| Code | Name | Responsibility | Model |
|------|------|---------------|-------|
| PLN | Planner | Planning, architecture, requirements analysis | Sonnet 4.6 |
| BLD | Builder | Implementation, feature development, bug fixes | Sonnet 4.6 |
| TST | Tester | QA, testing, acceptance criteria validation | Sonnet 4.6 |
| DOC | Docs writer | Documentation, changelogs, guides | Sonnet 4.6 |
| SEC | Security reviewer | Security audit, vulnerability scanning, investigation | Haiku 4.5 |
| REL | Releaser | Integration, CI/CD, deployment, release gates | Opus 4.7 |
| LEAD | Lead | Interactive partner role — plans, delegates, advises | (interactive) |

Legacy role codes (from the v2.x era) are retained as aliases: NAV=PLN, SHP=BLD, BOS=TST, SCR=DOC, LKT=SEC, COX=REL, QM=LEAD.

---

## Responsibilities at Each Layer

### Human

- Defines what needs to happen (requirements, high-level goals)
- Approves plans before significant work begins
- Reviews pull requests and merge gates
- Makes go/no-go decisions on releases
- Has full override authority at any point

### LEAD (interactive Claude session)

The LEAD is your AI partner in the main Claude Code session. Unlike squad members (which are autonomous), the LEAD is interactive — you direct it in real time.

**What LEAD does:**
- Reads the current sprint backlog and order queue
- Decomposes requirements into orders and assigns roles
- Creates order JSON files and voyage/sprint records
- Monitors squad output and synthesises results
- Flags blockers or decisions that need human input
- Writes handoff context for squads to pick up

**What LEAD does NOT do:**
- LEAD does not directly write production code (it delegates to BLD squads)
- LEAD does not approve its own plans (Human approves)
- LEAD does not merge PRs (REL squads handle this, with Human approval)

### Dispatcher (`mso dispatch`)

The dispatcher is the automation layer that converts the order queue into running squad processes.

**What it does:**
- Reads orders from `.mso/queues/orders/` and `.adm/orders/active/`
- Resolves dependency ordering (an order with `dependsOn` waits for its dependencies)
- Launches up to `--max-crews N` squad processes in parallel (default: 5)
- Injects role-specific system prompts, persona context, and environment variables
- Monitors squad lifecycle; promotes completed orders to `.adm/orders/complete/`
- Enforces branch discipline — each squad runs in the correct git worktree

### Squads (autonomous Claude agents)

Squads are independent Claude Code sessions, each executing a single order.

**Characteristics:**
- One order → one squad → one session
- Each squad runs in its own git worktree (parallel sprint support)
- Squad context is injected at launch: role prompt + persona + order JSON + handoff docs
- Squads write outputs to the workspace (code, tests, docs, reports) and handoff documents
- Squads cannot spawn other squads; only the dispatcher does that

---

## Information Flow

```
Human writes requirement
    ↓
LEAD decomposes into orders
    ↓
Orders land in .mso/queues/orders/
    ↓
Dispatcher picks up orders (mso dispatch)
    ↓
Squads execute in parallel (up to 5)
    ↓
Each squad writes output + handoff doc
    ↓
Dispatcher promotes order to complete/
    ↓
LEAD reads results and synthesises
    ↓
REL squad opens PR / closes sprint
    ↓
Human reviews and approves merge
```

---

## Persona-Aware Sub-Sections

Maestro ships with a built-in **nautical persona** that maps the chain of command to seafaring roles. When the nautical persona is active (the default), the terminology shifts:

| Canonical term | Nautical persona |
|---------------|-----------------|
| Human (operator) | Captain |
| LEAD | Quartermaster |
| Dispatcher | Fleet Admiral |
| Squad | Crew |
| Sprint | Voyage |
| Order | Order (unchanged) |

The underlying mechanics are identical — only the vocabulary changes. All documentation, CLI output, and role prompts are rendered through the active persona at runtime.

**In the nautical persona, the chain reads:**

```
Captain (You)  →  Quartermaster (Claude)  →  Fleet Admiral (mso dispatch)  →  Crews
```

To configure or switch personas, see [docs/PERSONAS.md](PERSONAS.md).

---

## Comparison: Old 4-Layer vs Current 3-Layer

Prior to v3.0.0 (the Maestro rebrand), the chain of command was documented as 4 layers:

```
Captain → Quartermaster → Fleet Admiral → Crews (up to 5)
```

This was actually still a 3-layer architecture — the "up to 5 Crews" was describing parallelism within the dispatcher layer, not a separate command layer. The v3.0.0 documentation makes this explicit. Nothing changed architecturally; the description became more accurate.

---

## Gates and Approvals

Maestro supports optional **human review gates** between role transitions, configurable via `.adm/config/gates.json`. Common gates:

| Gate | Default | Description |
|------|---------|-------------|
| PLN → BLD | optional | Human reviews PLN plan before BLD starts implementation |
| BLD → TST | off | TST starts automatically after BLD completes |
| TST → REL | optional | Human reviews TST report before REL creates the PR |
| REL → merge | **required** | Human explicitly approves PR before REL merges |

The PR merge gate is always required — Maestro never auto-merges without explicit human approval.

See [docs/HUMAN-REVIEW-GATES.md](HUMAN-REVIEW-GATES.md) for the full configuration reference.

---

## Branch Discipline

Each sprint runs on a dedicated git branch. The dispatcher enforces this:

1. `voyageBranch` on every order JSON is load-bearing — the dispatcher checks out the correct branch before launching the squad
2. The pretool branch guard (`maestro/hooks/branch_guard.py`) denies any git/gh mutation that targets a branch other than `$MAESTRO_VOYAGE_BRANCH`
3. Multiple sprints run safely in parallel because each uses its own git worktree

See [docs/BRANCH-DISCIPLINE.md](BRANCH-DISCIPLINE.md) for the operator reference.
