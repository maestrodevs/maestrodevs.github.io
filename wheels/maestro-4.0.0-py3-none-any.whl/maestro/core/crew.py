#!/usr/bin/env python3
"""
Maestro - Crew Execution Engine v2.0.0 (Python)

Role-aware autonomous execution engine for crew members with self-organizing capabilities.
Spawns a Claude Code CLI instance per order with role-based model selection and
hook-based iteration control (Ralph Wiggum pattern).

v2.0.5 Feature:
  - MULTI-PROJECT SUPPORT: Project acronym injected via MAESTRO_PROJECT env var.
    Crews resolve project-specific config at runtime from config/projects/{acronym}.json.

v2.0.1 Feature:
  - MANAGED REPO CWD: When MAESTRO_REPO_PATH is set by fleet-runner, crew.py uses
    the pre-cloned repo as the Claude CLI working directory. Falls back to workspace
    root if the path doesn't exist (crew self-manages).

v8.3 Feature:
  - ROLE-BASED MODEL SELECTION: Each role gets the optimal Claude model.
    COX → Opus 4.7 (critical review), NAV/SHP/BOS/SCR → Sonnet 4.6, LKT → Haiku 4.5
    Configured via ROLE_MODELS dict. Logged at invocation time.

v8.2 Fix:
  - TIMEOUT-COMPLETE RACE: When subprocess times out due to lingering background
    bash processes, check ralph-state before declaring TIMEOUT. If stop hook already
    detected <promise>COMPLETE</promise>, honour COMPLETE status instead of re-queuing.

v8.0 Features:
  - STOP HOOK ITERATION CONTROL: Uses python -m admiralty.hooks.stop (Ralph Wiggum pattern)
  - Single Claude invocation — hook intercepts exit, re-feeds prompts for multi-pass
  - Per-crew ralph-state.md tracks iteration count, status, completion
  - Environment variables (MAESTRO_CREW, MAESTRO_ORDER, etc.) isolate crew sessions
  - Captain's interactive sessions are NEVER affected (hook checks env vars)

v7.3 Features:
  - TIMEOUT BRIEFING: On timeout, captures iteration count, artifacts, partial output
  - Brief stored in crew state, appended to order JSON on re-queue
  - Next crew sees "Previous Attempts" section in prompt

v6.0 Features:
  - NO CLI LOCK: Crews run as fully detached independent processes (no mutex needed)
  - Launched by fleet-runner with DETACHED_PROCESS + CREATE_NEW_PROCESS_GROUP
  - Restores 5-crew concurrent capability

v5.0-5.1 Features:
  - Self-organizing crews: Can create bugs, requests, and breakdowns
  - Role permissions: Each role has specific creation/request permissions
  - Queue integration: Work items placed in .adm/queues/
  - PLANNING REQUESTS: LKT can request NAV to plan based on investigation findings

Usage:
    python crew.py --crew 1 --role LKT --order INV-2026-0001 --prompt path/to/prompt.md

    # Status & cleanup
    python crew.py --crew 1 --status
    python crew.py --crew 1 --cleanup
"""

import argparse
import io
import json
import os
import re
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, Any

# Fix Windows console encoding and buffering
if sys.platform == 'win32':
    # Set UTF-8 mode for stdout/stderr with line buffering for immediate output
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace', line_buffering=True)
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace', line_buffering=True)


def log(msg: str):
    """Print with immediate flush for visibility in subprocess."""
    print(msg, flush=True)

# ============================================================================
# CONFIGURATION
# ============================================================================

# v2.0.5: Multi-project support — project acronym from fleet-runner env injection
PROJECT_ACRONYM = os.environ.get("MAESTRO_PROJECT", "OTM")

# Squad names and role-model IDs are persona-driven — see maestro/core_constants.py
from maestro.workspace import get_workspace_dir  # noqa: E402
from maestro.core_constants import (  # noqa: E402
    get_squad_name,
    get_role_model_id,
    DEFAULT_ROLE_MODEL_IDS as _CANONICAL_ROLE_MODELS,
)

# v3.0.1 back-compat (FTR-MSO-2026-0168 moved the role-model dict to
# maestro.core_constants). Re-exposed here keyed on legacy role codes so
# existing test suites and external consumers of admiralty.core.crew
# continue to work. Single source of truth lives in core_constants.
_LEGACY_TO_CANONICAL_ROLE = {
    "NAV": "PLN", "SHP": "BLD", "BOS": "TST", "SCR": "DOC",
    "LKT": "SEC", "COX": "REL", "QM": "LEAD",
}
def _build_role_models() -> dict[str, str]:
    """Build legacy+canonical role-model mapping for back-compat consumers."""
    m = {
        legacy: _CANONICAL_ROLE_MODELS[canonical]
        for legacy, canonical in _LEGACY_TO_CANONICAL_ROLE.items()
    }
    m.update(_CANONICAL_ROLE_MODELS)
    return m

# Back-compat export — single source of truth is maestro.core_constants.
ROLE_MODELS: dict[str, str] = _build_role_models()

ROLE_INFO = {
    "NAV": {"name": "Navigator", "focus": "Planning & Architecture"},
    "SHP": {"name": "Shipwright", "focus": "Development & Implementation"},
    "BOS": {"name": "Bosun", "focus": "Quality Assurance & Testing"},
    "SCR": {"name": "Scribe", "focus": "Documentation"},
    "LKT": {"name": "Lookout", "focus": "Security & Investigation"},
    "COX": {"name": "Coxswain", "focus": "Integration & Deployment"}
}

# v7.0: Role Permissions Matrix - Self-Organizing Crews
# NOTE: All roles can escalate (Captain's directive) — no permission check needed for escalations
# v8.4: repo_write controls which repos each role may create/modify files in.
#   "target"  = the service/API repo specified by the order's targetRepo
#   "docs"    = documentation repo
#   "admiralty" = .adm/ directory (reports, handoffs, queues) — always allowed
ROLE_PERMISSIONS = {
    "NAV": {
        "can_create": ["orders", "bugs"],
        "can_request": ["investigation", "qa"],
        "can_breakdown": True,
        "repo_write": ["target", "docs"]  # NAV plans touch both
    },
    "SHP": {
        "can_create": ["bugs"],
        "can_request": ["investigation", "qa"],
        "can_breakdown": False,
        "repo_write": ["target"]  # SHP writes code to target repo ONLY
    },
    "BOS": {
        "can_create": ["bugs", "defects"],
        "can_request": ["investigation"],
        "can_breakdown": False,
        "repo_write": ["target"]  # BOS writes tests to target repo ONLY
    },
    "SCR": {
        "can_create": ["bugs"],
        "can_request": ["investigation", "qa"],
        "can_breakdown": False,
        "repo_write": ["docs"]  # SCR writes documentation ONLY
    },
    "LKT": {
        "can_create": ["bugs", "orders", "security"],
        "can_request": ["planning"],  # LKT can request NAV to plan based on findings
        "can_breakdown": True,
        "repo_write": ["docs"]  # LKT writes reports to docs repo ONLY — never touch code repos
    },
    "COX": {
        "can_create": ["bugs", "orders"],
        "can_request": ["investigation"],
        "can_breakdown": True,
        "repo_write": ["target", "docs"]  # COX reviews may annotate both
    }
}

# v8.3 / FTR-MSO-2026-0168: Role-model IDs moved to maestro/core_constants.py
# (DEFAULT_ROLE_MODEL_IDS). resolve_model_for() uses get_role_model_id() as
# the built-in default layer so canonical + legacy codes are both handled.
DEFAULT_MODEL = "claude-sonnet-4-6"

# v2.5.6 (FTR-ADM-2026-0129): set of model IDs Admiralty has cost-tracking
# pricing for. Used to validate operator overrides — unknown IDs raise so a
# typo doesn't silently dispatch against a model the usage tracker can't price.
SUPPORTED_MODELS = {
    "claude-opus-4-7",
    "claude-opus-4-6",
    "claude-sonnet-4-6",
    "claude-haiku-4-5-20251001",
}


def _load_workspace_role_models() -> dict:
    """Read .adm/config/role-models.json if present.

    Schema: {"models": {"SHP": "claude-opus-4-7", ...}}
    Returns {} if missing/unreadable.
    """
    try:
        cfg = get_workspace_dir() / "config" / "role-models.json"
        if not cfg.exists():
            return {}
        data = json.loads(cfg.read_text(encoding="utf-8"))
        return data.get("models", {}) if isinstance(data, dict) else {}
    except Exception:
        return {}


def _validate_model_id(model_id: str, source: str) -> str:
    """Reject unknown model IDs with a clear error pointing at the supported list."""
    if model_id not in SUPPORTED_MODELS:
        supported = ", ".join(sorted(SUPPORTED_MODELS))
        raise ValueError(
            f"Unknown model '{model_id}' (from {source}). "
            f"Admiralty does not have cost-tracking pricing for this ID and refuses "
            f"to dispatch against it. Supported: {supported}. "
            f"To add a new model, update SUPPORTED_MODELS + PRICING in admiralty/core/."
        )
    return model_id


def _load_order_data_for(order_id: str) -> dict:
    """Look up an order's JSON across all known queue + active locations.

    FTR-0129: needed so resolve_model_for() can apply per-order `model`
    overrides from anywhere a dispatcher hands the crew an order_id.
    Returns {} when not found or unreadable.

    Copilot review: covers every queue scanned by fleet_runner.scan_all_queues
    plus orders/active|complete|failed. A malformed JSON in one location
    doesn't end the search — the next candidate still gets a chance.
    """
    if not order_id:
        return {}
    try:
        adm = get_workspace_dir()
    except Exception:
        return {}
    queues = (
        "orders", "explicit", "bugs", "security",
        "defects", "requests", "breakdown", "high-level",
        "escalations", "proposed",
    )
    candidates = [adm / "queues" / q / f"{order_id}.json" for q in queues]
    candidates.extend([
        adm / "orders" / "active" / f"{order_id}.json",
        adm / "orders" / "complete" / f"{order_id}.json",
        adm / "orders" / "failed" / f"{order_id}.json",
    ])
    for path in candidates:
        if path.exists():
            try:
                return json.loads(path.read_text(encoding="utf-8"))
            except Exception:
                # Malformed copy in one location — keep scanning. Same order
                # may exist verifiably in another queue.
                continue
    return {}


def resolve_model_for(role: str, order_data: dict | None = None) -> str:
    """Resolve the Claude model for a (role, order) pair.

    FTR-ADM-2026-0129: three-layer override chain, highest priority first:
      1. Per-order override        — order JSON `model` field
      2. Workspace config          — .adm/config/role-models.json
      3. Env var                   — MAESTRO_MODEL_<ROLE> (uppercase)
      4. Built-in ROLE_MODELS dict — falls back to DEFAULT_MODEL

    Unknown model IDs at any layer raise ValueError. Operators see the
    misconfiguration immediately rather than dispatching against a model
    the usage tracker can't price.
    """
    # 1. Per-order override
    if order_data:
        order_model = order_data.get("model", "")
        if order_model:
            return _validate_model_id(order_model, f"order.model for {role}")

    # 2. Workspace config
    workspace_models = _load_workspace_role_models()
    if role in workspace_models and workspace_models[role]:
        return _validate_model_id(
            workspace_models[role],
            f".adm/config/role-models.json[{role}]",
        )

    # 3. Env var (case-insensitive role lookup, uppercase env name)
    env_var = f"MAESTRO_MODEL_{role.upper()}"
    env_model = os.environ.get(env_var, "")
    if env_model:
        return _validate_model_id(env_model, f"${env_var}")

    # 4. Built-in default
    return get_role_model_id(role)

# v7.0: Queue depth limits to prevent runaway queue growth
MAX_QUEUE_DEPTH = {
    "bugs": 50,
    "defects": 20,
    "security": 10,
    "breakdown": 30,
    "escalations": 20
}

# v7.0: Per-crew creation rate limit — max items a single crew can create per order execution
MAX_CREW_ITEMS_PER_ORDER = 10

# ============================================================================
# PATH HELPERS
# ============================================================================

def get_base_dir() -> Path:
    """Get the project base directory."""
    return get_workspace_dir().parent

def get_crew_dir(crew_number: int) -> Path:
    """Get the crew's working directory."""
    suffix = "" if crew_number == 1 else str(crew_number)
    return get_workspace_dir() / f"crews/crew{crew_number}"

def ensure_crew_dir(crew_number: int) -> Path:
    """Ensure crew directory exists and return it."""
    crew_dir = get_crew_dir(crew_number)
    crew_dir.mkdir(parents=True, exist_ok=True)
    return crew_dir

# ============================================================================
# STATE MANAGEMENT
# ============================================================================

def read_state(crew_number: int) -> Optional[Dict[str, Any]]:
    """Read crew state from state.json."""
    state_file = get_crew_dir(crew_number) / "state.json"
    if state_file.exists():
        try:
            return json.loads(state_file.read_text(encoding='utf-8'))
        except:
            return None
    return None

def write_state(crew_number: int, state: Dict[str, Any]):
    """Write crew state to state.json."""
    crew_dir = ensure_crew_dir(crew_number)
    state_file = crew_dir / "state.json"
    state_file.write_text(json.dumps(state, indent=2), encoding='utf-8')

def update_heartbeat(crew_number: int, phase: str = "", role: str = ""):
    """Update heartbeat file with current timestamp."""
    crew_dir = ensure_crew_dir(crew_number)
    heartbeat_file = crew_dir / "heartbeat.txt"
    heartbeat_file.write_text(datetime.now().isoformat(), encoding='utf-8')


# ============================================================================
# RALPH STATE (v8.0 Stop Hook Integration)
# ============================================================================

def create_ralph_state(crew_number: int, order_id: str, role: str,
                       max_iterations: int = 25,
                       completion_promise: str = "COMPLETE"):
    """Create the per-crew ralph-state.md file before launching Claude.

    v8.0: The stop hook (python -m admiralty.hooks.stop) reads this file to track iteration state.
    YAML frontmatter stores config + current iteration. Body is iteration log.
    """
    crew_dir = ensure_crew_dir(crew_number)
    state_file = crew_dir / "ralph-state.md"
    now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    content = (
        f"---\n"
        f"crew: {crew_number}\n"
        f'order: "{order_id}"\n'
        f'role: "{role}"\n'
        f"iteration: 1\n"
        f"max_iterations: {max_iterations}\n"
        f'completion_promise: "{completion_promise}"\n'
        f'status: "RUNNING"\n'
        f'created: "{now}"\n'
        f'last_iteration: "{now}"\n'
        f"---\n"
        f"\n"
        f"# Iteration Log\n"
        f"\n"
        f"## Initialization ({now})\n"
        f"Ralph state created. Stop hook will manage iterations.\n"
    )

    # Atomic write
    tmp_path = state_file.with_suffix('.tmp')
    try:
        tmp_path.write_text(content, encoding='utf-8')
        tmp_path.replace(state_file)
    except Exception:
        state_file.write_text(content, encoding='utf-8')

    log(f"  Ralph state created: {state_file.relative_to(get_base_dir())}")


def read_ralph_state(crew_number: int) -> dict:
    """Read the final ralph-state.md after Claude exits.

    v8.0: Returns parsed YAML frontmatter as a dict with keys:
    iteration, max_iterations, status, completion_promise, etc.
    """
    crew_dir = get_crew_dir(crew_number)
    state_file = crew_dir / "ralph-state.md"

    if not state_file.exists():
        return {}

    try:
        content = state_file.read_text(encoding='utf-8')
    except Exception:
        return {}

    # Parse YAML frontmatter (between --- delimiters)
    match = re.match(r'^---\s*\n(.*?)\n---\s*\n', content, re.DOTALL)
    if not match:
        return {}

    frontmatter = {}
    for line in match.group(1).strip().split('\n'):
        line = line.strip()
        if ':' in line:
            key, _, value = line.partition(':')
            key = key.strip()
            value = value.strip()
            # Strip surrounding quotes
            if value.startswith('"') and value.endswith('"'):
                value = value[1:-1]
            elif value.startswith("'") and value.endswith("'"):
                value = value[1:-1]
            # Convert numeric values
            if value.isdigit():
                value = int(value)
            elif value == 'true':
                value = True
            elif value == 'false':
                value = False
            elif value == 'null':
                value = None
            frontmatter[key] = value

    return frontmatter


def check_lock(crew_number: int) -> bool:
    """Check if crew is locked (already running).

    v6.0: Also checks if the PID in the lock is actually alive.
    This prevents stale locks from blocking new crew launches.
    """
    lock_file = get_crew_dir(crew_number) / "crew.lock"
    if not lock_file.exists():
        return False

    # Check if the PID in the lock is still alive
    try:
        lock_data = json.loads(lock_file.read_text(encoding='utf-8'))
        lock_pid = lock_data.get("pid", 0)
        if lock_pid and not _is_pid_alive(lock_pid):
            return False  # Process is dead - stale lock
    except:
        pass

    # Fallback: Check if lock is stale (older than 5 minutes with no heartbeat)
    heartbeat_file = get_crew_dir(crew_number) / "heartbeat.txt"
    if heartbeat_file.exists():
        try:
            heartbeat_time = datetime.fromisoformat(heartbeat_file.read_text().strip())
            age = (datetime.now() - heartbeat_time).total_seconds()
            if age > 300:  # 5 minutes
                return False  # Stale lock
        except:
            pass
    return True


def _is_pid_alive(pid: int) -> bool:
    """Check if a process is alive (used by lock check)."""
    if pid <= 0:
        return False
    try:
        if os.name == 'nt':
            import ctypes
            kernel32 = ctypes.windll.kernel32
            handle = kernel32.OpenProcess(0x1000, False, pid)
            if handle == 0:
                return False
            try:
                exit_code = ctypes.c_ulong()
                if kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code)):
                    return exit_code.value == 259
                return False
            finally:
                kernel32.CloseHandle(handle)
        else:
            os.kill(pid, 0)
            return True
    except:
        return False

def set_lock(crew_number: int, order_id: str, role: str):
    """Set crew lock."""
    crew_dir = ensure_crew_dir(crew_number)
    lock_file = crew_dir / "crew.lock"
    lock_data = {
        "pid": os.getpid(),
        "orderId": order_id,
        "role": role,
        "startTime": datetime.now().isoformat()
    }
    lock_file.write_text(json.dumps(lock_data, indent=2), encoding='utf-8')
    update_heartbeat(crew_number)

def clear_lock(crew_number: int):
    """Clear crew lock and related files."""
    crew_dir = get_crew_dir(crew_number)
    for filename in ["crew.lock", "heartbeat.txt", "pid.txt"]:
        lock_file = crew_dir / filename
        if lock_file.exists():
            lock_file.unlink()

# ============================================================================
# PROGRESS TRACKING
# ============================================================================

def init_progress(crew_number: int, order_id: str, role: str):
    """Initialize progress file."""
    crew_dir = ensure_crew_dir(crew_number)
    progress_file = crew_dir / "progress.md"

    role_name = ROLE_INFO.get(role, {}).get("name", role)
    start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    content = f"""# Progress: Order {order_id}

## Role: {role} ({role_name})
## Started: {start_time}

## Tasks
- [ ] Review task and understand requirements
- [ ] Begin execution

## Files Changed
(none yet)

## Notes
"""
    progress_file.write_text(content, encoding='utf-8')

    # v8.1: Clear hook data files for fresh start
    for filename in ["activity.jsonl", "activity.txt", "files_modified.json", "notifications.log"]:
        filepath = crew_dir / filename
        if filepath.exists():
            try:
                filepath.unlink()
            except Exception:
                pass

def read_progress(crew_number: int) -> str:
    """Read current progress."""
    progress_file = get_crew_dir(crew_number) / "progress.md"
    if progress_file.exists():
        return progress_file.read_text(encoding='utf-8')
    return "No progress yet."

# ============================================================================
# v5.0: QUEUE ITEM CREATION (Self-Organizing Crews)
# ============================================================================

def get_queue_dir() -> Path:
    """Get the queue directory."""
    return get_workspace_dir() / "queues"

def generate_queue_id(prefix: str) -> str:
    """Generate a unique queue item ID."""
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    import random
    suffix = random.randint(100, 999)
    return f"{prefix}-{timestamp}-{suffix}"

def can_create_item(role: str, item_type: str) -> bool:
    """Check if a role can create a specific item type."""
    permissions = ROLE_PERMISSIONS.get(role, {})
    return item_type in permissions.get("can_create", [])

def can_request_service(role: str, service_type: str) -> bool:
    """Check if a role can request a specific service."""
    permissions = ROLE_PERMISSIONS.get(role, {})
    return service_type in permissions.get("can_request", [])

def can_breakdown_orders(role: str) -> bool:
    """Check if a role can break down high-level orders."""
    permissions = ROLE_PERMISSIONS.get(role, {})
    return permissions.get("can_breakdown", False)

def check_queue_depth(queue_name: str) -> bool:
    """Check if a queue is under its depth limit (v7.0). Returns True if item can be added."""
    limit = MAX_QUEUE_DEPTH.get(queue_name)
    if limit is None:
        return True  # No limit configured for this queue
    queue_path = get_queue_dir() / queue_name
    if not queue_path.exists():
        return True
    count = len([f for f in queue_path.iterdir() if f.suffix == '.json'])
    if count >= limit:
        log(f"QUEUE DEPTH LIMIT: {queue_name} has {count}/{limit} items - rejecting new item")
        return False
    return True

def check_crew_rate_limit(crew_number: int, order_id: str) -> bool:
    """Check if a crew has exceeded its per-order item creation limit (v7.0).
    Prevents a single crew from flooding queues during one order execution.
    Returns True if crew can create more items, False if rate limited.
    """
    queues_dir = get_queue_dir()
    count = 0
    # Scan all queue directories for items created by this crew on this order
    for queue_name in ["bugs", "defects", "security", "breakdown", "escalations"]:
        queue_path = queues_dir / queue_name
        if not queue_path.exists():
            continue
        for json_file in queue_path.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                created_by = data.get("createdBy", {})
                if created_by.get("crew") == crew_number and created_by.get("order") == order_id:
                    count += 1
            except Exception:
                continue
    # Also scan request subdirectories
    requests_dir = queues_dir / "requests"
    if requests_dir.exists():
        for subdir in ["investigation", "qa", "planning", "documentation"]:
            subpath = requests_dir / subdir
            if not subpath.exists():
                continue
            for json_file in subpath.glob("*.json"):
                try:
                    data = json.loads(json_file.read_text(encoding='utf-8'))
                    created_by = data.get("createdBy", {})
                    if created_by.get("crew") == crew_number and created_by.get("order") == order_id:
                        count += 1
                except Exception:
                    continue

    if count >= MAX_CREW_ITEMS_PER_ORDER:
        log(f"CREW RATE LIMIT: Crew {crew_number} has created {count}/{MAX_CREW_ITEMS_PER_ORDER} items for order {order_id} - rejecting")
        return False
    return True

def create_bug_report(crew_number: int, role: str, order_id: str,
                      title: str, description: str, priority: str = "NORMAL") -> Optional[str]:
    """
    Create a bug report in the queue (v5.0).
    Returns the bug ID if successful, None if not permitted.
    """
    if not can_create_item(role, "bugs"):
        log(f"PERMISSION DENIED: Role {role} cannot create bugs")
        return None
    if not check_queue_depth("bugs"):
        return None
    if not check_crew_rate_limit(crew_number, order_id):
        return None

    bug_id = generate_queue_id("BUG")
    queue_item = {
        "id": bug_id,
        "type": "BUG",
        "priority": priority,
        "status": "PENDING",
        "createdBy": {
            "crew": crew_number,
            "role": role,
            "order": order_id
        },
        "createdAt": datetime.now().isoformat(),
        "title": title,
        "description": description,
        "targetRole": "SHP"
    }

    queue_file = get_queue_dir() / "bugs" / f"{bug_id}.json"
    queue_file.parent.mkdir(parents=True, exist_ok=True)
    queue_file.write_text(json.dumps(queue_item, indent=2), encoding='utf-8')

    log(f"BUG CREATED: {bug_id} - {title}")
    return bug_id

def create_defect_report(crew_number: int, role: str, order_id: str,
                         title: str, description: str, severity: str = "NORMAL") -> Optional[str]:
    """
    Create a defect report in the queue (v5.0 - BOS only).
    Returns the defect ID if successful, None if not permitted.
    """
    if not can_create_item(role, "defects"):
        log(f"PERMISSION DENIED: Role {role} cannot create defects")
        return None
    if not check_queue_depth("defects"):
        return None
    if not check_crew_rate_limit(crew_number, order_id):
        return None

    defect_id = generate_queue_id("DEF")
    queue_item = {
        "id": defect_id,
        "type": "DEFECT",
        "priority": "NORMAL+" if severity == "HIGH" else "NORMAL",
        "status": "PENDING",
        "createdBy": {
            "crew": crew_number,
            "role": role,
            "order": order_id
        },
        "createdAt": datetime.now().isoformat(),
        "title": title,
        "description": description,
        "severity": severity,
        "targetRole": "SHP"
    }

    queue_file = get_queue_dir() / "defects" / f"{defect_id}.json"
    queue_file.parent.mkdir(parents=True, exist_ok=True)
    queue_file.write_text(json.dumps(queue_item, indent=2), encoding='utf-8')

    log(f"DEFECT CREATED: {defect_id} - {title}")
    return defect_id

def create_security_issue(crew_number: int, role: str, order_id: str,
                          title: str, description: str, severity: str = "HIGH") -> Optional[str]:
    """
    Create a security issue in the queue (v5.0 - LKT only).
    Returns the security issue ID if successful, None if not permitted.
    """
    if not can_create_item(role, "security"):
        log(f"PERMISSION DENIED: Role {role} cannot create security issues")
        return None
    if not check_queue_depth("security"):
        return None
    if not check_crew_rate_limit(crew_number, order_id):
        return None

    sec_id = generate_queue_id("SEC")
    queue_item = {
        "id": sec_id,
        "type": "SECURITY",
        "priority": "HIGH" if severity == "CRITICAL" else "NORMAL+",
        "status": "PENDING",
        "createdBy": {
            "crew": crew_number,
            "role": role,
            "order": order_id
        },
        "createdAt": datetime.now().isoformat(),
        "title": title,
        "description": description,
        "severity": severity,
        "targetRole": "SHP"
    }

    queue_file = get_queue_dir() / "security" / f"{sec_id}.json"
    queue_file.parent.mkdir(parents=True, exist_ok=True)
    queue_file.write_text(json.dumps(queue_item, indent=2), encoding='utf-8')

    log(f"SECURITY ISSUE CREATED: {sec_id} - {title}")
    return sec_id

def request_investigation(crew_number: int, role: str, order_id: str,
                          title: str, description: str) -> Optional[str]:
    """
    Request an investigation from LKT (v5.0).
    Returns the request ID if successful, None if not permitted.
    """
    if not can_request_service(role, "investigation"):
        log(f"PERMISSION DENIED: Role {role} cannot request investigations")
        return None
    if not check_crew_rate_limit(crew_number, order_id):
        return None

    req_id = generate_queue_id("REQ-INV")
    queue_item = {
        "id": req_id,
        "type": "REQUEST",
        "requestType": "INVESTIGATION",
        "priority": "HIGH",
        "status": "PENDING",
        "createdBy": {
            "crew": crew_number,
            "role": role,
            "order": order_id
        },
        "createdAt": datetime.now().isoformat(),
        "title": title,
        "description": description,
        "targetRole": "LKT"
    }

    queue_file = get_queue_dir() / "requests" / "investigation" / f"{req_id}.json"
    queue_file.parent.mkdir(parents=True, exist_ok=True)
    queue_file.write_text(json.dumps(queue_item, indent=2), encoding='utf-8')

    log(f"INVESTIGATION REQUESTED: {req_id} - {title}")
    return req_id

def request_qa(crew_number: int, role: str, order_id: str,
               title: str, description: str) -> Optional[str]:
    """
    Request QA from BOS (v5.0).
    Returns the request ID if successful, None if not permitted.
    """
    if not can_request_service(role, "qa"):
        log(f"PERMISSION DENIED: Role {role} cannot request QA")
        return None
    if not check_crew_rate_limit(crew_number, order_id):
        return None

    req_id = generate_queue_id("REQ-QA")
    queue_item = {
        "id": req_id,
        "type": "REQUEST",
        "requestType": "QA",
        "priority": "HIGH",
        "status": "PENDING",
        "createdBy": {
            "crew": crew_number,
            "role": role,
            "order": order_id
        },
        "createdAt": datetime.now().isoformat(),
        "title": title,
        "description": description,
        "targetRole": "BOS"
    }

    queue_file = get_queue_dir() / "requests" / "qa" / f"{req_id}.json"
    queue_file.parent.mkdir(parents=True, exist_ok=True)
    queue_file.write_text(json.dumps(queue_item, indent=2), encoding='utf-8')

    log(f"QA REQUESTED: {req_id} - {title}")
    return req_id


def request_planning(crew_number: int, role: str, order_id: str,
                     title: str, description: str, report_path: str) -> Optional[str]:
    """
    Request planning/breakdown from NAV based on investigation findings (v5.0).
    Used by LKT after completing an investigation with findings.
    Returns the request ID if successful, None if not permitted.
    """
    if not can_request_service(role, "planning"):
        log(f"PERMISSION DENIED: Role {role} cannot request planning")
        return None
    if not check_crew_rate_limit(crew_number, order_id):
        return None

    req_id = generate_queue_id("REQ-PLAN")
    queue_item = {
        "id": req_id,
        "type": "REQUEST",
        "requestType": "PLANNING",
        "priority": "HIGH",
        "status": "PENDING",
        "createdBy": {
            "crew": crew_number,
            "role": role,
            "order": order_id
        },
        "createdAt": datetime.now().isoformat(),
        "title": title,
        "description": description,
        "reportPath": report_path,  # Path to LKT investigation report
        "targetRole": "NAV"
    }

    queue_file = get_queue_dir() / "requests" / "planning" / f"{req_id}.json"
    queue_file.parent.mkdir(parents=True, exist_ok=True)
    queue_file.write_text(json.dumps(queue_item, indent=2), encoding='utf-8')

    log(f"PLANNING REQUESTED: {req_id} - {title}")
    log(f"  Report: {report_path}")
    return req_id

def create_breakdown_order(crew_number: int, role: str, parent_order_id: str,
                           title: str, description: str, target_role: str) -> Optional[str]:
    """
    Create a breakdown sub-order from a high-level order (v5.0).
    Only NAV, LKT, COX can break down orders.
    Returns the order ID if successful, None if not permitted.
    """
    if not can_breakdown_orders(role):
        log(f"PERMISSION DENIED: Role {role} cannot break down orders")
        return None
    if not check_queue_depth("breakdown"):
        return None
    if not check_crew_rate_limit(crew_number, parent_order_id):
        return None

    order_id = generate_queue_id("SUB")
    queue_item = {
        "id": order_id,
        "type": "ORDER",
        "orderType": "BREAKDOWN",
        "priority": "LOW",
        "status": "PENDING",
        "createdBy": {
            "crew": crew_number,
            "role": role,
            "order": parent_order_id
        },
        "parentOrder": parent_order_id,
        "createdAt": datetime.now().isoformat(),
        "title": title,
        "description": description,
        "targetRole": target_role
    }

    queue_file = get_queue_dir() / "breakdown" / f"{order_id}.json"
    queue_file.parent.mkdir(parents=True, exist_ok=True)
    queue_file.write_text(json.dumps(queue_item, indent=2), encoding='utf-8')

    log(f"BREAKDOWN ORDER CREATED: {order_id} - {title} (target: {target_role})")
    return order_id

def create_escalation(crew_number: int, role: str, order_id: str,
                      title: str, description: str, decision_needed: str,
                      blocking: bool = False, voyage_id: str = None) -> Optional[str]:
    """
    Create an escalation requiring Captain/QM decision (v7.0).
    Any role can escalate — no permission check needed.
    If blocking=True, dispatcher holds all orders for the same voyageId.
    Returns the escalation ID if successful, None if queue is full.
    """
    if not check_queue_depth("escalations"):
        return None
    if not check_crew_rate_limit(crew_number, order_id):
        return None

    esc_id = generate_queue_id("ESC")
    queue_item = {
        "id": esc_id,
        "type": "ESCALATION",
        "status": "PENDING",
        "blocking": blocking,
        "createdBy": {
            "crew": crew_number,
            "role": role,
            "order": order_id
        },
        "createdAt": datetime.now().isoformat(),
        "title": title,
        "description": description,
        "decisionNeeded": decision_needed,
        "voyageId": voyage_id,
        "resolution": None
    }

    queue_file = get_queue_dir() / "escalations" / f"{esc_id}.json"
    queue_file.parent.mkdir(parents=True, exist_ok=True)
    queue_file.write_text(json.dumps(queue_item, indent=2), encoding='utf-8')

    block_str = " [BLOCKING]" if blocking else ""
    log(f"ESCALATION CREATED{block_str}: {esc_id} - {title}")
    log(f"  Decision needed: {decision_needed}")
    return esc_id

# ============================================================================
# PROMPT BUILDING
# ============================================================================

def load_role_template(role: str, minimal: bool = True) -> str:
    """Load role template - prefer minimal version for performance."""
    if minimal:
        minimal_file = get_workspace_dir() / f"prompts/templates/{role}-minimal.md"
        if minimal_file.exists():
            return minimal_file.read_text(encoding='utf-8')

    template_file = get_workspace_dir() / f"prompts/templates/{role}-template.md"
    if template_file.exists():
        return template_file.read_text(encoding='utf-8')
    return f"# Role: {role}"

def build_prompt(crew_number: int, iteration: int, max_iterations: int,
                 role: str, order_id: str, task_prompt: str,
                 completion_promise: str = "COMPLETE") -> str:
    """Build a focused prompt for Claude - optimized for performance."""

    role_injection = load_role_template(role, minimal=True)

    # Only include progress on subsequent iterations
    progress_section = ""
    if iteration > 1:
        progress = read_progress(crew_number)
        progress_section = f"\n## CURRENT PROGRESS\n\n{progress}\n"

    prompt = f"""# CREW {crew_number} | ITERATION {iteration}/{max_iterations} | {role} | {order_id}

{role_injection}

## ORDER

{task_prompt}
{progress_section}
## INSTRUCTIONS

Execute the next step. Update `.adm/crews/crew{crew_number}/progress.md`.

When complete: `<promise>{completion_promise}</promise>`
If blocked: `<promise>BLOCKED</promise>`
"""
    # Warn if prompt is large - queue mode recommended for reliability
    if len(prompt) > 3000:
        log(f"  [WARN] Prompt is {len(prompt)} bytes - large prompts may be slow")

    return prompt

# ============================================================================
# CLAUDE EXECUTION
# ============================================================================

def find_claude_cli() -> Optional[str]:
    """Find the Claude CLI executable."""
    # Try common locations
    possible_paths = [
        "claude",  # In PATH
        "claude.cmd",  # Windows
        os.path.expanduser("~/.npm-global/bin/claude"),
        os.path.expanduser("~/AppData/Roaming/npm/claude.cmd"),
    ]

    for path in possible_paths:
        try:
            result = subprocess.run(
                [path, "--version"],
                capture_output=True,
                text=True,
                timeout=10
            )
            if result.returncode == 0:
                return path
        except:
            continue

    return None

def invoke_claude(prompt: str, timeout_seconds: int = 1800,
                  crew_number: int = 0, order_id: str = "",
                  max_iterations: int = 25, completion_promise: str = "COMPLETE",
                  role: str = "") -> Dict[str, Any]:
    """
    Invoke Claude CLI with the given prompt.

    v8.3: Role-based model selection. Each role gets the optimal model:
      COX → Opus (critical review), NAV/SHP/BOS/SCR → Sonnet, LKT → Haiku (fast scan)

    v8.0: Stop hook handles iteration control. Environment variables tell
    the stop hook (python -m admiralty.hooks.stop) which crew is running so it can read the correct
    ralph-state.md file. Iterations happen inside the Claude session via
    the hook blocking exit and re-feeding prompts.

    v6.0: No CLI lock needed. Each crew runs as a fully detached independent
    process (launched by fleet-runner v6.0 with DETACHED_PROCESS flags).
    Concurrent API calls are safe when processes are truly independent.
    """
    result = {
        "success": False,
        "output": "",
        "error": None,
        "timed_out": False,
        "lock_failed": False
    }

    claude_cli = find_claude_cli()
    if not claude_cli:
        result["error"] = "Claude CLI not found. Install with: npm install -g @anthropic-ai/claude-code"
        return result

    try:
        # Run Claude with the prompt (use UTF-8 encoding explicitly)
        # CREATE_NO_WINDOW (0x08000000) prevents console window popup in background mode
        run_kwargs = {}
        if os.name == 'nt':
            run_kwargs['creationflags'] = 0x08000000  # CREATE_NO_WINDOW

        # v8.0: Set environment variables for the fleet stop hook
        # The hook reads MAESTRO_CREW to find the crew's ralph-state.md
        # If MAESTRO_CREW is not set (Captain's session), the hook exits immediately
        env = os.environ.copy()

        # v8.5: Inject NUGET_AUTH_TOKEN for GitHub Packages authentication
        # Crews need this to restore EML.* packages from the private feed.
        # Sources (in priority order): existing env var, gh CLI token
        if not env.get("NUGET_AUTH_TOKEN"):
            try:
                gh_token = subprocess.run(
                    ["gh", "auth", "token"],
                    capture_output=True, text=True, timeout=10
                )
                if gh_token.returncode == 0 and gh_token.stdout.strip():
                    env["NUGET_AUTH_TOKEN"] = gh_token.stdout.strip()
                    log("  NuGet auth: injected from gh CLI")
            except Exception:
                log("  NuGet auth: gh CLI not available, NUGET_AUTH_TOKEN not set")

        # v8.14: Centralized temp directory for crew artifacts
        # Prevents crews scattering .local-nuget, build outputs, etc. across the workspace
        admiralty_root = Path(__file__).resolve().parent.parent
        _temp_val = str(admiralty_root / "temp")
        env["MAESTRO_TEMP"] = _temp_val

        if crew_number > 0:
            env["MAESTRO_CREW"] = str(crew_number)
            env["MAESTRO_ORDER"] = order_id
            env["MAESTRO_MAX_ITERATIONS"] = str(max_iterations)
            env["MAESTRO_COMPLETION_PROMISE"] = completion_promise
            # v8.4: Force headless mode for Playwright tests run by fleet crews
            # Prevents browser windows popping up on the Captain's desktop
            env["K2_TEST_HEADLESS"] = "true"

        # v8.3 / v2.5.6 (FTR-0129): Resolve model with full override chain
        # (per-order → workspace config → env var → ROLE_MODELS default).
        # Look up the order JSON from disk so per-order `model` overrides apply.
        order_data = _load_order_data_for(order_id) if order_id else {}
        try:
            model = resolve_model_for(role, order_data)
        except ValueError as model_err:
            log(f"  Model resolution failed: {model_err}")
            raise
        log(f"  Model: {model} (role={role or 'default'})")

        # Use worktree path as working directory when available (injected via MAESTRO_REPO_PATH).
        work_dir = get_base_dir()
        repo_path = env.get("MAESTRO_REPO_PATH", "")
        if repo_path:
            repo_dir = Path(repo_path)
            if repo_dir.exists() and (repo_dir / ".git").exists():
                work_dir = repo_dir
                log(f"  Working dir: {repo_dir} (managed repo)")
            else:
                log(f"  Working dir: {work_dir} (managed repo not found, using workspace root)")

        proc = subprocess.run(
            [claude_cli, "--print", "--dangerously-skip-permissions", "--model", model],
            input=prompt,
            capture_output=True,
            text=True,
            encoding='utf-8',
            errors='replace',
            timeout=timeout_seconds,
            cwd=str(work_dir),
            env=env,
            **run_kwargs
        )

        result["output"] = proc.stdout or ""
        if proc.stderr:
            result["output"] += "\n" + proc.stderr
        result["success"] = proc.returncode == 0

    except subprocess.TimeoutExpired as e:
        result["timed_out"] = True
        result["error"] = f"Timed out after {timeout_seconds} seconds"
        # v7.3: Capture partial output for timeout briefing
        if e.stdout:
            result["output"] = e.stdout if isinstance(e.stdout, str) else e.stdout.decode('utf-8', errors='replace')
        if e.stderr:
            stderr_text = e.stderr if isinstance(e.stderr, str) else e.stderr.decode('utf-8', errors='replace')
            result["output"] = (result.get("output", "") + "\n" + stderr_text).strip()
    except Exception as e:
        result["error"] = str(e)

    return result

# ============================================================================
# TIMEOUT BRIEFING (v7.3)
# ============================================================================

def generate_timeout_brief(crew_number: int, order_id: str, role: str,
                           iteration: int, max_iterations: int,
                           last_result: Dict[str, Any]) -> str:
    """Generate a brief summarizing work done before timeout.

    v7.3: Called when a crew times out. Captures iteration progress,
    artifacts produced, and partial output from the timed-out iteration.
    The brief is stored in crew state and appended to the order on re-queue.
    """
    crew_dir = get_crew_dir(crew_number)
    lines = []

    lines.append(f"### Timeout Brief — {order_id}")
    lines.append(f"- **Crew:** {crew_number} ({get_squad_name(crew_number)})")
    lines.append(f"- **Role:** {role}")
    lines.append(f"- **Timed out at:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    lines.append(f"- **Iteration:** {iteration} of {max_iterations}")
    lines.append("")

    # List output files from completed iterations
    output_files = sorted(crew_dir.glob("output_*.txt"))
    if output_files:
        lines.append("**Completed iteration outputs:**")
        for f in output_files:
            size = f.stat().st_size
            lines.append(f"- `{f.name}` ({size:,} bytes)")
        lines.append("")

    # Capture partial output from the timed-out iteration
    partial_output = last_result.get("output", "").strip()
    if partial_output:
        # Truncate to last 2000 chars to keep brief manageable
        if len(partial_output) > 2000:
            partial_output = "...(truncated)...\n" + partial_output[-2000:]
        lines.append("**Partial output (timed-out iteration):**")
        lines.append("```")
        lines.append(partial_output)
        lines.append("```")
        lines.append("")
    else:
        lines.append("**Partial output:** None captured (subprocess killed before output flushed)")
        lines.append("")

    # Check state for files changed
    state = read_state(crew_number) or {}
    files_changed = state.get("filesChangedTotal", 0)
    if files_changed > 0:
        lines.append(f"**Files modified during session:** {files_changed}")
        lines.append("")

    return "\n".join(lines)


# ============================================================================
# MAIN EXECUTION (v8.0 — Stop Hook Iteration Control)
# ============================================================================

def run_crew(crew_number: int, role: str, order_id: str, prompt_file: str,
             max_iterations: int = 25, completion_promise: str = "COMPLETE",
             circuit_breaker: int = 3, timeout_minutes: int = 90):
    """Run the crew with stop hook iteration control.

    v8.0: Single Claude invocation — the stop hook (python -m admiralty.hooks.stop) handles iterations
    by intercepting Claude's natural exit and re-feeding prompts. The Python
    iteration for-loop is replaced with a single subprocess.run() call.

    Flow:
      1. Create ralph-state.md (hook reads this for iteration tracking)
      2. Build prompt once (iteration 1)
      3. invoke_claude() — single call, hook manages iterations internally
      4. Read ralph-state.md for final status/iteration count
      5. Map ralph status to crew state codes
    """

    log(f"""
+----------------------------------------------------------+
|  FLEET COMMAND SYSTEM - CREW EXECUTION ENGINE v8.0 (Py)  |
+----------------------------------------------------------+

  Crew:      {crew_number} ({get_squad_name(crew_number)})
  Role:      {role} ({ROLE_INFO.get(role, {}).get('name', 'Unknown')})
  Order:     {order_id}
  Focus:     {ROLE_INFO.get(role, {}).get('focus', 'Unknown')}
  Max Iter:  {max_iterations}
  Timeout:   {timeout_minutes} min
  Engine:    Stop Hook (Ralph Wiggum pattern)
""")

    # Check for existing lock
    if check_lock(crew_number):
        log("ERROR: Crew is already running.")
        log("Use --cleanup to force stop, or --status to check.")
        return 1

    # Load task prompt
    prompt_path = get_base_dir() / prompt_file
    if not prompt_path.exists():
        log(f"ERROR: Prompt file not found: {prompt_file}")
        return 1

    task_prompt = prompt_path.read_text(encoding='utf-8')

    # Set lock
    set_lock(crew_number, order_id, role)

    # Initialize state.json (kept for backward compat with fleet-runner/monitor)
    state = {
        "crewNumber": crew_number,
        "role": role,
        "orderId": order_id,
        "status": "RUNNING",
        "iteration": 1,
        "maxIterations": max_iterations,
        "filesChangedTotal": 0,
        "promptFile": prompt_file,
        "startTime": datetime.now().isoformat(),
        "pid": os.getpid()
    }
    write_state(crew_number, state)

    # Initialize progress
    init_progress(crew_number, order_id, role)

    # v8.0: Create ralph state file for stop hook
    create_ralph_state(crew_number, order_id, role, max_iterations, completion_promise)

    # Build prompt once (iteration 1 — hook handles subsequent iterations)
    full_prompt = build_prompt(
        crew_number, 1, max_iterations,
        role, order_id, task_prompt, completion_promise
    )

    # Save prompt for debugging
    current_prompt_file = get_crew_dir(crew_number) / "current_prompt.md"
    current_prompt_file.write_text(full_prompt, encoding='utf-8')

    # v6.0: Initial startup delay - stagger first API call per crew
    startup_delay = 10 * crew_number
    log(f"[{datetime.now().strftime('%H:%M:%S')}] Startup delay ({startup_delay}s, crew {crew_number} offset)...")
    time.sleep(startup_delay)

    final_status = "UNKNOWN"
    # Per-iteration timeout: spread total budget evenly, min 10 min, max 30 min
    iter_timeout = max(600, min(1800, (timeout_minutes * 60) // max_iterations))

    try:
        # --print mode does not fire Stop hooks, so implement the iteration loop
        # explicitly here in Python. Each iteration calls Claude once; we check
        # the output for <promise>COMPLETE</promise> to detect completion.
        for iteration in range(1, max_iterations + 1):
            state["iteration"] = iteration
            write_state(crew_number, state)

            iter_prompt = build_prompt(
                crew_number, iteration, max_iterations,
                role, order_id, task_prompt, completion_promise
            )

            log(f"[{datetime.now().strftime('%H:%M:%S')}] Invoking Claude (iteration {iteration}/{max_iterations})...")
            update_heartbeat(crew_number, f"iteration-{iteration}", role)

            result = invoke_claude(
                iter_prompt, iter_timeout,
                crew_number, order_id, max_iterations, completion_promise,
                role=role
            )

            output = result.get("output", "")

            # Save per-iteration output
            out_file = get_crew_dir(crew_number) / f"output_{iteration:02d}.txt"
            out_file.write_text(output, encoding='utf-8')

            log(f"[{datetime.now().strftime('%H:%M:%S')}] Iteration {iteration} complete.")

            if result["timed_out"]:
                log(f"[{datetime.now().strftime('%H:%M:%S')}] TIMEOUT on iteration {iteration}")
                brief = generate_timeout_brief(
                    crew_number, order_id, role, iteration, max_iterations, result
                )
                state["timeoutBrief"] = brief
                brief_file = get_crew_dir(crew_number) / f"timeout_brief_{order_id}.md"
                brief_file.write_text(brief, encoding='utf-8')
                final_status = "TIMEOUT"
                break

            if result["error"]:
                log(f"[{datetime.now().strftime('%H:%M:%S')}] ERROR: {result['error']}")
                error_lower = result["error"].lower()
                final_status = "AUTH_ERROR" if "authentication" in error_lower else "ERROR"
                break

            if f"<promise>{completion_promise}</promise>" in output:
                log(f"\n[{datetime.now().strftime('%H:%M:%S')}] COMPLETION detected (iteration {iteration})!")
                final_status = "COMPLETE"
                break

            if "<promise>BLOCKED</promise>" in output:
                log(f"\n[{datetime.now().strftime('%H:%M:%S')}] BLOCKED detected (iteration {iteration})!")
                final_status = "BLOCKED"
                break

            log(f"[{datetime.now().strftime('%H:%M:%S')}] Not complete — continuing to next iteration...")

        else:
            log(f"[{datetime.now().strftime('%H:%M:%S')}] Max iterations ({max_iterations}) reached")
            final_status = "MAX_ITERATIONS"

        # Copy last output to canonical file
        last_out = get_crew_dir(crew_number) / f"output_{state['iteration']:02d}.txt"
        if last_out.exists():
            (get_crew_dir(crew_number) / "output_final.txt").write_text(
                last_out.read_text(encoding='utf-8'), encoding='utf-8'
            )

    except KeyboardInterrupt:
        log("\n\nInterrupted by user.")
        final_status = "INTERRUPTED"
    except Exception as e:
        log(f"\nError: {e}")
        final_status = "ERROR"
    finally:
        # Update final state
        state["status"] = final_status
        state["endTime"] = datetime.now().isoformat()

        # v2.0.6: Load token usage captured by stop hook
        try:
            usage_file = get_workspace_dir() / "usage" / "orders" / f"{order_id}.json"
            if usage_file.exists():
                with open(usage_file, encoding="utf-8") as uf:
                    usage_data = json.load(uf)
                state["usage"] = {
                    "total_tokens": usage_data.get("total_tokens", 0),
                    "estimated_cost_usd": usage_data.get("estimated_cost_usd", 0),
                    "models": usage_data.get("models", {}),
                }
                log(f"[{datetime.now().strftime('%H:%M:%S')}] Token usage: {state['usage']['total_tokens']:,} tokens, ${state['usage']['estimated_cost_usd']:.2f}")
        except Exception:
            pass  # Fail-open: never block for usage tracking

        write_state(crew_number, state)

        # Clear lock
        clear_lock(crew_number)

    log(f"""
===========================================================
  VOYAGE {final_status}
===========================================================

Final Status: {final_status}
Iterations:   {state.get('iteration', 0)} (managed by stop hook)
""")

    return 0 if final_status == "COMPLETE" else 1

# ============================================================================
# STATUS & CLEANUP
# ============================================================================

def show_status(crew_number: int):
    """Show crew status."""
    state = read_state(crew_number)

    print(f"""
+----------------------------------------------------------+
|  CREW {crew_number} ({get_squad_name(crew_number)}) STATUS
+----------------------------------------------------------+
""")

    if not state:
        print("  Status: INACTIVE (no state file)")
        return

    role = state.get('role', 'Unknown')
    role_name = ROLE_INFO.get(role, {}).get('name', '')

    print(f"  Status:     {state.get('status', 'Unknown')}")
    print(f"  Role:       {role} ({role_name})")
    print(f"  Order:      {state.get('orderId', 'None')}")
    print(f"  Iteration:  {state.get('iteration', 0)} / {state.get('maxIterations', 0)}")
    print(f"  Started:    {state.get('startTime', 'Unknown')}")
    print(f"  PID:        {state.get('pid', 'Unknown')}")

    # Check heartbeat
    heartbeat_file = get_crew_dir(crew_number) / "heartbeat.txt"
    if heartbeat_file.exists():
        try:
            heartbeat_time = datetime.fromisoformat(heartbeat_file.read_text().strip())
            age = int((datetime.now() - heartbeat_time).total_seconds())
            print(f"  Heartbeat:  {age}s ago")
        except:
            pass

def watch_crew(crew_number: int, interval: int = 5):
    """Watch crew progress in real-time."""
    print(f"Watching Crew {crew_number} (Ctrl+C to stop)...\n")

    last_progress = ""
    last_iteration = 0

    try:
        while True:
            # Clear screen (works on Windows and Unix)
            os.system('cls' if sys.platform == 'win32' else 'clear')

            # Show status header
            state = read_state(crew_number)
            crew_name = get_squad_name(crew_number)

            print(f"+----------------------------------------------------------+")
            print(f"|  CREW {crew_number} ({crew_name}) - LIVE MONITOR")
            print(f"+----------------------------------------------------------+")
            print(f"  Time: {datetime.now().strftime('%H:%M:%S')}")
            print()

            if not state:
                print("  Status: INACTIVE")
                print("\n  Waiting for crew to start...")
            else:
                role = state.get('role', '?')
                role_name = ROLE_INFO.get(role, {}).get('name', '')
                status = state.get('status', 'Unknown')
                iteration = state.get('iteration', 0)
                max_iter = state.get('maxIterations', 0)

                # Status color indicator
                status_indicator = {
                    'RUNNING': '[*]',
                    'COMPLETE': '[+]',
                    'BLOCKED': '[!]',
                    'ERROR': '[X]'
                }.get(status, '[ ]')

                print(f"  {status_indicator} Status:    {status}")
                print(f"      Role:      {role} ({role_name})")
                print(f"      Order:     {state.get('orderId', 'None')}")
                print(f"      Progress:  {iteration} / {max_iter} iterations")

                # Heartbeat
                heartbeat_file = get_crew_dir(crew_number) / "heartbeat.txt"
                if heartbeat_file.exists():
                    try:
                        hb_time = datetime.fromisoformat(heartbeat_file.read_text().strip())
                        age = int((datetime.now() - hb_time).total_seconds())
                        hb_status = "OK" if age < 120 else "STALE" if age < 300 else "DEAD"
                        print(f"      Heartbeat: {age}s ago ({hb_status})")
                    except:
                        pass

                # Show progress file content
                progress_file = get_crew_dir(crew_number) / "progress.md"
                if progress_file.exists():
                    progress = progress_file.read_text(encoding='utf-8')
                    print("\n  --- PROGRESS ---")
                    # Show last 20 lines of progress
                    lines = progress.strip().split('\n')
                    for line in lines[-20:]:
                        print(f"  {line}")

                # Check if completed
                if status in ['COMPLETE', 'BLOCKED', 'ERROR', 'MAX_ITERATIONS']:
                    print(f"\n  >>> Voyage ended with status: {status}")
                    break

            print(f"\n  (Refreshing every {interval}s - Ctrl+C to stop)")
            time.sleep(interval)

    except KeyboardInterrupt:
        print("\n\nStopped watching.")

def cleanup_crew(crew_number: int):
    """Cleanup crew processes and locks."""
    print(f"Cleaning up Crew {crew_number}...")

    state = read_state(crew_number)
    if state and state.get('pid'):
        pid = state['pid']
        try:
            # Try to kill the process
            if sys.platform == 'win32':
                subprocess.run(['taskkill', '/F', '/PID', str(pid)],
                             capture_output=True)
            else:
                subprocess.run(['kill', '-9', str(pid)], capture_output=True)
            print(f"  Killed process {pid}")
        except:
            pass

    clear_lock(crew_number)

    # v8.1: Clean hook data files
    crew_dir = get_crew_dir(crew_number)
    for filename in ["activity.jsonl", "activity.txt", "files_modified.json", "notifications.log"]:
        filepath = crew_dir / filename
        if filepath.exists():
            try:
                filepath.unlink()
            except Exception:
                pass

    print("Cleanup complete.")

# ============================================================================
# MAIN
# ============================================================================

def main():
    parser = argparse.ArgumentParser(
        description="Maestro - Crew Execution Engine"
    )
    parser.add_argument("--crew", "-c", type=int, default=1, choices=[1,2,3,4,5],
                       help="Crew number (1-5)")
    # BUG-MSO-2026-0019: accept canonical role codes (PLN/BLD/TST/DOC/SEC/REL/LEAD)
    # alongside the legacy nautical codes the dispatcher passes after
    # fleet_runner.resolve_role_code() canonicalizes. Internal lookups
    # (ROLE_INFO / ROLE_MODELS / ROLE_PERMISSIONS) are still keyed on legacy
    # codes during the v3.x window, so canonical args.role is normalised back
    # to legacy below. Full canonical-only rewrite is in FTR-MSO-2026-0168.
    _CANONICAL_TO_LEGACY_ROLE = {
        "PLN": "NAV", "BLD": "SHP", "TST": "BOS", "DOC": "SCR",
        "SEC": "LKT", "REL": "COX", "LEAD": "QM",
    }
    _ALL_ROLE_CHOICES = list(ROLE_INFO.keys()) + list(_CANONICAL_TO_LEGACY_ROLE.keys())
    parser.add_argument("--role", "-r", type=str, choices=_ALL_ROLE_CHOICES,
                       help="Role code (legacy: NAV/SHP/BOS/SCR/LKT/COX; canonical: PLN/BLD/TST/DOC/SEC/REL/LEAD)")
    parser.add_argument("--order", "-o", type=str,
                       help="Order ID")
    parser.add_argument("--prompt", "-p", type=str,
                       help="Path to prompt file (relative to project root)")
    parser.add_argument("--max-iterations", "-m", type=int, default=20,
                       help="Maximum iterations (default: 20)")
    parser.add_argument("--timeout", "-t", type=int, default=90,
                       help="Timeout per iteration in minutes (default: 90)")
    parser.add_argument("--circuit-breaker", type=int, default=3,
                       help="Iterations with no progress before stopping (default: 3)")
    parser.add_argument("--status", "-s", action="store_true",
                       help="Show crew status")
    parser.add_argument("--watch", "-w", action="store_true",
                       help="Watch crew progress in real-time")
    parser.add_argument("--watch-interval", type=int, default=5,
                       help="Watch refresh interval in seconds (default: 5)")
    parser.add_argument("--cleanup", action="store_true",
                       help="Cleanup crew processes and locks")
    args = parser.parse_args()

    # BUG-MSO-2026-0019: normalise canonical → legacy code so the rest of the
    # file (ROLE_INFO / ROLE_MODELS / ROLE_PERMISSIONS lookups) keeps working
    # with its existing legacy keys during the v3.x window.
    if args.role in _CANONICAL_TO_LEGACY_ROLE:
        args.role = _CANONICAL_TO_LEGACY_ROLE[args.role]

    if args.watch:
        watch_crew(args.crew, args.watch_interval)
        return 0

    if args.status:
        show_status(args.crew)
        return 0

    if args.cleanup:
        cleanup_crew(args.crew)
        return 0

    # Validate required args
    if not args.role:
        parser.error("--role is required for running")
    if not args.order:
        parser.error("--order is required for running")
    if not args.prompt:
        parser.error("--prompt is required for running")

    return run_crew(
        crew_number=args.crew,
        role=args.role,
        order_id=args.order,
        prompt_file=args.prompt,
        max_iterations=args.max_iterations,
        timeout_minutes=args.timeout,
        circuit_breaker=args.circuit_breaker
    )

if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as e:
        # Log error to file for debugging
        error_log = get_workspace_dir() / "logs" / "crew-errors.log"
        error_log.parent.mkdir(parents=True, exist_ok=True)
        with open(error_log, "a", encoding="utf-8") as f:
            f.write(f"\n[{datetime.now().isoformat()}] CREW CRASH\n")
            f.write(f"Error: {e}\n")
            import traceback
            f.write(traceback.format_exc())
            f.write("\n")

        print(f"\n\n*** CREW CRASHED ***")
        print(f"Error: {e}")
        print(f"See {error_log} for details")
        print("\nPress Enter to close...")
        try:
            input()
        except:
            pass
        sys.exit(1)


# ---------------------------------------------------------------------------
# Rebrand vocabulary (FTR-MSO-2026-0155) — new canonical names
# ---------------------------------------------------------------------------

class Squad:
    """Namespace sentinel for a crew/squad execution unit."""


# Legacy alias — kept through v3.x, removed in v4.0
Crew = Squad  # legacy alias (v3.x); removed v4.0
