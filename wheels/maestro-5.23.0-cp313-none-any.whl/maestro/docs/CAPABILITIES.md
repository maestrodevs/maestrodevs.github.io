# Maestro — Capabilities

> What Maestro does, from a user's point of view. For setup see
> [GETTING-STARTED.md](GETTING-STARTED.md); for commands see
> [CLI-REFERENCE.md](CLI-REFERENCE.md).

Maestro turns Claude Code into a **fleet**: it runs multiple autonomous coding
sessions in parallel to take work from idea to merged PR, with you in command.

## Orchestration
- **Parallel crews** — dispatch up to 5 autonomous Claude sessions at once (`mso dispatch --max-crews N`), each isolated in its own git worktree so they never collide. Community tier is capped at 2 concurrent crews; Pro and above are uncapped by this limit.
- **Voyages & orders** — group work into a voyage (one branch, one PR); each order flows through a configurable sequence of roles (plan → build → test → docs).
- **Roles** — Planner, Builder, Tester, Docs, Security, Releaser, plus your interactive Lead. Each role can use a different model and is scoped to the right tools. Community tier can dispatch Planner, Builder and Tester (plus Investigator); Docs, Security and Releaser require Pro or above.
- **Personas** — pick a cosmetic theme (nautical, navy-seals, …) for how Maestro talks to you.

## Control & safety
- **Human review gates** — pause a voyage for your approval between roles (`mso review approve|revise|reject`).
- **Per-order timeouts** — give heavy orders more time without changing the global ceiling (`timeoutMinutes` on the order, or per-role defaults).
- **Work is never lost** — a crew that's interrupted has its in-progress work preserved on a salvage branch automatically.
- **Guardrails** — crews are confined to their own branch and worktree; secret-leak and branch/path guards run on every action.
- **The Judge** *(Pro and above, off by default)* — a separate decision agent that works your approval queue under rules you write, inside limits it cannot change. In this release it only watches: it records what it would have ruled on each plan awaiting your review and how often you agreed, and acts on nothing. See [JUDGE.md](JUDGE.md).

## CI & cost control
- **Draft-PR finalisation** — voyage PRs stay draft while crews work and are promoted to ready only when the voyage is complete, so CI runs once at the end instead of on every step.
- **Local verify gate** — set a `verifyCommand` (e.g. `dotnet build`, `pytest`) that must pass locally before any push, so a broken build never spends a CI run.

## Operating
- **Live monitoring** — `mso status` dashboard; structured lifecycle log.
- **Lifecycle automation** — completed voyages are finalised and their PRs promoted automatically; merged voyages are archived.
- **Workspace upkeep** — `mso init` scaffolds a project; `mso update` propagates new config safely.

## Enterprise
- Licensing, secrets providers (env / OS keyring / AWS / Azure), identity & ACLs, hash-chained audit log, Slack bridge, MCP server allow-listing, air-gapped install, backup/restore.

See the full command list in [CLI-REFERENCE.md](CLI-REFERENCE.md).
