# Maestro — Troubleshooting

Common errors and how to resolve them.

> **No error message — work has just stopped?** This page is organised around
> messages you can match. If nothing failed loudly and the board simply is not
> moving, ask Maestro directly instead: `mso voyage why VOY-ID` and
> `mso order why ORDER-ID`. See
> [WHEN-A-VOYAGE-IS-STUCK.md](WHEN-A-VOYAGE-IS-STUCK.md)
> (`mso docs when-a-voyage-is-stuck`) for how to read the answer, every cause it
> can report, and what to do about each one.

---

## Contents

- [Installation and PATH issues](#installation-and-path-issues)
  - [E01 — `mso: command not found`](#e01--mso-command-not-found)
  - [E02 — `claude: command not found`](#e02--claude-command-not-found)
  - [E03 — Wrong Python version](#e03--wrong-python-version)
- [Authentication and Licence](#authentication-and-licence)
  - [E04 — Licence key activation failed](#e04--licence-key-activation-failed)
  - [E05 — `ANTHROPIC_API_KEY` missing or invalid](#e05--anthropic_api_key-missing-or-invalid)
  - [E06 — Trial expired — access blocked](#e06--trial-expired--access-blocked)
  - [E07 — Licence expired or grace period exceeded](#e07--licence-expired-or-grace-period-exceeded)
  - [E30 — Licence activated, but Maestro still runs at community tier](#e30--licence-activated-but-maestro-still-runs-at-community-tier)
- [Dispatch and Order Problems](#dispatch-and-order-problems)
  - [E08 — No orders found — dispatch exits immediately](#e08--no-orders-found--dispatch-exits-immediately)
  - [E09 — Orders held: unsatisfied dependencies](#e09--orders-held-unsatisfied-dependencies)
  - [E10 — Crew launches but immediately stops](#e10--crew-launches-but-immediately-stops)
  - [E11 — Crew stuck: no progress for a long time](#e11--crew-stuck-no-progress-for-a-long-time)
  - [E12 — Crew crashes: CRASHED or FAILED status](#e12--crew-crashes-crashed-or-failed-status)
  - [E13 — Community tier: `--max-crews` clamped unexpectedly](#e13--community-tier---max-crews-clamped-unexpectedly)
  - [E14 — Community tier: project cap or role dispatch refused](#e14--community-tier-project-cap-or-role-dispatch-refused)
- [State and Stale Locks](#state-and-stale-locks)
  - [E15 — Stale lock files from a previous run](#e15--stale-lock-files-from-a-previous-run)
  - [E16 — Dispatcher shows STOPPED but process is running](#e16--dispatcher-shows-stopped-but-process-is-running)
- [Git and Repo Problems](#git-and-repo-problems)
  - [E17 — Crew fails: cannot push branch](#e17--crew-fails-cannot-push-branch)
  - [E18 — `mso init` fails: `.mso/` already exists](#e18--mso-init-fails-mso-already-exists)
- [Monitoring and Usage](#monitoring-and-usage)
  - [E19 — `mso usage` shows no data](#e19--mso-usage-shows-no-data)
  - [E20 — `mso status` shows no crews or blank dashboard](#e20--mso-status-shows-no-crews-or-blank-dashboard)
- [Crew Invocation Failures](#crew-invocation-failures)
  - [E21 — Crew exits with MAX_TURNS — order requeued immediately](#e21--crew-exits-with-max_turns--order-requeued-immediately)
  - [E22 — JSON parse error in crew result](#e22--json-parse-error-in-crew-result)
  - [E23 — Claude CLI preflight check fails at mso setup or mso dispatch](#e23--claude-cli-preflight-check-fails-at-mso-setup-or-mso-dispatch)
  - [E31 — Crew write refused: "resolves inside the INSTALLED Maestro package"](#e31--crew-write-refused-resolves-inside-the-installed-maestro-package)
  - [E32 — Crew `pip install` refused: "rule: pip-environment-mutation"](#e32--crew-pip-install-refused-rule-pip-environment-mutation)
  - [E34 — Crew ends as "backend error" (`MODEL_BACKEND_ERROR`)](#e34--crew-ends-as-backend-error-model_backend_error)
- [Runtime Updates](#runtime-updates)
  - [E35 — Runtime update held: "the install is broken, so this workspace is deliberately left paused"](#e35--runtime-update-held-the-install-is-broken-so-this-workspace-is-deliberately-left-paused)
- [Lifecycle Automation](#lifecycle-automation)
  - [E24 — Dispatcher exited on its own — no crash, no error](#e24--dispatcher-exited-on-its-own--no-crash-no-error)
- [CLI Error UX](#cli-error-ux)
  - [E25 — Raw Python traceback instead of a friendly error message](#e25--raw-python-traceback-instead-of-a-friendly-error-message)
  - [E26 — `mso usage` fails with "Multiple Claude project directories found"](#e26--mso-usage-fails-with-multiple-claude-project-directories-found)
  - [E27 — Mistyped subcommand: "argument command: invalid choice"](#e27--mistyped-subcommand-argument-command-invalid-choice)
  - [E28 — "takes no positional argument" / bare project acronym rejected](#e28--takes-no-positional-argument--bare-project-acronym-rejected)
- [Performance and Resource Usage](#performance-and-resource-usage)
  - [E29 — Machine slows down over time; leftover `find`, build-tool, or compiler-server processes](#e29--machine-slows-down-over-time-leftover-find-build-tool-or-compiler-server-processes)
  - [E33 — `mso cleanup` refuses: "a live dispatcher is running"](#e33--mso-cleanup-refuses-a-live-dispatcher-is-running)

---

## Installation and PATH issues

> **Overlapping / stale installs, or removing Maestro entirely?** See
> [INSTALL-UPGRADE-UNINSTALL.md](INSTALL-UPGRADE-UNINSTALL.md) — it covers the old `maestro` →
> `maestro-fleet` rename, user-vs-system scope shadowing, and the full uninstall procedure, none
> of which is repeated here.

### E01 — `mso: command not found`

**Cause:** pip installed the `maestro` entry point into a `bin` or `Scripts` directory that is not on your `PATH`.

**Fix:**

*Linux / macOS:*
```bash
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
source ~/.bashrc
```

*Windows (PowerShell):*

Add `%APPDATA%\Python\PythonXX\Scripts` to your user `PATH` via System > Advanced system settings > Environment Variables. Replace `XX` with your Python version (e.g. `311` for Python 3.11).

*Virtual environment:*

If you installed into a virtual environment, activate it first:
```bash
source .venv/bin/activate   # Linux/macOS
.venv\Scripts\activate      # Windows
mso version
```

**Verify the fix:**
```bash
which mso       # Linux/macOS
where mso       # Windows
mso version
```

---

### E02 — `claude: command not found`

**Cause:** Claude Code is not installed or not on your `PATH`.

**Fix:**

Install Claude Code from [claude.ai/code](https://claude.ai/code) and follow the installation guide for your platform. After installation, verify:

```bash
claude --version
```

If `claude` still is not found, check the Claude Code documentation for PATH setup on your platform. Common locations:
- macOS: `~/.claude/bin/` or a path added during install
- Windows: check the installer output for the installation path

Maestro crew sessions invoke `claude` as a subprocess — if `claude` is not on PATH, all crew dispatch will fail.

---

### E03 — Wrong Python version

**Cause:** Maestro requires Python 3.9 or later. Some systems have Python 2 as the default `python` command.

**Fix:**

Check your version:
```bash
python --version
python3 --version
```

If your system uses `python3`, install Maestro with:
```bash
python3 -m pip install maestro-fleet
```

Or create a virtual environment with the correct Python:
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install maestro-fleet
```

Air-gapped / private-index installs: append `--extra-index-url https://maestrodevs.github.io/simple/` and use the `maestro` package name instead — see [AIR-GAPPED.md](AIR-GAPPED.md).

---

## Authentication and Licence

> **Note:** v2.5.0+ uses the Polar.sh-backed licence-key system (`mso licence activate <KEY>`). The legacy GitHub-collaborator PAT path is retained as a transitional fallback only — see [docs/LICENCE.md](LICENCE.md) for the full activation flow, offline grace, and tamper-recovery paths.

### E04 — Licence key activation failed

**Symptom:**
```
Activation refused: <reason from Polar>
```
or
```
Couldn't reach the licence backend: <network error>
Activation requires online verification — try again with a live network.
```

**Cause:** The key string was entered incorrectly, the subscription was cancelled or expired, or the network couldn't reach `api.polar.sh` for verification.

**Fix:**

1. Copy the key exactly as Polar issued it — keys are case-sensitive and look like `adm_lic_<KEY>` (the key body is what Polar issues; treat the whole string as opaque).
2. Ensure there are no leading or trailing spaces.
3. Quote the key on the command line:
   ```bash
   mso licence activate "adm_lic_<KEY>"
   ```
4. Confirm your subscription is still active in the [Polar customer portal](https://polar.sh/maestro).
5. If activation fails with a network error, check that `api.polar.sh` is reachable (curl it). Activation requires the internet — there is no offline activation flow.
6. For ongoing offline operation after the first successful activation, see the 14-day grace window described in [docs/LICENCE.md](LICENCE.md).

If the key was recently issued and activation still fails, open a [GitHub Issue](https://github.com/Maestrodevs) with the exact error message.

---

### E05 — `ANTHROPIC_API_KEY` missing or invalid

**Symptom:** Crews start but immediately fail, or the dispatcher exits with an API authentication error.

**Cause:** The `ANTHROPIC_API_KEY` environment variable is not set, is set to a placeholder value, or the key does not have access to the Claude models your roles dispatch against (by default Opus 5.5 and Sonnet 5.5 — plus any model you selected via an override; see [CONFIG-MODELS.md](CONFIG-MODELS.md)).

**Fix:**

1. Verify the variable is set:
   ```bash
   echo $ANTHROPIC_API_KEY   # Linux/macOS
   echo %ANTHROPIC_API_KEY%  # Windows cmd
   ```
2. If blank, set it:
   ```bash
   export ANTHROPIC_API_KEY=sk-ant-api03-...
   ```
3. Add to your shell profile to persist across sessions:
   ```bash
   echo 'export ANTHROPIC_API_KEY=sk-ant-api03-...' >> ~/.bashrc
   source ~/.bashrc
   ```
4. Verify the key has model access in your [Anthropic Console](https://console.anthropic.com).

---

### E06 — Trial expired — access blocked

**Symptom:**
```
[Maestro Trial] Your 14-day trial has expired.
Only 'mso version' and 'mso licence' are available.
To continue: https://maestroai.com/pricing
```

**Cause:** The 14-day trial period has elapsed.

**Fix:**

Activate a licence key to resume all commands:
```bash
mso licence activate <YOUR-KEY>
```

If you do not have a key yet, see PRICING.md for options. The `mso licence` and `mso version` commands remain available without a key.

---

### E07 — Licence expired or grace period exceeded

**Symptom:**
```
[Maestro] Licence expired: ACME-TEAM-... expired on 2026-12-31.
Renew at: https://maestroai.com/pricing
```

**Cause:** The licence key's expiry date has passed and the 30-day offline grace period has also elapsed.

**Fix:**

1. Obtain a renewed licence key from your account or request one via [GitHub Issues](https://github.com/Maestrodevs)
2. Activate the new key:
   ```bash
   mso licence deactivate
   mso licence activate <NEW-KEY>
   ```

If you are within the 30-day grace period (last network validation was within 30 days), commands continue to work. The `mso licence status` output shows the days remaining in the grace period.

---

### E30 — Licence activated, but Maestro still runs at community tier

> Numbered E30 because entry IDs are allocated append-only — existing IDs are stable references and are never renumbered. It belongs in this section, so it is listed here.

**Symptom:** activation succeeded, but `mso licence status` — and the first lines of `mso dispatch` — print:

```
⚠ Licence token failed verification (<reason>) — running at community tier.
Run `mso licence activate <TOKEN>` with a valid token, or contact
https://www.maestrodevs.com/contact/
```

You are then subject to every community limit ([E13](#e13--community-tier---max-crews-clamped-unexpectedly), [E14](#e14--community-tier-project-cap-or-role-dispatch-refused)): 2 crews, `INV`/`PLN`/`BLD`/`TST` roles only, Hub unavailable.

**Cause:** your token is well-formed, but this **installation** cannot verify it. Maestro checks a token's signature against a set of vendor signing keys bundled inside the installed package; if that bundle has no entry for your token's key ID, verification fails closed and the tier drops to community. Activation itself does not detect this — it is a property of the install, not of your key. Two ways to get there:

- **You installed something other than an official release wheel** — a build from a source checkout, or a wheel built in a fork/CI that had no signing key configured. Source clones never carry the signing key.
- **Your token was issued under a newer key than your installed version bundles.** Upgrading picks up the current set.

Do not confuse this with the related-but-distinct `⚠ Stored licence record could not be read` message — that is the tamper path ([LICENCE.md § Tamper detection](LICENCE.md#tamper-detection)), and it is about `~/.maestro/licence.json` on **your machine**. This entry is about the **install** being unable to verify a record it can read perfectly well. Re-activating fixes the former and will not fix the latter.

**Fix:**

1. Reinstall from the official channel rather than from a source tree, then re-check:
   ```bash
   pip install --upgrade --force-reinstall maestro-fleet
   mso licence status
   ```
   For air-gapped/private-index installs use your usual `--extra-index-url` (see [AIR-GAPPED.md](AIR-GAPPED.md)).
2. If the warning persists on an official wheel, your token predates or postdates the bundled key set — send the `mso licence status` output to [maestrodevs.com/contact](https://www.maestrodevs.com/contact/) for a re-issue. It names the failure reason and your customer ID; it does **not** print your licence key, so it is safe to paste into a support thread.

Community tier is a working tier, not an error state — Maestro keeps running throughout; only the gated capabilities are withheld.

> **Maintainers building Maestro from source:** this is expected, and the local-refresh procedure that restores a licensed runtime is in the internal owner documentation, not here — a source build is not a supported customer install path.

---

## Dispatch and Order Problems

> **Before working through these by hand:** `mso order why ORDER-ID` answers
> "why is this one not moving" directly, and `mso voyage why VOY-ID` names the
> single order worth starting with. Both are read-only, and both tell you what
> your options are and what each would cost —
> [WHEN-A-VOYAGE-IS-STUCK.md](WHEN-A-VOYAGE-IS-STUCK.md).

### E08 — No orders found — dispatch exits immediately

**Symptom:** `mso dispatch` starts and immediately exits with:
```
[Maestro] No dispatchable orders found. Exiting.
```

**Cause:** One or more of the following:
- Queue directories are empty
- All queued orders have unsatisfied `dependsOn` dependencies
- Order files are not valid JSON or are in the wrong directory

**Fix:**

1. Verify the order file is in the correct queue directory:
   ```bash
   ls .maestro/queues/orders/
   ```
   Order files must be directly in the queue directory — not in a subdirectory.

2. Validate the order JSON:
   ```bash
   python -c "import json; json.load(open('.maestro/queues/orders/YOUR-ORDER-ID.json'))"
   ```

3. Check `dependsOn` — if an order lists an incomplete order as a dependency, it will not dispatch:
   ```bash
   cat .maestro/queues/orders/YOUR-ORDER-ID.json | python -c "import json,sys; print(json.load(sys.stdin).get('dependsOn'))"
   ```
   Check whether the listed dependency is in `.maestro/orders/complete/`.

4. Check all queue tiers, not just `queues/orders/`:
   ```bash
   ls .maestro/queues/bugs/
   ls .maestro/queues/requests/
   ```

---

### E09 — Orders held: unsatisfied dependencies

**Symptom:** The `QUEUE` line in `mso status` shows orders pending, but dispatch does not pick them up. The lifecycle log may show `HELD: dependency not met`.

**Cause:** The order's `dependsOn` array references one or more orders that are not yet in `orders/complete/`. The order itself sits at `status: "PROPOSED"` or `status: "HELD"` in its queue file until that clears — neither status is dispatchable, so it is expected for it not to appear as running work.

**Fix:**

1. Identify which dependency is missing:
   ```bash
   cat .mso/queues/orders/YOUR-ORDER-ID.json
   ```
   Check the `dependsOn` list.

2. Verify the dependency status:
   ```bash
   ls .mso/orders/complete/   # should contain the dependency
   ls .mso/orders/active/     # still in progress
   ls .mso/orders/failed/     # failed — need to retry or remove dependency
   ```

3. If the dependency is in `failed/`, either fix and re-queue it or remove the dependency from the dependent order and re-queue.

**Faster than steps 1–3:** `mso order why ORDER-ID` walks the dependency chain
to its root for you, says whether the root actually needs you or is simply
still in flight, and offers the root's own recovery options — acting on the
held order itself changes nothing. See
[WHEN-A-VOYAGE-IS-STUCK.md](WHEN-A-VOYAGE-IS-STUCK.md#held-on-a-dependency).

**If the dependency is already COMPLETE and the order is still stuck at `PROPOSED`/`HELD`:** this should self-heal on the next dispatcher tick — every tick (including the very first at startup) re-scans for exactly this shape and releases it to `PENDING`, logging an `AUTOQUEUE` lifecycle event. If it doesn't clear within a tick or two, check `mso status` phase for the voyage: a voyage whose only remaining orders are unmet-dependency `PROPOSED`/`HELD` reports `needs_attention` rather than `underway`, so a voyage that still shows `underway` while an order is stuck here points at something other than this bug.

---

### E10 — Crew launches but immediately stops

**Symptom:** A crew appears briefly in `mso status` then transitions to IDLE or FAILED within seconds.

**Cause:** Most commonly:
- `ANTHROPIC_API_KEY` not set (see [E05](#e05--anthropic_api_key-missing-or-invalid))
- `claude` not on PATH (see [E02](#e02--claude-command-not-found))
- Invalid or malformed order prompt
- Permission denied writing to crew directory

**Fix:**

1. Check the crew's state file:
   ```bash
   cat .maestro/crews/crew1/state.json
   ```
2. Check the crew's activity log:
   ```bash
   cat .maestro/crews/crew1/activity.txt
   ```
3. Check for errors in the crew's progress file:
   ```bash
   cat .maestro/crews/crew1/progress.md
   ```
4. Verify API key and Claude Code install as described in E05 and E02.

---

### E11 — Crew stuck: no progress for a long time

**Symptom:** A crew shows RUNNING status but the activity timestamp has not updated for 30+ minutes.

**Cause:** The crew may be:
- Waiting for a long API response
- In a loop retrying a failing action
- Blocked on a decision and unable to escalate

**Fix:**

1. Check recent activity:
   ```bash
   cat .maestro/crews/crew1/activity.txt
   ```
2. Check for escalations raised by the crew:
   ```bash
   ls .maestro/queues/escalations/
   ```
   If there is a blocking escalation, review and resolve it (see OWNER-GUIDE.md).
3. If the crew has genuinely stalled, stop and re-dispatch:
   ```bash
   mso crew --crew 1 --cleanup
   mso dispatch --max-crews 1
   ```

---

### E12 — Crew crashes: CRASHED or FAILED status

**Symptom:** `mso status` shows a crew in CRASHED or FAILED state.

**Cause:** The crew exceeded the maximum iteration count, hit an unrecoverable error, or the `claude` process exited unexpectedly.

**Fix:**

1. Check the ralph-state file for the final iteration count:
   ```bash
   cat .maestro/crews/crew1/ralph-state.md
   ```
2. Check the order's completion metadata:
   ```bash
   cat .maestro/orders/failed/YOUR-ORDER-ID.json
   ```
3. Review the progress file for the last known action:
   ```bash
   cat .maestro/crews/crew1/progress.md
   ```
4. Clean up and retry:
   ```bash
   mso cleanup
   # Move the order back to the queue if needed
   mv .maestro/orders/failed/YOUR-ORDER-ID.json .maestro/queues/orders/
   mso dispatch --max-crews 3
   ```

**Check for preserved work before retrying from scratch.** A crew that died
after producing something usually had that work preserved on a branch, and
`mso order why ORDER-ID` names the branch and its size alongside the retry that
uses it. Retrying fresh when preserved work exists rebuilds it at full cost —
see [WHEN-A-VOYAGE-IS-STUCK.md](WHEN-A-VOYAGE-IS-STUCK.md#stalled).

---

### E13 — Community tier: `--max-crews` clamped unexpectedly

**Symptom:**
```
Community tier is capped at 2 concurrent crews — requested 5, using 2.
Upgrade to Pro/Team/Enterprise for more: https://www.maestrodevs.com/contact/
```

**Cause:** You are on the free community tier and requested more than 2 concurrent crews. Three ways to be on it: no licence at all; an expired licence that downgraded; or an activated licence this install cannot verify — if you believe you hold a paid licence, check [E30](#e30--licence-activated-but-maestro-still-runs-at-community-tier) before assuming the clamp is expected. This is a hard clamp enforced inside the dispatcher itself, not a CLI-only default — it applies the same way whether you invoke `mso dispatch --max-crews N` or trigger a dispatch through the Maestro Hub.

**Fix:**

This is expected behaviour — not an error. Community tier limits dispatch to 2 concurrent crews.

To raise the limit, activate a Pro, Team or Enterprise licence:
```bash
mso licence activate <YOUR-KEY>
```

Then re-dispatch with the desired crew count:
```bash
mso dispatch --max-crews 5
```

---

### E14 — Community tier: project cap or role dispatch refused

**Symptom (registering a second project):**
```
[Maestro] Community tier is limited to 1 registered project
(already registered: MYPROJ).
Upgrade to Pro/Team/Enterprise to register additional projects:
https://www.maestrodevs.com/contact/
```

**Cause:** You are on the free community tier (if you hold a paid licence and did not expect to be, see [E30](#e30--licence-activated-but-maestro-still-runs-at-community-tier)) and ran `mso init` (or another operation that registers a new project acronym) for a *second, distinct* acronym. Community tier caps **registration** at 1 project — dispatching orders on your one existing project is never affected by this gate, and re-running `mso init` for an already-registered acronym (e.g. after moving the workspace) is always allowed.

**Fix:** Either keep working within your single registered project, or activate a Pro/Team/Enterprise licence key to register additional projects:
```bash
mso licence activate <YOUR-KEY>
```

**Symptom (dispatching a gated role):**
```
Refusing to dispatch SEC for SEC-MYPROJ-2026-0001: the SEC role requires a
Pro, Team or Enterprise licence (community tier is limited to
INV/PLN/BLD/TST). Upgrade: https://www.maestrodevs.com/contact/
```

**Cause:** Community tier can only dispatch `INV`, `PLN`, `BLD` and `TST` roles. An order whose `roleSequence` reaches `SEC`, `DOC` or `REL` is refused at dispatch time — the crew slot is never spent trying to run it.

**Fix:** Activate a Pro, Team or Enterprise licence to unlock the remaining roles, or restructure the order's `roleSequence` to stop before the gated role if you don't need it.

---

## State and Stale Locks

### E15 — Stale lock files from a previous run

**Symptom:** `mso status` shows crews as RUNNING but no actual crew processes are active, or `mso dispatch` skips slots that appear occupied.

**Cause:** A previous dispatcher run terminated without cleaning up `crew.lock` and `pid.txt` files.

**Fix:**

```bash
mso cleanup
```

This stops any orphaned processes and resets stale lock and state files. Safe to run at any time — does not affect orders that are genuinely in progress. If what you're actually seeing is high, sustained CPU usage from leftover `find`/build/compiler processes rather than a stuck dashboard, see [E29](#e29--machine-slows-down-over-time-leftover-find-build-tool-or-compiler-server-processes).

After cleanup:
```bash
mso dispatch --max-crews 5
```

---

### E16 — Dispatcher shows STOPPED but process is running

**Symptom:** `mso status` shows `DISPATCHER: STOPPED` but you know dispatch is running.

**Cause:** The dispatcher PID file is missing, stale, or the fleet monitor cannot read the dispatcher state file.

**Fix:**

1. Check whether the dispatcher process is actually running:
   ```bash
   ps aux | grep fleet-runner   # Linux/macOS
   tasklist | findstr fleet-runner   # Windows
   ```
2. If the process is running but the dashboard shows STOPPED, there may be a PID file issue. Because that dispatcher process is confirmed alive, plain `mso cleanup` refuses outright (it never tears down a live fleet — see [E33](#e33--mso-cleanup-refuses-a-live-dispatcher-is-running)); use `--force` to proceed anyway. `--force` never kills a process it can positively confirm is real, so a dispatcher that is genuinely running (as step 1 just confirmed) is left untouched by it — kill the PID you found in step 1 yourself before re-dispatching, or `mso dispatch` will immediately refuse with "Another dispatcher is already running":
   ```bash
   mso cleanup --force
   taskkill /F /PID <PID>        # Windows — <PID> from the tasklist output above
   kill -9 <PID>                 # Linux/macOS — <PID> from the ps aux output above
   mso dispatch --max-crews 5
   ```

---

## Git and Repo Problems

### E17 — Crew fails: cannot push branch

**Symptom:** A crew's final step fails with a Git push error, or the order completes but no branch appears in the remote.

**Cause:** One or more of the following:
- The Maestro host does not have push permissions for the target repository
- SSH key or HTTPS credentials not configured
- The voyage branch already exists with conflicting history

**Fix:**

1. Verify push access from the Maestro host:
   ```bash
   git push origin HEAD --dry-run
   ```
2. For HTTPS remotes, ensure a credential helper is configured:
   ```bash
   git config --global credential.helper store
   ```
3. For SSH remotes, verify the SSH key is added to your Git host and the key is loaded:
   ```bash
   ssh -T git@github.com
   ```
4. If the voyage branch has a conflict, delete it from the remote and re-dispatch:
   ```bash
   git push origin --delete voyage/YOUR-VOYAGE-BRANCH
   ```

---

### E18 — `mso init` fails: `.mso/` already exists

**Symptom:**
```
[Maestro] .maestro/ already exists. Use --force to overwrite.
```

**Cause:** The workspace was already initialised.

**Fix:**

If you want to re-scaffold the workspace (this will overwrite existing config):
```bash
mso init --project MYPROJ --force
```

If you just need to add a new project to an existing workspace, edit `.maestro/config/projects.json` and `.maestro/config/projects/NEWPROJ.json` directly rather than re-running init.

---

## Monitoring and Usage

### E19 — `mso usage` shows no data

**Symptom:** `mso usage --summary` returns `No usage data found` or shows zero tokens and zero cost.

**Cause:** Usage data is captured by the stop hook at the end of each crew session. If the hook did not run (e.g. the crew was interrupted, or the hook script is missing), usage files will not exist.

**Fix:**

1. Check whether usage files were created for completed orders:
   ```bash
   ls .maestro/usage/orders/
   ```
2. Verify the stop hook is present and executable:
   ```bash
   ls .maestro/hooks/fleet-stop-hook.py
   ```
3. Ensure `MAESTRO_CREW` is set when dispatching — the stop hook only captures usage when this variable is set. This is injected automatically by the dispatcher.
4. If usage files are absent for a completed order, the session may have been terminated before the hook fired. No usage data is available for those orders — this is expected for interrupted sessions.

---

### E20 — `mso status` shows no crews or blank dashboard

**Symptom:** `mso status --once` shows an empty dashboard with no crew slots, or exits immediately.

**Cause:** One or more of the following:
- The crew directories do not exist (workspace not initialised)
- `mso status` is being run from the wrong directory
- The fleet monitor script is missing

**Fix:**

1. Ensure you are in the workspace root (where `\.maestro/` is a direct subdirectory):
   ```bash
   ls .maestro/
   ```
2. Verify crew directories exist:
   ```bash
   ls .maestro/crews/
   ```
   If not present, re-run `mso init --project <ACRONYM>`.
3. Verify the fleet monitor is present:
   ```bash
   ls .maestro/core/fleet_monitor.py
   ```
   If missing, re-install or update Maestro:
   ```bash
   pip install --upgrade git+https://github.com/tavisbasing/Maestro.git@main
   ```

---

## Crew Invocation Failures

### E21 — Crew exits with `MAX_TURNS` — order requeued immediately

**Symptom:** `mso status` shows an order cycling through RUNNING → REQUEUE rapidly. The lifecycle log contains:

```
CREW_ITER_BOUNDARY  | crew1 | FTR-... | iter 1/25 | DONE subtype=error_max_turns
```

**Cause:** The Claude CLI hit its internal turn cap (`--max-turns N`, default 25) before the crew produced a `<promise>COMPLETE</promise>` signal. This is expected for large orders but indicates the order needs more turns or fewer responsibilities per iteration.

**Fix:**

1. Increase the turn cap via `mso dispatch --max-turns 40` (or the value that fits the order complexity).
2. If the order is genuinely too large for a single crew pass, ask the PLN role to break it into smaller sub-orders.
3. Check the crew's output file for partial work:
   ```bash
   cat .mso/crews/crew1/output_01.txt
   ```
   If useful work was done, the next dispatch picks up where git history left off (BUG-0023 silent-completion detection may even advance the order automatically if a commit was pushed).

---

### E22 — JSON parse error in crew result

**Symptom:** The lifecycle log or crew progress file shows:

```
JSON parse failed — truncated or malformed output
```

or the order is requeued with `subtype=parse_error` in the lifecycle event.

**Cause:** The Claude CLI stdout was truncated (wall-clock timeout killed the process mid-stream) or the output was not valid JSON. Maestro classifies this as `ERROR` and never as `COMPLETE`.

**Fix:**

1. Check whether the wall-clock timeout is too tight:
   ```bash
   mso dispatch --max-crews 3 --timeout 45   # increase per-iteration wall-clock cap
   ```
2. Check the raw output file for what was captured:
   ```bash
   cat .mso/crews/crew1/output_01.txt
   ```
3. If the `claude` CLI is producing non-JSON output (e.g. a version mismatch), run the preflight check manually:
   ```bash
   claude --print --dangerously-skip-permissions --output-format json --max-turns 1 <<< "Reply with the single word: OK"
   ```
   A healthy response is a JSON object with `"subtype": "success"`.

---

### E23 — Claude CLI preflight check fails at `mso setup` or `mso dispatch`

**Symptom:** `mso setup` exits with:

```
[Maestro] Preflight check FAILED: <error>
Claude CLI is not responding correctly. Fix the issue above before dispatching.
```

Or, if `preflight_check: true` is set in `workspace.json`, `mso dispatch` logs a `WARN` event in the lifecycle log before proceeding.

**Cause:** The Claude CLI is missing, unreachable, or not authenticated. Common causes:
- `claude` not on PATH (see [E02](#e02--claude-command-not-found))
- `ANTHROPIC_API_KEY` not set or invalid (see [E05](#e05--anthropic_api_key-missing-or-invalid))
- Claude Code version incompatible with `--output-format json`

**Fix:**

1. Verify `claude` is on PATH:
   ```bash
   claude --version
   ```
2. Run the smoke test manually to see the raw error:
   ```bash
   claude --print --dangerously-skip-permissions --output-format json --max-turns 1 <<< "Reply with the single word: OK"
   ```
3. Ensure `ANTHROPIC_API_KEY` is set (see E05).
4. In CI environments without a live Claude account, bypass the check:
   ```bash
   export MAESTRO_SKIP_AUTH=1
   mso dispatch
   ```

---

### E31 — Crew write refused: "resolves inside the INSTALLED Maestro package"

**Symptom:** A crew's write/edit is denied with a message like:

```
Path guard: refusing Write write to `...` — it resolves inside the INSTALLED Maestro package /
active Python environment at `.../site-packages/maestro`. Writing there corrupts the very tool
executing this write and has taken the whole fleet down twice...
```

**Cause:** This is deliberate, not a bug. `maestro/hooks/path_guard.py`'s environment-confinement
guard denies any crew file mutation that resolves inside the active Python environment's
`site-packages` or the installed `maestro/` package directory — computed from `sysconfig`/`sys.path`,
never from a live `import maestro` (which, especially in a self-hosted Maestro-on-Maestro workspace,
can resolve to the crew's *own* worktree copy instead of the real install). A crew has genuinely
destroyed the installed package this way, and this has caused real fleet outages.

**Fix:** The crew almost certainly resolved an absolute path (or `cd`'d) into the wrong tree. Point
the write at the crew's own worktree (`$MAESTRO_REPO_PATH`) or `$MAESTRO_TEMP` instead — both are
always allowed. If you are a LEAD/operator doing manual recovery and are certain the target really is
correct, set `MAESTRO_PATH_GUARD_BYPASS=1` (or `MAESTRO_BRANCH_GUARD_BYPASS=1`) in the parent shell
before the session that needs it — both are inherited by the processes it launches. This is not
something to work around routinely; if a legitimate workflow keeps tripping it, file a bug rather
than leaving the bypass set.

---

### E32 — Crew `pip install` refused: "rule: pip-environment-mutation"

**Symptom:** A crew's Bash/PowerShell command is denied with a message like:

```
Path guard [rule: pip-environment-mutation, BUG-MSO-2026-0816]: refusing `pip install -r requirements.txt` —
pip install/uninstall in crew context changes the ACTIVE Python environment (`C:\Python314`), which is
where the installed Maestro package and this hook run from...
```

**Cause:** This is deliberate. The same environment-confinement guard as E31 (crew write refused
inside the installed package) also recognises
`pip install` and `pip uninstall` (bare `pip`/`pip3`, `python -m pip`, and `pip install -e`) run in
crew context against the Python environment Maestro itself is installed in. It denies them, because
one pip command can remove or replace the installed package under a live fleet. A `pip uninstall`-style
removal of the `maestro` distribution leaves the package directory without its code, and every crew
launch then fails until it is reinstalled. Read-only pip commands
(`pip list`, `pip show`, `pip freeze`, `pip download`) are not affected, and neither is anything
outside crew context.

**Fix:** Install into somewhere other than the active environment:
- **Redirect the install** with `--target <dir>`, `--prefix <dir>` or `--root <dir>`, for example
  under `$MAESTRO_TEMP`.
- **Use a separate virtual environment.** Create it in one command (`python -m venv <dir>`), then run
  pip from it in the next (`<dir>/Scripts/python -m pip install ...` on Windows, `<dir>/bin/...` on
  POSIX). The venv must already exist when the guard checks the command, so both steps cannot share
  one command line.

For LEAD/operator manual recovery, `MAESTRO_PATH_GUARD_BYPASS=1` in the parent shell disables the
guard, as for the installed-package write refusal above.

If the installed package has already been wiped, `mso` itself cannot start. Reinstall the published
wheel, not the source tree, so the licence keyring is preserved (see E30):
`pip install --force-reinstall --no-deps "maestro==<version>"` from your package index, then
`mso licence revalidate`.

---

### E34 — Crew ends as "backend error" (`MODEL_BACKEND_ERROR`)

**Symptom:** `mso status` shows a crew as **backend error**; the lifecycle log has a
`MODEL_BACKEND_ERROR` event; `mso doctor` reports `model.backend-error`. The order
requeues and, after the normal requeue budget, goes `STALLED`. `mso usage` may print
`No model responses: …`.

**Cause:** the model backend rejected every request the crew made, so the crew got no
real model reply. Maestro quotes the backend's own message verbatim in the lifecycle
event and in the order's `operatorNote`, with the backend, region, the model requested
and the model sent. A common Bedrock example is:

```text
API Error 400 The provided model identifier is invalid
```

which means the model id is not available in that region or to your AWS account.

**Fix:**

1. Read the quoted message (`operatorNote` on the order, or the `MODEL_BACKEND_ERROR`
   line in `.mso/logs/lifecycle.log`) and fix the cause: the model pin, the region's
   inference profile, model access in the provider console, or credentials. See
   [MODEL-BACKENDS.md](MODEL-BACKENDS.md); `mso providers test model --live` checks a
   fix without dispatching.
2. Re-run the order: `mso order retry <ORDER-ID>`.
3. For support, attach the diagnostics file whose path the failure printed:
   `.mso/reports/backend-errors/<ORDER>-crew<N>-iter<NN>-<timestamp>.md`. It is
   redacted and excludes the order prompt and credentials.

A network failure is still reported as `NETWORK`, and an unreachable open-weights
endpoint as `BACKEND_UNREACHABLE`; those are not this entry.

---

## Runtime Updates

### E35 — Runtime update held: "the install is broken, so this workspace is deliberately left paused"

**Symptom:** `mso runtime update` (or the Hub's update button) finishes with the outcome **HELD**, the workspace stays **PAUSED**, and its resident LEAD is stopped. `mso runtime status` shows the last job with an outcome such as `FAILED_UPGRADE_HELD`.

**Cause:** the upgrade ran, but the post-upgrade health check could not confirm that the installed package works (for example the version it reports is not the one requested, the licence no longer verifies, or package files are missing). Maestro deliberately resumes nothing in that state, because dispatching against a broken install burns orders' retry budgets on a fault no retry can fix. Nothing was killed: crews that were running when the update began finished normally.

**Step 1 — read what pip said.** `mso runtime status` shows the last update job, including:

- a `PIP:` sentence that says whether pip itself succeeded, and
- pip's exit code and the last lines of its output, indented under `|`.

The Hub's runtime panel shows the same sentence and a collapsible output block. Credentials are redacted from the output before it is stored or shown (the Hub also hides filesystem paths; `mso runtime status` shows them, including the job record's own path), but treat it as sensitive anyway: if your package index URL embeds a token, do not paste `pip config list` output or this block into a public ticket or chat.

| What you see | What it means |
|---|---|
| `PIP:` says pip **installed** the version (exit code `0`) | pip worked. The failure was the health check afterwards, not the download. Go to Step 2. |
| `PIP:` says pip **failed** (non-zero exit), output ends `No matching distribution found` or `Could not find a version that satisfies the requirement` | pip could not find the wheel on the index it used. This is most often a `pip.conf` / `PIP_INDEX_URL` / `PIP_EXTRA_INDEX_URL` setting that points pip at a mirror, proxy or internal index that has not synced the new release. Run `pip config list` on the machine and check the index lines. Point pip at an index that carries the release (public PyPI carries `maestro-fleet`), or wait for your mirror to sync. Then reinstall the target version by hand and resume (Step 2, second bullet): a new `mso runtime update` is refused while a held job exists. |
| `PIP:` says pip **could not be run** | Python's `pip` module is missing or not runnable in the environment `mso` uses. Repair pip for that environment, then re-run the update. |

**Step 2 — check the install before reinstalling anything.** Do not reinstall the old version "to be safe"; that undoes the upgrade and usually fixes nothing.

```bash
mso version
mso licence status
```

- If `mso version` prints the version you expected **and** `mso licence status` prints no warning, the install is sound. Bring the fleet back; this re-checks the install before it resumes anything:
  ```bash
  mso runtime update --resume-only
  ```
- If `mso version` fails, or `mso doctor` reports a missing package marker, the package files are genuinely missing or damaged. Reinstall the **target** version's published wheel (the exact command for your channel is printed in the job's recovery advice in `mso runtime status`), then re-verify the licence and resume:
  ```bash
  pip install --force-reinstall --no-deps "maestro-fleet==<TARGET VERSION>"
  mso licence revalidate
  mso runtime update --resume-only
  ```
  That is the public PyPI package name. A private wheel index carries the package as `maestro`, not `maestro-fleet`: install `"maestro==<TARGET VERSION>"` with `--index-url <your index>` (not `--extra-index-url`) and keep the `==` pin, so pip cannot pick a same-named package from another index. Never reinstall from a source checkout (`pip install .`): it ships no licence keys and drops the install to community tier.
- If `mso licence status` prints a warning, see [E30](#e30--licence-activated-but-maestro-still-runs-at-community-tier).

**If `site-packages` holds a `~aestro` folder and no `maestro` folder (Windows).** pip moves the old package aside as `~aestro` while it reinstalls. If the update was interrupted because a file it had to replace was in use (`[WinError 32]` in pip's output, usually `Scripts\mso.exe`), pip can stop before putting the package back, so `mso` cannot start at all. Do not delete `~aestro` yet: it may be the only good copy. Run the recovery helper that the update left behind. It does not need `mso`, reinstalls the published wheel (or puts the `~aestro` copy back if it cannot reach the index), runs `mso licence revalidate` and `mso version`, and then prints a command to delete the leftovers:

```bash
"<path to python>" -I "%USERPROFILE%\.maestro\runtime-helper\runtime_pip_helper.pyc" recover --job <JOB ID>
mso runtime update --resume-only
```

The exact line for your machine, with the job id filled in, is in the job's recovery advice (`mso runtime status`, or the `operatorAction` field of `%USERPROFILE%\.maestro\runtime-update.json` if `mso` cannot start). Use the `.py` name instead of `.pyc` if that is the file in the folder. Close every other `mso` window first: a running `mso` command holds `Scripts\mso.exe` open. Once the package is back, `mso doctor` lists any remaining `~aestro*` folders under `machine.package-debris` with a delete command.

In releases that include this fix, an update started from the Hub or from `mso runtime update` runs pip in a separate background process, and it does not start pip while another `mso` command is still running. Instead the job ends `FAILED_UPGRADE_RESUMED`, names the process ID and program that has to close, and puts everything back as it was. A failed upgrade is never reported as upgraded.

**If the held update came from 5.20.x or earlier.** Those versions' health check wrongly fails on every released (compiled-only) install, so the hold is usually a false alarm and `mso runtime update --resume-only` on that version refuses for the same reason. Install the target release (5.21.0 or later) by hand with the Step 2 reinstall command, then run `mso licence revalidate` and `mso runtime update --resume-only`: the resume now runs the new release's check, passes, resumes every held workspace and clears the hold, so later updates from the Hub work again.

If you cannot upgrade yet, resume each held workspace by hand instead. Run this in **every** workspace the update held (the update touches every workspace registered on the machine; `mso projects` lists them):

```bash
cd <workspace>
mso resume
mso lead start
```

`mso resume` relaunches the paused dispatcher with the settings it was paused with; `mso lead start` restarts the resident LEAD that the update stopped (Pro and above — skip it on a tier without the resident LEAD). Then confirm with `mso status --once`. This leaves the held job on record, so a new update stays refused until you upgrade and run `--resume-only` as above.

---

## Lifecycle Automation

### E24 — Dispatcher exited on its own — no crash, no error

**Symptom:** `mso dispatch` terminates cleanly with no error message. The lifecycle log shows an `IDLE_REAP` event near the end:

```
IDLE_REAP | all crews idle 30+ min, no pending work — running cleanup and exiting
```

**Cause:** This is **expected behaviour**, not a crash. The idle-watchdog (introduced in v4.3.3) monitors whether all crew slots are idle and no orders are PENDING. When the idle threshold is exceeded (default: 30 minutes) and `action` is set to `"cleanup"` (the default), the dispatcher runs `mso cleanup` and exits cleanly.

**When this is a problem:**

If you expected more orders to arrive but the dispatcher exited before they were queued, the idle threshold may be too short for your workflow.

**Fix:**

Option 1 — Increase the idle threshold:
```json
{
  "completion": {
    "idleWatchdog": {
      "idleMinutes": 120
    }
  }
}
```

Option 2 — Switch to `"warn"` action (logs the idle event but keeps running):
```json
{
  "completion": {
    "idleWatchdog": {
      "action": "warn"
    }
  }
}
```

Option 3 — Disable the watchdog entirely (dispatcher runs until manually stopped):
```json
{
  "completion": {
    "idleWatchdog": {
      "enabled": false
    }
  }
}
```

**When this is correct:**

For batch workflows (queue a set of orders, dispatch, walk away), the idle-exit is exactly the right behaviour — the dispatcher finishes the work and exits without needing a manual `Ctrl-C`. CI pipelines in particular benefit from this: the dispatcher exits with code 0 when work is drained, so the CI step completes naturally.

See LIFECYCLE-AUTOMATION.md for the full idle-watchdog reference.

---

## CLI Error UX

### E25 — Raw Python traceback instead of a friendly error message

**Symptom:** Running an `mso` command produces a raw `Traceback (most recent call last):` dump.

**Cause:** You may be running an older Maestro version (pre-v4.3.9) that did not have the central error handler. Or the error originated in a subprocess-dispatched script (`fleet_usage_tracker.py`, `fleet_runner.py`, `fleet_monitor.py`) before `run_cli()` was wired in.

**Fix:**

1. Upgrade to the latest version:
   ```bash
   pip install --upgrade maestro-fleet
   ```
   Air-gapped / private-index installs: `pip install --upgrade maestro --extra-index-url https://maestrodevs.github.io/simple/` — see [AIR-GAPPED.md](AIR-GAPPED.md).
2. If the traceback persists after upgrading, it is a genuine unexpected error. Re-run with `--debug` to capture the full trace and report it:
   ```bash
   mso --debug <command> [args]
   ```
   Then open an issue at [github.com/tavisbasing/Maestro/issues](https://github.com/Maestrodevs) with the full output.

---

### E26 — `mso usage` fails with "Multiple Claude project directories found"

**Symptom:**
```
[Maestro] Multiple Claude projects match this workspace.
  Hint:
    Specify which one:
      mso usage --project @ACME
    or set MAESTRO_PROJECT=ACME.
```

Or (pre-v4.3.9):
```
RuntimeError: Multiple Claude project directories found matching '*ACME*' ...
```

**Cause:** The Maestro workspace contains more than one Claude project directory that matches the project acronym heuristic. `mso usage` cannot determine which project to report on.

**Fix:**

Pass the project acronym explicitly:
```bash
mso usage --project ACME
# or
mso usage --project @ACME
```

Or set the environment variable to avoid passing it every time:
```bash
export MAESTRO_PROJECT=ACME
mso usage --summary
```

---

### E27 — Mistyped subcommand: "argument command: invalid choice"

**Symptom:**
```
[Maestro] argument command: invalid choice: 'statsu'
  Did you mean: 'status'?
  Run: mso status --help
```

**Cause:** The subcommand was mistyped. The `mso` CLI (v4.3.9+) produces a did-you-mean suggestion using difflib.

**Fix:** Run the suggested command, or run `mso --help` to see all available subcommands.

---

### E28 — "takes no positional argument" / bare project acronym rejected

**Symptom:**
```
[Maestro] 'usage' takes no positional argument 'ACME'.
  Did you mean: mso usage --project ACME
```

**Cause:** A project acronym was passed as a bare positional argument (e.g. `mso usage ACME`) instead of as a flag (`mso usage --project ACME`).

**Fix:** Use the `--project` flag:
```bash
mso usage --project ACME
```

---

## Performance and Resource Usage

### E29 — Machine slows down over time; leftover `find`, build-tool, or compiler-server processes

**Symptom:** The machine running the dispatcher gets progressively slower over a long session, and Task Manager / `ps` shows one or more long-lived `find`, `dotnet`/MSBuild, `VBCSCompiler`, or shell processes that no longer correspond to any active crew — often with a very large cumulative CPU time.

**Cause:** A crew's tool calls can spawn subprocesses (a filesystem search, a build command, a compiler that stays resident between builds) several layers deep. On an older Maestro version, if that crew's iteration ended abnormally — a timeout, a kill, a crash — those subprocesses could be left running as orphans, since nothing tracked them individually. From the version that resolves this note onward, every subprocess a crew spawns, at any depth, is tracked as part of that crew's own process group for the lifetime of the crew, and is terminated as a group the moment the crew's lifecycle ends — normally, on timeout, or on a crash. `mso cleanup` also sweeps any group left behind by a crew that died before it could clean up after itself. If you still see this on a current install, upgrade first (`pip install --upgrade maestro-fleet`) and confirm with `mso version`.

**Fix:** Run cleanup to reap anything still lingering from before the upgrade (or from an edge case the sweep didn't catch):

```bash
mso cleanup
```

This is safe to run at any time and does not affect orders that are genuinely in progress — it only ever terminates processes it can trace back to a specific crew slot, never an unrelated process on the same machine (your editor, a Docker daemon, another project's own dispatcher).

**Note:** A resident compiler server (e.g. `VBCSCompiler`) that is still being reused by a **currently running** crew's build is expected and left alone — this only reaps processes belonging to a crew whose lifecycle has actually ended. If you routinely run several crews concurrently on a resource-constrained machine, consider lowering `--max-crews` as well; reaping orphans prevents runaway accumulation but does not by itself fix a machine that is oversubscribed by legitimate concurrent work.

---

### E33 — `mso cleanup` refuses: "a live dispatcher is running"

**Symptom:** `mso cleanup` prints `Refusing cleanup — a live dispatcher is running (PID N)` and exits non-zero instead of clearing stale state.

**Cause:** `mso cleanup` is deliberately destructive — it force-kills crews and resets their orders to PENDING. If a dispatcher process is genuinely alive and healthy, running that routine underneath it would sabotage its crews while the dispatcher itself survived to immediately re-dispatch into the wreckage, so it refuses outright rather than run partially.

**Fix:** First check whether that dispatcher is actually making progress (`mso doctor` — the `dispatcher.heartbeat` check reports `WEDGED` when a dispatcher's PID is alive but its heartbeat has gone stale, i.e. it is alive but not ticking) or `mso status`.

- **If it's healthy and just busy:** don't run cleanup — stop the dispatcher first (or wait for it to finish), then cleanup if still needed.
- **If it's WEDGED** (alive but not ticking — `mso doctor` flagged it, or you've confirmed by other means it is stuck): use `--force` to proceed anyway. This still force-kills crews and resets their orders to PENDING. `--force` clears `dispatcher.pid` itself only when it can never positively confirm the lock as your real dispatcher (a lock predating the identity-sidecar mechanism, recycled onto some other live pid); a lock it CAN positively confirm — the common case for an actually-wedged dispatcher started under a current install — is deliberately left alone, process included. Don't pre-emptively kill anything: try `mso dispatch` next, and only if it still refuses do you know for certain the lock survived and exactly which PID to remove:
  ```bash
  mso cleanup --force
  mso dispatch --max-crews 5
  # if that still refuses with "Another dispatcher is already running (PID N)",
  # kill exactly the PID it names, then retry:
  taskkill /F /PID <PID>        # Windows
  kill -9 <PID>                 # Linux/macOS
  mso dispatch --max-crews 5
  ```
  Killing only the PID the refusal itself names (rather than guessing one up front) matters because `--force` can also clear a lock that merely *looks* alive due to PID recycling — pre-emptively killing that number could terminate a completely unrelated process that happens to have reused it.

`--force` is specifically the escape hatch for a wedged dispatcher — it is not a general override for a healthy one.

**Same escape hatch covers a recycled `demo.pid`, and now a recycled `dispatcher.pid` too.** If `mso demo` or `mso dispatch` refuses with "another `mso demo` is already running (PID N)" but no demo is actually running, the PID in `demo.pid` was likely recycled by an unrelated OS process after the real demo exited — `is_process_alive()` cannot tell that apart from a genuine live demo. `mso cleanup --force` clears the stale lock the same way it clears a wedged `dispatcher.pid`. The same recycled-PID shape is also handled for `dispatcher.pid` itself when the lock predates the identity-sidecar mechanism — `mso cleanup --force` clears that lock on its own, no manual kill needed, and a plain `mso dispatch` afterward succeeds outright.

---

*Maestro v4.3.9 — If your issue is not listed here, see [SUPPORT.md](SUPPORT.md) for how to get help.*
