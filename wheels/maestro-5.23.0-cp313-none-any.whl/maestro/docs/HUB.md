# Maestro Hub

**New in v5.0.0.** The Maestro Hub is a real-time, multi-workspace fleet
dashboard. Where `mso status` shows one workspace in one terminal, the Hub gives
you a single pane of glass across **every registered project** — live voyages,
orders, crews, queue depth, token usage, the human-review queue, and the
streaming lifecycle log.

The Hub has two pieces:

| Piece | Ships in | What it is |
|-------|----------|------------|
| **Backend** | the `maestro` pip package (`maestro.hub`) | A FastAPI service exposing a versioned REST API (`/api/v1/...`) + a lifecycle WebSocket. Aggregates state from every workspace in the global registry. |
| **Frontend** | a static export **shipped inside the `maestro` wheel** at `maestro/hub/static/` | A Next.js dashboard that reads the backend API. In local mode the backend serves it on the same port — **no Node, no Docker.** (The `maestro-hub/` source is only needed to develop the UI or build the Docker frontend.) |

---

## Quick start

### Local (recommended) — no Docker, no Node

The Hub runs entirely from the pip package. The backend serves the dashboard UI
on its own port, so a fresh device needs nothing beyond `pip install maestro-fleet`:

```bash
mso hub setup          # validates your registered projects + confirms the UI bundle
mso hub start          # backend + dashboard UI on http://127.0.0.1:3847
```

Open <http://127.0.0.1:3847>. That's it — no second process, no Node runtime.
`mso hub setup --mode local` (the default) reports whether the built UI bundle
shipped with your install; a released wheel always includes it. If you installed
from a plain source checkout with no built bundle, the backend runs **API-only**
and `/` returns a message telling you how to build the UI (see
[Troubleshooting](#troubleshooting)).

> **Docker is an option, not a prerequisite.** Prefer Docker only when you want
> the frontend and backend in separate containers (a shared/multi-operator
> server). See [Docker deployment](#docker-deployment) below; otherwise the
> local flow above is all you need.

### Backend detail

There are two ways to run the backend.

**`mso hub start` — managed daemon (Team / Enterprise licence).**

```bash
mso hub start                 # background daemon on http://127.0.0.1:3847
mso hub start --port 4000 --open   # custom port + open a browser
mso hub status                # is it running? (PID + URL)
mso hub stop                  # stop the daemon
```

`mso hub start` is gated to **Team / Enterprise** licences (the Hub aggregates
multiple workspaces, a fleet-scale feature). FastAPI / uvicorn are installed on
first run if missing — or pre-install them with the `hub` extra:

```bash
pip install 'maestro-fleet[hub]'
```

Air-gapped / private-index installs: `pip install 'maestro[hub]' --extra-index-url https://maestrodevs.github.io/simple/` — see [AIR-GAPPED.md](AIR-GAPPED.md).

**`python -m maestro.hub` — direct, ungated (single-operator / dev).**

```bash
python -m maestro.hub --port 3847
```

This runs the same FastAPI app in the foreground with no licence gate — handy for
local development or a single-operator setup. (The write-control endpoints —
dispatch / hold — are still tier-gated at the HTTP layer; see
[Tier gating](#tier-gating).)

### Developing the frontend (optional)

Local mode already serves the built UI from the backend — you only need the
`maestro-hub/` source app if you are **changing** the dashboard. The dev server
runs on its own port and points back at the backend:

```bash
cd maestro-hub
npm install
NEXT_PUBLIC_HUB_URL=http://localhost:3847 npm run dev   # → http://localhost:3000
```

Open <http://localhost:3000>. The frontend polls the backend every few seconds
and subscribes to the lifecycle WebSocket for live updates.

To produce the static bundle the backend serves, run `npm run build` — it writes
`maestro-hub/out/`; copy that to `maestro/hub/static/` (the release/publish
workflow does this automatically before building the wheel).

### Docker deployment

Docker runs the frontend and backend as **separate containers** — useful for a
shared or multi-operator server, but not required for a single operator (use the
[local flow](#local-recommended--no-docker-no-node) instead). Generate your
device-local mounts, then bring the stack up:

```bash
mso hub setup --mode docker
docker compose -f docker/docker-compose.yml -f docker/docker-compose.local.yml up -d --build
```

The frontend container is a Next.js server build (`next start`) whose backend URL
is baked at build time via the `NEXT_PUBLIC_HUB_URL` compose build-arg. If you
change the port or bind address, rebuild the frontend container so the baked URL
matches.

---

## Provisioning: `mso hub setup`

**New in v5.2.0.** `mso hub setup` provisions the Hub from **your own** project
registry (`~/.maestro/projects.json`) — no hand-editing of config, no machine
paths committed anywhere. It has two modes, and it only ever *reads* your
registry: there is no new config surface to learn.

```bash
mso hub setup                          # local mode (default) — validate + print start command
mso hub setup --mode docker            # generate the Docker deployment config
mso hub setup --mode docker --dry-run  # preview both generated files, write nothing
mso hub setup --mode docker --force    # regenerate over existing generated files
```

Like `mso hub start`, `mso hub setup` needs a **Team / Enterprise** licence.
`mso hub stop` / `mso hub status` and the direct `python -m maestro.hub` entry
point stay ungated. If no projects are registered, setup stops with a hint to run
`mso init` first.

### Local mode (default) — no Docker

Local mode is the fast path: the native backend reads `~/.maestro` directly, so
there is **nothing to generate**. Setup validates the registry — checking that
each registered workspace path exists on this machine — **and confirms the
statically-exported dashboard UI bundle shipped with this install** (a released
wheel bundles it at `maestro/hub/static/`), then prints the start command:

```bash
mso hub setup     # → lists each project [ok]/[MISSING], reports the UI bundle, then:
mso hub start     # backend + dashboard on http://localhost:3847
```

A `[MISSING]` line means a registered workspace path is absent on this device;
the Hub simply won't show that project until the path is present. Setup also
reports the UI bundle: `[ok] Hub UI bundle present: …` when the built dashboard
shipped (so `mso hub start` serves the UI + API on one port), or `[MISSING] Hub
UI bundle not found …` when it did not — the backend then runs **API-only** until
you install a released wheel or build the UI from source
(`npm ci && npm run build` in `maestro-hub/`, then copy `out/` to
`maestro/hub/static/`). Nothing is written to disk in local mode.

### Docker mode — generate the deployment overlay

Docker mode generates the two **device-local** files the containerised Hub needs,
translating every host path in your registry into a container path
(`/repos/<basename>`):

| Generated file | What it is |
|----------------|------------|
| `docker/maestro-home/projects.json` | The container's copy of your registry, with every path field (top-level `path` / `productRepo` / `artefactRoot` **and** each nested `repos[].path`) rewritten to its `/repos/…` container path. `legacyAcronyms` / `artefactMode` and all other fields are preserved verbatim. |
| `docker/docker-compose.local.yml` | A Compose **overlay** whose `volumes` list bind-mounts each host repo to its container path. Compose merges it *additively* onto the tracked, host-path-free base file. |

Then setup prints the deploy command:

```bash
docker compose -f docker/docker-compose.yml -f docker/docker-compose.local.yml up -d --build
```

**Both `-f` files, always** — the tracked `docker/docker-compose.yml` carries no
host paths; the generated overlay supplies your workspace mounts. Run the command
from the repo root.

**Path handling.** Windows paths are normalised to forward slashes (Docker
Desktop accepts `C:/…`). Each host path maps to `/repos/<basename>`; if two
*different* host paths share a basename, the second gets a deterministic `-2`
(then `-3`, …) suffix and setup prints a warning naming both paths.

**Where the files land.** `--output-dir` defaults to the repo `docker/` directory
when a `docker/docker-compose.yml` is found by walking up from the current
directory; otherwise it falls back to `MAESTRO_HOME/hub-docker/` (for wheel-only
installs — building the images still needs the repo). Pass `--output-dir DIR` to
choose explicitly.

### Device-local, regenerable, never committed

Both generated files are **device-local and gitignored** — they carry your real
machine paths and must never be committed. Regenerate them at any time with
`mso hub setup --mode docker --force`; without `--force`, setup refuses to
overwrite existing generated files (so an accidental re-run can't clobber your
config). Use `--dry-run` to print exactly what *would* be written without
touching disk.

The tracked base — `docker/docker-compose.yml` and
`docker/maestro-home/projects.json.example` — stays generic and host-path-free,
so the repository can be shared without leaking any machine layout.

---

## What the Hub shows

- **Workspace overview** — one card per registered project: dispatcher
  running/stopped, active crews, active voyages, queued orders, pending reviews.
- **Voyage view** — voyages grouped into **Active / Proposed / Completed**
  accordions, each with a role-pipeline (PLN → BLD → TST → …) chip strip, the
  repo + worktree path, and a dependency-graph (DAG) of the orders.
- **Crew panels** — per-slot status, current order, iteration, activity age, PID.
  The crew drawer's **Reasoning** section shows the running crew's reasoning
  live: **Model reasoning** (a digest per turn; **Show full text** expands it)
  in one lane, **Activity — Maestro steps and tool calls** in another. When
  reasoning capture is off, or an iteration's reasoning file is full, the
  Activity lane falls back to the crew's `activity.jsonl`: those rows carry an
  **activity log** marker and a notice says why. See
  [REASONING.md](REASONING.md#when-capture-is-off-or-the-file-is-full-the-activity-log-fallback).
- **Order reasoning** — the order drawer's **Reasoning** tab: everything
  recorded for the order, grouped by role, lap and iteration, the same review
  as `mso reasoning show`. Read-only and not tier-gated; every Hub user can see
  it. See [REASONING.md](REASONING.md).
- **Project status** — a panel on the overview page, directly above **Token
  usage · cross-project**: one row per project with a state chip (**Live**,
  **Paused**, **Stopped** or **Off**), the latest status-update verdict and its
  age, and **More / Less** for the rest of that update and the three before it.
  A project's own page has a **Status updates** history (newest 50). Read-only
  and not tier-gated. See [STATUS-UPDATES.md](STATUS-UPDATES.md).
- **Judge** — a page in the sidebar between **Review** and **Reports**: the
  docket of the [Judge](JUDGE.md), its agreement with you, and its hard limits.
  Read-only in this release; see [The Judge page](#the-judge-page).
- **Token usage** — cross-project token totals and estimated cost on the
  overview page; per-voyage badges on workspace detail; a dedicated **Token
  Usage report** at `/reports/usage` with drill-down (project → voyage → order →
  role) and CSV export. All surfaces read from `.mso/usage/orders/`.
- **Reports** — a catalog at `/reports` of five read-only reports built from
  your workspaces' real artefacts: QA, Token Usage, Acceptance Criteria,
  Security Review and Voyage Summary. A result that was never recorded, or
  could not be read, is shown as exactly that — never as a pass or a zero. See
  [Reports](#reports).
- **Board buckets: In Review / Needs Attention / Blocked / Skipped** — every
  workspace board classifies its orders into these four lanes (alongside the
  ordinary In Progress / Backlog lanes) instead of leaving review-gated work
  indistinguishable from ordinary backlog. Approve / decline / request-change
  are one click away, inline, without leaving the board. See
  [Board buckets and inline review actions](#board-buckets-and-inline-review-actions).
- **`/review` page** — every order across every registered project that needs
  a human decision or a recovery action, grouped into the same four
  categories, each with its category-correct action. See
  [The /review page](#the-review-page).
- **Voyage inspection & retry** — a COMPLETE voyage's plan, handoffs, and
  reports are viewable read-only from the board; a stranded order gets a
  one-click **Retry**; a PENDING voyage shows a copy-able dispatch command.
  See [Voyage inspection & retry](#voyage-inspection--retry).
- **Captain Chat** — a durable, per-workspace conversation with the resident
  LEAD, hosted as a **Chat** tab in the LEAD drawer. The LEAD raises a question
  when a patrol tick needs a human; you can also ask it things on demand and it
  answers with bounded, read-only reasoning. Nothing it writes *does* anything —
  every effect leaves the panel through an explicit Confirm on a card that shows
  the exact verb, or the exact decision record. See
  [Captain Chat](#captain-chat).
- **Live lifecycle stream** — the dispatcher's `lifecycle.log` events as they
  happen, scopeable to a single workspace.
- **Authoring** — create voyages and orders, attach an order to a voyage, edit
  an order that is not yet in flight, and skip/restore one, all from the board
  (tier-gated). The Hub is deliberately **not** a full replacement for `mso`:
  see [Authoring](#authoring-creating-and-editing-work-from-the-hub) for the
  capability table *and* the boundary — which verbs stay CLI-only, and which
  command to reach for instead.
- **Dispatch / Hold controls** — start or stop a workspace's dispatcher from the
  UI (tier-gated; see below).
- **Housekeeping sweep** — a broom button that clears voyages whose PR you have
  already merged, with a preview first. See
  [Housekeeping sweep](#housekeeping-sweep).
- **Multi-repo pills and badges** — for a workspace configured with a multi-repo `repos` map, the
  Hub shows per-repo PR pills on voyage cards, a per-repo review-and-merge CTA in the Final Review
  strip, and a repo badge on every order row/drawer. Single-repo workspaces are unaffected. See
  [MULTI-REPO.md](MULTI-REPO.md#the-hubs-multi-repo-ui) for the full breakdown.
- **`claimedBy` badges** — for a shared-mode (corporate) workspace, an order currently claimed by
  another engineer's dispatcher shows who claimed it and when. See
  [ARTEFACT-REPO.md](ARTEFACT-REPO.md#corporate-shared-mode).
- **Stale-Hub badge** — the Topbar polls `/health` every 30s and shows a badge when the running
  process's own version doesn't match what's actually installed — a long-running daemon still
  serving pre-restart code, which otherwise shows up only as confusing 404s on routes the running
  process predates. Restart the Hub daemon (`mso hub stop && mso hub start`) to clear it.

---

## How workspaces appear in the Hub

The Hub reads the **global project registry** at `~/.maestro/projects.json`. Any
workspace registered there shows up automatically. Workspaces are registered when
you run `mso init` / `mso dispatch` in them, or you can manage the list with:

```bash
mso projects list             # show registered workspaces
mso projects remove <ACRONYM> # drop one from the registry
```

If the Hub shows a workspace you no longer use (or is missing one you do), prune
or re-register it via `mso projects`.

---

## Board buckets and inline review actions

Every workspace board classifies its orders with the workspace-parameterised
**attention classifier** (`maestro/hub/attention.py`) into exactly one of four
categories, plus the ordinary In Progress / Backlog lanes:

| Bucket | Source | Verb | Action |
|--------|--------|------|--------|
| **In Review** | `NAV_REVIEW_PENDING` orders (`queues/review/*.json`) | Authorising | Approve / Request change / Decline |
| **Needs Attention** | Stranded orders — `CONVERGENCE_FAILED`, `BLOCKED`, `AUTO_SERIALIZE`, `ESCALATED`, `STALLED`, `VERIFY_FAILED`, `FAILED` | Unsticking | Retry |
| **Blocked** | Dependency-held orders (`.mso/state/dep-holds.json`) | — | Informational; shows the blocking order id |
| **Skipped** | Orders on the operator skip list | — | Unskip. Collapsed by default — findable, but never counted in "Needs you". |

An order carries **at most one** attention tag — it renders in exactly one
bucket, never zero and never two. The classifier is computed **per
workspace** (not globally), so the Hub's multi-workspace poller never leaks
one workspace's held orders into another's counts. The workspace card and
sidebar show one rolled-up **"Needs you: N"** figure — In Review plus Needs
Attention, excluding Blocked and Skipped.

Before this classifier existed, a review-gated order rendered under
**Backlog**, indistinguishable from ordinary unstarted work — the operator
had no way to see, from the board, that something was waiting on them.

### Inline actions

Opening any **In Review** order's drawer replaces the ordinary edit form with
a **review action bar**: Approve, Request change, and Decline. Request
change and Decline both require a non-empty note (never optional) before
their Confirm button enables. These call the exact same
`POST /api/v1/review/{id}/{approve,revise,reject}` endpoints — and therefore
the same `review_core` implementation — as the [`/review` page](#the-review-page)
and `mso review approve|revise|reject`; there is no second, competing
mutation path.

A **Needs Attention** order's drawer instead shows a **Retry** button, enabled
only for a genuinely stranded order — disabled, with the CLI's own `--force`
hint text, for a `COMPLETE` order. There is no `--force` control in the UI;
force-retrying a completed order is a deliberate CLI-only action.

---

## The /review page

`/review` (linked from the sidebar) is the cross-workspace view of the same
four categories, spanning **every registered project** — not just the
workspace you happen to be looking at. Four tabs, same names and order as the
board's lanes: In Review / Needs Attention / Blocked / Skipped. Each tab
offers its category-correct action (the same review action bar, Retry,
informational, or Unskip), backed by `GET /api/v1/attention/queue`.

Acting on an item removes it from its category on the next poll — the tag
clear happens server-side, not as an optimistic UI-only update, so a
retried or unskipped order does not silently reappear in its old category.

---

## The Judge page

`/judge` (the **Judge** item in the sidebar, between **Review** and **Reports**)
shows the [Judge](JUDGE.md), the decision agent that runs inside the resident
LEAD. In this release the Judge only watches, and the page is **read-only**:
there is no Approve, Hold, Overturn or rule-editing control on it.

| Tab | Shows |
|-----|-------|
| **Docket** | Sub-tabs **Pending**, **Shadow**, **Escalated** and **Decided**. An Escalated row shows the Judge's recommendation and an **Open in Review →** link. The link opens the review queue; it does not preselect the order yet |
| **Agreement** | The agreement rate per decision kind next to "agreed of resolved" and a disagreed count, then the list of disagreements. With no resolved items the rate reads `—`, never `0%` |
| **Hard limits** | The limits the Judge can never cross, as a list with no controls |

A **workspace** selector (from `?workspace=`, otherwise the first registered
workspace) and a **kind** filter apply to the tabs. The page refreshes itself
every 15 seconds. A refusal (for example below Pro) is shown as an alert, never
as an empty docket.

The Judge's title follows the workspace's [persona](PERSONAS.md#the-judges-title).

**LEAD panel line.** A workspace's LEAD panel gains one line when the Judge has
a status to show:

```
Judge: on — plan.approve=shadow, 3 pending, 1 escalated
```

Modes that are `off` are left out, and when the Judge is off the line names the
reasons. "pending" counts the Pending and Shadow tabs; "escalated" counts the
Escalated tab. Clicking the line opens `/judge` for that workspace. Nothing is
shown when the status is unknown or refused.

**Tier and capability.** The Judge routes use the same licence as the resident
LEAD: **Pro, Team or Enterprise**, checked first and failing closed. In a
governed workspace the viewer also needs `judge.docket.view` (the hard-limits
panel needs `judge.rules.view`). Below the tier the routes return `403` with the
upgrade reason.

---

## Capability preflight

Before this feature, an unavailable action (dispatch on a containerised Hub,
housekeeping without `gh`) was only discoverable by clicking it and reading a
`409`. `GET /api/v1/capabilities` inverts that: it declares, before any click,
whether Dispatch / Sweep / Review / Order-retry / the four
[authoring](#authoring-creating-and-editing-work-from-the-hub) actions can
actually work in **this** deployment, and separately whether the caller's
licence tier permits mutating control actions at all.

```json
{
  "dispatch":     {"available": false, "reason": "This Hub runs in a container and cannot launch a usable dispatcher. Run `mso dispatch` from a host session."},
  "sweep":        {"available": true,  "reason": null},
  "review":       {"available": true,  "reason": null},
  "orderRetry":   {"available": true,  "reason": null},
  "voyageCreate": {"available": true,  "reason": null},
  "orderCreate":  {"available": true,  "reason": null},
  "orderEdit":    {"available": true,  "reason": null},
  "orderSkip":    {"available": true,  "reason": null},
  "settingsWrite":       {"available": true, "reason": null},
  "deviceSettingsWrite": {"available": true, "reason": null},
  "tier":         {"control": true,    "reason": null}
}
```

`settingsWrite` and `deviceSettingsWrite` cover the two
[settings](#settings-workspace-and-device) `PUT`s. Like the authoring fields,
they default to `available: false` with a reason. Unlike every other field,
their live value **folds in the licence tier**: settings writes need Pro or
above, where `tier.control` needs Team or above. A Pro seat therefore sees
Save enabled even though `tier.control` is `false`. After the tier, an
observe-only deployment is refused. The reason string is the same one the
endpoint returns.

The four authoring fields — `voyageCreate`, `orderCreate`, `orderEdit`,
`orderSkip` — are the mechanism the authoring surface was built on, and they
behave differently from the four above them in two ways worth knowing:

- **They default to `available: false` with a reason.** Every other field
  defaults to available. An authoring control has no backing endpoint until one
  ships, and a control with no endpoint must never render enabled — so the
  honest posture here is the *zero-configuration* one. A field an older Hub build never populates
  reports "unavailable, and here is why", not "go ahead".
- **They report a plane-writability probe, not just endpoint existence.** A
  read-only artefact mount is a real deployment, so these fields test that
  `voyages/` and `queues/` are actually writable. That refusal takes
  precedence over any other: an existing endpoint is not a writable
  directory. `available` is derived from the *same* probe the endpoint fails
  on, never asserted independently of it.

Unlike `dispatch`, authoring is **not** blocked by container mode: writing
order and voyage JSON is a file-plane mutation, not a process spawn — the same
reasoning that makes `review` and `orderRetry` available in a container.

The frontend contract: an unavailable action renders **disabled**, with
`reason` as its tooltip (and, for the primary Dispatch action, as inline
helper text too). While `/capabilities` is loading, every mutating action
renders disabled — never enabled-and-hopeful. The server-side `409`/`403`s on
the underlying endpoints remain as a defence-in-depth backstop, not the
primary mechanism — the reason strings on both sides are the exact same
server-side constants, so the explanation the button shows before the click
and the one the API returns if it happens anyway can never disagree.

`review` and `orderRetry` are workspace-independent by design and currently
always report `available: true` for a non-governed deployment (both are
file-plane mutations — see [Housekeeping sweep](#housekeeping-sweep)'s "file
plane vs process spawn" distinction, which applies identically here). In a
**governed** workspace, a caller who fails the `voyage.approve` or
`order.dispatch` capability check is still correctly refused server-side
(`403`) — `/capabilities` does not yet widen to a per-workspace,
per-operator preflight for that case, so the governed refusal currently
surfaces as a `403` after the click rather than a disabled button before it.

---

## Authoring: creating and editing work from the Hub

**New in v5.13.0.** Earlier Hub releases were a read-and-recover surface: they
could show you the fleet, approve a review gate, retry a stranded order and
sweep merged voyages, but every act of *authoring* — filing a voyage, filing an
order, changing one — was a CLI-only verb. The Hub now authors too, and this
section says exactly how far that goes.

**Start with the boundary, because it is the more useful half.** The Hub does
not do everything `mso` does, and it never will. The table in
[What the Hub does and does not do](#what-the-hub-does-and-does-not-do) is the
authoritative list; the rule that makes a partial surface safe is in
[The honesty rule](#the-honesty-rule-no-control-claims-what-it-cannot-verify).

### What you can do

| Action | Where | Endpoint |
|--------|-------|----------|
| **Create a voyage** | **New voyage** button → drawer | `POST /api/v1/workspaces/{id}/voyages` |
| **Create an order** — type, priority, target role, role sequence, acceptance criteria, `dependsOn`, `targetRepo`, lane | **New order** button → drawer | `POST /api/v1/workspaces/{id}/orders` |
| **Attach the new order to a voyage** | the same drawer's Voyage field | folded into the create call |
| **Edit an order that is not in flight** — title, description, priority, role, sequence, dependencies, acceptance criteria | order drawer → **Save** | `PATCH /api/v1/orders/{id}` |
| **Withhold an order from dispatch** | order drawer → **Remove** | `POST /api/v1/orders/{id}/skip` |
| **Return a skipped order to the queue** | order drawer, or `/review`'s **Skipped** tab | `POST /api/v1/orders/{id}/unskip` |
| **Approve / request change / decline** a review gate | board **In Review**, `/review` | `POST /api/v1/review/{id}/{approve,revise,reject}` |
| **Retry** a stranded order | order drawer | `POST /api/v1/orders/{id}/retry` |
| **Dispatch / Hold / Sweep** | workspace control row | `POST .../dispatch`, `.../stop`, `.../sweep` |
| **Pause / Resume** the fleet — drain (running crews finish, no new work), then resume | workspace control row | `POST .../pause`, `.../resume` |

Every one of those is **tier-gated to Team / Enterprise** and declared in
advance by [`GET /api/v1/capabilities`](#capability-preflight) — a control you
cannot use renders disabled *with the server's own reason*, before you click
it.

### Creating a voyage

The drawer asks for a title and an optional description. It does **not** ask
for an ID, a branch, or a status, and each omission is a decision:

- **The ID is allocated server-side and read back off the file that was
  written.** The drawer shows `assigned on create` until the response arrives,
  then renders the ID the server reports. Nothing in the browser computes an
  ID. (The previous drawer did: it regexed `max()+1` over the voyages the
  browser happened to be holding, which cannot see `voyages/complete/`, cannot
  lock, and is stale by one poll interval.)
- **The branch is named, not created.** The manifest records
  `voyage/{VOY-ID}`; the branch itself is created **on the remote** by the
  dispatcher at first crew dispatch. **No `git` command runs in the Hub
  process** — an HTTP handler that switches the operator's working tree from a
  background daemon is the sharpest form of the
  `CONVERGENCE_PRIMARY_PROTECTED` bug class, and it is unnecessary, because
  the dispatcher already creates the branch when it needs it.
- **The status is always `PLANNED`,** byte-identical to `mso voyage create`.
  There is no Planned/Active choice, because `voyage.status` gates no dispatch
  anywhere in the engine — offering the choice would have offered nothing.
  What actually starts work is **a `PENDING` order plus a running
  dispatcher**, and both are already explicit and already visible elsewhere in
  the Hub.

**A voyage with no orders never runs** — there is nothing for the dispatcher's
queue scan to find, at any status. So when you give a description, the drawer's
**Also create a planning (PLN) order from this description** checkbox is
**checked by default**: the same request files a `PENDING` PLN order carrying
the description and attaches it to the new voyage, and the planner runs on the
next dispatch. The response names the order it filed.

- **Opting out** (unchecking the box, or leaving the description blank) creates
  an empty voyage on purpose. The drawer's summary says so in warning colour,
  and the response message says nothing will run until an order is filed into
  it.
- **No partial success.** If the planning order cannot be filed, the voyage is
  rolled back too and the request fails, naming why — you are never told a
  voyage was created while the order you asked for was not.
- `mso doctor` backstops every other route to an empty voyage with the
  `voyages.no-orders` check, which reports any active voyage that has had no
  orders for over an hour (configurable via its `ageMinutes` parameter).

### Creating an order

The drawer's vocabulary is served by
`GET /api/v1/workspaces/{id}/order-defaults` — the workspace's own order
types, roles, priorities and creatable statuses, resolved through the same
functions the create path itself calls. Two consequences:

- **The type list is the workspace's, not a hard-coded one.** A division pack
  that defines extra order types shows them here. (The old drawer hard-coded
  four, one of which — `HANDOFF` — was not an order type at all.)
- **The role picker is constrained, never free-form.** You choose from the
  order type's resolved `roleSequence`, so a picker cannot express a
  combination the create path would refuse. This matters more than it looks: a
  half-valid sequence gates against nothing, and the role-sequence gate then
  blocks dispatch on a prior role that will never complete.

**Role codes are normalised to the canonical set**
(`PLN`/`BLD`/`TST`/`DOC`/`SEC`/`REL`) on write. Legacy nautical aliases
(`NAV`/`SHP`/`BOS`/`SCR`/`LKT`/`COX`) are accepted as *input* from any surface
and stored canonically.

**Lane** files a real `status`: In Progress → `PENDING`, Backlog →
`BACKLOG`. An order with unsatisfied `dependsOn` can also be filed
`PROPOSED`, which the dispatcher releases to `PENDING` via the `AUTOQUEUE`
event once its dependencies complete.

If you name a **Voyage**, the order is added to that voyage's `orders[]` as
part of the same request, and `voyageBranch` is taken **from the manifest** —
never from the browser. The two writes cannot leave an orphan between them:

1. the voyage is resolved **before** any ID is allocated, so an unknown (404)
   or archived (409) voyage costs nothing and burns no sequence number;
2. a failed attach **removes the order it just wrote** and raises.

### Editing, and what Remove actually does

**Save** (`PATCH /api/v1/orders/{id}`) works only on an order that is not in
flight — `PENDING`, `BACKLOG` or `PROPOSED`. Editing a `RUNNING` order returns
`409` and mutates nothing, and the refusal is raised **before the file is
opened for writing**. The drawer also disables its own form for those
statuses, but that is UX; the rule that matters is server-side, in the core
that `mso` and the Hub share.

**Remove is a skip, not a delete.** The order file stays exactly where it is,
`config/skipped-orders.json` is what changes, and the dispatcher stops picking
the order up from its next tick. It is reversible from the same drawer, from
`/review`'s **Skipped** tab, or with `mso order unskip`. The Hub says so in
the confirmation dialog. Deletion is deliberately not offered anywhere in the
Hub — see the boundary table below.

### What the Hub does and does not do

The full authoring inventory, with each deferred verb named as the CLI command
that does the job today. **An operator who knows a verb is CLI-only will use
the CLI; one who assumes the Hub can do everything looks for a button that is
not there and concludes the Hub is broken.** That is why this table is
published here rather than left implied by the UI.

| # | Capability | In the Hub? | How |
|---|-----------|-------------|-----|
| 1 | Create a voyage — and, by default, a PLN planning order from its description | Yes | **New voyage** |
| 2 | Create an order (type, role, priority, `targetRepo`, acceptance criteria) | Yes | **New order** |
| 3 | Attach an order to a voyage on creation | Yes | the create drawer's Voyage field |
| 4 | Set `dependsOn` | Yes | create + edit |
| 5 | Choose a `roleSequence` | Yes — *constrained* to the type's own sequence, never free-form | create + edit |
| 6 | Edit an order not yet in flight | Yes — `PENDING`/`BACKLOG`/`PROPOSED` only | order drawer → **Save** |
| 7 | Reprioritise | Yes (a field of #6) | order drawer → **Save** |
| 8 | Skip / unskip an order | Yes | **Remove** / **Restore** |
| 9 | Promote a `BACKLOG`/`PROPOSED` order to `PENDING` | Yes — the order must already be on a voyage | order drawer → **Promote to Pending** |
| 10 | Attach an existing (voyage-less) order to a voyage | Yes — writes the order and the voyage manifest together, or neither; an order already on a *different* voyage is refused | order drawer → **Attach**, or `mso order attach <ORDER-ID> --voyage <VOY-ID>` |
| 11 | Retry a stranded order | Yes | order drawer → **Retry** |
| 12 | Approve / request change / decline | Yes | board **In Review**, `/review` |
| 13 | Dispatch / Hold / housekeeping sweep | Yes | workspace control row |
| 13a | Start / stop / restart the resident LEAD daemon | Yes — Start and Restart need a Team or Enterprise licence and a native (non-observe-only) Hub; Stop is never tier-gated | LEAD strip / LEAD drawer — the same `maestro.lead.control` core as `mso lead start\|stop\|restart` |
| 13b | Pause (drain) / resume the fleet | Yes — needs a Team or Enterprise licence and a native (non-observe-only) Hub, since the request must name the live dispatcher process | workspace control row: **Pause** beside **Hold dispatch**; **Cancel pause** while draining; **Resume** when paused — the same `maestro.core.fleet_pause` core as `mso pause` / `mso resume`. Hold still means *stop now* (kill + salvage); Pause lets running crews finish. `mso pause --wait` has no Hub equivalent |
| 14 | **Detach an order from a voyage manifest** | **No** | `mso order remove <ORDER-ID> --from-voyage <VOY-ID>` |
| 15 | **Archive a voyage manually** | **No** | `mso voyage reconcile` — or the Hub's **broom**, which archives on verified PR-merge evidence |
| 16 | **Edit a voyage's title / branch / manifest wholesale** | **No** | edit the manifest under `.mso/voyages/active/` |
| 17 | **Park a voyage** | **No** | not implemented anywhere yet — park the *orders* instead (`mso order skip`, or **Remove**) |
| 18 | `mso order retry --force`, `mso cleanup`, `mso migrate …`, `mso licence …`, anything writing `.mso/state/` | **No — permanently** | the CLI, from a host session |
| 19 | Change workspace and device settings | Yes — registry keys only, **Pro+** | workspace **Settings** drawer; sidebar **Settings** page. See [Settings](#settings-workspace-and-device) |
| 20 | **Change a workspace's repositories** | **No** — shown read-only | `mso migrate import-workspace` ([MULTI-REPO.md](MULTI-REPO.md)) |
| 21 | Talk to the resident LEAD — ask about fleet state, answer its questions | Yes — **Pro+** to read, **Team/Enterprise** to post | LEAD drawer → **Chat** tab. See [Captain Chat](#captain-chat) |
| 22 | Run a LEAD-proposed verb from chat | Yes — via **Confirm** on the proposal card | Exactly the closed verb set the drawer's **Run** button offers, never more. Chat adds no verb |
| 23 | Record a **Captain Decision** from chat | Yes — via **Confirm** on the decision card; refused in a **governed** workspace (no per-request verified Hub identity) | `mso lead chat decide <CHAT_ID> … --confirm`, which is also the governed-mode route |
| 24 | **Merge, tag or publish** from chat; **edit source code** from chat; make a recorded decision **bypass a gate** | **No — permanently** | No such verb exists in the closed list, the chat model has no write or shell tools, and nothing in the engine reads `captainDecisions[]`. See [A confirmed Captain Decision is evidence](#a-confirmed-captain-decision-is-evidence-not-a-gate-change) |
| 25 | **See a co-operator's chat thread from another machine** | **No** | The thread is device-local (`.mso/state/`), like the LEAD daemon itself. Decisions are shared, because they land on the git-tracked artefact. See [The thread is device-local](#the-thread-is-device-local) |

After #1–#13 you can run a voyage end to end from the Hub — create it, fill
it, pull backlog orders onto it and promote them, order the work with
dependencies, dispatch it, clear its review gates, retry what strands, sweep it
closed — without opening a terminal.

**Promote is a status edit, not a dispatch (#9).** It sends
`PATCH /orders/{id}` with `{"status": "PENDING"}` — the same endpoint and the
same `orderEdit` capability as **Save** — and makes the order *eligible*; the
dispatcher still picks it up on its own tick, and an unmet `dependsOn` still
holds it (`DEP_HELD`). The button is disabled for an order with no voyage,
because a `PENDING` order with no voyage has no branch to dispatch onto: attach
it first (#10), then promote, in the same drawer.

**Attach (#10) is not a PATCH field.** Voyage membership lives in two files —
the order's `voyageId`/`voyageBranch` and the manifest's `orders[]` — and
writing one without the other strands the order. `POST /orders/{id}/attach`
(and its CLI twin `mso order attach`) go through one shared core,
`maestro/core/order_attach.py`, which writes both or restores the order file.
The branch always comes from the manifest. Moving an order *between* voyages is
still detach (#14, CLI-only) followed by attach.

**Why #14–#17 are deferred, specifically:**

- **Detach (#14)** and **manual archive (#15)** collide with the
  completion-truth machinery. `mso order remove --from-voyage` couples
  manifest removal to the skip list *because* removing an order from a
  manifest without skipping it strands it. Manual archive is worse: the sweep
  archives on **verified PR-merge evidence**, and a button that archived on
  operator assertion would be a false-finish generator. The Hub already has
  the honest version of #15 — the broom, which previews first and reports what
  it refused to touch, with reasons.
- **Wholesale voyage edit (#16)** — the `branch` field is load-bearing (the
  pretool branch guard denies any git mutation targeting anything else).
  Editing it after a crew has run is a corruption, not an edit.
- **Park (#17)** would need a real `HELD` voyage status in the engine, which
  does not exist yet. Since `voyage.status` gates no dispatch, a "park" built
  on it would be a second inert control.

#### One honest limit worth knowing

`mso order create --voyage VOY-…` writes the order's `voyageId` but **does not
add it to that voyage's `orders[]`**. The Hub's create endpoint does. An order
missing from its voyage's manifest is invisible to that voyage — the
completion guard reads the manifest — so it looks filed and can produce a
false finish later. Until the attach moves into the shared core, either use
the Hub for voyage-attached orders, or follow a CLI create with
`mso voyage status <VOY-ID>` and add the entry by hand. A strict `xfail` in the
parity suite holds this asymmetry visible and will fail loudly the day it is
closed.

### The honesty rule: no control claims what it cannot verify

Every mutating control in the Hub is **disabled until its backing endpoint is
confirmed available**, and every success message is **derived from the server's
response, never from your own input**. A button that looks ready is ready, and a
message saying something was created means the server said so.

That guarantee does not rest on each handler being written carefully. Four rules
hold it structurally:

1. **A drawer may not own a mutation.** Drawer components import nothing that
   reaches the network; the call is injected by the page. A component that
   cannot reach the network cannot fake a network result.
2. **One helper owns every success/failure branch.** The success toast is
   raised only from a *resolved* value, its text is derived from the server's
   response (never from the operator's own input), a rejection surfaces the
   server's own message, and the board refresh runs only on success — a
   refresh after a failed mutation is a second, quieter lie.
3. **A test registry enforces it.** One parameterised sweep over every
   mutating control asserts both polarities: with the backend refusing, no
   success toast is raised; with it succeeding, the message carries the ID
   **from the response body**. A new dishonest control fails by construction —
   it cannot be added without deleting a registry entry, and that deletion is
   visible in review.
4. **An unknown capability renders disabled.** While `/capabilities` has not
   answered, and for any capability field a build does not recognise, the
   control is disabled with a reason — never enabled-and-hopeful.

The backend half: every authoring endpoint allocates and writes inside one
lock, returns the ID **read back from the file it wrote**, and has no
partial-success `200`. A refusal — `400` validation, `403` tier or capability,
`404` unknown voyage, `409` archived voyage or in-flight order, `503`
read-only plane or stale mount — leaves **no artefact behind**.

### One implementation per verb, shared with the CLI

Every authoring action above runs the **same code** as its `mso` equivalent.
This is not a style preference. Two independent copies of a verb drift, and the
drift is invisible from either side — reading one implementation tells you
nothing about where the other one differs. For a lifecycle verb the cost of a
divergence is not cosmetic: a review flow that skips its lifecycle event can
strand an order with no way back. Sharing the implementation removes the class
rather than auditing for it.

| Verb | Shared core | Callers |
|------|-------------|---------|
| Create / load / attach / detach a voyage | `maestro/core/voyage_core.py` | `mso voyage create`, the Slack bridge, `POST .../voyages` |
| Create / edit an order | `maestro/core/order_create.py` | `mso order create`, `mso bug`, the Slack bridge, `POST .../orders`, `PATCH /orders/{id}` |
| Allocate an ID | `maestro/core/order_ids.py` | all of the above — one lock, one sequence space per workspace |
| Approve / revise / reject | `maestro/core/review_core.py` | `mso review …`, the board, `/review` |
| Retry | `maestro/core/order_retry.py` | `mso order retry`, `POST /orders/{id}/retry` |
| Skip / unskip | `fleet_runner.add_skipped_order` / `remove_skipped_order` (reads via `maestro/core/skip_list.py`) | `mso order skip`/`unskip`, `POST /orders/{id}/skip`/`unskip` |
| Housekeeping sweep | `fleet_runner.run_housekeeping_sweep` | `mso voyage reconcile`, the broom |
| Post / read a [Captain Chat](#captain-chat) message | `maestro/lead/chat.py` | `mso lead chat log\|say\|reply`, `GET`/`POST .../lead/chat` |
| Confirm a chat proposal | `maestro/lead/chat.py` (`confirm_proposal`, into the same closed verb list the drawer's **Run** button uses) | `POST .../lead/chat/{msgId}/proposals/{n}/confirm` |
| Record a **Captain Decision** | `maestro/core/captain_decision.py` | `mso lead chat decide … --confirm`, `POST .../lead/chat/{msgId}/decision/confirm` |

A parity suite asserts this on the artefacts rather than on the source: for
each verb it runs the CLI path and the Hub path over equivalent workspaces and
compares the resulting JSON **whole**, permitting a difference only in
provenance fields (`createdBy`, timestamps). A new field added on one side and
not the other fails it — including fields the test's author never knew about.

Two consequences worth stating plainly:

- **`order.create` is now enforced.** The shared core checks the
  `order.create` identity capability, which `mso bug` never did. This is a
  **new** enforcement point in governed/enterprise workspaces and a no-op
  everywhere else.
- **Hub-created IDs carry exactly the same cross-device collision exposure as
  CLI-created ones** — no more, no less. Both mint from one locked sequence
  space per workspace. For a shared artefact plane, see
  [ARTEFACT-REPO.md](ARTEFACT-REPO.md#corporate-shared-mode).

---

## Captain Chat

A durable, per-workspace conversation between you and the
[resident LEAD](LEAD.md), hosted as a **Chat** tab in the LEAD drawer
(alongside **Patrol**). When the LEAD is waiting on an answer, a pip appears
on that workspace's **LEAD strip** and on the Chat tab itself; clicking the
strip opens the drawer. (The cross-workspace overview page does **not** carry
the pip — you see it on the workspace you are looking at.)

Two channels, one thread:

- **Proactive** — the LEAD posts a question when a patrol tick produces a
  high-severity finding, or the lifecycle log shows an event that by
  definition needs a human. Templated and deterministic: it spends no tokens.
- **On demand** — you type into the composer, and the host daemon answers with
  one bounded, **read-only** model call. It can read the artefact plane; it
  cannot run a command, write a file, or reach the network.

The full CLI surface (`mso lead chat log|say|reply|decide`), the two channels,
tier gating, the thread's durability guarantees and the `lead.chat.*` config
keys are documented in [LEAD.md](LEAD.md). This section covers what the Hub
adds and what it deliberately refuses.

### How an effect leaves the chat

Chat text is never authority. There are exactly two confirmable cards, and
both re-validate server-side — the stored message is never trusted.

**Proposal card.** A proposal is a `{verbId, args}` pair from the same closed
verb list the LEAD drawer's **Run** button already uses; chat adds no verb to
it. The card's headline is the **canonical description of that verb**, keyed
on its id — the LEAD's own prose is rendered separately and labelled as its
reason, so a persuasively-worded proposal still cannot misdescribe what the
button does. **Confirm** runs the verb's existing handler after applying the
LEAD's `must_not` ceiling unconditionally, and writes
`LEAD_ACTION … trigger=captain-chat` plus an audit entry — the same path the
Run button takes. A refusal comes back as `200` with `outcome: "refused"` and
nothing ran; it is an outcome to render, not an error. The Confirm button
exists **only** while the proposal's state is `offered`, so a resolved
proposal can never be run twice.

**Decision card.** A decision with nothing executable behind it is recorded on
the order JSON's (or voyage manifest's) `captainDecisions[]`, with a
`CAPTAIN_DECISION` lifecycle line and an audit entry. The card says so in the
card: **recording is evidence only and changes no gate.**

### What Captain Chat does and does not do

This extends the [authoring boundary table](#what-the-hub-does-and-does-not-do)
above, for the same reason that one exists: an operator who knows a limit uses
the right tool, and one who assumes chat can do anything concludes it is
broken.

| Capability | In chat? | Notes |
|-----------|----------|-------|
| Ask the LEAD about this workspace's state | **Yes** | Read-only reasoning over the artefact plane |
| Answer a LEAD question | **Yes** | Composer, or `mso lead chat reply` — both fold the question to `answered` |
| Run a closed-list verb (retry, reconcile, sweep, …) | **Yes, via Confirm** | Exactly the set the LEAD drawer's **Run** button offers — never more |
| Record a Captain Decision | **Yes, via Confirm** | On the order/voyage artefact, plus lifecycle + audit. **Evidence, not a gate change** |
| **Merge a PR** | **No — permanently** | No merge verb exists in the closed list. "Merge it" typed in chat does nothing. Merge on your provider, as today |
| **Tag or publish a release** | **No — permanently** | Not a verb; the release chain is Captain-invoked from the CLI |
| **Edit source code** | **No — permanently** | The responder's invocation has no `Write`, `Edit`, `NotebookEdit`, `Bash`, `PowerShell`, `Monitor` or `Agent`, and a pretool hook denies writes and shell tools independently |
| **Bypass a guard, or make a recorded decision bypass one** | **No — permanently** | See the boundary below |
| **Share one thread across two machines** | **No** | See device-local, below |
| Add a new verb to the proposal list | **No** | A new verb is its own security-reviewed change, never a chat feature |

#### A confirmed Captain Decision is evidence, not a gate change

**Recording a decision does not, by itself, change any gate's behaviour.**
Nothing in the engine reads `captainDecisions[]`. After a `waive` is recorded
against a security finding, the SEC artefact gate, the local verify gate, the
human review gate, the dispatch ledger veto and the voyage completion guard
all behave **exactly** as they did before — because none of them looks at the
field.

A decision is there so a reviewer, a later role, the LEAD and a future session
can **see and cite** the call that was made, with the same durability as
`completedBy` / `completionNotes` / `reviewedBy`. It is the structured version
of writing the reasoning down, not a switch.

This is the same principle as `mso order retry` being the only sanctioned way
past the dispatch ledger's veto: there is exactly one explicit route past a
gate, and it is never "some text was recorded nearby". Making a *specific*
gate honour a *specific* decision kind is a separate change with its own
security review, and a test pins the current behaviour so it cannot happen
quietly.

#### The thread is device-local

The thread lives at `.mso/state/captain-chat/thread.jsonl`, which is
gitignored and **not** part of a shared artefact plane. The LEAD daemon that
answers is likewise per-machine-per-workspace.

**In shared artefact-repo mode, two operators on two machines have two
separate threads for the same workspace.** They will not see each other's
messages, questions or replies. This is consistent with how the daemon and the
order ledger are already scoped, and it is stated here rather than left to be
discovered: the Hub does not present the thread as shared across machines.
Decisions *are* shared, because they are promoted onto the git-tracked order
or voyage artefact.

Within one machine the thread is genuinely shared: the Hub, `mso lead chat`
and the daemon all append to the same file under a cross-process lock.

### Attribution: the Hub cannot verify who you are

The Hub authenticates with **one shared bearer token** and has no per-request
human identity. So:

- A display name typed into the chat is a courtesy label kept in your
  browser's `localStorage`. Every Hub-authored message is stamped
  `verified: false` and rendered with an **unverified** marker.
- Authority does not differ by author — anyone holding the Hub token can
  already click Retry or Approve, and chat adds nothing to that set.
- **In a governed workspace the Hub refuses to record a decision at all.** It
  would have to attribute it to the Hub process rather than to a person, on
  the one artefact whose entire value is attribution.
  `capabilities.captainChatDecide` reports this *before* the click, and the
  endpoint returns the same sentence as a `403`. Governed operators decide
  from the CLI, where identity is verified. Per-request verified Hub identity
  is a named future dependency.

### Tier and capability

- `GET .../lead/chat` is a **read**, so below Pro it returns
  `available: false` with the same upgrade sentence `GET .../lead` shows —
  **with the thread still populated**. A licence gates acting, never reading;
  a panel with nothing in it is not a gate, it is a blank panel.
- The posting and confirm endpoints are **Team / Enterprise**, like every
  other Hub mutation.
- `capabilities.captainChatPost` and `capabilities.captainChatDecide` follow
  the [honesty rule](#the-honesty-rule-no-control-claims-what-it-cannot-verify):
  they default to `available: false` **with a reason**, and become available
  when the file plane is writable. They are **not** blocked by observe-only
  mode — posting is a file-plane append, not a process spawn, so a
  containerised Hub with a writable plane can post perfectly well, and the
  host daemon answers.

### If nothing answers

The daemon, not the Hub, does the answering — so a stopped daemon means a
pending message, and the Chat tab says so with the existing **Start** control
beside it. Stood down, out of chat token budget, or missing the Claude CLI
each produce a `system` message in the thread naming the remedy. You never get
silence; see [LEAD.md](LEAD.md#on-demand--you-ask-the-lead-answers) for the
full table.

---

## Voyage inspection & retry

Every order's drawer now has an **Artefacts** tab, backed by
`GET /api/v1/orders/{id}/artefacts` — read-only, works for an order in any
lifecycle state (COMPLETE, PENDING, archived, mid-voyage), and requires no
running dispatcher. It discovers the order's plan, every role handoff, and
every qa/security/investigation/voyage report, and renders their content
(escaped, never executed — an artefact is untrusted content) with a loading
state that gates the empty state, so a slow fetch never reads as "nothing
here".

A voyage in the **backlog** phase (created but never dispatched, or PENDING
with no live crew) shows a copy-able `mso dispatch` command block naming the
correct **product repo** path — not the artefact-repo path, which can differ
in [artefact-repo mode](ARTEFACT-REPO.md). This is deliberate, not a stopgap:
spawning a dispatcher needs a host process and a real Claude CLI session,
which a container cannot provide (see [Tier gating](#tier-gating) and the
[Capability preflight](#capability-preflight) `dispatch` reason above) — the
Hub tells you the exact command instead of pretending it can run it for you.

A **stranded** order's drawer offers **Retry** (see
[Board buckets and inline review actions](#board-buckets-and-inline-review-actions)
above) — `POST /api/v1/orders/{id}/retry`, the same semantics as
[`mso order retry`](CLI-REFERENCE.md#mso-order-retry), including the salvage
fast-path and the governed-mode `order.dispatch` capability gate. It works
identically with `MAESTRO_HUB_CONTAINERIZED=1`, because retry only ever
rewrites order JSON and the ledger — the dispatcher that eventually re-runs
the role is someone else's problem, later, on a host.

---

## Tier gating

| Action | Gate |
|--------|------|
| Read-only API (`GET /api/v1/...`), lifecycle stream | Ungated on the direct `python -m maestro.hub` entry point. |
| `mso hub start` (managed daemon) | **Team / Enterprise** licence (`auth.require_tier`). |
| `mso hub setup` (provision config) | **Team / Enterprise** licence, same gate as `start`. `mso hub stop` / `status` stay ungated. |
| `POST .../dispatch`, `POST .../stop` (Dispatch / Hold) | **Team / Enterprise** at the HTTP layer → `403` otherwise. |
| `POST .../pause`, `POST .../resume` (Pause / Resume) | **Team / Enterprise** at the HTTP layer → `403` otherwise. (`mso pause` itself is not tier-gated; the Hub's control surface is.) |
| `POST .../sweep` (Housekeeping) | **Team / Enterprise** at the HTTP layer → `403` otherwise. |
| `POST /review/{id}/{approve,revise,reject}`, `POST /orders/{id}/retry`, `POST /orders/{id}/unskip` | **Team / Enterprise** at the HTTP layer → `403`. In a **governed** workspace, additionally gated per-operator by the `voyage.approve` (review) / `order.dispatch` (retry) identity capability → `403` with a different message. |
| `POST .../voyages`, `POST .../orders`, `PATCH /orders/{id}`, `POST /orders/{id}/skip` (the [authoring](#authoring-creating-and-editing-work-from-the-hub) actions) | **Team / Enterprise** at the HTTP layer → `403`. In a **governed** workspace, additionally gated per-operator by the `voyage.create` (voyages) / `order.create` (order create + edit) / `order.dispatch` (skip) identity capability → `403`. The capability check lives **inside the shared core**, so the CLI, the Slack bridge and the Hub inherit one gate between them. |
| `GET /orders/{id}/artefacts`, `GET /orders/{id}/artefacts/{key}` | Ungated reads (file-plane, container-safe) — same discipline as `/review/{id}/plan`. |
| `GET .../lead/chat` ([Captain Chat](#captain-chat)) | A read, so **never a bare `403`**: below Pro it returns `available: false` with the upgrade reason, thread still populated. Same posture as `GET .../lead`. |
| `POST .../lead/chat`, `POST .../lead/chat/{msgId}/proposals/{n}/confirm`, `POST .../lead/chat/{msgId}/decision/confirm` | **Team / Enterprise** at the HTTP layer → `403` otherwise. Declared beforehand by `capabilities.captainChatPost` / `captainChatDecide`, which follow plane-writability rather than observe-only (a chat append is a file-plane write, not a process spawn). In a **governed** workspace the decision endpoint is additionally refused — the Hub has no per-request verified identity — and `lead.chat.post` / `lead.chat.decide` identity capabilities are enforced inside the shared cores. |
| `WS .../lead/chat/stream` | Same Origin + bearer-token guard as `/lifecycle/stream`, applied before the socket is accepted. |
| `GET /capabilities`, `GET /attention/queue`, `GET .../order-defaults` | Ungated reads. |
| `GET .../judge/*` (the [Judge page](#the-judge-page) routes) | **Pro / Team / Enterprise** licence (the resident-LEAD tiers), checked first and failing closed → `403` with the upgrade reason. Reads only; no mutating method exists under `/judge/`. |
| `GET /reports/...` (every [report](#reports) route) | Ungated reads — same posture as `/usage` and the artefact routes. |

Setting `MAESTRO_SKIP_AUTH=1` bypasses both the licence check and the tier gate
(used by CI and local single-operator development).

---

## Mobile access

The Hub UI is responsive: on a phone the sidebar collapses to a hamburger drawer
and the review screen stacks the queue above the plan/action pane, so approving,
revising, and rejecting gates all work from a mobile browser. What it is **not**
is a public internet service. Reach it the safe way:

> **Never expose the Hub directly to the public internet.** The native
> `mso hub start` binds `127.0.0.1` only — unreachable from another device by
> design. Making it reachable is a deliberate act; do it over a **private network**,
> not a port forward on your router.

**Recommended: private overlay network.** Put your phone and the Hub host on the
same [Tailscale](https://tailscale.com/) / WireGuard tailnet (or use an SSH /
`kubectl port-forward` tunnel back to `localhost:3847`). Then browse to the host's
private address. Nothing is exposed beyond the tailnet.

**When the Hub host is network-reachable** (e.g. the Docker image, which binds
`0.0.0.0` and `EXPOSE`s `3847`/`3000`), harden it — all three are read from the
environment by `maestro/hub/server.py`:

| Setting | Env var | Purpose |
|---------|---------|---------|
| Bearer token | `MAESTRO_HUB_TOKEN` (or `~/.maestro/hub.token`) | Required on every `/api/*` call except `/health` and `/ping`. Opt-in, so **set it** before exposing the host. |
| Host allowlist | `MAESTRO_HUB_ALLOWED_HOSTS` (comma-separated) | Added to the localhost base set; requests with any other `Host:` header get `403` (defeats DNS rebinding). Add your tailnet hostname/IP. |
| CORS origins | `MAESTRO_HUB_ALLOWED_ORIGINS` (comma-separated) | Origins the browser UI may call from. Default is localhost only. |
| Frontend → backend URL | `NEXT_PUBLIC_HUB_URL` | Point the Next.js UI at the private address the phone will use. |

Put the token in the `Authorization: Bearer <token>` header (the bundled UI reads
`NEXT_PUBLIC_HUB_URL`; a token-aware reverse proxy or a browser extension can inject
the header, or terminate TLS + auth at the proxy).

**Tier note.** The Hub — and every write endpoint (dispatch / stop / sweep,
approve / revise / reject) — is **Team / Enterprise** gated (see
[Tier gating](#tier-gating)). On other tiers, use the tier-independent
[Slack Mobile Command Bridge](bridge-setup-guide.md) for remote control; it needs no
open port at all (it relays through a GitHub Gist). The Hub is the richer,
sit-down surface; Slack is the always-on, zero-exposure daily driver.

---

## REST API reference

Base URL: `http://127.0.0.1:3847` (default port). All routes are under `/api/v1`.

**An unmatched `/api/...` path always returns a JSON 404**, never the frontend's own HTML page. The
catch-all is registered after every real route and before the static UI mount, so the `/api`
namespace can never fall through to the SPA and hand the UI an unreadable ~20KB HTML document in
place of an error it can parse. The most common way to reach a genuine route miss is a stale,
not-yet-restarted Hub process missing a route a newer install has. Any non-JSON response body the
frontend does receive is bounded before display — an HTML body to 200
characters, anything else to 500 — and rendered in the existing drawer/toast error surface rather
than a browser `alert()`.

| Method | Path | Returns |
|--------|------|---------|
| `GET` | `/health` | Service status, version, workspace count. |
| `GET` | `/workspaces` | Array of workspace summaries (the overview cards). |
| `GET` | `/workspaces/{id}` | Full workspace detail — voyages, orders, crews, queue summary, usage, config, repos. |
| `GET` | `/workspaces/{id}/crews` | Per-crew live state for one workspace. |
| `GET` | `/capabilities` | Declares, before any click, whether dispatch / sweep / review / order-retry / the authoring actions (including `orderAttach`) / fleet pause + resume (`fleetPause`, `fleetResume`) can actually work in **this** Hub deployment, plus the caller's licence tier. Workspace-independent, poller-independent, cheap to poll. See [Capability preflight](#capability-preflight). |
| `POST` | `/workspaces/{id}/voyages` | **Create a voyage** — `mso voyage create` over HTTP, same [`voyage_core`](#one-implementation-per-verb-shared-with-the-cli) implementation (tier- and capability-gated). Always `PLANNED`; **runs no `git`**; returns the ID read back off the file it wrote. |
| `POST` | `/workspaces/{id}/orders` | **Create an order** of any type — `mso order create` over HTTP, same [`order_create`](#one-implementation-per-verb-shared-with-the-cli) implementation (tier- and capability-gated). With a `voyageId`, also attaches the order to that voyage's manifest; a failed attach removes the order it just wrote. |
| `GET` | `/workspaces/{id}/order-defaults` | The vocabulary a create form must be built from — the workspace's order types, roles, priorities, creatable statuses, and per-type defaults. Read-only and **ungated** (a licence gates acting, never reading). |
| `PATCH` | `/orders/{id}` | **Edit an order that is not in flight** — `PENDING`/`BACKLOG`/`PROPOSED` only; a `RUNNING` order returns `409` and is not touched (tier- and capability-gated). Reports `changed_fields` read back from the order it wrote. |
| `POST` | `/orders/{id}/skip` | Withhold an order from dispatch — `mso order skip` over HTTP. The order file is **not** deleted; the skip list changes. Reversible via `/unskip`. |
| `POST` | `/workspaces/{id}/dispatch` | Start the workspace's dispatcher (tier-gated). |
| `POST` | `/workspaces/{id}/stop` | Stop the workspace's dispatcher (tier-gated). |
| `POST` | `/workspaces/{id}/pause` | **Drain the fleet** — `mso pause` over HTTP, same `maestro.core.fleet_pause` core. The dispatcher claims no new work, running crews finish untouched, then it exits and the workspace reads `PAUSED`. Tier-gated (`403`); `409` on an observe-only Hub (the request names the live dispatcher by PID + create time, which a container cannot see). Idempotent; with no dispatcher running it returns `200` and pauses nothing. Declared by `capabilities.fleetPause`. |
| `POST` | `/workspaces/{id}/resume` | **Resume** — `mso resume` over HTTP. While `PAUSING`, cancels the drain (no restart); while `PAUSED` (or after an interrupted drain), relaunches the dispatcher through the same spawn as `/dispatch`, with the recorded dispatch args. Tier-gated (`403`); `409` on an observe-only Hub. Nothing paused → `200` saying so. Declared by `capabilities.fleetResume`. |
| `POST` | `/workspaces/{id}/sweep` | Run the [housekeeping sweep](#housekeeping-sweep) (tier-gated). Add `?dry_run=true` to preview. |
| `GET` | `/workspaces/{id}/settings` | Every `workspace`- and `both`-scope [setting](#settings-workspace-and-device) for one workspace: `{scope, settings[], models[]}`. Each entry carries `value`, `source`, `sourceDetail`, `default`, `type`, `choices`, `restartRequired`, `locked` and `lockedReason`. `models[]` is the model vocabulary, `[{id, label, generation}]`, with `claude-opus-5-5` first. Ungated read. |
| `PUT` | `/workspaces/{id}/settings` | Set one key, `{key, value}`, or remove it, `{key, unset: true}`, in that workspace's files. Returns `{ok, setting, changed, writtenScope, message}`, with `setting` read back from disk. A device-only key is `400` here. **Pro+**; `409` when observe-only. |
| `GET` | `/settings` | Every `device`- and `both`-scope setting for this device, resolved with no workspace. Ungated read. |
| `PUT` | `/settings` | Set or unset one key in `~/.maestro/config/settings.json`, or the device persona file. A workspace-only key is `400` here. **Pro+**; `409` when observe-only. |
| `POST` | `/workspaces/{id}/lead/start` | **Start the resident LEAD daemon** — `mso lead start` over HTTP, same `maestro.lead.control` implementation. Tier-gated (`403`); refused with `409` on an observe-only Hub, since a daemon launched inside a container is not a host daemon. Starting a daemon that is already running returns `200` and does nothing, and its `message` says so. Declared up front by `capabilities.leadStart`. |
| `POST` | `/workspaces/{id}/lead/stop` | **Stop the resident LEAD daemon** — `mso lead stop` over HTTP. **Never tier-gated.** Waits until the process is confirmed gone. Stopping a daemon that is not running returns `200` and does nothing; a stop that could not be confirmed returns `500`. Declared by `capabilities.leadStop`. |
| `POST` | `/workspaces/{id}/lead/restart` | **Restart the resident LEAD daemon** — `mso lead restart` over HTTP. Gated like `/lead/start`. No replacement starts unless the old daemon was confirmed stopped. |
| `GET` | `/workspaces/{id}/lead/chat` | One page of this workspace's [Captain Chat](#captain-chat) thread, newest last. `?before=<CHAT_ID>&limit=50` pages backwards; a `before` id that is not in this thread is a `404`, never a silent newest-page, so a client paging from a stale cursor is told. **Not tier-gated with a `403`** — below Pro it returns `available: false` plus the upgrade reason, with the thread still populated. |
| `POST` | `/workspaces/{id}/lead/chat` | Post a Captain message — `mso lead chat say` over HTTP, same `maestro.lead.chat` core. With `inReplyTo`, routes through `post_captain_reply`, which posts **and** folds the named question to `answered` as one call. Tier-gated (`403`); an observe-only Hub is **not** refused (a file-plane append, not a spawn) — only an unwritable plane is. Declared by `capabilities.captainChatPost`. |
| `POST` | `/workspaces/{id}/lead/chat/{msgId}/proposals/{n}/confirm` | Confirm one proposal — **the only way an effect leaves the chat**. Re-parses the proposal from its `verbId` and `args` against the closed verb list (never from stored text), applies the LEAD's `must_not` ceiling unconditionally, runs the verb's existing handler, and writes `LEAD_ACTION … trigger=captain-chat` + audit + the result message. A **refusal is a `200`** with `outcome: "refused"` and nothing ran; a second confirm of the same proposal is a `409`. Tier-gated. |
| `POST` | `/workspaces/{id}/lead/chat/{msgId}/decision/confirm` | Record a Captain Decision — `mso lead chat decide --confirm` over HTTP, same `maestro.core.captain_decision` core. Fields come from the message's `decisionDraft`; a field in the body wins over the draft. **Evidence only: a recorded decision changes no gate's behaviour.** Tier-gated, and refused with `403` in a governed workspace (no per-request verified identity). Declared by `capabilities.captainChatDecide`. |
| `WS` | `/workspaces/{id}/lead/chat/stream` | Live tail of one workspace's chat thread, backfilling the newest **50** messages. Frames are the same `ChatMessage` shape the REST page returns, so a client renders one code path for backfill and updates alike; a message is re-sent whenever its *folded* form changes (a question going `open` → `answered`, a proposal `offered` → `confirmed`), and clients key on `id` and replace. **Bound, stated honestly:** the watched window is those newest 50 — a state change folded onto an older message is not pushed, though it is still correct in the REST page, which folds the whole thread. Not tier-gated (a read). Same Origin + bearer-token guard as `/lifecycle/stream`, applied before accept; a separate socket by design, since multiplexing would have required chat bodies to exist in `lifecycle.log`. |
| `GET` | `/review/queue` | Cross-workspace **review-gated only** queue (bare array) — the original, narrower feed. Prefer `/attention/queue` for the full four-category view. |
| `GET` | `/review/{order_id}/plan` | The plan markdown for an order awaiting review. |
| `POST` | `/review/{order_id}/approve` | Approve a paused order (tier- and capability-gated). |
| `POST` | `/review/{order_id}/revise` | Send an order back with feedback (tier- and capability-gated; feedback is required). |
| `POST` | `/review/{order_id}/reject` | Reject a paused order (tier- and capability-gated; a reason is required). |
| `GET` | `/attention/queue` | Every order across every registered workspace needing attention — all four categories (review-gated / stranded / dep-held / skipped), bare `Order[]` array. Backs the [`/review` page](#the-review-page). |
| `GET` | `/orders/{order_id}/reasoning` | Everything recorded for an order's crews (FTR-MSO-2026-1206), grouped by role, lap and iteration: `groups[]`, each with `turns[]` (model reasoning) and `activity[]` (Maestro steps and tool calls), plus `enabled`, `storage`, `order_found`, `records` and `truncated`. Optional `?role=`. Same core as `mso reasoning show`. Read-only, ungated. `400` for an id or role that cannot name a reasoning file. **Bounded, not paged:** at most 32 MB read (newest first), the newest 10,000 records and 4M characters kept, and at most 16 MB / 20,000 entries (2,000 per group) joined from `activity.jsonl`; `truncated: true` means older records were left out, and a group with `activity_truncated: true` had its joined activity cut. **`429`** (`Retry-After: 2`) when 2 reviews are already running: it is refused, not queued. See [REASONING.md](REASONING.md#limits-on-what-the-hub-reads). |
| `GET` | `/projects/{id}/status-updates` | A project's recent [status updates](STATUS-UPDATES.md), oldest first, with the on/off setting and the state chip: `{project, enabled, intervalMinutes, state, dispatcherState, limit, records[], message}`. `?limit=N`: default `20`, below `1` is `400`, above `200` is clamped to `200`. `state` is `live`, `paused`, `stopped` or `off`. Read-only, ungated. Same records as `mso status-updates`. |
| `GET` | `/orders/{order_id}/artefacts` | Discovers every artefact for an order (plan, handoffs, qa/security/investigation reports, the order JSON) — manifest only, no content. Ungated, works in any lifecycle state. |
| `GET` | `/orders/{order_id}/artefacts/{key}` | Reads one artefact's content (≤512 KB; larger content is truncated with `truncated: true`). `key` is re-validated against a fresh discovery pass, never joined onto a client-supplied path. |
| `POST` | `/orders/{order_id}/retry` | Reopen a stranded/archived order — `mso order retry` over HTTP, same [`order_retry`](CLI-REFERENCE.md#mso-order-retry) implementation. Works with `MAESTRO_HUB_CONTAINERIZED=1` (file-plane only). |
| `POST` | `/orders/{order_id}/unskip` | Remove an order from the skip list — `mso order unskip` over HTTP. |
| `POST` | `/orders/{order_id}/attach` | **Attach an existing order to a voyage** — `mso order attach` over HTTP, same `order_attach` implementation (tier- and capability-gated). Body `{"voyageId": "VOY-…"}`. Writes the order's `voyageId`/`voyageBranch` (branch read from the manifest) **and** the manifest's `orders[]`, or neither. `404` unknown order/voyage, `409` archived voyage / in-flight order / order already on a different voyage, `503` read-only plane. Re-attaching returns `changed: false`. |
| — | *no endpoint* | **Detaching an order from a voyage (so also moving one between voyages), archiving a voyage by hand, editing a voyage manifest, parking a voyage, and saving workspace config are deliberately absent.** See [What the Hub does and does not do](#what-the-hub-does-and-does-not-do) for the CLI verb that does each one, and why. |
| `GET` | `/usage` | Cross-workspace token/cost rollup. Optional: `?from=YYYY-MM-DD&to=YYYY-MM-DD&group_by=project\|voyage\|order\|role` |
| `GET` | `/usage/projects/{id}` | Per-project rollup with voyage-level buckets. Optional `from` / `to` date filters. |
| `GET` | `/usage/voyages/{voyage_id}` | Per-voyage rollup with order-level buckets (+ role breakdown when per-iteration data is present). Optional `from` / `to`. |
| `GET` | `/usage/orders/{order_id}` | Full order usage: per-role buckets, per-iteration records, per-model breakdown. |
| `GET` | `/reports/qa` | QA records across workspaces, newest first, with [`parseCoverage`](#watch-parsecoverage-for-parser-drift). Optional `?workspace_id=` and `?limit=` (default 100, max 500). Ungated, like every report route. |
| `GET` | `/reports/qa/{order_id}` | One order's QA record. `404` when the order has no QA report. |
| `GET` | `/reports/ac` | The acceptance-criteria coverage headline (over every order) plus per-order records. Optional `?workspace_id=`, `?bucket=met\|partial\|outstanding\|not-covered\|no-criteria` and `?limit=` (default 200, max 1000); an unknown `bucket` is a `400`. |
| `GET` | `/reports/ac/{order_id}` | One order's criteria record. `404` only when no workspace holds the order — an order with nothing recorded is a `200` whose rows read `NOT RECORDED`. |
| `GET` | `/reports/security` | Per-order security review verdicts, with `parseCoverage` and `verdictCounts` (both count documents, not orders). Optional `?workspace_id=` and `?limit=` (default 200, max 500). Carries no scanner data. |
| `GET` | `/reports/security/scanner-runs` | Archived scanner runs, each with its counts, trust label and caveat. No severity total, by design. Optional `?workspace_id=` and `?limit=` (default 50, max 200). |
| `GET` | `/reports/security/{order_id}` | Every security review document for one order. `404` when there are none. |
| `GET` | `/reports/voyage` | The voyage index, from manifests only (`composed: false`). Optional `?workspace_id=` and `?limit=` (default 500, max 2000). |
| `GET` | `/reports/voyage/{voyage_id}` | One voyage's report, composed on read (`composed: true`). `404` when no workspace holds the voyage. |
| `GET` | `/workspaces/{id}/judge/status` | Whether the Judge is on (and why not), each kind's mode, the model, token spend against the ceiling, docket counts, and the persona's `judge_title`. Pro+ → `403` below it. |
| `GET` | `/workspaces/{id}/judge/docket` | Docket items. Optional `?view=all\|pending\|shadow\|escalated\|decided` and `?kind=`. An unknown view is `400`. |
| `GET` | `/workspaces/{id}/judge/docket/{item_id}` | One docket item. `400` for a malformed id, `404` when absent. |
| `GET` | `/workspaces/{id}/judge/limits` | The shipped hard limits. Read-only. |
| `GET` | `/workspaces/{id}/judge/agreement` | Agreement over the last 90 days: `overall` and `byKind`. Optional `?kind=`. |
| `WS` | `/workspaces/{id}/crews/{slot}/reasoning/stream` | Live reasoning of one crew slot (FTR-MSO-2026-1205), behind the crew drawer's Reasoning section. A target frame each time the crew moves to a new iteration, role or order, then that target's backfill and new records. Same core as `mso reasoning tail crewN -f`, except that the socket falls back to the crew's `activity.jsonl` when capture is off or the iteration's file is full (records carry `origin: "activity"` instead of `"reasoning"`, and `fallback`: `"off"` or `"capped"`, saying why). Not tier-gated (a read). Same Origin + bearer-token guard as `/lifecycle/stream`, applied before accept. **Caps:** 16 sockets open in total and 4 per client host (past either: closed with `1013` before accept); a socket that sends nothing for 900 s is closed with `1000` and the panel reconnects with a fresh backfill (the newest 200 records); a read error closes it with `1011`. See [REASONING.md](REASONING.md#limits-on-what-the-hub-reads). |
| `WS` | `/lifecycle/stream` | Live lifecycle events. Add `?workspace_id=<id>` to scope to one workspace. |

The JSON shapes are defined by the Pydantic models in `maestro/hub/models.py`
and serialize exactly to the frontend TypeScript interfaces in
`maestro-hub/app/types/index.ts` (the authoritative data contract).

---

## Housekeeping sweep

Each project's control row on the workspace detail page carries
a **broom button**, between **Dispatch** and **Settings**. It runs housekeeping
for that workspace: check every voyage's PR state, archive the ones whose PR has
merged, and report what it refused to touch.

### Why it exists

You approve and merge the voyage PR yourself most of the time — usually after the
dispatcher that produced the work has exited. Maestro therefore never *observes*
the merge event, and the voyage stays in `voyages/active/`, cluttering the **Final
Review** column indefinitely.

Housekeeping cannot be something that only happens when a dispatcher happens to be
running. It has to be **pull-based** — something you trigger. The broom button is
that trigger, and it needs **no running dispatcher**.

### Preview, then apply

Clicking the broom never mutates anything on the first click:

1. The first click runs a **dry run**. If there is anything to archive, it opens a
   confirm dialog listing **Will change** and **Will NOT touch**, each line naming
   the voyage and the reason. Nothing is written until you confirm — cancel and the
   workspace is untouched.
2. If there is nothing to change but voyages *were* refused (an open PR, a voyage
   with no PR, a PR closed without merging, an order archived but not `COMPLETE`),
   you get an informational dialog instead of a bare count — the same **Will NOT
   touch** lines the confirm dialog would have shown, labelled as a dry run so it's
   clear the workspace was inspected and nothing was mutated. There is nothing to
   apply, so it has a single dismiss, not a confirm/cancel choice.
3. If there is nothing to change *and* nothing was refused, you get a plain toast —
   *"everything is already up to date"* — since a dialog would be noise on a
   genuinely empty result.

The refusals are the point as much as the changes: an open PR, a voyage with no PR
at all, a PR closed without merging, or an order that is archived but not
`COMPLETE` is **reported with its reason**, never silently skipped.

### Same code as the CLI

The endpoint runs `mso voyage reconcile --json` — the button and the command
execute literally the same implementation, so they cannot drift or disagree. For
the full behaviour, the report shape and how merge state is resolved (PR record
first, raw git as the fallback), see
[`mso voyage reconcile`](CLI-REFERENCE.md#mso-voyage-reconcile).

### Requirements and limits

| Constraint | Detail |
|-----------|--------|
| **Tier** | Team / Enterprise, same as Dispatch / Hold. `403` otherwise (or set `MAESTRO_SKIP_AUTH=1` for local development). |
| **Origin / CORS** | Same allow-list and Host guard as the other control endpoints. |
| **Dispatcher** | Not required. |
| **Containerised Hub** | **Unavailable** — returns `409` with the observe-only message. Merge detection needs `git` and `gh` against the product repo, and a container has neither. Same constraint as the Dispatch button; run the sweep from a host session (`mso voyage reconcile`) or a native Hub (`mso hub start`). |
| **Timeout** | 5 minutes, then `504`. A hanging PR lookup is the usual cause; nothing is reported as changed. |

---

## Reports

The reports catalog at `/reports` links five reports. Every one reads real
artefacts from your registered workspaces through the Hub backend, none renders
example data, and all of them are read-only.

| Report | Page | Reads | Shows |
|--------|------|-------|-------|
| **QA Reports** | `/reports/qa` — one report at `/reports/qa?id=<ORDER-ID>` | Each order's QA report in `.mso/reports/qa/` | Per order: the QA decision, test counts, the acceptance-criteria table, defects and sign-off. Newest first. |
| **Token Usage** | `/reports/usage` | `.mso/usage/orders/` | Spend with drill-down and CSV export — see [Token usage & cost](#token-usage--cost). |
| **Acceptance Criteria** | `/reports/ac` | Each order's `acceptanceCriteria` and `acResults`, plus the acceptance-criteria table in its QA report | Coverage first, then met / partial / outstanding over the covered orders, with the source of every result. |
| **Security Review** | `/reports/security` | Security review documents in `.mso/reports/security/`, and archived `mso security review` runs | Per-order review verdicts and, kept separate, scanner runs. |
| **Voyage Summary** | `/reports/voyage` — one voyage at `/reports/voyage?id=<VOY-ID>` | The voyage manifest, its member orders' QA / criteria / security records, and usage | Per voyage: PR and dates, spend by role and crew, each order's verdicts, and links to any hand-written voyage narratives. |

### What a card's badge means

Each card on `/reports` carries a badge, and the badge is a claim about this Hub
build:

- **Live data** — a backend route stands behind the report. All five cards are
  live.
- **No backend yet** — reserved for a report type added before its backend. Such
  a card shows no figure at all, because any number would be invented.

A card never shows a count it cannot compute. Only the QA card carries a figure:
the number of QA reports the backend found, read when the page loads. While that
request is in flight the card shows `…`; if the backend cannot be reached it
shows `—` and says so, rather than `0`. The other cards state that their figures
are computed on their own page.

### States that are never a pass

The reports keep "nothing was recorded" and "this could not be read" apart from
a result. None of these states is ever counted as a pass, and none is shown as
zero:

| State | Where | Meaning |
|-------|-------|---------|
| `UNDETERMINED` | QA verdicts, security verdicts, individual criteria | A document exists but no verdict could be read from it. Open the document itself (the order drawer's artefact viewer) to see why. |
| `NOT RECORDED` | Acceptance criteria | A criterion was written down and no result was recorded for it, in the order or in its QA report. |
| `not-covered` | Acceptance Criteria buckets | An order has criteria and no recorded result for any of them. Its own bucket, outside met / partial / outstanding. |
| `no-criteria` | Acceptance Criteria buckets | Results exist for an order with no written criteria to judge them against. Listed, but outside the coverage figure. |
| not recorded | Voyage Summary spend | A voyage or order with no usage record reads "not recorded" — never 0 tokens or $0.00. |

### Acceptance Criteria: coverage is the headline

The page leads with **coverage** — "N of M orders with criteria have a recorded
verification" — not a pass rate. The covered orders are then split three ways:

- **met** — every criterion recorded `PASS`.
- **partial** — nothing failed, but some criterion is `PARTIAL`, `SKIP`,
  `UNDETERMINED` or still `NOT RECORDED`.
- **outstanding** — at least one criterion recorded `FAIL`, or the two sources
  recorded it differently.

Those three sum to the covered count; uncovered orders are their own bucket. The
coverage figure is computed over **every** order in the scanned workspaces, never
over the page of results you are looking at.

A result can come from two places: the order's own `acResults`, or the
acceptance-criteria table in its QA report. Every row names its source. When both
record the same criterion differently, the page shows both side by side and
marks a **conflict** — it never silently picks one.

### Security Review: verdicts and scanner runs are kept apart

- **Review verdicts** come from the security review documents written for
  individual orders. These have no enforced format, so for some of them
  `UNDETERMINED` is the honest answer. An order with more than one review
  document shows all of them, never one chosen winner.
- **Scanner runs** — archived `mso security review` output — are listed as
  runs, with their counts. Those counts are pattern matches over every file
  scanned and are known to be wrong by orders of magnitude, so every run carries
  a caveat and a trust label (`KNOWN-UNTRUSTED` or `UNVERIFIED`; there is no
  "trusted"). The Hub never totals scanner counts, never presents a latest run
  as your security posture, and never computes a severity figure from them.

### Voyage Summary is composed when you open it

There is no voyage-report file for a crew to produce. The index lists every
voyage in `voyages/active/` and `voyages/complete/` — whatever project acronym
their IDs carry — from their manifests alone. Opening one composes its report on the
spot from records that already exist: the manifest, each member order's QA,
criteria and security records, and the usage files. So every voyage in a
workspace has a report, including ones that closed long before this page
existed.

Hand-written narratives under `.mso/reports/voyage/` are **linked**, never mined
for numbers. Role and crew spend comes from the usage records; when only some of
a voyage's orders have per-iteration detail, the page says how much of the total
the split covers.

### Watch `parseCoverage` for parser drift

QA reports and security review documents are Markdown. The Hub reads a QA report
by its headings — `## QA Decision`, `## Acceptance Criteria Verification`,
`## Defects Found` and `## Test Summary` — which keeps every historical report
readable without requiring any metadata. The trade-off is that nothing enforces
those headings: an edited template, a renamed heading, or a role overlay that
writes its own report shape will quietly stop yielding verdicts, with no error
anywhere.

**`parseCoverage` is the figure to watch for exactly that.** Both
`GET /api/v1/reports/qa` and `GET /api/v1/reports/security` return it:

```json
"parseCoverage": { "total": 100, "parsed": 97, "undetermined": 3 }
```

| Field | Meaning |
|-------|---------|
| `total` | Documents in this response. |
| `parsed` | Documents a verdict was read from. |
| `undetermined` | Documents that exist but yielded no verdict. Reported on its own — never subtracted away or folded into `parsed`. |

**A steady `total` with a falling `parsed` is drift.** A handful of
`undetermined` documents is normal — an unfinished or hand-edited report. A jump
after you change a role overlay, a pack, or a report template is the signal to
open the newest `UNDETERMINED` reports and compare their headings with the
template. The pages surface the same figure: the QA list shows how many reports
have no readable verdict, and the security page states how many documents read
`UNDETERMINED`.

`parseCoverage` describes exactly the documents in that response, so it moves
with `limit` and `workspace_id`; `available` says how many exist in total. (The
Acceptance Criteria `coverage` object is a different figure: it is always computed
over every order, as described above.)

### The QA verdict front-matter

TST crews open every QA report with a small front-matter block that restates the
decision:

```markdown
---
nodeVerdict: PASS
---
# QA Report: FTR-ACME-2026-0001
```

`PASS` means the `## QA Decision` is APPROVED or CONDITIONAL; `FAIL` means it is
REJECTED. The Hub reads the block **only as corroboration** — the headings stay
the primary contract. A report without the block, which includes every report
written before the block was required, reads exactly as well as one with it. When
the two disagree, the QA record's `nodeVerdictCorroborates` is `false`, so the
disagreement can be flagged instead of either side being believed. A value of
`CONSUMED` means a rejection has already been acted on, and the Hub treats it as
absent.

If you customise the TST role with an overlay, keep both the four headings and
the block.

### Access

Every report route is a read-only `GET` and is **ungated**, the same posture as
`/usage` and the order artefact routes — those already serve the raw text of the
same QA and security documents, so gating a summary of them would protect
nothing. The Hub's deployment-level controls (the bearer token and the host /
origin allow-lists described under [Mobile access](#mobile-access)) apply to the
report routes as they do to every other `/api/*` route.

---

## Token usage & cost

The Hub surfaces token consumption and estimated cost across four levels: fleet
overview, workspace detail, the Token Usage report, and the REST API.

### Dashboard overview — CrossWorkspaceUsagePanel

On the Hub overview page (`/`), a **CrossWorkspaceUsagePanel** appears above the
workspace cards. It shows:

- **Total tokens** and **estimated cost** for all projects combined, for the
  selected date range.
- A **per-project breakdown table** sorted by spend (highest first), with each
  project's token total and cost.
- A **trend sparkline** driven by the daily series for the same period.
- A **date-range control** with 7d / 14d / 30d presets. Changing the preset
  re-fetches the overview and all workspace panels simultaneously.

When no usage has been recorded in the selected period, the panel shows
"No usage recorded in this period" — it never falls back to mock or example data.

### Workspace detail — WorkspaceUsagePanel and voyage badges

On a workspace detail page (`/workspaces/{id}`):

- A **WorkspaceUsagePanel** in the right sidebar shows the project-level token
  total and cost for the selected date range, with a sparkline.
- Each voyage row in the voyage list shows an inline **token/cost badge** when
  usage data exists for that voyage. The badge is omitted (not zeroed) when the
  voyage has no recorded usage.
- The **date-range control** (7d / 14d / 30d) drives both the sidebar panel and
  the per-voyage badges.

### Token Usage report

A dedicated **Token Usage report** is available at `/reports/usage` (linked from
the reports catalog at `/reports` with a "Live data" badge). It provides:

| Feature | Description |
|---------|-------------|
| **Drill-down navigation** | Start at the project level; click into a project to see its voyages; click a voyage to see its orders; click an order for role + model detail. A breadcrumb lets you navigate back up. |
| **TotalsPanel** | Shows total tokens, estimated cost, and order count for the current filter level, plus a trend sparkline. At order detail level the totals reflect that order's data. |
| **BreakdownTable** | Tabular list of buckets (projects / voyages / orders) sorted by tokens descending, with a "Drill in →" button on each row. |
| **Order detail view** | Shows per-role token/cost buckets (`role_buckets`, from the per-iteration JSONL) and a per-model breakdown (input / output / cache-read / cache-write / message count). Degrades gracefully when JSONL is absent. |
| **DailyTrendTable** | Per-day tokens and cost series shown below the main panel at project, voyage, and order-list levels. Hidden at the order detail level (no series available). |
| **CSV export** | Exports the current filtered view as a CSV file. At order level: role + model rows combined; at other levels: the current bucket list. |
| **Date-range control** | 7d / 14d / 30d presets re-fetch all panels at the current drill level. |
| **Empty/zero state** | "No usage data for the selected filters in this period" at every level — no fallback to mock data. |

### Data sources

All usage surfaces read from the files written by the Maestro stop hook:

| File type | Location | Contents |
|-----------|----------|----------|
| **Order summary** (`*.json`) | `.mso/usage/orders/{ORDER-ID}.json` | Cumulative per-order totals: `total_tokens`, `estimated_cost_usd`, per-model breakdown. One file per order; updated (merged, not overwritten) after each crew iteration by the stop hook. |
| **Iteration log** (`*.jsonl`) | `.mso/usage/orders/{ORDER-ID}.jsonl` | Append-only; one JSON line per completed crew iteration with `role`, `crew_number`, `iteration`, `total_tokens`, `estimated_cost_usd`, per-model breakdown, and `timestamp`. Written only by installs that produce per-iteration logs. |

### Forward-looking caveats

> **Data availability:** Token-usage files are written by the Maestro stop hook,
> which records usage for dispatched crews from **v5.0.2 onward**. Orders that ran
> under an earlier version have no recorded usage and show zero or empty in all
> Hub views.

> **Role-level breakdown:** The per-role breakdown in the order detail view needs
> the per-iteration JSONL files. An order that completed before your install began
> writing them has only the summary JSON, and the view says
> "No role-level breakdown — requires FTR-0332 iteration files." rather than
> failing. (That message names the iteration files by an internal flag name — it
> is the text you will see on screen.)

> **Cost estimates:** Estimated cost is calculated by the Maestro stop hook using
> a built-in per-model pricing table. It reflects published API list prices at the
> time of the release and is updated with each new Maestro version. Actual billing
> may differ due to promotional pricing, enterprise agreements, caching discounts,
> or model pricing changes that post-date the installed version.

---

## Settings: workspace and device

The Hub reads and writes the same settings as `mso settings`, through the same
code. The full key list, the precedence rule and the two files are in
[SETTINGS.md](SETTINGS.md).

- **Workspace settings drawer** — a workspace's **Settings** button. It shows
  every `workspace`- and `both`-scope key for that project, and saves to its
  `config/workspace.json`, or to that key's own file for `persona` and
  `models.<ROLE>.*`.
- **Settings page** — sidebar → **Settings** (`/settings`), headed *Applies to
  every project on this device*. It shows `device`- and `both`-scope keys and
  saves to `~/.maestro/config/settings.json`, or the device persona file.

Both forms are generated from the settings registry, not hand-listed. A key
with no engine code honouring it cannot be registered, so it cannot be shown.

**Status updates group.** The workspace drawer has a **Status updates** group
with `statusUpdates.enabled` and `statusUpdates.intervalMinutes` (5 to 240). An
out-of-range interval is flagged in the form and refused on save. In a workspace
that dispatches several projects, the drawer on a project's page edits that
project's own values. See [STATUS-UPDATES.md](STATUS-UPDATES.md).

**Source badges.** Every field shows where its value came from: `workspace`,
`device`, `env`, `bundle`, `overlay` or `default`. A workspace value overrides a
device value.

**Read-only fields.** A field set by an environment variable or a signed policy
bundle, or one that is locked, is read-only, and the reason is shown before you
interact with it.

**Restart chip.** A `restart` chip means the key is read when a dispatcher
starts, so it takes effect at the next start.

**How Save works.**
- Save sends **only the keys that changed**, one `PUT` per key, then re-reads.
- If some writes fail, the message names the keys that were not written.
- A write reports the value read back from disk. That value may still come from
  a higher source, such as an env var, and the badge says so.

**Kept elsewhere.**
- `providers.*` keys stay in the **SDLC Providers** section.
- **Repositories** are read-only in the drawer; change them with
  `mso migrate import-workspace` ([MULTI-REPO.md](MULTI-REPO.md)).
- The drawer no longer shows `maxIterations`, `autoDispatch` or `tokenDailyCap`:
  no engine code ever read them. Dispatch limits are `dispatch.maxCrews`,
  `dispatch.maxTurns` and `dispatch.timeoutMinutes`. The Hub's **Dispatch**
  button honours them instead of always launching five crews.
- The **Dispatch** button starts the same installed Maestro as `mso dispatch`,
  at your licensed tier. If the dispatcher it starts exits within the launch
  grace window, the Hub reports it as a failure ("Dispatcher exited (PID n) Xs
  after launch — exit code N"), with the tail of its error output. Each attempt
  is logged in `.mso/logs/hub-dispatch-spawn.log`, ending with a `--- result:`
  line.

**Gates.**
- Writes need a **Pro, Team or Enterprise** licence. This is one tier below
  the Hub's other acting endpoints, because a Pro seat's settings are its own
  machine's. The gate is the `settingsWrite` / `deviceSettingsWrite`
  [capability](#capability-preflight) fields, not `tier.control`.
- An observe-only (containerised) Hub also refuses writes.
- Reads are ungated.
- In a **governed** workspace, a workspace write also needs the `settings.write`
  identity capability, and each write appends an audit line. The line records
  the key, scope and resulting source, never the value.

| Refusal | Status |
|---------|--------|
| Licence below Pro | `403` |
| Observe-only deployment | `409` |
| Unknown key, wrong type, wrong scope for this endpoint, previous-generation model pin | `400` |
| Key locked by a policy bundle, or a file Maestro refuses to overwrite | `409` |
| Missing `settings.write` capability (governed) | `403` |

---

## Configuration

| Setting | Where | Default |
|---------|-------|---------|
| Backend port | `--port` on `mso hub start` / `python -m maestro.hub` | `3847` |
| Frontend → backend URL | `NEXT_PUBLIC_HUB_URL` env (frontend) | `http://localhost:3847` |
| Workspace registry | `~/.maestro/projects.json` | — |
| Terminal monitor auto-spawn | `spawnMonitor` in `~/.maestro/config/settings.json`, or `MAESTRO_SPAWN_MONITOR=0/1` env | `true` (spawns) |

Per-workspace and device settings (dispatch limits, verify gate, voyage PR
behaviour, idle watchdog, LEAD, persona, role models) are listed in
[SETTINGS.md](SETTINGS.md), and editable from the Hub as described in
[Settings](#settings-workspace-and-device).

**Running the Hub instead of the terminal Monitor?** `mso dispatch` normally
auto-spawns a separate visible "Maestro Monitor" terminal window on every
dispatch. When you're driving observation through the Hub, that window is
redundant. Set `spawnMonitor` to `false` in the **machine-level** (device-global,
not per-workspace) `~/.maestro/config/settings.json`:

```json
{
  "spawnMonitor": false
}
```

or set `MAESTRO_SPAWN_MONITOR=0` in the environment the dispatcher runs in — the
env var always wins over the machine config. This is a per-device display
preference, so it applies to every workspace dispatched from that machine. The
dispatcher and crews run unaffected either way; only the terminal window is
suppressed, and a one-line note is logged to `lifecycle.log` when it is.

**From the Hub.** The settings drawer has a **This device — all projects**
section with a *Status monitor window* toggle that writes the same
`spawnMonitor` key (other keys in `settings.json` are preserved). It is labelled
as machine-wide before you touch it, because it is: the same toggle appears in
every project's drawer and they all change one value. It shows the **effective**
value and where it came from — the saved setting, the default, or
`MAESTRO_SPAWN_MONITOR` in the Hub's environment. When that env var is set the
toggle is disabled and says so, since saving would change nothing a Hub-started
dispatch does. (A `mso dispatch` run from a terminal uses that terminal's own
environment.) A change applies to the **next** dispatch; no restart needed.
Observe-only (containerised) Hubs show the value read-only, because their
`~/.maestro` is not the host's.

| Method | Path | Purpose |
|--------|------|---------|
| `GET` | `/api/v1/machine/spawn-monitor` | Effective value, `source` (`env`/`settings`/`default`), `envValue`, `savedValue`. Ungated read. |
| `PUT` | `/api/v1/machine/spawn-monitor` | Body `{"spawnMonitor": true\|false\|null}` (`null` clears the saved value). Team/Enterprise tier, then refused `409` on an observe-only Hub. Declared by `capabilities.spawnMonitorWrite`. |

---

## Troubleshooting

- **Opening `http://127.0.0.1:3847/` returns JSON `{"ui": "unavailable", …}`** —
  the backend is running API-only because no built UI bundle shipped with this
  install. A released `maestro` wheel always bundles the UI; a plain source
  checkout does not. Either install a released wheel, or build the UI from source
  (`npm ci && npm run build` in `maestro-hub/`, then copy `out/` to
  `maestro/hub/static/`), or use the Docker frontend. `mso hub setup` reports the
  bundle's presence up front.
- **Frontend shows "backend unreachable" / no live data** — confirm the backend
  is up (`mso hub status` or `curl http://127.0.0.1:3847/api/v1/health`). In
  local mode the UI is same-origin, so there is nothing to point at; in Docker
  confirm the frontend's `NEXT_PUBLIC_HUB_URL` build-arg names the right backend.
- **`mso hub start` refuses with a tier error** — `mso hub` requires a Team /
  Enterprise licence. For single-operator/dev use, run the backend directly with
  `python -m maestro.hub --port 3847`.
- **A workspace is missing or stale** — check `mso projects list`; register with
  `mso init` / `mso dispatch` in the workspace, or remove with
  `mso projects remove <ACRONYM>`.
- **Dispatch / Hold / broom buttons return 403** — those endpoints are tier-gated;
  use a Team / Enterprise licence or set `MAESTRO_SKIP_AUTH=1` for local
  development.
- **The broom button returns 409 "observe-only deployment"** — expected in a
  containerised Hub, which has no product repo, `git` or `gh` to check PR state
  with. Run `mso voyage reconcile` from a host session instead, or run the Hub
  natively. Same limitation as Dispatch.
- **Voyages stay in Final Review after their PR merged** — click the broom button
  (or run `mso voyage reconcile`). Maestro does not see merges you perform
  yourself; housekeeping is
  [pull-based](#housekeeping-sweep) by design.
- **A "New voyage" / "New order" / "Save" button is disabled** — hover it, or
  read the notice in the drawer body: the reason shown is the server's own.
  The three usual causes are a licence below Team, a **read-only artefact
  plane** (the Hub could not write to `voyages/` or `queues/`), and a Hub build
  predating the [authoring surface](#authoring-creating-and-editing-work-from-the-hub)
  (a capability field it never populates reports unavailable by default — check
  the stale-Hub badge below and restart the daemon).
- **The button you want isn't there at all** — check
  [What the Hub does and does not do](#what-the-hub-does-and-does-not-do)
  before assuming it is broken. Detach-from-voyage, manual voyage archive,
  voyage-manifest editing, voyage parking, `retry --force`, `cleanup`,
  migrations and licence management are CLI-only *by design*; that table names
  the command for each.
- **An order created with `mso order create --voyage VOY-…` does not appear in
  the voyage** — a known asymmetry: the CLI records `voyageId` on the order but
  does not add the order to the voyage's `orders[]`, while the Hub's create does
  both. Add the manifest entry by hand, or create voyage-attached orders from
  the Hub. See
  [One honest limit worth knowing](#one-honest-limit-worth-knowing).
- **A "Hub stale" badge appears in the Topbar** — the running Hub process's version doesn't match
  what's installed, almost always because a `pip install --upgrade` landed after the daemon
  started. Restart it: `mso hub stop && mso hub start`.
- **An API call returns a bare JSON `{"detail": "API route not found: ..."}`** — the path doesn't
  exist under `/api/v1` in the version currently running (check the stale-Hub badge above first).
  This is the intended shape for an unmatched `/api/...` route — a parseable error rather than the
  frontend's own HTML page.
