# Maestro licence — activation, status, recovery

> Customer-facing reference for the `mso licence` CLI. The CLI talks to **`api.polar.sh` directly** — Maestro does not operate any licence-server infrastructure. Polar handles subscription billing, key issuance, and key state (granted / revoked / expired); the CLI reads that state via the Polar API.

## Tier limits (enforced in code, not just advertised)

Maestro's licence has four tiers: **community**, **pro**, **team**, **enterprise**. Running with no licence at all is the community tier — permanent and free, not a trial. Every limit below is enforced at the point of use, not merely described here:

| Limit | Community | Pro / Team / Enterprise |
|---|---|---|
| Concurrent crews (`mso dispatch --max-crews`) | **2** (any higher request is silently clamped, with a message stating the clamp and the requested value) | Uncapped by this gate |
| Registered projects (`mso init` / registering a new acronym) | **1** — registering a second, distinct acronym is refused; re-registering an already-known acronym (e.g. after a path change) is always allowed | Unlimited |
| Roles a crew can be dispatched as | `INV`, `PLN`, `BLD`, `TST` only — `SEC`, `DOC`, `REL` are refused with a licence message naming the required tier | All roles |
| `governance.governedMode` (`enforce`/`warn` in `workspace.json`) | Ignored — governance stays off, with a message explaining why | **Enterprise only** — pro and team also cannot turn this on |

Every gate above resolves the tier the same way (`maestro.auth.has_tier`), so `MAESTRO_SKIP_AUTH=1` (CI) bypasses all of them identically, and an unlicensed install is never treated as an error — it runs at the community limits shown above.

Advanced features gated separately (unchanged by the above): the Maestro Hub and non-free division packs require Team or Enterprise; signed policy bundle distribution (`mso policy pull`) and shared artefact mode require Enterprise.

## What a licence key is

A 26-character base32 string Polar issues to you on subscription. Looks like `adm_lic_AB12CD34EF56GH78IJ90KL`. **Treat it like an API token** — anyone with the key can activate Maestro as you, until you deactivate.

## Activate

```bash
mso licence activate <KEY>
```

What happens:
1. The CLI calls Polar's `customers/{cid}/license-keys/{key}/validate` endpoint to confirm the key is granted.
2. On success, your machine writes `~/.maestro/licence.json` (mode 0600) signed with a per-customer secret stored in your OS keychain (Keychain on macOS, Credential Manager on Windows, libsecret on Linux).
3. From now on, `adm` commands run normally.

**Activation requires the internet.** Without an online round-trip we can't trust the key.

### CI / non-interactive activation

```bash
MAESTRO_LICENCE_KEY=adm_lic_xxxxx adm <any-command>
```

The CLI activates on first run if no record is present. Useful for ephemeral build agents.

## Status

```bash
mso licence status         # human text
mso licence status --json  # JSON for scripts
```

Shows your tier, customer ID, issue date, expiry, last-validated time, and offline-grace deadline.

Any warning it reports — verification failure, revocation, expiry, running on offline grace — is **also printed once at `mso dispatch` startup** (and recorded in `.mso/logs/lifecycle.log`). You should never have to run `status` to discover that a fleet is about to launch at a tier you did not expect. An ordinary unlicensed install prints nothing: community is a normal tier, not a warning.

## Force a re-check

```bash
mso licence revalidate
```

Skips the 24-hour cache and calls Polar immediately. Use this if you've just renewed a subscription and want to refresh `expires_at` straight away.

> **Test-only:** `mso licence revalidate --offline-mark-stale` rewinds your local `last_validated_at` so the next `adm` run exercises the offline-grace path. Refuses to run unless `MAESTRO_*LICENCE_TEST_FLAGS=1` is set in your shell. Used during the live-test plan; not for everyday use.

> **Polar bypass for pre-launch testing:** set `MAESTRO_*LICENCE_FAKE_ACTIVATION=1` to skip the Polar API call entirely on `activate` and `revalidate`. The CLI synthesises a real-shape signed record (1-year Pro tier, customer ID prefixed `cust_FAKE_`). All other behaviour — HMAC tamper detection, keychain binding, offline grace, status banner — is unchanged. `mso licence status` shows `[FAKE ACTIVATION]` instead of `[TEST MODE]` so the synthetic state is obvious. Use this when Polar is unreachable (e.g. account under review) and you need to verify the install / activate / status / deactivate flow on a fresh machine.

## Deactivate

```bash
mso licence deactivate
```

Removes `~/.maestro/licence.json` and the keychain entry. **Does not** cancel your Polar subscription — manage that at https://polar.sh.

## Offline grace

After every successful online validation you get **14 days** of offline grace. During the window:

- If the network's down or Polar is degraded, `adm` keeps working with a warning banner like:
  > `⚠ Couldn't reach the licence backend; running on offline grace (10 days remaining). Reconnect to revalidate.`
- Reconnecting refreshes the window automatically the next time `adm` runs.
- Past 14 days with no online check → `adm` refuses to start until you connect or run `mso licence revalidate`.

For longer offline operation, see [Air-gapped operation](AIR-GAPPED.md).

## Tamper detection

If `~/.maestro/licence.json` is edited or copied from another machine, `adm` refuses to start with:

```
Licence file signature mismatch. The file may have been edited or copied
from another machine. Re-run `mso licence activate <KEY>` to recover.
```

The fix is always the same: re-run `mso licence activate` with your key. The CLI re-issues a fresh signed record bound to the current machine.

This is by design — your subscription is per-seat and we use the keychain entry to bind a record to a machine. **It's not a deactivation.** Polar doesn't know your file was tampered; you can re-activate as many times as your tier allows.

## Subscription cancelled — what happens?

| Event | What you see |
|---|---|
| You cancel via Polar customer portal | `adm` keeps working until end of paid period; on the next cache-stale validate it raises `LicenceRevoked` with a link back to https://polar.sh. |
| Refund processed | Polar marks the key revoked immediately. Next `adm` invocation past the cache window raises `LicenceRevoked`. |
| You re-subscribe | Re-run `mso licence activate <NEW-KEY>` (Polar issues a new key on re-subscribe) — your local state replaces the revoked record. |

## Does an install or upgrade preserve my licence?

**Yes, for the way almost everyone installs Maestro — a wheel install.** `pip
install` / `pip install --upgrade` replaces `site-packages/maestro/` with the
contents of a published wheel, and a correctly-published wheel carries the
vendor public key baked in at release-build time (see `scripts/
inject_licence_keys.py` and the injection step in `.github/workflows/
publish-pypi.yml` / `publish-maestro.yml`). Your activated licence
(`~/.maestro/licence.json`) lives outside `site-packages` entirely, so it is
never touched by the install itself — the only thing an install can change
is whether the copy of Maestro you now have still has a key to verify it
against.

| Install path | Licence preserved across install/upgrade? |
|---|---|
| `pip install --upgrade maestro` / `maestro-fleet` (wheel, from PyPI or the private index) | **Yes** — a correctly-published wheel always carries the vendor key. |
| `pip install . --no-deps` from a source clone of this repo | **No** — this repo's own tracked `maestro/licence/keys/licence-keys.json` ships `"keys": {}` by design (it is slated for a public mirror, so no key material is ever committed). This wipes any vendor key a previous install had. This is a deliberate trade-off, not a bug — see `maestro/licence/keys.py`'s module docstring. Restore it with `python scripts/inject_licence_keys.py` (maintainer-only tooling; requires the vendor key from outside the repo). |
| `pip install -e .` (editable install) | **No, and cannot be** — the "installed" keyring under editable mode *is* this repo's tracked `{}` file. Permanently community-tier by construction; use a non-editable install to run a licensed local fleet. |

If you're unsure which path you're on: `mso licence status` prints a warning
whenever a valid-looking token fails to verify because the installed copy's
keyring doesn't recognise it — see [BUG-MSO-2026-0513, below](#published-wheels-shipping-an-empty-trust-root-resolved).

### Published wheels shipping an empty trust root (resolved)

**Affected versions: `maestro` / `maestro-fleet` 5.6.4 and 5.7.0** (private
index and PyPI). A CI defect (BUG-MSO-2026-0513) meant these two releases
were built and published with an **empty** licence trust root — the release
build's key-injection step silently no-op'd (the same behaviour that is
correct and expected for a plain source-clone install, just wrongly reached
on the release path too) and nothing checked afterwards that a key had
actually landed.

**What you would have observed:** `mso licence activate <TOKEN>` appears to
succeed, but the fleet runs at **community** limits regardless of your
actual subscription tier (2 crews, `INV`/`PLN`/`BLD`/`TST` roles only, Hub
gated off) — the exact symptom described under ["Licence token failed
verification … running at community
tier"](#licence-token-failed-verification--running-at-community-tier) above,
except here the cause was the published artefact, not your local install.

**What to do:** upgrade to 5.8.0 or later (the first release built with the `--require-keys` guard, so its trust root is verified at build time) —

```bash
pip install --upgrade maestro --extra-index-url https://maestrodevs.github.io/simple/
# or: pip install --upgrade maestro-fleet
mso licence activate <YOUR-EXISTING-KEY>   # re-run — your key and Polar subscription are unaffected
mso licence status                          # confirm your real tier is back, no warning printed
```

Every release after this fix publishes only through a build step that now
hard-fails (rather than silently no-opping) if the vendor key isn't
correctly injected, so a keyless release can no longer reach either index —
see the CHANGELOG entry for BUG-MSO-2026-0513.

## Where things live on your machine

| Path | Purpose | Mode |
|---|---|---|
| `~/.maestro/licence.json` | Signed licence record | 0600 |
| OS keychain entry `maestro-licence/<customer_id>` | Per-customer signing secret | OS-managed |
| `~/.maestro/secrets/<customer_id>.key` (only on systems without a keychain provider) | Fallback for the signing secret | 0600 |

Nothing else. There are no remote files keyed to your account beyond what Polar holds for billing.

## Privacy

Activation transmits to `api.polar.sh` only:
- the licence key
- HTTP request metadata (User-Agent, IP)

That's it. No code, no prompts, no project names, no hostname. Verifiable from [`maestro/licence/client.py`](../maestro/licence/client.py).

## Common issues

### `Activation refused: <reason>`

Polar rejected the key. Most common causes:
- Typo (the key includes mixed case + digits; `0` vs `O`, `1` vs `l` are easy to mis-type).
- Expired subscription (re-subscribe at https://polar.sh).
- Wrong tier for the product (rare; open a [GitHub Issue](https://github.com/Maestrodevs)).

### `Couldn't reach the licence backend`

A network failure during activation — activation requires online verification. Try again on a live network. If Polar itself is down (check https://status.polar.sh), wait it out.

### `Licence file signature mismatch` after a system update

Some OS updates rotate the keychain master key (rare; macOS Migration Assistant is the most common cause). Re-run `mso licence activate <KEY>`.

### `Licence token failed verification … running at community tier`

Your token is well-formed, but this **installation** has no vendor signing key matching it, so verification fails closed and you drop to community limits. The usual cause is an install built from a source checkout rather than an official release wheel — source clones deliberately ship no signing key. Reinstall from the official channel; if it persists on an official wheel, send your `mso licence status` output to [maestrodevs.com/contact](https://www.maestrodevs.com/contact/) for a re-issue.

Full walkthrough, including how to tell this apart from the tamper path above: [TROUBLESHOOTING.md E30](TROUBLESHOOTING.md#e30--licence-activated-but-maestro-still-runs-at-community-tier).

### `Offline grace expired`

You've been offline > 14 days. Connect to the internet and run `mso licence revalidate`.

## Where to ask questions

- GitHub Issues: https://github.com/Maestrodevs
- GitHub Discussions: https://github.com/Maestrodevs
- Status of the licence backend: https://status.maestroai.com (not yet live; placeholder)
