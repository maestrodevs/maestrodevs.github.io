# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""
Maestro — GitHub collaborator licence validation.

Single public entry point: check().
Bypassable via MAESTRO_SKIP_AUTH=1 (CI/CD) or for 'version'/'init' subcommands.
"""

import getpass
import json
import os
import sys
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

from maestro.egress.filter import install_egress_filter, EgressDenied
from maestro.workspace import get_maestro_home

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

REPO = "tavisbasing/Maestro"
# Test/override hook. ``None`` ⇒ resolve live under the env-aware global home so
# MAESTRO_HOME redirects the auth cache (BUG-MSO-2026-0387). Tests that
# ``monkeypatch.setattr(auth, "AUTH_FILE", tmp)`` keep working — an explicit
# path wins over the resolver.
AUTH_FILE: Path | None = None
API_BASE = "https://api.github.com"
DEFAULT_GRACE_DAYS = 7
TIMEOUT_SECONDS = 5

# FTR-MSO-2026-0452 §D3b-i: the minimal always-available command floor. A
# STOPPED licence (Team/Enterprise past its 14-day grace) must never lock the
# operator out — applying a new licence is itself a command. This is also the
# pre-existing "skip auth entirely" bypass list (chicken-and-egg: `licence
# activate` is the only way to bootstrap a licence in the first place), so
# the two concerns share one set rather than inventing a second mechanism.
# Explicitly, per the order:
#   licence / license  — activate | status | deactivate | revalidate
#   version             — diagnosis
#   help / docs         — self-service
#   status               — the dispatcher Status Monitor dashboard; read-only
#                          inspection that must still explain WHY a fleet is
#                          stopped (plan §8 D6 hazard #2 — a blank/erroring
#                          dashboard at exactly the moment it's needed repeats
#                          the BUG-MSO-2026-0442 lesson).
#   init                 — scaffolding a brand-new (unlicensed) workspace
_SKIP_COMMANDS = {"version", "init", "licence", "license", "docs", "help", "status"}


def _auth_file() -> Path:
    """Resolve the auth-cache path live so ``MAESTRO_HOME`` is honoured."""
    if AUTH_FILE is not None:
        return Path(AUTH_FILE)
    return get_maestro_home() / "auth.json"


# ---------------------------------------------------------------------------
# Cache helpers
# ---------------------------------------------------------------------------

def _load_cache() -> dict:
    """Read the auth cache; return {} if missing or corrupt."""
    try:
        with _auth_file().open("r", encoding="utf-8") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return {}


def _save_cache(data: dict) -> None:
    """Write data to the auth cache with mode 0600. Creates the home if needed."""
    try:
        auth_file = _auth_file()
        dir_path = auth_file.parent
        dir_path.mkdir(mode=0o700, parents=True, exist_ok=True)
        with auth_file.open("w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        try:
            auth_file.chmod(0o600)
        except OSError:
            pass  # Limited effect on Windows — silently continue
    except OSError as exc:
        print(f"[Maestro] Warning: could not write auth cache ({exc})", file=sys.stderr)


# ---------------------------------------------------------------------------
# Token prompt
# ---------------------------------------------------------------------------

def _prompt_for_token() -> tuple:
    """Prompt for a GitHub PAT, resolve username via /user, return (token, username)."""
    print("[Maestro] GitHub authorisation required.", file=sys.stderr)
    print(
        "A GitHub Personal Access Token (PAT) with 'repo' scope is needed to verify\n"
        "your licence as an authorised collaborator on tavisbasing/Maestro.\n"
        "Create one at: https://github.com/settings/tokens",
        file=sys.stderr,
    )
    token = getpass.getpass("GitHub Personal Access Token: ")

    # Resolve username via /user endpoint
    req = urllib.request.Request(
        f"{API_BASE}/user",
        headers={
            "Authorization": f"Bearer {token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT_SECONDS) as resp:
            user_data = json.loads(resp.read().decode("utf-8"))
            username = user_data.get("login", "")
    except (urllib.error.URLError, urllib.error.HTTPError, json.JSONDecodeError, OSError) as exc:
        print(f"[Maestro] Failed to verify token: {exc}", file=sys.stderr)
        sys.exit(1)

    if not username:
        print("[Maestro] Could not determine GitHub username from token.", file=sys.stderr)
        sys.exit(1)

    return token, username


# ---------------------------------------------------------------------------
# Collaborator verification
# ---------------------------------------------------------------------------

def _verify_collaborator(token: str, username: str) -> str:
    """
    Call GET /repos/{REPO}/collaborators/{username}.

    Returns one of: 'ok', 'not_collaborator', 'bad_token', 'network_error'.
    """
    url = f"{API_BASE}/repos/{REPO}/collaborators/{username}"
    req = urllib.request.Request(
        url,
        headers={
            "Authorization": f"Bearer {token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT_SECONDS) as resp:
            if resp.status == 204:
                return "ok"
            return "not_collaborator"
    except EgressDenied as exc:
        print(f"[Maestro] {exc}", file=sys.stderr)
        return "network_error"
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            return "not_collaborator"
        if exc.code in (401, 403):
            return "bad_token"
        return "network_error"
    except (urllib.error.URLError, OSError):
        return "network_error"


# ---------------------------------------------------------------------------
# Exit messages
# ---------------------------------------------------------------------------

def _exit_not_collaborator() -> None:
    print(
        "\n[Maestro] Licence validation failed.\n"
        f"You are not listed as an authorised collaborator on {REPO}.\n\n"
        "To obtain access, contact: https://github.com/tavisbasing\n"
        f"For licensing enquiries: https://github.com/{REPO}\n",
        file=sys.stderr,
    )
    sys.exit(1)


def _exit_grace_expired(grace_days: int) -> None:
    print(
        f"\n[Maestro] Offline grace period expired ({grace_days} days).\n"
        "Could not reach GitHub to verify your licence.\n"
        "Please connect to the internet and retry, or contact https://github.com/tavisbasing.\n",
        file=sys.stderr,
    )
    sys.exit(1)


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Tier gate (Maestro Hub and future enterprise features)
# ---------------------------------------------------------------------------

HUB_TIERS = {"team", "enterprise"}

# PLAN-VOY-MSO-2026-0143 ruling 0a#3 (Maestro Charts tier ladder): chart
# *visualization* (`mso chart show`, the Hub's read-only graph view) is a
# `community`-tier feature — the marketing X-ray surface, and it must work
# without a licence. Authoring/execution (Phase 2: onFail/maxLaps) and the
# fan-in/verifier-panel/Hub-editor surface (Phase 3-4) will define their own,
# narrower tier sets alongside that work rather than widen this one.
CHART_VIEW_TIERS = {"community", "pro", "team", "enterprise"}

# FTR-MSO-2026-0505 (Captain ruling 2026-08-18): community tier is capped at
# 2 concurrent crews. Enforced in maestro.core.fleet_runner.run_dispatcher —
# a single choke point that covers the `mso dispatch --max-crews` CLI flag,
# the Hub's dispatch endpoint (which shells out to the same CLI), and a
# direct run_dispatcher() call, all identically.
COMMUNITY_MAX_CREWS = 2

# Roles gated behind Pro/Team/Enterprise — community is limited to
# INV/PLN/BLD/TST (FTR-MSO-2026-0505, Captain ruling 2026-08-18). This exists
# only as text in the downgrade banner today; the actual dispatch gate lives
# in maestro.core.fleet_runner._validate_role_tier_before_launch.
TIER_GATED_ROLES = {"SEC", "DOC", "REL"}


def community_crew_cap(requested: int) -> int:
    """Clamp `requested` concurrent-crew count to the community-tier cap.

    Any tier at or above pro is uncapped by this gate. MAESTRO_SKIP_AUTH
    bypasses via has_tier, and an unlicensed install (community) is clamped —
    that IS the community limit, not a bypass of it.
    """
    if has_tier({"pro", "team", "enterprise"}):
        return requested
    return min(requested, COMMUNITY_MAX_CREWS)


def has_tier(allowed: set) -> bool:
    """True if the licence's EFFECTIVE tier is in `allowed`. Never raises.

    Uses ``effective_tier`` (post tier-dependent-expiry, §D3b), not the raw
    stored ``tier`` — a downgraded-to-community record must not keep
    granting Hub/team/enterprise access just because the underlying token
    still carries its original tier string. v1 records have no
    ``effective_tier`` (that schema predates §D3b's downgrade concept) and
    fall back to ``.tier`` unchanged.

    ``status() is None`` is not an error — per its own docstring it means
    "no usable licence on disk" == ``community`` tier (§D3a). Every existing
    caller's ``allowed`` set (``HUB_TIERS``, ``SHARED_TIERS``, ``{"enterprise"}``)
    excludes ``community``, so this was previously indistinguishable from a
    blanket deny; ``CHART_VIEW_TIERS`` is the first set that includes
    ``community``, and PLAN-0143 ruling 0a#3 requires that an unlicensed
    install still passes it — chart visualization must work without a
    licence.
    """
    from maestro.env import skip_auth
    if skip_auth():
        return True
    try:
        from maestro.licence import COMMUNITY_TIER, status
        rec = status()
        if rec is None:
            return COMMUNITY_TIER in allowed
        tier = getattr(rec, "effective_tier", None) or rec.tier
        return tier in allowed
    except Exception:
        return False


def licence_dispatch_gate() -> "tuple[bool, str]":
    """FTR-MSO-2026-0452 §D3b-i: may `mso dispatch` launch a NEW crew right
    now? Returns ``(allowed, reason)`` — ``reason`` is only meaningful when
    ``allowed`` is False.

    Refuses only for a STOPPED licence (Team/Enterprise past its 14-day
    grace, §D3b: no downgrade exists for that tier). Every other state
    (community, valid, within grace, downgraded) allows dispatch — a
    downgraded-to-community install still gets to dispatch (its concurrency
    cap is a separate, later gate — FTR-MSO-2026-0454 — not this one).

    Deliberately never touches running crews — callers (the dispatcher) are
    responsible for draining rather than killing. See
    maestro.core.fleet_runner._licence_gate_allows_dispatch, which is the
    actual call site and documents how draining reuses the existing
    SHUTDOWN_REQUESTED exit path instead of inventing a second one.
    """
    from maestro.env import skip_auth
    if skip_auth():
        return True, ""
    try:
        from maestro.licence import resolve_state
        state = resolve_state()
    except Exception:
        # A licence-module failure must never itself block dispatch —
        # that would turn a bug in this module into an outage.
        return True, ""
    if state.stopped:
        return False, (state.warning or f"Maestro {state.tier} licence STOPPED.")
    return True, ""


def licence_keyring_warning() -> "str | None":
    """BUG-MSO-2026-0503: surface ``resolve_state().warning`` OUTSIDE of
    ``mso licence status`` — the one place it was previously printed.

    ``licence_dispatch_gate()`` above only inspects ``state.stopped``; a
    silent community downgrade (e.g. the vendor keyring in
    ``maestro/licence/keys.py`` came back empty after a ``pip install .``
    refresh wiped it — see that module's docstring) leaves ``stopped`` False
    and ``allowed`` True, so the gate itself never surfaces anything. That is
    correct for the drain-vs-refuse decision, but it means an operator could
    otherwise only discover the downgrade by noticing the Hub return 403 or
    the community crew cap kick in — never from a message. This function is
    the fix: called once at dispatcher startup (mirrors the FTR-MSO-2026-0505
    ``community_crew_cap`` warning already printed there) so the SAME
    ``state.warning`` `mso licence status` shows is also seen before crews
    ever launch.

    Returns the warning string, or ``None`` when there is nothing to report
    (includes the ordinary "never licensed" case — ``resolve_state()`` only
    sets ``.warning`` for a record that failed verification or was
    downgraded/graced from a paid tier, never for a plain unlicensed
    install). Never raises — a licence-module failure must not block
    dispatch, matching ``licence_dispatch_gate()``'s own fail-open contract.
    """
    from maestro.env import skip_auth
    if skip_auth():
        return None
    try:
        from maestro.licence import resolve_state
        state = resolve_state()
    except Exception:
        return None
    return state.warning


def require_tier(allowed: set, feature: str = "this feature") -> None:
    """Exit(1) with an upgrade message if the active licence tier is not in `allowed`."""
    if has_tier(allowed):
        return
    from maestro.licence import RENEWAL_CONTACT_URL
    print(
        f"\n[Maestro] {feature} requires a Team or Enterprise licence.\n"
        f"Your current tier does not include access to this feature.\n"
        f"Upgrade: {RENEWAL_CONTACT_URL}\n",
        file=sys.stderr,
    )
    sys.exit(1)


def _exit_licence_stopped(warning: str) -> None:
    print(f"\n[Maestro] {warning}\n", file=sys.stderr)
    sys.exit(1)


def check() -> None:
    """
    Verify the caller is licensed to run Maestro.

    Resolution order (first match wins):
      1. MAESTRO_SKIP_AUTH=1 in env  → skip
      2. MAESTRO_LICENCE_FAKE_ACTIVATION=1 in env → skip
         (fake-activation flow is itself the auth)
      3. Subcommand is in _SKIP_COMMANDS (the always-available floor,
         §D3b-i) → skip
      4. Resolve the licence state (maestro.licence.resolve_state()):
           - community (no licence, or auto-downgraded from an expired
             trial/Pro licence) → PASS. §D3a: this is not an error — it is
             a valid, permanent, free tier. This supersedes the legacy
             GitHub-collaborator path entirely: an unlicensed install must
             never be prompted for a GitHub PAT (AC: "An unlicensed install
             runs at community tier without error").
           - a Team/Enterprise licence past its 14-day grace (`stopped`)
             → refuse (§D3b: no downgrade exists for this tier).
           - anything else (valid, or within grace, or downgraded) → PASS,
             printing at most one banner line (T-30d/T-7d/grace/downgrade).
      5. (unreachable in practice — see note below) legacy GitHub-
         collaborator path, retained only for defence-in-depth if the
         licence module itself fails to import.

    The legacy GH-collab path predates the licence module and is now
    reached only if `maestro.licence` raises something resolve_state()
    itself doesn't catch (an internal bug, not a licensing state) — every
    licensing outcome (missing/tampered/invalid/expired/revoked/stopped) is
    now handled by resolve_state() itself, per §D3a.
    """
    # Env-var bypass (CI/CD)
    from maestro.env import skip_auth as _skip_auth
    if _skip_auth():
        return

    # Fake-activation bypass — the test-only escape is itself the auth.
    if os.environ.get("MAESTRO_LICENCE_FAKE_ACTIVATION") == "1":
        return

    # Subcommand bypass — the always-available floor (§D3b-i). Also covers
    # bootstrapping: `mso licence activate` is the ONLY way to acquire a
    # licence; gating it on licence state would be a chicken-and-egg.
    if len(sys.argv) > 1 and sys.argv[1] in _SKIP_COMMANDS:
        return

    # Primary auth (v2.5.0+, tier-aware from FTR-MSO-2026-0452) — community
    # (no licence at all) is success, not a fall-through condition.
    try:
        from maestro.licence import resolve_state as _resolve_licence_state
        state = _resolve_licence_state()
        if state.stopped:
            _exit_licence_stopped(state.warning or "Maestro licence STOPPED.")
        if state.warning:
            print(state.warning, file=sys.stderr)
        return
    except SystemExit:
        raise
    except Exception:
        # If the licence module itself fails to import / read, fall
        # through to the legacy path rather than hard-fail.
        pass

    # Install egress filter (no-op in permissive/non-enterprise mode)
    try:
        from pathlib import Path as _Path
        from maestro.workspace import find_workspace_dir as _find_ws
        _mso = _find_ws(_Path.cwd())
        if _mso is not None:
            install_egress_filter(_mso.parent)
    except Exception:
        pass

    cache = _load_cache()
    token = cache.get("token", "")
    username = cache.get("username", "")

    # First run — no token cached
    if not token:
        token, username = _prompt_for_token()
        cache = {"token": token, "username": username, "last_verified": ""}
        _save_cache(cache)

    # Verify collaborator status
    result = _verify_collaborator(token, username)

    if result == "ok":
        cache["last_verified"] = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        cache["token"] = token
        cache["username"] = username
        _save_cache(cache)
        return

    if result == "not_collaborator":
        _exit_not_collaborator()

    if result == "bad_token":
        print("[Maestro] Token rejected (401/403). Please re-enter your PAT.", file=sys.stderr)
        token, username = _prompt_for_token()
        retry = _verify_collaborator(token, username)
        if retry == "ok":
            cache["token"] = token
            cache["username"] = username
            cache["last_verified"] = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
            _save_cache(cache)
            return
        if retry == "not_collaborator":
            _exit_not_collaborator()
        # bad_token again or network_error — fall through to network_error handling
        result = retry

    # network_error — check grace period
    grace_days = DEFAULT_GRACE_DAYS
    try:
        grace_days = int(os.environ.get("MAESTRO_OFFLINE_GRACE_DAYS", DEFAULT_GRACE_DAYS))
    except (ValueError, TypeError):
        pass

    last_verified = cache.get("last_verified", "")
    if last_verified:
        try:
            last_dt = datetime.strptime(last_verified, "%Y-%m-%dT%H:%M:%SZ").replace(
                tzinfo=timezone.utc
            )
            elapsed = (datetime.now(timezone.utc) - last_dt).days
            if elapsed <= grace_days:
                print(
                    f"[Maestro] Warning: could not reach GitHub (offline). "
                    f"Grace period active ({elapsed}/{grace_days} days).",
                    file=sys.stderr,
                )
                return
        except ValueError:
            pass

    _exit_grace_expired(grace_days)
