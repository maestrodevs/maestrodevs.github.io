# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Pydantic models for the Maestro Hub API (all phases in one module).

Field names here are chosen to serialize to JSON that matches the frontend
TypeScript interfaces in `maestro-hub/app/types/index.ts` EXACTLY (the
authoritative data contract). Top-level entity fields are snake_case to match
the TS interfaces; the WorkspaceConfig sub-object intentionally keeps camelCase
keys (maxCrews, completion.idleWatchdog...) because the frontend reads them
straight from .mso/config/workspace.json shapes.
"""

from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, Field


# ---- Phase 1 ----------------------------------------------------------------

class HealthResponse(BaseModel):
    status: str = "ok"
    version: str
    workspaces: int = 0
    # BUG-MSO-2026-0467: was the poller's first full scan pass complete when
    # this response was built? False during the cold-start window — lets a
    # caller distinguish "workspaces: 0, still scanning" from "workspaces: 0,
    # genuinely nothing registered" without a second endpoint round-trip.
    poller_ready: bool = True


class PollerStatus(BaseModel):
    """Poller readiness — the authoritative source for the initialising-vs-empty
    distinction (BUG-MSO-2026-0467). See WorkspacePoller.status()."""
    state: str = "ready"   # "initialising" | "ready"
    ready: bool = True
    scanned: int = 0
    total: int = 0


class AttentionBreakdown(BaseModel):
    """Per-workspace rollup of BUG-MSO-2026-0451's held/dispatchable taxonomy,
    computed workspace-by-workspace by ``maestro.hub.attention``
    (FTR-MSO-2026-0487 / PLAN-PLN-MSO-2026-0468 §2 — reuses the four category
    NAMES ``get_held_breakdown()`` already established; this is not a second,
    competing taxonomy).

    Bucket mapping (§2): review_gated -> "In Review" (a human decision),
    stranded -> "Needs Attention" (a recovery), dep_held -> "Blocked"
    (resolves itself), skipped -> "Skipped" (operator-intended invisibility).
    """
    review_gated: int = 0
    stranded: int = 0
    dep_held: int = 0
    skipped: int = 0
    # needs_you = review_gated + stranded — the two buckets a human must act
    # on. Excludes dep_held (self-resolving) and skipped (operator-intended),
    # matching §2's ruling that both merge only at this summary level, never
    # in the per-bucket lists.
    needs_you: int = 0


class WorkspaceSummary(BaseModel):
    id: str
    name: str
    path: str
    online: bool = True
    dispatcher_running: bool = False
    active_voyage_count: int = 0
    pending_order_count: int = 0
    active_crew_count: int = 0
    review_pending_count: int = 0
    # Frontend Workspace interface uses `pending_review_count`; mirror it so the
    # overview cards can read either name. (Kept additive — review_pending_count
    # above is preserved so existing consumers/tests don't break.)
    pending_review_count: int = 0
    # BUG-MSO-2026-0451: orders excluded from pending_order_count because the
    # dispatcher is holding them (dep-held or operator-skipped) — the Hub-card
    # counterpart of `mso status`'s "N held" figure, so a fixed pending count
    # doesn't just make skipped/dep-held work silently vanish from the card.
    held_order_count: int = 0
    # FTR-MSO-2026-0487: the named breakdown behind held_order_count, plus the
    # review-gated + stranded categories held_order_count never counted (it
    # only ever covered dep-held + skipped). This is the one figure the
    # workspace card needs for "Needs you: N".
    attention: AttentionBreakdown = Field(default_factory=AttentionBreakdown)


# ---- Phase 2 ----------------------------------------------------------------

class ClaimedBy(BaseModel):
    """The FTR-MSO-2026-0374 shared-mode claim-by-commit stamp.

    Matches the frontend `ClaimedBy` interface. Mirrors the shape
    `_stamp_claim()` (maestro/core/artefact_sync.py) writes onto the durable
    order JSON — engineer identity, host, pid, and claim timestamp.
    """
    engineer: str = ""
    host: str = ""
    pid: Optional[int] = None
    at: str = ""


class Order(BaseModel):
    """Matches the frontend `Order` interface (app/types/index.ts)."""
    id: str
    title: str = ""
    description: Optional[str] = None
    status: str = "PENDING"
    role: str = ""
    target_role: Optional[str] = None
    voyage_id: Optional[str] = None
    workspace_id: str = ""
    priority: Optional[str] = None  # 'high' | 'normal' | 'low'
    created_at: str = ""
    updated_at: Optional[str] = None
    started_at: Optional[str] = None
    completed_at: Optional[str] = None
    depends_on: Optional[list[str]] = None
    role_sequence: list[str] = Field(default_factory=list)
    timeout_minutes: Optional[int] = None
    iteration: Optional[int] = None
    max_iterations: Optional[int] = None
    target_repo: Optional[str] = None
    # FTR-MSO-2026-0376: shared-mode multi-engineer visibility. Field names
    # are camelCase by order spec (mirrors Voyage.phaseReason above); absent
    # in embedded/solo mode where the order was never claimed-by-commit.
    claimedBy: Optional[ClaimedBy] = None
    claimedAt: Optional[str] = None
    # FTR-MSO-2026-0487: BUG-MSO-2026-0451 taxonomy tag — one of
    # 'review_gated' | 'stranded' | 'dep_held' | 'skipped', or None when the
    # order is plainly dispatchable/running/complete. Computed per workspace
    # by maestro.hub.attention.classify_orders (never re-derived client-side —
    # PLAN-PLN-MSO-2026-0468 §3.3's "reuse, don't copy the category list").
    attention: Optional[str] = None
    # Human-readable detail for the tag above — e.g. the blocking order id(s)
    # for a dep_held order. Empty/None for categories with no extra detail.
    attention_reason: Optional[str] = None


class VoyagePrEntry(BaseModel):
    """One repo's PR linkage within a voyage's ``prUrls`` map (FTR-MSO-2026-0380).

    Mirrors the per-repo entry ``_apply_pr_linkage``/``_reconcile_multi_repo_voyage``
    write onto ``voyage["prUrls"][repo_slug]`` (maestro/core/fleet_runner.py).
    Field names are camelCase to match the manifest verbatim (same convention
    as Voyage.phaseReason / Order.claimedBy above).
    """
    prNumber: Optional[int] = None
    prUrl: Optional[str] = None
    state: Optional[str] = None
    mergeCommit: Optional[str] = None
    mergedAt: Optional[str] = None


class VoyageOrderRollup(BaseModel):
    """Effective member-order counts backing the derived voyage phase
    (FTR-MSO-2026-0351). Keys are camelCase by contract (order spec)."""
    total: int = 0
    complete: int = 0
    blocked: int = 0
    inProgress: int = 0
    pending: int = 0
    held: int = 0


class Voyage(BaseModel):
    """Matches the frontend `Voyage` interface."""
    id: str
    title: str = ""
    status: str = "PLANNED"
    branch: str = ""
    order_count: int = 0
    complete_count: int = 0
    orders: Optional[list[Order]] = None
    created_at: str = ""
    pr_url: Optional[str] = None
    # BUG-MSO-2026-0394: sibling flat field to pr_url — the manifest's
    # flat prNumber (written by ``_apply_pr_linkage``), or the single
    # entry's prNumber when the manifest only ever wrote a prUrls map.
    # Ambiguous (left None) for a genuine multi-repo voyage with >1 PR
    # linked — per-repo numbers are available via prUrls in that case.
    pr_number: Optional[int] = None
    workspace_id: str = ""
    repo: str = ""
    worktree: str = ""
    # FTR-MSO-2026-0351: derived lifecycle phase from ledger + archive + PR
    # state (the stored `status` above is kept as-is for back-compat).
    phase: str = "backlog"
    phaseReason: str = ""
    rollup: VoyageOrderRollup = Field(default_factory=VoyageOrderRollup)
    # FTR-MSO-2026-0380: multi-repo voyage reality (FTR-0379 manifest shape).
    # `repo`/`pr_url` above remain the back-compat flat fields (unchanged
    # derivation — most-common targetRepo / best-effort last-recorded PR);
    # these carry the REAL per-repo set so the Hub can render one pill per
    # repo instead of collapsing to a single value. Empty for a legacy/
    # single-repo voyage that never wrote targetRepos/prUrls. camelCase by
    # order spec (mirrors phaseReason/claimedBy — matches the manifest keys
    # verbatim).
    targetRepos: list[str] = Field(default_factory=list)
    prUrls: dict[str, VoyagePrEntry] = Field(default_factory=dict)


class CrewState(BaseModel):
    """Matches the frontend `CrewState` interface."""
    slot: int
    name: str = ""
    status: str = "IDLE"
    role: Optional[str] = None
    current_order_id: Optional[str] = None
    current_order_title: Optional[str] = None
    iteration: Optional[int] = None
    max_iterations: Optional[int] = None
    activity_age_seconds: Optional[int] = None
    pid: Optional[int] = None
    session_id: Optional[str] = None
    maestro_session_id: Optional[str] = None


class Repo(BaseModel):
    """Matches the frontend `Repo` interface."""
    id: str
    name: str
    path: str
    default_branch: str = "main"


class IdleWatchdogConfig(BaseModel):
    enabled: bool = False
    idleMinutes: int = 30
    action: str = "none"


class OnVoyageCompleteConfig(BaseModel):
    archiveVoyageOnMerge: bool = True
    archiveOrders: bool = True
    autoRelease: bool = False


class CompletionConfig(BaseModel):
    idleWatchdog: Optional[IdleWatchdogConfig] = None
    onVoyageComplete: Optional[OnVoyageCompleteConfig] = None
    roleTimeouts: Optional[dict[str, int]] = None


class WorkspaceConfig(BaseModel):
    """Matches the frontend `WorkspaceConfig` interface (camelCase preserved)."""
    persona: Optional[str] = None
    project: Optional[str] = None
    maxCrews: Optional[int] = None
    completion: Optional[CompletionConfig] = None
    # FTR-MSO-2026-0328: per-workspace dispatch defaults (null = not configured)
    maxIterations: Optional[int] = None
    maxTurns: Optional[int] = None
    timeoutMinutes: Optional[int] = None
    autoDispatch: Optional[bool] = None
    requirePlanReview: Optional[bool] = None
    tokenDailyCap: Optional[int] = None


class UsagePoint(BaseModel):
    """One data point in a workspace token-usage history series."""
    date: str          # ISO date string (YYYY-MM-DD)
    tokens: int = 0
    cost_usd: float = 0.0


class WorkspaceUsage(BaseModel):
    """Aggregated token-usage metrics for a workspace (FTR-MSO-2026-0330)."""
    total_tokens: int = 0
    estimated_cost_usd: float = 0.0
    order_count: int = 0                        # number of orders with usage data
    history: list[UsagePoint] = Field(default_factory=list)  # per-day series (newest last)


class WorkspaceDetail(BaseModel):
    """Matches the frontend `WorkspaceDetail` (extends Workspace) interface."""
    id: str
    name: str
    path: str
    dispatcher_running: bool = False
    active_crew_count: int = 0
    active_voyage_count: int = 0
    pending_review_count: int = 0
    pending_order_count: int = 0
    held_order_count: int = 0  # BUG-MSO-2026-0451: dep-held + operator-skipped
    # FTR-MSO-2026-0487: see WorkspaceSummary.attention — same rollup, full detail view.
    attention: AttentionBreakdown = Field(default_factory=AttentionBreakdown)
    persona: Optional[str] = None
    project: Optional[str] = None
    config: WorkspaceConfig = Field(default_factory=WorkspaceConfig)
    voyages: list[Voyage] = Field(default_factory=list)
    crews: list[CrewState] = Field(default_factory=list)
    queue_summary: dict[str, int] = Field(default_factory=dict)
    orders: list[Order] = Field(default_factory=list)
    repos: list[Repo] = Field(default_factory=list)
    usage: Optional[WorkspaceUsage] = None
    # FTR-MSO-2026-0376: 'embedded' | 'solo' | 'shared' (maestro.workspace
    # ARTEFACT_MODES) — lets the frontend show a SHARED indicator without
    # inferring it from claimedBy presence alone. camelCase by order spec.
    artefactMode: str = "embedded"
    # FTR-MSO-2026-0492 §4.4: the exact `mso dispatch` command for a backlog
    # voyage, computed server-side from the PRODUCT repo path (never `path`
    # above, which is the artefact parent in solo/shared mode) — a
    # frontend-assembled `cd {path}` would print a command that fails on the
    # operator's machine. Empty when unknown (e.g. offline_detail()).
    dispatchCommand: str = ""


class LifecycleEvent(BaseModel):
    """Matches the frontend `LifecycleEvent` interface (WebSocket stream)."""
    workspace_id: str
    workspace_name: str
    line: str = ""              # raw log line (kept for backward-compat)
    message: str = ""           # parsed message — frontend contract field
    timestamp: str = ""
    event_type: str = ""
    order_id: Optional[str] = None
    crew_slot: Optional[int] = None
    role: Optional[str] = None
    subtype: Optional[str] = None


# ---- Phase 3 ----------------------------------------------------------------

class ReviewItem(BaseModel):
    """Matches the frontend `ReviewItem` interface (BARE-ARRAY endpoint)."""
    order_id: str
    workspace_id: str
    workspace_name: str = ""
    order_title: str = ""
    role: str = ""
    voyage_id: Optional[str] = None
    plan_markdown: Optional[str] = None
    created_at: str = ""
    paused_at: Optional[str] = None
    priority: Optional[str] = None


class PlanResponse(BaseModel):
    workspace_id: str
    order_id: str
    plan_markdown: str = ""
    has_plan_file: bool = False
    order: dict


class ReviseRequest(BaseModel):
    feedback: str


class RejectRequest(BaseModel):
    reason: str


class ActionResult(BaseModel):
    ok: bool
    order_id: str
    new_status: str = ""
    message: str = ""


# ---- Artefacts + Retry (FTR-MSO-2026-0492) ----------------------------------

class ArtefactRef(BaseModel):
    """One discovered artefact's manifest entry — no content.

    ``key`` is an opaque, server-issued token (``discover_artefacts``'s
    ``{kind}:{name}`` form); a client cannot construct one that resolves to a
    file discovery did not itself find (maestro/hub/artefacts.py §4.2).
    """
    key: str
    kind: str
    name: str
    size: int = 0
    modified: str = ""


class OrderArtefacts(BaseModel):
    """Response for ``GET /orders/{id}/artefacts`` — manifest only, no content."""
    order_id: str
    workspace_id: str
    artefacts: list[ArtefactRef] = Field(default_factory=list)


class ArtefactContent(BaseModel):
    """Response for ``GET /orders/{id}/artefacts/{key}`` — one artefact's body.

    Bounded at ``artefacts.MAX_ARTEFACT_BYTES`` (512 KB, §5.5); ``truncated``
    is set and ``size`` still carries the true on-disk size when the read was
    capped.
    """
    key: str
    kind: str
    name: str
    content: str = ""
    truncated: bool = False
    size: int = 0


class RetryResult(BaseModel):
    """Response for ``POST /orders/{id}/retry``."""
    ok: bool
    order_id: str
    new_status: str = ""
    target_role: str = ""
    salvage_branch: Optional[str] = None
    message: str = ""


class ControlResult(BaseModel):
    """Result of a workspace dispatch/stop control action (Feature B)."""
    ok: bool
    workspace_id: str
    action: str = ""   # 'dispatch' | 'stop'
    message: str = ""


class SweepEntry(BaseModel):
    """One housekeeping decision — what was done, or refused, and why.

    FTR-MSO-2026-0426. Mirrors an entry produced by
    ``fleet_runner._sweep_note``.
    """
    voyage: str = ""
    action: str = ""      # archived | annotated | linked | skipped | flagged
    reason: str = ""
    prNumber: Optional[int] = None
    mergedAt: Optional[str] = None
    order: Optional[str] = None
    orderStatus: Optional[str] = None
    repos: Optional[list[str]] = None


class SweepResult(BaseModel):
    """Result of a workspace housekeeping sweep (FTR-MSO-2026-0426).

    Carries the same report ``mso voyage reconcile --json`` prints, so the Hub
    button and the CLI surface identical results.
    """
    ok: bool
    workspace_id: str
    action: str = "sweep"
    message: str = ""
    dryRun: bool = False
    archived: int = 0
    annotated: int = 0
    changes: list[SweepEntry] = Field(default_factory=list)
    refusals: list[SweepEntry] = Field(default_factory=list)


# ---- Capabilities (FTR-MSO-2026-0489) ---------------------------------------

class CapabilityInfo(BaseModel):
    """Whether one mutating action is available in THIS deployment, and why not.

    PLAN-PLN-MSO-2026-0468 §4.5 / BUG-MSO-2026-0440: the reason a caller cannot
    act is declared here, before any click, so the frontend renders a disabled
    control with its reason instead of discovering a 409 after the fact.
    ``reason`` is populated only when ``available`` is False and is always the
    same server-side constant the corresponding endpoint's 409 uses.
    """
    available: bool = True
    reason: Optional[str] = None


class TierCapability(BaseModel):
    """Licence-tier gate shared by every mutating control action.

    Distinct from ``CapabilityInfo`` above: a deployment can be fully CAPABLE
    of an action (e.g. dispatch on a host session) and still be refused it for
    lacking a Team/Enterprise licence — two independent reasons to disable a
    button, both declared up front.
    """
    control: bool = False
    reason: Optional[str] = None


class CapabilityMap(BaseModel):
    """Response for ``GET /api/v1/capabilities`` — poller-independent, cheap.

    Declares, up front, which mutating actions this Hub deployment can
    actually perform, so the frontend disables a button WITH ITS REASON
    before the click rather than rendering it enabled-and-hopeful.
    """
    dispatch: CapabilityInfo = Field(default_factory=CapabilityInfo)
    sweep: CapabilityInfo = Field(default_factory=CapabilityInfo)
    review: CapabilityInfo = Field(default_factory=CapabilityInfo)
    orderRetry: CapabilityInfo = Field(default_factory=CapabilityInfo)
    tier: TierCapability = Field(default_factory=TierCapability)


# ---- Charts (FTR-MSO-2026-0496, PLAN-VOY-MSO-2026-0143 Phase 1 part 2) ------
# Field names mirror maestro.core.charts.Waypoint/Leg/Chart.to_dict() exactly
# (the same shape `mso chart show --format json` prints) so the CLI and the
# Hub's read-only graph view can never disagree about the wire format.

class ChartWaypoint(BaseModel):
    """One compiled chart node — matches Waypoint.to_dict()."""
    order: str
    role: str
    state: str = "NOT_STARTED"
    humanGate: bool = False


class ChartLeg(BaseModel):
    """One compiled chart edge — matches Leg.to_dict(). ``from`` is a Python
    keyword, so the field is named ``from_`` with an alias; construct via
    ``ChartLeg(**leg.to_dict())`` (dict key ``"from"`` resolves via the alias)."""
    model_config = {"populate_by_name": True}

    from_: str = Field(alias="from")
    to: str
    type: str
    humanGate: bool = False


class ChartResponse(BaseModel):
    """A compiled voyage or order chart — matches Chart.to_dict()."""
    chartId: str
    voyage: str = ""
    nodes: dict[str, ChartWaypoint] = Field(default_factory=dict)
    edges: list[ChartLeg] = Field(default_factory=list)


# ---- Usage aggregation (FTR-MSO-2026-0333) ----------------------------------

class UsageBucket(BaseModel):
    """A single bucket in a grouped usage rollup.

    Matches the frontend UsageBucket interface in app/types/index.ts.
    """
    key: str                    # project_id / voyage_id / order_id / role code
    label: str = ""             # human-readable label (same as key when not set)
    total_tokens: int = 0
    estimated_cost_usd: float = 0.0
    order_count: int = 0        # number of distinct orders contributing to this bucket


class UsageSeriesPoint(BaseModel):
    """One point in a date-keyed time series.

    Matches the frontend UsageSeriesPoint interface in app/types/index.ts.
    Extends UsagePoint semantics but kept separate so UsagePoint (workspace
    sparkline) stays backward-compatible.
    """
    date: str           # YYYY-MM-DD
    tokens: int = 0
    cost_usd: float = 0.0


class UsageRollup(BaseModel):
    """Top-level response for grouped usage aggregation endpoints.

    Matches the frontend UsageRollup interface in app/types/index.ts.
    """
    from_date: Optional[str] = None     # inclusive date filter applied (YYYY-MM-DD)
    to_date: Optional[str] = None       # inclusive date filter applied (YYYY-MM-DD)
    group_by: str = "project"           # 'project' | 'voyage' | 'order' | 'role'
    total_tokens: int = 0
    estimated_cost_usd: float = 0.0
    buckets: list[UsageBucket] = Field(default_factory=list)
    series: list[UsageSeriesPoint] = Field(default_factory=list)  # per-day totals


class ModelUsage(BaseModel):
    """Per-model token breakdown for an order.

    Matches the frontend ModelUsage interface in app/types/index.ts.
    """
    input_tokens: int = 0
    output_tokens: int = 0
    cache_creation_input_tokens: int = 0
    cache_read_input_tokens: int = 0
    message_count: int = 0


class IterationUsage(BaseModel):
    """Usage record for one crew iteration (from per-iteration *.jsonl files).

    Matches the frontend IterationUsage interface in app/types/index.ts.
    """
    iteration: int = 0
    role: str = ""
    crew_number: int = 0
    total_tokens: int = 0
    estimated_cost_usd: float = 0.0
    timestamp: str = ""
    models: dict[str, ModelUsage] = Field(default_factory=dict)


class OrderUsageDetail(BaseModel):
    """Full usage breakdown for a single order (JSON + JSONL combined).

    Matches the frontend OrderUsageDetail interface in app/types/index.ts.
    """
    order_id: str
    voyage_id: Optional[str] = None
    total_tokens: int = 0
    estimated_cost_usd: float = 0.0
    models: dict[str, ModelUsage] = Field(default_factory=dict)
    role_buckets: list[UsageBucket] = Field(default_factory=list)   # from JSONL (empty if absent)
    iterations: list[IterationUsage] = Field(default_factory=list)  # from JSONL (empty if absent)
    timestamp: Optional[str] = None
