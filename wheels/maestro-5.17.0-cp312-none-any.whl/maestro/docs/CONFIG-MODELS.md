# Configuring per-role models

Maestro assigns a Claude model to each role based on what the role does:

| Role | Default model | Default effort | Why |
|------|---------------|----------------|-----|
| **PLN** — Planner (NAV) | `claude-opus-5` | `medium` | Planning & architecture — high-leverage, low-volume; a better plan prevents downstream rework |
| **BLD** — Builder (SHP) | `claude-sonnet-5` | `high` | Implementation — highest-volume role; Sonnet is strong here. Promote individual hard orders via the per-order `model` override |
| **TST** — Tester (BOS) | `claude-sonnet-5` | `high` | QA, testing |
| **DOC** — Docs writer (SCR) | `claude-sonnet-5` | `high` | Documentation |
| **SEC** — Security (LKT) | `claude-haiku-4-5` | `high` | Fast investigation, scanning — independent adversarial reviewer |
| **REL** — Releaser (COX) | `claude-opus-5` | `medium` | Integration review + release — last role in the chain; best judgement matters most |
| **LEAD** | `claude-opus-5` | `medium` | Interactive orchestration & judgement |

In short: **PLN Opus 5, BLD/TST/DOC Sonnet 5, SEC Haiku 4.5, REL Opus 5.** These values are `DEFAULT_ROLE_MODEL_IDS` and `DEFAULT_ROLE_EFFORT` in `maestro/core_constants.py`; `mso config models` prints what your workspace actually resolves.

Selection principle: **high-stakes × low-volume → Opus**. PLN/REL/LEAD run infrequently but their decisions propagate, so they get Opus; the high-volume production roles (BLD/TST/DOC) stay on Sonnet, and SEC on Haiku.

## Available models

Every model below can be selected for any role or any order. No role defaults to Fable.

| Model | ID | Notes |
|-------|----|-------|
| Fable 5.1 | `claude-fable-5-1` | Highest-capability tier. Reserve for individual hard orders — see [Choosing Fable 5.1](#choosing-fable-51-for-an-order-or-a-role) |
| Fable 5 | `claude-fable-5` | |
| Opus 5.5 | `claude-opus-5-5` | Successor to Opus 5 in the Opus tier at a lower list price ($4/$20 per MTok, cache reads $0.20). Selectable for any role or order; no role defaults to it. |
| Opus 5 | `claude-opus-5` | Default for PLN / REL / LEAD |
| Sonnet 5.5 | `claude-sonnet-5-5` | Successor to Sonnet 5 in the Sonnet tier at the **same list price** ($2/$10 per MTok, cache reads $0.20) and faster. Effort levels are **recalibrated** — re-sweep rather than carrying your Sonnet 5 effort setting over. Selectable for any role or order; no role defaults to it. |
| Sonnet 5 | `claude-sonnet-5` | Default for BLD / TST / DOC |
| Haiku 4.5 | `claude-haiku-4-5` | Default for SEC. The dated snapshot id `claude-haiku-4-5-20251001` is still accepted where it is already pinned. |
| Opus 4.8 / 4.7 / 4.6 | `claude-opus-4-8`, `claude-opus-4-7`, `claude-opus-4-6` | Previous generation, still supported (historical pricing and transcripts resolve) |
| Sonnet 4.6 | `claude-sonnet-4-6` | Previous generation, still supported |

This set is `SUPPORTED_MODELS` in `maestro/core/crew.py`. Maestro refuses to dispatch against a model ID it can't price (no `PRICING` entry in `maestro/core/fleet_usage_tracker.py`) — an unknown ID at any override layer raises an error naming the supported set, rather than silently dispatching. Adding a new model means updating both `SUPPORTED_MODELS` and `PRICING` in the framework — file an FTR if you need one Maestro doesn't have.

A model ID may carry the `[1m]` context-window suffix (e.g. `claude-opus-5[1m]`); it is stripped before validation. See [Context window](#context-window) below.

### These IDs are the same on every backend

If your workspace runs its crews against a non-default **model backend** — AWS Bedrock, say — the IDs above do not change. `claude-opus-5` is still what you write in an order's `model` field, in `role-models.json`, in a role overlay and in an env var, and it is still what appears in usage records, `mso status`, the Hub and your plans. The backend-native ID is derived at dispatch time and appears only on the crew's `--model` argument and its `Model:` log line.

That is deliberate: the same order dispatches unedited on a Bedrock workspace and on a direct-API one. A model a backend cannot serve **refuses the launch**, naming the configuration key to map it — it is never silently swapped for a different model. See [MODEL-BACKENDS.md](MODEL-BACKENDS.md).

## How a role's model is resolved

Five layers, evaluated from highest to lowest priority — the first one that sets a model wins:

1. **Per-order** — order JSON `model` field (one-off, for a hard order)
2. **Workspace config** — `.mso/config/role-models.json` (per-project, persistent)
3. **Env var** — `MAESTRO_MODEL_<ROLE>` (per-shell, fastest to test)
4. **Role overlay** — `model` in `.mso/config/roles/<CODE>.md` frontmatter (per-project, travels with the role's other customisations)
5. **Built-in default** — the table at the top of this page

### Why the Opus roles default to `medium` effort

PLN/REL/LEAD default to **`claude-opus-5` at `medium` effort**, not to the top of the effort ladder. Maestro's recommendation, for the Opus roles specifically:

- **Prefer the newer model at the same effort.** Moving an Opus role forward a generation while holding effort constant is cheaper per order, not dearer — the newer model reaches the same answer in fewer tokens.
- **The effort ladder is steep on cost and flat on quality.** Stepping `low` → `medium` → `high` → `xhigh` on an Opus role roughly doubles the cost of an order without reliably improving what it produces.
- **Raising effort cancels the saving.** Opus 5 at `high` costs meaningfully more than Opus 5 at `medium`, and at `xhigh` roughly twice as much, for no dependable quality gain. **The economy win comes from dropping effort, not merely from switching model. Do NOT reflexively raise effort on Opus 5.**

Treat the direction as reliable and the magnitude as approximate — your own orders are the measurement that matters, and `mso usage --by-effort` will show you the cost-by-effort split for your workspace. Every one of these defaults is a default, not a policy: change them per role via `role-models.json`, or per order via the `model` / `effort` fields.

**This guidance covers the Opus roles only.** BLD/TST/DOC default to Sonnet 5 — a generation refresh from Sonnet 4.6, formerly their default, at identical list price, not a cost decision — and SEC stays on Haiku 4.5. Opus has not been shown to beat Sonnet in the high-volume production roles, and SEC is deliberately the independent adversarial reviewer, so assuming a bigger model wins there is speculation rather than measurement.

These defaults are tuned for the typical AU/NZ price-and-quality envelope.

## Inspecting the active configuration

```bash
mso config models
```

Prints a table showing the resolved model for each role and the source that decided it. The per-order layer can't be displayed in a static table (it depends on the order being dispatched), so this command shows the layers below it.

## Layer 1 — Per-order override

Add a `model` field to an order JSON. Highest priority — beats every other layer.

```json
{
  "orderId": "FTR-PSG-2026-0042",
  "type": "FTR",
  "role": "BLD",
  "title": "Refactor the auth flow",
  "model": "claude-opus-5"
}
```

Use this when one specific order needs a different model — e.g. a particularly thorny BLD refactor that benefits from Opus, while the rest of the fleet stays on Sonnet for cost.

## Layer 2 — Workspace config

Create `.mso/config/role-models.json` in your workspace:

```json
{
  "models": {
    "BLD": "claude-opus-5",
    "TST": "claude-opus-5"
  }
}
```

Only the roles you list are overridden — everything else falls through to the lower layers. Survives across shells, runs, and dispatcher restarts. Per-project: each project workspace can have its own.

## Layer 3 — Env var

```powershell
# PowerShell
$env:MAESTRO_MODEL_BLD = "claude-opus-5"
```

```bash
# bash / WSL
export MAESTRO_MODEL_BLD=claude-opus-5
```

Lives only in the shell that set it — useful for one-off testing or CI where you want different routing without touching files. Linux/macOS env vars are case-sensitive (must be uppercase `MAESTRO_MODEL_BLD`); Windows is case-insensitive at the OS level.

## Layer 4 — Role overlay

Set `model` in the role's overlay frontmatter at `.mso/config/roles/<CODE>.md`. Useful when the model choice belongs with the other customisations you've made to that role. See [ROLE-OVERLAYS.md](ROLE-OVERLAYS.md) for the full overlay format.

```markdown
---
{
  "role_code": "REL",
  "role_name": "Releaser",
  "extends": "core",
  "model": "claude-opus-5"
}
---
```

An overlay's `model` sits **below** the workspace config and env var layers, so a `role-models.json` entry or `MAESTRO_MODEL_<ROLE>` for the same role still wins.

## Choosing Fable 5.1 for an order or a role

`claude-fable-5-1` (Fable 5.1) is the highest-capability model Maestro supports. It lists at **$10 / $50 per MTok** (input / output) against Opus 5's $5 / $25 (`PRICING` in `maestro/core/fleet_usage_tracker.py`), and no role defaults to it. It is best reserved for individual hard orders — architecture-level design, a hard concurrency bug — not used as a role-wide default.

**For one order** (recommended) — add the per-order `model` field:

```json
{
  "orderId": "PLN-PSG-2026-0107",
  "type": "PLN",
  "role": "PLN",
  "title": "Design the multi-region replication architecture",
  "model": "claude-fable-5-1"
}
```

**For every order a role runs, via a role overlay** — create `.mso/config/roles/PLN.md`:

```markdown
---
{
  "role_code": "PLN",
  "role_name": "Planner",
  "extends": "core",
  "model": "claude-fable-5-1"
}
---
```

Then check that it took effect:

```bash
mso roles validate            # overlay parses and the model ID is recognised
mso config models             # PLN now resolves to claude-fable-5-1
```

**For every order a role runs, via workspace config** — `.mso/config/role-models.json`, which beats an overlay:

```json
{
  "models": {
    "PLN": {"model": "claude-fable-5-1", "effort": "medium"}
  }
}
```

Fable accepts the same effort values as Opus, including `xhigh`, so the effort guidance below applies to it too.

## Context window & reasoning effort

Maestro supports two additional per-role/per-order dispatch parameters.

### Context window

| Value | Meaning |
|-------|------|
| `standard` (default) | Normal context — no extra cost |
| `1m` | 1M context window — higher input token volume |

The `1m` selector appends as a suffix to `--model` (e.g. `claude-opus-5[1m]`), never as a separate flag. Use `1m` ONLY when many files must be held resident simultaneously.

### Reasoning effort

| Value | When to use |
|-------|------|
| `low` | Trivial/mechanical tasks |
| `medium` | Simple single-file tasks — and the default for the Opus roles (PLN/REL/LEAD) |
| `high` | Normal stories — the default for BLD/TST/DOC/SEC |
| `xhigh` | Opus/Fable only; complex long-horizon/high-risk work |
| `max` | **Interactive LEAD only** — rejected for crew dispatch |
| `ultracode` | **Interactive LEAD only** — rejected for crew dispatch |

### Object-form workspace config

```json
{
  "models": {
    "PLN": {"model": "claude-opus-5", "contextWindow": "1m", "effort": "xhigh"},
    "BLD": {"model": "claude-sonnet-5", "effort": "high"},
    "TST": "claude-sonnet-5"
  }
}
```

Bare-string values remain fully supported.

### Env vars

```bash
export MAESTRO_CONTEXT_PLN=1m
export MAESTRO_EFFORT_PLN=xhigh
```

### Cost guardrails

- Built-in defaults: contextWindow=standard for all roles; effort=`medium` for PLN/REL/LEAD and `high` for BLD/TST/DOC/SEC.
- Crew dispatch rejects effort=max and effort=ultracode (reserved for interactive LEAD).
- `1m` raises input token VOLUME; `xhigh` raises output+thinking tokens.

## Upgrading pins when a new model ships

When Anthropic ships a successor inside a model family, your existing pins keep working — a superseded model is *previous generation*, not retired, and it dispatches normally. Nothing here is on a deprecation clock. But a pin you set deliberately a year ago now names an older model than you would choose today, and finding every one of them by hand means grepping `role-models.json`, every role overlay, and every queued order.

`mso migrate model-pins` does that for you, and it is deliberately conservative:

```bash
mso migrate model-pins --dry-run     # ALWAYS do this first — writes nothing
mso migrate model-pins               # confirms, backs up, then applies
```

It moves a pin **one step forward inside its own family**, by an exact-id map:

| From | To |
|------|----|
| `claude-opus-5` | `claude-opus-5-5` |
| `claude-sonnet-5` | `claude-sonnet-5-5` |

Nothing else. A pin to any other model is reported as `UNCHANGED` and left exactly as it is — whether it names a previous-generation id (`claude-opus-4-8`, `claude-sonnet-4-6`) or a current model in another family (`claude-fable-5`, `claude-haiku-4-5`). The map is literal rather than a "newest in this family" rule, so the command's meaning does not change under you the next time a model launches.

### What it touches, and what it never touches

| Touched | Not touched |
|---------|-------------|
| `.mso/config/role-models.json` (both the bare-string and object forms) | Shipped defaults in the installed package — those move by **release**, never by a command |
| `.mso/config/roles/<CODE>.md` overlay frontmatter `model` | `orders/complete/`, `orders/failed/` — historical records, excluded by path |
| Live order JSON in `queues/**` and `orders/active/` | Any order whose `status` is `COMPLETE` / `FAILED` / `CANCELLED`, wherever it sits |
| — | `usage/**` — the usage ledger is a record of what *did* run |
| — | `MAESTRO_MODEL_<ROLE>` env vars (reported, but a shell variable is not a file) |

### The report is the output

Every pin gets one line, grouped by verdict: `CHANGE` (or `WOULD CHANGE` under `--dry-run`), `UNCHANGED`, `SKIPPED (historical)`, `SKIPPED (held)`, `REFUSED`, `INFO`, then a count line. On a mature workspace most of the report is skip lines — that is the point. You should be able to read off exactly which pins moved, which were declined, and why.

A `REFUSED` line always names the command that resolves it. The commonest cause is a model backend (`providers.model`) whose model map has no entry for the successor: rather than rewrite the pin into one that refuses every dispatch, the command leaves it alone and tells you the key to set.

### Holding a pin you chose deliberately

If a role is on an older model on purpose, say so next to the pin and the command will report it and never change it:

```json
{
  "models": {
    "SEC": {"model": "claude-opus-5", "holdModel": true},
    "BLD": {"model": "claude-opus-5"}
  }
}
```

`SEC` is reported `SKIPPED (held)`; `BLD` upgrades. In a role overlay the same marker is spelled `hold_model` (snake_case, matching `context_window`):

```markdown
---
{
  "role_code": "SEC",
  "role_name": "Security",
  "model": "claude-opus-5",
  "hold_model": true
}
---
```

`holdModel` / `hold_model` is read only by this command — nothing in dispatch consults it, so adding it changes no behaviour. An absent marker simply means "upgradeable". You can also set it with `mso settings set models.SEC.holdModel true`.

### Scope flags

| Flag | Effect |
|------|--------|
| `--dry-run` | Print the full report, write nothing |
| `--only ROLE[,ROLE]` | Limit to these role codes |
| `--exclude ROLE[,ROLE]` | Skip these role codes — **`--exclude` wins** where a role is named in both |
| `--no-orders` | Role pins and overlays only; leave live order pins alone (`--orders` is the default) |
| `--yes` | Skip the interactive confirm — the mandatory backup still runs |

Two things about the role filters that are easy to guess wrong:

- **`--exclude` beats `--only`.** `--only PLN --exclude PLN` changes nothing. The deny-list is the conservative reading: if the allow-list won, a typo in `--exclude` would silently *widen* a command that writes files.
- **They are role-scoped, and a live order is not.** `--only` / `--exclude` narrow role pins, overlays and the env-var report. An order carries its own `model` pin and may run several roles, so there is no role to attribute it to — `--no-orders` is the control for those. `--only PLN` on its own still upgrades every eligible live order pin.

An unknown role code is rejected with the list of canonical codes, rather than quietly matching nothing.

### How the files are rewritten

A role overlay is edited **surgically**: the one `model` token inside the frontmatter is replaced and the rest of the file — body, `sections`, `tools`, even its line endings — comes back byte-identical.

`role-models.json` and live order JSON are **re-serialised at two-space indentation** with a trailing newline. Every key survives, in its original order, including `_comment` and `$schema`; the file's own line-ending convention is preserved. For `role-models.json` that is simply its normal shape — the upgrade writes through the same path as `mso settings set`. For an order JSON you hand-wrote at four-space or compact indentation, expect the whole body to reformat, so review the diff with that in mind rather than reading it as unintended churn.

### Safety, and how to undo it

- **A backup is taken before the first write, and there is no flag to skip it.** The zip path is printed before anything is mutated, and the final line of the run names the exact undo: `mso restore "<path to the zip>"`. There is no `--rollback` for this action — re-inverting the map would not restore a pin the step refused, nor a key another path has touched since, so the backup is the honest recovery.
- **It refuses while the fleet is live** — a running dispatcher or a running crew. There is no `--force`: a mid-voyage model change would mean a voyage's TST crew ran on a different model than its BLD crew, with nothing in the record saying so. Let the fleet drain (`mso pause --wait`), then run it.
- **It is idempotent.** A second run reports `0 changes`.
- **The predecessor stays pinnable.** After an upgrade, `mso settings set models.PLN.model claude-opus-5` still works (with a "previous generation" warning). Going back is always available.

### `mso update` reports, and never rewrites

`mso update` is schema propagation, run casually and often, so it will tell you when pins are superseded and stop there:

```
[mso update] 7 model pins name a superseded model; run `mso migrate model-pins --dry-run` to see them.
```

That line is read-only. `mso migrate model-pins` is the only thing that changes a pin.

## Cost trade-offs

List prices per million tokens, input / output, from `PRICING` in `maestro/core/fleet_usage_tracker.py`. **These are Anthropic's first-party list prices.** On a workspace configured for a different model backend they are not your bill, so Maestro reports cost as `unpriced` rather than computing a figure from the wrong rate card — supply your own rates via `pricingOverrides` to get real numbers. Token counts are accurate on every backend. See [MODEL-BACKENDS.md](MODEL-BACKENDS.md#cost-is-reported-honestly-or-not-at-all).


| Tier | Models | Input | Output |
|------|--------|-------|--------|
| Fable | Fable 5.1, Fable 5 | $10.00 | $50.00 |
| Opus | Opus 5 (and the previous-generation Opus 4.x IDs) | $5.00 | $25.00 |
| Sonnet | Sonnet 5 | $2.00 | $10.00 |
| Sonnet | Sonnet 4.6 (previous generation) | $3.00 | $15.00 |
| Haiku | Haiku 4.5 | $1.00 | $5.00 |

Opus costs about 2.5× Sonnet 5 per token, Fable 2× Opus, and Haiku half of Sonnet 5. The defaults already exploit this asymmetry — Opus is reserved for the high-leverage, low-volume roles (PLN/REL/LEAD) where a mistake is costliest and the role runs infrequently, while the high-volume production roles (BLD/TST/DOC) stay on Sonnet. Most workspaces never need to override; for a one-off hard build, set a per-order `model` rather than moving BLD to Opus globally.

If your operators are seeing budget pressure, the cheapest first move is to drop the Opus roles back to Sonnet for non-critical projects — e.g. `.mso/config/role-models.json` with `{"models": {"PLN": "claude-sonnet-5", "REL": "claude-sonnet-5"}}`. That reclaims the Opus premium while keeping Sonnet's strong planning/coding quality. Run `mso usage --voyage <ID>` after a voyage to see whether the change paid off.
