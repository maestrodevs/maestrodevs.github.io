from __future__ import annotations

import json
import os
from pathlib import Path

from .base import SecretsProvider

_SERVICE_DEFAULT = "admiralty"
_INDEX_ENV = "MAESTRO_KEYRING_INDEX"


class OsKeyringSecretsProvider(SecretsProvider):
    """
    Wraps the `keyring` library (macOS Keychain, Windows Credential Manager,
    freedesktop libsecret on Linux).

    config options:
      service  — keyring service name (default: "admiralty")
      username — keyring username / namespace (default: current OS user)
      index_path — path to a JSON file tracking stored keys (default: .mso/secrets/keyring-index.json)
                   because keyring has no portable list() API.
    """

    def __init__(self, config: dict | None = None, workspace: Path | None = None) -> None:
        try:
            import keyring as _kr
            self._kr = _kr
        except ImportError as exc:
            raise RuntimeError(
                "The 'keyring' package is required for os_keyring provider. "
                "Install it with: pip install keyring"
            ) from exc

        cfg = config or {}
        self._service = cfg.get("service", _SERVICE_DEFAULT)
        self._username = cfg.get("username", os.getlogin())

        if "index_path" in cfg:
            self._index_path = Path(cfg["index_path"])
        elif workspace is not None:
            from maestro.workspace import resolve_artefact_dir
            self._index_path = resolve_artefact_dir(workspace) / "secrets" / "keyring-index.json"
        else:
            self._index_path = Path(
                os.environ.get(_INDEX_ENV, ".mso/secrets/keyring-index.json")
            )

    # ------------------------------------------------------------------
    # Index helpers — track keys because keyring has no portable list()
    # ------------------------------------------------------------------

    def _load_index(self) -> list[str]:
        if not self._index_path.exists():
            return []
        try:
            return json.loads(self._index_path.read_text(encoding="utf-8"))
        except Exception:
            return []

    def _save_index(self, keys: list[str]) -> None:
        self._index_path.parent.mkdir(parents=True, exist_ok=True)
        self._index_path.write_text(
            json.dumps(sorted(set(keys)), indent=2),
            encoding="utf-8",
        )

    # ------------------------------------------------------------------
    # SecretsProvider interface
    # ------------------------------------------------------------------

    def get(self, key: str) -> str | None:
        return self._kr.get_password(self._service, f"{self._username}:{key}")

    def set(self, key: str, value: str) -> None:
        self._kr.set_password(self._service, f"{self._username}:{key}", value)
        keys = self._load_index()
        if key not in keys:
            keys.append(key)
            self._save_index(keys)

    def delete(self, key: str) -> None:
        try:
            self._kr.delete_password(self._service, f"{self._username}:{key}")
        except Exception:
            pass
        keys = self._load_index()
        if key in keys:
            keys.remove(key)
            self._save_index(keys)

    def list(self) -> list[str]:
        return list(self._load_index())
