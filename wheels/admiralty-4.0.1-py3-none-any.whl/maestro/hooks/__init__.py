# maestro.hooks — Claude Code hooks

from pathlib import Path


def find_admiralty_root(start_dir: str) -> "Path | None":
    """Walk up from start_dir to find a Maestro workspace root.

    Checks ``.mso/config/`` (v4.0), ``.adm/config/`` (v3.x), then
    ``.admiralty/config/`` (v1.x). Returns the workspace root, or None.
    """
    path = Path(start_dir).resolve()
    for p in [path, *path.parents]:
        for name in (".mso", ".adm", ".admiralty"):
            if (p / name / "config").is_dir():
                return p
    return None
