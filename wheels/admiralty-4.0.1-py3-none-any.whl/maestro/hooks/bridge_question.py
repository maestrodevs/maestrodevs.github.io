#!/usr/bin/env python3
"""
Fleet Bridge Question Hook v1.0 — Relay AskUserQuestion to Slack.

Triggers on PreToolUse with matcher 'AskUserQuestion'. Reads the question
text from stdin JSON (tool_input field), then calls BridgeNotifier.send_question()
to relay it to the Captain via Slack.

Captain-session only: no MAESTRO_CREW check — this fires for QM sessions.

Fail-open: exit 0 on any error — never block the AskUserQuestion call.
"""

import json
import os
import sys
from pathlib import Path


def main():
    try:
        raw_input = sys.stdin.read()
        hook_input = json.loads(raw_input) if raw_input.strip() else {}
    except Exception:
        sys.exit(0)

    try:
        tool_input = hook_input.get("tool_input", {})
        question_text = tool_input.get("question", "")
        if not question_text:
            sys.exit(0)

        # Resolve admiralty dir relative to cwd
        cwd = hook_input.get("cwd", os.getcwd())
        from maestro.hooks import find_admiralty_root
        workspace = find_admiralty_root(cwd)
        if workspace is None:
            sys.exit(0)  # Not an Admiralty workspace — no-op
        from maestro.workspace import resolve_artefact_dir
        admiralty_dir = resolve_artefact_dir(workspace)

        from maestro.core.bridge_notifier import BridgeNotifier
        notifier = BridgeNotifier(admiralty_dir)

        if not notifier.enabled:
            sys.exit(0)

        # Use session_id from env or a default
        session_id = os.environ.get("MAESTRO_ORDER") or "captain-session"

        notifier.send_question(question_text, session_id)
    except Exception:
        pass  # Fail-open

    sys.exit(0)


if __name__ == "__main__":
    main()
