"""
maestro init — Scaffold a new Maestro workspace.

Creates the .mso/ directory structure and template config files
so a new project can start using Maestro immediately.

Auto-migrates legacy .adm/ (v3.x) workspaces by rename, and supports
migration from .admiralty/ (v1.x) installations.
"""

from __future__ import annotations

import json
import shutil
from datetime import datetime, timezone
from pathlib import Path


# ---------------------------------------------------------------------------
# Directory structure for .mso/
# ---------------------------------------------------------------------------

DIRS = [
    ".mso/orders/active",
    ".mso/orders/complete",
    ".mso/orders/failed",
    ".mso/voyages/active",
    ".mso/voyages/complete",
    ".mso/prompts/active",
    ".mso/prompts/complete",
    ".mso/crews/crew1",
    ".mso/crews/crew2",
    ".mso/crews/crew3",
    ".mso/crews/crew4",
    ".mso/crews/crew5",
    ".mso/queues/orders",
    ".mso/queues/bugs",
    ".mso/queues/security",
    ".mso/queues/defects",
    ".mso/queues/requests",
    ".mso/queues/breakdown",
    ".mso/queues/high-level",
    ".mso/queues/explicit",
    ".mso/queues/escalations",
    ".mso/queues/review",
    ".mso/handoffs",
    ".mso/plans",
    ".mso/reports/qa",
    ".mso/reports/security",
    ".mso/reports/investigation",
    ".mso/reports/voyage",
    ".mso/requirements",
    ".mso/logs",
    ".mso/temp",
    ".mso/usage/orders",
    ".mso/config/projects",
    ".mso/bridge/questions",
    ".mso/bridge/answers",
    ".mso/identity/users",
    ".mso/identity/groups",
]

# Project artefact directories to migrate from .admiralty/ → .mso/
MIGRATE_DIRS = [
    "orders",
    "voyages",
    "plans",
    "prompts",
    "handoffs",
    "reports",
    "requirements",
    "queues",
    "usage",
]

# Individual config files to migrate
MIGRATE_CONFIG_FILES = [
    "config/projects.json",
    "config/workspace.json",
    "config/bridge-settings.json",
    "config/role-paths.json",
]

# Directories/files to never migrate (engine code, not project artefacts)
SKIP_DIRS = {"core", "hooks", "roles", "crews"}
SKIP_FILES = {"CHAIN-OF-COMMAND.md", "CLAUDE.md", "README.md"}


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def scaffold_workspace(project: str, directory: Path, force: bool = False, enterprise: bool = False) -> None:
    """Scaffold a new Maestro workspace for the given project acronym.

    Resolution / idempotency:
      - If ``.mso/`` already exists → skip scaffold, just register globally.
      - If only legacy ``.adm/`` exists (v3.x) → rename to ``.mso/``.
      - If legacy ``.admiralty/`` (v1.x) is found → invite operator to run
        ``mso migrate`` to move artefacts to ``.mso/``.
    When enterprise=True, walks the operator through anchor provider configuration.
    """
    project = project.upper()
    base = directory.resolve()

    mso_dir = base / ".mso"
    legacy_adm = base / ".adm"
    legacy_dir = base / ".admiralty"

    # -----------------------------------------------------------------------
    # Idempotency: already initialised
    # -----------------------------------------------------------------------
    if mso_dir.exists() and not force:
        print(f"[Maestro] .mso/ already exists at {base} — skipping scaffold.")
        _register_global(project, base)
        return

    # v3.x → v4.0: if only .adm/ exists, rename it to .mso/ (the canonical
    # auto-migration documented in maestro/workspace.py:get_workspace_dir).
    if legacy_adm.exists() and not mso_dir.exists() and not force:
        legacy_adm.rename(mso_dir)
        print(f"[Maestro] Migrated legacy .adm/ → .mso/ at {base}")
        _register_global(project, base)
        return

    if mso_dir.exists() and force:
        import shutil
        shutil.rmtree(mso_dir)
        print(f"[Maestro] --force: removed existing .mso/")

    # -----------------------------------------------------------------------
    # Migration: legacy .admiralty/ detected
    # -----------------------------------------------------------------------
    migrated: list[str] = []
    skipped: list[str] = []
    backed_up = False

    if legacy_dir.exists():
        print(f"[Maestro] Legacy .admiralty/ detected — run 'mso migrate' to move artefacts to .mso/ (not auto-migrating)")
        active_crews = [d.name for d in (legacy_dir / "crews").iterdir() if d.is_dir()] if (legacy_dir / "crews").exists() else []
        if active_crews:
            print(f"  [WARNING] Active crews detected: {', '.join(active_crews)}")
            print(f"  [WARNING] Stop crews before migrating.")

    # -----------------------------------------------------------------------
    # Fresh scaffold
    # -----------------------------------------------------------------------
    print(f"[Maestro] Scaffolding workspace for project {project} at {base}")

    for rel in DIRS:
        d = base / rel
        d.mkdir(parents=True, exist_ok=True)
        # Only place .gitkeep in empty leaf dirs that aren't runtime-gitignored
        if not any(d.iterdir()):
            runtime = {".mso/crews", ".mso/logs", ".mso/temp", ".mso/bridge"}
            if not any(rel.startswith(r) for r in runtime):
                (d / ".gitkeep").touch()

    # -- workspace.json ------------------------------------------------------
    ws_config = {
        "$schema": "Maestro — Workspace Config",
        "schemaVersion": "2.5.0",
        "mode": "single-project",
        "project": project,
        "defaultGitHubOrg": None,  # Set to your GitHub org (e.g. "my-org") — required for auto-PR
        "notes": f"Maestro v2.4.0 — {project} workspace",
    }
    _merge_write_json(mso_dir / "config/workspace.json", ws_config)

    # -- projects.json -------------------------------------------------------
    projects_json = mso_dir / "config/projects.json"
    if not projects_json.exists():
        _write_json(projects_json, {
            "$schema": "Maestro — Project Registry",
            "description": "Registry of all projects managed by Maestro.",
            "projects": {
                project: {
                    "name": project,
                    "acronym": project,
                    "directory": project.lower(),
                    "repo": f"your-org/{project.lower()}",
                    "org": "your-org",
                    "defaultBranch": "main",
                    "voyageBranchPattern": "voyage/{VOYAGE-ID}",
                    "cloneProtocol": "ssh",
                    "configFile": f"config/projects/{project}.json",
                }
            },
            "defaultProject": project,
        })

    # -- per-project config stub ---------------------------------------------
    per_project = mso_dir / f"config/projects/{project}.json"
    if not per_project.exists():
        _write_json(per_project, {
            "$schema": f"Maestro — {project} Project Config",
            "project": project,
            "maestroRoot": ".mso",
            "projectRoot": project.lower(),
            "notes": f"Update repo, directory, and role paths for {project}.",
        })

    # -- .mso/config/mcp-servers.json from template --------------------------
    mcp_registry = mso_dir / "config" / "mcp-servers.json"
    if not mcp_registry.exists():
        content = _render_template("mcp-servers.json.j2", {
            "project_acronym": project,
        })
        if content:
            _write_text(mcp_registry, content)
        else:
            _write_json(mcp_registry, {
                "$schema": "../../../maestro/config/mcp-servers.schema.json",
                "schemaVersion": "1.0",
                "description": f"MCP server allowlist — {project} workspace",
                "servers": [],
            })

    # -- secret-allowlist.json from template ---------------------------------
    # Scaffolds an empty allowlist that the pretool secret scanner reads from
    # .mso/config/. Preserves any existing user-curated allowlist.
    secret_allowlist = mso_dir / "config" / "secret-allowlist.json"
    if not secret_allowlist.exists():
        content = _render_template("secret-allowlist.json.j2", {
            "project": project,
        })
        if content:
            _write_text(secret_allowlist, content)

    # -- .mso/config/gates.json from template --------------------------------
    gates_json = mso_dir / "config" / "gates.json"
    if not gates_json.exists():
        content = _render_template("gates.json.j2", {})
        if content:
            _write_text(gates_json, content)
        else:
            _write_json(gates_json, {
                "$schema": "Maestro — Gate Config",
                "schemaVersion": "1.0",
                "post_nav_review": {
                    "enabled": False,
                    "exempt_priorities": ["LOW"],
                    "auto_approve_after_hours": 0,
                },
            })

    # -- .mso/claude.md from template ----------------------------------------
    claude_md = mso_dir / "claude.md"
    if not claude_md.exists():
        content = _render_template("claude-adm.md.j2", {
            "project_acronym": project,
        })
        if content:
            _write_text(claude_md, content)
        else:
            _write_text(claude_md, _default_claude_md(project))

    # -- identity defaults ---------------------------------------------------
    _copy_identity_defaults(mso_dir)

    # -- enterprise bootstrap ------------------------------------------------
    if enterprise:
        _bootstrap_enterprise(mso_dir)

    # -- .gitignore ----------------------------------------------------------
    _update_gitignore(base)

    # -- global registry -----------------------------------------------------
    _register_global(project, base)

    # -----------------------------------------------------------------------
    # Summary
    # -----------------------------------------------------------------------
    print(f"\n[Maestro] Workspace scaffolded successfully.")

    if backed_up:
        print(f"\n  Migration summary:")
        if migrated:
            print(f"    Migrated ({len(migrated)} items):")
            for m in migrated:
                print(f"      + {m}")
        if skipped:
            print(f"    Skipped ({len(skipped)} items):")
            for s in skipped:
                print(f"      - {s}")
        print(f"    Legacy dir backed up: .admiralty.bak/")

    print(f"\n  Next steps:")
    print(f"  1. Update .mso/config/projects/{project}.json with your repo details")
    print(f"  2. Install Maestro pip package if not already done:")
    print(f"       pip install maestro --extra-index-url https://maestrodevs.github.io/simple/")
    print(f"  3. Run: mso dispatch --max-crews 3\n")


# ---------------------------------------------------------------------------
# Enterprise bootstrap
# ---------------------------------------------------------------------------

_ANCHOR_PROVIDERS = {
    "1": ("fs",    "Filesystem (dev/CI — not tamper-proof in production)"),
    "2": ("s3",    "AWS S3 with Object Lock"),
    "3": ("azure", "Azure Blob Storage with Immutability Policy"),
    "4": ("s3-compat", "S3-compatible (MinIO, Wasabi, Cloudflare R2)"),
}


def _bootstrap_enterprise(mso_dir: Path) -> None:
    """Interactive wizard to configure enterprise mode anchor provider in workspace.json."""
    print("\n[Maestro] Enterprise mode setup")
    print("=" * 50)
    print("Enterprise mode requires an external anchor provider for audit log immutability.")
    print("Available providers:")
    for key, (name, desc) in _ANCHOR_PROVIDERS.items():
        print(f"  {key}. {desc}  [{name}]")

    choice = ""
    while choice not in _ANCHOR_PROVIDERS:
        try:
            choice = input("\nSelect anchor provider [1-4] (default: 1 — filesystem): ").strip() or "1"
        except (EOFError, KeyboardInterrupt):
            choice = "1"
            print("1")

    provider_name, provider_desc = _ANCHOR_PROVIDERS[choice]
    print(f"\n[Maestro] Configuring anchor provider: {provider_desc}")

    config_path: str | None = None
    if provider_name != "fs":
        try:
            config_path = input(
                f"Path to {provider_name} anchor config JSON (leave blank to configure manually later): "
            ).strip() or None
        except (EOFError, KeyboardInterrupt):
            config_path = None
            print()

    max_age_raw = ""
    try:
        max_age_raw = input("Anchor SLA — max minutes between anchors [default: 60]: ").strip()
    except (EOFError, KeyboardInterrupt):
        print()
    try:
        max_age = int(max_age_raw) if max_age_raw else 60
    except ValueError:
        max_age = 60

    ws_path = mso_dir / "config" / "workspace.json"
    try:
        ws_data: dict = {}
        if ws_path.exists():
            ws_data = json.loads(ws_path.read_text(encoding="utf-8"))

        ws_data["enterprise"] = True
        audit_cfg: dict = ws_data.get("audit", {})
        audit_cfg["anchorProvider"] = provider_name
        audit_cfg["maxAnchorAgeMinutes"] = max_age
        if config_path:
            audit_cfg["anchorConfig"] = config_path
        ws_data["audit"] = audit_cfg

        ws_path.write_text(json.dumps(ws_data, indent=2) + "\n", encoding="utf-8")
        print(f"\n[Maestro] workspace.json updated:")
        print(f"  enterprise: true")
        print(f"  audit.anchorProvider: {provider_name}")
        print(f"  audit.maxAnchorAgeMinutes: {max_age}")
        if config_path:
            print(f"  audit.anchorConfig: {config_path}")
    except Exception as exc:
        print(f"[Maestro] WARNING: Could not update workspace.json for enterprise mode: {exc}")
        print(f"  Add manually: {{\"enterprise\": true, \"audit\": {{\"anchorProvider\": \"{provider_name}\"}}}}")

    if provider_name == "fs":
        print(
            "\n[Maestro] WARNING: filesystem anchor provider satisfies the mandatory check "
            "for dev/CI but is NOT tamper-proof in production.\n"
            "  Configure an object-lock backend (s3, azure, s3-compat) before going live."
        )

    print(
        f"\n[Maestro] To anchor on a schedule, add to cron or Task Scheduler:\n"
        f"  mso audit anchor --auto\n"
        f"  (See docs/ENTERPRISE-SECURITY.md for setup instructions.)"
    )


# ---------------------------------------------------------------------------
# Migration
# ---------------------------------------------------------------------------

def _migrate(legacy_dir: Path, mso_dir: Path) -> tuple[list[str], list[str]]:
    """Copy project artefacts from .admiralty/ to .mso/, then rename .admiralty/."""
    migrated: list[str] = []
    skipped: list[str] = []

    # Migrate top-level artefact directories
    for dir_name in MIGRATE_DIRS:
        src = legacy_dir / dir_name
        if src.exists():
            dst = mso_dir / dir_name
            _copy_tree(src, dst)
            migrated.append(dir_name + "/")
        else:
            skipped.append(dir_name + "/ (not present)")

    # Migrate individual config files
    for rel_path in MIGRATE_CONFIG_FILES:
        src = legacy_dir / rel_path
        if src.exists():
            dst = mso_dir / rel_path
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
            migrated.append(rel_path)
        else:
            skipped.append(f"{rel_path} (not present)")

    # Migrate config/projects/ directory
    src_projects = legacy_dir / "config" / "projects"
    if src_projects.exists():
        dst_projects = mso_dir / "config" / "projects"
        _copy_tree(src_projects, dst_projects)
        migrated.append("config/projects/")

    # Handle crews/: warn if stale, preserve if active
    crews_src = legacy_dir / "crews"
    if crews_src.exists():
        active_crews = _find_active_crews(crews_src)
        if active_crews:
            print(f"  [WARNING] Active crews detected: {', '.join(active_crews)}")
            print(f"  [WARNING] Crew state preserved in .admiralty/crews/ — stop crews before cleaning up.")
            skipped.append("crews/ (active crews detected — not migrated)")
        else:
            # Stale crew state — skip silently
            skipped.append("crews/ (stale runtime state — not migrated)")

    # Rename .admiralty/ → .admiralty.bak/
    bak_dir = legacy_dir.parent / ".admiralty.bak"
    if bak_dir.exists():
        shutil.rmtree(bak_dir)
    legacy_dir.rename(bak_dir)

    return migrated, skipped


def _copy_tree(src: Path, dst: Path) -> None:
    """Recursively copy src → dst, skipping .gitkeep files."""
    dst.mkdir(parents=True, exist_ok=True)
    for item in src.rglob("*"):
        if item.name == ".gitkeep":
            continue
        rel = item.relative_to(src)
        target = dst / rel
        if item.is_dir():
            target.mkdir(parents=True, exist_ok=True)
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(item, target)


def _find_active_crews(crews_dir: Path) -> list[str]:
    """Return list of crew names that appear to have active lock files."""
    active = []
    for lock_file in crews_dir.glob("*/crew.lock"):
        active.append(lock_file.parent.name)
    return active


# ---------------------------------------------------------------------------
# Global registry
# ---------------------------------------------------------------------------

def _register_global(project: str, base: Path) -> None:
    """Register this project in ~/.admiralty/projects.json."""
    global_dir = Path.home() / ".admiralty"
    global_dir.mkdir(parents=True, exist_ok=True)

    registry_path = global_dir / "projects.json"
    if registry_path.exists():
        try:
            registry = json.loads(registry_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            registry = {}
    else:
        registry = {}

    if "projects" not in registry:
        registry["projects"] = {}

    registry["projects"][project] = {
        "path": str(base),
        "registered": datetime.now(timezone.utc).isoformat(),
    }

    _write_json(registry_path, registry)
    print(f"[Maestro] Registered {project} in ~/.admiralty/projects.json")


# ---------------------------------------------------------------------------
# .gitignore management
# ---------------------------------------------------------------------------

GITIGNORE_BLOCK_START = "# Maestro runtime state (.mso/)"
GITIGNORE_BLOCK_END = "# END Maestro runtime state"

GITIGNORE_ADDITIONS = """\
# Maestro runtime state (.mso/)
.mso/crews/
.mso/logs/
.mso/bridge/
.mso/temp/
.mso/prompts/active/
# END Maestro runtime state
"""


def _update_gitignore(base: Path) -> None:
    """Add or update .mso/ runtime exclusions in .gitignore."""
    gitignore_path = base / ".gitignore"

    if gitignore_path.exists():
        content = gitignore_path.read_text(encoding="utf-8")

        # Already has our block — skip
        if GITIGNORE_BLOCK_START in content:
            return

        # Remove legacy .admiralty/ runtime lines if present
        lines = content.splitlines(keepends=True)
        filtered = [
            l for l in lines
            if not l.strip().startswith(".admiralty/") or "crews" not in l and "logs" not in l and "temp" not in l
        ]
        content = "".join(filtered)
        if not content.endswith("\n"):
            content += "\n"
        content += "\n" + GITIGNORE_ADDITIONS
        gitignore_path.write_text(content, encoding="utf-8")
    else:
        _write_text(gitignore_path, _default_gitignore() + "\n" + GITIGNORE_ADDITIONS)


def _default_gitignore() -> str:
    return """\
# Project directories (separate git repos — not tracked here)
# Add project directory names below:
# my-project/

# Claude Code local settings
.claude/settings.local.json

# Python
__pycache__/
*.pyc

# OS
.DS_Store
Thumbs.db
"""


# ---------------------------------------------------------------------------
# Template rendering
# ---------------------------------------------------------------------------

def _render_template(template_name: str, variables: dict) -> str | None:
    """Render a bundled .j2 template with simple variable substitution."""
    try:
        import importlib.resources as pkg_resources
        try:
            # Python 3.9+
            ref = pkg_resources.files("admiralty") / "templates" / template_name
            content = ref.read_text(encoding="utf-8")
        except AttributeError:
            # Python 3.8 fallback
            import pkgutil
            data = pkgutil.get_data("admiralty", f"templates/{template_name}")
            if data is None:
                return None
            content = data.decode("utf-8")
    except (FileNotFoundError, ModuleNotFoundError, TypeError):
        return None

    for key, value in variables.items():
        content = content.replace("{{ " + key + " }}", value)
        content = content.replace("{{" + key + "}}", value)

    return content


def _default_claude_md(project: str) -> str:
    """Fallback .mso/claude.md content if template is unavailable."""
    return f"""\
# Maestro — {project}

## Chain of Command

```
Captain (Human) → Quartermaster (Claude) → Fleet Admiral (mso dispatch) → Crews
```

This project uses Maestro v4.0+ (pip package). No Maestro core code lives here.
Only project artefacts live under `.mso/`.

## Maestro commands

```bash
mso dispatch --max-crews 5
mso status [--once]
mso voyage create "Voyage title" --project {project}
mso usage --summary
```

## Naming Conventions

- Orders: `{{TYPE}}-{project}-{{YEAR}}-{{SEQ}}`
- Voyages: `VOY-{project}-{{YEAR}}-{{SEQ}}`

Always continue from the highest existing sequence number.

## Full Documentation

```bash
mso docs
```
"""


# ---------------------------------------------------------------------------
# Identity defaults
# ---------------------------------------------------------------------------

_DEFAULT_GROUPS = {
    "captain": {"name": "captain", "members": [], "description": "Commander — all capabilities"},
    "fleet_operator": {"name": "fleet_operator", "members": [], "description": "Fleet Operator — fleet, bridge, backup, and audit read"},
    "contributor": {"name": "contributor", "members": [], "description": "Contributor — create orders, view voyages, read audit"},
    "auditor": {"name": "auditor", "members": [], "description": "Auditor — audit read, export, and anchor"},
}

_DEFAULT_ACL = {
    "entries": [
        {"principal": "group:captain",        "capability": "*",               "scope": "*"},
        {"principal": "group:fleet_operator", "capability": "fleet.dispatch",  "scope": "*"},
        {"principal": "group:fleet_operator", "capability": "bridge.start",    "scope": "*"},
        {"principal": "group:fleet_operator", "capability": "bridge.stop",     "scope": "*"},
        {"principal": "group:fleet_operator", "capability": "bridge.view",     "scope": "*"},
        {"principal": "group:fleet_operator", "capability": "backup.create",   "scope": "*"},
        {"principal": "group:fleet_operator", "capability": "backup.restore",  "scope": "*"},
        {"principal": "group:fleet_operator", "capability": "audit.read",      "scope": "*"},
        {"principal": "group:fleet_operator", "capability": "config.view",     "scope": "*"},
        {"principal": "group:contributor",    "capability": "order.create",    "scope": "*"},
        {"principal": "group:contributor",    "capability": "order.view",      "scope": "*"},
        {"principal": "group:contributor",    "capability": "voyage.view",     "scope": "*"},
        {"principal": "group:contributor",    "capability": "fleet.view",      "scope": "*"},
        {"principal": "group:contributor",    "capability": "audit.read",      "scope": "*"},
        {"principal": "group:auditor",        "capability": "audit.read",      "scope": "*"},
        {"principal": "group:auditor",        "capability": "audit.export",    "scope": "*"},
        {"principal": "group:auditor",        "capability": "audit.anchor",    "scope": "*"},
    ]
}


def _copy_identity_defaults(mso_dir: Path) -> None:
    """Seed .mso/identity/ with bundled default groups and access.json."""
    identity_dir = mso_dir / "identity"
    groups_dir = identity_dir / "groups"
    groups_dir.mkdir(parents=True, exist_ok=True)
    (identity_dir / "users").mkdir(parents=True, exist_ok=True)

    for name, data in _DEFAULT_GROUPS.items():
        dst = groups_dir / f"{name}.json"
        if not dst.exists():
            _write_json(dst, data)

    acl_dst = identity_dir / "access.json"
    if not acl_dst.exists():
        _write_json(acl_dst, _DEFAULT_ACL)


# ---------------------------------------------------------------------------
# File helpers
# ---------------------------------------------------------------------------

def _write_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
        f.write("\n")


def _merge_write_json(path: Path, data: dict) -> None:
    """Write JSON, but don't overwrite an existing file."""
    if path.exists():
        return
    _write_json(path, data)


def _write_text(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
