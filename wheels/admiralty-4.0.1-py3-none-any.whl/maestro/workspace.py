"""maestro.workspace — workspace directory resolution with .mso/ only, auto-migrate from .adm/."""

from __future__ import annotations

import logging
import os
import shutil
from pathlib import Path
from typing import Callable

_log = logging.getLogger(__name__)

_MSO_DIR = ".mso"
_ADM_DIR = ".adm"


def find_workspace_dir(start: Path | None = None) -> Path | None:
    """Walk up from *start* (default: cwd) looking for a ``.mso/`` workspace dir.

    Returns the ``.mso/`` directory or ``None`` if not found.
    Does NOT fall back to ``.adm/``; use ``get_workspace_dir()`` for auto-migration.
    """
    root = Path(start) if start is not None else Path.cwd()
    for path in [root, *root.parents]:
        mso = path / _MSO_DIR
        if (mso / "config").is_dir():
            return mso
    return None


def get_workspace_dir(start: Path | None = None) -> Path:
    """Return the workspace directory, auto-migrating ``.adm/`` → ``.mso/`` on first v4.0 run.

    Resolution order:
    1. ``MAESTRO_DIR`` environment variable (preferred)
    2. Walk up from *start* (default: cwd) looking for ``.mso/config``
    3. Walk up from *start* (default: cwd) looking for ``.mso/config/``

    Migration behaviour (v4.0 first-run):
    - If ``.adm/`` exists and ``.mso/`` does not → rename ``.adm/`` → ``.mso/`` atomically
      (no symlink, no junction). Logs ``WORKSPACE_MIGRATED`` lifecycle event.
    - If both ``.adm/`` and ``.mso/`` exist → raises :class:`RuntimeError` (split-brain).
      Run ``mso migrate-workspace --resolve`` to fix manually.
    - Idempotent: if ``.mso/`` already exists and ``.adm/`` does not → no-op.

    Raises :class:`FileNotFoundError` if no workspace is found after migration.
    """
    env_dir = os.environ.get("MAESTRO_DIR")
    if env_dir:
        return Path(env_dir).resolve()

    root = Path(start) if start is not None else Path.cwd()
    for path in [root, *root.parents]:
        mso = path / _MSO_DIR
        adm = path / _ADM_DIR
        mso_has_config = (mso / "config").is_dir()
        adm_has_config = (adm / "config").is_dir()

        if mso_has_config and adm_has_config:
            raise RuntimeError(
                f"Split-brain workspace at '{path}': both '{_MSO_DIR}/' and '{_ADM_DIR}/' "
                f"exist with a config/ directory. "
                f"Run `mso migrate-workspace --resolve` to reconcile manually."
            )

        if mso_has_config:
            return mso

        if adm_has_config:
            adm.rename(mso)
            _log.info("WORKSPACE_MIGRATED: renamed '%s' -> '%s'", adm, mso)
            return mso

    raise FileNotFoundError(
        "No Maestro workspace found in the current directory or any parent. "
        "Run `mso init --project <PRJ>` to create one."
    )


# Legacy alias kept for callers that imported from here before the rename.
_find_adm_dir = find_workspace_dir


_ADMIRALTY_DIR = ".admiralty"


def resolve_artefact_dir(workspace: Path) -> Path:
    """Return the canonical workspace artefact dir under *workspace*.

    Resolution order: ``.mso/`` (v4.0 canonical) → ``.adm/`` (v3.x) →
    ``.admiralty/`` (v1.x legacy). If none of the three exist, returns the
    ``.mso/`` path (so write-site callers can `.mkdir()` it).

    Use this for READ sites that need to find an existing artefact dir.
    For WRITE sites that create new artefacts, prefer ``workspace / ".mso"``
    directly so v4.0+ projects land at the canonical location.
    """
    mso = workspace / _MSO_DIR
    if mso.is_dir():
        return mso
    adm = workspace / _ADM_DIR
    if adm.is_dir():
        return adm
    legacy = workspace / _ADMIRALTY_DIR
    if legacy.is_dir():
        return legacy
    return mso


# ---------------------------------------------------------------------------
# migrate_workspace — used by `mso migrate-workspace` CLI command
# ---------------------------------------------------------------------------

class _MigrationPlan:
    """Describes what migrate_workspace will do, without doing it."""

    def __init__(self, state: str, root: Path, adm: Path, mso: Path) -> None:
        self.state = state  # "no-op", "rename", "split-brain", "not-found"
        self.root = root
        self.adm = adm
        self.mso = mso

    def describe(self) -> str:
        if self.state == "no-op":
            return (
                f"  State   : already migrated\n"
                f"  {self.mso} exists; {self.adm} is absent.\n"
                f"  Action  : nothing to do."
            )
        if self.state == "rename":
            return (
                f"  State   : needs migration\n"
                f"  Source  : {self.adm}\n"
                f"  Target  : {self.mso}\n"
                f"  Action  : rename {_ADM_DIR}/ -> {_MSO_DIR}/ (atomic OS rename)"
            )
        if self.state == "split-brain":
            return (
                f"  State   : split-brain\n"
                f"  Both {self.adm} and {self.mso} exist.\n"
                f"  Action  : requires --resolve; run `mso migrate-workspace --resolve`"
            )
        return f"  State   : no workspace found under {self.root}"


def _detect_migration_plan(root: Path) -> _MigrationPlan:
    """Walk up from *root* and return a _MigrationPlan describing the workspace state."""
    for path in [root, *root.parents]:
        mso = path / _MSO_DIR
        adm = path / _ADM_DIR
        mso_ok = (mso / "config").is_dir()
        adm_ok = (adm / "config").is_dir()

        if mso_ok and adm_ok:
            return _MigrationPlan("split-brain", path, adm, mso)
        if mso_ok:
            return _MigrationPlan("no-op", path, adm, mso)
        if adm_ok:
            return _MigrationPlan("rename", path, adm, mso)

    return _MigrationPlan("not-found", root, root / _ADM_DIR, root / _MSO_DIR)


def migrate_workspace(
    start: Path | None = None,
    *,
    dry_run: bool = False,
    force: bool = False,
    resolve: bool = False,
    input_fn: Callable[[str], str] = input,
) -> dict:
    """CLI-facing migration helper for `mso migrate-workspace`.

    Args:
        start:    Directory to start scanning from (default: cwd).
        dry_run:  If True, print the plan and return without making changes.
        force:    If True, skip confirmation prompts.
        resolve:  If True, handle split-brain by merging .adm/ into .mso/.
        input_fn: Callable used for interactive prompts (injectable for tests).

    Returns a dict with keys: ``state``, ``action``, ``moved_files`` (list),
    ``skipped_files`` (list), ``errors`` (list).
    """
    root = Path(start) if start is not None else Path.cwd()
    plan = _detect_migration_plan(root)

    result: dict = {
        "state": plan.state,
        "action": "none",
        "moved_files": [],
        "skipped_files": [],
        "errors": [],
    }

    print(plan.describe())

    if plan.state == "no-op":
        return result

    if plan.state == "not-found":
        raise FileNotFoundError(
            "No Maestro workspace found. "
            "Run `mso init --project <PRJ>` to create one."
        )

    if plan.state == "split-brain":
        if not resolve:
            raise RuntimeError(
                "Split-brain workspace detected. "
                "Run `mso migrate-workspace --resolve` to reconcile."
            )
        return _resolve_split_brain(plan, dry_run=dry_run, force=force, input_fn=input_fn, result=result)

    # state == "rename"
    if dry_run:
        result["action"] = "dry-run"
        return result

    if not force:
        answer = input_fn("  Proceed? [y/N] ").strip().lower()
        if answer not in ("y", "yes"):
            print("  Aborted.")
            result["action"] = "aborted"
            return result

    plan.adm.rename(plan.mso)
    _log.info("WORKSPACE_MIGRATED: renamed '%s' -> '%s'", plan.adm, plan.mso)
    print(f"  Done. Workspace is now at {plan.mso}")
    result["action"] = "renamed"
    return result


def _resolve_split_brain(
    plan: _MigrationPlan,
    *,
    dry_run: bool,
    force: bool,
    input_fn: Callable[[str], str],
    result: dict,
) -> dict:
    """Merge .adm/ files into .mso/, skipping files that already exist there."""
    print(
        f"\n  Resolving split-brain: merging {plan.adm} -> {plan.mso}\n"
        f"  Files already in {plan.mso} will not be overwritten."
    )

    adm_files = list(plan.adm.rglob("*"))
    file_count = sum(1 for f in adm_files if f.is_file())

    print(f"  Files to consider: {file_count}")

    if dry_run:
        for src in adm_files:
            if not src.is_file():
                continue
            rel = src.relative_to(plan.adm)
            dst = plan.mso / rel
            if dst.exists():
                result["skipped_files"].append(str(rel))
                print(f"    skip  {rel}  (already in .mso/)")
            else:
                result["moved_files"].append(str(rel))
                print(f"    merge {rel}")
        result["action"] = "dry-run"
        return result

    if not force:
        answer = input_fn("  Proceed with merge? [y/N] ").strip().lower()
        if answer not in ("y", "yes"):
            print("  Aborted.")
            result["action"] = "aborted"
            return result

    for src in sorted(adm_files):
        if not src.is_file():
            continue
        rel = src.relative_to(plan.adm)
        dst = plan.mso / rel
        if dst.exists():
            result["skipped_files"].append(str(rel))
            continue
        dst.parent.mkdir(parents=True, exist_ok=True)
        try:
            shutil.copy2(src, dst)
            result["moved_files"].append(str(rel))
        except OSError as exc:
            result["errors"].append(f"{rel}: {exc}")

    if not result["errors"]:
        # Remove the now-merged .adm/ tree
        shutil.rmtree(plan.adm)
        print(
            f"  Merged {len(result['moved_files'])} file(s), "
            f"skipped {len(result['skipped_files'])}. "
            f"Removed {plan.adm}."
        )
        result["action"] = "resolved"
    else:
        print(
            f"  Merged {len(result['moved_files'])} file(s) with {len(result['errors'])} error(s). "
            f"{plan.adm} was NOT removed."
        )
        result["action"] = "resolved-partial"

    return result
