#!/usr/bin/env python3
"""
PR Review Dispatch — Generates crew orders from PR review comments.

Usage:
    python pr_review_dispatch.py --repo my-service --pr 1
    python pr_review_dispatch.py --repo my-service --pr 1 --org my-org --role SHP --dry-run

Flow:
    1. Fetches PR review comments via gh CLI
    2. Groups comments by file
    3. Generates a SHP order with the review feedback
    4. Places order in dispatch queue

The order targets the same repo/branch as the PR, so the crew
checks out the voyage branch, addresses comments, and pushes.
"""

import argparse
import json
import os
import subprocess
import sys
from datetime import datetime
from pathlib import Path


from maestro.workspace import get_workspace_dir


def run_gh(args: list) -> str:
    """Run a gh CLI command and return stdout."""
    result = subprocess.run(
        ["gh"] + args,
        capture_output=True, text=True, timeout=30
    )
    if result.returncode != 0:
        print(f"  [ERROR] gh {' '.join(args[:3])}...: {result.stderr.strip()}")
        sys.exit(1)
    return result.stdout.strip()


def _full_repo(org: str, repo: str) -> str:
    """Build full repo identifier."""
    return f"{org}/{repo}" if org else repo


def fetch_pr_info(org: str, repo: str, pr_number: int) -> dict:
    """Fetch PR metadata."""
    raw = run_gh([
        "pr", "view", str(pr_number),
        "--repo", _full_repo(org, repo),
        "--json", "title,state,headRefName,baseRefName,number,author"
    ])
    return json.loads(raw)


def fetch_review_comments(org: str, repo: str, pr_number: int) -> list:
    """Fetch all review comments on a PR."""
    fr = _full_repo(org, repo)
    raw = run_gh([
        "api", f"repos/{fr}/pulls/{pr_number}/comments",
        "--jq", "."
    ])
    comments = json.loads(raw) if raw else []
    return comments


def fetch_review_body_comments(org: str, repo: str, pr_number: int) -> list:
    """Fetch top-level review body comments (not inline)."""
    fr = _full_repo(org, repo)
    raw = run_gh([
        "api", f"repos/{fr}/pulls/{pr_number}/reviews",
        "--jq", "."
    ])
    reviews = json.loads(raw) if raw else []
    # Filter to reviews with body text (not just approvals)
    return [r for r in reviews if r.get("body", "").strip()]


def group_comments_by_file(comments: list) -> dict:
    """Group inline comments by file path."""
    by_file = {}
    for c in comments:
        path = c.get("path", "unknown")
        line = c.get("line") or c.get("original_line") or "?"
        body = c.get("body", "").strip()
        author = c.get("user", {}).get("login", "unknown")

        if path not in by_file:
            by_file[path] = []
        by_file[path].append({
            "line": line,
            "body": body,
            "author": author,
        })
    return by_file


def generate_order(org: str, repo: str, pr_number: int, pr_info: dict,
                   comments_by_file: dict, review_comments: list,
                   role: str = "SHP") -> dict:
    """Generate an order JSON from PR review comments."""
    voyage_branch = pr_info.get("headRefName", "")
    pr_title = pr_info.get("title", "")

    # Build description from comments
    desc_parts = [
        f"Address PR review comments on PR #{pr_number}: {pr_title}",
        f"Branch: {voyage_branch}",
        "",
    ]

    # Add top-level review comments
    if review_comments:
        desc_parts.append("## General Review Comments")
        for r in review_comments:
            author = r.get("user", {}).get("login", "reviewer")
            desc_parts.append(f"- **{author}:** {r['body']}")
        desc_parts.append("")

    # Add inline comments grouped by file
    if comments_by_file:
        desc_parts.append("## Inline Comments by File")
        for path, comments in comments_by_file.items():
            desc_parts.append(f"\n### `{path}`")
            for c in comments:
                desc_parts.append(f"- **Line {c['line']}** ({c['author']}): {c['body']}")
        desc_parts.append("")

    description = "\n".join(desc_parts)

    # Build acceptance criteria from comments
    criteria = []
    for path, comments in comments_by_file.items():
        for c in comments:
            criteria.append(f"Address comment on {path}:{c['line']} — {c['body'][:80]}")
    if not criteria:
        criteria = ["All review comments addressed"]
    criteria.append(f"All commits pushed to {voyage_branch}")
    criteria.append("Build succeeds with 0 errors (dotnet build)")
    criteria.append("All tests pass (dotnet test)")

    # Affected files
    files = list(comments_by_file.keys())

    # Generate order ID
    # Strip common org prefixes for a shorter order ID
    short_repo = repo.split("-", 1)[-1] if "-" in repo else repo
    order_id = f"REV-{short_repo.upper()}-{pr_number:03d}"

    return {
        "id": order_id,
        "type": "ORDER",
        "orderType": "REV",
        "title": f"Address PR #{pr_number} review comments: {pr_title}",
        "description": description,
        "priority": "HIGH",
        "status": "PENDING",
        "targetRole": role,
        "targetRepo": repo,
        "voyageId": voyage_branch.replace("voyage/", "") if "voyage/" in voyage_branch else "",
        "requirements": [],
        "dependsOn": [],
        "acceptanceCriteria": criteria,
        "files": files,
        "prNumber": pr_number,
        "prBranch": voyage_branch,
        "createdAt": datetime.now().strftime("%Y-%m-%d"),
        "createdBy": "Quartermaster (pr_review_dispatch.py)"
    }


def main():
    parser = argparse.ArgumentParser(description="Generate crew order from PR review comments")
    parser.add_argument("--repo", required=True, help="Repository name (e.g., my-service)")
    parser.add_argument("--pr", required=True, type=int, help="PR number")
    parser.add_argument("--org", default="", help="GitHub org (e.g., my-org). If empty, uses repo name as-is.")
    parser.add_argument("--role", default="SHP", help="Target role (default: SHP)")
    parser.add_argument("--dry-run", action="store_true", help="Print order without saving")
    args = parser.parse_args()

    print(f"\n  PR Review Dispatch")
    print(f"  Repo: {args.org}/{args.repo} PR #{args.pr}")
    print(f"  Role: {args.role}\n")

    # Fetch PR info
    print("  Fetching PR metadata...")
    pr_info = fetch_pr_info(args.org, args.repo, args.pr)
    print(f"  Title: {pr_info['title']}")
    print(f"  Branch: {pr_info['headRefName']} -> {pr_info['baseRefName']}")
    print(f"  State: {pr_info['state']}")

    if pr_info["state"] == "MERGED":
        print("\n  [WARN] PR is already merged. Comments may no longer be actionable.")

    # Fetch comments
    print("\n  Fetching review comments...")
    inline_comments = fetch_review_comments(args.org, args.repo, args.pr)
    review_comments = fetch_review_body_comments(args.org, args.repo, args.pr)

    comments_by_file = group_comments_by_file(inline_comments)

    total = len(inline_comments) + len(review_comments)
    print(f"  Found: {len(inline_comments)} inline, {len(review_comments)} review-level ({total} total)")

    if total == 0:
        print("\n  No review comments found. Nothing to dispatch.")
        return

    # Generate order
    print("\n  Generating order...")
    order = generate_order(
        args.org, args.repo, args.pr, pr_info,
        comments_by_file, review_comments, args.role
    )
    print(f"  Order ID: {order['id']}")
    print(f"  Criteria: {len(order['acceptanceCriteria'])} items")
    print(f"  Files: {', '.join(order['files']) or '(general)'}")

    if args.dry_run:
        print("\n  [DRY RUN] Order JSON:\n")
        print(json.dumps(order, indent=2))
        return

    # Save to queue and orders/active
    admiralty = get_workspace_dir()

    queue_dir = admiralty / "queues" / "orders"
    queue_dir.mkdir(parents=True, exist_ok=True)
    queue_file = queue_dir / f"{order['id']}.json"
    queue_file.write_text(json.dumps(order, indent=2), encoding='utf-8')
    print(f"\n  Queued: {queue_file}")

    active_dir = admiralty / "orders" / "active"
    active_dir.mkdir(parents=True, exist_ok=True)
    active_file = active_dir / f"{order['id']}.json"
    active_file.write_text(json.dumps(order, indent=2), encoding='utf-8')
    print(f"  Active: {active_file}")

    print(f"\n  Order {order['id']} ready for dispatch.")
    print(f"  Set MAESTRO_SPRINT_BRANCH={order['prBranch']} before dispatching.\n")


if __name__ == "__main__":
    main()
