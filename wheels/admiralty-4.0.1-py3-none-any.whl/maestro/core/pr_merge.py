#!/usr/bin/env python3
"""
PR Merge Utility — Verifies checks and merges a PR.

Usage:
    python pr_merge.py --repo my-service --pr 1
    python pr_merge.py --repo my-service --pr 1 --org my-org --strategy squash
    python pr_merge.py --repo my-service --pr 1 --dry-run

Safety:
    - Verifies all CI checks pass before merging
    - Refuses to merge if checks are failing or pending
    - Defaults to squash merge (clean history)
    - Deletes voyage branch after merge (cleanup)
    - Dry-run mode for verification without action
"""

import argparse
import json
import subprocess
import sys
from pathlib import Path


def run_gh(args: list, check: bool = True) -> str:
    """Run a gh CLI command and return stdout."""
    result = subprocess.run(
        ["gh"] + args,
        capture_output=True, text=True, timeout=30
    )
    if check and result.returncode != 0:
        print(f"  [ERROR] gh {' '.join(args[:3])}...: {result.stderr.strip()}")
        sys.exit(1)
    return result.stdout.strip()


def check_security_gate(voyage_id: str | None, workspace: Path | None) -> tuple[bool, list[dict]]:
    """Read SEC-*.json reports for the voyage and enforce security gate.

    Returns (gate_passes, blocking_findings).
    - HARD BLOCK: any unwaived CRITICAL or HIGH finding.
    - SOFT BLOCK: any unwaived MEDIUM finding without an acknowledged waiver.
    """
    if not workspace:
        return True, []

    adm_root = workspace / ".adm" if (workspace / ".adm").is_dir() else workspace / ".admiralty"
    reports_dir = adm_root / "reports" / "security"
    if not reports_dir.exists():
        return True, []

    # Gather all reports: scoped to voyage if provided, otherwise all
    if voyage_id:
        # Orders under this voyage are tracked in the voyage JSON
        voyage_files = list((adm_root / "voyages").rglob(f"{voyage_id}.json"))
        order_ids: set[str] = set()
        for vf in voyage_files:
            try:
                vdata = json.loads(vf.read_text(encoding="utf-8"))
                for order in vdata.get("orders", []):
                    order_id = order.get("orderId") or order.get("id")
                    if order_id:
                        order_ids.add(order_id)
            except Exception:
                pass
        if order_ids:
            report_files = [
                reports_dir / f"SEC-{oid}.json" for oid in order_ids
                if (reports_dir / f"SEC-{oid}.json").exists()
            ]
        else:
            report_files = list(reports_dir.glob("SEC-*.json"))
    else:
        report_files = list(reports_dir.glob("SEC-*.json"))

    blocking: list[dict] = []
    for rf in report_files:
        try:
            report = json.loads(rf.read_text(encoding="utf-8"))
        except Exception:
            continue
        for finding in report.get("findings", []):
            if finding.get("waived"):
                # MEDIUM waivers are self-acknowledged by LKT;
                # HIGH/CRITICAL waivers require an explicit captainApproved flag.
                sev = finding.get("severity", "")
                if sev in ("HIGH", "CRITICAL"):
                    if not finding.get("captainApproved"):
                        blocking.append(finding)
                # MEDIUM: waived with any waiverReason is sufficient
                continue
            sev = finding.get("severity", "")
            if sev in ("CRITICAL", "HIGH"):
                blocking.append(finding)
            elif sev == "MEDIUM":
                # Require acknowledged waiver
                blocking.append(finding)

    return len(blocking) == 0, blocking


def main():
    parser = argparse.ArgumentParser(description="Verify and merge a PR")
    parser.add_argument("--repo", required=True, help="Repository name")
    parser.add_argument("--pr", required=True, type=int, help="PR number")
    parser.add_argument("--org", default="", help="GitHub org (e.g., my-org). If empty, uses repo name as-is.")
    parser.add_argument("--strategy", default="squash",
                        choices=["squash", "merge", "rebase"],
                        help="Merge strategy (default: squash)")
    parser.add_argument("--no-delete-branch", action="store_true",
                        help="Keep the branch after merge")
    parser.add_argument("--dry-run", action="store_true",
                        help="Check status without merging")
    parser.add_argument("--voyage", default="",
                        help="Voyage ID to scope security gate (e.g. VOY-ADM-2026-0024)")
    parser.add_argument("--workspace", default="",
                        help="Workspace root path (default: current directory)")
    parser.add_argument("--skip-security-gate", action="store_true",
                        help="Bypass security gate (Captain use only, documented in audit log)")
    args = parser.parse_args()

    full_repo = f"{args.org}/{args.repo}" if args.org else args.repo
    workspace = Path(args.workspace) if args.workspace else Path.cwd()

    print(f"\n  PR Merge Utility")
    print(f"  Repo: {full_repo} PR #{args.pr}")
    print(f"  Strategy: {args.strategy}\n")

    # Fetch PR info
    raw = run_gh([
        "pr", "view", str(args.pr), "--repo", full_repo,
        "--json", "title,state,headRefName,baseRefName,mergeable"
    ])
    pr = json.loads(raw)
    print(f"  Title: {pr['title']}")
    print(f"  Branch: {pr['headRefName']} -> {pr['baseRefName']}")
    print(f"  State: {pr['state']}")
    print(f"  Mergeable: {pr.get('mergeable', 'UNKNOWN')}")

    if pr["state"] != "OPEN":
        print(f"\n  [ERROR] PR is {pr['state']} — cannot merge.")
        sys.exit(1)

    # Check CI status
    print("\n  Checking CI status...")
    raw = run_gh([
        "pr", "checks", str(args.pr), "--repo", full_repo,
        "--json", "name,state,conclusion"
    ], check=False)

    if raw:
        checks = json.loads(raw)
    else:
        checks = []

    all_pass = True
    for check in checks:
        name = check.get("name", "?")
        conclusion = check.get("conclusion", "PENDING")
        state = check.get("state", "?")
        icon = "PASS" if conclusion == "SUCCESS" else "FAIL" if conclusion == "FAILURE" else "PEND"
        print(f"    [{icon}] {name}: {conclusion or state}")
        if conclusion != "SUCCESS":
            all_pass = False

    if not checks:
        print("    (no checks configured)")
        all_pass = True

    if not all_pass:
        print("\n  [BLOCKED] Not all checks are passing. Cannot merge.")
        sys.exit(1)

    print("\n  All checks passing.")

    # Security gate
    if args.skip_security_gate:
        print("\n  [WARN] Security gate bypassed (--skip-security-gate). Captain approval required.")
        try:
            from maestro.audit import get_audit_log
            get_audit_log(workspace).append(
                "cox.merge.gate_bypass",
                target=f"{full_repo}#PR{args.pr}",
                result="warn",
                metadata={"repo": full_repo, "pr": args.pr, "voyage": args.voyage or None},
            )
        except Exception:
            pass
    else:
        print("\n  Running security gate...")
        gate_passes, blocking = check_security_gate(
            voyage_id=args.voyage or None,
            workspace=workspace,
        )
        if blocking:
            print(f"\n  [SECURITY GATE BLOCKED] {len(blocking)} unresolved finding(s):")
            for f in blocking:
                waiver = " (waiver present but captain approval required)" if f.get("waived") else ""
                print(f"    [{f.get('severity')}] {f.get('title')} — {f.get('file')}:{f.get('line')}{waiver}")
            print(
                "\n  Resolve all CRITICAL/HIGH findings and acknowledge MEDIUM waivers before merging.\n"
                "  Use --skip-security-gate with Captain approval to override."
            )
            sys.exit(1)
        else:
            print("  Security gate: PASSED")

    if args.dry_run:
        print("  [DRY RUN] Would merge with --" + args.strategy)
        return

    # Merge
    print(f"\n  Merging with --{args.strategy}...")
    merge_args = [
        "pr", "merge", str(args.pr),
        "--repo", full_repo,
        f"--{args.strategy}",
    ]
    if not args.no_delete_branch:
        merge_args.append("--delete-branch")

    run_gh(merge_args)

    # Verify
    raw = run_gh([
        "pr", "view", str(args.pr), "--repo", full_repo,
        "--json", "state,mergedAt"
    ])
    result = json.loads(raw)
    print(f"  State: {result['state']}")
    print(f"  Merged at: {result.get('mergedAt', 'N/A')}")

    if result["state"] == "MERGED":
        print(f"\n  PR #{args.pr} merged successfully.")
        try:
            from maestro.audit import get_audit_log
            get_audit_log(workspace).append(
                "cox.merge",
                target=f"{full_repo}#PR{args.pr}",
                metadata={
                    "repo": full_repo,
                    "pr": args.pr,
                    "strategy": args.strategy,
                    "voyage": args.voyage or None,
                    "skip_security_gate": args.skip_security_gate,
                    "merged_at": result.get("mergedAt"),
                },
            )
        except Exception:
            pass
    else:
        print(f"\n  [ERROR] Merge may have failed. State: {result['state']}")
        sys.exit(1)


if __name__ == "__main__":
    main()
