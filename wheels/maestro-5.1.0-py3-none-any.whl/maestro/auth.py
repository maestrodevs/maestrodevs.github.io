# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""
Maestro — GitHub collaborator licence validation.

Single public entry point: check().
Bypassable via MAESTRO_SKIP_AUTH=1 (CI/CD) or for 'version'/'init' subcommands.
"""

import getpass
import json
import os
import sys
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

from maestro.egress.filter import install_egress_filter, EgressDenied

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

REPO = "tavisbasing/Maestro"
AUTH_FILE = Path.home() / ".maestro" / "auth.json"
API_BASE = "https://api.github.com"
DEFAULT_GRACE_DAYS = 7
TIMEOUT_SECONDS = 5

_SKIP_COMMANDS = {"version", "init", "licence", "license", "docs", "help"}


# ---------------------------------------------------------------------------
# Cache helpers
# ---------------------------------------------------------------------------

def _load_cache() -> dict:
    """Read AUTH_FILE; return {} if missing or corrupt."""
    try:
        with AUTH_FILE.open("r", encoding="utf-8") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return {}


def _save_cache(data: dict) -> None:
    """Write data to AUTH_FILE with mode 0600. Creates ~/.maestro/ if needed."""
    try:
        dir_path = AUTH_FILE.parent
        dir_path.mkdir(mode=0o700, parents=True, exist_ok=True)
        with AUTH_FILE.open("w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        try:
            AUTH_FILE.chmod(0o600)
        except OSError:
            pass  # Limited effect on Windows — silently continue
    except OSError as exc:
        print(f"[Maestro] Warning: could not write auth cache ({exc})", file=sys.stderr)


# ---------------------------------------------------------------------------
# Token prompt
# ---------------------------------------------------------------------------

def _prompt_for_token() -> tuple:
    """Prompt for a GitHub PAT, resolve username via /user, return (token, username)."""
    print("[Maestro] GitHub authorisation required.", file=sys.stderr)
    print(
        "A GitHub Personal Access Token (PAT) with 'repo' scope is needed to verify\n"
        "your licence as an authorised collaborator on tavisbasing/Maestro.\n"
        "Create one at: https://github.com/settings/tokens",
        file=sys.stderr,
    )
    token = getpass.getpass("GitHub Personal Access Token: ")

    # Resolve username via /user endpoint
    req = urllib.request.Request(
        f"{API_BASE}/user",
        headers={
            "Authorization": f"Bearer {token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT_SECONDS) as resp:
            user_data = json.loads(resp.read().decode("utf-8"))
            username = user_data.get("login", "")
    except (urllib.error.URLError, urllib.error.HTTPError, json.JSONDecodeError, OSError) as exc:
        print(f"[Maestro] Failed to verify token: {exc}", file=sys.stderr)
        sys.exit(1)

    if not username:
        print("[Maestro] Could not determine GitHub username from token.", file=sys.stderr)
        sys.exit(1)

    return token, username


# ---------------------------------------------------------------------------
# Collaborator verification
# ---------------------------------------------------------------------------

def _verify_collaborator(token: str, username: str) -> str:
    """
    Call GET /repos/{REPO}/collaborators/{username}.

    Returns one of: 'ok', 'not_collaborator', 'bad_token', 'network_error'.
    """
    url = f"{API_BASE}/repos/{REPO}/collaborators/{username}"
    req = urllib.request.Request(
        url,
        headers={
            "Authorization": f"Bearer {token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT_SECONDS) as resp:
            if resp.status == 204:
                return "ok"
            return "not_collaborator"
    except EgressDenied as exc:
        print(f"[Maestro] {exc}", file=sys.stderr)
        return "network_error"
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            return "not_collaborator"
        if exc.code in (401, 403):
            return "bad_token"
        return "network_error"
    except (urllib.error.URLError, OSError):
        return "network_error"


# ---------------------------------------------------------------------------
# Exit messages
# ---------------------------------------------------------------------------

def _exit_not_collaborator() -> None:
    print(
        "\n[Maestro] Licence validation failed.\n"
        f"You are not listed as an authorised collaborator on {REPO}.\n\n"
        "To obtain access, contact: https://github.com/tavisbasing\n"
        f"For licensing enquiries: https://github.com/{REPO}\n",
        file=sys.stderr,
    )
    sys.exit(1)


def _exit_grace_expired(grace_days: int) -> None:
    print(
        f"\n[Maestro] Offline grace period expired ({grace_days} days).\n"
        "Could not reach GitHub to verify your licence.\n"
        "Please connect to the internet and retry, or contact https://github.com/tavisbasing.\n",
        file=sys.stderr,
    )
    sys.exit(1)


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Tier gate (Maestro Hub and future enterprise features)
# ---------------------------------------------------------------------------

HUB_TIERS = {"team", "enterprise"}


def has_tier(allowed: set) -> bool:
    """True if an activated licence's tier is in `allowed`. Never raises."""
    from maestro.env import skip_auth
    if skip_auth():
        return True
    try:
        from maestro.licence import status
        rec = status()
        return bool(rec and rec.tier in allowed)
    except Exception:
        return False


def require_tier(allowed: set, feature: str = "this feature") -> None:
    """Exit(1) with an upgrade message if the active licence tier is not in `allowed`."""
    if has_tier(allowed):
        return
    print(
        f"\n[Maestro] {feature} requires a Team or Enterprise licence.\n"
        f"Your current tier does not include access to this feature.\n"
        f"Upgrade: https://polar.sh/tech127/portal\n",
        file=sys.stderr,
    )
    sys.exit(1)


def check() -> None:
    """
    Verify the caller is licensed to run Admiralty.

    Resolution order (first match wins):
      1. MAESTRO_SKIP_AUTH=1 in env  → skip
      2. MAESTRO_LICENCE_FAKE_ACTIVATION=1 in env → skip
         (fake-activation flow is itself the auth)
      3. Subcommand is in _SKIP_COMMANDS (version, init, licence, …) → skip
      4. A valid local licence record exists (~/.maestro/licence.json)
         → skip — the licence module is the primary auth from v2.5.0+
      5. Fall through to the legacy GitHub-collaborator path (transitional)

    The legacy GH-collab path is retained for users who installed
    pre-v2.5.0 and haven't migrated to a Polar-issued licence key yet.
    """
    # Env-var bypass (CI/CD)
    from maestro.env import skip_auth as _skip_auth
    if _skip_auth():
        return

    # Fake-activation bypass — the test-only escape is itself the auth.
    if os.environ.get("MAESTRO_LICENCE_FAKE_ACTIVATION") == "1":
        return

    # Subcommand bypass — `adm licence activate` is the ONLY way to
    # bootstrap a licence; blocking it on the legacy gate would be a
    # chicken-and-egg.
    if len(sys.argv) > 1 and sys.argv[1] in _SKIP_COMMANDS:
        return

    # Primary auth (v2.5.0+) — a valid licence record overrides the
    # legacy GH-collab gate entirely. The licence module's own
    # validate() handles expiry / revocation / tamper.
    try:
        from maestro.licence import status as _licence_status
        if _licence_status() is not None:
            return
    except Exception:
        # If the licence module itself fails to import / read, fall
        # through to the legacy path rather than hard-fail.
        pass

    # Install egress filter (no-op in permissive/non-enterprise mode)
    try:
        from pathlib import Path as _Path
        from maestro.workspace import find_workspace_dir as _find_ws
        _mso = _find_ws(_Path.cwd())
        if _mso is not None:
            install_egress_filter(_mso.parent)
    except Exception:
        pass

    cache = _load_cache()
    token = cache.get("token", "")
    username = cache.get("username", "")

    # First run — no token cached
    if not token:
        token, username = _prompt_for_token()
        cache = {"token": token, "username": username, "last_verified": ""}
        _save_cache(cache)

    # Verify collaborator status
    result = _verify_collaborator(token, username)

    if result == "ok":
        cache["last_verified"] = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        cache["token"] = token
        cache["username"] = username
        _save_cache(cache)
        return

    if result == "not_collaborator":
        _exit_not_collaborator()

    if result == "bad_token":
        print("[Maestro] Token rejected (401/403). Please re-enter your PAT.", file=sys.stderr)
        token, username = _prompt_for_token()
        retry = _verify_collaborator(token, username)
        if retry == "ok":
            cache["token"] = token
            cache["username"] = username
            cache["last_verified"] = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
            _save_cache(cache)
            return
        if retry == "not_collaborator":
            _exit_not_collaborator()
        # bad_token again or network_error — fall through to network_error handling
        result = retry

    # network_error — check grace period
    grace_days = DEFAULT_GRACE_DAYS
    try:
        grace_days = int(os.environ.get("MAESTRO_OFFLINE_GRACE_DAYS", DEFAULT_GRACE_DAYS))
    except (ValueError, TypeError):
        pass

    last_verified = cache.get("last_verified", "")
    if last_verified:
        try:
            last_dt = datetime.strptime(last_verified, "%Y-%m-%dT%H:%M:%SZ").replace(
                tzinfo=timezone.utc
            )
            elapsed = (datetime.now(timezone.utc) - last_dt).days
            if elapsed <= grace_days:
                print(
                    f"[Maestro] Warning: could not reach GitHub (offline). "
                    f"Grace period active ({elapsed}/{grace_days} days).",
                    file=sys.stderr,
                )
                return
        except ValueError:
            pass

    _exit_grace_expired(grace_days)
