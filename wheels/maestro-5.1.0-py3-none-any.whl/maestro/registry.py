"""
Maestro global project registry.

Manages ~/.maestro/projects.json so that `mso` commands can resolve
project workspaces by acronym from any directory using @PRJ syntax.

Schema v2 (FTR-MSO-2026-0363 — ADDITIVE; v1 entries keep working untouched)
---------------------------------------------------------------------------

::

    {
      "version": 2,                    // file-level marker (absent on pure-v1 files)
      "projects": {
        "GKT": {
          "schemaVersion": 2,
          "path": "C:/Repos/GKT-Coaching",          // workspace root (see dual-meaning note)
          "productRepo": "C:/Repos/GKT-Coaching",   // explicit product repo (v1: implied == path)
          "artefactRoot": "C:/Repos/GKT-Platform",  // OPTIONAL (Phase 2+); absent = embedded
          "artefactMode": "solo",                   // OPTIONAL: embedded|solo|shared; absent = embedded
          "repos": {                                // Phase 4 placeholder (validated now, consumed later)
            "GKT-Coaching-Platform": {
              "path": "C:/Repos/GKT-Coaching",
              "slug": "tavisbasing/GKT-Coaching-Platform",
              "defaultBranch": "main"
            }
          },
          "registered": "2026-07-15T00:00:00+00:00"
        }
      }
    }

v1 entries are just ``{path, registered}``. Migration is **on read only**:
:func:`list_projects` / :func:`get_project_entry` return every entry
normalised to the v2 shape in memory (``schemaVersion``/``productRepo``/
``repos`` defaulted). Nothing is written back to disk on read — a v1 entry is
upgraded on disk only when it is itself the target of an explicit mutation
(:func:`register_project`), never silently.

Dual-meaning note (documented per FTR-MSO-2026-0363; split lands in Phase 2):
``entry["path"]`` is used today as BOTH the ``.mso`` parent (workspace root)
AND the dispatch-subprocess ``cwd`` by the Hub (hub/server.py dispatch/stop
endpoints, hub/poller.py). In Phase 2 (artefact-repo mode) ``artefactRoot``
takes over as the ``.mso`` home while ``path`` remains the workspace root;
Hub consumers switch to ``artefactRoot`` then. Do NOT change Hub behaviour
from this module in the meantime.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

REGISTRY_FILE = Path.home() / ".maestro" / "projects.json"

# Schema version written on explicit mutations. v1 entries (no schemaVersion,
# just {path, registered}) remain valid indefinitely.
REGISTRY_SCHEMA_VERSION = 2

# Valid artefactMode values. Absence of the field means "embedded".
ARTEFACT_MODES = ("embedded", "solo", "shared")

# repos-map entry shape (Phase 4 placeholder — plan §4.2): key = repo name,
# value = per-repo checkout descriptor.
_REPO_ENTRY_REQUIRED_KEYS = ("path",)
_REPO_ENTRY_OPTIONAL_KEYS = (
    "slug", "defaultBranch", "cloneProtocol", "buildCommand", "testCommand",
)


def _load() -> dict:
    if REGISTRY_FILE.exists():
        try:
            return json.loads(REGISTRY_FILE.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return {}
    return {}


def _save(registry: dict) -> None:
    # File-level version marker rides along on explicit mutations only —
    # _save is never called from a read path.
    registry["version"] = REGISTRY_SCHEMA_VERSION
    REGISTRY_FILE.parent.mkdir(parents=True, exist_ok=True)
    REGISTRY_FILE.write_text(json.dumps(registry, indent=2), encoding="utf-8")


# ---------------------------------------------------------------------------
# v2 validation + migration-on-read
# ---------------------------------------------------------------------------

def validate_artefact_mode(mode: str) -> None:
    """Raise ValueError unless *mode* is a valid artefactMode."""
    if mode not in ARTEFACT_MODES:
        raise ValueError(
            f"Invalid artefactMode {mode!r} — must be one of {', '.join(ARTEFACT_MODES)}."
        )


def validate_repos_map(repos: dict) -> None:
    """Validate a v2 ``repos`` map (Phase 4 placeholder schema).

    Key = repo name; value = ``{path, slug?, defaultBranch?, cloneProtocol?,
    buildCommand?, testCommand?}``. Raises ValueError with a specific message
    on the first violation.
    """
    if not isinstance(repos, dict):
        raise ValueError(f"repos must be a dict of repoName -> entry, got {type(repos).__name__}.")
    allowed = set(_REPO_ENTRY_REQUIRED_KEYS) | set(_REPO_ENTRY_OPTIONAL_KEYS)
    for name, entry in repos.items():
        if not isinstance(name, str) or not name.strip():
            raise ValueError(f"repos key {name!r} must be a non-empty repo name string.")
        if not isinstance(entry, dict):
            raise ValueError(f"repos[{name!r}] must be a dict, got {type(entry).__name__}.")
        for req in _REPO_ENTRY_REQUIRED_KEYS:
            if not isinstance(entry.get(req), str) or not entry[req].strip():
                raise ValueError(f"repos[{name!r}].{req} is required and must be a non-empty string.")
        for key, value in entry.items():
            if key not in allowed:
                raise ValueError(
                    f"repos[{name!r}] has unknown key {key!r} — allowed: {', '.join(sorted(allowed))}."
                )
            if not isinstance(value, str):
                raise ValueError(f"repos[{name!r}].{key} must be a string, got {type(value).__name__}.")


def migrate_entry(entry: dict) -> dict:
    """Return *entry* normalised to the v2 shape (pure — in memory only).

    v1 entries gain ``schemaVersion``, ``productRepo`` (defaults to ``path``:
    in embedded mode the product repo IS the workspace root) and an empty
    ``repos`` map. ``artefactRoot``/``artefactMode`` are NOT invented —
    their absence is meaningful (= embedded). Never written back to disk.
    """
    migrated = dict(entry)
    migrated.setdefault("schemaVersion", REGISTRY_SCHEMA_VERSION)
    if "path" in migrated:
        migrated.setdefault("productRepo", migrated["path"])
    migrated.setdefault("repos", {})
    return migrated


# ---------------------------------------------------------------------------
# Mutations (the single write path — init.py's _register_global was absorbed
# here by FTR-MSO-2026-0363)
# ---------------------------------------------------------------------------

def register_project(
    acronym: str,
    path: Path,
    *,
    product_repo: Path | str | None = None,
    artefact_root: Path | str | None = None,
    artefact_mode: str | None = None,
    repos: dict | None = None,
) -> None:
    """Add or update a project entry in the global registry (v2 shape).

    Only ``acronym`` and ``path`` are required. ``product_repo`` defaults to
    *path* (embedded mode: the workspace root is the product repo). The
    optional v2 fields are validated before anything is written; untouched
    sibling entries are persisted exactly as loaded (a v1 sibling stays v1
    on disk).
    """
    if artefact_mode is not None:
        validate_artefact_mode(artefact_mode)
    if repos is not None:
        validate_repos_map(repos)

    resolved_path = Path(path).resolve()
    entry: dict = {
        "schemaVersion": REGISTRY_SCHEMA_VERSION,
        "path": str(resolved_path),
        "productRepo": str(Path(product_repo).resolve()) if product_repo is not None
                       else str(resolved_path),
        "repos": repos if repos is not None else {},
        "registered": datetime.now(timezone.utc).isoformat(),
    }
    if artefact_root is not None:
        entry["artefactRoot"] = str(Path(artefact_root).resolve())
    if artefact_mode is not None:
        entry["artefactMode"] = artefact_mode

    registry = _load()
    registry.setdefault("projects", {})
    registry["projects"][acronym.upper()] = entry
    _save(registry)


def unregister_project(acronym: str) -> bool:
    """Remove a project from the registry. Returns True if it existed."""
    registry = _load()
    projects = registry.get("projects", {})
    key = acronym.upper()
    if key in projects:
        del projects[key]
        registry["projects"] = projects
        _save(registry)
        return True
    return False


# ---------------------------------------------------------------------------
# Reads (v1 and v2 entries come back identically normalised)
# ---------------------------------------------------------------------------

def get_project_entry(acronym: str) -> dict | None:
    """Return the normalised (v2-shape) entry for *acronym*, or None."""
    entry = _load().get("projects", {}).get(acronym.upper())
    if entry is None:
        return None
    return migrate_entry(entry)


def get_project_path(acronym: str) -> Path | None:
    """Return the registered workspace path for the given acronym, or None."""
    entry = _load().get("projects", {}).get(acronym.upper())
    if entry and "path" in entry:
        p = Path(entry["path"])
        if p.exists():
            return p
    return None


def list_projects() -> dict:
    """Return all registered projects keyed by acronym, each normalised to
    the v2 shape in memory (v1 entries on disk are left untouched)."""
    return {
        acronym: migrate_entry(entry)
        for acronym, entry in _load().get("projects", {}).items()
    }
