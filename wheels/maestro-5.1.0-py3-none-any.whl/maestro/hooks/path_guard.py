"""
Worktree path-confinement guard for crew file mutations (BUG-MSO-2026-0282).

The branch guard (``branch_guard.py``) confines crew *git/gh* mutations to the
order's voyage branch, but it never sees plain ``Edit``/``Write``/``NotebookEdit``
or ``Bash`` file-writes whose target PATH lands in a different working tree. A
crew that resolves an absolute path into the main checkout (or ``cd``'s there)
could mutate files in the wrong tree — observed in FTR-MSO-2026-0281, where a
crew left 722 lines of uncommitted edits in the main repo working tree.

This guard denies file-mutating tool calls whose resolved target lies in the
**danger zone**: under the main repo root but OUTSIDE the crew's own worktree
(i.e. the main checkout or a sibling voyage worktree). Scratch writes to
unrelated locations (``/tmp``, ``$TEMP``, …) are deliberately NOT blocked — only
cross-tree contamination of the same repo is.

Relative targets are resolved against the tool call's effective working
directory (the hook ``cwd``) — NOT assumed to be the worktree — so a crew that
``cd``s into the main checkout and then writes a relative path is still caught.

It only acts in crew context (``MAESTRO_REPO_PATH`` set) and is bypassable via
``MAESTRO_PATH_GUARD_BYPASS=1`` (or ``MAESTRO_BRANCH_GUARD_BYPASS=1``) for LEAD
manual-recovery sessions. Fail-open: any path-resolution uncertainty allows the
operation (worktrees remain the primary isolation layer).
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import List, Optional, Tuple

from maestro.env import path_guard_bypass as _bypass, repo_path as _repo_path
from maestro.workspace import MSO_DIR_NAME


_FILE_MUTATING_TOOLS = {"Write", "Edit", "MultiEdit", "NotebookEdit"}

# Conservative Bash write-target extraction. Best-effort defence-in-depth on top
# of the structured-tool guard; the worktree remains the primary isolation layer.
# A single quoted/unquoted shell token.
_TOKEN = re.compile(r""""[^"]+"|'[^']+'|[^\s;&|<>]+""")
# Output redirections: optional fd number or `&`, `>`/`>>`, optional `|` (clobber),
# optional whitespace, then the target. Matches `>f`, `> f`, `2>f`, `&>f`, `>|f`,
# `2>>f`. Negative lookbehind skips arrow-like tokens (`->`, `=>`, `<>`).
_REDIRECT = re.compile(r"""(?<![-=<])(?:\d+|&)?>>?\|?\s*("[^"]+"|'[^']+'|[^\s;&|<>]+)""")
# `tee [flags] f1 f2 ...` — capture the whole arg run; files split out below.
_TEE = re.compile(r"""\btee\b((?:\s+(?:"[^"]+"|'[^']+'|[^\s;&|<>]+))+)""")
# `dd of=PATH` (and any `of=` form).
_OF = re.compile(r"""\bof=("[^"]+"|'[^']+'|[^\s;&|<>]+)""")


def _resolve_worktree() -> Optional[Path]:
    rp = _repo_path().strip()
    if not rp:
        return None
    try:
        return Path(rp).resolve()
    except Exception:
        return None


def _main_repo_root(worktree: Path) -> Optional[Path]:
    """Derive the main repo root from a Maestro worktree path.

    Dispatcher worktrees live at ``<root>/.mso/worktrees/<VOY>/crew<N>``
    (FTR-MSO-2026-0364), or at the legacy
    ``<root>/.mso/voyages/active/<VOY>/.worktree[-crewN]`` (or the legacy
    ``.adm`` prefix), so the segment before ``.mso``/``.adm`` is the main root.
    Returns None if the layout isn't recognised (caller then fails open).
    """
    parts = worktree.parts
    for i, seg in enumerate(parts):
        if (seg in (MSO_DIR_NAME, ".adm") and i + 1 < len(parts)
                and parts[i + 1] in ("voyages", "worktrees")):
            if i > 0:
                return Path(*parts[:i])
    return None


def _within(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False


def _resolve_target(target: str, base: Path) -> Optional[Path]:
    """Resolve a (possibly relative/quoted) target path against *base*.

    Relative paths resolve against *base* (the tool's effective cwd), so a crew
    that ``cd``'d out of its worktree is still evaluated correctly. Returns None
    on any uncertainty (caller fails open)."""
    if not target:
        return None
    t = target.strip().strip('"').strip("'")
    if not t:
        return None
    try:
        p = Path(t)
        if not p.is_absolute():
            p = base / p
        return p.resolve()
    except Exception:
        return None


# Shell separators that end one simple command.
_SEG_SPLIT = re.compile(r"(?:;|&&|\|\||\||&|\n)")
# Leading tokens that wrap/prefix a command without being the command itself.
_CMD_PREFIXES = {"sudo", "env", "command", "nice", "nohup", "time", "then", "do", "exec"}


def _writer_targets(command: str) -> List[str]:
    """Extract destination paths for common non-redirection file writers.

    Audit finding H13: the redirection/tee/of= extractor missed ordinary file
    writers (`cp`, `mv`, `install`, `sed -i`, `ln`), so a crew could write into
    the main checkout with e.g. `cp evil.py /main/repo/src/x.py` undetected.
    This is still best-effort heuristic parsing (the residual is documented;
    OS-level confinement is the real control), but it closes the common cases.
    """
    targets: List[str] = []
    for seg in _SEG_SPLIT.split(command):
        toks = _TOKEN.findall(seg.strip())
        if not toks:
            continue
        # Skip leading env-assignments (FOO=bar) and command wrappers (sudo …).
        i = 0
        while i < len(toks) and (
            (("=" in toks[i]) and not toks[i].startswith("-"))
            or toks[i].strip("\"'") in _CMD_PREFIXES
        ):
            i += 1
        if i >= len(toks):
            continue
        cmd0 = toks[i].strip("\"'").split("/")[-1]
        rest = toks[i + 1:]
        nonflag = [t for t in rest if not t.startswith("-")]
        if cmd0 in ("cp", "mv", "install"):
            # Destination is the last non-flag argument (cp SRC... DST).
            if len(nonflag) >= 2:
                targets.append(nonflag[-1])
        elif cmd0 == "ln":
            # Link name is the last non-flag argument.
            if nonflag:
                targets.append(nonflag[-1])
        elif cmd0 == "sed":
            # In-place edit: -i / -i.bak. First non-flag is the script; the
            # remainder are the files being rewritten.
            if any(t.startswith("-i") for t in rest) and len(nonflag) >= 2:
                targets.extend(nonflag[1:])
        elif cmd0 == "truncate":
            if nonflag:
                targets.append(nonflag[-1])
    return targets


def _bash_write_targets(command: str) -> List[str]:
    if not command:
        return []
    targets: List[str] = []
    for m in _REDIRECT.finditer(command):
        targets.append(m.group(1))
    for m in _TEE.finditer(command):
        for tok in _TOKEN.findall(m.group(1)):
            if tok.startswith("-"):  # skip tee flags (-a, --append, ...)
                continue
            targets.append(tok)
    for m in _OF.finditer(command):
        targets.append(m.group(1))
    targets.extend(_writer_targets(command))
    return targets


def check_path_confinement(
    tool_name: str, tool_input: dict, cwd: Optional[str] = None
) -> Tuple[bool, str]:
    """Return ``(allow, reason)``. ``allow=False`` denies a crew file mutation
    whose target is in the danger zone (another working tree of the same repo).

    *cwd* is the tool call's effective working directory (the hook ``cwd``), used
    to resolve relative targets; falls back to the worktree when unavailable."""
    if _bypass():
        return True, ""
    worktree = _resolve_worktree()
    if worktree is None:
        return True, ""  # not a crew dispatch (no MAESTRO_REPO_PATH)
    main_root = _main_repo_root(worktree)
    if main_root is None:
        return True, ""  # unrecognised layout — fail open

    # Resolve relative targets against the crew's actual cwd, not an assumed
    # worktree — this is what closes the "crew cd's into the main checkout" gap.
    try:
        base = Path(cwd).resolve() if cwd else worktree
    except Exception:
        base = worktree

    targets: List[str] = []
    if tool_name in _FILE_MUTATING_TOOLS:
        fp = (
            tool_input.get("file_path")
            or tool_input.get("filePath")
            or tool_input.get("notebook_path")
            or ""
        )
        if fp:
            targets.append(fp)
    elif tool_name == "Bash":
        targets = _bash_write_targets(tool_input.get("command", ""))

    for t in targets:
        resolved = _resolve_target(t, base)
        if resolved is None:
            continue  # fail-open on resolution uncertainty
        if _within(resolved, main_root) and not _within(resolved, worktree):
            return False, (
                f"Path guard: refusing {tool_name} write to `{t}` — it resolves "
                f"inside the repo at `{main_root}` but OUTSIDE this crew's worktree "
                f"`{worktree}`. Crews must confine file mutations to their own "
                f"MAESTRO_REPO_PATH worktree; writing into the main checkout or a "
                f"sibling voyage worktree causes cross-tree contamination "
                f"(BUG-MSO-2026-0282). Use a path inside the worktree, or set "
                f"MAESTRO_PATH_GUARD_BYPASS=1 in the parent shell for manual recovery."
            )
    return True, ""
