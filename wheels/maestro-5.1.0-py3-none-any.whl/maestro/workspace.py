"""maestro.workspace — workspace directory resolution (.mso/ only)."""

from __future__ import annotations

import logging
import os
from pathlib import Path

_log = logging.getLogger(__name__)

# Canonical artefact directory name. Modules that must spell ".mso" in a path
# join or git pathspec import this instead of hand-writing the literal — the
# FTR-MSO-2026-0361 audit tests forbid hand-built ".mso" strings outside this
# module.
MSO_DIR_NAME = ".mso"
_MSO_DIR = MSO_DIR_NAME  # legacy private alias


def find_workspace_dir(start: Path | None = None) -> Path | None:
    """Walk up from *start* (default: cwd) looking for a ``.mso/`` workspace dir.

    Returns the ``.mso/`` directory or ``None`` if not found.
    """
    root = Path(start) if start is not None else Path.cwd()
    for path in [root, *root.parents]:
        mso = path / _MSO_DIR
        if (mso / "config").is_dir():
            return mso
    return None


def get_workspace_dir(start: Path | None = None) -> Path:
    """Return the workspace directory.

    Resolution order:
    1. ``MAESTRO_DIR`` environment variable (preferred)
    2. Walk up from *start* (default: cwd) looking for ``.mso/config``

    Raises :class:`FileNotFoundError` if no workspace is found.
    """
    env_dir = os.environ.get("MAESTRO_DIR")
    if env_dir:
        return Path(env_dir).resolve()

    root = Path(start) if start is not None else Path.cwd()
    for path in [root, *root.parents]:
        mso = path / _MSO_DIR
        if (mso / "config").is_dir():
            return mso

    raise FileNotFoundError(
        "No Maestro workspace found in the current directory or any parent. "
        "Run `mso init --project <PRJ>` to create one."
    )


# Legacy alias kept for callers that imported from here before the rename.
_find_mso_dir = find_workspace_dir


def resolve_artefact_dir(workspace: Path) -> Path:
    """Return the canonical workspace artefact dir under *workspace*.

    Returns the ``.mso/`` path (creating it via `.mkdir()` at the call site
    if needed).
    """
    mso = workspace / _MSO_DIR
    if mso.is_dir():
        return mso
    return mso


def get_artefact_root(start: Path | None = None) -> Path:
    """Return the artefact root — the ``.mso/`` directory holding all durable
    Maestro artefacts (queues, orders, voyages, plans, handoffs, reports,
    usage, config) and the gitignored runtime plane (crews, logs, state, temp).

    **Today (embedded mode — the only mode):** identical to
    :func:`get_workspace_dir` — ``MAESTRO_DIR`` if set, else the ``.mso/``
    found by walking up from *start*/cwd. Zero behaviour change.

    **Phase 2+ retargeting contract (PLAN-PLN-MSO-2026-0358 §3.6):** when
    ``artefacts.mode`` is ``solo``/``shared``, this resolver — and only this
    resolver — retargets to ``<artefact-repo>/.mso`` while call sites stay
    unchanged. Callers MUST use this for artefact paths (anything under
    ``.mso/``) and :func:`get_product_repo` for product-repo paths; the two
    will stop being related once artefacts leave the product repo.
    """
    return get_workspace_dir(start)


def get_product_repo(target_repo: str | None = None,
                     start: Path | None = None) -> Path:
    """Return the product repository root — the git repo whose source code
    crews build, branch, and converge.

    **Today (embedded mode — the only mode):** the parent of the ``.mso/``
    workspace dir (``.mso`` is embedded in the product repo), so *target_repo*
    is accepted but unused. Zero behaviour change.

    **Phase 4 retargeting contract (PLAN-PLN-MSO-2026-0358 §3.6, §4):**
    *target_repo* resolves through the workspace ``repos`` map to a per-repo
    managed checkout; embedded mode keeps returning the ``.mso`` parent.
    Callers MUST use this (not ``get_workspace_dir().parent``) for any path
    or ``cwd`` that means "the product repo".
    """
    return get_workspace_dir(start).parent
