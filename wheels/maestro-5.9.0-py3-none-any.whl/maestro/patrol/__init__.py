"""maestro/patrol — `mso doctor`'s deterministic core.

PLAN-PLN-MSO-2026-0504 §3 (Dimension A3): the patrol finds problems whether
or not an LLM is awake, and whether or not the dispatcher is running. Every
check in ``maestro.patrol.checks`` reads on-disk state under a given
``artefact_root`` only — none of them touch a live process — so
:func:`run_patrol` works identically with the dispatcher stopped, wedged, or
never started.

Plan order 2 (FTR-MSO-2026-0532) wires in patrol-definition resolution (the
four-tier config in ``maestro.patrol.resolver``, §5): which checks run, and
at what severity, is now governed by the resolved definition rather than
every registered check running unconditionally at its registered severity.
Noise control (fingerprints/delta/age escalation, §6) remains a later order.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from maestro.patrol.registry import (
    CheckContext,
    CheckSkipped,
    Finding,
    all_checks,
    severity_rank,
)
from maestro.patrol.resolver import (
    InvalidDefinition,
    PatrolResolution,
    resolve_patrol_definition,
    write_definition_invalid_event,
)

# Import check modules for their @check registration side effects.
from maestro.patrol.checks import dispatcher as _dispatcher_checks  # noqa: F401
from maestro.patrol.checks import crews as _crews_checks  # noqa: F401
from maestro.patrol.checks import orders as _orders_checks  # noqa: F401
from maestro.patrol.checks import voyages as _voyages_checks  # noqa: F401
from maestro.patrol.checks import hygiene as _hygiene_checks  # noqa: F401
from maestro.patrol.checks import machine as _machine_checks  # noqa: F401

__all__ = [
    "Finding", "CheckContext", "CheckSkipped", "PatrolResult", "SkippedCheck", "run_patrol",
    "InvalidDefinition", "PatrolResolution", "resolve_patrol_definition",
]


@dataclass(frozen=True)
class SkippedCheck:
    check_id: str
    reason: str


@dataclass(frozen=True)
class PatrolResult:
    findings: "list[Finding]"
    skipped: "list[SkippedCheck]"
    checks_run: int
    generated_at: str
    definition: Optional[PatrolResolution] = None

    def exit_code(self, fail_at: str = "high") -> int:
        """Non-zero when any finding's severity is at or above *fail_at*, OR
        when the patrol definition itself failed to resolve.

        FTR-MSO-2026-0531: exit is non-zero when any finding is severity >=
        high, ranked, never a boolean flag on a single severity string.
        PLAN-PLN-MSO-2026-0504 §5.5 point 4 (FTR-MSO-2026-0532): a definition
        failure fails the run even when every check that DID run passed —
        "healthy" must never look identical to "silently ran a shorter list".
        """
        if self.definition is not None and self.definition.invalid is not None:
            return 1
        threshold = severity_rank(fail_at)
        return 1 if any(severity_rank(f.severity) >= threshold for f in self.findings) else 0


def run_patrol(
    artefact_root: Path,
    now: Optional[datetime] = None,
    *,
    workspace: Optional[Path] = None,
    machine_lease_holder: Optional[str] = None,
    machine_lease_path: Optional[Path] = None,
) -> PatrolResult:
    """Run every registered, policy-enabled check against *artefact_root* and
    collect findings.

    Deliberately does not start, contact, or require a dispatcher process —
    every check is a pure read of on-disk state, so this is safe to call with
    the dispatcher stopped, wedged, or never started (the regression this
    function exists to guarantee — see PLAN-PLN-MSO-2026-0504's evidence §4.1
    and FTR-MSO-2026-0531's acceptance criteria).

    *workspace* is the product-repo root (the ``.mso`` parent) — used to
    resolve the pack/bundle tiers of the patrol definition (``resolver.py``)
    AND handed to every check via ``CheckContext.workspace`` (FTR-MSO-2026-0535)
    for provider resolution (§10) and product-repo reads. ``None`` resolves
    workspace.json + the shipped default only, and any check that needs a
    product-repo root degrades to a self-skip rather than guessing.

    A check that raises is recorded as skipped rather than taking the whole
    run down — one broken check must not blind the patrol to every other one.
    :class:`~maestro.patrol.registry.CheckSkipped` is a check's own voluntary
    "I cannot answer this" (e.g. an unavailable provider, §10.3) and is
    recorded with its own message verbatim; any other exception is a genuine
    bug and is wrapped with its type name so it stays distinguishable in
    ``mso doctor``'s skipped-checks list. A check the resolved definition
    disables is never invoked at all. A check's resolved severity (policy
    tier, else its own registered default) replaces the severity on every
    Finding it returns — the check itself still never decides its own
    severity dynamically (registry.py).

    §7 (multi-fleet scope): a ``scope="machine"`` check only actually runs
    when this call acquires (or already holds) the machine-scope lease
    (``maestro.patrol.state.try_acquire_machine_lease``, default holder id
    derived from *artefact_root* so distinct workspaces get distinct
    identities). This is what makes `mso doctor --all-projects` (FTR-0535)
    report a machine-wide finding exactly once across N project sections
    instead of once per project, and what stops three independent per-project
    `mso doctor` invocations on one machine from each claiming the same
    orphan-process count — the loser is recorded as skipped, not silently
    dropped.
    """
    now = now or datetime.now(timezone.utc)
    definition = resolve_patrol_definition(Path(artefact_root), workspace=workspace)
    if definition.invalid is not None:
        write_definition_invalid_event(artefact_root, definition.invalid)

    context = CheckContext(
        artefact_root=Path(artefact_root),
        now=now,
        patrol_params={cid: rc.params for cid, rc in definition.checks.items()},
        workspace=Path(workspace) if workspace is not None else None,
    )
    findings: "list[Finding]" = []
    skipped: "list[SkippedCheck]" = []
    checks_run = 0
    lease_held: Optional[bool] = None
    for spec in all_checks():
        resolved = definition.checks.get(spec.id)
        if resolved is not None and not resolved.enabled:
            continue

        if spec.scope == "machine":
            if lease_held is None:
                from maestro.patrol.state import try_acquire_machine_lease

                holder = machine_lease_holder or str(Path(artefact_root).resolve())
                try:
                    lease_held = try_acquire_machine_lease(holder, lease_path=machine_lease_path)
                except Exception:  # noqa: BLE001 — lease I/O must never block the patrol
                    lease_held = True  # fail OPEN: better one extra report than a silent gap
            if not lease_held:
                skipped.append(
                    SkippedCheck(
                        check_id=spec.id,
                        reason="skipped — machine-scope lease held by another "
                               "workspace this tick (PLAN-PLN-MSO-2026-0504 §7)",
                    )
                )
                continue

        try:
            target_severity = resolved.severity if resolved is not None else spec.severity
            results = [replace(f, severity=target_severity) for f in spec.func(context)]
            findings.extend(results)
            checks_run += 1
        except CheckSkipped as exc:
            skipped.append(SkippedCheck(check_id=spec.id, reason=str(exc)))
        except Exception as exc:  # noqa: BLE001 — a broken check must not crash `mso doctor`
            skipped.append(
                SkippedCheck(
                    check_id=spec.id,
                    reason=f"check raised {type(exc).__name__}: {exc}",
                )
            )
    return PatrolResult(
        findings=findings,
        skipped=skipped,
        checks_run=checks_run,
        generated_at=context.now.isoformat(),
        definition=definition,
    )
