"""maestro/patrol/checks/hygiene.py — worktree and runtime-version hygiene.

PLAN-PLN-MSO-2026-0504 (plan order 5, FTR-MSO-2026-0535):

- `hygiene.stale-worktrees` — §1/§4.7 "Worktree cleanup" is ENGINE, partly
  exists: `maestro.core.worktrees.prune_stale_worktrees()` already removes a
  completed voyage's worktrees, but only at dispatcher startup/reconcile —
  nothing DETECTS the gap with the dispatcher stopped. This check is a
  READ-ONLY mirror of that function's own "voyage archived to
  voyages/complete/ but its worktree still exists" rule. It never calls
  `git worktree remove` itself, or any git command at all — a check never
  remediates (registry.py) — it only reports what the next prune pass (or a
  future LEAD act-and-inform `worktree.prune` action, §3.4/D7) would clear.

- `hygiene.runtime-version` — §4.5/D5: compares the installed `mso` version
  against the newest `vX.Y.Z` git tag reachable in the product repo. D5(b):
  ALWAYS states the fleet's current dispatcher state alongside the gap, so
  the operator knows whether a refresh is even actionable yet. Per the
  BUG-MSO-2026-0503 caveat, this NEVER prints the documented
  `pip install . --no-deps` reinstall command — that refresh currently wipes
  the licence signing keyring and silently downgrades the install to
  community. It only ever reports that a refresh is needed and why it must
  wait for an IDLE fleet, never how to run it. Deliberately an OFFLINE git-tag
  comparison rather than a wheel-index/PyPI query: `mso doctor` must stay
  fast and work with no network reachable (§3, "no LLM, no dispatcher, no
  network required" is the same spirit as the dispatcher-stopped guarantee),
  and a git tag is already the release chain's own source of truth (CLAUDE.md
  "Standard PR ship procedure" step 6: `git tag v<NEW>` triggers publish).
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Optional

from maestro.core.fleet_monitor import get_dispatcher_status
from maestro.core.proc import run_hidden
from maestro.patrol.registry import CheckContext, Finding, check

_VERSION_TAG_RE = re.compile(r"^v(\d+)\.(\d+)\.(\d+)$")


def _version_tuple(v: str) -> "Optional[tuple[int, int, int]]":
    v = v.strip()
    if v.startswith("v"):
        v = v[1:]
    parts = v.split(".")
    if len(parts) < 3:
        return None
    try:
        return (int(parts[0]), int(parts[1]), int(parts[2]))
    except ValueError:
        return None


# ---------------------------------------------------------------------------
# hygiene.stale-worktrees
# ---------------------------------------------------------------------------

@check(id="hygiene.stale-worktrees", severity="low")
def hygiene_stale_worktrees(context: CheckContext) -> "list[Finding]":
    findings: "list[Finding]" = []
    complete_dir = context.artefact_root / "voyages" / "complete"
    if not complete_dir.exists():
        return findings
    completed_voyage_ids = {p.stem for p in complete_dir.glob("*.json")}
    if not completed_voyage_ids:
        return findings

    stale_ids: "set[str]" = set()

    # Legacy home: voyages/active/<VID>/.worktree(-crew*)
    active_dir = context.artefact_root / "voyages" / "active"
    if active_dir.exists():
        for voyage_dir in active_dir.iterdir():
            if not voyage_dir.is_dir() or voyage_dir.name not in completed_voyage_ids:
                continue
            has_admin_worktree = (voyage_dir / ".worktree").exists()
            has_crew_worktree = any(
                c.is_dir() and c.name.startswith(".worktree-crew") for c in voyage_dir.iterdir()
            )
            if has_admin_worktree or has_crew_worktree:
                stale_ids.add(voyage_dir.name)

    # Canonical home: worktrees/<VID>/{admin,crew*,convergence-*}
    wt_root = context.artefact_root / "worktrees"
    if wt_root.exists():
        for voyage_home in wt_root.iterdir():
            if not voyage_home.is_dir() or voyage_home.name not in completed_voyage_ids:
                continue
            if any(c.is_dir() for c in voyage_home.iterdir()):
                stale_ids.add(voyage_home.name)

    for voyage_id in sorted(stale_ids):
        findings.append(
            Finding(
                check_id="hygiene.stale-worktrees",
                subject_id=voyage_id,
                severity="low",
                title=f"{voyage_id}: worktree(s) survived voyage archival",
                detail=(
                    f"{voyage_id} is archived to voyages/complete/ but still has a "
                    "worktree checked out (worktrees/, or the legacy voyages/active/ "
                    "home) — it will be pruned automatically at the next dispatcher "
                    "startup/reconcile pass (maestro.core.worktrees.prune_stale_worktrees)."
                ),
                firstSeenAt=context.now.isoformat(),
                suggestedCommand=None,
                scope="workspace",
                requires=(),
            )
        )
    return findings


# ---------------------------------------------------------------------------
# hygiene.runtime-version
# ---------------------------------------------------------------------------

def _installed_version() -> Optional[str]:
    try:
        from maestro import __version__
        return __version__
    except Exception:
        return None


def _latest_git_tag(repo_root: Path) -> Optional[str]:
    """Best-effort newest ``vX.Y.Z`` tag reachable in *repo_root*'s git
    history. Never raises — no git, no tags, or a repo that isn't a git
    checkout at all simply yields ``None`` and the check declines to guess."""
    try:
        r = run_hidden(
            ["git", "tag", "--list", "v*", "--sort=-v:refname"],
            capture_output=True, text=True, timeout=10, cwd=str(repo_root),
        )
    except Exception:
        return None
    if r.returncode != 0:
        return None
    for line in (r.stdout or "").splitlines():
        line = line.strip()
        if _VERSION_TAG_RE.match(line):
            return line
    return None


@check(id="hygiene.runtime-version", severity="medium")
def hygiene_runtime_version(context: CheckContext) -> "list[Finding]":
    if context.workspace is None:
        return []  # no product-repo root to hand — never guess (§10.3's spirit applied here too)

    installed = _installed_version()
    installed_t = _version_tuple(installed) if installed else None
    if installed_t is None:
        return []

    repo_root = Path(context.workspace)
    if not (repo_root / ".git").exists():
        return []
    latest_tag = _latest_git_tag(repo_root)
    if latest_tag is None:
        return []

    latest_t = _version_tuple(latest_tag)
    if latest_t is None or latest_t <= installed_t:
        return []  # up to date, or ahead (a dev/pre-release install) — nothing to report

    status = get_dispatcher_status(context.artefact_root)
    fleet_state = status.get("state", "UNKNOWN")

    return [
        Finding(
            check_id="hygiene.runtime-version",
            subject_id="runtime:mso",
            severity="medium",
            title=f"Installed mso v{installed} is behind the repo's newest tag {latest_tag}",
            detail=(
                f"The running install (v{installed}) is behind {latest_tag} — fleet is "
                f"currently {fleet_state}. This finding intentionally does NOT suggest a "
                "refresh command: the documented `pip install . --no-deps` refresh "
                "currently wipes the licence signing keyring and silently downgrades the "
                "install to community (BUG-MSO-2026-0503, still open). A refresh must wait "
                "for the fleet to be IDLE and follow CLAUDE.md's Phase 3b/3c procedure by "
                "hand — never while crews are RUNNING, and never via this finding alone."
            ),
            firstSeenAt=context.now.isoformat(),
            suggestedCommand=None,
            scope="workspace",
            requires=(),
        )
    ]
