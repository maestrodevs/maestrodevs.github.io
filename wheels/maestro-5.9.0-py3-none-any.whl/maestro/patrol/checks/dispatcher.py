"""maestro/patrol/checks/dispatcher.py — dispatcher liveness.

PLAN-PLN-MSO-2026-0504 §4.1 / BUG-MSO-2026-0541: a dispatcher whose PID is
alive but whose heartbeat has gone stale is WEDGED, not RUNNING, and must be
reported as a distinct, alarming state rather than folded into "healthy" —
that fold is exactly what let a dead/stuck MSO dispatcher go unnoticed for
three ticks on 2026-08-17. Reuses
``maestro.core.fleet_monitor.get_dispatcher_status`` (the BUG-MSO-2026-0426
one-implementation principle) rather than re-deriving liveness here.
"""

from __future__ import annotations

from maestro.core.fleet_monitor import get_dispatcher_status
from maestro.patrol.registry import CheckContext, Finding, check


@check(id="dispatcher.heartbeat", severity="critical")
def dispatcher_heartbeat(context: CheckContext) -> "list[Finding]":
    status = get_dispatcher_status(context.artefact_root)
    if status["state"] != "WEDGED":
        return []

    age = status.get("heartbeatAgeSeconds")
    age_desc = f"{age:.0f}s" if isinstance(age, (int, float)) else "unknown"
    pid = status.get("pid")

    return [
        Finding(
            check_id="dispatcher.heartbeat",
            subject_id=f"dispatcher:pid={pid}",
            severity="critical",
            title="Dispatcher is wedged — process alive, heartbeat stale",
            detail=(
                f"dispatcher.pid ({pid}) is alive, but fleet-runner-state.json has not "
                f"been rewritten in {age_desc} — the dispatcher looks running but is not "
                "ticking. It cannot make progress on pending work until it is restarted."
            ),
            firstSeenAt=context.now.isoformat(),
            suggestedCommand="mso cleanup",
            scope="workspace",
            requires=(),
        )
    ]
