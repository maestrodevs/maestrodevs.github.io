"""maestro/patrol/checks/voyages.py — voyage-level hygiene.

PLAN-PLN-MSO-2026-0504 §4.6: BUG-MSO-2026-0476 is fixed at source (`mso
review approve` releases pre-filed dependents; it never created them) but the
residual duty survives: a voyage whose only order(s) are a completed,
standalone plan, with nothing else ever filed, still needs a Captain to cut
build orders. `maestro.hub.phase.compute_voyage_phase()` already carries this
exact rule for the Hub's own `needs_attention` phase — this check reuses its
`_is_plan_only` / `classify_status` building blocks (the BUG-MSO-2026-0426
one-implementation principle) rather than re-deriving "is this order
plan-only and complete" a second time.

Five real MSO voyages hit exactly this shape before being manually resolved —
VOY-MSO-2026-0094/0100/0130/0145/0147 — and are used as the regression test
fixtures (now archived to `voyages/complete/`, so they no longer reproduce
live; the fixtures recreate their PLANNED-and-stuck shape from their real
ids/titles/orders).

FTR-MSO-2026-0535 (plan order 5) adds two more voyage-family checks:

- `voyages.pr-ci-state` — goes through the `scm`/`ci` providers (§10) rather
  than shelling `gh` directly, and raises `CheckSkipped` (never returns an
  empty, pass-shaped list) when either provider is unavailable — §10.3's
  "skipped, never a false green" rule, and this order's own AC.
- `voyages.merged-not-archived` — calls
  `maestro.core.fleet_runner.run_housekeeping_sweep(dry_run=True)` verbatim
  (no second implementation of merge/archive detection) and reports every
  voyage its dry run says it WOULD archive. That function resolves its own
  workspace via the process-wide `get_artefact_root()` rather than accepting
  an explicit root, so this check temporarily points the documented
  `MAESTRO_DIR` override (see `maestro/workspace.py:get_workspace_dir`) at
  `context.artefact_root` for the duration of the call — otherwise every
  section of a `mso doctor --all-projects` run would report whichever
  workspace the process happened to start in, not each project's own state.
"""

from __future__ import annotations

import json
import os
from pathlib import Path

from maestro.hub.phase import _is_plan_only, classify_status
from maestro.patrol.registry import CheckContext, CheckSkipped, Finding, check

_ORDER_QUEUE_DIRS = (
    "queues/orders", "queues/bugs", "queues/security", "queues/defects",
    "queues/requests", "queues/breakdown", "queues/high-level",
    "queues/review", "queues/proposed", "queues/escalations",
)


def _load_json_safe(path: Path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def _order_status_and_role_sequence(artefact_root: Path, order_id: str) -> "tuple[str, list]":
    """Best-effort ``(status, roleSequence)`` for *order_id*.

    Archive first (an order's terminal record), then the live queues. This is
    deliberately simpler than `hub.phase`'s full ledger-aware resolution — a
    patrol check reads on-disk artefacts only, with no runtime process
    dependency (works with the dispatcher stopped, per this order's own
    acceptance criteria), so it does not replay the order ledger.
    """
    for sub, default in (("orders/complete", "COMPLETE"), ("orders/failed", "FAILED")):
        data = _load_json_safe(artefact_root / sub / f"{order_id}.json")
        if data:
            return str(data.get("status") or default).upper(), data.get("roleSequence") or []
    for sub in _ORDER_QUEUE_DIRS:
        data = _load_json_safe(artefact_root / sub / f"{order_id}.json")
        if data:
            return str(data.get("status") or "PENDING").upper(), data.get("roleSequence") or []
    return "PENDING", []


def _order_id_of(entry) -> str:
    if isinstance(entry, dict):
        return str(entry.get("orderId") or entry.get("id") or "")
    return str(entry)


@check(id="voyages.planned-no-work", severity="high")
def voyages_planned_no_work(context: CheckContext) -> "list[Finding]":
    findings: "list[Finding]" = []
    voyages_dir = context.artefact_root / "voyages" / "active"
    if not voyages_dir.exists():
        return findings

    for voyage_file in sorted(voyages_dir.glob("*.json")):
        data = _load_json_safe(voyage_file)
        if not data:
            continue

        voyage_id = data.get("id") or data.get("voyageId") or voyage_file.stem
        order_ids = [oid for oid in (_order_id_of(o) for o in (data.get("orders") or [])) if oid]
        if not order_ids:
            continue

        members = [
            (oid, *_order_status_and_role_sequence(context.artefact_root, oid))
            for oid in order_ids
        ]
        all_plan_only = all(_is_plan_only(role_seq) for _, _, role_seq in members)
        all_complete = all(classify_status(status) == "complete" for _, status, _ in members)
        pr_merged = bool(data.get("merged") or data.get("mergedAt") or data.get("mergedPR"))

        if not (all_plan_only and all_complete and not pr_merged):
            continue

        findings.append(
            Finding(
                check_id="voyages.planned-no-work",
                subject_id=voyage_id,
                severity="high",
                title=f"{voyage_id}: plan approved but no build orders were filed",
                detail=(
                    f"All {len(order_ids)} order(s) on this voyage "
                    f"({', '.join(order_ids)}) are standalone plan-only orders and are "
                    "complete, but no PR was ever merged for it — the plan was approved "
                    "and nothing was queued to build it (BUG-MSO-2026-0476)."
                ),
                firstSeenAt=context.now.isoformat(),
                suggestedCommand=None,
                scope="workspace",
                requires=(),
            )
        )

    return findings


# ---------------------------------------------------------------------------
# voyages.pr-ci-state (FTR-MSO-2026-0535)
# ---------------------------------------------------------------------------

# gh's own CI conclusion vocabulary that means "this run did not succeed" —
# matched case-insensitively since the shipped `github_actions` provider
# passes `gh pr checks --json`'s raw `conclusion` field straight through.
_FAILING_CONCLUSIONS = {"failure", "cancelled", "timed_out", "action_required", "startup_failure"}
# Values of the raw `status`/`state` field that mean "still running" — a
# check whose conclusion is unset and whose state is one of these is normal,
# transient "pending" and is not itself a finding.
_IN_PROGRESS_STATES = {"in_progress", "queued", "pending", "requested", "waiting"}


def _pr_ci_state(checks_list: "list[dict]") -> str:
    """Classify a PR's overall CI state from a `ci` provider's
    `checks_for_pr()` output. Returns one of "green", "pending", "failing",
    "unknown" — deliberately never silently returning "green" for an
    inconclusive input (order-5 AC: "degrades to unknown, never a false
    green")."""
    if not checks_list:
        return "unknown"

    conclusions = [str(c.get("conclusion") or "").lower() for c in checks_list]
    if any(c in _FAILING_CONCLUSIONS for c in conclusions):
        return "failing"

    statuses = [str(c.get("status") or "").lower() for c in checks_list]
    if any(not conclusion and status in _IN_PROGRESS_STATES for conclusion, status in zip(conclusions, statuses)):
        return "pending"
    if all(conclusions) and all(c not in _FAILING_CONCLUSIONS for c in conclusions):
        return "green"
    return "unknown"


@check(id="voyages.pr-ci-state", severity="high", requires=("scm", "ci"))
def voyages_pr_ci_state(context: CheckContext) -> "list[Finding]":
    from maestro.providers import resolve_explain

    scm = resolve_explain("scm", workspace=context.workspace)
    ci = resolve_explain("ci", workspace=context.workspace)
    if not scm.available or not ci.available:
        reasons = [r.reason for r in (scm, ci) if not r.available]
        raise CheckSkipped(" ; ".join(reasons))

    findings: "list[Finding]" = []
    voyages_dir = context.artefact_root / "voyages" / "active"
    if not voyages_dir.exists():
        return findings

    for voyage_file in sorted(voyages_dir.glob("*.json")):
        data = _load_json_safe(voyage_file)
        if not data:
            continue
        voyage_id = data.get("id") or data.get("voyageId") or voyage_file.stem
        branch = data.get("branch")
        if not branch:
            continue

        pr = scm.provider.get_pr_for_branch(branch)
        if pr is None or scm.provider.pr_is_merged(pr):
            # No PR yet, or already merged — merge/CI-conclusion state is a
            # different check's concern (§12.3/§12.5 are LEAD-event-driven,
            # not part of this heartbeat-scope check).
            continue

        state = _pr_ci_state(ci.provider.checks_for_pr(pr))
        if state in ("green", "pending"):
            continue

        findings.append(
            Finding(
                check_id="voyages.pr-ci-state",
                subject_id=voyage_id,
                severity="high",
                title=f"{voyage_id}: PR CI is {state}",
                detail=(
                    f"PR #{pr.get('number')} ({pr.get('url', '') or branch}) for "
                    f"{voyage_id}'s branch '{branch}' reports CI state '{state}' via the "
                    f"'{ci.provider_id}' provider."
                ),
                firstSeenAt=context.now.isoformat(),
                suggestedCommand=None,
                scope="workspace",
                requires=("scm", "ci"),
            )
        )

    return findings


# ---------------------------------------------------------------------------
# voyages.merged-not-archived (FTR-MSO-2026-0535)
# ---------------------------------------------------------------------------

@check(id="voyages.merged-not-archived", severity="low")
def voyages_merged_not_archived(context: CheckContext) -> "list[Finding]":
    from maestro.core.fleet_runner import run_housekeeping_sweep

    # See module docstring: run_housekeeping_sweep() resolves its own
    # workspace via the process-wide get_artefact_root() rather than an
    # explicit root parameter. Reusing it verbatim (this order's AC forbids a
    # second implementation) means pointing that resolution at THIS check's
    # artefact_root via the documented MAESTRO_DIR override for the duration
    # of the call, restored immediately after — otherwise every section of a
    # `mso doctor --all-projects` run would report whichever workspace this
    # process happened to start in.
    previous = os.environ.get("MAESTRO_DIR")
    os.environ["MAESTRO_DIR"] = str(context.artefact_root)
    try:
        report = run_housekeeping_sweep(dry_run=True)
    except Exception as exc:  # noqa: BLE001 — a broken sweep must self-skip, not crash the patrol
        raise CheckSkipped(f"skipped — housekeeping sweep unavailable: {exc}") from exc
    finally:
        if previous is None:
            os.environ.pop("MAESTRO_DIR", None)
        else:
            os.environ["MAESTRO_DIR"] = previous

    findings: "list[Finding]" = []
    for entry in report.get("changes", []):
        if entry.get("action") != "archived":
            continue
        voyage_id = entry.get("voyage") or "?"
        findings.append(
            Finding(
                check_id="voyages.merged-not-archived",
                subject_id=voyage_id,
                severity="low",
                title=f"{voyage_id}: merged but not yet archived",
                detail=(
                    f"{entry.get('reason', 'PR merged')} — `mso voyage reconcile` would "
                    "archive it now; nothing has run reconcile since the merge."
                ),
                firstSeenAt=context.now.isoformat(),
                suggestedCommand="mso voyage reconcile",
                scope="workspace",
                requires=(),
            )
        )
    return findings
