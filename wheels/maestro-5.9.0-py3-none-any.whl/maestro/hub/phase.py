# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Derived voyage lifecycle phase (FTR-MSO-2026-0351).

The stored voyage ``status`` field is static ('PLANNED') and the manifest's
embedded order statuses go stale, so the Hub could not tell operators which
voyages actually need them. This module computes a derived ``phase`` from the
authoritative sources instead:

- per-order effective status: runtime order-ledger (replayed) > archived
  order files (orders/complete|failed) > live ledger claim > queue/manifest
  status
- voyage PR merge state: manifest merge metadata (mergedPR/mergedAt, written
  by ``mso voyage reconcile``) or archival to voyages/complete WITH NO PR ever
  linked (auto-finalised, no code deliverable — BUG-MSO-2026-0394)

Phase precedence (checked top-down):
1. ``merged``          — voyage PR merged, OR an operator manually confirmed
                          it complete (``mergeDetectedBy: "manual"``), OR its
                          PR closed without merging but carried no code
                          deliverable (``closedNoCodeDeliverable`` —
                          BUG-MSO-2026-0471), OR voyage archived with no PR
                          ever linked (nothing for a human to review)
2. ``needs_attention`` — >=1 order blocked (STALLED/FAILED/...) and nothing
                          the fleet can advance without a human, OR its PR
                          closed without merging and real work was abandoned
                          (``closedWithoutMerge`` — FTR-MSO-2026-0373 /
                          BUG-MSO-2026-0471)
3. ``final_review``    — all orders terminal-COMPLETE, not yet merged (this
                          also covers an archived voyage whose PR is still
                          open — FTR-MSO-2026-0287 archives a voyage to
                          voyages/complete once all orders finish, which is
                          NOT the same event as the PR merging)
4. ``underway``        — >=1 order progressing / fleet can still advance
5. ``backlog``         — nothing started
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

PHASE_MERGED = "merged"
PHASE_NEEDS_ATTENTION = "needs_attention"
PHASE_FINAL_REVIEW = "final_review"
PHASE_UNDERWAY = "underway"
PHASE_BACKLOG = "backlog"


# ---------------------------------------------------------------------------
# Status bucket classification
# ---------------------------------------------------------------------------

# Raw on-disk vocabulary AND the Hub's normalised contract statuses both appear
# here — effective statuses come from three different planes (ledger, archived
# files, queue files) and are not guaranteed to be pre-normalised.
_COMPLETE_STATUSES = {
    "COMPLETE", "COMPLETED", "COMPLETE_PENDING_STAGING",
    "COMPLETE_WITH_CONDITIONS", "RELEASE_APPROVED",
}
_BLOCKED_STATUSES = {
    "STALLED", "FAILED", "CONVERGENCE_FAILED", "VERIFY_FAILED",
    "AUTO_SERIALIZE", "BLOCKED",
}
_IN_PROGRESS_STATUSES = {
    "RUNNING", "IN_PROGRESS", "CLAIMED", "DISPATCHED", "ACTIVE",
}
_HELD_STATUSES = {
    "NAV_REVIEW_PENDING", "AWAITING_APPROVAL", "ON_HOLD", "HOLD", "HELD",
    "BACKLOG", "SKIPPED", "REJECTED",
    # BUG-MSO-2026-0499: PROPOSED is the standalone-plan-review-gate default a
    # dependent order carries until its dependsOn is satisfied; scan_all_queues
    # only ever dispatches status=="PENDING", so a PROPOSED order is invisible
    # to the dispatcher and cannot be "pending" (dispatchable-soon) work — it
    # needs its own dependsOn released (auto_queue_unblocked_orders /
    # promote_ready_dependents) or a human review approval before it can ever
    # be picked up. Bucketing it as "held" (not the "pending" fallthrough)
    # stops it from being miscounted as fleet-advanceable pending work below.
    "PROPOSED",
}
# HELD was previously missing here — only "HOLD" was recognised, so an order
# whose status literally read "HELD" (the operator/dep-gate hold convention
# documented at docs/TROUBLESHOOTING.md#e09) fell through to "pending"
# instead of "held" (BUG-MSO-2026-0499).
# Everything else (PENDING, REQUEUE, REOPENED, MAX_TURNS, unknown) → pending.


def classify_status(status: Optional[str]) -> str:
    """Map an effective order status onto a rollup bucket name."""
    s = (status or "PENDING").strip().upper()
    if s in _COMPLETE_STATUSES:
        return "complete"
    if s in _BLOCKED_STATUSES:
        return "blocked"
    if s in _IN_PROGRESS_STATUSES:
        return "inProgress"
    if s in _HELD_STATUSES:
        return "held"
    return "pending"


# ---------------------------------------------------------------------------
# Effective per-order status (ledger + archive + queue)
# ---------------------------------------------------------------------------

def _load_json_safe(path: Path) -> Optional[dict]:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def load_ledger_view(mso: Path):
    """Replay the runtime order ledger; None when absent or unreadable."""
    try:
        from maestro.core.order_ledger import load_view
        return load_view(mso)
    except Exception:
        return None


def read_archive_statuses(mso: Path) -> dict[str, str]:
    """Index archived order statuses by id from orders/complete + orders/failed.

    The archive DIRECTORY is only the default — the file's own ``status``
    wins when present, because BUG-MSO-2026-0296 established that files in
    orders/complete can legitimately carry STALLED.
    """
    out: dict[str, str] = {}
    for sub, default in (("complete", "COMPLETE"), ("failed", "FAILED")):
        d = mso / "orders" / sub
        if not d.is_dir():
            continue
        for f in d.glob("*.json"):
            data = _load_json_safe(f) or {}
            oid = data.get("orderId") or data.get("id") or f.stem
            out[str(oid)] = str(data.get("status") or default).strip().upper()
    return out


def effective_order_status(
    order_id: str,
    fallback_status: Optional[str],
    ledger_view,
    archive_statuses: dict[str, str],
) -> str:
    """Resolve one order's effective status (uppercase).

    Precedence: ledger TERMINAL verdict (git-immune truth) > archived order
    file > live ledger claim (a crew is on it right now) > the queue/manifest
    status the caller already has.
    """
    if ledger_view is not None:
        try:
            if ledger_view.is_terminal(order_id):
                return str(ledger_view.terminal.get(order_id) or "COMPLETE").upper()
        except Exception:
            pass
    if order_id in archive_statuses:
        return archive_statuses[order_id]
    if ledger_view is not None:
        try:
            if ledger_view.live_claim(order_id):
                return "RUNNING"
        except Exception:
            pass
    return (fallback_status or "PENDING").strip().upper()


# ---------------------------------------------------------------------------
# Phase computation
# ---------------------------------------------------------------------------

@dataclass
class MemberState:
    """One voyage member order, reduced to what the phase engine needs."""
    order_id: str
    status: str                      # effective status, uppercase
    role: str = ""                   # current/target role (reason strings)
    depends_on: list[str] = field(default_factory=list)
    # BUG-MSO-2026-0476: the order's full roleSequence, used to recognise a
    # standalone plan-approval order (roleSequence == [<planning role>], no
    # BLD/TST/etc. after it) — such an order's completion delivers no code.
    role_sequence: list[str] = field(default_factory=list)


def _is_plan_only(role_sequence: list[str]) -> bool:
    """True when *role_sequence* is exactly one planning role.

    A standalone plan-approval order (BUG-MSO-2026-0205) never gets a next
    role — its roleSequence is popped down to just the planning role. A
    normal order that merely STARTS with a planning role (e.g. PLN, BLD, TST)
    has more than one entry and is not plan-only.
    """
    from maestro.core.gates import is_planning_role
    return len(role_sequence) == 1 and is_planning_role(role_sequence[0])


@dataclass
class VoyagePhase:
    phase: str
    reason: str
    rollup: dict[str, int]


def _blocked_reason(blocked: list[MemberState]) -> str:
    parts = []
    for m in blocked[:2]:
        part = f"{m.order_id} {m.status}"
        if m.role:
            part += f" at {m.role}"
        parts.append(part)
    extra = len(blocked) - len(parts)
    reason = "; ".join(parts)
    if extra > 0:
        reason += f" (+{extra} more)"
    return reason


def compute_voyage_phase(
    members: list[MemberState],
    pr_merged: bool = False,
    voyage_archived: bool = False,
    dep_status: Optional[Callable[[str], str]] = None,
    closed_without_merge: bool = False,
    pr_linked: bool = False,
    closed_no_code_deliverable: bool = False,
    manually_resolved: bool = False,
) -> VoyagePhase:
    """Derive (phase, reason, rollup) for one voyage.

    ``dep_status`` resolves a dependency order id (possibly outside this
    voyage) to its effective status; used to decide whether a PENDING member
    is actually dispatchable. Defaults to looking within *members*.

    ``closed_without_merge`` (FTR-MSO-2026-0373): reconcile detected that the
    voyage's PR was CLOSED without merging (remote branch deleted, changes
    absent from base). Such a voyage needs a human even though its orders may
    all be COMPLETE — surface it as ``needs_attention`` (unless it has actually
    merged/archived, which always wins).

    ``pr_linked`` (BUG-MSO-2026-0394): a PR is recorded for at least one repo
    on the manifest (flat prUrl/prNumber, or a non-empty prUrls map), even
    though no merge metadata has been recorded yet. ``voyage_archived`` alone
    means "sitting in voyages/complete/" — which FTR-MSO-2026-0287 also does
    the moment all of a voyage's orders finish, well before its PR is
    reviewed/merged. So an archived voyage with a PR still linked (open) must
    NOT collapse to ``merged`` — it falls through to the normal precedence
    below, landing on ``final_review``. Only an archived voyage with NO PR
    ever linked (auto-finalised, no code deliverable) keeps the pre-existing
    shortcut straight to ``merged``.

    ``closed_no_code_deliverable`` (BUG-MSO-2026-0471): reconcile determined
    that an archived voyage's PR was CLOSED without merging, but the branch
    carried no real code deliverable beyond artefact-plane bookkeeping (a
    planning-only voyage) — closing it lost nothing, so this is a correct
    terminal state, not an operator problem. It wins the same way ``pr_merged``
    does, REGARDLESS of ``pr_linked`` (the whole point is that this voyage
    still carries a ``prNumber`` — that's what made rule 1's old ``not
    pr_linked`` shortcut miss it in the first place). Mutually exclusive with
    ``closed_without_merge`` in practice — reconcile sets exactly one — but if
    a caller somehow set both, this (the "safe" outcome) is checked first, so
    ``merged`` wins over ``needs_attention``.

    ``manually_resolved`` (BUG-MSO-2026-0471): the manifest's
    ``mergeDetectedBy`` field reads ``"manual"`` — an operator's explicit
    hand-recorded completion signal (as opposed to the automated ``"pr"``/
    ``"git"`` detection paths). Previously written but never read by the Hub.
    Treated with the same top precedence as ``pr_merged``: an operator saying
    "this is done" is not second-guessed by the derived phase.
    """
    rollup = {"total": len(members), "complete": 0, "blocked": 0,
              "inProgress": 0, "pending": 0, "held": 0}
    buckets: dict[str, list[MemberState]] = {
        "complete": [], "blocked": [], "inProgress": [], "pending": [], "held": [],
    }
    for m in members:
        b = classify_status(m.status)
        rollup[b] += 1
        buckets[b].append(m)

    # BUG-MSO-2026-0476: a voyage whose members are ALL standalone plan-only
    # orders, all complete, has delivered no code — nothing to build was ever
    # filed. Left unchecked this is indistinguishable from a finished voyage
    # (falls straight into final_review, or merged if auto-archived with no
    # PR ever linked). Refuse both shortcuts unless a human actually decided
    # otherwise — a merged PR, an operator confirmation, or a reconcile
    # determination that there was no code deliverable (BUG-MSO-2026-0471).
    # Those three ARE the "genuine, reviewed decision" this guard defers to.
    all_plan_only = bool(members) and all(_is_plan_only(m.role_sequence) for m in members)
    if (all_plan_only and rollup["complete"] == rollup["total"]
            and not pr_merged and not manually_resolved
            and not closed_no_code_deliverable):
        return VoyagePhase(
            PHASE_NEEDS_ATTENTION,
            "plan approved but no build orders were filed for this voyage "
            "— cut BLD/FTR orders to continue",
            rollup,
        )

    if pr_merged or manually_resolved or closed_no_code_deliverable or (
            voyage_archived and not pr_linked):
        reason = "PR merged" if pr_merged else (
            "operator manually confirmed complete" if manually_resolved else (
                "PR closed without merging — no code deliverable" if closed_no_code_deliverable
                else "voyage archived"))
        return VoyagePhase(PHASE_MERGED, reason, rollup)

    # FTR-MSO-2026-0373: a closed-without-merge voyage needs an operator
    # decision regardless of its (possibly all-complete) order rollup.
    if closed_without_merge:
        return VoyagePhase(
            PHASE_NEEDS_ATTENTION,
            "PR closed without merging — reopen/re-dispatch or archive manually",
            rollup,
        )

    total = rollup["total"]
    if total == 0:
        return VoyagePhase(PHASE_BACKLOG, "no orders", rollup)

    if dep_status is None:
        local = {m.order_id: m.status for m in members}
        def dep_status(oid: str) -> str:  # noqa: F811 — deliberate default
            return local.get(oid, "PENDING")

    def _dispatchable(m: MemberState) -> bool:
        return all(
            classify_status(dep_status(d)) == "complete"
            for d in (m.depends_on or [])
        )

    dispatchable_pending = [m for m in buckets["pending"] if _dispatchable(m)]

    # 2. needs_attention — something is stuck AND the fleet cannot advance
    # anything else on its own (held orders also need a human, so they don't
    # rescue the voyage from this phase).
    if rollup["blocked"] >= 1 and rollup["inProgress"] == 0 and not dispatchable_pending:
        return VoyagePhase(
            PHASE_NEEDS_ATTENTION, _blocked_reason(buckets["blocked"]), rollup)

    # BUG-MSO-2026-0499: a PROPOSED/HELD dependent (the "held" bucket) whose
    # own dependsOn is unmet — or was met but not yet released by the
    # dispatcher's auto-queue pass — cannot be picked up by the fleet, same
    # as a blocked order. Left unchecked, reaching rule 4 below with
    # complete/blocked >= 1 (some UPSTREAM order finished) and no in-progress
    # crew falls straight into "underway" even though nothing can actually
    # happen next — the exact false-positive this bug reports (a voyage
    # showing Underway while a dependency-satisfied dependent sits stranded
    # at PROPOSED/HELD indefinitely). Gated on complete/blocked >= 1 so a
    # voyage that has genuinely never started (only held/review-gated
    # orders, nothing has run yet) still falls through to plain `backlog`
    # below rather than a false attention alarm.
    if (
        rollup["held"] >= 1
        and rollup["inProgress"] == 0
        and not dispatchable_pending
        and (rollup["complete"] >= 1 or rollup["blocked"] >= 1)
    ):
        return VoyagePhase(
            PHASE_NEEDS_ATTENTION, _blocked_reason(buckets["held"]), rollup)

    # 3. final_review — everything done, awaiting PR review + merge.
    if rollup["complete"] == total:
        return VoyagePhase(
            PHASE_FINAL_REVIEW,
            f"all {total} orders complete — awaiting PR review + merge",
            rollup,
        )

    # 4. underway — a crew is on it, or work has progressed / can progress.
    # Reaching here with blocked >= 1 means dispatchable pending work exists,
    # so the fleet can still advance the voyage on its own.
    if rollup["inProgress"] >= 1 or rollup["complete"] >= 1 or rollup["blocked"] >= 1:
        bits = [f"{rollup['complete']}/{total} complete"]
        if rollup["inProgress"]:
            bits.append(f"{rollup['inProgress']} in progress")
        if rollup["blocked"]:
            bits.append(f"{rollup['blocked']} blocked")
        return VoyagePhase(PHASE_UNDERWAY, ", ".join(bits), rollup)

    # 5. backlog — nothing started.
    return VoyagePhase(
        PHASE_BACKLOG, f"none of {total} orders started", rollup)
