# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""maestro/lead/agent.py — one LEAD wake cycle, with an explicit terminal state.

Captain ruling D8 (2026-08-25, on FTR-MSO-2026-0536's own order text) re-framed
what looked like a spend-cap question into a termination-condition requirement:

    "the important element is knowing what tasks the Lead is responsible for
    and not to just keep working forever, there needs to be a point when the
    task is done or the lead needs to report back to the captain"

So every :class:`Task` this module runs has exactly two exits — reflected in
:class:`TaskOutcome`:

  * ``DONE``          — the task's own definition of done was reached.
  * ``REPORTED_BACK``  — it was not (or could not be) reached, and why is
                        recorded in :attr:`TaskResult.reason` /
                        :attr:`TaskResult.detail`. A hit token ceiling is
                        classified here too, not as a third exit — the
                        ceiling is a BACKSTOP against runaway spend, never a
                        routine way for work to end, so it is always logged
                        as an ABNORMAL report-back (`LEAD_CEILING_HIT`), never
                        folded silently into "done".

The only task type this order wires up is a patrol tick — read `mso doctor`'s
findings and report them, plus a small transition-based check of its own
(§ below) that a shared, stateless patrol check structurally cannot express.
It is a single bounded subprocess-free read, so it always reaches DONE on its
own; the ceiling short-circuits BEFORE it runs, so the "cannot end only by
exhausting a budget" guarantee is visible even though this task type could
never itself exhaust one. Later orders (plan §14 order 7) add task types that
actually spend tokens — they plug into this same two-exit contract rather
than inventing a second one.

Token accounting: nothing in this order actually spends a token (patrol
reads are pure subprocess-free disk reads), so :func:`record_token_spend` has
no caller yet — it exists so a later order's LLM-invoking task type has
somewhere to report spend without a second ceiling mechanism appearing next
to this one.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Optional

from maestro.core.lifecycle_log import sanitize_lifecycle_message

# ---------------------------------------------------------------------------
# Defaults — named here, ONCE, and only ever read through load_lead_config().
# No other module may hardcode a heartbeat interval or a token ceiling.
# ---------------------------------------------------------------------------

# PLAN-PLN-MSO-2026-0504 §12.1: "one cheap continuous heartbeat... default 5
# min, configurable."
DEFAULT_HEARTBEAT_SECONDS = 300

# Captain ruling D8 (2026-08-25): "This should be configurable, as it depends
# on the volume of work" — a NUMBER still has to ship as the shipped default
# (§5.2's "useful with zero configuration" precedent), so one is chosen here,
# conservatively, and named in this order's handoff so it can be changed
# knowingly. 200,000 tokens/day is roughly what a handful of short Sonnet
# completions cost — enough headroom for the "delta non-empty" invocations
# §6's noise-control addendum describes, not enough to bankroll a runaway
# agentic loop unnoticed for a day.
DEFAULT_DAILY_TOKEN_CEILING = 200_000

_STATE_FILENAME = "state.json"


class TaskOutcome(str, Enum):
    """The only two ways a LEAD task ends (Captain ruling D8). Never a third."""

    DONE = "done"
    REPORTED_BACK = "reported_back"


@dataclass(frozen=True)
class TaskResult:
    outcome: TaskOutcome
    summary: str
    reason: Optional[str] = None
    findings_count: int = 0
    tokens_spent: int = 0
    detail: str = ""


# ---------------------------------------------------------------------------
# Config resolution — mirrors fleet_runner.load_completion_config()'s shape:
# read config/workspace.json, fall back to the shipped defaults on any
# absence/malformed content (fail-safe, never an exception to the caller).
# ---------------------------------------------------------------------------

def load_lead_config(artefact_root: Path) -> dict:
    """Resolve the ``lead`` block of ``config/workspace.json``.

    Returns a dict with keys ``enabled``, ``heartbeatSeconds``,
    ``tokenCeiling.dailyTokens``. Absent/unreadable/malformed config, or a
    missing ``lead`` block entirely, all resolve to the shipped defaults —
    the block being absent enables sane behaviour, it never disables the
    daemon outright (same fail-safe shape as ``completion`` in
    ``load_completion_config``).
    """
    ws_file = artefact_root / "config" / "workspace.json"
    try:
        data = json.loads(ws_file.read_text(encoding="utf-8"))
        raw = data.get("lead", {}) or {}
    except Exception:
        raw = {}

    ceiling = raw.get("tokenCeiling", {}) or {}

    return {
        "enabled": bool(raw.get("enabled", True)),
        "heartbeatSeconds": int(raw.get("heartbeatSeconds", DEFAULT_HEARTBEAT_SECONDS)),
        "tokenCeiling": {
            "dailyTokens": int(ceiling.get("dailyTokens", DEFAULT_DAILY_TOKEN_CEILING)),
        },
    }


# ---------------------------------------------------------------------------
# Persisted daemon state — `.mso/lead/state.json` (gitignored runtime plane,
# same class as `.mso/state/order-ledger.jsonl`). Tracks what the daemon
# reported last time so a stateless re-derivation on every tick can't
# distinguish "always been stopped" (not alarming) from "just stopped"
# (alarming) — see `_dispatcher_transition_finding` below.
# ---------------------------------------------------------------------------

def _state_file(artefact_root: Path) -> Path:
    return artefact_root / "lead" / _STATE_FILENAME


def load_state(artefact_root: Path) -> dict:
    try:
        return json.loads(_state_file(artefact_root).read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save_state(artefact_root: Path, state: dict) -> None:
    f = _state_file(artefact_root)
    f.parent.mkdir(parents=True, exist_ok=True)
    f.write_text(json.dumps(state, indent=2), encoding="utf-8")


def _today(now: datetime) -> str:
    return now.astimezone(timezone.utc).date().isoformat()


def _daily_tokens_spent_so_far(artefact_root: Path, now: datetime) -> int:
    state = load_state(artefact_root)
    if state.get("dailyWindowDate") != _today(now):
        return 0
    return int(state.get("dailyTokensSpent", 0) or 0)


def record_token_spend(artefact_root: Path, tokens: int, *, now: Optional[datetime] = None) -> int:
    """Add *tokens* to today's spend counter and return the new total.

    Rolls the counter over at UTC midnight. No caller exists yet in this
    order (see module docstring) — this is the single accounting surface a
    later, LLM-invoking task type reports into, so the ceiling this module
    enforces and the spend a future task records are never two mechanisms.
    """
    now = now or datetime.now(timezone.utc)
    today = _today(now)
    state = load_state(artefact_root)
    if state.get("dailyWindowDate") != today:
        spent = 0
    else:
        spent = int(state.get("dailyTokensSpent", 0) or 0)
    spent += max(0, int(tokens))
    state["dailyWindowDate"] = today
    state["dailyTokensSpent"] = spent
    _save_state(artefact_root, state)
    return spent


def _write_lifecycle_event(artefact_root: Path, event_type: str, message: str) -> None:
    """Append a lifecycle.log line without depending on fleet_runner's
    ambient workspace resolution — this module always has an explicit
    *artefact_root* (the daemon is a separately-spawned process, not
    guaranteed to share the dispatcher's cwd/env resolution)."""
    log_dir = artefact_root / "logs"
    try:
        log_dir.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        line = f"{timestamp} | {event_type:<10} | {sanitize_lifecycle_message(message)}\n"
        with open(str(log_dir / "lifecycle.log"), "a", encoding="utf-8") as f:
            f.write(line)
    except OSError:
        pass


# ---------------------------------------------------------------------------
# The one task type this order wires up: a patrol tick.
# ---------------------------------------------------------------------------

def _dispatcher_transition_finding(artefact_root: Path, previous_state: Optional[str], now: datetime) -> Optional[str]:
    """Detect a RUNNING -> not-RUNNING transition the daemon itself observed.

    A shared, stateless patrol check (`maestro.patrol.checks.dispatcher`)
    deliberately treats a dead-pid-with-no-heartbeat as STOPPED, not an
    alarm (test_dispatcher_check_dead_pid_no_finding) — a dispatcher that was
    simply never started looks identical on disk to one that has cleanly
    exited, and neither is a problem. But "I watched it running, and now it
    is gone" IS worth a finding — it is exactly the acceptance scenario this
    order tests (start dispatcher, start LEAD, kill dispatcher). That
    requires memory across ticks, which a stateless check cannot have, so it
    lives here rather than in the shared registry.
    """
    if previous_state != "RUNNING":
        return None
    from maestro.core.fleet_monitor import get_dispatcher_status
    current = get_dispatcher_status(artefact_root)
    if current["state"] == "RUNNING":
        return None
    return (
        f"Dispatcher was RUNNING as of the previous LEAD tick and is now "
        f"{current['state']} (pid={current.get('pid')}). It will not make "
        f"progress on pending work until it is restarted."
    )


def run_once(artefact_root: Path, *, config: Optional[dict] = None, now: Optional[datetime] = None) -> TaskResult:
    """Run one LEAD wake cycle. Always returns — never loops, never blocks
    on anything beyond a single ``mso doctor`` pass.

    Definition of DONE for this task type: the patrol pass completed and its
    result was recorded. REPORTED_BACK covers a hit token ceiling (checked
    BEFORE any work runs, per Captain ruling D8 — the backstop aborts the
    tick rather than letting it run over budget) and a patrol pass that
    itself raised.
    """
    now = now or datetime.now(timezone.utc)
    cfg = config or load_lead_config(artefact_root)
    prior_state = load_state(artefact_root)

    ceiling = cfg["tokenCeiling"]["dailyTokens"]
    spent = _daily_tokens_spent_so_far(artefact_root, now)
    if spent >= ceiling:
        detail = (
            f"Daily token ceiling ({ceiling}) reached ({spent} spent) before "
            f"this tick ran. This is a backstop, not a routine stopping "
            f"point — reporting back instead of running."
        )
        _write_lifecycle_event(artefact_root, "LEAD_CEILING_HIT", detail)
        _save_state(artefact_root, {
            **prior_state,
            "lastTickAt": now.isoformat(),
            "lastOutcome": TaskOutcome.REPORTED_BACK.value,
            "lastReason": "token_ceiling",
        })
        return TaskResult(
            TaskOutcome.REPORTED_BACK,
            summary=f"Token ceiling reached ({spent}/{ceiling}) — reported back without running.",
            reason="token_ceiling",
            tokens_spent=spent,
            detail=detail,
        )

    try:
        from maestro.patrol import run_patrol
        result = run_patrol(artefact_root)
    except Exception as exc:
        detail = f"Patrol pass failed: {exc}"
        _write_lifecycle_event(artefact_root, "LEAD_REPORTED", detail)
        _save_state(artefact_root, {
            **prior_state,
            "lastTickAt": now.isoformat(),
            "lastOutcome": TaskOutcome.REPORTED_BACK.value,
            "lastReason": "error",
        })
        return TaskResult(
            TaskOutcome.REPORTED_BACK,
            summary="Patrol pass failed — reported back.",
            reason="error",
            detail=detail,
        )

    dispatcher_note = _dispatcher_transition_finding(artefact_root, prior_state.get("lastDispatcherState"), now)
    if dispatcher_note:
        _write_lifecycle_event(artefact_root, "LEAD_FINDING", dispatcher_note)

    from maestro.core.fleet_monitor import get_dispatcher_status
    current_dispatcher_state = get_dispatcher_status(artefact_root)["state"]

    summary = f"Patrol tick complete — {result.checks_run} check(s), {len(result.findings)} finding(s)."
    if dispatcher_note:
        summary += " " + dispatcher_note
    _write_lifecycle_event(artefact_root, "LEAD_TICK", summary)

    # PLAN-PLN-MSO-2026-0504 §13 / FTR-MSO-2026-0539: persisted alongside
    # lastFindingsCount so the Hub's LEAD status endpoint can read a
    # severity breakdown without running its own patrol pass on every HTTP
    # poll — the daemon's own heartbeat (this tick) is the single place
    # `mso doctor` actually runs, exactly as §6's noise-control design
    # intends. Unrecognised severities never occur (patrol.registry.Finding
    # is always built from SEVERITIES), so no "other" bucket is needed.
    findings_by_severity = {"critical": 0, "high": 0, "medium": 0, "low": 0}
    for f in result.findings:
        if f.severity in findings_by_severity:
            findings_by_severity[f.severity] += 1

    _save_state(artefact_root, {
        **prior_state,
        "lastTickAt": now.isoformat(),
        "lastOutcome": TaskOutcome.DONE.value,
        "lastReason": None,
        "lastDispatcherState": current_dispatcher_state,
        "lastFindingsCount": len(result.findings),
        "lastFindingsBySeverity": findings_by_severity,
    })

    return TaskResult(
        TaskOutcome.DONE,
        summary=summary,
        findings_count=len(result.findings),
        detail=dispatcher_note or "",
    )
