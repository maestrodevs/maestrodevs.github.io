#!/usr/bin/env python3
"""
Maestro - Parallel Fleet Runner v2.0.0

Features:
- Pre-flight checks (clean state before starting)
- Rogue process detection and cleanup
- Stale state file cleanup
- Robust process tracking via PID files (no parent-child handles)
- Graceful shutdown handling
- WAVE SEQUENCING - Auto-promotes through waves when crews complete
- Bell ringing on voyage completion
- v5.0: Compatible with self-organizing crews and queue system
- v5.1: STAGGERED CREW LAUNCHES - configurable delay between crew starts
- v5.2: AUTO-DISPATCHER - Watches queues and auto-dispatches idle crews
        Priority: requests first, then orders. Never exceeds max concurrent crews.
- v6.0: INDEPENDENT PROCESS LAUNCH - Crews launch as fully detached processes
        (CREATE_NEW_CONSOLE | CREATE_NEW_PROCESS_GROUP).
        No CLI lock needed. Restores 5-crew concurrent capability.
- v7.0: DEPENDENCY-AWARE DISPATCH - 8-tier priority queues, escalation handling
- v7.3: TIMEOUT BRIEFING - captures iteration state on timeout, re-feeds to next crew
- v8.0: STOP HOOK ITERATION CONTROL - crew.py uses python -m maestro.hooks.stop (Ralph Wiggum
        pattern) for multi-pass iterations. Single Claude invocation per order.
        Hook intercepts Claude's natural exit and re-feeds prompts.
        Per-crew ralph-state.md tracks iteration count and status.
- v8.2: ROLE SEQUENCE GATES - Automatic enforcement of role ordering per voyage.
        Reads roleSequence from order templates, checks voyage-level completion
        status before dispatching. Quality gates (BOS/QA) can never be skipped.
        Usage: python fleet-runner.py --validate-sequences (dry-run check)
- v8.3: REQUIREMENTS TRACEABILITY GATE - QM can run scanner pre-flight or post-voyage.
        Usage: python fleet-runner.py --validate-traceability
        Runs: dotnet run --project Uplifted/Tools/RequirementsScanner -- --gate --min-coverage 80
- v8.6: DISPATCH LOG FIXES + POST-VOYAGE MATRIX UPDATE
        Fixed: priority showing '?' (wrong field name sort_priority→priority)
        Fixed: order title showing 'Unknown' (queue JSONs use orderId, no title field)
        Fixed: order ID resolution (orderId→id→filename fallback chain)
        Added: Post-voyage auto-refresh of REQUIREMENTS-MATRIX.md via update-matrix.py
- v8.13: POST-VOYAGE AUTO-PR CREATION
        Scans completed orders at Eight Bells, collects unique targetRepo values,
        creates PRs from voyage branch to main for each repo that had work done.
        Usage: automatic at Eight Bells, or manual: python fleet-runner.py --create-prs
- v2.0.0: MANAGED REPO LIFECYCLE
        Per-crew worktree: each crew runs in its own git worktree on the voyage branch.
        Post-completion: create/update PR immediately when each crew completes.
        Cleanup: remove voyage worktree at Eight Bells.
"""

import argparse
import atexit
import json
import os
import re
import shutil
import signal
import subprocess
from maestro.core.proc import run_hidden, popen_hidden, clear_console, init_console  # FTR-MSO-2026-0408: windowless subprocess + in-process console
from maestro.launch.sandbox import spawn as _spawn
from maestro.core.gates import (  # FTR-MSO-2026-0427: per-transition gates
    load_gate_config,
    gate_check_post_nav,
    gate_check_transition,
    transition_key,
    should_auto_approve,
)
from maestro.personas import current_persona
import sys
import concurrent.futures
import threading
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Dict, Any, Optional, List

# Windows-specific process creation flags
if os.name == 'nt':
    CREATE_NEW_CONSOLE = 0x00000010
    DETACHED_PROCESS = 0x00000008
    CREATE_NEW_PROCESS_GROUP = 0x00000200

# Enable Windows console colors and UTF-8 output
if os.name == 'nt':
    # FTR-MSO-2026-0408: was os.system('chcp 65001')/os.system('') — each spawned
    # a cmd.exe (a console flash under the detached dispatcher). Now set in-process
    # via ctypes; no-ops when no console is attached (the detached case).
    init_console()
    # Fix Python stdout/stderr encoding for Windows consoles (prevents charmap errors)
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    if hasattr(sys.stderr, 'reconfigure'):
        sys.stderr.reconfigure(encoding='utf-8', errors='replace')

from maestro import core_constants as _core_constants
from maestro.core import order_ledger  # BUG-MSO-2026-0294: git-immune dispatch gate
from maestro.core.dep_holds import write_dep_holds  # BUG-MSO-2026-0349: held-order visibility
from maestro.core import skip_list  # BUG-MSO-2026-0451: shared skip-list schema normalisation
from maestro.core.lifecycle_log import sanitize_lifecycle_message  # BUG-MSO-2026-0474: one-line-per-event guard
from maestro.errors import run_cli
from maestro.workspace import MSO_DIR_NAME  # FTR-MSO-2026-0361: artefact dir name is never hand-spelled here

def _get_crew_name(slot: int) -> str:
    """Return persona squad name for slot, falling back to 'Crew<slot>'."""
    return _core_constants.get_squad_name(slot) or f"Crew{slot}"

def _get_role_model_label(role: str) -> str:
    """Return short model label for role (Opus/Sonnet/Haiku), falling back to 'Sonnet'."""
    return _core_constants.get_role_model(role)


# Active voyage branch — set from MAESTRO_SPRINT_BRANCH env var
# Injected into all crew process environments so crews know where to push commits.
ACTIVE_VOYAGE_BRANCH: str = os.environ.get("MAESTRO_SPRINT_BRANCH", "")

# v8.13: Track target repos dispatched during this session (for post-voyage PR creation)
_SESSION_TARGET_REPOS: Dict[str, list] = {}  # repo -> [order titles]
# v2.0.2: Track voyage branch per repo (for per-repo PR creation)
_SESSION_REPO_BRANCHES: Dict[str, str] = {}  # repo -> voyage branch

# v7.1: Comprehensive terminal states — any state a crew can exit with that means "done"
# This must match ALL possible final_status values from crew.py
# FTR-MSO-2026-0359: NETWORK — the iteration died of a connectivity loss
# (api_retry distress / offline signature); requeued OUTSIDE the MAX_REQUEUES budget.
# BUG-MSO-2026-0423: CODE — the iteration died of a DETERMINISTIC interpreter
# parse/syntax fault (PowerShell/bash/cmd/python); requeued INSIDE the normal
# MAX_REQUEUES budget so a genuine syntax bug trips the failure ceiling.
TERMINAL_STATES = {
    "COMPLETE", "BLOCKED", "ERROR", "MAX_ITERATIONS", "MAX_TURNS", "CRASHED",
    "CIRCUIT_BREAKER", "TIMEOUT", "AUTH_ERROR", "INTERRUPTED", "NETWORK", "CODE"
}

# BUG-MSO-2026-0443: the crew exit status that triggers archive_stalled_order
# ("BLOCKED" / "MAX_ITERATIONS" / "CIRCUIT_BREAKER") must map to its OWN
# stalledCause — archive_stalled_order's stalled_cause parameter defaults to
# "MAX_ITERATIONS", and the old call site passed only `reason`, so a
# first-iteration BLOCKED (a role deliberately declining to act, e.g. awaiting
# an operator decision) was archived with stalledCause=MAX_ITERATIONS even
# though the order never touched its iteration budget. BLOCKED_BY_ROLE names
# what actually happened; CIRCUIT_BREAKER now records its own cause instead of
# inheriting the MAX_ITERATIONS default too.
STALLED_CAUSE_BY_STATUS = {
    "BLOCKED": "BLOCKED_BY_ROLE",
    "MAX_ITERATIONS": "MAX_ITERATIONS",
    "CIRCUIT_BREAKER": "CIRCUIT_BREAKER",
}

# BUG-MSO-2026-0443: which stalledCause values leave behind partial, buildable
# work — vs. a cause where a dependent should wait for human resolution
# (`mso order retry`) rather than proceed on the assumption that useful output
# exists. MAX_ITERATIONS and CIRCUIT_BREAKER both mean the crew was actively
# working and hit a hard cap (turn budget / repeated-failure breaker) — partial
# work is the norm. ERROR (zero-turn failure) and BLOCKED_BY_ROLE (the role
# deliberately declined to act, often awaiting an operator decision) do not —
# there is nothing reliable for a dependent to build on yet.
STALLED_SATISFYING_CAUSES = {"MAX_ITERATIONS", "CIRCUIT_BREAKER"}

class C:
    """ANSI color codes."""
    RESET = '\033[0m'
    BOLD = '\033[1m'
    DIM = '\033[2m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    RED = '\033[91m'
    WHITE = '\033[97m'
    MAGENTA = '\033[95m'

# Global state
ACTIVE_PROCESSES: Dict[int, int] = {}  # crew_number -> PID (file-based monitoring, no process handles)
DRAINING_PROCESSES: Dict[int, Dict[str, Any]] = {}  # crew_number -> {pid, voyage_id, drained_at}
ORDERS_IN_TRANSITION: set = set()  # order IDs advanced to next role but not yet dispatched (BUG-MSO-2026-0017)
_BUG0263_WARNED: set = set()  # order IDs for which the BUG-0263 resurfaced-terminal WARN was already emitted this process (BUG-MSO-2026-0288)
LAST_ORDER_TERMINAL_AT: Optional[datetime] = None  # wall-clock of the most recent COMPLETE/STALLED archive (BUG-MSO-2026-0024)
# BUG-MSO-2026-0236: single-flight guard — set of (order_id, role) tuples currently
# being finalized in process_crew_completion(). Prevents a second dispatcher-loop
# iteration from entering finalization for the same (order, role) while the first
# finalization thread is still running.
_FINALIZING_ORDERS: set = set()
_FINALIZING_LOCK = threading.Lock()
# BUG-MSO-2026-0222: watchdog budget for post-crew finalization (advance/archive).
# If complete_order + auto_queue_unblocked_orders don't finish within this window,
# the dispatcher logs a warning and continues — the roleSucceededAt checkpoint ensures
# self-healing on the next restart.
FINALIZATION_WATCHDOG_SECONDS: int = 120
_CREW_LOG_HANDLES: Dict[int, Any] = {}  # crew_number -> file handle (for background mode log files)
FLEET_STATE_FILE: Optional[Path] = None
SHUTDOWN_REQUESTED = False
_MAESTRO_DIR_OVERRIDE: Optional[Path] = None
# BUG-MSO-2026-0268: CLI override for convergence network timeout; None = use workspace.json default.
_CONVERGENCE_TIMEOUT_CLI_OVERRIDE: Optional[int] = None


def _resolve_workspace_dir() -> Path:
    """Internal workspace resolver — honours _MAESTRO_DIR_OVERRIDE for test isolation."""
    if _MAESTRO_DIR_OVERRIDE is not None:
        return _MAESTRO_DIR_OVERRIDE
    from maestro.workspace import get_artefact_root as _gar
    return _gar()

# Public alias so external callers (tests, crew.py) can import get_workspace_dir from here.
get_workspace_dir = _resolve_workspace_dir


def get_artefact_root() -> Path:
    """Artefact root (the ``.mso/`` dir) — central resolver, FTR-MSO-2026-0361.

    Every artefact-plane path in this module (queues, orders, voyages, crews,
    logs, config, usage, prompts, state) resolves through here. Reads the
    module-global ``get_workspace_dir`` at call time so test monkeypatches of
    that name and ``_MAESTRO_DIR_OVERRIDE`` both keep working. Phase 2+
    retargets maestro.workspace.get_artefact_root() to the artefact repo
    without any call-site changes here.
    """
    return get_workspace_dir()


def get_product_repo(target_repo: Optional[str] = None) -> Path:
    """Product repository root — central resolver, FTR-MSO-2026-0361.

    Today (embedded mode) this is the parent of the ``.mso/`` dir; *target_repo*
    is accepted for the Phase-4 signature (repos-map resolution) and is unused.
    Mirrors the historical get_base_dir() semantics exactly, including the
    _MAESTRO_DIR_OVERRIDE test escape hatch.
    """
    if _MAESTRO_DIR_OVERRIDE is not None:
        # BUG-MSO-2026-0391: the override (--maestro-dir / test hatch) points at
        # the ARTEFACT workspace dir, whose parent is the product repo only in
        # embedded mode. In solo/shared mode the parent is the ARTEFACT repo —
        # returning it routed every product-side git surface at the artefact
        # checkout whenever the dispatcher was spawned via `mso dispatch`
        # (cli.py always passes --maestro-dir), defeating the BUG-0389 fix.
        # Delegate to the workspace resolver anchored at the override so the
        # configured productRepo / registry entry wins.
        if get_artefact_mode() == "embedded":
            return _MAESTRO_DIR_OVERRIDE.parent
        from maestro.workspace import get_product_repo as _gpr
        return _gpr(target_repo, start=_MAESTRO_DIR_OVERRIDE.parent)
    from maestro.workspace import get_product_repo as _gpr
    return _gpr(target_repo)


def get_base_dir() -> Path:
    return get_product_repo()


def get_artefact_repo_root() -> Path:
    """Root of the git repo that carries the DURABLE artefact plane.

    FTR-MSO-2026-0366: embedded mode — the product repo (identical to
    get_base_dir() by construction: the ``.mso`` parent IS the product repo).
    Solo/shared mode — the artefact repo root: get_artefact_root() already
    retargets to ``<artefact-repo>/.mso``, so its parent is correct by
    construction (plan PLAN-PLN-MSO-2026-0358 §3.2). All lifecycle commits
    (advance/archive/retry/untrack) MUST use this, never get_base_dir(),
    so bookkeeping lands in the right history in both modes.
    """
    return get_artefact_root().parent


def get_artefact_mode() -> str:
    """Artefact mode of the resolved workspace: embedded | solo | shared.

    Reads ``artefacts.mode`` from the artefact workspace's workspace.json via
    this module's own get_artefact_root() (so the _MAESTRO_DIR_OVERRIDE test
    escape hatch is honoured). Fail-open to "embedded" — full back-compat.
    """
    try:
        cfg = json.loads(
            (get_artefact_root() / "config" / "workspace.json").read_text(encoding="utf-8"))
        mode = (cfg.get("artefacts") or {}).get("mode")
        return mode if mode in ("solo", "shared") else "embedded"
    except Exception:
        return "embedded"


def _write_lifecycle_event_to(root: Path, event_type: str, message: str) -> None:
    """Write a lifecycle event line to a SPECIFIC artefact root, bypassing
    get_artefact_root() resolution.

    write_lifecycle_event() always writes wherever get_workspace_dir() (this
    module's global, honouring _MAESTRO_DIR_OVERRIDE) currently resolves. The
    BUG-MSO-2026-0448 divergence check needs to also record its WARN in the
    CANONICAL plane — the one `mso status`/the Hub actually read — which is
    exactly the plane get_artefact_root() is NOT pointing at while the
    override is active. Same format as write_lifecycle_event(); best-effort.
    """
    try:
        log_dir = root / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        line = f"{timestamp} | {event_type:<10} | {message}\n"
        with open(str(log_dir / "lifecycle.log"), 'a', encoding='utf-8') as f:
            f.write(line)
    except Exception:
        pass


def _check_maestro_dir_divergence(override: Path) -> bool:
    """BUG-MSO-2026-0448: warn loudly when `--maestro-dir` diverges from the
    artefact root solo/shared retargeting would otherwise choose.

    `_MAESTRO_DIR_OVERRIDE` (this function's *override* argument) bypasses
    `get_artefact_root()`'s solo/shared redirect entirely — by design, so
    tests and manual recovery sessions can pin an EXACT workspace regardless
    of what the registry/pointer says. That is a no-op in embedded mode
    (there is only one plane to point at). In solo/shared mode it means a
    stale/frozen product-repo `.mso` handed to `--maestro-dir` — exactly what
    `mso dispatch` itself did before this fix — silently sends every runtime
    write (crews/, logs/, state/) to the WRONG plane: `mso status` and the Hub
    resolve the artefact root normally and report an idle fleet while a live
    one runs invisibly elsewhere (the operator-reported failure).

    Chosen behaviour: WARN, not refuse. A hard refusal would break the
    documented escape hatch this flag exists for (tests pinning an isolated
    scratch workspace; manual recovery/diagnostic sessions that may
    deliberately want the non-canonical plane). The dispatch path that
    actually mattered (`mso dispatch`) is fixed at the source (cli.py now
    passes the solo-aware artefact dir), so in normal operation this WARN
    should never fire — it is a safety net for direct fleet_runner.py
    invocations and hand-built scripts, not the primary fix.

    Returns True (and prints + logs a WARN naming both planes) when the
    override diverges from the canonical artefact root; False otherwise
    (embedded mode, override already correct, or resolution failed — this
    check fails OPEN so a bare/incomplete workspace, as many tests set up,
    never blocks a run).
    """
    from maestro.workspace import artefact_root_for, get_artefact_mode

    override = override.resolve()
    try:
        correct = artefact_root_for(override.parent).resolve()
    except Exception:
        return False
    if correct == override:
        return False

    try:
        mode = get_artefact_mode(start=correct.parent)
    except Exception:
        mode = "solo/shared"

    msg = (
        f"--maestro-dir points at {override}, but this workspace's "
        f"artefacts.mode is '{mode}', which resolves the canonical artefact "
        f"root to {correct} instead. Runtime state (crews/, logs/, state/) "
        f"will be written to {override} and will be INVISIBLE to `mso status` "
        f"and the Hub, both of which resolve {correct}. If this divergence is "
        f"deliberate (a test or a manual recovery session), this warning is "
        f"safe to ignore."
    )
    print_warn(f"[BUG-MSO-2026-0448] {msg}")
    write_lifecycle_event("WARN", f"[BUG-MSO-2026-0448] {msg}")
    _write_lifecycle_event_to(correct, "WARN", f"[BUG-MSO-2026-0448] {msg}")
    return True


def solo_worktree_repo_root(target_repo: Optional[str] = None) -> Optional[Path]:
    """Product-repo checkout that PRODUCT-side git ops must run in (git ``cwd``).

    BUG-MSO-2026-0389: in solo/shared mode the dispatcher's cwd is the ARTEFACT
    repo, but every product-side git surface — crew/voyage worktree
    prep, crew-branch creation, convergence, salvage, prune, branch-existence
    checks, fetch/push — must target the PRODUCT repo. The voyage branch and
    every crew worktree live there; running these against the artefact checkout
    is exactly the dogfood failure (WORKTREE_FAIL, then an unisolated crew
    editing the primary product checkout).

    Embedded mode → ``None`` (the dispatcher's cwd IS the product repo, so the
    single-repo/embedded path stays byte-identical). Solo/shared mode → the
    configured product repo via :func:`get_product_repo`. Raises when the
    product repo cannot be resolved in solo/shared mode — callers translate that
    into HOLDING the order (never a silent fallback to the artefact checkout).
    """
    if get_artefact_mode() == "embedded":
        return None
    return get_product_repo(target_repo or None)


def get_crew_dir(crew_number: int) -> Path:
    return get_artefact_root() / f"crews/crew{crew_number}"


def load_project_config(project_acronym=None):
    """Load project config from the project registry."""
    admiralty_dir = get_artefact_root()
    projects_file = admiralty_dir / "config" / "projects.json"

    if not projects_file.exists():
        return None

    with open(projects_file, encoding='utf-8') as f:
        registry = json.load(f)

    if not project_acronym:
        project_acronym = registry.get("defaultProject", "OTM")

    project_info = registry.get("projects", {}).get(project_acronym)
    if not project_info:
        return None

    # Load per-project config if available
    config_file_rel = project_info.get("configFile", f"config/projects/{project_acronym}.json")
    config_file = admiralty_dir / config_file_rel

    if config_file.exists():
        with open(config_file, encoding='utf-8') as f:
            project_config = json.load(f)
        project_info["_config"] = project_config

    return project_info

def clear_screen():
    # FTR-MSO-2026-0408: was os.system('cls'/'clear') — each spawned a shell (a
    # console flash under the detached dispatcher). In-process ANSI clear that
    # no-ops when no console is attached.
    clear_console()

def print_header(title: str):
    """Print a section header."""
    print(f"\n  {C.CYAN}{C.BOLD}{'='*70}")
    print(f"  {title}")
    print(f"  {'='*70}{C.RESET}\n")

def print_ok(msg: str):
    print(f"  {C.GREEN}[OK]{C.RESET} {msg}")

def print_warn(msg: str):
    print(f"  {C.YELLOW}[!!]{C.RESET} {msg}")

def print_error(msg: str):
    print(f"  {C.RED}[XX]{C.RESET} {msg}")

def print_info(msg: str):
    print(f"  {C.DIM}[..]{C.RESET} {msg}")


def write_lifecycle_event(event_type: str, message: str):
    """Append a timestamped lifecycle event to the log file.

    Used by the unified Maestro Monitor to display recent events.
    Format: YYYY-MM-DD HH:MM:SS | EVENT_TYPE | message
    Auto-rotates when log exceeds 1000 lines.

    BUG-MSO-2026-0474: *message* is sanitized to a single physical line
    before it is written — lifecycle.log's contract is one line per event,
    and free text (e.g. review revise/reject notes) reaching this boundary
    unescaped used to blow the format apart.
    """
    log_dir = get_artefact_root() / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / "lifecycle.log"

    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    line = f"{timestamp} | {event_type:<10} | {sanitize_lifecycle_message(message)}\n"

    try:
        with open(str(log_file), 'a', encoding='utf-8') as f:
            f.write(line)

        # Rotate if too large
        if log_file.stat().st_size > 100000:  # ~1000 lines
            lines = log_file.read_text(encoding='utf-8').split('\n')
            # Keep last 500 lines
            log_file.write_text('\n'.join(lines[-500:]), encoding='utf-8')
    except:
        pass


def _lifecycle_commit_enabled() -> bool:
    """BUG-MSO-2026-0295: `lifecycle.commitTransitions` in workspace.json (default ON)."""
    try:
        cfg = json.loads(
            (get_artefact_root() / "config" / "workspace.json").read_text(encoding="utf-8"))
        return bool((cfg.get("lifecycle") or {}).get("commitTransitions", True))
    except Exception:
        return True


def _commit_lifecycle_transition(paths: List[Path], message: str) -> bool:
    """BUG-MSO-2026-0295: commit an order-lifecycle file transition (best-effort).

    Lifecycle moves (queue → orders/complete) used to live only in the working
    tree; any `git reset --hard` / checkout rewound them, resurrecting completed
    orders as PENDING and carrying stale queue snapshots through voyage PRs into
    the base branch (PSG VOY-PSG-2026-0344). Committing the transition puts the
    truth in history. Fail-open by design: not a git repo, nothing staged, or
    git missing → return False silently. The BUG-0294 ledger still gates
    dispatch regardless.

    FTR-MSO-2026-0366: the commit targets the repo that carries the durable
    artefact plane — the product repo in embedded mode (unchanged), the
    ARTEFACT repo in solo/shared mode (the product repo receives zero
    bookkeeping commits). In solo/shared mode each transition also sweeps the
    other durable-plane dirs into the same commit (queue/voyage/plan/handoff/
    report/usage writes — e.g. a crew's plan file — so the committed state is
    never stale; runtime dirs are gitignored and never picked up), and a
    successful commit arms the debounced artefact-repo push.
    """
    if not _lifecycle_commit_enabled():
        return False
    try:
        solo = get_artefact_mode() != "embedded"
        base = get_artefact_repo_root()
        if not (base / ".git").exists():
            return False
        rel = [str(p) for p in paths]
        add_r = run_hidden(["git", "add", "--"] + rel,
                               capture_output=True, text=True,
                               cwd=str(base), timeout=15)
        if add_r.returncode != 0:
            return False
        if solo:
            for spec in _durable_plane_pathspecs(base):
                run_hidden(["git", "add", "--", spec],
                               capture_output=True, text=True,
                               cwd=str(base), timeout=15)
            # Solo: commit everything staged for this transition (explicit
            # paths + durable-plane sweep). Embedded keeps the pathspec-scoped
            # commit so unrelated staged changes are never swept in.
            commit_cmd = ["git", "commit", "-m", message]
        else:
            commit_cmd = ["git", "commit", "-m", message, "--"] + rel
        commit_r = run_hidden(
            commit_cmd, capture_output=True, text=True, cwd=str(base), timeout=15)
        if commit_r.returncode == 0:
            _schedule_artefact_push()
            return True
        return False
    except Exception:
        return False


# FTR-MSO-2026-0366: durable-plane dirs swept into every solo-mode lifecycle
# commit (order scope item 2 — queue/voyage/plan/handoff/report/usage writes).
# The runtime plane (crews/, logs/, state/, temp/, worktrees/, prompts/active)
# is gitignored in the artefact repo, so `git add` on these specs can never
# pick it up (and BUG-0304 never-force-add is respected — no -f anywhere).
_DURABLE_PLANE_DIRS = ("queues", "orders", "voyages", "plans", "handoffs",
                       "reports", "requirements", "prompts", "usage")


def _durable_plane_pathspecs(base: Path) -> List[str]:
    """Existing durable-plane pathspecs under *base* (the artefact repo root).

    Filtered to dirs present on disk — `git add` errors on a pathspec that
    matches nothing.
    """
    specs = []
    for d in _DURABLE_PLANE_DIRS:
        spec = f"{MSO_DIR_NAME}/{d}"
        if (base / MSO_DIR_NAME / d).is_dir():
            specs.append(spec)
    return specs


# ---------------------------------------------------------------------------
# FTR-MSO-2026-0366: debounced artefact-repo push (solo/shared mode)
# ---------------------------------------------------------------------------
# Ruling #4 (PLAN-PLN-MSO-2026-0358 §0a): commit EVERY lifecycle transition
# locally, push debounced (default 30 s) so a dispatch storm doesn't hammer
# the remote — and NET git noise goes DOWN (product repos stop carrying
# bookkeeping pushes entirely; the artefact repo batches). No remote
# configured → local-only, silently. Push failures are fail-open: WARN +
# exponential backoff, never block dispatch (offline solo laptops must work).

ARTEFACT_PUSH_DEBOUNCE_DEFAULT = 30
_ARTEFACT_PUSH_LOCK = threading.Lock()
_ARTEFACT_PUSH_STATE = {
    "pending": False,     # unpushed lifecycle commit(s) exist
    "last_push": 0.0,     # time.monotonic() of last successful push
    "backoff": 0.0,       # current failure backoff (seconds)
    "not_before": 0.0,    # monotonic gate while backing off
    "fail_count": 0,      # BUG-MSO-2026-0548: consecutive push failures, reset on success
    "escalated": False,   # BUG-MSO-2026-0548: an ARTEFACT_PLANE_DIVERGED event has fired
                           # for the current failure streak — suppresses repeat escalation
                           # spam while the state file keeps updating every retry
}


def _artefact_push_debounce_seconds() -> int:
    try:
        cfg = json.loads(
            (get_artefact_root() / "config" / "workspace.json").read_text(encoding="utf-8"))
        val = int((cfg.get("artefacts") or {}).get(
            "pushDebounceSeconds", ARTEFACT_PUSH_DEBOUNCE_DEFAULT))
        return max(0, val)
    except Exception:
        return ARTEFACT_PUSH_DEBOUNCE_DEFAULT


def _schedule_artefact_push() -> None:
    """Arm the debounced artefact-repo push after a lifecycle commit.

    Embedded mode: no-op (bookkeeping rides the product repo's normal
    PR flow, unchanged). Solo/shared: mark pending and flush if the
    debounce window has already elapsed.
    """
    if get_artefact_mode() == "embedded":
        return
    with _ARTEFACT_PUSH_LOCK:
        _ARTEFACT_PUSH_STATE["pending"] = True
    flush_artefact_push()


def flush_artefact_push(force: bool = False) -> bool:
    """Push pending artefact-repo lifecycle commits to origin (debounced).

    Called after every lifecycle commit, once per dispatcher tick, and with
    ``force=True`` on dispatcher exit so the tail of a run is never left
    unpushed. Pushes the artefact repo's CURRENT branch — solo mode keeps
    the artefact repo on its default branch permanently (state never forks,
    plan §3.4). Returns True only when a push actually succeeded.

    Fail-open: no remote named ``origin`` → local-only (pending cleared, no
    error); push failure → WARN lifecycle event + exponential backoff
    (30 s → 10 min cap), pending kept so a later flush retries.
    """
    if get_artefact_mode() == "embedded":
        return False
    with _ARTEFACT_PUSH_LOCK:
        if not _ARTEFACT_PUSH_STATE["pending"]:
            return False
        now = time.monotonic()
        if not force:
            if now < _ARTEFACT_PUSH_STATE["not_before"]:
                return False
            if now - _ARTEFACT_PUSH_STATE["last_push"] < _artefact_push_debounce_seconds():
                return False
        try:
            repo = get_artefact_repo_root()
            if not (repo / ".git").exists():
                _ARTEFACT_PUSH_STATE["pending"] = False
                return False
            remote_r = run_hidden(["git", "remote", "get-url", "origin"],
                                      capture_output=True, text=True,
                                      cwd=str(repo), timeout=15)
            if remote_r.returncode != 0:
                # Remote optional in solo mode (plan §3.5) — local commits are
                # the durable record; nothing to push, not an error.
                _ARTEFACT_PUSH_STATE["pending"] = False
                return False
            branch_r = run_hidden(["git", "rev-parse", "--abbrev-ref", "HEAD"],
                                      capture_output=True, text=True,
                                      cwd=str(repo), timeout=15)
            branch = (branch_r.stdout or "").strip()
            if branch_r.returncode != 0 or not branch or branch == "HEAD":
                _ARTEFACT_PUSH_STATE["pending"] = False
                return False
            push_r = run_hidden(["git", "push", "origin", branch],
                                    capture_output=True, text=True,
                                    cwd=str(repo), timeout=120)
            if push_r.returncode == 0:
                _ARTEFACT_PUSH_STATE["pending"] = False
                _ARTEFACT_PUSH_STATE["last_push"] = time.monotonic()
                _ARTEFACT_PUSH_STATE["backoff"] = 0.0
                _ARTEFACT_PUSH_STATE["not_before"] = 0.0
                _clear_artefact_push_escalation(branch)
                write_lifecycle_event(
                    "ARTEFACT_PUSH",
                    f"artefact repo pushed to origin/{branch} (debounced, FTR-0366)")
                return True
            # Fail-open with backoff — never block dispatch on the remote.
            backoff = min(max(_ARTEFACT_PUSH_STATE["backoff"] * 2, 30.0), 600.0)
            _ARTEFACT_PUSH_STATE["backoff"] = backoff
            _ARTEFACT_PUSH_STATE["not_before"] = time.monotonic() + backoff
            write_lifecycle_event(
                "WARN",
                f"artefact repo push to origin/{branch} failed — retrying in "
                f"{int(backoff)}s (fail-open, FTR-0366): "
                f"{(push_r.stderr or push_r.stdout or '').strip()[:300]}")
            _handle_artefact_push_escalation(repo, branch)
            return False
        except Exception as exc:
            backoff = min(max(_ARTEFACT_PUSH_STATE["backoff"] * 2, 30.0), 600.0)
            _ARTEFACT_PUSH_STATE["backoff"] = backoff
            _ARTEFACT_PUSH_STATE["not_before"] = time.monotonic() + backoff
            try:
                write_lifecycle_event(
                    "WARN",
                    f"artefact repo push errored — retrying in {int(backoff)}s "
                    f"(fail-open, FTR-0366): {exc}")
            except Exception:
                pass
            try:
                _handle_artefact_push_escalation(
                    locals().get("repo") or get_artefact_repo_root(),
                    locals().get("branch") or "HEAD")
            except Exception:
                pass
            return False


# ---------------------------------------------------------------------------
# BUG-MSO-2026-0548: escalate sustained artefact-plane push divergence beyond
# a repeating WARN — see maestro/core/artefact_divergence.py for the full
# rationale and threshold defaults. The push above stays fail-open; this only
# adds a louder, status-visible signal once the failure looks sustained
# rather than a transient blip.
# ---------------------------------------------------------------------------

def _handle_artefact_push_escalation(repo: Path, branch: str) -> None:
    from maestro.core import artefact_divergence

    fail_count = _ARTEFACT_PUSH_STATE.get("fail_count", 0) + 1
    _ARTEFACT_PUSH_STATE["fail_count"] = fail_count

    artefact_root = get_artefact_root()
    cfg = artefact_divergence.load_divergence_config(artefact_root)
    counts = artefact_divergence.measure_divergence(repo, branch)
    behind, ahead = counts if counts is not None else (None, None)
    size = max(ahead or 0, behind or 0)

    should_escalate = (
        fail_count >= cfg["divergenceRetryThreshold"]
        or (counts is not None and size >= cfg["divergenceCommitThreshold"])
    )

    detail = (
        f"{ahead} ahead / {behind} behind origin/{branch}"
        if counts is not None else "divergence size unknown (offline or fetch failed)"
    ) + f"; {fail_count} consecutive push failure(s)"

    artefact_divergence.write_divergence_state(
        artefact_root,
        diverged=should_escalate,
        aheadCount=ahead,
        behindCount=behind,
        failCount=fail_count,
        detail=detail,
        resolveCommand=artefact_divergence.resolve_command(repo, branch),
    )

    if should_escalate and not _ARTEFACT_PUSH_STATE.get("escalated"):
        _ARTEFACT_PUSH_STATE["escalated"] = True
        write_lifecycle_event(
            "ARTEFACT_PLANE_DIVERGED",
            artefact_divergence.build_escalation_message(branch, fail_count, ahead, behind, repo))


def _clear_artefact_push_escalation(branch: str) -> None:
    from maestro.core import artefact_divergence

    was_escalated = _ARTEFACT_PUSH_STATE.get("escalated", False)
    _ARTEFACT_PUSH_STATE["fail_count"] = 0
    _ARTEFACT_PUSH_STATE["escalated"] = False
    artefact_root = get_artefact_root()
    artefact_divergence.write_divergence_state(
        artefact_root, diverged=False, aheadCount=0, behindCount=0,
        failCount=0, detail="", resolveCommand="")
    if was_escalated:
        write_lifecycle_event(
            "ARTEFACT_PUSH",
            f"artefact repo push to origin/{branch} recovered — plane divergence "
            f"cleared (BUG-MSO-2026-0548)")


# BUG-MSO-2026-0022: story-sizing ceilings (soft gate — warns, does not block)
SIZING_CEILING_FILES = 30
SIZING_CEILING_LOC = 2000
SIZING_CEILING_TOOL_CALLS = 50

# BUG-MSO-2026-0206: bound how many times an orphaned/timed-out order may be
# re-queued before escalating to STALLED (human review). Prevents the infinite
# REQUEUE loop seen on validate-only roles whose hung crew committed nothing.
MAX_REQUEUES = 2

# BUG-MSO-2026-0460 (GitHub #314): registry of every function in this module
# that writes an order's status back to PENDING. THIS IS THE AUDIT deliverable
# — WORKTREE_REQUIRED (this bug), SEC_ARTEFACT_MISSING (BUG-0444), and a
# NETWORK-misclassified wall-clock timeout (BUG-0435) were each independently
# discovered to release an order back to PENDING without ever touching
# requeueCount, so a chronically-failing order cycled CLAIM -> HOLD ->
# RELEASED -> CLAIM forever with no ceiling and no escalation. Three separate
# escapes of the same safety valve means the pattern was the problem, not any
# one call site — so every PENDING-status write in this module is classified
# here as either BUDGETED (consumes the shared MAX_REQUEUES/requeueCount
# ceiling, or its own dedicated bounded counter) or EXEMPT (not a
# failure-retry loop at all — a successful advance, a first-time queue, a
# human-gated pause, or a terminal park that requires explicit `mso order
# retry`). test_bug_0460_worktree_requeue_budget.py statically parses this
# file and fails if a NEW PENDING-status write appears in a function not
# listed here, so a fourth silent escape cannot be reintroduced.
REQUEUE_PATH_AUDIT: Dict[str, str] = {
    # --- BUDGETED: consumes MAX_REQUEUES / requeueCount --------------------
    "hold_order_worktree_required": (
        "BUDGETED (BUG-MSO-2026-0460) — increments requeueCount on every "
        "WORKTREE_REQUIRED hold; escalates to STALLED via "
        "_stall_worktree_required() at MAX_REQUEUES."
    ),
    "_hold_missing_sec_artefact": (
        "BUDGETED (BUG-MSO-2026-0444) — increments requeueCount on every "
        "SEC_ARTEFACT_MISSING hold; escalates to STALLED via "
        "_stall_missing_sec_artefact() at MAX_REQUEUES."
    ),
    "_hold_missing_deliverable": (
        "BUDGETED (BUG-MSO-2026-0546) — generalises _hold_missing_sec_artefact's "
        "shape to every role: increments requeueCount on every "
        "ROLE_DELIVERABLE_MISSING (or SEC_ARTEFACT_MISSING, for a SEC-family "
        "completed_role) hold; escalates to STALLED via "
        "_stall_missing_deliverable() at MAX_REQUEUES."
    ),
    "recover_orphaned_order": (
        "BUDGETED (BUG-MSO-2026-0206) — the CRASHED/ERROR/TIMEOUT/MAX_TURNS/"
        "CODE requeue path increments requeueCount and escalates to STALLED "
        "via archive_stalled_order() at MAX_REQUEUES. Contains three "
        "sibling branches in the SAME function that do NOT touch "
        "requeueCount, each independently exempt: reason=='NETWORK' "
        "(FTR-MSO-2026-0359 — infrastructure fault, not the order's fault; "
        "tracked on its own bounded networkRetry.count/networkRetryMax "
        "counter with its own STALLED escalation) and the three "
        "REQUEUE_ABORTED branches (file-not-in-queues / status-changed / "
        "dep-unsatisfied) — these REFUSE to re-dispatch under the same "
        "conditions rather than retrying a failure, so spending the budget "
        "would be wrong, not merely superfluous."
    ),
    # --- EXEMPT: not a failure-retry loop -----------------------------------
    "_auto_serialize_order": (
        "EXEMPT — content-conflict requeue (FTR-MSO-2026-0267) has its own "
        "dedicated, bounded counter (serializeCount / _AUTO_SERIALIZE_CAP=1); "
        "falls through to the terminal (non-retrying) CONVERGENCE_FAILED "
        "park via _record_convergence_failure once exceeded."
    ),
    "_requeue_for_convergence_retry": (
        "EXEMPT — convergence-network requeue (BUG-MSO-2026-0268) has its "
        "own dedicated, bounded counter (convergenceRetryCount / "
        "_CONVERGENCE_RETRY_CAP=3); falls through to the terminal "
        "CONVERGENCE_FAILED park once exceeded."
    ),
    "_tick_nav_review_auto_approve": (
        "EXEMPT — releases a human-review pause (NAV_REVIEW_PENDING) after "
        "a configured timeout. Not failure recovery: the order never failed, "
        "a human simply didn't act within the policy window."
    ),
    "auto_queue_unblocked_orders": (
        "EXEMPT — queues an order for its FIRST dispatch attempt once its "
        "dependsOn set becomes satisfied. Zero prior attempts; not a retry."
    ),
    "reconcile_stranded_dependents": (
        "EXEMPT — same as auto_queue_unblocked_orders (BUG-MSO-2026-0280 "
        "self-heal sweep for a dependent whose original auto-queue event "
        "didn't fire): first-time queuing, not a retry."
    ),
    "promote_ready_dependents": (
        "EXEMPT (BUG-MSO-2026-0499) — releases a PROPOSED/HELD order that "
        "lives in queues/* back to PENDING once its dependsOn set is fully "
        "satisfied. Same class as auto_queue_unblocked_orders and "
        "reconcile_stranded_dependents: the order has made ZERO prior "
        "dispatch attempts and nothing about it failed — it was simply "
        "invisible to scan_all_queues while gated. Spending requeueCount "
        "here would charge a retry budget against work that never ran."
    ),
    "complete_order": (
        "EXEMPT — the PENDING writes here are the ADVANCE transitions: a "
        "role SUCCEEDED and the order moves to the next role in its "
        "roleSequence. Successful progression, not failure recovery."
    ),
    "reset_orphaned_in_progress_orders": (
        "EXEMPT (reviewed BUG-MSO-2026-0460) — periodic (v8.7, every tick) "
        "self-heal for an order stuck IN_PROGRESS with no live crew tracked "
        "(dispatcher restart, or a crew death that bypassed the normal "
        "recover_orphaned_order exit handling). This is dispatcher/process-"
        "level orphan recovery, not a per-order failure-retry loop: in every "
        "documented incident (BUG-0018/0222/0226/0353) it fires once per "
        "actual crash/restart, and the order's NEXT dispatch attempt is "
        "protected by the BUDGETED paths above. Gating it behind "
        "MAX_REQUEUES would risk STALLING healthy orders after ordinary "
        "dispatcher restarts — a worse regression than the bug this audit "
        "closes. If future evidence shows a SINGLE order repeatedly "
        "orphaning here without ever reaching a budgeted path, that is a "
        "new, distinct bug (the crew-launch path silently failing before "
        "any exit status is observed), not a requeueCount gap."
    ),
}

# ---------------------------------------------------------------------------
# FTR-MSO-2026-0359: offline dispatch gate (OFFLINE_HOLD / OFFLINE_RECOVERED)
# ---------------------------------------------------------------------------
# Zero-cost in normal operation: no probe ever runs until a NETWORK-classified
# failure (crew death or ConvergenceNetworkError) arms the suspect flag. While
# holding, probes are rate-limited with exponential backoff (30s -> 5m cap).
# Running crews are NEVER touched by this gate — they may ride the blip out
# inside their own Claude sessions (2 of 3 crews did exactly that on
# 2026-07-14); the gate only withholds NEW dispatches.
_NET_SUSPECT = False                       # probe before the next dispatch
_NET_SUSPECT_DETAIL = ""                   # what armed the suspicion
_OFFLINE_HOLD = False                      # probes failing — dispatch held
_OFFLINE_SINCE: Optional[datetime] = None
_NEXT_PROBE_AT: Optional[datetime] = None  # backoff-scheduled next probe
_PROBE_BACKOFF_SECONDS = 30                # doubles per failed probe, cap 300


def _note_network_suspect(detail: str = "") -> None:
    """Arm the offline gate: a NETWORK-classified failure was just observed."""
    global _NET_SUSPECT, _NET_SUSPECT_DETAIL
    _NET_SUSPECT = True
    if detail:
        _NET_SUSPECT_DETAIL = detail


def _offline_gate_allows_dispatch(active_crews: int = 0) -> bool:
    """FTR-MSO-2026-0359: may the dispatcher launch a NEW crew right now?

    Returns True (allow) unless a network suspicion/hold is active AND the
    connectivity probe says we are offline. Emits OFFLINE_HOLD on the
    online->offline transition and OFFLINE_RECOVERED on recovery; mirrors the
    verdict into .mso/state/connectivity.json for `mso status`. Never kills
    running crews. Disabled entirely by `resilience.connectivityGate: false`.
    """
    global _NET_SUSPECT, _NET_SUSPECT_DETAIL, _OFFLINE_HOLD, _OFFLINE_SINCE, \
        _NEXT_PROBE_AT, _PROBE_BACKOFF_SECONDS

    if not (_NET_SUSPECT or _OFFLINE_HOLD):
        return True  # normal operation — no probe, no cost

    from maestro.core import connectivity

    ws = get_artefact_root()
    cfg = connectivity.load_resilience_config(ws)
    if not cfg.get("connectivityGate", True):
        # Kill-switch (airgapped/proxy setups): never probe, never hold.
        _NET_SUSPECT = False
        _OFFLINE_HOLD = False
        return True

    now = datetime.now()
    if _OFFLINE_HOLD and _NEXT_PROBE_AT and now < _NEXT_PROBE_AT:
        return False  # held; next probe not due yet (backoff, no probe spam)

    # While holding, bypass the probe cache — the whole point is to detect
    # recovery; the first (suspect) probe may use a fresh-enough cached verdict.
    probe = connectivity.probe_connectivity(ws, force=_OFFLINE_HOLD)

    if probe["online"]:
        if _OFFLINE_HOLD:
            _mins = ((now - _OFFLINE_SINCE).total_seconds() / 60.0) if _OFFLINE_SINCE else 0.0
            write_lifecycle_event(
                "OFFLINE_RECOVERED",
                f"connectivity restored after {_mins:.1f}m offline — dispatch resumed "
                f"({probe['detail']})"
            )
            print_ok(f"Connectivity restored ({probe['detail']}) — dispatch resumed.")
        _NET_SUSPECT = False
        _NET_SUSPECT_DETAIL = ""
        _OFFLINE_HOLD = False
        _OFFLINE_SINCE = None
        _NEXT_PROBE_AT = None
        _PROBE_BACKOFF_SECONDS = 30
        connectivity.write_connectivity_state(
            ws, online=True, holdActive=False, offlineSince=None,
            detail=probe["detail"], crewsRiding=active_crews,
        )
        return True

    # Offline.
    if not _OFFLINE_HOLD:
        _OFFLINE_HOLD = True
        _OFFLINE_SINCE = now
        write_lifecycle_event(
            "OFFLINE_HOLD",
            f"connectivity probe failed — HOLDING new dispatches; {active_crews} "
            f"running crew(s) left to ride it out. Trigger: {_NET_SUSPECT_DETAIL or 'probe'}. "
            f"Probe: {probe['detail']}"
        )
        print_warn(
            f"OFFLINE — dispatch held ({probe['detail']}); "
            f"{active_crews} running crew(s) untouched."
        )
    _NEXT_PROBE_AT = now + timedelta(seconds=_PROBE_BACKOFF_SECONDS)
    _PROBE_BACKOFF_SECONDS = min(_PROBE_BACKOFF_SECONDS * 2, 300)
    connectivity.write_connectivity_state(
        ws, online=False, holdActive=True,
        offlineSince=_OFFLINE_SINCE.isoformat() if _OFFLINE_SINCE else None,
        detail=probe["detail"], crewsRiding=active_crews,
    )
    return False


# FTR-MSO-2026-0452 (PLAN-PLN-MSO-2026-0450 §D3b-i): a STOPPED licence
# (Team/Enterprise past its 14-day grace) must drain the fleet, not kill it.
# `True` once a hold is active, so the HOLD/RECOVERED lifecycle events fire
# only on the transition, mirroring `_OFFLINE_HOLD`.
_LICENCE_STOP_HOLD = False


def _licence_gate_allows_dispatch(active_crews: int) -> bool:
    """May the dispatcher launch a NEW crew right now?

    Never touches a running crew — a STOPPED licence only withholds NEW
    dispatch (draining, not killing; same contract as
    `_offline_gate_allows_dispatch`). Once the fleet has genuinely drained
    (no active AND no draining crews left), the dispatcher exits through the
    SAME `SHUTDOWN_REQUESTED` flag/loop the idle-watchdog already uses
    (`run_dispatcher`'s `while not SHUTDOWN_REQUESTED` + the idle-reap
    block above) — reusing that exit path rather than inventing a second
    one, per the order's explicit instruction.
    """
    global _LICENCE_STOP_HOLD, SHUTDOWN_REQUESTED
    from maestro import auth as _auth

    allowed, reason = _auth.licence_dispatch_gate()
    if allowed:
        if _LICENCE_STOP_HOLD:
            _LICENCE_STOP_HOLD = False
            write_lifecycle_event("LICENCE_STOP_RECOVERED", "licence gate cleared — dispatch resumed")
            print_ok("Licence restored — dispatch resumed.")
        return True

    if not _LICENCE_STOP_HOLD:
        _LICENCE_STOP_HOLD = True
        write_lifecycle_event(
            "LICENCE_STOP_HOLD",
            f"{reason} — HOLDING new dispatches; {active_crews} running crew(s) "
            "left to drain untouched."
        )
        print_warn(f"LICENCE STOPPED — dispatch held; {active_crews} running crew(s) draining, untouched.")

    if active_crews == 0 and not DRAINING_PROCESSES:
        write_lifecycle_event(
            "LICENCE_STOP_REAP",
            "fleet fully drained under a stopped licence — stopping the dispatcher "
            "(reusing the idle-watchdog SHUTDOWN_REQUESTED exit path, FTR-0452)"
        )
        SHUTDOWN_REQUESTED = True

    return False


def _report_licence_keyring_warning() -> None:
    """BUG-MSO-2026-0503: a community downgrade the operator didn't expect
    (most concretely: the vendor licence keyring — maestro/licence/keys.py —
    came back empty after a `pip install .` runtime refresh wiped it, so a
    previously-activated token no longer verifies) must never be silent.
    ``auth.resolve_state()`` already computes a ``.warning`` for this; the
    only gap was that nothing printed it outside `mso licence status`.

    Called once at dispatcher startup (mirrors the FTR-MSO-2026-0505
    community-crew-cap warning immediately above its call site), not every
    tick — a per-tick print would just be noise once an operator has seen it.
    """
    from maestro import auth as _auth
    licence_warning = _auth.licence_keyring_warning()
    if licence_warning:
        print_warn(licence_warning)
        write_lifecycle_event("LICENCE_WARNING", licence_warning)


def _network_backoff_active(data: Dict[str, Any]) -> bool:
    """FTR-MSO-2026-0359: is this order inside its network-retry backoff window?

    Orders re-queued after a NETWORK failure carry networkRetry.backoffUntil;
    scan_all_queues skips them until the window passes (1m/5m/15m schedule) so
    a fresh crew is not launched straight back into a live outage.
    """
    until = (data.get("networkRetry") or {}).get("backoffUntil")
    if not until:
        return False
    try:
        return datetime.now() < datetime.fromisoformat(until)
    except (TypeError, ValueError):
        return False

# BUG-MSO-2026-0024: Eight Bells must wait out a grace window after the most
# recent order COMPLETE/STALLED archive before firing. The BUG-0017 fix only
# covered ADVANCE->DISPATCH transitions (ORDERS_IN_TRANSITION); it missed the
# COMPLETE->DISPATCH case where an archived order freshly unblocks a dependent
# the dispatcher hasn't re-scanned yet (~3-10s gap). The grace window closes
# that race. Override with MAESTRO_EIGHT_BELLS_GRACE_SECONDS.
EIGHT_BELLS_GRACE_SECONDS = 30


def parse_plan_sizing(plan_path: "Path") -> dict:
    """Extract declared sizing estimates from a PLN/NAV plan or handoff file.

    Looks for lines matching:
        Estimated files changed: N
        Estimated LoC changed: N
        Estimated Edit/Write tool calls: N

    Returns a dict with keys 'files', 'loc', 'tool_calls' (int or None if not found).
    """
    import re
    result = {"files": None, "loc": None, "tool_calls": None}
    if plan_path is None or not plan_path.exists():
        return result
    try:
        text = plan_path.read_text(encoding="utf-8")
    except Exception:
        return result

    patterns = [
        ("files", r"Estimated files changed:\s*(\d+)"),
        ("loc", r"Estimated LoC changed:\s*(\d+)"),
        ("tool_calls", r"Estimated Edit/Write tool calls:\s*(\d+)"),
    ]
    for key, pat in patterns:
        m = re.search(pat, text, re.IGNORECASE)
        if m:
            result[key] = int(m.group(1))
    return result


def check_plan_sizing(order_id: str, workspace_dir: "Path") -> list:
    """Check all plan/handoff files for an order against sizing ceilings.

    Returns a list of warning strings (empty if all ceilings satisfied or no
    sizing data found). Emits OVERSIZED_STORY lifecycle events for each breach.
    """
    import glob as _glob
    warnings = []
    plans_dir = workspace_dir / "plans"
    handoffs_dir = workspace_dir / "handoffs" / order_id

    candidate_paths = []
    for d in [plans_dir, handoffs_dir]:
        if d.exists():
            candidate_paths.extend(d.glob("*.md"))

    sizing: dict = {"files": None, "loc": None, "tool_calls": None}
    for path in candidate_paths:
        found = parse_plan_sizing(path)
        for k in sizing:
            if found[k] is not None:
                sizing[k] = found[k]

    ceilings = [
        ("files", SIZING_CEILING_FILES, "files changed"),
        ("loc", SIZING_CEILING_LOC, "LoC changed"),
        ("tool_calls", SIZING_CEILING_TOOL_CALLS, "Edit/Write tool calls"),
    ]
    for key, ceil, label in ceilings:
        val = sizing[key]
        if val is not None and val > ceil:
            msg = (
                f"{order_id} plan estimates {val} {label} "
                f"(ceiling: {ceil}) — PLN must decompose into sub-stories"
            )
            warnings.append(msg)
            write_lifecycle_event("OVERSIZED_STORY", msg)

    return warnings


# =============================================================================
# PRE-FLIGHT CHECKS
# =============================================================================

def _spawn_marker() -> str:
    """BUG-MSO-2026-0302: stable per-workspace marker for spawned process trees."""
    import hashlib
    ws = str(get_artefact_root()).lower().encode("utf-8", errors="replace")
    return f"mso-spawn-{hashlib.sha1(ws).hexdigest()[:12]}"


def sweep_marked_orphans() -> tuple:
    """BUG-MSO-2026-0302 (GKT: PID 28048 survived every cleanup): find and kill
    crew-descended processes that no PID file references.

    The PID-file reaper cannot reach a grandchild whose parent already died
    (taskkill /T needs a live tree root). This sweep enumerates processes
    whose CommandLine carries this workspace's spawn marker (stamped onto
    crew.py argv at launch) and kills them, then VERIFIES and reports any
    survivors loudly. Children that don't inherit the marker on their own
    command line (e.g. claude's node descendants) remain a known limitation —
    Windows Job Objects are the structural fix (documented in the order).

    Returns (reaped_pids, survivor_pids).
    """
    marker = _spawn_marker()
    my_pid = os.getpid()

    def _find() -> list:
        try:
            if os.name == "nt":
                # $PID/-notlike guards: the enumerating PowerShell's OWN command
                # line contains the marker — without exclusion the sweep finds
                # itself and reports a phantom survivor forever.
                ps = (
                    "Get-CimInstance Win32_Process | "
                    f"Where-Object {{ $_.CommandLine -like '*{marker}*' "
                    f"-and $_.ProcessId -ne $PID "
                    f"-and $_.CommandLine -notlike '*Get-CimInstance*' }} | "
                    "Select-Object -ExpandProperty ProcessId"
                )
                r = run_hidden(["powershell", "-NoProfile", "-Command", ps],
                                   capture_output=True, text=True, timeout=30)
            else:
                r = run_hidden(["pgrep", "-f", marker],
                                   capture_output=True, text=True, timeout=30)
            pids = []
            for line in (r.stdout or "").splitlines():
                line = line.strip()
                if line.isdigit() and int(line) != my_pid:
                    pids.append(int(line))
            return pids
        except Exception:
            return []

    targets = _find()
    for pid in targets:
        try:
            if os.name == "nt":
                run_hidden(["taskkill", "/F", "/T", "/PID", str(pid)],
                               capture_output=True, timeout=10)
            else:
                os.kill(pid, 9)
        except Exception:
            pass

    # taskkill returns before the process fully tears down — poll briefly
    # so a normal kill isn't misreported as a survivor.
    survivors = []
    if targets:
        for _ in range(6):
            time.sleep(0.5)
            survivors = _find()
            if not survivors:
                break
    if survivors:
        write_lifecycle_event(
            "WARN",
            f"cleanup orphan sweep: {len(survivors)} marked process(es) SURVIVED "
            f"kill — PIDs {survivors}. Kill manually and report (BUG-0302)."
        )
    elif targets:
        write_lifecycle_event(
            "DISPATCH",
            f"cleanup orphan sweep reaped {len(targets)} marked process(es): {targets} (BUG-0302)"
        )
    return targets, survivors


def reap_crew_job_objects() -> dict:
    """BUG-MSO-2026-0500: kill every process still tracked under each crew
    slot's descendant group — the general fix for orphaned crew descendants
    of ANY kind (find, MSBuild, VBCSCompiler, shells, ...), not just the
    marker-on-commandline class `sweep_marked_orphans` catches.

    Windows: reopens each crew slot's named Job Object (crew.py assigns its
    Claude subprocess — and transitively everything IT spawns — to this job
    at launch; see maestro.core.descendant_reaper). In the common case the
    job is already gone by the time this runs, because JOB_OBJECT_LIMIT_
    KILL_ON_JOB_CLOSE already destroyed it (and everything in it) the instant
    the owning crew.py process's handle closed — including on a crash. This
    is a backstop for whatever slips past that: a race before assignment, a
    duplicated/inherited handle keeping the job alive, or a pre-fix orphan.

    POSIX: reads each crew slot's persisted process-group id and kills the
    whole group — pgid membership, like job membership, survives the
    original leader's death.

    Every crew slot 1-5 is swept unconditionally (this command already
    force-kills every crew.py PID unconditionally — it's a stop-the-fleet
    operation, not a "tidy only what's provably dead" one). Returns
    {crew_number: [pids]} for slots that had something to reap.
    """
    from maestro.core import descendant_reaper
    marker = descendant_reaper.workspace_marker(get_artefact_root())
    reaped = descendant_reaper.sweep_all(get_crew_dir, marker, max_crews=5)
    if reaped:
        write_lifecycle_event(
            "DISPATCH",
            f"cleanup descendant reap: {sum(len(v) for v in reaped.values())} "
            f"process(es) across {len(reaped)} crew slot(s): {reaped} (BUG-0500)"
        )
    return reaped


# BUG-MSO-2026-0304: runtime dirs that must never be git-tracked. They are in
# the gitignore block, but git only honours gitignore for UNTRACKED files — a
# force-add (git add -f) or a pre-gitignore commit makes them tracked-and-live,
# and the dispatcher's per-tick writes to them then dirty the convergence blast
# radius (progress.md add/add conflicts -> AUTO_SERIALIZE cascade, PSG retest).
_RUNTIME_DIRS = ("crews", "logs", "state", "bridge", "temp", "prompts/active",
                 "worktrees")


def untrack_gitignored_runtime_paths() -> int:
    """Detect + `git rm --cached` any tracked-but-gitignored runtime path.

    Runs at dispatcher startup and in `mso cleanup`. Removes the paths from the
    git index (keeping the files on disk) so they stop participating in
    convergence merges, then commits the untrack when lifecycle.commitTransitions
    is on. Best-effort / fail-open — never blocks dispatch. Returns the count of
    paths untracked.

    FTR-MSO-2026-0366: targets the repo carrying the artefact plane — the
    product repo in embedded mode (unchanged), the artefact repo in
    solo/shared mode (runtime dirs live gitignored INSIDE the artefact repo
    checkout; BUG-0304 never-force-add applies there identically).
    """
    try:
        base = get_artefact_repo_root()
        if not (base / ".git").exists():
            return 0
    except Exception:
        return 0

    untracked = []
    for rel in _RUNTIME_DIRS:
        pathspec = f"{MSO_DIR_NAME}/{rel}"
        try:
            ls = run_hidden(["git", "ls-files", "--error-unmatch", pathspec],
                                capture_output=True, text=True, cwd=str(base), timeout=15)
        except Exception:
            continue
        # ls-files lists tracked files under the pathspec; empty => nothing tracked.
        tracked = [ln for ln in (ls.stdout or "").splitlines() if ln.strip()]
        if not tracked:
            continue
        rm = run_hidden(["git", "rm", "-r", "--cached", "--quiet", pathspec],
                            capture_output=True, text=True, cwd=str(base), timeout=30)
        if rm.returncode == 0:
            untracked.append((pathspec, len(tracked)))

    if not untracked:
        return 0

    names = ", ".join(f"{p} ({n})" for p, n in untracked)
    write_lifecycle_event(
        "WARN",
        f"untracked {len(untracked)} force-added gitignored runtime path(s) from the "
        f"git index: {names} — they were dirtying convergence (BUG-0304). Files kept on disk."
    )
    try:
        if _lifecycle_commit_enabled():
            run_hidden(
                ["git", "commit", "-m",
                 "chore: untrack gitignored runtime dirs from index (BUG-MSO-2026-0304)"],
                capture_output=True, text=True, cwd=str(base), timeout=15)
    except Exception:
        pass
    return len(untracked)


def ensure_artefact_repo_gitignore() -> bool:
    """FTR-MSO-2026-0366: self-heal the runtime gitignore block in the
    artefact repo (solo/shared mode only).

    The artefact repo checkout hosts the machine-local runtime plane
    (crews/, logs/, state/ — incl. the BUG-0294 ledger, temp/, worktrees/,
    pids); its git-immunity invariant depends on the canonical runtime
    block being present in the artefact repo's ``.gitignore``. `mso migrate
    artefact-repo` writes it at provision time; this startup self-heal keeps
    it intact (same idempotent normaliser `mso init`/`mso update` use).
    Embedded mode: no-op — the product repo's gitignore is init/update's
    responsibility, unchanged. Returns True when the file was (re)written.
    """
    if get_artefact_mode() == "embedded":
        return False
    try:
        from maestro.init import GITIGNORE_ADDITIONS, ensure_maestro_gitignore_block
        repo = get_artefact_repo_root()
        if not (repo / ".git").exists():
            return False
        gi = repo / ".gitignore"
        content = gi.read_text(encoding="utf-8") if gi.exists() else ""
        healed = ensure_maestro_gitignore_block(content) if content else GITIGNORE_ADDITIONS
        if healed != content:
            gi.write_text(healed, encoding="utf-8")
            write_lifecycle_event(
                "WARN",
                "artefact repo .gitignore runtime block was missing/stale — "
                "self-healed so the runtime plane (state/ ledger, crews/, logs/) "
                "stays git-immune (FTR-0366)")
            return True
        return False
    except Exception:
        return False


def preflight_kill_rogue_processes() -> int:
    """Kill rogue crew.py and fleet-runner.py processes from previous runs.

    Uses PID-based approach (fast, reliable) from pid.txt files and fleet state.
    Does NOT use wmic commandline matching (slow, can hang on Git Bash).
    IMPORTANT: Does NOT kill the CURRENT fleet-runner process.
    """
    killed = 0
    my_pid = os.getpid()

    if os.name == 'nt':
        # 1. Kill old dispatcher by PID lock
        dispatcher_lock = get_artefact_root() / "dispatcher.pid"
        if dispatcher_lock.exists():
            try:
                pid = int(dispatcher_lock.read_text(encoding='utf-8').strip())
                if pid != my_pid:
                    run_hidden(['taskkill', '/F', '/T', '/PID', str(pid)],
                                 capture_output=True, timeout=5)
                    killed += 1
                dispatcher_lock.unlink()
            except:
                pass

        # 2. Kill an orphaned live monitor (BUG-MSO-2026-0403) and clean stale locks
        if _kill_orphaned_monitor():
            killed += 1

        # 3. Kill by PID files in crew directories
        for crew_num in range(1, 6):
            pid = read_crew_pid(crew_num)
            if pid and pid != my_pid:
                try:
                    run_hidden(['taskkill', '/F', '/T', '/PID', str(pid)],
                                 capture_output=True, timeout=5)
                    killed += 1
                except:
                    pass

        # 4. Kill by fleet state file (catches tracked crews)
        fleet_state = get_artefact_root() / "fleet-runner-state.json"
        if fleet_state.exists():
            try:
                state = json.loads(fleet_state.read_text(encoding='utf-8'))
                for crew_num, pid in state.get("pids", {}).items():
                    if int(pid) != my_pid:
                        try:
                            run_hidden(['taskkill', '/F', '/T', '/PID', str(pid)],
                                         capture_output=True, timeout=5)
                            killed += 1
                        except:
                            pass
            except:
                pass

    return killed

def preflight_clear_stale_states(preserve_complete: bool = False) -> int:
    """Clear stale state files from crew directories.

    Args:
        preserve_complete: If True, don't clear COMPLETE status states (for --continue mode)
    """
    cleared = 0

    for crew_num in range(1, 6):
        crew_dir = get_crew_dir(crew_num)
        if crew_dir.exists():
            # Clear state.json
            state_file = crew_dir / "state.json"
            if state_file.exists():
                should_clear = True

                # In continue mode, preserve COMPLETE states
                if preserve_complete:
                    try:
                        state = json.loads(state_file.read_text(encoding='utf-8'))
                        if state.get("status") == "COMPLETE":
                            should_clear = False
                            print_info(f"Preserving Crew {crew_num} COMPLETE state")
                    except:
                        pass

                if should_clear:
                    try:
                        state_file.unlink()
                        cleared += 1
                    except:
                        pass

            # v8.9: Clear ralph-state.md (prevents stale COMPLETE detection on re-dispatch)
            ralph_file = crew_dir / "ralph-state.md"
            if ralph_file.exists():
                should_clear_ralph = True
                if preserve_complete:
                    try:
                        content = ralph_file.read_text(encoding='utf-8')
                        if "status: \"COMPLETE\"" in content:
                            should_clear_ralph = False
                    except:
                        pass
                if should_clear_ralph:
                    try:
                        ralph_file.unlink()
                        cleared += 1
                    except:
                        pass

            # Clear any lock files
            for lock_file in crew_dir.glob("*.lock"):
                try:
                    lock_file.unlink()
                except:
                    pass

    # Clear fleet state file
    fleet_state = get_artefact_root() / "fleet-runner-state.json"
    if fleet_state.exists():
        try:
            fleet_state.unlink()
            cleared += 1
        except:
            pass

    return cleared


def reset_orphaned_in_progress_orders() -> int:
    """Reset orphaned IN_PROGRESS orders back to PENDING (v8.2).

    After cleanup kills crew processes, orders they were working on remain
    stuck as IN_PROGRESS in the queues. This scans all queue directories
    and resets any IN_PROGRESS order whose assigned crew is no longer alive.
    """
    reset_count = 0
    queues_dir = get_queues_dir()

    if not queues_dir.exists():
        return 0

    for queue_subdir in queues_dir.iterdir():
        if not queue_subdir.is_dir():
            continue
        # Scan this tier's own *.json AND one level deeper (e.g. requests/<category>/*.json)
        # so checkpoint-based finalization resume works for nested subqueues too — matching
        # the requests-subdir search in recover_orphaned_order(). Completed-bug archives under
        # tiers like bugs/complete/ are caught by the */*.json pass but skipped by the
        # IN_PROGRESS guard below, so the wider scan is harmless.
        candidate_files = list(queue_subdir.glob("*.json")) + list(queue_subdir.glob("*/*.json"))
        for json_file in candidate_files:
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                if data.get("status") != "IN_PROGRESS":
                    continue

                # Check if assigned crew is still alive
                assigned = data.get("assignedTo", {})
                crew_num = assigned.get("crew")
                crew_alive = False

                if crew_num:
                    # Module-level tracking is authoritative — includes draining crews
                    # whose process may already be dead but whose order is still valid
                    if crew_num in ACTIVE_PROCESSES or crew_num in DRAINING_PROCESSES:
                        crew_alive = True
                    else:
                        pid = read_crew_pid(crew_num)
                        if pid and is_process_alive(pid):
                            crew_alive = True

                if not crew_alive:
                    order_id = data.get("orderId") or data.get("id") or json_file.stem

                    # BUG-MSO-2026-0353: a stale IN_PROGRESS queue copy whose order is
                    # ALSO parked in queues/review/ (NAV_REVIEW_PENDING) is a duplicate of
                    # an already-advanced order — the review/ copy is authoritative. The
                    # BUG-0219 guard in complete_order() early-returns on the review/ copy
                    # WITHOUT clearing this orphan, so the finalization-resume path below
                    # re-finds it every periodic tick -> a FINALIZE / "already held" / reset
                    # livelock that stalls the dispatcher (never reaching Eight Bells) after
                    # all real work is done (observed: VOY-0090's INV-0338/0339 stalling the
                    # VOY-0092 run). Remove the redundant orphan, release its ledger claim,
                    # and skip — the review gate still holds the authoritative copy.
                    review_copy = get_artefact_root() / "queues" / "review" / f"{order_id}.json"
                    if review_copy.exists():
                        try:
                            json_file.unlink()
                        except OSError:
                            pass
                        order_ledger.record_released(
                            order_id,
                            "cleanup: stale IN_PROGRESS duplicate of review-parked order (BUG-0353)",
                            workspace_dir=get_artefact_root())
                        write_lifecycle_event(
                            "DISPATCH",
                            f"{order_id} stale IN_PROGRESS queue copy removed — order already "
                            f"parked in queues/review/ (NAV_REVIEW_PENDING); breaking "
                            f"finalization livelock (BUG-MSO-2026-0353)"
                        )
                        reset_count += 1
                        continue

                    # BUG-MSO-2026-0222: if the crew succeeded but the dispatcher
                    # crashed before finalization completed, roleSucceededAt is set.
                    # Resume finalization (advance/archive) instead of re-dispatching
                    # the same role, which would cause an infinite re-run loop.
                    succeeded_by = data.get("roleSucceededBy", {})
                    if data.get("roleSucceededAt") and succeeded_by.get("role"):
                        succeeded_role = succeeded_by["role"]
                        orig_crew = succeeded_by.get("crew", crew_num)

                        # BUG-MSO-2026-0326: if the order has ALREADY advanced past the
                        # succeeded role, finalization completed before the crash/kill but
                        # the roleSucceededAt checkpoint was never cleared. Re-running
                        # complete_order for the old role is rejected by the BUG-0248
                        # stale-advance guard WITHOUT clearing the checkpoint, so the
                        # orphan-reset re-finds it on every tick → an infinite FINALIZE/
                        # reset livelock (observed on FTR-MSO-2026-0320 after a TST timeout
                        # kill: succeeded_role=BLD but targetRole already TST). Detect the
                        # already-advanced case, clear the stale checkpoint, and fall
                        # through to the normal PENDING reset so the CURRENT role is
                        # re-dispatched instead of re-finalizing the old one.
                        role_seq = data.get("roleSequence", []) or []
                        cur_role = data.get("targetRole")
                        already_advanced = (
                            succeeded_role in role_seq and cur_role in role_seq
                            and role_seq.index(succeeded_role) < role_seq.index(cur_role)
                        )
                        if already_advanced:
                            write_lifecycle_event(
                                "FINALIZE",
                                f"{order_id} stale roleSucceededAt checkpoint for {succeeded_role} "
                                f"cleared — order already advanced to {cur_role} "
                                f"(BUG-MSO-2026-0326 livelock fix)"
                            )
                            data.pop("roleSucceededAt", None)
                            data.pop("roleSucceededBy", None)
                            # fall through to the normal PENDING reset below
                        else:
                            write_lifecycle_event(
                                "FINALIZE",
                                f"{order_id} roleSucceededAt checkpoint found for role {succeeded_role} "
                                f"(orig Crew {orig_crew}) — resuming finalization instead of re-dispatching (BUG-0222)"
                            )
                            print_info(f"Order {order_id} role {succeeded_role} already succeeded — resuming finalization")
                            crew_state_resume = {
                                "role": succeeded_role,
                                "orderId": order_id,
                                "status": "COMPLETE",
                                "iteration": data.get("iteration", 0),
                                "crew": orig_crew,
                            }
                            try:
                                complete_order(order_id, orig_crew, crew_state_resume)
                                # Mirror the normal COMPLETE finalization path: complete_order
                                # advances/archives the order but does NOT itself queue
                                # dependents, so a crash-resumed completion must also release
                                # any orders whose dependencies are now satisfied — otherwise
                                # the "self-heal" archives this order but never dispatches its
                                # dependents.
                                auto_queue_unblocked_orders(order_id)
                            except Exception as exc:
                                write_lifecycle_event(
                                    "WARN",
                                    f"{order_id} finalization resume failed: {exc} — resetting to PENDING as fallback"
                                )
                                data["status"] = "PENDING"
                                data.pop("assignedTo", None)
                                data.pop("startedAt", None)
                                data.pop("roleSucceededAt", None)
                                data.pop("roleSucceededBy", None)
                                tmp_file = json_file.with_suffix('.tmp')
                                tmp_file.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')
                                tmp_file.replace(json_file)
                            reset_count += 1
                            continue

                    # Normal path: no checkpoint — reset to PENDING for re-dispatch
                    data["status"] = "PENDING"
                    data.pop("assignedTo", None)
                    data.pop("startedAt", None)

                    # Atomic write: temp file + rename
                    tmp_file = json_file.with_suffix('.tmp')
                    tmp_file.write_text(
                        json.dumps(data, indent=2, ensure_ascii=False),
                        encoding='utf-8'
                    )
                    tmp_file.replace(json_file)

                    # BUG-MSO-2026-0298: also release the durable ledger claim —
                    # without this, a cleanup-reset order stays vetoed as
                    # in-flight until the dead pid check happens to clear it.
                    order_ledger.record_released(
                        order_id, "cleanup: orphaned IN_PROGRESS reset",
                        workspace_dir=get_artefact_root())

                    print_info(f"Reset orphaned order {order_id} -> PENDING")
                    reset_count += 1
            except Exception:
                pass

    # BUG-MSO-2026-0226 (AC-3): Scan orders/active/ for orders that have a roleSucceededAt
    # checkpoint but are no longer IN_PROGRESS and have no live crew — these are
    # partially-finalized half-advanced orders that slipped through the queue orphan scan
    # (e.g. dispatcher exited between advance write and archive step).
    active_orders_dir = get_artefact_root() / "orders" / "active"
    if active_orders_dir.exists():
        for json_file in active_orders_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                if data.get("status") == "IN_PROGRESS":
                    continue  # already handled by the queue scan above
                if not data.get("roleSucceededAt"):
                    continue  # no checkpoint — not a partial-finalization orphan

                order_id = data.get("orderId") or data.get("id") or json_file.stem
                succeeded_by = data.get("roleSucceededBy", {})
                succeeded_role = succeeded_by.get("role")
                if not succeeded_role:
                    continue

                # Confirm no live crew holds this order
                assigned = data.get("assignedTo", {})
                crew_num = assigned.get("crew")
                crew_alive = False
                if crew_num:
                    if crew_num in ACTIVE_PROCESSES or crew_num in DRAINING_PROCESSES:
                        crew_alive = True
                    else:
                        pid = read_crew_pid(crew_num)
                        if pid and is_process_alive(pid):
                            crew_alive = True
                if crew_alive:
                    continue

                orig_crew = succeeded_by.get("crew", crew_num)
                write_lifecycle_event(
                    "FINALIZE",
                    f"{order_id} half-advanced orphan in orders/active/ — roleSucceededAt "
                    f"checkpoint for role {succeeded_role} (BUG-0226 AC-3) — resuming finalization"
                )
                print_info(f"Order {order_id} half-advanced in orders/active/ — resuming finalization")
                crew_state_resume = {
                    "role": succeeded_role,
                    "orderId": order_id,
                    "status": "COMPLETE",
                    "iteration": data.get("iteration", 0),
                    "crew": orig_crew,
                }
                try:
                    complete_order(order_id, orig_crew, crew_state_resume)
                    auto_queue_unblocked_orders(order_id)
                except Exception as exc:
                    write_lifecycle_event(
                        "WARN",
                        f"{order_id} orders/active/ finalization resume failed: {exc} — resetting to PENDING as fallback"
                    )
                    data["status"] = "PENDING"
                    data.pop("assignedTo", None)
                    data.pop("startedAt", None)
                    data.pop("roleSucceededAt", None)
                    data.pop("roleSucceededBy", None)
                    tmp_file = json_file.with_suffix('.tmp')
                    tmp_file.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')
                    tmp_file.replace(json_file)
                reset_count += 1
            except Exception:
                pass

    return reset_count


def _reclaim_inflight_from_crew_state() -> int:
    """BUG-MSO-2026-0018: Reconstruct ACTIVE_PROCESSES from crew state.json on startup.

    Scans .mso/crews/crewN/state.json for crews whose status is a non-terminal
    running state and whose PID is still alive.  Repopulates ACTIVE_PROCESSES so
    the first dispatcher tick does not re-dispatch orders that are already owned
    by a live crew.

    Dead-PID crews are skipped — their orders remain eligible for fresh dispatch
    via the normal reset_orphaned_in_progress_orders() path.

    Returns the number of crews reclaimed.
    """
    reclaimed = 0
    crews_dir = get_artefact_root() / "crews"
    if not crews_dir.exists():
        return 0

    for crew_dir in sorted(crews_dir.iterdir()):
        if not crew_dir.is_dir() or not crew_dir.name.startswith("crew"):
            continue
        state_file = crew_dir / "state.json"
        if not state_file.exists():
            continue
        try:
            state = json.loads(state_file.read_text(encoding="utf-8"))
        except Exception:
            continue

        crew_num = state.get("crewNumber")
        pid = state.get("pid")
        status = state.get("status", "")
        order_id = state.get("orderId", "")

        if crew_num is None or pid is None:
            continue
        if status in TERMINAL_STATES:
            continue
        if not is_process_alive(pid):
            continue

        # Live crew with non-terminal status — reclaim it
        ACTIVE_PROCESSES[crew_num] = pid
        print_info(f"[reclaim] Crew {crew_num} (PID {pid}) reclaimed for {order_id} ({status})")
        reclaimed += 1

    return reclaimed


def preflight_verify_crew_dirs():
    """Ensure crew directories exist."""
    for crew_num in range(1, 6):
        crew_dir = get_crew_dir(crew_num)
        crew_dir.mkdir(parents=True, exist_ok=True)

# Legacy manifest mode removed in v2.0.4 — use --dispatch (queue-based) instead


# =============================================================================
# VOYAGE BRANCH MANAGEMENT
# =============================================================================

# Track which repos we've already verified/created branches for (avoid repeated API calls)
_VERIFIED_VOYAGE_BRANCHES: set = set()

# BUG-ADM-2026-0007: per-(repo,branch) failure cache so a missing-default-branch
# or auth-failure doesn't trigger a `gh api` storm on every dispatcher loop.
# Maps cache_key -> last_error_message for diagnostics.
_FAILED_VOYAGE_BRANCHES: dict = {}


def _resolve_full_repo_slug(target_repo: str, org: str) -> str:
    """Return a full `org/repo` slug regardless of whether `target_repo` is
    bare ("Admiralty") or already-qualified ("PlaneSales/Planes-Sales-Global-AI").

    BUG-ADM-2026-0007 (Copilot review): orders + project registry entries
    use BOTH conventions, and unconditionally prepending `org/` produced
    `repos/PlaneSales/PlaneSales/Planes-Sales-Global-AI/...` paths that
    404'd permanently and got cached as failures.
    """
    if "/" in target_repo:
        return target_repo
    return f"{org}/{target_repo}"


def _get_default_branch_for_repo(target_repo: str, project_acronym: str = "") -> str:
    """Resolve the default branch for a given target repo.

    BUG-ADM-2026-0013: PR-creation paths used to hardcode `main`, which 404s
    on repos like PSG (Planes-Sales-Global-AI) whose defaultBranch is `master`.
    This helper reads `defaultBranch` from `.mso/config/projects.json`.

    Resolution order:
      1. If project_acronym given → look it up directly
      2. Else if target_repo given → scan registry for a project whose
         `repo` matches (handles both bare "Maestro" and qualified
         "tavisbasing/Maestro" forms)
      3. Fall back to `main`

    Same pattern as BUG-0007's fix in `ensure_voyage_branch_exists`.
    """
    # Path 1: explicit project acronym
    try:
        if project_acronym:
            project_info = load_project_config(project_acronym)
            if project_info:
                branch = project_info.get("defaultBranch") or ""
                if branch:
                    return branch
    except Exception:
        pass

    # Path 2: reverse lookup by target_repo
    try:
        if target_repo:
            admiralty_dir = get_artefact_root()
            projects_file = admiralty_dir / "config" / "projects.json"
            if projects_file.exists():
                registry = json.loads(projects_file.read_text(encoding='utf-8'))
                for _acronym, info in (registry.get("projects") or {}).items():
                    repo_value = info.get("repo", "")
                    # Match both bare and qualified slug forms
                    if repo_value == target_repo:
                        branch = info.get("defaultBranch") or ""
                        if branch:
                            return branch
                    # Tail of slug match (e.g. registry has "PlaneSales/PSG-AI",
                    # target_repo is just "PSG-AI")
                    if "/" in repo_value and repo_value.split("/", 1)[-1] == target_repo:
                        branch = info.get("defaultBranch") or ""
                        if branch:
                            return branch
    except Exception:
        pass

    # Path 3: fall back
    return "main"


def _load_workspace_org(project_acronym: str = None) -> str:
    """Load the GitHub org name from workspace.json or project registry.

    v4.0: reads `defaultGitHubOrg` from workspace.json. In multi-project mode,
    the project registry `org` field takes precedence. Raises ConfigurationError
    if no org is resolvable — callers must not fall back to a hardcoded default.
    """
    ws_file = get_artefact_root() / "config" / "workspace.json"
    try:
        data = json.loads(ws_file.read_text(encoding='utf-8'))
        mode = data.get("mode", "single-project")
    except Exception:
        data = {}
        mode = "single-project"

    # In multi-project mode, check project registry first
    if mode == "multi-project":
        project_info = load_project_config(project_acronym)
        if project_info and project_info.get("org"):
            return project_info["org"]

    # Read defaultGitHubOrg (v4.0) or legacy 'org' field
    org = data.get("defaultGitHubOrg") or data.get("org")
    if not org:
        raise ValueError(
            "No GitHub org configured. Set `defaultGitHubOrg` in "
            f"{ws_file} and restart the dispatcher."
        )
    return org


_PLACEHOLDER_ORG = "your-org"
_PLACEHOLDER_REPO_PREFIX = "your-org/"


def validate_placeholder_repo_config() -> list[str]:
    """Return a list of human-readable errors if any placeholder repo config is detected.

    Checks:
      - workspace.json  defaultGitHubOrg (None / "your-org")
      - projects.json   <project>.repo   ("your-org/...")
      - projects.json   <project>.org    ("your-org")

    Returns an empty list when config looks real.  Callers raise / print as
    appropriate — this function only detects, it does not abort.
    """
    errors: list[str] = []

    ws_file = get_artefact_root() / "config" / "workspace.json"
    try:
        ws_data = json.loads(ws_file.read_text(encoding="utf-8"))
    except Exception:
        ws_data = {}

    org_val = ws_data.get("defaultGitHubOrg")
    if not org_val or str(org_val).strip().lower() in ("null", _PLACEHOLDER_ORG, "none", ""):
        errors.append(
            f"workspace.json 'defaultGitHubOrg' is still the placeholder {org_val!r}. "
            f"Set it to your real GitHub organisation (e.g. \"my-org\")."
        )

    projects_file = get_artefact_root() / "config" / "projects.json"
    if projects_file.exists():
        try:
            proj_data = json.loads(projects_file.read_text(encoding="utf-8"))
            projects = proj_data.get("projects", {})
            for proj_key, proj_cfg in projects.items():
                repo_val = proj_cfg.get("repo", "")
                if repo_val.startswith(_PLACEHOLDER_REPO_PREFIX) or repo_val == "":
                    errors.append(
                        f"projects.json[{proj_key!r}].repo is still the placeholder {repo_val!r}. "
                        f"Set it to <github-org>/<repo> (e.g. \"my-org/my-repo\")."
                    )
                org_proj = proj_cfg.get("org", "")
                if org_proj == _PLACEHOLDER_ORG or org_proj == "":
                    errors.append(
                        f"projects.json[{proj_key!r}].org is still the placeholder {org_proj!r}. "
                        f"Set it to your real GitHub organisation (e.g. \"my-org\")."
                    )
        except Exception:
            pass

    return errors


def load_completion_config() -> dict:
    """Load the ``completion`` block from workspace.json with safe defaults.

    Returns a dict with keys:
      idleWatchdog: {enabled, idleMinutes, action}
      onVoyageComplete: {archiveVoyageOnMerge, archiveOrders, autoRelease}

    Defaults (when the ``completion`` block is absent) ENABLE the new housekeeping
    behaviours — idleWatchdog.enabled=True (action=cleanup, idleMinutes=30) and
    onVoyageComplete.archiveVoyageOnMerge=True / archiveOrders=True. This is
    intentional (FTR-MSO-2026-0203): auto voyage-completion housekeeping is on by
    default. To restore the pre-FTR-0203 behaviour (dispatcher never self-exits on
    idle; no archive-on-merge), set those keys to false in the workspace.json
    ``completion`` block. autoRelease stays opt-in (default False).
    """
    ws_file = get_artefact_root() / "config" / "workspace.json"
    try:
        data = json.loads(ws_file.read_text(encoding='utf-8'))
        raw = data.get("completion", {})
    except Exception:
        raw = {}

    watchdog = raw.get("idleWatchdog", {})
    on_complete = raw.get("onVoyageComplete", {})
    # FTR-MSO-2026-0287 (R1): voyage-PR draft + promote-on-finalisation.
    voyage_pr = raw.get("voyagePr", {})
    # BUG-MSO-2026-0268: per-op timeout for convergence git network ops (seconds).
    # CLI --convergence-timeout takes precedence over workspace.json.
    if _CONVERGENCE_TIMEOUT_CLI_OVERRIDE is not None:
        convergence_timeout = _CONVERGENCE_TIMEOUT_CLI_OVERRIDE
    else:
        convergence_timeout = int(raw.get("convergenceNetworkTimeout", 60))

    return {
        "idleWatchdog": {
            "enabled": watchdog.get("enabled", True),
            "idleMinutes": watchdog.get("idleMinutes", 30),
            "action": watchdog.get("action", "cleanup"),
        },
        "onVoyageComplete": {
            "archiveVoyageOnMerge": on_complete.get("archiveVoyageOnMerge", True),
            "archiveOrders": on_complete.get("archiveOrders", True),
            "autoRelease": on_complete.get("autoRelease", False),
        },
        # FTR-MSO-2026-0287 (R1): create the voyage PR as a draft (no CI on
        # intermediate convergence pushes) and promote it to ready-for-review
        # only when the voyage finalises (all orders complete). Defaults ON so
        # CI spend is bounded out-of-the-box; set draft=false to restore the
        # pre-0287 per-push-CI behaviour.
        "voyagePr": {
            "draft": voyage_pr.get("draft", True),
            "promoteOnFinalisation": voyage_pr.get("promoteOnFinalisation", True),
        },
        # BUG-MSO-2026-0285: optional per-ROLE default iteration timeout (minutes),
        # keyed by role code (PLN/BLD/TST/...). Used when an order has no explicit
        # timeoutMinutes. Empty = fall back to the global --timeout for every role.
        "roleTimeouts": raw.get("roleTimeouts", {}) if isinstance(raw.get("roleTimeouts", {}), dict) else {},
        "convergenceNetworkTimeout": convergence_timeout,
    }


def resolve_order_timeout(order_data: dict, global_timeout: int) -> int:
    """BUG-MSO-2026-0285: resolve the per-iteration timeout (minutes) for an order.

    The global ``--timeout`` is a CEILING, not a fixed wait — a 2-minute DOC order
    and a 40-minute docker+integration order should not share one number. Resolution
    order (first that yields a positive int wins):

        order.timeoutMinutes  >  completion.roleTimeouts[role]  >  global --timeout

    A non-numeric / non-positive override is ignored (falls through), so a config
    typo can never produce a 0/negative timeout that would insta-kill the crew.
    """
    # 1. order-level override
    ot = order_data.get("timeoutMinutes")
    if ot is not None:
        try:
            v = int(ot)
            if v > 0:
                return v
        except (TypeError, ValueError):
            pass
    # 2. per-role default from workspace config
    role = order_data.get("targetRole") or order_data.get("role")
    if role:
        try:
            rt = load_completion_config().get("roleTimeouts", {}).get(role)
            if rt is not None:
                v = int(rt)
                if v > 0:
                    return v
        except (TypeError, ValueError, Exception):
            pass
    # 3. global ceiling
    return global_timeout


def load_verify_config() -> dict:
    """Load the optional local-verify gate config from workspace.json.

    FTR-MSO-2026-0287 (R2). Returns ``{"command": str, "timeoutMinutes": int}``.
    ``command`` is a freeform shell command (e.g. ``dotnet build src/X.sln -c
    Release`` or ``python -m pytest -q``) run in the crew worktree BEFORE the
    convergence push. An empty command (the default) disables the gate entirely,
    so projects that don't configure it keep today's behaviour. This is the
    "only push/CI when the local build passes" guarantee.
    """
    ws_file = get_artefact_root() / "config" / "workspace.json"
    try:
        data = json.loads(ws_file.read_text(encoding='utf-8'))
    except Exception:
        data = {}
    # Copilot (PR #140): guard a non-numeric verifyTimeoutMinutes (e.g. "5m",
    # null) so a config typo falls back to the default instead of raising into
    # process_crew_completion's convergence try/except and mis-escalating the
    # order as CONVERGENCE_FAILED.
    try:
        timeout = int(data.get("verifyTimeoutMinutes", 20))
    except (TypeError, ValueError):
        timeout = 20
    return {
        "command": (data.get("verifyCommand") or "").strip(),
        "timeoutMinutes": timeout,
    }


# BUG-MSO-2026-0506: signatures that identify the FAILURE line(s) in a verify
# command's output, so the inline excerpt can name the cause instead of a
# blind tail — which for a folded-in vitest run (BUG-MSO-2026-0404) is
# dominated by PASS lines printed AFTER the failure detail.
_VERIFY_ERROR_SIGNATURES = (
    "error TS",              # tsc
    "FAIL ",                 # vitest / jest
    "npm ERR!",
    "ENOTEMPTY",
    "EPERM",
    "AssertionError",
    "SyntaxError",
    "Traceback (most recent call last)",
    "ERROR",
)


def _extract_verify_excerpt(stdout: str, stderr: str, max_len: int = 1200) -> str:
    """Pick the most useful bounded excerpt from a verify command's output.

    BUG-MSO-2026-0506: a blind tail is the wrong slice for a tool (vitest)
    that prints per-file PASS lines after the failure detail — the exact
    shape that made FTR-MSO-2026-0492's recorded 'failure' detail a wall of
    green checkmarks. Lines carrying a known error signature are preferred
    over position; when none match (a tool whose failure text doesn't hit
    any signature), a HEAD slice is used instead of a tail — it still beats
    a blind tail for tsc-style tools that front-load their errors, and is no
    worse than a tail for anything else since the full output is always
    persisted separately (see ``_persist_verify_log``).
    """
    combined = f"{stdout or ''}\n{stderr or ''}"
    lines = [ln for ln in combined.splitlines() if ln.strip()]
    matched = [ln for ln in lines if any(sig in ln for sig in _VERIFY_ERROR_SIGNATURES)]
    excerpt = "\n".join(matched) if matched else "\n".join(lines[:40])
    excerpt = excerpt.strip()
    if len(excerpt) > max_len:
        excerpt = excerpt[:max_len].rstrip() + "..."
    return excerpt


def _persist_verify_log(order_id: str, command: str, stdout: str, stderr: str,
                        status_note: str) -> Optional[Path]:
    """Write the verify gate's COMPLETE stdout+stderr to the artefact plane.

    BUG-MSO-2026-0506: the crew worktree is torn down (or replaced by a
    salvage branch, not a live checkout) shortly after a VERIFY_FAILED hold,
    so anything not written here is gone within minutes — as it was for
    FTR-MSO-2026-0488, FTR-MSO-2026-0492 and BUG-MSO-2026-0486, all
    investigated after the worktree no longer existed. Lives under
    ``get_artefact_root()`` per BUG-MSO-2026-0465's rule (role artefacts
    belong on the artefact plane, never the crew worktree), NOT the crew
    worktree that owns *command*. Returns ``None`` (never raises) when
    *order_id* is empty or the write fails — callers degrade to the inline
    excerpt only.
    """
    if not order_id:
        return None
    try:
        log_dir = get_artefact_root() / "reports" / "verify"
        log_dir.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%dT%H%M%S")
        log_path = log_dir / f"VERIFY-{order_id}-{timestamp}.log"
        body = (
            f"order: {order_id}\n"
            f"command: {command}\n"
            f"status: {status_note}\n"
            f"{'=' * 20} stdout {'=' * 20}\n"
            f"{stdout or '(empty)'}\n"
            f"{'=' * 20} stderr {'=' * 20}\n"
            f"{stderr or '(empty)'}\n"
        )
        log_path.write_text(body, encoding="utf-8")
        return log_path
    except Exception:
        return None


def run_verify_gate(worktree: "Path", command: str,
                    timeout_minutes: int = 20, order_id: str = "") -> tuple:
    """Run the project verify command in ``worktree`` (FTR-MSO-2026-0287 R2).

    Returns ``(ok: bool, detail: str, log_path: Optional[Path])``. ``ok`` is
    True when the command exits 0 (or when ``command`` is empty — gate
    disabled), in which case ``log_path`` is always ``None`` — a passing
    verify writes no artefact. On failure the COMPLETE stdout+stderr is
    persisted via :func:`_persist_verify_log` (BUG-MSO-2026-0506 — the prior
    behaviour discarded everything but a 2400-char blind tail, which was
    empirically insufficient to diagnose any of three same-morning failures
    on VOY-MSO-2026-0139) and ``detail`` carries the exit code plus a
    signature-preferring excerpt (see :func:`_extract_verify_excerpt`) for
    the lifecycle event. Never raises — a launch/timeout problem is reported
    as ``ok=False`` so the caller can hold the order rather than crash the
    dispatcher.
    """
    if not command:
        return True, "no verifyCommand configured (gate disabled)", None
    try:
        proc = run_hidden(
            command, shell=True, cwd=str(worktree),
            capture_output=True, text=True, timeout=max(1, timeout_minutes) * 60,
        )
    except subprocess.TimeoutExpired as exc:
        # TimeoutExpired carries whatever was captured before the kill —
        # persist it too, since a timeout is as undiagnosable blind as any
        # other failure (AC: "a timeout" is one of the required fixtures).
        stdout, stderr = exc.stdout or "", exc.stderr or ""
        log_path = _persist_verify_log(
            order_id, command, stdout, stderr, f"timed out after {timeout_minutes}m")
        return False, f"verifyCommand timed out after {timeout_minutes}m", log_path
    except Exception as exc:  # pragma: no cover - defensive
        return False, f"verifyCommand failed to launch: {exc}", None
    if proc.returncode == 0:
        return True, "verify passed", None
    stdout, stderr = proc.stdout or "", proc.stderr or ""
    log_path = _persist_verify_log(order_id, command, stdout, stderr, f"exit {proc.returncode}")
    excerpt = _extract_verify_excerpt(stdout, stderr)
    return False, f"verifyCommand exit {proc.returncode}: {excerpt}", log_path


def load_verify_config_for_repo(target_repo: str = "") -> dict:
    """Per-repo-aware local-verify gate config (FTR-MSO-2026-0378, plan §4.3.6).

    A multi-repo workspace carries per-repo build/test commands, so the verify
    gate must run the RIGHT one for the order's ``targetRepo``. Resolution:

      1. Start from the workspace-level :func:`load_verify_config` (the default).
      2. If a ``repos`` map is configured and *target_repo* resolves to an entry
         with a non-empty ``verifyCommand``, that command OVERRIDES the default
         (and an entry ``verifyTimeoutMinutes`` overrides the timeout).

    A single-repo workspace, an empty target, an unknown target, or an entry
    without a ``verifyCommand`` all fall back to the workspace default — so the
    return value is byte-identical to ``load_verify_config`` for every existing
    (single-repo) workspace.
    """
    base = load_verify_config()
    if not target_repo or not _repos_map_configured():
        return base
    resolved = _resolve_repo_map_entry(target_repo)
    if resolved is None:
        return base
    _, entry = resolved
    cmd = entry.get("verifyCommand")
    if not isinstance(cmd, str) or not cmd.strip():
        return base
    out = dict(base)
    out["command"] = cmd.strip()
    to = entry.get("verifyTimeoutMinutes")
    if isinstance(to, int) and to > 0:
        out["timeoutMinutes"] = to
    return out


def get_changed_paths(worktree: "Path", voyage_branch: str) -> list:
    """Files the crew branch touched relative to the voyage branch it forked from.

    BUG-MSO-2026-0404: used to decide whether a frontend (npm) verify step
    should be folded into the local verify gate. Tries ``origin/<voyage_branch>``
    first (the up-to-date remote tip), then the local branch ref as a fallback.
    Best-effort: any git failure returns ``[]`` so the caller just skips the
    frontend-detection step rather than raising into convergence.
    """
    for base_ref in (f"origin/{voyage_branch}", voyage_branch):
        try:
            merge_base = run_hidden(
                ["git", "merge-base", "HEAD", base_ref],
                cwd=str(worktree), capture_output=True, text=True, timeout=30,
            )
            if merge_base.returncode != 0 or not merge_base.stdout.strip():
                continue
            base_sha = merge_base.stdout.strip()
            diff = run_hidden(
                ["git", "diff", "--name-only", base_sha, "HEAD"],
                cwd=str(worktree), capture_output=True, text=True, timeout=30,
            )
            if diff.returncode != 0:
                continue
            return [line.strip() for line in diff.stdout.splitlines() if line.strip()]
        except Exception:
            continue
    return []


def _detect_frontend_verify_commands(worktree: "Path", changed_paths: list) -> list:
    """Auto-detect a tsc/vitest verify step for each npm package the crew touched.

    BUG-MSO-2026-0404: PR #241 passed a crew's local vitest run but FAILED CI in
    25s on a TypeScript compile error (a test mock typed a field as ``string``
    against a real union type) — maestro-hub's vitest script does not type-check,
    but CI runs a SEPARATE ``npm run typecheck`` job (see the ``hub-test`` job in
    ``.github/workflows/ci.yml``) that vitest alone can't catch. This repo is
    polyglot (Python core + several npm packages), so the fix can't be a single
    hardcoded frontend command — it has to detect, per changed file, which npm
    package (if any) was touched.

    For each changed file, walks up to the nearest ancestor directory containing
    a ``package.json`` (deduping repeated hits within the same package), and for
    every such package that declares BOTH a ``typecheck`` and a ``test`` script
    builds ``cd <dir> && npm run typecheck && npm run test`` — mirroring CI's
    two-step gate exactly. A package with no ``typecheck`` script (e.g. one with
    nothing statically typed to catch) is skipped, and a Python-only order that
    touches no npm package returns ``[]`` — so it never pays for an npm install.
    """
    seen_dirs = set()
    commands = []
    for rel_path in changed_paths:
        cur = (worktree / rel_path).parent
        while True:
            try:
                cur = cur.resolve()
            except Exception:
                break
            if cur != worktree and worktree not in cur.parents:
                break
            candidate = cur / "package.json"
            if candidate.exists():
                try:
                    rel_dir = cur.relative_to(worktree).as_posix()
                except ValueError:
                    break
                if rel_dir not in seen_dirs:
                    seen_dirs.add(rel_dir)
                    try:
                        pkg = json.loads(candidate.read_text(encoding="utf-8"))
                    except Exception:
                        pkg = {}
                    scripts = pkg.get("scripts") or {}
                    if isinstance(scripts, dict) and "typecheck" in scripts and "test" in scripts:
                        prefix = f"cd {rel_dir} && " if rel_dir != "." else ""
                        commands.append(f"{prefix}npm run typecheck && npm run test")
                break
            if cur == worktree:
                break
            cur = cur.parent
    return commands


def resolve_verify_config_for_paths(worktree: "Path", base_cfg: dict,
                                    changed_paths: list) -> dict:
    """Fold auto-detected frontend verify steps into the base verify gate config.

    BUG-MSO-2026-0404: extends (never replaces) the existing Python/workspace
    ``verifyCommand`` with a ``npm run typecheck && npm run test`` step per npm
    package the order touched, so a frontend-touching order's local gate matches
    CI's two-step (tsc + vitest) gate. An order with no detected frontend
    package returns *base_cfg* completely unchanged — including an empty/
    disabled command — so Python-only orders never run an npm install.
    """
    frontend_cmds = _detect_frontend_verify_commands(worktree, changed_paths)
    if not frontend_cmds:
        return base_cfg
    combined = " && ".join(frontend_cmds)
    if base_cfg.get("command"):
        combined = f"{base_cfg['command']} && {combined}"
    out = dict(base_cfg)
    out["command"] = combined
    out["timeoutMinutes"] = max(int(base_cfg.get("timeoutMinutes", 20) or 20), 15)
    return out


def promote_voyage_pr_ready(voyage: dict) -> bool:
    """Promote a voyage's draft PR to ready-for-review (FTR-MSO-2026-0287 R1).

    Called when a voyage finalises (all orders complete). Runs ``gh pr ready
    <branch>`` so the single end-of-voyage CI run fires before merge review. A
    no-op (returns False) when draft mode or promote-on-finalisation is disabled,
    or when the voyage has no resolvable branch/repo. Never raises.

    Copilot (PR #140): promotes the PR on EVERY repo in ``targetRepos`` (a voyage
    may target several repos, each with its own PR via create_pr_for_crew) so no
    repo's PR is left draft forever. Returns True if at least one was promoted.
    """
    try:
        cfg = load_completion_config().get("voyagePr", {})
        if not (cfg.get("draft", True) and cfg.get("promoteOnFinalisation", True)):
            return False
        branch = (voyage.get("branch") or "").replace("refs/heads/", "")
        if not branch:
            return False
        repos = voyage.get("targetRepos") or []
        project = voyage.get("project") or ""
        org = _load_workspace_org(project)
        vid = voyage.get("voyageId") or voyage.get("id") or branch
        promoted_any = False
        if repos:
            for repo in repos:
                full_repo = _resolve_full_repo_slug(repo, org)
                result = run_hidden(
                    ["gh", "pr", "ready", branch, "--repo", full_repo],
                    capture_output=True, text=True, timeout=30,
                )
                if result.returncode == 0:
                    write_lifecycle_event(
                        "PR",
                        f"Voyage {vid}: promoted PR to ready-for-review on finalisation "
                        f"({repo}@{branch})"
                    )
                    promoted_any = True
                else:
                    write_lifecycle_event(
                        "WARN",
                        f"Voyage {vid}: gh pr ready failed for {repo}@{branch}: "
                        f"{(result.stderr or '').strip()[:150]}"
                    )
        else:
            # FTR-MSO-2026-0373 (scope 3b): a single-repo / embedded voyage may
            # have NO targetRepos recorded — the create-time linkage set only the
            # flat prNumber/prUrl, or the PR was opened in an earlier session so
            # this dict was reconstructed from disk without targetRepos. Promote
            # by branch alone (gh resolves the repo from the workspace origin
            # remote) so a finalised voyage's draft PR is still flipped to ready
            # instead of sitting draft forever.
            result = run_hidden(
                ["gh", "pr", "ready", branch],
                capture_output=True, text=True, timeout=30,
                cwd=str(get_base_dir()),
            )
            if result.returncode == 0:
                write_lifecycle_event(
                    "PR",
                    f"Voyage {vid}: promoted PR to ready-for-review on "
                    f"finalisation ({branch})"
                )
                promoted_any = True
            else:
                write_lifecycle_event(
                    "WARN",
                    f"Voyage {vid}: gh pr ready failed for {branch}: "
                    f"{(result.stderr or '').strip()[:150]}"
                )
        return promoted_any
    except Exception as exc:  # pragma: no cover - defensive
        write_lifecycle_event(
            "WARN",
            f"Voyage PR promote-on-finalisation error: {exc}"
        )
        return False


# ---------------------------------------------------------------------------
# BUG-MSO-2026-0360: voyage <-> PR linkage + no-code voyage auto-finalisation
# ---------------------------------------------------------------------------

def _voyage_order_ids(voyage: dict) -> List[str]:
    """Extract order ids from a voyage manifest's orders[] (strings or dicts)."""
    ids: List[str] = []
    for entry in voyage.get("orders", []) or []:
        if isinstance(entry, str):
            oid = entry
        elif isinstance(entry, dict):
            oid = entry.get("orderId") or entry.get("id") or ""
        else:
            oid = ""
        if oid:
            ids.append(oid)
    return ids


def _pr_number_from_url(pr_url: str) -> Optional[int]:
    """Parse the PR number off a GitHub PR URL tail; None if unparseable."""
    try:
        return int((pr_url or "").rstrip("/").rsplit("/", 1)[-1])
    except (ValueError, IndexError):
        return None


def _apply_pr_linkage(voyage: dict, pr_number: Optional[int], pr_url: str,
                      repo_slug: Optional[str] = None) -> bool:
    """Set prNumber/prUrl on a voyage manifest dict (BUG-MSO-2026-0360).

    Returns True when the dict was actually changed. Idempotent: identical
    values are a no-op. Never rewinds to an OLDER PR number than the one
    already recorded (a stale re-run must not clobber a newer linkage).

    FTR-MSO-2026-0379 (voyage-spans-repos): when ``repo_slug`` is given the
    linkage is ALSO recorded under ``voyage["prUrls"][repo_slug]`` as a
    ``{"prNumber", "prUrl"}`` entry (one PR per repo per voyage), with the same
    per-entry clobber guard. The flat ``prNumber``/``prUrl`` fields are always
    maintained too so single-repo voyages and the Hub aggregator (which reads
    the flat ``prUrl``) keep working unchanged.
    """
    if not pr_url and pr_number is None:
        return False
    if pr_number is None:
        pr_number = _pr_number_from_url(pr_url)
    changed = False

    # Per-repo map (FTR-MSO-2026-0379). Each repo carries its own PR; guard each
    # entry independently so recording repo B's PR never clobbers repo A's.
    if repo_slug:
        prurls = voyage.get("prUrls")
        if not isinstance(prurls, dict):
            prurls = {}
        entry = prurls.get(repo_slug)
        entry = dict(entry) if isinstance(entry, dict) else {}
        existing_num = entry.get("prNumber")
        if not (isinstance(existing_num, int) and isinstance(pr_number, int)
                and existing_num > pr_number):
            entry_changed = False
            if pr_number is not None and entry.get("prNumber") != pr_number:
                entry["prNumber"] = pr_number
                entry_changed = True
            if pr_url and entry.get("prUrl") != pr_url:
                entry["prUrl"] = pr_url
                entry_changed = True
            if entry_changed:
                prurls[repo_slug] = entry
                voyage["prUrls"] = prurls
                changed = True

    # Flat fields (back-compat) — unchanged clobber guard.
    existing = voyage.get("prNumber")
    if not (isinstance(existing, int) and isinstance(pr_number, int)
            and existing > pr_number):
        if pr_number is not None and voyage.get("prNumber") != pr_number:
            voyage["prNumber"] = pr_number
            changed = True
        if pr_url and voyage.get("prUrl") != pr_url:
            voyage["prUrl"] = pr_url
            changed = True
    return changed


def _voyage_repo_slugs(voyage: dict) -> List[str]:
    """Ordered, de-duplicated list of repo slugs a voyage spans.

    FTR-MSO-2026-0379. Prefers the authoritative ``targetRepos`` list; falls
    back to the keys of a ``prUrls`` map (a voyage that recorded per-repo PRs
    before ``targetRepos`` was written). Returns ``[]`` for a legacy single-repo
    voyage that carries neither — such voyages keep the flat-field reconcile
    path. Order is stable (targetRepos order, then any prUrls-only extras).
    """
    slugs: List[str] = []
    seen = set()
    for repo in (voyage.get("targetRepos") or []):
        if isinstance(repo, str) and repo and repo not in seen:
            seen.add(repo)
            slugs.append(repo)
    prurls = voyage.get("prUrls")
    if isinstance(prurls, dict):
        for repo in prurls:
            if isinstance(repo, str) and repo and repo not in seen:
                seen.add(repo)
                slugs.append(repo)
    return slugs


def _add_voyage_target_repo(voyage: dict, repo: str) -> bool:
    """Add ``repo`` to a voyage's ``targetRepos`` list (idempotent).

    FTR-MSO-2026-0379: ``targetRepos`` is authoritative and derived from the
    voyage's orders' ``targetRepo`` set. It is populated incrementally as each
    repo's PR is recorded so ``promote_voyage_pr_ready`` / reconcile can iterate
    every touched repo. Returns True when the list changed.
    """
    if not repo:
        return False
    repos = voyage.get("targetRepos")
    if not isinstance(repos, list):
        repos = []
    if repo in repos:
        return False
    repos.append(repo)
    voyage["targetRepos"] = repos
    return True


def record_voyage_pr_linkage(voyage_branch: str, pr_url: str,
                             pr_number: Optional[int] = None,
                             repo_slug: Optional[str] = None) -> bool:
    """Write prNumber/prUrl onto the active voyage manifest for *voyage_branch*
    and commit it as a lifecycle transition (BUG-MSO-2026-0360).

    The Hub aggregator reads ``prUrl`` off the manifest on MAIN; PR creation
    used to open the PR without recording the linkage anywhere, so the Hub's
    Final Review bucket had no PR link/merge CTA. Best-effort: returns False
    (never raises) when no active manifest matches the branch.

    FTR-MSO-2026-0379 (voyage-spans-repos): when ``repo_slug`` is given the PR is
    ALSO recorded under ``prUrls[repo_slug]`` and the repo is added to the
    voyage's authoritative ``targetRepos`` list — so a voyage touching N repos
    ends up with one recorded PR per repo. The flat fields stay for back-compat.
    """
    branch_ref = (voyage_branch or "").replace("refs/heads/", "")
    if not branch_ref or not pr_url:
        return False
    try:
        active_dir = get_artefact_root() / "voyages" / "active"
        if not active_dir.exists():
            return False
        for voyage_file in sorted(active_dir.glob("*.json")):
            try:
                voyage = json.loads(voyage_file.read_text(encoding="utf-8"))
            except Exception:
                continue
            manifest_branch = (voyage.get("branch") or voyage.get("voyageBranch")
                               or "").replace("refs/heads/", "")
            if manifest_branch != branch_ref:
                continue
            linkage_changed = _apply_pr_linkage(voyage, pr_number, pr_url,
                                                repo_slug=repo_slug)
            repos_changed = _add_voyage_target_repo(voyage, repo_slug or "")
            if not (linkage_changed or repos_changed):
                return False  # already linked — idempotent no-op
            vid = voyage.get("voyageId") or voyage.get("id") or voyage_file.stem
            voyage_file.write_text(json.dumps(voyage, indent=2), encoding="utf-8")
            _repo_note = f" [{repo_slug}]" if repo_slug else ""
            write_lifecycle_event(
                "PR_LINKED",
                f"Voyage {vid}: PR #{voyage.get('prNumber')} linked on manifest "
                f"({branch_ref}){_repo_note} (BUG-0360)")
            _commit_lifecycle_transition(
                [voyage_file],
                f"lifecycle: link PR #{voyage.get('prNumber')} to {vid}{_repo_note}")
            return True
        return False
    except Exception as exc:
        write_lifecycle_event(
            "WARN", f"record_voyage_pr_linkage failed for {branch_ref}: {exc}")
        return False


def _is_bookkeeping_path(path_str: str) -> bool:
    """True for dispatcher/artefact bookkeeping paths — not a code deliverable.

    A voyage whose branch only touches the workspace artefact tree (order
    JSONs, plans, handoffs, lifecycle moves) has no source to merge; such
    changes are swept to main directly (Captain directive 2026-05-11).
    """
    p = path_str.replace("\\", "/").lstrip("/")
    while p.startswith("./"):
        p = p[2:]
    return p.startswith(f"{MSO_DIR_NAME}/") or p.startswith(".adm/")


def _resolve_local_default_branch(base: "Path") -> str:
    """Best-effort default-branch name from the local clone (offline-safe)."""
    try:
        r = run_hidden(
            ["git", "symbolic-ref", "--quiet", "refs/remotes/origin/HEAD"],
            capture_output=True, text=True, cwd=str(base), timeout=10)
        if r.returncode == 0 and r.stdout.strip():
            return r.stdout.strip().rsplit("/", 1)[-1]
    except Exception:
        pass
    for cand in ("main", "master"):
        try:
            r = run_hidden(
                ["git", "rev-parse", "--verify", "--quiet", f"refs/heads/{cand}"],
                capture_output=True, text=True, cwd=str(base), timeout=10)
            if r.returncode == 0:
                return cand
        except Exception:
            pass
    return "main"


def _branch_has_unmerged_source_changes(branch: str) -> Optional[bool]:
    """Does *branch* carry changes beyond artefact bookkeeping vs the default
    branch? (BUG-MSO-2026-0360 auto-finalise guard)

    Local-git first (offline-safe), ``gh api compare`` fallback when the branch
    is not in the local clone. Returns True/False, or None when undeterminable
    (git diff failed AND gh unavailable/failed) — callers MUST treat None as
    "unsafe to assume no code". A missing/empty branch is False: nothing
    exists to be unmerged.
    """
    branch_ref = (branch or "").replace("refs/heads/", "")
    if not branch_ref:
        return False
    base = get_base_dir()
    default_branch = _resolve_local_default_branch(base)

    def _ref_exists(ref: str) -> bool:
        try:
            return run_hidden(
                ["git", "rev-parse", "--verify", "--quiet", ref],
                capture_output=True, text=True, cwd=str(base), timeout=10
            ).returncode == 0
        except Exception:
            return False

    head_ref = None
    for cand in (f"refs/heads/{branch_ref}", f"refs/remotes/origin/{branch_ref}"):
        if _ref_exists(cand):
            head_ref = cand
            break

    if head_ref is not None:
        base_ref = (f"refs/remotes/origin/{default_branch}"
                    if _ref_exists(f"refs/remotes/origin/{default_branch}")
                    else f"refs/heads/{default_branch}")
        # FTR-MSO-2026-0426: squash/rebase-merge safety. The three-dot diff
        # below asks "what does this branch change relative to the MERGE-BASE",
        # which after a squash-merge still lists every file the branch ever
        # touched — the squashed commit landed on base but is not an ancestor
        # of the branch, so the merge-base never moves. That made this guard
        # report "unmerged source changes" FOREVER and permanently blocked
        # auto-finalisation (measured on VOY-0119/0120/0122, all merged).
        # Content-equality settles it first: if base already contains the
        # branch's cumulative patch, nothing on it is unmerged. This narrows
        # the guard to its real purpose (BUG-0360: block finalisation while
        # genuinely unmerged work sits on the branch) — an inconclusive
        # containment probe falls through to the original diff unchanged.
        if _base_contains_branch_changes(base_ref, head_ref, base) is True:
            return False
        try:
            diff = run_hidden(
                ["git", "diff", "--name-only", f"{base_ref}...{head_ref}"],
                capture_output=True, text=True, cwd=str(base), timeout=30)
        except Exception:
            return None
        if diff.returncode != 0:
            return None
        files = [ln.strip() for ln in diff.stdout.splitlines() if ln.strip()]
        return any(not _is_bookkeeping_path(f) for f in files)

    # Branch not in the local clone — ask GitHub. gh resolves {owner}/{repo}
    # placeholders from the cwd's origin remote.
    try:
        cmp_r = run_hidden(
            ["gh", "api",
             f"repos/{{owner}}/{{repo}}/compare/{default_branch}...{branch_ref}",
             "--jq", ".files[].filename"],
            capture_output=True, text=True, cwd=str(base), timeout=30)
    except Exception:
        return None
    if cmp_r.returncode != 0:
        if "404" in (cmp_r.stderr or ""):
            return False  # branch exists nowhere — nothing unmerged
        return None
    files = [ln.strip() for ln in cmp_r.stdout.splitlines() if ln.strip()]
    return any(not _is_bookkeeping_path(f) for f in files)


# ---------------------------------------------------------------------------
# FTR-MSO-2026-0373: host-neutral (raw-git) merge detection
# ---------------------------------------------------------------------------
# reconcile used to depend entirely on ``gh pr view`` to decide whether a voyage
# had merged, which left GitLab / Bitbucket / plain-git customers with NO
# reconciliation at all. The detection below uses raw git signals only —
# content-equality (which survives squash merges, where the branch tip is never
# an ancestor of the base and per-commit patch-ids don't match) plus
# remote-branch-deletion — and demotes ``gh`` to OPTIONAL metadata enrichment.
#
# Every git call validates the SHAPE of git's output (a real 40-hex sha, a
# ``+``/``-`` cherry line) rather than trusting the exit code alone. This keeps
# the detection inert under the existing test-suite pattern that globally stubs
# ``subprocess.run`` with gh JSON: those stubs never look like git output, so
# the verdict degrades to "unknown" and the legacy gh path runs unchanged.

_GIT_SHA_RE = re.compile(r"^[0-9a-f]{40}$")


def _git_capture(args: List[str], cwd: "Path", timeout: int = 30):
    """Run a git command; return the CompletedProcess, or None on any failure.

    Never raises — a missing git binary, a timeout, or an OS error all yield
    None so a caller can degrade to 'undeterminable' instead of crashing the
    reconcile loop.
    """
    try:
        return run_hidden(["git", *args], capture_output=True, text=True,
                              cwd=str(cwd), timeout=timeout)
    except Exception:
        return None


def _git_rev(ref: str, cwd: "Path") -> Optional[str]:
    """Resolve *ref* to a validated 40-hex commit sha, or None.

    Validates the OUTPUT (a real sha) rather than trusting the exit code, so a
    test that globally stubs ``subprocess.run`` with non-git JSON is not
    mistaken for a live git ref.
    """
    r = _git_capture(["rev-parse", "--verify", "--quiet", f"{ref}^{{commit}}"],
                     cwd, timeout=10)
    if r is None or r.returncode != 0:
        return None
    sha = (r.stdout or "").strip()
    return sha if _GIT_SHA_RE.match(sha) else None


def _branch_ref_never_diverged(branch_ref: str, cwd: "Path") -> bool:
    """True when *branch_ref* has exactly one reflog entry — its creation.

    BUG-MSO-2026-0434: a voyage branch is created FROM the tip of base with
    zero commits of its own, and its reflog carries exactly one entry
    (``branch: Created from ...`` on a local checkout/worktree-add, or
    ``update by push`` on a fetched remote-tracking ref). Any commit, or any
    later push/fetch advance, appends a second entry. Empirically verified
    against local ``checkout -b``, ``git worktree add -b``, and a fetched
    ``refs/remotes/origin/<branch>`` — all three write exactly one entry for
    an untouched branch and two once real work lands.

    Returns False (i.e. "can't confirm — assume it may have diverged") when
    the reflog is empty/unreadable (old branch past ``gc.reflogExpire``,
    reflogs disabled, shallow clone) so an expired reflog never blocks a
    legitimate old merge from being detected.
    """
    r = _git_capture(["reflog", "show", branch_ref], cwd, timeout=10)
    if r is None or r.returncode != 0:
        return False
    lines = [ln for ln in (r.stdout or "").splitlines() if ln.strip()]
    return len(lines) == 1


def _base_contains_branch_changes(base_ref: str, branch_ref: str,
                                  cwd: "Path") -> Optional[bool]:
    """Content-equality: are the branch's cumulative changes already in base?

    Collapses the branch into a single synthetic commit (its tree, parented on
    the merge-base) and asks ``git cherry`` whether base already contains that
    cumulative patch. This is squash-merge-proof: after a squash the branch tip
    is not an ancestor of base and the individual commits' patch-ids don't
    match, but the *cumulative* patch-id does.

    Returns True (base contains the changes → merged), False (base does not),
    or None (undeterminable via raw git).
    """
    base_sha = _git_rev(base_ref, cwd)
    branch_sha = _git_rev(branch_ref, cwd)
    if not base_sha or not branch_sha:
        return None
    # Ancestry short-circuit (DEF-0373-1): if the branch tip is already an
    # ancestor of base — an ordinary merge commit (``git merge --no-ff``) or a
    # fast-forward, the DEFAULT strategy on GitLab / Bitbucket / GitHub — then
    # base definitively contains the branch's changes. The squash-probe below
    # cannot see this: when merge-base == branch_tip the synthetic probe is an
    # empty-diff commit and ``git cherry`` reports it '+' (novel), yielding a
    # false 'not contained'. Content-equality is a SUPERSET of ancestry, so this
    # check runs first and the squash path (tip NOT an ancestor) still falls
    # through to the probe/cherry logic unchanged.
    anc = _git_capture(["merge-base", "--is-ancestor", branch_sha, base_sha],
                       cwd, timeout=10)
    if anc is not None and anc.returncode == 0:
        # BUG-MSO-2026-0434: a commit is trivially its own ancestor, so a
        # freshly-cut voyage branch (created FROM base's tip, zero commits of
        # its own) satisfies this check immediately — that is evidence of
        # nothing having happened yet, not of a merge. Distinguish "never
        # touched" from "genuinely landed" via the branch ref's OWN reflog:
        # creation writes exactly one entry ("branch: Created from ..." /
        # "update by push"); any subsequent commit or fetch-advance adds a
        # second. A branch with only its creation entry has not diverged —
        # report undeterminable rather than a false "merged". If the reflog
        # is unavailable/expired (old branch, gc'd, logs disabled) this can't
        # be confirmed either way, so it falls back to the prior behaviour
        # (trust the ancestry check) rather than blocking a real old merge.
        if _branch_ref_never_diverged(branch_ref, cwd):
            return None
        return True
    # Per-commit equivalence (FTR-MSO-2026-0426): a REBASE-merge replays the
    # branch's commits onto base as N separate new commits, each keeping its
    # own patch-id. The cumulative squash-probe below cannot see that — it
    # synthesises ONE combined patch, whose patch-id matches a squash merge but
    # never the N individual replayed patches. Ask git directly instead: when
    # every one of the branch's commits already has an equivalent in base
    # (``git cherry`` marks it '-'), base contains the branch. A squash merge
    # marks them '+' here and simply falls through to the probe below, so this
    # only ever ADDS detections.
    cherry_direct = _git_capture(["cherry", base_sha, branch_sha], cwd, timeout=15)
    if cherry_direct is not None and cherry_direct.returncode == 0:
        direct = [ln.strip() for ln in (cherry_direct.stdout or "").splitlines()
                  if ln.strip()]
        if direct and all(ln.startswith("-") for ln in direct):
            return True

    mb = _git_capture(["merge-base", base_sha, branch_sha], cwd, timeout=15)
    if mb is None or mb.returncode != 0:
        return None
    merge_base = (mb.stdout or "").strip()
    if not _GIT_SHA_RE.match(merge_base):
        return None
    tree = _git_capture(
        ["rev-parse", "--verify", "--quiet", f"{branch_sha}^{{tree}}"],
        cwd, timeout=10)
    if tree is None or tree.returncode != 0:
        return None
    tree_sha = (tree.stdout or "").strip()
    if not _GIT_SHA_RE.match(tree_sha):
        return None
    # Synthesise "the branch as one commit on the merge-base". -c user.* keeps
    # commit-tree working in environments with no committer identity configured.
    ct = _git_capture(
        ["-c", "user.name=maestro", "-c", "user.email=maestro@localhost",
         "commit-tree", tree_sha, "-p", merge_base, "-m", "mso-merge-probe"],
        cwd, timeout=10)
    if ct is None or ct.returncode != 0:
        return None
    probe = (ct.stdout or "").strip()
    if not _GIT_SHA_RE.match(probe):
        return None
    cherry = _git_capture(["cherry", base_sha, probe], cwd, timeout=15)
    if cherry is None or cherry.returncode != 0:
        return None
    lines = [ln.strip() for ln in (cherry.stdout or "").splitlines() if ln.strip()]
    has_plus = any(ln.startswith("+") for ln in lines)   # patch NOT in base
    has_minus = any(ln.startswith("-") for ln in lines)  # patch IS in base
    if has_plus:
        return False
    if has_minus:
        return True
    return None  # empty output (no unique commits) — do not infer 'merged'


def _origin_branch_present(branch_ref: str, cwd: "Path") -> Optional[bool]:
    """Does *branch_ref* still exist on origin? (remote-branch-deletion signal).

    True/False from ``git ls-remote --heads origin <branch>``, or None when the
    remote can't be reached (offline / no remote) — a network failure must NOT
    be read as deletion.
    """
    r = _git_capture(["ls-remote", "--heads", "origin", branch_ref],
                     cwd, timeout=20)
    if r is None or r.returncode != 0:
        return None
    out = (r.stdout or "").strip()
    if not out:
        return False  # remote reachable, branch absent → deleted
    target = f"refs/heads/{branch_ref}"
    return any(ln.split("\t")[-1].strip() == target
               for ln in out.splitlines() if ln.strip())


def _git_merge_verdict(branch: str, cwd: Optional["Path"] = None) -> dict:
    """Host-neutral merge verdict for a voyage *branch* using raw git only.

    Returns ``{"verdict", "base_contains", "origin_present"}`` where verdict is:
      - ``"merged"`` — base already contains the branch's changes (squash-safe).
      - ``"closed"`` — origin branch is GONE and base does NOT contain the
                        changes → PR closed without merging (operator decision).
      - ``"open"``   — base lacks the changes and the branch is still on origin
                        (or origin state is unknown) → live/unmerged.
      - ``"unknown"``— raw git could not decide (branch not resolvable locally,
                        git unavailable, mocked-out) → caller falls back to gh.
    """
    branch_ref = (branch or "").replace("refs/heads/", "")
    out = {"verdict": "unknown", "base_contains": None, "origin_present": None}
    if not branch_ref:
        return out
    if cwd is None:
        cwd = get_base_dir()
    default_branch = _resolve_local_default_branch(cwd)
    base_ref = (f"refs/remotes/origin/{default_branch}"
                if _git_rev(f"refs/remotes/origin/{default_branch}", cwd)
                else default_branch)
    head_ref = None
    for cand in (f"refs/remotes/origin/{branch_ref}", f"refs/heads/{branch_ref}"):
        if _git_rev(cand, cwd):
            head_ref = cand
            break
    if head_ref is None:
        return out  # branch not in the local clone — undeterminable via raw git
    contained = _base_contains_branch_changes(base_ref, head_ref, cwd)
    out["base_contains"] = contained
    if contained is True:
        out["verdict"] = "merged"
        return out
    if contained is False:
        present = _origin_branch_present(branch_ref, cwd)
        out["origin_present"] = present
        out["verdict"] = "closed" if present is False else "open"
        return out
    return out  # contained is None → unknown


def _gh_pr_view(branch: str, cwd: "Path", repo: Optional[str] = None) -> Optional[dict]:
    """Best-effort ``gh pr view`` → parsed dict, or None (gh absent/failed/no PR).

    Enrichment only — never load-bearing for the merged/closed decision. Never
    raises; a missing ``gh`` binary simply yields None.
    """
    args = ["gh", "pr", "view", branch, "--json",
            "state,mergeCommit,mergedAt,number,mergeable,url"]
    if repo:
        args += ["--repo", repo]
    try:
        r = run_hidden(args, capture_output=True, text=True,
                           timeout=30, cwd=str(cwd))
    except Exception:
        return None
    if r.returncode != 0:
        return None
    try:
        return json.loads(r.stdout)
    except Exception:
        return None


# ---------------------------------------------------------------------------
# FTR-MSO-2026-0426: PR-state-authoritative merge detection
# ---------------------------------------------------------------------------
# Every Maestro PR is SQUASH-merged (`gh pr merge --squash`), which lands a NEW
# single commit on the base branch — the branch's own commits never become
# ancestors of base. Any detection that reasons from commit ANCESTRY therefore
# reports "unmerged" permanently, the BUG-0360 finalisation guard refuses to
# auto-finalise, and reconcile reports "0 voyages would be archived" even when
# every PR is demonstrably merged (measured 2026-07-30 on VOY-0119/0120/0122).
#
# The fix: when a voyage records a prNumber, the GitHub PR record is the
# AUTHORITATIVE answer to "has this shipped" — `merged: true` is strategy-blind,
# so squash, rebase and merge-commit all resolve correctly. Raw-git detection
# (FTR-0373 content-equality, itself squash-safe) stays as the fallback for
# PR-less voyages and for offline / gh-unavailable operation, where the verdict
# degrades to "unknown" and NEVER to a false "merged".

def _voyage_pr_number(voyage: dict) -> Optional[int]:
    """The PR number linked to a voyage manifest, or None.

    Reads the flat ``prNumber`` (BUG-0360 linkage), then ``mergedPR``, then
    parses ``prUrl``. The per-repo ``prUrls`` map is deliberately NOT consulted:
    multi-repo voyages resolve per repo in ``_reconcile_multi_repo_voyage``.
    """
    for key in ("prNumber", "mergedPR"):
        val = voyage.get(key)
        if isinstance(val, bool):
            continue
        if isinstance(val, int):
            return val
        if isinstance(val, str) and val.strip().isdigit():
            return int(val.strip())
    return _pr_number_from_url(voyage.get("prUrl") or "")


def _gh_pr_by_number(pr_number: Optional[int], cwd: "Path",
                     repo: Optional[str] = None) -> Optional[dict]:
    """Authoritative PR record fetched BY NUMBER via the GitHub API.

    Returns a dict with ``state``/``merged``/``mergedAt``/``mergeCommit``/
    ``number``/``url``/``baseRefName``, or None when gh is absent, offline, the
    number is unusable, or the response doesn't look like a real PR record.

    Looking the PR up by NUMBER (rather than by branch, as ``gh pr view
    <branch>`` does) is what makes this survive the post-merge world: GitHub
    deletes the head branch on merge, after which a branch-keyed lookup finds
    nothing at all.

    The ``merged`` shape guard is load-bearing: the existing test suite globally
    stubs ``subprocess.run`` with ``gh pr view`` JSON, which carries no
    ``merged`` key. Such a stub yields None here and the caller degrades to the
    unchanged legacy path instead of being handed a bogus verdict.

    ``baseRefName`` (BUG-MSO-2026-0547) is the merge TARGET branch — ``merged:
    true`` alone does not mean the voyage has landed on the project's default
    branch; it only means the PR merged into *some* branch, which may be a
    staging/develop integration branch. Callers must check it before treating
    a merge as voyage completion.
    """
    try:
        num = int(pr_number)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return None
    if num <= 0:
        return None
    slug = repo or "{owner}/{repo}"
    try:
        r = run_hidden(
            ["gh", "api", f"repos/{slug}/pulls/{num}", "--jq",
             "{state:.state,merged:.merged,mergedAt:.merged_at,"
             "mergeCommit:.merge_commit_sha,number:.number,url:.html_url,"
             "baseRefName:.base.ref}"],
            capture_output=True, text=True, timeout=30, cwd=str(cwd))
    except Exception:
        return None
    if r.returncode != 0:
        return None
    try:
        data = json.loads(r.stdout)
    except Exception:
        return None
    if not isinstance(data, dict) or "merged" not in data:
        return None  # shape guard — not a real PR record; do not trust it
    return data


def _pr_authoritative_verdict(pr_number: Optional[int], cwd: "Path",
                              repo: Optional[str] = None,
                              expected_base: Optional[str] = None) -> dict:
    """``{"verdict", "meta"}`` derived from the GitHub PR record.

    verdict is ``"merged"`` (``merged: true`` AND, when *expected_base* is
    given, ``baseRefName`` matches it — strategy-blind, so squash / rebase /
    merge-commit all land here), ``"wrong_base"`` (``merged: true`` but into a
    branch other than *expected_base* — e.g. a staging/develop integration
    branch, NOT the project's default branch — BUG-MSO-2026-0547), ``"closed"``
    (closed WITHOUT merging), ``"open"``, or ``"unknown"`` when the PR could
    not be read at all. Only a same-base ``merged: true`` ever produces
    "merged" — an unreadable PR, or a PR merged to the wrong base, is never a
    false "merged".

    *expected_base* is optional: a caller with no opinion on the merge target
    (e.g. no project default-branch configured) omits it and gets the old
    strategy-blind-only behaviour.
    """
    data = _gh_pr_by_number(pr_number, cwd, repo)
    if data is None:
        return {"verdict": "unknown", "meta": {}}
    base_ref = data.get("baseRefName") or ""
    meta = {
        "mergeCommit": data.get("mergeCommit") or "",
        "mergedAt": data.get("mergedAt") or "",
        "number": data.get("number"),
        "url": data.get("url") or "",
        "baseRefName": base_ref,
    }
    if data.get("merged") is True:
        # BUG-MSO-2026-0547: `merged: true` only says the PR landed somewhere —
        # it says nothing about WHERE. A PR merged to a staging/develop
        # integration branch is not voyage completion. Only gate on this when
        # both sides are known; a caller/response missing baseRefName degrades
        # to the pre-0547 strategy-blind behaviour rather than failing closed.
        if expected_base and base_ref and base_ref != expected_base:
            meta["expectedBase"] = expected_base
            return {"verdict": "wrong_base", "meta": meta}
        return {"verdict": "merged", "meta": meta}
    state = str(data.get("state") or "").upper()
    if state == "CLOSED":
        return {"verdict": "closed", "meta": meta}
    if state == "OPEN":
        return {"verdict": "open", "meta": meta}
    return {"verdict": "unknown", "meta": meta}


def _expected_default_branch(voyage: dict, cwd: "Path") -> str:
    """Best-effort default (integration) branch a voyage's PR must land on.

    BUG-MSO-2026-0547: reconcile used to treat ``merged: true`` alone as voyage
    completion regardless of which branch the PR merged into, so a PR merged to
    a staging/develop branch archived a voyage whose work had not reached the
    project's actual default branch. Prefers the project registry's configured
    ``defaultBranch`` (e.g. ``master`` for PSG) since that is authoritative when
    present; falls back to git's own notion of the remote's default branch
    (``_resolve_local_default_branch`` — the same oracle ``_git_merge_verdict``
    already trusts) for a project with no explicit ``defaultBranch`` configured,
    rather than assuming ``main``.
    """
    project = voyage.get("project") or ""
    try:
        info = load_project_config(project) if project else None
        if info:
            branch = info.get("defaultBranch") or ""
            if branch:
                return branch
    except Exception:
        pass
    return _resolve_local_default_branch(cwd)


def _voyage_merge_verdict(voyage: dict, branch: str, cwd: "Path",
                          repo: Optional[str] = None) -> dict:
    """Merge verdict for a voyage: PR state first, raw git as the fallback.

    Returns ``{"verdict", "meta", "source"}``. ``source`` is ``"pr"`` when the
    GitHub PR record decided it and ``"git"`` when raw-git detection did —
    recorded on the manifest as ``mergeDetectedBy`` for provenance. ``verdict``
    is additionally ``"wrong_base"`` (BUG-MSO-2026-0547) when the PR merged but
    not into the project's default branch — the caller must not archive that
    as completion, only surface it.

    Precedence (AC: "prefers the GitHub PR state when a prNumber exists;
    commit-ancestry remains the fallback for PR-less voyages"):
      1. voyage has a prNumber AND the PR record is readable → that verdict.
      2. otherwise (no PR linked, or gh unavailable/offline) → the FTR-0373
         raw-git verdict, unchanged. An undeterminable raw-git verdict stays
         "unknown" so the caller leaves the voyage alone.
    """
    pr_number = _voyage_pr_number(voyage)
    if pr_number is not None:
        expected_base = _expected_default_branch(voyage, cwd)
        pv = _pr_authoritative_verdict(pr_number, cwd, repo, expected_base=expected_base)
        if pv["verdict"] != "unknown":
            pv["source"] = "pr"
            return pv
    gv = _git_merge_verdict(branch, cwd)
    return {"verdict": gv["verdict"], "meta": {}, "source": "git"}


def _reconcile_repo_root(ws: "Path") -> "Path":
    """The repo that merge-detection git/gh calls must run in.

    FTR-MSO-2026-0426: reconcile used ``ws.parent``. In solo/shared artefact
    mode that is the ARTEFACT repo — it carries no voyage branches and no PRs,
    so every probe returned "unknown" and reconcile archived nothing. Merge
    detection must target the PRODUCT repo. In embedded mode ``get_product_repo()``
    resolves to exactly ``ws.parent`` (the ``.mso`` parent IS the product repo),
    so this is a no-op there; an unresolvable product repo falls back to the old
    behaviour rather than raising.
    """
    try:
        root = get_product_repo()
        if root and Path(root).exists():
            return Path(root)
    except Exception:
        pass
    return ws.parent


def _sweep_note(report: Optional[list], voyage_id: str, action: str,
                reason: str, **extra) -> None:
    """Record one housekeeping decision on the sweep *report* (no-op if None).

    FTR-MSO-2026-0426: reconcile used to return only a count, so everything it
    REFUSED to touch — a stranded order, an unmerged PR, a voyage with no PR —
    vanished silently and the operator saw "0 voyages archived" with no reason.
    Every decision point now records why. ``action`` is one of ``archived``,
    ``annotated``, ``flagged``, ``linked`` or ``skipped``; ``reason`` is a
    human-readable explanation.
    """
    if report is None:
        return
    entry = {"voyage": voyage_id, "action": action, "reason": reason}
    entry.update({k: v for k, v in extra.items() if v is not None})
    report.append(entry)


def _flag_closed_without_merge(voyage: dict, voyage_file: "Path", vid: str,
                               dry_run: bool = False) -> bool:
    """Surface a closed-without-merge voyage for operator decision (scope 2).

    The remote branch is gone but base does NOT contain the branch's changes —
    the PR was closed WITHOUT merging. Do not archive it as merged: mark the
    manifest (``closedWithoutMerge`` + ``needsAttention`` so the Hub renders it
    in the ``needs_attention`` phase), emit a one-shot WARN, and leave it in
    active/ for a human. Returns True when it (re)surfaced, False if already
    flagged. Never raises.
    """
    if voyage.get("closedWithoutMerge") is True:
        return False  # already surfaced — don't WARN on every reconcile tick
    if dry_run:
        print_info(f"[dry-run] Would flag voyage {vid} as CLOSED-WITHOUT-MERGE "
                   f"(remote branch gone, changes absent from base)")
        return True
    voyage["closedWithoutMerge"] = True
    voyage["needsAttention"] = True
    voyage["attentionReason"] = (
        "PR closed without merging (remote branch deleted, changes absent from "
        "base) — reopen/re-dispatch or archive manually")
    try:
        voyage_file.write_text(json.dumps(voyage, indent=2), encoding="utf-8")
        _commit_lifecycle_transition(
            [voyage_file],
            f"lifecycle: flag {vid} closed-without-merge (FTR-0373)")
    except Exception:
        pass
    write_lifecycle_event(
        "WARN",
        f"Voyage {vid}: PR CLOSED WITHOUT MERGE — remote branch deleted but its "
        f"changes are absent from the base branch. NOT archived as merged; left "
        f"in active/ (needs_attention) for operator decision — reopen the PR / "
        f"re-dispatch, or archive manually. (FTR-MSO-2026-0373)")
    return True


def _settle_no_code_closed_pr(voyage: dict, voyage_file: "Path", vid: str,
                              pr_number: Optional[int],
                              dry_run: bool = False) -> bool:
    """Settle an ARCHIVED voyage whose PR closed without merging but carried
    no code deliverable (BUG-MSO-2026-0471).

    This is deliberately distinct from ``_flag_closed_without_merge``: that
    function assumes real work may have been lost and needs an operator
    decision. But a PLN/DOC-only voyage's branch carries nothing beyond
    artefact-plane bookkeeping (the same guard ``_maybe_auto_finalise_no_code_
    voyage`` already trusts, ``_branch_has_unmerged_source_changes``) — its
    actual deliverables were swept to main separately, so closing its PR
    without merging lost nothing. Flagging that ``needs_attention`` forever
    would be a permanent false alarm (this is exactly what happened to
    VOY-MSO-2026-0100). Instead this settles the voyage as the correct
    terminal state: sets ``closedNoCodeDeliverable`` (read by the Hub phase
    deriver as an alternate route to ``merged``, same precedence as an
    actual PR merge) and appends a ``completionNotes`` entry recording why.
    Returns True when it (re)settled, False if already settled.
    """
    if voyage.get("closedNoCodeDeliverable") is True:
        return False  # already settled — idempotent, no repeat lifecycle event
    if dry_run:
        print_info(f"[dry-run] Would settle voyage {vid} as CLOSED PR / NO CODE "
                   f"DELIVERABLE (planning-only — nothing lost)")
        return True
    voyage["closedNoCodeDeliverable"] = True
    notes = ("PR closed without merging, but the branch carried no code "
             "deliverable beyond artefact-plane bookkeeping (BUG-MSO-2026-0471) "
             "— planning-only voyage; nothing lost, settled as complete.")
    voyage["completionNotes"] = (
        f"{voyage['completionNotes']} | {notes}"
        if voyage.get("completionNotes") else notes)
    try:
        voyage_file.write_text(json.dumps(voyage, indent=2), encoding="utf-8")
        _commit_lifecycle_transition(
            [voyage_file],
            f"lifecycle: settle {vid} closed-PR no-code-deliverable (BUG-0471)")
    except Exception as exc:
        # The idempotency guard at the top of this function reads
        # closedNoCodeDeliverable back off the FILE, so a swallowed write
        # failure is not harmless: the next reconcile tick re-reads the
        # unmodified manifest, sees the flag still absent, and settles again —
        # emitting a fresh COMPLETE every tick for a voyage that was never
        # actually settled, and inflating the caller's annotated count each
        # time. Report the failure and return False (nothing was settled) so
        # the retry on the next tick is honest rather than a repeat of a
        # terminal event that never happened.
        write_lifecycle_event(
            "WARN",
            f"Voyage {vid}: could not persist closed-PR no-code-deliverable "
            f"settlement — {type(exc).__name__}: {exc}. NOT emitting COMPLETE; "
            f"will retry on the next reconcile tick.")
        return False
    write_lifecycle_event(
        "COMPLETE",
        f"Voyage {vid}: PR"
        f"{f' #{pr_number}' if pr_number else ''} closed without merging but "
        f"carried no code deliverable — settled as complete (planning-only, "
        f"BUG-MSO-2026-0471)")
    return True


def _maybe_auto_finalise_no_code_voyage(voyage: dict, voyage_file: "Path",
                                        ws: "Path", complete_dir: "Path",
                                        dry_run: bool = False) -> bool:
    """Auto-finalise a voyage that will never get a PR (BUG-MSO-2026-0360).

    A PLN/DOC-only voyage produces no code on its branch — its deliverables
    are swept to main as artefacts — so the reconcile loop's PR lookup finds
    nothing and the voyage sits in the Hub's Final Review bucket forever
    (VOY-MSO-2026-0094). When ALL its orders are archived COMPLETE and its
    branch carries no unmerged source changes (guard), archive the voyage to
    voyages/complete/ with completionNotes, clean up worktrees, and emit an
    AUTO_FINALISE lifecycle event. Returns True when finalised (or would be,
    in dry-run).
    """
    vid = voyage.get("voyageId") or voyage.get("id") or voyage_file.stem
    status = voyage.get("status")
    if status is not None and str(status).upper() not in (
            "ACTIVE", "PLANNED", "IN_PROGRESS"):
        return False  # HELD/PAUSED/PROPOSED/... — operator-managed, leave alone

    order_ids = _voyage_order_ids(voyage)
    if not order_ids:
        return False
    skipped = load_skipped_order_ids()
    complete_orders_dir = ws / "orders" / "complete"
    seen_complete = 0
    for oid in order_ids:
        if oid in skipped:
            # BUG-MSO-2026-0288: skipped stale orders count as satisfied.
            continue
        ofile = complete_orders_dir / f"{oid}.json"
        if not ofile.exists():
            return False
        try:
            odata = json.loads(ofile.read_text(encoding="utf-8"))
        except Exception:
            return False
        if str(odata.get("status") or "COMPLETE").upper() not in (
                "COMPLETE", "COMPLETED"):
            return False  # BUG-0296: STALLED-in-complete/ is NOT complete
        ovid = odata.get("voyageId") or ""
        if ovid and ovid != vid:
            return False  # BUG-ADM-2026-0010: cross-voyage id reuse
        seen_complete += 1
    if seen_complete == 0:
        return False

    branch = voyage.get("branch") or voyage.get("voyageBranch") or ""
    unmerged = _branch_has_unmerged_source_changes(branch)
    if unmerged is not False:
        if unmerged is True:
            write_lifecycle_event(
                "WARN",
                f"Voyage {vid}: all orders COMPLETE but branch {branch} carries "
                f"unmerged source changes — NOT auto-finalised; open/merge its "
                f"PR instead (BUG-0360 guard)")
        return False

    if dry_run:
        print_info(f"[dry-run] Would auto-finalise no-code voyage {vid} "
                   f"(all {len(order_ids)} orders COMPLETE, no source changes "
                   f"on {branch or '<no branch>'})")
        return True

    voyage["status"] = "COMPLETE"
    voyage.setdefault("completedAt", datetime.now().isoformat())
    notes = (f"Auto-finalised (BUG-MSO-2026-0360): no code deliverable on "
             f"{branch or '<no branch>'} — all {len(order_ids)} orders "
             f"COMPLETE; no PR required.")
    voyage["completionNotes"] = (
        f"{voyage['completionNotes']} | {notes}"
        if voyage.get("completionNotes") else notes)

    dest = complete_dir / voyage_file.name
    try:
        dest.write_text(json.dumps(voyage, indent=2), encoding="utf-8")
        voyage_file.unlink()
    except Exception as exc:
        write_lifecycle_event(
            "WARN", f"auto-finalise: failed to archive {vid}: {exc}")
        return False
    write_lifecycle_event(
        "AUTO_FINALISE",
        f"Voyage {vid} auto-finalised: no code deliverable — all orders "
        f"COMPLETE, no PR required (BUG-0360)")
    print_ok(f"Voyage {vid} auto-finalised (no code deliverable) -> voyages/complete/")
    _commit_lifecycle_transition(
        [dest, voyage_file],
        f"lifecycle: auto-finalise {vid} (no-code voyage, BUG-0360)")
    try:
        from maestro.core.worktrees import (
            cleanup_voyage_worktree,
            cleanup_all_crew_worktrees,
        )
        # BUG-MSO-2026-0389: git worktree ops must target the PRODUCT repo in
        # solo/shared mode (the artefact repo the dispatcher stands in has no
        # crew/admin worktrees registered). Embedded mode resolves None and the
        # call stays byte-identical (kwarg omitted).
        try:
            _clean_root = solo_worktree_repo_root()
        except Exception:
            _clean_root = None
        _ckw = {"repo_root": _clean_root} if _clean_root is not None else {}
        cleanup_all_crew_worktrees(vid, **_ckw)
        cleanup_voyage_worktree(vid, **_ckw)
    except Exception as wt_exc:
        print_warn(f"Worktree cleanup for {vid} failed: {wt_exc}")
    return True


# BUG-MSO-2026-0292: statuses that legitimately mean "this order is done" and may
# be swept to orders/complete/ when its voyage's PR is merged. Anything else
# (PENDING / IN_PROGRESS / BACKLOG / NAV_REVIEW_PENDING / STALLED / ...) is an order
# that did NOT complete — reconcile must NOT fabricate its completion.
_RECONCILE_COMPLETE_STATUSES = {"COMPLETE", "COMPLETED"}


def _reconcile_archive_order(order_file: "Path", vid: str, order_id: str,
                             report: Optional[list] = None) -> bool:
    """Archive a voyage's order to orders/complete/ on PR-merge — ONLY if it
    already reached a completion status (BUG-MSO-2026-0292).

    A merged voyage PR does NOT mean every order in the manifest ran: a voyage can
    list orders that never dispatched (no crew, no metadata). The pre-0292 reconcile
    blindly stamped status=COMPLETE on every listed order and moved it — fabricating
    completion of work that never happened. Now: only an order already COMPLETE/
    COMPLETED is archived; any non-complete order is left in place with a loud WARN.
    Returns True if archived.
    """
    try:
        odata = json.loads(order_file.read_text(encoding="utf-8"))
    except Exception:
        return False
    st = str(odata.get("status") or "").upper()
    if st not in _RECONCILE_COMPLETE_STATUSES:
        _sweep_note(report, vid, "skipped",
                    f"order {order_id} is {st or 'UNKNOWN'}, not COMPLETE — "
                    f"refused to archive it (a merged PR does not mean every "
                    f"listed order actually ran); recover it with "
                    f"`mso order retry {order_id}`",
                    order=order_id, orderStatus=st or "UNKNOWN")
        write_lifecycle_event(
            "WARN",
            f"reconcile: voyage {vid} PR merged but order {order_id} is "
            f"status={st or 'UNKNOWN'} (not COMPLETE) — NOT archived / NOT marked "
            f"complete (would fabricate completion of an order that didn't run). "
            f"Left in place for investigation. (BUG-MSO-2026-0292)"
        )
        return False
    try:
        dest_o = get_artefact_root() / "orders" / "complete" / order_file.name
        dest_o.parent.mkdir(parents=True, exist_ok=True)
        dest_o.write_text(json.dumps(odata, indent=2), encoding="utf-8")
        order_file.unlink()
        return True
    except Exception:
        return False


def reconcile_merged_voyages(
    on_complete_cfg: Optional[dict] = None,
    dry_run: bool = False,
    voyage_id_filter: Optional[str] = None,
    repo_filter: Optional[str] = None,
    report: Optional[list] = None,
) -> int:
    """Reconcile active voyages whose PR has been merged.

    Scans ``.mso/voyages/active/*.json``. For each voyage, resolves its branch
    PR via ``gh pr view``. If the PR is merged and ``archiveVoyageOnMerge`` is
    True:
      - Marks voyage COMPLETED with mergedPR/mergeCommit/mergedAt metadata
      - git-moves the JSON active/ -> complete/
      - Optionally sweeps order JSONs (orders/active -> orders/complete) and
        prompt files (prompts/active -> prompts/complete)

    FTR-MSO-2026-0379 (voyage-spans-repos): a voyage that spans >1 repo
    (``len(targetRepos) > 1``) has one PR per repo — it archives ONLY when
    EVERY repo's PR is merged. A partial merge keeps the voyage in final_review
    and records per-repo merge state under ``prUrls[repo]``. ``repo_filter``
    narrows the per-repo PR lookups to a single repo slug (optional).

    FTR-MSO-2026-0426: merge detection is PR-state-authoritative (see
    ``_voyage_merge_verdict``) so squash-merged voyages are detected instead of
    looking permanently unmerged, and the git/gh probes run in the PRODUCT repo
    (``_reconcile_repo_root``) rather than the artefact repo. Pass a list as
    *report* to collect a structured record of every decision — what was
    changed AND what was refused, with reasons.

    Returns count of voyages archived (or, in dry-run, the count that WOULD be
    archived — no files are moved).
    Safe when ``gh`` is unavailable (skips with a WARN lifecycle event).
    Idempotent: voyages already in complete/ are ignored.
    """
    if on_complete_cfg is None:
        on_complete_cfg = load_completion_config()["onVoyageComplete"]

    archive_voyage = on_complete_cfg.get("archiveVoyageOnMerge", True)
    archive_orders = on_complete_cfg.get("archiveOrders", True)

    if not archive_voyage:
        _sweep_note(report, "*", "skipped",
                    "archiveVoyageOnMerge is disabled in workspace.json "
                    "(completion.onVoyageComplete) — nothing was examined")
        return 0

    ws = get_artefact_root()
    active_dir = ws / "voyages" / "active"
    complete_dir = ws / "voyages" / "complete"
    if not active_dir.exists():
        return 0

    complete_dir.mkdir(parents=True, exist_ok=True)
    # FTR-MSO-2026-0426: probe the PRODUCT repo, not the artefact repo.
    repo_root = _reconcile_repo_root(ws)

    archived = 0
    for voyage_file in sorted(active_dir.glob("*.json")):
        try:
            voyage = json.loads(voyage_file.read_text(encoding="utf-8"))
        except Exception:
            continue

        vid = voyage.get("id", voyage_file.stem)
        if voyage_id_filter and vid != voyage_id_filter:
            continue

        branch = voyage.get("branch", "")
        if not branch:
            # BUG-MSO-2026-0360: a branchless voyage can never get a PR — if
            # all its orders are done it is a no-code voyage; finalise it.
            if _maybe_auto_finalise_no_code_voyage(voyage, voyage_file, ws,
                                                   complete_dir, dry_run):
                archived += 1
                _sweep_note(report, vid, "archived",
                            "no branch and all orders COMPLETE — auto-finalised "
                            "as a no-code voyage (BUG-0360)")
            else:
                _sweep_note(report, vid, "skipped",
                            "voyage has no branch (so can never get a PR) and "
                            "its orders are not all archived COMPLETE")
            continue

        # FTR-MSO-2026-0379: a voyage spanning >1 repo has one PR per repo and
        # archives only when ALL of them merge. Legacy single-repo voyages
        # (0 or 1 repo slug) keep the flat gh-pr-view path below unchanged.
        if len(_voyage_repo_slugs(voyage)) > 1:
            if _reconcile_multi_repo_voyage(
                    voyage, voyage_file, ws, complete_dir, vid,
                    archive_orders, dry_run, repo_filter):
                archived += 1
                _sweep_note(report, vid, "archived",
                            "multi-repo voyage — every repo's PR is merged",
                            repos=sorted(_voyage_repo_slugs(voyage)))
            else:
                _sweep_note(report, vid, "skipped",
                            "multi-repo voyage — not every repo's PR is merged "
                            "yet; left in final review",
                            repos=sorted(_voyage_repo_slugs(voyage)))
            continue

        # FTR-MSO-2026-0373: host-neutral raw-git merge detection is PRIMARY;
        # gh is optional metadata enrichment only. This restores reconciliation
        # for GitLab / Bitbucket / plain-git customers who never had `gh`. Only
        # the definite "merged" and "closed" verdicts short-circuit here — an
        # "open"/"unknown" verdict falls through to the legacy gh path below
        # (which still handles OPEN-PR linkage backfill, CONFLICTING surfacing,
        # and no-code auto-finalise, all of which are inherently gh-dependent).
        # FTR-MSO-2026-0426: PR state first (squash-merge-proof), raw git
        # second. `source` records which one decided, for provenance.
        resolved = _voyage_merge_verdict(voyage, branch, repo_root)
        verdict = {"verdict": resolved["verdict"]}
        detected_by = resolved.get("source") or "git"

        if verdict["verdict"] == "merged":
            meta = resolved.get("meta") or {}
            if meta:
                # Decided by the PR record — it already carries the metadata.
                merge_commit = meta.get("mergeCommit") or ""
                merged_at = meta.get("mergedAt") or ""
                pr_number = meta.get("number")
                pr_url = meta.get("url") or ""
            else:
                enrich = _gh_pr_view(branch, repo_root) or {}
                mc = enrich.get("mergeCommit")
                merge_commit = mc.get("oid", "") if isinstance(mc, dict) else ""
                merged_at = enrich.get("mergedAt") or ""
                pr_number = enrich.get("number")
                pr_url = enrich.get("url") or ""
            if dry_run:
                print_info(
                    f"[dry-run] Would archive merged voyage {vid} "
                    f"({detected_by}-detected"
                    f"{f', PR #{pr_number}' if pr_number else ''})")
                _sweep_note(report, vid, "archived",
                            f"PR is merged (detected via {detected_by})",
                            prNumber=pr_number, mergedAt=merged_at or None)
                archived += 1
                continue
            voyage["status"] = "COMPLETED"
            if pr_number is not None:
                voyage["mergedPR"] = pr_number
            voyage["mergeCommit"] = merge_commit
            voyage["mergedAt"] = merged_at
            voyage["completedAt"] = datetime.now().isoformat()
            voyage["mergeDetectedBy"] = detected_by  # "pr" or "git"
            _apply_pr_linkage(voyage, pr_number, pr_url)
            dest = complete_dir / voyage_file.name
            try:
                dest.write_text(json.dumps(voyage, indent=2), encoding="utf-8")
                voyage_file.unlink()
                write_lifecycle_event(
                    "COMPLETE",
                    f"Reconcile archived merged voyage {vid} ({detected_by} merge "
                    f"detection{f', PR #{pr_number}' if pr_number else ''})")
                archived += 1
                _sweep_note(report, vid, "archived",
                            f"PR is merged (detected via {detected_by})",
                            prNumber=pr_number, mergedAt=merged_at or None)
            except Exception as exc:
                write_lifecycle_event(
                    "WARN", f"reconcile: failed to archive {vid}: {exc}")
                _sweep_note(report, vid, "skipped",
                            f"detected as merged but archiving failed: {exc}")
                continue
            if archive_orders:
                _sweep_voyage_orders_and_prompts(voyage, ws, vid)
            continue

        if verdict["verdict"] == "closed":
            # Scope 2: PR closed WITHOUT merging — surface for operator decision,
            # never archive as merged.
            _flag_closed_without_merge(voyage, voyage_file, vid, dry_run)
            _sweep_note(report, vid, "flagged",
                        "PR was CLOSED WITHOUT MERGING — refused to archive as "
                        "merged; left in active/ for an operator decision "
                        "(reopen/re-dispatch, or archive manually)",
                        prNumber=_voyage_pr_number(voyage))
            continue

        if verdict["verdict"] == "wrong_base":
            # BUG-MSO-2026-0547: the PR merged, but into a branch other than the
            # project's default branch (e.g. staging/develop) — the voyage's
            # work has NOT landed. Never archive; surface it loudly so an
            # operator doesn't mistake this for completion (the PSG incident:
            # a WARN elsewhere read like data corruption when the real fault
            # was this undetected mismatch). Deduped via the manifest so this
            # doesn't WARN on every reconcile tick.
            meta = resolved.get("meta") or {}
            pr_number = meta.get("number")
            base_ref = meta.get("baseRefName") or "?"
            expected_base = meta.get("expectedBase") or "?"
            if voyage.get("mergedToWrongBaseWarned") != pr_number:
                write_lifecycle_event(
                    "WARN",
                    f"Voyage {vid}: PR #{pr_number} is MERGED but into "
                    f"'{base_ref}', not the project's default branch "
                    f"'{expected_base}' — NOT treated as voyage completion. "
                    f"The change set has not reached '{expected_base}' yet. "
                    f"(BUG-MSO-2026-0547)")
                if not dry_run:
                    voyage["mergedToWrongBaseWarned"] = pr_number
                    try:
                        voyage_file.write_text(
                            json.dumps(voyage, indent=2), encoding="utf-8")
                    except Exception:
                        pass
            _sweep_note(report, vid, "skipped",
                        f"PR #{pr_number} merged into '{base_ref}', not the "
                        f"project's default branch '{expected_base}' — refused "
                        f"to archive as complete",
                        prNumber=pr_number)
            continue

        # Check PR state via gh (fallback for "open"/"unknown" verdicts; also the
        # sole path when raw git can't decide — e.g. gh-hosted repo whose local
        # base ref is stale). gh remains OPTIONAL: its absence is handled below.
        try:
            gh_result = run_hidden(
                ["gh", "pr", "view", branch, "--json",
                 "state,mergeCommit,mergedAt,number,mergeable,url"],
                capture_output=True, text=True, timeout=30,
                # FTR-MSO-2026-0426: the PRODUCT repo — in solo/shared mode the
                # artefact repo has no PRs, so gh found nothing and every voyage
                # fell through to "no PR" forever.
                cwd=str(repo_root),
            )
            if gh_result.returncode != 0:
                # No PR found — not an error. BUG-MSO-2026-0360: a finished
                # no-code voyage (PLN/DOC-only) will NEVER get one — finalise
                # it instead of leaving it in final_review forever.
                if _maybe_auto_finalise_no_code_voyage(voyage, voyage_file, ws,
                                                       complete_dir, dry_run):
                    archived += 1
                    _sweep_note(report, vid, "archived",
                                "no PR exists and all orders are COMPLETE — "
                                "auto-finalised as a no-code voyage (BUG-0360)")
                else:
                    _sweep_note(report, vid, "skipped",
                                f"no PR found for branch '{branch}' and the "
                                f"voyage is not finalisable (orders not all "
                                f"archived COMPLETE, or its branch still "
                                f"carries unmerged source changes)")
                continue
            pr_data = json.loads(gh_result.stdout)
        except FileNotFoundError:
            write_lifecycle_event("WARN", "reconcile_merged_voyages: gh not available — skipping")
            _sweep_note(report, vid, "skipped",
                        "gh CLI is not available — cannot confirm PR state. "
                        "Merge status is UNKNOWN (never assumed merged); "
                        "remaining voyages were not examined")
            return archived
        except Exception as exc:
            write_lifecycle_event("WARN", f"reconcile_merged_voyages: gh call failed for {vid}: {exc}")
            _sweep_note(report, vid, "skipped",
                        f"gh call failed ({exc}) — merge status UNKNOWN, "
                        f"never assumed merged")
            continue

        if pr_data.get("state") != "MERGED":
            linkage_changed = False
            warn_changed = False
            # BUG-MSO-2026-0360: backfill missing prNumber/prUrl for an active
            # voyage with an OPEN PR so the Hub's Final Review bucket renders
            # the PR link/merge CTA (heals historical voyages like VOY-0089).
            if pr_data.get("state") == "OPEN":
                if dry_run:
                    if _apply_pr_linkage(dict(voyage), pr_data.get("number"),
                                         pr_data.get("url") or ""):
                        print_info(f"[dry-run] Would backfill PR "
                                   f"#{pr_data.get('number')} linkage on {vid}")
                elif _apply_pr_linkage(voyage, pr_data.get("number"),
                                       pr_data.get("url") or ""):
                    linkage_changed = True
                    write_lifecycle_event(
                        "PR_LINKED",
                        f"reconcile: backfilled PR #{pr_data.get('number')} "
                        f"onto {vid} manifest (BUG-0360)")
            # BUG-MSO-2026-0292/0290: an OPEN voyage PR that has gone CONFLICTING
            # is silently CI-dead — GitHub won't run pull_request CI on a PR whose
            # merge commit can't be computed, so a finished voyage can sit with an
            # unverifiable PR and no signal. Surface it (deduped via the voyage JSON
            # so we don't WARN every reconcile tick).
            if pr_data.get("state") == "OPEN" and pr_data.get("mergeable") == "CONFLICTING":
                if voyage.get("prConflictWarned") != pr_data.get("number"):
                    write_lifecycle_event(
                        "WARN",
                        f"Voyage {vid} PR #{pr_data.get('number')} is CONFLICTING — "
                        f"GitHub will not run its CI until the conflict is resolved "
                        f"(merge main into the voyage branch). (BUG-MSO-2026-0290)"
                    )
                    voyage["prConflictWarned"] = pr_data.get("number")
                    warn_changed = True
            if linkage_changed or warn_changed:
                try:
                    voyage_file.write_text(json.dumps(voyage, indent=2), encoding="utf-8")
                    if linkage_changed:
                        _commit_lifecycle_transition(
                            [voyage_file],
                            f"lifecycle: link PR #{pr_data.get('number')} to {vid}")
                except Exception:
                    pass
            if linkage_changed:
                _sweep_note(report, vid, "linked",
                            "backfilled the open PR's number/URL onto the "
                            "voyage manifest so the Hub can render it",
                            prNumber=pr_data.get("number"))
            _sweep_note(report, vid, "skipped",
                        f"PR #{pr_data.get('number')} is "
                        f"{str(pr_data.get('state') or 'not merged').upper()}"
                        f"{' and CONFLICTING' if pr_data.get('mergeable') == 'CONFLICTING' else ''}"
                        f" — refused to archive an unmerged voyage",
                        prNumber=pr_data.get("number"))
            continue

        merge_commit = (pr_data.get("mergeCommit") or {}).get("oid", "")
        merged_at = pr_data.get("mergedAt", "")
        pr_number = pr_data.get("number")

        if dry_run:
            print_info(f"[dry-run] Would archive merged voyage {vid} (PR #{pr_number}, merged {merged_at})")
            _sweep_note(report, vid, "archived",
                        "PR is merged (detected via gh pr view)",
                        prNumber=pr_number, mergedAt=merged_at or None)
            archived += 1  # count would-be archives so the CLI's "N would be archived" is accurate
            continue

        # Update voyage JSON with merge metadata
        voyage["status"] = "COMPLETED"
        voyage["mergedPR"] = pr_number
        voyage["mergeCommit"] = merge_commit
        voyage["mergedAt"] = merged_at
        voyage["completedAt"] = datetime.now().isoformat()
        # BUG-MSO-2026-0360: carry the PR linkage onto the archived manifest too.
        _apply_pr_linkage(voyage, pr_number, pr_data.get("url") or "")

        dest = complete_dir / voyage_file.name
        try:
            dest.write_text(json.dumps(voyage, indent=2), encoding="utf-8")
            voyage_file.unlink()
            write_lifecycle_event("COMPLETE",
                f"Reconcile archived merged voyage {vid} (PR #{pr_number})")
            archived += 1
            _sweep_note(report, vid, "archived",
                        "PR is merged (detected via gh pr view)",
                        prNumber=pr_number, mergedAt=merged_at or None)
        except Exception as exc:
            write_lifecycle_event("WARN", f"reconcile: failed to archive {vid}: {exc}")
            _sweep_note(report, vid, "skipped",
                        f"PR #{pr_number} is merged but archiving failed: {exc}",
                        prNumber=pr_number)
            continue

        if archive_orders:
            _sweep_voyage_orders_and_prompts(voyage, ws, vid, report=report)

    return archived


def _sweep_voyage_orders_and_prompts(voyage: dict, ws: "Path", vid: str,
                                     report: Optional[list] = None) -> None:
    """Sweep a completed voyage's order JSONs + prompt files into complete/.

    Extracted from ``reconcile_merged_voyages`` (FTR-MSO-2026-0379) so both the
    single-repo and the multi-repo (all-PRs-merged) archive paths reuse it.
    BUG-MSO-2026-0292 semantics preserved: only ALREADY-complete orders move.
    """
    order_ids: List[str] = []
    for order_ref in voyage.get("orders", []):
        if isinstance(order_ref, str):
            order_ids.append(order_ref)
        elif isinstance(order_ref, dict):
            oid = order_ref.get("orderId") or order_ref.get("id")
            if oid:
                order_ids.append(oid)

    # Same queue set scan_all_queues() searches — including defects/breakdown/
    # high-level and every requests/<category>/ subdir. NOT escalations (those
    # aren't order files).
    queue_dirs = [ws / "queues" / q for q in
                  ("explicit", "security", "bugs", "orders",
                   "defects", "breakdown", "high-level")]
    requests_root = ws / "queues" / "requests"
    if requests_root.exists():
        queue_dirs += [d for d in requests_root.iterdir() if d.is_dir()]
    for queue_dir in queue_dirs:
        if not queue_dir.exists():
            continue
        for order_id in order_ids:
            order_file = queue_dir / f"{order_id}.json"
            if order_file.exists():
                # BUG-MSO-2026-0292: only archive if already complete.
                _reconcile_archive_order(order_file, vid, order_id, report)

    for order_id in order_ids:
        f = ws / "orders" / "active" / f"{order_id}.json"
        if f.exists():
            # BUG-MSO-2026-0292: only archive if already complete.
            _reconcile_archive_order(f, vid, order_id, report)

        # Prompt sweep — prompts are generated as {order_id}-{role}.md
        # (generate_prompt_for_item), so move ALL files for this order id, not
        # just a bare {order_id}.md (which never exists).
        prompts_active = ws / "prompts" / "active"
        if prompts_active.exists():
            matches = list(prompts_active.glob(f"{order_id}-*.md")) + \
                      list(prompts_active.glob(f"{order_id}.md"))
            for prompt_src in matches:
                try:
                    dest_p = ws / "prompts" / "complete" / prompt_src.name
                    dest_p.parent.mkdir(parents=True, exist_ok=True)
                    prompt_src.replace(dest_p)  # BUG-MSO-2026-0291: overwrite-safe
                except Exception:
                    pass


def _resolve_pr_state_verdict(branch: str, cwd: "Path", repo: Optional[str] = None,
                              pr_number: Optional[int] = None) -> dict:
    """Full merge-state verdict for a completed voyage's PR (PR-state-first,
    git fallback, branch-keyed gh as the last resort).

    Same detection chain ``_resolve_pr_merge_state`` has always used
    (PR-number lookup -> raw-git content-equality -> branch-keyed
    ``gh pr view``), but returns the VERDICT itself (``"merged"``/``"closed"``/
    ``"open"``/``"unknown"``) instead of collapsing everything but "merged" to
    ``None``. BUG-MSO-2026-0471: ``reconcile_completed_voyage_pr_merges``
    needs the "closed" distinction to act on a closed-without-merge PR instead
    of silently skipping it forever; ``_resolve_pr_merge_state`` stays the
    thin merged-or-None wrapper its other callers already depend on.

    Returns ``{"verdict", "mergeCommit", "mergedAt", "number"}`` — the merge
    fields are only populated when ``verdict == "merged"``.
    """
    branch = (branch or "").replace("refs/heads/", "")
    if pr_number is not None:
        pv = _pr_authoritative_verdict(pr_number, cwd, repo)
        if pv["verdict"] == "merged":
            meta = pv["meta"]
            return {"verdict": "merged",
                    "mergeCommit": meta.get("mergeCommit") or "",
                    "mergedAt": meta.get("mergedAt") or "",
                    "number": meta.get("number")}
        if pv["verdict"] in ("open", "closed"):
            return {"verdict": pv["verdict"]}  # definitively decided — never fabricate a merge
    if not branch:
        return {"verdict": "unknown"}
    verdict = _git_merge_verdict(branch, cwd)
    if verdict["verdict"] == "merged":
        enrich = _gh_pr_view(branch, cwd, repo=repo) or {}
        return {"verdict": "merged",
                "mergeCommit": (enrich.get("mergeCommit") or {}).get("oid", ""),
                "mergedAt": enrich.get("mergedAt") or "",
                "number": enrich.get("number")}
    if verdict["verdict"] == "closed":
        return {"verdict": "closed"}  # closed without merging — never fabricate a merge
    # open/unknown → gh fallback (branch-keyed)
    pr_data = _gh_pr_view(branch, cwd, repo=repo)
    if pr_data and pr_data.get("state") == "MERGED":
        return {"verdict": "merged",
                "mergeCommit": (pr_data.get("mergeCommit") or {}).get("oid", ""),
                "mergedAt": pr_data.get("mergedAt", ""),
                "number": pr_data.get("number")}
    if pr_data and pr_data.get("state") == "CLOSED":
        return {"verdict": "closed"}
    return {"verdict": verdict["verdict"]}  # "open" or "unknown", as raw git saw it


def _resolve_pr_merge_state(branch: str, cwd: "Path", repo: Optional[str] = None,
                            pr_number: Optional[int] = None) -> Optional[dict]:
    """Resolve whether a voyage's PR is MERGED (PR-state-first, git fallback).

    Returns ``{"mergeCommit", "mergedAt", "number"}`` when the PR is
    definitively merged, or ``None`` for open/closed-without-merge/unknown/
    gh-unavailable. Thin wrapper around ``_resolve_pr_state_verdict`` — kept
    as its own function because most callers only care about merged-or-not.
    """
    resolved = _resolve_pr_state_verdict(branch, cwd, repo, pr_number)
    if resolved["verdict"] != "merged":
        return None
    return {"mergeCommit": resolved.get("mergeCommit", ""),
            "mergedAt": resolved.get("mergedAt", ""),
            "number": resolved.get("number")}


def reconcile_completed_voyage_pr_merges(
    dry_run: bool = False,
    voyage_id_filter: Optional[str] = None,
    repo_filter: Optional[str] = None,
    report: Optional[list] = None,
) -> int:
    """Backfill merge metadata onto voyages already archived to complete/.

    BUG-MSO-2026-0411: a voyage auto-finalises to COMPLETE the moment its
    last order finishes (BUG-MSO-2026-0360), which routinely happens BEFORE
    the human merges its PR. ``reconcile_merged_voyages`` only scans
    ``voyages/active/`` — once a voyage lands in ``voyages/complete/`` WITHOUT
    ``mergedAt``, a later PR merge previously never got recorded, so the Hub
    phase deriver (BUG-MSO-2026-0394) buckets it as ``final_review`` forever
    even though the PR merged.

    This scans ``voyages/complete/`` for voyages that already have a linked
    PR (flat ``prNumber``/``prUrl``, or a non-empty ``prUrls`` map) but no
    ``mergedAt``, resolves each linked PR's merge state via
    ``_resolve_pr_state_verdict`` (same raw-git-first / gh-fallback mechanism
    as the active path), and writes ``merged=True`` + ``mergedAt`` (+
    ``mergeCommit``/``mergedPR``) when merged. Never moves files — the
    voyage is already archived. Multi-repo voyages (``prUrls`` map) are
    checked per-repo; the voyage-level ``mergedAt`` is only stamped once
    every linked repo reports MERGED.

    BUG-MSO-2026-0471: an archived voyage whose linked PR is CLOSED without
    merging no longer sits in ``skipped`` limbo forever. It is resolved
    instead of just recorded: a branch with no real (non-bookkeeping) source
    changes lost nothing when its PR closed (a planning-only voyage) and is
    settled straight to complete (``closedNoCodeDeliverable``, see
    ``_settle_no_code_closed_pr``); a branch that genuinely carries unmerged
    work is flagged ``needs_attention`` for a human (``closedWithoutMerge``,
    see ``_flag_closed_without_merge`` — same flag the active-voyage path
    already uses). An OPEN PR, or a voyage with no PR linked yet, is left
    untouched. Safe when ``gh``/``git`` are unavailable.

    Returns the count of voyages annotated/settled (or, in dry-run, the count
    that WOULD be). Flags (needs_attention) are recorded on the *report* but
    do not count toward this return value — mirroring ``reconcile_merged_
    voyages``'s ``archived`` count, which also excludes flags.
    """
    ws = get_artefact_root()
    complete_dir = ws / "voyages" / "complete"
    if not complete_dir.exists():
        return 0
    # FTR-MSO-2026-0426: probe the PRODUCT repo, not the artefact repo.
    repo_root = _reconcile_repo_root(ws)

    annotated = 0
    for voyage_file in sorted(complete_dir.glob("*.json")):
        try:
            voyage = json.loads(voyage_file.read_text(encoding="utf-8"))
        except Exception:
            continue

        vid = voyage.get("id", voyage_file.stem)
        if voyage_id_filter and vid != voyage_id_filter:
            continue
        if voyage.get("mergedAt"):
            continue  # already annotated — idempotent

        branch = (voyage.get("branch") or voyage.get("voyageBranch") or "").replace("refs/heads/", "")
        if not branch:
            continue

        repo_slugs = [r for r in _voyage_repo_slugs(voyage)
                      if _repo_filter_matches(r, repo_filter or "")]

        if repo_slugs and isinstance(voyage.get("prUrls"), dict):
            if _annotate_completed_multi_repo_voyage(
                    voyage, voyage_file, ws, vid, branch, repo_slugs, dry_run):
                annotated += 1
            continue

        pr_number = voyage.get("prNumber")
        pr_url = voyage.get("prUrl") or voyage.get("pr_url")
        if pr_number is None and not pr_url:
            continue  # no PR linked yet — nothing for this pass to verify

        try:
            resolved = _resolve_pr_state_verdict(
                branch, repo_root, pr_number=_voyage_pr_number(voyage))
        except Exception as exc:
            write_lifecycle_event(
                "WARN", f"reconcile_completed_voyage_pr_merges: merge check failed for {vid}: {exc}")
            _sweep_note(report, vid, "skipped",
                        f"merge check failed ({exc}) — merge status UNKNOWN, "
                        f"never assumed merged")
            continue

        verdict = resolved.get("verdict")

        if verdict == "closed":
            # BUG-MSO-2026-0471: an archived voyage whose PR closed without
            # merging used to dead-end here forever — "skipped" every tick,
            # with no route back for the operator (VOY-MSO-2026-0100). Decide
            # the correct end state instead of only recording a refusal: a
            # branch carrying no real (non-bookkeeping) changes lost nothing
            # when its PR closed — a planning-only voyage, the same guard
            # BUG-0360's auto-finalise already trusts — so settle it as
            # complete. A branch with real unmerged changes needs a human,
            # same treatment as the active-voyage FTR-0373 path.
            unmerged = _branch_has_unmerged_source_changes(branch)
            if unmerged is False:
                if _settle_no_code_closed_pr(voyage, voyage_file, vid,
                                             pr_number, dry_run):
                    annotated += 1
                    _sweep_note(
                        report, vid, "annotated",
                        "already archived; PR closed without merging but the "
                        "branch carried no code deliverable (planning-only) "
                        "— settled as complete",
                        prNumber=pr_number)
                else:
                    _sweep_note(
                        report, vid, "skipped",
                        "already settled as closed-PR/no-code-deliverable — "
                        "nothing to do", prNumber=pr_number)
            else:
                reason = ("carries real unmerged source changes" if unmerged
                          else "the unmerged-source-change check was "
                               "inconclusive — treated conservatively")
                if _flag_closed_without_merge(voyage, voyage_file, vid, dry_run):
                    _sweep_note(
                        report, vid, "flagged",
                        f"already archived; PR closed without merging and "
                        f"{reason} — flagged needs_attention for an operator "
                        f"decision", prNumber=pr_number)
                else:
                    _sweep_note(
                        report, vid, "skipped",
                        "already flagged closed-without-merge — nothing to do",
                        prNumber=pr_number)
            continue

        if verdict != "merged":
            _sweep_note(report, vid, "skipped",
                        f"already archived, but PR "
                        f"{f'#{pr_number} ' if pr_number else ''}is not merged "
                        f"(or its state could not be confirmed) — no merge "
                        f"metadata written",
                        prNumber=pr_number)
            continue

        merged = resolved
        resolved_number = merged.get("number") if merged.get("number") is not None else pr_number

        if dry_run:
            print_info(f"[dry-run] Would annotate merged PR on completed voyage {vid} "
                        f"(PR #{resolved_number})")
            _sweep_note(report, vid, "annotated",
                        "already archived and its PR is merged — recorded the "
                        "merge metadata so it leaves Final Review",
                        prNumber=resolved_number,
                        mergedAt=merged.get("mergedAt") or None)
            annotated += 1
            continue

        voyage["merged"] = True
        voyage["mergedAt"] = merged["mergedAt"]
        voyage["mergeCommit"] = merged["mergeCommit"]
        voyage["mergedPR"] = resolved_number
        try:
            voyage_file.write_text(json.dumps(voyage, indent=2), encoding="utf-8")
            write_lifecycle_event(
                "COMPLETE",
                f"Reconcile annotated merge metadata on completed voyage {vid} "
                f"(PR #{resolved_number})")
            annotated += 1
            _sweep_note(report, vid, "annotated",
                        "already archived and its PR is merged — recorded the "
                        "merge metadata so it leaves Final Review",
                        prNumber=resolved_number,
                        mergedAt=merged.get("mergedAt") or None)
        except Exception as exc:
            write_lifecycle_event("WARN", f"reconcile: failed to annotate {vid}: {exc}")
            _sweep_note(report, vid, "skipped",
                        f"PR #{resolved_number} is merged but writing the "
                        f"metadata failed: {exc}", prNumber=resolved_number)

    return annotated


_SWEEP_CHANGE_ACTIONS = {"archived", "annotated", "linked"}


def run_housekeeping_sweep(
    dry_run: bool = False,
    voyage_id_filter: Optional[str] = None,
    repo_filter: Optional[str] = None,
) -> dict:
    """Run the full housekeeping reconcile and return a structured report.

    FTR-MSO-2026-0426. THE single entry point for housekeeping — ``mso voyage
    reconcile`` and the Hub's sweep button both call this, so the CLI and the
    button cannot drift apart or produce different results. It is exactly the
    existing reconcile pair (active-voyage archive + completed-voyage merge
    annotation), wrapped so callers get a machine-readable account of the run
    instead of a bare count.

    The Captain's framing: the human approves and merges the PR most of the
    time, so Maestro never observes the merge event. Housekeeping therefore has
    to be PULL-based — something an operator triggers, not something that only
    happens if a dispatcher happens to be running. Nothing here requires a
    dispatcher.

    Returns::

        {"dryRun", "archived", "annotated",
         "changes": [...],    # what it DID (or would do)
         "refusals": [...],   # what it REFUSED to touch, each with a reason
         "entries":  [...]}   # both, in the order they were decided
    """
    report: List[dict] = []
    cfg = load_completion_config()["onVoyageComplete"]
    archived = reconcile_merged_voyages(
        on_complete_cfg=cfg, dry_run=dry_run,
        voyage_id_filter=voyage_id_filter, repo_filter=repo_filter,
        report=report)
    annotated = reconcile_completed_voyage_pr_merges(
        dry_run=dry_run, voyage_id_filter=voyage_id_filter,
        repo_filter=repo_filter, report=report)
    return {
        "dryRun": bool(dry_run),
        "archived": archived,
        "annotated": annotated,
        "changes": [e for e in report
                    if e.get("action") in _SWEEP_CHANGE_ACTIONS],
        "refusals": [e for e in report
                     if e.get("action") not in _SWEEP_CHANGE_ACTIONS],
        "entries": report,
    }


def _annotate_completed_multi_repo_voyage(
    voyage: dict,
    voyage_file: "Path",
    ws: "Path",
    vid: str,
    branch: str,
    repos: List[str],
    dry_run: bool,
) -> bool:
    """Per-repo merge-state annotation for a completed multi-repo voyage.

    BUG-MSO-2026-0411. Mirrors ``_reconcile_multi_repo_voyage``'s per-repo PR
    lookup but never archives (the voyage is already in ``voyages/complete/``)
    — it backfills ``mergedAt``/``mergeCommit`` onto each merged
    ``prUrls[repo]`` entry, and only stamps the voyage-level ``mergedAt`` once
    every repo that has a PR linked reports MERGED. Returns True when the
    voyage was (or, in dry-run, would be) fully annotated as merged.
    """
    prurls = voyage.get("prUrls")
    if not isinstance(prurls, dict):
        return False

    project = voyage.get("project") or ""
    try:
        org = _load_workspace_org(project)
    except Exception:
        org = ""

    linked_repos = [r for r in repos
                     if isinstance(prurls.get(r), dict)
                     and (prurls[r].get("prNumber") or prurls[r].get("prUrl"))]
    if not linked_repos:
        return False

    changed = False
    merged_ats: List[str] = []
    all_merged = True

    for repo in linked_repos:
        entry = prurls[repo]
        if entry.get("state") == "MERGED" and entry.get("mergedAt"):
            merged_ats.append(entry["mergedAt"])
            continue
        full_repo = _resolve_full_repo_slug(repo, org) if org else repo
        try:
            repo_cwd = get_product_repo(repo)
        except Exception:
            repo_cwd = ws.parent
        try:
            merged = _resolve_pr_merge_state(branch, repo_cwd, repo=full_repo)
        except Exception as exc:
            write_lifecycle_event(
                "WARN", f"reconcile_completed_voyage_pr_merges: merge check failed "
                        f"for {vid} ({repo}): {exc}")
            all_merged = False
            continue
        if merged is None:
            all_merged = False
            continue
        merged_ats.append(merged["mergedAt"])
        if dry_run:
            continue
        entry = dict(entry)
        entry["state"] = "MERGED"
        entry["mergedAt"] = merged["mergedAt"]
        entry["mergeCommit"] = merged["mergeCommit"]
        prurls[repo] = entry
        changed = True

    if not all_merged:
        # Partial merge — persist whichever per-repo states we DID learn, but
        # never stamp voyage-level mergedAt until every linked repo merges.
        if changed and not dry_run:
            voyage["prUrls"] = prurls
            try:
                voyage_file.write_text(json.dumps(voyage, indent=2), encoding="utf-8")
            except Exception as exc:
                write_lifecycle_event("WARN", f"reconcile: failed to annotate {vid}: {exc}")
        return False

    if dry_run:
        return True

    voyage["prUrls"] = prurls
    voyage["merged"] = True
    voyage["mergedAt"] = max(merged_ats) if merged_ats else datetime.now().isoformat()
    try:
        voyage_file.write_text(json.dumps(voyage, indent=2), encoding="utf-8")
        write_lifecycle_event(
            "COMPLETE",
            f"Reconcile annotated merge metadata on completed multi-repo voyage {vid} "
            f"({len(linked_repos)} repos)")
        return True
    except Exception as exc:
        write_lifecycle_event("WARN", f"reconcile: failed to annotate {vid}: {exc}")
        return False


def _repo_filter_matches(repo_slug: str, repo_filter: str) -> bool:
    """True if ``repo_filter`` selects ``repo_slug`` (FTR-MSO-2026-0379).

    Tolerates bare ("Maestro") vs qualified ("org/Maestro") forms on either
    side so ``--repo Maestro`` matches a manifest carrying "org/Maestro" and
    vice-versa.
    """
    if not repo_filter:
        return True
    if repo_slug == repo_filter:
        return True
    return repo_slug.rsplit("/", 1)[-1] == repo_filter.rsplit("/", 1)[-1]


def _reconcile_multi_repo_voyage(
    voyage: dict,
    voyage_file: "Path",
    ws: "Path",
    complete_dir: "Path",
    vid: str,
    archive_orders: bool,
    dry_run: bool,
    repo_filter: Optional[str] = None,
) -> bool:
    """Reconcile a voyage spanning >1 repo (FTR-MSO-2026-0379).

    One PR per repo (``voyage['branch']`` on each). The voyage archives ONLY
    when EVERY repo's PR is MERGED; a partial merge keeps it active and records
    the per-repo merge state under ``prUrls[repo]``. ``repo_filter`` narrows the
    PR lookups to a single repo (its merge state is still recorded, but a subset
    can never trigger whole-voyage archival). Returns True when the voyage was
    (or, in dry-run, would be) archived. Never raises.
    """
    branch = (voyage.get("branch") or "").replace("refs/heads/", "")
    all_slugs = _voyage_repo_slugs(voyage)
    repos = [r for r in all_slugs if _repo_filter_matches(r, repo_filter or "")]
    if not repos:
        return False
    subset = len(repos) < len(all_slugs)

    project = voyage.get("project") or ""
    try:
        org = _load_workspace_org(project)
    except Exception:
        org = ""

    states: Dict[str, Optional[dict]] = {}
    for repo in repos:
        full_repo = _resolve_full_repo_slug(repo, org) if org else repo
        # FTR-MSO-2026-0373: evaluate raw-git merge signals PER repo (against
        # that repo's local checkout) FIRST; gh is enrichment/fallback only, so
        # a gh-less host still archives a multi-repo voyage once every repo's
        # branch content has landed on its base. A "closed" verdict holds the
        # voyage (never fabricates a merged state).
        try:
            repo_cwd = get_product_repo(repo)
        except Exception:
            repo_cwd = ws.parent
        rv = _git_merge_verdict(branch, repo_cwd)
        if rv["verdict"] == "merged":
            enrich = _gh_pr_view(branch, repo_cwd, repo=full_repo) or {}
            states[repo] = {
                "state": "MERGED",
                "mergeCommit": enrich.get("mergeCommit") or {},
                "mergedAt": enrich.get("mergedAt") or "",
                "number": enrich.get("number"),
                "url": enrich.get("url") or "",
                "mergeable": enrich.get("mergeable"),
            }
            continue
        if rv["verdict"] == "closed":
            states[repo] = None  # closed without merge on this repo
            continue
        # open / unknown → gh fallback (None when gh absent or no PR for repo).
        states[repo] = _gh_pr_view(branch, repo_cwd, repo=full_repo)

    manifest_changed = False
    merged_ats: List[str] = []
    newly_merged: List[str] = []
    all_merged = True

    for repo in repos:
        pr = states.get(repo)
        if not pr:
            all_merged = False
            continue
        url = pr.get("url") or ""
        num = pr.get("number")
        state = pr.get("state")
        if not dry_run and _apply_pr_linkage(voyage, num, url, repo_slug=repo):
            manifest_changed = True
        if state == "MERGED":
            merge_commit = (pr.get("mergeCommit") or {}).get("oid", "")
            merged_at = pr.get("mergedAt", "")
            if merged_at:
                merged_ats.append(merged_at)
            prurls = voyage.get("prUrls")
            entry = prurls.get(repo) if isinstance(prurls, dict) else None
            if isinstance(entry, dict) and entry.get("state") != "MERGED":
                if not dry_run:
                    entry["state"] = "MERGED"
                    entry["mergeCommit"] = merge_commit
                    entry["mergedAt"] = merged_at
                    manifest_changed = True
                newly_merged.append(repo)
        else:
            all_merged = False
            # BUG-MSO-2026-0290 (per repo): surface a CONFLICTING PR once.
            if state == "OPEN" and pr.get("mergeable") == "CONFLICTING":
                warned = voyage.get("prConflictWarned")
                if not isinstance(warned, dict):
                    warned = {}
                if warned.get(repo) != num:
                    write_lifecycle_event(
                        "WARN",
                        f"Voyage {vid} PR #{num} ({repo}) is CONFLICTING — GitHub "
                        f"will not run its CI until the conflict is resolved "
                        f"(merge the default branch into the voyage branch). "
                        f"(BUG-MSO-2026-0290)")
                    warned[repo] = num
                    voyage["prConflictWarned"] = warned
                    manifest_changed = True

    # A subset (repo_filter) can update per-repo state but never archive the
    # whole voyage — the un-inspected repos may still be open.
    can_archive = all_merged and not subset

    if can_archive:
        pr_numbers = sorted(
            e.get("prNumber") for e in (voyage.get("prUrls") or {}).values()
            if isinstance(e, dict) and isinstance(e.get("prNumber"), int))
        if dry_run:
            print_info(
                f"[dry-run] Would archive merged multi-repo voyage {vid} "
                f"(repos={len(repos)}, PRs={pr_numbers})")
            return True
        voyage["status"] = "COMPLETED"
        voyage["mergedAt"] = max(merged_ats) if merged_ats else datetime.now().isoformat()
        voyage["completedAt"] = datetime.now().isoformat()
        dest = complete_dir / voyage_file.name
        try:
            dest.write_text(json.dumps(voyage, indent=2), encoding="utf-8")
            voyage_file.unlink()
            write_lifecycle_event(
                "COMPLETE",
                f"Reconcile archived merged multi-repo voyage {vid} "
                f"({len(repos)} repos, PRs={pr_numbers})")
        except Exception as exc:
            write_lifecycle_event(
                "WARN", f"reconcile: failed to archive {vid}: {exc}")
            return False
        if archive_orders:
            _sweep_voyage_orders_and_prompts(voyage, ws, vid)
        return True

    # Partial merge (or subset) — persist any per-repo state change and hold.
    if not dry_run and manifest_changed:
        try:
            voyage_file.write_text(json.dumps(voyage, indent=2), encoding="utf-8")
            _commit_lifecycle_transition(
                [voyage_file],
                f"lifecycle: multi-repo PR state for {vid}")
        except Exception:
            pass
        if newly_merged:
            merged_now = [r for r in all_slugs
                          if isinstance((voyage.get("prUrls") or {}).get(r), dict)
                          and (voyage.get("prUrls") or {}).get(r, {}).get("state") == "MERGED"]
            write_lifecycle_event(
                "PARTIAL_MERGE",
                f"Voyage {vid}: {len(merged_now)}/{len(all_slugs)} repo PRs merged "
                f"({', '.join(merged_now)}) — holding in final_review until all merge "
                f"(FTR-MSO-2026-0379)")
    elif dry_run and all_merged and subset:
        print_info(
            f"[dry-run] Voyage {vid}: filtered repo(s) merged, but other repos "
            f"remain — not archiving")
    return False


def ensure_voyage_branch_exists(
    target_repo: str,
    voyage_branch: str,
    project_acronym: str = "",
) -> bool:
    """Ensure the voyage branch exists on the remote for the target repo.

    v8.12: Auto-creates voyage branches before crew dispatch.
    BUG-ADM-2026-0007 (v2.5.5): reads `defaultBranch` from the project
    registry (e.g. 'master' for PSG) instead of hardcoding 'main'. Caches
    failures so a missing default branch doesn't storm `gh api` on every
    dispatcher loop. Logs structured lifecycle events for every failure.

    Uses `gh api` to check and create branches — no local clone needed.

    Returns True if the branch exists (or was created), False on error.
    """
    if not target_repo or not voyage_branch:
        return True  # Nothing to do

    cache_key = f"{target_repo}:{voyage_branch}"
    if cache_key in _VERIFIED_VOYAGE_BRANCHES:
        return True  # Already verified this session
    if cache_key in _FAILED_VOYAGE_BRANCHES:
        # BUG-ADM-2026-0007: don't re-attempt failed branch ops every dispatcher
        # tick. The cached error gives the human operator something to act on.
        return False

    # BUG-ADM-2026-0007: resolve org + defaultBranch from the project registry
    # so single-project workspaces with non-main default branches (e.g. PSG on
    # 'master') don't 404 when looking up the default branch SHA.
    try:
        org = _load_workspace_org(project_acronym)
    except ValueError as exc:
        detail = str(exc)
        _FAILED_VOYAGE_BRANCHES[cache_key] = detail
        print_warn(
            f"Branch ensure failed for {target_repo}@{voyage_branch}: {detail}\n"
            f"  This failure is cached — re-attempts are suppressed until restart.\n"
            f"  Resolve manually and restart the dispatcher."
        )
        return False
    default_branch = "main"
    try:
        project_info = load_project_config(project_acronym) if project_acronym else None
        if project_info:
            default_branch = project_info.get("defaultBranch") or "main"
    except Exception:
        pass  # Best-effort — fall back to defaults

    full_repo = _resolve_full_repo_slug(target_repo, org)
    branch_ref = voyage_branch.replace("refs/heads/", "")

    def _record_failure(detail: str) -> bool:
        """Cache + log a structured failure so the operator can diagnose."""
        _FAILED_VOYAGE_BRANCHES[cache_key] = detail
        print_warn(
            f"Branch ensure failed for {full_repo}@{branch_ref}: {detail}\n"
            f"  This failure is cached — re-attempts are suppressed until restart.\n"
            f"  Resolve manually (push the branch, fix gh auth, fix project config) and restart the dispatcher."
        )
        try:
            write_lifecycle_event(
                "BRANCH_FAIL",
                f"{full_repo}@{branch_ref} (project={project_acronym or 'unknown'}, "
                f"default={default_branch}): {detail}"
            )
        except Exception:
            pass
        return False

    try:
        # Check if branch already exists
        result = run_hidden(
            ["gh", "api", f"repos/{full_repo}/branches/{branch_ref}",
             "--jq", ".name"],
            capture_output=True, text=True, timeout=30
        )

        if result.returncode == 0 and result.stdout.strip():
            _VERIFIED_VOYAGE_BRANCHES.add(cache_key)
            return True

        # Branch doesn't exist — get the SHA of the project's default branch
        sha_result = run_hidden(
            ["gh", "api", f"repos/{full_repo}/git/refs/heads/{default_branch}",
             "--jq", ".object.sha"],
            capture_output=True, text=True, timeout=30
        )

        if sha_result.returncode != 0 or not sha_result.stdout.strip():
            stderr = sha_result.stderr.strip() or "no SHA returned"
            return _record_failure(
                f"could not resolve default branch '{default_branch}' SHA — {stderr[:200]}"
            )

        default_sha = sha_result.stdout.strip()

        # Create the branch
        create_result = run_hidden(
            ["gh", "api", f"repos/{full_repo}/git/refs",
             "-f", f"ref=refs/heads/{branch_ref}",
             "-f", f"sha={default_sha}"],
            capture_output=True, text=True, timeout=30
        )

        if create_result.returncode == 0:
            print_ok(f"Created voyage branch '{branch_ref}' on {target_repo} (from {default_branch})")
            try:
                write_lifecycle_event(
                    "BRANCH_CREATE",
                    f"{full_repo}@{branch_ref} created from {default_branch} "
                    f"(project={project_acronym or 'unknown'})"
                )
            except Exception:
                pass
            _VERIFIED_VOYAGE_BRANCHES.add(cache_key)
            return True
        else:
            return _record_failure(
                f"branch creation failed — {create_result.stderr.strip()[:200]}"
            )

    except subprocess.TimeoutExpired:
        return _record_failure("timeout calling gh api (network or auth issue)")
    except Exception as e:
        return _record_failure(f"unexpected error — {type(e).__name__}: {e}")


# =============================================================================
# v2.0.0: MANAGED REPO LIFECYCLE
# =============================================================================

def _robust_rmtree(path: Path, label: str = "", retries: int = 3, backoff: float = 2.0) -> bool:
    """Remove a directory tree robustly on Windows.

    v2.0.1: Handles Windows-specific issues:
    - Git marks .git/objects/ files read-only — clear the flag before removal
    - NTFS file handles linger after process kill — retry with exponential backoff
    - Falls back to 'rd /s /q' as a last resort on Windows
    Returns True if directory was removed, False otherwise.
    """
    import shutil as _shutil
    import stat

    if not path.exists():
        return True

    def _on_rm_error(func, fpath, exc_info):
        """Error handler: clear read-only flag and retry."""
        try:
            os.chmod(fpath, stat.S_IWRITE)
            func(fpath)
        except Exception:
            pass

    for attempt in range(retries):
        _shutil.rmtree(str(path), onerror=_on_rm_error)
        if not path.exists():
            return True
        wait = backoff * (attempt + 1)
        if label:
            print_info(f"{label}: Retry {attempt + 1}/{retries} — waiting {wait:.0f}s for NTFS handles...")
        time.sleep(wait)

    # Last resort on Windows: rd /s /q handles more edge cases than Python
    if os.name == 'nt' and path.exists():
        try:
            run_hidden(
                ['cmd', '/c', 'rd', '/s', '/q', str(path)],
                capture_output=True, timeout=30
            )
        except Exception:
            pass

    return not path.exists()


def prepare_crew_repo(crew_num: int, target_repo: str, voyage_branch: str) -> Optional[Path]:
    """DEPRECATED (FTR-ADM-2026-0149): use prepare_voyage_worktree() instead.

    Kept functional for backwards compatibility with legacy callers (custom
    dispatchers, third-party scripts). Emits LEGACY_CREW_CLONE lifecycle event
    when invoked so operators can migrate.

    Returns Path to crew repo dir, or None on failure (crew self-manages as fallback).
    """
    try:
        write_lifecycle_event(
            "LEGACY_CREW_CLONE",
            f"prepare_crew_repo() called for crew {crew_num} / {target_repo} — "
            "this function is deprecated. Use prepare_voyage_worktree() instead."
        )
    except Exception:
        pass
    if not target_repo:
        return None

    crew_dir = get_crew_dir(crew_num)
    repo_dir = crew_dir / "repo"
    org = _load_workspace_org()

    # Load clone protocol from workspace config
    ws_file = get_artefact_root() / "config" / "workspace.json"
    try:
        ws_data = json.loads(ws_file.read_text(encoding='utf-8'))
        protocol = ws_data.get("cloneProtocol", "ssh")
    except Exception:
        protocol = "ssh"

    if protocol == "ssh":
        clone_url = f"git@github.com:{org}/{target_repo}.git"
    else:
        clone_url = f"https://github.com/{org}/{target_repo}.git"

    branch_ref = voyage_branch.replace("refs/heads/", "")

    try:
        # Step 1: Clean existing repo if present
        if repo_dir.exists():
            print_info(f"Crew {crew_num}: Cleaning existing repo clone...")
            if not _robust_rmtree(repo_dir, label=f"Crew {crew_num}"):
                print_warn(f"Crew {crew_num}: Could not remove {repo_dir} — file locks?")
                return None

        # Step 2: Clone directly onto the voyage branch
        print_info(f"Crew {crew_num}: Cloning {target_repo} (branch: {branch_ref})...")
        clone_result = run_hidden(
            ["git", "clone", "--branch", branch_ref, "--single-branch",
             clone_url, str(repo_dir)],
            capture_output=True, text=True, timeout=120
        )

        if clone_result.returncode != 0:
            # Voyage branch may have no commits yet — clone main, then checkout
            print_info(f"Crew {crew_num}: Direct branch clone failed, trying main + checkout...")
            clone_result = run_hidden(
                ["git", "clone", clone_url, str(repo_dir)],
                capture_output=True, text=True, timeout=120
            )
            if clone_result.returncode != 0:
                print_warn(f"Crew {crew_num}: Clone failed: {clone_result.stderr.strip()[:200]}")
                return None

            # Checkout voyage branch (tracking remote)
            checkout_result = run_hidden(
                ["git", "checkout", "-B", branch_ref, f"origin/{branch_ref}"],
                capture_output=True, text=True, timeout=30,
                cwd=str(repo_dir)
            )
            if checkout_result.returncode != 0:
                # Branch exists remote but no tracking — create local from current HEAD
                run_hidden(
                    ["git", "checkout", "-b", branch_ref],
                    capture_output=True, text=True, timeout=30,
                    cwd=str(repo_dir)
                )

        # Step 3: Verify correct branch
        branch_check = run_hidden(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True, text=True, timeout=10,
            cwd=str(repo_dir)
        )
        current_branch = branch_check.stdout.strip()
        if current_branch != branch_ref:
            print_warn(f"Crew {crew_num}: Expected branch '{branch_ref}', got '{current_branch}'")

        print_ok(f"Crew {crew_num}: Repo ready (branch: {current_branch})")
        write_lifecycle_event("REPO", f"Crew {crew_num}: {target_repo} cloned on {branch_ref}")
        return repo_dir

    except subprocess.TimeoutExpired:
        print_warn(f"Crew {crew_num}: Clone timed out for {target_repo}")
        return None
    except Exception as e:
        print_warn(f"Crew {crew_num}: Repo preparation failed: {e}")
        return None


# ===========================================================================
# Multi-repo dispatch — repos map + managed product-repo checkouts
# (FTR-MSO-2026-0377 / plan PLAN-PLN-MSO-2026-0358 §4.2–4.3)
# ===========================================================================
#
# A workspace maps 1..N product repos; the dispatcher routes each order's crew
# to the checkout named by ``order.targetRepo``. All of this is gated on a
# non-empty ``repos`` map — a single-repo/embedded workspace (no map) takes the
# byte-identical legacy path and none of the code below fires.

# Session cache of resolved product-repo checkouts, keyed by the repos-map key
# (the canonical repo NAME). Cleared implicitly per dispatcher process.
_REPO_CHECKOUT_CACHE: Dict[str, Path] = {}
# Repo names fetched at least once this session (fetch-on-reuse is once-per-run).
_REPO_CHECKOUT_FETCHED: set = set()


def _workspace_repos_map() -> dict:
    """The workspace's ``repos`` map (FTR-MSO-2026-0377), fail-open ``{}``.

    Delegates to the sanctioned resolver ``workspace.get_repos_map`` (which reads
    the workspace.json ``artefacts.repos`` mirror, then the registry v2 entry).
    """
    try:
        from maestro.workspace import get_repos_map
        return get_repos_map()
    except Exception:
        return {}


def _repos_map_configured() -> bool:
    """True when this workspace declares a multi-repo ``repos`` map (plan §4.2).

    Multi-repo routing (per-repo checkout resolution, per-repo crew worktree,
    unknown-targetRepo refusal) is entirely gated on this — single-repo/embedded
    workspaces get the byte-identical legacy dispatch path.
    """
    return bool(_workspace_repos_map())


def _resolve_repo_map_entry(target_repo: str) -> Optional[tuple]:
    """Resolve *target_repo* to a ``(repoName, entry)`` pair in the repos map.

    Matches on the map key (the canonical repo name) first, then tolerates a
    slug / slug-tail match so orders carrying either the bare repo name
    ("Maestro") or a qualified slug ("tavisbasing/Maestro") resolve to the same
    entry (mirrors ``_get_default_branch_for_repo``'s reverse-lookup). Returns
    ``None`` when no repos map is configured or the target is unknown — the
    dispatch guard turns that into a hard refusal, never a silent wrong repo.
    """
    if not target_repo:
        return None
    repos = _workspace_repos_map()
    if not repos:
        return None
    if isinstance(repos.get(target_repo), dict):
        return target_repo, repos[target_repo]
    for name, entry in repos.items():
        if not isinstance(entry, dict):
            continue
        slug = entry.get("slug", "")
        if slug and (slug == target_repo or
                     ("/" in slug and slug.split("/", 1)[-1] == target_repo)):
            return name, entry
    return None


def _repo_clone_url(name: str, entry: dict, project_acronym: str = "") -> str:
    """Build the clone URL for a repos-map entry (FTR-MSO-2026-0377).

    Prefers the entry's ``slug`` (``org/repo``) + ``cloneProtocol``; falls back
    to the workspace default org (``_load_workspace_org``) + workspace-level
    ``cloneProtocol``. Returns "" when no remote can be constructed (caller
    fails open to any existing local checkout). Reuses ``_resolve_full_repo_slug``
    so bare vs qualified forms behave exactly like the legacy clone path.
    """
    slug = entry.get("slug", "") or name
    protocol = entry.get("cloneProtocol", "")
    if not protocol:
        try:
            ws_file = get_artefact_root() / "config" / "workspace.json"
            protocol = json.loads(ws_file.read_text(encoding="utf-8")).get(
                "cloneProtocol", "ssh")
        except Exception:
            protocol = "ssh"
    if "/" not in slug:
        try:
            org = _load_workspace_org(project_acronym)
        except Exception:
            return ""
        slug = _resolve_full_repo_slug(slug, org)
    if "/" not in slug:
        return ""
    if protocol == "https":
        return f"https://github.com/{slug}.git"
    return f"git@github.com:{slug}.git"


def _fetch_checkout_best_effort(checkout: Path, name: str) -> None:
    """Best-effort ``git fetch --prune origin`` in a managed checkout.

    Fetch-on-reuse keeps the crew branching off a fresh voyage-branch tip. An
    offline/failed fetch is a WARN (never a hard error) — the existing checkout
    is still usable (fail-open). Runs at most once per repo per dispatcher run.
    """
    try:
        result = run_hidden(
            ["git", "fetch", "--prune", "origin"],
            cwd=str(checkout), capture_output=True, text=True, timeout=60)
        _REPO_CHECKOUT_FETCHED.add(name)
        if result.returncode != 0:
            write_lifecycle_event(
                "WARN",
                f"Fetch of product repo '{name}' failed (offline?): "
                f"{result.stderr.strip()[:200]} — using existing checkout (FTR-0377)")
    except Exception as e:
        _REPO_CHECKOUT_FETCHED.add(name)
        write_lifecycle_event(
            "WARN",
            f"Fetch of product repo '{name}' error: {e} — using existing "
            f"checkout (FTR-0377)")


def _clone_repo_checkout(clone_url: str, checkout: Path, name: str) -> bool:
    """Clone *clone_url* into *checkout*. Returns True on success.

    A failure (offline, auth, timeout) is a WARN, not an exception — the caller
    fails open to any pre-existing checkout, or holds the order.
    """
    try:
        checkout.parent.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        write_lifecycle_event(
            "WARN", f"Cannot create checkout parent for '{name}': {e} (FTR-0377)")
        return False
    print_info(f"Product repo '{name}': cloning {clone_url} -> {checkout}")
    try:
        result = run_hidden(
            ["git", "clone", clone_url, str(checkout)],
            capture_output=True, text=True, timeout=300)
        if result.returncode == 0:
            write_lifecycle_event(
                "REPO", f"Product repo '{name}' cloned to {checkout} (FTR-0377)")
            return True
        write_lifecycle_event(
            "WARN",
            f"Clone of product repo '{name}' failed (offline?): "
            f"{result.stderr.strip()[:200]} — fail-open (FTR-0377)")
        return False
    except subprocess.TimeoutExpired:
        write_lifecycle_event(
            "WARN", f"Clone of product repo '{name}' timed out — fail-open (FTR-0377)")
        return False
    except Exception as e:
        write_lifecycle_event(
            "WARN", f"Clone of product repo '{name}' error: {e} — fail-open (FTR-0377)")
        return False


def ensure_repo_checkout(target_repo: str, project_acronym: str = "",
                         fetch: bool = True) -> Optional[Path]:
    """Resolve — or clone on first use — the managed checkout for *target_repo*.

    Multi-repo dispatch (plan §4.3.1): each order's ``targetRepo`` maps to one
    product repo the crew branches/builds. This evolves the deprecated
    ``prepare_crew_repo`` clone machinery into a resolve-or-clone with a session
    cache and offline fail-open:

      1. Look up the repos-map entry. Unknown → ``None`` (caller refuses to
         dispatch — never a silent wrong checkout).
      2. Location: the entry's ``path`` if set, else the managed home
         ``<artefact-repo-root>/repos/<name>``.
      3. Present + a git repo → reuse; ``fetch`` (default True) refreshes the
         tip once per session (offline fetch = WARN, still usable).
      4. Absent → clone from the remote. A clone failure with no prior checkout
         returns ``None`` (fail-open + loud WARN); the caller holds the order
         rather than dispatching a crew against nothing.

    Returns the checkout ``Path``, or ``None`` when unknown/unresolvable.
    """
    resolved = _resolve_repo_map_entry(target_repo)
    if resolved is None:
        return None
    name, entry = resolved

    cached = _REPO_CHECKOUT_CACHE.get(name)
    if cached is not None and cached.is_dir():
        if fetch and name not in _REPO_CHECKOUT_FETCHED:
            _fetch_checkout_best_effort(cached, name)
        return cached

    entry_path = entry.get("path", "")
    if entry_path:
        checkout = Path(entry_path).expanduser().resolve()
    else:
        checkout = (get_artefact_repo_root() / "repos" / name).resolve()

    if checkout.is_dir() and (checkout / ".git").exists():
        _REPO_CHECKOUT_CACHE[name] = checkout
        if fetch:
            _fetch_checkout_best_effort(checkout, name)
        return checkout

    clone_url = _repo_clone_url(name, entry, project_acronym)
    if clone_url and _clone_repo_checkout(clone_url, checkout, name):
        _REPO_CHECKOUT_CACHE[name] = checkout
        _REPO_CHECKOUT_FETCHED.add(name)
        return checkout

    # Clone impossible / failed — fail open to a pre-existing checkout if any.
    if checkout.is_dir() and (checkout / ".git").exists():
        _REPO_CHECKOUT_CACHE[name] = checkout
        return checkout
    if not clone_url:
        write_lifecycle_event(
            "WARN",
            f"No remote resolvable for product repo '{name}' and no local "
            f"checkout at {checkout} — cannot prepare (FTR-0377)")
    return None


def _repo_ctx_for_order(order_id: str,
                        target_repo: str = "",
                        project_acronym: str = "") -> tuple:
    """Return ``(repo_root, repo_name)`` for an order's product repo (FTR-0378).

    Phase 4b (plan §4.3.5): convergence, salvage, and the verify gate operate
    against the ORDER's resolved product-repo checkout, not the dispatcher's
    cwd. This is the single resolution point every finalization/salvage site
    calls to obtain that context:

      - ``repo_name`` — the canonical repos-map key (suffixes per-repo
        worktrees ``crew<N>-<repoName>`` / ``admin-<repoName>``).
      - ``repo_root`` — the managed checkout the worktree/branch git ops run in
        (``cwd``), via the FTR-0377 :func:`ensure_repo_checkout` session cache.

    Single-repo / embedded workspaces (no ``repos`` map) return ``(None, "")``
    — every git op runs in the dispatcher's own repo and worktrees keep their
    legacy paths, so convergence stays byte-identical. Fail-open: an unknown
    target or a checkout that can't be resolved also returns ``(None, "")`` so a
    resolution hiccup never crashes finalization (the worst case degrades to
    the single-repo path, which the caller already handled pre-0378).

    BUG-MSO-2026-0389: a solo/shared SINGLE-repo workspace has no ``repos`` map
    but its product repo is NOT the dispatcher's cwd (the artefact repo). So
    before returning the single-repo ``(None, "")``, pin ``repo_root`` to the
    product repo — otherwise convergence/salvage/verify would run against the
    artefact checkout and never find the voyage branch. Fail-open to
    ``(None, "")`` if the product repo can't be resolved.
    """
    if not _repos_map_configured():
        try:
            _solo_root = solo_worktree_repo_root()
        except Exception:
            _solo_root = None
        return _solo_root, ""
    tr = target_repo or _get_target_repo_for_order(order_id)
    if not tr:
        return None, ""
    resolved = _resolve_repo_map_entry(tr)
    if resolved is None:
        return None, ""
    repo_name = resolved[0]
    repo_root = None
    try:
        # Checkout already exists post-dispatch (cache-hit); resolve without a
        # fresh fetch to keep finalization fast.
        repo_root = ensure_repo_checkout(tr, project_acronym=project_acronym,
                                         fetch=False)
    except Exception as exc:
        write_lifecycle_event(
            "WARN",
            f"{order_id}: repo context resolution for '{tr}' raised "
            f"{type(exc).__name__}: {exc} — degrading to single-repo convergence "
            f"(FTR-0378)")
        repo_root = None
    return repo_root, repo_name


def verify_and_push_crew_work(crew_num: int, target_repo: str, voyage_branch: str) -> Dict[str, Any]:
    """Post-completion: verify commits were pushed, commit+push any uncommitted work.

    v2.0.0: Runs after crew process exits. Returns verification report.

    DEPRECATED (BUG-MSO-2026-0284): this targets the legacy pre-worktree path
    ``get_crew_dir(crew_num)/'repo'`` and has NO production call sites — it does
    not run in the current worktree-based dispatch model. The live equivalent is
    ``maestro.core.worktrees.commit_crew_worktree_if_dirty()``, called from
    ``process_crew_completion`` before convergence. Retained only because
    ``tests/test_verify_and_push_branch_guard.py`` (BUG-MSO-2026-0241) exercises
    its branch-safety check; do not wire it back in without re-pointing it at the
    crew worktree.
    """
    repo_dir = get_crew_dir(crew_num) / "repo"
    report = {"pushed": False, "commits_ahead": 0,
              "uncommitted_committed": False, "error": None}

    if not repo_dir.exists() or not (repo_dir / ".git").exists():
        report["error"] = f"No repo found at {repo_dir}"
        return report

    branch_ref = voyage_branch.replace("refs/heads/", "")

    try:
        # BUG-MSO-2026-0241: assert the repo is on the voyage branch before touching it.
        # verify_and_push_crew_work runs as dispatcher Python code (not via Claude's Bash
        # tool), so the branch_guard pretool hook does NOT intercept it.  Without this
        # check, if repo_dir happened to be on main, auto-commit would push to main.
        head_result = run_hidden(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True, text=True, timeout=10,
            cwd=str(repo_dir)
        )
        if head_result.returncode != 0 or head_result.stdout.strip() != branch_ref:
            actual_branch = head_result.stdout.strip() if head_result.returncode == 0 else "<unknown>"
            report["error"] = (
                f"Branch safety check failed: repo at {repo_dir} is on "
                f"`{actual_branch}`, not voyage branch `{branch_ref}`. "
                "Refusing auto-commit/push to prevent main contamination."
            )
            print_warn(f"Crew {crew_num}: {report['error']}")
            return report

        # Step 1: Check for uncommitted changes
        status = run_hidden(
            ["git", "status", "--porcelain"],
            capture_output=True, text=True, timeout=30,
            cwd=str(repo_dir)
        )

        if status.stdout.strip():
            print_info(f"Crew {crew_num}: Found uncommitted changes, auto-committing...")
            run_hidden(
                ["git", "add", "-A"],
                capture_output=True, text=True, timeout=30,
                cwd=str(repo_dir)
            )
            commit_result = run_hidden(
                ["git", "commit", "-m",
                 f"[fleet] Auto-commit uncommitted work from Crew {crew_num}"],
                capture_output=True, text=True, timeout=30,
                cwd=str(repo_dir)
            )
            if commit_result.returncode == 0:
                report["uncommitted_committed"] = True
                print_ok(f"Crew {crew_num}: Uncommitted changes committed")

        # Step 2: Fetch remote state and check for unpushed commits
        run_hidden(
            ["git", "fetch", "origin", branch_ref],
            capture_output=True, text=True, timeout=60,
            cwd=str(repo_dir)
        )

        ahead = run_hidden(
            ["git", "rev-list", "--count", f"origin/{branch_ref}..HEAD"],
            capture_output=True, text=True, timeout=15,
            cwd=str(repo_dir)
        )

        commits_ahead = 0
        if ahead.returncode == 0:
            try:
                commits_ahead = int(ahead.stdout.strip())
            except ValueError:
                pass

        report["commits_ahead"] = commits_ahead

        if commits_ahead > 0:
            # BUG-MSO-2026-0347: never auto-push the remote default branch.
            from maestro.core.worktrees import default_branch_push_guard
            if not default_branch_push_guard(
                    branch_ref, f"crew {crew_num} auto-push to {target_repo}",
                    repo_dir=repo_dir):
                report["error"] = (
                    f"Push refused: '{branch_ref}' is the remote default branch "
                    f"of {target_repo} (BUG-MSO-2026-0347)")
                print_warn(f"Crew {crew_num}: {report['error']}")
                return report
            print_info(f"Crew {crew_num}: {commits_ahead} unpushed commit(s), pushing...")
            push_result = run_hidden(
                ["git", "push", "origin", branch_ref],
                capture_output=True, text=True, timeout=120,
                cwd=str(repo_dir)
            )
            if push_result.returncode == 0:
                report["pushed"] = True
                print_ok(f"Crew {crew_num}: Pushed {commits_ahead} commit(s) to {target_repo}/{branch_ref}")
                write_lifecycle_event("REPO",
                    f"Crew {crew_num}: Pushed {commits_ahead} commit(s) to {target_repo}/{branch_ref}")
            else:
                report["error"] = f"Push failed: {push_result.stderr.strip()[:200]}"
                print_warn(f"Crew {crew_num}: {report['error']}")
        else:
            report["pushed"] = True  # Nothing to push = success

        return report

    except subprocess.TimeoutExpired:
        report["error"] = "Git operation timed out"
        return report
    except Exception as e:
        report["error"] = str(e)
        return report


def create_pr_for_crew(crew_num: int, target_repo: str, voyage_branch: str,
                       order_id: str, order_title: str,
                       project_acronym: str = "") -> Optional[str]:
    """Create or update a PR for the crew's completed work.

    v2.0.0: Called immediately when each crew completes.
    If PR already exists, adds a comment. Otherwise creates a new PR.
    Returns PR URL on success, None on failure.

    BUG-ADM-2026-0013: project_acronym threaded through so the base branch
    can be resolved from the project registry (`master` for PSG, `main` for
    framework). Falls back to `main` if registry missing.
    """
    if not target_repo or not voyage_branch:
        return None

    org = _load_workspace_org(project_acronym)
    full_repo = _resolve_full_repo_slug(target_repo, org)
    branch_ref = voyage_branch.replace("refs/heads/", "")
    default_branch = _get_default_branch_for_repo(target_repo, project_acronym)

    try:
        # Check if branch has commits ahead of the project's default branch
        compare = run_hidden(
            ["gh", "api", f"repos/{full_repo}/compare/{default_branch}...{branch_ref}",
             "--jq", ".ahead_by"],
            capture_output=True, text=True, timeout=30
        )

        ahead_by = 0
        if compare.returncode == 0:
            try:
                ahead_by = int(compare.stdout.strip())
            except ValueError:
                pass

        if ahead_by == 0:
            print_info(f"Crew {crew_num}: No commits ahead of {default_branch} on {target_repo} — no PR needed")
            return None

        # Check for existing open PR
        pr_check = run_hidden(
            ["gh", "pr", "list", "--repo", full_repo,
             "--head", branch_ref, "--state", "open",
             "--json", "number,url"],
            capture_output=True, text=True, timeout=30
        )

        if pr_check.returncode == 0 and pr_check.stdout.strip() not in ("", "[]"):
            prs = json.loads(pr_check.stdout)
            if prs:
                pr_number = prs[0]["number"]
                pr_url = prs[0]["url"]
                codename = _get_crew_name(crew_num)
                comment_body = f"Crew {crew_num} ({codename}) completed order `{order_id}`: {order_title}"
                run_hidden(
                    ["gh", "pr", "comment", str(pr_number),
                     "--repo", full_repo, "--body", comment_body],
                    capture_output=True, text=True, timeout=30
                )
                # BUG-MSO-2026-0360: found-existing path also records the
                # linkage — heals manifests that missed it at creation time.
                # FTR-MSO-2026-0379: tag the linkage with this repo's slug.
                record_voyage_pr_linkage(branch_ref, pr_url, pr_number,
                                         repo_slug=target_repo)
                print_ok(f"Crew {crew_num}: Commented on existing PR #{pr_number} for {target_repo}")
                return pr_url

        # No existing PR — create one
        orders = _SESSION_TARGET_REPOS.get(target_repo, [])
        body_lines = ["## Summary", ""]
        body_lines.append(f"Voyage branch `{branch_ref}` with {ahead_by} commit(s).")
        body_lines.append("")
        body_lines.append("### Orders Completed")
        for t in orders[:20]:
            body_lines.append(f"- {t}")
        body_lines.append("")
        body_lines.append("## Test plan")
        body_lines.append("- [ ] CI checks pass")
        body_lines.append("- [ ] Code review completed")

        pr_title = f"[{branch_ref}] {target_repo}"
        pr_body = "\n".join(body_lines)

        # FTR-MSO-2026-0287 (R1): create the voyage PR as a DRAFT so the
        # intermediate per-role convergence pushes don't re-trigger CI. The PR is
        # promoted to ready-for-review only when the voyage finalises (see the
        # all-orders-complete sweep). draft=false restores per-push CI.
        _use_draft = bool(load_completion_config().get("voyagePr", {}).get("draft", True))
        create_args = [
            "gh", "pr", "create",
            "--repo", full_repo,
            "--base", default_branch,
            "--head", branch_ref,
            "--title", pr_title,
            "--body", pr_body,
        ]
        if _use_draft:
            create_args.append("--draft")

        pr_result = run_hidden(
            create_args, capture_output=True, text=True, timeout=60
        )

        # Some repos/plans don't permit draft PRs — fall back to a normal PR
        # rather than failing the finalisation.
        if (pr_result.returncode != 0 and _use_draft
                and "draft" in (pr_result.stderr or "").lower()):
            write_lifecycle_event(
                "WARN",
                f"Crew {crew_num}: draft PR not supported for {target_repo} — "
                f"retrying as a normal PR ({(pr_result.stderr or '').strip()[:120]})"
            )
            pr_result = run_hidden(
                [a for a in create_args if a != "--draft"],
                capture_output=True, text=True, timeout=60
            )

        if pr_result.returncode == 0:
            pr_url = pr_result.stdout.strip()
            print_ok(f"Crew {crew_num}: PR created for {target_repo} -> {pr_url}")
            write_lifecycle_event("PR", f"Crew {crew_num}: PR created for {target_repo}: {pr_url}")
            # BUG-MSO-2026-0360: record prNumber/prUrl on the voyage manifest
            # so the Hub's Final Review bucket carries the PR link.
            # FTR-MSO-2026-0379: record it per-repo under prUrls[target_repo].
            record_voyage_pr_linkage(branch_ref, pr_url, repo_slug=target_repo)
            return pr_url
        else:
            err = pr_result.stderr.strip()[:200]
            print_warn(f"Crew {crew_num}: PR creation failed for {target_repo}: {err}")
            write_lifecycle_event(
                "ERROR",
                f"Crew {crew_num}: PR creation failed for {target_repo}: {err}",
            )
            return None

    except subprocess.TimeoutExpired:
        print_warn(f"Crew {crew_num}: PR creation timed out for {target_repo}")
        write_lifecycle_event("ERROR", f"Crew {crew_num}: PR creation timed out for {target_repo}")
        return None
    except Exception as e:
        print_warn(f"Crew {crew_num}: PR creation error for {target_repo}: {e}")
        write_lifecycle_event("ERROR", f"Crew {crew_num}: PR creation error for {target_repo}: {e}")
        return None


def cleanup_crew_repo(crew_num: int):
    """Remove the crew's ephemeral repo clone after completion (legacy path).

    DEPRECATED (FTR-MSO-2026-0177): no-op in normal operation since crews run in worktrees.
    Kept callable for any legacy queue entries that used the per-crew clone path.
    """
    repo_dir = get_crew_dir(crew_num) / "repo"
    if repo_dir.exists():
        if _robust_rmtree(repo_dir, label=f"Crew {crew_num}"):
            print_info(f"Crew {crew_num}: Cleaned up ephemeral repo clone")
        else:
            print_warn(f"Crew {crew_num}: Failed to clean repo dir — will retry on next dispatch")


def reset_developer_repos():
    """Reset any repos/ checkouts back to their project's default branch.

    v2.0.0: Called at Eight Bells. Scans repos/ directory for any
    repos left on voyage branches and resets them to the resolved
    default branch (e.g. `master` for PSG, `main` for the framework).

    BUG-MSO-2026-0016 (v2.8.2): each repo's default branch is now
    resolved via `_get_default_branch_for_repo()` rather than hardcoded
    to `main`. Repos with a non-`main` default (PSG/master, anyone on
    develop/trunk) now reset to the correct branch.
    """
    repos_dir = get_base_dir() / "repos"
    if not repos_dir.exists():
        return

    reset_count = 0
    for repo_path in sorted(repos_dir.iterdir()):
        if not repo_path.is_dir() or not (repo_path / ".git").exists():
            continue

        try:
            branch = run_hidden(
                ["git", "rev-parse", "--abbrev-ref", "HEAD"],
                capture_output=True, text=True, timeout=10,
                cwd=str(repo_path)
            )
            current = branch.stdout.strip()

            if current.startswith("voyage/"):
                # Check for uncommitted changes first
                status = run_hidden(
                    ["git", "status", "--porcelain"],
                    capture_output=True, text=True, timeout=10,
                    cwd=str(repo_path)
                )
                if status.stdout.strip():
                    # Discard local changes (crew work should be in ephemeral clone)
                    run_hidden(
                        ["git", "checkout", "--", "."],
                        capture_output=True, text=True, timeout=15,
                        cwd=str(repo_path)
                    )
                    run_hidden(
                        ["git", "clean", "-fd"],
                        capture_output=True, text=True, timeout=15,
                        cwd=str(repo_path)
                    )

                repo_default_branch = _get_default_branch_for_repo(repo_path.name)
                result = run_hidden(
                    ["git", "checkout", repo_default_branch],
                    capture_output=True, text=True, timeout=30,
                    cwd=str(repo_path)
                )
                if result.returncode == 0:
                    run_hidden(
                        ["git", "pull", "--ff-only"],
                        capture_output=True, text=True, timeout=60,
                        cwd=str(repo_path)
                    )
                    reset_count += 1
        except Exception:
            continue

    if reset_count > 0:
        print_ok(f"Reset {reset_count} repo(s) in repos/ back to their default branch")


def _resolve_target_repo_from_project(data: dict) -> str:
    """Resolve targetRepo from order's project field via the project registry.

    v2.0.5: If an order has a 'project' field but no 'targetRepo', look up the
    repo name from the project registry.
    """
    project = data.get("project", "")
    if not project:
        return ""
    project_info = load_project_config(project)
    if project_info:
        return project_info.get("repo", "")
    return ""


def _get_target_repo_for_order(order_id: str) -> str:
    """Look up the targetRepo for an order from session tracking or queue files."""
    # Fast path: check session tracking (in-memory)
    for repo, orders in _SESSION_TARGET_REPOS.items():
        if any(order_id in o for o in orders):
            return repo

    # Fallback: scan queue files
    queues_dir = get_queues_dir()
    queue_names = ["orders", "explicit", "bugs", "security", "breakdown", "defects", "high-level"]
    for queue_name in queue_names:
        queue_dir = queues_dir / queue_name
        if not queue_dir.exists():
            continue
        for json_file in queue_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                file_id = data.get("orderId") or data.get("id") or json_file.stem
                if file_id == order_id:
                    repo = data.get("targetRepo", "")
                    # v2.0.5: Resolve from project field if targetRepo is missing
                    if not repo:
                        repo = _resolve_target_repo_from_project(data)
                    return repo
            except Exception:
                continue

    # Also check active orders
    active_dir = get_artefact_root() / "orders" / "active"
    if active_dir.exists():
        for json_file in active_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                file_id = data.get("orderId") or data.get("id") or json_file.stem
                if file_id == order_id:
                    repo = data.get("targetRepo", "")
                    # v2.0.5: Resolve from project field if targetRepo is missing
                    if not repo:
                        repo = _resolve_target_repo_from_project(data)
                    return repo
            except Exception:
                continue

    return ""


def _get_project_for_order(order_id: str) -> str:
    """Look up an order's project acronym from queue files.

    BUG-ADM-2026-0013: PR-creation needs the project to resolve the
    default branch (PSG → master, ADM → main). Same scan pattern as
    _get_target_repo_for_order.
    """
    if not order_id:
        return ""
    queues_dir = get_queues_dir()
    queue_names = ["orders", "explicit", "bugs", "security",
                   "breakdown", "defects", "high-level", "proposed"]
    for queue_name in queue_names:
        queue_dir = queues_dir / queue_name
        if not queue_dir.exists():
            continue
        for json_file in queue_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                file_id = data.get("orderId") or data.get("id") or json_file.stem
                if file_id == order_id:
                    return data.get("project", "")
            except Exception:
                continue
    for sub in ("orders/active", "orders/complete", "orders/failed"):
        d = get_artefact_root() / sub
        if not d.exists():
            continue
        for json_file in d.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                file_id = data.get("orderId") or data.get("id") or json_file.stem
                if file_id == order_id:
                    return data.get("project", "")
            except Exception:
                continue
    return ""


def _get_voyage_branch_for_order(order_id: str) -> str:
    """Look up the voyage branch for an order from its voyageId field.

    v2.0.1: Per-order voyage branch resolution. Converts voyageId (e.g. 'VOY-2026-0304')
    to a branch name (e.g. 'voyage/VOY-2026-0304'). Falls back to ACTIVE_VOYAGE_BRANCH
    if the order has no voyageId.
    """
    # Scan queue files and active orders for the voyageId
    search_dirs = []
    queues_dir = get_queues_dir()
    for queue_name in ["orders", "explicit", "bugs", "security", "breakdown", "defects", "high-level"]:
        qd = queues_dir / queue_name
        if qd.exists():
            search_dirs.append(qd)
    active_dir = get_artefact_root() / "orders" / "active"
    if active_dir.exists():
        search_dirs.append(active_dir)
    # v2.0.2: Also search completed orders (order may already be archived)
    complete_dir = get_artefact_root() / "orders" / "complete"
    if complete_dir.exists():
        search_dirs.append(complete_dir)

    for search_dir in search_dirs:
        for json_file in search_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                file_id = data.get("orderId") or data.get("id") or json_file.stem
                if file_id == order_id:
                    # v2.0.3: Check voyageBranch (full branch name) first, then voyageId
                    voyage_branch = data.get("voyageBranch", "")
                    if voyage_branch:
                        return voyage_branch
                    voyage_id = data.get("voyageId", "")
                    if voyage_id:
                        # Convert voyageId to branch name if not already prefixed
                        if voyage_id.startswith("voyage/"):
                            return voyage_id
                        return f"voyage/{voyage_id}"
            except Exception:
                continue

    return ""


def _get_voyage_id_for_order(order_id: str) -> str:
    """Look up the voyageId for an order from queue / complete files."""
    search_dirs = []
    queues_dir = get_queues_dir()
    for queue_name in ["orders", "explicit", "bugs", "security", "breakdown", "defects", "high-level"]:
        qd = queues_dir / queue_name
        if qd.exists():
            search_dirs.append(qd)
    for subdir in ["orders/active", "orders/complete"]:
        d = get_artefact_root() / subdir
        if d.exists():
            search_dirs.append(d)

    for search_dir in search_dirs:
        for json_file in search_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding="utf-8"))
                file_id = data.get("orderId") or data.get("id") or json_file.stem
                if file_id == order_id:
                    return data.get("voyageId", "")
            except Exception:
                continue
    return ""


def _get_order_title(order_id: str) -> str:
    """Look up order title from queue files."""
    queues_dir = get_queues_dir()
    for queue_name in ["orders", "explicit", "bugs", "security", "breakdown", "defects", "high-level"]:
        queue_dir = queues_dir / queue_name
        if not queue_dir.exists():
            continue
        for json_file in queue_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                file_id = data.get("orderId") or data.get("id") or json_file.stem
                if file_id == order_id:
                    return data.get("title", order_id)
            except Exception:
                continue
    return order_id


# =============================================================================
# PROCESS MANAGEMENT
# =============================================================================

def start_crew_process(crew_number: int, role: str, order_id: str,
                       prompt_file: str, max_iterations: int,
                       timeout: int, voyage_branch: str = "",
                       repo_path: str = "",
                       project_acronym: str = "",
                       worktree_path: str = "",
                       max_turns: int = 200) -> Optional[int]:
    """Start a crew process as a fully detached independent process.

    v6.0: Mimics Ralph's Start-Process + Dispose() pattern.
    Each crew gets its own process group and console - no parent-child
    handle inheritance. This allows 5 crews to call Claude API
    concurrently without session-level rate limiting.

    Returns PID (int) or None on failure.
    """
    # Resolve crew.py: prefer script-relative (pip package), fall back to .mso/core/
    crew_py = Path(__file__).resolve().parent / "crew.py"
    if not crew_py.exists():
        crew_py = get_artefact_root() / "core" / "crew.py"

    if not crew_py.exists():
        print_error(f"crew.py not found at {crew_py}")
        return None


    # Build the crew command
    crew_cmd = [
        sys.executable, str(crew_py),
        "--crew", str(crew_number),
        "--role", role,
        "--order", order_id,
        "--prompt", prompt_file,
        "--max-iterations", str(max_iterations),
        "--timeout", str(timeout),
        "--max-turns", str(max_turns),
        # BUG-MSO-2026-0302: command-line spawn marker — Win32_Process exposes
        # CommandLine (not env), so the marker must live in argv to make
        # orphaned crew processes discoverable by the cleanup sweep.
        "--spawn-marker", _spawn_marker(),
    ]

    try:
        # Build crew environment — inherit parent env, inject voyage branch if set.
        #
        crew_env = os.environ.copy()
        # Inject the workspace .mso path so crew.py uses the correct project dir
        # rather than resolving relative to the pip-installed package location.
        _mso_dir = str(get_artefact_root())
        crew_env["MAESTRO_DIR"] = _mso_dir
        # FTR-MSO-2026-0368: expose the artefact repo's .mso dir explicitly so the
        # hook guards (path_guard / branch_guard) can locate the durable plane in
        # solo/shared mode, where crew deliverables live in the artefact repo while
        # MAESTRO_REPO_PATH points at the product worktree. In embedded mode this
        # equals MAESTRO_DIR (artefact root == workspace) and the guards no-op.
        crew_env["MAESTRO_ARTEFACT_ROOT"] = _mso_dir
        # BUG-MSO-2026-0302: discoverable spawn marker — lets the cleanup orphan
        # sweep find crew-descended processes that no PID file references
        # (a grandchild whose parent died is unreachable via taskkill /T).
        crew_env["MAESTRO_SPAWN_MARKER"] = _spawn_marker()
        _branch = voyage_branch or ACTIVE_VOYAGE_BRANCH
        if _branch:
            crew_env["MAESTRO_SPRINT_BRANCH"] = _branch

        # v2.0.0 / FTR-0149: Inject managed repo path so Claude CLI knows where to work.
        # worktree_path takes precedence — it is the per-voyage git worktree.
        _repo = worktree_path or repo_path
        if _repo:
            crew_env["MAESTRO_REPO_PATH"] = _repo

        # v2.0.5: Inject project acronym for multi-project awareness
        _project = project_acronym or os.environ.get("MAESTRO_PROJECT", "OTM")
        crew_env["MAESTRO_PROJECT"] = _project

        # BUG-MSO-2026-0550: isolate the crew's user-global Maestro home so
        # anything the crew runs (a real crew tool call, or a verification
        # smoke test like `mso init` / `mso doctor`) can NEVER touch the
        # operator's real ~/.maestro — registry (projects.json), licence
        # cache, Hub pid/token, persona config, governance keyring all
        # resolve through get_maestro_home(), which honours MAESTRO_HOME
        # (BUG-MSO-2026-0387). Pointing it at a per-crew scratch dir under
        # the crew's own gitignored runtime dir means isolation holds even if
        # the crew forgets to clean up — nothing it registers survives the
        # crew dir, and it never reaches the real global state in the first
        # place. Chosen over gating `mso init` on MAESTRO_CREW (needs no
        # crew-side discipline) or a --scratch flag (relies on the crew
        # remembering to pass it) — this is the same isolation LEAD used by
        # hand when smoke-testing the governance flow.
        _crew_home = get_crew_dir(crew_number) / "maestro-home"
        _crew_home.mkdir(parents=True, exist_ok=True)
        crew_env["MAESTRO_HOME"] = str(_crew_home)

        # We pass crew_env explicitly via env= so that the MAESTRO_* injections
        # above are forwarded to the crew process.
        # FTR-0149: use worktree_path as cwd when available (crew boots inside its
        # dedicated worktree); fall back to base dir for legacy/no-worktree paths.
        crew_cwd = worktree_path if worktree_path else str(get_base_dir())

        if os.name == 'nt':
            # v6.0: Background mode - no visible console window
            # DETACHED_PROCESS: No console allocated (runs silently)
            # CREATE_NEW_PROCESS_GROUP: Own process group (Ctrl+C isolation)
            # Monitor fleet via fleet_monitor.py instead of crew windows
            # Crew log: .mso/crews/crewN/crew.log (stdout/stderr)
            # Crew output: .mso/crews/crewN/output_N.txt (from Claude)
            flags = DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP

            # Open log file for crew stdout/stderr (stays open via inherited handle)
            log_path = get_crew_dir(crew_number) / "crew.log"
            log_path.parent.mkdir(parents=True, exist_ok=True)
            log_fh = open(str(log_path), 'w', encoding='utf-8')

            proc = _spawn(
                crew_cmd,
                identity="fleet_runner",
                workspace=get_base_dir(),
                creationflags=flags,
                stdout=log_fh,
                stderr=subprocess.STDOUT,
                stdin=subprocess.DEVNULL,
                cwd=crew_cwd,
                env=crew_env,
            )
            # Don't close log_fh yet - the child process inherits the fd
            # Store it so we can close after confirming launch
            _CREW_LOG_HANDLES[crew_number] = log_fh
        else:
            proc = _spawn(
                crew_cmd,
                identity="fleet_runner",
                workspace=get_base_dir(),
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                cwd=crew_cwd,
                start_new_session=True,  # Unix equivalent: own process group
                env=crew_env,
            )

        pid = proc.pid

        # Save PID to file for cleanup capability
        pid_file = get_crew_dir(crew_number) / "pid.txt"
        pid_file.parent.mkdir(parents=True, exist_ok=True)
        pid_file.write_text(str(pid), encoding='utf-8')

        # CRITICAL: Release the Popen object immediately (like Ralph's $proc.Dispose())
        # This severs the parent-child relationship
        del proc

        # Give it a moment to start
        time.sleep(1)

        # Verify it's running via PID check (not proc.poll())
        if not is_process_alive(pid):
            print_error(f"Crew {crew_number} process exited immediately")
            # Close log handle on failure
            if crew_number in _CREW_LOG_HANDLES:
                try: _CREW_LOG_HANDLES.pop(crew_number).close()
                except: pass
            return None

        # Close parent's copy of log handle - child has its own inherited copy
        if crew_number in _CREW_LOG_HANDLES:
            try: _CREW_LOG_HANDLES.pop(crew_number).close()
            except: pass

        return pid

    except Exception as e:
        print_error(f"Failed to start Crew {crew_number}: {e}")
        if crew_number in _CREW_LOG_HANDLES:
            try: _CREW_LOG_HANDLES.pop(crew_number).close()
            except: pass
        return None

def is_process_alive(pid: int) -> bool:
    """Check if a process with the given PID is still running.

    Uses ctypes OpenProcess on Windows for reliability (works from cmd.exe AND Git Bash).
    The old tasklist /FI approach fails from Git Bash because it translates /FI to a path.
    Falls back to os.kill(0) on other platforms.
    """
    if pid <= 0:
        return False
    try:
        if os.name == 'nt':
            import ctypes
            PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            STILL_ACTIVE = 259
            kernel32 = ctypes.windll.kernel32
            handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
            if handle == 0:
                return False  # Can't open = doesn't exist or no access
            try:
                exit_code = ctypes.c_ulong()
                if kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code)):
                    return exit_code.value == STILL_ACTIVE
                return False
            finally:
                kernel32.CloseHandle(handle)
        else:
            os.kill(pid, 0)  # Signal 0 = existence check
            return True
    except (ProcessLookupError, PermissionError, OSError):
        return False


def read_crew_pid(crew_number: int) -> Optional[int]:
    """Read crew PID from pid.txt file."""
    pid_file = get_crew_dir(crew_number) / "pid.txt"
    if pid_file.exists():
        try:
            return int(pid_file.read_text(encoding='utf-8').strip())
        except (ValueError, IOError):
            return None
    return None


def save_fleet_state():
    """Save current fleet state for crash recovery."""
    global FLEET_STATE_FILE

    if not FLEET_STATE_FILE:
        FLEET_STATE_FILE = get_artefact_root() / "fleet-runner-state.json"

    state = {
        "pids": {},
        "timestamp": datetime.now().isoformat(),
        "status": "RUNNING"
    }

    # Collect PIDs from active tracking and pid.txt files
    for crew_num in range(1, 6):
        pid = ACTIVE_PROCESSES.get(crew_num)
        if not pid:
            pid = read_crew_pid(crew_num)
        if pid and is_process_alive(pid):
            state["pids"][str(crew_num)] = pid

    try:
        FLEET_STATE_FILE.write_text(json.dumps(state, indent=2), encoding='utf-8')
    except:
        pass

def _kill_orphaned_monitor() -> bool:
    """Kill a live fleet_monitor.py process tied to this workspace, and clear its PID lock.

    BUG-MSO-2026-0403: the monitor is auto-launched by the dispatcher
    (auto_launch_monitor) but nothing tore it down when the dispatcher exited
    (idle-reap OR manual stop) — it was observed surviving as an orphan
    repeatedly across 2026-07-18..20. The monitor's lifetime should be tied to
    its dispatcher's; this is the teardown half of that contract (the other
    half is `monitor.pid` staleness cleanup, unchanged).
    """
    monitor_lock = get_artefact_root() / "monitor.pid"
    if not monitor_lock.exists():
        return False
    try:
        mpid = int(monitor_lock.read_text(encoding='utf-8').strip())
    except (ValueError, OSError):
        try:
            monitor_lock.unlink()
        except OSError:
            pass
        return False

    killed = False
    if mpid and mpid != os.getpid() and is_process_alive(mpid):
        try:
            if os.name == 'nt':
                run_hidden(['taskkill', '/F', '/T', '/PID', str(mpid)],
                           capture_output=True, timeout=5)
            else:
                os.kill(mpid, 9)
            killed = True
        except Exception:
            pass
    try:
        monitor_lock.unlink()
    except OSError:
        pass
    return killed


def cleanup_fleet(reason: str = "shutdown"):
    """Clean up all fleet processes."""
    global SHUTDOWN_REQUESTED
    SHUTDOWN_REQUESTED = True

    print(f"\n  {C.YELLOW}Cleaning up fleet ({reason})...{C.RESET}")

    # Kill by tracked PIDs
    for crew_num, pid in list(ACTIVE_PROCESSES.items()):
        if pid and is_process_alive(pid):
            try:
                if os.name == 'nt':
                    run_hidden(
                        ['taskkill', '/F', '/T', '/PID', str(pid)],
                        capture_output=True, timeout=5
                    )
                else:
                    os.kill(pid, 9)
                print_info(f"Stopped Crew {crew_num} (PID {pid})")
            except:
                pass

    # Also check pid.txt files for any crews not in ACTIVE_PROCESSES
    for crew_num in range(1, 6):
        if crew_num not in ACTIVE_PROCESSES:
            pid = read_crew_pid(crew_num)
            if pid and is_process_alive(pid):
                try:
                    if os.name == 'nt':
                        run_hidden(
                            ['taskkill', '/F', '/T', '/PID', str(pid)],
                            capture_output=True, timeout=5
                        )
                    print_info(f"Stopped orphaned Crew {crew_num} (PID {pid})")
                except:
                    pass

    ACTIVE_PROCESSES.clear()

    # Clear fleet state file
    if FLEET_STATE_FILE and FLEET_STATE_FILE.exists():
        try:
            FLEET_STATE_FILE.unlink()
        except:
            pass

    # BUG-MSO-2026-0403: the monitor is a display companion, not independent
    # work — it must not outlive the dispatcher that launched it.
    if _kill_orphaned_monitor():
        print_info("Stopped Maestro Monitor")

    print(f"  {C.GREEN}Cleanup complete.{C.RESET}\n")

def signal_handler(signum, frame):
    """Handle interrupt signals."""
    cleanup_fleet("user interrupt")
    sys.exit(0)


# =============================================================================
# STATUS DISPLAY
# =============================================================================

def read_crew_state(crew_number: int) -> Optional[Dict[str, Any]]:
    """Read crew state from file."""
    state_file = get_crew_dir(crew_number) / "state.json"
    if state_file.exists():
        try:
            return json.loads(state_file.read_text(encoding='utf-8'))
        except:
            return None
    return None

    # Legacy manifest-mode print_status_board removed in v2.0.4


# =============================================================================
# WAVE SEQUENCING v4.0
# =============================================================================

def _mark_order_terminal_now() -> None:
    """Record that an order just reached a terminal archive (COMPLETE/STALLED).

    BUG-MSO-2026-0024: Eight Bells consults this timestamp so it cannot fire in
    the brief window after an order archives but before the dispatcher re-scans
    queues to notice a freshly-unblocked dependent.
    """
    global LAST_ORDER_TERMINAL_AT
    LAST_ORDER_TERMINAL_AT = datetime.now()


def _eight_bells_grace_elapsed() -> bool:
    """True if enough time has passed since the last order archive to ring Eight Bells.

    BUG-MSO-2026-0024: returns False during the grace window after a COMPLETE/STALLED
    archive, so a freshly-unblocked dependent gets a chance to be dispatched first.
    """
    if LAST_ORDER_TERMINAL_AT is None:
        return True
    try:
        grace = int(os.environ.get("MAESTRO_EIGHT_BELLS_GRACE_SECONDS", str(EIGHT_BELLS_GRACE_SECONDS)))
    except (TypeError, ValueError):
        grace = EIGHT_BELLS_GRACE_SECONDS
    if grace <= 0:
        return True
    return (datetime.now() - LAST_ORDER_TERMINAL_AT).total_seconds() >= grace


def ring_bell():
    """Ring the bell - voyage complete!"""
    print()
    print(f"  {C.GREEN}{C.BOLD}{'='*70}")
    print(f"  🔔🔔🔔  {current_persona().term('sprint').upper()} COMPLETE!  🔔🔔🔔")
    print(f"  {'='*70}{C.RESET}")
    print()
    try:
        import winsound
        # Three ascending bell tones for voyage complete
        winsound.Beep(800, 300)
        winsound.Beep(1000, 300)
        winsound.Beep(1200, 500)
    except Exception:
        pass


def ring_crew_bell(crew_num: int, order_id: str):
    """Ring a single bell - crew order complete!"""
    crew_name = _get_crew_name(crew_num)
    print(f"  {C.GREEN}🔔 BELL - {crew_name} completed {order_id}{C.RESET}")
    try:
        import winsound
        winsound.Beep(1000, 200)
    except Exception:
        pass


def run_post_voyage_matrix_update():
    """v8.6: Post-voyage — refresh REQUIREMENTS-MATRIX.md from current data.

    Runs .mso/tools/update-matrix.py to sync the matrix with
    _INDEX.md (specifications) and TRACEABILITY-REPORT.md (scanner counts).
    Non-blocking: logs warning on failure but does not halt the dispatcher.
    """
    update_script = get_artefact_root() / "tools" / "update-matrix.py"
    if not update_script.exists():
        print_warn("Post-voyage matrix update skipped — update-matrix.py not found")
        return

    print_info("Post-voyage: Refreshing REQUIREMENTS-MATRIX.md...")
    try:
        result = run_hidden(
            [sys.executable, str(update_script)],
            capture_output=True, text=True, timeout=60,
            cwd=str(get_product_repo())
        )
        if result.returncode == 0:
            print_ok("Requirements matrix updated successfully")
            write_lifecycle_event("POST-VOYAGE", "REQUIREMENTS-MATRIX.md refreshed by update-matrix.py")
        else:
            print_warn(f"Matrix update exited with code {result.returncode}")
            if result.stderr:
                print_warn(f"  {result.stderr.strip()[:200]}")
    except subprocess.TimeoutExpired:
        print_warn("Matrix update timed out (60s) — skipping")
    except Exception as e:
        print_warn(f"Matrix update failed: {e}")


def run_post_voyage_pr_creation():
    """v8.13: Post-voyage -- auto-create PRs from voyage branch to main.

    Uses _SESSION_TARGET_REPOS (populated during dispatch) to know which repos
    had orders dispatched this session. Only checks those repos for commits
    ahead of the project's resolved default branch (e.g. `master` for PSG,
    `main` for the framework), avoiding API rate limits from scanning all
    historical orders.

    BUG-MSO-2026-0016 (v2.8.2): both the COMPARE check and the `gh pr create`
    call now resolve the base via `_get_default_branch_for_repo()` rather
    than hardcoded `main`. Operators on non-main-default repos (PSG) get
    PRs opened against the correct base.

    v2.0.2: Uses per-repo voyage branches from _SESSION_REPO_BRANCHES instead of
    the global ACTIVE_VOYAGE_BRANCH, supporting mixed-voyage dispatch sessions.

    Non-blocking: logs warning on failure but does not halt the dispatcher.
    Skips repos where no voyage branch exists or where a PR already exists.
    """
    # v2.0.2: Check if we have any per-repo branches OR a global branch
    if not ACTIVE_VOYAGE_BRANCH and not _SESSION_REPO_BRANCHES:
        print_warn("Post-voyage PR creation skipped -- no voyage branch set")
        return

    org = _load_workspace_org()

    # Use session-tracked repos (populated during dispatch_crew)
    if not _SESSION_TARGET_REPOS:
        print_info("Post-voyage PR creation: no repos dispatched this session")
        return

    order_summaries = _SESSION_TARGET_REPOS
    target_repos = set(order_summaries.keys())

    print_info(f"Post-voyage: Checking {len(target_repos)} repo(s) dispatched this session for PRs...")

    created = 0
    skipped = 0
    failed = 0

    for repo in sorted(target_repos):
        full_repo = f"{org}/{repo}"
        # v2.0.2: Per-repo voyage branch resolution
        repo_branch = _SESSION_REPO_BRANCHES.get(repo, ACTIVE_VOYAGE_BRANCH)
        if not repo_branch:
            print_info(f"  {repo}: no voyage branch known -- skipping")
            skipped += 1
            continue
        branch_ref = repo_branch.replace("refs/heads/", "")

        try:
            # v8.13: Small delay between repos to avoid GitHub secondary rate limits
            time.sleep(1)

            # Check if voyage branch exists on this repo
            check = run_hidden(
                ["gh", "api", f"repos/{full_repo}/branches/{branch_ref}",
                 "--jq", ".name"],
                capture_output=True, text=True, timeout=30
            )
            if check.returncode != 0 or not check.stdout.strip():
                print_info(f"  {repo}: no voyage branch -- skipping")
                skipped += 1
                continue

            # Check if PR already exists for this branch
            pr_check = run_hidden(
                ["gh", "pr", "list", "--repo", full_repo,
                 "--head", branch_ref, "--state", "open", "--json", "number,url"],
                capture_output=True, text=True, timeout=30
            )
            if pr_check.returncode == 0 and pr_check.stdout.strip() not in ("", "[]"):
                # BUG-MSO-2026-0360: found-existing — make sure the voyage
                # manifest carries the linkage before skipping.
                try:
                    _prs = json.loads(pr_check.stdout)
                    if _prs:
                        record_voyage_pr_linkage(
                            branch_ref, _prs[0].get("url") or "",
                            _prs[0].get("number"))
                except Exception:
                    pass
                print_info(f"  {repo}: PR already exists -- skipping")
                skipped += 1
                continue

            # BUG-ADM-2026-0013: resolve base branch from project registry —
            # PSG uses `master`, framework uses `main`. Hardcoded `main` here
            # silently 404'd on PSG, so PRs never got opened.
            default_branch = _get_default_branch_for_repo(repo)

            # Check if branch has commits ahead of the project's default branch
            compare = run_hidden(
                ["gh", "api", f"repos/{full_repo}/compare/{default_branch}...{branch_ref}",
                 "--jq", ".ahead_by"],
                capture_output=True, text=True, timeout=30
            )
            ahead_by = 0
            if compare.returncode == 0:
                try:
                    ahead_by = int(compare.stdout.strip())
                except ValueError:
                    pass
            else:
                print_warn(f"  {repo}: compare API failed against {default_branch} (rc={compare.returncode}) -- {compare.stderr.strip()[:100]}")

            if ahead_by == 0:
                print_info(f"  {repo}: no commits ahead of {default_branch} -- skipping")
                skipped += 1
                continue

            # v8.13.1: Check actual file diff to avoid empty PRs
            # (ahead_by can be > 0 for commits already merged via previous voyage)
            diff_check = run_hidden(
                ["gh", "api", f"repos/{full_repo}/compare/{default_branch}...{branch_ref}",
                 "--jq", ".files | length"],
                capture_output=True, text=True, timeout=30
            )
            changed_files = 0
            if diff_check.returncode == 0:
                try:
                    changed_files = int(diff_check.stdout.strip())
                except ValueError:
                    pass

            if changed_files == 0:
                print_info(f"  {repo}: {ahead_by} commit(s) but 0 changed files -- skipping (already merged)")
                skipped += 1
                continue

            # Build PR body from order summaries
            orders = order_summaries.get(repo, [])
            body_lines = [f"## Summary", ""]
            body_lines.append(f"Voyage branch `{branch_ref}` with {ahead_by} commit(s).")
            body_lines.append("")
            body_lines.append("### Orders Completed")
            for t in orders[:20]:  # Cap at 20 to avoid huge PR bodies
                body_lines.append(f"- {t}")
            body_lines.append("")
            body_lines.append("## Test plan")
            body_lines.append("- [ ] CI checks pass")
            body_lines.append("- [ ] Code review completed")
            body_lines.append("")

            pr_body = "\n".join(body_lines)
            pr_title = f"[{branch_ref}] {repo} ({len(orders)} order(s))"
            if len(pr_title) > 70:
                pr_title = f"[{branch_ref}] {repo}"

            # Create the PR
            pr_result = run_hidden(
                ["gh", "pr", "create",
                 "--repo", full_repo,
                 "--base", default_branch,
                 "--head", branch_ref,
                 "--title", pr_title,
                 "--body", pr_body],
                capture_output=True, text=True, timeout=60
            )

            if pr_result.returncode == 0:
                pr_url = pr_result.stdout.strip()
                print_ok(f"  {repo}: PR created -> {pr_url}")
                write_lifecycle_event("POST-VOYAGE", f"PR created for {repo}: {pr_url}")
                # BUG-MSO-2026-0360: record the linkage on the voyage manifest.
                record_voyage_pr_linkage(branch_ref, pr_url)
                created += 1
            else:
                err = pr_result.stderr.strip()[:200]
                print_warn(f"  {repo}: PR creation failed -- {err}")
                failed += 1

        except subprocess.TimeoutExpired:
            print_warn(f"  {repo}: timeout -- skipping")
            failed += 1
        except Exception as e:
            print_warn(f"  {repo}: error -- {e}")
            failed += 1

    print_info(f"Post-voyage PRs: {created} created, {skipped} skipped, {failed} failed")
    write_lifecycle_event("POST-VOYAGE", f"Auto-PR: {created} created, {skipped} skipped, {failed} failed")


    # Legacy manifest-mode wave functions removed in v2.0.4


# =============================================================================
# AUTO-DISPATCHER v5.2
# =============================================================================

def get_queues_dir() -> Path:
    """Get the queues directory."""
    return get_artefact_root() / "queues"


def scan_requests_queue() -> List[Dict[str, Any]]:
    """Scan requests queue for pending items. Returns list sorted by priority."""
    requests = []
    requests_dir = get_queues_dir() / "requests"

    # Priority order for request types
    request_priority = {
        "planning": 1,      # NAV planning - highest priority
        "investigation": 2, # LKT investigation
        "qa": 3,            # BOS QA
        "security-scan": 4, # LKT security
        "documentation": 5  # SCR documentation
    }

    # Role mapping for request types
    request_roles = {
        "planning": "NAV",
        "investigation": "LKT",
        "qa": "BOS",
        "security-scan": "LKT",
        "documentation": "SCR"
    }

    if not requests_dir.exists():
        return []

    for subdir in requests_dir.iterdir():
        if subdir.is_dir():
            req_type = subdir.name
            for json_file in subdir.glob("*.json"):
                try:
                    data = _read_order_file_tolerant(json_file)
                    status = data.get("status", "PENDING")
                    if status == "PENDING":
                        # v8.6: Resolve ID and title consistently
                        req_id = data.get("orderId") or data.get("id") or json_file.stem
                        req_title = data.get("title") or data.get("description", "")
                        if not req_title:
                            parts = req_id.split("-", 1)
                            req_title = parts[1] if len(parts) > 1 else req_id

                        requests.append({
                            "type": "REQUEST",
                            "subtype": req_type,
                            "id": req_id,
                            "title": req_title,
                            "priority": request_priority.get(req_type, 10),
                            "role": request_roles.get(req_type, "NAV"),
                            "path": str(json_file),
                            "data": data
                        })
                except Exception as e:
                    msg = f"Unreadable request file skipped: {json_file.name} — {e}"
                    print_warn(msg)
                    write_lifecycle_event("ERROR", msg)

    # Sort by priority (lower = higher priority)
    return sorted(requests, key=lambda x: x["priority"])


def scan_orders_queue() -> List[Dict[str, Any]]:
    """Scan orders queue for pending items. Returns list sorted by priority."""
    orders = []
    orders_dir = get_queues_dir() / "orders"

    # Priority mapping
    priority_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "NORMAL": 2}

    # Order type to role mapping (default role)
    order_roles = {
        "FIX": "SHP",
        "BUG": "SHP",
        "TEST": "SHP",  # Writing tests is SHP work
        "SEC": "LKT",   # Security starts with LKT
        "FTR": "NAV",   # Features start with NAV planning
        "RFT": "SHP",   # Refactor is SHP work
        "DOC": "SCR",   # Documentation is SCR work
        "INV": "LKT"    # Investigation is LKT work
    }

    if not orders_dir.exists():
        return []

    for json_file in orders_dir.glob("*.json"):
        try:
            data = _read_order_file_tolerant(json_file)
            status = data.get("status", "PENDING")
            if status == "PENDING":
                # v8.6.1: Backwards-compat — check both "orderType" and "type" fields
                order_type = data.get("orderType") or data.get("type", "FIX")
                # Normalize: if "type" was "ORDER", it's not a valid orderType — use "FIX"
                if order_type == "ORDER":
                    order_type = data.get("orderType", "FIX")
                priority_str = data.get("priority", "MEDIUM")
                # v8.8: Check targetRole, role, roleSequence[0], then infer from orderType
                target_role = data.get("targetRole") or data.get("role") or ""
                if not target_role:
                    seq = data.get("roleSequence", [])
                    target_role = seq[0] if seq else order_roles.get(order_type, "SHP")

                # v8.6: Resolve ID and title consistently
                item_id = data.get("orderId") or data.get("id") or json_file.stem
                item_title = data.get("title") or data.get("description", "")
                if not item_title:
                    parts = item_id.split("-", 1)
                    item_title = parts[1] if len(parts) > 1 else item_id

                orders.append({
                    "type": "ORDER",
                    "subtype": order_type,
                    "id": item_id,
                    "title": item_title,
                    "priority": priority_order.get(priority_str, 2),
                    "role": target_role,
                    "path": str(json_file),
                    "data": data
                })
        except Exception as e:
            msg = f"Unreadable order file skipped: {json_file.name} — {e}"
            print_warn(msg)
            write_lifecycle_event("ERROR", msg)

    # Sort by priority (lower = higher priority)
    return sorted(orders, key=lambda x: x["priority"])


# =============================================================================
# v8.2: Role Sequence Gate Enforcement
# =============================================================================

# Loaded from order templates at startup — maps orderType to roleSequence
ROLE_SEQUENCES: Dict[str, List[str]] = {}

# BUG-MSO-2026-0205: the post-plan human review gate must fire for the canonical
# planning role `PLN` as well as the legacy nautical alias `NAV`. The original
# gate only matched `"NAV"`, so canonical-role workspaces were never paused.
_PLANNING_ROLES = {"PLN", "NAV"}


def _is_planning_role(role: str) -> bool:
    """True if `role` is the planning role (canonical PLN or legacy NAV alias)."""
    return (role or "").upper() in _PLANNING_ROLES


# BUG-MSO-2026-0401: the security-review role (canonical SEC, legacy nautical
# alias LKT). An order whose roleSequence includes one of these MUST leave a
# review artefact behind before it can be archived COMPLETE — otherwise the
# finalization pipeline is trusting "SEC returned success" with zero evidence
# the review happened (observed on FTR-MSO-2026-0397, a cryptographic order).
_SEC_ROLES = {"SEC", "LKT"}


def _sequence_sec_role(sequence: Optional[List[str]]) -> Optional[str]:
    """Return the SEC-family role present in *sequence*, or None.

    Matches the canonical `SEC` code and the legacy nautical `LKT` alias so the
    gate fires regardless of which vocabulary the order's roleSequence uses.
    """
    for role in (sequence or []):
        if (role or "").upper() in _SEC_ROLES:
            return role
    return None


def sec_artefact_present(order_id: str, data: Dict[str, Any],
                         admiralty_dir: Path) -> bool:
    """True if a SEC review artefact exists for *order_id* (BUG-MSO-2026-0401).

    Accepts either:
      - a structured ``secDecision`` field on the order JSON (mirrors the
        ``qaDecision`` pattern used for the Tester), or
      - a report file under ``reports/security/`` or ``reports/investigation/``
        whose name references the order id. The canonical SEC deliverable is
        ``SEC-{ORDER-ID}.md``; ``mso security review --order`` also emits
        ``SEC-{ORDER-ID}.json`` (consumed by the COX merge gate in
        pr_merge.py), so both extensions count. INV-type orders' SEC-family
        deliverable is instead ``INV-{ORDER-ID}.md`` under
        ``reports/investigation/`` (see maestro/roles/SEC.md OUTPUT Locations)
        — BUG-MSO-2026-0444: checking ``reports/security/`` only made this
        gate false-positive SEC_ARTEFACT_MISSING for every investigation
        order, regardless of filename (INV-PSG-2026-0529 was held even though
        INV-PSG-2026-0529-advertise.md was present and complete on disk).

    BUG-MSO-2026-0465: the match below is ``order_id in filename``, not an
    exact-name comparison — deliberately so it stays tolerant of both the
    BUG-0444 filename-suffix case above AND a SEC-/INV-type order id (whose id
    already begins with the same prefix the deliverable template adds, e.g.
    ``SEC-MSO-2026-0461``): the crew's correctly-written
    ``SEC-MSO-2026-0461.md`` contains ``SEC-MSO-2026-0461`` as a substring
    either way, so no special-casing is needed here. Only the human-facing
    "what did we look for" diagnostics
    (:func:`_sec_artefact_search_description`) and the OTHER, exact-match
    constructors of this filename (``mso security review --order`` in cli.py,
    the COX/REL merge gate in pr_merge.py, the OWASP posttool scanner) needed
    the anti-doubling fix — see :func:`maestro.workspace.artefact_report_stem`.
    """
    # Structured decision recorded directly on the order (fast path).
    if data.get("secDecision"):
        return True
    oid = (order_id or "").upper()
    if not oid:
        return False
    for sub_dir in ("security", "investigation"):
        report_dir = admiralty_dir / "reports" / sub_dir
        if not report_dir.exists():
            continue
        for report in report_dir.iterdir():
            if not report.is_file():
                continue
            if report.suffix.lower() not in (".md", ".json"):
                continue
            if oid in report.stem.upper():
                return True
    return False


def _sec_artefact_search_description(order_id: str) -> str:
    """Human-readable description of exactly what sec_artefact_present() looked
    for and where (BUG-MSO-2026-0459) — so a SEC_ARTEFACT_MISSING message reads
    as 'SEC wrote nothing' rather than an ambiguous gate failure, and is
    distinguishable from 'SEC wrote it somewhere unexpected'.

    BUG-MSO-2026-0465: routes through :func:`maestro.workspace.artefact_report_stem`
    so a SEC-type (or INV-type) order id — whose id already begins with the
    same prefix, e.g. ``SEC-MSO-2026-0461`` — is described accurately as
    ``SEC-MSO-2026-0461.md``, not the doubled ``SEC-SEC-MSO-2026-0461.md`` a
    naive ``f"SEC-{order_id}"`` would print (which no crew following
    maestro/roles/SEC.md would ever actually write).
    """
    from maestro.workspace import artefact_report_stem
    oid = order_id or "<order-id>"
    sec_stem = artefact_report_stem("SEC", oid)
    inv_stem = artefact_report_stem("INV", oid)
    return (
        f"{MSO_DIR_NAME}/reports/security/{sec_stem}.md (or .json), "
        f"{MSO_DIR_NAME}/reports/investigation/{inv_stem}.md (or .json), "
        f"or a secDecision field on the order JSON"
    )


def _hold_missing_sec_artefact(order_id: str, data: Dict[str, Any],
                               sec_role: str, source_file: Path,
                               completed_role: str, admiralty_dir: Path,
                               crew_num: int) -> Path:
    """Requeue *order_id* at the SEC role because its review artefact is missing.

    Called both from the EARLY gate at the SEC role's own completion
    (:func:`_check_sec_gate_at_role_completion`, BUG-MSO-2026-0459 — before the
    local verify gate / convergence ever runs) and, as a backstop, from the
    final-role archival branches of :func:`complete_order` (BUG-MSO-2026-0401)
    when the order's roleSequence includes a SEC-family role but no SEC
    artefact exists by the time the order's LAST role finishes. The order is
    written back to ``queues/orders/`` as ``PENDING@<sec_role>`` so the
    dispatcher re-runs the security review instead of silently completing.
    Emits a ``SEC_ARTEFACT_MISSING`` lifecycle event. Returns the destination
    path.

    BUG-MSO-2026-0444: this is a requeue like any other and MUST consume the
    MAX_REQUEUES budget. Previously it wrote status/targetRole/secArtefactMissing
    without ever touching requeueCount, so an order whose gate kept firing (a
    stale/misnamed report, a discriminator bug) cycled the SEC role forever —
    INV-PSG-2026-0529 requeued twice with requeueCount frozen at 0, re-running
    a ~40-minute investigation whose report had already been written correctly
    on the first pass. Once the cap is hit, escalate to STALLED instead.
    """
    requeue_count = int(data.get("requeueCount", 0))
    if requeue_count >= MAX_REQUEUES:
        return _stall_missing_sec_artefact(
            order_id, data, sec_role, source_file, completed_role,
            admiralty_dir, crew_num, requeue_count)

    # BUG-MSO-2026-0248: arm the transition gate BEFORE writing so the scanner
    # never sees an un-gated PENDING copy.
    ORDERS_IN_TRANSITION.add(order_id)
    data["status"] = "PENDING"
    data["targetRole"] = sec_role
    data["secArtefactMissing"] = True
    data["requeueCount"] = requeue_count + 1
    data.pop("assignedTo", None)
    data.pop("startedAt", None)

    queue_dir = admiralty_dir / "queues" / "orders"
    queue_dir.mkdir(parents=True, exist_ok=True)
    dest = queue_dir / source_file.name
    dest.write_text(json.dumps(data, indent=2), encoding='utf-8')
    # Relocate from a non-queue source (e.g. orders/active/, queues/security/).
    if dest.resolve() != source_file.resolve():
        source_file.unlink(missing_ok=True)

    # BUG-MSO-2026-0294: reset the durable role back to SEC and clear any claim
    # so the dispatch gate re-dispatches the review rather than vetoing it.
    order_ledger.record_advanced(order_id, completed_role, sec_role,
                                 workspace_dir=admiralty_dir)
    # BUG-MSO-2026-0295: commit the transition so a git rewind can't resurrect
    # the (wrongful) completion.
    _commit_lifecycle_transition(
        [dest, source_file],
        f"lifecycle: hold {order_id} SEC_ARTEFACT_MISSING -> requeue @{sec_role}",
    )
    _search_desc = _sec_artefact_search_description(order_id)
    print_warn(
        f"Order {order_id} completed role {completed_role} with no SEC "
        f"artefact -> held (SEC_ARTEFACT_MISSING), requeued @{sec_role} "
        f"[attempt {requeue_count + 1}/{MAX_REQUEUES}]. Looked for: {_search_desc}"
    )
    write_lifecycle_event(
        "SEC_ARTEFACT_MISSING",
        f"{order_id} no SEC artefact at completion of {completed_role} -> requeued "
        f"@{sec_role} [attempt {requeue_count + 1}/{MAX_REQUEUES}] "
        f"(Crew {crew_num}, BUG-0401/0444/0459). Looked for: {_search_desc}"
    )
    ring_crew_bell(crew_num, order_id)
    return dest


def _stall_missing_sec_artefact(order_id: str, data: Dict[str, Any], sec_role: str,
                                source_file: Path, completed_role: str,
                                admiralty_dir: Path, crew_num: int,
                                requeue_count: int) -> Path:
    """Escalate a SEC_ARTEFACT_MISSING order to STALLED once MAX_REQUEUES is hit.

    BUG-MSO-2026-0444: mirrors the STALLED-archive shape used by
    :func:`archive_stalled_order`, but operates directly on the already
    located *source_file* instead of re-searching the queue directories — the
    order may currently be sitting in ``orders/active/`` (the v8.5 fallback
    caller), which ``archive_stalled_order``'s search does not scan.
    """
    archive_dir = admiralty_dir / "orders" / "complete"
    archive_dir.mkdir(parents=True, exist_ok=True)

    _search_desc = _sec_artefact_search_description(order_id)
    reason = (
        f"SEC_ARTEFACT_MISSING requeue cap exceeded ({requeue_count}/{MAX_REQUEUES}) "
        f"— no SEC artefact found after {requeue_count} requeue(s) @{sec_role}. "
        f"Looked for: {_search_desc}"
    )
    data["status"] = "STALLED"
    data["stalledAt"] = datetime.now().isoformat()
    data["stalledReason"] = reason
    data["stalledCause"] = "ERROR"
    data["stalledBy"] = {
        "crew": crew_num,
        "role": completed_role,
        "iterations": 0,
        "startTime": "",
        "endTime": "",
    }
    data.pop("assignedTo", None)
    data.pop("startedAt", None)

    archive_file = archive_dir / source_file.name
    archive_file.write_text(json.dumps(data, indent=2), encoding='utf-8')
    if archive_file.resolve() != source_file.resolve():
        source_file.unlink(missing_ok=True)

    # BUG-MSO-2026-0294/0295: STALLED is terminal for dispatch purposes.
    order_ledger.record_terminal(order_id, "STALLED", workspace_dir=admiralty_dir)
    _commit_lifecycle_transition(
        [archive_file, source_file],
        f"lifecycle: archive {order_id} (STALLED, SEC_ARTEFACT_MISSING cap exceeded)",
    )
    # BUG-MSO-2026-0024: STALLED is a satisfying status, so dependents unblock.
    _mark_order_terminal_now()
    print_warn(
        f"Order {order_id} hit REQUEUE cap ({requeue_count}/{MAX_REQUEUES}) on "
        f"SEC_ARTEFACT_MISSING -> escalated to STALLED for human review."
    )
    write_lifecycle_event(
        "ESCALATE",
        f"{order_id} SEC_ARTEFACT_MISSING requeue cap exceeded "
        f"({requeue_count}/{MAX_REQUEUES}) -> STALLED (Crew {crew_num}, BUG-0444)"
    )
    ring_crew_bell(crew_num, order_id)
    # BUG-MSO-2026-0280: fire auto-queue from every terminal archival path so
    # dependents of this order are not stranded waiting on a STALLED parent.
    try:
        auto_queue_unblocked_orders(order_id)
    except Exception as _aq_exc:
        print_warn(f"Auto-queue after STALLED archival of {order_id} failed "
                   f"(non-fatal; reconciliation pass will recover): {_aq_exc}")
    return archive_file


# =============================================================================
# BUG-MSO-2026-0546 (GitHub #368): generalised per-role deliverable gate
# =============================================================================
# A role advanced (or archived) as SUCCEEDED with no deliverable at all — no
# commit, no handoff, no artefact — and the downstream role that correctly
# found nothing to do was then the one recorded as the cause of the stall.
# The SEC role already had exactly this guard for its own artefact
# (SEC_ARTEFACT_MISSING, BUG-MSO-2026-0401/0444/0459 above); this section
# generalises that proven hold/requeue/escalate shape to every role instead
# of inventing a second mechanism, per the order's explicit instruction.

def _role_deliverable_search_description(order_id: str, role: str) -> str:
    """Human-readable description of what role_deliverable_present() looked
    for, mirroring _sec_artefact_search_description()'s purpose."""
    role_u = (role or "").upper()
    if role_u in _SEC_ROLES:
        return _sec_artefact_search_description(order_id)
    if role_u in _PLANNING_ROLES:
        return f"{MSO_DIR_NAME}/plans/*.md referencing {order_id or '<order-id>'}"
    return (
        f"a commit on the order's voyage branch, authored after startedAt, "
        f"whose subject references {order_id or '<order-id>'}"
    )


def _plan_artefact_present(order_id: str, admiralty_dir: Path) -> bool:
    """True if a PLN-family role left a plan document for *order_id*.

    Mirrors sec_artefact_present()'s filename-substring search. The canonical
    shape is PLAN-{ORDER-ID}.md (see maestro/roles/PLN.md and the Hub's
    /review plan-file convention), but any .md under .mso/plans/ whose name
    references the order id counts.
    """
    oid = (order_id or "").upper()
    if not oid:
        return False
    plans_dir = admiralty_dir / "plans"
    if not plans_dir.exists():
        return False
    for plan_file in plans_dir.iterdir():
        if (plan_file.is_file() and plan_file.suffix.lower() == ".md"
                and oid in plan_file.stem.upper()):
            return True
    return False


def _voyage_branch_commit_status(order_data: Dict[str, Any]) -> Optional[bool]:
    """Tri-state sibling of _voyage_branch_has_post_started_commit() for a
    gate that must not FAIL CLOSED on unresolvable git state (BUG-MSO-2026-0546).

    _voyage_branch_has_post_started_commit() was written for BUG-MSO-2026-0023,
    where a False return only skips an OPTIMIZATION (advance instead of a
    wasted REQUEUE) — failing closed on "ref doesn't resolve" is harmless
    there because the legacy REQUEUE path is a perfectly safe fallback. Used
    as a hard advance/archive GATE instead, that same fail-closed behaviour
    would block every legitimately successful role whose voyage branch ref
    simply isn't resolvable from the current process (no local checkout of
    it yet, a test harness with no matching git fixture, etc.) — indistinguishable
    from "the branch exists but truly has no commit for this order", which is
    the ONLY case that should ever hold an order.

    Returns:
      - True  — the ref resolved and a commit referencing the order id,
                authored after startedAt, was found.
      - False — the ref resolved but NO matching commit exists — a genuine
                "nothing was committed" signal.
      - None  — the ref could not be resolved at all (missing fields, no
                local/remote ref, git unavailable) — indeterminate; callers
                must treat this as "can't tell", not as a negative.
    """
    order_id = order_data.get("orderId") or order_data.get("id")
    voyage_branch = order_data.get("voyageBranch")
    started_at = order_data.get("startedAt")
    if not (order_id and voyage_branch and started_at):
        return None

    candidate_refs = [voyage_branch, f"refs/remotes/origin/{voyage_branch}"]
    for ref in candidate_refs:
        try:
            verify = run_hidden(
                ["git", "rev-parse", "--verify", "--quiet", ref],
                capture_output=True, timeout=5
            )
            if verify.returncode != 0:
                continue
            log_result = run_hidden(
                ["git", "log", "--format=%s", f"--since={started_at}", ref],
                capture_output=True, text=True, timeout=10
            )
            if log_result.returncode != 0:
                continue
            for subject in log_result.stdout.splitlines():
                if order_id in subject:
                    return True
            # Found a valid ref but no matching commit; no need to check the other.
            return False
        except (subprocess.TimeoutExpired, Exception):
            continue
    return None


def role_deliverable_present(order_id: str, data: Dict[str, Any], role: str,
                             admiralty_dir: Path) -> bool:
    """True if *role* left the deliverable its role type requires for
    *order_id* (BUG-MSO-2026-0546).

    What counts as "a deliverable" is defined PER ROLE rather than assuming a
    single universal shape:
      - SEC/LKT — a security review artefact (sec_artefact_present(), the
        existing BUG-0401/0444/0459 check, unchanged).
      - PLN/NAV — a plan document under .mso/plans/ referencing the order id.
      - every other role (BLD/SHP, TST/BOS, DOC/SCR, REL/COX, ...) — a git
        commit on the order's voyage branch, authored after the order's
        startedAt, whose subject references the order id. Implementation and
        documentation roles both leave commits, so one check covers both;
        this reuses the same signal BUG-MSO-2026-0023's silent-completion
        detector trusts (via the tri-state _voyage_branch_commit_status()
        above) rather than a second, parallel "did anything happen"
        definition.

    Fails OPEN (True) if the role can't be classified, the order is missing
    the fields (voyageBranch/startedAt) the commit check needs, or the
    voyage branch ref simply can't be resolved from this process — a
    workspace/order not fully wired for this check must not have its orders
    wrongly held; absence of evidence here is not evidence of absence. Only a
    RESOLVED ref with no matching commit (status is False, not None) blocks.
    """
    role_u = (role or "").upper()
    if role_u in _SEC_ROLES:
        return sec_artefact_present(order_id, data, admiralty_dir)
    if role_u in _PLANNING_ROLES:
        return _plan_artefact_present(order_id, admiralty_dir)
    status = _voyage_branch_commit_status(data)
    if status is None:
        return True
    return status


def _hold_missing_deliverable(order_id: str, data: Dict[str, Any], requeue_role: str,
                              source_file: Path, completed_role: str,
                              admiralty_dir: Path, crew_num: int, *,
                              event_name: str = "ROLE_DELIVERABLE_MISSING",
                              cause_tag: str = "BUG-0546",
                              legacy_field: Optional[str] = None) -> Path:
    """Requeue *order_id* at *requeue_role* because *completed_role* produced
    no deliverable (BUG-MSO-2026-0546).

    Generalises the shape _hold_missing_sec_artefact() pioneered (BUG-0401/
    0444/0459) to every role: same MAX_REQUEUES budget, same STALLED
    escalation via _stall_missing_deliverable(), same commit-the-transition
    discipline. For a SEC-family completed_role, _check_role_deliverable_gate()
    passes event_name="SEC_ARTEFACT_MISSING", the BUG-0401/0444/0459 cause tag,
    and legacy_field="secArtefactMissing" so the existing lifecycle vocabulary
    and order-JSON field (both asserted on by the pre-existing SEC test suite)
    are unchanged for that case.
    """
    requeue_count = int(data.get("requeueCount", 0))
    if requeue_count >= MAX_REQUEUES:
        return _stall_missing_deliverable(
            order_id, data, requeue_role, source_file, completed_role,
            admiralty_dir, crew_num, requeue_count,
            event_name=event_name, cause_tag=cause_tag)

    # BUG-MSO-2026-0248: arm the transition gate BEFORE writing so the scanner
    # never sees an un-gated PENDING copy.
    ORDERS_IN_TRANSITION.add(order_id)
    data["status"] = "PENDING"
    data["targetRole"] = requeue_role
    data["roleDeliverableMissing"] = True
    if legacy_field:
        data[legacy_field] = True
    # BUG-MSO-2026-0546 fault 2: name the role that actually produced nothing
    # directly on the order, not just in the lifecycle log, so a later stall
    # elsewhere in the sequence can attribute back to the true origin.
    data["roleDeliverableMissingRole"] = completed_role
    data["requeueCount"] = requeue_count + 1
    data.pop("assignedTo", None)
    data.pop("startedAt", None)

    queue_dir = admiralty_dir / "queues" / "orders"
    queue_dir.mkdir(parents=True, exist_ok=True)
    dest = queue_dir / source_file.name
    dest.write_text(json.dumps(data, indent=2), encoding='utf-8')
    if dest.resolve() != source_file.resolve():
        source_file.unlink(missing_ok=True)

    order_ledger.record_advanced(order_id, completed_role, requeue_role,
                                 workspace_dir=admiralty_dir)
    _commit_lifecycle_transition(
        [dest, source_file],
        f"lifecycle: hold {order_id} {event_name} -> requeue @{requeue_role}",
    )
    _search_desc = _role_deliverable_search_description(order_id, completed_role)
    print_warn(
        f"Order {order_id} completed role {completed_role} with no deliverable "
        f"-> held ({event_name}), requeued @{requeue_role} "
        f"[attempt {requeue_count + 1}/{MAX_REQUEUES}]. Looked for: {_search_desc}"
    )
    write_lifecycle_event(
        event_name,
        f"{order_id} no deliverable from {completed_role} at completion -> requeued "
        f"@{requeue_role} [attempt {requeue_count + 1}/{MAX_REQUEUES}] "
        f"(Crew {crew_num}, {cause_tag}). Looked for: {_search_desc}"
    )
    ring_crew_bell(crew_num, order_id)
    return dest


def _stall_missing_deliverable(order_id: str, data: Dict[str, Any], requeue_role: str,
                               source_file: Path, completed_role: str,
                               admiralty_dir: Path, crew_num: int, requeue_count: int, *,
                               event_name: str = "ROLE_DELIVERABLE_MISSING",
                               cause_tag: str = "BUG-0546") -> Path:
    """Escalate a ROLE_DELIVERABLE_MISSING order to STALLED once MAX_REQUEUES
    is hit (BUG-MSO-2026-0546). Mirrors _stall_missing_sec_artefact()'s shape.
    """
    archive_dir = admiralty_dir / "orders" / "complete"
    archive_dir.mkdir(parents=True, exist_ok=True)

    _search_desc = _role_deliverable_search_description(order_id, completed_role)
    reason = (
        f"{event_name} requeue cap exceeded ({requeue_count}/{MAX_REQUEUES}) — "
        f"role {completed_role} produced no deliverable after {requeue_count} "
        f"requeue(s) @{requeue_role}. Looked for: {_search_desc}"
    )
    data["status"] = "STALLED"
    data["stalledAt"] = datetime.now().isoformat()
    data["stalledReason"] = reason
    data["stalledCause"] = "ERROR"
    # BUG-MSO-2026-0546 fault 2: the role NAME in stalledBy IS the true origin
    # here (the gate fired ON completed_role's own missing deliverable) — no
    # misattribution is possible on this path, unlike archive_stalled_order()'s
    # downstream-BLOCKED case, which _find_stall_origin_role() covers below.
    data["stalledBy"] = {
        "crew": crew_num,
        "role": completed_role,
        "iterations": 0,
        "startTime": "",
        "endTime": "",
    }
    data.pop("assignedTo", None)
    data.pop("startedAt", None)

    archive_file = archive_dir / source_file.name
    archive_file.write_text(json.dumps(data, indent=2), encoding='utf-8')
    if archive_file.resolve() != source_file.resolve():
        source_file.unlink(missing_ok=True)

    # BUG-MSO-2026-0294/0295: STALLED is terminal for dispatch purposes.
    order_ledger.record_terminal(order_id, "STALLED", workspace_dir=admiralty_dir)
    _commit_lifecycle_transition(
        [archive_file, source_file],
        f"lifecycle: archive {order_id} (STALLED, {event_name} cap exceeded)",
    )
    _mark_order_terminal_now()
    print_warn(
        f"Order {order_id} hit REQUEUE cap ({requeue_count}/{MAX_REQUEUES}) on "
        f"{event_name} (role {completed_role}) -> escalated to STALLED for human review."
    )
    write_lifecycle_event(
        "ESCALATE",
        f"{order_id} {event_name} requeue cap exceeded "
        f"({requeue_count}/{MAX_REQUEUES}) -> STALLED, role {completed_role} produced "
        f"nothing (Crew {crew_num}, {cause_tag})"
    )
    ring_crew_bell(crew_num, order_id)
    # BUG-MSO-2026-0280: fire auto-queue from every terminal archival path.
    try:
        auto_queue_unblocked_orders(order_id)
    except Exception as _aq_exc:
        print_warn(f"Auto-queue after STALLED archival of {order_id} failed "
                   f"(non-fatal; reconciliation pass will recover): {_aq_exc}")
    return archive_file


def _check_role_deliverable_gate(order_id: str, data: Dict[str, Any], completed_role: str,
                                 source_file: Path, admiralty_dir: Path, crew_num: int) -> bool:
    """Refuse to advance/archive *completed_role*'s completion as a success if
    it left no deliverable (BUG-MSO-2026-0546). Returns True if the order was
    held (caller must stop — NOT advance/archive it); False if a deliverable
    was found (or the check fails open) and the caller should proceed as
    normal.

    For a SEC-family completed_role this fires under the exact existing
    SEC_ARTEFACT_MISSING event name/wording so lifecycle-log consumers and
    docs referencing that vocabulary are unaffected — it is the SAME check as
    _check_sec_gate_at_role_completion(), reached here as the queue-scan-time
    equivalent, not a duplicate policy.
    """
    if role_deliverable_present(order_id, data, completed_role, admiralty_dir):
        return False
    if (completed_role or "").upper() in _SEC_ROLES:
        _hold_missing_deliverable(
            order_id, data, completed_role, source_file, completed_role,
            admiralty_dir, crew_num,
            event_name="SEC_ARTEFACT_MISSING", cause_tag="BUG-0401/0444/0459",
            legacy_field="secArtefactMissing")
    else:
        _hold_missing_deliverable(
            order_id, data, completed_role, source_file, completed_role,
            admiralty_dir, crew_num)
    return True


def _find_stall_origin_role(order_id: str, data: Dict[str, Any],
                            blocked_role: str) -> Optional[str]:
    """BUG-MSO-2026-0546 fault 2: if *blocked_role* stalled only because the
    role immediately BEFORE it in roleSequence left no deliverable, return
    that upstream role's code — the real origin of the stall — so the record
    doesn't lay the blame solely on the innocent downstream role.

    Returns None when blocked_role is first in sequence, the sequence can't
    be resolved, or the upstream role's deliverable IS present (an ordinary
    block unrelated to an empty upstream role).
    """
    meta = data.get("_meta", {})
    order_type = data.get("orderType") or data.get("type", "")
    sequence = (
        data.get("roleSequence") or meta.get("roleSequence")
        or ROLE_SEQUENCES.get(order_type, [])
    )
    if not sequence or blocked_role not in sequence:
        return None
    idx = sequence.index(blocked_role)
    if idx == 0:
        return None
    upstream_role = sequence[idx - 1]
    try:
        if role_deliverable_present(order_id, data, upstream_role, get_artefact_root()):
            return None
    except Exception:
        return None
    return upstream_role


# Directories complete_order() scans to locate an order's live queue file.
# Factored out (BUG-MSO-2026-0459) so the early SEC-artefact gate below can
# find the SAME file using the SAME search order, without duplicating the
# scan inline at every call site.
_ORDER_QUEUE_SUBDIRS = (
    "orders", "explicit", "high-level", "bugs", "defects", "security", "breakdown",
)


def _iter_queue_order_files(admiralty_dir: Optional[Path] = None):
    """Yield every order JSON file living in the LIVE queue directories.

    Same directory set as _find_order_json_file(): queues/{orders,explicit,
    high-level,bugs,defects,security,breakdown} plus queues/requests/*.
    Factored out (BUG-MSO-2026-0499) so both _find_order_json_file() and the
    dependent-promotion scan (promote_ready_dependents) search the exact same
    set of directories — a dependent order that already lives in one of
    these queue dirs at PROPOSED/HELD status must be found by promotion, not
    just by ID lookup.
    """
    admiralty_dir = admiralty_dir or get_artefact_root()
    queues_dir = admiralty_dir / "queues"
    search_dirs = [queues_dir / sub for sub in _ORDER_QUEUE_SUBDIRS]
    requests_dir = queues_dir / "requests"
    if requests_dir.exists():
        for sub in requests_dir.iterdir():
            if sub.is_dir():
                search_dirs.append(sub)
    for search_dir in search_dirs:
        if not search_dir.exists():
            continue
        for json_file in search_dir.glob("*.json"):
            yield json_file


def _find_order_json_file(order_id: str, admiralty_dir: Optional[Path] = None) -> Optional[Path]:
    """Locate the live queue/active JSON file for *order_id*, or None.

    Mirrors the search complete_order() does over queues/{orders,explicit,...}
    plus queues/requests/* and orders/active/ — used by the early SEC-artefact
    gate (BUG-MSO-2026-0459) so it can inspect an order's data BEFORE the
    (expensive) local verify gate + convergence step runs, not just at
    final-role archival.
    """
    admiralty_dir = admiralty_dir or get_artefact_root()
    for json_file in _iter_queue_order_files(admiralty_dir):
        try:
            data = json.loads(json_file.read_text(encoding='utf-8'))
        except Exception:
            continue
        file_order_id = data.get("orderId") or data.get("id") or json_file.stem
        if file_order_id == order_id:
            return json_file
    active_file = admiralty_dir / "orders" / "active" / f"{order_id}.json"
    if active_file.exists():
        return active_file
    return None


def _check_sec_gate_at_role_completion(order_id: str, completed_role: str,
                                       crew_num: int) -> bool:
    """BUG-MSO-2026-0459: fail the SEC role AT ITS OWN COMPLETION when its
    required artefact is missing — instead of letting the crew report
    ``subtype=success``, run the local verify gate, converge/push onto the
    voyage branch, and only discover the gap when the order later reaches its
    FINAL role and complete_order()'s BUG-0401 gate fires (which, for a
    single-role-remaining order, could be two requeues and ~$0.69/41 turns
    later per attempt).

    Reuses the exact same hold/requeue-budget machinery as the BUG-0401/0444
    finalization gate (:func:`_hold_missing_sec_artefact`) so the requeue
    budget (``MAX_REQUEUES``) and STALLED escalation behave identically —
    this is purely a "catch it sooner" optimisation layered in FRONT of that
    gate, not a new policy, and complete_order()'s own gate is left
    unchanged as the backstop for the case where SEC is not the final role
    but a later role also never gets an artefact.

    Returns True if the gate fired (the order was held; the caller must stop
    and NOT proceed to the verify gate / convergence). Fails OPEN (returns
    False) if the order's file can't be located, its role doesn't look like a
    SEC-family role, or its data can't be parsed — complete_order()'s gate
    remains the backstop in those cases.
    """
    if (completed_role or "").upper() not in _SEC_ROLES:
        return False
    admiralty_dir = get_artefact_root()
    json_file = _find_order_json_file(order_id, admiralty_dir)
    if json_file is None:
        return False
    try:
        data = json.loads(json_file.read_text(encoding='utf-8'))
    except Exception:
        return False
    if sec_artefact_present(order_id, data, admiralty_dir):
        return False
    _hold_missing_sec_artefact(
        order_id, data, completed_role, json_file,
        completed_role, admiralty_dir, crew_num)
    return True


def load_role_sequences(workspace_dir: Optional[Path] = None) -> Dict[str, List[str]]:
    """Load roleSequence from all order templates (v8.2).

    With no argument (every pre-existing caller: dispatcher startup,
    ``--validate-sequences``), populates and returns the module-global
    ROLE_SEQUENCES dict resolved from ``get_artefact_root()`` — i.e. the
    process cwd's workspace — exactly as before.

    With an explicit *workspace_dir*, returns a FRESH dict scoped to that
    workspace's own templates and leaves the global ROLE_SEQUENCES
    untouched. BUG-MSO-2026-0515: ROLE_SEQUENCES is a process-global cache
    populated once and never re-scoped, so a long-lived multi-workspace
    caller (the Hub daemon compiling charts for several projects in one
    process) must not read or write it — doing so silently mixes one
    workspace's role sequences into another's chart, or serves a
    FileNotFoundError from ``get_artefact_root()`` when the process cwd has
    no workspace of its own at all.
    """
    templates_dir = (workspace_dir or get_artefact_root()) / "orders" / "templates"
    sequences: Dict[str, List[str]] = {}
    if templates_dir.exists():
        for f in templates_dir.glob("*-template.json"):
            try:
                data = json.loads(f.read_text(encoding='utf-8'))
                meta = data.get("_meta", {})
                order_type = meta.get("orderType", "")
                sequence = meta.get("roleSequence", [])
                if order_type and sequence:
                    sequences[order_type] = sequence
            except Exception:
                pass

    if workspace_dir is None:
        global ROLE_SEQUENCES
        ROLE_SEQUENCES.update(sequences)
        return ROLE_SEQUENCES
    return sequences


def resolve_order_fields(data: Dict[str, Any]) -> tuple:
    """v8.6.1: Resolve targetRole and orderType from order data with backwards-compat fallback.

    Orders may use "targetRole" or "role", and "orderType" or "type".
    This helper normalizes both to avoid role misassignment.

    Returns: (target_role: str, order_type: str)
    """
    order_type = data.get("orderType") or data.get("type", "")
    if order_type == "ORDER":
        order_type = data.get("orderType", "")
    target_role = data.get("targetRole") or data.get("role", "")
    return target_role, order_type


def build_voyage_role_status() -> Dict[str, Dict[str, str]]:
    """Build per-voyage map of role completion status (v8.2).

    Scans complete archive and active queues to determine, for each voyage,
    which roles have COMPLETE, IN_PROGRESS, or PENDING orders.

    Returns: {voyageId: {role: "COMPLETE"|"IN_PROGRESS"|"PENDING"}}
    Best status wins: COMPLETE > IN_PROGRESS > PENDING.
    Also tracks the primary orderType per voyage for sequence lookup.
    """
    # BUG-MSO-2026-0244: CONVERGENCE_FAILED is a started-but-not-complete state. It
    # MUST rank above 0 (the unknown-status default) or update_voyage() would never
    # record the role, making it look "not present" and letting later roles dispatch
    # past it. Rank it like IN_PROGRESS: occupied/blocking, definitely not COMPLETE.
    STATUS_RANK = {"COMPLETE": 3, "IN_PROGRESS": 2, "CONVERGENCE_FAILED": 2, "PENDING": 1}
    voyage_roles: Dict[str, Dict[str, str]] = {}  # {voyageId: {role: status}}
    voyage_types: Dict[str, str] = {}  # {voyageId: primary orderType}

    def update_voyage(voyage_id: str, role: str, status: str, order_type: str):
        if not voyage_id or not role:
            return
        if voyage_id not in voyage_roles:
            voyage_roles[voyage_id] = {}
        current = voyage_roles[voyage_id].get(role, "")
        if STATUS_RANK.get(status, 0) > STATUS_RANK.get(current, 0):
            voyage_roles[voyage_id][role] = status
        # Track primary order type (template-defined types take precedence)
        if order_type in ROLE_SEQUENCES:
            voyage_types[voyage_id] = order_type

    mso_dir = get_artefact_root()

    # Scan completed orders archive
    complete_dir = mso_dir / "orders" / "complete"
    if complete_dir.exists():
        for f in complete_dir.glob("*.json"):
            try:
                data = json.loads(f.read_text(encoding='utf-8'))
                vid = data.get("voyageId", "")
                role, otype = resolve_order_fields(data)
                status = data.get("status", "COMPLETE")
                update_voyage(vid, role, status, otype)
            except Exception:
                pass

    # Scan all active queue directories
    queues_dir = get_queues_dir()
    queue_dirs = ["explicit", "security", "bugs", "orders", "defects",
                  "breakdown", "high-level"]
    for qname in queue_dirs:
        qpath = queues_dir / qname
        if not qpath.exists():
            continue
        for f in qpath.glob("*.json"):
            try:
                data = json.loads(f.read_text(encoding='utf-8'))
                vid = data.get("voyageId", "")
                role, otype = resolve_order_fields(data)
                status = data.get("status", "PENDING")
                update_voyage(vid, role, status, otype)
            except Exception:
                pass

    # Scan requests subdirectories
    requests_dir = queues_dir / "requests"
    if requests_dir.exists():
        for subdir in requests_dir.iterdir():
            if not subdir.is_dir():
                continue
            for f in subdir.glob("*.json"):
                try:
                    data = json.loads(f.read_text(encoding='utf-8'))
                    vid = data.get("voyageId", "")
                    role, otype = resolve_order_fields(data)
                    status = data.get("status", "PENDING")
                    update_voyage(vid, role, status, otype)
                except Exception:
                    pass

    # Scan orders/active/ directory (orders tracked but may not be in queues yet)
    active_dir = mso_dir / "orders" / "active"
    if active_dir.exists():
        for f in active_dir.glob("*.json"):
            try:
                data = json.loads(f.read_text(encoding='utf-8'))
                vid = data.get("voyageId", "")
                role, otype = resolve_order_fields(data)
                status = data.get("status", "PENDING")
                update_voyage(vid, role, status, otype)
            except Exception:
                pass

    # Attach primary type to each voyage's role map (under special key)
    for vid, ptype in voyage_types.items():
        if vid in voyage_roles:
            voyage_roles[vid]["__primaryType__"] = ptype

    return voyage_roles


def check_role_sequence_gate(order_data: Dict[str, Any],
                             voyage_roles: Dict[str, str]) -> tuple:
    """Check if prior roles in the sequence have completed for this voyage (v8.3.1).

    Returns (passed: bool, missing_roles: List[str])

    Pass-through cases (always pass):
    - No voyageId on the order
    - No roleSequence found for this order type
    - Single-role sequence (INV, DOC)
    - targetRole is the FIRST role in the sequence

    v8.3.1: Only enforce gate on roles that have orders in the voyage.
    If a prior role has no orders at all (not in voyage_roles), it is
    treated as not applicable and skipped. This prevents voyages without
    SCR/LKT orders from blocking COX dispatch.
    """
    # v8.6.1: Use resolve helper for backwards-compat
    target_role, resolved_type = resolve_order_fields(order_data)
    if not target_role:
        return True, []

    # Determine the role sequence to enforce
    # First try the order's own _meta, then fall back to template via orderType,
    # then fall back to the voyage's primary type
    sequence = None
    meta = order_data.get("_meta", {})
    if meta.get("roleSequence"):
        sequence = meta["roleSequence"]
    else:
        order_type = resolved_type
        if order_type in ROLE_SEQUENCES:
            sequence = ROLE_SEQUENCES[order_type]
        else:
            # Look up from voyage's primary type
            primary_type = voyage_roles.get("__primaryType__", "")
            if primary_type in ROLE_SEQUENCES:
                sequence = ROLE_SEQUENCES[primary_type]

    if not sequence or len(sequence) <= 1:
        return True, []  # Single-role or unknown — pass through

    # Find target role position in sequence
    if target_role not in sequence:
        return True, []  # Role not in known sequence — pass through

    role_index = sequence.index(target_role)
    if role_index == 0:
        return True, []  # First role in sequence — no prior roles to check

    # v8.9: If this order has already been advanced past the first role,
    # prior roles have already completed FOR THIS ORDER — pass through.
    # Checking voyage-wide role status would incorrectly block orders that
    # are mid-sequence when other orders in the same voyage are still at
    # earlier roles (e.g., FTR-0139 at SHP blocking BUG-0141 at BOS).
    first_role = sequence[0]
    if target_role != first_role:
        return True, []  # Already advanced — prior roles implicitly complete

    # Check PRIOR roles in the sequence that have orders in this voyage
    # v8.3.1: Roles with no orders (not in voyage_roles) are skipped —
    # only block on roles that exist but aren't COMPLETE yet
    missing = []
    for i in range(role_index):
        prior_role = sequence[i]
        prior_status = voyage_roles.get(prior_role, "")
        if not prior_status:
            continue  # No orders for this role in voyage — not applicable
        if prior_status != "COMPLETE":
            missing.append(f"{prior_role} ({prior_status})")

    return len(missing) == 0, missing


# =============================================================================
# v7.0: Dependency-Aware Dispatch
# =============================================================================

def check_dependencies_satisfied(order_data: Dict[str, Any]) -> tuple:
    """Check if all dependencies for an order are satisfied (v7.0, v8.7, BUG-0251).

    Returns (satisfied: bool, waiting_on: List[str])
    An order is dispatchable only when ALL dependencies are archived.

    v8.7: Accept COMPLETE or STALLED as satisfying a dependency.
    STALLED means the crew hit MAX_ITERATIONS but produced partial work.
    The QM wired the dependency chain deliberately, so downstream orders
    should proceed — they can build on or remediate the partial output.

    BUG-MSO-2026-0251: Do NOT treat ERROR-escalated STALLED as satisfying.
    An ERROR-escalation STALLED produced zero work (REQUEUE cap hit on cli_error
    or similar zero-turn failure). stalledCause="ERROR" marks this path.
    Only stalledCause="MAX_ITERATIONS" (or absent, for legacy records) satisfies.

    BUG-MSO-2026-0443: STALLED satisfaction is decided by stalledCause, not by
    the order's top-level `status` (which archive_stalled_order always writes
    as the literal string "STALLED" — it never sets `status` to "MAX_ITERATIONS"
    in any current archival path). See STALLED_SATISFYING_CAUSES for which
    causes count as "partial work exists" vs. "nothing to build on yet".
    """
    depends_on = order_data.get("dependsOn", [])
    if not depends_on:
        return True, []

    # HARD_SATISFYING checks the order's `status` field. "COMPLETE" is the real
    # terminal status for finished work. "MAX_ITERATIONS" is kept here only for
    # defensive/legacy compatibility with any record that might carry that
    # literal `status` value directly (no current code path writes it — the
    # STALLED archive path always sets status="STALLED" and distinguishes via
    # stalledCause instead, handled in the STALLED branch below). The new
    # BLOCKED_BY_ROLE / CIRCUIT_BREAKER causes are stalledCause values, not
    # `status` values, so they belong in STALLED_SATISFYING_CAUSES, not here.
    HARD_SATISFYING = {"COMPLETE", "MAX_ITERATIONS"}

    archive_dir = get_artefact_root() / "orders" / "complete"
    waiting_on = []

    for dep_id in depends_on:
        satisfied = False
        # Check in completed orders archive
        dep_file = archive_dir / f"{dep_id}.json"
        if dep_file.exists():
            try:
                dep_data = json.loads(dep_file.read_text(encoding='utf-8'))
                dep_status = dep_data.get("status")
                if dep_status in HARD_SATISFYING:
                    satisfied = True
                elif dep_status == "STALLED":
                    # BUG-0251: only satisfy when the STALLED was caused by
                    # iteration exhaustion (partial work exists), not ERROR escalation.
                    # Legacy records without stalledCause default to MAX_ITERATIONS
                    # (pre-fix behaviour: STALLED always satisfied).
                    # BUG-MSO-2026-0443: explicit allow-list, not "!= ERROR" — a
                    # BLOCKED_BY_ROLE STALLED (role deliberately declined to act,
                    # often awaiting an operator decision) is just as work-empty
                    # as an ERROR escalation and must NOT satisfy either.
                    stalled_cause = dep_data.get("stalledCause", "MAX_ITERATIONS")
                    satisfied = stalled_cause in STALLED_SATISFYING_CAUSES
            except Exception:
                pass
        if not satisfied:
            waiting_on.append(dep_id)

    return len(waiting_on) == 0, waiting_on


def detect_circular_dependencies(items: List[Dict[str, Any]]) -> List[List[str]]:
    """Detect circular dependency chains among pending items (v7.0).

    Uses iterative DFS. Returns list of cycles found.
    """
    # Build adjacency map
    dep_graph = {}
    for item in items:
        item_id = item.get("id", "")
        deps = item.get("data", {}).get("dependsOn", [])
        if deps:
            dep_graph[item_id] = deps

    if not dep_graph:
        return []

    cycles = []
    visited = set()
    rec_stack = set()

    for start_node in list(dep_graph.keys()):
        if start_node in visited:
            continue

        stack = [(start_node, iter(dep_graph.get(start_node, [])))]
        path = [start_node]
        rec_stack.add(start_node)

        while stack:
            node, neighbors = stack[-1]
            try:
                neighbor = next(neighbors)
                if neighbor in rec_stack:
                    # Found cycle
                    if neighbor in path:
                        cycle_start = path.index(neighbor)
                        cycles.append(path[cycle_start:] + [neighbor])
                elif neighbor not in visited and neighbor in dep_graph:
                    rec_stack.add(neighbor)
                    path.append(neighbor)
                    stack.append((neighbor, iter(dep_graph.get(neighbor, []))))
            except StopIteration:
                rec_stack.discard(node)
                if path:
                    path.pop()
                stack.pop()
                visited.add(node)

    return cycles


# v7.0: Track items waiting on dependencies (for display, not dispatched)
WAITING_ON_DEPS: Dict[str, List[str]] = {}

# BUG-MSO-2026-0274: remember the last waiting-on set we emitted a DEP_HELD event
# for, per item, so scan_all_queues (which runs every ~10s) logs DEP_HELD only on
# first hold or when the dependency set changes — not on every tick (log-flood).
# Persists across scans (NOT reset with WAITING_ON_DEPS).
_DEP_HELD_LOGGED: Dict[str, List[str]] = {}

# BUG-MSO-2026-0247: tracks order files that could not be read/parsed during a scan
_QUEUE_READ_ERRORS: List[str] = []


def _read_order_file_tolerant(json_file: "Path") -> dict:
    """Read an order JSON file with encoding tolerance (BUG-MSO-2026-0247).

    Tries UTF-8 first. On UnicodeDecodeError falls back to cp1252 — a single-byte
    codec that decodes ANY byte sequence, so a stray Windows-locale byte (e.g. an
    0x97 em-dash) can't hide an order from dispatch. When the cp1252 fallback
    succeeds the file is rewritten as UTF-8 in place so the mismatch doesn't recur.
    Raises json.JSONDecodeError on genuine JSON corruption (caller must handle);
    OSError if the file cannot be read at all.
    """
    raw: bytes = json_file.read_bytes()
    # cp1252 covers all 256 single-byte values, so it never raises UnicodeDecodeError
    # — it's the terminal fallback (no latin-1 needed; it would be unreachable).
    for enc in ("utf-8", "cp1252"):
        try:
            text = raw.decode(enc)
        except UnicodeDecodeError:
            continue
        data = json.loads(text)  # JSONDecodeError on genuine corruption propagates to caller
        if enc != "utf-8":
            # Normalise to UTF-8 so the mismatch doesn't recur
            json_file.write_bytes(text.encode("utf-8"))
            write_lifecycle_event(
                "WARN",
                f"Order file re-encoded {enc}→utf-8: {json_file.name}"
            )
        return data
    # Defensive only: cp1252 decodes any byte, so this is effectively unreachable.
    raise ValueError(f"Could not decode {json_file} with any known encoding")


def _terminal_order_ids() -> set:
    """Order IDs already archived as terminal (orders/complete/ or orders/failed/).

    BUG-MSO-2026-0263: a completed order is archived by moving its file
    queues/orders/X.json -> orders/complete/X.json in the working tree, and that move
    is not committed immediately (LEAD sweeps completions to main). If the working tree
    is reset to HEAD by concurrent git activity, the stale queue copy resurfaces and the
    dispatcher would re-dispatch an already-COMPLETE order (re-converging merged work).
    scan_all_queues() consults this set to veto re-selection regardless of a stale copy.
    """
    ids = set()
    ws = get_artefact_root()
    for sub in ("orders/complete", "orders/failed"):
        d = ws / sub
        if d.exists():
            for f in d.glob("*.json"):
                ids.add(f.stem)
    return ids


def _order_is_complete(order_id: str, completed_ids: set,
                       ledger_view=None) -> bool:
    """True only when *order_id* has a genuine COMPLETE terminal verdict.

    BUG-MSO-2026-0303: completion is judged from the ledger (git-immune) and
    the archive STATUS — never mere presence. A STALLED/FAILED archive, a
    CONVERGENCE_FAILED queue file, or a ledger TERMINAL of STALLED/FAILED does
    NOT count as complete (reuses the BUG-0296 status==COMPLETE rule).
    """
    if ledger_view is not None and ledger_view.is_terminal(order_id):
        return ledger_view.terminal.get(order_id, "").upper() in ("COMPLETE", "COMPLETED")
    if order_id in completed_ids:
        archive = get_artefact_root() / "orders" / "complete" / f"{order_id}.json"
        try:
            data = json.loads(archive.read_text(encoding="utf-8"))
            return (data.get("status") or "COMPLETE").upper() in ("COMPLETE", "COMPLETED")
        except (OSError, json.JSONDecodeError):
            return False
    return False


def voyages_outstanding_work() -> list:
    """BUG-MSO-2026-0303: active voyages with a manifest order not yet COMPLETE.

    Completion detection ("Eight Bells") used to gate only on scan_all_queues
    returning nothing — but that is PENDING-only, so an order parked in
    CONVERGENCE_FAILED / AUTO_SERIALIZE-limbo / STALLED-with-salvage was
    invisible and the dispatcher false-finished the voyage (PSG v4.7.2
    retest). This reconciles each active voyage's manifest against the ledger
    + archive status and returns ``[(voyage_id, [unfinished_order_id, ...]),
    ...]`` for every voyage that still has real work. Any non-empty result
    must block the bell, the sweep, PR promotion, and idle-reap.
    """
    ws = get_artefact_root()
    voyages_dir = ws / "voyages" / "active"
    if not voyages_dir.exists():
        return []

    completed_ids = _terminal_order_ids()
    try:
        ledger_view = order_ledger.load_view(ws)
    except Exception:
        ledger_view = None
    skipped = load_skipped_order_ids()

    outstanding = []
    for vf in voyages_dir.glob("*.json"):
        try:
            voyage = json.loads(vf.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if (voyage.get("status") or "ACTIVE").upper() not in ("ACTIVE", "IN_PROGRESS"):
            continue
        unfinished = []
        for entry in voyage.get("orders", []):
            oid = entry if isinstance(entry, str) else (
                entry.get("orderId") or entry.get("id") or "")
            if not oid or oid in skipped:
                continue
            if not _order_is_complete(oid, completed_ids, ledger_view):
                unfinished.append(oid)
        if unfinished:
            outstanding.append((voyage.get("id", vf.stem), unfinished))

    # BUG-MSO-2026-0307 (PSG v4.7.3): belt-and-braces — a queue order parked in a
    # non-terminal-non-PENDING limbo (CONVERGENCE_FAILED / BLOCKED / AUTO_SERIALIZE)
    # is real unfinished work even if it is NOT in any active voyage manifest as
    # read (manifest-vs-queue gap). Surface it directly from the queue files so it
    # blocks Eight Bells regardless of manifest membership. Dedup against orders
    # the manifest scan already reported, so an order isn't counted twice.
    already = {oid for _, oids in outstanding for oid in oids}
    stranded = _queue_stranded_order_ids(skipped) - already
    if stranded:
        outstanding.append(("(queue)", sorted(stranded)))
    return outstanding


# Queue statuses that are NOT dispatchable (so scan_all_queues skips them) yet
# also NOT terminal — they represent unfinished work needing recovery, and must
# block completion detection (BUG-MSO-2026-0307).
_STRANDED_QUEUE_STATUSES = {"CONVERGENCE_FAILED", "BLOCKED", "AUTO_SERIALIZE", "ESCALATED"}


def _queue_stranded_order_ids(skipped: Optional[set] = None) -> set:
    """Order IDs sitting in any queue with a stranded (non-terminal-non-PENDING)
    status — they block completion detection (BUG-MSO-2026-0307)."""
    if skipped is None:
        skipped = load_skipped_order_ids()
    ids = set()
    queues_dir = get_queues_dir()
    if not queues_dir.exists():
        return ids
    for json_file in list(queues_dir.glob("*/*.json")) + list(queues_dir.glob("*/*/*.json")):
        try:
            data = json.loads(json_file.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        status = (data.get("status") or "").upper()
        if status in _STRANDED_QUEUE_STATUSES:
            oid = data.get("orderId") or data.get("id") or json_file.stem
            if oid and oid not in skipped:
                ids.add(oid)
    return ids


def _live_crew_order_ids() -> set:
    """Order IDs currently owned by a crew whose process is alive.

    BUG-MSO-2026-0294 belt-and-braces alongside the ledger: the crew state
    files are gitignored runtime state, so they survive the git rewinds that
    erase the queue-file claim. Crews with dead pids are excluded — the
    crash-recovery path owns those.
    """
    ids = set()
    crews_dir = get_artefact_root() / "crews"
    if not crews_dir.exists():
        return ids
    for state_file in crews_dir.glob("crew*/state.json"):
        try:
            state = json.loads(state_file.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if state.get("status") not in ("RUNNING", "ACTIVE"):
            continue
        pid = state.get("pid")
        oid = state.get("orderId")
        if oid and pid and is_process_alive(pid):
            ids.add(oid)
    return ids


def _self_heal_stale_queue_file(json_file: Path, data: dict, order_id: str,
                                terminal_status: str) -> None:
    """BUG-MSO-2026-0295: re-archive a queue file the ledger knows is terminal.

    A git rewind (or a stale snapshot round-tripping through a voyage PR) can
    resurrect a completed order's queue file. Instead of WARNing about it
    forever, converge the tree back to truth: restore/refresh the archive copy
    and remove the queue copy, committing the move when lifecycle commits are
    enabled. Fail-open — on any error the file simply stays vetoed by the
    ledger.
    """
    try:
        archive_dir = get_artefact_root() / "orders" / "complete"
        archive_dir.mkdir(parents=True, exist_ok=True)
        archive_file = archive_dir / json_file.name
        if not archive_file.exists():
            data = dict(data)
            data["status"] = terminal_status
            data["rearchivedAt"] = datetime.now().isoformat()
            data["rearchivedBy"] = "BUG-0294 ledger self-heal"
            archive_file.write_text(json.dumps(data, indent=2), encoding="utf-8")
        json_file.unlink(missing_ok=True)
        _commit_lifecycle_transition(
            [archive_file, json_file],
            f"lifecycle: re-archive {order_id} ({terminal_status}) — ledger self-heal",
        )
    except Exception:
        pass


def _skipped_orders_path() -> Path:
    """Path to the persisted operator skip list (.mso/config/skipped-orders.json)."""
    return get_artefact_root() / "config" / "skipped-orders.json"


# BUG-MSO-2026-0451: schema normalisation lives in maestro.core.skip_list —
# a small, path-parameterised module shared with fleet_monitor (mso status)
# and the Hub aggregator, so every reader of the skip list applies the SAME
# rule instead of re-deriving it (two implementations of "is this
# dispatchable" drift). Kept as module-level aliases here so existing
# call sites (and tests reaching in via `fr._normalise_skipped_orders`) are
# unaffected.
_normalise_skip_entry = skip_list.normalise_skip_entry
_normalise_skipped_orders = skip_list.normalise_skipped_orders
_has_skip_content = skip_list.has_skip_content


def load_skipped_orders() -> Dict[str, Dict[str, Any]]:
    """Load the skip list as a dict keyed by order ID.

    Returns the CANONICAL flat map regardless of which on-disk schema the
    workspace carries (see :func:`_normalise_skipped_orders`).  Returns {} on
    any error (missing file, parse failure) — same tolerant pattern as
    load_completion_config() — warning on a file that exists but cannot be
    read or understood so the operator knows their skip list is being ignored.
    """
    path = _skipped_orders_path()
    try:
        raw = path.read_text(encoding="utf-8")
    except FileNotFoundError:
        return {}
    except Exception as exc:  # unreadable — permissions, encoding, …
        print_warn(f"Skip list at {path} could not be read ({exc}) — treating as empty.")
        return {}

    try:
        doc = json.loads(raw)
    except Exception as exc:
        print_warn(f"Skip list at {path} is not valid JSON ({exc}) — treating as empty.")
        return {}

    normalised = _normalise_skipped_orders(doc)
    if not normalised and _has_skip_content(doc):
        print_warn(f"Skip list at {path} has an unrecognised shape — treating as empty.")
    return normalised


def load_skipped_order_ids() -> set:
    """Return the set of order IDs in the skip list."""
    return set(load_skipped_orders().keys())


def add_skipped_order(
    order_id: str,
    *,
    reason: str = "",
    voyage_id: str = "",
    skipped_by: str = "cli",
) -> None:
    """Upsert an order into the skip list (BUG-MSO-2026-0288).

    Preserves the existing ``skippedAt`` timestamp if the entry already exists
    (idempotent re-skip).  Creates ``config/`` if needed.

    BUG-MSO-2026-0433: the load is normalised, so a workspace carrying the
    wrapped ``{"skipped": [...]}`` schema is migrated to the canonical flat map
    on the first write — existing entries are preserved, not dropped.  Reads
    keep tolerating both shapes forever, so migration is never required.
    """
    path = _skipped_orders_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    data = load_skipped_orders()
    existing = data.get(order_id, {})
    data[order_id] = {
        "skippedAt": existing.get("skippedAt", datetime.now(timezone.utc).isoformat()),
        "skippedBy": skipped_by,
        "reason": reason,
        "voyageId": voyage_id,
    }
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")


def remove_skipped_order(order_id: str) -> bool:
    """Remove an order from the skip list.

    Returns True if it was present (useful for ``mso order unskip`` reporting).
    """
    data = load_skipped_orders()
    if order_id not in data:
        return False
    del data[order_id]
    path = _skipped_orders_path()
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return True


def scan_all_queues() -> List[Dict[str, Any]]:
    """Scan ALL queue directories with tiered priority (v7.0).

    Priority tiers (lower = higher priority):
    T0: explicit/     (0)   - Captain's direct orders
    T1: security/     (100) - Security issues (LKT-generated)
    T2: bugs/         (200) - Bug reports (any crew)
    T3: requests/     (300) - Service requests
    T4: orders/       (400) - Standard orders
    T5: defects/      (500) - QA findings (BOS-generated)
    T6: breakdown/    (600) - Sub-orders from breakdown
    T7: high-level/   (700) - Needs NAV breakdown first
    """
    global WAITING_ON_DEPS, _QUEUE_READ_ERRORS
    WAITING_ON_DEPS = {}
    _QUEUE_READ_ERRORS = []
    all_items = []
    queues_dir = get_queues_dir()
    # BUG-MSO-2026-0263: orders already archived terminal must never be re-dispatched,
    # even if a stale PENDING copy resurfaced in a queue tier.
    terminal_ids = _terminal_order_ids()
    # BUG-MSO-2026-0294: the runtime ledger is the GIT-IMMUNE gate. The archive
    # dirs above are working-tree state a `git reset --hard` can rewind together
    # with the resurrected queue copy (how BUG-0263's guard was defeated at PSG);
    # the gitignored ledger survives any git operation.
    ledger_view = order_ledger.load_view(get_artefact_root())
    # BUG-MSO-2026-0294: ids owned by LIVE crews right now (belt-and-braces for
    # claims the ledger missed — e.g. written by an older engine version).
    inflight_ids = _live_crew_order_ids()
    # BUG-MSO-2026-0288: operator-skipped orders are silently dropped (no dispatch, no WARN).
    skipped_ids = load_skipped_order_ids()

    # Priority sub-sort within tier
    priority_sub = {"CRITICAL": 0, "HIGH": 10, "MEDIUM": 20, "NORMAL": 20, "LOW": 30}

    # Order type to default role mapping
    order_roles = {
        "FIX": "SHP", "BUG": "SHP", "TEST": "SHP", "SEC": "LKT",
        "FTR": "NAV", "RFT": "SHP", "DOC": "SCR", "INV": "LKT"
    }

    # Tier definitions: (queue_name, tier_offset, item_type, default_role_override)
    tier_configs = [
        ("explicit",   0,   "EXPLICIT",   None),
        ("security",   100, "SECURITY",   "SHP"),
        ("bugs",       200, "BUG",        "SHP"),
        ("orders",     400, "ORDER",      None),
        ("defects",    500, "DEFECT",     "SHP"),
        ("breakdown",  600, "BREAKDOWN",  None),
        ("high-level", 700, "HIGH-LEVEL", "NAV"),
    ]

    for queue_name, tier_offset, item_type, default_role in tier_configs:
        queue_path = queues_dir / queue_name
        if not queue_path.exists():
            continue
        for json_file in queue_path.glob("*.json"):
            try:
                data = _read_order_file_tolerant(json_file)
                # v2.0.3: Normalize defect fields to standard order fields
                status = data.get("status", "PENDING")
                if queue_name == "defects":
                    # Defects use OPEN/CLOSED; treat OPEN as dispatchable
                    if status not in ("OPEN", "PENDING"):
                        continue
                    # Map defect-specific fields to standard order fields
                    if "defectId" in data and "orderId" not in data:
                        data["orderId"] = data["defectId"]
                    if "affectedRepo" in data and "targetRepo" not in data:
                        data["targetRepo"] = data["affectedRepo"]
                    if "affectedBranch" in data and "voyageBranch" not in data:
                        data["voyageBranch"] = data["affectedBranch"]
                    if "severity" in data and "priority" not in data:
                        data["priority"] = data["severity"]
                else:
                    if status != "PENDING":
                        continue

                priority_str = data.get("priority", "MEDIUM")
                sub_pri = priority_sub.get(priority_str, 20)
                # v8.6.1: Use resolve helper for backwards-compat
                resolved_role, resolved_type = resolve_order_fields(data)
                order_type = resolved_type or "FIX"

                # default_role is a fallback, not an override — order's own targetRole/role wins
                target_role = resolved_role or default_role or order_roles.get(order_type, "SHP")

                # v8.6: Resolve ID from orderId or id or filename stem
                item_id = data.get("orderId") or data.get("id") or json_file.stem
                # BUG-MSO-2026-0288: operator explicitly skipped — silent drop, no WARN.
                if item_id in skipped_ids:
                    continue
                # FTR-MSO-2026-0359: inside a network-retry backoff window —
                # skip this tick; the order becomes eligible when it passes.
                if _network_backoff_active(data):
                    continue
                # BUG-MSO-2026-0263: veto re-dispatch of an order already archived terminal
                # (resurfaced stale queue copy). Never re-run / re-converge completed work.
                # Emit the WARN at most once per dispatcher process (BUG-MSO-2026-0288).
                if item_id in terminal_ids:
                    if item_id not in _BUG0263_WARNED:
                        write_lifecycle_event(
                            "WARN",
                            f"{item_id} in queues/{queue_name} but already archived in "
                            f"orders/complete|failed — skipping re-dispatch (BUG-0263 dedup)"
                        )
                        _BUG0263_WARNED.add(item_id)
                    # BUG-MSO-2026-0295: converge the tree back to truth instead
                    # of WARNing about the stale copy forever.
                    _self_heal_stale_queue_file(json_file, data, item_id, "COMPLETE")
                    continue
                # BUG-MSO-2026-0294: ledger says TERMINAL — veto regardless of what
                # the (possibly git-resurrected) queue file claims, and self-heal
                # the tree by re-archiving the stale copy (BUG-MSO-2026-0295).
                if ledger_view.is_terminal(item_id):
                    if item_id not in _BUG0263_WARNED:
                        write_lifecycle_event(
                            "WARN",
                            f"{item_id} in queues/{queue_name} but ledger records it "
                            f"{ledger_view.terminal.get(item_id, 'TERMINAL')} — skipping "
                            f"re-dispatch and re-archiving stale queue copy (BUG-0294 ledger)"
                        )
                        _BUG0263_WARNED.add(item_id)
                    _self_heal_stale_queue_file(
                        json_file, data, item_id,
                        ledger_view.terminal.get(item_id, "COMPLETE"))
                    continue
                # BUG-MSO-2026-0294: a LIVE crew already owns this order (ledger claim
                # with live pid, or the crew's own state.json says so) — never hand it
                # to a second crew. Silent skip: this is normal in-flight state.
                if item_id in inflight_ids:
                    continue
                _claim = ledger_view.live_claim(item_id)
                if _claim:
                    if _claim.get("pid") != os.getpid():
                        # Claim backed by some OTHER live process (e.g. written by an
                        # older engine version with a real crew pid) — honour it.
                        continue
                    # BUG-MSO-2026-0350 (issue #203): the claim's pid is THIS
                    # dispatcher itself (record_claimed's default), and no live crew
                    # actually holds the order — a requeue path set the file PENDING
                    # without record_released (AUTO_SERIALIZE was the 4th such path;
                    # BUG-0344 fixed three others). A self-claim proves nothing about
                    # a crew, so instead of skipping silently for the rest of this
                    # process's life (pending=0 heartbeats + false Eight Bells),
                    # self-heal: release the stale claim, refresh the bell grace
                    # clock, and let the next tick dispatch the order.
                    if item_id not in _BUG0263_WARNED:
                        write_lifecycle_event(
                            "WARN",
                            f"{item_id} PENDING in queues/{queue_name} but held by a stale "
                            f"dispatcher-pid ledger claim with no live crew — releasing "
                            f"claim for re-dispatch (BUG-0350 self-heal)"
                        )
                        _BUG0263_WARNED.add(item_id)
                    order_ledger.record_released(
                        item_id, "stale dispatcher-pid self-claim with no live crew (BUG-0350)",
                        workspace_dir=get_artefact_root())
                    _mark_order_terminal_now()
                    continue
                # BUG-0248 / PSG bug 3 (advance-loss loop): if a rewind reverted the
                # file's targetRole behind the ledger's durable role progression,
                # trust the LEDGER — dispatch at the real role and heal the file so
                # the order never loops back to an already-completed role.
                _ledger_role = ledger_view.current_role(item_id)
                if _ledger_role and _ledger_role != target_role:
                    if item_id not in _BUG0263_WARNED:
                        write_lifecycle_event(
                            "WARN",
                            f"{item_id} file targetRole={target_role} but ledger records "
                            f"progression to {_ledger_role} — dispatching at ledger role and "
                            f"healing file (BUG-0248 advance-loss)"
                        )
                        _BUG0263_WARNED.add(item_id)
                    target_role = _ledger_role
                    try:
                        data["targetRole"] = _ledger_role
                        json_file.write_text(json.dumps(data, indent=2), encoding="utf-8")
                    except OSError:
                        pass
                # v8.6: Derive title from data or order ID
                item_title = data.get("title") or data.get("description", "")
                if not item_title:
                    # Derive readable title from order ID (e.g. SHP-LOCK-091A → LOCK-091A)
                    parts = item_id.split("-", 1)
                    item_title = parts[1] if len(parts) > 1 else item_id

                all_items.append({
                    "type": item_type,
                    "subtype": order_type,
                    "id": item_id,
                    "title": item_title,
                    "priority": tier_offset + sub_pri,
                    "role": target_role,
                    "path": str(json_file),
                    "data": data,
                    "queue": queue_name,
                })
            except Exception as e:
                msg = f"Unreadable order file skipped: {json_file.name} — {e}"
                print_warn(msg)
                write_lifecycle_event("ERROR", msg)
                _QUEUE_READ_ERRORS.append(str(json_file))

    # Scan requests subdirectories (tier 300)
    requests_dir = queues_dir / "requests"
    request_roles = {
        "planning": "NAV", "investigation": "LKT", "qa": "BOS",
        "security-scan": "LKT", "documentation": "SCR"
    }
    if requests_dir.exists():
        for subdir_name, role in request_roles.items():
            subdir = requests_dir / subdir_name
            if not subdir.exists():
                continue
            for json_file in subdir.glob("*.json"):
                try:
                    data = _read_order_file_tolerant(json_file)
                    if data.get("status", "PENDING") != "PENDING":
                        continue
                    priority_str = data.get("priority", "MEDIUM")
                    sub_pri = priority_sub.get(priority_str, 20)
                    # v8.6: Resolve ID and title consistently
                    req_id = data.get("orderId") or data.get("id") or json_file.stem
                    # BUG-MSO-2026-0288: operator explicitly skipped — silent drop, no WARN.
                    if req_id in skipped_ids:
                        continue
                    # FTR-MSO-2026-0359: network-retry backoff window — skip this tick.
                    if _network_backoff_active(data):
                        continue
                    # BUG-MSO-2026-0263: veto re-dispatch of an already-archived order.
                    # Emit the WARN at most once per dispatcher process (BUG-MSO-2026-0288).
                    if req_id in terminal_ids:
                        if req_id not in _BUG0263_WARNED:
                            write_lifecycle_event(
                                "WARN",
                                f"{req_id} in queues/requests/{subdir_name} but already archived "
                                f"in orders/complete|failed — skipping re-dispatch (BUG-0263 dedup)"
                            )
                            _BUG0263_WARNED.add(req_id)
                        continue
                    req_title = data.get("title") or data.get("description", "")
                    if not req_title:
                        parts = req_id.split("-", 1)
                        req_title = parts[1] if len(parts) > 1 else req_id

                    resolved_role, _ = resolve_order_fields(data)
                    all_items.append({
                        "type": "REQUEST",
                        "subtype": subdir_name.upper(),
                        "id": req_id,
                        "title": req_title,
                        "priority": 300 + sub_pri,
                        "role": resolved_role or role,
                        "path": str(json_file),
                        "data": data,
                        "queue": f"requests/{subdir_name}",
                    })
                except Exception as e:
                    msg = f"Unreadable request file skipped: {json_file.name} — {e}"
                    print_warn(msg)
                    write_lifecycle_event("ERROR", msg)
                    _QUEUE_READ_ERRORS.append(str(json_file))

    # Check for circular dependencies
    cycles = detect_circular_dependencies(all_items)
    circular_ids = set()
    for cycle in cycles:
        cycle_str = " -> ".join(cycle)
        print_error(f"CIRCULAR DEPENDENCY: {cycle_str}")
        write_lifecycle_event("ERROR", f"Circular dependency: {cycle_str}")
        circular_ids.update(cycle[:-1])  # Exclude the repeated last element

    # Filter: dependency check + escalation blocking + role sequence gates
    _, blocking_voyages = scan_escalations()

    # v8.2: Build voyage role status for gate enforcement
    voyage_role_status = build_voyage_role_status() if ROLE_SEQUENCES else {}

    dispatchable = []
    for item in all_items:
        item_id = item["id"]

        # Skip circular dependency items
        if item_id in circular_ids:
            continue

        # Skip items blocked by escalation
        voyage_id = item["data"].get("voyageId", "")
        if voyage_id and voyage_id in blocking_voyages:
            WAITING_ON_DEPS[item_id] = [f"ESCALATION (voyage {voyage_id} blocked)"]
            continue

        # Check dependencies
        satisfied, waiting_on = check_dependencies_satisfied(item["data"])
        if not satisfied:
            # BUG-MSO-2026-0274: emit a DEP_HELD lifecycle event for EVERY
            # unmet-dependency hold (PENDING / IN_PROGRESS / NAV_REVIEW_PENDING /
            # absent dep), so a held candidate is observable — not only the
            # BUG-0251 STALLED(cause=ERROR) special case. Annotate each dep with
            # the reason it isn't satisfying where it's readable.
            archive_dir = get_artefact_root() / "orders" / "complete"
            dep_notes = []
            for dep_id in waiting_on:
                note = dep_id
                dep_file = archive_dir / f"{dep_id}.json"
                if dep_file.exists():
                    try:
                        dep_data = json.loads(dep_file.read_text(encoding='utf-8'))
                        _dep_cause = dep_data.get("stalledCause")
                        # BUG-MSO-2026-0251: a zero-progress ERROR escalation never
                        # satisfies a dependency — call it out explicitly. Exact
                        # wording preserved for existing callers/tests.
                        if dep_data.get("status") == "STALLED" and _dep_cause == "ERROR":
                            note = f"{dep_id}(STALLED,cause=ERROR — zero-progress; human review required)"
                        # BUG-MSO-2026-0443: a first-iteration BLOCKED is likewise
                        # non-satisfying (the role declined to act, often awaiting
                        # an operator decision) — surface its own cause too instead
                        # of falling through to a bare "(archived STALLED)" note.
                        elif dep_data.get("status") == "STALLED" and _dep_cause and _dep_cause not in STALLED_SATISFYING_CAUSES:
                            note = f"{dep_id}(STALLED,cause={_dep_cause} — human review required)"
                        else:
                            note = f"{dep_id}(archived {dep_data.get('status')})"
                    except Exception:
                        pass
                dep_notes.append(note)
            # BUG-MSO-2026-0349: store the ANNOTATED notes (not the bare dep ids)
            # so every surface reading this map — dispatcher console, dep-holds
            # snapshot, mso status — carries the hold REASON (e.g. a dep that is
            # STALLED,cause=ERROR and needs human review), not just the dep id.
            WAITING_ON_DEPS[item_id] = dep_notes
            # BUG-MSO-2026-0274: emit DEP_HELD only when this item FIRST becomes
            # held or when its waiting_on set changes — scan_all_queues runs every
            # ~10s, so logging on every tick would flood the (line-capped) log and
            # bury higher-signal events.
            if _DEP_HELD_LOGGED.get(item_id) != waiting_on:
                write_lifecycle_event(
                    "DEP_HELD",
                    f"{item_id} held: waiting on {', '.join(dep_notes)}"
                )
                _DEP_HELD_LOGGED[item_id] = list(waiting_on)
            continue

        # v8.5: Explicit dependencies take precedence over role sequence gate.
        # If an order has dependsOn and all deps are satisfied (checked above),
        # the QM's planned execution order is authoritative — skip the generic
        # template-based role gate. This prevents deadlocks when the dependency
        # chain order differs from the template role sequence (e.g., COX before SCR).
        has_explicit_deps = bool(item["data"].get("dependsOn"))

        # BUG-MSO-2026-0248: skip orders that are mid-transition (complete_order is
        # writing the next-role PENDING file but hasn't handed off to dispatch yet).
        # Defense-in-depth: the idempotency guard in complete_order is the primary fix;
        # this gate prevents even the transient PENDING window from being selected.
        # BUG-MSO-2026-0262: clear-on-settle — if the on-disk state is already PENDING
        # (transition has completed), discard the stale gate so subsequent ticks can
        # dispatch the next role.  The gate only needs to hold for the intra-tick race
        # window; surviving across ticks strands the order indefinitely.
        if item_id in ORDERS_IN_TRANSITION:
            if item["data"].get("status") == "PENDING":
                ORDERS_IN_TRANSITION.discard(item_id)
                write_lifecycle_event(
                    "DISPATCH",
                    f"{item_id} MID_TRANSITION gate cleared (transition settled to PENDING) — BUG-0262"
                )
            else:
                WAITING_ON_DEPS[item_id] = ["MID_TRANSITION"]
                continue

        # v8.2: Role sequence gate — ensure prior roles completed in this voyage
        # Only enforced for orders WITHOUT explicit dependencies.
        if not has_explicit_deps and voyage_id and voyage_id in voyage_role_status:
            gate_passed, missing = check_role_sequence_gate(
                item["data"], voyage_role_status[voyage_id]
            )
            if not gate_passed:
                WAITING_ON_DEPS[item_id] = [f"ROLE GATE: {r}" for r in missing]
                continue

        dispatchable.append(item)

    # BUG-MSO-2026-0274: drop DEP_HELD dedup entries for items no longer held, so
    # the map stays bounded and a genuine re-hold (held -> dispatched -> held) logs
    # afresh rather than being silently suppressed by a stale entry.
    for _stale in [k for k in _DEP_HELD_LOGGED if k not in WAITING_ON_DEPS]:
        _DEP_HELD_LOGGED.pop(_stale, None)

    # BUG-MSO-2026-0349: snapshot the holds to .mso/state/dep-holds.json so
    # out-of-process consumers (mso status) can distinguish held from
    # dispatchable work. An empty map clears the file's holds.
    # Copilot #204: pass the dispatcher's own workspace resolver so the snapshot
    # lands in the active workspace under a _MAESTRO_DIR_OVERRIDE / MAESTRO_DIR
    # override, not maestro.workspace's CWD fallback.
    write_dep_holds(WAITING_ON_DEPS, workspace_dir=get_artefact_root())

    return sorted(dispatchable, key=lambda x: x["priority"])


def scan_review_queue() -> List[Dict[str, Any]]:
    """Return all orders currently parked in queues/review/ (NAV_REVIEW_PENDING).

    BUG-MSO-2026-0226: Eight Bells must NOT fire while orders are held here,
    and the dispatcher status must surface this count explicitly.
    """
    review_dir = get_artefact_root() / "queues" / "review"
    if not review_dir.exists():
        return []
    items = []
    for json_file in review_dir.glob("*.json"):
        try:
            data = json.loads(json_file.read_text(encoding='utf-8'))
            items.append({
                "id": data.get("orderId") or data.get("id") or json_file.stem,
                "title": data.get("title", json_file.stem),
                "role": data.get("targetRole", data.get("role", "?")),
                "status": data.get("status", "NAV_REVIEW_PENDING"),
                # FTR-MSO-2026-0427: which transition is holding it. Empty for an
                # order parked by a pre-0427 dispatcher (always the planning gate).
                "gate": data.get("reviewGate", ""),
            })
        except Exception:
            pass
    return items


# v7.0: Stale escalation threshold (minutes) — warn Captain if escalation pending too long
ESCALATION_STALE_MINUTES = 60

def scan_escalations() -> tuple:
    """Scan escalation queue (v7.0). Returns (pending_count, blocking_voyage_ids).

    Escalations are NOT dispatched - they need human (Captain/QM) review.
    Blocking escalations hold all orders for the same voyageId.
    Stale escalations (> ESCALATION_STALE_MINUTES) are logged as warnings.
    """
    esc_dir = get_queues_dir() / "escalations"
    if not esc_dir.exists():
        return 0, set()

    pending_count = 0
    blocking_voyages = set()
    now = datetime.now()

    for json_file in esc_dir.glob("*.json"):
        try:
            data = json.loads(json_file.read_text(encoding='utf-8'))
            if data.get("status") == "PENDING":
                pending_count += 1
                esc_id = data.get("id", json_file.stem)

                # Check for stale escalation
                created_at = data.get("createdAt", "")
                if created_at:
                    try:
                        created_time = datetime.fromisoformat(created_at)
                        age_minutes = (now - created_time).total_seconds() / 60
                        if age_minutes > ESCALATION_STALE_MINUTES:
                            block_tag = " [BLOCKING]" if data.get("blocking") else ""
                            _ep = current_persona()
                            print_warn(f"STALE ESCALATION{block_tag}: {esc_id} pending for {int(age_minutes)} minutes — requires {_ep.term('userTitle')}/{_ep.term('leadTitle')} resolution!")
                            write_lifecycle_event("ESCALATION", f"STALE: {esc_id} pending {int(age_minutes)}min{block_tag}")
                    except (ValueError, TypeError):
                        pass

                if data.get("blocking") and data.get("voyageId"):
                    blocking_voyages.add(data["voyageId"])
        except Exception:
            pass

    return pending_count, blocking_voyages


def get_available_crews(max_crews: int = 2) -> List[int]:
    """Get list of available crew numbers (not currently active).

    v7.1: If a crew is in ACTIVE_PROCESSES with a dead PID and unprocessed state,
    process completion first before marking as available. This prevents orphaning orders.
    """
    available = []

    for crew_num in range(1, 6):
        # Check if there's an active process
        pid = ACTIVE_PROCESSES.get(crew_num)
        if not pid:
            pid = read_crew_pid(crew_num)
        if pid and is_process_alive(pid):
            continue  # Still running

        # v7.1 FIX: If crew is tracked in ACTIVE_PROCESSES with a dead PID,
        # ensure completion is processed before making it available
        if crew_num in ACTIVE_PROCESSES:
            state = read_crew_state(crew_num)
            status = state.get("status", "") if state else ""
            if status and status != "RUNNING":
                # Dead PID with non-RUNNING state — process completion now
                if status not in TERMINAL_STATES:
                    print_warn(f"Crew {crew_num} dead with state '{status}' in get_available_crews - treating as CRASHED")
                    write_lifecycle_event("WARN", f"Crew {crew_num} dead with state '{status}' - forced CRASHED in get_available_crews")
                process_crew_completion(crew_num)
                del ACTIVE_PROCESSES[crew_num]
                # BUG-MSO-2026-0266: reset state to IDLE so the orphan scan later
                # in the same dispatcher tick doesn't re-call process_crew_completion
                # on the still-COMPLETE crew state, causing a spurious second convergence.
                _idle = {"crewNumber": crew_num, "status": "IDLE", "role": "-", "orderId": "-"}
                (get_crew_dir(crew_num) / "state.json").write_text(
                    json.dumps(_idle, indent=2), encoding='utf-8'
                )
            else:
                continue  # State is RUNNING or unknown — not safe to reuse yet

        # Check state file
        state = read_crew_state(crew_num)
        if state:
            status = state.get("status", "")
            if status == "RUNNING":
                continue  # State says running

        available.append(crew_num)

        # Stop once we have enough candidates
        if len(available) >= max_crews:
            break

    return available


def _ws_for_item(item: Dict[str, Any]) -> Optional[Path]:
    """Workspace dir for an item's ledger writes — derived from its queue path.

    BUG-MSO-2026-0294: queue files live at <ws>/queues/<tier>[/<sub>]/x.json.
    Deriving the workspace from the file's own location keeps ledger writes in
    the SAME workspace as the queue mutation (and keeps tests that point items
    at tmp dirs hermetic). Returns None for items WITHOUT a path (synthetic /
    already-moved) — the caller skips the ledger write; an item we cannot
    locate on disk cannot carry a durable claim anyway.
    """
    raw = item.get("path")
    if not raw:
        return None
    try:
        for parent in Path(raw).parents:
            if parent.name == "queues":
                return parent.parent
    except Exception:
        pass
    return get_artefact_root()


def mark_work_item_in_progress(item: Dict[str, Any], crew_num: int):
    """Mark a work item as IN_PROGRESS."""
    try:
        path = Path(item["path"])
        data = item["data"]
        data["status"] = "IN_PROGRESS"
        data["assignedTo"] = {"crew": crew_num, "role": item["role"]}
        data["startedAt"] = datetime.now().isoformat()
        path.write_text(json.dumps(data, indent=2), encoding='utf-8')
    except Exception as e:
        print_warn(f"Could not update status for {item['id']}: {e}")
    # BUG-MSO-2026-0294: the file claim above is a working-tree write that a
    # git reset can erase — the ledger claim is the durable one.
    _ledger_ws = _ws_for_item(item)
    if _ledger_ws is not None:
        order_ledger.record_claimed(item["id"], item.get("role", ""), crew_num,
                                    workspace_dir=_ledger_ws)


def mark_work_item_failed(item: Dict[str, Any], reason: str = "") -> None:
    """Mark a work item as FAILED so the dispatcher loop stops re-attempting it.

    BUG-ADM-2026-0008 (v2.5.5): added so dispatch_crew can fail-fast on
    misconfigured orders (e.g. SHP/BOS without a resolvable targetRepo)
    rather than spinning the queue.
    """
    try:
        path = Path(item["path"])
        data = item["data"]
        data["status"] = "FAILED"
        data["failedAt"] = datetime.now().isoformat()
        if reason:
            data["failureReason"] = reason
        path.write_text(json.dumps(data, indent=2), encoding='utf-8')
        _ledger_ws = _ws_for_item(item)  # BUG-MSO-2026-0294
        if _ledger_ws is not None:
            order_ledger.record_terminal(item["id"], "FAILED", workspace_dir=_ledger_ws)
    except Exception as e:
        print_warn(f"Could not mark {item.get('id', '?')} FAILED: {e}")


def hold_order_worktree_required(item: Dict[str, Any], detail: str, *,
                                 crew_num: Optional[int] = None,
                                 voyage_id: str = "",
                                 repo_root: Optional[Path] = None,
                                 repo_name: str = "") -> None:
    """BUG-MSO-2026-0389: worktree isolation could not be established — release
    the claim back to PENDING and DO NOT dispatch.

    The pre-0389 self-manage fallback dispatched the crew anyway with no
    worktree, so it edited the operator's LIVE primary product checkout (on
    main, no voyage branch, no isolation — the dogfood incident). Editing the
    live checkout is strictly worse than not dispatching: hold the order
    (requeued PENDING, WORKTREE_REQUIRED) so the next tick retries once the
    transient cause (Windows file lock, missing branch fetch) clears, or the
    operator fixes a persistent one.

    BUG-MSO-2026-0460 (GitHub #314): this hold now consumes the MAX_REQUEUES
    budget like every other requeue path (recover_orphaned_order,
    _hold_missing_sec_artefact). Pre-fix it wrote status=PENDING and returned
    WITHOUT ever touching requeueCount, so a worktree that could never be
    isolated (e.g. a stranded child process holding a Windows file lock on
    the directory) cycled CLAIM -> WORKTREE_FAIL -> RELEASED -> CLAIM forever
    with no ceiling and no escalation — recovery required a human deleting
    the directory. At MAX_REQUEUES the order now escalates to STALLED via
    _stall_worktree_required(), which names the worktree path, the last git
    error, and (best-effort) the process still holding the directory open —
    the hold itself is unchanged (still no unisolated dispatch, ever).
    """
    data = item.get("data") or {}
    requeue_count = int(data.get("requeueCount", 0))
    if requeue_count >= MAX_REQUEUES:
        _stall_worktree_required(
            item, detail, requeue_count,
            crew_num=crew_num, voyage_id=voyage_id,
            repo_root=repo_root, repo_name=repo_name)
        return
    try:
        path = Path(item["path"])
        data["status"] = "PENDING"
        data["requeueCount"] = requeue_count + 1
        data.pop("assignedTo", None)
        # Clear the claim timestamp with the claim itself. Leaving a stale
        # startedAt on a PENDING order is not merely untidy: BUG-MSO-2026-0023's
        # silent-completion check (`_order_has_silent_completion`) asks whether a
        # commit referencing this order id was authored AFTER startedAt. A value
        # left over from the previous claim widens that window backwards, so a
        # re-dispatched order that later times out can match a commit made before
        # it ever ran and be ADVANCEd as "silently completed" when nothing was
        # done. Every other requeue/hold path in this module clears it — including
        # this one's own sibling `_stall_worktree_required`.
        data.pop("startedAt", None)
        path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    except Exception as exc:
        print_warn(f"Could not hold {item.get('id', '?')} WORKTREE_REQUIRED: {exc}")
    _ledger_ws = _ws_for_item(item)  # BUG-MSO-2026-0294: durable release
    if _ledger_ws is not None:
        try:
            order_ledger.record_released(
                item["id"], f"WORKTREE_REQUIRED: {detail}", workspace_dir=_ledger_ws)
        except Exception:
            pass
    try:
        write_lifecycle_event(
            "WORKTREE_REQUIRED",
            f"{item['id']}: {detail} — order HELD + requeued (no unisolated "
            f"dispatch; BUG-0389) [attempt {requeue_count + 1}/{MAX_REQUEUES}]")
    except Exception:
        pass


def _stall_worktree_required(item: Dict[str, Any], detail: str, requeue_count: int, *,
                             crew_num: Optional[int] = None,
                             voyage_id: str = "",
                             repo_root: Optional[Path] = None,
                             repo_name: str = "") -> Path:
    """Escalate a WORKTREE_REQUIRED hold to STALLED once MAX_REQUEUES is hit.

    BUG-MSO-2026-0460: mirrors the STALLED-archive shape used by
    :func:`_stall_missing_sec_artefact`. Unlike that gate, no crew ever ran
    for this order — isolation failed BEFORE dispatch — so there is no crew
    branch to converge or salvage; the order is archived directly. The
    BUG-MSO-2026-0389 guarantee is preserved even at the cap: the order is
    never dispatched without isolation, it is parked for a human instead.
    """
    order_id = item.get("id", "?")
    data = item.get("data") or {}
    admiralty_dir = _ws_for_item(item) or get_artefact_root()

    worktree_path: Optional[Path] = None
    if voyage_id and crew_num:
        try:
            from maestro.core.worktrees import crew_worktree_path_for
            worktree_path = crew_worktree_path_for(voyage_id, crew_num, repo_name)
        except Exception:
            worktree_path = None

    lock_info = ""
    if worktree_path is not None and worktree_path.exists():
        try:
            from maestro.core.worktrees import _identify_worktree_lock_holder
            lock_info = f" Lock holder: {_identify_worktree_lock_holder(worktree_path)}."
        except Exception as _lk_exc:
            lock_info = f" Lock holder: could not be determined ({_lk_exc})."

    path_desc = f" Worktree path: {worktree_path}." if worktree_path is not None else ""
    reason = (
        f"WORKTREE_REQUIRED requeue cap exceeded ({requeue_count}/{MAX_REQUEUES}) "
        f"— crew worktree isolation could not be established after "
        f"{requeue_count} attempt(s). {detail}{path_desc}{lock_info}"
    )

    try:
        source_file: Optional[Path] = Path(item["path"])
    except Exception:
        source_file = None

    archive_dir = admiralty_dir / "orders" / "complete"
    archive_dir.mkdir(parents=True, exist_ok=True)

    data["status"] = "STALLED"
    data["stalledAt"] = datetime.now().isoformat()
    data["stalledReason"] = reason
    data["stalledCause"] = "ERROR"
    data["stalledBy"] = {
        "crew": crew_num,
        "role": item.get("role", "UNK"),
        "iterations": 0,
        "startTime": "",
        "endTime": "",
    }
    data.pop("assignedTo", None)
    data.pop("startedAt", None)

    archive_file = archive_dir / (source_file.name if source_file else f"{order_id}.json")
    archive_file.write_text(json.dumps(data, indent=2), encoding="utf-8")
    if source_file is not None and archive_file.resolve() != source_file.resolve():
        source_file.unlink(missing_ok=True)

    # BUG-MSO-2026-0294/0295: STALLED is terminal for dispatch purposes.
    order_ledger.record_terminal(order_id, "STALLED", workspace_dir=admiralty_dir)
    _commit_lifecycle_transition(
        [p for p in (archive_file, source_file) if p is not None],
        f"lifecycle: archive {order_id} (STALLED, WORKTREE_REQUIRED cap exceeded)",
    )
    # BUG-MSO-2026-0024: STALLED is a satisfying status, so dependents unblock.
    _mark_order_terminal_now()
    print_warn(
        f"Order {order_id} hit REQUEUE cap ({requeue_count}/{MAX_REQUEUES}) on "
        f"WORKTREE_REQUIRED -> escalated to STALLED for human review.{lock_info}"
    )
    write_lifecycle_event(
        "ESCALATE",
        f"{order_id} WORKTREE_REQUIRED requeue cap exceeded "
        f"({requeue_count}/{MAX_REQUEUES}) -> STALLED "
        f"(Crew {crew_num}, BUG-0460). {reason}"
    )
    if crew_num:
        ring_crew_bell(crew_num, order_id)
    # BUG-MSO-2026-0280: fire auto-queue from every terminal archival path so
    # dependents of this order are not stranded waiting on a STALLED parent.
    try:
        auto_queue_unblocked_orders(order_id)
    except Exception as _aq_exc:
        print_warn(f"Auto-queue after STALLED archival of {order_id} failed "
                   f"(non-fatal; reconciliation pass will recover): {_aq_exc}")
    return archive_file


def _build_repo_routing_rules(role: str, target_repo: str, docs_repo: str = "") -> str:
    """Build repo routing rules section for crew prompts (v8.10/v2.0.6).

    Enforces which repos each role can write to:
    - LKT/SCR: Reports and docs go to docs_repo ONLY (if configured), else target repo docs/
    - SHP/BOS: Code and tests go to the target service repo ONLY
    - NAV/COX: May write to both (plans touch docs, reviews touch code)
    - ALL roles: May always write to .mso/ (reports, handoffs, queues)

    docs_repo: optional separate documentation repo (e.g. "eml-documentation").
               If empty, SCR/LKT write to docs/ within the target repo.
    """
    # BUG-ADM-2026-0008: the previous fallback ("the target service repo") looked
    # like an unrendered placeholder and caused Sonnet 4.6 SHP crews to exit in
    # 1 iteration with no commits. The new fallback is unambiguously diagnostic
    # so an operator can see at a glance that the order is misconfigured.
    target_label = (
        f"repos/{target_repo}/" if target_repo
        else "<TARGET-REPO-NOT-RESOLVED — fix the order's `targetRepo` field "
             "or the project registry's `repo` entry>"
    )
    has_docs_repo = bool(docs_repo)
    docs_label = f"repos/{docs_repo}/" if has_docs_repo else f"{target_label}docs/"

    if has_docs_repo:
        lkt_rule = (
            f"You are a Lookout. Write ALL reports and investigation artifacts to "
            f"repos/{docs_repo}/ (following the existing folder structure). "
            f"You must NEVER create, modify, or add files to the target service repo. "
            f"You may read the target repo for investigation but must not write to it."
        )
        scr_rule = (
            f"You are a Scribe. Write ALL documentation to repos/{docs_repo}/ "
            f"(following the existing folder structure). "
            f"You must NEVER create or modify files in target service repos."
        )
        lkt_cannot = ["target"]
        scr_cannot = ["target"]
        shp_cannot = [docs_repo]
        bos_cannot = [docs_repo]
    else:
        lkt_rule = (
            f"You are a Lookout. Write ALL reports and investigation artifacts to "
            f"the docs/ directory within the target repo (`{target_label}docs/`). "
            f"You may read all files in the target repo for investigation."
        )
        scr_rule = (
            f"You are a Scribe. Write ALL documentation to the target repo (`{target_label}`). "
            f"Use the docs/ subdirectory for documentation files unless the order specifies otherwise."
        )
        lkt_cannot = []
        scr_cannot = []
        shp_cannot = []
        bos_cannot = []

    ROLE_REPO_RULES = {
        "LKT": {
            "rule": lkt_rule,
            "cannot_write_labels": [f"`{target_label}`"] if lkt_cannot else [],
        },
        "SCR": {
            "rule": scr_rule,
            "cannot_write_labels": [f"`{target_label}`"] if scr_cannot else [],
        },
        "SHP": {
            "rule": (
                f"You are a Shipwright. Write ALL code changes to the target service repo. "
                + (f"You must NEVER create or modify files in repos/{docs_repo}/. " if has_docs_repo else "")
                + "Documentation changes are the Scribe's responsibility."
            ),
            "cannot_write_labels": [f"`repos/{docs_repo}/`"] if shp_cannot else [],
        },
        "BOS": {
            "rule": (
                f"You are a Bosun. Write ALL test code and QA artifacts to the target service repo. "
                + (f"You must NEVER create or modify files in repos/{docs_repo}/." if has_docs_repo else "")
            ),
            "cannot_write_labels": [f"`repos/{docs_repo}/`"] if bos_cannot else [],
        },
        "NAV": {
            "rule": (
                f"You are a Navigator. You may write plans to the target repo"
                + (f" and repos/{docs_repo}/ as needed. Prefer documentation repo for "
                   f"architecture documents and the target repo for implementation plans."
                   if has_docs_repo else ".")
            ),
            "cannot_write_labels": [],
        },
        "COX": {
            "rule": (
                f"You are a Coxswain. You may write review artifacts to the target repo"
                + (f" and repos/{docs_repo}/ as needed." if has_docs_repo else ".")
            ),
            "cannot_write_labels": [],
        },
    }

    rules = ROLE_REPO_RULES.get(role, {})
    if not rules:
        return ""

    section = "\n## Repo Routing Rules (MANDATORY)\n\n"
    section += f"**Target Repo:** `{target_label}`\n"
    if has_docs_repo:
        section += f"**Documentation Repo:** `repos/{docs_repo}/`\n\n"
    else:
        section += f"**Documentation Repo:** `{target_label}docs/` (within target repo)\n\n"
    section += f"**YOUR RULE:** {rules['rule']}\n\n"

    if rules["cannot_write_labels"]:
        section += f"**DO NOT WRITE TO:** {', '.join(rules['cannot_write_labels'])}\n\n"

    section += "**Always allowed:** `.mso/` directory (reports, handoffs, queues, logs)\n"

    return section


def generate_prompt_for_item(item: Dict[str, Any]) -> str:
    """Generate a prompt file path for the work item.

    v8.8: Enhanced to inject all order metadata (references, tables, deliverables,
    requirementIds) into the active prompt so crews have full context.
    v8.10: Repo routing rules injected per role — enforces write boundaries.
    """
    prompts_dir = get_artefact_root() / "prompts" / "active"
    prompts_dir.mkdir(parents=True, exist_ok=True)

    prompt_file = prompts_dir / f"{item['id']}-{item['role']}.md"

    # Generate prompt with full order context
    role = item["role"]
    item_id = item["id"]
    item_type = item["type"]
    subtype = item.get("subtype", "")
    title = item["title"]
    data = item["data"]
    description = data.get("description", "")

    # Get acceptance criteria if available
    # Supports both legacy string arrays and structured AC objects (PLAN-AC-SCHEMA)
    criteria = data.get("acceptanceCriteria", [])
    def _format_ac(c):
        if isinstance(c, dict):
            sev = f" [{c.get('severity', 'blocking')}]" if c.get('severity') else ""
            return f"- {c.get('description', str(c))}{sev}"
        return f"- {c}"
    criteria_text = "\n".join(_format_ac(c) for c in criteria) if criteria else "- Complete the task as described"

    # Get files if available
    files = data.get("files", [])
    files_text = "\n".join(f"- {f}" for f in files) if files else "- Determine relevant files"

    # v8.8: Requirement IDs
    req_ids = data.get("requirementIds", [])
    req_section = ""
    if req_ids:
        req_section = "\n## Requirement IDs\n"
        req_section += "\n".join(f"- `{r}`" for r in req_ids)
        req_section += "\n"

    # v8.8: References (reference implementations, target paths, etc.)
    references = data.get("references", {})
    ref_section = ""
    if references:
        ref_section = "\n## References\n"
        if isinstance(references, list):
            ref_section += "\n".join(f"- `{r}`" for r in references) + "\n"
        else:
            ref_section += "\n| Key | Path |\n|-----|------|\n"
            for key, val in references.items():
                ref_section += f"| {key} | `{val}` |\n"

    # v8.8: Oracle tables (domain-specific but critical for data persistence orders)
    oracle_tables = data.get("oracleTables", [])
    oracle_section = ""
    if oracle_tables:
        oracle_section = "\n## Oracle Tables\n"
        oracle_section += "\n| Table | Schema | Access | Notes |\n|-------|--------|--------|-------|\n"
        for t in oracle_tables:
            table = t.get("table", "?")
            schema = t.get("schema", "?")
            access = t.get("access", "?")
            note = t.get("note", "")
            oracle_section += f"| {table} | {schema} | {access} | {note} |\n"

    # v8.8: SQL Server database name
    sql_db = data.get("sqlServerDatabase", "")
    sql_section = ""
    if sql_db:
        sql_section = f"\n## SQL Server Database\n- `{sql_db}`\n"

    # v8.8: Deliverables checklist
    deliverables = data.get("deliverables", [])
    deliv_section = ""
    if deliverables:
        deliv_section = "\n## Expected Deliverables\n"
        deliv_section += "\n".join(f"- [ ] {d}" for d in deliverables)
        deliv_section += "\n"

    # v8.8: Depends-on (dependency tracking)
    depends_on = data.get("dependsOn", [])
    dep_section = ""
    if depends_on:
        dep_section = "\n## Dependencies\n"
        dep_section += "\n".join(f"- `{d}`" for d in depends_on)
        dep_section += "\n"

    # v8.9: Prior role deliverables (plan + handoffs) for downstream phases
    nav_plan = data.get("navPlan", "")
    nav_handoff = data.get("navHandoff", "")
    shp_handoff = data.get("shpHandoff", "")
    nav_section = ""
    if nav_plan or nav_handoff or shp_handoff:
        nav_section = "\n## Prior Role Deliverables\n"
        nav_section += "**READ THESE FIRST** — previous roles have explored and implemented. Review their handoffs before starting.\n\n"
        if shp_handoff:
            nav_section += f"- **Shipwright Handoff (what was built):** `{shp_handoff}`\n"
        if nav_handoff:
            nav_section += f"- **Navigator Handoff (original instructions):** `{nav_handoff}`\n"
        if nav_plan:
            nav_section += f"- **Navigator Plan (full detail):** `{nav_plan}`\n"
        nav_section += "\nThe handoffs contain file lists, warnings, and traceability requirements.\n"

    # v7.3: Include previous timeout briefs so next crew knows what was tried
    timeout_briefs = data.get("timeoutBriefs", [])
    briefs_section = ""
    if timeout_briefs:
        briefs_section = "\n## Previous Attempts (Timed Out)\n"
        briefs_section += "The following crews attempted this order but timed out. Review their briefs to avoid repeating work:\n\n"
        for tb in timeout_briefs:
            briefs_section += f"**{tb.get('timestamp', 'unknown')} — Crew {tb.get('crew', '?')} ({tb.get('crewName', '?')}) — {tb.get('reason', 'TIMEOUT')}**\n"
            briefs_section += tb.get("brief", "(no brief captured)") + "\n\n"

    # v8.10: Repo routing rules — enforce which repos each role can write to
    # v2.0.6: docs_repo is optional; absent = SCR/LKT write to target repo's docs/ dir
    # BUG-ADM-2026-0008 (v2.5.5): if targetRepo is omitted on the order, resolve
    # from the project registry. Previously the prompt fell through to the
    # literal fallback string "the target service repo", which Sonnet 4.6
    # interpreted as a placeholder and exited in 1 iteration with no commits.
    target_repo = data.get("targetRepo", "")
    if not target_repo:
        target_repo = _resolve_target_repo_from_project(data)
    docs_repo = data.get("documentationRepo", "")
    repo_rules = _build_repo_routing_rules(role, target_repo, docs_repo)

    # v2.0.0: Managed repo instructions
    # v2.0.1: Per-order voyage branch — prefer explicit voyageBranch, then voyageId, then global env var
    voyage_branch = data.get("voyageBranch", "")
    voyage_id = data.get("voyageId", "")
    if voyage_branch:
        order_branch = voyage_branch
    elif voyage_id:
        order_branch = f"voyage/{voyage_id}" if not voyage_id.startswith("voyage/") else voyage_id
    else:
        order_branch = ""
    branch_ref = (order_branch or ACTIVE_VOYAGE_BRANCH).replace("refs/heads/", "")
    managed_repo_section = ""
    if target_repo and branch_ref:
        managed_repo_section = f"""
## Working Directory (Managed Repo)

Your target repo `{target_repo}` has been **pre-cloned** to your crew working directory.
- **Path:** Available via `$MAESTRO_REPO_PATH` env var (resolves to the voyage worktree)
- **Branch:** `{branch_ref}` (already checked out — DO NOT create or switch branches)
- **DO NOT** clone the repo yourself — it is already ready
- **DO** commit and push your changes to `{branch_ref}` when complete
- **DO NOT** create temp directories (`.local-nuget/`, etc.) outside `$MAESTRO_TEMP`
- Use `$MAESTRO_TEMP/nuget-local/` for any local NuGet package workarounds
"""

    prompt_content = f"""# {item_type}: {item_id}

## Role: {role}
## Title: {title}

## Description
{description}
{req_section}{ref_section}{oracle_section}{sql_section}{nav_section}{deliv_section}{dep_section}
## Target Files
{files_text}

## Acceptance Criteria
{criteria_text}
{briefs_section}{managed_repo_section}{repo_rules}
## Instructions
Complete this {subtype or item_type} order following the established patterns in the codebase.
When complete, commit and push your changes, then update the order status and signal completion.
"""

    prompt_file.write_text(prompt_content, encoding='utf-8')
    return str(prompt_file)


def _voyage_branch_has_post_started_commit(order_data: Dict[str, Any]) -> bool:
    """BUG-MSO-2026-0023: detect 'silent completion' before re-queuing.

    The dispatcher's previous behaviour was to REQUEUE any order whose crew
    timed out / crashed, even if the crew had already committed its work to
    the voyage branch before the timeout fired (typical BLD flow: commit
    work → enter brief-generation tail → tail exceeds timeout → process killed
    after the commit already shipped). Re-queueing in that case wastes ~$0.10-
    $0.50 in fresh-crew Claude inference per occurrence and confuses operators
    who see REQUEUE/TIMEOUT messages for work that's actually done.

    This helper checks the order's voyageBranch for a commit referencing the
    order ID, authored after the order's startedAt timestamp. If found, the
    timeout-handler treats it as a 'silent completion' and ADVANCEs the order
    to its next role (or COMPLETEs it) instead of REQUEUE.

    Returns True if a post-startedAt commit referencing the order ID exists
    on the voyage branch (local or remote-tracking ref). False if the check
    can't be made (missing fields, git error) — the conservative path is
    REQUEUE, matching legacy behaviour.
    """
    order_id = order_data.get("orderId") or order_data.get("id")
    voyage_branch = order_data.get("voyageBranch")
    started_at = order_data.get("startedAt")

    if not (order_id and voyage_branch and started_at):
        return False

    # Prefer the local ref if it exists; fall back to refs/remotes/origin/.
    # Either is fine for `git log` — the SHA chain is the same regardless of
    # whether the local-tracking ref exists.
    candidate_refs = [voyage_branch, f"refs/remotes/origin/{voyage_branch}"]

    for ref in candidate_refs:
        try:
            verify = run_hidden(
                ["git", "rev-parse", "--verify", "--quiet", ref],
                capture_output=True, timeout=5
            )
            if verify.returncode != 0:
                continue

            # --since accepts ISO-8601; restrict log to commits after startedAt.
            # %s prints only the subject line, which is where order IDs land
            # (e.g. `bug(BUG-MSO-2026-0023): ...` or `feat(FTR-MSO-...): ...`).
            log_result = run_hidden(
                ["git", "log", "--format=%s", f"--since={started_at}", ref],
                capture_output=True, text=True, timeout=10
            )
            if log_result.returncode != 0:
                continue

            for subject in log_result.stdout.splitlines():
                if order_id in subject:
                    return True
            # Found a valid ref but no matching commit; no need to check the other.
            return False
        except (subprocess.TimeoutExpired, Exception):
            continue

    return False


def recover_orphaned_order(order_id: str, crew_num: int, reason: str):
    """Reset an orphaned IN_PROGRESS order back to PENDING for re-dispatch.

    BUG-MSO-2026-0023: before re-queuing, check whether the voyage branch
    already has a commit referencing this order ID, authored after the
    order's startedAt. If so, the crew silently completed its work (committed
    + pushed, then died in the brief-generation tail past the timeout). In
    that case route through complete_order() so the order ADVANCEs to the
    next role (or archives as COMPLETE) instead of being wastefully re-queued
    to a fresh crew that would just notice the existing commit and ADVANCE.

    v7.3: Reads timeout brief from crew state and appends it to the order's
    timeoutBriefs array before re-queuing. This preserves a record of what
    was attempted so the next crew can pick up where the previous one left off.
    """
    # v7.3: Read timeout brief from crew state before re-queuing
    crew_state = read_crew_state(crew_num)
    timeout_brief = None
    if crew_state:
        timeout_brief = crew_state.get("timeoutBrief")

    # BUG-MSO-2026-0276: a REQUEUE-after-crash must re-validate the order's CURRENT
    # on-disk eligibility, not blindly flip the cached IN_PROGRESS order back to
    # PENDING. While the crew was running, a LEAD recovering by hand may have changed
    # the status (e.g. to BACKLOG), added a dependsOn, or moved the file out of the
    # scanned queues. Honour those mutations and abort cleanly (REQUEUE_ABORTED)
    # instead of silently re-dispatching over the top of them. The scanned-dir set
    # MUST mirror scan_all_queues() so "dispatchable here" means the same in both paths.
    queues_dir = get_queues_dir()
    search_dirs = [
        queues_dir / "explicit", queues_dir / "security", queues_dir / "bugs",
        queues_dir / "orders", queues_dir / "defects", queues_dir / "breakdown",
        queues_dir / "high-level",
    ]
    # Mirror scan_all_queues() EXACTLY: it only dispatches a fixed set of request
    # categories, so the requeue eligibility check must scan the same fixed set
    # (not every subdir under requests/) or the two paths could disagree.
    requests_dir = queues_dir / "requests"
    for sub_name in ("planning", "investigation", "qa", "security-scan", "documentation"):
        sub = requests_dir / sub_name
        if sub.exists():
            search_dirs.append(sub)

    # Locate the order by ID across the scanned queues, regardless of status.
    found_file = None
    found_data = None
    for search_dir in search_dirs:
        if not search_dir.exists():
            continue
        for json_file in search_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
            except Exception as e:
                # v7.1 FIX: Log errors instead of silently swallowing them
                print_warn(f"Error reading queue file {json_file}: {e}")
                continue
            file_order_id = data.get("orderId") or data.get("id") or json_file.stem
            if file_order_id == order_id:
                found_file = json_file
                found_data = data
                break
        if found_file is not None:
            break

    # AC-3: file moved out of the scanned queues (e.g. parked in queues/proposed/)
    # or deleted entirely — the LEAD has taken it out of circulation; do not resurrect.
    if found_file is None:
        order_ledger.record_released(order_id, f"REQUEUE_ABORTED file-not-in-queues: {reason}", workspace_dir=get_artefact_root())  # BUG-MSO-2026-0294
        print_warn(f"REQUEUE aborted for {order_id}: not found in any scanned queue (Crew {crew_num} {reason})")
        write_lifecycle_event(
            "REQUEUE_ABORTED",
            f"{order_id} not re-dispatched: file-not-in-queues — parked/moved out of "
            f"dispatcher-scanned dirs (Crew {crew_num} {reason})"
        )
        return

    # AC-1: a LEAD changed the status away from IN_PROGRESS (e.g. BACKLOG) — the
    # order is deliberately no longer dispatchable; respect the intervention.
    current_status = found_data.get("status")
    if current_status != "IN_PROGRESS":
        order_ledger.record_released(order_id, f"REQUEUE_ABORTED status-changed: {current_status}", workspace_dir=get_artefact_root())  # BUG-MSO-2026-0294
        print_warn(f"REQUEUE aborted for {order_id}: on-disk status is {current_status}, not IN_PROGRESS (Crew {crew_num} {reason})")
        write_lifecycle_event(
            "REQUEUE_ABORTED",
            f"{order_id} not re-dispatched: status-changed (on-disk={current_status}) — "
            f"manual intervention respected (Crew {crew_num} {reason})"
        )
        return

    # BUG-MSO-2026-0023: check whether the crew silently completed its work
    # (committed to the voyage branch) before timing out in the brief-generation
    # tail. If so, route through the normal ADVANCE/COMPLETE path instead of REQUEUE.
    if _voyage_branch_has_post_started_commit(found_data):
        write_lifecycle_event(
            "SILENT_COMPLETION_DETECTED",
            f"{order_id} timeout ({reason}) but commit found on "
            f"{found_data.get('voyageBranch', '?')} after startedAt — "
            f"advancing instead of re-queueing (Crew {crew_num})"
        )
        print_ok(
            f"Silent completion detected for {order_id}: commit present on voyage "
            f"branch; advancing instead of REQUEUE."
        )
        # complete_order handles the role-sequence ADVANCE or final COMPLETE archive.
        complete_order(order_id, crew_num, crew_state or {})
        return

    # BUG-MSO-2026-0285: PRESERVE in-flight crew work before requeue/STALLED.
    # A crew killed at the timeout (or crashed) may have real uncommitted work in
    # its worktree that the silent-completion check above can't see (it's not on
    # the voyage branch). Commit it onto the crew branch, then rename that branch
    # to salvage/<order>-<sha> so it survives the worktree teardown — previously
    # this work was silently lost and needed manual LEAD recovery. We do NOT
    # auto-advance (the work may be partial); we just guarantee it's never lost.
    _salvage_vid = _get_voyage_id_for_order(order_id)
    if _salvage_vid:
        try:
            from maestro.core.worktrees import (
                commit_crew_worktree_if_dirty,
                preserve_failed_crew_branch,
            )
            # FTR-MSO-2026-0378: salvage the crew's per-repo worktree/branch in
            # the ORDER's product-repo checkout (single-repo → None/"").
            _rr_sv, _rn_sv = _repo_ctx_for_order(order_id)
            commit_crew_worktree_if_dirty(_salvage_vid, crew_num, order_id,
                                          repo_name=_rn_sv,
                                          voyage_branch=found_data.get("voyageBranch"))
            _salv = preserve_failed_crew_branch(_salvage_vid, crew_num, order_id,
                                                repo_root=_rr_sv, repo_name=_rn_sv)
            if _salv and _salv.get("salvageBranch"):
                found_data.setdefault("salvageBranches", []).append({
                    "branch": _salv.get("salvageBranch"),
                    "sha": _salv.get("strandedSha"),
                    "reason": reason,
                    "crew": crew_num,
                    "timestamp": datetime.now().isoformat(),
                })
                write_lifecycle_event(
                    "SALVAGE",
                    f"{order_id} in-flight crew work preserved on "
                    f"{_salv.get('salvageBranch')} before requeue "
                    f"(Crew {crew_num} {reason}, BUG-0285)"
                )
        except Exception as _salv_exc:
            write_lifecycle_event(
                "WARN",
                f"{order_id} timeout salvage failed: {_salv_exc} (Crew {crew_num})"
            )

    # AC-2: a dependsOn was added (or a dep regressed) since pickup — do not
    # re-dispatch into an unmet dependency. Reset to PENDING WITHOUT spending a
    # requeue attempt so the scan_all_queues dependency gate dispatches it later,
    # once the dependency is satisfied.
    deps_ok, waiting_on = check_dependencies_satisfied(found_data)
    if not deps_ok:
        found_data["status"] = "PENDING"
        found_data.pop("assignedTo", None)
        found_data.pop("startedAt", None)
        found_file.write_text(json.dumps(found_data, indent=2), encoding='utf-8')
        order_ledger.record_released(order_id, f"REQUEUE_ABORTED dep-unsatisfied: {waiting_on}", workspace_dir=get_artefact_root())  # BUG-MSO-2026-0294
        _mark_order_terminal_now()
        print_warn(f"REQUEUE aborted for {order_id}: dependencies unsatisfied {waiting_on} (Crew {crew_num} {reason})")
        write_lifecycle_event(
            "REQUEUE_ABORTED",
            f"{order_id} not re-dispatched: dep-unsatisfied (waiting on {waiting_on}) — "
            f"reset to PENDING; dependency gate will dispatch when satisfied (Crew {crew_num} {reason})"
        )
        return

    # FTR-MSO-2026-0359: NETWORK-classified failures are infrastructure, not the
    # order's fault — they must NEVER consume the MAX_REQUEUES budget (the
    # 2026-07-14 dropout burned attempt 1/2 on FTR-0355; a second blip would have
    # STALLED it). Track them on a separate, more generous counter with
    # exponential backoff, and arm the offline dispatch gate so the dispatcher
    # probes connectivity before launching the next crew into the same outage.
    if reason == "NETWORK":
        from maestro.core.connectivity import load_resilience_config
        _res_cfg = load_resilience_config(get_artefact_root())
        _net_max = max(1, int(_res_cfg.get("networkRetryMax", 5)))
        _backoffs = _res_cfg.get("networkBackoffMinutes") or [1, 5, 15]
        _net_info = found_data.get("networkRetry") or {}
        _net_count = int(_net_info.get("count", 0))
        if _net_count >= _net_max:
            write_lifecycle_event(
                "ESCALATE",
                f"{order_id} exhausted NETWORK retries ({_net_count}/{_net_max}) — "
                f"persistent network outage; escalating to STALLED for human review "
                f"(Crew {crew_num})"
            )
            print_warn(
                f"Order {order_id} exhausted NETWORK retries ({_net_count}/{_net_max}); "
                f"escalating to STALLED — persistent network outage."
            )
            archive_stalled_order(
                order_id, crew_num, crew_state or {},
                f"NETWORK retry cap exceeded ({_net_count}/{_net_max}) — persistent "
                f"network outage. Restore connectivity, then reopen with "
                f"`mso order retry {order_id}`.",
                stalled_cause="ERROR",
            )
            return
        try:
            _delay_min = float(_backoffs[min(_net_count, len(_backoffs) - 1)])
        except (TypeError, ValueError, IndexError):
            _delay_min = 1.0
        _backoff_until = datetime.now() + timedelta(minutes=_delay_min)
        found_data["status"] = "PENDING"
        found_data["networkRetry"] = {
            "count": _net_count + 1,
            "backoffUntil": _backoff_until.isoformat(),
            "lastAt": datetime.now().isoformat(),
            "lastCrew": crew_num,
        }
        found_data.pop("assignedTo", None)
        found_data.pop("startedAt", None)
        if timeout_brief:
            found_data.setdefault("timeoutBriefs", []).append({
                "crew": crew_num,
                "crewName": _get_crew_name(crew_num),
                "reason": reason,
                "timestamp": datetime.now().isoformat(),
                "brief": timeout_brief,
            })
        found_file.write_text(json.dumps(found_data, indent=2), encoding='utf-8')
        order_ledger.record_released(order_id, "NETWORK_RETRY", workspace_dir=get_artefact_root())
        _mark_order_terminal_now()
        _note_network_suspect(f"{order_id} crew {crew_num} died NETWORK")
        print_warn(
            f"Network failure on {order_id} (Crew {crew_num}) — network retry "
            f"{_net_count + 1}/{_net_max}, {_delay_min:g}m backoff (MAX_REQUEUES budget untouched)"
        )
        write_lifecycle_event(
            "NETWORK_RETRY",
            f"{order_id} network failure (Crew {crew_num}) — retry {_net_count + 1}/{_net_max} "
            f"after {_delay_min:g}m backoff; MAX_REQUEUES budget untouched (FTR-0359)"
        )
        return

    # BUG-MSO-2026-0206: cap REQUEUEs so a crew that hangs/fails every time can
    # never loop indefinitely. After MAX_REQUEUES real attempts, escalate to STALLED
    # (archived for human review). STALLED is a satisfying status, so the voyage's
    # dependents are not blocked forever.
    requeue_count = int(found_data.get("requeueCount", 0))
    if requeue_count >= MAX_REQUEUES:
        write_lifecycle_event(
            "ESCALATE",
            f"{order_id} hit REQUEUE cap ({requeue_count}/{MAX_REQUEUES}) "
            f"after {reason} — escalating to STALLED for human review (Crew {crew_num})"
        )
        print_warn(
            f"Order {order_id} hit REQUEUE cap ({requeue_count}/{MAX_REQUEUES}); "
            f"escalating to STALLED instead of re-queuing."
        )
        archive_stalled_order(
            order_id, crew_num, crew_state or {},
            f"REQUEUE cap exceeded ({requeue_count}/{MAX_REQUEUES}); last reason: {reason}",
            stalled_cause="ERROR",
        )
        return

    # AC-4 happy path: order is genuinely eligible (IN_PROGRESS, in a scanned queue,
    # deps satisfied, under the cap) — reset to PENDING for a fresh crew.
    found_data["status"] = "PENDING"
    found_data["requeueCount"] = requeue_count + 1
    found_data.pop("assignedTo", None)
    found_data.pop("startedAt", None)

    # v7.3: Append timeout brief to order history
    if timeout_brief:
        found_data.setdefault("timeoutBriefs", []).append({
            "crew": crew_num,
            "crewName": _get_crew_name(crew_num),
            "reason": reason,
            "timestamp": datetime.now().isoformat(),
            "brief": timeout_brief,
        })
        print_info(f"  Timeout brief attached to {order_id}")

    found_file.write_text(json.dumps(found_data, indent=2), encoding='utf-8')
    # BUG-MSO-2026-0294: release the durable claim — a fresh crew may take it.
    order_ledger.record_released(order_id, f"REQUEUE: {reason}", workspace_dir=get_artefact_root())
    # BUG-MSO-2026-0224: a REQUEUE->PENDING transition is in-flight work, not an
    # empty queue. Refresh the Eight Bells grace clock so the very next scan can't
    # ring a false "all work complete" bell (and fire a premature sweep_decks /
    # Auto-PR) in the window between pulling the order from IN_PROGRESS and the
    # dispatcher observing the PENDING write.
    _mark_order_terminal_now()
    print_warn(f"Re-queued orphaned order {order_id} (Crew {crew_num} {reason}) [attempt {requeue_count + 1}/{MAX_REQUEUES}]")
    write_lifecycle_event("REQUEUE", f"{order_id} re-queued (Crew {crew_num} {reason}) [attempt {requeue_count + 1}/{MAX_REQUEUES}]")


def _maybe_hold_plan_for_review(
    data: Dict[str, Any], source_file: Path, completed_role: str,
    crew_num: int, order_id: str, workspace_dir: Path,
) -> bool:
    """BUG-MSO-2026-0205: hold a completed standalone planning order for human review.

    The intra-order gate only fires when a planning role has a NEXT role in the
    SAME order's roleSequence. The current planning convention builds voyages as
    SEPARATE orders — a standalone `[PLN]` order whose plan is consumed by dependent
    FTR/BLD orders. Such an order has no next role, so it would archive COMPLETE
    immediately and its dependents would dispatch with no human checkpoint.

    When the gate is enabled (and the order isn't exempt / skip-overridden), route
    the planning order to queues/review/ as NAV_REVIEW_PENDING with `planApprovalOnly`.
    Because NAV_REVIEW_PENDING is NOT a satisfying status, dependents stay blocked
    until `mso review approve` archives the plan as COMPLETE.

    Returns True if the order was routed to review (caller must NOT archive it),
    False if it should proceed to normal COMPLETE archival.
    """
    if not _is_planning_role(completed_role):
        return False
    gate_cfg = load_gate_config(workspace_dir)
    if gate_check_post_nav(data, gate_cfg) != "pause":
        return False

    check_plan_sizing(order_id, workspace_dir)
    review_dir = workspace_dir / "queues" / "review"
    review_dir.mkdir(parents=True, exist_ok=True)
    data["status"] = "NAV_REVIEW_PENDING"
    data["planApprovalOnly"] = True  # no next role — approve archives as COMPLETE
    data["navReviewPausedAt"] = datetime.now().isoformat()
    data.pop("assignedTo", None)
    data.pop("startedAt", None)
    data.pop("targetRole", None)
    (review_dir / source_file.name).write_text(json.dumps(data, indent=2), encoding='utf-8')
    source_file.unlink()
    print_ok(f"Order {order_id} plan complete -> paused for human review (plan approval)")
    write_lifecycle_event(
        "NAV_REVIEW_PENDING",
        f"{order_id} planning complete -> queues/review/ (plan approval, Crew {crew_num})"
    )
    ring_crew_bell(crew_num, order_id)
    return True


def _maybe_hold_transition_for_review(
    data: Dict[str, Any], source_file: Path, review_dir: Path,
    completed_role: str, next_role: str,
    crew_num: int, order_id: str, workspace_dir: Path, context: str = "",
) -> bool:
    """FTR-MSO-2026-0427: hold an order at ANY gated role transition.

    Generalises the former post-planning-only checkpoint. The gate governing
    `completed_role -> next_role` is resolved from gates.json — schema-v2
    `transitions` map first, then the legacy `post_nav_review` key for planning
    exits (see maestro/core/gates.resolve_transition_gate). A workspace with a
    v1 gates.json, or none at all, therefore behaves exactly as before.

    The transition that paused the order is recorded on the order JSON
    (`reviewGate` / `reviewGateFrom` / `reviewGateTo`) so `mso review
    queue/approve/revise` and the auto-approve tick know which gate they are
    acting on rather than assuming PLN->BLD.

    Returns True if the order was parked in queues/review/ (caller must NOT
    advance it), False if it should proceed to the normal ADVANCE.
    """
    # BUG-MSO-2026-0022: story-sizing soft gate — planning exits only, and
    # before the gate decision, exactly as the pre-0427 call sites had it.
    if _is_planning_role(completed_role):
        check_plan_sizing(order_id, workspace_dir)

    gate_cfg = load_gate_config(workspace_dir)
    if gate_check_transition(data, gate_cfg, completed_role, next_role) != "pause":
        return False

    key = transition_key(completed_role, next_role)
    review_dir.mkdir(parents=True, exist_ok=True)
    data["status"] = "NAV_REVIEW_PENDING"
    data["targetRole"] = next_role
    data["navReviewPausedAt"] = datetime.now().isoformat()
    data["reviewGate"] = key
    # Store the RAW role codes, not the canonical ones: `mso review revise` puts
    # reviewGateFrom straight back into targetRole, and that must spell the role
    # the way this order's own roleSequence spells it (a legacy ["NAV","SHP",...]
    # sequence would not match a canonicalised "PLN", stranding the advance).
    # gates.order_gate_transition canonicalises on read for gate resolution.
    data["reviewGateFrom"] = completed_role
    data["reviewGateTo"] = next_role
    data.pop("assignedTo", None)
    data.pop("startedAt", None)
    review_file = review_dir / source_file.name
    review_file.write_text(json.dumps(data, indent=2), encoding='utf-8')
    source_file.unlink()
    suffix = f" ({context})" if context else ""
    print_ok(f"Order {order_id} {key} -> paused for human review{suffix}")
    write_lifecycle_event(
        "NAV_REVIEW_PENDING",
        f"{order_id} {key} transition -> queues/review/ (Crew {crew_num}{', ' + context if context else ''})"
    )
    ring_crew_bell(crew_num, order_id)
    return True


def _mark_role_succeeded(order_id: str, role: str, crew_num: int) -> bool:
    """Write crash-safe finalization checkpoint to the in-queue order JSON.

    Called in process_crew_completion() BEFORE any blocking finalization calls
    (PR creation, file moves). If the dispatcher crashes between crew completion
    and the ADVANCE/archive write, reset_orphaned_in_progress_orders() will detect
    roleSucceededAt and resume finalization instead of re-dispatching the same role.
    BUG-MSO-2026-0222.

    Returns True if the checkpoint was written, False if the order was not found
    or was already past IN_PROGRESS (no write needed).
    """
    queues_dir = get_queues_dir()
    search_dirs = [
        queues_dir / "orders", queues_dir / "explicit", queues_dir / "high-level",
        queues_dir / "bugs", queues_dir / "defects", queues_dir / "security",
        queues_dir / "breakdown",
    ]
    requests_dir = queues_dir / "requests"
    if requests_dir.exists():
        for sub in requests_dir.iterdir():
            if sub.is_dir():
                search_dirs.append(sub)

    for search_dir in search_dirs:
        if not search_dir.exists():
            continue
        for json_file in search_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                file_order_id = data.get("orderId") or data.get("id") or json_file.stem
                if file_order_id != order_id:
                    continue
                if data.get("status") != "IN_PROGRESS":
                    return False  # already past IN_PROGRESS — checkpoint not needed
                data["roleSucceededAt"] = datetime.now().isoformat()
                data["roleSucceededBy"] = {"role": role, "crew": crew_num}
                tmp = json_file.with_suffix('.tmp')
                tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')
                tmp.replace(json_file)
                write_lifecycle_event(
                    "FINALIZE",
                    f"{order_id} role {role} succeeded — crash-safe checkpoint written (Crew {crew_num}, BUG-0222)"
                )
                return True
            except Exception:
                pass
    return False


def _record_convergence_failure(order_id: str, error_detail: str,
                                salvage: Optional[Dict[str, Any]] = None) -> bool:
    """Mark an order CONVERGENCE_FAILED in its queue JSON (BUG-MSO-2026-0244).

    Called from process_crew_completion() when the crew->voyage convergence merge
    fails. Sets a non-PENDING, non-IN_PROGRESS status so the order is:
      - NOT re-dispatched (scan_all_queues only returns PENDING), and
      - NOT auto-archived by the resume-finalization paths (which require
        IN_PROGRESS in a queue, or roleSucceededAt in orders/active/).
    The order is left in place for operator/recovery action, annotated with the
    salvage branch + stranded SHA so the work can be cherry-picked.

    Returns True if the order JSON was found and updated.
    """
    queues_dir = get_queues_dir()
    search_dirs = [
        queues_dir / "orders", queues_dir / "explicit", queues_dir / "high-level",
        queues_dir / "bugs", queues_dir / "defects", queues_dir / "security",
        queues_dir / "breakdown",
    ]
    requests_dir = queues_dir / "requests"
    if requests_dir.exists():
        for sub in requests_dir.iterdir():
            if sub.is_dir():
                search_dirs.append(sub)

    for search_dir in search_dirs:
        if not search_dir.exists():
            continue
        for json_file in search_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                file_order_id = data.get("orderId") or data.get("id") or json_file.stem
                if file_order_id != order_id:
                    continue
                data["status"] = "CONVERGENCE_FAILED"
                data["convergence"] = {
                    "failed": True,
                    "failedAt": datetime.now().isoformat(),
                    "error": error_detail,
                    "salvageBranch": (salvage or {}).get("salvageBranch"),
                    "strandedSha": (salvage or {}).get("strandedSha"),
                }
                # Drop the live-crew assignment so orphan scans treat it as settled.
                data.pop("assignedTo", None)
                tmp = json_file.with_suffix('.tmp')
                tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')
                tmp.replace(json_file)
                # BUG-MSO-2026-0344: release the durable ledger claim. Claims
                # carry the DISPATCHER's pid, so without this the stranded
                # order stays "live-claimed" for the rest of the dispatcher's
                # life and scan_all_queues silently skips it even after an
                # operator resets it to PENDING (recovery needed a restart).
                order_ledger.record_released(
                    order_id, "CONVERGENCE_FAILED — stranded for operator recovery",
                    workspace_dir=get_artefact_root())
                # BUG-MSO-2026-0307: a CONVERGENCE_FAILED order is unfinished work
                # needing recovery — refresh the Eight Bells grace clock so the
                # next tick re-evaluates completion with this stranded order
                # visible, never false-finishing in the same/next tick.
                _mark_order_terminal_now()
                return True
            except Exception:
                pass
    return False


def _record_verify_failure(order_id: str, error_detail: str,
                           salvage: Optional[Dict[str, Any]] = None,
                           log_path: Optional["Path"] = None) -> bool:
    """Mark an order VERIFY_FAILED in its queue JSON (FTR-MSO-2026-0287 R2).

    Mirrors _record_convergence_failure: sets a non-PENDING, non-IN_PROGRESS
    status so the held order is neither re-dispatched nor auto-archived, and
    annotates it with the verify error + salvage branch. Used when the local
    verify gate fails BEFORE convergence, so the broken work is never pushed and
    no CI is spent on it.

    ``log_path`` (BUG-MSO-2026-0506) is the full verify stdout+stderr persisted
    by :func:`_persist_verify_log` — recorded alongside the bounded
    ``error_detail`` excerpt so an operator reading the order JSON has the same
    pointer the lifecycle event carries.
    """
    queues_dir = get_queues_dir()
    search_dirs = [
        queues_dir / "orders", queues_dir / "explicit", queues_dir / "high-level",
        queues_dir / "bugs", queues_dir / "defects", queues_dir / "security",
        queues_dir / "breakdown",
    ]
    requests_dir = queues_dir / "requests"
    if requests_dir.exists():
        for sub in requests_dir.iterdir():
            if sub.is_dir():
                search_dirs.append(sub)

    for search_dir in search_dirs:
        if not search_dir.exists():
            continue
        for json_file in search_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                file_order_id = data.get("orderId") or data.get("id") or json_file.stem
                if file_order_id != order_id:
                    continue
                data["status"] = "VERIFY_FAILED"
                data["verify"] = {
                    "failed": True,
                    "failedAt": datetime.now().isoformat(),
                    "error": error_detail,
                    "salvageBranch": (salvage or {}).get("salvageBranch"),
                    "strandedSha": (salvage or {}).get("strandedSha"),
                    "logPath": str(log_path) if log_path else None,
                }
                data.pop("assignedTo", None)
                tmp = json_file.with_suffix('.tmp')
                tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')
                tmp.replace(json_file)
                # BUG-MSO-2026-0344: release the dispatcher-pid ledger claim so
                # operator recovery (retry / status reset) is visible to the
                # RUNNING dispatcher — see _record_convergence_failure.
                order_ledger.record_released(
                    order_id, "VERIFY_FAILED — held for operator recovery",
                    workspace_dir=get_artefact_root())
                return True
            except Exception:
                pass
    return False


_AUTO_SERIALIZE_CAP = 1  # FTR-MSO-2026-0267: max auto-serialize retries before CONVERGENCE_FAILED
_CONVERGENCE_RETRY_CAP = 3  # BUG-MSO-2026-0268: max convergence-network retries before CONVERGENCE_FAILED


def _auto_serialize_order(order_id: str, conflict_files: list,
                          salvage: Optional[Dict[str, Any]] = None) -> bool:
    """Re-queue a content-conflicted order as PENDING (FTR-MSO-2026-0267).

    Called when merge_crew_branch_into_voyage raises WorktreeContentConflict.
    Increments ``serializeCount`` on the order JSON and re-sets status to PENDING
    so the dispatcher will re-dispatch it.  The fresh crew builds on the now-updated
    voyage branch (the winner already converged) and should merge cleanly.

    The salvage branch is retained unchanged — if this re-run also fails (because
    serializeCount reached _AUTO_SERIALIZE_CAP) the operator can still cherry-pick
    from it.

    Returns True if the order was found and updated, False otherwise.
    """
    queues_dir = get_queues_dir()
    search_dirs = [
        queues_dir / "orders", queues_dir / "explicit", queues_dir / "high-level",
        queues_dir / "bugs", queues_dir / "defects", queues_dir / "security",
        queues_dir / "breakdown",
    ]
    requests_dir = queues_dir / "requests"
    if requests_dir.exists():
        for sub in requests_dir.iterdir():
            if sub.is_dir():
                search_dirs.append(sub)

    for search_dir in search_dirs:
        if not search_dir.exists():
            continue
        for json_file in search_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                file_order_id = data.get("orderId") or data.get("id") or json_file.stem
                if file_order_id != order_id:
                    continue
                data["status"] = "PENDING"
                data["serializeCount"] = data.get("serializeCount", 0) + 1
                data["autoSerialized"] = {
                    "at": datetime.now().isoformat(),
                    "conflictFiles": conflict_files,
                    "salvageBranch": (salvage or {}).get("salvageBranch"),
                }
                # Drop live-crew assignment so the dispatcher treats it as ready to pick up.
                data.pop("assignedTo", None)
                tmp = json_file.with_suffix('.tmp')
                tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')
                tmp.replace(json_file)
                # BUG-MSO-2026-0350 (issue #203): release the dispatcher-pid
                # ledger claim — same class as BUG-0344. Claims carry the
                # DISPATCHER's own pid, so without this the freshly re-queued
                # PENDING file stays "live-claimed" for the rest of this
                # dispatcher's life and scan_all_queues silently skips it:
                # pending=0 heartbeats + a false Eight Bells while real work
                # sits on disk, until a restart.
                order_ledger.record_released(
                    order_id, "AUTO_SERIALIZE — content conflict, requeued PENDING",
                    workspace_dir=get_artefact_root())
                # BUG-MSO-2026-0309: an AUTO_SERIALIZE re-queue is unfinished work
                # created mid-tick. Refresh the Eight Bells grace clock so the bell
                # cannot fire in the same/next tick using stale top-of-tick state.
                _mark_order_terminal_now()
                return True
            except Exception:
                pass
    return False


def _get_serialize_count_for_order(order_id: str) -> int:
    """Return the current serializeCount for an order (0 if never auto-serialized)."""
    queues_dir = get_queues_dir()
    search_dirs = [
        queues_dir / "orders", queues_dir / "explicit", queues_dir / "high-level",
        queues_dir / "bugs", queues_dir / "defects", queues_dir / "security",
        queues_dir / "breakdown",
    ]
    requests_dir = queues_dir / "requests"
    if requests_dir.exists():
        for sub in requests_dir.iterdir():
            if sub.is_dir():
                search_dirs.append(sub)
    for search_dir in search_dirs:
        if not search_dir.exists():
            continue
        for json_file in search_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                file_order_id = data.get("orderId") or data.get("id") or json_file.stem
                if file_order_id == order_id:
                    return int(data.get("serializeCount", 0))
            except Exception:
                pass
    return 0


def _get_convergence_retry_count(order_id: str) -> int:
    """Return the current convergenceRetryCount for an order (0 if never retried)."""
    queues_dir = get_queues_dir()
    search_dirs = [
        queues_dir / "orders", queues_dir / "explicit", queues_dir / "high-level",
        queues_dir / "bugs", queues_dir / "defects", queues_dir / "security",
        queues_dir / "breakdown",
    ]
    requests_dir = queues_dir / "requests"
    if requests_dir.exists():
        for sub in requests_dir.iterdir():
            if sub.is_dir():
                search_dirs.append(sub)
    for search_dir in search_dirs:
        if not search_dir.exists():
            continue
        for json_file in search_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                file_order_id = data.get("orderId") or data.get("id") or json_file.stem
                if file_order_id == order_id:
                    return int(data.get("convergenceRetryCount", 0))
            except Exception:
                pass
    return 0


def _requeue_for_convergence_retry(order_id: str, error_detail: str,
                                   salvage: Optional[Dict[str, Any]] = None) -> bool:
    """Re-queue an order as PENDING after a transient convergence network failure (BUG-MSO-2026-0268).

    Called when merge_crew_branch_into_voyage raises ConvergenceNetworkError.
    Increments ``convergenceRetryCount`` and resets status to PENDING so the
    dispatcher will attempt convergence again on the next cycle.

    The salvage branch (holding the crew's committed work) is retained unchanged
    so the retry can converge from it rather than re-running the role. If
    ``convergenceRetryCount`` reaches ``_CONVERGENCE_RETRY_CAP``, the caller
    falls through to ``_record_convergence_failure`` instead.

    Returns True if the order was found and updated.
    """
    queues_dir = get_queues_dir()
    search_dirs = [
        queues_dir / "orders", queues_dir / "explicit", queues_dir / "high-level",
        queues_dir / "bugs", queues_dir / "defects", queues_dir / "security",
        queues_dir / "breakdown",
    ]
    requests_dir = queues_dir / "requests"
    if requests_dir.exists():
        for sub in requests_dir.iterdir():
            if sub.is_dir():
                search_dirs.append(sub)

    for search_dir in search_dirs:
        if not search_dir.exists():
            continue
        for json_file in search_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                file_order_id = data.get("orderId") or data.get("id") or json_file.stem
                if file_order_id != order_id:
                    continue
                data["status"] = "PENDING"
                data["convergenceRetryCount"] = data.get("convergenceRetryCount", 0) + 1
                data["convergenceRetry"] = {
                    "at": datetime.now().isoformat(),
                    "error": error_detail,
                    "salvageBranch": (salvage or {}).get("salvageBranch"),
                    "strandedSha": (salvage or {}).get("strandedSha"),
                }
                data.pop("assignedTo", None)
                tmp = json_file.with_suffix('.tmp')
                tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')
                tmp.replace(json_file)
                # BUG-MSO-2026-0344: release the dispatcher-pid ledger claim —
                # this PENDING requeue is meant to re-dispatch, but a lingering
                # live claim makes scan_all_queues skip it silently.
                order_ledger.record_released(
                    order_id, "convergence-network retry — requeued PENDING",
                    workspace_dir=get_artefact_root())
                return True
            except Exception:
                pass
    return False


def _clear_convergence_retry(order_id: str) -> bool:
    """Remove the convergenceRetry block from an order JSON after a successful fast-convergence.

    BUG-MSO-2026-0273: called by _fast_converge_salvage_branch on success so the
    next role dispatch does not re-fire the salvage fast-path.
    Returns True if the order was found and updated.
    """
    queues_dir = get_queues_dir()
    search_dirs = [
        queues_dir / "orders", queues_dir / "explicit", queues_dir / "high-level",
        queues_dir / "bugs", queues_dir / "defects", queues_dir / "security",
        queues_dir / "breakdown",
    ]
    requests_dir = queues_dir / "requests"
    if requests_dir.exists():
        for sub in requests_dir.iterdir():
            if sub.is_dir():
                search_dirs.append(sub)

    for search_dir in search_dirs:
        if not search_dir.exists():
            continue
        for json_file in search_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                file_order_id = data.get("orderId") or data.get("id") or json_file.stem
                if file_order_id != order_id:
                    continue
                data.pop("convergenceRetry", None)
                tmp = json_file.with_suffix('.tmp')
                tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')
                tmp.replace(json_file)
                return True
            except Exception:
                pass
    return False


def _fast_converge_salvage_branch(order_id: str, salvage_branch: str,
                                   voyage_branch: str, voyage_id: str,
                                   repo_root: Optional[Path] = None,
                                   repo_name: str = "") -> bool:
    """Converge a salvage branch directly into the voyage branch (BUG-MSO-2026-0273).

    Called by dispatch_squad when an order arrives with convergenceRetry.salvageBranch
    set, indicating that a prior crew completed its work but convergence failed transiently.
    Instead of re-running the role from scratch, we merge the salvage branch directly.

    Uses the voyage admin worktree (same as merge_crew_branch_into_voyage).

    FTR-MSO-2026-0378: *repo_root* / *repo_name* run the admin/scratch worktree,
    default-branch guard, and primary-checkout fast-forward against the order's
    product-repo checkout; defaults keep single-repo behaviour byte-identical.

    Returns True  — fast-path took ownership (success, re-queued, or serialized).
    Returns False — salvage branch is absent; caller should fall through to normal dispatch.

    On ConvergenceNetworkError: re-queues the order (cap logic preserved) and returns True.
    On WorktreeContentConflict: auto-serializes and returns True.
    """
    from maestro.core.worktrees import (
        resolve_convergence_worktree,
        WorktreeContentConflict,
        ConvergenceNetworkError,
        WorktreeError,
        _retry_git_network_op,
        _merge_lock,
        _autoresolve_bookkeeping_conflicts,
        _clean_untracked_bookkeeping,
        _parse_untracked_overwrite_paths,
        default_branch_push_guard,
    )

    write_lifecycle_event(
        "CONVERGENCE_RETRY_FROM_SALVAGE",
        f"{order_id}: fast-path convergence of salvage branch '{salvage_branch}' "
        f"into '{voyage_branch}' (voyage={voyage_id})"
    )

    # Resolve admin worktree for merge operations. BUG-MSO-2026-0295: never the
    # primary workspace checkout — a detached scratch worktree is used when the
    # branch is held by the primary tree (on_branch=False → push HEAD:ref).
    try:
        admin_wt, on_branch = resolve_convergence_worktree(
            voyage_id, voyage_branch, repo_root=repo_root, repo_name=repo_name)
    except Exception as exc:
        write_lifecycle_event(
            "WARN",
            f"{order_id}: CONVERGENCE_RETRY_FROM_SALVAGE — worktree prep failed ({exc}); "
            f"falling through to normal role dispatch"
        )
        return False

    _scratch_wt = admin_wt if not on_branch else None
    try:
        _completion_config = load_completion_config()
        _conv_timeout = _completion_config.get("convergenceNetworkTimeout", 60)

        def _run(cmd: list) -> subprocess.CompletedProcess:
            return run_hidden(cmd, capture_output=True, text=True, cwd=str(admin_wt), timeout=60)

        def _run_net(cmd: list, timeout: Optional[int] = None) -> subprocess.CompletedProcess:
            return _retry_git_network_op(
                cmd, cwd=str(admin_wt),
                timeout=timeout if timeout is not None else _conv_timeout,
            )

        def _has_ref(ref: str) -> bool:
            return _run(["git", "rev-parse", "--verify", "--quiet", ref]).returncode == 0

        # BUG-MSO-2026-0273 review: serialize concurrent fast-converges against the
        # same voyage branch — parity with merge_crew_branch_into_voyage's lock.
        # Without this, a normal convergence and a fast-path convergence could race
        # on fetch/reset/merge/push.
        try:
            with _merge_lock:
                # Sync voyage branch to latest remote state.
                _run_net(["git", "fetch", "origin",
                          f"{voyage_branch}:refs/remotes/origin/{voyage_branch}"])

                # Resolve salvage branch — prefer local ref, fall back to origin.
                if _has_ref(f"refs/heads/{salvage_branch}"):
                    merge_target = salvage_branch
                elif _has_ref(f"refs/remotes/origin/{salvage_branch}"):
                    merge_target = f"origin/{salvage_branch}"
                else:
                    # Try fetching from origin.
                    try:
                        _run_net(["git", "fetch", "origin",
                                  f"{salvage_branch}:refs/remotes/origin/{salvage_branch}"])
                    except ConvergenceNetworkError:
                        raise  # transient — let the outer handler re-queue
                    if _has_ref(f"refs/remotes/origin/{salvage_branch}"):
                        merge_target = f"origin/{salvage_branch}"
                    else:
                        # Salvage branch is gone — fall through to normal role re-run.
                        write_lifecycle_event(
                            "WARN",
                            f"{order_id}: CONVERGENCE_RETRY_FROM_SALVAGE — salvage branch "
                            f"'{salvage_branch}' not found locally or on origin; "
                            f"falling through to normal role re-run"
                        )
                        return False

                # Reset admin worktree to latest voyage tip.
                reset_r = _run(["git", "reset", "--hard", f"origin/{voyage_branch}"])
                if reset_r.returncode != 0:
                    raise WorktreeError(
                        f"git reset --hard origin/{voyage_branch} failed: {reset_r.stderr.strip()}"
                    )

                # BUG-MSO-2026-0343: reset --hard leaves untracked telemetry
                # from prior convergence attempts behind (e.g. .mso/usage/
                # orders/<order>.json) — it would block the merge with
                # "untracked working tree files would be overwritten".
                _swept = _clean_untracked_bookkeeping(_run)
                if _swept:
                    write_lifecycle_event(
                        "CONVERGENCE_UNTRACKED_CLEANED",
                        f"{order_id}: fast-converge removed untracked bookkeeping/"
                        f"telemetry leftover(s) from the voyage worktree before "
                        f"merge: {', '.join(_swept)} — BUG-0343"
                    )

                # Merge salvage branch --no-ff to preserve history.
                merge_r = _run([
                    "git", "merge", "--no-ff", merge_target,
                    "-m",
                    f"convergence: fast-converge salvage '{salvage_branch}' into "
                    f"{voyage_branch} ({order_id})",
                ])
                if merge_r.returncode != 0:
                    conflicts_r = _run(["git", "diff", "--name-only", "--diff-filter=U"])
                    conflict_files = [f for f in conflicts_r.stdout.splitlines() if f.strip()]
                    _detail = (merge_r.stdout.strip() + " " + merge_r.stderr.strip()).strip()
                    # BUG-MSO-2026-0342: the fast path previously escalated EVERY
                    # conflict — including ones confined to dispatcher bookkeeping /
                    # crew telemetry. Apply the same BUG-0308/0342 auto-resolve as
                    # merge_crew_branch_into_voyage.
                    _bk_status, _bk_files = _autoresolve_bookkeeping_conflicts(
                        _run, conflict_files)
                    if _bk_status == "resolved":
                        write_lifecycle_event(
                            "CONVERGENCE_BOOKKEEPING_AUTORESOLVED",
                            f"{order_id}: fast-converge of '{salvage_branch}' auto-resolved "
                            f"bookkeeping/telemetry conflict(s): {', '.join(_bk_files)} — "
                            f"control-plane kept the voyage (dispatcher) copy, crew "
                            f"telemetry kept the crew copy — BUG-0308/BUG-0342"
                        )
                        # fall through to the push step below (merge completed)
                    elif _bk_status == "commit_failed":
                        _run(["git", "merge", "--abort"])
                        raise WorktreeError(
                            f"Fast-converge of '{salvage_branch}' into '{voyage_branch}': "
                            f"bookkeeping auto-resolve failed to commit. git: "
                            f"{_bk_files[0] if _bk_files else ''}"
                        )
                    else:
                        _run(["git", "merge", "--abort"])
                        # BUG-MSO-2026-0343: no index conflicts → likely git
                        # refusing to start over untracked working-tree files.
                        # Name the actual blocking paths instead of "unknown".
                        if not conflict_files:
                            _untracked = _parse_untracked_overwrite_paths(_detail)
                            if _untracked:
                                raise WorktreeError(
                                    f"Fast-converge of '{salvage_branch}' into "
                                    f"'{voyage_branch}' blocked by untracked files in "
                                    f"the voyage worktree: {', '.join(_untracked)}. "
                                    f"git: {_detail}"
                                )
                        # BUG-MSO-2026-0342: report ONLY genuine source conflicts.
                        report_files = _bk_files or conflict_files
                        _files = ", ".join(report_files) if report_files else "unknown"
                        if conflict_files:
                            raise WorktreeContentConflict(
                                f"Fast-converge of '{salvage_branch}' into '{voyage_branch}' "
                                f"failed (content conflict). Conflicting files: {_files}. git: {_detail}",
                                conflict_files=report_files,
                            )
                        raise WorktreeError(
                            f"Fast-converge of '{salvage_branch}' into '{voyage_branch}' "
                            f"failed: {_detail}"
                        )

                # Push merged voyage branch. BUG-MSO-2026-0273 review (parity with
                # BUG-MSO-2026-0272): pushes upload pack data and need a longer
                # ceiling than fetches; use 2x convergence_timeout to match the
                # behaviour of merge_crew_branch_into_voyage's push.
                # BUG-MSO-2026-0295: detached scratch worktree pushes HEAD:ref.
                # BUG-MSO-2026-0347: never auto-push the remote default branch.
                if not default_branch_push_guard(
                        voyage_branch,
                        f"{order_id}: fast-converge of {salvage_branch}",
                        repo_dir=admin_wt):
                    raise WorktreeError(
                        f"Fast-converge of '{salvage_branch}' refused: voyage "
                        f"branch '{voyage_branch}' is the remote default branch "
                        f"— Maestro never auto-pushes the default branch "
                        f"(BUG-MSO-2026-0347)."
                    )
                _push_ref = voyage_branch if on_branch else f"HEAD:refs/heads/{voyage_branch}"
                _run_net(["git", "push", "origin", _push_ref],
                         timeout=2 * _conv_timeout)
                if not on_branch:
                    from maestro.core.worktrees import safe_ff_primary_checkout
                    _run(["git", "fetch", "origin",
                          f"{voyage_branch}:refs/remotes/origin/{voyage_branch}"])
                    safe_ff_primary_checkout(voyage_branch, repo_root=repo_root)

        except ConvergenceNetworkError as net_exc:
            # FTR-MSO-2026-0359: convergence network failures arm the offline
            # dispatch gate too (they already have their own retry cap separate
            # from MAX_REQUEUES — aligned with the NETWORK-retry policy).
            _note_network_suspect(f"{order_id} ConvergenceNetworkError (fast-converge)")
            _retry_count = _get_convergence_retry_count(order_id)
            if _retry_count < _CONVERGENCE_RETRY_CAP:
                _requeue_for_convergence_retry(
                    order_id, str(net_exc),
                    salvage={"salvageBranch": salvage_branch}
                )
                write_lifecycle_event(
                    "CONVERGENCE_RETRY",
                    f"{order_id}: CONVERGENCE_RETRY_FROM_SALVAGE network failure "
                    f"(attempt {_retry_count + 1}/{_CONVERGENCE_RETRY_CAP}). "
                    f"Re-queued PENDING. Salvage: {salvage_branch}. Error: {net_exc}"
                )
            else:
                _record_convergence_failure(
                    order_id, str(net_exc),
                    salvage={"salvageBranch": salvage_branch}
                )
                write_lifecycle_event(
                    "ERROR",
                    f"{order_id}: CONVERGENCE_RETRY_FROM_SALVAGE cap ({_CONVERGENCE_RETRY_CAP}) "
                    f"reached — CONVERGENCE_FAILED. Salvage: {salvage_branch}"
                )
            return True

        except WorktreeContentConflict as conflict_exc:
            _serialize_count = _get_serialize_count_for_order(order_id)
            if _serialize_count < _AUTO_SERIALIZE_CAP:
                _auto_serialize_order(
                    order_id, conflict_exc.conflict_files,
                    salvage={"salvageBranch": salvage_branch}
                )
                write_lifecycle_event(
                    "CONVERGENCE_RETRY",
                    f"{order_id}: CONVERGENCE_RETRY_FROM_SALVAGE content conflict — "
                    f"auto-serializing (attempt {_serialize_count + 1}/{_AUTO_SERIALIZE_CAP}). "
                    f"Salvage: {salvage_branch}"
                )
            else:
                _record_convergence_failure(
                    order_id, str(conflict_exc),
                    salvage={"salvageBranch": salvage_branch}
                )
                write_lifecycle_event(
                    "ERROR",
                    f"{order_id}: CONVERGENCE_RETRY_FROM_SALVAGE serialize cap reached — "
                    f"CONVERGENCE_FAILED. Salvage: {salvage_branch}"
                )
            return True

        except Exception as exc:
            write_lifecycle_event(
                "WARN",
                f"{order_id}: CONVERGENCE_RETRY_FROM_SALVAGE unexpected error ({exc}); "
                f"falling through to normal role re-run"
            )
            return False

        # SUCCESS: clear convergenceRetry so the next role dispatch is clean.
        _clear_convergence_retry(order_id)
        write_lifecycle_event(
            "CONVERGENCE_RETRY_FROM_SALVAGE",
            f"{order_id}: fast-convergence SUCCESS — salvage '{salvage_branch}' merged "
            f"into '{voyage_branch}'; convergenceRetry cleared. Advancing order."
        )

        # Advance the order to the next role (same logic as normal COMPLETE finalization).
        try:
            complete_order(order_id, 0, {"status": "COMPLETE", "role": "", "orderId": order_id})
            auto_queue_unblocked_orders(order_id)
        except Exception as adv_exc:
            write_lifecycle_event(
                "WARN",
                f"{order_id}: CONVERGENCE_RETRY_FROM_SALVAGE — advance/unblock failed: {adv_exc}"
            )

        return True
    finally:
        # BUG-MSO-2026-0306: tear down the scratch worktree after the salvage
        # convergence so the next role's convergence cannot collide.
        if _scratch_wt is not None:
            from maestro.core.worktrees import cleanup_convergence_worktree
            cleanup_convergence_worktree(_scratch_wt, repo_root=repo_root)


def complete_order(order_id: str, crew_num: int, crew_state: Dict[str, Any]):
    """Mark an order as COMPLETE and archive it out of the active queue.

    Lifecycle: PENDING -> IN_PROGRESS -> COMPLETE (archived)
    Searches queue directories first, then falls back to orders/active/.
    v8.5: Also archives from orders/active/ to fix dependency resolution
    when queue file is missing (e.g., cleaned up or pipe-hang scenario).
    """
    queues_dir = get_queues_dir()
    admiralty_dir = get_artefact_root()

    # BUG-MSO-2026-0219: if the order is already parked for human review
    # (plan-approval hold, NAV_REVIEW_PENDING), a SECOND completion call must NOT
    # fabricate a COMPLETE archive entry — that would defeat the review gate and
    # prematurely unblock dependents. Treat as already-handled and return.
    if (admiralty_dir / "queues" / "review" / f"{order_id}.json").exists():
        write_lifecycle_event(
            "WARN",
            f"{order_id} already held in queues/review/ — skipping duplicate completion (Crew {crew_num})"
        )
        return

    # BUG-MSO-2026-0024: any completion (advance, archive, or sweep) may unblock a
    # dependent the dispatcher hasn't re-scanned yet — refresh the Eight Bells grace clock.
    _mark_order_terminal_now()

    archive_dir = admiralty_dir / "orders" / "complete"
    archive_dir.mkdir(parents=True, exist_ok=True)

    completion_metadata = {
        "status": "COMPLETE",
        "completedAt": datetime.now().isoformat(),
        "completedBy": {
            "crew": crew_num,
            "role": crew_state.get("role", "UNK"),
            "iterations": crew_state.get("iteration", 0),
            "startTime": crew_state.get("startTime", ""),
            "endTime": crew_state.get("endTime", "")
        }
    }

    # v7.0: Search ALL queue directories
    search_dirs = [
        queues_dir / "orders", queues_dir / "explicit", queues_dir / "high-level",
        queues_dir / "bugs", queues_dir / "defects", queues_dir / "security",
        queues_dir / "breakdown",
    ]
    # Also search all request subdirectories
    requests_dir = queues_dir / "requests"
    if requests_dir.exists():
        for sub in requests_dir.iterdir():
            if sub.is_dir():
                search_dirs.append(sub)

    found_in_queue = False
    for search_dir in search_dirs:
        if not search_dir.exists():
            continue
        for json_file in search_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                file_order_id = data.get("orderId") or data.get("id") or json_file.stem
                if file_order_id != order_id:
                    continue

                # BUG-MSO-2026-0236: extract completed_role before the status==COMPLETE
                # branch so we can check roleSequence in BOTH paths.
                completed_role = crew_state.get("role", "")

                # v8.9: If the queue file already has status=COMPLETE, it was
                # written by the crew but not yet moved to archive (e.g. due to
                # timing or a prior unlink failure).
                # BUG-MSO-2026-0236: MUST check roleSequence before archiving —
                # if the completed role is non-final, ADVANCE instead of archiving
                # so subsequent roles (TST, DOC, …) are not silently skipped.
                if data.get("status") == "COMPLETE":
                    # BUG-MSO-2026-0546: refuse to advance/archive completed_role's
                    # completion as a success if it left no deliverable behind.
                    if _check_role_deliverable_gate(order_id, data, completed_role,
                                                    json_file, admiralty_dir, crew_num):
                        found_in_queue = True
                        break

                    meta_c = data.get("_meta", {})
                    order_type_c = data.get("orderType") or data.get("type", "")
                    sequence_c = (
                        data.get("roleSequence")
                        or meta_c.get("roleSequence")
                        or ROLE_SEQUENCES.get(order_type_c, [])
                    )
                    next_role_c = None
                    if sequence_c and completed_role in sequence_c:
                        idx_c = sequence_c.index(completed_role)
                        if idx_c + 1 < len(sequence_c):
                            next_role_c = sequence_c[idx_c + 1]

                    if next_role_c:
                        # Non-final role — advance rather than archive
                        # BUG-MSO-2026-0248: arm transition gate BEFORE writing the file so
                        # scan_all_queues can never see a PENDING item that isn't gated yet.
                        ORDERS_IN_TRANSITION.add(order_id)
                        data["status"] = "PENDING"
                        data["targetRole"] = next_role_c
                        data.pop("assignedTo", None)
                        data.pop("startedAt", None)
                        json_file.write_text(json.dumps(data, indent=2), encoding='utf-8')
                        found_in_queue = True
                        print_ok(
                            f"Order {order_id} COMPLETE-in-queue {completed_role} "
                            f"-> advancing to {next_role_c} (BUG-0236)"
                        )
                        write_lifecycle_event(
                            "ADVANCE",
                            f"{order_id} COMPLETE-in-queue {completed_role} -> {next_role_c} "
                            f"(Crew {crew_num}, BUG-0236)"
                        )
                        ring_crew_bell(crew_num, order_id)
                    else:
                        # BUG-MSO-2026-0401: SEC finalization gate — an order whose
                        # roleSequence includes SEC cannot be archived COMPLETE
                        # without a SEC review artefact. Hold + requeue @SEC instead.
                        _sec_role_c = _sequence_sec_role(sequence_c)
                        if _sec_role_c and not sec_artefact_present(order_id, data, get_artefact_root()):
                            _hold_missing_sec_artefact(
                                order_id, data, _sec_role_c, json_file,
                                completed_role, get_artefact_root(), crew_num)
                            found_in_queue = True
                            break
                        # Final role (or no sequence) — archive as COMPLETE
                        data.update(completion_metadata)
                        archive_file = archive_dir / json_file.name
                        archive_file.write_text(json.dumps(data, indent=2), encoding='utf-8')
                        json_file.unlink()
                        found_in_queue = True
                        print_ok(f"Order {order_id} already COMPLETE in queue -> swept to archive")
                        write_lifecycle_event("COMPLETE", f"{order_id} swept to archive from queue (Crew {crew_num})")
                        ring_crew_bell(crew_num, order_id)
                    break

                # Found the order in queue — check role sequence before archiving
                # (completed_role already extracted above, before the COMPLETE branch)

                # Idempotency guard: if the order was already advanced past completed_role
                # (status=PENDING waiting for dispatch, or status=IN_PROGRESS already claimed
                # by another crew), a stale complete_order call must not overwrite it.
                # BUG-MSO-2026-0015: original guard covered PENDING only.
                # BUG-MSO-2026-0248: extend to IN_PROGRESS — without this, a late BLD
                # complete_order would overwrite an already-dispatched IN_PROGRESS@TST order
                # back to PENDING@TST, causing a second crew to be dispatched for the same role.
                if data.get("status") in ("PENDING", "IN_PROGRESS") and data.get("targetRole") and data.get("targetRole") != completed_role:
                    # PSG bug 3 (advance-loss loop): a mismatch can mean the FILE
                    # was rewound BEHIND the crew, not that the crew is stale. The
                    # ledger's durable role progression disambiguates: if it confirms
                    # completed_role is the order's current role, the completion is
                    # legitimate — heal the file and fall through to the advance.
                    _ledger_role = order_ledger.load_view(get_artefact_root()).current_role(order_id)
                    if _ledger_role == completed_role:
                        write_lifecycle_event(
                            "WARN",
                            f"{order_id} file says {data['targetRole']} but ledger confirms "
                            f"{completed_role} is current — file was rewound; accepting "
                            f"completion and healing (BUG-0248 advance-loss)"
                        )
                        data["targetRole"] = completed_role
                    else:
                        print_info(f"Order {order_id} already past {completed_role} -> {data['targetRole']} (status={data.get('status')}, skipping stale completion)")
                        write_lifecycle_event("WARN", f"{order_id} stale complete_order call for {completed_role} ignored — already at {data['targetRole']} status={data.get('status')} (BUG-0248)")
                        found_in_queue = True
                        break

                # BUG-MSO-2026-0546: refuse to advance/archive completed_role's
                # completion as a success if it left no deliverable behind — run
                # AFTER the idempotency guard above so a stale/duplicate
                # completion call is skipped on its own terms rather than
                # re-evaluated against a role that isn't actually current.
                if _check_role_deliverable_gate(order_id, data, completed_role,
                                                json_file, admiralty_dir, crew_num):
                    found_in_queue = True
                    break

                meta = data.get("_meta", {})
                order_type = data.get("orderType") or data.get("type", "")
                sequence = (
                    data.get("roleSequence")
                    or meta.get("roleSequence")
                    or ROLE_SEQUENCES.get(order_type, [])
                )
                next_role = None
                if sequence and completed_role in sequence:
                    idx = sequence.index(completed_role)
                    if idx + 1 < len(sequence):
                        next_role = sequence[idx + 1]

                if next_role:
                    # FTR-MSO-2026-0427: per-transition human review gate. Was
                    # post-PLN-only (BUG-MSO-2026-0205 matched the legacy NAV alias);
                    # now ANY transition gates.json names can pause here, with the
                    # legacy post_nav_review key still governing planning exits.
                    if _maybe_hold_transition_for_review(
                        data, json_file, get_artefact_root() / "queues" / "review",
                        completed_role, next_role, crew_num, order_id, get_artefact_root(),
                    ):
                        found_in_queue = True
                        break

                    # Not the final role — advance to next role and re-queue
                    # BUG-MSO-2026-0248: arm transition gate BEFORE writing the file.
                    ORDERS_IN_TRANSITION.add(order_id)
                    data["status"] = "PENDING"
                    data["targetRole"] = next_role
                    data.pop("assignedTo", None)
                    data.pop("startedAt", None)
                    json_file.write_text(json.dumps(data, indent=2), encoding='utf-8')
                    found_in_queue = True
                    # BUG-MSO-2026-0294: clear the durable claim so the next
                    # role's dispatch isn't vetoed as in-flight. The ADVANCED
                    # event also records the role progression (PSG bug 3).
                    order_ledger.record_advanced(order_id, completed_role, next_role,
                                                  workspace_dir=get_artefact_root())
                    # BUG-MSO-2026-0295: put the advance in history so a rewind
                    # can't revert the role (the PSG PLN<->BLD loop vector).
                    _commit_lifecycle_transition(
                        [json_file],
                        f"lifecycle: advance {order_id} {completed_role} -> {next_role}",
                    )
                    print_ok(f"Order {order_id} {completed_role} complete -> advancing to {next_role}")
                    write_lifecycle_event("ADVANCE", f"{order_id} {completed_role} complete -> {next_role} (Crew {crew_num})")
                    ring_crew_bell(crew_num, order_id)
                else:
                    # BUG-MSO-2026-0205: a standalone planning order ([PLN] with no next
                    # role) must still pause for human plan-approval when the gate is on,
                    # so its dependent FTR/BLD orders don't dispatch unreviewed.
                    if _maybe_hold_plan_for_review(data, json_file, completed_role, crew_num, order_id, get_artefact_root()):
                        found_in_queue = True
                        break
                    # BUG-MSO-2026-0401: SEC finalization gate — refuse to archive a
                    # SEC-in-sequence order COMPLETE without a review artefact.
                    _sec_role = _sequence_sec_role(sequence)
                    if _sec_role and not sec_artefact_present(order_id, data, get_artefact_root()):
                        _hold_missing_sec_artefact(
                            order_id, data, _sec_role, json_file,
                            completed_role, get_artefact_root(), crew_num)
                        found_in_queue = True
                        break
                    # Final role — archive as COMPLETE
                    data.update(completion_metadata)
                    archive_file = archive_dir / json_file.name
                    archive_file.write_text(json.dumps(data, indent=2), encoding='utf-8')
                    json_file.unlink()
                    found_in_queue = True
                    # BUG-MSO-2026-0294: durable TERMINAL — survives any git rewind.
                    order_ledger.record_terminal(order_id, "COMPLETE", workspace_dir=get_artefact_root())
                    # BUG-MSO-2026-0295: commit the archive transition so git
                    # history carries the truth (best-effort, config-gated).
                    _commit_lifecycle_transition(
                        [archive_file, json_file],
                        f"lifecycle: archive {order_id} (COMPLETE)",
                    )
                    print_ok(f"Order {order_id} COMPLETE -> archived to orders/complete/")
                    write_lifecycle_event("COMPLETE", f"{order_id} COMPLETE -> archived (Crew {crew_num})")
                    ring_crew_bell(crew_num, order_id)
                break

            except Exception as e:
                print_warn(f"Error processing {json_file}: {e}")
        if found_in_queue:
            break

    # v8.5: Also archive from orders/active/ to orders/complete/
    # This ensures dependency resolution works even if the queue file was
    # already cleaned up (pipe-hang scenario, manual cleanup, etc.)
    active_dir = admiralty_dir / "orders" / "active"
    active_file = active_dir / f"{order_id}.json"
    if active_file.exists():
        try:
            data = json.loads(active_file.read_text(encoding='utf-8'))
            if not found_in_queue:
                # Apply same advance-vs-archive logic as queue path
                completed_role = crew_state.get("role", "")

                # BUG-MSO-2026-0546: same deliverable gate as the queue path above.
                if _check_role_deliverable_gate(order_id, data, completed_role,
                                                active_file, admiralty_dir, crew_num):
                    return True

                meta = data.get("_meta", {})
                order_type = data.get("orderType") or data.get("type", "")
                sequence = (
                    data.get("roleSequence")
                    or meta.get("roleSequence")
                    or ROLE_SEQUENCES.get(order_type, [])
                )
                next_role = None
                if sequence and completed_role in sequence:
                    idx = sequence.index(completed_role)
                    if idx + 1 < len(sequence):
                        next_role = sequence[idx + 1]

                if next_role:
                    # FTR-MSO-2026-0427: per-transition human review gate (v8.5
                    # orders/active fallback path — same engine as the queue path).
                    if _maybe_hold_transition_for_review(
                        data, active_file, admiralty_dir / "queues" / "review",
                        completed_role, next_role, crew_num, order_id, admiralty_dir,
                        context="v8.5 fallback from active",
                    ):
                        return True

                    # Not the final role — move back to queue at next role
                    # BUG-MSO-2026-0248: arm transition gate BEFORE writing the file.
                    ORDERS_IN_TRANSITION.add(order_id)
                    queue_dir = admiralty_dir / "queues" / "orders"
                    queue_dir.mkdir(parents=True, exist_ok=True)
                    data["status"] = "PENDING"
                    data["targetRole"] = next_role
                    data.pop("assignedTo", None)
                    data.pop("startedAt", None)
                    queue_file = queue_dir / active_file.name
                    queue_file.write_text(json.dumps(data, indent=2), encoding='utf-8')
                    active_file.unlink()
                    order_ledger.record_advanced(order_id, completed_role, next_role, workspace_dir=admiralty_dir)  # BUG-MSO-2026-0294
                    _commit_lifecycle_transition(  # BUG-MSO-2026-0295 / PSG bug 3
                        [queue_file, active_file],
                        f"lifecycle: advance {order_id} {completed_role} -> {next_role}",
                    )
                    print_ok(f"Order {order_id} {completed_role} complete -> advancing to {next_role} (v8.5 fallback)")
                    write_lifecycle_event("ADVANCE", f"{order_id} {completed_role} -> {next_role} from active (Crew {crew_num}, v8.5)")
                    ring_crew_bell(crew_num, order_id)
                else:
                    # BUG-MSO-2026-0205: standalone planning order — hold for plan approval.
                    if _maybe_hold_plan_for_review(data, active_file, completed_role, crew_num, order_id, admiralty_dir):
                        return True
                    # BUG-MSO-2026-0401: SEC finalization gate (v8.5 fallback path).
                    _sec_role = _sequence_sec_role(sequence)
                    if _sec_role and not sec_artefact_present(order_id, data, admiralty_dir):
                        _hold_missing_sec_artefact(
                            order_id, data, _sec_role, active_file,
                            completed_role, admiralty_dir, crew_num)
                        return True
                    data.update(completion_metadata)
                    archive_file = archive_dir / active_file.name
                    archive_file.write_text(json.dumps(data, indent=2), encoding='utf-8')
                    active_file.unlink()
                    order_ledger.record_terminal(order_id, "COMPLETE", workspace_dir=admiralty_dir)  # BUG-MSO-2026-0294
                    _commit_lifecycle_transition(
                        [archive_file, active_file],
                        f"lifecycle: archive {order_id} (COMPLETE)",
                    )
                    print_ok(f"Order {order_id} COMPLETE -> archived from orders/active/ (v8.5 fallback)")
                    write_lifecycle_event("COMPLETE", f"{order_id} COMPLETE -> archived from active (Crew {crew_num}, v8.5)")
                    ring_crew_bell(crew_num, order_id)
            else:
                # Queue path already handled it — just clean up active copy if present
                active_file.unlink(missing_ok=True)
        except Exception as e:
            print_warn(f"Error archiving {order_id} from active: {e}")
        return True

    if found_in_queue:
        return True

    # v8.7: Check if already archived (e.g., pipe-hang fix already processed it)
    archive_check = archive_dir / f"{order_id}.json"
    if archive_check.exists():
        return True

    # BUG-MSO-2026-0219 (defense in depth): never synthesize a COMPLETE stub for an
    # order that is parked in review (plan-approval hold). It is not 'missing' — it is
    # deliberately held, and a COMPLETE stub here would unblock its dependents.
    if (admiralty_dir / "queues" / "review" / f"{order_id}.json").exists():
        return True

    # v8.5: Log warning when order not found anywhere
    print_warn(f"Order {order_id} not found in queues or active — creating archive entry from crew state")
    write_lifecycle_event("WARN", f"Order {order_id} not found in queues/active — synthesized archive entry (Crew {crew_num}, v8.5)")
    # Last resort: create a minimal archive entry so dependencies resolve
    archive_file = archive_dir / f"{order_id}.json"
    if not archive_file.exists():
        minimal_data = {"orderId": order_id, "id": order_id}
        minimal_data.update(completion_metadata)
        archive_file.write_text(json.dumps(minimal_data, indent=2), encoding='utf-8')
    ring_crew_bell(crew_num, order_id)
    return True


def process_crew_completion(crew_num: int):
    """Process a crew that has finished (COMPLETE, BLOCKED, ERROR, CRASHED, etc).

    v7.1: Handles ALL terminal states including AUTH_ERROR and INTERRUPTED.
    v2.0.0: Added post-completion repo verification, per-crew PR creation, and cleanup.

    Handles the full lifecycle:
    - COMPLETE: Verify+push, create PR, archive the order
    - CRASHED/ERROR/TIMEOUT/AUTH_ERROR/INTERRUPTED: Verify+push, re-queue for retry
    - BLOCKED/MAX_ITERATIONS/CIRCUIT_BREAKER: Verify+push, archive with failure status
    """
    state = read_crew_state(crew_num)
    if not state:
        return

    status = state.get("status", "")
    order_id = state.get("orderId", "")
    if not order_id:
        return

    # BUG-MSO-2026-0236: extract completed_role early so the single-flight guard
    # (below) can reference it regardless of whether target_repo/voyage_branch are set.
    completed_role = state.get("role", "")

    # BUG-MSO-2026-0459: catch a missing SEC artefact AT ROLE COMPLETION — before
    # the local verify gate and convergence/push run — rather than letting the
    # crew "succeed" and only discovering the gap when the order's FINAL role
    # archives (complete_order()'s BUG-0401 gate, still intact as a backstop).
    # No-op (returns False immediately) for every non-SEC role.
    if status == "COMPLETE" and _check_sec_gate_at_role_completion(
            order_id, completed_role, crew_num):
        return

    # v2.0.0: Post-completion repo verification (for ALL terminal states)
    target_repo = _get_target_repo_for_order(order_id)
    # v2.0.1: Per-order voyage branch resolution
    voyage_branch = _get_voyage_branch_for_order(order_id) or ACTIVE_VOYAGE_BRANCH

    if target_repo and voyage_branch:
        # Create/update PR on successful completion
        # BUG-ADM-2026-0013: pass project_acronym so create_pr_for_crew can
        # resolve the base branch from project registry (PSG → master).
        if status == "COMPLETE":
            # BUG-MSO-2026-0266: idempotency guard for the final-role convergence path.
            # If the order is already archived to orders/complete/, a duplicate
            # process_crew_completion call must not re-attempt convergence (crew branch
            # is already consumed/deleted — would raise REF_MISSING + spurious ESCALATE).
            _archive_check = get_artefact_root() / "orders" / "complete" / f"{order_id}.json"
            if _archive_check.exists():
                write_lifecycle_event(
                    "WARN",
                    f"{order_id} already archived COMPLETE — skipping duplicate "
                    f"process_crew_completion (Crew {crew_num}, BUG-0266)"
                )
                return

            # BUG-MSO-2026-0222: write crash-safe checkpoint before any blocking call.
            # If the dispatcher dies between here and the ADVANCE/archive write,
            # reset_orphaned_in_progress_orders() will resume finalization on restart.
            _mark_role_succeeded(order_id, completed_role, crew_num)

            # BUG-MSO-2026-0240: merge per-crew branch into voyage branch so the
            # voyage branch PR reflects the crew's work BEFORE create_pr_for_crew.
            _voyage_id = _get_voyage_id_for_order(order_id)
            # BUG-MSO-2026-0268: load completion config once so convergence_timeout
            # is available inside the try/except block below.
            _completion_config = load_completion_config()
            # FTR-MSO-2026-0378 (plan §4.3.5): resolve the order's product-repo
            # context ONCE so convergence, salvage, and the verify gate all run
            # against the RIGHT checkout / per-repo worktree. Single-repo /
            # embedded workspaces get (None, "") — byte-identical convergence.
            _repo_root_cc, _repo_name_cc = _repo_ctx_for_order(
                order_id, target_repo=target_repo,
                project_acronym=(state.get("project")
                                 or _get_project_for_order(order_id) or ""))
            if _voyage_id:
                try:
                    from maestro.core.worktrees import (
                        merge_crew_branch_into_voyage,
                        cleanup_crew_worktree,
                        commit_crew_worktree_if_dirty,
                        crew_worktree_path_for,
                        preserve_failed_crew_branch,
                    )
                    # BUG-MSO-2026-0284: a crew may finish (subtype=success) having
                    # WRITTEN artefacts (e.g. a PLN plan) but never run `git commit`.
                    # Convergence merges the crew BRANCH, so uncommitted worktree
                    # changes would be silently lost. Auto-commit them onto the crew
                    # branch FIRST so the merge below actually captures the work.
                    if commit_crew_worktree_if_dirty(
                            _voyage_id, crew_num, order_id, repo_name=_repo_name_cc,
                            voyage_branch=voyage_branch):
                        write_lifecycle_event(
                            "FINALIZE",
                            f"{order_id} auto-committed uncommitted crew artefacts "
                            f"before convergence (Crew {crew_num}, BUG-0284)"
                        )
                    # FTR-MSO-2026-0287 (R2): local verify gate. Run the project
                    # verifyCommand in the crew worktree BEFORE pushing. If it
                    # fails, hold the order (VERIFY_FAILED) and do NOT converge/
                    # push — so a broken build never reaches the remote and never
                    # spends a CI run. Empty verifyCommand = gate disabled.
                    # FTR-MSO-2026-0378: per-repo verifyCommand (repos-map entry
                    # overrides the workspace default) runs in the per-repo crew
                    # worktree.
                    _verify_cfg = load_verify_config_for_repo(target_repo)
                    # BUG-MSO-2026-0404: fold a frontend tsc/vitest step into the
                    # gate when the crew touched an npm package (e.g. maestro-hub/)
                    # so CI's separate typecheck job can't fail on something the
                    # local gate never ran. No-op for Python-only orders.
                    _wt = crew_worktree_path_for(_voyage_id, crew_num, _repo_name_cc)
                    _changed_paths = get_changed_paths(_wt, voyage_branch)
                    _verify_cfg = resolve_verify_config_for_paths(
                        _wt, _verify_cfg, _changed_paths)
                    if _verify_cfg["command"]:
                        _ok, _vdetail, _log_path = run_verify_gate(
                            _wt, _verify_cfg["command"], _verify_cfg["timeoutMinutes"],
                            order_id=order_id,
                        )
                        if not _ok:
                            _salvage = None
                            try:
                                _salvage = preserve_failed_crew_branch(
                                    _voyage_id, crew_num, order_id,
                                    repo_root=_repo_root_cc, repo_name=_repo_name_cc)
                            except Exception:
                                pass
                            _record_verify_failure(order_id, _vdetail, _salvage, _log_path)
                            _salvage_ref = (_salvage or {}).get("salvageBranch", "<none>")
                            # BUG-MSO-2026-0506: the log path is placed BEFORE the
                            # (unbounded-looking) excerpt so it survives
                            # sanitize_lifecycle_message's truncation regardless of
                            # excerpt length — an operator/LEAD must always be able
                            # to reach the full output from the event line.
                            _log_note = f"Full log: {_log_path}" if _log_path else "Full log: <not persisted>"
                            write_lifecycle_event(
                                "VERIFY_FAILED",
                                f"{order_id} local verify gate FAILED — NOT converged/"
                                f"pushed (no CI spent). {_log_note}. Work preserved on "
                                f"{_salvage_ref}. Crew {crew_num}. Detail: {_vdetail}"
                            )
                            print_warn(
                                f"Crew {crew_num}: {order_id} verify gate failed — held "
                                f"VERIFY_FAILED (not pushed). Recover from {_salvage_ref}."
                            )
                            return
                        write_lifecycle_event(
                            "VERIFY_OK",
                            f"{order_id} local verify gate passed (Crew {crew_num}) — "
                            f"proceeding to convergence"
                        )
                    write_lifecycle_event(
                        "DISPATCH",
                        f"Crew {crew_num}: merging crew branch into {voyage_branch} "
                        f"(voyage={_voyage_id})"
                    )
                    # BUG-MSO-2026-0268: load convergence_timeout from workspace config
                    # so operators can tune it via workspace.json or --convergence-timeout.
                    _conv_timeout = _completion_config.get("convergenceNetworkTimeout", 60)
                    merge_crew_branch_into_voyage(
                        _voyage_id, crew_num, voyage_branch, order_id=order_id,
                        convergence_timeout=_conv_timeout,
                        repo_root=_repo_root_cc, repo_name=_repo_name_cc,
                    )
                    cleanup_crew_worktree(_voyage_id, crew_num,
                                          repo_root=_repo_root_cc, repo_name=_repo_name_cc)
                except Exception as _merge_exc:
                    # BUG-MSO-2026-0244: convergence FAILURE must GATE completion — the
                    # crew's work is not on the voyage branch, so the order is NOT done.
                    # Preserve the stranded branch for recovery, mark the order
                    # CONVERGENCE_FAILED, ESCALATE, and RETURN without creating a PR or
                    # archiving. BUG-MSO-2026-0243: preserving + slot-freeing here also
                    # stops the stale crew worktree from wedging the next dispatch.
                    from maestro.core.worktrees import (
                        preserve_failed_crew_branch,
                        WorktreeContentConflict,
                        ConvergenceNetworkError,
                    )
                    _salvage = None
                    try:
                        _salvage = preserve_failed_crew_branch(
                            _voyage_id, crew_num, order_id,
                            repo_root=_repo_root_cc, repo_name=_repo_name_cc)
                    except Exception:
                        pass

                    # BUG-MSO-2026-0268: RETRYABLE path — transient network/timeout failure.
                    # Re-queue as PENDING for a convergence-only retry; the role's work is
                    # intact on the salvage branch. Dispatcher does NOT idle.
                    if isinstance(_merge_exc, ConvergenceNetworkError):
                        # FTR-MSO-2026-0359: arm the offline dispatch gate — a
                        # convergence network failure is the same outage signal
                        # as a NETWORK crew death.
                        _note_network_suspect(f"{order_id} ConvergenceNetworkError (Crew {crew_num})")
                        _retry_count = _get_convergence_retry_count(order_id)
                        if _retry_count < _CONVERGENCE_RETRY_CAP:
                            _requeued = _requeue_for_convergence_retry(
                                order_id, str(_merge_exc), salvage=_salvage
                            )
                            _salvage_ref = (_salvage or {}).get("salvageBranch", "<none>")
                            write_lifecycle_event(
                                "CONVERGENCE_RETRY",
                                f"{order_id} re-queued PENDING after transient convergence "
                                f"network failure (attempt {_retry_count + 1}/{_CONVERGENCE_RETRY_CAP}). "
                                f"Salvage: {_salvage_ref}. Crew {crew_num}. Error: {_merge_exc}"
                            )
                            print_warn(
                                f"Crew {crew_num}: {order_id} convergence network error — "
                                f"re-queued for retry "
                                f"(attempt {_retry_count + 1}/{_CONVERGENCE_RETRY_CAP})."
                            )
                            return
                        # Cap exceeded — fall through to CONVERGENCE_FAILED below.
                        write_lifecycle_event(
                            "WARN",
                            f"{order_id} convergence retry cap ({_CONVERGENCE_RETRY_CAP}) reached "
                            f"— escalating to CONVERGENCE_FAILED (Crew {crew_num})"
                        )

                    # FTR-MSO-2026-0267: auto-serialize on genuine content conflicts.
                    # REF_MISSING and push failures are NOT eligible (only WorktreeContentConflict).
                    if isinstance(_merge_exc, WorktreeContentConflict):
                        _serialize_count = _get_serialize_count_for_order(order_id)
                        if _serialize_count < _AUTO_SERIALIZE_CAP:
                            _conflict_files = _merge_exc.conflict_files
                            _serialized = _auto_serialize_order(
                                order_id, _conflict_files, salvage=_salvage
                            )
                            _salvage_ref = (_salvage or {}).get("salvageBranch", "<none>")
                            write_lifecycle_event(
                                "AUTO_SERIALIZE",
                                f"{order_id} re-queued PENDING after content conflict "
                                f"(serializeCount={_serialize_count + 1}/{_AUTO_SERIALIZE_CAP}). "
                                f"Conflicting files: {', '.join(_conflict_files)}. "
                                f"Salvage: {_salvage_ref}. Crew {crew_num}."
                            )
                            print_warn(
                                f"Crew {crew_num}: {order_id} auto-serialized — re-queued "
                                f"(attempt {_serialize_count + 1}/{_AUTO_SERIALIZE_CAP}). "
                                f"Files: {', '.join(_conflict_files)}"
                            )
                            return
                        # Cap exceeded — fall through to CONVERGENCE_FAILED below.
                        write_lifecycle_event(
                            "WARN",
                            f"{order_id} auto-serialize cap ({_AUTO_SERIALIZE_CAP}) reached "
                            f"— escalating to CONVERGENCE_FAILED (Crew {crew_num})"
                        )

                    _record_convergence_failure(order_id, str(_merge_exc), _salvage)
                    _salvage_ref = (_salvage or {}).get("salvageBranch", "<none>")
                    write_lifecycle_event(
                        "ESCALATE",
                        f"{order_id} convergence into {voyage_branch} FAILED — NOT archived "
                        f"(status=CONVERGENCE_FAILED). Work preserved on {_salvage_ref}. "
                        f"Crew {crew_num}. Detail: {_merge_exc}"
                    )
                    print_warn(
                        f"Crew {crew_num}: convergence for {order_id} failed — order held as "
                        f"CONVERGENCE_FAILED (not archived). Recover from {_salvage_ref}: {_merge_exc}"
                    )
                    return

            write_lifecycle_event(
                "FINALIZE",
                f"{order_id} finalization stage 1/3: PR creation (Crew {crew_num})"
            )
            order_title = _get_order_title(order_id)
            project_acronym = state.get("project") or _get_project_for_order(order_id) or ""
            create_pr_for_crew(crew_num, target_repo, voyage_branch, order_id,
                               order_title, project_acronym=project_acronym)

    if status == "COMPLETE":
        # BUG-MSO-2026-0236: single-flight guard — if another dispatcher iteration is
        # already finalizing this (order, role) pair, skip silently.  This prevents the
        # double-finalization that races the role-advance and archives before TST runs.
        _fin_key = (order_id, completed_role)
        with _FINALIZING_LOCK:
            if _fin_key in _FINALIZING_ORDERS:
                write_lifecycle_event(
                    "WARN",
                    f"{order_id} role {completed_role} finalization already in-flight — "
                    f"skipping duplicate process_crew_completion call (Crew {crew_num}, BUG-0236)"
                )
                return
            _FINALIZING_ORDERS.add(_fin_key)

        write_lifecycle_event(
            "FINALIZE",
            f"{order_id} finalization stage 2/3: advancing/archiving order (Crew {crew_num})"
        )

        # BUG-MSO-2026-0222: run advance+unblock on a watchdog thread so a blocked
        # file-system or git call can't freeze the dispatcher indefinitely.
        #
        # BUG-MSO-2026-0224: the watchdog MUST use a daemon thread joined with a
        # timeout — NOT `with ThreadPoolExecutor(...)`. A ThreadPoolExecutor's
        # context-manager exit calls shutdown(wait=True), which blocks forever on a
        # hung finalize task, defeating the watchdog AND hanging the interpreter at
        # exit (the pool's worker thread is non-daemon, so it pins process shutdown —
        # which is what hung pytest). A daemon thread is abandoned cleanly if it
        # overruns: join(timeout) returns, the dispatcher continues, and process exit
        # is never blocked.
        _fin_error: List[BaseException] = []

        def _do_finalize():
            try:
                complete_order(order_id, crew_num, state)
                # v2.0.5: Auto-queue dependent orders whose dependencies are now satisfied
                auto_queue_unblocked_orders(order_id)
            except BaseException as exc:  # noqa: BLE001 — surfaced to caller below
                _fin_error.append(exc)

        _fin_thread = threading.Thread(
            target=_do_finalize,
            name=f"finalize-{order_id}",
            daemon=True,
        )
        _fin_thread.start()
        _fin_thread.join(timeout=FINALIZATION_WATCHDOG_SECONDS)

        if _fin_thread.is_alive():
            write_lifecycle_event(
                "WARN",
                f"{order_id} finalization watchdog fired after {FINALIZATION_WATCHDOG_SECONDS}s "
                f"(Crew {crew_num}) — dispatcher continuing; roleSucceededAt checkpoint will "
                f"self-heal on next restart (BUG-0222)"
            )
            print_warn(
                f"Order {order_id} finalization timed out after {FINALIZATION_WATCHDOG_SECONDS}s — "
                f"will self-heal on next dispatcher restart"
            )
            # BUG-MSO-2026-0236: leave _fin_key in _FINALIZING_ORDERS while the
            # daemon thread is still running so no concurrent caller re-enters.
            # The self-heal path (reset_orphaned_in_progress_orders + roleSucceededAt
            # checkpoint) will complete the finalization on the next restart without
            # re-entering this single-flight guard.
        else:
            # Thread completed (success or error) — release the guard so that
            # self-heal paths can re-enter if needed after a dispatcher restart.
            with _FINALIZING_LOCK:
                _FINALIZING_ORDERS.discard(_fin_key)
            if _fin_error:
                write_lifecycle_event(
                    "WARN",
                    f"{order_id} finalization error: {_fin_error[0]} (Crew {crew_num})"
                )
                print_warn(f"Order {order_id} finalization error: {_fin_error[0]}")
            else:
                write_lifecycle_event(
                    "FINALIZE",
                    f"{order_id} finalization stage 3/3: complete (Crew {crew_num})"
                )

    elif status in ["CRASHED", "ERROR", "TIMEOUT", "AUTH_ERROR", "INTERRUPTED", "MAX_TURNS", "NETWORK", "CODE"]:
        # v7.1: Added AUTH_ERROR + INTERRUPTED — re-queue for retry
        # FTR-MSO-2026-0193: MAX_TURNS treated same as TIMEOUT — REQUEUE with
        # BUG-0023 silent-completion check (commit-detect may ADVANCE instead)
        # FTR-MSO-2026-0359: NETWORK — re-queue WITHOUT burning MAX_REQUEUES
        # (recover_orphaned_order routes it to the network-retry track).
        # BUG-MSO-2026-0423: CODE — deterministic syntax/shell fault; re-queued
        # via the normal path so it DOES consume the MAX_REQUEUES budget (only
        # reason == "NETWORK" takes the budget-exempt track).
        recover_orphaned_order(order_id, crew_num, status)

    elif status in ["BLOCKED", "MAX_ITERATIONS", "CIRCUIT_BREAKER"]:
        # Stalled - archive with failure status so it doesn't clog the queue
        # BUG-MSO-2026-0443: derive stalledCause from the ACTUAL exit status
        # instead of relying on archive_stalled_order's MAX_ITERATIONS default,
        # which mislabeled a first-iteration BLOCKED as budget exhaustion.
        archive_stalled_order(order_id, crew_num, state, status,
                               STALLED_CAUSE_BY_STATUS[status])

    else:
        # v7.1: Unknown status — treat as crash, re-queue
        print_warn(f"Crew {crew_num} has unknown status '{status}' for {order_id} — re-queuing")
        write_lifecycle_event("WARN", f"Crew {crew_num} unknown status '{status}' for {order_id} — re-queuing")
        recover_orphaned_order(order_id, crew_num, f"UNKNOWN({status})")



def archive_stalled_order(order_id: str, crew_num: int, crew_state: Dict[str, Any], reason: str, stalled_cause: str = "MAX_ITERATIONS"):
    """Archive a stalled order (BLOCKED, MAX_ITERATIONS, CIRCUIT_BREAKER).

    These orders need human review - they go to orders/complete/ with a STALLED status
    so they don't sit in the active queue forever.

    BUG-MSO-2026-0443: `stalled_cause` has NO safe default — every caller must
    pass one explicitly, derived from the actual reason (see
    STALLED_CAUSE_BY_STATUS for the BLOCKED/MAX_ITERATIONS/CIRCUIT_BREAKER
    call site; other callers pass "ERROR" directly for zero-progress
    escalations). The "MAX_ITERATIONS" default is kept only so an omitted
    argument fails safe as the pre-existing (if imprecise) behaviour rather
    than raising — it must never be relied on for a new call site.
    """
    queues_dir = get_queues_dir()
    archive_dir = get_artefact_root() / "orders" / "complete"
    archive_dir.mkdir(parents=True, exist_ok=True)

    # v7.0: Search ALL queue directories
    search_dirs = [
        queues_dir / "orders", queues_dir / "explicit", queues_dir / "high-level",
        queues_dir / "bugs", queues_dir / "defects", queues_dir / "security",
        queues_dir / "breakdown",
    ]
    requests_dir = queues_dir / "requests"
    if requests_dir.exists():
        for sub in requests_dir.iterdir():
            if sub.is_dir():
                search_dirs.append(sub)

    for search_dir in search_dirs:
        if not search_dir.exists():
            continue
        for json_file in search_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                file_order_id = data.get("orderId") or data.get("id") or json_file.stem
                if file_order_id != order_id:
                    continue

                data["status"] = "STALLED"
                data["stalledAt"] = datetime.now().isoformat()
                data["stalledReason"] = reason
                data["stalledCause"] = stalled_cause  # "MAX_ITERATIONS" | "ERROR" — used by dependency gate
                data["stalledBy"] = {
                    "crew": crew_num,
                    "role": crew_state.get("role", "UNK"),
                    "iterations": crew_state.get("iteration", 0),
                    "startTime": crew_state.get("startTime", ""),
                    "endTime": crew_state.get("endTime", "")
                }

                # BUG-MSO-2026-0546 fault 2: a downstream role that (correctly)
                # found nothing to do because an UPSTREAM role left no
                # deliverable must not be the only name recorded as the cause
                # of the stall — every post-mortem starts from stalledBy, and
                # blaming the innocent role hides the role that actually
                # failed. Name the real origin alongside the reporting role
                # without changing what stalledBy.role means (still the role
                # that reported the block).
                _origin_role = _find_stall_origin_role(
                    order_id, data, crew_state.get("role", ""))
                if _origin_role:
                    data["stalledBy"]["originRole"] = _origin_role
                    data["stalledBy"]["misattributed"] = True
                    data["stalledReason"] = (
                        f"{reason} — {crew_state.get('role', 'UNK')} correctly found "
                        f"nothing to do; the real cause is upstream role {_origin_role}, "
                        f"which produced no deliverable before advancing (BUG-MSO-2026-0546)"
                    )
                    write_lifecycle_event(
                        "STALL_ORIGIN_ATTRIBUTED",
                        f"{order_id} stalled at {crew_state.get('role', 'UNK')} but the "
                        f"real origin is upstream role {_origin_role} (no deliverable) — "
                        f"recorded in stalledBy.originRole (Crew {crew_num}, BUG-0546)"
                    )

                # BUG-MSO-2026-0445 (GitHub #205): attempt REAL convergence —
                # merge the crew branch into the voyage branch — before falling
                # back to salvage-only preservation. Every other terminal-STALLED
                # escalation (TIMEOUT/ERROR via recover_orphaned_order) at least
                # gets a chance at convergence on a later retry; BLOCKED /
                # MAX_ITERATIONS / CIRCUIT_BREAKER previously went straight from
                # SALVAGE to archival with no merge attempt at all, stranding
                # real, reviewed-quality work off the PR branch behind a salvage
                # ref only a manual `mso order retry` would ever reach. Mirrors
                # the COMPLETE path's merge_crew_branch_into_voyage call — same
                # helper, same failure handling (fall through to salvage).
                _stall_vid = _get_voyage_id_for_order(order_id) or data.get("voyageId")
                _converged = False
                if _stall_vid:
                    _stall_branch = (data.get("voyageBranch")
                                      or _get_voyage_branch_for_order(order_id)
                                      or ACTIVE_VOYAGE_BRANCH)
                    _rr_st, _rn_st = _repo_ctx_for_order(order_id)
                    from maestro.core.worktrees import (
                        commit_crew_worktree_if_dirty,
                        merge_crew_branch_into_voyage,
                        cleanup_crew_worktree,
                        crew_branch_name,
                        _branch_exists_local,
                    )
                    # Only spin up the convergence worktree machinery (fetch/reset/
                    # merge — real git ops) when a crew branch actually exists
                    # locally. A first-iteration BLOCKED (no commit ever made) has
                    # nothing to converge — skip straight to the no-op salvage
                    # fallback below, exactly as before this fix.
                    if (_stall_branch
                            and _branch_exists_local(crew_branch_name(_stall_vid, crew_num), _rr_st)):
                        try:
                            commit_crew_worktree_if_dirty(_stall_vid, crew_num, order_id,
                                                          repo_name=_rn_st,
                                                          voyage_branch=_stall_branch)
                            merge_crew_branch_into_voyage(
                                _stall_vid, crew_num, _stall_branch, order_id=order_id,
                                repo_root=_rr_st, repo_name=_rn_st,
                            )
                            cleanup_crew_worktree(_stall_vid, crew_num,
                                                  repo_root=_rr_st, repo_name=_rn_st)
                            _converged = True
                            data["convergedAt"] = datetime.now().isoformat()
                            data["convergedInto"] = _stall_branch
                            write_lifecycle_event(
                                "STALLED_CONVERGED",
                                f"{order_id} crew work merged into {_stall_branch} "
                                f"before STALLED archival (Crew {crew_num}, BUG-0445)"
                            )
                        except Exception as _conv_exc:
                            # Content conflict, transient network failure, or push
                            # refusal (e.g. default-branch guard) — fall through to
                            # salvage-only preservation below. Never raised further;
                            # the crew's work is never lost, only left un-merged.
                            write_lifecycle_event(
                                "WARN",
                                f"{order_id} pre-STALLED convergence into "
                                f"{_stall_branch} skipped/failed: {_conv_exc} "
                                f"(Crew {crew_num}, BUG-0445) — falling back to salvage"
                            )

                # BUG-MSO-2026-0298 (GKT F4): salvage BEFORE archival if the work
                # was NOT already converged above. The requeue path salvages on
                # every timeout, but work done after the last requeue-salvage was
                # unprotected at STALLED escalation — and the falsely-finalised
                # voyage's worktrees were then pruned unsalvaged.
                if not _converged and _stall_vid:
                    try:
                        from maestro.core.worktrees import (
                            commit_crew_worktree_if_dirty,
                            preserve_failed_crew_branch,
                        )
                        # FTR-MSO-2026-0378: repo-aware salvage at STALLED
                        # escalation (single-repo → None/"").
                        _rr_st, _rn_st = _repo_ctx_for_order(order_id)
                        commit_crew_worktree_if_dirty(_stall_vid, crew_num, order_id,
                                                      repo_name=_rn_st,
                                                      voyage_branch=_stall_branch)
                        _salv = preserve_failed_crew_branch(_stall_vid, crew_num, order_id,
                                                            repo_root=_rr_st, repo_name=_rn_st)
                        if _salv and _salv.get("salvageBranch"):
                            data.setdefault("salvageBranches", []).append({
                                "branch": _salv.get("salvageBranch"),
                                "sha": _salv.get("strandedSha"),
                                "reason": f"STALLED: {reason}",
                                "crew": crew_num,
                                "timestamp": datetime.now().isoformat(),
                            })
                            write_lifecycle_event(
                                "SALVAGE",
                                f"{order_id} in-flight work preserved on "
                                f"{_salv.get('salvageBranch')} before STALLED archival "
                                f"(Crew {crew_num}, BUG-0298)"
                            )
                    except Exception as _stall_salv_exc:
                        write_lifecycle_event(
                            "WARN",
                            f"{order_id} STALLED salvage failed: {_stall_salv_exc} (Crew {crew_num})"
                        )

                # BUG-MSO-2026-0301 (GKT follow-up): the operator must SEE that
                # work survived — 'STALLED, $0, 0 turns' read as total loss in
                # the field when salvage branches held the full deliverable.
                # BUG-MSO-2026-0445: converged work needs no recovery at all —
                # say so plainly instead of pointing at a retry that isn't needed.
                _salvages = data.get("salvageBranches") or []
                if _converged:
                    data["operatorNote"] = (
                        f"Work merged into {data.get('convergedInto')} before "
                        f"STALLED archival — already on the voyage branch, no "
                        f"recovery needed."
                    )
                    _salvage_msg = f" — work merged into {data.get('convergedInto')}"
                elif _salvages:
                    _newest = _salvages[-1].get("branch", "?")
                    data["operatorNote"] = (
                        f"Work preserved on {_newest} "
                        f"({len(_salvages)} salvage branch(es) total). "
                        f"Retry with: mso order retry {order_id}"
                    )
                    _salvage_msg = f" — work preserved on {_newest}"
                else:
                    data["operatorNote"] = f"Retry with: mso order retry {order_id}"
                    _salvage_msg = ""

                archive_file = archive_dir / json_file.name
                archive_file.write_text(json.dumps(data, indent=2), encoding='utf-8')
                json_file.unlink()
                # BUG-MSO-2026-0294/0295: STALLED is terminal for dispatch purposes.
                order_ledger.record_terminal(order_id, "STALLED", workspace_dir=get_artefact_root())
                _commit_lifecycle_transition(
                    [archive_file, json_file],
                    f"lifecycle: archive {order_id} (STALLED)",
                )

                # BUG-MSO-2026-0024: STALLED is a satisfying status, so dependents
                # unblock — refresh the Eight Bells grace clock.
                _mark_order_terminal_now()
                print_warn(f"Order {order_id} STALLED ({reason}) -> archived for review{_salvage_msg}")
                _stalled_suffix = (
                    " (BUG-0445)" if _converged
                    else f" — recover with `mso order retry {order_id}` (BUG-0301)"
                )
                write_lifecycle_event(
                    "STALLED",
                    f"{order_id} STALLED ({reason}) -> archived (Crew {crew_num})"
                    f"{_salvage_msg}{_stalled_suffix}"
                )
                # BUG-MSO-2026-0280 (defect B): fire auto-queue from EVERY terminal
                # archival path, not just the COMPLETE/advance path. Without this,
                # dependents of a STALLED order are never queued and the chain halts.
                #
                # Copilot PR #129: the order is ALREADY archived at this point, so
                # the archival must be reported as success (return True) regardless
                # of whether the dependent auto-queue succeeds. Wrap the auto-queue
                # in its own fail-open try/except so an exception here cannot fall
                # through to the outer handler and make us return False for an order
                # that is, in fact, archived. The heartbeat reconciliation pass
                # (reconcile_stranded_dependents) is the backstop if this misses.
                try:
                    auto_queue_unblocked_orders(order_id)
                except Exception as _aq_exc:
                    print_warn(f"Auto-queue after STALLED archival of {order_id} failed "
                               f"(non-fatal; reconciliation pass will recover): {_aq_exc}")
                return True

            except Exception as e:
                print_warn(f"Error processing {json_file}: {e}")

    return False


def archive_all_completed_orders() -> int:
    """Manual sweep: archive terminal-status orders from queues.

    CONSERVATIVE: Only archives orders with confirmed terminal status:
    - COMPLETE, PROCESSED -> archived as-is
    - IN_PROGRESS -> only if crew state confirms COMPLETE (enriches metadata)
    - PENDING, RUNNING -> always skipped (still active work)

    Matches crew state files to add completion metadata.
    Used via --archive-completed CLI command.
    """
    archived = 0
    queues_dir = get_queues_dir()
    archive_dir = get_artefact_root() / "orders" / "complete"
    archive_dir.mkdir(parents=True, exist_ok=True)

    # Build a lookup of crew states by orderId for metadata enrichment
    crew_states = {}
    for crew_num in range(1, 6):
        state = read_crew_state(crew_num)
        if state and state.get("orderId"):
            crew_states[state["orderId"]] = state

    # Collect all queue directories to scan
    search_dirs = [queues_dir / "orders"]
    requests_dir = queues_dir / "requests"
    if requests_dir.exists():
        for sub in requests_dir.iterdir():
            if sub.is_dir():
                search_dirs.append(sub)

    for search_dir in search_dirs:
        if not search_dir.exists():
            continue
        for json_file in search_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                status = data.get("status", "PENDING")
                order_id = data.get("id", json_file.stem)

                # Only archive confirmed terminal statuses
                should_archive = False

                if status in ["COMPLETE", "PROCESSED"]:
                    # Already marked complete - safe to archive
                    should_archive = True

                elif status == "IN_PROGRESS":
                    # Check crew state - only archive if crew confirms COMPLETE
                    crew_state = crew_states.get(order_id, {})
                    crew_status = crew_state.get("status", "") if crew_state else ""

                    if crew_status == "COMPLETE":
                        # Crew finished - enrich and archive
                        data["status"] = "COMPLETE"
                        data["completedAt"] = datetime.now().isoformat()
                        data["completedBy"] = {
                            "crew": crew_state.get("crewNumber"),
                            "role": crew_state.get("role", "UNK"),
                            "iterations": crew_state.get("iteration", 0),
                            "startTime": crew_state.get("startTime", ""),
                            "endTime": crew_state.get("endTime", "")
                        }
                        should_archive = True
                    else:
                        # Crew still working, crashed, or reassigned - leave in queue
                        print_info(f"{order_id} IN_PROGRESS (crew: {crew_status or 'unknown'}) -> skipped")

                # PENDING, RUNNING, and unconfirmed IN_PROGRESS are always skipped

                if not should_archive:
                    continue

                # Archive it
                data["archivedAt"] = datetime.now().isoformat()
                archive_file = archive_dir / json_file.name
                archive_file.write_text(json.dumps(data, indent=2), encoding='utf-8')
                json_file.unlink()

                print_ok(f"{order_id} ({data['status']}) -> archived")
                archived += 1

            except Exception as e:
                print_warn(f"Error processing {json_file}: {e}")

    return archived


# BUG-MSO-2026-0499: statuses that mean "waiting on a dependency, release me
# automatically once dependsOn is satisfied" — as opposed to statuses like
# BACKLOG/DRAFT/PAUSED that mean "operator parked this on purpose, an
# auto-release would override a deliberate decision" (see the HELD/PAUSED/
# PROPOSED "operator-managed, leave alone" comment near line 3064, which is
# about VOYAGE status, not per-order status — this set only ever touches an
# order whose OWN dependsOn has just become satisfied).
#   PROPOSED — the standalone-plan-review-gate default a dependent order
#     carries until its dependency (often the reviewed plan) completes
#     (BUG-MSO-2026-0239/0476 handle the plan-approval trigger directly;
#     this is the general dependsOn-satisfied backstop for every OTHER
#     order-completion route, since a PROPOSED order also gates on a
#     regular dependsOn like any other order — see BUG-MSO-2026-0499).
#   HELD — the operator/dep-gate hold literal documented at
#     docs/TROUBLESHOOTING.md#e09 and hand-set by LEAD when parking a
#     dependency-blocked order; must auto-release the moment the
#     dependency it was held on actually completes.
_AUTO_RELEASE_STATUSES = {"PROPOSED", "HELD"}


def promote_ready_dependents(admiralty_dir: Optional[Path] = None) -> int:
    """BUG-MSO-2026-0499: release PROPOSED/HELD orders in the LIVE queues
    whose dependsOn is now fully satisfied, back to PENDING.

    Root cause this fixes: `scan_all_queues()` only ever considers files
    whose status == "PENDING" (queue_name != "defects" branch above) — a
    PROPOSED or HELD order sitting in queues/{orders,bugs,...} is invisible
    to it forever, even after every entry in its dependsOn archives COMPLETE.
    Neither `auto_queue_unblocked_orders` (below) nor `reconcile_stranded_
    dependents` ever looked here — both scan ONLY `orders/active/`, a
    legacy/fallback directory that is empty under the current convention
    (orders live in queues/* for their whole active lifetime, in place,
    until archived to orders/complete|failed). That directory mismatch —
    not a missing call site — is why dependent promotion silently never ran:
    `auto_queue_unblocked_orders` IS already wired into every completion
    route (normal archive, BUG-0023 silent completion, the convergence
    salvage fast-path, and every terminal-archival branch incl. STALLED),
    it was just scanning the wrong place.

    Deliberately requires a NON-EMPTY dependsOn before doing anything — a
    PROPOSED order with no dependsOn is gated by the human plan-review flow
    (`mso review approve` / promote_proposed_dependents), not by dependency
    completion, and must not be auto-released here.

    Called from both auto_queue_unblocked_orders (fires on every completion
    route) and reconcile_stranded_dependents (fires every dispatcher tick,
    including the first tick at startup) so a miss on one path self-heals
    via the other — same belt-and-braces pattern BUG-MSO-2026-0280 already
    established for the orders/active/ scan.
    """
    admiralty_dir = admiralty_dir or get_artefact_root()
    promoted = 0
    for json_file in _iter_queue_order_files(admiralty_dir):
        try:
            data = json.loads(json_file.read_text(encoding="utf-8"))
        except Exception:
            continue

        status = str(data.get("status", "")).strip().upper()
        if status not in _AUTO_RELEASE_STATUSES:
            continue

        deps = data.get("dependsOn", data.get("dependencies", []))
        if not deps:
            continue  # not dependency-gated — leave to the review-gate flow

        satisfied, _waiting_on = check_dependencies_satisfied({**data, "dependsOn": deps})
        if not satisfied:
            continue

        order_id = data.get("orderId") or data.get("id") or json_file.stem
        data["status"] = "PENDING"
        try:
            tmp_file = json_file.with_suffix(".tmp")
            tmp_file.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
            tmp_file.replace(json_file)
        except OSError as e:
            print_warn(f"promote_ready_dependents: failed to write {json_file}: {e}")
            continue

        promoted += 1
        print_ok(f"Released {order_id} {status} -> PENDING (dependsOn now satisfied)")
        write_lifecycle_event(
            "AUTOQUEUE",
            f"{order_id} released {status} -> PENDING — dependsOn {deps} now "
            f"satisfied (BUG-MSO-2026-0499)"
        )

    return promoted


def auto_queue_unblocked_orders(completed_order_id: str):
    """v2.0.5: When an order completes, auto-queue any orders from orders/active/
    whose dependencies are now satisfied.

    This closes the critical gap where orders sat in orders/active/ but never
    made it into queues/orders/ because no one copied them there.

    Logic:
    1. Scan orders/active/ for orders with a 'dependencies' field
    2. For each, check if ALL dependencies exist in orders/complete/
    3. If satisfied and not already in a queue, copy to queues/orders/

    BUG-MSO-2026-0499: ALSO runs promote_ready_dependents(), which covers the
    dependents that actually live in queues/* at PROPOSED/HELD status — the
    gap this scan alone could never close (see that function's docstring).
    """
    admiralty_dir = get_artefact_root()
    active_dir = admiralty_dir / "orders" / "active"
    complete_dir = admiralty_dir / "orders" / "complete"
    queue_dir = get_queues_dir() / "orders"
    queue_dir.mkdir(parents=True, exist_ok=True)

    queue_promoted = promote_ready_dependents(admiralty_dir)

    if not active_dir.exists():
        if queue_promoted:
            print_ok(f"Auto-queued {queue_promoted} order(s) after {completed_order_id} completed")
        return

    # Build set of completed order IDs for fast lookup
    completed_ids = set()
    if complete_dir.exists():
        for f in complete_dir.glob("*.json"):
            completed_ids.add(f.stem)

    # Statuses that mean "this order is finished — do not re-queue it"
    # Defends against complete/ lagging behind active/ across branches
    # (BUG-ADM-2026-0002): the rename from active/ to complete/ might not
    # have landed on the current branch yet, so the complete/ glob above
    # wouldn't catch it. In that case, the order's own status field is the
    # authoritative signal — include every terminal outcome that fleet_runner
    # treats as archived/complete elsewhere so all stalled-but-finished
    # variants are skipped consistently.
    TERMINAL_STATUSES = {
        "COMPLETE",
        "FAILED",
        "CANCELLED",
        "BLOCKED",
        "STALLED",
        "MAX_ITERATIONS",
        "PROCESSED",
    }

    queued_count = 0
    for order_file in list(active_dir.glob("*.json")):
        try:
            data = json.loads(order_file.read_text(encoding='utf-8'))
            order_id = data.get("orderId", order_file.stem)

            # Skip if already in a queue
            if (queue_dir / order_file.name).exists():
                continue

            # Skip if already completed (archive present)
            if order_id in completed_ids:
                continue

            # Skip if the order's own status says it's finished, even when
            # the archive isn't on this branch yet (BUG-ADM-2026-0002).
            if data.get("status", "").upper() in TERMINAL_STATUSES:
                continue

            # Check dependencies - support both 'dependencies' and 'dependsOn' fields
            deps = data.get("dependencies", data.get("dependsOn", []))
            if not deps:
                # No dependencies — queue immediately
                data["status"] = "PENDING"
                queue_file = queue_dir / order_file.name
                queue_file.write_text(json.dumps(data, indent=2), encoding='utf-8')
                queued_count += 1
                print_ok(f"Auto-queued {order_id} (no dependencies)")
                write_lifecycle_event("AUTOQUEUE", f"{order_id} auto-queued (no dependencies)")
                continue

            # Check if all dependencies are satisfied
            all_satisfied = True
            for dep_id in deps:
                if dep_id not in completed_ids:
                    all_satisfied = False
                    break

            if all_satisfied:
                data["status"] = "PENDING"
                queue_file = queue_dir / order_file.name
                queue_file.write_text(json.dumps(data, indent=2), encoding='utf-8')
                queued_count += 1
                print_ok(f"Auto-queued {order_id} (dependency {completed_order_id} satisfied)")
                write_lifecycle_event("AUTOQUEUE",
                    f"{order_id} auto-queued after {completed_order_id} completed")

        except Exception as e:
            print_warn(f"Error checking {order_file.name} for auto-queue: {e}")

    total_queued = queued_count + queue_promoted
    if total_queued > 0:
        print_ok(f"Auto-queued {total_queued} order(s) after {completed_order_id} completed")


def reconcile_stranded_dependents() -> int:
    """BUG-MSO-2026-0280: Heartbeat reconciliation pass.

    On every dispatcher tick, scan orders/active/ for orders whose full
    dependsOn set is satisfied by orders/complete/ but are not yet queued
    or in-progress. Queue any found with a RECONCILE_QUEUED lifecycle event.

    BUG-MSO-2026-0499: ALSO runs promote_ready_dependents() every tick — this
    is the "on dispatcher startup" self-heal for a dependent stranded at
    PROPOSED/HELD in queues/* (the first tick fires at startup), independent
    of whether the completion that satisfied its dependsOn ever ran through
    auto_queue_unblocked_orders (crash mid-finalize, older engine version,
    manual JSON edit that set HELD directly, etc.).

    This is a self-healing safety net — it catches dependents that were
    stranded because the post-completion auto-queue event did not fire
    (e.g. order archived via BLOCKED/STALLED path, dispatcher crash, etc.).

    Returns the number of orders queued.
    """
    admiralty_dir = get_artefact_root()
    active_dir = admiralty_dir / "orders" / "active"
    complete_dir = admiralty_dir / "orders" / "complete"
    queue_dir = get_queues_dir() / "orders"
    queue_dir.mkdir(parents=True, exist_ok=True)

    queued_count = promote_ready_dependents(admiralty_dir)

    if not active_dir.exists():
        return queued_count

    # Build set of completed order IDs for fast lookup
    completed_ids: set = set()
    if complete_dir.exists():
        for f in complete_dir.glob("*.json"):
            completed_ids.add(f.stem)

    TERMINAL_STATUSES = {
        "COMPLETE", "FAILED", "CANCELLED", "BLOCKED",
        "STALLED", "MAX_ITERATIONS", "PROCESSED",
    }

    for order_file in list(active_dir.glob("*.json")):
        try:
            data = json.loads(order_file.read_text(encoding="utf-8"))
            order_id = data.get("orderId", order_file.stem)

            # Already queued or in a terminal state — skip
            if (queue_dir / order_file.name).exists():
                continue
            if order_id in completed_ids:
                continue
            if data.get("status", "").upper() in TERMINAL_STATUSES:
                continue
            # Already in-progress — skip (these are actively being worked on)
            if data.get("status", "").upper() in {"IN_PROGRESS", "RUNNING"}:
                continue

            deps = data.get("dependencies", data.get("dependsOn", []))
            if not deps:
                continue  # no-dep orders handled by normal dispatch; skip here

            # Copilot PR #129: use the SAME status-aware dependency gate the
            # dispatcher uses (check_dependencies_satisfied), not bare presence
            # in complete/. BUG-MSO-2026-0251: an ERROR-escalated STALLED
            # dependency (stalledCause="ERROR", zero work) must NOT satisfy
            # dependsOn — existence-only would wrongly queue a dependent that is
            # still blocked by policy. Normalise to the `dependsOn` key the
            # checker expects so the legacy `dependencies` key is honoured too.
            satisfied, _waiting_on = check_dependencies_satisfied({**data, "dependsOn": deps})
            if satisfied:
                data["status"] = "PENDING"
                queue_file = queue_dir / order_file.name
                queue_file.write_text(json.dumps(data, indent=2), encoding="utf-8")
                queued_count += 1
                print_ok(f"Reconciled stranded dependent {order_id} -> PENDING")
                write_lifecycle_event(
                    "RECONCILE_QUEUED",
                    f"{order_id} queued by reconciliation pass — dependsOn satisfied in complete/ "
                    f"but order was stranded (BUG-MSO-2026-0280)"
                )

        except Exception as e:
            print_warn(f"reconcile_stranded_dependents: error checking {order_file.name}: {e}")

    return queued_count


# BUG-MSO-2026-0436: voyage statuses that mean "in flight" and are therefore
# eligible for finalisation by sweep_decks(). Anything NOT in this set (HELD,
# PAUSED, DRAFT, PROPOSED, ABANDONED, CANCELLED, COMPLETE, FAILED, or any
# custom workspace status) is treated as deliberately parked and left alone,
# preserving BUG-ADM-2026-0012's intent. An absent/empty status also sweeps
# (legacy pre-status manifests).
_SWEEPABLE_VOYAGE_STATUSES = frozenset({"PLANNED", "ACTIVE", "IN_PROGRESS"})


def sweep_decks(quiet: bool = False) -> dict:
    """Automatic deck sweep: clean stale orders and complete finished voyages.

    v2.0.5: Called at Eight Bells and via --sweep-decks CLI command.
    BUG-MSO-2026-0289: also called on the dispatcher's heartbeat throttle (with
    quiet=True) so a voyage whose orders are ALL complete is finalised + its PR
    promoted PER-VOYAGE — not held hostage until the WHOLE workspace goes idle
    (Eight Bells). `quiet` suppresses the per-tick console chatter; the `SWEEP`
    lifecycle event still fires whenever real work is done.

    Actions:
    1. Remove stale duplicates from orders/active/ that already exist in orders/complete/
    2. Archive prompts/active/ files for completed orders to prompts/complete/
    3. Check all active voyages - if all orders are COMPLETE, mark voyage COMPLETE
       and move from voyages/active/ to voyages/complete/

    Returns a summary dict with counts of actions taken.
    """
    admiralty_dir = get_artefact_root()
    active_orders_dir = admiralty_dir / "orders" / "active"
    complete_orders_dir = admiralty_dir / "orders" / "complete"
    active_voyages_dir = admiralty_dir / "voyages" / "active"
    complete_voyages_dir = admiralty_dir / "voyages" / "complete"
    complete_voyages_dir.mkdir(parents=True, exist_ok=True)

    summary = {"stale_orders_removed": 0, "prompts_archived": 0, "voyages_completed": 0, "errors": []}

    # --- Step 1: Remove stale active orders that have completed copies ---
    if active_orders_dir.exists() and complete_orders_dir.exists():
        completed_ids = {f.stem for f in complete_orders_dir.glob("*.json")}
        for order_file in list(active_orders_dir.glob("*.json")):
            if order_file.stem in completed_ids:
                try:
                    order_file.unlink()
                    summary["stale_orders_removed"] += 1
                    print_ok(f"Swept stale active order: {order_file.stem}")
                except Exception as e:
                    summary["errors"].append(f"Failed to remove {order_file.stem}: {e}")

    # --- Step 2: Archive prompts for completed orders ---
    active_prompts_dir = admiralty_dir / "prompts" / "active"
    complete_prompts_dir = admiralty_dir / "prompts" / "complete"
    if active_prompts_dir.exists() and complete_orders_dir.exists():
        complete_prompts_dir.mkdir(parents=True, exist_ok=True)
        completed_ids = {f.stem for f in complete_orders_dir.glob("*.json")}
        for prompt_file in list(active_prompts_dir.glob("*.md")):
            # Prompt files are named {ORDER-ID}-{ROLE}.md — extract order ID
            parts = prompt_file.stem.rsplit("-", 1)
            order_id = parts[0] if len(parts) == 2 else prompt_file.stem
            if order_id in completed_ids:
                try:
                    dest = complete_prompts_dir / prompt_file.name
                    prompt_file.replace(dest)  # BUG-MSO-2026-0291: overwrite-safe (rename raises WinError 183 if dest exists on Windows)
                    summary["prompts_archived"] += 1
                except Exception as e:
                    summary["errors"].append(f"Failed to archive prompt {prompt_file.name}: {e}")

    # --- Step 3: Complete finished voyages ---
    if active_voyages_dir.exists():
        for voyage_file in list(active_voyages_dir.glob("VOY-*.json")):
            try:
                voyage = json.loads(voyage_file.read_text(encoding='utf-8'))
                voyage_id = voyage.get("voyageId", voyage_file.stem)
                orders = voyage.get("orders", [])

                # BUG-MSO-2026-0436: this guard used to be an ALLOWLIST of
                # exactly "ACTIVE" (BUG-ADM-2026-0012), which silently made
                # voyage finalisation unreachable for almost every real voyage.
                # `mso voyage create` writes status="PLANNED" and NOTHING ever
                # promotes it to "ACTIVE", so a voyage whose orders had all
                # completed was skipped here forever: never moved to
                # voyages/complete/, never had its draft PR promoted, and so
                # never became mergeable. Measured across three live
                # workspaces when this was found: 10 voyages PLANNED, 1
                # IN_PROGRESS, 1 ACTIVE — i.e. 11 of 12 were unsweepable.
                # That is the Final Review pile-up operators kept reporting.
                #
                # BUG-ADM-2026-0012's INTENT was sound: a voyage an operator has
                # deliberately parked must not be finalised out from under them.
                # So the guard is now a DENYLIST of parked/terminal statuses —
                # in-flight statuses (None, PLANNED, ACTIVE, IN_PROGRESS) sweep,
                # everything an operator uses to pause or retire a voyage does
                # not. Unknown/custom statuses are treated as parked, preserving
                # the conservative half of the original behaviour.
                voyage_status = (voyage.get("status") or "").upper()
                if voyage_status and voyage_status not in _SWEEPABLE_VOYAGE_STATUSES:
                    continue

                if not orders:
                    continue

                # Check if ALL orders in this voyage have completed copies.
                # BUG-ADM-2026-0010: file presence alone is not enough — the
                # completed order must also be owned by THIS voyage. Without
                # this check, an order ID that happens to exist in
                # orders/complete/ from a prior voyage (cross-voyage ID
                # reuse, manual residue, fix-and-revert cycle) will falsely
                # mark the new voyage COMPLETE before its crews ever ran.
                # BUG-MSO-2026-0288: load the skip list once before the per-order loop.
                _sweep_skipped_ids = load_skipped_order_ids()
                all_complete = True
                for order_entry in orders:
                    # orders field may be a list of strings or a list of dicts
                    if isinstance(order_entry, str):
                        order_id = order_entry
                    else:
                        # BUG-ADM-2026-0012: schemas use both `orderId` and
                        # `id` in the wild (PSG manifests use `id`; framework
                        # manifests use `orderId`). Accept either — falling
                        # back to "" if neither is present.
                        order_id = (
                            order_entry.get("orderId")
                            or order_entry.get("id")
                            or ""
                        )
                    if not order_id:
                        # BUG-ADM-2026-0012: pre-fix this silently skipped an
                        # unidentifiable order entry. That left all_complete
                        # True for voyages with no recognisable order keys —
                        # they'd auto-archive without any crew ever running.
                        # Now: treat as not-complete (operator must fix the
                        # voyage manifest before sweep advances).
                        # Copilot review on PR #62: write_lifecycle_event
                        # already swallows exceptions internally, so the
                        # outer try/except is redundant.
                        all_complete = False
                        write_lifecycle_event(
                            "SWEEP_UNREADABLE_ORDER",
                            f"Voyage {voyage_id}: order entry has neither "
                            f"`orderId` nor `id` field — refusing to sweep. "
                            "Fix the voyage manifest's orders[] schema."
                        )
                        break
                    # BUG-MSO-2026-0288: a skipped stale order is treated as satisfied
                    # so it cannot strand a voyage as never-complete.
                    if order_id in _sweep_skipped_ids:
                        continue
                    completed_file = complete_orders_dir / f"{order_id}.json"
                    if not completed_file.exists():
                        all_complete = False
                        break

                    # BUG-ADM-2026-0010: ownership verification.
                    # Copilot review on PR #60: catch UnicodeDecodeError too
                    # (Path.read_text with explicit encoding raises it on
                    # invalid UTF-8). Without it, the error bubbles to the
                    # outer except Exception and aborts voyage processing
                    # rather than just refusing the sweep. Also record the
                    # specific blocker in summary + lifecycle log so
                    # operators can find the offending file.
                    try:
                        order_data = json.loads(completed_file.read_text(encoding='utf-8'))
                    except (OSError, json.JSONDecodeError, UnicodeDecodeError) as exc:
                        all_complete = False
                        err_msg = (
                            f"Voyage {voyage_id}: cannot read completed order "
                            f"{order_id} ({type(exc).__name__}: {str(exc)[:100]}) — "
                            "treating as not-complete (sweep refused)."
                        )
                        summary["errors"].append(err_msg)
                        try:
                            write_lifecycle_event("SWEEP_READ_ERROR", err_msg)
                        except Exception:
                            pass
                        break
                    completed_voyage_id = order_data.get("voyageId") or ""
                    if completed_voyage_id and completed_voyage_id != voyage_id:
                        all_complete = False
                        try:
                            write_lifecycle_event(
                                "SWEEP_OWNERSHIP_MISMATCH",
                                f"Voyage {voyage_id} references {order_id}, "
                                f"but the completed order is owned by "
                                f"{completed_voyage_id}. Refusing to sweep "
                                f"{voyage_id} as COMPLETE — fix the voyage's "
                                "orders[] reference or re-run the order under "
                                f"{voyage_id}."
                            )
                        except Exception:
                            pass
                        break

                    # BUG-MSO-2026-0296 (GKT F1): STALLED is NOT COMPLETE.
                    # archive_stalled_order files STALLED orders into
                    # orders/complete/ for dependency-resolution reasons, but
                    # file PRESENCE must not finalise the voyage — that
                    # falsely archived GKT's voyage and let the worktree
                    # pruner destroy unsalvaged work. Only genuine COMPLETE
                    # status counts toward voyage completion.
                    _archived_status = (order_data.get("status") or "COMPLETE").upper()
                    if _archived_status not in ("COMPLETE", "COMPLETED"):
                        all_complete = False
                        write_lifecycle_event(
                            "SWEEP_STALLED_ORDER",
                            f"Voyage {voyage_id}: {order_id} is archived with "
                            f"status={_archived_status}, not COMPLETE — refusing "
                            f"to finalise the voyage. Recover it with "
                            f"`mso order retry {order_id}` (BUG-0296)."
                        )
                        break

                if not all_complete:
                    continue

                # All orders complete - update voyage status and move to complete
                voyage["status"] = "COMPLETE"
                if not voyage.get("startedDate"):
                    voyage["startedDate"] = voyage.get("createdDate",
                        datetime.now().strftime("%Y-%m-%d"))
                if not voyage.get("completedDate"):
                    voyage["completedDate"] = datetime.now().strftime("%Y-%m-%d")

                for o in voyage.get("orders", []):
                    if isinstance(o, dict):
                        o["status"] = "COMPLETE"
                for p in voyage.get("phases", []):
                    p["status"] = "COMPLETE"
                for ac in voyage.get("acceptanceCriteria", []):
                    if ac.get("status") == "PENDING":
                        ac["status"] = "VERIFIED"
                for g in voyage.get("gates", {}).values():
                    if g.get("status") == "PENDING":
                        g["status"] = "PASSED"
                        if not g.get("verifiedAt"):
                            g["verifiedAt"] = voyage["completedDate"]

                dest = complete_voyages_dir / voyage_file.name
                dest.write_text(json.dumps(voyage, indent=2), encoding='utf-8')
                voyage_file.unlink()

                summary["voyages_completed"] += 1
                print_ok(f"Voyage {voyage_id} COMPLETE -> moved to voyages/complete/")
                write_lifecycle_event("SWEEP",
                    f"Voyage {voyage_id} auto-completed (all orders done)")

                # FTR-MSO-2026-0287 (R1): the voyage is done — promote its draft
                # PR to ready-for-review so the single end-of-voyage CI run fires
                # before merge review. No-op when draft mode is off.
                try:
                    promote_voyage_pr_ready(voyage)
                except Exception as _prx:
                    print_warn(f"PR promote-on-finalisation for {voyage_id} failed: {_prx}")

                # Clean up voyage worktree (admin) and any lingering crew worktrees
                try:
                    from maestro.core.worktrees import (
                        cleanup_voyage_worktree,
                        cleanup_all_crew_worktrees,
                    )
                    # BUG-MSO-2026-0389: target the PRODUCT repo in solo/shared
                    # mode (worktrees are registered there, not in the artefact
                    # checkout the dispatcher's cwd points at). Embedded resolves
                    # None and the call stays byte-identical (kwarg omitted).
                    try:
                        _clean_root = solo_worktree_repo_root()
                    except Exception:
                        _clean_root = None
                    _ckw = {"repo_root": _clean_root} if _clean_root is not None else {}
                    cleanup_all_crew_worktrees(voyage_id, **_ckw)
                    cleanup_voyage_worktree(voyage_id, **_ckw)
                except Exception as wt_exc:
                    print_warn(f"Worktree cleanup for {voyage_id} failed: {wt_exc}")

            except Exception as e:
                summary["errors"].append(f"Error processing voyage {voyage_file.name}: {e}")

    # Log summary
    total_actions = summary["stale_orders_removed"] + summary["prompts_archived"] + summary["voyages_completed"]
    if total_actions > 0:
        if not quiet:
            print_ok(f"Deck sweep: {summary['stale_orders_removed']} stale orders removed, "
                     f"{summary['prompts_archived']} prompts archived, "
                     f"{summary['voyages_completed']} voyages completed")
        write_lifecycle_event("SWEEP", f"Deck sweep: {summary['stale_orders_removed']} orders, "
                              f"{summary['prompts_archived']} prompts, "
                              f"{summary['voyages_completed']} voyages")
    elif not quiet:
        print_info("Deck sweep: all clear, nothing to clean")

    if summary["errors"]:
        for err in summary["errors"]:
            print_warn(f"Sweep error: {err}")

    return summary


def _validate_mcp_before_launch(item: Dict[str, Any], order_data: Dict[str, Any]) -> None:
    """
    Validate MCP server permissions before launching a crew.
    Raises RuntimeError (caught by dispatch_crew) with lifecycle log entry on
    violation. Logs a warning and continues in permissive mode when no registry
    is present.
    """
    try:
        from maestro.mcp import validate_mcp_permissions, load_registry
    except ImportError:
        return  # mcp module not available — skip silently

    role: str = item.get("role", "")
    workspace = Path(get_artefact_root()).parent

    # Per-order override: order.data.mcpServers lists required server names.
    # order_data is untyped runtime data so the field could legally be any JSON
    # type; treat anything other than a list[str] as a schema error rather than
    # iterate characters of a string into validate_mcp_permissions.
    raw_order_mcp_servers = order_data.get("mcpServers")
    order_mcp_servers: Optional[List[str]]
    if raw_order_mcp_servers is None:
        order_mcp_servers = None
    elif (
        isinstance(raw_order_mcp_servers, list)
        and all(isinstance(s, str) for s in raw_order_mcp_servers)
    ):
        order_mcp_servers = raw_order_mcp_servers
    else:
        order_id = item.get("id", "?")
        error = "Invalid order schema: 'mcpServers' must be a list of strings"
        print_error(f"MCP validation failed for {order_id} ({role}): {error}")
        write_lifecycle_event(
            "MCP_BLOCK",
            f"Crew blocked — {order_id} ({role}): {error}",
        )
        raise RuntimeError(f"MCP validation failed: {error}")

    # Permissive-mode check: no registry → warn and allow
    registry = load_registry(workspace)
    if registry is None:
        print_warn(
            f"MCP registry not found (.mso/config/mcp-servers.json) — "
            f"running in permissive mode for {item.get('id', '?')}"
        )
        write_lifecycle_event(
            "MCP_WARN",
            f"No MCP registry — permissive mode for {item.get('id', '?')} ({role})",
        )
        return

    error = validate_mcp_permissions(role, workspace, server_names=order_mcp_servers)
    if error:
        order_id = item.get("id", "?")
        print_error(f"MCP validation failed for {order_id} ({role}): {error}")
        write_lifecycle_event(
            "MCP_BLOCK",
            f"Crew blocked — {order_id} ({role}): {error}",
        )
        raise RuntimeError(f"MCP validation failed: {error}")


def _validate_governance_before_launch(item: Dict[str, Any]) -> None:
    """Pre-dispatch governance gate (FTR-MSO-2026-0397, PLAN-0372 §3.5).

    In governed mode, refuse to launch a crew when the workspace's distributed
    policy bundle is tampered (signature invalid), rolled back (version below the
    recorded floor), or stale past its offline-grace window. This is the
    signed-bundle counterpart to the pretool STEP-1 gate — it stops a governed
    crew from ever starting against an untrusted policy.

    Behaviour is scoped to be zero-impact for Phase-1 / non-Enterprise
    workspaces:
      * governedMode == off (the default)        → no-op.
      * No signed bundle + no requireSignature    → no-op (Phase-1 pass-through).
      * enforce + tamper/rollback/stale           → RuntimeError (order held).
      * warn  + tamper/rollback/stale             → log POLICY_DISPATCH_WARN, allow.

    Never raises for a transient/internal error unless we are certain the mode is
    'enforce' and the failure is a genuine governance verdict.
    """
    order_id = item.get("id", "?")

    # SEC-FTR-MSO-2026-0397 F6: resolve the GOVERNED INTENT first, before any other
    # resolution can throw. MAESTRO_GOVERNED is the dispatcher's authoritative signal
    # and needs no artefact-root/config lookup — so even if artefact-root, mode, or
    # the governance import subsequently fails, we still know whether this launch was
    # meant to be governed. When it was, an internal resolution failure must fail
    # CLOSED (refuse the launch), never silently allow an ungoverned crew to start.
    from maestro.governance import GOVERNED_ENV
    _env_raw = (os.environ.get(GOVERNED_ENV) or "").strip().lower()
    forced_mode = (
        "enforce" if _env_raw in ("1", "enforce", "true", "yes")
        else "warn" if _env_raw == "warn"
        else None
    )

    def _resolution_failed(exc: Exception) -> None:
        """Handle an internal resolution failure per the governed intent."""
        if forced_mode == "enforce":
            print_error(
                f"Governance gate could not resolve governed context for {order_id}: "
                f"{exc}. Failing CLOSED (governed enforce mode)."
            )
            write_lifecycle_event(
                "POLICY_DISPATCH_BLOCKED",
                f"Crew blocked — {order_id}: governance resolution failed: {exc}",
            )
            raise RuntimeError(
                f"Governance validation failed: cannot resolve governed context: {exc}"
            )
        if forced_mode == "warn":
            print_warn(
                f"Governance gate could not resolve governed context for {order_id}: "
                f"{exc} (warn mode — allowing)."
            )
            write_lifecycle_event(
                "POLICY_DISPATCH_WARN",
                f"{order_id}: governance resolution failed: {exc}",
            )
        # No governed intent → an unresolvable workspace is nothing to govern.
        return

    try:
        from maestro.governance import resolve_governed_mode
        artefact_root = get_artefact_root()
        workspace = Path(artefact_root).parent
        mode = resolve_governed_mode(workspace)
    except Exception as exc:
        _resolution_failed(exc)
        return
    if mode == "off":
        return

    try:
        from maestro.governance import validate_workspace_bundle, GovernanceError
    except Exception as exc:
        _resolution_failed(exc)
        return

    try:
        validate_workspace_bundle(
            workspace, enforce=(mode == "enforce"), artefact_root=artefact_root
        )
    except GovernanceError as exc:
        if mode == "enforce":
            print_error(f"Governance validation failed for {order_id}: {exc}")
            write_lifecycle_event(
                "POLICY_DISPATCH_BLOCKED",
                f"Crew blocked — {order_id}: {exc}",
            )
            raise RuntimeError(f"Governance validation failed: {exc}")
        # warn mode: surface but allow.
        print_warn(f"Governance warning for {order_id}: {exc}")
        write_lifecycle_event(
            "POLICY_DISPATCH_WARN",
            f"{order_id}: {exc}",
        )


_REQUIRES_TARGET_REPO_ROLES = {"SHP", "BOS", "BLD", "TST"}


def _load_voyage_by_id(voyage_id: str) -> Dict[str, Any]:
    """Look up a voyage's JSON across active and complete locations.

    BUG-ADM-2026-0009: needed by resolve_voyage_branch_for_order so an
    order without explicit voyageBranch can inherit from its parent voyage.
    Returns {} when not found.
    """
    if not voyage_id:
        return {}
    try:
        adm = get_artefact_root()
    except Exception:
        return {}
    for sub in ("voyages/active", "voyages/complete"):
        path = adm / sub / f"{voyage_id}.json"
        if path.exists():
            try:
                return json.loads(path.read_text(encoding="utf-8"))
            except Exception:
                continue
    return {}


def resolve_voyage_branch_for_order(order_data: Dict[str, Any]) -> str:
    """Resolve voyageBranch for an order, walking the propagation chain:

      1. order.voyageBranch              (explicit on the order)
      2. parent_voyage.branch            (inherited from voyage)
      3. MAESTRO_SPRINT_BRANCH env       (operator-level, current shell)
      4. ""                              (loose — caller must refuse)

    BUG-ADM-2026-0009: this is the single source of truth for an order's
    branch identity. dispatch_crew calls it, persists the resolved value
    back to the order JSON if it came from layers 2 or 3, so every
    subsequent role in the order's roleSequence sees the same branch
    without re-resolving.

    Also emits a BRANCH_MISMATCH lifecycle event (defence-in-depth) when
    the order has an explicit voyageBranch that disagrees with its parent
    voyage's branch — operator-edited drift is the most likely cause.
    """
    if not isinstance(order_data, dict):
        return os.environ.get("MAESTRO_SPRINT_BRANCH", "").strip()

    explicit = (order_data.get("voyageBranch") or "").strip()
    voyage_id = order_data.get("voyageId") or ""
    voyage_branch = ""
    if voyage_id:
        voyage = _load_voyage_by_id(voyage_id)
        voyage_branch = (voyage.get("branch") or voyage.get("voyageBranch") or "").strip()

    if explicit:
        if voyage_branch and voyage_branch != explicit:
            try:
                write_lifecycle_event(
                    "BRANCH_MISMATCH",
                    f"{order_data.get('orderId', '?')}: order.voyageBranch="
                    f"`{explicit}` but voyage {voyage_id}.branch=`{voyage_branch}` "
                    "— honouring the order. Reconcile by hand if this drift is "
                    "unintentional."
                )
            except Exception:
                pass
        return explicit

    if voyage_branch:
        return voyage_branch

    return os.environ.get("MAESTRO_SPRINT_BRANCH", "").strip()


def _persist_voyage_branch_to_order(item: Dict[str, Any], voyage_branch: str) -> None:
    """Write the resolved voyageBranch back to the order JSON on disk.

    BUG-ADM-2026-0009: when resolve_voyage_branch_for_order pulls the
    branch from the parent voyage or the env var, persist it onto the
    order so the next role in roleSequence reads it directly. Single
    source of truth from this point onward — no re-resolution races.
    """
    try:
        path = Path(item["path"])
        data = item.get("data", {})
        if data.get("voyageBranch") == voyage_branch:
            return  # already up to date
        data["voyageBranch"] = voyage_branch
        path.write_text(json.dumps(data, indent=2), encoding="utf-8")
        item["data"] = data
    except Exception as exc:
        print_warn(
            f"Could not persist voyageBranch={voyage_branch} to {item.get('id', '?')}: {exc}"
        )


def _reset_crew_tracking(crew_num: int, order_id: str) -> None:
    """Reset crew tracking files for a fresh order dispatch (BUG-MSO-2026-0030).

    Overwrites files_modified.json, activity.jsonl, activity.txt, and progress.md
    so stale paths from previous orders/voyages don't carry forward.
    Files preserved intentionally: crew.log, ralph-state.md, state.json, heartbeat.txt
    (those are already reset elsewhere in the dispatch path).
    """
    crew_dir = get_crew_dir(crew_num)
    crew_dir.mkdir(parents=True, exist_ok=True)
    resets = {
        "files_modified.json": "[]\n",
        "activity.jsonl": "",
        "activity.txt": "",
        "progress.md": f"# Crew {crew_num} Progress — {order_id}\n\n## Status: RUNNING\n",
    }
    for filename, content in resets.items():
        target = crew_dir / filename
        try:
            target.write_text(content, encoding="utf-8")
        except OSError as e:
            print_warn(f"Crew {crew_num}: Failed to reset {filename}: {e}")


def _validate_role_tier_before_launch(item: Dict[str, Any]) -> None:
    """FTR-MSO-2026-0505 (Captain ruling 2026-08-18): community tier may not
    dispatch SEC, DOC or REL — community is limited to INV/PLN/BLD/TST.

    Raises RuntimeError (caught by dispatch_squad, same contract as
    _validate_mcp_before_launch / _validate_governance_before_launch) with a
    licence-tier message that names the tier and the upgrade path — never a
    bare role-not-found failure. Resolves legacy nautical aliases (LKT/SCR/
    COX) to their canonical code first so the gate can't be sidestepped by
    alias spelling.
    """
    from maestro import auth
    from maestro.licence import RENEWAL_CONTACT_URL
    from maestro.roles.loader import LEGACY_ALIASES

    role = item.get("role", "")
    canonical = LEGACY_ALIASES.get(role, role)
    if canonical not in auth.TIER_GATED_ROLES:
        return
    if auth.has_tier({"pro", "team", "enterprise"}):
        return

    order_id = item.get("id", "?")
    msg = (
        f"Refusing to dispatch {role} for {order_id}: the {canonical} role "
        f"requires a Pro, Team or Enterprise licence (community tier is "
        f"limited to INV/PLN/BLD/TST). Upgrade: {RENEWAL_CONTACT_URL}"
    )
    print_error(msg)
    write_lifecycle_event(
        "ROLE_TIER_BLOCK",
        f"Crew blocked — {order_id} ({role}): community tier cannot dispatch {canonical}.",
    )
    raise RuntimeError(msg)


def dispatch_squad(crew_num: int, item: Dict[str, Any], max_iterations: int = 25,
                   timeout_minutes: int = 60, voyage_branch: str = "",
                   max_turns: int = 200) -> Optional[int]:
    """Dispatch a crew to work on a queue item. Returns PID or None."""
    codename = _get_crew_name(crew_num)

    print_info(f"Dispatching Crew {crew_num} ({codename}) as {item['role']} for {item['id']}...")

    order_data = item.get("data", {})
    role = item.get("role", "")

    # FTR-MSO-2026-0505: role-tier gate — refuse before any branch/worktree
    # resolution work is spent on an order this tier can never run.
    try:
        _validate_role_tier_before_launch(item)
    except RuntimeError:
        return None

    # BUG-ADM-2026-0009: resolve voyageBranch via the order/voyage/env chain.
    # The chain takes precedence over the dispatcher's `voyage_branch`
    # parameter — callers (run_dispatcher) compute that argument from
    # voyageId pattern matching (e.g. `voyage/<id>`) which can disagree
    # with the voyage JSON's actual `branch` field (Copilot review on
    # PR #58). The order/voyage entry wins; the parameter is a fallback
    # used only when the chain returns empty.
    resolved_branch = resolve_voyage_branch_for_order(order_data)
    if resolved_branch:
        effective_branch = resolved_branch
        # If the caller passed an explicit voyage_branch argument that
        # disagrees with the resolved value, log it — the resolved value
        # wins but the drift might be intentional (operator one-shot).
        if voyage_branch and voyage_branch != resolved_branch:
            try:
                write_lifecycle_event(
                    "BRANCH_MISMATCH",
                    f"{item.get('id', '?')}: dispatch arg voyage_branch="
                    f"`{voyage_branch}` overridden by resolved value "
                    f"`{resolved_branch}` (order/voyage wins)."
                )
            except Exception:
                pass
    else:
        effective_branch = voyage_branch or ACTIVE_VOYAGE_BRANCH

    # Persist the resolved value back to the order JSON so the next role in
    # roleSequence sees it directly and downstream handoffs can carry it.
    if effective_branch and effective_branch != order_data.get("voyageBranch"):
        _persist_voyage_branch_to_order(item, effective_branch)
        order_data = item.get("data", order_data)

    target_repo = order_data.get("targetRepo", "")
    project_acronym = order_data.get("project", "")

    # BUG-MSO-2026-0245: per-order turn-budget override. A heavy order/role can raise
    # its turn budget above the dispatch-level --max-turns via order JSON fields:
    #   "maxTurnsByRole": {"TST": 120}   (per-role; wins for that role)
    #   "maxTurns": 120                  (whole-order; all roles)
    # Falls back to the dispatch-level max_turns when neither is set.
    effective_max_turns = max_turns
    _by_role = order_data.get("maxTurnsByRole") or {}
    try:
        if isinstance(_by_role, dict) and role in _by_role:
            effective_max_turns = int(_by_role[role])
        elif order_data.get("maxTurns"):
            effective_max_turns = int(order_data["maxTurns"])
    except (TypeError, ValueError):
        effective_max_turns = max_turns  # malformed override → ignore, keep default
    # A turn budget must be >= 1; a non-positive override (e.g. 0 or -5) would be
    # invalid / cause immediate termination, so ignore it and keep the default
    # (Copilot PR #110).
    if effective_max_turns < 1:
        effective_max_turns = max_turns
    if effective_max_turns != max_turns:
        write_lifecycle_event(
            "DISPATCH",
            f"{item['id']} ({role}): per-order turn budget {effective_max_turns} "
            f"(override of dispatch default {max_turns}) — BUG-0245"
        )
    if not target_repo:
        target_repo = _resolve_target_repo_from_project(order_data)

    # BUG-ADM-2026-0008 + BUG-ADM-2026-0009: combined dispatch guard.
    #   - All roles need a resolvable voyageBranch (BUG-0009 — every role
    #     writes some artefact and silent misrouting hits all of them)
    #   - SHP/BOS additionally need a resolvable targetRepo (BUG-0008 —
    #     code/test crews otherwise dispatch against a placeholder string
    #     and exit 1-iteration with no commits, burning ~$0.40 each)
    missing: list[str] = []
    if not effective_branch:
        missing.append("voyageBranch")
    if role in _REQUIRES_TARGET_REPO_ROLES and not target_repo:
        missing.append("targetRepo")

    if missing:
        msg = (
            f"Refusing to dispatch {role} for {item['id']}: "
            f"{', '.join(missing)} not resolvable "
            f"(project={project_acronym or 'unknown'}). "
            "Set order.voyageBranch (or voyage.branch on the parent voyage), "
            "and 'repo' under projects.json[<project>] for SHP/BOS roles."
        )
        print_error(msg)
        try:
            write_lifecycle_event("DISPATCH_BLOCK", msg)
        except Exception:
            pass
        try:
            mark_work_item_failed(item, reason=f"{', '.join(missing)} not resolved")
        except Exception:
            pass
        return None

    # FTR-MSO-2026-0377: multi-repo dispatch routing. In a workspace with a
    # ``repos`` map, ``targetRepo`` is load-bearing for CHECKOUT resolution — the
    # crew's worktree must come from the RIGHT product repo. Two pre-dispatch
    # gates (both before any claim / crew spawn, so a bad order costs nothing):
    #   1. Unknown targetRepo (not in the map) → refuse loudly (no silent wrong
    #      checkout, no wasted crew tokens).
    #   2. Known but no checkout could be resolved/cloned (offline first-use) →
    #      hold the order rather than dispatch a crew against nothing.
    # Single-repo/embedded workspaces (no map) skip this entirely and keep the
    # byte-identical legacy path (repo_root=None / repo_name="").
    repo_root_for_worktree: Optional[Path] = None
    repo_name_for_worktree = ""
    if target_repo and _repos_map_configured():
        _map_entry = _resolve_repo_map_entry(target_repo)
        if _map_entry is None:
            known = ", ".join(sorted(_workspace_repos_map().keys())) or "(none)"
            msg = (
                f"Refusing to dispatch {role} for {item['id']}: targetRepo "
                f"'{target_repo}' is not in the workspace repos map "
                f"(known: {known}). Fix the order's targetRepo, or add the repo "
                f"to workspace.json artefacts.repos / the registry (FTR-0377)."
            )
            print_error(msg)
            try:
                write_lifecycle_event("DISPATCH_BLOCK", msg)
            except Exception:
                pass
            try:
                mark_work_item_failed(item, reason=f"unknown targetRepo '{target_repo}'")
            except Exception:
                pass
            return None
        repo_name_for_worktree = _map_entry[0]
        try:
            repo_root_for_worktree = ensure_repo_checkout(
                target_repo, project_acronym=project_acronym)
        except Exception as _rc_exc:
            repo_root_for_worktree = None
            write_lifecycle_event(
                "WARN",
                f"{item['id']}: ensure_repo_checkout('{target_repo}') raised "
                f"{type(_rc_exc).__name__}: {_rc_exc} (FTR-0377)")
        if repo_root_for_worktree is None:
            msg = (
                f"Refusing to dispatch {role} for {item['id']}: could not "
                f"resolve a checkout for targetRepo '{target_repo}' "
                f"(offline first-clone, or misconfigured remote) (FTR-0377)."
            )
            print_error(msg)
            try:
                write_lifecycle_event("DISPATCH_BLOCK", msg)
            except Exception:
                pass
            try:
                mark_work_item_failed(item, reason=f"no checkout for '{target_repo}'")
            except Exception:
                pass
            return None

    # BUG-MSO-2026-0389: solo/shared SINGLE-repo mode (no repos map, so the
    # multi-repo block above left repo_root_for_worktree=None). The dispatcher's
    # cwd is the ARTEFACT repo; the crew worktree MUST be created against the
    # PRODUCT repo (that's where the voyage branch and every crew worktree live).
    # Resolve it here — BEFORE claiming the order — so an unresolvable product
    # repo refuses loudly (DISPATCH_BLOCK) instead of silently falling back to
    # the artefact checkout and dispatching an unisolated crew.
    if repo_root_for_worktree is None and get_artefact_mode() != "embedded":
        try:
            repo_root_for_worktree = solo_worktree_repo_root()
        except Exception as _solo_exc:
            repo_root_for_worktree = None
        if repo_root_for_worktree is None:
            msg = (
                f"Refusing to dispatch {role} for {item['id']}: artefact mode is "
                f"'{get_artefact_mode()}' but the product repo could not be resolved. "
                f"Configure 'artefacts.productRepo' (or a 'repos' map) in the "
                f"artefact workspace's workspace.json (BUG-0389). Dispatching "
                f"without an isolated product-repo worktree would edit the primary "
                f"checkout directly."
            )
            print_error(msg)
            try:
                write_lifecycle_event("DISPATCH_BLOCK", msg)
            except Exception:
                pass
            try:
                mark_work_item_failed(item, reason="solo mode: product repo unresolved")
            except Exception:
                pass
            return None

    # BUG-MSO-2026-0273: fast-path convergence for orders with a pending salvage branch.
    # When _requeue_for_convergence_retry sets convergenceRetry.salvageBranch, the crew's
    # work is already done — skip role invocation and merge the salvage directly.
    _salvage_info = order_data.get("convergenceRetry") or {}
    _salvage_br = _salvage_info.get("salvageBranch")
    _retry_count_fp = order_data.get("convergenceRetryCount", 0)
    if _salvage_br and _retry_count_fp > 0 and effective_branch:
        _voyage_id_fp = order_data.get("voyageId", "")
        if _voyage_id_fp:
            print_info(
                f"Crew {crew_num}: fast-path convergence for {item['id']} "
                f"(salvage={_salvage_br})"
            )
            # FTR-MSO-2026-0378: fast-converge against the order's product-repo
            # checkout resolved above (single-repo → None/"").
            _handled = _fast_converge_salvage_branch(
                item["id"], _salvage_br, effective_branch, _voyage_id_fp,
                repo_root=repo_root_for_worktree, repo_name=repo_name_for_worktree
            )
            if _handled:
                # Fast-path took ownership — no crew needed.
                return None
            # _handled is False: salvage branch missing, fall through to normal dispatch.
            print_info(
                f"Crew {crew_num}: salvage branch absent for {item['id']} — "
                f"dispatching normal role re-run"
            )

    # Generate prompt
    prompt_file = generate_prompt_for_item(item)

    # Mark item as in progress.
    # FTR-MSO-2026-0374: in SHARED mode the claim is by-commit (first push wins)
    # — the artefact repo is the cross-machine mutex. A lost claim race means
    # another engineer's dispatcher got there first: release locally and spawn
    # NO crew (no error). Solo/embedded modes keep the plain in-place claim.
    if get_artefact_mode() == "shared":
        from maestro.core import artefact_sync
        # Belt-and-braces tier gate at dispatch (startup already hard-gated).
        if not artefact_sync.shared_tier_ok():
            write_lifecycle_event(
                "WARN",
                f"{item['id']} shared-mode dispatch skipped — licence tier does "
                f"not permit shared artefact repo (FTR-0374)")
            return None
        _claim = artefact_sync.claim_order_shared(
            item, crew_num, workspace_dir=get_artefact_root())
        if not _claim.won:
            # RELEASED{lost-claim-race} already recorded + logged by the module.
            return None
    else:
        mark_work_item_in_progress(item, crew_num)

    # BUG-MSO-2026-0294 defence-in-depth: re-validate the claim immediately
    # before launch. If the on-disk file no longer carries THIS dispatch's
    # claim (concurrent mutation, git rewind between selection and launch),
    # abort rather than launch a duplicate crew. Items without a queue file
    # (synthetic test items, already-moved files) skip the check.
    _claim_path = item.get("path")
    if _claim_path and Path(_claim_path).exists():
        try:
            _claim_check = json.loads(Path(_claim_path).read_text(encoding="utf-8"))
            _claimed_crew = (_claim_check.get("assignedTo") or {}).get("crew")
            if _claim_check.get("status") != "IN_PROGRESS" or _claimed_crew != crew_num:
                if _ws_for_item(item) is not None:
                    order_ledger.record_released(item["id"], "claim re-validation failed pre-launch",
                                                 workspace_dir=_ws_for_item(item))
                write_lifecycle_event(
                    "WARN",
                    f"{item['id']} claim re-validation failed pre-launch "
                    f"(status={_claim_check.get('status')}, assignedTo.crew={_claimed_crew}, "
                    f"expected crew {crew_num}) — aborting dispatch (BUG-0294)"
                )
                return None
        except (OSError, json.JSONDecodeError):
            pass  # unreadable file — existing error paths handle it

    # BUG-MSO-2026-0030: reset tracking files so stale data from previous
    # orders/voyages doesn't carry forward into this crew's run.
    _reset_crew_tracking(crew_num, item["id"])

    if effective_branch and target_repo:
        ensure_voyage_branch_exists(target_repo, effective_branch, project_acronym=project_acronym)

    # v8.13: Track dispatched repos for post-voyage PR creation
    if target_repo:
        title = item.get("title", item.get("id", ""))
        _SESSION_TARGET_REPOS.setdefault(target_repo, []).append(f"{item['id']}: {title}")
        # v2.0.2: Track voyage branch per repo
        if effective_branch:
            _SESSION_REPO_BRANCHES[target_repo] = effective_branch

    # BUG-MSO-2026-0240: Use per-crew git worktree on a per-crew branch so
    # concurrent crews of the same voyage never share a working tree or
    # git index.  Each crew gets:
    #   worktree: .mso/worktrees/<voyage_id>/crew<N>  (FTR-MSO-2026-0364; a
    #             legacy voyages/active/<voyage_id>/.worktree-crew<N> dir is
    #             reused while it exists)
    #   branch:   crew/<voyage_id>-<N>  (branched from voyage branch at dispatch time)
    # MAESTRO_SPRINT_BRANCH is set to the crew branch so the branch guard
    # allows mutations on that branch.  On order completion, fleet_runner
    # calls merge_crew_branch_into_voyage() to converge the crew's work back
    # onto the voyage branch before PR creation.
    voyage_id = order_data.get("voyageId", "")
    worktree_path = None
    _crew_branch = effective_branch  # fallback: branch guard armed with voyage branch
    if effective_branch and voyage_id:
        try:
            from maestro.core.worktrees import (
                WorktreeBranchDrift, crew_branch_name, prepare_crew_worktree,
                worktree_head_branch,
            )
            # FTR-MSO-2026-0377: in multi-repo mode the worktree is created
            # against the resolved product-repo checkout (repo_root) and named
            # per-repo (crew<N>-<repoName>). Single-repo keeps the exact legacy
            # positional call — no routing kwargs — so behaviour is byte-identical.
            if repo_name_for_worktree or repo_root_for_worktree is not None:
                wt = prepare_crew_worktree(
                    voyage_id, crew_num, effective_branch,
                    repo_root=repo_root_for_worktree,
                    repo_name=repo_name_for_worktree)
            else:
                wt = prepare_crew_worktree(voyage_id, crew_num, effective_branch)
            _crew_branch = crew_branch_name(voyage_id, crew_num)
            # BUG-MSO-2026-0544: a second, independent assertion at the actual
            # launch gate — the last point before a crew process starts. Even
            # though prepare_crew_worktree() now repairs-and-refuses on a
            # branch mismatch internally, this makes it impossible for ANY
            # future worktree-prep code path (including one that doesn't go
            # through worktrees.py) to hand dispatch a worktree that isn't
            # provably on its expected crew branch. PSG's crew3 worktree was
            # checked out to `master` with a pre-voyage HEAD and ran anyway
            # (#367, #368).
            actual_branch = worktree_head_branch(wt)
            if actual_branch != _crew_branch:
                raise WorktreeBranchDrift(
                    f"worktree at {wt} is on branch "
                    f"`{actual_branch or '<unknown/detached>'}`, not the "
                    f"expected crew branch `{_crew_branch}` — refusing to "
                    "dispatch (BUG-MSO-2026-0544).",
                    actual_branch=actual_branch, expected_branch=_crew_branch,
                )
            worktree_path = str(wt)
            write_lifecycle_event(
                "DISPATCH",
                f"Crew {crew_num}: isolated worktree ready at {wt} "
                f"(voyage={voyage_id}, crew_branch={_crew_branch})"
            )
        except Exception as wt_exc:
            # BUG-MSO-2026-0345: collapse embedded newlines — lifecycle.log is
            # one line per event, so git's "fatal: ..." detail on a second
            # line was silently dropped (message truncated after 'Preparing
            # worktree' in the PSG report). Widened cap keeps the full detail.
            err_summary = " ".join(f"{type(wt_exc).__name__}: {wt_exc}".split())[:500]
            print_warn(
                f"Crew {crew_num}: Per-crew worktree prepare failed ({err_summary}) — "
                "HOLDING order (isolation could not be established)"
            )
            try:
                write_lifecycle_event(
                    "WORKTREE_FAIL",
                    f"Crew {crew_num} voyage={voyage_id} branch={effective_branch}: {err_summary}"
                )
            except Exception:
                pass
            # BUG-MSO-2026-0389: NEVER dispatch a crew without an isolated
            # worktree. The pre-0389 fallback let the crew "self-manage",
            # editing the operator's primary product checkout directly (the
            # dogfood incident). Release the claim to PENDING (WORKTREE_REQUIRED)
            # and refuse to spawn — the next tick retries once the transient
            # cause clears (or the operator fixes a persistent one).
            hold_order_worktree_required(
                item,
                f"crew worktree prepare failed (voyage={voyage_id}, "
                f"branch={effective_branch}): {err_summary}",
                crew_num=crew_num, voyage_id=voyage_id,
                repo_root=repo_root_for_worktree,
                repo_name=repo_name_for_worktree)
            return None

    # MCP registry validation — refuse if role is not permitted to use required servers
    try:
        _validate_mcp_before_launch(item, order_data)
    except RuntimeError:
        return None

    # Governance validation (FTR-MSO-2026-0397) — refuse to launch a governed
    # crew against a tampered / rolled-back / stale signed policy bundle.
    try:
        _validate_governance_before_launch(item)
    except RuntimeError:
        return None

    # v2.0.6.1: Clear stale ralph-state.md before dispatch.
    # Prevents v8.4 early-completion detection from reading the previous crew's
    # COMPLETE state in the same monitoring tick as the new dispatch, which caused
    # new orders to be immediately archived before the crew could do any work.
    ralph_file = get_crew_dir(crew_num) / "ralph-state.md"
    try:
        ralph_file.unlink(missing_ok=True)
    except OSError as e:
        # If we fail to unlink, log and fall back to truncating/overwriting the file
        print_warn(f"Crew {crew_num}: Failed to remove stale ralph-state.md at {ralph_file}: {e}. Falling back to truncate.")
        try:
            # Truncate/overwrite so that stale COMPLETE state cannot be read
            with open(ralph_file, "w", encoding="utf-8") as f:
                f.write("")
        except OSError as e2:
            print_warn(f"Crew {crew_num}: Failed to truncate ralph-state.md at {ralph_file}: {e2}. Stale state may persist.")

    # Start the crew (returns PID, fully detached).
    # BUG-ADM-2026-0009 (Copilot review on PR #58): pass `effective_branch`
    # — the resolved value from order/voyage/env — so MAESTRO_SPRINT_BRANCH
    # injected into the crew env is correct, keeping branch_guard armed.
    # BUG-MSO-2026-0240: MAESTRO_SPRINT_BRANCH = per-crew branch so branch guard
    # allows git mutations on the crew branch (not the voyage branch).
    pid = start_crew_process(
        crew_number=crew_num,
        role=role,
        order_id=item["id"],
        prompt_file=prompt_file,
        max_iterations=max_iterations,
        timeout=timeout_minutes,
        voyage_branch=_crew_branch,
        repo_path="",
        project_acronym=project_acronym,
        worktree_path=worktree_path or "",
        max_turns=effective_max_turns,
    )

    if pid:
        ACTIVE_PROCESSES[crew_num] = pid
        ORDERS_IN_TRANSITION.discard(item["id"])  # BUG-MSO-2026-0017: clear transition gate on dispatch
        print_ok(f"Crew {crew_num} ({codename}) dispatched - PID {pid}")
        print_info(f"  > {item['type']}: {item['id']} - {item['title'][:50]}")
        write_lifecycle_event("DISPATCH", f"Crew {crew_num} ({codename}) dispatched as {item['role']} for {item['id']}")
    else:
        print_error(f"Failed to dispatch Crew {crew_num}")
        write_lifecycle_event("ERROR", f"Crew {crew_num} failed to start for {item['id']}")

    return pid


def print_dispatcher_status(start_time: datetime, max_crews: int,
                           all_work: List[Dict],
                           review_held: Optional[List[Dict]] = None) -> int:
    """Print dispatcher status board (v7.0). Returns count of active crews."""
    clear_screen()

    elapsed = datetime.now() - start_time
    elapsed_str = str(elapsed).split('.')[0]

    _p = current_persona()
    print()
    print(f"  {C.CYAN}{C.BOLD}+=========================================================================+")
    print(f"  |           {_p.term('product').upper()} DISPATCHER (Auto-Dispatch Mode){' ' * (33 - len(_p.term('product')))}|")
    print(f"  +=========================================================================+{C.RESET}")
    print()

    # v7.0: Escalation banner
    esc_count, blocking_voyages = scan_escalations()
    if esc_count > 0:
        print(f"  {C.RED}{C.BOLD}!!! ESCALATIONS: {esc_count} pending (requires {_p.term('userTitle')}/{_p.term('leadTitle')} review) !!!{C.RESET}")
        if blocking_voyages:
            print(f"  {C.RED}    Blocking {_p.term('sprint').lower()}s: {', '.join(blocking_voyages)}{C.RESET}")
        print()

    print(f"  {C.WHITE}Max Concurrent {_p.term('squad').title()}s:{C.RESET} {max_crews}")
    print(f"  {C.WHITE}Started:{C.RESET}  {start_time.strftime('%Y-%m-%d %H:%M:%S')}  {C.DIM}(Elapsed: {elapsed_str}){C.RESET}")
    print()

    # Count active crews
    active_count = 0
    _squad_col = _p.term("squad").upper()
    print(f"  {C.BOLD}{_squad_col:<18} {'PID':<8} {'STATUS':<12} {'ROLE':<6} {'MODEL':<8} {'ORDER':<22}{C.RESET}")
    print(f"  {C.DIM}{'-'*75}{C.RESET}")

    for crew_num in range(1, 6):
        codename = _get_crew_name(crew_num)
        pid = ACTIVE_PROCESSES.get(crew_num)
        if not pid:
            pid = read_crew_pid(crew_num)
        proc_alive = pid and is_process_alive(pid)
        pid_str = str(pid) if proc_alive else "-"

        state = read_crew_state(crew_num)

        if state:
            status = state.get("status", "UNKNOWN")
            role = state.get("role", "-")
            order_id = state.get("orderId", "-")[:20]

            if not proc_alive and status == "RUNNING":
                status = "CRASHED"
        else:
            status = "IDLE"
            role = "-"
            order_id = "-"

        # v8.7: Resolve model label from role
        model_label = _get_role_model_label(role) if status != "IDLE" else "-"

        # Determine display
        if status == "COMPLETE":
            icon = f"{C.GREEN}[DONE]{C.RESET}"
            status_color = C.GREEN
        elif status == "RUNNING":
            icon = f"{C.YELLOW}[>>>>]{C.RESET}"
            status_color = C.YELLOW
            active_count += 1
        elif status in ["BLOCKED", "ERROR", "CRASHED"]:
            icon = f"{C.RED}[FAIL]{C.RESET}"
            status_color = C.RED
        else:
            icon = f"{C.DIM}[IDLE]{C.RESET}"
            status_color = C.DIM

        crew_label = f"{crew_num}. {codename}"
        print(f"  {icon} {crew_label:<11} {C.CYAN}{pid_str:<8}{C.RESET} "
              f"{status_color}{status:<12}{C.RESET} {role:<6} {model_label:<8} {C.DIM}{order_id}{C.RESET}")

    print(f"  {C.DIM}{'-'*70}{C.RESET}")
    print()

    # v7.0: Unified queue status
    # BUG-MSO-2026-0226: surface review-held count so operators see NAV_REVIEW_PENDING orders
    # Caller passes review_held from the same tick's scan_review_queue(); None = standalone call
    if review_held is None:
        review_held = scan_review_queue()
    print(f"  {C.BOLD}QUEUE STATUS{C.RESET}")
    print(f"  {C.GREEN}Dispatchable:{C.RESET} {len(all_work)} items")
    for item in all_work[:5]:
        queue_tag = item.get("queue", "orders")
        print(f"    {C.DIM}> [{queue_tag}] {item['id']}: {item['title'][:40]} ({item['role']}){C.RESET}")
    if len(all_work) > 5:
        print(f"    {C.DIM}... and {len(all_work)-5} more{C.RESET}")

    # v7.0 + v8.2: Dependency-waiting and gate-blocked items
    if WAITING_ON_DEPS:
        # Separate gate blocks from dependency waits
        gate_items = {k: v for k, v in WAITING_ON_DEPS.items()
                      if any("ROLE GATE:" in d for d in v)}
        dep_items = {k: v for k, v in WAITING_ON_DEPS.items()
                     if not any("ROLE GATE:" in d for d in v)}

        if gate_items:
            print(f"  {C.RED}Role sequence gates:{C.RESET} {len(gate_items)} blocked")
            for item_id, deps in list(gate_items.items())[:3]:
                deps_str = ", ".join(deps[:2])
                print(f"    {C.RED}[GATE]{C.RESET} {item_id} -> {deps_str}")
            if len(gate_items) > 3:
                print(f"    {C.DIM}... and {len(gate_items)-3} more gated{C.RESET}")

        if dep_items:
            print(f"  {C.YELLOW}Waiting on deps:{C.RESET} {len(dep_items)} items")
            for item_id, deps in list(dep_items.items())[:3]:
                deps_str = ", ".join(deps[:3])
                if len(deps) > 3:
                    deps_str += f" +{len(deps)-3} more"
                print(f"    {C.DIM}[WAIT] {item_id} -> {deps_str}{C.RESET}")
            if len(dep_items) > 3:
                print(f"    {C.DIM}... and {len(dep_items)-3} more waiting{C.RESET}")

    # BUG-MSO-2026-0226: show review-held orders so they are never silently absent
    if review_held:
        _p2 = current_persona()
        print(f"  {C.MAGENTA}Awaiting review:{C.RESET} {len(review_held)} order(s) — run `mso review` to approve/revise/reject")
        for item in review_held[:3]:
            print(f"    {C.MAGENTA}[REVIEW]{C.RESET} {item['id']}: {item['title'][:40]} (next: {item['role']})")
        if len(review_held) > 3:
            print(f"    {C.DIM}... and {len(review_held)-3} more awaiting review{C.RESET}")

    print()
    review_suffix = f" | {C.MAGENTA}Awaiting review:{C.RESET} {len(review_held)}" if review_held else ""
    print(f"  {C.WHITE}Active:{C.RESET} {C.YELLOW}{active_count}{C.RESET} | "
          f"{C.WHITE}Available:{C.RESET} {C.GREEN}{max_crews - active_count}{C.RESET} | "
          f"{C.WHITE}Dispatchable:{C.RESET} {len(all_work)} | "
          f"{C.WHITE}Waiting:{C.RESET} {len(WAITING_ON_DEPS)}{review_suffix}")
    if _QUEUE_READ_ERRORS:
        print(f"  {C.RED}[!!] {len(_QUEUE_READ_ERRORS)} unreadable order file(s) in queue — check lifecycle.log for details{C.RESET}")
    print()
    print(f"  {C.DIM}Press Ctrl+C to stop dispatcher.{C.RESET}")
    print()

    return active_count


def _tick_nav_review_auto_approve() -> None:
    """Promote orders in queues/review/ that have exceeded auto_approve_after_hours."""
    admiralty_dir = get_artefact_root()
    review_dir = admiralty_dir / "queues" / "review"
    if not review_dir.exists():
        return
    try:
        gate_cfg = load_gate_config(admiralty_dir)
    except Exception:
        return
    orders_dir = admiralty_dir / "queues" / "orders"
    orders_dir.mkdir(parents=True, exist_ok=True)
    for json_file in list(review_dir.glob("*.json")):
        try:
            data = json.loads(json_file.read_text(encoding="utf-8"))
            paused_at = data.get("navReviewPausedAt", "")
            if not should_auto_approve(data, gate_cfg, paused_at):
                continue
            order_id = data.get("orderId") or data.get("id") or json_file.stem
            data.pop("navReviewPausedAt", None)
            # FTR-MSO-2026-0427: name the gate that timed out, then drop the
            # transition markers so a released order carries no stale gate label.
            gate_label = data.get("reviewGate", "")
            gate_note = f" at gate {gate_label}" if gate_label else ""
            for _gate_field in ("reviewGate", "reviewGateFrom", "reviewGateTo"):
                data.pop(_gate_field, None)
            # BUG-MSO-2026-0205: a standalone plan-approval order has no next role —
            # auto-approve archives it COMPLETE (releasing dependents), not re-queue.
            if data.get("planApprovalOnly"):
                data["status"] = "COMPLETE"
                data["completedAt"] = datetime.now().isoformat()
                data.pop("planApprovalOnly", None)
                archive_dir = admiralty_dir / "orders" / "complete"
                archive_dir.mkdir(parents=True, exist_ok=True)
                (archive_dir / json_file.name).write_text(json.dumps(data, indent=2), encoding="utf-8")
                json_file.unlink()
                _mark_order_terminal_now()
                print_ok(f"Order {order_id} plan auto-approved after timeout -> COMPLETE (dependents released)")
                write_lifecycle_event("NAV_REVIEW_AUTO_APPROVED", f"{order_id} plan auto-approved after timeout -> COMPLETE")
                continue
            data["status"] = "PENDING"
            dest = orders_dir / json_file.name
            dest.write_text(json.dumps(data, indent=2), encoding="utf-8")
            json_file.unlink()
            print_ok(f"Order {order_id} auto-approved after timeout{gate_note} -> advancing to {data.get('targetRole', '?')}")
            write_lifecycle_event("NAV_REVIEW_AUTO_APPROVED", f"{order_id} auto-approved after timeout{gate_note} -> {data.get('targetRole', '?')}")
        except Exception as e:
            print_warn(f"Auto-approve tick error for {json_file}: {e}")


def run_dispatcher(max_crews: int = 2, stagger_delay: int = 120,
                   max_iterations: int = 25, timeout_minutes: int = 60,
                   max_turns: int = 200):
    """Run the auto-dispatcher loop.

    Voyage branch comes from the MAESTRO_SPRINT_BRANCH environment variable
    set before launching fleet-runner (typically via Launch-FleetCommand.bat).
    """
    global SHUTDOWN_REQUESTED

    # FTR-MSO-2026-0505 (Captain ruling 2026-08-18): community tier is capped
    # at 2 concurrent crews. Clamped here — a single choke point mutating the
    # local `max_crews` used for the rest of this function — rather than at
    # the argparse layer, so the Hub's dispatch endpoint (which shells out to
    # `mso dispatch`) and any direct run_dispatcher() call are covered by the
    # same gate, not just the CLI flag. MAESTRO_SKIP_AUTH bypasses via
    # auth.has_tier, and an unlicensed install (community) IS clamped — that
    # is the community limit, not a bypass of it.
    from maestro import auth as _auth
    from maestro.licence import RENEWAL_CONTACT_URL as _RENEWAL_URL
    _requested_max_crews = max_crews
    max_crews = _auth.community_crew_cap(max_crews)
    if max_crews != _requested_max_crews:
        print_warn(
            f"Community tier is capped at {_auth.COMMUNITY_MAX_CREWS} concurrent "
            f"crews — requested {_requested_max_crews}, using {max_crews}. "
            f"Upgrade to Pro/Team/Enterprise for more: {_RENEWAL_URL}"
        )
        write_lifecycle_event(
            "CREW_CAP_CLAMPED",
            f"Community tier: max-crews clamped {_requested_max_crews} -> {max_crews} (FTR-0505)"
        )

    _report_licence_keyring_warning()

    # Dispatcher PID lock - prevent duplicate dispatchers
    dispatcher_lock = get_artefact_root() / "dispatcher.pid"
    if dispatcher_lock.exists():
        try:
            old_pid = int(dispatcher_lock.read_text(encoding='utf-8').strip())
            if is_process_alive(old_pid):
                print_error(f"Another dispatcher is already running (PID {old_pid})")
                print_info("Kill it first: taskkill /F /PID " + str(old_pid))
                return
        except:
            pass
    dispatcher_lock.write_text(str(os.getpid()), encoding='utf-8')

    # v8.2: Load role sequences from templates for gate enforcement
    load_role_sequences()

    print_header("AUTO-DISPATCHER v8.7 — ROLE SEQUENCE GATES")
    print_info(f"Max concurrent crews: {max_crews}")
    print_info(f"Stagger delay: {stagger_delay}s")
    print_info(f"Dispatcher PID: {os.getpid()}")
    print_info("Priority: Explicit > Security > Bugs > Requests > Orders > Defects > Breakdown > High-Level")
    print_info("Dependency checking: ENABLED")
    print_info("Escalation blocking: ENABLED")
    print_info(f"Role sequence gates: ENABLED ({len(ROLE_SEQUENCES)} sequences loaded)")
    print_info("Watching all queues...")
    print()
    write_lifecycle_event("DISPATCH", f"Dispatcher started (PID {os.getpid()}, max-crews={max_crews})")

    # BUG-MSO-2026-0018: Reconstruct in-flight claim table from crew state before first tick.
    # Prevents re-dispatching orders that already have a live crew after a dispatcher restart.
    reclaimed = _reclaim_inflight_from_crew_state()
    if reclaimed:
        print_info(f"Reclaimed {reclaimed} in-flight crew(s) from prior run — skipping their orders")
        write_lifecycle_event("DISPATCH", f"Reclaimed {reclaimed} in-flight crew(s) on startup")

    # BUG-MSO-2026-0294: runtime order ledger — seed on upgrade, compact when large.
    try:
        if order_ledger.seed_if_missing(get_artefact_root()):
            print_info("Order ledger seeded from existing archives + live crew state (BUG-0294)")
            write_lifecycle_event("DISPATCH", "Order ledger seeded on startup (BUG-0294)")
        order_ledger.compact(get_artefact_root())
    except Exception as ledger_exc:
        print_warn(f"Order ledger startup maintenance failed: {ledger_exc}")

    # BUG-MSO-2026-0304: untrack force-added gitignored runtime dirs before any
    # convergence can conflict on them (PSG retest — tracked progress.md).
    try:
        _untracked = untrack_gitignored_runtime_paths()
        if _untracked:
            print_warn(f"Untracked {_untracked} force-added runtime path(s) from git index (BUG-0304)")
    except Exception as _untrack_exc:
        print_warn(f"Runtime-dir untrack failed: {_untrack_exc}")

    # FTR-MSO-2026-0366: solo/shared mode — self-heal the artefact repo's
    # runtime gitignore block so the runtime plane stays git-immune.
    try:
        ensure_artefact_repo_gitignore()
    except Exception as _gi_exc:
        print_warn(f"Artefact repo gitignore self-heal failed: {_gi_exc}")

    # FTR-MSO-2026-0374: SHARED mode is Team/Enterprise only (Captain ruling
    # 0a #5). Hard-gate at the `mode: shared` config switch (dispatcher
    # startup); MAESTRO_SKIP_AUTH is honoured for CI. On an initial artefact
    # fetch+rebase so the first tick's scan already sees remote claims.
    if get_artefact_mode() == "shared":
        from maestro.core import artefact_sync
        artefact_sync.require_shared_tier()  # exit(1) unless Team/Enterprise
        write_lifecycle_event(
            "DISPATCH", "Shared artefact mode active — tier gate passed (FTR-0374)")
        print_info("Artefact mode: SHARED (claim-by-commit, cross-machine dispatch)")
        try:
            artefact_sync.sync_pull_rebase(get_artefact_root(), force=True)
        except Exception as _sync_exc:
            print_warn(f"Startup artefact sync failed: {_sync_exc}")

    # FTR-0149: prune stale worktrees from prior runs before accepting new work
    try:
        from maestro.core.worktrees import prune_stale_worktrees
        # BUG-MSO-2026-0389: in solo/shared mode the worktrees are registered in
        # the PRODUCT repo, not the dispatcher's cwd (artefact repo) — pin the
        # git ops there so they are actually found and pruned.
        try:
            _prune_root = solo_worktree_repo_root()
        except Exception:
            _prune_root = None
        pruned = prune_stale_worktrees(repo_root=_prune_root)
        if pruned:
            print_info(f"Pruned {pruned} stale worktree(s) from prior runs")
            write_lifecycle_event("DISPATCH", f"Pruned {pruned} stale worktree(s) at startup")
    except Exception as prune_exc:
        print_warn(f"Worktree prune at startup failed: {prune_exc}")

    # BUG-MSO-2026-0306: sweep crash-left convergence scratch worktrees
    # (.mso/temp/convergence-*) so a leftover from a prior run never collides
    # with a fresh convergence (the PSG v4.7.3 'already exists' regression).
    try:
        from maestro.core.worktrees import _prune_orphan_convergence_worktrees
        _sw = _prune_orphan_convergence_worktrees()
        if _sw:
            print_info(f"Pruned {_sw} orphaned convergence scratch worktree(s)")
            write_lifecycle_event("DISPATCH", f"Pruned {_sw} orphan convergence worktree(s) at startup (BUG-0306)")
    except Exception as _sw_exc:
        print_warn(f"Convergence scratch prune at startup failed: {_sw_exc}")

    # Run startup reconcile of merged voyages (FTR-MSO-2026-0203)
    try:
        completion_cfg = load_completion_config()
        if completion_cfg["onVoyageComplete"]["archiveVoyageOnMerge"]:
            reconciled = reconcile_merged_voyages(completion_cfg["onVoyageComplete"])
            if reconciled:
                write_lifecycle_event("DISPATCH", f"Startup reconcile: archived {reconciled} merged voyage(s)")
    except Exception as _rec_exc:
        write_lifecycle_event("WARN", f"Startup voyage reconcile failed: {_rec_exc}")

    # BUG-MSO-2026-0411: also backfill merge metadata onto voyages that
    # already auto-finalised to complete/ before their PR was merged — the
    # scan above only touches active/, and without this a merged voyage's PR
    # never gets recorded, so the Hub leaves it stuck in Final Review forever.
    try:
        annotated = reconcile_completed_voyage_pr_merges()
        if annotated:
            write_lifecycle_event(
                "DISPATCH", f"Startup reconcile: annotated {annotated} completed voyage(s) with merge metadata")
    except Exception as _rec_exc:
        write_lifecycle_event("WARN", f"Startup completed-voyage merge reconcile failed: {_rec_exc}")

    # Setup signal handlers
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    def cleanup_dispatcher():
        cleanup_fleet("dispatcher exit")
        try: dispatcher_lock.unlink()
        except: pass

    atexit.register(cleanup_dispatcher)

    start_time = datetime.now()
    last_dispatch_time = datetime.min
    voyage_bell_rung = False  # Only ring voyage bell once when all work completes
    # BUG-MSO-2026-0243: heartbeat so a wedged/livelocked loop is visible in
    # lifecycle.log instead of going silent. Emitted at most every HEARTBEAT_SECONDS.
    # Defensive parse (mirrors MAESTRO_EIGHT_BELLS_GRACE_SECONDS) + clamp to >=1s so a
    # misconfigured env var can neither crash startup nor spin a tight-loop heartbeat.
    last_heartbeat = datetime.min
    try:
        HEARTBEAT_SECONDS = int(os.environ.get("MAESTRO_HEARTBEAT_SECONDS", "120"))
    except (TypeError, ValueError):
        HEARTBEAT_SECONDS = 120
    if HEARTBEAT_SECONDS < 1:
        HEARTBEAT_SECONDS = 1

    # FTR-MSO-2026-0203: idle-watchdog
    _watchdog_cfg = load_completion_config()["idleWatchdog"]
    _idle_since: Optional[datetime] = None  # wall-clock when all-idle started
    _last_outstanding_warn: Optional[datetime] = None  # BUG-0303 WARN throttle

    try:
        while not SHUTDOWN_REQUESTED:
            # BUG-MSO-2026-0262: clear the intra-tick transition gate at the START of each
            # loop iteration. ORDERS_IN_TRANSITION is populated in process_crew_completion()
            # when an order advances to its next role (e.g. BLD->TST); its only job is to stop
            # scan from double-selecting an order mid-handoff within the tick that advanced it.
            # It was previously cleared ONLY on dispatch (dispatch_squad, BUG-0017), so an order
            # advanced while all crew slots were busy stayed gated forever and its next role
            # never dispatched (heartbeat pending=0 with idle crews). Clearing at tick start lets
            # the next scan see it; the PENDING-only filter + the complete_order idempotency
            # guard (BUG-0248) still prevent any double-dispatch.
            ORDERS_IN_TRANSITION.clear()
            # v7.0: Unified queue scan (all 8 queue types, dependency-aware, escalation-aware)
            all_work = scan_all_queues()
            # BUG-MSO-2026-0226: scan review queue once per tick; used for Eight Bells guard
            # and dispatcher status display so both are consistent within one iteration.
            review_held = scan_review_queue()
            # BUG-MSO-2026-0303: orders parked in CONVERGENCE_FAILED / STALLED /
            # AUTO_SERIALIZE-limbo are invisible to scan_all_queues (PENDING-only) but
            # represent real unfinished voyage work. Reconcile manifests against the
            # ledger+archive so the bell, sweep, PR promotion, and idle-reap cannot
            # false-finish a voyage that still has non-COMPLETE orders (PSG retest).
            voyage_outstanding = voyages_outstanding_work()

            # Check if unified monitor is handling display
            monitor_pid_file = get_artefact_root() / "monitor.pid"
            monitor_running = False
            if monitor_pid_file.exists():
                try:
                    mpid = int(monitor_pid_file.read_text(encoding='utf-8').strip())
                    monitor_running = is_process_alive(mpid)
                except:
                    pass

            if not monitor_running:
                # No monitor - show status in this console
                active_count = print_dispatcher_status(start_time, max_crews, all_work, review_held)
            else:
                # Monitor is handling display - just count active crews silently
                active_count = 0
                for cn in range(1, 6):
                    pid = ACTIVE_PROCESSES.get(cn) or read_crew_pid(cn)
                    if pid and is_process_alive(pid):
                        active_count += 1

            # Check if we can dispatch more crews
            available_slots = max_crews - active_count

            if available_slots > 0:
                # Check stagger delay
                time_since_last = (datetime.now() - last_dispatch_time).total_seconds()
                if time_since_last < stagger_delay and last_dispatch_time != datetime.min:
                    remaining = int(stagger_delay - time_since_last)
                    print_info(f"Stagger delay: {remaining}s until next dispatch...")
                else:
                    # Get available crew numbers
                    available_crews = get_available_crews(max_crews)

                    if available_crews:
                        # v7.0: Unified priority — all_work is pre-sorted by tier + priority
                        work_item = all_work[0] if all_work else None

                        # FTR-MSO-2026-0359: offline dispatch gate. After a
                        # NETWORK-classified failure, probe connectivity before
                        # launching a new crew into a possible outage. Running
                        # crews are never touched; probes are cached + backoff-
                        # rate-limited; `resilience.connectivityGate: false`
                        # disables the gate entirely.
                        if work_item and not _offline_gate_allows_dispatch(active_count):
                            print_info(
                                f"OFFLINE hold — dispatch of {work_item['id']} deferred "
                                f"(connectivity gate, FTR-0359)"
                            )
                            work_item = None

                        # FTR-MSO-2026-0452: a STOPPED licence (Team/Enterprise
                        # past its 14-day grace) holds new dispatch the same way
                        # — running crews are never touched, only new launches
                        # are withheld.
                        if work_item and not _licence_gate_allows_dispatch(active_count):
                            print_info(
                                f"LICENCE hold — dispatch of {work_item['id']} deferred "
                                f"(FTR-0452)"
                            )
                            work_item = None

                        if work_item:
                            queue_tag = work_item.get("queue", "orders")
                            print_info(f"Picking [{queue_tag}]: {work_item['id']} (priority {work_item.get('priority', '?')})")

                            crew_num = available_crews[0]
                            # v2.0.1: Per-order voyage branch — read from order's voyageId,
                            # fall back to ACTIVE_VOYAGE_BRANCH for backwards compatibility
                            # v2.0.3: Also check inline voyageBranch (set by defect normalization)
                            order_voyage_branch = (
                                work_item.get("data", {}).get("voyageBranch", "")
                                or _get_voyage_branch_for_order(work_item["id"])
                            )
                            effective_voyage_branch = order_voyage_branch or ACTIVE_VOYAGE_BRANCH
                            # BUG-MSO-2026-0285: per-order/per-role timeout override.
                            # The global --timeout is a ceiling; a heavy order (docker,
                            # integration tests, multi-file refactor) can set
                            # timeoutMinutes to avoid being killed mid-work.
                            effective_timeout = resolve_order_timeout(
                                work_item.get("data", {}), timeout_minutes)
                            if effective_timeout != timeout_minutes:
                                write_lifecycle_event(
                                    "DISPATCH",
                                    f"{work_item['id']}: per-order iteration timeout "
                                    f"{effective_timeout}m (override of global {timeout_minutes}m, BUG-0285)"
                                )
                            pid = dispatch_squad(crew_num, work_item,
                                                max_iterations, effective_timeout,
                                                voyage_branch=effective_voyage_branch,
                                                max_turns=max_turns)
                            if pid:
                                last_dispatch_time = datetime.now()
                                save_fleet_state()

            # v8.4: Early completion detection via ralph-state.md
            # Fixes: crew.py run_hidden() hangs on open pipes (background bash)
            # even after Claude exits. ralph-state shows COMPLETE but state.json
            # still shows RUNNING because crew.py hasn't returned yet.
            for crew_num in list(ACTIVE_PROCESSES.keys()):
                pid = ACTIVE_PROCESSES[crew_num]
                if pid and is_process_alive(pid):
                    ralph_file = get_crew_dir(crew_num) / "ralph-state.md"
                    if ralph_file.exists():
                        try:
                            content = ralph_file.read_text(encoding='utf-8')
                            match = re.search(r'^status:\s*["\']?(\w+)', content, re.MULTILINE)
                            if match:
                                ralph_status = match.group(1)
                                if ralph_status in TERMINAL_STATES:
                                    print_info(f"Crew {crew_num} ralph-state={ralph_status} but process alive (pipe hang) — draining")
                                    write_lifecycle_event("DRAIN_START", f"Crew {crew_num} ralph-state={ralph_status}, pipe-hang detected — entering drain window")
                                    # Update state.json so process_crew_completion reads correct status
                                    state = read_crew_state(crew_num)
                                    if state:
                                        state["status"] = ralph_status
                                        state_file = get_crew_dir(crew_num) / "state.json"
                                        state_file.write_text(json.dumps(state, indent=2), encoding='utf-8')
                                    # Move to draining — process_crew_completion called after drain window
                                    crew_state = read_crew_state(crew_num)
                                    voyage_id = crew_state.get("voyageId", "") if crew_state else ""
                                    DRAINING_PROCESSES[crew_num] = {"pid": pid, "voyage_id": voyage_id, "drained_at": datetime.now()}
                                    del ACTIVE_PROCESSES[crew_num]
                                    # Kill the hung process (stuck on pipes)
                                    try:
                                        os.kill(pid, signal.SIGTERM)
                                    except OSError:
                                        pass
                                    continue
                        except Exception as e:
                            print_warn(f"Crew {crew_num} ralph-state read error: {e}")

            # v7.1: Clean up completed crews - full order lifecycle management
            for crew_num in list(ACTIVE_PROCESSES.keys()):
                pid = ACTIVE_PROCESSES[crew_num]
                if not pid or not is_process_alive(pid):
                    state = read_crew_state(crew_num)
                    status = state.get("status", "") if state else ""
                    if status in TERMINAL_STATES:
                        process_crew_completion(crew_num)
                        del ACTIVE_PROCESSES[crew_num]
                        # Reset to IDLE immediately so the orphaned-state scan below
                        # doesn't re-process this crew in the same dispatcher tick (BUG-MSO-2026-0015)
                        _idle = {"crewNumber": crew_num, "status": "IDLE", "role": "-", "orderId": "-"}
                        (get_crew_dir(crew_num) / "state.json").write_text(json.dumps(_idle, indent=2), encoding='utf-8')
                    elif status and status != "RUNNING":
                        # v7.1 FIX: Dead crew with unrecognized non-RUNNING state
                        # Treat as CRASHED to prevent orphaning orders
                        print_warn(f"Crew {crew_num} dead with unrecognized state '{status}' - treating as CRASHED")
                        write_lifecycle_event("WARN", f"Crew {crew_num} dead with unrecognized state '{status}' - treating as CRASHED")
                        if state:
                            state["status"] = "CRASHED"
                            state_file = get_crew_dir(crew_num) / "state.json"
                        state_file.write_text(json.dumps(state, indent=2), encoding='utf-8')
                        process_crew_completion(crew_num)
                        del ACTIVE_PROCESSES[crew_num]
                        # Reset to IDLE immediately (BUG-MSO-2026-0015)
                        _idle = {"crewNumber": crew_num, "status": "IDLE", "role": "-", "orderId": "-"}
                        (get_crew_dir(crew_num) / "state.json").write_text(json.dumps(_idle, indent=2), encoding='utf-8')

            # v7.1: Clean up orphaned crew states not tracked in ACTIVE_PROCESSES
            # (e.g. from previous dispatcher runs that left stale TIMEOUT/CRASHED states)
            for crew_num in range(1, max_crews + 1):
                if crew_num in ACTIVE_PROCESSES:
                    continue  # Already tracked
                if crew_num in DRAINING_PROCESSES:
                    continue  # In drain window — completion handled by drain-check below
                state = read_crew_state(crew_num)
                if not state:
                    continue
                status = state.get("status", "")
                if status in TERMINAL_STATES or (status and status not in ("RUNNING", "IDLE", "")):
                    pid = state.get("pid")
                    if not pid or not is_process_alive(pid):
                        # Dead crew with terminal/unexpected state - process and reset
                        if status not in TERMINAL_STATES:
                            print_warn(f"Orphaned Crew {crew_num} with unrecognized state '{status}' - treating as CRASHED")
                            write_lifecycle_event("WARN", f"Orphaned Crew {crew_num} state '{status}' - treating as CRASHED")
                            state["status"] = "CRASHED"
                            sf = get_crew_dir(crew_num) / "state.json"
                            sf.write_text(json.dumps(state, indent=2), encoding='utf-8')
                        process_crew_completion(crew_num)
                        # Reset state to IDLE so monitor shows clean
                        state_file = get_crew_dir(crew_num) / "state.json"
                        idle_state = {"crewNumber": crew_num, "status": "IDLE", "role": "-", "orderId": "-"}
                        state_file.write_text(json.dumps(idle_state, indent=2), encoding='utf-8')

            # Drain-check: complete crews that have exited AND waited out the drain window
            drain_window = int(os.environ.get("MAESTRO_SQUAD_DRAIN_SECONDS", "5"))
            _drain_now = datetime.now()
            for crew_num in list(DRAINING_PROCESSES.keys()):
                entry = DRAINING_PROCESSES[crew_num]
                elapsed = (_drain_now - entry["drained_at"]).total_seconds()
                if not is_process_alive(entry["pid"]) and elapsed >= drain_window:
                    write_lifecycle_event("DRAIN_COMPLETE", f"Crew {crew_num} drained after {drain_window}s")
                    process_crew_completion(crew_num)
                    del DRAINING_PROCESSES[crew_num]
                    # Reset to IDLE so orphan scan next tick doesn't re-process (BUG-MSO-2026-0015)
                    _idle = {"crewNumber": crew_num, "status": "IDLE", "role": "-", "orderId": "-"}
                    (get_crew_dir(crew_num) / "state.json").write_text(json.dumps(_idle, indent=2), encoding='utf-8')

            # Post-NAV auto-approve: promote orders that have waited long enough in review
            _tick_nav_review_auto_approve()

            # v8.7: Periodic orphan reset — detect IN_PROGRESS orders with no live crew
            # (Fixes: orders stuck as IN_PROGRESS when crew dies between dispatch and launch)
            reset = reset_orphaned_in_progress_orders()
            if reset > 0:
                write_lifecycle_event("DISPATCH", f"Reset {reset} orphaned IN_PROGRESS order(s) -> PENDING (v8.7 periodic check)")

            # BUG-MSO-2026-0280: Reconciliation pass — self-heal stranded dependents
            # whose auto-queue event did not fire (BLOCKED/STALLED archival, crash, etc.)
            reconcile_stranded_dependents()

            # BUG-MSO-2026-0309: all_work / voyage_outstanding were sampled at the TOP
            # of this tick, but convergence + AUTO_SERIALIZE / CONVERGENCE_FAILED run
            # mid-tick. Re-sample BOTH right before the completion guard so a just-
            # re-queued or just-stranded order is visible and the bell cannot
            # false-finish on stale top-of-tick state.
            all_work = scan_all_queues()
            voyage_outstanding = voyages_outstanding_work()

            # Check if all work is done (no active crews, no pending items in any queue)
            # BUG-MSO-2026-0024: also require the post-completion grace window to have
            # elapsed, so a freshly-unblocked dependent can be dispatched before we
            # declare the voyage done (closes the COMPLETE->DISPATCH false-fire race).
            # BUG-MSO-2026-0226: also require no orders held in queues/review/
            # (NAV_REVIEW_PENDING) — review-held orders are non-terminal and must
            # block Eight Bells just as PENDING orders do.
            # BUG-MSO-2026-0303: a voyage with a stranded non-COMPLETE order (e.g.
            # CONVERGENCE_FAILED after the auto-serialize cap) blocks Eight Bells and
            # is surfaced loudly + throttled so the operator can recover it
            # (mso order retry) rather than seeing a silent false-finish.
            if voyage_outstanding and not all_work and not review_held and not ACTIVE_PROCESSES:
                _now = datetime.now()
                if (_last_outstanding_warn is None
                        or (_now - _last_outstanding_warn).total_seconds() >= 300):
                    _stranded = "; ".join(
                        f"{vid}: {', '.join(oids[:5])}{' …' if len(oids) > 5 else ''}"
                        for vid, oids in voyage_outstanding)
                    write_lifecycle_event(
                        "WARN",
                        f"Eight Bells withheld — {sum(len(o) for _, o in voyage_outstanding)} "
                        f"order(s) not COMPLETE: {_stranded}. Recover stranded orders with "
                        f"`mso order retry <ID>` (BUG-0303)."
                    )
                    _last_outstanding_warn = _now

            if (not ACTIVE_PROCESSES and not DRAINING_PROCESSES and not ORDERS_IN_TRANSITION
                    and not all_work and not review_held and not voyage_outstanding
                    and not voyage_bell_rung and _eight_bells_grace_elapsed()):
                ring_bell()
                write_lifecycle_event("COMPLETE", "All queued work complete - Eight Bells!")
                if WAITING_ON_DEPS:
                    print_info(f"All dispatchable work complete. {len(WAITING_ON_DEPS)} item(s) waiting on dependencies.")
                else:
                    print_info("All work dispatched and completed. Dispatcher idle - watching for new orders...")

                # v2.0.5: Sweep decks — clean stale orders and complete finished voyages
                sweep_decks()

                # v8.6: Post-voyage — refresh requirements matrix from current data
                run_post_voyage_matrix_update()

                # v8.13: Post-voyage — auto-create PRs for repos with completed work
                # v2.0.0: Now a safety net — per-crew PR creation handles most cases
                run_post_voyage_pr_creation()

                # v2.0.0: Reset developer repos back to main
                reset_developer_repos()

                voyage_bell_rung = True
            elif all_work or review_held or voyage_outstanding:
                # New work arrived (or review-held / stranded orders remain) — reset
                # bell so it rings again when next batch completes (BUG-MSO-2026-0226
                # / BUG-MSO-2026-0303).
                voyage_bell_rung = False

            # FTR-MSO-2026-0203: idle-watchdog — track all-crews-idle elapsed time.
            # BUG-MSO-2026-0393: idle is determined by DISPATCHABLE work ONLY —
            # orders that could actually be CLAIMED this tick. `all_work`
            # (scan_all_queues) is already dispatchable-only: dependency-blocked
            # candidates land in WAITING_ON_DEPS, operator-skipped ids are dropped,
            # and review-gated orders live in queues/review (review_held), none of
            # which appear here. HELD items — review-gated (NAV_REVIEW_PENDING),
            # dep-blocked, operator-skipped, and stranded voyage work
            # (voyage_outstanding, recoverable only via `mso order retry`) — cannot
            # dispatch without human action, so a queue of ONLY held items IS idle
            # and MUST self-reap. Previously review_held / voyage_outstanding reset
            # the idle clock, so a review-gated-only queue kept the dispatcher
            # running forever (observed 2026-07-18/19: MSO idle 5.5h with held=2,
            # killed by hand both times; also the cmd /c cls console-flash source).
            # NOTE: this is deliberately distinct from Eight Bells above — the bell
            # still refuses to ring while held/stranded work remains (no false
            # "all complete"); the watchdog merely stops burning resources on a
            # queue nothing can be dispatched from.
            _any_active = bool(ACTIVE_PROCESSES) or bool(DRAINING_PROCESSES)
            if _any_active or all_work:
                _idle_since = None  # reset: running crews or dispatchable work exists
            else:
                if _idle_since is None:
                    _idle_since = datetime.now()
                elif _watchdog_cfg["enabled"]:
                    _idle_elapsed = (datetime.now() - _idle_since).total_seconds() / 60.0
                    _idle_threshold = _watchdog_cfg["idleMinutes"]
                    if _idle_elapsed >= _idle_threshold:
                        _action = _watchdog_cfg["action"]
                        # BUG-MSO-2026-0393: tally the held/skipped work the reap is
                        # deliberately ignoring so the IDLE_REAP event tells operators
                        # WHY the dispatcher exited with items still in the queue.
                        _held_review = len(review_held)
                        _held_deps = len(WAITING_ON_DEPS)
                        _held_stranded = sum(len(oids) for _, oids in voyage_outstanding) \
                            if voyage_outstanding else 0
                        try:
                            _held_skipped = len(load_skipped_order_ids())
                        except Exception:
                            _held_skipped = 0
                        _held_summary = (
                            f"review-gated={_held_review}, dep-held={_held_deps}, "
                            f"stranded={_held_stranded}, skipped={_held_skipped}"
                        )
                        if _action == "warn":
                            write_lifecycle_event("IDLE_TIMEOUT",
                                f"Dispatcher idle {_idle_elapsed:.1f}m >= {_idle_threshold}m — action=warn")
                            print_warn(f"Idle-watchdog: dispatcher idle {_idle_elapsed:.1f}m (threshold {_idle_threshold}m)")
                            _idle_since = datetime.now()  # reset to avoid repeated warn spam
                        elif _action == "cleanup":
                            write_lifecycle_event("IDLE_REAP",
                                f"Dispatcher idle {_idle_elapsed:.1f}m >= {_idle_threshold}m — reaping "
                                f"(cleanup + exit); ignored held work: {_held_summary}")
                            print_info(f"Idle-watchdog: idle {_idle_elapsed:.1f}m >= {_idle_threshold}m — running cleanup and exiting ({_held_summary})")
                            preflight_kill_rogue_processes()
                            preflight_clear_stale_states()
                            SHUTDOWN_REQUESTED = True
                        # action=="none" or anything else: do nothing

            # BUG-MSO-2026-0243: periodic heartbeat. If the loop ever wedges after a
            # convergence failure (or any blocking call), the ABSENCE of this line in
            # lifecycle.log pinpoints when forward progress stopped — instead of the
            # loop going silently dark with idle crews and pending work.
            _hb_elapsed = (datetime.now() - last_heartbeat).total_seconds()
            if _hb_elapsed >= HEARTBEAT_SECONDS:
                _pending = len(all_work) if all_work else 0
                _busy = len(ACTIVE_PROCESSES) + len(DRAINING_PROCESSES)
                _free = max_crews - _busy
                # FTR-MSO-2026-0359: surface the offline hold on the heartbeat so
                # the operator can see WHY nothing new is launching.
                _off = ""
                if _OFFLINE_HOLD:
                    _off_mins = ((datetime.now() - _OFFLINE_SINCE).total_seconds() / 60.0
                                 if _OFFLINE_SINCE else 0.0)
                    _off = (f" | OFFLINE — dispatch held {_off_mins:.0f}m, "
                            f"{_busy} crew(s) riding it out")
                write_lifecycle_event(
                    "HEARTBEAT",
                    f"dispatcher alive — pending={_pending} held={len(review_held)} "
                    f"crews_busy={_busy} crews_free={_free}{_off}"
                )
                last_heartbeat = datetime.now()

                # BUG-MSO-2026-0289: per-voyage finalisation + PR promote, decoupled
                # from the Eight Bells (whole-workspace-idle) gate. A voyage whose
                # own orders are all COMPLETE is finalised and its draft PR promoted
                # here on the heartbeat cadence, even while other voyages / review-
                # held orders keep the fleet busy. Quiet + idempotent.
                try:
                    sweep_decks(quiet=True)
                except Exception as _swx:
                    write_lifecycle_event("WARN", f"heartbeat sweep_decks failed: {_swx}")

            # FTR-MSO-2026-0374: SHARED mode — debounced fetch+rebase of the
            # artefact repo (artefacts.syncIntervalSeconds, default 60) so other
            # engineers' claims/completions become visible to the next scan.
            # Fail-open (offline degrades to last-known state). No-op otherwise.
            if get_artefact_mode() == "shared":
                try:
                    from maestro.core import artefact_sync
                    artefact_sync.sync_pull_rebase(get_artefact_root())
                except Exception:
                    pass

            # FTR-MSO-2026-0366: solo/shared mode — flush the debounced
            # artefact-repo push once per tick (no-op in embedded mode or
            # when nothing is pending / the debounce window hasn't elapsed).
            try:
                flush_artefact_push()
            except Exception:
                pass

            # Sleep before next check
            for _ in range(10):  # 10 second check interval
                if SHUTDOWN_REQUESTED:
                    break
                time.sleep(1)

    except KeyboardInterrupt:
        pass

    # FTR-MSO-2026-0366: never leave the tail of a run unpushed (solo/shared).
    try:
        flush_artefact_push(force=True)
    except Exception:
        pass

    cleanup_fleet("dispatcher stopped")
    write_lifecycle_event("DISPATCH", "Dispatcher stopped")
    print(f"\n  {C.GREEN}Dispatcher stopped.{C.RESET}\n")


# =============================================================================
# MAIN FLEET RUNNER
# =============================================================================

# Legacy manifest-mode run_fleet() removed in v2.0.4 — use --dispatch instead


def _find_window_by_title(title: str) -> bool:
    """Check if a window with the given title exists (Windows only)."""
    if os.name != 'nt':
        return False
    try:
        import ctypes
        hwnd = ctypes.windll.user32.FindWindowW(None, title)
        return hwnd != 0
    except Exception:
        return False


def _spawn_monitor_enabled() -> bool:
    """FTR-MSO-2026-0406: resolve whether auto_launch_monitor() should spawn.

    Machine-level (device-global) display preference — NOT per-workspace, since
    whether a terminal monitor window makes sense depends on how the operator's
    device is used (e.g. headless dispatch host driven via the Hub), not which
    workspace is dispatching. Precedence: env MAESTRO_SPAWN_MONITOR > machine
    config ~/.maestro/config/settings.json `spawnMonitor` > default (True —
    preserves current behaviour; opt-out is explicit).
    """
    env_val = os.environ.get("MAESTRO_SPAWN_MONITOR", "").strip()
    if env_val:
        return env_val not in ("0", "false", "False", "no", "off")

    try:
        from maestro.workspace import get_maestro_home
        settings_path = get_maestro_home() / "config" / "settings.json"
        if settings_path.exists():
            cfg = json.loads(settings_path.read_text(encoding="utf-8"))
            return bool(cfg.get("spawnMonitor", True))
    except Exception:
        pass

    return True


def auto_launch_monitor():
    """Launch the unified Maestro Monitor in a visible window.

    Checks monitor.pid AND window title to avoid launching duplicates.
    The monitor handles all status display, so the dispatcher can run silently.

    FTR-MSO-2026-0406: skipped entirely when machine-level config or the
    MAESTRO_SPAWN_MONITOR env var disables it (e.g. operators driving dispatch
    exclusively through the Maestro Hub, where the terminal monitor is
    redundant and a source of console-flashing / orphaned processes — BUG-0403).
    """
    if not _spawn_monitor_enabled():
        print_info("Maestro Monitor auto-spawn disabled by machine config")
        write_lifecycle_event("MONITOR", "Monitor auto-spawn disabled by machine config")
        return

    from maestro import __version__ as _maestro_version
    monitor_title = f"Maestro Monitor v{_maestro_version}"

    # Check 1: PID file — is the monitor process alive?
    monitor_pid_file = get_artefact_root() / "monitor.pid"
    if monitor_pid_file.exists():
        try:
            mpid = int(monitor_pid_file.read_text(encoding='utf-8').strip())
            if is_process_alive(mpid):
                print_ok("Maestro Monitor already running")
                return
        except:
            pass

    # Check 2: Window title — is there already a visible monitor window?
    if _find_window_by_title(monitor_title):
        print_ok("Maestro Monitor window already exists")
        return

    monitor_py = Path(__file__).resolve().parent / "fleet_monitor.py"
    if not monitor_py.exists():
        monitor_py = get_artefact_root() / "core" / "fleet_monitor.py"
    if not monitor_py.exists():
        print_warn("fleet_monitor.py not found - skipping monitor launch")
        return

    try:
        print(f"\n  {C.CYAN}Launching {monitor_title}...{C.RESET}")
        # BUG-MSO-2026-0407: point the monitor at the ARTEFACT plane, not the
        # product repo. In solo/shared mode get_base_dir()==the product repo,
        # whose .mso is FROZEN since the artefact migration — spawning the
        # monitor there (with no MAESTRO_DIR) made it resolve the dead plane.
        # fleet_monitor.py resolves via get_workspace_dir() (MAESTRO_DIR first,
        # else walk up from cwd), so we set BOTH: MAESTRO_DIR=artefact root in
        # the child env AND cwd=artefact repo root. Embedded mode: artefact root
        # == product/.mso and artefact repo root == product repo, so behaviour is
        # byte-identical to before.
        monitor_repo_root = get_artefact_repo_root()
        monitor_env = os.environ.copy()
        monitor_env["MAESTRO_DIR"] = str(get_artefact_root())
        if os.name == 'nt':
            # Quote paths to handle spaces (e.g. C:\Program Files\Python313\python.exe)
            py_exe = f'"{sys.executable}"'
            mon_script = f'"{monitor_py}"'
            base = f'"{monitor_repo_root}"'
            cmd = f'start "{monitor_title}" cmd /c "cd /d {base} && {py_exe} {mon_script}"'
            _spawn(cmd, identity="fleet_runner", workspace=monitor_repo_root,
                   env=monitor_env, shell=True)
        else:
            _spawn(
                [sys.executable, str(monitor_py)],
                identity="fleet_runner",
                workspace=monitor_repo_root,
                cwd=str(monitor_repo_root),
                env=monitor_env,
                start_new_session=True,
            )
        time.sleep(1)
        print_ok("Maestro Monitor launched")
        write_lifecycle_event("MONITOR", f"{monitor_title} launched")
    except Exception as e:
        print_warn(f"Could not launch monitor: {e}")


def build_parser() -> argparse.ArgumentParser:
    """Build the fleet_runner CLI argument parser (extracted from main() for testability — Copilot PR #87)."""
    parser = argparse.ArgumentParser(
        description="Maestro v2.0.5 - Queue-Based Dispatch with Dependency Precedence",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s --dispatch --max-crews 5
  %(prog)s --cleanup
  %(prog)s --archive-completed
        """
    )
    parser.add_argument("--maestro-dir", type=str, default=None,
                       help="Path to .mso directory (auto-detected from cwd if omitted)")
    parser.add_argument("--cleanup", action="store_true",
                       help="Clean up rogue processes and stale states, then exit")
    # v5.2 Auto-Dispatcher arguments
    parser.add_argument("--dispatch", action="store_true",
                       help="Run in auto-dispatch mode - watches queues and dispatches crews automatically")
    parser.add_argument("--max-crews", type=int, default=5,
                       help="Maximum concurrent crews for dispatch mode (default: 5)")
    parser.add_argument("--stagger-delay", type=int, default=30,
                       help="Seconds between crew dispatches (default: 30)")
    parser.add_argument("--max-iterations", type=int, default=25,
                       help="Max iterations per dispatched crew (default: 25)")
    parser.add_argument("--timeout", type=int, default=25,
                       help="Per-iteration timeout in minutes (default: 25)")
    parser.add_argument("--max-turns", type=int, default=25,
                       help="Max Claude turns per crew iteration (default: 25)")
    parser.add_argument("--convergence-timeout", type=int, default=None, metavar="SECS",
                       help="Per-op timeout for convergence git network ops in seconds "
                            "(default: 60; also configurable via workspace.json "
                            "completion.convergenceNetworkTimeout)")
    # v6.0 Lifecycle management
    parser.add_argument("--archive-completed", action="store_true",
                       help="Archive completed/stalled orders from queues to orders/complete/")
    # v2.0.5 Deck sweep + auto-queue
    parser.add_argument("--sweep-decks", action="store_true",
                       help="Sweep decks: remove stale active orders, complete finished voyages")
    parser.add_argument("--auto-queue", action="store_true",
                       help="Auto-queue orders from orders/active/ whose dependencies are satisfied")
    # v8.2 Role sequence validation
    parser.add_argument("--validate-sequences", action="store_true",
                       help="Validate role sequence gates for all active orders (dry-run)")
    # v8.3 Requirements traceability validation
    parser.add_argument("--validate-traceability", action="store_true",
                       help="Run Requirements Scanner gate check (min 80%% coverage)")

    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()

    global _MAESTRO_DIR_OVERRIDE, _CONVERGENCE_TIMEOUT_CLI_OVERRIDE
    if args.maestro_dir:
        _MAESTRO_DIR_OVERRIDE = Path(args.maestro_dir).resolve()
        # BUG-MSO-2026-0448: surfaced BEFORE any crew/dispatch mode below runs.
        _check_maestro_dir_divergence(_MAESTRO_DIR_OVERRIDE)
    if getattr(args, "convergence_timeout", None) is not None:
        _CONVERGENCE_TIMEOUT_CLI_OVERRIDE = args.convergence_timeout

    print()
    try:
        from maestro import __version__ as _adm_version
    except ImportError:
        _adm_version = "unknown"
    print(f"  {C.CYAN}{C.BOLD}Maestro v{_adm_version}{C.RESET}")
    print(f"  {C.DIM}Queue-Based Dispatch + Dependency Precedence + Role Gates | {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}{C.RESET}")

    if args.cleanup:
        print_header("CLEANUP MODE")
        killed = preflight_kill_rogue_processes()
        print_ok(f"Killed {killed} rogue process(es)")
        # BUG-MSO-2026-0304: untrack any force-added gitignored runtime dirs so they
        # stop dirtying convergence (a resume-oriented cleanup leaves the tree clean).
        try:
            _untracked = untrack_gitignored_runtime_paths()
            print_ok(f"Untracked {_untracked} force-added runtime path(s) from git index")
        except Exception as _ux:
            print_warn(f"Runtime-dir untrack failed: {_ux}")
        # BUG-MSO-2026-0302: marker-based orphan sweep — catches crew-descended
        # processes no PID file references (GKT: PID 28048 survived every cleanup)
        reaped, survivors = sweep_marked_orphans()
        if reaped:
            print_ok(f"Orphan sweep reaped {len(reaped)} marked process(es): {reaped}")
        if survivors:
            print_warn(f"Orphan sweep: {len(survivors)} process(es) SURVIVED — kill manually: {survivors}")
        # BUG-MSO-2026-0500: descendant-group reap — catches what the marker
        # sweep above structurally cannot: find/MSBuild/VBCSCompiler/shells
        # never carry the spawn marker on their OWN command line (only
        # crew.py's argv did), so they were invisible to CommandLine matching.
        # Every crew slot is swept unconditionally, mirroring how this
        # command already force-kills every crew.py PID unconditionally.
        try:
            descendant_reaped = reap_crew_job_objects()
            if descendant_reaped:
                _total = sum(len(v) for v in descendant_reaped.values())
                print_ok(f"Descendant reap: {_total} process(es) across {len(descendant_reaped)} crew slot(s): {descendant_reaped}")
        except Exception as _drx:
            print_warn(f"Descendant reap failed: {_drx}")
        # BUG-MSO-2026-0298: salvage-first — preserve any dirty worktree work
        # BEFORE clearing state, so cleanup never destroys in-flight progress.
        try:
            from maestro.core.worktrees import _salvage_worktree_if_dirty
            _salvaged = 0
            _voyages_active = get_artefact_root() / "voyages" / "active"
            if _voyages_active.exists():
                for _vdir in _voyages_active.iterdir():
                    if not _vdir.is_dir():
                        continue
                    for _wt in _vdir.iterdir():
                        if _wt.is_dir() and _wt.name.startswith(".worktree"):
                            if _salvage_worktree_if_dirty(_wt, _vdir.name, _wt.name) == "salvaged":
                                _salvaged += 1
            # FTR-MSO-2026-0364: canonical runtime home .mso/worktrees/<VID>/*
            _wt_root = get_artefact_root() / "worktrees"
            if _wt_root.exists():
                for _vdir in _wt_root.iterdir():
                    if not _vdir.is_dir():
                        continue
                    for _wt in _vdir.iterdir():
                        if _wt.is_dir():
                            if _salvage_worktree_if_dirty(_wt, _vdir.name, _wt.name) == "salvaged":
                                _salvaged += 1
            if _salvaged:
                print_ok(f"Salvaged {_salvaged} dirty worktree(s) to salvage/ branches")
        except Exception as _salv_exc:
            print_warn(f"Cleanup salvage pass failed: {_salv_exc}")
        cleared = preflight_clear_stale_states()
        print_ok(f"Cleared {cleared} stale state file(s)")
        reset = reset_orphaned_in_progress_orders()
        if reset > 0:
            print_ok(f"Reset {reset} orphaned IN_PROGRESS order(s) -> PENDING")
        else:
            print_ok("No orphaned orders found")
        # v2.0.1: Clean ephemeral crew repo clones (robust Windows removal)
        crew_repos_cleaned = 0
        crew_repos_failed = 0
        for cn in range(1, 6):
            repo_dir = get_crew_dir(cn) / "repo"
            if repo_dir.exists():
                if _robust_rmtree(repo_dir, label=f"Crew {cn}"):
                    crew_repos_cleaned += 1
                else:
                    crew_repos_failed += 1
                    print_warn(f"Crew {cn}: Could not remove {repo_dir} — manual cleanup needed")
        if crew_repos_cleaned > 0:
            print_ok(f"Cleaned {crew_repos_cleaned} ephemeral crew repo clone(s)")
        if crew_repos_failed > 0:
            print_warn(f"{crew_repos_failed} crew repo(s) could not be removed")
        elif crew_repos_cleaned == 0:
            print_ok("No crew repo clones to clean")
        # v8.14: Clean temp working directory
        temp_dir = get_artefact_root() / "temp"
        if temp_dir.exists():
            temp_cleared = 0
            for sub in ("nuget-local", "build-artifacts", "scratch"):
                sub_dir = temp_dir / sub
                if sub_dir.exists():
                    for item in sub_dir.iterdir():
                        if item.name == ".gitkeep":
                            continue
                        if item.is_dir():
                            import shutil
                            shutil.rmtree(item, ignore_errors=True)
                        else:
                            item.unlink(missing_ok=True)
                        temp_cleared += 1
            if temp_cleared > 0:
                print_ok(f"Cleared {temp_cleared} temp artifact(s) from .mso/temp/")
            else:
                print_ok("Temp directory already clean")
        print(f"\n  {C.GREEN}Cleanup complete.{C.RESET}\n")
        return 0

    # v6.0: Archive completed orders
    if args.archive_completed:
        print_header("ARCHIVE COMPLETED ORDERS")
        archived = archive_all_completed_orders()
        if archived == 0:
            print_info("No completed orders found in queues")
        else:
            print_ok(f"Archived {archived} completed order(s) to orders/complete/")
        print(f"\n  {C.GREEN}Archive complete.{C.RESET}\n")
        return 0

    # v2.0.5: Sweep decks
    if args.sweep_decks:
        print_header("SWEEP DECKS (v2.0.5)")
        result = sweep_decks()
        total = result["stale_orders_removed"] + result["voyages_completed"]
        if total == 0:
            print_info("Decks are clean - nothing to sweep")
        print(f"\n  {C.GREEN}Sweep complete.{C.RESET}\n")
        return 0

    # v2.0.5: Auto-queue unblocked orders
    if args.auto_queue:
        print_header("AUTO-QUEUE UNBLOCKED ORDERS (v2.0.5)")
        auto_queue_unblocked_orders("MANUAL")
        print(f"\n  {C.GREEN}Auto-queue complete.{C.RESET}\n")
        return 0

    # v8.2: Validate role sequences (dry-run)
    if args.validate_sequences:
        print_header("ROLE SEQUENCE VALIDATION (v8.2)")
        load_role_sequences()
        if not ROLE_SEQUENCES:
            print_error("No role sequences loaded from templates")
            return 1
        print_ok(f"Loaded {len(ROLE_SEQUENCES)} role sequence(s): {', '.join(ROLE_SEQUENCES.keys())}")
        for otype, seq in sorted(ROLE_SEQUENCES.items()):
            print_info(f"  {otype}: {' -> '.join(seq)}")
        print()

        voyage_status = build_voyage_role_status()
        if not voyage_status:
            print_info("No voyages found with active orders")
            return 0

        # Scan all active orders and check gates (queues + orders/active)
        gate_failures = 0
        gate_passes = 0
        scan_dirs = []

        # Queue directories
        queues_dir = get_queues_dir()
        for qname in ["explicit", "security", "bugs", "orders", "defects",
                       "breakdown", "high-level"]:
            qpath = queues_dir / qname
            if qpath.exists():
                scan_dirs.append(qpath)

        # orders/active directory
        active_dir = get_artefact_root() / "orders" / "active"
        if active_dir.exists():
            scan_dirs.append(active_dir)

        for scan_path in scan_dirs:
            for json_file in scan_path.glob("*.json"):
                try:
                    data = json.loads(json_file.read_text(encoding='utf-8'))
                    vid = data.get("voyageId", "")
                    order_id = data.get("id", json_file.stem)
                    target_role, _ = resolve_order_fields(data)
                    if not vid or vid not in voyage_status:
                        continue
                    passed, missing = check_role_sequence_gate(data, voyage_status[vid])
                    if not passed:
                        gate_failures += 1
                        missing_str = ", ".join(missing)
                        print_warn(f"  GATE BLOCK: {order_id} ({target_role}) in {vid}")
                        print_warn(f"    Prior roles not complete: {missing_str}")
                    else:
                        gate_passes += 1
                except Exception:
                    pass

        print()
        if gate_failures == 0:
            print_ok(f"All role sequence gates PASS ({gate_passes} orders checked across {len(voyage_status)} voyages)")
        else:
            print_error(f"{gate_failures} order(s) BLOCKED by role sequence gates ({gate_passes} pass)")
        print()
        return 0

    # v8.3: Validate requirements traceability
    if args.validate_traceability:
        print_header("REQUIREMENTS TRACEABILITY GATE (v8.3)")
        # v2.0.5: Resolve scanner path from project config, fallback to legacy path
        scanner_project = None
        project_info = load_project_config()
        if project_info and "_config" in project_info:
            scanner_rel = project_info["_config"].get("scannerProject")
            if scanner_rel:
                scanner_project = get_product_repo() / scanner_rel
        if not scanner_project:
            # TODO: Remove legacy fallback once all projects define scannerProject in config
            scanner_project = get_product_repo() / "Uplifted" / "Tools" / "RequirementsScanner"
        if not scanner_project.exists():
            print_error(f"Scanner project not found: {scanner_project}")
            return 1
        print_info("Running Requirements Scanner gate check (--gate --min-coverage 80)...")
        print()
        try:
            result = run_hidden(
                ["dotnet", "run", "--project", str(scanner_project), "--", "--gate", "--min-coverage", "80"],
                capture_output=False,
                timeout=300,
                cwd=str(get_product_repo())
            )
            print()
            if result.returncode == 0:
                print_ok("Requirements traceability gate: PASS")
            else:
                print_error(f"Requirements traceability gate: FAIL (exit code {result.returncode})")
            return result.returncode
        except subprocess.TimeoutExpired:
            print_error("Scanner timed out after 300 seconds")
            return 1
        except FileNotFoundError:
            print_error("dotnet command not found - ensure .NET SDK is installed")
            return 1

    # v5.2: Auto-Dispatch mode
    if args.dispatch:
        # Light pre-flight for dispatch mode
        print_header("PRE-FLIGHT CHECKS (Dispatch Mode)")
        print_info("Checking for rogue processes...")
        killed = preflight_kill_rogue_processes()
        if killed > 0:
            print_warn(f"Killed {killed} rogue process(es)")
        else:
            print_ok("No rogue processes found")

        print_info("Verifying crew directories...")
        preflight_verify_crew_dirs()
        print_ok("Crew directories ready")

        print_info("Verifying queue directories (v7.0 - all queues)...")
        queues_dir = get_queues_dir()
        for qdir in ["explicit", "high-level", "orders", "bugs", "defects",
                      "security", "breakdown", "escalations",
                      "requests/planning", "requests/investigation",
                      "requests/qa", "requests/documentation"]:
            (queues_dir / qdir).mkdir(parents=True, exist_ok=True)
        print_ok("All queue directories ready (8 types + 4 request subtypes)")

        print_info("Checking for orphaned IN_PROGRESS orders...")
        reset = reset_orphaned_in_progress_orders()
        if reset > 0:
            print_warn(f"Reset {reset} orphaned order(s) -> PENDING")
        else:
            print_ok("No orphaned orders found")

        print_info("Validating repo config (placeholder check)...")
        _repo_cfg_errors = validate_placeholder_repo_config()
        if _repo_cfg_errors:
            print_error("Dispatch aborted — workspace still has placeholder repo config:")
            for _err in _repo_cfg_errors:
                print_error(f"  • {_err}")
            print_info("Fix the values above, then re-run `mso dispatch`.")
            print_info("Or run `mso setup --check` to audit the full workspace.")
            write_lifecycle_event(
                "ERROR",
                "Dispatch aborted: placeholder repo config detected — " + "; ".join(_repo_cfg_errors),
            )
            return 1
        print_ok("Repo config looks real (no placeholder values)")

        print(f"\n  {C.GREEN}{C.BOLD}Pre-flight checks PASSED{C.RESET}\n")
        time.sleep(1)

        # Auto-launch the unified Maestro Monitor
        auto_launch_monitor()

        # Run dispatcher
        try:
            run_dispatcher(
                max_crews=args.max_crews,
                stagger_delay=args.stagger_delay,
                max_iterations=args.max_iterations,
                timeout_minutes=args.timeout,
                max_turns=args.max_turns,
            )
            return 0
        except Exception as e:
            print(f"\n  {C.RED}Dispatcher error: {e}{C.RESET}\n")
            cleanup_fleet("error")
            return 1

    parser.error("Please specify --dispatch, --cleanup, or --archive-completed")


if __name__ == "__main__":
    run_cli(main, command="mso dispatch")


# ---------------------------------------------------------------------------
# Rebrand vocabulary (FTR-MSO-2026-0155) — new canonical names
# ---------------------------------------------------------------------------

class TeamRunner:
    """Namespace sentinel for the fleet-runner dispatch subsystem."""


class Sprint:
    """Namespace sentinel representing a voyage/sprint unit of work."""


class Squad:
    """Namespace sentinel representing a crew/squad unit of work."""


# Legacy aliases — kept through v3.x, removed in v4.0
FleetRunner = TeamRunner  # legacy alias (v3.x); removed v4.0
Voyage = Sprint           # legacy alias (v3.x); removed v4.0
Crew = Squad              # legacy alias (v3.x); removed v4.0
dispatch_crew = dispatch_squad  # legacy alias (v3.x); removed v4.0
