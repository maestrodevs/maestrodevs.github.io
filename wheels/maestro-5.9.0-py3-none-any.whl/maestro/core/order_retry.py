# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Shared order-retry core (BUG-MSO-2026-0297 / BUG-MSO-2026-0344).

Extracted from ``maestro/cli.py``'s ``mso order retry`` branch
(PLAN-FTR-MSO-2026-0492 §4.1) so the Hub's ``POST /orders/{id}/retry``
endpoint and the CLI share exactly ONE implementation of the framework's
only recovery verb for a terminal/stranded order — never two copies that
can silently drift apart.

Explicit ``mso: Path`` throughout, no ``find_workspace()``, no CWD — matches
the discipline ``maestro/hub/attention.py`` established for a Hub-callable
module serving N workspaces from one process. Typed exceptions, no
printing, no ``sys.exit`` — callers (CLI, HTTP) map these to their own
presentation.
"""

from __future__ import annotations

import contextlib
import json
import threading
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Optional

# Serialises every workspace_scope() use across this process. The Hub's
# poller serves N workspaces concurrently from one process; an UNGUARDED
# set/restore of fleet_runner._MAESTRO_DIR_OVERRIDE would let a poller tick
# for workspace A write into workspace B's lifecycle log while a retry for B
# holds the override. RLock (not Lock) so retry_order()'s own use nests
# safely inside a caller that already holds the scope (cli.py's cmd_order).
_SCOPE_LOCK = threading.RLock()


@contextlib.contextmanager
def workspace_scope(mso: Path):
    """Serialise + scope fleet_runner's process-global artefact-root override.

    ``fleet_runner.write_lifecycle_event`` / ``_commit_lifecycle_transition`` /
    ``add_skipped_order`` / ``remove_skipped_order`` resolve their target
    workspace from ``fleet_runner._MAESTRO_DIR_OVERRIDE``, a module global —
    none of the four take a workspace argument. ``cli.py``'s ``mso order``
    command sets the override around the whole command, which is correct
    there (one process, one workspace, single-threaded). The Hub is neither:
    its poller (``maestro/hub/poller.py``) serves N registered workspaces
    concurrently, so a bare set/restore here would race it — this is
    PLAN-PLN-MSO-2026-0468 §3.3's trap, relocated from ``fleet_monitor`` to
    ``fleet_runner``. The lock makes this scope the sole writer of the
    override for its duration; the ``finally``-restore makes it safe even
    when the wrapped body raises.

    Correctness requirement for HTTP callers: any endpoint that (directly or
    via :func:`retry_order`) enters this scope MUST be a sync ``def``, not
    ``async def`` — FastAPI runs a sync path operation in its threadpool, so
    the lock only blocks other threadpool work. An ``async def`` would hold
    the lock on the event loop itself and stall every other request.
    """
    import maestro.core.fleet_runner as _fr

    with _SCOPE_LOCK:
        prior = _fr._MAESTRO_DIR_OVERRIDE
        _fr._MAESTRO_DIR_OVERRIDE = mso
        try:
            yield
        finally:
            _fr._MAESTRO_DIR_OVERRIDE = prior


class OrderNotFound(Exception):
    """*order_id* is not in ``orders/complete/``, ``orders/failed/``, or any queue."""

    def __init__(self, order_id: str) -> None:
        self.order_id = order_id
        self.hint = (
            "Check the ID with 'mso status' — retry reopens archived orders "
            "and resets stranded queued orders to PENDING."
        )
        super().__init__(
            f"Order {order_id} not found in orders/complete/, "
            "orders/failed/ or any queue."
        )


class RetryRefused(Exception):
    """Retry refused: archived COMPLETE without --force, or IN_PROGRESS without --force."""

    def __init__(self, order_id: str, message: str, hint: str = "") -> None:
        self.order_id = order_id
        self.hint = hint
        super().__init__(message)


@dataclass
class RetryOutcome:
    """Result of a successful :func:`retry_order` call."""

    order_id: str
    prior_state: str
    new_status: str
    target_role: str
    salvage_note: str
    salvage_branch: Optional[str]
    reason: str


def _newest_salvage_branch(d: dict) -> Optional[str]:
    salvages = d.get("salvageBranches") or []
    if salvages:
        return salvages[-1].get("branch")
    for key in ("convergence", "verify"):
        br = (d.get(key) or {}).get("salvageBranch")
        if br:
            return br
    return None


def _arm_salvage_fast_path(d: dict, no_salvage: bool) -> str:
    """BUG-MSO-2026-0301: wire the newest salvage branch into the fast-converge
    path so the next dispatch merges the preserved work
    (CONVERGENCE_RETRY_FROM_SALVAGE) instead of re-running the role.

    Returns a human-readable note for operator output ('' if none).
    """
    if no_salvage:
        # --no-salvage promises a from-scratch re-run: actively clear any
        # pre-existing fast-converge arming so the dispatcher does NOT merge
        # previously-salvaged work.
        d.pop("convergenceRetry", None)
        d.pop("convergenceRetryCount", None)
        return ""
    branch = _newest_salvage_branch(d)
    if not branch:
        return ""
    d["convergenceRetry"] = {"salvageBranch": branch}
    # BUG-MSO-2026-0344: the dispatch fast-path only fires when
    # convergenceRetryCount > 0 — arm it for orders that stranded without a
    # prior convergence-network retry (e.g. plain STALLED).
    try:
        count = int(d.get("convergenceRetryCount") or 0)
    except (TypeError, ValueError):
        count = 0
    d["convergenceRetryCount"] = max(count, 1)
    return f" (will fast-converge salvaged work from {branch})"


def retry_order(
    mso: Path,
    order_id: str,
    *,
    role: Optional[str] = None,
    reason: str = "",
    force: bool = False,
    no_salvage: bool = False,
) -> RetryOutcome:
    """Reopen a terminal/stranded order in workspace *mso* for re-dispatch.

    Sole implementation of ``mso order retry`` semantics (BUG-MSO-2026-0297 /
    BUG-MSO-2026-0344) — ``cli.py``'s ``retry`` branch and the Hub's
    ``POST /orders/{id}/retry`` endpoint both call this. Explicit ``mso: Path``,
    no globals of its own; the four ``fleet_runner`` calls this makes are
    scoped via :func:`workspace_scope`.

    Raises :class:`OrderNotFound` / :class:`RetryRefused` (typed, no
    printing, no ``sys.exit``) and, from the capability gate,
    ``maestro.identity.gate.CapabilityDenied``.
    """
    from maestro.core import fleet_runner as _fr
    from maestro.core import order_ledger as _ledger
    from maestro.identity.gate import require_capability

    # PLAN-FTR-MSO-2026-0492 §5.1: the gate belongs in the core, not in
    # either wrapper, so every caller (CLI and Hub) is protected identically.
    # `mso` is the artefact `.mso` dir; the gate wants the WORKSPACE ROOT
    # (its parent), matching every other require_capability() call site's
    # find_workspace() return. A no-op outside enterprise/governed
    # workspaces (require_capability short-circuits there).
    require_capability("order.dispatch", workspace=mso.parent)

    archive_file: Optional[Path] = None
    for sub in ("complete", "failed"):
        candidate = mso / "orders" / sub / f"{order_id}.json"
        if candidate.exists():
            archive_file = candidate
            break

    queue_file: Optional[Path] = None
    queue_data: Optional[dict] = None
    if archive_file is None:
        # BUG-MSO-2026-0344: fall back to the queue tree (same coverage as
        # the stranded-order scan: queues/*/ and queues/requests/*/).
        queues_dir = mso / "queues"
        if queues_dir.exists():
            for jf in (list(queues_dir.glob("*/*.json"))
                       + list(queues_dir.glob("*/*/*.json"))):
                try:
                    d = json.loads(jf.read_text(encoding="utf-8"))
                except (OSError, json.JSONDecodeError):
                    continue
                if (d.get("orderId") or d.get("id") or jf.stem) == order_id:
                    queue_file = jf
                    queue_data = d
                    break
        if queue_file is None:
            raise OrderNotFound(order_id)

    if archive_file is not None:
        try:
            data = json.loads(archive_file.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise RetryRefused(order_id, f"Cannot read {archive_file}: {exc}")

        status = (data.get("status") or "").upper()
        if status in ("COMPLETE", "COMPLETED") and not force:
            raise RetryRefused(
                order_id,
                f"Order {order_id} is archived COMPLETE — retrying completed "
                "work re-runs and re-converges it.",
                f"If you really mean it: mso order retry {order_id} --force",
            )

        retry_role = (role or (data.get("stalledBy") or {}).get("role")
                      or data.get("targetRole") or data.get("role") or "BLD")
        data["status"] = "PENDING"
        data["targetRole"] = retry_role
        data.pop("assignedTo", None)
        data.pop("startedAt", None)
        data.pop("requeueCount", None)
        data.pop("networkRetry", None)  # FTR-MSO-2026-0359: reset network-retry track too
        data["retriedAt"] = datetime.now().isoformat()
        data["retriedReason"] = reason or "operator retry"
        salvage_note = _arm_salvage_fast_path(data, no_salvage)
        salvage_branch = (data.get("convergenceRetry") or {}).get("salvageBranch")

        queue_file = mso / "queues" / "orders" / f"{order_id}.json"
        queue_file.parent.mkdir(parents=True, exist_ok=True)
        queue_file.write_text(json.dumps(data, indent=2), encoding="utf-8")
        archive_file.unlink()
        commit_paths = [queue_file, archive_file]
        prior_state = status or "archived"
    else:
        # BUG-MSO-2026-0344: stranded queued order — reset it to PENDING in
        # place (it already sits in a scanned queue dir).
        status = (queue_data.get("status") or "").upper()
        if status == "IN_PROGRESS" and not force:
            raise RetryRefused(
                order_id,
                f"Order {order_id} is IN_PROGRESS in "
                f"queues/{queue_file.parent.name}/ — a crew may still own it.",
                f"If the crew is dead: mso order retry {order_id} --force",
            )

        data = queue_data
        # Preserve the order's own role progression unless overridden.
        retry_role = (role or data.get("targetRole") or data.get("role") or "BLD")
        data["status"] = "PENDING"
        data["targetRole"] = retry_role
        data.pop("assignedTo", None)
        data.pop("startedAt", None)
        data.pop("requeueCount", None)
        data.pop("networkRetry", None)  # FTR-MSO-2026-0359: reset network-retry track too
        data["retriedAt"] = datetime.now().isoformat()
        data["retriedReason"] = reason or "operator retry"
        salvage_note = _arm_salvage_fast_path(data, no_salvage)
        salvage_branch = (data.get("convergenceRetry") or {}).get("salvageBranch")

        tmp = queue_file.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
        tmp.replace(queue_file)
        commit_paths = [queue_file]
        prior_state = status or "queued"

    # REOPENED clears the ledger TERMINAL verdict AND any lingering claim —
    # claims carry the dispatcher's pid, so without this a RUNNING dispatcher
    # silently skips the order until restarted. record_reopened takes an
    # explicit workspace_dir already (no global to scope); the two
    # fleet_runner calls below are what need workspace_scope().
    _ledger.record_reopened(order_id, data["retriedReason"], workspace_dir=mso)
    with workspace_scope(mso):
        _fr.remove_skipped_order(order_id)  # a retried order must not stay skip-listed
        _fr.write_lifecycle_event(
            "RETRY",
            f"{order_id} reopened by operator ({data['retriedReason']}) — "
            f"{prior_state} -> PENDING@{retry_role}{salvage_note} (BUG-0297/BUG-0344)"
        )
        _fr._commit_lifecycle_transition(
            commit_paths,
            f"lifecycle: retry {order_id} ({prior_state} -> PENDING@{retry_role})",
        )

    return RetryOutcome(
        order_id=order_id,
        prior_state=prior_state,
        new_status="PENDING",
        target_role=retry_role,
        salvage_note=salvage_note,
        salvage_branch=salvage_branch,
        reason=data["retriedReason"],
    )
