"""Tests for v3.0.2 deprecation warnings (FTR-MSO-2026-0180)."""
from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import patch

import pytest

# Import the module under test
import maestro.cli as cli_mod


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_adm(tmp_path: Path) -> Path:
    adm = tmp_path / ".adm"
    adm.mkdir()
    return adm


# ---------------------------------------------------------------------------
# CLI deprecation
# ---------------------------------------------------------------------------

class TestCliDeprecation:
    def test_first_run_prints_warning_and_creates_marker(self, tmp_path, capsys, monkeypatch):
        adm = _make_adm(tmp_path)
        monkeypatch.chdir(tmp_path)

        cli_mod._warn_once(cli_mod._CLI_MARKER, cli_mod._CLI_WARNING)

        captured = capsys.readouterr()
        assert "[deprecation]" in captured.err
        assert "adm" in captured.err
        assert "v4.0" in captured.err
        assert (adm / cli_mod._CLI_MARKER).exists()

    def test_second_run_skips_warning(self, tmp_path, capsys, monkeypatch):
        adm = _make_adm(tmp_path)
        monkeypatch.chdir(tmp_path)
        # Pre-create marker
        (adm / cli_mod._CLI_MARKER).touch()

        cli_mod._warn_once(cli_mod._CLI_MARKER, cli_mod._CLI_WARNING)

        captured = capsys.readouterr()
        assert captured.err == ""

    def test_mso_invocation_never_triggers_cli_warning(self, tmp_path, capsys, monkeypatch):
        """main() called as 'mso' must not produce a CLI deprecation warning."""
        _make_adm(tmp_path)
        monkeypatch.chdir(tmp_path)

        with patch.object(sys, "argv", ["mso", "version"]):
            # Patch _main so we don't actually run the CLI
            with patch("admiralty.cli.main"):
                # Patch _check_env_deprecation to isolate CLI path
                with patch.object(cli_mod, "_check_env_deprecation"):
                    cli_mod.main()

        captured = capsys.readouterr()
        assert cli_mod._CLI_WARNING not in captured.err


# ---------------------------------------------------------------------------
# Env-var deprecation
# ---------------------------------------------------------------------------

class TestEnvDeprecation:
    def test_first_run_with_admiralty_var_prints_warning_and_creates_marker(
        self, tmp_path, capsys, monkeypatch
    ):
        adm = _make_adm(tmp_path)
        monkeypatch.chdir(tmp_path)
        monkeypatch.setenv("ADMIRALTY_DIR", "/some/path")

        cli_mod._check_env_deprecation("mso")

        captured = capsys.readouterr()
        assert "[deprecation]" in captured.err
        assert "ADMIRALTY_" in captured.err
        assert "MAESTRO_" in captured.err
        assert (adm / cli_mod._ENV_MARKER).exists()

    def test_second_run_skips_env_warning(self, tmp_path, capsys, monkeypatch):
        adm = _make_adm(tmp_path)
        monkeypatch.chdir(tmp_path)
        monkeypatch.setenv("ADMIRALTY_DIR", "/some/path")
        (adm / cli_mod._ENV_MARKER).touch()

        cli_mod._check_env_deprecation("mso")

        captured = capsys.readouterr()
        assert captured.err == ""

    def test_no_admiralty_vars_no_warning(self, tmp_path, capsys, monkeypatch):
        _make_adm(tmp_path)
        monkeypatch.chdir(tmp_path)
        # Ensure no ADMIRALTY_* vars leak in from the test environment
        for key in list(k for k in __import__("os").environ if k.startswith("ADMIRALTY_")):
            monkeypatch.delenv(key, raising=False)

        cli_mod._check_env_deprecation("mso")

        captured = capsys.readouterr()
        assert captured.err == ""

    def test_warnings_go_to_stderr_not_stdout(self, tmp_path, capsys, monkeypatch):
        _make_adm(tmp_path)
        monkeypatch.chdir(tmp_path)
        monkeypatch.setenv("ADMIRALTY_FOO", "bar")

        cli_mod._check_env_deprecation("mso")

        captured = capsys.readouterr()
        assert captured.out == ""
        assert "[deprecation]" in captured.err
