"""maestro.cli — primary entry point for mso / adm / admiralty CLI aliases."""
from __future__ import annotations

import os
import sys
from pathlib import Path


_CLI_MARKER = ".deprecation-shown-cli"
_ENV_MARKER = ".deprecation-shown-env"

_CLI_WARNING = (
    "[deprecation] The 'adm' / 'admiralty' commands will be removed in Maestro v4.0.\n"
    "              Use 'mso' instead.  This warning is shown once per workspace."
)

_ENV_WARNING = (
    "[deprecation] ADMIRALTY_* env vars will be removed in Maestro v4.0.\n"
    "              Use MAESTRO_* instead (e.g. ADMIRALTY_DIR → MAESTRO_DIR).\n"
    "              This warning is shown once per workspace."
)


def _find_adm_dir() -> Path | None:
    """Walk up from cwd to find the .adm/ directory."""
    for path in [Path.cwd(), *Path.cwd().parents]:
        candidate = path / ".adm"
        if candidate.is_dir():
            return candidate
    return None


def _warn_once(marker_name: str, message: str) -> None:
    """Print message to stderr and create marker; skip if marker already exists."""
    adm = _find_adm_dir()
    if adm is None:
        # No workspace found — emit warning unconditionally (can't track marker)
        print(message, file=sys.stderr)
        return
    marker = adm / marker_name
    if marker.exists():
        return
    print(message, file=sys.stderr)
    try:
        marker.touch()
    except OSError:
        pass


def _check_env_deprecation(invoke_name: str) -> None:
    """Warn once if any ADMIRALTY_* env vars are set."""
    admiralty_vars = [k for k in os.environ if k.startswith("ADMIRALTY_")]
    if admiralty_vars:
        _warn_once(_ENV_MARKER, _ENV_WARNING)


def main() -> None:
    invoke_name = Path(sys.argv[0]).stem

    if invoke_name in ("adm", "admiralty"):
        _warn_once(_CLI_MARKER, _CLI_WARNING)

    _check_env_deprecation(invoke_name)

    from admiralty.cli import main as _main
    _main()
