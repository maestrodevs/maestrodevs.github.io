# Maestro — Enterprise Security & Compliance Guide

> **Scope:** Operator + buyer guide for the V6 enterprise hardening surface (identity, audit, secrets, data-residency, operator separation). Targets v3.0.0 release threshold. Some controls in this guide were flagged with open findings during the V6 pen-test ([SEC-FTR-ADM-2026-0064.md](../.mso/reports/security/SEC-FTR-ADM-2026-0064.md)) — see [§7 Threat model summary](#7-threat-model-summary--open-findings) before deploying to production.

> **Activation:** every control in this guide is gated behind `workspace.json: enterprise: true`. Solo and dev workspaces continue to behave as in v2.x with no change.

---

## Contents

1. [Identity model + ACL](#1-identity-model--acl)
2. [Immutable audit trail](#2-immutable-audit-trail)
3. [Secrets management](#3-secrets-management)
4. [Data-residency controls](#4-data-residency-controls)
5. [Operator separation](#5-operator-separation)
6. [Identity privacy + GDPR](#6-identity-privacy--gdpr)
7. [Threat model summary + open findings](#7-threat-model-summary--open-findings)

For the auditor-facing control mapping, see the companion [COMPLIANCE-MAPPING.md](COMPLIANCE-MAPPING.md).

---

## 1. Identity model + ACL

Maestro 3.0+ identifies the *human* running each privileged action — distinct from the *crew roles* (NAV, SHP, BOS, SCR, LKT, COX, QM) that name AI workers.

### Identity records

```
.mso/identity/
├── users/
│   ├── alice@acme.com.json
│   └── bob@acme.com.json
├── groups/
│   ├── captains.json
│   └── operators.json
├── access.json              # ACL bindings
└── integrity.json           # SHA-256 manifest (FTR-0067)
```

Each user record:

```json
{
  "email": "alice@acme.com",
  "displayName": "Alice Example",
  "providers": { "github": "alice-gh", "bitbucket": "alice-bb" },
  "publicKey": "ssh-ed25519 AAAA...",
  "groups": ["captains"],
  "_meta": { "dataClassification": ["email", "displayName"] }
}
```

### Authentication

Maestro does **not** run its own auth. Caller identity is resolved from, in order:

1. `MAESTRO_USER` env var (CI / scripted contexts)
2. Attached VCS — your `gh auth status` / `bb whoami` identity
3. OIDC session (when `workspace.json: identity.oidc` is configured)
4. OS user (last-resort fallback for air-gapped workflows; relies on signed commits)

### ACL — capability-based

`access.json` binds principals to `(capability, scope)` pairs:

```json
{
  "entries": [
    { "principal": "group:captains",   "capability": "voyage.approve",  "scope": "*" },
    { "principal": "group:operators",  "capability": "fleet.dispatch",  "scope": "*" },
    { "principal": "user:carol@acme.com", "capability": "order.create", "scope": "voyage:VOY-ADM-2026-0050" }
  ]
}
```

Capabilities: `voyage.create`, `voyage.approve`, `order.create`, `order.dispatch`, `fleet.dispatch`, `config.modify`, `bridge.start`, `bridge.stop`, `secrets.read`, `secrets.write`, `secrets.delete`, `secrets.list`, `audit.read`, `audit.write`, `identity.read`, `identity.write`, `process.spawn`.

Scopes: `*` (any), `voyage:<id>`, `project:<acronym>`, `role:<code>`.

### Integrity guard (FTR-0067)

Every identity file load verifies the file is either:

1. Tracked + clean in git (`git ls-files --error-unmatch <path>` and `git status --porcelain <path>` empty), **or**
2. Hash-matches the entry in `.mso/identity/integrity.json` (which is updated atomically by `mso identity` mutations)

A file failing both checks raises `IdentityIntegrityError` and refuses to load the workspace identity at all. This converts post-hoc detection into pre-action enforcement — privilege escalation via direct file edit is no longer possible.

### CLI

```bash
mso identity init [--encryption git-crypt|sops|none]
mso identity user add EMAIL --display-name NAME [--public-key PATH]
mso identity user list
mso identity group add NAME --capabilities CAP1,CAP2 [--scope SCOPE]
mso identity assign EMAIL --to-group GROUP
mso identity show EMAIL                 # Effective capabilities + memberships
mso identity acl show                   # Full effective ACL
mso identity rights export EMAIL        # GDPR Article 15
mso identity rights forget EMAIL --dry-run
mso identity rights restrict EMAIL
```

---

## 2. Immutable audit trail

Append-only log at `.mso/audit/log.jsonl` with cryptographic chain integrity.

### Entry shape

```json
{
  "seq": 42,
  "timestamp": "2026-04-28T09:12:00Z",
  "actor": "user:alice@acme.com",
  "action": "voyage.approve",
  "target": "voyage:VOY-ADM-2026-0050",
  "result": "success",
  "metadata": { "reason": "QA passed", "pr": "https://..." },
  "prevHash": "sha256:...",
  "signature": "..."
}
```

- `prevHash` is the SHA-256 of the previous serialized entry; the genesis entry uses a fixed constant
- `signature` is computed with the actor's private key when enrolled; otherwise the workspace signing key
- Hooks fire on: `dispatch start/stop`, `voyage.approve`, `secret.read/write/delete`, `config.modify`, `bridge.command`, `identity.write`, `identity.rights.*`, `process.spawn`, `egress.proxied`

### CLI

```bash
mso audit tail                       # Live tail
mso audit verify                     # Walk hash chain — exits non-zero on tamper
mso audit export --since 2026-01-01 --format json
mso audit anchor --provider {s3|azure|s3-compat|fs}
mso audit anchor --auto              # For cron / Task Scheduler
```

### External anchoring (mandatory in enterprise mode — FTR-0068)

When `workspace.json: enterprise: true`, `audit.anchorProvider` is required. AuditLog refuses to start without it. `audit.maxAnchorAgeMinutes` (default 60) gates new privileged actions when the last anchor is stale.

| Provider | Module | Backend | Notes |
|----------|--------|---------|-------|
| `s3` | `maestro/audit/anchor/s3.py` | AWS S3 + Object Lock | Tamper-proof via Object Lock retention |
| `azure_blob` | `azure_blob.py` | Azure Immutable Blob | Tamper-proof via legal hold / time-based retention |
| `s3_compatible` | `s3_compatible.py` | Customer-provided S3-compatible endpoint | MinIO, Wasabi, Backblaze B2 |
| `filesystem` | `filesystem.py` | Local filesystem | **Dev/CI only** — emits startup warning that filesystem-only anchoring is not tamper-proof |

Configure in `workspace.json`:

```json
{
  "enterprise": true,
  "audit": {
    "anchorProvider": "s3",
    "maxAnchorAgeMinutes": 60,
    "providerConfig": {
      "bucket": "acme-maestro-audit",
      "region": "us-east-1",
      "objectLockMode": "COMPLIANCE",
      "objectLockYears": 7,
      "credentials": "secret://aws/maestro/anchor"
    }
  }
}
```

> **Open finding (CRITICAL):** the V6 pen-test identified that JSONL truncation is not detected by `verify_chain` ([SEC-FTR-ADM-2026-0064 Scenario 2.2](../.mso/reports/security/SEC-FTR-ADM-2026-0064.md)). Until this is fixed in the v3.0.x patch, treat the audit log as tamper-detectable for *modifications* but **not** for *truncation*. External anchoring at high cadence partially mitigates.

---

## 3. Secrets management

### Provider matrix

| Provider | Module | Pip extras | Notes |
|----------|--------|------------|-------|
| `env` | `maestro/secrets/env.py` | (none) | Default, dev-friendly |
| `os_keyring` | `os_keyring.py` | `keyring` (default install) | macOS Keychain, Windows Credential Manager, libsecret |
| `azure_keyvault` | `azure_keyvault.py` | `maestro[azure-secrets]` | DefaultAzureCredential |
| `aws_secrets` | `aws_secrets.py` | `maestro[aws-secrets]` | boto3 secretsmanager |
| `vault` | `vault.py` | (none — stdlib HTTP) | KV v1 + v2 mounts |
| `one_password` | `one_password.py` | (none — HTTP API) | 1Password Connect |

Selection via `workspace.json`:

```json
{
  "enterprise": true,
  "secretsProvider": {
    "type": "vault",
    "config": {
      "address": "https://vault.acme.com:8200",
      "namespace": "maestro",
      "token": "secret://env/VAULT_TOKEN"
    }
  }
}
```

### Reference scheme

Once a provider is declared, replace literal secrets in any config file with references:

```json
{
  "transport": {
    "type": "gist",
    "gistId": "abc123",
    "githubToken": "secret://azure-keyvault/maestro-prod/github-token"
  }
}
```

References are parsed by `maestro/secrets/refs.py` and resolved **lazily** at use site — never at config-load time, never written to disk, never logged. The central log filter detects `secret://...` strings and known resolved values and replaces them with `[REDACTED:secret://...]` before any log line emits.

### Operator tooling

```bash
adm secrets doctor                # Verify every reference resolves
adm secrets rotate --key KEY      # Provider-aware rotation
adm secrets scrub                 # Scan config + logs for cleartext patterns
adm secrets list                  # Keys only — never values
```

`adm secrets scrub` re-uses the secret pattern library from VOY-ADM-2026-0022.

> **Open finding (CRITICAL + HIGH):** the central scrub catches `logging` module emissions but **not** `print()` calls or subprocess stdout ([SEC-FTR-ADM-2026-0064 Scenario 3.1](../.mso/reports/security/SEC-FTR-ADM-2026-0064.md)). Avoid `print()` in code paths that may handle resolved secrets until this is patched.

### Subprocess env scrub (FTR-0069)

Every `subprocess.Popen` in the framework routes through `maestro/launch/sandbox.py:spawn()`, which builds a minimal env from scratch (PATH, HOME, LANG, ANTHROPIC_API_KEY, MAESTRO_*, CLAUDE_*) and explicitly stripsothers. Crew Claude sessions and MCP server processes do not inherit the operator's shell env when `enterprise: true`.

---

## 4. Data-residency controls

### Modes (FTR-0061 + FTR-0070)

`workspace.json: dataResidency.mode`:

| Mode | Behaviour |
|------|-----------|
| `permissive` | All outbound HTTP allowed (default for solo / dev) |
| `restrictive` | Allowlist enforced; non-matching destinations raise `EgressDenied` |
| `air-gapped` | All outbound HTTP denied except `localhost`, `127.0.0.1`, `::1`, unix sockets — startup logs `EGRESS MODE: AIR-GAPPED` prominently |

```json
{
  "enterprise": true,
  "dataResidency": {
    "mode": "restrictive",
    "allowedDestinations": ["api.github.com", "api.anthropic.com", "*.azure.com"],
    "proxy": {
      "url": "http://corp-proxy.acme:8080",
      "decryptDestinationHostFromProxyHeader": false
    }
  }
}
```

When `proxy` is configured, the egress filter inspects the **intended** destination host (parsed from the request URL before proxy substitution) against `allowedDestinations` — preventing the operator-intent gap where allowlisting the proxy itself would silently allow all destinations.

### Diagram

```bash
adm data-flow diagram                # Default Mermaid output
adm data-flow diagram --mode air-gapped --output airgap-mode.mmd
```

> **Open finding (HIGH):** the egress filter installs at the urllib/requests layer but does **not** intercept direct socket calls or subprocess output ([SEC-FTR-ADM-2026-0064 Scenario 4.1](../.mso/reports/security/SEC-FTR-ADM-2026-0064.md)). Out-of-band exfil paths (npx-spawned MCP servers, raw socket clients) bypass the filter. Combine with network-layer controls (firewall, egress proxy) until this is patched.

---

## 5. Operator separation

Four default human roles ship with the framework, distinct from the AI crew roles:

| Human role | Default capabilities |
|------------|----------------------|
| **Captain** (commander) | All capabilities |
| **Fleet Operator** | `fleet.dispatch`, `bridge.start`, `bridge.stop`, `backup.*`, `audit.read` |
| **Contributor** | `order.create`, `voyage.view`, `audit.read` |
| **Auditor** | `audit.*`, no write capabilities |

`mso init` copies these into a fresh workspace; `mso identity group` mutates them in place. ACL-gated by `identity.write` capability for mutations and `identity.read` for reads.

---

## 6. Identity privacy + GDPR

Identity records contain personal data (email, displayName). V6 ships three GDPR-aligned mitigations (FTR-0071):

### Optional encryption

```bash
mso identity init --encryption git-crypt   # Or --encryption sops
```

When configured, `.mso/identity/users/*.json` and `integrity.json` are encrypted at rest in git via filter encryption. Integrity hashes are computed over plaintext so commits don't constantly invalidate the manifest. Key reference stored via the secrets provider.

### Data-classification annotations

Each user record's `_meta.dataClassification` lists which top-level keys are personal data (default `["email", "displayName"]`). `mso identity export-classification` dumps a CSV for compliance audits.

### Data-subject-rights tooling

| Article | Command | Behaviour |
|---------|---------|-----------|
| 15 (access) | `mso identity rights export EMAIL` | JSON dump of every reference to the email across `.mso/` |
| 17 (erasure) | `mso identity rights forget EMAIL [--dry-run]` | Sketches deletion plan + audit-redaction (preserves hash chain via tombstones); does NOT rewrite git history (manual procedure documented) |
| 18 (restriction) | `mso identity rights restrict EMAIL` | Capability resolver refuses new operations under that identity; historical audit entries remain readable |

All rights calls produce `identity.rights.*` audit entries.

---

## 7. Threat model summary + open findings

The V6 design + implementation underwent **two** security reviews:

| Phase | Report | Verdict |
|-------|--------|---------|
| Pre-implementation (LKT) | [SEC-FTR-ADM-2026-0053.md](../.mso/reports/security/SEC-FTR-ADM-2026-0053.md) | 2 CRITICAL + 3 HIGH design findings — addressed in FTR-0067 (identity integrity), FTR-0068 (mandatory anchoring), FTR-0069 (subprocess scrub), FTR-0070 (egress modes), FTR-0071 (GDPR rights) |
| Post-implementation (LKT) | [SEC-FTR-ADM-2026-0064.md](../.mso/reports/security/SEC-FTR-ADM-2026-0064.md) | **2 CRITICAL + 2 HIGH + 5 MEDIUM** open findings |

### Open CRITICAL/HIGH findings (block v3.0.0 release)

| ID | Severity | Summary | Mitigation until patched |
|----|----------|---------|--------------------------|
| 2.2 | CRITICAL | Audit log truncation not detected by `verify_chain` | Frequent external anchoring; treat the local log as append-detectable but not truncation-detectable |
| 3.1 (a) | CRITICAL | `print()` and subprocess stdout bypass the central secrets scrub | Avoid `print()` for any value derived from secrets; capture subprocess output via the framework helpers |
| 3.1 (b) | HIGH | Logging exfil paths not exhaustively covered | As above |
| 4.1 | HIGH | Egress filter doesn't intercept raw socket / subprocess network | Combine with network-layer controls (firewall, egress proxy) |

A v3.0.x patch voyage is committed to closing these before any production customer deployment. See the V6 voyage report ([VOY-ADM-2026-0026.md](../.mso/reports/voyage/VOY-ADM-2026-0026.md)) for the planned scope.

### External-review commitment

Per [PLAN-VOY-ADM-2026-0020.md §Risks](../.mso/plans/PLAN-VOY-ADM-2026-0020.md), no enterprise customer should run V6 without **independent external security review**. The internal LKT pen-test (FTR-0064) was performed for design validation and is not a substitute for an outside review. Procurement should treat this guide as describing intended controls, not a certification.

---

## Further reading

- [COMPLIANCE-MAPPING.md](COMPLIANCE-MAPPING.md) — SOC2 CC + ISO27001 Annex A control mapping
- [PLAN-VOY-ADM-2026-0020.md](../.mso/plans/PLAN-VOY-ADM-2026-0020.md) — Original V6 roadmap
- [PLAN-VOY-ADM-2026-0026.md](../.mso/plans/PLAN-VOY-ADM-2026-0026.md) — Master design doc
- [VERSIONING.md](../maestro/docs/VERSIONING.md) — Release history
