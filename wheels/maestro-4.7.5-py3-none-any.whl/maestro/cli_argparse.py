"""maestro.cli_argparse — friendly ArgumentParser with did-you-mean and positional hints.

NOT yet wired into cli.py main() — wiring is FTR-0260.
"""

from __future__ import annotations

import argparse
import difflib
import sys
from typing import Sequence

# Top-level mso subcommands (kept here so FriendlyArgumentParser can suggest them
# independently of importing the full cli module).
KNOWN_SUBCOMMANDS: tuple[str, ...] = (
    "audit",
    "backup",
    "bridge",
    "bug",
    "cleanup",
    "config",
    "data-flow",
    "dispatch",
    "hooks",
    "identity",
    "init",
    "licence",
    "license",
    "mcp",
    "order",
    "projects",
    "quickstart",
    "restore",
    "review",
    "roles",
    "secrets",
    "security",
    "setup",
    "sprint",
    "squad",
    "crew",
    "status",
    "update",
    "usage",
    "verify",
    "version",
    "voyage",
)

# Project-like tokens: a bare uppercase-only word (2-8 chars) or @WORD.
# Heuristic: if it matches this pattern it's probably a project acronym.
import re
_PROJECT_PATTERN = re.compile(r"^@?[A-Z][A-Z0-9]{1,7}$")

# Per-command flags that accept a project/acronym argument.
_PROJECT_FLAGS: dict[str, str] = {
    "usage": "--project",
    "status": "--project",
    "dispatch": "--project",
    "order": "--project",
    "sprint": "--project",
    "voyage": "--project",
    "bug": "--project",
    "verify": "--project",
    "init": "--project",
}


def suggest_did_you_mean(
    typed: str,
    candidates: Sequence[str],
    *,
    n: int = 3,
    cutoff: float = 0.6,
) -> list[str]:
    """Return the closest matches for *typed* from *candidates*."""
    return difflib.get_close_matches(typed, candidates, n=n, cutoff=cutoff)


def suggest_flag_form(command: str, stray_positional: str) -> str | None:
    """Return a flag-form suggestion if *stray_positional* looks like a project token.

    For example: ``mso usage MSO`` → ``mso usage --project MSO``

    Returns a suggestion string, or None if the heuristic does not match.
    """
    if not _PROJECT_PATTERN.match(stray_positional):
        return None
    flag = _PROJECT_FLAGS.get(command)
    if flag is None:
        return None
    clean = stray_positional.lstrip("@")
    return f"mso {command} {flag} {clean}"


class FriendlyArgumentParser(argparse.ArgumentParser):
    """ArgumentParser subclass that overrides error() to provide helpful output.

    On a parse error the standard argparse error() prints a terse message and
    exits 2.  This override:

    1. Prints the terse reason argparse generated.
    2. Checks whether the bad token looks like a mistyped subcommand and, if so,
       prints a "did you mean?" suggestion using difflib.
    3. If the error involves an unexpected positional that matches a project token
       pattern (e.g. ``MSO``), suggests the ``--project`` flag form instead.
    4. Prints the relevant usage line (the subparser's usage if available, or
       the top-level usage).

    The exit code remains 2 (argparse convention for usage errors).
    """

    def __init__(self, *args, known_subcommands: Sequence[str] | None = None, **kwargs):
        super().__init__(*args, **kwargs)
        self._known_subcommands: tuple[str, ...] = (
            tuple(known_subcommands) if known_subcommands is not None else KNOWN_SUBCOMMANDS
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _extract_bad_token(self, message: str) -> str | None:
        """Pull the bad token out of a standard argparse error message."""
        for prefix in (
            "argument command: invalid choice: ",
            "unrecognized arguments: ",
            "invalid choice: ",
        ):
            if prefix in message:
                rest = message.split(prefix, 1)[1]
                # strip trailing " (choose from ...)" / "'" clutter
                token = rest.split(" (choose from")[0].strip(" '\"")
                # take just the first token if multiple are present
                return token.split()[0] if token else None
        return None

    def _did_you_mean_lines(self, bad_token: str) -> list[str]:
        suggestions = suggest_did_you_mean(bad_token, self._known_subcommands)
        if not suggestions:
            return []
        quoted = ", ".join(f"'{s}'" for s in suggestions)
        lines = [f"  Did you mean: {quoted}?"]
        if len(suggestions) == 1:
            lines.append(f"  Run: mso {suggestions[0]} --help")
        else:
            lines.append("  Run 'mso --help' for the full command list.")
        return lines

    def _stray_positional_hint(self, message: str) -> list[str]:
        """Return hint lines if the error looks like a stray project positional."""
        if "unrecognized arguments:" not in message:
            return []
        rest = message.split("unrecognized arguments:", 1)[1].strip()
        # The first stray token is what we test.
        first_token = rest.split()[0].strip("'\"") if rest else ""
        if not first_token:
            return []
        # Determine the command context from prog (e.g. "mso usage").
        prog_parts = self.prog.split() if self.prog else []
        command = prog_parts[1] if len(prog_parts) >= 2 else (prog_parts[0] if prog_parts else "")
        # When this is the root parser (prog=="mso"), unknown subcommand args bubble up
        # here rather than being caught by the subparser itself.  Peek at sys.argv to
        # recover the subcommand so we can still suggest the flag form.
        if len(prog_parts) == 1 and prog_parts and prog_parts[0] in ("mso", "maestro"):
            argv = sys.argv[1:]
            for tok in argv:
                if tok in _PROJECT_FLAGS:
                    command = tok
                    break
        suggestion = suggest_flag_form(command, first_token)
        if suggestion is None:
            return []
        return [
            f"  '{command}' takes no positional argument '{first_token}'.",
            f"  Did you mean: {suggestion}",
        ]

    # ------------------------------------------------------------------
    # Override
    # ------------------------------------------------------------------

    def error(self, message: str) -> None:  # type: ignore[override]
        """Print a friendly error and exit 2."""
        lines: list[str] = []

        # 1. Product prefix + terse reason
        try:
            from maestro.personas import current_persona
            prod = current_persona().term("product")
        except Exception:
            prod = "Maestro"
        lines.append(f"[{prod}] {message}")

        # 2. Did-you-mean suggestion for mistyped subcommands
        bad = self._extract_bad_token(message)
        if bad:
            lines.extend(self._did_you_mean_lines(bad))

        # 3. Stray-positional / project-flag hint
        lines.extend(self._stray_positional_hint(message))

        # 4. Relevant usage
        lines.append("")
        lines.append(self.format_usage().rstrip())

        print("\n".join(lines), file=sys.stderr)
        sys.exit(2)
