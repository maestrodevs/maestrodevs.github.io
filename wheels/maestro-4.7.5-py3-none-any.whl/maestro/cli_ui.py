"""maestro.cli_ui — shared presentation helpers for the mso CLI.

Provides print_error() and print_unexpected() with persona-aware prefixes
and ANSI colour that degrades gracefully when stdout is not a TTY.

Wave-1 constraint: this module must NOT import maestro.errors.
"""

from __future__ import annotations

import os
import sys
from maestro.personas import current_persona as _current_persona

_COLOURS = {
    "error": "\033[31m",   # red
    "hint":  "\033[33m",   # yellow
    "reset": "\033[0m",
    "bold":  "\033[1m",
}

_REPORT_URL = "https://github.com/tavisbasing/Maestro/issues"


def _use_colour() -> bool:
    return sys.stderr.isatty() and os.environ.get("NO_COLOR") is None


def _prefix() -> str:
    try:
        product = _current_persona().term("product")
    except Exception:
        product = "Maestro"
    return f"[{product}]"


def print_error(message: str, hint: str | None = None) -> None:
    """Print a user-facing error message (and optional hint) to stderr."""
    colour = _use_colour()
    pfx = _prefix()
    if colour:
        err_colour = _COLOURS["error"]
        reset = _COLOURS["reset"]
        bold = _COLOURS["bold"]
        header = f"{bold}{err_colour}{pfx} Error:{reset} {message}"
    else:
        header = f"{pfx} Error: {message}"
    print(header, file=sys.stderr)
    if hint:
        if colour:
            hint_colour = _COLOURS["hint"]
            reset = _COLOURS["reset"]
            print(f"{hint_colour}  Hint: {reset}{hint}", file=sys.stderr)
        else:
            print(f"  Hint: {hint}", file=sys.stderr)


def print_unexpected(exc: BaseException, command: str) -> None:
    """Print a concise unexpected-error message to stderr (no traceback).

    Tells the user:
      - what went wrong (exception class + message)
      - how to re-run with --debug for the full traceback
      - where to report the issue
    """
    colour = _use_colour()
    pfx = _prefix()
    exc_class = type(exc).__name__
    exc_msg = str(exc) or "(no details)"

    if colour:
        bold = _COLOURS["bold"]
        reset = _COLOURS["reset"]
        err_colour = _COLOURS["error"]
        print(
            f"{bold}{err_colour}{pfx} Unexpected error in '{command}':{reset} "
            f"{exc_class}: {exc_msg}",
            file=sys.stderr,
        )
    else:
        print(
            f"{pfx} Unexpected error in '{command}': {exc_class}: {exc_msg}",
            file=sys.stderr,
        )
    print(
        f"  Re-run with --debug (or MAESTRO_DEBUG=1) for the full traceback.",
        file=sys.stderr,
    )
    print(
        f"  Report this issue at: {_REPORT_URL}",
        file=sys.stderr,
    )
