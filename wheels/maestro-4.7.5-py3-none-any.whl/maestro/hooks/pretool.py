#!/usr/bin/env python3
"""
Fleet PreToolUse Hook v8.1 — Role Permission Enforcement.

Prevents crews from writing files outside their role permissions.
Reads the crew's role from state.json and checks file paths against
the prohibited patterns in role-paths.json.

IMPORTANT: This hook ONLY activates for crew sessions (MAESTRO_CREW env set).
The Captain's interactive sessions are NEVER affected.

Fail-open: If role-paths.json or state.json can't be read, the operation is allowed.

Input:  JSON on stdin (from Claude Code hook system)
Output: JSON on stdout with {"decision": "deny", "reason": "..."} to block
        OR exit 0 with no output to allow
"""

import fnmatch
import json
import logging
import os
import sys
from pathlib import Path

logger = logging.getLogger("maestro.secret_scan")


# Paths that ALL roles are allowed to write to (bypass enforcement)
ALWAYS_ALLOWED = [
    # v4.0 canonical
    ".mso/crews/*",
    ".mso/handoffs/*",
    ".mso/queues/*",
    ".mso/orders/*",
    # v3.x legacy (pre-cutover workspaces)
    ".mso/crews/*",
    ".mso/handoffs/*",
    ".mso/queues/*",
    ".mso/orders/*",
    # v1.x legacy
    ".maestro/crews/*",
    ".maestro/handoffs/*",
    ".maestro/queues/*",
    ".maestro/orders/*",
]


def normalize_path(file_path: str, cwd: str) -> str:
    """Normalize a file path to forward slashes relative to project root."""
    path = file_path.replace("\\", "/")

    # Make relative to project root if absolute
    cwd_normalized = cwd.replace("\\", "/").rstrip("/")
    if path.startswith(cwd_normalized):
        path = path[len(cwd_normalized):].lstrip("/")

    return path


def is_always_allowed(rel_path: str) -> bool:
    """Check if path is in the always-allowed list."""
    for pattern in ALWAYS_ALLOWED:
        if fnmatch.fnmatch(rel_path, pattern):
            return True
    return False


def matches_pattern_list(rel_path: str, patterns: list) -> bool:
    """Check if path matches any pattern in a list."""
    for pattern in patterns:
        pattern = pattern.replace("\\", "/")
        if fnmatch.fnmatch(rel_path, pattern):
            return True
    return False


def main():
    try:
        # ===================================================================
        # STEP 1: Read hook input from stdin
        # ===================================================================
        raw_input = sys.stdin.read()
        hook_input = json.loads(raw_input) if raw_input.strip() else {}
    except Exception:
        sys.exit(0)  # Can't parse — allow

    # ===================================================================
    # STEP 2: Check if this is a crew session
    # ===================================================================
    crew_str = os.environ.get("MAESTRO_CREW")
    if not crew_str:
        sys.exit(0)  # Captain's session — always allow everything

    try:
        crew_number = int(crew_str)
    except ValueError:
        sys.exit(0)

    # ===================================================================
    # STEP 2.5: Branch discipline (BUG-ADM-2026-0004)
    # ===================================================================
    # For Bash tool calls, refuse git/gh mutations whose target branch
    # disagrees with the order's voyageBranch. Runs before the file-path
    # check because this is a more fundamental discipline violation.
    try:
        from maestro.hooks.branch_guard import check_branch
        tool_name = hook_input.get("tool_name", "")
        tool_input = hook_input.get("tool_input", {})
        bash_command = tool_input.get("command", "") if tool_name == "Bash" else ""
        if bash_command:
            allow, reason = check_branch(tool_name, bash_command)
            if not allow:
                print(json.dumps({"decision": "deny", "reason": reason}))
                sys.exit(0)
    except Exception:
        # Fail-open on guard failure — branch discipline is belt-and-braces;
        # the branch_guard hook is belt-and-braces; worktrees are the primary isolation layer.
        pass

    # ===================================================================
    # STEP 2.6: Worktree path confinement (BUG-MSO-2026-0282)
    # ===================================================================
    # branch_guard only sees git/gh mutations; this denies Edit/Write/Bash file
    # writes whose target lands in another working tree of the same repo (the
    # main checkout or a sibling voyage worktree) instead of the crew's own
    # MAESTRO_REPO_PATH worktree. Fail-open; worktrees remain primary isolation.
    try:
        from maestro.hooks.path_guard import check_path_confinement
        tool_name = hook_input.get("tool_name", "")
        tool_input = hook_input.get("tool_input", {})
        # Pass the hook cwd so relative write targets resolve against the crew's
        # ACTUAL working directory (it may have cd'd out of its worktree), closing
        # the relative-path branch of the contamination gap.
        allow, reason = check_path_confinement(
            tool_name, tool_input, hook_input.get("cwd")
        )
        if not allow:
            print(json.dumps({"decision": "deny", "reason": reason}))
            sys.exit(0)
    except SystemExit:
        raise
    except Exception:
        pass

    # ===================================================================
    # STEP 2.7: Security PR gate (enterprise workspaces only)
    # Blocks gh pr create / gh pr merge when CRITICAL or HIGH scan findings
    # are present. Gated on enterprise:true in workspace.json so solo
    # workspaces are unaffected.
    # ===================================================================
    try:
        _tool_name_pr = hook_input.get("tool_name", "")
        _bash_cmd_pr = hook_input.get("tool_input", {}).get("command", "") if _tool_name_pr == "Bash" else ""
        _is_pr_op = _bash_cmd_pr and (
            "gh pr create" in _bash_cmd_pr or "gh pr merge" in _bash_cmd_pr
        )
        if _is_pr_op:
            # Check enterprise flag in workspace.json
            _enterprise_enabled = False
            try:
                from maestro.workspace import resolve_artefact_dir
                _ws_cfg = resolve_artefact_dir(Path(hook_input.get("cwd", os.getcwd()))) / ".." / "config" / "workspace.json"
                if _ws_cfg.exists():
                    _ws_data = json.loads(_ws_cfg.read_text(encoding="utf-8"))
                    _enterprise_enabled = bool(_ws_data.get("enterprise", False))
            except Exception:
                pass

            if _enterprise_enabled:
                from maestro.security.owasp_patterns import OWASPScanner, Severity
                _scan_ws = Path(hook_input.get("cwd", os.getcwd()))
                _py_files = [str(p) for p in _scan_ws.rglob("*.py") if p.exists()]
                if _py_files:
                    _scanner = OWASPScanner(language="python")
                    _findings = _scanner.scan_files(_py_files)
                    _critical_high = [
                        f for f in _findings
                        if f.severity.value in ("CRITICAL", "HIGH")
                    ]
                    if _critical_high:
                        _finding_summary = "; ".join(
                            f"{f.severity.value}: {f.title} ({f.file}:{f.line})"
                            for f in _critical_high[:5]
                        )
                        print(json.dumps({
                            "decision": "deny",
                            "reason": (
                                f"SECURITY PR GATE: {len(_critical_high)} CRITICAL/HIGH finding(s) block this PR operation. "
                                f"Run 'mso security review' for details. "
                                f"Findings: {_finding_summary}"
                            ),
                        }))
                        sys.exit(0)
                    elif any(f.severity.value in ("MEDIUM", "LOW") for f in _findings):
                        # Emit lifecycle event for medium/low — permit but log
                        try:
                            from maestro.workspace import resolve_artefact_dir as _rad
                            _adm = _rad(Path(hook_input.get("cwd", os.getcwd())))
                            _log_dir = _adm / ".." / "logs"
                            _log_dir.mkdir(parents=True, exist_ok=True)
                            import datetime as _dt_mod
                            _ts = _dt_mod.datetime.now(_dt_mod.timezone.utc).isoformat()
                            _med_count = sum(1 for f in _findings if f.severity.value in ("MEDIUM", "LOW"))
                            with open(_log_dir / "lifecycle.log", "a", encoding="utf-8") as _lf:
                                _lf.write(
                                    f"{_ts} | SECURITY_FINDINGS_LOW_MED | crew={crew_number} "
                                    f"medium_low_count={_med_count} op='{_bash_cmd_pr[:80]}'\n"
                                )
                        except Exception:
                            pass
    except SystemExit:
        raise
    except Exception:
        pass  # Fail-open on gate errors

    # ===================================================================
    # STEP 3: Get the target file path
    # ===================================================================
    tool_input = hook_input.get("tool_input", {})
    # NotebookEdit uses `notebook_path` rather than `file_path`.
    file_path = (
        tool_input.get("file_path")
        or tool_input.get("filePath")
        or tool_input.get("notebook_path")
        or ""
    )

    if not file_path:
        sys.exit(0)  # No file path — allow

    # ===================================================================
    # STEP 4: Normalize path and check always-allowed
    # ===================================================================
    cwd = hook_input.get("cwd", os.getcwd())
    from maestro.hooks import find_mso_root
    workspace = find_mso_root(cwd)
    if workspace is None:
        sys.exit(0)  # Not an Admiralty workspace — no-op
    cwd = str(workspace)
    rel_path = normalize_path(file_path, cwd)

    # ===================================================================
    # STEP 3.5: Secret scan (runs for all paths, including always-allowed)
    # ===================================================================
    try:
        from maestro.hooks.secret_patterns import Scanner

        def _extract_write_content(tname: str, tinput: dict) -> list[tuple[str, str]]:
            if tname == "Write":
                content = tinput.get("content", "")
                return [("content", content)] if content else []
            if tname == "Edit":
                new_str = tinput.get("new_string", "")
                return [("new_string", new_str)] if new_str else []
            if tname == "MultiEdit":
                results = []
                for i, edit in enumerate(tinput.get("edits", [])):
                    ns = edit.get("new_string", "")
                    if ns:
                        results.append((f"edits[{i}].new_string", ns))
                return results
            if tname == "NotebookEdit":
                # Claude Code NotebookEdit input shape:
                #   {notebook_path, cell_id, new_source, cell_type, edit_mode}
                # The cell payload is `new_source`. Older clients sometimes send
                # `cell_source` — accept either to be safe.
                new_source = tinput.get("new_source") or tinput.get("cell_source") or ""
                return [("new_source", new_source)] if new_source else []
            return []

        tool_name = hook_input.get("tool_name", "")
        write_contents = _extract_write_content(tool_name, tool_input)
        if write_contents:
            scanner = Scanner(workspace_root=workspace)
            for field_label, content in write_contents:
                matches = scanner.scan(content, field_label=field_label, rel_path=rel_path, stop_on_first=True)
                if matches:
                    hit = matches[0]
                    logger.warning(
                        "Secret scan: pattern=%s severity=%s file=%s crew=%s field=%s",
                        hit.pattern_name, hit.severity, rel_path, crew_number, field_label,
                    )
                    decision = {
                        "decision": "deny",
                        "reason": (
                            f"SECRET DETECTED: Pattern '{hit.pattern_name}' matched in "
                            f"{field_label} of {tool_name} → '{rel_path}'. "
                            f"Severity: {hit.severity}. "
                            f"The matched value has NOT been logged. "
                            f"Remove the secret and retry, or add to allowlist if this is a test fixture."
                        ),
                    }
                    print(json.dumps(decision))
                    sys.exit(0)
    except SystemExit:
        raise
    except Exception as exc:
        # Log full traceback so this fail-closed branch is diagnosable.
        # logger.exception() includes the traceback. We deliberately log only
        # the tool name, file path and crew — never any payload that could
        # contain the matched (and unredacted) secret value.
        logger.exception(
            "Secret scanner crashed (fail-closed): tool=%s file=%s crew=%s error=%s",
            hook_input.get("tool_name", "?"), rel_path, crew_number, type(exc).__name__,
        )
        decision = {
            "decision": "deny",
            "reason": (
                f"SECRET SCANNER CRASH: failing closed. "
                f"Error type: {type(exc).__name__}. Check fleet logs."
            ),
        }
        print(json.dumps(decision))
        sys.exit(0)

    if is_always_allowed(rel_path):
        sys.exit(0)  # Always-allowed path — bypass role enforcement

    # ===================================================================
    # STEP 5: Get crew's role from state.json
    # ===================================================================
    from maestro.workspace import resolve_artefact_dir
    _mso_root = resolve_artefact_dir(Path(cwd))
    crew_dir = _mso_root / "crews" / f"crew{crew_number}"
    state_file = crew_dir / "state.json"

    if not state_file.exists():
        sys.exit(0)  # No state — fail-open

    try:
        state = json.loads(state_file.read_text(encoding='utf-8'))
    except Exception:
        sys.exit(0)  # Can't read state — fail-open

    role = state.get("role", "")
    if not role:
        sys.exit(0)  # No role — fail-open

    # ===================================================================
    # STEP 6: Load role-paths.json and get prohibited patterns
    # ===================================================================
    role_paths_file = _mso_root / "config" / "role-paths.json"

    if not role_paths_file.exists():
        sys.exit(0)  # No config — fail-open

    try:
        config = json.loads(role_paths_file.read_text(encoding='utf-8'))
    except Exception:
        sys.exit(0)  # Can't parse config — fail-open

    role_config = config.get("roles", {}).get(role, {})
    prohibited = role_config.get("prohibited", {})
    prohibited_paths = prohibited.get("paths", [])
    prohibited_reason = prohibited.get("reason", "Permission denied by role")

    if not prohibited_paths:
        sys.exit(0)  # No prohibitions — allow

    # ===================================================================
    # STEP 6b: Load allowed override patterns (allowed wins over prohibited)
    # ===================================================================
    allowed = role_config.get("allowed", {})
    allowed_paths = allowed.get("paths", [])

    # ===================================================================
    # STEP 7: Check file against prohibited patterns (with allowed override)
    # ===================================================================
    if matches_pattern_list(rel_path, prohibited_paths):
        # Check if an allowed pattern overrides the prohibition
        if matches_pattern_list(rel_path, allowed_paths):
            sys.exit(0)  # Allowed override — permit despite prohibition
        role_name = role_config.get("roleName", role)
        filename = Path(file_path).name
        decision = {
            "decision": "deny",
            "reason": (
                f"ROLE ENFORCEMENT: {role} ({role_name}) cannot write to '{filename}'. "
                f"{prohibited_reason}. "
                f"Matched prohibited pattern for path: {rel_path}"
            )
        }
        print(json.dumps(decision))
        sys.exit(0)

    # Allowed
    sys.exit(0)


if __name__ == "__main__":
    try:
        main()
    except Exception:
        sys.exit(0)  # Fail-open: never block on hook errors
