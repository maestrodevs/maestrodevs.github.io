# Planning Story Sizing — Hard Ceilings

> **Introduced in:** BUG-MSO-2026-0022 (v4.0)
> **Applies to:** PLN / NAV role (Planner / Navigator)

## Why sizing ceilings exist

During FTR-MSO-2026-0170 (v4.0 engine rename), the Planner produced a single
BLD spec covering 90 Python files, ~734 import-site rewrites, and ~170 caller
updates — all as one iteration. The Builder executed the spec correctly and
committed the work, but the inference ran ~2h17m. Several compounding problems
surfaced:

- The 90-minute crew timeout fired late (~2h17m), giving a false indication
  that the crew was hung.
- No progress signal was visible during the 2-hour inference window; the
  heartbeat went stale at ~45 minutes.
- If the inference had crashed before the final commit, 2 hours of token spend
  would have been lost with no recovery checkpoint.

The root cause is a missing hard ceiling on what one BLD iteration is allowed
to attempt. This document specifies those ceilings.

## The ceilings

| Dimension | Hard ceiling per BLD iteration |
|-----------|-------------------------------|
| Files changed | ≤ 30 |
| Net lines of code changed | ≤ 2 000 |
| Edit / Write tool calls | ≤ 50 |

**Any single BLD iteration that would exceed any ceiling MUST be decomposed
into sub-stories before dispatch.**

## Sub-story decomposition

When a story exceeds a ceiling, PLN decomposes it into sub-stories with a
dependency chain:

```
FTR-XXXX-0001a  →  FTR-XXXX-0001b  →  FTR-XXXX-0001c
  (≤30 files)        (≤30 files)        (≤30 files)
```

Name sub-stories by appending a lowercase letter suffix to the parent order ID
(e.g., `FTR-MSO-2026-0170a`). Each sub-story must independently satisfy all
three ceilings.

## Sizing justification in handoff docs

Every PLN→BLD (NAV→SHP) handoff document MUST include a `## Sizing Justification`
section:

```markdown
## Sizing Justification
- Estimated files changed: 12 (ceiling: 30)
- Estimated LoC changed: 450 (ceiling: 2000)
- Estimated Edit/Write tool calls: 20 (ceiling: 50)
- Why this is one story and not several: only touches the auth module's public API
```

The act of writing this section forces PLN to confront sizing before BLD runs.
If PLN cannot write a convincing one-sentence justification for why this is one
story, it should be split.

## Dispatcher behaviour (soft gate)

When NAV/PLN completes and the dispatcher advances the order to BLD/SHP, it
calls `check_plan_sizing()` which parses the handoff file for the three
declared estimates. If any ceiling is exceeded, the dispatcher emits an
`OVERSIZED_STORY` lifecycle event visible in `mso status`:

```
2026-05-18 14:32:01 | OVERSIZED_STORY | FTR-MSO-2026-0170 plan estimates 90 files
                                         changed (ceiling: 30) — PLN must decompose
```

**In v4.0 this is a warning only — BLD dispatch is not blocked.** A future
release may hard-gate on this event; operators can opt in via
`.mso/config/gates.json` when that option ships.

## Rationale for the ceiling values

| Ceiling | Rationale |
|---------|-----------|
| 30 files | Typical BLD inference on 30 files completes in 20–40 minutes, well within the 90-min crew timeout with headroom for retries. |
| 2 000 LoC | Correlates roughly with 30 files of average 65 lines each. Also the point at which context pressure starts degrading BLD output quality. |
| 50 tool calls | Each Edit/Write call takes 1–5 seconds of real time; 50 calls ≈ 5–15 minutes of tool-call overhead, leaving ample room in a 90-min budget. |

## What FTR-MSO-2026-0170 would have looked like

With these ceilings in place, PLN would have been required to split the rename
into four sub-stories:

| Sub-story | Scope | Est. files |
|-----------|-------|-----------|
| FTR-0170a | `maestro/core/` dir move | ~20 |
| FTR-0170b | `maestro/hooks/` + `maestro/roles/` | ~22 |
| FTR-0170c | remaining subpackages + flat files | ~25 |
| FTR-0170d | `get_workspace_dir` dedupe + 170 callers | ~28 |

Each sub-story would have run in ~25–35 minutes with clear inter-story
checkpoints — providing natural recovery points and LEAD visibility.

## Related

- `maestro/roles/PLN.md` — PLN role definition (canonical sizing rules)
- `maestro/personas/nautical/roles/NAV.md` — nautical overlay (same rules)
- `maestro/core/fleet_runner.py:check_plan_sizing` — dispatcher soft gate
- `maestro/core/fleet_runner.py:parse_plan_sizing` — handoff file parser
- BUG-MSO-2026-0022 — bug record that introduced these ceilings
