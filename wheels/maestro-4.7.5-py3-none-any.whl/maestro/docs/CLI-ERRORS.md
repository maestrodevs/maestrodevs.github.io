# Maestro CLI — Error Handling Reference

This document covers the `mso` CLI error surface: exit-code contract, exception taxonomy, debug mode, and did-you-mean suggestions.

---

## Exit codes

| Code | Meaning | When it fires |
|------|---------|---------------|
| `0` | Success | Command completed normally |
| `1` | General error | Configuration problem, licence issue, unexpected runtime error |
| `2` | Usage / argument error | Mistyped subcommand, wrong flags, ambiguous input needing disambiguation |
| `3` | No work | Nothing to do — empty queue, no pending orders, no matching data |
| `130` | Interrupted | `Ctrl+C` / `SIGINT` in the top-level `mso` process |

> Scripts should test `$?` against these codes. Exit 1 always means something went wrong; exit 3 is informational (the command ran cleanly but had no work to perform).

---

## Exception taxonomy

Domain code raises typed `MaestroError` subclasses instead of bare `RuntimeError` or `SystemExit`. Each class carries a `message`, an optional `hint` (an actionable next step), and a fixed `exit_code`.

```
MaestroError (exit 1)
├── MaestroConfigError (exit 1)   — workspace/config/licence not set up
├── MaestroNoWorkError (exit 3)   — nothing to do (empty queue, etc.)
└── MaestroUserError (exit 2)     — bad user input or invocation mistake
    └── MaestroAmbiguityError (exit 2) — multiple candidates; user must disambiguate
```

### MaestroError (base, exit 1)

General-purpose error base. Used when none of the more specific subclasses apply.

```
[Maestro] <message>
  Hint: <hint>
```

### MaestroConfigError (exit 1)

Workspace, configuration, or licence is not set up correctly. Example: `.mso/` directory not found, `workspace.json` is malformed, licence key invalid.

```
[Maestro] Could not find a Maestro workspace in this directory or any parent.
  Hint:
    Options:
      1. Run this command from your workspace root (where .mso/ lives).
      2. Use @PRJ to reference a registered project: mso status --project @MSO
      3. Scaffold a new workspace: mso init --project MYPROJECT
```

### MaestroUserError (exit 2)

The user made a correctable mistake: wrong flag, bad argument value, command not applicable in context.

### MaestroAmbiguityError (exit 2)

Multiple candidates match and the user must pick one. Inherits `MaestroUserError` (exit 2). Example: `mso usage` when multiple Claude project directories match the workspace.

```
[Maestro] Multiple Claude projects match this workspace.
  Hint:
    Specify which one:
      mso usage --project @MSO
    or set MAESTRO_PROJECT=MSO.
```

### MaestroNoWorkError (exit 3)

Nothing to do — the command ran cleanly but the queue was empty, the result set was empty, or there are no pending orders. Not an error; useful for scripting (`if mso dispatch; then ...`).

---

## Debug mode — `--debug` / `MAESTRO_DEBUG`

By default, unexpected errors (those not covered by the `MaestroError` hierarchy) produce a concise, user-friendly message instead of a raw Python traceback:

```
[Maestro] Unexpected error in 'dispatch': <ExceptionType>: <short message>
  Run with --debug for a full traceback.
  Report bugs at: https://github.com/tavisbasing/Maestro/issues
```

To see the full traceback, use either:

```bash
mso --debug <command> [args]
# or
MAESTRO_DEBUG=1 mso <command> [args]
```

When `--debug` is passed, `MAESTRO_DEBUG=1` is also injected into any child processes launched by the command (e.g. the dispatcher scripts), so the full traceback is visible at every level.

> **When to use debug mode:** when diagnosing an unexpected error you are about to report as a bug. For routine "something went wrong" messages, the friendly error is sufficient.

---

## Did-you-mean suggestions

When a mistyped subcommand is entered, `mso` uses difflib to find the closest match among its known subcommands:

```
$ mso statsu
[Maestro] argument command: invalid choice: 'statsu'
  Did you mean: 'status'?
  Run: mso status --help

usage: mso <command> ...
```

If multiple close matches exist, all are shown:

```
$ mso ord
[Maestro] argument command: invalid choice: 'ord'
  Did you mean: 'order', 'roles'?
  Run 'mso --help' for the full command list.
```

### Stray positional / project-flag hint

For commands that take a `--project` flag, passing the project acronym as a bare positional argument produces a targeted suggestion:

```
$ mso usage MSO
[Maestro] 'usage' takes no positional argument 'MSO'.
  Did you mean: mso usage --project MSO
```

---

## `run_cli()` — subprocess entry-point wrapper

Core scripts (`fleet_runner.py`, `fleet_monitor.py`, `fleet_usage_tracker.py`) are launched as subprocesses by `mso` commands. Each of these scripts wraps its `main()` call in `run_cli()` from `maestro.errors`:

```python
from maestro.errors import run_cli
if __name__ == "__main__":
    run_cli(main, command="usage")
```

`run_cli()` provides the same error surface as the top-level `mso` handler:

| Exception type | Behaviour |
|----------------|-----------|
| `MaestroError` (any subclass) | Print friendly message + hint; exit with `exc.exit_code` |
| `KeyboardInterrupt` | Silent clean exit — code 0 |
| `SystemExit` | Re-raise (pass-through, code unchanged) |
| Any other `Exception` | Print concise unexpected-error message; show full traceback only if `MAESTRO_DEBUG=1`; exit 1 |

This means `Ctrl+C` during `mso status`, `mso dispatch` (foreground), or `mso usage --watch` exits cleanly with no traceback.

---

## Ctrl+C behaviour

| Context | Behaviour |
|---------|-----------|
| `mso status` (live monitor) | Child monitor prints "… Monitor stopped." and exits. Parent `mso` catches `KeyboardInterrupt` and exits 0. No traceback. |
| `mso dispatch` (background launch) | `mso dispatch` returns immediately after launching the dispatcher; `Ctrl+C` does not apply to the daemonised fleet runner. |
| Any `mso` command | `KeyboardInterrupt` at the top-level `main()` exits with code 130 (POSIX convention for SIGINT-terminated processes). |

---

*See also: [TROUBLESHOOTING.md](TROUBLESHOOTING.md) for specific error scenarios, [CLI-REFERENCE.md](CLI-REFERENCE.md) for command flags.*
