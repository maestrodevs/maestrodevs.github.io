# Getting Started with Maestro

Maestro coordinates up to 5 parallel AI crews across your software project. Each crew runs as an independent Claude Code session, specialised for a specific role — planning, development, testing, documentation, security, or deployment.

This guide walks you from zero to your first fleet dispatch. **The recommended path uses the requirements workflow** — you describe what needs to happen, and Maestro handles planning and breaking work into orders.

> **New user?** Start with [QUICKSTART.md](QUICKSTART.md) for a 5-minute, command-only guide.

---

## Contents

1. [Prerequisites](#1-prerequisites)
2. [Installation and Setup Wizard](#2-installation-and-setup-wizard)
3. [Scaffold a Workspace](#3-scaffold-a-workspace)
4. [Configure Your Project](#4-configure-your-project)
5. [Create Work via Requirements (Recommended)](#5-create-work-via-requirements-recommended)
6. [Create Orders Directly (Advanced)](#6-create-orders-directly-advanced)
7. [Configure Billing Mode and Usage Estimation](#7-configure-billing-mode-and-usage-estimation)
8. [Launch the Fleet](#8-launch-the-fleet)
9. [Monitor Progress](#9-monitor-progress)
10. [Review Results](#10-review-results)
11. [Back Up and Restore Workspace State](#11-back-up-and-restore-workspace-state)
12. [Troubleshooting](#12-troubleshooting)

---

## 1. Prerequisites

Before installing Maestro, you need:

| Requirement | Version | Notes |
|-------------|---------|-------|
| Python | 3.9 or later | `python --version` to check |
| Claude Code | Latest | Install from [claude.ai/code](https://claude.ai/code) |
| Anthropic API key | — | Requires access to Sonnet 4.6, Haiku 4.5, and Opus 4.7 |
| Git | Any recent version | For cloning and branch management |

**Setting your API key:**

```bash
export ANTHROPIC_API_KEY=sk-ant-...
```

Add this to your shell profile (`~/.bashrc`, `~/.zshrc`, etc.) to persist it across sessions.

**Verifying Claude Code:**

```bash
claude --version
```

If `claude` is not on your PATH, follow the Claude Code installation guide at [claude.ai/code](https://claude.ai/code).

---

## 2. Installation and Setup Wizard

### Recommended: pip from GitHub

```bash
pip install maestro-fleet
```

Verify the installation:

```bash
mso version
```

You should see the installed version printed. If you get a "command not found" error, ensure your Python `bin` or `Scripts` directory is on your `PATH`.

### Alternative: Git Submodule

If you prefer to pin to a specific version or need offline access to the source scripts:

```bash
# In your workspace root
git submodule add https://github.com/tavisbasing/Maestro .maestro
git submodule update --init --recursive
```

With the submodule approach, run scripts directly:

```bash
python .maestro/core/fleet-runner.py --dispatch --max-crews 3
```

Or install pip alongside the submodule to use the `maestro` CLI while keeping the pinned source:

```bash
pip install maestro-fleet
mso dispatch --max-crews 3   # delegates to your pinned submodule
```

### Validate prerequisites with the setup wizard

> **Planned** — The `mso setup` command is not yet available. Until then, manually verify the prerequisites listed below.

After installing, run the setup wizard to verify your environment:

```bash
mso setup
```

The wizard runs three phases:

1. **Prerequisite checks** — Python version, Claude Code, API key, Git, network access
2. **Project analysis** — scans your registered project for language, structure, and existing tooling
3. **Tailored suggestions** — prints a cheatsheet of recommended first requirements and voyages based on your project

For CI/CD or a quick headless check:

```bash
mso setup --check
```

Exits with code `0` if all prerequisites pass, `1` if any fail. No Phase 2 or 3 output.

---

## 3. Scaffold a Workspace

Run `mso init` to create the directory structure Maestro needs:

```bash
mso init --project MYPROJ
```

Replace `MYPROJ` with your project acronym (2–8 uppercase letters, e.g. `OTM`, `PSG`, `ACME`).

By default, this creates the structure in the current directory. To specify a different location:

```bash
mso init --project MYPROJ --directory /path/to/my-workspace
```

**What gets created:**

```
.maestro/
├── config/
│   ├── workspace.json          # Workspace settings
│   ├── projects.json           # Project registry
│   └── projects/
│       └── MYPROJ.json         # Per-project role configuration
├── orders/
│   ├── active/                 # In-flight orders
│   ├── complete/               # Finished orders
│   └── failed/                 # Failed orders
├── voyages/
│   ├── active/
│   └── complete/
├── queues/
│   ├── orders/                 # Primary dispatch queue
│   ├── bugs/
│   ├── security/
│   └── ...
├── plans/
├── crews/
│   ├── crew1/ through crew5/
└── CHAIN-OF-COMMAND.md
CLAUDE.md                       # Quartermaster configuration
.gitignore
```

> **Note:** `mso init` scaffolds a valid workspace (config, orders, queues, etc.). Commands like `dispatch` and `status` additionally require the core scripts, which are provided by adding the repo as a git submodule (see Step 2 below).

---

## 4. Configure Your Project

Maestro needs to know where your project lives and how each role should interact with it.

### Step 1 — Register your project repo

Edit `.maestro/config/projects.json`:

```json
{
  "projects": {
    "MYPROJ": {
      "name": "My Project",
      "acronym": "MYPROJ",
      "directory": "my-project",
      "repo": "your-org/my-project",
      "org": "your-org",
      "defaultBranch": "main",
      "voyageBranchPattern": "voyage/{VOYAGE-ID}",
      "cloneProtocol": "https",
      "configFile": "config/projects/MYPROJ.json"
    }
  }
}
```

`directory` is the path to your project repo, relative to the workspace root.

### Step 2 — Configure role paths

Edit `.maestro/config/projects/MYPROJ.json` to tell each role where to find and write files in your project:

```json
{
  "common": {
    "projectRoot": "my-project",
    "sourceRoot": "my-project/src",
    "documentationRoot": "my-project/docs"
  },
  "roles": {
    "NAV": {
      "inputs": { "fullCodebase": "my-project/**/*" },
      "outputs": { "plans": ".maestro/plans/" }
    },
    "SHP": {
      "inputs": { "sourceCode": "my-project/src/**" },
      "outputs": { "sourceCode": "my-project/src/" }
    }
  }
}
```

Adjust paths to match your project's actual structure. The `mso init` command generates a starter config — you typically only need to verify the paths are correct.

### Step 3 — Ensure your project repo is available

The Fleet Admiral can clone your project repo automatically when dispatching, or you can clone it manually:

```bash
git clone https://github.com/your-org/my-project my-project
```

---

## 5. Create Work via Requirements (Recommended)

Requirements are the recommended entry point to Maestro. You describe *what* needs to happen; a Navigator crew breaks it into a voyage plan and orders.

### Requirement lifecycle

```
create → AWAITING_APPROVAL → approve → APPROVED → plan (Navigator)
→ PLANNING → PLANNED → approve plan → IN_PROGRESS → COMPLETE
```

### Step 1 — Create a requirement

```bash
# Interactive mode (prompts for all fields)
mso requirement create --project MYPROJ --interactive

# From a template
mso requirement create --project MYPROJ --template new-feature --title "Add user authentication"

# Direct flags
mso requirement create \
  --project MYPROJ \
  --title "Add user authentication" \
  --type feature \
  --priority high
```

**Built-in templates:**

| Template | Use for |
|----------|---------|
| `new-feature` | Feature implementation |
| `project-setup` | CI/CD, linting, baseline structure |
| `security-review` | Security audit of a module or feature |
| `test-coverage` | Increase test coverage |
| `doc-audit` | Documentation review and update |
| `bug-report` | Structured bug investigation |
| `performance` | Performance profiling and optimisation |
| `refactor` | Code quality and restructuring |

The requirement file is written to `.maestro/requirements/REQ-MYPROJ-YYYY-NNNN.md`.

### Step 2 — Review and approve the requirement

```bash
# List all requirements and their status
mso requirement list

# Show a specific requirement
mso requirement show REQ-MYPROJ-2026-0001

# Approve (moves status from AWAITING_APPROVAL to APPROVED)
mso approve --requirement .maestro/requirements/REQ-MYPROJ-2026-0001.md

# Or reject with a reason
mso reject --requirement .maestro/requirements/REQ-MYPROJ-2026-0001.md --reason "Needs more detail"
```

### Step 3 — Plan (Navigator creates the voyage)

After approval, dispatch and a Navigator crew will pick up the requirement, create a voyage plan, and submit it for your review:

```bash
mso dispatch --max-crews 1
# Navigator creates: .maestro/plans/NAV-REQ-MYPROJ-2026-0001.md
# Approve the plan when it appears in the APPROVALS dashboard panel
mso approve --plan .maestro/plans/NAV-REQ-MYPROJ-2026-0001.md
```

Once the plan is approved, the Fleet Admiral dispatches the work crews automatically.

---

## 6. Create Orders Directly (Advanced)

If you prefer to skip the requirements workflow, you can create orders and voyages directly using the CLI helpers or by writing JSON files manually.

### Using CLI helpers

```bash
# Create an order interactively
mso create-order --interactive

# Create from a template
mso create-order --template feature --project MYPROJ --title "Add user authentication"

# Create a voyage
mso create-voyage --project MYPROJ --title "Auth sprint" --orders FTR-MYPROJ-2026-0001
```

### Using raw JSON

Drop a JSON file in `.maestro/queues/orders/`. See [ORDERS-AND-VOYAGES.md](ORDERS-AND-VOYAGES.md) for the full order format.

---

## 7. Configure Billing Mode and Usage Estimation

Maestro v2.0.0 introduces billing mode configuration and pre-dispatch cost estimation. These features help you understand and control API costs before work begins.

### Billing modes

Set the billing mode in `.maestro/config/workspace.json` under the `billing` key:

```json
{
  "billing": {
    "mode": "track",
    "currency": "USD",
    "budgetPerVoyage": null,
    "budgetTotal": null,
    "alertThreshold": 0.8
  }
}
```

| Mode | Behaviour |
|------|-----------|
| `track` *(default)* | Record and report usage after each session. No enforcement. |
| `enforce` | Halt dispatch when a `budgetPerVoyage` or `budgetTotal` threshold is exceeded. |
| `estimate-first` | Require Captain to review an estimate before each dispatch is launched. |

**Budget fields:**

| Field | Type | Description |
|-------|------|-------------|
| `budgetPerVoyage` | number or null | Maximum spend per voyage in `currency`. Null means no limit. |
| `budgetTotal` | number or null | Maximum cumulative spend across all voyages. Null means no limit. |
| `alertThreshold` | float (0–1) | Fraction of budget at which a warning is shown (e.g. `0.8` = warn at 80%). |

### Estimating cost before dispatch

Use `mso estimate` to preview expected token usage and cost for queued orders without launching any crews:

```bash
# Estimate all queued orders
mso estimate

# Estimate a specific voyage
mso estimate --voyage VOY-MYPROJ-2026-0001
```

Example output:

```
[Maestro] Usage estimate — queued orders

  FTR-MYPROJ-2026-0001  SHP  ~85k tokens  ~$0.42
  DOC-MYPROJ-2026-0002  SCR  ~30k tokens  ~$0.15

  Total: 2 orders, ~115k tokens, estimated cost ~$0.57
```

Estimates are based on historical averages for the same role and order type, combined with order complexity heuristics (description length, target file count). Actual usage will vary.

> **Tip:** In `estimate-first` mode, `mso dispatch` will run an estimate and display it before asking for Captain confirmation. Press Enter to proceed or Ctrl+C to cancel.

---

## 8. Launch the Fleet

With your orders queued, launch the dispatcher:

```bash
mso dispatch --max-crews 3
```

The Fleet Admiral will:

1. Scan all queues for available orders
2. Check dependencies (orders with `dependsOn` wait until prerequisites are complete)
3. Assign each order to a crew slot (crew1 through crew5)
4. Launch a Claude Code session for each crew, injecting the role, order, and project context
5. Monitor crew health and advance crews through multi-pass iterations

**Common dispatch options:**

```bash
# Start up to 5 concurrent crews
mso dispatch --max-crews 5

# Clean up stale state before dispatching
mso dispatch --cleanup --max-crews 3

# Longer timeout for complex orders (default is 90 minutes)
mso dispatch --max-crews 3 --timeout 120
```

---

## 9. Monitor Progress

While crews are running, watch the fleet dashboard:

```bash
# Live dashboard (refreshes automatically in the alt buffer; Ctrl+C restores scrollback)
mso status

# One-shot summary (pipe-friendly plain output)
mso status --once

# Compact view — one line per crew, for narrow terminals or tmux panes
mso status --once --compact
```

The dashboard (Squad Monitor v5.0) shows several sections:

- **Voyage block** — Each active voyage with a progress bar, completed/total orders, and an ETA estimate. On API billing, a SPEND line tracks workspace cost.
- **ESCALATIONS** *(red, appears only when needed)* — Blocking issues raised by crews that require your intervention.
- **PENDING REVIEW** *(yellow, appears only when needed)* — Voyages, plans, or requirements waiting for your sign-off, plus orders paused at a human review gate. If you see this section, review the listed items and approve or reject before the relevant work proceeds. See OWNER-GUIDE.md for how the approval workflow works.
- **Crews** — Live status dot per crew: role, model, order, iteration progress, live turn counter, token spend, activity, and a heuristic ETA.
- **QUEUE** — Pending order count with per-role breakdown.
- **LIFECYCLE** — Recent fleet events (crew starts, completions, role transitions).
- **Footer** — Dispatcher status, bridge status, aggregate counts, refresh interval.

To watch a specific crew:

```bash
mso crew --crew 1 --watch
```

Progress details for each crew are written to `.maestro/crews/crewN/progress.md`. You can read these directly if you want detail beyond what the dashboard shows.

---

## 10. Review Results

When orders complete, crews commit their changes and update the order status. Review the output:

**Check completed orders:**
```bash
ls .maestro/orders/complete/
```

**Check token usage:**
```bash
mso usage --summary
```

The summary shows total token consumption and estimated API cost across all projects and orders. Token data is captured automatically at the end of each crew session and stored in `.maestro/usage/orders/`.

**Check usage for a specific voyage:**
```bash
mso usage --voyage VOY-MYPROJ-2026-0001
```

This breaks down token consumption by order within the voyage, so you can see which orders were most expensive.

**Generate a full usage report:**
```bash
mso usage --report --output .maestro/reports/usage-report.md
```

**Run post-voyage verification** (builds and tests):
```bash
mso verify --voyage VOY-MYPROJ-2026-0001
```

---

## 11. Back Up and Restore Workspace State

Maestro workspaces accumulate valuable state over time — orders, voyages, plans, usage records, and configuration. The `mso backup` and `mso restore` commands let you snapshot and recover that state from a single ZIP archive.

### Create a backup

```bash
# Full workspace backup (all projects)
mso backup
```

The archive is written to `./maestro-backups/` in your workspace root. The filename includes the scope and a timestamp, for example:

```
maestro-backups/maestro-backup-all-2026-03-30-143000.zip
```

### Backup a single project (multi-project workspaces)

If your workspace manages multiple projects, you can back up just one:

```bash
mso backup --project OTM
```

Only files associated with the `OTM` project are included (orders, voyages, prompts, usage records whose filenames contain `-OTM-`). Workspace-level config is always included.

### Write to a custom directory

```bash
mso backup --output /mnt/backups/maestro/
```

### List available backups

```bash
mso backup --list
```

Prints a summary of each backup archive in the output directory, including creation time, projects included, Maestro version, and file count.

### Auto-backup before cleanup

`mso cleanup` automatically creates a full backup before removing stale state. The backup path is printed so you always know where the pre-cleanup snapshot is:

```
[Maestro] Auto-backup created: /workspace/maestro-backups/maestro-backup-all-2026-03-30-143000.zip
```

### Restore from a backup

```bash
# Restore from a backup (skips existing files by default)
mso restore maestro-backup-all-2026-03-30-143000.zip
```

By default, restore skips any file that already exists at the destination — safe to run against an active workspace without overwriting current work.

**Preview before restoring:**

```bash
mso restore maestro-backup-all-2026-03-30-143000.zip --dry-run
```

Prints every file that would be written without writing anything. Run this first when restoring into a workspace with active work.

**Restore a single project from a full backup:**

```bash
mso restore maestro-backup-all-2026-03-30-143000.zip --project OTM
```

Only OTM-associated files are extracted, leaving other projects untouched.

**Conflict resolution options:**

| Flag | Behaviour |
|------|-----------|
| *(none)* | Skip files that already exist |
| `--force` | Overwrite existing files unconditionally |
| `--merge` | Keep whichever copy has the later modification time |
| `--dry-run` | Preview without writing anything |

---

## 12. Troubleshooting

### "command not found: mso"

Your Python `bin` or `Scripts` directory is not on your PATH.

**Fix (Linux/macOS):**
```bash
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
source ~/.bashrc
```

**Fix (Windows):**
Add `%APPDATA%\Python\PythonXX\Scripts` to your PATH in System Environment Variables.

### "claude: command not found"

Claude Code is not installed or not on your PATH. Install it from [claude.ai/code](https://claude.ai/code) and follow the PATH setup instructions.

### Crew launches but immediately stops

Check whether `ANTHROPIC_API_KEY` is set:
```bash
echo $ANTHROPIC_API_KEY
```

If blank, set it and retry. The key must have access to Sonnet 4.6, Haiku 4.5, and Opus 4.7.

### Orders are not being picked up

Confirm the order file is in `.maestro/queues/orders/` (not a subdirectory of it) and that the JSON is valid:

```bash
python -c "import json; json.load(open('.maestro/queues/orders/YOUR-ORDER-ID.json'))"
```

If the `dependsOn` field references an order ID that is not yet complete, the dispatcher will hold the order until the dependency is resolved.

### A crew is stuck or not making progress

1. Check the crew's progress file: `.maestro/crews/crewN/progress.md`
2. Check the escalation queue: `.maestro/queues/escalations/` — the crew may have raised a blocking issue
3. If the crew process has died, run `mso cleanup` then `mso dispatch` again

### Stale state from a previous run

```bash
mso cleanup
```

This stops orphaned processes and resets stale lock files. Safe to run at any time.

---

## Next Steps

- [QUICKSTART.md](QUICKSTART.md) — 5-minute command-only guide
- [CLI-REFERENCE.md](CLI-REFERENCE.md) — All commands, flags, and examples
- [OPERATOR-GUIDE.md](OPERATOR-GUIDE.md) — Daily operations, scaling, cost management, notifications, and reporting
- [ROLES-GUIDE.md](ROLES-GUIDE.md) — Understanding what each crew role does
- [ORDERS-AND-VOYAGES.md](ORDERS-AND-VOYAGES.md) — Creating and managing work
- OWNER-GUIDE.md — Framework configuration and development

---

*Maestro Maestro v2.5.0 — [maestroai.com](https://maestroai.com) — Licensing enquiries: [maestro@tech127.com](mailto:maestro@tech127.com).*
