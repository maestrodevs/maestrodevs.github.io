# Maestro — Architecture Overview

> A high-level overview for operators, security reviewers, and buyers. For the
> full feature list see [CAPABILITIES.md](CAPABILITIES.md).

Maestro is a Python package (`maestro`, CLI `mso`) that orchestrates multiple
autonomous Claude Code sessions to deliver software work. It runs **on your
infrastructure** — your machine or your CI — and drives the Claude CLI you already
trust. Maestro itself stores no source code; a project keeps only its own
artefacts (orders, voyages, plans, logs) under a local `.mso/` directory.

## The chain

```
Human  →  LEAD (interactive Claude)  →  Dispatcher (mso dispatch)  →  Crews (autonomous Claude)
```

- **Human** sets direction and approves PRs.
- **LEAD** is your interactive Claude session.
- **Dispatcher** manages the lifecycle of crews — launching, monitoring, and recovering them.
- **Crews** are autonomous Claude sessions, each isolated in its own git worktree, executing one role of one order at a time.

## How work flows

1. You create a **voyage** (one branch, one PR) containing one or more **orders**.
2. The dispatcher assigns each order to a free crew slot and runs it through its **role sequence** (e.g. plan → build → test).
3. Each crew works in an **isolated worktree**, commits to its own branch, and converges into the voyage branch.
4. When all orders complete, the voyage PR is finalised for your review and merge.

## Where things run & live

- **Execution:** local processes (or your CI runner) calling the Claude CLI. No Maestro-hosted compute.
- **Data:** everything stays in your repo / workspace. Runtime state (`.mso/crews/`, `.mso/logs/`) is git-ignored and local.
- **Network:** Maestro calls the Claude API via the CLI and (optionally) `gh` for PRs and your configured integrations (e.g. Slack). Nothing else leaves your environment by default.

## Safety model

- Crews are confined to their own branch and worktree; guards deny any git/file action outside their assigned scope.
- Secret-pattern scanning runs on crew actions.
- Optional human-review gates pause work for approval between roles.
- Per-role tool scoping restricts what each role can do (e.g. read-only security review).

For security posture, compliance mapping, and data-flow details, contact us for the
enterprise security pack.
