"""
Maestro exception taxonomy.

Domain code raises these instead of bare RuntimeError / SystemExit so the
central CLI handler can present a consistent, user-friendly error surface.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Callable


class MaestroError(Exception):
    """Base class for all Maestro user-facing errors.

    Attributes:
        hint  -- optional actionable next step shown below the error message
        exit_code -- process exit code (default 1)
    """

    exit_code: int = 1

    def __init__(self, message: str, *, hint: str | None = None) -> None:
        super().__init__(message)
        self.hint = hint


class MaestroUserError(MaestroError):
    """Bad user input or invocation mistake — exit 2."""

    exit_code = 2


class MaestroConfigError(MaestroError):
    """Workspace / config / licence not set up correctly — exit 1."""

    exit_code = 1


class MaestroNoWorkError(MaestroError):
    """Nothing to do (e.g. empty queue, no pending orders) — exit 3."""

    exit_code = 3


class MaestroAmbiguityError(MaestroUserError):
    """Multiple candidates match; user must disambiguate — exit 2 (inherits MaestroUserError)."""


def run_cli(main_fn: "Callable[[], None]", command: str = "") -> None:
    """Entry-point wrapper for subprocess-dispatched core scripts.

    Catches MaestroError → clean message + correct exit code.
    Catches unexpected exceptions → concise message; full traceback only under MAESTRO_DEBUG.
    Catches KeyboardInterrupt → silent clean exit (code 0) for interactive-quit gestures.
    """
    import os
    import sys
    import traceback
    from maestro.cli_ui import print_error, print_unexpected

    cmd = command or (main_fn.__name__ if hasattr(main_fn, "__name__") else "maestro")
    try:
        main_fn()
    except MaestroError as exc:
        print_error(str(exc), hint=exc.hint)
        sys.exit(exc.exit_code)
    except KeyboardInterrupt:
        sys.exit(0)
    except SystemExit:
        raise
    except Exception as exc:
        if os.environ.get("MAESTRO_DEBUG"):
            traceback.print_exc()
        else:
            print_unexpected(exc, cmd)
        sys.exit(1)
