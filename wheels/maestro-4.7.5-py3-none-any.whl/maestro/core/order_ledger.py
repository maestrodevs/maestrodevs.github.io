"""Runtime order ledger — the git-immune dispatch gate (BUG-MSO-2026-0294).

Why this exists
---------------
The duplicate-dispatch / re-dispatch family recurred three times (BUG-0248
v4.3.5, BUG-0263 v4.3.9, PSG VOY-PSG-2026-0344 on v4.6.1) because every
prior guard anchored dispatch eligibility to git-rewindable state: the
in-progress claim lives in the queue JSON, and the BUG-0263 dedup reads
``orders/complete|failed`` — all uncommitted working-tree writes that a
single ``git reset --hard`` (see BUG-MSO-2026-0295) rewinds in one stroke,
resurrecting completed orders as PENDING and erasing the evidence the
guards relied on.

This module keeps an append-only JSONL ledger at
``.mso/state/order-ledger.jsonl``. The ``state/`` directory is gitignored
(runtime state, like ``crews/`` and ``logs/``), so NO git operation —
reset, checkout, pull, PR round-trip — can touch it. ``scan_all_queues``
consults the replayed ledger before anything else: an order with a
TERMINAL entry is never dispatched again regardless of what its queue file
claims, and an order CLAIMED by a live crew is never handed to a second
crew.

Event grammar (one JSON object per line)
----------------------------------------
    {"ts": iso8601, "event": "CLAIMED",  "orderId": id, "role": r, "crew": n, "pid": p}
    {"ts": iso8601, "event": "ADVANCED", "orderId": id, "fromRole": r1, "toRole": r2}
    {"ts": iso8601, "event": "TERMINAL", "orderId": id, "status": "COMPLETE"|"FAILED"|"STALLED"}
    {"ts": iso8601, "event": "RELEASED", "orderId": id, "reason": str}

Replay semantics: TERMINAL is forever. CLAIMED is cleared by a subsequent
ADVANCED or RELEASED (role advance re-queues the order for its next role;
release/requeue frees it for a fresh crew). A CLAIMED whose pid is dead is
treated as released — the crash-recovery path owns it.

All writes are best-effort: a ledger failure must never crash the
dispatcher (the file-based guards remain as the degraded fallback).
"""

from __future__ import annotations

import json
import os
import threading
from datetime import datetime
from pathlib import Path
from typing import Dict, Optional

LEDGER_RELPATH = Path("state") / "order-ledger.jsonl"
COMPACT_THRESHOLD_LINES = 5000

# Serialises ledger file access within this process. The dispatcher is the
# only WRITER process, but it is not single-threaded (bridge notifier, demo
# drivers, tests) — and on Windows, concurrent appends through separate
# handles can interleave mid-line, corrupting the JSONL. Found by the
# stress suite (test_ledger_survives_concurrent_writers).
_WRITE_LOCK = threading.Lock()


def _workspace_dir() -> Path:
    from maestro.workspace import get_workspace_dir
    return get_workspace_dir()


def ledger_path(workspace_dir: Optional[Path] = None) -> Path:
    return (workspace_dir or _workspace_dir()) / LEDGER_RELPATH


# ---------------------------------------------------------------------------
# Writers (append-only, best-effort)
# ---------------------------------------------------------------------------

def _append(record: dict, workspace_dir: Optional[Path] = None) -> None:
    try:
        path = ledger_path(workspace_dir)
        path.parent.mkdir(parents=True, exist_ok=True)
        record = {"ts": datetime.now().isoformat(), **record}
        with _WRITE_LOCK:
            with open(str(path), "a", encoding="utf-8") as f:
                f.write(json.dumps(record) + "\n")
    except Exception:
        pass  # never let ledger I/O take down the dispatcher


def record_claimed(order_id: str, role: str, crew: int,
                   pid: Optional[int] = None,
                   workspace_dir: Optional[Path] = None) -> None:
    _append({"event": "CLAIMED", "orderId": order_id, "role": role,
             "crew": crew, "pid": pid or os.getpid()}, workspace_dir)


def record_advanced(order_id: str, from_role: str, to_role: str,
                    workspace_dir: Optional[Path] = None) -> None:
    _append({"event": "ADVANCED", "orderId": order_id,
             "fromRole": from_role, "toRole": to_role}, workspace_dir)


def record_terminal(order_id: str, status: str,
                    workspace_dir: Optional[Path] = None) -> None:
    _append({"event": "TERMINAL", "orderId": order_id, "status": status},
            workspace_dir)


def record_released(order_id: str, reason: str,
                    workspace_dir: Optional[Path] = None) -> None:
    _append({"event": "RELEASED", "orderId": order_id, "reason": reason},
            workspace_dir)


def record_reopened(order_id: str, reason: str,
                    workspace_dir: Optional[Path] = None) -> None:
    """BUG-MSO-2026-0297: sanctioned reopen of a TERMINAL order (`mso order retry`).

    The ONLY event that clears a TERMINAL verdict. Without it, a STALLED
    order is unrecoverable: the ledger vetoes re-dispatch forever and the
    scanner self-heal re-archives any manual file move (GKT F2).
    """
    _append({"event": "REOPENED", "orderId": order_id, "reason": reason},
            workspace_dir)


# ---------------------------------------------------------------------------
# Replay view
# ---------------------------------------------------------------------------

class LedgerView:
    """Replayed ledger state: per-order verdicts for the dispatch gate."""

    def __init__(self, terminal: Dict[str, str], claimed: Dict[str, dict],
                 roles: Optional[Dict[str, str]] = None):
        self.terminal = terminal    # order_id -> terminal status
        self.claimed = claimed      # order_id -> {"crew": n, "pid": p, "role": r}
        self.roles = roles or {}    # order_id -> current expected role

    def is_terminal(self, order_id: str) -> bool:
        return order_id in self.terminal

    def current_role(self, order_id: str) -> Optional[str]:
        """The role the order should run NEXT, per the ledger.

        BUG-0248 / PSG bug 3 (advance-loss loop): the role advance is a
        working-tree write to a git-tracked queue file; a rewind reverts it
        and the order loops PLN↔BLD forever. The ledger's ADVANCED events
        are the durable record of how far the order really progressed —
        scan and complete_order reconcile the file against this.
        """
        return self.roles.get(order_id)

    def live_claim(self, order_id: str, is_alive=None) -> Optional[dict]:
        """Return the claim record if *order_id* is claimed by a LIVE crew.

        A claim whose pid is dead is NOT live — crash recovery owns it.
        ``is_alive`` is injectable for tests; defaults to the dispatcher's
        ctypes-based check.
        """
        claim = self.claimed.get(order_id)
        if not claim:
            return None
        if is_alive is None:
            from maestro.core.fleet_monitor import is_process_alive as is_alive
        pid = claim.get("pid")
        if pid and is_alive(pid):
            return claim
        return None


def load_view(workspace_dir: Optional[Path] = None) -> LedgerView:
    """Replay the ledger into a LedgerView. Corrupt lines are skipped."""
    terminal: Dict[str, str] = {}
    claimed: Dict[str, dict] = {}
    roles: Dict[str, str] = {}
    path = ledger_path(workspace_dir)
    if path.exists():
        try:
            for line in path.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if not line:
                    continue
                try:
                    rec = json.loads(line)
                except json.JSONDecodeError:
                    continue
                oid = rec.get("orderId")
                event = rec.get("event")
                if not oid or not event:
                    continue
                if event == "TERMINAL":
                    terminal[oid] = rec.get("status", "COMPLETE")
                    claimed.pop(oid, None)
                elif event == "CLAIMED":
                    claimed[oid] = {"crew": rec.get("crew"),
                                    "pid": rec.get("pid"),
                                    "role": rec.get("role")}
                    if rec.get("role"):
                        roles[oid] = rec["role"]
                elif event == "ADVANCED":
                    claimed.pop(oid, None)
                    if rec.get("toRole"):
                        roles[oid] = rec["toRole"]
                elif event == "RELEASED":
                    claimed.pop(oid, None)
                elif event == "REOPENED":
                    # BUG-MSO-2026-0297: `mso order retry` — clears the terminal
                    # verdict AND the role memory (the reopened file's targetRole
                    # is authoritative; stale ledger role must not override it).
                    terminal.pop(oid, None)
                    claimed.pop(oid, None)
                    roles.pop(oid, None)
        except OSError:
            pass
    return LedgerView(terminal, claimed, roles)


# ---------------------------------------------------------------------------
# Startup: seed + compact
# ---------------------------------------------------------------------------

def seed_if_missing(workspace_dir: Optional[Path] = None) -> bool:
    """Create the ledger from existing workspace state if it doesn't exist.

    Upgrade path for workspaces that pre-date the ledger: every order
    already archived in ``orders/complete|failed`` gets a TERMINAL entry;
    every live crew's current orderId gets a CLAIMED entry. Idempotent —
    does nothing when the ledger file exists. Returns True if seeded.
    """
    ws = workspace_dir or _workspace_dir()
    path = ledger_path(ws)
    if path.exists():
        return False

    records = []
    now = datetime.now().isoformat()
    for sub, status in (("orders/complete", "COMPLETE"), ("orders/failed", "FAILED")):
        d = ws / sub
        if d.exists():
            for f in d.glob("*.json"):
                records.append({"ts": now, "event": "TERMINAL",
                                "orderId": f.stem, "status": status})

    try:
        from maestro.core.fleet_monitor import is_process_alive, load_json_safe
        crews_dir = ws / "crews"
        if crews_dir.exists():
            for crew_dir in crews_dir.glob("crew*"):
                state = load_json_safe(crew_dir / "state.json") or {}
                if state.get("status") in ("RUNNING", "ACTIVE"):
                    pid = state.get("pid")
                    oid = state.get("orderId")
                    if oid and pid and is_process_alive(pid):
                        try:
                            crew_num = int(crew_dir.name.replace("crew", ""))
                        except ValueError:
                            crew_num = 0
                        records.append({"ts": now, "event": "CLAIMED",
                                        "orderId": oid,
                                        "role": state.get("role", ""),
                                        "crew": crew_num, "pid": pid})
    except Exception:
        pass

    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("".join(json.dumps(r) + "\n" for r in records),
                        encoding="utf-8")
        return True
    except OSError:
        return False


def compact(workspace_dir: Optional[Path] = None,
            threshold: int = COMPACT_THRESHOLD_LINES) -> bool:
    """Rewrite the ledger as one latest-state line per order when it grows
    past *threshold* lines. Returns True if compacted."""
    ws = workspace_dir or _workspace_dir()
    path = ledger_path(ws)
    if not path.exists():
        return False
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError:
        return False
    if len(lines) <= threshold:
        return False

    with _WRITE_LOCK:
        view = load_view(ws)
        now = datetime.now().isoformat()
        records = [
            {"ts": now, "event": "TERMINAL", "orderId": oid, "status": status}
            for oid, status in sorted(view.terminal.items())
        ] + [
            {"ts": now, "event": "CLAIMED", "orderId": oid, **claim}
            for oid, claim in sorted(view.claimed.items())
        ] + [
            # Preserve role progression for in-flight-but-unclaimed orders
            # (BUG-0248 advance-loss reconciliation needs it across compactions).
            {"ts": now, "event": "ADVANCED", "orderId": oid, "toRole": role}
            for oid, role in sorted(view.roles.items())
            if oid not in view.terminal and oid not in view.claimed
        ]
        try:
            path.write_text("".join(json.dumps(r) + "\n" for r in records),
                            encoding="utf-8")
            return True
        except OSError:
            return False
