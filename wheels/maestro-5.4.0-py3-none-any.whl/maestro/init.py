"""
maestro init — Scaffold a new Maestro workspace.

Creates the .mso/ directory structure and template config files
so a new project can start using Maestro immediately.
"""

from __future__ import annotations

import json
import re
import shutil
from pathlib import Path

from maestro.registry import register_project
from maestro.workspace import MSO_DIR_NAME, resolve_artefact_dir


# ---------------------------------------------------------------------------
# Directory structure for .mso/
# ---------------------------------------------------------------------------

_DIR_SUBPATHS = [
    "orders/active",
    "orders/complete",
    "orders/failed",
    "voyages/active",
    "voyages/complete",
    "prompts/active",
    "prompts/complete",
    "crews/crew1",
    "crews/crew2",
    "crews/crew3",
    "crews/crew4",
    "crews/crew5",
    "queues/orders",
    "queues/bugs",
    "queues/security",
    "queues/defects",
    "queues/requests",
    "queues/breakdown",
    "queues/high-level",
    "queues/explicit",
    "queues/escalations",
    "queues/review",
    "handoffs",
    "plans",
    "reports/qa",
    "reports/security",
    "reports/investigation",
    "reports/voyage",
    "requirements",
    "logs",
    "temp",
    "usage/orders",
    "config/projects",
    "bridge/questions",
    "bridge/answers",
    "identity/users",
    "identity/groups",
]

# Workspace-root-relative scaffold dirs (public shape unchanged — consumers
# like `mso update` iterate these as ".mso/…" strings).
DIRS = [f"{MSO_DIR_NAME}/{sub}" for sub in _DIR_SUBPATHS]

# Runtime (gitignored) scaffold roots — no .gitkeep is placed under these.
_RUNTIME_SCAFFOLD_ROOTS = {
    f"{MSO_DIR_NAME}/{d}" for d in ("crews", "logs", "temp", "bridge")
}

# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def scaffold_workspace(project: str, directory: Path, force: bool = False,
                       enterprise: bool = False, pack: "object | None" = None) -> None:
    """Scaffold a new Maestro workspace for the given project acronym.

    Idempotency: if ``.mso/`` already exists, skip scaffold and just register globally.
    When enterprise=True, walks the operator through anchor provider configuration.
    When *pack* (a :class:`maestro.packs.Pack`) is given, its persona / role overlays /
    order templates / gates / workspace defaults are layered onto the workspace AFTER
    the standard scaffold (FTR-MSO-2026-0383). The ``sdlc`` pack contributes nothing
    beyond the manifest, so ``--pack sdlc`` is byte-equivalent to a plain init.
    """
    project = project.upper()
    base = directory.resolve()

    mso_dir = resolve_artefact_dir(base)

    # -----------------------------------------------------------------------
    # Idempotency: already initialised
    # -----------------------------------------------------------------------
    if mso_dir.exists() and not force:
        print(f"[Maestro] .mso/ already exists at {base} — skipping scaffold.")
        if pack is not None:
            _apply_pack_scaffold(pack, base)
        _register_workspace(project, base)
        return

    if mso_dir.exists() and force:
        import shutil
        shutil.rmtree(mso_dir)
        print(f"[Maestro] --force: removed existing .mso/")

    migrated: list[str] = []
    skipped: list[str] = []
    backed_up = False

    # -----------------------------------------------------------------------
    # Fresh scaffold
    # -----------------------------------------------------------------------
    print(f"[Maestro] Scaffolding workspace for project {project} at {base}")

    for rel in DIRS:
        d = base / rel
        d.mkdir(parents=True, exist_ok=True)
        # Only place .gitkeep in empty leaf dirs that aren't runtime-gitignored
        if not any(d.iterdir()):
            if not any(rel.startswith(r) for r in _RUNTIME_SCAFFOLD_ROOTS):
                (d / ".gitkeep").touch()

    # -- workspace.json ------------------------------------------------------
    ws_config = {
        "$schema": "Maestro — Workspace Config",
        "schemaVersion": "2.5.0",
        "mode": "single-project",
        "project": project,
        "defaultGitHubOrg": None,  # Set to your GitHub org (e.g. "my-org") — required for auto-PR
        "notes": f"Maestro v2.4.0 — {project} workspace",
        "completion": {
            "idleWatchdog": {
                "enabled": True,
                "idleMinutes": 30,
                "action": "cleanup",
            },
            "onVoyageComplete": {
                "archiveVoyageOnMerge": True,
                "archiveOrders": True,
                "autoRelease": False,
            },
            # FTR-MSO-2026-0287: voyage PR is a draft until the voyage finalises,
            # so intermediate per-role convergence pushes don't re-trigger CI.
            "voyagePr": {
                "draft": True,
                "promoteOnFinalisation": True,
            },
        },
        # FTR-MSO-2026-0287: optional local verify gate — a shell command run in
        # the crew worktree before the convergence push; non-zero exit holds the
        # order (no push, no CI). Empty = disabled. e.g. "dotnet build -c Release".
        "verifyCommand": "",
        "verifyTimeoutMinutes": 20,
    }
    _merge_write_json(mso_dir / "config/workspace.json", ws_config)

    # -- projects.json -------------------------------------------------------
    projects_json = mso_dir / "config/projects.json"
    if not projects_json.exists():
        _write_json(projects_json, {
            "$schema": "Maestro — Project Registry",
            "description": "Registry of all projects managed by Maestro.",
            "projects": {
                project: {
                    "name": project,
                    "acronym": project,
                    "directory": project.lower(),
                    "repo": f"your-org/{project.lower()}",
                    "org": "your-org",
                    "defaultBranch": "main",
                    "voyageBranchPattern": "voyage/{VOYAGE-ID}",
                    "cloneProtocol": "ssh",
                    "configFile": f"config/projects/{project}.json",
                }
            },
            "defaultProject": project,
        })

    # -- per-project config stub ---------------------------------------------
    per_project = mso_dir / f"config/projects/{project}.json"
    if not per_project.exists():
        _write_json(per_project, {
            "$schema": f"Maestro — {project} Project Config",
            "project": project,
            "maestroRoot": MSO_DIR_NAME,
            "projectRoot": project.lower(),
            "notes": f"Update repo, directory, and role paths for {project}.",
        })

    # -- .mso/config/mcp-servers.json from template --------------------------
    mcp_registry = mso_dir / "config" / "mcp-servers.json"
    if not mcp_registry.exists():
        content = _render_template("mcp-servers.json.j2", {
            "project_acronym": project,
        })
        if content:
            _write_text(mcp_registry, content)
        else:
            _write_json(mcp_registry, {
                "$schema": "../../../maestro/config/mcp-servers.schema.json",
                "schemaVersion": "1.0",
                "description": f"MCP server allowlist — {project} workspace",
                "servers": [],
            })

    # -- secret-allowlist.json from template ---------------------------------
    # Scaffolds an empty allowlist that the pretool secret scanner reads from
    # .mso/config/. Preserves any existing user-curated allowlist.
    secret_allowlist = mso_dir / "config" / "secret-allowlist.json"
    if not secret_allowlist.exists():
        content = _render_template("secret-allowlist.json.j2", {
            "project": project,
        })
        if content:
            _write_text(secret_allowlist, content)

    # -- .mso/config/gates.json from template --------------------------------
    gates_json = mso_dir / "config" / "gates.json"
    if not gates_json.exists():
        content = _render_template("gates.json.j2", {})
        if content:
            _write_text(gates_json, content)
        else:
            _write_json(gates_json, {
                "$schema": "Maestro — Gate Config",
                "schemaVersion": "1.0",
                "post_nav_review": {
                    "enabled": False,
                    "exempt_priorities": ["LOW"],
                    "auto_approve_after_hours": 0,
                },
            })

    # -- .mso/config/role-models.json (FTR-ADM-2026-0129) --------------------
    # Scaffold a discoverable, EMPTY per-role model override file. An empty
    # `models` map means every role inherits Maestro's built-in defaults
    # (maestro/core_constants.py DEFAULT_ROLE_MODEL_IDS) — so a fresh workspace
    # does NOT freeze the model choices at install time; it keeps picking up
    # default-model improvements (e.g. an Opus minor bump) on package upgrade.
    # Operators add entries to override; see `mso config models`.
    role_models_json = mso_dir / "config" / "role-models.json"
    if not role_models_json.exists():
        _write_json(role_models_json, {
            "$schema": "Maestro — Per-Role Model Overrides",
            "_comment": (
                "Override the Claude model, context window, and reasoning effort per role. "
                "Leave `models` empty to inherit Maestro's built-in defaults (run "
                "`mso config models` to see what's resolved and from where). Canonical "
                "role codes: PLN, BLD, TST, DOC, SEC, REL, LEAD. "
                "Bare-string form (model only): "
                "{\"models\": {\"BLD\": \"claude-opus-4-8\"}}. "
                "Object form (model + context + effort): "
                "{\"models\": {\"PLN\": {\"model\": \"claude-opus-4-8\", "
                "\"contextWindow\": \"1m\", \"effort\": \"xhigh\"}}}. "
                "contextWindow: standard (default) | 1m. "
                "effort: low | medium | high (default) | xhigh. "
                "Resolution order: per-order `model` > this file > "
                "MAESTRO_MODEL_<ROLE> env var > MAESTRO_CONTEXT_<ROLE> env var > "
                "MAESTRO_EFFORT_<ROLE> env var > "
                "role overlay (.mso/config/roles/<CODE>.md) > built-in default."
            ),
            "models": {},
        })

    # -- .mso/claude.md from template ----------------------------------------
    claude_md = mso_dir / "claude.md"
    if not claude_md.exists():
        content = _render_template("claude-adm.md.j2", {
            "project_acronym": project,
        })
        if content:
            _write_text(claude_md, content)
        else:
            _write_text(claude_md, _default_claude_md(project))

    # -- identity defaults ---------------------------------------------------
    _copy_identity_defaults(mso_dir)

    # -- enterprise bootstrap ------------------------------------------------
    if enterprise:
        _bootstrap_enterprise(mso_dir)

    # -- .gitignore ----------------------------------------------------------
    _update_gitignore(base)

    # -- division pack (FTR-MSO-2026-0383) -----------------------------------
    if pack is not None:
        _apply_pack_scaffold(pack, base)

    # -- global registry -----------------------------------------------------
    _register_workspace(project, base)

    # -----------------------------------------------------------------------
    # Summary
    # -----------------------------------------------------------------------
    print(f"\n[Maestro] Workspace scaffolded successfully.")

    if backed_up:
        print(f"\n  Migration summary:")
        if migrated:
            print(f"    Migrated ({len(migrated)} items):")
            for m in migrated:
                print(f"      + {m}")
        if skipped:
            print(f"    Skipped ({len(skipped)} items):")
            for s in skipped:
                print(f"      - {s}")
        print(f"    Legacy dir backed up: .mso.bak/")

    print(f"\n  Next steps:")
    print(f"  1. Update .mso/config/projects/{project}.json with your repo details")
    print(f"  2. Install Maestro pip package if not already done:")
    print(f"       pip install maestro --extra-index-url https://maestrodevs.github.io/simple/")
    print(f"  3. Run: mso dispatch --max-crews 3\n")


# ---------------------------------------------------------------------------
# Division pack scaffolding (FTR-MSO-2026-0383)
# ---------------------------------------------------------------------------

def _apply_pack_scaffold(pack: "object", base: Path) -> None:
    """Layer a division pack onto the freshly scaffolded workspace and report."""
    from maestro.packs import apply_pack

    result = apply_pack(pack, base)
    if not result.changed():
        print(f"[Maestro] Pack '{pack.id}' applied (no changes beyond default init).")
        return
    print(f"[Maestro] Pack '{pack.id}' applied:")
    if result.persona_written:
        print(f"    persona    -> .maestro/config/persona.json ({pack.persona})")
    if result.role_overlays:
        print(f"    role overlays ({len(result.role_overlays)}): {', '.join(result.role_overlays)}")
    if result.order_templates:
        print(f"    order templates ({len(result.order_templates)}): {', '.join(result.order_templates)}")
    if result.gates_written:
        print(f"    gates      -> .mso/config/gates.json")
    if result.workspace_defaults_merged:
        print(f"    workspace defaults merged into .mso/config/workspace.json")
    if result.scaffold_dirs:
        print(f"    extra dirs: {', '.join(result.scaffold_dirs)}")
    if result.requirements_copied:
        print(f"    requirement templates -> .mso/requirements/")
    if result.quickstart_copied:
        print(f"    quickstart -> .mso/QUICKSTART-{pack.id}.md")


# ---------------------------------------------------------------------------
# Enterprise bootstrap
# ---------------------------------------------------------------------------

_ANCHOR_PROVIDERS = {
    "1": ("fs",    "Filesystem (dev/CI — not tamper-proof in production)"),
    "2": ("s3",    "AWS S3 with Object Lock"),
    "3": ("azure", "Azure Blob Storage with Immutability Policy"),
    "4": ("s3-compat", "S3-compatible (MinIO, Wasabi, Cloudflare R2)"),
}


def _bootstrap_enterprise(mso_dir: Path) -> None:
    """Interactive wizard to configure enterprise mode anchor provider in workspace.json."""
    print("\n[Maestro] Enterprise mode setup")
    print("=" * 50)
    print("Enterprise mode requires an external anchor provider for audit log immutability.")
    print("Available providers:")
    for key, (name, desc) in _ANCHOR_PROVIDERS.items():
        print(f"  {key}. {desc}  [{name}]")

    choice = ""
    while choice not in _ANCHOR_PROVIDERS:
        try:
            choice = input("\nSelect anchor provider [1-4] (default: 1 — filesystem): ").strip() or "1"
        except (EOFError, KeyboardInterrupt):
            choice = "1"
            print("1")

    provider_name, provider_desc = _ANCHOR_PROVIDERS[choice]
    print(f"\n[Maestro] Configuring anchor provider: {provider_desc}")

    config_path: str | None = None
    if provider_name != "fs":
        try:
            config_path = input(
                f"Path to {provider_name} anchor config JSON (leave blank to configure manually later): "
            ).strip() or None
        except (EOFError, KeyboardInterrupt):
            config_path = None
            print()

    max_age_raw = ""
    try:
        max_age_raw = input("Anchor SLA — max minutes between anchors [default: 60]: ").strip()
    except (EOFError, KeyboardInterrupt):
        print()
    try:
        max_age = int(max_age_raw) if max_age_raw else 60
    except ValueError:
        max_age = 60

    ws_path = mso_dir / "config" / "workspace.json"
    try:
        ws_data: dict = {}
        if ws_path.exists():
            ws_data = json.loads(ws_path.read_text(encoding="utf-8"))

        ws_data["enterprise"] = True
        audit_cfg: dict = ws_data.get("audit", {})
        audit_cfg["anchorProvider"] = provider_name
        audit_cfg["maxAnchorAgeMinutes"] = max_age
        if config_path:
            audit_cfg["anchorConfig"] = config_path
        ws_data["audit"] = audit_cfg

        ws_path.write_text(json.dumps(ws_data, indent=2) + "\n", encoding="utf-8")
        print(f"\n[Maestro] workspace.json updated:")
        print(f"  enterprise: true")
        print(f"  audit.anchorProvider: {provider_name}")
        print(f"  audit.maxAnchorAgeMinutes: {max_age}")
        if config_path:
            print(f"  audit.anchorConfig: {config_path}")
    except Exception as exc:
        print(f"[Maestro] WARNING: Could not update workspace.json for enterprise mode: {exc}")
        print(f"  Add manually: {{\"enterprise\": true, \"audit\": {{\"anchorProvider\": \"{provider_name}\"}}}}")

    if provider_name == "fs":
        print(
            "\n[Maestro] WARNING: filesystem anchor provider satisfies the mandatory check "
            "for dev/CI but is NOT tamper-proof in production.\n"
            "  Configure an object-lock backend (s3, azure, s3-compat) before going live."
        )

    print(
        f"\n[Maestro] To anchor on a schedule, add to cron or Task Scheduler:\n"
        f"  mso audit anchor --auto\n"
        f"  (See docs/ENTERPRISE-SECURITY.md for setup instructions.)"
    )


# ---------------------------------------------------------------------------
# Global registry
# ---------------------------------------------------------------------------

def _register_workspace(project: str, base: Path) -> None:
    """Register this workspace via the single registry write path
    (maestro.registry — FTR-MSO-2026-0363). Embedded mode: the workspace
    root IS the product repo, recorded explicitly as ``productRepo``.
    """
    register_project(project, base, product_repo=base)
    print(f"[Maestro] Registered {project} in ~/.maestro/projects.json")


# ---------------------------------------------------------------------------
# .gitignore management
# ---------------------------------------------------------------------------

GITIGNORE_BLOCK_START = "# Maestro runtime state (.mso/)"
GITIGNORE_BLOCK_END = "# END Maestro runtime state"

# Canonical Maestro runtime-state block. Single source of truth used by both
# `mso init` and `mso update`. ASCII-only (no em-dashes) so the byte content is
# stable across editors/encodings and string comparisons never drift.
GITIGNORE_ADDITIONS = """\
# Maestro runtime state (.mso/)
.mso/crews/
.mso/state/
.mso/logs/
.mso/bridge/
.mso/temp/
.mso/prompts/active/
.mso/*.pid
.mso/fleet-runner-state.json
.mso/identity/workspace-signing.key
.mso/audit/
.mso/.deprecation-shown-*

# Maestro-managed worktrees (crew/admin/convergence - live git worktrees, not artefact state)
.mso/worktrees/

# Per-voyage worktree dirs (legacy pre-FTR-0364 home; kept so in-flight legacy worktrees stay ignored)
.mso/voyages/active/*/

# Legacy .adm/ runtime patterns - safety net for working trees still on .adm/
# at the v4.0 cutover. Safe to remove once all operators are on post-cutover main.
.adm/crews/
.adm/logs/
.adm/bridge/
.adm/temp/
.adm/prompts/active/
.adm/*.pid
.adm/fleet-runner-state.json
.adm/identity/workspace-signing.key
.adm/audit/
.adm/.deprecation-shown-*
.adm/voyages/active/*/
# END Maestro runtime state
"""

# Matches a Maestro runtime-state block for ANY historical header variant
# (e.g. "(.mso/)" or "(.mso/ canonical from v4.0)") up to the next END marker.
# Non-greedy + DOTALL so each block is matched independently. Used to strip ALL
# occurrences before re-appending exactly one canonical block — this is what
# makes re-running `mso update` idempotent instead of duplicating the block
# (the old find()-based logic mis-sliced when a stale END preceded the START).
_RUNTIME_BLOCK_RE = re.compile(
    r"\n*# Maestro runtime state \(\.mso/[^\n]*\n.*?# END Maestro runtime state\n?",
    re.DOTALL,
)


def ensure_maestro_gitignore_block(content: str) -> str:
    """Return `content` with EXACTLY ONE canonical Maestro runtime block.

    Strips every existing runtime block (all header variants, any count),
    collapses the blank-line runs left behind, then appends the canonical
    block once. Idempotent: ``ensure(ensure(x)) == ensure(x)``. Dedup-safe:
    a file with N stale/duplicate blocks normalises to one.
    """
    stripped = _RUNTIME_BLOCK_RE.sub("\n", content)
    stripped = re.sub(r"\n{3,}", "\n\n", stripped).rstrip("\n")
    if stripped:
        return stripped + "\n\n" + GITIGNORE_ADDITIONS
    return GITIGNORE_ADDITIONS


def _update_gitignore(base: Path) -> None:
    """Add or normalise the .mso/ runtime exclusions in .gitignore (idempotent)."""
    gitignore_path = base / ".gitignore"

    if gitignore_path.exists():
        content = gitignore_path.read_text(encoding="utf-8")
        new_content = ensure_maestro_gitignore_block(content)
        if new_content != content:
            gitignore_path.write_text(new_content, encoding="utf-8")
    else:
        _write_text(gitignore_path, _default_gitignore() + "\n" + GITIGNORE_ADDITIONS)


def _default_gitignore() -> str:
    return """\
# Project directories (separate git repos — not tracked here)
# Add project directory names below:
# my-project/

# Claude Code local settings
.claude/settings.local.json

# Python
__pycache__/
*.pyc

# OS
.DS_Store
Thumbs.db
"""


# ---------------------------------------------------------------------------
# Template rendering
# ---------------------------------------------------------------------------

def _render_template(template_name: str, variables: dict) -> str | None:
    """Render a bundled .j2 template with simple variable substitution."""
    try:
        import importlib.resources as pkg_resources
        ref = pkg_resources.files("maestro") / "templates" / template_name
        content = ref.read_text(encoding="utf-8")
    except (FileNotFoundError, ModuleNotFoundError, TypeError, AttributeError):
        return None

    for key, value in variables.items():
        content = content.replace("{{ " + key + " }}", value)
        content = content.replace("{{" + key + "}}", value)

    return content


def _default_claude_md(project: str) -> str:
    """Fallback .mso/claude.md content if template is unavailable."""
    return f"""\
# Maestro — {project}

## Chain of Command

```
Captain (Human) → Quartermaster (Claude) → Fleet Admiral (mso dispatch) → Crews
```

This project uses Maestro v4.0+ (pip package). No Maestro core code lives here.
Only project artefacts live under `.mso/`.

## Maestro commands

```bash
mso dispatch --max-crews 5
mso status [--once]
mso voyage create "Voyage title" --project {project}
mso usage --summary
```

## Naming Conventions

- Orders: `{{TYPE}}-{project}-{{YEAR}}-{{SEQ}}`
- Voyages: `VOY-{project}-{{YEAR}}-{{SEQ}}`

Always continue from the highest existing sequence number.

## Full Documentation

```bash
mso docs
```
"""


# ---------------------------------------------------------------------------
# Identity defaults
# ---------------------------------------------------------------------------

_DEFAULT_GROUPS = {
    "captain": {"name": "captain", "members": [], "description": "Commander — all capabilities"},
    "fleet_operator": {"name": "fleet_operator", "members": [], "description": "Fleet Operator — fleet, bridge, backup, and audit read"},
    "contributor": {"name": "contributor", "members": [], "description": "Contributor — create orders, view voyages, read audit"},
    "auditor": {"name": "auditor", "members": [], "description": "Auditor — audit read, export, and anchor"},
}

_DEFAULT_ACL = {
    "entries": [
        {"principal": "group:captain",        "capability": "*",               "scope": "*"},
        {"principal": "group:fleet_operator", "capability": "fleet.dispatch",  "scope": "*"},
        {"principal": "group:fleet_operator", "capability": "bridge.start",    "scope": "*"},
        {"principal": "group:fleet_operator", "capability": "bridge.stop",     "scope": "*"},
        {"principal": "group:fleet_operator", "capability": "bridge.view",     "scope": "*"},
        {"principal": "group:fleet_operator", "capability": "backup.create",   "scope": "*"},
        {"principal": "group:fleet_operator", "capability": "backup.restore",  "scope": "*"},
        {"principal": "group:fleet_operator", "capability": "audit.read",      "scope": "*"},
        {"principal": "group:fleet_operator", "capability": "config.view",     "scope": "*"},
        {"principal": "group:contributor",    "capability": "order.create",    "scope": "*"},
        {"principal": "group:contributor",    "capability": "order.view",      "scope": "*"},
        {"principal": "group:contributor",    "capability": "voyage.view",     "scope": "*"},
        {"principal": "group:contributor",    "capability": "fleet.view",      "scope": "*"},
        {"principal": "group:contributor",    "capability": "audit.read",      "scope": "*"},
        {"principal": "group:auditor",        "capability": "audit.read",      "scope": "*"},
        {"principal": "group:auditor",        "capability": "audit.export",    "scope": "*"},
        {"principal": "group:auditor",        "capability": "audit.anchor",    "scope": "*"},
    ]
}


def _copy_identity_defaults(mso_dir: Path) -> None:
    """Seed .mso/identity/ with bundled default groups and access.json."""
    identity_dir = mso_dir / "identity"
    groups_dir = identity_dir / "groups"
    groups_dir.mkdir(parents=True, exist_ok=True)
    (identity_dir / "users").mkdir(parents=True, exist_ok=True)

    for name, data in _DEFAULT_GROUPS.items():
        dst = groups_dir / f"{name}.json"
        if not dst.exists():
            _write_json(dst, data)

    acl_dst = identity_dir / "access.json"
    if not acl_dst.exists():
        _write_json(acl_dst, _DEFAULT_ACL)


# ---------------------------------------------------------------------------
# File helpers
# ---------------------------------------------------------------------------

def _write_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
        f.write("\n")


def _merge_write_json(path: Path, data: dict) -> None:
    """Write JSON, but don't overwrite an existing file."""
    if path.exists():
        return
    _write_json(path, data)


def _write_text(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
