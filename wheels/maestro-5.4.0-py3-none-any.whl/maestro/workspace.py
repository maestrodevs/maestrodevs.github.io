"""maestro.workspace — workspace directory resolution (.mso/ only)."""

from __future__ import annotations

import json
import logging
import os
from pathlib import Path

_log = logging.getLogger(__name__)

# Canonical artefact directory name. Modules that must spell ".mso" in a path
# join or git pathspec import this instead of hand-writing the literal — the
# FTR-MSO-2026-0361 audit tests forbid hand-built ".mso" strings outside this
# module.
MSO_DIR_NAME = ".mso"
_MSO_DIR = MSO_DIR_NAME  # legacy private alias

# Canonical user-global Maestro home directory name (``~/.maestro``). Like
# MSO_DIR_NAME this is the single sanctioned spelling of the ".maestro" home
# literal: EVERY reader/writer of the global plane (registry, licence cache,
# auth cache, user-global persona/config, Hub pid/token) routes through
# :func:`get_maestro_home`, so one env override (``MAESTRO_HOME``) redirects
# them all at once. The BUG-MSO-2026-0387 audit test forbids hand-built
# ``Path.home() / ".maestro"`` joins outside this module — they silently hit the
# operator's real global state (a crew QA walkthrough once clobbered the real
# ~/.maestro/projects.json this way).
MAESTRO_HOME_DIR_NAME = ".maestro"


def get_maestro_home(*, create: bool = False) -> Path:
    """Return the user-global Maestro home directory.

    Resolution order:

    1. ``MAESTRO_HOME`` environment variable (preferred). Tests and QA cold-start
       walkthroughs set this to a scratch dir so they can NEVER clobber the
       operator's real ``~/.maestro`` (BUG-MSO-2026-0387). ``~`` in the value is
       expanded.
    2. ``~/.maestro`` (``Path.home() / ".maestro"``) — the historical default;
       behaviour is unchanged when the env var is unset.

    Pass ``create=True`` to ``mkdir(parents=True, exist_ok=True)`` the directory
    before returning it (writers create; readers do not).
    """
    env_home = os.environ.get("MAESTRO_HOME", "").strip()
    base = (
        Path(env_home).expanduser()
        if env_home
        else Path.home() / MAESTRO_HOME_DIR_NAME
    )
    if create:
        base.mkdir(parents=True, exist_ok=True)
    return base


def maestro_home_file(*parts: str, create_parent: bool = False) -> Path:
    """Return ``get_maestro_home() / *parts`` (a file/subdir under the home).

    Convenience wrapper so callers spell the leaf name only
    (``maestro_home_file("projects.json")``) and never the ``.maestro`` literal.
    ``create_parent=True`` ensures the parent directory exists.
    """
    p = get_maestro_home().joinpath(*parts)
    if create_parent:
        p.parent.mkdir(parents=True, exist_ok=True)
    return p


def find_workspace_dir(start: Path | None = None) -> Path | None:
    """Walk up from *start* (default: cwd) looking for a ``.mso/`` workspace dir.

    Returns the ``.mso/`` directory or ``None`` if not found.
    """
    root = Path(start) if start is not None else Path.cwd()
    for path in [root, *root.parents]:
        mso = path / _MSO_DIR
        if (mso / "config").is_dir():
            return mso
    return None


def get_workspace_dir(start: Path | None = None) -> Path:
    """Return the workspace directory.

    Resolution order:
    1. ``MAESTRO_DIR`` environment variable (preferred)
    2. Walk up from *start* (default: cwd) looking for ``.mso/config``

    Raises :class:`FileNotFoundError` if no workspace is found.
    """
    env_dir = os.environ.get("MAESTRO_DIR")
    if env_dir:
        return Path(env_dir).resolve()

    root = Path(start) if start is not None else Path.cwd()
    for path in [root, *root.parents]:
        mso = path / _MSO_DIR
        if (mso / "config").is_dir():
            return mso

    raise FileNotFoundError(
        "No Maestro workspace found in the current directory or any parent. "
        "Run `mso init --project <PRJ>` to create one."
    )


# Legacy alias kept for callers that imported from here before the rename.
_find_mso_dir = find_workspace_dir


def resolve_artefact_dir(workspace: Path) -> Path:
    """Return the canonical workspace artefact dir under *workspace*.

    Returns the ``.mso/`` path (creating it via `.mkdir()` at the call site
    if needed).
    """
    mso = workspace / _MSO_DIR
    if mso.is_dir():
        return mso
    return mso


# ---------------------------------------------------------------------------
# Artefact-mode resolution (FTR-MSO-2026-0366 — Phase 2 solo mode)
# ---------------------------------------------------------------------------

# Valid artefacts.mode values (mirrors maestro.registry.ARTEFACT_MODES).
# Absence of the block — or any unrecognised value — means "embedded".
ARTEFACT_MODES = ("embedded", "solo", "shared")

# Parsed workspace.json cache keyed by workspace dir, invalidated by mtime.
# get_artefact_root() is called on every artefact path build (hot dispatcher
# loops), so the config read must be stat-cheap in steady state.
_WORKSPACE_CONFIG_CACHE: dict[Path, tuple[int, dict]] = {}


def clear_workspace_config_cache() -> None:
    """Drop the parsed workspace.json cache (test isolation helper)."""
    _WORKSPACE_CONFIG_CACHE.clear()


def _workspace_config(workspace: Path) -> dict:
    """Parsed ``<workspace>/config/workspace.json`` (mtime-cached, fail-open {})."""
    cfg_file = workspace / "config" / "workspace.json"
    try:
        mtime = cfg_file.stat().st_mtime_ns
    except OSError:
        return {}
    cached = _WORKSPACE_CONFIG_CACHE.get(workspace)
    if cached is not None and cached[0] == mtime:
        return cached[1]
    try:
        cfg = json.loads(cfg_file.read_text(encoding="utf-8"))
        if not isinstance(cfg, dict):
            cfg = {}
    except Exception:
        cfg = {}
    _WORKSPACE_CONFIG_CACHE[workspace] = (mtime, cfg)
    return cfg


def _artefacts_block(workspace: Path) -> dict:
    """The ``artefacts`` block of *workspace*'s workspace.json ({} if absent)."""
    block = _workspace_config(workspace).get("artefacts")
    return block if isinstance(block, dict) else {}


def _workspace_project_acronym(workspace: Path) -> str | None:
    """Best-effort project acronym for registry lookups: workspace.json
    ``project`` (single-project scaffold), else projects.json ``defaultProject``."""
    acronym = _workspace_config(workspace).get("project")
    if isinstance(acronym, str) and acronym.strip():
        return acronym.strip()
    try:
        projects = json.loads(
            (workspace / "config" / "projects.json").read_text(encoding="utf-8"))
        acronym = projects.get("defaultProject")
        if isinstance(acronym, str) and acronym.strip():
            return acronym.strip()
    except Exception:
        pass
    return None


def _registry_entry_for(workspace: Path, block: dict) -> dict | None:
    """Normalised registry v2 entry for this workspace's project, or None."""
    acronym = block.get("project") or _workspace_project_acronym(workspace)
    if not acronym:
        return None
    try:
        from maestro import registry
        return registry.get_project_entry(acronym)
    except Exception:
        return None


def _redirected_artefact_root(ws: Path, block: dict) -> Path | None:
    """Resolve the artefact repo's ``.mso`` for a solo/shared *ws*, or None.

    Order: workspace.json ``artefacts.root`` (the committed mirror), then the
    registry v2 ``artefactRoot``. A candidate must be a real workspace
    (``<root>/.mso/config`` exists) to win; when the candidate IS *ws* we are
    already standing in the artefact repo and no redirect is needed.
    """
    root = block.get("root")
    if isinstance(root, str) and root.strip():
        candidate = (Path(root).expanduser().resolve() / MSO_DIR_NAME)
        if (candidate / "config").is_dir():
            return None if candidate == ws else candidate
    entry = _registry_entry_for(ws, block)
    if entry and entry.get("artefactRoot"):
        candidate = Path(entry["artefactRoot"]).resolve() / MSO_DIR_NAME
        if (candidate / "config").is_dir() and candidate != ws:
            return candidate
    return None


def get_artefact_mode(start: Path | None = None) -> str:
    """Return the workspace's artefact mode: ``embedded`` | ``solo`` | ``shared``.

    Reads the ``artefacts.mode`` key of the resolved workspace's
    workspace.json (FTR-MSO-2026-0366). The block being absent, unreadable,
    or carrying an unrecognised value all mean ``embedded`` — full
    back-compat by construction. No workspace resolvable → ``embedded``.
    """
    try:
        ws = get_workspace_dir(start)
    except FileNotFoundError:
        return "embedded"
    mode = _artefacts_block(ws).get("mode")
    return mode if mode in ("solo", "shared") else "embedded"


def get_artefact_root(start: Path | None = None) -> Path:
    """Return the artefact root — the ``.mso/`` directory holding all durable
    Maestro artefacts (queues, orders, voyages, plans, handoffs, reports,
    usage, config) and the gitignored runtime plane (crews, logs, state, temp).

    **Embedded mode (default — ``artefacts`` block absent):** identical to
    :func:`get_workspace_dir` — ``MAESTRO_DIR`` if set, else the ``.mso/``
    found by walking up from *start*/cwd. Zero behaviour change.

    **Solo/shared mode (FTR-MSO-2026-0366, plan §3.6):** when the resolved
    workspace's ``artefacts.mode`` is ``solo``/``shared``, this resolver —
    and only this resolver — retargets to ``<artefact-repo>/.mso``. The
    redirect source is the workspace.json ``artefacts.root`` mirror, falling
    back to the registry v2 ``artefactRoot``; a workspace already standing in
    the artefact repo resolves to itself. Callers MUST use this for artefact
    paths (anything under ``.mso/``) and :func:`get_product_repo` for
    product-repo paths; the two stop being related once artefacts leave the
    product repo.
    """
    ws = get_workspace_dir(start)
    block = _artefacts_block(ws)
    if block.get("mode") in ("solo", "shared"):
        redirected = _redirected_artefact_root(ws, block)
        if redirected is not None:
            return redirected
    return ws


def get_product_repo(target_repo: str | None = None,
                     start: Path | None = None) -> Path:
    """Return the product repository root — the git repo whose source code
    crews build, branch, and converge.

    **Embedded mode (default):** the parent of the ``.mso/`` workspace dir
    (``.mso`` is embedded in the product repo), so *target_repo* is accepted
    but unused. Zero behaviour change.

    **Solo/shared mode (FTR-MSO-2026-0366):** the ``.mso`` parent is the
    ARTEFACT repo, so the product repo must be configured. Resolution order:
    the workspace.json ``artefacts`` mirror (``repos[target_repo].path`` /
    ``productRepo`` / single-entry ``repos`` map), then the registry v2 entry
    (``repos`` map / ``productRepo``). When resolution is standing in a
    product-side pointer stub (walk-up ``.mso`` != artefact root), the stub's
    parent is the product repo. Anything else raises FileNotFoundError with
    remediation guidance — silently treating the artefact repo as the product
    repo would let the dispatcher branch/converge the artefact repo, which is
    exactly what solo mode exists to prevent.

    **Phase 4 (plan §4):** *target_repo* resolves through the full ``repos``
    map to a per-repo managed checkout. Callers MUST use this (not
    ``get_workspace_dir().parent``) for any path or ``cwd`` that means "the
    product repo".
    """
    ws = get_workspace_dir(start)
    block = _artefacts_block(ws)
    if block.get("mode") not in ("solo", "shared"):
        return ws.parent

    art = get_artefact_root(start)
    # In solo mode the authoritative mirror lives in the ARTEFACT workspace's
    # config; a product-side stub may carry only {mode, root}.
    art_block = _artefacts_block(art) or block
    entry = _registry_entry_for(art, art_block) or _registry_entry_for(ws, block)

    def _repo_path_from(repos: object, name: str | None) -> Path | None:
        if not isinstance(repos, dict) or not repos:
            return None
        if name is not None:
            item = repos.get(name)
        elif len(repos) == 1:
            item = next(iter(repos.values()))
        else:
            return None
        if isinstance(item, dict) and isinstance(item.get("path"), str):
            return Path(item["path"]).resolve()
        return None

    for candidate in (
        _repo_path_from(art_block.get("repos"), target_repo),
        _repo_path_from((entry or {}).get("repos"), target_repo),
        Path(art_block["productRepo"]).resolve()
            if isinstance(art_block.get("productRepo"), str) and art_block["productRepo"].strip()
            else None,
        Path(entry["productRepo"]).resolve()
            if entry and isinstance(entry.get("productRepo"), str)
            and Path(entry["productRepo"]).resolve() != art.parent.resolve()
            else None,
        _repo_path_from(art_block.get("repos"), None),
        _repo_path_from((entry or {}).get("repos"), None),
    ):
        if candidate is not None and candidate.is_dir():
            return candidate

    if ws != art:
        # Standing in a product-side pointer stub: its parent IS the product repo.
        return ws.parent

    raise FileNotFoundError(
        f"Artefact mode is '{block.get('mode')}' but no product repo is "
        f"configured for target_repo={target_repo!r}. Set "
        f"'artefacts.productRepo' (or a 'repos' map entry) in "
        f"{art / 'config' / 'workspace.json'}, or register the project with "
        f"`productRepo`/`repos` in the global registry (~/.maestro/projects.json)."
    )


def get_repos_map(start: Path | None = None) -> dict:
    """Return the workspace's ``repos`` map (plan §4.2 / FTR-MSO-2026-0377).

    A multi-repo workspace maps 1..N product repos: ``{repoName: {path, slug?,
    defaultBranch?, cloneProtocol?, buildCommand?, testCommand?}}``. Resolution
    prefers the workspace.json ``artefacts.repos`` mirror (the committed,
    machine-independent source), falling back to the registry v2 entry's
    ``repos`` map. An empty/absent map means "single-repo workspace" — callers
    MUST treat that as the embedded default (zero behaviour change).

    Pure read, fail-open ``{}``: no workspace, unreadable config, or a malformed
    ``repos`` value all yield ``{}`` so single-repo/embedded dispatch is never
    perturbed by a config problem.
    """
    try:
        ws = get_workspace_dir(start)
    except FileNotFoundError:
        return {}
    block = _artefacts_block(ws)
    repos = block.get("repos")
    if isinstance(repos, dict) and repos:
        return repos
    entry = _registry_entry_for(ws, block)
    if entry:
        repos = entry.get("repos")
        if isinstance(repos, dict) and repos:
            return repos
    return {}


# ---------------------------------------------------------------------------
# Registry-entry resolution (FTR-MSO-2026-0369 — Hub Phase 2d)
# ---------------------------------------------------------------------------
#
# get_artefact_root()/get_product_repo() above resolve relative to a single
# *process-wide* workspace: they honour MAESTRO_DIR and walk up from cwd/start.
# That is wrong for the Hub, which polls MANY registered workspaces from one
# long-lived process — a stray MAESTRO_DIR in the Hub's own environment must
# never leak into every workspace's resolution. The two helpers below are pure
# functions of a single ``maestro.registry`` v2 entry dict: no env vars, no cwd,
# no filesystem walk-up. Hub code (server.py/poller.py/aggregator.py) MUST use
# these instead of reading ``entry["path"]`` directly once ``artefactMode`` may
# be ``solo``/``shared``.

def artefact_parent_for_entry(entry: dict) -> Path:
    """Return the directory whose child is ``.mso`` for a registry v2 entry.

    Embedded (default — ``artefactMode`` absent/not solo|shared, or
    ``artefactRoot`` absent): ``entry['path']`` — byte-identical to pre-Phase-2
    behaviour (``resolve_artefact_dir(artefact_parent_for_entry(entry))`` ==
    today's ``resolve_artefact_dir(Path(entry['path']))``).

    Solo/shared: ``entry['artefactRoot']`` — the dedicated artefact repo that
    holds the durable ``.mso/`` plane (plan §3.6 / FTR-MSO-2026-0366).
    """
    mode = entry.get("artefactMode")
    root = entry.get("artefactRoot")
    if mode in ("solo", "shared") and isinstance(root, str) and root.strip():
        return Path(root).expanduser().resolve()
    return Path(entry["path"]).expanduser().resolve()


def product_repo_for_entry(entry: dict) -> Path:
    """Return the product-repo checkout for a registry v2 entry (Hub-safe).

    ``entry['productRepo']`` when present, else ``entry['path']`` — mirrors
    :func:`maestro.registry.migrate_entry`'s default (v1/embedded: the product
    repo IS the workspace path). This is the directory dispatch/stop subprocess
    invocations must run in — never the artefact root in solo/shared mode.
    """
    repo = entry.get("productRepo")
    if isinstance(repo, str) and repo.strip():
        return Path(repo).expanduser().resolve()
    return Path(entry["path"]).expanduser().resolve()
