"""maestro.packs.validate — full-content validation for division packs.

`mso packs validate` (FTR-MSO-2026-0384) checks a pack's *entire* asset set,
not just the ``pack.json`` manifest that :func:`maestro.packs.loader.load_pack_from_dir`
already schema-validates on load. Role overlay files are validated through the
exact SAME function ``mso roles validate`` uses (``maestro.roles.loader.parse_role_file``)
so the two commands can never drift apart (PLAN-PLN-MSO-2026-0371 section 5.4) —
this module adds no forked copy of that logic.

Validation walks the pack directory directly (rather than only trusting the
loaded ``Pack`` object) so that a broken manifest does not prevent every other
defect in the pack from being reported in the same run — the multi-error,
CI-friendly contract ``mso roles validate`` already established.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional

from maestro.roles.loader import (
    CANONICAL_ROLE_CODES,
    LEGACY_ALIASES,
    RoleFileValidationError,
    parse_role_file,
)

from .loader import Pack, PackSchemaError, load_pack_from_dir

_BUILTIN_DIR = Path(__file__).parent
_VALID_ROLE_CODES = set(CANONICAL_ROLE_CODES) | set(LEGACY_ALIASES.keys())


def builtin_pack_root(name: str) -> Path:
    """Return the on-disk root of the built-in pack *name* (may not exist)."""
    return _BUILTIN_DIR / name


def _validate_order_template(path: Path) -> List[str]:
    """Required fields per PLAN-PLN-MSO-2026-0371 5.4: orderType, roleSequence, description."""
    try:
        data: Any = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        return [f"Malformed JSON: {exc}"]
    if not isinstance(data, dict):
        return ["Order template must be a JSON object"]

    diags: List[str] = []
    meta = data.get("_meta")
    if not isinstance(meta, dict):
        diags.append("Missing required '_meta' object")
        meta = {}

    order_type = meta.get("orderType")
    if not order_type or not isinstance(order_type, str):
        diags.append("Missing required '_meta.orderType' (non-empty string)")

    sequence = meta.get("roleSequence")
    if not sequence or not isinstance(sequence, list):
        diags.append("Missing required '_meta.roleSequence' (non-empty array)")
    else:
        for code in sequence:
            if code not in _VALID_ROLE_CODES:
                diags.append(
                    f"'_meta.roleSequence' contains unknown role code '{code}' "
                    f"(expected one of {sorted(_VALID_ROLE_CODES)})"
                )

    description = data.get("description")
    if not description or not isinstance(description, str):
        diags.append("Missing required 'description' (non-empty string placeholder/template)")

    return diags


def _validate_gates_file(path: Path) -> List[str]:
    try:
        data: Any = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        return [f"Malformed JSON: {exc}"]
    if not isinstance(data, dict):
        return ["gates.json must be a JSON object"]

    diags: List[str] = []
    for gate_name, gate_cfg in data.items():
        # Metadata keys are not gates: the real workspace gates.json carries
        # "$schema", "schemaVersion" and "_notes" headers (see
        # .mso/config/gates.json) — skip anything $-prefixed, _-prefixed, or
        # the schemaVersion marker. (PVT 2026-07-17 finding on the sdlc pack.)
        if gate_name.startswith(("$", "_")) or gate_name == "schemaVersion":
            continue
        if not isinstance(gate_cfg, dict):
            diags.append(f"Gate '{gate_name}' must be a JSON object")
            continue
        if "enabled" in gate_cfg and not isinstance(gate_cfg["enabled"], bool):
            diags.append(f"Gate '{gate_name}.enabled' must be a boolean")
    return diags


def _validate_workspace_defaults_file(path: Path) -> List[str]:
    try:
        data: Any = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        return [f"Malformed JSON: {exc}"]
    if not isinstance(data, dict):
        return ["workspace-defaults.json must be a JSON object"]
    return []


def _persona_reference_diagnostics(pack: Pack) -> List[str]:
    """Flag a manifest ``persona`` id that resolves to nothing.

    A pack may either ship its own ``persona.json`` (validated separately
    against the persona schema) or point ``persona`` at a built-in persona
    id. If it does neither, `mso init --pack` would silently fall through —
    catch that here as the "missing persona" defect class.
    """
    if pack.persona_file.exists():
        return []
    if pack.persona and pack.persona != "default":
        from maestro.personas.loader import builtin_names as persona_builtin_names

        available = persona_builtin_names()
        if pack.persona not in available:
            return [
                f"persona '{pack.persona}' not found: no persona.json shipped by this "
                f"pack and '{pack.persona}' is not a built-in persona "
                f"(available: {', '.join(available)})"
            ]
    return []


def validate_pack_dir(path: Path) -> Dict[str, List[str]]:
    """Validate every asset of the pack rooted at *path*.

    Returns ``{file_path: [diagnostics]}`` — an empty list means that file is
    valid. Mirrors ``maestro.roles.loader.validate_all``'s return shape so
    ``mso packs validate`` gets the same multi-error, exit-0/1 CI contract as
    ``mso roles validate``. Every asset is checked independently — a broken
    manifest does not stop the rest of the pack from being reported.
    """
    path = Path(path)
    results: Dict[str, List[str]] = {}

    manifest_path = path / "pack.json"
    pack: Optional[Pack] = None
    try:
        pack = load_pack_from_dir(path)
        results[str(manifest_path)] = []
    except PackSchemaError as exc:
        results[str(manifest_path)] = [str(exc)]

    if pack is not None:
        results[str(manifest_path)].extend(_persona_reference_diagnostics(pack))

    roles_dir = path / "roles"
    if roles_dir.is_dir():
        for md_file in sorted(roles_dir.glob("*.md")):
            try:
                parse_role_file(md_file, is_core=False, strict=True)
                results[str(md_file)] = []
            except RoleFileValidationError as exc:
                results[str(md_file)] = exc.diagnostics

    persona_file = path / "persona.json"
    if persona_file.exists():
        from maestro.personas.loader import load_persona_from_file
        from maestro.personas.models import PersonaSchemaError

        try:
            load_persona_from_file(persona_file)
            results[str(persona_file)] = []
        except PersonaSchemaError as exc:
            results[str(persona_file)] = [str(exc)]

    order_templates_dir = path / "order-templates"
    if order_templates_dir.is_dir():
        for tpl_file in sorted(order_templates_dir.glob("*-template.json")):
            results[str(tpl_file)] = _validate_order_template(tpl_file)

    gates_file = path / "gates.json"
    if gates_file.exists():
        results[str(gates_file)] = _validate_gates_file(gates_file)

    workspace_defaults_file = path / "workspace-defaults.json"
    if workspace_defaults_file.exists():
        results[str(workspace_defaults_file)] = _validate_workspace_defaults_file(
            workspace_defaults_file
        )

    return results


def validate_all_packs() -> Dict[str, Dict[str, List[str]]]:
    """Validate every built-in pack (including invalid ones — unlike ``load_all_builtin``).

    Returns ``{pack_id: {file_path: [diagnostics]}}``.
    """
    from .loader import builtin_names

    return {name: validate_pack_dir(builtin_pack_root(name)) for name in builtin_names()}
