# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Hub aggregator — path-parameterised workspace state reader.

Pure read functions: no globals, no get_workspace_dir(). Designed for
the WorkspacePoller which calls these on arbitrary registered workspace roots.
"""

from __future__ import annotations

import json
import os
import subprocess
import time
from pathlib import Path
from typing import Optional

from maestro.hub.models import (
    ClaimedBy,
    CompletionConfig,
    CrewState,
    IdleWatchdogConfig,
    IterationUsage,
    ModelUsage,
    OnVoyageCompleteConfig,
    Order,
    OrderUsageDetail,
    Repo,
    UsageBucket,
    UsagePoint,
    UsageRollup,
    UsageSeriesPoint,
    Voyage,
    VoyageOrderRollup,
    VoyagePrEntry,
    WorkspaceConfig,
    WorkspaceDetail,
    WorkspaceSummary,
    WorkspaceUsage,
)


# Crew display codenames by slot (data contract — frontend mock pins these).
# Falls back to the persona squad name (then "Crew<slot>") for slots beyond 5.
CREW_CODENAMES = {1: "Lion", 2: "Leopard", 3: "Cheetah", 4: "Hyena", 5: "Wild Dog"}


def _crew_name(slot: int) -> str:
    name = CREW_CODENAMES.get(slot)
    if name:
        return name
    try:
        from maestro import core_constants
        return core_constants.get_squad_name(slot) or f"Crew{slot}"
    except Exception:
        return f"Crew{slot}"


# Map raw order priority strings (HIGH/MEDIUM/LOW/etc) to the contract enum.
def _norm_priority(raw) -> Optional[str]:
    if not raw:
        return None
    p = str(raw).strip().lower()
    if p in ("high", "urgent", "critical"):
        return "high"
    if p in ("low",):
        return "low"
    if p in ("normal", "medium", "med", "default"):
        return "normal"
    return "normal"


# ---------------------------------------------------------------------------
# Low-level helpers (mirrored from fleet_monitor, parameterised by path)
# ---------------------------------------------------------------------------

def _load_json_safe(path: Path) -> Optional[dict]:
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


# ---------------------------------------------------------------------------
# BUG-MSO-2026-0360: PR-link fallback (backfill tolerance)
# ---------------------------------------------------------------------------
# Historical voyage manifests predate the dispatcher writing prNumber/prUrl at
# PR-creation time, so the Final Review bucket rendered without its PR link.
# When an ACTIVE voyage in final_review lacks prUrl, look the open PR up via
# gh — cached per (workspace, branch) with a TTL for hits AND misses, and
# offline-safe: any failure degrades to None (negative-cached) so the
# dashboard render is never blocked repeatedly. This is the one sanctioned
# non-filesystem read in this module.

_PR_FALLBACK_TTL_SECONDS = 600.0
_PR_FALLBACK_CACHE: dict[tuple[str, str], tuple[float, Optional[str]]] = {}
_PR_FALLBACK_GH_MISSING = False


def _pr_url_fallback(mso: Path, branch: str, product_repo: Optional[Path] = None) -> Optional[str]:
    """Open-PR URL for *branch* via gh, cached; None on any failure/offline.

    ``gh`` must run with cwd inside the PRODUCT repo checkout (that's where the
    git remote/branch actually live) — in solo/shared artefact mode ``mso`` is
    the artefact repo and NOT a valid git-remote-bearing checkout for this
    branch (FTR-MSO-2026-0369). *product_repo* defaults to ``mso.parent``
    (embedded mode: byte-identical to the pre-0369 behaviour).
    """
    global _PR_FALLBACK_GH_MISSING
    branch = (branch or "").replace("refs/heads/", "")
    if _PR_FALLBACK_GH_MISSING or not branch:
        return None
    key = (str(mso), branch)
    now = time.time()
    hit = _PR_FALLBACK_CACHE.get(key)
    if hit is not None and (now - hit[0]) < _PR_FALLBACK_TTL_SECONDS:
        return hit[1]
    url: Optional[str] = None
    try:
        r = subprocess.run(
            ["gh", "pr", "list", "--head", branch,
             "--state", "open", "--json", "number,url"],
            capture_output=True, text=True, timeout=5,
            cwd=str(product_repo or mso.parent))
        if r.returncode == 0 and r.stdout.strip() not in ("", "[]"):
            prs = json.loads(r.stdout)
            if prs:
                url = prs[0].get("url") or None
    except FileNotFoundError:
        _PR_FALLBACK_GH_MISSING = True  # gh not installed — stop trying
    except Exception:
        url = None
    _PR_FALLBACK_CACHE[key] = (now, url)
    return url


def _is_process_alive(pid: int) -> bool:
    if not pid or pid <= 0:
        return False
    try:
        if os.name == "nt":
            import ctypes
            PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            STILL_ACTIVE = 259
            kernel32 = ctypes.windll.kernel32
            handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
            if handle == 0:
                return False
            try:
                exit_code = ctypes.c_ulong()
                if kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code)):
                    return exit_code.value == STILL_ACTIVE
                return False
            finally:
                kernel32.CloseHandle(handle)
        else:
            os.kill(pid, 0)
            return True
    except (ProcessLookupError, PermissionError, OSError):
        return False


# ---------------------------------------------------------------------------
# Workspace state readers (summary-level — Phase 1)
# ---------------------------------------------------------------------------

def _get_mso_dir(ws_root: Path) -> Path:
    from maestro.workspace import resolve_artefact_dir
    return resolve_artefact_dir(ws_root)


# Dispatcher heartbeat staleness ceiling (seconds). The dispatcher rewrites
# fleet-runner-state.json every tick (~every 2 min), so a heartbeat within ~3x
# that interval means "alive". Unlike a host PID, an mtime crosses the container
# PID-namespace boundary, which is what makes the containerized Hub reliable
# (BUG-MSO-2026-0405).
_HEARTBEAT_STALENESS_SECONDS = 360


def _mtime_age_seconds(path: Path) -> Optional[float]:
    """Age in seconds of *path*'s mtime, or None if it can't be stat-ed."""
    try:
        return max(0.0, time.time() - path.stat().st_mtime)
    except Exception:
        return None


def _dispatcher_heartbeat_fresh(
    mso: Path, threshold: float = _HEARTBEAT_STALENESS_SECONDS
) -> bool:
    """True when a dispatcher heartbeat file was rewritten within *threshold*.

    The dispatcher rewrites ``.mso/fleet-runner-state.json`` on every tick; its
    mtime is visible across the container PID-namespace boundary where the host
    PID is not, so a fresh heartbeat proves a live host dispatcher even when its
    PID is invisible in-container. ``logs/lifecycle.log`` is a secondary
    corroborating signal. Note: ``dispatcher.pid`` mtime is NOT usable — it is
    written once at startup and goes stale while the dispatcher runs.
    """
    for name in ("fleet-runner-state.json", "logs/lifecycle.log"):
        age = _mtime_age_seconds(mso / name)
        if age is not None and age <= threshold:
            return True
    return False


def _dispatcher_running(mso: Path) -> bool:
    """Whether a dispatcher is live for this workspace (container-safe).

    The Hub backend frequently runs in Docker, where ``.mso/dispatcher.pid``
    holds a HOST pid that is invisible inside the container's PID namespace — so
    a pid-liveness check alone false-negatives and hides the whole workspace in
    the UI (BUG-MSO-2026-0405). We treat the dispatcher as running when
    ``dispatcher.pid`` exists AND EITHER:

      (a) the pid is alive — the reliable path on a native-host Hub, OR
      (b) a fresh dispatcher heartbeat exists — the container-safe fallback.

    A genuinely stopped dispatcher (stale/dead pid AND stale heartbeat) reads
    False.
    """
    pid_file = mso / "dispatcher.pid"
    if not pid_file.exists():
        return False
    try:
        pid = int(pid_file.read_text(encoding="utf-8").strip())
    except Exception:
        pid = 0
    if pid and _is_process_alive(pid):
        return True
    return _dispatcher_heartbeat_fresh(mso)


def _count_active_voyages(mso: Path) -> int:
    voyages_dir = mso / "voyages" / "active"
    if not voyages_dir.exists():
        return 0
    count = 0
    for f in voyages_dir.glob("*.json"):
        data = _load_json_safe(f)
        if data and (data.get("status") or "").upper() not in ("AWAITING_APPROVAL", "COMPLETE"):
            count += 1
    return count


def _count_pending_orders(mso: Path) -> int:
    orders_dir = mso / "queues" / "orders"
    if not orders_dir.exists():
        return 0
    count = 0
    for f in orders_dir.glob("*.json"):
        data = _load_json_safe(f)
        if data:
            if data.get("status", "PENDING") == "PENDING":
                count += 1
        else:
            count += 1  # unreadable → treat as pending (mirrors fleet_monitor)
    return count


def _count_active_crews(mso: Path, max_crews: int = 5) -> int:
    count = 0
    for i in range(1, max_crews + 1):
        state = _load_json_safe(mso / "crews" / f"crew{i}" / "state.json")
        if state:
            status = (state.get("status") or "").upper()
            if status in ("RUNNING", "ACTIVE"):
                count += 1
    return count


def _count_review_pending(mso: Path) -> int:
    review_dir = mso / "queues" / "review"
    if not review_dir.exists():
        return 0
    return len(list(review_dir.glob("*.json")))


def _get_max_crews(mso: Path) -> int:
    settings = _load_json_safe(mso / "config" / "fleet-settings.json") or {}
    return int(settings.get("maxCrews", 5))


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def read_workspace_snapshot(ws_root: Path, id: str) -> WorkspaceSummary:
    """Read a summary-level snapshot of one registered workspace.

    Phase 1: returns WorkspaceSummary (counts only).
    Phase 2 will return full WorkspaceDetail.
    """
    mso = _get_mso_dir(ws_root)
    if not mso.is_dir():
        return offline_summary(id, str(ws_root))

    max_crews = _get_max_crews(mso)
    review_pending = _count_review_pending(mso)
    return WorkspaceSummary(
        id=id,
        name=id,
        path=str(ws_root),
        online=True,
        dispatcher_running=_dispatcher_running(mso),
        active_voyage_count=_count_active_voyages(mso),
        pending_order_count=_count_pending_orders(mso),
        active_crew_count=_count_active_crews(mso, max_crews),
        review_pending_count=review_pending,
        pending_review_count=review_pending,
    )


def offline_summary(acronym: str, path: str) -> WorkspaceSummary:
    """Return a WorkspaceSummary for an unreadable or missing workspace."""
    return WorkspaceSummary(
        id=acronym,
        name=acronym,
        path=path,
        online=False,
    )


# ---------------------------------------------------------------------------
# Phase 2 helpers — detail-level readers (contract-aligned)
# ---------------------------------------------------------------------------

# Maestro's on-disk order vocabulary is richer than the Hub's OrderStatus
# contract (app/types/index.ts). Map the extra statuses onto the contract set so
# the frontend renders them — without this, e.g. a running order (IN_PROGRESS)
# matched none of the frontend's RUNNING/PENDING filters and vanished from view.
_ORDER_STATUS_MAP = {
    "IN_PROGRESS": "RUNNING",
    "CLAIMED": "RUNNING",
    "DISPATCHED": "RUNNING",
    "COMPLETE_PENDING_STAGING": "COMPLETE",
    "COMPLETE_WITH_CONDITIONS": "COMPLETE",
    "RELEASE_APPROVED": "COMPLETE",
    "COMPLETED": "COMPLETE",
    "REQUEUE": "PENDING",
    "REOPENED": "PENDING",
}


def _norm_order_status(raw: Optional[str]) -> str:
    """Normalise a raw .mso order status onto the frontend OrderStatus contract."""
    s = (raw or "PENDING").strip()
    return _ORDER_STATUS_MAP.get(s.upper(), s)


def _derive_voyage_status(stored: Optional[str], member_orders: list) -> str:
    """Reflect live member-order state in the voyage status.

    The on-disk voyage `status` is often stale — e.g. PSG voyages stay at PLANNED
    after a crew starts work, so the dashboard showed an in-flight voyage as
    PLANNED even with a RUNNING order. When the stored status isn't terminal,
    surface ACTIVE if any member order is running. Completion stays owned by the
    dispatcher's gating — we never force COMPLETE here.
    """
    s = (stored or "").upper()
    if s in ("COMPLETE", "IN_REVIEW"):
        return s
    statuses = [(o.status or "").upper() for o in member_orders]
    # All members done → leave completion to the stored status / archival gating.
    if statuses and all(st == "COMPLETE" for st in statuses):
        return s or "PLANNED"
    # PLANNED means "not started". A voyage is started — and therefore ACTIVE —
    # once any member order has moved past the queue (running, complete, stalled,
    # etc.), not only while one is literally RUNNING (order files churn fast).
    not_started = {"", "PENDING", "BACKLOG", "PROPOSED", "NAV_REVIEW_PENDING"}
    started = any(st not in not_started for st in statuses)
    if started:
        return "ACTIVE"
    return s or "PLANNED"


def _apply_running_crew_voyage_status(voyages: list, crews: list) -> None:
    """Mark a voyage ACTIVE in-place when a running crew is on one of its orders.

    The crew state is the authoritative live signal: on a busy fleet the order
    files churn (IN_PROGRESS -> COMPLETE per role-phase while the crew advances)
    and the voyage JSON's stored status is often stale at PLANNED. Terminal
    statuses (COMPLETE / IN_REVIEW) are never downgraded.
    """
    running_ids = {
        c.current_order_id
        for c in crews
        if (getattr(c, "status", "") or "").upper() == "RUNNING" and c.current_order_id
    }
    if not running_ids:
        return
    for v in voyages:
        if (v.status or "").upper() in ("COMPLETE", "IN_REVIEW"):
            continue
        member_ids = {o.id for o in (v.orders or []) if o.id}
        if member_ids & running_ids:
            v.status = "ACTIVE"


def _map_order(data: dict, workspace_id: str) -> Order:
    """Map a raw .mso order JSON (camelCase) → contract Order (snake_case)."""
    oid = data.get("orderId") or data.get("id") or ""
    role = data.get("role") or data.get("targetRole") or ""
    target_role = data.get("targetRole")
    depends_on = data.get("dependsOn")
    if isinstance(depends_on, list):
        depends_on = [str(d) for d in depends_on] or None
    else:
        depends_on = None
    timeout = data.get("timeoutMinutes")
    iteration = data.get("iteration")
    max_iterations = data.get("maxIterations") or data.get("maxIters")
    # FTR-MSO-2026-0376: shared-mode claim-by-commit stamp (FTR-0374's
    # `_stamp_claim`). Absent in embedded/solo mode or an unclaimed order.
    raw_claimed_by = data.get("claimedBy")
    claimed_by = ClaimedBy(**raw_claimed_by) if isinstance(raw_claimed_by, dict) else None
    claimed_at = data.get("claimedAt")
    claimed_at = claimed_at if isinstance(claimed_at, str) else None
    return Order(
        id=oid,
        title=data.get("title", "") or "",
        description=data.get("description"),
        status=_norm_order_status(data.get("status")),
        role=role,
        target_role=target_role,
        voyage_id=data.get("voyageId"),
        workspace_id=workspace_id,
        priority=_norm_priority(data.get("priority")),
        created_at=data.get("createdAt", "") or "",
        updated_at=data.get("updatedAt"),
        started_at=data.get("startedAt"),
        completed_at=data.get("completedAt"),
        depends_on=depends_on,
        role_sequence=data.get("roleSequence", []) or [],
        timeout_minutes=int(timeout) if isinstance(timeout, (int, float)) else None,
        iteration=int(iteration) if isinstance(iteration, (int, float)) else None,
        max_iterations=int(max_iterations) if isinstance(max_iterations, (int, float)) else None,
        target_repo=data.get("targetRepo"),
        claimedBy=claimed_by,
        claimedAt=claimed_at,
    )


def _build_order_index(mso: Path, workspace_id: str) -> dict[str, Order]:
    """Index every discoverable order JSON by id (queues + active + complete).

    Live queue/active copies win over archived complete copies when ids collide.
    """
    index: dict[str, Order] = {}
    # complete first (lowest precedence), then active, then live queues (highest)
    search_dirs = [
        mso / "orders" / "complete",
        mso / "orders" / "active",
        mso / "queues" / "orders",
        mso / "queues" / "bugs",
        mso / "queues" / "security",
        mso / "queues" / "review",
        mso / "queues" / "requests",
        mso / "queues" / "escalations",
    ]
    for d in search_dirs:
        if not d.exists():
            continue
        for f in d.glob("*.json"):
            data = _load_json_safe(f)
            if not data:
                continue
            order = _map_order(data, workspace_id)
            if order.id:
                index[order.id] = order
    return index


def _queue_orders(mso: Path, workspace_id: str) -> list[Order]:
    """Orders currently sitting in the live queue dirs (the workspace's worklist)."""
    out: list[Order] = []
    for d in ["orders", "bugs", "security", "review", "requests", "escalations"]:
        qd = mso / "queues" / d
        if not qd.exists():
            continue
        for f in sorted(qd.glob("*.json")):
            data = _load_json_safe(f)
            if not data:
                continue
            order = _map_order(data, workspace_id)
            if order.id:
                out.append(order)
    return out


def _voyage_target_repos(data: dict, member_orders: list[Order]) -> list[str]:
    """Ordered, de-duplicated real repo set for a voyage (FTR-MSO-2026-0380).

    Mirrors ``_voyage_repo_slugs`` (maestro/core/fleet_runner.py): prefers the
    manifest's authoritative ``targetRepos`` list (written incrementally as
    each repo's PR is recorded), falls back to the keys of a ``prUrls`` map,
    and finally derives from the member orders' ``target_repo`` set for a
    voyage dispatched before either was written. ``[]`` for a legacy/
    single-repo voyage that carries none of the three — callers keep using
    the flat ``repo``/``pr_url`` fields for those.
    """
    repos: list[str] = []
    seen: set[str] = set()
    for repo in (data.get("targetRepos") or []):
        if isinstance(repo, str) and repo and repo not in seen:
            seen.add(repo)
            repos.append(repo)
    prurls = data.get("prUrls")
    if isinstance(prurls, dict):
        for repo in prurls:
            if isinstance(repo, str) and repo and repo not in seen:
                seen.add(repo)
                repos.append(repo)
    if not repos:
        for o in member_orders:
            repo = (o.target_repo or "").strip()
            if repo and repo not in seen:
                seen.add(repo)
                repos.append(repo)
    return repos


def _voyage_pr_urls(data: dict) -> dict[str, VoyagePrEntry]:
    """Parse the manifest's ``prUrls`` map into contract entries, tolerating
    malformed/partial data (FTR-MSO-2026-0380)."""
    prurls = data.get("prUrls")
    if not isinstance(prurls, dict):
        return {}
    out: dict[str, VoyagePrEntry] = {}
    for repo, entry in prurls.items():
        if isinstance(repo, str) and repo and isinstance(entry, dict):
            out[repo] = VoyagePrEntry(
                prNumber=entry.get("prNumber") if isinstance(entry.get("prNumber"), int) else None,
                prUrl=entry.get("prUrl") if isinstance(entry.get("prUrl"), str) else None,
                state=entry.get("state") if isinstance(entry.get("state"), str) else None,
                mergeCommit=entry.get("mergeCommit") if isinstance(entry.get("mergeCommit"), str) else None,
                mergedAt=entry.get("mergedAt") if isinstance(entry.get("mergedAt"), str) else None,
            )
    return out


def _read_voyages(mso: Path, workspace_id: str, order_index: dict[str, Order],
                   product_repo: Optional[Path] = None) -> list[Voyage]:
    """Read active + complete voyage JSONs → contract Voyage list."""
    from maestro.hub import phase as phase_mod

    # FTR-MSO-2026-0351: authoritative per-order state for the derived voyage
    # phase — loaded once per workspace read, shared across all voyages.
    ledger_view = phase_mod.load_ledger_view(mso)
    archive_statuses = phase_mod.read_archive_statuses(mso)

    def _dep_status(oid: str) -> str:
        fallback = order_index.get(oid)
        return phase_mod.effective_order_status(
            oid, fallback.status if fallback else None,
            ledger_view, archive_statuses)

    results: list[Voyage] = []
    for state, default_status in (("active", "ACTIVE"), ("complete", "COMPLETE")):
        voyages_dir = mso / "voyages" / state
        if not voyages_dir.exists():
            continue
        for f in sorted(voyages_dir.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True):
            data = _load_json_safe(f)
            if not data:
                continue
            if (data.get("status") or "").upper() == "AWAITING_APPROVAL":
                continue

            voyage_id = data.get("voyageId") or data.get("id") or f.stem
            raw_orders = data.get("orders") or []
            statuses = data.get("orderStatuses") or {}

            member_orders: list[Order] = []
            for o in raw_orders:
                if isinstance(o, dict):
                    oid = o.get("orderId") or o.get("id") or ""
                    resolved = order_index.get(oid)
                    if resolved is not None:
                        member_orders.append(resolved)
                    elif oid:
                        member = _map_order(o, workspace_id)
                        member.voyage_id = member.voyage_id or voyage_id
                        member_orders.append(member)
                else:
                    oid = str(o)
                    resolved = order_index.get(oid)
                    if resolved is not None:
                        member_orders.append(resolved)
                    else:
                        member_orders.append(Order(
                            id=oid,
                            status=(statuses.get(oid) or "PENDING"),
                            voyage_id=voyage_id,
                            workspace_id=workspace_id,
                        ))

            complete = sum(1 for o in member_orders if (o.status or "").upper() == "COMPLETE")
            status = _derive_voyage_status(data.get("status") or default_status, member_orders)

            # Feature A: repo = most common non-empty target_repo among members
            # (they share one) — kept verbatim as the back-compat flat field
            # (single-repo voyages are byte-identical). FTR-MSO-2026-0380:
            # target_repos below carries the REAL per-repo set instead of
            # collapsing a multi-repo voyage to one most-common guess.
            from collections import Counter
            repo_counts = Counter(
                (o.target_repo or "").strip()
                for o in member_orders
                if (o.target_repo or "").strip()
            )
            repo = repo_counts.most_common(1)[0][0] if repo_counts else ""
            target_repos = _voyage_target_repos(data, member_orders)
            pr_urls = _voyage_pr_urls(data)

            worktree = ""
            if status == "ACTIVE":
                # FTR-MSO-2026-0364: worktrees live under .mso/worktrees/<VID>/;
                # a legacy in-voyage .worktree dir wins while it still exists
                # (in-flight voyages dispatched pre-relocation). FTR-0380: this
                # is the voyage's worktree HOME, not a single checkout — a
                # multi-repo voyage (plan §4.3) nests its per-repo/per-crew
                # worktrees under it (crew<N>-<repoName>, admin-<repoName>),
                # so the fabricated path already honours that layout as-is.
                legacy_wt = mso / "voyages" / "active" / voyage_id / ".worktree"
                wt_path = legacy_wt if legacy_wt.exists() else mso / "worktrees" / voyage_id
                worktree = wt_path.as_posix()

            # FTR-MSO-2026-0351: derived phase from ledger + archive + PR state
            # — never from the stored voyage `status` (static/stale).
            pr_merged = bool(
                data.get("mergedPR") or data.get("mergedAt")
                or data.get("prMerged") or data.get("mergeCommit")
            )
            # BUG-MSO-2026-0394: a PR recorded on the manifest (flat fields or
            # a non-empty prUrls map) even without merge metadata — lets the
            # phase deriver tell "archived because all orders finished, PR
            # still open" apart from "archived because it actually merged".
            pr_linked = bool(
                data.get("prUrl") or data.get("pr_url") or data.get("prNumber")
                or (isinstance(pr_urls, dict) and pr_urls)
            )
            member_states = [
                phase_mod.MemberState(
                    order_id=o.id,
                    status=phase_mod.effective_order_status(
                        o.id, o.status, ledger_view, archive_statuses),
                    role=o.target_role or o.role or "",
                    depends_on=list(o.depends_on or []),
                )
                for o in member_orders
            ]
            derived = phase_mod.compute_voyage_phase(
                member_states,
                pr_merged=pr_merged,
                voyage_archived=(state == "complete"),
                dep_status=_dep_status,
                # FTR-MSO-2026-0373: reconcile flags a PR closed-without-merge on
                # the manifest — surface it as needs_attention for the operator.
                closed_without_merge=bool(data.get("closedWithoutMerge")),
                pr_linked=pr_linked,
            )

            # BUG-MSO-2026-0360: manifests written before the dispatcher
            # recorded PR linkage lack prUrl — fall back to a cached gh
            # lookup, but only where the link is load-bearing (an active
            # voyage sitting in Final Review awaiting its PR review/merge).
            voyage_pr_url = data.get("prUrl") or data.get("pr_url")
            if (not voyage_pr_url and state == "active"
                    and derived.phase == phase_mod.PHASE_FINAL_REVIEW):
                voyage_pr_url = _pr_url_fallback(
                    mso, data.get("branch") or data.get("voyageBranch") or "",
                    product_repo)

            # BUG-MSO-2026-0394: flat sibling to pr_url. Ambiguous (left None)
            # for a genuine multi-repo voyage with >1 PR linked via prUrls —
            # only a single-repo prUrls-only manifest gets the fallback below.
            voyage_pr_number = data.get("prNumber")
            if not isinstance(voyage_pr_number, int):
                raw_pr_number = data.get("pr_number")
                voyage_pr_number = raw_pr_number if isinstance(raw_pr_number, int) else None
            if voyage_pr_number is None and len(pr_urls) == 1:
                (_only_pr_entry,) = pr_urls.values()
                voyage_pr_number = _only_pr_entry.prNumber

            results.append(Voyage(
                id=voyage_id,
                title=data.get("title", "") or "",
                status=status,
                branch=data.get("branch") or data.get("voyageBranch") or "",
                order_count=len(member_orders),
                complete_count=complete,
                orders=member_orders or None,
                created_at=data.get("createdAt", "") or "",
                pr_url=voyage_pr_url,
                pr_number=voyage_pr_number,
                workspace_id=workspace_id,
                repo=repo,
                worktree=worktree,
                phase=derived.phase,
                phaseReason=derived.reason,
                rollup=VoyageOrderRollup(**derived.rollup),
                targetRepos=target_repos,
                prUrls=pr_urls,
            ))
    return results


def _read_one_crew(mso: Path, slot: int) -> CrewState:
    """Read state.json for one crew slot; returns IDLE CrewState if missing."""
    name = _crew_name(slot)
    state_file = mso / "crews" / f"crew{slot}" / "state.json"
    data = _load_json_safe(state_file)
    if not data:
        return CrewState(slot=slot, name=name, status="IDLE")

    activity_age: Optional[int] = None
    activity_file = mso / "crews" / f"crew{slot}" / "activity.txt"
    if activity_file.exists():
        try:
            if activity_file.read_text(encoding="utf-8").strip():
                activity_age = int(time.time() - activity_file.stat().st_mtime)
        except Exception:
            pass

    def _int_or_none(v):
        return int(v) if isinstance(v, (int, float)) else None

    return CrewState(
        slot=slot,
        name=name,
        status=data.get("status", "IDLE") or "IDLE",
        role=data.get("role") or None,
        current_order_id=data.get("orderId") or data.get("currentOrderId") or None,
        current_order_title=data.get("orderTitle") or data.get("currentOrderTitle") or None,
        iteration=_int_or_none(data.get("iteration")),
        max_iterations=_int_or_none(data.get("maxIterations")),
        activity_age_seconds=activity_age,
        pid=_int_or_none(data.get("pid")),
        session_id=data.get("claudeSessionId") or data.get("sessionId") or None,
        maestro_session_id=data.get("maestroSessionId") or None,
    )


def _read_crews(mso: Path, max_crews: int = 5) -> list[CrewState]:
    """Read crew state for all slots (1..max_crews)."""
    return [_read_one_crew(mso, i) for i in range(1, max_crews + 1)]


def _read_queue_summary(mso: Path) -> dict[str, int]:
    """Counts per queue dir (Record<string,number> for the frontend)."""
    queues = mso / "queues"
    summary: dict[str, int] = {}
    if not queues.exists():
        return summary
    for d in sorted(p for p in queues.iterdir() if p.is_dir()):
        n = len(list(d.glob("*.json")))
        if n:
            summary[d.name] = n
    return summary


def _read_config(mso: Path, workspace_id: str) -> tuple[WorkspaceConfig, Optional[str], Optional[str]]:
    """Read workspace.json + gates.json → (WorkspaceConfig, persona, project).

    FTR-MSO-2026-0328: exposes all per-workspace dispatch defaults so the Hub
    drawer can show real values instead of hardcoded mocks.  Fields absent from
    workspace.json are returned as None (frontend renders "using default").
    """
    ws = _load_json_safe(mso / "config" / "workspace.json") or {}

    persona = ws.get("persona") or "nautical"
    project = ws.get("project") or workspace_id

    max_crews = ws.get("maxCrews")
    if max_crews is None:
        # fall back to fleet-settings.json if present (legacy)
        fleet = _load_json_safe(mso / "config" / "fleet-settings.json") or {}
        max_crews = fleet.get("maxCrews")
    max_crews = int(max_crews) if isinstance(max_crews, (int, float)) else None

    def _int_opt(v) -> Optional[int]:
        return int(v) if isinstance(v, (int, float)) else None

    completion_cfg = None
    raw_completion = ws.get("completion")
    role_timeouts: Optional[dict[str, int]] = None
    if isinstance(raw_completion, dict):
        idle = raw_completion.get("idleWatchdog")
        ovc = raw_completion.get("onVoyageComplete")
        rt = raw_completion.get("roleTimeouts")
        if isinstance(rt, dict):
            role_timeouts = {str(k): int(v) for k, v in rt.items() if isinstance(v, (int, float))}
        completion_cfg = CompletionConfig(
            idleWatchdog=IdleWatchdogConfig(
                enabled=bool(idle.get("enabled", False)),
                idleMinutes=int(idle.get("idleMinutes", 30)),
                action=str(idle.get("action", "none")),
            ) if isinstance(idle, dict) else None,
            onVoyageComplete=OnVoyageCompleteConfig(
                archiveVoyageOnMerge=bool(ovc.get("archiveVoyageOnMerge", True)),
                archiveOrders=bool(ovc.get("archiveOrders", True)),
                autoRelease=bool(ovc.get("autoRelease", False)),
            ) if isinstance(ovc, dict) else None,
            roleTimeouts=role_timeouts,
        )

    # Workspace-level dispatch defaults (all optional; absent → None → "using default" in UI)
    max_iterations = _int_opt(ws.get("maxIterations"))
    max_turns = _int_opt(ws.get("maxTurns"))
    timeout_minutes = _int_opt(ws.get("timeoutMinutes"))
    auto_dispatch_raw = ws.get("autoDispatch")
    auto_dispatch = bool(auto_dispatch_raw) if auto_dispatch_raw is not None else None
    token_daily_cap = _int_opt(ws.get("tokenDailyCap"))

    # requirePlanReview: read from gates.json post_nav_review.enabled
    require_plan_review: Optional[bool] = None
    gates = _load_json_safe(mso / "config" / "gates.json") or {}
    post_nav = gates.get("post_nav_review")
    if isinstance(post_nav, dict):
        require_plan_review = bool(post_nav.get("enabled", False))

    config = WorkspaceConfig(
        persona=persona,
        project=project,
        maxCrews=max_crews,
        completion=completion_cfg,
        maxIterations=max_iterations,
        maxTurns=max_turns,
        timeoutMinutes=timeout_minutes,
        autoDispatch=auto_dispatch,
        requirePlanReview=require_plan_review,
        tokenDailyCap=token_daily_cap,
    )
    return config, persona, project


def _read_repos(mso: Path, product_repo: Path, workspace_id: str) -> list[Repo]:
    """Read managed repos from workspace config, else a sensible default.

    The fallback path is the PRODUCT repo (where source code actually lives),
    never the artefact root — in solo/shared mode those are different repos.
    """
    ws = _load_json_safe(mso / "config" / "workspace.json") or {}
    raw = ws.get("managedRepos") or ws.get("repos") or []
    repos: list[Repo] = []
    if isinstance(raw, list):
        for r in raw:
            if isinstance(r, dict):
                name = r.get("name") or r.get("id") or ""
                path = r.get("path") or ""
                repos.append(Repo(
                    id=r.get("id") or name or path,
                    name=name or (Path(path).name if path else workspace_id),
                    path=path or str(product_repo),
                    default_branch=r.get("defaultBranch") or r.get("default_branch") or "main",
                ))
            elif isinstance(r, str):
                repos.append(Repo(id=r, name=Path(r).name, path=r, default_branch="main"))
    return repos


def _max_crews(mso: Path) -> int:
    ws = _load_json_safe(mso / "config" / "workspace.json") or {}
    mc = ws.get("maxCrews")
    if isinstance(mc, (int, float)):
        return int(mc)
    return _get_max_crews(mso)


def _artefact_mode(mso: Path) -> str:
    """Workspace artefact mode: 'embedded' | 'solo' | 'shared' (FTR-MSO-2026-0376).

    Reads workspace.json's `artefacts.mode` key directly from *mso* rather
    than calling `maestro.workspace.get_artefact_mode()`, which resolves via
    `MAESTRO_DIR`/cwd and would be wrong when the Hub aggregates several
    workspaces in one process (this module stays path-parameterised — see
    module docstring). Mirrors `maestro.workspace.ARTEFACT_MODES` semantics:
    absent/unreadable/unrecognised all mean "embedded".
    """
    ws = _load_json_safe(mso / "config" / "workspace.json") or {}
    block = ws.get("artefacts")
    mode = block.get("mode") if isinstance(block, dict) else None
    return mode if mode in ("solo", "shared") else "embedded"


def _dispatcher_pid(mso: Path) -> Optional[int]:
    pid_file = mso / "dispatcher.pid"
    if not pid_file.exists():
        return None
    try:
        return int(pid_file.read_text(encoding="utf-8").strip())
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Usage aggregation (FTR-MSO-2026-0330)
# ---------------------------------------------------------------------------

def _read_usage_stats(mso: Path, history_days: int = 14) -> WorkspaceUsage:
    """Aggregate token usage from .mso/usage/orders/*.json.

    Builds a daily history series (newest-last, up to history_days entries)
    suitable for the frontend sparkline.  Returns a zero WorkspaceUsage when
    the usage directory is absent or unreadable.
    """
    usage_dir = mso / "usage" / "orders"
    if not usage_dir.is_dir():
        return WorkspaceUsage()

    total_tokens: int = 0
    total_cost: float = 0.0
    order_count: int = 0
    # bucket: date-string → (tokens, cost)
    buckets: dict[str, tuple[int, float]] = {}

    for f in usage_dir.glob("*.json"):
        data = _load_json_safe(f)
        if not data:
            continue
        tokens = data.get("total_tokens") or 0
        cost = data.get("estimated_cost_usd") or 0.0
        if not isinstance(tokens, (int, float)):
            tokens = 0
        if not isinstance(cost, (int, float)):
            cost = 0.0
        tokens = int(tokens)
        cost = float(cost)

        total_tokens += tokens
        total_cost += cost
        order_count += 1

        ts = data.get("timestamp") or ""
        date_key = ts[:10] if len(ts) >= 10 else "unknown"
        prev_t, prev_c = buckets.get(date_key, (0, 0.0))
        buckets[date_key] = (prev_t + tokens, prev_c + cost)

    # Build sorted history series, capped to history_days (skipping "unknown")
    sorted_dates = sorted(
        (d for d in buckets if d != "unknown"),
        reverse=False,
    )[-history_days:]
    history = [
        UsagePoint(date=d, tokens=buckets[d][0], cost_usd=round(buckets[d][1], 4))
        for d in sorted_dates
    ]

    return WorkspaceUsage(
        total_tokens=total_tokens,
        estimated_cost_usd=round(total_cost, 4),
        order_count=order_count,
        history=history,
    )


# ---------------------------------------------------------------------------
# Phase 2 public API
# ---------------------------------------------------------------------------

def build_workspace_detail(ws_root: Path, workspace_id: str,
                            product_repo: Optional[Path] = None) -> WorkspaceDetail:
    """Build a full WorkspaceDetail matching the frontend contract.

    *ws_root* is the artefact root's parent (already resolved via
    ``workspace.artefact_parent_for_entry`` by the caller — this module stays
    path-parameterised and never reads the registry itself for this call).
    *product_repo* is the checkout that owns branches/PRs; defaults to
    *ws_root* (embedded mode: the two are the same directory).

    Returns an offline detail (no 500) when .mso/ is missing or unreadable.
    """
    product_repo = product_repo or ws_root
    try:
        mso = _get_mso_dir(ws_root)
        if not mso.is_dir():
            return offline_detail(workspace_id, str(ws_root))

        max_crews = _max_crews(mso)
        config, persona, project = _read_config(mso, workspace_id)
        order_index = _build_order_index(mso, workspace_id)
        voyages = _read_voyages(mso, workspace_id, order_index, product_repo)
        crews = _read_crews(mso, max_crews)
        orders = _queue_orders(mso, workspace_id)
        queue_summary = _read_queue_summary(mso)
        usage = _read_usage_stats(mso)

        # A voyage with a live crew running one of its orders is ACTIVE — the
        # crew state is the authoritative "in-flight" signal. On a busy fleet the
        # order FILES churn (an order flips IN_PROGRESS -> COMPLETE per role-phase
        # while the crew advances to the next role), and the voyage JSON's own
        # status is often left stale at PLANNED. Reconcile against running crews.
        _apply_running_crew_voyage_status(voyages, crews)

        return WorkspaceDetail(
            id=workspace_id,
            name=workspace_id,
            path=str(ws_root),
            dispatcher_running=_dispatcher_running(mso),
            active_crew_count=_count_active_crews(mso, max_crews),
            active_voyage_count=_count_active_voyages(mso),
            pending_review_count=_count_review_pending(mso),
            pending_order_count=_count_pending_orders(mso),
            persona=persona,
            project=project,
            config=config,
            voyages=voyages,
            crews=crews,
            queue_summary=queue_summary,
            orders=orders,
            repos=_read_repos(mso, product_repo, workspace_id),
            usage=usage,
            artefactMode=_artefact_mode(mso),
        )
    except Exception:
        return offline_detail(workspace_id, str(ws_root))


def build_crew_list(ws_root: Path, workspace_id: str) -> list[CrewState]:
    """Build a bare CrewState[] (always max_crews slots, IDLE for non-running)."""
    try:
        mso = _get_mso_dir(ws_root)
        if mso.is_dir():
            return _read_crews(mso, _max_crews(mso))
    except Exception:
        pass
    return [CrewState(slot=i, name=_crew_name(i)) for i in range(1, 6)]


def offline_detail(workspace_id: str, path: str) -> WorkspaceDetail:
    """Return a WorkspaceDetail for an unreadable or missing workspace."""
    return WorkspaceDetail(
        id=workspace_id,
        name=workspace_id,
        path=path,
        config=WorkspaceConfig(project=workspace_id),
        crews=[CrewState(slot=i, name=_crew_name(i)) for i in range(1, 6)],
    )


# ---------------------------------------------------------------------------
# Usage aggregation (FTR-MSO-2026-0333) — path-parameterised, no globals
# ---------------------------------------------------------------------------

def _in_date_range(timestamp: str, from_date: Optional[str], to_date: Optional[str]) -> bool:
    """Return True when the record's date falls within [from_date, to_date] (inclusive, day granularity)."""
    date = timestamp[:10] if len(timestamp) >= 10 else ""
    if not date:
        return True  # undated records always pass the filter
    if from_date and date < from_date:
        return False
    if to_date and date > to_date:
        return False
    return True


def _iter_order_usage_json(
    usage_dir: Path,
    from_date: Optional[str] = None,
    to_date: Optional[str] = None,
):
    """Yield parsed JSON usage records from *.json files, date-filtered."""
    if not usage_dir.is_dir():
        return
    for f in usage_dir.glob("*.json"):
        data = _load_json_safe(f)
        if not data:
            continue
        ts = data.get("timestamp") or ""
        if not _in_date_range(ts, from_date, to_date):
            continue
        yield data


def _iter_order_usage_jsonl(
    usage_dir: Path,
    from_date: Optional[str] = None,
    to_date: Optional[str] = None,
):
    """Yield individual JSONL usage records from *.jsonl files, date-filtered."""
    if not usage_dir.is_dir():
        return
    for f in usage_dir.glob("*.jsonl"):
        try:
            for line in f.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if not line:
                    continue
                try:
                    data = json.loads(line)
                except json.JSONDecodeError:
                    continue
                ts = data.get("timestamp") or ""
                if not _in_date_range(ts, from_date, to_date):
                    continue
                yield data
        except Exception:
            continue


def _accumulate_series(
    buckets: dict,
    timestamp: str,
    tokens: int,
    cost: float,
) -> None:
    """Accumulate tokens/cost into a date-keyed series dict."""
    date = timestamp[:10] if len(timestamp) >= 10 else ""
    if not date:
        return
    prev_t, prev_c = buckets.get(date, (0, 0.0))
    buckets[date] = (prev_t + tokens, prev_c + cost)


def _build_series(date_buckets: dict) -> list[UsageSeriesPoint]:
    """Convert a {date: (tokens, cost)} dict into a sorted UsageSeriesPoint list."""
    return [
        UsageSeriesPoint(date=d, tokens=date_buckets[d][0], cost_usd=round(date_buckets[d][1], 4))
        for d in sorted(date_buckets)
    ]


def aggregate_usage_for_workspace(
    ws_root: Path,
    workspace_id: str,
    from_date: Optional[str] = None,
    to_date: Optional[str] = None,
    group_by: str = "order",
) -> UsageRollup:
    """Aggregate usage for a single workspace.

    group_by in {'voyage', 'order', 'role'}.  The 'role' dimension reads
    per-iteration JSONL records (from FTR-0332); degrades to empty buckets
    when none are present.
    """
    try:
        mso = _get_mso_dir(ws_root)
    except Exception:
        mso = _get_mso_dir(ws_root)

    usage_dir = mso / "usage" / "orders"

    # bucket_map: key → (total_tokens, total_cost, order_set)
    bucket_map: dict[str, list] = {}
    series_map: dict[str, tuple[int, float]] = {}
    grand_tokens = 0
    grand_cost = 0.0

    if group_by == "role":
        # Role dimension: read JSONL per-iteration records
        for rec in _iter_order_usage_jsonl(usage_dir, from_date, to_date):
            role = (rec.get("role") or "").strip() or "UNKNOWN"
            tokens = int(rec.get("total_tokens") or 0)
            cost = float(rec.get("estimated_cost_usd") or 0.0)
            ts = rec.get("timestamp") or ""
            order_id = rec.get("orderId") or ""
            if role not in bucket_map:
                bucket_map[role] = [0, 0.0, set()]
            bucket_map[role][0] += tokens
            bucket_map[role][1] += cost
            if order_id:
                bucket_map[role][2].add(order_id)
            grand_tokens += tokens
            grand_cost += cost
            _accumulate_series(series_map, ts, tokens, cost)
    else:
        # voyage and order dimensions: read JSON summary files
        for rec in _iter_order_usage_json(usage_dir, from_date, to_date):
            order_id = rec.get("orderId") or ""
            voyage_id = rec.get("voyageId") or ""
            tokens = int(rec.get("total_tokens") or 0)
            cost = float(rec.get("estimated_cost_usd") or 0.0)
            ts = rec.get("timestamp") or ""

            key = voyage_id if group_by == "voyage" else order_id
            if not key:
                key = order_id or "unknown"
            if key not in bucket_map:
                bucket_map[key] = [0, 0.0, set()]
            bucket_map[key][0] += tokens
            bucket_map[key][1] += cost
            if order_id:
                bucket_map[key][2].add(order_id)
            grand_tokens += tokens
            grand_cost += cost
            _accumulate_series(series_map, ts, tokens, cost)

    buckets = [
        UsageBucket(
            key=k,
            label=k,
            total_tokens=v[0],
            estimated_cost_usd=round(v[1], 4),
            order_count=len(v[2]) if isinstance(v[2], set) else v[0],
        )
        for k, v in sorted(bucket_map.items(), key=lambda x: -x[1][0])
    ]

    return UsageRollup(
        from_date=from_date,
        to_date=to_date,
        group_by=group_by,
        total_tokens=grand_tokens,
        estimated_cost_usd=round(grand_cost, 4),
        buckets=buckets,
        series=_build_series(series_map),
    )


def aggregate_usage_cross_workspace(
    from_date: Optional[str] = None,
    to_date: Optional[str] = None,
    group_by: str = "project",
) -> UsageRollup:
    """Cross-workspace usage rollup using the global project registry.

    group_by in {'project', 'voyage', 'order', 'role'}.
    A project/voyage/order with no data returns a zero bucket (not an error).
    """
    import maestro.registry as registry
    from maestro.workspace import artefact_parent_for_entry

    projects = registry.list_projects()

    if group_by == "project":
        # One bucket per registered workspace
        buckets: list[UsageBucket] = []
        series_map: dict[str, tuple[int, float]] = {}
        grand_tokens = 0
        grand_cost = 0.0

        for ws_id, entry in projects.items():
            ws_root = artefact_parent_for_entry(entry)
            rollup = aggregate_usage_for_workspace(ws_root, ws_id, from_date, to_date, "order")
            buckets.append(UsageBucket(
                key=ws_id,
                label=ws_id,
                total_tokens=rollup.total_tokens,
                estimated_cost_usd=rollup.estimated_cost_usd,
                order_count=len(rollup.buckets),
            ))
            grand_tokens += rollup.total_tokens
            grand_cost += rollup.estimated_cost_usd
            for pt in rollup.series:
                prev_t, prev_c = series_map.get(pt.date, (0, 0.0))
                series_map[pt.date] = (prev_t + pt.tokens, prev_c + pt.cost_usd)

        buckets.sort(key=lambda b: -b.total_tokens)
        return UsageRollup(
            from_date=from_date,
            to_date=to_date,
            group_by="project",
            total_tokens=grand_tokens,
            estimated_cost_usd=round(grand_cost, 4),
            buckets=buckets,
            series=_build_series(series_map),
        )
    else:
        # For voyage/order/role: aggregate across all workspaces, merge by key
        merged_buckets: dict[str, list] = {}
        series_map2: dict[str, tuple[int, float]] = {}
        grand_tokens2 = 0
        grand_cost2 = 0.0

        for ws_id, entry in projects.items():
            ws_root = artefact_parent_for_entry(entry)
            rollup = aggregate_usage_for_workspace(ws_root, ws_id, from_date, to_date, group_by)
            grand_tokens2 += rollup.total_tokens
            grand_cost2 += rollup.estimated_cost_usd
            for b in rollup.buckets:
                if b.key not in merged_buckets:
                    merged_buckets[b.key] = [0, 0.0, 0]
                merged_buckets[b.key][0] += b.total_tokens
                merged_buckets[b.key][1] += b.estimated_cost_usd
                merged_buckets[b.key][2] += b.order_count
            for pt in rollup.series:
                prev_t, prev_c = series_map2.get(pt.date, (0, 0.0))
                series_map2[pt.date] = (prev_t + pt.tokens, prev_c + pt.cost_usd)

        final_buckets = [
            UsageBucket(
                key=k, label=k,
                total_tokens=v[0],
                estimated_cost_usd=round(v[1], 4),
                order_count=v[2],
            )
            for k, v in sorted(merged_buckets.items(), key=lambda x: -x[1][0])
        ]
        return UsageRollup(
            from_date=from_date,
            to_date=to_date,
            group_by=group_by,
            total_tokens=grand_tokens2,
            estimated_cost_usd=round(grand_cost2, 4),
            buckets=final_buckets,
            series=_build_series(series_map2),
        )


def aggregate_usage_for_project(
    workspace_id: str,
    ws_root: Path,
    from_date: Optional[str] = None,
    to_date: Optional[str] = None,
) -> UsageRollup:
    """Per-project usage with voyage/order breakdown."""
    return aggregate_usage_for_workspace(ws_root, workspace_id, from_date, to_date, "voyage")


def aggregate_usage_for_voyage(
    voyage_id: str,
    ws_root: Path,
    from_date: Optional[str] = None,
    to_date: Optional[str] = None,
) -> UsageRollup:
    """Per-voyage usage: orders → roles (if JSONL data available).

    Filters the workspace's usage/orders/*.json files to those stamped with
    this voyageId (or belonging to the voyage's order list as a fallback).
    """
    try:
        mso = _get_mso_dir(ws_root)
    except Exception:
        mso = _get_mso_dir(ws_root)

    usage_dir = mso / "usage" / "orders"

    # Build the set of order IDs belonging to this voyage for fallback matching
    voyage_order_ids: set[str] = set()
    for sub in ("active", "complete"):
        vf = mso / "voyages" / sub / f"{voyage_id}.json"
        vdata = _load_json_safe(vf)
        if vdata:
            for o in vdata.get("orders") or []:
                if isinstance(o, dict):
                    oid = o.get("orderId") or o.get("id") or ""
                elif isinstance(o, str):
                    oid = o
                else:
                    oid = ""
                if oid:
                    voyage_order_ids.add(oid)

    # Collect per-order totals for this voyage
    order_buckets: dict[str, list] = {}
    series_map: dict[str, tuple[int, float]] = {}
    grand_tokens = 0
    grand_cost = 0.0

    for rec in _iter_order_usage_json(usage_dir, from_date, to_date):
        order_id = rec.get("orderId") or ""
        file_voyage = rec.get("voyageId") or ""
        if file_voyage != voyage_id:
            if order_id not in voyage_order_ids:
                continue
        tokens = int(rec.get("total_tokens") or 0)
        cost = float(rec.get("estimated_cost_usd") or 0.0)
        ts = rec.get("timestamp") or ""
        if order_id not in order_buckets:
            order_buckets[order_id] = [0, 0.0]
        order_buckets[order_id][0] += tokens
        order_buckets[order_id][1] += cost
        grand_tokens += tokens
        grand_cost += cost
        _accumulate_series(series_map, ts, tokens, cost)

    buckets = [
        UsageBucket(
            key=k, label=k,
            total_tokens=v[0],
            estimated_cost_usd=round(v[1], 4),
            order_count=1,
        )
        for k, v in sorted(order_buckets.items(), key=lambda x: -x[1][0])
    ]

    return UsageRollup(
        from_date=from_date,
        to_date=to_date,
        group_by="order",
        total_tokens=grand_tokens,
        estimated_cost_usd=round(grand_cost, 4),
        buckets=buckets,
        series=_build_series(series_map),
    )


def get_order_usage_detail(
    order_id: str,
    usage_dir: Path,
) -> OrderUsageDetail:
    """Full usage breakdown for a single order (JSON + JSONL combined).

    Reads {order_id}.json for the base total + models breakdown.
    Reads {order_id}.jsonl for per-role/per-iteration detail (FTR-0332 data).
    Degrades gracefully when JSONL is absent.
    """
    detail = OrderUsageDetail(order_id=order_id)

    # Base JSON record
    json_file = usage_dir / f"{order_id}.json"
    base = _load_json_safe(json_file)
    if base:
        detail.total_tokens = int(base.get("total_tokens") or 0)
        detail.estimated_cost_usd = round(float(base.get("estimated_cost_usd") or 0.0), 4)
        detail.voyage_id = base.get("voyageId") or None
        detail.timestamp = base.get("timestamp") or None
        raw_models = base.get("models") or {}
        for model_name, mu in raw_models.items():
            if isinstance(mu, dict):
                detail.models[model_name] = ModelUsage(
                    input_tokens=int(mu.get("input_tokens") or 0),
                    output_tokens=int(mu.get("output_tokens") or 0),
                    cache_creation_input_tokens=int(mu.get("cache_creation_input_tokens") or 0),
                    cache_read_input_tokens=int(mu.get("cache_read_input_tokens") or 0),
                    message_count=int(mu.get("message_count") or 0),
                )

    # Per-iteration JSONL (FTR-0332 data) — role dimension + iterations list
    jsonl_file = usage_dir / f"{order_id}.jsonl"
    role_map: dict[str, list] = {}
    iterations: list[IterationUsage] = []

    if jsonl_file.exists():
        try:
            for line in jsonl_file.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if not line:
                    continue
                try:
                    rec = json.loads(line)
                except json.JSONDecodeError:
                    continue
                role = (rec.get("role") or "").strip() or "UNKNOWN"
                tokens = int(rec.get("total_tokens") or 0)
                cost = float(rec.get("estimated_cost_usd") or 0.0)
                ts = rec.get("timestamp") or ""
                crew = int(rec.get("crewNumber") or 0)
                iteration = int(rec.get("iteration") or 0)
                raw_models = rec.get("models") or {}

                model_usage = {
                    m: ModelUsage(
                        input_tokens=int(v.get("input_tokens") or 0),
                        output_tokens=int(v.get("output_tokens") or 0),
                        cache_creation_input_tokens=int(v.get("cache_creation_input_tokens") or 0),
                        cache_read_input_tokens=int(v.get("cache_read_input_tokens") or 0),
                        message_count=int(v.get("message_count") or 0),
                    )
                    for m, v in raw_models.items()
                    if isinstance(v, dict)
                }

                iterations.append(IterationUsage(
                    iteration=iteration,
                    role=role,
                    crew_number=crew,
                    total_tokens=tokens,
                    estimated_cost_usd=round(cost, 4),
                    timestamp=ts,
                    models=model_usage,
                ))

                if role not in role_map:
                    role_map[role] = [0, 0.0, set()]
                role_map[role][0] += tokens
                role_map[role][1] += cost
        except Exception:
            pass

    detail.iterations = iterations
    detail.role_buckets = [
        UsageBucket(
            key=r, label=r,
            total_tokens=v[0],
            estimated_cost_usd=round(v[1], 4),
            order_count=1,
        )
        for r, v in sorted(role_map.items(), key=lambda x: -x[1][0])
    ]

    return detail


def _find_order_usage_dir(order_id: str) -> Optional[Path]:
    """Search registered workspaces for an order's usage directory.

    Returns the usage/orders dir of the first workspace that has
    a usage file ({order_id}.json or {order_id}.jsonl) for this order.
    Returns None if not found in any workspace.
    """
    import maestro.registry as registry
    from maestro.workspace import artefact_parent_for_entry

    for ws_id, entry in registry.list_projects().items():
        ws_root = artefact_parent_for_entry(entry)
        try:
            mso = _get_mso_dir(ws_root)
        except Exception:
            mso = _get_mso_dir(ws_root)
        usage_dir = mso / "usage" / "orders"
        if (usage_dir / f"{order_id}.json").exists() or (usage_dir / f"{order_id}.jsonl").exists():
            return usage_dir
    return None
