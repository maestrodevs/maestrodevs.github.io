# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Hub daemon PID management (mirrors maestro/bridge.py pattern exactly).

The hub is a GLOBAL daemon (not per-workspace) — PID file at ~/.maestro/hub.pid.
"""

from __future__ import annotations

import os
import subprocess
import sys
import webbrowser
from pathlib import Path
from typing import Optional

from maestro.launch.sandbox import spawn as _spawn
from maestro.workspace import get_maestro_home

DEFAULT_PORT = 3847


def _hub_pid_file() -> Path:
    """Global Hub PID file, resolved live so MAESTRO_HOME redirects it
    (BUG-MSO-2026-0387). Default ``~/.maestro/hub.pid``."""
    return get_maestro_home() / "hub.pid"


# ---------------------------------------------------------------------------
# PID helpers (verbatim from bridge.py)
# ---------------------------------------------------------------------------

def _is_process_alive(pid: int) -> bool:
    if not pid or pid <= 0:
        return False
    try:
        if os.name == "nt":
            import ctypes
            PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            STILL_ACTIVE = 259
            kernel32 = ctypes.windll.kernel32
            handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
            if handle == 0:
                return False
            try:
                exit_code = ctypes.c_ulong()
                if kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code)):
                    return exit_code.value == STILL_ACTIVE
                return False
            finally:
                kernel32.CloseHandle(handle)
        else:
            os.kill(pid, 0)
            return True
    except (ProcessLookupError, PermissionError, OSError):
        return False


def _read_pid(pid_file: Path) -> Optional[int]:
    if not pid_file.exists():
        return None
    try:
        return int(pid_file.read_text(encoding="utf-8").strip())
    except (ValueError, OSError):
        return None


# ---------------------------------------------------------------------------
# Dep check
# ---------------------------------------------------------------------------

def _ensure_hub_deps() -> None:
    try:
        import fastapi  # noqa: F401
        import uvicorn  # noqa: F401
    except ImportError:
        print(
            "[Hub] FastAPI/uvicorn not installed.\n"
            "      Install the hub extra:  pip install 'maestro[hub]'",
            file=sys.stderr,
        )
        sys.exit(1)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def start_hub(port: int = DEFAULT_PORT, open_browser: bool = False) -> None:
    hub_pid = _hub_pid_file()
    existing_pid = _read_pid(hub_pid)
    if existing_pid and _is_process_alive(existing_pid):
        print(f"[Hub] Already running (PID: {existing_pid}) on http://127.0.0.1:{port}")
        if open_browser:
            webbrowser.open(f"http://127.0.0.1:{port}")
        return

    _ensure_hub_deps()

    cmd = [sys.executable, "-m", "maestro.hub", "--port", str(port)]
    hub_pid.parent.mkdir(parents=True, exist_ok=True)

    if os.name == "nt":
        DETACHED_PROCESS = 0x00000008
        CREATE_NEW_PROCESS_GROUP = 0x00000200
        flags = DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
        proc = _spawn(
            cmd,
            identity="hub",
            creationflags=flags,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    else:
        proc = _spawn(
            cmd,
            identity="hub",
            start_new_session=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

    hub_pid.write_text(str(proc.pid), encoding="utf-8")
    print(f"[Hub] Started on http://127.0.0.1:{port} (PID {proc.pid})")
    if open_browser:
        webbrowser.open(f"http://127.0.0.1:{port}")


def stop_hub() -> None:
    hub_pid = _hub_pid_file()
    pid = _read_pid(hub_pid)
    if not pid or not _is_process_alive(pid):
        print("[Hub] Not running")
        if hub_pid.exists():
            hub_pid.unlink()
        return

    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/PID", str(pid)], capture_output=True, timeout=10)
        else:
            os.kill(pid, 15)  # SIGTERM
        print(f"[Hub] Stop signal sent (PID: {pid})")
    except Exception as exc:
        print(f"[Hub] Failed to stop: {exc}", file=sys.stderr)

    import time
    time.sleep(1)
    if hub_pid.exists() and not _is_process_alive(pid):
        hub_pid.unlink()


def hub_status() -> dict:
    pid = _read_pid(_hub_pid_file())
    running = bool(pid and _is_process_alive(pid))
    return {"running": running, "pid": pid if running else None, "port": DEFAULT_PORT}


def print_status() -> None:
    s = hub_status()
    print("\n  MAESTRO HUB — STATUS")
    print("  " + "-" * 40)
    if s["running"]:
        print(f"  Status:  RUNNING (PID: {s['pid']})")
        print(f"  URL:     http://127.0.0.1:{s['port']}")
    else:
        print("  Status:  STOPPED")
    print("  " + "-" * 40)
    print()
