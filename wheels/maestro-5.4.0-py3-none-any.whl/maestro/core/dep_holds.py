"""Dependency-hold snapshot — makes DEP_HELD orders visible off-process (BUG-MSO-2026-0349).

Why this exists
---------------
When ``scan_all_queues`` refuses to dispatch an order (unmet dependency, a
BUG-0251 STALLED(cause=ERROR) dependency, an escalation block, or a role-gate
miss), the hold lives only in the dispatcher's in-memory ``WAITING_ON_DEPS``
map plus a ``DEP_HELD`` line in ``lifecycle.log``. ``mso status`` runs in a
SEPARATE process, so the held order surfaces as a bare ``N pending`` count —
indistinguishable from genuinely dispatchable work (GitHub issue #202:
FTR-GKT-2026-0169 was held on a zero-progress STALLED dependency, but the
morning status showed only ``QUEUE 1 pending · BLD:1``).

The dispatcher snapshots ``WAITING_ON_DEPS`` here after every queue scan; the
monitor (``fleet_monitor.get_queue_counts``) reads it back and splits held
items out of the pending count. The file lives in the gitignored
``.mso/state/`` control plane — same rationale as ``order-ledger.jsonl``
(BUG-0294): runtime truth that no git operation can rewind and that never
round-trips through voyage PRs.

File shape::

    {
      "updatedAt": "<iso8601>",
      "holds": {
        "<ORDER-ID>": {"waitingOn": ["<annotated dep>", ...], "heldSince": "<iso8601>"}
      }
    }

All writes are best-effort — a snapshot failure must never crash the
dispatcher. Readers treat a missing or corrupt file as "no holds"; the
lifecycle log remains the audit trail of record.
"""

from __future__ import annotations

import json
import os
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

DEP_HOLDS_RELPATH = Path("state") / "dep-holds.json"

# Last holds map actually written by this process — skips the rewrite on the
# ~10s scan tick when nothing changed (same churn-avoidance rationale as the
# dispatcher's _DEP_HELD_LOGGED lifecycle dedup).
_LAST_WRITTEN: Optional[Dict[str, List[str]]] = None


def _workspace_dir() -> Path:
    from maestro.workspace import get_workspace_dir
    return get_workspace_dir()


def dep_holds_path(workspace_dir: Optional[Path] = None) -> Path:
    return (workspace_dir or _workspace_dir()) / DEP_HOLDS_RELPATH


def write_dep_holds(holds: Dict[str, List[str]],
                    workspace_dir: Optional[Path] = None) -> None:
    """Snapshot the dispatcher's current hold map (order id -> reasons).

    Preserves each order's ``heldSince`` across rewrites so consumers can show
    how long an item has been blocked. Atomic (write-temp + replace) so a
    concurrent reader never sees a torn file. Never raises.
    """
    global _LAST_WRITTEN
    try:
        path = dep_holds_path(workspace_dir)
        if _LAST_WRITTEN == holds and path.exists():
            return
        existing = read_dep_holds(workspace_dir)
        now = datetime.now().isoformat()
        snapshot = {
            "updatedAt": now,
            "holds": {
                order_id: {
                    "waitingOn": list(reasons),
                    "heldSince": existing.get(order_id, {}).get("heldSince", now),
                }
                for order_id, reasons in holds.items()
            },
        }
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(snapshot, indent=2), encoding="utf-8")
        os.replace(str(tmp), str(path))
        _LAST_WRITTEN = {k: list(v) for k, v in holds.items()}
    except Exception:
        pass  # best-effort: the lifecycle log remains the audit trail


def read_dep_holds(workspace_dir: Optional[Path] = None) -> Dict[str, dict]:
    """Return the holds map ({order id: {waitingOn, heldSince}}), {} on any error."""
    try:
        path = dep_holds_path(workspace_dir)
        if not path.exists():
            return {}
        data = json.loads(path.read_text(encoding="utf-8"))
        holds = data.get("holds", {})
        return holds if isinstance(holds, dict) else {}
    except Exception:
        return {}
