"""Worktree lifecycle primitives for parallel voyage isolation.

Provides prepare/cleanup/prune operations for git worktrees scoped to the
runtime worktree home under .mso/worktrees/<voyage_id>/ (FTR-MSO-2026-0364).

Per-crew isolation (BUG-MSO-2026-0240)
---------------------------------------
FTR-ADM-2026-0149 introduced a single shared worktree per voyage, which
caused concurrent crews of the same voyage to clobber each other's files
and git index. The fix gives every dispatched crew its OWN worktree on a
per-crew branch:

  .mso/worktrees/<voyage_id>/crew<N>   ← crew N works here
  .mso/worktrees/<voyage_id>/admin     ← voyage admin worktree
                                          (convergence merges only)

When a crew completes, its crew branch is merged back into the voyage branch
via merge_crew_branch_into_voyage() and the crew worktree is cleaned up.
Cross-voyage parallelism (different voyages → different voyage dirs) is
unaffected.

Worktree relocation (FTR-MSO-2026-0364, Captain ruling PLAN-PLN-MSO-2026-0358
§0a #6): worktrees used to live INSIDE voyages/active/<voyage_id>/ next to
durable JSON, polluting the artefact tree (GKT counted 55,857 files there,
nearly all node_modules). They now live under the gitignored runtime home
.mso/worktrees/. LEGACY worktrees at voyages/active/<VID>/.worktree[-crewN]
are still honoured for in-flight voyages: the path resolvers return the
legacy location while it exists on disk (so running work is never stranded),
and the cleanup/prune sweeps cover both homes so legacy worktrees are pruned
when their voyage completes. New voyages always create under .mso/worktrees/.
"""

from __future__ import annotations

import itertools
import os
import re
import subprocess
from maestro.core.proc import run_hidden, popen_hidden  # FTR-MSO-2026-0408: windowless subprocess
import threading
import time
from pathlib import Path
from typing import Optional

# FTR-MSO-2026-0362: the artefact dir name is never hand-spelled in this module;
# prefix tuples and pathspecs below build from the canonical constant.
from maestro.workspace import MSO_DIR_NAME

# BUG-MSO-2026-0306: monotonic counter for unique scratch-worktree paths within
# a process. Combined with the pid it guarantees `git worktree add` never
# collides with a leftover dir, even if a prior teardown failed on Windows.
_SCRATCH_SEQ = itertools.count()

# BUG-MSO-2026-0308: dispatcher CONTROL-PLANE paths — the dispatcher (voyage
# side) is authoritative for these; a crew branch only ever carries a STALE
# copy, so a convergence conflict here is auto-resolved in favour of the
# voyage. Crew DELIVERABLE paths under .mso (reports/, handoffs/, plans/,
# prompts/) are deliberately NOT here — they merge normally.
_CONTROL_PLANE_PREFIXES = tuple(
    f"{MSO_DIR_NAME}/{d}/" for d in ("queues", "orders", "voyages", "state", "usage")
)

# BUG-MSO-2026-0342: per-crew TELEMETRY paths — scratch the CREW writes as it
# works (progress.md etc.). In workspaces that track .mso/crews/ in git (this
# repo gitignores it; consumer workspaces like PSG may not), the crew branch
# carries the LATEST copy and the voyage side a stale one, so a convergence
# conflict here is auto-resolved in favour of the CREW. Never a reason to
# AUTO_SERIALIZE-requeue a completed role.
_CREW_TELEMETRY_PREFIXES = (
    f"{MSO_DIR_NAME}/crews/",
)


def _bookkeeping_machinery_active() -> bool:
    """FTR-MSO-2026-0366: is the control-plane conflict machinery needed?

    The auto-resolve/flush/clean machinery below exists because EMBEDDED mode
    carries ``.mso`` inside the product repo, so dispatcher bookkeeping rides
    crew/voyage branches and collides at convergence (BUG-0305/0308/0342/0343).
    In solo/shared artefact-repo mode the product repos carry no ``.mso`` at
    all — crew→voyage merges are SOURCE ONLY — so the machinery is switched
    off cleanly rather than ported (plan PLAN-PLN-MSO-2026-0358 §3.4). Any
    leftover ``.mso`` conflict in a product repo then escalates as a genuine
    source conflict, which is the honest signal (it means migration hygiene
    failed, not that the dispatcher should paper over it).

    Fail-open to True (embedded behaviour) — full back-compat.
    """
    try:
        from maestro.workspace import get_artefact_mode
        return get_artefact_mode() == "embedded"
    except Exception:
        return True


def _is_control_plane_path(path: str) -> bool:
    """True if *path* (a git-relative path, forward-slashed) is dispatcher
    control-plane bookkeeping (BUG-MSO-2026-0308)."""
    p = path.strip().strip('"').replace("\\", "/")
    return any(p.startswith(prefix) for prefix in _CONTROL_PLANE_PREFIXES)


def _is_crew_telemetry_path(path: str) -> bool:
    """True if *path* (a git-relative path, forward-slashed) is per-crew
    telemetry/scratch (BUG-MSO-2026-0342)."""
    p = path.strip().strip('"').replace("\\", "/")
    return any(p.startswith(prefix) for prefix in _CREW_TELEMETRY_PREFIXES)


def _autoresolve_bookkeeping_conflicts(run, conflict_files):
    """BUG-MSO-2026-0308 / BUG-MSO-2026-0342: auto-resolve a merge conflict that
    is confined to Maestro bookkeeping/telemetry paths, inside an in-progress
    (conflicted) merge.

    Control-plane paths keep the VOYAGE (dispatcher) copy (``--ours``);
    per-crew telemetry paths keep the CREW copy (``--theirs``). Neither class
    is ever a genuine content conflict — requeuing a completed role over them
    costs a full re-run (the PSG VOY-PSG-2026-0358 false-positives).

    ``run`` executes a git argv list in the merge worktree and returns a
    CompletedProcess. Returns ``(status, files)``:

    - ``("resolved", resolutions)`` — every conflict was bookkeeping/telemetry;
      the merge is committed and the caller proceeds to push. ``resolutions``
      lists ``"path (voyage)"`` / ``"path (crew)"`` for the lifecycle event.
    - ``("commit_failed", [detail])`` — auto-resolve could not commit; caller
      must ``git merge --abort`` and raise ``WorktreeError``.
    - ``("source", src_conflicts)`` — genuine source conflicts remain (or the
      conflict list was empty); caller must ``git merge --abort`` and escalate,
      reporting ONLY ``src_conflicts`` (telemetry noise filtered out).

    FTR-MSO-2026-0366: in solo/shared artefact-repo mode the machinery is
    switched off — every conflict is treated as a genuine source conflict
    (product-repo merges must not contain ``.mso`` paths at all).
    """
    if not _bookkeeping_machinery_active():
        return "source", list(conflict_files)
    src_conflicts = [f for f in conflict_files
                     if not _is_control_plane_path(f)
                     and not _is_crew_telemetry_path(f)]
    if not conflict_files or src_conflicts:
        return "source", src_conflicts
    resolutions = []
    for f in conflict_files:
        if _is_control_plane_path(f):
            side, winner = "--ours", "voyage"
        else:
            side, winner = "--theirs", "crew"
        run(["git", "checkout", side, "--", f])
        run(["git", "add", "--", f])
        resolutions.append(f"{f} ({winner})")
    commit_r = run(["git", "commit", "--no-edit"])
    if commit_r.returncode != 0:
        return "commit_failed", [commit_r.stderr.strip()]
    return "resolved", resolutions


# BUG-MSO-2026-0343: git refuses to START a merge when UNTRACKED working-tree
# files would be overwritten by it — no index conflict entries exist yet, so
# `git diff --diff-filter=U` is empty and the old error said "Conflicting
# files: unknown". The blocking paths are only available in git's own output.
_UNTRACKED_OVERWRITE_RE = re.compile(
    r"untracked working tree files would be (?:overwritten|removed) by "
    r"(?:merge|checkout):\s*\n((?:[ \t]+[^\n]*\n?)+)",
    re.IGNORECASE,
)


def _parse_untracked_overwrite_paths(git_output: str) -> list:
    """Extract the paths git lists under 'error: The following untracked
    working tree files would be overwritten by merge:' (BUG-MSO-2026-0343).

    Returns [] when the output does not contain that error."""
    paths = []
    for m in _UNTRACKED_OVERWRITE_RE.finditer(git_output or ""):
        for line in m.group(1).splitlines():
            p = line.strip().strip('"')
            if p:
                paths.append(p)
    return paths


def _clean_untracked_bookkeeping(run) -> list:
    """BUG-MSO-2026-0343: remove UNTRACKED files under Maestro bookkeeping/
    telemetry prefixes from the convergence worktree before merging.

    `git reset --hard origin/<voyage>` syncs TRACKED state only — telemetry a
    prior convergence attempt wrote into the voyage worktree (the PSG case:
    .mso/usage/orders/<order>.json) stays behind untracked and makes every
    subsequent merge of a crew branch that tracks the same path fail with
    "untracked working tree files would be overwritten by merge", stranding
    the order CONVERGENCE_FAILED. The branch/origin copy is authoritative for
    all of these paths, so deleting the local leftovers is always safe.

    Only non-gitignored untracked files are removed (gitignored files never
    block a merge). Returns the list of paths removed (possibly empty).

    FTR-MSO-2026-0366: no-op in solo/shared artefact-repo mode — product-repo
    worktrees carry no Maestro bookkeeping to clean."""
    if not _bookkeeping_machinery_active():
        return []
    prefixes = list(_CONTROL_PLANE_PREFIXES + _CREW_TELEMETRY_PREFIXES)
    ls_r = run(["git", "ls-files", "--others", "--exclude-standard", "--"] + prefixes)
    if ls_r.returncode != 0:
        return []
    untracked = [ln.strip().strip('"') for ln in ls_r.stdout.splitlines() if ln.strip()]
    if not untracked:
        return []
    run(["git", "clean", "-fdq", "--"] + prefixes)
    return untracked


from maestro.workspace import resolve_artefact_dir as _resolve_artefact_dir

from maestro.core.fleet_runner import _robust_rmtree

# Module-level lock to serialize concurrent prepare calls for the same worktree
_prepare_lock = threading.Lock()

# Serialize convergence merges to avoid concurrent pushes to the same voyage branch
_merge_lock = threading.Lock()


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class WorktreeError(Exception):
    """Base class for worktree lifecycle errors."""


class WorktreeBranchConflict(WorktreeError):
    """Branch is already checked out in another worktree."""


class WorktreeDirExists(WorktreeError):
    """Worktree directory exists but is not registered with git."""


class WorktreeMissingBranch(WorktreeError):
    """The requested branch does not exist and cannot be created."""


class WorktreeContentConflict(WorktreeError):
    """Merge failed due to a genuine content/add-add conflict (FTR-MSO-2026-0267).

    Raised instead of generic WorktreeError when `git merge` exits non-zero AND
    there are conflicting files (--diff-filter=U).  Distinguished from REF_MISSING
    (crew branch not found) and push failures so the dispatcher can auto-serialize
    the loser order instead of immediately escalating to CONVERGENCE_FAILED.

    Attributes:
        conflict_files: list of relative paths that conflicted.
    """

    def __init__(self, message: str, conflict_files: list):
        super().__init__(message)
        self.conflict_files = conflict_files


class ConvergenceNetworkError(WorktreeError):
    """Convergence failed due to a transient network/timeout condition (BUG-MSO-2026-0268).

    Raised when a git network op (voyage fetch, crew fetch, voyage push) times out
    or fails for a reason that indicates a transient infrastructure problem rather
    than a real content conflict or missing ref.

    Unlike WorktreeContentConflict (real merge conflict — may need operator) or
    REF_MISSING (crew branch absent — work is truly lost), this error class means
    the work is intact and convergence can be retried without re-running the role.
    The dispatcher re-queues the order for a convergence-only retry.
    """


# ---------------------------------------------------------------------------
# Convergence retry config
# ---------------------------------------------------------------------------

# Exponential backoff delays (seconds) for convergence network ops (BUG-MSO-2026-0268).
# 3 attempts: immediate, then 1 s, then 3 s before giving up.
# BUG-MSO-2026-0272: inner x outer retry budget.
# This inner loop (3 attempts) is independent of the outer convergence-retry loop in
# fleet_runner._CONVERGENCE_RETRY_CAP (also 3).  Combined with re-queue-as-PENDING
# between outer attempts, a persistently broken network will attempt each net op up to
# 3 x 3 = 9 times (with 2 full role re-executions between outer retries) before the
# order is marked CONVERGENCE_FAILED.  See fleet_runner._CONVERGENCE_RETRY_CAP.
_CONVERGENCE_RETRY_DELAYS = (0, 1, 3)


def _retry_git_network_op(cmd: list, *, cwd: str, timeout: int) -> subprocess.CompletedProcess:
    """Run a git network command with exponential-backoff retry (BUG-MSO-2026-0268).

    Attempts the command up to len(_CONVERGENCE_RETRY_DELAYS) times. Between
    attempts it sleeps for the delay specified in _CONVERGENCE_RETRY_DELAYS.
    A subprocess.TimeoutExpired on the LAST attempt is re-raised as
    ConvergenceNetworkError so callers can distinguish transient from terminal.

    Returns the CompletedProcess from the first successful attempt (returncode==0).
    Raises ConvergenceNetworkError if all attempts fail or time out.
    """
    last_exc: Optional[Exception] = None
    last_result: Optional[subprocess.CompletedProcess] = None

    for attempt, delay in enumerate(_CONVERGENCE_RETRY_DELAYS):
        if delay > 0:
            time.sleep(delay)
        try:
            result = run_hidden(cmd, capture_output=True, text=True,
                                    cwd=cwd, timeout=timeout)
            last_result = result
            if result.returncode == 0:
                return result
            # Non-zero return on a network op may be transient (temporary
            # connectivity loss) or permanent (auth failure, missing ref).
            # Re-raise after retries as ConvergenceNetworkError; the caller
            # can inspect stderr to further classify if needed.
            last_exc = None
        except subprocess.TimeoutExpired as exc:
            last_exc = exc
            last_result = None

    # All retries exhausted
    detail = ""
    if last_exc is not None:
        detail = f"timed out after {timeout}s (command: {' '.join(cmd)})"
    elif last_result is not None:
        stderr = (last_result.stderr or "").strip()
        stdout = (last_result.stdout or "").strip()
        detail = f"returncode={last_result.returncode} stderr={stderr!r} stdout={stdout!r}"
    raise ConvergenceNetworkError(
        f"Git network op failed after {len(_CONVERGENCE_RETRY_DELAYS)} attempts: {detail}"
    )


# ---------------------------------------------------------------------------
# Worktree-add retry config (BUG-MSO-2026-0345)
# ---------------------------------------------------------------------------

# Short backoff for `git worktree add` on the transient dir-collision class.
# On Windows, a just-killed crew process can hold its previous worktree dir
# open (process cwd, AV scan) for a few seconds after teardown, so the orphan
# sweep leaves the dir behind and git refuses with "fatal: '<dir>' already
# exists". PSG observed the condition clear within ONE second (2-for-2 on
# consecutive same-crew re-dispatches, VOY-PSG-2026-0358). 3 attempts:
# immediate, then 1 s, then 3 s.
_WORKTREE_ADD_RETRY_DELAYS = (0, 1, 3)


def _flatten_git_output(text: Optional[str]) -> str:
    """Collapse multi-line git output onto one line for lifecycle.log.

    BUG-MSO-2026-0345: `git worktree add` prints "Preparing worktree (...)"
    followed by the actual "fatal: ..." reason on a later line. lifecycle.log
    is a one-line-per-event format, so an embedded newline silently drops the
    fatal detail (PSG saw the message truncate after 'Preparing worktree').
    """
    return "; ".join(
        ln.strip() for ln in (text or "").strip().splitlines() if ln.strip()
    )


def _is_transient_worktree_add_failure(stderr: Optional[str]) -> bool:
    """True when a failed `git worktree add` is worth retrying (BUG-MSO-2026-0345).

    Structural failures (branch checked out elsewhere, already-registered
    path, missing refs) are excluded — retrying those cannot help and the
    callers classify them into typed exceptions instead.
    """
    s = (stderr or "").lower()
    if "already checked out" in s or "already used by worktree" in s:
        return False  # WorktreeBranchConflict — structural
    if "already registered" in s:
        return False  # caller's idempotency check handles this
    return (
        "already exists" in s          # leftover dir (Windows lock latency)
        or "permission denied" in s    # lingering NTFS handle
        or "resource busy" in s
        or "unable to create" in s
    )


def _worktree_add_with_retry(build_cmd, wt_path: Path, orphan_label: str,
                             cwd: Optional[Path] = None):
    """Run `git worktree add` with short-backoff retries (BUG-MSO-2026-0345).

    ``build_cmd`` is a zero-arg callable returning the argv list — rebuilt per
    attempt because branch existence can change between attempts (e.g. a
    partially-failed ``-b`` attempt that did create the branch).

    Between attempts the stale dir that blocked the previous attempt is
    re-swept (orphan rmtree + ``git worktree prune``), giving the Windows
    file lock time to clear.

    ``cwd`` (FTR-MSO-2026-0377) selects the product repo the worktree is added
    to / pruned from; ``None`` keeps the single-repo behaviour (dispatcher's
    own repo). ``build_cmd`` must itself target ``cwd`` for the actual add.

    Returns ``(result, failed_attempts, last_error)`` where ``result`` is the
    final CompletedProcess, ``failed_attempts`` counts attempts that failed
    before it, and ``last_error`` is the flattened stderr of the most recent
    failure ("" when the first attempt succeeded).
    """
    _git_cwd = str(cwd) if cwd else None
    result = None
    failed_attempts = 0
    last_error = ""
    for delay in _WORKTREE_ADD_RETRY_DELAYS:
        if failed_attempts:
            if delay:
                time.sleep(delay)
            if wt_path.exists() and wt_path.resolve(strict=False) not in _registered_worktrees(cwd):
                _robust_rmtree(wt_path, label=orphan_label)
            run_hidden(["git", "worktree", "prune"], capture_output=True, cwd=_git_cwd)
        result = run_hidden(build_cmd(), capture_output=True, text=True, cwd=_git_cwd)
        if result.returncode == 0:
            return result, failed_attempts, last_error
        last_error = _flatten_git_output(result.stderr)
        if not _is_transient_worktree_add_failure(result.stderr):
            return result, failed_attempts, last_error
        failed_attempts += 1
    return result, failed_attempts, last_error


def _warn_worktree_add_recovered(what: str, failed_attempts: int,
                                 last_error: str) -> None:
    """Emit a WARN lifecycle event for a self-recovered worktree add.

    BUG-MSO-2026-0345: the pre-retry behaviour surfaced this transient class
    as an error-level WORKTREE_FAIL, which reads as fatal and can page an
    operator even though the very next dispatch tick succeeded.
    """
    try:
        from maestro.core.fleet_runner import write_lifecycle_event
        write_lifecycle_event(
            "WARN",
            f"transient worktree add failure self-recovered for {what} after "
            f"{failed_attempts} failed attempt(s) — last git error: "
            f"{last_error} — retried with backoff, no operator action needed "
            f"(BUG-0345)"
        )
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _repo_root() -> Path:
    """Return the product-repo root for worktree git operations.

    Reconciliation contract (FTR-MSO-2026-0362, plan PLAN-PLN-MSO-2026-0358
    §2.1): this is the module's SINGLE product-repo derivation, and in
    embedded mode it equals ``maestro.workspace.get_product_repo()`` by
    construction — the dispatcher runs at the product-repo root, whose
    ``.mso`` parent IS the git toplevel. It deliberately derives from
    ``git rev-parse --show-toplevel`` (cwd truth) rather than the env-first
    resolver: worktree primitives operate on the repo the calling process is
    standing in, and callers (tests included) drive them from scratch repos
    that have no resolvable workspace — while ``MAESTRO_DIR`` may
    legitimately point at an isolated workspace (the pytest autouse guard,
    BUG-MSO-2026-0327). Phase 4 (plan §4.3.5) replaces the *call sites* with
    ``get_product_repo(order.targetRepo)`` and retires this helper; do not
    add new callers.
    """
    result = run_hidden(
        ["git", "rev-parse", "--show-toplevel"],
        capture_output=True, text=True
    )
    if result.returncode != 0:
        raise WorktreeError(f"Not inside a git repository: {result.stderr.strip()}")
    return Path(result.stdout.strip())


def _registered_worktrees(cwd: Optional[Path] = None) -> set[Path]:
    """Return the set of resolved paths currently registered with git worktree.

    ``cwd`` (FTR-MSO-2026-0377) selects the product repo the worktree list is
    read from — ``None`` (default) means the dispatcher's own repo, keeping the
    single-repo path byte-identical; a per-repo checkout is passed in multi-repo
    dispatch so each repo's worktrees are resolved independently.
    """
    result = run_hidden(
        ["git", "worktree", "list", "--porcelain"],
        capture_output=True, text=True,
        cwd=str(cwd) if cwd else None,
    )
    paths = set()
    for line in result.stdout.splitlines():
        if line.startswith("worktree "):
            raw = line[len("worktree "):].strip()
            # Canonicalise so comparisons are robust across path representations
            # (relative/absolute, slashes, symlinks, Windows case) — the callers
            # resolve() their side too before membership-testing (Copilot, PR #187).
            paths.add(Path(raw).resolve(strict=False))
    return paths


def _branch_exists_local(branch: str, cwd: Optional[Path] = None) -> bool:
    """Check whether ``refs/heads/<branch>`` exists in the local repo.

    ``cwd`` (FTR-MSO-2026-0377) selects the product repo; ``None`` keeps the
    single-repo behaviour (dispatcher's own repo)."""
    result = run_hidden(
        ["git", "rev-parse", "--verify", f"refs/heads/{branch}"],
        capture_output=True,
        cwd=str(cwd) if cwd else None,
    )
    return result.returncode == 0


def _branch_exists_remote(branch: str, remote: str = "origin",
                          cwd: Optional[Path] = None) -> bool:
    """Check whether ``refs/remotes/<remote>/<branch>`` exists in the local repo.

    Returns True if the remote-tracking ref is present locally. Does not call
    ``git fetch`` — use :func:`_fetch_remote_branch` first if you need to
    refresh the local view of the remote. ``cwd`` (FTR-MSO-2026-0377) selects
    the product repo; ``None`` keeps single-repo behaviour.
    """
    result = run_hidden(
        ["git", "rev-parse", "--verify", f"refs/remotes/{remote}/{branch}"],
        capture_output=True,
        cwd=str(cwd) if cwd else None,
    )
    return result.returncode == 0


def _fetch_remote_branch(branch: str, remote: str = "origin",
                         cwd: Optional[Path] = None) -> bool:
    """Fetch a single branch from *remote* into the matching remote-tracking ref.

    BUG-MSO-2026-0027: the dispatcher creates voyage branches via ``gh api``,
    which only touches the GitHub remote — the local repo has no record of
    the new ref until something fetches. Without this, ``git worktree add``
    fails because ``refs/heads/<branch>`` doesn't exist. ``cwd``
    (FTR-MSO-2026-0377) selects the product repo; ``None`` keeps single-repo
    behaviour.
    """
    result = run_hidden(
        ["git", "fetch", remote, f"{branch}:refs/remotes/{remote}/{branch}"],
        capture_output=True, text=True, timeout=30,
        cwd=str(cwd) if cwd else None,
    )
    return result.returncode == 0


# Backward-compat alias; new callers should use the explicit local/remote form.
def _branch_exists(branch: str) -> bool:
    return _branch_exists_local(branch)


# BUG-MSO-2026-0347: branch names treated as a remote default branch even when
# refs/remotes/origin/HEAD is not resolvable locally (it is only populated by
# `git clone` / `git remote set-head`, so many dispatcher checkouts lack it).
_COMMON_DEFAULT_BRANCHES = ("master", "main")


def _resolve_origin_default_branch(repo_dir=None) -> str:
    """Best-effort LOCAL resolution of origin's default branch (no network).

    Reads ``refs/remotes/origin/HEAD``; returns the bare branch name (e.g.
    ``master``) or ``""`` when the symref is absent/unreadable.
    """
    try:
        result = run_hidden(
            ["git", "symbolic-ref", "--short", "refs/remotes/origin/HEAD"],
            capture_output=True, text=True, timeout=10,
            cwd=str(repo_dir) if repo_dir else None,
        )
        if result.returncode == 0:
            ref = result.stdout.strip()
            return ref[len("origin/"):] if ref.startswith("origin/") else ref
    except Exception:
        pass
    return ""


def is_default_branch(branch: str, repo_dir=None) -> bool:
    """True when *branch* is (or is conventionally named as) the remote default
    branch — the ref the dispatcher must never auto-push (BUG-MSO-2026-0347)."""
    b = (branch or "").strip().replace("refs/heads/", "")
    if not b:
        return False
    if b in _COMMON_DEFAULT_BRANCHES:
        return True
    resolved = _resolve_origin_default_branch(repo_dir)
    return bool(resolved) and b == resolved


def _default_branch_push_opted_in() -> bool:
    """BUG-MSO-2026-0347: ``lifecycle.allowDefaultBranchPush`` in workspace.json
    (default OFF — pushing the remote default branch is opt-in)."""
    try:
        import json
        from maestro.workspace import get_workspace_dir
        cfg = json.loads(
            (get_workspace_dir() / "config" / "workspace.json").read_text(encoding="utf-8"))
        return bool((cfg.get("lifecycle") or {}).get("allowDefaultBranchPush", False))
    except Exception:
        return False


def default_branch_push_guard(branch: str, context: str, repo_dir=None) -> bool:
    """Return True when pushing *branch* to origin is permitted.

    BUG-MSO-2026-0347: on PSG, dispatcher bookkeeping (``lifecycle: advance/
    archive`` + salvage commits) was pushed straight to origin/master because a
    voyage branch resolved to the repo's default branch — bypassing the
    project's PR-only policy. Every dispatcher-side ``git push origin
    <computed-branch>`` must pass this guard: the remote default branch is
    never auto-pushed unless the operator opts in via
    ``lifecycle.allowDefaultBranchPush`` in workspace.json. Blocked pushes emit
    a WARN lifecycle event; bookkeeping stays local for the operator's sweep PR.
    """
    if not is_default_branch(branch, repo_dir):
        return True
    if _default_branch_push_opted_in():
        try:
            from maestro.core.fleet_runner import write_lifecycle_event
            write_lifecycle_event(
                "WARN",
                f"{context}: pushing remote default branch '{branch}' — permitted "
                f"by lifecycle.allowDefaultBranchPush=true (BUG-0347)")
        except Exception:
            pass
        return True
    try:
        from maestro.core.fleet_runner import write_lifecycle_event
        write_lifecycle_event(
            "WARN",
            f"{context}: push to remote default branch '{branch}' REFUSED — "
            f"lifecycle/salvage bookkeeping stays local; reconcile via a sweep "
            f"PR, point the voyage at a dedicated voyage/* branch, or set "
            f"lifecycle.allowDefaultBranchPush=true in workspace.json to opt "
            f"in (BUG-0347)")
    except Exception:
        pass
    return False


def _find_worktree_for_branch(branch: str,
                              cwd: Optional[Path] = None) -> Optional[Path]:
    """Return the worktree path where *branch* is currently checked out, or None.

    ``cwd`` (FTR-MSO-2026-0378) selects the product repo whose worktree list is
    queried; ``None`` keeps the single-repo behaviour (dispatcher's own repo).
    """
    result = run_hidden(
        ["git", "worktree", "list", "--porcelain"],
        capture_output=True, text=True,
        cwd=str(cwd) if cwd else None,
    )
    current_wt: Optional[Path] = None
    for line in result.stdout.splitlines():
        if line.startswith("worktree "):
            current_wt = Path(line[len("worktree "):].strip())
        elif line.startswith("branch ") and line.split()[-1] == f"refs/heads/{branch}":
            return current_wt
    return None


def _primary_worktree_path(cwd: Optional[Path] = None) -> Optional[Path]:
    """The PRIMARY repo checkout — first entry of `git worktree list --porcelain`.

    ``cwd`` (FTR-MSO-2026-0378) selects the product repo; ``None`` keeps the
    single-repo behaviour.
    """
    result = run_hidden(
        ["git", "worktree", "list", "--porcelain"],
        capture_output=True, text=True,
        cwd=str(cwd) if cwd else None,
    )
    for line in result.stdout.splitlines():
        if line.startswith("worktree "):
            return Path(line[len("worktree "):].strip())
    return None


def _is_primary_worktree(path, cwd: Optional[Path] = None) -> bool:
    """True when *path* is the primary repo checkout (the live workspace).

    BUG-MSO-2026-0295: convergence must NEVER run `git reset --hard` /
    `git merge` in the primary checkout — that is where the dispatcher's
    uncommitted `.mso` lifecycle state lives, and resetting it resurrects
    completed orders as PENDING (the PSG VOY-PSG-2026-0344 mechanism).

    ``cwd`` (FTR-MSO-2026-0378) selects the product repo whose primary checkout
    is compared against; ``None`` keeps the single-repo behaviour.
    """
    primary = _primary_worktree_path(cwd)
    if primary is None:
        return False
    try:
        return Path(path).resolve() == primary.resolve()
    except OSError:
        return False


def resolve_convergence_worktree(voyage_id: str, voyage_branch: str,
                                 repo_root: Optional[Path] = None,
                                 repo_name: str = ""):
    """Resolve a worktree for convergence git operations — NEVER the primary checkout.

    Returns ``(worktree_path, on_branch)``:
      - ``on_branch=True``  — the worktree has *voyage_branch* checked out;
        push with ``git push origin <branch>``.
      - ``on_branch=False`` — a DETACHED scratch worktree (the branch is
        checked out in the primary workspace checkout, which is off-limits);
        push with ``git push origin HEAD:refs/heads/<branch>``.

    BUG-MSO-2026-0295: the old fallback (`_find_worktree_for_branch`) could
    hand back the primary checkout, and the caller's `git reset --hard`
    then destroyed live dispatcher state. This resolver makes the primary
    checkout structurally unreachable from convergence code.

    FTR-MSO-2026-0378 (plan §4.3.5): *repo_root* / *repo_name* run the whole
    resolution (admin worktree prep, primary-checkout comparison, detached
    scratch worktree add) against the ORDER's product-repo checkout. Defaults
    keep the single-repo path byte-identical.

    Raises WorktreeError when no safe worktree can be produced.
    """
    try:
        return prepare_voyage_worktree(
            voyage_id, voyage_branch, repo_root=repo_root, repo_name=repo_name), True
    except WorktreeBranchConflict:
        existing = _find_worktree_for_branch(voyage_branch, cwd=repo_root)
        if existing is not None and not _is_primary_worktree(existing, cwd=repo_root):
            return existing, True

        # The voyage branch is checked out in the PRIMARY workspace checkout.
        # Use a detached scratch worktree instead of touching it.
        try:
            from maestro.core.fleet_runner import write_lifecycle_event
            write_lifecycle_event(
                "CONVERGENCE_PRIMARY_PROTECTED",
                f"'{voyage_branch}' is checked out in the primary workspace "
                f"checkout — converging via detached scratch worktree instead "
                f"of resetting live state (BUG-0295)"
            )
        except Exception:
            pass

        # BUG-MSO-2026-0306: UNIQUE path per convergence. The pre-0306 fixed
        # path (convergence-<voyage_id>) was never torn down after use, so the
        # 2nd convergence failed `git worktree add ... already exists` and the
        # role's work stranded on a salvage branch (PSG v4.7.3 regression). A
        # unique suffix makes a collision impossible even if a prior teardown
        # failed on Windows; the caller removes it after use (try/finally) and
        # _prune_orphan_convergence_worktrees() sweeps any crash-left dirs.
        # FTR-MSO-2026-0364: scratch worktrees live in the runtime worktree
        # home (.mso/worktrees/<VID>/) alongside crew/admin worktrees; the
        # legacy .mso/temp/convergence-* location is still swept by
        # _prune_orphan_convergence_worktrees for pre-relocation leftovers.
        # FTR-MSO-2026-0378: run the scratch add against the order's repo
        # checkout (repo_root) and namespace the dir per-repo so a voyage's
        # per-repo branches (identically named) never collide on one path.
        _rr = repo_root if repo_root is not None else _repo_root()
        _prune_orphan_convergence_worktrees(voyage_id, repo_root=repo_root)
        scratch_dir = worktrees_root() / voyage_id
        scratch_dir.mkdir(parents=True, exist_ok=True)
        _slug = f"-{repo_name}" if repo_name else ""
        tmp = scratch_dir / f"convergence-{voyage_id}{_slug}-{os.getpid()}-{next(_SCRATCH_SEQ)}"
        add_r = run_hidden(
            ["git", "worktree", "add", "--detach", str(tmp), voyage_branch],
            capture_output=True, text=True, cwd=str(_rr),
        )
        if add_r.returncode != 0:
            raise WorktreeError(
                f"CONVERGENCE_REFUSED_PRIMARY: '{voyage_branch}' is checked out in "
                f"the primary workspace checkout and a detached scratch worktree "
                f"could not be created: {add_r.stderr.strip()}"
            )
        return tmp, False


def _prune_orphan_convergence_worktrees(voyage_id: Optional[str] = None,
                                        repo_root: Optional[Path] = None) -> int:
    """BUG-MSO-2026-0306: remove leftover convergence scratch worktrees.

    Sweeps scratch dirs (optionally scoped to *voyage_id*) that a crashed or
    pre-0306 run left behind, so they neither accumulate nor block a fresh
    convergence. FTR-MSO-2026-0364: scratch worktrees live under
    ``.mso/worktrees/<VID>/convergence-*``; the legacy
    ``.mso/temp/convergence-*`` home is swept too for pre-relocation
    leftovers. Best-effort / fail-open. Returns the count removed.

    FTR-MSO-2026-0378: *repo_root* selects the product repo the ``git worktree``
    ops (unregister/prune) run against; ``None`` keeps the dispatcher's own
    repo (single-repo). The scratch-dir prefix stays voyage-scoped so a
    per-repo prefix (``convergence-<VID>-<repoName>-``) is still matched by the
    voyage-only ``convergence-<VID>-`` prefix.
    """
    removed = 0
    try:
        repo_root = repo_root if repo_root is not None else _repo_root()
        prefix = f"convergence-{voyage_id}-" if voyage_id else "convergence-"

        candidates = []
        temp_dir = _resolve_artefact_dir(repo_root) / "temp"
        if temp_dir.exists():
            candidates.extend(temp_dir.glob(f"{prefix}*"))
        wt_root = worktrees_root()
        if wt_root.exists():
            scopes = [wt_root / voyage_id] if voyage_id else [
                d for d in wt_root.iterdir() if d.is_dir()]
            for scope in scopes:
                if scope.is_dir():
                    candidates.extend(scope.glob(f"{prefix}*"))

        for d in candidates:
            if not d.is_dir():
                continue
            run_hidden(["git", "worktree", "remove", "--force", str(d)],
                           capture_output=True, text=True, cwd=str(repo_root))
            if d.exists():
                _robust_rmtree(d, label=f"orphan convergence worktree {d.name}")
            removed += 1
        if removed:
            run_hidden(["git", "worktree", "prune"],
                           capture_output=True, cwd=str(repo_root))
    except Exception:
        pass
    return removed


def cleanup_convergence_worktree(path, repo_root: Optional[Path] = None) -> None:
    """BUG-MSO-2026-0306: remove a scratch convergence worktree after use.

    Callers invoke this in a `finally` so a successful convergence never leaves
    a scratch worktree behind (the pre-0306 bug). Best-effort / fail-open.

    FTR-MSO-2026-0378: *repo_root* selects the product repo the ``git worktree
    remove/prune`` ops run against; ``None`` keeps single-repo behaviour.
    """
    try:
        path = Path(path)
        repo_root = repo_root if repo_root is not None else _repo_root()
        run_hidden(["git", "worktree", "remove", "--force", str(path)],
                       capture_output=True, text=True, cwd=str(repo_root))
        if path.exists():
            _robust_rmtree(path, label=f"convergence worktree {path.name}")
        run_hidden(["git", "worktree", "prune"],
                       capture_output=True, cwd=str(repo_root))
        # FTR-MSO-2026-0364: scratch worktrees live under worktrees/<VID>/ —
        # tidy the voyage dir when this was its last occupant.
        _rmdir_if_empty(path.parent)
    except Exception:
        pass


def safe_ff_primary_checkout(voyage_branch: str,
                             repo_root: Optional[Path] = None) -> bool:
    """Fast-forward a CLEAN primary checkout holding *voyage_branch* to origin.

    BUG-MSO-2026-0295: when convergence merges via the detached scratch
    worktree (the branch is held by the primary checkout), the LOCAL branch
    ref is left behind origin. Crew worktree prep resolves branches
    local-first (BUG-0253), so a stale local ref would hand dependent crews
    an old voyage tip. If the primary tree is clean, `merge --ff-only` is a
    safe catch-up (no reset, no content loss possible — ff refuses anything
    but a strict descendant). A DIRTY primary tree is left untouched: origin
    holds the truth, the next convergence merges both lineages, and we warn.

    FTR-MSO-2026-0378: *repo_root* selects the product repo whose primary
    checkout is fast-forwarded; ``None`` keeps single-repo behaviour.
    """
    wt = _find_worktree_for_branch(voyage_branch, cwd=repo_root)
    if wt is None or not _is_primary_worktree(wt, cwd=repo_root):
        return False
    # Untracked files never block an ff merge (git refuses on its own if one
    # would be overwritten) — only tracked modifications make the tree dirty.
    status_r = run_hidden(["git", "status", "--porcelain", "--untracked-files=no"],
                              capture_output=True, text=True, cwd=str(wt))
    if status_r.returncode != 0 or status_r.stdout.strip():
        try:
            from maestro.core.fleet_runner import write_lifecycle_event
            write_lifecycle_event(
                "WARN",
                f"primary checkout on '{voyage_branch}' has uncommitted changes — "
                f"local ref left behind origin after scratch-worktree convergence "
                f"(catch up manually with `git pull --ff-only`) (BUG-0295)"
            )
        except Exception:
            pass
        return False
    ff_r = run_hidden(
        ["git", "merge", "--ff-only", f"origin/{voyage_branch}"],
        capture_output=True, text=True, cwd=str(wt))
    return ff_r.returncode == 0


# Dispatcher artefact files that legitimately live git-tracked in the primary
# checkout (queue/order/voyage JSONs). Committing these before convergence keeps
# the primary tree clean so safe_ff can fast-forward (BUG-MSO-2026-0305).
_ARTEFACT_PATHSPECS = tuple(
    f"{MSO_DIR_NAME}/{d}" for d in ("queues", "orders", "voyages", "usage")
)


def commit_and_push_primary_artefacts(voyage_branch: str,
                                      convergence_timeout: int = 60,
                                      repo_root: Optional[Path] = None) -> bool:
    """BUG-MSO-2026-0305: flush the dispatcher's tracked .mso artefact writes to
    origin BEFORE convergence, so the primary checkout doesn't strand behind.

    When *voyage_branch* is checked out in the primary workspace and that tree
    has dirty TRACKED .mso artefact files (order status, voyage manifests), the
    scratch-worktree convergence (BUG-0295) would later leave the primary local
    ref behind origin (safe_ff refuses a dirty tree). Committing + pushing those
    artefacts here means the scratch convergence builds ON TOP of them and the
    primary fast-forwards cleanly afterward — topologically sound (primary
    commits X -> origin X; scratch resets to origin, merges crew -> Y, pushes;
    primary ff X->Y).

    Only commits the artefact pathspecs (never src or other files), so a crew's
    own uncommitted work elsewhere is untouched. Best-effort / fail-open: any
    error leaves the pre-0305 behaviour (safe_ff WARN) as the fallback.
    Returns True if a commit+push happened.

    FTR-MSO-2026-0366: no-op in solo/shared artefact-repo mode — dispatcher
    artefact writes are committed to the ARTEFACT repo by
    fleet_runner._commit_lifecycle_transition; the product repo's primary
    checkout has no tracked ``.mso`` artefacts to flush.

    FTR-MSO-2026-0378: *repo_root* selects the product repo whose primary
    checkout is inspected; ``None`` keeps single-repo behaviour.
    """
    if not _bookkeeping_machinery_active():
        return False
    wt = _find_worktree_for_branch(voyage_branch, cwd=repo_root)
    if wt is None or not _is_primary_worktree(wt, cwd=repo_root):
        return False
    # BUG-MSO-2026-0347: when the primary checkout sits on the remote DEFAULT
    # branch (PSG: master), this flush would push accumulated lifecycle/salvage
    # bookkeeping straight to origin/master, bypassing PR-only policy. Keep the
    # commits local (the operator's sweep PR reconciles them) unless opted in.
    if not default_branch_push_guard(
            voyage_branch, "pre-convergence artefact flush (BUG-0305)",
            repo_dir=wt):
        return False
    try:
        # Restrict to artefact pathspecs that are actually tracked — a bare
        # `git add -- <dir>` fails (exit 128) on a pathspec matching no tracked
        # files, so only pass the ones git knows about.
        present = []
        for spec in _ARTEFACT_PATHSPECS:
            ls = run_hidden(["git", "ls-files", "--", spec],
                                capture_output=True, text=True, cwd=str(wt), timeout=15)
            if (ls.stdout or "").strip():
                present.append(spec)
        if not present:
            return False
        # Anything dirty (tracked) under the present artefact pathspecs?
        status_r = run_hidden(
            ["git", "status", "--porcelain", "--untracked-files=no", "--"] + present,
            capture_output=True, text=True, cwd=str(wt), timeout=15)
        if status_r.returncode != 0 or not status_r.stdout.strip():
            return False

        add_r = run_hidden(["git", "add", "--"] + present,
                               capture_output=True, text=True, cwd=str(wt), timeout=15)
        if add_r.returncode != 0:
            return False
        commit_r = run_hidden(
            ["git",
             "-c", "user.name=Maestro Dispatcher",
             "-c", "user.email=dispatcher@maestro.local",
             "commit", "-m",
             f"lifecycle: flush dispatcher artefacts before convergence ({voyage_branch}) (BUG-0305)",
             "--"] + present,
            capture_output=True, text=True, cwd=str(wt), timeout=15)
        if commit_r.returncode != 0:
            return False  # nothing staged / commit refused — leave as-is
        # _retry_git_network_op returns only on returncode==0, else raises
        # (ConvergenceNetworkError) — caught by the outer except as fail-open.
        _retry_git_network_op(
            ["git", "push", "origin", voyage_branch],
            cwd=str(wt), timeout=2 * convergence_timeout)
        try:
            from maestro.core.fleet_runner import write_lifecycle_event
            write_lifecycle_event(
                "DISPATCH",
                f"flushed dispatcher artefacts to origin/{voyage_branch} before "
                f"convergence (primary stays in sync, BUG-0305)")
        except Exception:
            pass
        return True
    except Exception:
        return False


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def worktrees_root() -> Path:
    """Return the runtime worktree home ``.mso/worktrees/`` (FTR-MSO-2026-0364).

    Gitignored, machine-local. All Maestro-managed worktrees (crew, voyage
    admin, convergence scratch) live under ``<root>/<voyage_id>/``. Paths are
    kept shallow deliberately (Windows long-path / junction risk — plan
    PLAN-PLN-MSO-2026-0358 §6).
    """
    return _resolve_artefact_dir(_repo_root()) / "worktrees"


def _legacy_voyage_dir(voyage_id: str) -> Path:
    """Pre-FTR-0364 voyage dir that used to host worktrees next to durable JSON."""
    return _resolve_artefact_dir(_repo_root()) / "voyages" / "active" / voyage_id


def legacy_worktree_path_for(voyage_id: str) -> Path:
    """Pre-FTR-0364 voyage admin worktree location (no I/O)."""
    return _legacy_voyage_dir(voyage_id) / ".worktree"


def legacy_crew_worktree_path_for(voyage_id: str, crew_num: int) -> Path:
    """Pre-FTR-0364 per-crew worktree location (no I/O)."""
    return _legacy_voyage_dir(voyage_id) / f".worktree-crew{crew_num}"


def worktree_path_for(voyage_id: str, repo_name: str = "") -> Path:
    """Return the voyage admin worktree path.

    This worktree is used exclusively for convergence merges. Crew work
    happens in crew_worktree_path_for() worktrees (BUG-MSO-2026-0240).

    FTR-MSO-2026-0364: canonical home is ``.mso/worktrees/<voyage_id>/admin``.
    Legacy-aware: while a pre-relocation worktree dir still exists at
    ``voyages/active/<voyage_id>/.worktree`` (an in-flight voyage dispatched
    by an older version), that path is returned so running work is never
    stranded; the legacy dir is pruned at voyage completion.

    FTR-MSO-2026-0378 (multi-repo convergence, plan §4.3-4.4): a voyage spans
    N product repos, each with its own branch of the SAME name
    (``voyage/<VID>-<slug>``). Two same-named branches cannot share one admin
    worktree path, so *repo_name* gives each repo its own admin worktree at
    ``.mso/worktrees/<voyage_id>/admin-<repoName>``. The default ``repo_name=""``
    keeps the single-repo path (and legacy-home compat) byte-identical.
    """
    if repo_name:
        return worktrees_root() / voyage_id / f"admin-{repo_name}"
    legacy = legacy_worktree_path_for(voyage_id)
    if legacy.exists():
        return legacy
    return worktrees_root() / voyage_id / "admin"


def crew_worktree_path_for(voyage_id: str, crew_num: int,
                           repo_name: str = "") -> Path:
    """Return the per-crew worktree path for (voyage_id, crew_num).

    FTR-MSO-2026-0364: canonical home is ``.mso/worktrees/<voyage_id>/crew<N>``;
    a still-existing legacy ``voyages/active/<VID>/.worktree-crew<N>`` dir wins
    while it exists (in-flight voyage compat — see worktree_path_for).

    FTR-MSO-2026-0377 (multi-repo, plan §4.3.3): when *repo_name* is given, the
    worktree lands at ``.mso/worktrees/<voyage_id>/crew<N>-<repoName>`` so an
    order targeting each product repo gets its own checkout. The legacy
    single-repo home is bypassed for per-repo worktrees (a new-feature path with
    no legacy dirs). The default ``repo_name=""`` keeps the single-repo path
    byte-identical.
    """
    if repo_name:
        return worktrees_root() / voyage_id / f"crew{crew_num}-{repo_name}"
    legacy = legacy_crew_worktree_path_for(voyage_id, crew_num)
    if legacy.exists():
        return legacy
    return worktrees_root() / voyage_id / f"crew{crew_num}"


def _rmdir_if_empty(path: Path) -> None:
    """Remove *path* if it is an empty dir (used to tidy ``worktrees/<VID>/``
    after the last worktree of a voyage is cleaned up). Best-effort."""
    try:
        if path.is_dir() and not any(path.iterdir()):
            path.rmdir()
    except OSError:
        pass


def crew_branch_name(voyage_id: str, crew_num: int) -> str:
    """Return the per-crew git branch name, e.g. ``crew/VOY-MSO-2026-0056-1``."""
    return f"crew/{voyage_id}-{crew_num}"


def commit_crew_worktree_if_dirty(voyage_id: str, crew_num: int,
                                  order_id: Optional[str] = None,
                                  repo_name: str = "") -> bool:
    """BUG-MSO-2026-0284: auto-commit a crew's uncommitted worktree changes.

    Convergence (``merge_crew_branch_into_voyage``) merges the crew BRANCH and
    assumes the crew committed its work. A crew that writes artefacts (e.g. a PLN
    plan) but never runs ``git commit`` would otherwise have its work SILENTLY
    LOST: the dispatcher pre-creates the crew branch, so an empty crew branch
    merges as a no-op and the order advances "success" with nothing persisted.
    (The legacy ``verify_and_push_crew_work`` was meant to cover this but is dead
    code wired to the pre-worktree ``crews/N/repo`` path — see BUG-0284.)

    Call this in finalize BEFORE convergence. It runs as dispatcher code (not via
    Claude's Bash tool), so the branch_guard pretool hook does NOT intercept it —
    hence the explicit branch-safety check: only commit when HEAD is the crew's
    OWN branch, never some other ref (mirrors BUG-MSO-2026-0241's intent).

    Returns True iff a commit was created. Fail-safe: returns False on a clean
    tree, a missing worktree, an unexpected HEAD, or ANY git error — this is a
    best-effort safety net and must never break finalization.

    FTR-MSO-2026-0378: *repo_name* resolves the per-repo crew worktree
    (``crew<N>-<repoName>``) in multi-repo dispatch; git ops run in that
    worktree (its own repo), so no repo_root is needed. ``""`` keeps the
    single-repo path byte-identical.
    """
    wt = crew_worktree_path_for(voyage_id, crew_num, repo_name)
    if not wt.exists():
        return False
    expected_branch = crew_branch_name(voyage_id, crew_num)

    def _git(args, timeout: int = 30) -> subprocess.CompletedProcess:
        return run_hidden(["git", *args], capture_output=True, text=True,
                              cwd=str(wt), timeout=timeout)

    try:
        status = _git(["status", "--porcelain"])
        if status.returncode != 0 or not status.stdout.strip():
            return False  # clean (or unreadable) — nothing to commit

        head = _git(["rev-parse", "--abbrev-ref", "HEAD"])
        actual = head.stdout.strip() if head.returncode == 0 else ""
        if actual != expected_branch:
            # Safety: never auto-commit onto an unexpected branch (e.g. main /
            # the voyage branch). Caller may log the skip via the return value.
            return False

        if _git(["add", "-A"]).returncode != 0:
            return False
        msg = (f"[fleet] auto-commit uncommitted crew artefacts for "
               f"{order_id or voyage_id} (Crew {crew_num}, BUG-MSO-2026-0284)")
        # Make the commit self-sufficient in headless/dispatcher environments:
        # never sign (no key/agent in automated runs) and supply a fallback
        # committer identity ONLY when none is configured — otherwise the commit
        # fails silently and the safety net is defeated (Copilot review of PR #139).
        commit_cfg = ["-c", "commit.gpgsign=false"]
        if not _git(["config", "user.email"]).stdout.strip():
            commit_cfg += ["-c", "user.email=fleet@maestro.local",
                           "-c", "user.name=Maestro Fleet"]
        return _git([*commit_cfg, "commit", "-m", msg]).returncode == 0
    except Exception:
        return False


def prepare_voyage_worktree(voyage_id: str, voyage_branch: str,
                            repo_root: Optional[Path] = None,
                            repo_name: str = "") -> Path:
    """Create (or reuse) the git worktree for a voyage.

    Idempotent: if the worktree already exists and is registered, returns its path.
    Handles orphaned dirs from crashed PREPARING state by removing and recreating.

    FTR-MSO-2026-0378 (multi-repo convergence, plan §4.3.5): *repo_root* pins the
    product-repo checkout every git op runs against (``cwd``) and *repo_name*
    suffixes the admin worktree dir so a voyage's per-repo branches (all named
    identically) each get their own admin worktree. The defaults (``None`` /
    ``""``) leave single-repo behaviour byte-identical.

    Raises:
        WorktreeBranchConflict: branch is checked out in another worktree.
        WorktreeMissingBranch: branch does not exist.
        WorktreeError: git worktree add failed for another reason.
    """
    with _prepare_lock:
        worktree_path = worktree_path_for(voyage_id, repo_name)
        registered = _registered_worktrees(repo_root)

        # Happy path: already ready
        if worktree_path.exists() and worktree_path in registered:
            return worktree_path

        # Orphaned dir (PREPARING crash): remove and recreate
        if worktree_path.exists() and worktree_path not in registered:
            _robust_rmtree(worktree_path, label=f"worktree orphan {voyage_id}")
            # FTR-MSO-2026-0364: a removed LEGACY orphan must not be recreated
            # in the legacy home — re-resolve so recreation lands under
            # .mso/worktrees/ (new voyages/dispatches always use the new home).
            worktree_path = worktree_path_for(voyage_id, repo_name)

        # BUG-MSO-2026-0027: the dispatcher creates voyage branches via
        # ``gh api`` (remote-only). Resolve in three tiers:
        #   1. Local branch ref present → standard ``git worktree add <path> <branch>``.
        #   2. Remote-tracking ref already present → fetch is unnecessary; create
        #      the local branch via ``git worktree add -b <branch> <path> origin/<branch>``.
        #   3. Neither present → ``git fetch`` the specific branch from origin
        #      and retry the tracking-branch worktree add.
        # Fail loudly with WorktreeMissingBranch only if all three fail.
        local_branch = _branch_exists_local(voyage_branch, repo_root)
        if not local_branch:
            if not _branch_exists_remote(voyage_branch, cwd=repo_root):
                _fetch_remote_branch(voyage_branch, cwd=repo_root)
            if not _branch_exists_remote(voyage_branch, cwd=repo_root):
                raise WorktreeMissingBranch(
                    f"Branch '{voyage_branch}' does not exist locally or on origin. "
                    "Create it before calling prepare_voyage_worktree()."
                )

        worktree_path.parent.mkdir(parents=True, exist_ok=True)

        def _build_cmd() -> list:
            if _branch_exists_local(voyage_branch, repo_root):
                return ["git", "worktree", "add", str(worktree_path), voyage_branch]
            # Create local branch tracking origin/<branch> in the same step.
            return [
                "git", "worktree", "add",
                "-b", voyage_branch,
                str(worktree_path),
                f"origin/{voyage_branch}",
            ]

        # BUG-MSO-2026-0345: retry with short backoff — a leftover dir a
        # Windows file lock kept the orphan sweep from removing clears within
        # seconds; don't surface a transient blip as WORKTREE_FAIL.
        result, failed_attempts, last_error = _worktree_add_with_retry(
            _build_cmd, worktree_path, f"worktree orphan {voyage_id}", cwd=repo_root)

        if result.returncode == 0:
            if failed_attempts:
                _warn_worktree_add_recovered(
                    f"voyage worktree '{voyage_branch}' ({voyage_id})",
                    failed_attempts, last_error)
            return worktree_path

        stderr = _flatten_git_output(result.stderr)

        if "already checked out" in stderr or "already used by worktree" in stderr:
            raise WorktreeBranchConflict(
                f"Branch '{voyage_branch}' is already checked out in another worktree. "
                f"git error: {stderr}"
            )

        if "No space left" in stderr or "disk full" in stderr.lower():
            raise WorktreeError(f"Disk full while creating worktree: {stderr}")

        # Already registered (e.g. path comparison miss in concurrent scenario)
        if "already registered" in stderr and worktree_path.exists():
            return worktree_path

        raise WorktreeError(f"git worktree add failed: {stderr}")


def prepare_crew_worktree(voyage_id: str, crew_num: int, voyage_branch: str,
                          repo_root: Optional[Path] = None,
                          repo_name: str = "") -> Path:
    """Create (or reuse) an isolated per-crew git worktree on a per-crew branch.

    Each crew of the same voyage gets its own worktree at
    .mso/worktrees/<voyage_id>/crew<crew_num> on branch
    crew/<voyage_id>-<crew_num>, branched from voyage_branch (a legacy
    voyages/active/<voyage_id>/.worktree-crew<crew_num> worktree is reused
    while it exists — FTR-MSO-2026-0364).

    On re-dispatch (crew timed out and was requeued): if the crew branch already
    exists locally, the worktree is recreated on that same branch so the crew
    can continue from where it left off.

    The MAESTRO_SPRINT_BRANCH injected into the crew process must be the crew
    branch name (from crew_branch_name()) so the branch guard allows mutations
    on the crew branch rather than the voyage branch.

    FTR-MSO-2026-0377 (multi-repo dispatch, plan §4.3): *repo_root* pins the
    product-repo checkout the worktree + branch operations run against (git
    ``cwd``), and *repo_name* suffixes the worktree dir (``crew<N>-<repoName>``)
    so one order per product repo gets an isolated checkout. The defaults
    (``None`` / ``""``) leave the single-repo behaviour byte-identical — every
    git op runs in the dispatcher's own repo and the worktree keeps its legacy
    path.

    Raises:
        WorktreeMissingBranch: voyage_branch does not exist locally or on origin.
        WorktreeBranchConflict: crew branch already checked out in another worktree.
        WorktreeError: git worktree add failed for another reason.
    """
    with _prepare_lock:
        wt_path = crew_worktree_path_for(voyage_id, crew_num, repo_name)
        c_branch = crew_branch_name(voyage_id, crew_num)
        registered = _registered_worktrees(repo_root)

        # Happy path: already ready (idempotent on re-call)
        if wt_path.exists() and wt_path in registered:
            return wt_path

        # Orphaned dir (PREPARING crash): remove and recreate
        if wt_path.exists() and wt_path not in registered:
            _robust_rmtree(wt_path, label=f"crew worktree orphan {voyage_id}-{crew_num}")
            # FTR-MSO-2026-0364: re-resolve after removing a LEGACY orphan so
            # recreation lands under .mso/worktrees/, never the legacy home.
            wt_path = crew_worktree_path_for(voyage_id, crew_num, repo_name)

        # Resolve the voyage branch start-point using the same three-tier strategy
        # as prepare_voyage_worktree (BUG-MSO-2026-0027).
        local_voy = _branch_exists_local(voyage_branch, repo_root)
        if not local_voy:
            if not _branch_exists_remote(voyage_branch, cwd=repo_root):
                _fetch_remote_branch(voyage_branch, cwd=repo_root)
            if not _branch_exists_remote(voyage_branch, cwd=repo_root):
                raise WorktreeMissingBranch(
                    f"Voyage branch '{voyage_branch}' does not exist locally or on origin."
                )
        start_point = voyage_branch if local_voy else f"origin/{voyage_branch}"

        wt_path.parent.mkdir(parents=True, exist_ok=True)

        def _build_cmd() -> list:
            # Re-dispatch: crew branch already exists — reuse it (don't re-branch
            # from voyage tip). Re-checked per retry attempt (BUG-MSO-2026-0345).
            if _branch_exists_local(c_branch, repo_root):
                return ["git", "worktree", "add", str(wt_path), c_branch]
            # Fresh crew: create crew branch from the current voyage branch tip
            return ["git", "worktree", "add", "-b", c_branch, str(wt_path), start_point]

        # BUG-MSO-2026-0345: same-crew re-dispatch can hit "fatal:
        # '.worktree-crew<N>' already exists" — Windows holds the just-killed
        # crew's dir (process cwd / AV handle) so the orphan sweep above left
        # it behind. The lock clears within seconds (PSG: the next dispatch
        # tick ONE second later succeeded, 2-for-2). Retry with short backoff,
        # re-sweeping between attempts, before surfacing WORKTREE_FAIL.
        result, failed_attempts, last_error = _worktree_add_with_retry(
            _build_cmd, wt_path, f"crew worktree orphan {voyage_id}-{crew_num}",
            cwd=repo_root)

        if result.returncode == 0:
            if failed_attempts:
                _warn_worktree_add_recovered(
                    f"crew {crew_num} worktree '{c_branch}' ({voyage_id})",
                    failed_attempts, last_error)
            return wt_path

        stderr = _flatten_git_output(result.stderr)

        if "already checked out" in stderr or "already used by worktree" in stderr:
            raise WorktreeBranchConflict(
                f"Crew branch '{c_branch}' is already checked out in another worktree. "
                f"git error: {stderr}"
            )

        if "already registered" in stderr and wt_path.exists():
            return wt_path

        if "No space left" in stderr or "disk full" in stderr.lower():
            raise WorktreeError(f"Disk full while creating crew worktree: {stderr}")

        raise WorktreeError(f"git worktree add failed for crew {crew_num}: {stderr}")


def merge_crew_branch_into_voyage(voyage_id: str, crew_num: int, voyage_branch: str,
                                  order_id: Optional[str] = None,
                                  convergence_timeout: int = 60,
                                  repo_root: Optional[Path] = None,
                                  repo_name: str = "") -> bool:
    """Merge a completed crew's branch into the voyage branch (convergence step).

    Uses the voyage admin worktree (worktrees/<VID>/admin) as a scratch pad:
      1. Sync to origin/<voyage_branch> (reset --hard to handle any prior failed merge)
      2. Fetch origin/<crew_branch>
      3. Merge --no-ff to preserve crew history
      4. Push to origin/<voyage_branch>

    The _merge_lock serializes concurrent convergence merges so two crews
    finishing simultaneously don't produce a push race on the same branch.

    `order_id` (BUG-MSO-2026-0244) is woven into the convergence commit message so
    `git log` on the voyage branch reflects the order actually being merged rather
    than a hardcoded bug id.

    `convergence_timeout` (BUG-MSO-2026-0268) is the per-op timeout in seconds for
    git network operations (voyage fetch, crew fetch, voyage push). Each op is retried
    with exponential backoff before raising ConvergenceNetworkError. Default: 60 s.

    FTR-MSO-2026-0378 (multi-repo convergence, plan §4.3.5): *repo_root* pins the
    ORDER's product-repo checkout that the admin/scratch worktree, primary-checkout
    protection, and default-branch guard all run against; *repo_name* namespaces
    the admin worktree so a voyage's per-repo branches (identically named) don't
    collide. The defaults (``None`` / ``""``) leave single-repo convergence
    byte-identical. The crew branch's local ref lives in the SAME repo's shared
    ref store as the admin worktree, so the local-first crew-branch resolution is
    unchanged — it just resolves in the right repo now.

    Returns True on clean merge+push.
    Raises ConvergenceNetworkError on transient network/timeout failures (retryable).
    Raises WorktreeError on merge conflict or push failure. On a merge conflict the
    error message lists the conflicting files (BUG-MSO-2026-0244) so finalization can
    record them for recovery.
    """
    c_branch = crew_branch_name(voyage_id, crew_num)

    with _merge_lock:
        # BUG-MSO-2026-0347: convergence ends in `git push origin <voyage_branch>`.
        # If the voyage branch resolved to the remote DEFAULT branch, that push
        # would land dispatcher bookkeeping (and crew work) directly on e.g.
        # origin/master, bypassing PR-only policy. Refuse up front — the caller's
        # failure handling preserves the crew's work on a salvage branch.
        if not default_branch_push_guard(
                voyage_branch, f"convergence of {c_branch}", repo_dir=repo_root):
            raise WorktreeError(
                f"Convergence of '{c_branch}' refused: voyage branch "
                f"'{voyage_branch}' is the remote default branch — Maestro never "
                f"auto-pushes the default branch (BUG-MSO-2026-0347). Point the "
                f"voyage at a dedicated voyage/* branch, or set "
                f"lifecycle.allowDefaultBranchPush=true in workspace.json to opt in."
            )
        # BUG-MSO-2026-0305: if the voyage branch is checked out in the primary
        # workspace with dirty tracked .mso artefacts, flush them to origin first
        # so this convergence builds on top of them and the primary fast-forwards
        # cleanly afterward (instead of being left behind origin).
        try:
            commit_and_push_primary_artefacts(
                voyage_branch, convergence_timeout, repo_root=repo_root)
        except Exception:
            pass
        # Resolve a worktree on the voyage branch for convergence merges.
        # Preference: voyage admin worktree; fall back to another
        # non-primary checkout of the branch. BUG-MSO-2026-0295: NEVER the
        # primary workspace checkout — resetting it destroys live dispatcher
        # state. When the branch is checked out in the primary tree, a
        # detached scratch worktree is used (on_branch=False → push HEAD:ref).
        try:
            admin_wt, on_branch = resolve_convergence_worktree(
                voyage_id, voyage_branch, repo_root=repo_root, repo_name=repo_name)
        except WorktreeError:
            raise
        except Exception as exc:
            raise WorktreeError(
                f"Cannot prepare voyage admin worktree for convergence: {exc}"
            ) from exc

        def _run(cmd: list, *, timeout: int = 60) -> subprocess.CompletedProcess:
            return run_hidden(cmd, capture_output=True, text=True,
                                  cwd=str(admin_wt), timeout=timeout)

        def _run_net(cmd: list, *, timeout: Optional[int] = None) -> subprocess.CompletedProcess:
            """Network op with retry/backoff; raises ConvergenceNetworkError on failure."""
            return _retry_git_network_op(cmd, cwd=str(admin_wt),
                                         timeout=timeout or convergence_timeout)

        def _has_ref(ref: str) -> bool:
            return _run(["git", "rev-parse", "--verify", "--quiet", ref]).returncode == 0

        _scratch_wt = admin_wt if not on_branch else None
        try:
            # Sync origin/<voyage_branch> so the admin worktree has the latest voyage
            # state to merge onto. BUG-MSO-2026-0268: use retry helper (was single-shot,
            # ignoring returncode). ConvergenceNetworkError propagates to the dispatcher
            # as a RETRYABLE failure rather than terminal CONVERGENCE_FAILED.
            _run_net(["git", "fetch", "origin",
                      f"{voyage_branch}:refs/remotes/origin/{voyage_branch}"])

            # BUG-MSO-2026-0253: resolve the crew-branch merge target LOCAL-first.
            # In normal dispatch the crew commits to its branch inside a per-crew worktree
            # and never pushes it to origin; because all worktrees of this repo share one
            # ref store, that branch is visible here as a local ref. The old code merged
            # origin/<c_branch> unconditionally, which failed with "not something we can
            # merge" and stranded EVERY successful build whose crew branch was unpushed
            # (the existing test masked this by manually pushing the crew branch). Prefer
            # the local ref; fall back to origin only for the rare pre-pushed case; raise
            # a clear REF_MISSING error if neither exists.
            if _has_ref(f"refs/heads/{c_branch}"):
                merge_target = c_branch
            else:
                # BUG-MSO-2026-0268: use retry helper for crew-branch fetch too.
                # Raises ConvergenceNetworkError on timeout/transient; swallow and
                # fall through to REF_MISSING check only on "couldn't find remote ref".
                try:
                    fetch_r = _run_net(["git", "fetch", "origin",
                                        f"{c_branch}:refs/remotes/origin/{c_branch}"])
                except ConvergenceNetworkError as _net_exc:
                    # Distinguish "ref genuinely absent" (REF_MISSING) from transient
                    # network failure. _run_net only raises if returncode != 0 on all
                    # retries or if every attempt timed out. Check the last result's
                    # output for the canonical "couldn't find remote ref" marker.
                    # BUG-MSO-2026-0272: match only specific git phrases for a genuinely
                    # missing ref.  The bare substring 'remote ref' is too broad — it
                    # appears in timeout/command echoes and many transient error messages
                    # (auth failures, DNS issues, 5xx) and would misclassify them as
                    # REF_MISSING (terminal) instead of retryable.
                    _net_msg = str(_net_exc).lower()
                    _is_ref_missing = (
                        "couldn't find remote ref" in _net_msg
                        or "remote ref does not exist" in _net_msg
                        or "unknown revision" in _net_msg
                        or bool(re.search(r"refspec .* does not match any", _net_msg))
                    )
                    if _is_ref_missing:
                        raise WorktreeError(
                            f"Convergence target missing: crew branch '{c_branch}' was not "
                            f"found locally or on origin — the crew's work cannot be located "
                            f"(REF_MISSING). This usually means the crew produced no commit."
                        )
                    raise  # propagate as ConvergenceNetworkError (retryable)
                if _has_ref(f"refs/remotes/origin/{c_branch}"):
                    merge_target = f"origin/{c_branch}"
                else:
                    raise WorktreeError(
                        f"Convergence target missing: crew branch '{c_branch}' was not "
                        f"found locally or on origin — the crew's work cannot be located "
                        f"(REF_MISSING). This usually means the crew produced no commit."
                    )

            # Sync admin worktree to latest origin/voyage_branch (handles prior failed pushes)
            reset_r = _run(["git", "reset", "--hard", f"origin/{voyage_branch}"])
            if reset_r.returncode != 0:
                raise WorktreeError(
                    f"git reset --hard origin/{voyage_branch} failed: {reset_r.stderr.strip()}"
                )

            # BUG-MSO-2026-0343: reset --hard leaves UNTRACKED files behind —
            # telemetry a prior convergence attempt wrote into this worktree
            # (e.g. .mso/usage/orders/<order>.json) would make the merge refuse
            # with "untracked working tree files would be overwritten by merge"
            # and strand the order CONVERGENCE_FAILED. Clean bookkeeping/
            # telemetry leftovers before merging; branch state is authoritative.
            _swept = _clean_untracked_bookkeeping(_run)
            if _swept:
                try:
                    from maestro.core.fleet_runner import write_lifecycle_event
                    write_lifecycle_event(
                        "CONVERGENCE_UNTRACKED_CLEANED",
                        f"convergence of {c_branch}: removed untracked bookkeeping/"
                        f"telemetry leftover(s) from the voyage worktree before "
                        f"merge: {', '.join(_swept)} — BUG-0343"
                    )
                except Exception:
                    pass

            # Merge crew branch; --no-ff keeps crew history readable.
            # BUG-MSO-2026-0244: reference the order actually being merged, not a hardcoded bug id.
            _ref = order_id or c_branch
            merge_r = _run([
                "git", "merge", "--no-ff", merge_target,
                "-m",
                f"convergence: merge crew {crew_num} ({c_branch}) into {voyage_branch} ({_ref})",
            ])
            if merge_r.returncode != 0:
                # BUG-MSO-2026-0244: capture the conflicting files BEFORE aborting (abort
                # clears the conflicted index). Conflict detail lands on git's stdout, not
                # stderr, so include both streams in the raised error.
                conflicts_r = _run(["git", "diff", "--name-only", "--diff-filter=U"])
                conflict_files = [f for f in conflicts_r.stdout.splitlines() if f.strip()]
                _detail = (merge_r.stdout.strip() + " " + merge_r.stderr.strip()).strip()

                # BUG-MSO-2026-0308 (PSG v4.7.4): a conflict confined to dispatcher
                # CONTROL-PLANE bookkeeping (.mso/queues|orders|voyages|state|usage)
                # is NOT a real failure — the voyage side is authoritative for those
                # files (BUG-0305 flushed the dispatcher's current order JSON to
                # origin/voyage; the crew branch only carries a STALE copy). The 3rd
                # version of this class (progress.md in 4.7.2, order JSON in 4.7.4).
                # BUG-MSO-2026-0342 (PSG v5.0.3) extends the class to per-crew
                # TELEMETRY (.mso/crews/, crew authoritative). Auto-resolve and
                # COMPLETE the merge so the crew's SOURCE changes still land; only
                # genuine source conflicts escalate.
                _status, _resolved = _autoresolve_bookkeeping_conflicts(
                    _run, conflict_files)
                if _status == "resolved":
                    try:
                        from maestro.core.fleet_runner import write_lifecycle_event
                        write_lifecycle_event(
                            "CONVERGENCE_BOOKKEEPING_AUTORESOLVED",
                            f"convergence of {c_branch} auto-resolved bookkeeping/"
                            f"telemetry conflict(s): {', '.join(_resolved)} — "
                            f"control-plane kept the voyage (dispatcher) copy, crew "
                            f"telemetry kept the crew copy — BUG-0308/BUG-0342"
                        )
                    except Exception:
                        pass
                    # fall through to the push step below (merge completed)
                elif _status == "commit_failed":
                    _run(["git", "merge", "--abort"])
                    raise WorktreeError(
                        f"Merge of {c_branch} into {voyage_branch}: bookkeeping "
                        f"auto-resolve failed to commit. git: "
                        f"{_resolved[0] if _resolved else ''}"
                    )
                else:
                    _run(["git", "merge", "--abort"])
                    # BUG-MSO-2026-0343: with no index conflicts, the failure is
                    # usually git refusing to start because UNTRACKED working-tree
                    # files would be overwritten. Name the actual blocking paths
                    # (parsed from git's own output) instead of "unknown".
                    if not conflict_files:
                        _untracked = _parse_untracked_overwrite_paths(_detail)
                        if _untracked:
                            raise WorktreeError(
                                f"Merge of {c_branch} into {voyage_branch} blocked by "
                                f"untracked files in the voyage worktree: "
                                f"{', '.join(_untracked)}. Remove them (or re-dispatch — "
                                f"convergence now cleans .mso bookkeeping leftovers "
                                f"automatically) and retry. git: {_detail}"
                            )
                    # BUG-MSO-2026-0342: escalate with ONLY the genuine source
                    # conflicts — bookkeeping/telemetry paths are noise and must
                    # not be blamed in AUTO_SERIALIZE requeue messages.
                    report_files = _resolved or conflict_files
                    _files = ", ".join(report_files) if report_files else "unknown"
                    if conflict_files:
                        # FTR-MSO-2026-0267: real SOURCE content/add-add conflict — raise
                        # typed exception so the dispatcher can auto-serialize the loser.
                        raise WorktreeContentConflict(
                            f"Merge of {c_branch} into {voyage_branch} failed (content conflict). "
                            f"Conflicting files: {_files}. git: {_detail}",
                            conflict_files=report_files,
                        )
                    raise WorktreeError(
                        f"Merge of {c_branch} into {voyage_branch} failed (conflict). "
                        f"Conflicting files: {_files}. git: {_detail}"
                    )

            # Push merged voyage branch. BUG-MSO-2026-0268: use retry helper.
            # BUG-MSO-2026-0272: pushes upload pack data and need a longer ceiling than
            # fetches; use 2x convergence_timeout to restore pre-PR-122 behaviour.
            # ConvergenceNetworkError propagates to dispatcher as RETRYABLE.
            # BUG-MSO-2026-0295: a detached scratch worktree (branch held by the
            # primary checkout) pushes its merged HEAD to the branch ref directly,
            # then fast-forwards the primary checkout if (and only if) it is clean.
            push_ref = voyage_branch if on_branch else f"HEAD:refs/heads/{voyage_branch}"
            _run_net(["git", "push", "origin", push_ref],
                     timeout=2 * convergence_timeout)
            if not on_branch:
                _run(["git", "fetch", "origin",
                      f"{voyage_branch}:refs/remotes/origin/{voyage_branch}"])
                safe_ff_primary_checkout(voyage_branch, repo_root=repo_root)

            return True
        finally:
            # BUG-MSO-2026-0306: always tear down the scratch worktree so the
            # NEXT convergence (next role) does not collide with a leftover dir.
            if _scratch_wt is not None:
                cleanup_convergence_worktree(_scratch_wt, repo_root=repo_root)


def cleanup_crew_worktree(voyage_id: str, crew_num: int,
                          repo_root: Optional[Path] = None,
                          repo_name: str = "") -> bool:
    """Remove the per-crew worktree (and optionally its crew branch).

    FTR-MSO-2026-0364: removes the worktree from BOTH homes (canonical
    ``.mso/worktrees/<VID>/crew<N>`` and legacy
    ``voyages/active/<VID>/.worktree-crew<N>``) so a relocation transition
    never strands a legacy dir.

    FTR-MSO-2026-0378: *repo_root* pins the product repo the ``git worktree``
    / branch ops run against, and *repo_name* resolves the per-repo crew
    worktree (``crew<N>-<repoName>``). Defaults keep single-repo behaviour
    byte-identical.

    Returns True on clean removal, False if the worktree didn't exist.
    """
    _gc = str(repo_root) if repo_root else None
    c_branch = crew_branch_name(voyage_id, crew_num)
    _per_repo = [worktrees_root() / voyage_id / f"crew{crew_num}-{repo_name}"] if repo_name else []
    candidates = [
        p for p in (
            *_per_repo,
            legacy_crew_worktree_path_for(voyage_id, crew_num),
            worktrees_root() / voyage_id / f"crew{crew_num}",
        ) if p.exists()
    ]

    if not candidates:
        run_hidden(["git", "worktree", "prune"], capture_output=True, cwd=_gc)
        return False

    removed = True
    for wt_path in candidates:
        result = run_hidden(
            ["git", "worktree", "remove", "--force", str(wt_path)],
            capture_output=True, text=True, cwd=_gc,
        )
        if result.returncode != 0:
            removed = _robust_rmtree(
                wt_path, label=f"crew worktree cleanup {voyage_id}-{crew_num}") and removed
            run_hidden(["git", "worktree", "prune"], capture_output=True, cwd=_gc)
        elif wt_path.exists():
            _robust_rmtree(wt_path, label=f"crew worktree cleanup {voyage_id}-{crew_num}")
    _rmdir_if_empty(worktrees_root() / voyage_id)

    # Delete the ephemeral crew branch (it has been merged; keep remote clean).
    # `git branch -d` is the SAFE delete: it refuses to drop a branch whose commits
    # are not reachable from its upstream/HEAD. So if convergence failed (branch is
    # unmerged) this is a no-op and the stranded work survives — see
    # preserve_failed_crew_branch() for the recovery-preserving path.
    if _branch_exists_local(c_branch, repo_root):
        run_hidden(
            ["git", "branch", "-d", c_branch],
            capture_output=True, cwd=_gc,
        )

    # BUG-MSO-2026-0249: also delete the REMOTE crew branch. The branch name is
    # deterministic per (voyage, crew_num), so a leftover origin/crew/<voyage>-<N>
    # would be re-fetched/merged when the same slot is reused for a later order,
    # leaking the prior order's work onto the new crew branch. Best-effort + only
    # when an 'origin' remote exists; never fail cleanup over it.
    _delete_remote_crew_branch(c_branch, repo_root)

    return removed


def _delete_remote_crew_branch(c_branch: str,
                               repo_root: Optional[Path] = None) -> None:
    """Best-effort delete of origin/<c_branch> so a reused crew slot can't merge it
    (BUG-MSO-2026-0249). Silent no-op when there's no origin or the ref is gone.

    FTR-MSO-2026-0378: *repo_root* selects the product repo; ``None`` keeps
    single-repo behaviour."""
    _gc = str(repo_root) if repo_root else None
    try:
        has_origin = run_hidden(
            ["git", "remote", "get-url", "origin"], capture_output=True, text=True,
            cwd=_gc,
        ).returncode == 0
        if not has_origin:
            return
        # Check the REAL remote state, not the local remote-tracking ref. A crew
        # typically pushes its branch without the dispatcher's main repo ever
        # fetching it, so refs/remotes/origin/<branch> may not exist locally even
        # though the branch is live on origin (Copilot PR #110). ls-remote queries
        # origin directly.
        ls = run_hidden(
            ["git", "ls-remote", "--heads", "origin", c_branch],
            capture_output=True, text=True, timeout=60, cwd=_gc,
        )
        if ls.returncode != 0 or not ls.stdout.strip():
            return  # branch not present on the remote
        run_hidden(
            ["git", "push", "origin", "--delete", c_branch],
            capture_output=True, text=True, timeout=60, cwd=_gc,
        )
    except Exception:
        pass


def preserve_failed_crew_branch(voyage_id: str, crew_num: int,
                                order_id: Optional[str] = None,
                                repo_root: Optional[Path] = None,
                                repo_name: str = "") -> Optional[dict]:
    """Preserve a crew branch whose convergence merge FAILED, and free its slot.

    BUG-MSO-2026-0244 / BUG-MSO-2026-0243. When merge_crew_branch_into_voyage()
    raises, the crew's work is stranded on crew/<voyage>-<N>. We must:
      1. Record the stranded commit SHA so it can be cherry-picked during recovery
         even after the crew slot is reused.
      2. Remove the crew worktree dir and RENAME the crew branch out of the way
         (crew/<voyage>-<N> -> salvage/<order>-<sha8>) so the next dispatch of the
         same crew slot starts from a fresh branch off the voyage tip — never
         building on top of the stranded order's work.

    Returns {"salvageBranch": ..., "strandedSha": ...} where salvageBranch is the
    ref that ACTUALLY holds the work (the renamed salvage ref on success, or the
    original crew branch if the rename didn't happen), or None if there was no local
    crew branch to preserve. strandedSha is the durable handle regardless. Best-effort:
    git failures are swallowed so this can never wedge finalization.

    FTR-MSO-2026-0378: *repo_root* pins the product repo the branch ops run
    against; *repo_name* resolves the per-repo crew worktree removed before the
    rename. Defaults keep single-repo behaviour byte-identical.
    """
    _gc = str(repo_root) if repo_root else None
    c_branch = crew_branch_name(voyage_id, crew_num)
    if not _branch_exists_local(c_branch, repo_root):
        return None

    sha = "unknown"
    try:
        sha_r = run_hidden(["git", "rev-parse", c_branch],
                               capture_output=True, text=True, cwd=_gc)
        if sha_r.returncode == 0 and sha_r.stdout.strip():
            sha = sha_r.stdout.strip()
    except Exception:
        pass

    sha8 = sha[:8] if sha != "unknown" else "unknown"
    # Sanitize the label into a git-ref-safe token so an unusual order_id can't make
    # `git branch -M` fail (which would otherwise leave the slot occupied).
    raw_label = order_id or c_branch
    label = re.sub(r"[^A-Za-z0-9._-]", "-", raw_label).strip("-") or "crew"
    salvage = f"salvage/{label}-{sha8}"

    # Remove the worktree first — a checked-out branch cannot be renamed.
    try:
        cleanup_crew_worktree(voyage_id, crew_num,
                              repo_root=repo_root, repo_name=repo_name)
    except Exception:
        pass

    # Rename the (still-unmerged) crew branch out of the slot's namespace so the
    # slot frees for a fresh crew branch on next dispatch. -M forces past an
    # existing salvage ref.
    salvage_ok = False
    if _branch_exists_local(c_branch, repo_root):
        try:
            r = run_hidden(["git", "branch", "-M", c_branch, salvage],
                               capture_output=True, text=True, cwd=_gc)
            salvage_ok = (r.returncode == 0) and _branch_exists_local(salvage, repo_root)
        except Exception:
            salvage_ok = False

    # Report the ref that actually holds the work — never a salvage name that may
    # not exist. If the rename failed, the work still lives on the crew branch (and
    # the SHA is always a valid handle for recovery).
    if salvage_ok:
        preserved_ref = salvage
    elif _branch_exists_local(c_branch, repo_root):
        preserved_ref = c_branch
    elif _branch_exists_local(salvage, repo_root):
        preserved_ref = salvage
    else:
        preserved_ref = None

    return {"salvageBranch": preserved_ref, "strandedSha": sha}


def cleanup_all_crew_worktrees(voyage_id: str,
                               repo_root: Optional[Path] = None) -> int:
    """Remove all per-crew worktrees for a voyage (called from sweep_decks).

    FTR-MSO-2026-0364: sweeps BOTH homes — canonical
    ``.mso/worktrees/<VID>/crew*`` and legacy
    ``voyages/active/<VID>/.worktree-crew*``.

    BUG-MSO-2026-0389: *repo_root* pins the product repo the ``git worktree``
    ops run against (git ``cwd``). ``None`` keeps the single-repo/embedded
    behaviour (dispatcher's own repo); solo/shared mode MUST pass the product
    repo, because the crew worktrees are registered there, not in the artefact
    repo the dispatcher stands in.

    Returns count removed.
    """
    _gc = str(repo_root) if repo_root else None
    candidates = []
    voyage_dir = _legacy_voyage_dir(voyage_id)
    if voyage_dir.exists():
        candidates.extend(
            c for c in voyage_dir.iterdir()
            if c.name.startswith(".worktree-crew") and c.is_dir()
        )
    new_home = worktrees_root() / voyage_id
    if new_home.exists():
        candidates.extend(
            c for c in new_home.iterdir()
            if c.name.startswith("crew") and c.is_dir()
        )

    removed = 0
    for candidate in candidates:
        result = run_hidden(
            ["git", "worktree", "remove", "--force", str(candidate)],
            capture_output=True, cwd=_gc,
        )
        if result.returncode != 0:
            _robust_rmtree(candidate, label=f"crew worktree sweep {voyage_id}")
        else:
            if candidate.exists():
                _robust_rmtree(candidate, label=f"crew worktree sweep {voyage_id}")
        removed += 1

    if removed:
        run_hidden(["git", "worktree", "prune"], capture_output=True, cwd=_gc)
    _rmdir_if_empty(new_home)

    return removed


def cleanup_voyage_worktree(voyage_id: str,
                            repo_root: Optional[Path] = None) -> bool:
    """Remove the admin worktree for a voyage.

    FTR-MSO-2026-0364: removes it from BOTH homes (canonical
    ``.mso/worktrees/<VID>/admin`` and legacy
    ``voyages/active/<VID>/.worktree``).

    BUG-MSO-2026-0389: *repo_root* pins the product repo the ``git worktree``
    ops run against (git ``cwd``). ``None`` keeps single-repo/embedded
    behaviour; solo/shared mode MUST pass the product repo (the admin worktree
    is registered there, not in the artefact repo).

    Returns True on clean removal, False if removal failed (caller should log).
    No-op (returns False) if the worktree directory does not exist.
    """
    _gc = str(repo_root) if repo_root else None
    candidates = [
        p for p in (
            legacy_worktree_path_for(voyage_id),
            worktrees_root() / voyage_id / "admin",
        ) if p.exists()
    ]

    if not candidates:
        # Still prune in case git has stale refs
        run_hidden(["git", "worktree", "prune"], capture_output=True, cwd=_gc)
        return False

    ok = True
    for worktree_path in candidates:
        result = run_hidden(
            ["git", "worktree", "remove", "--force", str(worktree_path)],
            capture_output=True, text=True, cwd=_gc,
        )
        if result.returncode != 0:
            # Fall back to manual removal + prune
            ok = _robust_rmtree(
                worktree_path, label=f"worktree cleanup {voyage_id}") and ok
            run_hidden(["git", "worktree", "prune"], capture_output=True, cwd=_gc)
        elif worktree_path.exists():
            # Belt-and-suspenders: remove any lingering dir
            _robust_rmtree(worktree_path, label=f"worktree cleanup {voyage_id}")
    _rmdir_if_empty(worktrees_root() / voyage_id)

    return ok


def prune_stale_worktrees(repo_root: Optional[Path] = None) -> int:
    """Remove worktrees whose voyage has moved to voyages/complete/.

    FTR-MSO-2026-0364: sweeps BOTH homes — legacy worktrees inside
    ``voyages/active/<VID>/`` (pre-relocation dispatches) and the canonical
    ``.mso/worktrees/<VID>/`` runtime home — so a voyage that ran with a
    legacy worktree still has it pruned at completion.

    Also runs `git worktree prune` to clean broken git refs.

    BUG-MSO-2026-0389: *repo_root* pins the product repo the ``git worktree``
    prune/remove ops run against (git ``cwd``). ``None`` keeps single-repo/
    embedded behaviour — the git ops AND the durable-plane scan resolve from
    the dispatcher's own repo. In solo/shared mode the caller passes the
    product repo so the worktrees registered there are actually found and
    pruned; the durable-plane scan (voyages/active|complete) still resolves via
    the dispatcher's artefact repo (``_repo_root()``), which is correct because
    that plane lives in the artefact repo.

    Returns the count of worktrees pruned.
    """
    _gc = str(repo_root) if repo_root else None
    run_hidden(["git", "worktree", "prune"], capture_output=True, cwd=_gc)

    artefact_dir = _resolve_artefact_dir(_repo_root())
    active_dir = artefact_dir / "voyages" / "active"
    complete_dir = artefact_dir / "voyages" / "complete"

    completed_voyage_ids = {p.name for p in complete_dir.iterdir()} if complete_dir.exists() else set()

    pruned = 0
    if active_dir.exists():
        for voyage_dir in active_dir.iterdir():
            if not voyage_dir.is_dir():
                continue
            voyage_id = voyage_dir.name
            if voyage_id not in completed_voyage_ids:
                continue
            # Prune legacy voyage admin worktree
            worktree_path = voyage_dir / ".worktree"
            if worktree_path.exists():
                if _salvage_worktree_if_dirty(worktree_path, voyage_id, "admin") == "failed":
                    continue  # BUG-0298: never destroy unsalvaged work — skip, operator inspects
                run_hidden(
                    ["git", "worktree", "remove", "--force", str(worktree_path)],
                    capture_output=True, cwd=_gc,
                )
                _robust_rmtree(worktree_path, label=f"prune stale worktree {voyage_id}")
                pruned += 1
            # BUG-MSO-2026-0240: also prune any lingering per-crew worktrees
            for candidate in voyage_dir.iterdir():
                if candidate.name.startswith(".worktree-crew") and candidate.is_dir():
                    if _salvage_worktree_if_dirty(candidate, voyage_id, candidate.name) == "failed":
                        continue  # BUG-0298: skip unsalvageable dirty tree
                    run_hidden(
                        ["git", "worktree", "remove", "--force", str(candidate)],
                        capture_output=True, cwd=_gc,
                    )
                    _robust_rmtree(candidate, label=f"prune stale crew worktree {voyage_id}")
                    pruned += 1

    # FTR-MSO-2026-0364: canonical runtime home — everything under
    # worktrees/<VID>/ (admin, crew*, convergence scratch) goes when the
    # voyage completes.
    wt_root = worktrees_root()
    if wt_root.exists():
        for voyage_home in wt_root.iterdir():
            if not voyage_home.is_dir():
                continue
            voyage_id = voyage_home.name
            if voyage_id not in completed_voyage_ids:
                continue
            for candidate in voyage_home.iterdir():
                if not candidate.is_dir():
                    continue
                if _salvage_worktree_if_dirty(candidate, voyage_id, candidate.name) == "failed":
                    continue  # BUG-0298: skip unsalvageable dirty tree
                run_hidden(
                    ["git", "worktree", "remove", "--force", str(candidate)],
                    capture_output=True, cwd=_gc,
                )
                _robust_rmtree(candidate, label=f"prune stale worktree {voyage_id}")
                pruned += 1
            _rmdir_if_empty(voyage_home)

    return pruned


def _salvage_worktree_if_dirty(wt_path, voyage_id: str, label: str) -> str:
    """BUG-MSO-2026-0298 (GKT F4): never force-remove a dirty worktree unsalvaged.

    A voyage can be (falsely or legitimately) archived while a worktree still
    holds uncommitted work — the GKT loss vector was exactly this prune. If the
    tree has tracked modifications, commit them and pin the commit on a
    `salvage/prune-<voyage>-<label>-<sha>` branch before removal.

    Returns "clean" (nothing to save), "salvaged" (branch created), or
    "failed" — and on "failed" the caller must SKIP removal: an unsalvaged
    dirty worktree is never destroyed; the WARN tells the operator where it is.
    """
    try:
        status_r = run_hidden(
            ["git", "status", "--porcelain", "--untracked-files=no"],
            capture_output=True, text=True, cwd=str(wt_path))
        if status_r.returncode != 0 or not status_r.stdout.strip():
            return "clean"
        run_hidden(["git", "add", "-A"], capture_output=True, cwd=str(wt_path))
        commit_r = run_hidden(
            ["git",
             "-c", "user.name=Maestro Salvage",
             "-c", "user.email=salvage@maestro.local",
             "commit", "-m",
             f"salvage: uncommitted work in {label} worktree of {voyage_id} at prune (BUG-0298)"],
            capture_output=True, text=True, cwd=str(wt_path))
        if commit_r.returncode != 0:
            raise RuntimeError(f"salvage commit failed: {commit_r.stderr.strip()[:200]}")
        sha_r = run_hidden(["git", "rev-parse", "--short", "HEAD"],
                               capture_output=True, text=True, cwd=str(wt_path))
        sha = sha_r.stdout.strip() or "unknown"
        branch = f"salvage/prune-{voyage_id}-{label}-{sha}"
        run_hidden(["git", "branch", branch, "HEAD"],
                       capture_output=True, cwd=str(wt_path))
        try:
            from maestro.core.fleet_runner import write_lifecycle_event
            write_lifecycle_event(
                "SALVAGE",
                f"{voyage_id}: dirty {label} worktree preserved on {branch} "
                f"before prune (BUG-0298)")
        except Exception:
            pass
        return "salvaged"
    except Exception as exc:
        try:
            from maestro.core.fleet_runner import write_lifecycle_event
            write_lifecycle_event(
                "WARN",
                f"{voyage_id}: prune salvage of {label} worktree FAILED ({exc}) — "
                f"worktree LEFT IN PLACE at {wt_path}; inspect and salvage manually (BUG-0298)")
        except Exception:
            pass
        return "failed"
