"""Connectivity probing + offline dispatch-gate state (FTR-MSO-2026-0359).

Field evidence (2026-07-14, VOY-0093): an internet dropout killed a crew with
``subtype=parse_error cost=$0 turns=0`` and the order burned a MAX_REQUEUES
attempt on pure infrastructure failure, while the dispatcher kept launching
fresh crews into the same outage. This module gives the dispatcher a cheap,
cached way to ask "are we online?" before spending a dispatch, and a state
file (`.mso/state/connectivity.json`, gitignored) that `mso status` reads to
show the operator why nothing new is launching.

Probe design:
- HTTPS request to the Anthropic API endpoint. ANY HTTP response — including
  4xx — proves transport works (the server answered); only transport-level
  errors (DNS, connect, TLS, timeout) count as unreachable.
- If the API probe fails, a `git ls-remote origin HEAD` distinguishes
  "Anthropic outage / API blocked" from "local connectivity loss" in the
  detail string. Either way dispatch is held: crews cannot work without the
  API regardless of whether git is reachable.
- Results are cached (`probeCacheSeconds`, default 60) so scan ticks never
  probe-spam, and the whole gate is skippable via
  ``resilience.connectivityGate: false`` for airgapped/proxy setups where the
  probe itself would misfire.
"""

import json
import subprocess
from maestro.core.proc import run_hidden, popen_hidden  # FTR-MSO-2026-0408: windowless subprocess
import time
import urllib.request
import urllib.error
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional

from maestro.workspace import get_workspace_dir

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

RESILIENCE_DEFAULTS: Dict[str, Any] = {
    # Master kill-switch for the offline dispatch gate. False = never probe,
    # never hold (airgapped / proxied setups where the probe would misfire).
    "connectivityGate": True,
    # Probe target. Any HTTP response (even 401/404) counts as ONLINE.
    "probeUrl": "https://api.anthropic.com",
    # Per-probe transport timeout (seconds) — keep short; this runs on the
    # dispatcher's main loop.
    "probeTimeoutSeconds": 5,
    # Cache TTL: repeat calls inside this window return the cached verdict.
    "probeCacheSeconds": 60,
    # NETWORK-classified requeues get their own generous cap (separate from
    # MAX_REQUEUES) ...
    "networkRetryMax": 5,
    # ... with per-attempt backoff (minutes). Attempts beyond the list length
    # reuse the last entry (1m / 5m / 15m / 15m / 15m).
    "networkBackoffMinutes": [1, 5, 15],
}


def load_resilience_config(workspace_dir: Optional[Path] = None) -> Dict[str, Any]:
    """Read the `resilience` block from workspace.json, merged over defaults.

    Omitting the block (or any key) enables the FTR-0359 defaults above.
    """
    cfg = dict(RESILIENCE_DEFAULTS)
    try:
        ws = workspace_dir or get_workspace_dir()
        raw = json.loads((ws / "config" / "workspace.json").read_text(encoding="utf-8"))
        block = raw.get("resilience") or {}
        if isinstance(block, dict):
            cfg.update({k: v for k, v in block.items() if v is not None})
    except Exception:
        pass  # fail-open to defaults — a broken config must not crash dispatch
    return cfg


# ---------------------------------------------------------------------------
# Probe (module-level cache)
# ---------------------------------------------------------------------------

_PROBE_CACHE: Dict[str, Any] = {"at": 0.0, "result": None}


def _probe_api(url: str, timeout: int) -> tuple:
    """(reachable: bool, detail: str). Any HTTP response counts as reachable."""
    req = urllib.request.Request(url, method="HEAD")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return True, f"api: HTTP {resp.status}"
    except urllib.error.HTTPError as exc:
        # Server answered (401/403/404/...) — transport is fine.
        return True, f"api: HTTP {exc.code}"
    except Exception as exc:  # URLError, socket.timeout, ssl errors, ...
        return False, f"api: unreachable ({type(exc).__name__}: {str(exc)[:120]})"


def _probe_git(repo_dir: Optional[Path], timeout: int) -> tuple:
    """(reachable: bool, detail: str) via `git ls-remote origin HEAD`."""
    cwd = repo_dir or get_workspace_dir().parent
    try:
        r = run_hidden(
            ["git", "ls-remote", "--exit-code", "origin", "HEAD"],
            capture_output=True, text=True, cwd=str(cwd), timeout=timeout + 5,
        )
        if r.returncode == 0:
            return True, "git: reachable"
        return False, f"git: unreachable (rc={r.returncode} {r.stderr.strip()[:120]})"
    except subprocess.TimeoutExpired:
        return False, "git: unreachable (ls-remote timed out)"
    except Exception as exc:
        return False, f"git: unreachable ({type(exc).__name__})"


def probe_connectivity(workspace_dir: Optional[Path] = None,
                       repo_dir: Optional[Path] = None,
                       force: bool = False) -> Dict[str, Any]:
    """Cheap, cached connectivity probe.

    Returns {"online": bool, "detail": str, "checkedAt": iso, "cached": bool}.

    ONLINE means the Anthropic API endpoint answered at transport level —
    crews cannot make progress without it, so a reachable git remote alone
    does NOT count as online (it only enriches the detail string so the
    operator can tell an Anthropic outage from a dead uplink).
    """
    cfg = load_resilience_config(workspace_dir)
    ttl = max(1, int(cfg.get("probeCacheSeconds", 60)))
    now = time.monotonic()
    if not force and _PROBE_CACHE["result"] is not None and now - _PROBE_CACHE["at"] < ttl:
        cached = dict(_PROBE_CACHE["result"])
        cached["cached"] = True
        return cached

    timeout = max(1, int(cfg.get("probeTimeoutSeconds", 5)))
    api_ok, api_detail = _probe_api(str(cfg.get("probeUrl", "https://api.anthropic.com")), timeout)
    if api_ok:
        detail = api_detail
        online = True
    else:
        git_ok, git_detail = _probe_git(repo_dir, timeout)
        online = False
        if git_ok:
            detail = f"{api_detail}; {git_detail} — Anthropic outage or API blocked"
        else:
            detail = f"{api_detail}; {git_detail} — local connectivity loss"

    result = {
        "online": online,
        "detail": detail,
        "checkedAt": datetime.now().isoformat(),
        "cached": False,
    }
    _PROBE_CACHE["at"] = now
    _PROBE_CACHE["result"] = dict(result)
    return result


def reset_probe_cache() -> None:
    """Test hook: clear the module-level probe cache."""
    _PROBE_CACHE["at"] = 0.0
    _PROBE_CACHE["result"] = None


# ---------------------------------------------------------------------------
# Connectivity state file (read by `mso status`)
# ---------------------------------------------------------------------------

def _state_file(workspace_dir: Optional[Path] = None) -> Path:
    ws = workspace_dir or get_workspace_dir()
    return ws / "state" / "connectivity.json"


def read_connectivity_state(workspace_dir: Optional[Path] = None) -> Dict[str, Any]:
    """Read `.mso/state/connectivity.json`; {} if absent/unreadable."""
    try:
        return json.loads(_state_file(workspace_dir).read_text(encoding="utf-8"))
    except Exception:
        return {}


def write_connectivity_state(workspace_dir: Optional[Path] = None, **fields: Any) -> None:
    """Merge-write the connectivity state file (fail-open on IO errors)."""
    try:
        state = read_connectivity_state(workspace_dir)
        state.update(fields)
        state["updatedAt"] = datetime.now().isoformat()
        path = _state_file(workspace_dir)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(state, indent=2), encoding="utf-8")
    except Exception:
        pass
