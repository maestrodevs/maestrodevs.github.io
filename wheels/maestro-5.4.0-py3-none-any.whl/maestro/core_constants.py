"""Centralised role-model and squad-name constants for the Maestro engine.

Replaces the triplicated CREW_NAMES / ROLE_MODELS dicts that previously lived
in maestro/core/{fleet_monitor,crew,fleet_runner}.py (FTR-MSO-2026-0168).
"""

from __future__ import annotations

from typing import Optional

# Canonical role → short model label used in dashboards and lifecycle logs.
# Legacy role codes (NAV/SHP/BOS/SCR/LKT/COX/QM) resolve via
# maestro.core.fleet_runner.resolve_role_code before lookup here.
DEFAULT_ROLE_MODELS: dict[str, str] = {
    "PLN":  "Opus",     # was NAV — Opus for high-leverage planning (low volume, propagates downstream)
    "BLD":  "Sonnet",   # was SHP — highest-volume role; Sonnet by default, per-order `model` override for hard orders
    "TST":  "Sonnet",   # was BOS
    "DOC":  "Sonnet",   # was SCR
    "SEC":  "Haiku",    # was LKT
    "REL":  "Opus",     # was COX — last role in the chain; high-stakes, low-volume
    "LEAD": "Opus",     # interactive judgment/reasoning role
}

# Canonical role → full Claude model ID used when dispatching crews.
# Mirrors DEFAULT_ROLE_MODELS but contains the actual API model strings.
#
# Model selection principle (high-stakes x low-volume gets Opus):
#   - PLN/REL/LEAD → Opus: planning, release/integration, and interactive
#     judgment are high-leverage and run infrequently, so the ~5x Opus cost
#     is paid sparingly where errors are costliest.
#   - BLD/TST/DOC → Sonnet: high-volume production roles where Sonnet 4.6 is
#     already strong; promote individual hard orders via the per-order `model`
#     override (FTR-0129) rather than globally.
#   - SEC → Haiku: read-only review; cheapest tier suffices.
DEFAULT_ROLE_MODEL_IDS: dict[str, str] = {
    "PLN":  "claude-opus-4-8",
    "BLD":  "claude-sonnet-4-6",
    "TST":  "claude-sonnet-4-6",
    "DOC":  "claude-sonnet-4-6",
    "SEC":  "claude-haiku-4-5-20251001",
    "REL":  "claude-opus-4-8",
    "LEAD": "claude-opus-4-8",
}

_DEFAULT_MODEL_LABEL = "Sonnet"
_DEFAULT_MODEL_ID = "claude-sonnet-4-6"


def _resolve(role: str) -> str:
    """Resolve legacy nautical role code to canonical without importing fleet_runner at module level."""
    try:
        from maestro.core.fleet_runner import resolve_role_code  # noqa: PLC0415
        return resolve_role_code(role)
    except Exception:
        return role


def get_role_model(role: str) -> str:
    """Return the short model label (Opus/Sonnet/Haiku) for a role code.

    Accepts both canonical (PLN/BLD/…) and legacy (NAV/SHP/…) codes.
    """
    canonical = _resolve(role) if role else role
    return DEFAULT_ROLE_MODELS.get(canonical, _DEFAULT_MODEL_LABEL)


def get_role_model_id(role: str) -> str:
    """Return the full Claude model ID for a role code (used when dispatching crews)."""
    canonical = _resolve(role) if role else role
    return DEFAULT_ROLE_MODEL_IDS.get(canonical, _DEFAULT_MODEL_ID)


def get_squad_name(slot: int) -> str:
    """Return the persona-specific display name for crew slot *slot* (1-indexed).

    Falls back to 'Squad <slot>' if the slot is out of range or persona unavailable.
    """
    try:
        from maestro.personas import current_persona  # noqa: PLC0415
        names = current_persona().squad_names()
        if 1 <= slot <= len(names):
            return names[slot - 1]
    except Exception:
        pass
    return f"Squad {slot}"


# ---------------------------------------------------------------------------
# FTR-MSO-2026-0281: Context window + reasoning effort configuration
# ---------------------------------------------------------------------------

# Shared enum sets — single source of truth imported by crew.py / loader.py / cli.py.
VALID_CONTEXT_WINDOWS: frozenset = frozenset({"standard", "1m"})

# Effort levels available to crew dispatch (max + ultracode reserved for interactive LEAD)
VALID_EFFORTS_CREW: frozenset = frozenset({"low", "medium", "high", "xhigh"})

# All known effort values including interactive-only ones
VALID_EFFORTS_ALL: frozenset = VALID_EFFORTS_CREW | frozenset({"max", "ultracode"})

# Effort levels that require an Opus model
OPUS_ONLY_EFFORTS: frozenset = frozenset({"xhigh"})

# Model IDs that support the 1M context window selector.
# Opus 5 ships 1M as both the default AND the maximum, so the '[1m]' selector
# is a no-op there rather than an upgrade — harmless, and kept for uniformity.
MILLION_CONTEXT_MODEL_IDS: frozenset = frozenset({
    "claude-fable-5",
    "claude-opus-5",
    "claude-opus-4-8",
    "claude-opus-4-7",
    "claude-sonnet-5",
    "claude-sonnet-4-6",
})

# Model IDs that support the top-tier reasoning efforts (xhigh effort guard).
# Fable 5 supports xhigh/max like the Opus family, so it is grouped here.
OPUS_MODEL_IDS: frozenset = frozenset({
    "claude-fable-5",
    "claude-opus-5",
    "claude-opus-4-8",
    "claude-opus-4-7",
    "claude-opus-4-6",
})

# Conservative per-role context window defaults (no extra cost out of the box).
DEFAULT_ROLE_CONTEXT_WINDOW: dict = {
    "PLN":  "standard",
    "BLD":  "standard",
    "TST":  "standard",
    "DOC":  "standard",
    "SEC":  "standard",
    "REL":  "standard",
    "LEAD": "standard",
}

# Conservative per-role effort defaults (high is Claude's own default; no extra cost).
DEFAULT_ROLE_EFFORT: dict = {
    "PLN":  "high",
    "BLD":  "high",
    "TST":  "high",
    "DOC":  "high",
    "SEC":  "high",
    "REL":  "high",
    "LEAD": "high",
}

_DEFAULT_CONTEXT_WINDOW = "standard"
_DEFAULT_EFFORT = "high"


def get_role_context_window(role: str) -> str:
    """Return the default context window for a role code (standard|1m).

    Accepts both canonical (PLN/BLD/…) and legacy (NAV/SHP/…) codes.
    """
    canonical = _resolve(role) if role else role
    return DEFAULT_ROLE_CONTEXT_WINDOW.get(canonical, _DEFAULT_CONTEXT_WINDOW)


def get_role_effort(role: str) -> str:
    """Return the default reasoning effort for a role code (low|medium|high|xhigh).

    Accepts both canonical (PLN/BLD/…) and legacy (NAV/SHP/…) codes.
    """
    canonical = _resolve(role) if role else role
    return DEFAULT_ROLE_EFFORT.get(canonical, _DEFAULT_EFFORT)
