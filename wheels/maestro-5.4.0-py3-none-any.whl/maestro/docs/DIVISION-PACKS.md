# Division Packs — Maestro

Division packs template Maestro's persona + role + order-type system for teams that don't run
a classic software-delivery lifecycle — QA/test-automation, and (in future packs) other
non-SDLC divisions. A pack is **data**: a manifest plus optional persona, role overlays, order
templates, gates, and workspace defaults. Installing one requires no engine change and no
Python code.

---

## Contents

- [What a pack is](#what-a-pack-is)
- [Pack anatomy](#pack-anatomy)
- [Built-in packs](#built-in-packs)
  - [sdlc (pack #0)](#sdlc-pack-0)
  - [test-engineering](#test-engineering)
- [`mso packs list`](#mso-packs-list)
- [`mso packs show`](#mso-packs-show)
- [`mso packs validate`](#mso-packs-validate)
- [`mso init --pack`](#mso-init---pack)
- [Tiers and licensing](#tiers-and-licensing)
- [Authoring your own pack](#authoring-your-own-pack)
- [Common pitfalls](#common-pitfalls)
- [See also](#see-also)

---

## What a pack is

Maestro's canonical 7 roles (`PLN`/`BLD`/`TST`/`DOC`/`SEC`/`REL`/`LEAD`) are generic delivery
archetypes, not software-specific job titles: plan, build, verify, document, audit, release,
and interactively partner. A division pack **relabels and re-scopes** those archetypes for a
different delivery process — e.g. a QA/test-automation division calls `PLN` the "Strategist"
and `TST` the "Explorer" — using the same overlay and order-template mechanisms every Maestro
workspace already has:

- **Persona** — renames roles, the product, and vocabulary throughout CLI output and prompts
- **Role overlays** — the same `.mso/config/roles/<CODE>.md` overlay files described in
  [ROLE-OVERLAYS.md](ROLE-OVERLAYS.md), pre-written for the division
- **Order-type templates** — division-specific order types (e.g. `TSD`, `AUT`) with their own
  `roleSequence` over the canonical archetypes
- **Gates** — a division-appropriate default `.mso/config/gates.json`
- **Workspace defaults** — suggested `verifyCommand`, per-role timeouts, and other
  `workspace.json` keys, deep-merged in at install time

Nothing in a pack requires a code change. If a pack author needs something the engine doesn't
support, that's a framework feature request, not a pack problem.

---

## Pack anatomy

A pack is a directory. Only `pack.json` is required — everything else is optional and applied
only if present:

```
maestro/packs/<pack-id>/
├── pack.json                 # required — manifest (id, displayName, description, tier, ...)
├── persona.json              # optional — persona this pack activates
├── roles/                    # optional — role overlays, e.g. PLN.md, BLD.md, TST.md
│   ├── PLN.md
│   └── ...
├── order-templates/          # optional — *-template.json files with _meta.roleSequence
│   └── TSD-template.json
├── gates.json                 # optional — division default human-review gate config
├── workspace-defaults.json    # optional — deep-merged into .mso/config/workspace.json
├── requirements/               # optional — .md.j2 order-description templates
└── QUICKSTART.md               # optional — division onboarding doc
```

### `pack.json` fields

| Field | Required | Type | Description |
|-------|----------|------|-------------|
| `id` | Yes | string | Slug — lowercase, hyphens allowed. Must match the pack's directory name. |
| `displayName` | Yes | string | Human-readable pack name. |
| `description` | Yes | string | One-line summary of the division this pack templates. |
| `tier` | Yes | `free` \| `team` \| `enterprise` | Licence tier required by `mso init --pack`. |
| `persona` | No | string | Persona id this pack activates. Either a built-in persona id, or the id of a `persona.json` shipped alongside `pack.json`. Defaults to `default` (no persona file written — preserves the plain-init workspace shape). |
| `roles` | No | array | Canonical archetype codes this division uses — a subset of `PLN`/`BLD`/`TST`/`DOC`/`SEC`/`REL`/`LEAD`. Informational (drives `mso packs show`'s "Roles" line). |
| `orderTypes` | No | object | Division order types keyed by type code, each with a `roleSequence` (and optional `description`). Informational for `mso packs show`; concrete order-template files (if shipped) live in `order-templates/`. |
| `scaffoldDirs` | No | array | Extra workspace-relative directories to create at init time, on top of the standard `.mso/` scaffold. |
| `verifyCommand` | No | string | Suggested `workspace.json` `verifyCommand` for this division. Merged in at init only if the pack ships no `workspace-defaults.json` that already sets it. |

### Where each asset lands on `mso init --pack`

| Pack asset | Installed to |
|---|---|
| `roles/*.md` | `.mso/config/roles/` (ordinary role overlays — same mechanism as [ROLE-OVERLAYS.md](ROLE-OVERLAYS.md)) |
| `persona.json` (or a built-in `persona` id) | `<workspace>/.maestro/config/persona.json` — **note**: this is the persona-resolver location, distinct from the `.mso/` artefact directory |
| `order-templates/*-template.json` | `.mso/orders/templates/` |
| `gates.json` | `.mso/config/gates.json` (overwrites) |
| `workspace-defaults.json` (and/or `verifyCommand`) | deep-merged into `.mso/config/workspace.json` — existing keys not present in the pack's defaults are preserved |
| `scaffoldDirs` | created under the workspace root (each empty dir gets a `.gitkeep`) |
| `requirements/*` | `.mso/requirements/` |
| `QUICKSTART.md` | `.mso/QUICKSTART-<pack-id>.md` |

A pack that ships nothing beyond `pack.json` (the `sdlc` pack) leaves the workspace
byte-identical to a plain `mso init` — this is what proves the mechanism round-trips cleanly.

---

## Built-in packs

### sdlc (pack #0)

`tier: free`. Formalises Maestro's own default software-delivery behaviour as a pack — the
same PLN→BLD→TST→DOC→SEC→REL process every existing Maestro workspace already runs. It ships
**only its manifest**: no role overlays, no persona file, no order templates. `mso init`
without `--pack` is equivalent to `mso init --pack sdlc`.

| Order type | Sequence | Description |
|---|---|---|
| `FTR` | `PLN → BLD → TST → DOC → SEC → REL` | Feature |
| `BUG` | `PLN → BLD → TST → REL` | Bug fix |
| `SEC` | `SEC → BLD → TST → REL` | Security fix — review-first |
| `INV` | `PLN` | Investigation — planning deliverable only |
| `PLN` | `PLN` | Planner document |
| `DOC` | `DOC` | Documentation only |

### test-engineering

`tier: team`. A QA/test-automation division: risk-based test strategy, automation
implementation, exploratory gap-finding, and quality/release-readiness reporting.

| Archetype | Division title | Does |
|---|---|---|
| `PLN` | Strategist | Risk assessment, coverage-gap analysis, tooling choice (Playwright / pytest / k6) |
| `BLD` | Automator | Implements automation code in the test repo |
| `TST` | Explorer | Exploratory charters, session notes, gap-finding against the automation |
| `DOC` | Reporter | Coverage / quality / release-readiness reports |
| `SEC` | Auditor | Read-only test-quality and flaky-test audit (optional in a sequence) |

| Order type | Sequence | Use for |
|---|---|---|
| `TSD` | `PLN` | Test strategy — a single-role planning deliverable |
| `AUT` | `PLN → BLD → TST` | Automation — strategy refinement, implementation, gap-check |
| `EXP` | `PLN → TST → DOC` | Exploratory charter — scope, execute, report |
| `QRP` | `TST → DOC` | Quality report — assess, report |

The pack ships all five role overlays, four order templates, a `post_nav_review` gate that
pauses `AUT` orders between the Strategist and the Automator for human review (mirroring the
`sdlc` pack's `PLN → BLD` gate), workspace defaults (a placeholder `verifyCommand`, per-role
timeouts, `qa.e2e: true`), four requirement templates, an extra scaffold directory
(`.mso/reports/qa/charters`), and a `QUICKSTART-test-engineering.md`.

---

## `mso packs list`

```bash
mso packs list
```

```
  Pack                 Tier         Access    Description
  ----                 ----         ------    -----------
  sdlc                 free         yes       Maestro's built-in software-delivery process — the default behaviour, formalised as pack #0.
  test-engineering     team         upgrade   Risk-based test strategy, automation engineering, exploratory testing, and quality reporting — ...
```

The `Access` column is `yes` for free packs and for non-free packs when the current licence
already meets the required tier; otherwise it reads `upgrade`.

---

## `mso packs show`

```bash
mso packs show test-engineering
mso packs show test-engineering --json    # raw pack.json manifest
```

Prints the manifest fields (id, name, description, tier, persona, roles), the order types with
their role sequences, and an **anatomy** block showing which optional assets the pack actually
ships on disk:

```
Pack:         test-engineering
Name:         Test Engineering
Description:  Risk-based test strategy, automation engineering, exploratory testing, and quality reporting — ...
Tier:         team
Persona:      test-engineering
Roles:        PLN, BLD, TST, DOC, SEC

Order types:
  TSD    [PLN]  — Test strategy — risk-based approach, coverage plan, tooling choice ...
  AUT    [PLN -> BLD -> TST]  — Automation — strategy refinement, Playwright/pytest/k6 implementation ...
  EXP    [PLN -> TST -> DOC]  — Exploratory charter — charter scoping, session execution, findings report
  QRP    [TST -> DOC]  — Quality report — coverage/quality assessment, release-readiness report

Anatomy (shipped assets):
  persona.json           : yes
  role overlays          : BLD.md, DOC.md, PLN.md, SEC.md, TST.md
  order-templates        : AUT-template.json, EXP-template.json, QRP-template.json, TSD-template.json
  gates.json             : yes
  workspace-defaults.json: yes
  requirements/          : yes
  QUICKSTART.md          : yes
```

For the `sdlc` pack, every "shipped assets" line reads `no` (or `no (uses default)` for the
persona line) — it ships only its manifest.

---

## `mso packs validate`

```bash
mso packs validate                       # every built-in pack
mso packs validate sdlc                  # one built-in pack by id
mso packs validate --path ./my-pack      # an arbitrary directory, e.g. while authoring
```

Validates a pack's **entire** asset set — not just the manifest schema check that loading a
pack already performs. Exit code `0` if everything is valid, `1` otherwise, so it drops
straight into a pack-authoring CI step:

```bash
mso packs validate --path ./my-pack || exit 1
```

Output is grouped per pack under a `[pack-id]` header. Every checked file prints `ok <path>` or
`INVALID <path>` followed by its diagnostics — the whole pack is checked in one run, not
fail-fast on the first bad file:

```
[test-engineering]
  ok       maestro/packs/test-engineering/pack.json
  ok       maestro/packs/test-engineering/roles/BLD.md
  ok       maestro/packs/test-engineering/roles/DOC.md
  ok       maestro/packs/test-engineering/roles/PLN.md
  ok       maestro/packs/test-engineering/roles/SEC.md
  ok       maestro/packs/test-engineering/roles/TST.md
  ok       maestro/packs/test-engineering/persona.json
  ok       maestro/packs/test-engineering/order-templates/AUT-template.json
  ok       maestro/packs/test-engineering/order-templates/EXP-template.json
  ok       maestro/packs/test-engineering/order-templates/QRP-template.json
  ok       maestro/packs/test-engineering/order-templates/TSD-template.json
  INVALID  maestro/packs/test-engineering/gates.json
    Gate '$schema' must be a JSON object
    Gate 'schemaVersion' must be a JSON object
    Gate '_notes' must be a JSON object
  ok       maestro/packs/test-engineering/workspace-defaults.json
```

> **Known issue:** the `gates.json` check above is a known false positive, not a defect in the
> `test-engineering` pack. The validator currently treats every top-level key in `gates.json` as
> a gate object, but the file also carries `$schema` / `schemaVersion` / `_notes` metadata keys
> (documented in [ROLE-OVERLAYS.md](ROLE-OVERLAYS.md)-style header conventions used elsewhere in
> Maestro config files) that aren't gates. The fix is to skip non-gate metadata keys in the
> `gates.json` check — tracked as a follow-up bug against `maestro/packs/validate.py`, not a
> content problem in the pack itself. Until fixed, expect `mso packs validate` (no args) and
> `mso packs validate test-engineering` to exit `1` on this one diagnostic.

### What gets checked

| Asset | Check |
|---|---|
| `pack.json` | The same manifest-schema check `mso packs show` performs on load. |
| `roles/*.md` | **The exact same code path `mso roles validate` uses.** A broken role overlay in a pack produces byte-identical diagnostics to a broken workspace overlay — there is no separate overlay-validation logic in the packs system. |
| `persona.json` (if shipped) | Validated against the persona schema. If a pack ships no `persona.json` but its manifest names a non-`default` persona, that id must resolve to a real built-in persona or the check fails. |
| `order-templates/*-template.json` | Requires `_meta.orderType` (non-empty string), `_meta.roleSequence` (non-empty array of canonical or legacy-alias role codes), and a top-level `description` (placeholder/template string). |
| `gates.json` | Every entry must be an object; an `enabled` key, if present, must be a boolean. |
| `workspace-defaults.json` | Must be a JSON object (it's the deep-merge target). |

This is the same multi-error, CI-friendly contract `mso roles validate` already established:
a broken manifest does not stop the rest of the pack's assets from being checked and reported
in the same invocation.

---

## `mso init --pack`

```bash
mso init --project QA1 --pack test-engineering
```

Runs a normal `mso init`, then layers the pack's assets on top per the
[installed-to table above](#where-each-asset-lands-on-mso-init---pack). Omit `--pack` (or pass
`--pack sdlc`) for the default SDLC workspace.

```bash
# Default SDLC workspace — these two are byte-identical
mso init --project MYPROJ
mso init --project MYPROJ --pack sdlc

# Team/Enterprise-tier division pack
mso init --project QA1 --pack test-engineering

# Trial a non-free pack without a Team/Enterprise licence
MAESTRO_SKIP_AUTH=1 mso init --project QA1 --pack test-engineering
```

`mso init --pack <name>` prints a summary of what the pack actually applied:

```
[Maestro] Pack 'test-engineering' applied:
    persona    -> .maestro/config/persona.json (test-engineering)
    role overlays (5): BLD.md, DOC.md, PLN.md, SEC.md, TST.md
    order templates (4): AUT-template.json, EXP-template.json, QRP-template.json, TSD-template.json
    gates      -> .mso/config/gates.json
    workspace defaults merged into .mso/config/workspace.json
    extra dirs: .mso/reports/qa/charters
    requirement templates -> .mso/requirements/
    quickstart -> .mso/QUICKSTART-test-engineering.md
```

An unknown pack id exits non-zero with the list of available packs:

```
$ mso init --project QA1 --pack nope
[Maestro] Unknown pack 'nope': Built-in pack 'nope' not found at ...
Available packs: sdlc, test-engineering
```

---

## Tiers and licensing

`tier: free` packs (the built-in `sdlc` pack) install at any licence tier. `tier: team` and
`tier: enterprise` packs (the built-in `test-engineering` pack, `tier: team`) are gated through
the same licence check every other Team/Enterprise feature uses — `mso init --pack
<non-free-pack>` exits non-zero without a sufficient licence, printing an upgrade message.

For local trial without activating a licence, set `MAESTRO_SKIP_AUTH=1` (the same escape hatch
used everywhere else in Maestro for CI and offline development):

```bash
MAESTRO_SKIP_AUTH=1 mso init --project QA1 --pack test-engineering
```

---

## Authoring your own pack

There's no `mso packs create` scaffolding command yet — author a pack directory by hand,
validate it as you go, and reference it with `--path`.

### 1. Start with the manifest

```json
{
  "id": "my-division",
  "displayName": "My Division",
  "description": "One-line summary of the delivery process this pack templates.",
  "tier": "free",
  "persona": "default",
  "roles": ["PLN", "BLD", "DOC"],
  "orderTypes": {
    "PRP": {
      "roleSequence": ["PLN", "BLD", "DOC"],
      "description": "Proposal — plan, produce, document"
    }
  }
}
```

Validate the manifest alone before adding anything else:

```bash
mso packs validate --path ./my-division
```

### 2. Write role overlays (optional)

Each `roles/<CODE>.md` file is an **ordinary role overlay** — the exact format described in
[ROLE-OVERLAYS.md](ROLE-OVERLAYS.md). The fastest way to start one is to dump the core role and
edit from there:

```bash
mkdir -p my-division/roles
mso roles show PLN --core > my-division/roles/PLN.md
```

Set `"extends": "core"` and choose `extend` / `override` / `replace` per section — division
packs typically `replace` most prose sections (`overview`, `permissions`, `paths`,
`prompt_preamble`, `transitions`, `branch_discipline`) since the core SDLC-flavoured prose
rarely fits a different division, while `extend`-ing list sections (`responsibilities`,
`must_do`, `must_not`, `quality_checklist`) to layer division-specific items onto the
generic ones. The built-in `test-engineering` pack's `roles/*.md` files
(`maestro/packs/test-engineering/roles/`) are a complete worked example of this pattern.

### 3. Write order-type templates (optional)

Each `order-templates/<TYPE>-template.json` needs an `_meta` block with `orderType` and a
non-empty `roleSequence`, plus a top-level `description` placeholder for order authors to fill
in. See `maestro/packs/test-engineering/order-templates/TSD-template.json` for a complete
example, including a `## Repository Impact Map` and `## Assumptions Made` section in the
description body.

### 4. Add gates, workspace defaults, requirements, and a QUICKSTART (all optional)

- `gates.json` — reuses the engine's existing gate keys (e.g. `post_nav_review`); a pack cannot
  invent new gate names, only configure existing ones.
- `workspace-defaults.json` — any subset of `workspace.json` keys; deep-merged at init time, so
  it only needs to set what the division actually wants to change.
- `requirements/*.md.j2` — Jinja2 order-description templates, one per order type, matching the
  shape of `maestro/templates/requirements/` (see `tsd-test-strategy.md.j2` for a full example).
- `QUICKSTART.md` — plain Markdown; lands at `.mso/QUICKSTART-<pack-id>.md` on init.

### 5. Validate the whole pack

```bash
mso packs validate --path ./my-division
```

Fix every `INVALID` line reported — the command checks the entire pack in one pass, so all
defects surface together.

### 6. Try a full init against a scratch workspace

```bash
mkdir /tmp/pack-trial && cd /tmp/pack-trial
MAESTRO_SKIP_AUTH=1 mso init --project TRY --pack ./path/to/my-division
```

(`mso init --pack` currently resolves **built-in** pack ids from `maestro/packs/`; to trial a
pack you're authoring outside the pip package, copy or symlink it into `maestro/packs/` in a
local checkout, or wait for the third-party `mso packs install <path>` command — not yet
shipped.)

---

## Common pitfalls

### Pack id doesn't match its directory name

`load_pack_from_dir` rejects the pack if `pack.json`'s `id` field doesn't match the containing
directory's name — this guards against `mso init --pack <id>` resolving a different directory
than `mso packs list` advertised. Rename the directory or fix `id`.

### Non-`free` tier with no persona/role overlay content

A pack manifest alone is enough to pass schema validation, but a `team`/`enterprise` pack with
no role overlays or order templates provides nothing beyond a persona rename — usually not what
was intended. `mso packs show <pack>`'s anatomy block makes this obvious at a glance.

### `persona` id with no matching persona

If a pack's manifest names a `persona` other than `default` and ships no `persona.json`, that
id must resolve to a real **built-in** persona (see [PERSONAS.md](PERSONAS.md)) or `mso packs
validate` reports it as invalid — `mso init --pack` would otherwise silently fall through with
no persona applied.

### Expecting `mso order --template` to see pack requirement templates

Pack `requirements/*.md.j2` files land at `.mso/requirements/` on init, but the custom-template
resolution path for `mso order --template` currently reads `.mso/templates/requirements/` — a
different directory. Use the pack's requirement templates as copy-paste references for now
rather than expecting automatic `--template` discovery.

### Forgetting the tier gate applies to `mso init --pack`, not `mso packs show`/`list`

`mso packs list` and `mso packs show` never require a licence — they only read files. The tier
check runs at `mso init --pack <non-free-pack>` time.

---

## See also

- [ROLE-OVERLAYS.md](ROLE-OVERLAYS.md) — the overlay mechanism every pack's `roles/*.md` files use
- [PERSONAS.md](PERSONAS.md) — the persona system a pack's `persona.json` activates
- [CLI-REFERENCE.md](CLI-REFERENCE.md) — full `mso packs` and `mso init` flag reference
- [ORDERS-AND-VOYAGES.md](ORDERS-AND-VOYAGES.md) — order-type and `roleSequence` fundamentals a pack's order templates build on
