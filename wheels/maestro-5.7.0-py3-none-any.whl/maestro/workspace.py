"""maestro.workspace — workspace directory resolution (.mso/ only)."""

from __future__ import annotations

import json
import logging
import os
from pathlib import Path

_log = logging.getLogger(__name__)

# Canonical artefact directory name. Modules that must spell ".mso" in a path
# join or git pathspec import this instead of hand-writing the literal — the
# FTR-MSO-2026-0361 audit tests forbid hand-built ".mso" strings outside this
# module.
MSO_DIR_NAME = ".mso"
_MSO_DIR = MSO_DIR_NAME  # legacy private alias

# Canonical user-global Maestro home directory name (``~/.maestro``). Like
# MSO_DIR_NAME this is the single sanctioned spelling of the ".maestro" home
# literal: EVERY reader/writer of the global plane (registry, licence cache,
# auth cache, user-global persona/config, Hub pid/token) routes through
# :func:`get_maestro_home`, so one env override (``MAESTRO_HOME``) redirects
# them all at once. The BUG-MSO-2026-0387 audit test forbids hand-built
# ``Path.home() / ".maestro"`` joins outside this module — they silently hit the
# operator's real global state (a crew QA walkthrough once clobbered the real
# ~/.maestro/projects.json this way).
MAESTRO_HOME_DIR_NAME = ".maestro"


def get_maestro_home(*, create: bool = False) -> Path:
    """Return the user-global Maestro home directory.

    Resolution order:

    1. ``MAESTRO_HOME`` environment variable (preferred). Tests and QA cold-start
       walkthroughs set this to a scratch dir so they can NEVER clobber the
       operator's real ``~/.maestro`` (BUG-MSO-2026-0387). ``~`` in the value is
       expanded.
    2. ``~/.maestro`` (``Path.home() / ".maestro"``) — the historical default;
       behaviour is unchanged when the env var is unset.

    Pass ``create=True`` to ``mkdir(parents=True, exist_ok=True)`` the directory
    before returning it (writers create; readers do not).
    """
    env_home = os.environ.get("MAESTRO_HOME", "").strip()
    base = (
        Path(env_home).expanduser()
        if env_home
        else Path.home() / MAESTRO_HOME_DIR_NAME
    )
    if create:
        base.mkdir(parents=True, exist_ok=True)
    return base


def maestro_home_file(*parts: str, create_parent: bool = False) -> Path:
    """Return ``get_maestro_home() / *parts`` (a file/subdir under the home).

    Convenience wrapper so callers spell the leaf name only
    (``maestro_home_file("projects.json")``) and never the ``.maestro`` literal.
    ``create_parent=True`` ensures the parent directory exists.
    """
    p = get_maestro_home().joinpath(*parts)
    if create_parent:
        p.parent.mkdir(parents=True, exist_ok=True)
    return p


def find_workspace_dir(start: Path | None = None) -> Path | None:
    """Walk up from *start* (default: cwd) looking for a ``.mso/`` workspace dir.

    Returns the ``.mso/`` directory or ``None`` if not found.
    """
    root = Path(start) if start is not None else Path.cwd()
    for path in [root, *root.parents]:
        mso = path / _MSO_DIR
        if (mso / "config").is_dir():
            return mso
    return None


def get_workspace_dir(start: Path | None = None) -> Path:
    """Return the workspace directory.

    Resolution order:
    1. ``MAESTRO_DIR`` environment variable (preferred)
    2. Walk up from *start* (default: cwd) looking for ``.mso/config``

    Raises :class:`FileNotFoundError` if no workspace is found.
    """
    env_dir = os.environ.get("MAESTRO_DIR")
    if env_dir:
        return Path(env_dir).resolve()

    root = Path(start) if start is not None else Path.cwd()
    for path in [root, *root.parents]:
        mso = path / _MSO_DIR
        if (mso / "config").is_dir():
            return mso

    raise FileNotFoundError(
        "No Maestro workspace found in the current directory or any parent. "
        "Run `mso init --project <PRJ>` to create one."
    )


# Legacy alias kept for callers that imported from here before the rename.
_find_mso_dir = find_workspace_dir


def resolve_artefact_dir(workspace: Path) -> Path:
    """Return the canonical workspace artefact dir under *workspace*.

    Returns the ``.mso/`` path (creating it via `.mkdir()` at the call site
    if needed).
    """
    mso = workspace / _MSO_DIR
    if mso.is_dir():
        return mso
    return mso


def artefact_report_stem(kind: str, order_id: str) -> str:
    """Canonical ``{kind}-{ORDER-ID}`` filename stem (no extension) for a
    SEC/INV-family deliverable, without doubling the prefix when *order_id*
    already carries it (BUG-MSO-2026-0465).

    ``maestro/roles/SEC.md`` documents the deliverable location as
    ``SEC-{ORDER-ID}.md`` (and ``INV-{ORDER-ID}.md`` for investigation orders).
    That template is unambiguous for a BUG-/FTR-/PLN-type order id
    (``SEC-BUG-MSO-2026-0100``), but a SEC-type (or INV-type) order id already
    begins with its own type prefix (``SEC-MSO-2026-0461``) — naively
    substituting into the template doubles it (``SEC-SEC-MSO-2026-0461``),
    which never matches what a crew following the docs sensibly writes
    (``SEC-MSO-2026-0461.md``, unchanged). Every constructor of one of these
    filenames (the SEC_ARTEFACT_MISSING gate's diagnostics, ``mso security
    review --order``, the COX/REL merge gate, the OWASP posttool scanner)
    should route through this helper so they agree with each other and with
    what the docs actually tell a crew to write.
    """
    kind = (kind or "").strip().upper()
    prefix = f"{kind}-"
    oid = (order_id or "").strip()
    return oid if oid.upper().startswith(prefix) else f"{prefix}{oid}"


# ---------------------------------------------------------------------------
# Artefact-mode resolution (FTR-MSO-2026-0366 — Phase 2 solo mode)
# ---------------------------------------------------------------------------

# Valid artefacts.mode values (mirrors maestro.registry.ARTEFACT_MODES).
# Absence of the block — or any unrecognised value — means "embedded".
ARTEFACT_MODES = ("embedded", "solo", "shared")

# Parsed workspace.json cache keyed by workspace dir, invalidated by mtime.
# get_artefact_root() is called on every artefact path build (hot dispatcher
# loops), so the config read must be stat-cheap in steady state.
_WORKSPACE_CONFIG_CACHE: dict[Path, tuple[int, dict]] = {}

# BUG-MSO-2026-0425: resolved registry-fallback redirect keyed by walk-up
# workspace dir. get_artefact_root() is a hot path; the registry-fallback branch
# (product-repo pointer stub missing/stale) reads ~/.maestro/projects.json, so
# the decision is memoised per process. Cleared alongside the config cache.
_REGISTRY_REDIRECT_CACHE: dict[Path, Path | None] = {}

# BUG-MSO-2026-0425: warn-once keys so a missing/stale solo pointer surfaces
# without spamming (get_artefact_root() runs many times per command).
_POINTER_WARNINGS_EMITTED: set[str] = set()


def clear_workspace_config_cache() -> None:
    """Drop the parsed workspace.json cache (test isolation helper)."""
    _WORKSPACE_CONFIG_CACHE.clear()
    _REGISTRY_REDIRECT_CACHE.clear()
    _POINTER_WARNINGS_EMITTED.clear()


def _workspace_config(workspace: Path) -> dict:
    """Parsed ``<workspace>/config/workspace.json`` (mtime-cached, fail-open {})."""
    cfg_file = workspace / "config" / "workspace.json"
    try:
        mtime = cfg_file.stat().st_mtime_ns
    except OSError:
        return {}
    cached = _WORKSPACE_CONFIG_CACHE.get(workspace)
    if cached is not None and cached[0] == mtime:
        return cached[1]
    try:
        cfg = json.loads(cfg_file.read_text(encoding="utf-8"))
        if not isinstance(cfg, dict):
            cfg = {}
    except Exception:
        cfg = {}
    _WORKSPACE_CONFIG_CACHE[workspace] = (mtime, cfg)
    return cfg


def _artefacts_block(workspace: Path) -> dict:
    """The ``artefacts`` block of *workspace*'s workspace.json ({} if absent)."""
    block = _workspace_config(workspace).get("artefacts")
    return block if isinstance(block, dict) else {}


def _workspace_project_acronym(workspace: Path) -> str | None:
    """Best-effort project acronym for registry lookups: workspace.json
    ``project`` (single-project scaffold), else projects.json ``defaultProject``."""
    acronym = _workspace_config(workspace).get("project")
    if isinstance(acronym, str) and acronym.strip():
        return acronym.strip()
    try:
        projects = json.loads(
            (workspace / "config" / "projects.json").read_text(encoding="utf-8"))
        acronym = projects.get("defaultProject")
        if isinstance(acronym, str) and acronym.strip():
            return acronym.strip()
    except Exception:
        pass
    return None


def _registry_entry_for(workspace: Path, block: dict) -> dict | None:
    """Normalised registry v2 entry for this workspace's project, or None."""
    acronym = block.get("project") or _workspace_project_acronym(workspace)
    if not acronym:
        return None
    try:
        from maestro import registry
        return registry.get_project_entry(acronym)
    except Exception:
        return None


def _redirected_artefact_root(ws: Path, block: dict) -> Path | None:
    """Resolve the artefact repo's ``.mso`` for a solo/shared *ws*, or None.

    Order: workspace.json ``artefacts.root`` (the committed mirror), then the
    registry v2 ``artefactRoot``. A candidate must be a real workspace
    (``<root>/.mso/config`` exists) to win; when the candidate IS *ws* we are
    already standing in the artefact repo and no redirect is needed.
    """
    root = block.get("root")
    if isinstance(root, str) and root.strip():
        candidate = (Path(root).expanduser().resolve() / MSO_DIR_NAME)
        if (candidate / "config").is_dir():
            return None if candidate == ws else candidate
    entry = _registry_entry_for(ws, block)
    if entry and entry.get("artefactRoot"):
        candidate = Path(entry["artefactRoot"]).resolve() / MSO_DIR_NAME
        if (candidate / "config").is_dir() and candidate != ws:
            return candidate
    return None


def _emit_pointer_warning(key: str, message: str) -> None:
    """Warn once per *key* about a missing/stale solo artefact pointer.

    Routed through :mod:`logging`; Python's last-resort handler surfaces
    WARNING to stderr even when the CLI configured no handlers, so operators
    see it. Deduped so the many get_artefact_root() calls in one command emit
    a single line.
    """
    if key in _POINTER_WARNINGS_EMITTED:
        return
    _POINTER_WARNINGS_EMITTED.add(key)
    _log.warning(message)


def _registry_solo_redirect(ws: Path, block: dict) -> Path | None:
    """Registry-driven artefact redirect for a *ws* whose local ``artefacts``
    block does NOT declare solo/shared (BUG-MSO-2026-0425).

    The reproduced failure: a product-repo checkout keeps a stale ``.mso/`` with
    no (or a stale) ``artefacts`` pointer, so :func:`get_artefact_root` walked up,
    found that plane, and silently served empty/wrong artefact state. The global
    registry still records the project as solo/shared with an ``artefactRoot``,
    so we consult it as the authority. Returns the redirect ``.mso`` path when
    the registry positively resolves a *different*, real artefact workspace;
    otherwise ``None`` (genuinely embedded, or unresolvable).

    Memoised per *ws* — this only runs for non-override callers (cold CLI /
    monitor refresh), never the dispatcher hot loop (which resolves through
    ``_MAESTRO_DIR_OVERRIDE`` and never reaches here).
    """
    if ws in _REGISTRY_REDIRECT_CACHE:
        return _REGISTRY_REDIRECT_CACHE[ws]
    result: Path | None = None
    entry = _registry_entry_for(ws, block)
    if entry and entry.get("artefactMode") in ("solo", "shared"):
        root = entry.get("artefactRoot")
        if isinstance(root, str) and root.strip():
            candidate = Path(root).expanduser().resolve() / MSO_DIR_NAME
            if (candidate / "config").is_dir() and candidate != ws:
                result = candidate
    _REGISTRY_REDIRECT_CACHE[ws] = result
    return result


def get_artefact_mode(start: Path | None = None) -> str:
    """Return the workspace's artefact mode: ``embedded`` | ``solo`` | ``shared``.

    Reads the ``artefacts.mode`` key of the resolved workspace's
    workspace.json (FTR-MSO-2026-0366). The block being absent, unreadable,
    or carrying an unrecognised value all mean ``embedded`` — full
    back-compat by construction. No workspace resolvable → ``embedded``.
    """
    try:
        ws = get_workspace_dir(start)
    except FileNotFoundError:
        return "embedded"
    mode = _artefacts_block(ws).get("mode")
    return mode if mode in ("solo", "shared") else "embedded"


def get_artefact_root(start: Path | None = None) -> Path:
    """Return the artefact root — the ``.mso/`` directory holding all durable
    Maestro artefacts (queues, orders, voyages, plans, handoffs, reports,
    usage, config) and the gitignored runtime plane (crews, logs, state, temp).

    **Embedded mode (default — ``artefacts`` block absent):** identical to
    :func:`get_workspace_dir` — ``MAESTRO_DIR`` if set, else the ``.mso/``
    found by walking up from *start*/cwd. Zero behaviour change.

    **Solo/shared mode (FTR-MSO-2026-0366, plan §3.6):** when the resolved
    workspace's ``artefacts.mode`` is ``solo``/``shared``, this resolver —
    and only this resolver — retargets to ``<artefact-repo>/.mso``. The
    redirect source is the workspace.json ``artefacts.root`` mirror, falling
    back to the registry v2 ``artefactRoot``; a workspace already standing in
    the artefact repo resolves to itself. Callers MUST use this for artefact
    paths (anything under ``.mso/``) and :func:`get_product_repo` for
    product-repo paths; the two stop being related once artefacts leave the
    product repo.
    """
    return _artefact_root_from_mso(get_workspace_dir(start))


def artefact_root_for(workspace_root: Path) -> Path:
    """Artefact ``.mso`` for a KNOWN *workspace_root*, honouring the solo/shared
    pointer but anchored at that root — NOT re-resolved via ``MAESTRO_DIR``/cwd.

    BUG-MSO-2026-0425: CLI commands call :func:`maestro.cli.find_workspace`
    (walk-up from cwd / ``@PRJ`` registry), which ignores ``MAESTRO_DIR``, to pick
    the workspace; they must then resolve THAT workspace's artefact plane, not
    whatever an ambient ``MAESTRO_DIR`` points at (mixing the two strategies is
    how a stray env var silently retargeted the review/order CLI). Use this from
    such call sites instead of ``get_artefact_root(start=...)``. Embedded mode
    returns ``<workspace_root>/.mso`` — identical to :func:`resolve_artefact_dir`.
    """
    return _artefact_root_from_mso(resolve_artefact_dir(workspace_root))


def _artefact_root_from_mso(ws: Path) -> Path:
    """Resolve the artefact root given a specific walk-up ``.mso`` dir *ws*.

    Shared core of :func:`get_artefact_root` (env/cwd-resolved *ws*) and
    :func:`artefact_root_for` (caller-anchored *ws*) so the solo/shared pointer +
    registry-fallback + WARN logic lives in exactly one place.
    """
    block = _artefacts_block(ws)
    if block.get("mode") in ("solo", "shared"):
        redirected = _redirected_artefact_root(ws, block)
        if redirected is not None:
            return redirected
        # Declared solo/shared but no external artefact root resolved. Either we
        # are standing IN the artefact repo (legitimate — its own block points to
        # self) or the pointer is stale. The registry disambiguates: if it names a
        # usable, different artefact root, honour it and warn; otherwise fall
        # through to ws (we ARE the artefact plane, or nothing better exists).
        reg = _registry_solo_redirect(ws, block)
        if reg is not None:
            _emit_pointer_warning(
                str(ws),
                f"[BUG-MSO-2026-0425] Local 'artefacts' pointer in "
                f"{ws / 'config' / 'workspace.json'} is stale (declares "
                f"{block.get('mode')} but resolves no artefact root); using the "
                f"registry's artefactRoot {reg.parent} instead. Repair with "
                f"`mso migrate artefact-repo`.",
            )
            return reg
        # A configured ``root`` that names a DIFFERENT but unusable path is a
        # broken pointer (as opposed to omitted/self-pointing, which just means
        # "we ARE the artefact repo"). Surface it rather than silently serving
        # this plane.
        root = block.get("root")
        if isinstance(root, str) and root.strip():
            broken = Path(root).expanduser().resolve() / MSO_DIR_NAME
            if broken != ws and not (broken / "config").is_dir():
                _emit_pointer_warning(
                    str(ws),
                    f"[BUG-MSO-2026-0425] 'artefacts.root' in "
                    f"{ws / 'config' / 'workspace.json'} points to {broken.parent}, "
                    f"which is not a Maestro artefact workspace — falling back to "
                    f"{ws.parent}. Repair with `mso migrate artefact-repo`.",
                )
        return ws
    # Local block does NOT declare solo/shared. In solo mode a product-repo
    # checkout may carry a stale/absent pointer stub while the global registry
    # still records the project as solo/shared — resolving here to the frozen
    # product-repo plane is the BUG-MSO-2026-0425 silent-wrong-data failure.
    # Consult the registry and, if it names a real artefact repo, redirect + warn
    # rather than serving stale artefacts. Embedded projects have no such registry
    # entry, so this is a no-op there (byte-identical behaviour).
    reg = _registry_solo_redirect(ws, block)
    if reg is not None:
        _emit_pointer_warning(
            str(ws),
            f"[BUG-MSO-2026-0425] The global registry records this project as "
            f"solo/shared artefact mode, but {ws / 'config' / 'workspace.json'} is "
            f"missing its 'artefacts' pointer — resolving artefacts from "
            f"{reg.parent} via the registry. Repair the local pointer with "
            f"`mso migrate artefact-repo`.",
        )
        return reg
    return ws


def get_product_repo(target_repo: str | None = None,
                     start: Path | None = None) -> Path:
    """Return the product repository root — the git repo whose source code
    crews build, branch, and converge.

    **Embedded mode (default):** the parent of the ``.mso/`` workspace dir
    (``.mso`` is embedded in the product repo), so *target_repo* is accepted
    but unused. Zero behaviour change.

    **Solo/shared mode (FTR-MSO-2026-0366):** the ``.mso`` parent is the
    ARTEFACT repo, so the product repo must be configured. Resolution order:
    the workspace.json ``artefacts`` mirror (``repos[target_repo].path`` /
    ``productRepo`` / single-entry ``repos`` map), then the registry v2 entry
    (``repos`` map / ``productRepo``). When resolution is standing in a
    product-side pointer stub (walk-up ``.mso`` != artefact root), the stub's
    parent is the product repo. Anything else raises FileNotFoundError with
    remediation guidance — silently treating the artefact repo as the product
    repo would let the dispatcher branch/converge the artefact repo, which is
    exactly what solo mode exists to prevent.

    **Phase 4 (plan §4):** *target_repo* resolves through the full ``repos``
    map to a per-repo managed checkout. Callers MUST use this (not
    ``get_workspace_dir().parent``) for any path or ``cwd`` that means "the
    product repo".
    """
    ws = get_workspace_dir(start)
    block = _artefacts_block(ws)
    if block.get("mode") not in ("solo", "shared"):
        return ws.parent

    art = get_artefact_root(start)
    # In solo mode the authoritative mirror lives in the ARTEFACT workspace's
    # config; a product-side stub may carry only {mode, root}.
    art_block = _artefacts_block(art) or block
    entry = _registry_entry_for(art, art_block) or _registry_entry_for(ws, block)

    def _repo_path_from(repos: object, name: str | None) -> Path | None:
        if not isinstance(repos, dict) or not repos:
            return None
        if name is not None:
            item = repos.get(name)
        elif len(repos) == 1:
            item = next(iter(repos.values()))
        else:
            return None
        if isinstance(item, dict) and isinstance(item.get("path"), str):
            return Path(item["path"]).resolve()
        return None

    for candidate in (
        _repo_path_from(art_block.get("repos"), target_repo),
        _repo_path_from((entry or {}).get("repos"), target_repo),
        Path(art_block["productRepo"]).resolve()
            if isinstance(art_block.get("productRepo"), str) and art_block["productRepo"].strip()
            else None,
        Path(entry["productRepo"]).resolve()
            if entry and isinstance(entry.get("productRepo"), str)
            and Path(entry["productRepo"]).resolve() != art.parent.resolve()
            else None,
        _repo_path_from(art_block.get("repos"), None),
        _repo_path_from((entry or {}).get("repos"), None),
    ):
        if candidate is not None and candidate.is_dir():
            return candidate

    if ws != art:
        # Standing in a product-side pointer stub: its parent IS the product repo.
        return ws.parent

    raise FileNotFoundError(
        f"Artefact mode is '{block.get('mode')}' but no product repo is "
        f"configured for target_repo={target_repo!r}. Set "
        f"'artefacts.productRepo' (or a 'repos' map entry) in "
        f"{art / 'config' / 'workspace.json'}, or register the project with "
        f"`productRepo`/`repos` in the global registry (~/.maestro/projects.json)."
    )


def get_repos_map(start: Path | None = None) -> dict:
    """Return the workspace's ``repos`` map (plan §4.2 / FTR-MSO-2026-0377).

    A multi-repo workspace maps 1..N product repos: ``{repoName: {path, slug?,
    defaultBranch?, cloneProtocol?, buildCommand?, testCommand?}}``. Resolution
    prefers the workspace.json ``artefacts.repos`` mirror (the committed,
    machine-independent source), falling back to the registry v2 entry's
    ``repos`` map. An empty/absent map means "single-repo workspace" — callers
    MUST treat that as the embedded default (zero behaviour change).

    Pure read, fail-open ``{}``: no workspace, unreadable config, or a malformed
    ``repos`` value all yield ``{}`` so single-repo/embedded dispatch is never
    perturbed by a config problem.
    """
    try:
        ws = get_workspace_dir(start)
    except FileNotFoundError:
        return {}
    block = _artefacts_block(ws)
    repos = block.get("repos")
    if isinstance(repos, dict) and repos:
        return repos
    entry = _registry_entry_for(ws, block)
    if entry:
        repos = entry.get("repos")
        if isinstance(repos, dict) and repos:
            return repos
    return {}


# ---------------------------------------------------------------------------
# Registry-entry resolution (FTR-MSO-2026-0369 — Hub Phase 2d)
# ---------------------------------------------------------------------------
#
# get_artefact_root()/get_product_repo() above resolve relative to a single
# *process-wide* workspace: they honour MAESTRO_DIR and walk up from cwd/start.
# That is wrong for the Hub, which polls MANY registered workspaces from one
# long-lived process — a stray MAESTRO_DIR in the Hub's own environment must
# never leak into every workspace's resolution. The two helpers below are pure
# functions of a single ``maestro.registry`` v2 entry dict: no env vars, no cwd,
# no filesystem walk-up. Hub code (server.py/poller.py/aggregator.py) MUST use
# these instead of reading ``entry["path"]`` directly once ``artefactMode`` may
# be ``solo``/``shared``.

def artefact_parent_for_entry(entry: dict) -> Path:
    """Return the directory whose child is ``.mso`` for a registry v2 entry.

    Embedded (default — ``artefactMode`` absent/not solo|shared, or
    ``artefactRoot`` absent): ``entry['path']`` — byte-identical to pre-Phase-2
    behaviour (``resolve_artefact_dir(artefact_parent_for_entry(entry))`` ==
    today's ``resolve_artefact_dir(Path(entry['path']))``).

    Solo/shared: ``entry['artefactRoot']`` — the dedicated artefact repo that
    holds the durable ``.mso/`` plane (plan §3.6 / FTR-MSO-2026-0366).
    """
    mode = entry.get("artefactMode")
    root = entry.get("artefactRoot")
    if mode in ("solo", "shared") and isinstance(root, str) and root.strip():
        return Path(root).expanduser().resolve()
    return Path(entry["path"]).expanduser().resolve()


def product_repo_for_entry(entry: dict) -> Path:
    """Return the product-repo checkout for a registry v2 entry (Hub-safe).

    ``entry['productRepo']`` when present, else ``entry['path']`` — mirrors
    :func:`maestro.registry.migrate_entry`'s default (v1/embedded: the product
    repo IS the workspace path). This is the directory dispatch/stop subprocess
    invocations must run in — never the artefact root in solo/shared mode.
    """
    repo = entry.get("productRepo")
    if isinstance(repo, str) and repo.strip():
        return Path(repo).expanduser().resolve()
    return Path(entry["path"]).expanduser().resolve()
