"""
Licence token — encode / decode / verify.

FTR-MSO-2026-0451 (PLAN-PLN-MSO-2026-0450 §3 D1, §4, §4.2, §4.3).

A licence token is a single copy-pasteable string::

    MSO1.<base64url(canonical-JSON payload)>.<base64url(64-byte Ed25519 signature)>

Sign only (Captain ruling D1) — the payload must be legible to the client that
enforces it (tier gates, expiry banner, `mso licence status`), so encryption would
protect nothing; only a signature stops forgery. The Ed25519 + canonical-JSON math
is reused wholesale from ``maestro.governance.verify`` (pure-Python RFC 8032 with a
transparent ``cryptography`` fast path) rather than reimplemented.

The trust root is closed (Captain ruling D2, ``maestro.licence.keys`` — vendor-only,
no workspace / home / env channel). This is the property that makes a licence token
different from a signed governance policy bundle: nothing short of a new package
release can add a key a licence can be trusted against.

Verification path (§4.3), implemented here up to (not including) revocation
(§6, deferred to a later order — FTR-MSO-2026-0455):

    token --split--> payload_b64, sig_b64
        |-- decode + json.loads (reject: bad base64, bad JSON, unknown schemaVersion)
        |-- resolve_licence_key(payload["keyId"])   <- vendor keyring ONLY
        |-- verify(pubkey, canonical_bytes(payload), sig)
        |-- notBefore <= now                        <- clock-skew tolerance: 24h
        `-- now <= expiresAt

Every failure raises a specific, typed error so the caller (and eventually the CLI)
can give an actionable message: :class:`~maestro.licence.errors.LicenceMalformed`
(not a token), :class:`~maestro.licence.errors.LicenceUntrusted` (unknown/revoked
key), :class:`~maestro.licence.errors.LicenceForged` (signature mismatch), or the
existing :class:`~maestro.licence.errors.LicenceExpired` (outside the payload's
validity window). There is no permissive default — an unrecognised failure mode is
a bug in this module, not a reason to return a payload.
"""
from __future__ import annotations

import base64
import binascii
import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from maestro.governance import verify as _verify
from maestro.licence import grace as _grace
from maestro.licence.errors import LicenceExpired, LicenceForged, LicenceMalformed
from maestro.licence.keys import resolve_licence_key

MSO1_PREFIX = "MSO1."
SCHEMA_VERSION = 1

# §2a D3 (Captain ruling, OVERRIDES the plan's original two-tier proposal).
VALID_TIERS = ("community", "pro", "team", "enterprise")

# §4.3: notBefore tolerates 24h of clock skew; expiresAt does not (post-expiry
# grace is a caller-level UX concern — see maestro.licence.grace — not a token
# primitive concern).
CLOCK_SKEW = timedelta(hours=24)


# ---------------------------------------------------------------------------
# base64url helpers (unpadded, URL-safe — the token's own encoding, distinct
# from the base64 used inside governance/keys.py for public-key material)
# ---------------------------------------------------------------------------

def _b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _b64url_decode(value: str, what: str) -> bytes:
    if not isinstance(value, str) or not value:
        raise LicenceMalformed(f"licence token {what} segment is empty")
    padded = value + "=" * (-len(value) % 4)
    try:
        return base64.urlsafe_b64decode(padded.encode("ascii"))
    except (binascii.Error, ValueError) as exc:
        raise LicenceMalformed(
            f"licence token {what} segment is not valid base64url: {exc}"
        ) from exc


def _split(token: str) -> tuple[str, str]:
    """Return ``(payload_b64, sig_b64)`` after stripping the ``MSO1.`` prefix."""
    if not isinstance(token, str) or not token.startswith(MSO1_PREFIX):
        raise LicenceMalformed(
            f"not a Maestro licence token (expected the '{MSO1_PREFIX}' prefix)"
        )
    rest = token[len(MSO1_PREFIX):]
    parts = rest.split(".")
    if len(parts) != 2 or not parts[0] or not parts[1]:
        raise LicenceMalformed(
            "malformed licence token: expected 'MSO1.<payload>.<signature>'"
        )
    return parts[0], parts[1]


def _parse_ts(value: Any, field_name: str) -> datetime:
    if not isinstance(value, str) or not value:
        raise LicenceMalformed(f"licence token '{field_name}' is missing or not a string")
    try:
        return _grace.parse_iso(value)
    except Exception as exc:  # noqa: BLE001 — an unparseable timestamp is malformed input
        raise LicenceMalformed(
            f"licence token '{field_name}' is not a valid ISO-8601 timestamp: {value!r}"
        ) from exc


def _decode_parts(token: str) -> tuple[dict[str, Any], bytes, bytes]:
    """Structural parse only: ``(payload, canonical_payload_bytes, signature_bytes)``.

    Does not resolve a key, verify the signature, or check any time bound. Raises
    :class:`LicenceMalformed` for anything not shaped like a v1 licence token.
    """
    payload_b64, sig_b64 = _split(token)
    canonical = _b64url_decode(payload_b64, "payload")
    try:
        payload = json.loads(canonical)
    except Exception as exc:  # noqa: BLE001
        raise LicenceMalformed(f"licence token payload is not valid JSON: {exc}") from exc
    if not isinstance(payload, dict):
        raise LicenceMalformed("licence token payload must be a JSON object")

    schema_version = payload.get("schemaVersion")
    if schema_version != SCHEMA_VERSION:
        raise LicenceMalformed(
            f"unsupported licence schemaVersion {schema_version!r} — this Maestro "
            f"build understands schemaVersion {SCHEMA_VERSION}"
        )

    sig = _b64url_decode(sig_b64, "signature")
    if len(sig) != 64:
        raise LicenceMalformed(
            f"licence token signature must be 64 bytes, got {len(sig)}"
        )
    return payload, canonical, sig


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def encode(payload: dict[str, Any], seed: bytes) -> str:
    """Sign ``payload`` and return an ``MSO1.`` licence token.

    Off-client authoring only (mirrors ``governance.signing.sign_bundle``): the
    Ed25519 seed never touches a client runtime. Here purely for the test suite
    and future issuer tooling (``mso licence issue``, FTR-MSO-2026-0453).

    ``payload`` must already carry ``schemaVersion`` (must equal
    :data:`SCHEMA_VERSION`), a ``tier`` from :data:`VALID_TIERS`, and a ``keyId``
    identifying which licence-keyring entry will verify it — these are cheap
    authoring-time sanity checks, not the fail-closed trust-root enforcement
    :func:`verify` performs on tokens accepted from the outside world.
    """
    if not isinstance(payload, dict):
        raise ValueError("licence payload must be a dict")
    if payload.get("schemaVersion") != SCHEMA_VERSION:
        raise ValueError(f"licence payload schemaVersion must be {SCHEMA_VERSION}")
    if payload.get("tier") not in VALID_TIERS:
        raise ValueError(f"licence payload tier must be one of {VALID_TIERS}")
    if not payload.get("keyId"):
        raise ValueError("licence payload must include 'keyId'")

    canonical = _verify.canonical_bytes(payload)
    sig = _verify.sign(seed, canonical)
    return f"{MSO1_PREFIX}{_b64url_encode(canonical)}.{_b64url_encode(sig)}"


def decode(token: str) -> dict[str, Any]:
    """Parse a token's structure and return its payload, UNVERIFIED.

    Confirms the token is shaped like a v1 Maestro licence token (base64url,
    JSON, a supported ``schemaVersion``, a well-formed signature segment) but
    performs no trust or temporal check. Callers must not act on this payload as
    if it were authenticated — use :func:`verify` for anything that gates
    behaviour.
    """
    payload, _canonical, _sig = _decode_parts(token)
    return payload


def verify(
    token: str,
    *,
    now: datetime | None = None,
    keyring_path: Path | None = None,
) -> dict[str, Any]:
    """Decode, authenticate, and time-bound-check a licence token.

    Returns the verified payload only when every check passes:
    structurally-valid token -> known/usable vendor key -> matching Ed25519
    signature -> within ``notBefore``/``expiresAt``. Raises
    :class:`~maestro.licence.errors.LicenceMalformed`,
    :class:`~maestro.licence.errors.LicenceUntrusted`,
    :class:`~maestro.licence.errors.LicenceForged`, or
    :class:`~maestro.licence.errors.LicenceExpired` otherwise — never a
    permissive default.

    ``keyring_path`` is a test-only injection point forwarded to
    :func:`maestro.licence.keys.resolve_licence_key`; production callers never
    pass it.
    """
    now = now or datetime.now(timezone.utc)
    payload, canonical, sig = _decode_parts(token)

    tier = payload.get("tier")
    if tier not in VALID_TIERS:
        raise LicenceMalformed(
            f"unknown licence tier {tier!r}; must be one of {VALID_TIERS}"
        )

    key_id = payload.get("keyId")
    if not key_id or not isinstance(key_id, str):
        raise LicenceMalformed("licence token payload missing 'keyId'")

    key = resolve_licence_key(key_id, now=now, keyring_path=keyring_path)

    if not _verify.verify(key.public_key, canonical, sig):
        raise LicenceForged(
            f"signature verification FAILED for licence "
            f"'{payload.get('licenceId', '<unknown>')}' (keyId={key_id}). The token "
            "has been tampered with, or was signed by a different key — refusing "
            "to trust it."
        )

    # Copilot review on PR #317: these were guarded by truthiness, so a SIGNED
    # token with a missing or empty expiresAt skipped the expiry check entirely
    # and was valid forever. Expiry is the ONLY enforcement an offline licence
    # has — there is no server to revoke against — and the whole tier-dependent
    # expiry policy (PLAN-PLN-MSO-2026-0450 §D3b: trial/pro downgrade,
    # team/enterprise stop) is unreachable if the field is optional. Both fields
    # are REQUIRED; absent or empty is malformed, never permissive.
    not_before = payload.get("notBefore")
    if not not_before:
        raise LicenceMalformed(
            "licence payload is missing a notBefore timestamp — a token without "
            "a validity start cannot be time-bound"
        )
    nb = _parse_ts(not_before, "notBefore")
    if now < nb - CLOCK_SKEW:
        raise LicenceExpired(
            f"licence is not valid until {not_before} (current time "
            f"{now.isoformat()})"
        )

    expires_at = payload.get("expiresAt")
    if not expires_at:
        raise LicenceMalformed(
            "licence payload is missing an expiresAt timestamp — a token "
            "without an expiry would never expire"
        )
    exp = _parse_ts(expires_at, "expiresAt")
    if now > exp:
        raise LicenceExpired(f"licence expired at {expires_at}")

    return payload
