"""Licence-system error hierarchy.

Surfaces in the CLI as exit codes and human-readable messages.
"""

from __future__ import annotations


class LicenceError(Exception):
    """Base class for all licence-system errors."""


class LicenceMissing(LicenceError):
    """No licence file is present — user has not run `mso licence activate`."""

    def __init__(self) -> None:
        super().__init__(
            "No licence found. Run `mso licence activate <KEY>` to start."
        )


class LicenceInvalid(LicenceError):
    """Polar rejected the key as invalid (key not found, malformed, etc.)."""


class LicenceRevoked(LicenceError):
    """Polar reported the key as revoked (cancelled or refunded subscription)."""


class LicenceExpired(LicenceError):
    """Licence has expired (or grace window has elapsed without revalidation)."""


class LicenceTampered(LicenceError):
    """Stored licence file's signature does not match — file has been
    edited or copied from another machine without the keychain secret.
    """

    def __init__(self) -> None:
        super().__init__(
            "Licence file signature mismatch. The file may have been edited "
            "or copied from another machine. Re-run `mso licence activate <KEY>` "
            "to recover."
        )


class LicenceMalformed(LicenceError):
    """A licence token is not shaped like a valid Maestro licence token.

    Covers everything that fails before a signature is even checked: wrong
    prefix, wrong number of parts, bad base64, bad JSON, an unsupported
    ``schemaVersion``, an unknown ``tier``, or a missing ``keyId``.
    """


class LicenceUntrusted(LicenceError):
    """A licence token's ``keyId`` is not a usable key in the vendor licence
    keyring — unknown, revoked, or past its ``notAfter``.

    Raised only by ``maestro.licence.keys.resolve_licence_key`` (a closed,
    vendor-only trust root — see FTR-MSO-2026-0451 / PLAN-PLN-MSO-2026-0450
    §4.2). This is never raised because of a key pinned in a workspace, the
    user home, or an environment variable — none of those are consulted.
    """


class LicenceForged(LicenceError):
    """A licence token's Ed25519 signature does not match its payload.

    The offline-token analogue of ``LicenceTampered`` (FTR-MSO-2026-0451).
    Raised when the payload has been altered after signing, or was signed by
    a different key than the one its ``keyId`` claims.
    """
