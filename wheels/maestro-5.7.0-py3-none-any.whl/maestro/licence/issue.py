"""
Licence issuer tooling — ``mso licence keygen`` / ``mso licence issue``.

FTR-MSO-2026-0453 (PLAN-PLN-MSO-2026-0450 §10 order FTR-0453, §11 private-key
custody — the explicit guarantee).

This module is OFF-CLIENT authoring tooling for a Maestro Admin (someone with
access to Maestro's private source). It is never imported by the runtime
verification path (``maestro.licence.token.verify`` /
``maestro.licence.keys.resolve_licence_key``), which only ever handles public
keys — the private seed this module generates and consumes never appears on a
customer machine.

Mirrors the shape already proven by ``maestro.identity.integrity``
(``decode_seed`` / ``resolve_signing_seed`` / ``mso identity sign-acl``): the
Ed25519 seed lives off-client and is supplied only at signing time via
``--key-file`` or an env var, never persisted into a workspace.

§11 IS NON-NEGOTIABLE — the private seed must never enter the wheel or the
repository. ``keygen`` refuses to write its output inside a git working tree
or a ``.mso/`` workspace: generation happens somewhere else entirely (the
operator's password manager or an offline secrets store), never inside a
clone of this repo. That refusal is the mechanism; ``tests/test_licence_issue.py``
(including a guard that builds the actual wheel and inspects its contents) is
the mechanical proof the guarantee held — "a guarantee nobody checks is not a
guarantee" (order FTR-MSO-2026-0453).

Community-tier decision (D3a, Captain 2026-08-04): community is free and
requires NO licence at all, so :func:`issue` REFUSES to mint one. There is
nothing a community "licence" would grant that isn't already available with
no licence installed — see the refusal message in :func:`issue` for the full
rationale. DOC-MSO-2026-0457 should surface this in the customer-facing
``maestro/docs/LICENCE.md`` rewrite; recorded here (and in this order's
handoff) in the meantime.
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
import uuid
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Sequence

from maestro.governance import verify as _verify
from maestro.workspace import MSO_DIR_NAME  # FTR-MSO-2026-0362: no hand-built literal
from maestro.identity.integrity import decode_seed
from maestro.licence import grace as _grace
from maestro.licence import token as _token
from maestro.licence.token import VALID_TIERS

# Off-client SIGNING seed channel — distinct from every licence VERIFICATION
# channel. maestro.licence.keys resolves PUBLIC keys only, from the vendor
# file only, with no env channel at all (see maestro/licence/keys.py — that
# closed trust root is the whole point of Captain ruling D2). This env var
# carries the PRIVATE seed and is read only by this authoring module, never
# by the runtime verification path.
SIGNING_SEED_ENV = "MAESTRO_LICENCE_SIGNING_KEY"

DEFAULT_TERM_DAYS = 365

# Tiers this tool will mint. Community is deliberately excluded — see
# module docstring and the refusal in issue().
ISSUABLE_TIERS: tuple[str, ...] = tuple(t for t in VALID_TIERS if t != "community")

# Default entitlement grants per tier when --entitlements is not supplied.
# `entitlements` remains the actual enforcement surface (a specific deal can
# grant or withhold one feature without inventing a tier, per PLAN §5.2) —
# these are just sane defaults so an operator does not have to spell out the
# common case by hand every time.
DEFAULT_ENTITLEMENTS: dict[str, tuple[str, ...]] = {
    "pro": (),
    "team": ("hub", "shared-artefacts", "packs.team"),
    "enterprise": ("hub", "shared-artefacts", "packs.team", "packs.enterprise", "policy-bundles"),
}

REGISTER_FIELDS = (
    "licenceId", "licensee", "contact", "tier", "entitlements", "seats",
    "issuedAt", "expiresAt", "keyId", "tokenSha256",
)


class LicenceIssueError(Exception):
    """Refused to keygen/issue — an operator-facing, actionable error."""


@dataclass(frozen=True)
class IssuedLicence:
    token: str
    payload: dict[str, Any]


# ---------------------------------------------------------------------------
# keygen
# ---------------------------------------------------------------------------

def _refuse_if_protected(out_path: Path) -> None:
    """Refuse a seed-output path inside a git working tree or `.mso/` workspace.

    §11 point 1: generation happens off-repo. Walks the target's directory
    ancestry (the file need not exist yet — only its parent directory is
    inspected) looking for a `.git` entry or a directory literally named
    `.mso` anywhere above it.
    """
    target_dir = out_path.expanduser().resolve().parent
    for candidate in (target_dir, *target_dir.parents):
        if (candidate / ".git").exists():
            raise LicenceIssueError(
                f"refusing to write a signing seed inside a git working tree "
                f"(found {candidate / '.git'}). Generate the seed OUTSIDE any "
                "repository — a password manager, an offline secrets store, "
                "or a plain directory that is never committed "
                "(PLAN-PLN-MSO-2026-0450 §11 point 1)."
            )
        if candidate.name == MSO_DIR_NAME:
            raise LicenceIssueError(
                f"refusing to write a signing seed inside a Maestro workspace "
                f"({candidate}). Generate the seed somewhere outside any "
                "`.mso/` workspace (PLAN-PLN-MSO-2026-0450 §11 point 1)."
            )


def keygen(out_path: "str | Path") -> tuple[bytes, str]:
    """Generate a new Ed25519 licence-signing seed. Returns ``(seed, public_key_b64)``.

    Writes ONLY the seed — base64, single line, no comment or label, matching
    the plain-text convention ``maestro.identity.integrity.decode_seed``
    already expects — to ``out_path``, mode 0600 where the platform supports
    it. The seed is never printed, logged, or returned to a caller that would
    echo it; only the caller's CLI layer decides what to print, and it must
    print the public key only.

    Refuses (via :func:`_refuse_if_protected`) BEFORE generating anything, so
    a refusal never leaves partially-written key material on disk. Also
    refuses to silently overwrite an existing file — clobbering a seed that
    licences may already have been issued under is not a recoverable mistake.
    """
    out_path = Path(out_path)
    _refuse_if_protected(out_path)
    if out_path.exists():
        raise LicenceIssueError(
            f"refusing to overwrite an existing file: {out_path}. Choose a new "
            "path — overwriting a signing seed risks silently discarding key "
            "material that licences may already have been issued under."
        )

    seed = os.urandom(32)
    public_key = _verify.public_key_from_seed(seed)

    out_path.parent.mkdir(parents=True, exist_ok=True)
    seed_b64 = base64.b64encode(seed).decode("ascii")
    out_path.write_text(seed_b64, encoding="utf-8")
    try:
        os.chmod(out_path, 0o600)
    except OSError:
        pass  # best-effort — platforms without POSIX permission bits (e.g. Windows)

    return seed, base64.b64encode(public_key).decode("ascii")


# ---------------------------------------------------------------------------
# Seed resolution for `issue` — supply at signing time only (§11 point 3)
# ---------------------------------------------------------------------------

def resolve_signing_seed(
    key_file: "str | Path | None" = None,
    env: "dict | None" = None,
) -> bytes:
    """Resolve the licence-signing Ed25519 seed from ``--key-file`` or the env channel.

    Mirrors ``maestro.identity.integrity.resolve_signing_seed`` exactly (§11
    point 3) — same precedence (an explicit file wins), same fail-closed
    ``decode_seed`` validation, same "never persisted into a workspace"
    guarantee. Kept as a distinct function (not a re-export) because the env
    var name is licence-specific (``MAESTRO_LICENCE_SIGNING_KEY``, not
    ``MAESTRO_IDENTITY_SIGNING_KEY``) — conflating the two would let an
    identity-signing seed silently double as a licence-signing seed, an
    equivalence nothing in the design asserts.
    """
    env = env if env is not None else os.environ
    if key_file is not None:
        p = Path(key_file)
        if not p.exists():
            raise LicenceIssueError(f"signing key file not found: {p}")
        try:
            return decode_seed(p.read_text(encoding="utf-8"))
        except ValueError as exc:
            raise LicenceIssueError(f"signing key file is invalid: {exc}") from exc

    raw = env.get(SIGNING_SEED_ENV, "")
    if raw.strip():
        try:
            return decode_seed(raw)
        except ValueError as exc:
            raise LicenceIssueError(f"{SIGNING_SEED_ENV} is invalid: {exc}") from exc

    raise LicenceIssueError(
        "no signing seed provided — pass --key-file PATH or set "
        f"{SIGNING_SEED_ENV} to the licence-signing Ed25519 seed (base64 or hex, 32 bytes)"
    )


# ---------------------------------------------------------------------------
# issue
# ---------------------------------------------------------------------------

def _iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _coerce_dt(value: "str | datetime") -> datetime:
    if isinstance(value, datetime):
        return value if value.tzinfo else value.replace(tzinfo=timezone.utc)
    return _grace.parse_iso(value)


def _generate_licence_id(now: datetime) -> str:
    # uuid4-derived suffix — globally unique with no shared counter to manage
    # across machines/operators, unlike a sequential "lic_2026_0007" scheme.
    return f"lic_{now.year}_{uuid.uuid4().hex[:8]}"


def issue(
    *,
    tier: str,
    licensee_name: str,
    contact: str,
    key_id: str,
    seed: bytes,
    seats: int = 1,
    entitlements: "Sequence[str] | None" = None,
    term_days: int = DEFAULT_TERM_DAYS,
    expires_at: "str | datetime | None" = None,
    not_before: "str | datetime | None" = None,
    licence_id: "str | None" = None,
    now: "datetime | None" = None,
) -> IssuedLicence:
    """Mint a signed licence token for ``tier``.

    Off-client authoring only — takes the seed directly (resolve it first via
    :func:`resolve_signing_seed`); this function never resolves a seed itself,
    so a caller cannot accidentally source one from an unexpected channel.

    ``tier="community"`` is REFUSED — see the module docstring's D3a note.
    ``expires_at`` overrides ``term_days`` when given. Every timestamp is
    computed from ``now`` (or ``datetime.now(UTC)`` if not supplied), so the
    whole function is deterministic under test.
    """
    if tier == "community":
        raise LicenceIssueError(
            "refusing to issue a 'community' licence: community is free and "
            "requires NO licence at all (Captain ruling D3a, "
            "PLAN-PLN-MSO-2026-0450 §2a). An unlicensed install already runs "
            "at community tier with no activation step — there is nothing a "
            "community 'licence' token would grant that isn't already true "
            "with no licence installed. Issue 'pro', 'team', or 'enterprise' "
            "instead."
        )
    if tier not in ISSUABLE_TIERS:
        raise LicenceIssueError(f"tier must be one of {ISSUABLE_TIERS}, got {tier!r}")
    if seats < 1:
        raise LicenceIssueError("seats must be >= 1")
    if not licensee_name or not licensee_name.strip():
        raise LicenceIssueError("licensee_name must not be empty")
    if not contact or not contact.strip():
        raise LicenceIssueError("contact must not be empty")
    if not key_id:
        raise LicenceIssueError("key_id is required (which licence-keys.json entry will verify this token)")

    now = now or datetime.now(timezone.utc)
    nb = _coerce_dt(not_before) if not_before is not None else now
    if expires_at is not None:
        exp = _coerce_dt(expires_at)
    else:
        exp = nb + timedelta(days=term_days)
    if exp <= nb:
        raise LicenceIssueError(
            f"expiresAt ({_iso(exp)}) must be after notBefore ({_iso(nb)})"
        )

    resolved_entitlements = (
        list(entitlements) if entitlements is not None
        else list(DEFAULT_ENTITLEMENTS.get(tier, ()))
    )

    payload = {
        "schemaVersion": _token.SCHEMA_VERSION,
        "licenceId": licence_id or _generate_licence_id(now),
        "tier": tier,
        "entitlements": sorted(set(resolved_entitlements)),
        "licensee": {"name": licensee_name, "contact": contact},
        "seats": seats,
        "issuedAt": _iso(now),
        "notBefore": _iso(nb),
        "expiresAt": _iso(exp),
        "keyId": key_id,
    }
    tok = _token.encode(payload, seed)
    return IssuedLicence(token=tok, payload=payload)


# ---------------------------------------------------------------------------
# Issuance register (§11.3) — append-only JSONL, no key material
# ---------------------------------------------------------------------------

def append_to_register(register_path: "str | Path", issued: IssuedLicence) -> dict[str, Any]:
    """Append one issuance record to the append-only JSONL register (§11.3).

    Records ``licenceId``, ``licensee``, ``contact``, ``tier``,
    ``entitlements``, ``seats``, ``issuedAt``, ``expiresAt``, ``keyId``, and
    ``tokenSha256`` (a hash of the issued token for support/audit
    correlation — never the token or any key material). Not shipped in the
    wheel or the public repo; the caller (``mso licence issue --register
    PATH``) points this at the private Maestro-Admin artefact store.

    Returns the record that was written.
    """
    p = issued.payload
    record = {
        "licenceId": p["licenceId"],
        "licensee": p["licensee"]["name"],
        "contact": p["licensee"]["contact"],
        "tier": p["tier"],
        "entitlements": p["entitlements"],
        "seats": p["seats"],
        "issuedAt": p["issuedAt"],
        "expiresAt": p["expiresAt"],
        "keyId": p["keyId"],
        "tokenSha256": hashlib.sha256(issued.token.encode("ascii")).hexdigest(),
    }
    register_path = Path(register_path)
    register_path.parent.mkdir(parents=True, exist_ok=True)
    with open(register_path, "a", encoding="utf-8") as fh:
        fh.write(json.dumps(record, sort_keys=True) + "\n")
    return record
