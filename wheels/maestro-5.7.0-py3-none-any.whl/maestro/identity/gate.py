from __future__ import annotations

import json
import sys
from pathlib import Path

from .types import Capability, Scope


class CapabilityDenied(RuntimeError):
    """Raised when the resolved caller lacks a required capability."""

    def __init__(self, actor: str, capability: str, scope: str, reason: str) -> None:
        self.actor = actor
        self.capability = capability
        self.scope = scope
        self.reason = reason
        super().__init__(f"permission denied: {actor} lacks {capability} (scope: {scope})")


def _load_enterprise_flag(workspace: Path) -> bool:
    """Read workspace.json and return whether the ``enterprise`` flag is enabled.

    This reads ONLY the (attacker-writable) ``enterprise`` key. It is deliberately
    NOT the capability-gate's activation decision — see :func:`_acl_enforcement_active`,
    which additionally consults the dispatcher-stamped ``MAESTRO_GOVERNED`` so a crew
    cannot downgrade out of the ACL by rewriting ``workspace.json`` (BUG-MSO-2026-0409).
    """
    from maestro.workspace import resolve_artefact_dir
    ws_cfg = resolve_artefact_dir(workspace) / "config" / "workspace.json"
    if not ws_cfg.exists():
        return False
    try:
        data = json.loads(ws_cfg.read_text(encoding="utf-8"))
        flag = data.get("enterprise", False)
        # Support both bool and nested dict (future-proofing)
        if isinstance(flag, bool):
            return flag
        if isinstance(flag, dict):
            return True  # presence of the object implies enterprise
        return bool(flag)
    except Exception:
        return False


def _acl_enforcement_active(workspace: Path) -> bool:
    """Whether the capability ACL must be enforced for this call.

    BUG-MSO-2026-0409 F1 (was CRITICAL): the gate previously returned pass-through
    whenever ``workspace.json``'s ``enterprise`` key was false — but that file is
    writable by the very crew being governed, so a crew could write
    ``{"enterprise": false}`` (or delete the file, or set ``governedMode: off``) and
    the capability gate would then consult NO ACL at all — a full downgrade.

    Enforcement is now anchored to governed-enforce mode as well. ``resolve_governed_mode``
    treats the dispatcher-stamped ``MAESTRO_GOVERNED`` env var as authoritative (a crew
    cannot set it on its own parent process), so when a governed crew is running the ACL
    is FORCED on regardless of ``workspace.json``. Legacy plain-enterprise activation
    (the ``enterprise`` flag) still applies for non-governed enterprise workspaces.
    """
    if _load_enterprise_flag(workspace):
        return True
    try:
        from maestro.governance import resolve_governed_mode
        return resolve_governed_mode(workspace) == "enforce"
    except Exception:
        # A resolution error must not silently disable the gate; but with no
        # enterprise flag and no resolvable governed mode there is nothing to enforce.
        return False


def require_capability(
    capability: Capability,
    scope: Scope = "*",
    *,
    workspace: Path | None = None,
) -> None:
    """
    Resolve the caller, check the ACL, and raise CapabilityDenied if check fails.
    No-op when enterprise mode is disabled.

    Args:
        capability: The capability required for the operation.
        scope: The scope for the check (e.g. '*', 'project:PSG').
        workspace: Workspace root. Detected from cwd if not provided.
    """
    if workspace is None:
        # Walk up from cwd looking for any workspace artefact dir
        from pathlib import Path as _Path
        from maestro.workspace import find_workspace_dir
        cwd = _Path.cwd()
        mso = find_workspace_dir(cwd)
        workspace = mso.parent if mso is not None else cwd

    if not _acl_enforcement_active(workspace):
        return  # neither enterprise nor governed-enforce: pass-through

    from maestro.workspace import resolve_artefact_dir
    identity_dir = resolve_artefact_dir(workspace) / "identity"
    acl_path = identity_dir / "access.json"
    groups_dir = identity_dir / "groups"

    # BUG-MSO-2026-0409: any identity-integrity failure raised while resolving the
    # caller or the ACL is a fail-closed signal — deny rather than let the exception
    # crash open past the guard. In enforce mode a forged/unsigned trust anchor lands
    # here and must refuse the capability.
    from .integrity import IdentityIntegrityError
    try:
        from .auth import resolve_caller
        actor = resolve_caller(workspace, enterprise=True)

        if actor == "anonymous":
            _deny(actor, capability, scope, "anonymous callers are not permitted in enterprise mode")

        from .acl import resolve_capability as _resolve
        allowed = _resolve(
            actor=actor,
            capability=capability,
            scope=scope,
            acl_path=acl_path,
            groups_dir=groups_dir,
        )

        if not allowed:
            _deny(
                actor,
                capability,
                scope,
                "caller is not in a group with this capability",
            )

        # Check restriction flag (Article 18 — right to restriction)
        email = actor.removeprefix("user:")
        from .rights import is_restricted
        if is_restricted(email, workspace):
            _deny(actor, capability, scope, "identity is restricted (GDPR Article 18)")
    except IdentityIntegrityError as exc:
        _deny(
            "unknown",
            capability,
            scope,
            f"identity integrity could not be verified — failing closed ({exc.reason})",
        )


def _deny(actor: str, capability: str, scope: str, reason: str) -> None:
    print(
        f"\nError: permission denied\n"
        f"  Caller  : {actor}\n"
        f"  Requires: {capability} (scope: {scope})\n"
        f"  Reason  : {reason}\n"
        f"  Fix     : ask a Captain to grant {capability} in .mso/identity/access.json\n",
        file=sys.stderr,
    )
    raise SystemExit(1)
