#!/usr/bin/env python3
"""
Fleet Bridge Question Hook v2.0 — Relay AskUserQuestion to Slack and back.

Triggers on PreToolUse with matcher 'AskUserQuestion'. Reads the question text
from stdin JSON (tool_input field), relays it to the Captain via Slack
(BridgeNotifier.send_question), then BLOCKS waiting for the Captain's reply.

Two-way loop:
  1. Hook fires -> writes .mso/bridge/qm-question.json and posts the question
     to Slack (project channel, falling back to defaultChannel).
  2. Captain replies with `/adm reply <text>` on their phone. The Slack bot
     writes the command to the gist; the poller executes `qm_response`, which
     writes .mso/bridge/qm-response.json.
  3. This hook polls qm-response.json. On a fresh matching reply it emits a
     PreToolUse `deny` decision whose `reason` carries the Captain's answer,
     so the paused Claude session receives the answer and proceeds WITHOUT
     rendering the local interactive picker.

Delivery is via block-feedback text, not a native selection object: Claude
receives the Captain's reply as guidance and continues. This is the best the
hook model allows.

Timing: the round trip (notify -> read -> /adm reply -> ~30s poll) far exceeds
a fast hook timeout, so the AskUserQuestion hook `timeout` in .claude/settings
must be raised to accommodate the blocking wait (see the wait budget below).

Fail-open: on ANY error, or if no reply arrives within the wait budget, the
hook exits 0 with no output — the local interactive picker renders so a human
at the device can still answer. It NEVER blocks the AskUserQuestion call
permanently.

Limitations:
  - One outstanding QM question per project at a time (a blocked session holds
    exactly one). A stale reply from a prior question is rejected by timestamp.
  - On timeout the Captain's later reply is ignored; the local human answers.
"""

import json
import os
import sys
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional


# Default seconds to block waiting for the Captain's reply. Kept below the
# AskUserQuestion hook `timeout` in .claude/settings.json (600s) so the hook
# returns cleanly (fail-open) before the harness force-kills it. Overridable
# via bridge-settings.json -> bridge.notifications.qmResponseTimeoutSeconds.
DEFAULT_WAIT_SECONDS = 570
POLL_INTERVAL_SECONDS = 2.0


def _parse_iso(ts: str) -> Optional[datetime]:
    """Parse an ISO-8601 timestamp (tolerating a trailing 'Z') to aware UTC."""
    if not ts:
        return None
    try:
        if ts.endswith("Z"):
            ts = ts[:-1] + "+00:00"
        dt = datetime.fromisoformat(ts)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except (ValueError, TypeError):
        return None


def wait_for_qm_response(
    bridge_dir: Path,
    dispatched_at: str,
    project: str,
    timeout: float,
    interval: float = POLL_INTERVAL_SECONDS,
) -> Optional[str]:
    """Block until a fresh, matching Captain reply lands in qm-response.json.

    A reply is accepted only when its ``timestamp`` is strictly newer than
    ``dispatched_at`` (rejecting a stale reply left from a prior question) and
    its ``project`` matches (or either side is unset). On acceptance the
    response file is consumed (removed) and its text returned. Returns None on
    timeout.
    """
    response_path = bridge_dir / "qm-response.json"
    dispatched_dt = _parse_iso(dispatched_at)
    deadline = time.monotonic() + max(0.0, timeout)

    while True:
        try:
            if response_path.exists():
                data = json.loads(response_path.read_text(encoding="utf-8"))
                text = (data.get("response") or data.get("text") or "").strip()
                resp_ts = _parse_iso(data.get("timestamp", ""))
                resp_project = (data.get("project") or "").upper()

                if dispatched_dt is None:
                    # We couldn't stamp our own dispatch time (should not happen);
                    # we initiated the question, so accept rather than deadlock.
                    fresh = True
                elif resp_ts is None:
                    # We have a baseline but the reply's timestamp is missing or
                    # unparseable — we cannot confirm it is newer, so reject it
                    # (fail-safe: the local picker still answers on timeout).
                    fresh = False
                else:
                    fresh = resp_ts > dispatched_dt
                project_ok = (
                    not project
                    or not resp_project
                    or resp_project == project.upper()
                )

                if text and fresh and project_ok:
                    # Consume so the next question doesn't re-read this reply.
                    try:
                        response_path.unlink()
                    except OSError:
                        pass
                    return text
        except (json.JSONDecodeError, OSError):
            pass  # transient read/parse race — retry on the next tick

        if time.monotonic() >= deadline:
            return None
        time.sleep(interval)


def _wait_budget(settings: dict) -> float:
    """Resolve the blocking wait budget from bridge settings (or the default)."""
    try:
        val = (
            settings.get("bridge", {})
            .get("notifications", {})
            .get("qmResponseTimeoutSeconds")
        )
        if val is not None:
            return float(val)
    except (AttributeError, TypeError, ValueError):
        pass
    return float(DEFAULT_WAIT_SECONDS)


def main():
    try:
        raw_input = sys.stdin.read()
        hook_input = json.loads(raw_input) if raw_input.strip() else {}
    except Exception:
        sys.exit(0)

    try:
        tool_input = hook_input.get("tool_input", {})
        question_text = tool_input.get("question", "")
        if not question_text:
            sys.exit(0)

        # Resolve maestro dir relative to cwd
        cwd = hook_input.get("cwd", os.getcwd())
        from maestro.hooks import find_mso_root
        workspace = find_mso_root(cwd)
        if workspace is None:
            sys.exit(0)  # Not an Admiralty workspace — no-op
        from maestro.workspace import resolve_artefact_dir
        admiralty_dir = resolve_artefact_dir(workspace)

        from maestro.core.bridge_notifier import BridgeNotifier
        notifier = BridgeNotifier(admiralty_dir)

        if not notifier.enabled:
            sys.exit(0)

        project = (os.environ.get("MAESTRO_PROJECT") or "").upper()

        bridge_dir = admiralty_dir / "bridge"
        bridge_dir.mkdir(parents=True, exist_ok=True)
        dispatched_at = datetime.now(timezone.utc).isoformat()
        question_id = uuid.uuid4().hex

        # Record the outstanding question so the poller/response can correlate.
        try:
            (bridge_dir / "qm-question.json").write_text(
                json.dumps(
                    {
                        "id": question_id,
                        "question": question_text,
                        "project": project,
                        "dispatchedAt": dispatched_at,
                    },
                    indent=2,
                ),
                encoding="utf-8",
            )
        except OSError:
            pass  # non-fatal — correlation is best-effort

        # Relay outbound (project-aware channel routing after the Fix 3 dedup).
        notifier.send_question(question_text, project=project)

        # Block for the Captain's reply.
        timeout = _wait_budget(getattr(notifier, "settings", {}) or {})
        answer = wait_for_qm_response(bridge_dir, dispatched_at, project, timeout)

        # Clear the outstanding-question marker on BOTH paths (answered or timed
        # out). If a timed-out question left the marker behind, the poller would
        # stamp a later /adm reply with this stale question's project/id.
        try:
            (bridge_dir / "qm-question.json").unlink()
        except OSError:
            pass

        if answer:
            print(json.dumps({
                "decision": "deny",
                "reason": (
                    f"The Captain answered via Slack: {answer}. "
                    "Treat this as the answer to your question and proceed."
                ),
            }))
            sys.exit(0)

        # Timeout: fall through to fail-open (local interactive picker renders).
    except Exception:
        pass  # Fail-open

    sys.exit(0)


if __name__ == "__main__":
    main()
