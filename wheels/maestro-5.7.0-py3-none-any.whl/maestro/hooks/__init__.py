# maestro.hooks — Claude Code hooks

from pathlib import Path

from maestro.workspace import get_workspace_dir


def find_mso_root(start_dir: str) -> "Path | None":
    """Resolve the Maestro workspace root a crew hook should operate against.

    Delegates to :func:`maestro.workspace.get_workspace_dir`, which checks
    ``MAESTRO_DIR`` BEFORE walking up from *start_dir* (FTR-MSO-2026-0362).

    BUG-MSO-2026-0465: a walk-up-only resolver is wrong for crew hooks. The
    product repo commits ``.mso/`` artefacts to every branch, so a crew's own
    worktree checkout carries its OWN nested ``.mso/config`` — a pure walk-up
    from the crew's cwd stops there instead of reaching the TRUE artefact root,
    so hooks that build write-scope decisions from it (e.g. the SEC
    ``SEC_WRITE_ALLOWED`` gate in ``pretool.py``) approve report writes that
    land in the worktree's own ``.mso`` mirror and are discarded when the
    worktree is pruned. The dispatcher always injects ``MAESTRO_DIR`` (and
    ``MAESTRO_ARTEFACT_ROOT``, an equal value) into every crew subprocess
    (``maestro/core/fleet_runner.py`` ``crew_env``), so checking it first here
    makes hook resolution agree with the dispatcher's own authoritative root.
    Interactive/non-crew sessions (no ``MAESTRO_DIR``) keep the pre-existing
    walk-up-from-cwd behaviour, byte-identical to before.

    Returns the workspace root (the ``.mso`` parent), or None.
    """
    try:
        mso = get_workspace_dir(Path(start_dir).resolve())
    except FileNotFoundError:
        return None
    return mso.parent
