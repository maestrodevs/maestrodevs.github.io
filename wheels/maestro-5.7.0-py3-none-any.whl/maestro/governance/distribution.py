"""
Policy-bundle distribution — ``mso policy pull`` over the artefact-repo channel.

FTR-MSO-2026-0397 (PLAN-PLN-MSO-2026-0372 §3.3 distribution option A).

Option A reuses the same public artefact/wheel-index machinery Maestro already
ships through (``maestrodevs.github.io``). The published bundle is *signed*
(Ed25519), so a public, tamperable index is fine: the client verifies the
signature against a pinned key before it will trust — or persist — a byte of it.

Flow of :func:`pull_bundle`:

  1. Resolve the source URL (arg > ``MAESTRO_POLICY_PULL_URL`` env >
     ``workspace.json`` ``governance.pullUrl`` > vendor default).
  2. Fetch the bundle JSON (stdlib ``urllib`` — zero extra dependency, airgap-
     friendly; a custom ``fetcher`` can be injected for tests/offline mirrors).
  3. Verify signature + anti-rollback + freshness stamp
     (:func:`maestro.governance.signing.verify_signed_bundle`). A tampered or
     downgraded bundle is REJECTED and never written.
  4. Persist to ``<artefact-root>/config/policy-bundle.json`` (path via
     ``maestro.workspace`` resolvers — BUG-0362/0387/0003).

Offline grace: if the fetch fails but a previously-verified bundle is still on
disk AND within its offline-grace window, the pull SUCCEEDS with a warning and
leaves the good bundle in place — mirroring the licence offline-grace precedent.
Outside the grace window the pull fails (fail-closed).
"""
from __future__ import annotations

import json
import urllib.error
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Optional

from maestro.governance.schema import GovernanceError
from maestro.governance import signing as _signing
from maestro.governance import rollback as _rollback

DEFAULT_PULL_URL = "https://maestrodevs.github.io/policy/policy-bundle.json"
_ENV_PULL_URL = "MAESTRO_POLICY_PULL_URL"
_TIMEOUT_SECONDS = 20

Fetcher = Callable[[str], bytes]


@dataclass
class PullResult:
    ok: bool
    bundle_id: str = ""
    version: int = 0
    key_id: str = ""
    source: str = ""          # "network" | "offline-grace"
    path: str = ""
    message: str = ""


def _artefact_root(start: Optional[Path] = None) -> Path:
    from maestro.workspace import get_artefact_root
    return get_artefact_root(start)


def _bundle_dest(artefact_root: Path) -> Path:
    return artefact_root / "config" / "policy-bundle.json"


def _resolve_url(explicit: Optional[str], workspace: Optional[Path]) -> str:
    if explicit:
        return explicit
    import os
    env_url = os.environ.get(_ENV_PULL_URL)
    if env_url:
        return env_url
    if workspace is not None:
        from maestro.workspace import MSO_DIR_NAME
        ws = Path(workspace)
        for cfg in (ws / MSO_DIR_NAME / "config" / "workspace.json", ws / "config" / "workspace.json"):
            if cfg.exists():
                try:
                    data = json.loads(cfg.read_text(encoding="utf-8"))
                    url = (data.get("governance", {}) or {}).get("pullUrl")
                    if url:
                        return str(url)
                except Exception:
                    pass
    return DEFAULT_PULL_URL


def _default_fetch(url: str) -> bytes:
    req = urllib.request.Request(url, headers={"Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=_TIMEOUT_SECONDS) as resp:  # noqa: S310 (https default)
        return resp.read()


def pull_bundle(
    *,
    workspace: Optional[Path] = None,
    url: Optional[str] = None,
    fetcher: Optional[Fetcher] = None,
    now: Optional[datetime] = None,
    write: bool = True,
    artefact_root: Optional[Path] = None,
) -> PullResult:
    """Fetch, verify, and persist a signed policy bundle. See module docstring."""
    now = now or datetime.now(timezone.utc)
    root = Path(artefact_root) if artefact_root is not None else _artefact_root(workspace)
    dest = _bundle_dest(root)
    resolved_url = _resolve_url(url, workspace)
    fetch = fetcher or _default_fetch

    # --- Fetch -------------------------------------------------------------
    try:
        raw_bytes = fetch(resolved_url)
    except (urllib.error.URLError, urllib.error.HTTPError, OSError, TimeoutError) as exc:
        return _offline_fallback(dest, root, now, resolved_url, str(exc))

    try:
        bundle = json.loads(raw_bytes.decode("utf-8"))
    except Exception as exc:  # noqa: BLE001
        raise GovernanceError(
            f"pulled policy bundle from {resolved_url} is not valid JSON: {exc}"
        ) from exc

    # --- Verify (signature + anti-rollback + freshness stamp) --------------
    # require_signature=True: a *pulled* org bundle must be signed by definition.
    outcome = _signing.verify_signed_bundle(
        bundle, workspace=workspace, now=now, record=True,
        require_signature=True, artefact_root=root,
    )

    # --- Persist -----------------------------------------------------------
    if write:
        try:
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_text(
                json.dumps(bundle, indent=2, sort_keys=True) + "\n", encoding="utf-8"
            )
        except OSError as exc:
            raise GovernanceError(f"could not write pulled bundle to {dest}: {exc}") from exc

    return PullResult(
        ok=True, bundle_id=outcome.bundle_id, version=outcome.version,
        key_id=outcome.key_id, source="network", path=str(dest),
        message=f"pulled + verified bundle '{outcome.bundle_id}' v{outcome.version}",
    )


def _offline_fallback(
    dest: Path, root: Path, now: datetime, url: str, err: str
) -> PullResult:
    """Network fetch failed — honour offline grace if a verified bundle survives."""
    if not dest.exists():
        raise GovernanceError(
            f"could not fetch policy bundle from {url} ({err}) and no local bundle "
            f"exists at {dest} to fall back to."
        )
    try:
        bundle = json.loads(dest.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001
        raise GovernanceError(
            f"network unreachable ({err}) and the local bundle at {dest} is unreadable: {exc}"
        ) from exc

    bundle_id = bundle.get("bundleId", "")
    fresh, reason = _rollback.is_fresh(bundle_id, now=now, artefact_root=root)
    if not fresh:
        raise GovernanceError(
            f"network unreachable ({err}) and the local bundle is stale: {reason}. "
            "Reconnect and re-run `mso policy pull`."
        )
    return PullResult(
        ok=True, bundle_id=bundle_id,
        version=bundle.get("version", 0) if isinstance(bundle.get("version"), int) else 0,
        source="offline-grace", path=str(dest),
        message=(f"network unreachable ({err}); using locally-verified bundle "
                 f"'{bundle_id}' within offline grace"),
    )
