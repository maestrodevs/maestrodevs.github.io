"""
Trusted-key registry for signed policy bundles — vendor pin + rotation.

FTR-MSO-2026-0397 (PLAN-PLN-MSO-2026-0372 §3.4 "Trust root" / "Rotation").

A signed bundle's ``signature.keyId`` selects one pinned Ed25519 public key from a
merged registry, assembled from three sources. The **vendor baseline is
authoritative**: lower-authority sources may only ADD keyIds the vendor has not
pinned — a keyId collision ALWAYS keeps the vendor entry, so a workspace or a local
engineer cannot swap in their own public key for a shipped vendor keyId and then
self-sign policy (SEC-FTR-MSO-2026-0397 findings F1 + F5).

Precedence, LOWEST → HIGHEST authority (a higher source wins a keyId clash):

  4. Env injection    — ``MAESTRO_GOVERNANCE_TRUSTED_KEYS`` (JSON) — **TEST MODE ONLY**;
     LOWEST precedence, and can never override any other source. BUG-MSO-2026-0409
     F2/F3: this channel is IGNORED outside test mode (``MAESTRO_SKIP_AUTH`` set, or an
     active pytest run). In production ``enforce`` it MUST NOT be a trust root — a local
     writer could otherwise export their own keyId, self-sign a forged ``access.json``,
     and pass verification. Real out-of-workspace pins are the home keyring + vendor.
  3. Workspace pins   — ``workspace.json`` ``governance.trustedKeys`` (an org layers
     its own signing keys on top; cannot override a home or vendor keyId). NOTE: the
     identity signed-manifest anchor calls ``resolve_key(key_id, workspace=None)`` so
     workspace pins are excluded there entirely (a local writer must not self-pin).
  2. Home keyring     — ``$MAESTRO_HOME/trusted-keys.json`` (default ``~/.maestro/``).
     BUG-MSO-2026-0409 F3: a REAL out-of-workspace customer pin — an OS-protected file
     OUTSIDE any product repo / workspace a dispatched crew can write. This is where a
     customer pins their org signing key for the identity anchor when the vendor
     baseline is not used.
  1. Vendor baseline  — ``maestro/governance/keys/trusted-keys.json`` (ships in the
     pip package; the org's pinned trust root — HIGHEST authority, wins every clash).

Each entry:

    "acme-2026-q3": {
        "algorithm": "ed25519",
        "publicKey": "<base64 32-byte Ed25519 public key>",
        "status": "active",          // active | retiring | revoked
        "notAfter": "2027-01-01T00:00:00Z"   // optional hard expiry
    }

Rotation: publish the new key as ``active`` and mark the old one ``retiring`` (still
valid) for an overlap window, then flip the old one to ``revoked``. A bundle signed
by a ``revoked`` key — or by a ``retiring``/``active`` key past its ``notAfter`` —
is rejected.
"""
from __future__ import annotations

import base64
import binascii
import json
import os
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from maestro.governance.schema import GovernanceError

_KEYS_DIRNAME = "keys"
_KEYS_FILENAME = "trusted-keys.json"
_ENV_KEYS = "MAESTRO_GOVERNANCE_TRUSTED_KEYS"
_HOME_KEYS_FILENAME = "trusted-keys.json"


def _in_test_mode() -> bool:
    """Whether the process is running under test/CI (env-injected keys are honoured).

    BUG-MSO-2026-0409 F2/F3: the ``MAESTRO_GOVERNANCE_TRUSTED_KEYS`` env channel is a
    convenience for tests/CI to pin a throwaway signing key — it MUST NOT be a
    production trust root, or a local writer could inject their own key and self-sign a
    forged ACL. Test mode is signalled by ``MAESTRO_SKIP_AUTH`` (the sanctioned CI flag)
    or by an active pytest run (``PYTEST_CURRENT_TEST``). In real production neither is
    set, so the env channel is ignored and env-injected keys are refused.
    """
    return bool(os.environ.get("MAESTRO_SKIP_AUTH") or os.environ.get("PYTEST_CURRENT_TEST"))

VALID_KEY_STATUS = ("active", "retiring", "revoked")


@dataclass(frozen=True)
class TrustedKey:
    key_id: str
    public_key: bytes          # raw 32-byte Ed25519 public key
    status: str = "active"
    not_after: Optional[str] = None
    source: str = "vendor"     # vendor | workspace | env (provenance, for reporting)

    def is_usable(self, now: datetime) -> tuple[bool, str]:
        """Whether this key may verify a signature at ``now`` (+ human reason)."""
        if self.status == "revoked":
            return False, f"key '{self.key_id}' is revoked"
        if self.status not in VALID_KEY_STATUS:
            return False, f"key '{self.key_id}' has invalid status '{self.status}'"
        if self.not_after:
            try:
                from maestro.licence.grace import parse_iso
                if now > parse_iso(self.not_after):
                    return False, f"key '{self.key_id}' expired (notAfter={self.not_after})"
            except GovernanceError:
                raise
            except Exception:
                # An unparseable notAfter is a fail-closed integrity problem.
                return False, f"key '{self.key_id}' has unparseable notAfter"
        return True, ""


def _decode_public_key(raw: str, key_id: str) -> bytes:
    """Decode a base64 (or hex) 32-byte Ed25519 public key. Raises on bad shape."""
    if not isinstance(raw, str) or not raw:
        raise GovernanceError(f"trusted key '{key_id}' missing 'publicKey'")
    data: bytes | None = None
    try:
        data = base64.b64decode(raw, validate=True)
    except (binascii.Error, ValueError):
        # Tolerate a hex-encoded key as a convenience.
        try:
            data = bytes.fromhex(raw)
        except ValueError:
            data = None
    if data is None:
        raise GovernanceError(
            f"trusted key '{key_id}': publicKey is not valid base64 or hex"
        )
    if len(data) != 32:
        raise GovernanceError(
            f"trusted key '{key_id}': Ed25519 public key must be 32 bytes, got {len(data)}"
        )
    return data


def _keys_from_map(raw: Any, source: str) -> dict[str, TrustedKey]:
    if raw is None:
        return {}
    if not isinstance(raw, dict):
        raise GovernanceError(f"{source} trusted-keys must be a JSON object")
    out: dict[str, TrustedKey] = {}
    for key_id, entry in raw.items():
        if not isinstance(entry, dict):
            raise GovernanceError(f"{source} trusted key '{key_id}' must be an object")
        algo = entry.get("algorithm", "ed25519")
        if algo != "ed25519":
            raise GovernanceError(
                f"{source} trusted key '{key_id}': unsupported algorithm '{algo}'"
            )
        out[key_id] = TrustedKey(
            key_id=key_id,
            public_key=_decode_public_key(entry.get("publicKey"), key_id),
            status=entry.get("status", "active"),
            not_after=entry.get("notAfter"),
            source=source,
        )
    return out


def _vendor_keys_path() -> Path:
    return Path(__file__).resolve().parent / _KEYS_DIRNAME / _KEYS_FILENAME


def _load_vendor_keys() -> dict[str, TrustedKey]:
    path = _vendor_keys_path()
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001 — malformed vendor keyring is fail-closed
        raise GovernanceError(f"vendor trusted-keys unreadable ({path}): {exc}") from exc
    return _keys_from_map(data.get("keys", {}), "vendor")


def _load_workspace_keys(workspace: Path | None) -> dict[str, TrustedKey]:
    if workspace is None:
        return {}
    from maestro.workspace import MSO_DIR_NAME
    ws = Path(workspace)
    candidates = [
        ws / MSO_DIR_NAME / "config" / "workspace.json",
        ws / "config" / "workspace.json",
    ]
    cfg_path = next((c for c in candidates if c.exists()), None)
    if cfg_path is None:
        return {}
    try:
        cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
    except Exception:
        # A broken workspace.json must not inject phantom keys; treat as none.
        return {}
    gov = cfg.get("governance", {}) or {}
    return _keys_from_map(gov.get("trustedKeys"), "workspace")


def _load_env_keys() -> dict[str, TrustedKey]:
    # BUG-MSO-2026-0409 F2/F3: the env-injection channel is TEST MODE ONLY. Outside
    # test/CI it is ignored so a local writer cannot inject a trust root and self-sign
    # a forged ACL/manifest in production enforce mode.
    if not _in_test_mode():
        return {}
    raw = os.environ.get(_ENV_KEYS)
    if not raw:
        return {}
    try:
        data = json.loads(raw)
    except Exception as exc:  # noqa: BLE001
        raise GovernanceError(f"{_ENV_KEYS} is not valid JSON: {exc}") from exc
    # Accept either a bare map or a {"keys": {...}} wrapper.
    if isinstance(data, dict) and "keys" in data and isinstance(data["keys"], dict):
        data = data["keys"]
    return _keys_from_map(data, "env")


def _load_home_keys() -> dict[str, TrustedKey]:
    """Load pins from ``$MAESTRO_HOME/trusted-keys.json`` — a REAL out-of-workspace pin.

    BUG-MSO-2026-0409 F3: the vendor keyring ships empty and workspace pins are excluded
    from the identity anchor, so a customer needs an out-of-workspace location to pin
    their org signing key that a dispatched crew (confined to the product repo /
    workspace) cannot write. The user-global home dir is OS-owned and outside every
    workspace, so it is that anchor. Absent file → no pins (unchanged behaviour).
    """
    from maestro.workspace import get_maestro_home
    try:
        path = get_maestro_home() / _HOME_KEYS_FILENAME
    except Exception:
        return {}
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001 — a malformed home keyring is fail-closed
        raise GovernanceError(f"home trusted-keys unreadable ({path}): {exc}") from exc
    # Accept either the vendor-style {"keys": {...}} wrapper or a bare map.
    if isinstance(data, dict) and "keys" in data and isinstance(data["keys"], dict):
        data = data["keys"]
    return _keys_from_map(data, "home")


def load_trusted_keys(workspace: Path | None = None) -> dict[str, TrustedKey]:
    """Merge trusted keys with the VENDOR trust root authoritative.

    Precedence, LOWEST → HIGHEST: env < workspace < home < vendor. Applying the
    sources in that order means a higher-authority source's ``.update()`` overwrites
    any colliding keyId — so a vendor-pinned keyId ALWAYS keeps the vendor public key
    (SEC F1), and the env-injection channel can never override a vendor/home/workspace
    keyId (SEC F5). Lower sources may only ADD keyIds a higher one has not pinned.

    BUG-MSO-2026-0409: ``env`` is test-mode-only (see ``_load_env_keys``) and ``home``
    (``$MAESTRO_HOME/trusted-keys.json``) is the real out-of-workspace customer pin.
    """
    keys: dict[str, TrustedKey] = {}
    keys.update(_load_env_keys())              # lowest authority (test mode only)
    keys.update(_load_workspace_keys(workspace))
    keys.update(_load_home_keys())             # out-of-workspace OS-protected pin
    keys.update(_load_vendor_keys())           # vendor wins every keyId collision
    return keys


def resolve_key(
    key_id: str,
    workspace: Path | None = None,
    *,
    now: datetime | None = None,
) -> TrustedKey:
    """Resolve + validate a usable trusted key for ``key_id``.

    Raises GovernanceError when the key is unknown, revoked, or expired — every
    one of which is a fail-closed signal in governed enforce mode.
    """
    now = now or datetime.now(timezone.utc)
    keys = load_trusted_keys(workspace)
    key = keys.get(key_id)
    if key is None:
        known = ", ".join(sorted(keys)) or "(none pinned)"
        raise GovernanceError(
            f"signed bundle references unknown signing key '{key_id}'. "
            f"Pinned keys: {known}. Pin the org key via workspace.json "
            f"governance.trustedKeys before this bundle can be trusted."
        )
    usable, reason = key.is_usable(now)
    if not usable:
        raise GovernanceError(f"signing key rejected: {reason}")
    return key
