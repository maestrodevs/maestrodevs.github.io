"""
Ed25519 detached-signature verification for signed policy bundles.

FTR-MSO-2026-0397 (PLAN-PLN-MSO-2026-0372 Phase 2, §3.4).

The one net-new cryptographic component in the governance plane. The client only
ever *verifies* — private keys never touch a client machine (this is precisely
why the licence's symmetric HMAC, §1.3, is structurally unsuitable: the verifier
would have to hold the signing secret). A vendor/org signs a bundle; the client
verifies it against a pinned Ed25519 public key.

Implementation choice — pure Python, zero new dependency
--------------------------------------------------------
Verification is a self-contained RFC 8032 implementation (~120 lines). Maestro's
core dependency set is deliberately tiny (jinja2 / jsonschema / rich); pulling in
``cryptography`` (a large binary wheel) just to *verify* 64-byte signatures would
hurt the airgapped-install story the plan calls out. If ``cryptography`` *is*
installed, :func:`verify` transparently uses it as a fast path — otherwise the
pure-Python path runs. Both are constant across environments and fully testable
in CI without adding a crypto dep.

Canonical bytes
---------------
The signed message is the *canonical JSON* of the bundle payload with the
``signature`` envelope removed: ``json.dumps(payload, sort_keys=True,
separators=(",", ":"))`` encoded UTF-8. Re-serialising the parsed dict is
inherently line-ending independent, which honours the BUG-001 lesson
(FTR-MSO-2026-0392) that a raw-byte hash breaks under a benign CRLF transform —
here there is simply no raw-byte surface to normalise.
"""
from __future__ import annotations

import hashlib
import json
from typing import Any

SIGNATURE_FIELD = "signature"
ALGORITHM = "ed25519"


# ---------------------------------------------------------------------------
# Canonical serialisation
# ---------------------------------------------------------------------------

def canonical_payload(bundle: dict[str, Any]) -> dict[str, Any]:
    """Return a copy of *bundle* with the detached ``signature`` envelope removed.

    The signature is computed/verified over everything EXCEPT itself.
    """
    return {k: v for k, v in bundle.items() if k != SIGNATURE_FIELD}


def canonical_bytes(payload: dict[str, Any]) -> bytes:
    """Stable, EOL-independent serialisation of a signed payload.

    Sorted keys + tight separators, matching the canonical-JSON discipline used
    by ``licence/storage.py`` and ``audit/signer.py``.
    """
    return json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")


# ---------------------------------------------------------------------------
# Pure-Python Ed25519 (RFC 8032) — verify + sign (sign used for test/maintainer
# fixture generation; the client runtime only calls verify())
# ---------------------------------------------------------------------------

_p = 2 ** 255 - 19
_L = 2 ** 252 + 27742317777372353535851937790883648493


def _sha512_int(b: bytes) -> int:
    return int.from_bytes(hashlib.sha512(b).digest(), "little")


def _modp_inv(x: int) -> int:
    return pow(x, _p - 2, _p)


_d = (-121665 * _modp_inv(121666)) % _p
_modp_sqrt_m1 = pow(2, (_p - 1) // 4, _p)


def _recover_x(y: int, sign: int) -> int | None:
    if y >= _p:
        return None
    x2 = (y * y - 1) * _modp_inv(_d * y * y + 1) % _p
    if x2 == 0:
        if sign:
            return None
        return 0
    x = pow(x2, (_p + 3) // 8, _p)
    if (x * x - x2) % _p != 0:
        x = x * _modp_sqrt_m1 % _p
    if (x * x - x2) % _p != 0:
        return None
    if (x & 1) != sign:
        x = _p - x
    return x


# Extended homogeneous coordinates (X, Y, Z, T) with x = X/Z, y = Y/Z, x*y = T/Z.
_g_y = 4 * _modp_inv(5) % _p
_g_x = _recover_x(_g_y, 0)
_G = (_g_x, _g_y, 1, _g_x * _g_y % _p)


def _point_add(P, Q):
    A = (P[1] - P[0]) * (Q[1] - Q[0]) % _p
    B = (P[1] + P[0]) * (Q[1] + Q[0]) % _p
    C = 2 * P[3] * Q[3] * _d % _p
    D = 2 * P[2] * Q[2] % _p
    E, F, G, H = B - A, D - C, D + C, B + A
    return (E * F % _p, G * H % _p, F * G % _p, E * H % _p)


def _point_mul(s: int, P):
    Q = (0, 1, 1, 0)  # neutral element
    while s > 0:
        if s & 1:
            Q = _point_add(Q, P)
        P = _point_add(P, P)
        s >>= 1
    return Q


def _point_equal(P, Q) -> bool:
    if (P[0] * Q[2] - Q[0] * P[2]) % _p != 0:
        return False
    if (P[1] * Q[2] - Q[1] * P[2]) % _p != 0:
        return False
    return True


def _point_compress(P) -> bytes:
    zinv = _modp_inv(P[2])
    x = P[0] * zinv % _p
    y = P[1] * zinv % _p
    return int.to_bytes(y | ((x & 1) << 255), 32, "little")


def _point_decompress(s: bytes):
    if len(s) != 32:
        return None
    y = int.from_bytes(s, "little")
    sign = y >> 255
    y &= (1 << 255) - 1
    x = _recover_x(y, sign)
    if x is None:
        return None
    return (x, y, 1, x * y % _p)


def _verify_pure(public_key: bytes, msg: bytes, signature: bytes) -> bool:
    if len(public_key) != 32 or len(signature) != 64:
        return False
    A = _point_decompress(public_key)
    if A is None:
        return False
    Rs = signature[:32]
    R = _point_decompress(Rs)
    if R is None:
        return False
    s = int.from_bytes(signature[32:], "little")
    if s >= _L:
        return False
    h = _sha512_int(Rs + public_key + msg) % _L
    sB = _point_mul(s, _G)
    hA = _point_mul(h, A)
    return _point_equal(sB, _point_add(R, hA))


def _secret_expand(seed: bytes) -> tuple[int, bytes]:
    if len(seed) != 32:
        raise ValueError("Ed25519 seed must be exactly 32 bytes")
    h = hashlib.sha512(seed).digest()
    a = int.from_bytes(h[:32], "little")
    a &= (1 << 254) - 8
    a |= (1 << 254)
    return a, h[32:]


def public_key_from_seed(seed: bytes) -> bytes:
    """Derive the 32-byte Ed25519 public key from a 32-byte seed (private key)."""
    a, _ = _secret_expand(seed)
    return _point_compress(_point_mul(a, _G))


def sign(seed: bytes, msg: bytes) -> bytes:
    """Produce a 64-byte Ed25519 detached signature.

    NOT used by the client runtime — provided so maintainers (and the test suite)
    can generate signed fixtures without any external tooling. Signing keys live
    off-client; this is purely a fixture/authoring convenience.
    """
    a, prefix = _secret_expand(seed)
    A = _point_compress(_point_mul(a, _G))
    r = _sha512_int(prefix + msg) % _L
    R = _point_compress(_point_mul(r, _G))
    h = _sha512_int(R + A + msg) % _L
    s = (r + h * a) % _L
    return R + int.to_bytes(s, 32, "little")


def verify(public_key: bytes, msg: bytes, signature: bytes) -> bool:
    """Verify a detached Ed25519 signature. Never raises — returns True/False.

    Uses ``cryptography`` when importable (fast C path), else the pure-Python
    RFC 8032 verifier. Both agree bit-for-bit on the same inputs.
    """
    try:
        from cryptography.hazmat.primitives.asymmetric.ed25519 import (
            Ed25519PublicKey,
        )
        from cryptography.exceptions import InvalidSignature

        try:
            key = Ed25519PublicKey.from_public_bytes(public_key)
            key.verify(signature, msg)
            return True
        except (InvalidSignature, ValueError):
            return False
    except Exception:
        # cryptography absent (airgapped default) — pure-Python fallback.
        try:
            return _verify_pure(public_key, msg, signature)
        except Exception:
            return False


def verify_bundle(bundle: dict[str, Any], public_key: bytes, signature: bytes) -> bool:
    """Verify a signature over the canonical (signature-stripped) bundle payload."""
    return verify(public_key, canonical_bytes(canonical_payload(bundle)), signature)
