"""
CI-side diff verification — the governance enforcement backstop.

FTR-MSO-2026-0400 (PLAN-PLN-MSO-2026-0372 Phase 5).

``mso policy verify --ci`` re-evaluates a committed diff against the governed
packs on infrastructure the engineer does not own. Per the plan's trust-boundary
analysis (§6): client-side hooks protect the *crew from itself* (safety +
evidence); the CI backstop re-checks the same signed packs against what actually
landed, on infrastructure the developer does not control, so a rule bypassed
*locally* is still evaluated here.

Best-effort defense-in-depth — NOT a bypass-proof gate (FTR-MSO-2026-0400 re-scope)
-----------------------------------------------------------------------------------
Read this before trusting the exit code as a security guarantee.

This backstop scans the **textual content of a diff** and asks each added line /
aggregated block "does this match a governed deny pattern?". That makes it a
reliable catch for the **obvious and common** violations — a plain
``DROP DATABASE prod``, an ``rm -rf``, a ``terraform destroy``, including the
split-across-lines and header-collision variants this module specifically
reconstructs (see ``_join_line_continuations`` and the aggregated-block pass in
``verify_diff``). Those are exactly the mistakes a client-side hook bypass would
let slip, and catching them at merge time is real, useful defense-in-depth.

It is **not** an omniscient gate and does not claim to be. Content scanning of a
diff is *inherently incomplete*: a determined attacker who wants to smuggle a
destructive action past a regex can obfuscate it without bound — base64/hex
encoding decoded at runtime, string concatenation (``"DRO"+"P DATABASE"``),
variable indirection, ``eval``/``$(...)`` construction, reading the payload from
a data file, or splitting it in ways this parser does not reconstruct. Chasing
every such variant is unwinnable whack-a-mole; this module deliberately does not
try. **A green ``mso policy verify --ci`` means "no obvious/common violation was
found", NOT "this diff is safe".**

The real guarantees against a *determined* insider live elsewhere and this layer
does not replace them:

  * **Branch protection + mandatory human review** — a reviewer reads intent, not
    just pattern-matches; an obfuscated payload is *more* suspicious to a human,
    not less.
  * **Runtime controls** — least-privilege credentials, network egress limits,
    and running crews on **org-controlled infrastructure** stop the action even
    if the text got merged.
  * **Client-side hooks** — the fast in-loop safety net + tamper-evident record.

Frame this backstop as one honest layer of that crew-focused model — the merge-
time net for the common case — never as the wall that makes the others optional.

The evaluator reuses the *identical* pure engine (`engine.evaluate`) the pretool
hook uses at runtime. It turns each added line of the diff into a synthetic
``EvalContext`` and asks the merged policy for a verdict:

  * every added line → a **Bash** context (catches Bash-scoped deny rules — the
    committed line may be a shell command in a script, Makefile, or workflow);
  * every changed file → one **Write** context over its aggregated added content
    (catches Write-scoped rules, e.g. secret-handling, forward-compatible with
    later packs).

Any ``deny`` verdict is a violation; the command exits non-zero. This is
independent of the client's ``governedMode`` — CI enforcement does not care
whether the developer's machine had governance switched on.

``verify_diff`` is a pure function of ``(policy, diff_text)`` so it is
unit-testable without a git repository; all subprocess/git I/O is confined to
``resolve_diff_text`` / ``run_ci_verify``.

Module name note
----------------
This lives in ``ci_verify.py``, NOT ``verify.py`` — the latter is the Phase-2
Ed25519 signed-bundle crypto verifier (``maestro/governance/verify.py``). The
two are unrelated; keeping them in separate modules avoids a name collision.

Fail-closed posture (SEC-0400-02, CWE-636)
------------------------------------------
An enforcement gate must never let an *unparseable* diff read as a *clean* one.
``run_ci_verify`` rejects (exit 2) a non-empty diff whose parse does not
reconcile — a hunk body that does not match its ``@@`` header, an unrecognised
combined-merge header, or a content-bearing file that produced no parseable
hunk. "I could not understand this diff" fails the build; it does not pass it.
"""
from __future__ import annotations

import fnmatch
import json
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

from maestro.governance.context import EvalContext
from maestro.governance.diff import DiffFile, added_lines_by_file, parse_diff
from maestro.governance.engine import Decision, MergedPolicy, evaluate
from maestro.governance.loader import load_policy
from maestro.governance.schema import GovernanceError

# Paths that are *authoring surfaces* — documentation and the policy packs
# themselves legitimately contain the very command strings the deny-patterns
# look for (a doc showing an example, a pack defining the regex). Scanning them
# produces false positives, so they are excluded by default.
#
# SEC-0400-03 (coverage gap): the earlier default set ALSO skipped ``.github/*``
# and ``tests/*`` — but those are EXECUTABLE surfaces (a workflow step runs in
# CI; a test module runs in the test job), exactly the paths an attacker targets.
# Blanket-excluding them is a real gap, so they are NO LONGER excluded by
# default. The residual false-positive risk (a test fixture or workflow that
# legitimately embeds a trigger string) is handled by the operator with an
# explicit ``--exclude`` — see GOVERNANCE-TRUST-BOUNDARY.md. fnmatch's ``*``
# spans ``/``.
#
# NEW-1 (SEC-FTR-MSO-2026-0400): the ``LICENSE``/``CHANGELOG`` entries were
# previously the UNANCHORED prefix globs ``LICENSE*`` / ``CHANGELOG*``. Because
# fnmatch's ``*`` spans ``/``, those matched entire attacker-selectable subtrees
# (``LICENSES/deploy.sh`` — the real SPDX/REUSE convention — ``LICENSE-x/evil.sh``,
# ``CHANGELOG.d/run.sh``), letting a PR author smuggle a policy violation past the
# gate by naming a file under a ``LICENSE``/``CHANGELOG`` prefix on the real CI
# path. They are now the EXACT top-level filenames only (no ``*``, so no ``/``
# span); ``CHANGELOG.md`` / ``LICENSE.md`` remain covered by the ``*.md`` entry.
DEFAULT_EXCLUDES: tuple[str, ...] = (
    "*.md",
    "docs/*",
    "maestro/docs/*",
    "maestro/governance/library/*",
    "CHANGELOG",
    "CHANGELOG.rst",
    "LICENSE",
    "LICENSE.txt",
    "LICENSE.rst",
)


@dataclass(frozen=True)
class Violation:
    """One denied added line (or file write) in the diff."""

    file_path: str
    line_no: int
    decision: Decision
    snippet: str = ""

    def as_dict(self) -> dict:
        return {
            "file": self.file_path,
            "line": self.line_no,
            "ruleId": self.decision.rule_id,
            "action": self.decision.action,
            "severity": self.decision.severity,
            "tier": self.decision.tier,
            "reason": self.decision.reason,
            "snippet": self.snippet,
        }


class DiffParseError(Exception):
    """A non-empty diff did not reconcile — fail closed (exit 2)."""


def _bash_context(command: str) -> EvalContext:
    """A synthetic Bash tool-call context for one committed line."""
    return EvalContext(
        tool="Bash",
        command=command,
        file_path="",
        content="",
        role="",
        cwd="",
        worktree="",
        env_class="unknown",
    )


def _write_context(file_path: str, content: str) -> EvalContext:
    """A synthetic Write tool-call context over a file's aggregated added lines."""
    return EvalContext(
        tool="Write",
        command="",
        file_path=file_path,
        content=content,
        role="",
        cwd="",
        worktree="",
        env_class="unknown",
    )


def _join_line_continuations(lines) -> list[tuple[int, str]]:
    """Reconstruct shell ``\\``-newline line-continuations across added lines.

    F1 (SEC-FTR-MSO-2026-0400) — the evaluator used to model each added line as a
    COMPLETE standalone Bash command. A destructive command split with a trailing
    backslash continuation (``+psql -c "DROP \\`` then ``+DATABASE prod"``) lands
    in two isolated single-line contexts, so no single line matches a line-anchored
    deny rule — yet the checked-out script runs the merged ``DROP DATABASE prod``.

    A committed line ending in an ODD number of backslashes continues onto the
    next added line; the shell drops the trailing ``\\`` + newline and concatenates
    directly (``DROP \\`` + ``DATABASE`` → ``DROP DATABASE``). This reproduces that
    join so the merged command is evaluated as the one command it becomes at
    runtime. Each logical command is returned as ``(first_physical_line_no, text)``
    so a violation is reported at the line the command starts on. Lines with no
    continuation pass through unchanged (identical to the old per-line behaviour,
    deduped against the raw pass).
    """
    logical: list[tuple[int, str]] = []
    buf: str | None = None
    first_no = 0
    for al in lines:
        text = al.text
        # A trailing run of backslashes continues iff its length is odd (an even
        # run is escaped backslashes — e.g. ``foo\\`` is a literal ``\`` at EOL).
        trailing = len(text) - len(text.rstrip("\\"))
        continues = trailing % 2 == 1
        if buf is None:
            first_no = al.line_no
            buf = ""
        if continues:
            buf += text[:-1]        # drop the single continuation backslash; join directly
        else:
            buf += text
            logical.append((first_no, buf))
            buf = None
    if buf is not None:             # a dangling continuation at end-of-file
        logical.append((first_no, buf))
    return logical


def _is_excluded(path: str, excludes: tuple[str, ...], includes: tuple[str, ...]) -> bool:
    """True when ``path`` should be skipped.

    An ``includes`` allowlist, when non-empty, restricts evaluation to matching
    paths; ``excludes`` then subtract from whatever remains.
    """
    if includes and not any(fnmatch.fnmatch(path, pat) for pat in includes):
        return True
    return any(fnmatch.fnmatch(path, pat) for pat in excludes)


def _parse_anomalies(
    diff_text: str,
    *,
    excludes: tuple[str, ...] = (),
    includes: tuple[str, ...] = (),
) -> list[str]:
    """Return human-readable reasons a non-empty diff failed to parse cleanly.

    An empty list means the diff parsed cleanly (or was genuinely empty). A
    non-empty list is the SEC-0400-02 fail-closed signal — the caller must treat
    it as an operational error, never as "no violations".

    Only *evaluated* (non-excluded) files count: a parse miss in a file we would
    not have scanned anyway is not a bypass of enforcement.
    """
    parsed = parse_diff(diff_text)
    reasons: list[str] = []

    if parsed.saw_unparsed_hunk_header:
        reasons.append(
            "diff contains an unrecognised hunk header (e.g. a combined-merge "
            "'@@@' diff); refusing to evaluate an un-modelled format"
        )
    elif diff_text.strip() and not parsed.files:
        # F5 (SEC-FTR-MSO-2026-0400): we were handed bytes but recognised no
        # diff structure at all (no file/hunk). That is an unparseable diff, not
        # a clean one — fail closed rather than reporting a false PASS. (Guarded
        # by ``elif`` so the combined-merge case above owns its own message.)
        reasons.append(
            "non-empty input produced no parseable diff (no file/hunk structure "
            "recognised); refusing to treat unrecognised bytes as a clean diff"
        )

    for f in parsed.files:
        if not f.path or _is_excluded(f.path, excludes, includes):
            continue
        if f.is_binary or f.is_deletion or f.is_rename_or_mode_only:
            continue  # legitimately no added lines to evaluate
        if f.anomaly:
            reasons.append(f"{f.path}: hunk body did not reconcile against its @@ header")
        elif f.hunk_count == 0:
            reasons.append(f"{f.path}: changed file yielded no parseable hunk")

    return reasons


def verify_diff(
    policy: MergedPolicy,
    diff_text: str,
    *,
    excludes: tuple[str, ...] = (),
    includes: tuple[str, ...] = (),
) -> list[Violation]:
    """Evaluate every added line/file of ``diff_text`` against ``policy``.

    Pure and deterministic — no git, no clock, no ambient env. Returns the list
    of ``deny`` violations, ordered by (file, line). ``warn`` and ``allow``
    verdicts are not violations.
    """
    violations: list[Violation] = []
    seen: set[tuple[str, str, int]] = set()

    def _record(decision, file_path: str, line_no: int, snippet: str) -> None:
        if decision.allowed:
            return
        key = (decision.rule_id, file_path, line_no)
        if key in seen:
            return
        seen.add(key)
        violations.append(Violation(file_path, line_no, decision, snippet))

    for file_path, lines in added_lines_by_file(diff_text).items():
        if not file_path or _is_excluded(file_path, excludes, includes):
            continue

        # Rule ids already flagged on this file by the per-line / continuation
        # passes, so the whole-block pass (2b) only surfaces GENUINELY-split
        # commands rather than re-reporting a single-line match at a second line.
        file_rule_hits: set[str] = set()

        # (1) Per-physical-line Bash contexts — a deny rule that matches a single
        # committed line (the common case).
        for al in lines:
            d = evaluate(policy, _bash_context(al.text))
            if not d.allowed:
                file_rule_hits.add(d.rule_id)
            _record(d, file_path, al.line_no, al.text.strip())

        # (2) Logical-command Bash contexts (F1, SEC-FTR-MSO-2026-0400) — a
        # command split across added lines with a trailing-'\' shell
        # line-continuation is ONE command when the file runs, but each physical
        # line alone matches no line-anchored deny rule. Reconstruct the shell's
        # own continuation join and evaluate the merged command so the split
        # cannot slip a `DROP \`\n`DATABASE prod` past the gate. Reported at the
        # first physical line of the logical command; a non-continued line yields
        # its own text and is deduped against pass (1).
        for first_no, command in _join_line_continuations(lines):
            d = evaluate(policy, _bash_context(command))
            if not d.allowed:
                file_rule_hits.add(d.rule_id)
            _record(d, file_path, first_no, command.strip())

        first_line = lines[0].line_no if lines else 0
        block = "\n".join(al.text for al in lines)

        # (2b) Whole-file aggregated Bash context (F1, FTR-MSO-2026-0400 re-scope).
        # The added lines run as one script when the file executes, so a
        # destructive command split across lines WITHOUT a trailing-'\' — or one a
        # deny pattern only recognises whole because its `\s` spans the newline
        # (e.g. `DROP`\n`DATABASE prod`) — still runs. Evaluate the entire added
        # block as one Bash subject as a best-effort common-case net (it does NOT
        # defeat deliberate obfuscation — see the module docstring). Only recorded
        # when it surfaces a rule the per-line / continuation passes did not
        # already flag for this file, so a single-line match is never
        # double-counted; reported at the first added line.
        d_block = evaluate(policy, _bash_context(block))
        if not d_block.allowed and d_block.rule_id not in file_rule_hits:
            snippet = block.strip()
            if len(snippet) > 200:
                snippet = snippet[:197] + "..."
            _record(d_block, file_path, first_line, snippet)

        # (3) Whole-file Write context (forward-compatible with Write-scoped packs).
        _record(evaluate(policy, _write_context(file_path, block)), file_path, first_line, "")

    violations.sort(key=lambda v: (v.file_path, v.line_no))
    return violations


# ---------------------------------------------------------------------------
# CLI-facing orchestration (git I/O lives here, never in verify_diff)
# ---------------------------------------------------------------------------

def _validate_ref(ref: str, flag: str) -> str:
    """Reject a git ref that would be parsed as an option (SEC-0400-04).

    ``base``/``head`` come only from operator CLI flags and the workflow's
    derived base ref today, but a value beginning with ``-`` would be
    interpreted as a ``git`` option rather than a revision. Defence-in-depth:
    forbid it outright.
    """
    if ref.startswith("-"):
        raise RuntimeError(f"invalid {flag} ref {ref!r}: must not begin with '-'")
    return ref


def _git(args: list[str], repo: Path) -> str:
    """Run a git command in ``repo`` and return stdout (raises on failure)."""
    proc = subprocess.run(
        ["git", *args],
        cwd=str(repo),
        capture_output=True,
        text=True,
    )
    if proc.returncode != 0:
        raise RuntimeError(
            f"git {' '.join(args)} failed (exit {proc.returncode}): {proc.stderr.strip()}"
        )
    return proc.stdout


def resolve_diff_text(args, repo: Path) -> tuple[str, str]:
    """Resolve the unified diff to evaluate + a human label for it.

    Sources, in precedence order:
      1. ``--diff-file PATH`` (``-`` = stdin) — pre-computed diff, no git needed.
      2. ``--staged``          — ``git diff --staged``.
      3. ``--base``/``--against`` REF ... ``--head`` REF — ``git diff base...head``
         (three-dot = merge-base, the correct PR-review semantics). Defaults:
         base ``origin/main``, head ``HEAD``.
    """
    diff_file = getattr(args, "diff_file", None)
    if diff_file:
        if diff_file == "-":
            return sys.stdin.read(), "stdin"
        return Path(diff_file).read_text(encoding="utf-8"), diff_file

    if getattr(args, "staged", False):
        return _git(["diff", "--staged", "--unified=0", "--"], repo), "--staged"

    base = _validate_ref(
        getattr(args, "base", None) or getattr(args, "against", None) or "origin/main",
        "--base",
    )
    head = _validate_ref(getattr(args, "head", None) or "HEAD", "--head")
    target = f"{base}...{head}"
    # ``--`` terminates option parsing; ``target`` is a revision range, never a
    # pathspec, and is already validated not to start with '-'.
    return _git(["diff", "--unified=0", target, "--"], repo), target


def _resolve_excludes(args) -> tuple[tuple[str, ...], tuple[str, ...]]:
    excludes: list[str] = []
    if not getattr(args, "no_default_excludes", False):
        excludes.extend(DEFAULT_EXCLUDES)
    excludes.extend(getattr(args, "exclude", None) or [])
    includes = tuple(getattr(args, "include", None) or [])
    return tuple(excludes), includes


def run_ci_verify(args, workspace: Path | None, repo: Path) -> int:
    """`mso policy verify --ci` entry point. Returns a process exit code.

    Exit codes:
      * 0 — no violations (or ``--warn-only``).
      * 1 — at least one governed-pack violation in the diff (CI must fail).
      * 2 — operational error (bad diff source, git failure, tampered packs, or
            an unparseable diff — fail-closed).
    """
    as_json = getattr(args, "json", False)
    warn_only = getattr(args, "warn_only", False)

    # Load + integrity-verify the merged policy. A tampered pack must FAIL the
    # build (fail-closed), never silently pass — this is the enforcement point.
    try:
        policy = load_policy(workspace, verify=True)
    except GovernanceError as exc:
        _emit_error(f"governance policy failed to load: {exc}", as_json)
        return 2

    # FOLLOW-UP (SEC-FTR-MSO-2026-0400) — fail CLOSED if the policy resolves to
    # ZERO rules. ``load_policy`` raises on a missing/tampered/unreadable pack,
    # but a silently mis-resolved or empty merge could yield an all-permitting
    # rule set; an enforcement backstop that evaluates a diff against no rules
    # would PASS everything (a silent total fail-open). A zero-rule policy at the
    # enforcement point is a misconfiguration, not a clean policy — reject it.
    if not policy.rules:
        _emit_error(
            "governed policy resolved to ZERO rules — an enforcement backstop "
            "with no rules cannot be trusted to have evaluated the diff; failing "
            "closed rather than passing every change",
            as_json,
        )
        return 2

    try:
        diff_text, label = resolve_diff_text(args, repo)
    except (RuntimeError, OSError) as exc:
        _emit_error(f"could not resolve diff: {exc}", as_json)
        return 2

    excludes, includes = _resolve_excludes(args)

    # SEC-0400-02: fail closed on a non-empty diff we could not parse cleanly,
    # rather than silently reporting PASS. An empty diff is genuinely clean.
    if diff_text.strip():
        anomalies = _parse_anomalies(diff_text, excludes=excludes, includes=includes)
        if anomalies:
            detail = "; ".join(anomalies)
            _emit_error(
                f"diff did not parse cleanly against an enforcement gate ({detail}); "
                f"failing closed — an unparseable diff is not a clean one",
                as_json,
            )
            return 2

    violations = verify_diff(policy, diff_text, excludes=excludes, includes=includes)

    return _report(violations, label, policy, as_json=as_json, warn_only=warn_only)


def _emit_error(message: str, as_json: bool) -> None:
    if as_json:
        print(json.dumps({"result": "error", "error": message}, indent=2))
    else:
        print(f"[policy verify] ERROR: {message}", file=sys.stderr)


def _report(
    violations: list[Violation],
    label: str,
    policy: MergedPolicy,
    *,
    as_json: bool,
    warn_only: bool,
) -> int:
    counts: dict[str, int] = {}
    for v in violations:
        sev = v.decision.severity or "unknown"
        counts[sev] = counts.get(sev, 0) + 1

    failed = bool(violations) and not warn_only

    # F6 (SEC-FTR-MSO-2026-0400): --warn-only downgrades a hard block to exit 0.
    # That is a legitimate rollout mode, but it must NOT be able to silently
    # disable enforcement — emit a distinct signal on STDERR (separate from the
    # stdout/JSON report a consumer parses) that cannot be suppressed by reading
    # only the report. A reviewer scanning CI logs sees enforcement was waived.
    if violations and warn_only:
        print(
            f"[policy verify --ci] ENFORCEMENT WAIVED: --warn-only suppressed "
            f"{len(violations)} governed-pack violation(s); this run did NOT block. "
            f"Remove --warn-only to enforce.",
            file=sys.stderr,
        )

    if as_json:
        print(json.dumps(
            {
                "result": "fail" if failed else ("warn" if violations else "pass"),
                "target": label,
                "rulesEvaluated": len(policy.rules),
                "violationCount": len(violations),
                "counts": counts,
                "warnOnly": warn_only,
                "violations": [v.as_dict() for v in violations],
            },
            indent=2,
        ))
        return 1 if failed else 0

    header = "policy verify --ci"
    print(f"[{header}] evaluated diff `{label}` against {len(policy.rules)} governed rule(s).")
    if not violations:
        print(f"[{header}] PASS — no governed-pack violations.")
        return 0

    tag = "WARNING" if warn_only else "VIOLATION"
    for v in violations:
        loc = f"{v.file_path}:{v.line_no}"
        print(
            f"[{header}] {tag} {loc}  "
            f"[{v.decision.severity}] {v.decision.rule_id} — {v.decision.reason}"
        )
        if v.snippet:
            print(f"           + {v.snippet}")

    summary = ", ".join(f"{k}={n}" for k, n in sorted(counts.items()))
    if warn_only:
        print(f"[{header}] {len(violations)} warning(s) ({summary}) — not blocking (--warn-only).")
        return 0

    print(f"[{header}] FAIL — {len(violations)} violation(s) ({summary}).")
    print(
        f"[{header}] A client-side hook may have been bypassed; this CI backstop is one "
        f"(best-effort) enforcement layer — pair it with branch protection + human review."
    )
    return 1
