"""
Anti-rollback version ledger + offline-freshness state for signed bundles.

FTR-MSO-2026-0397 (PLAN-PLN-MSO-2026-0372 §3.4 "Anti-rollback" / "Offline grace").

Two properties, one small JSON state file:

* **Anti-rollback** — the engine persists the highest ``version`` ever verified per
  ``bundleId``; a bundle presenting a LOWER version is a downgrade attack and is
  rejected (even across a fresh ``mso policy pull``).
* **Offline freshness** — the timestamp + expiry of the last successful signature
  verification, so the loader can honour an offline grace window (reusing the
  licence ``grace.py`` precedent) without re-fetching on every crew action.

The state lives at ``<artefact-root>/state/policy-version-ledger.json`` — the same
gitignored, git-immune runtime plane as the order ledger (BUG-MSO-2026-0294). Path
resolution goes through :func:`maestro.workspace.get_artefact_root` so solo/shared
artefact-repo mode retargets automatically and hand-built joins are avoided
(BUG-MSO-2026-0362/0387/0003 lesson).
"""
from __future__ import annotations

import json
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from maestro.governance.schema import GovernanceError

LEDGER_RELPATH = Path("state") / "policy-version-ledger.json"
# A once-written sentinel proving the ledger was initialised. It lets load_ledger
# distinguish "never initialised" (legit — return an empty floor) from "was
# initialised, now GONE" (a tamper signal — fail closed). SEC-FTR-MSO-2026-0397 F3:
# deleting the ledger must not silently reset the anti-rollback floor to zero.
LEDGER_MARKER_RELPATH = Path("state") / ".policy-version-ledger.initialised"

_WRITE_LOCK = threading.Lock()


def _artefact_root(explicit: Optional[Path] = None) -> Path:
    if explicit is not None:
        return Path(explicit)
    # Route through the artefact resolver (solo/shared aware). Fall back to the
    # embedded workspace dir if no artefact mode is configured.
    from maestro.workspace import get_artefact_root
    return get_artefact_root()


def ledger_path(artefact_root: Optional[Path] = None) -> Path:
    return _artefact_root(artefact_root) / LEDGER_RELPATH


def ledger_marker_path(artefact_root: Optional[Path] = None) -> Path:
    return _artefact_root(artefact_root) / LEDGER_MARKER_RELPATH


def load_ledger(artefact_root: Optional[Path] = None) -> dict:
    """Read the version ledger.

    * Missing file **and** no init marker → never initialised → empty ledger.
    * Missing file **but** the init marker survives → the ledger was recorded and
      then DELETED → fail closed (GovernanceError). SEC F3: an erased ledger must
      not reset the anti-rollback floor to zero and permit a downgrade.
    * Corrupt / malformed file → fail closed (a tampered record cannot be trusted).
    """
    path = ledger_path(artefact_root)
    if not path.exists():
        if ledger_marker_path(artefact_root).exists():
            raise GovernanceError(
                f"policy version ledger is missing ({path}) but was previously "
                "initialised — it appears to have been DELETED. Refusing to reset "
                "the anti-rollback floor (this is how a downgrade attack erases the "
                "record). Restore the ledger or re-run `mso policy pull`."
            )
        return {"bundles": {}}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001
        raise GovernanceError(
            f"policy version ledger unreadable ({path}): {exc} — refusing to "
            "proceed (a corrupt anti-rollback record cannot be trusted)."
        ) from exc
    if not isinstance(data, dict) or not isinstance(data.get("bundles"), dict):
        raise GovernanceError(
            f"policy version ledger malformed ({path}): missing 'bundles' map."
        )
    return data


def highest_version(bundle_id: str, artefact_root: Optional[Path] = None) -> Optional[int]:
    """Highest verified version recorded for ``bundle_id`` (None if never seen)."""
    entry = load_ledger(artefact_root)["bundles"].get(bundle_id)
    if not entry:
        return None
    v = entry.get("version")
    return v if isinstance(v, int) else None


def check_not_rollback(
    bundle_id: str, version: int, artefact_root: Optional[Path] = None
) -> None:
    """Raise GovernanceError if ``version`` is BELOW the highest recorded version.

    Equal versions are allowed (re-verifying the same bundle); only a strict
    decrease is a rollback.
    """
    seen = highest_version(bundle_id, artefact_root)
    if seen is not None and version < seen:
        raise GovernanceError(
            f"anti-rollback: bundle '{bundle_id}' version {version} is OLDER than "
            f"the highest previously verified version {seen}. This is a downgrade "
            f"attack — refusing the bundle."
        )


def record_version(
    bundle_id: str,
    version: int,
    *,
    key_id: str = "",
    verified_at: Optional[datetime] = None,
    expires_at: Optional[str] = None,
    offline_grace_days: int = 0,
    artefact_root: Optional[Path] = None,
) -> None:
    """Persist a successful verification: advance the version floor + stamp freshness.

    Monotonic — never lowers a recorded version. Best-effort on write failure is
    NOT appropriate here (unlike the order ledger's advisory writes): if we cannot
    persist the floor we would silently permit a later rollback, so a write error
    surfaces as GovernanceError.
    """
    verified_at = verified_at or datetime.now(timezone.utc)
    with _WRITE_LOCK:
        data = load_ledger(artefact_root)
        bundles = data["bundles"]
        prev = bundles.get(bundle_id, {})
        prev_version = prev.get("version")
        new_version = version
        if isinstance(prev_version, int) and prev_version > version:
            # Never regress the floor even if asked to (defensive).
            new_version = prev_version
        bundles[bundle_id] = {
            "version": new_version,
            "keyId": key_id or prev.get("keyId", ""),
            "lastVerifiedAt": verified_at.astimezone(timezone.utc).isoformat(),
            "expiresAt": expires_at if expires_at is not None else prev.get("expiresAt"),
            "offlineGraceDays": offline_grace_days or prev.get("offlineGraceDays", 0),
        }
        path = ledger_path(artefact_root)
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n", encoding="utf-8")
            # Drop the once-written init marker so a later deletion of the ledger
            # is detectable as tamper (SEC F3). Best-effort content; its mere
            # existence is the signal.
            marker = ledger_marker_path(artefact_root)
            if not marker.exists():
                marker.write_text(
                    "policy-version-ledger initialised; do not delete\n",
                    encoding="utf-8",
                )
        except OSError as exc:
            raise GovernanceError(
                f"could not persist anti-rollback ledger ({path}): {exc}"
            ) from exc


def freshness_state(bundle_id: str, artefact_root: Optional[Path] = None) -> Optional[dict]:
    """The recorded freshness entry for ``bundle_id`` (None if never verified)."""
    return load_ledger(artefact_root)["bundles"].get(bundle_id)


def is_fresh(
    bundle_id: str,
    *,
    now: Optional[datetime] = None,
    artefact_root: Optional[Path] = None,
) -> tuple[bool, str]:
    """Whether a previously-verified bundle is still within its freshness window.

    Fresh when ``now <= expiresAt`` OR ``now <= lastVerifiedAt + offlineGraceDays``
    (the offline grace precedent from ``licence/grace.py``). Returns
    ``(fresh, human_reason)``. A bundle never verified is (False, ...).
    """
    now = (now or datetime.now(timezone.utc))
    if now.tzinfo is None:
        now = now.replace(tzinfo=timezone.utc)
    entry = freshness_state(bundle_id, artefact_root)
    if not entry:
        return False, f"bundle '{bundle_id}' has never been verified"

    from maestro.licence.grace import parse_iso

    expires_at = entry.get("expiresAt")
    if expires_at:
        try:
            if now <= parse_iso(expires_at):
                return True, ""
        except Exception:
            pass  # fall through to grace-window evaluation

    last = entry.get("lastVerifiedAt")
    grace_days = entry.get("offlineGraceDays", 0) or 0
    if last and grace_days:
        try:
            from datetime import timedelta
            deadline = parse_iso(last) + timedelta(days=int(grace_days))
            if now <= deadline:
                return True, ""
            return False, (
                f"bundle '{bundle_id}' offline grace expired "
                f"(last verified {last}, grace {grace_days}d)"
            )
        except Exception:
            pass

    if expires_at:
        return False, f"bundle '{bundle_id}' expired at {expires_at} and no grace remains"
    return False, f"bundle '{bundle_id}' freshness cannot be established"
