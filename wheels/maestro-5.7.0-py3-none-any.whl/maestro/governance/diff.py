"""
Unified-diff parser for the CI backstop.

FTR-MSO-2026-0400 (PLAN-PLN-MSO-2026-0372 Phase 5).

The Phase 5 ``mso policy verify --ci`` command re-evaluates a *committed diff*
against the governed packs on infrastructure the engineer does not own (§6 of
the plan: **client = safety + evidence; CI = enforcement**). To do that it must
turn a unified diff into the same ``EvalContext`` the pretool hook produces at
runtime, so the *identical* pure engine (`engine.evaluate`) decides.

This module is the diff → added-lines half. It is deliberately free of policy
logic and of any git/subprocess I/O — parsing a diff string is a pure function,
which keeps ``ci_verify.verify_diff`` unit-testable without a repo. Context
construction and evaluation live in ``ci_verify.py``.

Only **added** lines are evaluated: the backstop asks "what did this change try
to introduce", not "what already existed". A removed line cannot execute.

Security note (SEC-0400-01 — header-collision bypass, CWE-20)
------------------------------------------------------------
The parser is **position-aware**. A naïve parser that tests ``raw.startswith
("+++ ")`` / ``"--- "`` / ``"diff --git"`` on *every* line before deciding
whether it is inside a hunk can be defeated: an added line whose file content
begins with ``++ `` is rendered by ``git diff`` as ``+++ <content>`` — byte
identical to a ``+++ b/file`` header. A naïve parser mis-tokenizes it as a file
header, resets its in-hunk state, and silently drops the *next* (payload) line.

To close this, header prefixes are recognised **only at structurally valid
positions** — never while consuming a hunk body. Once a ``@@`` hunk header
declares its line counts, this parser dispatches strictly on the first byte
(``+`` = added, ``-`` = removed, space = context) and counts the declared
lines down. It re-enters "structural" mode only when a hunk is exhausted, so an
added line's *content* can never be mistaken for a header. A hunk whose body
fails to reconcile against its declared ``@@`` counts is flagged as an anomaly
(consumed by the fail-closed check in ``ci_verify`` — SEC-0400-02).
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Iterator

# ``@@ -old_start,old_len +new_start,new_len @@`` — capture every count so the
# hunk body can be reconciled against what the header promised. When a length is
# omitted git means exactly 1 (``@@ -1 +1 @@``).
_HUNK_RE = re.compile(r"^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@")


@dataclass(frozen=True)
class AddedLine:
    """A single added (``+``) line from a unified diff."""

    file_path: str        # new-file path (``b/…`` prefix stripped)
    line_no: int          # 1-based line number in the new file
    text: str             # line content WITHOUT the leading ``+``


@dataclass
class DiffFile:
    """One file's worth of parsed diff, with structural metadata.

    The metadata lets the CI backstop fail *closed* (SEC-0400-02): a changed
    file that is not binary, not a pure deletion, yet yields no parseable hunk
    body — or whose hunk body does not reconcile against its ``@@`` header — is
    an unparseable-diff signal, not a clean one.
    """

    path: str
    is_binary: bool = False
    is_deletion: bool = False          # new side is ``/dev/null``
    is_rename_or_mode_only: bool = False   # rename/copy/mode change, no content hunk
    hunk_count: int = 0
    added: list[AddedLine] = field(default_factory=list)
    anomaly: bool = False              # a hunk body did not reconcile against its @@ header


@dataclass
class DiffParse:
    """Full structural parse of a unified diff."""

    files: list[DiffFile] = field(default_factory=list)
    # A ``@@``-leading line whose shape ``_HUNK_RE`` could not parse (e.g. a
    # combined-merge ``@@@`` header) — an unrecognised structure we must not
    # silently treat as "no changes".
    saw_unparsed_hunk_header: bool = False


def _strip_prefix(path: str) -> str:
    """Strip a leading ``a/`` or ``b/`` diff prefix and surrounding quotes."""
    path = path.strip()
    # git may quote paths containing spaces/unicode: "b/some path".
    if len(path) >= 2 and path[0] == '"' and path[-1] == '"':
        path = path[1:-1]
    if path.startswith(("a/", "b/")):
        path = path[2:]
    return path


def parse_diff(diff_text: str) -> DiffParse:
    """Parse a unified diff into structured per-file results.

    Position-aware and robust to multi-file diffs, renames, ``/dev/null`` sides,
    binary hunks, and ``\\ No newline`` markers. This is the authoritative parser
    — ``iter_added_lines`` / ``added_lines_by_file`` are thin views over it.
    """
    result = DiffParse()
    cur: DiffFile | None = None

    # Hunk-body cursor. While either ``*_remaining`` is > 0 we are strictly
    # inside a hunk body and NEVER re-interpret a line as a header.
    new_line_no = 0
    old_remaining = 0
    new_remaining = 0

    def _handle_structural(raw: str) -> None:
        nonlocal cur, new_line_no, old_remaining, new_remaining

        if raw.startswith("diff --git"):
            parts = raw.split(" ")
            path = _strip_prefix(parts[3]) if len(parts) >= 4 else ""
            cur = DiffFile(path=path)
            result.files.append(cur)
            old_remaining = new_remaining = 0
            return

        if raw.startswith("+++ "):
            target = raw[4:].strip()
            if cur is None:
                # Plain ``diff -u`` output with no ``diff --git`` preamble.
                cur = DiffFile(path="")
                result.files.append(cur)
            if target == "/dev/null":
                cur.is_deletion = True
            else:
                cur.path = _strip_prefix(target)
            return

        if raw.startswith("--- "):
            # Old-side header; the ``+++`` that follows names the new file.
            return

        if raw.startswith("Binary files ") or raw.startswith("GIT binary patch"):
            if cur is not None:
                cur.is_binary = True
            return

        # Rename / copy / pure mode-change metadata — content-free, legitimately
        # yields no added lines (must not trip the fail-closed check).
        if raw.startswith(("rename from", "rename to", "copy from", "copy to",
                           "old mode", "new mode", "similarity index",
                           "dissimilarity index", "new file mode", "deleted file mode")):
            if cur is not None and cur.hunk_count == 0:
                cur.is_rename_or_mode_only = True
            return

        # A hunk header — the only place ``in_hunk`` is (re)armed.
        if raw.startswith("@@"):
            m = _HUNK_RE.match(raw)
            if not m or cur is None:
                # ``@@@`` combined-merge header or a shape we do not model.
                result.saw_unparsed_hunk_header = True
                return
            new_start = int(m.group(3))
            new_len = int(m.group(4)) if m.group(4) is not None else 1
            old_len = int(m.group(2)) if m.group(2) is not None else 1
            new_line_no = new_start
            new_remaining = new_len
            old_remaining = old_len
            cur.hunk_count += 1
            cur.is_rename_or_mode_only = False
            return

        # Anything else outside a hunk (``index …``, blank separators, git
        # trailer noise) is ignored.

    for raw in diff_text.splitlines():
        in_hunk_body = old_remaining > 0 or new_remaining > 0

        if in_hunk_body:
            first = raw[:1]
            if first == "+":
                if cur is not None:
                    cur.added.append(AddedLine(cur.path, new_line_no, raw[1:]))
                new_line_no += 1
                new_remaining -= 1
            elif first == "-":
                old_remaining -= 1
            elif first == " ":
                new_line_no += 1
                new_remaining -= 1
                old_remaining -= 1
            elif first == "\\":
                # "\ No newline at end of file" — metadata, consumes nothing.
                pass
            elif raw == "":
                # A truly empty line inside a hunk = a blank context line whose
                # leading space some tools drop. Treat as context.
                new_line_no += 1
                new_remaining -= 1
                old_remaining -= 1
            else:
                # An unexpected byte while the hunk still owes lines: the hunk
                # body did not reconcile against its @@ header. Flag it and let
                # the line be re-interpreted structurally.
                if cur is not None:
                    cur.anomaly = True
                old_remaining = new_remaining = 0
                _handle_structural(raw)
            continue

        # F2 (SEC-FTR-MSO-2026-0400): out of the hunk body, a line that still
        # begins with '+'/'-' — and is NOT a '+++ '/'--- ' file header — is diff
        # BODY that overflows the hunk's declared @@ count (the header
        # under-declared its length). The old code let ``_handle_structural``
        # silently ignore it, which drops the extra added line(s) from evaluation
        # entirely — a fail-open enforcement bypass reachable via --diff-file /
        # stdin. Flag the file as an anomaly instead and let the fail-closed check
        # in ``ci_verify`` reject the whole diff (exit 2).
        if (
            cur is not None
            and cur.hunk_count > 0
            and raw[:1] in ("+", "-")
            and not raw.startswith(("+++ ", "--- "))
        ):
            cur.anomaly = True
            continue

        _handle_structural(raw)

    # A hunk that never delivered all its declared lines before the diff ended.
    if (old_remaining > 0 or new_remaining > 0) and cur is not None:
        cur.anomaly = True

    return result


def iter_added_lines(diff_text: str) -> Iterator[AddedLine]:
    """Yield every added line in a unified diff, with its new-file line number.

    Position-aware (see the module docstring's security note). Deletions and
    context lines are skipped; header lines and ``\\ No newline`` markers are
    never emitted, and an added line whose content begins with ``++ ``/``-- ``
    is NOT mistaken for a header.
    """
    for f in parse_diff(diff_text).files:
        yield from f.added


def added_lines_by_file(diff_text: str) -> dict[str, list[AddedLine]]:
    """Group added lines by their new-file path (preserving order)."""
    grouped: dict[str, list[AddedLine]] = {}
    for line in iter_added_lines(diff_text):
        grouped.setdefault(line.file_path, []).append(line)
    return grouped
