"""
Governance compliance evidence report — FTR-MSO-2026-0399
(PLAN-PLN-MSO-2026-0372 S9 row 4, governance Phase 4).

Produces a SOC2/ISO-mappable *evidence document* for governed mode. The report
is assembled from REAL state — never a static template:

  * **Policy inventory** — every bundle in force (built-in + workspace/user),
    its version/tier/issuer/signed-status, and the full flattened rule list.
  * **Provenance** — pinned trusted keys, anti-rollback version floors, and
    whether the workspace bundle is Ed25519-signed (Phase 2 machinery).
  * **Enforcement statistics** — ``policy.eval`` / ``policy.deny`` /
    ``policy.breakglass`` counts, denials broken down by rule + severity, and
    break-glass grants/refusals, all read from the hash-chained audit log
    (``maestro/audit/log.py``), plus a chain-integrity verdict.
  * **Control mapping** — the concrete evidence backing SOC2 CC5.3 / CC5.1 /
    CC9.2 and ISO/IEC 27001 A.5.1 / A.8.9 (the two controls previously
    documented as customer-owned; see docs/internal/COMPLIANCE-MAPPING.md).

The module is pure-ish: ``collect_evidence`` reads state and returns a plain
dict; ``render_markdown`` turns that dict into the evidence document. Every
audit read is defensive — a non-enterprise workspace (audit inactive) still
produces a valid report, just with zeroed statistics and an explanatory note.
"""
from __future__ import annotations

import datetime as _dt
from pathlib import Path
from typing import Any

_POLICY_ACTIONS = ("policy.eval", "policy.deny", "policy.breakglass")


def _utc_now_iso() -> str:
    return _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


# ---------------------------------------------------------------------------
# Evidence collection
# ---------------------------------------------------------------------------

def _collect_inventory(workspace: Path | None, *, verify: bool) -> tuple[list[dict], list[dict]]:
    """Return (bundles, rules) inventories from the currently-loaded policy."""
    from maestro.governance.loader import load_bundles
    from maestro.governance.signing import is_signed

    bundles_out: list[dict] = []
    rules_out: list[dict] = []
    bundle_objs = load_bundles(workspace, verify=verify)
    for b in bundle_objs:
        # Built-in org packs are integrity-manifest verified (unsigned); a
        # workspace/user bundle may carry an Ed25519 envelope — reflect that.
        signed = False
        try:
            signed = b.issuer not in ("", "maestro-builtin") and b.tier != "org"
        except Exception:
            signed = False
        bundles_out.append({
            "bundleId": b.bundle_id,
            "version": b.version,
            "tier": b.tier,
            "issuer": b.issuer or "-",
            "governedMode": b.governed_mode,
            "defaultAction": b.default_action,
            "ruleCount": len(b.rules),
            "verification": "ed25519-signature" if signed else "sha256-manifest",
        })
        for r in b.rules:
            rules_out.append({
                "id": r.id,
                "action": r.action,
                "severity": r.severity,
                "tier": r.tier,
                "tool": list(r.match.tool),
                "toolPattern": r.match.tool_pattern or "",
                "reason": r.reason,
            })
    # Mark the workspace bundle signed/unsigned from its raw envelope, if present.
    if workspace is not None:
        try:
            import json
            from maestro.workspace import MSO_DIR_NAME
            wb = Path(workspace) / MSO_DIR_NAME / "config" / "policy-bundle.json"
            if wb.exists():
                raw = json.loads(wb.read_text(encoding="utf-8"))
                sig = is_signed(raw)
                for entry in bundles_out:
                    if entry["bundleId"] == raw.get("bundleId"):
                        entry["verification"] = (
                            "ed25519-signature" if sig else "unsigned-workspace-bundle"
                        )
        except Exception:
            pass
    return bundles_out, rules_out


def _collect_provenance(workspace: Path | None) -> dict:
    """Trusted keys + anti-rollback version floors (Phase 2 machinery)."""
    prov: dict[str, Any] = {"trustedKeys": [], "versionFloors": {}, "notes": []}
    try:
        from maestro.governance import keys as _keys
        trusted = _keys.load_trusted_keys(workspace)
        prov["trustedKeys"] = [
            {"keyId": kid, "status": k.status, "source": k.source}
            for kid, k in sorted(trusted.items())
        ]
    except Exception as exc:  # noqa: BLE001
        prov["notes"].append(f"trusted-key registry unavailable: {exc}")
    try:
        from maestro.governance import rollback as _rollback
        from maestro.workspace import get_artefact_root
        root = get_artefact_root(workspace) if workspace else get_artefact_root()
        ledger = _rollback.load_ledger(root)
        prov["versionFloors"] = ledger.get("bundles", {}) if isinstance(ledger, dict) else {}
    except Exception as exc:  # noqa: BLE001
        prov["notes"].append(f"version-floor ledger unavailable: {exc}")
    return prov


def _collect_audit_stats(workspace: Path | None) -> dict:
    """Read policy.* events from the hash-chained audit log (defensive)."""
    stats: dict[str, Any] = {
        "enterprise": False,
        "active": False,
        "chainVerified": None,
        "chainErrors": [],
        "totals": {a: 0 for a in _POLICY_ACTIONS},
        "denialsByRule": {},
        "denialsBySeverity": {},
        "breakglassByResult": {},
        "recentDenials": [],
        "recentBreakglass": [],
        "note": "",
    }
    if workspace is None:
        stats["note"] = "No workspace resolved — audit statistics unavailable."
        return stats
    try:
        from maestro.audit import get_audit_log
    except Exception as exc:  # noqa: BLE001
        stats["note"] = f"audit subsystem unavailable: {exc}"
        return stats

    try:
        log = get_audit_log(workspace)
    except Exception as exc:  # noqa: BLE001 — e.g. AuditPolicyError (anchor not configured)
        stats["note"] = f"audit log inactive or policy-blocked: {exc}"
        return stats

    log_path = getattr(log, "_log_path", None)
    if log_path is None or not Path(log_path).exists():
        stats["note"] = (
            "Audit log is not active (enterprise disabled or no events yet). "
            "Governance decisions are still recorded to the lifecycle log; "
            "enable enterprise mode + an anchor provider for the tamper-evident trail."
        )
        return stats

    stats["active"] = True
    stats["enterprise"] = True
    recent_denials: list[dict] = []
    recent_bg: list[dict] = []
    try:
        for entry in log.iterate():
            if entry.action not in _POLICY_ACTIONS:
                continue
            stats["totals"][entry.action] += 1
            meta = entry.metadata or {}
            if entry.action == "policy.deny":
                rule = str(meta.get("ruleId", "default"))
                sev = str(meta.get("severity", "unknown"))
                stats["denialsByRule"][rule] = stats["denialsByRule"].get(rule, 0) + 1
                stats["denialsBySeverity"][sev] = stats["denialsBySeverity"].get(sev, 0) + 1
                recent_denials.append({
                    "timestamp": entry.timestamp, "actor": entry.actor,
                    "target": entry.target, "ruleId": rule, "severity": sev,
                })
            elif entry.action == "policy.breakglass":
                res = str(entry.result)
                stats["breakglassByResult"][res] = stats["breakglassByResult"].get(res, 0) + 1
                recent_bg.append({
                    "timestamp": entry.timestamp, "actor": entry.actor,
                    "guard": str(meta.get("guard", entry.target)), "result": res,
                    "reason": str(meta.get("reason", "")),
                })
    except Exception as exc:  # noqa: BLE001
        stats["note"] = f"partial read ({exc})"

    stats["recentDenials"] = recent_denials[-10:]
    stats["recentBreakglass"] = recent_bg[-10:]

    # Chain integrity — the tamper-evidence claim the report attests to.
    try:
        ok, errors = log.verify_chain()
        stats["chainVerified"] = bool(ok)
        stats["chainErrors"] = list(errors)[:10]
    except Exception as exc:  # noqa: BLE001
        stats["chainVerified"] = None
        stats["chainErrors"] = [f"verify_chain failed: {exc}"]
    return stats


# The compliance control cross-reference. Kept here (not in a doc) so the report
# maps live evidence → control at generation time. Prose lives in
# docs/internal/COMPLIANCE-MAPPING.md.
_CONTROL_MAP = [
    ("SOC2 CC5.3",
     "The entity deploys control activities through policies and procedures.",
     "Signed org policy bundle in force (precedence-enforced, local config cannot relax); "
     "policy inventory + version floor below."),
    ("SOC2 CC5.1",
     "Selects and develops control activities that mitigate risks.",
     "Built-in deny packs (destructive-data, protected-branch, env-fencing, secret-handling, "
     "network-egress) evaluated on every mutating tool call."),
    ("SOC2 CC9.2",
     "Assesses and manages vendor / third-party (MCP) risk.",
     "mcp-allowlist pack: MCP tool invocations deny-by-default; only an org ALLOW carves out an approved server."),
    ("ISO/IEC 27001 A.5.1",
     "Policies for information security (management direction).",
     "Ed25519-signed org bundle = management-approved policy an engineer cannot silently strip; "
     "trusted-key registry + provenance below."),
    ("ISO/IEC 27001 A.8.9",
     "Configuration management.",
     "Anti-rollback version floor + SHA-256 integrity manifest on the built-in packs; tamper => fail-closed."),
]


def collect_evidence(workspace: Path | None, *, verify: bool = True) -> dict:
    """Assemble the full evidence dict from live governance + audit state."""
    from maestro.governance import resolve_governed_mode

    bundles, rules = _collect_inventory(workspace, verify=verify)
    audit = _collect_audit_stats(workspace)
    provenance = _collect_provenance(workspace)
    try:
        mode = resolve_governed_mode(workspace, None)
    except Exception:
        mode = "off"

    return {
        "schema": "maestro.governance.evidence/1.0",
        "generatedAt": _utc_now_iso(),
        "workspace": str(workspace) if workspace else "",
        "governedMode": mode,
        "bundles": bundles,
        "ruleInventory": rules,
        "provenance": provenance,
        "audit": audit,
        "controls": [
            {"control": c, "requirement": req, "evidence": ev}
            for (c, req, ev) in _CONTROL_MAP
        ],
    }


# ---------------------------------------------------------------------------
# Rendering
# ---------------------------------------------------------------------------

def _md_table(headers: list[str], rows: list[list[str]]) -> str:
    if not rows:
        return "_(none)_\n"
    out = ["| " + " | ".join(headers) + " |",
           "|" + "|".join(["---"] * len(headers)) + "|"]
    for r in rows:
        out.append("| " + " | ".join(str(c).replace("|", "\\|") for c in r) + " |")
    return "\n".join(out) + "\n"


def render_markdown(evidence: dict) -> str:
    a = evidence["audit"]
    totals = a["totals"]
    lines: list[str] = []
    L = lines.append

    L("# Governance Compliance Evidence")
    L("")
    L(f"- **Generated:** {evidence['generatedAt']}")
    L(f"- **Workspace:** `{evidence['workspace'] or '(unresolved)'}`")
    L(f"- **Governed mode:** `{evidence['governedMode']}`")
    L(f"- **Schema:** `{evidence['schema']}`")
    L("")
    L("> Generated by `mso policy report` from live policy state and the "
      "hash-chained audit log. This is control evidence, not a static template — "
      "every count below is read from `.mso/audit/log.jsonl` at generation time.")
    L("")

    # 1. Policy inventory
    L("## 1. Policy inventory (bundles in force)")
    L("")
    L(_md_table(
        ["bundleId", "version", "tier", "issuer", "rules", "verification"],
        [[b["bundleId"], b["version"], b["tier"], b["issuer"], b["ruleCount"], b["verification"]]
         for b in evidence["bundles"]],
    ))
    L(f"**Total rules in force:** {len(evidence['ruleInventory'])}")
    L("")
    L("<details><summary>Full rule inventory</summary>")
    L("")
    L(_md_table(
        ["ruleId", "action", "severity", "tier", "tool / toolPattern"],
        [[r["id"], r["action"], r["severity"], r["tier"],
          (", ".join(r["tool"]) or r["toolPattern"] or "-")]
         for r in evidence["ruleInventory"]],
    ))
    L("</details>")
    L("")

    # 2. Provenance
    L("## 2. Bundle provenance")
    L("")
    prov = evidence["provenance"]
    L("**Pinned trusted keys** (Ed25519 verification roots):")
    L("")
    L(_md_table(
        ["keyId", "status", "source"],
        [[k["keyId"], k["status"], k["source"]] for k in prov["trustedKeys"]],
    ))
    L("**Anti-rollback version floors** (highest bundle version accepted per id):")
    L("")
    floor_rows = [[bid, e.get("version", "?"), e.get("lastVerifiedAt", "-")]
                  for bid, e in sorted((prov["versionFloors"] or {}).items())]
    L(_md_table(["bundleId", "floor", "lastVerified"], floor_rows))
    for note in prov.get("notes", []):
        L(f"> _note: {note}_")
    L("")

    # 3. Enforcement statistics
    L("## 3. Enforcement statistics (from the audit log)")
    L("")
    if not a["active"]:
        L(f"> ⚠ {a['note']}")
        L("")
    L(_md_table(
        ["event", "count"],
        [["policy.eval (warns/evaluations)", totals["policy.eval"]],
         ["policy.deny (blocked actions)", totals["policy.deny"]],
         ["policy.breakglass (bypass attempts)", totals["policy.breakglass"]]],
    ))
    if a["denialsByRule"]:
        L("**Denials by rule:**")
        L("")
        L(_md_table(["ruleId", "denials"],
                    [[k, v] for k, v in sorted(a["denialsByRule"].items(), key=lambda x: -x[1])]))
    if a["denialsBySeverity"]:
        L("**Denials by severity:**")
        L("")
        L(_md_table(["severity", "denials"],
                    [[k, v] for k, v in sorted(a["denialsBySeverity"].items())]))
    if a["breakglassByResult"]:
        L("**Break-glass by outcome:**")
        L("")
        L(_md_table(["result", "count"],
                    [[k, v] for k, v in sorted(a["breakglassByResult"].items())]))
    if a["recentDenials"]:
        L("**Most recent denials:**")
        L("")
        L(_md_table(
            ["timestamp", "actor", "ruleId", "severity", "target"],
            [[d["timestamp"], d["actor"], d["ruleId"], d["severity"], d["target"]]
             for d in a["recentDenials"]],
        ))
    if a["recentBreakglass"]:
        L("**Most recent break-glass events:**")
        L("")
        L(_md_table(
            ["timestamp", "actor", "guard", "result", "reason"],
            [[d["timestamp"], d["actor"], d["guard"], d["result"], d["reason"]]
             for d in a["recentBreakglass"]],
        ))
    L("")

    # 4. Chain integrity
    L("## 4. Audit-chain integrity")
    L("")
    cv = a["chainVerified"]
    verdict = {True: "✓ VERIFIED — hash chain intact", False: "✗ FAILED — see errors",
               None: "— not evaluated (audit inactive)"}[cv]
    L(f"**Verdict:** {verdict}")
    if a["chainErrors"]:
        L("")
        for e in a["chainErrors"]:
            L(f"- {e}")
    L("")
    L("> Tail-truncation of a local log is only detectable against an external "
      "anchor receipt (S3 Object Lock). Run `mso audit anchor --auto` to anchor "
      "the head hash + entry count for truncation/rewrite detection.")
    L("")

    # 5. Control mapping
    L("## 5. Control mapping (SOC2 / ISO 27001)")
    L("")
    L(_md_table(
        ["control", "requirement", "evidence in this report"],
        [[c["control"], c["requirement"], c["evidence"]] for c in evidence["controls"]],
    ))
    L("")
    L("Full narrative + trust-boundary caveats: `docs/internal/COMPLIANCE-MAPPING.md`.")
    L("")
    return "\n".join(lines)


def write_report(
    workspace: Path | None,
    *,
    verify: bool = True,
    output: Path | None = None,
) -> tuple[Path, dict]:
    """Collect evidence, render Markdown, and write it under the artefact root.

    Returns (path_written, evidence_dict). Default location:
    ``<artefact-root>/reports/compliance/POLICY-EVIDENCE-<UTC-stamp>.md``.
    """
    evidence = collect_evidence(workspace, verify=verify)
    md = render_markdown(evidence)

    if output is not None:
        out_path = Path(output)
    else:
        from maestro.workspace import get_artefact_root
        root = get_artefact_root(workspace) if workspace else get_artefact_root()
        stamp = evidence["generatedAt"].replace(":", "").replace("-", "")
        out_path = root / "reports" / "compliance" / f"POLICY-EVIDENCE-{stamp}.md"

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(md, encoding="utf-8")
    return out_path, evidence
