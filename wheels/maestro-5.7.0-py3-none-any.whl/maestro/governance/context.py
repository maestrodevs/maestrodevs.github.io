"""
Governance evaluation context.

FTR-MSO-2026-0392 (PLAN-PLN-MSO-2026-0372 Phase 1).

Builds the immutable ``EvalContext`` the engine reasons over from a Claude Code
hook payload. Kept free of policy logic so the same context can be produced by
the pretool hook (runtime) and, later, the CI backstop (diff evaluation).
"""
from __future__ import annotations

import os
from dataclasses import dataclass

# Tools that mutate state. In governed FAIL-CLOSED mode a governance-eval error
# denies these; read-only tools (Read/Glob/Grep) are still allowed on error
# because they cannot themselves cause harm.
MUTATING_TOOLS = frozenset({"Bash", "Edit", "MultiEdit", "Write", "NotebookEdit"})


def _extract_write_content(tool_name: str, tool_input: dict) -> str:
    """Concatenate the write payload(s) of a file-mutating tool into one string."""
    if tool_name == "Write":
        return tool_input.get("content", "") or ""
    if tool_name == "Edit":
        return tool_input.get("new_string", "") or ""
    if tool_name == "MultiEdit":
        parts = []
        for edit in tool_input.get("edits", []) or []:
            ns = edit.get("new_string", "")
            if ns:
                parts.append(ns)
        return "\n".join(parts)
    if tool_name == "NotebookEdit":
        return tool_input.get("new_source") or tool_input.get("cell_source") or ""
    return ""


@dataclass(frozen=True)
class EvalContext:
    """Everything a rule may match against — a pure snapshot of one tool call."""

    tool: str
    command: str          # Bash command text (empty for non-Bash tools)
    file_path: str        # target path for file-mutating tools (empty otherwise)
    content: str          # write payload for file-mutating tools (empty otherwise)
    role: str             # crew role code (BLD/TST/…), best-effort
    cwd: str
    worktree: str         # MAESTRO_REPO_PATH, best-effort
    env_class: str        # "prod" | "unknown" | "dev" — coarse environment class

    @property
    def is_mutating(self) -> bool:
        return self.tool in MUTATING_TOOLS

    @property
    def subject_text(self) -> str:
        """The text a rule's commandPattern is searched against.

        For Bash it is the command; for a file-mutating tool it is the target
        path plus the write payload (so a secret/DROP written via Write is
        still visible to a pattern rule).
        """
        if self.command:
            return self.command
        if self.file_path or self.content:
            return f"{self.file_path}\n{self.content}"
        return ""


def _classify_env(env: dict) -> str:
    """Coarse environment classification for context narrowing.

    Phase 1 heuristic: presence of a ``*_PROD_*`` / ``*PROD`` env var marks the
    session as prod-adjacent. Absent any signal we return "unknown" (which the
    built-in packs treat as still-risky), never a falsely-reassuring "dev".
    """
    for key in env:
        up = key.upper()
        if "_PROD_" in up or up.endswith("_PROD") or up.startswith("PROD_"):
            return "prod"
    return "unknown"


def build_context(hook_input: dict, env: dict | None = None) -> EvalContext:
    """Construct an EvalContext from a Claude Code PreToolUse hook payload."""
    env = env if env is not None else os.environ
    tool_name = hook_input.get("tool_name", "") or ""
    tool_input = hook_input.get("tool_input", {}) or {}

    command = tool_input.get("command", "") if tool_name == "Bash" else ""
    file_path = (
        tool_input.get("file_path")
        or tool_input.get("filePath")
        or tool_input.get("notebook_path")
        or ""
    )
    content = _extract_write_content(tool_name, tool_input)

    role = env.get("MAESTRO_ROLE", "") or ""
    cwd = hook_input.get("cwd", "") or env.get("PWD", "") or os.getcwd()
    worktree = env.get("MAESTRO_REPO_PATH", "") or ""

    return EvalContext(
        tool=tool_name,
        command=command,
        file_path=file_path,
        content=content,
        role=role,
        cwd=cwd,
        worktree=worktree,
        env_class=_classify_env(env),
    )
