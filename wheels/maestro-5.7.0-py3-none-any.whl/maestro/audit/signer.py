from __future__ import annotations

import base64
import hashlib
import hmac
import json
from pathlib import Path
from typing import Any


def _canonical(d: dict[str, Any]) -> bytes:
    """Deterministic JSON serialisation (sorted keys, no trailing whitespace)."""
    return json.dumps(d, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("utf-8")


def compute_hash(entry_body: dict[str, Any]) -> str:
    """SHA-256 over the canonical entry body (excluding hash and signature fields)."""
    body = {k: v for k, v in entry_body.items() if k not in ("hash", "signature")}
    return hashlib.sha256(_canonical(body)).hexdigest()


def _load_workspace_key(workspace: Path) -> bytes | None:
    from maestro.workspace import resolve_artefact_dir
    key_path = resolve_artefact_dir(workspace) / "identity" / "workspace-signing.key"
    if not key_path.exists():
        return None
    try:
        raw = key_path.read_text(encoding="utf-8").strip()
        return base64.b64decode(raw)
    except Exception:
        return None


def sign_entry(entry_body: dict[str, Any], workspace: Path) -> str:
    """
    Sign the canonical entry body.  Returns a 'hmac:<hex>' string.
    Falls back to empty string when no signing key is available.
    """
    key = _load_workspace_key(workspace)
    if key is None:
        return ""
    body = {k: v for k, v in entry_body.items() if k not in ("hash", "signature")}
    mac = hmac.new(key, _canonical(body), hashlib.sha256).hexdigest()
    return f"hmac:{mac}"


def has_signing_key(workspace: Path) -> bool:
    """True when a workspace signing key is configured."""
    return _load_workspace_key(workspace) is not None


def verify_signature(
    entry_body: dict[str, Any],
    signature: str,
    workspace: Path,
    *,
    strict: bool = False,
) -> bool:
    """Verify an entry signature.

    Audit finding H8 — fail-closed mode:
      When ``strict`` is True (used whenever a signing key is configured, i.e.
      the log is meant to be signed), an **empty signature** or a **missing
      key** is a verification FAILURE, not a pass. This closes the forge path
      where an attacker strips the ``signature`` field to ``""`` (which
      previously returned True) and re-chains the unkeyed SHA-256.

      When ``strict`` is False the legacy behaviour is preserved: absence of a
      signature or key is treated as "signing not configured" and passes, so
      unsigned dev/test logs still verify.
    """
    key = _load_workspace_key(workspace)
    if strict:
        if not signature or key is None:
            return False
    else:
        if not signature:
            return True
        if key is None:
            return True
    body = {k: v for k, v in entry_body.items() if k not in ("hash", "signature")}
    expected = hmac.new(key, _canonical(body), hashlib.sha256).hexdigest()
    if not signature.startswith("hmac:"):
        return False
    return hmac.compare_digest(expected, signature[5:])
