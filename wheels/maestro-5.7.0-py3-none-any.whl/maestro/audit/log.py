from __future__ import annotations

import json
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator

from maestro.workspace import resolve_artefact_dir
from .types import AuditEntry, GENESIS_HASH
from .signer import compute_hash, has_signing_key, sign_entry, verify_signature
from .policy import AuditPolicyError, check_enterprise_anchor_policy, is_privileged_action


_LOG_RELPATH = Path("audit") / "log.jsonl"

_lock = threading.Lock()


def _load_enterprise_flag(workspace: Path) -> bool:
    ws_cfg = resolve_artefact_dir(workspace) / "config" / "workspace.json"
    if not ws_cfg.exists():
        return False
    try:
        data = json.loads(ws_cfg.read_text(encoding="utf-8"))
        flag = data.get("enterprise", False)
        if isinstance(flag, bool):
            return flag
        if isinstance(flag, dict):
            return True
        return bool(flag)
    except Exception:
        return False


def _resolve_actor(workspace: Path) -> str:
    try:
        from maestro.identity.auth import resolve_caller
        return resolve_caller(workspace)
    except Exception:
        return "anonymous"


class AuditLog:
    """
    Hash-chained append-only audit log backed by a JSONL file.

    Feature-gated: when enterprise=false in workspace.json all writes
    are silently skipped (fail-open).
    """

    def __init__(self, workspace: Path, log_path: Path | None = None) -> None:
        self._workspace = workspace
        self._log_path = log_path or (resolve_artefact_dir(workspace) / _LOG_RELPATH)
        # Raises AuditPolicyError when enterprise=true but no anchorProvider configured.
        check_enterprise_anchor_policy(workspace)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def append(
        self,
        action: str,
        target: str,
        result: str = "ok",
        metadata: dict[str, Any] | None = None,
        actor: str | None = None,
    ) -> AuditEntry | None:
        if not _load_enterprise_flag(self._workspace):
            return None
        try:
            self._check_anchor_freshness_gate(action)
            return self._append_locked(action, target, result, metadata or {}, actor)
        except AuditPolicyError:
            raise
        except Exception:
            return None

    def iterate(self, since: datetime | None = None) -> Iterator[AuditEntry]:
        if not self._log_path.exists():
            return
        with open(self._log_path, encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    entry = AuditEntry.from_dict(json.loads(line))
                except Exception:
                    continue
                if since is not None:
                    try:
                        ts = datetime.fromisoformat(entry.timestamp.replace("Z", "+00:00"))
                        if ts < since:
                            continue
                    except Exception:
                        pass
                yield entry

    def verify_chain(
        self,
        *,
        expected_head_hash: str | None = None,
        expected_count: int | None = None,
    ) -> tuple[bool, list[str]]:
        """
        Walk the entire chain and verify hashes and (when possible) signatures.
        Returns (ok, errors).  errors is empty on success.

        Audit findings H8/H9/H10:
          - When a signing key is configured the signature check runs in
            STRICT mode, so an attacker who strips the ``signature`` field to
            re-chain the unkeyed hash is now detected (previously fail-open).
          - ``expected_head_hash`` / ``expected_count`` let a caller that holds
            an *external anchor receipt* (the one artefact an on-host attacker
            cannot rewrite) detect tail-truncation and full-rewrite: pass the
            anchored head hash and/or entry count and this asserts the live log
            still matches. Without them, tail-truncation remains undetectable
            from the local log alone — that is the residual documented in the
            trust posture, addressed by anchoring.
        """
        errors: list[str] = []
        prev_hash = GENESIS_HASH
        expected_seq = 1
        strict = has_signing_key(self._workspace)
        last_hash = GENESIS_HASH
        count = 0

        for entry in self.iterate():
            count += 1
            # Sequence continuity
            if entry.seq != expected_seq:
                errors.append(f"seq gap: expected {expected_seq}, got {entry.seq}")
            expected_seq = entry.seq + 1

            # prevHash linkage
            if entry.prev_hash != prev_hash:
                errors.append(
                    f"seq {entry.seq}: prevHash mismatch "
                    f"(expected {prev_hash[:16]}…, got {entry.prev_hash[:16]}…)"
                )

            # Recompute hash
            body = entry.to_dict()
            expected_hash = compute_hash(body)
            if entry.hash != expected_hash:
                errors.append(
                    f"seq {entry.seq}: hash mismatch — entry has been tampered with"
                )

            # Signature (strict when signing is configured)
            if not verify_signature(body, entry.signature, self._workspace, strict=strict):
                errors.append(f"seq {entry.seq}: signature invalid")

            prev_hash = entry.hash
            last_hash = entry.hash

        # Anchored-commitment checks (truncation / rewrite detection).
        if expected_count is not None and count != expected_count:
            errors.append(
                f"entry count {count} does not match anchored count "
                f"{expected_count} — log may have been truncated or extended"
            )
        if expected_head_hash is not None and last_hash != expected_head_hash:
            errors.append(
                "head hash does not match the external anchor — log has been "
                "truncated or rewritten since the last anchor"
            )

        return (len(errors) == 0, errors)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _check_anchor_freshness_gate(self, action: str) -> None:
        """Write ANCHOR_OVERDUE to the lifecycle log and block privileged actions when the SLA is exceeded."""
        from .anchor.scheduler import check_anchor_freshness
        is_fresh, elapsed = check_anchor_freshness(self._workspace)
        if is_fresh:
            return
        # Write a single warning entry (guarded to avoid infinite recursion)
        if action != "audit.anchor_overdue":
            try:
                self._append_locked(
                    "audit.anchor_overdue",
                    "lifecycle",
                    "warning",
                    {"elapsedMinutes": round(elapsed, 1)},
                    "system",
                )
            except Exception:
                pass
        if is_privileged_action(action):
            raise AuditPolicyError(
                f"Anchor SLA exceeded ({elapsed:.0f} min since last anchor). "
                "Run 'mso audit anchor --auto' to resume privileged operations."
            )

    def _append_locked(
        self,
        action: str,
        target: str,
        result: str,
        metadata: dict[str, Any],
        actor: str | None,
    ) -> AuditEntry:
        with _lock:
            self._log_path.parent.mkdir(parents=True, exist_ok=True)

            prev_hash, seq = self._tail_state()

            if actor is None:
                actor = _resolve_actor(self._workspace)

            entry = AuditEntry(
                seq=seq,
                timestamp=datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z",
                actor=actor,
                action=action,
                target=target,
                result=result,
                metadata=metadata,
                prev_hash=prev_hash,
            )

            body = entry.to_dict()
            entry.hash = compute_hash(body)
            body["hash"] = entry.hash
            entry.signature = sign_entry(body, self._workspace)
            body["signature"] = entry.signature

            with open(self._log_path, "a", encoding="utf-8") as fh:
                fh.write(json.dumps(body, separators=(",", ":")) + "\n")

            return entry

    def _tail_state(self) -> tuple[str, int]:
        """Return (last_hash, next_seq) by reading the last line of the log."""
        if not self._log_path.exists():
            return GENESIS_HASH, 1
        last_line = ""
        with open(self._log_path, "rb") as fh:
            fh.seek(0, 2)
            size = fh.tell()
            if size == 0:
                return GENESIS_HASH, 1
            # scan backwards for last non-empty line
            pos = size - 1
            buf = b""
            while pos >= 0:
                fh.seek(pos)
                ch = fh.read(1)
                if ch == b"\n" and buf:
                    break
                buf = ch + buf
                pos -= 1
            last_line = buf.decode("utf-8", errors="replace").strip()

        if not last_line:
            return GENESIS_HASH, 1

        try:
            d = json.loads(last_line)
            return d.get("hash", GENESIS_HASH), d.get("seq", 0) + 1
        except Exception:
            return GENESIS_HASH, 1


def get_audit_log(workspace: Path) -> AuditLog:
    return AuditLog(workspace)
