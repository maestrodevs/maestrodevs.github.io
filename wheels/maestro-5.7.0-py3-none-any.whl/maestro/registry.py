"""
Maestro global project registry.

Manages ~/.maestro/projects.json so that `mso` commands can resolve
project workspaces by acronym from any directory using @PRJ syntax.

Schema v2 (FTR-MSO-2026-0363 — ADDITIVE; v1 entries keep working untouched)
---------------------------------------------------------------------------

::

    {
      "version": 2,                    // file-level marker (absent on pure-v1 files)
      "projects": {
        "GKT": {
          "schemaVersion": 2,
          "path": "C:/Repos/GKT-Coaching",          // workspace root (see dual-meaning note)
          "productRepo": "C:/Repos/GKT-Coaching",   // explicit product repo (v1: implied == path)
          "artefactRoot": "C:/Repos/GKT-Platform",  // OPTIONAL (Phase 2+); absent = embedded
          "artefactMode": "solo",                   // OPTIONAL: embedded|solo|shared; absent = embedded
          "repos": {                                // Phase 4 placeholder (validated now, consumed later)
            "GKT-Coaching-Platform": {
              "path": "C:/Repos/GKT-Coaching",
              "slug": "tavisbasing/GKT-Coaching-Platform",
              "defaultBranch": "main"
            }
          },
          "registered": "2026-07-15T00:00:00+00:00"
        }
      }
    }

v1 entries are just ``{path, registered}``. Migration is **on read only**:
:func:`list_projects` / :func:`get_project_entry` return every entry
normalised to the v2 shape in memory (``schemaVersion``/``productRepo``/
``repos`` defaulted). Nothing is written back to disk on read — a v1 entry is
upgraded on disk only when it is itself the target of an explicit mutation
(:func:`register_project`), never silently.

Dual-meaning note (documented per FTR-MSO-2026-0363; split lands in Phase 2):
``entry["path"]`` is used today as BOTH the ``.mso`` parent (workspace root)
AND the dispatch-subprocess ``cwd`` by the Hub (hub/server.py dispatch/stop
endpoints, hub/poller.py). In Phase 2 (artefact-repo mode) ``artefactRoot``
takes over as the ``.mso`` home while ``path`` remains the workspace root;
Hub consumers switch to ``artefactRoot`` then. Do NOT change Hub behaviour
from this module in the meantime.
"""

from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path

from maestro.workspace import get_maestro_home

# Test/override hook. When left ``None`` the live, env-aware resolver
# (:func:`maestro.workspace.get_maestro_home`) is consulted on every read/write
# so ``MAESTRO_HOME`` redirects the registry (BUG-MSO-2026-0387). Existing tests
# that ``monkeypatch.setattr(registry, "REGISTRY_FILE", tmp)`` keep working — a
# concrete path here wins over the resolver.
REGISTRY_FILE: Path | None = None

# How many timestamped ``projects.json.bak-*`` snapshots to retain. Every write
# backs up the prior file first, so a clobber is one-command recoverable
# (BUG-MSO-2026-0387). Restore the newest with, e.g.::
#
#     cp "$(ls -t ~/.maestro/projects.json.bak-* | head -1)" ~/.maestro/projects.json
#
# or, programmatically, :func:`restore_latest_backup`.
BACKUP_RETENTION = 5


def _registry_file() -> Path:
    """Resolve the registry path live so ``MAESTRO_HOME`` is always honoured.

    An explicit :data:`REGISTRY_FILE` override (set by tests) takes precedence;
    otherwise the file lives under the env-aware global home.
    """
    if REGISTRY_FILE is not None:
        return Path(REGISTRY_FILE)
    return get_maestro_home() / "projects.json"

# Schema version written on explicit mutations. v1 entries (no schemaVersion,
# just {path, registered}) remain valid indefinitely.
REGISTRY_SCHEMA_VERSION = 2

# Valid artefactMode values. Absence of the field means "embedded".
ARTEFACT_MODES = ("embedded", "solo", "shared")

# repos-map entry shape (Phase 4 placeholder — plan §4.2): key = repo name,
# value = per-repo checkout descriptor.
_REPO_ENTRY_REQUIRED_KEYS = ("path",)
_REPO_ENTRY_OPTIONAL_KEYS = (
    "slug", "defaultBranch", "cloneProtocol", "buildCommand", "testCommand",
)


def _load() -> dict:
    path = _registry_file()
    if path.exists():
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return {}
    return {}


def _prune_backups(path: Path, *, keep: int) -> None:
    """Keep only the newest *keep* ``<name>.bak-*`` snapshots for *path*."""
    backups = sorted(path.parent.glob(f"{path.name}.bak-*"))
    stale = backups if keep <= 0 else backups[:-keep]
    for old in stale:
        try:
            old.unlink()
        except OSError:
            pass


def _atomic_write_with_backup(path: Path, text: str, *, keep: int = BACKUP_RETENTION) -> None:
    """Write *text* to *path* atomically, snapshotting the prior file first.

    1. Back up the current file to a lexicographically-sortable timestamped
       ``<name>.bak-<UTC>`` (best-effort — a backup failure never blocks the
       write), then prune to the newest *keep*.
    2. Write to a sibling temp file and ``os.replace`` it into place, so a
       reader never observes a half-written registry and a crash cannot leave
       the real file truncated (BUG-MSO-2026-0387).
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
        backup = path.with_name(f"{path.name}.bak-{stamp}")
        try:
            backup.write_text(path.read_text(encoding="utf-8"), encoding="utf-8")
        except OSError:
            pass
        _prune_backups(path, keep=keep)
    tmp = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def _save(registry: dict) -> None:
    # File-level version marker rides along on explicit mutations only —
    # _save is never called from a read path.
    registry["version"] = REGISTRY_SCHEMA_VERSION
    _atomic_write_with_backup(_registry_file(), json.dumps(registry, indent=2))


def latest_backup() -> Path | None:
    """Return the newest ``projects.json.bak-*`` snapshot, or ``None``."""
    path = _registry_file()
    backups = sorted(path.parent.glob(f"{path.name}.bak-*"))
    return backups[-1] if backups else None


def restore_latest_backup() -> Path | None:
    """Restore the registry from its newest backup snapshot.

    Returns the backup Path that was restored, or ``None`` if none exists.
    The one-command recovery path documented on :data:`BACKUP_RETENTION`.
    """
    backup = latest_backup()
    if backup is None:
        return None
    # Direct atomic replace (no fresh .bak) so the newest snapshot stays the
    # known-good one — restoring must not bury it behind a copy of the clobber.
    path = _registry_file()
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    tmp.write_text(backup.read_text(encoding="utf-8"), encoding="utf-8")
    os.replace(tmp, path)
    return backup


# ---------------------------------------------------------------------------
# v2 validation + migration-on-read
# ---------------------------------------------------------------------------

def validate_artefact_mode(mode: str) -> None:
    """Raise ValueError unless *mode* is a valid artefactMode."""
    if mode not in ARTEFACT_MODES:
        raise ValueError(
            f"Invalid artefactMode {mode!r} — must be one of {', '.join(ARTEFACT_MODES)}."
        )


def validate_repos_map(repos: dict) -> None:
    """Validate a v2 ``repos`` map (Phase 4 placeholder schema).

    Key = repo name; value = ``{path, slug?, defaultBranch?, cloneProtocol?,
    buildCommand?, testCommand?}``. Raises ValueError with a specific message
    on the first violation.
    """
    if not isinstance(repos, dict):
        raise ValueError(f"repos must be a dict of repoName -> entry, got {type(repos).__name__}.")
    allowed = set(_REPO_ENTRY_REQUIRED_KEYS) | set(_REPO_ENTRY_OPTIONAL_KEYS)
    for name, entry in repos.items():
        if not isinstance(name, str) or not name.strip():
            raise ValueError(f"repos key {name!r} must be a non-empty repo name string.")
        if not isinstance(entry, dict):
            raise ValueError(f"repos[{name!r}] must be a dict, got {type(entry).__name__}.")
        for req in _REPO_ENTRY_REQUIRED_KEYS:
            if not isinstance(entry.get(req), str) or not entry[req].strip():
                raise ValueError(f"repos[{name!r}].{req} is required and must be a non-empty string.")
        for key, value in entry.items():
            if key not in allowed:
                raise ValueError(
                    f"repos[{name!r}] has unknown key {key!r} — allowed: {', '.join(sorted(allowed))}."
                )
            if not isinstance(value, str):
                raise ValueError(f"repos[{name!r}].{key} must be a string, got {type(value).__name__}.")


def migrate_entry(entry: dict) -> dict:
    """Return *entry* normalised to the v2 shape (pure — in memory only).

    v1 entries gain ``schemaVersion``, ``productRepo`` (defaults to ``path``:
    in embedded mode the product repo IS the workspace root) and an empty
    ``repos`` map. ``artefactRoot``/``artefactMode`` are NOT invented —
    their absence is meaningful (= embedded). Never written back to disk.
    """
    migrated = dict(entry)
    migrated.setdefault("schemaVersion", REGISTRY_SCHEMA_VERSION)
    if "path" in migrated:
        migrated.setdefault("productRepo", migrated["path"])
    migrated.setdefault("repos", {})
    return migrated


# ---------------------------------------------------------------------------
# Mutations (the single write path — init.py's _register_global was absorbed
# here by FTR-MSO-2026-0363)
# ---------------------------------------------------------------------------

def register_project(
    acronym: str,
    path: Path,
    *,
    product_repo: Path | str | None = None,
    artefact_root: Path | str | None = None,
    artefact_mode: str | None = None,
    repos: dict | None = None,
) -> None:
    """Add or update a project entry in the global registry (v2 shape).

    Only ``acronym`` and ``path`` are required. ``product_repo`` defaults to
    *path* (embedded mode: the workspace root is the product repo). The
    optional v2 fields are validated before anything is written; untouched
    sibling entries are persisted exactly as loaded (a v1 sibling stays v1
    on disk).
    """
    if artefact_mode is not None:
        validate_artefact_mode(artefact_mode)
    if repos is not None:
        validate_repos_map(repos)

    resolved_path = Path(path).resolve()
    entry: dict = {
        "schemaVersion": REGISTRY_SCHEMA_VERSION,
        "path": str(resolved_path),
        "productRepo": str(Path(product_repo).resolve()) if product_repo is not None
                       else str(resolved_path),
        "repos": repos if repos is not None else {},
        "registered": datetime.now(timezone.utc).isoformat(),
    }
    if artefact_root is not None:
        entry["artefactRoot"] = str(Path(artefact_root).resolve())
    if artefact_mode is not None:
        entry["artefactMode"] = artefact_mode

    registry = _load()
    registry.setdefault("projects", {})
    registry["projects"][acronym.upper()] = entry
    _save(registry)


def add_legacy_acronym(
    target_acronym: str,
    sub_acronym: str,
    *,
    source_acronym: str,
    source_path: Path | str,
    target_root: Path | str | None = None,
    id_count: int | None = None,
) -> None:
    """Record an imported sub-acronym namespace on the *target*'s entry.

    ``import-workspace`` (FTR-MSO-2026-0381) amalgamates a source workspace's
    durable plane into the target's artefact repo with IDs renamed
    ``<SOURCE>-* → <TARGET>-<SUB>-*``. This merges (never replaces) a
    ``legacyAcronyms`` map onto the target entry so the sub-acronym mapping is
    auditable and idempotent re-imports overwrite the same key:

    ::

        "legacyAcronyms": {
          "POR": {"sourceAcronym": "POR", "sourcePath": "…", "idCount": 12}
        }

    Unlike :func:`register_project`, this is a read-modify-write that preserves
    every other field on the target entry (artefactRoot, repos, …). If the
    target is not yet registered it is created minimally from *target_root*.
    """
    registry = _load()
    projects = registry.setdefault("projects", {})
    key = target_acronym.upper()
    entry = projects.get(key)
    if entry is None:
        if target_root is None:
            raise KeyError(
                f"target project {key!r} is not registered — pass target_root "
                f"to create it."
            )
        resolved = Path(target_root).resolve()
        entry = {
            "schemaVersion": REGISTRY_SCHEMA_VERSION,
            "path": str(resolved),
            "productRepo": str(resolved),
            "repos": {},
            "registered": datetime.now(timezone.utc).isoformat(),
        }
        projects[key] = entry
    entry.setdefault("schemaVersion", REGISTRY_SCHEMA_VERSION)
    legacy = entry.setdefault("legacyAcronyms", {})
    record: dict = {
        "sourceAcronym": source_acronym.upper(),
        "sourcePath": str(Path(source_path).resolve()),
        "importedAt": datetime.now(timezone.utc).isoformat(),
    }
    if id_count is not None:
        record["idCount"] = id_count
    legacy[sub_acronym.upper()] = record
    _save(registry)


def mark_imported(source_acronym: str, *, into: str, sub: str) -> bool:
    """Mark a *source* project entry as imported/retired into another project.

    Records ``imported=True``, ``importedInto`` and ``importedAs`` on the
    source entry (read-modify-write; other fields preserved). Returns ``False``
    if the source acronym is not registered (a source workspace need not have
    been in the global registry — the import still succeeds).
    """
    registry = _load()
    projects = registry.get("projects", {})
    entry = projects.get(source_acronym.upper())
    if entry is None:
        return False
    entry.setdefault("schemaVersion", REGISTRY_SCHEMA_VERSION)
    entry["imported"] = True
    entry["importedInto"] = into.upper()
    entry["importedAs"] = sub.upper()
    _save(registry)
    return True


def unregister_project(acronym: str) -> bool:
    """Remove a project from the registry. Returns True if it existed."""
    registry = _load()
    projects = registry.get("projects", {})
    key = acronym.upper()
    if key in projects:
        del projects[key]
        registry["projects"] = projects
        _save(registry)
        return True
    return False


# ---------------------------------------------------------------------------
# Reads (v1 and v2 entries come back identically normalised)
# ---------------------------------------------------------------------------

def get_project_entry(acronym: str) -> dict | None:
    """Return the normalised (v2-shape) entry for *acronym*, or None."""
    entry = _load().get("projects", {}).get(acronym.upper())
    if entry is None:
        return None
    return migrate_entry(entry)


def get_project_path(acronym: str) -> Path | None:
    """Return the registered workspace path for the given acronym, or None."""
    entry = _load().get("projects", {}).get(acronym.upper())
    if entry and "path" in entry:
        p = Path(entry["path"])
        if p.exists():
            return p
    return None


def list_projects() -> dict:
    """Return all registered projects keyed by acronym, each normalised to
    the v2 shape in memory (v1 entries on disk are left untouched)."""
    return {
        acronym: migrate_entry(entry)
        for acronym, entry in _load().get("projects", {}).items()
    }
