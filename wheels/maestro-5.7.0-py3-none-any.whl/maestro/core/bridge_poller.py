#!/usr/bin/env python3
# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
"""
Mobile Command Bridge — Inbound Poller v1.0

Polls a GitHub Gist for commands sent by the Captain from mobile (via Slack),
executes them locally, and writes results back to the gist.

Flow:
  1. Captain sends command via Slack → Slack bot writes to GitHub Gist
  2. BridgePoller polls the gist on a configurable interval (default 30s)
  3. Unprocessed commands are validated, executed, and results written back
  4. Slack bot reads results from gist and relays to Captain

Daemon management:
  - PID file at .mso/bridge/poller.pid
  - Windows-compatible process detection (ctypes OpenProcess)
  - Clean shutdown via --stop flag or PID file removal

Security:
  - Command whitelist enforced before execution
  - JSON schema validation on all inbound commands
  - Tokens never logged or exposed in output
"""

import argparse
import json
import logging
import os
import re
import subprocess
from maestro.core.proc import run_hidden, popen_hidden  # FTR-MSO-2026-0408: windowless subprocess
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

try:
    from maestro.egress.filter import EgressDenied, install_egress_filter
    _EGRESS_AVAILABLE = True
except ImportError:
    _EGRESS_AVAILABLE = False
    # Define a dedicated dummy type — aliasing to Exception would make any
    # later `except EgressDenied:` clause swallow unrelated errors and
    # mis-report them as egress denials.
    class EgressDenied(Exception):  # type: ignore[no-redef]
        pass


# =============================================================================
# CONSTANTS
# =============================================================================

# BUG-MSO-2026-0463: every entry below is a deliberate allowlist decision, not
# an accreted one. Each is assessed for blast radius — what it can do to the
# fleet/state if invoked by anyone who can post in the bridge channel.
#
#   approve/reject   moderate — advances or archives a review-gate order.
#                     BUG-MSO-2026-0469: this used to write a status field
#                     directly into whatever voyage/plan JSON file loosely
#                     matched the target string, with no capability check.
#                     _handle_approval now shells out to `mso review
#                     approve|reject` (same mechanism dispatch/cleanup use),
#                     so it is capability-gated (require_capability
#                     ("voyage.approve", ...) in cmd_review_approve/reject)
#                     and target-matches an order_id exactly — no more
#                     substring search. Reversible (re-approve / re-reject);
#                     does not touch running processes.
#   dispatch         moderate — launches crew processes (state-changing, can
#                     spend tokens/CI). Already capability-gated in the CLI
#                     itself: cmd_dispatch() calls require_capability
#                     ("fleet.dispatch", ...), which the bridge inherits for
#                     free because this handler shells out to `mso dispatch`.
#   status           none — read-only dashboard snapshot.
#   cleanup          HIGH — kills rogue fleet processes and resets crew state.
#                     The single most destructive command in this list: an
#                     accidental or hostile invocation mid-voyage destroys
#                     in-flight crew work (salvage branches mitigate, they do
#                     not eliminate the loss). Retained deliberately — a
#                     remote kill switch has legitimate value when a fleet is
#                     runaway and nobody is at the machine — but it is now
#                     capability-gated (require_capability("fleet.cleanup", ...)
#                     in cmd_cleanup(), inherited via the same CLI shell-out as
#                     dispatch) AND requires an explicit confirmation round-trip
#                     (see _handle_cleanup below) rather than executing on the
#                     first message, mirroring the Hub's broom button
#                     (dry-run-then-confirm, run_housekeeping_sweep).
#   crew             low-moderate — `--cleanup` on a SINGLE crew slot kills
#                     that one process (narrower blast radius than the fleet-
#                     wide `cleanup` above); other flags (--status/--watch) are
#                     read-only. Not gated by this bug — out of scope (SEC-0461
#                     named `cleanup` specifically) — flagged here as a
#                     follow-up candidate rather than left unassessed.
#   usage            none — read-only token/cost report.
#   verify           low — runs the post-voyage build/test verification
#                     command; consumes CPU/time but mutates no fleet state.
#   order            low — creates a new FTR order JSON. Pre-existing input
#                     validation gap (unbounded description, racy sequence
#                     number) is SEC-0461 FINDING 3, tracked separately.
#   acknowledge      low — flips an escalation JSON's status to ACKNOWLEDGED.
#   voyage_create    low-moderate — writes a voyage JSON and creates a git
#                     branch. Additive, not destructive.
#   voyage_list      none — read-only.
#   voyage_status    none — read-only.
#   bug_create       low — creates a new BUG order JSON. Same F3 gap as `order`.
#   qm_response      low — writes a local response file the QM hook reads;
#                     no process or fleet-state impact.
ALLOWED_COMMANDS = frozenset([
    "approve", "reject", "revise", "dispatch", "status", "cleanup",
    "crew", "usage", "verify", "order", "acknowledge",
    "voyage_create", "voyage_list", "voyage_status", "bug_create", "qm_response",
])

# BUG-MSO-2026-0463: a bare `cleanup` command over the bridge does NOT execute.
# It returns a warning naming the blast radius and requires the SAME command to
# be resent with `args.confirm: true` to actually run — an explicit two-message
# confirmation round-trip, not a single message, matching the Hub's broom
# button (preview, then a separate confirmed call).
CLEANUP_CONFIRM_MESSAGE = (
    "cleanup kills rogue fleet processes and resets crew state. In-flight "
    "crew work not yet committed can be lost (salvage branches mitigate but "
    "do not eliminate this). Resend this command with args.confirm=true to "
    "proceed."
)

COMMAND_EXPIRY_HOURS = 24

REQUIRED_COMMAND_FIELDS = {"id", "project", "command", "timestamp", "processed"}

PID_SUBDIR = "bridge"
PID_FILENAME = "poller.pid"
LOG_FILENAME = "bridge.log"

DEFAULT_POLL_INTERVAL = 30  # seconds


# =============================================================================
# LOGGING
# =============================================================================

def _setup_logger(admiralty_dir: Path) -> logging.Logger:
    """Configure bridge logger with file output."""
    log_dir = admiralty_dir / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)

    logger = logging.getLogger("bridge_poller")
    logger.setLevel(logging.DEBUG)

    if not logger.handlers:
        handler = logging.FileHandler(log_dir / LOG_FILENAME, encoding="utf-8")
        handler.setFormatter(logging.Formatter(
            "%(asctime)s [%(levelname)s] %(message)s", datefmt="%Y-%m-%d %H:%M:%S"
        ))
        logger.addHandler(handler)

    return logger


# =============================================================================
# PROCESS HELPERS
# =============================================================================

def is_process_alive(pid: int) -> bool:
    """Check if a process with the given PID is still running.

    Uses ctypes OpenProcess on Windows for reliability (works from cmd.exe AND Git Bash).
    """
    if not pid or pid <= 0:
        return False
    try:
        if os.name == "nt":
            import ctypes
            PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            STILL_ACTIVE = 259
            kernel32 = ctypes.windll.kernel32
            handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
            if handle == 0:
                return False
            try:
                exit_code = ctypes.c_ulong()
                if kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code)):
                    return exit_code.value == STILL_ACTIVE
                return False
            finally:
                kernel32.CloseHandle(handle)
        else:
            os.kill(pid, 0)
            return True
    except (ProcessLookupError, PermissionError, OSError):
        return False


# =============================================================================
# BRIDGE POLLER
# =============================================================================

class BridgePoller:
    """Polls a GitHub Gist for inbound commands and executes them locally."""

    def __init__(self, admiralty_dir: Path) -> None:
        self.admiralty_dir = admiralty_dir.resolve()
        self.logger = _setup_logger(self.admiralty_dir)

        # Load settings
        settings_path = self.admiralty_dir / "config" / "bridge-settings.json"
        if not settings_path.exists():
            raise FileNotFoundError(
                f"Bridge settings not found: {settings_path}\n"
                "Create .mso/config/bridge-settings.json with gist_id and token fields."
            )

        with open(settings_path, "r", encoding="utf-8") as f:
            raw_settings = json.load(f)

        self.settings = self._resolve_env_vars(raw_settings)
        try:
            from maestro.secrets.refs import resolve_secret_refs, install_log_scrub
            install_log_scrub()
            self.settings = resolve_secret_refs(self.settings, self.admiralty_dir.parent)
        except Exception:
            pass
        bridge = self.settings.get("bridge", {})
        queue_cfg = bridge.get("queue", {})
        self.gist_id: str = queue_cfg.get("gistId", "")
        self.token: str = queue_cfg.get("githubToken", "")
        self.poll_interval: int = int(queue_cfg.get("pollIntervalSeconds", DEFAULT_POLL_INTERVAL))

        if not self.gist_id:
            raise ValueError("bridge-settings.json: bridge.queue.gistId is required (or set MAESTRO_BRIDGE_GIST_ID).")
        if not self.token:
            raise ValueError("bridge-settings.json: bridge.queue.githubToken is required (or set MAESTRO_GITHUB_TOKEN).")

        self.logger.info("BridgePoller initialized (gist_id=...%s, interval=%ds)",
                         self.gist_id[-6:], self.poll_interval)

        # Install egress filter (no-op in permissive/non-enterprise mode)
        if _EGRESS_AVAILABLE:
            try:
                install_egress_filter(self.admiralty_dir.parent)
            except Exception:
                pass

    # -------------------------------------------------------------------------
    # Settings helpers
    # -------------------------------------------------------------------------

    @staticmethod
    def _resolve_env_vars(obj: Any) -> Any:
        """Recursively resolve ${VAR_NAME} references in settings values."""
        if isinstance(obj, str):
            def _replace(match: re.Match) -> str:
                var_name = match.group(1)
                return os.environ.get(var_name, match.group(0))
            return re.sub(r"\$\{(\w+)}", _replace, obj)
        if isinstance(obj, dict):
            return {k: BridgePoller._resolve_env_vars(v) for k, v in obj.items()}
        if isinstance(obj, list):
            return [BridgePoller._resolve_env_vars(v) for v in obj]
        return obj

    # -------------------------------------------------------------------------
    # Gist interaction
    # -------------------------------------------------------------------------

    def _gist_url(self) -> str:
        return f"https://api.github.com/gists/{self.gist_id}"

    def _make_request(self, method: str = "GET", data: Optional[bytes] = None,
                      extra_headers: Optional[Dict[str, str]] = None) -> tuple:
        """Make an authenticated GitHub API request to the gist endpoint.

        Returns (body_dict, etag_str).
        """
        req = urllib.request.Request(self._gist_url(), data=data, method=method)
        req.add_header("Authorization", f"token {self.token}")
        req.add_header("Accept", "application/vnd.github.v3+json")
        if data:
            req.add_header("Content-Type", "application/json")
        if extra_headers:
            for k, v in extra_headers.items():
                req.add_header(k, v)

        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                etag = resp.headers.get("ETag", "")
                return json.loads(resp.read().decode("utf-8")), etag
        except EgressDenied:
            raise urllib.error.URLError("Egress denied for GitHub API by allowlist")

    def _fetch_commands(self, project: Optional[str] = None) -> tuple:
        """Fetch unprocessed commands from the gist, grouped by project file.

        Returns: (dict mapping filename -> list of command dicts, etag).
        """
        gist, etag = self._make_request("GET")
        files = gist.get("files", {})
        result: Dict[str, List[dict]] = {}

        for filename, file_info in files.items():
            if not filename.startswith("commands-") or not filename.endswith(".json"):
                continue
            file_project = filename.replace("commands-", "").replace(".json", "")
            if project and file_project != project:
                continue

            content = file_info.get("content", "[]")
            try:
                commands = json.loads(content)
                if isinstance(commands, list):
                    result[filename] = commands
            except json.JSONDecodeError:
                self.logger.warning("Invalid JSON in gist file %s — skipping", filename)

        return result, etag

    def _update_gist_file(self, filename: str, commands: List[dict],
                          etag: str = "") -> None:
        """PATCH the gist to update a single commands file.

        Uses If-Match ETag header for optimistic concurrency.
        """
        payload = json.dumps({
            "files": {
                filename: {
                    "content": json.dumps(commands, indent=2)
                }
            }
        }).encode("utf-8")
        extra = {"If-Match": etag} if etag else None
        self._make_request("PATCH", data=payload, extra_headers=extra)

    # -------------------------------------------------------------------------
    # Command validation
    # -------------------------------------------------------------------------

    @staticmethod
    def _validate_command(cmd: dict) -> Optional[str]:
        """Validate a command dict. Returns error string or None if valid."""
        if not isinstance(cmd, dict):
            return "Command is not a dict"

        missing = REQUIRED_COMMAND_FIELDS - set(cmd.keys())
        if missing:
            return f"Missing fields: {', '.join(sorted(missing))}"

        if cmd.get("command") not in ALLOWED_COMMANDS:
            return f"Command '{cmd.get('command')}' not in whitelist"

        # Validate timestamp is parseable
        try:
            datetime.fromisoformat(cmd["timestamp"].replace("Z", "+00:00"))
        except (ValueError, TypeError, AttributeError):
            return f"Invalid timestamp: {cmd.get('timestamp')}"

        return None

    @staticmethod
    def _is_expired(cmd: dict) -> bool:
        """Check if a command is older than COMMAND_EXPIRY_HOURS."""
        try:
            ts = datetime.fromisoformat(cmd["timestamp"].replace("Z", "+00:00"))
            if ts.tzinfo is None:
                ts = ts.replace(tzinfo=timezone.utc)
            cutoff = datetime.now(timezone.utc) - timedelta(hours=COMMAND_EXPIRY_HOURS)
            return ts < cutoff
        except (ValueError, KeyError, TypeError):
            return True

    # -------------------------------------------------------------------------
    # Command execution
    # -------------------------------------------------------------------------

    def _execute_command(self, cmd: dict) -> dict:
        """Execute a single validated command. Returns result dict."""
        command = cmd["command"]
        project = cmd.get("project", "ADM")
        args = cmd.get("args", {})

        self.logger.info("Executing: %s (project=%s, id=%s)", command, project, cmd.get("id"))

        try:
            if command in ("approve", "reject", "revise"):
                return self._handle_approval(command, project, args)
            elif command == "acknowledge":
                return self._handle_acknowledge(project, args)
            elif command == "order":
                return self._handle_order(project, args)
            elif command == "voyage_create":
                return self._handle_voyage_create(project, args)
            elif command == "voyage_list":
                return self._handle_voyage_list(project, args)
            elif command == "voyage_status":
                return self._handle_voyage_status(project, args)
            elif command == "bug_create":
                return self._handle_bug_create(project, args)
            elif command == "qm_response":
                return self._handle_qm_response(project, args)
            elif command == "cleanup":
                return self._handle_cleanup(project, args)
            else:
                return self._handle_cli_command(command, project, args)
        except Exception as exc:
            self.logger.error("Command %s failed: %s", cmd.get("id"), exc)
            return {"status": "error", "message": str(exc)}

    def _handle_approval(self, action: str, project: str, args: dict) -> dict:
        """Handle approve/reject by delegating to `mso review approve|reject`.

        BUG-MSO-2026-0469: this used to write a status field directly into
        whatever voyage/plan JSON file *loosely matched the target string*
        (`if target in candidate.name`) — ungated (no capability check, so a
        governed workspace's identity ACL was bypassed entirely), and
        non-deterministic on an ambiguous target (first filesystem match
        wins, not the sender's intended artefact). Worse, the status values
        it wrote ("APPROVED"/"REJECTED") are not read or written anywhere
        else in the codebase and sit outside
        `fleet_runner._SWEEPABLE_VOYAGE_STATUSES` — flipping a voyage's
        status this way silently removed it from `mso voyage reconcile`
        sweep eligibility forever, the exact stranding class fixed in
        BUG-MSO-2026-0436, now reachable from a single Slack message.

        Nothing depends on that direct-write fallback (grep confirms no
        other code reads a voyage/plan "status" of APPROVED/REJECTED), and
        the review queue already has an actively-used, capability-gated path
        for precisely this decision (`mso review approve|reject`, gated on
        `voyage.approve` — BUG-MSO-2026-0462). So the fallback is deleted
        rather than duplicated-and-gated (BUG-MSO-2026-0426: one
        implementation for a given decision, not two that can drift).

        Delegating via subprocess (not calling require_capability()
        in-process) means a denial's SystemExit terminates the CHILD CLI
        process, not this long-running poller daemon — same isolation
        `_handle_cleanup` relies on for `fleet.cleanup`. The CLI's own
        order-id lookup (`queues/review/{order_id}.json`) is an exact match,
        not a substring scan, so an ambiguous or unrecognised target is
        refused ("not found") rather than silently resolved to a guess.
        """
        target = args.get("target") or args.get("item_id", "")  # accept both field names
        if not target:
            return {"status": "error", "message": "No target specified for approval"}

        cli_argv = ["review", action, target]
        if action in ("reject", "revise"):
            # BOTH require --notes at the CLI (maestro/review.py exits 1 without
            # them), so refuse here rather than shelling out to a guaranteed
            # failure the sender would see only as an opaque CLI error. `revise`
            # was previously omitted from this check — PR #315 spotted the same
            # gap but filled it with a placeholder ("Revision requested via Slack
            # bridge"). A placeholder is worse than a refusal: it satisfies the
            # CLI and hands the receiving crew a revision request with no reason
            # in it, which is exactly the failure the --notes requirement exists
            # to prevent. Make the sender say why.
            notes = args.get("notes") or args.get("reason")
            if not notes:
                verb = "Rejection" if action == "reject" else "Revision"
                return {"status": "error",
                        "message": f"{verb} requires args.notes (the reason, which is "
                                   f"passed to the crew that receives it)"}
            cli_argv.extend(["--notes", notes])

        return self._run_cli_argv(cli_argv, project)

    def _handle_acknowledge(self, project: str, args: dict) -> dict:
        """Handle escalation acknowledgment by updating the escalation JSON status."""
        esc_id = args.get("escalation_id", "")
        if not esc_id:
            return {"status": "error", "message": "No escalation_id specified"}

        esc_dir = self.admiralty_dir / "queues" / "escalations"
        if not esc_dir.exists():
            return {"status": "error", "message": "No escalations directory found"}

        for candidate in esc_dir.glob("*.json"):
            try:
                data = json.loads(candidate.read_text(encoding="utf-8"))
                if data.get("id") == esc_id:
                    data["status"] = "ACKNOWLEDGED"
                    data["acknowledgedBy"] = "bridge-poller"
                    data["acknowledgedAt"] = datetime.now(timezone.utc).isoformat()
                    candidate.write_text(json.dumps(data, indent=2), encoding="utf-8")
                    self.logger.info("ACKNOWLEDGED escalation %s", esc_id)
                    return {"status": "ok", "message": f"Escalation {esc_id} acknowledged"}
            except Exception:
                continue

        return {"status": "error", "message": f"Escalation not found: {esc_id}"}

    def _handle_order(self, project: str, args: dict) -> dict:
        """Handle order creation by writing a new order JSON to the orders queue."""
        from maestro.core.order_ids import (
            OrderValidationError, allocate_order_id, lock_for_allocation,
            validate_description, validate_priority,
        )

        try:
            description = validate_description(args.get("description", ""))
            priority = validate_priority(args.get("priority"))
        except OrderValidationError as exc:
            return {"status": "error", "message": str(exc)}

        now = datetime.now(timezone.utc)
        year = now.strftime("%Y")
        orders_dir = self.admiralty_dir / "queues" / "orders"
        orders_dir.mkdir(parents=True, exist_ok=True)

        with lock_for_allocation(self.admiralty_dir):
            order_id = allocate_order_id(self.admiralty_dir, "FTR", project, year)

            order = {
                "orderId": order_id,
                "type": "FTR",
                "project": project,
                "title": description,
                "priority": priority,
                "status": "PENDING",
                "createdBy": "bridge-poller",
                "createdAt": now.isoformat(),
                "targetRole": "NAV",
                "roleSequence": ["NAV", "SHP", "BOS", "SCR", "LKT"],
                "acceptanceCriteria": [],
                "acResults": [],
            }

            order_path = orders_dir / f"{order_id}.json"
            order_path.write_text(json.dumps(order, indent=2), encoding="utf-8")

        self.logger.info("Created order %s: %s", order_id, description[:60])
        return {"status": "ok", "message": f"Order created: {order_id}", "orderId": order_id}

    def _handle_voyage_create(self, project: str, args: dict) -> dict:
        """Create a new voyage: write JSON, create git branch."""
        title = args.get("title", "")
        if not title:
            return {"status": "error", "message": "No title provided for voyage_create"}

        now = datetime.now(timezone.utc)
        year = now.strftime("%Y")
        voyages_dir = self.admiralty_dir / "voyages" / "active"
        voyages_dir.mkdir(parents=True, exist_ok=True)

        existing = list(voyages_dir.glob(f"VOY-{project}-{year}-*.json"))
        seq = len(existing) + 1
        voyage_id = f"VOY-{project}-{year}-{seq:04d}"

        voyage = {
            "voyageId": voyage_id,
            "project": project,
            "title": title,
            "status": "PLANNED",
            "orders": [],
            "createdBy": "bridge-poller",
            "createdAt": now.isoformat(),
        }

        voyage_path = voyages_dir / f"{voyage_id}.json"
        voyage_path.write_text(json.dumps(voyage, indent=2), encoding="utf-8")
        self.logger.info("Created voyage %s: %s", voyage_id, title[:60])

        # Create git branch
        branch = f"voyage/{voyage_id}"
        repo_root = str(self.admiralty_dir.parent)
        try:
            run_hidden(
                ["git", "checkout", "-b", branch],
                capture_output=True, text=True, cwd=repo_root, timeout=30,
            )
        except Exception as exc:
            self.logger.warning("Failed to create branch %s: %s", branch, exc)

        return {"status": "ok", "message": f"Voyage created: {voyage_id}", "voyageId": voyage_id}

    def _handle_voyage_list(self, project: str, args: dict) -> dict:
        """List voyages for a project."""
        voyages_dir = self.admiralty_dir / "voyages" / "active"
        if not voyages_dir.exists():
            return {"status": "ok", "voyages": [], "message": "No voyages found"}

        voyages = []
        for candidate in sorted(voyages_dir.glob("*.json")):
            try:
                data = json.loads(candidate.read_text(encoding="utf-8"))
                if data.get("project") != project:
                    continue
                voyages.append({
                    "id": data.get("voyageId", candidate.stem),
                    "title": data.get("title", ""),
                    "status": data.get("status", ""),
                    "orderCount": len(data.get("orders", [])),
                })
            except Exception:
                continue

        lines = [f"{v['id']} | {v['status']} | orders={v['orderCount']} | {v['title']}" for v in voyages]
        return {"status": "ok", "voyages": voyages, "message": "\n".join(lines) if lines else "No voyages found"}

    def _handle_voyage_status(self, project: str, args: dict) -> dict:
        """Return status summary for a specific voyage."""
        voyage_id = args.get("voyage_id", "") or args.get("id", "")
        if not voyage_id:
            return {"status": "error", "message": "No voyage_id specified"}

        voyages_dir = self.admiralty_dir / "voyages" / "active"
        if voyages_dir.exists():
            for candidate in voyages_dir.glob("*.json"):
                if voyage_id in candidate.name:
                    try:
                        data = json.loads(candidate.read_text(encoding="utf-8"))
                        summary = (
                            f"Voyage: {data.get('voyageId')}\n"
                            f"Title: {data.get('title')}\n"
                            f"Status: {data.get('status')}\n"
                            f"Orders: {len(data.get('orders', []))}\n"
                            f"Created: {data.get('createdAt', '')}"
                        )
                        return {"status": "ok", "message": summary, "voyage": data}
                    except Exception as exc:
                        return {"status": "error", "message": f"Failed to read voyage: {exc}"}

        return {"status": "error", "message": f"Voyage not found: {voyage_id}"}

    def _handle_bug_create(self, project: str, args: dict) -> dict:
        """Create a BUG order and write it to the orders queue."""
        from maestro.core.order_ids import (
            OrderValidationError, allocate_order_id, lock_for_allocation,
            validate_description, validate_priority,
        )

        try:
            description = validate_description(args.get("description", ""))
            priority = validate_priority(args.get("priority"), default="HIGH")
        except OrderValidationError as exc:
            return {"status": "error", "message": str(exc)}

        now = datetime.now(timezone.utc)
        year = now.strftime("%Y")
        orders_dir = self.admiralty_dir / "queues" / "orders"
        orders_dir.mkdir(parents=True, exist_ok=True)

        with lock_for_allocation(self.admiralty_dir):
            bug_id = allocate_order_id(self.admiralty_dir, "BUG", project, year)

            order = {
                "orderId": bug_id,
                "type": "BUG",
                "project": project,
                "title": description,
                "priority": priority,
                "status": "PENDING",
                "createdBy": "bridge-poller",
                "createdAt": now.isoformat(),
                "targetRole": "SHP",
                "roleSequence": ["SHP", "BOS"],
                "acceptanceCriteria": [],
                "acResults": [],
            }

            order_path = orders_dir / f"{bug_id}.json"
            order_path.write_text(json.dumps(order, indent=2), encoding="utf-8")

        self.logger.info("Created bug order %s: %s", bug_id, description[:60])
        return {"status": "ok", "message": f"Bug order created: {bug_id}", "orderId": bug_id}

    def _handle_qm_response(self, project: str, args: dict) -> dict:
        """Write the Captain's reply to qm-response.json for the blocking QM hook.

        The AskUserQuestion hook (`maestro.hooks.bridge_question`) blocks on this
        file. `/adm reply` hardcodes project=ADM, so — to keep correlation robust
        for non-ADM questions — we stamp the response with the project (and id) of
        the outstanding question recorded in qm-question.json when one exists.
        """
        response_text = args.get("response", "") or args.get("text", "")
        if not response_text:
            return {"status": "error", "message": "No response text provided"}

        bridge_dir = self.admiralty_dir / "bridge"
        bridge_dir.mkdir(parents=True, exist_ok=True)

        # Prefer the outstanding question's project/id over the command default.
        resolved_project = project
        question_id = ""
        try:
            q_path = bridge_dir / "qm-question.json"
            if q_path.exists():
                q_data = json.loads(q_path.read_text(encoding="utf-8"))
                resolved_project = q_data.get("project") or project
                question_id = q_data.get("id", "")
        except (json.JSONDecodeError, OSError):
            pass

        payload = {
            "project": resolved_project,
            "questionId": question_id,
            "response": response_text,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "source": "bridge-poller",
        }

        response_path = bridge_dir / "qm-response.json"
        response_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        self.logger.info("QM response written for project %s", resolved_project)
        return {"status": "ok", "message": "Captain's response delivered to QM"}

    def _handle_cleanup(self, project: str, args: dict) -> dict:
        """Handle `cleanup` with a mandatory explicit-confirmation round-trip.

        BUG-MSO-2026-0463: `mso cleanup` kills rogue fleet processes and resets
        crew state — the most destructive command reachable via the bridge. A
        bare `cleanup` command is treated as a preview request: it executes
        nothing and returns the blast-radius warning. Only a command carrying
        `args.confirm: true` (necessarily a second, deliberate message) is
        actually run. The `confirm` key itself is stripped before falling
        through to the CLI shell-out, since `mso cleanup` has no such flag.

        The check is `is True` — a JSON boolean and nothing else. A truthiness
        test would accept any non-empty value, so the string ``"false"``, ``"no"``
        or ``"0"`` would all CONFIRM the most destructive command on the bridge.
        That is not a hypothetical typo: these payloads arrive as JSON authored by
        a Slack bot, where a client that stringifies its booleans turns an intended
        refusal into an execution. For a command that kills processes and resets
        crew state, the confirmation must be unambiguous rather than convenient.
        """
        if args.get("confirm") is not True:
            return {"status": "confirm_required", "message": CLEANUP_CONFIRM_MESSAGE}

        confirmed_args = {k: v for k, v in args.items() if k != "confirm"}
        return self._handle_cli_command("cleanup", project, confirmed_args)

    def _handle_cli_command(self, command: str, project: str, args: dict) -> dict:
        """Execute a Maestro CLI command via subprocess, mapping `args` to `--flags`."""
        cli_argv = [command]

        # Map common args
        for key, value in args.items():
            if isinstance(value, bool):
                if value:
                    cli_argv.append(f"--{key}")
            else:
                cli_argv.extend([f"--{key}", str(value)])

        return self._run_cli_argv(cli_argv, project)

    def _run_cli_argv(self, cli_argv: List[str], project: str, timeout: int = 120) -> dict:
        """Run `python -m maestro.cli <cli_argv>` and normalise the result.

        Shared by every bridge command that shells out to the CLI (cleanup,
        dispatch, review approve/reject, ...) — spawning a child process for
        each means any CLI-side `require_capability` gate is inherited for
        free, and a denial's `SystemExit` only ever terminates the child,
        never this long-running poller daemon.
        """
        cli_args = [sys.executable, "-m", "maestro.cli", *cli_argv]

        # Inject project context
        env = os.environ.copy()
        env["MAESTRO_PROJECT"] = project

        label = " ".join(cli_argv)
        try:
            result = run_hidden(
                cli_args,
                capture_output=True,
                text=True,
                timeout=timeout,
                cwd=str(self.admiralty_dir.parent),
                env=env,
            )
            output = result.stdout.strip() or result.stderr.strip()
            # Truncate long output for gist storage
            if len(output) > 2000:
                output = output[:1997] + "..."

            status = "ok" if result.returncode == 0 else "error"
            self.logger.info("CLI %s exited %d (%d chars output)", label, result.returncode, len(output))
            return {"status": status, "returncode": result.returncode, "output": output}
        except subprocess.TimeoutExpired:
            self.logger.warning("CLI %s timed out after %ds", label, timeout)
            return {"status": "error", "message": f"Command timed out ({timeout}s)"}
        except Exception as exc:
            return {"status": "error", "message": str(exc)}

    # -------------------------------------------------------------------------
    # Poll cycle
    # -------------------------------------------------------------------------

    def poll_once(self) -> int:
        """Fetch gist, process unprocessed commands, write results back.

        Returns the number of commands processed.
        """
        processed_count = 0

        try:
            all_commands, etag = self._fetch_commands()
        except urllib.error.HTTPError as exc:
            self.logger.error("Gist fetch failed: HTTP %d", exc.code)
            return 0
        except Exception as exc:
            self.logger.error("Gist fetch failed: %s", exc)
            return 0

        for filename, commands in all_commands.items():
            dirty = False

            for cmd in commands:
                if cmd.get("processed", False):
                    continue

                # Validate
                error = self._validate_command(cmd)
                if error:
                    self.logger.warning("Invalid command %s: %s", cmd.get("id", "?"), error)
                    cmd["processed"] = True
                    cmd["result"] = {"status": "error", "message": f"Validation failed: {error}"}
                    dirty = True
                    processed_count += 1
                    continue

                # Check expiry
                if self._is_expired(cmd):
                    self.logger.info("Expired command %s (ts=%s)", cmd.get("id"), cmd.get("timestamp"))
                    cmd["processed"] = True
                    cmd["result"] = {"status": "expired", "message": "Command older than 24h"}
                    dirty = True
                    processed_count += 1
                    continue

                # Execute
                result = self._execute_command(cmd)
                cmd["processed"] = True
                cmd["result"] = result
                cmd["processedAt"] = datetime.now(timezone.utc).isoformat()
                dirty = True
                processed_count += 1

            if dirty:
                try:
                    self._update_gist_file(filename, commands, etag)
                    self.logger.info("Updated gist file %s", filename)
                except urllib.error.HTTPError as exc:
                    if exc.code == 412:
                        self.logger.warning("Gist conflict on %s — will retry next cycle", filename)
                    else:
                        self.logger.error("Failed to update gist file %s: HTTP %d", filename, exc.code)
                except Exception as exc:
                    self.logger.error("Failed to update gist file %s: %s", filename, exc)

        return processed_count

    # -------------------------------------------------------------------------
    # Daemon management
    # -------------------------------------------------------------------------

    def _pid_dir(self) -> Path:
        return self.admiralty_dir / PID_SUBDIR

    def _pid_file(self) -> Path:
        return self._pid_dir() / PID_FILENAME

    def _write_pid(self) -> None:
        """Write current PID to the PID file."""
        pid_dir = self._pid_dir()
        pid_dir.mkdir(parents=True, exist_ok=True)
        self._pid_file().write_text(str(os.getpid()), encoding="utf-8")

    def _remove_pid(self) -> None:
        """Remove the PID file."""
        try:
            self._pid_file().unlink(missing_ok=True)
        except OSError:
            pass

    def _check_existing_daemon(self) -> Optional[int]:
        """Check if a daemon is already running. Returns PID or None."""
        pid_file = self._pid_file()
        if not pid_file.exists():
            return None
        try:
            pid = int(pid_file.read_text(encoding="utf-8").strip())
            if is_process_alive(pid):
                return pid
            # Stale PID file
            self.logger.info("Removing stale PID file (pid=%d)", pid)
            pid_file.unlink(missing_ok=True)
            return None
        except (ValueError, OSError):
            return None

    def run_daemon(self) -> None:
        """Start the polling daemon loop."""
        existing = self._check_existing_daemon()
        if existing:
            print(f"Bridge poller already running (PID {existing}). Use --stop first.")
            return

        self._write_pid()
        self.logger.info("Bridge poller daemon started (PID %d, interval %ds)",
                         os.getpid(), self.poll_interval)
        print(f"Bridge poller started (PID {os.getpid()}, interval {self.poll_interval}s)")
        print("Polling gist for inbound commands... (Ctrl+C to stop)")

        try:
            while True:
                count = self.poll_once()
                if count > 0:
                    self.logger.info("Poll cycle: %d command(s) processed", count)

                # Check if PID file was removed (external stop signal)
                if not self._pid_file().exists():
                    self.logger.info("PID file removed — shutting down")
                    break

                time.sleep(self.poll_interval)
        except KeyboardInterrupt:
            self.logger.info("Keyboard interrupt — shutting down")
            print("\nBridge poller stopped.")
        finally:
            self._remove_pid()
            self.logger.info("Bridge poller daemon stopped")

    @classmethod
    def stop_daemon(cls, admiralty_dir: Path) -> bool:
        """Stop a running poller by removing its PID file.

        Returns True if a daemon was found and signaled, False otherwise.
        """
        pid_file = admiralty_dir / PID_SUBDIR / PID_FILENAME
        if not pid_file.exists():
            print("No bridge poller PID file found — not running.")
            return False

        try:
            pid = int(pid_file.read_text(encoding="utf-8").strip())
        except (ValueError, OSError):
            print("Invalid PID file — removing.")
            pid_file.unlink(missing_ok=True)
            return False

        if not is_process_alive(pid):
            print(f"Bridge poller (PID {pid}) is not running — removing stale PID file.")
            pid_file.unlink(missing_ok=True)
            return False

        # Remove PID file — daemon checks this each cycle and exits cleanly
        pid_file.unlink(missing_ok=True)
        print(f"Stop signal sent to bridge poller (PID {pid}). "
              f"It will exit after the current poll cycle.")
        return True


# =============================================================================
# MAIN
# =============================================================================

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Mobile Command Bridge — Inbound Poller",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  python bridge_poller.py              # Start daemon (polls every 30s)\n"
            "  python bridge_poller.py --once        # Single poll cycle\n"
            "  python bridge_poller.py --stop        # Stop running daemon\n"
        ),
    )
    parser.add_argument("--once", action="store_true", help="Run a single poll cycle and exit")
    parser.add_argument("--stop", action="store_true", help="Stop a running poller daemon")
    parser.add_argument("--maestro-dir", type=str, default=None,
                        help="Path to .mso directory (auto-detected if omitted)")

    args = parser.parse_args()

    # Resolve workspace artefact directory
    if args.maestro_dir:
        admiralty_dir = Path(args.maestro_dir).resolve()
    else:
        from maestro.workspace import resolve_artefact_dir
        admiralty_dir = resolve_artefact_dir(Path.cwd())

    if not (admiralty_dir / "config").is_dir():
        print(f"Error: {admiralty_dir} does not appear to be a valid .mso directory.")
        sys.exit(1)

    if args.stop:
        BridgePoller.stop_daemon(admiralty_dir)
        return

    poller = BridgePoller(admiralty_dir)

    if args.once:
        count = poller.poll_once()
        print(f"Poll complete: {count} command(s) processed.")
    else:
        poller.run_daemon()


if __name__ == "__main__":
    main()
