#!/usr/bin/env python3
# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
"""
Bridge Slack Bot v1.0 — Inbound command receiver for Maestro.

Receives commands from the Captain via Slack (slash commands and interactive
button callbacks) and writes them to a GitHub Gist command queue for the
laptop-side poller to execute. Commands are acknowledged immediately in Slack;
execution results are written back to the gist by the poller.

Features:
- Socket Mode connection using stdlib only (ssl + socket, RFC 6455 frames)
- Slash command parsing: /adm status|approve|reject|dispatch|cleanup|order|help
- Interactive button callback handling (approve/reject/acknowledge/details)
- User authorization via configurable allowlist
- Gist-based command queue with ETag optimistic concurrency
- Auto-reconnect with exponential backoff
- PID file daemon management
- Zero external dependencies

Usage:
    python bridge_slack_bot.py           # Start bot
    python bridge_slack_bot.py --stop    # Stop bot

    from bridge_slack_bot import SlackBridgeBot
    bot = SlackBridgeBot(admiralty_dir)
    bot.start()
"""

import argparse
import hashlib
import json
import os
import re
import signal
import socket
import ssl
import struct
import sys
import threading
import time
import urllib.error
import urllib.request
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


class SlackBridgeBot:
    """Receives Slack commands and writes them to the Gist command queue."""

    def __init__(self, admiralty_dir: Path):
        self.admiralty_dir = admiralty_dir
        self.bridge_dir = admiralty_dir / "bridge"
        self.pid_file = self.bridge_dir / "slack-bot.pid"
        self.log_file = admiralty_dir / "logs" / "bridge.log"
        self.settings = self._load_settings()

        self._ws_sock: Optional[ssl.SSLSocket] = None
        self._running = False
        self._reconnect_delay = 1.0
        self._max_reconnect_delay = 60.0
        self._shutdown_event = threading.Event()

    # -----------------------------------------------------------------
    # Configuration
    # -----------------------------------------------------------------

    def _load_settings(self) -> Dict:
        """Load bridge-settings.json, resolving env var placeholders."""
        config_path = self.admiralty_dir / "config" / "bridge-settings.json"
        if not config_path.exists():
            return {"bridge": {"enabled": False}}
        try:
            raw = config_path.read_text(encoding="utf-8")
            settings = json.loads(raw)
        except Exception:
            return {"bridge": {"enabled": False}}
        return settings

    def _resolve_env(self, value: str) -> str:
        """Resolve ${VAR} placeholders from environment variables."""
        if not isinstance(value, str):
            return value
        match = re.match(r'^\$\{(\w+)\}$', value)
        if match:
            return os.environ.get(match.group(1), "")
        return value

    @property
    def app_token(self) -> str:
        return self._resolve_env(
            self.settings.get("bridge", {}).get("slack", {}).get("appToken", "")
        )

    @property
    def bot_token(self) -> str:
        return self._resolve_env(
            self.settings.get("bridge", {}).get("slack", {}).get("botToken", "")
        )

    @property
    def gist_id(self) -> str:
        return self._resolve_env(
            self.settings.get("bridge", {}).get("queue", {}).get("gistId", "")
        )

    @property
    def github_token(self) -> str:
        return self._resolve_env(
            self.settings.get("bridge", {}).get("queue", {}).get("githubToken", "")
        )

    @property
    def default_channel(self) -> str:
        return self.settings.get("bridge", {}).get("slack", {}).get(
            "defaultChannel", "#fleet-command"
        )

    @property
    def authorized_users(self) -> list:
        """List of Slack user IDs authorized to use bridge commands."""
        return self.settings.get("bridge", {}).get("slack", {}).get("authorizedUsers", [])

    @property
    def allow_all_users(self) -> bool:
        """Explicit opt-in to the legacy allow-all behaviour.

        SEC-MSO-2026 (audit finding H3): the bridge previously authorised *all*
        workspace users whenever ``authorizedUsers`` was empty, so anyone who
        could post to the workspace could dispatch a ``--dangerously-skip-
        permissions`` crew on the operator host. The default is now DENY. An
        operator who genuinely wants an open bridge must set
        ``bridge.slack.allowAllUsers: true`` in bridge-settings.json — a
        conscious, auditable choice rather than a silent default.
        """
        return bool(
            self.settings.get("bridge", {}).get("slack", {}).get("allowAllUsers", False)
        )

    def _is_authorized(self, user_id: str) -> bool:
        """Check if a Slack user is authorized to use bridge commands.

        Fails CLOSED: with no ``authorizedUsers`` allowlist and no explicit
        ``allowAllUsers: true`` opt-in, every user is denied.
        """
        allowed = self.authorized_users
        if allowed:
            return user_id in allowed
        # No allowlist configured.
        return self.allow_all_users

    def get_channel_for_project(self, project: str) -> str:
        """Get the Slack channel for a project, falling back to default."""
        projects = self.settings.get("bridge", {}).get("projects", {})
        proj_config = projects.get(project, {})
        if not proj_config.get("enabled", True):
            return self.default_channel
        return proj_config.get("channel", self.default_channel)

    # -----------------------------------------------------------------
    # Logging
    # -----------------------------------------------------------------

    def _log(self, level: str, message: str):
        """Append a log entry to the bridge log file."""
        try:
            self.log_file.parent.mkdir(parents=True, exist_ok=True)
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            with open(self.log_file, "a", encoding="utf-8") as f:
                f.write(f"[{timestamp}] [SlackBot] [{level}] {message}\n")
        except Exception:
            pass  # Fail-open: never block fleet operations for logging

    # -----------------------------------------------------------------
    # PID file management
    # -----------------------------------------------------------------

    def _write_pid(self):
        """Write current PID to the pid file."""
        self.bridge_dir.mkdir(parents=True, exist_ok=True)
        self.pid_file.write_text(str(os.getpid()), encoding="utf-8")

    def _remove_pid(self):
        """Remove the pid file if it belongs to us."""
        try:
            if self.pid_file.exists():
                stored = self.pid_file.read_text(encoding="utf-8").strip()
                if stored == str(os.getpid()):
                    self.pid_file.unlink()
        except Exception:
            pass

    def _read_pid(self) -> Optional[int]:
        """Read the PID from the pid file, if it exists."""
        try:
            if self.pid_file.exists():
                return int(self.pid_file.read_text(encoding="utf-8").strip())
        except Exception:
            pass
        return None

    # -----------------------------------------------------------------
    # Socket Mode — WebSocket (RFC 6455, stdlib only)
    # -----------------------------------------------------------------

    def _get_wss_url(self) -> Optional[str]:
        """Call apps.connections.open to get a Socket Mode WSS URL."""
        token = self.app_token
        if not token:
            self._log("ERROR", "No app-level token configured (MAESTRO_SLACK_APP_TOKEN)")
            return None

        req = urllib.request.Request(
            "https://slack.com/api/apps.connections.open",
            data=b"",
            headers={
                "Content-Type": "application/x-www-form-urlencoded",
                "Authorization": f"Bearer {token}",
            },
            method="POST",
        )

        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                body = json.loads(resp.read().decode("utf-8"))
                if not body.get("ok"):
                    self._log("ERROR", f"apps.connections.open failed: {body.get('error', 'unknown')}")
                    return None
                return body.get("url")
        except Exception as e:
            self._log("ERROR", f"Failed to get WSS URL: {e}")
            return None

    def _ws_connect(self, wss_url: str) -> Optional[ssl.SSLSocket]:
        """Establish a WebSocket connection to the given WSS URL.

        Implements the minimal RFC 6455 opening handshake using stdlib.
        """
        # Parse the WSS URL
        # Format: wss://host/path...
        url_stripped = wss_url.replace("wss://", "").replace("ws://", "")
        slash_idx = url_stripped.find("/")
        if slash_idx == -1:
            host = url_stripped
            path = "/"
        else:
            host = url_stripped[:slash_idx]
            path = url_stripped[slash_idx:]

        # Determine port
        port = 443
        if ":" in host:
            host, port_str = host.rsplit(":", 1)
            port = int(port_str)

        # Generate a random WebSocket key
        ws_key_bytes = os.urandom(16)
        import base64
        ws_key = base64.b64encode(ws_key_bytes).decode("ascii")

        try:
            raw_sock = socket.create_connection((host, port), timeout=15)
            ctx = ssl.create_default_context()
            sock = ctx.wrap_socket(raw_sock, server_hostname=host)
        except Exception as e:
            self._log("ERROR", f"TCP/TLS connection failed: {e}")
            return None

        # Send HTTP upgrade request
        handshake = (
            f"GET {path} HTTP/1.1\r\n"
            f"Host: {host}\r\n"
            f"Upgrade: websocket\r\n"
            f"Connection: Upgrade\r\n"
            f"Sec-WebSocket-Key: {ws_key}\r\n"
            f"Sec-WebSocket-Version: 13\r\n"
            f"\r\n"
        )

        try:
            sock.sendall(handshake.encode("utf-8"))
        except Exception as e:
            self._log("ERROR", f"WebSocket handshake send failed: {e}")
            sock.close()
            return None

        # Read the HTTP response (look for 101 Switching Protocols)
        response_data = b""
        try:
            while b"\r\n\r\n" not in response_data:
                chunk = sock.recv(4096)
                if not chunk:
                    break
                response_data += chunk
        except Exception as e:
            self._log("ERROR", f"WebSocket handshake recv failed: {e}")
            sock.close()
            return None

        status_line = response_data.split(b"\r\n")[0].decode("utf-8", errors="replace")
        if "101" not in status_line:
            self._log("ERROR", f"WebSocket upgrade rejected: {status_line}")
            sock.close()
            return None

        self._log("INFO", "WebSocket connection established")
        return sock

    def _ws_read_frame(self, sock: ssl.SSLSocket) -> Optional[Tuple[int, bytes]]:
        """Read a single WebSocket frame. Returns (opcode, payload) or None.

        Handles text (0x1), ping (0x9), pong (0xA), and close (0x8) opcodes.
        Only supports unmasked frames from server (RFC 6455 compliance).
        """
        try:
            # Read first 2 bytes
            header = self._recv_exact(sock, 2)
            if header is None:
                return None

            byte0, byte1 = header[0], header[1]
            opcode = byte0 & 0x0F
            masked = (byte1 & 0x80) != 0
            payload_len = byte1 & 0x7F

            # Extended payload length
            if payload_len == 126:
                ext = self._recv_exact(sock, 2)
                if ext is None:
                    return None
                payload_len = struct.unpack("!H", ext)[0]
            elif payload_len == 127:
                ext = self._recv_exact(sock, 8)
                if ext is None:
                    return None
                payload_len = struct.unpack("!Q", ext)[0]

            # Masking key (server frames should not be masked, but handle it)
            mask_key = b""
            if masked:
                mask_key = self._recv_exact(sock, 4)
                if mask_key is None:
                    return None

            # Payload
            payload = self._recv_exact(sock, payload_len) if payload_len > 0 else b""
            if payload is None:
                return None

            # Unmask if needed
            if masked and mask_key:
                payload = bytes(b ^ mask_key[i % 4] for i, b in enumerate(payload))

            return (opcode, payload)

        except (socket.timeout, OSError):
            return None

    def _recv_exact(self, sock: ssl.SSLSocket, n: int) -> Optional[bytes]:
        """Read exactly n bytes from the socket."""
        if n == 0:
            return b""
        data = b""
        while len(data) < n:
            try:
                chunk = sock.recv(n - len(data))
                if not chunk:
                    return None
                data += chunk
            except (socket.timeout, OSError):
                return None
        return data

    def _ws_send_frame(self, sock: ssl.SSLSocket, opcode: int, payload: bytes):
        """Send a masked WebSocket frame (client frames must be masked)."""
        frame = bytearray()

        # FIN + opcode
        frame.append(0x80 | opcode)

        # Mask bit + payload length
        mask_bit = 0x80
        length = len(payload)
        if length < 126:
            frame.append(mask_bit | length)
        elif length < 65536:
            frame.append(mask_bit | 126)
            frame.extend(struct.pack("!H", length))
        else:
            frame.append(mask_bit | 127)
            frame.extend(struct.pack("!Q", length))

        # Masking key
        mask_key = os.urandom(4)
        frame.extend(mask_key)

        # Masked payload
        masked = bytes(b ^ mask_key[i % 4] for i, b in enumerate(payload))
        frame.extend(masked)

        try:
            sock.sendall(bytes(frame))
        except Exception as e:
            self._log("ERROR", f"WebSocket send failed: {e}")

    def _ws_send_text(self, sock: ssl.SSLSocket, text: str):
        """Send a text WebSocket frame."""
        self._ws_send_frame(sock, 0x1, text.encode("utf-8"))

    def _ws_send_pong(self, sock: ssl.SSLSocket, payload: bytes):
        """Send a pong frame in response to a ping."""
        self._ws_send_frame(sock, 0xA, payload)

    def _ws_close(self, sock: ssl.SSLSocket):
        """Send a close frame and close the socket."""
        try:
            self._ws_send_frame(sock, 0x8, b"")
        except Exception:
            pass
        try:
            sock.close()
        except Exception:
            pass

    # -----------------------------------------------------------------
    # Socket Mode event loop
    # -----------------------------------------------------------------

    def _handle_socket_event(self, envelope: Dict):
        """Process a Socket Mode envelope and dispatch to the right handler."""
        envelope_id = envelope.get("envelope_id", "")
        event_type = envelope.get("type", "")
        payload = envelope.get("payload", {})

        # Acknowledge immediately (Slack requires this within 3 seconds)
        if envelope_id and self._ws_sock:
            ack = {"envelope_id": envelope_id}

            # For slash commands, we can include an immediate response
            if event_type == "slash_commands":
                command_text = payload.get("text", "").strip()
                ack_text = self._get_immediate_ack(command_text)
                if ack_text:
                    ack["payload"] = {"text": ack_text}

            self._ws_send_text(self._ws_sock, json.dumps(ack))

        # Route to handler
        try:
            if event_type == "slash_commands":
                self._handle_slash_command(payload)
            elif event_type == "interactive":
                self._handle_interactive(payload)
            else:
                self._log("DEBUG", f"Unhandled envelope type: {event_type}")
        except Exception as e:
            self._log("ERROR", f"Error handling {event_type}: {e}")

    def _event_loop(self, sock: ssl.SSLSocket):
        """Main WebSocket event loop — reads frames, dispatches events."""
        sock.settimeout(30.0)  # Timeout to allow periodic shutdown checks

        while self._running and not self._shutdown_event.is_set():
            result = self._ws_read_frame(sock)
            if result is None:
                # Timeout or disconnect — check if we should reconnect
                if self._running:
                    self._log("WARN", "WebSocket read returned None, will reconnect")
                break

            opcode, payload = result

            if opcode == 0x1:  # Text frame
                try:
                    envelope = json.loads(payload.decode("utf-8"))
                    self._handle_socket_event(envelope)
                except json.JSONDecodeError:
                    self._log("WARN", f"Non-JSON text frame received ({len(payload)} bytes)")

            elif opcode == 0x9:  # Ping
                self._ws_send_pong(sock, payload)

            elif opcode == 0x8:  # Close
                self._log("INFO", "Server sent close frame")
                break

            # Reset reconnect delay on successful activity
            self._reconnect_delay = 1.0

    # -----------------------------------------------------------------
    # Slash command handling
    # -----------------------------------------------------------------

    HELP_TEXT = (
        "*Maestro — `/adm` Commands:*\n"
        "```\n"
        "Markers (use anywhere in args):\n"
        "  @PRJ       — Set project (default: ADM)\n"
        "  !PRIORITY  — Set priority: HIGH, MEDIUM, LOW (default: MEDIUM)\n"
        "\n"
        "/adm status [@PRJ]                    — Fleet status\n"
        "/adm approve <ITEM_ID>                — Approve a gate-paused order (advances it)\n"
        "/adm revise <ITEM_ID> <notes>         — Send an order back for revision (notes required)\n"
        "/adm reject <ITEM_ID> [reason]        — Reject an order (archived FAILED)\n"
        "/adm dispatch [@PRJ] [N]              — Dispatch up to N crews (default 5)\n"
        "/adm cleanup [@PRJ]                   — Run cleanup\n"
        "/adm order <desc> [@PRJ] [!pri]       — Create a new order\n"
        "/adm voyage <title> [@PRJ]            — Create a voyage\n"
        "/adm voyage list [@PRJ]               — List voyages\n"
        "/adm voyage status <VOY-ID>           — Show voyage status\n"
        "/adm bug <title> [@PRJ] [!pri]        — Create a bug order\n"
        "/adm reply <text>                     — Send a response to the Quartermaster\n"
        "/adm help                             — Show this message\n"
        "```\n"
        "_Examples: `/adm order add login page @OTM !HIGH` · `/adm dispatch @ADM 3` · `/adm bug crash on save @OTM`_"
    )

    def _get_immediate_ack(self, command_text: str) -> str:
        """Return an immediate acknowledgment string for the slash command."""
        parts = command_text.split()
        subcommand = parts[0].lower() if parts else "help"

        if subcommand == "help":
            return self.HELP_TEXT
        if subcommand == "voyage":
            return ":ship: Voyage command received — queuing..."
        if subcommand == "bug":
            return ":bug: Bug report received — queuing..."
        if subcommand == "reply":
            return ":speech_balloon: Reply received — queuing..."
        if subcommand == "revise":
            return ":pencil: Revision request received — queuing..."

        return f":anchor: Command received: `/adm {command_text}`\nQueuing for execution..."

    def _handle_slash_command(self, payload: Dict):
        """Parse /adm slash command and write to gist queue."""
        text = payload.get("text", "").strip()
        channel_id = payload.get("channel_id", "")
        user_id = payload.get("user_id", "")
        response_url = payload.get("response_url", "")

        # Authorization check
        if not self._is_authorized(user_id):
            self._send_response(
                response_url,
                ":no_entry: You are not authorized to use Maestro Bridge. "
                "Ask the Captain to add your Slack user ID to bridge-settings.json `authorizedUsers`."
            )
            self._log("WARN", f"Unauthorized user {user_id} attempted: /adm {text}")
            return

        parts = text.split()
        subcommand = parts[0].lower() if parts else "help"

        if subcommand == "help":
            # Already sent via ack payload
            return

        # Parse subcommand into a queue command
        command_data = self._parse_subcommand(subcommand, parts[1:])
        if command_data is None:
            self._send_response(
                response_url,
                f":warning: Unknown subcommand: `{subcommand}`\n{self.HELP_TEXT}"
            )
            return

        command_data["requested_by"] = user_id
        command_data["channel_id"] = channel_id
        command_data["response_url"] = response_url

        # Write to gist queue
        project = command_data.get("project", "ADM")
        success = self._write_command_to_gist(project, command_data)

        if success:
            self._send_response(
                response_url,
                f":white_check_mark: Command queued: `{subcommand}` "
                f"(project: {project}, id: `{command_data['id']}`)"
            )
        else:
            self._send_response(
                response_url,
                f":x: Failed to queue command. Check bridge logs."
            )

    def _extract_markers(self, args: List[str]) -> Tuple[str, str, List[str]]:
        """Extract @PRJ and !PRIORITY markers from args list.

        Returns (project, priority, remaining_args) where remaining_args has
        markers removed. Markers can appear anywhere in the args list.
        """
        project = "ADM"
        priority = "MEDIUM"
        remaining = []
        for token in args:
            if token.startswith("@") and len(token) > 1:
                project = token[1:].upper()
            elif token.startswith("!") and len(token) > 1:
                priority = token[1:].upper()
            else:
                remaining.append(token)
        return project, priority, remaining

    def _parse_subcommand(self, subcommand: str, args: List[str]) -> Optional[Dict]:
        """Parse a subcommand and its arguments into a command dict."""
        timestamp = datetime.utcnow().isoformat() + "Z"
        cmd_id = f"cmd-{int(time.time())}-{os.urandom(4).hex()}"

        base = {
            "id": cmd_id,
            "timestamp": timestamp,
            "processed": False,
            "result": None,
        }

        if subcommand == "status":
            project, _, remaining = self._extract_markers(args)
            if not args or args[0].startswith("@"):
                pass  # project already set via marker or default
            elif remaining:
                project = remaining[0].upper()
            return {**base, "command": "status", "project": project, "args": {}}

        elif subcommand == "approve":
            if not args:
                return None
            item_id = args[0]
            return {
                **base,
                "command": "approve",
                "project": self._project_from_id(item_id),
                "args": {"item_id": item_id},
            }

        elif subcommand == "reject":
            if not args:
                return None
            item_id = args[0]
            reason = " ".join(args[1:]) if len(args) > 1 else ""
            return {
                **base,
                "command": "reject",
                "project": self._project_from_id(item_id),
                "args": {"item_id": item_id, "reason": reason},
            }

        elif subcommand == "revise":
            # Revise sends a gated order back to the role that triggered its gate,
            # with the Captain's notes. Notes are mandatory (the CLI requires them),
            # so a bare `/adm revise <ID>` with no text is rejected here.
            if len(args) < 2:
                return None
            item_id = args[0]
            notes = " ".join(args[1:])
            return {
                **base,
                "command": "revise",
                "project": self._project_from_id(item_id),
                "args": {"item_id": item_id, "notes": notes},
            }

        elif subcommand == "dispatch":
            # Positional: /adm dispatch [@PRJ] [N]
            # Flag fallback: --max-crews N --project PRJ
            project = "ADM"
            max_crews = 5
            # Check for legacy flag syntax first
            if "--max-crews" in args or "--project" in args:
                i = 0
                while i < len(args):
                    if args[i] == "--max-crews" and i + 1 < len(args):
                        try:
                            max_crews = int(args[i + 1])
                        except ValueError:
                            pass
                        i += 2
                    elif args[i] == "--project" and i + 1 < len(args):
                        project = args[i + 1].upper()
                        i += 2
                    else:
                        i += 1
            else:
                project, _, remaining = self._extract_markers(args)
                for token in remaining:
                    try:
                        max_crews = int(token)
                    except ValueError:
                        pass
            return {
                **base,
                "command": "dispatch",
                "project": project,
                "args": {"max_crews": max_crews},
            }

        elif subcommand == "cleanup":
            project, _, remaining = self._extract_markers(args)
            if remaining:
                project = remaining[0].upper()
            return {**base, "command": "cleanup", "project": project, "args": {}}

        elif subcommand == "order":
            project, priority, remaining = self._extract_markers(args)
            description = " ".join(remaining)
            if not description:
                return None
            return {
                **base,
                "command": "order",
                "project": project,
                "args": {
                    "description": description,
                    "priority": priority,
                },
            }

        elif subcommand == "voyage":
            if not args:
                return None
            sub = args[0].lower()
            rest = args[1:]
            if sub == "list":
                project, _, _ = self._extract_markers(rest)
                return {**base, "command": "voyage_list", "project": project, "args": {}}
            elif sub == "status":
                if not rest:
                    return None
                voy_id = rest[0]
                return {
                    **base,
                    "command": "voyage_status",
                    "project": self._project_from_id(voy_id),
                    "args": {"voyage_id": voy_id},
                }
            else:
                # /adm voyage <title> [@PRJ]
                all_args = args  # sub is part of the title
                project, _, remaining = self._extract_markers(all_args)
                title = " ".join(remaining)
                if not title:
                    return None
                return {
                    **base,
                    "command": "voyage_create",
                    "project": project,
                    "args": {"title": title},
                }

        elif subcommand == "bug":
            project, priority, remaining = self._extract_markers(args)
            title = " ".join(remaining)
            if not title:
                return None
            return {
                **base,
                "command": "bug_create",
                "project": project,
                "args": {
                    "title": title,
                    "type": "BUG",
                    "priority": priority,
                },
            }

        elif subcommand == "reply":
            text = " ".join(args)
            if not text:
                return None
            return {**base, "command": "qm_response", "project": "ADM", "args": {"text": text}}

        return None

    def _project_from_id(self, item_id: str) -> str:
        """Extract project acronym from an order/item ID.

        IDs follow the pattern TYPE-PROJECT-YEAR-SEQ (e.g. FTR-ADM-2026-0001).
        """
        parts = item_id.split("-")
        if len(parts) >= 2:
            return parts[1].upper()
        return "ADM"

    # -----------------------------------------------------------------
    # Interactive button handling
    # -----------------------------------------------------------------

    def _handle_interactive(self, payload: Dict):
        """Handle interactive button callbacks from Block Kit messages."""
        actions = payload.get("actions", [])
        response_url = payload.get("response_url", "")
        user = payload.get("user", {})
        user_id = user.get("id", "unknown")

        # Authorization check
        if not self._is_authorized(user_id):
            self._update_interactive_message(
                response_url,
                ":no_entry: You are not authorized to use Maestro Bridge."
            )
            self._log("WARN", f"Unauthorized user {user_id} attempted interactive action")
            return

        for action in actions:
            action_id = action.get("action_id", "")
            value_raw = action.get("value", "{}")

            try:
                value = json.loads(value_raw)
            except json.JSONDecodeError:
                value = {"raw": value_raw}

            item_id = value.get("id", "unknown")
            project = value.get("project", "ADM")

            timestamp = datetime.utcnow().isoformat() + "Z"
            cmd_id = f"cmd-{int(time.time())}-{os.urandom(4).hex()}"

            command_data = None

            if action_id == "bridge_approve":
                command_data = {
                    "id": cmd_id,
                    "command": "approve",
                    "project": project,
                    "args": {"item_id": item_id},
                    "timestamp": timestamp,
                    "processed": False,
                    "result": None,
                    "requested_by": user_id,
                }

            elif action_id == "bridge_reject":
                command_data = {
                    "id": cmd_id,
                    "command": "reject",
                    "project": project,
                    "args": {"item_id": item_id, "reason": "Rejected via Slack"},
                    "timestamp": timestamp,
                    "processed": False,
                    "result": None,
                    "requested_by": user_id,
                }

            elif action_id == "bridge_details":
                # View Details — show the file path info, no command to queue
                file_path = value.get("path", "unknown")
                self._update_interactive_message(
                    response_url,
                    f":mag: *Details requested* by <@{user_id}>\n"
                    f"*Item:* `{item_id}` | *Project:* {project}\n"
                    f"*File:* `{file_path}`\n"
                    f"_Review this file on your laptop to see full details._"
                )
                continue  # No gist command needed

            elif action_id == "bridge_ack_escalation":
                command_data = {
                    "id": cmd_id,
                    "command": "acknowledge",
                    "project": project,
                    "args": {"escalation_id": item_id},
                    "timestamp": timestamp,
                    "processed": False,
                    "result": None,
                    "requested_by": user_id,
                }

            if command_data:
                success = self._write_command_to_gist(project, command_data)
                action_label = command_data["command"].capitalize()

                if success:
                    self._update_interactive_message(
                        response_url,
                        f":white_check_mark: *{action_label}* action taken by <@{user_id}> "
                        f"on `{item_id}` (queued as `{cmd_id}`)"
                    )
                else:
                    self._update_interactive_message(
                        response_url,
                        f":x: Failed to queue {action_label} for `{item_id}`. Check bridge logs."
                    )

    def _update_interactive_message(self, response_url: str, text: str):
        """Update the original interactive message to reflect the action taken."""
        if not response_url:
            return

        payload = {
            "replace_original": True,
            "text": text,
            "blocks": [
                {
                    "type": "section",
                    "text": {"type": "mrkdwn", "text": text},
                },
                {
                    "type": "context",
                    "elements": [
                        {
                            "type": "mrkdwn",
                            "text": f"Maestro Bridge | {datetime.now().strftime('%H:%M:%S')}",
                        }
                    ],
                },
            ],
        }

        self._post_json(response_url, payload)

    # -----------------------------------------------------------------
    # Slack response helpers
    # -----------------------------------------------------------------

    def _send_response(self, response_url: str, text: str):
        """Send a follow-up response to a slash command via response_url."""
        if not response_url:
            return

        payload = {
            "response_type": "ephemeral",
            "text": text,
        }

        self._post_json(response_url, payload)

    def _post_json(self, url: str, payload: Dict):
        """POST a JSON payload to a URL. Fail-open."""
        try:
            req = urllib.request.Request(
                url,
                data=json.dumps(payload).encode("utf-8"),
                headers={"Content-Type": "application/json; charset=utf-8"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=10):
                pass
        except Exception as e:
            self._log("ERROR", f"POST to {url[:60]}... failed: {e}")

    # -----------------------------------------------------------------
    # Gist command queue
    # -----------------------------------------------------------------

    def _write_command_to_gist(self, project: str, command: Dict) -> bool:
        """Write a command to the project-specific Gist command queue file.

        Creates or updates the gist with a commands-{PROJECT}.json file
        containing an array of command objects.
        """
        token = self.github_token
        gist_id = self.gist_id
        if not token:
            self._log("ERROR", "No GitHub token configured")
            return False

        filename = f"commands-{project}.json"

        # Retry loop for optimistic concurrency (re-read on conflict)
        max_retries = 3
        for attempt in range(max_retries):
            existing_commands = []
            etag = ""
            if gist_id:
                existing_commands, etag = self._read_gist_file(gist_id, filename, token)

            existing_commands.append(command)

            files_payload = {
                filename: {
                    "content": json.dumps(existing_commands, indent=2),
                }
            }

            try:
                if gist_id:
                    url = f"https://api.github.com/gists/{gist_id}"
                    method = "PATCH"
                else:
                    url = "https://api.github.com/gists"
                    method = "POST"

                body = {
                    "description": "Maestro — Bridge Command Queue",
                    "public": False,
                    "files": files_payload,
                }

                headers = {
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {token}",
                    "Accept": "application/vnd.github+json",
                    "X-GitHub-Api-Version": "2022-11-28",
                }
                if etag:
                    headers["If-Match"] = etag

                req = urllib.request.Request(
                    url,
                    data=json.dumps(body).encode("utf-8"),
                    headers=headers,
                    method=method,
                )

                with urllib.request.urlopen(req, timeout=15) as resp:
                    resp_body = json.loads(resp.read().decode("utf-8"))
                    if not gist_id:
                        new_id = resp_body.get("id", "")
                        self._log("INFO", f"Created new gist: {new_id}")
                        self._persist_gist_id(new_id)
                    return True

            except urllib.error.HTTPError as e:
                if e.code == 412 and attempt < max_retries - 1:
                    # ETag mismatch — concurrent write detected, retry with fresh read
                    self._log("WARN", f"Gist conflict on {filename}, retrying ({attempt + 1}/{max_retries})")
                    existing_commands.pop()  # remove our command before retry
                    time.sleep(0.5)
                    continue
                self._log("ERROR", f"Gist API error ({e.code}): {e.read().decode('utf-8', errors='replace')[:200]}")
                return False
            except Exception as e:
                self._log("ERROR", f"Gist write failed: {e}")
                return False

        return False

    def _persist_gist_id(self, new_id: str):
        """Write a newly created gist ID back to bridge-settings.json."""
        try:
            config_path = self.admiralty_dir / "config" / "bridge-settings.json"
            raw = config_path.read_text(encoding="utf-8")
            config = json.loads(raw)
            config.setdefault("bridge", {}).setdefault("queue", {})["gistId"] = new_id
            config_path.write_text(json.dumps(config, indent=2), encoding="utf-8")
            self._log("INFO", f"Persisted new gist ID to bridge-settings.json: {new_id}")
        except Exception as e:
            self._log("ERROR", f"Failed to persist gist ID: {e}. Set MAESTRO_BRIDGE_GIST_ID={new_id} manually.")

    def _read_gist_file(self, gist_id: str, filename: str,
                        token: str) -> Tuple[List[Dict], str]:
        """Read an existing file from a gist. Returns (commands, etag).

        The ETag is used for optimistic concurrency on write-back.
        """
        try:
            req = urllib.request.Request(
                f"https://api.github.com/gists/{gist_id}",
                headers={
                    "Authorization": f"Bearer {token}",
                    "Accept": "application/vnd.github+json",
                    "X-GitHub-Api-Version": "2022-11-28",
                },
            )
            with urllib.request.urlopen(req, timeout=15) as resp:
                etag = resp.headers.get("ETag", "")
                body = json.loads(resp.read().decode("utf-8"))
                files = body.get("files", {})
                file_info = files.get(filename)
                if file_info:
                    content = file_info.get("content", "[]")
                    return json.loads(content), etag
                return [], etag
        except Exception as e:
            self._log("WARN", f"Failed to read gist file {filename}: {e}")
        return [], ""

    # -----------------------------------------------------------------
    # Start / Stop
    # -----------------------------------------------------------------

    def start(self):
        """Start the Socket Mode WebSocket connection.

        Blocks the calling thread. Handles auto-reconnect with exponential
        backoff on disconnect.
        """
        if not self.app_token:
            print("[Bridge SlackBot] ERROR: No app-level token configured.")
            print("  Set MAESTRO_SLACK_APP_TOKEN environment variable.")
            return

        if not self.bot_token:
            print("[Bridge SlackBot] ERROR: No bot token configured.")
            print("  Set MAESTRO_SLACK_BOT_TOKEN environment variable.")
            return

        # Security posture banner (audit finding H3). Make an open bridge
        # impossible to run by accident: warn loudly when allow-all is active,
        # and remind operators to set an allowlist when neither is configured.
        if not self.authorized_users:
            if self.allow_all_users:
                print(
                    "[Bridge SlackBot] SECURITY WARNING: allowAllUsers=true — "
                    "EVERY workspace user can dispatch crews on this host. "
                    "Set bridge.slack.authorizedUsers to restrict access."
                )
                self._log("WARN", "Bridge running with allowAllUsers=true (open to all workspace users)")
            else:
                print(
                    "[Bridge SlackBot] Access control: no authorizedUsers configured — "
                    "all commands will be DENIED. Add Slack user IDs to "
                    "bridge.slack.authorizedUsers (or set allowAllUsers=true to opt "
                    "into an open bridge)."
                )
                self._log("INFO", "Bridge started with empty allowlist — commands deny-by-default")

        self._running = True
        self._shutdown_event.clear()
        self._write_pid()

        # Register signal handlers for graceful shutdown
        for sig in (signal.SIGINT, signal.SIGTERM):
            try:
                signal.signal(sig, lambda s, f: self.stop())
            except (OSError, ValueError):
                pass

        self._log("INFO", "Slack bot starting")
        print("[Bridge SlackBot] Starting Socket Mode connection...")

        try:
            while self._running and not self._shutdown_event.is_set():
                # Get a fresh WSS URL for each connection attempt
                wss_url = self._get_wss_url()
                if not wss_url:
                    self._log("WARN", f"No WSS URL, retrying in {self._reconnect_delay}s")
                    self._shutdown_event.wait(self._reconnect_delay)
                    self._reconnect_delay = min(
                        self._reconnect_delay * 2, self._max_reconnect_delay
                    )
                    continue

                # Connect
                sock = self._ws_connect(wss_url)
                if not sock:
                    self._log("WARN", f"WebSocket connect failed, retrying in {self._reconnect_delay}s")
                    self._shutdown_event.wait(self._reconnect_delay)
                    self._reconnect_delay = min(
                        self._reconnect_delay * 2, self._max_reconnect_delay
                    )
                    continue

                self._ws_sock = sock
                self._reconnect_delay = 1.0
                print("[Bridge SlackBot] Connected. Listening for commands...")
                self._log("INFO", "WebSocket connected, entering event loop")

                # Run event loop (blocks until disconnect)
                self._event_loop(sock)

                # Cleanup after disconnect
                self._ws_sock = None
                self._ws_close(sock)

                if self._running:
                    self._log("INFO", f"Disconnected, reconnecting in {self._reconnect_delay}s")
                    self._shutdown_event.wait(self._reconnect_delay)
                    self._reconnect_delay = min(
                        self._reconnect_delay * 2, self._max_reconnect_delay
                    )

        finally:
            self._remove_pid()
            self._log("INFO", "Slack bot stopped")
            print("[Bridge SlackBot] Stopped.")

    def stop(self):
        """Graceful shutdown — close WebSocket, remove PID file."""
        self._log("INFO", "Stop requested")
        self._running = False
        self._shutdown_event.set()

        if self._ws_sock:
            try:
                self._ws_close(self._ws_sock)
            except Exception:
                pass
            self._ws_sock = None

    def stop_remote(self) -> bool:
        """Stop a running bot instance by sending SIGTERM to its PID."""
        pid = self._read_pid()
        if pid is None:
            print("[Bridge SlackBot] No PID file found. Bot may not be running.")
            return False

        print(f"[Bridge SlackBot] Sending stop signal to PID {pid}...")

        if os.name == "nt":
            # Windows: use taskkill
            try:
                import subprocess  # noqa: F401 — kept for subprocess.* constants
                from maestro.core.proc import run_hidden  # FTR-MSO-2026-0408
                run_hidden(
                    ["taskkill", "/PID", str(pid), "/F"],
                    capture_output=True,
                )
                print(f"[Bridge SlackBot] Sent kill to PID {pid}")
                return True
            except Exception as e:
                print(f"[Bridge SlackBot] Failed to kill PID {pid}: {e}")
                return False
        else:
            try:
                os.kill(pid, signal.SIGTERM)
                print(f"[Bridge SlackBot] SIGTERM sent to PID {pid}")
                return True
            except ProcessLookupError:
                print(f"[Bridge SlackBot] PID {pid} not found (already stopped?)")
                try:
                    self.pid_file.unlink()
                except Exception:
                    pass
                return False
            except Exception as e:
                print(f"[Bridge SlackBot] Failed to stop PID {pid}: {e}")
                return False


# =====================================================================
# CLI entry point
# =====================================================================

def main():
    """CLI entry point for the Bridge Slack Bot."""
    parser = argparse.ArgumentParser(
        description="Maestro — Bridge Slack Bot"
    )
    parser.add_argument(
        "--stop",
        action="store_true",
        help="Stop a running bot instance",
    )
    parser.add_argument(
        "--maestro-dir",
        type=Path,
        default=None,
        help="Path to .mso directory (auto-detected if omitted)",
    )

    args = parser.parse_args()

    # Resolve maestro dir
    admiralty_dir = args.maestro_dir
    if admiralty_dir is None:
        # Look relative to this script's location
        script_dir = Path(__file__).resolve().parent
        if script_dir.name == "core":
            admiralty_dir = script_dir.parent
        else:
            admiralty_dir = script_dir

    if not admiralty_dir.exists():
        print(f"[Bridge SlackBot] ERROR: Maestro directory not found: {admiralty_dir}")
        sys.exit(1)

    bot = SlackBridgeBot(admiralty_dir)

    if args.stop:
        success = bot.stop_remote()
        sys.exit(0 if success else 1)
    else:
        bot.start()


if __name__ == "__main__":
    main()
