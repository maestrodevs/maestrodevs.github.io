"""Shared order-creation validation and ID allocation (BUG-MSO-2026-0464).

SEC-MSO-2026-0461 FINDING 3: the bridge's ``_handle_order`` created FTR orders
with no description-length or priority validation, and allocated its sequence
number via ``len(existing) + 1`` over a single directory listing — not atomic
(two concurrent creations collide) and not correct once earlier orders have
been archived out of that directory (the count no longer reflects the highest
sequence). CLAUDE.md requires IDs to continue from the highest existing
sequence across ALL types and ALL order directories, never a re-count.

This module is the single allocator/validator both the CLI (``mso bug``) and
the bridge poller call, so the two rule sets cannot drift apart again.
"""

from __future__ import annotations

import os
import re
import time
from pathlib import Path
from typing import Optional

MAX_DESCRIPTION_LENGTH = 500
VALID_PRIORITIES = ("CRITICAL", "HIGH", "MEDIUM", "LOW")
DEFAULT_PRIORITY = "MEDIUM"

# Every directory an order JSON can live in across its lifecycle — active
# queues plus archives — so a sequence scan can never under-count because an
# earlier order moved out of queues/orders into orders/complete|failed.
ORDER_SCAN_SUBDIRS = (
    "queues/orders", "queues/bugs", "queues/security", "queues/defects",
    "queues/breakdown", "queues/high-level", "queues/requests",
    "orders/active", "orders/complete", "orders/failed",
)

_LOCK_STALE_SECONDS = 30
_LOCK_RETRY_INTERVAL_SECONDS = 0.05
_LOCK_TIMEOUT_SECONDS = 15


class OrderValidationError(ValueError):
    """Raised when order-creation input (description/priority) fails validation."""


def validate_description(description: Optional[str]) -> str:
    """Validate and normalise a description/title. Raises OrderValidationError."""
    description = (description or "").strip()
    if not description:
        raise OrderValidationError("Description is required")
    if len(description) > MAX_DESCRIPTION_LENGTH:
        raise OrderValidationError(
            f"Description exceeds {MAX_DESCRIPTION_LENGTH} characters "
            f"({len(description)} given)"
        )
    return description


def validate_priority(priority: Optional[str], default: str = DEFAULT_PRIORITY) -> str:
    """Validate and normalise a priority string. Raises OrderValidationError."""
    priority = (priority or default).strip().upper()
    if priority not in VALID_PRIORITIES:
        raise OrderValidationError(
            f"Invalid priority '{priority}' — must be one of {', '.join(VALID_PRIORITIES)}"
        )
    return priority


def _lock_path(mso_dir: Path) -> Path:
    return mso_dir / "state" / "order-id.lock"


class _CrossProcessLock:
    """Exclusive-create lockfile guarding order-ID allocation.

    ``os.O_CREAT | os.O_EXCL`` is atomic on both POSIX and Windows, so this
    works as a portable cross-process mutex without extra dependencies. A
    lock older than ``_LOCK_STALE_SECONDS`` is assumed to be left behind by a
    crashed holder and broken. If the lock cannot be acquired within
    ``_LOCK_TIMEOUT_SECONDS`` (wedged holder), allocation proceeds unlocked
    rather than blocking order creation forever — still far safer than the
    always-unlocked ``len(existing) + 1`` this replaces.
    """

    def __init__(self, path: Path):
        self.path = path
        self._acquired = False

    def __enter__(self) -> "_CrossProcessLock":
        self.path.parent.mkdir(parents=True, exist_ok=True)
        deadline = time.monotonic() + _LOCK_TIMEOUT_SECONDS
        while True:
            try:
                fd = os.open(str(self.path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                try:
                    os.write(fd, str(os.getpid()).encode("utf-8"))
                finally:
                    os.close(fd)
                self._acquired = True
                return self
            except (FileExistsError, PermissionError):
                # FileExistsError — a live holder owns the lock. Expected.
                #
                # PermissionError — Windows only, and the reason this clause is
                # not just FileExistsError. When the holder's __exit__ unlinks the
                # lock, Windows puts the file into a DELETE-PENDING state until the
                # last handle closes; os.open() against a delete-pending path
                # raises WinError 5 (PermissionError), not FileExistsError. Since
                # both are OSError subclasses but only one was caught, that race
                # escaped the retry loop and propagated out of __enter__, failing
                # order creation under exactly the contention this lock exists to
                # survive. Both conditions mean "someone else has it right now", so
                # both retry; a genuine permissions fault simply retries until the
                # deadline and then proceeds unlocked, the same degradation path a
                # wedged holder already takes.
                try:
                    if time.time() - self.path.stat().st_mtime > _LOCK_STALE_SECONDS:
                        self.path.unlink(missing_ok=True)
                        continue
                except OSError:
                    # stat() can itself fail on a delete-pending path — that just
                    # means the holder is releasing, so fall through and retry.
                    pass
                if time.monotonic() >= deadline:
                    return self
                time.sleep(_LOCK_RETRY_INTERVAL_SECONDS)

    def __exit__(self, exc_type, exc, tb) -> bool:
        if self._acquired:
            try:
                self.path.unlink(missing_ok=True)
            except OSError:
                pass
        return False


def lock_for_allocation(mso_dir: Path) -> _CrossProcessLock:
    """Context manager serialising order-ID allocation across processes.

    The scan-then-write critical section MUST happen entirely inside the
    ``with`` block — computing the ID and writing the order file both inside
    the lock is what makes two concurrent creations race-safe::

        with lock_for_allocation(mso_dir):
            order_id = allocate_order_id(mso_dir, "BUG", project, year)
            (orders_dir / f"{order_id}.json").write_text(...)
    """
    return _CrossProcessLock(_lock_path(mso_dir))


def highest_existing_sequence(mso_dir: Path, order_type: str, project: str, year: str) -> int:
    """Highest existing sequence number for (order_type, project, year),
    scanning every active-queue and archive directory the order could be in."""
    pattern = re.compile(
        rf'^{re.escape(order_type)}-{re.escape(project)}-{re.escape(year)}-(\d+)\.json$'
    )
    highest = 0
    for sub in ORDER_SCAN_SUBDIRS:
        d = mso_dir / sub
        if not d.exists():
            continue
        for f in d.iterdir():
            m = pattern.match(f.name)
            if m:
                highest = max(highest, int(m.group(1)))
    return highest


def allocate_order_id(mso_dir: Path, order_type: str, project: str, year: str) -> str:
    """Allocate the next order ID for (order_type, project, year).

    Callers MUST invoke this inside a ``with lock_for_allocation(mso_dir):``
    block that also performs the resulting file write (see that function's
    docstring) — calling this alone is not race-safe.
    """
    seq = highest_existing_sequence(mso_dir, order_type, project, year) + 1
    return f"{order_type}-{project}-{year}-{seq:04d}"
