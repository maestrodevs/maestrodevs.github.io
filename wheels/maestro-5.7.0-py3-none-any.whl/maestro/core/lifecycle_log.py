"""
maestro/core/lifecycle_log.py — shared lifecycle.log message sanitization.

BUG-MSO-2026-0474

``lifecycle.log`` has a strict one-line-per-event contract — the CLAUDE.md
triage recipe (``grep -E '\\| (WARN|ERROR) ' .mso/logs/lifecycle.log``),
operator monitors, and any "last N events" tail are all line-based. Free
text that reaches a lifecycle write call (review revise/reject notes,
rejection reasons, and any future operator-supplied field) must never be
allowed to span more than one physical line, or it silently pushes real
events out of a tail window and can masquerade as extra events.

No module-level dependencies beyond the stdlib, so every lifecycle writer
(``maestro.core.fleet_runner``, ``maestro.review``, ``maestro.hub.review``,
``maestro.demo``) can import this without circular-import risk.
"""

from __future__ import annotations

MAX_LIFECYCLE_MESSAGE_LENGTH = 500


def sanitize_lifecycle_message(message: str, max_length: int = MAX_LIFECYCLE_MESSAGE_LENGTH) -> str:
    """Collapse *message* into a single safe ``lifecycle.log`` line.

    Embedded newlines (``\\r\\n``, ``\\r``, or ``\\n``) are collapsed into a
    literal ``\\n`` marker so multi-line operator input can never produce
    continuation lines — the whole message always lands on exactly one
    physical line, so it can never be mistaken for a second timestamped
    event. Overlong messages are truncated with a pointer to the full text,
    which callers that gate on human notes (e.g. review revise/reject)
    already persist verbatim in the order JSON.
    """
    if not message:
        return message or ""

    collapsed = message.replace("\r\n", "\n").replace("\r", "\n")
    collapsed = " \\n ".join(part.strip() for part in collapsed.split("\n"))

    if len(collapsed) > max_length:
        collapsed = collapsed[:max_length].rstrip() + " ...[truncated; full text in order JSON]"

    return collapsed
