"""
maestro/core/gates.py — Human review gate configuration and checks.

Reads .mso/config/gates.json to determine whether an order should pause for
human review at a role transition.

FTR-MSO-2026-0427 — schema v2 / per-transition gates
----------------------------------------------------
Historically the engine implemented exactly ONE gate: pause after the planning
role completes (PLN, legacy alias NAV) before the next role picks the order up,
configured under the fixed ``post_nav_review`` key. PLAN-PLN-MSO-2026-0371 §2.4
records that as the blocker for the DevOps division pack, which needs a PRE-REL
(pre-deploy) approval gate.

Schema v2 adds a ``transitions`` map keyed ``"<FROM>-><TO>"``::

    {
      "$schema": "Maestro — Gate Config",
      "schemaVersion": "2.0",
      "transitions": {
        "PLN->BLD": {"enabled": true,  "exempt_priorities": ["LOW"], "auto_approve_after_hours": 0},
        "BLD->REL": {"enabled": true,  "exempt_priorities": [],      "auto_approve_after_hours": 0},
        "*->REL":   {"enabled": true}
      }
    }

Back-compat is mandatory and total:

* A v1 gates.json carrying only ``post_nav_review`` keeps working with no
  migration — it is the fallback for any transition OUT of a planning role.
* A workspace with no gates.json at all behaves exactly as before (the default
  config has the planning gate disabled).
* ``gate_check_post_nav`` is preserved as a thin wrapper over the generalised
  ``gate_check_transition``.

Transition keys are canonicalised through the legacy role aliases (NAV→PLN,
SHP→BLD, BOS→TST, SCR→DOC, LKT→SEC, COX→REL, QM→LEAD), so a gates.json written
with nautical codes (``"NAV->SHP"``) matches a canonical transition (PLN->BLD)
and vice versa.
"""

from __future__ import annotations

import json
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, Literal, Optional, Tuple

from maestro.roles.loader import LEGACY_ALIASES


_DEFAULT_GATE_CONFIG: Dict[str, Any] = {
    "post_nav_review": {
        "enabled": False,
        "exempt_priorities": ["LOW"],
        "auto_approve_after_hours": 0,
    }
}

#: Planning-role codes (canonical PLN + legacy nautical NAV alias). The legacy
#: ``post_nav_review`` config key and the legacy per-order gate tokens apply to
#: transitions out of these roles only.
_PLANNING_ROLES = frozenset({"PLN", "NAV"})

#: Wildcard accepted on either side of a transition key.
_WILDCARD = "*"

#: Separator variants tolerated in a transition key, longest first so "-->"
#: is not consumed as "->" plus a stray ">". A hand-edited gates.json should not
#: silently do nothing because the operator typed the arrow a different way.
_KEY_SEPARATORS = ("-->", "->", "=>", "→", ">>", ":")


# ---------------------------------------------------------------------------
# Role / transition-key helpers
# ---------------------------------------------------------------------------

def canonical_role(role: Any) -> str:
    """Return the canonical uppercase role code for *role*.

    Legacy nautical aliases are folded to their canonical archetype (NAV→PLN,
    SHP→BLD, …). The wildcard ``*`` passes through. Unknown codes are returned
    uppercased and unchanged so a pack may name a role the engine doesn't know
    without the lookup exploding.
    """
    if not isinstance(role, str):
        return ""
    code = role.strip().upper()
    if not code:
        return ""
    if code == _WILDCARD:
        return _WILDCARD
    return LEGACY_ALIASES.get(code, code)


def is_planning_role(role: Any) -> bool:
    """True if *role* is the planning role (canonical PLN or legacy NAV)."""
    return isinstance(role, str) and role.strip().upper() in _PLANNING_ROLES


def transition_key(from_role: Any, to_role: Any) -> str:
    """Build the canonical ``"<FROM>-><TO>"`` key for a role transition.

    Both sides are canonicalised. A missing side renders as empty, which never
    matches a concrete configured key (only a wildcard tier can).
    """
    return f"{canonical_role(from_role)}->{canonical_role(to_role)}"


def parse_transition_key(key: Any) -> Optional[Tuple[str, str]]:
    """Parse a transition key into a canonical ``(from_role, to_role)`` pair.

    Tolerant of whitespace, lowercase, legacy aliases and the separator
    variants in :data:`_KEY_SEPARATORS`. Returns None when *key* is not a
    transition key at all (e.g. ``"post_nav_review"``, ``"$schema"``), which is
    how metadata keys are skipped.
    """
    if not isinstance(key, str):
        return None
    raw = key.strip()
    if not raw:
        return None
    for sep in _KEY_SEPARATORS:
        if sep in raw:
            left, _, right = raw.partition(sep)
            from_role = canonical_role(left)
            to_role = canonical_role(right)
            if not from_role and not to_role:
                return None
            return from_role, to_role
    return None


def _lookup_tiers(from_role: str, to_role: str) -> list[str]:
    """Transition keys to try, most specific first.

    Exact match wins, then a wildcard on the FROM side (``*->REL`` — "any role
    handing off to release"), then a wildcard on the TO side (``PLN->*``), then
    the catch-all ``*->*``. The FROM wildcard is deliberately ahead of the TO
    wildcard: a pre-deploy gate is defined by what is being entered, not by
    which role happened to precede it.
    """
    tiers: list[str] = []
    if from_role and to_role:
        tiers.append(f"{from_role}->{to_role}")
    if to_role:
        tiers.append(f"{_WILDCARD}->{to_role}")
    if from_role:
        tiers.append(f"{from_role}->{_WILDCARD}")
    tiers.append(f"{_WILDCARD}->{_WILDCARD}")
    return tiers


def transitions_index(config: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    """Canonicalise the ``transitions`` map into ``{canonical_key: gate_cfg}``.

    Non-dict values and unparseable keys are dropped rather than raised on — a
    malformed gates.json must not take the dispatcher down; `mso packs validate`
    is where authors get told about it.
    """
    raw = config.get("transitions") if isinstance(config, dict) else None
    if not isinstance(raw, dict):
        return {}
    index: Dict[str, Dict[str, Any]] = {}
    for raw_key, gate_cfg in raw.items():
        if not isinstance(gate_cfg, dict):
            continue
        parsed = parse_transition_key(raw_key)
        if parsed is None:
            continue
        index[f"{parsed[0]}->{parsed[1]}"] = gate_cfg
    return index


# ---------------------------------------------------------------------------
# Config loading
# ---------------------------------------------------------------------------

def _get_workspace_dir() -> Path:
    """Resolve the artefact plane (where config/gates.json lives).

    BUG-MSO-2026-0425: gate config is ARTEFACT state, so it must resolve via the
    artefact root (honours the solo/shared pointer), not the product repo's
    frozen .mso. fleet_runner.get_artefact_root honours _MAESTRO_DIR_OVERRIDE and
    delegates to maestro.workspace.get_artefact_root(). Imported lazily to avoid
    a circular import at module load.
    """
    try:
        from maestro.core.fleet_runner import get_artefact_root
        return get_artefact_root()
    except Exception:
        from maestro.workspace import MSO_DIR_NAME
        return Path(MSO_DIR_NAME)


def load_gate_config(adm_dir: Path | None = None) -> Dict[str, Any]:
    """Load .mso/config/gates.json, returning the default config when missing."""
    if adm_dir is None:
        adm_dir = _get_workspace_dir()
    gates_file = adm_dir / "config" / "gates.json"
    if not gates_file.exists():
        return json.loads(json.dumps(_DEFAULT_GATE_CONFIG))
    try:
        return json.loads(gates_file.read_text(encoding="utf-8"))
    except Exception:
        return json.loads(json.dumps(_DEFAULT_GATE_CONFIG))


def resolve_transition_gate(
    config: Dict[str, Any],
    from_role: Any,
    to_role: Any,
) -> Tuple[Optional[str], Optional[Dict[str, Any]]]:
    """Resolve the gate config governing the ``from_role -> to_role`` transition.

    Returns ``(matched_key, gate_cfg)``, or ``(None, None)`` when no gate is
    configured for this transition.

    Resolution order:

    1. schema-v2 ``transitions`` map — exact key, then ``*-><TO>``, then
       ``<FROM>->*``, then ``*->*``.
    2. legacy ``post_nav_review`` — the v1 shape, honoured for transitions OUT
       of a planning role only (exactly the set of transitions the v1 engine
       could gate).

    An explicit v2 entry always wins over the v1 fallback, so an operator can
    turn the planning gate off per-transition without deleting the legacy key.
    """
    if not isinstance(config, dict):
        return None, None

    index = transitions_index(config)
    if index:
        canon_from = canonical_role(from_role)
        canon_to = canonical_role(to_role)
        for key in _lookup_tiers(canon_from, canon_to):
            if key in index:
                return key, index[key]

    legacy = config.get("post_nav_review")
    if isinstance(legacy, dict) and is_planning_role(from_role):
        return "post_nav_review", legacy

    return None, None


# ---------------------------------------------------------------------------
# Per-order gate tokens
# ---------------------------------------------------------------------------

def _normalise_token(token: Any) -> str:
    """Canonicalise a per-order ``gates`` token.

    ``"human_review:NAV->SHP"`` → ``"human_review:PLN->BLD"``; bare tokens are
    just lowercased. Unknown shapes normalise to their lowercase selves and
    simply never match.
    """
    if not isinstance(token, str):
        return ""
    raw = token.strip()
    if not raw:
        return ""
    name, sep, target = raw.partition(":")
    name = name.strip().lower()
    if not sep:
        return name
    parsed = parse_transition_key(target)
    if parsed is None:
        return f"{name}:{target.strip().upper()}"
    return f"{name}:{parsed[0]}->{parsed[1]}"


def _order_tokens(order_data: Dict[str, Any]) -> set[str]:
    tokens = order_data.get("gates") if isinstance(order_data, dict) else None
    if not isinstance(tokens, list):
        return set()
    return {t for t in (_normalise_token(tok) for tok in tokens) if t}


# ---------------------------------------------------------------------------
# Gate checks
# ---------------------------------------------------------------------------

def gate_check_transition(
    order_data: Dict[str, Any],
    config: Dict[str, Any],
    from_role: Any,
    to_role: Any = "",
) -> Literal["advance", "pause"]:
    """Return 'pause' or 'advance' for an order completing *from_role*.

    Per-order overrides win over the workspace config, most specific first:

      ``gates: ["human_review:BLD->REL"]``      → always pause that transition
      ``gates: ["skip_human_review:BLD->REL"]`` → always advance it
      ``gates: ["nav_human_review"]``           → legacy; pause planning exits
      ``gates: ["skip_nav_human_review"]``      → legacy; advance planning exits
      ``gates: ["human_review"]``               → pause every gated transition
      ``gates: ["skip_human_review"]``          → advance every transition

    Workspace config (see :func:`resolve_transition_gate`):
      ``enabled=true`` + priority not in ``exempt_priorities`` → pause.

    Otherwise: advance.
    """
    order_data = order_data if isinstance(order_data, dict) else {}
    tokens = _order_tokens(order_data)
    key = transition_key(from_role, to_role)

    if f"human_review:{key}" in tokens:
        return "pause"
    if f"skip_human_review:{key}" in tokens:
        return "advance"

    # Legacy tokens are scoped to planning exits — the only transitions the v1
    # engine ever consulted them for, so scoping them here changes nothing.
    if is_planning_role(from_role):
        if "nav_human_review" in tokens:
            return "pause"
        if "skip_nav_human_review" in tokens:
            return "advance"

    if "human_review" in tokens:
        return "pause"
    if "skip_human_review" in tokens:
        return "advance"

    _matched, gate_cfg = resolve_transition_gate(config, from_role, to_role)
    if not gate_cfg or not gate_cfg.get("enabled", False):
        return "advance"

    priority = order_data.get("priority", "NORMAL")
    exempt = gate_cfg.get("exempt_priorities", [])
    if isinstance(exempt, list) and priority in exempt:
        return "advance"

    return "pause"


def gate_check_post_nav(
    order_data: Dict[str, Any],
    config: Dict[str, Any],
) -> Literal["advance", "pause"]:
    """Return 'pause' or 'advance' for an order that just completed planning.

    Back-compat wrapper over :func:`gate_check_transition` (FTR-MSO-2026-0427).
    The destination role is unknown here, so only wildcard ``transitions``
    entries and the legacy ``post_nav_review`` key can match — which is what a
    standalone planning order (no next role in its own roleSequence) needs.
    """
    return gate_check_transition(order_data, config, "PLN", "")


def order_gate_transition(order_data: Dict[str, Any]) -> Tuple[str, str]:
    """Recover the ``(from_role, to_role)`` a review-held order was paused at.

    Reads the ``reviewGateFrom``/``reviewGateTo`` fields written when the order
    was parked, falling back to parsing ``reviewGate``. Returns ``("", "")`` for
    an order paused by a pre-FTR-0427 dispatcher — callers then fall back to the
    legacy ``post_nav_review`` behaviour, which is what that order was gated on.
    """
    if not isinstance(order_data, dict):
        return "", ""
    from_role = canonical_role(order_data.get("reviewGateFrom"))
    to_role = canonical_role(order_data.get("reviewGateTo"))
    if from_role or to_role:
        return from_role, to_role
    parsed = parse_transition_key(order_data.get("reviewGate"))
    if parsed:
        return parsed
    return "", ""


def should_auto_approve(
    order_data: Dict[str, Any],
    config: Dict[str, Any],
    paused_at: str,
) -> bool:
    """Return True if the order has been paused long enough for auto-approval.

    paused_at is an ISO-8601 timestamp string written when the order was moved
    to queues/review/.  Returns False when auto_approve_after_hours is 0.

    FTR-MSO-2026-0427: the timeout is read from the gate that actually paused
    this order (recovered via :func:`order_gate_transition`), so a per-transition
    gate can set its own auto-approve window. Orders with no recorded transition
    fall back to ``post_nav_review`` — the v1 behaviour.
    """
    from_role, to_role = order_gate_transition(order_data)
    _matched, gate_cfg = resolve_transition_gate(config, from_role, to_role)
    if gate_cfg is None:
        gate_cfg = config.get("post_nav_review", {}) if isinstance(config, dict) else {}
    if not isinstance(gate_cfg, dict):
        return False
    hours = gate_cfg.get("auto_approve_after_hours", 0)
    if not hours:
        return False
    try:
        paused_dt = datetime.fromisoformat(paused_at)
    except (ValueError, TypeError):
        return False
    return datetime.now() >= paused_dt + timedelta(hours=hours)
