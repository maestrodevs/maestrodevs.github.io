"""FTR-MSO-2026-0408 — silent subprocess + console helpers.

Maestro runs its dispatcher and crews windowless/detached on Windows
(``DETACHED_PROCESS``, launched hidden). On Windows, any child console process
a windowless parent spawns **without** the ``CREATE_NO_WINDOW`` flag is handed
its *own* console window — a visible flash on the Captain's desktop that
disrupts other work. Two flash classes existed before this module:

1. ~117 raw ``subprocess.run``/``Popen`` calls for git/gh/worktree/etc. across
   ``maestro/core/*`` that never set ``creationflags`` — each flashed when the
   parent had no console.
2. ``os.system('cls')`` screen repaints and ``os.system('chcp 65001 …')`` /
   ``os.system('')`` code-page/ANSI setup — each spawns a ``cmd.exe`` → one
   flash per repaint.

The fix routes every captured/synchronous subprocess in ``maestro/core/*``
through :func:`run_hidden` / :func:`popen_hidden` (which stamp
``CREATE_NO_WINDOW`` plus a hidden ``STARTUPINFO`` on win32, and no-op the flag
elsewhere), and replaces the ``os.system`` repaints with :func:`clear_console`
/ :func:`init_console` (in-process ANSI / ``ctypes`` equivalents that no-op
when no console is attached — the detached-dispatcher case).

The intentional *detached* launches (the crew process launch and the bridge/hub
daemons) are already windowless via ``DETACHED_PROCESS`` and are deliberately
left untouched.

The FTR-0408 audit test (``tests/test_ftr_0408_no_window_audit.py``) fails CI
if a bare ``subprocess.run``/``Popen`` or ``os.system('cls'|'chcp'…)`` is
reintroduced anywhere in ``maestro/core/*`` outside this module.
"""

from __future__ import annotations

import os
import subprocess
import sys
from typing import Any, Optional

# CREATE_NO_WINDOW: the child runs with no console of its own (no desktop
# flash) but keeps its stdio pipes, so output capture is unaffected. 0x08000000.
CREATE_NO_WINDOW = 0x08000000


def _hidden_startupinfo() -> "Optional[subprocess.STARTUPINFO]":
    """A ``STARTUPINFO`` that hides any window the child might show (win32 only).

    Belt-and-suspenders alongside ``CREATE_NO_WINDOW``: even a child that calls
    ``ShowWindow`` itself stays hidden.
    """
    if os.name != "nt":
        return None
    si = subprocess.STARTUPINFO()
    si.dwFlags |= getattr(subprocess, "STARTF_USESHOWWINDOW", 0x1)
    si.wShowWindow = getattr(subprocess, "SW_HIDE", 0)
    return si


def _augment(kwargs: dict) -> dict:
    """OR ``CREATE_NO_WINDOW`` into ``creationflags`` and attach a hidden
    ``STARTUPINFO`` (win32 only). Existing caller flags / startupinfo are
    preserved, never overwritten. No-op on non-Windows platforms."""
    if os.name != "nt":
        return kwargs
    kwargs["creationflags"] = kwargs.get("creationflags", 0) | CREATE_NO_WINDOW
    if kwargs.get("startupinfo") is None:
        kwargs["startupinfo"] = _hidden_startupinfo()
    return kwargs


def run_hidden(*args: Any, **kwargs: Any) -> "subprocess.CompletedProcess":
    """Drop-in replacement for :func:`subprocess.run` that never flashes a
    console window on Windows.

    Every positional/keyword argument (``cwd``, ``env``, ``capture_output``,
    ``text``, ``timeout``, ``input``, ``check`` …) passes straight through, so
    return codes, captured output and timeout semantics are unchanged.
    """
    return subprocess.run(*args, **_augment(kwargs))


def popen_hidden(*args: Any, **kwargs: Any) -> "subprocess.Popen":
    """Drop-in replacement for :class:`subprocess.Popen` with
    ``CREATE_NO_WINDOW`` on Windows. All args/kwargs pass through unchanged."""
    return subprocess.Popen(*args, **_augment(kwargs))


# Neutral aliases for callers that read better without the "_hidden" suffix.
run = run_hidden
popen = popen_hidden


def no_window_kwargs(base: Optional[dict] = None) -> dict:
    """Return a Popen/run kwargs dict carrying the no-window hardening, for
    callers that build their own kwargs (e.g. the crew claude invocation, or a
    sandboxed detached launch that wants belt-and-suspenders hiding)."""
    return _augment(dict(base or {}))


def _has_console() -> bool:
    """True only when a real console is attached — i.e. a screen repaint or
    code-page change would actually be visible. The detached dispatcher (stdout
    redirected to a log, no tty) returns False so we skip the work entirely and
    never spawn a shell."""
    try:
        return bool(sys.stdout) and sys.stdout.isatty()
    except Exception:
        return False


def clear_console() -> None:
    """In-process screen clear. Replaces ``os.system('cls'/'clear')`` — which
    each spawn a shell (a console-window flash under a detached parent). Writes
    the ANSI "erase screen + home cursor" sequence, and only when a console is
    actually attached."""
    if not _has_console():
        return
    try:
        sys.stdout.write("\033[2J\033[H")
        sys.stdout.flush()
    except Exception:
        pass


def init_console() -> None:
    """Windows console setup without spawning ``cmd.exe``.

    Replaces ``os.system('chcp 65001 …')`` + ``os.system('')`` (the historic
    ANSI-enable trick), both of which flash a window under a detached parent.
    Sets the console code page to UTF-8 and enables virtual-terminal (ANSI)
    processing in-process via ``ctypes``. No-ops when not on Windows or when no
    console is attached."""
    if os.name != "nt" or not _has_console():
        return
    try:
        import ctypes

        kernel32 = ctypes.windll.kernel32  # type: ignore[attr-defined]
        # 65001 = UTF-8 code page (replaces `chcp 65001`).
        kernel32.SetConsoleOutputCP(65001)
        kernel32.SetConsoleCP(65001)
        # Enable ENABLE_VIRTUAL_TERMINAL_PROCESSING (0x0004) on stdout so ANSI
        # colour / clear sequences render (replaces the os.system('') trick).
        STD_OUTPUT_HANDLE = -11
        ENABLE_VIRTUAL_TERMINAL_PROCESSING = 0x0004
        handle = kernel32.GetStdHandle(STD_OUTPUT_HANDLE)
        mode = ctypes.c_uint32()
        if kernel32.GetConsoleMode(handle, ctypes.byref(mode)):
            kernel32.SetConsoleMode(
                handle, mode.value | ENABLE_VIRTUAL_TERMINAL_PROCESSING
            )
    except Exception:
        pass
