"""maestro/core/charts.py — Maestro Charts Phase 1: the read-only chart compiler.

FTR-MSO-2026-0495 (PLAN-VOY-MSO-2026-0143 Phase 1, part 1 of 3).

Compiles an INTERNAL graph representation ("chart") purely by projecting engine
mechanics that already exist and already behave like graph primitives — it does
not add any new state or touch dispatch:

  - roleSequence  -> a chain of waypoints (nodes) per order, resolved with the
                     exact precedence fleet_runner itself uses (order-level
                     ``roleSequence`` -> ``_meta.roleSequence`` -> the
                     order-type default in ``ROLE_SEQUENCES``, populated by
                     :func:`fleet_runner.load_role_sequences`). See
                     fleet_runner.py ~9137-9140 for the canonical resolution
                     this mirrors.
  - dependsOn     -> legs between order chains, drawn from the same field
                     :func:`fleet_runner.check_dependencies_satisfied` reads.
  - gates.json    -> humanGate annotations on role-pair legs, resolved via
                     :func:`gates.gate_check_transition` — the exact function
                     the dispatcher itself calls, so a waypoint's ``humanGate``
                     flag always agrees with what the real transition gate
                     would decide for that order (priority exemptions and
                     per-order override tokens included).
  - order ledger  -> node state, resolved via :func:`order_ledger.load_view`
                     (the BUG-MSO-2026-0294 checkpoint store). No parallel
                     state record is invented; a node with no ledger history
                     falls back to the order file's own ``status``/
                     ``targetRole`` fields (the same fields the dispatcher
                     reads for a fresh, not-yet-claimed order).

Hard constraint (PLAN-VOY-MSO-2026-0143 ruling 0a#2 — zero behaviour change):
this module is READ-ONLY. It never writes a file, never mutates ledger state,
and is never called from the dispatch loop or any queue scan — it only reads
already-computed state and renders it as a graph. Everything here is safe to
import and call from a CLI (`mso chart show`, Phase 1 part 2) or the Hub
without any risk of perturbing dispatch decisions.

Equivalence proof shape (ruling 0a#2 — "a linear roleSequence is a degenerate
chart"): :func:`compile_order_chart` renders exactly ONE order's own
roleSequence as a chain of waypoints joined only by ``onSuccess`` legs, with no
fan-in/fan-out. :meth:`Chart.is_degenerate_chain` checks that shape mechanically
so the equivalence claim is checkable, not asserted.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from maestro.core import gates as _gates
from maestro.core import order_ledger as _order_ledger

# ---------------------------------------------------------------------------
# Node (waypoint) state vocabulary
# ---------------------------------------------------------------------------
# A strict, read-only extension of the ledger's own event vocabulary
# (CLAIMED/ADVANCED/TERMINAL/RELEASED/REOPENED). Phase 1 only needs states a
# projection of TODAY's engine can already observe from the ledger + order
# file; dispatch-affecting states (FRONTIER/LAPPED/GATED) are Phase 2+ scope
# (PLAN-0143 §2.4) and are deliberately not introduced here.
NODE_NOT_STARTED = "NOT_STARTED"
NODE_QUEUED = "QUEUED"
NODE_RUNNING = "RUNNING"
NODE_DONE = "DONE"
NODE_FAILED = "FAILED"
NODE_STALLED = "STALLED"

_TERMINAL_STATUS_TO_NODE = {
    "COMPLETE": NODE_DONE,
    "FAILED": NODE_FAILED,
    "STALLED": NODE_STALLED,
}

# ---------------------------------------------------------------------------
# Leg (edge) type vocabulary
# ---------------------------------------------------------------------------
# Restricted to what Phase 1 actually observes today: plain role-sequence
# advance and dependsOn. onFail/onVerdict/fanIn are Phase 2/3 scope (typed
# failure edges, verifier panels) and are not wired here.
LEG_SUCCESS = "onSuccess"
LEG_DEPENDS_ON = "dependsOn"


def node_id(order_id: str, role: str) -> str:
    """Canonical waypoint id: one role-step of one order."""
    return f"{order_id}:{role}"


@dataclass
class Waypoint:
    """A chart node: one role-step of one order."""

    node_id: str
    order_id: str
    role: str
    state: str = NODE_NOT_STARTED
    humanGate: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "order": self.order_id,
            "role": self.role,
            "state": self.state,
            "humanGate": self.humanGate,
        }


@dataclass
class Leg:
    """A chart edge: a typed transition between two waypoints."""

    from_node: str
    to_node: str
    type: str
    humanGate: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "from": self.from_node,
            "to": self.to_node,
            "type": self.type,
            "humanGate": self.humanGate,
        }


@dataclass
class Chart:
    """A compiled chart: waypoints + legs for one order or one voyage."""

    chart_id: str
    voyage_id: str = ""
    nodes: Dict[str, Waypoint] = field(default_factory=dict)
    edges: List[Leg] = field(default_factory=list)

    def is_degenerate_chain(self) -> bool:
        """True iff this chart is a single linear chain with only onSuccess
        legs — the shape ruling 0a#2 requires of a plain (chart-less)
        roleSequence, and the equivalence Phase 1's acceptance test proves."""
        if any(e.type != LEG_SUCCESS for e in self.edges):
            return False
        outdeg: Dict[str, int] = {}
        indeg: Dict[str, int] = {}
        for e in self.edges:
            outdeg[e.from_node] = outdeg.get(e.from_node, 0) + 1
            indeg[e.to_node] = indeg.get(e.to_node, 0) + 1
        return all(v <= 1 for v in outdeg.values()) and all(v <= 1 for v in indeg.values())

    def to_dict(self) -> Dict[str, Any]:
        return {
            "chartId": self.chart_id,
            "voyage": self.voyage_id,
            "nodes": {nid: wp.to_dict() for nid, wp in self.nodes.items()},
            "edges": [e.to_dict() for e in self.edges],
        }


# ---------------------------------------------------------------------------
# Order / voyage artefact lookup (read-only)
# ---------------------------------------------------------------------------

def _load_order_data(order_id: str, workspace_dir: Optional[Path] = None) -> Optional[Dict[str, Any]]:
    """Load an order's JSON, archived or live. Mirrors the search
    fleet_runner._find_order_json_file does for live orders, plus the
    orders/complete|failed archive dirs it does not cover."""
    from maestro.core.fleet_runner import get_artefact_root, _find_order_json_file

    ws = workspace_dir or get_artefact_root()
    for sub in ("orders/complete", "orders/failed"):
        p = ws / sub / f"{order_id}.json"
        if p.exists():
            try:
                return json.loads(p.read_text(encoding="utf-8"))
            except Exception:
                pass
    live = _find_order_json_file(order_id, ws)
    if live is not None:
        try:
            return json.loads(live.read_text(encoding="utf-8"))
        except Exception:
            pass
    return None


def _load_voyage_data(voyage_id: str, workspace_dir: Optional[Path] = None) -> Optional[Dict[str, Any]]:
    from maestro.core.fleet_runner import get_artefact_root

    ws = workspace_dir or get_artefact_root()
    for sub in ("active", "complete"):
        p = ws / "voyages" / sub / f"{voyage_id}.json"
        if p.exists():
            try:
                return json.loads(p.read_text(encoding="utf-8"))
            except Exception:
                return None
    return None


def resolve_role_sequence(order_data: Optional[Dict[str, Any]]) -> List[str]:
    """Resolve an order's roleSequence with fleet_runner's own precedence:
    order-level ``roleSequence`` -> ``_meta.roleSequence`` -> the order-type
    default in ``ROLE_SEQUENCES`` (fleet_runner.py ~9137-9140). Reused
    verbatim rather than reimplemented so the chart's chain always agrees
    with what the dispatcher itself would advance through."""
    if not isinstance(order_data, dict):
        return []
    from maestro.core.fleet_runner import ROLE_SEQUENCES, load_role_sequences

    if not ROLE_SEQUENCES:
        load_role_sequences()
    meta = order_data.get("_meta", {}) if isinstance(order_data.get("_meta"), dict) else {}
    order_type = order_data.get("orderType") or order_data.get("type", "")
    sequence = (
        order_data.get("roleSequence")
        or meta.get("roleSequence")
        or ROLE_SEQUENCES.get(order_type, [])
    )
    return list(sequence) if sequence else []


# ---------------------------------------------------------------------------
# Node-state resolution (ledger-first, file-status fallback)
# ---------------------------------------------------------------------------

def resolve_node_states(
    order_id: str,
    sequence: List[str],
    order_data: Optional[Dict[str, Any]],
    ledger_view: _order_ledger.LedgerView,
) -> Dict[str, str]:
    """Return ``{role: NODE_STATE}`` for every role in *sequence*, for one
    order. Ledger-first (the BUG-0294 checkpoint store); an order the
    dispatcher has never touched (no ledger history at all) falls back to
    the order file's own ``status``/``targetRole`` fields — never a new
    parallel state record."""
    states: Dict[str, str] = {}
    if not sequence:
        return states

    from maestro.core.fleet_runner import resolve_order_fields

    if ledger_view.is_terminal(order_id):
        status = ledger_view.terminal.get(order_id, "COMPLETE")
        if status == "COMPLETE":
            for role in sequence:
                states[role] = NODE_DONE
            return states
        stalled_role = ledger_view.current_role(order_id)
        if stalled_role not in sequence:
            stalled_role = sequence[-1]
        idx = sequence.index(stalled_role)
        for i, role in enumerate(sequence):
            if i < idx:
                states[role] = NODE_DONE
            elif i == idx:
                states[role] = _TERMINAL_STATUS_TO_NODE.get(status, NODE_FAILED)
            else:
                states[role] = NODE_NOT_STARTED
        return states

    claim = ledger_view.live_claim(order_id)
    if claim and claim.get("role") in sequence:
        idx = sequence.index(claim["role"])
        for i, role in enumerate(sequence):
            states[role] = NODE_DONE if i < idx else (NODE_RUNNING if i == idx else NODE_NOT_STARTED)
        return states

    current = ledger_view.current_role(order_id)
    if current and current in sequence:
        idx = sequence.index(current)
        for i, role in enumerate(sequence):
            states[role] = NODE_DONE if i < idx else (NODE_QUEUED if i == idx else NODE_NOT_STARTED)
        return states

    # No ledger history at all for this order — fall back to its own file.
    file_status = (order_data or {}).get("status", "")
    target_role, _order_type = resolve_order_fields(order_data or {})
    if file_status == "COMPLETE":
        for role in sequence:
            states[role] = NODE_DONE
        return states
    if file_status in ("FAILED", "STALLED"):
        idx = sequence.index(target_role) if target_role in sequence else len(sequence) - 1
        for i, role in enumerate(sequence):
            if i < idx:
                states[role] = NODE_DONE
            elif i == idx:
                states[role] = _TERMINAL_STATUS_TO_NODE.get(file_status, NODE_FAILED)
            else:
                states[role] = NODE_NOT_STARTED
        return states
    if target_role in sequence:
        # scan_all_queues only ever picks up status=="PENDING" (fleet_runner.py
        # ~6930: "if status != 'PENDING': continue") — a PROPOSED/BACKLOG/other
        # order is not actually in the dispatch queue yet, so it must not read
        # as QUEUED here either. Only PENDING/IN_PROGRESS map to an active node.
        if file_status == "IN_PROGRESS":
            active_state = NODE_RUNNING
        elif file_status == "PENDING":
            active_state = NODE_QUEUED
        else:
            active_state = None
        if active_state is not None:
            idx = sequence.index(target_role)
            for i, role in enumerate(sequence):
                states[role] = NODE_DONE if i < idx else (active_state if i == idx else NODE_NOT_STARTED)
            return states

    for role in sequence:
        states[role] = NODE_NOT_STARTED
    return states


# ---------------------------------------------------------------------------
# Compilation
# ---------------------------------------------------------------------------

def compile_order_chain(
    order_id: str,
    order_data: Dict[str, Any],
    ledger_view: _order_ledger.LedgerView,
    gate_config: Dict[str, Any],
) -> tuple:
    """Compile one order's roleSequence into a linear chain of waypoints
    joined by onSuccess legs. Returns ``(nodes, edges)``.

    A single order's chain is exactly the degenerate chart ruling 0a#2
    requires: N waypoints, N-1 onSuccess legs, no branching. Gate annotation
    reuses :func:`gates.gate_check_transition` verbatim (not
    :func:`gates.resolve_transition_gate` directly) so ``humanGate`` reflects
    the ACTUAL pause/advance decision for this order — priority exemptions
    and per-order ``gates`` override tokens included — not merely whether a
    transition key exists in gates.json.
    """
    nodes: Dict[str, Waypoint] = {}
    edges: List[Leg] = []
    sequence = resolve_role_sequence(order_data)
    if not sequence:
        return nodes, edges

    states = resolve_node_states(order_id, sequence, order_data, ledger_view)
    for role in sequence:
        nid = node_id(order_id, role)
        nodes[nid] = Waypoint(node_id=nid, order_id=order_id, role=role,
                               state=states.get(role, NODE_NOT_STARTED))

    for i in range(len(sequence) - 1):
        from_role, to_role = sequence[i], sequence[i + 1]
        gated = _gates.gate_check_transition(order_data, gate_config, from_role, to_role) == "pause"
        from_id, to_id = node_id(order_id, from_role), node_id(order_id, to_role)
        edges.append(Leg(from_node=from_id, to_node=to_id, type=LEG_SUCCESS, humanGate=gated))
        nodes[to_id].humanGate = gated

    return nodes, edges


def compile_order_chart(order_id: str, workspace_dir: Optional[Path] = None) -> Chart:
    """Compile the degenerate single-order chart: this order's own
    roleSequence rendered as a linear chain of waypoints with only
    onSuccess legs. This is the exact equivalence case ruling 0a#2 requires
    provable — a plain, chart-less order compiles to precisely this shape,
    checkable via :meth:`Chart.is_degenerate_chain`."""
    from maestro.core.fleet_runner import get_artefact_root

    ws = workspace_dir or get_artefact_root()
    order_data = _load_order_data(order_id, ws)
    voyage_id = order_data.get("voyageId", "") if order_data else ""
    chart = Chart(chart_id=f"CHT-{order_id}", voyage_id=voyage_id)
    if order_data is None:
        return chart

    ledger_view = _order_ledger.load_view(ws)
    gate_config = _gates.load_gate_config(ws)
    nodes, edges = compile_order_chain(order_id, order_data, ledger_view, gate_config)
    chart.nodes = nodes
    chart.edges = edges
    return chart


def compile_voyage_chart(voyage_id: str, workspace_dir: Optional[Path] = None) -> Chart:
    """Compile the full chart for a voyage: every order's roleSequence chain,
    wired together by dependsOn legs. Node state and gate annotation are
    resolved once (ledger view + gate config) and shared across all of the
    voyage's order chains for consistency and to avoid re-reading the ledger
    file per order."""
    from maestro.core.fleet_runner import get_artefact_root, _voyage_order_ids

    ws = workspace_dir or get_artefact_root()
    voyage_data = _load_voyage_data(voyage_id, ws) or {}
    order_ids = _voyage_order_ids(voyage_data)

    ledger_view = _order_ledger.load_view(ws)
    gate_config = _gates.load_gate_config(ws)

    chart = Chart(chart_id=f"CHT-{voyage_id}", voyage_id=voyage_id)
    order_data_by_id: Dict[str, Dict[str, Any]] = {}

    for order_id in order_ids:
        data = _load_order_data(order_id, ws)
        if data is None:
            continue
        order_data_by_id[order_id] = data
        nodes, edges = compile_order_chain(order_id, data, ledger_view, gate_config)
        chart.nodes.update(nodes)
        chart.edges.extend(edges)

    # dependsOn legs: last waypoint of the dependency's own chain -> first
    # waypoint of the dependent's chain. We draw the edge from the field
    # check_dependencies_satisfied itself reads; we do not re-derive its
    # COMPLETE/STALLED-satisfies judgement here — the per-order ledger
    # resolution above already reflects whether the dependency actually
    # finished, which is what the waypoint states show.
    # list(...items()) — a dependency outside the voyage manifest gets loaded
    # and inserted into order_data_by_id inside this loop (below), which would
    # otherwise raise "dictionary changed size during iteration".
    for order_id, data in list(order_data_by_id.items()):
        depends_on = data.get("dependsOn", []) or []
        if not depends_on:
            continue
        dependent_sequence = resolve_role_sequence(data)
        if not dependent_sequence:
            continue
        to_id = node_id(order_id, dependent_sequence[0])
        for dep_id in depends_on:
            dep_data = order_data_by_id.get(dep_id)
            if dep_data is None:
                dep_data = _load_order_data(dep_id, ws)
                if dep_data is not None:
                    dep_nodes, dep_edges = compile_order_chain(dep_id, dep_data, ledger_view, gate_config)
                    chart.nodes.update(dep_nodes)
                    chart.edges.extend(dep_edges)
                    order_data_by_id[dep_id] = dep_data
            dep_sequence = resolve_role_sequence(dep_data) if dep_data else []
            if not dep_sequence:
                continue
            from_id = node_id(dep_id, dep_sequence[-1])
            chart.edges.append(Leg(from_node=from_id, to_node=to_id, type=LEG_DEPENDS_ON))

    return chart


# ---------------------------------------------------------------------------
# Rendering (Phase 1 part 2, FTR-MSO-2026-0496): `mso chart show` / Hub view
# ---------------------------------------------------------------------------
# Pure string builders over an already-compiled Chart. Like the compilation
# functions above, these never touch the workspace or the ledger themselves —
# they only format what compile_order_chart/compile_voyage_chart already
# resolved, so the read-only guarantee (ruling 0a#2) extends to rendering.

_STATE_GLYPH = {
    NODE_NOT_STARTED: ".",
    NODE_QUEUED: "o",
    NODE_RUNNING: ">",
    NODE_DONE: "x",
    NODE_FAILED: "!",
    NODE_STALLED: "?",
}

_MERMAID_STATE_CLASS = {
    NODE_NOT_STARTED: "notStarted",
    NODE_QUEUED: "queued",
    NODE_RUNNING: "running",
    NODE_DONE: "done",
    NODE_FAILED: "failed",
    NODE_STALLED: "stalled",
}


def _chains_by_order(chart: Chart) -> "Dict[str, List[Waypoint]]":
    """Group a chart's waypoints back into per-order chains, preserving each
    order's own insertion order (== its roleSequence order)."""
    chains: Dict[str, List[Waypoint]] = {}
    for wp in chart.nodes.values():
        chains.setdefault(wp.order_id, []).append(wp)
    return chains


def render_ascii(chart: Chart) -> str:
    """Render *chart* as a plain-text X-ray: one line per order's role chain,
    with dependsOn legs listed below and a '(gate)' suffix on any waypoint
    a human-review gate sits in front of."""
    lines: List[str] = [f"Chart: {chart.chart_id}"]
    if chart.voyage_id:
        lines.append(f"Voyage: {chart.voyage_id}")

    if not chart.nodes:
        lines.append("")
        lines.append("(no waypoints — nothing to chart)")
        return "\n".join(lines) + "\n"

    gated_ids = {e.to_node for e in chart.edges if e.humanGate}
    depends_edges = [e for e in chart.edges if e.type == LEG_DEPENDS_ON]

    lines.append("")
    for order_id, waypoints in _chains_by_order(chart).items():
        lines.append(order_id)
        parts = []
        for wp in waypoints:
            glyph = _STATE_GLYPH.get(wp.state, "?")
            tag = f"[{glyph}] {wp.role} ({wp.state})"
            if wp.node_id in gated_ids:
                tag += " (gate)"
            parts.append(tag)
        lines.append("  " + " -> ".join(parts))
        lines.append("")

    if depends_edges:
        lines.append("Depends on:")
        for e in depends_edges:
            lines.append(f"  {e.from_node} -> {e.to_node}")
        lines.append("")

    return "\n".join(lines).rstrip("\n") + "\n"


def _mermaid_node_id(waypoint_id: str) -> str:
    """Mermaid node ids must be identifier-safe (no ':' or '-'); waypoint ids
    (``ORDER-ID:ROLE``) are already unique, so a naive character-class
    substitution can't collide two distinct waypoints onto one node id."""
    return re.sub(r"[^A-Za-z0-9_]+", "_", waypoint_id)


def render_mermaid(chart: Chart) -> str:
    """Render *chart* as a Mermaid ``flowchart`` — pasteable into any Mermaid
    renderer (GitHub, mermaid.live, the Hub) with no Maestro-specific viewer
    required."""
    lines = ["flowchart LR"]
    for nid, wp in chart.nodes.items():
        mid = _mermaid_node_id(nid)
        label = f"{wp.order_id}:{wp.role}\\n{wp.state}"
        css_class = _MERMAID_STATE_CLASS.get(wp.state, "notStarted")
        lines.append(f'    {mid}["{label}"]:::{css_class}')
    for e in chart.edges:
        src, dst = _mermaid_node_id(e.from_node), _mermaid_node_id(e.to_node)
        label = e.type + (" (gate)" if e.humanGate else "")
        lines.append(f"    {src} -->|{label}| {dst}")
    lines.append("    classDef notStarted fill:#eeeeee,stroke:#999999,color:#333333;")
    lines.append("    classDef queued fill:#fff3cd,stroke:#997404,color:#333333;")
    lines.append("    classDef running fill:#cfe2ff,stroke:#0a58ca,color:#052c65;")
    lines.append("    classDef done fill:#d1e7dd,stroke:#146c43,color:#0a3622;")
    lines.append("    classDef failed fill:#f8d7da,stroke:#b02a37,color:#58151c;")
    lines.append("    classDef stalled fill:#fff3cd,stroke:#997404,color:#333333;")
    return "\n".join(lines) + "\n"
