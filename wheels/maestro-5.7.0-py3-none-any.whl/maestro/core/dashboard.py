"""
Maestro — Squad Monitor dashboard renderer (v5.0)
=================================================

Pure render layer for `mso status`. Replaces the box-drawing layout of the
v4.0 fleet_monitor.print_dashboard() with a modern, indentation-based design
matching the brand system (Abyss & Ember).

Design contract:
    - This module imports ONLY `rich` + stdlib. No `maestro.*` imports, no
      filesystem access, no environment reads. All data — including persona
      vocabulary — arrives inside a `DashboardState`.
    - `render_dashboard(state, compact, width)` returns a `rich.console.Group`
      ready to print once (`--once`) or hand to a `rich.live.Live` context.

Data gathering lives in maestro/core/fleet_monitor.py
(`build_dashboard_state()`), which maps the workspace state files into the
dataclasses below.

Requires: rich>=13.7 (hard dependency since v4.7).
"""

from __future__ import annotations

import shutil
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional

from rich.console import Group
from rich.text import Text

# ─── Brand palette (Abyss & Ember) ────────────────────────────────────────
# Hex literals; rich emits truecolor escapes and degrades gracefully on
# 256-color and legacy 16-color terminals.
EMBER = "#E0573A"
EMBER_HI = "#ED6F52"
TEAL = "#2B6B7A"
TEAL_HI = "#58A3B0"
SIGNAL = "#F1B843"
DANGER = "#D14B2F"
OK = "#6FC78A"
PAPER = "#EDE6D3"
DIM = "#6C7A87"
MUTE = "#8696A4"
BAR_EMPTY = "rgb(60,68,80)"


# ─── Styled-text helpers ──────────────────────────────────────────────────
def paper(s: str, bold: bool = False) -> Text:
    return Text(s, style=f"{PAPER}{' bold' if bold else ''}")


def dim(s: str) -> Text:
    return Text(s, style=DIM)


def mute(s: str) -> Text:
    return Text(s, style=MUTE)


def teal(s: str) -> Text:
    return Text(s, style=TEAL_HI)


def teal_label(s: str) -> Text:
    return Text(s, style=f"{TEAL_HI} bold")


def ember(s: str, bold: bool = False) -> Text:
    return Text(s, style=f"{EMBER}{' bold' if bold else ''}")


def signal(s: str, bold: bool = False) -> Text:
    return Text(s, style=f"{SIGNAL}{' bold' if bold else ''}")


def ok(s: str) -> Text:
    return Text(s, style=OK)


def danger(s: str, bold: bool = False) -> Text:
    return Text(s, style=f"{DANGER}{' bold' if bold else ''}")


def _dot_sep() -> Text:
    return dim("·")


# ─── Formatting helpers ───────────────────────────────────────────────────
def fmt_duration(sec: float) -> str:
    """HH:MM:SS / MM:SS; negative (sentinel) renders as --:--."""
    if sec < 0:
        return "--:--"
    sec = int(sec)
    h, rem = divmod(sec, 3600)
    m, s = divmod(rem, 60)
    return f"{h:02d}:{m:02d}:{s:02d}" if h else f"{m:02d}:{s:02d}"


def fmt_tokens(tok: int) -> str:
    if tok >= 1_000_000:
        return f"{tok / 1_000_000:.2f}M tok"
    if tok >= 1_000:
        return f"{tok / 1_000:.1f}k tok"
    return f"{tok} tok"


def fmt_money(d: float) -> str:
    return f"${d:.2f}"


def progress_bar(pct: float, width: int, fill_style: str = EMBER) -> Text:
    """Unicode block bar — fill in ember (or given style), empty dimmed."""
    pct = max(0.0, min(100.0, pct))
    filled = round((pct / 100) * width)
    empty = width - filled
    bar = Text()
    bar.append("█" * filled, style=fill_style)
    bar.append("░" * empty, style=BAR_EMPTY)
    return bar


def join(*parts, sep=" ") -> Text:
    """Join Text/str parts with a separator, skipping None, into one Text."""
    out = Text()
    sep_text = sep if isinstance(sep, Text) else Text(sep)
    first = True
    for p in parts:
        if p is None:
            continue
        if not first:
            out.append_text(sep_text.copy())
        first = False
        out.append_text(p if isinstance(p, Text) else Text(p))
    return out


def justify(left: Text, right: Text, width: int) -> Text:
    """Left-align `left`, right-align `right`, pad spaces between."""
    gap = max(2, width - left.cell_len - right.cell_len)
    out = Text()
    out.append_text(left)
    out.append(" " * gap)
    out.append_text(right)
    return out


def pluralize(noun: str) -> str:
    """Persona-noun plural: append 's' unless it already ends in 's'."""
    return noun if noun.lower().endswith("s") else noun + "s"


# ─── Status vocabulary ────────────────────────────────────────────────────
# Real on-disk crew statuses (written by crew.py / fleet_runner.py /
# fleet_monitor orphan repair). Severity drives both the dot colour and the
# footer aggregates so they can never disagree.
#   severity: active | done | idle | attention | failed
# FTR-MSO-2026-0310: roles that write deliverables via a subagent rather than
# tracked file edits — "0 files" is expected, not a sign of no progress.
_READ_ONLY_ROLES = frozenset({"SEC"})

STATUS_STYLE: dict[str, tuple[str, str, str, str]] = {
    # status        dot  style                label          severity
    "RUNNING":      ("●", f"{EMBER} bold",    "",            "active"),
    "ACTIVE":       ("●", f"{EMBER} bold",    "",            "active"),
    "COMPLETE":     ("●", f"{OK} bold",       "done",        "done"),
    "IDLE":         ("○", DIM,                "idle",        "idle"),
    "UNKNOWN":      ("○", DIM,                "idle",        "idle"),
    "BLOCKED":      ("●", f"{SIGNAL} bold",   "blocked",     "attention"),
    "MAX_TURNS":    ("●", f"{SIGNAL} bold",   "max turns",   "attention"),
    "MAX_ITERATIONS": ("●", f"{SIGNAL} bold", "max iter",    "attention"),
    "CIRCUIT_BREAKER": ("●", f"{SIGNAL} bold", "max iter",   "attention"),
    "TIMEOUT":      ("●", f"{DANGER} bold",   "timeout",     "failed"),
    "HUNG":         ("●", f"{DANGER} bold",   "hung",        "failed"),
    # FTR-MSO-2026-0359: crew died of a connectivity loss — retried outside
    # the requeue cap, so "attention" rather than "failed".
    "NETWORK":      ("●", f"{SIGNAL} bold",   "network",     "attention"),
    # BUG-MSO-2026-0423: deterministic interpreter parse/syntax fault — a real
    # code failure (normal requeue budget), so "failed" not "attention".
    "CODE":         ("●", f"{DANGER} bold",   "code fault",  "failed"),
    "ERROR":        ("●", f"{DANGER} bold",   "error",       "failed"),
    "AUTH_ERROR":   ("●", f"{DANGER} bold",   "auth error",  "failed"),
    "CRASHED":      ("●", f"{DANGER} bold",   "crashed",     "failed"),
    "INTERRUPTED":  ("●", f"{DANGER} bold",   "interrupted", "failed"),
    "FAILED":       ("●", f"{DANGER} bold",   "failed",      "failed"),
}


def status_style(status: str) -> tuple[str, str, str, str]:
    """Resolve a status to (dot, dot_style, label, severity); forward-compatible."""
    entry = STATUS_STYLE.get((status or "IDLE").upper())
    if entry:
        return entry
    # Unknown future status — visible but not alarming.
    return ("●", MUTE, (status or "?").lower().replace("_", " "), "attention")


def severity_counts(crews: list["Crew"]) -> dict[str, int]:
    counts = {"active": 0, "done": 0, "idle": 0, "attention": 0, "failed": 0}
    for c in crews:
        counts[status_style(c.status)[3]] += 1
    return counts


# ─── Data model ───────────────────────────────────────────────────────────
@dataclass
class PersonaLabels:
    """Persona vocabulary resolved by the state builder — keeps the renderer pure."""
    product: str = "maestro"
    sprint: str = "Voyage"
    squad: str = "Squad"
    story: str = "Order"
    user_title: str = "Captain"
    lead_title: str = "Fleet Lead"
    crew_names: list = field(default_factory=list)  # fallback names per slot


@dataclass
class Crew:
    slot: int = 0
    name: str = ""
    status: str = "IDLE"        # see STATUS_STYLE
    role: str = ""              # PLN | BLD | TST | DOC | SEC | REL | LEAD
    model: str = ""             # Opus | Sonnet | Haiku
    order: str = ""             # e.g. FTR-MSO-2026-0186
    iter: int = 0
    max_iter: int = 0
    live_turn: int = 0          # FTR-MSO-2026-0227 live step counter
    max_turns: int = 0
    elapsed_sec: float = 0
    eta_sec: float = -1         # -1 sentinel → "--:--"
    files: int = 0
    tokens: int = 0
    cost_usd: float = 0.0
    duration_label: str = ""    # only used when status == COMPLETE
    activity: str = ""          # latest hook-written activity string
    pid: Optional[int] = None


@dataclass
class Approval:
    story: str
    voyage: str
    age: str = "--"


@dataclass
class Escalation:
    id: str
    title: str
    blocking: bool = False


@dataclass
class Voyage:
    id: str
    title: str = ""
    orders_done: int = 0
    orders_total: int = 0
    eta_sec: float = -1         # -1 sentinel → "--:--"
    orders_running: int = 0     # FTR-0310: orders with a live crew right now
    #   (appended last to preserve positional construction in existing tests)


@dataclass
class DashboardState:
    version: str = ""
    now: datetime = field(default_factory=datetime.now)
    dispatcher_running: bool = False
    dispatcher_pid: Optional[int] = None
    dispatcher_uptime_sec: float = -1
    voyages: list = field(default_factory=list)        # list[Voyage]
    crews: list = field(default_factory=list)          # list[Crew]
    approvals: list = field(default_factory=list)      # list[Approval]
    escalations: list = field(default_factory=list)    # list[Escalation]
    billing_mode: str = "max"   # "max" | "api"
    spend_usd: float = 0.0      # API spend (sum of order usage files)
    budget_usd: float = 0.0     # API budget (0 = no budget configured)
    queued: int = 0             # PENDING orders awaiting dispatch
    queue_breakdown: str = ""   # e.g. "BLD:3 TST:1 · requests 2 · defects 1"
    lifecycle: list = field(default_factory=list)      # list[str], oldest→newest
    labels: PersonaLabels = field(default_factory=PersonaLabels)
    bridge_status: str = ""     # "" hidden | "on" | "on (2 pending)" | "no token"
    refresh_seconds: int = 5
    max_crews: int = 5
    # BUG-MSO-2026-0349 (appended last to preserve positional construction):
    held: int = 0               # orders the dispatcher is holding on unmet deps
    held_items: list = field(default_factory=list)  # list[str] "ID — waiting on ..."
    # FTR-MSO-2026-0359 (appended last to preserve positional construction):
    offline_hold: bool = False  # connectivity gate holding new dispatches
    offline_detail: str = ""    # e.g. "OFFLINE — dispatch held, 2 crews riding it out"
    # BUG-MSO-2026-0451 (appended last to preserve positional construction):
    held_breakdown: str = ""   # e.g. "review-gated 4 · dep-held 0 · stranded 0 · skipped 2"


# ─── Renderers ────────────────────────────────────────────────────────────
def _header(state: DashboardState, width: int) -> Text:
    left = join(
        Text(state.labels.product.lower(), style=f"{PAPER} bold"),
        dim(f"v{state.version}" if state.version else ""),
        sep=" ",
    )
    ts = state.now.strftime("%Y-%m-%d %H:%M:%S")
    return justify(left, dim(ts), width)


def _voyage_full(v: Voyage, width: int) -> list:
    lines = []
    title = v.title or ""
    max_title = max(0, width - len(v.id) - 14)
    if len(title) > max_title:
        title = title[: max(0, max_title - 3)] + "..."
    lines.append(join(paper(v.id, bold=True), mute(title), sep="  "))

    pct = (v.orders_done / v.orders_total) * 100 if v.orders_total else 0
    bar_line = Text("  ")
    bar_line.append_text(progress_bar(pct, 40))
    bar_line.append("  ")
    bar_line.append_text(paper(f"{pct:.0f}%", bold=True))
    bar_line.append("  ")
    bar_line.append_text(_dot_sep())
    bar_line.append("  ")
    bar_line.append_text(paper(f"{v.orders_done} / {v.orders_total} orders"))
    if v.orders_running > 0:
        bar_line.append("  ")
        bar_line.append_text(_dot_sep())
        bar_line.append("  ")
        bar_line.append_text(ember(f"{v.orders_running} running"))
    if v.eta_sec >= 0:
        bar_line.append("  ")
        bar_line.append_text(_dot_sep())
        bar_line.append("  ")
        bar_line.append_text(paper(f"ETA {fmt_duration(v.eta_sec)}"))
    lines.append(bar_line)
    return lines


def _voyage_condensed(v: Voyage, width: int) -> Text:
    pct = (v.orders_done / v.orders_total) * 100 if v.orders_total else 0
    line = Text("  ")
    line.append_text(paper(v.id))
    line.append("  ")
    line.append_text(progress_bar(pct, 20))
    line.append("  ")
    line.append_text(paper(f"{v.orders_done}/{v.orders_total}"))
    title = v.title or ""
    room = width - line.cell_len - 4
    if title and room > 8:
        if len(title) > room:
            title = title[: room - 3] + "..."
        line.append("  ")
        line.append_text(mute(title))
    return line


def _voyages_block(state: DashboardState, width: int) -> list:
    label = state.labels.sprint.upper()
    lines = []
    voyages = state.voyages

    if not voyages:
        lines.append(join(teal_label(label), dim("none active"), sep="  "))
    else:
        head = join(teal_label(label), sep="  ") if len(voyages) == 1 else join(
            teal_label(pluralize(state.labels.sprint).upper()),
            mute(f"{len(voyages)} active"), sep="  ")
        lines.append(head)
        lines.extend(_voyage_full(voyages[0], width))
        for v in voyages[1:4]:
            lines.append(_voyage_condensed(v, width))
        if len(voyages) > 4:
            lines.append(join(Text("  "), mute(f"+ {len(voyages) - 4} more"), sep=""))

    # Billing-adaptive spend line — only when real data exists.
    if state.billing_mode == "api" and state.spend_usd > 0:
        usage = Text("  ")
        usage.append_text(mute("SPEND"))
        usage.append("  ")
        if state.budget_usd > 0:
            pct = state.spend_usd / state.budget_usd * 100
            usage.append_text(progress_bar(pct, 20, fill_style=TEAL_HI))
            usage.append("  ")
            usage.append_text(paper(
                f"{fmt_money(state.spend_usd)} of {fmt_money(state.budget_usd)} budget"))
            usage.append("  ")
            usage.append_text(_dot_sep())
            usage.append("  ")
            usage.append_text(teal(f"{pct:.0f}% used"))
        else:
            usage.append_text(paper(fmt_money(state.spend_usd), bold=True))
            usage.append("  ")
            usage.append_text(mute("this workspace"))
        lines.append(usage)
    return lines


def _escalations_block(state: DashboardState) -> list:
    if not state.escalations:
        return []
    labels = state.labels
    lines = [join(
        danger("!!", bold=True),
        danger("ESCALATIONS", bold=True),
        paper(f"{len(state.escalations)} pending"),
        _dot_sep(),
        mute(f"requires {labels.user_title}/{labels.lead_title} review"),
        sep="  ",
    )]
    for e in state.escalations[:3]:
        row = join(
            Text("  "),
            _dot_sep(),
            paper(e.id),
            mute(e.title[:40]),
            sep="  ",
        )
        if e.blocking:
            row.append("  ")
            row.append_text(danger("[BLOCKING]", bold=True))
        lines.append(row)
    if len(state.escalations) > 3:
        lines.append(join(Text("  "), _dot_sep(),
                          mute(f"+ {len(state.escalations) - 3} more"), sep="  "))
    return lines


def _approvals_block(state: DashboardState) -> list:
    if not state.approvals:
        return []
    labels = state.labels
    noun = pluralize(labels.story.lower())
    lines = [join(
        signal("!", bold=True),
        signal("PENDING REVIEW", bold=True),
        paper(f"{len(state.approvals)} {noun} awaiting {labels.user_title} review"),
        _dot_sep(),
        teal("mso review"),
        sep="  ",
    )]
    for a in state.approvals[:2]:
        lines.append(join(
            Text("  "),
            _dot_sep(),
            paper(a.story),
            dim(a.voyage),
            mute(f"age {a.age}") if a.age and a.age != "--" else None,
            sep="  ",
        ))
    if len(state.approvals) > 2:
        lines.append(join(
            Text("  "),
            _dot_sep(),
            mute(f"+ {len(state.approvals) - 2} more"),
            sep="  ",
        ))
    return lines


def _dot_for(status: str) -> Text:
    dot, style, _, _ = status_style(status)
    return Text(dot, style=style)


def _crew_full(crew: Crew, billing_mode: str, width: int) -> list:
    name_cell = paper(f"{crew.name[:12]:<13}", bold=True)
    dot, _, label, severity = status_style(crew.status)

    if severity == "idle":
        line = Text("  ")
        line.append_text(_dot_for(crew.status))
        line.append(" ")
        line.append_text(name_cell)
        line.append_text(dim("idle"))
        return [line]

    if severity == "done":
        line = Text("  ")
        line.append_text(_dot_for(crew.status))
        line.append(" ")
        line.append_text(name_cell)
        line.append_text(ember(crew.role))
        line.append("  ")
        line.append_text(mute(crew.model))
        line.append("  ")
        line.append_text(paper(crew.order))
        line.append("  ")
        line.append_text(_dot_sep())
        line.append("  ")
        line.append_text(ok("done"))
        if crew.duration_label:
            line.append("  ")
            line.append_text(mute(f"in {crew.duration_label}"))
        if crew.tokens:
            line.append("  ")
            line.append_text(_dot_sep())
            line.append("  ")
            line.append_text(mute(fmt_tokens(crew.tokens)))
        return [line]

    if severity in ("failed", "attention"):
        line = Text("  ")
        line.append_text(_dot_for(crew.status))
        line.append(" ")
        line.append_text(name_cell)
        line.append_text(ember(crew.role))
        line.append("  ")
        line.append_text(mute(crew.model))
        line.append("  ")
        line.append_text(paper(crew.order))
        line.append("  ")
        line.append_text(_dot_sep())
        line.append("  ")
        line.append_text(danger(label) if severity == "failed" else signal(label))
        return [line]

    # RUNNING — 2 lines + activity detail
    left = Text("  ")
    left.append_text(_dot_for(crew.status))
    left.append(" ")
    left.append_text(name_cell)
    left.append_text(ember(crew.role))
    left.append("  ")
    left.append_text(mute(crew.model))
    left.append("  ")
    left.append_text(paper(crew.order))

    right = join(
        mute(fmt_duration(crew.elapsed_sec)),
        _dot_sep(),
        paper(f"ETA {fmt_duration(crew.eta_sec)}"),
        sep="  ",
    )
    line1 = justify(left, right, width)

    # FTR-MSO-2026-0310: the progress bar tracks TURN burn-rate within the
    # current iteration (live_turn / max_turns) — the real "how far into this
    # push" signal — NOT iter / max_iter (max_iter is the 25-iteration Ralph
    # safety ceiling, so that bar read ~4% for a crew half-way through its work
    # and contradicted the turn count). "turns" is now the primary label; the
    # iteration is demoted to a plain counter.
    pct = (crew.live_turn / crew.max_turns) * 100 if crew.max_turns else 0
    line2 = Text("    ")
    line2.append_text(progress_bar(pct, 26))
    line2.append("  ")
    line2.append_text(paper(f"turns {crew.live_turn}/{crew.max_turns}" if crew.max_turns
                            else f"turns {crew.live_turn}"))
    line2.append("  ")
    line2.append_text(_dot_sep())
    line2.append("  ")
    line2.append_text(mute(f"iter {crew.iter}/{crew.max_iter}" if crew.max_iter
                           else f"iter {crew.iter}"))
    line2.append("  ")
    line2.append_text(_dot_sep())
    line2.append("  ")
    # Role-aware files: a read-only role (SEC) writes its report via a subagent,
    # so "0 files" is expected and shouldn't read as "no progress".
    if crew.files == 0 and crew.role.upper() in _READ_ONLY_ROLES:
        line2.append_text(mute("read-only"))
    else:
        line2.append_text(mute(f"{crew.files} files"))
    if crew.tokens:
        line2.append("  ")
        line2.append_text(_dot_sep())
        line2.append("  ")
        line2.append_text(mute(fmt_tokens(crew.tokens)))
    if billing_mode == "api" and crew.cost_usd:
        line2.append("  ")
        line2.append_text(dim(f"({fmt_money(crew.cost_usd)})"))

    lines = [line1, line2]
    if crew.activity:
        act = crew.activity
        if len(act) > width - 8:
            act = act[: width - 11] + "..."
        line3 = Text("    ")
        line3.append_text(dim(f"> {act}"))
        lines.append(line3)
    return lines


def _crew_compact(crew: Crew, billing_mode: str, width: int) -> list:
    name_cell = paper(f"{crew.name[:12]:<13}", bold=True)
    dot, _, label, severity = status_style(crew.status)

    if severity == "idle":
        line = Text("  ")
        line.append_text(_dot_for(crew.status))
        line.append(" ")
        line.append_text(name_cell)
        line.append_text(dim("idle"))
        return [line]

    if severity == "done":
        line = Text("  ")
        line.append_text(_dot_for(crew.status))
        line.append(" ")
        line.append_text(name_cell)
        line.append_text(ember(crew.role))
        line.append("  ")
        line.append_text(paper(crew.order))
        line.append("  ")
        line.append_text(_dot_sep())
        line.append("  ")
        line.append_text(ok("done"))
        if crew.duration_label:
            line.append(" ")
            line.append_text(mute(crew.duration_label))
        if crew.tokens:
            line.append("  ")
            line.append_text(mute(fmt_tokens(crew.tokens)))
        return [line]

    if severity in ("failed", "attention"):
        line = Text("  ")
        line.append_text(_dot_for(crew.status))
        line.append(" ")
        line.append_text(name_cell)
        line.append_text(ember(crew.role))
        line.append("  ")
        line.append_text(paper(crew.order))
        line.append("  ")
        line.append_text(_dot_sep())
        line.append("  ")
        line.append_text(danger(label) if severity == "failed" else signal(label))
        return [line]

    # RUNNING — 1 line. FTR-MSO-2026-0310: bar tracks turn burn-rate (see the
    # full-layout note); label shows live turns, not the iteration fraction.
    pct = (crew.live_turn / crew.max_turns) * 100 if crew.max_turns else 0
    left = Text("  ")
    left.append_text(_dot_for(crew.status))
    left.append(" ")
    left.append_text(name_cell)
    left.append_text(ember(crew.role))
    left.append("  ")
    left.append_text(progress_bar(pct, 14))
    left.append("  ")
    left.append_text(paper(f"{crew.live_turn}/{crew.max_turns}" if crew.max_turns
                           else f"turn {crew.live_turn}"))

    right = Text()
    right.append_text(mute(fmt_duration(crew.elapsed_sec)))
    right.append("  ")
    right.append_text(_dot_sep())
    right.append("  ")
    right.append_text(paper(f"ETA {fmt_duration(crew.eta_sec)}"))
    if crew.tokens:
        right.append("  ")
        right.append_text(_dot_sep())
        right.append("  ")
        right.append_text(mute(fmt_tokens(crew.tokens)))
    if billing_mode == "api" and crew.cost_usd:
        right.append(" ")
        right.append_text(dim(f"({fmt_money(crew.cost_usd)})"))
    return [justify(left, right, width)]


def _crews_block(state: DashboardState, compact: bool, width: int) -> list:
    labels = state.labels
    counts = severity_counts(state.crews)

    header_left = teal_label(pluralize(labels.squad).upper())
    right_parts = [
        mute(f"{state.max_crews} max"),
        _dot_sep(),
        paper(f"{counts['active']} active"),
    ]
    if counts["done"]:
        right_parts += [_dot_sep(), paper(f"{counts['done']} done")]
    if counts["attention"]:
        right_parts += [_dot_sep(), signal(f"{counts['attention']} need attention")]
    if counts["failed"]:
        right_parts += [_dot_sep(), danger(f"{counts['failed']} failed")]
    header_right = join(*right_parts, sep="  ")

    lines = [justify(header_left, header_right, width), Text("")]

    renderer = _crew_compact if compact else _crew_full
    for i, crew in enumerate(state.crews):
        if not crew.name:
            names = labels.crew_names
            crew.name = names[i] if i < len(names) else f"{labels.squad} {i + 1}"
        lines.extend(renderer(crew, state.billing_mode, width))
    return lines


def _queue_block(state: DashboardState) -> list:
    if (not state.queued and not state.queue_breakdown and not state.held
            and not state.held_breakdown):
        return []
    line = join(
        mute("QUEUE"),
        paper(f"{state.queued} pending"),
        sep="  ",
    )
    # BUG-MSO-2026-0349: dependency-held items are NOT dispatchable — show them
    # apart from pending, with one detail line per held order so the operator
    # can triage without grepping lifecycle.log for DEP_HELD.
    if state.held:
        line.append("  ")
        line.append_text(_dot_sep())
        line.append("  ")
        line.append_text(signal(f"{state.held} held", bold=True))
    if state.queue_breakdown:
        line.append("  ")
        line.append_text(_dot_sep())
        line.append("  ")
        line.append_text(mute(state.queue_breakdown))
    lines = [line]
    # BUG-MSO-2026-0451: the NAMED split across all four dispatcher-held
    # categories — same wording as the dispatcher's own IDLE_REAP line, so an
    # operator never has to grep lifecycle.log to learn WHY nothing is
    # dispatchable (e.g. stranded/review-gated orders that never appear as a
    # queue-file PENDING count at all).
    if state.held_breakdown:
        lines.append(join(Text("  "), mute("HELD"), mute(state.held_breakdown), sep=" "))
    shown = state.held_items[:4]
    for item in shown:
        lines.append(join(Text("  "), signal("HELD"), mute(item), sep=" "))
    if len(state.held_items) > len(shown):
        lines.append(join(
            Text("  "),
            dim(f"... and {len(state.held_items) - len(shown)} more held"),
            sep="",
        ))
    return lines


def _lifecycle_block(state: DashboardState) -> list:
    if not state.lifecycle:
        return []
    lines = [teal_label("LIFECYCLE")]
    for event in reversed(state.lifecycle):  # most recent first
        lines.append(join(Text("  "), dim(event), sep=""))
    return lines


def _footer(state: DashboardState, width: int) -> list:
    counts = severity_counts(state.crews)

    disp_parts = [mute("DISPATCHER")]
    if state.dispatcher_running:
        disp_parts.append(ok("● active"))
        if state.dispatcher_pid:
            disp_parts.append(dim(f"PID {state.dispatcher_pid}"))
        if state.dispatcher_uptime_sec >= 0:
            disp_parts += [_dot_sep(),
                           paper(f"uptime {fmt_duration(state.dispatcher_uptime_sec)}")]
    else:
        disp_parts.append(dim("○ stopped"))
    # FTR-MSO-2026-0359: the operator must see WHY nothing new is launching.
    if state.offline_hold:
        disp_parts += [_dot_sep(),
                       danger(state.offline_detail or "OFFLINE — dispatch held")]
    if state.bridge_status:
        bridge_style = ok if state.bridge_status.startswith("on") else danger
        disp_parts += [_dot_sep(), mute("BRIDGE"), bridge_style(state.bridge_status)]
    dispatch_left = join(*disp_parts, sep=" ")

    if state.billing_mode == "api" and state.spend_usd > 0:
        if state.budget_usd > 0:
            pct = state.spend_usd / state.budget_usd * 100
            usage_right = join(
                mute("SPEND"),
                paper(fmt_money(state.spend_usd), bold=True),
                mute(f"/ {fmt_money(state.budget_usd)}"),
                _dot_sep(),
                mute("BUDGET"), ok(f"{pct:.0f}%"),
                sep=" ",
            )
        else:
            usage_right = join(
                mute("SPEND"),
                paper(fmt_money(state.spend_usd), bold=True),
                sep=" ",
            )
    else:
        usage_right = Text("")
    line1 = justify(dispatch_left, usage_right, width)

    agg = join(
        paper(f"{counts['active']} active"),
        _dot_sep(),
        paper(f"{counts['done']} done"),
        _dot_sep(),
        signal(f"{counts['attention']} attention") if counts["attention"] else None,
        _dot_sep() if counts["attention"] else None,
        danger(f"{counts['failed']} failed") if counts["failed"] else paper("0 failed"),
        _dot_sep(),
        paper(f"{state.queued} queued"),
        _dot_sep() if state.held else None,
        signal(f"{state.held} held") if state.held else None,
        sep="  ",
    )
    hint = join(
        mute("REFRESH"), paper(f"{state.refresh_seconds}s"),
        _dot_sep(),
        mute("EXIT"), paper("ctrl+C"),
        sep=" ",
    )
    line2 = justify(agg, hint, width)
    return [line1, line2]


def render_dashboard(state: DashboardState, compact: bool = False,
                     width: Optional[int] = None) -> Group:
    """Return a rich Group ready to print or pass to a Live context."""
    if width is None:
        width = max(64, shutil.get_terminal_size((100, 30)).columns - 2)

    lines = []
    lines.append(_header(state, width))
    lines.append(Text(""))
    lines.extend(_voyages_block(state, width))
    lines.append(Text(""))

    escalations = _escalations_block(state)
    if escalations:
        lines.extend(escalations)
        lines.append(Text(""))

    approvals = _approvals_block(state)
    if approvals:
        lines.extend(approvals)
        lines.append(Text(""))

    lines.extend(_crews_block(state, compact=compact, width=width))
    lines.append(Text(""))

    queue = _queue_block(state)
    if queue:
        lines.extend(queue)
        lines.append(Text(""))

    if not compact:
        lifecycle = _lifecycle_block(state)
        if lifecycle:
            lines.extend(lifecycle)
            lines.append(Text(""))

    lines.extend(_footer(state, width))
    return Group(*lines)
