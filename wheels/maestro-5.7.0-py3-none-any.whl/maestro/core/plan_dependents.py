"""maestro/core/plan_dependents.py — shared dependent-order lookup for
standalone plan approval (BUG-MSO-2026-0239, BUG-MSO-2026-0476).

Both `mso review approve` (maestro/review.py) and the Hub's approve endpoint
(maestro/hub/review.py) need to answer, for a just-approved standalone
planning order:

  1. Which same-voyage orders declare it as a dependency, at all (any
     status) — used to decide whether approval unblocked something real or
     nothing was ever filed (BUG-MSO-2026-0476's silent false-finish).
  2. Which of those are PROPOSED — promoted to PENDING so the dispatcher
     picks them up (BUG-MSO-2026-0239).

Centralised here so the CLI and Hub review surfaces cannot drift out of
parity again — until this fix, only the CLI path (maestro/review.py)
actually promoted PROPOSED dependents; the Hub path silently did not.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Callable, Optional

#: Queue directories that may hold a dependent order (mirrors the set
#: scanned elsewhere in the codebase for the same purpose).
_QUEUE_SUBDIRS = (
    "orders", "bugs", "security", "explicit", "breakdown", "high-level", "defects",
)


def _iter_order_dirs(adm: Path) -> list[Path]:
    queues_dir = adm / "queues"
    dirs = [queues_dir / name for name in _QUEUE_SUBDIRS]
    requests_dir = queues_dir / "requests"
    if requests_dir.exists() and requests_dir.is_dir():
        dirs += [d for d in requests_dir.iterdir() if d.is_dir()]
    return dirs


def _depends_on(data: dict) -> list:
    deps = data.get("dependsOn", data.get("dependencies", []))
    return deps if isinstance(deps, list) else []


def find_filed_dependents(adm: Path, approved_order_id: str, voyage_id: str) -> list[str]:
    """Return the ids of same-voyage orders (any status) that declare
    *approved_order_id* as a dependency.

    Scans the live queues AND the archive (a dependent may already have run
    to completion by the time the plan gate is reviewed). An empty result
    means nothing was ever filed to unblock this plan.
    """
    found: list[str] = []
    dirs = _iter_order_dirs(adm) + [adm / "orders" / "complete", adm / "orders" / "failed"]
    for d in dirs:
        if not d.exists() or not d.is_dir():
            continue
        for json_file in d.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding="utf-8"))
            except Exception:
                continue
            if data.get("voyageId", "") != voyage_id:
                continue
            if approved_order_id in _depends_on(data):
                found.append(str(data.get("id") or data.get("orderId") or json_file.stem))
    return found


def promote_proposed_dependents(
    adm: Path,
    approved_order_id: str,
    voyage_id: str,
    write_json: Optional[Callable[[Path, dict], None]] = None,
) -> int:
    """Promote PROPOSED same-voyage dependents of *approved_order_id* to PENDING.

    *write_json* lets a caller plug in an atomic writer (the Hub uses
    temp-file + rename); defaults to a plain write (the CLI's prior
    behaviour). Returns the count promoted.
    """
    if write_json is None:
        def write_json(path: Path, data: dict) -> None:
            path.write_text(json.dumps(data, indent=2), encoding="utf-8")

    promoted = 0
    for d in _iter_order_dirs(adm):
        if not d.exists() or not d.is_dir():
            continue
        for json_file in d.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding="utf-8"))
            except Exception:
                continue
            if data.get("status", "").upper() != "PROPOSED":
                continue
            if data.get("voyageId", "") != voyage_id:
                continue
            if approved_order_id not in _depends_on(data):
                continue
            data["status"] = "PENDING"
            write_json(json_file, data)
            promoted += 1
    return promoted
