"""
maestro/review.py — Human review queue CLI handlers.

Supports: mso review queue | show | approve | revise | reject
Orders sit in .mso/queues/review/ while awaiting human decision.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict

from maestro.cli import find_workspace
from maestro.core.lifecycle_log import sanitize_lifecycle_message  # BUG-MSO-2026-0474: one-line-per-event guard
from maestro.core.plan_dependents import find_filed_dependents, promote_proposed_dependents


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _adm_dir(ws: Path) -> Path:
    # BUG-MSO-2026-0425: honour the solo/shared `artefacts` pointer so the review
    # queue reads the artefact plane, not the product repo's frozen .mso. Anchored
    # at *ws* (chosen by find_workspace) so an ambient MAESTRO_DIR can't retarget
    # it. In embedded mode this is byte-identical to resolve_artefact_dir(ws).
    from maestro.workspace import artefact_root_for
    return artefact_root_for(ws)


def _review_dir(adm: Path) -> Path:
    return adm / "queues" / "review"


def _orders_dir(adm: Path) -> Path:
    return adm / "queues" / "orders"


def _load_order(review_dir: Path, order_id: str) -> tuple[Path, Dict[str, Any]]:
    path = review_dir / f"{order_id}.json"
    if not path.exists():
        print(f"[review] Order {order_id} not found in queues/review/", file=sys.stderr)
        sys.exit(1)
    data = json.loads(path.read_text(encoding="utf-8"))
    return path, data


def _write_lifecycle(adm: Path, event_type: str, message: str) -> None:
    """BUG-MSO-2026-0474: *message* is sanitized to a single physical line —
    operator-supplied free text (revise/reject notes) used to be written
    verbatim, breaking lifecycle.log's one-line-per-event contract."""
    log_dir = adm / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / "lifecycle.log"
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"{timestamp} | {event_type:<10} | {sanitize_lifecycle_message(message)}\n"
    try:
        with open(str(log_file), "a", encoding="utf-8") as f:
            f.write(line)
    except OSError:
        pass


def _reviewer() -> str:
    """Best-effort reviewer identity (git user or env fallback)."""
    try:
        result = subprocess.run(
            ["git", "config", "user.email"],
            capture_output=True, text=True, timeout=5,
        )
        email = result.stdout.strip()
        if email:
            return email
    except Exception:
        pass
    return os.environ.get("USER", os.environ.get("USERNAME", "unknown"))


def _gate_roles(data: Dict[str, Any]) -> tuple[str, str]:
    """FTR-MSO-2026-0427: the RAW (from_role, to_role) the order is gated at.

    Raw — spelled the way this order's own roleSequence spells them — because
    `revise` puts from_role straight back into `targetRole` and `approve` feeds
    both into the ADVANCED ledger event.

    Prefers the `reviewGateFrom`/`reviewGateTo` fields the dispatcher writes when
    parking the order, and falls back to deriving the predecessor from the order's
    roleSequence — which is how an order paused by a pre-0427 dispatcher (only
    `targetRole` recorded) still resolves correctly.
    """
    to_role = str(data.get("reviewGateTo") or data.get("targetRole") or "")
    from_role = str(data.get("reviewGateFrom") or "")
    if not from_role:
        sequence = data.get("roleSequence") or data.get("_meta", {}).get("roleSequence") or []
        if sequence and to_role in sequence:
            idx = sequence.index(to_role)
            if idx > 0:
                from_role = sequence[idx - 1]
    return from_role, to_role


def _gate_label(data: Dict[str, Any]) -> str:
    """Human-facing label for the gate an order is held at.

    A planning gate — including the BUG-0205 standalone plan-approval hold, which
    has no next role to name — keeps rendering as ``NAV``, so existing operator
    muscle memory and log greps (``"rejected at NAV review"``) hold verbatim. Any
    gate that could not exist before FTR-MSO-2026-0427 renders as its canonical
    transition (``BLD->REL``).
    """
    from maestro.core.gates import canonical_role, is_planning_role

    from_role, to_role = _gate_roles(data)
    if not from_role or not to_role or is_planning_role(from_role):
        return "NAV"
    return f"{canonical_role(from_role)}->{canonical_role(to_role)}"


def _age_str(iso_ts: str) -> str:
    try:
        dt = datetime.fromisoformat(iso_ts)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        delta = datetime.now(timezone.utc) - dt
        minutes = int(delta.total_seconds() // 60)
        if minutes < 60:
            return f"{minutes}m"
        hours = minutes // 60
        if hours < 24:
            return f"{hours}h"
        return f"{hours // 24}d"
    except Exception:
        return "?"


# ---------------------------------------------------------------------------
# Command handlers
# ---------------------------------------------------------------------------

# BUG-MSO-2026-0462: queue/show are read-only (they list/display pending
# reviews, same as `mso status` or `mso voyage list`) and neither of those
# gates on a capability either — this codebase's convention is to gate
# state-changing decisions, not reads. approve/revise/reject are gated below
# because they are the human sign-off the review gate exists to enforce.

def cmd_review_queue(args: Any) -> None:
    """List orders currently awaiting human review."""
    ws = find_workspace(getattr(args, "project", None))
    adm = _adm_dir(ws)
    rev_dir = _review_dir(adm)

    if not rev_dir.exists():
        print("[review] No orders pending review.")
        return

    files = sorted(rev_dir.glob("*.json"))
    if not files:
        print("[review] No orders pending review.")
        return

    header = (f"{'ORDER ID':<28} {'TITLE':<40} {'VOYAGE':<22} {'AGE':>5} "
              f"{'ROLE':<6} {'GATE':<12}")
    print(header)
    print("-" * len(header))
    for f in files:
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
        except Exception:
            continue
        order_id = data.get("id", f.stem)
        title = (data.get("title", "") or "")[:38]
        voyage = data.get("voyageId", "")
        paused_at = data.get("navReviewPausedAt", "")
        age = _age_str(paused_at) if paused_at else "?"
        # BUG-MSO-2026-0205: standalone plan-approval orders have no next role.
        role = "PLAN" if data.get("planApprovalOnly") else data.get("targetRole", "")
        # FTR-MSO-2026-0427: which transition is this order held at? An order
        # gated at BLD->REL is indistinguishable from a plan review otherwise.
        gate = data.get("reviewGate") or _gate_label(data)
        print(f"{order_id:<28} {title:<40} {voyage:<22} {age:>5} {role:<6} {gate:<12}")


def _review_artefact(adm: Path, order_id: str, data: Dict[str, Any]) -> Path | None:
    """The document a reviewer should read for this gate, if one exists.

    A planning gate is reviewed against the plan. FTR-MSO-2026-0427: any other
    gate is reviewed against the handoff the gated role wrote — for a BLD->REL
    gate there is no PLAN-<id>.md, and dumping the order JSON tells the reviewer
    nothing about what is being approved for deploy.
    """
    plan_path = adm / "plans" / f"PLAN-{order_id}.md"
    if plan_path.exists():
        return plan_path
    from_role, to_role = _gate_roles(data)
    if from_role and to_role:
        handoff = adm / "handoffs" / order_id / f"{from_role}-to-{to_role}.md"
        if handoff.exists():
            return handoff
    return None


def cmd_review_show(args: Any) -> None:
    """Open the artefact under review in $EDITOR, or print it to stdout."""
    ws = find_workspace(getattr(args, "project", None))
    adm = _adm_dir(ws)
    order_id = args.order_id

    _, data = _load_order(_review_dir(adm), order_id)

    doc_path = _review_artefact(adm, order_id, data)
    if doc_path is None:
        # Fallback: dump order JSON
        print(json.dumps(data, indent=2))
        return

    editor = getattr(args, "editor", None) or os.environ.get("EDITOR", "")
    if editor:
        subprocess.run([editor, str(doc_path)])
    else:
        print(doc_path.read_text(encoding="utf-8"))


def cmd_review_approve(args: Any) -> None:
    """Approve an order paused for human review.

    Two cases:
      * Intra-order (targetRole set): advance to the next role and re-queue to
        queues/orders/ for the dispatcher to pick up.
      * BUG-MSO-2026-0205 plan approval (planApprovalOnly): the standalone planning
        order has no next role — archive it as COMPLETE so its dependent FTR/BLD
        orders unblock (NAV_REVIEW_PENDING is not a satisfying dependency status).
    """
    ws = find_workspace(getattr(args, "project", None))
    from maestro.identity.gate import require_capability
    require_capability("voyage.approve", workspace=ws)
    adm = _adm_dir(ws)
    order_id = args.order_id

    rev_dir = _review_dir(adm)
    order_path, data = _load_order(rev_dir, order_id)

    now = datetime.now().isoformat()
    reviewer = _reviewer()

    data["reviewedAt"] = now
    data["reviewedBy"] = reviewer
    data.pop("navReviewPausedAt", None)

    if data.get("planApprovalOnly"):
        # Standalone planning order — archive COMPLETE to release dependents.
        voyage_id = data.get("voyageId", "")
        data["status"] = "COMPLETE"
        data["completedAt"] = now
        data.pop("planApprovalOnly", None)
        archive_dir = adm / "orders" / "complete"
        archive_dir.mkdir(parents=True, exist_ok=True)
        dest = archive_dir / order_path.name
        dest.write_text(json.dumps(data, indent=2), encoding="utf-8")
        order_path.unlink()
        # BUG-MSO-2026-0239: promote PROPOSED same-voyage dependents to PENDING
        promoted = promote_proposed_dependents(adm, order_id, voyage_id)
        # BUG-MSO-2026-0476: was ANYTHING ever filed to depend on this plan?
        # promoted==0 alone is ambiguous — dependents may exist but simply
        # not be PROPOSED right now. The operator needs to know specifically
        # when NOTHING was ever filed, because then this voyage has no path
        # forward: it just looks finished with zero code delivered.
        filed = find_filed_dependents(adm, order_id, voyage_id)
        if promoted:
            promo_msg = f"promoted {promoted} build order(s) to PENDING"
        elif filed:
            promo_msg = f"{len(filed)} dependent(s) already filed, none PROPOSED to promote"
        else:
            promo_msg = "no PROPOSED dependents found to promote"
        _write_lifecycle(
            adm, "NAV_REVIEW_APPROVED",
            f"{order_id} plan approved by {reviewer} -> COMPLETE; {promo_msg}",
        )
        print(f"[review] {order_id} plan approved — archived COMPLETE; {promo_msg}.")

        if not filed:
            warning = (
                f"no dependent orders exist for {voyage_id or order_id} — "
                "build orders (FTR/BLD) must be filed before this voyage can finish"
            )
            _write_lifecycle(adm, "PLAN_ORPHANED", f"{order_id}: {warning}")
            print(f"[review] WARNING: {warning}.")
        return

    # Intra-order: advance to the next role (already set by fleet_runner) and re-queue.
    next_role = data.get("targetRole", "SHP")
    data["status"] = "PENDING"

    # FTR-MSO-2026-0281: copy PLN-recommended execution profile to authoritative fields
    # at the human approve gate (advisory default — recommended* never auto-applied at dispatch).
    # Only copy when the authoritative field is unset (do not clobber operator choices).
    copied_profile = []
    for rec_key, auth_key in (
        ("recommendedModel", "model"),
        ("recommendedContextWindow", "contextWindow"),
        ("recommendedEffort", "effort"),
    ):
        rec_val = data.get(rec_key, "")
        auth_val = data.get(auth_key, "")
        if rec_val and not auth_val:
            data[auth_key] = rec_val
            copied_profile.append(f"{auth_key}={rec_val}")
    profile_note = f"; profile: {', '.join(copied_profile)}" if copied_profile else ""

    # BUG-MSO-2026-0315: derive from_role BEFORE the file move so we can record
    # the ADVANCED ledger event that the BUG-0248 advance-loss guard requires.
    # FTR-MSO-2026-0427: prefer the transition the dispatcher recorded when it
    # parked the order — the roleSequence walk is the pre-0427 fallback and gets
    # the wrong answer when a role appears more than once in the sequence.
    gate_label = _gate_label(data)
    from_role, _ = _gate_roles(data)

    # The gate has been satisfied — clear its markers so the released order
    # doesn't carry a stale gate label into its next role.
    for gate_field in ("reviewGate", "reviewGateFrom", "reviewGateTo"):
        data.pop(gate_field, None)

    orders_dir = _orders_dir(adm)
    orders_dir.mkdir(parents=True, exist_ok=True)
    dest = orders_dir / order_path.name
    dest.write_text(json.dumps(data, indent=2), encoding="utf-8")
    order_path.unlink()

    # BUG-MSO-2026-0315: write the ADVANCED ledger event so the dispatch gate
    # sees the role progression after mso cleanup or a fresh dispatcher session.
    # Without this, the ledger only has CLAIMED events (at the old role) and
    # the BUG-0248 guard rewinds targetRole back to the completed role, causing
    # the approved crew to re-dispatch in an infinite loop.
    from maestro.core import order_ledger
    order_ledger.record_advanced(order_id, from_role, next_role, workspace_dir=adm)

    _write_lifecycle(
        adm, "NAV_REVIEW_APPROVED",
        f"{order_id} approved by {reviewer} at gate {gate_label} -> {next_role}{profile_note}",
    )
    print(f"[review] {order_id} approved at gate {gate_label} — advanced to {next_role} and re-queued{profile_note}.")


def cmd_review_revise(args: Any) -> None:
    """Send the order back to the gated role for revision, appending notes.

    FTR-MSO-2026-0427: "back" is the role that just completed and triggered the
    gate, not an unconditional NAV. An order held at BLD->REL goes back to BLD to
    redo the build; only when no transition can be recovered (a pre-0427 pause
    with an unhelpful roleSequence) does it fall back to NAV.
    """
    ws = find_workspace(getattr(args, "project", None))
    from maestro.identity.gate import require_capability
    require_capability("voyage.approve", workspace=ws)
    adm = _adm_dir(ws)
    order_id = args.order_id
    notes = getattr(args, "notes", None)

    if not notes:
        print("[review] --notes is required for revise.", file=sys.stderr)
        sys.exit(1)

    rev_dir = _review_dir(adm)
    order_path, data = _load_order(rev_dir, order_id)

    now = datetime.now().isoformat()
    reviewer = _reviewer()

    gate_label = _gate_label(data)
    revise_role, _ = _gate_roles(data)
    revise_role = revise_role or "NAV"

    existing_desc = data.get("description", "") or ""
    data["description"] = f"{existing_desc}\n\n[Revision requested {now} by {reviewer}]: {notes}".strip()
    data["status"] = "PENDING"
    data["targetRole"] = revise_role
    data["reviewedAt"] = now
    data["reviewedBy"] = reviewer
    data.pop("navReviewPausedAt", None)
    for gate_field in ("reviewGate", "reviewGateFrom", "reviewGateTo"):
        data.pop(gate_field, None)

    orders_dir = _orders_dir(adm)
    orders_dir.mkdir(parents=True, exist_ok=True)
    dest = orders_dir / order_path.name
    dest.write_text(json.dumps(data, indent=2), encoding="utf-8")
    order_path.unlink()

    _write_lifecycle(
        adm, "NAV_REVIEW_REVISED",
        f"{order_id} revised by {reviewer} at gate {gate_label} -> {revise_role}: {notes}",
    )
    print(f"[review] {order_id} sent back to {revise_role} for revision.")


def cmd_review_reject(args: Any) -> None:
    """Reject an order: mark it FAILED and archive it."""
    ws = find_workspace(getattr(args, "project", None))
    from maestro.identity.gate import require_capability
    require_capability("voyage.approve", workspace=ws)
    adm = _adm_dir(ws)
    order_id = args.order_id
    notes = getattr(args, "notes", None)

    if not notes:
        print("[review] --notes is required for reject.", file=sys.stderr)
        sys.exit(1)

    rev_dir = _review_dir(adm)
    order_path, data = _load_order(rev_dir, order_id)

    now = datetime.now().isoformat()
    reviewer = _reviewer()

    # FTR-MSO-2026-0427: name the gate that rejected it. _gate_label renders the
    # planning gate as "NAV", so the legacy "rejected at NAV review" phrasing is
    # unchanged for every gate that existed before this feature.
    gate_label = _gate_label(data)
    data["status"] = "FAILED"
    data["failureReason"] = f"rejected at {gate_label} review: {notes}"
    data["reviewedAt"] = now
    data["reviewedBy"] = reviewer
    data.pop("navReviewPausedAt", None)

    archive_dir = adm / "orders" / "failed"
    archive_dir.mkdir(parents=True, exist_ok=True)
    dest = archive_dir / order_path.name
    dest.write_text(json.dumps(data, indent=2), encoding="utf-8")
    order_path.unlink()

    _write_lifecycle(adm, "NAV_REVIEW_REJECTED", f"{order_id} rejected by {reviewer}: {notes}")
    print(f"[review] {order_id} rejected and archived to orders/failed/.")
