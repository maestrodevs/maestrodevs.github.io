"""
maestro/demo.py — `mso demo`: Squad Monitor dashboard PVT.

A production verification test for the v5.0 dashboard. Creates a demo voyage
with 6 demo orders (2× 20s, 2× 40s, 2× 60s) and drives them through 3
simulated crew slots on a staggered schedule, writing the SAME workspace
state files a real fleet writes (crew state.json, activity.txt, order queue
JSONs, usage files, lifecycle events). The live dashboard renders in-process
while the simulation runs, so every metric is exercised:

  - voyage progress bar + ETA draining 0/6 → 6/6
  - RUNNING crews with iteration bars, live turn counters, files, tokens, ETAs
  - COMPLETE transitions with durations, IDLE slots, staggered pickup
  - a mid-run ESCALATION that appears and resolves
  - a mid-run PENDING REVIEW item that appears and clears
  - QUEUE drain with role breakdown, LIFECYCLE events, SPEND line, footer counts

While the simulation runs, the demo gathers REAL local findings — an OWASP
pattern scan of the project's Python files, an outstanding-backlog review,
and a last-activity summary — and folds them into the final PVT report at
.mso/reports/demo/.

Everything the demo creates is removed afterwards; pre-existing crew state
files are backed up and restored byte-for-byte. No git mutations, no Claude
invocations, no token spend.
"""

from __future__ import annotations

import json
import os
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from maestro.core.lifecycle_log import sanitize_lifecycle_message  # BUG-MSO-2026-0474: one-line-per-event guard
from maestro.workspace import get_artefact_root  # BUG-MSO-2026-0425: demo artefact plane

DEMO_PROJECT = "DEMO"
DEMO_BUDGET_USD = 5.00          # synthetic budget for the SPEND line
TOLERANCE = 0.35                # PVT pass band: actual within ±35% of planned

# Crew slot → list of (role, type, planned seconds, title, activity script)
# 6 orders: 2× 20s, 2× 40s, 2× 60s across 3 crews, two waves each.
DEMO_PLAN: Dict[int, List[dict]] = {
    1: [
        {"role": "SEC", "type": "SEC", "seconds": 20,
         "title": "Security review of the application (OWASP pattern scan)",
         "activities": [
             "Scanning Python sources for OWASP patterns",
             "Checking secret/credential patterns",
             "Compiling severity counts",
         ]},
        {"role": "BLD", "type": "FTR", "seconds": 60,
         "title": "Demo build task — simulated implementation flow",
         "activities": [
             "Reading plan and acceptance criteria",
             "Editing demo module (simulated)",
             "Running unit tests (simulated)",
             "Committing work to demo branch (simulated)",
         ]},
    ],
    2: [
        {"role": "PLN", "type": "PLN", "seconds": 40,
         "title": "Review outstanding tickets, orders and bugs",
         "activities": [
             "Scanning queues for PENDING orders",
             "Reviewing bug queue ages",
             "Drafting backlog recommendations",
         ]},
        {"role": "TST", "type": "TST", "seconds": 40,
         "title": "Demo verification task — simulated QA flow",
         "activities": [
             "Collecting changed files",
             "Executing verification suite (simulated)",
             "Writing QA verdict",
         ]},
    ],
    3: [
        {"role": "DOC", "type": "DOC", "seconds": 20,
         "title": "Report last fleet activity",
         "activities": [
             "Tailing lifecycle log",
             "Summarising recent completions",
         ]},
        {"role": "REL", "type": "REL", "seconds": 60,
         "title": "Compile PVT report and recommended tasks",
         "activities": [
             "Aggregating PVT metrics",
             "Composing recommendations",
             "Finalising demo report",
         ]},
    ],
}

STAGGER_SECONDS = 4             # delay between crew starts (shows pickup flow)
ORDER_GAP_SECONDS = 4           # idle gap between a crew's two orders
ESCALATION_AT = 12              # T+12s: escalation appears
ESCALATION_RESOLVE_AT = 34      # T+34s: escalation resolves (visible ~22s)
REVIEW_AT = 22                  # T+22s: pending-review item appears
REVIEW_CLEAR_AT = 50            # T+50s: review item clears


# ---------------------------------------------------------------------------
# Lifecycle log (same format as fleet_runner.write_lifecycle_event)
# ---------------------------------------------------------------------------

def _write_lifecycle(event_type: str, message: str) -> None:
    """BUG-MSO-2026-0474: *message* is sanitized to a single physical line,
    matching every other lifecycle writer."""
    log_dir = get_artefact_root() / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(str(log_dir / "lifecycle.log"), "a", encoding="utf-8") as f:
        f.write(f"{timestamp} | {event_type:<10} | {sanitize_lifecycle_message(message)}\n")


# ---------------------------------------------------------------------------
# Demo artefact bookkeeping
# ---------------------------------------------------------------------------

@dataclass
class OrderRun:
    """One demo order's identity, schedule, and observed PVT timings."""
    order_id: str
    role: str
    crew: int
    planned_seconds: float
    title: str
    activities: List[str]
    started_at: Optional[float] = None      # time.monotonic()
    completed_at: Optional[float] = None
    final_tokens: int = 0
    final_cost: float = 0.0
    final_files: int = 0
    final_iter: int = 0

    @property
    def actual_seconds(self) -> Optional[float]:
        if self.started_at is None or self.completed_at is None:
            return None
        return self.completed_at - self.started_at


@dataclass
class DemoContext:
    """Shared state across the demo run: paths created, backups, results."""
    mso: Path
    voyage_id: str = ""
    time_scale: float = 1.0
    orders: List[OrderRun] = field(default_factory=list)
    created_paths: List[Path] = field(default_factory=list)
    crew_backups: Dict[Path, Optional[bytes]] = field(default_factory=dict)
    stop: threading.Event = field(default_factory=threading.Event)
    lock: threading.Lock = field(default_factory=threading.Lock)
    coverage: Dict[str, bool] = field(default_factory=dict)
    findings: Dict[str, object] = field(default_factory=dict)
    t0: float = 0.0

    def scaled(self, seconds: float) -> float:
        return seconds * self.time_scale

    def track(self, path: Path) -> Path:
        """Register a path for cleanup."""
        if path not in self.created_paths:
            self.created_paths.append(path)
        return path

    def demo_spend(self) -> float:
        return round(sum(o.final_cost for o in self.orders), 2)


# ---------------------------------------------------------------------------
# Safety checks
# ---------------------------------------------------------------------------

def check_fleet_idle(mso: Path) -> Optional[str]:
    """Return a refusal reason if a real fleet is active, else None."""
    from maestro.core.fleet_monitor import is_process_alive, load_json_safe

    pid_file = mso / "dispatcher.pid"
    if pid_file.exists():
        try:
            pid = int(pid_file.read_text(encoding="utf-8").strip())
            if is_process_alive(pid):
                return (f"the dispatcher is running (PID {pid}). "
                        "Stop it first — the demo writes to the same crew state files.")
        except (ValueError, OSError):
            pass

    for slot in (1, 2, 3):
        state = load_json_safe(mso / "crews" / f"crew{slot}" / "state.json") or {}
        if state.get("status") in ("RUNNING", "ACTIVE"):
            pid = state.get("pid")
            if pid and is_process_alive(pid):
                return (f"crew {slot} is RUNNING (PID {pid}). "
                        "The demo needs crew slots 1-3 idle.")
    return None


# ---------------------------------------------------------------------------
# Setup: demo voyage + orders + crew-state backups
# ---------------------------------------------------------------------------

def _next_demo_seq(mso: Path, year: int) -> int:
    """First sequence number with no existing *-DEMO-{year}-* collisions."""
    import re
    pattern = re.compile(rf"-{DEMO_PROJECT}-{year}-(\d{{4}})")
    highest = 0
    for sub in ("queues/orders", "orders/complete", "voyages/active",
                "voyages/complete", "usage/orders"):
        d = mso / sub
        if d.exists():
            for f in d.glob(f"*-{DEMO_PROJECT}-{year}-*.json"):
                m = pattern.search(f.stem)
                if m:
                    highest = max(highest, int(m.group(1)))
    return highest + 1


_CREW_FILES = ("state.json", "activity.txt", "activity.jsonl",
               "ralph-state.md", "progress.md")


def backup_crew_state(ctx: DemoContext) -> None:
    """Snapshot crew slot 1-3 files so cleanup can restore them byte-for-byte."""
    for slot in (1, 2, 3):
        crew_dir = ctx.mso / "crews" / f"crew{slot}"
        for name in _CREW_FILES:
            path = crew_dir / name
            ctx.crew_backups[path] = path.read_bytes() if path.exists() else None
            # Stale ralph-state.md would override the demo's iteration counter
            # in the dashboard's collector — clear it for the run.
            if name in ("ralph-state.md",) and path.exists():
                path.unlink()


def create_demo_artefacts(ctx: DemoContext) -> None:
    """Materialise the demo voyage + 6 queued orders."""
    year = datetime.now().year
    seq = _next_demo_seq(ctx.mso, year)
    ctx.voyage_id = f"VOY-{DEMO_PROJECT}-{year}-{seq:04d}"
    voyage_branch = f"demo/{ctx.voyage_id}"

    queues_dir = ctx.mso / "queues" / "orders"
    queues_dir.mkdir(parents=True, exist_ok=True)

    order_entries = []
    n = 0
    for crew_slot, plan in DEMO_PLAN.items():
        for spec in plan:
            n += 1
            order_id = f"{spec['type']}-{DEMO_PROJECT}-{year}-{seq + n:04d}"
            run = OrderRun(
                order_id=order_id,
                role=spec["role"],
                crew=crew_slot,
                planned_seconds=ctx.scaled(spec["seconds"]),
                title=spec["title"],
                activities=spec["activities"],
            )
            ctx.orders.append(run)
            order_json = {
                "id": order_id,
                "orderId": order_id,
                "type": spec["type"],
                "project": DEMO_PROJECT,
                "title": spec["title"],
                "status": "PENDING",
                "priority": "NORMAL",
                "role": spec["role"],
                "targetRole": spec["role"],
                "roleSequence": [spec["role"]],
                "voyageId": ctx.voyage_id,
                "voyageBranch": voyage_branch,
                "demo": True,
            }
            path = ctx.track(queues_dir / f"{order_id}.json")
            path.write_text(json.dumps(order_json, indent=2), encoding="utf-8")
            order_entries.append({"orderId": order_id, "status": "PENDING",
                                  "title": spec["title"]})

    voyage = {
        "id": ctx.voyage_id,
        "voyageId": ctx.voyage_id,
        "project": DEMO_PROJECT,
        "title": "Squad Monitor PVT — dashboard demo voyage",
        "status": "active",
        "createdAt": datetime.now().isoformat(),
        "orders": order_entries,           # dict shape — exercises that parser
        "voyageBranch": voyage_branch,
        "demo": True,
    }
    voyages_dir = ctx.mso / "voyages" / "active"
    voyages_dir.mkdir(parents=True, exist_ok=True)
    vpath = ctx.track(voyages_dir / f"{ctx.voyage_id}.json")
    vpath.write_text(json.dumps(voyage, indent=2), encoding="utf-8")

    # Mark the order-complete archive dir for cleanup tracking
    (ctx.mso / "orders" / "complete").mkdir(parents=True, exist_ok=True)

    _write_lifecycle("DEMO", f"PVT demo started — {ctx.voyage_id} (6 orders, 3 crews)")


# ---------------------------------------------------------------------------
# Simulated crew driver
# ---------------------------------------------------------------------------

def _update_voyage_order_status(ctx: DemoContext, order_id: str, status: str) -> None:
    vpath = ctx.mso / "voyages" / "active" / f"{ctx.voyage_id}.json"
    with ctx.lock:
        try:
            data = json.loads(vpath.read_text(encoding="utf-8"))
            for entry in data.get("orders", []):
                if entry.get("orderId") == order_id:
                    entry["status"] = status
            vpath.write_text(json.dumps(data, indent=2), encoding="utf-8")
        except (OSError, json.JSONDecodeError):
            pass


def _drive_order(ctx: DemoContext, crew_dir: Path, run: OrderRun) -> None:
    """Simulate one order: queue pickup → RUNNING ticks → COMPLETE + archive."""
    state_file = crew_dir / "state.json"
    activity_file = crew_dir / "activity.txt"
    queue_file = ctx.mso / "queues" / "orders" / f"{run.order_id}.json"
    usage_file = ctx.mso / "usage" / "orders" / f"{run.order_id}.json"
    usage_file.parent.mkdir(parents=True, exist_ok=True)
    ctx.track(usage_file)

    duration = run.planned_seconds
    max_iter = max(3, int(run.planned_seconds / ctx.time_scale / 5))  # ~1 iter / 5s
    max_turns = max_iter * 8
    tick = max(0.2, ctx.scaled(1.0))
    started = datetime.now()
    run.started_at = time.monotonic()

    # Queue order → IN_PROGRESS (drains the PENDING count on the dashboard)
    try:
        oj = json.loads(queue_file.read_text(encoding="utf-8"))
        oj["status"] = "IN_PROGRESS"
        queue_file.write_text(json.dumps(oj, indent=2), encoding="utf-8")
    except (OSError, json.JSONDecodeError):
        pass
    _update_voyage_order_status(ctx, run.order_id, "IN_PROGRESS")
    _write_lifecycle("DISPATCH", f"[DEMO] crew{run.crew} picked up {run.order_id} ({run.role})")

    elapsed = 0.0
    files = 0
    tokens = 0
    cost = 0.0
    while elapsed < duration and not ctx.stop.is_set():
        frac = min(1.0, elapsed / duration)
        iteration = max(1, round(frac * max_iter))
        live_turn = max(1, round(frac * max_turns))
        if int(elapsed) % 7 == 3:
            files += 1
        tokens = int(frac * run.planned_seconds / ctx.time_scale * 950)
        cost = round(tokens / 1_000_000 * 12.0, 4)

        state = {
            "status": "RUNNING",
            "role": run.role,
            "orderId": run.order_id,
            "iteration": iteration,
            "maxIterations": max_iter,
            "liveTurn": live_turn,
            "maxTurns": max_turns,
            "subagentCount": 0,
            "startTime": started.isoformat(),
            "filesChangedTotal": files,
            "pid": os.getpid(),
            "timeoutMinutes": 30,
            "demo": True,
        }
        state_file.write_text(json.dumps(state, indent=2), encoding="utf-8")
        activity = run.activities[min(len(run.activities) - 1,
                                      int(frac * len(run.activities)))]
        activity_file.write_text(activity, encoding="utf-8")
        usage_file.write_text(json.dumps({
            "orderId": run.order_id,
            "crewNumber": run.crew,
            "timestamp": datetime.now().isoformat(),
            "total_tokens": tokens,
            "estimated_cost_usd": cost,
            "demo": True,
        }, indent=2), encoding="utf-8")

        ctx.stop.wait(tick)
        elapsed = time.monotonic() - run.started_at

    if ctx.stop.is_set():
        return

    # COMPLETE
    run.completed_at = time.monotonic()
    run.final_tokens, run.final_cost = tokens, cost
    run.final_files, run.final_iter = files, max_iter
    ended = datetime.now()
    state = {
        "status": "COMPLETE",
        "role": run.role,
        "orderId": run.order_id,
        "iteration": max_iter,
        "maxIterations": max_iter,
        "liveTurn": max_turns,
        "maxTurns": max_turns,
        "startTime": started.isoformat(),
        "endTime": ended.isoformat(),
        "filesChangedTotal": files,
        "pid": os.getpid(),
        "demo": True,
    }
    state_file.write_text(json.dumps(state, indent=2), encoding="utf-8")
    activity_file.write_text("Done", encoding="utf-8")

    # Archive queue order → orders/complete (drains the queue file itself)
    complete_path = ctx.mso / "orders" / "complete" / f"{run.order_id}.json"
    try:
        oj = json.loads(queue_file.read_text(encoding="utf-8"))
        oj["status"] = "COMPLETE"
        oj["completedAt"] = ended.isoformat()
        complete_path.write_text(json.dumps(oj, indent=2), encoding="utf-8")
        ctx.track(complete_path)
        queue_file.unlink()
    except (OSError, json.JSONDecodeError):
        pass
    _update_voyage_order_status(ctx, run.order_id, "COMPLETE")
    _write_lifecycle("COMPLETE",
                     f"[DEMO] {run.order_id} complete on crew{run.crew} "
                     f"({run.actual_seconds:.0f}s)")


def _crew_thread(ctx: DemoContext, crew_slot: int) -> None:
    crew_dir = ctx.mso / "crews" / f"crew{crew_slot}"
    crew_dir.mkdir(parents=True, exist_ok=True)

    # Staggered start so the dashboard shows crews picking up one by one
    ctx.stop.wait(ctx.scaled((crew_slot - 1) * STAGGER_SECONDS))

    runs = [o for o in ctx.orders if o.crew == crew_slot]
    for i, run in enumerate(runs):
        if ctx.stop.is_set():
            return
        _drive_order(ctx, crew_dir, run)
        if i < len(runs) - 1 and not ctx.stop.is_set():
            # Brief IDLE gap between the crew's orders
            (crew_dir / "state.json").write_text(
                json.dumps({"status": "IDLE", "demo": True}), encoding="utf-8")
            ctx.stop.wait(ctx.scaled(ORDER_GAP_SECONDS))
    # leave final COMPLETE state visible; cleanup restores the original


def _events_thread(ctx: DemoContext) -> None:
    """Mid-run escalation + pending-review items (appear, then clear)."""
    esc_dir = ctx.mso / "queues" / "escalations"
    rev_dir = ctx.mso / "queues" / "review"
    esc_path = esc_dir / f"ESC-{DEMO_PROJECT}-PVT-0001.json"
    rev_path = rev_dir / f"PLN-{DEMO_PROJECT}-PVT-0001.json"

    ctx.stop.wait(ctx.scaled(ESCALATION_AT))
    if ctx.stop.is_set():
        return
    esc_dir.mkdir(parents=True, exist_ok=True)
    ctx.track(esc_path).write_text(json.dumps({
        "id": f"ESC-{DEMO_PROJECT}-PVT-0001",
        "title": "Demo escalation — dashboard PVT (auto-resolves)",
        "status": "PENDING",
        "blocking": True,
        "demo": True,
    }, indent=2), encoding="utf-8")
    ctx.coverage["escalation_shown"] = True
    _write_lifecycle("WARN", "[DEMO] escalation raised (PVT — auto-resolves)")

    ctx.stop.wait(ctx.scaled(REVIEW_AT - ESCALATION_AT))
    if ctx.stop.is_set():
        return
    rev_dir.mkdir(parents=True, exist_ok=True)
    ctx.track(rev_path).write_text(json.dumps({
        "id": f"PLN-{DEMO_PROJECT}-PVT-0001",
        "voyageId": ctx.voyage_id,
        "navReviewPausedAt": datetime.now().isoformat(),
        "demo": True,
    }, indent=2), encoding="utf-8")
    ctx.coverage["review_shown"] = True

    ctx.stop.wait(ctx.scaled(ESCALATION_RESOLVE_AT - REVIEW_AT))
    if not ctx.stop.is_set() and esc_path.exists():
        try:
            data = json.loads(esc_path.read_text(encoding="utf-8"))
            data["status"] = "RESOLVED"
            esc_path.write_text(json.dumps(data, indent=2), encoding="utf-8")
            _write_lifecycle("DEMO", "[DEMO] escalation resolved")
        except (OSError, json.JSONDecodeError):
            pass

    ctx.stop.wait(ctx.scaled(REVIEW_CLEAR_AT - ESCALATION_RESOLVE_AT))
    if not ctx.stop.is_set() and rev_path.exists():
        try:
            rev_path.unlink()
        except OSError:
            pass


# ---------------------------------------------------------------------------
# Real findings (local, no Claude, no tokens)
# ---------------------------------------------------------------------------

def gather_security_findings(ctx: DemoContext, max_files: int = 40) -> None:
    """OWASP pattern scan over the project's Python files (capped for speed)."""
    try:
        from maestro.security.owasp_patterns import OWASPScanner
    except ImportError:
        ctx.findings["security"] = {"error": "OWASP scanner unavailable"}
        return

    root = ctx.mso.parent
    candidates: List[Path] = []
    for base in (root / "maestro", root / "src", root):
        if base.exists():
            candidates = [p for p in sorted(base.rglob("*.py"))
                          if "__pycache__" not in p.parts
                          and ".venv" not in p.parts][:max_files]
            if candidates:
                break

    scanner = OWASPScanner(language="python")
    findings = scanner.scan_files([str(p) for p in candidates])
    by_severity: Dict[str, int] = {}
    for f in findings:
        sev = getattr(getattr(f, "severity", None), "value", None) or str(
            getattr(f, "severity", "UNKNOWN"))
        by_severity[sev] = by_severity.get(sev, 0) + 1
    # Top distinct patterns with counts + one example site each
    grouped: Dict[str, dict] = {}
    for f in findings:
        title = getattr(f, "title", "?")
        entry = grouped.setdefault(title, {
            "name": title,
            "severity": getattr(getattr(f, "severity", None), "value", "?"),
            "count": 0,
            "file": getattr(f, "file", "?"),
            "line": getattr(f, "line", 0),
        })
        entry["count"] += 1
    top = sorted(grouped.values(), key=lambda e: -e["count"])[:5]
    ctx.findings["security"] = {
        "files_scanned": len(candidates),
        "total": len(findings),
        "by_severity": by_severity,
        "top": top,
    }


def gather_backlog_review(ctx: DemoContext) -> None:
    """Real outstanding-work review: PENDING orders/bugs per queue with ages."""
    queues = ctx.mso / "queues"
    review: Dict[str, dict] = {}
    demo_ids = {o.order_id for o in ctx.orders}
    now = time.time()
    for qdir in sorted(queues.glob("*")) if queues.exists() else []:
        if not qdir.is_dir():
            continue
        items = []
        for f in qdir.rglob("*.json"):
            if f.stem in demo_ids or "-DEMO-" in f.stem:
                continue
            try:
                data = json.loads(f.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            status = data.get("status", "PENDING")
            if status in ("PENDING", ""):
                items.append({
                    "id": data.get("id", f.stem),
                    "title": (data.get("title") or "")[:60],
                    "age_days": round((now - f.stat().st_mtime) / 86400, 1),
                })
        if items:
            items.sort(key=lambda x: -x["age_days"])
            review[qdir.name] = {"count": len(items), "oldest": items[:3]}
    ctx.findings["backlog"] = review


def gather_last_activity(ctx: DemoContext, pre_demo_lifecycle: List[str]) -> None:
    """Recent completions + pre-demo lifecycle tail."""
    complete_dir = ctx.mso / "orders" / "complete"
    demo_ids = {o.order_id for o in ctx.orders}
    recent = []
    if complete_dir.exists():
        files = sorted(complete_dir.glob("*.json"),
                       key=lambda f: f.stat().st_mtime, reverse=True)
        for f in files:
            if f.stem in demo_ids or "-DEMO-" in f.stem:
                continue
            recent.append(f.stem)
            if len(recent) >= 5:
                break
    ctx.findings["activity"] = {
        "recent_completions": recent,
        "lifecycle_tail": pre_demo_lifecycle[-5:],
    }


def gather_recommendations(ctx: DemoContext) -> None:
    recs: List[str] = []
    backlog = ctx.findings.get("backlog") or {}
    total_pending = sum(v["count"] for v in backlog.values()) if backlog else 0
    if total_pending:
        oldest_age = max((i["age_days"] for v in backlog.values()
                          for i in v["oldest"]), default=0)
        recs.append(f"{total_pending} item(s) pending across "
                    f"{len(backlog)} queue(s) — oldest is {oldest_age:.0f} days old. "
                    "Consider `mso dispatch` or `mso order skip` for stale items.")
    sec = ctx.findings.get("security") or {}
    if sec.get("total"):
        recs.append(f"Security scan found {sec['total']} pattern match(es) "
                    f"across {sec['files_scanned']} files — review with "
                    "`mso security scan` and triage real positives.")
    if not (ctx.mso / "dispatcher.pid").exists():
        recs.append("No dispatcher running — start one with `mso dispatch` "
                    "when work is queued.")
    if not recs:
        recs.append("Workspace is clean: no pending backlog, no scanner hits.")
    ctx.findings["recommendations"] = recs


# ---------------------------------------------------------------------------
# PVT verdicts + report
# ---------------------------------------------------------------------------

def evaluate_pvt(ctx: DemoContext) -> Tuple[bool, List[dict]]:
    rows = []
    all_pass = True
    for run in ctx.orders:
        actual = run.actual_seconds
        if actual is None:
            verdict = "FAIL (did not complete)"
            all_pass = False
        else:
            drift = abs(actual - run.planned_seconds) / run.planned_seconds
            verdict = "PASS" if drift <= TOLERANCE else f"FAIL (drift {drift:.0%})"
            if drift > TOLERANCE:
                all_pass = False
        rows.append({
            "order": run.order_id, "role": run.role, "crew": run.crew,
            "planned": run.planned_seconds, "actual": actual,
            "tokens": run.final_tokens, "files": run.final_files,
            "verdict": verdict,
        })

    ctx.coverage.setdefault("escalation_shown", False)
    ctx.coverage.setdefault("review_shown", False)
    ctx.coverage["all_orders_complete"] = all(
        o.actual_seconds is not None for o in ctx.orders)
    ctx.coverage["voyage_progress"] = True
    ctx.coverage["running_metrics"] = any(o.final_tokens > 0 for o in ctx.orders)
    if not ctx.coverage["all_orders_complete"]:
        all_pass = False
    return all_pass, rows


def write_report(ctx: DemoContext, passed: bool, rows: List[dict],
                 interrupted: bool) -> Path:
    reports_dir = ctx.mso / "reports" / "demo"
    reports_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    path = reports_dir / f"DEMO-PVT-{stamp}.md"

    lines = [
        f"# Squad Monitor PVT report — {ctx.voyage_id}",
        "",
        f"- **Date:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"- **Result:** {'PASS' if passed else 'FAIL'}"
        + (" (interrupted)" if interrupted else ""),
        f"- **Crews:** 3 simulated · **Orders:** {len(ctx.orders)} "
        f"(2× 20s, 2× 40s, 2× 60s, scale ×{ctx.time_scale:g})",
        f"- **Simulated spend:** ${ctx.demo_spend():.2f} "
        f"(synthetic — no real tokens were used)",
        "",
        "## Order timings",
        "",
        "| Order | Role | Crew | Planned | Actual | Tokens | Files | Verdict |",
        "|---|---|---|---|---|---|---|---|",
    ]
    for r in rows:
        actual = f"{r['actual']:.1f}s" if r["actual"] is not None else "—"
        lines.append(
            f"| {r['order']} | {r['role']} | {r['crew']} | "
            f"{r['planned']:.0f}s | {actual} | {r['tokens']:,} | "
            f"{r['files']} | {r['verdict']} |")

    lines += ["", "## Dashboard coverage", ""]
    labels = {
        "all_orders_complete": "All 6 orders reached COMPLETE",
        "voyage_progress": "Voyage progress bar 0/6 → 6/6",
        "running_metrics": "RUNNING metrics (iter, turns, files, tokens, ETA)",
        "escalation_shown": "ESCALATIONS block appeared and resolved",
        "review_shown": "PENDING REVIEW block appeared and cleared",
    }
    for key, label in labels.items():
        mark = "x" if ctx.coverage.get(key) else " "
        lines.append(f"- [{mark}] {label}")

    sec = ctx.findings.get("security") or {}
    lines += ["", "## Security review (real — OWASP pattern scan)", ""]
    if sec.get("error"):
        lines.append(f"_{sec['error']}_")
    else:
        lines.append(f"Scanned **{sec.get('files_scanned', 0)}** Python files — "
                     f"**{sec.get('total', 0)}** pattern match(es).")
        if sec.get("by_severity"):
            lines.append("")
            lines.append("| Severity | Count |")
            lines.append("|---|---|")
            for sev, count in sorted(sec["by_severity"].items()):
                lines.append(f"| {sev} | {count} |")
        for t in sec.get("top", []):
            lines.append(f"- {t['name']} ({t['severity']}) — {t['count']}× "
                         f"(e.g. `{t['file']}:{t['line']}`)")
        lines.append("")
        lines.append("> Pattern matches are leads, not verdicts — triage with "
                     "`mso security scan` / `mso security review`.")

    backlog = ctx.findings.get("backlog") or {}
    lines += ["", "## Outstanding backlog (real)", ""]
    if not backlog:
        lines.append("All queues empty.")
    else:
        for queue, info in backlog.items():
            lines.append(f"- **{queue}**: {info['count']} pending")
            for item in info["oldest"]:
                lines.append(f"  - {item['id']} — {item['title']} "
                             f"(age {item['age_days']}d)")

    activity = ctx.findings.get("activity") or {}
    lines += ["", "## Last fleet activity (real)", ""]
    recent = activity.get("recent_completions") or []
    lines.append("Recent completions: " + (", ".join(recent) if recent else "none."))
    for event in activity.get("lifecycle_tail", []):
        lines.append(f"- `{event}`")

    lines += ["", "## Recommended tasks", ""]
    for rec in ctx.findings.get("recommendations", []):
        lines.append(f"- {rec}")

    lines += ["", "---", "_Generated by `mso demo` — all demo artefacts were "
              "removed after this run; this report is the only thing left behind._"]

    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


# ---------------------------------------------------------------------------
# Cleanup
# ---------------------------------------------------------------------------

def cleanup(ctx: DemoContext, keep: bool = False) -> int:
    """Remove every demo artefact; restore pre-demo crew state. Returns count removed."""
    removed = 0
    if not keep:
        for path in ctx.created_paths:
            try:
                if path.exists():
                    path.unlink()
                    removed += 1
            except OSError:
                pass

    # Restore crew files byte-for-byte (even with --keep: crew slots are live
    # operational state, not demo artefacts).
    for path, original in ctx.crew_backups.items():
        try:
            if original is None:
                if path.exists():
                    path.unlink()
            else:
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(original)
        except OSError:
            pass

    _write_lifecycle("DEMO", f"PVT demo finished — {ctx.voyage_id} "
                             f"({removed} demo artefact(s) removed)")
    return removed


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def run_demo(headless: bool = False, time_scale: float = 1.0,
             keep: bool = False) -> int:
    """Run the dashboard PVT. Returns process exit code (0 = PASS)."""
    from maestro.core import fleet_monitor as fm

    mso = get_artefact_root()
    refusal = check_fleet_idle(mso)
    if refusal:
        print(f"\n  mso demo: refusing to run — {refusal}\n")
        return 1

    ctx = DemoContext(mso=mso, time_scale=time_scale)

    pre_demo_lifecycle = fm.get_lifecycle_log(8)

    # The demo must never page the bridge (Slack) about its synthetic
    # escalation — disable the notifier for the duration.
    original_notifier = fm._get_bridge_notifier
    fm._get_bridge_notifier = lambda: None

    backup_crew_state(ctx)
    create_demo_artefacts(ctx)

    print(f"\n  Squad Monitor PVT — {ctx.voyage_id}")
    print(f"  6 demo orders (2x20s 2x40s 2x60s, scale x{time_scale:g}) "
          "across 3 simulated crews. No tokens are spent.")
    if not headless:
        print("  The live dashboard takes over this terminal; "
              "Ctrl+C aborts and cleans up.\n")
    time.sleep(0 if headless else min(2.0, ctx.scaled(2.0)))

    threads = [threading.Thread(target=_crew_thread, args=(ctx, slot), daemon=True)
               for slot in DEMO_PLAN]
    threads.append(threading.Thread(target=_events_thread, args=(ctx,), daemon=True))

    ctx.t0 = time.monotonic()
    for t in threads:
        t.start()

    interrupted = False
    try:
        if headless:
            # Gather real findings while the sim runs
            gather_security_findings(ctx)
            gather_backlog_review(ctx)
            gather_last_activity(ctx, pre_demo_lifecycle)
            for t in threads:
                while t.is_alive():
                    t.join(timeout=0.5)
        else:
            from rich.console import Console
            from rich.live import Live
            from maestro.core.dashboard import render_dashboard

            console = Console()
            width = max(64, console.width - 2)
            settings = {"maxCrews": 3}

            def frame():
                state = fm.build_dashboard_state(settings, refresh_seconds=1)
                # Demo always demonstrates the API-billing visuals, scoped to
                # demo-order spend only (never the workspace's real history).
                state.billing_mode = "api"
                state.spend_usd = ctx.demo_spend()
                state.budget_usd = DEMO_BUDGET_USD
                return render_dashboard(state, width=width)

            findings_done = False
            with Live(frame(), console=console, refresh_per_second=2,
                      screen=True) as live:
                while any(t.is_alive() for t in threads):
                    time.sleep(max(0.25, ctx.scaled(1.0)))
                    live.update(frame())
                    if not findings_done:
                        # Cheap local gathering, once, mid-run
                        gather_security_findings(ctx)
                        gather_backlog_review(ctx)
                        gather_last_activity(ctx, pre_demo_lifecycle)
                        findings_done = True
                # Hold the final frame briefly so 6/6 + all-done is visible
                live.update(frame())
                time.sleep(min(3.0, ctx.scaled(3.0)))
            if not findings_done:
                gather_security_findings(ctx)
                gather_backlog_review(ctx)
                gather_last_activity(ctx, pre_demo_lifecycle)
    except KeyboardInterrupt:
        interrupted = True
        ctx.stop.set()
        for t in threads:
            t.join(timeout=2)
    finally:
        fm._get_bridge_notifier = original_notifier
        gather_recommendations(ctx)
        passed, rows = evaluate_pvt(ctx)
        report_path = write_report(ctx, passed and not interrupted, rows,
                                   interrupted)
        removed = cleanup(ctx, keep=keep)

    # Console summary (printed after the Live alt buffer exits)
    verdict = "PASS" if (passed and not interrupted) else (
        "ABORTED" if interrupted else "FAIL")
    print(f"\n  PVT {verdict} — {ctx.voyage_id}")
    for r in rows:
        actual = f"{r['actual']:.1f}s" if r["actual"] is not None else "—"
        print(f"    crew{r['crew']}  {r['order']:<22} {r['role']:<4} "
              f"planned {r['planned']:>5.0f}s  actual {actual:>7}  {r['verdict']}")
    sec = ctx.findings.get("security") or {}
    if not sec.get("error"):
        print(f"    security scan: {sec.get('total', 0)} match(es) in "
              f"{sec.get('files_scanned', 0)} files")
    backlog = ctx.findings.get("backlog") or {}
    pending = sum(v["count"] for v in backlog.values()) if backlog else 0
    print(f"    outstanding backlog: {pending} pending item(s)")
    print(f"    cleanup: {removed} demo artefact(s) removed"
          + (" (--keep: artefacts retained)" if keep else ""))
    print(f"\n  Full report: {report_path}\n")
    return 0 if (passed and not interrupted) else 1
