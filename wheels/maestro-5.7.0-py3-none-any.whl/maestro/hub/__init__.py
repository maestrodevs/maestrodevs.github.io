# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Maestro Hub — enterprise multi-workspace dashboard server."""

from __future__ import annotations

import maestro

__version__ = maestro.__version__

__all__ = ["create_app", "WorkspacePoller"]


def create_app(*args, **kwargs):
    from maestro.hub.server import create_app as _ca
    return _ca(*args, **kwargs)
