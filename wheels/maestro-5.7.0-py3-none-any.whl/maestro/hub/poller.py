# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""WorkspacePoller — background thread that owns all workspace disk I/O.

Single background thread polls all registered workspaces on a fixed interval,
maintaining a thread-safe in-memory snapshot. Request handlers read the cached
snapshot without blocking on I/O.
"""

from __future__ import annotations

import threading
from typing import Dict, List, Optional

from maestro.hub.models import WorkspaceDetail, WorkspaceSummary


class WorkspacePoller:
    """Poll all registered workspaces and maintain a thread-safe snapshot cache."""

    def __init__(self, interval: float = 5.0) -> None:
        self.interval = interval
        self._cache: Dict[str, WorkspaceSummary] = {}
        self._detail_cache: Dict[str, WorkspaceDetail] = {}
        # BUG-MSO-2026-0467: the set of workspace ids the CURRENT poll pass
        # expects to scan (from the registry) vs. how many of those have
        # actually landed in the cache so far — the gap between the two is
        # what lets callers tell "still filling in" apart from "genuinely
        # nothing registered".
        self._known_ids: set[str] = set()
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._first_poll_done = threading.Event()
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        """Spawn the background poll thread (daemon so it dies with the process).

        The very first poll runs inside the thread, NOT synchronously here, so
        server startup is never blocked on workspace disk I/O. On a small/local
        store the first poll completes in well under the 2s grace below, so the
        snapshot is still populated before ``start()`` returns (keeps TestClient
        and fast request paths working). On a large or slow-mounted artefact
        store (e.g. Docker Desktop bind-mounts) the first cold scan can take
        minutes — there we return after the grace and serve immediately while
        the snapshot fills in on the thread (BUG-MSO-2026-0413: the synchronous
        initial fill blocked uvicorn from binding until the cold scan finished).
        """
        self._stop.clear()
        self._first_poll_done.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True, name="hub-poller")
        self._thread.start()
        # Brief, bounded wait — populate synchronously when cheap, never block
        # server startup on a slow/large store.
        self._first_poll_done.wait(timeout=2.0)

    def stop(self) -> None:
        """Signal the poll thread to stop and wait for it to exit."""
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=self.interval + 2)
            self._thread = None

    def snapshot(self) -> Dict[str, WorkspaceSummary]:
        """Return a thread-safe shallow copy of the current workspace cache."""
        with self._lock:
            return dict(self._cache)

    def summaries(self) -> List[WorkspaceSummary]:
        """Return a list of WorkspaceSummary objects from the current snapshot."""
        with self._lock:
            return list(self._cache.values())

    def detail(self, workspace_id: str) -> Optional[WorkspaceDetail]:
        """Return the cached WorkspaceDetail for one workspace, or None if unknown."""
        with self._lock:
            return self._detail_cache.get(workspace_id)

    def status(self) -> dict:
        """Report poller readiness, distinct from a genuinely empty fleet.

        BUG-MSO-2026-0467: before this, the ONLY signal available to a caller
        was ``summaries()`` — and an empty list meant three different things
        (poller hasn't scanned anything yet, poller finished and there truly
        are zero workspaces, or the caller can't reach the backend at all)
        with no way to tell them apart.

        ``state`` is derived SOLELY from whether the FIRST poll pass has
        finished — it latches to "ready" once and never returns to
        "initialising" for the life of the poller:
          - "initialising" — no poll pass has completed yet. This is the
            cold-start window the bug is about, and the only time an empty
            ``summaries()`` is ambiguous.
          - "ready" — at least one full pass has completed. From here on an
            empty list is trustworthy: it means the registry really is empty.
            Later passes may still be mid-flight, but the cache retains the
            previous pass's contents throughout, so there is no second
            ambiguous window to report.

        ``scanned``/``total`` are progress detail, NOT the basis of ``state``.
        They are most useful during the initialising window; afterwards they
        can legitimately disagree (a workspace registered after startup makes
        ``total`` grow before its own scan lands) while ``state`` stays
        "ready" — by design, because the cache is populated and callers can
        already trust it.
        """
        with self._lock:
            known = len(self._known_ids)
            scanned = len(self._cache)
        ready = self._first_poll_done.is_set()
        return {
            "state": "ready" if ready else "initialising",
            "ready": ready,
            "scanned": scanned,
            "total": known,
        }

    def is_ready(self) -> bool:
        """True once the first full poll pass has scanned every workspace."""
        return self._first_poll_done.is_set()

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _loop(self) -> None:
        # Do the first (cold) poll here, off the server-startup path, then
        # signal start() and run the wait-then-poll cycle.
        try:
            self._poll_once()
        finally:
            self._first_poll_done.set()
        while not self._stop.wait(self.interval):
            self._poll_once()

    def _poll_once(self) -> None:
        from maestro import registry
        from maestro.hub import aggregator
        from maestro.workspace import artefact_parent_for_entry, product_repo_for_entry

        projects = registry.list_projects()
        known_ids = set(projects.keys())
        with self._lock:
            self._known_ids = known_ids

        # BUG-MSO-2026-0467: assign each workspace into the cache AS SOON AS
        # it is scanned, instead of building the whole pass in local dicts
        # and swapping them in only once every registered workspace has been
        # read. On a large registry (200+ orders in one workspace) that final
        # swap could be tens of seconds away, during which a workspace already
        # scanned was invisible to /workspaces and /workspaces/{id} even
        # though /workspaces/{id}/crews (which reads live, bypassing this
        # cache entirely) could already see it — the exact inconsistency this
        # bug reports. Incremental assignment shrinks that window from
        # "whole pass" to "this one workspace's scan".
        for acronym, entry in projects.items():
            try:
                ws_root = artefact_parent_for_entry(entry)
                product_repo = product_repo_for_entry(entry)
                summary = aggregator.read_workspace_snapshot(ws_root, id=acronym)
                detail = aggregator.build_workspace_detail(
                    ws_root, acronym, product_repo=product_repo)
            except Exception:
                path = entry.get("path", "")
                summary = aggregator.offline_summary(acronym, path)
                detail = aggregator.offline_detail(acronym, path)
            with self._lock:
                self._cache[acronym] = summary
                self._detail_cache[acronym] = detail

        # Prune entries for workspaces no longer in the registry (removed /
        # deregistered since the last pass) — done once at the end of the
        # pass rather than per-item since removals are rare and unlike
        # additions carry no "invisible but live" risk.
        with self._lock:
            stale = set(self._cache) - known_ids
            for acronym in stale:
                self._cache.pop(acronym, None)
                self._detail_cache.pop(acronym, None)
