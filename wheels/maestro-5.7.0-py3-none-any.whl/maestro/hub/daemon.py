# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Hub daemon PID management (mirrors maestro/bridge.py pattern exactly).

The hub is a GLOBAL daemon (not per-workspace) — PID file at ~/.maestro/hub.pid.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import webbrowser
from pathlib import Path
from typing import Optional, Tuple

from maestro.launch.sandbox import spawn as _spawn
from maestro.workspace import get_maestro_home

DEFAULT_PORT = 3847


def _hub_pid_file() -> Path:
    """Global Hub PID file, resolved live so MAESTRO_HOME redirects it
    (BUG-MSO-2026-0387). Default ``~/.maestro/hub.pid``."""
    return get_maestro_home() / "hub.pid"


# ---------------------------------------------------------------------------
# Process-identity helpers (BUG-MSO-2026-0424)
#
# A bare PID is NOT a stable process identity — operating systems recycle PIDs,
# so after the hub dies uncleanly the recorded number can be reassigned to
# unrelated software. We therefore record the process CREATION TIME alongside
# the PID and treat a record as "our hub" only when a process with that PID
# exists AND its creation time matches. A recycled PID always has a later start
# time, so the check is decisive and needs no third-party dependency.
# ---------------------------------------------------------------------------

def _process_create_time(pid: int) -> Optional[int]:
    """Return an opaque, stable process-creation-time token for *pid*, or
    ``None`` if no such process exists (or the value cannot be determined).

    The token is only ever compared for equality against another token
    produced by this same function, so its units/epoch are irrelevant — only
    that it is stable for the life of one process and differs for a recycled
    PID. Windows uses ``GetProcessTimes`` (100 ns ticks since 1601); POSIX
    reads ``/proc/<pid>/stat`` field 22 (starttime in clock ticks); systems
    without procfs (e.g. macOS) fall back to ``psutil`` if present.
    """
    if not pid or pid <= 0:
        return None
    try:
        if os.name == "nt":
            import ctypes
            from ctypes import wintypes
            PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            kernel32 = ctypes.windll.kernel32
            handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
            if not handle:
                return None
            try:
                creation = wintypes.FILETIME()
                exited = wintypes.FILETIME()
                kern = wintypes.FILETIME()
                user = wintypes.FILETIME()
                ok = kernel32.GetProcessTimes(
                    handle,
                    ctypes.byref(creation),
                    ctypes.byref(exited),
                    ctypes.byref(kern),
                    ctypes.byref(user),
                )
                if not ok:
                    return None
                return (creation.dwHighDateTime << 32) | creation.dwLowDateTime
            finally:
                kernel32.CloseHandle(handle)
        else:
            try:
                with open(f"/proc/{pid}/stat", "r", encoding="utf-8") as fh:
                    data = fh.read()
                # comm (field 2) may itself contain spaces/parens; it is wrapped
                # in parens, so split on the text AFTER the final ')'. In that
                # tail, field indices are: [0]=state (overall field 3) …
                # starttime is overall field 22 → tail index 19.
                tail = data[data.rfind(")") + 2:].split()
                return int(tail[19])
            except (FileNotFoundError, ProcessLookupError, OSError, ValueError, IndexError):
                try:
                    import psutil  # type: ignore
                    return int(psutil.Process(pid).create_time() * 1_000_000)
                except Exception:
                    return None
    except (OSError, ValueError):
        return None


def _read_record(pid_file: Path) -> Optional[Tuple[int, Optional[int]]]:
    """Read the hub PID record → ``(pid, recorded_create_time)`` or ``None``.

    Accepts both the current JSON form ``{"pid": N, "createTime": T}`` and the
    legacy bare-integer form (``recorded_create_time`` is then ``None``, which
    forces the identity check to fail — the safe outcome for an un-verifiable
    record).
    """
    if not pid_file.exists():
        return None
    try:
        raw = pid_file.read_text(encoding="utf-8").strip()
    except OSError:
        return None
    if not raw:
        return None
    try:
        obj = json.loads(raw)
        if isinstance(obj, dict):
            pid = int(obj.get("pid", 0))
            ct = obj.get("createTime")
            return (pid, int(ct) if ct is not None else None)
    except (ValueError, TypeError):
        pass
    # Legacy bare-integer form → PID with no recorded identity.
    try:
        return (int(raw), None)
    except ValueError:
        return None


def _write_record(pid_file: Path, pid: int, create_time: Optional[int]) -> None:
    pid_file.parent.mkdir(parents=True, exist_ok=True)
    pid_file.write_text(
        json.dumps({"pid": pid, "createTime": create_time}),
        encoding="utf-8",
    )


def _read_pid(pid_file: Path) -> Optional[int]:
    """Backwards-compatible PID accessor (identity NOT verified)."""
    rec = _read_record(pid_file)
    return rec[0] if rec else None


def _is_process_alive(pid: int) -> bool:
    """Bare liveness — does SOME process hold *pid*? Kept for callers that only
    need existence; the hub lifecycle uses :func:`_is_hub_running` instead,
    which also verifies process identity."""
    return _process_create_time(pid) is not None


def _is_hub_running(pid_file: Path) -> Tuple[bool, Optional[int]]:
    """Identity-verified hub liveness.

    Returns ``(running, pid)``. ``running`` is ``True`` only when the recorded
    PID belongs to a live process whose creation time matches the recorded
    identity. A recycled PID (same number, different — later — process) or a
    legacy record with no recorded identity is classified as NOT running, so no
    termination signal is ever sent to an unrelated process.
    """
    rec = _read_record(pid_file)
    if rec is None:
        return (False, None)
    pid, recorded_ct = rec
    if not pid or pid <= 0 or recorded_ct is None:
        return (False, pid or None)
    current_ct = _process_create_time(pid)
    if current_ct is None or current_ct != recorded_ct:
        return (False, pid)
    return (True, pid)


# ---------------------------------------------------------------------------
# Dep check
# ---------------------------------------------------------------------------

def _ensure_hub_deps() -> None:
    try:
        import fastapi  # noqa: F401
        import uvicorn  # noqa: F401
    except ImportError:
        print(
            "[Hub] FastAPI/uvicorn not installed.\n"
            "      Install the hub extra:  pip install 'maestro[hub]'",
            file=sys.stderr,
        )
        sys.exit(1)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def start_hub(port: int = DEFAULT_PORT, open_browser: bool = False, force: bool = False) -> None:
    hub_pid = _hub_pid_file()
    running, existing_pid = _is_hub_running(hub_pid)
    if running and not force:
        print(f"[Hub] Already running (PID: {existing_pid}) on http://127.0.0.1:{port}")
        if open_browser:
            webbrowser.open(f"http://127.0.0.1:{port}")
        return
    if not running and hub_pid.exists():
        # Stale / recycled-PID / legacy record — clear it and start clean.
        # NB: no signal is ever sent here; the old PID may now belong to
        # unrelated software (BUG-MSO-2026-0424).
        hub_pid.unlink()

    _ensure_hub_deps()

    cmd = [sys.executable, "-m", "maestro.hub", "--port", str(port)]
    hub_pid.parent.mkdir(parents=True, exist_ok=True)

    if os.name == "nt":
        DETACHED_PROCESS = 0x00000008
        CREATE_NEW_PROCESS_GROUP = 0x00000200
        flags = DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
        proc = _spawn(
            cmd,
            identity="hub",
            creationflags=flags,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    else:
        proc = _spawn(
            cmd,
            identity="hub",
            start_new_session=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

    _write_record(hub_pid, proc.pid, _process_create_time(proc.pid))
    print(f"[Hub] Started on http://127.0.0.1:{port} (PID {proc.pid})")
    if open_browser:
        webbrowser.open(f"http://127.0.0.1:{port}")


def stop_hub() -> None:
    hub_pid = _hub_pid_file()
    running, pid = _is_hub_running(hub_pid)
    if not running:
        # Not our hub (dead, recycled PID, or legacy record). Send NO signal —
        # the recorded PID may now belong to unrelated software
        # (BUG-MSO-2026-0424) — and always clear the stale record.
        print("[Hub] Not running")
        if hub_pid.exists():
            hub_pid.unlink()
        return

    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/PID", str(pid)], capture_output=True, timeout=10)
        else:
            os.kill(pid, 15)  # SIGTERM
        print(f"[Hub] Stop signal sent (PID: {pid})")
    except Exception as exc:
        print(f"[Hub] Failed to stop: {exc}", file=sys.stderr)

    import time
    time.sleep(1)
    # Remove the record once the identity-verified hub is gone.
    if hub_pid.exists() and not _is_hub_running(hub_pid)[0]:
        hub_pid.unlink()


def hub_status() -> dict:
    running, pid = _is_hub_running(_hub_pid_file())
    return {"running": running, "pid": pid if running else None, "port": DEFAULT_PORT}


def print_status() -> None:
    s = hub_status()
    print("\n  MAESTRO HUB — STATUS")
    print("  " + "-" * 40)
    if s["running"]:
        print(f"  Status:  RUNNING (PID: {s['pid']})")
        print(f"  URL:     http://127.0.0.1:{s['port']}")
    else:
        print("  Status:  STOPPED")
    print("  " + "-" * 40)
    print()
