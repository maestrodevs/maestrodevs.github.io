# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Hub review module — parameterised review action handlers.

Mirrors the logic in maestro/review.py but:
  - accepts explicit workspace_path arguments (no find_workspace() call)
  - uses atomic writes (temp-file + rename) for all JSON mutations
  - raises exceptions instead of calling sys.exit() (caller maps to HTTP status)

Exception contract:
  FileNotFoundError  → 404 (order not in review queue for this workspace)
  ValueError         → 409 (order exists but is not in NAV_REVIEW_PENDING state)
"""

from __future__ import annotations

import json
import os
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Optional

from maestro.core.lifecycle_log import sanitize_lifecycle_message  # BUG-MSO-2026-0474: one-line-per-event guard


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _get_mso_dir(workspace_path: Path) -> Path:
    """Resolve ``.mso`` under *workspace_path*.

    *workspace_path* is expected to already be the artefact root's parent —
    callers (``hub/server.py``'s ``_iter_workspaces``/``_find_order_workspace``)
    resolve the registry v2 entry (``workspace.artefact_parent_for_entry``,
    honouring ``artefactMode: solo|shared``) before reaching this module, so
    the review flow reads/writes the artefact repo's queue in solo mode
    without this module needing any registry awareness itself
    (FTR-MSO-2026-0369).
    """
    from maestro.workspace import resolve_artefact_dir
    return resolve_artefact_dir(workspace_path)


def _write_atomic(path: Path, data: dict) -> None:
    """Write JSON to a temp file then rename — avoids partial writes."""
    content = json.dumps(data, indent=2)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(content, encoding="utf-8")
    tmp.replace(path)


def _write_lifecycle(mso: Path, event_type: str, message: str) -> None:
    """BUG-MSO-2026-0474: *message* is sanitized to a single physical line —
    operator-supplied free text (revise/reject notes) used to be written
    verbatim, breaking lifecycle.log's one-line-per-event contract."""
    log_dir = mso / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / "lifecycle.log"
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"{timestamp} | {event_type:<10} | {sanitize_lifecycle_message(message)}\n"
    try:
        with open(str(log_file), "a", encoding="utf-8") as f:
            f.write(line)
    except OSError:
        pass


def _reviewer() -> str:
    """Best-effort reviewer identity (git user or env fallback)."""
    try:
        result = subprocess.run(
            ["git", "config", "user.email"],
            capture_output=True, text=True, timeout=5,
        )
        email = result.stdout.strip()
        if email:
            return email
    except Exception:
        pass
    return os.environ.get("USER", os.environ.get("USERNAME", "hub-api"))


def _load_review_order(review_dir: Path, order_id: str) -> tuple[Path, dict]:
    """Load order from review queue; raise FileNotFoundError if absent."""
    order_file = review_dir / f"{order_id}.json"
    if not order_file.exists():
        raise FileNotFoundError(f"Order {order_id!r} not found in review queue")
    data = json.loads(order_file.read_text(encoding="utf-8"))
    return order_file, data


def _assert_nav_review_pending(order_id: str, data: dict) -> None:
    """Raise ValueError if order is not in an actionable review state."""
    status = (data.get("status") or "").upper()
    if status and status != "NAV_REVIEW_PENDING":
        raise ValueError(
            f"Order {order_id!r} has status {status!r}; expected NAV_REVIEW_PENDING"
        )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def find_review_pending_orders(workspace_path: Path) -> list[dict]:
    """Return all orders from queues/review/ (NAV_REVIEW_PENDING and unlabelled).

    Each dict contains the raw order JSON.  Callers use workspace_id from the
    outer registry loop — this function does not add it.
    """
    mso = _get_mso_dir(workspace_path)
    review_dir = mso / "queues" / "review"
    if not review_dir.exists():
        return []

    results: list[dict] = []
    for f in sorted(review_dir.glob("*.json")):
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
            results.append(data)
        except Exception:
            pass
    return results


def get_plan_content(workspace_path: Path, order_id: str) -> tuple[Optional[str], bool, Optional[dict]]:
    """Return (plan_markdown, has_plan_file, order_data).

    plan_markdown is the plan file content when has_plan_file=True, or the
    order's description field when False.  Returns (None, False, None) when
    the order is not found in the review queue.
    """
    mso = _get_mso_dir(workspace_path)
    review_dir = mso / "queues" / "review"
    order_file = review_dir / f"{order_id}.json"

    if not order_file.exists():
        return None, False, None

    try:
        data = json.loads(order_file.read_text(encoding="utf-8"))
    except Exception:
        return None, False, None

    plan_file = mso / "plans" / f"PLAN-{order_id}.md"
    if plan_file.exists():
        try:
            return plan_file.read_text(encoding="utf-8"), True, data
        except Exception:
            pass

    # Fallback: order description
    return (data.get("description") or ""), False, data


def approve_order(workspace_path: Path, order_id: str) -> dict:
    """Approve a NAV_REVIEW_PENDING order — mirrors mso review approve.

    Intra-order: sets status→PENDING, moves to queues/orders/.
    Plan-approval-only: sets status→COMPLETE, archives to orders/complete/.

    Returns {"new_status": <str>}.
    Raises FileNotFoundError (404) or ValueError (409).
    """
    mso = _get_mso_dir(workspace_path)
    review_dir = mso / "queues" / "review"
    order_file, data = _load_review_order(review_dir, order_id)
    _assert_nav_review_pending(order_id, data)

    now = datetime.now().isoformat()
    reviewer = _reviewer()
    data["reviewedAt"] = now
    data["reviewedBy"] = reviewer
    data.pop("navReviewPausedAt", None)

    if data.get("planApprovalOnly"):
        voyage_id = data.get("voyageId", "")
        data["status"] = "COMPLETE"
        data["completedAt"] = now
        data.pop("planApprovalOnly", None)
        archive_dir = mso / "orders" / "complete"
        archive_dir.mkdir(parents=True, exist_ok=True)
        dest = archive_dir / order_file.name
        _write_atomic(dest, data)
        order_file.unlink()

        # BUG-MSO-2026-0239 / BUG-MSO-2026-0476: mirrors the CLI path
        # (maestro/review.py) — this Hub path used to skip promotion
        # entirely, so a plan approved through the Hub never released its
        # pre-filed dependents. Shares the lookup with the CLI so the two
        # surfaces cannot drift out of parity again.
        from maestro.core.plan_dependents import find_filed_dependents, promote_proposed_dependents
        promoted = promote_proposed_dependents(mso, order_id, voyage_id, write_json=_write_atomic)
        filed = find_filed_dependents(mso, order_id, voyage_id)
        if promoted:
            promo_msg = f"promoted {promoted} build order(s) to PENDING"
        elif filed:
            promo_msg = f"{len(filed)} dependent(s) already filed, none PROPOSED to promote"
        else:
            promo_msg = "no PROPOSED dependents found to promote"
        _write_lifecycle(
            mso, "NAV_REVIEW_APPROVED",
            f"{order_id} plan approved by {reviewer} -> COMPLETE; {promo_msg} (hub)",
        )

        result = {"new_status": "COMPLETE", "dependents_promoted": promoted}
        if not filed:
            # BUG-MSO-2026-0476: nothing was ever filed to unblock this plan
            # — surfaced in the API response for the Hub UI, and always in
            # the lifecycle log regardless of whether the UI reads it.
            warning = (
                f"no dependent orders exist for {voyage_id or order_id} — "
                "build orders (FTR/BLD) must be filed before this voyage can finish"
            )
            _write_lifecycle(mso, "PLAN_ORPHANED", f"{order_id}: {warning}")
            result["warning"] = warning
        return result

    next_role = data.get("targetRole", "BLD")
    data["status"] = "PENDING"
    # FTR-MSO-2026-0427: name the transition that was gated, then clear the
    # markers so the released order doesn't carry a stale gate label onward.
    gate = data.get("reviewGate") or ""
    for gate_field in ("reviewGate", "reviewGateFrom", "reviewGateTo"):
        data.pop(gate_field, None)
    orders_dir = mso / "queues" / "orders"
    orders_dir.mkdir(parents=True, exist_ok=True)
    dest = orders_dir / order_file.name
    _write_atomic(dest, data)
    order_file.unlink()
    _write_lifecycle(
        mso, "NAV_REVIEW_APPROVED",
        f"{order_id} approved by {reviewer}{f' at gate {gate}' if gate else ''} "
        f"-> {next_role} (hub)",
    )
    return {"new_status": "PENDING"}


def revise_order(workspace_path: Path, order_id: str, feedback: str) -> dict:
    """Request revision — writes feedback, sets REVISION_REQUESTED, stays in review queue.

    Returns {"new_status": "REVISION_REQUESTED"}.
    Raises FileNotFoundError (404) or ValueError (409).
    """
    mso = _get_mso_dir(workspace_path)
    review_dir = mso / "queues" / "review"
    order_file, data = _load_review_order(review_dir, order_id)
    _assert_nav_review_pending(order_id, data)

    now = datetime.now().isoformat()
    reviewer = _reviewer()
    data["status"] = "REVISION_REQUESTED"
    data["reviewFeedback"] = feedback
    data["reviewedAt"] = now
    data["reviewedBy"] = reviewer

    _write_atomic(order_file, data)
    # BUG-MSO-2026-0474: pass the full feedback through — _write_lifecycle's
    # shared sanitizer now handles both newline-collapsing and length
    # truncation (with a pointer to the order JSON), so a hardcoded [:80]
    # slice here would only hide the newline problem, not fix it.
    _write_lifecycle(
        mso, "NAV_REVIEW_REVISED",
        f"{order_id} revision requested by {reviewer}: {feedback} (hub)",
    )
    return {"new_status": "REVISION_REQUESTED"}


def reject_order(workspace_path: Path, order_id: str, reason: str) -> dict:
    """Reject an order — marks REJECTED, moves to queues/review/rejected/.

    Returns {"new_status": "REJECTED"}.
    Raises FileNotFoundError (404) or ValueError (409).
    """
    mso = _get_mso_dir(workspace_path)
    review_dir = mso / "queues" / "review"
    order_file, data = _load_review_order(review_dir, order_id)
    _assert_nav_review_pending(order_id, data)

    now = datetime.now().isoformat()
    reviewer = _reviewer()
    data["status"] = "REJECTED"
    data["rejectionReason"] = reason
    data["reviewedAt"] = now
    data["reviewedBy"] = reviewer

    rejected_dir = review_dir / "rejected"
    rejected_dir.mkdir(parents=True, exist_ok=True)
    dest = rejected_dir / order_file.name
    _write_atomic(dest, data)
    order_file.unlink()
    # BUG-MSO-2026-0474: see revise_order() above — sanitization now happens
    # once, at the _write_lifecycle boundary, instead of an ad-hoc slice here.
    _write_lifecycle(
        mso, "NAV_REVIEW_REJECTED",
        f"{order_id} rejected by {reviewer}: {reason} (hub)",
    )
    return {"new_status": "REJECTED"}
