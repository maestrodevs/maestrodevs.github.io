# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Per-workspace lifecycle log tailer for the Maestro Hub WebSocket stream."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Optional

_ORDER_RE = re.compile(r"\b([A-Z]{2,5}-[A-Z]{2,5}-\d{4}-\d+)\b")
_ROLE_RE = re.compile(r"\b(PLN|BLD|TST|DOC|SEC|REL)\b")
_CREW_RE = re.compile(r"[Cc]rew\s*(\d+)")
_SUBTYPE_RE = re.compile(r"subtype=(\S+)")


def _parse_event_type(line: str) -> str:
    """Extract event_type from 'YYYY-MM-DD HH:MM:SS | EVENT_TYPE | message...'"""
    parts = line.split("|")
    if len(parts) >= 2:
        return parts[1].strip()
    return ""


def _parse_timestamp(line: str) -> str:
    """Extract timestamp from log line."""
    parts = line.split("|")
    if parts:
        return parts[0].strip()
    return ""


def _parse_message(line: str) -> str:
    """Extract the message body from 'timestamp | EVENT_TYPE | message...'.

    The message may itself contain '|', so re-join everything after the 2nd pipe.
    """
    parts = line.split("|")
    if len(parts) >= 3:
        return "|".join(parts[2:]).strip()
    return line.strip()


def _parse_order_id(line: str) -> Optional[str]:
    m = _ORDER_RE.search(line)
    return m.group(1) if m else None


def _parse_role(line: str) -> Optional[str]:
    # Search the message body only, so the EVENT_TYPE column never matches.
    m = _ROLE_RE.search(_parse_message(line))
    return m.group(1) if m else None


def _parse_crew_slot(line: str) -> Optional[int]:
    m = _CREW_RE.search(_parse_message(line))
    return int(m.group(1)) if m else None


def _parse_subtype(line: str) -> Optional[str]:
    m = _SUBTYPE_RE.search(line)
    return m.group(1) if m else None


class LifecycleTail:
    """Tails a workspace's lifecycle.log, tracking read position in memory."""

    def __init__(self, workspace_path: Path) -> None:
        self._ws_root = workspace_path
        self._log_path: Optional[Path] = None
        self._offset: int = 0

    def _get_log(self) -> Path:
        if self._log_path is None:
            from maestro.workspace import resolve_artefact_dir
            mso = resolve_artefact_dir(self._ws_root)
            self._log_path = mso / "logs" / "lifecycle.log"
        return self._log_path

    def read_last_n(self, n: int = 20) -> list[str]:
        """Return up to the last n non-empty lines from lifecycle.log."""
        log = self._get_log()
        if not log.exists():
            return []
        try:
            text = log.read_text(encoding="utf-8")
            lines = [line for line in text.splitlines() if line.strip()]
            return lines[-n:]
        except Exception:
            return []

    def read_new_lines(self) -> list[str]:
        """Return lines added since last call and advance the internal byte offset."""
        log = self._get_log()
        if not log.exists():
            return []
        try:
            size = log.stat().st_size
            if size <= self._offset:
                return []
            with log.open("rb") as f:
                f.seek(self._offset)
                data = f.read()
            self._offset += len(data)
            text = data.decode("utf-8", errors="replace")
            return [line for line in text.splitlines() if line.strip()]
        except Exception:
            return []

    def seek_to_end(self) -> None:
        """Move offset to current end of file so read_new_lines skips existing content."""
        log = self._get_log()
        if not log.exists():
            self._offset = 0
            return
        try:
            self._offset = log.stat().st_size
        except Exception:
            self._offset = 0
