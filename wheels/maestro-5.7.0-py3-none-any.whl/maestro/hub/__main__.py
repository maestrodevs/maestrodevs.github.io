# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Entry point: python -m maestro.hub [--port N]"""

import argparse
import uvicorn

from maestro.hub.server import create_app


def main() -> None:
    ap = argparse.ArgumentParser(description="Maestro Hub server")
    ap.add_argument("--port", type=int, default=3847, help="Port to bind (default 3847)")
    args = ap.parse_args()
    uvicorn.run(create_app(), host="127.0.0.1", port=args.port, log_level="warning")


if __name__ == "__main__":
    main()
