# Maestro — Governance Trust Boundary & CI Backstop

> Audience: operators and security/compliance owners enabling Maestro **governed mode**. This page
> explains, honestly, what governance enforces on a developer's machine versus in CI, and how to
> wire the CI backstop (`mso policy verify --ci`) into your pipeline.

## Contents

- [The one thing to understand](#the-one-thing-to-understand)
- [Client vs CI: who enforces what](#client-vs-ci-who-enforces-what)
- [Limits of the CI backstop (best-effort, not bypass-proof)](#limits-of-the-ci-backstop-best-effort-not-bypass-proof)
- [`mso policy verify --ci`](#mso-policy-verify---ci)
- [Drop-in GitHub Actions snippet](#drop-in-github-actions-snippet)
- [What the backstop scans (and what it skips)](#what-the-backstop-scans-and-what-it-skips)
- [Exit codes](#exit-codes)
- [Tuning: includes, excludes, warn-only](#tuning-includes-excludes-warn-only)
- [FAQ](#faq)
- [See also](#see-also)

## The one thing to understand

**On a developer-owned machine you cannot achieve absolute prevention — and any tool that claims
otherwise is overselling.** A determined engineer who owns the interpreter can always edit the code
that reads the policy, or run their agent with no hooks at all. What governance *can* do is make
that tampering **evident**, protect the crew from its own mistakes, and — most importantly — put the
binding enforcement point somewhere the engineer does **not** control: **your CI**.

Maestro's honest model:

> **Client = safety + evidence. CI = enforcement.**

The client-side pretool hook stops the *accidental* and *prompt-injected* destructive action and
records what happened. `mso policy verify --ci`, running on infrastructure the engineer does not
own, **re-checks the merged diff** against the same signed packs: a rule bypassed locally is
evaluated again here, so an *obvious* violation still fails the merge. It is a best-effort content
scan, not a bypass-proof wall — see [Limits of the CI
backstop](#limits-of-the-ci-backstop-best-effort-not-bypass-proof) for exactly what that does and
does not buy you.

## Client vs CI: who enforces what

| Concern | Client-side hook | CI backstop (`mso policy verify --ci`) |
|---|---|---|
| Blocks an LLM crew's accidental `DROP DATABASE` before it runs | ✅ Yes | ✅ Re-checked on the diff |
| Stops a well-meaning local config relaxation | ✅ Org DENYs are precedence-protected | ✅ Same packs re-evaluated |
| Survives a developer disabling hooks / editing the package | ❌ No client control can | ✅ Runs off the developer's machine |
| Catches an *obvious/common* violation in the merged diff | ✅ Before it runs | ✅ Re-checked at merge time |
| Is a *bypass-proof* gate against a determined, obfuscating attacker | ❌ No | ❌ **No — see limits below** |

Run **both**. The client layer is the fast, in-loop safety net; the CI layer is the merge-time net a
compliance team can point to and say "policy was re-checked on every merge." Neither is a wall
against a determined insider — that is what branch protection, human review, and runtime controls are
for (next section).

## Limits of the CI backstop (best-effort, not bypass-proof)

**Read this before you treat a green `mso policy verify --ci` as a security guarantee.** It is the
single most important thing to understand about this feature, and we would rather under-promise it
than have you rely on it for something it cannot do.

The backstop scans the **textual content of a diff**. For each added line — and the aggregated added
block of each file — it asks "does this match a governed *deny* pattern?" That makes it a **reliable
catch for the obvious and common violations**:

- a plain `DROP DATABASE prod`, `TRUNCATE`, `DELETE FROM … ` without a `WHERE`,
- `rm -rf`, `terraform destroy`, `aws … delete-*`,
- and the **split-across-lines** and **header-collision** variants the evaluator specifically
  reconstructs (a `DROP \`-continued command, or a `DROP`\n`DATABASE prod` split — both are caught).

Those are exactly the actions a bypassed client-side hook would let slip, and catching them at merge
time is genuine, useful defense-in-depth. **That is what this backstop is for.**

### What it does *not* do

It is **not** an omniscient gate, and does not claim to be. Content scanning of a diff is *inherently
incomplete*. A determined attacker who wants to smuggle a destructive action past a regex can
obfuscate it without bound, and chasing every variant is unwinnable whack-a-mole that this tool
deliberately does not attempt:

- **Encoding** — `echo ZHJvcCBkYXRhYmFzZQ== | base64 -d | sh` (or hex, rot13, gzip).
- **Concatenation / interpolation** — `X="DRO"; Y="P DATABASE"; psql -c "$X$Y prod"`.
- **Indirection** — read the payload from a data file, an env var, or a remote URL and pipe it to a
  shell; call a wrapper script whose *name* is innocent.
- **Dynamic construction** — build the command with `eval` / `$(…)` / `printf` at runtime.

A green result means **"no obvious/common violation was found"**, *not* "this diff is safe". Do not
wire an approval or a compliance attestation to the exit code alone.

### Where the real guarantees live

Against a *determined* insider, the load-bearing controls are **not** this content scan — they are:

1. **Branch protection + mandatory human review.** A reviewer reads *intent*. An obfuscated payload
   (`base64 -d | sh` in a deploy script) is *more* suspicious to a human, not less. This is the
   primary control; the CI backstop assists it, it does not replace it.
2. **Runtime controls.** Least-privilege database/cloud credentials, network-egress limits, and —
   the strongest answer — running crews on **org-controlled infrastructure** stop the destructive
   action even if the text merged.
3. **Client-side hooks.** The fast in-loop safety net plus the tamper-evident record.

Think of `mso policy verify --ci` as **one honest layer** of that model — the automated merge-time
net for the common case — never as the wall that makes the others optional.

```bash
# Default: evaluate origin/main...HEAD in the current repo
mso policy verify --ci

# Explicit PR base
mso policy verify --ci --base origin/main

# Staged changes (handy in a pre-push hook)
mso policy verify --ci --staged

# A pre-computed diff from a file or stdin
mso policy verify --ci --diff-file changes.patch
git diff origin/main...HEAD | mso policy verify --ci --diff-file -

# Machine-readable report
mso policy verify --ci --json
```

> `mso policy verify` **without** `--ci` is a different, read-only command: it checks an Ed25519
> **signed bundle's** signature (Phase 2). `--ci` selects the diff-evaluator enforcement backstop
> described here. The two share the subcommand but do unrelated work.

Enforcement is **independent of whether the developer had governed mode switched on locally** — CI
does not trust the client's configuration. If the built-in packs cannot be integrity-verified
(tampered), the command fails closed (exit 2) rather than passing.

**Only added lines are evaluated.** Removed lines cannot execute, so they are never checked; the
backstop asks "what did this change try to *introduce*."

## Drop-in GitHub Actions snippet

Add this job to your workflow. It installs Maestro, fetches the base branch, and fails the build on
any violation:

```yaml
jobs:
  policy-verify:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0            # base...HEAD needs history for the merge-base
      - uses: actions/setup-python@v5
        with:
          python-version: "3.13"
      - run: pip install maestro-fleet
      - name: Governance backstop
        env:
          MAESTRO_SKIP_AUTH: "1"    # the backstop reads packs + diff; no dispatch licence needed
        run: |
          BASE="origin/${{ github.event.pull_request.base.ref || 'main' }}"
          git fetch --no-tags origin "${{ github.event.pull_request.base.ref || 'main' }}"
          mso policy verify --ci --base "$BASE"
```

If you vendor the Maestro repository, an equivalent **reusable composite action** ships at
`.github/actions/policy-verify` — reference it with
`uses: <org>/Maestro/.github/actions/policy-verify@<ref>` and pass `base`, `warn-only`, or
`extra-args` inputs. Maestro's own repository wires this action into
`.github/workflows/policy-verify.yml` as a live, tested example, alongside a self-check job that
feeds a known-bad diff (and the SEC-0400-01 header-collision exploit) and asserts the command
rejects both.

### Draft-PR CI economy

If you use Maestro's draft-voyage-PR pattern (`completion.voyagePr.draft`), guard the job so it does
not run on every per-role convergence push:

```yaml
    if: github.event_name != 'pull_request' || github.event.pull_request.draft == false
```

and add `ready_for_review` to your `pull_request` trigger `types`. CI then fires once, when the PR
is promoted at finalisation.

## What the backstop scans (and what it skips)

The evaluator treats each **added** line of the diff as a candidate command and each changed file's
added content as a candidate write, then asks the merged policy for a verdict.

Because documentation and the policy packs themselves legitimately *contain* the very strings the
deny-patterns look for (a doc showing an example command; a pack defining a regex), those
**authoring surfaces are excluded by default**:

```
*.md   docs/*   maestro/docs/*   maestro/governance/library/*
CHANGELOG   CHANGELOG.rst   LICENSE   LICENSE.txt   LICENSE.rst
```

The `LICENSE`/`CHANGELOG` entries are the **exact top-level filenames** (plus `*.md` covers
`CHANGELOG.md` / `LICENSE.md`). They are deliberately *not* the unanchored globs `LICENSE*` /
`CHANGELOG*` — because `fnmatch`'s `*` spans `/`, those would also skip an attacker-named subtree
like `LICENSES/deploy.sh` (the real SPDX/REUSE convention) or `CHANGELOG.d/run.sh`, silently
un-governing executable content (NEW-1, SEC-FTR-MSO-2026-0400). A file under such a path is scanned.

### Executable surfaces ARE governed by default (SEC-0400-03)

Earlier iterations of this backstop also excluded `.github/*` and `tests/*` by default. **They no
longer are** — a GitHub workflow step *executes* in CI, and a test module *runs* in the test job, so
they are exactly the surfaces an attacker would target. Blanket-excluding them was a real coverage
gap, so the default now **scans** them.

The trade-off: a repository whose own tests or workflows *legitimately* embed a trigger string (for
example a governance test fixture that asserts `DROP DATABASE` is caught, or a workflow that
demonstrates a bad command) will see those flagged. Handle that with a **targeted, documented**
`--exclude`, not by re-widening the default:

```bash
# Only because THIS repo's fixtures/workflows embed the trigger strings on purpose.
mso policy verify --ci --exclude 'tests/*' --exclude '.github/*'
```

Maestro's own dogfood workflow does exactly this (see `.github/workflows/policy-verify.yml`), with a
comment explaining that a consumer whose tests/workflows do **not** embed such strings should not
copy the exclusion. Prefer the narrowest exclude that removes the false positive — e.g.
`--exclude 'tests/fixtures/*'` rather than all of `tests/*`.

## Exit codes

| Code | Meaning |
|---|---|
| `0` | No violations (or `--warn-only`). |
| `1` | At least one governed-pack violation in the diff — **CI must fail**. |
| `2` | Operational error: bad diff source, git failure, tampered/unverifiable packs, **or a non-empty diff that did not parse cleanly** (fail-closed). |

### Fail-closed on an unparseable diff (SEC-0400-02)

An enforcement gate must never let a diff it *could not understand* read as a *clean* one. If a
changed, non-binary, non-deleted file yields no parseable hunk, if a hunk body does not reconcile
against its `@@` header, or if the diff contains an un-modelled structure (e.g. a combined-merge
`@@@` diff), the command exits **2** rather than 0. "I could not parse this" fails the build. Normal
`git diff base...HEAD` output (what a PR backstop evaluates) parses cleanly and is unaffected.

## Tuning: includes, excludes, warn-only

| Flag | Effect |
|---|---|
| `--exclude GLOB` | Skip paths matching GLOB (repeatable; **adds to** the defaults). |
| `--include GLOB` | Restrict evaluation to matching paths (repeatable). |
| `--no-default-excludes` | Drop the built-in doc/pack exclude set entirely (scan everything). |
| `--warn-only` | Report violations but exit `0` (roll-out / observe mode). |
| `--base REF` / `--head REF` | Set the `base...HEAD` comparison (defaults: `origin/main` / `HEAD`). |
| `--staged` | Evaluate `git diff --staged` instead of a branch diff. |
| `--diff-file PATH` | Read a pre-computed unified diff (`-` = stdin). |
| `--json` | Emit a machine-readable report. |

Typical roll-out: start with `--warn-only` so the team sees what would be blocked, then drop it to
make the gate binding. `--warn-only` is never silent: whenever it suppresses one or more violations
the command prints a distinct `ENFORCEMENT WAIVED` line to **stderr** (separate from the stdout/JSON
report), so a run that waived enforcement is always visible in the CI log even to a reviewer who only
reads the report.

## FAQ

**Does this replace the client-side hook?** No. The hook is your fast, in-loop safety net; the CI
backstop is the binding enforcement gate. Run both.

**Can a developer bypass the CI check?** Two honest answers. (1) They can edit your CI configuration
to skip the job — but that is a reviewable, auditable change in your pipeline, not a silent local
action, and since the backstop now scans `.github/*` by default a violation smuggled *into* a
workflow step is itself caught. (2) More importantly: they can leave the job running and still slip a
*deliberately obfuscated* payload past the content scan (encoding, string concatenation, indirection
— see [Limits of the CI backstop](#limits-of-the-ci-backstop-best-effort-not-bypass-proof)). The
backstop catches the obvious/common case, not a determined obfuscator. That is why it is one layer,
paired with human review and runtime controls — not a standalone gate.

**Will it flag example commands in my README?** Not by default — Markdown and docs are excluded.
Remove them from the exclude set (`--no-default-excludes`, or a narrower `--include`) if you want
prose policed too.

**Why did my test file get flagged?** Because `tests/*` is scanned by default now (SEC-0400-03). If
the match is a legitimate fixture, add a narrow `--exclude` for that path and note why — don't
re-widen the whole default.

**What about a truly determined insider?** See the honest limits above: no client control stops
someone who owns the interpreter. For hard prevention, the only real answer is running crews on
org-controlled infrastructure. The CI backstop is the pragmatic, defensible enforcement boundary
for developer-owned machines.

## See also

- `mso policy verify --help` — full flag reference.
- [ROLE-OVERLAYS.md](ROLE-OVERLAYS.md) — customising crew role behaviour.
- [ENTERPRISE-SETUP.md](ENTERPRISE-SETUP.md) — enabling enterprise-tier features.
