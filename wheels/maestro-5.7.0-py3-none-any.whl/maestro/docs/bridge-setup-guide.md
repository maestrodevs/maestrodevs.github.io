# Mobile Command Bridge — Setup Guide

This guide walks you through enabling the Maestro Bridge, which provides two-way communication between your laptop fleet and your mobile device via Slack.

## Prerequisites

- A Maestro workspace with `.mso/` configured
- A Slack workspace where you have admin permissions
- A GitHub account with a Personal Access Token (PAT)
- Python 3.10+ with the `maestro` package installed

---

## Step 1: Create a Slack App

1. Go to **https://api.slack.com/apps**
2. Click **Create New App** → **From scratch**
3. App Name: `Maestro Bridge` (or your preference)
4. Select your Slack workspace
5. Click **Create App**

## Step 2: Enable Socket Mode

Socket Mode allows the bot to receive events via WebSocket — no public URL or inbound ports required.

1. In your app settings, go to **Socket Mode** (left sidebar)
2. Toggle **Enable Socket Mode** → ON
3. You will be prompted to create an **App-Level Token**:
   - Token Name: `bridge-socket`
   - Scope: `connections:write`
   - Click **Generate**
4. **Copy the token** (starts with `xapp-`) — this is your `MAESTRO_SLACK_APP_TOKEN`

> **Security:** Never share this token in chat, commits, or config files. Store it as an environment variable only.

## Step 3: Configure Bot Token Scopes

1. Go to **OAuth & Permissions** (left sidebar)
2. Scroll to **Bot Token Scopes**
3. Add the following scopes:
   - `chat:write` — send messages to channels
   - `commands` — handle slash commands
   - `channels:read` — list channels for routing

## Step 4: Register the Slash Command

1. Go to **Slash Commands** (left sidebar)
2. Click **Create New Command**
3. Fill in:
   - **Command:** `/adm`
   - **Short Description:** `Maestro Bridge`
   - **Usage Hint:** `status | approve <ID> | dispatch | help`
4. Click **Save**

> No Request URL is needed — Socket Mode handles event delivery.

## Step 5: Enable Interactive Components

1. Go to **Interactivity & Shortcuts** (left sidebar)
2. Toggle **Interactivity** → ON
3. Click **Save Changes**

> No Request URL is needed with Socket Mode. Interactive components enable the Approve/Reject buttons on notification messages.

## Step 6: Install the App to Your Workspace

1. Go to **Install App** (left sidebar)
2. Click **Install to Workspace**
3. Review the permissions and click **Allow**
4. **Copy the Bot User OAuth Token** (starts with `xoxb-`) — this is your `MAESTRO_SLACK_BOT_TOKEN`

## Step 7: Create Slack Channels

Create a channel for each project you want to receive notifications for:

| Project | Channel |
|---------|---------|
| ADM | `#fleet-ADM` |
| GKT | `#fleet-GKT` |
| PSG | `#fleet-PSG` |
| OTM | `#fleet-OTM` |

In each channel, invite the bot:
```
/invite @Maestro Bridge
```

> Channel names must match the `channel` values in `bridge-settings.json`. You can customise them — just keep the config in sync.

## Step 8: Create the GitHub Gist Command Queue

The bridge uses a private GitHub Gist as a lightweight cloud queue for relaying commands from your phone to your laptop.

1. Go to **https://gist.github.com**
2. Click **+ New gist** (top right)
3. Set the filename to `commands-ADM.json`
4. Set the content to: `[]`
5. Select **Create secret gist** (not public)
6. **Copy the Gist ID** from the URL — it's the long hexadecimal string after `gist.github.com/yourusername/`

Example URL: `https://gist.github.com/tavisbasing/a1b2c3d4e5f6` → Gist ID is `a1b2c3d4e5f6`

> The poller will automatically create additional project files (`commands-GKT.json`, etc.) in the same gist as needed.

## Step 9: Create a GitHub Personal Access Token

If you don't already have one with `gist` scope:

1. Go to **https://github.com/settings/tokens**
2. Click **Generate new token (classic)**
3. Name: `Maestro Bridge`
4. Scopes: check `gist` (under the gist section)
5. Click **Generate token**
6. **Copy the token** (starts with `ghp_`) — this is your `MAESTRO_GITHUB_TOKEN`

> If you already have `MAESTRO_GITHUB_TOKEN` set with `repo` scope, it likely already covers `gist` access. You can reuse it.

## Step 10: Set Environment Variables

Set all four tokens as persistent environment variables on your laptop.

### Windows (PowerShell — recommended)

```powershell
[System.Environment]::SetEnvironmentVariable("MAESTRO_SLACK_BOT_TOKEN", "xoxb-your-token", "User")
[System.Environment]::SetEnvironmentVariable("MAESTRO_SLACK_APP_TOKEN", "xapp-your-token", "User")
[System.Environment]::SetEnvironmentVariable("MAESTRO_BRIDGE_GIST_ID", "your-gist-id", "User")
[System.Environment]::SetEnvironmentVariable("MAESTRO_GITHUB_TOKEN", "ghp_your-token", "User")
```

### Windows (cmd)

```cmd
setx MAESTRO_SLACK_BOT_TOKEN "xoxb-your-token"
setx MAESTRO_SLACK_APP_TOKEN "xapp-your-token"
setx MAESTRO_BRIDGE_GIST_ID "your-gist-id"
setx MAESTRO_GITHUB_TOKEN "ghp_your-token"
```

### macOS / Linux

Add to your shell profile (`~/.bashrc`, `~/.zshrc`, etc.):

```bash
export MAESTRO_SLACK_BOT_TOKEN="xoxb-your-token"
export MAESTRO_SLACK_APP_TOKEN="xapp-your-token"
export MAESTRO_BRIDGE_GIST_ID="your-gist-id"
export MAESTRO_GITHUB_TOKEN="ghp_your-token"
```

Then reload: `source ~/.bashrc`

> **Important:** Restart your terminal (or IDE) after setting environment variables so they take effect.

## Step 11: Enable the Bridge in Configuration

Edit `.mso/config/bridge-settings.json` and set `enabled` to `true`:

```json
{
  "bridge": {
    "enabled": true,
    ...
  }
}
```

Also verify that your project channels are correct in the `projects` section:

```json
"projects": {
  "ADM": { "enabled": true, "channel": "#fleet-ADM" },
  "GKT": { "enabled": true, "channel": "#fleet-GKT" }
}
```

## Step 12: Start the Bridge

```bash
mso bridge start
```

This launches two background daemons:
- **Poller** — polls the GitHub Gist every 30 seconds for inbound commands
- **Slack Bot** — connects to Slack via Socket Mode for slash commands and button interactions

Verify everything is running:

```bash
mso bridge status
```

You should see:

```
  FLEET COMMAND BRIDGE — STATUS
  --------------------------------------------------
  Config:     bridge-settings.json found
  Notifier:   ACTIVE (token configured, 0 pending)
  Poller:     RUNNING (PID: 12345)
  Slack Bot:  RUNNING (PID: 12346)
  --------------------------------------------------
```

## Step 13: Send a Test Notification

```bash
mso bridge test --project ADM
```

Check the `#fleet-ADM` channel in Slack — you should see a test message.

## Step 14: Test from Mobile

Open Slack on your phone and type in any fleet channel:

```
/adm help
```

You should see the available commands. Try:

```
/adm status @ADM
```

---

## Slash Commands Reference

The `/adm` command is the primary interface for controlling your fleet from Slack.

### Marker Syntax

Commands support two inline markers to specify context without flags:

| Marker | Meaning | Example |
|--------|---------|---------|
| `@PRJ` | Project acronym (default: `ADM`) | `@OTM`, `@GKT` |
| `!priority` | Priority level (default: `medium`) | `!critical`, `!high`, `!medium`, `!low` |

These markers can appear anywhere in the command arguments after the subcommand.

---

### `/adm status [@PRJ]`

Request the current fleet status for a project.

```
/adm status
/adm status @ADM
/adm status @OTM
```

The Quartermaster will respond with crew counts, active orders, and system health.

---

### `/adm approve <ID>`

Approve an order paused at a human-review gate (see [Human Review Gates](HUMAN-REVIEW-GATES.md)).

```
/adm approve FTR-OTM-2026-0012
/adm approve PLN-ADM-2026-0003
```

When `<ID>` names an order sitting in `.mso/queues/review/`, the poller drives it
through `mso review approve` — advancing the order to its next role, recording the
ledger event, and promoting any dependent orders (a plan-only order is archived
COMPLETE so its dependents unblock). This is the real gate release, not a status
flip. If `<ID>` instead matches a voyage/plan file (no review-queue entry), the
poller falls back to the legacy behaviour of setting that file's `status` to
`APPROVED`.

---

### `/adm revise <ID> <notes>`

Send a gate-paused order back to the role that triggered its gate, with revision
notes. Notes are **required** (a revise with no notes is rejected).

```
/adm revise FTR-OTM-2026-0012 tighten the error handling and add a rollback path
/adm revise PLN-ADM-2026-0003 split this into two stories, the second depends on auth
```

The poller runs `mso review revise <ID> --notes "<notes>"`, appending the notes and
re-queuing the order at the gated role.

---

### `/adm reject <ID> [reason]`

Reject a gate-paused order, with an optional reason.

```
/adm reject FTR-OTM-2026-0012
/adm reject FTR-OTM-2026-0012 not enough detail
```

When `<ID>` names a review-queue order, the poller runs `mso review reject <ID>
--notes "<reason>"` (substituting a default reason when none is given), marking the
order FAILED and archiving it to `.mso/orders/failed/` — it will not be
re-dispatched. For a voyage/plan file with no review-queue entry, the legacy
`status: REJECTED` flip applies.

---

### `/adm dispatch [@PRJ] [N]`

Dispatch up to N crews (default: 5) for the specified project.

```
/adm dispatch
/adm dispatch @ADM
/adm dispatch @OTM 3
```

---

### `/adm cleanup [@PRJ]`

Run fleet cleanup — stops rogue processes and resets stale crew state.

```
/adm cleanup
/adm cleanup @ADM
```

---

### `/adm order <desc> [@PRJ] [!priority]`

Create a new feature order (FTR type) with an optional priority.

```
/adm order add OAuth login page @OTM
/adm order fix dashboard performance @ADM !high
/adm order update deployment pipeline !critical
```

Priority levels: `!critical`, `!high`, `!medium` (default), `!low`

The order is created as `FTR-{PROJECT}-{YEAR}-{SEQ}` and queued for the Navigator role.

---

### `/adm voyage <title> [@PRJ]`

Create a new voyage (feature branch grouping) for a project.

```
/adm voyage Bridge v2 overhaul @ADM
/adm voyage Mobile dashboard redesign @OTM
```

A `VOY-{PROJECT}-{YEAR}-{SEQ}` JSON is created and a `voyage/VOY-...` git branch is checked out.

---

### `/adm voyage list [@PRJ]`

List active voyages for a project.

```
/adm voyage list
/adm voyage list @ADM
/adm voyage list @OTM
```

Returns each voyage with its ID, status, order count, and title.

---

### `/adm voyage status <VOY-ID>`

Show details for a specific voyage.

```
/adm voyage status VOY-ADM-2026-0001
/adm voyage status VOY-OTM-2026-0003
```

Returns voyage title, status, branch, project, and listed orders.

---

### `/adm bug <title> [@PRJ] [!priority]`

Create a BUG order (default priority: HIGH). Routes directly to the Shipwright role.

```
/adm bug login page crashes on mobile @OTM
/adm bug dashboard freezes on load @ADM !critical
```

The order is created as `BUG-{PROJECT}-{YEAR}-{SEQ}` and queued for the Shipwright (SHP) role.

---

### `/adm reply <text>`

Send a text response to the Quartermaster. Used to answer questions posed by the QM via `AskUserQuestion` (see [QM-Captain Relay](#qm-captain-relay) below).

```
/adm reply Yes, use the existing OAuth library
/adm reply No, skip the migration step for now
```

The reply is delivered back into the paused session by the blocking QM hook (see
[QM-Captain Relay](#qm-captain-relay) below). Send it while a question is
outstanding — the hook waits for it.

---

### `/adm help`

Display the full command reference in Slack.

```
/adm help
```

---

## QM-Captain Relay

The bridge supports a two-way question/answer flow between the Quartermaster (running locally) and the Captain (on mobile).

### How It Works

1. **Question sent:** When the QM session calls `AskUserQuestion`, the PreToolUse
   hook `maestro.hooks.bridge_question` intercepts it, records the outstanding
   question in `.mso/bridge/qm-question.json`, and posts it to Slack via
   `BridgeNotifier.send_question()` (project channel, falling back to
   `defaultChannel`).
2. **Hook blocks:** The same hook then **blocks**, polling
   `.mso/bridge/qm-response.json` for the Captain's reply. Because it blocks, the
   `AskUserQuestion` hook `timeout` in `.claude/settings.json` is raised to 600s
   (the wait budget is configurable — see below).
3. **Captain replies:** From mobile, the Captain sends `/adm reply <answer text>`.
4. **Poller writes the reply:** The bridge poller receives the `qm_response`
   command and writes the answer to `.mso/bridge/qm-response.json`, stamped with the
   outstanding question's project so it correlates even for non-`ADM` projects.
5. **Answer injected:** The blocking hook sees the fresh reply and emits a
   PreToolUse `deny` decision whose reason carries the Captain's answer, so the
   session receives the answer and proceeds **without** rendering the local picker.

> **Delivery model & limitations.** The answer reaches Claude as *guidance text*
> (a `deny`+`reason` block-feedback), not a native picker selection — this is the
> best the hook model allows. Only **one** QM question per project can be
> outstanding at a time; a stale reply from a prior question is rejected by
> timestamp. If no reply arrives within the wait budget, the hook **fails open**:
> it exits cleanly and the **local interactive picker renders**, so a human at the
> device can still answer. A reply that arrives after the timeout is ignored.

### Example Flow

```
[Slack: #fleet-command]
  Fleet QM: 🙋 Quartermaster Question: Should I use the legacy API or the new v2 endpoint?

[Captain on mobile]
  /adm reply Use the v2 endpoint

[Slack: #fleet-command]
  💬 Reply received — queuing...

[Locally]
  bridge_question hook unblocks, injects "Use the v2 endpoint"
  QM session resumes with the Captain's answer
```

### Configuration

The question posts to the project channel (`bridge.projects.<ACR>.channel`) when one
is configured, otherwise to `bridge.slack.defaultChannel` (default: `#fleet-command`).
Ensure the bot is invited to whichever channel it will use. The blocking wait budget
defaults to 570s and can be overridden with
`bridge.notifications.qmResponseTimeoutSeconds` — keep it below the `AskUserQuestion`
hook `timeout` in `.claude/settings.json` (600s) so the hook returns cleanly on
timeout.

---

## CLI Command Reference

### Bridge Management

```bash
mso bridge start              # Start poller + Slack bot
mso bridge stop               # Stop poller + Slack bot
mso bridge restart            # Stop then start both
mso bridge status             # Show component status
mso bridge test --project ADM # Send test notification

mso bridge poller-start       # Start only the poller
mso bridge poller-stop        # Stop only the poller
mso bridge bot-start          # Start only the Slack bot
mso bridge bot-stop           # Stop only the Slack bot
```

### Voyage Management

```bash
mso voyage create "My new voyage" --project ADM
mso voyage list --project ADM
mso voyage list                        # List all projects
mso voyage status VOY-ADM-2026-0001
```

### Bug Orders

```bash
mso bug "Login crashes on submit" --project ADM
mso bug "Dashboard freezes on load" --project OTM
```

Creates a `BUG-{PROJECT}-{YEAR}-{SEQ}` order at HIGH priority, routed to the Shipwright role.

---

## Configuration Reference

### bridge-settings.json

| Path | Type | Default | Description |
|------|------|---------|-------------|
| `bridge.enabled` | bool | `false` | Master enable/disable switch |
| `bridge.slack.botToken` | string | `${MAESTRO_SLACK_BOT_TOKEN}` | Slack Bot OAuth token (env var) |
| `bridge.slack.appToken` | string | `${MAESTRO_SLACK_APP_TOKEN}` | Slack App-Level token (env var) |
| `bridge.slack.defaultChannel` | string | `#fleet-command` | Fallback channel; also used for QM questions |
| `bridge.slack.authorizedUsers` | list | `[]` | Slack user IDs allowed to use `/adm`. **Deny-by-default**: an empty list denies everyone unless `allowAllUsers` is `true`. |
| `bridge.slack.allowAllUsers` | bool | `false` | Opt-in to allow **any** Slack user in the workspace (logs a loud startup warning). Leave `false` and populate `authorizedUsers` for a locked-down bridge. |
| `bridge.projects.<ACR>.enabled` | bool | `true` | Enable notifications for this project |
| `bridge.projects.<ACR>.channel` | string | — | Slack channel for this project |
| `bridge.queue.provider` | string | `github-gist` | Queue provider (only gist supported) |
| `bridge.queue.gistId` | string | `${MAESTRO_BRIDGE_GIST_ID}` | GitHub Gist ID (env var) |
| `bridge.queue.githubToken` | string | `${MAESTRO_GITHUB_TOKEN}` | GitHub PAT (env var) |
| `bridge.queue.pollIntervalSeconds` | int | `30` | How often the poller checks for commands |
| `bridge.notifications.gracePeriodMinutes` | int | `5` | Wait before sending Slack notification |
| `bridge.notifications.includeEscalations` | bool | `true` | Notify on escalations |
| `bridge.notifications.includeApprovals` | bool | `true` | Notify on pending approvals |
| `bridge.notifications.immediateOnBlocked` | bool | `true` | Skip grace period for BLOCKED crews |
| `bridge.notifications.qmResponseTimeoutSeconds` | int | `570` | How long the QM hook blocks for a Captain reply before failing open to the local picker. Keep below the `AskUserQuestion` hook `timeout` (600s). |

### Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `MAESTRO_SLACK_BOT_TOKEN` | Yes | Bot User OAuth Token (`xoxb-...`) |
| `MAESTRO_SLACK_APP_TOKEN` | Yes | App-Level Token (`xapp-...`) |
| `MAESTRO_BRIDGE_GIST_ID` | Yes | GitHub Gist ID for command queue |
| `MAESTRO_GITHUB_TOKEN` | Yes | GitHub PAT with `gist` scope |

---

## Troubleshooting

### Bridge status shows "NO TOKEN"
- Verify env vars are set: `echo $MAESTRO_SLACK_BOT_TOKEN`
- Restart your terminal after setting env vars with `setx`

### Test notification doesn't arrive
- Check the bot is invited to the channel (`/invite @Maestro Bridge`)
- Verify the channel name in `bridge-settings.json` matches exactly (including `#`)
- Check `.mso/logs/bridge.log` for error details

### Poller not picking up commands
- Verify the Gist ID is correct and the gist is accessible with your token
- Check `.mso/logs/bridge.log` for API errors
- Try `mso bridge stop` then `mso bridge start` to restart

### Slash commands not responding
- Ensure Socket Mode is enabled in the Slack app settings
- Verify the App-Level Token has `connections:write` scope
- Check that the `/adm` slash command is registered in the app

### `/adm reply` not reaching QM
- Ensure the poller is running: `mso bridge status`
- Check `.mso/logs/bridge.log` for `qm_response` entries
- Verify `.mso/bridge/qm-response.json` was written after the reply

### Bridge won't start (PID file stale)
```bash
mso bridge stop    # cleans up PID files
mso bridge start   # fresh start
```

---

## Stopping the Bridge

```bash
mso bridge stop
```

This stops both the poller and Slack bot daemons. You can also stop them individually:

```bash
mso bridge poller-stop
mso bridge bot-stop
```
