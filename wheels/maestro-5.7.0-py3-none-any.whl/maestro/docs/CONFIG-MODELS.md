# Configuring per-role models

Maestro assigns a Claude model to each role based on what the role does:

| Role | Default model | Default effort | Why |
|------|---------------|----------------|-----|
| **PLN** — Planner (NAV) | `claude-opus-5` | `medium` | Planning & architecture — high-leverage, low-volume; a better plan prevents downstream rework |
| **BLD** — Builder (SHP) | `claude-sonnet-5` | `high` | Implementation — highest-volume role; Sonnet is strong here. Promote individual hard orders via the per-order `model` override |
| **TST** — Tester (BOS) | `claude-sonnet-5` | `high` | QA, testing |
| **DOC** — Docs writer (SCR) | `claude-sonnet-5` | `high` | Documentation |
| **SEC** — Security (LKT) | `claude-haiku-4-5-20251001` | `high` | Fast investigation, scanning — independent adversarial reviewer |
| **REL** — Releaser (COX) | `claude-opus-5` | `medium` | Integration review + release — last role in the chain; best judgement matters most |
| **LEAD** | `claude-opus-5` | `medium` | Interactive orchestration & judgement |

Selection principle: **high-stakes × low-volume → Opus**. PLN/REL/LEAD run infrequently but their decisions propagate, so they get Opus; the high-volume production roles (BLD/TST/DOC) stay on Sonnet, and SEC on Haiku.

### Opus 5 at medium effort for the Opus roles (FTR-MSO-2026-0419)

PLN/REL/LEAD default to **`claude-opus-5` at `medium` effort** (previously `claude-opus-4-8` at `high`). This is the narrow policy retune supported by the [INV-MSO-2026-0417 A/B measurement](../../.mso/reports/investigation/INV-MSO-2026-0417/INV-MSO-2026-0417-opus5-ab.md). What the data showed:

- **Model swap at equal effort is cheaper.** Replacing Opus 4.8 with Opus 5 at the *same* effort measured **~0.82×** the cost on an M-class order (0405) and **~0.76×** on a class-S order (0411), both passing the quality gate.
- **The effort ladder is flat on quality but steep on cost.** Across low → medium → high → xhigh, quality was flat while cost rose ~**2.3×** (0405: low $3.50, medium $3.32, high $4.80, xhigh $7.72).
- **The saving inverts if you raise effort.** Opus 5 at `high` cost **~1.19×** and at `xhigh` **~1.92×** the old Opus 4.8/medium baseline — *more* expensive for no measured quality gain. **The economy win comes from dropping effort, not merely from switching model. Do NOT reflexively raise effort on Opus 5.**

**Honesty caveat (read before trusting these numbers).** Every measured run **timed out at a bounded 15-minute ceiling** (none signalled completion within budget), and the quality gate was **import-smoke** — "do the touched files still import" — not a full acceptance-criteria check. So "quality flat" means **"nothing obviously broke"**, not "output is equivalent". Treat the ratios as directional. The change is fully reversible by reverting the `DEFAULT_ROLE_MODEL_IDS` and `DEFAULT_ROLE_EFFORT` entries for PLN/REL/LEAD in `maestro/core_constants.py`.

**Deliberately unchanged:** BLD/TST/DOC (Sonnet 4.6) and SEC (Haiku 4.5) were **not** part of the A/B. Sonnet is cheaper per token than Opus 5, and SEC is the independent adversarial reviewer — assuming Opus 5 wins in those roles is unmeasured speculation, so they were left alone.

These defaults are tuned for the typical AU/NZ price-and-quality envelope. You can override at three layers, evaluated in order from highest to lowest priority:

1. **Per-order** — order JSON `model` field (one-off, for a hard order)
2. **Workspace config** — `.mso/config/role-models.json` (per-project, persistent)
3. **Env var** — `MAESTRO_MODEL_<ROLE>` (per-shell, fastest to test)
4. **Built-in default** — falls back to the table above

If none of the above is set, the built-in default is used.

## Inspecting the active configuration

```bash
adm config models
```

Prints a table showing the resolved model for each role and the source that decided it. The per-order layer can't be displayed in a static table (it depends on the order being dispatched), so this command shows the next three layers.

## Layer 1 — Per-order override

Add a `model` field to an order JSON. Highest priority — beats every other layer.

```json
{
  "orderId": "FTR-PSG-2026-0042",
  "type": "FTR",
  "role": "SHP",
  "title": "Refactor the auth flow",
  "model": "claude-opus-4-7"
}
```

Use this when one specific order needs a different model — e.g. a particularly thorny SHP refactor that benefits from Opus, while the rest of the fleet stays on Sonnet for cost.

## Layer 2 — Workspace config

Create `.mso/config/role-models.json` in your workspace:

```json
{
  "models": {
    "SHP": "claude-opus-4-7",
    "BOS": "claude-opus-4-7"
  }
}
```

Only the roles you list are overridden — everything else stays on the built-in default. Survives across shells, runs, and dispatcher restarts. Per-project: each project workspace can have its own.

## Layer 3 — Env var

```powershell
# PowerShell
$env:MAESTRO_MODEL_SHP = "claude-opus-4-7"
```

```bash
# bash / WSL
export MAESTRO_MODEL_SHP=claude-opus-4-7
```

Lives only in the shell that set it — useful for one-off testing or CI where you want different routing without touching files. Linux/macOS env vars are case-sensitive (must be uppercase `MAESTRO_MODEL_SHP`); Windows is case-insensitive at the OS level.

## Supported model IDs

```
claude-opus-5
claude-opus-4-8
claude-opus-4-7
claude-opus-4-6
claude-sonnet-4-6
claude-haiku-4-5-20251001
```

Maestro refuses to dispatch against a model ID it can't price (no `PRICING` entry in `maestro/core/fleet_usage_tracker.py`). Adding a new model means updating both `SUPPORTED_MODELS` and `PRICING` in the framework — file an FTR if you need one Maestro doesn't have.

## Context window & reasoning effort (FTR-MSO-2026-0281)

Maestro supports two additional per-role/per-order dispatch parameters.

### Context window

| Value | Meaning |
|-------|------|
| `standard` (default) | Normal 200K context — no extra cost |
| `1m` | 1M context window — higher input token volume |

The `1m` selector appends as a suffix to `--model` (e.g. `claude-opus-4-8[1m]`), never as a separate flag. Use `1m` ONLY when many files must be held resident simultaneously.

### Reasoning effort

| Value | When to use |
|-------|------|
| `low` | Trivial/mechanical tasks |
| `medium` | Simple single-file tasks |
| `high` (default) | Normal stories — Claude's own default |
| `xhigh` | Opus only; complex long-horizon/high-risk work |
| `max` | **Interactive LEAD only** — rejected for crew dispatch |
| `ultracode` | **Interactive LEAD only** — rejected for crew dispatch |

### Object-form workspace config

```json
{
  "models": {
    "PLN": {"model": "claude-opus-4-8", "contextWindow": "1m", "effort": "xhigh"},
    "BLD": {"model": "claude-sonnet-5", "effort": "high"},
    "TST": "claude-sonnet-5"
  }
}
```

Bare-string values remain fully supported.

### Env vars

```bash
export MAESTRO_CONTEXT_PLN=1m
export MAESTRO_EFFORT_PLN=xhigh
```

### Cost guardrails

- Built-in defaults: contextWindow=standard, effort=high for all roles — zero extra cost out of the box.
- Crew dispatch rejects effort=max and effort=ultracode (reserved for interactive LEAD).
- Opus ~5x Sonnet cost; 1m raises input token VOLUME (no per-token premium on 4.x); xhigh raises output+thinking tokens.

## Cost trade-offs

Sonnet 4.6 is roughly **5× cheaper** than Opus on input and output. Haiku 4.5 is another order of magnitude cheaper than Sonnet. The defaults already exploit this asymmetry — Opus is reserved for the high-leverage, low-volume roles (PLN/REL/LEAD) where a mistake is costliest and the role runs infrequently, while the high-volume production roles (BLD/TST/DOC) stay on Sonnet. Most workspaces never need to override; for a one-off hard build, set a per-order `model` rather than moving BLD to Opus globally.

If your operators are seeing budget pressure, the cheapest first move is to drop the Opus roles back to Sonnet for non-critical projects — e.g. `.mso/config/role-models.json` with `{"models": {"PLN": "claude-sonnet-5", "REL": "claude-sonnet-5"}}`. That reclaims most of the Opus premium while keeping Sonnet's strong planning/coding quality. Run `mso usage --voyage <ID>` after a voyage to see whether the change paid off.
