# Maestro — Multi-Repo Workspaces

> Audience: operators who want **one** Maestro workspace — one dispatcher, one Hub card, one order
> sequence space — to manage crews across **several** product repositories, instead of running a
> separate workspace per repo.

## Contents

- [What this is](#what-this-is)
- [Why](#why)
- [Enabling it: the `repos` map](#enabling-it-the-repos-map)
- [`targetRepo` on orders](#targetrepo-on-orders)
- [Per-repo PRs and voyages](#per-repo-prs-and-voyages)
- [The Hub's multi-repo UI](#the-hubs-multi-repo-ui)
- [Amalgamating existing workspaces: `mso migrate import-workspace`](#amalgamating-existing-workspaces-mso-migrate-import-workspace)
- [Pre-flight checklist](#pre-flight-checklist)
- [Rollback](#rollback)
- [FAQ](#faq)
- [See also](#see-also)

---

## What this is

By default, a Maestro workspace manages **one** product repository: one `.mso/` directory, one
dispatcher, orders and voyages that branch/commit/PR against that single repo.

**Multi-repo workspaces** let one workspace map to **1..N product repositories**. Each order
carries a `targetRepo` naming which repo its crew works in; the dispatcher clones/checks out the
right repo per order; a voyage that touches more than one repo opens **one branch and one PR per
repo it touches**, and only archives once every one of those PRs has merged. You still run one
dispatcher, look at one Hub card, and orders/voyages share one sequence space (`FTR-<ACR>-2026-…`)
regardless of which repo they target.

A workspace with no `repos` map configured is unaffected — this is the single-repo default, and
every existing single-repo workspace keeps working exactly as before.

## Why

The typical trigger is a product that used to be one repo and became several — a coaching platform
split into a core app, a customer portal, and a marketing site, for example — each with its own
deploy pipeline, CI, and git history (so merging them back into one repo isn't the answer), but
still planned, built, and shipped together day to day. Without multi-repo support, that means either
three separate Maestro workspaces (three dispatchers, three Hub cards, no cross-repo voyage, and a
hand-rolled way to reference one repo's order from another's) or awkward workarounds. A multi-repo
workspace gives the three repos one shared planning surface while keeping their git histories,
deploy pipelines, and CI completely separate.

## Enabling it: the `repos` map

A multi-repo workspace is configured with a `repos` map — one entry per product repo — written
either into the workspace's `artefacts` config block (`.mso/config/workspace.json`) or into the
project's entry in the global registry (`~/.maestro/projects.json`). The workspace-config copy is
consulted first (it's the committed, machine-independent source); the registry entry is the
fallback (useful for machine-local path overrides).

```json
{
  "artefacts": {
    "repos": {
      "GKT-Coaching-Platform": {
        "path": "C:/Repos/GKT-Coaching",
        "slug": "your-org/GKT-Coaching-Platform",
        "defaultBranch": "main",
        "cloneProtocol": "ssh",
        "buildCommand": "npm run build",
        "testCommand": "npm test",
        "verifyCommand": "npm run build && npm test",
        "verifyTimeoutMinutes": 15
      },
      "GKT-Portal": {
        "slug": "your-org/GKT-Portal",
        "defaultBranch": "main"
      }
    }
  }
}
```

| Key | Required | Description |
|---|---|---|
| `path` | No | Absolute path to an existing local checkout. If omitted, Maestro clones the repo on first use into a managed location, `<artefact-repo-root>/repos/<repoName>`. |
| `slug` | Only if `path` is omitted (or fetch/clone needs a remote) | `org/repo` — used to build the clone URL and for `gh` operations (`gh pr view/create --repo <slug>`). |
| `defaultBranch` | No | Falls back to the repo's actual default branch if omitted. |
| `cloneProtocol` | No | `"ssh"` (default) or `"https"` — used only for a managed first-use clone. |
| `buildCommand` / `testCommand` | No | Informational — surfaced to crews, not directly invoked by the dispatcher. |
| `verifyCommand` | No | **Per-repo override** of the workspace-level `verifyCommand` local-verify gate (see [FTR-MSO-2026-0287](ARTEFACT-REPO.md)). An order targeting this repo runs this command instead of the workspace default before its convergence push. Omitted or blank → falls back to the workspace default. |
| `verifyTimeoutMinutes` | No | Overrides the workspace-level `verifyTimeoutMinutes` for this repo only. A malformed or non-positive value silently falls back to the workspace default — never fails the gate on a config typo. |

An absent or empty `repos` map means "single-repo workspace" — every dispatch, worktree,
convergence, and verify-gate code path is byte-identical to a workspace that has never heard of
multi-repo mode.

## `targetRepo` on orders

Every order in a multi-repo workspace carries a `targetRepo` field naming which entry in the
`repos` map its crew should work in. This field is **load-bearing** — it selects the actual git
checkout the crew's worktree is created from, not just a display label or PR target. Two refusal
gates protect against a bad or missing value, both **before** any crew is spawned (so a
misconfigured order costs nothing):

- **Missing `targetRepo`** on an order whose role needs a repo (BLD/TST) in a multi-repo workspace
  — the order is refused with a `DISPATCH_BLOCK` and marked failed. Set `targetRepo` to one of the
  configured repo names and it will be picked up on the next dispatch pass.
- **Unknown `targetRepo`** (a value not present in the `repos` map) — refused the same way, with
  the list of known repo names in the error message.
- **Known `targetRepo` but no checkout resolvable** (e.g. offline on a first-use clone, or a bad
  `slug`/remote) — the order is **held**, not failed, and retried on a later dispatch pass once
  connectivity or config is fixed.

Roles that don't need a product-repo checkout (PLN, DOC, SEC) are unaffected by `targetRepo` and
dispatch normally regardless of its value.

## Per-repo PRs and voyages

A voyage that spans more than one repo (its member orders carry more than one distinct
`targetRepo`) gets:

- **One branch name across every repo it touches** — the same `voyage/<VOY-ID>-<slug>` branch name
  in each repo, so the branch is recognisable everywhere even though it's N separate branches in N
  separate git histories.
- **One PR per repo.** The voyage manifest's `targetRepos` array lists every repo it spans (written
  incrementally as each repo's PR is recorded), and `prUrls` maps each repo name to
  `{prNumber, prUrl, state, mergeCommit?, mergedAt?}`. A single-repo voyage keeps writing the flat
  `prNumber`/`prUrl` fields it always has — the `prUrls` map only appears once a voyage actually
  spans more than one repo.
- **Archival only when every repo's PR has merged.** `mso voyage reconcile` checks each repo's PR
  state; if some have merged and others haven't, the voyage is held in `final_review` and a
  `PARTIAL_MERGE` lifecycle event records how many of N have merged so far. Nothing archives until
  the last one lands.
- **A `--repo` filter on reconcile**, for checking one repo's PR state without affecting the
  others:

  ```bash
  mso voyage reconcile --repo GKT-Portal
  ```

  This records that repo's merge state (so the Hub reflects it immediately) but a filtered,
  partial check **never** triggers whole-voyage archival on its own — the other repos may still be
  open.
- **`mso voyage status`** renders a `Repos (N):` block for a multi-repo voyage, one line per repo:

  ```
  VOYAGE: VOY-MSO-2026-0102
  Title:   ...
  Status:  final_review
  Branch:  voyage/VOY-MSO-2026-0102-multi-repo-workspaces
  Project: MSO
  Repos (2):
    - GKT-Coaching-Platform: voyage/VOY-MSO-2026-0102-multi-repo-workspaces — PR #41 (MERGED) https://github.com/...
    - GKT-Portal: voyage/VOY-MSO-2026-0102-multi-repo-workspaces — PR #9 (OPEN) https://github.com/...
  ```

  A legacy single-repo voyage still prints the flat `PR:` line it always has; a voyage with no PR
  recorded yet prints neither block.

## The Hub's multi-repo UI

The Hub surfaces the same `targetRepos`/`prUrls` data directly in the dashboard instead of
collapsing a multi-repo voyage down to a single guessed repo:

- **Voyage cards — per-repo PR pills.** A voyage whose `targetRepos` has more than one entry shows
  a small repo-tagged pill per repo next to the branch chip (e.g. `coaching #12`, `portal #5`). A
  merged repo's pill shows a checkmark and links to its PR; an open or not-yet-opened repo's pill
  stays neutral. A voyage with 0 or 1 repos renders exactly as it always has — no pills — which
  covers every legacy voyage that predates this feature.
- **Final Review strip — one call-to-action per unmerged repo.** For a multi-repo voyage sitting in
  `final_review`, the strip shows a "review & merge" link per repo whose PR isn't yet `MERGED` (or
  a muted "PR not yet opened" note if a repo has no PR yet) — instead of the single button a
  single-repo voyage shows. The voyage only flips to the merged phase once every repo's PR is
  `MERGED`, matching the reconcile rule above exactly.
- **Order rows and drawers — a repo badge.** In a workspace whose `repos` map has more than one
  entry, every order (in the queue accordion, an expanded voyage's order list, and the order detail
  drawer) shows a small pill naming its `targetRepo`. In a single-repo workspace this badge never
  renders anywhere.

  This "is the workspace multi-repo" check is **independent** of the per-voyage "does this voyage
  span more than one repo" check that gates the voyage-card pills above — a single-repo voyage
  living inside an otherwise multi-repo workspace still shows the simple single-PR call-to-action on
  its own card, but its orders still carry the workspace-level repo badge. The two signals can
  legitimately disagree for one voyage; that's expected, not a bug.
- **`claimedBy` badges** (shared-mode workspaces only — see [ARTEFACT-REPO.md](ARTEFACT-REPO.md#corporate-shared-mode))
  appear on claimed orders regardless of single- or multi-repo mode; the two features compose.

No extra Hub configuration is needed — once your project's `repos` map is populated, the Hub picks
it up on its next poll.

## Amalgamating existing workspaces: `mso migrate import-workspace`

If you already have **separate** Maestro workspaces — say `GKT` (the coaching platform, already
running solo/shared artefact-repo mode) plus standalone `POR` (portal) and `WEB` (website)
workspaces — you can fold them into one multi-repo workspace without losing any order/voyage
history, using a **copy-fresh amalgamation with ID renaming**:

```bash
mso migrate import-workspace <SOURCE> --into <TARGET> --sub-acronym <SUB> [--target-acronym ACR] [--dry-run]
```

| Flag | Required | Description |
|---|---|---|
| `<SOURCE>` | Yes (positional) | The source workspace root — the directory containing its `.mso/`. |
| `--into <TARGET>` | Yes | The target artefact-repo / workspace root to import into — must already contain a `.mso/`. |
| `--sub-acronym <SUB>` | Yes | The sub-acronym the imported namespace gets renamed under (see below). |
| `--target-acronym <ACR>` | No | Override the target's acronym (default: resolved from the target's `workspace.json` / directory name). |
| `--dry-run` | No | Print the full action table and rename-map preview; mutates nothing. |

**Worked example — importing the Portal and Website workspaces into the GKT coaching platform's
artefact repo:**

```bash
# Preview first — always
mso migrate import-workspace C:/Repos/GKT-Portal --into C:/Repos/GKT-Platform --sub-acronym POR --dry-run

# Then for real
mso migrate import-workspace C:/Repos/GKT-Portal --into C:/Repos/GKT-Platform --sub-acronym POR
mso migrate import-workspace C:/Repos/GKT-Web --into C:/Repos/GKT-Platform --sub-acronym WEB
```

### What "sub-acronym ID renaming" means

Every artefact ID in the source workspace is **renamed**, not kept as-is: an order like
`BUG-POR-2026-0007` in the Portal workspace becomes `BUG-GKT-POR-2026-0007` once imported into the
`GKT-Platform` target (`GKT` is the target's acronym, `POR` is the `--sub-acronym` you passed). The
shape is always `<TYPE>-<TARGET>-<SUB>-<YEAR>-<SEQ>`. This is a **deliberate, binding decision**
(it overrides an earlier draft of the design that proposed keeping imported IDs unchanged) — it
guarantees every ID in the amalgamated workspace is unique and immediately tells you, from the ID
alone, which product repo an order originally belonged to.

Every cross-reference to a renamed ID is rewritten consistently as part of the same import — inside
filenames, `dependsOn` lists, `voyageId` fields, and free-text mentions in `.md`/`.json`/`.txt`
bodies. A deep verify pass checks for **dangling old-ID references** after the copy-rename and
before the commit; the import refuses (leaving the target's git working tree uncommitted, for
inspection) rather than land a half-renamed cross-reference.

### What actually happens, step by step

1. **Source pre-flight gate** (same shape as `mso migrate artefact-repo`'s) — refuses if the source
   has a running dispatcher, any live crew/voyage/salvage worktree, an unmerged artefact branch, or
   uncommitted `.mso` changes. See [Pre-flight checklist](#pre-flight-checklist).
2. **Mandatory backup of BOTH sides** — the source workspace and the target artefact repo are each
   backed up (`mso backup`-equivalent zip) before anything is mutated. If either backup fails to
   complete, the import aborts before touching anything.
3. **Copy-rename** — every durable-plane file (`orders/`, `queues/`, `voyages/`, `plans/`,
   `handoffs/`, `reports/`, `usage/`) is copied into the target with every renamed ID applied to
   both its filename and its contents. Files whose renamed target already exists are skipped
   (idempotent — see below).
4. **Rename-map audit artefact** — a full record of every renamed ID, written to
   `.mso/reports/imports/RENAME-MAP-<SUB>.json` in the target, including:
   - `renameMap` — the complete old-ID → new-ID mapping.
   - `sequenceHighWater` — the target's own per-year high-water mark, the imported source's
     original high-water mark, and the **combined** high-water (the max of the two per year).
5. **Deep verify** — confirms no old, un-renamed ID reference survived the copy-rename anywhere in
   the target. A failure here stops before the commit.
6. **One import commit** in the target: `import: workspace <source-name> as <SUB>`.
7. **Registry update** — the target's registry entry records `legacyAcronyms[<SUB>]` (so a
   `@POR`-style reference still resolves to the GKT workspace, exactly like the historical
   `ADM → MSO` acronym transition), and the source workspace is marked `imported`.

### Combined sequence high-water

After an import, new orders created in the target workspace start numbering **above the combined
high-water mark**, not just the target's own — so a freshly created `FTR-GKT-2026-0213` order can
never collide with a just-imported `FTR-GKT-POR-2026-0212` (formerly `FTR-POR-2026-0212`). The
exact numbers you'll actually see are recorded in
`sequenceHighWater.combined` inside the rename-map artefact from step 4 above — check it after each
import if you want to confirm where the next new order will land.

### Idempotency

Re-running the same `import-workspace` command against an already-imported source is safe: files
whose renamed target already exists in the target workspace are skipped rather than duplicated or
overwritten, and if every renamed file is already present the command reports "nothing to do" and
makes no commit.

## Pre-flight checklist

Because the import takes a one-time copy-rename of the **source's** current state, run through this
before importing (the command will refuse and name the specific blocker if you skip a step, but
it's faster to check first):

- [ ] No dispatcher is currently running against the **source** workspace (`mso cleanup` on the
      source if unsure).
- [ ] No crew, voyage, salvage, or scratch worktree is still checked out in the source.
- [ ] Every voyage/crew/salvage branch in the source that touched `.mso/` has been merged to its
      default branch.
- [ ] `git status` in the source shows no uncommitted changes under `.mso/`.
- [ ] The **target** already has a `.mso/` (an artefact repo from
      [`mso migrate artefact-repo`](ARTEFACT-REPO.md), or any existing Maestro workspace root) —
      `--into` must point at an existing workspace, not a fresh empty directory.

## Rollback

`import-workspace` doesn't have its own `--rollback` flag — its safety net is the **mandatory
backup of both sides taken in step 2 above, before any mutation**. If an import needs undoing:

```bash
mso restore <backup-file> --dry-run   # preview
mso restore <backup-file>             # restore the target (or source) from its pre-import zip
```

Because the import only ever *copies* from the source (the source's own `.mso/` is never modified
by the import itself), the source workspace remains fully intact and usable throughout — you only
need to restore the **target** if you want to undo an import that already committed. A `--dry-run`
import mutates nothing at all, so it never needs rolling back.

## FAQ

**Do I need artefact-repo mode (solo/shared) to use multi-repo workspaces?**
The `--into` target for `import-workspace` must already have a `.mso/` — in practice this is
almost always an artefact repo from `mso migrate artefact-repo`, since the whole point of
amalgamating several product repos is to have one shared home for their combined state that isn't
any one of the product repos itself. A plain embedded single-repo workspace can also carry a
`repos` map directly, but an artefact repo is the natural fit once you're spanning more than one
product repo.

**Can a multi-repo workspace also run in shared (corporate) mode?**
Yes — `artefacts.mode: "shared"` and a populated `repos` map are independent settings and compose
normally; see [Corporate shared mode](ARTEFACT-REPO.md#corporate-shared-mode).

**What if an order doesn't need a specific repo (e.g. a planning or docs order)?**
Only roles that actually touch a product-repo checkout (BLD/TST) require a resolvable `targetRepo`.
Planning, documentation, and security-review orders dispatch normally regardless of `targetRepo`.

**Does every repo need its own build/test command?**
`buildCommand`/`testCommand` in a `repos` map entry are informational. If you want the automated
local-verify gate (the one that holds an order's push on a failing build) to run something specific
per repo, set that repo's `verifyCommand` (and optionally `verifyTimeoutMinutes`) — see
[Enabling it](#enabling-it-the-repos-map).

## See also

- [ARTEFACT-REPO.md](ARTEFACT-REPO.md) — dedicated artefact repository + corporate shared mode
- [HUB.md](HUB.md) — Maestro Hub dashboard
- [CLI-REFERENCE.md](CLI-REFERENCE.md) — full command reference
