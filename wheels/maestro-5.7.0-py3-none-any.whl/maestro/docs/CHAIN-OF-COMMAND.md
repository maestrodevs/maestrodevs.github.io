# Chain of Command — Maestro

> **v4.0 note:** The chain of command was previously described in a 4-layer nautical model (Captain → Quartermaster → Fleet Admiral → Crews). This document reflects the current 3-layer model using role-neutral terminology, with a nautical-persona callout section for operators using the built-in nautical theme.

---

## The 3-Layer Chain

```
Human (You)  →  LEAD (Claude, interactive)  →  Dispatcher (mso dispatch)  →  Squads
```

```mermaid
flowchart TB
    H["Human<br/>(You)"]
    L["LEAD<br/>Claude, interactive session"]
    D["Dispatcher<br/>mso dispatch"]

    S1["Squad 1"]
    S2["Squad 2"]
    S3["Squad 3"]
    S4["Squad 4"]
    S5["Squad 5"]

    A1["1..N agents"]
    A2["1..N agents"]
    A3["1..N agents"]
    A4["1..N agents"]
    A5["1..N agents"]

    H --> L
    L --> D

    D --> S1
    D --> S2
    D --> S3
    D --> S4
    D --> S5

    S1 --> A1
    S2 --> A2
    S3 --> A3
    S4 --> A4
    S5 --> A5

    classDef human fill:#ffe4b5,stroke:#b8860b,color:#4a3000
    classDef interactive fill:#e8f4ff,stroke:#0366d6,color:#0366d6
    classDef automation fill:#f0e8ff,stroke:#6f42c1,color:#4a148c
    classDef autonomous fill:#d4edda,stroke:#155724,color:#0d3315
    classDef agents fill:#fff4e6,stroke:#cc7a00,color:#663d00,stroke-dasharray: 5 5

    class H human
    class L interactive
    class D automation
    class S1,S2,S3,S4,S5 autonomous
    class A1,A2,A3,A4,A5 agents
```

Each squad is one autonomous Claude session running a single role on a single order. Within that session the squad can fan out to **1..N subagents** via the SDK Task tool — these are the workhorse agents that actually do the file-level investigation, code edits, test runs, etc. Subagent count is bounded only by the API; in practice 1–10 per squad is typical.

| Layer | Who | What they do |
|-------|-----|-------------|
| **Human** | You, the operator | Sets direction, approves PRs, makes go/no-go decisions |
| **LEAD** | Claude (interactive session) | Your AI partner in the main session — plans work, delegates to squads, reviews output |
| **Dispatcher** | `mso dispatch` | Automation layer that launches and manages squad lifecycle |
| **Squads** | Autonomous Claude agents | Execute individual orders (tasks) in isolated sessions |

### Roles (Canonical)

| Code | Name | Responsibility | Model |
|------|------|---------------|-------|
| PLN | Planner | Planning, architecture, requirements analysis | Sonnet 4.6 |
| BLD | Builder | Implementation, feature development, bug fixes | Sonnet 4.6 |
| TST | Tester | QA, testing, acceptance criteria validation | Sonnet 4.6 |
| DOC | Docs writer | Documentation, changelogs, guides | Sonnet 4.6 |
| SEC | Security reviewer | Security audit, vulnerability scanning, investigation | Haiku 4.5 |
| REL | Releaser | Integration, CI/CD, deployment, release gates | Opus 4.7 |
| LEAD | Lead | Interactive partner role — plans, delegates, advises | (interactive) |

Legacy role codes (from the v2.x era) are retained as aliases: NAV=PLN, SHP=BLD, BOS=TST, SCR=DOC, LKT=SEC, COX=REL, QM=LEAD.

---

## Responsibilities at Each Layer

### Human

- Defines what needs to happen (requirements, high-level goals)
- Approves plans before significant work begins
- Reviews pull requests and merge gates
- Makes go/no-go decisions on releases
- Has full override authority at any point

### LEAD (interactive Claude session)

The LEAD is your AI partner in the main Claude Code session. Unlike squad members (which are autonomous), the LEAD is interactive — you direct it in real time.

**What LEAD does:**
- Reads the current sprint backlog and order queue
- Decomposes requirements into orders and assigns roles
- Creates order JSON files and voyage/sprint records
- Monitors squad output and synthesises results
- Flags blockers or decisions that need human input
- Writes handoff context for squads to pick up

**What LEAD does NOT do:**
- LEAD does not directly write production code (it delegates to BLD squads)
- LEAD does not approve its own plans (Human approves)
- LEAD does not merge PRs (REL squads handle this, with Human approval)

### Dispatcher (`mso dispatch`)

The dispatcher is the automation layer that converts the order queue into running squad processes.

**What it does:**
- Reads orders from `.mso/queues/orders/` and `.mso/orders/active/`
- Resolves dependency ordering (an order with `dependsOn` waits for its dependencies)
- Launches up to `--max-crews N` squad processes in parallel (default: 5)
- Injects role-specific system prompts, persona context, and environment variables
- Monitors squad lifecycle; promotes completed orders to `.mso/orders/complete/`
- Enforces branch discipline — each squad runs in the correct git worktree

### Squads (autonomous Claude agents)

Squads are independent Claude Code sessions, each executing a single order.

**Characteristics:**
- One order → one squad → one session
- Each squad runs in its own git worktree (parallel sprint support)
- Squad context is injected at launch: role prompt + persona + order JSON + handoff docs
- Squads write outputs to the workspace (code, tests, docs, reports) and handoff documents
- Squads cannot spawn other squads; only the dispatcher does that

---

## Information Flow

```
Human writes requirement
    ↓
LEAD decomposes into orders
    ↓
Orders land in .mso/queues/orders/
    ↓
Dispatcher picks up orders (mso dispatch)
    ↓
Squads execute in parallel (up to 5)
    ↓
Each squad writes output + handoff doc
    ↓
Dispatcher promotes order to complete/
    ↓
LEAD reads results and synthesises
    ↓
REL squad opens PR / closes sprint
    ↓
Human reviews and approves merge
```

---

## Runtime Execution Model

The 3-layer chain tells you *who's responsible* for what. The diagrams below show *how it actually runs* — three orthogonal axes that all happen simultaneously: **parallel crew slots**, **role iteration through `roleSequence`**, and **per-squad subagent fan-out**.

### Axis 1 — Parallel crew slots (1–5, set by `--max-crews`)

The dispatcher holds a fixed pool of squad slots (`Crew 1` through `Crew 5` by default). Each slot is either IDLE or running a single order, in a single role, inside a single git worktree. Slots are **independent** — five different orders from different voyages can run simultaneously, each in its own worktree.

```mermaid
flowchart LR
    Q[(".mso/queues/&ast;<br/>PENDING orders")] --> DISP[["mso dispatch<br/>--max-crews 5"]]
    DISP --> C1["Crew 1<br/>Lion"]
    DISP --> C2["Crew 2<br/>Leopard"]
    DISP --> C3["Crew 3<br/>Cheetah"]
    DISP --> C4["Crew 4<br/>Hyena"]
    DISP --> C5["Crew 5<br/>Wild Dog"]

    C1 --> W1["worktrees/<br/>VOY-A/crew1/"]
    C2 --> W2["worktrees/<br/>VOY-B/crew2/"]
    C3 --> W3["worktrees/<br/>VOY-A/crew3/<br/>(same voyage as Crew 1,<br/>own worktree)"]
    C4 --> W4["(IDLE — no eligible<br/>PENDING order)"]
    C5 --> W5["(IDLE)"]

    classDef idle fill:#eee,stroke:#999,color:#666
    class W4,W5 idle
```

- One **voyage** can have multiple orders in flight on the same branch, sharing a worktree.
- Different **voyages** always get different worktrees (parallel isolation).
- The dispatcher's `stagger-delay` (default 30s) prevents Claude API rate-limiting during simultaneous slot fills.

### Axis 2 — Role iteration through `roleSequence` (per order)

A single order moves through its `roleSequence` (e.g. `["PLN", "BLD", "TST", "REL"]`) one role at a time. Each role is a **fresh squad dispatch into the same worktree** — the previous role's commits + handoff doc are picked up by the next role.

```mermaid
stateDiagram-v2
    [*] --> PROPOSED
    PROPOSED --> PENDING : LEAD promotes
    PENDING --> IN_PROGRESS_PLN : dispatcher → Crew N

    state "IN_PROGRESS @ PLN" as IN_PROGRESS_PLN
    state "IN_PROGRESS @ BLD" as IN_PROGRESS_BLD
    state "IN_PROGRESS @ TST" as IN_PROGRESS_TST
    state "IN_PROGRESS @ REL" as IN_PROGRESS_REL

    IN_PROGRESS_PLN --> NAV_REVIEW_PENDING : gates.json says<br/>pause for human
    NAV_REVIEW_PENDING --> IN_PROGRESS_BLD : mso review approve
    IN_PROGRESS_PLN --> IN_PROGRESS_BLD : ADVANCE
    IN_PROGRESS_BLD --> IN_PROGRESS_TST : ADVANCE
    IN_PROGRESS_TST --> IN_PROGRESS_REL : ADVANCE
    IN_PROGRESS_REL --> COMPLETE : last role done<br/>(archive to orders/complete/)
    COMPLETE --> [*]

    IN_PROGRESS_BLD --> TIMEOUT : crew dies /<br/>iteration timeout
    TIMEOUT --> SILENT_COMPLETION_DETECTED : commit on voyage branch<br/>after startedAt<br/>(BUG-MSO-2026-0023)
    SILENT_COMPLETION_DETECTED --> IN_PROGRESS_TST : ADVANCE
    TIMEOUT --> PENDING : REQUEUE<br/>(no commit found)
```

- The dispatcher picks the next role by looking up the **completed role** in `roleSequence` and selecting the next entry.
- Between roles, the order's `targetRole` field is rewritten and the order JSON is re-queued at PENDING — the dispatcher's next tick picks it up for the new role.
- Across roles in one order, the **same git worktree** is reused — handoffs land at `.mso/handoffs/{ORDER-ID}/{from-role}-to-{to-role}.md`.

### Axis 3 — Per-squad subagent fan-out (N agents)

Within a single squad's Claude session (e.g. BLD on FTR-MSO-2026-0150), the crew can spawn additional Claude agents via the SDK's **Task tool**. These are *not* visible to the dispatcher — they're internal parallelism owned by the squad's Claude session. Use cases: scanning many files in parallel, running independent investigations, cross-validating results.

```mermaid
flowchart TB
    DISP[["Dispatcher launches<br/>Crew 1 as BLD<br/>for FTR-MSO-2026-0150"]]
    DISP --> CREW["Crew 1 / Lion<br/>(Claude session, role=BLD)"]

    CREW -->|Task tool| SUB1["Subagent A<br/>'inventory all .py files<br/>that import &lt;module&gt;'"]
    CREW -->|Task tool| SUB2["Subagent B<br/>'audit role-paths.json<br/>for legacy keys'"]
    CREW -->|Task tool| SUB3["Subagent C<br/>'verify tests/test_crew.py<br/>covers iter 2'"]
    CREW -->|Task tool| SUBN["Subagent ...N"]

    SUB1 -->|report| CREW
    SUB2 -->|report| CREW
    SUB3 -->|report| CREW
    SUBN -->|report| CREW

    CREW -->|synthesises| OUT["Order outputs:<br/>code edits, tests,<br/>handoff doc,<br/>commit on voyage branch"]

    classDef subagent fill:#e8f4ff,stroke:#0366d6,color:#0366d6
    class SUB1,SUB2,SUB3,SUBN subagent
```

- Subagent count `N` is **bounded only by the SDK / API** — typically 1–10 in practice.
- Subagents inherit the parent crew's role permissions (branch guard, MCP allowlist, etc.) — they cannot escape the parent's sandbox.
- Subagents do **not** count toward `--max-crews` — they're internal to a single dispatcher-owned slot.
- The crew's [maestro/hooks/posttool.py](../hooks/posttool.py) records subagent tool-use in `.mso/crews/crew{N}/activity.jsonl` so the audit trail captures the full fan-out.

### Putting all three axes together

```mermaid
flowchart TB
    subgraph DISP_LAYER ["Dispatcher (1 process)"]
        D["mso dispatch<br/>--max-crews 5"]
    end

    subgraph SLOTS ["Axis 1 — Parallel slots"]
        direction LR
        SLOT1["Crew 1<br/>order: FTR-MSO-2026-0150<br/>role: BLD<br/>voyage: VOY-A"]
        SLOT2["Crew 2<br/>order: BUG-MSO-2026-0029<br/>role: TST<br/>voyage: VOY-B"]
        SLOT3["Crew 3<br/>order: SEC-MSO-2026-0004<br/>role: BLD<br/>voyage: VOY-C"]
    end

    subgraph ITER ["Axis 2 — Role iteration (per order)"]
        direction LR
        R1[PLN] --> R2[BLD] --> R3[TST] --> R4[REL]
    end

    subgraph FANOUT ["Axis 3 — Subagent fan-out (per crew)"]
        direction LR
        CR["Crew (Claude<br/>session)"]
        CR -.Task tool.-> A1[agent]
        CR -.Task tool.-> A2[agent]
        CR -.Task tool.-> AN[...]
    end

    D -.dispatches.-> SLOT1
    D -.dispatches.-> SLOT2
    D -.dispatches.-> SLOT3

    SLOT1 -.advances.-> ITER
    SLOT1 -.spawns.-> FANOUT
```

Three concurrent axes:
- **Axis 1** (horizontal): up to 5 crew slots × parallel = 5 orders progressing simultaneously
- **Axis 2** (vertical, per order): each order steps through its `roleSequence`, picking up a fresh crew dispatch at each role
- **Axis 3** (depth, per crew): a single crew can fan out to N internal subagents during its iteration

A maximally-utilised dispatcher with 5 crews, each crew on a different role of a different voyage, each spawning ~5 subagents = up to **25 parallel Claude sessions** observable at one moment.

---

## Persona-Aware Sub-Sections

Maestro ships with a built-in **nautical persona** that maps the chain of command to seafaring roles. When the nautical persona is active (the default), the terminology shifts:

| Canonical term | Nautical persona |
|---------------|-----------------|
| Human (operator) | Captain |
| LEAD | Quartermaster |
| Dispatcher | Fleet Admiral |
| Squad | Crew |
| Sprint | Voyage |
| Order | Order (unchanged) |

The underlying mechanics are identical — only the vocabulary changes. All documentation, CLI output, and role prompts are rendered through the active persona at runtime.

**In the nautical persona, the chain reads:**

```
Captain (You)  →  Quartermaster (Claude)  →  Fleet Admiral (mso dispatch)  →  Crews
```

To configure or switch personas, see [docs/PERSONAS.md](PERSONAS.md).

---

## Comparison: Old 4-Layer vs Current 3-Layer

Prior to v3.0.0 (the Maestro rebrand), the chain of command was documented as 4 layers:

```
Captain → Quartermaster → Fleet Admiral → Crews (up to 5)
```

This was actually still a 3-layer architecture — the "up to 5 Crews" was describing parallelism within the dispatcher layer, not a separate command layer. The v3.0.0 documentation makes this explicit. Nothing changed architecturally; the description became more accurate.

---

## Gates and Approvals

Maestro supports optional **human review gates** between role transitions, configurable via `.mso/config/gates.json`. Common gates:

| Gate | Default | Description |
|------|---------|-------------|
| PLN → BLD | optional | Human reviews PLN plan before BLD starts implementation |
| BLD → TST | off | TST starts automatically after BLD completes |
| TST → REL | optional | Human reviews TST report before REL creates the PR |
| REL → merge | **required** | Human explicitly approves PR before REL merges |

The PR merge gate is always required — Maestro never auto-merges without explicit human approval.

See [docs/HUMAN-REVIEW-GATES.md](HUMAN-REVIEW-GATES.md) for the full configuration reference.

---

## Branch Discipline

Each sprint runs on a dedicated git branch. The dispatcher enforces this:

1. `voyageBranch` on every order JSON is load-bearing — the dispatcher checks out the correct branch before launching the squad
2. The pretool branch guard (`maestro/hooks/branch_guard.py`) denies any git/gh mutation that targets a branch other than `$MAESTRO_VOYAGE_BRANCH`
3. Multiple sprints run safely in parallel because each uses its own git worktree

See docs/BRANCH-DISCIPLINE.md for the operator reference.
