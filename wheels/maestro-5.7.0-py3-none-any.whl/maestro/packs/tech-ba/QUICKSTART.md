# Technical BA pack — QUICKSTART

The Technical BA pack templates Maestro's canonical-7 archetypes into a requirements-engineering
delivery process: stakeholder elicitation, process mapping, spec writing, and requirements
validation. It is a **division pack** — content only, zero engine change (see
`PLAN-PLN-MSO-2026-0371` section 2.3). This is a **Team/Enterprise-tier** pack; `mso init --pack
tech-ba` requires that licence tier (or `MAESTRO_SKIP_AUTH=1` for local trial).

## What you get

| Archetype | Division title | Does |
|-----------|-----------------|------|
| PLN | Elicitor | Stakeholder question capture, scope analysis |
| BLD | Process Mapper | BPMN/Mermaid process maps, committed as docs-as-code |
| DOC | Spec Writer | BRD/FSD documents |
| TST | Validator | Traceability matrix, walkthrough scripts, AC verification |

| Order type | Sequence | Use for |
|------------|----------|---------|
| `ELC` | `[PLN]` | Elicitation — a single-role planning deliverable |
| `MAP` | `[PLN, BLD]` | Process map — scope confirmation, then the diagram |
| `SPC` | `[PLN, BLD, DOC, TST]` | Spec — scope, map, BRD/FSD, traceability + AC validation |
| `VAL` | `[TST]` | Validation — a single-role deliverable, run standalone or against a prior `SPC` |

## The docs-as-code / PR-as-stakeholder-review model

This pack's delivery model is the load-bearing design decision, not an implementation detail:
**every division deliverable is a content repo.** Elicitation briefs live on the artefact plane
(`.mso/plans/`); process maps and specs are Markdown files with embedded Mermaid diagrams,
committed to the content repo like any other source file.

That is deliberate, not a workaround:

- **Mermaid and Markdown render natively on GitHub.** A process-map PR shows the actual diagram
  in the diff view — no separate export step, no screenshot pasted into a ticket.
- **The PR *is* the stakeholder-review artefact.** Reviewers comment inline on the specific
  requirement or diagram node that's wrong, the same way engineers review code — full history,
  full provenance, no separate review tool to keep in sync.
- **The workspace `verifyCommand`** (`workspace-defaults.json`) enforces this before a PR is
  even opened: a Markdown lint plus a Mermaid render check, so a malformed diagram or broken
  Markdown table never reaches the reviewer.

## Known adoption risk — Word/Confluence export (explicitly out of scope here)

Most non-technical stakeholders live in Word documents and Confluence spaces, not GitHub. This
pack does **not** solve that gap. `PLAN-PLN-MSO-2026-0371` section 4c identifies an
export/sync adapter (BRD/FSD → Confluence page, or → a `.docx` export) as the real integration
work a production rollout needs — and explicitly defers it as **demand-driven, not
pilot-scope**. Until an adapter exists, expect one of:

- A human on the BA team manually mirrors the merged spec into Confluence/Word, or
- Stakeholders are onboarded to reviewing Markdown/Mermaid directly in GitHub PRs (works well
  for technically-adjacent stakeholders; a harder sell for purely business stakeholders).

Do not treat "no adapter" as a defect in this pack — it is a named, deliberately deferred gap.
Flag it explicitly in any pilot's Elicitation Brief when stakeholders are Word/Confluence-native
(the Elicitor role's `must_do` calls this out).

## Cold start

```bash
# 1. Scaffold a new workspace with the pack
mso init --project BA1 --pack tech-ba

# (trial without a Team/Enterprise licence)
MAESTRO_SKIP_AUTH=1 mso init --project BA1 --pack tech-ba
```

This lands the persona (Elicitor/Process Mapper/Spec Writer/Validator), the four role overlays
at `.mso/config/roles/`, the four order templates at `.mso/orders/templates/`, the
scope-approval gate at `.mso/config/gates.json`, workspace defaults (verify command, role
timeouts) merged into `.mso/config/workspace.json`, requirement templates at
`.mso/requirements/`, and this file at `.mso/QUICKSTART-tech-ba.md`.

```bash
# 2. Confirm the pack landed correctly
mso packs show tech-ba
mso packs validate tech-ba
mso roles show PLN     # renders the merged Elicitor overlay
mso roles show BLD     # renders the merged Process Mapper overlay
mso roles show DOC     # renders the merged Spec Writer overlay
mso roles show TST     # renders the merged Validator overlay
```

```bash
# 3. Author your first ELC order — copy the template and fill it in
cp .mso/orders/templates/ELC-template.json .mso/queues/orders/ELC-BA1-2026-0001.json
# edit: orderId, title, description, voyageId, voyageBranch, createdBy, createdAt
```

An `ELC` order is single-role (`PLN` only) — the Elicitor reads it, produces an Elicitation
Brief at `.mso/plans/PLAN-ELC-BA1-2026-0001.md`, and the order completes. No process map or
spec is written yet.

```bash
# 4. Turn the brief into your first SPC voyage
mso voyage create "First spec pass" --project BA1
cp .mso/orders/templates/SPC-template.json .mso/queues/orders/SPC-BA1-2026-0002.json
# edit: fill in the same fields, plus targetRepo (the content repo) and voyageId/voyageBranch
mso dispatch
```

The `SPC` order runs Elicitor → Process Mapper → Spec Writer → Validator: the Elicitor
refines the brief for this specific requirement (or reuses ELC-0001's brief), the Process Mapper
draws the process as a Mermaid diagram in the content repo, the Spec Writer turns the brief and
diagram into a BRD/FSD, and the Validator builds a traceability matrix and marks every
acceptance criterion before the order completes. If `gates.json`'s `post_nav_review` is enabled
(it is, by default), the Elicitation Brief pauses for human review before the Process Mapper
starts — approve with `mso review approve`.

## Notes and known gaps

- **Word/Confluence export adapter** — see "Known adoption risk" above; tracked as
  `PLAN-PLN-MSO-2026-0371` section 4c, not in scope for this pack.
- **`mso packs validate tech-ba`** — validates the manifest schema, every `roles/*.md` overlay
  (via the same `parse_role_file` path `mso roles validate` uses), `persona.json`, and every
  order-template's `_meta.roleSequence` against the canonical role codes. Exit 0 on a clean
  pack.
