"""Apply a division pack's contents onto a scaffolded Maestro workspace.

``apply_pack`` runs AFTER the standard ``.mso/`` scaffold and layers the pack's
persona, role overlays, order-type templates, gates, workspace defaults, extra
dirs, requirement templates, and quickstart onto it. Every step is conditional
on the pack actually shipping that asset, so a pack that ships nothing beyond
its manifest (the ``sdlc`` pack #0) leaves the workspace byte-identical to a
plain ``mso init`` — the invariant the FTR-A regression fixture pins.

Persona note: the persona resolver reads ``<workspace>/.maestro/config/persona.json``
(distinct from the ``.mso`` artefact dir), matching the existing setup wizard
(``maestro/setup.py``). A ``persona: "default"`` pack writes NO persona file, so
the plain-init workspace shape is preserved.
"""

from __future__ import annotations

import json
import shutil
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List

from maestro.workspace import resolve_artefact_dir

from .loader import Pack


@dataclass
class PackScaffoldResult:
    """What ``apply_pack`` did — for CLI reporting and tests."""

    pack_id: str
    role_overlays: List[str] = field(default_factory=list)
    order_templates: List[str] = field(default_factory=list)
    persona_written: bool = False
    gates_written: bool = False
    workspace_defaults_merged: bool = False
    scaffold_dirs: List[str] = field(default_factory=list)
    requirements_copied: bool = False
    quickstart_copied: bool = False

    def changed(self) -> bool:
        """True if the pack contributed anything beyond a plain init."""
        return bool(
            self.role_overlays
            or self.order_templates
            or self.persona_written
            or self.gates_written
            or self.workspace_defaults_merged
            or self.scaffold_dirs
            or self.requirements_copied
            or self.quickstart_copied
        )


def _deep_merge(base: Dict[str, Any], overlay: Dict[str, Any]) -> Dict[str, Any]:
    """Recursively merge *overlay* into *base* (overlay wins on scalar/leaf keys)."""
    for key, value in overlay.items():
        if (
            key in base
            and isinstance(base[key], dict)
            and isinstance(value, dict)
        ):
            _deep_merge(base[key], value)
        else:
            base[key] = value
    return base


def apply_pack(pack: Pack, base: Path) -> PackScaffoldResult:
    """Layer *pack*'s contents onto the already-scaffolded workspace at *base*.

    Returns a PackScaffoldResult describing every file/dir the pack contributed.
    Idempotent-friendly: role overlays / order templates / gates overwrite;
    workspace defaults deep-merge.
    """
    base = Path(base).resolve()
    mso_dir = resolve_artefact_dir(base)
    result = PackScaffoldResult(pack_id=pack.id)

    # -- role overlays → .mso/config/roles/ ---------------------------------
    overlay_files = pack.role_overlay_files()
    if overlay_files:
        dest = mso_dir / "config" / "roles"
        dest.mkdir(parents=True, exist_ok=True)
        for src in overlay_files:
            shutil.copyfile(src, dest / src.name)
            result.role_overlays.append(src.name)

    # -- persona → <base>/.maestro/config/persona.json ----------------------
    # (matches the resolver + setup-wizard location, NOT the .mso artefact dir)
    if pack.persona_file.exists():
        persona_dest = base / ".maestro" / "config" / "persona.json"
        persona_dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(pack.persona_file, persona_dest)
        result.persona_written = True
    elif pack.persona and pack.persona != "default":
        persona_dest = base / ".maestro" / "config" / "persona.json"
        persona_dest.parent.mkdir(parents=True, exist_ok=True)
        persona_dest.write_text(
            json.dumps({"id": pack.persona}, indent=2) + "\n", encoding="utf-8"
        )
        result.persona_written = True

    # -- order templates → .mso/orders/templates/ ---------------------------
    template_files = pack.order_template_files()
    if template_files:
        dest = mso_dir / "orders" / "templates"
        dest.mkdir(parents=True, exist_ok=True)
        for src in template_files:
            shutil.copyfile(src, dest / src.name)
            result.order_templates.append(src.name)

    # -- gates → .mso/config/gates.json (overwrite) -------------------------
    if pack.gates_file.exists():
        gates_dest = mso_dir / "config" / "gates.json"
        gates_dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(pack.gates_file, gates_dest)
        result.gates_written = True

    # -- workspace defaults → deep-merge into .mso/config/workspace.json ----
    ws_path = mso_dir / "config" / "workspace.json"
    ws_overlay: Dict[str, Any] = {}
    if pack.workspace_defaults_file.exists():
        ws_overlay = json.loads(pack.workspace_defaults_file.read_text(encoding="utf-8"))
    if pack.verify_command and "verifyCommand" not in ws_overlay:
        ws_overlay["verifyCommand"] = pack.verify_command
    if ws_overlay and ws_path.exists():
        ws_data = json.loads(ws_path.read_text(encoding="utf-8"))
        _deep_merge(ws_data, ws_overlay)
        ws_path.write_text(json.dumps(ws_data, indent=2) + "\n", encoding="utf-8")
        result.workspace_defaults_merged = True

    # -- extra scaffold dirs ------------------------------------------------
    for rel in pack.scaffold_dirs:
        d = base / rel
        d.mkdir(parents=True, exist_ok=True)
        if not any(d.iterdir()):
            (d / ".gitkeep").touch()
        result.scaffold_dirs.append(rel)

    # -- requirement templates → .mso/requirements/ -------------------------
    if pack.requirements_dir.is_dir():
        dest = mso_dir / "requirements"
        dest.mkdir(parents=True, exist_ok=True)
        for src in sorted(pack.requirements_dir.iterdir()):
            if src.is_file():
                shutil.copyfile(src, dest / src.name)
        result.requirements_copied = True

    # -- quickstart → .mso/QUICKSTART-<pack>.md -----------------------------
    if pack.quickstart_file.exists():
        qs_dest = mso_dir / f"QUICKSTART-{pack.id}.md"
        shutil.copyfile(pack.quickstart_file, qs_dest)
        result.quickstart_copied = True

    return result
