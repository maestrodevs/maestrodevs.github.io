# DevOps pack — QUICKSTART

The DevOps pack templates Maestro's canonical-7 archetypes into an infra-delivery process:
change planning, Terraform/Helm/pipeline implementation, terraform-plan/policy/smoke-test
validation, and a gated, controlled deploy. It is a **division pack** — content only, zero
engine change (see `PLAN-PLN-MSO-2026-0371` section 5). PLAN-PLN-MSO-2026-0371 section 2.4
rates this division's engine fit **HIGHEST**: infra is already repo-shaped, and
`verifyCommand` maps directly onto the terraform-plan / policy-check / smoke-test tooling most
infra repos already run in CI. This is a **Team/Enterprise-tier** pack; `mso init --pack
devops` requires that licence tier (or `MAESTRO_SKIP_AUTH=1` for local trial).

## The one real gap this pack needed: a pre-deploy human gate

Every other pilot/fast-follow pack only ever needed the planning gate the engine already had
(`post_nav_review`, PLN→BLD). DevOps is different: the plan explicitly calls out that it needs
a **pre-REL (pre-deploy) human gate**, and the engine's gate check used to only fire on the
planning transition. `FTR-MSO-2026-0427` generalised the gate engine to any role transition
(`gates.json` schema v2, a `transitions` map keyed `"<FROM>-><TO>"`), and this pack is the
reason that generalisation exists — see `gates.json` in this directory, which sets
`transitions["*->REL"]` so no Deployer performs a controlled rollout without explicit human
approval, regardless of which role advanced into REL.

## What you get

| Archetype | Division title | Does |
|-----------|-----------------|------|
| PLN | Infra Planner | Architecture, capacity, blast-radius, change plans |
| BLD | Pipeline/IaC Builder | Terraform/Helm/pipeline code |
| TST | Change Validator | `terraform plan`, policy checks (checkov/OPA), smoke tests |
| DOC | Runbook Writer | Operational runbooks, dashboards-as-code documentation |
| REL | Deployer | Controlled rollout, environment promotion — gated by `transitions["*->REL"]` |

| Order type | Sequence | Use for |
|------------|----------|---------|
| `INF` | `[PLN, BLD, TST, REL]` | Infra — plan, build, validate, deploy (the only order type that reaches REL) |
| `PIP` | `[PLN, BLD, TST]` | Pipeline — CI/CD change plan, implementation, validation (ships via PR merge, not a rollout) |
| `OBS` | `[PLN, BLD, DOC]` | Observability — plan, dashboards-as-code implementation, runbook |

## Cold start

```bash
# 1. Scaffold a new workspace with the pack
mso init --project INF1 --pack devops

# (trial without a Team/Enterprise licence)
MAESTRO_SKIP_AUTH=1 mso init --project INF1 --pack devops
```

This lands the persona (Infra Planner/Pipeline-IaC Builder/Change Validator/Runbook
Writer/Deployer), the five role overlays at `.mso/config/roles/`, the three order templates at
`.mso/orders/templates/`, the change-plan-approval + pre-deploy gates at
`.mso/config/gates.json` (schema v2 — see above), workspace defaults (verify command, role
timeouts, `devops.requireChangeValidation`) merged into `.mso/config/workspace.json`,
requirement templates at `.mso/requirements/`, the extra scaffold dirs
(`.mso/reports/devops/validation/`, `.mso/reports/devops/runbooks/`), and this file at
`.mso/QUICKSTART-devops.md`.

```bash
# 2. Confirm the pack landed correctly
mso packs show devops
mso roles show PLN     # renders the merged Infra Planner overlay
mso roles show BLD     # renders the merged Pipeline/IaC Builder overlay
mso roles show TST     # renders the merged Change Validator overlay
mso roles show DOC     # renders the merged Runbook Writer overlay
mso roles show REL     # renders the merged Deployer overlay
```

```bash
# 3. Author your first PIP or OBS order — copy the template and fill it in
cp .mso/orders/templates/PIP-template.json .mso/queues/orders/PIP-INF1-2026-0001.json
# edit: orderId, title, description, targetRepo, voyageId, voyageBranch, createdBy, createdAt
```

A `PIP` order runs Infra Planner → Pipeline/IaC Builder → Change Validator: the plan states the
pipeline stage and rollback path, the Builder implements it, and the Validator runs policy
checks and a dry-run before the order completes. No REL phase — a pipeline change ships via PR
merge, not a controlled infra rollout.

```bash
# 4. Turn a capacity/architecture need into your first INF voyage
mso voyage create "First infra change" --project INF1
cp .mso/orders/templates/INF-template.json .mso/queues/orders/INF-INF1-2026-0002.json
# edit: fill in the same fields, plus targetRepo (the infra repo) and voyageId/voyageBranch
mso dispatch
```

The `INF` order runs Infra Planner → Pipeline/IaC Builder → Change Validator → Deployer. If
`gates.json`'s `post_nav_review` is enabled (it is, by default), the change plan pauses for
human review before the Builder starts — approve with `mso review approve`. After the Change
Validator writes its GO/NO-GO recommendation, the order pauses **again** at the pre-REL gate —
no Deployer runs `terraform apply`/`helm upgrade` (or triggers a deploy pipeline) until that
second approval lands, also via `mso review approve`. `mso review queue` shows both pauses with
the transition that triggered them (`PLN->BLD`, then `TST->REL`) in the GATE column.

## Notes and known gaps

- **`verifyCommand` is a Terraform-shaped placeholder** (`terraform fmt -check -recursive &&
  terraform validate`) — a well-formedness check, not a functional one. Swap for the target
  repo's actual verify chain once its toolchain is known: add `checkov -d . --quiet --compact`
  for policy-as-code, `helm lint charts/* && helm template charts/* | kubeval` for Helm, or the
  repo's own pipeline linter for `PIP` orders. See `workspace-defaults.json`'s `verifyNotes`.
- **The Deployer never applies/deploys directly unless that is the target repo's own
  established convention.** The role overlay (`roles/REL.md`) prefers a merge-triggered CD
  pipeline over a direct `terraform apply`/`helm upgrade`; direct apply is documented as the
  fallback for repos with no CD pipeline, not the default assumption.
- **Requirement templates location** — this pack's `requirements/*.md.j2` files land at
  `.mso/requirements/` on init (per the existing `apply_pack` scaffold step). They are not yet
  wired into the `mso order --template` custom-template resolution path, which currently reads
  `.mso/templates/requirements/` — a pre-existing gap in the pack scaffold shared with every
  pack, not specific to DevOps. Use them as copy-paste references for now.
- **No live deploy adapter.** Like every division pack shipped so far, delivery rides the
  everything-as-repo convention (PLAN-PLN-MSO-2026-0371 section 4a) — the Deployer's rollout is
  whatever mechanism the target repo already uses (CD pipeline trigger, or a direct apply
  command run in the crew's sandboxed worktree). There is no first-class cloud-provider
  adapter; that is out of scope for a division pack (content only, zero engine change).
