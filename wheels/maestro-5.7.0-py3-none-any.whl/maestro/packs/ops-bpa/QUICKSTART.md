# Operations / Business-Process Automation pack — QUICKSTART

The Ops/BPA pack templates Maestro's canonical-7 archetypes into a business-process-automation
delivery process: as-is/to-be discovery with automation-candidate scoring, workflow
implementation, UAT, and runbook authoring. It is a **division pack** — content only, zero
engine change (see `PLAN-PLN-MSO-2026-0371` section 5). This is a **Team/Enterprise-tier**
pack; `mso init --pack ops-bpa` requires that licence tier (or `MAESTRO_SKIP_AUTH=1` for local
trial).

## Scope limitation — read this before you start

**This pack is scoped to the n8n workflow-export-as-code model only. It does not build a
Power Automate (or any other external SaaS) adapter.**

The deployed workflow always lives in an external system, and this division is where that
first becomes a real constraint on the pack mechanism: a division pack is data (persona + role
overlays + order templates + gates), and Maestro's `git`/PR-centred delivery model round-trips
cleanly onto n8n because n8n ships a CLI (`n8n export:workflow` / `n8n import:workflow`) that
turns a workflow into a versioned JSON file. Power Automate's equivalent deliverable is a
solution `.zip` — there is no comparably clean CLI-friendly export/import/verify loop, and
building one would mean writing a genuine `DeliveryBackend`/SaaS adapter (tracked as a deferred,
demand-driven follow-up in the plan, section 4c), not authoring pack content.

**Practical effect:**
- The Discoverer's Tooling Scope Check (in every Discovery Plan) must flag any
  Power-Automate-only or otherwise non-CLI-exportable automation candidate as **out of scope**
  for a `WFL` order raised against this pack — not silently recommend it.
- The Builder must raise a blocker rather than attempt a Power Automate build.
- The Runbook Writer's Known Limitations section always states this constraint explicitly, so
  an operator maintaining the workflow later is not surprised by it.
- If your organisation's automation candidate genuinely requires Power Automate (or another
  SaaS with no CLI export path), this pack is not yet the right tool for that candidate.

## What you get

| Archetype | Division title | Does |
|-----------|-----------------|------|
| PLN | Discoverer | As-is/to-be process mapping, automation-candidate scoring, n8n tooling-scope check |
| BLD | Builder | n8n workflow implementation, delivered as versioned JSON exports in git |
| TST | Runner | UAT case execution against the deployed workflow, evidence capture |
| DOC | Writer | Operating procedures, failure playbooks |

| Order type | Sequence | Use for |
|------------|----------|---------|
| `DSC` | `[PLN]` | Discovery — a single-role planning deliverable |
| `WFL` | `[PLN, BLD, TST, DOC]` | Workflow — refine, build, UAT, document |

## Cold start

```bash
# 1. Scaffold a new workspace with the pack
mso init --project OPS1 --pack ops-bpa

# (trial without a Team/Enterprise licence)
MAESTRO_SKIP_AUTH=1 mso init --project OPS1 --pack ops-bpa
```

This lands the persona (Discoverer/Builder/Runner/Writer), the four role overlays at
`.mso/config/roles/`, the two order templates at `.mso/orders/templates/`, the
process-approval gate at `.mso/config/gates.json`, workspace defaults (verify command, role
timeouts, `ops.exportAsCodeOnly`) merged into `.mso/config/workspace.json`, requirement
templates at `.mso/requirements/`, the extra scaffold dirs
(`.mso/reports/ops-bpa/uat/`, `.mso/reports/ops-bpa/runbooks/`), and this file at
`.mso/QUICKSTART-ops-bpa.md`.

```bash
# 2. Confirm the pack landed correctly
mso packs show ops-bpa
mso roles show PLN     # renders the merged Discoverer overlay
mso roles show BLD     # renders the merged Builder overlay
mso roles show TST     # renders the merged Runner overlay
mso roles show DOC     # renders the merged Writer overlay
```

```bash
# 3. Author your first DSC order — copy the template and fill it in
cp .mso/orders/templates/DSC-template.json .mso/queues/orders/DSC-OPS1-2026-0001.json
# edit: orderId, title, description, voyageId, voyageBranch, createdBy, createdAt
```

A `DSC` order is single-role (`PLN` only) — the Discoverer reads it, produces a Discovery Plan
at `.mso/plans/PLAN-DSC-OPS1-2026-0001.md` (as-is map, to-be design, scored candidates, and the
n8n tooling-scope check), and the order completes. No workflow is built yet.

```bash
# 4. Turn a discovered candidate into your first WFL voyage
mso voyage create "First workflow automation pass" --project OPS1
cp .mso/orders/templates/WFL-template.json .mso/queues/orders/WFL-OPS1-2026-0002.json
# edit: fill in the same fields, plus targetRepo (the workflow-export repo) and voyageId/voyageBranch
mso dispatch
```

The `WFL` order runs Discoverer → Builder → Runner → Writer: the Discoverer refines the plan
for this specific candidate (or reuses DSC-0001's plan), the Builder implements it as an n8n
workflow-export-as-code JSON file in the target repo, the Runner executes UAT against the
deployed workflow, and the Writer publishes the operating procedure and failure playbook. If
`gates.json`'s `post_nav_review` is enabled (it is, by default), the Discovery Plan pauses for
human review before the Builder starts — approve with `mso review approve`.

## Notes and known gaps

- **Requirement templates location** — this pack's `requirements/*.md.j2` files land at
  `.mso/requirements/` on init (per the existing `apply_pack` scaffold step). They are not yet
  wired into the `mso order --template` custom-template resolution path, which currently reads
  `.mso/templates/requirements/` — a pre-existing gap in the pack scaffold shared with every
  pack, not specific to Ops/BPA. Use them as copy-paste references for now.
- **`verifyCommand` is a well-formedness check, not a functional one** — the shipped default
  parses `workflows/**/*.json` as JSON and nothing more. It does not confirm the workflow
  actually runs correctly in n8n. Swap in `n8n import:workflow` (or your CI's real check) once
  the target repo's n8n tooling is wired up — see `workspace-defaults.json`'s `verifyNotes`.
- **No Power Automate support** — repeated here because it is the single most important thing
  to know before raising a `WFL` order against this pack: see "Scope limitation" above.
