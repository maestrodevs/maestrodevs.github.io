"""JSON loader for Maestro division packs with schema validation.

Mirrors ``maestro/personas/loader.py`` exactly: schema-validated JSON asset
loading with built-in directory discovery and a safe, explicit error type. A
division pack is DATA — persona + role overlays + order types + gates +
workspace defaults — that templates a non-SDLC delivery process onto the
existing engine with zero engine change (PLAN-PLN-MSO-2026-0371 section 5).
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

import jsonschema

logger = logging.getLogger(__name__)

_SCHEMA_PATH = Path(__file__).parent / "_schema.json"
_BUILTIN_DIR = Path(__file__).parent

_schema: Optional[dict] = None


class PackSchemaError(Exception):
    """Raised when a pack manifest fails schema validation or cannot be parsed."""


@dataclass
class Pack:
    """An in-memory division pack: the validated manifest plus its on-disk root."""

    id: str
    display_name: str
    description: str
    tier: str
    root: Path
    persona: str = "default"
    roles: List[str] = field(default_factory=list)
    order_types: Dict[str, Any] = field(default_factory=dict)
    scaffold_dirs: List[str] = field(default_factory=list)
    verify_command: Optional[str] = None
    manifest: Dict[str, Any] = field(default_factory=dict)

    # -- anatomy probes (which optional pack assets ship on disk) -----------

    @property
    def roles_dir(self) -> Path:
        return self.root / "roles"

    @property
    def order_templates_dir(self) -> Path:
        return self.root / "order-templates"

    @property
    def requirements_dir(self) -> Path:
        return self.root / "requirements"

    @property
    def persona_file(self) -> Path:
        return self.root / "persona.json"

    @property
    def gates_file(self) -> Path:
        return self.root / "gates.json"

    @property
    def workspace_defaults_file(self) -> Path:
        return self.root / "workspace-defaults.json"

    @property
    def quickstart_file(self) -> Path:
        return self.root / "QUICKSTART.md"

    def role_overlay_files(self) -> List[Path]:
        """Role overlay .md files shipped by this pack (ordinary R2 overlays)."""
        if not self.roles_dir.is_dir():
            return []
        return sorted(self.roles_dir.glob("*.md"))

    def order_template_files(self) -> List[Path]:
        """Order-template *-template.json files shipped by this pack."""
        if not self.order_templates_dir.is_dir():
            return []
        return sorted(self.order_templates_dir.glob("*-template.json"))

    def is_free(self) -> bool:
        return self.tier == "free"


def _get_schema() -> dict:
    global _schema
    if _schema is None:
        _schema = json.loads(_SCHEMA_PATH.read_text(encoding="utf-8"))
    return _schema


def load_pack_from_dict(data: dict, root: Path, source: str = "<dict>") -> "Pack":
    """Validate *data* against the pack schema and return a Pack instance."""
    try:
        jsonschema.validate(data, _get_schema())
    except jsonschema.ValidationError as exc:
        raise PackSchemaError(
            f"Pack schema validation failed ({source}): {exc.message}"
        ) from exc
    return Pack(
        id=data["id"],
        display_name=data["displayName"],
        description=data["description"],
        tier=data["tier"],
        root=Path(root),
        persona=data.get("persona", "default"),
        roles=list(data.get("roles", [])),
        order_types=dict(data.get("orderTypes", {})),
        scaffold_dirs=list(data.get("scaffoldDirs", [])),
        verify_command=data.get("verifyCommand"),
        manifest=data,
    )


def load_pack_from_dir(path: Union[str, Path]) -> "Pack":
    """Load and validate the ``pack.json`` manifest in directory *path*.

    Raises PackSchemaError on missing/malformed/invalid manifest.
    """
    path = Path(path)
    manifest_path = path / "pack.json"
    if not manifest_path.exists():
        raise PackSchemaError(f"No pack.json manifest found in {path}")
    try:
        data = json.loads(manifest_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise PackSchemaError(f"Malformed JSON in {manifest_path}: {exc}") from exc
    pack = load_pack_from_dict(data, root=path, source=str(manifest_path))
    # Guard against directory/id drift so `mso init --pack <id>` resolves the
    # same directory that `mso packs list` advertised.
    if pack.id != path.name:
        raise PackSchemaError(
            f"Pack id '{pack.id}' does not match its directory name '{path.name}' ({manifest_path})"
        )
    return pack


def load_builtin(name: str) -> "Pack":
    """Load a built-in pack by id. Raises PackSchemaError if not found/invalid."""
    pack_dir = _BUILTIN_DIR / name
    if not (pack_dir / "pack.json").exists():
        raise PackSchemaError(f"Built-in pack '{name}' not found at {pack_dir}")
    return load_pack_from_dir(pack_dir)


def builtin_names() -> List[str]:
    """Return the sorted list of available built-in pack ids."""
    return sorted(
        d.name
        for d in _BUILTIN_DIR.iterdir()
        if d.is_dir() and (d / "pack.json").exists()
    )


def load_all_builtin() -> List["Pack"]:
    """Load every built-in pack. Invalid packs are skipped with a warning."""
    packs: List[Pack] = []
    for name in builtin_names():
        try:
            packs.append(load_builtin(name))
        except PackSchemaError as exc:
            logger.warning("Skipping invalid built-in pack '%s': %s", name, exc)
    return packs
