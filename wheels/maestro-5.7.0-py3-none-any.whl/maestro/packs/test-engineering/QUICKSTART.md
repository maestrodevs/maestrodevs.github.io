# Test Engineering pack — QUICKSTART

The Test Engineering pack templates Maestro's canonical-7 archetypes into a QA/test-automation
delivery process: risk-based strategy, automation implementation, exploratory gap-finding, and
release-readiness reporting. It is a **division pack** — content only, zero engine change
(see `PLAN-PLN-MSO-2026-0371` section 5). This is a **Team/Enterprise-tier** pack; `mso init
--pack test-engineering` requires that licence tier (or `MAESTRO_SKIP_AUTH=1` for local trial).

## What you get

| Archetype | Division title | Does |
|-----------|-----------------|------|
| PLN | Strategist | Risk assessment, coverage-gap analysis, tooling choice |
| BLD | Automator | Playwright / pytest / k6 implementation in the test repo |
| TST | Explorer | Exploratory charters, session notes, gap-finding |
| DOC | Reporter | Coverage / quality / release-readiness reports |
| SEC | Auditor (optional) | Read-only test-quality + flaky-test audit |

| Order type | Sequence | Use for |
|------------|----------|---------|
| `TSD` | `[PLN]` | Test strategy — a single-role planning deliverable |
| `AUT` | `[PLN, BLD, TST]` | Automation — strategy, implementation, gap-check |
| `EXP` | `[PLN, TST, DOC]` | Exploratory charter — scope, execute, report |
| `QRP` | `[TST, DOC]` | Quality report — assess, report |

## Cold start

```bash
# 1. Scaffold a new workspace with the pack
mso init --project QA1 --pack test-engineering

# (trial without a Team/Enterprise licence)
MAESTRO_SKIP_AUTH=1 mso init --project QA1 --pack test-engineering
```

This lands the persona (Strategist/Automator/Explorer/Reporter/Auditor), the five role
overlays at `.mso/config/roles/`, the four order templates at `.mso/orders/templates/`, the
strategy-approval gate at `.mso/config/gates.json`, workspace defaults (verify command, role
timeouts, `qa.e2e`) merged into `.mso/config/workspace.json`, requirement templates at
`.mso/requirements/`, and this file at `.mso/QUICKSTART-test-engineering.md`.

```bash
# 2. Confirm the pack landed correctly
mso packs show test-engineering
mso roles show PLN     # renders the merged Strategist overlay
mso roles show BLD     # renders the merged Automator overlay
mso roles show TST     # renders the merged Explorer overlay
mso roles show DOC     # renders the merged Reporter overlay
mso roles show SEC     # renders the merged Auditor overlay
```

```bash
# 3. Author your first TSD order — copy the template and fill it in
cp .mso/orders/templates/TSD-template.json .mso/queues/orders/TSD-QA1-2026-0001.json
# edit: orderId, title, description, voyageId, voyageBranch, createdBy, createdAt
```

A `TSD` order is single-role (`PLN` only) — the Strategist reads it, produces a Test Strategy
Plan at `.mso/plans/PLAN-TSD-QA1-2026-0001.md`, and the order completes. No automation code is
written yet.

```bash
# 4. Turn the strategy into your first AUT voyage
mso voyage create "First automation pass" --project QA1
cp .mso/orders/templates/AUT-template.json .mso/queues/orders/AUT-QA1-2026-0002.json
# edit: fill in the same fields, plus targetRepo (the test repo) and voyageId/voyageBranch
mso dispatch
```

The `AUT` order runs Strategist → Automator → Explorer: the Strategist refines the plan for
this specific coverage area (or reuses TSD-0001's plan), the Automator implements it as
Playwright/pytest/k6 code in the test repo, and the Explorer runs an exploratory gap-check
against the freshly automated area before the order completes. If `gates.json`'s
`post_nav_review` is enabled (it is, by default), the Test Strategy Plan pauses for human
review before the Automator starts — approve with `mso review approve`.

## Dogfooding: Maestro's own test estate as a worked example

Maestro's own `pytest` suite is a live pilot candidate for this pack. At the time this pack
shipped, this repo carried **~24 known environmental test failures** (licence-tampering,
version-string, and persona role→model-leak tests that fail on this dogfood machine's local
setup but pass on a clean CI runner — see `.mso/config/workspace.json`'s `verifyNotes`), plus a
history of flaky-test triage across the fleet-runner and hooks test suites.

A first `TSD` order against this repo would look like:

```json
{
  "title": "Test strategy: resolve the ~24 environmental pytest failures",
  "description": "## Scope\nThe ~24 known-environmental failures tracked in workspace.json verifyNotes (licence-tampering, version-string, persona role->model-leak). Risk-tier each, decide whether each needs an environment fix, a test-isolation fix, or a documented waiver."
}
```

...and a follow-up `EXP` charter could target flaky-test triage across `tests/` — a genuine,
already-known gap rather than a synthetic example. This is exactly the kind of scoping the
Strategist role is designed to produce.

## Notes and known gaps

- **`mso packs validate test-engineering`** — the schema/content validator described in the
  division-packs plan (§7, FTR-B) ships in a separate follow-up order
  (`FTR-MSO-2026-0384`); it is not yet available as of this pack's initial content. Until then,
  validate structurally with the existing loader: `python -c "from maestro.packs import
  load_builtin; load_builtin('test-engineering')"` exits 0 on a schema-valid manifest, and `mso
  roles validate` covers the five role overlays once installed into a workspace.
- **Requirement templates location** — this pack's `requirements/*.md.j2` files land at
  `.mso/requirements/` on init (per the existing `apply_pack` scaffold step). They are not yet
  wired into the `mso order --template` custom-template resolution path, which currently reads
  `.mso/templates/requirements/` — a pre-existing gap in the pack scaffold shared with every
  pack, not specific to Test Engineering. Use them as copy-paste references for now.
