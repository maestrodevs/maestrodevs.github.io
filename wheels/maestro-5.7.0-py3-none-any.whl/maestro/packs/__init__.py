"""maestro.packs — division-pack loading, discovery, and workspace scaffolding.

A *division pack* templates Maestro's persona + role + order-type surface for a
non-SDLC delivery team (Test Engineering, SecOps, DevOps, …). A pack is pure
DATA and requires no engine change — see PLAN-PLN-MSO-2026-0371 section 5.

Public surface:
    load_builtin(id)        → Pack           (built-in pack by id)
    builtin_names()         → list[str]      (available built-in pack ids)
    load_all_builtin()      → list[Pack]     (every valid built-in pack)
    load_pack_from_dir(p)   → Pack           (pack in an arbitrary directory)
    apply_pack(pack, base)  → PackScaffoldResult (scaffold a workspace)
    validate_pack_dir(p)    → dict[str, list[str]]  (full-content validation, one pack)
    validate_all_packs()    → dict[str, dict[str, list[str]]]  (every built-in pack)
    Pack, PackSchemaError
"""

from .loader import (
    Pack,
    PackSchemaError,
    builtin_names,
    load_all_builtin,
    load_builtin,
    load_pack_from_dict,
    load_pack_from_dir,
)
from .scaffold import PackScaffoldResult, apply_pack
from .validate import builtin_pack_root, validate_all_packs, validate_pack_dir

__all__ = [
    "Pack",
    "PackSchemaError",
    "PackScaffoldResult",
    "apply_pack",
    "builtin_names",
    "builtin_pack_root",
    "load_all_builtin",
    "load_builtin",
    "load_pack_from_dict",
    "load_pack_from_dir",
    "validate_all_packs",
    "validate_pack_dir",
]
