"""maestro/patrol/checks/lead.py — the resident LEAD's own surfaces.

PLAN-PLN-MSO-2026-0828 §0 Q3 / Risk R8, FTR-MSO-2026-0844.

The Captain Chat thread is durable and the LEAD daemon is not: it can be
stopped, stood down, or simply never started. A proactive question posted
into the thread therefore outlives the process that asked it, and an
unanswered one is invisible to anybody not looking at the thread — which is
the population this check exists for.

``lead.chat-open-question`` closes that hole from the OTHER direction, through
the one surface an operator already runs when they want to know whether
anything is wrong: `mso doctor`. Its `suggestedCommand` is
``mso lead chat log --open``, which is a read, and reading is the whole
remedy — the question is answered by a human in the thread, never by a
command.

**Read-only, and structurally so.** ``CheckContext`` carries no writer (see
``maestro.patrol.registry``'s module docstring and
``test_checks_have_no_writer_end_to_end``), so this check cannot supersede,
expire or answer the questions it reports even if a later change wanted it
to. The daemon supersedes a question when its finding resolves or is
acknowledged (``chat_proactive.reconcile_questions``); this check only ever
says that one has gone unanswered.
"""

from __future__ import annotations

from maestro.patrol.registry import CheckContext, Finding, check

#: Read through ``load_lead_config`` so the shipped number lives in ONE place
#: (``agent.DEFAULT_CHAT_OPEN_QUESTION_HOURS``) and an operator who sets
#: ``lead.chat.openQuestionHours`` changes both the daemon's notion of stale
#: and this check's in one edit.
_PARAM_HOURS = "openQuestionHours"

#: A workspace where the daemon has asked a great many questions and nobody
#: has answered any of them does not need a hundred findings to make that
#: point — and `mso doctor`'s exit code and the Hub drawer both degrade badly
#: past a certain length. Beyond this the oldest are reported individually and
#: the remainder are named as a count, never silently dropped.
_MAX_INDIVIDUAL_FINDINGS = 5


def _resolved_hours(context: CheckContext) -> int:
    """This check's threshold: the patrol definition's param if a tier set
    one, else ``lead.chat.openQuestionHours``, else the shipped default.

    The patrol param wins when present because that is the tier mechanism
    every other check's thresholds resolve through (bundle > pack >
    workspace.json > default), and a governed workspace must be able to pin
    it. Absent that, the LEAD's own config is the authority — it is where an
    operator would look for a chat setting.
    """
    params = context.params_for("lead.chat-open-question")
    raw = params.get(_PARAM_HOURS)
    if raw is not None:
        try:
            hours = int(raw)
            if hours > 0:
                return hours
        except (TypeError, ValueError):
            pass  # a malformed override falls through to the config below
    try:
        from maestro.lead.agent import load_lead_config

        return int(load_lead_config(context.artefact_root)["chat"][_PARAM_HOURS])
    except Exception:  # noqa: BLE001
        from maestro.lead.agent import DEFAULT_CHAT_OPEN_QUESTION_HOURS

        return DEFAULT_CHAT_OPEN_QUESTION_HOURS


def _age_phrase(hours: int) -> str:
    if hours >= 48:
        return f"{hours // 24} days"
    return f"{hours} hours"


@check(id="lead.chat-open-question", severity="medium", scope="workspace")
def chat_open_question(context: CheckContext) -> "list[Finding]":
    # Lazily imported, like every other check's heavier dependency: a patrol
    # run must never fail (or pay the import) because of a subsystem the
    # workspace does not use. A workspace that has never had a chat thread
    # simply has no questions.
    try:
        from maestro.lead import chat_proactive
    except Exception:  # noqa: BLE001
        return []

    hours = _resolved_hours(context)
    try:
        stale = chat_proactive.stale_open_questions(
            context.artefact_root, hours=hours, now=context.now)
    except Exception:  # noqa: BLE001 — an unreadable thread is not a finding
        return []
    if not stale:
        return []

    findings: "list[Finding]" = []
    for message in stale[:_MAX_INDIVIDUAL_FINDINGS]:
        # The first line of the body is the question's own headline, and it
        # is the only part worth putting in a finding title — the rest is
        # detail the operator reads in the thread, where it belongs.
        headline = (message.body or "").strip().splitlines()
        headline = headline[0].strip().strip("*") if headline else "(no text)"
        subject_ref = message.subject.ref
        findings.append(
            Finding(
                check_id="lead.chat-open-question",
                # Keyed on the MESSAGE id, not the subject: two questions
                # about one order at different times are two unanswered
                # questions, and a fingerprint that collapsed them would
                # make acknowledging one silence the other.
                subject_id=f"chat:{message.id}",
                severity="medium",
                title=(
                    f"LEAD question unanswered for over {_age_phrase(hours)}: {headline}"
                ),
                detail=(
                    f"The resident LEAD asked about {subject_ref} at {message.ts} "
                    f"and the question is still open — nobody has answered it and "
                    f"the condition has not resolved or been acknowledged.\n"
                    f"Message: {message.id}\n"
                    f"Read the thread with `mso lead chat log --open`; answer in it "
                    f"with `mso lead chat say \"...\"` or from the Hub. This check "
                    f"clears when the question is answered, its finding resolves, or "
                    f"you acknowledge that finding."
                ),
                firstSeenAt=message.ts or context.now.isoformat(),
                suggestedCommand="mso lead chat log --open",
                scope="workspace",
                requires=(),
            )
        )

    overflow = len(stale) - len(findings)
    if overflow > 0:
        findings.append(
            Finding(
                check_id="lead.chat-open-question",
                subject_id="chat:overflow",
                severity="medium",
                title=(
                    f"{overflow} further LEAD question(s) unanswered for over "
                    f"{_age_phrase(hours)}"
                ),
                detail=(
                    f"{len(stale)} open LEAD questions are older than {hours}h; the "
                    f"{len(findings)} oldest are reported individually above and the "
                    f"remaining {overflow} are counted here rather than listed, to keep "
                    f"one unread thread from filling the whole patrol report. None has "
                    f"been dropped — `mso lead chat log --open` lists them all."
                ),
                firstSeenAt=context.now.isoformat(),
                suggestedCommand="mso lead chat log --open",
                scope="workspace",
                requires=(),
            )
        )
    return findings
