"""maestro/patrol/checks/voyages.py — voyage-level hygiene.

PLAN-PLN-MSO-2026-0504 §4.6: BUG-MSO-2026-0476 is fixed at source (`mso
review approve` releases pre-filed dependents; it never created them) but the
residual duty survives: a voyage whose only order(s) are a completed,
standalone plan, with nothing else ever filed, still needs a Captain to cut
build orders. `maestro.hub.phase.compute_voyage_phase()` already carries this
exact rule for the Hub's own `needs_attention` phase — this check reuses its
`_is_plan_only` / `classify_status` building blocks (the BUG-MSO-2026-0426
one-implementation principle) rather than re-deriving "is this order
plan-only and complete" a second time.

Five real MSO voyages hit exactly this shape before being manually resolved —
VOY-MSO-2026-0094/0100/0130/0145/0147 — and are used as the regression test
fixtures (now archived to `voyages/complete/`, so they no longer reproduce
live; the fixtures recreate their PLANNED-and-stuck shape from their real
ids/titles/orders).

FTR-MSO-2026-0535 (plan order 5) adds two more voyage-family checks:

- `voyages.pr-ci-state` — goes through the `scm`/`ci` providers (§10) rather
  than shelling `gh` directly, and raises `CheckSkipped` (never returns an
  empty, pass-shaped list) when either provider is unavailable — §10.3's
  "skipped, never a false green" rule, and this order's own AC.
- `voyages.merged-not-archived` — calls
  `maestro.core.fleet_runner.run_housekeeping_sweep(dry_run=True)` verbatim
  (no second implementation of merge/archive detection) and reports every
  voyage its dry run says it WOULD archive. That function resolves its own
  workspace via the process-wide `get_artefact_root()` rather than accepting
  an explicit root, so this check temporarily points that resolution at
  `context.artefact_root` for the duration of the call — otherwise every
  section of a `mso doctor --all-projects` run would report whichever
  workspace the process happened to start in, not each project's own state.
  BUG-MSO-2026-0643 F2: this MUST go through
  `maestro.core.order_retry.workspace_scope()` (a locked context manager
  around `fleet_runner._MAESTRO_DIR_OVERRIDE`), never a bare
  `os.environ["MAESTRO_DIR"]` set/restore — `_resolve_workspace_dir` checks
  the override BEFORE the env var, so an unlocked env-var write here can lose
  a race to a concurrent Hub Run for a different workspace and compute this
  check's verdict (including a real archive-affecting dry run) against the
  WRONG workspace's plane. `workspace_scope()` is the one primitive every
  other caller of this override already shares (order_retry itself, and
  `bands.py`'s D7 `voyage.reconcile`/`artefact.sweep` actions).

BUG-MSO-2026-0604 (PLAN-PLN-MSO-2026-0592 §3.4, plan order 11) adds the
inverse pair to `voyages.merged-not-archived` — that check watches "merged
but not archived"; these watch the two ways an archived/annotated manifest's
merge claim can itself be wrong:

- `voyages.archived-not-merged` — a voyage sits in `voyages/complete/`
  claiming its PR merged, but re-deriving the merge state via
  `maestro.core.fleet_runner.resolve_voyage_merge_state()` (FTR-MSO-2026-0600,
  Captain decision D3(a) — the ONE resolver every merge-state consumer must
  share) disagrees. GH #375's exact shape.
- `voyages.merged-missing-mergedat` — a voyage manifest carries `merged:
  true` with no `mergedAt` — the impossible-record / empty-string-sentinel
  shape that let GH #375's corrupted record defeat every downstream presence
  check (FTR-MSO-2026-0600 rule 3: `null`, never `""`).

Both consume `resolve_voyage_merge_state()` and derive no merge state of
their own — the entire point of Captain decision D3(a) is one derivation,
and a doctor check with its own copy would reintroduce exactly what
FTR-MSO-2026-0600 removed. Both use the same `workspace_scope()` override as
`voyages.merged-not-archived`, since `resolve_voyage_merge_state()` also
resolves its workspace via `get_artefact_root()`.

BUG-MSO-2026-0922 adds `voyages.pr-still-draft` — the backstop for a
promote-on-finalisation (FTR-MSO-2026-0287) that failed, leaving a COMPLETE
voyage's PR in draft so its end-of-voyage CI never fires and it cannot be
merged, while every Maestro surface correctly reports "Final review". It is
deliberately the INVERSE-scoped sibling of `voyages.pr-ci-state`: that check
reads `voyages/active/` (a voyage still in flight), this one reads
`voyages/complete/` too, because `sweep_decks` archives the manifest BEFORE it
calls `promote_voyage_pr_ready` — so the incident's own voyage was already in
`complete/` when its promotion timed out. See the block comment above the
check for the incident and its two cost bounds.

BUG-MSO-2026-0793 adds `voyages.no-orders` — the backstop for a voyage with
an EMPTY `orders` manifest, which nothing can ever dispatch from.
`voyages.planned-no-work` deliberately skips that shape (it needs orders to
classify), so VOY-MSO-2026-0791 — created in the Hub with a full planning
brief and no order — sat inert, invisible to every check, until the Captain
asked. The Hub wizard now files a planning order by default; this check
catches every other way an empty voyage happens (hand-minted, opt-out, a
future integration). Report-only: no writer, no suggested command (the CLI's
`mso order create --voyage` does not attach to the manifest, so suggesting it
would propose a fix that recreates the bug).
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from maestro.hub.phase import _is_plan_only, classify_status, merge_metadata_trustworthy
from maestro.core.artefact_json import decode_artefact_bytes
from maestro.patrol.registry import CheckContext, CheckSkipped, Finding, check

_ORDER_QUEUE_DIRS = (
    "queues/orders", "queues/bugs", "queues/security", "queues/defects",
    "queues/requests", "queues/breakdown", "queues/high-level",
    "queues/review", "queues/proposed", "queues/escalations",
)


def _load_json_safe(path: Path):
    # BUG-MSO-2026-0819: decode tolerantly — a cp1252 artefact must still be
    # read, not silently dropped; hygiene.artefact-encoding reports the file.
    try:
        return json.loads(decode_artefact_bytes(path.read_bytes())[0])
    except Exception:
        return None


def _order_status_and_role_sequence(artefact_root: Path, order_id: str) -> "tuple[str, list]":
    """Best-effort ``(status, roleSequence)`` for *order_id*.

    Archive first (an order's terminal record), then the live queues. This is
    deliberately simpler than `hub.phase`'s full ledger-aware resolution — a
    patrol check reads on-disk artefacts only, with no runtime process
    dependency (works with the dispatcher stopped, per this order's own
    acceptance criteria), so it does not replay the order ledger.
    """
    for sub, default in (("orders/complete", "COMPLETE"), ("orders/failed", "FAILED")):
        data = _load_json_safe(artefact_root / sub / f"{order_id}.json")
        if data:
            return str(data.get("status") or default).upper(), data.get("roleSequence") or []
    for sub in _ORDER_QUEUE_DIRS:
        data = _load_json_safe(artefact_root / sub / f"{order_id}.json")
        if data:
            return str(data.get("status") or "PENDING").upper(), data.get("roleSequence") or []
    return "PENDING", []


def _order_id_of(entry) -> str:
    if isinstance(entry, dict):
        return str(entry.get("orderId") or entry.get("id") or "")
    return str(entry)


@check(id="voyages.planned-no-work", severity="high")
def voyages_planned_no_work(context: CheckContext) -> "list[Finding]":
    findings: "list[Finding]" = []
    voyages_dir = context.artefact_root / "voyages" / "active"
    if not voyages_dir.exists():
        return findings

    # BUG-MSO-2026-0775: a planning voyage whose plan was cut into separate
    # build voyages DID have its build orders filed — just not on its own
    # manifest. Read the link in both directions (the one shared reader).
    from maestro.core.plan_links import load_voyage_manifests, plan_link_index
    linked_builds = plan_link_index(load_voyage_manifests(context.artefact_root))

    for voyage_file in sorted(voyages_dir.glob("*.json")):
        data = _load_json_safe(voyage_file)
        if not data:
            continue

        voyage_id = data.get("id") or data.get("voyageId") or voyage_file.stem
        order_ids = [oid for oid in (_order_id_of(o) for o in (data.get("orders") or [])) if oid]
        if not order_ids:
            continue
        if linked_builds.get(str(voyage_id)):
            continue

        members = [
            (oid, *_order_status_and_role_sequence(context.artefact_root, oid))
            for oid in order_ids
        ]
        all_plan_only = all(_is_plan_only(role_seq) for _, _, role_seq in members)
        all_complete = all(classify_status(status) == "complete" for _, status, _ in members)
        # BUG-MSO-2026-0569: an inconsistent merged=true/mergedAt="" record
        # must not silently suppress this finding.
        pr_merged = merge_metadata_trustworthy(data)

        if not (all_plan_only and all_complete and not pr_merged):
            continue

        findings.append(
            Finding(
                check_id="voyages.planned-no-work",
                subject_id=voyage_id,
                severity="high",
                title=f"{voyage_id}: plan approved but no build orders were filed",
                detail=(
                    f"All {len(order_ids)} order(s) on this voyage "
                    f"({', '.join(order_ids)}) are standalone plan-only orders and are "
                    "complete, but no PR was ever merged for it — the plan was approved "
                    "and nothing was queued to build it (BUG-MSO-2026-0476)."
                ),
                firstSeenAt=context.now.isoformat(),
                suggestedCommand=None,
                scope="workspace",
                requires=(),
            )
        )

    return findings


# ---------------------------------------------------------------------------
# voyages.no-orders (BUG-MSO-2026-0793)
# ---------------------------------------------------------------------------

_NO_ORDERS_DEFAULT_AGE_MINUTES = 60.0


def _as_utc(value: datetime) -> datetime:
    """A naive timestamp is treated as UTC, so naive and aware compare."""
    return value.replace(tzinfo=timezone.utc) if value.tzinfo is None else value


def _voyage_created_at(data: dict, voyage_file: Path) -> "datetime | None":
    """Best-effort creation time: ``createdAt``, then ``startedDate``
    (midnight UTC), then the manifest's mtime. A manifest with no timestamp
    is NEVER skipped for that reason — an ancient hand-minted voyage is
    exactly the case this backstop exists for."""
    for key in ("createdAt", "startedDate"):
        raw = data.get(key)
        if not isinstance(raw, str) or not raw.strip():
            continue
        text = raw.strip()
        if text.endswith("Z"):
            text = text[:-1] + "+00:00"
        try:
            return _as_utc(datetime.fromisoformat(text))
        except ValueError:
            continue
    try:
        return datetime.fromtimestamp(voyage_file.stat().st_mtime, tz=timezone.utc)
    except OSError:
        return None


@check(id="voyages.no-orders", severity="high")
def voyages_no_orders(context: CheckContext) -> "list[Finding]":
    """BUG-MSO-2026-0793: an active, non-parked voyage whose ``orders``
    manifest is empty and older than ``ageMinutes`` (default 60). Nothing can
    ever dispatch from it. See the module docstring for the incident."""
    from maestro.core.fleet_runner import _SWEEPABLE_VOYAGE_STATUSES

    findings: "list[Finding]" = []
    voyages_dir = context.artefact_root / "voyages" / "active"
    if not voyages_dir.exists():
        return findings

    try:
        age_minutes = float(
            context.params_for("voyages.no-orders").get(
                "ageMinutes", _NO_ORDERS_DEFAULT_AGE_MINUTES))
    except (TypeError, ValueError):
        age_minutes = _NO_ORDERS_DEFAULT_AGE_MINUTES
    now = _as_utc(context.now)

    for voyage_file in sorted(voyages_dir.glob("*.json")):
        data = _load_json_safe(voyage_file)
        if not isinstance(data, dict):
            continue

        voyage_status = str(data.get("status") or "").upper()
        if voyage_status and voyage_status not in _SWEEPABLE_VOYAGE_STATUSES:
            continue  # deliberately parked (HELD/PAUSED/...) — not stranded

        if any(_order_id_of(o) for o in (data.get("orders") or [])):
            continue

        created_at = _voyage_created_at(data, voyage_file)
        if created_at is None:
            continue
        age = (now - created_at).total_seconds() / 60.0
        if age < age_minutes:
            continue  # young enough to still be mid-creation

        voyage_id = data.get("id") or data.get("voyageId") or voyage_file.stem
        voyage_title = str(data.get("title") or "").strip()
        findings.append(
            Finding(
                check_id="voyages.no-orders",
                subject_id=voyage_id,
                severity="high",
                title=f"{voyage_id}: voyage has no orders — nothing will ever dispatch",
                detail=(
                    f"{voyage_id}"
                    + (f" ('{voyage_title}')" if voyage_title else "")
                    + f" has an empty orders manifest and is {int(age)} minute(s) old — "
                    "the dispatcher has nothing to find, so it will sit inert forever "
                    "(BUG-MSO-2026-0793). File an order into it from the Hub's New order "
                    "drawer with this voyage selected (which attaches it), or run "
                    f"`mso order create ... --voyage {voyage_id}` AND add the new id to "
                    "the manifest's orders[] (the CLI flag alone does not attach). If the "
                    "voyage was abandoned, archive it instead."
                ),
                firstSeenAt=context.now.isoformat(),
                suggestedCommand=None,
                scope="workspace",
                requires=(),
            )
        )

    return findings


# ---------------------------------------------------------------------------
# voyages.pr-ci-state (FTR-MSO-2026-0535)
# ---------------------------------------------------------------------------

# gh's own CI conclusion vocabulary that means "this run did not succeed" —
# matched case-insensitively since the shipped `github_actions` provider
# passes `gh pr checks --json`'s raw `conclusion` field straight through.
_FAILING_CONCLUSIONS = {"failure", "cancelled", "timed_out", "action_required", "startup_failure"}
# Values of the raw `status`/`state` field that mean "still running" — a
# check whose conclusion is unset and whose state is one of these is normal,
# transient "pending" and is not itself a finding.
_IN_PROGRESS_STATES = {"in_progress", "queued", "pending", "requested", "waiting"}


def _pr_ci_state(checks_list: "list[dict]") -> str:
    """Classify a PR's overall CI state from a `ci` provider's
    `checks_for_pr()` output. Returns one of "green", "pending", "failing",
    "unknown" — deliberately never silently returning "green" for an
    inconclusive input (order-5 AC: "degrades to unknown, never a false
    green")."""
    if not checks_list:
        return "unknown"

    conclusions = [str(c.get("conclusion") or "").lower() for c in checks_list]
    if any(c in _FAILING_CONCLUSIONS for c in conclusions):
        return "failing"

    statuses = [str(c.get("status") or "").lower() for c in checks_list]
    if any(not conclusion and status in _IN_PROGRESS_STATES for conclusion, status in zip(conclusions, statuses)):
        return "pending"
    if all(conclusions) and all(c not in _FAILING_CONCLUSIONS for c in conclusions):
        return "green"
    return "unknown"


@check(id="voyages.pr-ci-state", severity="high", requires=("scm", "ci"))
def voyages_pr_ci_state(context: CheckContext) -> "list[Finding]":
    from maestro.providers import resolve_explain

    scm = resolve_explain("scm", workspace=context.workspace)
    ci = resolve_explain("ci", workspace=context.workspace)
    if not scm.available or not ci.available:
        reasons = [r.reason for r in (scm, ci) if not r.available]
        raise CheckSkipped(" ; ".join(reasons))

    findings: "list[Finding]" = []
    voyages_dir = context.artefact_root / "voyages" / "active"
    if not voyages_dir.exists():
        return findings

    for voyage_file in sorted(voyages_dir.glob("*.json")):
        data = _load_json_safe(voyage_file)
        if not data:
            continue
        voyage_id = data.get("id") or data.get("voyageId") or voyage_file.stem
        branch = data.get("branch")
        if not branch:
            continue

        pr = scm.provider.get_pr_for_branch(branch)
        if pr is None or scm.provider.pr_is_merged(pr):
            # No PR yet, or already merged — merge/CI-conclusion state is a
            # different check's concern (§12.3/§12.5 are LEAD-event-driven,
            # not part of this heartbeat-scope check).
            continue

        state = _pr_ci_state(ci.provider.checks_for_pr(pr))
        if state in ("green", "pending"):
            continue

        findings.append(
            Finding(
                check_id="voyages.pr-ci-state",
                subject_id=voyage_id,
                severity="high",
                title=f"{voyage_id}: PR CI is {state}",
                detail=(
                    f"PR #{pr.get('number')} ({pr.get('url', '') or branch}) for "
                    f"{voyage_id}'s branch '{branch}' reports CI state '{state}' via the "
                    f"'{ci.provider_id}' provider."
                ),
                firstSeenAt=context.now.isoformat(),
                suggestedCommand=None,
                scope="workspace",
                requires=("scm", "ci"),
            )
        )

    return findings


# ---------------------------------------------------------------------------
# voyages.stalled-order-deadlock (BUG-MSO-2026-0597)
# ---------------------------------------------------------------------------

def _dependents_held_behind(artefact_root: Path, stalled_id: str) -> "list[str]":
    """Order ids currently sitting in the live queues whose `dependsOn` /
    `dependencies` names *stalled_id* — the operator-actionable "what is
    this actually blocking" half of the deadlock that a bare
    `SWEEP_STALLED_ORDER` log line never named (BUG-MSO-2026-0597)."""
    held: "list[str]" = []
    for sub in _ORDER_QUEUE_DIRS:
        d = artefact_root / sub
        if not d.exists():
            continue
        for f in sorted(d.glob("*.json")):
            data = _load_json_safe(f)
            if not data:
                continue
            deps = data.get("dependsOn") or data.get("dependencies") or []
            if stalled_id in deps:
                held.append(str(data.get("orderId") or data.get("id") or f.stem))
    return held


@check(id="voyages.stalled-order-deadlock", severity="high")
def voyages_stalled_order_deadlock(context: CheckContext) -> "list[Finding]":
    """BUG-MSO-2026-0597: the operator-actionable half of what used to be
    ONLY a heartbeat-cadence log line. `fleet_runner.sweep_decks()` refuses
    to finalise a voyage that has a manifest order archived STALLED (not
    COMPLETE) and used to say so via an unthrottled `SWEEP_STALLED_ORDER`
    line on every dispatcher heartbeat — 121 identical copies were measured
    in one eight-hour window on the live MSO fleet (PLAN-PLN-MSO-2026-0592
    §6.4), which is now throttled to the same 300s cadence
    BUG-MSO-2026-0303's Eight-Bells-withheld WARN already uses. A throttled
    log line is still not a finding: nothing aggregates it, nothing ages it,
    and it never named what the stall was actually blocking downstream. This
    check reads the same on-disk state sweep_decks() does — reusing
    `fleet_runner._SWEEPABLE_VOYAGE_STATUSES` so "is this voyage in-flight"
    is answered identically in both places — and additionally names every
    dependent order held behind the stall.

    Each finding's ``subject_id`` is the stalled order's own id, which
    matches ``patrol.__init__._STABLE_SUBJECT_ID_RE`` (BUG-MSO-2026-0662 F3 /
    BUG-MSO-2026-0675 F2 — that regex, not a per-check opt-in, is the single
    source of truth for which subject ids ``run_single_check`` filters
    per-subject) — durable across re-checks, so re-running via `mso order
    retry <id>`'s Run button confirms THAT order specifically. Before the
    original fix, retrying one of several stalled orders reported "condition
    still present" (some OTHER order was still stalled) and left that
    order's own Run button wrongly enabled.
    """
    from maestro.core.fleet_runner import _SWEEPABLE_VOYAGE_STATUSES

    findings: "list[Finding]" = []
    voyages_dir = context.artefact_root / "voyages" / "active"
    if not voyages_dir.exists():
        return findings

    complete_dir = context.artefact_root / "orders" / "complete"

    for voyage_file in sorted(voyages_dir.glob("*.json")):
        data = _load_json_safe(voyage_file)
        if not data:
            continue

        voyage_status = (data.get("status") or "").upper()
        if voyage_status and voyage_status not in _SWEEPABLE_VOYAGE_STATUSES:
            continue  # deliberately parked (HELD/PAUSED/...) — not a deadlock

        voyage_id = data.get("id") or data.get("voyageId") or voyage_file.stem
        order_ids = [oid for oid in (_order_id_of(o) for o in (data.get("orders") or [])) if oid]

        for order_id in order_ids:
            order_data = _load_json_safe(complete_dir / f"{order_id}.json")
            if not order_data:
                continue
            if str(order_data.get("status") or "").upper() != "STALLED":
                continue

            dependents = _dependents_held_behind(context.artefact_root, order_id)

            # BUG-MSO-2026-0705 (AC3): a stall whose cause is a ROLE REJECTION
            # is not a generic STALLED — the fleet's own QA verdict named the
            # defect and the role that found it, and the recovery is a re-run
            # of the PREVIOUS role, not a bare retry. Reuse `role_rejection`'s
            # single describer/command pair so `mso doctor`, `mso status` and
            # the Hub all say the same sentence.
            from maestro.core import role_rejection

            rejection_desc = role_rejection.describe_rejection(order_data)
            command = (role_rejection.retry_command(order_id, order_data)
                       if rejection_desc else f"mso order retry {order_id}")

            if rejection_desc:
                title = f"{voyage_id}: {order_id} {rejection_desc}"
                detail = (
                    f"{order_id} is archived STALLED in {voyage_id}'s manifest, but it was "
                    f"REJECTED on review, not abandoned — {rejection_desc}. The voyage "
                    "cannot finalise while it stays that way."
                )
                report = (role_rejection.rejection_block(order_data) or {}).get("reportPath")
                if report:
                    detail += f" Reviewer's report: {report}."
            else:
                title = f"{voyage_id}: queued work deadlocked behind STALLED order {order_id}"
                detail = (
                    f"{order_id} is archived STALLED in {voyage_id}'s manifest — the "
                    "voyage cannot finalise while it stays that way."
                )
            if dependents:
                detail += (
                    f" {len(dependents)} dependent order(s) are held behind it: "
                    f"{', '.join(dependents)}."
                )
            detail += f" Recover with `{command}`."

            findings.append(
                Finding(
                    check_id="voyages.stalled-order-deadlock",
                    subject_id=order_id,
                    severity="high",
                    title=title,
                    detail=detail,
                    firstSeenAt=context.now.isoformat(),
                    suggestedCommand=command,
                    scope="workspace",
                    requires=(),
                )
            )

    return findings


# ---------------------------------------------------------------------------
# voyages.deadlocked (BUG-MSO-2026-0699)
# ---------------------------------------------------------------------------

@check(id="voyages.deadlocked", severity="high")
def voyages_deadlocked(context: CheckContext) -> "list[Finding]":
    """BUG-MSO-2026-0699: a voyage that can NEVER finish without an operator.

    Distinct from `voyages.stalled-order-deadlock` above, which reports one
    STALLED order and what it happens to block. This reports the VOYAGE-level
    verdict — every remaining order is transitively held behind a terminal
    non-COMPLETE order (STALLED / FAILED / CONVERGENCE_FAILED / VERIFY_FAILED /
    VERIFY_DEPS_FAILED / AUTO_SERIALIZE / operator-skipped) and no crew is on
    any of them. That is the thing the Captain could not see on 2026-09-09: the
    Hub board showed the held orders as held, `mso status` drew a 0% bar, and
    nothing anywhere said the voyage was finished as far as the fleet was
    concerned. A stalled order in a voyage that still has dispatchable work is
    NOT this finding — the fleet will keep going, and the per-order check above
    already covers it.

    Derives NOTHING of its own: the verdict comes from
    `maestro.core.deadlock.detect_deadlocked_voyages()`, the one shared
    classifier this order's AC1 requires, which `mso status`, the dispatcher's
    idle watchdog and `hub/phase.py` also call. A second copy here would
    reintroduce exactly the per-surface divergence that made the incident
    invisible.

    ``subject_id`` is the VOYAGE id — durable across re-checks
    (`patrol.__init__._STABLE_SUBJECT_ID_RE`), so the Hub's per-subject Run
    button re-confirms this voyage specifically rather than reporting "still
    present" because some other voyage is also stuck.
    """
    from maestro.core.deadlock import detect_deadlocked_voyages

    findings: "list[Finding]" = []
    for verdict in detect_deadlocked_voyages(context.artefact_root):
        findings.append(
            Finding(
                check_id="voyages.deadlocked",
                subject_id=verdict.voyage_id,
                severity="high",
                title=(
                    f"{verdict.voyage_id}: DEADLOCKED — blocked by "
                    f"{verdict.blocking_order_id} ({verdict.blocking_cause})"
                ),
                detail=verdict.detail(),
                firstSeenAt=context.now.isoformat(),
                suggestedCommand=verdict.suggested_command,
                scope="workspace",
                requires=(),
            )
        )
    return findings


# ---------------------------------------------------------------------------
# voyages.merged-not-archived (FTR-MSO-2026-0535)
# ---------------------------------------------------------------------------

@check(id="voyages.merged-not-archived", severity="low")
def voyages_merged_not_archived(context: CheckContext) -> "list[Finding]":
    from maestro.core.fleet_runner import run_housekeeping_sweep
    from maestro.core.order_retry import workspace_scope

    # See module docstring: run_housekeeping_sweep() resolves its own
    # workspace via the process-wide get_artefact_root() rather than an
    # explicit root parameter. Reusing it verbatim (this order's AC forbids a
    # second implementation) means pointing that resolution at THIS check's
    # artefact_root for the duration of the call.
    #
    # BUG-MSO-2026-0643 F2: this used to be a bare, unlocked
    # os.environ["MAESTRO_DIR"] set/restore. fleet_runner._resolve_workspace_dir
    # checks the process-global _MAESTRO_DIR_OVERRIDE BEFORE the env var, so a
    # concurrent Hub Run for another workspace holding workspace_scope() (or
    # order_retry itself) would win the race and this check would compute its
    # verdict — including a real `mso voyage reconcile` dry run — against the
    # WRONG workspace's plane. workspace_scope() is the one locked primitive
    # every other caller of this override (order_retry, bands.py's
    # voyage.reconcile/artefact.sweep D7 actions) already uses; using anything
    # else here reintroduces exactly the race order_retry.workspace_scope's
    # own docstring says must not happen in the Hub.
    try:
        with workspace_scope(context.artefact_root):
            report = run_housekeeping_sweep(dry_run=True)
    except Exception as exc:  # noqa: BLE001 — a broken sweep must self-skip, not crash the patrol
        raise CheckSkipped(f"skipped — housekeeping sweep unavailable: {exc}") from exc

    findings: "list[Finding]" = []
    for entry in report.get("changes", []):
        if entry.get("action") != "archived":
            continue
        voyage_id = entry.get("voyage") or "?"
        findings.append(
            Finding(
                check_id="voyages.merged-not-archived",
                subject_id=voyage_id,
                severity="low",
                title=f"{voyage_id}: merged but not yet archived",
                detail=(
                    f"{entry.get('reason', 'PR merged')} — `mso voyage reconcile` would "
                    "archive it now; nothing has run reconcile since the merge."
                ),
                firstSeenAt=context.now.isoformat(),
                suggestedCommand="mso voyage reconcile",
                scope="workspace",
                requires=(),
            )
        )
    return findings


# ---------------------------------------------------------------------------
# voyages.archived-not-merged / voyages.merged-missing-mergedat
# (BUG-MSO-2026-0604 — PLAN-PLN-MSO-2026-0592 §3.4, plan order 11)
# ---------------------------------------------------------------------------

def _voyage_claims_merged(voyage: dict) -> bool:
    """True if *voyage*'s manifest asserts its PR merged — the flat
    ``merged`` boolean, a linked ``mergedPR``, or a non-empty ``mergedAt``.
    Any one of these is a claim of completion; ``resolve_voyage_merge_state``
    is what checks whether the claim still holds."""
    if voyage.get("merged") is True:
        return True
    if voyage.get("mergedPR") is not None:
        return True
    if voyage.get("mergedAt"):
        return True
    return False


@check(id="voyages.archived-not-merged", severity="high")
def voyages_archived_not_merged(context: CheckContext) -> "list[Finding]":
    """GH #375's exact shape: a voyage sits in ``voyages/complete/`` claiming
    its PR merged, but re-deriving the merge state via THE one resolver
    (``resolve_voyage_merge_state`` — FTR-MSO-2026-0600, Captain decision
    D3(a)) disagrees. This check derives no merge state of its own — it
    calls the shared resolver and compares against the archived claim.

    An ``UNKNOWN`` re-derivation (gh/git unavailable, offline, rate-limited)
    is deliberately NOT a finding — absence of evidence is never evidence of
    absence (the plan's tri-state rule, §2.4: INDETERMINATE always fails
    open). Only a definite contradiction — ``CLOSED_UNMERGED``, ``OPEN`` or
    ``WRONG_BASE`` — fires.
    """
    from maestro.core.fleet_runner import resolve_voyage_merge_state
    from maestro.core.order_retry import workspace_scope

    findings: "list[Finding]" = []
    complete_dir = context.artefact_root / "voyages" / "complete"
    if not complete_dir.exists():
        return findings

    # BUG-MSO-2026-0643 F2: workspace_scope(), not a bare unlocked
    # os.environ["MAESTRO_DIR"] set/restore — see voyages_merged_not_archived
    # above for why the override (which _resolve_workspace_dir ranks ABOVE
    # the env var) needs the shared lock.
    #
    # BUG-MSO-2026-0670 F3: scope is entered PER ITERATION, not once around
    # the whole loop. `resolve_voyage_merge_state()` makes a gh/git round-trip
    # per voyage, and the prior "one `with` around the whole `for`" held the
    # process-global `_SCOPE_LOCK` (an RLock — cheap to re-acquire once per
    # voyage) for the sum of every voyage's network latency instead of one
    # voyage's — on an O(N)-voyage workspace that is O(N) times longer that
    # every other `workspace_scope()` caller in this process (a concurrent
    # Hub Run click, an order-retry POST) sits blocked. Per-iteration scoping
    # keeps the exact race-fix this lock exists for (BUG-0643 F2, BUG-0656
    # F1's both-mechanisms pinning) — the override is still pinned for every
    # resolver call — while shrinking the hold to one gh round-trip at a time
    # WORSE case: a concurrent scope-holder can now interleave BETWEEN this
    # check's voyages, so two different callers' `_MAESTRO_DIR_OVERRIDE`
    # pins can alternate voyage-by-voyage instead of one caller finishing
    # first — harmless here since each iteration reads its own already-loaded
    # `data`/`voyage_id` before entering the scope and only the resolver call
    # itself needs the pin.
    for voyage_file in sorted(complete_dir.glob("*.json")):
        data = _load_json_safe(voyage_file)
        if not data or not _voyage_claims_merged(data):
            continue

        voyage_id = data.get("id") or data.get("voyageId") or voyage_file.stem
        try:
            with workspace_scope(context.artefact_root):
                resolved = resolve_voyage_merge_state(data)
        except Exception:
            continue  # a broken re-derivation for one voyage must not sink the rest

        state = resolved.get("state")
        if state not in ("CLOSED_UNMERGED", "OPEN", "WRONG_BASE"):
            continue  # MERGED confirms the claim; UNKNOWN is indeterminate — fail open

        # BUG-MSO-2026-0637: a voyage whose work shipped under a DIFFERENT PR
        # is not this shape — the shared resolver already followed the
        # recorded supersession and resolved the SUPERSEDING PR, so reaching
        # here means that PR is not merged either. Say so, rather than letting
        # the finding read as if the closed original were the whole story.
        sup = resolved.get("supersession")
        sup_text = ""
        if sup:
            sup_text = (
                f" The manifest records PR #{sup['originalPrNumber']} as superseded "
                f"by PR #{sup['supersedingPrNumber']}, and that superseding PR "
                f"resolves '{state}' as well — the supersession does not account "
                "for the missing merge.")

        findings.append(
            Finding(
                check_id="voyages.archived-not-merged",
                subject_id=voyage_id,
                severity="high",
                title=f"{voyage_id}: archived as merged, but the PR was never merged",
                detail=(
                    "This voyage is archived in voyages/complete/ claiming its PR "
                    f"merged, but resolve_voyage_merge_state() now reports "
                    f"'{state}' — GH #375's exact shape (a side-channel merge, or "
                    "a manifest written before the PR/git contradiction was "
                    "resolvable, recorded completion the PR record does not "
                    "support). Confirm what actually happened before treating "
                    "this voyage's work as shipped." + sup_text
                ),
                firstSeenAt=context.now.isoformat(),
                suggestedCommand=None,
                scope="workspace",
                requires=(),
            )
        )

    return findings


@check(id="voyages.merged-missing-mergedat", severity="medium")
def voyages_merged_missing_mergedat(context: CheckContext) -> "list[Finding]":
    """The impossible-record shape (PLAN-PLN-MSO-2026-0592 §3.3 rule 3):
    ``merged: true`` with no ``mergedAt`` — the empty-string-sentinel bug
    that let GH #375's corrupted record survive every downstream presence
    check. Scans both ``voyages/active/`` (annotated mid-flight) and
    ``voyages/complete/`` (the archive path) — the flat ``merged`` boolean is
    written by both. Consumes ``resolve_voyage_merge_state`` to attach the
    currently-resolvable ``mergedAt`` to the finding rather than re-deriving
    the presence check itself; the resolver's outcome never gates whether
    this fires — a manifest self-contradiction is a finding regardless of
    whether live evidence can now backfill it.
    """
    from maestro.core.fleet_runner import resolve_voyage_merge_state
    from maestro.core.order_retry import workspace_scope

    findings: "list[Finding]" = []
    # BUG-MSO-2026-0643 F2: workspace_scope(), not a bare unlocked
    # os.environ["MAESTRO_DIR"] set/restore — see voyages_merged_not_archived
    # above for why the override (which _resolve_workspace_dir ranks ABOVE
    # the env var) needs the shared lock.
    #
    # BUG-MSO-2026-0670 F3: scope PER ITERATION (per voyage's resolver call),
    # not once around both directories' whole nested loop — see the matching
    # note in voyages_archived_not_merged above for the full trade-off
    # (shrinks the global-lock hold from O(N) gh round-trips to one at a
    # time; worse case is a concurrent scope-holder can now interleave
    # between voyages, which is harmless since each iteration's `data`/
    # `voyage_id` are already loaded before the scope is entered).
    for sub in ("active", "complete"):
        voyages_dir = context.artefact_root / "voyages" / sub
        if not voyages_dir.exists():
            continue
        for voyage_file in sorted(voyages_dir.glob("*.json")):
            data = _load_json_safe(voyage_file)
            if not data:
                continue
            if data.get("merged") is not True:
                continue
            if data.get("mergedAt"):
                continue  # present and non-empty — the record is sound

            voyage_id = data.get("id") or data.get("voyageId") or voyage_file.stem
            resolved_at = None
            try:
                with workspace_scope(context.artefact_root):
                    resolved_at = resolve_voyage_merge_state(data).get("mergedAt")
            except Exception:
                pass

            backfill = (
                f"resolve_voyage_merge_state() currently resolves "
                f"mergedAt={resolved_at!r} — the manifest can be backfilled "
                "with that value."
                if resolved_at else
                "resolve_voyage_merge_state() cannot currently re-derive a "
                "mergedAt either (gh/git unavailable, or the PR record itself "
                "never carried one)."
            )

            findings.append(
                Finding(
                    check_id="voyages.merged-missing-mergedat",
                    subject_id=voyage_id,
                    severity="medium",
                    title=f"{voyage_id}: merged=true but mergedAt is missing",
                    detail=(
                        "This voyage's manifest asserts merged=true with no "
                        "mergedAt — the impossible-record shape that let GH "
                        "#375's corrupted record defeat every downstream "
                        "presence check (rule 3: null, never \"\"). " + backfill
                    ),
                    firstSeenAt=context.now.isoformat(),
                    suggestedCommand=None,
                    scope="workspace",
                    requires=(),
                )
            )

    return findings


# ---------------------------------------------------------------------------
# voyages.plan-decomposition-failed (FTR-MSO-2026-0860, plan D6)
# ---------------------------------------------------------------------------
#
# This check is NOT optional garnish on the decomposition feature — it is the
# half that keeps detection from going BACKWARDS.
#
# `voyages.planned-no-work` above requires EVERY manifest order to be complete
# before it reports. A decomposition order joins the manifest and is, by
# design, not complete while it runs. So the moment one stalls, fails, or sits
# in review with a breakdown nobody can parse, `all_complete` is false and the
# existing PLAN_ORPHANED detector goes quiet — the voyage is exactly as stuck
# as it was before FTR-MSO-2026-0860, and now nothing says so. Shipping the
# feature without this check would make the situation worse than not shipping
# it at all.


def _decomposition_order_state(artefact_root: Path, order_id: str) -> "tuple[str, dict]":
    """``(status, data)`` for a decomposition order, archive first."""
    for sub, default in (("orders/complete", "COMPLETE"), ("orders/failed", "FAILED")):
        data = _load_json_safe(artefact_root / sub / f"{order_id}.json")
        if data:
            return str(data.get("status") or default).upper(), data
    for sub in _ORDER_QUEUE_DIRS:
        data = _load_json_safe(artefact_root / sub / f"{order_id}.json")
        if data:
            return str(data.get("status") or "PENDING").upper(), data
    return "MISSING", {}


@check(id="voyages.plan-decomposition-failed", severity="high")
def voyages_plan_decomposition_failed(context: CheckContext) -> "list[Finding]":
    from maestro.core import plan_decomposition

    findings: "list[Finding]" = []
    voyages_dir = context.artefact_root / "voyages" / "active"
    if not voyages_dir.exists():
        return findings

    for voyage_file in sorted(voyages_dir.glob("*.json")):
        data = _load_json_safe(voyage_file)
        if not data:
            continue
        marker = data.get(plan_decomposition.VOYAGE_MARKER_FIELD)
        if not isinstance(marker, dict):
            continue
        decomp_id = str(marker.get("orderId") or "")
        if not decomp_id:
            continue

        voyage_id = data.get("id") or data.get("voyageId") or voyage_file.stem
        plan_order = str(marker.get("planOrder") or "")
        status, order = _decomposition_order_state(context.artefact_root, decomp_id)

        problem = ""
        remedy = f"mso order retry {decomp_id} --role PLN"

        if status == "MISSING":
            problem = (
                f"the voyage's manifest records decomposition order {decomp_id}, "
                "but no order with that id exists anywhere on the artefact plane — "
                "the marker outlived the order it names")
            remedy = None
        elif status in ("FAILED", "STALLED", "CANCELLED"):
            problem = (
                f"decomposition order {decomp_id} is {status} — it never produced "
                "a breakdown, so nothing was filed to build this plan")
        elif status == "COMPLETE":
            # A COMPLETE decomposition order that filed nothing is the silent
            # failure this check exists for: its own status says success.
            if not plan_decomposition.recorded_batch(order):
                problem = (
                    f"decomposition order {decomp_id} is COMPLETE but records no "
                    "filed batch — it was approved (or archived with the plan gate "
                    "off) without minting any build orders")
                remedy = None
        elif status == "NAV_REVIEW_PENDING":
            # Waiting on the Captain is NORMAL and is not reported here
            # (orders.awaiting-approval owns the age dimension). What IS
            # reported is a breakdown that cannot be applied even if approved —
            # the Captain would click approve and get a refusal.
            doc = plan_decomposition.plan_document_path(context.artefact_root, decomp_id)
            # SEC-001: this read is the UNATTENDED one — it runs on every
            # `mso doctor` and every resident-LEAD tick, with no human in the
            # loop, over a document an autonomous crew authored. It goes
            # through the same bounded helper the approve path uses, so an
            # oversized document is refused here too rather than parsed.
            unreadable = ""
            try:
                text = plan_decomposition.read_plan_document(doc)
            except plan_decomposition.DecompositionManifestError as exc:
                text, unreadable = None, str(exc)
            except OSError:
                text = None
            if text is None and unreadable:
                problem = (
                    f"decomposition order {decomp_id} is awaiting approval but its "
                    f"breakdown cannot be read: {unreadable} Approving it will be "
                    "refused, and the order will stay in review")
            elif text is None:
                problem = (
                    f"decomposition order {decomp_id} is awaiting approval but its "
                    f"plan document {doc.name} does not exist — there is no "
                    "breakdown to approve, and approving it will be refused")
            else:
                try:
                    plan_decomposition.parse_manifest(
                        text, plan_order=plan_order, voyage_id=str(voyage_id),
                        max_orders=plan_decomposition.configured_max_orders(
                            context.artefact_root))
                except Exception as exc:   # noqa: BLE001 — the message IS the finding
                    problem = (
                        f"decomposition order {decomp_id} is awaiting approval but "
                        f"its breakdown cannot be parsed: {exc}. Approving it will "
                        "be refused, and the order will stay in review")

        if not problem:
            continue

        findings.append(
            Finding(
                check_id="voyages.plan-decomposition-failed",
                subject_id=str(voyage_id),
                severity="high",
                title=f"{voyage_id}: plan decomposition did not produce build orders",
                detail=(
                    f"Plan {plan_order or '(unrecorded)'} was approved and Maestro "
                    f"filed a decomposition order to break it down, but {problem}. "
                    "Note that voyages.planned-no-work cannot see this: that check "
                    "requires every manifest order to be complete, and the "
                    "decomposition order on this manifest is not — which is exactly "
                    "why this check exists (FTR-MSO-2026-0860 D6)."
                ),
                firstSeenAt=context.now.isoformat(),
                suggestedCommand=remedy,
                scope="workspace",
                requires=(),
            )
        )

    return findings


# ---------------------------------------------------------------------------
# voyages.pr-still-draft (BUG-MSO-2026-0922)
# ---------------------------------------------------------------------------
#
# The backstop for a promote-on-finalisation (FTR-MSO-2026-0287) that failed.
# `fleet_runner.promote_voyage_pr_ready` now retries a transient failure
# (BUG-MSO-2026-0922), but retries have a ceiling: a longer outage, an expired
# `gh` auth token, or a provider-side refusal still leaves a finalised voyage's
# PR sitting in DRAFT — which means its end-of-voyage CI run never fires and it
# cannot be merged, while `mso status` and the Hub both correctly report the
# voyage as "Final review". That contradiction is the whole incident:
#
#   2026-09-23 20:00:26 | SWEEP | Voyage VOY-MSO-2026-0910 auto-completed
#   2026-09-23 20:01:28 | WARN  | Voyage PR promote-on-finalisation error:
#                                 Command '['gh','pr','ready',...]' timed out
#
# PR #458 stayed draft until the Captain noticed the disagreement BY EYE and ran
# `gh pr ready 458`. Nothing in `mso status`, `mso doctor` or the Hub said so.
#
# Deliberately NOT mapped in `maestro.lead.bands.FINDING_ACTION_MAP`. The
# `pr.promote-draft` action exists and stays OBSERVE by Captain ruling D7
# because promoting a PR starts CI, which spends money — so this check
# PROPOSES the remedy (`suggestedCommand`) and a human runs it, exactly like
# `hygiene.stale-worktrees` post-narrowing.
#
# Two bounds keep this cheap. It only asks the provider about a voyage that is
# (a) finalised COMPLETE, (b) not already recorded merged, and (c) finalised
# recently (`maxAgeHours`, default 72) — a promote that failed is an ACUTE,
# freshly-actionable condition, whereas this workspace's `voyages/complete/`
# holds 60+ old manifests that simply predate the `merged` field and would
# otherwise cost a `gh` round trip each, every tick. A hard `maxVoyages` cap
# (default 10, newest first) bounds it even when the recency window is widened.

_PR_DRAFT_DEFAULT_MAX_AGE_HOURS = 72.0
_PR_DRAFT_DEFAULT_MAX_VOYAGES = 10


def _voyage_completed_at(data: dict, voyage_file: Path) -> "datetime | None":
    """Best-effort finalisation time: ``completedAt``, then ``completedDate``
    (a bare ``YYYY-MM-DD``, read as midnight UTC), then the manifest's mtime.

    Mirrors :func:`_voyage_created_at` rather than re-deriving a second date
    convention. ``None`` only when the manifest carries no usable date AND its
    mtime is unreadable.
    """
    for key in ("completedAt", "completedDate", "mergedAt"):
        raw = data.get(key)
        if not isinstance(raw, str) or not raw.strip():
            continue
        text = raw.strip()
        if text.endswith("Z"):
            text = text[:-1] + "+00:00"
        try:
            return _as_utc(datetime.fromisoformat(text))
        except ValueError:
            continue
    try:
        return datetime.fromtimestamp(voyage_file.stat().st_mtime, tz=timezone.utc)
    except OSError:
        return None


def _draft_pr_candidates(context: CheckContext, max_age_hours: float,
                         max_voyages: int) -> list:
    """Finalised, not-recorded-merged voyages recent enough to be worth asking
    the provider about — newest first, capped at *max_voyages*.

    A voyage is read from BOTH ``voyages/complete/`` and ``voyages/active/``:
    ``sweep_decks`` MOVES the manifest to ``complete/`` and only THEN calls
    ``promote_voyage_pr_ready``, so the incident's own voyage was already
    archived when its promotion failed — a check that read ``active/`` alone
    (as ``voyages.pr-ci-state`` does, correctly, for its own question) could
    never have seen it.
    """
    now = _as_utc(context.now)
    candidates: list = []
    for sub in ("voyages/complete", "voyages/active"):
        vdir = context.artefact_root / sub
        if not vdir.exists():
            continue
        for voyage_file in sorted(vdir.glob("*.json")):
            data = _load_json_safe(voyage_file)
            if not isinstance(data, dict):
                continue
            if str(data.get("status") or "").upper() != "COMPLETE":
                continue  # not finalised — nothing should have been promoted yet
            if data.get("merged"):
                continue  # a merged PR is not a draft; GitHub cannot merge one
            if not data.get("branch"):
                continue  # no branch — see _lookup_pr on why number is unusable here
            completed_at = _voyage_completed_at(data, voyage_file)
            if completed_at is None:
                continue
            if (now - completed_at).total_seconds() / 3600.0 > max_age_hours:
                continue
            candidates.append((voyage_file, data, completed_at))

    candidates.sort(key=lambda row: row[2] or datetime.min.replace(tzinfo=timezone.utc),
                    reverse=True)
    return candidates[:max_voyages]


def _lookup_pr(provider, data: dict):
    """The voyage's PR record, looked up BY BRANCH — deliberately NOT by number.

    This is a conscious exception to FTR-MSO-2026-0426's "look it up BY NUMBER"
    rule, and the exception matters: that rule exists for MERGE state, and
    ``get_pr_by_id`` on the GitHub provider projects
    ``scm_lifecycle.GH_PR_BY_NUMBER_JQ``, which selects
    ``state/merged/mergedAt/mergeCommit/number/url/baseRefName`` — **and no
    draft field at all**. ``normalise_pr`` then defaults the absent key, so that
    record reports ``isDraft: False`` for every PR, including a draft one.
    Verified against the live draft PR #459 while building this check: the
    by-number record said ``isDraft: False`` and the by-branch record said
    ``isDraft: True`` for the same PR.

    Asking by number would therefore produce exactly the FALSE GREEN §10.3
    forbids — the check would run, report nothing, and look healthy. So draft
    state is read only from a lookup that actually carries it
    (``gh pr view --json ...,isDraft``; Bitbucket's own records carry ``draft``
    on both paths). A voyage whose branch is gone cannot be answered here, and
    that is reported as nothing rather than as a pass — a deleted voyage branch
    means the PR merged or closed, which is not the stranded-draft case.

    ``None`` on any failure: a provider that could not answer cannot prove a
    draft either way, so the check stays silent (the ``voyages.pr-ci-state``
    precedent).
    """
    branch = data.get("branch")
    if not branch:
        return None
    try:
        pr = provider.get_pr_for_branch(branch)
    except Exception:
        return None
    return pr if isinstance(pr, dict) else None


@check(id="voyages.pr-still-draft", severity="high", requires=("scm",))
def voyages_pr_still_draft(context: CheckContext) -> "list[Finding]":
    """BUG-MSO-2026-0922: a COMPLETE voyage whose PR is still a draft.

    See the block comment above for the incident and the two cost bounds.
    """
    from maestro.providers import resolve_explain

    scm = resolve_explain("scm", workspace=context.workspace)
    if not scm.available:
        raise CheckSkipped(scm.reason)

    params = context.params_for("voyages.pr-still-draft")
    try:
        max_age_hours = float(params.get("maxAgeHours", _PR_DRAFT_DEFAULT_MAX_AGE_HOURS))
    except (TypeError, ValueError):
        max_age_hours = _PR_DRAFT_DEFAULT_MAX_AGE_HOURS
    try:
        max_voyages = int(params.get("maxVoyages", _PR_DRAFT_DEFAULT_MAX_VOYAGES))
    except (TypeError, ValueError):
        max_voyages = _PR_DRAFT_DEFAULT_MAX_VOYAGES

    findings: "list[Finding]" = []
    for voyage_file, data, _completed_at in _draft_pr_candidates(
            context, max_age_hours, max_voyages):
        voyage_id = data.get("id") or data.get("voyageId") or voyage_file.stem
        pr = _lookup_pr(scm.provider, data)
        if not isinstance(pr, dict):
            continue  # could not ask — never reported as a pass, never as a finding
        try:
            if scm.provider.pr_is_merged(pr) or not scm.provider.pr_is_draft(pr):
                continue
        except Exception:
            continue

        number = pr.get("number") or data.get("prNumber") or ""
        url = pr.get("url") or data.get("prUrl") or ""
        branch = data.get("branch") or pr.get("headRefName") or ""
        remedy = f"gh pr ready {number}" if number else None
        findings.append(
            Finding(
                check_id="voyages.pr-still-draft",
                subject_id=str(voyage_id),
                severity="high",
                title=f"{voyage_id}: finalised, but its PR is still a draft",
                detail=(
                    f"{voyage_id} is COMPLETE (all orders done) but PR "
                    f"#{number or '?'} {url or branch} is still a DRAFT on the "
                    f"'{scm.provider_id}' provider, so its end-of-voyage CI run has "
                    "not fired and it cannot be merged — while `mso status` and the "
                    "Hub both correctly report the voyage as in final review. "
                    "Promote-on-finalisation (FTR-MSO-2026-0287) evidently did not "
                    "succeed: grep lifecycle.log for 'mark-ready failed' / "
                    "'promote-on-finalisation' around this voyage's SWEEP line for "
                    "the cause. Promoting starts CI, which spends money, so this is "
                    "proposed for a human rather than done unattended (Captain "
                    "ruling D7). BUG-MSO-2026-0922."
                ),
                firstSeenAt=context.now.isoformat(),
                suggestedCommand=remedy,
                scope="workspace",
                requires=("scm",),
            )
        )

    return findings
