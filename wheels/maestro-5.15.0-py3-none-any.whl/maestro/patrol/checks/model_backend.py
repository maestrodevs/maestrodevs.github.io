"""maestro/patrol/checks/model_backend.py — the workspace's model backend.

FTR-MSO-2026-0870, order 6 of ``PLAN-PLN-MSO-2026-0864`` (Phase 3 — wiring the
model backend to the fleet). Two checks answering the two questions an operator
asks about a backend before a crew is ever launched:

* ``model.backend-credentials`` — can this workspace reach the backend it is
  configured for *right now*? A workspace whose SSO session has expired launches
  crews that come up, are REFUSED by ``crew.plan_model_backend``, and die.
* ``model.backend-unmapped-role`` — will every role's resolved model translate
  on that backend? A role pinned to a model the backend cannot serve is the same
  fault class, found before it costs an order rather than after.

**Both REPORT; neither remediates.** Checks are handed no writer
(``maestro/patrol/registry.py``, ``test_checks_have_no_writer_end_to_end``), and
the remedy here is not one Maestro could run anyway: **Maestro never runs ``aws
sso login``** — browser SSO needs a human at a browser, and a detached crew
launched with ``CREATE_NO_WINDOW`` has nobody to click the link.

**Works with the dispatcher stopped**, the same requirement
``dispatcher.heartbeat`` and ``dispatcher.scan-disagreement`` carry: nothing
here asks whether a dispatcher is alive. The live answer comes from probing the
configured backend, and ``state/model-backend.json`` is read only as
*corroboration* — a stale hold file left by a dispatcher that exited mid-hold
never fires anything on its own.

Three states, never two
-----------------------

``model_backend_gate.probe_model_backend`` answers ``available`` /
``unavailable`` / ``indeterminate``, and collapsing the third into either of the
others is the mistake this module exists not to make. *indeterminate* means
"this process could not DETERMINE the credential state" — no ``aws`` on PATH, an
instance-role machine, a probe that timed out. It is a :class:`CheckSkipped`
(never a pass, never a silent omission — §10.3), because a finding there would
put a permanent HIGH on every machine that authenticates some other way.

An **unconfigured** workspace — the overwhelmingly common case, and this
voyage's load-bearing negative property — is silent, and reaches that verdict
without instantiating or probing anything: ``providers.configured_entry`` reads
configuration only and is consulted first. ``probe_model_backend``'s verdict
alone cannot distinguish it (unconfigured, "providers unavailable" and
"configuration unreadable" all return ``indeterminate`` with an empty backend
id), which is exactly why the config read happens here rather than being
inferred from the probe.

Nothing composed here interpolates provider config, environment values or raw
AWS output (FTR-MSO-2026-0869 AC4, which names ``mso doctor --json``
explicitly — this module is what puts findings in it). Every string is either a
Maestro literal or a sentence the provider already composed and capped:
``hold_detail()`` for the title, ``verdict.reason`` / ``verdict.remedy``
verbatim, and :class:`ModelUnavailableOnBackend`'s own message.

Fail-open throughout, for ``model_backend_gate``'s reason: a check that can hold
a fleet by failing itself is worse than no check.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, Optional, Tuple

from maestro.core.model_backend_gate import (
    PROBE_TTL_SECONDS,
    hold_detail,
    probe_model_backend,
    read_backend_state,
)
from maestro.patrol.registry import CheckContext, CheckSkipped, Finding, check

#: The shipped default backend (``providers.DEFAULT_MODEL_BACKEND_ID``), on
#: which translation is the identity — so there is no such thing as an unmapped
#: role model there and ``model.backend-unmapped-role`` has nothing to say.
#: Named here rather than imported at module scope for the same reason every
#: provider import below is lazy: a patrol run must never pay for the provider
#: registry on a workspace that has no backend configured.
_DEFAULT_BACKEND_ID = "anthropic"

#: ``{resolved workspace path: ResolvedProvider}`` — a process-local, READ-ONLY
#: memo of ``providers.resolve_explain("model", workspace)``.
#:
#: Without it one ``mso doctor`` run resolves the backend twice (once inside
#: ``probe_model_backend``, once for the translation check), and for a backend
#: whose ``available()`` shells out that is a second subprocess for an answer
#: already in hand. ``probe_model_backend``'s TTL covers the probe half; this
#: covers the resolution half.
#:
#: It writes nothing to disk — the no-writer boundary is intact.
_RESOLVED: Dict[str, Any] = {}


def reset_cache() -> None:
    """Drop the resolution memo (tests, and any caller that has just changed a
    workspace's provider configuration)."""
    _RESOLVED.clear()


def _workspace_key(workspace: Path) -> str:
    try:
        return str(Path(workspace).resolve())
    except Exception:  # noqa: BLE001 — an unresolvable path still keys fine as text
        return str(workspace)


def _resolve_once(workspace: Path) -> Any:
    """``providers.resolve_explain("model", workspace)``, memoised per workspace.

    Returns ``None`` when the provider registry is unavailable — never raises.
    """
    key = _workspace_key(workspace)
    if key in _RESOLVED:
        return _RESOLVED[key]
    try:
        from maestro import providers
        resolved = providers.resolve_explain("model", workspace)
    except Exception:  # noqa: BLE001 — resolve_explain never raises; belt and braces
        resolved = None
    _RESOLVED[key] = resolved
    return resolved


def _configured_backend(workspace: Path) -> Tuple[Optional[str], Optional[str]]:
    """``(configured backend id or None, failure reason or None)``.

    Configuration only — ``providers.configured_entry`` is explicitly the half
    of ``resolve_explain`` that does NOT probe, so this costs no subprocess and
    instantiates no provider. A reason is returned (rather than raised) when the
    configuration could not be read at all, so the caller can self-skip instead
    of reporting a fault it has not established.
    """
    try:
        from maestro import providers
    except Exception as exc:  # noqa: BLE001
        return None, f"the provider registry is unavailable ({type(exc).__name__})"
    try:
        _tier, configured_id, _config = providers.configured_entry("model", workspace)
    except Exception as exc:  # noqa: BLE001
        return None, f"the workspace's provider configuration is unreadable ({type(exc).__name__})"
    return (str(configured_id) if configured_id else None), None


def _latched_hold_line(artefact_root: Path) -> str:
    """The dispatcher's own persisted hold, as a corroborating line — or ``""``.

    Read-only, and never a firing condition of its own: a dispatcher that exited
    while holding leaves this file behind, and a stale hold whose backend now
    probes ``available`` is not a fault. It only ever *adds* detail to a hold
    this check has independently established by probing.
    """
    try:
        state = read_backend_state(Path(artefact_root))
    except Exception:  # noqa: BLE001
        return ""
    if not isinstance(state, dict) or not state.get("held"):
        return ""
    updated_at = state.get("updatedAt") or "(time not recorded)"
    detail = state.get("detail") or ""
    line = f"The dispatcher latched this hold at {updated_at}"
    return f"{line} — {detail}" if detail else line


# ---------------------------------------------------------------------------
# model.backend-credentials
# ---------------------------------------------------------------------------

@check(id="model.backend-credentials", severity="high")
def model_backend_credentials(context: CheckContext) -> "list[Finding]":
    """The configured model backend cannot be reached from this machine.

    ``scope="workspace"`` deliberately, even though the *credentials* are often
    machine-wide: a model backend is a per-WORKSPACE choice
    (``maestro/providers/model/base.py``'s opening paragraph — two workspaces on
    one machine must be able to differ), so two workspaces can legitimately
    disagree about whether this is a fault.

    ==========================================  ==========================
    Situation                                   Result
    ==========================================  ==========================
    no product-repo root handed to the check    skip
    configuration unreadable                    skip
    no ``providers.model`` configured           ``[]`` — silent, unprobed
    probe ``available``                         ``[]``
    probe ``indeterminate``                     skip (the provider's reason)
    probe ``unavailable``                       one finding
    ==========================================  ==========================
    """
    workspace = context.workspace
    if workspace is None:
        # A model backend is resolved from the PRODUCT-repo root, not from
        # `.mso`. With no root to hand, guessing one would read some other
        # workspace's configuration — so degrade exactly as
        # `resolve_patrol_definition` does with `workspace=None`.
        raise CheckSkipped(
            "no product-repo root was handed to this check — a model backend is a "
            "per-workspace setting and cannot be resolved without one"
        )

    backend_id, config_error = _configured_backend(Path(workspace))
    if config_error is not None:
        raise CheckSkipped(config_error)
    if backend_id is None:
        # The common case: nothing configured, nothing instantiated, nothing
        # probed, no subprocess spawned. Silent on purpose.
        return []

    try:
        verdict = probe_model_backend(Path(workspace))
    except Exception as exc:  # noqa: BLE001 — probe_model_backend cannot raise; belt and braces
        raise CheckSkipped(f"the model backend could not be probed ({type(exc).__name__})")

    if verdict.state == "available":
        return []
    if verdict.state != "unavailable":
        # `indeterminate` — "could not determine", NOT "failed". Never a
        # finding: a machine with no `aws` CLI, or one authenticating by
        # instance role, would otherwise carry a permanent HIGH.
        reason = verdict.reason or "the backend's credential state could not be determined"
        raise CheckSkipped(
            f"model backend '{backend_id}' — {reason} (undeterminable, not a failure)"
        )

    backend = verdict.backend_id or backend_id
    lines = [
        f"Every crew launched against this workspace now would come up, be refused by "
        f"`crew.plan_model_backend`, and die — the '{backend}' model backend reports: "
        f"{verdict.reason or 'credentials are unavailable'}",
    ]
    if verdict.remedy:
        lines.append(verdict.remedy)
    latched = _latched_hold_line(context.artefact_root)
    if latched:
        lines.append(latched)
    lines.append(
        "Maestro never runs `aws sso login` for you: browser-based SSO needs a human at a "
        "browser, and a detached crew launched with CREATE_NO_WINDOW has nobody to click the "
        "link. It detects, holds new dispatch, leaves running crews alone, and tells you."
    )
    lines.append(
        f"The probe verdict is reused for {PROBE_TTL_SECONDS}s, so a hold lifts within one "
        "cache lifetime of the credentials actually returning — not the instant they do."
    )

    return [
        Finding(
            check_id="model.backend-credentials",
            # Carries a ':', so `patrol.__init__._STABLE_SUBJECT_ID_RE` treats
            # it as scoped/ephemeral rather than a durable order id — a backend
            # name is not a subject a `Run re-check` should filter on.
            subject_id=f"model-backend:{backend}",
            severity="high",
            # `hold_detail()` is the ONE shared sentence — `mso status`'s footer,
            # the Hub's `model_backend_detail` and this title cannot word the
            # same condition differently. Never re-word it here.
            title=hold_detail(verdict),
            detail="\n".join(lines),
            firstSeenAt=context.now.isoformat(),
            # Never a bare `aws sso login --profile <name>`: an interpolated
            # profile is provider config reaching `mso doctor --json`, and
            # `verdict.remedy` already carries the precise command whenever the
            # provider composed one.
            suggestedCommand="mso providers test model",
            scope="workspace",
            requires=(),
        )
    ]


# ---------------------------------------------------------------------------
# model.backend-unmapped-role
# ---------------------------------------------------------------------------

@check(id="model.backend-unmapped-role", severity="high")
def model_backend_unmapped_role(context: CheckContext) -> "list[Finding]":
    """A role is pinned to a model the configured backend cannot serve.

    Every crew for that role is REFUSED at launch (ADR-2: a backend never
    substitutes a model it cannot serve), so this is the credentials check's
    fault class found one step earlier — before it costs an order.

    Runs only when the credentials check would be silent-clean. An unconfigured
    workspace, the default ``anthropic`` backend (where translation is the
    identity) and a backend that is not currently reachable all return ``[]``:
    the last of those is not a skip, because the sibling check is already
    reporting that exact condition and two findings for one cause is noise.
    """
    workspace = context.workspace
    if workspace is None:
        raise CheckSkipped(
            "no product-repo root was handed to this check — a model backend is a "
            "per-workspace setting and cannot be resolved without one"
        )

    backend_id, config_error = _configured_backend(Path(workspace))
    if config_error is not None:
        raise CheckSkipped(config_error)
    if backend_id is None or backend_id == _DEFAULT_BACKEND_ID:
        # Unconfigured, or the direct Anthropic API — nothing is translated, so
        # there is nothing here that can be unmapped. Nothing is probed either.
        return []

    try:
        verdict = probe_model_backend(Path(workspace))
    except Exception:  # noqa: BLE001
        return []
    if verdict.state != "available":
        return []  # the sibling check owns this condition

    resolved = _resolve_once(Path(workspace))
    provider = getattr(resolved, "provider", None)
    if provider is None:
        return []
    backend = str(getattr(resolved, "provider_id", backend_id) or backend_id)

    try:
        from maestro.core.crew import resolve_model_detail
        from maestro.core_constants import DEFAULT_ROLE_MODELS
        from maestro.providers.model.base import ModelUnavailableOnBackend
    except Exception:  # noqa: BLE001 — fail open; a broken import is not a role fault
        return []

    findings: "list[Finding]" = []
    for role in DEFAULT_ROLE_MODELS:
        try:
            # `include_env=False` is deliberate: `mso doctor` may run in the
            # LEAD daemon's or the Hub's environment rather than the
            # dispatcher's, so reading `MAESTRO_MODEL_<ROLE>` here would
            # describe a host that never dispatches anything. Said out loud in
            # the detail below rather than left as a silent narrowing.
            model, source = resolve_model_detail(
                role, None, Path(context.artefact_root), include_env=False
            )
        except Exception:  # noqa: BLE001
            # An unknown model id is `orders.invalid-role`'s and
            # `_validate_model_id`'s territory, not this check's.
            continue

        try:
            provider.translate_model_arg(model)
        except ModelUnavailableOnBackend as exc:
            findings.append(
                Finding(
                    check_id="model.backend-unmapped-role",
                    subject_id=f"model-backend:{backend}:{role}",
                    severity="high",
                    title=(
                        f"Role {role} is pinned to a model the '{backend}' backend "
                        f"cannot serve"
                    ),
                    detail=(
                        f"{exc}\n"
                        f"Resolved model for {role}: {model} (pinned by the "
                        f"'{source}' layer of the model-resolution chain).\n"
                        "Every crew dispatched for this role is refused at launch — a backend "
                        "never substitutes a model it cannot serve, because a substitution the "
                        "fleet cannot see is worse than a refusal it can.\n"
                        "Resolved without $MAESTRO_MODEL_" + role.upper() + ": `mso doctor` may "
                        "run in the LEAD daemon's or the Hub's environment rather than the "
                        "dispatcher's, so an environment pin read here would describe a host "
                        "that never dispatches anything."
                    ),
                    firstSeenAt=context.now.isoformat(),
                    suggestedCommand=(
                        f"mso providers set model {backend} "
                        f"--config {exc.config_key}=<backend-native id>"
                        if getattr(exc, "config_key", "")
                        else "mso providers show model"
                    ),
                    scope="workspace",
                    requires=(),
                )
            )
        except Exception:  # noqa: BLE001
            # A backend bug must not be reported as a role misconfiguration.
            continue

    return findings
