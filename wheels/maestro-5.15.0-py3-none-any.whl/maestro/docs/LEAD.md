# The resident LEAD agent (`mso lead`)

The **resident LEAD** is a detached, per-workspace daemon that watches one
fleet on a cadence. It runs the same read-only patrol `mso doctor` runs, tails
the lifecycle log, and — within a narrow, configured band — performs a small
set of reversible housekeeping actions and says so afterwards.

Two things follow from it being a daemon rather than a session:

- **It survives the dispatcher exiting.** The idle watchdog reaps a dispatcher
  after 30 idle minutes; the LEAD keeps observing and will still report the
  dead dispatcher afterwards.
- **It can report *transitions*.** "The dispatcher was running at my last tick
  and is gone now" is a different claim from "no dispatcher is running", and
  only a process that was there for both ticks can make it.

It consumes **no crew slot**, so running it costs no dispatch capacity.

**Tier:** Pro, Team or Enterprise (`mso lead start`). Reading is never gated —
`mso lead status`, `mso lead chat log`, `mso lead ack`/`unack` and
`mso lead stand-down` work at any tier, because a licence gates *acting*, not
*looking*.

---

## Quick start

```bash
mso lead run --once     # one foreground pass — see what it would do, no daemon
mso lead start          # start the daemon for this workspace
mso lead status         # state, heartbeat age, findings by severity, last action
mso lead stand-down     # keep the process, skip ticks (never tier-gated)
mso lead resume         # start ticking again
mso lead stop
```

Nothing starts the daemon for you. If `mso lead status` says `STOPPED` with an
old heartbeat, that is the truth, not a display bug.

**Heartbeat age is a number, never a yes/no.** `mso lead status` prints how
long ago the last tick was, because "is it alive?" as a boolean is exactly how
a dead dispatcher once went unnoticed for three ticks.

The Maestro Hub renders the same data as a strip above the queue summary, and
can start, stop and restart the daemon from that strip and the LEAD drawer —
the same `maestro.lead.control` core as the CLI, writing the same
`LEAD_STARTED` / `LEAD_STOPPED` lifecycle lines with the actor named. See
[HUB.md](HUB.md).

---

## Captain Chat

Captain Chat is a durable, per-workspace **conversation** between you and the
resident LEAD. There are two channels into one thread.

| Channel | Who starts it | Costs tokens? |
|---------|---------------|---------------|
| **Proactive** | The LEAD, from its own patrol tick | **No.** The question is templated from data the daemon already has |
| **On demand** | You, with `mso lead chat say` or the Hub composer | **Yes.** One bounded, read-only model call per message |

### Proactive — the LEAD raises a question

When a patrol tick produces a NEW or ESCALATED finding at or above
`lead.chat.proactiveMinSeverity` (default `high`), or the lifecycle log shows
one of a small set of events that by definition need a human
(`NAV_REVIEW_PENDING`, `PLAN_ORPHANED`, `SEC_ARTEFACT_MISSING`,
`VERIFY_FAILED`, `LAP_EXHAUSTED`, and a `STALLED` line whose cause is
`BLOCKED_BY_ROLE`), the daemon posts a **question** into the thread.

This path is deterministic and templated — it invokes no model and spends no
tokens. A question costs a disk append.

Questions are **deduplicated by subject**: ten identical ticks produce one
question, not ten. Acknowledging the finding (`mso lead ack`) or the finding
resolving marks the question `superseded` with a note, so the thread never
shows an open question the patrol has already cleared.

An unanswered question that sits `open` for longer than
`lead.chat.openQuestionHours` (default 12) is reported by `mso doctor` as a
`medium` finding, `lead.chat-open-question`, suggesting
`mso lead chat log --open`.

### On demand — you ask, the LEAD answers

Post a message and the daemon answers it on its next chat poll (default every
5 s). It builds a context pack itself — the LEAD role text, the persisted
findings, recent lifecycle lines, the queue/voyage summary, recent thread
messages and open decisions — then makes **one bounded `claude --print` call**
with `Read`, `Glob` and `Grep` and nothing else.

It **cannot run anything.** `Bash`, `Write`, `Edit`, `NotebookEdit`, `Agent`,
`WebFetch`, `WebSearch` and `TodoWrite` are all removed from the invocation,
and a pretool hook denies writes again independently. Anything the LEAD wants
*done* comes back as a **proposal** you confirm, never as an action it took.

You never get silence. If the daemon cannot answer, it says why, in the
thread, and the message is not dropped:

| Situation | What you see | Tokens | Your message |
|-----------|--------------|--------|--------------|
| Daemon stood down | "LEAD is stood down… run `mso lead resume`" | none | **stays queued** — answered once you resume |
| Chat token ceiling reached | The exact spend against the exact ceiling, and the key to raise | none | **stays queued** — answered once the ceiling clears |
| Claude CLI not found | Said plainly, with the install command | none | **stays queued** — answered on the next poll once installed |
| Message older than `staleAfterHours` | A stale notice: ask again if it still matters | none | **answered** — deliberately not run against context that has moved on |
| Daemon not running at all | Nothing yet | none | waits; answered oldest-first when the daemon starts |

Every one of these states the remedy. A status message that does not tell you
what to do is an alarm, not an answer.

At most **one** reply is in flight per workspace; a queued message gets an
immediate status message telling you its position. The reply runs as a
killable child process with a wall-clock timeout
(`lead.chat.replyTimeoutSeconds`, default 180 s), so a hung call can never
block a patrol tick.

### The CLI surface

```bash
# read — never tier-gated
mso lead chat log                       # the last 50 messages
mso lead chat log --limit 200
mso lead chat log --since CHAT-20260917T101502Z-a1b2c3
mso lead chat log --open                # only questions still awaiting an answer
mso lead chat log --decisions [--days N]   # only recorded decisions (default 7 days)
mso lead chat log --json                # machine-readable

# write — Pro / Team / Enterprise
mso lead chat say "why is FTR-MSO-2026-0842 still PENDING?"
mso lead chat say "..." --in-reply-to CHAT-...
mso lead chat reply CHAT-20260917T101502Z-a1b2c3 "yes, requeue it at BLD"

# record a decision — Pro / Team / Enterprise, and WRITES NOTHING without --confirm
mso lead chat decide CHAT-20260917T101502Z-a1b2c3 \
  --decision waive --order SEC-MSO-2026-0461 --ref "SEC-MSO-2026-0461#F1" \
  --rationale "accepted risk for v5.15; tracked in BUG-MSO-2026-0900"
mso lead chat decide CHAT-20260917T101502Z-a1b2c3 ... --confirm
```

`chat reply` both posts your answer **and** folds the question it answers to
`answered`, as one operation — posting without the state transition is how a
question ends up looking open forever.

`chat decide` without `--confirm` prints the exact record it would write and
writes nothing. Use `--voyage` instead of `--order` for a decision with no
single order.

| Sub-command | Gate |
|-------------|------|
| `chat log` | **Ungated** — reading never spends anything |
| `chat say`, `chat reply`, `chat decide` | `LEAD_AGENT_TIERS` — **Pro / Team / Enterprise**, the same tier as the agent they talk to |
| The daemon's proactive questions and its responder | Pro+, because `mso lead start` is |
| The Hub's chat composer and confirm buttons | **Team / Enterprise** — every Hub mutation is |

A **Pro** operator gets Captain Chat through the CLI; a **Team/Enterprise**
operator also gets it in the Hub. That is the split the LEAD and the Hub
already have; chat adds no new tier.

---

## What the chat can and cannot do

**Chat text is never itself authority.** Nothing the LEAD writes does
anything, and nothing you write in prose is executed. Every effect leaves the
chat through one of exactly two explicit, typed confirmations.

**1. A proposal → Confirm.** A proposal is a `{verbId, args}` pair drawn from
the *closed* list of verbs the LEAD drawer's Run button already offers — chat
adds no verb to that list. On confirm it is re-parsed from the verb id and
args (**never** from stored text), the LEAD's `must_not` ceiling is applied
unconditionally, and the verb's existing handler runs. The net effect is
exactly what the Run button can do and no more. A refusal is a normal,
rendered outcome, not an error.

**2. A decision → Confirm.** A decision with nothing executable behind it —
"waive SEC F1, ship it" — is recorded on the git-tracked order JSON's
`captainDecisions[]` (or the voyage manifest's), with a `CAPTAIN_DECISION`
lifecycle line and an audit entry.

> **Recording a decision does not change what any gate does.** Nothing in the
> engine reads `captainDecisions[]`. The SEC artefact gate, the verify gate,
> the review gate and the completion guard all behave exactly as they did
> before. A decision is **evidence** — the same class as `completedBy` or
> `reviewedBy` — that a reviewer, a later role, or a future session can see
> and cite. It is not a bypass, and "it was waived in chat" is not a way past
> a gate.

Everything else — questions, explanations, status — is conversation, and
nothing beyond the thread records it.

There is no chat verb for **merging**, **tagging**, **publishing**, **editing
source code**, or **bypassing a guard**. You merge on your own provider, as
before.

---

## Where the thread lives, and who can read it

The thread is `<workspace>/.mso/state/captain-chat/thread.jsonl` — append-only
JSONL, the same durability class as the order ledger.

- **Durable and readable off-process.** `mso lead chat log --json` works with
  the daemon, the Hub and the dispatcher all stopped.
- **Never git-committed.** Free-text conversation can contain sensitive
  operational detail, and `state/` is gitignored. The parts that need git
  durability — decisions — are promoted onto the order or voyage artefact,
  which *is* tracked.
- **Lifecycle lines carry metadata only.** `CAPTAIN_CHAT`, `LEAD_CHAT_REPLY`
  and `CAPTAIN_DECISION` record ids, authors, kinds and token usage. No
  message body and no decision rationale ever appears in `lifecycle.log`.
- **It rotates.** At 5 MB the active segment becomes `thread-<UTC>.jsonl` and
  a new one begins; paged reads walk the segments. Old segments are never
  deleted automatically.
- **`mso backup` includes it.**
- **Message bodies are capped at 8,000 characters** — a chat message is a
  message, not a file upload.

> **Shared artefact-repo mode: the thread is device-local.** `state/` is not
> part of the shared plane, and the LEAD daemon is per-machine-per-workspace.
> Two operators running daemons on two machines therefore have **two separate
> threads** for the same workspace. This is consistent with the order ledger
> and with how the daemon itself is scoped — it is documented here so it is
> not discovered as a surprise, and the chat is never presented as shared
> across machines.

---

## Who "the Captain" is

Attribution is honest about what each surface can actually verify.

- **From the CLI**, the author is resolved from your own shell, which is the
  stronger path; in a governed workspace it reflects verified identity.
- **From the Hub**, there is one shared bearer token and no per-request human
  identity. A display name typed in the Hub is a courtesy label stored in your
  browser, and every Hub-authored message is stamped `verified: false` and
  rendered with an unverified marker.
- **Authority does not differ by author.** Anyone holding the Hub token can
  already click Retry or Approve; chat grants nothing beyond that set.
- **In a governed workspace the Hub will not record a decision at all** — it
  would have to attribute it to a process rather than to a person, on the one
  artefact whose whole value is attribution. It says so before the click, and
  governed operators decide from the CLI. Per-request verified Hub identity is
  a named future dependency.

`lead.chat.post` and `lead.chat.decide` are identity capabilities enforced
inside the shared cores, so the CLI, the Hub and any later surface inherit one
gate rather than each remembering it. Outside a governed workspace they are a
no-op.

---

## Bands — what the daemon may do unattended

The LEAD's proactivity ceiling is its role definition's `must_not` list. It is
**extend-only**: a role overlay may add to it, and may never replace or
override it. Anything on that list — merging, approving its own work,
resolving security findings — is refused regardless of configured band, and
that refusal is recorded.

The default act-and-inform set is deliberately small and consists only of
idempotent, reversible housekeeping: **voyage reconcile** and **artefact
sweep**. Everything else, including PR draft→ready promotion (it starts CI, so
it spends money) and worktree pruning, is *observe-only* by default — the LEAD
detects and proposes, a human runs it.

Every action the LEAD takes, or tries and fails to take, is written to the
lifecycle log as `LEAD_ACTION` with the action, the band, the outcome and the
finding that triggered it. Acting never means acting quietly.

---

## Termination, not throttling

Every LEAD task has a definition of done: it either finishes or reports back.
"Keeps running" is not a third outcome.

The per-workspace daily token ceilings are **abnormal backstops**, not budgets
to operate against:

- `lead.tokenCeiling.dailyTokens` (default 200,000) — the patrol.
- `lead.chat.dailyTokens` (default 1,000,000) — chat, deliberately separate,
  so ordinary conversation cannot consume the patrol's budget or turn an
  abnormal signal into a daily one.

Hitting either is reported (`LEAD_CEILING_HIT`). If one is being hit in normal
operation, the task's completion conditions are the bug to fix, not the
ceiling.

---

## Configuration

The `lead` block lives in `.mso/config/workspace.json`. Every key has a
shipped default, and a malformed value falls back to it rather than stopping
the daemon from starting — so the block can be omitted entirely.

```json
{
  "lead": {
    "standDown": false,
    "tokenCeiling": { "dailyTokens": 200000 },
    "chat": {
      "pollSeconds": 5,
      "maxTurns": 6,
      "replyTimeoutSeconds": 180,
      "dailyTokens": 1000000,
      "proactiveMinSeverity": "high",
      "staleAfterHours": 24,
      "openQuestionHours": 12,
      "model": null
    }
  }
}
```

| Key | Default | What it controls |
|-----|---------|------------------|
| `lead.standDown` | `false` | Skip ticks while keeping the process alive. Set by `mso lead stand-down` / `resume` or the Hub toggle; read fresh every loop, so it survives a restart |
| `lead.tokenCeiling.dailyTokens` | `200000` | The **patrol's** abnormal-spend backstop |
| `lead.chat.pollSeconds` | `5` | How often the daemon checks the chat inbox. The heartbeat sleep is sliced to this, so a reply does not wait on the patrol cadence |
| `lead.chat.maxTurns` | `6` | Turn cap on one reply. The context pack is pre-built, so few tool turns should be needed |
| `lead.chat.replyTimeoutSeconds` | `180` | Wall-clock ceiling on one reply; the child process is killed at it |
| `lead.chat.dailyTokens` | `1000000` | The **chat's own** daily ceiling, separate from the patrol's |
| `lead.chat.proactiveMinSeverity` | `"high"` | Severity floor for a proactive question |
| `lead.chat.staleAfterHours` | `24` | Older messages get a stale notice instead of tokens spent on stale context |
| `lead.chat.openQuestionHours` | `12` | When `mso doctor` starts reporting an unanswered question |
| `lead.chat.model` | `null` | `null` = inherit the workspace's LEAD role-model policy. Set it to run chat on a cheaper model. An unusable value is refused and falls back to `null` |

### What a reply costs

One on-demand reply is a single bounded call with a pre-built context pack —
roughly tens of thousands of input tokens and one to two thousand output
tokens. On a frontier model that is a fraction of a dollar per message; on a
smaller model, less. The default `lead.chat.dailyTokens` is sized for roughly
twenty replies a day per workspace. If you chat heavily, either raise it
knowingly or set `lead.chat.model` to something cheaper — the point of the
separate ceiling is that the decision is yours and visible, not that the
number is right for everyone.

---

## See also

- [PATROL.md](PATROL.md) — the checks the LEAD runs, and how to configure them
- [HUB.md](HUB.md) — the LEAD strip, the LEAD drawer's Chat tab, and the Hub's
  chat endpoints
- [ROLE-OVERLAYS.md](ROLE-OVERLAYS.md) — extending the LEAD role's `must_not`
