# Plan decomposition — approval as a trigger, not a dead end

**Status:** opt-in · **Config:** `completion.planDecomposition` · **Since:** FTR-MSO-2026-0860

When you approve a plan-only order and nothing has been filed to build it,
Maestro can file a **decomposition order** that reads the approved plan and
proposes the concrete build orders for it. You review that proposal at the plan
gate you already use, and only then are any orders minted.

Without it, approving such a plan writes a `PLAN_ORPHANED` warning and stops.
Somebody then has to read the plan prose and type out `mso order create --voyage`
once per order. That is the gap this closes.

---

## The flow

```
you approve a plan-only order
  │
  ├─ it already has build orders filed? ──────────────► nothing changes
  │
  └─ nothing filed to build it (the PLAN_ORPHANED point)
       │
       └─ Maestro files a decomposition order    ......... PLAN_DECOMPOSITION_FILED
            │
            └─ the dispatcher runs it as an ordinary PLN crew, which writes
               plans/PLAN-<decomposition-order-id>.md — prose plus one
               machine-readable manifest block
                 │
                 └─ it stops at the plan-review gate, like any plan
                      │
                      ├─ mso review approve ─► the batch is filed PENDING
                      │                        on the voyage ..... PLAN_DECOMPOSITION_APPLIED
                      ├─ mso review revise  ─► back to PLN with your notes
                      └─ mso review reject  ─► FAILED; nothing was ever minted
```

**No order id exists until you approve.** The crew's proposal references orders
*positionally* (`"order": 2`, `"dependsOn": [1]`), and Maestro resolves those
positions to real ids at the moment it files them. Rejecting a breakdown
therefore leaves nothing to clean up — no orphaned orders, no burnt ids.

## Turning it on

```json
{
  "completion": {
    "planDecomposition": {
      "enabled": true,
      "maxOrders": 25
    }
  }
}
```

or `mso settings set completion.planDecomposition.enabled true`.

**The plan-review gate must also be on.** Filing the batch is the approve gate's
own action, so on a workspace with `post_nav_review` disabled this flag gets you
a written breakdown and no build orders. See
[Workspaces with the plan-review gate off](#workspaces-with-the-plan-review-gate-off).

| Key | Default | Meaning |
|---|---|---|
| `enabled` | `false` | Only a literal JSON `true` turns it on. A malformed block, the string `"true"` and an absent key all read as **off**, because off is the state guaranteed to behave exactly as a build without this feature. |
| `maxOrders` | `25` | Ceiling on one batch. A larger breakdown is **refused**, not trimmed — a plan that needs more than this is telling you something. |

With it off, nothing about approval changes: `PLAN_ORPHANED` is written exactly
as before.

## What you see when you approve

```
$ mso review approve PLN-MSO-2026-0828
[review] PLN-MSO-2026-0828 plan approved — archived COMPLETE; no PROPOSED dependents found to promote.
[review] Nothing was filed to build this plan, so Maestro filed decomposition
         order PLN-MSO-2026-0831 to propose the breakdown. It will come back to
         you at this same review gate before any build order is minted.
```

and later, on the decomposition order itself:

```
$ mso review show PLN-MSO-2026-0831       # renders the proposed breakdown
$ mso review approve PLN-MSO-2026-0831
[review] PLN-MSO-2026-0831 breakdown approved — archived COMPLETE; filed 4 build
         order(s) PENDING: FTR-MSO-2026-0832, FTR-MSO-2026-0833, ...
```

The Hub's `/review` page and board show the same document and return the same
ids (`filed_orders` on the action result) — one shared core, no second
implementation.

## If the breakdown is wrong

Use `mso review revise <decomposition-order-id> "<what to change>"`. The order
goes back to PLN with your notes and is re-decomposed. Nothing has been minted
yet, so there is nothing to undo.

`mso review reject` fails the decomposition order outright. The plan stays
unbuilt and you file its orders by hand — exactly the position you would have
been in without the feature.

## When it does not fire

Four ways, each of which makes it permanently or temporarily a no-op — and none
of which is silent:

1. **The feature is off.** `PLAN_ORPHANED` as before.
2. **The plan already has build orders** — filed dependents, or a linked build
   voyage. The trigger fires *only* at the PLAN_ORPHANED point, so once real
   work exists it can never fire again. Re-approving, re-running
   `mso voyage reconcile`, or clicking approve twice in the Hub all change
   nothing.
3. **A decomposition order was already filed for this plan.** The voyage manifest
   records it (`planDecomposition`), so exactly one is ever filed.
4. **The order being approved is itself a decomposition order.** It cannot
   decompose itself, so the chain always terminates.

## Failure is visible, on purpose

A decomposition order that stalls, fails, or carries a breakdown that cannot be
parsed is reported by `mso doctor` as **`voyages.plan-decomposition-failed`**
(severity `high`), with `mso order retry <id> --role PLN` as the remedy.

That check is not decoration. The older detector, `voyages.planned-no-work`,
only reports when *every* order on a voyage is complete — and a decomposition
order sitting on the manifest, unfinished, makes that false. Without the new
check, a failed decomposition would leave you worse off than no feature at all:
the voyage still stuck, and now nothing saying so.

Approving a breakdown that cannot be applied never archives the order. It stays
`NAV_REVIEW_PENDING` in `queues/review/`, you get the parse error, and
`mso review revise` still works.

## Workspaces with the plan-review gate off

**Enable the plan-review gate if you want this feature to produce build orders.**
With `post_nav_review` disabled in `.mso/config/gates.json`, decomposition gets
you a written breakdown but never mints anything from it.

Here is why. A plan-only order on a gate-off workspace never reaches a review
gate at all — it archives COMPLETE straight from the dispatcher. The trigger
still fires there, so you get the first half of the flow: a decomposition order
is filed, the dispatcher runs it as an ordinary PLN crew, and that crew writes
`plans/PLAN-<decomposition-order-id>.md` with its proposed breakdown in a
manifest block. **The second half never happens.** Filing the batch is the
approve gate's own action — it is what `mso review approve` does — so with no
gate to stop at, the decomposition order archives COMPLETE like any other
plan-only order and **no build order is ever minted**.

That is the safe direction to fail in: the failure mode is "mints nothing",
never "mints something you did not read". But it is not a useful one. What it
costs you is a PLN crew turn per approved plan, and a voyage that still has no
build orders — a quieter version of the same `PLAN_ORPHANED` dead end the
feature exists to remove.

Two ways out:

* **Enable the planning gate** (`post_nav_review` in `.mso/config/gates.json`).
  This is the supported configuration, and the one the whole flow above
  describes. Decomposition then works end to end.
* **Read the breakdown and file it yourself.** The proposal is not lost — it is
  sitting in `plans/PLAN-<decomposition-order-id>.md`, written out in full. You
  can work through it with `mso order create --voyage <VOY-ID>`, which is the
  manual job decomposition exists to save you, but with the thinking already
  done.

> **If you read an earlier version of this page**, it said the batch was filed
> *unreviewed* on this path — that your "I do not review plans" posture was being
> applied consistently. It never was: no release has ever minted build orders on
> a gate-off workspace. The behaviour described above is what the code has always
> done, and it is deliberate — a planning crew's own output should not spawn real,
> dispatchable work with no human in the loop, which is precisely what the
> plan-review gate exists to enforce. Corrected 2026-09-23.

## The manifest a decomposition crew writes

You do not write this by hand — it is documented so you can read one, and so a
custom PLN overlay can be checked against it.

````markdown
```maestro-decomposition
{
  "schemaVersion": "1.0",
  "planOrder": "PLN-MSO-2026-0828",
  "voyageId": "VOY-MSO-2026-0827",
  "orders": [
    {
      "order": 1,
      "type": "FTR",
      "title": "Short imperative title",
      "priority": "HIGH",
      "roleSequence": ["PLN", "BLD", "TST"],
      "description": "Carried forward from the approved plan.",
      "acceptanceCriteria": ["..."],
      "dependsOn": []
    },
    { "order": 2, "type": "FTR", "title": "...", "dependsOn": [1] }
  ]
}
```
````

| Field | Rule |
|---|---|
| `schemaVersion` | Exactly `"1.0"`. |
| `planOrder` / `voyageId` | Must match the decomposition order's own. A manifest naming a different plan or voyage is refused. |
| `order` | A unique positive integer — a **position**, never an id. |
| `dependsOn` | Positions declared in this same manifest. No self-reference, no cycles. An id-shaped string here is refused outright: ids do not exist yet, so any id named would be a guess. |
| `dependsOnExisting` | Order ids that already exist on disk — the separate key that makes the refusal above unambiguous. |
| `type`, `roleSequence`, `priority`, `acceptanceCriteria` | Validated by the ordinary order-creation path, the same as a hand-filed order. `LEAD` in a `roleSequence` is refused there. |
| Free text | Bounded before it reaches disk: title 200 chars and no path separators, description 8000, up to 40 acceptance criteria of 1000 chars each. |
| The block itself | Exactly one per document. Two is refused — taking the first would file a breakdown the reviewer did not read. |

## Lifecycle events

| Event | Meaning |
|---|---|
| `PLAN_DECOMPOSITION_FILED` | A plan was approved with nothing to build it, and a decomposition order was filed (or an unattached one adopted). On a workspace with the plan-review gate off this is where the chain ends — see [Workspaces with the plan-review gate off](#workspaces-with-the-plan-review-gate-off). |
| `PLAN_DECOMPOSITION_APPLIED` | A breakdown was approved and its build orders were filed PENDING. Names them. |
| `PLAN_DECOMPOSITION_FAILED` | Either a decomposition order could not be filed, or an approved breakdown could not be applied. In the second case the order stays in review and the message names the remedy. |
| `PLAN_ORPHANED` | Unchanged, and still correct: a declined trigger, a disabled feature, or a plan approved by hand. This feature makes it rare, not dead. |
