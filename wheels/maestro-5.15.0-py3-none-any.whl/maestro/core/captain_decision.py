# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""maestro/core/captain_decision.py — the ONE core that records a Captain
Decision (PLAN-PLN-MSO-2026-0828 Order 4, FTR-MSO-2026-0848).

A Captain Decision is the second of the two outcomes a Captain Chat
conversation can have (plan §0 Q2). The first — an actionable verb — goes
through :func:`maestro.lead.chat.confirm_proposal` into the CLOSED
``run_verbs`` list and an existing shared core. This module is the other
one: a decision with **no executable core behind it**, such as "waive SEC
F1, ship it". There is nothing to run, so the only honest thing to do with
it is write it down where everyone who needs it can find it.

    ``record_decision(mso, *, subject, decision, rationale, decided_by,
    source_message_id)``

appends the record to the git-tracked **order JSON**'s ``captainDecisions[]``
(or, for a voyage-level call, to the voyage manifest's own
``captainDecisions[]``, identical shape), writes a ``CAPTAIN_DECISION``
lifecycle line, writes an audit entry, posts a ``decision`` message into the
chat thread, and enforces ``require_capability("lead.chat.decide")``.

THE HONEST BOUNDARY — read this before assuming otherwise
---------------------------------------------------------
**Recording a decision does NOT, by itself, change any gate's behaviour.**
Nothing in the engine reads ``captainDecisions[]`` today, and this order
deliberately did not make anything read it:

* the SEC artefact gate (``fleet_runner.sec_artefact_present`` and the
  ``SEC_ARTEFACT_MISSING`` hold/escalate path) behaves **exactly** as it did
  before a waiver was recorded;
* the local verify gate (``VERIFY_FAILED`` / ``VERIFY_DEPS_FAILED``) behaves
  exactly as before;
* the human review gate, the BUG-0294 ledger veto, the BUG-0303 completion
  guard and the role-rejection lap all behave exactly as before.

A decision is **EVIDENCE**, not a bypass. It is there so REL, the LEAD, an
interactive session and a human reviewer can SEE and CITE the call that was
made, in the same place and with the same durability as ``completedBy`` /
``completionNotes`` / ``reviewedBy`` — which is exactly how a hand-applied
Captain decision has always been recorded in this workspace.

Letting a SPECIFIC gate HONOUR a SPECIFIC decision kind is a separate,
per-gate order with its own SEC review, named in the plan's
Dependencies/Blocks section and deliberately not built here. The principle is
the same one ``mso order retry`` embodies for the ledger veto: there is
exactly one sanctioned way past a gate, it is explicit, and it is not "some
text was recorded nearby". ``tests/test_captain_decision_core.py`` PINS this
boundary — a test there asserts the SEC gate's answer is unchanged by a
recorded waiver, so a future change that quietly makes a gate consult this
field has to break that test on the way in.

The shared-core contract (``maestro/core/order_retry.py``)
----------------------------------------------------------
Explicit ``mso: Path`` throughout — no ``find_workspace()``, no CWD, because
the Hub serves N workspaces from one process. Typed exceptions, never
printing and never ``sys.exit``: :class:`DecisionValidationError` -> 400,
:class:`DecisionSubjectNotFound` -> 404, :class:`DecisionAlreadyRecorded` ->
409, ``CapabilityDenied`` -> 403. Every mutation runs inside
``order_retry.workspace_scope(mso)``. The capability gate is enforced HERE,
in the core, so the CLI, the Hub and any later surface inherit it rather than
each remembering it — the shape FTR-MSO-2026-0492 established for
``order.dispatch``. Licence-tier gating stays at the call sites.

Exactly once, under concurrent confirms
---------------------------------------
Two Confirm clicks (a double-click, or the CLI and the Hub at the same
moment) must leave ONE record, not two. Serialising the read-modify-write on
a cross-process lock is necessary but not sufficient — two *serialised*
confirms still append twice. So the same lock additionally makes the write
idempotent on ``sourceMessageId``: a second confirm of the same chat message
finds the first record and raises :class:`DecisionAlreadyRecorded` carrying
it, rather than appending a duplicate. The id is minted inside that lock and
**read back from the file that was just written** — never composed by the
caller — the same rule ``maestro/core/order_ids.py`` states for allocation,
for the same reason.

The writer this lock does NOT cover (BUG-MSO-2026-0891)
-------------------------------------------------------
That lock is PRIVATE to this core. ``fleet_runner`` writes the very same
order and voyage JSONs with a bare ``write_text(json.dumps(...))`` under no
lock at all, so serialising decisions against each other says nothing about
the dispatcher. A decision recorded while the dispatcher is mid-``ADVANCE``
on the same order used to write back the copy read at the top of
``record_decision``, silently reverting whatever the dispatcher had just
written to some OTHER key — ``verify{}``, ``salvageBranches[]``,
``convergenceRetry{}``, ``requeueCount``, ``relSignOff{}`` — with no conflict
detection and no warning.

So the document is RE-READ immediately before the atomic write
(:func:`_reread_before_write`) and only ``captainDecisions`` is carried
across; every other key is taken from the fresh read. The two writers' changes
now compose whenever they touch different keys, and the loss window shrinks
from the whole function to the final read-plus-replace. **It is not made
atomic** — a dispatcher write landing inside that last window is still lost,
because closing it needs the other writer to take a lock too. That is the
codebase-wide write-discipline project FTR-MSO-2026-0848's SEC report (F3)
deferred, and it is deliberately not attempted here.
"""

from __future__ import annotations

import json
import logging
import os
import re
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional

# The order-ID allocator's lockfile class, reused rather than copied — the
# codebase's one portable O_CREAT|O_EXCL cross-process mutex, already carrying
# the Windows delete-pending retry BUG-MSO-2026-0464 had to learn the hard way.
from maestro.core.order_ids import _CrossProcessLock

__all__ = [
    "DECISION_ID_PREFIX",
    "DECISION_VIA_CLI",
    "DECISION_VIA_HUB",
    "KNOWN_DECISIONS",
    "MAX_DECIDED_BY_CHARS",
    "validate_decided_by",
    "derive_attributed_verified",
    "MAX_RATIONALE_CHARS",
    "DecisionAlreadyRecorded",
    "DecisionArtefactUnreadable",
    "DecisionSubjectNotFound",
    "DecisionValidationError",
    "DecisionSubject",
    "RecordedDecision",
    "LIFECYCLE_EVENT",
    "AUDIT_ACTION",
    "decisions_on",
    "describe_provenance",
    "find_subject_file",
    "record_decision",
]

_log = logging.getLogger(__name__)

#: ``DEC-0001``, ``DEC-0002``, … — per subject file, allocated under the lock.
DECISION_ID_PREFIX = "DEC-"
_DECISION_ID_RE = re.compile(r"^DEC-(\d+)$")

#: Metadata only — the rationale is Captain-authored free text and is NEVER
#: written to ``lifecycle.log``, for the same reason a chat body is not
#: (plan §0 Q3: that log must not become a second, less-protected copy).
LIFECYCLE_EVENT = "CAPTAIN_DECISION"
AUDIT_ACTION = "captain.decision"

#: An ADVISORY vocabulary a surface can offer in a picker. Deliberately NOT
#: enforced: which kinds exist is a policy question that belongs to the
#: per-gate follow-up order, and refusing an unlisted word here would just
#: push Captains into recording the real decision as prose in the rationale.
KNOWN_DECISIONS = (
    "waive", "accept-risk", "defer", "approve", "reject", "note",
)

MAX_DECISION_CHARS = 120
MAX_RATIONALE_CHARS = 8_000
MAX_REF_CHARS = 200

#: ``decidedBy`` / ``resolvedBy`` — an identity, not prose. 200 is the natural
#: peer of :data:`MAX_REF_CHARS` and the value the Hub already clamps its own
#: ``displayName`` to. Bounded in the CORE so every surface inherits it: before
#: BUG-MSO-2026-0890 DEF-004 this was the one free-text field on the record
#: with no limit at all, so a 5 MB ``by`` posted to the Hub was committed and
#: pushed to the artefact plane verbatim.
MAX_DECIDED_BY_CHARS = 200

#: WHICH SURFACE recorded the decision, written to the durable record as
#: ``decidedVia`` (BUG-MSO-2026-0890). Set by the SURFACE, never by a client
#: — the Hub's request model has no ``via`` field and must never grow one,
#: because a provenance marker a caller can choose is not provenance.
DECISION_VIA_CLI = "cli"
DECISION_VIA_HUB = "hub"

#: Same shape rule as a subject id, one size down: a surface slug goes into a
#: git-tracked field and a lifecycle line, so it may not carry whitespace,
#: newlines or separators.
_VIA_RE = re.compile(r"^[a-z0-9][a-z0-9._-]{0,31}$")

#: Same shape as ``run_verbs._ORDER_ID`` / ``hub.server._ORDER_ID_RE``. Also
#: the reason a subject id can safely become part of a lock FILENAME below:
#: no separator, no traversal, no wildcard can survive this.
_SUBJECT_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,64}$")

# Serialises decision writes within THIS process. The cross-process lock
# covers separate processes; the Hub is one process with per-workspace poller
# threads, and on Windows two threads' read-modify-write of the same order
# file can interleave between the read and the os.replace.
_WRITE_LOCK = threading.Lock()


# ---------------------------------------------------------------------------
# Typed exceptions — the CLI renders them, the Hub maps them to HTTP.
# ---------------------------------------------------------------------------

class DecisionValidationError(ValueError):
    """Malformed decision input — no subject, empty decision, oversized
    rationale, a subject id that is not an id. Maps to HTTP 400."""


class DecisionArtefactUnreadable(DecisionValidationError):
    """The subject artefact exists but could not be read or parsed.

    A SUBCLASS of :class:`DecisionValidationError`, so every existing
    ``except DecisionValidationError`` — the CLI's and the Hub's — keeps
    catching it and the HTTP mapping is unchanged at 400.

    What it adds is a SPLIT, for BUG-MSO-2026-0892 item 5 (CWE-209). Every
    other ``DecisionValidationError`` in this module describes the CALLER's
    input ("decision must be a single line") and is safe to hand back
    verbatim; these describe the SERVER's filesystem, and the useful version
    of the message — the absolute host path plus the OS's own error text — is
    exactly the version that leaks the plane's layout to a remote caller.

    So there are two messages. ``str(exc)`` is the full operator-facing one,
    unchanged, and is what the CLI prints and what the Hub logs locally;
    ``client_detail`` is a generic sentence naming WHAT failed and on WHICH
    artefact id — enough to act on — and nothing about where it lives.
    """

    def __init__(self, message: str, *, client_detail: str) -> None:
        super().__init__(message)
        #: Safe to return over HTTP. Never contains a path or OS error text.
        self.client_detail = client_detail


class DecisionSubjectNotFound(LookupError):
    """The named order or voyage has no file in this workspace. HTTP 404."""

    def __init__(self, subject_id: str) -> None:
        self.subject_id = subject_id
        super().__init__(
            f"No order or voyage '{subject_id}' in this workspace — a decision "
            "is recorded ON an artefact, so the artefact has to exist first."
        )


class DecisionAlreadyRecorded(Exception):
    """This chat message's decision is already on the subject. HTTP 409.

    Carries the EXISTING record, so a caller rendering a second Confirm click
    can show what was recorded the first time rather than a bare error.
    """

    def __init__(self, subject_id: str, record: Dict[str, Any]) -> None:
        self.subject_id = subject_id
        self.record = dict(record or {})
        self.decision_id = str(self.record.get("id") or "")
        super().__init__(
            f"Decision {self.decision_id or '(unknown id)'} for this chat "
            f"message is already recorded on {subject_id} — not recording it "
            "twice."
        )


# ---------------------------------------------------------------------------
# Subject
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class DecisionSubject:
    """WHAT the decision is about.

    ``order_id`` and ``voyage_id`` choose the artefact the record lands on;
    ``ref`` is the free-form pointer INSIDE it (``"SEC-MSO-2026-0461#F1"``,
    ``"QA DEF-002"``) and is carried verbatim. An order-level decision is the
    normal case; a voyage-level one (no order) records on the manifest with
    the identical shape, so a reader does not need two parsers.
    """

    order_id: Optional[str] = None
    voyage_id: Optional[str] = None
    ref: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {"orderId": self.order_id, "voyageId": self.voyage_id, "ref": self.ref}

    @classmethod
    def coerce(cls, raw: Any) -> "DecisionSubject":
        """Accept a :class:`DecisionSubject` or the wire dict the Hub and the
        chat ``decisionDraft`` both carry."""
        if isinstance(raw, DecisionSubject):
            return raw
        if raw is None:
            return cls()
        if not isinstance(raw, Mapping):
            raise DecisionValidationError(
                "subject must be a DecisionSubject or a mapping with orderId/voyageId/ref"
            )
        return cls(
            order_id=_clean(raw.get("orderId") or raw.get("order_id")),
            voyage_id=_clean(raw.get("voyageId") or raw.get("voyage_id")),
            ref=str(raw.get("ref") or "").strip(),
        )

    @property
    def primary_id(self) -> str:
        """The artefact the record lands on — the order when one is named."""
        return self.order_id or self.voyage_id or ""


def _clean(value: Any) -> Optional[str]:
    text = str(value or "").strip()
    return text or None


# ---------------------------------------------------------------------------
# Provenance (BUG-MSO-2026-0890)
# ---------------------------------------------------------------------------

def describe_provenance(record: Mapping[str, Any], *,
                        include_via: bool = True) -> str:
    """One clause describing how well *record*'s ``decidedBy`` is known.

    ``"alice (verified, via cli)"`` / ``"alice (UNVERIFIED, via hub)"``.

    ``include_via=False`` drops the surface and keeps the trust judgement:
    ``"alice (UNVERIFIED)"``. That form is for the CHAT BODY, and the reason
    is the anti-drift contract. WHICH surface recorded a decision is the one
    thing about it that legitimately differs between the CLI and the Hub, so
    baking it into free text would make the two surfaces' message bodies
    permanently unequal — and the only way past the detector would be to
    exempt the body itself, which is exactly the field that must never be
    exempt. The surface travels STRUCTURALLY instead, on the record's
    ``decidedVia``, which is where both renderers read it from.

    THE POINT OF THIS FUNCTION IS THAT THERE IS ONLY ONE OF IT. The finding
    that produced it (CWE-345) was not that the Hub could accept a name — it
    was that a Hub-typed name landed in the git-tracked record, the lifecycle
    line and the audit log looking EXACTLY like a CLI-resolved one. Rendering
    the distinction in five places by hand is how four of them drift; every
    surface calls this.

    A record written before BUG-MSO-2026-0890 carries neither field. It reads
    back as UNVERIFIED with an unknown surface, which is the honest answer:
    nothing recorded at the time proves otherwise.
    """
    actor = str(record.get("decidedBy") or "") or "unknown"
    verified = bool(record.get("decidedByVerified"))
    trust = "verified" if verified else "UNVERIFIED"
    if not include_via:
        return f"{actor} ({trust})"
    via = str(record.get("decidedVia") or "") or "unknown"
    return f"{actor} ({trust}, via {via})"


def _normalise_via(via: Any) -> str:
    """A surface slug, sanitised. Never raises — an unusable value becomes
    ``"unknown"``, because a decision must not be lost over a label, and
    ``"unknown"`` is read as unverified provenance anyway."""
    text = str(via or "").strip().lower()
    return text if _VIA_RE.match(text) else "unknown"


# ---------------------------------------------------------------------------
# Result
# ---------------------------------------------------------------------------

@dataclass
class RecordedDecision:
    """What :func:`record_decision` actually wrote.

    ``record`` is the entry **as read back from the file on disk**, never the
    dict this module composed — the same discipline the order/voyage id
    allocators use, and the only version of the record that is true.

    The three side effects report honestly rather than being assumed: the
    decision itself is durable the moment the file is replaced, so a failure
    to write the lifecycle line, the audit entry or the chat message must not
    be reported as a failure to record the decision — but it must not be
    silently claimed as a success either.
    """

    decision_id: str
    subject_kind: str          # "order" | "voyage"
    subject_id: str
    path: Path
    record: Dict[str, Any] = field(default_factory=dict)
    chat_message_id: str = ""
    lifecycle_written: bool = False
    audit_written: bool = False
    warnings: List[str] = field(default_factory=list)

    #: BUG-MSO-2026-0891. Keys on the artefact that a CONCURRENT, unlocked
    #: writer (the dispatcher mid-``ADVANCE``, say) changed between this
    #: call's first read and its write, and which this write therefore took
    #: from the fresh read rather than reverting. Informational, not a
    #: warning: preserving them is the fix WORKING, not a fault. Deliberately
    #: NOT in :meth:`to_dict` — that dict is the Hub's
    #: ``DecisionRecordResult`` wire shape, and this is a local diagnostic.
    preserved_keys: List[str] = field(default_factory=list)

    @property
    def decision(self) -> str:
        """The decision word, read off the record that is on disk."""
        return str(self.record.get("decision") or "")

    @property
    def ref(self) -> str:
        """The subject's in-artefact pointer, read off the same record."""
        subject = self.record.get("subject")
        return str(subject.get("ref") or "") if isinstance(subject, dict) else ""

    @property
    def decided_by(self) -> str:
        """The attributed name, read off the record on disk."""
        return str(self.record.get("decidedBy") or "")

    @property
    def verified(self) -> bool:
        """Whether that name is the identity the surface actually RESOLVED.

        Read off the record rather than off the call, for the same reason
        ``decision`` is: the record on disk is the only version that is true.
        """
        return bool(self.record.get("decidedByVerified"))

    @property
    def via(self) -> str:
        """Which surface recorded it — ``"cli"``, ``"hub"``, …"""
        return str(self.record.get("decidedVia") or "")

    @property
    def trust(self) -> str:
        """The provenance clause WITHOUT the surface — what the chat body
        carries. See :func:`describe_provenance`."""
        return describe_provenance(self.record, include_via=False)

    @property
    def provenance(self) -> str:
        """One human-readable clause naming who decided and how well that is
        known. The ONE describer — the lifecycle line, the audit metadata,
        the chat body, the CLI renderer and the Hub UI all show this same
        judgement, so no two surfaces can present the same record with
        different confidence (BUG-MSO-2026-0890)."""
        return describe_provenance(self.record)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "decisionId": self.decision_id,
            "subjectKind": self.subject_kind,
            "subjectId": self.subject_id,
            "path": str(self.path),
            "record": dict(self.record),
            "chatMessageId": self.chat_message_id,
            "lifecycleWritten": self.lifecycle_written,
            "auditWritten": self.audit_written,
            "warnings": list(self.warnings),
        }


# ---------------------------------------------------------------------------
# Subject resolution
# ---------------------------------------------------------------------------

def find_subject_file(mso: Path, subject: "DecisionSubject") -> "tuple[str, Path]":
    """``("order"|"voyage", path)`` for *subject* — or raise.

    An order is looked up with the SAME coverage ``order_retry`` uses for a
    stranded order (``orders/complete``, ``orders/failed``, ``queues/*/`` and
    ``queues/requests/*/``), not just the queue tree: "waive SEC F1, ship it"
    is precisely the kind of call made about an order that has already been
    archived, and a decision that cannot be recorded on an archived order
    would be useless exactly when it matters most.
    """
    mso = Path(mso)
    if subject.order_id:
        _assert_id_shape(subject.order_id, "orderId")
        path = _find_order_file(mso, subject.order_id)
        if path is None:
            raise DecisionSubjectNotFound(subject.order_id)
        return "order", path
    if subject.voyage_id:
        _assert_id_shape(subject.voyage_id, "voyageId")
        from maestro.core.voyage_core import find_voyage_file

        path = find_voyage_file(mso, subject.voyage_id)
        if path is None:
            raise DecisionSubjectNotFound(subject.voyage_id)
        return "voyage", path
    raise DecisionValidationError(
        "A decision must name the artefact it is about — subject.orderId for "
        "an order-level call, or subject.voyageId for a voyage-level one."
    )


def _assert_id_shape(value: str, field_name: str) -> None:
    if not _SUBJECT_ID_RE.match(value):
        raise DecisionValidationError(
            f"{field_name} '{value}' is not an artefact id — expected the "
            "TYPE-PRJ-YEAR-SEQ shape (letters, digits, '.', '_' and '-' only)."
        )


def _find_order_file(mso: Path, order_id: str) -> Optional[Path]:
    for sub in ("complete", "failed"):
        candidate = mso / "orders" / sub / f"{order_id}.json"
        if candidate.exists():
            return candidate
    from maestro.core.order_create import find_order_file

    path = find_order_file(mso, order_id)
    if path is not None:
        return path
    # An order still sitting in the (non-queue) active tree.
    candidate = mso / "orders" / "active" / f"{order_id}.json"
    return candidate if candidate.exists() else None


def decisions_on(mso: Path, subject: Any) -> List[Dict[str, Any]]:
    """Every decision recorded on *subject*'s artefact, oldest first.

    A READ. The whole point of promoting decisions onto the git-tracked plane
    is that they can be cited later, so reading them must not require the
    chat thread, the Hub or a daemon.
    """
    coerced = DecisionSubject.coerce(subject)
    _kind, path = find_subject_file(Path(mso), coerced)
    return _existing_decisions(_load_json(path, coerced.primary_id))


# ---------------------------------------------------------------------------
# Record
# ---------------------------------------------------------------------------

def record_decision(
    mso: Path,
    *,
    subject: Any,
    decision: str,
    rationale: str = "",
    decided_by: str = "",
    source_message_id: str = "",
    display_name: str = "",
    verified: bool = False,
    resolved_by: str = "",
    via: str = DECISION_VIA_CLI,
    workspace_root: Optional[Path] = None,
    post_to_chat: bool = True,
) -> RecordedDecision:
    """Record a Captain Decision on its order (or voyage) and return it.

    Does five things, in this order:

    (0) ``require_capability("lead.chat.decide")`` — FIRST, before anything is
        written, so a refusal in a governed/enterprise workspace leaves no
        half-recorded state. A no-op everywhere else.
    (a) appends the record to the artefact's ``captainDecisions[]`` inside
        ``workspace_scope(mso)``, under a cross-process lock on that subject,
        minting the id inside the lock and reading it back off disk;
    (b) writes the ``CAPTAIN_DECISION`` lifecycle line (metadata only);
    (c) writes the ``captain.decision`` audit entry (enterprise; a no-op
        otherwise, exactly like every other audit call site);
    (d) posts a ``decision`` message into the chat thread.

    (b)–(d) are best-effort and reported on :class:`RecordedDecision`. Once
    (a) has replaced the file the decision IS recorded; raising because a log
    line failed would tell the caller their decision was lost when it was not.

    Raises :class:`DecisionValidationError`, :class:`DecisionSubjectNotFound`,
    :class:`DecisionAlreadyRecorded` and ``CapabilityDenied`` — typed, never
    printed.

    **This does not change what any gate does.** See the module docstring.

    Attribution, and why ``verified`` is not simply believed
    -------------------------------------------------------
    BUG-MSO-2026-0890 (CWE-345). ``decided_by`` is a CLAIM: on the Hub it is
    a client-supplied ``by`` sent under one shared bearer token, and on the
    CLI it is the ``--by`` flag. ``resolved_by`` is what the surface actually
    RESOLVED — ``resolve_caller()``'s identity for the CLI, the Hub's own
    process identity for the Hub. Three fields go onto the record and all
    three are derived here rather than trusted from the caller:

    * ``decidedBy``     — ``decided_by`` if given, else ``resolved_by``;
    * ``decidedByVerified`` — ``verified`` AND the attributed name IS the
      resolved one. A caller that overrides the name has, by that act, made
      the record unverified, however verified its own session was. This is
      what stops ``--by "the Captain"`` from minting a verified record, and
      it closes the CLI half of the finding as well as the Hub half.
    * ``decidedVia``    — the SURFACE, set by the surface. No request model
      carries it, and none may: provenance a caller can choose is not
      provenance.

    Before this order the record carried none of the three beyond
    ``decidedBy``, and ``verified`` reached only the ephemeral chat message —
    so a Hub-typed name was indistinguishable, on the durable plane, from a
    CLI-resolved one.
    """
    mso = Path(mso)
    ws_root = Path(workspace_root) if workspace_root else mso.parent

    coerced = DecisionSubject.coerce(subject)
    decision_text = _validate_decision(decision)
    rationale_text = _validate_rationale(rationale)
    if coerced.ref and len(coerced.ref) > MAX_REF_CHARS:
        raise DecisionValidationError(
            f"subject.ref exceeds {MAX_REF_CHARS} characters — it is a pointer "
            "into the artefact, not the rationale."
        )
    claimed = validate_decided_by(decided_by, field="decidedBy")
    resolved = validate_decided_by(resolved_by, field="resolvedBy")
    actor = claimed or resolved or "unknown"
    # Verified only if the name WRITTEN is the name the surface PROVED. An
    # override is unverified by construction, whatever the caller passed.
    attributed_verified = derive_attributed_verified(
        verified=verified, attributed=actor, resolved=resolved)
    via_slug = _normalise_via(via)
    source_id = str(source_message_id or "").strip()

    from maestro.identity.gate import require_capability

    require_capability("lead.chat.decide", workspace=ws_root)

    subject_kind, path = find_subject_file(mso, coerced)
    subject_id = coerced.primary_id

    from maestro.core.order_retry import workspace_scope

    with _WRITE_LOCK:
        with _lock_for_subject(mso, subject_id):
            data = _load_json(path, subject_id)
            existing = _existing_decisions(data)

            # BUG-MSO-2026-0891 (CWE-362) — RE-READ immediately before the
            # write, and carry across ONLY ``captainDecisions``. See
            # `_reread_before_write` for why the first read is not enough.
            fresh = _reread_before_write(path, subject_id)
            merged, recovered = _merge_decision_lists(
                existing, _existing_decisions(fresh))
            preserved = _concurrently_written_keys(data, fresh)

            if source_id:
                duplicate = next(
                    (d for d in merged
                     if str(d.get("sourceMessageId") or "") == source_id),
                    None,
                )
                if duplicate is not None:
                    # Idempotent under concurrent confirms: the lock made the
                    # two attempts sequential, and THIS is what stops the
                    # second one appending a second record. Checked against
                    # the MERGED set, so a record written between the two
                    # reads is still seen (0891).
                    raise DecisionAlreadyRecorded(subject_id, duplicate)

            decision_id = _next_decision_id(merged)
            record = {
                "id": decision_id,
                "subject": coerced.to_dict(),
                "decision": decision_text,
                "rationale": rationale_text,
                "decidedBy": actor,
                "decidedByVerified": attributed_verified,
                "decidedVia": via_slug,
                "decidedAt": _iso_now(),
                "sourceMessageId": source_id or None,
            }
            # `fresh`, not `data`: every OTHER key is whatever the concurrent
            # writer left on disk, so its `verify{}` / `salvageBranches[]` /
            # `relSignOff{}` survives this write instead of being reverted to
            # the value read at the top of the function.
            fresh["captainDecisions"] = merged + [record]

            with workspace_scope(mso):
                _atomic_write_json(path, fresh)

            # Read the id back OFF DISK, from the file just written — never
            # trust the dict composed above (order_ids.py's rule; a write that
            # silently did not take must not be reported as a success).
            written = next(
                (d for d in _existing_decisions(_load_json(path, subject_id))
                 if str(d.get("id") or "") == decision_id),
                None,
            )
            if written is None:
                raise DecisionArtefactUnreadable(
                    f"Decision {decision_id} was not readable back from {path} "
                    "after writing — refusing to report it as recorded.",
                    client_detail=(
                        f"Decision {decision_id} was not readable back from "
                        f"the artefact for '{subject_id}' "
                        "after writing, so it is not being reported as "
                        "recorded. Check the workspace on the host."),
                )

    result = RecordedDecision(
        decision_id=str(written.get("id") or ""),
        subject_kind=subject_kind,
        subject_id=subject_id,
        path=path,
        record=written,
        preserved_keys=preserved,
    )
    if recovered:
        # ANOMALOUS, unlike `preserved_keys`: a concurrent writer replaced the
        # file with one whose `captainDecisions[]` was missing records this
        # process had already read. They were carried forward rather than
        # lost, but something clobbered a durable record and a human should
        # know (0891).
        result.warnings.append(
            "carried forward " + str(len(recovered)) + " decision(s) a "
            "concurrent write had dropped: " + ", ".join(recovered[:8])
            + ("…" if len(recovered) > 8 else "")
        )

    result.lifecycle_written = _write_lifecycle(mso, result, source_id)
    if not result.lifecycle_written:
        result.warnings.append("lifecycle line could not be written")

    result.audit_written = _write_audit(ws_root, result)

    if post_to_chat:
        try:
            result.chat_message_id = _post_decision_message(
                mso, result, coerced, decision_text, rationale_text,
                display_name, source_id,
            )
        except Exception as exc:  # noqa: BLE001 — never lose a recorded decision
            _log.debug("captain-decision: chat post failed", exc_info=True)
            result.warnings.append(f"chat message not posted ({type(exc).__name__})")

    return result


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------

def _validate_decision(decision: Any) -> str:
    text = str(decision or "").strip()
    if not text:
        raise DecisionValidationError(
            "A decision needs a decision — e.g. one of "
            f"{', '.join(KNOWN_DECISIONS)} (advisory, not a closed list)."
        )
    if len(text) > MAX_DECISION_CHARS:
        raise DecisionValidationError(
            f"decision exceeds {MAX_DECISION_CHARS} characters — the long form "
            "belongs in rationale."
        )
    if "\n" in text or "\r" in text:
        raise DecisionValidationError("decision must be a single line")
    return text


#: Anything a terminal would act on rather than print: the C0 range, DEL, and
#: the C1 range (which includes ``\x9b``, a single-byte CSI introducer).
_CONTROL_CHARS = re.compile(r"[\x00-\x1f\x7f-\x9f]")


def validate_decided_by(value: Any, *, field: str) -> str:
    """Bound and neutralise one attribution field (BUG-MSO-2026-0890
    DEF-003/DEF-004).

    ``decided_by`` is a CLAIM — the Hub's client-supplied ``by`` under a single
    shared bearer token, or the CLI's ``--by`` flag — and it is written to a
    git-tracked artefact that is then rendered into terminals, the Hub and the
    lifecycle log for as long as the order exists. It gets the same class of
    check :func:`_validate_decision` already applies, in the CORE so that every
    surface inherits one bound rather than each re-deriving its own:

    * **Length** — capped at :data:`MAX_DECIDED_BY_CHARS`.
    * **Control characters** — refused outright, not stripped. ``"alice\\x1b[2K
      \\x1b[1G\\x1b[A"`` is a durable payload that erases the ``UNVERIFIED:``
      warning the CLI prints two lines below the name, replaying for every
      future reader; ``sanitize_lifecycle_message`` handles newlines only.
      Refusing says so to whoever typed it, where silently rewriting the name
      would attribute the record to someone who never existed.

    Empty is fine and returns ``""`` — the caller falls back to the resolved
    identity, which is the ordinary no-override path.
    """
    text = str(value or "").strip()
    if not text:
        return ""
    if len(text) > MAX_DECIDED_BY_CHARS:
        raise DecisionValidationError(
            f"{field} exceeds {MAX_DECIDED_BY_CHARS} characters ({len(text)} "
            "given) — it names who decided, not why."
        )
    if _CONTROL_CHARS.search(text):
        raise DecisionValidationError(
            f"{field} contains control characters — it is written to a "
            "git-tracked record and rendered in terminals, so an escape "
            "sequence there is durable and replays for every later reader."
        )
    if "=" in text:
        raise DecisionValidationError(
            f"{field} may not contain '=' — it is interpolated into the "
            "CAPTAIN_DECISION lifecycle line, whose shape is key=value, so "
            "a name carrying one injects a second pair a parser can read as "
            "genuine. An identity never needs it."
        )
    return text


def derive_attributed_verified(*, verified: Any, attributed: Any,
                               resolved: Any) -> bool:
    """Is the name ABOUT TO BE WRITTEN a proven one?

    ``verified`` says how well the SESSION authenticated. This says whether
    that authority reaches the name on the record — it does not, if the caller
    overrode it. ``--by "the Captain"`` therefore cannot mint a verified
    record however well the operator authenticated, which closes the CLI half
    of BUG-MSO-2026-0890's finding as well as the Hub half.

    Exported so the CLI's dry-run **preview** and :func:`record_decision` share
    ONE derivation (SEC-BUG-MSO-2026-0890 INFO-2). Two copies agreed when they
    were written and compared a stripped value against an unstripped one; a
    preview that promises provenance the confirm will not write is this order's
    own finding in miniature — the operator is shown a provenance that never
    existed. Both sides also pass their inputs through
    :func:`validate_decided_by` first, so the comparison is on normalised
    values in both places.
    """
    attributed_text = str(attributed or "").strip()
    resolved_text = str(resolved or "").strip()
    return bool(verified) and bool(resolved_text) and attributed_text == resolved_text


def _validate_rationale(rationale: Any) -> str:
    text = str(rationale or "").strip()
    if len(text) > MAX_RATIONALE_CHARS:
        raise DecisionValidationError(
            f"rationale exceeds {MAX_RATIONALE_CHARS} characters ({len(text)} given)"
        )
    return text


# ---------------------------------------------------------------------------
# File plumbing
# ---------------------------------------------------------------------------

def _lock_for_subject(mso: Path, subject_id: str) -> "_CrossProcessLock":
    """Cross-process lock covering ONE subject's read-modify-write.

    Per subject rather than per workspace, so a decision on one order never
    serialises behind a decision on another. ``subject_id`` has already been
    through :data:`_SUBJECT_ID_RE`, which is what makes it safe to put in a
    filename.
    """
    return _CrossProcessLock(
        Path(mso) / "state" / f"captain-decision-{subject_id}.lock"
    )


def _load_json(path: Path, subject_id: str) -> Dict[str, Any]:
    """The subject artefact as a dict, or :class:`DecisionArtefactUnreadable`.

    Both failures here name the host path (and one of them the OS's own error
    text), which is what makes them diagnosable locally and what makes them
    unsafe to return to a remote caller — hence the two-message exception.
    """
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise DecisionArtefactUnreadable(
            f"Cannot read {path}: {exc}",
            client_detail=(
                f"The artefact for '{subject_id}' could not be read — it is "
                "missing, unreadable or not valid JSON. The decision was NOT "
                "recorded. Check the workspace on the host."),
        )
    if not isinstance(data, dict):
        raise DecisionArtefactUnreadable(
            f"{path} is not an object — cannot record a decision on {subject_id}",
            client_detail=(
                f"The artefact for '{subject_id}' is not a JSON object, so a "
                "decision cannot be recorded on it. The decision was NOT "
                "recorded."),
        )
    return data


def _existing_decisions(data: Dict[str, Any]) -> List[Dict[str, Any]]:
    """The artefact's current ``captainDecisions[]``, tolerantly.

    A non-list (or a list with non-dict members) is treated as "nothing
    recorded yet" for the members it cannot read, rather than raising: a
    malformed field must not make it impossible to record the decision, and
    the well-formed entries are still preserved.
    """
    raw = data.get("captainDecisions")
    if not isinstance(raw, list):
        return []
    return [dict(item) for item in raw if isinstance(item, dict)]


#: Bounded retry for the pre-write re-read below. A concurrent writer that
#: does NOT write atomically (``fleet_runner`` uses a bare ``write_text``) can
#: be caught mid-write, and on Windows an ``os.replace`` in flight can make an
#: ordinary ``open`` fail outright. Both are transient and measured in
#: milliseconds; a genuinely malformed or unreadable file still surfaces as
#: itself after the last attempt.
_REREAD_ATTEMPTS = 4
_REREAD_RETRY_INTERVAL_SECONDS = 0.02


def _reread_before_write(path: Path, subject_id: str) -> Dict[str, Any]:
    """Re-read the subject's JSON immediately before replacing it — the
    BUG-MSO-2026-0891 fix.

    WHY THE FIRST READ IS NOT ENOUGH. ``record_decision`` holds a lock that
    no other writer of the same file takes: it is private to this core
    (``state/captain-decision-<id>.lock``), while ``fleet_runner`` writes
    order and voyage JSONs with a bare ``write_text(json.dumps(...))`` under
    no lock at all. So the lock makes two DECISIONS serial and does nothing
    whatever about the dispatcher. A dispatcher write landing between this
    function's first read and its ``os.replace`` — a ``verify{}`` block, a
    ``salvageBranches[]`` entry, ``convergenceRetry{}``, ``requeueCount``, a
    ``relSignOff{}`` — would be silently reverted by writing back the copy
    read at the top, with no conflict detection and no warning.

    Re-reading here and carrying across ONLY ``captainDecisions`` shrinks the
    window from "the whole function" to "the final read-plus-replace", and
    makes the two writers' changes compose instead of one erasing the other
    whenever they touch different keys. It does NOT make the sequence atomic:
    a dispatcher write landing INSIDE that last window is still lost, because
    closing that would need the other writer to take a lock too. That is the
    codebase-wide write-discipline project this order deliberately scoped out
    (FTR-MSO-2026-0848's SEC report F3, rated MEDIUM for exactly this reason:
    it is the ambient pattern of every artefact writer here, and this
    function is the most careful instance of it, not the worst).

    Retries because the file being re-read may be mid-write: see
    :data:`_REREAD_ATTEMPTS`.
    """
    for attempt in range(_REREAD_ATTEMPTS - 1):
        try:
            return _load_json(path, subject_id)
        except DecisionValidationError:
            time.sleep(_REREAD_RETRY_INTERVAL_SECONDS)
    # The last attempt is deliberately unguarded: whatever it raises is the
    # real, non-transient fault, and it surfaces as itself.
    return _load_json(path, subject_id)


def _decision_key(item: Mapping[str, Any]) -> str:
    """Identity of one decision record, for the merge below.

    ``id`` when there is one — it is allocated per subject file and is what
    every other part of this module keys on. An entry with no id (hand-added,
    or written by something older) falls back to its own content, so it is
    still de-duplicated against an identical copy rather than doubled.
    """
    ident = str(item.get("id") or "").strip()
    if ident:
        return "id:" + ident
    return "body:" + json.dumps(dict(item), sort_keys=True, default=str)


def _merge_decision_lists(
    previous: List[Dict[str, Any]],
    current: List[Dict[str, Any]],
) -> "tuple[List[Dict[str, Any]], List[str]]":
    """``(merged, recovered_ids)`` — the union of both reads' decisions.

    ``current`` (the fresh read) wins on ordering and content, because it is
    what is on disk. Anything ``previous`` had that ``current`` no longer
    does is APPENDED rather than dropped: that only happens when a concurrent
    writer replaced the file with a copy whose ``captainDecisions[]`` was
    stale, and silently discarding an already-recorded decision would be the
    same class of loss this fix exists to stop, just in the other direction.

    ``recovered_ids`` names those, so the caller can say so instead of
    healing in silence.
    """
    merged = [dict(item) for item in current]
    seen = {_decision_key(item) for item in current}
    recovered: List[str] = []
    for item in previous:
        key = _decision_key(item)
        if key in seen:
            continue
        seen.add(key)
        merged.append(dict(item))
        recovered.append(str(item.get("id") or "?"))
    return merged, recovered


def _concurrently_written_keys(
    before: Mapping[str, Any],
    after: Mapping[str, Any],
) -> List[str]:
    """Top-level keys that changed between the two reads — i.e. what some
    OTHER writer did to this artefact while this call was in flight.

    ``captainDecisions`` is excluded: this function's own business is that
    key, and merging it is handled by :func:`_merge_decision_lists`.
    Reported, never acted on — the fresh values are kept either way.
    """
    missing = object()
    names = (set(before) | set(after)) - {"captainDecisions"}
    return sorted(
        name for name in names
        if before.get(name, missing) != after.get(name, missing)
    )


def _next_decision_id(existing: List[Dict[str, Any]]) -> str:
    """``DEC-0001`` upward, never reusing a number already on the artefact.

    Derived from the file's own contents under the lock — the same
    highest-existing-plus-one rule the workspace uses for order and voyage
    ids, and for the same reason: a count would collide the moment an entry
    were ever removed by hand.
    """
    highest = 0
    for item in existing:
        match = _DECISION_ID_RE.match(str(item.get("id") or ""))
        if match:
            highest = max(highest, int(match.group(1)))
    return f"{DECISION_ID_PREFIX}{highest + 1:04d}"


#: Windows-only: how long to keep retrying the final rename past a reader's
#: open handle (see :func:`_atomic_write_json`). Short, because the readers it
#: waits out are single ``read_text`` calls, and bounded, because a genuine
#: permissions fault must surface as one rather than hang.
_REPLACE_TIMEOUT_SECONDS = 10.0
_REPLACE_RETRY_INTERVAL_SECONDS = 0.02


def _atomic_write_json(path: Path, data: Dict[str, Any]) -> None:
    """Write-temp-then-replace, so a concurrent unlocked reader (the
    dispatcher's own scan, the Hub's poller) sees the old complete file or
    the new one, never a truncated one — BUG-MSO-2026-0621's fix, same shape
    as ``voyage_core._save_voyage``.

    With one addition that ``_save_voyage`` does not have and that concurrent
    confirms need: the rename RETRIES past ``PermissionError``. On Windows a
    file cannot be renamed over while any handle to it is open, and CPython's
    ``open()`` does not pass ``FILE_SHARE_DELETE`` — so an ordinary
    ``read_text`` anywhere else (another confirm resolving its subject, the
    dispatcher's queue scan, the Hub's poller) makes ``os.replace`` raise
    WinError 5 for as long as it holds the file. This is the same lesson
    ``order_ids._CrossProcessLock`` records for delete-pending paths, arriving
    from the other direction, and it is not theoretical: it failed the
    six-concurrent-confirms test on the first run, where the reader was
    another confirm's own subject lookup running OUTSIDE the write lock.

    Retrying is safe because the temp file is already complete on disk — the
    only thing being waited for is the moment nobody is reading the target.
    A POSIX rename never hits this path at all.
    """
    path = Path(path)
    tmp = path.with_name(f"{path.name}.tmp-{os.getpid()}-{threading.get_ident()}")
    tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
    deadline = time.monotonic() + _REPLACE_TIMEOUT_SECONDS
    while True:
        try:
            os.replace(str(tmp), str(path))
            return
        except PermissionError:
            if time.monotonic() >= deadline:
                # Clean up rather than leave a stray .tmp beside the artefact;
                # the caller sees the real error, which at this point is a
                # genuine permissions fault and not a transient reader.
                try:
                    tmp.unlink(missing_ok=True)
                except OSError:
                    pass
                raise
            time.sleep(_REPLACE_RETRY_INTERVAL_SECONDS)


def _iso_now() -> str:
    return datetime.now(timezone.utc).isoformat()


# ---------------------------------------------------------------------------
# Side effects (b) (c) (d) — best effort, honestly reported
# ---------------------------------------------------------------------------

def _write_lifecycle(mso: Path, result: RecordedDecision,
                     source_id: str) -> bool:
    """``CAPTAIN_DECISION id=… subject=… decision=… by=… verified=… via=… source=…``.

    ``verified``/``via`` are BUG-MSO-2026-0890: a reader grepping this log
    for a waiver must be able to see, on the line itself, whether the name
    beside ``by=`` was resolved or merely typed.

    METADATA ONLY. The rationale is Captain-authored free text and stays out,
    exactly as a chat body does (plan §0 Q3) — ``lifecycle.log`` is written
    for every workspace, read by the Hub and the patrol and swept into bug
    reports, and must not become a second, less-protected copy of the
    conversation. The rationale lives on the artefact, which is where a
    reader should go for it.

    Scoped: ``write_lifecycle_event`` resolves its target from
    ``fleet_runner._MAESTRO_DIR_OVERRIDE``, a process global, so an unscoped
    write from a Hub thread serving workspace A lands in workspace B's log.
    """
    try:
        from maestro.core.fleet_runner import write_lifecycle_event
        from maestro.core.order_retry import workspace_scope

        # ORDER MATTERS — do not move `verified=`/`via=` back behind `by=`
        # (BUG-MSO-2026-0890 DEF-002). They are the two keys a reader most
        # needs to trust, and `by=` is the one value on this line a client
        # supplies. Behind it, both were defeatable without touching the code:
        #
        #   * FORGERY — `by="alice verified=yes via=cli"` rendered
        #     `… by=alice verified=yes via=cli verified=no via=hub …`, and a
        #     first-match parse reads the forged pair.
        #   * TRUNCATION — `sanitize_lifecycle_message` cuts at 500 chars, so a
        #     long enough `by` dropped the genuine pair off the end entirely.
        #
        # First-match and truncation both now favour the authoritative values.
        # `validate_decided_by` bounds and de-controls `by` as well (DEF-003/4),
        # so this is the second of two independent guards, not the only one.
        detail = (
            f"id={result.decision_id} {result.subject_kind}={result.subject_id} "
            f"verified={'yes' if result.verified else 'no'} "
            f"via={result.via or 'unknown'} "
            f"decision={result.decision} by={result.decided_by} "
            f"source={source_id or '-'} ref={result.ref or '-'} "
            "(evidence only — changes no gate)"
        )
        with workspace_scope(Path(mso)):
            write_lifecycle_event(LIFECYCLE_EVENT, detail)
        return True
    except Exception:  # pragma: no cover - defensive
        _log.debug("captain-decision: lifecycle write failed", exc_info=True)
        return False


def _write_audit(ws_root: Path, result: RecordedDecision) -> bool:
    """``captain.decision`` in the hash-chained audit log.

    ``AuditLog.append`` is itself a no-op outside enterprise mode and returns
    ``None`` there, which is reported here as "not written" — honestly, not
    as a failure.

    ``actor`` is still the attributed name, because that IS who the record
    says decided — but ``actorVerified``/``via`` now travel beside it
    (BUG-MSO-2026-0890). An audit trail whose ``actor=`` field cannot be
    told apart from a proven one is the finding; naming the difference in
    the entry's own metadata is the fix, and it keeps the existing
    ``actor``-field semantics every other call site relies on.
    """
    try:
        from maestro.audit import get_audit_log

        entry = get_audit_log(Path(ws_root)).append(
            action=AUDIT_ACTION,
            target=result.subject_id,
            result="recorded",
            metadata={
                "decisionId": result.decision_id,
                "decision": result.decision,
                "ref": result.ref,
                "subjectKind": result.subject_kind,
                "sourceMessageId": result.record.get("sourceMessageId") or "",
                "path": str(result.path),
                "actorVerified": result.verified,
                "via": result.via,
                "provenance": result.provenance,
            },
            actor=result.decided_by,
        )
        return entry is not None
    except Exception:  # pragma: no cover - defensive
        _log.debug("captain-decision: audit write failed", exc_info=True)
        return False


def _post_decision_message(mso: Path, result: RecordedDecision,
                           subject: DecisionSubject, decision: str,
                           rationale: str, display_name: str,
                           source_id: str) -> str:
    """Post the ``decision`` message into the chat thread.

    Goes through ``maestro.lead.chat``'s own writer — the one thread writer —
    rather than formatting a line here. The confirmed record travels on the
    message's ``decisionDraft`` field: on a ``kind="decision"`` message that
    field holds the record AS WRITTEN, not a draft, which is what makes the
    thread's copy and the artefact's copy verifiably the same thing.

    The body names the boundary out loud. An operator reading the thread
    should never be left to infer that a waiver changed a gate.

    It also names the ATTRIBUTION out loud (BUG-MSO-2026-0890), from the
    record on disk rather than from the call, so the thread cannot present a
    typed name as a resolved one. The message author's ``verified`` flag is
    the same derived judgement, for the same reason: a message posted about
    an unverified record may not itself claim a verified author.
    """
    from maestro.lead import chat as _chat

    where = f"{subject.ref} on {result.subject_id}" if subject.ref else result.subject_id
    body = (
        f"Decision recorded: {decision} — {where}\n"
        f"{result.decision_id} on {result.path.name}, by {result.trust}.\n"
    )
    if rationale:
        body += f"\n{rationale}\n"
    body += (
        "\nRecorded as EVIDENCE only: this does not change what any gate does "
        "(SEC artefact, verify, review and the ledger veto all behave exactly "
        "as before)."
    )

    message = _chat.append_message(
        Path(mso),
        kind="decision",
        body=body,
        author=_chat.Author(
            kind="captain", id=result.decided_by,
            display_name=display_name or result.decided_by,
            verified=result.verified,
        ),
        in_reply_to=source_id or None,
        subject=_chat.Subject(
            order_id=subject.order_id, voyage_id=subject.voyage_id,
        ),
        decision_draft=dict(result.record),
    )
    return message.id

