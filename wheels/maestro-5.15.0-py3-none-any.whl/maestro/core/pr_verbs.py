"""maestro/core/pr_verbs.py — the one implementation of ``mso pr …``.

FTR-MSO-2026-0760 / PLAN-PLN-MSO-2026-0747 §3 (D2). The voyage-level REL pass
reaches its PR only through these verbs — never through raw ``gh`` or a
provider's REST API — so the same instruction works on every SCM/CI provider,
and so the scope rules below are enforced in Python rather than guessed at by a
branch-guard regex over arbitrary shell commands:

1. **The PR comes from the voyage branch, never from an argument.** It is the
   PR for ``$MAESTRO_VOYAGE_BRANCH`` (legacy ``$MAESTRO_SPRINT_BRANCH``), read
   from this process's environment. No verb accepts a PR number. The
   environment alone does not bind the scope — a process can be started with
   any value — so for a crew the binding is the pretool branch guard, which
   inherits the environment the DISPATCHER set and refuses a command that
   re-points either variable for an ``mso pr`` call (BUG-MSO-2026-0778). Like
   every branch-guard rule that is a regex over a shell string, not a security
   boundary; rules 2 and 3 hold whichever branch is named.
2. **A thread must be on that PR.** ``reply`` and ``resolve`` refuse a thread
   id the provider does not list for it — including when the provider could
   not list threads at all (fail closed).
3. **Only automated reviewers' threads are resolvable.** ``resolve`` refuses a
   thread whose author is not in ``providers.scm.config.reviewBots`` (the
   provider's default when unset). A human reviewer's thread is the Captain's.

**The PR is looked up in the voyage's own repository (BUG-MSO-2026-0825).** In
a multi-repo workspace (``artefacts.repos``) the voyage manifest for the branch
names its ``targetRepo``; the providers are scoped to that repos-map entry
(``maestro/core/repo_target.py``). Without it every verb asked the workspace's
PRIMARY repository and reported "no pull request found" for an open PR in a
secondary one. A voyage spanning several repos has no single PR, so the verbs
refuse rather than pick one. A single-repo workspace is unchanged.

Nothing here lands, tags or publishes anything; the providers expose no such
capability to call.

Shared-core contract (see ``order_retry.py``): explicit workspace path, typed
exceptions, no printing, no ``sys.exit``.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Mapping, Optional

from maestro.providers.base import PR_KEYS, STATUS_OK, ActionResult

VOYAGE_BRANCH_ENV_VARS = ("MAESTRO_VOYAGE_BRANCH", "MAESTRO_SPRINT_BRANCH")


class PrVerbError(Exception):
    """Base for every refusal/failure a ``mso pr`` verb raises."""

    hint: Optional[str] = None

    def __init__(self, message: str, hint: Optional[str] = None) -> None:
        super().__init__(message)
        if hint is not None:
            self.hint = hint


class NoVoyageBranch(PrVerbError):
    hint = "Set MAESTRO_VOYAGE_BRANCH to the voyage branch (the dispatcher sets it for every crew)."


class ProviderUnavailable(PrVerbError):
    hint = "Run `mso doctor --explain` to see how providers resolved for this workspace."


class PrNotFound(PrVerbError):
    pass


class ProviderLookupFailed(PrVerbError):
    hint = ("The provider could not answer, which is NOT the same as 'none'. Check `gh auth status` "
            "and connectivity, then retry; until it answers, report this item as SKIPPED with the reason.")


class AmbiguousVoyageRepo(PrVerbError):
    hint = ("This voyage spans more than one repository, so it has one PR per repository and "
            "`mso pr` cannot tell which one is meant. Review each repository's PR directly.")


class ThreadNotOnPr(PrVerbError):
    hint = "Run `mso pr threads` to list the threads on the voyage PR."


class ThreadNotResolvable(PrVerbError):
    hint = ("Only threads from automated reviewers listed in providers.scm.config.reviewBots "
            "may be resolved by `mso pr resolve`; a human reviewer's thread stays for the Captain.")


def voyage_branch(env: Optional[Mapping[str, str]] = None) -> str:
    source = os.environ if env is None else env
    for key in VOYAGE_BRANCH_ENV_VARS:
        value = (source.get(key) or "").strip()
        if value:
            return value
    raise NoVoyageBranch("no voyage branch: MAESTRO_VOYAGE_BRANCH is not set")


def voyage_repo(workspace: Path, branch: str):
    """The :class:`~maestro.core.repo_target.RepoTarget` the voyage on *branch*
    targets, or None for a single-repo workspace / a voyage naming no repo.

    Raises :class:`AmbiguousVoyageRepo` when the voyage resolves to more than
    one repository of the workspace's ``repos`` map."""
    from maestro.core import repo_target
    from maestro.workspace import artefact_root_for, repos_map_for, resolve_artefact_dir

    try:
        mso = resolve_artefact_dir(Path(workspace))
        repos = repos_map_for(mso)
        if not repos:
            return None
        artefact_root = artefact_root_for(Path(workspace))
    except Exception:
        return None
    voyage = repo_target.find_voyage_by_branch(artefact_root, branch)
    if voyage is None:
        return None
    org = repo_target.workspace_default_org(artefact_root)
    target = repo_target.voyage_repo_target(voyage, repos, org)
    if target is None:
        known = {t.name for t in (repo_target.resolve_repo_target(n, repos, org)
                                  for n in repo_target.voyage_repo_names(voyage)) if t}
        if len(known) > 1:
            raise AmbiguousVoyageRepo(
                f"voyage {voyage.get('id') or branch} spans {len(known)} repositories "
                f"({', '.join(sorted(known))}) — there is no single voyage PR")
    return target


def _resolved(kind: str, workspace: Path, repo=None):
    """The resolved provider for *kind*, scoped to the voyage's repository.

    A multi-repo voyage names its repository with *repo*, and ``repo_slug``
    scopes the provider to it (BUG-MSO-2026-0825). With no repos map there is
    no *repo*, and nothing here names a repository at all — so
    ``resolve_explain`` scopes the provider to the workspace's PRODUCT repo
    itself, which is BUG-MSO-2026-0897: in artefact-repo mode the workspace
    root is the ARTEFACT repo, a different GitHub repository, so every verb
    here asked the wrong one and reported an existing PR as absent.
    """
    from maestro.providers import resolve_explain

    if repo is None:
        resolved = resolve_explain(kind, workspace=workspace)
    else:
        resolved = resolve_explain(kind, workspace=workspace, repo_slug=repo.slug)
    if not resolved.available or resolved.provider is None:
        raise ProviderUnavailable(f"{kind} provider unavailable: {resolved.reason}")
    return resolved


def _where(repo) -> str:
    return f" in repository '{repo.slug}'" if repo is not None else ""


def voyage_pr(workspace: Path, env: Optional[Mapping[str, str]] = None):
    """``(resolved_scm, branch, pr)`` for the voyage branch, or raise."""
    scm, branch, pr, _repo = _voyage_pr(workspace, env)
    return scm, branch, pr


def _voyage_pr(workspace: Path, env: Optional[Mapping[str, str]] = None):
    branch = voyage_branch(env)
    repo = voyage_repo(workspace, branch)
    scm = _resolved("scm", workspace, repo)
    pr = scm.provider.get_pr_for_branch(branch)
    if not pr:
        raise PrNotFound(f"no pull request found for voyage branch '{branch}'{_where(repo)} "
                         f"via the '{scm.provider_id}' provider")
    return scm, branch, pr, repo


def _repo_fields(repo) -> dict:
    return {"repo": repo.slug} if repo is not None else {}


def _checked(result, what: str, provider_id: str) -> list:
    items, err = result
    if items is None:
        raise ProviderLookupFailed(
            f"could not list {what} via the '{provider_id}' provider: {err or 'unknown error'}")
    return items


def _pr_summary(pr: dict) -> dict:
    return {key: pr.get(key) for key in PR_KEYS}


def pr_status(workspace: Path, env: Optional[Mapping[str, str]] = None) -> dict:
    scm, branch, pr, repo = _voyage_pr(workspace, env)
    return {"provider": scm.provider_id, "tier": scm.tier, "branch": branch, **_repo_fields(repo),
            "pr": _pr_summary(pr)}


def pr_checks(workspace: Path, env: Optional[Mapping[str, str]] = None) -> dict:
    scm, branch, pr, repo = _voyage_pr(workspace, env)
    ci = _resolved("ci", workspace, repo)
    return {
        "provider": ci.provider_id, "tier": ci.tier, "branch": branch, **_repo_fields(repo),
        "pr": _pr_summary(pr),
        "checks": _checked(ci.provider.checks_for_pr_checked(pr), "CI checks", ci.provider_id),
    }


def pr_ci_log(workspace: Path, check: str, env: Optional[Mapping[str, str]] = None) -> ActionResult:
    _scm, _branch, pr, repo = _voyage_pr(workspace, env)
    ci = _resolved("ci", workspace, repo)
    return ci.provider.failed_log(pr, check)


def _bot_set(scm) -> set[str]:
    return {b.casefold() for b in scm.provider.review_bots()}


def pr_threads(workspace: Path, env: Optional[Mapping[str, str]] = None) -> dict:
    scm, branch, pr, repo = _voyage_pr(workspace, env)
    bots = _bot_set(scm)
    threads = []
    for thread in _checked(scm.provider.pr_review_threads_checked(pr), "review threads", scm.provider_id):
        author = thread.get("author") or ""
        threads.append({**thread, "fromReviewBot": bool(author) and author.casefold() in bots})
    return {
        "provider": scm.provider_id, "branch": branch, **_repo_fields(repo), "pr": _pr_summary(pr),
        "reviewBots": scm.provider.review_bots(), "threads": threads,
    }


def _thread_on_pr(scm, branch: str, pr: dict, thread_id: str) -> dict:
    threads = _checked(scm.provider.pr_review_threads_checked(pr), "review threads", scm.provider_id)
    for thread in threads:
        if thread.get("id") == thread_id:
            return thread
    raise ThreadNotOnPr(
        f"refused: thread '{thread_id}' is not a review thread on PR {pr.get('id')} for voyage "
        f"branch '{branch}' ({len(threads)} thread(s) listed)"
    )


def pr_reply(workspace: Path, thread_id: str, body: str, env: Optional[Mapping[str, str]] = None) -> ActionResult:
    scm, branch, pr = voyage_pr(workspace, env)
    _thread_on_pr(scm, branch, pr, thread_id)
    return scm.provider.reply_to_thread(pr, thread_id, body)


def pr_resolve(workspace: Path, thread_id: str, env: Optional[Mapping[str, str]] = None) -> ActionResult:
    scm, branch, pr = voyage_pr(workspace, env)
    thread = _thread_on_pr(scm, branch, pr, thread_id)
    author = thread.get("author") or ""
    if not author or author.casefold() not in _bot_set(scm):
        bots = ", ".join(scm.provider.review_bots()) or "none configured"
        raise ThreadNotResolvable(
            f"refused: thread '{thread_id}' was opened by '{author or 'unknown'}', which is not an "
            f"automated reviewer in reviewBots ({bots})"
        )
    if thread.get("isResolved"):
        return ActionResult(STATUS_OK, "thread was already resolved; nothing changed",
                            {"id": thread_id, "isResolved": True})
    return scm.provider.resolve_thread(pr, thread_id)
