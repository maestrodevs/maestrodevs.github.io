# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""maestro/core/plan_decomposition.py — plan approval as a TRIGGER, not a dead
end (FTR-MSO-2026-0860, PLAN-FTR-MSO-2026-0860).

``PLAN_ORPHANED`` is the dispatcher's own admission of a gap: it can detect
"this plan was approved and nothing exists to build it", but it has no
mechanism to generate what is missing. Two Captain-approved plans
(PLN-MSO-2026-0823, PLN-MSO-2026-0828) sat archived COMPLETE for two days with
their voyages stuck in exactly that state, until a LEAD read the plan prose by
hand and filed the orders it named. This module closes that gap at the source.

THE SHAPE, AND WHY IT IS THIS SHAPE
-----------------------------------

**D1 — the crew writes a MANIFEST; the ENGINE mints the orders.** A
decomposition crew never shells out to ``mso order create``. It writes one
machine-readable ```maestro-decomposition``` fence into a markdown document it
already owns (``plans/PLAN-<decomposition-order-id>.md``), and
:func:`file_decomposition_batch` parses that block and files the orders through
:func:`maestro.core.voyage_core.create_order_on_voyage` — the same core a human
LEAD's ``mso order create --voyage`` calls, so a framework-generated order is
byte-identical in shape to a hand-filed one.

Four reasons, none of them taste:

1. **Ids.** ``maestro/roles/PLN.md`` forbids reserving concrete ids, and
   records why: a plan that named ``BUG-MSO-2026-0470..0477`` had every one of
   those ids consumed by other work between planning and approval. The manifest
   references orders **positionally** (``order: 2``, ``dependsOn: [1]``) and
   the engine resolves position → real id AFTER allocation. An LLM cannot get
   this right by construction; a mapping pass can.
2. **Validation and rollback.** Type/role/status/priority/queue validation, id
   allocation under ``lock_for_allocation``, manifest attach and
   rollback-on-failed-attach all already exist in the cores. A crew running a
   CLI in a loop gets none of that transactionally, and a half-filed batch is
   precisely the "second, worse variant of PLAN_ORPHANED" the order forbids.
3. **Testability.** ``parse_manifest`` is pure and
   ``file_decomposition_batch`` takes an explicit workspace — both unit-testable
   without invoking Claude.
4. **Role contract.** PLN is read-and-plan. Writing a plan document is what it
   already does; filing orders would be a new capability for the role.

**D2 — the Captain reviews the breakdown BEFORE any id is minted**, at the
plan-review gate that already exists. The decomposition step is itself a
plan-only ``PLN`` order carrying ``decomposesPlan``, so it flows through
machinery that is already built, with zero new review UI:

    plan approved (PLAN_ORPHANED condition true)
      └─ engine files a decomposition order      (file_decomposition_order_if_due)
          └─ dispatcher runs it as an ordinary PLN crew
              └─ crew writes plans/PLAN-<decomp-id>.md  (prose + manifest fence)
                  └─ _maybe_hold_plan_for_review parks it NAV_REVIEW_PENDING
                      └─ `mso review show` / Hub /review render that document
                          ├─ approve → apply_decomposition_on_approval() files
                          │            the batch as PENDING on the voyage
                          ├─ revise  → back to PLN with the Captain's notes
                          └─ reject  → order FAILED; nothing was ever minted

The rejected alternative — file the batch ``PROPOSED`` and promote it on
approval — is not merely noisier, it **defeats its own gate**:
BUG-MSO-2026-0499's ``promote_ready_dependents`` releases a ``PROPOSED`` order
the instant its ``dependsOn`` is satisfied, i.e. the moment the decomposition
order completes — *before* the Captain looks.

**D5 — idempotent and loop-safe, three independent ways.** (a) The trigger
condition is self-extinguishing: it fires only at the exact ``PLAN_ORPHANED``
point, and the moment real dependents exist it is false. (b) A once-only
manifest marker (``voyage["planDecomposition"]``) plus adopt-an-unattached-order
recovery, the same device as ``voyageRelOrder``. (c) A ``decomposesPlan``
self-guard, because a decomposition order is itself a plan-only PLN order whose
own approval re-enters the same branch. Guard (a) would also catch (c) by then,
and both are kept — the belt-and-braces discipline ``salvage_arming`` and
``voyageRel`` already use. Filing is idempotent too:
``decompositionFiled.orderIds`` is recorded on the decomposition order, so a
retried approve (Hub clicked twice, CLI re-run after a crash) returns the same
ids rather than double-filing.

**D6 — failure is LOUD, because the existing detector goes SILENT.** The patrol
check ``voyages.planned-no-work`` requires every manifest order to be complete;
the moment a decomposition order joins the manifest and then stalls, that check
stops reporting. Shipping D1–D5 without ``voyages.plan-decomposition-failed``
would make detection *worse* than doing nothing. So: a parse/validation/attach
failure never archives the decomposition order — it stays ``NAV_REVIEW_PENDING``
in ``queues/review/`` where the Captain can ``revise`` it — and raises typed.

Exception contract (the shared-core contract, copied from
``maestro/core/order_retry.py``'s docstring rather than re-derived): explicit
``mso: Path`` throughout, no ``find_workspace()``, no CWD; typed exceptions,
no printing, no ``sys.exit``; every mutation inside
``order_retry.workspace_scope(mso)``; allocation and write inside the same
``lock_for_allocation`` block (owned by ``create_order_on_voyage``); no git
side effect from a core called over HTTP.
"""

from __future__ import annotations

import json
import re
import unicodedata
from bisect import bisect_right
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

from maestro.core.order_ids import OrderValidationError

#: Manifest schema this module writes and accepts.
SCHEMA_VERSION = "1.0"

#: The fenced-block language tag a decomposition crew must use.
FENCE_LANGUAGE = "maestro-decomposition"

#: Field name carried on a decomposition order naming the plan it decomposes.
#: Its presence is the recursion self-guard (D5c) AND the marker
#: ``review_core.approve_order`` routes on.
DECOMPOSES_PLAN_FIELD = "decomposesPlan"

#: Field name recording what a completed batch filed (D5, idempotency).
FILED_FIELD = "decompositionFiled"

#: Manifest marker on the VOYAGE recording that a decomposition order was
#: filed for a given plan — the once-only guard, mirroring ``voyageRelOrder``.
VOYAGE_MARKER_FIELD = "planDecomposition"

#: roleSequence of the decomposition order itself. Plan-only, deliberately:
#: it must reach the plan-review gate (``_maybe_hold_plan_for_review`` keys on
#: a planning role with no next role), and it must never build anything.
DECOMPOSITION_ROLE_SEQUENCE = ("PLN",)

#: Default ceiling on one batch. A plan that wants more orders than this is
#: telling the Captain something; refuse and say so.
DEFAULT_MAX_ORDERS = 25

#: Bounds on LLM-authored free text before it reaches the filesystem and argv.
#: ``create_order`` names files by allocated id only (never by title), but the
#: title still reaches lifecycle logs, PR bodies and the manifest.
MAX_TITLE_LENGTH = 200
MAX_DESCRIPTION_LENGTH = 8000
MAX_CRITERION_LENGTH = 1000
MAX_ACCEPTANCE_CRITERIA = 40

#: An id-shaped token. A ``dependsOn`` entry matching this is REFUSED — that is
#: exactly the reserved-id mistake PLN.md documents.
_ORDER_ID_RE = re.compile(r"^[A-Z]{3}-[A-Z0-9]+-\d{4}-\d{3,}$", re.IGNORECASE)

#: Ceiling on a plan document read from disk, in bytes (SEC-001).
#: A plan document is prose a planning crew wrote about one piece of work;
#: 100 KB of that is large but entirely ordinary, and the realistic documents
#: this feature produces sit well below it. Anything past this ceiling is not
#: a plan — it is a crew-authored file being handed, unattended, to the patrol
#: check that re-reads every pending breakdown on every ``mso doctor`` run and
#: every resident-LEAD tick. Refused outright rather than truncated: a
#: truncated read would silently change WHICH breakdown the Captain approves,
#: which is the one thing this gate exists to prevent.
MAX_PLAN_DOCUMENT_BYTES = 256 * 1024

#: The OPENING fence line, matched against one line at a time.
#: Tolerant of ``~~~`` and of trailing spaces/tabs after the tag, because a
#: crew writes this by hand into prose.
#:
#: **Why a line matcher and not one whole-document regex (SEC-001, HIGH).**
#: The original pattern put a lazy body ``(?P<body>.*?)`` in front of ``^``.
#: ``^`` compiles to ``AT_BEGINNING_LINE``, not a literal, so CPython's
#: ``MIN_REPEAT_ONE`` skip optimisation never applied: the engine stepped the
#: lazy repeat one character at a time and retried the whole tail at every
#: position, and ``finditer`` then paid a full scan-to-EOF for EVERY opening
#: fence that never found a close — O(K*n) in K unclosed opening fences.
#: Measured at 2.9 s for 147 KB and ~11 s for 285 KB, per unattended patrol
#: tick, on a document an autonomous crew authored. Not exponential (there is
#: no nested quantifier), but quadratic over an unbounded input is sufficient
#: on its own. :func:`_scan_manifest_blocks` below is O(n): every line is
#: classified exactly once, and a closing fence is located by bisection over a
#: prebuilt index rather than by re-scanning the tail.
_OPEN_FENCE_LINE_RE = re.compile(
    r"[ \t]*(?P<fence>`{3,}|~{3,})[ \t]*" + re.escape(FENCE_LANGUAGE) + r"[ \t]*\Z"
)


# ---------------------------------------------------------------------------
# Typed exceptions
# ---------------------------------------------------------------------------

class DecompositionManifestError(OrderValidationError):
    """The manifest is missing, unparseable, or violates its own contract.

    Subclasses ``OrderValidationError`` so every caller that already maps that
    to a 400 (Hub) or a printed refusal (CLI) inherits the behaviour — the
    shared-core exception contract, not a new dialect.
    """


class DecompositionBatchFailed(Exception):
    """A manifest parsed cleanly but the batch could not be filed.

    Carries what DID land (``filed``) so a retry resumes rather than
    duplicates, and never leaves a caller guessing whether anything was
    written.
    """

    def __init__(self, message: str, *, decomposition_order_id: str = "",
                 filed: Optional[Sequence[str]] = None,
                 cause: Optional[BaseException] = None) -> None:
        super().__init__(message)
        self.decomposition_order_id = decomposition_order_id
        self.filed = list(filed or [])
        self.cause = cause


# ---------------------------------------------------------------------------
# Typed manifest
# ---------------------------------------------------------------------------

@dataclass
class ProposedOrder:
    """One order a decomposition crew proposes. ``position`` is positional —
    never an id (D1 reason 1)."""

    position: int
    order_type: str
    title: str
    description: str = ""
    priority: str = ""
    role_sequence: List[str] = field(default_factory=list)
    acceptance_criteria: List[Any] = field(default_factory=list)
    #: Positions within this same manifest.
    depends_on: List[int] = field(default_factory=list)
    #: Ids of orders that ALREADY exist on disk. The separate key exists so an
    #: id-shaped string in ``dependsOn`` can be refused outright.
    depends_on_existing: List[str] = field(default_factory=list)


@dataclass
class DecompositionManifest:
    """A parsed, validated ``maestro-decomposition`` block."""

    schema_version: str
    plan_order: str
    voyage_id: str
    orders: List[ProposedOrder] = field(default_factory=list)


@dataclass
class FiledBatch:
    """What :func:`file_decomposition_batch` landed."""

    order_ids: List[str] = field(default_factory=list)
    paths: List[str] = field(default_factory=list)
    voyage_id: str = ""
    #: True when the batch was already on record and nothing new was written.
    already_filed: bool = False


# ---------------------------------------------------------------------------
# Config — strictly opt-in
# ---------------------------------------------------------------------------

def enabled_from(block: Any) -> bool:
    """``completion.planDecomposition.enabled`` — strictly opt-in (D3).

    Only a literal JSON ``true`` enables it: a malformed block, a string
    ``"true"`` and an absent key all read as off, because the off state is the
    one whose behaviour is guaranteed identical to a pre-0860 build. Copied
    verbatim from ``fleet_runner._voyage_rel_enabled_from`` rather than
    re-derived — the two must not drift.
    """
    if not isinstance(block, dict):
        return False
    return block.get("enabled", False) is True


def max_orders_from(block: Any, default: int = DEFAULT_MAX_ORDERS) -> int:
    """``completion.planDecomposition.maxOrders``, degrading to *default*.

    A hand-edited workspace.json is the normal source, so a string, a null, a
    zero or a negative must degrade rather than raise inside a config load.
    """
    if not isinstance(block, dict):
        return default
    try:
        parsed = int(block.get("maxOrders", default))
    except (TypeError, ValueError):
        return default
    return parsed if parsed > 0 else default


def _completion_block(mso: Path) -> Any:
    """``completion.planDecomposition`` read from *mso*'s own workspace.json.

    Read DIRECTLY rather than through ``fleet_runner.load_completion_config``
    on purpose: that function resolves its workspace from a process global, and
    this core is called from the Hub, which serves N workspaces from one
    process. ``enabled_from`` / ``max_orders_from`` above hold the semantics, so
    the dispatcher's config load and this one cannot disagree about what the
    block MEANS — only about which file it came from, which is the point.
    """
    try:
        raw = json.loads((Path(mso) / "config" / "workspace.json").read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError, UnicodeDecodeError):
        return {}
    if not isinstance(raw, dict):
        return {}
    completion = raw.get("completion")
    if not isinstance(completion, dict):
        return {}
    return completion.get("planDecomposition", {})


def plan_decomposition_enabled(mso: Path) -> bool:
    """True only when *mso*'s ``completion.planDecomposition.enabled`` is
    literally ``true``. Never raises."""
    return enabled_from(_completion_block(mso))


def configured_max_orders(mso: Path) -> int:
    """*mso*'s batch ceiling. Never raises."""
    return max_orders_from(_completion_block(mso))


# ---------------------------------------------------------------------------
# Manifest parsing — every rule a REFUSAL, never a silent fix
# ---------------------------------------------------------------------------

def _line_spans(text: str) -> List[tuple]:
    r"""``(start, content_end, next_start)`` for every line, in one pass.

    ``content_end`` excludes the terminating newline, so a slice
    ``text[start:content_end]`` is the line's content — exactly what
    ``^...$`` matched under ``re.MULTILINE``. ``\r`` is deliberately left IN
    the content, so a CRLF document that never went through universal-newline
    translation fails the fence match here exactly as it failed the old
    ``[ \t]*$``.
    """
    spans: List[tuple] = []
    start = 0
    length = len(text)
    while start <= length:
        newline = text.find("\n", start)
        if newline == -1:
            spans.append((start, length, length + 1))
            break
        spans.append((start, newline, newline + 1))
        start = newline + 1
    return spans


def _is_bare_fence(line: str) -> str:
    r"""The fence run of a line that is nothing but one backtick or tilde
    run of three or more, with optional surrounding spaces/tabs — otherwise
    the empty string.

    This is ``^[ \t]*(?P=fence)[ \t]*$`` restated as an O(len) test, so a
    closing fence can be INDEXED instead of searched for.
    """
    stripped = line.strip(" \t")
    if len(stripped) < 3:
        return ""
    head = stripped[0]
    if head not in ("`", "~"):
        return ""
    if stripped.count(head) != len(stripped):
        return ""
    return stripped


def _scan_manifest_blocks(text: str) -> List[tuple]:
    """``(body_start, body_end)`` for every complete fenced block. O(n).

    Behaviourally identical to the ``_FENCE_RE.finditer`` it replaces — the
    equivalence is pinned test-by-test in
    ``tests/test_plan_decomposition_fence_scan.py::TestFenceEquivalence`` — but
    linear instead of quadratic:

    * every line is classified exactly once (opening fence? bare fence run?);
    * a closing fence is found by bisecting a prebuilt index of bare-fence
      lines keyed on the exact run, not by re-scanning the rest of the
      document;
    * an opening fence that never closes therefore costs O(log n), not a
      scan to EOF — which is the whole of SEC-001.

    ``finditer``'s non-overlapping semantics are preserved: a closed block
    consumes its lines, and an unclosed opening fence consumes only itself, so
    a later fence can still open a block.
    """
    spans = _line_spans(text)
    closers: Dict[str, List[int]] = {}
    for index, (start, content_end, _) in enumerate(spans):
        run = _is_bare_fence(text[start:content_end])
        if run:
            closers.setdefault(run, []).append(index)

    blocks: List[tuple] = []
    index = 0
    total = len(spans)
    while index < total:
        start, content_end, _ = spans[index]
        opening = _OPEN_FENCE_LINE_RE.fullmatch(text, start, content_end)
        if opening is None:
            index += 1
            continue
        candidates = closers.get(opening.group("fence"))
        close_at = -1
        if candidates:
            position = bisect_right(candidates, index)
            if position < len(candidates):
                close_at = candidates[position]
        if close_at == -1:
            index += 1          # unclosed — consumes only its own line
            continue
        blocks.append((content_end, spans[close_at][0]))
        index = close_at + 1
    return blocks


def extract_manifest_block(text: str) -> Optional[str]:
    """The raw JSON inside the ``maestro-decomposition`` fence, or ``None``.

    Refuses ambiguity rather than guessing: two fences in one document is a
    :class:`DecompositionManifestError`, because silently taking the first
    would file a batch the Captain did not read.
    """
    text = text or ""
    blocks = _scan_manifest_blocks(text)
    if not blocks:
        return None
    if len(blocks) > 1:
        raise DecompositionManifestError(
            f"{len(blocks)} `{FENCE_LANGUAGE}` blocks found in the plan document — "
            "exactly one is expected. Merge them into a single block; taking the "
            "first would file a breakdown the reviewer did not read."
        )
    body_start, body_end = blocks[0]
    return text[body_start:body_end]


def _clean_text(value: Any, *, field_name: str, limit: int,
                required: bool = False, allow_newlines: bool = True) -> str:
    """Bound and sanitise one LLM-authored free-text field.

    Control characters are stripped (not escaped) because this text reaches
    lifecycle logs, whose one-line-per-event contract a raw newline breaks, and
    PR bodies. The length bound is enforced HERE rather than left to
    ``create_order``: ``validate_description`` bounds the title at 500 but does
    not bound ``description`` at all.
    """
    if value is None:
        text = ""
    elif isinstance(value, str):
        text = value
    else:
        raise DecompositionManifestError(
            f"{field_name} must be a string, got {type(value).__name__}")
    # Normalise CRLF first: handled character-by-character below, a "\r\n"
    # would become two newlines rather than one.
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    cleaned_chars = []
    for ch in text:
        if ch in ("\n", "\r", "\t"):
            cleaned_chars.append("\n" if allow_newlines and ch != "\t" else " ")
            continue
        if unicodedata.category(ch) in ("Cc", "Cf", "Cs"):
            continue
        cleaned_chars.append(ch)
    cleaned = "".join(cleaned_chars).strip()
    if required and not cleaned:
        raise DecompositionManifestError(f"{field_name} is required and was empty")
    if len(cleaned) > limit:
        raise DecompositionManifestError(
            f"{field_name} is {len(cleaned)} characters, over the {limit} limit")
    return cleaned


def _clean_title(value: Any, *, position: int) -> str:
    """A title with a path separator in it is refused, not sanitised.

    ``create_order`` names files by allocated id only, so a separator cannot
    reach a path today — but the refusal is kept because the title DOES reach
    branch names, PR bodies and shell-rendered lifecycle lines, and "it happens
    not to be used as a path right now" is not a property to depend on.
    """
    title = _clean_text(value, field_name=f"orders[{position}].title",
                        limit=MAX_TITLE_LENGTH, required=True, allow_newlines=False)
    for bad in ("/", "\\", "\x00"):
        if bad in title:
            raise DecompositionManifestError(
                f"orders[{position}].title contains {bad!r} — titles must not "
                "contain path separators")
    return title


def _as_positive_int(value: Any, *, field_name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise DecompositionManifestError(
            f"{field_name} must be an integer, got {value!r}")
    if value <= 0:
        raise DecompositionManifestError(
            f"{field_name} must be a positive integer, got {value}")
    return value


def _parse_depends_on(raw: Any, *, position: int) -> "tuple[List[int], List[str]]":
    """Split a ``dependsOn`` list into positions, refusing id-shaped strings."""
    if raw is None:
        return [], []
    if not isinstance(raw, list):
        raise DecompositionManifestError(
            f"orders[{position}].dependsOn must be a list of positions")
    positions: List[int] = []
    for entry in raw:
        if isinstance(entry, str):
            if _ORDER_ID_RE.match(entry.strip()):
                raise DecompositionManifestError(
                    f"orders[{position}].dependsOn names a concrete order id "
                    f"{entry!r}. Ids are allocated AFTER review, so no id named "
                    "here can be trusted (maestro/roles/PLN.md records a plan "
                    "whose eight reserved ids were all consumed by other work "
                    "before it was approved). Reference a position from this "
                    "manifest, or use dependsOnExisting for an order that "
                    "already exists on disk.")
            raise DecompositionManifestError(
                f"orders[{position}].dependsOn entry {entry!r} is a string — "
                "dependsOn holds integer positions from this manifest")
        positions.append(_as_positive_int(
            entry, field_name=f"orders[{position}].dependsOn entry"))
    return positions, []


def _parse_depends_on_existing(raw: Any, *, position: int) -> List[str]:
    if raw is None:
        return []
    if not isinstance(raw, list):
        raise DecompositionManifestError(
            f"orders[{position}].dependsOnExisting must be a list of order ids")
    ids: List[str] = []
    for entry in raw:
        if not isinstance(entry, str) or not _ORDER_ID_RE.match(entry.strip()):
            raise DecompositionManifestError(
                f"orders[{position}].dependsOnExisting entry {entry!r} is not an "
                "order id (e.g. FTR-MSO-2026-0123)")
        ids.append(entry.strip().upper())
    return ids


def _parse_acceptance_criteria(raw: Any, *, position: int) -> List[Any]:
    if raw is None:
        return []
    if not isinstance(raw, list):
        raise DecompositionManifestError(
            f"orders[{position}].acceptanceCriteria must be a list")
    if len(raw) > MAX_ACCEPTANCE_CRITERIA:
        raise DecompositionManifestError(
            f"orders[{position}].acceptanceCriteria has {len(raw)} entries, "
            f"over the {MAX_ACCEPTANCE_CRITERIA} limit")
    criteria: List[Any] = []
    for index, entry in enumerate(raw):
        if isinstance(entry, dict):
            # An AC object (id/description/validationType) — bound its strings
            # and pass it through; order_create owns its shape.
            bounded = {}
            for key, value in entry.items():
                bounded[str(key)] = (
                    _clean_text(value, field_name=f"orders[{position}].acceptanceCriteria[{index}].{key}",
                                limit=MAX_CRITERION_LENGTH)
                    if isinstance(value, str) else value)
            criteria.append(bounded)
            continue
        criteria.append(_clean_text(
            entry, field_name=f"orders[{position}].acceptanceCriteria[{index}]",
            limit=MAX_CRITERION_LENGTH, required=True))
    return criteria


def _validate_dependency_graph(orders: Sequence[ProposedOrder]) -> None:
    """Positions unique; every ``dependsOn`` declared; no self-reference; no cycle."""
    seen: Dict[int, ProposedOrder] = {}
    for proposed in orders:
        if proposed.position in seen:
            raise DecompositionManifestError(
                f"duplicate order position {proposed.position} — positions must be unique")
        seen[proposed.position] = proposed

    for proposed in orders:
        for dep in proposed.depends_on:
            if dep == proposed.position:
                raise DecompositionManifestError(
                    f"orders[{proposed.position}] depends on itself")
            if dep not in seen:
                raise DecompositionManifestError(
                    f"orders[{proposed.position}].dependsOn references position "
                    f"{dep}, which this manifest does not declare")

    # Iterative DFS with an explicit colour map — a manifest is small, but a
    # recursive walk on crew-authored input is a needless stack risk.
    WHITE, GREY, BLACK = 0, 1, 2
    colour = {pos: WHITE for pos in seen}
    for start in list(seen):
        if colour[start] != WHITE:
            continue
        stack: List["tuple[int, bool]"] = [(start, False)]
        path: List[int] = []
        while stack:
            node, leaving = stack.pop()
            if leaving:
                colour[node] = BLACK
                path.pop()
                continue
            if colour[node] == GREY:
                continue
            colour[node] = GREY
            path.append(node)
            stack.append((node, True))
            for dep in seen[node].depends_on:
                if colour[dep] == GREY:
                    cycle = " -> ".join(str(p) for p in path[path.index(dep):] + [dep])
                    raise DecompositionManifestError(
                        f"dependsOn forms a cycle: {cycle}")
                if colour[dep] == WHITE:
                    stack.append((dep, False))


def parse_manifest(text: str, *, plan_order: str, voyage_id: str,
                   max_orders: int = DEFAULT_MAX_ORDERS) -> DecompositionManifest:
    """Parse and validate the ``maestro-decomposition`` block in *text*.

    Validates the MANIFEST'S OWN invariants only — positions, the dependency
    graph, matching plan/voyage, batch size, and text bounds. Type, role
    sequence, priority and status are **not** re-validated here:
    ``order_create.create_order`` owns those (``normalise_role_sequence``
    already refuses ``LEAD`` and normalises the legacy nautical codes), and a
    second implementation is a second place for them to drift.

    Never repairs. Every violation raises :class:`DecompositionManifestError`
    naming the offending entry.
    """
    block = extract_manifest_block(text)
    if block is None:
        raise DecompositionManifestError(
            f"no ```{FENCE_LANGUAGE}``` block found in the plan document — the "
            "decomposition crew must write its proposed order breakdown as a "
            "single fenced JSON block (see maestro/docs/PLAN-DECOMPOSITION.md)")

    try:
        payload = json.loads(block)
    except json.JSONDecodeError as exc:
        raise DecompositionManifestError(
            f"the `{FENCE_LANGUAGE}` block is not valid JSON: {exc}") from exc

    if not isinstance(payload, dict):
        raise DecompositionManifestError(
            f"the `{FENCE_LANGUAGE}` block must be a JSON object, got "
            f"{type(payload).__name__}")

    schema_version = str(payload.get("schemaVersion") or "").strip()
    if schema_version != SCHEMA_VERSION:
        raise DecompositionManifestError(
            f"unsupported schemaVersion {schema_version!r} — this build accepts "
            f"{SCHEMA_VERSION!r}")

    declared_plan = str(payload.get("planOrder") or "").strip().upper()
    declared_voyage = str(payload.get("voyageId") or "").strip().upper()
    expected_plan = (plan_order or "").strip().upper()
    expected_voyage = (voyage_id or "").strip().upper()
    if expected_plan and declared_plan != expected_plan:
        raise DecompositionManifestError(
            f"manifest planOrder {declared_plan or '(missing)'} does not match the "
            f"decomposition order's own plan {expected_plan} — a manifest naming a "
            "different plan is refused, not honoured")
    if expected_voyage and declared_voyage != expected_voyage:
        raise DecompositionManifestError(
            f"manifest voyageId {declared_voyage or '(missing)'} does not match the "
            f"decomposition order's own voyage {expected_voyage} — a manifest naming "
            "a different voyage is refused, not honoured")

    raw_orders = payload.get("orders")
    if not isinstance(raw_orders, list) or not raw_orders:
        raise DecompositionManifestError(
            "the manifest declares no orders — an empty breakdown cannot be "
            "approved; revise the decomposition order instead")
    if len(raw_orders) > max_orders:
        raise DecompositionManifestError(
            f"the manifest declares {len(raw_orders)} orders, over the "
            f"completion.planDecomposition.maxOrders ceiling of {max_orders}. A "
            "plan that needs more than that is telling the Captain something — "
            "split the voyage, or raise the ceiling deliberately")

    orders: List[ProposedOrder] = []
    for index, raw in enumerate(raw_orders):
        if not isinstance(raw, dict):
            raise DecompositionManifestError(
                f"orders[{index}] must be a JSON object, got {type(raw).__name__}")
        position = _as_positive_int(raw.get("order"), field_name=f"orders[{index}].order")
        role_sequence_raw = raw.get("roleSequence")
        if role_sequence_raw is not None and not isinstance(role_sequence_raw, list):
            raise DecompositionManifestError(
                f"orders[{position}].roleSequence must be a list of role codes")
        depends_on, _ = _parse_depends_on(raw.get("dependsOn"), position=position)
        orders.append(ProposedOrder(
            position=position,
            order_type=str(raw.get("type") or "").strip().upper(),
            title=_clean_title(raw.get("title"), position=position),
            description=_clean_text(
                raw.get("description"), field_name=f"orders[{position}].description",
                limit=MAX_DESCRIPTION_LENGTH),
            priority=str(raw.get("priority") or "").strip().upper(),
            role_sequence=[str(r) for r in (role_sequence_raw or [])],
            acceptance_criteria=_parse_acceptance_criteria(
                raw.get("acceptanceCriteria"), position=position),
            depends_on=depends_on,
            depends_on_existing=_parse_depends_on_existing(
                raw.get("dependsOnExisting"), position=position),
        ))

    _validate_dependency_graph(orders)

    return DecompositionManifest(
        schema_version=schema_version,
        plan_order=declared_plan or expected_plan,
        voyage_id=declared_voyage or expected_voyage,
        orders=orders,
    )


# ---------------------------------------------------------------------------
# Order-record helpers (explicit mso, no CWD)
# ---------------------------------------------------------------------------

_ORDER_SEARCH_DIRS = (
    "queues/review", "queues/orders", "queues/bugs", "queues/security",
    "queues/explicit", "queues/breakdown", "queues/high-level", "queues/defects",
    "queues/proposed", "queues/escalations",
    "orders/complete", "orders/failed", "orders/active",
)


def find_order_path(mso: Path, order_id: str) -> Optional[Path]:
    """Locate *order_id*'s JSON anywhere in *mso*, review queue first."""
    mso = Path(mso)
    for sub in _ORDER_SEARCH_DIRS:
        candidate = mso / sub / f"{order_id}.json"
        if candidate.exists():
            return candidate
    requests = mso / "queues" / "requests"
    if requests.is_dir():
        for child in sorted(requests.iterdir()):
            candidate = child / f"{order_id}.json"
            if child.is_dir() and candidate.exists():
                return candidate
    return None


def load_order(mso: Path, order_id: str) -> "tuple[Optional[Path], Optional[dict]]":
    """``(path, data)`` for *order_id*, or ``(None, None)``. Never raises."""
    path = find_order_path(mso, order_id)
    if path is None:
        return None, None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError, UnicodeDecodeError):
        return path, None
    return path, (data if isinstance(data, dict) else None)


def is_decomposition_order(data: Any) -> bool:
    """True when *data* is a decomposition order (carries ``decomposesPlan``)."""
    return bool(isinstance(data, dict) and data.get(DECOMPOSES_PLAN_FIELD))


def plan_document_path(mso: Path, order_id: str) -> Path:
    """``plans/PLAN-<order-id>.md`` — the EXACT filename ``review_artefact()``
    resolves. Anything else and neither ``mso review show`` nor the Hub's
    ``/review`` page renders the breakdown the Captain is meant to approve."""
    return Path(mso) / "plans" / f"PLAN-{order_id}.md"


def read_plan_document(doc: Path) -> str:
    """Read a plan document, bounded at :data:`MAX_PLAN_DOCUMENT_BYTES`.

    **The one way any caller reads a plan document** (SEC-001). There are two
    — ``apply_decomposition_on_approval`` here, and the ``mso doctor`` /
    resident-LEAD patrol check in ``maestro/patrol/checks/voyages.py`` — and
    the second has no human in the loop, so a bound applied to only the first
    would leave the exposed caller exposed. One helper, so a third caller
    inherits the bound rather than forgetting it.

    Read in TEXT mode after a ``stat()`` bound rather than by reading N bytes:
    universal-newline translation is what lets a Windows crew's CRLF document
    parse at all, and a byte-slice read both loses it and can cut a multi-byte
    character in half. ``stat()`` measures bytes and the ceiling is in bytes,
    so the two agree.

    Raises :class:`DecompositionManifestError` when the document is over the
    ceiling — refused, never truncated, because a truncated read would change
    WHICH breakdown the Captain is shown. ``OSError`` (a missing or unreadable
    file) is left to propagate: each caller already has its own, better message
    for that.
    """
    size = doc.stat().st_size          # OSError propagates — see docstring
    if size > MAX_PLAN_DOCUMENT_BYTES:
        raise DecompositionManifestError(
            f"the plan document {doc} is {size:,} bytes, over the "
            f"{MAX_PLAN_DOCUMENT_BYTES:,}-byte ceiling — it is refused unread. "
            "A plan document is prose about one piece of work; something this "
            "size is not a breakdown a reviewer can read, and parsing it "
            "unattended is what MAX_PLAN_DOCUMENT_BYTES exists to prevent. "
            "Shorten it and re-run the decomposition order."
        )
    return doc.read_text(encoding="utf-8")


def _write_order(path: Path, data: dict) -> None:
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
    tmp.replace(path)


# ---------------------------------------------------------------------------
# Filing the batch
# ---------------------------------------------------------------------------

def recorded_batch(data: Any) -> Optional[List[str]]:
    """The ids a previous successful filing recorded on this order, if any."""
    if not isinstance(data, dict):
        return None
    block = data.get(FILED_FIELD)
    if not isinstance(block, dict):
        return None
    ids = block.get("orderIds")
    if isinstance(ids, list) and ids:
        return [str(i) for i in ids]
    return None


def file_decomposition_batch(mso: Path, *, manifest: DecompositionManifest,
                             decomposition_order_id: str,
                             created_by: str = "decomposition") -> FiledBatch:
    """File every order in *manifest* onto its voyage, PENDING.

    Orders are filed in ascending position order, so a positional
    ``dependsOn`` always resolves against ids already allocated. Each one goes
    through :func:`voyage_core.create_order_on_voyage`, which resolves the
    voyage before allocating, derives ``voyageBranch`` from the manifest,
    attaches under ``lock_for_allocation`` and rolls its own order back on a
    failed attach — none of which is re-implemented here.

    **Filed PENDING, never PROPOSED** (D2, and plan note 3): a ``PROPOSED``
    batch re-opens the ``AUTOQUEUE`` hole the review-then-file design exists to
    close.

    Idempotent (D5): if the decomposition order already records a filed batch,
    the recorded ids are returned unchanged with ``already_filed=True``. A
    partial batch records what landed BEFORE raising, so a retry resumes.

    Raises :class:`DecompositionBatchFailed`; the ``filed`` attribute names
    what already exists.
    """
    from maestro.core.voyage_core import create_order_on_voyage

    mso = Path(mso)
    order_path, order_data = load_order(mso, decomposition_order_id)

    previous = recorded_batch(order_data)
    if previous:
        return FiledBatch(order_ids=list(previous), paths=[],
                          voyage_id=manifest.voyage_id, already_filed=True)

    project = ""
    if isinstance(order_data, dict):
        project = str(order_data.get("project") or "").strip()
    if not project:
        parts = str(manifest.plan_order or manifest.voyage_id).split("-")
        project = parts[1] if len(parts) >= 3 else ""

    position_to_id: Dict[int, str] = {}
    filed_ids: List[str] = []
    filed_paths: List[str] = []

    def _record_progress() -> None:
        """Persist what landed so a retry resumes rather than duplicates."""
        if order_path is None or not isinstance(order_data, dict):
            return
        try:
            fresh = json.loads(order_path.read_text(encoding="utf-8"))
            if not isinstance(fresh, dict):
                fresh = dict(order_data)
        except (OSError, json.JSONDecodeError, UnicodeDecodeError):
            fresh = dict(order_data)
        fresh[FILED_FIELD] = {
            "orderIds": list(filed_ids),
            "filedAt": datetime.now().isoformat(),
            "planOrder": manifest.plan_order,
            "voyageId": manifest.voyage_id,
        }
        try:
            _write_order(order_path, fresh)
        except OSError:
            pass

    for proposed in sorted(manifest.orders, key=lambda o: o.position):
        depends_on = [position_to_id[dep] for dep in proposed.depends_on
                      if dep in position_to_id]
        missing = [dep for dep in proposed.depends_on if dep not in position_to_id]
        if missing:
            # Only reachable if the graph validation was bypassed; a forward
            # reference must never silently become a dependency-free order.
            _record_progress()
            raise DecompositionBatchFailed(
                f"order position {proposed.position} depends on position(s) "
                f"{missing} that have not been filed yet — the manifest's "
                "dependency order is inconsistent",
                decomposition_order_id=decomposition_order_id, filed=filed_ids)
        depends_on += list(proposed.depends_on_existing)

        try:
            created = create_order_on_voyage(
                mso,
                voyage_id=manifest.voyage_id,
                plan_order=manifest.plan_order,
                order_type=proposed.order_type or "FTR",
                project=project,
                title=proposed.title,
                description=proposed.description,
                priority=proposed.priority or None,
                role_sequence=proposed.role_sequence or None,
                acceptance_criteria=proposed.acceptance_criteria or None,
                depends_on=depends_on or None,
                created_by=created_by,
                extra={"decomposedFrom": decomposition_order_id},
            )
        except Exception as exc:   # noqa: BLE001 — re-raised typed, with progress
            _record_progress()
            raise DecompositionBatchFailed(
                f"filing order position {proposed.position} "
                f"({proposed.title[:80]!r}) failed: {type(exc).__name__}: {exc}. "
                f"{len(filed_ids)} order(s) already filed "
                f"({', '.join(filed_ids) or 'none'}) — they stand; a retry resumes "
                "from here rather than re-filing them.",
                decomposition_order_id=decomposition_order_id,
                filed=filed_ids, cause=exc) from exc

        order_id = created.created.order_id
        position_to_id[proposed.position] = order_id
        filed_ids.append(order_id)
        filed_paths.append(str(created.created.path))

    _record_progress()
    return FiledBatch(order_ids=filed_ids, paths=filed_paths,
                      voyage_id=manifest.voyage_id, already_filed=False)


def apply_decomposition_on_approval(mso: Path, *, decomposition_order_id: str,
                                    plan_order: str, voyage_id: str,
                                    created_by: str = "decomposition") -> FiledBatch:
    """Read ``plans/PLAN-<id>.md``, parse its manifest, and file the batch.

    The whole approve-side operation in one call, so ``review_core`` holds no
    copy of it. A missing or unreadable plan document is a
    :class:`DecompositionManifestError` exactly like a malformed one — from the
    Captain's point of view they are the same failure (there is no breakdown to
    apply), and both must leave the order in review rather than archive it.
    """
    doc = plan_document_path(mso, decomposition_order_id)
    try:
        # Bounded — SEC-001. An oversized document raises
        # DecompositionManifestError straight past both handlers below, which
        # is the right shape: it is a refusal of the breakdown, not an I/O
        # failure, and the order must stay in review either way.
        text = read_plan_document(doc)
    except FileNotFoundError as exc:
        raise DecompositionManifestError(
            f"the decomposition order's plan document {doc} does not exist — the "
            "crew never wrote its proposed breakdown. Re-run it with "
            f"`mso order retry {decomposition_order_id} --role PLN`.") from exc
    except OSError as exc:
        raise DecompositionManifestError(
            f"the decomposition order's plan document {doc} could not be read: "
            f"{exc}") from exc

    manifest = parse_manifest(
        text, plan_order=plan_order, voyage_id=voyage_id,
        max_orders=configured_max_orders(mso))
    return file_decomposition_batch(
        mso, manifest=manifest,
        decomposition_order_id=decomposition_order_id,
        created_by=created_by)


# ---------------------------------------------------------------------------
# The trigger — file the decomposition order when a plan is orphaned
# ---------------------------------------------------------------------------

def _voyage_file(mso: Path, voyage_id: str) -> Optional[Path]:
    for sub in ("voyages/active", "voyages/complete"):
        candidate = Path(mso) / sub / f"{voyage_id}.json"
        if candidate.exists():
            return candidate
    return None


def _find_unattached_decomposition_order(mso: Path, plan_order: str) -> Optional[str]:
    """A decomposition order for *plan_order* that never made it onto the
    manifest (created, then the attach failed). Adopted instead of re-filed —
    the same recovery ``_find_unattached_voyage_rel_order`` performs."""
    queues = Path(mso) / "queues"
    if not queues.is_dir():
        return None
    for json_file in sorted(list(queues.glob("*/*.json")) + list(queues.glob("*/*/*.json"))):
        try:
            data = json.loads(json_file.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError, UnicodeDecodeError):
            continue
        if isinstance(data, dict) and data.get(DECOMPOSES_PLAN_FIELD) == plan_order:
            return str(data.get("orderId") or data.get("id") or json_file.stem)
    return None


def decomposition_due(mso: Path, *, plan_order_id: str, voyage_id: str,
                      plan_order_data: Optional[dict] = None) -> "tuple[bool, str]":
    """``(due, reason)`` — is a decomposition order due for this plan?

    The three D5 guards, each declining with a reason the caller can log:

    * the feature is off (``completion.planDecomposition.enabled``);
    * the plan order is ITSELF a decomposition order (the recursion self-guard);
    * a decomposition order was already filed for it (the voyage marker);
    * the voyage already holds real dependents (the self-extinguishing
      condition — this is the ``PLAN_ORPHANED`` point, and past it the trigger
      is permanently false).
    """
    mso = Path(mso)
    if not plan_decomposition_enabled(mso):
        return False, "completion.planDecomposition.enabled is not true"
    if not voyage_id:
        return False, "the plan order names no voyage"

    if plan_order_data is None:
        _, plan_order_data = load_order(mso, plan_order_id)
    if is_decomposition_order(plan_order_data):
        return False, (f"{plan_order_id} is itself a decomposition order "
                       "(recursion self-guard)")

    voyage_file = _voyage_file(mso, voyage_id)
    if voyage_file is None:
        return False, f"voyage {voyage_id} has no manifest on disk"
    try:
        voyage = json.loads(voyage_file.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError, UnicodeDecodeError):
        return False, f"voyage {voyage_id}'s manifest could not be read"
    if not isinstance(voyage, dict):
        return False, f"voyage {voyage_id}'s manifest is not an object"

    marker = voyage.get(VOYAGE_MARKER_FIELD)
    if isinstance(marker, dict) and marker.get("orderId"):
        return False, (f"voyage {voyage_id} already has decomposition order "
                       f"{marker.get('orderId')} (filed once already)")

    # The PLAN_ORPHANED condition itself, read through the SAME shared readers
    # review_core uses — never a second derivation of "did anything get filed".
    from maestro.core.plan_dependents import find_filed_dependents
    from maestro.core.plan_links import load_voyage_manifests, plan_link_index

    if find_filed_dependents(mso, plan_order_id, voyage_id):
        return False, f"{plan_order_id} already has filed dependents"
    # plan_link_index, not link_voyages_cut_from_plan: this is a PREDICATE and
    # must not write. The linker is idempotent, but a `*_due` question that
    # mutates the plane is one a caller cannot ask safely (the patrol check
    # asks the same question, read-only, through this same reader).
    try:
        if plan_link_index(load_voyage_manifests(mso)).get(voyage_id):
            return False, f"{plan_order_id} already has linked build voyages"
    except Exception:
        pass
    return True, ""


def file_decomposition_order_if_due(mso: Path, *, plan_order_id: str,
                                    voyage_id: str, source: str = "cli",
                                    plan_order_data: Optional[dict] = None,
                                    ) -> Optional[str]:
    """File the decomposition order for *plan_order_id* when it is due.

    Structurally mirrors ``fleet_runner.file_voyage_rel_order_if_due``
    (FTR-MSO-2026-0762) — flag check, marker check, self-guard, ``create_order``
    + ``attach_order``, manifest marker, adopt-unattached recovery, a lifecycle
    event, and **never raises**. That function is the same problem solved once
    already; diverging from it would invent a second dialect for one decision.

    Returns the decomposition order id when this call filed (or adopted) one,
    else ``None`` — a ``None`` means the caller should keep whatever it already
    does (``review_core`` keeps writing ``PLAN_ORPHANED``, which stays correct
    for a declined trigger, a disabled feature and a hand-approved plan).
    """
    mso = Path(mso)
    try:
        due, reason = decomposition_due(
            mso, plan_order_id=plan_order_id, voyage_id=voyage_id,
            plan_order_data=plan_order_data)
        if not due:
            return None

        from maestro.core.order_create import create_order
        from maestro.core.voyage_core import attach_order

        voyage_file = _voyage_file(mso, voyage_id)
        if voyage_file is None:
            return None
        voyage = json.loads(voyage_file.read_text(encoding="utf-8"))

        project = ""
        if plan_order_data is None:
            _, plan_order_data = load_order(mso, plan_order_id)
        if isinstance(plan_order_data, dict):
            project = str(plan_order_data.get("project") or "").strip()
        if not project:
            project = str(voyage.get("project") or "").strip()
        if not project:
            parts = str(plan_order_id).split("-")
            project = parts[1] if len(parts) >= 3 else ""

        plan_title = ""
        if isinstance(plan_order_data, dict):
            plan_title = str(plan_order_data.get("title") or "")
        title = f"Decompose approved plan {plan_order_id} into build orders"

        decomp_id = _find_unattached_decomposition_order(mso, plan_order_id)
        created_path: Optional[Path] = None
        if decomp_id is None:
            created = create_order(
                mso,
                order_type="PLN",
                project=project,
                title=title,
                description=(
                    f"Read the APPROVED plan for {plan_order_id}"
                    + (f" ({plan_title})" if plan_title else "")
                    + f" and propose the concrete build orders for voyage {voyage_id}.\n\n"
                    "Auto-filed by Maestro because that plan was approved with nothing "
                    "filed to build it — the PLAN_ORPHANED condition "
                    "(FTR-MSO-2026-0860).\n\n"
                    "You are in DECOMPOSITION MODE. Write your proposed breakdown into "
                    f"`plans/PLAN-<this order's id>.md` as prose PLUS one machine-readable "
                    f"```{FENCE_LANGUAGE}``` JSON block. **Do not file any orders "
                    "yourself** — the engine files them, from your manifest, only after "
                    "the Captain approves this order at the plan-review gate. Reference "
                    "orders POSITIONALLY (`\"order\": 2`, `\"dependsOn\": [1]`); ids do "
                    "not exist yet and any id you name will be wrong. Carry the approved "
                    "plan's own scope and acceptance criteria forward rather than "
                    "re-deriving them. See maestro/docs/PLAN-DECOMPOSITION.md."
                ),
                role_sequence=list(DECOMPOSITION_ROLE_SEQUENCE),
                voyage_id=voyage_id,
                voyage_branch=str(voyage.get("branch") or "").replace("refs/heads/", ""),
                created_by=f"decomposition-trigger({source})",
                extra={DECOMPOSES_PLAN_FIELD: plan_order_id},
            )
            decomp_id = created.order_id
            created_path = Path(created.path)

        attach_order(mso, voyage_id, decomp_id, title=title)

        # Re-read: attach_order just rewrote the manifest.
        voyage = json.loads(voyage_file.read_text(encoding="utf-8"))
        voyage[VOYAGE_MARKER_FIELD] = {
            "planOrder": plan_order_id,
            "orderId": decomp_id,
            "filedAt": datetime.now().isoformat(),
            "source": source,
        }
        voyage_file.write_text(json.dumps(voyage, indent=2), encoding="utf-8")

        _lifecycle(
            mso, "PLAN_DECOMPOSITION_FILED",
            f"{plan_order_id} approved with nothing filed to build it — "
            f"{'filed' if created_path else 'adopted unattached'} decomposition "
            f"order {decomp_id} on {voyage_id} ({source}); the Captain reviews its "
            "proposed breakdown at the plan-review gate before any order is minted "
            "(FTR-MSO-2026-0860)")
        _commit(mso, [p for p in (created_path, voyage_file) if p is not None],
                f"lifecycle: file decomposition order {decomp_id} for {plan_order_id}")
        return decomp_id
    except Exception as exc:   # noqa: BLE001 — never raise into a review/archive path
        _lifecycle(
            mso, "PLAN_DECOMPOSITION_FAILED",
            f"auto-filing a decomposition order for {plan_order_id} failed: "
            f"{type(exc).__name__}: {str(exc)[:200]} — the plan stays orphaned; "
            "file its build orders by hand with `mso order create --voyage "
            f"{voyage_id}` (FTR-MSO-2026-0860)")
        return None


# ---------------------------------------------------------------------------
# Lifecycle + commit helpers (explicit mso; no CWD resolution)
# ---------------------------------------------------------------------------

def _lifecycle(mso: Path, event_type: str, message: str) -> None:
    """Write one lifecycle line into *mso*'s own log. Never raises.

    Deliberately a local writer rather than ``fleet_runner.write_lifecycle_event``:
    that function resolves its workspace from a process global, and this core is
    called from the Hub, which serves N workspaces from one process.
    """
    try:
        from maestro.core.lifecycle_log import sanitize_lifecycle_message
        log_dir = Path(mso) / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        line = f"{stamp} | {event_type:<10} | {sanitize_lifecycle_message(message)}\n"
        with open(str(log_dir / "lifecycle.log"), "a", encoding="utf-8") as handle:
            handle.write(line)
    except Exception:
        pass


def _commit(mso: Path, paths: Sequence[Path], message: str) -> None:
    """Commit artefact-plane transitions, if this workspace commits them.

    Best-effort and never raises: the order and the manifest are already on
    disk, and an uncommitted transition is a smaller problem than an exception
    thrown into an approve path.
    """
    if not paths:
        return
    try:
        from maestro.core import fleet_runner
        from maestro.core.order_retry import workspace_scope
        # workspace_scope, never a bare override write: _commit_lifecycle_transition
        # resolves its workspace from fleet_runner._MAESTRO_DIR_OVERRIDE, a process
        # global the Hub's poller also races for (BUG-MSO-2026-0643 F2).
        with workspace_scope(Path(mso)):
            fleet_runner._commit_lifecycle_transition(list(paths), message)
    except Exception:
        pass
