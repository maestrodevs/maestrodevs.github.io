"""maestro/core/artefact_json.py — encoding-tolerant artefact JSON reads.

BUG-MSO-2026-0819: every Maestro writer emits artefact JSON as UTF-8, but an
artefact plane is also written to by hand and by tools outside Maestro — a
PowerShell 5.1 ``Set-Content``, a Python ``open(path, "w")`` with no
``encoding=`` on a Windows code page. One such file on GKT carried a cp1252
em-dash (byte ``0x97``); ``plan_links._load_json`` caught ``JSONDecodeError``
but not ``UnicodeDecodeError`` (a ``ValueError`` sibling, not a subclass of
it), so ``voyages.planned-no-work`` raised and ``mso doctor`` skipped the
check for EVERY voyage in the workspace. The readers that did catch it
(``_load_json_safe`` in the patrol checks) silently dropped the voyage
instead — no crash, but the file was just as invisible.

The rule here: a reader never lets one badly-encoded file blind it to the
rest, and never silently discards the file's content when it can be
recovered. Decoding falls back UTF-8 (BOM tolerated) → cp1252 → UTF-8 with
replacement characters. Detecting that a file is NOT UTF-8 — so a human can
re-save it — is a separate question, answered by :func:`utf8_decode_error`
and surfaced by the ``hygiene.artefact-encoding`` patrol check.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

__all__ = [
    "decode_artefact_bytes",
    "load_artefact_json",
    "utf8_decode_error",
]


def decode_artefact_bytes(raw: bytes) -> Tuple[str, str]:
    """Decode *raw* artefact bytes, never raising.

    Returns ``(text, encoding)`` where *encoding* names the decode that
    succeeded: ``"utf-8"``, ``"cp1252"``, or ``"utf-8-replace"`` (the last
    resort — undecodable bytes become U+FFFD, the structure survives).
    ``utf-8-sig`` is used for the first attempt so a BOM written by
    PowerShell's ``-Encoding UTF8`` does not break ``json.loads``.
    """
    try:
        return raw.decode("utf-8-sig"), "utf-8"
    except UnicodeDecodeError:
        pass
    try:
        # cp1252 leaves 0x81/0x8D/0x8F/0x90/0x9D undefined, so this can still
        # fail on bytes that are not Windows-1252 either.
        return raw.decode("cp1252"), "cp1252"
    except UnicodeDecodeError:
        pass
    return raw.decode("utf-8", errors="replace"), "utf-8-replace"


def load_artefact_json(path: Path) -> Optional[Dict[str, Any]]:
    """Load a JSON object from *path*, tolerating non-UTF-8 encodings.

    Returns ``None`` for a missing/unreadable file, invalid JSON, or a
    top-level value that is not an object — never raises.
    """
    try:
        raw = Path(path).read_bytes()
    except OSError:
        return None
    text, _ = decode_artefact_bytes(raw)
    try:
        data = json.loads(text)
    except ValueError:
        return None
    return data if isinstance(data, dict) else None


def utf8_decode_error(path: Path) -> Optional[UnicodeDecodeError]:
    """The strict-UTF-8 decode error for *path*, or ``None`` when it decodes
    cleanly (or cannot be read at all — an unreadable file is not an
    encoding problem)."""
    try:
        raw = Path(path).read_bytes()
    except OSError:
        return None
    try:
        raw.decode("utf-8")
    except UnicodeDecodeError as exc:
        return exc
    return None
