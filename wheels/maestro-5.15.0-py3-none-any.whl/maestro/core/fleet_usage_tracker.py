#!/usr/bin/env python3
# Maestro - Usage Tracker
"""
Maestro - Usage Tracker

Tracks token usage across fleet crew sessions and QM-Captain interactions.
Parses Claude Code transcript JSONL files to extract actual API usage data
(input_tokens, output_tokens, cache_creation, cache_read) per model.

Usage:
    python -m maestro.core.fleet_usage_tracker --crew 1          # Show crew 1 usage
    python -m maestro.core.fleet_usage_tracker --order FTR-OTM-2026-0001  # Show order usage
    python -m maestro.core.fleet_usage_tracker --voyage VOY-OTM-2026-0100 # Aggregate voyage
    python -m maestro.core.fleet_usage_tracker --summary          # Grand totals
    python -m maestro.core.fleet_usage_tracker --report           # Generate usage report

Features:
  - Parse transcript JSONL for actual token usage (input, output, cache_creation, cache_read)
  - Per-order usage tracking stored in .mso/usage/orders/{ORDER-ID}.json
  - Per-crew session tracking stored in .mso/usage/crews/crew{N}.json
  - Voyage-level aggregation
  - Cost estimation using current API pricing
  - Integration with stop hook for automatic capture at session end
  - Dynamic version resolution from maestro package
"""

import json
import os
import re
import sys
import glob
import argparse
from datetime import datetime, timedelta
from pathlib import Path
from collections import defaultdict
from dataclasses import dataclass, field as _dc_field
from typing import Any, Optional

from maestro.core_constants import _DEFAULT_MODEL_ID, canonical_model_id
from maestro.errors import MaestroAmbiguityError, run_cli
from maestro.workspace import MSO_DIR_NAME as _MSO_NAME

# ============================================================================
# CONFIGURATION
# ============================================================================

# API pricing per million tokens.
# Historical model IDs are retained so cost calculations on old transcripts still resolve.
#
# PROVENANCE — last verified 2026-09-20 (BUG-MSO-2026-0834) by fetching the live
# pricing page, https://platform.claude.com/docs/en/about-claude/pricing, and
# reading every row of its "Model pricing" table. `cache_creation` is that table's
# 5-minute cache-write column (1.25x base input) and `cache_read` is its
# "Cache hits and refreshes" column (0.1x base input, except Fable 5.1 at 0.025x).
#
# RE-VERIFICATION CADENCE: re-read that page whenever a model is added to this
# table or a role is re-pinned in config/role-models.json, and otherwise at each
# release that touches `mso usage`. Anthropic changes published prices without
# warning and without changing any model ID — BUG-MSO-2026-0834 was exactly that
# (see the Sonnet 5 note below) — so a model ID that still looks familiar is NOT
# evidence its price is still current. Update this PROVENANCE date when you check.
PRICING = {
    "claude-fable-5-1": {
        # Same base input/output pricing as Fable 5; cache reads drop to 2.5%
        # of base input (was 10%) — confirmed via
        # platform.claude.com/docs/en/models/fable-5-1/overview (Pricing table).
        "input": 10.00,
        "output": 50.00,
        "cache_creation": 12.50,
        "cache_read": 0.25,
    },
    "claude-fable-5": {
        "input": 10.00,
        "output": 50.00,
        "cache_creation": 12.50,
        "cache_read": 1.00,
    },
    "claude-opus-5": {
        # Same Opus-tier list pricing as 4.8 (fast mode, if used, bills $10/$50).
        "input": 5.00,
        "output": 25.00,
        "cache_creation": 6.25,
        "cache_read": 0.50,
    },
    "claude-opus-4-8": {
        "input": 5.00,
        "output": 25.00,
        "cache_creation": 6.25,
        "cache_read": 0.50,
    },
    "claude-opus-4-7": {
        "input": 5.00,
        "output": 25.00,
        "cache_creation": 6.25,
        "cache_read": 0.50,
    },
    "claude-opus-4-6": {
        "input": 5.00,
        "output": 25.00,
        "cache_creation": 6.25,
        "cache_read": 0.50,
    },
    "claude-sonnet-5": {
        # FTR-MSO-2026-0865: $2/$10 per MTok IS the standard list rate, not an
        # intro rate — the $3/$15 previously recorded here was Sonnet 4.6's.
        # $2/$10 per MTok is the STANDARD price — do NOT "restore" $3/$15.
        # The launch $2/$10 rate was announced as introductory pricing through
        # 2026-08-31, and this table was originally written assuming the scheduled
        # 2026-09-01 rise to $3/$15 would happen. Anthropic cancelled it. Verbatim,
        # from the pricing page's own `claude-sonnet-5-introductory-pricing` note:
        #
        #   "The $2/$10 per million input/output token pricing for Claude Sonnet 5,
        #    announced at launch as introductory pricing through August 31, 2026, is
        #    now the standard price. The previously scheduled increase to $3/$15 per
        #    million input/output tokens on September 1, 2026 will not occur."
        #
        # The pre-fix $3/$15 values overstated every Sonnet 5 estimate by 50%
        # (BUG-MSO-2026-0834).
        "input": 2.00,
        "output": 10.00,
        "cache_creation": 2.50,
        "cache_read": 0.20,
    },
    "claude-sonnet-4-6": {
        "input": 3.00,
        "output": 15.00,
        "cache_creation": 3.75,
        "cache_read": 0.30,
    },
    "claude-haiku-4-5": {
        # FTR-MSO-2026-0865: $0.80/$4.00 previously recorded here was the
        # Haiku *3.5* rate; Haiku 4.5's published list price is $1/$5.
        # NOT $0.80/$4: that is the RETIRED Claude Haiku 3.5 rate
        # ($0.80 / $4.00 / $1.00 / $0.08), which this table carried under the
        # 4.5 id and which understated every Haiku 4.5 estimate by 20-25%
        # (BUG-MSO-2026-0834). Both rows are still on the live pricing page one
        # under the other, so check you are reading the 4.5 row before touching
        # these. Keyed on the canonical `claude-haiku-4-5` id (not the dated
        # `claude-haiku-4-5-20251001` snapshot) — `resolve_pricing()` (below)
        # resolves MODEL_ID_ALIASES before indexing here, so the dated id
        # still prices correctly without a duplicate entry; see
        # core_constants.py's MODEL_ID_ALIASES docstring.
        "input": 1.00,
        "output": 5.00,
        "cache_creation": 1.25,
        "cache_read": 0.10,
    },
}

# Model display names
MODEL_NAMES = {
    "claude-fable-5-1": "Fable 5.1",
    "claude-fable-5": "Fable 5",
    "claude-opus-5": "Opus 5",
    "claude-opus-4-8": "Opus 4.8",
    "claude-opus-4-7": "Opus 4.7",
    "claude-opus-4-6": "Opus 4.6",
    "claude-sonnet-5": "Sonnet 5",
    "claude-sonnet-4-6": "Sonnet 4.6",
    "claude-haiku-4-5": "Haiku 4.5",
}


def resolve_pricing(model_id: str) -> dict:
    """Return the PRICING entry for *model_id* (FTR-MSO-2026-0865).

    The ONE pricing lookup. Resolves a MODEL_ID_ALIASES spelling and strips a
    '[1m]' context-window selector (closing FTR-MSO-2026-0865 F4, where '[1m]'
    was stripped at one of three call sites and a `claude-opus-5[1m]`
    transcript was therefore priced 40% low at the fallback rate), then falls
    back to the catalogue's OWN default model rather than a fourth hand-typed
    model id that nothing keeps current (F5).

    One price per model, resolved at lookup — never a second PRICING row
    carrying the same numbers, which is the drift mechanism this closes.
    """
    resolved = canonical_model_id(model_id) if isinstance(model_id, str) else model_id
    return PRICING.get(resolved, PRICING.get(_DEFAULT_MODEL_ID, {}))


SCRIPT_DIR = Path(os.path.dirname(os.path.abspath(__file__)))
MAESTRO_DIR = SCRIPT_DIR.parent
USAGE_DIR = MAESTRO_DIR / "usage"

#: FTR-MSO-2026-0868 D9 — the resolved model backend, cached for this process.
#: ``False`` means "not resolved yet"; ``None`` means "resolved to nothing
#: useful, do not try again". The usage tracker runs per iteration and may
#: parse hundreds of transcript lines, so this must resolve at most once —
#: `BedrockModelProvider.probe()` shells out to `aws sts get-caller-identity`.
_BACKEND_PROVIDER: Any = False


def _canonicalise_backend_model_id(model: str) -> str:
    """Backend-native model id -> canonical Maestro id (FTR-MSO-2026-0868 D9).

    The identity for the default backend and for any id the backend does not
    recognise — so an unconfigured workspace's usage records are byte-identical
    and an unknown id stays visible rather than being guessed into the wrong
    cost row.

    **Never raises.** This runs mid-write of a usage record; a broken provider
    must cost a label, not the record.
    """
    global _BACKEND_PROVIDER

    if not model or not isinstance(model, str):
        return model

    if _BACKEND_PROVIDER is False:
        _BACKEND_PROVIDER = None
        try:
            from maestro import providers
            from maestro.workspace import get_artefact_root
            # The artefact root's PARENT is the workspace — the same rule as
            # `crew.model_backend_workspace` and `fleet_runner._dispatcher_scm`
            # ("solo-mode safe — resolve_artefact_dir is not"). Both sides of
            # the translation must resolve the same workspace or a usage record
            # is canonicalised against a backend the crew never ran on.
            resolved = providers.resolve_explain("model", get_artefact_root().parent)
            if resolved.available and resolved.provider is not None:
                _BACKEND_PROVIDER = resolved.provider
        except Exception:
            _BACKEND_PROVIDER = None

    if _BACKEND_PROVIDER is None:
        return model
    try:
        canonical = _BACKEND_PROVIDER.canonicalise_model_id(model)
    except Exception:
        return model
    return canonical if isinstance(canonical, str) and canonical else model


class CostBasis:
    """How a usage record's ``estimated_cost_usd`` was arrived at
    (FTR-MSO-2026-0871, PLAN-PLN-MSO-2026-0864 ADR-4).

    Mirrors ``maestro/reports/models.py``'s ``UsageStatus`` vocabulary
    deliberately: that class already solved "report an absent cost honestly"
    in this codebase (*totals are ``None`` unless ``status`` is ``RECORDED`` --
    never ``0``*), and a second vocabulary for the same idea would be one more
    thing to keep in step.
    """

    #: Priced from ``PRICING`` -- Anthropic's published list rates. Also the
    #: basis for a record written before this order existed, and for any
    #: workspace whose backend could not be resolved at all (see
    #: :func:`resolve_cost_context`).
    FIRST_PARTY_LIST = "first-party-list"

    #: Priced from ``providers.model.<id>.config.pricingOverrides`` -- the
    #: operator's own negotiated rates, covering EVERY model in the record.
    WORKSPACE_OVERRIDE = "workspace-override"

    #: Not priced. ``estimated_cost_usd`` is ``None``. The backend does not
    #: bill at first-party list rates and no usable override covers at least
    #: one model in the record.
    UNPRICED = "unpriced"


@dataclass(frozen=True)
class CostContext:
    """The workspace's pricing basis, resolved once per process."""

    #: The configured model-backend id, or ``"anthropic"`` when nothing is
    #: configured. Written to the usage record's ``backend`` field.
    backend_id: str = "anthropic"
    #: Whether ``PRICING`` is this backend's actual bill.
    first_party: bool = True
    #: ``{canonical model: {input, output, cache_creation, cache_read}}``.
    overrides: dict = _dc_field(default_factory=dict)
    #: ``{canonical model: "is missing 'cache_read'"}`` -- entries the operator
    #: configured but which are unusable, so the reason can say so.
    override_gaps: dict = _dc_field(default_factory=dict)


#: Process-level cache for :func:`resolve_cost_context`, beside
#: ``_BACKEND_PROVIDER`` and for the same reason: the tracker runs per crew
#: iteration and may parse hundreds of transcript lines, so the workspace's
#: provider config must be read at most once. ``False`` means "not resolved
#: yet" -- ``None`` cannot be the sentinel, because the sentinel has to be
#: distinguishable from every valid resolved value.
_COST_CONTEXT: Any = False


def reset_cost_context_cache() -> None:
    """Drop the cached :class:`CostContext`.

    Exists for tests, which configure a workspace and then expect the next
    pricing call to see it. Nothing in the fleet calls this: a dispatcher run
    has one backend for its whole life.
    """
    global _COST_CONTEXT
    _COST_CONTEXT = False


def resolve_cost_context() -> "CostContext":
    """The workspace's pricing basis. **Never raises** (FTR-MSO-2026-0871 D1/D2).

    **Anything unresolvable resolves to first-party** -- a missing workspace, a
    provider import that raises, a ``configured_entry`` that throws. This code
    runs inside the usage-record write path on every iteration of every crew on
    every existing workspace, so a resolution failure must cost nothing: only a
    backend *positively identified* as non-first-party flips the basis. Same
    polarity as :func:`_canonicalise_backend_model_id`'s "identity on failure".

    **Resolved from the CONFIG, never from a live provider instance.**
    ``providers.resolve_explain()`` sets ``provider=None`` whenever
    ``available`` is False -- which on a Bedrock workspace is exactly what an
    expired AWS SSO session produces. A pricer branching on
    ``resolved.provider`` would therefore report first-party cost on a Bedrock
    workspace at the precise moment the fleet is degraded.
    ``configured_entry`` never probes and always carries ``(tier, id, config)``.
    """
    global _COST_CONTEXT

    if _COST_CONTEXT is not False:
        return _COST_CONTEXT

    context = CostContext()
    try:
        from maestro import providers
        from maestro.workspace import get_artefact_root

        # The artefact root's PARENT is the workspace -- the same rule as
        # `_canonicalise_backend_model_id` above and `crew.model_backend_workspace`.
        workspace = get_artefact_root().parent
        _tier, configured_id, config = providers.configured_entry("model", workspace)
        backend_id = configured_id or providers.DEFAULT_MODEL_BACKEND_ID

        provider_cls = providers._REGISTRY["model"].get(backend_id)
        if provider_cls is None:
            # An id this Maestro version does not ship. Unknown is not the same
            # as non-first-party, and D1 says unresolvable stays first-party --
            # but the id is still recorded, so the record names what the
            # workspace asked for.
            context = CostContext(backend_id=backend_id)
        else:
            # The flag is read off the CLASS, before any instantiation, and the
            # override parse is guarded SEPARATELY below. Both deliberate: once
            # a backend has been positively identified as non-first-party, that
            # finding must survive every later failure. Folding these into the
            # outer `except` would mean a provider whose constructor or
            # override parse raised got priced at Anthropic's list rates --
            # which is the one outcome ADR-4 exists to prevent, arrived at from
            # the opposite direction to D1's.
            first_party = bool(getattr(provider_cls, "prices_at_first_party_list", False))
            overrides: dict = {}
            gaps: dict = {}
            try:
                # Cheap and I/O-free for every backend shipped; if a future one
                # changes that, this guard still holds.
                instance = provider_cls(config, workspace=workspace)
                overrides = dict(instance.pricing_overrides() or {})
                gaps = dict(instance.pricing_override_gaps() or {})
            except Exception:
                # No usable rates => `unpriced`, not a fabricated figure.
                overrides, gaps = {}, {}
            context = CostContext(
                backend_id=backend_id,
                first_party=first_party,
                overrides=overrides,
                override_gaps=gaps,
            )
    except Exception:
        context = CostContext()

    _COST_CONTEXT = context
    return context


def _rate_keys() -> tuple:
    """The four rate-key names, from the provider contract that defines them.

    Imported lazily, with a literal fallback. This module is imported by the
    stop hook on every crew exit, and ``maestro.providers`` pulls in every
    provider class in the package at import time; the keys are only ever used
    to compose an operator-facing message, so paying that cost at module load
    -- or raising on the usage-record write path if it ever failed -- would be
    the wrong trade in both directions.
    """
    try:
        from maestro.providers.model.base import PRICING_RATE_KEYS
        return tuple(PRICING_RATE_KEYS)
    except Exception:
        return ("input", "output", "cache_creation", "cache_read")


def _apply_rates(rates: dict, usage: dict) -> float:
    """USD for *usage* at *rates* (both in USD per million tokens)."""
    return (
        usage.get("input_tokens", 0) * rates.get("input", 0)
        + usage.get("output_tokens", 0) * rates.get("output", 0)
        + usage.get("cache_creation_input_tokens", 0) * rates.get("cache_creation", 0)
        + usage.get("cache_read_input_tokens", 0) * rates.get("cache_read", 0)
    ) / 1_000_000


def price_models(models: dict, ctx: Optional["CostContext"] = None) -> tuple:
    """``(cost or None, costBasis, backend id, reason)`` for a record's models.

    The ONE pricer (FTR-MSO-2026-0871). Both writers -- :func:`parse_transcript`
    here and ``hooks/stop.py:extract_usage_from_transcript`` -- route through
    it, so the fleet cannot end up holding two answers to "what did this cost".

    ``resolve_pricing()`` is used unchanged for the first-party path and is not
    modified by this order: FTR-MSO-2026-0865 made it the one pricing lookup
    after a real drift bug, and this function sits *above* it.

    **The weakest basis wins (D5).** If ANY model in the record is unpriced,
    the whole record is ``unpriced`` with a cost of ``None``. Emitting the
    priced models' subtotal as if it were the total is precisely "a dollar
    figure wrong by an unknown margin", which is the thing this order exists
    to stop.

    **Never raises.**
    """
    try:
        context = ctx if ctx is not None else resolve_cost_context()
    except Exception:
        context = CostContext()

    models = models if isinstance(models, dict) else {}

    if context.first_party:
        total = 0.0
        for model, usage in models.items():
            total += _apply_rates(resolve_pricing(model), usage or {})
        return round(total, 4), CostBasis.FIRST_PARTY_LIST, context.backend_id, ""

    if not models:
        # Nothing was spent, so nothing is unknown: zero tokens cost zero at any
        # rate card. Reporting `unpriced` here would put a "we could not price
        # this" banner on a record with nothing in it to price.
        #
        # The basis is FIRST_PARTY_LIST, not WORKSPACE_OVERRIDE, and that is the
        # deliberate choice of the two vacuous labels available: `$0` is
        # consistent with every rate card, but `workspace-override` additionally
        # ASSERTS that overrides were applied -- a claim a reader can check and
        # find false on a backend with none configured. It also matches what the
        # empty `parse_transcript` result and `read_cost_basis`'s default already
        # say, so a zero record reads the same way wherever it is met.
        return 0.0, CostBasis.FIRST_PARTY_LIST, context.backend_id, ""

    total = 0.0
    unpriced = []
    for model, usage in models.items():
        canon = canonical_model_id(model) if isinstance(model, str) else model
        rates = context.overrides.get(canon)
        if not rates:
            gap = context.override_gaps.get(canon)
            unpriced.append("'{}' {}".format(canon, gap) if gap else "'{}'".format(canon))
            continue
        total += _apply_rates(rates, usage or {})

    if unpriced:
        key_root = "providers.model.{}.config.pricingOverrides".format(context.backend_id)
        rate_keys = "{" + ",".join(_rate_keys()) + "}"
        reason = (
            "backend '{}' does not bill at first-party list rates; "
            "no usable pricingOverrides for {} -- set {}.<model>.{}".format(
                context.backend_id, ", ".join(unpriced), key_root, rate_keys,
            )
        )
        return None, CostBasis.UNPRICED, context.backend_id, reason

    return round(total, 4), CostBasis.WORKSPACE_OVERRIDE, context.backend_id, ""


def read_cost_basis(record: dict) -> tuple:
    """A record's ``(costBasis, reason)``.

    The ONE reader-side default (FTR-MSO-2026-0871 D7). A record with no
    ``costBasis`` field predates this order and reads as ``first-party-list``
    -- which is what it was. No consumer may inline
    ``record.get("costBasis", ...)``: one default in one place, or an archived
    record reads differently depending on which reader opened it.
    """
    if not isinstance(record, dict):
        return CostBasis.FIRST_PARTY_LIST, ""
    basis = record.get("costBasis")
    if basis not in (CostBasis.FIRST_PARTY_LIST, CostBasis.WORKSPACE_OVERRIDE, CostBasis.UNPRICED):
        return CostBasis.FIRST_PARTY_LIST, ""
    reason = record.get("costBasisReason")
    return basis, reason if isinstance(reason, str) else ""


def weakest_basis(bases) -> str:
    """The weakest of several contributing bases (FTR-MSO-2026-0871 D5).

    ``unpriced`` beats ``workspace-override`` beats ``first-party-list``. The
    ONE place that ordering is written, so a voyage rollup, a Hub bucket and a
    merged stop-hook record cannot disagree about what a mixed set adds up to.
    An empty set is ``first-party-list`` -- nothing contributed, nothing is
    unknown.
    """
    collected = set(bases or ())
    if CostBasis.UNPRICED in collected:
        return CostBasis.UNPRICED
    if CostBasis.WORKSPACE_OVERRIDE in collected:
        return CostBasis.WORKSPACE_OVERRIDE
    return CostBasis.FIRST_PARTY_LIST


def calculate_cost_basis(model: str, usage: dict, ctx: Optional["CostContext"] = None) -> tuple:
    """:func:`calculate_cost` for ONE model, honest about the basis.

    Returns ``(cost or None, costBasis)``. Used by the per-model render rows,
    which must print ``unpriced`` rather than ``$0.00`` for a model this
    workspace's backend has no rate for. :func:`calculate_cost` itself is left
    exactly as it was -- it has other callers, and changing a function's return
    type under them is how a reporting fix becomes a crash.
    """
    cost, basis, _backend, _reason = price_models({model: usage or {}}, ctx)
    return cost, basis


def resolve_version() -> str:
    """Resolve the package version from the installed maestro package or __init__.py."""
    try:
        import maestro
        return maestro.__version__
    except ImportError:
        pass

    script_path = Path(__file__).resolve()
    for candidate in [
        script_path.parent.parent.parent / "maestro" / "__init__.py",
        script_path.parent.parent / "maestro" / "__init__.py",
    ]:
        if candidate.exists():
            try:
                content = candidate.read_text(encoding="utf-8")
                m = re.search(r'^__version__\s*=\s*["\']([^"\']+)["\']', content, re.MULTILINE)
                if m:
                    return m.group(1)
            except Exception:
                pass

    return "unknown"


def ensure_usage_dirs():
    """Create usage tracking directories if they don't exist."""
    (USAGE_DIR / "orders").mkdir(parents=True, exist_ok=True)
    (USAGE_DIR / "crews").mkdir(parents=True, exist_ok=True)
    (USAGE_DIR / "voyages").mkdir(parents=True, exist_ok=True)
    (USAGE_DIR / "sessions").mkdir(parents=True, exist_ok=True)


def parse_transcript(transcript_path: str) -> dict:
    """
    Parse a Claude Code transcript JSONL file and extract token usage.

    Returns:
        {
            "session_id": str,
            "start_time": str (ISO),
            "end_time": str (ISO),
            "message_count": int,
            "models": {
                "claude-opus-4-7": {
                    "input_tokens": int,
                    "output_tokens": int,
                    "cache_creation_input_tokens": int,
                    "cache_read_input_tokens": int,
                    "message_count": int,
                },
                ...
            },
            "total_tokens": int,
            "estimated_cost_usd": float | None,   # None when costBasis is "unpriced"
            "backend": str,                       # the model backend that served it
            "costBasis": str,                     # CostBasis.* — see price_models()
            "costBasisReason": str,               # one line, "" unless unpriced
        }

    FTR-MSO-2026-0871: cost is priced through :func:`price_models`, so a
    backend that does not bill at Anthropic's list rates reports ``unpriced``
    with a reason rather than a fabricated dollar figure. Token counts are
    unaffected.
    """
    result = {
        "session_id": "",
        "start_time": None,
        "end_time": None,
        "message_count": 0,
        "models": {},
        "total_tokens": 0,
        "estimated_cost_usd": 0.0,
        # FTR-MSO-2026-0871. The empty/unparseable result is a zero, not an
        # unknown, so it keeps the first-party basis: there is nothing in it
        # whose price could be wrong.
        "backend": "",
        "costBasis": CostBasis.FIRST_PARTY_LIST,
        "costBasisReason": "",
    }

    if not os.path.exists(transcript_path):
        return result

    first_ts = None
    last_ts = None
    models = defaultdict(lambda: {
        "input_tokens": 0,
        "output_tokens": 0,
        "cache_creation_input_tokens": 0,
        "cache_read_input_tokens": 0,
        "message_count": 0,
    })

    try:
        with open(transcript_path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    entry = json.loads(line)
                except json.JSONDecodeError:
                    continue

                ts = entry.get("timestamp")
                if ts and not first_ts:
                    first_ts = ts
                if ts:
                    last_ts = ts

                session_id = entry.get("sessionId", "")
                if session_id and not result["session_id"]:
                    result["session_id"] = session_id

                if entry.get("type") == "assistant":
                    msg = entry.get("message", {})
                    if not isinstance(msg, dict):
                        continue

                    usage = msg.get("usage", {})
                    model = msg.get("model", "unknown")
                    if isinstance(model, str):
                        model = model.removesuffix("[1m]")
                        # FTR-MSO-2026-0868 D9: this id comes from the CLAUDE
                        # TRANSCRIPT, not from what Maestro asked for — so on a
                        # translating backend it is the BACKEND-NATIVE id.
                        # Without this, .mso/usage/ would fill with
                        # `apac.anthropic.claude-opus-5`: a second vocabulary in
                        # the artefact plane (which ADR-2 exists to prevent), and
                        # a `resolve_pricing()` miss on every Bedrock crew —
                        # silently, at the very artefact spend is decided from.
                        # Identity for the default backend, so the usage records
                        # of an unconfigured workspace are byte-identical.
                        model = _canonicalise_backend_model_id(model)

                    # Skip synthetic/unknown models
                    if model in ("<synthetic>", "unknown", ""):
                        continue

                    result["message_count"] += 1
                    models[model]["message_count"] += 1

                    for key in [
                        "input_tokens",
                        "output_tokens",
                        "cache_creation_input_tokens",
                        "cache_read_input_tokens",
                    ]:
                        models[model][key] += usage.get(key, 0)

    except Exception as e:
        print(f"Error parsing transcript: {e}", file=sys.stderr)
        return result

    result["start_time"] = first_ts
    result["end_time"] = last_ts
    result["models"] = dict(models)

    # Token accounting is unchanged by FTR-MSO-2026-0871 -- tokens are tokens
    # on any backend. Only the COST is now basis-aware.
    total_tokens = 0
    for usage in models.values():
        total_tokens += sum(usage[k] for k in [
            "input_tokens", "output_tokens",
            "cache_creation_input_tokens", "cache_read_input_tokens",
        ])

    cost, basis, backend_id, reason = price_models(result["models"])

    result["total_tokens"] = total_tokens
    # `None`, never 0, when unpriced (D6) -- and the KEY STAYS PRESENT, because
    # every reader outside this module coerces with `... or 0.0`.
    result["estimated_cost_usd"] = cost
    result["backend"] = backend_id
    result["costBasis"] = basis
    result["costBasisReason"] = reason

    return result


def save_order_usage(order_id: str, usage_data: dict, voyage_id: str = ""):
    """Save usage data for a specific order.

    BUG-MSO-2026-0201: stamp `voyageId` so `mso usage --voyage` can filter
    per-order usage files to a single voyage.
    """
    ensure_usage_dirs()
    path = USAGE_DIR / "orders" / f"{order_id}.json"

    record = {
        "orderId": order_id,
        "timestamp": datetime.now().isoformat(),
        **usage_data,
    }
    if voyage_id and "voyageId" not in record:
        record["voyageId"] = voyage_id

    with open(path, "w", encoding="utf-8") as f:
        json.dump(record, f, indent=2)


def record_review_time(order_id: str, review_pending_at: str, approved_at: str) -> int:
    """Calculate and persist review time for an order.

    Reads the existing usage file (or creates a minimal one), writes
    reviewTimeSeconds, and returns the elapsed seconds.
    """
    ensure_usage_dirs()
    try:
        pending_dt = datetime.fromisoformat(review_pending_at.replace("Z", "+00:00")).replace(tzinfo=None)
        approved_dt = datetime.fromisoformat(approved_at.replace("Z", "+00:00")).replace(tzinfo=None)
        elapsed = int((approved_dt - pending_dt).total_seconds())
    except Exception:
        elapsed = 0

    path = USAGE_DIR / "orders" / f"{order_id}.json"
    if path.exists():
        try:
            with open(path, encoding="utf-8") as f:
                record = json.load(f)
        except Exception:
            record = {"orderId": order_id}
    else:
        record = {"orderId": order_id, "timestamp": datetime.now().isoformat()}

    record["reviewTimeSeconds"] = elapsed

    with open(path, "w", encoding="utf-8") as f:
        json.dump(record, f, indent=2)

    return elapsed


def save_crew_usage(crew_number: int, order_id: str, usage_data: dict):
    """Append usage data for a crew session."""
    ensure_usage_dirs()
    path = USAGE_DIR / "crews" / f"crew{crew_number}.jsonl"

    record = {
        "crewNumber": crew_number,
        "orderId": order_id,
        "timestamp": datetime.now().isoformat(),
        **usage_data,
    }

    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(record) + "\n")


def save_session_usage(session_id: str, usage_data: dict, session_type: str = "crew"):
    """Save usage data for any session (crew or QM)."""
    ensure_usage_dirs()
    path = USAGE_DIR / "sessions" / f"{session_id}.json"

    record = {
        "sessionId": session_id,
        "sessionType": session_type,
        "timestamp": datetime.now().isoformat(),
        **usage_data,
    }

    with open(path, "w", encoding="utf-8") as f:
        json.dump(record, f, indent=2)


def _resolve_voyage_order_ids(voyage_id: str) -> set:
    """Best-effort: order IDs belonging to a voyage, from its voyage JSON.

    BUG-MSO-2026-0201 fallback for legacy per-order usage files written before
    `voyageId` was stamped into them. Looks in <workspace>/voyages/{active,complete}/.
    """
    ws = USAGE_DIR.parent  # workspace root (e.g. .mso/)
    for sub in ("active", "complete"):
        vpath = ws / "voyages" / sub / f"{voyage_id}.json"
        if vpath.exists():
            try:
                data = json.loads(vpath.read_text(encoding="utf-8"))
                return set(data.get("orders") or data.get("orderIds") or [])
            except Exception:
                return set()
    return set()


def aggregate_voyage_usage(voyage_id: str) -> dict:
    """Aggregate usage across the orders belonging to a single voyage.

    BUG-MSO-2026-0201: previously this globbed EVERY per-order usage file and
    summed them with no filter, so `mso usage --voyage X` ignored X entirely.
    Now orders are selected by their stamped `voyageId`; for legacy files that
    lack the field, we fall back to the voyage JSON's order list.
    """
    orders_dir = USAGE_DIR / "orders"
    if not orders_dir.exists():
        # Same shape as the normal return so callers never hit a missing key (Copilot PR #89).
        return {
            "voyage_id": voyage_id,
            "order_count": 0,
            "models": {},
            "total_tokens": 0,
            "estimated_cost_usd": 0,
            "costBasis": CostBasis.FIRST_PARTY_LIST,
            "costBasisReason": "",
            "unpricedOrderCount": 0,
            "reviewTimeSeconds": 0,
            "reviewOrderCount": 0,
        }

    allowed_ids = _resolve_voyage_order_ids(voyage_id)

    # Load order usage files belonging to this voyage
    voyage_orders = []
    total_tokens = 0
    total_cost = 0.0
    total_review_seconds = 0
    review_order_count = 0
    # FTR-MSO-2026-0871 D6: an unpriced order is COUNTED, never summed as zero.
    unpriced_order_count = 0
    unpriced_reason = ""
    contributing_bases = set()
    models_agg = defaultdict(lambda: {
        "input_tokens": 0, "output_tokens": 0,
        "cache_creation_input_tokens": 0, "cache_read_input_tokens": 0,
        "message_count": 0,
    })

    for fpath in orders_dir.glob("*.json"):
        try:
            with open(fpath, encoding="utf-8") as f:
                data = json.load(f)
            # BUG-MSO-2026-0201: only count orders that belong to this voyage.
            file_voyage = data.get("voyageId")
            order_id = data.get("orderId") or fpath.stem
            if file_voyage:
                if file_voyage != voyage_id:
                    continue
            elif allowed_ids:
                if order_id not in allowed_ids:
                    continue
            else:
                # No voyageId on the file and no voyage order-list to match against —
                # cannot attribute this order to the voyage; skip rather than over-count.
                continue
            voyage_orders.append(data)
            total_tokens += data.get("total_tokens", 0)
            basis, reason = read_cost_basis(data)
            contributing_bases.add(basis)
            order_cost = data.get("estimated_cost_usd")
            if basis == CostBasis.UNPRICED or order_cost is None:
                unpriced_order_count += 1
                if reason and not unpriced_reason:
                    unpriced_reason = reason
            else:
                total_cost += order_cost
            if "reviewTimeSeconds" in data:
                total_review_seconds += data["reviewTimeSeconds"]
                review_order_count += 1

            for model, usage in data.get("models", {}).items():
                for key in models_agg[model]:
                    models_agg[model][key] += usage.get(key, 0)
        except Exception:
            continue

    return {
        "voyage_id": voyage_id,
        "order_count": len(voyage_orders),
        "models": dict(models_agg),
        "total_tokens": total_tokens,
        # A SUBTOTAL over the priced orders when `unpricedOrderCount` is
        # non-zero -- never a total. The renderer says so out loud; a caller
        # reading this field must consult `unpricedOrderCount` before
        # presenting it as a voyage's spend (FTR-MSO-2026-0871 D5/D8).
        "estimated_cost_usd": round(total_cost, 4),
        "costBasis": weakest_basis(contributing_bases),
        "costBasisReason": unpriced_reason,
        "unpricedOrderCount": unpriced_order_count,
        "reviewTimeSeconds": total_review_seconds,
        "reviewOrderCount": review_order_count,
    }


def _claude_project_dirname(path) -> str:
    """Replicate Claude Code's ``~/.claude/projects/<name>`` mangling of an absolute path.

    Claude Code names each transcript directory after the absolute cwd a session was
    launched from, replacing every character outside ``[a-zA-Z0-9_-]`` with ``-``
    (so ``C:\\Repos\\MSO-Maestro`` -> ``C--Repos-MSO-Maestro``).
    """
    return re.sub(r"[^a-zA-Z0-9_-]", "-", str(Path(path).resolve()))


def _group_project_candidates(candidates: list) -> list:
    """Group Claude project directories that belong to the same workspace.

    BUG-MSO-2026-0446: a crew's worktree (``.mso/worktrees/<VOY>/crew<N>``) is a
    real, distinct cwd, so Claude Code gives it its own transcript directory whose
    mangled name carries the workspace root's mangled name as a prefix (e.g.
    ``C--Repos-MSO-Maestro`` is a prefix of
    ``C--Repos-MSO-Maestro--mso-worktrees-VOY-MSO-2026-0127-crew1``). Those are not
    separate projects — they're the same workspace's crew sessions — so group by
    that prefix relationship instead of treating every directory as ambiguous.

    Returns a list of groups (each a list of Paths); a workspace with genuinely
    unrelated candidates (neither a prefix of the other) yields multiple groups.
    """
    by_len = sorted(candidates, key=lambda p: len(p.name))
    roots: list = []
    groups: dict = {}
    for cand in by_len:
        parent = next(
            (r for r in roots if cand.name == r.name or cand.name.startswith(r.name + "-")),
            None,
        )
        if parent is None:
            roots.append(cand)
            groups[cand.name] = [cand]
        else:
            groups[parent.name].append(cand)
    return list(groups.values())


def scan_all_project_sessions(project_path: str = None, project_acronym: str = None) -> list:
    """
    Scan all Claude Code transcript files for a project directory
    and return usage summaries.

    *project_path*, if given, is scanned directly (no auto-detection).
    *project_acronym* (or the ``MAESTRO_PROJECT`` env var) narrows auto-detection
    to project directories whose name contains it — forwarded from ``mso usage
    --project``.
    """
    if not project_path:
        # Auto-detect from ~/.claude/projects/
        home = Path.home()
        projects_dir = home / ".claude" / "projects"

        # BUG-MSO-2026-0446: try the workspace's OWN mangled directory name first.
        # `mso usage` always runs its tracker subprocess with cwd == the workspace
        # root (see cli.py _run), so this is a deterministic, no-guessing match —
        # and it automatically pulls in every crew worktree transcript dir too,
        # since their names are prefixed by the workspace root's name.
        workspace_dirname = _claude_project_dirname(Path.cwd())
        own_prefix = workspace_dirname + "-"
        candidates = [
            p for p in projects_dir.glob("*")
            if p.name == workspace_dirname or p.name.startswith(own_prefix)
        ] if projects_dir.exists() else []

        pattern_label = workspace_dirname
        if not candidates:
            # Fall back to an explicit acronym (--project / MAESTRO_PROJECT).
            #
            # NOTE for future maintainers: this branch previously defaulted to
            # `projects_dir.glob("*OTM*")` when no acronym was set. That default
            # was traced (BUG-MSO-2026-0446) to crew.py / fleet_runner.py's
            # `PROJECT_ACRONYM = os.environ.get("MAESTRO_PROJECT", "OTM")` — a
            # generic placeholder Maestro stamps into a NEW crew's env when the
            # operator hasn't configured MAESTRO_PROJECT. Copy-pasted here, it
            # was nonsensical: this code SEARCHES existing transcript dirs by
            # name, and no real project's directory name contains the literal
            # substring "OTM" unless the project is actually named that. It could
            # never match anything, so it always silently fell through to
            # glob("*") anyway — just after wasting a lookup. Removed; the
            # cwd-derived match above and the honest glob("*") fallback below
            # cover the same cases without the dead detour.
            admiralty_project = project_acronym or os.environ.get("MAESTRO_PROJECT")
            if admiralty_project:
                pattern_label = f"*{admiralty_project}*"
                candidates = list(projects_dir.glob(pattern_label))

        # Last-resort fallback: any project directory if nothing else matched.
        if not candidates:
            candidates = list(projects_dir.glob("*"))
            pattern_label = "*"

        if not candidates:
            return []

        if len(candidates) > 1:
            groups = _group_project_candidates(candidates)
            if len(groups) == 1:
                candidates = groups[0]
            else:
                names = ", ".join(c.name for c in candidates)
                raise MaestroAmbiguityError(
                    f"Multiple Claude project directories found matching "
                    f"'{pattern_label}' in {projects_dir}: {names}.",
                    hint="Specify --project-path explicitly or pass --project @MSO (e.g. `mso usage --project @MSO`).",
                )

        project_paths = [str(c) for c in candidates]
    else:
        project_paths = [project_path]

    sessions = []
    for pp in project_paths:
        for fpath in sorted(glob.glob(os.path.join(pp, "*.jsonl"))):
            usage = parse_transcript(fpath)
            if usage["message_count"] > 0:
                usage["transcript_path"] = fpath
                sessions.append(usage)

    return sessions


def calculate_cost(model: str, usage: dict) -> float:
    """Calculate cost in USD for a given model and usage dict."""
    pricing = resolve_pricing(model)
    return (
        usage.get("input_tokens", 0) * pricing.get("input", 0)
        + usage.get("output_tokens", 0) * pricing.get("output", 0)
        + usage.get("cache_creation_input_tokens", 0) * pricing.get("cache_creation", 0)
        + usage.get("cache_read_input_tokens", 0) * pricing.get("cache_read", 0)
    ) / 1_000_000


#: What an unpriced cost renders as, everywhere. A literal word, never a
#: dollar sign and never a blank -- `$0.00` reads as "this was free" and a
#: blank reads as "nothing ran here", and both are false.
UNPRICED_LABEL = "unpriced"


def format_cost_summary(total_cost, unpriced_count: int, contributor_count: int,
                        reason: str = "", noun: str = "session") -> str:
    """The ``Est. Cost:`` value, honest about what it does and does not cover
    (FTR-MSO-2026-0871 D8).

    Three outcomes, and the middle one is the one that matters: when SOME
    contributors are unpriced, the priced figure is rendered as a **subtotal
    over N of M**, never as the total. A total that quietly omits part of the
    fleet's spend is the failure this order exists to prevent, and it is
    invisible at the point of reading unless the line says so itself.

    ASCII only: this goes to a Windows console whose code page is often
    cp1252, where an em dash raises ``UnicodeEncodeError`` mid-report.
    """
    priced_count = max(contributor_count - unpriced_count, 0)
    plural = "" if contributor_count == 1 else "s"

    if unpriced_count <= 0:
        return "${:,.2f}".format(total_cost or 0.0)

    detail = reason or "the configured model backend does not bill at first-party list rates"

    if priced_count <= 0:
        return "{} -- {}".format(UNPRICED_LABEL, detail)

    return (
        "${:,.2f} -- SUBTOTAL over {} of {} {}{} only; {} {} ({})".format(
            total_cost or 0.0, priced_count, contributor_count, noun, plural,
            unpriced_count, UNPRICED_LABEL, detail,
        )
    )


def format_tokens(n: int) -> str:
    """Format token count with K/M suffix."""
    if n >= 1_000_000:
        return f"{n / 1_000_000:.1f}M"
    elif n >= 1_000:
        return f"{n / 1_000:.1f}K"
    return str(n)


def _aggregate_review_time() -> tuple:
    """Sum reviewTimeSeconds across all order usage files. Returns (seconds, order_count)."""
    orders_dir = USAGE_DIR / "orders"
    if not orders_dir.exists():
        return 0, 0
    total_secs = 0
    count = 0
    for fpath in orders_dir.glob("*.json"):
        try:
            with open(fpath, encoding="utf-8") as f:
                data = json.load(f)
            if "reviewTimeSeconds" in data:
                total_secs += data["reviewTimeSeconds"]
                count += 1
        except Exception:
            continue
    return total_secs, count


# FTR-MSO-2026-0835 -------------------------------------------------------
# Aggregation over the DURABLE per-iteration usage records
# (.mso/usage/orders/*.jsonl), as opposed to print_summary() /
# generate_usage_report() above, which are fed by scan_all_project_sessions() —
# Claude Code transcripts that carry no Maestro role, order or effort at all.

UNKNOWN_BUCKET = "unknown"

_VALID_ITERATION_DIMENSIONS = ("model", "effort", "role")

_UNKNOWN_FOOTNOTE = (
    "recorded before FTR-MSO-2026-0835 shipped, or the Claude CLI on that run "
    "had no --effort support (the tier was resolved but never applied)"
)


def _bucket_label(value) -> str:
    """Missing / null / empty -> the labelled unknown bucket. Never a default."""
    if value is None:
        return UNKNOWN_BUCKET
    text = str(value).strip()
    return text or UNKNOWN_BUCKET


def _iteration_usage_records(usage_dir=None):
    """Yield every parseable per-iteration record from usage/orders/*.jsonl.

    Blank and unparseable lines are skipped (mirrors hub/aggregator.py's
    _iter_order_usage_jsonl); an unreadable file never aborts the walk.
    """
    orders_dir = Path(usage_dir) if usage_dir else (USAGE_DIR / "orders")
    if not orders_dir.is_dir():
        return
    for fpath in sorted(orders_dir.glob("*.jsonl")):
        try:
            with open(fpath, encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        record = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    if isinstance(record, dict):
                        yield record
        except Exception:
            continue


def _record_within_days(record: dict, cutoff: str) -> bool:
    """True when the record's timestamp date is on/after *cutoff* (YYYY-MM-DD).

    A malformed or absent timestamp is EXCLUDED from a windowed run rather than
    crashing it — a record that cannot prove it falls inside the window must not
    be counted as if it did.
    """
    ts = record.get("timestamp")
    if not isinstance(ts, str) or len(ts) < 10:
        return False
    date = ts[:10]
    try:
        datetime.strptime(date, "%Y-%m-%d")
    except ValueError:
        return False
    return date >= cutoff


def aggregate_iteration_usage_by(dimensions=("model", "effort"), days: int = None,
                                 usage_dir=None) -> dict:
    """Group durable per-iteration usage records by any of model / effort / role.

    Each JSONL line is one crew invocation and may legitimately carry more than
    one model (subagents), so a record is split across one bucket per model in
    its ``models`` dict; token counts and cost are computed from those per-model
    counts with calculate_cost(), exactly as parse_transcript() derived the
    record's own totals in the first place.

    Missing / null / empty ``effort`` and ``role`` bucket as the literal string
    ``"unknown"``. A row is never dropped and a tier is never invented: a record
    written before this feature shipped, and one whose run had no --effort
    support, both land in the same clearly-labelled bucket.

    Returns::

        {"dimensions": [...], "days": int|None,
         "buckets": [{<dim>: str, ..., "tokens": int, "input_tokens": int,
                      "output_tokens": int, "cache_tokens": int,
                      "cost_usd": float, "records": int, "orders": int}, ...],
         "totals": {"tokens": int, "cost_usd": float, "recorded_cost_usd": float,
                    "records": int, "unknown_tokens": int}}

    ``cost_usd`` is recomputed at CURRENT pricing; ``recorded_cost_usd`` is the
    sum of what each record was stamped with at write time. They differ only
    when PRICING has been corrected since (e.g. BUG-MSO-2026-0834), and the gap
    is reported rather than hidden.
    """
    dims = tuple(d for d in dimensions if d in _VALID_ITERATION_DIMENSIONS)
    if not dims:
        dims = ("model", "effort")

    cutoff = ""
    if days is not None:
        cutoff = (datetime.now() - timedelta(days=int(days))).strftime("%Y-%m-%d")

    buckets = {}
    total_tokens = 0
    total_cost = 0.0
    recorded_cost = 0.0
    record_count = 0
    unknown_tokens = 0

    for record in _iteration_usage_records(usage_dir):
        if cutoff and not _record_within_days(record, cutoff):
            continue
        record_count += 1
        recorded_cost += float(record.get("estimated_cost_usd") or 0.0)

        effort = _bucket_label(record.get("effort"))
        role = _bucket_label(record.get("role"))
        order_id = str(record.get("orderId") or "").strip()

        models = record.get("models")
        if not isinstance(models, dict) or not models:
            # No per-model breakdown (should not happen, but never drop the row):
            # attribute the record's own totals to an unknown model.
            models = {UNKNOWN_BUCKET: {
                "input_tokens": int(record.get("total_tokens") or 0),
                "output_tokens": 0,
                "cache_creation_input_tokens": 0,
                "cache_read_input_tokens": 0,
            }}

        for raw_model, counts in models.items():
            if not isinstance(counts, dict):
                continue
            model = _bucket_label(raw_model)
            inp = int(counts.get("input_tokens") or 0)
            out = int(counts.get("output_tokens") or 0)
            cc = int(counts.get("cache_creation_input_tokens") or 0)
            cr = int(counts.get("cache_read_input_tokens") or 0)
            tokens = inp + out + cc + cr
            cost = 0.0 if model == UNKNOWN_BUCKET else calculate_cost(model, counts)

            values = {"model": model, "effort": effort, "role": role}
            key = tuple(values[d] for d in dims)
            row = buckets.get(key)
            if row is None:
                row = {d: values[d] for d in dims}
                row.update({"tokens": 0, "input_tokens": 0, "output_tokens": 0,
                            "cache_tokens": 0, "cost_usd": 0.0,
                            "records": 0, "_orders": set()})
                buckets[key] = row
            row["tokens"] += tokens
            row["input_tokens"] += inp
            row["output_tokens"] += out
            row["cache_tokens"] += cc + cr
            row["cost_usd"] += cost
            row["records"] += 1
            if order_id:
                row["_orders"].add(order_id)

            total_tokens += tokens
            total_cost += cost
            if UNKNOWN_BUCKET in key:
                unknown_tokens += tokens

    rows = []
    for key in sorted(buckets):
        row = buckets[key]
        row["orders"] = len(row.pop("_orders"))
        row["cost_usd"] = round(row["cost_usd"], 4)
        rows.append(row)

    return {
        "dimensions": list(dims),
        "days": days,
        "buckets": rows,
        "totals": {
            "tokens": total_tokens,
            "cost_usd": round(total_cost, 4),
            "recorded_cost_usd": round(recorded_cost, 4),
            "records": record_count,
            "unknown_tokens": unknown_tokens,
        },
    }


def print_effort_breakdown(agg: dict):
    """Print the model x effort table produced by aggregate_iteration_usage_by()."""
    dims = agg.get("dimensions") or ["model", "effort"]
    totals = agg.get("totals") or {}
    rows = agg.get("buckets") or []
    days = agg.get("days")

    window = f"last {days} day{'s' if days != 1 else ''}" if days else "all time"

    print("=" * 72)
    print("FLEET COMMAND - USAGE BY MODEL x EFFORT")
    print("=" * 72)
    print(f"  Window:      {window}")
    print(f"  Iterations:  {totals.get('records', 0):,}")
    print(f"  Tokens:      {format_tokens(totals.get('tokens', 0))}")
    print(f"  Est. Cost:   ${totals.get('cost_usd', 0):,.2f}")
    print()

    if not rows:
        suffix = " in this window" if days else ""
        print(f"  No per-iteration usage records found{suffix}.")
        print("  (Records are written by the stop hook to usage/orders/*.jsonl.)")
        print()
        return

    label = " x ".join(d.capitalize() for d in dims)
    print(f"BY {label.upper()}:")
    print("-" * 72)
    header = f"  {'Model':<24} {'Effort':<10}"
    if "role" in dims:
        header += f" {'Role':<6}"
    header += f" {'Tokens':>10} {'Iters':>7} {'Cost':>10}"
    print(header)
    print("-" * 72)

    for row in rows:
        model = row.get("model", UNKNOWN_BUCKET)
        display = MODEL_NAMES.get(model, model)
        line = f"  {display:<24} {row.get('effort', UNKNOWN_BUCKET):<10}"
        if "role" in dims:
            line += f" {row.get('role', UNKNOWN_BUCKET):<6}"
        line += (f" {format_tokens(row['tokens']):>10} {row['records']:>7,}"
                 f" ${row['cost_usd']:>9,.2f}")
        print(line)

    print("-" * 72)
    pad = 35 + (7 if "role" in dims else 0)
    print(f"  {'TOTAL':<{pad}} {format_tokens(totals.get('tokens', 0)):>10} "
          f"{totals.get('records', 0):>7,} ${totals.get('cost_usd', 0):>9,.2f}")
    print()

    if totals.get("unknown_tokens"):
        share = totals["unknown_tokens"] / max(totals.get("tokens", 0), 1)
        print(f"  NOTE: '{UNKNOWN_BUCKET}' rows are {_UNKNOWN_FOOTNOTE}.")
        print(f"        {format_tokens(totals['unknown_tokens'])} tokens "
              f"({share:.0%}) fall in an unknown bucket.")
        print()

    recorded = totals.get("recorded_cost_usd", 0)
    if recorded and abs(recorded - totals.get("cost_usd", 0)) > 0.01:
        print(f"  NOTE: cost recomputed at current pricing (${totals['cost_usd']:,.2f}); "
              f"records were stamped ${recorded:,.2f} at write time.")
        print()


def effort_breakdown_markdown(agg: dict) -> list:
    """Markdown lines for the model x effort section of --report. [] when no data."""
    rows = agg.get("buckets") or []
    if not rows:
        # An empty table reads as "nothing was spent" - omit the section entirely.
        return []
    totals = agg.get("totals") or {}
    lines = [
        "---",
        "",
        "## Usage by Model x Effort",
        "",
        "_Source: durable per-iteration records (`usage/orders/*.jsonl`), not "
        "Claude Code transcripts._",
        "",
        "| Model | Effort | Tokens | Iterations | Cost |",
        "|-------|--------|--------|------------|------|",
    ]
    for row in rows:
        model = row.get("model", UNKNOWN_BUCKET)
        display = MODEL_NAMES.get(model, model)
        lines.append(
            f"| {display} | {row.get('effort', UNKNOWN_BUCKET)} | "
            f"{format_tokens(row['tokens'])} | {row['records']:,} | ${row['cost_usd']:,.2f} |"
        )
    lines.append(
        f"| **Total** | | **{format_tokens(totals.get('tokens', 0))}** | "
        f"**{totals.get('records', 0):,}** | **${totals.get('cost_usd', 0):,.2f}** |"
    )
    lines.append("")
    if totals.get("unknown_tokens"):
        lines.append(f"> `{UNKNOWN_BUCKET}` rows are {_UNKNOWN_FOOTNOTE}.")
        lines.append("")
    return lines


def print_summary(sessions: list):
    """Print a formatted summary of all sessions."""
    grand_models = defaultdict(lambda: {
        "input_tokens": 0, "output_tokens": 0,
        "cache_creation_input_tokens": 0, "cache_read_input_tokens": 0,
        "message_count": 0,
    })
    grand_total_tokens = 0
    grand_total_cost = 0.0
    total_messages = 0
    unpriced_sessions = 0
    unpriced_reason = ""
    contributing_bases = set()

    for s in sessions:
        total_messages += s.get("message_count", 0)
        grand_total_tokens += s.get("total_tokens", 0)
        # FTR-MSO-2026-0871 D6: an unpriced session is COUNTED, never summed
        # as zero -- `grand_total_cost` would otherwise read as the fleet's
        # spend while silently omitting part of it.
        basis, reason = read_cost_basis(s)
        contributing_bases.add(basis)
        session_cost = s.get("estimated_cost_usd")
        if basis == CostBasis.UNPRICED or session_cost is None:
            unpriced_sessions += 1
            if reason and not unpriced_reason:
                unpriced_reason = reason
        else:
            grand_total_cost += session_cost
        for model, usage in s.get("models", {}).items():
            for key in grand_models[model]:
                grand_models[model][key] += usage.get(key, 0)

    review_secs, review_count = _aggregate_review_time()

    print("=" * 72)
    print("FLEET COMMAND — TOKEN USAGE SUMMARY")
    print("=" * 72)
    print(f"  Sessions:    {len(sessions)}")
    print(f"  Messages:    {total_messages:,}")
    print(f"  Tokens:      {format_tokens(grand_total_tokens)}")
    print(f"  Est. Cost:   {format_cost_summary(grand_total_cost, unpriced_sessions, len(sessions), unpriced_reason)}")
    if review_count > 0:
        review_mins = round(review_secs / 60, 1)
        print(f"  Operator review:  {review_mins} minutes across {review_count} order{'s' if review_count != 1 else ''}")
    print()

    print("BY MODEL:")
    print("-" * 72)
    print(f"  {'Model':<30} {'Input':>10} {'Output':>10} {'Cache':>12} {'Cost':>10}")
    print("-" * 72)

    for model in sorted(grand_models.keys()):
        if model in ("<synthetic>", "unknown"):
            continue
        u = grand_models[model]
        display = MODEL_NAMES.get(canonical_model_id(model), model)
        inp = u["input_tokens"]
        out = u["output_tokens"]
        cache = u["cache_creation_input_tokens"] + u["cache_read_input_tokens"]
        # FTR-MSO-2026-0871: a model this backend has no rate for prints
        # `unpriced`, not `$0.00`.
        cost, _basis = calculate_cost_basis(model, u)
        cost_cell = f"${cost:>9,.2f}" if cost is not None else f"{UNPRICED_LABEL:>10}"
        print(f"  {display:<30} {format_tokens(inp):>10} {format_tokens(out):>10} {format_tokens(cache):>12} {cost_cell}")

    print("-" * 72)
    if unpriced_sessions > 0:
        total_cell = f"{UNPRICED_LABEL:>10}" if unpriced_sessions >= len(sessions) else f"${grand_total_cost:>9,.2f}*"
    else:
        total_cell = f"${grand_total_cost:>9,.2f}"
    print(f"  {'TOTAL':<30} {'':>10} {'':>10} {'':>12} {total_cell}")
    if unpriced_sessions > 0:
        print(f"  * {format_cost_summary(grand_total_cost, unpriced_sessions, len(sessions), unpriced_reason)}")
    print()


def generate_usage_report(sessions: list, output_path: str = None):
    """Generate a markdown usage report."""
    grand_models = defaultdict(lambda: {
        "input_tokens": 0, "output_tokens": 0,
        "cache_creation_input_tokens": 0, "cache_read_input_tokens": 0,
        "message_count": 0,
    })
    grand_total_tokens = 0
    grand_total_cost = 0.0
    total_messages = 0
    unpriced_sessions = 0
    unpriced_reason = ""

    for s in sessions:
        total_messages += s.get("message_count", 0)
        grand_total_tokens += s.get("total_tokens", 0)
        # FTR-MSO-2026-0871 D6 -- count, never sum as zero. `mso usage --report`
        # is read to make spend decisions, so a total that silently omits part
        # of the spend is worse here than anywhere else in the codebase.
        basis, reason = read_cost_basis(s)
        session_cost = s.get("estimated_cost_usd")
        if basis == CostBasis.UNPRICED or session_cost is None:
            unpriced_sessions += 1
            if reason and not unpriced_reason:
                unpriced_reason = reason
        else:
            grand_total_cost += session_cost
        for model, usage in s.get("models", {}).items():
            for key in grand_models[model]:
                grand_models[model][key] += usage.get(key, 0)

    cost_line = format_cost_summary(grand_total_cost, unpriced_sessions, len(sessions), unpriced_reason)

    now = datetime.now().strftime("%Y-%m-%d %H:%M")

    lines = [
        f"# Maestro — Token Usage Report",
        f"",
        f"**Generated:** {now}",
        f"**Sessions:** {len(sessions)}",
        f"**Total Messages:** {total_messages:,}",
        f"**Total Tokens:** {format_tokens(grand_total_tokens)}",
        f"**Estimated Cost:** {cost_line}",
        f"",
        f"---",
        f"",
        f"## Usage by Model",
        f"",
        f"| Model | Input | Output | Cache Create | Cache Read | Total | Cost |",
        f"|-------|-------|--------|-------------|------------|-------|------|",
    ]

    for model in sorted(grand_models.keys()):
        if model in ("<synthetic>", "unknown"):
            continue
        u = grand_models[model]
        display = MODEL_NAMES.get(canonical_model_id(model), model)
        inp = u["input_tokens"]
        out = u["output_tokens"]
        cc = u["cache_creation_input_tokens"]
        cr = u["cache_read_input_tokens"]
        total = inp + out + cc + cr
        cost, _basis = calculate_cost_basis(model, u)
        cost_cell = f"${cost:,.2f}" if cost is not None else UNPRICED_LABEL
        lines.append(
            f"| {display} | {format_tokens(inp)} | {format_tokens(out)} | "
            f"{format_tokens(cc)} | {format_tokens(cr)} | {format_tokens(total)} | {cost_cell} |"
        )

    if unpriced_sessions > 0:
        total_cell = UNPRICED_LABEL if unpriced_sessions >= len(sessions) else f"{cost_line}"
    else:
        total_cell = f"${grand_total_cost:,.2f}"
    lines.append(f"| **Total** | | | | | **{format_tokens(grand_total_tokens)}** | **{total_cell}** |")
    lines.append("")

    # Per-session breakdown
    lines.extend([
        "---",
        "",
        "## Per-Session Breakdown",
        "",
        "| # | Date | Messages | Tokens | Model | Cost |",
        "|---|------|----------|--------|-------|------|",
    ])

    for i, s in enumerate(sessions, 1):
        date = s.get("start_time", "?")[:16] if s.get("start_time") else "?"
        msgs = s.get("message_count", 0)
        tokens = s.get("total_tokens", 0)
        cost = s.get("estimated_cost_usd")
        session_basis, _session_reason = read_cost_basis(s)
        if cost is None or session_basis == CostBasis.UNPRICED:
            cost_cell = UNPRICED_LABEL
        else:
            cost_cell = f"${cost:,.2f}"
        primary_model = max(s.get("models", {}).items(), key=lambda x: sum(x[1].values()))[0] if s.get("models") else "?"
        display_model = MODEL_NAMES.get(canonical_model_id(primary_model), primary_model)
        lines.append(f"| {i} | {date} | {msgs} | {format_tokens(tokens)} | {display_model} | {cost_cell} |")

    lines.append("")

    # FTR-MSO-2026-0835: model x effort over the durable per-iteration records.
    # Appended only when at least one such record exists — an empty table would
    # read as "nothing was spent" rather than "this fleet has no records yet".
    try:
        lines.extend(effort_breakdown_markdown(
            aggregate_iteration_usage_by(("model", "effort"))
        ))
    except Exception:
        pass  # a reporting extra must never sink the whole report

    report = "\n".join(lines)

    if output_path:
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(report)
        print(f"Report written: {output_path}")
    else:
        print(report)


def _positive_days(value: str) -> int:
    """argparse type for --days: a positive integer, or a clean parse error.

    A non-positive or non-integer value must never degrade silently into an
    all-time report — the operator asked for a window and would read the answer
    as one.
    """
    try:
        days = int(value)
    except (TypeError, ValueError):
        raise argparse.ArgumentTypeError(f"--days must be an integer (got {value!r})")
    if days <= 0:
        raise argparse.ArgumentTypeError(f"--days must be a positive integer (got {days})")
    return days


def main():
    parser = argparse.ArgumentParser(
        description=f"Maestro - Usage Tracker v{resolve_version()}"
    )
    parser.add_argument("--crew", type=int, help="Show usage for a specific crew")
    parser.add_argument("--order", type=str, help="Show usage for a specific order")
    parser.add_argument("--voyage", type=str, help="Aggregate usage for a voyage")
    parser.add_argument("--summary", action="store_true", help="Show grand total summary")
    parser.add_argument("--report", action="store_true", help="Generate markdown report")
    parser.add_argument("--by-effort", action="store_true",
                        help="Model x reasoning-effort cost table from the durable "
                             "per-iteration usage records (FTR-MSO-2026-0835)")
    parser.add_argument("--by-role", action="store_true",
                        help="Add the role dimension to --by-effort")
    parser.add_argument("--days", type=_positive_days, default=None,
                        help="Restrict --by-effort to the last N days (e.g. 7, 15, 30)")
    parser.add_argument("--output", type=str, help="Output path for report")
    parser.add_argument("--transcript", type=str, help="Parse a single transcript file")
    parser.add_argument("--maestro-dir", type=str, default="",
                        help="Workspace artefact dir (.mso). Usage is read from here.")
    parser.add_argument("--project", type=str, default="",
                        help="Project acronym to disambiguate Claude project "
                             "transcript directories (e.g. MSO). Overrides MAESTRO_PROJECT.")
    parser.add_argument("--project-path", type=str, default="",
                        help="Explicit Claude Code transcript directory, bypassing auto-detection.")

    args = parser.parse_args()

    # BUG-MSO-2026-0201: the per-order usage files are WRITTEN by the stop hook to
    # the workspace `.mso/usage/orders/`, but USAGE_DIR defaulted to the installed
    # package's own `usage/` dir — so reads never found them and `mso usage` reported
    # 0 orders. Resolve the workspace dir (CLI passes --maestro-dir; fall back to the
    # MAESTRO_DIR env or a `.mso` under the current working directory).
    global MAESTRO_DIR, USAGE_DIR
    resolved_root = ""
    if args.maestro_dir:
        resolved_root = args.maestro_dir
    elif os.environ.get("MAESTRO_DIR"):
        resolved_root = os.environ["MAESTRO_DIR"]
    elif (Path.cwd() / _MSO_NAME).exists():
        resolved_root = str(Path.cwd() / _MSO_NAME)
    if resolved_root:
        MAESTRO_DIR = Path(resolved_root)
        USAGE_DIR = MAESTRO_DIR / "usage"

    if args.transcript:
        usage = parse_transcript(args.transcript)
        print(json.dumps(usage, indent=2))
        return

    if args.order:
        usage_file = USAGE_DIR / "orders" / f"{args.order}.json"
        if usage_file.exists():
            with open(usage_file, encoding="utf-8") as f:
                print(json.dumps(json.load(f), indent=2))
        else:
            print(f"No usage data for order {args.order}")
        return

    if args.voyage:
        agg = aggregate_voyage_usage(args.voyage)
        total_cost = agg.get("estimated_cost_usd") or 0.0
        review_secs = agg.get("reviewTimeSeconds", 0)
        review_count = agg.get("reviewOrderCount", 0)
        order_count = agg.get("order_count", 0)
        unpriced_orders = agg.get("unpricedOrderCount", 0)
        print("=" * 72)
        print(f"VOYAGE USAGE — {agg['voyage_id']}")
        print("=" * 72)
        print(f"  Orders:      {order_count}")
        print(f"  Tokens:      {format_tokens(agg.get('total_tokens', 0))}")
        # FTR-MSO-2026-0871 D8 -- never a bare total when part of the voyage is
        # unpriced.
        print("  Token cost:  " + format_cost_summary(
            total_cost, unpriced_orders, order_count,
            agg.get("costBasisReason", ""), noun="order",
        ))
        if review_count > 0:
            review_mins = round(review_secs / 60, 1)
            print(f"  Operator review:  {review_mins} minutes across {review_count} order{'s' if review_count != 1 else ''}")
        return

    # FTR-MSO-2026-0835: reads the durable per-iteration records, so it must run
    # BEFORE the transcript scan below — there is no reason to pay that cost.
    if args.by_effort:
        dims = ("model", "effort", "role") if args.by_role else ("model", "effort")
        print_effort_breakdown(aggregate_iteration_usage_by(dims, days=args.days))
        return

    # Default: scan all project sessions
    sessions = scan_all_project_sessions(
        project_path=args.project_path or None,
        project_acronym=args.project or None,
    )

    if args.report:
        output = args.output or str(MAESTRO_DIR / "reports" / "usage" / f"usage-report-{datetime.now().strftime('%Y-%m-%d')}.md")
        os.makedirs(os.path.dirname(output), exist_ok=True)
        generate_usage_report(sessions, output)
    elif args.summary or not any([args.crew, args.order, args.voyage]):
        print_summary(sessions)


if __name__ == "__main__":
    run_cli(main, command="mso usage")
