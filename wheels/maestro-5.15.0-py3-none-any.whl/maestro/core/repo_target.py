"""maestro/core/repo_target.py — which product repository a voyage's PR lives in.

BUG-MSO-2026-0825. A multi-repo workspace (``artefacts.repos``, FTR-MSO-2026-0377)
spans N product repositories under one workspace. A voyage that targets a
SECONDARY repo still names only its branch (and, for a single-repo voyage, a
flat ``prNumber``), so any PR lookup that does not first resolve the voyage's
``targetRepo`` falls through to the workspace's PRIMARY repo:

* every ``mso pr`` verb (``pr_verbs.voyage_pr``) looked the branch up in the
  primary repo and reported "no pull request found" for a PR that was open;
* ``mso voyage reconcile`` looked the voyage's PR up BY NUMBER in the primary
  repo, where an unrelated, closed PR happened to share the number, and flagged
  the voyage "CLOSED WITHOUT MERGING".

The second is the dangerous half: a PR number means nothing without its
repository. This module is the one derivation of that repository, so the two
call sites (and the dispatcher's branch-ensure path, which has the same
matching rules) cannot drift apart.

Pure functions over explicit inputs — no CWD, no ``MAESTRO_DIR``, no printing,
never raises. A single-repo workspace (no ``repos`` map) always resolves to
``None``, which every caller treats as "use the workspace default exactly as
before".
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Optional


@dataclass(frozen=True)
class RepoTarget:
    """One repos-map entry, resolved to what a provider needs.

    ``slug`` is the ``owner/repo`` form whenever it can be built (the entry's
    own ``slug``, else the map key qualified with the workspace's default org),
    otherwise the bare name. ``path`` is the entry's local checkout, or None.
    """

    name: str
    slug: str
    path: Optional[Path]
    default_branch: str


def match_repo_entry(target_repo: Optional[str],
                     repos: Optional[Mapping[str, Any]]) -> Optional[tuple[str, dict]]:
    """``(repoName, entry)`` for *target_repo* in a repos map, or None.

    Matches the map key first, then an entry whose ``slug`` equals
    *target_repo* or whose slug's repo half equals it — so a bare name
    (``GKT-Portal``) and a qualified slug (``tavisbasing/GKT-Portal``) resolve
    to the same entry. The same rules as the dispatcher's
    ``fleet_runner._resolve_repo_map_entry``, which delegates here.
    """
    if not target_repo or not isinstance(target_repo, str) or not isinstance(repos, Mapping):
        return None
    wanted = target_repo.strip().strip("/")
    if not wanted:
        return None
    entry = repos.get(wanted)
    if isinstance(entry, dict):
        return wanted, entry
    for name, entry in repos.items():
        if not isinstance(entry, dict):
            continue
        slug = str(entry.get("slug") or "").strip().strip("/")
        if slug and (slug == wanted or ("/" in slug and slug.split("/", 1)[-1] == wanted)):
            return name, entry
    return None


def resolve_repo_target(target_repo: Optional[str],
                        repos: Optional[Mapping[str, Any]],
                        default_org: str = "") -> Optional[RepoTarget]:
    """Resolve *target_repo* against *repos* to a :class:`RepoTarget`, or None."""
    matched = match_repo_entry(target_repo, repos)
    if matched is None:
        return None
    name, entry = matched
    slug = str(entry.get("slug") or "").strip().strip("/") or name
    if "/" not in slug and default_org:
        slug = f"{default_org.strip().strip('/')}/{slug}"
    raw_path = entry.get("path")
    path = Path(raw_path) if isinstance(raw_path, str) and raw_path.strip() else None
    default_branch = str(entry.get("defaultBranch") or "").strip()
    return RepoTarget(name=name, slug=slug, path=path, default_branch=default_branch)


def voyage_repo_names(voyage: Mapping[str, Any]) -> list[str]:
    """Every repo a voyage manifest names, ordered and de-duplicated.

    ``targetRepos`` (authoritative), then the flat ``targetRepo``, then the
    keys of a per-repo ``prUrls`` map.
    """
    names: list[str] = []

    def _add(value: Any) -> None:
        if isinstance(value, str) and value.strip() and value.strip() not in names:
            names.append(value.strip())

    repos = voyage.get("targetRepos")
    if isinstance(repos, list):
        for repo in repos:
            _add(repo)
    _add(voyage.get("targetRepo"))
    prurls = voyage.get("prUrls")
    if isinstance(prurls, dict):
        for repo in prurls:
            _add(repo)
    return names


def voyage_repo_target(voyage: Mapping[str, Any],
                       repos: Optional[Mapping[str, Any]],
                       default_org: str = "") -> Optional[RepoTarget]:
    """The ONE repository a voyage's PR lives in, or None.

    None when no repos map is configured (single-repo workspace), when the
    voyage names no repo, or when its names resolve to more than one distinct
    entry — a genuinely multi-repo voyage has one PR per repo and no single
    answer. A name the map does not know is ignored rather than guessed at.
    """
    if not isinstance(repos, Mapping) or not repos:
        return None
    found: dict[str, RepoTarget] = {}
    for name in voyage_repo_names(voyage):
        target = resolve_repo_target(name, repos, default_org)
        if target is not None:
            found.setdefault(target.name, target)
    if len(found) != 1:
        return None
    return next(iter(found.values()))


def _branch_key(branch: Any) -> str:
    return str(branch or "").strip().replace("refs/heads/", "")


def find_voyage_by_branch(artefact_root: Path, branch: str) -> Optional[dict]:
    """The voyage manifest whose branch is *branch* — active first, then complete."""
    wanted = _branch_key(branch)
    if not wanted:
        return None
    for sub in ("active", "complete"):
        directory = Path(artefact_root) / "voyages" / sub
        try:
            files = sorted(directory.glob("*.json"))
        except OSError:
            continue
        for voyage_file in files:
            try:
                data = json.loads(voyage_file.read_text(encoding="utf-8"))
            except Exception:
                continue
            if not isinstance(data, dict):
                continue
            if wanted in (_branch_key(data.get("branch")), _branch_key(data.get("voyageBranch"))):
                return data
    return None


def workspace_default_org(artefact_root: Path) -> str:
    """``defaultGitHubOrg`` (or legacy ``org``) from the artefact workspace.json, or ""."""
    try:
        data = json.loads((Path(artefact_root) / "config" / "workspace.json").read_text(encoding="utf-8"))
    except Exception:
        return ""
    if not isinstance(data, dict):
        return ""
    return str(data.get("defaultGitHubOrg") or data.get("org") or "").strip()
