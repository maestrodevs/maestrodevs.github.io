"""Model-backend credential probe, TTL cache and hold state (FTR-MSO-2026-0869).

ADR-3 of ``PLAN-PLN-MSO-2026-0864``. A workspace configured for a remote model
backend (AWS Bedrock today) stops being able to launch crews the moment its SSO
session expires — every crew process comes up, refuses, and dies. Before this
module the dispatcher could not tell that apart from an order that keeps
failing, so it spent the order's whole requeue budget on a machine-level fault
no retry of that order could fix, then archived it STALLED. That is
BUG-MSO-2026-0814's incident shape exactly, one layer out, and this module is
the same answer: **detect, hold new dispatch, leave running crews alone, and
tell the Captain.**

**Maestro never runs ``aws sso login``.** Browser-based SSO needs a human at a
browser, and a detached crew launched with ``CREATE_NO_WINDOW`` has nobody to
click the link — attempting it produces the documented authentication-loop
failure mode. The honest behaviour is to report the remedy, not to try it.

Three states, two outcomes
--------------------------

=================  ================================================
``probe()``        the gate
=================  ================================================
``available``      allow — and lift any hold
``indeterminate``  **allow** — no event, no state write, no hold,
                   and (the part that is easy to get wrong) no
                   clearing of a hold that is already latched
``unavailable``    hold
=================  ================================================

*indeterminate* must never hold dispatch: a machine with no ``aws`` CLI, or one
authenticating by instance role, would otherwise never dispatch at all. And it
must never CLEAR a hold either — nothing has been proven restored, so the latch
stays and ``MODEL_BACKEND_RESTORED`` still fires later on the first genuinely
``available`` probe.

Two readers, one file
---------------------

The gate's in-process latch (``fleet_runner._MODEL_BACKEND_HOLD``) is what makes
the lifecycle events fire once per transition, but it is invisible to ``mso
status`` and the Hub, which are separate processes. So each transition also
writes ``state/model-backend.json`` — the ``artefact_divergence.py`` shape
verbatim, for the same reason that module gives: a hold stays true for the
operator even after the dispatcher that raised it has exited, and both reading
surfaces must read the same file rather than each deciding for itself.

Everything here is fail-open. A check that can hold a fleet by failing itself is
worse than no check.
"""
from __future__ import annotations

import json
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Dict, NamedTuple, Optional, Tuple

#: How long a probe verdict is reused before the backend is asked again.
#:
#: The dispatcher ticks roughly every 10s and ``bedrock.probe()`` shells out to
#: ``aws sts get-caller-identity`` with a 10s cap, so an uncached per-tick probe
#: would spend a subprocess every tick forever and, on a slow STS, make the tick
#: itself take 10s.
#:
#: The honest consequence, stated here and in the ``MODEL_BACKEND_RESTORED``
#: message rather than glossed over: a hold lifts on the first tick whose probe
#: is fresh AND passing, i.e. **within one TTL** of the credentials actually
#: returning. No dispatcher restart is needed — but this is not sub-tick
#: precision and must not be described as if it were.
#:
#: ``crew.py``'s 300s memo is deliberately longer (a crew runs up to 25
#: iterations and must not re-probe a dead SSO session 25 times). The two
#: lifetimes answer different questions; they are not unified.
#:
#: PUBLIC, because the gate quotes it in the ``MODEL_BACKEND_RESTORED`` message
#: — a message that states a bound must not be able to drift from the bound it
#: states.
PROBE_TTL_SECONDS = 60

#: The spelling ``PLAN-FTR-MSO-2026-0869`` names. ONE value, aliased — change
#: :data:`PROBE_TTL_SECONDS` above; never assign to this.
_PROBE_TTL_SECONDS = PROBE_TTL_SECONDS

#: The only three values :attr:`ProbeVerdict.state` ever takes.
PROBE_STATES = ("available", "unavailable", "indeterminate")

_CACHE: Dict[str, Tuple[float, "ProbeVerdict"]] = {}
_CACHE_LOCK = threading.Lock()


class ProbeVerdict(NamedTuple):
    """What the workspace's configured model backend said, once."""

    state: str          # one of PROBE_STATES
    backend_id: str     # the configured provider id ("bedrock", "anthropic", ...)
    reason: str         # the provider's OWN sentence; "" when available
    remedy: str         # the operator's next step; "" when there is nothing to do

    @property
    def holds_dispatch(self) -> bool:
        """``True`` only for a POSITIVELY established failure.

        ``indeterminate`` is not a failure — see this module's docstring.
        """
        return self.state == "unavailable"


def _workspace_key(workspace: Optional[Path]) -> str:
    try:
        return str(Path(workspace).resolve()) if workspace is not None else ""
    except Exception:  # noqa: BLE001 — an unresolvable path still keys fine as text
        return str(workspace)


def build_remedy(backend_id: str, reason: str) -> str:
    """The operator's next step for *reason*, without ever duplicating one.

    ``bedrock._explain_probe_failure`` already composes Maestro's OWN sentence
    for a recognised expiry signature, ending in the exact
    ``aws sso login --profile <name>``. When *reason* carries that, it is passed
    through and nothing is appended — a second, vaguer instruction after a
    precise one only invites the operator to run the wrong thing.

    Nothing here interpolates provider config, environment values or raw AWS
    output (AC4): every string this can return is either Maestro's own literal
    or a sentence the provider already capped and signature-matched.
    """
    reason = str(reason or "")
    if "aws sso login" in reason.lower():
        return ""
    backend = str(backend_id or "model")
    return (
        f"Maestro does not authenticate for you — inspect the '{backend}' backend "
        f"with `mso providers show model` and re-test it with `mso providers test "
        f"model` once the credentials are back."
    )


def _uncached_probe(workspace: Optional[Path]) -> ProbeVerdict:
    """One probe of the workspace's configured model backend. Never raises."""
    # Imported INSIDE the function, matching `crew.py:_resolve_model_backend`'s
    # deliberate avoidance of a module-scope `providers` dependency: this module
    # is imported by the dispatcher's hot path and by `mso status`, and neither
    # should pay for the provider registry when no backend is configured.
    try:
        from maestro import providers
    except Exception as exc:  # noqa: BLE001
        return ProbeVerdict("indeterminate", "", f"providers unavailable ({type(exc).__name__})", "")

    # An UNCONFIGURED workspace is the overwhelmingly common case and this
    # order's load-bearing negative property (Order 2's negative acceptance,
    # carried to the gate): nothing is instantiated, nothing is probed, no
    # subprocess is spawned. `configured_entry` reads config only — it is
    # explicitly the half of `resolve_explain` that does NOT probe.
    try:
        _tier, configured_id, _config = providers.configured_entry("model", workspace)
    except Exception as exc:  # noqa: BLE001
        return ProbeVerdict("indeterminate", "", f"configuration unreadable ({type(exc).__name__})", "")

    if configured_id is None:
        return ProbeVerdict("indeterminate", "", "no model backend configured", "")

    backend_id = str(configured_id)
    try:
        resolved = providers.resolve_explain("model", workspace)
    except Exception as exc:  # noqa: BLE001 — resolve_explain never raises; belt and braces
        return ProbeVerdict("indeterminate", backend_id,
                            f"backend could not be resolved ({type(exc).__name__})", "")

    provider = getattr(resolved, "provider", None)
    backend_id = str(getattr(resolved, "provider_id", backend_id) or backend_id)

    if provider is None:
        # `resolve_explain` hands back no instance when `available()` was False,
        # when the id is unknown, or when the provider failed to initialise. All
        # three mean every crew launch against this workspace will be REFUSED by
        # `crew.plan_model_backend` — a machine/config-level fault that no retry
        # of any single order can fix, which is exactly what this gate holds on.
        # `resolved.reason` is the provider's own composed sentence (already
        # capped and signature-matched); it is used as-is, never re-derived.
        reason = str(getattr(resolved, "reason", "") or f"model backend '{backend_id}' is unavailable")
        return ProbeVerdict("unavailable", backend_id, reason, build_remedy(backend_id, reason))

    # The backend is up as far as `available()` is concerned — but `available()`
    # is only two-state, and `bedrock` maps BOTH "available" and "indeterminate"
    # onto True. Ask `probe()` for the third state, which is the one that
    # decides whether a latched hold may be cleared (it may not, on
    # indeterminate). This is a second probe on the healthy path; the TTL cache
    # above is what keeps it to one pair per minute rather than one per tick.
    try:
        state, reason = provider.probe()
    except Exception as exc:  # noqa: BLE001 — contract says it cannot; belt and braces
        return ProbeVerdict("indeterminate", backend_id, f"probe raised {type(exc).__name__}", "")

    state = str(state or "").lower()
    if state not in PROBE_STATES:
        # An unrecognised state is not evidence of anything. Never collapse it
        # into `unavailable`: a backend with a typo'd verdict must not be able
        # to hold the fleet.
        return ProbeVerdict("indeterminate", backend_id,
                            f"backend returned an unrecognised probe state {state!r}", "")
    reason = str(reason or "")
    remedy = build_remedy(backend_id, reason) if state == "unavailable" else ""
    return ProbeVerdict(state, backend_id, reason, remedy)


def probe_model_backend(workspace: Optional[Path], *,
                        clock: Callable[[], float] = time.monotonic) -> ProbeVerdict:
    """The workspace's model-backend credential state, memoised for the TTL.

    Never raises: every failure path resolves to ``indeterminate``, which
    allows dispatch. *clock* is injectable so tests advance time instead of
    sleeping.
    """
    key = _workspace_key(workspace)
    try:
        now = clock()
    except Exception:  # noqa: BLE001 — a broken clock must not break the gate
        now = time.monotonic()

    with _CACHE_LOCK:
        hit = _CACHE.get(key)
    if hit is not None and (now - hit[0]) < PROBE_TTL_SECONDS:
        return hit[1]

    try:
        verdict = _uncached_probe(workspace)
    except Exception as exc:  # noqa: BLE001 — the function above cannot, so this is belt and braces
        verdict = ProbeVerdict("indeterminate", "", f"probe failed ({type(exc).__name__})", "")

    with _CACHE_LOCK:
        _CACHE[key] = (now, verdict)
    return verdict


def reset_cache() -> None:
    """Drop every memoised verdict (tests; and any caller that has just changed
    the workspace's provider configuration)."""
    with _CACHE_LOCK:
        _CACHE.clear()


# ---------------------------------------------------------------------------
# The off-process hold state — `artefact_divergence.py`'s shape, verbatim
# ---------------------------------------------------------------------------

def _state_file(artefact_root: Path) -> Path:
    return Path(artefact_root) / "state" / "model-backend.json"


def read_backend_state(artefact_root: Path) -> Dict[str, Any]:
    """The persisted hold state; ``{}`` if absent/unreadable (never held)."""
    try:
        return json.loads(_state_file(artefact_root).read_text(encoding="utf-8"))
    except Exception:
        return {}


def write_backend_state(artefact_root: Path, **fields: Any) -> None:
    """Merge-write the hold state file (fail-open on IO errors)."""
    try:
        state = read_backend_state(artefact_root)
        state.update(fields)
        state["updatedAt"] = datetime.now().isoformat()
        path = _state_file(artefact_root)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(state, indent=2), encoding="utf-8")
    except Exception:
        pass


def hold_detail(verdict: ProbeVerdict) -> str:
    """The one-line operator string both reading surfaces render.

    Built once here so ``mso status``'s footer and the Hub's
    ``model_backend_detail`` can never word the same condition differently.
    """
    backend = verdict.backend_id or "model backend"
    reason = verdict.reason or "credentials are unavailable"
    return f"MODEL BACKEND UNAVAILABLE ({backend}) — {reason}"
