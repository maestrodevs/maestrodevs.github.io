"""
maestro/review.py — Human review queue CLI handlers.

Supports: mso review queue | show | approve | revise | reject
Orders sit in .mso/queues/review/ while awaiting human decision.

BUG-MSO-2026-0486: the actual queue/approve/revise/reject/gate-label logic
now lives in maestro/core/review_core.py, shared with the Hub
(maestro/hub/review.py) so the two surfaces cannot drift out of parity
again. This module is the CLI-shaped adapter around it: workspace
resolution, table/editor rendering, and turning review_core's typed
exceptions into the CLI's print-to-stderr-then-exit(1) convention.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from maestro.cli import find_workspace
from maestro.core import review_core


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _adm_dir(ws: Path) -> Path:
    # BUG-MSO-2026-0425: honour the solo/shared `artefacts` pointer so the review
    # queue reads the artefact plane, not the product repo's frozen .mso. Anchored
    # at *ws* (chosen by find_workspace) so an ambient MAESTRO_DIR can't retarget
    # it. In embedded mode this is byte-identical to resolve_artefact_dir(ws).
    from maestro.workspace import artefact_root_for
    return artefact_root_for(ws)


def _review_dir(adm: Path) -> Path:
    return adm / "queues" / "review"


def _reviewer() -> str:
    """Best-effort reviewer identity (git user or env fallback).

    Kept as a real, module-level CLI hook (delegating to
    ``review_core.reviewer_identity``) rather than inlined, so the CLI
    surface can resolve "who is running this command" independently of the
    Hub's resolution strategy — and so it stays independently patchable in
    tests, matching this module's pre-existing convention.
    """
    return review_core.reviewer_identity()


def _age_str(iso_ts: str) -> str:
    try:
        dt = datetime.fromisoformat(iso_ts)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        delta = datetime.now(timezone.utc) - dt
        minutes = int(delta.total_seconds() // 60)
        if minutes < 60:
            return f"{minutes}m"
        hours = minutes // 60
        if hours < 24:
            return f"{hours}h"
        return f"{hours // 24}d"
    except Exception:
        return "?"


def _exit_not_found(exc: FileNotFoundError) -> None:
    print(f"[review] {exc}", file=sys.stderr)
    sys.exit(1)


def _exit_permission_denied(exc: PermissionError) -> None:
    """Render the capability refusal to stderr, then exit 1.

    BUG-MSO-2026-0889: these three handlers used to just ``sys.exit(1)`` on the
    strength of a comment reading "review_core already printed the formatted
    refusal to stderr" — which was only ever true because the gate itself
    printed the block before raising ``SystemExit``. The gate now raises
    ``CapabilityDenied`` and each surface renders it (the Hub as a 403 detail),
    so the CLI has to print it here. Without this the operator gets a bare exit
    code, and the Slack bridge — which reads the child ``mso review approve``
    process's captured output to explain the refusal — reports nothing at all.

    ``review_core._enforce_capability`` chains the original denial, so the exact
    pre-fix block is reproduced from ``__cause__``; the short
    ``PermissionError`` message is the fallback for any other refusal.
    """
    cause = exc.__cause__
    try:
        from maestro.identity.gate import CapabilityDenied, format_denial
    except Exception:
        CapabilityDenied = ()  # type: ignore[assignment]
        format_denial = None  # type: ignore[assignment]
    if format_denial is not None and isinstance(cause, CapabilityDenied):
        print(format_denial(cause), file=sys.stderr)
    else:
        print(f"\nError: {exc}\n", file=sys.stderr)
    sys.exit(1)


def _exit_bad_status(exc: ValueError) -> None:
    print(f"[review] {exc}", file=sys.stderr)
    sys.exit(1)


# ---------------------------------------------------------------------------
# Command handlers
# ---------------------------------------------------------------------------

# BUG-MSO-2026-0462: queue/show are read-only (they list/display pending
# reviews, same as `mso status` or `mso voyage list`) and neither of those
# gates on a capability either — this codebase's convention is to gate
# state-changing decisions, not reads. approve/revise/reject are gated
# (inside review_core, so both the CLI and the Hub enforce it identically)
# because they are the human sign-off the review gate exists to enforce.

def cmd_review_queue(args: Any) -> None:
    """List orders currently awaiting human review."""
    ws = find_workspace(getattr(args, "project", None))
    adm = _adm_dir(ws)

    orders = review_core.find_review_pending_orders(adm)
    if not orders:
        print("[review] No orders pending review.")
        return

    header = (f"{'ORDER ID':<28} {'TITLE':<40} {'VOYAGE':<22} {'AGE':>5} "
              f"{'ROLE':<6} {'GATE':<12}")
    print(header)
    print("-" * len(header))
    for data in orders:
        order_id = data.get("id", "")
        title = (data.get("title", "") or "")[:38]
        voyage = data.get("voyageId", "")
        paused_at = data.get("navReviewPausedAt", "")
        age = _age_str(paused_at) if paused_at else "?"
        # BUG-MSO-2026-0205: standalone plan-approval orders have no next role.
        role = "PLAN" if data.get("planApprovalOnly") else data.get("targetRole", "")
        # FTR-MSO-2026-0427: which transition is this order held at? An order
        # gated at BLD->REL is indistinguishable from a plan review otherwise.
        gate = data.get("reviewGate") or review_core.gate_label(data)
        print(f"{order_id:<28} {title:<40} {voyage:<22} {age:>5} {role:<6} {gate:<12}")


def cmd_review_show(args: Any) -> None:
    """Open the artefact under review in $EDITOR, or print it to stdout."""
    ws = find_workspace(getattr(args, "project", None))
    adm = _adm_dir(ws)
    order_id = args.order_id

    try:
        _, data = review_core.load_review_order(adm, order_id)
    except FileNotFoundError as exc:
        _exit_not_found(exc)
        return

    doc_path = review_core.review_artefact(adm, order_id, data)
    if doc_path is None:
        # Fallback: dump order JSON
        print(json.dumps(data, indent=2))
        return

    editor = getattr(args, "editor", None) or os.environ.get("EDITOR", "")
    if editor:
        subprocess.run([editor, str(doc_path)])
    else:
        print(doc_path.read_text(encoding="utf-8"))


def cmd_review_approve(args: Any) -> None:
    """Approve an order paused for human review.

    Two cases:
      * Intra-order (targetRole set): advance to the next role and re-queue to
        queues/orders/ for the dispatcher to pick up.
      * BUG-MSO-2026-0205 plan approval (planApprovalOnly): the standalone planning
        order has no next role — archive it as COMPLETE so its dependent FTR/BLD
        orders unblock (NAV_REVIEW_PENDING is not a satisfying dependency status).
    """
    ws = find_workspace(getattr(args, "project", None))
    adm = _adm_dir(ws)
    order_id = args.order_id

    try:
        result = review_core.approve_order(adm, order_id, reviewer=_reviewer())
    except PermissionError as exc:
        _exit_permission_denied(exc)
        return
    except FileNotFoundError as exc:
        _exit_not_found(exc)
        return
    except ValueError as exc:
        _exit_bad_status(exc)
        return

    # FTR-MSO-2026-0860: a decomposition order's approval MINTED orders. Name
    # them — the ids are the whole point of the click, and an operator who
    # cannot see what was filed has to go and read the voyage manifest to find
    # out what they just authorised.
    if result.get("decomposition"):
        filed = result.get("filed_orders") or []
        if result.get("already_filed"):
            print(f"[review] {order_id} breakdown already applied — archived "
                  f"COMPLETE; {len(filed)} order(s) were filed by an earlier "
                  f"approval: {', '.join(filed)}.")
        else:
            print(f"[review] {order_id} breakdown approved — archived COMPLETE; "
                  f"filed {len(filed)} build order(s) PENDING: {', '.join(filed)}.")
        return

    if result["new_status"] == "COMPLETE":
        promo_msg = _promo_message(result)
        print(f"[review] {order_id} plan approved — archived COMPLETE; {promo_msg}.")
        if result.get("decomposition_order"):
            # FTR-MSO-2026-0860: the trigger fired instead of PLAN_ORPHANED.
            print(f"[review] Nothing was filed to build this plan, so Maestro "
                  f"filed decomposition order {result['decomposition_order']} to "
                  f"propose the breakdown. It will come back to you at this same "
                  f"review gate before any build order is minted.")
        if result.get("warning"):
            print(f"[review] WARNING: {result['warning']}.")
        return

    print(f"[review] {order_id} approved at gate {result['gate']} — "
          f"advanced to {result['target_role']} and re-queued.")


def _promo_message(result: dict) -> str:
    promoted = result.get("dependents_promoted", 0)
    filed = result.get("dependents_filed", 0)
    if promoted:
        return f"promoted {promoted} build order(s) to PENDING"
    if filed:
        return f"{filed} dependent(s) already filed, none PROPOSED to promote"
    return "no PROPOSED dependents found to promote"


def cmd_review_revise(args: Any) -> None:
    """Send the order back to the gated role for revision, appending notes.

    FTR-MSO-2026-0427: "back" is the role that just completed and triggered the
    gate, not an unconditional NAV. An order held at BLD->REL goes back to BLD to
    redo the build; only when no transition can be recovered (a pre-0427 pause
    with an unhelpful roleSequence) does it fall back to NAV.
    """
    ws = find_workspace(getattr(args, "project", None))
    adm = _adm_dir(ws)
    order_id = args.order_id
    notes = getattr(args, "notes", None)

    if not notes:
        print("[review] --notes is required for revise.", file=sys.stderr)
        sys.exit(1)

    try:
        result = review_core.revise_order(adm, order_id, notes, reviewer=_reviewer())
    except PermissionError as exc:
        _exit_permission_denied(exc)
        return
    except FileNotFoundError as exc:
        _exit_not_found(exc)
        return
    except ValueError as exc:
        _exit_bad_status(exc)
        return

    print(f"[review] {order_id} sent back to {result['target_role']} for revision.")


def cmd_review_reject(args: Any) -> None:
    """Reject an order: mark it FAILED and archive it."""
    ws = find_workspace(getattr(args, "project", None))
    adm = _adm_dir(ws)
    order_id = args.order_id
    notes = getattr(args, "notes", None)

    if not notes:
        print("[review] --notes is required for reject.", file=sys.stderr)
        sys.exit(1)

    try:
        review_core.reject_order(adm, order_id, notes, reviewer=_reviewer())
    except PermissionError as exc:
        _exit_permission_denied(exc)
        return
    except FileNotFoundError as exc:
        _exit_not_found(exc)
        return
    except ValueError as exc:
        _exit_bad_status(exc)
        return

    print(f"[review] {order_id} rejected and archived to orders/failed/.")
