#!/usr/bin/env python3
"""
Fleet Stop Hook v2.0.6 — Iteration control + token tracking for Maestro crews.

Intercepts Claude's natural exit and re-feeds prompts to create a genuine
multi-pass iteration loop. Implements the Ralph Wiggum pattern from Anthropic's
official Claude Code hooks system.

IMPORTANT: This hook ONLY activates for crew sessions (MAESTRO_CREW env set).
The Captain's interactive sessions are NEVER affected.

Hook lifecycle:
  1. Claude finishes a response and tries to exit
  2. Stop event fires, this script runs
  3. Script checks MAESTRO_CREW env — if absent, allows exit (Captain's session)
  4. Reads per-crew ralph-state.md for iteration tracking
  5. Reads transcript for <promise>COMPLETE</promise> or <promise>BLOCKED</promise>
  6. If not complete and iterations remain: blocks exit, re-feeds prompt
  7. If complete or max iterations: allows exit

v2.0.6 Addition:
  - TOKEN TRACKING: On session end (COMPLETE/BLOCKED/MAX_ITERATIONS), parses
    the transcript JSONL for actual API usage (input_tokens, output_tokens,
    cache_creation, cache_read) per model. Saves to .maestro/usage/orders/
    and updates order completedBy metadata with token counts.

Input:  JSON on stdin (from Claude Code hook system)
Output: JSON on stdout with {"decision": "block", "reason": "..."} to continue
        OR exit 0 with no JSON to allow exit
"""

import json
import os
import re
import sys
import tempfile
from collections import defaultdict
from datetime import datetime
from pathlib import Path


def parse_yaml_frontmatter(content: str) -> dict:
    """Parse YAML frontmatter from markdown content (between --- delimiters).

    Uses simple regex parsing — no external YAML library needed.
    """
    match = re.match(r'^---\s*\n(.*?)\n---\s*\n', content, re.DOTALL)
    if not match:
        return {}

    frontmatter = {}
    for line in match.group(1).strip().split('\n'):
        line = line.strip()
        if ':' in line:
            key, _, value = line.partition(':')
            key = key.strip()
            value = value.strip()
            # Strip surrounding quotes
            if value.startswith('"') and value.endswith('"'):
                value = value[1:-1]
            elif value.startswith("'") and value.endswith("'"):
                value = value[1:-1]
            # Convert numeric values
            if value.isdigit():
                value = int(value)
            elif value == 'true':
                value = True
            elif value == 'false':
                value = False
            elif value == 'null':
                value = None
            frontmatter[key] = value

    return frontmatter


def write_state_atomic(state_file: Path, frontmatter: dict, log_entries: str):
    """Write state file atomically (write to temp, rename)."""
    lines = ["---"]
    for key, value in frontmatter.items():
        if isinstance(value, str):
            lines.append(f'{key}: "{value}"')
        elif isinstance(value, bool):
            lines.append(f'{key}: {"true" if value else "false"}')
        elif value is None:
            lines.append(f'{key}: null')
        else:
            lines.append(f'{key}: {value}')
    lines.append("---")
    lines.append("")
    lines.append(log_entries)

    content = "\n".join(lines)

    # Atomic write: temp file + rename
    tmp_path = state_file.with_suffix('.tmp')
    try:
        tmp_path.write_text(content, encoding='utf-8')
        tmp_path.replace(state_file)
    except Exception:
        # Fallback: direct write
        state_file.write_text(content, encoding='utf-8')


def check_transcript_for_promise(transcript_path: str, promise: str) -> tuple:
    """Scan transcript for completion/blocked promise tags.

    Returns (is_complete, is_blocked).
    Only reads the tail of the transcript for performance.
    """
    is_complete = False
    is_blocked = False

    if not transcript_path or not Path(transcript_path).exists():
        return is_complete, is_blocked

    try:
        file_path = Path(transcript_path)
        file_size = file_path.stat().st_size

        # Only read last 100KB for performance on large transcripts
        read_start = max(0, file_size - 102400)

        with open(file_path, 'r', encoding='utf-8', errors='replace') as f:
            if read_start > 0:
                f.seek(read_start)
                # Skip partial first line
                f.readline()

            content = f.read()

        # Search for promise tags in assistant messages
        # JSONL format: each line is a JSON object
        for line in reversed(content.strip().split('\n')):
            line = line.strip()
            if not line:
                continue

            try:
                entry = json.loads(line)
            except json.JSONDecodeError:
                continue

            # Only check assistant messages
            role = entry.get('role', '')
            if role != 'assistant':
                # Also check nested message format
                message = entry.get('message', {})
                if message.get('role', '') != 'assistant':
                    continue
                content_blocks = message.get('content', [])
            else:
                content_blocks = entry.get('content', [])

            # Extract text from content blocks
            text_parts = []
            if isinstance(content_blocks, list):
                for block in content_blocks:
                    if isinstance(block, dict) and block.get('type') == 'text':
                        text_parts.append(block.get('text', ''))
                    elif isinstance(block, str):
                        text_parts.append(block)
            elif isinstance(content_blocks, str):
                text_parts.append(content_blocks)

            full_text = '\n'.join(text_parts)

            # Check for completion promise
            promise_pattern = rf'<promise>\s*{re.escape(promise)}\s*</promise>'
            if re.search(promise_pattern, full_text):
                is_complete = True

            # Check for blocked signal
            if re.search(r'<promise>\s*BLOCKED\s*</promise>', full_text):
                is_blocked = True

            # Only need to check recent assistant messages (last 5)
            if is_complete or is_blocked:
                break

    except Exception:
        pass

    return is_complete, is_blocked


def get_log_entries(state_file: Path) -> str:
    """Extract the log entries section (after the second ---) from the state file."""
    if not state_file.exists():
        return "# Iteration Log\n"

    content = state_file.read_text(encoding='utf-8')
    # Find content after second ---
    parts = content.split('---', 2)
    if len(parts) >= 3:
        return parts[2].strip()
    return "# Iteration Log\n"


def extract_usage_from_transcript(transcript_path: str) -> dict:
    """Parse transcript JSONL and extract token usage per model.

    Returns dict with models, total_tokens, estimated_cost_usd, backend,
    costBasis and costBasisReason.

    FTR-MSO-2026-0871: cost is priced through
    ``fleet_usage_tracker.price_models`` -- the ONE pricer -- so a backend that
    does not bill at Anthropic's first-party list rates writes ``unpriced``
    with a reason rather than a fabricated dollar figure. This hook is the
    writer for the records the fleet actually reads (``.mso/usage/orders/``),
    so the tracker's own change is only half the fix without this one.
    """
    from maestro.core.fleet_usage_tracker import CostBasis, price_models

    models = defaultdict(lambda: {
        "input_tokens": 0, "output_tokens": 0,
        "cache_creation_input_tokens": 0, "cache_read_input_tokens": 0,
        "message_count": 0,
    })

    empty = {
        "models": {}, "total_tokens": 0, "estimated_cost_usd": 0,
        # A zero, not an unknown: nothing in it could be mispriced.
        "backend": "", "costBasis": CostBasis.FIRST_PARTY_LIST, "costBasisReason": "",
    }

    if not transcript_path or not Path(transcript_path).exists():
        return dict(empty)

    try:
        with open(transcript_path, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    entry = json.loads(line)
                except json.JSONDecodeError:
                    continue

                # Support multiple transcript schemas: some use `role` directly,
                # others nest it under `message.role`, and some use `type`.
                # Check `role` first to avoid treating type="message" as the role.
                msg = entry.get("message")
                role = entry.get("role")
                if not role and isinstance(msg, dict):
                    role = msg.get("role")
                if not role:
                    entry_type = entry.get("type", "")
                    if entry_type == "assistant":
                        role = "assistant"

                if role != "assistant":
                    continue

                # Usage/model may live either under `message` or at the top level,
                # depending on the transcript schema.
                if isinstance(msg, dict):
                    msg_container = msg
                else:
                    msg_container = entry

                usage = msg_container.get("usage", {})
                model = msg_container.get("model", "")
                if not model or model in ("<synthetic>", "unknown"):
                    continue

                models[model]["message_count"] += 1
                for key in ["input_tokens", "output_tokens",
                            "cache_creation_input_tokens", "cache_read_input_tokens"]:
                    models[model][key] += usage.get(key, 0)
    except Exception:
        return dict(empty)

    total_tokens = 0
    for u in models.values():
        total_tokens += sum(u[k] for k in ["input_tokens", "output_tokens",
                                           "cache_creation_input_tokens",
                                           "cache_read_input_tokens"])

    resolved_models = {k: dict(v) for k, v in models.items()}
    cost, basis, backend_id, reason = price_models(resolved_models)

    return {
        "models": resolved_models,
        "total_tokens": total_tokens,
        # `None`, never 0, when unpriced -- and the key stays present, because
        # every reader outside the tracker coerces with `... or 0.0`.
        "estimated_cost_usd": cost,
        "backend": backend_id,
        "costBasis": basis,
        "costBasisReason": reason,
    }


def _resolve_voyage_id(mso_root: Path, order_id: str) -> str:
    """Best-effort lookup of the order's voyageId for usage stamping (BUG-MSO-2026-0201).

    Searches the queues + order archives for the order JSON; falls back to parsing
    a VOY-* id out of the dispatcher's voyage-branch env var. Fail-open (returns "").
    """
    try:
        queues = mso_root / "queues"
        search = [
            queues / "orders", queues / "bugs", queues / "security",
            queues / "explicit", queues / "high-level", queues / "defects",
            queues / "breakdown", queues / "review",
            mso_root / "orders" / "active", mso_root / "orders" / "complete",
            mso_root / "orders" / "failed",
        ]
        # queues/requests/ has per-category subdirectories (Copilot PR #89).
        requests_dir = queues / "requests"
        if requests_dir.exists():
            search += [sub for sub in requests_dir.iterdir() if sub.is_dir()]
        for d in search:
            f = d / f"{order_id}.json"
            if f.exists():
                vid = json.loads(f.read_text(encoding="utf-8")).get("voyageId")
                if vid:
                    return vid
    except Exception:
        pass
    # Fallback: dispatcher sets the voyage branch env (voyage/VOY-XXX-YYYY-NNNN-...).
    for env_key in ("MAESTRO_VOYAGE_BRANCH", "MAESTRO_SPRINT_BRANCH"):
        branch = os.environ.get(env_key, "")
        m = re.search(r"VOY-[A-Z]+-\d{4}-\d+", branch)
        if m:
            return m.group(0)
    return ""


_USAGE_MODEL_KEYS = (
    "input_tokens", "output_tokens",
    "cache_creation_input_tokens", "cache_read_input_tokens", "message_count",
)


def _format_usage_cost(usage: dict) -> str:
    """``"$1.23"`` or ``"unpriced"`` (FTR-MSO-2026-0871).

    ``estimated_cost_usd`` became ``Optional[float]`` with this order, and a
    ``None`` formatted with ``:.2f`` raises. This hook runs on crew exit, so a
    raise here is a crew that cannot finish -- the reason every path in this
    module is fail-open.
    """
    cost = usage.get("estimated_cost_usd") if isinstance(usage, dict) else None
    if cost is None:
        return "unpriced"
    try:
        return f"${float(cost):.2f}"
    except (TypeError, ValueError):
        return "unpriced"


def _merge_usage(existing: dict, new: dict) -> dict:
    """Sum two usage dicts (per-model token counts + totals + cost).

    Used to accumulate usage across iterations: under MAESTRO_ITER_MANAGED each
    iteration is a separate Claude session/transcript, so the stop hook sees only
    that iteration's tokens. Without summing, the order file would only ever hold
    the LAST iteration's usage.

    FTR-MSO-2026-0871 D5 -- **the weakest basis wins across a merge.** A merge
    of a priced and an unpriced iteration is unpriced, with a cost of ``None``:
    summing only the priced iterations and labelling the result the order's
    cost is exactly the "figure wrong by an unknown margin" ADR-4 exists to
    prevent, and an accumulated record is the one the Hub and ``mso usage``
    read.
    """
    from maestro.core.fleet_usage_tracker import CostBasis, read_cost_basis, weakest_basis

    merged: dict = {"models": {}, "total_tokens": 0, "estimated_cost_usd": 0.0}
    bases = []
    reason = ""
    backend = ""
    any_unpriced = False

    for src in (existing or {}, new or {}):
        for model, m in (src.get("models") or {}).items():
            dst = merged["models"].setdefault(model, {k: 0 for k in _USAGE_MODEL_KEYS})
            for k in _USAGE_MODEL_KEYS:
                dst[k] += int(m.get(k, 0) or 0)
        merged["total_tokens"] += int(src.get("total_tokens", 0) or 0)

        src_basis, src_reason = read_cost_basis(src)
        bases.append(src_basis)
        if src_reason and not reason:
            reason = src_reason
        if isinstance(src.get("backend"), str) and src["backend"] and not backend:
            backend = src["backend"]

        src_cost = src.get("estimated_cost_usd")
        if src_basis == CostBasis.UNPRICED or src_cost is None:
            any_unpriced = True
        else:
            merged["estimated_cost_usd"] += float(src_cost or 0)

    basis = weakest_basis(bases)
    if any_unpriced:
        basis = CostBasis.UNPRICED
        merged["estimated_cost_usd"] = None
    else:
        merged["estimated_cost_usd"] = round(merged["estimated_cost_usd"], 4)

    merged["costBasis"] = basis
    merged["costBasisReason"] = reason if basis == CostBasis.UNPRICED else ""
    if backend:
        merged["backend"] = backend
    return merged


def _union_presence(prior: list, value: str) -> list:
    """Sorted unique presence list of *prior* plus *value* (blank -> "unknown").

    FTR-MSO-2026-0835. The accumulated ``<id>.json`` spans every iteration of an
    order, and an order's roleSequence means those iterations may run under
    different roles and different effort tiers. A scalar ``"role": "TST"`` there
    would be a fabricated attribution, so the file carries a LIST of what was
    seen instead — including the literal ``"unknown"`` when an iteration had no
    value, so a partially-known order cannot read as fully known.

    The list is a convenience for a human reading one file. The per-iteration
    ``<id>.jsonl`` remains the join key for any aggregation.
    """
    seen = {str(v).strip() for v in (prior or []) if str(v).strip()}
    seen.add((value or "").strip() or "unknown")
    return sorted(seen)


def save_order_usage(base_dir: Path, order_id: str, crew_number: int, usage: dict,
                     accumulate: bool = False, role: str = "", effort: str = ""):
    """Save token usage data for the order.

    accumulate=True merges into any existing record for the order (summing across
    iterations) instead of overwriting — required for the MAESTRO_ITER_MANAGED
    flow where each iteration is a distinct session/transcript.

    FTR-MSO-2026-0835: also records ``roles`` / ``efforts`` presence lists (see
    `_union_presence`), never scalars.
    """
    try:
        from maestro.workspace import resolve_artefact_dir
        mso_root = resolve_artefact_dir(base_dir)
        usage_dir = mso_root / "usage" / "orders"
        usage_dir.mkdir(parents=True, exist_ok=True)

        path = usage_dir / f"{order_id}.json"
        prior_roles: list = []
        prior_efforts: list = []
        if accumulate and path.exists():
            try:
                prior = json.loads(path.read_text(encoding="utf-8"))
                prior_roles = prior.get("roles") or []
                prior_efforts = prior.get("efforts") or []
                usage = _merge_usage(prior, usage)
            except Exception:
                pass  # corrupt/partial prior record — fall back to this iteration's usage

        record = {
            "orderId": order_id,
            "crewNumber": crew_number,
            "timestamp": datetime.now().isoformat(),
            **usage,
            "roles": _union_presence(prior_roles, role),
            "efforts": _union_presence(prior_efforts, effort),
        }
        # BUG-MSO-2026-0201: stamp voyageId so `mso usage --voyage` can filter.
        voyage_id = _resolve_voyage_id(mso_root, order_id)
        if voyage_id:
            record["voyageId"] = voyage_id

        tmp_path = path.with_suffix(".tmp")
        tmp_path.write_text(json.dumps(record, indent=2), encoding="utf-8")
        tmp_path.replace(path)
    except Exception:
        pass  # Fail-open: never block crew exit for usage tracking


def append_iteration_usage(base_dir: Path, order_id: str, crew_number: int, usage: dict,
                           role: str, iteration: int,
                           effort: str = "", effort_source: str = ""):
    """Append one per-iteration record to .mso/usage/orders/<id>.jsonl.

    Append-only write — each call adds exactly one JSON line.  The file is the
    fine-grained companion to the accumulated <id>.json; the two are kept in
    sync by save_order_usage(accumulate=True) + this function being called
    together (FTR-MSO-2026-0332).

    FTR-MSO-2026-0835: also records the reasoning-effort tier ACTUALLY APPLIED
    to this invocation (``effort``) and the layer it was resolved from
    (``effortSource``), so token spend can be grouped by (model, effort) after
    the fact.  Both keys are emitted unconditionally — ``null`` when the value
    is unknown — because an explicit null ("this fleet records effort and this
    invocation had none") is a different fact from an absent key ("recorded
    before the feature shipped").  Every reader must bucket both as *unknown*
    and neither may be substituted with a default tier.

    Fail-open: never raises; any exception is silently swallowed so crew exit
    is never blocked.
    """
    try:
        from maestro.workspace import resolve_artefact_dir
        mso_root = resolve_artefact_dir(base_dir)
        usage_dir = mso_root / "usage" / "orders"
        usage_dir.mkdir(parents=True, exist_ok=True)

        record = {
            "orderId": order_id,
            "role": role,
            "iteration": iteration,
            "crewNumber": crew_number,
            "timestamp": datetime.now().isoformat(),
            "models": usage.get("models", {}),
            "total_tokens": usage.get("total_tokens", 0),
            # FTR-MSO-2026-0871: `None` when unpriced -- carried through rather
            # than coerced to 0, so a per-iteration record cannot be read back
            # as "this iteration was free".
            "estimated_cost_usd": usage.get("estimated_cost_usd"),
            "costBasis": usage.get("costBasis", ""),
            "costBasisReason": usage.get("costBasisReason", ""),
            "backend": usage.get("backend", ""),
            # FTR-MSO-2026-0835 — explicit null, never a fabricated default.
            "effort": (effort or "").strip() or None,
            "effortSource": (effort_source or "").strip() or None,
        }

        jsonl_path = usage_dir / f"{order_id}.jsonl"
        with open(jsonl_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(record) + "\n")
    except Exception:
        pass  # Fail-open: never block crew exit for usage tracking


def build_continuation_prompt(iteration: int, max_iterations: int, order_id: str,
                              crew_number: int, completion_promise: str) -> str:
    """Build the prompt that re-feeds Claude on the next iteration."""
    return (
        f"# ITERATION {iteration}/{max_iterations} | Order: {order_id} | Crew: {crew_number}\n"
        f"\n"
        f"Your previous iteration ended. Review the files you modified and continue working.\n"
        f"\n"
        f"Check your progress in `.mso/crews/crew{crew_number}/progress.md`.\n"
        f"Review any test output or build errors from your previous work.\n"
        f"\n"
        f"Continue executing the order. Focus on what remains to be done.\n"
        f"\n"
        f"When ALL tasks are genuinely complete and verified:\n"
        f"  <promise>{completion_promise}</promise>\n"
        f"\n"
        f"If blocked and cannot proceed:\n"
        f"  <promise>BLOCKED</promise>\n"
    )


def main():
    # ===================================================================
    # STEP 1: Read hook input from stdin
    # ===================================================================
    try:
        raw_input = sys.stdin.read()
        hook_input = json.loads(raw_input) if raw_input.strip() else {}
    except Exception:
        sys.exit(0)  # Can't parse input — allow exit

    # ===================================================================
    # STEP 2: Check if this is a crew session
    # ===================================================================
    crew_number_str = os.environ.get("MAESTRO_CREW")
    if not crew_number_str:
        # Captain's interactive session — NEVER interfere
        sys.exit(0)

    try:
        crew_number = int(crew_number_str)
    except ValueError:
        sys.exit(0)

    # BUG-MSO-2026-0029: When MAESTRO_ITER_MANAGED is set, the Python for-loop
    # in crew.py owns iteration control. The stop hook must exit cleanly so it
    # doesn't try to re-feed prompts via {"decision": "block"} — that mechanism
    # fails silently on Windows with CREATE_NO_WINDOW in a DETACHED_PROCESS,
    # producing 0-byte output for every iteration after the first.
    if os.environ.get("MAESTRO_ITER_MANAGED"):
        # BUG-MSO-2026-0331: the early exit above used to skip the usage-capture
        # block at the bottom of main(), so NO crew has recorded token usage since
        # ITER_MANAGED shipped (~2026-05-14). Capture it here before exiting. Each
        # managed iteration is a separate session/transcript, so accumulate.
        try:
            order_id = os.environ.get("MAESTRO_ORDER", "UNKNOWN")
            role = os.environ.get("MAESTRO_ROLE", "")
            # FTR-MSO-2026-0835: the effort tier crew.py actually passed to the
            # CLI for this invocation (empty when it passed none).
            effort = os.environ.get("MAESTRO_APPLIED_EFFORT", "")
            effort_source = os.environ.get("MAESTRO_APPLIED_EFFORT_SOURCE", "")
            iteration_str = os.environ.get("MAESTRO_ITERATION", "")
            iteration = int(iteration_str) if iteration_str.isdigit() else 0
            cwd = hook_input.get("cwd", os.getcwd())
            from maestro.hooks import find_mso_root
            base_dir = find_mso_root(cwd)
            if base_dir is not None:
                usage = extract_usage_from_transcript(hook_input.get("transcript_path", ""))
                if usage.get("total_tokens"):
                    save_order_usage(base_dir, order_id, crew_number, usage, accumulate=True,
                                     role=role, effort=effort)
                    # FTR-MSO-2026-0332: per-iteration JSONL record (fine-grained companion
                    # to the accumulated .json total).
                    append_iteration_usage(base_dir, order_id, crew_number, usage, role,
                                           iteration, effort, effort_source)
        except Exception:
            pass  # Fail-open: never block crew exit for usage tracking
        sys.exit(0)

    order_id = os.environ.get("MAESTRO_ORDER", "UNKNOWN")
    max_iterations = int(os.environ.get("MAESTRO_MAX_ITERATIONS", "25"))
    completion_promise = os.environ.get("MAESTRO_COMPLETION_PROMISE", "COMPLETE")

    # ===================================================================
    # STEP 3: Read crew state file
    # ===================================================================
    cwd = hook_input.get("cwd", os.getcwd())
    from maestro.hooks import find_mso_root
    base_dir = find_mso_root(cwd)
    if base_dir is None:
        sys.exit(0)  # Not a Maestro workspace — no-op
    from maestro.workspace import resolve_artefact_dir
    _mso_root = resolve_artefact_dir(base_dir)
    state_file = _mso_root / "crews" / f"crew{crew_number}" / "ralph-state.md"

    if not state_file.exists():
        # No state file — crew.py didn't set up properly, allow exit
        sys.exit(0)

    frontmatter = parse_yaml_frontmatter(state_file.read_text(encoding='utf-8'))
    current_iteration = frontmatter.get("iteration", 1)
    log_entries = get_log_entries(state_file)
    now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    # ===================================================================
    # STEP 4: Check transcript for completion
    # ===================================================================
    transcript_path = hook_input.get("transcript_path", "")
    is_complete, is_blocked = check_transcript_for_promise(transcript_path, completion_promise)

    # ===================================================================
    # STEP 5: Decision logic
    # ===================================================================

    # FTR-MSO-2026-0332: role is available from the env even in the non-managed path.
    _hook_role = os.environ.get("MAESTRO_ROLE", "")
    # FTR-MSO-2026-0835: ditto the applied effort tier and its provenance.
    _hook_effort = os.environ.get("MAESTRO_APPLIED_EFFORT", "")
    _hook_effort_source = os.environ.get("MAESTRO_APPLIED_EFFORT_SOURCE", "")

    # COMPLETE — task is done
    if is_complete:
        frontmatter["status"] = "COMPLETE"
        frontmatter["last_iteration"] = now
        # v2.0.6: Extract and save token usage
        usage = extract_usage_from_transcript(transcript_path)
        save_order_usage(base_dir, order_id, crew_number, usage,
                         role=_hook_role, effort=_hook_effort)
        append_iteration_usage(base_dir, order_id, crew_number, usage, _hook_role,
                               current_iteration, _hook_effort, _hook_effort_source)
        tokens_str = f" | Tokens: {usage['total_tokens']:,} | Cost: {_format_usage_cost(usage)}" if usage["total_tokens"] else ""
        log_entries += f"\n## Iteration {current_iteration} ({now})\nDetected <promise>{completion_promise}</promise>. Task COMPLETE.{tokens_str} Allowing exit.\n"
        write_state_atomic(state_file, frontmatter, log_entries)
        sys.exit(0)

    # BLOCKED — crew is stuck
    if is_blocked:
        frontmatter["status"] = "BLOCKED"
        frontmatter["last_iteration"] = now
        # v2.0.6: Extract and save token usage even for blocked sessions
        usage = extract_usage_from_transcript(transcript_path)
        save_order_usage(base_dir, order_id, crew_number, usage,
                         role=_hook_role, effort=_hook_effort)
        append_iteration_usage(base_dir, order_id, crew_number, usage, _hook_role,
                               current_iteration, _hook_effort, _hook_effort_source)
        log_entries += f"\n## Iteration {current_iteration} ({now})\nDetected <promise>BLOCKED</promise>. Allowing exit.\n"
        write_state_atomic(state_file, frontmatter, log_entries)
        # v2.0.9: Bridge notification for BLOCKED crews (immediate, bypasses grace period)
        try:
            from maestro.core.bridge_notifier import BridgeNotifier
            notifier = BridgeNotifier(_mso_root)
            project = os.environ.get("MAESTRO_PROJECT", "?")
            notifier.notify_crew_blocked(crew_number, order_id, project)
        except Exception:
            pass  # Fail-open: never block crew exit for bridge errors
        sys.exit(0)

    # MAX ITERATIONS — hard limit reached
    if current_iteration >= max_iterations:
        frontmatter["status"] = "MAX_ITERATIONS"
        frontmatter["last_iteration"] = now
        # v2.0.6: Extract and save token usage for max iteration exits
        usage = extract_usage_from_transcript(transcript_path)
        save_order_usage(base_dir, order_id, crew_number, usage,
                         role=_hook_role, effort=_hook_effort)
        append_iteration_usage(base_dir, order_id, crew_number, usage, _hook_role,
                               current_iteration, _hook_effort, _hook_effort_source)
        log_entries += f"\n## Iteration {current_iteration} ({now})\nMax iterations ({max_iterations}) reached. Allowing exit.\n"
        write_state_atomic(state_file, frontmatter, log_entries)
        sys.exit(0)

    # NOT COMPLETE — continue with next iteration
    next_iteration = current_iteration + 1
    frontmatter["iteration"] = next_iteration
    frontmatter["status"] = "RUNNING"
    frontmatter["last_iteration"] = now
    log_entries += f"\n## Iteration {current_iteration} ({now})\nNo completion detected. Continuing to iteration {next_iteration}.\n"
    write_state_atomic(state_file, frontmatter, log_entries)

    # Build continuation prompt
    reason = build_continuation_prompt(
        next_iteration, max_iterations, order_id, crew_number, completion_promise
    )

    # Output decision to block exit and re-feed prompt
    output = {
        "decision": "block",
        "reason": reason
    }
    print(json.dumps(output))
    sys.exit(0)


if __name__ == "__main__":
    main()
