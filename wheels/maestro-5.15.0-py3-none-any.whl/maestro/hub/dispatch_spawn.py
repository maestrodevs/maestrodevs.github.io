# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""maestro/hub/dispatch_spawn.py — spawn a dispatcher and CONFIRM it came up.

BUG-MSO-2026-0923. The Hub's Dispatch button was fire-and-forget: a bare
``subprocess.Popen(cmd, stdout=DEVNULL, stderr=DEVNULL)`` followed
immediately by ``ControlResult(ok=True, message="Dispatcher starting")``,
with nothing between them that could observe the spawn failing. On
2026-09-24 the Captain's dispatcher had idle-reaped, Dispatch appeared to do
nothing, and there was no evidence of any kind to work from: the spawned
process's own diagnostics went to DEVNULL, and the Hub's log carried no
record that the request had even arrived.

This module is what sits between the two now, and the shape of the check is
dictated by one non-obvious fact about the process tree:

**The Hub's direct child is a LAUNCHER, not the dispatcher.**
``python -m maestro.cli dispatch`` runs :func:`maestro.cli.cmd_dispatch`,
which calls ``_run_detached()`` — that spawns a *further* detached process
(``died_record supervise`` -> ``fleet_runner.py``), waits up to 5s for its
handshake so it can print the real PID, and then RETURNS. The launcher
exiting is therefore the NORMAL, healthy outcome, and ``proc.poll() is not
None`` is not a failure signal. Only two things are:

* a **non-zero** launcher exit — it died before or during the spawn
  (``SystemExit`` from a missing script, an identity-capability refusal, an
  ``OSError`` on ``sys.executable``), so no dispatcher exists; and
* **no dispatcher registering itself** on the artefact plane within the
  grace window, which is the only way to see a failure of the GRANDCHILD —
  including ``run_dispatcher()``'s own refusals (a duplicate
  ``dispatcher.pid``, a held demo lock), which ``return`` and so exit
  **zero** while starting nothing.

The confirmation signal is deliberately the same one ``mso status`` and the
Hub dashboard read — :func:`maestro.hub.aggregator._dispatcher_state` over
``dispatcher.pid`` + the lifecycle heartbeat — so a Dispatch click that
reports success cannot disagree with the dashboard it refreshes into.

Three outcomes, and the third one is the reason this file has a docstring
this long:

``confirmed``       a dispatcher is live on the plane. ``ok=True``.
``launcher-failed`` the launcher exited non-zero, or ``Popen`` itself raised.
                    ``ok=False``, naming the exit code and the captured
                    output. This is a DEFINITE failure.
``unconfirmed``     the launcher exited cleanly (or is still running) but no
                    dispatcher appeared within the grace window. ``ok=False``.

``unconfirmed`` is reported as a failure even though it is strictly an
absence of evidence, and that is a deliberate choice rather than an
oversight: this whole order exists because the Hub answered "starting" and
the operator had no way to tell that nothing had started. A wrong
``ok=False`` costs a re-read of the dashboard, which the caller refreshes
anyway; a wrong ``ok=True`` costs what it cost on 2026-09-24. So the
message for this verdict never claims the dispatcher failed — it says
exactly what was checked, for how long, and where to look, and it says that
a slow machine may still be coming up.

Output capture is bounded and honest about its reach: the launcher's
combined stdout+stderr is appended to ``<mso>/logs/hub-dispatch-spawn.log``
(rotated, gitignored, on the artefact plane like every other dispatcher
log). The GRANDCHILD's output is not ours to capture — ``_run_detached``
DEVNULLs it on its way past — so the failure messages point at
``logs/lifecycle.log`` as well, which is where ``run_dispatcher``'s own
refusals land as ``ERROR`` events.
"""

from __future__ import annotations

import os
import subprocess
import sys
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, IO, Optional

#: Wall-clock ceiling on the post-spawn confirmation wait. Sized from the real
#: startup path, not picked round: the launcher alone can take ~5-7s (its
#: ``await_child_pid`` handshake is bounded at 5s), and the grandchild then
#: has to import ``fleet_runner`` before it writes ``dispatcher.pid``. A
#: confirmed start returns as soon as the plane says so — typically well
#: inside this — so the full window is only ever paid by a start that is
#: already going wrong.
DEFAULT_GRACE_SECONDS = 20.0

#: Overrides :data:`DEFAULT_GRACE_SECONDS` for an operator on a slow host (or
#: a test that wants the window closed fast). A malformed or non-positive
#: value falls back to the default rather than disabling the check — the one
#: outcome this module exists to prevent.
GRACE_ENV_VAR = "MAESTRO_HUB_DISPATCH_GRACE_SECONDS"

#: How often the plane is re-read while waiting. Two file stats per poll.
POLL_INTERVAL_SECONDS = 0.25

SPAWN_LOG_NAME = "hub-dispatch-spawn.log"

#: 512 KiB then rotate (one backup). Each spawn writes a header plus whatever
#: the launcher printed — kilobytes at worst — so this holds a long history of
#: Dispatch clicks while never becoming a disk problem.
SPAWN_LOG_MAX_BYTES = 512 * 1024
SPAWN_LOG_BACKUPS = 1

#: Lines of captured launcher output quoted inline in a failure message. The
#: full text is always in the log file the message names.
LOG_EXCERPT_LINES = 12

VERDICT_CONFIRMED = "confirmed"
VERDICT_LAUNCHER_FAILED = "launcher-failed"
VERDICT_UNCONFIRMED = "unconfirmed"


@dataclass(frozen=True)
class SpawnOutcome:
    """What a spawn attempt actually achieved.

    ``ok`` is the caller's verdict (``ControlResult.ok``); ``verdict`` is the
    machine-readable reason, one of the three ``VERDICT_*`` constants above.
    Everything else is evidence, and every field is allowed to be ``None``
    when it genuinely is not known — a fabricated PID or exit code would be
    worse than an absent one.
    """

    ok: bool
    verdict: str
    message: str
    log_path: Optional[Path] = None
    dispatcher_pid: Optional[int] = None
    launcher_pid: Optional[int] = None
    launcher_exit_code: Optional[int] = None
    waited_seconds: float = 0.0

    @property
    def confirmed(self) -> bool:
        return self.verdict == VERDICT_CONFIRMED


# ---------------------------------------------------------------------------
# Grace window
# ---------------------------------------------------------------------------

def resolve_grace_seconds(default: float = DEFAULT_GRACE_SECONDS) -> float:
    """The confirmation window, honouring :data:`GRACE_ENV_VAR`."""
    raw = os.environ.get(GRACE_ENV_VAR, "").strip()
    if not raw:
        return default
    try:
        value = float(raw)
    except (TypeError, ValueError):
        return default
    return value if value > 0 else default


# ---------------------------------------------------------------------------
# The spawn log
# ---------------------------------------------------------------------------

def spawn_log_path(mso: Path) -> Path:
    """``<mso>/logs/hub-dispatch-spawn.log`` — beside ``lifecycle.log``.

    On the artefact plane rather than under the Maestro home because a
    dispatcher start is a per-WORKSPACE event: an operator triaging one
    fleet's failed Dispatch should find it next to that fleet's other
    dispatcher evidence, not interleaved with every other workspace's in
    ``hub.log``.
    """
    return Path(mso) / "logs" / SPAWN_LOG_NAME


def _rotate_spawn_log(path: Path) -> None:
    """Roll the log at :data:`SPAWN_LOG_MAX_BYTES`. Never raises — losing a
    rotation means the file keeps growing, which beats refusing to dispatch."""
    from maestro.hub import logs as hub_logs

    try:
        hub_logs.rotate_if_needed(
            path, max_bytes=SPAWN_LOG_MAX_BYTES, backups=SPAWN_LOG_BACKUPS,
        )
    except Exception:  # noqa: BLE001 — best-effort by contract
        pass


def open_spawn_log(mso: Path, cmd: "list[str]", cwd: str) -> "tuple[Optional[IO[bytes]], Optional[Path], int]":
    """``(handle, path, offset)`` for the spawned launcher's stdout/stderr.

    Binary append, and the handle is inherited by the detached child, so its
    writes land even when it dies without flushing anything Python-level —
    the same reasoning as :func:`maestro.hub.logs.open_log_for_append`.

    ``offset`` is the file size *before* this spawn's header, so a later
    excerpt can quote only what THIS attempt printed rather than the previous
    click's output.

    Returns ``(None, None, 0)`` when the log cannot be opened at all. A
    workspace whose ``logs/`` is unwritable still gets dispatched — losing the
    capture is a reason to say so in the message, never a reason to refuse.
    Every failure counts, not just ``OSError``: an unusable artefact path
    raises ``ValueError`` from ``mkdir`` rather than ``OSError``, and letting
    that escape would turn a missing LOG into a failed DISPATCH — the
    opposite of this function's contract.
    """
    try:
        path = spawn_log_path(mso)
        path.parent.mkdir(parents=True, exist_ok=True)
        _rotate_spawn_log(path)
        offset = path.stat().st_size if path.exists() else 0
        handle = open(path, "ab")
    except Exception:  # noqa: BLE001 — see the contract above
        return None, None, 0
    header = (
        "\n=== [{}] Hub dispatch spawn ===\n"
        "cwd={}\nexecutable={}\nMAESTRO_DIR={}\ncmd={}\n"
    ).format(
        datetime.now(timezone.utc).isoformat(),
        cwd,
        sys.executable,
        str(mso),
        " ".join(cmd),
    )
    try:
        handle.write(header.encode("utf-8", errors="replace"))
        handle.flush()
    except OSError:
        pass
    return handle, path, offset


def read_log_excerpt(
    path: Optional[Path], offset: int = 0, lines: int = LOG_EXCERPT_LINES,
) -> str:
    """The last *lines* non-empty lines written after *offset*, oldest first.

    ``""`` for a missing/unreadable/silent log — "the launcher printed
    nothing" is reported as emptiness by every caller, never as a fabricated
    line (the :func:`maestro.hub.logs.tail` rule).
    """
    if path is None:
        return ""
    try:
        with open(path, "rb") as fh:
            fh.seek(max(0, int(offset)))
            raw = fh.read()
    except OSError:
        return ""
    text = raw.decode("utf-8", errors="replace")
    kept = [
        ln.rstrip()
        for ln in text.splitlines()
        if ln.strip() and not ln.startswith(("=== [", "cwd=", "executable=", "MAESTRO_DIR=", "cmd="))
    ]
    if lines <= 0 or not kept:
        return ""
    return "\n".join(kept[-lines:])


# ---------------------------------------------------------------------------
# Liveness on the artefact plane
# ---------------------------------------------------------------------------

def dispatcher_live(mso: Path) -> bool:
    """Is a dispatcher live for this workspace, per the artefact plane?

    Delegates to ``aggregator._dispatcher_running`` — the SAME verdict the
    dashboard, ``mso status`` and the duplicate-spawn guard in the dispatch
    endpoint read — so a confirmation here can never disagree with the view
    the operator refreshes into. Container-safe (heartbeat fallback for a
    host PID invisible in the Hub's PID namespace, BUG-MSO-2026-0405), and a
    WEDGED dispatcher reads False (BUG-MSO-2026-0541).
    """
    try:
        from maestro.hub import aggregator

        return bool(aggregator._dispatcher_running(Path(mso)))
    except Exception:  # noqa: BLE001 — an unreadable plane is "not confirmed"
        return False


def read_dispatcher_pid(mso: Path) -> Optional[int]:
    """The PID in ``dispatcher.pid``, or ``None`` when it cannot be read.

    Reported for the operator's benefit only; liveness is never inferred from
    it here (:func:`dispatcher_live` owns that, PID namespace and all).
    """
    try:
        raw = (Path(mso) / "dispatcher.pid").read_text(encoding="utf-8").strip()
        return int(raw)
    except (OSError, ValueError):
        return None


# ---------------------------------------------------------------------------
# The spawn
# ---------------------------------------------------------------------------

def build_command(dispatch_argv: "list[str]") -> "list[str]":
    return [sys.executable, "-m", "maestro.cli", "dispatch", *list(dispatch_argv)]


def popen_kwargs(product_repo, env: dict, log_handle: Optional[IO[bytes]]) -> dict:
    """The detached-launch kwargs, with stdout/stderr wired to *log_handle*.

    ``close_fds=True`` and an explicit ``stdout``/``stderr`` are not in
    conflict: the standard handles are always passed to the child (on Windows
    via ``STARTUPINFO``), so the launcher's output still reaches the log.
    A ``None`` handle falls back to ``DEVNULL`` — the pre-BUG-0923 behaviour,
    reached only when the log could not be opened at all.
    """
    sink = log_handle if log_handle is not None else subprocess.DEVNULL
    kwargs = dict(
        cwd=str(product_repo),
        env=env,
        stdin=subprocess.DEVNULL,
        stdout=sink,
        stderr=subprocess.STDOUT if log_handle is not None else subprocess.DEVNULL,
    )
    if os.name == "nt":
        DETACHED_PROCESS = 0x00000008
        CREATE_NEW_PROCESS_GROUP = 0x00000200
        kwargs["creationflags"] = DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
        kwargs["close_fds"] = True
    else:
        kwargs["start_new_session"] = True
    return kwargs


def _describe_exit(code: Optional[int]) -> str:
    return "still running" if code is None else "exit code {}".format(code)


def _with_excerpt(message: str, path: Optional[Path], excerpt: str) -> str:
    """Append the log path FIRST, then the excerpt.

    Ordering copied from BUG-MSO-2026-0506's ``VERIFY_FAILED`` line for the
    same reason: the path is the durable artefact, so it must survive any
    truncation an intermediate surface applies to a long message.
    """
    if path is not None:
        message += "\nSpawn log: {}".format(path)
    if excerpt:
        message += "\nLauncher output:\n{}".format(excerpt)
    return message


def spawn_dispatcher(
    mso,
    product_repo,
    dispatch_argv: "list[str]",
    *,
    grace_seconds: Optional[float] = None,
    popen: Optional[Callable] = None,
    live_check: Optional[Callable[[Path], bool]] = None,
    sleep: Callable[[float], None] = time.sleep,
    monotonic: Callable[[], float] = time.monotonic,
) -> SpawnOutcome:
    """Launch ``mso dispatch <dispatch_argv>`` detached, then confirm it.

    Blocking by design — bounded by *grace_seconds*, and returning the
    moment the plane confirms a live dispatcher. Callers serving an async
    request MUST run it off the event loop (``run_in_threadpool``), because
    the Hub serves every other workspace from that same loop.

    ``popen`` / ``live_check`` / ``sleep`` / ``monotonic`` are injected so the
    three verdicts can be exercised without a real process tree; production
    callers pass none of them.
    """
    mso = Path(mso)
    popen = popen or subprocess.Popen
    live_check = live_check or dispatcher_live
    grace = resolve_grace_seconds() if grace_seconds is None else float(grace_seconds)

    env = {**os.environ, "MAESTRO_DIR": str(mso)}
    cmd = build_command(dispatch_argv)
    handle, log_path, offset = open_spawn_log(mso, cmd, str(product_repo))
    try:
        try:
            proc = popen(cmd, **popen_kwargs(product_repo, env, handle))
        except OSError as exc:
            # The `sys.executable`-inside-a-long-running-daemon class of
            # failure the order names: the Hub could not even start the
            # process. Pre-0923 this raised out of the endpoint as a 500 with
            # no record of which command was attempted; the header written
            # above now names it, and so does this message.
            message = (
                "Dispatcher NOT started — the Hub could not launch the "
                "dispatch command: {}: {}\nCommand: {}\nWorking directory: {}"
            ).format(type(exc).__name__, exc, " ".join(cmd), product_repo)
            return SpawnOutcome(
                ok=False, verdict=VERDICT_LAUNCHER_FAILED,
                message=_with_excerpt(message, log_path, ""),
                log_path=log_path,
            )

        started = monotonic()
        launcher_pid = getattr(proc, "pid", None)
        if not isinstance(launcher_pid, int):
            launcher_pid = None
        exit_code: Optional[int] = None

        while True:
            if live_check(mso):
                waited = monotonic() - started
                pid = read_dispatcher_pid(mso)
                return SpawnOutcome(
                    ok=True, verdict=VERDICT_CONFIRMED,
                    message="Dispatcher started and confirmed live{} after {:.1f}s".format(
                        " (PID {})".format(pid) if pid else "", waited,
                    ),
                    log_path=log_path, dispatcher_pid=pid,
                    launcher_pid=launcher_pid, launcher_exit_code=exit_code,
                    waited_seconds=waited,
                )

            if exit_code is None:
                try:
                    polled = proc.poll()
                except Exception:  # noqa: BLE001 — an unpollable handle is not a verdict
                    polled = None
                # ``Popen.poll()`` returns ``None`` or an int. Anything else is
                # an UNUSABLE answer, not an exit: it is treated as "still
                # running" so the verdict falls through to the liveness check,
                # which rests on evidence. The BUG-MSO-2026-0698 /
                # BUG-MSO-2026-0707 rule, in the other direction — an
                # indeterminate read may cost a re-check, never fabricate a
                # failure the plane does not support.
                exit_code = polled if isinstance(polled, int) else None
                # A ZERO exit is the healthy launcher handing off to its
                # detached grandchild (see the module docstring) — keep
                # waiting for the dispatcher itself. Only a non-zero exit is
                # proof that nothing was started.
                if exit_code is not None and exit_code != 0:
                    waited = monotonic() - started
                    message = (
                        "Dispatcher NOT started — the dispatch command exited "
                        "with code {} after {:.1f}s (it normally exits 0 having "
                        "handed off to the detached dispatcher).".format(exit_code, waited)
                    )
                    return SpawnOutcome(
                        ok=False, verdict=VERDICT_LAUNCHER_FAILED,
                        message=_with_excerpt(
                            message, log_path, read_log_excerpt(log_path, offset)),
                        log_path=log_path, launcher_pid=launcher_pid,
                        launcher_exit_code=exit_code, waited_seconds=waited,
                    )

            if monotonic() - started >= grace:
                break
            sleep(POLL_INTERVAL_SECONDS)

        waited = monotonic() - started
        message = (
            "Dispatcher start NOT CONFIRMED — the dispatch command was launched "
            "({}) but no live dispatcher appeared within {:.0f}s. Checked {} and "
            "the lifecycle heartbeat. A slow host may still be starting up: "
            "refresh, and if the fleet is still stopped read the spawn log below "
            "and {} (a dispatcher that refused to start — a duplicate "
            "dispatcher.pid, a held demo lock — records an ERROR event there and "
            "exits 0)."
        ).format(
            _describe_exit(exit_code), grace,
            mso / "dispatcher.pid", mso / "logs" / "lifecycle.log",
        )
        return SpawnOutcome(
            ok=False, verdict=VERDICT_UNCONFIRMED,
            message=_with_excerpt(message, log_path, read_log_excerpt(log_path, offset)),
            log_path=log_path, launcher_pid=launcher_pid,
            launcher_exit_code=exit_code, waited_seconds=waited,
        )
    finally:
        if handle is not None:
            try:
                handle.close()
            except OSError:
                pass
