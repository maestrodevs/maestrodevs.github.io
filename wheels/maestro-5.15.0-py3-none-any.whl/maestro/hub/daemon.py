# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Hub daemon PID management (mirrors maestro/bridge.py pattern exactly).

The hub is a GLOBAL daemon (not per-workspace) — PID file at ~/.maestro/hub.pid.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import time
import webbrowser
from datetime import datetime, timezone
from pathlib import Path

# FTR-MSO-2026-0536 promoted this to maestro/proc_identity.py so the LEAD
# daemon and the Hub daemon share ONE identity implementation. Imported
# under the original private name so existing tests that monkeypatch
# `daemon._process_create_time` keep working unchanged.
from maestro.proc_identity import (
    process_create_time as _process_create_time,
    read_identity_record as _read_record,
    read_record_dict as _read_record_dict,
    write_identity_record as _write_record,
)
from typing import Optional, Tuple

from maestro.hub import logs as _logs
from maestro.launch.sandbox import spawn as _spawn
from maestro.workspace import get_maestro_home

DEFAULT_PORT = 3847


def _hub_pid_file() -> Path:
    """Global Hub PID file, resolved live so MAESTRO_HOME redirects it
    (BUG-MSO-2026-0387). Default ``~/.maestro/hub.pid``."""
    return get_maestro_home() / "hub.pid"


# ---------------------------------------------------------------------------
# Process-identity helpers (BUG-MSO-2026-0424)
#
# A bare PID is NOT a stable process identity — operating systems recycle PIDs,
# so after the hub dies uncleanly the recorded number can be reassigned to
# unrelated software. We therefore record the process CREATION TIME alongside
# the PID and treat a record as "our hub" only when a process with that PID
# exists AND its creation time matches. A recycled PID always has a later start
# time, so the check is decisive and needs no third-party dependency.
# ---------------------------------------------------------------------------

def _read_pid(pid_file: Path) -> Optional[int]:
    """Backwards-compatible PID accessor (identity NOT verified)."""
    rec = _read_record(pid_file)
    return rec[0] if rec else None


def _is_process_alive(pid: int) -> bool:
    """Bare liveness — does SOME process hold *pid*? Kept for callers that only
    need existence; the hub lifecycle uses :func:`_is_hub_running` instead,
    which also verifies process identity."""
    return _process_create_time(pid) is not None


def _is_hub_running(pid_file: Path) -> Tuple[bool, Optional[int]]:
    """Identity-verified hub liveness.

    Returns ``(running, pid)``. ``running`` is ``True`` only when the recorded
    PID belongs to a live process whose creation time matches the recorded
    identity. A recycled PID (same number, different — later — process) or a
    legacy record with no recorded identity is classified as NOT running, so no
    termination signal is ever sent to an unrelated process.
    """
    rec = _read_record(pid_file)
    if rec is None:
        return (False, None)
    pid, recorded_ct = rec
    if not pid or pid <= 0 or recorded_ct is None:
        return (False, pid or None)
    current_ct = _process_create_time(pid)
    if current_ct is None or current_ct != recorded_ct:
        return (False, pid)
    return (True, pid)


# ---------------------------------------------------------------------------
# Dep check
# ---------------------------------------------------------------------------

def _ensure_hub_deps() -> None:
    try:
        import fastapi  # noqa: F401
        import uvicorn  # noqa: F401
    except ImportError:
        print(
            "[Hub] FastAPI/uvicorn not installed.\n"
            "      Install the hub extra:  pip install 'maestro-fleet[hub]'",
            file=sys.stderr,
        )
        sys.exit(1)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def _hub_entry_point() -> Path:
    """Absolute path to ``maestro/hub/__main__.py`` (BUG-MSO-2026-0516).

    ``python -m maestro.hub`` puts the SUBPROCESS'S OWN cwd at ``sys.path[0]``.
    Since the single most likely place an operator runs ``mso hub start`` from
    is a Maestro source checkout, that checkout's own (bundle-less) ``maestro/``
    package silently shadows the installed wheel — the daemon comes up
    correctly, but serving from the wrong package tree, with no built UI
    bundle to mount, so it degrades to the API-only payload while looking
    identical to the real thing.

    Launching by this RESOLVED FILE PATH instead sidesteps the trap entirely:
    running ``python <script>.py`` puts the script's own directory at
    ``sys.path[0]``, never the cwd. Because that directory is derived from
    ``__file__`` of THIS already-imported module — the same import that
    resolved the currently-running ``mso`` process's own ``maestro`` package —
    the spawned daemon is guaranteed to import that exact same package,
    regardless of what the operator's cwd happens to be. This makes cwd
    irrelevant to package resolution rather than merely picking a "safer" cwd
    (a plain ``cwd=`` override would still leave any *other* cwd-sensitive
    code path — see the sibling BUG-MSO-2026-0515 — exposed).
    """
    return Path(__file__).resolve().parent / "__main__.py"


def _child_env_pinned_to_this_package(base_env: Optional[dict] = None) -> dict:
    """Child environment with THIS process's ``maestro`` package parent
    prepended to ``PYTHONPATH``.

    BUG-MSO-2026-0712 found that :func:`_hub_entry_point`'s guarantee — "the
    spawned daemon is guaranteed to import that exact same package" — did not
    actually hold. Launching by file path puts ``maestro/hub/`` on the child's
    ``sys.path[0]``, which correctly stops the CWD from shadowing anything but
    does NOT make ``import maestro`` resolve to the parent's tree: the child
    falls through to whatever is installed in site-packages. Parent and child
    therefore ran DIFFERENT Maestro versions whenever the two differed (a
    source checkout, a repo-relative import, a stale install), and the child
    won silently.

    This was latent until this order added ``maestro.hub.logs``: a child
    resolving an older installed package died at import with
    ``ImportError: cannot import name 'logs'`` — and, before this same order,
    with its stderr going to ``DEVNULL``, so ``mso hub start`` printed
    "Started ... (PID N)" for a process that was already gone. Pinning the
    path makes the docstring's claim true by construction rather than by
    hope; when parent and child would have agreed anyway (an ordinary wheel
    install) it prepends the directory the child was going to use regardless,
    and changes nothing.
    """
    env = dict(base_env if base_env is not None else os.environ)
    try:
        import maestro
        package_parent = str(Path(maestro.__file__).resolve().parent.parent)
    except Exception:  # noqa: BLE001 — an unpinnable parent is not a reason to refuse to start
        return env
    existing = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = (
        package_parent + os.pathsep + existing if existing else package_parent
    )
    return env


def start_hub(port: int = DEFAULT_PORT, open_browser: bool = False, force: bool = False) -> None:
    hub_pid = _hub_pid_file()
    running, existing_pid = _is_hub_running(hub_pid)
    if running and not force:
        # BUG-MSO-2026-0751: a live PID is not a serving Hub. Saying "Already
        # running" about a process whose listener died sends the operator to a
        # dashboard that refuses the connection.
        serving_port = recorded_port(default=port)
        if not port_answers(serving_port):
            # A Hub that has not answered YET is not a Hub whose listener
            # died. Two cases produce a miss on a healthy Hub, and neither may
            # be told to kill it (PR #424 code review):
            #  * it is still starting (`mso hub start` run twice in quick
            #    succession) - judged from the PID record's own startedAt;
            #  * it is busy and answered slowly - given one longer retry.
            age = _record_age_seconds()
            if age is not None and age < HUB_STARTUP_GRACE_SECONDS:
                print(f"[Hub] PID {existing_pid} started {int(age)}s ago and is not answering on "
                      f"port {serving_port} yet — it is still starting. Not starting a second Hub; "
                      "check again with:  mso hub status", file=sys.stderr)
                return
            if not port_answers(serving_port, timeout=PORT_PROBE_RETRY_TIMEOUT_SECONDS):
                print(f"[Hub] PID {existing_pid} is alive but NOT SERVING on port {serving_port} — "
                      "its listener died. Not starting a second Hub over it.", file=sys.stderr)
                print("[Hub]   Recover with:  mso hub stop && mso hub start", file=sys.stderr)
                return
        print(f"[Hub] Already running (PID: {existing_pid}) on http://127.0.0.1:{serving_port}")
        if open_browser:
            webbrowser.open(f"http://127.0.0.1:{serving_port}")
        return
    if not running and hub_pid.exists():
        # Stale / recycled-PID / legacy record — clear it and start clean.
        # NB: no signal is ever sent here; the old PID may now belong to
        # unrelated software (BUG-MSO-2026-0424).
        #
        # BUG-MSO-2026-0724 (parity with maestro/lead/daemon.py:start): say so.
        # A surviving record next to a dead PID is the CRASH signal
        # BUG-MSO-2026-0712 added `death_evidence()` for; clearing it silently
        # here destroys the only evidence that the last Hub died rather than
        # being stopped.
        print(f"[Hub] Clearing stale PID record (PID {existing_pid} is not this Hub "
              "— dead, recycled, or a different process); no signal sent.")
        hub_pid.unlink()

    _ensure_hub_deps()

    cmd = [sys.executable, str(_hub_entry_point()), "--port", str(port)]
    hub_pid.parent.mkdir(parents=True, exist_ok=True)

    # BUG-MSO-2026-0712: the child's stdout+stderr go to ~/.maestro/logs/hub.log,
    # never DEVNULL. Rotation is checked HERE, at the one moment no live daemon
    # holds the file open (Windows cannot rename an open file) — see
    # maestro/hub/logs.py's module docstring. Any previous run's exit record is
    # cleared first so a later `mso hub status` can never attribute an OLD death
    # to the run starting now.
    _logs.clear_exit_record()
    log_path = _logs.hub_log_path()
    try:
        log_handle = _logs.open_log_for_append()
    except OSError as exc:
        # A log we cannot open is a reason to say so, not a reason to refuse
        # to start — the Hub being up matters more than its log, and the
        # pre-0712 behaviour was no log at all.
        print(f"[Hub] WARNING: could not open {log_path} ({exc}) — starting without capture",
              file=sys.stderr)
        log_handle = None

    stream = log_handle if log_handle is not None else subprocess.DEVNULL
    child_env = _child_env_pinned_to_this_package()

    # BUG-MSO-2026-0713: run the Hub under the shared supervisor wrapper.
    # BUG-MSO-2026-0712 already routes the child's output to hub.log and writes
    # an exit record when the daemon observes its own exit — but its own
    # docstring names the residual gap: "``exitCode`` ... present only when the
    # daemon observed its own exit. ``None`` is the honest answer for a
    # ``taskkill /F``". The 2026-09-09 Hub death was exactly that case. Only a
    # separate process waiting on the child can supply an exit code for a kill
    # that runs no code inside the victim, so the wrapper closes the half 0712
    # structurally could not.
    #
    # As on the dispatcher side, the wrapper never becomes the Hub's identity:
    # hub.pid is written below from the CHILD's pid via the handshake, so
    # _is_hub_running(), `mso hub status` and every reader keep naming the real
    # daemon.
    supervised = False
    handshake = None
    launch_cmd = cmd
    try:
        from maestro.core import died_record
        state_dir = get_maestro_home()
        handshake = state_dir / "hub.supervisor.json"
        try:
            handshake.unlink()
        except OSError:
            pass
        launch_cmd = [
            # By resolved FILE path, never `-m` (BUG-MSO-2026-0516): `-m` puts the
            # cwd first on sys.path, so a source checkout would shadow the wheel.
            sys.executable, str(Path(died_record.__file__).resolve()), "supervise",
            "--kind", "hub",
            "--workspace", str(state_dir),
            "--handshake", str(handshake),
            # BUG-MSO-2026-0751: the supervisor also watches the Hub keeps
            # SERVING this port, so a process whose listener died is recorded
            # and ended instead of living on as a zombie.
            "--probe-port", str(port),
            "--",
        ] + cmd
        supervised = True
    except Exception:
        supervised = False
        handshake = None
        launch_cmd = cmd
    cmd = launch_cmd

    try:
        if os.name == "nt":
            DETACHED_PROCESS = 0x00000008
            CREATE_NEW_PROCESS_GROUP = 0x00000200
            flags = DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
            proc = _spawn(
                cmd,
                identity="hub",
                env=child_env,
                creationflags=flags,
                stdout=stream,
                stderr=subprocess.STDOUT if log_handle is not None else subprocess.DEVNULL,
            )
        else:
            proc = _spawn(
                cmd,
                identity="hub",
                env=child_env,
                start_new_session=True,
                stdout=stream,
                stderr=subprocess.STDOUT if log_handle is not None else subprocess.DEVNULL,
            )
    finally:
        # The child inherited its own duplicate of the handle; this parent's
        # copy must not be held open, or a later rotation could not rename the
        # file on Windows even after the daemon has gone.
        if log_handle is not None:
            try:
                log_handle.close()
            except OSError:
                pass

    # BUG-MSO-2026-0713: under the supervisor, proc.pid is the WRAPPER's. The
    # PID record must name the Hub itself or every liveness check drifts, so
    # resolve the child's pid from the handshake. A handshake that never appears
    # means the wrapper failed to start the child — fall back to the record we
    # would have written before, which is no worse than the pre-0713 behaviour.
    daemon_pid = proc.pid
    if supervised and handshake is not None:
        try:
            from maestro.core import died_record
            resolved = died_record.await_child_pid(handshake, timeout_seconds=5.0)
        except Exception:
            resolved = None
        if resolved:
            daemon_pid = resolved

    _write_record(
        hub_pid,
        daemon_pid,
        _process_create_time(daemon_pid),
        extra={
            "port": port,
            "startedAt": datetime.now(timezone.utc).isoformat(),
            "logPath": str(log_path),
            "supervisorPid": proc.pid if supervised and daemon_pid != proc.pid else None,
        },
    )
    print(f"[Hub] Started on http://127.0.0.1:{port} (PID {daemon_pid})")
    print(f"[Hub] Log: {log_path}")
    if open_browser:
        webbrowser.open(f"http://127.0.0.1:{port}")


def stop_hub(*, timeout: float = 10.0, poll_interval: float = 0.5) -> bool:
    """Stop the Hub daemon and BLOCK until it has actually exited.

    BUG-MSO-2026-0516: the previous implementation printed "Stop signal sent"
    on the strength of having SENT a signal — never confirming the process
    actually died — so ``mso hub stop`` could report success while the daemon
    (and its hold on the port) lived on. This version waits for the
    identity-verified record to go not-running, escalates to a force-kill if
    the graceful signal doesn't land within ``timeout`` seconds, and returns
    ``False`` (with a truthful failure message) if the process still could not
    be stopped — "signal sent" is never printed as though it meant "stopped".

    Returns ``True`` once the daemon is confirmed gone (or was never running).
    """
    hub_pid = _hub_pid_file()
    running, pid = _is_hub_running(hub_pid)
    if not running:
        # Not our hub (dead, recycled PID, or legacy record). Send NO signal —
        # the recorded PID may now belong to unrelated software
        # (BUG-MSO-2026-0424) — and always clear the stale record.
        print("[Hub] Not running")
        if hub_pid.exists():
            # BUG-MSO-2026-0712: this record surviving next to a dead PID means
            # the hub CRASHED. Clearing it here is correct (the operator asked
            # to stop), but doing so silently would destroy the only signal
            # that says so — say what happened before the evidence goes.
            ev = death_evidence(tail_lines=3)
            print(f"[Hub]   (PID {ev.get('pid')} had crashed — died {ev.get('diedAt')}"
                  f", exit {ev.get('exitCode') if ev.get('exitCode') is not None else 'not recorded'})")
            print(f"[Hub]   Log: {ev.get('logPath')}")
            hub_pid.unlink()
        return True

    def _signal(force: bool) -> None:
        try:
            if os.name == "nt":
                cmd = ["taskkill", "/PID", str(pid)]
                if force:
                    cmd.append("/F")
                subprocess.run(cmd, capture_output=True, timeout=10)
            else:
                os.kill(pid, 9 if force else 15)  # SIGKILL : SIGTERM
        except Exception as exc:
            kind = "force-kill" if force else "stop"
            print(f"[Hub] Failed to send {kind} signal: {exc}", file=sys.stderr)

    def _wait_for_exit(budget_seconds: float) -> bool:
        iterations = max(1, int(budget_seconds / poll_interval))
        for _ in range(iterations):
            if not _is_hub_running(hub_pid)[0]:
                return True
            time.sleep(poll_interval)
        return not _is_hub_running(hub_pid)[0]

    def _confirm_stopped(note: str = "") -> bool:
        if hub_pid.exists():
            hub_pid.unlink()
        print(f"[Hub] Stopped (PID: {pid}){note}")
        return True

    _signal(force=False)
    if _wait_for_exit(timeout):
        return _confirm_stopped()

    print(
        f"[Hub] PID {pid} still running after {timeout:.0f}s — escalating to force-kill",
        file=sys.stderr,
    )
    _signal(force=True)
    if _wait_for_exit(5.0):
        return _confirm_stopped(", required force-kill")

    print(
        f"[Hub] Failed to stop (PID: {pid} still running after stop signal + force-kill)",
        file=sys.stderr,
    )
    return False


def _installed_version() -> Optional[str]:
    """This reader's own fresh import — used ONLY as a fallback when the
    live Hub process can't be reached to ask it about itself (see
    ``hub_status`` below). Mirrors ``maestro.lead.daemon._installed_version``.
    """
    try:
        import maestro
        return getattr(maestro, "__version__", None)
    except Exception:
        return None


def _fetch_health(port: int, timeout: float = 2.0) -> Optional[dict]:
    """Best-effort GET of the running Hub's own /api/v1/health.

    BUG-MSO-2026-0627: `/api/v1/health` is exempt from the bearer-token gate
    (see `hub/server.py`'s auth guard — `/health` and `/ping` stay open for
    liveness probes), so no token handling is needed here. The health
    response already carries `version` (this process's pinned code version)
    and `installedVersion`/`versionMismatch` (a live self-check computed
    fresh on every call via `importlib.metadata`, so it reflects a `pip
    install --upgrade` done after this daemon started, without needing a
    restart) — `hub_status()` below just relays what the live process
    already knows about itself. Returns ``None`` on any failure (backend not
    responding on this port, connection refused, timeout, bad JSON): a
    version-unknown Hub is reported honestly, never guessed.
    """
    import json as _json
    import urllib.request

    try:
        with urllib.request.urlopen(
            f"http://127.0.0.1:{port}/api/v1/health", timeout=timeout
        ) as resp:
            return _json.loads(resp.read().decode("utf-8"))
    except Exception:
        return None


def recorded_port(default: int = DEFAULT_PORT) -> int:
    """The port the CURRENT PID record was started on, falling back to
    *default*.

    BUG-MSO-2026-0712: a reader that assumes ``DEFAULT_PORT`` reports a Hub
    started with ``--port 4000`` as unreachable — a false alarm that would
    make the new ``hub.alive`` patrol check worse than no check at all. The
    port is written into the PID record at start (one file, no second piece
    of state to fall out of sync), so a record written by an older Maestro
    simply has no ``port`` key and degrades to *default* exactly as before.
    """
    record = _read_record_dict(_hub_pid_file()) or {}
    value = record.get("port")
    try:
        return int(value) if value is not None else default
    except (TypeError, ValueError):
        return default


def death_evidence(*, tail_lines: int = 5) -> dict:
    """Everything knowable about a Hub that is no longer running.

    Deliberately assembled from THREE independent sources, because no single
    one covers every way a daemon dies (BUG-MSO-2026-0712):

    * ``startedAt`` / ``pid`` — the PID record the last ``mso hub start``
      wrote. Left in place by a crash; only a clean ``mso hub stop`` removes
      it, so its presence next to a dead PID IS the crash signal.
    * ``diedAt`` — the exit record's own timestamp when the daemon managed
      to write one, otherwise the PID file's mtime. ``diedAtSource`` says
      which, because the second is only ever an upper bound ("no later
      than"), never the moment of death — a hard kill leaves the mtime at
      the START time, and reporting that as the death time would be a
      fabrication.
    * ``exitCode`` / ``error`` / ``traceback`` — present only when the
      daemon observed its own exit. ``None`` is the honest answer for a
      ``taskkill /F``, a console-session teardown or an OOM.
    """
    pid_file = _hub_pid_file()
    record = _read_record_dict(pid_file) or {}
    exit_record = _logs.read_exit_record() or {}

    pid = record.get("pid")
    # An exit record from a DIFFERENT process is a previous run's death, not
    # this one's — reported as such rather than silently misattributed.
    exit_pid = exit_record.get("pid")
    exit_is_for_this_pid = bool(exit_record) and (exit_pid is None or exit_pid == pid)

    died_at = None
    died_at_source = None
    if exit_is_for_this_pid and exit_record.get("at"):
        died_at, died_at_source = exit_record["at"], "exit-record"
    else:
        try:
            died_at = datetime.fromtimestamp(
                pid_file.stat().st_mtime, tz=timezone.utc
            ).isoformat()
            died_at_source = "pid-file-mtime"
        except OSError:
            pass

    # BUG-MSO-2026-0713: a FOURTH source — the supervisor's `died` record. The
    # three above all depend on the daemon having observed something about its
    # own exit, which is exactly what a `taskkill /F` denies it. The supervisor
    # is a separate process still alive when the Hub is not, so its exit code is
    # available for precisely the deaths the others report as `None`. It never
    # OVERWRITES an exit code the daemon itself managed to record (that one is
    # closer to the source); it fills in when there is none, and `causeSource`
    # says which spoke.
    died = None
    try:
        from maestro.core import died_record
        died = died_record.read_died("hub", workspace_dir=get_maestro_home(),
                                     include_clean=True)
        if died and pid is not None and died.get("pid") not in (None, pid):
            died = None  # a previous run's death — never misattributed to this one
    except Exception:
        died = None

    exit_code = exit_record.get("exitCode") if exit_is_for_this_pid else None
    cause_source = "exit-record" if exit_code is not None else None
    if exit_code is None and died is not None and died.get("exitCode") is not None:
        exit_code = died.get("exitCode")
        cause_source = "supervisor"

    return {
        "pidFile": str(pid_file),
        "pidFileExists": pid_file.exists(),
        "pid": pid,
        "startedAt": record.get("startedAt"),
        "diedAt": died_at or (died or {}).get("diedAt"),
        "diedAtSource": died_at_source or ("supervisor" if died else None),
        "exitCode": exit_code,
        "exitError": exit_record.get("error") if exit_is_for_this_pid else None,
        "exitRecordedForPid": exit_pid if exit_record else None,
        "exitRecordIsStale": bool(exit_record) and not exit_is_for_this_pid,
        "cause": (died or {}).get("cause"),
        "causeSource": cause_source,
        "supervisorStderrTail": (died or {}).get("stderrTail") or [],
        "logPath": str(_logs.hub_log_path()),
        "logTail": _logs.tail(tail_lines),
    }


PORT_PROBE_TIMEOUT_SECONDS = 5.0


#: How long after `mso hub start` a Hub that does not answer yet is reported as
#: still starting rather than as a Hub whose listener died (PR #424 review).
HUB_STARTUP_GRACE_SECONDS = 60.0
#: The one longer probe `mso hub start` makes before calling an older Hub dead,
#: so a busy Hub that answers slowly is not reported as NOT SERVING.
PORT_PROBE_RETRY_TIMEOUT_SECONDS = 10.0


def _record_age_seconds() -> Optional[float]:
    """Seconds since the current PID record's ``startedAt``, or ``None``.

    ``None`` when the record, the key or the timestamp is missing or
    unparseable - the caller then gives no startup grace, so a genuine zombie
    is never hidden behind an unreadable record.
    """
    record = _read_record_dict(_hub_pid_file()) or {}
    raw = record.get("startedAt")
    if not raw:
        return None
    try:
        started = datetime.fromisoformat(str(raw))
    except (TypeError, ValueError):
        return None
    if started.tzinfo is None:
        started = started.replace(tzinfo=timezone.utc)
    age = (datetime.now(timezone.utc) - started).total_seconds()
    return age if age >= 0 else None


def port_answers(port: int, timeout: float = PORT_PROBE_TIMEOUT_SECONDS) -> bool:
    """Does a live Hub actually SERVE on *port* within *timeout* seconds?

    Probes ``/api/v1/ping`` — the auth-exempt liveness route that touches no
    registry, filesystem or poller (BUG-MSO-2026-0390) — deliberately rather
    than a bare TCP connect: the kernel accepts a connection into the listen
    backlog even when the server behind it is wedged, so a socket-level check
    would call a hung Hub healthy. ``/api/v1/health`` is the wrong probe for
    the opposite reason: it walks every registered workspace, so a slow scan
    on a big fleet would read as a fault.

    Returns ``False`` on any failure — the caller reports "did not answer",
    which is exactly what a would-be dashboard user experiences.
    """
    import urllib.request

    try:
        with urllib.request.urlopen(
            f"http://127.0.0.1:{port}/api/v1/ping", timeout=timeout
        ) as resp:
            return 200 <= getattr(resp, "status", 200) < 400
    except Exception:  # noqa: BLE001 — any failure means "not answering"
        return False


ACCEPT_FAILED_MARKER = "Accept failed on a socket"


def not_serving_evidence(*, pid: Optional[int] = None, tail_lines: int = 8) -> dict:
    """What is knowable about a live Hub that does not serve (BUG-MSO-2026-0751).

    The supervisor's capture is where the asyncio accept failure lands (the
    child's stderr goes there, not to hub.log), so its tail is the evidence
    that names the cause. A ``stopped-serving`` record is included only when
    it is about *pid* — a previous run's is never attributed to this one.
    """
    capture_tail: "list[str]" = []
    stopped = None
    try:
        from maestro.core import died_record
        home = get_maestro_home()
        capture_tail = died_record._tail_lines(died_record.capture_path("hub", home))
        stopped = died_record.read_stopped_serving("hub", workspace_dir=home)
        if stopped and pid is not None and stopped.get("pid") not in (None, pid):
            stopped = None
    except Exception:  # noqa: BLE001 — evidence is best-effort, the state is not
        pass
    return {
        "acceptLoopDied": any(ACCEPT_FAILED_MARKER in line for line in capture_tail),
        "captureTail": capture_tail[-tail_lines:],
        "stoppedServing": stopped,
        "logPath": str(_logs.hub_log_path()),
        "logTail": _logs.tail(tail_lines),
    }


def serving_state(port: Optional[int] = None, *,
                  timeout: float = PORT_PROBE_TIMEOUT_SECONDS) -> dict:
    """The ONE classification of the Hub's state (BUG-MSO-2026-0751).

    ``RUNNING`` requires a live, identity-verified PID **and** a port that
    answers. A live PID whose port does not answer is ``NOT_SERVING`` — its
    own state, never ``RUNNING``: on 2026-09-13/14 a Hub whose asyncio accept
    loop had closed its listener was reported RUNNING by every surface.
    ``CRASHED`` is a dead PID whose record survives; ``STOPPED`` is no record.
    *port* defaults to the port recorded at start.
    """
    pid_file = _hub_pid_file()
    alive, pid = _is_hub_running(pid_file)
    port = port if port is not None else recorded_port()
    if not alive:
        return {
            "state": "CRASHED" if pid_file.exists() else "STOPPED",
            "processAlive": False, "serving": False, "pid": pid, "port": port,
        }
    serving = port_answers(port, timeout=timeout)
    return {
        "state": "RUNNING" if serving else "NOT_SERVING",
        "processAlive": True, "serving": serving, "pid": pid, "port": port,
    }


def hub_status(port: int = DEFAULT_PORT) -> dict:
    alive, pid = _is_hub_running(_hub_pid_file())
    if alive:
        # The port the live Hub was STARTED on wins over the caller's default,
        # or a Hub started with --port 4000 would read as not serving.
        port = recorded_port(default=port)
    health = _fetch_health(port) if alive else None
    # BUG-MSO-2026-0751: a live PID alone is not RUNNING. A health answer
    # proves serving; without one, the cheap /ping decides (health walks every
    # workspace and can time out on a big fleet while the Hub serves fine).
    serving = bool(health) or (alive and port_answers(port))
    running = alive and serving
    if health:
        running_version = health.get("version")
        installed_version = health.get("installedVersion") or _installed_version()
        version_mismatch = bool(health.get("versionMismatch"))
    else:
        # Backend unreachable (wrong port, unresponsive, or genuinely not
        # running) — report what we honestly know: nothing about the running
        # process, only this reader's own fresh import as a best-effort
        # installed-version hint.
        running_version = None
        installed_version = _installed_version()
        version_mismatch = False
    pid_file_exists = _hub_pid_file().exists()
    status = {
        "running": running,
        "state": (
            "RUNNING" if running
            else "NOT_SERVING" if alive
            else "CRASHED" if pid_file_exists
            else "STOPPED"
        ),
        "processAlive": alive,
        "serving": serving,
        "pid": pid if alive else None,
        "port": port,
        "runningVersion": running_version,
        "installedVersion": installed_version,
        "versionMismatch": version_mismatch,
        "logPath": str(_logs.hub_log_path()),
        "startedAt": (_read_record_dict(_hub_pid_file()) or {}).get("startedAt") if alive else None,
        "notServingEvidence": not_serving_evidence(pid=pid) if alive and not serving else None,
    }
    # BUG-MSO-2026-0712: a STOPPED hub whose PID file survives is a CRASHED
    # hub — a clean `mso hub stop` always removes the record. That distinction
    # is the whole finding, so the evidence rides on the status dict rather
    # than being left for the operator to go and dig up.
    if not alive and pid_file_exists:
        status["crashed"] = True
        status["evidence"] = death_evidence()
    else:
        status["crashed"] = False
        status["evidence"] = None
    return status


def _describe_age(iso_timestamp: Optional[str]) -> str:
    """``"2026-09-09T21:40:11+00:00 (1h 57m ago)"`` — or the raw value when it
    cannot be parsed, never a guess."""
    if not iso_timestamp:
        return "(unknown)"
    try:
        stamp = datetime.fromisoformat(iso_timestamp)
        if stamp.tzinfo is None:
            stamp = stamp.replace(tzinfo=timezone.utc)
    except (TypeError, ValueError):
        return str(iso_timestamp)
    seconds = int((datetime.now(timezone.utc) - stamp).total_seconds())
    if seconds < 0:
        return f"{iso_timestamp} (in the future — clock skew?)"
    if seconds < 60:
        ago = f"{seconds}s ago"
    elif seconds < 3600:
        ago = f"{seconds // 60}m ago"
    else:
        ago = f"{seconds // 3600}h {(seconds % 3600) // 60}m ago"
    return f"{iso_timestamp} ({ago})"


def print_status(port: int = DEFAULT_PORT) -> None:
    s = hub_status(port=port)
    print("\n  MAESTRO HUB — STATUS")
    print("  " + "-" * 40)
    if s["running"]:
        print(f"  Status:  RUNNING (PID: {s['pid']})")
        print(f"  URL:     http://127.0.0.1:{s['port']}")
        if s.get("startedAt"):
            print(f"  Started: {_describe_age(s['startedAt'])}")
        version_line = f"  Running version: {s.get('runningVersion') or '(unknown — health check unreachable)'}"
        if s.get("versionMismatch"):
            version_line += f"  [STALE — installed is {s.get('installedVersion')}]"
        print(version_line)
        print(f"  Log:     {s.get('logPath')}")
    elif s.get("state") == "NOT_SERVING":
        # BUG-MSO-2026-0751: never "RUNNING" — the dashboard is unreachable.
        ev = s.get("notServingEvidence") or {}
        print(f"  Status:  NOT SERVING — PID {s['pid']} is alive, but "
              f"http://127.0.0.1:{s['port']} does not answer")
        if s.get("startedAt"):
            print(f"  Started: {_describe_age(s['startedAt'])}")
        if ev.get("acceptLoopDied"):
            print("  Cause:   the asyncio accept loop died (\"Accept failed on a socket\") "
                  "and closed the listening socket while the process kept running")
        else:
            print("  Cause:   not recorded — the process holds its PID but its port refuses "
                  "or does not answer")
        tail = ev.get("captureTail") or []
        if tail:
            print("  Supervisor captured:")
            for line in tail:
                print(f"    | {line}")
        print(f"  Log:     {ev.get('logPath') or s.get('logPath')}")
        print("  Recover: mso hub stop && mso hub start")
    elif s.get("crashed"):
        # BUG-MSO-2026-0712: STOPPED-with-a-PID-file is a CRASH, and saying
        # only "STOPPED" here is what left the 2026-09-09 death unexplainable.
        ev = s["evidence"] or {}
        print(f"  Status:  STOPPED — crashed (PID {ev.get('pid')} is gone, PID file survives)")
        if ev.get("startedAt"):
            print(f"  Started: {_describe_age(ev['startedAt'])}")
        died_source = {
            "exit-record": "recorded by the daemon",
            "pid-file-mtime": "PID-file mtime — an upper bound, not the moment of death",
            # BUG-MSO-2026-0713: the supervisor waited on the daemon from
            # outside, so its timestamp is the moment the process actually
            # ended — not an upper bound like the mtime above.
            "supervisor": "observed by the supervisor",
        }.get(ev.get("diedAtSource") or "", "source unknown")
        print(f"  Died:    {_describe_age(ev.get('diedAt'))}  [{died_source}]")
        if ev.get("exitCode") is not None:
            via = " (via the supervisor)" if ev.get("causeSource") == "supervisor" else ""
            cause = {
                "crash": "in-process crash — its own code raised",
                "terminated": "terminated from outside — no traceback, nothing in it ran",
                "clean": "clean exit",
                # BUG-MSO-2026-0751
                "stopped-serving": "stopped serving — its listener died, so it was ended "
                                   "to be restarted",
            }.get(ev.get("cause") or "", "")
            print(f"  Exit:    code {ev['exitCode']}{via}"
                  + (f" — {ev['exitError']}" if ev.get("exitError") else "")
                  + (f" — {cause}" if cause and not ev.get("exitError") else ""))
        else:
            print("  Exit:    not recorded — the daemon was killed without a chance to "
                  "write one (hard kill, console teardown, or OOM)")
        sup_tail = ev.get("supervisorStderrTail") or []
        if sup_tail:
            print("  Supervisor captured:")
            for line in sup_tail[-5:]:
                print(f"    | {line}")
        print(f"  Log:     {ev.get('logPath')}")
        log_tail = ev.get("logTail") or []
        if log_tail:
            print("  Last log lines:")
            for line in log_tail:
                print(f"    | {line}")
        else:
            print("  Last log lines: (none — log absent or empty)")
        print("  Restart: mso hub start")
    else:
        print("  Status:  STOPPED")
        print(f"  Log:     {s.get('logPath')}")
    print("  " + "-" * 40)
    print()
