"""Centralised role-model and squad-name constants for the Maestro engine.

Replaces the triplicated CREW_NAMES / ROLE_MODELS dicts that previously lived
in maestro/core/{fleet_monitor,crew,fleet_runner}.py (FTR-MSO-2026-0168).
"""

from __future__ import annotations

import re
from typing import Optional

# Canonical role → short model label used in dashboards and lifecycle logs.
# Legacy role codes (NAV/SHP/BOS/SCR/LKT/COX/QM) resolve via
# maestro.core.fleet_runner.resolve_role_code before lookup here.
DEFAULT_ROLE_MODELS: dict[str, str] = {
    "PLN":  "Opus",     # was NAV — Opus for high-leverage planning (low volume, propagates downstream)
    "BLD":  "Sonnet",   # was SHP — highest-volume role; Sonnet by default, per-order `model` override for hard orders
    "TST":  "Sonnet",   # was BOS
    "DOC":  "Sonnet",   # was SCR
    "SEC":  "Haiku",    # was LKT
    "REL":  "Opus",     # was COX — last role in the chain; high-stakes, low-volume
    "LEAD": "Opus",     # interactive judgment/reasoning role
}

# Canonical role → full Claude model ID used when dispatching crews.
# Mirrors DEFAULT_ROLE_MODELS but contains the actual API model strings.
#
# Model selection principle (high-stakes x low-volume gets Opus):
#   - PLN/REL/LEAD → Opus 5 at medium effort: planning, release/integration,
#     and interactive judgment are high-leverage and run infrequently. The
#     INV-MSO-2026-0417 A/B measured Opus 5 as ~0.82x the cost of Opus 4.8 at
#     equal (medium) effort with no measured quality loss, so these roles moved
#     from claude-opus-4-8 -> claude-opus-5 (FTR-MSO-2026-0419). The economy
#     win comes from the model swap AT medium effort — the paired effort default
#     dropped to 'medium' (see DEFAULT_ROLE_EFFORT); raising Opus 5 to high/xhigh
#     costs MORE than the old Opus 4.8 baseline for no measured gain.
#   - BLD/TST/DOC → Sonnet 5: high-volume production roles. Moved from
#     claude-sonnet-4-6 ($3/$15 in/out) to the current Sonnet generation
#     ($2/$10 in/out) — a generation refresh AND a 33% list-price reduction
#     (FTR-MSO-2026-0865 corrected an earlier comment here that claimed the two
#     were identically priced); promote individual hard orders via the
#     per-order `model` override (FTR-0129) rather than globally. Opus 5 was
#     never A/B'd against Sonnet, so these are deliberately left unchanged.
#   - SEC → Haiku: read-only review; cheapest tier suffices.
DEFAULT_ROLE_MODEL_IDS: dict[str, str] = {
    "PLN":  "claude-opus-5",
    "BLD":  "claude-sonnet-5",
    "TST":  "claude-sonnet-5",
    "DOC":  "claude-sonnet-5",
    "SEC":  "claude-haiku-4-5",
    "REL":  "claude-opus-5",
    "LEAD": "claude-opus-5",
}

_DEFAULT_MODEL_LABEL = "Sonnet"
_DEFAULT_MODEL_ID = "claude-sonnet-5"

# Full Claude model ID -> short display label (Opus/Sonnet/Haiku/Fable).
# BUG-MSO-2026-0447: lets a status display show the label for whatever model
# ID an override chain (crew.resolve_model_for) actually resolved to, instead
# of only the built-in per-role default.
MODEL_ID_LABELS: dict[str, str] = {
    "claude-fable-5-1": "Fable",
    "claude-fable-5": "Fable",
    "claude-opus-5": "Opus",
    "claude-opus-4-8": "Opus",
    "claude-opus-4-7": "Opus",
    "claude-opus-4-6": "Opus",
    "claude-sonnet-5": "Sonnet",
    "claude-sonnet-4-6": "Sonnet",
    "claude-haiku-4-5": "Haiku",
}

# FTR-MSO-2026-0865: model IDs that name a model already in MODEL_ID_LABELS
# under a non-canonical spelling — a dated API snapshot, in practice. ACCEPTED
# at every layer (dispatch, pricing, overlays, labels) so a workspace that
# pinned one keeps working; NOT advertised, so `mso settings` choices, the
# Hub's model dropdown and the docs tables show exactly one id per model.
#
# DO NOT "tidy away" an entry here. `claude-haiku-4-5-20251001` was Maestro's
# own shipped SEC default up to v5.14.x, so removing it would stall dispatch
# (crew._validate_model_id) on every workspace whose role-models.json still
# pins it, and would re-price archived Haiku usage at the fallback rate.
# Aliases are deliberately NOT in LEGACY_OVERLAY_MODEL_IDS — that set is
# documented "NOT dispatchable", which is the opposite of what an alias is.
MODEL_ID_ALIASES: dict[str, str] = {
    "claude-haiku-4-5-20251001": "claude-haiku-4-5",
}

# BUG-MSO-2026-0718: the ONE list of model IDs Maestro supports (prices and
# dispatches against). crew.SUPPORTED_MODELS (the dispatch gate) and
# roles.loader.KNOWN_MODELS (overlay warning set) both derive from it, and
# tests/test_docs_model_names_current.py checks every shipped doc against it.
# Adding a model = a MODEL_ID_LABELS entry here + a PRICING entry in
# maestro/core/fleet_usage_tracker.py. Retiring a SPELLING (not a model) =
# a MODEL_ID_ALIASES entry above, which keeps it dispatchable and priceable
# without advertising it a second time.
SUPPORTED_MODEL_IDS: frozenset = frozenset(MODEL_ID_LABELS) | frozenset(MODEL_ID_ALIASES)

# Retired IDs that an older role overlay may still name. Recognised by the
# overlay loader so those files load without a warning; NOT dispatchable.
LEGACY_OVERLAY_MODEL_IDS: frozenset = frozenset({
    "claude-sonnet-4-5",
    "claude-opus-4-5",
})

_MODEL_ID_RE = re.compile(r"^claude-[a-z]+-(\d+)(?:-(\d{1,2}))?(?:-\d{8})?$")


def canonical_model_id(model_id: str) -> str:
    """Return the canonical model ID for *model_id* (FTR-MSO-2026-0865).

    Strips a trailing '[1m]' context-window selector, then resolves a
    MODEL_ID_ALIASES spelling to the id MODEL_ID_LABELS / PRICING are keyed on.
    Identity for anything already canonical or entirely unknown — never raises,
    so every lookup site can route through it unconditionally.

    NOT for crew._validate_model_id: dispatch must pass the operator's own
    spelling through to the Claude CLI, which serves a dated snapshot id fine.
    """
    if not model_id or not isinstance(model_id, str):
        return model_id
    bare = model_id.removesuffix("[1m]")
    return MODEL_ID_ALIASES.get(bare, bare)


def get_model_display_name(model_id: str) -> str:
    """Return the human display name for a model ID, e.g. 'Opus 5', 'Haiku 4.5'.

    Derived from MODEL_ID_LABELS plus the version digits in the ID (a trailing
    8-digit snapshot date is ignored), so docs tables rendered from it can never
    disagree with the IDs the dispatcher actually uses.
    """
    bare = canonical_model_id(model_id or "")
    m = _MODEL_ID_RE.match(bare)
    if not m:
        return get_model_label(bare)
    version = m.group(1) + (f".{m.group(2)}" if m.group(2) else "")
    return f"{get_model_label(bare)} {version}"


def get_model_label(model_id: str) -> str:
    """Return the short display label (Opus/Sonnet/Haiku/Fable) for a full model ID.

    Strips a trailing '[1m]' context-window suffix and resolves a
    MODEL_ID_ALIASES spelling before lookup. Unknown IDs fall back to
    title-casing the 'claude-<family>-...' segment so a future model still
    renders something readable rather than the wrong family name.
    """
    if not model_id:
        return _DEFAULT_MODEL_LABEL
    bare = canonical_model_id(model_id)
    if bare in MODEL_ID_LABELS:
        return MODEL_ID_LABELS[bare]
    parts = bare.split("-")
    if len(parts) >= 2 and parts[0] == "claude":
        return parts[1].capitalize()
    return _DEFAULT_MODEL_LABEL


def _resolve(role: str) -> str:
    """Resolve legacy nautical role code to canonical without importing fleet_runner at module level."""
    try:
        from maestro.core.fleet_runner import resolve_role_code  # noqa: PLC0415
        return resolve_role_code(role)
    except Exception:
        return role


def get_role_model(role: str) -> str:
    """Return the short model label (Opus/Sonnet/Haiku) for a role code.

    Accepts both canonical (PLN/BLD/…) and legacy (NAV/SHP/…) codes.
    """
    canonical = _resolve(role) if role else role
    return DEFAULT_ROLE_MODELS.get(canonical, _DEFAULT_MODEL_LABEL)


def get_role_model_id(role: str) -> str:
    """Return the full Claude model ID for a role code (used when dispatching crews)."""
    canonical = _resolve(role) if role else role
    return DEFAULT_ROLE_MODEL_IDS.get(canonical, _DEFAULT_MODEL_ID)


def get_squad_name(slot: int) -> str:
    """Return the persona-specific display name for crew slot *slot* (1-indexed).

    Falls back to 'Squad <slot>' if the slot is out of range or persona unavailable.
    """
    try:
        from maestro.personas import current_persona  # noqa: PLC0415
        names = current_persona().squad_names()
        if 1 <= slot <= len(names):
            return names[slot - 1]
    except Exception:
        pass
    return f"Squad {slot}"


# ---------------------------------------------------------------------------
# FTR-MSO-2026-0281: Context window + reasoning effort configuration
# ---------------------------------------------------------------------------

# Shared enum sets — single source of truth imported by crew.py / loader.py / cli.py.
VALID_CONTEXT_WINDOWS: frozenset = frozenset({"standard", "1m"})

# Effort levels available to crew dispatch (max + ultracode reserved for interactive LEAD)
VALID_EFFORTS_CREW: frozenset = frozenset({"low", "medium", "high", "xhigh"})

# All known effort values including interactive-only ones
VALID_EFFORTS_ALL: frozenset = VALID_EFFORTS_CREW | frozenset({"max", "ultracode"})

# Effort levels that require an Opus model
OPUS_ONLY_EFFORTS: frozenset = frozenset({"xhigh"})

# Model IDs that support the 1M context window selector.
# Opus 5 ships 1M as both the default AND the maximum, so the '[1m]' selector
# is a no-op there rather than an upgrade — harmless, and kept for uniformity.
# FTR-MSO-2026-0628: Fable 5.1 also ships 1M as default+max, confirmed via
# platform.claude.com/docs/en/models/fable-5-1/overview (context window row).
MILLION_CONTEXT_MODEL_IDS: frozenset = frozenset({
    "claude-fable-5-1",
    "claude-fable-5",
    "claude-opus-5",
    "claude-opus-4-8",
    "claude-opus-4-7",
    "claude-sonnet-5",
    "claude-sonnet-4-6",
})

# Model IDs that support the top-tier reasoning efforts (xhigh effort guard).
# Fable 5 supports xhigh/max like the Opus family, so it is grouped here.
# Fable 5.1 confirmed to support the full low/medium/high/xhigh/max ladder
# (platform.claude.com/docs/en/build-with-claude/effort.md), so it joins too.
OPUS_MODEL_IDS: frozenset = frozenset({
    "claude-fable-5-1",
    "claude-fable-5",
    "claude-opus-5",
    "claude-opus-4-8",
    "claude-opus-4-7",
    "claude-opus-4-6",
})

# Conservative per-role context window defaults (no extra cost out of the box).
DEFAULT_ROLE_CONTEXT_WINDOW: dict = {
    "PLN":  "standard",
    "BLD":  "standard",
    "TST":  "standard",
    "DOC":  "standard",
    "SEC":  "standard",
    "REL":  "standard",
    "LEAD": "standard",
}

# Per-role effort defaults.
#   - PLN/REL/LEAD → 'medium': these roles run on Opus 5 (see DEFAULT_ROLE_MODEL_IDS).
#     INV-MSO-2026-0417 measured Opus 5's low/medium effort as unusually strong;
#     high/xhigh cost 1.19x/1.92x the old Opus 4.8 baseline for no measured quality
#     gain. medium is the sweet spot — do NOT reflexively raise it (FTR-MSO-2026-0419).
#   - BLD/TST/DOC/SEC → 'high': Sonnet/Haiku roles, unchanged (high is Claude's own
#     default; no extra cost). These were not part of the Opus 5 A/B.
DEFAULT_ROLE_EFFORT: dict = {
    "PLN":  "medium",
    "BLD":  "high",
    "TST":  "high",
    "DOC":  "high",
    "SEC":  "high",
    "REL":  "medium",
    "LEAD": "medium",
}

_DEFAULT_CONTEXT_WINDOW = "standard"
_DEFAULT_EFFORT = "high"


def get_role_context_window(role: str) -> str:
    """Return the default context window for a role code (standard|1m).

    Accepts both canonical (PLN/BLD/…) and legacy (NAV/SHP/…) codes.
    """
    canonical = _resolve(role) if role else role
    return DEFAULT_ROLE_CONTEXT_WINDOW.get(canonical, _DEFAULT_CONTEXT_WINDOW)


def get_role_effort(role: str) -> str:
    """Return the default reasoning effort for a role code (low|medium|high|xhigh).

    Accepts both canonical (PLN/BLD/…) and legacy (NAV/SHP/…) codes.
    """
    canonical = _resolve(role) if role else role
    return DEFAULT_ROLE_EFFORT.get(canonical, _DEFAULT_EFFORT)
