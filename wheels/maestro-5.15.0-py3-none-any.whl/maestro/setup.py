"""
maestro/setup.py — Prerequisite validation and interactive setup wizard.

Provides:
  - PrereqCheck dataclass
  - 8 validator functions
  - run_all_checks() -> list[PrereqCheck]
  - format_check_report(results, verbose=False) -> str
  - interactive_setup()
  - check_mode_exit_code(results) -> int
"""

from __future__ import annotations

import os
import re
import shutil
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Literal

from maestro.personas import current_persona
from maestro.workspace import MSO_DIR_NAME, find_workspace_dir


StatusT = Literal["OK", "WARN", "FAIL"]


@dataclass
class PrereqCheck:
    name: str
    status: StatusT
    message: str
    remediation: str = ""
    repair_fn: Callable[[], None] | None = field(default=None, repr=False)


# ---------------------------------------------------------------------------
# Validators
# ---------------------------------------------------------------------------

def check_python_version() -> PrereqCheck:
    if sys.version_info >= (3, 9):
        return PrereqCheck(
            name="python_version",
            status="OK",
            message=f"Python {sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
        )
    vi = sys.version_info
    major, minor = (vi[0], vi[1]) if isinstance(vi, tuple) else (vi.major, vi.minor)
    return PrereqCheck(
        name="python_version",
        status="FAIL",
        message=f"Python {major}.{minor} — 3.9+ required",
        remediation="Upgrade Python: https://www.python.org/downloads/",
    )


def check_claude_cli() -> PrereqCheck:
    if sys.platform == "win32" and shutil.which("claude") is None:
        return PrereqCheck(
            name="claude_cli",
            status="FAIL",
            message="Claude Code CLI not found (Windows requires WSL2)",
            remediation=(
                "Install WSL2 then install Claude Code inside it:\n"
                "  wsl --install\n"
                "  npm install -g @anthropic-ai/claude-code"
            ),
        )
    if shutil.which("claude") is None:
        return PrereqCheck(
            name="claude_cli",
            status="FAIL",
            message="Claude Code CLI not found on PATH",
            remediation="npm install -g @anthropic-ai/claude-code  (requires Node 18+)",
        )
    # On Windows, the npm-installed `claude` is a .CMD shim. subprocess.run with
    # a bare ["claude", ...] argv triggers CreateProcess, which does NOT consult
    # PATHEXT and fails with [WinError 2]. Resolving via shutil.which first hands
    # subprocess the actual .CMD path and works cross-platform.
    claude_path = shutil.which("claude") or "claude"
    try:
        result = subprocess.run(
            [claude_path, "--version"],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode == 0:
            version = (result.stdout.strip() or result.stderr.strip()).splitlines()[0]
            return PrereqCheck(
                name="claude_cli",
                status="OK",
                message=f"Claude Code {version}",
            )
    except Exception:
        pass
    return PrereqCheck(
        name="claude_cli",
        status="FAIL",
        message="Claude Code CLI found but did not respond to --version",
        remediation="Try: npm install -g @anthropic-ai/claude-code",
    )


def check_git() -> PrereqCheck:
    if shutil.which("git") is None:
        return PrereqCheck(
            name="git",
            status="FAIL",
            message="git not found on PATH",
            remediation="Install Git: https://git-scm.com/downloads",
        )
    try:
        result = subprocess.run(
            ["git", "--version"],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode == 0:
            version = result.stdout.strip()
            return PrereqCheck(name="git", status="OK", message=version)
    except Exception:
        pass
    return PrereqCheck(
        name="git",
        status="FAIL",
        message="git found but did not respond",
        remediation="Reinstall Git: https://git-scm.com/downloads",
    )


def check_gh_cli() -> PrereqCheck:
    if shutil.which("gh") is None:
        return PrereqCheck(
            name="gh_cli",
            status="WARN",
            message="GitHub CLI (gh) not found — required for PR workflows",
            remediation="Install gh: https://cli.github.com/",
        )
    try:
        result = subprocess.run(
            ["gh", "--version"],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode == 0:
            version = result.stdout.strip().splitlines()[0]
            # Check auth status
            auth = subprocess.run(
                ["gh", "auth", "status"],
                capture_output=True, text=True, timeout=10,
            )
            if auth.returncode != 0:
                return PrereqCheck(
                    name="gh_cli",
                    status="WARN",
                    message=f"{version} — not authenticated",
                    remediation="Run: gh auth login",
                )
            return PrereqCheck(name="gh_cli", status="OK", message=version)
    except Exception:
        pass
    return PrereqCheck(
        name="gh_cli",
        status="WARN",
        message="gh found but did not respond",
        remediation="Reinstall gh: https://cli.github.com/",
    )


def check_anthropic_auth() -> PrereqCheck:
    if os.environ.get("ANTHROPIC_API_KEY"):
        return PrereqCheck(
            name="anthropic_auth",
            status="OK",
            message="ANTHROPIC_API_KEY set",
        )
    # Claude Code subscription auth is also valid — we can't probe it
    # directly, but if claude CLI is available we assume it may be logged in.
    if shutil.which("claude") is not None:
        return PrereqCheck(
            name="anthropic_auth",
            status="OK",
            message="Claude Code subscription auth (no ANTHROPIC_API_KEY — crews use subscription billing)",
        )
    return PrereqCheck(
        name="anthropic_auth",
        status="WARN",
        message="No ANTHROPIC_API_KEY and Claude Code CLI not found",
        remediation=(
            "Set API key: export ANTHROPIC_API_KEY=sk-ant-...\n"
            "  or install Claude Code: npm install -g @anthropic-ai/claude-code"
        ),
    )


def check_workspace_scaffold() -> PrereqCheck:
    mso = find_workspace_dir(Path.cwd())
    if mso is not None:
        ws_json = mso / "config" / "workspace.json"
        if not ws_json.exists():
            return PrereqCheck(
                name="workspace_scaffold",
                status="WARN",
                message=f"{MSO_DIR_NAME}/ found at {mso.parent} but workspace.json is missing",
                remediation="Run: mso init --project <PRJ>",
            )
        return PrereqCheck(
            name="workspace_scaffold",
            status="OK",
            message=f"Workspace at {mso}",
        )

    def _repair():
        from maestro.init import scaffold_workspace
        try:
            project = input("    Project acronym (e.g. PSG): ").strip().upper()
        except EOFError:
            project = ""
        if not project:
            print("    No project acronym supplied — skipping scaffold.")
            return
        scaffold_workspace(project, Path.cwd())

    return PrereqCheck(
        name="workspace_scaffold",
        status="FAIL",
        message="No Maestro workspace (.mso/) found in current directory or any parent",
        remediation="Run: mso init --project <PRJ>",
        repair_fn=_repair,
    )


# ---------------------------------------------------------------------------
# Aggregator
# ---------------------------------------------------------------------------

def check_repo_config() -> PrereqCheck:
    """Warn when projects.json / workspace.json still hold placeholder values."""
    mso_dir = _find_mso_dir()
    if mso_dir is None:
        return PrereqCheck(
            name="repo_config",
            status="OK",
            message="No .mso/ workspace found — skipping repo config check",
        )

    from maestro.core.fleet_runner import validate_placeholder_repo_config
    errors = validate_placeholder_repo_config()
    if errors:
        detail = "; ".join(errors[:2])
        return PrereqCheck(
            name="repo_config",
            status="WARN",
            message=f"Placeholder repo config detected: {detail}",
            remediation=(
                "Edit .mso/config/workspace.json and .mso/config/projects.json, "
                "then re-run `mso setup --check`."
            ),
        )
    return PrereqCheck(name="repo_config", status="OK", message="Repo config looks real")


def check_unsigned_acl_manifest() -> PrereqCheck:
    """8th validator (FTR-MSO-2026-0482, plan §7.4/§7.5): in a GOVERNED
    (enforce-mode) workspace only, FAIL when identity records exist but the
    integrity manifest is missing or unsigned. Never fires at community, pro,
    or an ungoverned team/enterprise workspace — those have no manifest to
    sign, and this check's whole precondition is governed-enforce mode."""
    mso_dir = _find_mso_dir()
    if mso_dir is None:
        return PrereqCheck(
            name="acl_signed",
            status="OK",
            message="No .mso/ workspace found — skipping unsigned-ACL check",
        )

    ws_root = mso_dir.parent
    from maestro.governance import resolve_governed_mode
    mode = resolve_governed_mode(ws_root)
    if mode != "enforce":
        return PrereqCheck(
            name="acl_signed",
            status="OK",
            message=f"Governed mode is {mode!r} — unsigned-ACL check only applies in 'enforce' mode",
        )

    identity_dir = mso_dir / "identity"
    has_identity_records = identity_dir.is_dir() and any(
        p for p in identity_dir.rglob("*.json") if p.name != "integrity.json"
    )
    if not has_identity_records:
        return PrereqCheck(
            name="acl_signed",
            status="OK",
            message="Governed workspace has no identity records yet — nothing to sign",
        )

    from maestro.identity.integrity import manifest_is_signed
    if not manifest_is_signed(identity_dir):
        return PrereqCheck(
            name="acl_signed",
            status="FAIL",
            message=f"Identity integrity manifest at {identity_dir / 'integrity.json'} is "
                    "missing or UNSIGNED in a governed (enforce) workspace — the ACL is "
                    "untrusted until re-signed (§7.4).",
            remediation="Run `mso identity sign-acl --key-id <id> --key-file <path>` "
                        "(or set MAESTRO_IDENTITY_SIGNING_KEY) with the org's off-client "
                        "Ed25519 seed to produce a trusted signed manifest.",
        )
    return PrereqCheck(
        name="acl_signed",
        status="OK",
        message="Identity integrity manifest is signed",
    )


def run_all_checks() -> list[PrereqCheck]:
    return [
        check_python_version(),
        check_claude_cli(),
        check_git(),
        check_gh_cli(),
        check_anthropic_auth(),
        check_workspace_scaffold(),
        check_repo_config(),
        check_unsigned_acl_manifest(),
    ]


# ---------------------------------------------------------------------------
# Formatting
# ---------------------------------------------------------------------------

_STATUS_SYMBOLS = {"OK": "✓", "WARN": "⚠", "FAIL": "✗"}
_STATUS_LABELS = {"OK": "OK  ", "WARN": "WARN", "FAIL": "FAIL"}

# ANSI colour codes (disabled on Windows without ENABLE_VIRTUAL_TERMINAL_PROCESSING
# or when not a TTY — callers that need plain output pass colour=False).
_COLOURS = {
    "OK": "\033[32m",    # green
    "WARN": "\033[33m",  # yellow
    "FAIL": "\033[31m",  # red
    "RESET": "\033[0m",
}

def _colour_supported() -> bool:
    return sys.stdout.isatty() and os.environ.get("NO_COLOR") is None


def format_check_report(results: list[PrereqCheck], verbose: bool = False) -> str:
    use_colour = _colour_supported()
    lines: list[str] = []
    for r in results:
        sym = _STATUS_SYMBOLS[r.status]
        label = _STATUS_LABELS[r.status]
        if use_colour:
            c = _COLOURS[r.status]
            reset = _COLOURS["RESET"]
            prefix = f"{c}{sym} [{label}]{reset}"
        else:
            prefix = f"{sym} [{label}]"
        lines.append(f"  {prefix}  {r.name}: {r.message}")
        if verbose and r.remediation and r.status != "OK":
            for rem_line in r.remediation.splitlines():
                lines.append(f"             {rem_line}")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Exit-code helper
# ---------------------------------------------------------------------------

def check_mode_exit_code(results: list[PrereqCheck]) -> int:
    """0=all OK, 1=any FAIL, 2=any WARN (no FAIL), 3=internal error."""
    try:
        statuses = {r.status for r in results}
        if "FAIL" in statuses:
            return 1
        if "WARN" in statuses:
            return 2
        return 0
    except Exception:
        return 3


# ---------------------------------------------------------------------------
# Interactive wizard
# ---------------------------------------------------------------------------

def _find_mso_dir() -> Path | None:
    """Walk up from cwd looking for a Maestro workspace (.mso/)."""
    return find_workspace_dir(Path.cwd())


@dataclass
class SetupContext:
    """Shared state threaded through a wizard run (FTR-MSO-2026-0478).

    ``tier`` is resolved ONCE, at entry, via ``licence.resolve_state()`` —
    read only; nothing in the wizard sets, caches, or infers a tier (§3.2a
    rule 2). ``results`` / ``analysis`` let later steps (e.g. the cheatsheet)
    see earlier steps' findings without relying on ``locals()`` inspection.
    """

    tier: str
    non_interactive: bool = False
    profile_path: "str | None" = None
    answers: dict = field(default_factory=dict)
    licence_state: "object | None" = None
    results: list = field(default_factory=list)
    analysis: "object | None" = None
    errors: list = field(default_factory=list)

    def fail(self, message: str) -> None:
        self.errors.append(message)


@dataclass
class SetupStep:
    """One entry in the wizard's step registry.

    ``applies_to`` is a tier predicate: ``None`` means every tier (the six
    original steps — §3.3), a ``set[str]`` restricts the step to those
    tiers. Community never resolves an enrolment profile or sees a licence
    prompt because neither step's ``applies_to`` includes ``"community"`` —
    enforced structurally here, not by a runtime branch inside the step.
    """

    key: str
    title: str
    run: "Callable[[SetupContext], None]"
    applies_to: "set[str] | None" = None


def _parse_answers_file(path: "str | Path") -> dict:
    """Parse a flat ``KEY=VALUE`` answers file for ``mso setup --answers FILE``
    (§3.5 — the third unattended mode, for orgs without an enrolment profile).
    Blank lines and ``#``-comments are skipped.
    """
    p = Path(path)
    if not p.exists():
        print(f"[Maestro] --answers file not found: {p}", file=sys.stderr)
        sys.exit(1)
    answers: dict = {}
    for line in p.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        answers[key.strip()] = value.strip()
    return answers


# ---------------------------------------------------------------------------
# STEP 0 — persona
# ---------------------------------------------------------------------------

def _step_persona(ctx: "SetupContext") -> None:
    print("[STEP 0] Workstation setup — persona\n")
    from maestro.personas import load_persona, reset_persona_cache
    from maestro.personas.loader import builtin_names
    from maestro.personas.resolver import _find_workspace_config

    _p = current_persona()
    env_persona = os.environ.get("MAESTRO_PERSONA", "").strip()
    if env_persona:
        print(f"  Active persona: {_p.id} (set via MAESTRO_PERSONA env var — not changed here)")
    else:
        ws_config = _find_workspace_config()
        if ws_config:
            print(f"  Active persona: {_p.id} (from {ws_config})")
        else:
            print(f"  Active persona: {_p.id} (built-in default)")

        names = builtin_names()
        print(f"\n  Available personas: {', '.join(names)}")
        if not ctx.non_interactive and _ask("  Change persona for this workspace?"):
            print()
            for i, name in enumerate(names, 1):
                try:
                    px = load_persona(name)
                    print(f"    {i}. {name} — {px.vocabulary.get('userTitle', name)}")
                except Exception:
                    print(f"    {i}. {name}")
            raw = input("  Enter persona name or number (blank to skip): ").strip()
            chosen = None
            if raw.isdigit():
                idx = int(raw) - 1
                if 0 <= idx < len(names):
                    chosen = names[idx]
            elif raw in names:
                chosen = raw
            if chosen:
                # Write to the workspace root (found by walking up from cwd),
                # not always cwd — previously a dead `if False:` branch meant
                # this silently landed in cwd whenever `mso setup` ran from a
                # subdirectory (FTR-MSO-2026-0478 §4.4 persona-location bug).
                mso_dir = _find_mso_dir()
                ws_root = mso_dir.parent if mso_dir is not None else Path.cwd()
                config_dir = ws_root / ".maestro" / "config"
                config_dir.mkdir(parents=True, exist_ok=True)
                persona_file = config_dir / "persona.json"
                import json as _json
                persona_file.write_text(_json.dumps({"id": chosen}, indent=2), encoding="utf-8")
                reset_persona_cache()
                _p = current_persona()
                print(f"  ✓ Persona set to '{chosen}' at {persona_file}")
            else:
                print("  (skipped — keeping current persona)")
    print()


# ---------------------------------------------------------------------------
# STEP 1 — prerequisite checks
# ---------------------------------------------------------------------------

def _step_prereqs(ctx: "SetupContext") -> None:
    print("[STEP 1] Prerequisite checks\n")
    results = run_all_checks()
    ctx.results = results
    print(format_check_report(results, verbose=True))
    print()

    for check in results:
        if check.status in ("WARN", "FAIL") and check.remediation:
            print(f"  → {check.name}: {check.remediation}")
            if check.repair_fn and check.status == "FAIL" and not ctx.non_interactive:
                if _ask(f"  Attempt automatic repair for '{check.name}'?"):
                    try:
                        check.repair_fn()
                        print(f"  ✓ Repair attempted. Re-run `mso setup` to verify.")
                    except Exception as exc:
                        print(f"  ✗ Repair failed: {exc}")


# ---------------------------------------------------------------------------
# LICENCE — new in FTR-MSO-2026-0478, pro/team/enterprise only (§3.2a rule 1:
# community never sees a licence prompt, warning, or licence-shaped absence).
# ---------------------------------------------------------------------------

def _step_licence(ctx: "SetupContext") -> None:
    print("\n[LICENCE] Licence\n")
    state = ctx.licence_state
    line = f"  Tier   : {state.effective_tier}"
    if state.downgraded:
        line += f" (downgraded from {state.downgraded_from})"
    print(line)
    if state.expires_at:
        print(f"  Expires: {state.expires_at}")
    if state.warning:
        print(f"  {state.warning}")


# ---------------------------------------------------------------------------
# STEP 2 — project analysis
# ---------------------------------------------------------------------------

def _step_project_analysis(ctx: "SetupContext") -> None:
    print("\n[STEP 2] Project analysis\n")
    try:
        from pathlib import Path as _Path
        from maestro.project_analysis import analyse_project

        analysis = analyse_project(_Path.cwd())
        ctx.analysis = analysis
        print(f"  Language   : {analysis.primary_language}")
        if analysis.secondary_languages:
            print(f"  Also uses  : {', '.join(analysis.secondary_languages)}")
        print(f"  Framework  : {analysis.framework}")
        print(f"  Source root: {analysis.source_root}")
        print(f"  Test layout: {', '.join(analysis.test_layouts) or 'none detected'}")
        print(f"  Docs       : {'README ✓' if analysis.has_readme else 'no README'}"
              f"{', docs/ ✓' if analysis.has_docs_dir else ''}")
        print(f"  CI         : {', '.join(analysis.ci_systems) if analysis.ci_systems else 'none detected'}")
        print(f"  Git        : activity={analysis.recent_activity}, branches={analysis.branch_model}")
    except Exception as exc:
        print(f"  ⚠ Project analysis failed: {exc}")


# ---------------------------------------------------------------------------
# STEP 3 — workspace configuration
# ---------------------------------------------------------------------------

def _configure_workspace(ctx: "SetupContext") -> None:
    """Step 3: confirm/update workspace.json.

    FTR-MSO-2026-0478 §4.4: this step can now WRITE a correction
    (``defaultGitHubOrg``, project acronym) instead of only telling the
    operator to edit the file themselves. The default ("keep as-is") path is
    byte-identical to before — the write path is reached only when the
    operator declines it (or, non-interactively, via ``--answers``).
    """
    import json

    adm_dir = _find_mso_dir()
    if adm_dir is None:
        print("  ⚠ No Maestro workspace (.mso/) found — skipping workspace configuration.")
        print("    Run `mso init --project <PRJ>` first.")
        return

    ws_path = adm_dir / "config" / "workspace.json"
    if ws_path.exists():
        try:
            ws = json.loads(ws_path.read_text(encoding="utf-8"))
            project = ws.get("project", "UNKNOWN")
            print(f"  Current project : {project}")
            print(f"  workspace.json  : {ws_path}")
            if ctx.non_interactive:
                _apply_workspace_answers(ws, ws_path, ctx)
            elif not _ask("  Configuration looks correct. Keep it as-is?", default="y"):
                _edit_workspace_interactively(ws, ws_path)
        except Exception as exc:
            print(f"  ⚠ Could not read workspace.json: {exc}")
    else:
        print("  ⚠ workspace.json not found.")
        print("    Run `mso init --project <PRJ>` to create it.")


def _edit_workspace_interactively(ws: dict, ws_path: Path) -> None:
    """The write path for a "no, it's not right" answer to STEP 3."""
    import json
    try:
        new_project = input(f"  Project acronym [{ws.get('project', '')}]: ").strip()
    except EOFError:
        new_project = ""
    if new_project:
        ws["project"] = new_project.upper()
    try:
        new_org = input(f"  Default GitHub org [{ws.get('defaultGitHubOrg') or ''}]: ").strip()
    except EOFError:
        new_org = ""
    if new_org:
        ws["defaultGitHubOrg"] = new_org
    ws_path.write_text(json.dumps(ws, indent=2) + "\n", encoding="utf-8")
    print(f"  ✓ workspace.json updated at {ws_path}")


def _apply_workspace_answers(ws: dict, ws_path: Path, ctx: "SetupContext") -> None:
    """Non-interactive STEP 3: apply ``--answers`` overrides, or leave as-is."""
    import json
    changed = False
    project_answer = ctx.answers.get("workspace.project")
    if project_answer:
        ws["project"] = str(project_answer).upper()
        changed = True
    org_answer = ctx.answers.get("workspace.defaultGitHubOrg")
    if org_answer:
        ws["defaultGitHubOrg"] = org_answer
        changed = True
    if changed:
        ws_path.write_text(json.dumps(ws, indent=2) + "\n", encoding="utf-8")
        print(f"  ✓ workspace.json updated from --answers at {ws_path}")
    else:
        print("  Configuration kept as-is (non-interactive; no --answers overrides supplied).")


# ---------------------------------------------------------------------------
# STEP 3a — division pack selection (PLAN-PLN-MSO-2026-0449 §6.2, Order 4)
# ---------------------------------------------------------------------------

def _select_pack(ctx: "SetupContext") -> None:
    """Step 3a: tier-filtered division-pack selection (PLAN-PLN-MSO-2026-0449 §6.2).

    Defaults to `sdlc` — byte-identical to a plain init, so this step is a
    no-op at the default answer for every tier (plan §4.1 anti-leak guarantee
    #1). Selectable packs are filtered to what this tier can reach; WITHHELD
    packs are still NAMED ("Also available on Team/Enterprise"), never just
    dropped from the list — a community user should see what they are
    missing, not a shorter list with no explanation.

    Community must never even probe for an enrolment profile (plan §3.2a rule
    1: "must not even stat these paths") — the profile-pin lookup below is
    gated on ``ctx.tier in ("pro", "team", "enterprise")`` (the same
    once-resolved tier every other step uses, §3.2a rule 2) and is skipped
    entirely otherwise, so a community run of this step never mentions a
    profile, licence, or upgrade path.

    ``ctx.non_interactive`` never calls ``input()`` — a supplied
    ``--answers pack.id=...`` overrides the (possibly profile-pinned)
    default when it names a pack selectable at this tier; otherwise the
    default is applied silently, matching ``_apply_workspace_answers``.
    """
    from maestro import auth
    from maestro.packs import apply_pack, describe_pack_scaffold_result, load_all_builtin

    mso_dir = _find_mso_dir()
    if mso_dir is None:
        print("  ⚠ No Maestro workspace (.mso/) found — skipping pack selection.")
        print("    Run `mso init --project <PRJ>` first.")
        return
    base = mso_dir.parent

    packs = sorted(load_all_builtin(), key=lambda p: p.id)
    if not packs:
        print("  ⚠ No division packs found — skipping.")
        return

    hub_tier = ctx.tier in auth.HUB_TIERS
    selectable = [p for p in packs if p.is_free() or hub_tier]
    withheld = [p for p in packs if p not in selectable]
    selectable_ids = {p.id for p in selectable}

    # Enrolment-profile pack pin — only probed at pro/team/enterprise
    # (community: rule 1, above). A broken profile is reported but does not
    # abort the step; this is the pack-selection step, not full profile
    # application (a different order's job — see maestro/enrolment/apply.py).
    pin = None
    if ctx.tier in ("pro", "team", "enterprise"):
        try:
            from maestro.packs import resolve_profile_pack_pin
            pin = resolve_profile_pack_pin(base)
        except Exception as exc:  # noqa: BLE001
            print(f"  ⚠ Could not resolve the enrolment profile's pack pin: {exc}")

    default_id = "sdlc" if "sdlc" in selectable_ids else (selectable[0].id if selectable else "sdlc")
    locked = False
    if pin and pin.get("id"):
        pinned_id = pin["id"]
        if pinned_id in selectable_ids:
            default_id = pinned_id
            locked = bool(pin.get("locked"))
        else:
            print(f"  ⚠ Enrolment profile pins pack '{pinned_id}', which needs a "
                  f"higher tier than this device has — keeping '{default_id}'.")

    print("  Division packs available at your tier:")
    for p in selectable:
        marker = " (default)" if p.id == default_id else ""
        print(f"    • {p.id:<20} {p.description}{marker}")
    if withheld:
        print("\n  Also available on Team/Enterprise:")
        for p in withheld:
            print(f"    • {p.id:<20} {p.description}")

    chosen_id = default_id
    if locked:
        print(f"\n  This workspace is locked to the '{chosen_id}' pack by your "
              f"organisation's enrolment profile.")
    elif ctx.non_interactive:
        answer = ctx.answers.get("pack.id")
        if answer:
            if answer not in selectable_ids:
                print(f"  ✗ '{answer}' is not available at your tier — keeping '{chosen_id}'.")
            else:
                chosen_id = answer
    elif not _ask(f"\n  Apply the '{chosen_id}' pack?", default="y"):
        print("  Enter pack id (blank to keep default): ", end="", flush=True)
        try:
            raw = input().strip()
        except EOFError:
            raw = ""
        if raw:
            if raw not in selectable_ids:
                print(f"  ✗ '{raw}' is not available at your tier — keeping '{chosen_id}'.")
            else:
                chosen_id = raw

    pack = next(p for p in packs if p.id == chosen_id)
    preview = apply_pack(pack, base, dry_run=True)
    if not preview.changed():
        print(f"\n  Pack '{pack.id}' contributes nothing beyond the current workspace — no changes.")
        return

    print(f"\n  Preview — pack '{pack.id}' would change:")
    for line in describe_pack_scaffold_result(pack, preview):
        print(f"    {line}")
    apply_pack(pack, base)
    print(f"\n  ✓ Pack '{pack.id}' applied.")


# ---------------------------------------------------------------------------
# PROFILE — new in FTR-MSO-2026-0478, pro/team/enterprise only. LOOKUP only:
# precedence resolution + detection, mirroring governance.distribution's
# _resolve_url shape. Actual application (workspace/governance/trustedKeys/
# secrets/identity) is the ENTERPRISE step below (FTR-MSO-2026-0482,
# team/enterprise only) — pro still stops at "detected" here (§3.2a: pro
# gets the core wizard + optional profile lookup, not the enterprise steps).
# ---------------------------------------------------------------------------

_ENROLMENT_PROFILE_ENV = "MAESTRO_ENROLMENT_PROFILE"


def _resolve_enrolment_profile_path(ctx: "SetupContext") -> "tuple[str | None, str]":
    """Precedence chain (§3.3): --profile > env var > ~/.maestro/enrolment.json
    > .mso/config/enrolment.json > none. Never called for community — gated
    structurally by this step's ``applies_to``, so community performs no
    filesystem/env probe at all (§12 AC)."""
    if ctx.profile_path:
        return str(ctx.profile_path), "--profile"
    env = os.environ.get(_ENROLMENT_PROFILE_ENV, "").strip()
    if env:
        return env, _ENROLMENT_PROFILE_ENV
    from maestro.workspace import maestro_home_file
    home_profile = maestro_home_file("enrolment.json")
    if home_profile.exists():
        return str(home_profile), "~/.maestro/enrolment.json"
    adm_dir = _find_mso_dir()
    if adm_dir is not None:
        ws_profile = adm_dir / "config" / "enrolment.json"
        if ws_profile.exists():
            return str(ws_profile), f"{MSO_DIR_NAME}/config/enrolment.json"
    return None, ""


def _step_profile_lookup(ctx: "SetupContext") -> None:
    print("\n[PROFILE] Enrolment profile\n")
    path, source = _resolve_enrolment_profile_path(ctx)
    if path is None:
        if ctx.tier == "enterprise":
            print(
                "  ⚠ No enrolment profile found — running ungoverned. An Enterprise "
                "device should have one; see maestro/docs/ENTERPRISE-SETUP.md."
            )
        else:
            print(
                "  No enrolment profile found — core setup only. An admin-authored "
                "profile can automate the rest."
            )
        return
    print(f"  Profile detected: {path} (via {source})")
    if ctx.tier in ("team", "enterprise"):
        print("  Applying enterprise settings from the profile next (secrets, identity, governance)…")
    else:
        print(
            "  This tier does not apply enrolment-profile settings automatically "
            "(only team/enterprise do) — detected only."
        )


# ---------------------------------------------------------------------------
# ENTERPRISE SECURITY — new in FTR-MSO-2026-0482, team/enterprise only.
# Applies the resolved+verified enrolment profile (workspace/governance/
# trustedKeys/secrets — maestro.enrolment.apply.apply_profile) and, when the
# profile requests it, seeds identity (maybe_seed_identity). §3.2a: these
# steps are appended only when a profile actually resolves — an absent
# profile is a silent no-op here (profile_lookup already printed the
# pointer/warning above), never a half-configured governance state (§4.2
# team guarantee: zero governance.* keys written when no profile is found).
# ---------------------------------------------------------------------------

def _step_enterprise_security(ctx: "SetupContext") -> None:
    from maestro.enrolment.loader import resolve_profile
    from maestro.enrolment.schema import EnrolmentError
    from maestro.enrolment.apply import apply_profile, maybe_seed_identity, ApplyError
    from maestro.governance.schema import GovernanceError

    adm_dir = _find_mso_dir()
    ws_root = adm_dir.parent if adm_dir is not None else Path.cwd()

    try:
        resolved = resolve_profile(source=ctx.profile_path, workspace=ws_root)
    except (EnrolmentError, GovernanceError) as exc:
        msg = f"enrolment profile rejected: {exc}"
        print(f"\n[ENTERPRISE] ✗ {msg}")
        ctx.fail(msg)
        return

    if resolved is None:
        return  # no profile found — core setup only, nothing to apply (§4.2)

    profile = resolved.profile
    print(f"\n[ENTERPRISE] Applying enrolment profile '{profile.bundle_id}' (source: {resolved.source})\n")

    try:
        apply_profile(profile, workspace=ws_root, current_tier=ctx.tier)
    except (ApplyError, EnrolmentError) as exc:
        msg = f"enrolment profile '{profile.bundle_id}' refused: {exc}"
        print(f"  ✗ {msg}")
        ctx.fail(msg)
        return

    print("  ✓ Profile applied to workspace.json.")

    if profile.secrets:
        print("\n  Secrets provider configured from profile — running `mso secrets doctor`:")
        from maestro.cli import _secrets_doctor
        try:
            _secrets_doctor(ws_root)
        except SystemExit as exc:
            code = exc.code if isinstance(exc.code, int) else 1
            if code != 0:
                print(f"  ⚠ secrets doctor reported issues (exit {code}) — see above.")

    try:
        seed_result = maybe_seed_identity(profile, workspace=ws_root)
    except Exception as exc:  # noqa: BLE001 — never abort the wizard on this optional step
        print(f"\n  ⚠ Identity seeding failed: {exc}")
        seed_result = None
    if seed_result is not None:
        print(f"\n  ✓ Identity seeded at {seed_result['identity_dir']}.")


# ---------------------------------------------------------------------------
# STEP 4 — requirement templates
# ---------------------------------------------------------------------------

def _offer_template_generation(ctx: "SetupContext") -> None:
    """Step 4: offer to generate a starter order from a requirement template."""
    import datetime

    from maestro.templates_loader import (
        list_builtin_templates,
        list_custom_templates,
        render_template,
    )

    adm_dir = _find_mso_dir()
    if adm_dir is None:
        print("  ⚠ No Maestro workspace (.mso/) found — skipping template generation.")
        return

    builtin = list_builtin_templates()
    custom = list_custom_templates(adm_dir)
    all_templates = builtin + [t for t in custom if t not in builtin]

    print("  Available built-in templates:")
    for name in builtin:
        print(f"    • {name}")
    if custom:
        print("  Custom templates:")
        for name in custom:
            marker = " (overrides built-in)" if name in builtin else ""
            print(f"    • {name}{marker}")

    if ctx.non_interactive or not _ask("\n  Generate a starter order from a template?", default="n"):
        return

    print("\n  Enter template name (or press Enter to skip): ", end="", flush=True)
    try:
        chosen = input().strip()
    except EOFError:
        chosen = ""

    if not chosen:
        return

    if chosen not in all_templates:
        print(f"  ✗ Unknown template '{chosen}'. Skipping.")
        return

    # Collect minimal fields
    print(f"\n  Filling in '{chosen}' template fields (press Enter to use placeholder):\n")
    def _field(label: str, placeholder: str = "TBD") -> str:
        try:
            val = input(f"    {label} [{placeholder}]: ").strip()
        except EOFError:
            val = ""
        return val or placeholder

    title = _field("Title", "New order title")
    scope = _field("Scope / affected component", "TBD")
    background = _field("Background", "TBD")
    notes = _field("Additional notes", "")

    # Derive type from template name
    _type_map = {
        "new-feature": "FTR",
        "project-setup": "FTR",
        "security-review": "SEC",
        "test-coverage": "FTR",
        "doc-audit": "DOC",
        "bug-report": "BUG",
        "performance": "FTR",
        "refactor": "FTR",
    }
    order_type = _type_map.get(chosen, "FTR")

    # Determine project and next sequence
    import json as _json
    project = "PRJ"
    ws_path = adm_dir / "config" / "workspace.json"
    if ws_path.exists():
        try:
            ws = _json.loads(ws_path.read_text(encoding="utf-8"))
            project = ws.get("project", "PRJ")
        except Exception:
            pass

    year = datetime.datetime.now().year
    proposed_dir = adm_dir / "queues" / "proposed"
    proposed_dir.mkdir(parents=True, exist_ok=True)
    # BUG-MSO-2026-0752: continue past the highest sequence in the whole
    # workspace, not a count of proposals — `len(existing) + 1` reissued the
    # number of every order, voyage or chart already past it.
    from maestro.core.order_ids import highest_existing_sequence
    seq = highest_existing_sequence(adm_dir, project, str(year)) + 1
    order_id = f"{order_type}-{project}-{year}-{seq:04d}"

    context = {
        "order_id": order_id,
        "title": title,
        "scope": scope,
        "background": background,
        "notes": notes,
    }

    try:
        rendered = render_template(chosen, context, adm_dir)
    except Exception as exc:
        print(f"  ✗ Render failed: {exc}")
        return

    out_path = proposed_dir / f"{order_id}.md"
    out_path.write_text(rendered, encoding="utf-8")
    print(f"\n  ✓ Starter order written to: {out_path}")
    print("    Review and edit it, then use `mso order` to promote it to the queue.")


# ---------------------------------------------------------------------------
# STEP 2a — SDLC providers (PLAN-PLN-MSO-2026-0747 Order 9)
# ---------------------------------------------------------------------------

# CI-system fingerprints project_analysis.py already gathers (top-level
# .github/workflows, Jenkinsfile — see analyse_project()) mapped to the
# provider id resolve_explain() would use for that CI system. Jenkins is not
# yet registered in maestro.providers._REGISTRY (Order 12) — it is still
# proposed here so an operator sees the gap; set_provider() itself refuses
# an id that is not installed, so nothing partially-supported is written.
_CI_SYSTEM_TO_PROVIDER_ID = {
    "GitHub Actions": "github_actions",
    "Jenkins": "jenkins",
}


def _detect_git_scm_provider(cwd: Path) -> "str | None":
    """SCM provider id proposed from the ``origin`` remote's host.

    github.com -> "github"; bitbucket.org -> "bitbucket" (Order 11, not yet
    registered — same "propose it anyway" reasoning as Jenkins above).
    """
    try:
        result = subprocess.run(
            ["git", "remote", "get-url", "origin"],
            cwd=cwd, capture_output=True, text=True, timeout=2,
        )
        url = result.stdout.strip().lower()
    except Exception:
        return None
    if not url:
        return None
    if "github.com" in url:
        return "github"
    if "bitbucket.org" in url:
        return "bitbucket"
    return None


def _detect_ci_provider(analysis) -> "str | None":
    """CI provider id proposed from project_analysis's ``ci_systems`` list."""
    if analysis is None:
        return None
    for system in getattr(analysis, "ci_systems", None) or []:
        provider_id = _CI_SYSTEM_TO_PROVIDER_ID.get(system)
        if provider_id:
            return provider_id
    return None


def _run_providers_test(workspace: Path) -> None:
    from maestro.providers import config as providers_config

    for kind in ("scm", "ci", "issues"):
        try:
            resolved = providers_config.test_provider(workspace, kind)
        except Exception as exc:
            print(f"    {kind:8s}: test failed — {exc}")
            continue
        status = "available" if resolved.available else f"unavailable ({resolved.reason})"
        print(f"    {kind:8s}: {resolved.provider_id} — {status}")


def _step_sdlc_providers(ctx: "SetupContext") -> None:
    """STEP 2a: detect, propose, ask, and write SCM/CI/issues providers.

    Sits right after project_analysis (whose ``ctx.analysis.ci_systems`` this
    reuses for CI detection) and before workspace_config. Every write goes
    through ``maestro.providers.config`` — the ONE writer (Order 8) — never a
    second write path here.

    Re-running on an already-configured workspace shows the CURRENT
    configured id as the default; accepting that default (or an
    ``--answers`` value equal to it) makes no write at all, so re-running
    setup on a settled workspace is a no-op for this step.
    """
    print("\n[STEP 2a] SDLC providers\n")

    mso_dir = _find_mso_dir()
    if mso_dir is None:
        print("  ⚠ No Maestro workspace (.mso/) found — skipping provider configuration.")
        print("    Run `mso init --project <PRJ>` first.")
        return

    workspace = mso_dir.parent
    from maestro.providers import config as providers_config

    detected = {
        "scm": _detect_git_scm_provider(Path.cwd()),
        "ci": _detect_ci_provider(ctx.analysis),
        "issues": None,
    }

    any_answered = False

    for kind in ("scm", "ci", "issues"):
        try:
            current = providers_config.show_provider(workspace, kind)
        except Exception as exc:
            print(f"  ⚠ Could not read {kind} provider config: {exc}")
            continue

        configured = current.get("configured")
        current_id = configured.get("id") if isinstance(configured, dict) else None
        locked_by = current.get("lockedBy")
        proposal = detected.get(kind)
        default_id = current_id or proposal

        if locked_by:
            print(f"  {kind:8s}: locked to '{locked_by}' by a signed policy bundle — skipping")
            continue

        answer_key = f"providers.{kind}"

        if ctx.non_interactive:
            answer = ctx.answers.get(answer_key)
            if not answer:
                if current_id:
                    print(f"  {kind:8s}: keeping configured '{current_id}' (no answer for {answer_key})")
                elif proposal:
                    print(f"  {kind:8s}: detected '{proposal}' — no answer for {answer_key}, leaving unset")
                else:
                    print(f"  {kind:8s}: nothing detected, nothing configured")
                continue
            if answer == current_id:
                print(f"  {kind:8s}: answers file confirms '{answer}' — no change")
                continue
            try:
                providers_config.set_provider(workspace, kind, answer)
                print(f"  {kind:8s}: set to '{answer}' (from {answer_key})")
                any_answered = True
            except providers_config.ProviderConfigError as exc:
                print(f"  ⚠ {kind}: {exc}")
            continue

        # Interactive.
        if proposal and proposal != current_id:
            suffix = f" (currently '{current_id}')" if current_id else ""
            print(f"  {kind:8s}: detected '{proposal}'{suffix}")
        elif current_id:
            print(f"  {kind:8s}: currently '{current_id}'")
        else:
            print(f"  {kind:8s}: nothing detected, nothing configured")

        if default_id is None:
            continue

        if _ask(f"  Set {kind} provider to '{default_id}'?", default="y"):
            if default_id == current_id:
                continue  # accepted the current value — no write, nothing changed
            try:
                providers_config.set_provider(workspace, kind, default_id)
                print(f"  ✓ {kind} provider set to '{default_id}'")
                any_answered = True
            except providers_config.ProviderConfigError as exc:
                print(f"  ⚠ {kind}: {exc}")
                if exc.hint:
                    print(f"    → {exc.hint}")
        else:
            print(f"  (skipped — {kind} provider unchanged)")

    if ctx.non_interactive:
        if any_answered:
            _run_providers_test(workspace)
    elif _ask("  Test configured providers now?", default="y"):
        _run_providers_test(workspace)


# ---------------------------------------------------------------------------
# STEP 2b — model backend (FTR-MSO-2026-0872)
#
# Registered as "2b" beside "2a" rather than as a new numbered step: a new
# number would renumber the original six, which the golden-transcript test and
# the FTR-MSO-2026-0478 registry comment both treat as a regression.
#
# Every write goes through ``maestro.providers.config.set_provider`` — the ONE
# writer. This step never opens ``workspace.json`` itself, which is what makes
# the credential guard in ``providers/config.py`` unbypassable from here.
# ---------------------------------------------------------------------------

#: The CLOSED set of config keys this step may ever write. No credential-shaped
#: name is in it and none can be constructed at runtime — ``awsProfile`` is a
#: profile NAME, which is exactly why it passes the ``providers.config``
#: credential guard. Order 9 (SEC) reviews this set; keep it closed.
_MODEL_BACKEND_CONFIG_KEYS: "tuple[str, ...]" = (
    "endpoint",
    "region",
    "regionPrefix",
    "awsProfile",
    "pinRoleDefaults",
    "modelMap",
)

#: Loose, deliberately: AWS adds regions, and Maestro refusing a real one is a
#: worse failure than accepting a typo the probe will catch anyway. A miss
#: WARNS, never refuses.
_AWS_REGION_RE = re.compile(r"^[a-z]{2}(-gov)?-[a-z]+-\d+$")

#: The one paste a hurried operator actually makes at a profile prompt.
_AWS_ACCESS_KEY_RE = re.compile(r"^(AKIA|ASIA)[0-9A-Z]{12,}$")

#: (provider id, endpoint, label) — the three offerable backends, in menu order.
_MODEL_BACKEND_CHOICES: "tuple[tuple[str, str, str], ...]" = (
    ("anthropic", "", "Direct Anthropic API — the shipped default"),
    ("bedrock", "invoke", "AWS Bedrock"),
    ("bedrock", "mantle", "AWS Bedrock via Mantle"),
)

#: Printed once, above the profile prompt. The login sequence is the Captain's
#: own (F6) and is checked by Order 9. ``ccb``/``cca`` are named ONLY to say
#: that they are interactive-shell aliases this wizard neither configures nor
#: invokes — a crew is a detached subprocess with no shell.
_AWS_LOGIN_GUIDANCE = (
    "    Maestro does not log you in, and never stores an AWS credential.\n"
    "    Sign in yourself first:\n"
    "      aws sso login --profile <name>   (or `aws login` for Management Console credentials)\n"
    "      -> a browser opens -> the session is time-boxed and will need repeating when it expires.\n"
    "    Credentials then come from the AWS credential chain at dispatch time.\n"
    "    (`ccb` / `cca` are interactive-shell aliases, not part of this configuration: a crew is a\n"
    "     detached subprocess with no shell, so Maestro composes the backend environment itself\n"
    "     from the block this step writes.)"
)


def _prompt_text(label: str, default: str = "") -> str:
    """Free-text prompt; a blank answer or EOF degrades to *default*.

    The caller composes the WHOLE label, including any ``[default]`` hint, so
    the region prompt can carry its provenance inline (D3).
    """
    try:
        answer = input(f"{label}: ").strip()
    except EOFError:
        return default
    return answer or default


def _as_bool(value: "object", default: bool) -> bool:
    """A config value as a bool, accepting the string forms the flat,
    string-only ``--config`` CLI produces. Mirrors ``BedrockModelProvider._bool``
    in behaviour but never imports it — this runs before any provider exists."""
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    text = str(value).strip().lower()
    if text in ("1", "true", "yes", "on"):
        return True
    if text in ("0", "false", "no", "off"):
        return False
    return default


def _parse_model_map_answer(text: str) -> "dict[str, str]":
    """``"claude-opus-5=anthropic.claude-x,claude-haiku-4-5=..."`` -> dict.

    A malformed pair is WARNED about and skipped rather than raising — one
    fat-fingered comma must not lose the pairs either side of it.
    """
    out: "dict[str, str]" = {}
    for chunk in (text or "").split(","):
        item = chunk.strip()
        if not item:
            continue
        canonical, sep, native = item.partition("=")
        canonical, native = canonical.strip(), native.strip()
        if not sep or not canonical or not native:
            print(f"    ⚠ ignoring '{item}' — expected canonical=native")
            continue
        out[canonical] = native
    return out


def _probe_candidate_backend(
    provider_id: str, config: dict, workspace: "Path | None"
) -> "tuple[str, str]":
    """``(state, reason)`` for a CANDIDATE, as-yet-unwritten config (D5).

    ``probe()`` rather than ``available()``: ``available()`` collapses
    *indeterminate* into ``True``, and the third state is exactly what decides
    whether the "write anyway?" that follows defaults yes or no (ADR-3).

    Never raises. Anything unexpected degrades to *indeterminate*, which by
    ADR-3 never blocks a write.
    """
    try:
        from maestro.providers import _REGISTRY

        provider_cls = _REGISTRY.get("model", {}).get(provider_id)
        if provider_cls is None:
            return "indeterminate", f"no installed model provider '{provider_id}'"
        provider = provider_cls(
            dict(config), workspace=Path(workspace) if workspace else None
        )
        probe = getattr(provider, "probe", None)
        if callable(probe):
            state, reason = probe()
            return str(state), str(reason or "")
        ok, detail = provider.available()
        return ("available" if ok else "unavailable"), str(detail or "")
    except Exception as exc:  # noqa: BLE001 — contract: never raises
        return "indeterminate", f"probe failed: {type(exc).__name__}"


def _prompt_bedrock_config(
    ctx: "SetupContext", current_cfg: dict, endpoint: str, workspace: Path
) -> dict:
    """Build the candidate ``bedrock`` config: endpoint -> region -> prefix ->
    profile -> pinRoleDefaults -> optional modelMap.

    Only keys in :data:`_MODEL_BACKEND_CONFIG_KEYS` can appear in the result —
    the starting dict is filtered to that set, and nothing below writes a key
    outside it. No credential is prompted for, and there is no field for one.
    """
    from maestro.providers.model.bedrock import BedrockModelProvider

    cfg = {k: v for k, v in (current_cfg or {}).items() if k in _MODEL_BACKEND_CONFIG_KEYS}
    cfg["endpoint"] = endpoint

    # -- region (D3) — ALWAYS asked, ALWAYS written ------------------------
    region_default, source = BedrockModelProvider(
        config=dict(current_cfg or {}), workspace=workspace
    ).resolve_region()

    if ctx.non_interactive:
        answered_region = (ctx.answers.get("providers.model.region") or "").strip()
        region = answered_region or region_default
        if answered_region:
            print(f"    region: {region} (from providers.model.region)")
        else:
            print(f"    region: {region} (no answer for providers.model.region — "
                  f"pinning the resolved value, source: {source})")
    else:
        if source == "default":
            print(f"    Nothing on this machine sets an AWS region — "
                  f"Maestro would fall back to {region_default}.")
            label = f"    AWS region [{region_default}]"
        else:
            if source.startswith("profile:"):
                provenance = f"from the '{source.split(':', 1)[1]}' profile in ~/.aws/config"
            elif source == "config":
                provenance = "currently set in workspace.json"
            else:
                provenance = f"from the {source} environment variable"
            label = f"    AWS region [{region_default}] ({provenance})"
        region = _prompt_text(label, region_default)

    if not _AWS_REGION_RE.match(region):
        print(f"    ⚠ '{region}' does not look like an AWS region name — accepting it anyway.")
    # Written even when it equals the fallback: an accepted fallback is an
    # explicit, recorded choice, not a value re-derived on another machine
    # whose AWS_REGION says something else (D3 point 3).
    cfg["region"] = region

    # -- inference profile prefix (D3a) ------------------------------------
    answered_prefix = (ctx.answers.get("providers.model.regionPrefix") or "").strip()
    pinned_prefix = str(cfg.get("regionPrefix") or "").strip()
    prefix = BedrockModelProvider(config=dict(cfg), workspace=workspace).resolve_prefix()
    if pinned_prefix:
        print(f"    region {region} -> inference-profile prefix '{prefix}' "
              f"(pinned by regionPrefix={pinned_prefix})")
    else:
        print(f"    region {region} -> inference-profile prefix '{prefix}'")

    warn_prefix = (
        not pinned_prefix
        and prefix in ("apac.", "us-gov.")
        and cfg["endpoint"] in ("invoke", "both")
    )
    if warn_prefix:
        print(f"    ⚠ Not every Claude model is served by the '{prefix}' inference profile — the")
        print("      Bedrock documentation lists Claude Haiku 4.5 as unavailable on apac/jp. If a")
        print("      model is refused, set regionPrefix=global (the global inference profile) or")
        print("      map that one model explicitly with modelMap.")

    if ctx.non_interactive:
        if answered_prefix:
            cfg["regionPrefix"] = answered_prefix
    elif warn_prefix and _ask(
        f"    Use the global inference profile instead of '{prefix}'?", default="n"
    ):
        cfg["regionPrefix"] = "global"

    # -- AWS profile NAME (D4) — never a credential ------------------------
    profile_default = str(cfg.get("awsProfile") or "")
    if ctx.non_interactive:
        profile = (ctx.answers.get("providers.model.awsProfile") or profile_default).strip()
    else:
        print(_AWS_LOGIN_GUIDANCE)
        hint = profile_default or "(none — use the default credential chain)"
        profile = profile_default
        for _attempt in range(3):
            profile = _prompt_text(f"    AWS profile name [{hint}]", profile_default).strip()
            if profile and _AWS_ACCESS_KEY_RE.match(profile):
                print("    ✗ That looks like an AWS access key id. Maestro never stores AWS")
                print("      credentials — this asks for a named profile from ~/.aws/config.")
                print("      Credentials come from the AWS credential chain.")
                profile = ""
                continue
            break

    if profile and _AWS_ACCESS_KEY_RE.match(profile):
        # Belt and braces for the non-interactive path and for an answer that
        # survived three interactive attempts: refused here, so it never
        # reaches set_provider (AC2b).
        print("    ✗ Refusing an AWS access key id as a profile name — leaving awsProfile unset.")
        profile = ""

    if profile:
        cfg["awsProfile"] = profile
    else:
        cfg.pop("awsProfile", None)

    # -- pinRoleDefaults ---------------------------------------------------
    pinned_now = _as_bool(cfg.get("pinRoleDefaults"), True)
    if ctx.non_interactive:
        answered_pin = ctx.answers.get("providers.model.pinRoleDefaults")
        pin = _as_bool(answered_pin, pinned_now) if answered_pin is not None else pinned_now
    else:
        pin = _ask(
            "    Pin the per-role model defaults (ANTHROPIC_DEFAULT_*_MODEL) to their Bedrock ids?",
            default="y" if pinned_now else "n",
        )
    if pin == pinned_now and "pinRoleDefaults" not in cfg:
        pass  # the shipped default already says this — adding the key changes nothing
    else:
        cfg["pinRoleDefaults"] = pin

    # -- optional modelMap -------------------------------------------------
    existing_map = cfg.get("modelMap") if isinstance(cfg.get("modelMap"), dict) else {}
    if ctx.non_interactive:
        raw_map = (ctx.answers.get("providers.model.modelMap") or "").strip()
    else:
        if existing_map:
            pairs = ", ".join(f"{k}={v}" for k, v in sorted(existing_map.items()))
            print(f"    Current modelMap: {pairs}")
        raw_map = _prompt_text(
            "    Model id overrides (canonical=native, comma-separated; blank for none)", ""
        ).strip()
    if raw_map:
        parsed = _parse_model_map_answer(raw_map)
        if parsed:
            cfg["modelMap"] = {**existing_map, **parsed}

    return {k: v for k, v in cfg.items() if k in _MODEL_BACKEND_CONFIG_KEYS}


def _print_resolved_model_backend(workspace: Path) -> None:
    """The resolved line after a write — provider id, tier and availability
    (AC1), read back through ``show_provider`` rather than composed from what
    we just asked for."""
    from maestro.providers import config as providers_config

    try:
        payload = providers_config.show_provider(workspace, "model")
    except Exception as exc:  # noqa: BLE001
        print(f"    (could not read back the resolved model backend: {exc})")
        return
    resolved = payload.get("resolved") or {}
    status = (
        "available" if resolved.get("available")
        else f"unavailable — {resolved.get('reason')}"
    )
    print(f"    resolved: {resolved.get('providerId')} "
          f"(tier: {resolved.get('tier')}) — {status}")


def _step_model_backend(ctx: "SetupContext") -> None:
    """STEP 2b: choose the model backend every crew's Claude session runs against.

    Structured exactly like :func:`_step_sdlc_providers`: workspace lookup and
    early ``return`` come BEFORE any prompt, so the no-workspace path calls
    ``input()`` zero times (the golden-transcript test supplies exactly one
    input value for the whole wizard).

    Accepting the current backend writes nothing at all (D6), so re-running
    ``mso setup`` on a settled workspace leaves ``workspace.json``
    byte-identical.
    """
    print("\n[STEP 2b] Model backend\n")

    mso_dir = _find_mso_dir()
    if mso_dir is None:
        print("  ⚠ No Maestro workspace (.mso/) found — skipping model backend configuration.")
        print("    Run `mso init --project <PRJ>` first.")
        return

    workspace = mso_dir.parent
    from maestro import auth
    from maestro.providers import DEFAULT_MODEL_BACKEND_ID
    from maestro.providers import config as providers_config

    try:
        current = providers_config.show_provider(workspace, "model")
    except Exception as exc:  # noqa: BLE001
        print(f"  ⚠ Could not read model provider config: {exc}")
        return

    locked_by = current.get("lockedBy")
    if locked_by:
        print(f"  model   : locked to '{locked_by}' by a signed policy bundle — skipping")
        return

    configured = current.get("configured")
    current_id = configured.get("id") if isinstance(configured, dict) else None
    raw_cfg = configured.get("config") if isinstance(configured, dict) else None
    current_cfg = dict(raw_cfg) if isinstance(raw_cfg, dict) else {}
    current_endpoint = str(current_cfg.get("endpoint") or "invoke").lower()
    effective_id = current_id or DEFAULT_MODEL_BACKEND_ID

    if current_id:
        detail = f" (endpoint: {current_endpoint})" if current_id == "bedrock" else ""
        print(f"  Current backend: {current_id}{detail}")
    else:
        print(f"  Current backend: {DEFAULT_MODEL_BACKEND_ID} "
              "(the shipped default — nothing configured in workspace.json)")

    # -- tier gate (D2) — never require_tier, which sys.exit(1)s -----------
    tier = ctx.tier or ""
    bedrock_allowed = (
        tier in auth.MODEL_BACKEND_TIERS if tier else auth.has_tier(auth.MODEL_BACKEND_TIERS)
    )
    if not bedrock_allowed:
        allowed = "/".join(sorted(auth.MODEL_BACKEND_TIERS))
        if (tier or "community") == "community":
            # FTR-MSO-2026-0478 §3.2a rule 1 — the community transcript is
            # LICENCE-SILENT, and
            # tests/test_setup_wizard_tiers.py::
            # test_community_non_interactive_transcript_is_licence_silent
            # asserts it names no "licence"/"profile"/"trial"/"upgrade" at all.
            # That invariant predates this step and wins over the plan's D2
            # wording: community is told which backend it is on and that
            # Bedrock is a higher-tier one, and is sold nothing. Every OTHER
            # sub-Enterprise tier gets the full message, escape hatch included.
            print(f"  AWS Bedrock is an {allowed.title()}-tier backend — "
                  "not offered at this tier.")
            return
        print(f"  AWS Bedrock requires an {allowed} licence (this workspace resolves to "
              f"'{tier}') — not offered here.")
        print("    Activate one with `mso licence activate <KEY>`, or stage the configuration")
        print("    ahead of activation with:")
        print("      mso providers set model bedrock --config region=ap-southeast-2 "
              "--config awsProfile=<profile>")
        return

    # -- choose the backend -------------------------------------------------
    if current_id == "bedrock":
        current_choice = 3 if current_endpoint == "mantle" else 2
    else:
        current_choice = 1

    if ctx.non_interactive:
        answer = (ctx.answers.get("providers.model") or "").strip()
        if not answer:
            print("  (no answer for providers.model — backend unchanged)")
            return
        if answer not in ("anthropic", "bedrock"):
            ctx.fail(f"providers.model: unknown model backend '{answer}' "
                     "(expected 'anthropic' or 'bedrock')")
            return
        chosen_id = answer
        chosen_endpoint = ""
        if chosen_id == "bedrock":
            chosen_endpoint = (
                ctx.answers.get("providers.model.endpoint") or current_endpoint
            ).strip().lower()
            if chosen_endpoint not in ("invoke", "mantle", "both"):
                chosen_endpoint = "invoke"
    else:
        print("\n  Which backend should every crew's Claude session run against?")
        for index, (_pid, _endpoint, label) in enumerate(_MODEL_BACKEND_CHOICES, start=1):
            marker = " (current)" if index == current_choice else ""
            print(f"    {index}) {label}{marker}")
        raw = _prompt_text(f"  Backend [{current_choice}]", str(current_choice))
        try:
            index = int(raw)
        except ValueError:
            index = current_choice
        if not 1 <= index <= len(_MODEL_BACKEND_CHOICES):
            index = current_choice
        chosen_id, chosen_endpoint, _label = _MODEL_BACKEND_CHOICES[index - 1]

    # -- direct Anthropic ---------------------------------------------------
    if chosen_id == "anthropic":
        if effective_id == "anthropic":
            print("  (unchanged — crews already run against the direct Anthropic API)")
            return
        try:
            providers_config.set_provider(workspace, "model", "anthropic", {})
        except providers_config.ProviderConfigError as exc:
            print(f"  ⚠ model: {exc}")
            if getattr(exc, "hint", ""):
                print(f"    -> {exc.hint}")
            return
        print("  ✓ model backend set to 'anthropic' (the direct Anthropic API)")
        _print_resolved_model_backend(workspace)
        return

    # -- Bedrock ------------------------------------------------------------
    candidate = _prompt_bedrock_config(ctx, current_cfg, chosen_endpoint, workspace)

    if chosen_endpoint in ("mantle", "both") and not str(
        current_cfg.get("mantleBaseUrl") or ""
    ).strip():
        print("    Note: no mantleBaseUrl is configured. Set one with")
        print("      mso providers set model bedrock --config mantleBaseUrl=<url>")
        print("    (this step deliberately writes no URL or credential field).")

    # The probe runs against the CANDIDATE config, BEFORE any write (D5).
    state, reason = _probe_candidate_backend("bedrock", candidate, workspace)
    if state == "available":
        print("    ✓ AWS credentials look usable.")
    elif state == "indeterminate":
        print(f"    ? Could not determine credential state — {reason}")
    else:
        print(f"    ✗ {reason}")

    if not ctx.non_interactive and state != "available":
        # ADR-3: an indeterminate probe must NEVER block a write, so it asks
        # with a yes default; only a positive "unavailable" defaults to no.
        if not _ask(
            "    Write the configuration anyway?",
            default="y" if state == "indeterminate" else "n",
        ):
            print("    (not written — model backend unchanged)")
            return

    if current_id == "bedrock" and candidate == current_cfg:
        print("  (unchanged — the configuration you accepted is already in workspace.json)")
        return

    try:
        providers_config.set_provider(workspace, "model", "bedrock", candidate)
    except providers_config.ProviderConfigError as exc:
        print(f"  ⚠ model: {exc}")
        if getattr(exc, "hint", ""):
            print(f"    -> {exc.hint}")
        return

    print(f"  ✓ model backend set to 'bedrock' (region {candidate.get('region')}, "
          f"endpoint {candidate.get('endpoint')})")
    _print_resolved_model_backend(workspace)


def _ask(prompt: str, default: str = "y") -> bool:
    """Prompt yes/no; returns True for yes."""
    indicator = "[Y/n]" if default.lower() == "y" else "[y/N]"
    try:
        answer = input(f"{prompt} {indicator}: ").strip().lower()
    except EOFError:
        return default.lower() == "y"
    if not answer:
        return default.lower() == "y"
    return answer in ("y", "yes")


# ---------------------------------------------------------------------------
# STEP 5 — contextual next-steps cheatsheet
# ---------------------------------------------------------------------------

def _step_next_steps(ctx: "SetupContext") -> None:
    # BUG fixed via Copilot review on PR #67: previous wizard never surfaced
    # the cheatsheet rules from FTR-ADM-2026-0110, so operators saw zero
    # contextual guidance after setup. Now we always print it before signing off.
    print("\n[STEP 5] Suggested next steps\n")
    try:
        from maestro.setup_cheatsheet import generate_cheatsheet
        print(generate_cheatsheet(ctx.analysis, ctx.results))
    except Exception as exc:
        print(f"  ⚠ Cheatsheet generation failed: {exc}")


def _step_workspace_config(ctx: "SetupContext") -> None:
    print("\n[STEP 3] Workspace configuration\n")
    _configure_workspace(ctx)


def _step_pack_selection(ctx: "SetupContext") -> None:
    print("\n[STEP 3a] Division pack selection\n")
    _select_pack(ctx)


def _step_templates(ctx: "SetupContext") -> None:
    print("\n[STEP 4] Requirement templates\n")
    _offer_template_generation(ctx)


# ---------------------------------------------------------------------------
# The step registry (FTR-MSO-2026-0478 §3.3).
#
# The six original steps carry ``applies_to=None`` (every tier) and are
# provably byte-identical in content and order to pre-refactor `main` — each
# still prints its own hardcoded "[STEP N]" header exactly as before. LICENCE,
# PROFILE, and ENTERPRISE_SECURITY are new, tier-restricted, and use distinct
# (non-numeric) headers, so they never renumber or otherwise perturb the
# original six.
#
# PACK_SELECTION (FTR-MSO-2026-0480, PLAN-PLN-MSO-2026-0449 §6.2) is also new
# but, unlike LICENCE/PROFILE/ENTERPRISE_SECURITY, carries ``applies_to=None``
# — every tier, including community, sees this step by design: a community
# user should see what division packs they are missing, not a shorter step
# list with no explanation (§6.2). It is byte-identical to a no-op at its
# default answer ('sdlc') for every tier (plan §4.1 anti-leak guarantee #1),
# and never itself probes for an enrolment profile at community tier (§3.2a
# rule 1 — delegated to ``_select_pack``'s own tier gate). Community's
# filtered step list is therefore the original six PLUS this one, in the
# order below — the golden-transcript no-regression guarantee for the
# original six's own content/order still falls out of this structure.
# ---------------------------------------------------------------------------

SETUP_STEPS: "list[SetupStep]" = [
    SetupStep("persona", "Workstation setup — persona", _step_persona, applies_to=None),
    SetupStep("prereqs", "Prerequisite checks", _step_prereqs, applies_to=None),
    SetupStep("licence", "Licence", _step_licence, applies_to={"pro", "team", "enterprise"}),
    SetupStep("project_analysis", "Project analysis", _step_project_analysis, applies_to=None),
    SetupStep("sdlc_providers", "SDLC providers", _step_sdlc_providers, applies_to=None),
    # FTR-MSO-2026-0872: "2b" beside "2a" — the same configure-the-providers
    # phase, and it renumbers none of the original six. applies_to=None for
    # the reason pack_selection records: a community operator should SEE what
    # backend they are on and learn Bedrock exists and needs an Enterprise
    # licence, not silently get a shorter step list with no explanation.
    SetupStep("model_backend", "Model backend", _step_model_backend, applies_to=None),
    SetupStep("workspace_config", "Workspace configuration", _step_workspace_config, applies_to=None),
    SetupStep("pack_selection", "Division pack selection", _step_pack_selection, applies_to=None),
    SetupStep("profile_lookup", "Enrolment profile", _step_profile_lookup, applies_to={"pro", "team", "enterprise"}),
    SetupStep("enterprise_security", "Enterprise security onboarding", _step_enterprise_security, applies_to={"team", "enterprise"}),
    SetupStep("templates", "Requirement templates", _step_templates, applies_to=None),
    SetupStep("next_steps", "Suggested next steps", _step_next_steps, applies_to=None),
]


def interactive_setup(
    *,
    profile: "str | None" = None,
    non_interactive: bool = False,
    answers: "dict | None" = None,
) -> None:
    """Run the setup wizard.

    FTR-MSO-2026-0478: tier is resolved ONCE here, via
    ``licence.resolve_state()`` — read only (§3.2a rule 2) — and then used to
    filter :data:`SETUP_STEPS` by ``applies_to``. A STOPPED licence (Team/
    Enterprise past its 14-day grace, §D3b) refuses before any step runs,
    matching ``auth.check()``'s existing behaviour.

    ``non_interactive=True`` must never call ``input()`` — every step that
    would otherwise prompt is gated on this flag instead.
    """
    from maestro import __version__
    from maestro.licence import resolve_state

    _p = current_persona()

    print(f"\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print(f" {_p.term('product')} Setup Wizard — v{__version__}")
    print(f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n")

    state = resolve_state()
    if state.stopped:
        print(state.warning or f"Maestro {state.tier} licence STOPPED.")
        sys.exit(1)

    ctx = SetupContext(
        tier=state.effective_tier,
        non_interactive=non_interactive,
        profile_path=profile,
        answers=answers or {},
        licence_state=state,
    )

    for step in SETUP_STEPS:
        if step.applies_to is not None and ctx.tier not in step.applies_to:
            continue
        step.run(ctx)

    if ctx.errors:
        print("\n[Maestro] Setup could not complete non-interactively:")
        for err in ctx.errors:
            print(f"  ✗ {err}")
        sys.exit(1)

    print(f"\nSetup complete. Run `mso status` to see your {_p.term('team').lower()}.")
