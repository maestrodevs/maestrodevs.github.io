"""maestro/providers/model/bedrock.py — the AWS Bedrock model backend.

PLAN-PLN-MSO-2026-0864 Order 3 (FTR-MSO-2026-0867), added beside ``anthropic``
exactly as ``ci/jenkins`` was added beside ``ci/github_actions``: purely
additively, with one new line in ``providers._REGISTRY``.

This module composes the environment a crew subprocess needs in order to talk
to Bedrock, translates Maestro's canonical model ids into Bedrock's own, and
reports — cheaply and honestly — whether AWS credentials look usable. It does
**not** touch dispatch: ``crew.invoke_claude`` calling ``env_overlay()`` is
Order 4 and the dispatch gate is Order 5, so until those land this code is
reachable only from ``mso providers show|test model`` and its own tests.

ADR-1 — configuration, never credentials
----------------------------------------
Everything here is driven by ``providers.model.bedrock.config`` in
``workspace.json``. **There is deliberately no config field for an AWS access
key, secret key, session token or bearer token** — not "they must be ``env:``
references", they *do not exist*. A crew inherits ``os.environ`` via
``os.environ.copy()``, so ``AWS_ACCESS_KEY_ID``, ``AWS_SESSION_TOKEN`` and
``AWS_BEARER_TOKEN_BEDROCK`` already reach it from the dispatcher's own
environment without ever passing through ``workspace.json``. Adding a field for
one would put a resolved secret in the dict :meth:`env_overlay` returns — one
refactor away from a lifecycle log. ``awsProfile`` is a profile NAME, which is
why it passes ``providers.config``'s credential-name guard; that guard is the
seam ADR-1 chose to sit behind.

ADR-2 — translation is explicit, and an unmapped model REFUSES
--------------------------------------------------------------
Canonical first-party ids (``claude-opus-5``) stay the id written everywhere in
the artefact plane; ``core_constants.SUPPORTED_MODEL_IDS`` is never widened
with Bedrock ids, which would multiply by region prefix and ARN form and make
an overlay written on Bedrock un-loadable on the direct API. The table below is
**explicit, never derived**: a ``{prefix}.anthropic.{canonical}`` rule is wrong
for Haiku 4.5 — whose ARN-versioned profile carries a date *and* ``-v1:0`` —
and cannot express an application-inference-profile ARN at all. A model with no
entry raises :class:`ModelUnavailableOnBackend` naming the model, the backend,
the region/prefix in force and the ``modelMap`` key to set. It never falls back
to a different model: Claude Code's own startup check silently downgrades an
unavailable pin, which for an unattended fleet would mean an order planned for
Opus 5 quietly running on something cheaper with no record of it.

ADR-3 — the probe is cheap, never raises, and has THREE states
--------------------------------------------------------------
``aws sts get-caller-identity`` (the credential check AWS's own documentation
prescribes) behind a short timeout, skipped entirely when
``AWS_BEARER_TOKEN_BEDROCK`` is set because a bearer token does not use the
credential chain. When the ``aws`` CLI is absent the answer is
**indeterminate, not unavailable** — a machine authenticating by instance role
or a pre-exported key pair has working credentials and no ``aws`` binary, and
reporting failure there would (once Order 5 lands) hold dispatch on a fleet
that works. Maestro never runs ``aws sso login``; the read-only
``get-caller-identity`` is the only AWS command in this module.

ADR-5 — Mantle is a MODE, not a sixth provider kind
---------------------------------------------------
``endpoint`` selects ``"invoke"`` (the ``bedrock-runtime`` InvokeModel path,
region-prefixed inference-profile ids), ``"mantle"`` (the Messages-API endpoint
at ``bedrock-mantle.{region}.api.aws``, whose ids are ``anthropic.``-prefixed
and suffix-free), or ``"both"`` — the two may legitimately run together, routed
by id shape. Each endpoint has its own map.

Four traps in the surrounding code shaped this module's API. They are recorded
here because each looks like an eccentricity from the inside:

* **``mso providers set --config`` is flat and string-only**
  (``cli.py:_parse_provider_config_args``), so a nested-only ``modelMap`` would
  be unreachable from the CLI — while the refusal message promises a runnable
  ``--config <key>=<id>`` command. Hence both shapes are accepted and merged,
  flat dotted winning; see :meth:`_effective_map`. ``_parse_provider_config_args``
  is shared by all five provider kinds and is deliberately NOT changed.
* **The credential-name guard is a substring match that includes ``auth``**
  (``providers/config.py:_CREDENTIAL_FIELD_RE``), so the obvious spelling
  ``mantleSkipAuth`` would be refused with ``InvalidCredentialError`` unless its
  value were ``env:…`` — absurd for a boolean. The field is therefore named
  **``mantleSkipSignin``**. Every field name here was checked against that regex.
* **``auth.require_tier()`` calls ``sys.exit(1)``** (``auth.py:429``), so it can
  never be reached from ``providers.resolve_explain``, whose contract is "never
  raises" and which ``mso doctor``, the Hub and (Order 5) the dispatcher all
  call. This module declares :data:`required_tiers` and uses the non-exiting
  :meth:`tier_ok`; the exiting call belongs at Order 4's crew-launch choke point.
* **``available() -> (bool, str)`` cannot express ADR-3's *indeterminate***, and
  ``resolve_explain`` discards the reason whenever ``ok`` is true. Hence
  :meth:`probe`, which carries the tri-state, with :meth:`available` derived
  from it in one place so the two can never disagree. :meth:`probe` lives here
  rather than on ``ModelBackendProvider`` so ``anthropic`` is not forced to grow
  a probe it deliberately does not have.

No ``boto3``, no ``botocore``, no new dependency: ``configparser``,
``shutil.which``, ``os.environ`` and ``maestro.core.proc.run_hidden`` are the
whole toolkit. (``boto3`` exists elsewhere in Maestro — lazily imported by the
audit anchors and the AWS secrets provider, behind optional extras — but it is
not a dependency of the dispatch path and must not become one.)
"""

from __future__ import annotations

import configparser
import os
import shutil
import subprocess
from pathlib import Path
from typing import Any, Optional

from maestro import auth
from maestro.core_constants import canonical_model_id
from maestro.providers.model.base import ModelBackendProvider, ModelUnavailableOnBackend

__all__ = [
    "DEFAULT_PREFIX",
    "DEFAULT_REGION",
    "PROBE_TIMEOUT_SECONDS",
    "REGION_PREFIXES",
    "SHIPPED_MANTLE_MODEL_MAP",
    "SHIPPED_MODEL_MAP",
    "BedrockModelProvider",
]


# --------------------------------------------------------------------------
# Translation tables (ADR-2)
# --------------------------------------------------------------------------
#
# VERIFIED AGAINST ANTHROPIC/AWS DOCUMENTATION 2026-09-20:
#   https://platform.claude.com/docs/en/build-with-claude/claude-on-amazon-bedrock-legacy
#       (InvokeModel on bedrock-runtime; ARN-versioned ids + the inference-profile
#        prefix table. Claude Haiku 4.5 is listed there verbatim as
#        `anthropic.claude-haiku-4-5-20251001-v1:0`, with global/us/eu = Yes and
#        jp/apac = No.)
#   https://platform.claude.com/docs/en/build-with-claude/claude-in-amazon-bedrock
#       (the Messages-API "Mantle" endpoint; ids carry an `anthropic.` provider
#        prefix and NO region prefix — the region lives in the host,
#        bedrock-mantle.{region}.api.aws.)
#
# The legacy page states that Claude Opus 5, Sonnet 5, Fable 5/5.1 and Opus
# 4.7/4.8 are reachable through InvokeModel but are "omitted from the model
# table ... because they do not have ARN-versioned model IDs" — they are served
# by the same infrastructure as the Mantle endpoint. That is why the current
# generation is suffix-free on BOTH maps while Haiku 4.5 is not: exactly the
# asymmetry a derived rule cannot express.

#: Canonical Maestro id -> Bedrock native id for the ``invoke`` endpoint,
#: WITHOUT the inference-profile prefix (:meth:`BedrockModelProvider._apply_prefix`
#: adds it, and guards against adding it twice).
SHIPPED_MODEL_MAP: dict[str, str] = {
    "claude-opus-5": "anthropic.claude-opus-5",
    "claude-sonnet-5": "anthropic.claude-sonnet-5",
    "claude-haiku-4-5": "anthropic.claude-haiku-4-5-20251001-v1:0",
    # claude-fable-5-1 is DELIBERATELY ABSENT.
    #
    # The 2026-09-20 documentation check above DOES list Fable 5.1 on the
    # Mantle endpoint (`anthropic.claude-fable-5-1`, access "Open"), so the
    # order's "unverified on Bedrock" premise is weaker than when it was
    # written — that finding is recorded in this order's BLD-to-TST handoff.
    # It is still shipped absent, deliberately: FTR-MSO-2026-0867's body
    # reserves Fable 5.1 to INV Order 12 ("never assumed") against the
    # client's real account, and a wrong-but-PRESENT mapping is the single
    # failure mode ADR-2's refusal cannot protect against, whereas a refusal
    # names the exact key to set and is recoverable in one command. Order 12
    # lands a one-line change here; a guess here lands a silently wrong model.
}

#: Canonical Maestro id -> Bedrock native id for the ``mantle`` endpoint.
#: Applied VERBATIM — never region-prefixed (ADR-5; the region is in the host).
SHIPPED_MANTLE_MODEL_MAP: dict[str, str] = {
    "claude-opus-5": "anthropic.claude-opus-5",
    "claude-sonnet-5": "anthropic.claude-sonnet-5",
    "claude-haiku-4-5": "anthropic.claude-haiku-4-5",
    # claude-fable-5-1: absent for the same reason as above.
}


# --------------------------------------------------------------------------
# Region + inference-profile prefix (D2/D3)
# --------------------------------------------------------------------------

#: An ORDERED tuple, longest-match-first, rather than a dict: ``us-gov-`` MUST
#: be tested before ``us-``, and making that a property of the data means it
#: cannot be lost by whoever next iterates it. A GovCloud fleet silently routed
#: to the commercial partition is the worst outcome this module can produce.
REGION_PREFIXES: tuple[tuple[str, str], ...] = (
    ("us-gov-", "us-gov."),
    ("us-", "us."),
    ("eu-", "eu."),
    ("ap-", "apac."),
)

#: The prefix for any region matching no row above (e.g. ``sa-east-1``,
#: ``af-south-1``, ``me-central-1`` — all of which Bedrock serves from the
#: global endpoint).
DEFAULT_PREFIX = "global."

#: Every prefix this module recognises, used by the double-prefix guard.
_KNOWN_PREFIXES: tuple[str, ...] = tuple(p for _, p in REGION_PREFIXES) + (DEFAULT_PREFIX,)

#: Where the region resolution chain ends — the value used when *nothing* said
#: (not ``config.region``, not ``AWS_REGION``/``AWS_DEFAULT_REGION``, not the
#: profile's own region). Every one of those still wins, unchanged, so a
#: workspace, operator or profile that states a region is unaffected by this.
#:
#: ``ap-southeast-2`` rather than AWS's own example region ``us-east-1``
#: (Captain revision, FTR-MSO-2026-0868 D8): this fleet is Australian-based,
#: and for an Australian operator a silent fallback to ``us-east-1`` is a
#: data-residency surprise that *works* — a wrong-but-working default is worse
#: than a wrong-and-loud one, because nothing ever reports it.
#:
#: **Caveat, record rather than rediscover:** ``ap-southeast-2`` matches
#: ``("ap-", "apac.")`` in :data:`REGION_PREFIXES`, so an unconfigured
#: workspace translates to ``apac.anthropic.…``. FTR-MSO-2026-0867's own
#: documentation check recorded Haiku 4.5 as ``apac = No`` on the legacy
#: InvokeModel page, so a Haiku-pinned role on an unconfigured APAC workspace
#: is refused *by Bedrock*, not by Maestro — set ``region`` explicitly, or map
#: the model, rather than spending an hour on it. Which inference profiles the
#: client's account actually carries is PLAN-PLN-MSO-2026-0864's Order 12.
DEFAULT_REGION = "ap-southeast-2"

#: ADR-3: "cheap". Well inside a dispatcher tick, and a timeout is reported as
#: INDETERMINATE rather than as evidence the credentials are bad.
PROBE_TIMEOUT_SECONDS = 10

_ENDPOINTS: tuple[str, ...] = ("invoke", "mantle", "both")

#: The role-default pins (D5). Explicit rather than derived from the catalogue
#: for the same reason as the translation tables: a rule that picks "the current
#: model of family X" is one release away from picking a different one silently.
#: These stop Claude Code's own alias path reaching for a model this backend
#: cannot serve.
_ROLE_DEFAULT_PINS: tuple[tuple[str, str], ...] = (
    ("ANTHROPIC_DEFAULT_OPUS_MODEL", "claude-opus-5"),
    ("ANTHROPIC_DEFAULT_SONNET_MODEL", "claude-sonnet-5"),
    ("ANTHROPIC_DEFAULT_HAIKU_MODEL", "claude-haiku-4-5"),
)

#: Substrings in ``aws`` output that identify a cause we can describe better
#: than the raw text can. Ordered: the first match wins.
_PROBE_SIGNATURES: tuple[tuple[str, str, bool], ...] = (
    ("token has expired", "the AWS SSO session has expired", True),
    ("expiredtoken", "the AWS session token has expired", True),
    ("refresh failed", "the AWS SSO session could not be refreshed", True),
    ("sso session associated", "no valid AWS SSO session", True),
    ("invalidclienttokenid", "the AWS credentials were rejected (invalid access key id)", False),
    ("signaturedoesnotmatch", "the AWS credentials were rejected (signature mismatch)", False),
    ("accessdenied", "the AWS credentials lack sts:GetCallerIdentity permission", False),
    ("could not be found", "the configured AWS profile was not found", False),
    ("unable to locate credentials", "no AWS credentials could be located", False),
)

_TRUTHY = frozenset({"1", "true", "yes", "on"})
_FALSEY = frozenset({"0", "false", "no", "off", ""})


class BedrockModelProvider(ModelBackendProvider):
    """``providers.model = {"id": "bedrock", "config": {...}}``."""

    id = "bedrock"

    #: The CONSTANT, never a ``{"enterprise"}`` literal:
    #: ``tests/test_ftr_0865_model_catalogue.py`` derives its expected upgrade
    #: message from the set that is passed in, so a literal here would pass that
    #: test while defeating its purpose the next time the tier set changes.
    #: Declaring it is not enforcing it — the exiting ``auth.require_tier()``
    #: call belongs at Order 4's crew-launch choke point, because a
    #: ``workspace.json`` copied between machines never passes through
    #: ``providers.config.set_provider``.
    required_tiers = auth.MODEL_BACKEND_TIERS

    def __init__(self, config: dict[str, Any] | None = None, workspace: Optional[Path] = None) -> None:
        super().__init__(config)
        # Needed by EgressFilter.from_workspace (D6). The resolver passes
        # workspace= for every provider id that is not "none".
        self._workspace = Path(workspace) if workspace else None

    # -- config accessors --------------------------------------------------

    def _str(self, field: str) -> str:
        """A config field as a stripped string, or ``""``. Never raises.

        An unknown config key is IGNORED rather than refused: ``set_provider``
        has no per-provider schema, and refusing here would be a second,
        divergent validation layer. ``mso doctor`` (Order 6) is where a typo'd
        key becomes visible.
        """
        value = self.config.get(field)
        if value is None or isinstance(value, (dict, list, bool)):
            return ""
        return str(value).strip()

    def _bool(self, field: str, default: bool) -> bool:
        """A config field as a bool, accepting the string forms the flat,
        string-only CLI can produce (TRAP A). An unrecognised value falls back
        to *default* rather than raising — this runs on the dispatch path."""
        value = self.config.get(field)
        if value is None:
            return default
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in _TRUTHY:
            return True
        if text in _FALSEY:
            return False
        return default

    def _endpoint(self) -> str:
        """``"invoke"`` (the shipped default), ``"mantle"`` or ``"both"``.

        An unrecognised value resolves to the default rather than raising: the
        cost of a typo must not be a dead dispatcher.
        """
        value = self._str("endpoint").lower()
        return value if value in _ENDPOINTS else "invoke"

    def _effective_map(self, field: str) -> dict[str, str]:
        """The shipped default for *field*, overlaid with the workspace's own.

        Accepts BOTH shapes, because ``mso providers set --config`` is flat and
        string-only (TRAP A) while a hand-edit, the Hub or ``mso setup`` produce
        a nested dict::

            "modelMap":                 {"claude-opus-5": "..."}   # nested
            "modelMap.claude-sonnet-5": "..."                       # flat dotted

        Flat dotted wins over a nested entry for the same canonical id — it is
        the more specific, more recently-typed form, and it is the spelling
        :class:`ModelUnavailableOnBackend`'s ``config_key`` names, so the command
        the refusal prints is literally copy-pasteable.

        Keys are canonicalised on the way in, so a workspace that pins the dated
        ``claude-haiku-4-5-20251001`` spelling maps onto the same entry.
        """
        shipped = SHIPPED_MANTLE_MODEL_MAP if field == "mantleModelMap" else SHIPPED_MODEL_MAP
        merged: dict[str, str] = dict(shipped)

        nested = self.config.get(field)
        if isinstance(nested, dict):
            for key, value in nested.items():
                if isinstance(key, str) and isinstance(value, str) and value.strip() and key.strip():
                    merged[canonical_model_id(key.strip())] = value.strip()

        dotted = f"{field}."
        for key, value in self.config.items():
            if not isinstance(key, str) or not key.startswith(dotted):
                continue
            if not isinstance(value, str) or not value.strip():
                continue
            canon = key[len(dotted):].strip()
            if canon:
                merged[canonical_model_id(canon)] = value.strip()

        return merged

    # -- region + prefix (D2/D3) -------------------------------------------

    def resolve_region(self) -> tuple[str, str]:
        """``(region, source)`` by the documented precedence. **Never raises.**

        ``source`` is carried so Order 4 can log where the region came from and
        Order 6 can say "falling back to ap-southeast-2 because nothing set one" —
        a resolved region with no provenance is the hard thing to debug.
        """
        configured = self._str("region")
        if configured:
            return configured, "config"

        for var in ("AWS_REGION", "AWS_DEFAULT_REGION"):
            value = os.environ.get(var, "").strip()
            if value:
                return value, var

        profile = self._str("awsProfile")
        from_profile = self._region_from_profile(profile)
        if from_profile:
            return from_profile, f"profile:{profile or 'default'}"

        return DEFAULT_REGION, "default"

    def _region_from_profile(self, profile: str) -> str:
        """The ``region`` key of the AWS shared config file, or ``""``.

        ``configparser`` from the stdlib, never ``boto3``: Maestro has no AWS
        dependency and must not acquire one for a four-line INI read. Every
        failure — missing file, permission error, malformed INI, missing key —
        falls through silently, which is load-bearing because
        :meth:`env_overlay` calls this on the dispatch path.
        """
        try:
            raw = os.environ.get("AWS_CONFIG_FILE", "").strip()
            path = Path(raw) if raw else Path.home() / ".aws" / "config"
            if not path.is_file():
                return ""
            parser = configparser.ConfigParser()
            parser.read(path, encoding="utf-8")
            # The shared config file names the default profile "[default]" and
            # every other one "[profile <name>]".
            section = "default" if not profile or profile == "default" else f"profile {profile}"
            if parser.has_option(section, "region"):
                return (parser.get(section, "region") or "").strip()
        except Exception:  # noqa: BLE001 — never raises, by contract
            return ""
        return ""

    def resolve_prefix(self) -> str:
        """The inference-profile prefix, INCLUDING its trailing dot.

        Called by BOTH :meth:`env_overlay` and :meth:`resolve_model_id`, which
        is the substantive point: a workspace whose ``ANTHROPIC_BEDROCK_REGION_PREFIX``
        and whose translated ids disagreed about the prefix would fail in a way
        nobody could read.

        The ambient environment variable is honoured (step 2) so that exporting
        it works as an operator would expect, not only configuring it.
        """
        for candidate in (
            self._str("regionPrefix"),
            os.environ.get("ANTHROPIC_BEDROCK_REGION_PREFIX", ""),
        ):
            normalised = self._normalise_prefix(candidate)
            if normalised:
                return normalised

        region, _source = self.resolve_region()
        lowered = region.lower()
        for pattern, prefix in REGION_PREFIXES:
            if lowered.startswith(pattern):
                return prefix
        return DEFAULT_PREFIX

    @staticmethod
    def _normalise_prefix(value: str) -> str:
        """``"global"`` / ``"global."`` / ``" global.. "`` -> ``"global."``.

        Accepting both spellings matters because the acceptance criterion is
        written as ``ANTHROPIC_BEDROCK_REGION_PREFIX=global`` — without the dot —
        while the prefix must carry exactly one dot when concatenated.
        """
        text = (value or "").strip()
        if not text:
            return ""
        return text.rstrip(".") + "." if text.strip(".") else ""

    # -- translation (D4/D4a) ----------------------------------------------

    def resolve_model_id(self, canonical: str) -> str:
        """Canonical Maestro id -> Bedrock native id. Refuses, never substitutes.

        *canonical* is BARE: ``[1m]`` is stripped and re-attached by the
        inherited :meth:`~maestro.providers.model.base.ModelBackendProvider.translate_model_arg`,
        whose docstring explains why that rule lives there once rather than in
        each backend. This method neither accepts nor emits the suffix.
        """
        canon = canonical_model_id(canonical)
        endpoint = self._endpoint()

        # "both" means both endpoints are live and Claude Code routes by id
        # shape — but Maestro still has to choose ONE id to emit, and
        # "whichever, first one wins" is not a rule. Invoke is consulted first,
        # falling back to the Mantle map only when the id is absent from it.
        if endpoint == "mantle":
            consulted: tuple[tuple[str, bool], ...] = (("mantleModelMap", True),)
        elif endpoint == "both":
            consulted = (("modelMap", False), ("mantleModelMap", True))
        else:
            consulted = (("modelMap", False),)

        for field, is_mantle in consulted:
            mapped = self._effective_map(field).get(canon)
            if mapped:
                return self._apply_prefix(mapped, mantle=is_mantle)

        region, _source = self.resolve_region()
        key_field = "mantleModelMap" if endpoint == "mantle" else "modelMap"
        raise ModelUnavailableOnBackend(
            canon,
            "bedrock",
            detail=f"region {region} (prefix {self.resolve_prefix()!r}), endpoint {endpoint}",
            config_key=f"{key_field}.{canon}",
        )

    def _apply_prefix(self, value: str, *, mantle: bool) -> str:
        """Apply the inference-profile prefix to a mapped value — or don't.

        Three values are emitted VERBATIM:

        * anything starting ``arn:`` — an application-inference-profile ARN is
          already fully qualified;
        * anything already carrying a known prefix — the guard against
          ``us.us.anthropic.…`` when an operator pastes a fully-prefixed id out
          of the AWS console into ``modelMap``, which they will;
        * every Mantle value, always (ADR-5) — Mantle ids are ``anthropic.``-
          prefixed and suffix-free, and the region is in the endpoint host, so
          a region prefix on one is simply wrong.
        """
        if mantle or value.startswith("arn:"):
            return value
        if value.startswith(_KNOWN_PREFIXES):
            return value
        return f"{self.resolve_prefix()}{value}"

    def canonicalise_model_id(self, native: str) -> str:
        """Bedrock native id -> canonical Maestro id (FTR-MSO-2026-0868 D9).

        The reverse of :meth:`resolve_model_id`, needed because a model id also
        travels backwards: ``fleet_usage_tracker`` takes the model from the
        Claude transcript, which on this backend is the native id. Without this
        every Bedrock crew would write ``apac.anthropic.claude-opus-5`` into
        ``.mso/usage/`` — a second vocabulary in the artefact plane, which
        ADR-2 exists to prevent — and ``resolve_pricing`` would miss it.

        **Derived from the same tables, so there is no second vocabulary to
        drift.** The reverse map is built by running each canonical key of the
        effective maps through :meth:`_apply_prefix` — literally the forward
        transform — rather than by parsing a native id's shape. The maps are
        consulted in the same order :meth:`resolve_model_id` consults them, so
        a canonical id that both endpoints serve resolves the same way in both
        directions.

        A candidate carrying ANY of :data:`_KNOWN_PREFIXES` also matches
        against the raw (unprefixed) map value, not only against the prefix
        this provider currently resolves. That is not guessing — the prefix
        list is this module's own closed set, and the remainder still has to
        match a map value exactly — and it is the realistic case: the region
        can differ between the crew that ran and the process that later parses
        its transcript (``config`` in one, ``default`` in the other), and a
        usage record holding ``us.anthropic.claude-opus-5`` because the reader
        happened to resolve ``apac.`` is precisely the artefact-plane leak this
        method exists to prevent.

        *native* is BARE — the ``[1m]`` selector is Maestro's own construct and
        the caller strips it (``fleet_usage_tracker`` already does, one line
        above the call).

        An unrecognised *native* is returned **unchanged, never guessed**: an
        odd string in a usage record is visible and investigable; a wrongly
        canonicalised one is a silent mis-attribution of cost. Never raises —
        this runs while a usage record is being written, and a broken map must
        cost a wrong label, not a lost record.
        """
        if not isinstance(native, str) or not native.strip():
            return native
        candidate = native.strip()

        # The same candidate with any known inference-profile prefix removed.
        # `None` when it carries none — which is itself matched by `mapped`
        # below, since the shipped maps are stored unprefixed.
        unprefixed = ""
        if not candidate.startswith("arn:"):
            for prefix in _KNOWN_PREFIXES:
                if candidate.startswith(prefix):
                    unprefixed = candidate[len(prefix):]
                    break

        endpoint = self._endpoint()
        if endpoint == "mantle":
            consulted: tuple[tuple[str, bool], ...] = (("mantleModelMap", True),)
        elif endpoint == "both":
            consulted = (("modelMap", False), ("mantleModelMap", True))
        else:
            consulted = (("modelMap", False),)

        fallback = ""
        for field, is_mantle in consulted:
            try:
                effective = self._effective_map(field)
            except Exception:  # noqa: BLE001 — a broken map costs a label, not the record
                continue
            for canonical, mapped in effective.items():
                if not mapped:
                    continue
                try:
                    emitted = self._apply_prefix(mapped, mantle=is_mantle)
                except Exception:  # noqa: BLE001
                    emitted = mapped
                if candidate == emitted:
                    return canonical
                if not fallback and mapped in (candidate, unprefixed):
                    fallback = canonical

        return fallback or native

    # -- environment composition (D5/D6) -----------------------------------

    def env_overlay(self) -> dict[str, str]:
        """The variables a crew subprocess needs. Fresh dict, all ``str``.

        **Never raises and never mutates ``os.environ``.** This runs on the
        dispatch path, so every branch that could fail degrades to omitting one
        variable rather than propagating — see the per-pin handling below.
        """
        overlay: dict[str, str] = {}
        try:
            endpoint = self._endpoint()
            invoke_on = endpoint in ("invoke", "both")
            mantle_on = endpoint in ("mantle", "both")

            if invoke_on:
                overlay["CLAUDE_CODE_USE_BEDROCK"] = "1"
            if mantle_on:
                overlay["CLAUDE_CODE_USE_MANTLE"] = "1"

            region, _source = self.resolve_region()
            overlay["AWS_REGION"] = region

            profile = self._str("awsProfile")
            if profile:
                overlay["AWS_PROFILE"] = profile

            if invoke_on:
                overlay["ANTHROPIC_BEDROCK_REGION_PREFIX"] = self.resolve_prefix()

                base_url = self._str("baseUrl")
                if base_url and self._egress_ok(base_url)[0]:
                    overlay["ANTHROPIC_BEDROCK_BASE_URL"] = base_url

            service_tier = self._str("serviceTier")
            if service_tier:
                overlay["ANTHROPIC_BEDROCK_SERVICE_TIER"] = service_tier

            if mantle_on:
                mantle_url = self._str("mantleBaseUrl")
                if mantle_url and self._egress_ok(mantle_url)[0]:
                    overlay["ANTHROPIC_BEDROCK_MANTLE_BASE_URL"] = mantle_url
                # Emitted ONLY as "1" when truthy, and omitted entirely when
                # falsey — never "0". A tri-state variable that Claude Code may
                # read as "present => on" must not be handed a value we are
                # guessing about.
                if self._bool("mantleSkipSignin", False):
                    overlay["CLAUDE_CODE_SKIP_MANTLE_AUTH"] = "1"

            if self._bool("pinRoleDefaults", True):
                for var, canon in _ROLE_DEFAULT_PINS:
                    try:
                        overlay[var] = self.resolve_model_id(canon)
                    except Exception:  # noqa: BLE001
                        # Best-effort PER PIN. A fleet whose Haiku is unmapped
                        # must still be able to run its Opus orders; an omitted
                        # pin is a far smaller problem than a dead dispatch
                        # path, and Order 6's `mso doctor` check is where a
                        # missing pin becomes visible.
                        continue
        except Exception:  # noqa: BLE001 — contract: never raises
            pass

        # Coerced because the mapping goes straight into subprocess(env=...),
        # where a non-string raises.
        return {str(key): str(value) for key, value in overlay.items()}

    def _egress_ok(self, url_or_host: str) -> tuple[bool, str]:
        """Check a host against the workspace egress allowlist, failing CLOSED.

        Same call ``scm/bitbucket.py:_egress_ok`` makes, and the literal
        ``host not permitted`` prefix matters: ``resolve_explain`` surfaces that
        reason unwrapped instead of nesting it in its generic shape. A blocked
        host means the variable is OMITTED from the overlay — never
        emitted-and-hoped. A permissive workspace imposes no restriction, so
        this is a no-op for nearly everyone.
        """
        host = self._hostname(url_or_host)
        if not host:
            return False, f"host not permitted: '{url_or_host}' is not a parseable host"
        try:
            from maestro.egress.filter import EgressFilter

            allowed = EgressFilter.from_workspace(self._workspace).is_allowed(host)
        except Exception as exc:  # noqa: BLE001 — fail CLOSED
            return False, (
                f"host not permitted: egress policy could not be evaluated "
                f"({type(exc).__name__}); refusing to route crew traffic"
            )
        if not allowed:
            return False, f"host not permitted: '{host}' is not in allowedDestinations"
        return True, ""

    @staticmethod
    def _hostname(url_or_host: str) -> str:
        """The host of a URL, or the value itself when it is already bare."""
        try:
            from urllib.parse import urlparse

            text = (url_or_host or "").strip()
            if not text:
                return ""
            parsed = urlparse(text if "//" in text else f"//{text}")
            return (parsed.hostname or "").strip()
        except Exception:  # noqa: BLE001
            return ""

    # -- availability (D7 / TRAP C / TRAP D) -------------------------------

    def tier_ok(self) -> tuple[bool, str]:
        """Non-exiting tier check. ``auth.has_tier`` never raises and honours
        ``MAESTRO_SKIP_AUTH``; ``auth.require_tier`` — which ``sys.exit(1)``s —
        must never be reached from anything ``resolve_explain`` calls."""
        if auth.has_tier(auth.MODEL_BACKEND_TIERS):
            return True, ""
        return False, "the AWS Bedrock backend requires an Enterprise licence"

    def probe(self) -> tuple[str, str]:
        """``("available" | "unavailable" | "indeterminate", reason)``. Never raises.

        The third state is the whole point (ADR-3): *indeterminate* means "this
        process could not determine credential state", which is not evidence of
        failure and must not hold dispatch. Collapsing it into ``unavailable``
        would stop a fleet that authenticates by instance role from dispatching
        at all.
        """
        try:
            ok, reason = self.tier_ok()
            if not ok:
                return "unavailable", reason

            endpoint = self._endpoint()
            urls = []
            if endpoint in ("invoke", "both"):
                urls.append(self._str("baseUrl"))
            if endpoint in ("mantle", "both"):
                urls.append(self._str("mantleBaseUrl"))
            for url in urls:
                if url:
                    allowed, why = self._egress_ok(url)
                    if not allowed:
                        return "unavailable", why

            # A bearer token does not use the credential chain, so
            # get-caller-identity would be irrelevant to whether it works.
            if os.environ.get("AWS_BEARER_TOKEN_BEDROCK", "").strip():
                return "available", ""

            if shutil.which("aws") is None:
                return "indeterminate", (
                    "the AWS CLI is not on PATH — credential state could not be determined"
                )

            profile = self._str("awsProfile")
            region, _source = self.resolve_region()
            command = ["aws", "sts", "get-caller-identity"]
            if profile:
                command += ["--profile", profile]
            command += ["--region", region]

            try:
                from maestro.core.proc import run_hidden

                completed = run_hidden(
                    command, capture_output=True, text=True, timeout=PROBE_TIMEOUT_SECONDS
                )
            except subprocess.TimeoutExpired:
                # A timeout is not evidence the credentials are bad.
                return "indeterminate", (
                    f"aws sts get-caller-identity timed out after {PROBE_TIMEOUT_SECONDS}s"
                )
            except Exception as exc:  # noqa: BLE001 — OSError and friends
                return "indeterminate", f"probe failed: {type(exc).__name__}"

            if getattr(completed, "returncode", 1) == 0:
                return "available", ""
            return "unavailable", self._explain_probe_failure(completed, profile)
        except Exception as exc:  # noqa: BLE001 — contract: never raises
            return "indeterminate", f"probe failed: {type(exc).__name__}"

    def _explain_probe_failure(self, completed: Any, profile: str) -> str:
        """Our OWN sentence for a failed probe — derived, never pasted.

        ``aws`` emits things like "Error when retrieving token from sso: Token
        has expired and refresh failed". That text lands in ``lifecycle.log``,
        so it is matched against known signatures and replaced with a short
        sentence plus the exact remedy. Unmatched output degrades to its FIRST
        line, capped — never raw AWS output echoed wholesale.
        """
        raw = ""
        for stream in ("stderr", "stdout"):
            value = getattr(completed, stream, None)
            if value:
                raw = f"{raw}\n{value}" if raw else str(value)
        lowered = raw.lower()

        for needle, sentence, is_expiry in _PROBE_SIGNATURES:
            if needle in lowered:
                if is_expiry:
                    remedy = f"aws sso login --profile {profile}" if profile else "aws sso login"
                    return f"{sentence} — run `{remedy}`"
                return sentence

        first_line = next((line.strip() for line in raw.splitlines() if line.strip()), "")
        if not first_line:
            return "aws sts get-caller-identity failed with no output"
        if len(first_line) > 200:
            first_line = first_line[:197] + "..."
        return f"aws sts get-caller-identity failed: {first_line}"

    def available(self) -> tuple[bool, str]:
        """The inherited two-state contract, derived from :meth:`probe` in ONE
        place so the two answers can never disagree.

        *indeterminate* maps to ``(True, "")`` deliberately: ``resolve_explain``
        discards the reason whenever ``ok`` is true, so there is nowhere to put
        it here — callers that need the third state (Order 5's dispatch gate,
        Order 6's ``mso doctor`` check) consult :meth:`probe` directly.
        """
        state, reason = self.probe()
        return (state != "unavailable"), ("" if state != "unavailable" else reason)
