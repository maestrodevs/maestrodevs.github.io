"""maestro/providers/model/anthropic.py — the direct Anthropic API backend.

The shipped default, and what every Maestro workspace has used since before
model backends were configurable at all (FTR-MSO-2026-0866,
PLAN-PLN-MSO-2026-0864 Order 2).

**This provider's whole job is to change nothing.** Order 2's acceptance is
negative: a workspace with no ``providers.model`` block must produce a crew
command line and subprocess environment byte-identical to the pre-voyage
build. Each of the three methods below is written to that standard, and each
says why — these are not stubs waiting to be filled in, they are the
behaviour.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Optional

from maestro.providers.model.base import ModelBackendProvider

__all__ = ["AnthropicModelProvider"]


class AnthropicModelProvider(ModelBackendProvider):
    """``providers.model = {"id": "anthropic"}`` — and the default when the
    block is absent entirely."""

    id = "anthropic"

    #: Not tier-gated. The direct API is what an unlicensed community
    #: workspace already uses; gating it would gate dispatch itself. Mirrors
    #: ``auth.UNGATED_MODEL_BACKEND_IDS``, which names this id.
    required_tiers = None

    #: The ONE backend for which ``fleet_usage_tracker.PRICING`` *is* the bill
    #: (FTR-MSO-2026-0871, ADR-4). Every other backend inherits ``False`` from
    #: :class:`ModelBackendProvider` and reports ``unpriced`` until its
    #: operator supplies ``pricingOverrides`` — see that attribute's docstring
    #: for why the default has that polarity.
    #:
    #: This line is what keeps the negative acceptance true: a workspace with
    #: no ``providers.model`` block resolves to this provider and therefore to
    #: first-party pricing, so its usage records and ``mso usage`` output are
    #: byte-identical to the pre-order build.
    prices_at_first_party_list = True

    def __init__(self, config: dict[str, Any] | None = None, workspace: Optional[Path] = None) -> None:
        super().__init__(config)
        # Kept for symmetry with every other provider's constructor (the
        # resolver passes `workspace=` to any provider id that is not
        # "none"), and so a later diagnostic can name the workspace it was
        # resolved for. Nothing in this provider reads the filesystem.
        self._workspace = Path(workspace) if workspace else None

    def env_overlay(self) -> dict[str, str]:
        """``{}`` — no variables, ever.

        Load-bearing, not an omission. Setting anything here (even a variable
        whose value matches the ambient one) would make the default path
        differ from today's, which is precisely what Order 2's acceptance
        forbids. The direct API is reached through whatever credentials the
        ``claude`` CLI already resolves — an OAuth session or
        ``ANTHROPIC_API_KEY`` in the dispatcher's own environment — and a crew
        inherits those through ``os.environ.copy()`` exactly as before.
        """
        return {}

    def resolve_model_id(self, canonical: str) -> str:
        """The identity function: Maestro's canonical ids ARE this backend's ids.

        Returned unchanged, and never validated against
        ``core_constants.SUPPORTED_MODEL_IDS`` here — that check already
        happens once, in ``crew._validate_model_id``, and a second copy of it
        in the translation layer would be a rule that could drift from the
        first. This method therefore cannot raise
        :class:`~maestro.providers.model.base.ModelUnavailableOnBackend`:
        there is no model in Maestro's vocabulary the direct API does not
        serve, which is exactly what makes this backend the default.
        """
        return canonical

    def available(self) -> tuple[bool, str]:
        """Always ``(True, "")``.

        There is deliberately no probe. The credentials the direct API needs
        are the ``claude`` CLI's own, resolved inside the crew subprocess at
        launch — from an interactive OAuth session, a keychain entry, or an
        environment variable, none of which this process can inspect
        reliably. A probe for, say, ``ANTHROPIC_API_KEY`` would report
        UNAVAILABLE on every workspace that authenticates through the CLI's
        OAuth session, and (once the dispatch gate of Order 5 consults this)
        would hold dispatch on a fleet that is working perfectly. Reporting
        unavailable is only honest when it is TRUE; here it would not be.

        The failure this cannot catch — the ``claude`` CLI itself being
        missing or unauthenticated — is already caught by the preflight smoke
        test (``crew.run_preflight_check``), which runs the real binary.
        """
        return True, ""
