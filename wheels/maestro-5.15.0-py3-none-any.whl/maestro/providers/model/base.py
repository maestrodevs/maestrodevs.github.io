"""maestro/providers/model/base.py — the model-backend capability.

PLAN-PLN-MSO-2026-0864 ADR-1, shipped by FTR-MSO-2026-0866 (Order 2).

A *model backend* is the service a crew's Claude session actually talks to:
the direct Anthropic API (``anthropic`` — the shipped default and what every
workspace has always used) or a third-party backend. It is a per-WORKSPACE
choice, never per-device: two workspaces on one machine must be able to
differ, which is the Captain's stated requirement ("the ability to use either
or when setting up or configuring a Project").

Two capabilities are genuinely new, so they live here on
:class:`ModelBackendProvider` rather than on :class:`maestro.providers.base.Provider`
— the other four provider kinds must not grow them:

* :meth:`ModelBackendProvider.env_overlay` — the environment variables
  injected into every crew subprocess. This is the mechanism that replaces
  "run ``ccb`` before starting an agent": a crew is a detached ``Popen`` of
  the ``claude`` binary with ``env = os.environ.copy()`` and **no shell**
  (``maestro/core/crew.py:2846``), so there is no shell in which a profile
  alias could ever run. Maestro composes the environment itself instead.
* :meth:`ModelBackendProvider.resolve_model_id` — canonical id → backend-native
  id. Its reverse, :meth:`ModelBackendProvider.canonicalise_model_id`
  (FTR-MSO-2026-0868), exists because an id also travels backwards: the usage
  tracker reads the model from the Claude transcript, which on a translating
  backend is the native id. It is the one capability here that is *not*
  abstract — see its own docstring for why an identity default is correct
  there and dangerous for the other two.

**Both are abstract, and deliberately so.** A base-class default would have to
be the identity function, and a backend author who forgot to override it would
ship a fleet that sends untranslated ids to a backend that does not know
them — or, worse, one that silently answers with a different model. ADR-2 is
explicit that an unmapped model must REFUSE; the way to guarantee that is to
make every backend state its translation out loud.

**ADR-2 — canonical first-party ids are Maestro's ONE vocabulary.**
``claude-opus-5`` and its siblings stay the id written in order JSON,
``role-models.json``, role overlays, usage records, the Hub, ``mso status``,
plans and docs. ``core_constants.SUPPORTED_MODEL_IDS`` is **never** widened
with backend ids. Translation happens at exactly one call site — where
``crew.invoke_claude`` builds the ``--model`` argument (Order 4) — so an order
is portable between a workspace on one backend and a workspace on another
without editing a single artefact. That portability *is* the feature.

**A backend never substitutes a model it cannot serve.** It raises
:class:`ModelUnavailableOnBackend`. Claude Code's own startup check silently
falls back to a lower-tier model when a pin is unavailable; for an unattended
fleet that means an order planned for Opus 5 quietly running on something
cheaper with no record of it in the usage table. Maestro must not inherit that
behaviour, and this exception is how it does not.
"""

from __future__ import annotations

from abc import abstractmethod
from typing import Any, Optional

from maestro.core_constants import canonical_model_id
from maestro.providers.base import Provider

__all__ = [
    "CONTEXT_SELECTOR_SUFFIX",
    "PRICING_RATE_KEYS",
    "ModelBackendProvider",
    "ModelUnavailableOnBackend",
    "merge_dotted_config",
]

#: The context-window selector ``crew.invoke_claude`` appends to a model id
#: when a role's ``contextWindow`` is ``1m`` (FTR-MSO-2026-0281). It is a
#: Maestro/Claude-CLI construct, not part of any model id, so translation must
#: strip it before mapping and re-attach it afterwards — see
#: :meth:`ModelBackendProvider.translate_model_arg`.
CONTEXT_SELECTOR_SUFFIX = "[1m]"

#: The four rate keys every pricing entry must carry, in the units the
#: first-party ``fleet_usage_tracker.PRICING`` table already uses: **USD per
#: million tokens**. Same units on purpose — an operator reads one number off
#: their bill and types it in one place, with no arithmetic in between.
PRICING_RATE_KEYS = ("input", "output", "cache_creation", "cache_read")


def merge_dotted_config(
    config: dict[str, Any],
    field: str,
    shipped: Optional[dict[str, Any]] = None,
) -> dict[str, Any]:
    """*shipped* overlaid with *config*'s ``field``, accepting BOTH config shapes.

    ``mso providers set --config`` is flat and string-only
    (``cli.py:_parse_provider_config_args``), while a hand-edit, ``mso setup``
    and the Hub all produce a nested dict. The same value therefore arrives in
    two spellings and both have to work::

        "pricingOverrides": {"claude-opus-5": {"input": 4.20}}   # nested
        "pricingOverrides.claude-opus-5.input": "4.20"            # flat dotted

    Flat dotted wins over a nested entry for the same key — it is the more
    specific, more recently-typed form, and it is the spelling every refusal
    message names, so the command a refusal prints is copy-pasteable.

    The **first** dotted segment is canonicalised with
    :func:`~maestro.core_constants.canonical_model_id` (so a workspace pinning
    the dated ``claude-haiku-4-5-20251001`` spelling lands on the same entry);
    deeper segments are rate/field names and are left alone. Arbitrary depth is
    supported — ``modelMap`` uses one level, ``pricingOverrides`` two.

    **Never raises and never mutates its inputs.** This runs on the dispatch
    and usage-record write paths; *shipped* is a module constant in at least
    one caller, so nested dicts are copied before any write.

    The dual-shape contract was first written for
    ``maestro/providers/model/bedrock.py:_effective_map`` (FTR-MSO-2026-0867);
    this is that contract extracted so ``pricingOverrides`` cannot drift from
    it (FTR-MSO-2026-0871 D4).
    """
    merged: dict[str, Any] = {}
    for key, value in (shipped or {}).items():
        merged[key] = dict(value) if isinstance(value, dict) else value

    if not isinstance(config, dict):
        return merged

    nested = config.get(field)
    if isinstance(nested, dict):
        for key, value in nested.items():
            if not isinstance(key, str) or not key.strip():
                continue
            canon = canonical_model_id(key.strip())
            merged[canon] = dict(value) if isinstance(value, dict) else value

    prefix = f"{field}."
    for key, value in config.items():
        if not isinstance(key, str) or not key.startswith(prefix):
            continue
        path = [segment.strip() for segment in key[len(prefix):].split(".")]
        if not path or not all(path):
            continue
        path[0] = canonical_model_id(path[0])

        cursor = merged
        for segment in path[:-1]:
            child = cursor.get(segment)
            if not isinstance(child, dict):
                # A flat dotted key is the more specific spelling, so it
                # replaces a scalar that occupies the same slot rather than
                # being dropped against it.
                child = {}
                cursor[segment] = child
            cursor = child
        cursor[path[-1]] = value

    return merged


class ModelUnavailableOnBackend(Exception):
    """The configured backend cannot serve the canonical model that was asked for.

    Carries the four things an operator needs to fix it without reading source
    (ADR-2): the canonical model, the backend, whatever narrowing was in force
    (a region/prefix, an endpoint), and the config key to set. The message is
    composed from those fields so every backend reports the refusal the same
    way; ``detail`` and ``config_key`` are optional because a backend may
    genuinely have neither.
    """

    def __init__(
        self,
        canonical: str,
        backend: str,
        *,
        detail: str = "",
        config_key: str = "",
    ) -> None:
        self.canonical = canonical
        self.backend = backend
        self.detail = detail
        self.config_key = config_key

        message = f"model '{canonical}' is not available on the '{backend}' backend"
        if detail:
            message += f" ({detail})"
        if config_key:
            message += (
                f" — map it explicitly with `mso providers set model {backend} "
                f"--config {config_key}=<backend-native id>`"
            )
        super().__init__(message)


def _coerce_rate(value: Any) -> Optional[float]:
    """A config rate as a finite, non-negative float, or ``None``.

    ``str`` is accepted because ``mso providers set --config`` can only produce
    strings; ``bool`` is rejected before the numeric branch because it is an
    ``int`` subclass in Python and ``True`` would otherwise price as $1/MTok.
    """
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, str):
        value = value.strip()
        if not value:
            return None
    try:
        rate = float(value)
    except (TypeError, ValueError):
        return None
    if rate != rate or rate in (float("inf"), float("-inf")) or rate < 0:
        return None
    return rate


class ModelBackendProvider(Provider):
    """Base class for every model backend (``providers.model.<id>``)."""

    kind = "model"

    #: The licence tiers this backend requires, or ``None`` when it is
    #: ungated. Declared here so it is a stated contract rather than a
    #: duck-typed accident: ``tests/test_ftr_0865_model_catalogue.py``'s
    #: forward-binding tripwire reads exactly this attribute and fails any
    #: backend outside ``auth.UNGATED_MODEL_BACKEND_IDS`` that leaves it unset.
    #: A gated backend must ALSO call ``auth.require_tier()`` at the point a
    #: backend is resolved for a crew launch — an attribute alone is a
    #: declaration, not an enforcement, and a ``workspace.json`` copied between
    #: machines never passes through ``providers.config.set_provider``.
    required_tiers: Optional[set[str]] = None

    #: A model backend is a property of the WORKSPACE, not of any one product
    #: repository: every repo of a multi-repo voyage runs its crews on the same
    #: backend, so a ``repo_slug`` handed to ``resolve_explain`` is a no-op for
    #: it rather than a refusal. Read by ``providers.__init__._is_repo_scoped``,
    #: which defaults to ``True`` — every provider that predates
    #: FTR-MSO-2026-0866 keeps its existing behaviour without declaring
    #: anything.
    repo_scoped: bool = False

    #: Whether this backend bills at Anthropic's published first-party list
    #: rates — i.e. whether ``fleet_usage_tracker.PRICING`` IS this backend's
    #: bill (FTR-MSO-2026-0871, PLAN-PLN-MSO-2026-0864 ADR-4).
    #:
    #: **The default is ``False``, and the polarity is the whole point.** A
    #: backend author who forgets this attribute gets ``unpriced`` — visible,
    #: and safe. The other polarity would hand them a fabricated dollar figure
    #: computed from someone else's rate card: invisible, and unsafe, because
    #: ``mso usage --report`` is read to make spend decisions. Same argument
    #: :meth:`resolve_model_id` already makes for refusing rather than
    #: substituting a model.
    #:
    #: Only :class:`~maestro.providers.model.anthropic.AnthropicModelProvider`
    #: overrides it. Bedrock inherits ``False`` and needs no code of its own:
    #: its pricing is partner-operated, varies by region, and differs between
    #: regional and global inference profiles.
    prices_at_first_party_list: bool = False

    def pricing_overrides(self) -> dict[str, dict[str, float]]:
        """``{canonical model id: {input, output, cache_creation, cache_read}}``.

        The operator's own negotiated rates, from
        ``providers.model.<id>.config.pricingOverrides``, in **USD per million
        tokens** — the same units as ``fleet_usage_tracker.PRICING``. Both
        config shapes are accepted (see :func:`merge_dotted_config`).

        **Concrete, not abstract**, for :meth:`canonicalise_model_id`'s reason:
        the failure mode of forgetting to override it is mild and visible (a
        backend reports ``unpriced`` until its operator supplies rates), not
        the silent, severe one the three abstract methods guard against.

        **A partial entry is not an entry.** A model missing any one of the
        four rate keys is omitted entirely rather than having the gap filled
        from the first-party table or from zero. Both of those are a number
        wrong by an unknown margin, which is exactly what ADR-4 exists to
        prevent; the omitted model prices as ``unpriced`` instead, and
        :meth:`pricing_override_gaps` says which key was missing.

        **Never raises.** It is consulted mid-write of a usage record.
        """
        return self._parse_pricing_overrides()[0]

    def pricing_override_gaps(self) -> dict[str, str]:
        """``{canonical model id: "missing 'cache_read'"}`` for entries that are
        PRESENT in ``pricingOverrides`` but unusable.

        Separate from :meth:`pricing_overrides` so that method keeps a single
        clean contract (a rate map that can be trusted), while the pricer can
        still tell an operator who *tried* to configure a model apart from one
        who never mentioned it — the difference between "set
        pricingOverrides..." and "your override for X is missing 'cache_read'".

        **Never raises.**
        """
        return self._parse_pricing_overrides()[1]

    def _parse_pricing_overrides(self) -> tuple[dict[str, dict[str, float]], dict[str, str]]:
        """``(usable rate map, per-model gap reason)``. Never raises."""
        usable: dict[str, dict[str, float]] = {}
        gaps: dict[str, str] = {}
        try:
            raw = merge_dotted_config(self.config or {}, "pricingOverrides")
        except Exception:
            return usable, gaps

        for model, entry in raw.items():
            if not isinstance(model, str) or not model:
                continue
            if not isinstance(entry, dict):
                gaps[model] = "is not a table of the four rate keys"
                continue
            rates: dict[str, float] = {}
            missing: list[str] = []
            for key in PRICING_RATE_KEYS:
                rate = _coerce_rate(entry.get(key))
                if rate is None:
                    missing.append(key)
                else:
                    rates[key] = rate
            if missing:
                gaps[model] = "is missing " + ", ".join(f"'{k}'" for k in missing)
            else:
                usable[model] = rates
        return usable, gaps

    @abstractmethod
    def env_overlay(self) -> dict[str, str]:
        """Environment variables to layer over a crew subprocess's environment.

        Returned fresh on every call and applied by the caller — this method
        never mutates ``os.environ``, because the dispatcher's own environment
        must not acquire a crew's backend settings.

        Every value must be a ``str``: the mapping goes straight into
        ``subprocess`` via ``env=``, where a non-string raises. Returning
        ``{}`` means "change nothing", and is the shipped default's answer.
        """
        raise NotImplementedError

    @abstractmethod
    def resolve_model_id(self, canonical: str) -> str:
        """Translate a **bare** canonical Maestro model id to this backend's own.

        *canonical* never carries the :data:`CONTEXT_SELECTOR_SUFFIX` — that is
        stripped and re-attached by :meth:`translate_model_arg`, so a backend
        implements one mapping and not two.

        Raises :class:`ModelUnavailableOnBackend` when this backend cannot
        serve *canonical*. It must never return a DIFFERENT model's id: a
        substitution the fleet cannot see is worse than a refusal it can.
        """
        raise NotImplementedError

    def translate_model_arg(self, model_arg: str) -> str:
        """:meth:`resolve_model_id`, with the ``[1m]`` selector preserved.

        The one entry point a caller building a ``--model`` argument should
        use. The suffix rule lives here, once, rather than in each backend,
        where a new backend could forget it and silently drop a role's
        1M-context pin.
        """
        if model_arg.endswith(CONTEXT_SELECTOR_SUFFIX):
            bare = model_arg[: -len(CONTEXT_SELECTOR_SUFFIX)]
            return self.resolve_model_id(bare) + CONTEXT_SELECTOR_SUFFIX
        return self.resolve_model_id(model_arg)

    def canonicalise_model_id(self, native: str) -> str:
        """Backend-native id -> canonical Maestro id. The reverse of
        :meth:`resolve_model_id`, and the ONLY one of the four capabilities
        with a safe base implementation (FTR-MSO-2026-0868 D9).

        Why not abstract, when the other three are: an identity reverse-map is
        *correct* for any backend whose :meth:`resolve_model_id` is the
        identity — the ``anthropic`` default inherits this unchanged and is
        right to — and the failure mode of forgetting to override it is the
        mild, visible one (an unrecognised native id appears verbatim in a
        usage record) rather than the severe, invisible one the abstract
        methods guard against (an untranslated id sent to a backend, or a
        silently substituted model).

        Needed because a model id also travels *backwards*: the usage tracker
        reads the model from the Claude transcript, which on a translating
        backend is the native id. Without a reverse map, ``.mso/usage/`` fills
        with backend ids — breaking ADR-2's "canonical ids are Maestro's one
        vocabulary" at the very artefact the fleet prices spend from.

        **An unknown *native* is returned unchanged, never guessed.** An
        unrecognised string in a usage record is a visible oddity someone
        investigates; a wrongly-canonicalised one is a silent mis-attribution
        of cost. Like every other method here, it never raises.
        """
        return native

    @abstractmethod
    def available(self) -> tuple[bool, str]:
        """``(True, "")`` if crews can be launched against this backend right
        now, else ``(False, reason)``. Inherited contract: **never raises**.

        Re-declared abstract here only to keep the three capabilities of a
        model backend visible in one place; the contract is
        :meth:`maestro.providers.base.Provider.available`'s, unchanged.
        """
        raise NotImplementedError

    def probe(self) -> tuple[str, str]:
        """``("available" | "unavailable" | "indeterminate", reason)``. Never raises.

        **Concrete, not abstract** (FTR-MSO-2026-0869): the dispatcher's
        credential gate needs ONE contract for EVERY model backend, and a
        backend whose availability is a local, always-answerable question has
        nothing to add beyond :meth:`available`. So the default derives the
        three-state answer from the two-state one, and a backend with a
        genuinely undeterminable state (``bedrock``, whose answer depends on an
        external ``aws sts`` call that can time out) overrides it.

        The third state is what makes the gate safe. *indeterminate* means
        "this process could not DETERMINE credential state" — it is not
        evidence of failure, so :func:`maestro.core.model_backend_gate
        .probe_model_backend`'s caller must neither hold dispatch on it nor
        treat it as proof that a held backend has recovered. This default
        never returns it: an answer derived from a local ``available()`` was
        always determinable.
        """
        try:
            ok, reason = self.available()
        except Exception as exc:  # noqa: BLE001 — contract: never raises
            # available() promises not to raise; if one does, that is a broken
            # provider, not a failed backend. Undeterminable, never a hold.
            return "indeterminate", f"available() raised {type(exc).__name__}"
        return ("available", "") if ok else ("unavailable", reason)
