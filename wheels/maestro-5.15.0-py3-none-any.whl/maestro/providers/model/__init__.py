"""maestro/providers/model — model backends (which service a crew's Claude
session runs against).

FTR-MSO-2026-0866, PLAN-PLN-MSO-2026-0864 Order 2. ``anthropic`` — the direct
API — is the shipped default. ``bedrock`` (AWS Bedrock) was added by Order 3,
FTR-MSO-2026-0867, additively — exactly as ``ci/jenkins`` was added beside
``ci/github_actions`` without touching it: one import and one registry entry in
``maestro/providers/__init__.py``, and nothing else in this package changed.

Unlike the other four kinds there is no ``none`` provider here, and that is a
decision rather than an omission: every crew talks to *some* model backend, so
"no model backend configured" is not a state a fleet can be in. An unconfigured
workspace resolves ``anthropic`` (see ``providers.__init__._default_id``), not
``none``.

See :mod:`maestro.providers.model.base` for the capability contract and why
``env_overlay``/``resolve_model_id`` live on a subclass rather than on
``Provider``.
"""

from maestro.providers.model.anthropic import AnthropicModelProvider
from maestro.providers.model.bedrock import BedrockModelProvider
from maestro.providers.model.base import (
    CONTEXT_SELECTOR_SUFFIX,
    ModelBackendProvider,
    ModelUnavailableOnBackend,
)

__all__ = [
    "CONTEXT_SELECTOR_SUFFIX",
    "AnthropicModelProvider",
    "BedrockModelProvider",
    "ModelBackendProvider",
    "ModelUnavailableOnBackend",
]
