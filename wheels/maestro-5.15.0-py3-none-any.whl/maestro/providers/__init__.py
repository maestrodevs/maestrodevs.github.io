"""maestro/providers — the tool-provider abstraction (PLAN-PLN-MSO-2026-0504 §10).

The measured problem: 30 hardcoded ``"gh"`` call sites across 9 modules
(§10, ``grep -rn '"gh"' maestro --include=*.py``). For an organisation on
Jira + Bitbucket + Jenkins, every check that shells out to ``gh`` directly is
not degraded — it is inoperative. ``resolve(kind)`` is the seam: callers ask
for a capability (``scm`` / ``ci`` / ``issues`` / ``deploy`` / ``model``),
never for "GitHub" by name.

``model`` (FTR-MSO-2026-0866, PLAN-PLN-MSO-2026-0864 ADR-1) is the fifth kind
and the one that is not an SDLC tool: it names which backend a crew's Claude
session runs against. It joined this package rather than getting a config
block of its own so that it inherits the tiering, the ``available()``
contract, the credential-reference guard and the CLI/Hub surface below —
re-implementing the credential guard, in particular, is the piece most
expensive to get wrong. Unlike the other four kinds it has no ``none``
provider and its shipped default (``anthropic``) never depends on ``gh``;
see :data:`DEFAULT_MODEL_BACKEND_ID` and :func:`_default_id`.

**Scope (§10.4 — read before extending this module).** PLAN-PLN-MSO-2026-0504
shipped ``github`` + ``none`` only; PLAN-PLN-MSO-2026-0747 Order 12
(FTR-MSO-2026-0770) additively registered ``ci/jenkins`` alongside it, and
Order 13 additively registered ``issues/jira``, and Order 11
(FTR-MSO-2026-0769) ``scm/bitbucket`` (Cloud + Data Center) — none of the
existing providers changed. Every real deploy provider is still a
separate, additive order — the whole point of the seam is that adding one
means a new module under ``scm/``/``ci/``/``issues/``/``deploy/``, never a
rewrite of this package.
**The dispatcher's own 18 ``gh`` call sites in ``fleet_runner.py`` are NOT
migrated to call through here in this order** — that is convergence/PR
machinery with a large, separate blast radius (PLAN-PLN-MSO-2026-0747
Order 14). The ``github`` providers ARE written as thin wrappers over the
identical ``gh`` invocations ``fleet_runner.py`` and the core PR helpers
already use, specifically so that later migration is a call-site move, not a
second implementation.
"""

from __future__ import annotations

import json
import logging
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

from maestro.providers.base import PROVIDER_KINDS, Provider
from maestro.providers.ci.github_actions import GithubActionsCiProvider
from maestro.providers.ci.jenkins import JenkinsCiProvider
from maestro.providers.ci.none import NoneCiProvider
from maestro.providers.deploy.none import NoneDeployProvider
from maestro.providers.issues.github_issues import GithubIssuesProvider
from maestro.providers.issues.jira import JiraIssuesProvider
from maestro.providers.issues.none import NoneIssuesProvider
from maestro.providers.model.anthropic import AnthropicModelProvider
from maestro.providers.model.bedrock import BedrockModelProvider
from maestro.providers.scm.bitbucket import BitbucketScmProvider
from maestro.providers.scm.github import GithubScmProvider
from maestro.providers.scm.none import NoneScmProvider

__all__ = [
    "DEFAULT_MODEL_BACKEND_ID",
    "PROVIDER_KINDS",
    "ResolvedProvider",
    "all_kinds",
    "configured_entry",
    "resolve",
    "resolve_explain",
]

logger = logging.getLogger(__name__)

# id -> provider class, per kind. A provider id not present here resolves to
# "unknown provider" (§10.3), never a crash — an org's pack/bundle can name a
# provider this Maestro version doesn't ship yet (e.g. "jenkins") and the
# patrol degrades loudly rather than refusing to run at all (§5.3).
_REGISTRY: dict[str, dict[str, type]] = {
    "scm": {"bitbucket": BitbucketScmProvider, "github": GithubScmProvider, "none": NoneScmProvider},
    "ci": {"github_actions": GithubActionsCiProvider, "jenkins": JenkinsCiProvider, "none": NoneCiProvider},
    "issues": {"github_issues": GithubIssuesProvider, "jira": JiraIssuesProvider, "none": NoneIssuesProvider},
    "deploy": {"none": NoneDeployProvider},
    # FTR-MSO-2026-0866. No `none` entry, deliberately: every crew talks to
    # some model backend, so "none configured" is not a state a fleet can be
    # in — see maestro/providers/model/__init__.py. `bedrock` is Order 3 and
    # registers HERE, with no other change to this module: that one-line
    # extensibility is what Order 2's acceptance criterion 2 is asserting.
    "model": {"anthropic": AnthropicModelProvider, "bedrock": BedrockModelProvider},
}

# The shipped-default id per kind WHEN gh is authenticated (§10.2). `deploy`
# has no real provider yet, so it is always "none" regardless of gh.
#
# `model` is NOT in this map, and must not be: its default has nothing to do
# with GitHub, and unlike every other kind it is never `none`. It is resolved
# unconditionally by `_default_id` below.
_DEFAULT_ID_IF_GH_AUTHED = {
    "scm": "github", "ci": "github_actions", "issues": "github_issues", "deploy": "none",
}

# The shipped default for the `model` kind: the direct Anthropic API, which is
# what every workspace used before the kind existed (ADR-1). Named rather than
# inlined so the "unconfigured == anthropic" rule has one spelling.
DEFAULT_MODEL_BACKEND_ID = "anthropic"


@dataclass(frozen=True)
class ResolvedProvider:
    """What :func:`resolve_explain` found, and why — the ``--explain`` payload.

    ``provider`` is ``None`` whenever ``available`` is ``False``: a caller
    must branch on ``available``, never assume a truthy ``provider``.
    """

    kind: str
    provider_id: str
    tier: str                      # "bundle" | "workspace" | "default"
    available: bool
    reason: str                    # "" when available; always non-empty when not
    provider: Optional[Provider]


def _workspace_json(workspace: Optional[Path]) -> dict:
    if workspace is None:
        return {}
    try:
        from maestro.workspace import resolve_artefact_dir
        cfg_path = resolve_artefact_dir(Path(workspace)) / "config" / "workspace.json"
        if not cfg_path.exists():
            return {}
        data = json.loads(cfg_path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _bundle_providers(workspace: Optional[Path]) -> Optional[dict]:
    """Tier 1 — signed policy bundle override (§5.3 / §10.2), enterprise-gated.

    §10.2 is explicit that the ``providers`` block is per-workspace, never
    per-machine, so only the WORKSPACE-tier bundle
    (``.mso/config/policy-bundle.json``) is consulted — never the user-home
    tier. This reuses ``governance.loader.load_bundles()`` for the real
    integrity/signature verification (a tampered — or, under
    ``governance.requireSignature``, unsigned — bundle raises and its
    ``providers`` override is never trusted either) rather than
    re-implementing that check a second time. The ``providers`` key itself
    is then read from the SAME already-verified file, because
    ``governance.schema.PolicyBundle`` only models deny/allow/warn rules and
    has nowhere to carry arbitrary data — extending that schema is a
    separate, larger change than this order's scope.
    """
    if workspace is None:
        return None
    try:
        from maestro import auth
        if not auth.has_tier({"enterprise"}):
            return None
        from maestro.governance.loader import load_bundles
        from maestro.workspace import MSO_DIR_NAME

        load_bundles(workspace)  # fail closed: raises on tamper/invalid/unsigned-when-required
        bundle_path = Path(workspace) / MSO_DIR_NAME / "config" / "policy-bundle.json"
        if not bundle_path.exists():
            return None
        data = json.loads(bundle_path.read_text(encoding="utf-8"))
        providers = data.get("providers") if isinstance(data, dict) else None
        return providers if isinstance(providers, dict) else None
    except Exception:
        # A malformed/tampered bundle must not silently grant a provider
        # override — fail closed to "no bundle tier", same as §5.5's rule.
        return None


def _default_id(kind: str, workspace: Optional[Path]) -> str:
    """§10.2 shipped default: `github` for scm/ci/issues IF `gh` is
    authenticated, otherwise `none` — never a silent assumption that GitHub
    is present. `deploy` has no real provider in this order (§10.4).

    `model` is answered first and unconditionally (FTR-MSO-2026-0866): its
    default is the direct Anthropic API on every machine, whether or not `gh`
    is installed or authenticated. Falling through to the `gh` probe would
    make a fleet's model backend depend on its GitHub login — and, on a
    machine with no `gh`, would resolve `none`, which for this kind means a
    dispatcher that cannot launch a crew at all.
    """
    if kind == "model":
        return DEFAULT_MODEL_BACKEND_ID
    if kind == "deploy":
        return "none"
    if shutil.which("gh") is None:
        return "none"
    try:
        from maestro.core.proc import run_hidden
        r = run_hidden(["gh", "auth", "status"], capture_output=True, text=True, timeout=10)
        return _DEFAULT_ID_IF_GH_AUTHED[kind] if r.returncode == 0 else "none"
    except Exception:
        return "none"


def configured_entry(kind: str, workspace: Optional[Path] = None) -> tuple[str, Optional[str], dict]:
    """``(tier, configured id or None, config)`` for *kind* — bundle > workspace;
    ``("default", None, {})`` when neither names *kind*.

    The configuration half of :func:`resolve_explain`, extracted (FTR-MSO-2026-0772)
    so the dispatcher can learn what a workspace CONFIGURED without the shipped
    default's ``gh auth status`` probe or a provider's ``available()`` network
    check. ``config`` is returned raw: ``secret://`` references are resolved by
    :func:`resolve_explain` only.
    """
    if kind not in PROVIDER_KINDS:
        raise ValueError(f"unknown provider kind: {kind!r} (expected one of {PROVIDER_KINDS})")

    entry: Any = None
    tier = "default"

    bundle_providers = _bundle_providers(workspace)
    if isinstance(bundle_providers, dict) and kind in bundle_providers:
        entry = bundle_providers[kind]
        tier = "bundle"
    else:
        ws_data = _workspace_json(workspace)
        ws_providers = ws_data.get("providers") if isinstance(ws_data, dict) else None
        if isinstance(ws_providers, dict) and kind in ws_providers:
            entry = ws_providers[kind]
            tier = "workspace"

    if not isinstance(entry, dict):
        return tier, None, {}
    return tier, entry.get("id") or None, dict(entry.get("config") or {})


# Providers that take a per-call repository ``slug``, exactly as
# ``scm_lifecycle.dispatcher_scm`` already hands one to GitHub per call.
_REPO_SCOPED_PROVIDER_IDS = frozenset({"github", "github_actions", "github_issues"})

def _is_repo_scoped(provider_cls: type) -> bool:
    """Whether a ``repo_slug`` means anything to this provider (BUG-MSO-2026-0825).

    Read off the provider CLASS rather than a parallel list of kinds kept
    here, so the answer cannot drift from the provider that gives it. Absent
    ⇒ ``True``, which is every provider that existed before
    FTR-MSO-2026-0866 — their behaviour is unchanged.

    ``ModelBackendProvider`` declares ``False``: a model backend is a property
    of the WORKSPACE, so every repo of a multi-repo voyage runs its crews on
    the same one, and a slug passed for it is a no-op rather than a refusal.
    """
    return bool(getattr(provider_cls, "repo_scoped", True))


def _repo_name(value: Any) -> str:
    return str(value or "").strip().strip("/").rsplit("/", 1)[-1]


def _scope_to_repo(config: dict, provider_id: str, repo_slug: str) -> str:
    """Point *config* at one repository in place. Returns a refusal reason, or "".

    Only the slug moves here — ``gh --repo`` needs no checkout. The working
    directory is :func:`_scope_to_repo_path`'s job (BUG-MSO-2026-0897), which
    runs first and pins it to that repository's own checkout when the caller
    knows one; a GitHub provider reads its egress allowlist from the
    workspace, not from that directory, so the two no longer interact."""
    if provider_id in _REPO_SCOPED_PROVIDER_IDS:
        config["slug"] = str(repo_slug)
        return ""
    if provider_id == "none":
        return ""
    configured = _repo_name(config.get("slug")) or _repo_name(config.get("repo"))
    wanted = _repo_name(repo_slug)
    if configured and wanted and configured.casefold() != wanted.casefold():
        return (f"{provider_id} provider is configured for '{configured}', not '{repo_slug}' "
                "— a multi-repo voyage on this provider needs a per-repo provider configuration")
    return ""


def _product_repo_path(workspace: Optional[Path]) -> Optional[Path]:
    """The PRODUCT repository for *workspace*, or None when it cannot be resolved.

    BUG-MSO-2026-0897. Every provider defaults its working directory to the
    ``workspace`` it was constructed with, and ``gh`` resolves *which
    repository it is talking about* from that directory's git remote. In
    **embedded** mode that is harmless — the workspace root IS the product
    repo. In **artefact-repo mode** (``artefacts.mode`` solo/shared) the
    workspace root is the ARTEFACT repo, a different GitHub repository
    entirely, so every branch→PR lookup asked the wrong repo and answered "no
    pull request found" for a PR that plainly exists.

    Best-effort by construction: ``get_product_repo`` raises when solo mode is
    unconfigured, and a provider that cannot be scoped must keep behaving as
    it did rather than fail to resolve at all.
    """
    if workspace is None:
        return None
    try:
        from maestro.workspace import find_workspace_dir, get_product_repo, workspace_override

        # Explicit workspace, never the process's. `get_product_repo`'s `start`
        # hint is only tier 3 of `get_workspace_dir` — a `MAESTRO_DIR` in the
        # environment outranks it — so pinning it needs the ContextVar, the
        # same discipline BUG-MSO-2026-0825 applied with `repos_map_for`. The
        # Hub serves N workspaces from one process; resolving the product repo
        # of whichever one the environment happens to name would answer about
        # the wrong repository, which is the very bug being closed here.
        mso = find_workspace_dir(Path(workspace))
        if mso is None:
            return None
        with workspace_override(mso):
            resolved = Path(get_product_repo(None, Path(workspace)))
    except Exception as exc:  # noqa: BLE001 — fail-safe, see the docstring
        # SEC-BUG-MSO-2026-0897 F2: staying silent here is how this very bug
        # presents — `mso pr status` reports "no pull request found" with
        # nothing to say the provider was never scoped to the product repo.
        # Debug, not warning: an unconfigured solo mode raises here on every
        # ordinary embedded-mode call, so this is expected traffic, not a fault.
        logger.debug(
            "provider repo scoping: could not resolve the product repo for "
            "workspace %s (%s: %s) — leaving repoPath unset",
            workspace, type(exc).__name__, exc,
        )
        return None
    return resolved if resolved.is_dir() else None


def _scope_to_repo_path(config: dict, provider_id: str, workspace: Optional[Path],
                        repo_path: Optional[Path], repo_slug: Optional[str]) -> None:
    """Pin *config*'s ``repoPath`` to the repository the provider is about.

    A configured ``repoPath`` always wins, then an explicit *repo_path*; the
    workspace's product repo is only the last resort, and only when nothing
    else names a repository. A *repo_slug* with no *repo_path* is such a
    naming: the caller knows which repository it means but not where its
    checkout is, and the workspace default would be a DIFFERENT repository —
    ``gh --repo`` already scopes that case correctly (BUG-MSO-2026-0825), so
    guessing a contradictory working directory could only make it worse.
    ``none`` takes no working directory at all.
    """
    if provider_id == "none" or config.get("repoPath"):
        return
    if repo_path is not None:
        config["repoPath"] = str(Path(repo_path))
        return
    if repo_slug:
        return
    resolved = _product_repo_path(workspace)
    if resolved is not None:
        config["repoPath"] = str(resolved)


def resolve_explain(kind: str, workspace: Optional[Path] = None, *,
                    repo_slug: Optional[str] = None,
                    repo_path: Optional[Path] = None) -> ResolvedProvider:
    """Resolve *kind* through the same tiers as §5's patrol-definition
    resolution: signed bundle > workspace.json > shipped default.

    ("Division pack" — §5.3's tier 2 — folds into the workspace.json tier
    here rather than being a separate live read: `maestro/packs/scaffold.py
    :apply_pack` already deep-folds a pack's `workspace-defaults.json` into
    `workspace.json` once, at `mso init --pack` time, exactly how
    `verifyCommand` resolves today. A pack that wants to recommend a
    `providers` block ships it in that same `workspace-defaults.json` — no
    new pack-schema plumbing needed. There is no live per-request
    "which pack is this workspace running" lookup anywhere in the codebase
    to hook into, so inventing one here — for `providers` alone — would be a
    second, divergent tiering mechanism ahead of Order 2's shared
    `maestro/patrol/resolver.py`, not a reuse of it.)

    Never raises. Unconfigured, unavailable, and unknown provider ids all
    resolve to `available=False` with a non-empty reason (§10.3) — a skip is
    always reported, never a silent pass and never a crash.

    *repo_slug* (BUG-MSO-2026-0825) scopes the provider to ONE product
    repository of a multi-repo workspace — the repos-map entry a voyage's
    ``targetRepo`` names (``maestro/core/repo_target.py``). A GitHub provider
    takes it as its ``slug`` (the per-call value wins over a configured one, the
    same rule as ``scm_lifecycle.dispatcher_scm``). Any other provider is
    configured for exactly one repository, so a slug naming a different
    repository resolves UNAVAILABLE with a reason — never an answer read from
    the wrong repository. Omitted: unchanged.

    *repo_path* (BUG-MSO-2026-0897) is that repository's local checkout — the
    provider's working directory, and therefore the directory ``gh`` resolves
    the repository from when no slug scopes it. Omitted **and** with no
    *repo_slug* — i.e. nothing names a repository at all — it defaults to the
    workspace's PRODUCT repo (:func:`_product_repo_path`): the workspace root
    in embedded mode (unchanged), and the configured ``artefacts.productRepo``
    in solo/shared mode, where the workspace root is the ARTEFACT repo and
    asking it about a voyage branch's PR had always, silently, answered
    "none". Omitted alongside a *repo_slug*: left unset, so a workspace
    default can never contradict the slug — see :func:`_scope_to_repo_path`.
    """
    if kind not in PROVIDER_KINDS:
        raise ValueError(f"unknown provider kind: {kind!r} (expected one of {PROVIDER_KINDS})")

    tier, configured_id, config = configured_entry(kind, workspace)
    provider_id = configured_id or _default_id(kind, workspace)

    # Credentials: NO second credential path (order-4 AC) — resolved via
    # secrets.refs.resolve_secret_refs at the use site, exactly as
    # bridge-settings.json already does (core/bridge_notifier.py). A
    # non-enterprise workspace passes `secret://` strings through unchanged
    # (resolve_secret_refs's own feature gate), so this is a no-op there.
    try:
        from maestro.secrets.refs import resolve_secret_refs
        config = resolve_secret_refs(config, workspace=Path(workspace) if workspace else None)
    except Exception:
        pass

    provider_cls = _REGISTRY[kind].get(provider_id)
    if provider_cls is not None:
        _scope_to_repo_path(config, str(provider_id), workspace, repo_path, repo_slug)
    if provider_cls is not None and repo_slug and _is_repo_scoped(provider_cls):
        refusal = _scope_to_repo(config, provider_id, repo_slug)
        if refusal:
            return ResolvedProvider(kind=kind, provider_id=provider_id, tier=tier,
                                    available=False, reason=f"skipped — {refusal}", provider=None)
    if provider_cls is None:
        return ResolvedProvider(
            kind=kind, provider_id=str(provider_id), tier=tier, available=False,
            reason=f"skipped — unknown {kind} provider '{provider_id}' "
                   "(not installed in this Maestro version)",
            provider=None,
        )

    try:
        if provider_id == "none":
            instance = provider_cls(config)
        else:
            instance = provider_cls(config, workspace=Path(workspace) if workspace else None)
    except Exception as exc:
        return ResolvedProvider(
            kind=kind, provider_id=provider_id, tier=tier, available=False,
            reason=f"{kind} provider '{provider_id}' failed to initialise: {exc}",
            provider=None,
        )

    try:
        ok, detail = instance.available()
    except Exception as exc:  # noqa: BLE001 — a broken provider must not crash the resolver
        ok, detail = False, f"available() raised {type(exc).__name__}: {exc}"

    if ok:
        return ResolvedProvider(kind=kind, provider_id=provider_id, tier=tier,
                                 available=True, reason="", provider=instance)

    if provider_id == "none":
        composed = f"no {kind} provider configured"
    elif detail.startswith("host not permitted"):
        # §10.2 egress rule: surfaced as its own distinct reason rather than
        # wrapped in the generic "<kind> provider '<id>' unavailable:" shape,
        # per order-4 AC: "skipped — host not permitted".
        composed = detail
    else:
        composed = f"{kind} provider '{provider_id}' unavailable: {detail}"

    return ResolvedProvider(kind=kind, provider_id=provider_id, tier=tier,
                             available=False, reason=f"skipped — {composed}", provider=None)


def resolve(kind: str, workspace: Optional[Path] = None) -> Optional[Provider]:
    """``resolve(kind) -> Provider | None`` (§10.1's literal signature).

    Returns the working provider instance, or ``None`` when
    unconfigured/unavailable/unknown. Callers that must REPORT a skip (never
    silently omit it — §10.3) should call :func:`resolve_explain` instead,
    which carries the reason.
    """
    return resolve_explain(kind, workspace=workspace).provider


def all_kinds() -> tuple[str, ...]:
    return PROVIDER_KINDS
