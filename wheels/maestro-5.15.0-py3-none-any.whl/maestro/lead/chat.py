# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""maestro/lead/chat.py — the ONE Captain-chat core (PLAN-PLN-MSO-2026-0828
Order 1, FTR-MSO-2026-0842).

An append-only, cross-process-safe JSONL thread at
``<artefact_root>/state/captain-chat/thread.jsonl``, plus the reads every
later order in the roadmap is built on: the CLI (``mso lead chat log|say``),
the proactive question emitter (Order 2), the on-demand responder (Order 3),
the decision core (Order 4) and the Hub's REST/WebSocket surface (Order 5)
all go through this module. Per CLAUDE.md "Shared cores — one implementation
per decision", none of them may grow a second reader or writer.

Why ``state/`` and not ``logs/`` or the git-tracked plane (plan §0 Q3)
----------------------------------------------------------------------
``state/`` is device-local, gitignored, durable on disk and readable
off-process with no daemon, Hub or dispatcher running — the same class as
``state/order-ledger.jsonl`` and ``state/lead-critical.json``. ``logs/`` is
throwaway runtime output that ``mso cleanup`` may discard; the chat is a
record other processes act on, so it needs ledger-class durability.

It is deliberately **never git-committed**: free-text chat can carry
sensitive operational detail, this repo is slated for a public mirror, and a
commit per message would reproduce the bookkeeping-conflict class that
``CONVERGENCE_BOOKKEEPING_AUTORESOLVED`` exists to contain. The only part of
a conversation that needs git durability is a confirmed **decision**, and
Order 4 promotes those onto the (git-tracked) order JSON. A decision message
in this thread is the conversation; the order JSON's ``captainDecisions[]``
is the record.

For the same reason the ``CAPTAIN_CHAT`` lifecycle line this module writes
carries **metadata only** (``msg=`` / ``author=`` / ``kind=`` / ``subject=``)
and never the body — ``lifecycle.log`` must never become a second copy of
the chat.

Append-only, and updates are appended too
-----------------------------------------
Nothing already written is ever rewritten. A state change — a question going
``open`` -> ``answered``, a proposal going ``offered`` -> ``confirmed`` — is
appended as its own *update line* naming the message it folds onto
(:func:`append_update`), exactly the discipline
``maestro/core/order_ledger.py`` uses for ``CLAIMED``/``TERMINAL``.
:func:`fold` replays them. A reader therefore never has to trust that a
concurrent writer finished a rewrite, which is what makes the torn-line
tolerance below sufficient rather than merely hopeful.

Concurrency (plan Risk R5)
--------------------------
Three processes can write concurrently: the Hub, the LEAD daemon and a
terminal running ``mso lead chat say``. So:

* appends serialise on a cross-process lock at ``state/captain-chat/.lock``
  (:func:`lock_for_append`, the same ``_CrossProcessLock`` the order-ID
  allocator uses — imported rather than copied, so there is one lock
  implementation in the codebase, not two that can drift);
* each line is one ``write()`` + ``flush()`` + ``fsync()``;
* message ids are minted **inside** the lock and never reused;
* readers tolerate a torn final line (skip it, warn) — a writer killed
  mid-``write`` can only ever damage the last line of the active segment.

The shared-core contract (``maestro/core/order_retry.py``)
----------------------------------------------------------
Explicit ``artefact_root: Path`` throughout — no ``find_workspace()``, no
CWD, because the Hub serves N workspaces from one process. Typed exceptions
(:class:`ChatValidationError` -> 400, :class:`ChatMessageNotFound` -> 404),
never printing and never ``sys.exit``. ``require_capability`` is enforced
here in the core (:func:`post_captain_message`), not per surface, so a new
caller inherits the gate instead of forgetting it. Licence-tier gating stays
at the call sites, as ``maestro/lead/control.py`` records.
"""

from __future__ import annotations

import json
import logging
import os
import secrets
import threading
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, List, Optional, Sequence, Tuple

# The order-ID allocator's lockfile class, reused rather than copied: it is
# already the codebase's portable O_CREAT|O_EXCL cross-process mutex, and it
# already carries the Windows delete-pending (PermissionError) retry that
# BUG-MSO-2026-0464 had to learn the hard way. A second copy here would be a
# second place for that lesson to be forgotten.
from maestro.core.order_ids import _CrossProcessLock

__all__ = [
    "AUTHOR_KINDS",
    "CONFIRM_LOCK_FILENAME",
    "MAX_BODY_CHARS",
    "MAX_PAGE_LIMIT",
    "MESSAGE_KINDS",
    "PROPOSAL_STATES",
    "QUESTION_STATES",
    "ROTATION_BYTES",
    "SCHEMA_VERSION",
    "Author",
    "ChatMessage",
    "ChatMessageNotFound",
    "ChatPage",
    "ChatValidationError",
    "ConfirmOutcome",
    "LlmUsage",
    "Proposal",
    "ProposalAlreadyResolved",
    "ProposalNotFound",
    "Subject",
    "answer_question",
    "append_message",
    "append_update",
    "chat_dir",
    "confirm_proposal",
    "cursor_path",
    "fold",
    "load_cursor",
    "lock_for_append",
    "new_message_id",
    "open_questions",
    "post_captain_message",
    "post_captain_reply",
    "post_lead_message",
    "post_system_message",
    "proposal_age_minutes",
    "proposal_is_stale",
    "read_page",
    "read_since",
    "recent_decisions",
    "resolve_proposal_ttl_minutes",
    "resolve_workspace_label",
    "save_cursor",
    "segment_paths",
    "thread_path",
    "unanswered_captain_messages",
]

_log = logging.getLogger(__name__)

#: Message schema version. Bump only with a reader that accepts both.
SCHEMA_VERSION = 1

CHAT_RELDIR = Path("state") / "captain-chat"
THREAD_FILENAME = "thread.jsonl"
LOCK_FILENAME = ".lock"
#: A SECOND, distinct cross-process lock, held only across a proposal's
#: claim (:func:`confirm_proposal`). It can never be the append lock: the
#: claim itself appends an update line, and ``_CrossProcessLock`` is not
#: re-entrant — nesting would spin until its timeout and then proceed
#: unlocked, which is exactly the serialisation the claim depends on.
CONFIRM_LOCK_FILENAME = ".confirm.lock"
CURSOR_FILENAME = "lead-cursor.json"

#: Rotate the active segment once it would pass 5 MB (plan §0 Q3).
ROTATION_BYTES = 5 * 1024 * 1024

#: A chat message is a message, not a file upload. 8,000 characters is
#: roughly 2,000 tokens — comfortably more than anyone types, and small
#: enough that a pasted log cannot blow out the responder's context pack.
MAX_BODY_CHARS = 8_000

#: Hard ceiling on one :func:`read_page` page, applied REGARDLESS of what the
#: caller asked for (BUG-MSO-2026-0892 item 1, CWE-770). ``read_page`` walks
#: thread segments off disk and folds every record in the window, so an
#: unbounded ``limit`` lets one request re-read and re-fold the entire
#: history — the amplification is on the server's disk and memory, not the
#: caller's. Clamped rather than refused: a page is a page, and a caller who
#: asked for more gets the newest 500 with ``has_more`` telling the truth,
#: which is the same answer paging gives. Well above every caller in the
#: tree (the Hub panel and the CLI both ask for 50, the chat socket's
#: backfill 50, the responder's transcript 20), so nothing real is truncated.
MAX_PAGE_LIMIT = 500

AUTHOR_KINDS: Tuple[str, ...] = ("captain", "lead", "system")
MESSAGE_KINDS: Tuple[str, ...] = (
    "text", "question", "reply", "status", "proposal-result", "decision",
)
QUESTION_STATES: Tuple[str, ...] = ("open", "answered", "expired", "superseded")
PROPOSAL_STATES: Tuple[str, ...] = (
    "offered", "confirmed", "refused", "failed", "expired",
)

#: Metadata-only. The body NEVER appears in a lifecycle line (plan §0 Q3).
LIFECYCLE_EVENT = "CAPTAIN_CHAT"

#: Well-known author ids, so surfaces do not each invent their own string.
AUTHOR_LEAD_DAEMON = "lead-daemon"
AUTHOR_SYSTEM = "system"
AUTHOR_HUB = "hub"

# Serialises appends within THIS process, the way order_ledger._WRITE_LOCK
# does: the cross-process lock covers separate processes, but a single
# process (the Hub, with its per-workspace poller threads) is not
# single-threaded, and on Windows concurrent appends through separate
# handles can interleave mid-line.
_WRITE_LOCK = threading.Lock()


# ---------------------------------------------------------------------------
# Typed exceptions — the CLI renders them, the Hub maps them to HTTP.
# ---------------------------------------------------------------------------

class ChatValidationError(ValueError):
    """Invalid chat input — empty body, oversized body, unknown kind/state.

    Maps to HTTP 400.
    """


class ChatMessageNotFound(LookupError):
    """A referenced chat message id is not in the thread. Maps to HTTP 404."""


class ProposalNotFound(LookupError):
    """The message exists but carries no proposal at that index. HTTP 404."""


class ProposalAlreadyResolved(Exception):
    """This proposal has already been confirmed, refused, failed or expired.

    Maps to HTTP 409. Raised — never silently re-run — because the second
    click of a double-click must not execute the verb a second time, and
    because a caller that was told "accepted" for work it did not cause
    would have no way to tell the two apart. Carries the state it is in, so
    the surface can say which.
    """

    def __init__(self, message_id: str, index: int, state: str) -> None:
        self.message_id = message_id
        self.index = index
        self.state = state
        super().__init__(
            f"Proposal {index} of {message_id} is already '{state}' — "
            "a proposal is confirmed once and only once."
        )


# ---------------------------------------------------------------------------
# Schema v1 — dataclasses in, plain dicts on disk.
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class Author:
    """Who said it. ``verified`` is honest, not decorative: the Hub has one
    shared bearer token and no per-request human identity, so a Hub-authored
    message is ``verified=False`` and says so in the UI (plan Risk R4). No
    authority differs by author — every effect goes through an explicit
    confirmation that calls an existing core.
    """

    kind: str
    id: str
    display_name: str = ""
    verified: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "kind": self.kind,
            "id": self.id,
            "displayName": self.display_name,
            "verified": bool(self.verified),
        }

    @classmethod
    def from_dict(cls, raw: Any) -> "Author":
        raw = raw if isinstance(raw, dict) else {}
        return cls(
            kind=str(raw.get("kind") or "system"),
            id=str(raw.get("id") or AUTHOR_SYSTEM),
            display_name=str(raw.get("displayName") or ""),
            verified=bool(raw.get("verified", False)),
        )


@dataclass(frozen=True)
class Subject:
    """What the message is *about* — the dedup key for proactive questions
    (Order 2) and the ``subject=`` field of the lifecycle line."""

    fingerprint: Optional[str] = None
    order_id: Optional[str] = None
    voyage_id: Optional[str] = None
    event_type: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "fingerprint": self.fingerprint,
            "orderId": self.order_id,
            "voyageId": self.voyage_id,
            "eventType": self.event_type,
        }

    @classmethod
    def from_dict(cls, raw: Any) -> "Subject":
        raw = raw if isinstance(raw, dict) else {}
        return cls(
            fingerprint=raw.get("fingerprint") or None,
            order_id=raw.get("orderId") or None,
            voyage_id=raw.get("voyageId") or None,
            event_type=raw.get("eventType") or None,
        )

    @property
    def is_empty(self) -> bool:
        return not any(
            (self.fingerprint, self.order_id, self.voyage_id, self.event_type)
        )

    @property
    def ref(self) -> str:
        """One short reference for the lifecycle line. Never free text."""
        for value in (self.order_id, self.voyage_id, self.event_type, self.fingerprint):
            if value:
                return str(value)
        return "-"


@dataclass
class Proposal:
    """An offered action. ``verb_id`` may only ever name a verb that already
    exists in ``maestro/lead/run_verbs.py``'s closed list, and it is
    RE-VALIDATED server-side at confirm time — the stored JSON is never
    trusted (plan §0 Q2). This module stores it; it never executes one.
    """

    verb_id: str
    args: Dict[str, Any] = field(default_factory=dict)
    why: str = ""
    state: str = "offered"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "verbId": self.verb_id,
            "args": dict(self.args or {}),
            "why": self.why,
            "state": self.state,
        }

    @classmethod
    def from_dict(cls, raw: Any) -> "Proposal":
        raw = raw if isinstance(raw, dict) else {}
        args = raw.get("args")
        return cls(
            verb_id=str(raw.get("verbId") or ""),
            args=dict(args) if isinstance(args, dict) else {},
            why=str(raw.get("why") or ""),
            state=str(raw.get("state") or "offered"),
        )


@dataclass(frozen=True)
class LlmUsage:
    """Per-reply token accounting (Order 3). Present only on a ``reply``."""

    model: str = ""
    input_tokens: int = 0
    output_tokens: int = 0
    duration_ms: int = 0
    outcome: str = "done"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "model": self.model,
            "inputTokens": int(self.input_tokens),
            "outputTokens": int(self.output_tokens),
            "durationMs": int(self.duration_ms),
            "outcome": self.outcome,
        }

    @classmethod
    def from_dict(cls, raw: Any) -> "LlmUsage":
        raw = raw if isinstance(raw, dict) else {}
        return cls(
            model=str(raw.get("model") or ""),
            input_tokens=int(raw.get("inputTokens") or 0),
            output_tokens=int(raw.get("outputTokens") or 0),
            duration_ms=int(raw.get("durationMs") or 0),
            outcome=str(raw.get("outcome") or "done"),
        )


@dataclass
class ChatMessage:
    """One thread message, schema v1 (plan §0 Q3).

    Every key is always emitted, null where unset, so the CLI-vs-Hub
    whole-artefact anti-drift comparison (Order 5) has a stable shape to
    compare rather than a shape that varies by which surface wrote it.
    """

    id: str
    ts: str
    workspace: str
    author: Author
    kind: str
    in_reply_to: Optional[str] = None
    subject: Subject = field(default_factory=Subject)
    body: str = ""
    proposals: List[Proposal] = field(default_factory=list)
    decision_draft: Optional[Dict[str, Any]] = None
    question: Optional[Dict[str, Any]] = None
    llm: Optional[LlmUsage] = None
    v: int = SCHEMA_VERSION

    def to_dict(self) -> Dict[str, Any]:
        return {
            "v": int(self.v),
            "id": self.id,
            "ts": self.ts,
            "workspace": self.workspace,
            "author": self.author.to_dict(),
            "kind": self.kind,
            "inReplyTo": self.in_reply_to,
            "subject": self.subject.to_dict(),
            "body": self.body,
            "proposals": [p.to_dict() for p in self.proposals],
            "decisionDraft": self.decision_draft,
            "question": dict(self.question) if self.question else None,
            "llm": self.llm.to_dict() if self.llm else None,
        }

    @classmethod
    def from_dict(cls, raw: Dict[str, Any]) -> "ChatMessage":
        proposals = raw.get("proposals")
        return cls(
            id=str(raw.get("id") or ""),
            ts=str(raw.get("ts") or ""),
            workspace=str(raw.get("workspace") or ""),
            author=Author.from_dict(raw.get("author")),
            kind=str(raw.get("kind") or "text"),
            in_reply_to=raw.get("inReplyTo") or None,
            subject=Subject.from_dict(raw.get("subject")),
            body=str(raw.get("body") or ""),
            proposals=[Proposal.from_dict(p) for p in proposals]
            if isinstance(proposals, list) else [],
            decision_draft=raw.get("decisionDraft") or None,
            question=dict(raw["question"])
            if isinstance(raw.get("question"), dict) else None,
            llm=LlmUsage.from_dict(raw["llm"])
            if isinstance(raw.get("llm"), dict) else None,
            v=int(raw.get("v") or SCHEMA_VERSION),
        )

    @property
    def question_state(self) -> Optional[str]:
        return (self.question or {}).get("state")

    @property
    def is_open_question(self) -> bool:
        return self.kind == "question" and self.question_state == "open"


@dataclass(frozen=True)
class ChatPage:
    """One page of thread history, oldest-first within the page."""

    messages: List[ChatMessage]
    has_more: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "messages": [m.to_dict() for m in self.messages],
            "hasMore": bool(self.has_more),
            "oldestId": self.messages[0].id if self.messages else None,
            "newestId": self.messages[-1].id if self.messages else None,
        }


# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

def chat_dir(artefact_root: Path) -> Path:
    """``<artefact_root>/state/captain-chat``. Never resolved from CWD."""
    return Path(artefact_root) / CHAT_RELDIR


def thread_path(artefact_root: Path) -> Path:
    """The ACTIVE segment. Rotated segments sit beside it (see
    :func:`segment_paths`)."""
    return chat_dir(artefact_root) / THREAD_FILENAME


def lock_path(artefact_root: Path) -> Path:
    return chat_dir(artefact_root) / LOCK_FILENAME


def confirm_lock_path(artefact_root: Path) -> Path:
    return chat_dir(artefact_root) / CONFIRM_LOCK_FILENAME


def cursor_path(artefact_root: Path) -> Path:
    """Where the LEAD daemon remembers how far it has read."""
    return chat_dir(artefact_root) / CURSOR_FILENAME


def lock_for_append(artefact_root: Path) -> "_CrossProcessLock":
    """Context manager serialising thread appends across processes.

    Mint-the-id and write-the-line MUST both happen inside the ``with``
    block — that is what makes two concurrent appends race-safe, exactly as
    ``order_ids.lock_for_allocation`` documents for ID allocation. Like that
    lock, a wedged holder degrades to proceeding unlocked after the timeout
    rather than blocking a Captain's message forever; the in-process
    ``_WRITE_LOCK`` and the single fsync'd ``write()`` still hold.
    """
    return _CrossProcessLock(lock_path(artefact_root))


def segment_paths(artefact_root: Path) -> List[Path]:
    """Every thread segment, OLDEST first, active segment last.

    Rotated segments are ``thread-<YYYYMMDDHHMMSS>.jsonl``; the fixed-width
    timestamp makes a lexical sort a chronological one.
    """
    directory = chat_dir(artefact_root)
    if not directory.is_dir():
        return []
    rotated = sorted(
        (p for p in directory.iterdir()
         if p.is_file() and p.name.startswith("thread-") and p.name.endswith(".jsonl")),
        key=_segment_sort_key,
    )
    active = directory / THREAD_FILENAME
    if active.is_file():
        rotated.append(active)
    return rotated


def _segment_sort_key(path: Path) -> Tuple[str, int]:
    """Chronological sort key for a rotated segment.

    NOT a plain name sort. Several rotations can land inside one second, and
    the collision suffix makes ``thread-<stamp>-1.jsonl`` sort BEFORE
    ``thread-<stamp>.jsonl`` lexically ('-' is 0x2D, '.' is 0x2E) — which read
    a thread's history back out of order. Parsing the stamp and the suffix
    separately puts the unsuffixed segment (suffix 0) first, where it belongs.
    """
    stem = path.name[len("thread-"):-len(".jsonl")]
    stamp, _, suffix = stem.partition("-")
    try:
        sequence = int(suffix) if suffix else 0
    except ValueError:
        sequence = 0
    return (stamp, sequence)


# ---------------------------------------------------------------------------
# Ids, timestamps, workspace label
# ---------------------------------------------------------------------------

def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _iso(now: Optional[datetime] = None) -> str:
    return (now or _utc_now()).isoformat()


def _compact(now: Optional[datetime] = None) -> str:
    return (now or _utc_now()).strftime("%Y%m%dT%H%M%SZ")


def new_message_id(now: Optional[datetime] = None) -> str:
    """``CHAT-<utc-compact>-<6 hex>``.

    Time-prefixed so ids sort chronologically and a collision is only ever
    possible within a single second — which :func:`append_message` closes
    completely by checking the ids already minted in that same second while
    holding the append lock.
    """
    return f"CHAT-{_compact(now)}-{secrets.token_hex(3)}"


def resolve_workspace_label(artefact_root: Path) -> str:
    """A short human label for the workspace this thread belongs to.

    ``config/workspace.json``'s ``project`` key, else ``MAESTRO_PROJECT``,
    else the product-repo directory name. Cosmetic — it is carried on the
    message so a Hub rendering several workspaces can label them, and it is
    never used to resolve a path.
    """
    root = Path(artefact_root)
    try:
        data = json.loads((root / "config" / "workspace.json").read_text(encoding="utf-8"))
        project = data.get("project") or data.get("projectAcronym")
        if isinstance(project, str) and project.strip():
            return project.strip()
    except Exception:
        pass
    env_project = os.environ.get("MAESTRO_PROJECT", "").strip()
    if env_project:
        return env_project
    return root.parent.name or root.name


# ---------------------------------------------------------------------------
# Reading — torn-line tolerant, segment walking
# ---------------------------------------------------------------------------

def _iter_records_in_file(path: Path) -> Iterator[Dict[str, Any]]:
    """Yield the JSON records in one segment, skipping unparseable lines.

    A writer killed between ``write()`` and ``fsync()`` can only damage the
    LAST line of the active segment (every append is one write of one
    complete line under the lock), so a skipped line is a torn tail, not
    lost history. It is skipped and warned about rather than raised on:
    a half-written final line must never make the whole thread unreadable.
    """
    try:
        raw = path.read_text(encoding="utf-8", errors="replace")
    except OSError as exc:
        _log.warning("captain-chat: cannot read segment %s (%s)", path, exc)
        return
    # Split on the newline and NOTHING else (DEF-001, FTR-MSO-2026-0842 lap 1).
    # This format's record separator is the newline; str.splitlines()
    # additionally breaks on U+2028, U+2029 and U+0085, which json.dumps(
    # ensure_ascii=False) historically wrote through literally — so one physical
    # line was read back as two unparseable fragments and a message the caller
    # had been told was fsync'd disappeared from every read path. The writer now
    # escapes those three (_encode_record), but this side of the fix is what
    # recovers anything already on disk, and what keeps the reader correct for
    # any line this process did not write.
    lines = raw.split("\n")
    last_index = len(lines) - 1
    for index, line in enumerate(lines):
        line = line.strip()
        if not line:
            continue
        try:
            record = json.loads(line)
        except json.JSONDecodeError:
            _log.warning(
                "captain-chat: skipping unparseable line %d of %s%s",
                index + 1, path.name,
                " (torn final line — a writer was interrupted)" if index == last_index else "",
            )
            continue
        if isinstance(record, dict):
            yield record


def _read_records(artefact_root: Path) -> List[Dict[str, Any]]:
    """Every record across every segment, oldest first."""
    records: List[Dict[str, Any]] = []
    for segment in segment_paths(artefact_root):
        records.extend(_iter_records_in_file(segment))
    return records


def _is_update(record: Dict[str, Any]) -> bool:
    return bool(record.get("update"))


def fold(records: Iterable[Dict[str, Any]]) -> List[ChatMessage]:
    """Replay base messages + update lines into current messages.

    Update lines (:func:`append_update`) carry ``{"update": <target id>,
    "changes": {...}}`` and are applied in file order onto the target's
    dict. An update whose target is not in *records* is ignored — that is
    the normal case for a partial page whose base message is older than the
    window, and it must degrade quietly rather than raise.
    """
    by_id: Dict[str, Dict[str, Any]] = {}
    order: List[str] = []
    for record in records:
        if _is_update(record):
            target = str(record.get("update") or "")
            base = by_id.get(target)
            if base is None:
                continue
            _apply_changes(base, record.get("changes"))
            continue
        msg_id = str(record.get("id") or "")
        if not msg_id:
            continue
        if msg_id not in by_id:
            order.append(msg_id)
        by_id[msg_id] = dict(record)
    return [ChatMessage.from_dict(by_id[i]) for i in order]


def _apply_changes(base: Dict[str, Any], changes: Any) -> None:
    """Apply one update line's ``changes`` onto a base message dict.

    Only the three mutable shapes exist, deliberately: a question's state, a
    proposal's state (by index) and a bounded set of scalar top-level fields.
    An update can never rewrite a body — an append-only thread in which the
    text can silently change is not append-only in any useful sense.
    """
    if not isinstance(changes, dict):
        return
    question = changes.get("question")
    if isinstance(question, dict) and question.get("state"):
        current = dict(base.get("question") or {})
        current["state"] = str(question["state"])
        base["question"] = current
    proposals = changes.get("proposals")
    if isinstance(proposals, dict) and isinstance(base.get("proposals"), list):
        for raw_index, state in proposals.items():
            try:
                index = int(raw_index)
            except (TypeError, ValueError):
                continue
            if 0 <= index < len(base["proposals"]) and isinstance(base["proposals"][index], dict):
                base["proposals"][index]["state"] = str(state)
    for key in ("decisionDraft", "llm"):
        if key in changes:
            base[key] = changes[key]


def read_page(artefact_root: Path, before: Optional[str] = None,
              limit: int = 50) -> ChatPage:
    """The *limit* messages immediately BEFORE *before* (exclusive), oldest
    first within the page; the newest *limit* messages when *before* is None.

    Segments are walked newest-first and only as far back as the page needs,
    so a thread with many rotated segments does not re-read its whole history
    for one page. Update lines from newer segments are read FIRST and folded
    onto whatever base messages the window contains, which is why the walk
    starts at the newest end rather than the oldest — a page must show a
    question's current state, not the state it was posted with.

    Raises :class:`ChatMessageNotFound` if *before* names no message in the
    thread, so a client paging with a stale id is told, not silently handed
    the newest page as though it were the older one.

    *limit* is CLAMPED to :data:`MAX_PAGE_LIMIT`, never refused for being too
    large (BUG-MSO-2026-0892 item 1). Clamping here rather than only at the
    Hub endpoint is deliberate: this function is the thing that walks and
    folds segments, so the ceiling belongs where the cost is, and every
    caller — the Hub page, the chat socket's backfill, ``mso lead chat log``
    — inherits it instead of each needing its own. A caller who asked for
    more is not lied to: it gets the newest :data:`MAX_PAGE_LIMIT` messages
    with ``has_more`` set, which is exactly what paging already means.
    A non-positive *limit* is still a :class:`ChatValidationError` — that is
    a malformed request, not an oversized one, and the two deserve different
    answers.
    """
    if limit <= 0:
        raise ChatValidationError("limit must be a positive integer")
    limit = min(limit, MAX_PAGE_LIMIT)

    segments = list(reversed(segment_paths(artefact_root)))
    window: deque = deque()
    segments_read = 0

    for segment in segments:
        window.extendleft(reversed(list(_iter_records_in_file(segment))))
        segments_read += 1
        base_ids = [r.get("id") for r in window if not _is_update(r)]
        if before is None:
            older_count = len(base_ids)
        elif before in base_ids:
            older_count = base_ids.index(before)
        else:
            continue  # anchor not reached yet — keep walking back
        if older_count > limit:
            break

    exhausted = segments_read >= len(segments)
    messages = fold(window)

    if before is not None:
        index = next((i for i, m in enumerate(messages) if m.id == before), None)
        if index is None:
            if not exhausted:
                # The anchor is older than the window we chose to read. Fall
                # back to a full read rather than return a wrong page —
                # correctness beats the optimisation.
                messages = fold(_read_records(artefact_root))
                exhausted = True
                index = next((i for i, m in enumerate(messages) if m.id == before), None)
            if index is None:
                raise ChatMessageNotFound(f"No chat message '{before}' in this thread")
        messages = messages[:index]

    page = messages[-limit:] if len(messages) > limit else list(messages)
    has_more = len(messages) > len(page) or not exhausted
    return ChatPage(messages=page, has_more=has_more)


def read_since(artefact_root: Path, message_id: Optional[str] = None, *,
               missing_ok: bool = False, limit: Optional[int] = None) -> List[ChatMessage]:
    """Messages strictly AFTER *message_id*, oldest first.

    ``message_id=None`` returns the whole thread. An unknown id raises
    :class:`ChatMessageNotFound` unless *missing_ok*, in which case the whole
    thread is returned — the right behaviour for a daemon resuming from a
    cursor it can no longer place, which must not crash-loop.
    """
    messages = fold(_read_records(artefact_root))
    if message_id:
        index = next((i for i, m in enumerate(messages) if m.id == message_id), None)
        if index is None:
            if not missing_ok:
                raise ChatMessageNotFound(f"No chat message '{message_id}' in this thread")
        else:
            messages = messages[index + 1:]
    if limit is not None and limit >= 0:
        messages = messages[:limit]
    return messages


def open_questions(artefact_root: Path) -> List[ChatMessage]:
    """Every question still ``open`` after folding, oldest first."""
    return [m for m in fold(_read_records(artefact_root)) if m.is_open_question]


def recent_decisions(artefact_root: Path, days: int = 7) -> List[ChatMessage]:
    """``decision`` messages from the last *days*, oldest first.

    A message whose timestamp cannot be parsed is INCLUDED, not dropped: a
    decision is the highest-value content in the thread, and silently hiding
    one because its timestamp is malformed is the worse failure.
    """
    cutoff = _utc_now() - timedelta(days=max(days, 0))
    out: List[ChatMessage] = []
    for msg in fold(_read_records(artefact_root)):
        if msg.kind != "decision":
            continue
        ts = _parse_ts(msg.ts)
        if ts is None or ts >= cutoff:
            out.append(msg)
    return out


def _parse_ts(value: str) -> Optional[datetime]:
    try:
        parsed = datetime.fromisoformat(str(value))
    except (TypeError, ValueError):
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed


def unanswered_captain_messages(artefact_root: Path,
                                since_id: Optional[str] = None) -> List[ChatMessage]:
    """Captain messages after *since_id* that no ``reply`` answers yet.

    The daemon's inbox (Order 3). Oldest first, so it answers in order.
    """
    messages = read_since(artefact_root, since_id, missing_ok=True)
    answered = {m.in_reply_to for m in messages if m.kind == "reply" and m.in_reply_to}
    return [
        m for m in messages
        if m.author.kind == "captain" and m.kind == "text" and m.id not in answered
    ]


# ---------------------------------------------------------------------------
# Cursor — how far the LEAD daemon has read
# ---------------------------------------------------------------------------

def load_cursor(artefact_root: Path) -> Optional[str]:
    """The last message id the daemon processed, or None. Never raises."""
    try:
        data = json.loads(cursor_path(artefact_root).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    value = data.get("lastSeenId") if isinstance(data, dict) else None
    return str(value) if value else None


def save_cursor(artefact_root: Path, message_id: str) -> Path:
    """Persist the daemon's read cursor atomically (write-temp-then-replace),
    so a crash mid-write can never leave a truncated cursor that would make
    the daemon re-answer messages it has already answered."""
    path = cursor_path(artefact_root)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(
        {"lastSeenId": str(message_id), "updatedAt": _iso()}, indent=2
    ) + "\n"
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(payload, encoding="utf-8")
    os.replace(str(tmp), str(path))
    return path


# ---------------------------------------------------------------------------
# Writing
# ---------------------------------------------------------------------------

def _validate_body(body: Optional[str]) -> str:
    text = (body or "").strip()
    if not text:
        raise ChatValidationError("Message body is required")
    if len(text) > MAX_BODY_CHARS:
        raise ChatValidationError(
            f"Message body exceeds {MAX_BODY_CHARS} characters ({len(text)} given)"
        )
    return text


def _validate_choice(value: str, allowed: Sequence[str], label: str) -> str:
    if value not in allowed:
        raise ChatValidationError(
            f"Invalid {label} '{value}' — must be one of {', '.join(allowed)}"
        )
    return value


def _ends_mid_line(path: Path) -> bool:
    """True if *path* exists, is non-empty and does NOT end with a newline —
    i.e. its last line was never finished. Reads one byte."""
    try:
        size = path.stat().st_size
        if size == 0:
            return False
        with open(str(path), "rb") as handle:
            handle.seek(size - 1)
            return handle.read(1) != b"\n"
    except OSError:
        return False


# The three characters json.dumps(ensure_ascii=False) leaves literal but
# str.splitlines() (and several non-Python JSONL readers, and pre-ES2019
# JavaScript) treat as line breaks. Escaping them is lossless: "\u2028" decodes
# back to the same character, so a body round-trips byte-identically.
_LINE_BREAK_ESCAPES = {
    "\u2028": "\\u2028",  # LINE SEPARATOR
    "\u2029": "\\u2029",  # PARAGRAPH SEPARATOR
    "\u0085": "\\u0085",  # NEL
}


def _encode_record(record: Dict[str, Any]) -> str:
    """One record -> its exact on-disk JSON text, with no embedded line break.

    The single place a record becomes bytes, so the rotation size estimate and
    the line actually written can never disagree.
    """
    line = json.dumps(record, ensure_ascii=False, separators=(",", ":"))
    for char, escape in _LINE_BREAK_ESCAPES.items():
        if char in line:
            # Safe as a blind replace: JSON's structural characters are all
            # ASCII, so these can only occur inside a string literal.
            line = line.replace(char, escape)
    return line


def _write_line(path: Path, record: Dict[str, Any]) -> None:
    """One record -> one line, in a single ``write()``, flushed and fsync'd.

    The single write is what bounds torn-line damage to the tail; the fsync
    is what makes a message that a caller was told was persisted survive a
    power loss, which is the whole reason this lives in ``state/`` rather
    than ``logs/``.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    line = _encode_record(record) + "\n"
    if _ends_mid_line(path):
        # A previous writer died between write() and the newline. Close its
        # torn line first, or this append is appended ONTO it and both become
        # one unparseable line — the torn tail would then swallow every
        # message written after it, turning a one-line loss into a permanent
        # one. The torn line stays torn (readers skip it); this one lands.
        line = "\n" + line
    with open(str(path), "a", encoding="utf-8") as handle:
        handle.write(line)
        handle.flush()
        try:
            os.fsync(handle.fileno())
        except OSError:
            # A filesystem that cannot fsync (some network mounts) must not
            # make the append fail — the line is already written and flushed.
            pass


_SCAN_CHUNK_BYTES = 256 * 1024


def _id_stamp(msg_id: str) -> str:
    """The ``<utc-compact>`` half of a chat id, or "" if it is not one."""
    if not msg_id.startswith("CHAT-"):
        return ""
    stamp, sep, _hex = msg_id[len("CHAT-"):].rpartition("-")
    return stamp if sep else ""


def _same_second_ids_in_segment(path: Path, prefix: str) -> Tuple[set, bool]:
    """Ids in one segment sharing *prefix*, plus "the run ended in here".

    Reads BACKWARDS in :data:`_SCAN_CHUNK_BYTES` chunks and stops at the first
    record whose id stamp is older than *prefix* — at that point every
    same-second id in this segment and in every older one has been passed, so
    the caller can stop too. Normally that is one chunk of one segment.
    """
    try:
        size = path.stat().st_size
    except OSError:
        return set(), False
    found: set = set()
    target = prefix[len("CHAT-"):-1]
    pos = size
    carry = b""
    while pos > 0:
        start = max(0, pos - _SCAN_CHUNK_BYTES)
        try:
            with open(str(path), "rb") as handle:
                handle.seek(start)
                data = handle.read(pos - start)
        except OSError:
            return found, False
        pos = start
        data += carry
        if pos > 0:
            head, sep, rest = data.partition(b"\n")
            if not sep:
                # No complete line in this chunk yet — widen and re-read.
                carry = data
                continue
            carry, data = head, rest
        else:
            carry = b""
        for line in reversed(data.decode("utf-8", errors="replace").split("\n")):
            line = line.strip()
            if not line:
                continue
            try:
                record = json.loads(line)
            except json.JSONDecodeError:
                continue
            if not isinstance(record, dict):
                continue
            msg_id = record.get("id")
            if not isinstance(msg_id, str):
                continue
            if msg_id.startswith(prefix):
                found.add(msg_id)
                continue
            stamp = _id_stamp(msg_id)
            if stamp and len(stamp) == len(target) and stamp < target:
                # Older than the second being minted for. Appends are
                # lock-serialised and ids are time-prefixed, so nothing behind
                # this point can share the prefix.
                return found, True
    return found, False


def _ids_minted_this_second(artefact_root: Path, prefix: str) -> set:
    """EVERY id in the thread sharing *prefix* (``CHAT-<second>-``).

    Complete, not a bounded sample. The first version of this read a fixed
    256 KB tail of the ACTIVE segment only, which two things broke: ~32
    maximum-length messages in one second exhausted the window (so the oldest
    same-second ids were invisible and could be re-minted), and a rotation
    hid every same-second id that had just been moved into the retired
    segment. Both were bounded and improbable, but "ids are never reused" is
    load-bearing for ``inReplyTo``, the cursor and decision promotion, and
    ``fold()`` keys strictly by id — a reused id silently drops a message.

    So the scan walks segments newest-first and reads each backwards, stopping
    the moment it passes a record older than *prefix*. Cost in the ordinary
    case is one chunk of the active segment; the walk only widens when a
    single second genuinely holds that much traffic.

    Caller holds the append lock.
    """
    found: set = set()
    for segment in reversed(segment_paths(Path(artefact_root))):
        ids, passed_older = _same_second_ids_in_segment(segment, prefix)
        found |= ids
        if passed_older:
            break
    return found


def _mint_id(artefact_root: Path, now: datetime,
             exclude: Optional[set] = None) -> str:
    """Mint an id that is not already in the thread. Caller holds the lock.

    *exclude* carries ids minted in this same critical section but not yet
    written (the rotation continuation line is minted alongside the
    message that triggered the rotation), so "never reused" holds across
    the whole append, not just against what is already on disk.
    """
    prefix = f"CHAT-{_compact(now)}-"
    taken = _ids_minted_this_second(artefact_root, prefix)
    taken |= set(exclude or ())
    for _ in range(64):
        candidate = f"{prefix}{secrets.token_hex(3)}"
        if candidate not in taken:
            return candidate
    # 64 collisions in one second against a 16.7M space is not luck, it is a
    # broken RNG. Widen rather than return a duplicate id.
    return f"{prefix}{secrets.token_hex(8)}"


def _rotate_if_needed(artefact_root: Path, incoming_bytes: int,
                      now: datetime, workspace: str,
                      exclude: Optional[set] = None) -> None:
    """Rotate the active segment past :data:`ROTATION_BYTES`. Caller holds
    the lock.

    The retired segment keeps its content untouched and is NEVER deleted
    automatically (plan §0 Q3) — paged reads walk it. The new active segment
    opens with a ``system`` "continued from" message so a reader landing at
    the top of a segment can see where its history came from.
    """
    active = thread_path(artefact_root)
    try:
        size = active.stat().st_size
    except OSError:
        return
    if size + incoming_bytes <= ROTATION_BYTES:
        return

    # Minted BEFORE the rename, while the active segment is still readable,
    # so the continuation line cannot reuse an id already in the segment it
    # is pointing at.
    continued_id = _mint_id(artefact_root, now, exclude=exclude)
    stamp = now.strftime("%Y%m%d%H%M%S")
    target = active.parent / f"thread-{stamp}.jsonl"
    suffix = 1
    while target.exists():
        target = active.parent / f"thread-{stamp}-{suffix}.jsonl"
        suffix += 1
    try:
        os.replace(str(active), str(target))
    except OSError as exc:
        _log.warning("captain-chat: rotation failed (%s) — continuing to append", exc)
        return

    continued = ChatMessage(
        id=continued_id,
        ts=_iso(now),
        workspace=workspace,
        author=Author(kind="system", id=AUTHOR_SYSTEM, display_name="Maestro"),
        kind="status",
        body=f"Thread continued from {target.name} (rotated at {ROTATION_BYTES} bytes).",
    )
    _write_line(active, continued.to_dict())


def append_message(
    artefact_root: Path,
    *,
    kind: str,
    body: str,
    author: Author,
    subject: Optional[Subject] = None,
    in_reply_to: Optional[str] = None,
    proposals: Optional[Sequence[Proposal]] = None,
    decision_draft: Optional[Dict[str, Any]] = None,
    question_state: Optional[str] = None,
    llm: Optional[LlmUsage] = None,
    workspace: Optional[str] = None,
    log_lifecycle: bool = True,
) -> ChatMessage:
    """Append one message and return it, with the id the thread actually got.

    The id is minted and the line written inside one hold of
    :func:`lock_for_append`, never composed by the caller — the same rule
    ``order_ids`` states for order ids, for the same reason.

    Raises :class:`ChatValidationError` on an empty/oversized body or an
    unknown ``kind``/``question_state``/proposal state.
    """
    root = Path(artefact_root)
    _validate_choice(kind, MESSAGE_KINDS, "message kind")
    _validate_choice(author.kind, AUTHOR_KINDS, "author kind")
    text = _validate_body(body)
    if kind == "question" and question_state is None:
        question_state = "open"
    if question_state is not None:
        _validate_choice(question_state, QUESTION_STATES, "question state")
    prepared = [Proposal.from_dict(p.to_dict()) for p in (proposals or [])]
    for proposal in prepared:
        if not proposal.verb_id:
            raise ChatValidationError("A proposal must name a verbId")
        _validate_choice(proposal.state, PROPOSAL_STATES, "proposal state")

    label = workspace or resolve_workspace_label(root)
    now = _utc_now()

    message = ChatMessage(
        id="",  # minted under the lock, below
        ts=_iso(now),
        workspace=label,
        author=author,
        kind=kind,
        in_reply_to=in_reply_to or None,
        subject=subject or Subject(),
        body=text,
        proposals=prepared,
        decision_draft=decision_draft or None,
        question=({"state": question_state} if question_state is not None else None),
        llm=llm,
    )

    with _WRITE_LOCK:
        with lock_for_append(root):
            message.id = _mint_id(root, now)
            payload = message.to_dict()
            encoded = len(_encode_record(payload).encode("utf-8")) + 1
            _rotate_if_needed(root, encoded, now, label, exclude={message.id})
            _write_line(thread_path(root), payload)

    if log_lifecycle:
        try:
            _write_lifecycle(root, message)
        except Exception:  # pragma: no cover - defensive
            # The message is already fsync'd to disk. Raising here would tell
            # the caller their message was lost when it was not.
            _log.debug("captain-chat: lifecycle write failed", exc_info=True)
    return message


def append_update(
    artefact_root: Path,
    target_id: str,
    *,
    question_state: Optional[str] = None,
    proposal_states: Optional[Dict[int, str]] = None,
    decision_draft: Optional[Dict[str, Any]] = None,
    llm: Optional[LlmUsage] = None,
    reason: str = "",
    actor: str = AUTHOR_LEAD_DAEMON,
    log_lifecycle: bool = False,
) -> Dict[str, Any]:
    """Fold a state change onto an EXISTING message by appending a new line.

    Nothing earlier in the file is rewritten — the same append-only
    discipline ``order_ledger.py`` uses. :func:`fold` replays these onto the
    base message, so a reader that races a writer sees either the old state
    or the new one, never a half-rewritten record.

    Raises :class:`ChatMessageNotFound` if *target_id* is not in the thread,
    and :class:`ChatValidationError` on an unknown state or an update that
    changes nothing.
    """
    root = Path(artefact_root)
    messages = fold(_read_records(root))
    target = next((m for m in messages if m.id == target_id), None)
    if target is None:
        raise ChatMessageNotFound(f"No chat message '{target_id}' in this thread")

    changes: Dict[str, Any] = {}
    if question_state is not None:
        _validate_choice(question_state, QUESTION_STATES, "question state")
        changes["question"] = {"state": question_state}
    if proposal_states:
        folded: Dict[str, str] = {}
        for index, state in proposal_states.items():
            _validate_choice(str(state), PROPOSAL_STATES, "proposal state")
            if not (0 <= int(index) < len(target.proposals)):
                raise ChatValidationError(
                    f"Message '{target_id}' has no proposal at index {index}"
                )
            folded[str(int(index))] = str(state)
        changes["proposals"] = folded
    if decision_draft is not None:
        changes["decisionDraft"] = decision_draft
    if llm is not None:
        changes["llm"] = llm.to_dict()
    if not changes:
        raise ChatValidationError("An update must change at least one field")

    now = _utc_now()
    record: Dict[str, Any] = {
        "v": SCHEMA_VERSION,
        "id": "",
        "ts": _iso(now),
        "update": target_id,
        "actor": actor,
        "reason": reason,
        "changes": changes,
    }

    with _WRITE_LOCK:
        with lock_for_append(root):
            record["id"] = _mint_id(root, now)
            encoded = len(_encode_record(record).encode("utf-8")) + 1
            _rotate_if_needed(root, encoded, now,
                              target.workspace or resolve_workspace_label(root),
                              exclude={record["id"]})
            _write_line(thread_path(root), record)

    if log_lifecycle:
        try:
            _write_lifecycle_line(
                root,
                f"msg={record['id']} author={actor} kind=update subject={target_id}",
            )
        except Exception:  # pragma: no cover - defensive
            _log.debug("captain-chat: lifecycle write failed", exc_info=True)
    return record


# ---------------------------------------------------------------------------
# Convenience writers — one per author kind, so no surface invents its own
# ---------------------------------------------------------------------------

def post_captain_message(
    artefact_root: Path,
    body: str,
    *,
    author_id: str,
    display_name: str = "",
    verified: bool = False,
    in_reply_to: Optional[str] = None,
    subject: Optional[Subject] = None,
    workspace: Optional[str] = None,
    workspace_root: Optional[Path] = None,
) -> ChatMessage:
    """The Captain says something. The ONE entry point for a human post —
    ``mso lead chat say`` and the Hub's ``POST .../lead/chat`` both call it.

    ``require_capability("lead.chat.post")`` is enforced HERE, in the core,
    so a later caller inherits the gate rather than forgetting it
    (FTR-MSO-2026-0492's shape). It is a no-op outside governed/enterprise
    workspaces and raises :class:`maestro.identity.gate.CapabilityDenied`
    (-> HTTP 403) inside one.
    """
    root = Path(artefact_root)
    from maestro.identity.gate import require_capability

    require_capability(
        "lead.chat.post",
        workspace=Path(workspace_root) if workspace_root else root.parent,
    )
    return append_message(
        root,
        kind="text",
        body=body,
        author=Author(
            kind="captain", id=author_id, display_name=display_name, verified=verified,
        ),
        in_reply_to=in_reply_to,
        subject=subject,
        workspace=workspace,
    )


def post_lead_message(
    artefact_root: Path,
    body: str,
    *,
    kind: str = "reply",
    in_reply_to: Optional[str] = None,
    subject: Optional[Subject] = None,
    proposals: Optional[Sequence[Proposal]] = None,
    decision_draft: Optional[Dict[str, Any]] = None,
    question_state: Optional[str] = None,
    llm: Optional[LlmUsage] = None,
    author_id: str = AUTHOR_LEAD_DAEMON,
    workspace: Optional[str] = None,
) -> ChatMessage:
    """The LEAD says something — a proactive ``question`` (Order 2) or a
    ``reply`` (Order 3). Never tier-gated here; the daemon's own gate applies.
    """
    return append_message(
        Path(artefact_root),
        kind=kind,
        body=body,
        author=Author(kind="lead", id=author_id, display_name="LEAD (AI)"),
        in_reply_to=in_reply_to,
        subject=subject,
        proposals=proposals,
        decision_draft=decision_draft,
        question_state=question_state,
        llm=llm,
        workspace=workspace,
    )


def post_system_message(
    artefact_root: Path,
    body: str,
    *,
    kind: str = "status",
    in_reply_to: Optional[str] = None,
    subject: Optional[Subject] = None,
    workspace: Optional[str] = None,
) -> ChatMessage:
    """Maestro itself says something — a ceiling notice, a proposal result, a
    rotation marker. Never an LLM, never a human."""
    return append_message(
        Path(artefact_root),
        kind=kind,
        body=body,
        author=Author(kind="system", id=AUTHOR_SYSTEM, display_name="Maestro"),
        in_reply_to=in_reply_to,
        subject=subject,
        workspace=workspace,
    )


# ---------------------------------------------------------------------------
# Lifecycle — METADATA ONLY (plan §0 Q3)
# ---------------------------------------------------------------------------

def _write_lifecycle(artefact_root: Path, message: ChatMessage) -> None:
    """``CAPTAIN_CHAT msg=<id> author=<kind> kind=<kind> subject=<ref>``.

    The body is deliberately absent and must stay absent: ``lifecycle.log``
    is written for every workspace, read by the Hub and the patrol, and
    swept into bug reports — it must never become a second, less-protected
    copy of the conversation.
    """
    _write_lifecycle_line(
        artefact_root,
        f"msg={message.id} author={message.author.kind} "
        f"kind={message.kind} subject={message.subject.ref}",
    )


def _write_lifecycle_line(artefact_root: Path, metadata: str,
                          event: str = LIFECYCLE_EVENT) -> None:
    """Best-effort lifecycle append inside ``workspace_scope``.

    *event* defaults to ``CAPTAIN_CHAT``; :func:`confirm_proposal` passes
    ``LEAD_ACTION`` so a chat-triggered run lands in the SAME event stream as
    the drawer's Run button, distinguished by ``trigger=``, rather than
    inventing a parallel vocabulary an operator would have to learn.

    The scope is not decoration: ``write_lifecycle_event`` resolves its
    target from ``fleet_runner._MAESTRO_DIR_OVERRIDE``, a process global, so
    an unscoped write from a Hub thread serving workspace A can land in
    workspace B's log. Never raises — a logging failure must not lose a
    message that is already durably on disk.
    """
    try:
        from maestro.core.fleet_runner import write_lifecycle_event
        from maestro.core.order_retry import workspace_scope

        with workspace_scope(Path(artefact_root)):
            write_lifecycle_event(event, metadata)
    except Exception:  # pragma: no cover - defensive
        _log.debug("captain-chat: lifecycle write failed", exc_info=True)


# ---------------------------------------------------------------------------
# Answering a LEAD question (plan §0 Q3: open -> answered)
# ---------------------------------------------------------------------------

def answer_question(artefact_root: Path, question_id: str, *,
                    actor: str = AUTHOR_HUB, reason: str = "") -> bool:
    """Fold an OPEN question to ``answered``. Returns whether it changed.

    Idempotent and non-fatal by design: a question already ``answered``,
    ``expired`` or ``superseded`` returns ``False`` rather than raising,
    because the Captain's reply is the thing that matters and it has already
    been posted by the time this runs. Only a genuinely unknown id raises
    :class:`ChatMessageNotFound`.
    """
    root = Path(artefact_root)
    target = next((m for m in fold(_read_records(root)) if m.id == question_id), None)
    if target is None:
        raise ChatMessageNotFound(f"No chat message '{question_id}' in this thread")
    if not target.is_open_question:
        return False
    append_update(root, question_id, question_state="answered",
                  actor=actor, reason=reason or "captain replied")
    return True


def post_captain_reply(
    artefact_root: Path,
    question_id: str,
    body: str,
    *,
    author_id: str,
    display_name: str = "",
    verified: bool = False,
    workspace: Optional[str] = None,
    workspace_root: Optional[Path] = None,
) -> ChatMessage:
    """The Captain answers a LEAD question — post + fold, as ONE operation.

    ``mso lead chat reply`` and the Hub's reply control both call this, so
    the question-state transition can never be done by one surface and
    forgotten by the other (the drift BUG-MSO-2026-0486 is the record of).

    The message itself is an ordinary Captain ``text`` message, deliberately:
    ``unanswered_captain_messages`` must still pick it up, because a Captain
    answering a LEAD question is usually also asking the LEAD to act on the
    answer. The ``answered`` fold is about the QUESTION's state, not about
    ending the exchange.

    Raises :class:`ChatMessageNotFound` if *question_id* is not in the
    thread — BEFORE posting, so a typo'd id never leaves an orphan message
    replying to nothing.
    """
    root = Path(artefact_root)
    target = next((m for m in fold(_read_records(root)) if m.id == question_id), None)
    if target is None:
        raise ChatMessageNotFound(f"No chat message '{question_id}' in this thread")

    message = post_captain_message(
        root, body,
        author_id=author_id, display_name=display_name, verified=verified,
        in_reply_to=question_id,
        subject=target.subject if not target.subject.is_empty else None,
        workspace=workspace,
        workspace_root=workspace_root,
    )
    try:
        answer_question(root, question_id, actor=author_id,
                        reason=f"answered by {message.id}")
    except Exception:  # pragma: no cover - defensive
        # The reply is on disk. Failing the call now would tell the Captain
        # their message was lost when only the state fold was.
        _log.debug("captain-chat: question fold failed", exc_info=True)
    return message


# ---------------------------------------------------------------------------
# Confirming a proposal (PLAN-PLN-MSO-2026-0828 Order 4, FTR-MSO-2026-0848)
# ---------------------------------------------------------------------------
#
# THE GOVERNANCE BOUNDARY. Chat text is never itself authority: nothing a
# Captain (or the LEAD) writes in the thread runs anything. The ONLY way an
# effect leaves a conversation is an explicit, typed confirmation of a
# proposal whose verb is on ``run_verbs``' CLOSED list, and that confirmation
# runs EXACTLY the code path the Hub's LEAD-drawer Run button already runs:
#
#     the blast-radius exclusion           (run_verbs.is_chat_proposal_
#                                           excluded, 0888)
#     -> the freshness window              (proposal_is_stale, 0888)
#     -> re-validate against the closed list  (run_verbs.parse_verb_id)
#     -> the D6 must_not ceiling           (run_verbs.is_forbidden)
#     -> the verb's EXISTING handler       (order_retry.retry_order, the
#                                           reconcile subprocess)
#     -> LEAD_ACTION + audit               (trigger=captain-chat)
#     -> the outcome posted back           (a `proposal-result` message)
#
# Net effect: chat can do LESS than the Run button can do, and never more
# (SEC-MSO-2026-0888). It used to be exactly the same set, because it was
# exactly the same list; `dispatcher.cleanup` is now the one member of that
# list the chat surface refuses, because the Run button's safety mechanism —
# re-running the originating finding's check immediately before acting
# (BUG-MSO-2026-0662 F1) — has no equivalent here to run.
# There is no merge, tag, publish, source-edit or guard-bypass verb anywhere
# on that list — ``pr.merge`` is on it only as a structural safety-net entry
# that the must_not ceiling refuses — so "the Captain said merge it in chat"
# cannot happen, on any surface, by construction rather than by policy.
#
# NO NEW AUTHORITY IS CREATED HERE. Licence-tier gating stays at the call
# site (the Hub's `_require_control_tier()`, the CLI's `LEAD_AGENT_TIERS`),
# exactly as maestro/lead/control.py records; each verb's own capability gate
# stays inside its own core (`order.dispatch` inside `retry_order`). This
# function adds no third gate of its own, because a new gate here would be a
# new place for the ceiling to be defined — and therefore a new place for it
# to drift.

@dataclass(frozen=True)
class ConfirmOutcome:
    """What a confirmed proposal actually did.

    ``outcome`` mirrors the Hub RunResult vocabulary exactly — ``accepted``
    (the handler ran and reported success), ``refused`` (the must_not
    ceiling, re-validation, or the freshness window said no; NOTHING ran)
    and ``failed`` (the handler ran and reported, or raised, a failure).
    ``ok`` is True only for ``accepted``.

    ``proposal_state`` is what distinguishes the three kinds of refusal:
    ``refused`` for a verb that is not runnable or not permitted, and
    ``expired`` for one that was both but too old to act on
    (SEC-MSO-2026-0888). A caller that only switches on ``outcome`` still
    behaves correctly — it just tells the operator less.
    """

    ok: bool
    outcome: str
    verb_id: str
    message: str
    proposal_state: str
    message_id: str = ""
    index: int = 0
    result_message_id: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "ok": bool(self.ok),
            "outcome": self.outcome,
            "verbId": self.verb_id,
            "message": self.message,
            "proposalState": self.proposal_state,
            "messageId": self.message_id,
            "index": int(self.index),
            "resultMessageId": self.result_message_id,
        }


#: outcome -> the proposal state it folds to. "refused" and "failed" are
#: deliberately distinct: refused means NOTHING RAN (the ceiling, or
#: re-validation, said no), failed means the handler ran and did not succeed.
#: Collapsing them would hide which of the two happened, and they call for
#: opposite responses from an operator.
_CONFIRM_TERMINAL_OUTCOMES = {
    "refused": "refused", "failed": "failed", "accepted": "confirmed",
}


# ---------------------------------------------------------------------------
# Freshness (SEC-MSO-2026-0888)
# ---------------------------------------------------------------------------
#
# THE THIRD REFUSAL REASON. Re-validation asks "is this verb still runnable
# at all"; the must_not ceiling asks "is it allowed"; neither asks "is it
# still the right thing to do". A proposal is written about fleet state
# observed at one instant — "the dispatcher looks wedged, shall I run
# `mso cleanup`?" — and nothing about a verb that was safe to offer on
# Monday makes it safe to run on Friday. `dispatcher.cleanup` is the case
# the order names: it kills processes and clears state, so confirming a
# week-old offer reaps whatever is running NOW to fix a wedge that is long
# gone. Before this, an `offered` proposal was confirmable forever; the
# `expired` member of PROPOSAL_STATES existed and nothing ever produced it.
#
# Expiry is measured from the MESSAGE's timestamp, not a new field on the
# Proposal, because that is already exactly the offered-at time: proposals
# are only ever born with their message (`_apply_update` folds a proposal's
# STATE by index and can add nothing), so no schema change, no migration,
# and every thread already on disk is covered by the same rule.

def resolve_proposal_ttl_minutes(artefact_root: Path) -> int:
    """``lead.chat.proposalTtlMinutes``, via the ONE config reader.

    ``0`` means expiry is disabled (the documented escape hatch). An
    unreadable config falls back to the shipped default rather than to
    "disabled": a workspace whose config cannot be parsed must keep the
    protection, not silently lose it.
    """
    try:
        from maestro.lead.agent import load_lead_config

        chat_cfg = load_lead_config(Path(artefact_root)).get("chat") or {}
        from maestro.lead.agent import DEFAULT_CHAT_PROPOSAL_TTL_MINUTES

        value = int(chat_cfg.get(
            "proposalTtlMinutes", DEFAULT_CHAT_PROPOSAL_TTL_MINUTES))
        return value if value >= 0 else DEFAULT_CHAT_PROPOSAL_TTL_MINUTES
    except Exception:  # noqa: BLE001 — config must never break a confirm
        try:
            from maestro.lead.agent import DEFAULT_CHAT_PROPOSAL_TTL_MINUTES

            return DEFAULT_CHAT_PROPOSAL_TTL_MINUTES
        except Exception:  # pragma: no cover - defensive
            return 60


def proposal_age_minutes(message: ChatMessage,
                         now: Optional[datetime] = None) -> Optional[float]:
    """How many minutes ago *message* offered its proposals, or ``None``.

    ``None`` means the timestamp could not be read — an answer the caller
    must decide about, never one this function guesses at.
    """
    stamp = _parse_ts(message.ts)
    if stamp is None:
        return None
    delta = (now or _utc_now()) - stamp
    return delta.total_seconds() / 60.0


def proposal_is_stale(message: ChatMessage, *, ttl_minutes: int,
                      now: Optional[datetime] = None) -> bool:
    """Is *message*'s offer too old to act on?

    ``ttl_minutes <= 0`` disables the check and nothing is ever stale.

    AN UNREADABLE TIMESTAMP IS STALE — and this is the deliberate opposite
    of `chat_responder.is_stale`, which treats one as fresh. The two
    asymmetries point in opposite directions because the costs do. There, a
    wrong answer either wastes one LLM reply or silently declines to answer
    the Captain, so the cheap error is "answer it". Here, a wrong answer
    either costs the Captain re-asking for a proposal or runs `mso cleanup`
    against a live fleet on the strength of a timestamp we could not read,
    so the cheap error is "refuse it". An inability to verify a safety
    mechanism is not permission — the same rule `confirm_proposal` already
    applies to a ceiling that raises.

    A timestamp in the FUTURE (clock skew between the Hub and the daemon, a
    hand-edited thread) yields a negative age and is therefore NOT stale.
    That is the honest reading: skew is not evidence of age, and refusing a
    proposal because a clock ran fast would be a new failure mode in place
    of the one being closed.
    """
    if int(ttl_minutes) <= 0:
        return False
    age = proposal_age_minutes(message, now=now)
    if age is None:
        return True
    return age > float(ttl_minutes)


def _age_for_message(message: ChatMessage) -> Optional[float]:
    """:func:`proposal_age_minutes`, but never raising. ``None`` on any
    failure, which :func:`_expiry_refusal_message` renders as "age could not
    be verified" — the honest thing to say when it could not."""
    try:
        return proposal_age_minutes(message)
    except Exception:  # pragma: no cover - defensive
        return None


def _expiry_refusal_message(verb_id: str, age_minutes: Optional[float],
                            ttl_minutes: int) -> str:
    """Why the confirm was refused, in words an operator can act on.

    Names the verb, how stale it is and what to do instead. A refusal that
    does not say what would work leaves the Captain to guess, and guessing
    here means hunting for a way to force it.
    """
    if age_minutes is None:
        aged = "its timestamp could not be read, so its age cannot be verified"
    elif age_minutes >= 120:
        aged = f"it was offered about {age_minutes / 60:.0f} hours ago"
    else:
        aged = f"it was offered about {max(age_minutes, 0):.0f} minutes ago"
    return (
        f"'{verb_id}' has expired — {aged}, past this workspace's "
        f"{ttl_minutes}-minute proposal window. Nothing ran. A proposal "
        "describes the fleet as it was when it was offered, and that is no "
        "longer the fleet this would run against. Ask the LEAD again and "
        "confirm the fresh proposal it offers."
    )


def _excluded_refusal_message(verb_id: str) -> str:
    """Why an excluded verb was refused, and where it CAN still be run.

    Says the three things a refusal has to say: that nothing ran, that this
    is categorical rather than a matter of timing, and what the working
    route is. Without the last one the Captain is left hunting for a way to
    force it, which is how a refusal turns into a workaround.
    """
    return (
        f"'{verb_id}' cannot be run from the chat, by anyone. Nothing ran. "
        "This verb changes live fleet state, and a chat proposal carries no "
        "condition that can be re-checked at the moment you confirm it — so "
        "it could only ever run against the fleet as it was described, not "
        "the fleet as it is. Run it from the Hub's LEAD drawer instead, "
        "where the finding's own check is re-confirmed immediately before "
        "it fires, or run the command yourself."
    )


def confirm_proposal(
    artefact_root: Path,
    message_id: str,
    index: int,
    *,
    confirmed_by: str = AUTHOR_HUB,
    product_repo: Optional[Path] = None,
    workspace_root: Optional[Path] = None,
) -> ConfirmOutcome:
    """Execute proposal *index* of *message_id* — the one confirm path.

    *artefact_root* is the ``.mso`` dir, which is what ``run_verbs``'
    handlers take as their ``mso`` argument. *product_repo* is the product
    checkout (``None`` where there is none), passed through to
    ``is_forbidden`` and to the handlers exactly as ``run_lead_finding``
    passes it.

    Re-validation, every time
    -------------------------
    The proposal is re-parsed **from its ``verbId`` and ``args``**, through
    ``run_verbs.parse_verb_id`` — never from any stored command text, and
    never trusted because it was stored. A proposal is persisted data written
    by an LLM (Order 3) or by a template (Order 2); having survived a round
    trip through a JSONL file makes it no more trustworthy than it was when
    it was generated. An unknown verb id, or arguments its pattern refuses,
    is ``refused`` here — not passed to a handler.

    Never runnable from here (SEC-MSO-2026-0888)
    --------------------------------------------
    A verb in ``run_verbs.CHAT_PROPOSAL_EXCLUDED_VERB_IDS`` —
    ``dispatcher.cleanup``, and today only that — is refused here
    unconditionally, ahead of every other gate, however old the proposal is
    and however it came to be offered. It stays runnable from the Hub's Run
    button, whose pre-flight re-check of the originating finding
    (BUG-MSO-2026-0662 F1) is the safety mechanism this surface cannot
    reproduce for BOTH of the ways a proposal is born: a proactive one keeps
    its finding's fingerprint and could in principle re-check (the check id
    is looked up by that fingerprint, not derived from it), but an
    LLM-authored one never had a finding, a fingerprint or a check at all.
    Half a guard is not a guard — see
    ``run_verbs.CHAT_PROPOSAL_EXCLUDED_VERB_IDS`` for the full reasoning.

    Still worth doing (SEC-MSO-2026-0888)
    -------------------------------------
    An offered proposal is confirmable only inside
    ``lead.chat.proposalTtlMinutes`` of the message that offered it (60
    minutes by default; ``0`` disables the window). Past that it folds to
    ``expired`` and is refused — nothing runs, and it can never run
    afterwards. Re-validation asks whether the verb is runnable and the
    ceiling asks whether it is permitted; a stale `dispatcher.cleanup`
    passes both and is still the wrong thing to do, because the fleet it
    was offered about is not the fleet it would run against.

    Exactly once
    ------------
    The state check and the state write happen together, under
    :data:`CONFIRM_LOCK_FILENAME`, and the proposal is marked ``confirmed``
    BEFORE the handler runs. So two concurrent confirms cannot both reach the
    handler: the loser finds a non-``offered`` state and raises
    :class:`ProposalAlreadyResolved`. A handler that then fails folds the
    state on to ``failed``; a refusal never claims the proposal at all, and
    marks it ``refused`` instead — a refused proposal was never executed and
    must not read as though it were.

    Raises :class:`ChatMessageNotFound`, :class:`ProposalNotFound`,
    :class:`ProposalAlreadyResolved`; every other failure is REPORTED as an
    outcome, because "the action failed" is an ordinary, renderable business
    result and not an exception. Expiry is an outcome, not an exception, for
    that reason — but a SECOND confirm of a proposal already folded to
    ``expired`` does raise :class:`ProposalAlreadyResolved`, exactly as a
    second confirm of any other resolved proposal does.
    """
    root = Path(artefact_root)
    from maestro.lead import run_verbs

    # --- claim (serialised) -------------------------------------------------
    with _CrossProcessLock(confirm_lock_path(root)):
        target = next((m for m in fold(_read_records(root)) if m.id == message_id), None)
        if target is None:
            raise ChatMessageNotFound(f"No chat message '{message_id}' in this thread")
        try:
            position = int(index)
        except (TypeError, ValueError):
            raise ChatValidationError(f"Proposal index '{index}' is not an integer")
        if not (0 <= position < len(target.proposals)):
            raise ProposalNotFound(
                f"Message '{message_id}' has no proposal at index {position} "
                f"({len(target.proposals)} offered)"
            )
        proposal = target.proposals[position]
        if proposal.state != "offered":
            raise ProposalAlreadyResolved(message_id, position, proposal.state)

        verb_id = proposal.verb_id

        # BLAST-RADIUS EXCLUSION (SEC-MSO-2026-0888) — FIRST, ahead of the
        # freshness window and ahead of re-validation.
        #
        # First because it is CATEGORICAL, and the others are conditional. A
        # `dispatcher.cleanup` proposal is refused here whether it is five
        # minutes old or five days old, so the answer an operator gets does
        # not depend on when they happen to click. Were the freshness gate
        # to run first, a stale one would fold to `expired` and be told to
        # "ask the LEAD again and confirm the fresh proposal it offers" —
        # advice that is now false for this verb, since it can no longer be
        # offered at all. A refusal that sends the Captain somewhere that
        # does not exist is worse than no refusal message.
        #
        # This is the ordered fallback remedy. The preferred one — re-run
        # the originating condition check at confirm time, as the Hub's Run
        # button does (BUG-MSO-2026-0662 F1) — covers only ONE of the two
        # ways a proposal is born here: a proactive proposal carries its
        # finding's fingerprint and the check id is recoverable by looking
        # that up, but an LLM responder proposal has no finding and no check
        # to look up. See `run_verbs.CHAT_PROPOSAL_EXCLUDED_VERB_IDS` for
        # the full reasoning and the per-verb audit of the closed list.
        #
        # It also covers the threads that already exist. A proposal offered
        # BEFORE this fix is sitting on disk right now in the `offered`
        # state; an offer-time filter alone would never have seen it. This
        # gate is the one that makes it unconfirmable.
        #
        # Consulted by ID, before `parse_verb_id` — an excluded verb must be
        # refused without ever being turned into something runnable.
        # Fails CLOSED on an unexpected raise, like every other gate here.
        try:
            chat_excluded = run_verbs.is_chat_proposal_excluded(verb_id)
        except Exception:  # noqa: BLE001 — see above
            _log.debug("captain-chat: exclusion check raised", exc_info=True)
            chat_excluded = True
        if chat_excluded:
            return _resolve_confirm(
                root, target, position, verb_id, confirmed_by, workspace_root,
                outcome="refused", ok=False,
                message=_excluded_refusal_message(verb_id),
            )

        # FRESHNESS (SEC-MSO-2026-0888) — before re-validation, because a
        # stale proposal should not be executed even if it is still a
        # perfectly valid, perfectly permitted verb, and that is the whole
        # point: the other two gates would both pass it. Inside the claim
        # lock, so the expiry is written under the same serialisation as a
        # confirmation and the two can never interleave.
        # Fails CLOSED on an unexpected raise, for the same reason the two
        # checks below do, and in the same shape: a freshness check that
        # could not be evaluated has not established that this offer is
        # still current, and not knowing is not permission.
        ttl_minutes = resolve_proposal_ttl_minutes(root)
        try:
            stale = proposal_is_stale(target, ttl_minutes=ttl_minutes)
        except Exception:  # noqa: BLE001 — see above
            _log.debug("captain-chat: freshness check raised", exc_info=True)
            stale = True
        if stale:
            # Folded to `expired`, not left `offered`: expiry is terminal in
            # the same one-way sense as `refused`. Raising the TTL afterwards
            # must not resurrect an offer the fleet has already moved past —
            # the recovery is a fresh proposal, which is cheap, and never a
            # config edit that silently re-arms an old one.
            return _resolve_confirm(
                root, target, position, verb_id, confirmed_by, workspace_root,
                outcome="refused", ok=False,
                state_override="expired",
                message=_expiry_refusal_message(
                    verb_id,
                    # Best-effort: the refusal stands whether or not the age
                    # can be rendered, so this may never be the thing that
                    # turns a refusal into a stack trace.
                    _age_for_message(target),
                    ttl_minutes,
                ),
            )

        # Both checks below fail CLOSED on an unexpected raise. Neither can
        # raise today (`parse_verb_id` guards every branch, and
        # `bands.is_forbidden_by_must_not` already fails closed on a
        # corrupted role file), but "the ceiling could not be evaluated" must
        # never reach the caller as a stack trace that some future wrapper
        # retries past. An inability to verify a safety mechanism is not
        # permission.
        try:
            match = run_verbs.parse_verb_id(verb_id, proposal.args)
        except Exception:  # noqa: BLE001 — see above
            _log.debug("captain-chat: verb re-validation raised", exc_info=True)
            match = None
        if match is None:
            return _resolve_confirm(
                root, target, position, verb_id, confirmed_by, workspace_root,
                outcome="refused", ok=False,
                message=(
                    f"'{verb_id}' is not a runnable action with these arguments "
                    "— it is not on the closed verb list, or its arguments do "
                    "not match the shape that list accepts. Nothing ran."
                ),
            )

        # The D6 must_not ceiling — UNCONDITIONALLY, and before anything is
        # claimed. `run_verbs.is_forbidden` delegates to the exact function
        # the autonomous LEAD's execute_action() calls, so a verb mapped to a
        # LEAD.md must_not item is refused identically for a Captain
        # confirming in chat, a human clicking Run, and the daemon acting on
        # its own. Three surfaces, one ceiling, one implementation.
        ceiling_failed = False
        try:
            forbidden = run_verbs.is_forbidden(match.spec, product_repo)
        except Exception:  # noqa: BLE001 — see above
            _log.debug("captain-chat: must_not ceiling raised", exc_info=True)
            forbidden = True
            ceiling_failed = True

        if forbidden:
            if ceiling_failed:
                refusal = (
                    f"the LEAD's must_not ceiling could not be evaluated for "
                    f"'{verb_id}' — refusing rather than proceeding without it. "
                    "Nothing ran."
                )
            else:
                refusal = (
                    f"'{verb_id}' is on the LEAD's must_not list — it cannot be "
                    "run from the chat, by anyone, however it was asked for. "
                    "Nothing ran."
                )
            return _resolve_confirm(
                root, target, position, verb_id, confirmed_by, workspace_root,
                outcome="refused", ok=False, message=refusal,
            )

        # Claim it. From here the handler runs exactly once.
        append_update(root, message_id, proposal_states={position: "confirmed"},
                      actor=confirmed_by, reason="captain confirmed")

    # --- execute (unserialised — a handler can be slow) ---------------------
    handler_args = dict(match.args)
    try:
        result = match.spec.handler(handler_args, root, product_repo)
        outcome = "accepted" if result.ok else "failed"
        detail = result.message
    except Exception as exc:  # noqa: BLE001 — report, never crash the caller
        outcome, detail = "failed", f"{type(exc).__name__}: {exc}"

    return _resolve_confirm(
        root, target, position, verb_id, confirmed_by, workspace_root,
        outcome=outcome, ok=(outcome == "accepted"), message=detail,
        already_claimed=True,
    )


def _resolve_confirm(artefact_root: Path, target: ChatMessage, index: int,
                     verb_id: str, confirmed_by: str,
                     workspace_root: Optional[Path], *,
                     outcome: str, ok: bool, message: str,
                     already_claimed: bool = False,
                     state_override: Optional[str] = None) -> ConfirmOutcome:
    """Fold the proposal's final state, log, audit and post the result.

    The one exit for every confirm path, so a refusal, a failure and a
    success are recorded the same way and can never diverge in which of the
    four things they remember to do.

    *state_override* records a more specific proposal state than the outcome
    alone implies. It exists for exactly one caller — an EXPIRED proposal
    (SEC-MSO-2026-0888), whose ``outcome`` is ``refused`` because nothing
    ran, but whose state is ``expired`` because *why* nothing ran is the
    part an operator needs. The wire ``outcome`` vocabulary deliberately
    stays the Hub RunResult's three values, so no frontend has to learn a
    fourth; the state carries the detail. It is validated against
    :data:`PROPOSAL_STATES` — an override that is not a real state is
    ignored rather than written, because a bad state on disk would be read
    back by :func:`fold` forever.
    """
    root = Path(artefact_root)
    state = _CONFIRM_TERMINAL_OUTCOMES.get(outcome, "failed")
    if state_override and state_override in PROPOSAL_STATES:
        state = state_override

    # `confirmed` was already written by the claim; re-writing it would add a
    # no-op update line to an append-only log for no reason.
    if not (already_claimed and state == "confirmed"):
        try:
            append_update(root, target.id, proposal_states={index: state},
                          actor=confirmed_by, reason=f"confirm -> {outcome}")
        except Exception:  # pragma: no cover - defensive
            _log.debug("captain-chat: proposal state fold failed", exc_info=True)

    # Same event, same vocabulary and the same audit action shape the Run
    # button uses — `trigger=` is what distinguishes them, so an operator
    # greps ONE stream for "what did the LEAD's verbs do".
    try:
        _write_lifecycle_line(
            root,
            f"action={verb_id} trigger=captain-chat outcome={outcome} "
            f"who={confirmed_by} chatMessage={target.id} proposal={index} "
            f"detail={message}",
            event="LEAD_ACTION",
        )
    except Exception:  # pragma: no cover - defensive
        _log.debug("captain-chat: LEAD_ACTION write failed", exc_info=True)

    try:
        from maestro.audit import get_audit_log

        get_audit_log(Path(workspace_root) if workspace_root else root.parent).append(
            action=f"lead.chat.run.{verb_id}",
            target=target.id,
            result=outcome,
            metadata={"proposal": index, "verbId": verb_id, "detail": message},
            actor=confirmed_by,
        )
    except Exception:  # pragma: no cover - defensive
        _log.debug("captain-chat: audit write failed", exc_info=True)

    result_id = ""
    try:
        posted = post_system_message(
            root,
            f"{verb_id}: {outcome} — {message}",
            kind="proposal-result",
            in_reply_to=target.id,
            subject=target.subject if not target.subject.is_empty else None,
        )
        result_id = posted.id
    except Exception:  # pragma: no cover - defensive
        _log.debug("captain-chat: result message not posted", exc_info=True)

    return ConfirmOutcome(
        ok=ok, outcome=outcome, verb_id=verb_id, message=message,
        proposal_state=state, message_id=target.id, index=index,
        result_message_id=result_id,
    )
