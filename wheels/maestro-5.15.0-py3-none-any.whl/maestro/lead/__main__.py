# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Entry point for the detached LEAD daemon process:

    python -m maestro.lead --artefact-root PATH

Spawned by :func:`maestro.lead.daemon.start`. Loops forever: run one wake
cycle (:func:`maestro.lead.agent.run_once`), sleep for the configured
heartbeat interval, repeat. There is no in-loop stop check by design — like
`maestro/hub/__main__.py`, termination is external (SIGTERM / taskkill from
:func:`maestro.lead.daemon.stop`), not a polled flag.

The per-tick termination contract (DONE / REPORTED_BACK — Captain ruling D8)
governs a single wake cycle, not this outer loop: the daemon process itself
is meant to run indefinitely (that is its entire purpose per §3.1 — durable
across dispatcher restarts and closed sessions), but every wake cycle it
runs is bounded and reports a terminal state rather than free-running.

Captain Chat (FTR-MSO-2026-0846, PLAN-PLN-MSO-2026-0828 §1.2)
-------------------------------------------------------------
The heartbeat sleep is SLICED into ``lead.chat.pollSeconds`` pieces, and the
chat inbox is checked between slices. The patrol cadence is unchanged — the
slices still add up to exactly ``heartbeatSeconds`` — but a Captain no longer
waits up to five minutes for the daemon to notice their message.

Two properties this deliberately keeps:

* **The poll is cheap and never blocks.** It reads one file and, when there
  is a message to answer, hands it to a worker THREAD
  (``chat_responder.ResponderRunner``). A three-minute reply therefore
  cannot delay the next patrol tick (plan Risk R6).
* **A caller with no ``chat`` block behaves exactly as before.** Chat
  polling is driven by the resolved ``chat`` config; a hand-built config
  dict that carries none (as ``load_lead_config`` never produces, but a
  direct caller may) falls back to the single unsliced ``time.sleep`` this
  loop did before this order — the same "reproduce the EXACT prior call
  shape" discipline the optional ``--workspace`` argument already follows.
"""

from __future__ import annotations

import argparse
import time
from pathlib import Path
from typing import Optional

from maestro.lead.agent import DEFAULT_HEARTBEAT_SECONDS, load_lead_config, run_once


def main() -> None:
    ap = argparse.ArgumentParser(description="Maestro LEAD resident daemon")
    ap.add_argument("--artefact-root", required=True, help="Path to the workspace's .mso/ dir")
    # FTR-MSO-2026-0585 (RC-2): the product-repo root, threaded from
    # maestro.lead.daemon.start()'s own workspace_root argument. Optional —
    # a daemon started without it (or spawned by an older caller) keeps
    # running exactly as before; run_once() simply gets workspace=None,
    # which is today's behaviour.
    ap.add_argument("--workspace", default=None, help="Product-repo root (RC-2 root-pinning)")
    args = ap.parse_args()

    artefact_root = Path(args.artefact_root)
    workspace = Path(args.workspace) if args.workspace else None
    responder = _make_responder(artefact_root, workspace)

    while True:
        config = load_lead_config(artefact_root)
        # Passed conditionally, not as workspace=workspace unconditionally,
        # so a caller with no workspace reproduces the EXACT prior call
        # signature — not merely the same runtime behaviour.
        kwargs = {"config": config}
        if workspace is not None:
            kwargs["workspace"] = workspace
        run_once(artefact_root, **kwargs)
        sleep_between_ticks(config, responder)


def _make_responder(artefact_root: Path, workspace: Optional[Path]):
    """The chat inbox poller, or ``None`` if it cannot be constructed.

    Best-effort on purpose: an import or construction failure here must
    leave a daemon that still runs its patrol, not one that will not start.
    """
    try:
        from maestro.lead.chat_responder import ResponderRunner

        return ResponderRunner(artefact_root, workspace=workspace)
    except Exception:  # noqa: BLE001
        return None


def sleep_between_ticks(config: dict, responder=None) -> None:
    """Sleep one heartbeat, checking the chat inbox every ``pollSeconds``.

    The slices sum to exactly ``heartbeatSeconds``, so the patrol cadence is
    byte-for-byte what it was before Captain Chat existed. Two cases collapse
    back to the single unsliced sleep this loop used to do:

    * no responder (construction failed), or
    * a config with no resolved ``chat`` block — the shape a direct caller
      hand-builds; ``load_lead_config`` always supplies one.

    A poll that raises can never shorten or skip the sleep. ``poll()`` is
    itself total (it catches and reports), and :func:`_poll_quietly` below
    catches anything that gets past it anyway — without that second guard a
    raising poller would skip the remaining ``time.sleep`` calls entirely
    and turn this loop into a hot spin, which is a far worse failure than a
    missed chat message. The remaining slices are counted, not timed, so
    they are unaffected either way.
    """
    # Defaulting to the shipped heartbeat, not to 1: a config missing the
    # key used to raise KeyError here, and swapping that for a one-second
    # sleep would turn a malformed config into a daemon that spins.
    heartbeat = max(1, int(config.get("heartbeatSeconds") or DEFAULT_HEARTBEAT_SECONDS))
    chat_cfg = config.get("chat") if isinstance(config, dict) else None

    if responder is None or not isinstance(chat_cfg, dict):
        time.sleep(heartbeat)
        return

    slice_seconds = max(1, int(chat_cfg.get("pollSeconds") or 1))
    if slice_seconds >= heartbeat:
        # A poll interval at or above the heartbeat means the tick boundary
        # IS the poll — one sleep, one check, no behaviour change.
        _poll_quietly(responder, config)
        time.sleep(heartbeat)
        return

    remaining = heartbeat
    while remaining > 0:
        _poll_quietly(responder, config)
        nap = min(slice_seconds, remaining)
        time.sleep(nap)
        remaining -= nap


def _poll_quietly(responder, config: dict) -> None:
    """Poll the chat inbox, swallowing anything it raises.

    Belt and braces over ``ResponderRunner.poll``'s own catch: the sleep
    loop's correctness must not depend on the poller's internals staying
    total, because the cost of being wrong about that is a hot spin in the
    daemon's main loop rather than a missed message.
    """
    try:
        responder.poll(config)
    except Exception:  # noqa: BLE001 — see docstring
        pass


if __name__ == "__main__":
    main()
