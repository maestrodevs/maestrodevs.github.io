# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""maestro/lead/events.py — the lifecycle-event catalogue + LLM-invocation gate.

PLAN-PLN-MSO-2026-0504 §12: cadence is one cheap continuous heartbeat plus
event-triggered duties keyed off LIFECYCLE events — not Claude Code tool
hooks (§3, B3 was rejected specifically because a hook "cannot see absence":
a fleet stalled while nothing happens generates no tool events, but
``.mso/logs/lifecycle.log`` is on disk regardless, so a resident process can
see it). §12's tables enumerate, per trigger, a debounce/provider/severity/
band — this module supplies the TRIGGER side: which already-real
``lifecycle.log`` event types are "catalogued" (worth invoking the LLM over
even when the patrol's own delta is empty).

§6's revision-1 addition is the noise-budget rule this module implements
for the resident agent specifically (the CLI's own delta/age-escalation
noise control, FTR-MSO-2026-0533, already exists and is unaffected):

    "[the LEAD] only invokes the LLM when the delta is non-empty. A
    heartbeat tick that produces no NEW/RESOLVED/ESCALATED finding runs
    `mso doctor` (cheap, deterministic, no tokens) and stops."

Order 7 generalises "delta non-empty" to "delta non-empty OR a catalogued
event fired" — some duties are genuinely event-triggered rather than
delta-driven (e.g. `NAV_REVIEW_PENDING` may need an escalation even when the
patrol's own finding set is byte-identical to the previous tick).
:func:`should_invoke_llm` is the single gate a later order's actual
LLM-invoking task type must consult before spending a token; it is a pure
function precisely so "10 quiet ticks, zero completions" is testable
without any completion-invoking machinery existing yet.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Sequence

from maestro.hub.lifecycle_tail import (
    LifecycleTail,
    _parse_event_type,
    _parse_message,
    _parse_timestamp,
)

__all__ = [
    "CATALOGUED_EVENT_TYPES",
    "CHAT_TRIGGER_EVENT_TYPES",
    "LifecycleEvent",
    "LeadEventTailer",
    "should_invoke_llm",
]

# PLAN §12's tables, mapped onto the REAL lifecycle.log event-type
# vocabulary (top-level CLAUDE.md "Lifecycle event vocabulary") rather than
# re-deriving it from the plan's section headings — each of these is a
# genuine `event_type` string a lifecycle.log line carries today. This is
# DATA, not hardcoded control flow inside the tailer, so a later order can
# extend the catalogue by editing this set alone.
CATALOGUED_EVENT_TYPES = frozenset({
    "ADVANCE",               # §12.2 — role completion
    "COMPLETE",               # §12.3 — voyage finalisation
    "NAV_REVIEW_PENDING",     # §12.7 — the Captain's original complaint, literally
    "NAV_REVIEW_APPROVED",    # §12.8 — plan approved
    "AUTOQUEUE",              # §12.9 — dependency satisfied, dependents released
    "REQUEUE",                # §12.6 — crew death/timeout
    "SALVAGE",                # §12.6 — crew death/timeout, work preserved
    "MAX_TURNS",              # §12.6 — crew death/timeout
    "PLAN_ORPHANED",          # a plan approved with nothing released — judgement-worthy
    "SEC_ARTEFACT_MISSING",   # §12.2 generalised — a required artefact is missing
    "VERIFY_FAILED",          # local verify gate failed — needs the LEAD's read
    "IDLE_REAP",              # the dispatcher self-exited — LEAD now watches alone
    "LICENCE_WARNING",        # §12.10-adjacent — keyring/tier state worth a look
})


# PLAN-PLN-MSO-2026-0828 §0 Q1a (FTR-MSO-2026-0844): the event types that
# alone justify pushing a TEMPLATED, ZERO-TOKEN question into the Captain
# Chat thread. DATA, not control flow — this module neither filters on it nor
# knows what a chat question is; `maestro.lead.chat_proactive` is the only
# reader, exactly as CATALOGUED_EVENT_TYPES is data for `should_invoke_llm`'s
# callers.
#
# It is deliberately a DIFFERENT, much SMALLER set than
# CATALOGUED_EVENT_TYPES above, and neither is derived from the other. That
# set answers "is this worth the LEAD spending a token thinking about?";
# this one answers the far stricter "does this need a HUMAN, personally?".
# ADVANCE, COMPLETE and AUTOQUEUE are catalogued and deliberately absent
# here: they are the fleet working correctly, and a question per role
# advance would make the thread unreadable within one voyage — which is the
# failure mode that ends with an operator ignoring the channel entirely.
#
# `STALLED` is NOT in this set even though a stall can need a human, because
# only ONE of its causes does in a way a template can state usefully:
# `stalledCause=BLOCKED_BY_ROLE` (BUG-MSO-2026-0705). That condition is on
# the line's MESSAGE, not its type, so it is matched separately by the
# reader rather than smuggled in here as a type — a set of event types must
# stay a set of event types.
CHAT_TRIGGER_EVENT_TYPES = frozenset({
    "NAV_REVIEW_PENDING",     # a plan is waiting on the Captain, by definition
    "PLAN_ORPHANED",          # approved, released nothing — needs orders filed
    "SEC_ARTEFACT_MISSING",   # requeued at SEC; a second miss STALLS the order
    "VERIFY_FAILED",          # the gate RAN and the code lost — held, not pushed
    "LAP_EXHAUSTED",          # the ceiling is spent; the fleet will not retry
})


@dataclass(frozen=True)
class LifecycleEvent:
    timestamp: str
    event_type: str
    message: str
    raw: str


def _parse_line(line: str) -> Optional[LifecycleEvent]:
    event_type = _parse_event_type(line)
    if not event_type:
        return None
    return LifecycleEvent(
        timestamp=_parse_timestamp(line),
        event_type=event_type,
        message=_parse_message(line),
        raw=line,
    )


class LeadEventTailer:
    """Tails a workspace's ``lifecycle.log`` for §12's catalogued event
    types, reusing ``hub.lifecycle_tail.LifecycleTail`` per the order's own
    instruction ("reusing hub/lifecycle_tail.py if its API permits") —
    it is the SAME class the Hub's WebSocket stream already tails this file
    with, so this is a second reader of one implementation, not a second
    implementation (Notes for Builder #2).

    One adaptation was needed. ``LifecycleTail.__init__`` takes a
    PRODUCT-repo *workspace* path and lazily resolves the log path via
    ``resolve_artefact_dir(workspace)``, which joins the workspace root to the
    artefact directory name — built for the Hub's caller, which only ever
    holds a workspace root. The LEAD daemon instead already HOLDS the fully resolved artefact
    root directly (solo/shared-mode aware, via
    ``maestro.core.fleet_runner.get_artefact_root()`` at the CLI layer), so
    re-deriving it through a resolution path built for a different caller
    would be a second, narrower resolver — this class pins the tailer's
    private ``_log_path`` directly after construction instead. Every public
    method below (``read_new_lines()``'s byte-offset tracking,
    ``seek_to_end()``) runs completely unmodified.
    """

    def __init__(self, artefact_root: Path) -> None:
        self._artefact_root = Path(artefact_root)
        self._tail = LifecycleTail(self._artefact_root)
        self._tail._log_path = self._artefact_root / "logs" / "lifecycle.log"

    def seek_to_end(self) -> None:
        """Skip everything already on disk — call once at daemon startup so
        the first tick only sees events that happen from here on."""
        self._tail.seek_to_end()

    @property
    def offset(self) -> int:
        """How far into ``lifecycle.log`` this tailer has read, in bytes.

        FTR-MSO-2026-0844. ``LifecycleTail`` tracks its position in memory
        only, which is right for the Hub's WebSocket stream (a tail lives
        exactly as long as one connection). A reader that must not re-ask
        the same question after a restart needs to persist that position,
        and the honest way to let it is to expose the number rather than
        have every such reader reach into ``_offset``. Reading and writing
        this is state plumbing, not control flow: nothing here decides what
        an event means.
        """
        return int(self._tail._offset)

    def seek_to(self, offset: int) -> None:
        """Resume from a previously persisted :attr:`offset`.

        A *offset* past the current end of file (the log was rotated or
        truncated under us) is NOT honoured — this seeks to the end instead,
        because the alternative readings are both worse: keeping the stale
        offset stops this reader permanently and silently, and resetting to
        zero replays a whole log's worth of events as though they had just
        happened. Skipping forward loses only events written between the
        rotation and this call, and says nothing false about the ones it
        does report.
        """
        try:
            # `_get_log()`, never the raw `_log_path` attribute: the tail
            # resolves its path LAZILY, so on a tailer that has not polled
            # yet `_log_path` is still None. Reading it directly measured
            # every fresh tailer's log as zero bytes, clamped every saved
            # offset to 0, and replayed the entire log — the precise
            # behaviour this method's docstring promises not to have. A
            # caller that persists its cursor builds a new tailer per poll,
            # so "has not polled yet" is the ONLY case that ever reaches
            # here.
            log = self._tail._get_log()
            size = log.stat().st_size if log.exists() else 0
        except OSError:
            size = 0
        target = int(offset)
        self._tail._offset = target if 0 <= target <= size else size

    def poll(self) -> "list[LifecycleEvent]":
        """Every parseable event appended since the last poll (or since
        construction if never polled), regardless of type."""
        events = []
        for line in self._tail.read_new_lines():
            evt = _parse_line(line)
            if evt is not None:
                events.append(evt)
        return events

    def poll_catalogued(self) -> "list[LifecycleEvent]":
        """The subset of :meth:`poll` matching :data:`CATALOGUED_EVENT_TYPES`
        — the ones that alone justify invoking the LLM even on an otherwise
        quiet heartbeat."""
        return [e for e in self.poll() if e.event_type in CATALOGUED_EVENT_TYPES]


def should_invoke_llm(delta_has_changes: bool, catalogued_events: Sequence[LifecycleEvent]) -> bool:
    """PLAN §6 revision-1 addition, generalised to include §12's event
    triggers: the LLM is invoked only on a non-empty patrol delta (typically
    ``maestro.patrol.state.PatrolDelta.has_changes``) OR at least one
    catalogued lifecycle event since the last tick.

    A pure boolean gate that does not itself call an LLM, run a patrol, or
    touch a lifecycle log — callers own all of that. That separation is
    what makes "10 quiet ticks, zero completions" testable today: the test
    drives this function directly across 10 simulated quiet ticks (no
    delta, no events) and asserts a "would invoke" counter never advances,
    with no actual completion-invoking machinery needing to exist yet.
    """
    return bool(delta_has_changes) or bool(catalogued_events)
