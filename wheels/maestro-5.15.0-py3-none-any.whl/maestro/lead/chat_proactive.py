# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""maestro/lead/chat_proactive.py — the LEAD's PROACTIVE voice in the Captain
Chat thread (PLAN-PLN-MSO-2026-0828 §0 Q1a, FTR-MSO-2026-0844).

**There is no LLM anywhere in this module, and there must never be one.**
Everything a proactive question needs is already in the daemon's hands the
moment it decides to ask: a patrol ``Finding`` carries its own title, detail,
severity, ``suggestedCommand`` and fingerprint; a lifecycle line carries its
own event type and, usually, its order id. Spending a model call to restate
data we already hold would cost money, add latency, add a failure mode, and
produce a WORSE message than a template — because a template cannot
hallucinate an order id. A question costs one disk append.

The test suite enforces this rather than trusting it: it patches
``find_claude_cli`` to raise and drives the whole path, findings and events
alike, start to finish.

What this module does
---------------------
* :func:`build_question` — PURE. A ``Finding`` or a :class:`ChatQuestion`
  source goes in, a :class:`QuestionDraft` (body, subject, proposals) comes
  out. No I/O at all, so every template decision is testable without a
  thread on disk.
* :func:`raise_finding_question` / :func:`raise_event_questions` — apply the
  draft to a real thread, with dedup.
* :func:`poll_trigger_events` — read new :data:`CHAT_TRIGGER_EVENT_TYPES`
  lines through ``LeadEventTailer``, from a DURABLE byte cursor.
* :func:`reconcile_questions` — supersede an open question whose finding has
  since been RESOLVED or acknowledged.

Dedup: one open question per subject
------------------------------------
The subject key is the finding's fingerprint, or ``<eventType>:<orderId>``
for an event. While a question on that key is still ``open``, a re-raise
appends an UPDATE line and does not post again — the same shape
``maestro.core.lead_banner.record_critical`` uses, and for the same reason:
a condition that stays true for six hours is one conversation, not 2,160 of
them at a 10-second tick.

The update line's own ``ts`` IS the "last seen at" (plan §0 Q1a). It is not a
new field on the message: ``chat.append_update``'s ``changes`` vocabulary is
deliberately narrow (a question's state, a proposal's state, ``decisionDraft``,
``llm``) precisely so an append-only thread cannot grow arbitrary mutable
state, and widening it to carry a timestamp that the record already has would
be storing the same fact twice.

Proposals
---------
When a finding's ``suggestedCommand`` parses via
``run_verbs.parse_verb`` — the CLOSED list behind the Hub's Run button — the
question carries exactly ONE pre-validated proposal, which is the same action
the LEAD drawer already offers for that finding. Nothing new becomes runnable
here: a command outside the list is still shown as text and is not clickable,
and a verb mapped to a ``LEAD.md`` ``must_not`` item
(``run_verbs.is_forbidden``, the D6 ceiling) is never offered at all. Adding a
verb stays its own SEC-reviewed order, as FTR-MSO-2026-0631 was.
"""

from __future__ import annotations

import json
import logging
import os
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple

from maestro.lead import chat
from maestro.lead.chat import Proposal, Subject
from maestro.lead.events import CHAT_TRIGGER_EVENT_TYPES, LeadEventTailer, LifecycleEvent

__all__ = [
    "CHAT_TRIGGER_EVENT_TYPES",
    "EVENT_CURSOR_FILENAME",
    "MAX_DETAIL_CHARS",
    "QuestionDraft",
    "QuestionOutcome",
    "SELF_REFERENTIAL_CHECK_IDS",
    "build_question",
    "event_subject",
    "is_trigger_event",
    "load_event_cursor",
    "poll_trigger_events",
    "raise_event_questions",
    "raise_finding_question",
    "reconcile_questions",
    "save_event_cursor",
    "subject_key",
]

_log = logging.getLogger(__name__)

#: Where the durable lifecycle-tail position lives — beside the chat's own
#: ``lead-cursor.json``, in ``state/``, for the reason plan §0 Q3 gives for
#: putting the thread there: control-plane state must be readable
#: off-process with no daemon and no Hub running.
EVENT_CURSOR_FILENAME = "event-cursor.json"

#: How much of a finding's ``detail`` a question body carries. Findings are
#: written for `mso doctor`'s terminal output and some (``hub.alive``) embed a
#: log tail, while ``chat.MAX_BODY_CHARS`` is 8,000 for the whole message.
#: Truncation is always MARKED — a body that silently stops mid-sentence
#: reads as a bug in the fleet rather than as a bounded quote.
MAX_DETAIL_CHARS = 3_000

#: The one check whose findings must NEVER become chat questions
#: (FTR-MSO-2026-0844). ``lead.chat-open-question`` reports questions that
#: have gone unanswered, and patrol findings ESCALATE by age — a `medium`
#: finding reaches `high` at 24h (``maestro.patrol.state``). So without this
#: guard an unanswered question becomes a high finding, a high finding posts
#: a chat question, and that question goes unanswered in its turn: one
#: ignored question multiplies instead of just sitting there, and at
#: `critical` (day 7) it would start paging Slack about itself.
#:
#: Excluded HERE, at the single policy gate, rather than by capping that
#: check's severity — the finding SHOULD keep getting louder in `mso doctor`,
#: which is the surface it exists for. What must not happen is the chat
#: channel answering its own output.
SELF_REFERENTIAL_CHECK_IDS = frozenset({"lead.chat-open-question"})

#: ``STALLED`` is in neither event set: only one of its causes needs a human
#: in a way a template can state usefully (BUG-MSO-2026-0705). Matched on the
#: line's MESSAGE, never smuggled into CHAT_TRIGGER_EVENT_TYPES as a type.
_STALLED_EVENT_TYPE = "STALLED"
_STALLED_TRIGGER_CAUSE = "stalledCause=BLOCKED_BY_ROLE"

#: One line of "why you are being told this" per trigger, written from the
#: lifecycle vocabulary in the top-level CLAUDE.md rather than invented. The
#: event's own message follows it verbatim; this never replaces that text.
_EVENT_GUIDANCE: Dict[str, str] = {
    "NAV_REVIEW_PENDING": (
        "A plan is paused at the human review gate. Nothing on this order "
        "advances until you approve, revise or reject it "
        "(`mso review approve|revise|reject`, or the Hub's In Review actions)."
    ),
    "PLAN_ORPHANED": (
        "A plan-approval order was approved but had no PROPOSED dependents to "
        "release, and none were already filed — so approving it unblocked "
        "nothing. Build orders for the plan's voyage probably still need filing."
    ),
    "SEC_ARTEFACT_MISSING": (
        "An order whose roleSequence includes SEC reached completion with no "
        "SEC artefact on disk. It has been held and requeued at SEC; the "
        "SECOND miss escalates it to STALLED rather than cycling."
    ),
    "VERIFY_FAILED": (
        "The local verify gate RAN and exited non-zero — the code failed; this "
        "is not a missing tool (that is VERIFY_DEPS_FAILED). The order is held, "
        "nothing was pushed, and the work is preserved on a salvage branch. The "
        "event line names a full log path; read that, not the excerpt."
    ),
    "LAP_EXHAUSTED": (
        "An order's lap ceiling is spent. The fleet will NOT try again on its "
        "own — the edge's onExhausted applies, so this is now a human's."
    ),
    _STALLED_EVENT_TYPE: (
        "A reviewing role REJECTED this order and its auto-lap is already "
        "spent, so it is archived STALLED. The work may well be on the voyage "
        "branch and rejected at the same time — read the QA report's blocking "
        "defects before deciding."
    ),
}


# ---------------------------------------------------------------------------
# Drafts — the pure half.
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class QuestionDraft:
    """A question ready to post, and the key it deduplicates on.

    Deliberately separate from the act of posting: every template decision
    above is then testable with no thread on disk, and one code path builds
    the body whether the source is a finding or a lifecycle line.
    """

    key: str
    subject: Subject
    body: str
    proposals: List[Proposal] = field(default_factory=list)
    severity: str = ""
    source: str = "finding"


@dataclass(frozen=True)
class QuestionOutcome:
    """What :func:`raise_finding_question` actually did.

    ``posted`` and ``refreshed`` are distinct on purpose: a caller that
    cannot tell "I asked" from "I noticed again" cannot report honestly, and
    the whole point of the dedup is that the second is the common case.
    """

    message_id: Optional[str] = None
    posted: bool = False
    refreshed: bool = False
    skipped_reason: str = ""

    @property
    def delivered(self) -> bool:
        """Whether an open question exists for this subject as a result —
        true for a fresh post AND for a refresh of one already open."""
        return bool(self.message_id)


def subject_key(subject: Subject) -> str:
    """The dedup identity of a question's subject.

    A fingerprint is already a stable ``(check_id, subject_id, base_severity)``
    hash, so it is used alone when present. An event has no fingerprint, so
    its key is ``<eventType>:<orderId>`` — the pair the plan names. An event
    with no order id keys on its type alone, which is the honest reading:
    two ``PLAN_ORPHANED`` lines naming no order are, as far as anything here
    can tell, the same condition still true.
    """
    if subject.fingerprint:
        return f"fp:{subject.fingerprint}"
    return f"evt:{subject.event_type or '-'}:{subject.order_id or '-'}"


def event_subject(event: LifecycleEvent) -> Subject:
    """The :class:`Subject` for a lifecycle event — its type plus the order
    id parsed out of the line, when it carries one."""
    from maestro.hub.lifecycle_tail import _parse_order_id

    try:
        order_id = _parse_order_id(event.raw or event.message or "")
    except Exception:  # noqa: BLE001 — a parse must never break a question
        order_id = None
    return Subject(event_type=event.event_type, order_id=order_id)


def is_trigger_event(event: LifecycleEvent) -> bool:
    """Whether *event* is one this module asks the Captain about.

    Two rules, not one: membership of :data:`CHAT_TRIGGER_EVENT_TYPES`, plus
    the single message-level condition ``STALLED`` +
    ``stalledCause=BLOCKED_BY_ROLE``. The second is matched HERE rather than
    by widening the type set, because a set of event types that silently
    means "…and also this one substring" is a set nobody can read correctly.
    """
    if event.event_type in CHAT_TRIGGER_EVENT_TYPES:
        return True
    return (
        event.event_type == _STALLED_EVENT_TYPE
        and _STALLED_TRIGGER_CAUSE in (event.raw or event.message or "")
    )


def _clip(text: str, limit: int = MAX_DETAIL_CHARS) -> str:
    """Bound *text*, saying so when it bounds. Never a silent cut."""
    text = (text or "").strip()
    if len(text) <= limit:
        return text
    kept = text[:limit].rstrip()
    dropped = len(text) - len(kept)
    return f"{kept}\n… ({dropped} more characters — see `mso doctor` for the full detail)"


#: Returned by :func:`_proposals_for` alongside an empty list, to say WHICH
#: kind of "no button" this is. The body sentence differs, because the two
#: call for different things from the Captain: a verb that is simply not on
#: the closed list is one they should run themselves, and an excluded one is
#: one they should run from the Hub's Run button, which re-checks first.
NOT_RUNNABLE = "not-runnable"
CHAT_EXCLUDED = "chat-excluded"


def _proposals_for(command: Optional[str],
                   artefact_root: Optional[Path]) -> Tuple[List[Proposal], Optional[str]]:
    """At most ONE pre-validated proposal for *command*, and why not if none.

    Returns ``(proposals, reason)``. *reason* is ``None`` when a proposal was
    built, and otherwise one of :data:`NOT_RUNNABLE` / :data:`CHAT_EXCLUDED`
    so the caller can say the accurate thing in the question body.

    Four ways to get nothing, all of them deliberate:

    * the command is absent, or is not on ``run_verbs``' closed list — it is
      still shown as text in the body, it is simply not clickable;
    * the verb is mapped to a ``LEAD.md`` ``must_not`` item — the D6 ceiling,
      checked with the SAME ``is_forbidden`` the autonomous daemon and the
      Hub's Run button call, so a refusal is identical across all three;
    * the verb is excluded from the chat surface by blast radius
      (SEC-MSO-2026-0888) — see
      ``run_verbs.CHAT_PROPOSAL_EXCLUDED_VERB_IDS``. This is an
      OFFER-TIME courtesy, not the control: ``chat.confirm_proposal``
      refuses the same verb again at confirm time, which is what covers the
      proposals already sitting in threads written before that fix;
    * anything at all raises — a question that reaches the Captain without a
      button beats no question.
    """
    if not command:
        return [], None
    try:
        from maestro.lead import run_verbs

        match = run_verbs.parse_verb(command)
        if match is None:
            return [], NOT_RUNNABLE
        if run_verbs.is_chat_proposal_excluded(match.spec.id):
            return [], CHAT_EXCLUDED
        if run_verbs.is_forbidden(match.spec, artefact_root):
            return [], NOT_RUNNABLE
        return [
            Proposal(
                verb_id=match.spec.id,
                args=dict(match.args),
                why=f"The suggested remedy for this finding: `{command.strip()}`",
                state="offered",
            )
        ], None
    except Exception:  # noqa: BLE001
        _log.debug("captain-chat: proposal build failed for %r", command, exc_info=True)
        return [], NOT_RUNNABLE


def build_question(source: Any, *, fingerprint: Optional[str] = None,
                   artefact_root: Optional[Path] = None) -> Optional[QuestionDraft]:
    """Format a patrol ``Finding`` or a :class:`LifecycleEvent` into a draft.

    PURE: no thread is read, nothing is written, no severity policy is
    applied (callers own the ``proactiveMinSeverity`` floor — see
    :func:`raise_finding_question`). Returns ``None`` only for an event this
    module does not ask about; a ``Finding`` always produces a draft, because
    by the time one reaches here the caller has already decided it matters.
    """
    if isinstance(source, LifecycleEvent):
        return _build_event_question(source)
    return _build_finding_question(source, fingerprint=fingerprint,
                                   artefact_root=artefact_root)


def _build_finding_question(finding: Any, *, fingerprint: Optional[str],
                            artefact_root: Optional[Path]) -> QuestionDraft:
    severity = str(getattr(finding, "severity", "") or "")
    check_id = str(getattr(finding, "check_id", "") or "")
    title = str(getattr(finding, "title", "") or "").strip() or check_id or "LEAD finding"
    detail = _clip(str(getattr(finding, "detail", "") or ""))
    command = getattr(finding, "suggestedCommand", None)
    fp = fingerprint or ""

    subject = Subject(fingerprint=fp or None)
    proposals, no_proposal_reason = _proposals_for(command, artefact_root)

    lines = [f"**{title}**", ""]
    if detail:
        lines += [detail, ""]
    meta = f"Severity **{severity or 'unknown'}**"
    if check_id:
        meta += f" · check `{check_id}`"
    lines.append(meta)
    if command:
        if proposals:
            lines.append(f"Suggested: `{command}` — offered as a proposal below.")
        elif no_proposal_reason == CHAT_EXCLUDED:
            # SEC-MSO-2026-0888: say the true reason. "Not on the closed
            # list" would be a lie about this verb — it is on the list and
            # is runnable, just not from here — and it would send the
            # Captain to the wrong place.
            lines.append(
                f"Suggested: `{command}` — shown as text only. This one changes "
                f"live fleet state, so it is never offered as a chat button: "
                f"run it from the Hub's LEAD drawer, where the finding's own "
                f"check is re-confirmed immediately before it fires."
            )
        else:
            lines.append(
                f"Suggested: `{command}` — shown as text only; it is not on the "
                f"closed list of one-click verbs, so run it yourself."
            )
    lines += [
        "",
        "Reply in this thread if you want the LEAD's read on it. This question "
        "closes by itself when the finding resolves or you acknowledge it.",
    ]

    return QuestionDraft(
        key=subject_key(subject),
        subject=subject,
        body="\n".join(lines).strip(),
        proposals=proposals,
        severity=severity,
        source="finding",
    )


def _build_event_question(event: LifecycleEvent) -> Optional[QuestionDraft]:
    if not is_trigger_event(event):
        return None
    subject = event_subject(event)
    guidance = _EVENT_GUIDANCE.get(event.event_type, "")
    headline = event.event_type
    if subject.order_id:
        headline += f" — {subject.order_id}"

    lines = [f"**{headline}**", ""]
    if guidance:
        lines += [guidance, ""]
    message = _clip(event.message or event.raw or "")
    if message:
        lines += ["The lifecycle line, verbatim:", "", f"> {message}", ""]
    if event.timestamp:
        lines.append(f"Logged at {event.timestamp}.")
    lines.append(
        "Reply in this thread if you want the LEAD's read on it. Nothing has "
        "been run or changed on your behalf."
    )

    return QuestionDraft(
        key=subject_key(subject),
        subject=subject,
        # An event is not a patrol finding and has no severity of its own;
        # saying "high" here would invent a rating nothing computed.
        severity="",
        body="\n".join(lines).strip(),
        proposals=[],
        source="event",
    )


# ---------------------------------------------------------------------------
# Posting — the half that touches the thread.
# ---------------------------------------------------------------------------

def _open_questions_by_key(artefact_root: Path) -> Dict[str, chat.ChatMessage]:
    """Every currently-open question, keyed by :func:`subject_key`.

    The NEWEST wins on a duplicate key. That can only happen if two
    processes raced past the read below before either appended, and in that
    case the operator sees two questions and one of them stops being
    refreshed — an honest, self-limiting outcome. Taking a lock across the
    read-decide-append would serialise every tick of every workspace behind
    one file for a duplicate that costs a single extra message.
    """
    by_key: Dict[str, chat.ChatMessage] = {}
    for message in chat.open_questions(artefact_root):
        by_key[subject_key(message.subject)] = message
    return by_key


def _raise_draft(artefact_root: Path, draft: QuestionDraft, *,
                 open_by_key: Optional[Dict[str, chat.ChatMessage]] = None,
                 ) -> QuestionOutcome:
    """Post *draft*, or refresh the open question already on its key."""
    root = Path(artefact_root)
    if open_by_key is None:
        open_by_key = _open_questions_by_key(root)

    existing = open_by_key.get(draft.key)
    if existing is not None:
        try:
            chat.append_update(
                root,
                existing.id,
                # A no-op state re-affirmation: the point of the line is its
                # own `ts` (the "last seen at" of plan §0 Q1a) and its
                # `reason`, not a state transition — the question was open
                # before and is open still.
                question_state="open",
                reason="re-raised by the patrol — still open",
            )
            return QuestionOutcome(message_id=existing.id, refreshed=True)
        except Exception:  # noqa: BLE001
            _log.debug("captain-chat: re-raise update failed", exc_info=True)
            # The question IS still open and the Captain can still see it;
            # only the freshness marker was lost.
            return QuestionOutcome(message_id=existing.id, refreshed=False,
                                   skipped_reason="update-failed")

    message = chat.post_lead_message(
        root,
        draft.body,
        kind="question",
        subject=draft.subject,
        proposals=draft.proposals or None,
        question_state="open",
    )
    open_by_key[draft.key] = message
    return QuestionOutcome(message_id=message.id, posted=True)


def _min_severity(artefact_root: Path) -> str:
    """``lead.chat.proactiveMinSeverity``, via the ONE config reader."""
    try:
        from maestro.lead.agent import load_lead_config

        return str(load_lead_config(Path(artefact_root))["chat"]["proactiveMinSeverity"])
    except Exception:  # noqa: BLE001
        from maestro.lead.agent import DEFAULT_CHAT_PROACTIVE_MIN_SEVERITY

        return DEFAULT_CHAT_PROACTIVE_MIN_SEVERITY


def raise_finding_question(artefact_root: Path, fingerprint: str, finding: Any,
                           *, min_severity: Optional[str] = None,
                           open_by_key: Optional[Dict[str, chat.ChatMessage]] = None,
                           ) -> QuestionOutcome:
    """Ask the Captain about one NEW/ESCALATED patrol finding.

    The severity floor (``lead.chat.proactiveMinSeverity``, default ``high``)
    is applied HERE rather than at each call site, so the ``critical`` channel
    and the ``high`` branch of ``_deliver_findings`` cannot drift into two
    different policies. A finding below the floor is skipped with a reason,
    never silently.

    Never raises. A chat failure must not fail a patrol tick — the finding
    still reaches the lifecycle log, the banner, Slack and the Hub, all of
    which pre-date this channel.
    """
    try:
        root = Path(artefact_root)
        from maestro.patrol.registry import severity_rank

        check_id = str(getattr(finding, "check_id", "") or "")
        if check_id in SELF_REFERENTIAL_CHECK_IDS:
            # See SELF_REFERENTIAL_CHECK_IDS: asking about an unanswered
            # question, in the thread that already holds it, is the one
            # question this channel can never usefully ask.
            return QuestionOutcome(skipped_reason=f"self-referential:{check_id}")

        floor = (min_severity or _min_severity(root)).lower()
        severity = str(getattr(finding, "severity", "") or "").lower()
        if severity_rank(severity) < severity_rank(floor):
            return QuestionOutcome(skipped_reason=f"below-min-severity:{floor}")
        if not fingerprint:
            # Without a fingerprint there is no dedup key, so this would ask
            # again on every tick, forever. Refusing is the lesser failure.
            return QuestionOutcome(skipped_reason="no-fingerprint")

        draft = build_question(finding, fingerprint=fingerprint, artefact_root=root)
        if draft is None:  # pragma: no cover - a Finding always drafts
            return QuestionOutcome(skipped_reason="no-draft")
        return _raise_draft(root, draft, open_by_key=open_by_key)
    except Exception:  # noqa: BLE001
        _log.debug("captain-chat: raise_finding_question failed", exc_info=True)
        return QuestionOutcome(skipped_reason="error")


def raise_event_questions(artefact_root: Path,
                          events: Sequence[LifecycleEvent]) -> List[QuestionOutcome]:
    """Ask about each trigger event in *events*, oldest first.

    The open-question map is read ONCE for the whole batch and updated as we
    go, so ten ``VERIFY_FAILED`` lines for one order in a single poll produce
    one question — not one per line, and not N reads of the thread.
    """
    outcomes: List[QuestionOutcome] = []
    try:
        root = Path(artefact_root)
        open_by_key = _open_questions_by_key(root)
    except Exception:  # noqa: BLE001
        _log.debug("captain-chat: could not read open questions", exc_info=True)
        return outcomes

    for event in events or ():
        try:
            draft = build_question(event)
            if draft is None:
                continue
            outcomes.append(_raise_draft(root, draft, open_by_key=open_by_key))
        except Exception:  # noqa: BLE001
            _log.debug("captain-chat: event question failed", exc_info=True)
            outcomes.append(QuestionOutcome(skipped_reason="error"))
    return outcomes


# ---------------------------------------------------------------------------
# Supersession — a question the patrol has already answered for itself.
# ---------------------------------------------------------------------------

def reconcile_questions(artefact_root: Path,
                        open_fingerprints: Iterable[str],
                        acknowledged_fingerprints: Iterable[str] = (),
                        ) -> List[str]:
    """Supersede every open FINDING question whose condition no longer holds.

    Returns the message ids superseded. The Captain has to be able to trust
    that an open question is a live one: a thread showing a question the
    patrol cleared two days ago is the same failure as a status banner that
    lies — an operator learns to ignore it, which is precisely what this
    channel exists to prevent (BUG-MSO-2026-0713's lesson, applied here).

    Two conditions supersede, and the system note says WHICH:

    * the fingerprint is no longer in this tick's open findings — RESOLVED;
    * it is in *acknowledged_fingerprints* — the Captain answered it on
      another surface (`mso doctor ack`, the Hub drawer), and asking again
      would be the fleet not listening.

    EVENT-sourced questions are deliberately untouched. They have no
    fingerprint, so the patrol has no opinion on whether their condition
    still holds, and superseding one on the strength of a set it was never
    in would be closing a question on no evidence at all.
    """
    superseded: List[str] = []
    try:
        root = Path(artefact_root)
        still_open = {fp for fp in open_fingerprints if fp}
        acked = {fp for fp in acknowledged_fingerprints if fp}
        questions = chat.open_questions(root)
    except Exception:  # noqa: BLE001
        _log.debug("captain-chat: reconcile could not read the thread", exc_info=True)
        return superseded

    for message in questions:
        fp = message.subject.fingerprint
        if not fp:
            continue  # event-sourced — see the docstring
        if fp in acked:
            reason = "acknowledged"
            note = (
                "Superseded — you acknowledged this finding, so the LEAD has "
                "stopped asking about it. It returns if the acknowledgement "
                "expires or the finding escalates past the severity it was "
                "acknowledged at."
            )
        elif fp not in still_open:
            reason = "resolved"
            note = (
                "Superseded — RESOLVED. The patrol no longer reports this "
                "finding, so the condition it asked about has cleared. It "
                "returns as a new question if the condition comes back."
            )
        else:
            continue
        if supersede_question(root, message.id, reason=reason, note=note,
                              subject=message.subject):
            superseded.append(message.id)
    return superseded


def supersede_question(artefact_root: Path, message_id: str, *, reason: str,
                       note: str, subject: Optional[Subject] = None) -> bool:
    """Mark one open question ``superseded`` and say so in the thread.

    Both halves matter. The state change is what stops
    :func:`reconcile_questions` and the ``lead.chat-open-question`` check
    from seeing it again; the ``system`` message is what tells a human
    reading the thread WHY a question they never answered went quiet —
    without it, the thread would silently drop questions and read as though
    the LEAD had lost interest.

    A failure to post the note does not undo the state change: the question
    is genuinely no longer open, and re-opening it to keep the two in step
    would put a stale question back in front of the Captain to preserve a
    note.
    """
    root = Path(artefact_root)
    try:
        chat.append_update(root, message_id, question_state="superseded",
                           reason=reason)
    except Exception:  # noqa: BLE001
        _log.debug("captain-chat: supersede failed for %s", message_id, exc_info=True)
        return False
    try:
        chat.post_system_message(root, note, kind="status",
                                 in_reply_to=message_id, subject=subject)
    except Exception:  # noqa: BLE001
        _log.debug("captain-chat: supersede note failed for %s", message_id, exc_info=True)
    return True


# ---------------------------------------------------------------------------
# The lifecycle-event cursor — durable, because a daemon restarts.
# ---------------------------------------------------------------------------

def _event_cursor_path(artefact_root: Path) -> Path:
    return chat.chat_dir(Path(artefact_root)) / EVENT_CURSOR_FILENAME


def load_event_cursor(artefact_root: Path) -> Optional[int]:
    """The persisted lifecycle-log byte offset, or ``None`` if there is none.

    ``None`` means "this workspace has never polled", and the caller must
    treat it as SEEK TO END rather than zero — a daemon started on a
    workspace with months of ``lifecycle.log`` behind it must not open the
    thread with a flood of questions about events that are long since dealt
    with. Never raises.
    """
    try:
        data = json.loads(_event_cursor_path(artefact_root).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    value = data.get("offset") if isinstance(data, dict) else None
    try:
        offset = int(value)
    except (TypeError, ValueError):
        return None
    return offset if offset >= 0 else None


def save_event_cursor(artefact_root: Path, offset: int) -> bool:
    """Persist the lifecycle-log byte offset. Returns whether the write landed.

    Written to a temp file and ``os.replace``d, like every other small state
    file in the control plane (``lead_banner``, ``patrol.state``): a torn
    cursor read as a smaller offset would re-ask questions already asked.
    """
    path = _event_cursor_path(artefact_root)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".json.tmp")
        tmp.write_text(
            json.dumps({"offset": int(offset), "updatedAt": _now_iso()}, indent=2),
            encoding="utf-8",
        )
        os.replace(str(tmp), str(path))
        return True
    except Exception:  # noqa: BLE001
        _log.debug("captain-chat: event cursor write failed", exc_info=True)
        return False


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def poll_trigger_events(artefact_root: Path) -> List[LifecycleEvent]:
    """Lifecycle trigger events appended since the last poll of this workspace.

    Reads through ``LeadEventTailer`` — the SAME tailer of the SAME
    ``hub.lifecycle_tail.LifecycleTail`` the Hub's WebSocket stream uses, so
    this is a third reader of one implementation, not a third parser of the
    log format.

    The position is persisted (:func:`save_event_cursor`) rather than held in
    the tailer, because the tailer lives for one call and the daemon it
    serves is expected to outlive dispatchers, Hubs and sessions. A first
    poll with no cursor starts at the END of the log (see
    :func:`load_event_cursor`); the cursor is advanced even when no trigger
    event was found, so a quiet log is read once and not re-read.

    Never raises: an unreadable lifecycle log means no questions this tick,
    not a failed tick.
    """
    try:
        root = Path(artefact_root)
        tailer = LeadEventTailer(root)
        cursor = load_event_cursor(root)
        if cursor is None:
            tailer.seek_to_end()
            save_event_cursor(root, tailer.offset)
            return []
        tailer.seek_to(cursor)
        events = [e for e in tailer.poll() if is_trigger_event(e)]
        save_event_cursor(root, tailer.offset)
        return events
    except Exception:  # noqa: BLE001
        _log.debug("captain-chat: trigger-event poll failed", exc_info=True)
        return []


def stale_open_questions(artefact_root: Path, *, hours: int,
                         now: Optional[datetime] = None) -> List[chat.ChatMessage]:
    """Open questions posted more than *hours* ago, oldest first.

    The reader behind the ``lead.chat-open-question`` patrol check. "Open
    for" is measured from the question's own ``ts``, not from the last
    re-raise: a question re-raised every tick for twelve hours has still
    gone twelve hours unanswered, and measuring from the refresh would make
    a permanently-true condition permanently invisible.

    A message whose timestamp will not parse is INCLUDED, for the same
    reason ``chat.recent_decisions`` includes one: dropping it would hide an
    unanswered question because of a formatting fault.
    """
    now = now or datetime.now(timezone.utc)
    cutoff = now - timedelta(hours=max(int(hours), 0))
    out: List[chat.ChatMessage] = []
    for message in chat.open_questions(artefact_root):
        ts = _parse_ts(message.ts)
        if ts is None or ts <= cutoff:
            out.append(message)
    return out


def _parse_ts(value: str) -> Optional[datetime]:
    try:
        parsed = datetime.fromisoformat(str(value))
    except (TypeError, ValueError):
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed
