# Maestro — Architecture & Data Flow

> Version: 2.0.0 (framework) / 3.0.0 (enterprise hardening, in progress)
> Audience: security-aware enterprise buyers, procurement, and infrastructure teams.

---

## Contents

1. [Architecture diagram](#1-architecture-diagram)
2. [Data flow narrative — order lifecycle](#2-data-flow-narrative--order-lifecycle)
3. [Egress inventory](#3-egress-inventory)
4. [Air-gapped deployment guide](#4-air-gapped-deployment-guide)
5. [Security posture statement](#5-security-posture-statement)

---

## 1. Architecture Diagram

The diagram below describes every process Maestro starts, every network boundary it crosses, and every file it writes. All components run on the operator's machine (or CI runner) unless noted.

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  OPERATOR MACHINE / CI RUNNER                                               │
│                                                                             │
│  ┌────────────────┐   CLI commands    ┌──────────────────────────────────┐  │
│  │  Operator      │──────────────────▶│  adm CLI (Python process)        │  │
│  │  (human)       │                   │  maestro/cli.py                │  │
│  └────────────────┘                   │                                  │  │
│                                       │  • Reads workspace.json          │  │
│  ┌────────────────┐                   │  • Installs egress filter        │  │
│  │  Slack /       │  HTTP (optional)  │  • Calls auth.py → GitHub API    │  │
│  │  GitHub Gist   │◀─────────────────▶│  • Calls bridge start/stop       │  │
│  └────────────────┘                   └────────────┬─────────────────────┘  │
│                                                    │ spawns                  │
│                                       ┌────────────▼─────────────────────┐  │
│                                       │  Fleet Runner (Python process)   │  │
│                                       │  maestro/core/fleet_runner.py  │  │
│                                       │                                  │  │
│                                       │  • Reads orders from .mso/queues │  │
│                                       │  • Manages PID files (.mso/crews)│  │
│                                       │  • Writes fleet-runner-state.json│  │
│                                       │  • Enforces role sequence gates  │  │
│                                       └────────────┬─────────────────────┘  │
│                                                    │ spawns (detached)       │
│                              ┌─────────────────────▼──────────────────────┐ │
│                              │  Crew processes (one per concurrent crew)  │ │
│                              │  maestro/core/crew.py (via Claude Code)  │ │
│                              │                                            │ │
│                              │  Per crew:                                 │ │
│                              │  • .mso/crews/crewN/ralph-state.md        │ │
│                              │  • .mso/crews/crewN/progress.md           │ │
│                              │  • ANTHROPIC_API_KEY injected via sandbox  │ │
│                              │  • Voyage worktree (git worktree per voyage)│ │
│                              └────────────┬───────────────────────────────┘ │
│                                           │                                  │
│                  ┌────────────────────────┼────────────────────────────┐     │
│                  │                        │                            │     │
│                  ▼                        ▼                            ▼     │
│          ┌───────────────┐   ┌────────────────────┐   ┌─────────────────┐   │
│          │  Claude Code  │   │  MCP servers       │   │  Git / VCS      │   │
│          │  (subprocess) │   │  (subprocess, opt) │   │  (subprocess)   │   │
│          │               │   │                    │   │                 │   │
│          │  Egress:      │   │  Operator-chosen;  │   │  Egress:        │   │
│          │  api.anthropic│   │  any domain        │   │  github.com /   │   │
│          │  .com only    │   │  operator allows   │   │  bitbucket.org  │   │
│          └───────────────┘   └────────────────────┘   └─────────────────┘   │
│                                                                             │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  .mso/ WORKSPACE DIRECTORY (project root)                            │   │
│  │                                                                      │   │
│  │  config/workspace.json        — runtime configuration               │   │
│  │  config/role-paths.json       — role-to-model mappings              │   │
│  │  config/mcp-servers.json      — MCP server allowlist                │   │
│  │  queues/orders/               — pending order JSON files            │   │
│  │  queues/bugs/, security/, …   — other queue types                   │   │
│  │  orders/active/               — in-progress order JSON              │   │
│  │  orders/complete/             — completed order JSON                │   │
│  │  orders/failed/               — failed order JSON                   │   │
│  │  voyages/active/              — voyage manifests                    │   │
│  │  voyages/complete/            — closed voyage records               │   │
│  │  plans/                       — Navigator planning documents        │   │
│  │  reports/qa/, security/, …    — crew output reports                 │   │
│  │  audit/log.jsonl              — append-only audit log (enterprise)  │   │
│  │  identity/users/, groups/     — identity records (enterprise)       │   │
│  │  usage/orders/                — token usage records                 │   │
│  │  handoffs/                    — role-to-role transition documents   │   │
│  │  [gitignored] crews/          — runtime crew state + repo clones    │   │
│  │  [gitignored] logs/           — fleet and bridge logs               │   │
│  │  [gitignored] bridge/         — bridge runtime state                │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ~/.maestro/auth.json           — licence cache (GitHub PAT, username)   │
│  ~/.maestro/projects.json       — global project registry                │
└─────────────────────────────────────────────────────────────────────────────┘

EXTERNAL NETWORK BOUNDARIES
═══════════════════════════
  api.anthropic.com       — LLM inference (crew Claude sessions)
  api.github.com          — licence validation + VCS operations
  github.com              — git push/pull (SSH or HTTPS)
  bitbucket.org           — git push/pull (optional)
  slack.com / api.slack.com — bridge notifications (optional)
  <operator-chosen MCP>   — any domain permitted by the operator
  <audit anchor>          — s3.amazonaws.com, *.blob.core.windows.net,
                            or customer-chosen S3-compatible (enterprise)
```

**Notes:**
- All subprocess spawning routes through `maestro/launch/sandbox.py:spawn()`, which builds a minimal environment (PATH, HOME, LANG, ANTHROPIC_API_KEY, MAESTRO_**, CLAUDE_\*) and strips all other inherited environment variables when `enterprise: true`.
- MCP server processes are spawned as subprocesses of Claude Code. Their network access is not constrained by Maestro's egress filter (which operates at the urllib/requests layer). Use network-layer controls (firewall, egress proxy) to restrict MCP server egress.
- The Bridge components (Gist poller, Slack bot, notifier) are optional and disabled by default. They are only active when the operator runs `mso bridge start`.

---

## 2. Data Flow Narrative — Order Lifecycle

This section traces a single order from creation to PR merge, identifying what data exists where and which boundaries it crosses at each step.

### Step 1 — Order creation

**What happens:** The operator (or a Navigator crew) writes an order JSON file to `.mso/queues/orders/FTR-{PROJECT}-{YEAR}-{SEQ}.json`.

**Data in motion:** None. File is written locally. No network egress.

**Files written:**
- `.mso/queues/orders/<order-id>.json` — order specification (title, role, description, target files, acceptance criteria)

**Boundaries crossed:** None.

---

### Step 2 — Fleet runner picks up the order

**What happens:** `mso dispatch` starts the fleet runner (`fleet_runner.py`). The runner scans `.mso/queues/orders/`, selects an eligible order (respecting dependency gates and role-sequence rules), moves it to `.mso/orders/active/`, and records its intention.

**Data in motion:** None external. State written locally.

**Files written:**
- `.mso/orders/active/<order-id>.json` — order marked active
- `.mso/fleet-runner-state.json` — (gitignored) runner checkpoint
- `.mso/crews/crewN/ralph-state.md` — (gitignored) crew iteration state

**Boundaries crossed:** None.

---

### Step 3 — Licence validation

**What happens:** Before the crew Claude session starts, `auth.py` loads a cached GitHub PAT from `~/.maestro/auth.json` and calls `GET https://api.github.com/repos/tavisbasing/Maestro/collaborators/{username}`.

**Data in motion:**
- Outbound to `api.github.com`: HTTP request containing the operator's GitHub PAT in the `Authorization` header and the operator's GitHub username in the URL path.
- Inbound from `api.github.com`: HTTP 204 (authorised) or 404 (not authorised).

**Files written:**
- `~/.maestro/auth.json` — `last_verified` timestamp updated on success. Token stored in plain text at `0600` permissions.

**Boundaries crossed:** Operator machine → `api.github.com` (HTTPS, port 443).

**Bypass:** Set `MAESTRO_SKIP_AUTH=1` in CI/CD environments or in air-gapped deployments (see §4).

---

### Step 4 — Voyage worktree prepared

**What happens:** The fleet runner creates a git worktree at `.mso/voyages/active/VOY-X/.worktree/` on the voyage branch. Each crew operates in this isolated working tree.

**Data in motion:**
- Local git worktree add (no network required if branch already tracked).
- Outbound fetch to VCS host if the branch isn't local yet.

**Files written:**
- `.mso/voyages/active/VOY-X/.worktree/` — (gitignored) per-voyage working tree

**Boundaries crossed:** Operator machine → VCS host (HTTPS port 443 or SSH port 22) for branch fetch only.

---

### Step 5 — Crew Claude session runs

**What happens:** The fleet runner spawns a detached Claude Code process with the order prompt injected. `crew.py` invokes `claude --print --output-format json --max-turns N --session-id <uuid>` once per iteration in a Python `for`-loop. The structured JSON result (not raw stdout) is the primary classification source. Claude Code connects to the Anthropic API to perform inference. The crew reads and writes files within the target repo clone and the `.mso/` workspace.

**Structured result parsing (FTR-MSO-2026-0193):** Each Claude CLI invocation produces a JSON object on stdout containing `subtype`, `is_error`, `result`, `session_id`, `num_turns`, and `total_cost_usd`. Maestro classifies the invocation as `COMPLETE`, `MAX_TURNS`, or `ERROR` from these fields rather than grepping raw text output. On wall-clock timeout or malformed output, a safe sentinel dict is returned and classified as `ERROR`. See [CREW-INVOCATION.md §2](CREW-INVOCATION.md#2-json-result-contract) for the full contract.

**Data in motion:**
- Outbound to `api.anthropic.com`: Inference requests containing the system prompt, order text, file contents read by the crew, and any tool results. These requests contain code, documentation, and configuration from the target repository.
- Inbound from `api.anthropic.com`: Model completions (tool calls, text responses).

**Files written (target repo clone):**
- Source code, documentation, configuration — as directed by the order.

**Files written (.mso/ workspace):**
- `.mso/crews/crewN/progress.md` — (gitignored) crew iteration log
- `.mso/crews/crewN/state.json` — (gitignored) crew state including `maestroSessionId`, `claudeSessionId`, `numTurns`, `totalCostUsd`
- `.mso/usage/orders/<order-id>.json` — token usage record

**Boundaries crossed:** Operator machine → `api.anthropic.com` (HTTPS, port 443).

**Data classification note:** The contents of files read by the crew — source code, secrets referenced in config, comments — are transmitted to Anthropic's API as part of the inference context. Operators should ensure no unresolved secrets appear in files the crew will read.

**Further reading:** [CREW-INVOCATION.md](CREW-INVOCATION.md) — full crew invocation model reference (JSON contract, terminal states, tool scoping, session IDs, preflight check).

---

### Step 6 — Hook intercepts Stop event

**What happens:** When the crew session would naturally exit, the `maestro/hooks/stop.py` hook intercepts the Stop event, evaluates whether the order is complete (or whether another iteration is needed), and re-feeds the prompt if iteration count allows. Bridge notifications may fire here.

**Data in motion:**
- Optional: outbound to `api.slack.com` (Slack bridge notification).
- Optional: outbound to `gist.github.com` (Gist bridge poller read).

**Files written:**
- `.mso/crews/crewN/ralph-state.md` — iteration count updated
- `.mso/handoffs/<role>-<order-id>.md` — role handoff document (if crew produces one)

**Boundaries crossed:** Optionally — operator machine → `api.slack.com`, `gist.github.com`.

---

### Step 7 — Commits pushed to voyage branch

**What happens:** The crew (or the fleet runner post-completion logic) runs `git push` to push commits on the voyage branch to the remote VCS host.

**Data in motion:**
- Outbound to VCS host: git push over HTTPS or SSH, containing committed source changes.

**Files written:**
- `.mso/orders/complete/<order-id>.json` — order marked complete

**Boundaries crossed:** Operator machine → VCS host.

---

### Step 8 — Pull request created

**What happens:** The fleet runner calls the VCS API (e.g. `api.github.com`) to open a pull request from the voyage branch to `main`.

**Data in motion:**
- Outbound to `api.github.com`: PR creation request containing branch name, title, body.
- Inbound: PR URL.

**Files written:**
- `.mso/voyages/complete/<voyage-id>.json` — voyage closed after all orders complete

**Boundaries crossed:** Operator machine → `api.github.com`.

---

### Step 9 — PR reviewed and merged

**What happens:** A human reviewer approves and merges the PR using standard VCS tooling. Maestro is not involved after PR creation.

**Data in motion:** None through Maestro.

**Boundaries crossed:** None through Maestro.

---

## 3. Egress Inventory

The table below lists every external domain Maestro contacts at runtime, the purpose of each contact, and whether it is optional or required.

| Domain | Protocol | Purpose | Required / Optional |
|--------|----------|---------|---------------------|
| `api.anthropic.com` | HTTPS | LLM inference — all crew Claude sessions | **Required** (core function) |
| `api.github.com` | HTTPS | Licence validation (collaborator check) | Required unless `MAESTRO_SKIP_AUTH=1` |
| `api.github.com` | HTTPS | PR creation, VCS API operations | Required when using GitHub |
| `github.com` | HTTPS or SSH | git clone, fetch, push (target repos) | Required when using GitHub |
| `raw.githubusercontent.com` | HTTPS | (potential) — package resource fetches if `importlib.resources` falls back | Incidental |
| `gist.github.com` | HTTPS | Bridge Gist poller — inbound commands from mobile | Optional (Bridge only) |
| `slack.com` / `api.slack.com` | HTTPS | Bridge Slack bot — notifications + interactive commands | Optional (Bridge only) |
| `bitbucket.org` | HTTPS or SSH | git operations (alternative VCS) | Optional |
| `s3.amazonaws.com` | HTTPS | Audit log external anchoring (enterprise, S3 provider) | Optional (Enterprise audit) |
| `*.blob.core.windows.net` | HTTPS | Audit log external anchoring (enterprise, Azure Blob provider) | Optional (Enterprise audit) |
| `<operator-chosen S3-compatible>` | HTTPS | Audit log external anchoring (enterprise, S3-compatible provider) | Optional (Enterprise audit) |
| `<operator-chosen MCP server host>` | Varies | MCP server capabilities — any domain permitted by the operator | Optional (MCP servers) |
| `<operator-chosen secrets provider>` | HTTPS | Secrets resolution: Vault, AWS Secrets Manager, Azure Key Vault, 1Password Connect | Optional (Enterprise secrets) |

**Important:** Maestro's egress filter (`maestro/egress/filter.py`) operates at the Python urllib/requests layer. It does not intercept direct socket calls, subprocess stdout, or network calls made by MCP server subprocesses. In enterprise deployments, complement the software-layer filter with a network-layer control (firewall or egress proxy).

---

## 4. Air-Gapped Deployment Guide

### Overview

Maestro supports three egress modes, configured in `.mso/config/workspace.json`:

| Mode | Behaviour |
|------|-----------|
| `permissive` | All outbound HTTP allowed (default, non-enterprise) |
| `restrictive` | Only destinations matching `allowedDestinations` are permitted |
| `air-gapped` | All outbound HTTP denied except `localhost`, `127.0.0.1`, `::1`, and Unix sockets |

### Minimal egress allowlist (restrictive mode)

The minimum set of destinations required for core function, with the Bridge and enterprise audit anchor disabled:

```json
{
  "enterprise": true,
  "dataResidency": {
    "mode": "restrictive",
    "allowedDestinations": [
      "api.anthropic.com",
      "api.github.com",
      "github.com"
    ]
  }
}
```

If using Bitbucket instead of GitHub, replace `api.github.com` and `github.com` with `api.bitbucket.org` and `bitbucket.org`.

If using an enterprise audit anchor, add the anchor host (e.g. `s3.amazonaws.com` or `*.blob.core.windows.net`).

If MCP servers are in use, add each MCP server's hostname to `allowedDestinations`.

### True air-gapped mode

In environments with no outbound internet access:

```json
{
  "enterprise": true,
  "dataResidency": {
    "mode": "air-gapped"
  }
}
```

Maestro will log `[Maestro] EGRESS MODE: AIR_GAPPED` prominently on startup.

In air-gapped mode, the following additional steps are required:

**1. Disable licence validation**

Set the environment variable `MAESTRO_SKIP_AUTH=1` in the shell or CI environment before running any `adm` command. This bypasses the GitHub collaborator check entirely.

```bash
export MAESTRO_SKIP_AUTH=1
mso dispatch
```

In Windows:
```cmd
set MAESTRO_SKIP_AUTH=1
mso dispatch
```

**2. Pre-install Claude Code and the `claude` CLI**

Claude Code must be pre-installed on the air-gapped machine. No automatic update mechanism exists within Maestro itself; Claude Code's own auto-update (if any) must be disabled or blocked at the network layer.

**3. Configure Anthropic API via a local proxy or private endpoint**

If the Anthropic API is available through an on-premises proxy or private endpoint, set:

```bash
export ANTHROPIC_API_URL=https://your-internal-proxy.example.com
```

Claude Code respects the `ANTHROPIC_API_URL` environment variable. If the Anthropic API is not reachable at all, crew Claude sessions will fail to connect and the fleet runner will mark orders as failed.

**4. Disable the Bridge**

Do not run `mso bridge start`. The Bridge requires outbound connections to `gist.github.com` and `api.slack.com`.

**5. Use a local filesystem audit anchor (development only) or pre-provision a local S3-compatible endpoint**

```json
{
  "enterprise": true,
  "audit": {
    "anchorProvider": "filesystem",
    "providerConfig": {
      "path": "/secure/audit-anchor"
    }
  }
}
```

Note: filesystem anchoring is not tamper-proof and is not suitable for production compliance use. For production air-gapped deployments, provision a local S3-compatible endpoint (e.g. MinIO) and use the `s3_compatible` provider.

**6. Disable auto-update**

Maestro does not implement its own auto-update mechanism. The `mso` CLI is installed via `pip install`. To prevent automatic updates:

- Pin the package version in your deployment manifest: `maestro==4.4.0`
- Use an internal PyPI mirror and do not mirror new versions until vetted
- Block outbound access to `pypi.org` and `files.pythonhosted.org` at the network layer (these are not contacted by Maestro at runtime, only at install time)

---

## 5. Security Posture Statement

*Formatted for vendor security questionnaires. Copy and adapt as required.*

---

**Product:** Maestro Maestro
**Version assessed:** 2.0.0 (framework); v3.0.0 enterprise hardening in progress
**Assessment date:** 2026-04-28

---

### Deployment model

Maestro is an on-premises orchestration framework. All processes run on the operator's machine or CI runner. No Maestro-operated cloud infrastructure exists. The operator retains full control of the execution environment.

### Data handled

Maestro processes:
- Source code, configuration, and documentation from target repositories (transmitted to Anthropic's API as inference context)
- Order and voyage metadata (stored locally in `.mso/`)
- Token usage records (stored locally in `.mso/usage/`)
- Operator identity information: GitHub username, GitHub PAT (stored in `~/.maestro/auth.json` at `0600` permissions)
- In enterprise mode: user email addresses and display names in `.mso/identity/` (optional encryption via git-crypt or SOPS)

### Network egress

At runtime, Maestro contacts:
- `api.anthropic.com` — LLM inference (required for core function)
- `api.github.com` — licence validation and VCS API operations
- `github.com` — git operations
- Operator-configured destinations only (MCP servers, audit anchors, secrets providers)

Egress can be restricted to an explicit allowlist or fully disabled (air-gapped mode) via `workspace.json`. See §3 and §4.

### Authentication and authorisation

- Maestro does not operate its own identity provider
- Licence validation uses a GitHub PAT stored locally at `0600` permissions
- Enterprise mode supports OIDC, VCS identity, `MAESTRO_USER` env var, or OS user fallback
- Capability-based ACL (`access.json`) gates all privileged actions when enterprise mode is enabled
- ACL files are integrity-checked against git state or a SHA-256 manifest before load; tampered files cause a hard startup failure

### Secrets handling

- Secrets are never stored in plaintext in `.mso/` config files; a reference scheme (`secret://provider/key`) is used
- Secrets are resolved lazily at use site and never written to disk or logged
- Central log filter redacts `secret://...` strings and known resolved values before any log line emits
- Subprocess environments are scrubbed to a minimal set when `enterprise: true`
- Supported providers: environment variables, OS keyring, Azure Key Vault, AWS Secrets Manager, HashiCorp Vault, 1Password Connect

**Open finding (CRITICAL):** `print()` calls and subprocess stdout bypass the central log filter. This is an open finding from the V6 pen-test (ref: SEC-FTR-ADM-2026-0064, Scenario 3.1). Mitigation is planned in the v3.0.x patch voyage before any production customer deployment.

### Audit logging

- Enterprise mode requires an append-only audit log at `.mso/audit/log.jsonl` with SHA-256 hash chaining
- External anchoring to immutable storage (AWS S3 Object Lock, Azure Immutable Blob, S3-compatible) is mandatory in enterprise mode
- `mso audit verify` walks the hash chain and exits non-zero on detected tampering

**Open finding (CRITICAL):** Log truncation is not currently detected by `verify_chain`. Frequent external anchoring partially mitigates. Planned for v3.0.x patch.

### Data residency

- All `.mso/` artefacts are stored on the operator's machine within the project repository
- Source code is transmitted to Anthropic's API as inference context. Operators should review Anthropic's data processing terms for compliance with their data residency requirements
- Enterprise mode provides `restrictive` and `air-gapped` egress modes to control which external destinations are reachable

### Vulnerability disclosure and patching

- Two internal security reviews have been conducted (pre- and post-implementation of V6 enterprise hardening)
- Open findings from the post-implementation review are documented in `docs/ENTERPRISE-SECURITY.md §7`
- All CRITICAL and HIGH findings block the v3.0.0 release; they will be remediated in a v3.0.x patch voyage before any production customer deployment
- No enterprise customer should run V6 without independent external security review. The internal pen-test was conducted for design validation only

### Compliance mapping

See [COMPLIANCE-MAPPING.md](COMPLIANCE-MAPPING.md) for SOC 2 CC and ISO 27001 Annex A control mappings.

---

*This document describes intended controls. It is not a certification or audit opinion. Procurement should engage an independent security assessor for formal assurance.*
