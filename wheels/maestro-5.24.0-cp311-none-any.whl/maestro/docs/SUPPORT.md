# Maestro — Support

How to get help, report bugs, and contact us for licensing and security matters.

---

## Contents

1. [Self-Service Resources](#1-self-service-resources)
2. [Bug Reports](#2-bug-reports)
3. [Security Issues](#3-security-issues)
4. [Licence and Billing](#4-licence-and-billing)
5. [Enterprise Support](#5-enterprise-support)
6. [Service Level Agreements](#6-service-level-agreements)

---

## 1. Self-Service Resources

Before opening a support request, check the following resources — most common issues are covered:

| Resource | What it covers |
|----------|---------------|
| [TROUBLESHOOTING.md](TROUBLESHOOTING.md) | Top 20 common errors with cause and fix |
| [GETTING-STARTED.md](GETTING-STARTED.md) | Installation, workspace setup, first dispatch |
| [CLI-REFERENCE.md](CLI-REFERENCE.md) | All commands, flags, and examples |
| [LICENCE.md](LICENCE.md) | Licence tiers, activation, expiry |
| [ENTERPRISE-SETUP.md](ENTERPRISE-SETUP.md) | Multi-team deployment, network, compliance, SSO |
| [OPERATOR-GUIDE.md](OPERATOR-GUIDE.md) | Day-to-day fleet operation |

---

## 2. Bug Reports

**Channel:** [GitHub Issues — tavisbasing/Maestro](https://github.com/Maestrodevs)

Use GitHub Issues for:
- Unexpected errors or crashes
- Incorrect command output
- Documentation errors or gaps
- Feature requests

### How to file a good bug report

Include the following information to help us reproduce the issue quickly:

1. **Maestro version:**
   ```bash
   mso version
   ```

2. **Python version:**
   ```bash
   python --version
   ```

3. **Operating system and version** (e.g. macOS 14.4, Windows 11, Ubuntu 22.04)

4. **Steps to reproduce** — the exact commands you ran, in order

5. **Expected behaviour** — what you expected to happen

6. **Actual behaviour** — what actually happened, including the full error message

7. **Relevant files** (if applicable):
   - `.maestro/crews/crewN/progress.md` (crew progress)
   - `.maestro/crews/crewN/activity.txt` (last known action)
   - The order JSON from `.maestro/queues/orders/` or `.maestro/orders/active/`

**Sensitive data:** Redact your `ANTHROPIC_API_KEY`, licence token, and any proprietary source code before posting. GitHub Issues are public.

### Issue labels

| Label | Use for |
|-------|---------|
| `bug` | Something is broken |
| `documentation` | Doc error or gap |
| `enhancement` | Feature request |
| `question` | General question (prefer Discussions for this) |

---

## 3. Security Issues

**Do not open a public GitHub Issue for security vulnerabilities.**

Security issues include:
- Authentication bypass or licence validation weaknesses
- Injection vulnerabilities in order processing or crew dispatch
- Unintended exposure of API keys or secrets
- Privilege escalation via hook system

### Reporting

Report security vulnerabilities via **[GitHub Security Advisories](https://github.com/Maestrodevs)**

Include in your report:
- Description of the vulnerability
- Steps to reproduce
- Potential impact
- Your contact details (for follow-up)

### What to expect

| Step | Timeline |
|------|---------|
| Acknowledgement | Within 48 hours |
| Initial assessment | Within 5 business days |
| Fix timeline estimate | Within 10 business days of confirmation |
| Public disclosure | After fix is released; coordinated with reporter |

We follow responsible disclosure. We will credit reporters in the release notes unless you prefer to remain anonymous.

---

## 4. Licence and Billing

### Purchasing a licence

Use the [Maestro contact page](https://www.maestrodevs.com/contact/).

Include in your enquiry:
- Desired tier (Pro / Team / Enterprise)
- Number of machines or seats
- Organisation name (for Team/Enterprise)
- Preferred expiry term (1 year standard)
- Whether the machines are air-gapped (you will need an `MSO1.` token; see [AIR-GAPPED.md](AIR-GAPPED.md))

### Activating your token

Once you have a token:
```bash
mso licence activate MSO1.<YOUR-TOKEN>
mso licence status
```

See [LICENCE.md](LICENCE.md) for the full activation flow.

### Renewing an expiring licence

Ask for a renewal token before the expiry date and run `mso licence activate` with it. Maestro warns you 30 days and 7 days before expiry. After the expiry date Pro, Team and Enterprise licences have a 14-day grace period; see [LICENCE.md](LICENCE.md#expiry-and-renewal). Use the [Maestro contact page](https://www.maestrodevs.com/contact/) at least 2 weeks before expiry to avoid any interruption.

### Token lost or corrupted

If you have lost your licence token or need a replacement, use the [Maestro contact page](https://www.maestrodevs.com/contact/) and give the organisation name, the tier, and the expiry date of the licence you are replacing.

### Billing disputes

For invoice or billing issues, use the [Maestro contact page](https://www.maestrodevs.com/contact/).

---

## 5. Enterprise Support

Enterprise licence holders receive access to a dedicated support channel.

**Contact:** the [Maestro contact page](https://www.maestrodevs.com/contact/)

Include your **licensee name and licence ID** (both shown by `mso licence status`) in all enterprise support requests so we can identify your organisation and tier.

Enterprise support covers:
- Priority response (see SLA below)
- Multi-team deployment guidance
- SSO configuration assistance
- Custom SLA arrangements
- Escalation path for critical production issues

---

## 6. Service Level Agreements

Response time targets by tier.

| Tier | Channel | Initial response | Update cadence |
|------|---------|-----------------|----------------|
| **Trial** | GitHub Issues | Best effort (community) | None guaranteed |
| **Solo** | GitHub Issues | Best effort | None guaranteed |
| **Team** | GitHub Issues + email | 2 business days | As needed |
| **Enterprise** | Dedicated email | 1 business day | Every 2 business days until resolved |
| **Enterprise (Critical)** | Dedicated email | 4 business hours | Daily until resolved |

### Definition of severity

| Severity | Description |
|----------|-------------|
| **Critical** | Production fleet completely down; no workaround available |
| **High** | Major feature broken; workaround is difficult or unavailable |
| **Medium** | Feature partially broken; workaround exists |
| **Low** | Cosmetic issue, documentation error, or feature request |

SLA response targets apply to Team and Enterprise tiers only. Trial and Solo support is provided on a best-effort basis via GitHub Issues.

### Community support

For general questions, usage tips, and non-urgent discussions, use [GitHub Discussions](https://github.com/tavisbasing/Maestro/discussions) on the Maestro repository. The community and maintainers monitor this channel.

---

*Maestro — Bugs: [GitHub Issues](https://github.com/Maestrodevs). Licensing and billing: [Maestro contact page](https://www.maestrodevs.com/contact/). Vulnerabilities: [GitHub Security Advisories](https://github.com/Maestrodevs).*
