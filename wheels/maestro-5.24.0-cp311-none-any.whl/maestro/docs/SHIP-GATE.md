# Ship gate, re-land and release planning

When a voyage finishes, its pull request still needs **your** go-ahead to merge. This guide covers
the commands that make that decision quick and well-founded:

- [`mso pr ready` / `mso voyage ready`](#the-ship-gate) answer "is this voyage safe to merge?" from
  the final evidence, in six rows.
- [The evidence comment](#the-evidence-comment) puts that answer on the pull request itself.
- [`mso voyage reland`](#re-landing-a-stale-or-conflicting-voyage) re-creates a finished voyage on a
  fresh branch when its PR has gone stale or conflicting.
- [`--requires voy:`](#holding-an-order-until-another-voyage-has-merged) holds an order until another
  voyage has merged.
- [`mso release plan`](#planning-a-release) reports what a release would contain and whether the
  fleet is ready for one.

**Maestro never merges, tags, releases or publishes for you.** Every command here only reads, or
writes a report or a comment. The merge, the release cut, the tag, the package publish and the
website deploy are always steps **you** run. See [Release steps stay yours](#release-steps-stay-yours).

## Contents

- [The ship gate](#the-ship-gate)
- [Reading the result](#reading-the-result)
- [The evidence comment](#the-evidence-comment)
- [Re-landing a stale or conflicting voyage](#re-landing-a-stale-or-conflicting-voyage)
- [Holding an order until another voyage has merged](#holding-an-order-until-another-voyage-has-merged)
- [Planning a release](#planning-a-release)
- [Release steps stay yours](#release-steps-stay-yours)
- [Settings](#settings)
- [Patrol checks and the LEAD](#patrol-checks-and-the-lead)
- [Offline mode](#offline-mode)

---

## The ship gate

```
mso pr ready [--json] [--post]
mso voyage ready VOY-ID [--json] [--post] [--project @P]
```

Both run the same check. `mso voyage ready` names the voyage. `mso pr ready` takes no argument: it
uses the voyage of `$MAESTRO_VOYAGE_BRANCH` (the same scoping as the other `mso pr` commands, which
is how a role such as REL uses it). Abbreviated flags are refused.

The gate reads the **final** evidence for the voyage's pull request and answers READY or NOT READY.
It is READY only when every one of the six gates below is `PASS` or `N/A`.

| # | Gate | PASS when |
|---|------|-----------|
| 1 | Voyage finished | Every order of the voyage has reached `COMPLETE` (or been skipped on purpose) |
| 2 | CI on current tip | The PR is not a draft, no check is pending, and every check on the current tip passed |
| 3 | Acceptance criteria | Each order's acceptance criteria are recorded as met. A criterion recorded as skipped or partial fails the gate; one with no recorded result is `UNKNOWN` |
| 4 | Code review / QA | The final QA (and REL, where the order has one) report is a pass, and no review thread, human or bot, is still unresolved |
| 5 | Security | The final security report for each order that has one is APPROVED |
| 6 | Mergeable | The provider reports the PR as clean: no conflicts, not behind its base, not blocked |

"Final" matters: a report from an earlier pass (`-lap1`, `-reverify`, or one filed under
`superseded/`) is listed as history only. If an order failed security review on its first pass and
was approved on its second, gate 5 reads the second. A report you have waived shows as
`PASS (waived)` and stops counting if that report is later changed.

### Exit codes

| Code | Meaning |
|------|---------|
| `0` | READY |
| `1` | NOT READY. This includes an offline evaluation, because CI and mergeability could not be read |
| `2` | Could not evaluate: unknown voyage, no pull request for it, a multi-repo voyage, a missing or unmatched `$MAESTRO_VOYAGE_BRANCH`, or a workspace problem. With `--json` the output is `{"verdict": null, "error": …, "hint": …}` |

When `mso pr ready` cannot find a voyage for the branch, the hint suggests `mso voyage ready VOY-ID`.

### Flags

| Flag | Description |
|------|-------------|
| `--json` | Machine-readable result. The Hub's voyage report page shows the same result |
| `--post` | Also write the result to the pull request as the [evidence comment](#the-evidence-comment). The exit code is still the verdict's |

```bash
mso voyage ready VOY-MYPROJ-2026-0042          # read it at the terminal
mso voyage ready VOY-MYPROJ-2026-0042 --post   # and put it on the PR
mso pr ready --json                            # a role or script, from the voyage branch
```

The Hub's voyage report page has a **Ship gate** section. It checks when you click **Check ship
gate** (and **Check again**), not when the page loads. The Hub's answer is held for 60 seconds per
voyage tip.

---

## Reading the result

An example (the details are illustrative):

```
NOT READY — VOY-MYPROJ-2026-0042  PR 118 @ 3f9a1c07b2de
https://github.com/acme/app/pull/118
failing: 2 CI on current tip (FAIL), 5 Security (FAIL)

 #  Gate                  Status   Summary
 1  Voyage finished       PASS     4 of 4 orders complete
 2  CI on current tip     FAIL     1 check failing: pytest (3.13)
 ...
Verdict: NOT READY (evaluated 2026-11-19T09:12:44Z)
```

- The **first line** is the verdict, the voyage, the PR number and the first 12 characters of the
  tip commit. The verdict is for that tip. A result for a different tip is stale.
- When the verdict is NOT READY, the next line names the **failing gates**.
- Under each gate that did not clear, evidence lines name the order and the report or check behind
  the status.

| Status | Meaning |
|--------|---------|
| `PASS` | The evidence was read and it passes |
| `FAIL` | The evidence was read and it does not pass. This blocks the verdict |
| `UNKNOWN` | There was nothing to read (no checks reported, a provider that does not report mergeability, no recorded result). **It is never treated as a pass** |
| `SKIPPED` | The check could not be made: offline mode, or the provider could not be reached. Blocks the verdict |
| `N/A` | The gate does not apply (for example, no order of the voyage has a security step) |

A NOT READY verdict is a prompt to look, not a final ruling. Run the command again after you fix
the named gate; the evidence is read afresh each time.

---

## The evidence comment

`--post` writes the result to the voyage's pull request as **one comment per voyage**. The same
comment is edited in place when the result changes, so the PR never collects a trail of them.

The comment:

- starts with a hidden marker line that Maestro uses to find its own comment, then a heading
  `Ship gate: READY` or `Ship gate: NOT READY`;
- names the voyage, the PR, the tip commit and the time it was evaluated;
- says **Not ready because:** and lists the failing gates, or **All six gates pass.**;
- carries the six-row gate table (the same rows as the terminal output);
- has a collapsible **What blocks it** section with the evidence for each failing gate;
- has an **Orders** section: one line per order with its acceptance-criteria, QA and security
  status and the final reports behind them. Report paths are relative to the `.mso/` artefact
  directory. They are file names to look up, not links;
- ends, always, with **The Captain merges.** The comment is evidence only.

How to use it: read the verdict and the table. If it says READY, the decision is yours and the
evidence is all on the page. If it says NOT READY, the **What blocks it** section names what to fix.
When the tip commit moves, the comment is re-evaluated and edited, so the tip named in the footer is
the one the verdict is for. If you resolve a review thread or update a report without pushing a new
commit, run `mso voyage ready VOY-ID --post` to refresh the comment.

On GitHub, only a comment written by the account Maestro posts as is ever edited.

### When it is posted

- You can post at any time with `--post`. A **draft** PR is never posted to (the result is reported
  as skipped).
- The dispatcher posts for you once the voyage has finished, the PR is no longer a draft and its CI
  has settled, **once per tip commit**. If CI is still running when you post by hand, the
  dispatcher posts again when it settles.
- When a voyage has a REL step, REL runs `mso pr ready --post` after it pushes its fixes.
- A failed post never holds up the voyage. It is logged as a warning (`SHIP_EVIDENCE_FAILED` in
  `.mso/logs/lifecycle.log`) and retried later.
- If REL recommends the PR as ready while the gate says NOT READY, Maestro logs a warning
  (`SHIP_GATE_DISAGREES`) once per tip. Nothing is held. It is a prompt for you to look.
- Providers that cannot post comments (Bitbucket, and the `none` provider) report `UNSUPPORTED` and
  Maestro notes it once. Use the terminal output instead.

---

## Re-landing a stale or conflicting voyage

```
mso voyage reland VOY-ID [--dry-run] [--json]
```

A finished voyage can wait a long time for review while `main` moves on. When its PR is
conflicting, or has sat open longer than [`completion.shipGate.staleDays`](#settings), re-land it:
the voyage's finished work is re-created on a fresh branch cut from the current default branch.

`mso voyage reland` files **one new voyage with one order**:

- the order is a **security** order if any original order had a security step, otherwise a **bug**
  order;
- its roles are BLD and TST, plus SEC when the original had it;
- it records which voyage and PR it supersedes.

**It never closes the original PR.** Closing it is your step, once the re-land has merged. When the
re-land's PR merges, `mso voyage reconcile` records the supersession on the original voyage.

`--dry-run` shows the voyage and order that would be filed and writes nothing. With `--json`, a dry
run prints `voyageId: null`.

The command refuses, with a hint, a voyage that is unfinished, already merged, already superseded,
multi-repo, or has no PR. It also refuses a second re-land of the same voyage.

When the resident LEAD sees a stale voyage it **proposes** this command and waits for you. See
[Patrol checks and the LEAD](#patrol-checks-and-the-lead).

---

## Holding an order until another voyage has merged

```
mso order create "Title" --type FTR --project MYPROJ --requires voy:VOY-MYPROJ-2026-0042
```

`--requires` takes order ids that must be complete, pull request numbers that must be merged
(`#509` or `pr:509`), and now **voyages that must have merged** (`voy:VOY-…`; a bare `VOY-…` id also
works, in any case). Separate several with commas or repeat the flag.

The order is held, and shown as waiting on dependencies, until the voyage has merged. A voyage whose
work shipped under a re-land counts as merged. If Maestro cannot tell whether the voyage merged (for
example, offline), the order stays held and says `state unknown — cannot verify`. The other hold
notes are `unknown voyage — no manifest on the plane` and `not merged — <state>`.

The same `requires` key works in a decomposition manifest. When the hold ends, `REQUIRES_VOYAGE_MET`
is logged once.

### The held voyage's branch is brought up to date

When the awaited voyage merges, the held voyage's branch is out of date with the default branch. At
release, Maestro fast-forwards the held voyage's branch **only when it has no commits of its own
yet**, with an ordinary push, never a forced one. It does nothing while a crew is working on that
voyage. If the branch already has commits, Maestro leaves it alone and the order gets a note telling
the crew to merge the default branch in (`git merge origin/<default>`), never to rebase or force-push.

The result is logged as `VOYAGE_BRANCH_FAST_FORWARDED` or `VOYAGE_BRANCH_FF_SKIPPED reason=…`. The
reasons are `live-crew`, `offline-mode`, `outbox-owned`, `branch-absent`, `up-to-date`,
`commits-ahead`, `fetch-failed`, `push-rejected`, `error`, `no-voyage` and `no-voyage-branch`.
Only `fetch-failed`, `push-rejected` and `error` are logged as warnings.

---

## Planning a release

```
mso release plan [--version X.Y.Z] [--json] [--write]
```

A read-only report on what a release would contain and whether you can cut it now. It writes
nothing unless you add `--write`, which saves `reports/release/RELEASE-PLAN-<version>.md` in the
artefact directory. Run it from the repository being released, like the other `mso release`
commands.

The report has five parts:

1. **What is unreleased.** Each merged voyage records a release note when its PR merges. The report
   lists those notes by section: Security, Added, Fixed and Docs. It also lists commits since the
   last `v*` tag that did not come from a voyage, with their PR numbers. A voyage may set its own
   section and mark itself `breaking` or `behaviour-change`.
2. **A recommended version, and the rule that fired.** Any breaking change recommends a major
   version; any feature or behaviour change a minor version; otherwise a patch. `--version` plans for
   a version you choose instead, and the report notes that you overrode the recommendation.
3. **Scope options.** Finished voyages whose PR is not yet merged, each with its ship-gate verdict,
   and voyages still in flight with what each is waiting on. Parked voyages are counted, not listed.
   The report does not recommend a scope: that is your call.
4. **Preconditions**, each `PASS`, `FAIL` or `UNKNOWN`: `fleet-idle`, `main-ci`, `last-preflight`,
   `runtime-vs-main` and `scope-ready`. "Could not read CI" and "no checks" are `UNKNOWN`, never green.
5. **The release chain**, written out as text, with each step that only you run marked as yours.

`mso release preflight` now has a seventh check, `release-notes`. It fails when there are unreleased
notes but the changelog section would be empty, when a note's merge commit is not on the default
branch or is not known to this repository, or when the current version's changelog section has no
entries. See [CLI-REFERENCE.md](CLI-REFERENCE.md#mso-release).

`mso release cut VERSION --execute` also writes the new `## [VERSION] — <date>` section into
`CHANGELOG.md` from those notes. Highlights come first, then Security, Added, Fixed and Docs, then
"Other changes" for commits that did not come from a voyage. A dry run previews the section and
writes nothing. A changelog that already has that version's section is refused before any file
changes.

In the report's install-refresh step, the private-index command uses `--index-url`, never
`--extra-index-url`.

---

## Release steps stay yours

Nothing in this guide merges a pull request, cuts or tags a release, publishes a package, or deploys
a website. Those are always your steps, on every provider and tier:

| Step | Who |
|------|-----|
| Merge the voyage PR | **You** |
| `mso release cut VERSION --execute` (version bump, changelog section, release PR) | **You** |
| Merge the release PR | **You** |
| Tag the release and push the tag | **You** |
| Publish the package | **You** (the publish workflow runs on your tag) |
| Deploy the website or docs | **You** |

`mso release plan`, `mso release preflight`, `mso pr ready` and `mso voyage ready` never run any of
them.

---

## Settings

| Key | Type | Default | Meaning |
|-----|------|---------|---------|
| `completion.shipGate.staleDays` | int 1–60 | `5` | Days a finished voyage's PR may stay open before patrol calls it stale. A value outside 1–60 is **refused**, not clamped. A hand-edited invalid value in `workspace.json` is read as `5` |

```bash
mso settings set completion.shipGate.staleDays 10
```

See [SETTINGS.md](SETTINGS.md).

---

## Patrol checks and the LEAD

Two checks in `mso doctor` (see [PATROL.md](PATROL.md)) watch finished voyages whose PR is still
open:

| Check | Severity | Fires when |
|-------|----------|------------|
| `voyages.pr-stale` | high | The voyage is finished, its PR is still open, and either more than `completion.shipGate.staleDays` days have passed since its last order completed, or the PR is conflicting (this one fires at once). Skipped offline and when no SCM provider is configured |
| `voyages.ship-ready` | low | The ship gate says READY. The finding reads "VOY-X is READY to merge. The Captain's go is needed." The result is remembered per tip commit for 15 minutes by default |

Both take the parameters `maxAgeDays` (default 90) and `maxVoyages` (default 20). No shipped
provider reports which files conflict or how far behind a PR is, so a stale finding says "not
reported by the provider" for those details.

The resident LEAD ([LEAD.md](LEAD.md)) acts on the stale finding with the `voyage.reland` action. Its
default band is **propose and wait**: the LEAD proposes `mso voyage reland VOY-ID` and you run it.
A LEAD `must_not` item containing "re-land" keeps it at propose-and-wait whatever else is
configured. `voyages.ship-ready` maps to no action. It tells you the voyage is ready and nothing
more.

---

## Offline mode

While [offline mode](OFFLINE.md) is on, `mso pr ready` and `mso voyage ready` still run. They do
not contact the provider, so gates 2 and 6 (and the review-thread part of gate 4) report `SKIPPED`
and the verdict is always NOT READY (exit `1`). `--post` records the comment in the outbox instead
of posting it. On replay the gate is evaluated again and the comment written fresh; if the PR is
then a draft or its CI is still running, the entry is dropped and the dispatcher posts once CI
settles.
