# Egress control — what Maestro enforces, and what you must add

Maestro can restrict where its own processes connect. It **cannot** restrict where a crew
connects. This page says exactly where that line is, and which operating-system control you
need for a real network boundary.

Related: [AIR-GAPPED.md](AIR-GAPPED.md) (install and licence on a restricted machine),
[OFFLINE.md](OFFLINE.md) (offline mode), [ENTERPRISE-SETUP.md](ENTERPRISE-SETUP.md#2-network-requirements)
(the hosts a fleet needs), [LOCAL-MODELS.md](LOCAL-MODELS.md).

## Contents

- [The short version](#the-short-version)
- [Modes](#modes)
- [What Maestro enforces](#what-maestro-enforces)
- [What Maestro does not enforce](#what-maestro-does-not-enforce)
- [Crew-side measures](#crew-side-measures)
- [The OS-level control you must add](#the-os-level-control-you-must-add)
- [Checking what is allowed](#checking-what-is-allowed)

---

## The short version

> On its own, `restrictive` or `air-gapped` mode does **not** stop a crew from reaching the
> network. It is a best-effort, application-layer control over Maestro's own processes.

A crew is a separate Claude Code process, and everything it runs (shell commands, `git`,
`npm`, MCP servers) is another process again. None of them is filtered by Maestro's egress
setting. If you need a guarantee that nothing on the machine reaches an unapproved host, add
one of the [OS-level controls](#the-os-level-control-you-must-add) below.

---

## Modes

Egress modes are an **Enterprise** feature, set in `.mso/config/workspace.json`. A workspace
without `"enterprise": true` is always `permissive`, whatever `dataResidency.mode` says.

```json
{
  "enterprise": true,
  "dataResidency": {
    "mode": "restrictive",
    "allowedDestinations": ["api.anthropic.com", "*.slack.com"],
    "proxy": { "url": "http://proxy.your-org.internal:8080" }
  }
}
```

An `MSO1.` licence token is verified on the machine and needs no licence host in this list.
Only a legacy schema-1 licence key contacts `api.polar.sh`.

| Mode | Maestro's own processes may connect to |
|---|---|
| `permissive` (default) | anything — nothing is checked |
| `restrictive` | hosts matching `allowedDestinations` (shell-style patterns such as `*.example.com`; an IP address or `10.0.0.*` also works) |
| `air-gapped` | loopback only (`localhost`, `127.0.0.0/8`, `::1`) |
| offline mode (`mso offline on`) | loopback and the hosts your local model backends name — see [OFFLINE.md](OFFLINE.md) |

If `workspace.json` cannot be read, is not valid JSON, or has a `dataResidency` that is not
an object, an unrecognised `mode` (a misspelling such as `"airgapped"` included) or an
`allowedDestinations` that is not a list, Maestro keeps the mode it is already enforcing and
logs a warning; a process that starts with such a file runs `air-gapped` until the file is
fixed. If the file briefly disappears, the current mode is kept for one more cycle. While a
`restrictive` or `air-gapped` mode is in force, an empty or cut-off `workspace.json` also
keeps it, with a warning. A file that mentions `dataResidency` or an `"enterprise"` key (even
`"enterprise": false`) and is not valid JSON — a UTF-8 byte-order mark counts as invalid —
makes a process that starts with it run `air-gapped`. In the Hub, while one workspace's file is invalid, a
change in another workspace can still tighten the Hub's mode, but nothing loosens it until
the file is fixed.

In every mode, loopback and local (Unix-domain) sockets are always allowed: the Hub, health
checks and local model endpoints talk over them, and none of that is egress.

`proxy` routes Maestro's HTTP requests through your proxy. How the proxy is checked depends
on the mode:

- **`restrictive`:** Maestro's own HTTP requests are checked against their **destination**
  before they are sent, and a connection to the configured `proxy` host is allowed. Any other
  program code in a Maestro process that opens a tunnel through the proxy is checked only
  against the proxy, not against where the tunnel leads. For proxied traffic, the destination
  is enforced by **your proxy's own allowlist** — configure one.
- **`air-gapped` and offline mode:** no proxy is reachable. These modes allow loopback only
  (plus, in offline mode, your local model hosts), so a proxy setting cannot open a way out.
- **A proxy from the environment** (`HTTPS_PROXY`, `HTTP_PROXY`, or the operating system's
  proxy setting) is **not** allowed by Maestro's check in any mode. If Maestro must reach the
  network through a proxy, set it as `dataResidency.proxy` (or add its host to
  `allowedDestinations`).

A denied connection fails with an `Egress denied` error naming the host and the patterns that
were checked. Add the host to `allowedDestinations` if it should be allowed.

The check is made per **IP address**. When an allowed host name resolves to an address, that
address is allowed, so any other site served from the same address (common on shared CDN
front ends) is reachable too. If you need host-level control, send traffic through a proxy
that enforces a host allowlist.

---

## What Maestro enforces

In `restrictive`, `air-gapped` and offline mode, every network connection made by a Maestro
process is checked against the mode — not only its HTTP requests, but any socket the process
opens, including name lookups:

- the dispatcher (`mso dispatch`)
- the resident LEAD (`mso lead start`)
- the Hub (`mso hub start`)
- `mso` CLI commands
- the Slack bridge (poller and bot)

Each of these applies the workspace's mode when it starts, before it opens any connection.
The dispatcher, the resident LEAD and the Hub read `workspace.json` again on every cycle, so a
change to `dataResidency` takes effect without a restart. A `mso` command uses the workspace
it is run in (the current directory, or `MAESTRO_DIR`).

The Hub is one process for every workspace on the machine, so the **strictest** mode among
the registered workspaces applies to it. If any workspace is `air-gapped`, the Hub is
`air-gapped`. Otherwise, if any is `restrictive`, the Hub is `restrictive` and may reach the
hosts allowed by **any** of the `restrictive` workspaces. Its proxy is used only when every
`restrictive` workspace that sets one sets the same proxy.

With `restrictive` or `air-gapped` mode on, Maestro's own calls to outside services (the
licence server, GitHub, Anthropic, update checks) need their hosts in `allowedDestinations`,
or they fail as denied.

The Slack bridge bot opens its Socket Mode connection to a host Slack names at connect time
(`wss-primary.slack.com` and siblings), not to `slack.com`. To run the bot in `restrictive`
mode, allowlist `*.slack.com`. In `air-gapped` mode the bridge cannot run.

---

## What Maestro does not enforce

| Not covered | Why |
|---|---|
| **Crews** — the Claude Code CLI and every command a crew runs (`curl`, `git push`, `npx`, a script that opens a socket) | Each crew is its own operating-system process. Maestro's check lives inside Maestro's processes and does not travel to a child. |
| **MCP servers** a crew starts | Child processes of the crew. |
| **`git`, `gh`, `npm`/`npx`** run by Maestro itself | Separate programs. In offline mode, Maestro refuses or defers its own remote `git`/`gh` calls instead (see [OFFLINE.md](OFFLINE.md)); in `restrictive`/`air-gapped` mode it does not. |
| **Native extensions** that open sockets without going through Python's networking | Below the layer Maestro checks. |

Maestro does **not** try to spot network commands inside a crew's shell commands. Pattern
matching on command text is easy to evade, and offering it as a control would overstate what
it does.

---

## Crew-side measures

Two small measures reduce what a crew does by default. Neither is a network boundary.

- **`air-gapped` mode removes the web tools.** Crews on an `air-gapped` workspace are launched
  without `WebFetch` and `WebSearch`, as they already are in offline mode. `restrictive` mode
  keeps them; restrict them per role if you need to.
- **`proxy` is passed to crews.** When `dataResidency.proxy` is set and the mode is
  `restrictive` or `air-gapped`, crews are launched with `HTTPS_PROXY` / `HTTP_PROXY` pointing
  at it, and `NO_PROXY=localhost,127.0.0.1,::1`. A variable you already set yourself is left
  as it is. Tools that honour these variables (Claude Code, `git`, `gh`, `curl`, `npm`) then
  go through your proxy, and the proxy can enforce your allowlist. A crew can still unset them
  — combine this with a firewall rule that allows **only** the proxy. The URL is passed as
  written; if your proxy needs credentials, put them where your proxy clients expect them.

---

## The OS-level control you must add

For a real boundary, enforce it below every process on the machine. Pick one.

### Option A — allow only your egress proxy (recommended)

1. Run an egress proxy that enforces your allowlist (a forward proxy with a host allowlist, or
   your organisation's secure web gateway).
2. Block all other outbound traffic from the Maestro host (or from the account crews run as),
   allowing only the proxy, DNS to your resolver, and loopback.
3. Set `dataResidency.proxy` so Maestro and crews use the proxy.

Anything that ignores the proxy settings then fails at the firewall instead of leaking.

### Option B — default-deny firewall with an allowlist

**Windows (Defender Firewall, elevated PowerShell)** — block outbound by default and allow the
hosts' addresses you need:

```powershell
Set-NetFirewallProfile -Profile Domain,Private,Public -DefaultOutboundAction Block
New-NetFirewallRule -DisplayName "Maestro: proxy" -Direction Outbound -Action Allow `
  -RemoteAddress 10.0.0.10 -RemotePort 8080 -Protocol TCP
New-NetFirewallRule -DisplayName "Maestro: DNS" -Direction Outbound -Action Allow `
  -RemoteAddress 10.0.0.2 -RemotePort 53 -Protocol UDP
```

Windows Firewall rules match addresses, not host names. For hosts behind CDNs (such as
`api.anthropic.com`), allow your proxy rather than the host.

**Linux (nftables)** — run crews under a dedicated user and restrict that user only:

```bash
nft add table inet maestro
nft add chain inet maestro out '{ type filter hook output priority 0; policy accept; }'
nft add rule inet maestro out meta skuid maestro-crew oif lo accept
nft add rule inet maestro out meta skuid maestro-crew ip daddr 10.0.0.10 tcp dport 8080 accept
nft add rule inet maestro out meta skuid maestro-crew udp dport 53 ip daddr 10.0.0.2 accept
nft add rule inet maestro out meta skuid maestro-crew drop
```

(The `iptables` equivalent uses `-m owner --uid-owner maestro-crew`.)

**macOS** — use `pf` anchors or your MDM's network content filter to block outbound traffic
except to the proxy.

Replace the example addresses with your own, and test the rules on a non-production machine
before you rely on them.

### Containers

Running crews in containers with no network, or on an internal network whose only exit is your
proxy, is planned and not yet available. Until it is, use Option A or B.

---

## Checking what is allowed

```bash
mso data-flow                       # destinations for the workspace's current mode
mso data-flow --mode restrictive    # preview another mode
mso data-flow --mode offline
```

The diagram lists the destinations **Maestro's own processes** may reach. It does not describe
crew traffic; that is bounded only by the OS-level control you add.
