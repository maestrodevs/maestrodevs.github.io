# Maestro — Enterprise Setup Guide

This guide covers deploying Maestro for multi-team enterprise use: network requirements, data residency, compliance notes, and the current status of SSO (not yet available).

> **This guide applies to Team and Enterprise tier only.** For individual and small-team setup at
> community or pro tier, see [GETTING-STARTED.md](GETTING-STARTED.md). Not sure which tier you're
> on? Start at [START-HERE.md](START-HERE.md).
> For the enforced tier limits (community/pro/team/enterprise), see [LICENCE.md](LICENCE.md#tier-limits-enforced-in-code-not-just-advertised).
>
> **Getting a device onboarded quickly?** The day-to-day onboarding path for an individual
> engineer — activate licence, run `mso setup`, let the org's enrolment profile do the rest — is
> [ENTERPRISE-QUICKSTART.md](ENTERPRISE-QUICKSTART.md). *This* guide covers the surrounding
> deployment concerns: network, residency, compliance, and the governed-mode/break-glass mechanics
> in [§6](#6-governed-mode-and-break-glass). The admin-side authoring work (signing a policy
> bundle, authoring the enrolment profile devices consume, unattended imaging) is
> [ENTERPRISE-ADMIN-GUIDE.md](ENTERPRISE-ADMIN-GUIDE.md).
>
> **Version scope:** This guide describes Maestro **v5.22.0**. Licence behaviour (activation, expiry, offline grace) is documented in [LICENCE.md](LICENCE.md), which is authoritative if the two ever disagree.

---

## Contents

1. [Overview](#1-overview)
2. [Network Requirements](#2-network-requirements)
3. [Multi-Team Deployment](#3-multi-team-deployment)
4. [Data Residency](#4-data-residency)
5. [Compliance Notes](#5-compliance-notes)
6. [Governed Mode and Break-Glass](#6-governed-mode-and-break-glass)
7. [SSO and SCIM: not yet available](#7-sso-and-scim-not-yet-available)
8. [Licence Key Management](#8-licence-key-management)
9. [Air-Gap and Restricted Networks](#9-air-gap-and-restricted-networks)
10. [Deployment Checklist](#10-deployment-checklist)
11. [Onboarding via an Enrolment Profile](#11-onboarding-via-an-enrolment-profile)

---

## 1. Overview

Maestro is a local orchestration framework. The core system runs entirely on the developer's machine or CI host — there is no Maestro application server, no data sent to Maestro infrastructure, and no persistent cloud state.

**What runs locally:**
- The dispatcher (`mso dispatch`)
- The patrol monitor (`mso status`)
- All crew Claude Code sessions
- All workspace state (orders, voyages, plans, usage records)

**What leaves the local machine:**
- Claude Code API calls to Anthropic (via `ANTHROPIC_API_KEY`)
- Git operations (push/pull to your own source repositories)
- Licence validation: an `MSO1.` licence token is verified on the machine with no network call; a legacy `adm_lic_…` key is checked online against the licence backend (`api.polar.sh`). See [Section 9](#9-air-gap-and-restricted-networks)

Enterprise deployments typically involve:
- One Maestro workspace per team or department
- Shared source repositories accessed via crew managed clones
- Centralised API key management
- Workspace backup to a shared store

---

## 2. Network Requirements

### Outbound connections required

| Destination | Port | Purpose | Required |
|-------------|------|---------|---------|
| `api.anthropic.com` | 443 (HTTPS) | Claude Code API (crew sessions) | Yes — unless crews run on AWS Bedrock |
| `bedrock-runtime.<region>.amazonaws.com` | 443 (HTTPS) | Crew sessions, when the workspace's model backend is AWS Bedrock | Bedrock workspaces only |
| `sts.<region>.amazonaws.com` | 443 (HTTPS) | AWS credential check before dispatch, when the model backend is AWS Bedrock | Bedrock workspaces only |
| `github.com` (or your Git host) | 443 / 22 | Repo clone and push for crew work | Yes |
| `pypi.org` / GitHub | 443 | pip install (install time only) | Install only |

A workspace configured for AWS Bedrock also needs whatever your AWS sign-in
method requires — for AWS IAM Identity Center that is your SSO start URL and
the regional OIDC endpoint, reached from a **browser on the operator's
machine**, not from the dispatcher. See
[MODEL-BACKENDS.md](MODEL-BACKENDS.md).

### Optional / non-mandatory

No other outbound destination is required. Integrations you choose to enable (the Slack bridge, audit anchors, an external secrets provider, a legacy-key licence check) connect to services named in your own configuration.

### Firewall configuration

At minimum, ensure outbound HTTPS to `api.anthropic.com` is permitted from the host(s) running Maestro — or, on a workspace whose model backend is AWS Bedrock, to the Bedrock and STS endpoints for your region instead. All Claude Code API traffic uses HTTPS (TLS 1.2 or later).

If your organisation uses a TLS-inspection proxy, ensure the proxy CA certificate is trusted on the Maestro host. Claude Code uses the system certificate store.

**Your firewall is the egress boundary for crews.** `dataResidency` modes (`restrictive`, `air-gapped`) check the connections Maestro's own processes make; they do not filter crews or the commands crews run. For a guarantee, block outbound traffic at the OS or network layer and allow only what you need (ideally only your egress proxy). See [EGRESS-CONTROL.md](EGRESS-CONTROL.md).

### Proxy support

Set standard proxy environment variables before running Maestro commands:

```bash
export HTTPS_PROXY=https://proxy.your-org.internal:8080
export HTTP_PROXY=http://proxy.your-org.internal:8080
export NO_PROXY=localhost,127.0.0.1,your-internal-git-host
```

These are inherited by all crew Claude Code subprocesses automatically. On an Enterprise workspace in `restrictive` or `air-gapped` mode, `dataResidency.proxy` is also passed to crews as these variables when you have not set them yourself — see [EGRESS-CONTROL.md § Crew-side measures](EGRESS-CONTROL.md#crew-side-measures).

---

## 3. Multi-Team Deployment

### One workspace per team (recommended)

Each team maintains its own Maestro workspace containing that team's projects, orders, and voyages. This provides clear ownership boundaries and prevents cross-team order interference.

```
/workspaces/
├── team-frontend/          # Frontend team workspace
│   ├── .mso/
│   └── ...
├── team-backend/           # Backend team workspace
│   ├── .mso/
│   └── ...
└── team-platform/          # Platform team workspace
    ├── .mso/
    └── ...
```

### Shared source repositories

Each workspace references one or more source repositories via `projects.json`. Multiple teams can reference the same source repository — each workspace maintains its own voyage branch namespace to avoid conflicts.

Voyage branches are named `voyage/VOY-<PROJECT>-<YEAR>-<SEQ>-<slug>`, and the sequence is allocated per workspace. Two workspaces that register the same project acronym can therefore mint the same voyage ID against the same repository. Give each team's workspace a **distinct project acronym** to keep their branch namespaces apart.

> **Not yet available:** a configurable per-team branch pattern. `mso init` writes a `voyageBranchPattern` key into `projects.json`, but nothing reads it today, so editing it changes no branch name.

### CI/CD integration

Maestro can run in CI for automated order dispatch. Set the following in your CI environment:

```bash
# Required
export ANTHROPIC_API_KEY=<your-key>

# Licence: an MSO1. token, supplied from your CI secret store
export MAESTRO_LICENCE_KEY=MSO1.<your-token>
```

Then run `mso licence activate` once in the job (with no argument it reads `MAESTRO_LICENCE_KEY`). An `MSO1.` token is verified on the runner with no network call, so it suits ephemeral and restricted CI hosts. `MAESTRO_SKIP_AUTH` is a test-only switch and has no effect on a released install. Do not rely on it to run CI.

### Resource limits

Each crew runs a Claude Code subprocess. Plan for:

| Teams | Max concurrent crews per team | Concurrent Claude sessions (worst case) |
|-------|-------------------------------|-----------------------------------------|
| 1 | 5 | 5 |
| 3 | 5 each | 15 |
| 5 | 5 each | 25 |

Anthropic API rate limits apply per API key. For large multi-team deployments, consider separate API keys per team or per workspace to distribute rate limits.

---

## 4. Data Residency

### Where workspace data lives

All Maestro workspace data is local to the machine or file server where the workspace is stored. Maestro does not transmit workspace content to any Maestro-operated service.

| Data type | Location | Leaves the machine? |
|-----------|----------|---------------------|
| Orders, voyages, plans | `.mso/` directories | No (unless you back up to cloud storage) |
| Crew prompts and context | `.mso/crews/crewN/` | No |
| Token usage records | `.mso/usage/` | No |
| Licence key | `~/.maestro/licence.json` | No |
| Source code changes | Your Git repositories | Yes (pushed to your Git host) |
| Claude API requests | Sent to `api.anthropic.com`, or to AWS Bedrock in your own account and region | Yes — see below |

### Claude API data handling

Crew sessions send prompts (including order content and code context) to the Anthropic API. Anthropic's data handling policies apply. Review [Anthropic's privacy policy](https://www.anthropic.com/privacy) for details on:

- Data retention for API requests
- Training data opt-out (Enterprise API agreements)
- Data residency options (where available)

For workspaces containing sensitive code or data, review what context is included in crew prompts. Orders, file reads, and code snippets are sent as part of crew sessions.

### Running crews on AWS Bedrock

A workspace can be configured to run its crews against **AWS Bedrock** in your
own AWS account and region instead of the direct Anthropic API — per workspace,
so one machine can host projects on different backends. Crew prompts then travel
to your Bedrock region under your own AWS agreement, and are billed by AWS.

```bash
mso setup                                   # [STEP 2b] Model backend
# or
mso providers set model bedrock --config region=<your region> --config awsProfile=<profile>
mso providers show model                    # read it back, with availability
```

Points that matter at review time:

- **No AWS credential is ever stored by Maestro.** The Bedrock backend has no
  configuration field for an access key, secret key, session token or bearer
  token. Credentials come from the AWS credential chain on the dispatcher host —
  established by your operator with `aws sso login --profile <name>` (or
  `aws login`), which opens a browser and creates a time-boxed session.
- **Maestro never authenticates on your behalf.** When the session expires it
  holds new crew dispatch, leaves running crews untouched, records
  `MODEL_BACKEND_UNAVAILABLE` in the lifecycle log with the exact remedy, and
  resumes on its own once an operator has signed back in.
- **`workspace.json` is git-tracked.** `awsProfile` holds a profile *name*, not
  a secret; treat everything else in the block as visible to everyone with
  repository access.
- **Cost reporting changes.** Maestro's built-in rate table is Anthropic's
  first-party one, so on Bedrock `mso usage` reports `unpriced` rather than a
  figure computed from the wrong rate card. Supply your negotiated rates via
  `pricingOverrides` if you need dollar figures; token counts are accurate
  either way.
- **The `WebSearch` tool is not served by Bedrock**, so planning crews on a
  Bedrock workspace have `WebFetch` and nothing else for external lookups. This
  is announced in the Planner role's own definition.
- **Bedrock is Enterprise-tier.** Below that, the backend is not offered.

Full guide: [MODEL-BACKENDS.md](MODEL-BACKENDS.md).

### Backup data residency

`mso backup` creates ZIP archives in a local directory by default. If you copy these to cloud storage (S3, Azure Blob, etc.), the residency of backup data is governed by your cloud storage configuration — not by Maestro.

---

## 5. Compliance Notes

### Source code and IP

Maestro crews read and write source code in managed clones. All output is committed to your own Git repositories. No source code is retained by Maestro beyond the local crew working directories (which are wiped by `mso cleanup`).

### Audit trail

Maestro maintains the following audit-relevant records locally:

| Record | Location | Contents |
|--------|----------|---------|
| Order lifecycle | `.mso/orders/` | Status, timestamps, completion metadata |
| Voyage history | `.mso/voyages/` | Voyage ID, orders, completion status |
| Crew activity | `.mso/crews/crewN/activity.jsonl` | Per-tool-call structured log |
| Token usage | `.mso/usage/orders/` | Per-order token breakdown and cost |
| Lifecycle log | `.mso/logs/lifecycle.log` | Crew starts, completions, role transitions |

The records above are plain workspace files that you can collect with your own tooling. On the Enterprise tier, the separate hash-chained audit log can be exported with `mso audit export` (it covers privileged actions, not these order and voyage records). See `mso usage --report` for token and cost reporting.

### Secrets and credentials

Maestro itself does not store secrets. The `ANTHROPIC_API_KEY` is passed as an environment variable to crew subprocesses. Do not commit your API key to workspace files or orders.

#### Crew permission mode

Crews run Claude Code headless (`claude --print`), where nobody can answer a permission prompt, so Maestro chooses a permission mode in which nothing can prompt. The choice is `claudeCli.permissionMode` in `.mso/config/workspace.json` (`mso settings set claudeCli.permissionMode <value>`):

| Value | Crews launch with | When |
|---|---|---|
| `auto` (default) | `--dangerously-skip-permissions` — unless this machine's Claude Code managed policy disables bypass mode, or the CLI recently refused it, then the `dontAsk` row | Most workspaces |
| `dontAsk` | `--permission-mode dontAsk` plus an explicit `--allowedTools` list of the built-in tools crews use | Your organisation disables bypass mode through a route Maestro cannot read (server-managed settings from the claude.ai console) |
| `bypass` | `--dangerously-skip-permissions` | Explicit opt-in; still switches to `dontAsk` if the managed policy disables bypass, because the CLI would refuse it |

`auto` reads the managed policy the way Claude Code ranks it (the CLI's default `managedSourcesBehavior: "first-wins"`: the highest-ranked source carrying any policy key supplies the whole policy):

1. Server-managed settings (claude.ai console / apps gateway) — **not readable by Maestro**; see "refused launches" below.
2. MDM / OS policy — the `Settings` value under `HKLM\SOFTWARE\Policies\ClaudeCode` (Windows) or the `com.anthropic.claudecode` plist in `/Library/Managed Preferences` (macOS).
3. The managed-settings file — `C:\Program Files\ClaudeCode\managed-settings.json` (Windows), `/Library/Application Support/ClaudeCode/managed-settings.json` (macOS), `/etc/claude-code/managed-settings.json` (Linux) — merged with its `managed-settings.d/*.json` drop-ins in name order (a later file wins per key).
4. `HKCU\SOFTWARE\Policies\ClaudeCode` — only when no source above exists at all.

If the highest-ranked source sets `managedSourcesBehavior: "merge"`, sources 2 and 3 both count and `permissions.disableBypassPermissionsMode: "disable"` in either wins. The `mso setup`/dispatch preflight smoke test and the LEAD chat responder use the same decision as the crews.

**Refused launches.** A launch the CLI refuses for bypass mode (a policy Maestro could not read) is a machine-level fault: the order is released without spending a requeue attempt, the refusal is recorded in `.mso/state/claude-permissions.json`, and for up to 4 hours `auto`/`bypass` resolve to `dontAsk`. Only the Claude CLI's own refusal message on its error output counts — never text from a crew's reply. The record ends sooner when the CLI's cached copy of the server-managed settings is refreshed and no longer disables bypass mode, or when you set `claudeCli.permissionMode` to `bypass` after the refusal; the next launch then tries bypass again, and a CLI that still refuses simply records it again at no requeue cost. `mso doctor` reports a record in force (`config.claude-permissions`); `mso claude-permissions status` shows it and `mso claude-permissions reset` clears it once the policy is fixed. While new dispatch is held for a permission fault, the hold survives a dispatcher restart. If `dontAsk` is required but the installed CLI does not support it, no crew is launched and new dispatch is held until Claude Code is upgraded.

What this means for restricting crews:

- **Bypass mode (the default):** Claude Code's allow/ask rules do **not** apply — every tool is allowed. The only restrictions are Maestro's per-role tool removals (e.g. SEC cannot use `Edit`), deny rules, and Maestro's own pretool hooks (branch guard, path guard). Adding `permissions.allow` rules to `.claude/settings.json` does nothing in this mode.
- **`dontAsk` mode:** Claude Code's permission rules apply. Anything not pre-approved is **denied**, not prompted; denials appear in the run's `permission_denials`. Deny rules — including scoped ones such as `Bash(rm:*)` — are honoured, so this mode is where `.claude/settings.json` deny rules can narrow what crews may do. MCP tools are not in Maestro's allow list: add `permissions.allow` rules for any a crew needs (e.g. `"mcp__github"` for every tool of that server) to `~/.claude/settings.json` or the repo's `.claude/settings.json`. Every denied tool is logged as a lifecycle `WARN` naming it, so a missing allow rule is never silent. Built-in tools are covered without any rule: besides Maestro's own list, crews are allowed every built-in tool the installed Claude CLI reports for its sessions (learned from each run). If a crew is still denied a built-in tool it was never allowed, the iteration fails with a lifecycle `ERROR` (`TOOL_DENIED`) instead of finishing as if nothing happened, and the retry allows the tool.
- **`allowManagedPermissionRulesOnly`:** if your managed policy also sets this, the CLI ignores Maestro's `--allowedTools`, and crews can use only what the policy itself allows. `mso doctor` reports this combination (`config.claude-permissions`); ask the policy owner to allow the tools crews need.

Claude Code's per-folder trust dialog does not apply to crews: it is skipped for `--print` runs, so a crew worktree never needs to be trusted interactively.

### GDPR and PII

If your orders or source code contain personal data, ensure your Anthropic API usage agreement covers the relevant data categories. Apart from crew reasoning (below), Maestro does not process or store PII independently — any PII in prompts is subject to Anthropic's API data handling terms.

**Crew reasoning.** With `reasoning.enabled` on (the default), Maestro stores each crew's summarised model reasoning under `<artefact root>/reasoning/`, and the crews' raw output files under `crews/` hold the same text unredacted. Either can repeat personal data a crew read. `mso identity rights export` / `forget` do **not** search these files: search and delete them yourself. Under `reasoning.storage: repo` the files are in git history, so erasure needs a manual history rewrite (`git filter-repo` or BFG, force-push, re-clone everywhere). If you may need to honour erasure requests, keep `reasoning.storage: local`. See [REASONING.md](REASONING.md#erasure-and-data-subject-requests).

---

## 6. Governed Mode and Break-Glass

Enterprise workspaces can run in **governed enforce mode** (`governance.governedMode: "enforce"` in `.mso/config/workspace.json`). This is Enterprise-only — the `governedMode` key is licence-tier gated where it is read, so setting it to `enforce`/`warn` on a community, Pro or Team workspace does not enable governed mode; it is ignored and Maestro prints why, rather than silently accepting the config. See [LICENCE.md](LICENCE.md#tier-limits-enforced-in-code-not-just-advertised). In enforce mode the guard-bypass escape hatches — `MAESTRO_BRANCH_GUARD_BYPASS` and `MAESTRO_PATH_GUARD_BYPASS` — are no longer honoured on their own. A bypass ("break-glass") is granted only when **all** of the following hold:

1. A justification is supplied via `MAESTRO_BREAKGLASS_REASON` (recorded in the audit log).
2. The caller is a **credential-backed / verified** identity (GitHub- or OIDC-verified) in an **enterprise** workspace.
3. That verified caller holds the `governance.breakglass` capability in the identity ACL.
4. The tamper-evident audit record lands durably first.

Every grant and refusal is written to the hash-chained audit log with the actor, timestamp, and reason.

### Break-glass requires a **signed** identity ACL

In enforce mode the identity ACL (`.mso/identity/access.json`) is trusted only when the identity integrity manifest (`.mso/identity/integrity.json`) is an **Ed25519-signed manifest** whose signature verifies against a key pinned **outside the workspace**. This closes a local-write forgery hole: an unsigned, self-adjacent manifest — the kind an on-host attacker could hand-write alongside a forged `access.json` — is refused.

> **Consequence:** the `mso identity` mutation commands (`add-user`, `add-group`, `set-group`, `acl set`, …) leave the manifest **unsigned**. Until the manifest is signed with your org key, the ACL is not trusted in enforce mode, so **break-glass will never grant** (and enterprise identity loads fail closed). After editing identity/ACL state you must re-sign.

### Signing the ACL

The signing key is an Ed25519 **seed** (32 bytes) that your organisation holds **off-client** — it is never stored in the workspace. Supply it only at signing time:

```bash
# The org seed as base64 (or hex), 32 bytes — kept off-client, e.g. in a secrets vault.
export MAESTRO_IDENTITY_SIGNING_KEY="<base64-or-hex-encoded-32-byte-seed>"

# ...or point at a file instead of the env var:
#   mso identity sign-acl --key-id acme-2026-q3 --key-file ~/keys/org-seed.b64

mso identity sign-acl --key-id acme-2026-q3
```

`sign-acl` recomputes the hash of every identity file, signs the manifest, writes `integrity.json`, and prints the **public** key to pin.

### Pinning the public key (runtime trust root)

At runtime Maestro resolves the manifest's signing key **only** from out-of-workspace locations — never from the workspace's own config (a local writer controls that). Pin the **public** half of your signing key in the OS-owned home keyring, `~/.maestro/trusted-keys.json`:

```json
{
  "keys": {
    "acme-2026-q3": {
      "algorithm": "ed25519",
      "publicKey": "<base64 32-byte Ed25519 public key printed by sign-acl>",
      "status": "active"
    }
  }
}
```

The `keyId` must match the `--key-id` you signed with. Rotate by publishing a new `active` key and marking the old one `retiring`, then `revoked` after the overlap window.

### End-to-end workflow

```bash
# 1. Grant a Captain the break-glass capability
mso identity acl set --principal group:captains --capability governance.breakglass --scope "*"

# 2. Sign the ACL with the org key (seed supplied off-client)
export MAESTRO_IDENTITY_SIGNING_KEY="<org-seed>"
mso identity sign-acl --key-id acme-2026-q3

# 3. Pin the printed public key in ~/.maestro/trusted-keys.json (once per machine)

# 4. A verified, capable operator can now break glass:
export MAESTRO_BREAKGLASS_REASON="prod incident #42"
export MAESTRO_BRANCH_GUARD_BYPASS=1
# ...the guarded operation is now honoured and audited.
```

> **Security note:** never weaken these requirements to unblock work. An unsigned manifest, a manifest signed by an unpinned key, a tampered ACL, or an unverifiable caller are all refused **by design** — that is the property that stops a local-write attacker from self-authorising a bypass.

---

## 7. SSO and SCIM: not yet available

> **Status: not yet available.** Maestro does not currently offer single sign-on (SAML 2.0 or an OIDC
> login flow) or SCIM user provisioning. There is nothing to configure, no setting to enable, and no
> date committed for either.

A Maestro licence is held per machine and checked locally; it is not delegated to an identity
provider, and `mso licence status` shows no SSO line.

**What is available today.** For governed workspaces (see [§6](#6-governed-mode-and-break-glass)),
Maestro can treat a caller as a **credential-backed, verified identity** in two ways:

- the caller's GitHub identity, as reported by the authenticated GitHub CLI (`gh`); or
- an OIDC identity token supplied in the environment, trusted **only** when its signature verifies
  against a key you have configured for the workspace.

The second is token *verification*, not a login flow: Maestro does not redirect anyone to your
identity provider or sign anyone in. When `identity.requireVerifiedIdentity` is enabled for an
Enterprise workspace, weaker sources (an unverified `ADM_USER` hint, a local git `user.email`, the
operating-system username) are not accepted: the caller is treated as anonymous unless a verified
source is available.

If SSO or SCIM is a requirement for your deployment, tell us through the
[Maestro contact page](https://www.maestrodevs.com/contact/). Do not include your licence key in the
message.

---

## 8. Licence Key Management

A licence is a single string that starts with `MSO1.`. Treat it as a secret. Full behaviour — tiers,
expiry, grace, tampering and troubleshooting — is in [LICENCE.md](LICENCE.md); the command reference
is [CLI-REFERENCE.md](CLI-REFERENCE.md#mso-licence).

### Activating an Enterprise licence

```bash
mso licence activate MSO1.<your token>
```

The token is verified on the machine, with no network call, and saved to `~/.maestro/licence.json`.
For multi-machine deployments, activate on each machine.

A legacy `adm_lic_…` key (issued before the `MSO1.` token format) is instead confirmed online. See
[LICENCE.md](LICENCE.md#legacy-keys-v1).

### Deploying via environment variable

For CI/CD or shared-host deployments where an interactive step is not practical, set the token as an
environment variable and run `mso licence activate` with no argument:

```bash
export MAESTRO_LICENCE_KEY=MSO1.<your token>
mso licence activate
```

`MAESTRO_LICENCE_KEY` does not activate anything by itself: it is only read by
`mso licence activate`. The result is saved to `~/.maestro/licence.json`, so activate once per
host, not on every run.

### Key rotation

When you receive a renewed token:

```bash
mso licence deactivate
mso licence activate MSO1.<new token>
```

When a token passes its expiry date, a Team or Enterprise install gets a **14-day grace period** at
full tier with a warning banner, then Maestro stops dispatching until a renewed token is activated.
See [LICENCE.md](LICENCE.md) for the exact behaviour.

### Viewing licence status

```bash
mso licence status
mso licence status --json
```

It reads local files only, so it works offline. Sample output for an Enterprise token
(fictitious values):

```
Tier:               enterprise
Effective tier:     enterprise
Licensee:           Example Ltd
Licence ID:         LIC-0000000000
Issued:             2026-04-01T00:00:00+00:00
Expires:            2027-03-31T00:00:00+00:00
Last verified:      2026-11-11T09:30:00+00:00
```

While an expired token is inside its grace period, a `Grace remaining:` line shows the days left
and a warning is printed to stderr.

---

## 9. Air-Gap and Restricted Networks

Maestro's licence validation is local and offline-safe by design.

### Licence key validation

An `MSO1.` licence token is verified on the machine against the signature in the token and the trust root inside the installed Maestro. No server call is made, at activation or afterwards, so it works with no internet access at all. A legacy `adm_lic_…` key is different: it is checked online about every 24 hours and runs on a hard 14-day offline grace, so it cannot be used for a permanently air-gapped site. See [AIR-GAPPED.md](AIR-GAPPED.md) for the full air-gapped procedure.

### Fully air-gapped operation

For workspaces that cannot reach `api.anthropic.com`, crew sessions cannot run (Claude Code requires API access). However, all workspace management commands (`mso status`, `mso backup`, `mso restore`, `mso usage`) work offline.

If your network blocks `api.anthropic.com` but allows access via an internal proxy, configure the proxy as described in [Section 2](#2-network-requirements).

### Git in restricted networks

Crews clone source repositories using the `cloneProtocol` configured in `projects.json`. For internal Git hosts:

```json
{
  "projects": {
    "MYPROJ": {
      "repo": "your-internal-git.corp/my-project",
      "cloneProtocol": "https"
    }
  }
}
```

Ensure the Maestro host can reach your Git host on the configured protocol. SSH keys or Git credential helpers apply as normal.

---

## 10. Deployment Checklist

Use this checklist when setting up an Enterprise workspace.

### Pre-deployment

- [ ] Python 3.11 – 3.14 installed on all Maestro hosts
- [ ] Claude Code installed and on PATH (`claude --version`)
- [ ] `ANTHROPIC_API_KEY` set (or confirmed via enterprise key agreement) — not needed if crews run on AWS Bedrock
- [ ] Outbound HTTPS to `api.anthropic.com` permitted (or to the Bedrock + STS endpoints for your region)
- [ ] Model backend decided: direct Anthropic API (default) or AWS Bedrock — see [MODEL-BACKENDS.md](MODEL-BACKENDS.md)
- [ ] Git host accessible from Maestro hosts
- [ ] Enterprise licence token (`MSO1.…`) received (request via the [Maestro contact page](https://www.maestrodevs.com/contact/))

### Workspace setup

- [ ] `pip install maestro-fleet` run on each host
- [ ] `mso licence activate <key>` run on each machine
- [ ] `mso licence status` confirms Enterprise tier and correct expiry
- [ ] `mso init --project <ACRONYM>` run for each project
- [ ] `projects.json` updated with correct repo URLs and protocols
- [ ] Each team workspace uses a distinct project acronym, so voyage IDs and branches cannot collide (see [§3](#3-multi-team-deployment))
- [ ] `.gitignore` reviewed — crew runtime files should not be committed

### Security baseline

- [ ] `ANTHROPIC_API_KEY` stored in secrets manager, not in workspace files
- [ ] On a Bedrock workspace: `mso providers show model` confirms the backend, region and availability, and `workspace.json` holds no credential value
- [ ] `.claude/settings.json` reviewed for permitted commands and file paths
- [ ] Backup destination confirmed (local path or mounted share)
- [ ] `mso backup` tested and restore verified on staging

### Go-live

- [ ] Test order dispatched and completed successfully
- [ ] `mso status --once` shows correct crew slot and dispatcher state
- [ ] `mso usage --summary` returns expected output
- [ ] Token usage and cost within expected range for test order

---

## 11. Onboarding via an Enrolment Profile

The checklist in [§10](#10-deployment-checklist) describes onboarding as a sequence of manual
steps repeated per machine — `mso init --project <ACRONYM>`, hand-editing `projects.json`, setting
`governedMode`. That is still exactly what happens *under the hood*, but as of the tier-aware
setup wizard it does not need to be typed out by hand on every device.

An admin authors and signs a single **enrolment profile** once for the organisation — it carries
workspace defaults, the governance gate itself, trusted signing keys, a pinned division pack, a
secrets-provider configuration, and (optionally) identity seeding. Every device then runs plain
`mso setup`; if a profile resolves (per a fixed precedence chain — explicit path, env var, home
keyring, workspace-committed file), it is verified and applied automatically, and the wizard
prompts only for what the profile leaves open. An Enterprise device with no profile still
completes the full core wizard — it warns and points here rather than silently proceeding
ungoverned; a Team device with no profile completes silently (an ungoverned Team workspace is a
normal, supported state).

This does not replace anything in [§6](#6-governed-mode-and-break-glass) — governed mode, signed
ACL manifests, and break-glass all work exactly as documented there regardless of whether
`governedMode` was set by hand or by an applied profile. It replaces the *typing*, not the
mechanism.

- **Engineer's side** (activate, `mso setup`, done): [ENTERPRISE-QUICKSTART.md](ENTERPRISE-QUICKSTART.md)
- **Admin's side** (author, sign, publish, pin, rotate, prove, plus the unattended/imaging runbook): [ENTERPRISE-ADMIN-GUIDE.md](ENTERPRISE-ADMIN-GUIDE.md)
- **Full profile field reference**: [ENTERPRISE-ADMIN-GUIDE.md § Part B](ENTERPRISE-ADMIN-GUIDE.md#part-b--the-enrolment-profile)

---

*Maestro v5.22.0 — For Enterprise support, use the [Maestro contact page](https://www.maestrodevs.com/contact/).*
