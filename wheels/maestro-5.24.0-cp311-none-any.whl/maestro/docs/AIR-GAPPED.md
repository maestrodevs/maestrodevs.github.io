# Air-gapped operation

> Running Maestro on a machine that has no internet egress.

> **Working offline for a while rather than permanently?** Use offline mode (`mso offline on`): voyage branches and convergence run locally, every remote step is recorded in an outbox, and `mso outbox replay` publishes it safely when you are back. See [OFFLINE.md](OFFLINE.md). On a machine that is *always* offline, set `mso settings set offline.mode on` so the fleet never tries the network.

This page covers what an air-gapped site needs, in the order you need it: a licence that works with no network, an install that works with no network, and a model that works with no network.

## 1. Choose your licence

An air-gapped machine needs an **`MSO1.` token** (a "v2" licence). A token is verified on the machine itself: activation and every later check use the signature in the token and the trust root inside the installed Maestro, with **no network call**. Nothing is sent anywhere.

What happens when the token's expiry date passes:

| Tier | At expiry |
|---|---|
| Trial | Drops to the free community tier at once (2 crews; `INV`/`PLN`/`BLD`/`TST` only). |
| Pro | A 14-day grace period at full Pro, with a warning banner on every run; then drops to the community tier. |
| Team, Enterprise | A 14-day grace period, then Maestro **stops** (dispatch and crew execution are refused; `mso licence activate`, `status`, `revalidate`, `version` and `--help` keep working). |

So ask for a token whose expiry covers your deployment, plus a renewal window. A token is just a signed expiry date. Ask through the [Maestro contact page](https://www.maestrodevs.com/contact/) and say the machine is air-gapped. You activate a replacement the same way you activated the first one.

**No licence is also fine.** With no licence the machine runs at the community tier, permanently and without error. See the tier limits at the top of [LICENCE.md](LICENCE.md).

A **legacy key** (`adm_lic_…`, "v1") cannot run indefinitely air-gapped: it needs an online check every 24 hours and its offline grace is a hard 14-day limit. See [Legacy keys](#legacy-keys-v1) below.

## 2. Install without internet

A released Maestro wheel is built per CPython minor version, so download on a connected machine that has the **same Python minor version (3.11 – 3.14) and the same operating system** as the air-gapped one.

On the connected machine:

```bash
pip download maestro-fleet==<VERSION> -d wheels/
```

`pip download` fetches the dependencies as well. Copy the `wheels/` folder across (removable media, a file transfer, whatever your site allows), then on the air-gapped machine:

```bash
pip install --no-index --find-links wheels/ maestro-fleet==<VERSION>
mso version
```

Customers who install from the private index use the same pattern with `--index-url <your index URL>` on the `pip download` line and the distribution name your onboarding notes give you. Do not use `--extra-index-url` for this: it makes pip look at both indexes and pick the highest version it finds.

**Claude Code** is a separate install and it also needs an offline route. Follow Anthropic's own Claude Code setup documentation for your platform and your site's policy. Maestro does not install or vendor it.

To upgrade, repeat the download-and-copy with the new version number.

## 3. Activate

```bash
mso licence activate MSO1.<your token>
mso licence status        # confirm the tier and the expiry date
```

For an unattended host, put the token in the environment and run the same command with no argument:

```bash
MAESTRO_LICENCE_KEY="MSO1.<your token>" mso licence activate
```

`mso licence status` reads local files only. `mso licence revalidate` is **refused while offline mode is on**, and a token does not need it: every `mso` run re-verifies the token anyway.

## 4. Turn offline mode on permanently

```bash
mso settings set offline.mode on
```

This tells the dispatcher, the resident LEAD, the Hub and the CLI never to try the network, and defers or refuses every `git`/`gh` step that would reach a remote. [OFFLINE.md](OFFLINE.md) describes what is held, what is deferred to the outbox, and the data-egress guarantee.

## 5. Models without the internet

Offline mode **holds** every order that runs on a hosted model (Anthropic or Bedrock), because those orders cannot reach their model. An air-gapped site therefore needs a local model backend. See [LOCAL-MODELS.md](LOCAL-MODELS.md), including its [Offline scope](LOCAL-MODELS.md#offline-scope) section for what a fleet still needs the network for.

If your site allows *restricted* egress rather than none (for example the Anthropic API through a corporate proxy), you are not air-gapped. Use the allowlist below and leave offline mode off.

## Restricted egress allowlist

If your machine has restrictive egress rather than zero egress, allowlist exactly:

| Host | Purpose | When |
|---|---|---|
| `api.anthropic.com` (or your Bedrock endpoint) | Model inference (your own credentials) | Per crew tool call |
| Your Python package index (PyPI, or your private index) | `pip install` / upgrade | Install and upgrade only |
| Your git host | Voyage branches, pull requests, convergence | Per voyage |
| Your MCP server hosts | Whatever your `.mso/config/mcp-servers.json` lists | Per MCP tool call |
| `api.polar.sh` | Licence check for a **legacy key (v1) only** | At activation and about every 24 hours |

An `MSO1.` token never contacts any host. The Slack bridge is opt-in; see [bridge-setup-guide.md](bridge-setup-guide.md). If you never set it up, Maestro opens no Slack connection.

> **Crews are not covered by this list.** Maestro does not enforce it for crews: a crew is its own process, and the commands it runs (`git`, `curl`, `npx`, MCP servers) can reach any host the machine can. Your firewall or egress proxy is what holds the line for them — see [EGRESS-CONTROL.md](EGRESS-CONTROL.md) for what Maestro enforces and the OS-level control to add.

## Legacy keys (v1)

A legacy `adm_lic_…` key activates online against `api.polar.sh`, is re-checked about every 24 hours, and runs on a 14-day offline grace if that check cannot reach the network. A copied `~/.maestro/licence.json` is refused as tampered, so there is no way to carry a legacy activation to an air-gapped machine. To move to an `MSO1.` token, contact us through the [Maestro contact page](https://www.maestrodevs.com/contact/). Details: [LICENCE.md](LICENCE.md#legacy-keys-v1).
