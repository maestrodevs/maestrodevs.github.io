# Maestro licence — activation, status, recovery

> Customer-facing reference for the `mso licence` CLI. A licence is an **`MSO1.` token** that Maestro verifies **on your machine, with no network call**. Older customers may still hold a legacy `adm_lic_…` key, which is checked online; see [Legacy keys (v1)](#legacy-keys-v1).

## Tier limits (enforced in code, not just advertised)

Maestro's licence has four tiers: **community**, **pro**, **team**, **enterprise**. Running with no licence at all is the community tier — permanent and free, not a trial. Every limit below is enforced at the point of use, not merely described here:

| Limit | Community | Pro / Team / Enterprise |
|---|---|---|
| Concurrent crews (`mso dispatch --max-crews`) | **2** (any higher request is silently clamped, with a message stating the clamp and the requested value) | Up to 5 (the dispatcher runs at most 5 crew slots) |
| Registered projects (`mso init` / registering a new acronym) | **1** — registering a second, distinct acronym is refused; re-registering an already-known acronym (e.g. after a path change) is always allowed | Unlimited |
| Roles a crew can be dispatched as | `PLN`, `BLD`, `TST` only — `SEC`, `DOC`, `REL` are refused with a licence message naming the required tier | All roles |
| `governance.governedMode` (`enforce`/`warn` in `workspace.json`) | Ignored — governance stays off, with a message explaining why | **Enterprise only** — pro and team also cannot turn this on |

Investigation (`INV`) is an order type, not a role: its orders run on `PLN`, so they work on community too.

Every gate above resolves the tier the same way (`maestro.auth.has_tier`), and an unlicensed install is never treated as an error — it runs at the community limits shown above.

**`MAESTRO_SKIP_AUTH=1` has no effect on an installed Maestro (SEC-MSO-2026-0945).** It is honoured only on a build whose vendor licence keyring is empty — a repo-tree or editable (`pip install -e .`) install, which is also the only kind of install that is permanently community-tier for exactly the same reason (it carries no vendor key, so no licence token can verify against it — see [Does an install or upgrade preserve my licence?](#does-an-install-or-upgrade-preserve-my-licence)). Every published wheel carries an injected vendor key, so on any wheel the flag is ignored and the tier is enforced from the activated licence; setting it there is reported, not silently dropped (a `LICENCE_WARNING` at dispatcher startup, and a line on the tier-refusal message).

Features gated separately, each enforced where it runs:

| Feature | Tiers |
|---|---|
| Resident LEAD agent (`mso lead start`) and the Captain chat (`mso lead chat say` / `reply` / `decide`) — see [LEAD.md](LEAD.md) | **Pro, Team, Enterprise** |
| The Judge (approval-queue decision agent) | **Pro, Team, Enterprise** |
| Scheduled tasks — authoring and running (viewing them works at every tier) — see [SCHEDULES.md](SCHEDULES.md) | **Pro, Team, Enterprise** |
| Chart authoring and execution (`mso chart new`, and `charts.enabled` actually routing work; `mso chart show` works at every tier) — see [CHARTS.md](CHARTS.md) | **Pro, Team, Enterprise** |
| Local open-weights model endpoint (`providers.local_model`) — see [LOCAL-MODELS.md](LOCAL-MODELS.md) | **Pro, Team, Enterprise** |
| Maestro Hub (`mso hub start` / `mso hub setup`, and every Hub control action) — see [HUB.md](HUB.md) | **Pro, Team, Enterprise** |
| Fleet-wide runtime update (`mso runtime update --confirm`, and the Hub's Update button) | **Pro, Team, Enterprise** |
| Shared artefact mode (`"artefacts": {"mode": "shared"}` — one artefact plane written by several machines, see [ARTEFACT-REPO.md](ARTEFACT-REPO.md)) | **Team, Enterprise** |
| Non-free division packs, and remote signed packs (`--pack https://…`) | **Team, Enterprise** |
| Policy governance: `governance.governedMode`, and `mso policy enable`, `mso policy publish`, `mso policy trust add`, `mso policy trust rotate` | **Enterprise** |
| Signed policy bundle distribution (`mso policy pull`) | **Enterprise** |
| AWS Bedrock model backend (`providers.model: bedrock`) — see [MODEL-BACKENDS.md](MODEL-BACKENDS.md) | **Enterprise** |

**Not licence-gated — available at every tier, switched on by configuration:** multi-seat identity and ACLs, the hash-chained audit log with external anchoring, data-rights tooling (`mso identity rights export`, `mso identity rights forget`) and multi-repo workspaces ([MULTI-REPO.md](MULTI-REPO.md)). Identity, ACLs and the audit log switch on from the `"enterprise": true` flag in `.mso/config/workspace.json` (or an active governed mode); multi-repo switches on from the `artefacts.repos` map. Community included.

## What a licence is

A **token** that starts with `MSO1.`, issued to you by Maestro. It carries your tier, your organisation's name and an expiry date, and it is signed by Maestro. **Treat it like an API token**: anyone with the token can activate Maestro as you.

You do not need a licence to run Maestro. With none, you run at the **community tier**, which is free and permanent. Contact us through the [Maestro contact page](https://www.maestrodevs.com/contact/) for pricing or a Pro, Team or Enterprise token.

## Activate

```bash
mso licence activate MSO1.<your token>
```

What happens:
1. The CLI checks the token's signature against the trust root that ships inside the installed Maestro, and checks that the token is currently valid. **It makes no network call.** This works on a machine with no internet.
2. On success, your machine writes the token to `~/.maestro/licence.json`. No keychain entry and no per-machine secret is involved.
3. On every later `mso` run the token is verified again. If the token is edited, or its signature does not match, Maestro refuses to trust it.

A token that is expired or not yet valid is refused at activation, with a message saying so.

### CI / non-interactive activation

```bash
MAESTRO_LICENCE_KEY="MSO1.<your token>" mso licence activate
```

With no argument, `mso licence activate` reads the token from `MAESTRO_LICENCE_KEY`. Run it once per host. Other commands do not read that variable. Useful for ephemeral build agents and headless servers.

## Status

```bash
mso licence status         # human text
mso licence status --json  # JSON for scripts
```

Shows your tier (and effective tier, if it has been downgraded or stopped), licensee, licence ID, issue date, expiry, last-verified time, and any grace days remaining. It reads local files only, so it works offline.

Any warning it reports — verification failure, revocation, expiry, running on offline grace — is **also printed once at `mso dispatch` startup** (and recorded in `.mso/logs/lifecycle.log`). You should never have to run `status` to discover that a fleet is about to launch at a tier you did not expect. An ordinary unlicensed install prints nothing: community is a normal tier, not a warning.

## Force a re-check

```bash
mso licence revalidate
```

Re-verifies your licence immediately. For an `MSO1.` token this is a local check, so it is only useful to confirm the state after you have activated a renewal. It is **refused while offline mode is on** (see [OFFLINE.md](OFFLINE.md)); `mso licence status` still works. For a legacy key it also forces the online check, skipping the 24-hour cache.

## Deactivate

```bash
mso licence deactivate
```

Removes `~/.maestro/licence.json` (and, for a legacy key, the keychain entry). The machine then runs at the community tier. It cannot be run from inside a crew.

## Expiry and renewal

An `MSO1.` token has an expiry date. Maestro warns you at 30 days and again at 7 days before it. What happens after the date depends on the tier:

| Tier | After the expiry date |
|---|---|
| Trial | Drops to the community tier at once. |
| Pro | A 14-day grace period at full Pro, with a warning banner on every run; then drops to the community tier. |
| Team, Enterprise | A 14-day grace period at full tier, with a warning banner; then Maestro **stops**: dispatch and crew execution are refused. There is no automatic downgrade for these tiers. `mso licence activate`, `status`, `revalidate`, `version`, `mso status` and `--help` keep working while it is stopped. |

Team and Enterprise stop rather than downgrade because dropping to community mid-run would change how the workspace behaves without telling you: on Team, shared artefact mode and the Hub would drop out; on Enterprise, the policy governance engine would silently switch off while agents kept running. Identity, ACLs and the audit log are not licence-gated, so they keep working at the community tier either way.

To renew, ask for a new token through the [Maestro contact page](https://www.maestrodevs.com/contact/) and run `mso licence activate MSO1.<new token>`. It replaces the old one. A renewal can be sent before the old token expires. No network is needed, so this works on an [air-gapped machine](AIR-GAPPED.md).

## Tamper detection

An `MSO1.` token is signed. If `~/.maestro/licence.json` is edited so the token no longer matches its signature, or the token names a signing key that this installed Maestro does not trust, Maestro refuses it and tells you why. Re-run `mso licence activate MSO1.<your token>` with the token you were sent. If the message persists on an official release install, see [Licence token failed verification](#licence-token-failed-verification--running-at-community-tier) below.

A token is verified by its signature alone and is not bound to one machine. How many seats or machines it covers is set by your licence terms.

## Legacy keys (v1)

Before `MSO1.` tokens, Maestro licences were keys such as `adm_lic_AB12CD34EF56GH78IJ90KL`, issued through Polar. Existing legacy keys keep working, with the behaviour below. If you hold one, ask to move to an `MSO1.` token through the [Maestro contact page](https://www.maestrodevs.com/contact/).

- **Activation needs the internet.** `mso licence activate adm_lic_…` contacts `api.polar.sh` to confirm the key is granted. Only the key and ordinary HTTP request metadata are sent. Your machine then writes `~/.maestro/licence.json` (mode 0600), signed with a per-customer secret stored in your OS keychain (Keychain on macOS, Credential Manager on Windows, libsecret on Linux).
- **Re-checked about every 24 hours.** `mso licence revalidate` forces the check now.
- **14 days of offline grace.** If the licence backend cannot be reached, `mso` keeps working with a banner such as `⚠ Couldn't reach the licence backend; running on offline grace (10 days remaining). Reconnect to revalidate.` A successful check restarts the window. Past 14 days with no successful check, `mso` refuses to start until you reconnect and run `mso licence revalidate`.
- **A copied `licence.json` is refused.** The record is bound to the machine's keychain entry. A file that is edited or copied from another machine fails with `Licence file signature mismatch…`; re-run `mso licence activate <KEY>` on that machine, online.
- **Cancellation and refunds.** Cancelling through the Polar customer portal keeps Maestro working to the end of the paid period, then the next online check reports the key as revoked or expired. A refund revokes the key at the next online check. Re-subscribing issues a new key: run `mso licence activate <NEW-KEY>` and it replaces the old record. `mso licence deactivate` removes only the local record and does not cancel your subscription; manage that in the Polar portal.
- **Not for air-gapped use.** The grace limit is hard. See [AIR-GAPPED.md](AIR-GAPPED.md).

## Does an install or upgrade preserve my licence?

**Yes, for the way almost everyone installs Maestro — a wheel install.** `pip
install` / `pip install --upgrade` replaces `site-packages/maestro/` with the
contents of a published wheel, and a correctly-published wheel carries the
vendor public key baked in at release-build time. Your activated licence
(`~/.maestro/licence.json`) lives outside `site-packages` entirely, so it is
never touched by the install itself — the only thing an install can change
is whether the copy of Maestro you now have still has a key to verify it
against.

| Install path | Licence preserved across install/upgrade? |
|---|---|
| `pip install --upgrade maestro-fleet` (wheel, from PyPI — the normal path) or from the private index (air-gapped/enterprise only, see [AIR-GAPPED.md](AIR-GAPPED.md)) | **Yes** — a correctly-published wheel always carries the vendor key. |
| `pip install . --no-deps` from a source clone of this repo | **No** — a source clone carries no vendor key by design, so no key material is ever committed. This wipes any vendor key a previous install had. This is a deliberate trade-off, not a bug. The vendor key cannot be restored from a source clone — reinstall from an official release wheel instead. |
| `pip install -e .` (editable install) | **No, and cannot be** — the "installed" keyring under editable mode *is* this repo's tracked `{}` file. Permanently community-tier by construction; use a non-editable install to run a licensed local fleet. |

If you're unsure which path you're on: `mso licence status` prints a warning
whenever a valid-looking token fails to verify because the installed copy's
keyring doesn't recognise it — see [below](#published-wheels-shipping-an-empty-trust-root-resolved).

### Published wheels shipping an empty trust root (resolved)

**Affected versions: `maestro` / `maestro-fleet` 5.6.4 and 5.7.0** (private
index and PyPI). A CI defect meant these two releases
were built and published with an **empty** licence trust root — the release
build's key-injection step silently no-op'd (the same behaviour that is
correct and expected for a plain source-clone install, just wrongly reached
on the release path too) and nothing checked afterwards that a key had
actually landed.

**What you would have observed:** `mso licence activate <TOKEN>` appears to
succeed, but the fleet runs at **community** limits regardless of your
actual subscription tier (2 crews, `PLN`/`BLD`/`TST` roles only, Hub
gated off) — the exact symptom described under ["Licence token failed
verification … running at community
tier"](#licence-token-failed-verification--running-at-community-tier) above,
except here the cause was the published artefact, not your local install.

**What to do:** upgrade to 5.8.0 or later (the first release built with the `--require-keys` guard, so its trust root is verified at build time) —

```bash
pip install --upgrade maestro-fleet
mso licence activate <YOUR-EXISTING-KEY>   # re-run — your licence is unaffected
mso licence status                          # confirm your real tier is back, no warning printed
```

Air-gapped / private-index installs: `pip install --upgrade maestro --extra-index-url https://maestrodevs.github.io/simple/` — the same 5.8.0 fix applies there too; see [AIR-GAPPED.md](AIR-GAPPED.md).

Every release after this fix publishes only through a build step that now
hard-fails (rather than silently no-opping) if the vendor key isn't
correctly injected, so a keyless release can no longer reach either index —
see the CHANGELOG entry for that release.

## Crews and the legacy licence on servers without a keyring

Crews always run at the same tier as the `mso dispatch` that launched them,
never higher. A crew does not read a licence of its own: anything a crew
writes into its working area cannot change its tier.

That guarantee is about files, and it holds only while the licence details
`mso dispatch` gives the crew are still in the crew's environment. **It is
not a security boundary against the crew itself.** A crew runs as your
operating-system user. It can remove those details from the commands it runs,
and those commands then fall back to the community tier or to whatever
licence your user account can read. A legacy licence (one that does not
start with `MSO1.`) can also be re-signed by anything that can read your OS
keyring. Treat a crew the way you would treat any other program you run as
yourself.

Those licence details include your full licence token (or, for a legacy
licence, your licence key). Maestro removes them from the activity feed and
the saved crew reasoning, and refuses a crew's file-editing tools when they
would write them into a file such as a handoff or report. Other copies of the
crew's output are not cleaned: a shell command that redirects its output
into a file, or the Claude session history that Claude Code saves itself.
The cleaning catches ordinary environment listings (`env`, `printenv`,
`Get-ChildItem Env:`, including PowerShell's wrapped `Format-List` output). It
does not protect against a crew that is trying to leak the token, for example
by re-encoding or slicing it before printing. Never paste a crew's raw
environment listing anywhere public.

One case needs action on your side. A **legacy** licence (a key that does not
start with `MSO1.`) on a host **with no OS keyring** (common on headless Linux
servers and containers) reaches crews as **community**. The dispatcher itself
still runs at your licensed tier, so tier-gated work inside crews is refused,
for example the Amazon Bedrock model backend.

The fix is to activate a Maestro licence token (`MSO1.…`). A token needs no
keyring and reaches crews at its full tier:

```bash
mso licence activate MSO1.<your token>
```

Contact us for a token if you only have a legacy key. `mso doctor` reports
the mismatch as `model.backend-crew-licence` when a tier-gated backend is
configured.

## Where things live on your machine

| Path | Purpose | Mode |
|---|---|---|
| `~/.maestro/licence.json` | Your `MSO1.` token and cached details | 0600 |
| Legacy key only: OS keychain entry `maestro-licence/<customer_id>` | Per-customer signing secret | OS-managed |
| Legacy key only: `~/.maestro/secrets/<customer_id>.key` (systems without a keychain provider) | Fallback for the signing secret | 0600 |

Nothing else. There are no remote files keyed to your account.

## Privacy

Activating or checking an `MSO1.` token sends **nothing**: it never leaves your machine.

Activating or re-checking a legacy key transmits to `api.polar.sh` only the licence key and ordinary HTTP request metadata (User-Agent, IP address). No code, no prompts, no project names, no hostname.

## Common issues

### `Activation refused — token failed verification`

The token is not a valid Maestro token. Check that you pasted the whole string, starting with `MSO1.`, with no spaces or line breaks added by an email client. Quote it on the command line. If the message names a signing key this install does not trust, see [Licence token failed verification](#licence-token-failed-verification--running-at-community-tier) below.

### `Activation refused — token is not currently valid`

The token has expired, or its start date has not arrived yet. Ask for a new token through the [Maestro contact page](https://www.maestrodevs.com/contact/).

### `Activation refused: <reason>` or `Couldn't reach the licence backend` (legacy key only)

You are activating a legacy `adm_lic_…` key, which is verified online. Check for typos (the key includes mixed case and digits) and that `api.polar.sh` is reachable. Activation of a legacy key cannot work offline. Ask to move to an `MSO1.` token, which can.

### `Licence file signature mismatch` (legacy key only)

The legacy licence file was edited, or copied from another machine, or an OS update rotated the keychain master key (rare; macOS Migration Assistant is the most common cause). Re-run `mso licence activate <KEY>` on this machine while online.

### `Licence token failed verification … running at community tier`

Your token is well-formed, but this **installation** has no vendor signing key matching it, so verification fails closed and you drop to community limits. The usual cause is an install built from a source checkout rather than an official release wheel — source clones deliberately ship no signing key. Reinstall from the official channel; if it persists on an official wheel, send your `mso licence status` output to [maestrodevs.com/contact](https://www.maestrodevs.com/contact/) for a re-issue.

Full walkthrough, including how to tell this apart from the tamper path above: [TROUBLESHOOTING.md E30](TROUBLESHOOTING.md#e30--licence-activated-but-maestro-still-runs-at-community-tier).

### `Offline grace expired` (legacy key only)

A legacy key has been offline for more than 14 days. Connect to the internet and run `mso licence revalidate`, or move to an `MSO1.` token, which has no online check.

### `Maestro licence EXPIRED and its grace period has ended`

An `MSO1.` Team or Enterprise token is past its expiry date plus 14 days. Maestro has stopped. Ask for a renewal token through the [Maestro contact page](https://www.maestrodevs.com/contact/) and run `mso licence activate MSO1.<new token>`.

## Where to ask questions

Pricing, renewals, licence problems and any question about your licence: the [Maestro contact page](https://www.maestrodevs.com/contact/). See also [SUPPORT.md](SUPPORT.md).
