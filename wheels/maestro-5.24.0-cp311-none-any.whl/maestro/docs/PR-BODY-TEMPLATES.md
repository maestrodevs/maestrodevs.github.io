# Voyage PR body templates

Every voyage pull request Maestro opens carries a body built from the evidence the fleet
has already written: the QA report's acceptance-criteria results and test counts, and
the security review's verdict and findings. The body comes from a **template**. Maestro
ships a default, and an organisation can supply its own.

This page covers what the default body shows, how Maestro chooses a template, what a
template can use, and what happens when a template breaks.

---

## What the default body shows

From top to bottom:

1. **Template failure notice.** Shown only if a custom template failed (see [Fail-safe](#fail-safe)).
2. **Blocking issues** (`[!CAUTION]`). Lists every order with any of:
   - a FAILED acceptance criterion;
   - a criterion where the order and its QA report disagree (CONFLICT);
   - a QA verdict of REJECTED or BLOCKED;
   - QA-listed blocking defects;
   - new test failures;
   - a SEC verdict of BLOCKED or REJECTED;
   - a CRITICAL or HIGH finding, unless the final SEC report approves (see below).

   Computed over **every** order in the voyage, including orders the order cap leaves out of the per-order section.
   The banner reads "Not safe to merge: the final QA/security evidence reports N blocking issue(s)".
   It judges the **final** reports only: `QA-{ORDER-ID}.md` and `SEC-{ORDER-ID}.md`, plus any
   independent SEC review such as `-LEAD-INDEPENDENT` (an independent REJECTED always blocks).
   Earlier passes (`-lapN`, `-reverify`, or anything under `reports/<kind>/superseded/`) are listed
   under each order as superseded and never block. With no final report at all, earlier passes
   are read conservatively and do block.
3. **Evidence gaps** (`[!WARNING]`). Lists:
   - orders with no QA report where the role sequence includes TST;
   - orders with no SEC report where the role sequence includes SEC (the `SEC_ARTEFACT_MISSING` condition);
   - reports whose verdict cannot be read;
   - a final SEC report that declares no readable verdict while an earlier pass was adverse;
   - an earlier pass that was adverse while the final report approves (for a reviewer's glance,
     not a block).

   A missing report is always listed, never left out. If nothing is listed, reviewers would read that as "nothing to report".
   **Noted, not blocking** (`[!NOTE]`) follows: CRITICAL or HIGH findings that an APPROVED or
   CONDITIONAL final SEC report lists, and so has dispositioned.
4. **Summary table.** One row per order: status, QA verdict, criteria passed, tests passed out of run (with new failures), and security verdict with CRITICAL/HIGH/MEDIUM counts.
5. **Per-order sections.** Each has:
   - the acceptance-criteria table (ID, criterion, PASS/FAIL, source);
   - test counts by category, with the new-failures figure;
   - the SEC verdict with per-severity finding counts and the report path.

   Long evidence prose stays in the QA and SEC reports; the body gives their paths.
6. **Test plan** checkboxes and a footer naming the template that rendered the body.

### When the body is written

- **PR creation.** The PR is opened when the voyage's first crew converges, before any QA
  or SEC report exists. The first body is therefore mostly evidence gaps.
- **Refresh.** Maestro renders the body again when the voyage-level REL order is filed and
  when the voyage finalises. Both happen just before the PR is promoted to ready for review.
  To turn this off, set `completion.voyagePr.refreshBodyOnFinalisation: false`.
- **Provider support.** GitHub and Bitbucket Cloud support the refresh. Bitbucket Data Center
  does not yet support editing a PR description; Maestro logs that once and carries on.

### Reading the evidence

The body uses the same report readers as the Maestro Hub, so the two always agree:

- **Acceptance criteria:** `order.acResults` combined with the QA report's own AC table.
  When the two disagree, the criterion shows as CONFLICT rather than one side winning.
- **Unrecorded results:** a criterion with no recorded result shows as `NOT RECORDED`, never PASS.
- **Unreadable verdicts:** show as `UNDETERMINED`.
- **SEC verdicts:** normalised to `APPROVED`, `CONDITIONAL`, `REJECTED` or `BLOCKED`. The
  wording the report used is kept, so `APPROVED-WITH-FINDINGS` shows as
  `CONDITIONAL (declared: "APPROVED-WITH-FINDINGS")`.

---

## The PR title

Every voyage PR Maestro opens is titled `[VOY-ID] <voyage title>`, taken from the voyage manifest and cut to 100 characters, so the PR list shows what each voyage does and not just its id. If the manifest cannot be found or has no title, the title falls back to `[<branch>] <repo>`. The title is not templated; only the body is.

## Choosing a template

Maestro checks four places, highest authority first. The **first one that is configured** is used:

| Rank | Tier | Where | Tier gate |
|---|---|---|---|
| 1 | **Signed policy bundle** | `prBody.template` in a policy bundle (`mso policy pull`). The template text is inline, so the bundle signature covers it. | Enterprise (distribution) |
| 2 | **Division pack** | `prBodyTemplate` in the pinned pack's `pack.json`: a path to a `.j2` file inside the pack directory | Pro / Team / Enterprise |
| 3 | **Workspace** | `completion.voyagePr.bodyTemplate` in `workspace.json` (a path relative to `.mso/`, or absolute). If that key is not set, `.mso/config/pr-body.md.j2` is used when it exists. | any |
| 4 | **Shipped default** | `maestro/templates/pr-body.md.j2` | any |

The footer of each body names the template that rendered it. If a lower tier is also
configured but was outranked, the footer lists it as `shadowed` so the override is visible.

### Can a governed template be overridden locally? No.

A template from a signed policy bundle or a pinned division pack takes precedence. A workspace
template cannot replace it. The same applies if the governed template **breaks**: Maestro falls
back to the shipped default, never to the workspace template.

**Why.** A governed template exists so a team cannot quietly drop the security section or the
acceptance-criteria table from the PR a reviewer approves. If a workspace file could override it,
the governance would be advisory. If a broken governed template fell back to the workspace
template, breaking the governed one would become a way around it. The shipped default always
shows every blocking issue and gap, so it is the only safe fallback. An organisation that wants
teams to control their own PR body simply leaves `prBody` out of its bundle.

### Configuration keys (`completion.voyagePr` in `workspace.json`)

| Key | Default | Meaning |
|---|---|---|
| `bodyTemplate` | *(unset)* | Path to a workspace template (relative to `.mso/`, or absolute). |
| `bodyOrderCap` | `20` | Orders rendered in full in the per-order section. Every order still counts towards the blocking and gap lists. |
| `bodyMaxChars` | `30000` | Maximum body length, clamped to 2000–65000. GitHub's hard limit is 65536, but the GitHub CLI passes the body on the command line and Windows caps a command line at 32767 characters, so the default is kept well below both. |
| `reportLinkBase` | *(unset)* | Web URL prefix for report links, for example `https://github.com/acme/ACME-Platform/blob/main/`. When unset, report paths render as plain code paths. |
| `refreshBodyOnFinalisation` | `true` | Re-render the PR body at REL filing and finalisation. |

---

## Template variables

Templates are Jinja2 and run in a **sandbox**: a template can read the variables below but
cannot call arbitrary Python. **Undefined variables are an error**, not an empty string. A
misspelt variable therefore triggers the fail-safe instead of quietly rendering a blank where
the security verdict should be.

The contract is versioned by `schema_version`, currently `1`. Fields may be added without a
version change; renaming or removing a field bumps it.

### Top level

| Variable | Type | Meaning |
|---|---|---|
| `schema_version` | int | Version of this contract. |
| `generated_at` | str | UTC time the body was rendered, ISO 8601. |
| `voyage.id` / `.title` / `.status` | str | From the voyage manifest; empty strings when no manifest names this branch. |
| `voyage.branch` | str | The voyage branch. |
| `voyage.commits_ahead` | int or none | Commits ahead of the base branch; `none` when unknown, for example on a refresh. |
| `voyage.manifest_found` | bool | Whether a voyage manifest was found for this branch. |
| `orders` | list of **order** | Orders rendered in full, in voyage order. Capped at `limits.order_cap`, and orders with blocking issues or gaps are kept first. |
| `all_orders` | list | Every order: `id`, `title`, `status`, `rendered`, `blocking` (bool), `gaps` (bool). |
| `order_count` / `orders_rendered` / `orders_omitted` | int | Number of orders in total, rendered, and left out by the cap. |
| `omitted_order_ids` | list of str | IDs of orders left out by the cap. |
| `flags` | dict of bool | Summary flags, covering **all** orders (below). |
| `blocking` | list of **issue** | Every blocking issue, over all orders. |
| `gaps` | list of **issue** | Every evidence gap, over all orders. |
| `noted` | list of **issue** | Items the final evidence noted without blocking, over all orders: CRITICAL/HIGH findings listed by an approving final SEC report. |
| `evidence_basis` | str | What the blocking banner judges: `final QA/security evidence`. Earlier passes never block. |
| `missing_qa` / `missing_sec` | list of str | IDs of orders missing an expected QA or SEC report. |
| `totals` | dict | `ac_total`, `ac_met`, `ac_failed`, `ac_not_recorded`, `tests_total`, `tests_failed` and `new_failures` (each int or none), plus `sec_reports` (int). |
| `compact` | bool | `true` on the size-limit re-render (see [Size limits](#size-limits-and-truncation)). |
| `limits.order_cap` / `limits.body_max_chars` | int | The active limits. |
| `template.tier` / `template.source` | str | The template that is rendering this body. |
| `template.shadowed` | list of str | Lower tiers that were also configured but outranked. |
| `template.failure` | dict or none | Set when a custom template failed: `tier`, `source`, `error`. |
| `notes` | list of str | Configuration notes, for example a clamped `bodyMaxChars`. |

### `flags` — building your own banner

`any_ac_failed`, `any_ac_conflict`, `any_qa_rejected`, `any_qa_blocking_defects`,
`any_new_failures`, `any_sec_blocked`, `any_critical_high`, `any_missing_qa`,
`any_missing_sec`, `any_blocking`, `any_gaps`, `any_noted`, `attention_required`.

`any_blocking` is true when `blocking` is non-empty, `any_gaps` when `gaps` is non-empty,
`any_noted` when `noted` is non-empty, and `attention_required` when `blocking` or `gaps` is. You never need to derive these flags yourself:

```jinja
{% if flags.any_blocking %}
> [!CAUTION]
> **Do not merge.**{% if flags.any_sec_blocked %} Security review BLOCKED.{% endif %}
{% for i in blocking %}
> - {{ i.order_id }}: {{ i.message | md_cell }}
{% endfor %}
{% endif %}
```

### issue

| Field | Meaning |
|---|---|
| `kind` | Blocking kinds: `ac_failed`, `ac_conflict`, `qa_rejected`, `qa_blocking_defects`, `new_failures`, `sec_blocked`, `sec_critical_high`. Gap kinds: `missing_qa`, `missing_sec`, `qa_undetermined`, `sec_undetermined`, `sec_verdict_unreadable`, `history_adverse`, `reports_unreadable`, `reader_error`. Noted kind: `sec_findings_noted`. |
| `order_id` | The order the issue belongs to. |
| `message` | One-line text a reviewer can read. |
| `report_path` | The report the issue comes from, if any. |

### order

| Field | Meaning |
|---|---|
| `id`, `title`, `type`, `status` | From the order record. |
| `found` | Whether the order record was found. |
| `role_sequence` | List of role codes, upper-case. |
| `qa.expected` | The role sequence includes TST. |
| `qa.present` | A QA report exists. |
| `qa.verdict` | `APPROVED`, `CONDITIONAL`, `REJECTED`, `BLOCKED` or `UNDETERMINED`; `none` when there is no report. |
| `qa.raw_verdict` | The verdict as the report wrote it. |
| `qa.decided` | The verdict is one of the four decided values. |
| `qa.blocking_defects` | Number of blocking defects the report lists. |
| `qa.report_path` / `qa.report_url` | Report path relative to the artefact root; web link when `reportLinkBase` is set, else `none`. |
| `qa.report_class` | `canonical` when the verdict comes from `QA-{ORDER-ID}.md`; `history` when only an earlier pass exists (read conservatively); else `independent`; `none` with no report. |
| `qa.superseded[]` | Earlier QA passes beside the final report, never blocking: `name`, `report_path`, `report_url`, `verdict`, `adverse` (bool). |
| `qa.missing_reason` | Why there is no report, for example `no QA report - did not reach TST (order status IN_PROGRESS)`. |
| `acceptance.has_criteria` | The order carries acceptance criteria. |
| `acceptance.total` / `met` / `failed` / `partial` / `skipped` / `not_recorded` / `undetermined` / `conflicted` | Criterion counts by result. |
| `acceptance.bucket` | Coverage bucket from the reports core. |
| `acceptance.rows[]` | `id`, `criterion` (full text), `criterion_short` (140 characters), `status` (`PASS` / `FAIL` / `PARTIAL` / `SKIP` / `NOT RECORDED` / `UNDETERMINED` / `CONFLICT`), `provenance` (`order.acResults` or `QA report`). |
| `acceptance.failed_ids` / `conflict_ids` | IDs of failed and conflicting criteria. |
| `tests.recorded` | The QA report has a readable test summary. |
| `tests.total` / `passed` / `failed` | Test counts; each can be `none`, which means "not recorded", **not** zero. |
| `tests.new_failures` | New failures the QA report says the order introduced; `none` when not stated. |
| `tests.categories[]` | `name`, `tests`, `passed`, `failed`. |
| `security.required` | The role sequence includes SEC. |
| `security.present` | At least one SEC report exists. |
| `security.verdict` / `raw_verdict` / `decided` / `report_path` / `report_url` | As for QA, taken from the primary report `SEC-{ORDER-ID}.md` (the final report; an earlier pass only when no final report exists). |
| `security.counts` | Finding counts: `CRITICAL`, `HIGH`, `MEDIUM`, `LOW`, `INFO`, `UNSPECIFIED`. |
| `security.findings_total` | Total findings in the primary report. |
| `security.blocked` | A final or independent SEC report for the order is BLOCKED or REJECTED. A superseded earlier pass never sets it. |
| `security.critical_high` | A final or independent SEC report has a CRITICAL or HIGH finding **and** the final verdict is not APPROVED or CONDITIONAL, so the findings block. |
| `security.critical_high_noted` | The same findings exist but an approving final report dispositioned them: noted, not blocking. |
| `security.approving` | The final verdict is APPROVED or CONDITIONAL, nothing blocks, and the verdict is readable. |
| `security.standing_verdict` / `standing_report` | The verdict the merge decision stands on, and the report it was read from. |
| `security.unreadable` | Set (a text reason) when the final report declares no readable verdict while an earlier pass was adverse; else `none`. |
| `security.disagreement` | The order's final and independent SEC reports give different verdicts. |
| `security.superseded[]` | The earlier passes, as `reports[]` entries. |
| `security.reports[]` | Every SEC report, final first, then independent variants such as `-LEAD-INDEPENDENT`, then superseded earlier passes: `name`, `variant`, `verdict`, `raw_verdict`, `decided`, `report_path`, `report_url`, `counts`, `findings_total`, `blocked`, `critical_high` (the report lists one, a fact rather than a block), `report_class` (`canonical` / `independent` / `history`), `superseded`. |
| `security.missing_reason` | Why there is no report, when SEC is required. |
| `blocking_issues` / `gaps` / `noted` | This order's own issues. |
| `notes` | Notes from reading this order's records. |

Dictionary fields can be read with dot syntax (`o.security.counts.HIGH`) or brackets.

### Filters

| Filter | Meaning |
|---|---|
| `md_cell` | Makes a value safe inside a markdown table cell or a quoted line: newlines become spaces, `|` is escaped, and `none` becomes empty. |
| `truncate_text(n)` | Cuts to *n* characters, ending with `...` when cut. |

Standard Jinja2 filters (`join`, `length`, `upper`, and so on) are also available.

---

## Fail-safe

A custom template (bundle, pack or workspace) that:

- points at a missing or unreadable file, is not UTF-8, or exceeds 256 KB;
- has a syntax error;
- raises while rendering, including any undefined variable; or
- renders an empty body

**never** produces an empty, truncated or silently incomplete PR body. Instead:

1. Maestro renders the body with the **shipped default**. Every QA and SEC detail is present.
2. It writes a `PR_BODY_TEMPLATE_FAILED` lifecycle event naming the tier, the source and the error.
3. The body opens with a notice that the custom template failed, and why.

If a policy bundle cannot be loaded at all, for example because it fails verification, Maestro
treats that as a failed bundle-tier template. A broken bundle might be hiding a governed template,
so Maestro does not skip to a lower tier.

If the shipped default itself cannot render, Maestro produces a plain fallback body without
using a template. It still lists every blocking issue and gap.

## Size limits and truncation

If the rendered body is longer than `bodyMaxChars`:

1. **Compact mode.** The same template is rendered again with `compact = true`. The default
   template then leaves out passing criterion rows and per-category test tables, and says so in
   the body. Failures, conflicts and unrecorded results are still shown.
2. **Cut.** If the compact body is still too long, it is cut at a line break and a visible note
   says how many characters were dropped.

Both steps write a `PR_BODY_TRUNCATED` lifecycle event. The blocking issues and gaps sit at the
top of the default template, so a cut removes the end of the body first. **Keep them at the top
of a house template too.** A house template can ignore `compact`; if it does, step 2 still
applies.

The order cap (`bodyOrderCap`) is separate from the size limit. Orders it leaves out are named
in the body (`omitted_order_ids`), and their blocking issues and gaps still appear at the top.
