# Maestro — Operator Guide

> For teams running Maestro in production. Covers day-to-day operations, scaling, cost control, failure handling, backups, notifications and reporting. For initial setup, see [GETTING-STARTED.md](GETTING-STARTED.md).

> **Current as of v5.22.** Every command shown here runs on this release. For the full flag list of any command run `mso <command> --help`, or see [CLI-REFERENCE.md](CLI-REFERENCE.md).

---

## Contents

1. [Daily Operations](#1-daily-operations)
2. [Scaling Crews](#2-scaling-crews)
3. [Cost Management](#3-cost-management)
4. [Handling Failures](#4-handling-failures)
5. [Backup Strategy](#5-backup-strategy)
6. [Notifications](#6-notifications)
7. [Multi-Project Operations](#7-multi-project-operations)
8. [Performance Tuning](#8-performance-tuning)
9. [Team Workflows](#9-team-workflows)
10. [Reporting](#10-reporting)

---

## 1. Daily Operations

### Morning checklist

```bash
# Fleet state: dispatcher, crews, queues
mso status --once

# A compact view of pending and active orders
mso status --once --compact

# Health check of the fleet itself (read-only)
mso doctor

# Spend so far
mso usage --summary
```

`mso doctor` is the first thing to run when something looks wrong. See [PATROL.md](PATROL.md).

### Dispatching work

Queue orders, then launch the dispatcher:

```bash
# Standard launch
mso dispatch --max-crews 3

# Clean up stale state from a previous run first
mso dispatch --cleanup --max-crews 3
```

The dispatcher keeps running while there is work. Leave it in a dedicated terminal. It stops itself after it has been idle for a while (the idle watchdog; see [SETTINGS.md](SETTINGS.md)).

### Monitoring running crews

```bash
# Live dashboard (auto-refreshes)
mso status

# Watch one crew
mso crew --crew 1 --watch

# One-shot snapshot, for scripts
mso status --once
```

The **APPROVALS** panel appears when something is waiting for your sign-off. Review those promptly, because crews may be blocked on your decision. See [HUMAN-REVIEW-GATES.md](HUMAN-REVIEW-GATES.md).

### Stopping

To stop taking new work and let running crews finish, drain the fleet:

```bash
mso pause --wait     # drain, then return when the fleet is quiet
mso resume           # start dispatching again
```

If crews are stalled or processes were left behind, clean up:

```bash
mso cleanup
```

`mso cleanup` makes a backup before it removes stale state, so your work is safe. Use `--no-backup` only if you are certain you do not want one.

### Checking completed work

```bash
# List orders and their state
mso order list

# Why is this order where it is?
mso order why FTR-MYPROJ-2026-0001

# Completed order records
ls .mso/orders/complete/

# What a voyage changed (crews commit to the voyage branch)
git log --oneline voyage/VOY-MYPROJ-2026-0001
```

---

## 2. Scaling Crews

### Concurrency limits

`--max-crews` sets the number of concurrent crews (the default comes from the `dispatch.maxCrews` setting; the built-in default is 5). The community tier is limited to 2. See [LICENCE.md](LICENCE.md) for the tier limits. The right number also depends on your API tier and the work:

| Crew count | Suitable for |
|-----------|-------------|
| 1–2 | Exploratory work, tight budget, sequential dependencies |
| 3 | Standard daily operations: balances throughput and rate pressure |
| 4–5 | Large voyages with independent parallel orders; high-tier API access |

```bash
mso dispatch --max-crews 5     # parallel
mso dispatch --max-crews 2     # conservative
```

### Stagger delay

Maestro staggers crew starts to reduce API rate pressure. The default is 30 seconds between launches:

```bash
mso dispatch --max-crews 5 --stagger-delay 60    # slower, for shared API keys
mso dispatch --max-crews 5 --stagger-delay 15    # faster, with a high rate limit
```

### Timeouts and turns

`--timeout` is a **wall-clock ceiling in minutes per crew iteration** (the default comes from `dispatch.timeoutMinutes`; the built-in default is 60). `--max-turns` caps the model turns per iteration (built-in default 200). A crew that goes quiet is caught by the activity watchdog, which is the real hang control.

```bash
mso dispatch --max-crews 3 --timeout 180      # complex orders
mso dispatch --max-crews 5 --timeout 45       # documentation or investigation orders
```

When a crew exceeds its limits, Maestro preserves its work on a salvage branch and requeues the order for another attempt. See [WHEN-A-VOYAGE-IS-STUCK.md](WHEN-A-VOYAGE-IS-STUCK.md) for what to do when an order stops making progress.

### Queue priority

The dispatcher takes work from the highest queue tier first:

| Queue | Priority | Use for |
|-------|---------|---------|
| `queues/explicit/` | Highest | Urgent work you force to the front |
| `queues/security/` | High | Security findings |
| `queues/bugs/` | High | Bugs |
| `queues/requests/` | Medium-High | Follow-on work raised by crews |
| `queues/orders/` | Medium | Standard feature work (default) |
| `queues/defects/` | Medium-Low | Defects found in QA |
| `queues/breakdown/` | Low | Sub-tasks broken down from larger work |
| `queues/high-level/` | Lowest | High-level work awaiting breakdown |
| `queues/escalations/` | Not dispatched | Waiting for a human decision |

See [ORDERS-AND-VOYAGES.md](ORDERS-AND-VOYAGES.md#queue-tiers) for details, including how to raise an order's `priority` without moving its file.

### Horizontal scaling considerations

Each crew runs as an independent `claude` subprocess. On a shared machine, ensure:

- Enough RAM for the crew count (allow roughly 500 MB to 1 GB per crew session)
- Your API key has enough rate limit for your crew count
- `--stagger-delay` spreads API calls over time

---

## 3. Cost Management

### Checking costs

```bash
# Overall usage summary
mso usage --summary

# Breakdown by voyage
mso usage --voyage VOY-MYPROJ-2026-0001

# Token detail for one order
mso usage --order FTR-MYPROJ-2026-0001

# Full usage report to a file
mso usage --report --output .mso/reports/usage-report.md

# Cost by model and reasoning-effort tier over a window, and by role
mso usage --by-effort --days 7
mso usage --by-effort --by-role --days 30
```

Usage that was recorded before effort tracking shipped is bucketed as `unknown` rather than dropped.

### Setting a spend cap

Set a spend ceiling for the workspace with the settings command:

```bash
mso settings set budget.maxUsd 25        # cap this workspace at $25
mso settings set budget.windowDays 30    # optional: count only the last 30 days
mso settings get budget.maxUsd
```

When the cap is reached, the dispatcher holds new dispatch and drains (`budget.onReach` = `pause`, the default) or logs a warning and carries on (`warn`). The cap is checked between crew iterations, so it can be overshot by what running crews go on to spend. See [SETTINGS.md](SETTINGS.md#spend-cap-budget) for the full details.

### Cost-efficient order design

- **Scope orders tightly.** A single focused order (one endpoint, one component) is faster and cheaper than a broad one.
- **Match the model to the work.** Role defaults and per-order overrides are covered in [CONFIG-MODELS.md](CONFIG-MODELS.md), with list prices under [Cost trade-offs](CONFIG-MODELS.md#cost-trade-offs).
- **Keep documentation orders in one voyage.** They are cheap; batching them avoids repeated setup.
- **Set `--timeout` appropriately.** Long timeouts let a crew explore when it is stuck; short ones force faster completion or escalation.

---

## 4. Handling Failures

### Types of failure

| Failure type | Symptom | Action |
|-------------|---------|--------|
| Crew crash | Crew shows as crashed, or its process is gone | `mso cleanup`, then `mso dispatch` |
| Order timeout | The order is requeued, or held as stalled | `mso order why <ID>`, then `mso order retry <ID>` |
| Dependency block | Order stays queued and is not picked up | Check the order's `dependsOn` field; make sure the prerequisites are complete |
| Verify failure | The pre-push check failed | Read the log the message names. `mso order retry <ID>` once fixed |
| API error | Crew exits with an API error | Check the API key and rate limits; retry after a pause |
| Escalation | ESCALATIONS panel appears | Read the file in `.mso/queues/escalations/`, take the indicated action, and re-dispatch |

### Finding out what went wrong

```bash
# Why is this order where it is, and what can I do about it?
mso order why FTR-MYPROJ-2026-0001

# Fleet health
mso doctor

# Warnings and errors in the lifecycle log
grep -E '\| (WARN|ERROR) ' .mso/logs/lifecycle.log

# A crew's progress notes and activity
cat .mso/crews/crew2/progress.md
```

[WHEN-A-VOYAGE-IS-STUCK.md](WHEN-A-VOYAGE-IS-STUCK.md) explains every stuck-state answer and the options Maestro offers for each.

### Retrying an order

`mso order retry` is the supported way to send a failed or stalled order back to the queue:

```bash
# Re-queue an order
mso order retry FTR-MYPROJ-2026-0001

# Retry from a specific role
mso order retry FTR-MYPROJ-2026-0001 --role BLD

# Skip an order the fleet should leave alone, and bring it back later
mso order skip FTR-MYPROJ-2026-0001 --reason "waiting on API access"
mso order unskip FTR-MYPROJ-2026-0001
```

A crew that was killed leaves its work on a salvage branch (`salvage/<order>-<sha>`) and the next crew resumes from it. Check which branch will be used before you retry; `mso order retry --help` lists the salvage options.

### Handling stale state

After an unexpected interruption (machine restart, out-of-memory kill, network loss):

```bash
mso cleanup
mso dispatch --max-crews 3
```

`cleanup` creates a backup snapshot, ends any orphaned crew processes, and clears stale lock files and idle crew state.

---

## 5. Backup Strategy

### What gets backed up

`mso backup` archives the workspace's state: orders (active, complete, failed), voyages, plans, handoffs, usage records and workspace configuration.

### Recommended backup schedule

| Frequency | Command | Rationale |
|-----------|---------|-----------|
| Before each cleanup | Automatic | `mso cleanup` creates a backup unless you pass `--no-backup` |
| End of each voyage | Manual | Capture the complete voyage state |
| Weekly | Cron / scheduled task | Safety net for continuous workspaces |
| Before upgrading Maestro | Manual | Preserve state before the upgrade |

### Creating backups

```bash
# Full workspace backup
mso backup

# One project (multi-project workspaces)
mso backup --project OTM

# A custom output directory
mso backup --output /mnt/backups/maestro/

# List existing backups
mso backup --list
```

Backups are ZIP archives named with the scope and a timestamp, by default under `maestro-backups/` in the workspace:

```
maestro-backups/maestro-backup-all-2026-04-01-090000.zip
```

### Restoring from backup

Always preview before restoring into an active workspace:

```bash
# Preview what would be restored
mso restore maestro-backup-all-2026-04-01-090000.zip --dry-run

# Restore, skipping files that already exist (default, safe)
mso restore maestro-backup-all-2026-04-01-090000.zip

# Restore only one project from a full backup
mso restore maestro-backup-all-2026-04-01-090000.zip --project OTM

# Overwrite existing files (clean-slate restore)
mso restore maestro-backup-all-2026-04-01-090000.zip --force

# Keep the newer file on conflict (merging two workspaces)
mso restore maestro-backup-all-2026-04-01-090000.zip --merge
```

### Offsite backup

Backups are local ZIP files. For durable offsite storage, copy them with your own tooling:

```bash
mso backup --output /tmp/maestro-backups/
aws s3 cp /tmp/maestro-backups/ s3://your-bucket/maestro/ --recursive
```

If your artefacts live in their own repository (see [ARTEFACT-REPO.md](ARTEFACT-REPO.md)), that repository is already a durable copy of the plane.

---

## 6. Notifications

Maestro has no generic webhook subscription. Notifications reach you in these ways:

| Need | Use |
|------|-----|
| Fleet events and commands in Slack, including from your phone | The Slack bridge. See [bridge-setup-guide.md](bridge-setup-guide.md). |
| A regular, no-model summary of each project's state | Project status updates. See [STATUS-UPDATES.md](STATUS-UPDATES.md) (`mso status-updates`). |
| A voyage or plan waiting for your sign-off | The APPROVALS panel in `mso status`, `mso review queue`, or the Hub. See [HUMAN-REVIEW-GATES.md](HUMAN-REVIEW-GATES.md). |
| Something wrong with the fleet | `mso doctor`, or the resident LEAD ([LEAD.md](LEAD.md)), which reports changes between checks. |

Spend alerts: the spend cap (see [Cost Management](#3-cost-management)) holds dispatch or logs a warning when it is reached.

---

## 7. Multi-Project Operations

### Workspace structure for multiple projects

A single Maestro workspace can manage several projects. Each project has its own:

- Acronym, which prefixes its orders (`{TYPE}-{ACRONYM}-{YEAR}-{SEQ}`) and voyages (`VOY-{ACRONYM}-{YEAR}-{SEQ}`)
- Repository, and its own settings

```bash
# Projects registered on this machine
mso projects list

# Add a project (from the project's repository)
mso init --project PROJ2
```

Community tier is limited to one project. See [LICENCE.md](LICENCE.md). For several repositories behind one project, see [MULTI-REPO.md](MULTI-REPO.md).

### Dispatching across projects

The dispatcher takes orders from every project. Orders carry a `project` field that routes them to the right repository. To work on one project only, name it:

```bash
mso dispatch --max-crews 5 --project PROJ1
mso status --once --project PROJ1
```

### Per-project usage and backups

```bash
mso usage --summary --project PROJ1
mso usage --voyage VOY-PROJ1-2026-0001

mso backup --project PROJ1
mso restore maestro-backup-PROJ1-2026-04-01-090000.zip --project PROJ1
```

### Coordination patterns

- **Cross-project dependency.** If work in PROJ2 depends on a completed order in PROJ1, list the PROJ1 order ID in the PROJ2 order's `dependsOn`. The dispatcher holds the PROJ2 order until it completes.
- **One project per voyage.** A voyage is one branch and one pull request, so keep each voyage inside a single project.

---

## 8. Performance Tuning

### Dispatcher configuration

The levers are `--max-crews`, `--stagger-delay`, `--timeout` and `--max-turns`. See [Scaling Crews](#2-scaling-crews). For many small orders, raise `--max-crews` and lower `--stagger-delay`. For a few large orders, use fewer crews with a longer `--timeout`.

### Dependency graph design

Orders with `dependsOn` are held until their prerequisites complete. Poor design creates bottlenecks:

- **Avoid fan-in from many orders to one.** If ten orders all feed a single integration order, it cannot start until all ten finish. Restructure to integrate incrementally.
- **Prefer parallel voyages.** Group independent work into separate voyages.
- **Reserve the explicit queue** for unblocking stalled work, not for routine prioritisation.

### Model selection

Each role has a default model, and the models differ a great deal in cost and capability. Keep the high-volume roles on the cheaper tier and promote individual hard orders with a per-order `model` override rather than moving a whole role. The current table of role defaults, the layers you can override at, and list prices are in [CONFIG-MODELS.md](CONFIG-MODELS.md).

### Order scoping for throughput

Well-scoped orders finish faster and cheaper:

- **One concern per order.** "Implement the cart service" is too broad. Split it into data model, service layer, API endpoints and tests.
- **Name the target files** when you know them, so crews can navigate faster.
- **Write precise acceptance criteria.** Each criterion should be independently verifiable. Vague criteria make crews over-explore.

---

## 9. Team Workflows

### Operator responsibilities

The human operator is responsible for:

- Approving plans and voyages that are gated for review
- Reading escalations and unblocking crews
- Merging completed voyage pull requests
- Watching spend
- Keeping the fleet moving: `mso doctor`, `mso cleanup`, `mso dispatch`

### Handling approvals

When the APPROVALS panel shows an item:

```bash
mso review queue            # what is waiting
mso review show <ID>        # read it
mso review approve <ID>
mso review revise <ID> --notes "Split the migration into its own order"
mso review reject <ID> --notes "Out of scope for this release"
```

The Hub offers the same actions. See [HUMAN-REVIEW-GATES.md](HUMAN-REVIEW-GATES.md).

### Code review workflow

Crew output is committed to the voyage branch. Typical flow:

1. `mso verify --voyage VOY-MYPROJ-2026-0001` runs the build and tests
2. `git log --oneline voyage/VOY-MYPROJ-2026-0001` shows the commits
3. Review the voyage's pull request
4. Merge it through your normal PR process

### Shared workspace (several operators)

If several operators use one workspace:

- Only one operator should run `mso dispatch` at a time
- A workspace written by more than one machine needs shared artefact mode. See [ARTEFACT-REPO.md](ARTEFACT-REPO.md)
- Use the Slack bridge or the Hub to tell the team about approvals ([bridge-setup-guide.md](bridge-setup-guide.md), [HUB.md](HUB.md))

### Escalation handling

When a crew raises an escalation:

1. The ESCALATIONS panel appears in the dashboard
2. Read the file in `.mso/queues/escalations/`
3. Work out the blocking issue (ambiguity, permissions, a missing dependency)
4. Take the indicated action: update the order, provide the missing access, clarify the requirement
5. Re-queue or retry the order, then `mso dispatch` again

---

## 10. Reporting

### Usage reports

```bash
mso usage --summary                                       # console summary
mso usage --voyage VOY-MYPROJ-2026-0001                   # per voyage
mso usage --report --output .mso/reports/usage-report.md  # full markdown report
mso usage --by-role --days 30                             # by role over a window
mso usage --by-backend                                    # by model backend
```

### Status history

```bash
mso status-updates --last 10            # recent per-project status updates
mso status-updates --project MYPROJ --json
```

### Lifecycle and audit log

The fleet writes lifecycle events (crew starts, completions, role transitions, failures) to `.mso/logs/lifecycle.log`.

```bash
# Recent lifecycle events
tail -50 .mso/logs/lifecycle.log

# Warnings and errors only
grep -E '\| (WARN|ERROR) ' .mso/logs/lifecycle.log
```

For a tamper-evident audit trail on Enterprise, see [ENTERPRISE-ADMIN-GUIDE.md](ENTERPRISE-ADMIN-GUIDE.md).

---

*Maestro · Pricing and licensing enquiries: [maestrodevs.com/contact](https://www.maestrodevs.com/contact/).*
