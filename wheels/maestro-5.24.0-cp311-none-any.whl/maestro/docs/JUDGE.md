# The Judge

> **Status in this release: foundations only. Leave the Judge off for now.**
> This release ships the Judge in `off` and `shadow` modes. It watches and
> records; it **cannot approve, retry, reject or change anything**. It is
> not ready for use yet (see [Known limits](#known-limits)), so do not turn
> `judge.enabled` on.

The Judge is a separate **decision agent** that works the Captain's approval
queue under rules the Captain wrote. The two agents are deliberately distinct:

| Agent | Job |
|-------|-----|
| **LEAD** (`mso lead`) | Operates the fleet: patrol, reconcile, chat. See [LEAD.md](LEAD.md). |
| **Judge** | Decides, within rules you set and limits you cannot change. |

The Judge's pass runs inside the resident LEAD's tick, but the Judge takes no
instructions from the LEAD and has none of its powers. Its authority comes only
from the rules you give it.

In the nautical persona the Judge is the **Judge Advocate**. The title is
cosmetic; the mechanics are identical in every persona (see
[PERSONAS.md](PERSONAS.md)).

---

## What it does today

The first decision kind is **`plan.approve`**: a PLN order whose plan is waiting
at the human review gate (`NAV_REVIEW_PENDING`).

In `shadow` mode the Judge:

1. Notices each plan waiting for your review and opens a **docket item** for it.
2. Works out what it **would** rule: approve, or escalate to you.
3. Records that ruling on the docket. It does **not** act on it, show it on the
   review card, or tell you.
4. When you then approve, revise or reject the plan yourself, records what you
   did and whether the two of you **agreed**.

That agreement record is the point of shadow mode. Before any later release lets
the Judge act, you can look at how often it would have matched you.

**Shadow never touches your work.** It writes no order, no review, no decision.
Your orders are byte-for-byte what they would have been without it.

Later releases add `advise` (the Judge's recommendation shown beside the
review), then `decide` (the Judge applies it, after an optional delay you can
hold or overturn). Neither exists yet: the settings refuse them.

---

## Requirements

| | |
|---|---|
| **Tier** | Pro, Team or Enterprise (the same tiers as the resident LEAD). Below Pro the Judge does nothing and writes nothing. |
| **Runs inside** | A running resident LEAD (`mso lead start`). No LEAD, no Judge pass. |
| **Artefact mode** | Not supported in `shared` artefact mode in this release. |
| **Default** | Off. `judge.enabled` is `false` and every mode is `off`. |

On the command line, `mso judge limits`, `rules list` and `rules show` read
static data and work on any tier. Everything that changes a rule or runs a pass
needs Pro or above, and so does every view on the Hub's Judge page, the hard
limits included: below Pro the Hub refuses it.

---

## How a plan is judged: the order of precedence

Every item goes through the same steps, **strongest first**. The first step that
objects wins, and nothing later can undo it.

1. **Hard limits.** Fixed in the product (listed [below](#the-hard-limits)).
   Nobody can change them, including you.
2. **Risk checks.** Deterministic checks of the order and its plan for work that
   touches sensitive areas. Any finding escalates.
3. **Deny and escalate rules**, at any layer. If one matches, the item
   escalates.
4. **Allow rules.** Only a rule that is **enabled** and has been enabled through
   Maestro can allow anything. If none matches, the item escalates.
   **The default answer is "ask the Captain".**
5. **A model review**, which can only **restrict**. It may add a concern and
   turn an allow into an escalation. It can never turn an escalation into an
   approval, and its output cannot even express an approval.

Two consequences worth knowing:

- A **workspace** rule can never loosen a **global** deny. A workspace allow
  cannot beat a global deny; a workspace deny can narrow a global allow.
- An allow rule edited by hand after you enabled it stops counting until you
  enable it again. Maestro logs `JUDGE_RULE_UNRATIFIED` when it notices, so a
  hand edit can never make an allow rule count.
- Deny and escalate rules count without being enabled through Maestro in this
  release. Removing or narrowing one by hand therefore loosens what it guarded,
  and nothing records it. Bringing those changes under the same enable-through-
  Maestro record as allow rules is scheduled before the Judge can act.

---

## Rules

A rule is a plain-language statement plus a small, fixed set of conditions. There
are no expressions to get wrong.

| Layer | Applies to | Stored |
|-------|------------|--------|
| **Global** (`JR-G-NNNN`) | Every workspace on this device | Your device |
| **Workspace** (`JR-W-<PROJECT>-NNNN`) | One project | The workspace's artefact plane, committed like schedules |

| Effect | Meaning |
|--------|---------|
| `allow` | The plan may be approved (subject to every earlier step) |
| `deny` | Never decide this; ask me |
| `escalate` | Always ask me |

Conditions (`when`), all optional and combined with AND:

| Flag | Condition |
|------|-----------|
| `--order-type-in BUG,FTR` | The order's type is in the list |
| `--files-at-most N` | The plan's Impact Map lists at most N files |
| `--paths-none-match GLOB` | No Impact Map path matches the glob (repeatable) |
| `--role-sequence-includes TST,SEC` | The order's role sequence includes those roles |
| `--voyage-id-in VOY-…` | The order is in one of those voyages |
| `--severity-at-most LEVEL` | Every finding is at most this severity |

An unknown condition is **refused** when you add the rule, and **disables** the
rule if it reaches the file some other way. An unknown condition never widens a
rule.

### Managing rules

```bash
mso judge limits                     # the shipped hard limits (read-only)
mso judge rules list [--scope global|workspace]
mso judge rules show JR-W-MSO-0001
mso judge rules add --statement "Approve small BUG plans" --effect allow \
    --kind plan.approve --order-type-in BUG --files-at-most 5 \
    --paths-none-match "maestro/docs/**" --role-sequence-includes TST
mso judge rules add --scope global --effect deny --kind plan.approve \
    --order-type-in INV --statement "Never decide INV plans; always ask me"
mso judge rules edit JR-W-MSO-0001 --files-at-most 3
mso judge rules enable JR-W-MSO-0001     # enables it as it is written now
mso judge rules disable JR-W-MSO-0001
```

- `rules enable` is what turns an allow rule on. It enables exactly what the
  rule says at that moment. Editing a rule through `rules edit` keeps an
  enabled rule enabled for its new wording; a rule that was changed by hand
  outside Maestro stays ignored until you run `rules enable` on it.
- Only a human can change rules. The Judge and dispatched crews are refused.
- Rule changes need the `judge.rules.manage` capability and Pro or above.

### If the rule record is reported truncated

Maestro keeps a signed record of every rule change on your device, and checks
that the record has not been cut short, deleted or swapped for an older copy.
If it has, the log says so (`JUDGE_LEDGER_UNREADABLE` naming a truncated or
missing record), the Judge asks you about **every** plan, and rule changes are
refused until it is resolved.

Find out what changed it first. Then start a fresh record:

```bash
mso judge rules reset-ledger --scope workspace    # or --scope global
```

The command shows what it will do and asks before changing anything (pass
`--yes` when there is no terminal). The old record is kept beside the new one,
not deleted. Afterwards nothing is enabled until you say so again: run
`mso judge rules enable <id>` for each rule you still want; the command lists
them. Resetting needs `judge.rules.manage` for the whole workspace.

**Moving a workspace counts as a missing record.** The record is tied to the
workspace's location on disk. If you move or rename the workspace folder, change
its drive letter, or clone it afresh, Maestro reports the record as missing and
the Judge asks you about every plan. Run
`mso judge rules reset-ledger --scope workspace`, then re-enable the rules you
still want.

---

## The CLI

All the docket verbs accept `--json` and `--project ACRONYM`.

| Command | What it shows |
|---------|---------------|
| `mso judge status` | Whether the Judge is on (and if not, why), each kind's mode, the model, today's token spend against its ceiling, and docket counts |
| `mso judge docket [--pending\|--escalated\|--decided] [--kind K]` | Docket items. No flag lists everything |
| `mso judge show <DKT-id>` | One item: the ruling, rules cited, limits and risks hit, and what the Captain did |
| `mso judge agreement [--kind K]` | Agreement with you over the last 90 days |
| `mso judge limits` | The hard limits |
| `mso judge rules …` | Rules (see above) |
| `mso judge run --once [--dry-run]` | One Judge pass now. Pro or above |

Notes:

- `status`, `docket`, `show` and `agreement` need the `judge.docket.view`
  capability.
- `run` is refused if the caller is a dispatched crew.
- **`--dry-run` writes nothing and calls no model.** It reports what each plan
  would be ruled. Anything that would otherwise be allowed is reported as an
  escalation with reason `dry-run`, because the model step is skipped.
- `status` prints the title from your persona, for example `[Judge Advocate] on`.

Docket ids look like `DKT-PLN-MSO-2026-1300-plan.approve-3fa9c2d1`. The same plan
always produces the same id, so running the Judge twice never creates duplicates.
When the plan changes, the old item is voided and a new one is opened.

### Reading agreement

Agreement counts only items you have already resolved, in `shadow` or `advise`
mode, over the last 90 days.

| The Judge said | You | Counted |
|----------------|-----|---------|
| approve | approved | agreed |
| approve | revised or rejected | disagreed |
| escalate | revised or rejected | agreed |
| escalate | approved | disagreed |

With no samples the rate shows as `-`, never `0%`.

Maestro infers what you did from what happened to the order: it moved on
(approve), it went back to the gated role (revise), or it failed with
"rejected at …" (reject). A review stamped by an agent is ignored.

---

## In the Hub

On Pro and above the Hub has a **Judge** page, in the sidebar between Review and
Reports. It is **read-only** in this release.

- **Docket**: Pending, Shadow, Escalated and Decided tabs. Escalated rows show
  the recommendation and an "Open in Review" link (it opens the review queue;
  it does not preselect the order yet).
- **Agreement**: the rate per kind, "agreed of resolved", and the list of
  disagreements.
- **Hard limits**: the list below, with no controls.
- A **workspace** selector and a **kind** filter. The workspace comes from
  `?workspace=` and otherwise the first registered workspace.

The workspace page's LEAD panel gains one line, for example:

```
Judge: on — plan.approve=shadow, 3 pending, 1 escalated
```

Modes that are off are left out; when the Judge is off it names the reasons. The
line links to the Judge page, and is hidden when the status is unknown or
refused. Details of every Hub screen are in [HUB.md](HUB.md).

---

## Settings

Five keys, all per workspace. See [SETTINGS.md](SETTINGS.md) for the registry
table and `mso settings` for changing them.

| Key | Default | Meaning |
|-----|---------|---------|
| `judge.enabled` | `false` | Master switch |
| `judge.mode.plan.approve` | `off` | `off` or `shadow`. `advise` and `decide` are refused in this release |
| `judge.model` | `claude-opus-5-5` | Claude model used for the review step. Open-weights models are refused |
| `judge.tokenCeiling.dailyTokens` | `300000` | The Judge's own daily token budget, separate from patrol and chat. `0` means the model is never called |
| `judge.confidenceFloor` | `0.8` | Between 0.8 and 1.0: it can be raised, never lowered. Below it, the Judge escalates. Out-of-range values are **refused, not clamped**; a hand-edited value from 0.5 up to 0.8 reads as 0.8, any other invalid value as 1.0 |

A hand-edited invalid value fails **closed**: the mode reads as `off`, the
floor as `1.0` and the ceiling as `0`.

When the daily ceiling is reached, every new item escalates with reason
`ceiling` and the model is not called. The Judge never decides *more* because it
ran out of budget.

---

## Reading the log

`.mso/logs/lifecycle.log` records the Judge's activity. Events that need a look
lead with `WARN` or `ERROR`.

| Event | Meaning |
|-------|---------|
| `JUDGE_DOCKETED` | A plan was opened as a docket item |
| `JUDGE_SHADOW` | A shadow ruling was recorded, or reconciled with your action |
| `JUDGE_ESCALATED` | The Judge would have asked you (shadow: recorded only, nothing sent) |
| `JUDGE_CEILING_HIT` | WARN. The daily token ceiling was reached |
| `JUDGE_DISABLED` | WARN, once per process. The Judge is on but did nothing: stand-down, shared artefact mode, or every mode `off`. Below Pro, or `judge.enabled=false`, logs nothing |
| `JUDGE_ERROR` | ERROR, once per distinct error. A pass failed; patrol carries on |
| `JUDGE_RULE_INVALID` | WARN. A rule is malformed and disabled |
| `JUDGE_RULE_UNRATIFIED` | WARN. An allow rule was edited by hand or never enabled, and is ignored |
| `JUDGE_LEDGER_RESET` | WARN. You reset a rule record with `mso judge rules reset-ledger`; re-enable the rules you still want |
| `JUDGE_LEDGER_MARK_LAG` | WARN. A rule change was recorded but its tamper check could not be updated; the next rule change retries |

---

## The hard limits

These are fixed in the product and apply to every kind, every mode and every
rule. They are statements of what the Judge will **never** do:

| Id | The Judge will never… |
|----|-----------------------|
| HL1 | approve or retry anything that touches a production database, infrastructure, secrets/credentials, authentication/authorisation, payments, or data deletion |
| HL2 | merge, tag, release or publish |
| HL3 | waive or accept a HIGH or CRITICAL finding (an unreadable severity counts as HIGH) |
| HL4 | create, edit, enable, disable or ratify a rule, a mode or a limit |
| HL5 | guess: when it is uncertain whether something is in scope, it escalates |
| HL6 | reject, fail, skip, remove or abandon work |
| HL7 | re-rule a subject you overturned or held |
| HL8 | rule when the caller is a dispatched crew |
| HL9 | apply a ruling whose subject changed after it was evaluated |

`mso judge limits` prints the same list.

---

## Privacy and who can see what

- The docket is **device-local runtime state** under the workspace's `state/`
  directory. It is not committed and is not shared between machines. Dispatched
  crews cannot write to it.
- The review step reads the plan and order text, which are crew-authored. They
  are passed to the model as clearly delimited data, never as instructions, and
  the model has no way to approve.
- Workspace rules are committed with the workspace artefacts; global rules stay
  on your device.
- This release reads **nothing** from your chats or Claude Code sessions. Any
  later source of learned rules will be opt-in and off by default.
- Every Judge action is written to the audit log where one is configured
  (Enterprise).

### Identity

The Judge acts as its own fixed principal, `agent:judge`, never as you. An agent
principal is never granted a capability through a wildcard (`*`) or a group, so
giving the Captain group everything does not give the Judge anything. Three
capabilities exist:

| Capability | Held by |
|------------|---------|
| `judge.decide` | `agent:judge` only |
| `judge.docket.view` | The fleet-operator group |
| `judge.overturn` | Captains (reserved for a later release) |

On a Pro solo workspace there is no access-control list in force, so capability
checks are bookkeeping rather than a barrier there. What protects you on every
tier is that the Judge's actions are limited by the hard limits and the closed
set of things it can do, not by who it says it is. See
[CAPABILITIES.md](CAPABILITIES.md) and [GOVERNANCE-TRUST-BOUNDARY.md](GOVERNANCE-TRUST-BOUNDARY.md).

---

## Known limits

- **Not ready for use.** A security follow-up is still open. **Leave
  `judge.enabled` at `false`.**
- **No docket pruning.** Items accumulate on the device. Agreement reads only the
  last 90 days.
- **Items can stay `shadowed`** if the order was removed without a review, or
  disappeared from every queue.
- The Hub page and the CLI display text from plans and notes; treat the docket
  as read-only evidence.
- Only `plan.approve` exists. Other decision kinds are planned.

---

## See also

- [LEAD.md](LEAD.md): the resident agent the Judge runs inside
- [HUMAN-REVIEW-GATES.md](HUMAN-REVIEW-GATES.md): the gates the Judge shadows
- [SETTINGS.md](SETTINGS.md): the `judge.*` keys
- [PERSONAS.md](PERSONAS.md): the Judge's title per persona
- [HUB.md](HUB.md): the Judge page
