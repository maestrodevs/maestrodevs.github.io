# Configuring your stack (`providers`)

**New in v5.14.0; `model` added in v5.15.0.** Maestro talks to your git host,
your CI system, your issue tracker — and the service your crews' Claude
sessions run against — through a small **capability seam**, not by hard-coding
`gh`. The dispatcher, `mso doctor`, the resident LEAD sub-agent, and the
Releaser (REL) role all ask for a **capability** — source control (`scm`), CI
(`ci`), issue tracking (`issues`), deployment (`deploy`), model backend
(`model`) — and Maestro resolves whichever provider your workspace is
configured for. If your organisation runs
Bitbucket instead of GitHub, or Jenkins instead of GitHub Actions, or Jira
instead of GitHub Issues, the same checks and the same REL completion pass
run unchanged — a missing or unreachable provider degrades honestly (a
named, visible skip) instead of silently assuming GitHub.

## The five capability kinds

| Kind | What it's used for | Shipped providers |
|------|---------------------|----------------|
| `scm` | Pull/merge request state — open/merged/draft, review threads, branch + PR creation, mark-ready | `github`, `bitbucket` |
| `ci` | Build/check status for a pull request, failed-step logs | `github_actions`, `jenkins` |
| `issues` | Reading a linked issue's state (read-only from a crew's perspective) | `github_issues`, `jira` |
| `deploy` | Last-deployment status for an environment | *(none shipped yet)* |
| `model` | The backend every crew's Claude session runs against | `anthropic` (default), `bedrock` (Enterprise) |

**`model` is the one kind that is never "not configured".** The other four
degrade to a `none` provider when they aren't wired up; a crew always has to
talk to *something*, so `model` falls back to `anthropic` — the direct Anthropic
API, which is what every workspace used before the kind existed. Omitting the
block is identical to configuring `anthropic`. See
[MODEL-BACKENDS.md](MODEL-BACKENDS.md) for the full guide, including AWS Bedrock
setup, credential expiry behaviour, model-id translation, and what differs on a
non-default backend.

Every kind also has a built-in `none` provider — the honest default when a
capability isn't wired up. A check or a REL step that depends on an
unconfigured or unreachable provider is always reported as **skipped, with a
reason** — never silently passed and never counted as a false success. Run
`mso doctor --explain` or `mso providers test <kind>` to see, per kind, which
provider is currently resolved, which configuration tier supplied it, and
why it is or isn't available.

**Deploy** has no real provider yet — Bitbucket/Jenkins/Jira closed the
`scm`/`ci`/`issues` gap; a deploy provider (e.g. reading a Kubernetes
rollout or a hosting platform's release status) is a separate, additive
order, not part of this feature.

## Quick start

```bash
mso providers list                  # what's installed, what's configured, per kind
mso providers show scm              # one kind's configured entry + resolved outcome
mso providers test scm              # resolve it right now — same shape as `mso doctor --explain`
```

Or configure interactively during first-run setup — `mso setup` includes an
**SDLC providers** step that inspects your git remote and detected CI system
(`.github/workflows/`, a `Jenkinsfile`) and proposes providers accordingly,
then asks and writes through the one config core (below). Re-run `mso setup`
at any later point to change the stack; accepting the current default makes
no write.

## Configuring a provider

`mso providers set <kind> <id> [--config KEY=VALUE ...]` is the one command
that changes what's configured — the CLI, `mso setup`'s SDLC-providers step,
and the Hub's Providers section (Pro/Team/Enterprise) all write through the same
core module (`maestro/providers/config.py`), so a change made in one place is
visible everywhere else.

```bash
mso providers set scm github --config slug=your-org/your-repo
mso providers set scm bitbucket --config flavour=cloud --config workspace=acme --config repo=your-repo \
    --config token=env:BITBUCKET_TOKEN
mso providers set ci jenkins --config host=https://ci.example.com --config jobPath=your-org/your-repo \
    --config user=env:JENKINS_USER --config apiToken=env:JENKINS_TOKEN
mso providers set issues jira --config host=https://yourorg.atlassian.net --config email=you@yourorg.com \
    --config apiToken=env:JIRA_TOKEN
mso providers set model bedrock --config region=ap-southeast-2 --config awsProfile=corp
mso providers unset scm             # revert a kind to the shipped default
```

Equivalently, this is exactly the block `mso providers set` writes into
`.mso/config/workspace.json`:

```jsonc
{
  "providers": {
    "scm":    { "id": "github", "config": { "slug": "your-org/your-repo" } },
    "ci":     { "id": "github_actions" },
    "issues": { "id": "github_issues" },
    "deploy": { "id": "none" },
    "model":  { "id": "anthropic", "config": {} }
  }
}
```

Omit the `providers` block entirely and Maestro picks a sensible default: for
`scm`/`ci`/`issues` it uses the GitHub providers if the `gh` CLI is installed
and authenticated, otherwise `none`. `deploy` has no shipped provider yet, so
it is always `none`. `model` defaults to `anthropic` — the direct Anthropic
API — so the `"model"` line above is exactly equivalent to leaving it out.
Nothing assumes GitHub is present — absence is detected, never guessed.

**Mixed stacks are first-class.** GitHub + Jenkins, Bitbucket + GitHub
Issues, Bitbucket + Jenkins + Jira — any combination is supported, because
each kind resolves independently. The one real coupling is CI↔SCM: Jenkins
locates "the build for this PR" by the PR's own head branch/SHA (below), not
by anything GitHub-shaped, so it works the same whether the PR itself lives
on GitHub or Bitbucket.

## Where configuration comes from

A `providers` block resolves the same way the rest of your workspace's
governed settings do — the most specific applicable source wins:

1. A signed governance bundle (Enterprise only) — a kind it pins is reported
   **locked**, and `mso providers set`/`unset`/the Hub's Providers section all
   refuse to change it.
2. Your workspace's own `.mso/config/workspace.json` `providers` block.
3. The shipped default described above.

A division/team pack applied at `mso init` time can pre-populate the
`workspace.json` entry for you, so day-to-day resolution is really "did a
bundle override this, otherwise use what's in `workspace.json`."

## Credentials

**`workspace.json` never holds a credential value.** A config field whose
name looks like a credential (`token`, `password`, `secret`, `apiKey`,
`credential`, `auth`, `pat`, etc.) must be given as one of two *references*,
never a literal — `mso providers set` refuses a pasted token before it
reaches disk, with a message explaining why:

- **`env:NAME`** — reads the named environment variable **at the point of
  use**, on any licence tier. This is how `gh` itself resolves `GH_TOKEN` —
  Bitbucket, Jenkins and Jira have no CLI that owns a token the way `gh`
  does, so `env:` is the supported way to give them one without a Team or
  Enterprise licence.
- **`secret://provider/namespace/key`** — resolved through Maestro's
  existing secrets registry (OS keyring, AWS/Azure secrets manager, etc.),
  **Enterprise only**. On a non-enterprise workspace a `secret://` reference
  is left as a literal string and will not resolve — use `env:` instead.

Both forms go through the same resolution function
(`maestro.secrets.refs.resolve_secret_refs`) — this is a second *reference
scheme* on the one credential path, not a second credential path. Resolved
values are scrubbed from install/crew logs the same way every other
integration's credentials already are.

## Egress (self-hosted providers)

A provider's configured host must be on your workspace's allowed outbound
destinations list if you run in restrictive or air-gapped egress mode
(`dataResidency.mode` / `dataResidency.allowedDestinations` under
`enterprise` workspaces — a non-enterprise workspace imposes no restriction
at all). A host that isn't allowed surfaces as a skipped check or REL step
naming the reason (`host not permitted: ...`), never a crash and never a
silent pass. Run `mso data-flow` to review and manage that allowlist (see
[CLI-REFERENCE.md](CLI-REFERENCE.md)).

There is **no special-casing for localhost or LAN hosts** — a local Jenkins
or a Bitbucket/Jira Data Center instance on your network is allowlisted the
same way any other host is, via the same `dataResidency.allowedDestinations`
glob list. Bitbucket additionally refuses to send its credential over plain
`http` to anything that isn't a local host, regardless of the egress policy.

## Providers, one by one

### `scm: github` (default)

| Config key | Purpose |
|------------|---------|
| `slug` | `owner/repo` — inferred from the repository if omitted |
| `host` | Override the GitHub host (e.g. a GitHub Enterprise Server instance) |
| `repoPath` | Local checkout path, if it differs from the workspace root |

Uses the `gh` CLI's own authentication (`gh auth status`) — no separate
credential configuration needed. Review-bot threads default to
`copilot-pull-request-reviewer`.

**Minimum token scope** (when `gh` is authenticated with a fine-grained PAT
rather than the interactive login): `repo` read/write (or the fine-grained
equivalent: Contents, Pull requests, and Issues — read and write) so REL can
push fixes, reply to and resolve review threads, and read linked issues. A
fine-grained PAT can omit the Administration/merge permission entirely —
Maestro never calls a merge endpoint, so withholding merge at the token
level is a real, additional control, not just a documented promise.

### `scm: bitbucket` (Cloud + Data Center)

One provider class handles both flavours, selected by `flavour`:

| Config key | Purpose |
|------------|---------|
| `flavour` | `cloud` or `datacenter` (`server`/`dc` also accepted) — **required** |
| `host` | API host. Defaults to `api.bitbucket.org` for Cloud; **required** for Data Center |
| `scheme` | Data Center only — `https` (default) or `http`; `http` is refused for a non-local host |
| `contextPath` | Data Center only — REST context path prefix, if your instance isn't mounted at the root |
| `workspace` + `repo` | Cloud — the repository's workspace and slug |
| `project` + `repo` | Data Center — the project key and repo slug |
| `slug` | Alternative to the pair above — `owner/repo`-shaped |
| `user` | Optional — when set, credentials use HTTP Basic (`user:token`); otherwise Bearer |
| `token` | **Credential** — `env:NAME` or `secret://...` (see [Credentials](#credentials)) |
| `caBundle` | Path to a private CA PEM, for a Data Center instance with an internal cert |
| `repoPath` | Local checkout path, if it differs from the workspace root |

**Minimum token scope:** an app password / access token with **repository
read** and **pull request write** (Cloud) or the equivalent repository
read + pull-request write permission (Data Center) — enough to read PR
state, review threads, and reply/resolve, but not enough to merge on its
own if your Bitbucket project's branch permissions require a named approver
for merge. **Bitbucket exposes no merge action anywhere in Maestro** — there
is no `merge` method on the provider class at all, so this isn't a
configuration choice, it's a structural absence (`grep -n "/merge"
maestro/providers/scm/bitbucket.py` returns nothing).

**Known Data Center gaps**, honestly reported as `unsupported` rather than
guessed at: resolving a review thread (the `threadResolved` field's exact
behaviour is unverified against older server versions) and marking a draft
PR ready (draft support varies by Data Center version, verified from 8.18+).
Cloud has neither limitation. See `tests/fixtures/providers/bitbucket/README.md`
for the fixture-level detail.

### `ci: github_actions` (default)

No provider-specific config — reads checks for the PR `scm` resolved,
through `gh`.

### `ci: jenkins`

| Config key | Purpose |
|------------|---------|
| `host` | Jenkins base URL |
| `jobPath` | Multibranch pipeline job path (slash-segmented) |
| `checkName` | Display name reported for the resolved build (default `jenkins`) |
| `user` + `apiToken` | HTTP Basic credentials — **both** required for authenticated access, or requests are sent unauthenticated |
| `repoPath` | Local checkout path, if it differs from the workspace root |

**Finding the build for a PR:** Jenkins has no native concept of "the PR" —
the provider first tries the multibranch sub-job named after the PR's own
head branch, then a synthesised `PR-<id>` job name. If neither's `lastBuild`
matches, it falls back to scanning each candidate job's recent builds (up to
20) for one whose git-plugin revision SHA matches the PR's head SHA (full or
7-character prefix). No match at all is reported as an empty check list with
a reason — **never a fabricated pass**.

**Minimum token scope:** an API token for a Jenkins user with **read** access
to the job(s) named by `jobPath` — no build/execute permission is needed,
since Maestro only reads build results and console logs, never triggers a
build.

**Local/self-hosted Jenkins:** allowlist `host` in
`dataResidency.allowedDestinations` exactly as you would any other host (see
[Egress](#egress-self-hosted-providers) above) — a local or LAN instance
gets no special treatment.

### `issues: github_issues` (default)

No provider-specific config — resolves through `gh`.

### `issues: jira` (Cloud + Data Center)

| Config key | Purpose |
|------------|---------|
| `host` | e.g. `https://yourorg.atlassian.net` (Cloud) or `https://jira.example.com` (Data Center) |
| `flavour` | `cloud` (default, REST API v3) or `datacenter` (REST API v2) |
| `email` | Cloud — paired with `apiToken` for HTTP Basic |
| `apiToken` | **Credential** — Cloud API token (with `email`), or a Data Center bearer token if `pat` is unset |
| `pat` | **Credential** — Data Center Personal Access Token (Bearer); takes priority over `apiToken` when both are set |
| `closeTransitionName` | Workflow transition name matched case-insensitively for `close_issue` (default `done`) |

**What REL actually does with this provider:** read a linked issue's state
and report it. **Nothing in Maestro calls `update_issue` or `close_issue`
from a crew's own context** — moving a ticket is a project-management
decision the Captain owns (see [`maestro/roles/REL.md`](../roles/REL.md)
`must_not` item 10). The methods exist on the provider class for future,
explicitly Captain-invoked tooling, not for autonomous use today.

**Minimum token scope:** an API token (Cloud) or PAT (Data Center) scoped to
**read** access on the projects your voyages reference — write/transition
scope is not needed for anything a crew does today.

### `model: anthropic` (default)

The direct Anthropic API — what every workspace used before the `model` kind
existed. No provider-specific config, no credential configuration, and no
availability probe: the credentials are the `claude` CLI's own (an interactive
OAuth session, a keychain entry, or `ANTHROPIC_API_KEY` in the dispatcher's
environment), resolved inside the crew process at launch. Omitting the
`providers.model` block resolves to this.

### `model: bedrock` (Enterprise)

Claude served through your own AWS account, on the Bedrock InvokeModel path, the
Mantle endpoint, or both. Full guide: **[MODEL-BACKENDS.md](MODEL-BACKENDS.md)**.

| Config key | Purpose |
|------------|---------|
| `endpoint` | `invoke` (default), `mantle`, or `both` |
| `region` | AWS region — falls back to `AWS_REGION`, `AWS_DEFAULT_REGION`, the named profile's region, then `ap-southeast-2` |
| `regionPrefix` | Pin the inference-profile prefix (e.g. `global`) instead of deriving it from the region |
| `awsProfile` | A profile **name** from `~/.aws/config` — never a credential |
| `pinRoleDefaults` | Pin `ANTHROPIC_DEFAULT_*_MODEL` to their backend ids (default `true`) |
| `modelMap` / `mantleModelMap` | Per-model id overrides, per endpoint |
| `baseUrl` / `mantleBaseUrl` | Endpoint URL overrides — subject to the egress allowlist |
| `serviceTier` | Bedrock service tier |
| `mantleSkipSignin` | Skip the Mantle sign-in step |
| `pricingOverrides` | Your negotiated rates, per model, in USD per million tokens |

**There is no AWS credential field, at all.** Not "it must be an `env:`
reference" — no access key, secret key, session token or bearer token key
exists. Credentials reach a crew through the AWS credential chain, which the
crew inherits from the dispatcher's environment; you establish them yourself
with `aws sso login --profile <name>` (or `aws login`), which opens a browser
and creates a time-boxed session. **Maestro never runs that command** — when the
session expires it holds new dispatch, leaves running crews alone, and tells you
the command to run.

**Model ids are translated at dispatch, never in your artefacts.**
`claude-opus-5` stays the id in every order, overlay and usage record; the
backend-native id appears only on the crew's `--model` argument. A model with no
mapping **refuses the launch** naming the config key to set — it never
substitutes a different model.

**Cost on a non-default backend is reported as `unpriced`** unless you supply
`pricingOverrides`, because Maestro's built-in rate table is the first-party one
and is not your AWS bill. Token counts are unaffected.

### Checking the model backend — `mso doctor`

Two patrol checks answer the two questions worth asking before a crew is
launched. Both **report**; neither remediates, and neither needs a running
dispatcher — they read your configuration and ask the backend directly, so they
answer correctly with the fleet stopped.

| Check | Fires when | Suggested next step |
|-------|-----------|---------------------|
| `model.backend-credentials` | The configured backend cannot be reached — every crew launched now would come up, be refused, and die | `mso providers test model` (plus whatever the backend's own message names, typically `aws sso login --profile <name>`) |
| `model.backend-unmapped-role` | A role's resolved model is one the backend cannot serve — every crew for that role is refused at launch | `mso providers set model <backend> --config modelMap.<model>=<backend-native id>` |

```bash
mso doctor            # human-readable
mso doctor --json     # the same findings, machine-readable
```

Three things these checks deliberately do **not** do:

* **An undeterminable credential state is a SKIP, never a failure.** No `aws`
  CLI on the machine, an instance-role host, a probe that timed out — none of
  those is evidence of anything, so `mso doctor` reports the check as skipped
  with the reason rather than raising a finding you can never clear.
* **An unconfigured workspace is silent, and is not probed at all.** If you have
  no `providers.model` block, nothing is instantiated and no subprocess is
  spawned — these checks cost you nothing.
* **No credential, profile name or raw backend output reaches
  `mso doctor --json`.** Every sentence in a finding is either Maestro's own or
  one the backend already composed and capped.

The credential hold also appears in the Maestro Hub, as a banner on the
workspace page and a marker on the workspace card — the same sentence `mso
status` prints in its footer, rendered verbatim. It sits **beside** the
dispatcher state rather than replacing it: a dispatcher holding on credentials
is still running and still ticking, it is simply not claiming new work.

## What REL uses this for

Once a provider is configured, the Releaser (REL) role resolves the voyage's
pull/merge request, CI status, and linked issues through it — never through
a raw `gh`/`curl`/provider REST call — via the `mso pr` command group:

```bash
mso pr status                              # the voyage PR: id, URL, head/base, draft, merged
mso pr checks                              # CI checks on the voyage PR
mso pr ci-log "pytest (3.13)"              # failed-step log of one check
mso pr threads                             # review threads, flagging bot-authored ones
mso pr reply THREAD --body "Fixed in ..."  # reply on a review thread
mso pr resolve THREAD                      # resolve a review-bot thread
mso pr ready [--post]                      # the six ship gates: READY / NOT READY (+ evidence comment)
```

Every `mso pr` action resolves the PR from `$MAESTRO_VOYAGE_BRANCH` — there
is deliberately no PR-number argument. `mso pr resolve` refuses a thread
whose author isn't one of the workspace's configured review bots (default
`copilot-pull-request-reviewer` on GitHub, empty on Bitbucket — a human
thread is always the Captain's to close, on every provider).

`mso pr ready` reads the PR's mergeability from the provider. GitHub reports it; Bitbucket and the
`none` provider report `UNKNOWN`, which keeps the verdict NOT READY. Only GitHub can post the
evidence comment (`--post`); the others report `UNSUPPORTED`. See [SHIP-GATE.md](SHIP-GATE.md).

**No provider anywhere in Maestro exposes a merge, tag, or release method.**
That absence is deliberate and total — see
[`maestro/roles/REL.md`](../roles/REL.md) for the full completion checklist,
and the [Roles Guide](ROLES-GUIDE.md#coxswain-cox) for what REL's
voyage-completion pass covers and what stays the Captain's regardless of
which providers are configured.

`mso release preflight` (read-only) and `mso release cut <VERSION>`
(Captain-invoked, stops before the tag) round out the release side — see
`mso release --help`. Release *mechanics* (the tag → publish-workflow →
package-index pipeline) are this project's own and are not made
provider-neutral by this feature; `mso release` says so in its own help
text.

## Configuring providers from the Maestro Hub

Pro, Team and Enterprise workspaces can also configure providers from the Hub's
Workspace settings drawer (**Providers** section) — `GET`/`PUT
/api/v1/workspaces/{id}/providers` and `POST
.../providers/test`, gated the same way the Hub's other acting endpoints
are (tier, and refused with a 409 in an observe-only deployment). It writes
through the exact same `maestro.providers.config` core as the CLI and
`mso setup` — there is no second write path, and no other part of the
Workspace settings drawer accepts writes. Credential fields in the Hub
accept and display only `env:`/`secret://` references, never a resolved
value.

## Testing before you trust it

`mso providers test <kind>` resolves a kind right now and prints the same
`tier` / `available` / `reason` shape `mso doctor --explain` shows — use it
after any config change, and it's what `mso setup`'s SDLC-providers step
runs automatically once you've answered its prompts.

## See also

- [`maestro/roles/REL.md`](../roles/REL.md) — the Releaser's provider-neutral
  voyage-completion checklist that consumes these providers
- [Roles Guide](ROLES-GUIDE.md#coxswain-cox) — what REL does with a
  configured stack, and what always stays the Captain's
- [PATROL.md](PATROL.md) — the fleet-health checks that also consume these providers
- [ROLE-OVERLAYS.md](ROLE-OVERLAYS.md) — customising role behaviour, including the resident LEAD agent
- [MODEL-BACKENDS.md](MODEL-BACKENDS.md) — the `model` kind in full: AWS Bedrock
  setup, the AWS login sequence, credential expiry, model-id translation
- [CLI-REFERENCE.md](CLI-REFERENCE.md) — full `mso pr` / `mso release` / `mso providers` command reference
