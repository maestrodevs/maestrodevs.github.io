"""maestro.migrate — workspace migration engine.

FTR-MSO-2026-0367 / Phase 2b (FTR-E) of PLAN-PLN-MSO-2026-0358 (§3.5, §3.7, §5,
§6, §7; Captain rulings 0a #1/#2 BINDING).

`migrate_artefact_repo()` moves an *embedded* workspace's durable artefact plane
(queues/orders/voyages/plans/handoffs/reports/requirements/prompts/usage/config)
into a new dedicated **artefact repository** whose root contains a ``.mso/``
directory (Option 1d, layout-preserving — plan §3.2). Solo topology: a plain
local ``git init`` repo, remote optional.

Design guarantees (plan risk register §6):

* **Copy-not-move** — the source ``.mso`` is never touched until (and unless) a
  post-copy manifest hash-diff proves the import is byte-identical. A failed
  verify leaves the product workspace fully functional in embedded mode.
* **Mandatory backup** — a :func:`maestro.backup.backup` zip is taken BEFORE any
  filesystem mutation.
* **Mandatory pre-flight cleanup gate** (ruling #2) — migration REFUSES while any
  crew/voyage/salvage/scratch worktree exists, any voyage/salvage/crew branch
  carries ``.mso`` deltas not merged to the default branch, or uncommitted
  ``.mso`` changes exist. Each blocker is reported with the exact recovery
  command.
* **Copy-fresh, one import commit** (ruling #2) — the durable plane lands as a
  single ``import: .mso from <product-repo>@<sha>`` commit; the full source
  history stays readable in the product repo forever.
* **Idempotent** — re-running against an already-migrated (solo/shared)
  workspace is a clear no-op with status output.

The engine follows ``maestro.update``'s check / plan / apply triad with a
``--dry-run`` action table.
"""

from __future__ import annotations

import hashlib
import os
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from maestro import backup as _backup
from maestro import registry
from maestro.init import ensure_maestro_gitignore_block
from maestro.workspace import (
    MSO_DIR_NAME,
    _artefacts_block,
    _workspace_project_acronym,
    clear_workspace_config_cache,
    get_artefact_mode,
)

# Runtime-plane git ref prefixes: worktree-bearing / artefact-carrying branch
# families that MUST be merged & cleared before a copy-fresh import (ruling #2).
_ARTEFACT_BRANCH_PREFIXES = ("voyage/", "salvage/", "crew/")

# Default artefact-repo name suffix (ruling #1 — NEVER "-maestro").
_ARTEFACT_REPO_SUFFIX = "Platform"

# Default push debounce written into the new artefacts block (plan §3.6).
_DEFAULT_PUSH_DEBOUNCE_SECONDS = 30

# ---------------------------------------------------------------------------
# import-workspace (FTR-MSO-2026-0381 / Phase 4e / FTR-L) constants
# ---------------------------------------------------------------------------

# Durable-plane subdirs amalgamated by ``import-workspace`` (scope §4.6/§7).
# Runtime/config planes (config, state, logs, crews, bridge, temp, worktrees)
# are NEVER imported — the target keeps its own config and runtime.
_IMPORT_SUBDIRS = (
    "orders", "queues", "voyages", "plans", "handoffs", "reports", "usage",
)

# Suffixes whose *contents* get the ID-rename text substitution (everything
# else is copied byte-for-byte).
_TEXT_SUFFIXES = (".json", ".jsonl", ".md", ".txt", ".yaml", ".yml")

# Rename-map audit artefact — written into the target durable plane so it is
# committed alongside the import (one per imported sub-acronym; deterministic
# name → idempotent re-runs overwrite in place).
_IMPORT_ARTEFACT_DIRREL = "reports/imports"


# ---------------------------------------------------------------------------
# small git / process helpers (self-contained — no fleet_runner import)
# ---------------------------------------------------------------------------

def _git(repo: Path, *args: str, check: bool = False) -> subprocess.CompletedProcess:
    """Run ``git *args`` in *repo*; capture text output. ``check`` raises on rc!=0."""
    return subprocess.run(
        ["git", *args],
        cwd=str(repo),
        capture_output=True,
        text=True,
        check=check,
    )


def _process_alive(pid: int) -> bool:
    """True if *pid* is a live process (Windows-aware; mirrors fleet_runner)."""
    if pid <= 0:
        return False
    try:
        if os.name == "nt":
            import ctypes

            PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            STILL_ACTIVE = 259
            kernel32 = ctypes.windll.kernel32
            handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
            if handle == 0:
                return False
            try:
                exit_code = ctypes.c_ulong()
                if kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code)):
                    return exit_code.value == STILL_ACTIVE
                return False
            finally:
                kernel32.CloseHandle(handle)
        else:
            os.kill(pid, 0)
            return True
    except (ProcessLookupError, PermissionError, OSError):
        return False


def _default_branch(repo: Path) -> str:
    """Best-effort default branch of *repo* (origin/HEAD → main → master → HEAD)."""
    res = _git(repo, "symbolic-ref", "--quiet", "refs/remotes/origin/HEAD")
    if res.returncode == 0 and res.stdout.strip():
        return res.stdout.strip().rsplit("/", 1)[-1]
    for candidate in ("main", "master"):
        if _git(repo, "rev-parse", "--verify", "--quiet",
                f"refs/heads/{candidate}").returncode == 0:
            return candidate
    cur = _git(repo, "rev-parse", "--abbrev-ref", "HEAD")
    return cur.stdout.strip() or "main"


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _is_git_repo(repo: Path) -> bool:
    return (repo / ".git").exists() and _git(repo, "rev-parse", "--git-dir").returncode == 0


def _rmtree_force(path: Path) -> None:
    """Remove *path* recursively, clearing read-only bits (Windows ``.git`` objects).

    ``shutil.rmtree(..., ignore_errors=True)`` silently leaves read-only files
    (git packs its object store read-only) behind on Windows, so rollback must
    chmod-and-retry rather than swallow the error.
    """
    import shutil
    import stat

    def _on_error(func, p, _exc):  # pragma: no cover - platform-specific
        try:
            os.chmod(p, stat.S_IWRITE)
            func(p)
        except OSError:
            pass

    if not path.exists():
        return
    # Python 3.12 renamed the callback kwarg from onerror -> onexc.
    try:
        shutil.rmtree(path, onexc=_on_error)  # type: ignore[call-arg]
    except TypeError:
        shutil.rmtree(path, onerror=_on_error)


# ---------------------------------------------------------------------------
# pre-flight cleanup gate (ruling #2)
# ---------------------------------------------------------------------------

@dataclass
class Blocker:
    """A single pre-flight failure with the exact operator recovery command."""

    kind: str          # dispatcher | worktree | branch | dirty
    detail: str        # human description of what is in the way
    recovery: str      # the exact command to clear it

    def __str__(self) -> str:  # pragma: no cover - trivial
        return f"[{self.kind}] {self.detail}\n      → {self.recovery}"


def _dispatcher_blockers(artefact_root: Path) -> list[Blocker]:
    """Refuse while a dispatcher owns this workspace (pid lock live)."""
    lock = artefact_root / "dispatcher.pid"
    if not lock.exists():
        return []
    try:
        pid = int(lock.read_text(encoding="utf-8").strip())
    except (ValueError, OSError):
        return []
    if _process_alive(pid):
        return [Blocker(
            "dispatcher",
            f"A dispatcher is running (PID {pid}) — migrating its live state is unsafe.",
            f"Stop it first: mso cleanup  (or  taskkill /F /PID {pid}).",
        )]
    return []


def _worktree_blockers(product_repo: Path) -> list[Blocker]:
    """Refuse while any managed (crew/voyage/salvage/scratch/admin) worktree exists.

    The primary checkout (first porcelain record) is never a blocker.
    """
    res = _git(product_repo, "worktree", "list", "--porcelain")
    if res.returncode != 0:
        return []
    blockers: list[Blocker] = []
    paths: list[Path] = []
    for line in res.stdout.splitlines():
        if line.startswith("worktree "):
            paths.append(Path(line[len("worktree "):].strip()))
    # First entry is the primary checkout — skip it.
    for wt in paths[1:]:
        blockers.append(Blocker(
            "worktree",
            f"Live worktree present: {wt}",
            f'git worktree remove --force "{wt}"',
        ))
    return blockers


def _branch_blockers(product_repo: Path, default: str) -> list[Blocker]:
    """Refuse while any artefact branch carries ``.mso`` commits not in *default*.

    Ruling #2: no artefact may be stranded on a voyage/crew/salvage branch when
    the copy is taken. A branch is a blocker iff ``git rev-list default..branch
    -- .mso`` is non-empty (commits touching ``.mso`` reachable from the branch
    but not the default branch).
    """
    res = _git(product_repo, "for-each-ref", "--format=%(refname:short)", "refs/heads/")
    if res.returncode != 0:
        return []
    blockers: list[Blocker] = []
    for branch in (b.strip() for b in res.stdout.splitlines() if b.strip()):
        if branch == default:
            continue
        if not any(branch.startswith(p) for p in _ARTEFACT_BRANCH_PREFIXES):
            continue
        stranded = _git(product_repo, "rev-list", f"{default}..{branch}",
                        "--", MSO_DIR_NAME)
        if stranded.returncode == 0 and stranded.stdout.strip():
            blockers.append(Blocker(
                "branch",
                f"Branch '{branch}' has {MSO_DIR_NAME} commits not merged to '{default}'.",
                f"git checkout {default} && git merge --no-ff {branch}"
                f"   (or sweep its {MSO_DIR_NAME} deltas onto {default}).",
            ))
    return blockers


def _dirty_mso_blockers(product_repo: Path) -> list[Blocker]:
    """Refuse while the working tree has uncommitted ``.mso`` changes."""
    res = _git(product_repo, "status", "--porcelain", "--", MSO_DIR_NAME)
    if res.returncode != 0 or not res.stdout.strip():
        return []
    changed = [ln[3:] for ln in res.stdout.splitlines() if ln.strip()]
    preview = ", ".join(changed[:5]) + ("…" if len(changed) > 5 else "")
    return [Blocker(
        "dirty",
        f"Uncommitted {MSO_DIR_NAME} changes ({len(changed)} path(s)): {preview}",
        f'git add {MSO_DIR_NAME} && git commit -m "sweep: artefacts before migration"',
    )]


def preflight(product_repo: Path, artefact_root: Path,
              default_branch: Optional[str] = None) -> list[Blocker]:
    """Run the full mandatory cleanup gate; return every blocker (empty == clear)."""
    default = default_branch or _default_branch(product_repo)
    blockers: list[Blocker] = []
    blockers += _dispatcher_blockers(artefact_root)
    blockers += _worktree_blockers(product_repo)
    blockers += _branch_blockers(product_repo, default)
    blockers += _dirty_mso_blockers(product_repo)
    return blockers


# ---------------------------------------------------------------------------
# planning
# ---------------------------------------------------------------------------

def resolve_acronym(workspace: Path) -> str:
    """Project acronym for the default repo name (ruling #1: ``<ACRONYM>-Platform``).

    workspace.json ``project`` → projects.json ``defaultProject`` → the product
    repo's directory name (upper-cased) as a last resort.
    """
    mso = workspace / MSO_DIR_NAME
    acronym = _workspace_project_acronym(mso if mso.is_dir() else workspace)
    if acronym:
        return acronym.upper()
    return workspace.resolve().name.upper() or "WORKSPACE"


def default_dest(product_repo: Path, name: Optional[str], acronym: str) -> Path:
    """Default artefact-repo destination: sibling ``<ACRONYM>-Platform`` dir."""
    repo_name = name or f"{acronym}-{_ARTEFACT_REPO_SUFFIX}"
    return (product_repo.resolve().parent / repo_name)


def _tracked_mso_files(product_repo: Path) -> list[str]:
    """Durable set = git-tracked files under ``.mso/`` (POSIX-relative paths)."""
    res = _git(product_repo, "ls-files", "--", f"{MSO_DIR_NAME}/")
    if res.returncode != 0:
        return []
    return [ln.strip() for ln in res.stdout.splitlines() if ln.strip()]


@dataclass
class MigrationPlan:
    """The resolved, about-to-execute (or dry-run) migration."""

    product_repo: Path
    workspace: Path
    acronym: str
    dest: Path
    repo_name: str
    remote: Optional[str]
    clean_product: bool
    default_branch: str
    tracked_files: list[str] = field(default_factory=list)
    blockers: list[Blocker] = field(default_factory=list)

    @property
    def file_count(self) -> int:
        return len(self.tracked_files)

    def action_table(self) -> list[tuple[str, str, str]]:
        """(ACTION, TARGET, DETAIL) rows for the dry-run / plan print-out."""
        rows: list[tuple[str, str, str]] = [
            ("BACKUP", "maestro-backup-*.zip", "zip durable state before any mutation"),
            ("PROVISION", str(self.dest), f"git init '{self.repo_name}' + .gitignore + README"),
            ("COPY-FRESH", f"{MSO_DIR_NAME}/ ({self.file_count} files)",
             "copy tracked durable plane into <dest>/.mso"),
            ("IMPORT-COMMIT", self.dest.name,
             f"one commit: import: {MSO_DIR_NAME} from {self.product_repo.name}@<sha>"),
            ("VERIFY", "manifest hash-diff", "file count + per-file sha256 gate"),
            ("REGISTER", "~/.maestro/projects.json",
             f"v2: artefactRoot={self.dest.name}, artefactMode=solo"),
            ("WORKSPACE", f"{MSO_DIR_NAME}/config/workspace.json",
             "write artefacts block (mode=solo, root, productRepo)"),
        ]
        if self.remote:
            rows.append(("REMOTE", self.remote, "git remote add origin"))
        if self.clean_product:
            rows.append(("CLEAN-PRODUCT", f"{MSO_DIR_NAME}/ (product index)",
                         "git rm --cached + gitignore + sweep commit (keep on disk)"))
        return rows


def plan_migration(
    workspace: Path,
    *,
    dest: Optional[Path] = None,
    name: Optional[str] = None,
    remote: Optional[str] = None,
    clean_product: bool = False,
) -> MigrationPlan:
    """Resolve a :class:`MigrationPlan` and run the pre-flight gate (no mutation)."""
    workspace = workspace.resolve()
    # In embedded mode the product repo IS the workspace root.
    product_repo = workspace
    acronym = resolve_acronym(workspace)
    resolved_dest = (dest.resolve() if dest is not None
                     else default_dest(product_repo, name, acronym))
    repo_name = resolved_dest.name
    default = _default_branch(product_repo)

    plan = MigrationPlan(
        product_repo=product_repo,
        workspace=workspace,
        acronym=acronym,
        dest=resolved_dest,
        repo_name=repo_name,
        remote=remote,
        clean_product=clean_product,
        default_branch=default,
        tracked_files=_tracked_mso_files(product_repo),
    )
    plan.blockers = preflight(product_repo, workspace / MSO_DIR_NAME, default)
    return plan


# ---------------------------------------------------------------------------
# apply — provision + copy-fresh + verify + rewire
# ---------------------------------------------------------------------------

class MigrationError(RuntimeError):
    """Raised when a migration cannot proceed (blockers, verify failure, …)."""


def _readme(acronym: str, product_repo: Path) -> str:
    return (
        f"# {acronym}-{_ARTEFACT_REPO_SUFFIX} — Maestro artefact repository\n\n"
        f"This repository holds the **durable artefact plane** for the `{acronym}` "
        f"Maestro workspace (queues, orders, voyages, plans, handoffs, reports, "
        f"usage, config) under `{MSO_DIR_NAME}/`.\n\n"
        f"It governs the product repository:\n\n"
        f"- `{product_repo.name}` (`{product_repo}`)\n\n"
        f"Durable state is committed to this repo's default branch on every "
        f"lifecycle transition; the runtime plane (crews, logs, state, temp, "
        f"worktrees, pids) stays machine-local and gitignored.\n\n"
        f"Generated by `mso migrate artefact-repo` "
        f"(FTR-MSO-2026-0367 / PLAN-VOY-MSO-2026-0094).\n"
    )


def _provision_repo(dest: Path, acronym: str, product_repo: Path,
                    remote: Optional[str]) -> None:
    """Create the artefact repo skeleton: git init, .gitignore, README."""
    dest.mkdir(parents=True, exist_ok=True)
    if not _is_git_repo(dest):
        _git(dest, "init", check=True)
    # Runtime-plane .gitignore — same canonical block as init/update (idempotent).
    gitignore = dest / ".gitignore"
    existing = gitignore.read_text(encoding="utf-8") if gitignore.exists() else ""
    gitignore.write_text(ensure_maestro_gitignore_block(existing), encoding="utf-8")
    (dest / "README.md").write_text(_readme(acronym, product_repo), encoding="utf-8")
    if remote:
        # Idempotent: replace any existing origin.
        if _git(dest, "remote", "get-url", "origin").returncode == 0:
            _git(dest, "remote", "set-url", "origin", remote)
        else:
            _git(dest, "remote", "add", "origin", remote)


def _copy_fresh(product_repo: Path, dest: Path, tracked_files: list[str]) -> None:
    """Copy each tracked ``.mso`` file into *dest*, preserving relative paths."""
    for rel in tracked_files:
        src = product_repo / rel
        if not src.is_file():
            continue
        target = dest / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(src.read_bytes())


def _import_commit(dest: Path, product_repo: Path) -> str:
    """Stage the copied durable plane and make the single import commit.

    ``git add`` (never ``-f``) respects the runtime .gitignore, so runtime files
    that happen to be tracked in the source never enter the artefact repo's
    history (BUG-0304 pattern). Returns the source HEAD sha recorded in the msg.
    """
    src_sha = _git(product_repo, "rev-parse", "--short", "HEAD").stdout.strip() or "unknown"
    _git(dest, "add", MSO_DIR_NAME, ".gitignore", "README.md")
    # Provide an identity only when the environment lacks one (never override).
    ident: list[str] = []
    if not _git(dest, "config", "user.email").stdout.strip():
        ident = ["-c", "user.email=maestro@localhost", "-c", "user.name=Maestro"]
    msg = f"import: {MSO_DIR_NAME} from {product_repo.name}@{src_sha}"
    res = _git(dest, *ident, "commit", "-m", msg)
    if res.returncode != 0:
        raise MigrationError(
            f"Import commit failed in {dest}: {res.stderr.strip() or res.stdout.strip()}"
        )
    return src_sha


def verify_manifest(product_repo: Path, dest: Path) -> tuple[bool, list[str]]:
    """Post-copy manifest hash-diff gate (plan §6 mitigation).

    Compares the artefact repo's *committed* file set against the source: every
    committed ``.mso`` file must be byte-identical (sha256) to its product-repo
    counterpart, and none may be missing. Returns ``(ok, problems)``.
    """
    committed = _git(dest, "ls-files", "--", f"{MSO_DIR_NAME}/")
    problems: list[str] = []
    dest_files = [ln.strip() for ln in committed.stdout.splitlines() if ln.strip()]
    if not dest_files:
        return False, [f"no {MSO_DIR_NAME} files committed in artefact repo"]
    for rel in dest_files:
        src = product_repo / rel
        dst = dest / rel
        if not src.is_file():
            problems.append(f"committed file has no source: {rel}")
            continue
        if not dst.is_file():
            problems.append(f"missing in dest after commit: {rel}")
            continue
        if _sha256(src) != _sha256(dst):
            problems.append(f"hash mismatch: {rel}")
    return (not problems), problems


def _write_artefacts_block(
    workspace_json: Path,
    *,
    dest: Path,
    product_repo: Path,
    remote: Optional[str],
    mode: str = "solo",
) -> None:
    """Merge an ``artefacts`` block into *workspace_json* (create file if absent)."""
    import json

    data: dict = {}
    if workspace_json.exists():
        try:
            data = json.loads(workspace_json.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                data = {}
        except (json.JSONDecodeError, OSError):
            data = {}
    block: dict = {
        "mode": mode,
        "root": str(dest.resolve()),
        "productRepo": str(product_repo.resolve()),
        "pushDebounceSeconds": _DEFAULT_PUSH_DEBOUNCE_SECONDS,
    }
    if remote:
        block["remote"] = remote
    data["artefacts"] = block
    workspace_json.parent.mkdir(parents=True, exist_ok=True)
    workspace_json.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


def _write_product_stub(product_ws_json: Path, dest: Path) -> None:
    """Write a minimal ``artefacts`` pointer stub into the PRODUCT workspace.json.

    Lets interactive sessions run from the product repo redirect to the artefact
    repo (workspace.py ``_redirected_artefact_root`` + get_product_repo
    stub-parent heuristic). Only ``mode`` + ``root`` — the product repo carries
    no authoritative artefact config.
    """
    import json

    data: dict = {}
    if product_ws_json.exists():
        try:
            data = json.loads(product_ws_json.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                data = {}
        except (json.JSONDecodeError, OSError):
            data = {}
    data["artefacts"] = {"mode": "solo", "root": str(dest.resolve())}
    product_ws_json.parent.mkdir(parents=True, exist_ok=True)
    product_ws_json.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


def _clean_product_index(product_repo: Path, dest: Path) -> None:
    """Detach ``.mso`` from the product repo index (BUG-0304 pattern).

    ``git rm -r --cached .mso`` (keep on disk) + ensure ``.mso/`` is gitignored
    product-side + one sweep commit. The last Maestro bookkeeping commit the
    product repo ever takes.
    """
    rm = _git(product_repo, "rm", "-r", "--cached", "--quiet", MSO_DIR_NAME)
    if rm.returncode != 0 and "did not match" not in (rm.stderr + rm.stdout):
        raise MigrationError(
            f"git rm --cached {MSO_DIR_NAME} failed: {rm.stderr.strip() or rm.stdout.strip()}"
        )
    gitignore = product_repo / ".gitignore"
    content = gitignore.read_text(encoding="utf-8") if gitignore.exists() else ""
    marker = f"# Maestro artefacts relocated to {dest.name} (FTR-MSO-2026-0367)"
    if f"\n{MSO_DIR_NAME}/\n" not in f"\n{content}\n":
        addition = f"\n{marker}\n{MSO_DIR_NAME}/\n"
        gitignore.write_text((content.rstrip("\n") + "\n" + addition) if content
                             else addition.lstrip("\n"), encoding="utf-8")
    _git(product_repo, "add", ".gitignore")
    ident: list[str] = []
    if not _git(product_repo, "config", "user.email").stdout.strip():
        ident = ["-c", "user.email=maestro@localhost", "-c", "user.name=Maestro"]
    _git(product_repo, *ident, "commit", "-m",
         f"chore: relocate Maestro artefacts to {dest.name}")


def _rewire(plan: MigrationPlan, dest: Path) -> None:
    """Registry v2 + workspace.json artefacts block + optional product stub."""
    # 1. Global registry v2 entry (artefactRoot / artefactMode=solo).
    registry.register_project(
        plan.acronym,
        path=plan.product_repo,
        product_repo=plan.product_repo,
        artefact_root=dest,
        artefact_mode="solo",
    )
    # 2. Authoritative artefacts block in the NEW artefact repo's workspace.json.
    _write_artefacts_block(
        dest / MSO_DIR_NAME / "config" / "workspace.json",
        dest=dest,
        product_repo=plan.product_repo,
        remote=plan.remote,
    )
    # 3. Product-side pointer stub (skipped when the product index is cleaned —
    #    a cleaned product repo is expected to be dispatched from the artefact
    #    repo root, not walked-up from).
    if not plan.clean_product:
        _write_product_stub(
            plan.product_repo / MSO_DIR_NAME / "config" / "workspace.json",
            dest,
        )
    clear_workspace_config_cache()


def migrate_artefact_repo(
    workspace: Path,
    *,
    dest: Optional[Path] = None,
    name: Optional[str] = None,
    remote: Optional[str] = None,
    clean_product: bool = False,
    dry_run: bool = False,
) -> MigrationPlan:
    """Migrate an embedded workspace's durable plane into a solo artefact repo.

    Returns the resolved :class:`MigrationPlan`. Raises :class:`MigrationError`
    on a blocked pre-flight or a failed manifest verify. Idempotent: an
    already-migrated (solo/shared) workspace is a no-op.
    """
    workspace = workspace.resolve()

    # --- Idempotency: already migrated? -----------------------------------
    if get_artefact_mode(workspace) in ("solo", "shared"):
        block = _artefacts_block(workspace / MSO_DIR_NAME)
        print(f"[Maestro] Workspace already migrated "
              f"(artefacts.mode={block.get('mode')!r}, root={block.get('root')}). "
              f"Nothing to do.")
        return plan_migration(workspace, dest=dest, name=name, remote=remote,
                              clean_product=clean_product)

    plan = plan_migration(workspace, dest=dest, name=name, remote=remote,
                          clean_product=clean_product)

    # --- Pre-flight cleanup gate (ruling #2 — mandatory) ------------------
    if plan.blockers:
        print("[Maestro] Migration refused — pre-flight cleanup required:\n")
        for b in plan.blockers:
            print(f"  {b}")
        print("\nClear the blocker(s) above and re-run.")
        if dry_run:
            _print_action_table(plan, mutated=False)
        raise MigrationError(
            f"{len(plan.blockers)} pre-flight blocker(s) — migration refused."
        )

    # --- Dry-run: print the full action table, mutate nothing -------------
    if dry_run:
        _print_action_table(plan, mutated=False)
        return plan

    # --- Guard the destination --------------------------------------------
    if plan.dest.exists() and any(plan.dest.iterdir()):
        if _is_git_repo(plan.dest) and (plan.dest / MSO_DIR_NAME / "config").is_dir():
            raise MigrationError(
                f"Destination {plan.dest} already contains a Maestro workspace. "
                f"Choose another --dest or remove it first."
            )
        raise MigrationError(
            f"Destination {plan.dest} exists and is not empty. "
            f"Choose an empty --dest."
        )

    # --- 1. Mandatory backup BEFORE any mutation --------------------------
    zip_path = _backup.backup(workspace=workspace, project=None)
    if zip_path is None:
        raise MigrationError(
            "Pre-migration backup did not complete (workspace too large?) — "
            "aborting before any mutation."
        )
    print(f"[Maestro] Backup created: {zip_path}")

    # --- 2. Provision + 3. copy-fresh + 4. import commit ------------------
    _provision_repo(plan.dest, plan.acronym, plan.product_repo, plan.remote)
    _copy_fresh(plan.product_repo, plan.dest, plan.tracked_files)
    src_sha = _import_commit(plan.dest, plan.product_repo)
    print(f"[Maestro] Copy-fresh import committed "
          f"({plan.file_count} tracked files, source @{src_sha}).")

    # --- 5. Post-copy manifest hash-diff gate -----------------------------
    ok, problems = verify_manifest(plan.product_repo, plan.dest)
    if not ok:
        preview = "\n  ".join(problems[:10])
        raise MigrationError(
            f"Manifest verify FAILED ({len(problems)} problem(s)) — source "
            f"{MSO_DIR_NAME} left untouched; artefact repo at {plan.dest} kept "
            f"for inspection. Roll back with rollback_migration(). Problems:\n"
            f"  {preview}"
        )
    print("[Maestro] Manifest hash-diff green.")

    # --- 6. Rewire (registry v2 + workspace.json artefacts block) ---------
    _rewire(plan, plan.dest)
    print(f"[Maestro] Registry + workspace.json updated — artefact mode 'solo' "
          f"(root: {plan.dest}).")

    # --- 7. Optional product-repo index hygiene ---------------------------
    if plan.clean_product:
        _clean_product_index(plan.product_repo, plan.dest)
        print(f"[Maestro] Product repo detached from {MSO_DIR_NAME} bookkeeping "
              f"(git rm --cached; on-disk copy retained). Remove it manually once "
              f"you have confirmed the artefact repo: rm -rf {plan.product_repo / MSO_DIR_NAME}")

    print(f"\n[Maestro] Migration complete. Dispatch from: {plan.dest}")
    return plan


def _print_action_table(plan: MigrationPlan, *, mutated: bool) -> None:
    """Print the aligned action table (mso update pattern)."""
    header = "PLANNED ACTIONS (dry-run — nothing mutated)" if not mutated else "ACTIONS"
    print(f"\n{header}")
    print(f"  acronym={plan.acronym}  dest={plan.dest}  "
          f"files={plan.file_count}  default-branch={plan.default_branch}")
    print("  " + "-" * 70)
    for action, target, detail in plan.action_table():
        print(f"  {action:<15} {target}")
        print(f"  {'':<15} └─ {detail}")
    print("  " + "-" * 70)


# ---------------------------------------------------------------------------
# rollback (plan §6 — "delete dest + revert registry")
# ---------------------------------------------------------------------------

def rollback_migration(
    product_repo: Path,
    dest: Path,
    acronym: str,
    *,
    delete_dest: bool = True,
) -> None:
    """Restore embedded mode: delete the artefact repo + revert the registry.

    * Deletes *dest* (the newly-provisioned artefact repo) when ``delete_dest``.
    * Re-registers *acronym* as an embedded v2 entry (no artefactRoot/mode).
    * Strips the ``artefacts`` block from the product workspace.json stub.

    The source ``.mso`` was never moved (copy-not-move), so the product
    workspace is fully functional in embedded mode immediately after rollback.
    """
    import json

    if delete_dest and dest.exists():
        _rmtree_force(dest)

    # Revert the registry entry to embedded (drops artefactRoot / artefactMode).
    registry.register_project(
        acronym,
        path=product_repo,
        product_repo=product_repo,
    )

    # Strip the artefacts block from the product stub workspace.json.
    product_ws_json = product_repo / MSO_DIR_NAME / "config" / "workspace.json"
    if product_ws_json.exists():
        try:
            data = json.loads(product_ws_json.read_text(encoding="utf-8"))
            if isinstance(data, dict) and "artefacts" in data:
                del data["artefacts"]
                product_ws_json.write_text(json.dumps(data, indent=2) + "\n",
                                           encoding="utf-8")
        except (json.JSONDecodeError, OSError):
            pass

    clear_workspace_config_cache()
    print(f"[Maestro] Rolled back — embedded mode restored for {acronym} "
          f"(source {MSO_DIR_NAME} untouched).")


# ===========================================================================
# import-workspace — amalgamate an existing workspace into a target's
# artefact repo with sub-acronym ID renaming (FTR-MSO-2026-0381 / FTR-L).
#
# Captain ruling 0a #3 (BINDING): imported artefact IDs are RENAMED with a
# sub-acronym prefix — e.g. ``POR-* -> GKT-POR-*``, ``WEB-* -> GKT-WEB-*`` —
# and EVERY cross-reference (dependsOn / relates / voyageId / voyage order
# lists / plan+handoff+report body text) is rewritten consistently. A rename
# map is emitted as an import artefact for audit. This OVERRIDES the plan's
# original keep-IDs-unchanged recommendation.
# ===========================================================================

import re as _re


def _artefact_id_re(acronym: str) -> "_re.Pattern[str]":
    """Regex matching a full Maestro artefact ID for *acronym*.

    Shape ``<TYPE>-<ACR>-<YEAR>-<SEQ>`` (e.g. ``BUG-POR-2026-0001``,
    ``VOY-POR-2026-0005``). ``<TYPE>`` is any 2+ upper-case token, ``<YEAR>``
    and ``<SEQ>`` are 4-digit runs. Anchored with ``\\b`` on both ends so a
    longer surrounding token (``…-00019``) never partial-matches.
    """
    return _re.compile(
        rf"\b([A-Z]{{2,}})-{_re.escape(acronym)}-(\d{{4}})-(\d{{4}})\b"
    )


def detect_source_acronym(source_repo: Path, tracked_files: list[str]) -> str:
    """Best-effort acronym the *source* workspace's artefact IDs use.

    Ladder: workspace.json ``project`` → most frequent acronym segment across
    the durable filenames → :func:`resolve_acronym` (dirname fallback). The
    filename-frequency step matters because a source dir named ``GKT-Portal``
    would otherwise resolve to ``GKT-PORTAL`` while its IDs use ``POR``.
    """
    mso = source_repo / MSO_DIR_NAME
    proj = _workspace_project_acronym(mso if mso.is_dir() else source_repo)
    if proj:
        return proj.upper()
    # Frequency-count the middle acronym segment of every id-shaped filename.
    seg_re = _re.compile(r"\b[A-Z]{2,}-([A-Z]{2,})-\d{4}-\d{4}\b")
    counts: dict[str, int] = {}
    for rel in tracked_files:
        for m in seg_re.finditer(rel):
            counts[m.group(1)] = counts.get(m.group(1), 0) + 1
    if counts:
        return max(counts, key=lambda k: counts[k])
    return resolve_acronym(source_repo)


def resolve_target_acronym(target_root: Path, override: Optional[str] = None) -> str:
    """Acronym the target namespaces imports under (``<TARGET>-<SUB>-*``).

    ``--target-acronym`` override wins; else workspace.json ``project`` /
    registry; else the target dir name with a trailing ``-Platform`` stripped
    (artefact-repo repos are conventionally ``<ACR>-Platform``).
    """
    if override and override.strip():
        return override.strip().upper()
    mso = target_root / MSO_DIR_NAME
    proj = _workspace_project_acronym(mso if mso.is_dir() else target_root)
    if proj:
        return proj.upper()
    name = target_root.resolve().name
    suffix = f"-{_ARTEFACT_REPO_SUFFIX}"
    if name.lower().endswith(suffix.lower()):
        name = name[: -len(suffix)]
    return name.upper() or "TARGET"


def _import_tracked_files(source_repo: Path) -> list[str]:
    """Git-tracked durable-plane files of the source (``.mso/<subdir>/…``)."""
    keep: list[str] = []
    for rel in _tracked_mso_files(source_repo):
        parts = rel.split("/")
        if len(parts) >= 2 and parts[0] == MSO_DIR_NAME and parts[1] in _IMPORT_SUBDIRS:
            keep.append(rel)
    return keep


def build_rename_map(
    source_repo: Path,
    tracked_files: list[str],
    *,
    source_acronym: str,
    target_acronym: str,
    sub_acronym: str,
) -> dict[str, str]:
    """Map every source artefact ID → its ``<TARGET>-<SUB>`` renamed form.

    IDs are discovered from BOTH durable filenames and text-file contents
    (dependsOn / relates / voyageId / order lists / body references), so a
    reference that never appears as a filename is still captured. Only IDs
    carrying *source_acronym* are renamed — other acronyms (e.g. a stray legacy
    id) are left untouched and their references stay internally consistent.
    """
    id_re = _artefact_id_re(source_acronym)
    repl = rf"\1-{target_acronym}-{sub_acronym}-\2-\3"
    ids: set[str] = set()
    for rel in tracked_files:
        for m in id_re.finditer(rel):
            ids.add(m.group(0))
        p = source_repo / rel
        if p.suffix.lower() in _TEXT_SUFFIXES and p.is_file():
            try:
                for m in id_re.finditer(p.read_text(encoding="utf-8", errors="ignore")):
                    ids.add(m.group(0))
            except OSError:
                continue
    return {oid: id_re.sub(repl, oid) for oid in sorted(ids)}


def _compile_map_pattern(rename_map: dict[str, str]) -> Optional["_re.Pattern[str]"]:
    """A single ``\\b(id1|id2|…)\\b`` alternation over the full-ID map keys.

    Longest-first so no key ever partial-matches a longer sibling. Returns
    ``None`` for an empty map (caller copies text verbatim).
    """
    if not rename_map:
        return None
    keys = sorted(rename_map, key=len, reverse=True)
    return _re.compile(r"\b(" + "|".join(_re.escape(k) for k in keys) + r")\b")


def _apply_map(text: str, pattern: Optional["_re.Pattern[str]"],
               rename_map: dict[str, str]) -> str:
    """Rewrite every full-ID occurrence in *text* via the compiled *pattern*."""
    if pattern is None:
        return text
    return pattern.sub(lambda m: rename_map[m.group(0)], text)


def high_water(mso_dir: Path, acronym: str) -> dict[str, int]:
    """Per-year highest 4-digit sequence for *acronym* under *mso_dir*.

    Scans the durable dirs the way the ``mso order`` / ``mso voyage`` sequence
    allocators do (filename-anchored), returning ``{year: max_seq}``.
    """
    hw: dict[str, int] = {}
    seq_re = _re.compile(rf"\b[A-Z]{{2,}}-{_re.escape(acronym)}-(\d{{4}})-(\d{{4}})\b")
    for sub in _IMPORT_SUBDIRS:
        d = mso_dir / sub
        if not d.exists():
            continue
        for f in d.rglob("*"):
            if not f.is_file():
                continue
            m = seq_re.search(f.name)
            if m:
                year, seq = m.group(1), int(m.group(2))
                hw[year] = max(hw.get(year, 0), seq)
    return hw


@dataclass
class ImportPlan:
    """A resolved (or dry-run) ``import-workspace`` amalgamation."""

    source_repo: Path
    target_root: Path
    source_acronym: str
    target_acronym: str
    sub_acronym: str
    import_files: list[str] = field(default_factory=list)
    rename_map: dict[str, str] = field(default_factory=dict)
    blockers: list[Blocker] = field(default_factory=list)
    source_high_water: dict[str, int] = field(default_factory=dict)
    target_high_water: dict[str, int] = field(default_factory=dict)

    @property
    def combined_high_water(self) -> dict[str, int]:
        """Per-year max of the target's own IDs and the imported originals —
        so new target orders start above the combined mark (scope §3)."""
        merged = dict(self.target_high_water)
        for year, seq in self.source_high_water.items():
            merged[year] = max(merged.get(year, 0), seq)
        return merged

    @property
    def id_count(self) -> int:
        return len(self.rename_map)

    @property
    def artefact_rel(self) -> str:
        """Repo-relative path of the rename-map audit artefact."""
        return f"{MSO_DIR_NAME}/{_IMPORT_ARTEFACT_DIRREL}/RENAME-MAP-{self.sub_acronym}.json"

    def action_table(self) -> list[tuple[str, str, str]]:
        rows: list[tuple[str, str, str]] = [
            ("BACKUP", "maestro-backup-*.zip (x2)",
             "zip BOTH source and target durable state before any mutation"),
            ("RENAME", f"{self.id_count} artefact ID(s)",
             f"{self.source_acronym}-* → {self.target_acronym}-{self.sub_acronym}-*"),
            ("COPY-RENAME", f"{len(self.import_files)} file(s)",
             "copy durable plane into target, paths + contents rewritten"),
            ("RENAME-MAP", self.artefact_rel, "write audit artefact of the full map"),
            ("IMPORT-COMMIT", self.target_root.name,
             f"one commit: import: workspace {self.source_repo.name} as {self.sub_acronym}"),
            ("REGISTER", "~/.maestro/projects.json",
             f"target.legacyAcronyms[{self.sub_acronym}]; source marked imported"),
        ]
        return rows


def _resolve_target_root(into: Path) -> Path:
    """The artefact-repo root that owns ``<into>/.mso`` (must already exist)."""
    root = into.resolve()
    if not (root / MSO_DIR_NAME).is_dir():
        raise MigrationError(
            f"--into target {root} has no {MSO_DIR_NAME}/ durable plane. Point "
            f"--into at the target workspace / artefact repo root (the dir that "
            f"contains {MSO_DIR_NAME}/)."
        )
    return root


def plan_import(
    source: Path,
    into: Path,
    sub_acronym: str,
    *,
    target_acronym: Optional[str] = None,
) -> ImportPlan:
    """Resolve an :class:`ImportPlan` and run the source pre-flight gate.

    No mutation. The pre-flight mirrors ``artefact-repo`` migration (FTR-0367):
    the *source* must be clean — no live dispatcher, no managed worktrees, no
    artefact branch carrying unmerged ``.mso`` commits, no dirty ``.mso``.
    """
    source = source.resolve()
    target_root = _resolve_target_root(into)
    sub = sub_acronym.strip().upper()
    if not sub:
        raise MigrationError("--sub-acronym must be a non-empty token (e.g. POR, WEB).")
    src_acr = detect_source_acronym(source, _tracked_mso_files(source))
    tgt_acr = resolve_target_acronym(target_root, target_acronym)

    import_files = _import_tracked_files(source)
    rename_map = build_rename_map(
        source, import_files,
        source_acronym=src_acr, target_acronym=tgt_acr, sub_acronym=sub,
    )
    plan = ImportPlan(
        source_repo=source,
        target_root=target_root,
        source_acronym=src_acr,
        target_acronym=tgt_acr,
        sub_acronym=sub,
        import_files=import_files,
        rename_map=rename_map,
        source_high_water=high_water(source / MSO_DIR_NAME, src_acr),
        target_high_water=high_water(target_root / MSO_DIR_NAME, tgt_acr),
    )
    plan.blockers = preflight(source, source / MSO_DIR_NAME)
    return plan


def _write_rename_artefact(plan: ImportPlan, src_sha: str) -> Path:
    """Write the rename-map audit artefact into the target durable plane."""
    import json

    artefact = plan.target_root / plan.artefact_rel
    artefact.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "schemaVersion": 1,
        "feature": "FTR-MSO-2026-0381",
        "source": {
            "path": str(plan.source_repo),
            "acronym": plan.source_acronym,
            "sha": src_sha,
        },
        "target": {
            "path": str(plan.target_root),
            "acronym": plan.target_acronym,
        },
        "subAcronym": plan.sub_acronym,
        "idCount": plan.id_count,
        "renameMap": dict(sorted(plan.rename_map.items())),
        "sequenceHighWater": {
            "targetAcronym": plan.target_high_water,
            "importedOriginal": plan.source_high_water,
            "combined": plan.combined_high_water,
        },
    }
    artefact.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    return artefact


def _copy_rename(plan: ImportPlan) -> tuple[list[str], list[str]]:
    """Copy each durable file into the target with paths + contents rewritten.

    Idempotent: a destination that already exists is SKIPPED (skip-if-exists by
    renamed ID — scope §3), so a re-run over an already-imported source adds no
    new files. Returns ``(written_rel, skipped_rel)`` (target-relative paths).
    """
    pattern = _compile_map_pattern(plan.rename_map)
    written: list[str] = []
    skipped: list[str] = []
    for rel in plan.import_files:
        src = plan.source_repo / rel
        if not src.is_file():
            continue
        new_rel = _apply_map(rel, pattern, plan.rename_map)
        dst = plan.target_root / new_rel
        if dst.exists():
            skipped.append(new_rel)
            continue
        dst.parent.mkdir(parents=True, exist_ok=True)
        if src.suffix.lower() in _TEXT_SUFFIXES:
            content = src.read_text(encoding="utf-8", errors="ignore")
            dst.write_text(_apply_map(content, pattern, plan.rename_map),
                           encoding="utf-8")
        else:
            dst.write_bytes(src.read_bytes())
        written.append(new_rel)
    return written, skipped


def _import_commit_target(plan: ImportPlan, written: list[str],
                          artefact_rel: str, src_sha: str) -> None:
    """Stage the written files + rename artefact and make one import commit."""
    target = plan.target_root
    _git(target, "add", "--", *(written + [artefact_rel]))
    ident: list[str] = []
    if not _git(target, "config", "user.email").stdout.strip():
        ident = ["-c", "user.email=maestro@localhost", "-c", "user.name=Maestro"]
    msg = (f"import: workspace {plan.source_repo.name} as {plan.sub_acronym} "
           f"({plan.id_count} artefact IDs {plan.source_acronym}-* → "
           f"{plan.target_acronym}-{plan.sub_acronym}-*) @{src_sha}")
    res = _git(target, *ident, "commit", "-m", msg)
    if res.returncode != 0:
        raise MigrationError(
            f"Import commit failed in {target}: "
            f"{res.stderr.strip() or res.stdout.strip()}"
        )


def _dangling_old_ids(text: str, old_re: "_re.Pattern[str]",
                      target_acronym: str) -> list[str]:
    """Old source-acronym IDs left un-renamed in *text*.

    A genuine dangling id is ``<TYPE>-<SOURCE_ACR>-…`` whose ``<TYPE>`` is a
    real order type (BUG/FTR/VOY/…). The renamed compound form
    ``<TYPE>-<TARGET>-<SOURCE_ACR>-…`` also matches ``old_re`` (its acronym
    segment ends in the source acronym), but there the captured ``<TYPE>``
    group equals the TARGET acronym — those are the correctly-renamed IDs and
    are excluded.
    """
    return [m.group(0) for m in old_re.finditer(text)
            if m.group(1) != target_acronym]


def verify_no_dangling(plan: ImportPlan) -> tuple[bool, list[str]]:
    """Deep check: no OLD source-acronym ID survives in the imported subtree.

    Scans every imported file (renamed path) — filename AND text content — for
    any residual ``<TYPE>-<SOURCE_ACR>-<YEAR>-<SEQ>`` reference that was NOT
    rewritten to the ``<TARGET>-<SUB>`` form. A clean import has zero. Returns
    ``(ok, problems)``.
    """
    pattern = _compile_map_pattern(plan.rename_map)
    old_re = _artefact_id_re(plan.source_acronym)
    tgt = plan.target_acronym
    problems: list[str] = []
    for rel in plan.import_files:
        src = plan.source_repo / rel
        if not src.is_file():
            continue
        new_rel = _apply_map(rel, pattern, plan.rename_map)
        for hit in _dangling_old_ids(new_rel, old_re, tgt):
            problems.append(f"dangling old ID '{hit}' in path: {new_rel}")
        dst = plan.target_root / new_rel
        if dst.is_file() and dst.suffix.lower() in _TEXT_SUFFIXES:
            for hit in _dangling_old_ids(
                    dst.read_text(encoding="utf-8", errors="ignore"), old_re, tgt):
                problems.append(f"dangling old ID '{hit}' in {new_rel}")
    return (not problems), problems


def import_workspace(
    source: Path,
    into: Path,
    sub_acronym: str,
    *,
    target_acronym: Optional[str] = None,
    dry_run: bool = False,
) -> ImportPlan:
    """Amalgamate *source*'s durable plane into *into*'s artefact repo.

    Renames every source artefact ID to ``<TARGET>-<SUB>-*`` (ruling #3),
    rewrites all cross-references, emits a rename-map audit artefact, and lands
    the result as ONE import commit. Idempotent (skip-if-exists by renamed ID);
    ``--dry-run`` mutates nothing; a blocked source pre-flight refuses with
    recovery hints; both sides are backed up before any mutation.

    Returns the resolved :class:`ImportPlan`. Raises :class:`MigrationError`.
    """
    plan = plan_import(source, into, sub_acronym, target_acronym=target_acronym)

    # --- Pre-flight cleanup gate (source must be clean) -------------------
    if plan.blockers:
        print("[Maestro] Import refused — source pre-flight cleanup required:\n")
        for b in plan.blockers:
            print(f"  {b}")
        print("\nClear the blocker(s) above and re-run.")
        if dry_run:
            _print_import_action_table(plan)
        raise MigrationError(
            f"{len(plan.blockers)} source pre-flight blocker(s) — import refused."
        )

    if not plan.rename_map:
        print(f"[Maestro] Nothing to import — no {plan.source_acronym}-* artefact "
              f"IDs found in {plan.source_repo / MSO_DIR_NAME}.")
        if dry_run:
            _print_import_action_table(plan)
        return plan

    # --- Dry-run: full action table + rename-map preview, mutate nothing --
    if dry_run:
        _print_import_action_table(plan)
        return plan

    # --- 1. Mandatory backup of BOTH sides BEFORE any mutation -----------
    for label, ws in (("source", plan.source_repo), ("target", plan.target_root)):
        zip_path = _backup.backup(workspace=ws, project=None)
        if zip_path is None:
            raise MigrationError(
                f"Pre-import backup of the {label} did not complete — aborting "
                f"before any mutation."
            )
        print(f"[Maestro] Backup ({label}) created: {zip_path}")

    src_sha = (_git(plan.source_repo, "rev-parse", "--short", "HEAD").stdout.strip()
               or "unknown")

    # --- 2. Copy-rename durable plane into the target --------------------
    written, skipped = _copy_rename(plan)
    if not written:
        print(f"[Maestro] Import is a no-op — all {len(skipped)} renamed "
              f"artefact(s) already present in {plan.target_root.name} "
              f"(idempotent skip-if-exists).")
        return plan
    print(f"[Maestro] Copy-rename: {len(written)} file(s) written, "
          f"{len(skipped)} already present (skipped).")

    # --- 3. Rename-map audit artefact -----------------------------------
    _write_rename_artefact(plan, src_sha)

    # --- 4. Deep verify: no dangling old IDs before we commit -----------
    ok, problems = verify_no_dangling(plan)
    if not ok:
        preview = "\n  ".join(problems[:10])
        raise MigrationError(
            f"Import verify FAILED ({len(problems)} dangling old-ID "
            f"reference(s)) — target left with uncommitted work for inspection. "
            f"Problems:\n  {preview}"
        )
    print("[Maestro] Deep verify green — no dangling old-ID references.")

    # --- 5. One import commit -------------------------------------------
    _import_commit_target(plan, written, plan.artefact_rel, src_sha)
    print(f"[Maestro] Imported {plan.source_repo.name} as sub-acronym "
          f"'{plan.sub_acronym}' ({plan.id_count} IDs renamed, source @{src_sha}).")

    # --- 6. Registry: legacyAcronyms on target + source retired ---------
    registry.add_legacy_acronym(
        plan.target_acronym, plan.sub_acronym,
        source_acronym=plan.source_acronym,
        source_path=plan.source_repo,
        target_root=plan.target_root,
        id_count=plan.id_count,
    )
    registry.mark_imported(
        plan.source_acronym, into=plan.target_acronym, sub=plan.sub_acronym)
    print(f"[Maestro] Registry updated — {plan.target_acronym}.legacyAcronyms"
          f"[{plan.sub_acronym}] recorded; source '{plan.source_acronym}' marked "
          f"imported.")

    print(f"\n[Maestro] Import complete. Combined sequence high-water: "
          f"{plan.combined_high_water or '{}'}")
    return plan


def _print_import_action_table(plan: ImportPlan) -> None:
    """Print the dry-run action table + a preview of the full rename map."""
    print("\nPLANNED ACTIONS (dry-run — nothing mutated)")
    print(f"  source={plan.source_repo.name} ({plan.source_acronym})  "
          f"into={plan.target_root.name} ({plan.target_acronym})  "
          f"sub={plan.sub_acronym}  ids={plan.id_count}  files={len(plan.import_files)}")
    print("  " + "-" * 70)
    for action, target, detail in plan.action_table():
        print(f"  {action:<15} {target}")
        print(f"  {'':<15} └─ {detail}")
    print("  " + "-" * 70)
    if plan.rename_map:
        print("  RENAME MAP (old ID → new ID):")
        for old, new in sorted(plan.rename_map.items()):
            print(f"    {old}  →  {new}")
    if plan.combined_high_water:
        print("  COMBINED SEQUENCE HIGH-WATER (new target orders start above):")
        for year, seq in sorted(plan.combined_high_water.items()):
            print(f"    {year}: {seq:04d}")
    print("  " + "-" * 70)
