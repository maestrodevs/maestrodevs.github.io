# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Derived voyage lifecycle phase (FTR-MSO-2026-0351).

The stored voyage ``status`` field is static ('PLANNED') and the manifest's
embedded order statuses go stale, so the Hub could not tell operators which
voyages actually need them. This module computes a derived ``phase`` from the
authoritative sources instead:

- per-order effective status: runtime order-ledger (replayed) > archived
  order files (orders/complete|failed) > live ledger claim > queue/manifest
  status
- voyage PR merge state: manifest merge metadata (mergedPR/mergedAt, written
  by ``mso voyage reconcile``) or archival to voyages/complete

Phase precedence (checked top-down):
1. ``merged``          — voyage PR merged OR voyage archived
2. ``needs_attention`` — >=1 order blocked (STALLED/FAILED/...) and nothing
                          the fleet can advance without a human
3. ``final_review``    — all orders terminal-COMPLETE, not yet merged
4. ``underway``        — >=1 order progressing / fleet can still advance
5. ``backlog``         — nothing started
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

PHASE_MERGED = "merged"
PHASE_NEEDS_ATTENTION = "needs_attention"
PHASE_FINAL_REVIEW = "final_review"
PHASE_UNDERWAY = "underway"
PHASE_BACKLOG = "backlog"


# ---------------------------------------------------------------------------
# Status bucket classification
# ---------------------------------------------------------------------------

# Raw on-disk vocabulary AND the Hub's normalised contract statuses both appear
# here — effective statuses come from three different planes (ledger, archived
# files, queue files) and are not guaranteed to be pre-normalised.
_COMPLETE_STATUSES = {
    "COMPLETE", "COMPLETED", "COMPLETE_PENDING_STAGING",
    "COMPLETE_WITH_CONDITIONS", "RELEASE_APPROVED",
}
_BLOCKED_STATUSES = {
    "STALLED", "FAILED", "CONVERGENCE_FAILED", "VERIFY_FAILED",
    "AUTO_SERIALIZE", "BLOCKED",
}
_IN_PROGRESS_STATUSES = {
    "RUNNING", "IN_PROGRESS", "CLAIMED", "DISPATCHED", "ACTIVE",
}
_HELD_STATUSES = {
    "NAV_REVIEW_PENDING", "AWAITING_APPROVAL", "ON_HOLD", "HOLD",
    "BACKLOG", "SKIPPED", "REJECTED",
}
# Everything else (PENDING, REQUEUE, REOPENED, MAX_TURNS, unknown) → pending.


def classify_status(status: Optional[str]) -> str:
    """Map an effective order status onto a rollup bucket name."""
    s = (status or "PENDING").strip().upper()
    if s in _COMPLETE_STATUSES:
        return "complete"
    if s in _BLOCKED_STATUSES:
        return "blocked"
    if s in _IN_PROGRESS_STATUSES:
        return "inProgress"
    if s in _HELD_STATUSES:
        return "held"
    return "pending"


# ---------------------------------------------------------------------------
# Effective per-order status (ledger + archive + queue)
# ---------------------------------------------------------------------------

def _load_json_safe(path: Path) -> Optional[dict]:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def load_ledger_view(mso: Path):
    """Replay the runtime order ledger; None when absent or unreadable."""
    try:
        from maestro.core.order_ledger import load_view
        return load_view(mso)
    except Exception:
        return None


def read_archive_statuses(mso: Path) -> dict[str, str]:
    """Index archived order statuses by id from orders/complete + orders/failed.

    The archive DIRECTORY is only the default — the file's own ``status``
    wins when present, because BUG-MSO-2026-0296 established that files in
    orders/complete can legitimately carry STALLED.
    """
    out: dict[str, str] = {}
    for sub, default in (("complete", "COMPLETE"), ("failed", "FAILED")):
        d = mso / "orders" / sub
        if not d.is_dir():
            continue
        for f in d.glob("*.json"):
            data = _load_json_safe(f) or {}
            oid = data.get("orderId") or data.get("id") or f.stem
            out[str(oid)] = str(data.get("status") or default).strip().upper()
    return out


def effective_order_status(
    order_id: str,
    fallback_status: Optional[str],
    ledger_view,
    archive_statuses: dict[str, str],
) -> str:
    """Resolve one order's effective status (uppercase).

    Precedence: ledger TERMINAL verdict (git-immune truth) > archived order
    file > live ledger claim (a crew is on it right now) > the queue/manifest
    status the caller already has.
    """
    if ledger_view is not None:
        try:
            if ledger_view.is_terminal(order_id):
                return str(ledger_view.terminal.get(order_id) or "COMPLETE").upper()
        except Exception:
            pass
    if order_id in archive_statuses:
        return archive_statuses[order_id]
    if ledger_view is not None:
        try:
            if ledger_view.live_claim(order_id):
                return "RUNNING"
        except Exception:
            pass
    return (fallback_status or "PENDING").strip().upper()


# ---------------------------------------------------------------------------
# Phase computation
# ---------------------------------------------------------------------------

@dataclass
class MemberState:
    """One voyage member order, reduced to what the phase engine needs."""
    order_id: str
    status: str                      # effective status, uppercase
    role: str = ""                   # current/target role (reason strings)
    depends_on: list[str] = field(default_factory=list)


@dataclass
class VoyagePhase:
    phase: str
    reason: str
    rollup: dict[str, int]


def _blocked_reason(blocked: list[MemberState]) -> str:
    parts = []
    for m in blocked[:2]:
        part = f"{m.order_id} {m.status}"
        if m.role:
            part += f" at {m.role}"
        parts.append(part)
    extra = len(blocked) - len(parts)
    reason = "; ".join(parts)
    if extra > 0:
        reason += f" (+{extra} more)"
    return reason


def compute_voyage_phase(
    members: list[MemberState],
    pr_merged: bool = False,
    voyage_archived: bool = False,
    dep_status: Optional[Callable[[str], str]] = None,
    closed_without_merge: bool = False,
) -> VoyagePhase:
    """Derive (phase, reason, rollup) for one voyage.

    ``dep_status`` resolves a dependency order id (possibly outside this
    voyage) to its effective status; used to decide whether a PENDING member
    is actually dispatchable. Defaults to looking within *members*.

    ``closed_without_merge`` (FTR-MSO-2026-0373): reconcile detected that the
    voyage's PR was CLOSED without merging (remote branch deleted, changes
    absent from base). Such a voyage needs a human even though its orders may
    all be COMPLETE — surface it as ``needs_attention`` (unless it has actually
    merged/archived, which always wins).
    """
    rollup = {"total": len(members), "complete": 0, "blocked": 0,
              "inProgress": 0, "pending": 0, "held": 0}
    buckets: dict[str, list[MemberState]] = {
        "complete": [], "blocked": [], "inProgress": [], "pending": [], "held": [],
    }
    for m in members:
        b = classify_status(m.status)
        rollup[b] += 1
        buckets[b].append(m)

    if pr_merged or voyage_archived:
        return VoyagePhase(
            PHASE_MERGED,
            "PR merged" if pr_merged else "voyage archived",
            rollup,
        )

    # FTR-MSO-2026-0373: a closed-without-merge voyage needs an operator
    # decision regardless of its (possibly all-complete) order rollup.
    if closed_without_merge:
        return VoyagePhase(
            PHASE_NEEDS_ATTENTION,
            "PR closed without merging — reopen/re-dispatch or archive manually",
            rollup,
        )

    total = rollup["total"]
    if total == 0:
        return VoyagePhase(PHASE_BACKLOG, "no orders", rollup)

    if dep_status is None:
        local = {m.order_id: m.status for m in members}
        def dep_status(oid: str) -> str:  # noqa: F811 — deliberate default
            return local.get(oid, "PENDING")

    def _dispatchable(m: MemberState) -> bool:
        return all(
            classify_status(dep_status(d)) == "complete"
            for d in (m.depends_on or [])
        )

    dispatchable_pending = [m for m in buckets["pending"] if _dispatchable(m)]

    # 2. needs_attention — something is stuck AND the fleet cannot advance
    # anything else on its own (held orders also need a human, so they don't
    # rescue the voyage from this phase).
    if rollup["blocked"] >= 1 and rollup["inProgress"] == 0 and not dispatchable_pending:
        return VoyagePhase(
            PHASE_NEEDS_ATTENTION, _blocked_reason(buckets["blocked"]), rollup)

    # 3. final_review — everything done, awaiting PR review + merge.
    if rollup["complete"] == total:
        return VoyagePhase(
            PHASE_FINAL_REVIEW,
            f"all {total} orders complete — awaiting PR review + merge",
            rollup,
        )

    # 4. underway — a crew is on it, or work has progressed / can progress.
    # Reaching here with blocked >= 1 means dispatchable pending work exists,
    # so the fleet can still advance the voyage on its own.
    if rollup["inProgress"] >= 1 or rollup["complete"] >= 1 or rollup["blocked"] >= 1:
        bits = [f"{rollup['complete']}/{total} complete"]
        if rollup["inProgress"]:
            bits.append(f"{rollup['inProgress']} in progress")
        if rollup["blocked"]:
            bits.append(f"{rollup['blocked']} blocked")
        return VoyagePhase(PHASE_UNDERWAY, ", ".join(bits), rollup)

    # 5. backlog — nothing started.
    return VoyagePhase(
        PHASE_BACKLOG, f"none of {total} orders started", rollup)
