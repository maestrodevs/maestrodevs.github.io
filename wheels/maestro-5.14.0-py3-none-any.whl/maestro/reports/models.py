# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Framework-agnostic report records (FTR-MSO-2026-0728 — PLAN-PLN-MSO-2026-0726 §5, Order A1).

**This module imports no web framework, and must never grow one.** It carries
plain :mod:`dataclasses` only — no FastAPI, no Pydantic. That is the whole
point: this package follows FTR-MSO-2026-0700's one-core-model-many-surfaces
shape, so *one* function computes a report record and the Hub API, the CLI and
FTR-MSO-2026-0502's PR-body generator all consume the same one. The moment a
Pydantic model appears here that property is gone — the Hub owns the wire shape
(``maestro/hub/models.py``) and adapts to these records, never the reverse.
``tests/test_ftr_0728_reports_core.py`` asserts the absence mechanically so it
cannot regress quietly.

**The honesty rule (plan §7) lives at this layer, not only at the page layer.**
Every status vocabulary below carries an explicit "we do not know" member, and
no reader is permitted to default to the optimistic answer:

* :data:`Verdict.UNDETERMINED` — the report exists but declares no verdict we
  can read. Never rendered, counted or defaulted as an approval.
* :data:`ACStatus.NOT_RECORDED` — a criterion with no recorded result (Captain
  decision D4). A first-class status, never folded into ``met`` or ``failed``.
* :data:`Provenance.NOT_RECORDED` — the absence itself is attributable, so a
  surface can say *where* it looked rather than implying nothing exists.

Counts are :class:`typing.Optional` throughout for the same reason: a report
with no parseable test-summary table has ``tests=None``, which is a different
claim from ``tests=0`` ("the fleet ran no tests"). A surface that cannot tell
those apart cannot be honest about either.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple


# ---------------------------------------------------------------------------
# Vocabularies
# ---------------------------------------------------------------------------

class Verdict:
    """The QA / security verdict tokens, plus the honest unknown.

    ``APPROVED / CONDITIONAL / REJECTED / BLOCKED`` are the four tokens the
    live plane actually writes (measured over 275 MSO QA reports at build
    time — plan §1.3). ``PASS`` / ``FAIL`` also appear, exclusively in
    hand-written and ADM-era reports declaring ``**Verdict:** PASS``; they are
    the same claim in different words and are aliased, never invented — and the
    literal text is always preserved on :attr:`QAReportSummary.raw_verdict`, so
    a normalisation can be audited against its source.
    """

    APPROVED = "APPROVED"
    CONDITIONAL = "CONDITIONAL"
    REJECTED = "REJECTED"
    BLOCKED = "BLOCKED"
    UNDETERMINED = "UNDETERMINED"

    #: Decided tokens, in the order a scan prefers them when a declaration
    #: line names more than one (see
    #: :func:`maestro.reports.qa_reader.extract_verdict`).
    DECIDED = (APPROVED, CONDITIONAL, REJECTED, BLOCKED)

    ALL = DECIDED + (UNDETERMINED,)

    #: Aliases seen in the wild, mapped to the canonical token. Deliberately
    #: tiny and explicit — an unrecognised word yields UNDETERMINED, not a guess.
    ALIASES = {
        "PASS": APPROVED,
        "PASSED": APPROVED,
        "FAIL": REJECTED,
        "FAILED": REJECTED,
    }

    @classmethod
    def normalise(cls, token: Optional[str]) -> str:
        """Map *token* to a canonical verdict, or ``UNDETERMINED``."""
        text = (token or "").strip().upper()
        if text in cls.DECIDED:
            return text
        return cls.ALIASES.get(text, cls.UNDETERMINED)

    @classmethod
    def is_decided(cls, token: Optional[str]) -> bool:
        return (token or "") in cls.DECIDED


class ACStatus:
    """Acceptance-criterion result vocabulary.

    ``NOT_RECORDED`` is Captain decision D4 made structural: absence of a
    result is never a pass, and it is never folded into a pass/fail total. A
    status word that cannot be classified at all yields ``UNDETERMINED`` — also
    not a pass. The two are distinct on purpose: ``NOT_RECORDED`` means nobody
    wrote anything down, ``UNDETERMINED`` means somebody did and it cannot be
    read.
    """

    PASS = "PASS"
    FAIL = "FAIL"
    PARTIAL = "PARTIAL"
    SKIP = "SKIP"
    NOT_RECORDED = "NOT RECORDED"
    UNDETERMINED = "UNDETERMINED"
    #: Two sources recorded READABLE, DIFFERENT results for the same criterion
    #: (FTR-MSO-2026-0733). Never produced by a single-source reader; only the
    #: AC join emits it, and it is never resolved by preferring one side.
    CONFLICT = "CONFLICT"

    #: Statuses that count as a positive verification. Exactly one member, and
    #: that is the point — PARTIAL and SKIP are not passes.
    MET = (PASS,)

    #: Statuses that are a legible claim about the criterion — the only ones
    #: that can disagree with each other. NOT_RECORDED is no claim at all and
    #: UNDETERMINED is a claim nobody can read, so neither can conflict.
    READABLE = (PASS, FAIL, PARTIAL, SKIP)

    ALL = (PASS, FAIL, PARTIAL, SKIP, NOT_RECORDED, UNDETERMINED, CONFLICT)

    _ALIASES = {
        "PASS": PASS, "PASSED": PASS, "PASSES": PASS, "OK": PASS,
        "MET": PASS, "VERIFIED": PASS, "YES": PASS, "DONE": PASS,
        "FAIL": FAIL, "FAILED": FAIL, "FAILS": FAIL, "NOT MET": FAIL, "NO": FAIL,
        "PARTIAL": PARTIAL, "PARTIALLY": PARTIAL, "CONDITIONAL": PARTIAL,
        "SKIP": SKIP, "SKIPPED": SKIP, "N/A": SKIP, "NA": SKIP,
        "NOT APPLICABLE": SKIP, "DEFERRED": SKIP,
        "NOT RECORDED": NOT_RECORDED, "NOT-RECORDED": NOT_RECORDED,
    }

    #: Decoration reports actually put in a status cell. Stripped before
    #: matching so a tick beside a word does not defeat the lookup.
    _DECORATION = (
        "*", "`", "_", "✅", "✔", "☑", "✓", "❌",
        "✗", "✘", "⚠", "️", "\U0001f7e1", "\U0001f7e2",
        "\U0001f534",
    )

    @classmethod
    def normalise(cls, token: Optional[str]) -> str:
        """Map a raw status cell to a canonical status.

        Tolerant of the decoration reports actually use — a leading tick or
        cross, bold markers, and a trailing qualifier after an em dash or
        parenthesis (``PASS — see note``, ``PASS (with caveat)``). An empty
        cell is ``NOT_RECORDED``; an unrecognised word is ``UNDETERMINED``.
        Never ``PASS`` by default.
        """
        text = (token or "").strip()
        if not text:
            return cls.NOT_RECORDED
        for ch in cls._DECORATION:
            text = text.replace(ch, " ")
        text = " ".join(text.split()).upper()
        if not text:
            # The cell held only a decoration glyph. Honest answer: a tick is
            # not a word, and guessing which of PASS/SKIP it stood for would be
            # exactly the invention the honesty rule forbids.
            return cls.UNDETERMINED
        # Strip a trailing qualifier: "PASS — with caveat", "PASS (see ac-04)".
        head = text
        for sep in ("—", "–", "(", ",", ";", ":", " - "):
            head = head.split(sep)[0]
        head = head.strip()
        for candidate in (head, text):
            if candidate in cls._ALIASES:
                return cls._ALIASES[candidate]
        # A leading recognised word still decides ("PASS with caveat").
        first = head.split(" ")[0] if head else ""
        return cls._ALIASES.get(first, cls.UNDETERMINED)


class Provenance:
    """Where a record's value came from.

    Carried per AC row (Captain decision D4b: the QA report's own AC table is a
    legitimate *second* source alongside ``order.acResults``, with explicit
    provenance so the two can be shown side by side when they disagree rather
    than one silently winning).
    """

    ORDER_RESULTS = "order.acResults"
    QA_REPORT = "QA report"
    NOT_RECORDED = "not recorded"
    SECURITY_REPORT = "SEC report"
    SCANNER_RUN = "scanner run"
    VOYAGE_RECORD = "voyage record"
    USAGE_ROLLUP = "usage rollup"


# ---------------------------------------------------------------------------
# QA
# ---------------------------------------------------------------------------

@dataclass
class TestCategoryCounts:
    """One ``### <category> Tests`` subsection's counts.

    ``None`` means the subsection carried no numeric table — not zero.
    """

    name: str
    tests: Optional[int] = None
    passed: Optional[int] = None
    failed: Optional[int] = None

    def to_dict(self) -> Dict[str, Any]:
        return {"name": self.name, "tests": self.tests,
                "passed": self.passed, "failed": self.failed}


@dataclass
class TestCounts:
    """A report's ``## Test Summary`` rollup.

    Every figure is optional. ``tests=None`` says "this report has no parseable
    count", which a surface must render differently from ``tests=0``.
    """

    tests: Optional[int] = None
    passed: Optional[int] = None
    failed: Optional[int] = None
    categories: List[TestCategoryCounts] = field(default_factory=list)

    @property
    def recorded(self) -> bool:
        return (self.tests is not None or self.passed is not None
                or self.failed is not None)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "tests": self.tests, "passed": self.passed, "failed": self.failed,
            "recorded": self.recorded,
            "categories": [c.to_dict() for c in self.categories],
        }


@dataclass
class ACCriterionRow:
    """One acceptance criterion and its recorded result.

    Produced by the QA reader from a report's ``## Acceptance Criteria
    Verification`` table, and by Order B1's ``ac_reader`` from an order's
    ``acceptanceCriteria`` / ``acResults`` fields — the same row shape either
    way, distinguished by :attr:`provenance`.
    """

    id: str = ""
    criterion: str = ""
    status: str = ACStatus.NOT_RECORDED
    raw_status: str = ""
    validation: str = ""
    notes: str = ""
    evidence: str = ""
    provenance: str = Provenance.NOT_RECORDED

    @property
    def met(self) -> bool:
        """True only for an affirmative recorded pass. Absence is never a pass."""
        return self.status in ACStatus.MET

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "criterion": self.criterion, "status": self.status,
            "rawStatus": self.raw_status, "validation": self.validation,
            "notes": self.notes, "evidence": self.evidence,
            "provenance": self.provenance, "met": self.met,
        }


@dataclass
class QAReportSummary:
    """The machine-readable record of one ``reports/qa/*.md`` report.

    Built by :func:`maestro.reports.qa_reader.read_qa_report`. Every field is
    derived from text actually present in the file; a missing section yields an
    empty collection or ``None``, never a fabricated value, and
    :attr:`parse_notes` records what could not be read so a surface can say so
    out loud.
    """

    order_id: str
    verdict: str = Verdict.UNDETERMINED
    #: The literal declaration text the verdict was read from, e.g.
    #: ``"CONDITIONAL — F1 and F3 APPROVED; F2 REJECTED"``. Preserved verbatim
    #: so a normalisation can always be audited against the source.
    raw_verdict: str = ""
    #: Which heading (or document-level declaration) supplied the verdict —
    #: e.g. ``"## QA Decision"``. Empty when the verdict is UNDETERMINED.
    verdict_source: str = ""
    #: ``nodeVerdict`` front-matter, when present and not ``CONSUMED``.
    #: A CORROBORATING HINT ONLY (Captain decision D3) — the dispatcher
    #: rewrites this field to ``CONSUMED`` the moment routing acts on it
    #: (``chart_routing._rewrite_verdict_consumed``), so it is a routing token
    #: with a lifecycle, not a report field. Never the source of truth.
    node_verdict: Optional[str] = None
    ac_rows: List[ACCriterionRow] = field(default_factory=list)
    #: ``maestro.core.role_rejection.Defect`` rows from ``## Defects Found``,
    #: parsed by that module's own parser (never a reimplementation).
    defects: List[Any] = field(default_factory=list)
    test_counts: TestCounts = field(default_factory=TestCounts)
    #: Report file identity — relative to the artefact root, never absolute
    #: (an absolute path on a wire response leaks the operator's filesystem).
    report_name: str = ""
    report_rel: str = ""
    modified: str = ""
    size: int = 0
    truncated: bool = False
    #: Human-readable notes about what could NOT be parsed. Rendered by a
    #: surface as a caveat; never empty-and-silent about a real gap.
    parse_notes: List[str] = field(default_factory=list)

    @property
    def decided(self) -> bool:
        return Verdict.is_decided(self.verdict)

    @property
    def blocking_defects(self) -> List[Any]:
        return [d for d in self.defects if getattr(d, "blocking", False)]

    @property
    def ac_met(self) -> int:
        return sum(1 for r in self.ac_rows if r.met)

    @property
    def ac_not_recorded(self) -> int:
        return sum(1 for r in self.ac_rows if r.status == ACStatus.NOT_RECORDED)

    @property
    def node_verdict_corroborates(self) -> Optional[bool]:
        """Whether :attr:`node_verdict` agrees with :attr:`verdict`.

        ``None`` when there is nothing to compare — no front-matter verdict, or
        an undecided heading verdict. Exposed so a surface can flag a
        disagreement rather than silently preferring one source (plan §7).
        """
        if not self.node_verdict or not self.decided:
            return None
        nv = self.node_verdict.strip().upper()
        if nv in ("PASS", "APPROVED", "OK"):
            return self.verdict in (Verdict.APPROVED, Verdict.CONDITIONAL)
        if nv in ("FAIL", "REJECTED", "BLOCKED"):
            return self.verdict in (Verdict.REJECTED, Verdict.BLOCKED)
        return None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "orderId": self.order_id,
            "verdict": self.verdict,
            "rawVerdict": self.raw_verdict,
            "verdictSource": self.verdict_source,
            "nodeVerdict": self.node_verdict,
            "nodeVerdictCorroborates": self.node_verdict_corroborates,
            "decided": self.decided,
            "acRows": [r.to_dict() for r in self.ac_rows],
            "acMet": self.ac_met,
            "acNotRecorded": self.ac_not_recorded,
            "defects": [d.to_dict() for d in self.defects if hasattr(d, "to_dict")],
            "blockingDefectCount": len(self.blocking_defects),
            "testCounts": self.test_counts.to_dict(),
            "reportName": self.report_name,
            "reportRel": self.report_rel,
            "modified": self.modified,
            "size": self.size,
            "truncated": self.truncated,
            "parseNotes": list(self.parse_notes),
        }


@dataclass
class ParseCoverage:
    """How much of a set of reports actually parsed (plan §3, D3's mitigation).

    Exposed on every list response so parser drift against a heading contract
    nobody enforces becomes *visible* rather than silent. ``undetermined`` is
    reported as its own figure, never subtracted away.
    """

    total: int = 0
    parsed: int = 0
    undetermined: int = 0

    def add(self, decided: bool) -> None:
        self.total += 1
        if decided:
            self.parsed += 1
        else:
            self.undetermined += 1

    def to_dict(self) -> Dict[str, Any]:
        return {"total": self.total, "parsed": self.parsed,
                "undetermined": self.undetermined}


# ---------------------------------------------------------------------------
# AC rollup (populated by Order B1's ac_reader; the shape is fixed here so the
# Hub, the CLI and the PR-body generator agree on it from the start)
# ---------------------------------------------------------------------------

@dataclass
class ACConflict:
    """One criterion the two AC sources recorded differently (FTR-MSO-2026-0733).

    Both sides are kept verbatim — canonical status AND the literal text — so a
    surface can show the disagreement side by side. The row itself carries
    :data:`ACStatus.CONFLICT`; this record is the evidence behind that status.
    """

    id: str
    order_status: str
    order_raw_status: str
    qa_status: str
    qa_raw_status: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "orderStatus": self.order_status,
            "orderRawStatus": self.order_raw_status,
            "qaStatus": self.qa_status,
            "qaRawStatus": self.qa_raw_status,
        }


class ACBucket:
    """Which coverage bucket an order's AC record falls in (FTR-MSO-2026-0734).

    The AC page's headline is COVERAGE, not a pass rate (Captain decision D4),
    so the buckets split along that line first:

    * ``NO_CRITERIA`` — results with no ``acceptanceCriteria`` to judge them
      against. Outside the D4 denominator entirely.
    * ``NOT_COVERED`` — criteria exist, and neither source recorded a result for
      any of them. Its own bucket; never folded into a covered one.
    * ``MET`` / ``PARTIAL`` / ``OUTSTANDING`` — computed over COVERED orders
      only, and together they sum to :attr:`ACCoverage.covered`:

      - ``OUTSTANDING``: at least one criterion recorded ``FAIL``, or the two
        sources recorded it differently (``CONFLICT``). A recorded negative or
        a disputed claim is outstanding work, whatever else passed.
      - ``MET``: every criterion recorded ``PASS``.
      - ``PARTIAL``: everything else — some criterion is ``PARTIAL``, ``SKIP``,
        ``UNDETERMINED`` or still ``NOT RECORDED`` beside the recorded ones.
        An unrecorded criterion keeps an otherwise-passing order out of
        ``MET``; it never pushes it into ``OUTSTANDING``.
    """

    MET = "met"
    PARTIAL = "partial"
    OUTSTANDING = "outstanding"
    NOT_COVERED = "not-covered"
    NO_CRITERIA = "no-criteria"

    COVERED = (MET, PARTIAL, OUTSTANDING)
    ALL = COVERED + (NOT_COVERED, NO_CRITERIA)


@dataclass
class ACOrderRollup:
    """One order's acceptance-criteria verification record.

    Coverage semantics are Captain decision D4 and are load-bearing:
    :attr:`met` / :attr:`failed` / :attr:`partial` are computed over rows that
    have a *recorded* result, and :attr:`not_recorded` is its own bucket. A
    caller must never derive "outstanding" as ``total - met``: that silently
    converts an unrecorded criterion into a failure, the mirror image of the
    error the rule forbids.
    """

    order_id: str
    title: str = ""
    voyage_id: str = ""
    rows: List[ACCriterionRow] = field(default_factory=list)
    #: Sources that contributed rows, in :class:`Provenance` terms.
    sources: List[str] = field(default_factory=list)
    #: Criterion ids where the order JSON and the QA report disagree. Shown as
    #: a conflict, never resolved by preferring one side.
    conflicts: List[str] = field(default_factory=list)
    #: The two recorded values behind each id in :attr:`conflicts`.
    conflict_details: List[ACConflict] = field(default_factory=list)
    #: Whether the order carries ``acceptanceCriteria`` at all. An order with
    #: results and no criteria is a data-integrity case (plan §3 D4), kept
    #: visible rather than dropped.
    has_criteria: bool = False
    #: ``bool(order["acResults"])`` — the exact truthiness test
    #: ``fleet_runner``'s TST deliverable check applies.
    has_order_results: bool = False
    #: Whether a ``reports/qa/`` file references this order, by the same
    #: stem-contains rule as ``fleet_runner._artefact_dir_match_status``.
    qa_report_present: bool = False
    #: The QA report the second source was read from, relative to the
    #: artefact root (never absolute). Empty when there is none.
    qa_report_rel: str = ""
    parse_notes: List[str] = field(default_factory=list)

    @property
    def total(self) -> int:
        return len(self.rows)

    @property
    def recorded(self) -> int:
        return sum(1 for r in self.rows if r.status != ACStatus.NOT_RECORDED)

    @property
    def met(self) -> int:
        return sum(1 for r in self.rows if r.status == ACStatus.PASS)

    @property
    def failed(self) -> int:
        return sum(1 for r in self.rows if r.status == ACStatus.FAIL)

    @property
    def partial(self) -> int:
        return sum(1 for r in self.rows if r.status == ACStatus.PARTIAL)

    @property
    def not_recorded(self) -> int:
        return sum(1 for r in self.rows if r.status == ACStatus.NOT_RECORDED)

    @property
    def conflicted(self) -> int:
        return sum(1 for r in self.rows if r.status == ACStatus.CONFLICT)

    @property
    def covered(self) -> bool:
        """Whether at least one criterion carries a recorded result (D4)."""
        return self.recorded > 0

    @property
    def evidence_present(self) -> bool:
        """``fleet_runner``'s TST-deliverable reading: results OR a QA file.

        Deliberately weaker than :attr:`covered` — a QA report can exist with
        no parseable AC table — and exposed separately so the two figures are
        never conflated.
        """
        return self.has_order_results or self.qa_report_present

    @property
    def coverage_bucket(self) -> str:
        """This order's :class:`ACBucket` — see that class for the rules."""
        if not self.has_criteria:
            return ACBucket.NO_CRITERIA
        if not self.covered:
            return ACBucket.NOT_COVERED
        if self.failed or self.conflicted:
            return ACBucket.OUTSTANDING
        if self.met == self.total:
            return ACBucket.MET
        return ACBucket.PARTIAL

    def to_dict(self) -> Dict[str, Any]:
        return {
            "orderId": self.order_id, "title": self.title,
            "coverageBucket": self.coverage_bucket,
            "voyageId": self.voyage_id,
            "rows": [r.to_dict() for r in self.rows],
            "sources": list(self.sources), "conflicts": list(self.conflicts),
            "conflictDetails": [c.to_dict() for c in self.conflict_details],
            "total": self.total, "recorded": self.recorded, "met": self.met,
            "failed": self.failed, "partial": self.partial,
            "notRecorded": self.not_recorded, "conflicted": self.conflicted,
            "covered": self.covered, "hasCriteria": self.has_criteria,
            "hasOrderResults": self.has_order_results,
            "qaReportPresent": self.qa_report_present,
            "evidencePresent": self.evidence_present,
            "qaReportRel": self.qa_report_rel,
            "parseNotes": list(self.parse_notes),
        }


@dataclass
class ACCoverage:
    """Workspace-level AC coverage — the AC page's headline (Captain decision D4).

    ``covered`` is "N of ``orders_with_criteria`` have a recorded verification";
    ``not_covered`` is its own bucket and is reported, never subtracted away.
    ``results_without_criteria`` counts the data-integrity case of results for
    criteria that were never written down — outside the denominator, visible.
    """

    orders_with_criteria: int = 0
    covered: int = 0
    not_covered: int = 0
    covered_by_order_results: int = 0
    covered_by_qa_report: int = 0
    evidence_present: int = 0
    orders_with_conflicts: int = 0
    results_without_criteria: int = 0
    #: FTR-MSO-2026-0734: the covered orders split by :class:`ACBucket`.
    #: ``met + partial + outstanding == covered`` always — computed over
    #: covered orders only, so an unrecorded order can never dilute or inflate
    #: them (D4).
    met: int = 0
    partial: int = 0
    outstanding: int = 0
    #: Per-criterion status tally over the rows of COVERED orders only, keyed by
    #: :class:`ACStatus`. NOT RECORDED rows inside a covered order are counted
    #: here under their own key — visible, never merged into another status.
    covered_criteria_status: Dict[str, int] = field(default_factory=dict)

    def add(self, rollup: "ACOrderRollup") -> None:
        if not rollup.has_criteria:
            if rollup.has_order_results:
                self.results_without_criteria += 1
            return
        self.orders_with_criteria += 1
        if rollup.evidence_present:
            self.evidence_present += 1
        if rollup.conflicts:
            self.orders_with_conflicts += 1
        if not rollup.covered:
            self.not_covered += 1
            return
        self.covered += 1
        bucket = rollup.coverage_bucket
        if bucket == ACBucket.MET:
            self.met += 1
        elif bucket == ACBucket.OUTSTANDING:
            self.outstanding += 1
        else:
            self.partial += 1
        for row in rollup.rows:
            self.covered_criteria_status[row.status] = (
                self.covered_criteria_status.get(row.status, 0) + 1)
        provs = {r.provenance for r in rollup.rows
                 if r.status != ACStatus.NOT_RECORDED}
        if Provenance.ORDER_RESULTS in provs:
            self.covered_by_order_results += 1
        if Provenance.QA_REPORT in provs:
            self.covered_by_qa_report += 1

    def to_dict(self) -> Dict[str, Any]:
        return {
            "ordersWithCriteria": self.orders_with_criteria,
            "covered": self.covered, "notCovered": self.not_covered,
            "coveredByOrderResults": self.covered_by_order_results,
            "coveredByQaReport": self.covered_by_qa_report,
            "evidencePresent": self.evidence_present,
            "ordersWithConflicts": self.orders_with_conflicts,
            "resultsWithoutCriteria": self.results_without_criteria,
            "met": self.met, "partial": self.partial,
            "outstanding": self.outstanding,
            "coveredCriteriaStatus": dict(self.covered_criteria_status),
        }


# ---------------------------------------------------------------------------
# Security (populated by Order B3's security_reader)
# ---------------------------------------------------------------------------

class ScannerTrust:
    """How far a :class:`ScannerRun`'s counts can be believed (FTR-MSO-2026-0735).

    There is **no TRUSTED member, on purpose.** Nothing a report reader can see
    in a ``REVIEW-*.md`` file establishes that a regex scanner's counts describe
    real risk, so the best any run can earn is ``UNVERIFIED``. What the reader
    *can* establish is the opposite — a run whose own listed findings carry a
    known false-positive signature is ``KNOWN_UNTRUSTED``, with the evidence
    named on :attr:`ScannerRun.untrusted_reasons`.
    """

    KNOWN_UNTRUSTED = "KNOWN-UNTRUSTED"
    UNVERIFIED = "UNVERIFIED"

    ALL = (KNOWN_UNTRUSTED, UNVERIFIED)


def finding_dict_keys() -> List[str]:
    """The key set of :meth:`maestro.security.owasp_patterns.Finding.to_dict`.

    Read from the scanner's own ``Finding`` at call time rather than copied, so
    a field added to the scanner's JSON appears on :class:`ReportedFinding` too
    (as ``None``) and the Hub's security shape and the scanner's JSON can never
    diverge (plan §4). Imported lazily: ``owasp_patterns`` compiles its pattern
    table at import, which a caller that never touches findings should not pay.
    """
    from maestro.security.owasp_patterns import Finding, Severity

    probe = Finding(id="", cwe="", owasp_category="", title="",
                    severity=Severity.INFO, file="", line=0, column=0,
                    snippet="", remediation="")
    return list(probe.to_dict().keys())


def _camel_to_snake(key: str) -> str:
    out: List[str] = []
    for ch in key:
        if ch.isupper():
            out.append("_")
            out.append(ch.lower())
        else:
            out.append(ch)
    return "".join(out)


@dataclass
class ReportedFinding:
    """A finding as a markdown report *wrote it down* — not as a scanner emitted it.

    Carries the same fields as :class:`maestro.security.owasp_patterns.Finding`
    and serialises under exactly its ``to_dict()`` key names, but every field is
    ``Optional``: a hand-written ``### F1 - MEDIUM: …`` heading records an id, a
    severity and a title and nothing else, and filling ``column=0`` or
    ``waived=False`` to satisfy the scanner's constructor would be inventing
    facts the report never stated (plan §7). ``baseSeverity`` /
    ``adjustedSeverity`` stay ``None`` for the same reason — a report states one
    severity, not the scanner's base-vs-adjusted pair.
    """

    id: Optional[str] = None
    cwe: Optional[str] = None
    owasp_category: Optional[str] = None
    title: Optional[str] = None
    severity: Optional[str] = None
    base_severity: Optional[str] = None
    adjusted_severity: Optional[str] = None
    file: Optional[str] = None
    line: Optional[int] = None
    column: Optional[int] = None
    snippet: Optional[str] = None
    remediation: Optional[str] = None
    waived: Optional[bool] = None
    waiver_reason: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {key: getattr(self, _camel_to_snake(key), None)
                for key in finding_dict_keys()}


@dataclass
class SecurityReportSummary:
    """One hand-written ``reports/security/SEC-{ORDER-ID}.md`` record.

    Deliberately separate from :class:`ScannerRun`. Plan §1.4 measured these as
    three incompatible populations, and the SEC family is the weak one: no
    front-matter at all, ``## Security Decision`` in 20 of 35 files, verdict
    prose ranging from ``**Status**: Secure`` to
    ``**Status**: PARTIALLY MODERNISED``. ``UNDETERMINED`` will be the honest
    answer for a real fraction of them, and that is the intended output — not a
    defect in the reader.

    Reports written since FTR-MSO-2026-0779 open with a ``secVerdict``
    front-matter field that the reader treats as authoritative;
    :attr:`verdict_basis` says which path decided each record.
    """

    order_id: str
    verdict: str = Verdict.UNDETERMINED
    raw_verdict: str = ""
    verdict_source: str = ""
    #: Which reader path decided :attr:`verdict` — ``front-matter`` (the
    #: ``secVerdict`` field, FTR-MSO-2026-0779), ``heuristic`` (the heading
    #: cascade, for reports without the field), ``json`` (a ``.json`` SEC
    #: artefact) — or ``""`` when the report could not be read at all.
    verdict_basis: str = ""
    findings: List[ReportedFinding] = field(default_factory=list)
    report_name: str = ""
    report_rel: str = ""
    modified: str = ""
    #: The suffix after the order id in the filename — ``LEAD-INDEPENDENT``,
    #: ``RETRY``, ``LEAD-ACCEPTED`` — or ``""`` for the canonical
    #: ``SEC-{ORDER-ID}.md``. One order can carry several SEC documents that
    #: disagree (a crew APPROVED, an independent LEAD review REJECTED); the
    #: variant keeps them distinguishable instead of one silently winning.
    variant: str = ""
    size: int = 0
    truncated: bool = False
    parse_notes: List[str] = field(default_factory=list)

    @property
    def decided(self) -> bool:
        return Verdict.is_decided(self.verdict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "orderId": self.order_id, "verdict": self.verdict,
            "rawVerdict": self.raw_verdict, "verdictSource": self.verdict_source,
            "verdictBasis": self.verdict_basis,
            "decided": self.decided,
            "findings": [f.to_dict() for f in self.findings if hasattr(f, "to_dict")],
            "reportName": self.report_name, "reportRel": self.report_rel,
            "modified": self.modified, "variant": self.variant,
            "size": self.size, "truncated": self.truncated,
            "parseNotes": list(self.parse_notes),
        }


@dataclass
class ScannerRun:
    """One ``reports/security/REVIEW-{timestamp}.md`` scanner run.

    A **run record**, never a fleet risk posture. Plan §1.1 pinned why: a
    sampled HIGH from ``REVIEW-20260807T214608Z.md`` was *"Literal path
    traversal sequence in string"* fired on the ``...`` inside
    ``print("Loading scanner counts...")``, and the run scanned the artefact
    plane including its own tooling. The counts are real numbers about a real
    execution and are simultaneously wrong by orders of magnitude about risk.
    :attr:`counts_trustworthy` exists so no surface can quietly forget that —
    it defaults to ``False``, and Order B4's acceptance criteria forbid deriving
    a severity KPI from these.
    """

    run_id: str
    ran_at: str = ""
    files_scanned: Optional[int] = None
    counts_by_severity: Dict[str, int] = field(default_factory=dict)
    report_name: str = ""
    report_rel: str = ""
    counts_trustworthy: bool = False
    caveat: str = ""
    #: :class:`ScannerTrust` — ``UNVERIFIED`` unless the run's own listed
    #: findings prove otherwise. Never a "trusted" value; see that class.
    trust: str = ScannerTrust.UNVERIFIED
    #: The evidence behind ``KNOWN_UNTRUSTED``, one sentence per signature,
    #: each naming a concrete finding from the file.
    untrusted_reasons: List[str] = field(default_factory=list)
    #: The ``**Diff target**`` label as written. A LABEL ONLY: the scanner that
    #: writes these files walks the whole tree regardless of it.
    diff_target: str = ""
    #: The scanner's own ``**Status**`` line — a mechanical function of the
    #: counts (any CRITICAL/HIGH => REJECTED), NOT a security review verdict,
    #: and never to be rendered beside :class:`SecurityReportSummary` verdicts
    #: as if it were one.
    scanner_decision: str = ""
    #: A bounded sample of the findings the file lists, for showing *why* a run
    #: is untrusted. Never the full set, and never a source for a count.
    sample_findings: List[ReportedFinding] = field(default_factory=list)
    modified: str = ""
    size: int = 0
    truncated: bool = False
    parse_notes: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "runId": self.run_id, "ranAt": self.ran_at,
            "filesScanned": self.files_scanned,
            "countsBySeverity": dict(self.counts_by_severity),
            "reportName": self.report_name, "reportRel": self.report_rel,
            "countsTrustworthy": self.counts_trustworthy, "caveat": self.caveat,
            "trust": self.trust,
            "untrustedReasons": list(self.untrusted_reasons),
            "diffTarget": self.diff_target,
            "scannerDecision": self.scanner_decision,
            "sampleFindings": [f.to_dict() for f in self.sample_findings],
            "modified": self.modified, "size": self.size,
            "truncated": self.truncated, "parseNotes": list(self.parse_notes),
        }


# ---------------------------------------------------------------------------
# Voyage (populated by Order B5's voyage_reader)
# ---------------------------------------------------------------------------

class UsageStatus:
    """Whether a voyage's spend could be read (FTR-MSO-2026-0737).

    ``NOT_RECORDED`` is D4's rule applied to spend: a voyage whose orders left
    no usage record has *no figure*, and rendering ``0 tokens`` for it would be
    a claim that the fleet did the work for free. ``UNAVAILABLE`` is the
    different case where the aggregator itself could not run (the Hub extra is
    absent, or it raised) — nobody knows whether usage exists.
    """

    RECORDED = "recorded"
    NOT_RECORDED = "not-recorded"
    UNAVAILABLE = "unavailable"

    ALL = (RECORDED, NOT_RECORDED, UNAVAILABLE)


#: The tally key for an order with no QA report at all. Deliberately not a
#: :class:`Verdict` token — "no QA was done" is not a verdict, and folding it
#: into ``UNDETERMINED`` would say a report exists that could not be read.
NO_QA_REPORT = "NO REPORT"

#: The tally key for an order carrying neither ``acceptanceCriteria`` nor
#: ``acResults`` — outside :class:`ACBucket` exactly as it is outside the AC page.
NO_AC_RECORD = "no-ac-record"


@dataclass
class UsageShare:
    """One slice of a voyage's spend — a role, or a crew slot.

    Every figure is summed by the usage aggregator's own per-iteration reader;
    nothing here is estimated. ``key`` is the role code or the crew number as a
    string; an iteration that recorded no crew number is keyed
    ``"not recorded"`` rather than attributed to a crew it may not have been.
    """

    key: str
    label: str = ""
    total_tokens: int = 0
    estimated_cost_usd: float = 0.0
    order_count: int = 0
    iterations: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "key": self.key, "label": self.label or self.key,
            "totalTokens": self.total_tokens,
            "estimatedCostUsd": round(self.estimated_cost_usd, 4),
            "orderCount": self.order_count, "iterations": self.iterations,
        }


@dataclass
class VoyageUsage:
    """A voyage's spend, as the usage aggregator reports it.

    Totals are ``None`` unless :attr:`status` is ``RECORDED`` — never ``0``.
    The role and crew breakdowns come from per-iteration usage records, which
    older orders do not carry; :attr:`orders_with_iteration_data` against
    :attr:`orders_with_usage` says how much of the total the breakdown covers,
    so a surface never presents a partial breakdown as the whole spend.
    """

    status: str = UsageStatus.NOT_RECORDED
    total_tokens: Optional[int] = None
    estimated_cost_usd: Optional[float] = None
    orders_with_usage: int = 0
    orders_with_iteration_data: int = 0
    roles: List[UsageShare] = field(default_factory=list)
    crews: List[UsageShare] = field(default_factory=list)
    note: str = ""
    #: ``{order_id: (tokens, cost_usd)}`` for each order the aggregator found
    #: usage for. Not serialised here — it is projected onto each
    #: :class:`VoyageOrderEntry` instead, so it reaches the wire exactly once.
    order_totals: Dict[str, Tuple[int, float]] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        recorded = self.status == UsageStatus.RECORDED
        return {
            "status": self.status,
            "totalTokens": self.total_tokens if recorded else None,
            "estimatedCostUsd": (round(self.estimated_cost_usd, 4)
                                 if recorded and self.estimated_cost_usd is not None
                                 else None),
            "ordersWithUsage": self.orders_with_usage,
            "ordersWithIterationData": self.orders_with_iteration_data,
            "roles": [r.to_dict() for r in self.roles],
            "crews": [c.to_dict() for c in self.crews],
            "note": self.note,
        }


@dataclass
class SecurityVerdictRef:
    """One SEC document's verdict, as a voyage report row carries it.

    A projection of :class:`SecurityReportSummary` — every SEC document for the
    order, never a single winner, because an order's crew review and an
    independent LEAD review can disagree.
    """

    verdict: str = Verdict.UNDETERMINED
    decided: bool = False
    variant: str = ""
    report_rel: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {"verdict": self.verdict, "decided": self.decided,
                "variant": self.variant, "reportRel": self.report_rel}


@dataclass
class VoyageOrderEntry:
    """One member order of a voyage, composed from the records that name it.

    Every ``None`` here means *not recorded*, and each is distinct from a
    negative: ``qa_verdict=None`` is "no QA report exists" (whereas
    ``UNDETERMINED`` is "a report exists and could not be read"),
    ``ac_bucket=None`` is "the order carries no criteria and no results",
    ``usage_tokens=None`` is "no usage record", never zero spend.
    """

    order_id: str
    title: str = ""
    order_type: str = ""
    #: Where the order was found: ``complete`` / ``failed`` / ``queue:<name>``,
    #: or ``""`` when no order JSON exists for an id the manifest lists.
    location: str = ""
    found: bool = False
    status: str = ""
    #: ``order`` when :attr:`status` came from the order JSON, ``voyage record``
    #: when only the manifest carried one, ``""`` when neither did.
    status_source: str = ""
    qa_report_present: bool = False
    qa_verdict: Optional[str] = None
    qa_decided: bool = False
    qa_report_rel: str = ""
    qa_blocking_defects: int = 0
    ac_bucket: Optional[str] = None
    ac_total: int = 0
    ac_recorded: int = 0
    ac_met: int = 0
    ac_not_recorded: int = 0
    ac_conflicted: int = 0
    security: List[SecurityVerdictRef] = field(default_factory=list)
    usage_tokens: Optional[int] = None
    usage_cost_usd: Optional[float] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "orderId": self.order_id, "title": self.title,
            "orderType": self.order_type, "location": self.location,
            "found": self.found, "status": self.status,
            "statusSource": self.status_source,
            "qaReportPresent": self.qa_report_present,
            "qaVerdict": self.qa_verdict, "qaDecided": self.qa_decided,
            "qaReportRel": self.qa_report_rel,
            "qaBlockingDefects": self.qa_blocking_defects,
            "acBucket": self.ac_bucket, "acTotal": self.ac_total,
            "acRecorded": self.ac_recorded, "acMet": self.ac_met,
            "acNotRecorded": self.ac_not_recorded,
            "acConflicted": self.ac_conflicted,
            "security": [s.to_dict() for s in self.security],
            "usageTokens": self.usage_tokens,
            "usageCostUsd": (round(self.usage_cost_usd, 4)
                             if self.usage_cost_usd is not None else None),
        }


@dataclass
class VoyageNarrative:
    """A free-form ``reports/voyage/*`` document that belongs to a voyage.

    LINKED, NEVER PARSED (plan §5 B5). Seven of these exist, five ADM-era, all
    free prose; no number is ever read out of one. ``matched_by`` is the id the
    filename contains — the voyage's own id, or one of its member orders'.
    """

    name: str
    report_rel: str = ""
    matched_by: str = ""
    #: Set when the match was a member ORDER id, so a surface can reach the
    #: document through that order's artefact manifest.
    order_id: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {"name": self.name, "reportRel": self.report_rel,
                "matchedBy": self.matched_by, "orderId": self.order_id}


@dataclass
class VoyageReportSummary:
    """A voyage report COMPOSED ON READ (Captain decision D2).

    There is no producer artefact and there must not be one: every input
    already exists on disk (``voyages/{active,complete}/*.json`` for the
    manifest and PR state, ``aggregator.aggregate_usage_for_voyage`` for spend,
    this package's QA reader for verdicts), and composing lights up *every*
    voyage in the workspace on day one where a new artefact would cover only
    voyages closing after it shipped.

    A genuinely unavailable field stays ``None`` / empty. Per plan §6 the
    voyage report does not compute blockage — that is FTR-MSO-2026-0700's
    ``Blockage`` record, served by its own route — so :attr:`blockages` stays
    empty and is not put on the wire.

    :attr:`composed` separates the two ways a record is built. An INDEX entry
    (``composed=False``) carries the manifest only — its ``orders`` and
    ``usage`` were never read, so their emptiness means nothing. A DETAIL record
    (``composed=True``) has read every member order's QA / AC / SEC record and
    the usage aggregator, so an absence there is a finding.
    """

    voyage_id: str
    title: str = ""
    branch: str = ""
    status: str = ""
    pr_number: Optional[int] = None
    merged: Optional[bool] = None
    started_date: str = ""
    completed_date: str = ""
    order_ids: List[str] = field(default_factory=list)
    qa_summaries: List[QAReportSummary] = field(default_factory=list)
    ac_rollups: List[ACOrderRollup] = field(default_factory=list)
    usage: Optional[VoyageUsage] = None
    blockages: List[Any] = field(default_factory=list)
    parse_notes: List[str] = field(default_factory=list)
    project: str = ""
    #: ``active`` or ``complete`` — which ``voyages/`` directory holds it.
    location: str = ""
    pr_url: str = ""
    merged_at: str = ""
    created_at: str = ""
    manifest_rel: str = ""
    composed: bool = False
    orders: List[VoyageOrderEntry] = field(default_factory=list)
    narratives: List[VoyageNarrative] = field(default_factory=list)

    def sort_key(self) -> tuple:
        """Newest first when sorted descending: the latest date the manifest
        records, then the id. A voyage recording no date sorts last."""
        date = max((d for d in (self.completed_date, self.merged_at,
                                self.started_date, self.created_at) if d),
                   default="")
        return (date[:10], self.voyage_id)

    def qa_verdict_counts(self) -> Dict[str, int]:
        counts: Dict[str, int] = {}
        for entry in self.orders:
            key = entry.qa_verdict if entry.qa_verdict is not None else NO_QA_REPORT
            counts[key] = counts.get(key, 0) + 1
        return counts

    def ac_bucket_counts(self) -> Dict[str, int]:
        counts: Dict[str, int] = {}
        for entry in self.orders:
            key = entry.ac_bucket if entry.ac_bucket is not None else NO_AC_RECORD
            counts[key] = counts.get(key, 0) + 1
        return counts

    def to_dict(self) -> Dict[str, Any]:
        return {
            "voyageId": self.voyage_id, "title": self.title,
            "branch": self.branch, "status": self.status,
            "prNumber": self.pr_number, "merged": self.merged,
            "startedDate": self.started_date,
            "completedDate": self.completed_date,
            "orderIds": list(self.order_ids),
            "qaSummaries": [q.to_dict() for q in self.qa_summaries],
            "acRollups": [a.to_dict() for a in self.ac_rollups],
            "usage": self.usage.to_dict() if self.usage is not None else None,
            "parseNotes": list(self.parse_notes),
            "project": self.project, "location": self.location,
            "prUrl": self.pr_url, "mergedAt": self.merged_at,
            "createdAt": self.created_at, "manifestRel": self.manifest_rel,
            "composed": self.composed,
            "orders": [o.to_dict() for o in self.orders],
            "narratives": [n.to_dict() for n in self.narratives],
            "qaVerdictCounts": self.qa_verdict_counts() if self.composed else {},
            "acBucketCounts": self.ac_bucket_counts() if self.composed else {},
        }


__all__ = [
    "ACBucket", "ACConflict", "ACCoverage",
    "ACCriterionRow", "ACOrderRollup", "ACStatus", "ParseCoverage",
    "NO_AC_RECORD", "NO_QA_REPORT",
    "Provenance", "QAReportSummary", "ReportedFinding", "ScannerRun",
    "ScannerTrust", "SecurityReportSummary", "SecurityVerdictRef",
    "TestCategoryCounts", "TestCounts", "UsageShare", "UsageStatus",
    "Verdict", "VoyageNarrative", "VoyageOrderEntry", "VoyageReportSummary",
    "VoyageUsage", "finding_dict_keys",
]
