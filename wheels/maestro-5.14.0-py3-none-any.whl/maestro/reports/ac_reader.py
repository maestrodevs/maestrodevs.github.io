# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Acceptance-criteria normaliser and two-source join (FTR-MSO-2026-0733 — PLAN §5, Order B1).

**What this reads.** An order's verification record lives in up to three
places, none of them consistently shaped:

1. ``acceptanceCriteria`` on the order JSON — **two container shapes**: a list
   of plain strings (the majority) or a list of dicts
   (``{id, description, validationType}`` plus minor variants that add
   ``command`` / ``status`` / ``result`` / ``note`` / ``verifiedBy``).
2. ``acResults`` on the order JSON — **fifteen list-of-dict key-sets** measured
   on the live plane (``id,notes,status`` up to
   ``checkedAt,id,notes,revalidatedAt,revalidatedBy,status,validationType``,
   one family writing ``result`` instead of ``status``), plus **two orders that
   store a dict keyed by criterion id** — one mapping to ``{status, notes}``
   dicts, one mapping straight to a status string.
3. The QA report's ``## Acceptance Criteria Verification`` table, read through
   :mod:`maestro.reports.qa_reader` — a legitimate SECOND source (plan §1.5:
   it lifts measured coverage from 119 to ~204 of 494 orders).

**Normalisation is by key role, never by key-set.** Every observed key-set is a
combination of the same handful of roles (id / status-or-result / criterion-or-
description / notes-or-note / validationType / checked-at / checked-by), so a
synonym lookup per role handles all seventeen shapes without a branch per shape
— and a sixteenth key-set that reuses those names needs no code change.

**Ids are joined on a canonical key.** String criteria carry no id at all; the
fleet's convention (TST.md's ac_validation workflow) numbers them ``ac-01``,
``ac-02`` … by position, and results and QA tables write the same criterion as
``ac-01``, ``AC-1``, ``1`` or ``#1``. :func:`canonical_ac_id` folds all of those
to one key. A non-numeric id (``AC-SEC-1``) is kept as itself, lower-cased — it
is joined only to an identical id, never guessed.

**The honesty rule (plan §7), mechanically:**

* A row with no recorded result is :data:`ACStatus.NOT_RECORDED` with
  :data:`Provenance.NOT_RECORDED`. That pairing is an invariant: a
  NOT RECORDED row never claims a source, and a row claiming a source always
  has something recorded from it.
* Two sources that recorded *readable, different* results yield
  :data:`ACStatus.CONFLICT` plus an :class:`~maestro.reports.models.ACConflict`
  carrying both sides verbatim. Neither side is preferred.
* A readable result on one side and an unreadable or empty one on the other is
  NOT a conflict — an unreadable cell is not a competing claim — but the other
  side's literal text is kept on the row's ``notes`` so nothing is hidden.
* Results for an id that no criterion carries are emitted as their own rows,
  with a parse note, rather than dropped or attached to a guessed criterion.

**Coverage agrees with the dispatcher.** :attr:`ACOrderRollup.has_order_results`
is ``bool(order["acResults"])`` and :attr:`ACOrderRollup.qa_report_present`
applies the stem-contains rule, which together are exactly
``fleet_runner``'s TST deliverable reading (``acResults`` OR
``_artefact_dir_match_status(order, reports/qa)``). QA-file discovery goes
through :mod:`maestro.hub.artefacts`; the one scoping difference (discovery
recurses one level into an id-named subdirectory, ``fleet_runner`` uses
``rglob``) is immaterial for ``reports/qa/``, whose only subdirectory is the
empty ``charters/``.

Imports no web framework (plan §12 note 2).
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

from maestro.hub.artefacts import discover_report_paths, find_order_file, iter_order_files
from maestro.reports import qa_reader
from maestro.reports.models import (
    ACConflict,
    ACCoverage,
    ACCriterionRow,
    ACOrderRollup,
    ACStatus,
    Provenance,
    QAReportSummary,
)

__all__ = [
    "NormalisedCriterion",
    "NormalisedResult",
    "build_ac_rollup",
    "canonical_ac_id",
    "join_criterion",
    "list_ac_rollups",
    "normalise_ac_results",
    "normalise_acceptance_criteria",
    "read_order_ac",
]


# ---------------------------------------------------------------------------
# Key-role synonym tables — built from the live census, not guessed
# ---------------------------------------------------------------------------

_ID_KEYS = ("id", "acId", "criterionId", "ac")
#: ``status`` before ``result``: no observed row carries both, but if one ever
#: does the key the TST role mandates is the one honoured.
_STATUS_KEYS = ("status", "result", "outcome", "verdict")
_CRITERION_KEYS = ("criterion", "description", "text", "title")
_NOTES_KEYS = ("notes", "note", "evidence", "comment")
_VALIDATION_KEYS = ("validationType", "validation")
_CHECKED_AT_KEYS = ("revalidatedAt", "checkedAt")
_CHECKED_BY_KEYS = ("revalidatedBy", "checkedBy", "verifiedBy")

_NUMERIC_ID_RE = re.compile(r"^(?:ac|criterion|c)?[\s#_.\-]*0*(\d+)[.)]?$",
                            re.IGNORECASE)


def _first(d: Dict[str, Any], keys: Sequence[str]) -> Tuple[bool, Any]:
    """``(present, value)`` for the first of *keys* that *d* carries."""
    for key in keys:
        if key in d:
            return True, d[key]
    return False, None


def _text(value: Any) -> str:
    """A cell as text. ``None`` is empty; nothing is coerced into a status."""
    if value is None:
        return ""
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, (list, tuple)):
        return "; ".join(_text(v) for v in value if v is not None)
    return str(value).strip()


def canonical_ac_id(raw: Any) -> str:
    """The join key for a criterion id.

    ``ac-01``, ``AC-1``, ``1``, ``#1`` and ``ac_001`` are one criterion
    (``"ac-1"``). Anything that is not a bare ordinal is lower-cased and kept —
    ``AC-SEC-1`` joins only to ``ac-sec-1``. Empty in, empty out.
    """
    text = qa_reader._strip_md(_text(raw)).strip().strip("*`").strip()
    if not text:
        return ""
    m = _NUMERIC_ID_RE.match(text)
    if m:
        return f"ac-{int(m.group(1))}"
    return " ".join(text.lower().split())


def _positional_id(index: int) -> str:
    return f"ac-{index + 1:02d}"


def _text_key(text: str) -> str:
    return " ".join(qa_reader._strip_md(text or "").lower().split())


# ---------------------------------------------------------------------------
# Normalised inputs
# ---------------------------------------------------------------------------

@dataclass
class NormalisedCriterion:
    """One entry of ``acceptanceCriteria``, whichever container shape it came in."""

    key: str
    id: str
    criterion: str = ""
    validation: str = ""
    #: ``True`` when the id was assigned by position (a string criterion, or a
    #: dict criterion with no id) rather than read from the order.
    positional: bool = False
    #: A result recorded INLINE on the criterion dict (``status`` / ``result``),
    #: or ``None`` when the criterion carries no such key.
    inline_result: Optional["NormalisedResult"] = None


@dataclass
class NormalisedResult:
    """One recorded result, from ``acResults`` or inline on a criterion."""

    key: str
    id: str
    status: str
    raw_status: str = ""
    criterion: str = ""
    notes: str = ""
    validation: str = ""
    checked_at: str = ""
    checked_by: str = ""


def normalise_acceptance_criteria(raw: Any) -> Tuple[List[NormalisedCriterion], List[str]]:
    """``(criteria, parse_notes)`` for either ``acceptanceCriteria`` container shape.

    * list of strings — each gets the positional id ``ac-NN``;
    * list of dicts — ``id`` is read (positional fallback, noted), the text from
      ``description``/``criterion``, and an inline ``status``/``result`` becomes
      :attr:`NormalisedCriterion.inline_result`;
    * a dict keyed by id — tolerated the same way ``acResults`` is.

    Anything else is skipped with a note; never raises.
    """
    notes: List[str] = []
    out: List[NormalisedCriterion] = []
    if raw is None or raw == "" or raw == [] or raw == {}:
        return out, notes

    if isinstance(raw, dict):
        items: List[Tuple[Optional[str], Any]] = [(str(k), v) for k, v in raw.items()]
    elif isinstance(raw, (list, tuple)):
        items = [(None, v) for v in raw]
    else:
        return out, [f"acceptanceCriteria is a {type(raw).__name__}, not a list — ignored."]

    seen: Dict[str, int] = {}
    for index, (dict_key, item) in enumerate(items):
        if isinstance(item, str) or (dict_key is not None and not isinstance(item, dict)):
            ident = dict_key or _positional_id(index)
            crit = NormalisedCriterion(key=canonical_ac_id(ident), id=ident,
                                       criterion=_text(item),
                                       positional=dict_key is None)
        elif isinstance(item, dict):
            has_id, raw_id = _first(item, _ID_KEYS)
            ident = _text(raw_id) if has_id else ""
            positional = not ident and dict_key is None
            if not ident:
                ident = dict_key or _positional_id(index)
            _, crit_text = _first(item, _CRITERION_KEYS)
            _, validation = _first(item, _VALIDATION_KEYS)
            crit = NormalisedCriterion(key=canonical_ac_id(ident), id=ident,
                                       criterion=_text(crit_text),
                                       validation=_text(validation),
                                       positional=positional)
            if positional:
                notes.append(f"acceptanceCriteria[{index}] has no id — "
                             f"numbered {ident} by position.")
            has_status, _ = _first(item, _STATUS_KEYS)
            if has_status:
                crit.inline_result = _result_from_dict(crit.id, item)
        else:
            notes.append(f"acceptanceCriteria[{index}] is a {type(item).__name__} — ignored.")
            continue

        if crit.key in seen:
            notes.append(f"Duplicate criterion id {crit.id!r} — kept both; "
                         "only the first is joined to results.")
            crit.key = f"{crit.key}#dup{index}"
        seen[crit.key] = index
        out.append(crit)
    return out, notes


def _result_from_dict(ident: str, item: Dict[str, Any]) -> NormalisedResult:
    _, raw_status = _first(item, _STATUS_KEYS)
    _, crit_text = _first(item, _CRITERION_KEYS)
    _, notes = _first(item, _NOTES_KEYS)
    _, validation = _first(item, _VALIDATION_KEYS)
    _, checked_at = _first(item, _CHECKED_AT_KEYS)
    _, checked_by = _first(item, _CHECKED_BY_KEYS)
    raw = _text(raw_status)
    return NormalisedResult(
        key=canonical_ac_id(ident), id=ident,
        status=ACStatus.normalise(raw), raw_status=raw,
        criterion=_text(crit_text), notes=_text(notes),
        validation=_text(validation), checked_at=_text(checked_at),
        checked_by=_text(checked_by),
    )


def normalise_ac_results(raw: Any) -> Tuple[Dict[str, NormalisedResult], List[str]]:
    """``({canonical_key: result}, parse_notes)`` for every ``acResults`` shape.

    Handles the list-of-dict key-sets by role (see module docstring) and both
    dict-keyed forms (``{"ac-01": {"status": ...}}`` and
    ``{"ac-01": "PASS"}``). A missing or ``null`` status is
    :data:`ACStatus.NOT_RECORDED` — never a pass. A result with no id is keyed
    by position and noted. When the same id is recorded twice the LATER entry
    is kept (a re-validation appends) and the replacement is noted.
    """
    notes: List[str] = []
    out: Dict[str, NormalisedResult] = {}
    if raw is None or raw == "" or raw == [] or raw == {}:
        return out, notes

    entries: List[NormalisedResult] = []
    if isinstance(raw, dict):
        for key, value in raw.items():
            ident = str(key)
            if isinstance(value, dict):
                has_id, inner = _first(value, _ID_KEYS)
                if has_id and _text(inner) and canonical_ac_id(inner) != canonical_ac_id(ident):
                    notes.append(f"acResults[{ident!r}] carries a different inner id "
                                 f"{_text(inner)!r} — the dict key is used.")
                entries.append(_result_from_dict(ident, value))
            else:
                text = _text(value)
                entries.append(NormalisedResult(key=canonical_ac_id(ident), id=ident,
                                                status=ACStatus.normalise(text),
                                                raw_status=text))
    elif isinstance(raw, (list, tuple)):
        for index, item in enumerate(raw):
            if isinstance(item, dict):
                has_id, raw_id = _first(item, _ID_KEYS)
                ident = _text(raw_id) if has_id else ""
                if not ident:
                    ident = _positional_id(index)
                    notes.append(f"acResults[{index}] has no id — numbered {ident} by position.")
                entries.append(_result_from_dict(ident, item))
            else:
                # Never observed. Kept visible as an unreadable result rather
                # than guessed at: a bare "PASS" string with no id could belong
                # to any criterion.
                ident = _positional_id(index)
                text = _text(item)
                notes.append(f"acResults[{index}] is a {type(item).__name__}, "
                             f"not a record — numbered {ident} by position.")
                entries.append(NormalisedResult(key=canonical_ac_id(ident), id=ident,
                                                status=ACStatus.normalise(text),
                                                raw_status=text))
    else:
        return out, [f"acResults is a {type(raw).__name__} — ignored."]

    for entry in entries:
        previous = out.get(entry.key)
        if previous is not None:
            notes.append(
                f"acResults records {entry.id!r} more than once "
                f"({previous.raw_status or 'empty'} then {entry.raw_status or 'empty'}) "
                "— the later entry is used.")
        out[entry.key] = entry
    return out, notes


# ---------------------------------------------------------------------------
# The join
# ---------------------------------------------------------------------------

def _is_readable(status: Optional[str]) -> bool:
    return status in ACStatus.READABLE


def join_criterion(criterion: Optional[NormalisedCriterion],
                   order_result: Optional[NormalisedResult],
                   qa_row: Optional[ACCriterionRow],
                   ) -> Tuple[ACCriterionRow, Optional[ACConflict]]:
    """One output row from whatever the three inputs say about one criterion.

    The decision table (plan §3 D4, §7):

    ============================  ============================  ===============
    order.acResults               QA report                     row
    ============================  ============================  ===============
    readable X                    readable X                    X, order
    readable X                    readable Y (Y != X)           CONFLICT, order
    readable X                    absent / empty / unreadable   X, order
    absent / empty / unreadable   readable Y                    Y, QA report
    unreadable                    absent / empty                UNDETERMINED, order
    absent / empty                unreadable                    UNDETERMINED, QA report
    absent / empty                absent / empty                NOT RECORDED, not recorded
    ============================  ============================  ===============

    Agreement keeps the order JSON as the row's provenance because it is the
    structured record; the corroborating QA row is named in ``notes``.
    """
    o_status = order_result.status if order_result is not None else None
    q_status = qa_row.status if qa_row is not None else None

    ident = (criterion.id if criterion is not None
             else order_result.id if order_result is not None
             else qa_row.id if qa_row is not None else "")
    text = ((criterion.criterion if criterion is not None else "")
            or (order_result.criterion if order_result is not None else "")
            or (qa_row.criterion if qa_row is not None else ""))
    validation = ((criterion.validation if criterion is not None else "")
                  or (order_result.validation if order_result is not None else "")
                  or (qa_row.validation if qa_row is not None else ""))
    evidence = qa_row.evidence if qa_row is not None else ""

    row = ACCriterionRow(id=ident, criterion=text, validation=validation,
                         evidence=evidence)
    conflict: Optional[ACConflict] = None
    note_parts: List[str] = []

    def _order_note() -> str:
        return order_result.notes if order_result is not None else ""

    if _is_readable(o_status) and _is_readable(q_status):
        if o_status == q_status:
            row.status = o_status
            row.raw_status = order_result.raw_status
            row.provenance = Provenance.ORDER_RESULTS
            note_parts.append(_order_note())
            note_parts.append(f"Corroborated by QA report ({qa_row.raw_status}).")
        else:
            row.status = ACStatus.CONFLICT
            row.raw_status = (f"{Provenance.ORDER_RESULTS}: {order_result.raw_status} | "
                              f"{Provenance.QA_REPORT}: {qa_row.raw_status}")
            row.provenance = Provenance.ORDER_RESULTS
            conflict = ACConflict(id=ident, order_status=o_status,
                                  order_raw_status=order_result.raw_status,
                                  qa_status=q_status, qa_raw_status=qa_row.raw_status)
            note_parts.append(
                f"CONFLICT — {Provenance.ORDER_RESULTS} records {o_status}, "
                f"{Provenance.QA_REPORT} records {q_status}; neither is preferred.")
            note_parts.append(_order_note())
    elif _is_readable(o_status):
        row.status = o_status
        row.raw_status = order_result.raw_status
        row.provenance = Provenance.ORDER_RESULTS
        note_parts.append(_order_note())
        if qa_row is not None:
            note_parts.append(f"QA report row carries no readable status "
                              f"({qa_row.raw_status or 'empty'}).")
    elif _is_readable(q_status):
        row.status = q_status
        row.raw_status = qa_row.raw_status
        row.provenance = Provenance.QA_REPORT
        note_parts.append(qa_row.notes)
        if order_result is not None:
            note_parts.append(f"order.acResults entry carries no readable status "
                              f"({order_result.raw_status or 'empty'}).")
    elif o_status == ACStatus.UNDETERMINED:
        row.status = ACStatus.UNDETERMINED
        row.raw_status = order_result.raw_status
        row.provenance = Provenance.ORDER_RESULTS
        note_parts.append(_order_note())
    elif q_status == ACStatus.UNDETERMINED:
        row.status = ACStatus.UNDETERMINED
        row.raw_status = qa_row.raw_status
        row.provenance = Provenance.QA_REPORT
        note_parts.append(qa_row.notes)
    else:
        # Nothing readable, nothing unreadable: nobody wrote a result down.
        row.status = ACStatus.NOT_RECORDED
        row.raw_status = ""
        row.provenance = Provenance.NOT_RECORDED
        note_parts.append(_order_note())

    row.notes = " ".join(p for p in note_parts if p).strip()
    return row, conflict


def build_ac_rollup(order: Dict[str, Any],
                    qa_summary: Optional[QAReportSummary] = None,
                    qa_report_present: Optional[bool] = None,
                    order_id: str = "") -> ACOrderRollup:
    """Build an order's :class:`ACOrderRollup` from its JSON and QA record.

    Pure — no filesystem — which is what lets the normaliser be tested
    table-driven against every key-set. :func:`read_order_ac` is the thin
    workspace wrapper. Never raises: a malformed order yields a rollup whose
    ``parse_notes`` say what could not be read.

    Row order is criteria order, then results for ids no criterion carries,
    then QA rows that matched nothing. The last two are noted, never dropped.
    *qa_report_present* defaults to "a QA summary was supplied".
    """
    data = order if isinstance(order, dict) else {}
    oid = (order_id or _text(data.get("orderId")) or _text(data.get("id")))
    rollup = ACOrderRollup(order_id=oid, title=_text(data.get("title")),
                           voyage_id=_text(data.get("voyageId")))
    if not isinstance(order, dict):
        rollup.parse_notes.append("Order record is not a JSON object.")
        return rollup

    try:
        criteria, c_notes = normalise_acceptance_criteria(data.get("acceptanceCriteria"))
        results, r_notes = normalise_ac_results(data.get("acResults"))
        rollup.parse_notes.extend(c_notes)
        rollup.parse_notes.extend(r_notes)
        rollup.has_criteria = bool(criteria)
        rollup.has_order_results = bool(data.get("acResults"))
        rollup.qa_report_present = (bool(qa_summary is not None)
                                    if qa_report_present is None else bool(qa_report_present))
        if qa_summary is not None:
            rollup.qa_report_rel = qa_summary.report_rel

        qa_rows = list(qa_summary.ac_rows) if qa_summary is not None else []
        qa_by_key: Dict[str, ACCriterionRow] = {}
        qa_by_text: Dict[str, ACCriterionRow] = {}
        for qrow in qa_rows:
            key = canonical_ac_id(qrow.id)
            if key and key not in qa_by_key:
                qa_by_key[key] = qrow
            tkey = _text_key(qrow.criterion)
            if tkey and tkey not in qa_by_text:
                qa_by_text[tkey] = qrow

        used_results: set = set()
        used_qa: set = set()

        def _take_qa(crit: Optional[NormalisedCriterion], key: str) -> Optional[ACCriterionRow]:
            candidate = qa_by_key.get(key) if key else None
            if candidate is None and crit is not None:
                # An id-less QA row joins on its criterion text, exactly — never
                # on position, which would attach a verdict to the wrong line.
                candidate = qa_by_text.get(_text_key(crit.criterion))
                if candidate is not None and canonical_ac_id(candidate.id):
                    candidate = None  # it has an id, and the id did not match
            if candidate is not None and id(candidate) in used_qa:
                return None
            if candidate is not None:
                used_qa.add(id(candidate))
            return candidate

        for crit in criteria:
            result = results.get(crit.key)
            if result is not None:
                used_results.add(crit.key)
                if crit.inline_result is not None and _is_readable(crit.inline_result.status) \
                        and crit.inline_result.status != result.status:
                    rollup.parse_notes.append(
                        f"{crit.id}: inline criterion status "
                        f"{crit.inline_result.raw_status!r} differs from acResults "
                        f"{result.raw_status!r} — acResults is used.")
            elif crit.inline_result is not None:
                result = crit.inline_result
            _append(rollup, *join_criterion(crit, result, _take_qa(crit, crit.key)))

        for key, result in results.items():
            if key in used_results:
                continue
            if rollup.has_criteria:
                rollup.parse_notes.append(
                    f"acResults records {result.id!r}, which no acceptance criterion carries.")
            _append(rollup, *join_criterion(None, result, _take_qa(None, key)))

        orphans = [q for q in qa_rows if id(q) not in used_qa]
        if orphans and (criteria or results):
            rollup.parse_notes.append(
                "QA report AC rows matched no criterion and are listed separately: "
                + ", ".join((q.id or q.criterion[:40]) for q in orphans[:10])
                + (" …" if len(orphans) > 10 else ""))
        for qrow in orphans:
            _append(rollup, *join_criterion(None, None, qrow))

        sources: List[str] = []
        for prov in (Provenance.ORDER_RESULTS, Provenance.QA_REPORT):
            if any(r.provenance == prov for r in rollup.rows):
                sources.append(prov)
        rollup.sources = sources
    except Exception as exc:  # pragma: no cover - defensive
        rollup.parse_notes.append(f"AC reader error: {type(exc).__name__}: {exc}")
    return rollup


def _append(rollup: ACOrderRollup, row: ACCriterionRow,
            conflict: Optional[ACConflict]) -> None:
    rollup.rows.append(row)
    if conflict is not None:
        rollup.conflicts.append(conflict.id)
        rollup.conflict_details.append(conflict)


# ---------------------------------------------------------------------------
# Workspace readers
# ---------------------------------------------------------------------------

def _load_order(path: Path) -> Optional[Dict[str, Any]]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return data if isinstance(data, dict) else None


def _qa_source(mso: Path, order_id: str) -> Tuple[bool, Optional[QAReportSummary]]:
    """``(qa_report_present, summary)`` from ONE discovery pass.

    Presence counts ``.md`` and ``.json`` (``fleet_runner``'s rule); the
    summary is read from the report ``qa_reader`` would pick, which is
    ``.md``-only. A ``.json``-only QA artefact is therefore present-but-unread,
    which is the honest reading of it.
    """
    try:
        paths = discover_report_paths(mso, order_id, kinds=("qa",))
    except Exception:
        return False, None
    if not paths:
        return False, None
    path = qa_reader._pick_report(order_id, paths)
    if path is None:
        return True, None
    return True, qa_reader._summarise_path(mso, path, order_id)


def read_order_ac(mso: Path, order_id: str) -> Optional[ACOrderRollup]:
    """*order_id*'s AC record, or ``None`` if the order JSON cannot be found.

    Never raises. Order location goes through
    :func:`maestro.hub.artefacts.find_order_file`, QA discovery through
    :func:`maestro.hub.artefacts.discover_report_paths`.
    """
    try:
        mso_path = Path(mso)
        path = find_order_file(mso_path, order_id)
    except Exception:
        return None
    if path is None:
        return None
    data = _load_order(path)
    if data is None:
        rollup = ACOrderRollup(order_id=order_id)
        rollup.parse_notes.append("Order JSON could not be read.")
        return rollup
    present, summary = _qa_source(mso_path, order_id)
    return build_ac_rollup(data, summary, qa_report_present=present, order_id=order_id)


def list_ac_rollups(mso: Path, include_all: bool = False,
                    ) -> Tuple[List[ACOrderRollup], ACCoverage]:
    """Every order's AC record in the workspace, plus the coverage headline.

    By default only orders that carry ``acceptanceCriteria`` or ``acResults``
    are returned (``include_all`` returns every order). ``coverage`` is
    computed over exactly the rollups considered, with D4's denominator:
    orders WITH criteria. Never raises.
    """
    mso_path = Path(mso)
    coverage = ACCoverage()
    rollups: List[ACOrderRollup] = []
    seen: set = set()
    try:
        # First file per order id wins — iter_order_files yields in
        # find_order_file's precedence, so a stale queue copy is shadowed.
        files = iter_order_files(mso_path)
    except Exception:
        return rollups, coverage

    for path in files:
        data = _load_order(path)
        if data is None:
            continue
        oid = _text(data.get("orderId")) or _text(data.get("id")) or path.stem
        if oid in seen:
            continue
        seen.add(oid)
        if not include_all and not (data.get("acceptanceCriteria") or data.get("acResults")):
            continue
        present, summary = _qa_source(mso_path, oid)
        rollup = build_ac_rollup(data, summary, qa_report_present=present, order_id=oid)
        rollups.append(rollup)
        coverage.add(rollup)
    return rollups, coverage
