# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""The voyage report, COMPOSED ON READ (FTR-MSO-2026-0737 — PLAN-PLN-MSO-2026-0726 §5 B5).

**There is no voyage report file, and this module does not create one**
(Captain decision D2). A voyage report is the join of records that already
exist for every voyage the workspace has ever run:

* the voyage manifest — ``voyages/{active,complete}/{VOY-ID}.json`` — for the
  title, branch, PR, merge state, dates and member orders;
* each member order's JSON, found through
  :func:`maestro.hub.artefacts.find_order_file`, for its status and title;
* this package's own readers for the per-order QA verdict
  (:mod:`~maestro.reports.qa_reader`), acceptance-criteria rollup
  (:mod:`~maestro.reports.ac_reader`) and SEC verdicts
  (:mod:`~maestro.reports.security_reader`) — called, never re-implemented;
* the Hub's usage aggregator (``aggregate_usage_for_voyage`` for the voyage's
  spend and per-order totals, ``get_order_usage_detail`` for the per-role and
  per-crew split) — the numbers ``DEMO_CREWS`` used to invent.

Composition is what makes backfill free: every ADM-era voyage lights up on the
same day as the newest one, where a producer artefact would only ever cover
voyages closing after it shipped.

**The free-form ``reports/voyage/*`` narratives are LINKED, never parsed.** They
are prose written by hand, five of seven ADM-era, and nothing here reads a
number out of one. :func:`narratives_for` matches them to a voyage by filename
only.

**The honesty rule (plan §7) at this layer.** A voyage whose orders left no
usage record reports :data:`UsageStatus.NOT_RECORDED` with ``None`` totals —
never ``0`` tokens. An order with no QA report has ``qa_verdict=None``, which is
distinct from a report whose verdict is ``UNDETERMINED``. A manifest field that
was never written stays empty rather than being inferred from a neighbour.

**Why the usage aggregator is imported lazily.** It lives in
:mod:`maestro.hub.aggregator`, which builds Pydantic models, and this package
must never pull a web framework in at import (``test_ftr_0728_reports_core``).
The import happens only when a composed report is actually asked for spend; a
caller without the Hub extra installed gets :data:`UsageStatus.UNAVAILABLE`
and a note saying why, not a crash and not a zero. A caller that already holds
usage figures passes its own ``usage_provider``.

**Boundary with FTR-MSO-2026-0700** (plan §6): this module answers *what did the
voyage do and verify*. It does not compute why an order is stuck — that is the
``Blockage`` record, served by ``/api/v1/voyages/{id}/blockage``.
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

from maestro.hub.artefacts import find_order_file, iter_report_paths, iter_voyage_files
from maestro.reports import ac_reader, security_reader
from maestro.reports.models import (
    SecurityVerdictRef,
    UsageShare,
    UsageStatus,
    VoyageNarrative,
    VoyageOrderEntry,
    VoyageReportSummary,
    VoyageUsage,
)

#: The two manifest directories, in precedence order. An id present in both (a
#: voyage archived while a stale active copy lingered) resolves to ``active``,
#: matching ``aggregator.aggregate_usage_for_voyage``'s own probe order.
VOYAGE_LOCATIONS = ("active", "complete")

#: Signature of an injectable spend source: ``(voyage_id, member_order_ids)``
#: to a :class:`VoyageUsage`. The Hub uses the default (the aggregator); a test
#: or a CLI that already has figures passes its own.
UsageProvider = Callable[[str, Sequence[str]], VoyageUsage]

_PR_URL_RE = re.compile(r"/pull/(\d+)")

#: Crew-number key for an iteration that recorded none. A crew slot is a fact
#: the usage record either states or does not; it is never guessed.
CREW_NOT_RECORDED = "not recorded"


# ---------------------------------------------------------------------------
# Small tolerant readers
# ---------------------------------------------------------------------------

def _text(value: Any) -> str:
    if value is None or isinstance(value, (dict, list)):
        return ""
    return str(value).strip()


def _load_json(path: Path) -> Optional[Dict[str, Any]]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return data if isinstance(data, dict) else None


def _rel(mso: Path, path: Path) -> str:
    try:
        return path.relative_to(mso).as_posix()
    except ValueError:
        return path.name


def manifest_order_ids(data: Dict[str, Any]) -> List[str]:
    """Member order ids, in manifest order, de-duplicated.

    Both live container shapes: a list of id strings (MSO-era) and a list of
    ``{orderId, sequence, title, ...}`` dicts (ADM-era). Anything else in the
    list is skipped, not coerced.
    """
    out: List[str] = []
    seen: set = set()
    for item in data.get("orders") or []:
        if isinstance(item, dict):
            oid = _text(item.get("orderId")) or _text(item.get("id"))
        elif isinstance(item, str):
            oid = item.strip()
        else:
            oid = ""
        if oid and oid not in seen:
            seen.add(oid)
            out.append(oid)
    return out


def _manifest_order_status(data: Dict[str, Any], order_id: str) -> str:
    """A status the MANIFEST itself records for an order, or ``""``."""
    for item in data.get("orders") or []:
        if isinstance(item, dict) and (_text(item.get("orderId")) or _text(item.get("id"))) == order_id:
            return _text(item.get("status"))
    statuses = data.get("orderStatuses")
    if isinstance(statuses, dict):
        return _text(statuses.get(order_id))
    return ""


def _pr_number(data: Dict[str, Any]) -> Tuple[Optional[int], str]:
    """``(number, url)`` from ``prNumber`` / ``prUrl``, falling back to the
    ADM-era ``mergedPR`` (an int, or a PR URL). Never guessed from the branch."""
    url = _text(data.get("prUrl"))
    for key in ("prNumber", "mergedPR"):
        raw = data.get(key)
        if isinstance(raw, bool):
            continue
        if isinstance(raw, int):
            return raw, url
        text = _text(raw)
        if text.isdigit():
            return int(text), url
        m = _PR_URL_RE.search(text)
        if m:
            return int(m.group(1)), url or text
    return None, url


def _merged(data: Dict[str, Any]) -> Optional[bool]:
    """The recorded merge state, or ``None`` when the manifest records none.

    An explicit boolean wins. Otherwise a recorded merge TIMESTAMP or merge
    COMMIT is itself a record of a merge; a PR number alone is not (a PR can be
    open or closed unmerged), so it yields ``None``, not ``False``.
    """
    raw = data.get("merged")
    if isinstance(raw, bool):
        return raw
    if _text(data.get("mergedAt")) or _text(data.get("mergeCommit")):
        return True
    return None


# ---------------------------------------------------------------------------
# Manifest discovery
# ---------------------------------------------------------------------------

def iter_voyage_manifests(mso: Path) -> List[Tuple[str, Path]]:
    """``(location, path)`` for every voyage manifest, active first.

    Delegates to :func:`maestro.hub.artefacts.iter_voyage_files` — this package
    carries no directory walker of its own (``test_ftr_0728_reports_core``).
    """
    return iter_voyage_files(Path(mso))


def find_voyage_manifest(mso: Path, voyage_id: str) -> Optional[Tuple[str, Path]]:
    """Locate *voyage_id*'s manifest: the canonical ``{id}.json`` first, then a
    manifest whose own ``voyageId``/``id`` names it."""
    wanted = (voyage_id or "").strip()
    if not wanted:
        return None
    for location in VOYAGE_LOCATIONS:
        candidate = Path(mso) / "voyages" / location / f"{wanted}.json"
        if candidate.is_file():
            return location, candidate
    for location, path in iter_voyage_manifests(mso):
        data = _load_json(path)
        if data and wanted in (_text(data.get("voyageId")), _text(data.get("id"))):
            return location, path
    return None


def summarise_manifest(mso: Path, location: str, path: Path,
                       data: Optional[Dict[str, Any]] = None) -> VoyageReportSummary:
    """A manifest-only (``composed=False``) record. Never raises."""
    if data is None:
        data = _load_json(path)
    voyage_id = path.stem
    if data is None:
        summary = VoyageReportSummary(voyage_id=voyage_id, location=location,
                                      manifest_rel=_rel(mso, path))
        summary.parse_notes.append("Voyage manifest could not be read as a JSON object.")
        return summary

    voyage_id = _text(data.get("voyageId")) or _text(data.get("id")) or voyage_id
    pr_number, pr_url = _pr_number(data)
    summary = VoyageReportSummary(
        voyage_id=voyage_id,
        title=_text(data.get("title")),
        branch=_text(data.get("branch")) or _text(data.get("voyageBranch")),
        status=_text(data.get("status")),
        pr_number=pr_number,
        pr_url=pr_url,
        merged=_merged(data),
        merged_at=_text(data.get("mergedAt")),
        started_date=_text(data.get("startedDate")) or _text(data.get("startedAt")),
        completed_date=_text(data.get("completedDate")) or _text(data.get("completedAt")),
        created_at=_text(data.get("createdAt")),
        project=_text(data.get("project")),
        location=location,
        manifest_rel=_rel(mso, path),
        order_ids=manifest_order_ids(data),
    )
    if not isinstance(data.get("orders"), list):
        summary.parse_notes.append("Voyage manifest carries no orders list.")
    return summary


# ---------------------------------------------------------------------------
# Narratives — linked, never parsed
# ---------------------------------------------------------------------------

def narratives_for(mso: Path, voyage_id: str, order_ids: Sequence[str],
                   paths: Optional[Sequence[Path]] = None) -> List[VoyageNarrative]:
    """The ``reports/voyage/`` documents whose FILENAME names this voyage or a
    member order. The file's content is never opened.

    Matched case-insensitively on the id followed by a non-alphanumeric
    boundary, so ``VOY-MSO-2026-0040-v3.0.0-release-notes.md`` belongs to
    ``VOY-MSO-2026-0040`` and ``VOY-MSO-2026-00401.md`` would not.
    """
    if paths is None:
        try:
            paths = iter_report_paths(Path(mso), "voyage")
        except Exception:
            return []
    wanted = [(voyage_id, "")] + [(oid, oid) for oid in order_ids]
    out: List[VoyageNarrative] = []
    for path in paths:
        upper = path.name.upper()
        for ident, order_id in wanted:
            if not ident:
                continue
            if re.search(rf"(?<![A-Z0-9]){re.escape(ident.upper())}(?![0-9A-Z])", upper):
                out.append(VoyageNarrative(name=path.name, report_rel=_rel(Path(mso), path),
                                           matched_by=ident, order_id=order_id))
                break
    return out


# ---------------------------------------------------------------------------
# Per-order composition
# ---------------------------------------------------------------------------

def _order_location(mso: Path, path: Path) -> str:
    try:
        parts = path.relative_to(mso).parts
    except ValueError:
        return ""
    if len(parts) >= 3 and parts[0] == "orders":
        return parts[1]
    if len(parts) >= 3 and parts[0] == "queues":
        return "queue:" + "/".join(parts[1:-1])
    return ""


def compose_order_entry(mso: Path, order_id: str,
                        manifest: Optional[Dict[str, Any]] = None,
                        ) -> Tuple[VoyageOrderEntry, Any, Any]:
    """One member order's row, plus the full QA and AC records it was built from.

    Returns ``(entry, qa_summary_or_None, ac_rollup_or_None)``. The QA report is
    discovered ONCE and handed to the AC join, so an order's QA verdict and its
    QA-sourced AC rows can never come from two different files. Never raises.
    """
    mso_path = Path(mso)
    entry = VoyageOrderEntry(order_id=order_id)

    data: Optional[Dict[str, Any]] = None
    try:
        path = find_order_file(mso_path, order_id)
    except Exception:
        path = None
    if path is not None:
        entry.found = True
        entry.location = _order_location(mso_path, path)
        data = _load_json(path)

    if data is not None:
        entry.title = _text(data.get("title"))
        entry.order_type = _text(data.get("type"))
        entry.status = _text(data.get("status"))
        if entry.status:
            entry.status_source = "order"
    if not entry.status and manifest is not None:
        entry.status = _manifest_order_status(manifest, order_id)
        if entry.status:
            entry.status_source = "voyage record"
    if not entry.title and manifest is not None:
        for item in manifest.get("orders") or []:
            # ADM-era manifests key a member by "id", MSO-era ones by "orderId".
            if isinstance(item, dict) and _text(item.get("orderId") or item.get("id")) == order_id:
                entry.title = _text(item.get("title"))
                break

    try:
        qa_present, qa_summary = ac_reader._qa_source(mso_path, order_id)
    except Exception:
        qa_present, qa_summary = False, None
    entry.qa_report_present = bool(qa_present)
    if qa_summary is not None:
        entry.qa_verdict = qa_summary.verdict
        entry.qa_decided = qa_summary.decided
        entry.qa_report_rel = qa_summary.report_rel
        try:
            entry.qa_blocking_defects = len(qa_summary.blocking_defects)
        except Exception:
            entry.qa_blocking_defects = 0

    ac_rollup = None
    if data is not None and (data.get("acceptanceCriteria") or data.get("acResults")):
        try:
            ac_rollup = ac_reader.build_ac_rollup(
                data, qa_summary, qa_report_present=qa_present, order_id=order_id)
        except Exception:
            ac_rollup = None
    if ac_rollup is not None:
        entry.ac_bucket = ac_rollup.coverage_bucket
        entry.ac_total = ac_rollup.total
        entry.ac_recorded = ac_rollup.recorded
        entry.ac_met = ac_rollup.met
        entry.ac_not_recorded = ac_rollup.not_recorded
        entry.ac_conflicted = ac_rollup.conflicted

    try:
        sec_reports = security_reader.read_security_reports(mso_path, order_id)
    except Exception:
        sec_reports = []
    entry.security = [
        SecurityVerdictRef(verdict=s.verdict, decided=s.decided,
                           variant=s.variant, report_rel=s.report_rel)
        for s in sec_reports
    ]
    return entry, qa_summary, ac_rollup


# ---------------------------------------------------------------------------
# Usage — through the aggregator, never re-summed from files here
# ---------------------------------------------------------------------------

def _share_list(buckets: Dict[str, List[Any]], label: Callable[[str], str]) -> List[UsageShare]:
    shares = [
        UsageShare(key=k, label=label(k), total_tokens=v[0], estimated_cost_usd=v[1],
                   order_count=len(v[2]), iterations=v[3])
        for k, v in buckets.items()
    ]
    shares.sort(key=lambda s: (-s.total_tokens, s.key))
    return shares


def aggregator_usage_provider(mso: Path, ws_root: Optional[Path] = None) -> UsageProvider:
    """The default spend source: the Hub's usage aggregator.

    ``aggregate_usage_for_voyage`` decides WHICH usage records are this
    voyage's (stamped with its id, or belonging to a member order) and supplies
    the totals; ``get_order_usage_detail`` supplies each of those orders'
    per-iteration role and crew split. Both are imported at call time — see the
    module docstring.
    """
    mso_path = Path(mso)
    root = Path(ws_root) if ws_root is not None else mso_path.parent

    def provide(voyage_id: str, order_ids: Sequence[str]) -> VoyageUsage:
        try:
            from maestro.hub.aggregator import (
                aggregate_usage_for_voyage,
                get_order_usage_detail,
            )
        except Exception as exc:   # the [hub] extra is absent
            return VoyageUsage(status=UsageStatus.UNAVAILABLE,
                               note=f"The usage aggregator could not be loaded ({type(exc).__name__}).")
        try:
            # Pass the member ids we already hold: the aggregator only reloads them
            # from voyages/*/{voyage_id}.json, which misses a manifest found under a
            # different filename (find_manifest matches by inner id too).
            rollup = aggregate_usage_for_voyage(voyage_id, root, order_ids=order_ids)
        except Exception as exc:
            return VoyageUsage(status=UsageStatus.UNAVAILABLE,
                               note=f"The usage aggregator failed ({type(exc).__name__}).")

        buckets = list(getattr(rollup, "buckets", None) or [])
        if not buckets:
            return VoyageUsage(
                status=UsageStatus.NOT_RECORDED,
                note="No usage record exists for this voyage or any of its orders.")

        usage = VoyageUsage(
            status=UsageStatus.RECORDED,
            total_tokens=int(getattr(rollup, "total_tokens", 0) or 0),
            estimated_cost_usd=float(getattr(rollup, "estimated_cost_usd", 0.0) or 0.0),
            orders_with_usage=len(buckets),
        )

        roles: Dict[str, List[Any]] = {}
        crews: Dict[str, List[Any]] = {}
        usage_dir = mso_path / "usage" / "orders"
        for bucket in buckets:
            oid = getattr(bucket, "key", "")
            try:
                detail = get_order_usage_detail(oid, usage_dir)
            except Exception:
                continue
            iterations = list(getattr(detail, "iterations", None) or [])
            if not iterations:
                continue
            usage.orders_with_iteration_data += 1
            for it in iterations:
                tokens = int(getattr(it, "total_tokens", 0) or 0)
                cost = float(getattr(it, "estimated_cost_usd", 0.0) or 0.0)
                role = _text(getattr(it, "role", "")) or "UNKNOWN"
                crew_no = int(getattr(it, "crew_number", 0) or 0)
                crew = str(crew_no) if crew_no > 0 else CREW_NOT_RECORDED
                for table, key in ((roles, role), (crews, crew)):
                    slot = table.setdefault(key, [0, 0.0, set(), 0])
                    slot[0] += tokens
                    slot[1] += cost
                    slot[2].add(oid)
                    slot[3] += 1

        usage.roles = _share_list(roles, lambda k: k)
        usage.crews = _share_list(
            crews, lambda k: k if k == CREW_NOT_RECORDED else f"Crew {k}")
        if usage.orders_with_iteration_data < usage.orders_with_usage:
            usage.note = (
                f"The role and crew split covers {usage.orders_with_iteration_data} of "
                f"{usage.orders_with_usage} orders with usage; the rest recorded a total "
                "only, so the split does not sum to the voyage total.")
        usage.order_totals = {
            getattr(b, "key", ""): (int(getattr(b, "total_tokens", 0) or 0),
                                    float(getattr(b, "estimated_cost_usd", 0.0) or 0.0))
            for b in buckets
        }
        return usage

    return provide


# ---------------------------------------------------------------------------
# Public entry points
# ---------------------------------------------------------------------------

def list_voyage_reports(mso: Path) -> List[VoyageReportSummary]:
    """Every voyage in the workspace as a manifest-only index entry, newest first.

    Entries are ``composed=False``: member orders and spend are NOT read (that
    would parse every QA report in the workspace per request). Narratives are
    matched, since that is a filename comparison over a handful of files.
    Never raises.
    """
    mso_path = Path(mso)
    try:
        narrative_paths = iter_report_paths(mso_path, "voyage")
    except Exception:
        narrative_paths = []

    out: List[VoyageReportSummary] = []
    seen: set = set()
    try:
        manifests = iter_voyage_manifests(mso_path)
    except Exception:
        return out
    for location, path in manifests:
        try:
            summary = summarise_manifest(mso_path, location, path)
        except Exception:
            continue
        if summary.voyage_id in seen:
            continue
        seen.add(summary.voyage_id)
        summary.narratives = narratives_for(mso_path, summary.voyage_id,
                                            summary.order_ids, narrative_paths)
        out.append(summary)
    out.sort(key=lambda s: s.sort_key(), reverse=True)
    return out


def read_voyage_report(mso: Path, voyage_id: str, *,
                       ws_root: Optional[Path] = None,
                       usage_provider: Optional[UsageProvider] = None,
                       ) -> Optional[VoyageReportSummary]:
    """*voyage_id*'s composed report, or ``None`` when no manifest names it.

    ``None`` means exactly "no such voyage". A voyage that exists and recorded
    nothing is a record whose absences say so. Never raises.
    """
    mso_path = Path(mso)
    try:
        found = find_voyage_manifest(mso_path, voyage_id)
    except Exception:
        return None
    if found is None:
        return None
    location, path = found
    data = _load_json(path)
    summary = summarise_manifest(mso_path, location, path, data)
    summary.composed = True

    for oid in summary.order_ids:
        try:
            entry, qa_summary, ac_rollup = compose_order_entry(mso_path, oid, data)
        except Exception:
            entry, qa_summary, ac_rollup = VoyageOrderEntry(order_id=oid), None, None
            summary.parse_notes.append(f"{oid}: its records could not be composed.")
        if not entry.found:
            summary.parse_notes.append(
                f"{oid} is listed on the voyage but no order JSON exists for it.")
        summary.orders.append(entry)
        if qa_summary is not None:
            summary.qa_summaries.append(qa_summary)
        if ac_rollup is not None:
            summary.ac_rollups.append(ac_rollup)

    provider = usage_provider or aggregator_usage_provider(mso_path, ws_root)
    try:
        usage = provider(summary.voyage_id, list(summary.order_ids))
    except Exception as exc:
        usage = VoyageUsage(status=UsageStatus.UNAVAILABLE,
                            note=f"The usage source failed ({type(exc).__name__}).")
    summary.usage = usage
    if usage.status == UsageStatus.RECORDED:
        for entry in summary.orders:
            if entry.order_id in usage.order_totals:
                entry.usage_tokens, entry.usage_cost_usd = usage.order_totals[entry.order_id]

    summary.narratives = narratives_for(mso_path, summary.voyage_id, summary.order_ids)
    return summary


__all__ = [
    "CREW_NOT_RECORDED",
    "UsageProvider",
    "VOYAGE_LOCATIONS",
    "aggregator_usage_provider",
    "compose_order_entry",
    "find_voyage_manifest",
    "iter_voyage_manifests",
    "list_voyage_reports",
    "manifest_order_ids",
    "narratives_for",
    "read_voyage_report",
    "summarise_manifest",
]
