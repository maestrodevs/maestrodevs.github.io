# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Security report reader (FTR-MSO-2026-0735 — PLAN-PLN-MSO-2026-0726 §5, Order B3).

**Two models, never merged.** ``reports/security/`` holds three populations
that share a directory and nothing else (plan §1.4):

=====================================  ===  ==========================================
Family                                   n  What this module does with it
=====================================  ===  ==========================================
``SEC-{ORDER-ID}[-VARIANT].md``         35  :class:`SecurityReportSummary` — a per-order
                                            verdict, ``UNDETERMINED`` where unreadable
``REVIEW-{timestamp}.md``               14  :class:`ScannerRun` — a run with counts,
                                            never a risk posture
``SECURITY-AUDIT-*``, ``THREAT-MODEL``   2  named by :func:`list_other_security_documents`
                                            and nothing more — not a report type
=====================================  ===  ==========================================

There is deliberately **no function here that combines the first two into one
figure**. A SEC crew's ``APPROVED`` is a judgement about one order's diff; a
``REVIEW-*`` run's ``4539 HIGH`` is a regex scanner's match count over every
``*.py`` under the workspace — including the artefact plane, every crew
worktree's copy of the same source, and its own tooling. Summing, averaging or
ranking one against the other produces a number that means nothing, and the
first surface to render it would present it as the fleet's security posture.

**The ``secVerdict`` front-matter field (FTR-MSO-2026-0779, Captain ruling NB-02
option 3).** ``maestro/roles/SEC.md`` mandates that every SEC report open with a
three-dash front-matter block carrying ``secVerdict: APPROVED | CONDITIONAL |
REJECTED``. When the field is present it is AUTHORITATIVE — the free-prose
residual (``Subject to F1…``, ``contingent on…``) is closed at the producer, not
by a prose allowlist here:

* A value that is not exactly one of the three tokens, a key declared twice, or a
  block with no closing ``---`` reads ``UNDETERMINED``; the body is not read in
  its place.
* The body is still read by the cascade below and cross-checked. A body that
  declares a DIFFERENT decided verdict, denies itself, or whose own document
  check withholds its approval reads ``UNDETERMINED`` — neither side is silently
  preferred. ``REJECTED`` and ``BLOCKED`` agree. A body with no readable verdict
  leaves the field standing, except that an ``APPROVED`` field is still held to
  the document allowlist below.
* :attr:`~maestro.reports.models.SecurityReportSummary.verdict_basis` records
  which path decided: ``front-matter``, ``heuristic`` or ``json``.

A report WITHOUT the field — every report written before the mandate — is read by
the heuristic cascade exactly as before.

**How a SEC verdict is read without the field.** Legacy SEC reports carry no
verdict front-matter and no enforced heading contract, so this is a cascade that
reads only what a report *declares*:

1. A verdict section — ``## Security Decision``, ``## Verdict``, ``## Decision``
   (``## Prior verdict (superseded …)`` is excluded by construction). Within
   it: a value in the heading itself (``## Security Decision: APPROVED``), then
   a declaration line (``**Status:** CONDITIONAL``, ``### Status: ✅ APPROVED``),
   then a line that *opens* with a verdict token (``✓ APPROVED``,
   ``**APPROVED-WITH-FINDINGS**``).
2. A sign-off section (``## SEC Sign-off``, ``## Signature``) — declarations only.
3. An executive-summary section, then the preamble — declarations only.
4. Nothing matched → ``UNDETERMINED``.

Two rules differ from the QA reader and both make it *more* conservative, because
SEC prose is full of the words: tokens are matched **uppercase only** (so
``Captain-approved`` and ``cannot be approved`` are not approvals), and a value
must **open** with its token — ``NOT YET APPROVED``, ``NEVER APPROVED`` and
``Plan APPROVED by Captain; review in progress`` name the word without deciding
anything. A negation in the token's own clause (``APPROVED is not granted``) skips
it rather than inverting it; for an approval, a negation in ANY later clause does
the same (``APPROVED — no findings, NOT for release``). An approval stands only
when every clause after it is on a known-benign ALLOWLIST (``FOR RELEASE``,
``no findings``, ``3 fixed``, ``0 CRITICAL/HIGH``); anything else —
``APPROVED WITH FINDINGS``, ``APPROVED — 1 deferred``, ``except F2``,
``CONDITIONALLY APPROVED`` — reads as ``CONDITIONAL``, never ``APPROVED``. A
declaration that names no recognised token (``ACCEPTED (LEAD)``, ``COMPLETE``,
``PENDING``) yields ``UNDETERMINED`` and a parse note quoting it, so the text is
visible rather than guessed at; inside a verdict section it also ends the
cascade, so a lower-tier ``APPROVED`` never overrides it.

**The document allowlist.** The clause allowlist judges one line; a report can
approve on one line and qualify it on the next. So an ``APPROVED`` the cascade
read stands only when no decision-bearing line AT ITS TIER OR ABOVE disagrees
(QA DEF-018..021) — a ``**Conditions:**`` block, a ``CONDITIONAL`` word or a
caution marker on a verdict line makes it ``CONDITIONAL``; a denial,
``PENDING``/``WITHDRAWN``/``ON HOLD``, a contradicting ``REJECTED`` or a denial
marker on a verdict line makes it ``UNDETERMINED``. A nonzero finding count is
benign only when the next clause resolves it (``1 finding (FIXED)``, DEF-022); a
JSON artefact's non-empty ``conditions``/``caveats`` field downgrades an approval
the same way, and an unreadable non-string decision field ends the read (DEF-023).

**Residual shapes (BUG-MSO-2026-0755, NB-01/03/04/06..10).** The same structural
checks, widened rather than given new vocabulary: a declaration counts behind a
numbered-list prefix, and a WEAK declaration — a qualified label (``Final Verdict:``),
a dash separator (``Status — FAIL``) or a table row of three or more cells —
disagrees when its value opens with a verdict that is not an approval; a conditions
heading's WHOLE body is judged, not its first line; headings naming blockers or open
items are conditions headings; a JSON artefact's top-level decision siblings,
``approved: false`` and condition-shaped keys in any case (``Conditions``,
``requiredActions``) are read; a footnote star glued to an approval (``APPROVED*``)
qualifies it; ``after re-test`` is no longer a benign aside (only the review itself
is); and ``signature`` makes a sign-off section only as a title's last word. A report
whose only declaration is a list item (``- **Status:** APPROVED``, NB-11) still reads
``UNDETERMINED``: that is pinned as the safe read of an ambiguous checklist status.

**A self-contradicting report (Captain ruling NB-05 option 2).** A DECIDED denial
or rejection in a decision-bearing section BELOW the approval's tier — a
``## SEC Sign-off`` ``**Status:** REJECTED`` or ``NOT APPROVED`` under a
``## Security Decision`` APPROVED — makes the report ``UNDETERMINED``. It is not
read as ``REJECTED``: the report contradicts itself, and neither half is evidence
for the other. Only decided shapes count at the lower tiers (a declaration, or a
line that OPENS by rejecting, blocking or denying); a ``PENDING`` or
``CONDITIONAL`` there does not, and the document preamble is not a section. The
rule only ever moves a read away from ``APPROVED``.

**How a scanner run is judged.** :class:`~maestro.reports.models.ScannerTrust`
has no "trusted" member. Every run's ``counts_trustworthy`` is ``False``; a run
whose own listed findings carry a known false-positive signature is additionally
``KNOWN-UNTRUSTED``, with each signature named on ``untrusted_reasons``. The
signatures are evidence read from the file, not a list of filenames — so the
regression case (``REVIEW-20260807T214608Z.md``, a CWE-22 HIGH on the ``...`` in
``print("Loading scanner counts...")``) is caught for the reason it is wrong,
and a future run with the same defect is caught the same way.

Discovery goes through :mod:`maestro.hub.artefacts`; this module has no
filesystem walker of its own (plan §4), and imports no web framework.
"""

from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from pathlib import Path, PureWindowsPath
from typing import Callable, Dict, Iterable, List, Optional, Sequence, Tuple

from maestro.hub.artefacts import (
    MAX_ARTEFACT_BYTES,
    discover_report_paths,
    iter_report_paths,
)
from maestro.reports.models import (
    ParseCoverage,
    ReportedFinding,
    ScannerRun,
    ScannerTrust,
    SecurityReportSummary,
    Verdict,
    _camel_to_snake,
    finding_dict_keys,
)
# The QA reader's table splitter, header mapper, heading normaliser, order-id
# regex and bounded read are reused rather than copied, for the reason
# qa_reader gives for reusing role_rejection's ``_strip_md``: two copies of "what
# is a table row" would eventually disagree about the same markdown.
from maestro.reports.qa_reader import (
    _HEADING_RE,
    _ORDER_ID_IN_TEXT_RE,
    _canonical_header,
    _normalise_heading,
    _read_bounded,
    _tables,
    extract_order_id,
)

__all__ = [
    "BASIS_FRONT_MATTER",
    "BASIS_HEURISTIC",
    "BASIS_JSON",
    "SCANNER_SAMPLE_LIMIT",
    "SEC_VERDICT_KEY",
    "SEC_VERDICT_VALUES",
    "extract_security_findings",
    "extract_security_verdict",
    "list_other_security_documents",
    "list_scanner_runs",
    "list_security_reports",
    "parse_scanner_run",
    "parse_security_report",
    "read_security_report",
    "read_security_reports",
]

#: How many listed findings a :class:`ScannerRun` carries as its sample. The
#: sample exists to show *why* a run is untrusted; it is never a count source.
SCANNER_SAMPLE_LIMIT = 10

_SEC_PREFIX = "SEC-"
_REVIEW_PREFIX = "REVIEW-"

#: The machine-readable verdict ``maestro/roles/SEC.md`` mandates on every SEC
#: report (FTR-MSO-2026-0779, NB-02 option 3), and the only values it may take.
SEC_VERDICT_KEY = "secVerdict"
SEC_VERDICT_VALUES = ("APPROVED", "CONDITIONAL", "REJECTED")
#: :attr:`SecurityReportSummary.verdict_basis` values — which path decided a read.
BASIS_FRONT_MATTER = "front-matter"
BASIS_HEURISTIC = "heuristic"
BASIS_JSON = "json"
_FRONT_MATTER_SOURCE = f"(front-matter: {SEC_VERDICT_KEY})"
#: Lines a front-matter block may span, opener included. Wider than
#: chart_routing's 15-line ``nodeVerdict`` window on purpose: a block that is
#: still open at the cap is reported malformed, so the cap must not be tight.
_FRONT_MATTER_LINE_CAP = 40

_SEVERITIES = ("CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO")
_SEVERITY_RE = re.compile(r"\b(CRITICAL|HIGH|MEDIUM|LOW|INFO)\b")
_SEV = r"(?:CRITICAL|HIGH|MEDIUM|LOW|INFO)"
# A heading segment that IS a severity: the bare word or a paired "HIGH/MEDIUM",
# optionally followed by a bracketed aside ("MEDIUM (by-design residual)") or by
# the word "severity" ("HIGH severity path traversal"). "HIGH-level overview" and
# "LOW priority questions" use the word as an adjective (QA DEF-005, DEF-013).
_SEVERITY_SLOT_RE = re.compile(
    rf"^{_SEV}(?:\s*/\s*{_SEV})*(?:\s+(?i:severity)\b.*|\s*[(\[].*)?$")
# The "HIGH severity <title>" form: the title is what follows "severity", past
# an optional bracketed aside ("HIGH Severity (confirmed) SSRF" — QA DEF-017).
_SEVERITY_LEAD_RE = re.compile(
    rf"^{_SEV}(?:\s*/\s*{_SEV})*\s+(?i:severity)(?:\s*[(\[][^)\]]*[)\]])?"
    r"\s+(?P<rest>[^(\[\s].*)$")

# A verdict is read only from text that OPENS with its token (QA DEF-001):
# "NOT YET APPROVED", "CANNOT BE APPROVED", "PENDING — to be APPROVED once F1 is
# fixed" and "Plan APPROVED by Captain; review in progress" all name the word and
# none of them is an approval. Every decided shape in the live plane opens with it.
_OPENING_TOKEN_RE = re.compile(r"^(APPROVED|CONDITIONAL|REJECTED|BLOCKED)\b")
_OPENING_ALIAS_RE = re.compile(r"^(PASSED|PASS|FAILED|FAIL)\b")
_ADVERB_APPROVAL_RE = re.compile(r"^(?:CONDITIONALLY|PROVISIONALLY)\s+APPROVED\b",
                                 re.IGNORECASE)
_LEADING_QUOTES = " \"'“”‘’"
# Clause boundaries after the token. A hyphen only counts with spaces around it,
# so "APPROVED-WITH-FINDINGS" stays one clause. No leading whitespace RUN in any
# branch (BUG-MSO-2026-0756): "\s*," retried from every blank of a long run is
# O(n^2), and every caller strips its clauses, so the split is unchanged.
_CLAUSE_SPLIT_RE = re.compile(r"[—–;,.()\[\]]\s*|\s-\s+|:\s+")
_CLAUSE_NEGATION_RE = re.compile(
    r"\b(?:NOT|NEVER|CANNOT|NO\s+LONGER|CAN['’]T|WON['’]T|ISN['’]T|WASN['’]T"
    r"|AREN['’]T|WEREN['’]T)\b",
    re.IGNORECASE,
)
# An approval is read as CONDITIONAL unless EVERY clause after its token is one
# of these known-benign asides (QA DEF-009, DEF-014). This is an ALLOWLIST on
# purpose: a blocklist of conditional words ("if", "unless", "until", "except",
# "requires … first", "must be fixed before release" …) always misses one more
# word, and each miss is a false pass. Only RESOLVED work is benign — "3 fixed",
# "no findings", "0 CRITICAL/HIGH"; a DEFERRED or OPEN count is a condition.
_BENIGN_ASIDE_RE = re.compile(
    r"(?:"
    r"UNCONDITIONAL(?:LY)?"
    r"|FOR\s+(?:RELEASE|MERGE|MERGING|PRODUCTION|DEPLOYMENT|SHIPPING)"
    r"|(?:NO|WITHOUT|WITH\s+NO)\s+(?:(?:OPEN|NEW|UNFIXED|OUTSTANDING|BLOCKING|REMAINING)\s+)?"
    r"(?:CONDITIONS?|CAVEATS?|RESERVATIONS?|FINDINGS?|ISSUES?)"
    rf"|(?:0|ZERO)\s+(?:{_SEV}(?:\s*/\s*{_SEV})*\s+)?(?:FINDINGS?|ISSUES?)"
    rf"|(?:0|NO|ZERO)\s+(?:(?:OPEN|UNFIXED|OUTSTANDING|BLOCKING|REMAINING|NEW)"
    rf"|{_SEV}(?:\s*/\s*{_SEV})*)(?:\s+(?:FINDINGS?|ISSUES?))?"
    r"|(?:ALL\s+)?(?:FIXED|RESOLVED|REMEDIATED)"
    r"|(?:\d+|ALL)\s+(?:FIXED|RESOLVED|REMEDIATED)"
    r"(?:\s+IN\s+THIS\s+(?:PR|CHANGE|DIFF|ORDER|VOYAGE|BRANCH))?"
    r"|(?:WAS|PREVIOUSLY|FORMERLY)\s+(?:APPROVED|CONDITIONAL|REJECTED|BLOCKED)"
    # Only the review itself (BUG-MSO-2026-0755 NB-01): "after re-review" says the
    # SEC review this report IS was redone; "after re-test" or "after verification"
    # names OTHER work that may still be to come, so it qualifies the approval.
    r"|AFTER\s+(?:RE-?)?(?:REVIEW|AUDIT)"
    r")",
    re.IGNORECASE,
)
_ASIDE_TRIM = " \t\"'“”‘’!-–—~_:"
# A NONZERO count is not resolved work on its own ("APPROVED — 2 CRITICAL
# findings" is a condition — QA DEF-022). It is benign only when the clause
# directly after it resolves it: "1 finding (FIXED)", "2 findings, all fixed".
_COUNT_CLAUSE_RE = re.compile(
    rf"\d+\s+(?:{_SEV}(?:\s*/\s*{_SEV})*\s+)?(?:FINDINGS?|ISSUES?)", re.IGNORECASE)
_RESOLVES_COUNT_RE = re.compile(r"(?:ALL\s+)?(?:FIXED|RESOLVED|REMEDIATED)", re.IGNORECASE)
# Any verdict word, anywhere — used only to classify a value that did NOT decide.
_TOKEN_MENTION_RE = re.compile(
    r"\b(?:APPROVED|CONDITIONAL|REJECTED|BLOCKED|PASSED|PASS|FAILED|FAIL)\b")
# Two verdict words joined as alternatives: an unfilled template placeholder
# ("APPROVED | CONDITIONAL | REJECTED" — maestro/roles/SEC.md), never a decision
# (QA DEF-010). "APPROVED (was REJECTED)" names two words and is not one.
_PLACEHOLDER_RE = re.compile(
    r"\b(?:APPROVED|CONDITIONAL|REJECTED|BLOCKED|PASSED|PASS|FAILED|FAIL)"
    r"\s*(?:\\?\||/|\b(?i:or)\b)\s*"
    r"(?:APPROVED|CONDITIONAL|REJECTED|BLOCKED|PASSED|PASS|FAILED|FAIL)\b")
# A value that is NOTHING BUT verdict words, joined by commas, spaces or "or"
# ("APPROVED, CONDITIONAL, or REJECTED", "✅ APPROVED ⚠️ CONDITIONAL ❌ REJECTED")
# — the same unfilled template without the pipes (QA DEF-015). The one decided
# two-word phrase of that shape, "CONDITIONAL APPROVED", is excluded.
_VERDICT_WORD = r"(?:APPROVED|CONDITIONAL|REJECTED|BLOCKED|PASSED|PASS|FAILED|FAIL)"
_VERDICT_LIST_RE = re.compile(
    rf"{_VERDICT_WORD}(?:(?:\s*,\s*|\s+)(?:(?i:or)\s+)?{_VERDICT_WORD})+[\s.!]*")
_CONDITIONAL_APPROVED_RE = re.compile(r"CONDITIONAL\s+APPROVED[\s.!]*")
# A prose line that opens by denying ("NOT APPROVED.", "NOT YET APPROVED").
_OPENING_DENIAL_RE = re.compile(
    r"^(?:NOT|NEVER|CANNOT)\b(?:\s+[A-Z]+){0,2}?\s+(?:APPROVED|CONDITIONAL|REJECTED|BLOCKED)\b")

# ---- The DOCUMENT allowlist (QA DEF-018..022) --------------------------------
# The clause allowlist judges ONE line. A report can approve on one line and
# qualify, deny or contradict it on another ("**Status:** APPROVED" followed by
# "**Conditions:**", a sign-off that says PENDING, a second section that says
# REJECTED). So an APPROVED read by the cascade stands only when NO decision-
# bearing line in the document disagrees with it. Matched case-insensitively and
# on letter boundaries (not \b), so "_REJECTED_" and "__Status:__ REJECTED" count.
_DISAGREEMENT_RE = re.compile(
    r"(?<![A-Za-z])(?:REJECTED|BLOCKED|CONDITIONAL(?:LY)?|NOT\s+(?:YET\s+)?APPROVED"
    r"|PENDING|ON\s+HOLD|WITHDRAWN|REVOKED|DO\s+NOT\s+MERGE"
    r"|NOT\s+FOR\s+(?:RELEASE|MERGE|MERGING|PRODUCTION|DEPLOYMENT)"
    # QA DEF-027: denial vocabulary a decision line uses that the list above lacked.
    r"|DENIED|UNAPPROVED|DEFERRED|CHANGES\s+REQUESTED"
    r"|DO\s+NOT\s+(?:RELEASE|SHIP|DEPLOY)|NOT\s+(?:YET\s+)?READY)(?![A-Za-z])",
    re.IGNORECASE,
)
# A line that opens with a conditions label introduces conditions — unless its
# value says there are none ("Conditions: None"). The label may carry qualifier
# words (QA DEF-025): "Conditions of approval:", "Approval conditions:",
# "Release conditions:", "Conditions apply:", "Pre-merge requirements:".
# The FIRST qualifier word may not open with "_" or "-" (BUG-MSO-2026-0756,
# SEC-0735-01): the leading [\W_]* class matches both too, so a long run of either
# could be split between the two O(n) ways at every backtrack point — O(n^2),
# ~50 minutes for one 512 KiB line. It matches exactly the same lines: a leading
# "_"/"-" is always absorbed by the leading class instead.
_CONDITIONS_LABEL_RE = re.compile(
    r"^[\W_]*(?:[^\W_][\w-]*\s+(?:[\w-]+\s+){0,2}?)??"
    r"(?:conditions?|caveats?|reservations?|requirements?)"
    r"(?:\s+(?:of|for|before|to)\s+[\w-]+|\s+apply)?\s*:\s*(?P<rest>.*)$", re.IGNORECASE)
_NONE_VALUE_RE = re.compile(r"^(?:none|n/?a|nil|-|—|–)[\s.]*$", re.IGNORECASE)
# A table whose FIRST header cell names conditions is a conditions block
# ("| Condition | Owner |" — QA DEF-025).
_CONDITIONS_TABLE_RE = re.compile(
    r"^\|\s*(?:[\w-]+\s+){0,2}?(?:conditions?|caveats?|reservations?)\s*\|", re.IGNORECASE)
# A HEADING that introduces conditions on the approval (QA DEF-024): "Conditions",
# "Release Conditions", "Conditions of Approval", "Required Actions Before Merge".
# "Conditions for exploitation" and "Race Conditions" describe a finding, not the
# decision — the object after of/for/before must be an approval word, and a
# technical qualifier excludes the heading.
_APPROVAL_OBJECT = (r"(?:the\s+)?(?:approval|acceptance|release|merg\w*|ship\w*|deploy\w*"
                    r"|sign-?off|production)\b")
_CONDITIONS_HEADING_RE = re.compile(
    r"^(?:[\w-]+\s+){0,3}?(?:conditions?|caveats?|reservations?)"
    rf"(?:\s+(?:of|for|before|to|on)\s+{_APPROVAL_OBJECT}.*|\s+apply)?(?:\s*[—–(:].*)?$"
    r"|^(?:[\w-]+\s+){0,3}?(?:required|requirements?|must)\b.*"
    rf"\bbefore\s+{_APPROVAL_OBJECT}"
    # BUG-MSO-2026-0755 NB-09: a heading naming work still to do before the approval
    # holds ("Merge Blockers", "Open Items", "Action Items") introduces conditions on
    # it just as "Conditions" does. Deliberately NOT "Outstanding/Open Issues" or
    # "... Findings": live SEC reports use those for a severity-count table of
    # findings (mostly "0 | —") under a genuine APPROVED.
    r"|^(?:[\w-]+\s+){0,3}?(?:blockers?|(?:open|outstanding)\s+items?|action\s+items?)"
    r"(?:\s*[—–(:].*)?$",
    re.IGNORECASE)
_TECHNICAL_CONDITION_RE = re.compile(
    r"(?<![A-Za-z])(?:race|edge|boundary|error|failure|exit|loop|initial|trigger|test"
    r"|branch|pre|post)[\s-]+conditions?(?![A-Za-z])", re.IGNORECASE)
# The first body line of a conditions heading that says there are none.
_NONE_BODY_RE = re.compile(
    r"^(?:none|n/?a|nil|no\s+(?:(?:open|outstanding|unresolved|remaining)\s+)?"
    r"(?:conditions?|caveats?|reservations?|requirements?|blockers?|items?|issues?"
    r"|actions?|findings?)(?:\s+apply)?|-|—|–)[\s.!]*$", re.IGNORECASE)
# A thematic break ("---", "***") ends a section visually; it is not body content.
_RULE_LINE_RE = re.compile(r"^(?:[-*_]\s*){3,}$")
# A bullet or blockquote prefix before a declaration ("- **Verdict:** FAIL").
_DECLARATION_PREFIX_RE = re.compile(r"^(?:[>+*-]\s*)+")
# A numbered-list prefix before a declaration ("1. **Verdict:** FAIL" — NB-07).
_NUMBERED_PREFIX_RE = re.compile(r"^\d{1,3}[.)]\s+")
# Declaration shapes weaker than a bare label (BUG-MSO-2026-0755 NB-07): a qualified
# label ("Final Verdict: FAIL") or a dash separator ("Status — FAIL"). Descriptive
# lines share the shape ("Test Status: 12 passing"), so a weak declaration only
# disagrees when its value opens with a verdict — see _judge_weak_declaration.
_WEAK_DECLARATION_RE = re.compile(
    r"^(?:#{1,6}\s+)?(?:[\w-]+\s+){0,2}?(?:status|decision|verdict)"
    r"(?:\s*:|\s*[—–]|\s+-\s)\s*(?P<value>\S.*)$", re.IGNORECASE)
# History, not disagreement: "APPROVED (was REJECTED)".
_HISTORICAL_VERDICT_RE = re.compile(
    r"(?<![A-Za-z])(?:WAS|PREVIOUSLY|FORMERLY)\s+(?:REJECTED|BLOCKED|CONDITIONAL)(?![A-Za-z])",
    re.IGNORECASE)
# Warning / denial markers on a verdict line ("APPROVED ⚠️", "APPROVED ❌").
_CAUTION_GLYPHS = ("⚠", "\U0001f7e1")
_DENIAL_GLYPHS = ("❌", "✗", "✘", "⛔", "\U0001f534", "\U0001f6ab")
# Which sections carry the report's decision. Deliberately NOT only the cascade's
# verdict-section shapes: "## Security Review Decision", "## Verdict (after
# re-review)" and "## Security Decision — REJECTED" are decision-bearing too.
# "signature" only as the title's LAST word (BUG-MSO-2026-0755 NB-06): "## Signature"
# and "## SEC Signature" sign a report; "### 2. Signature Forgery" is a finding.
_DECISION_BEARING_RE = re.compile(
    r"(?<![A-Za-z])(?:decision|verdict)(?![A-Za-z])|sign-?off|(?<![A-Za-z])signatures?$"
    r"|^(?:executive\s+)?summary$",
    re.IGNORECASE,
)
_SUPERSEDED_RE = re.compile(r"(?<![A-Za-z])(?:prior|previous|supersed\w*)(?![A-Za-z])",
                            re.IGNORECASE)

# ---- Lower-tier decided denials (Captain ruling NB-05 option 2) ---------------
# Narrower than _DISAGREEMENT_RE: at a tier BELOW the approval only a DECIDED
# denial counts, and it must OPEN the value or line. PENDING / ON HOLD / DEFERRED
# are not decisions; NOT READY is not a denial of approval.
_DENIAL_VALUE_RE = re.compile(
    r"^(?:NOT\s+(?:YET\s+)?APPROVED|UNAPPROVED|DENIED|REVOKED|CHANGES\s+REQUESTED"
    r"|DO\s+NOT\s+(?:MERGE|RELEASE|SHIP|DEPLOY)"
    r"|NOT\s+FOR\s+(?:RELEASE|MERGE|MERGING|PRODUCTION|DEPLOYMENT))(?![A-Za-z])",
    re.IGNORECASE,
)
# "NEVER APPROVED", "CANNOT BE APPROVED" — uppercase, like every token rule here.
# Unlike _OPENING_DENIAL_RE, only a denied APPROVAL: "NOT REJECTED" denies nothing.
_OPENING_APPROVAL_DENIAL_RE = re.compile(r"^(?:NOT|NEVER|CANNOT)\b(?:\s+[A-Z]+){0,2}?\s+APPROVED\b")
# A declaration VALUE opening with a denial token in any case ("Rejected",
# "blocked", "Fail") — QA DEF-001. Whole word only: "rejected-input handling" is
# a description, not a decision. Approval tokens are deliberately absent, so
# nothing here can move a read toward APPROVED.
_ANY_CASE_DENIAL_TOKEN_RE = re.compile(r"^(rejected|blocked|failed|fail)(?![\w-])", re.IGNORECASE)
# A lower-tier line that says its denial was since RESOLVED is history, not a
# decision: "REJECTED in lap 1 (F1); F1 fixed in abc123 and re-reviewed",
# "REJECTED in the draft; approved now". Lower-tier path only — the shared
# _HISTORICAL_VERDICT_RE (and so every same-tier read) is untouched. A line that
# also says the resolution is still to come ("until F1 is fixed in the next PR")
# keeps its denial. Plain alternations, searched on one plain line — linear.
_LOWER_TIER_RESOLVED_RE = re.compile(
    r"(?<![A-Za-z])(?:(?:fixed|resolved|remediated|addressed)\s+in|since\s+(?:fixed|resolved)"
    r"|approved\s+now|now\s+approved)(?![A-Za-z])", re.IGNORECASE)
_LOWER_TIER_STILL_OPEN_RE = re.compile(
    r"(?<![A-Za-z])(?:until|pending|before|unless|once)(?![A-Za-z])", re.IGNORECASE)
# "FAIL-safe", "BLOCKED-list": a hyphenated compound opening a value names a
# thing, not a verdict (mirrors the "rejected-input" control).
_HYPHEN_COMPOUND_RE = re.compile(r"^[A-Za-z]+-[A-Za-z]")
# A line or heading that declares a section's verdict after its title
# ("SEC Sign-off: REJECTED", "Summary — REJECTED") — QA DEF-002. Matched on
# PLAIN, whitespace-collapsed text only, so every gap is ONE literal space: a
# ``\s*`` after the lazy label would rescan a long blank run once per label
# length (BUG-MSO-2026-0756). Label bounded, match anchored — linear.
_SECTION_DECLARATION_RE = re.compile(
    r"^(?:#{1,6} )?(?P<label>[^:—–|]{1,80}?) ?(?::|—|–| - ) ?(?P<value>\S.*)$")

# A declaration line, matched on the PLAIN text (emphasis and code markers
# removed). Optional heading hashes, so ``### Status: APPROVED`` counts; NO bullet
# prefix, because a bulleted ``- **Status:** NOT IMPLEMENTED`` is an item's status
# inside a checklist, not the report's decision. ``result`` is deliberately not a
# label: ``Validation Result: PASS`` is a statement about validation.
_DECLARATION_RE = re.compile(
    r"^(?:#{1,6}\s+)?(?:(?:security|sec)\s+)?"
    r"(status|decision|verdict)\s*:\s*(.+)$",
    re.IGNORECASE,
)
_DECLARATION_LABEL_RE = re.compile(
    r"^(?:(?:security|sec)\s+)?(status|decision|verdict)$", re.IGNORECASE
)

_VERDICT_SECTION_RE = re.compile(
    r"^(?:(?:security|sec)\s+(?:decision|verdict)|(?:final\s+)?verdict"
    r"|(?:final\s+)?decision)\s*(?::|$)",
    re.IGNORECASE,
)
_SIGNOFF_SECTION_RE = re.compile(r"(?:^|\s)sign-?off$|^signature$", re.IGNORECASE)
_SUMMARY_SECTION_RE = re.compile(r"^(?:executive\s+)?summary$", re.IGNORECASE)

_GLYPHS = ("✅", "✔", "☑", "✓", "❌", "✗", "✘", "⚠", "️", "\U0001f7e2",
           "\U0001f7e1", "\U0001f534")
# A footnote star glued to an approval ("**Status:** APPROVED*", "**APPROVED***")
# points at text elsewhere that qualifies it (BUG-MSO-2026-0755 NB-03). Emphasis
# stars pair up, so the star run after the token is a footnote only when that run
# is odd AND the line's stars (a leading "* " bullet aside) do not pair. It is kept
# as a dagger, which survives _plain and reads as a non-benign clause.
_FOOTNOTE_STAR_RE = re.compile(r"(?<![A-Za-z])(APPROVED|PASSED|PASS)(\*+)")
_FOOTNOTE_MARK = "†"

_FENCE_RE = re.compile(r"^\s*(```|~~~)")
_LIST_ITEM_RE = re.compile(r"^\s*(?:[-*+]|\d+[.)])\s")

_FINDING_ID_RE = re.compile(
    r"^(?:(?P<word>(?i:finding)\s+\d+)|(?P<code>[A-Z]{1,4}-?\d+(?:-\d+)*)"
    r"|(?P<num>\d+)\.)(?=[\s:(\[\-—–]|$)"
)
# Retried from every UNCLOSED opener, this is O(n^2) — apply it only through
# :func:`_bracket_head`, which cuts the text at its last closer (BUG-MSO-2026-0756).
_BRACKET_GROUP_RE = re.compile(r"[(\[]([^)\]]*)[)\]]")
# As _CLAUSE_SPLIT_RE: no leading whitespace run; callers strip every segment.
_SEGMENT_SPLIT_RE = re.compile(r"\s-\s+|[—–]\s*|:\s+")
_CWE_RE = re.compile(r"\bCWE-\d+\b")

_REVIEW_STEM_TS_RE = re.compile(r"(\d{8}T\d{6}Z)")
_SCANNER_FINDING_HEAD_RE = re.compile(r"^###\s+(\d+)\.\s+\[([A-Z]+)\]\s+(.*)$")
_SCANNER_BULLET_RE = re.compile(r"^-\s+\*\*([A-Za-z ]+)\*\*:\s*(.*)$")
_SCANNER_HEADER_RE = re.compile(r"^\*\*([A-Za-z ]+)\*\*:\s*(.*?)\s*$")
_SCAN_SUMMARY_COLUMNS = {"severity": "severity", "count": "count"}

_PATH_TRAVERSAL_REAL_RE = re.compile(r"\.\.[/\\]")

_BASE_SCANNER_CAVEAT = (
    "Pattern-scanner run: regex matches over every file the scanner walked, not "
    "reviewed findings and not a security posture. The diff target is a label "
    "only and does not narrow the scan."
)


# ---------------------------------------------------------------------------
# Markdown structure (fence-aware)
# ---------------------------------------------------------------------------

class _Block:
    """A heading and every line beneath it up to the next same-or-shallower heading.

    Unlike ``qa_reader._Section``, a block keeps its SUBHEADING lines, because
    SEC reports put declarations in them (``## Security Decision`` /
    ``### Status: ✅ APPROVED``). Lines inside a fenced code block are kept as
    blanks: a ``# comment`` in a shell sample is not a heading, and a
    ``Status: REJECTED`` inside quoted output is not the report's decision.
    """

    __slots__ = ("level", "raw_title", "title", "lines")

    def __init__(self, level: int, raw_title: str) -> None:
        self.level = level
        self.raw_title = raw_title
        self.title = _normalise_heading(_plain(raw_title))
        self.lines: List[str] = []

    @property
    def heading(self) -> str:
        return f"{'#' * self.level} {self.raw_title}".strip()


def _unfenced_lines(text: str) -> List[Tuple[str, bool]]:
    """``(line, is_prose)`` for every line — ``False`` inside a code block.

    Both fenced blocks and indented (4-space / tab) blocks are code (QA DEF-002).
    An indented block needs a blank line before it and must not continue a list
    item, so a list item's indented continuation paragraph stays prose.
    """
    out: List[Tuple[str, bool]] = []
    in_fence = False
    in_indented = False
    prev_blank = True
    in_list = False
    for line in (text or "").splitlines():
        if in_fence:
            if _FENCE_RE.match(line):
                in_fence = False
            out.append((line, False))
            prev_blank = False
            continue
        if not line.strip():
            out.append((line, True))
            prev_blank = True
            continue
        expanded = line.expandtabs(4)
        indent = len(expanded) - len(expanded.lstrip())
        if indent >= 4 and (in_indented or (prev_blank and not in_list)):
            in_indented = True
            out.append((line, False))
            prev_blank = False
            continue
        in_indented = False
        prev_blank = False
        if _FENCE_RE.match(line):
            in_fence = True
            out.append((line, False))
            continue
        if _HEADING_RE.match(line.strip()):
            # A heading is not a paragraph: an indented block directly beneath it
            # is code, blank line or not (QA DEF-012).
            prev_blank = True
            in_list = False
        elif _LIST_ITEM_RE.match(line):
            in_list = True
        elif indent == 0:
            in_list = False
        out.append((line, True))
    return out


def _blocks(text: str) -> List[_Block]:
    blocks: List[_Block] = []
    stack: List[_Block] = []
    for line, prose in _unfenced_lines(text):
        m = _HEADING_RE.match(line.strip()) if prose else None
        if m:
            level = len(m.group(1))
            block = _Block(level, m.group(2))
            while stack and stack[-1].level >= level:
                stack.pop()
            for parent in stack:
                parent.lines.append(line)
            blocks.append(block)
            stack.append(block)
            continue
        for parent in stack:
            parent.lines.append(line if prose else "")
    return blocks


def _preamble(text: str, cap: int = 40) -> List[str]:
    out: List[str] = []
    for line, prose in _unfenced_lines(text)[:cap]:
        if prose:
            m = _HEADING_RE.match(line.strip())
            if m and len(m.group(1)) >= 2:
                break
        out.append(line if prose else "")
    return out


def _plain(text: str) -> str:
    """*text* without emphasis/code markers or status glyphs, whitespace-collapsed.

    Every marker is removed, not just matched outer wrappers:
    ``**Status:** ✅ **APPROVED**`` has four ``**`` runs and would otherwise keep
    two of them glued to the label.
    """
    body = _mark_footnote_star(text or "").replace("**", "").replace("`", "")
    body = body.replace("*", "")
    for glyph in _GLYPHS:
        body = body.replace(glyph, " ")
    return " ".join(body.split())


def _mark_footnote_star(text: str) -> str:
    """*text* with a footnote star after an approval token marked (NB-03)."""
    if "*" not in text:
        return text
    stars = text.count("*") - (1 if text.lstrip().startswith("* ") else 0)
    if stars % 2 == 0:
        return text
    return _FOOTNOTE_STAR_RE.sub(
        lambda m: m.group(0) + _FOOTNOTE_MARK if len(m.group(2)) % 2 else m.group(0), text)


# ---------------------------------------------------------------------------
# Verdict
# ---------------------------------------------------------------------------

def _opening_verdict(text: str, allow_aliases: bool) -> Optional[str]:
    """The canonical verdict *text* OPENS with, or ``None``.

    Uppercase tokens only, and only at the start (after emphasis, glyphs and
    quotes) — a token later in the text is a mention, not a decision
    ("NOT YET APPROVED", "Plan APPROVED by Captain; review in progress").

    * A negation in the token's own clause skips it, never inverts it —
      inverting would be inventing the opposite claim ("APPROVED is not granted
      until F1 lands"). An approval is judged over EVERY clause by
      :func:`_judge_approval_clauses` — the one rule every tier shares.
    * "CONDITIONALLY APPROVED" reads as CONDITIONAL.
    * Verdict words offered as alternatives ("APPROVED | REJECTED",
      "APPROVED, CONDITIONAL, or REJECTED") are an unfilled template, not a
      decision.
    * Aliases (PASS/FAIL) are honoured only where the caller says the text is a
      declaration.
    """
    body = _plain(text).lstrip(_LEADING_QUOTES)
    if not body or _is_placeholder(body):
        return None
    if _ADVERB_APPROVAL_RE.match(body):
        return Verdict.CONDITIONAL
    m = _OPENING_TOKEN_RE.match(body)
    canonical = m.group(1) if m else None
    if m is None and allow_aliases:
        m = _OPENING_ALIAS_RE.match(body)
        canonical = Verdict.normalise(m.group(1)) if m else None
    if m is None or canonical is None:
        return None

    clauses = [c.strip() for c in _CLAUSE_SPLIT_RE.split(body[m.end():])]
    if canonical == Verdict.APPROVED:
        return _judge_approval_clauses(clauses)
    own = clauses[0]
    following = next((c for c in clauses[1:] if c), "")
    window = own if own or canonical != Verdict.CONDITIONAL else following
    if _CLAUSE_NEGATION_RE.search(own) or _CLAUSE_NEGATION_RE.search(window):
        return None
    return canonical


def _judge_approval_clauses(clauses: Sequence[str]) -> Optional[str]:
    """What an APPROVED token followed by *clauses* declares — ONE rule, every tier.

    Declaration line, table cell, JSON field, heading value and opening line all
    reach this through :func:`_opening_verdict`, so the tiers cannot disagree
    about the same words (QA DEF-014).

    * A negation in ANY clause → ``None`` (the caller ends the cascade
      UNDETERMINED). "APPROVED — no findings, NOT for release" names the word and
      withholds it; which clause the denial sits in does not matter.
    * Otherwise every non-empty clause must be a known-benign aside for
      ``APPROVED``. Any other clause, anywhere — "requires LEAD sign-off first",
      "except F2", "1 deferred", "if F1 is out of scope" — makes it
      ``CONDITIONAL``: the report said more than "approved", and what it said is
      not on the list of things known not to qualify an approval.
    """
    live = [c for c in clauses if c.strip(_ASIDE_TRIM)]
    if any(_CLAUSE_NEGATION_RE.search(c) for c in live):
        return None
    for idx, clause in enumerate(live):
        if _is_benign_aside(clause):
            continue
        text = " ".join(clause.split()).strip(_ASIDE_TRIM)
        after = " ".join(live[idx + 1].split()).strip(_ASIDE_TRIM) if idx + 1 < len(live) else ""
        if _COUNT_CLAUSE_RE.fullmatch(text) and _RESOLVES_COUNT_RE.fullmatch(after):
            continue
        return Verdict.CONDITIONAL
    return Verdict.APPROVED


def _is_placeholder(body: str) -> bool:
    """True when *body* offers verdict words as alternatives rather than deciding."""
    if _PLACEHOLDER_RE.search(body):
        return True
    return (_VERDICT_LIST_RE.fullmatch(body) is not None
            and _CONDITIONAL_APPROVED_RE.fullmatch(body) is None)


def _is_benign_aside(clause: str) -> bool:
    """True when an approval's clause is empty or a known-benign aside."""
    text = " ".join((clause or "").split()).strip(_ASIDE_TRIM)
    return not text or _BENIGN_ASIDE_RE.fullmatch(text) is not None


def _undecided_reason(value: str) -> Optional[str]:
    """Why a value that did NOT decide must still END the cascade, or ``None``.

    A report that declares a denial ("NOT APPROVED", "APPROVED — NOT for
    release") or an unfilled placeholder has said something about its verdict;
    reading a later or lower-precedence line past it would override the report's
    own declaration (QA DEF-008, DEF-010). A value that merely names no verdict
    word ("COMPLETE", "ACCEPTED (LEAD)") says nothing and the cascade continues.
    """
    body = _plain(value).lstrip(_LEADING_QUOTES)
    if _is_placeholder(body):
        return ("offers verdicts as alternatives — an unfilled template placeholder, "
                "not a decision")
    if _TOKEN_MENTION_RE.search(body) and _CLAUSE_NEGATION_RE.search(body):
        return "names a verdict but negates or withholds it"
    if _OPENING_TOKEN_RE.match(body) or _OPENING_DENIAL_RE.match(body):
        return "opens with a verdict word but does not decide it"
    return None


def _declarations(lines: Iterable[str]) -> Iterable[Tuple[str, str]]:
    """Every ``(label, value)`` declaration in *lines*, in order."""
    for line in lines:
        raw = (line or "").strip()
        if not raw:
            continue
        if raw.startswith("|"):
            cells = [_plain(c) for c in raw.strip("|").split("|")]
            if len(cells) == 2 and cells[1] and _DECLARATION_LABEL_RE.match(
                    cells[0].strip().strip(":")):
                yield cells[0].strip(), cells[1].strip()
            continue
        m = _DECLARATION_RE.match(_plain(raw))
        if m and m.group(2).strip():
            yield m.group(1).strip(), m.group(2).strip()


_UNRECOGNISED_REASON = ("is not a recognised verdict token (APPROVED, CONDITIONAL, "
                        "REJECTED or BLOCKED) and was not interpreted")


class _Stop(Exception):
    """A value that ends the cascade UNDETERMINED (see :func:`_undecided_reason`)."""

    def __init__(self, value: str, where: str, reason: str) -> None:
        super().__init__(reason)
        self.value, self.where, self.reason = value, where, reason

    def result(self) -> Tuple[str, str, str, List[str]]:
        return Verdict.UNDETERMINED, "", "", [
            f"Declared verdict '{_clip(self.value)}' under '{self.where}' "
            f"{self.reason}; read as UNDETERMINED. No later or lower-precedence "
            "line was consulted — a report's own denial is never overridden."]


def _opening_token_line(lines: Iterable[str], where: str) -> Optional[Tuple[str, str]]:
    """A standalone verdict line: prose that OPENS with a token.

    ``✓ APPROVED``, ``**APPROVED** ✅``, ``✅ **APPROVED FOR RELEASE**``,
    ``**CONDITIONAL APPROVAL**``. Opening-only on purpose — a sentence that
    mentions REJECTED halfway through is explaining, not deciding. A line that
    opens with a token or a denial and does not decide raises :class:`_Stop`.
    """
    for line in lines:
        text = _plain(line)
        if not text or text.startswith(("|", "#", "-", ">")):
            continue
        verdict = _opening_verdict(text, allow_aliases=False)
        if verdict is not None:
            return verdict, text
        body = text.lstrip(_LEADING_QUOTES)
        if (_OPENING_TOKEN_RE.match(body) or _OPENING_DENIAL_RE.match(body)
                or _ADVERB_APPROVAL_RE.match(body)):
            raise _Stop(text, where, _undecided_reason(text)
                        or "opens with a verdict word but does not decide it")
    return None


class _VerdictScan:
    __slots__ = ("unrecognised",)

    def __init__(self) -> None:
        #: First declaration seen that named no recognised token, for the note.
        self.unrecognised: Optional[Tuple[str, str]] = None

    def note(self, value: str, where: str) -> None:
        if self.unrecognised is None:
            self.unrecognised = (value, where)

    def check(self, value: str, where: str, final: bool = False) -> Optional[str]:
        """The verdict *value* declares; raises :class:`_Stop` on a denial.

        With *final* (a declaration inside a verdict section) a value that names
        no verdict — ``PENDING``, ``REVOKED``, ``ON HOLD`` — ALSO raises: the
        report has declared its verdict status, and a lower-tier ``APPROVED``
        read past it would be a stale approval overriding it (QA DEF-016).
        """
        verdict = _opening_verdict(value, allow_aliases=True)
        if verdict is not None:
            return verdict
        reason = _undecided_reason(value)
        if reason is None and final:
            reason = _UNRECOGNISED_REASON
        if reason is not None:
            raise _Stop(value, where, reason)
        self.note(value, where)
        return None

    def from_declarations(self, lines: Iterable[str], where: str, final: bool = False
                          ) -> Optional[Tuple[str, str]]:
        for _label, value in _declarations(lines):
            verdict = self.check(value, where, final)
            if verdict is not None:
                return verdict, value
        return None


def extract_security_verdict(text: str) -> Tuple[str, str, str, List[str]]:
    """``(verdict, raw_verdict, verdict_source, parse_notes)`` for a SEC report.

    A ``secVerdict`` front-matter field is authoritative and cross-checked
    against the body; without one the heuristic cascade decides (see the module
    docstring for both). Never returns a verdict it did not read, and never
    defaults to APPROVED.
    """
    field = _sec_verdict_field(text)
    if field is not None:
        return _front_matter_verdict(text, field)
    return _heuristic_verdict(text)


def _heuristic_verdict(text: str) -> Tuple[str, str, str, List[str]]:
    """The cascade plus the document checks — the whole read of a report with no field."""
    try:
        result = _verdict_cascade(text)
    except _Stop as stop:
        return stop.result()
    if result[0] != Verdict.APPROVED:
        return result
    return _judge_document_approval(text, result)


def _judge_document_approval(text: str, result: Tuple[str, str, str, List[str]]
                             ) -> Tuple[str, str, str, List[str]]:
    """What the rest of the document does to the cascade's APPROVED *result*.

    The tiered document allowlist first (a disagreement at or above the
    approval's tier), then the NB-05 rule: a decided denial or rejection in a
    LOWER decision-bearing section makes the report UNDETERMINED. A lower-tier
    denial outranks a same-tier qualification — UNDETERMINED is the more
    conservative of the two reads.
    """
    tier = _source_tier(result[2])
    read = f"Read APPROVED from '{_clip(result[1])}' under '{result[2]}', but "
    disagreement = _document_disagreement(text, tier)
    if disagreement is not None and disagreement[0] != Verdict.CONDITIONAL:
        _verdict, line, where = disagreement
        return Verdict.UNDETERMINED, "", "", [
            read + f"the decision line '{_clip(line)}' under '{where}' disagrees with it; "
            "read as UNDETERMINED. A report whose own decision text withholds, denies or "
            "contradicts an approval is never shown as approved."]
    lower = _lower_tier_contradiction(text, tier)
    if lower is not None:
        _verdict, line, where = lower
        return Verdict.UNDETERMINED, "", "", [
            read + f"the lower-tier decision line '{_clip(line)}' under '{where}' denies "
            "or rejects it; read as UNDETERMINED. A self-contradicting report is never "
            "shown as approved, and is not read as rejected either (NB-05)."]
    if disagreement is not None:
        _verdict, line, where = disagreement
        return Verdict.CONDITIONAL, result[1], result[2], [
            read + f"the decision line '{_clip(line)}' under '{where}' qualifies it; "
            "read as CONDITIONAL."]
    return result


def _lower_tier_contradiction(text: str, source_tier: int
                              ) -> Optional[Tuple[str, str, str]]:
    """``(verdict, line, where)`` for a decided denial BELOW *source_tier* (NB-05).

    Reads the decision-bearing sections strictly below the approval's tier, down
    to the summary tier — never the document preamble, which is not a section
    (a stale preamble from before a re-review is still not read).
    """
    if source_tier >= _TIER_SUMMARY:
        return None
    return _document_disagreement(text, _TIER_SUMMARY, min_tier=source_tier + 1,
                                  judge=_judge_lower_tier_line,
                                  conditions_headings=False,
                                  tier_of=_declared_section_tier)


def _declared_section_tier(title: str) -> Optional[int]:
    """:func:`_block_tier`, or the tier of the label a title declares a verdict after.

    ``## Summary: REJECTED`` is the summary section even though its title is not
    exactly ``Summary`` (QA DEF-002). Lower-tier pass only — the document
    allowlist keeps :func:`_block_tier`, so no same-tier read changes.
    """
    tier = _block_tier(title)
    if tier is not None or not title or _SUPERSEDED_RE.search(title):
        return tier
    split = _SECTION_DECLARATION_RE.match(title)
    return _block_tier(_normalise_heading(split.group("label"))) if split else None


def _judge_lower_tier_line(line: str) -> Optional[str]:
    """``UNDETERMINED`` when a lower-tier *line* DECIDES a denial or rejection, else ``None``.

    Narrower than :func:`_judge_decision_line` on purpose: below the approval's
    tier only a declaration whose value rejects, blocks or denies
    (``**Status:** REJECTED``, ``Decision: Rejected``, ``Verdict: FAIL``), a
    section title declaring one (``SEC Sign-off: REJECTED``), or a prose line
    that OPENS with one (``REJECTED.``, ``NOT APPROVED``), counts. A ``PENDING``
    or ``CONDITIONAL`` there, a sentence naming ``REJECTED`` halfway through, or
    a history aside (``was REJECTED``) does not.
    """
    raw = (line or "").strip()
    if not raw:
        return None
    body = _HISTORICAL_VERDICT_RE.sub(" ", _plain(raw)).strip()
    if (_LOWER_TIER_RESOLVED_RE.search(body) is not None
            and _LOWER_TIER_STILL_OPEN_RE.search(body) is None):
        return None  # a denial the line itself says was resolved (PR #428 review)
    value = _declaration_value(body)
    if value is not None:
        return Verdict.UNDETERMINED if _is_decided_denial(value, declaration=True) else None
    if body.startswith(("|", ">", "-", "*", "+")):
        split = None
    else:
        split = _SECTION_DECLARATION_RE.match(body)
    if (split is not None
            and _block_tier(_normalise_heading(split.group("label"))) is not None
            and _is_decided_denial(split.group("value"), declaration=True)):
        return Verdict.UNDETERMINED  # QA DEF-002: the label says the value is the decision
    if body.startswith(("|", "#")):
        return None
    prose = _DECLARATION_PREFIX_RE.sub("", body)
    return Verdict.UNDETERMINED if _is_decided_denial(prose, declaration=False) else None


def _is_decided_denial(text: str, declaration: bool) -> bool:
    """True when *text* OPENS by rejecting, blocking or denying an approval.

    Verdict tokens stay uppercase-only in prose; inside a *declaration* value,
    where the label already says the text is the decision, an opening denial
    token and the denial vocabulary are honoured in any case (QA DEF-001).
    PASS/FAIL aliases likewise count only in a declaration.
    """
    body = (text or "").strip().lstrip(_LEADING_QUOTES)
    if _HYPHEN_COMPOUND_RE.match(body):
        return False  # "FAIL-safe defaults confirmed" names a thing, not a verdict
    if declaration:
        body = _ANY_CASE_DENIAL_TOKEN_RE.sub(lambda m: m.group(1).upper(), body, count=1)
    if not body or _is_placeholder(body):
        return False
    got = _opening_verdict(body, allow_aliases=declaration)
    if got is not None:
        return got in (Verdict.REJECTED, Verdict.BLOCKED)
    if _OPENING_APPROVAL_DENIAL_RE.match(body):
        return True
    denial = _DENIAL_VALUE_RE.match(body)
    if denial is not None and (declaration or denial.group(0).isupper()):
        return True
    opening = _OPENING_TOKEN_RE.match(body)
    return (opening is not None and opening.group(1) == Verdict.APPROVED
            and _CLAUSE_NEGATION_RE.search(body) is not None)


# ---------------------------------------------------------------------------
# The secVerdict front-matter field (FTR-MSO-2026-0779, NB-02 option 3)
# ---------------------------------------------------------------------------

def _sec_verdict_field(text: str) -> Optional[Tuple[Optional[str], str, str, int]]:
    """``(verdict, raw, problem, end)`` for a ``secVerdict`` front-matter field.

    ``None`` when the report declares no such field — the text does not open with
    a ``---`` line, or its opening block never names ``secVerdict`` — so the
    heuristic cascade reads it exactly as before. Otherwise *verdict* is the token
    when the field is well-formed, or ``None`` with *problem* saying why it is not;
    *end* is the index of the closing ``---`` line (``-1`` when there is none).
    Deliberately strict: a machine-readable field that needs interpreting is not
    machine-readable, so ``approved``, ``APPROVED — no findings`` and the SEC.md
    placeholder ``APPROVED | CONDITIONAL | REJECTED`` are all malformed.
    """
    lines = (text or "").splitlines()[:_FRONT_MATTER_LINE_CAP]
    # Leading blank lines before the block are an easy producer slip. The field
    # is not honoured there (front-matter opens on line 1, as Charts' nodeVerdict
    # parser requires), but it is not silently dropped either: a secVerdict behind
    # them is malformed and reads UNDETERMINED (PR #428 review).
    start = 0
    while start < len(lines) and not lines[start].lstrip("﻿").strip():
        start += 1
    if start >= len(lines) or lines[start].lstrip("﻿").strip() != "---":
        return None
    values: List[str] = []
    end = -1
    for idx, line in enumerate(lines[start + 1:], start=start + 1):
        stripped = line.strip()
        if stripped == "---":
            end = idx
            break
        key, sep, value = stripped.partition(":")
        if sep and key.strip() == SEC_VERDICT_KEY:
            values.append(value.strip())
    if not values:
        return None
    raw = values[0]
    if start > 0:
        return None, raw, ("sits in a front-matter block that does not open on line 1 "
                           "(leading blank lines)"), end
    if end < 0:
        return None, raw, "sits in a front-matter block with no closing '---' line", end
    if len(values) > 1:
        return None, raw, f"is declared {len(values)} times in one front-matter block", end
    token = raw
    if len(token) >= 2 and token[0] == token[-1] and token[0] in "\"'":
        token = token[1:-1].strip()
    if token not in SEC_VERDICT_VALUES:
        return None, raw, "is not exactly one of APPROVED, CONDITIONAL or REJECTED", end
    return token, raw, "", end


def _front_matter_verdict(text: str, field: Tuple[Optional[str], str, str, int]
                          ) -> Tuple[str, str, str, List[str]]:
    """The read of a report carrying a ``secVerdict`` field — authoritative, cross-checked.

    The body (front-matter blanked, line numbers kept) is read by the same
    cascade and document checks as a report with no field. The field stands when
    the body agrees with it or declares no verdict at all; any other body —
    a different decided verdict, a self-denial, an approval its own document
    withholds — makes the report UNDETERMINED, preferring neither side.
    """
    declared, raw, problem, end = field
    if declared is None:
        return Verdict.UNDETERMINED, "", "", [
            f"Front-matter {SEC_VERDICT_KEY} '{_clip(raw)}' {problem}; read as "
            "UNDETERMINED. A malformed machine-readable verdict is never guessed at, "
            "and the report body is not read in its place."]
    kept = (text or "").splitlines(keepends=True)
    body = "\n" * (end + 1) + "".join(kept[end + 1:])
    lead = f"Front-matter {SEC_VERDICT_KEY} is {declared}, but "
    disagree = " A report whose verdict field and body disagree is never read as either."
    try:
        cascade = _verdict_cascade(body)
    except _Stop as stop:
        return Verdict.UNDETERMINED, "", "", [
            lead + f"the body's declared verdict '{_clip(stop.value)}' under "
            f"'{stop.where}' {stop.reason}; read as UNDETERMINED." + disagree]
    if cascade[0] == Verdict.UNDETERMINED:
        if declared == Verdict.APPROVED:
            withheld = _document_disagreement(body)
            if withheld is not None:
                _verdict, line, where = withheld
                return Verdict.UNDETERMINED, "", "", [
                    lead + f"the body's decision line '{_clip(line)}' under '{where}' "
                    "does not approve; read as UNDETERMINED." + disagree]
        return declared, raw, _FRONT_MATTER_SOURCE, []
    found = (_judge_document_approval(body, cascade)
             if cascade[0] == Verdict.APPROVED else cascade)
    if found[0] == Verdict.UNDETERMINED:
        return Verdict.UNDETERMINED, "", "", [
            lead + "the body's own verdict does not stand; read as UNDETERMINED."
            + disagree] + list(found[3])
    if found[0] == declared or {found[0], declared} == {Verdict.REJECTED, Verdict.BLOCKED}:
        return declared, raw, _FRONT_MATTER_SOURCE, []
    return Verdict.UNDETERMINED, "", "", [
        lead + f"the body declares {found[0]} ('{_clip(found[1])}' under '{found[2]}'); "
        "read as UNDETERMINED." + disagree]


def _judge_decision_line(line: str) -> Optional[str]:
    """What one decision-bearing *line* does to an APPROVED read, or ``None``.

    ``CONDITIONAL`` for a conditions label (qualified or not) with a real value, a
    conditions table, a ``CONDITIONAL`` word or a caution marker on a verdict
    line; ``UNDETERMINED`` for any other disagreement (a denial, a
    pending/withdrawn status, a contradicting verdict, a denial marker on a
    verdict line). Never ``REJECTED`` — a contradiction is not evidence of a
    rejection either.

    Last, STRUCTURE rather than vocabulary (QA DEF-026): a line that is itself a
    declaration (``status``/``decision``/``verdict``, bullet or quote prefix
    allowed, or a two-cell table row) must itself read APPROVED. A second
    ``**Verdict:** FAIL`` or ``**Status:** IN PROGRESS`` disagrees because it is a
    declaration that does not approve — no word list has to name it.
    """
    raw = (line or "").strip()
    if not raw:
        return None
    body = _HISTORICAL_VERDICT_RE.sub(" ", _plain(raw))
    if _CONDITIONS_TABLE_RE.match(body):
        return Verdict.CONDITIONAL
    label = _CONDITIONS_LABEL_RE.match(body)
    if label is not None and not _NONE_VALUE_RE.match(label.group("rest")):
        return Verdict.CONDITIONAL
    m = _DISAGREEMENT_RE.search(body)
    if m is not None:
        return (Verdict.CONDITIONAL if m.group(0).upper().startswith("CONDITIONAL")
                else Verdict.UNDETERMINED)
    if _TOKEN_MENTION_RE.search(body):
        if any(g in raw for g in _DENIAL_GLYPHS):
            return Verdict.UNDETERMINED
        if any(g in raw for g in _CAUTION_GLYPHS):
            return Verdict.CONDITIONAL
    return _judge_declaration(body)


def _judge_declaration(body: str) -> Optional[str]:
    """What a declaration *body* does to an APPROVED read — ``None`` if it approves
    or is not a declaration, else ``CONDITIONAL`` / ``UNDETERMINED`` (QA DEF-026)."""
    value = _declaration_value(body)
    if value is None:
        return _judge_weak_declaration(body)
    got = _opening_verdict(value, allow_aliases=True)
    if got == Verdict.APPROVED:
        return None
    return Verdict.CONDITIONAL if got == Verdict.CONDITIONAL else Verdict.UNDETERMINED


def _judge_weak_declaration(body: str) -> Optional[str]:
    """What a WEAK declaration *body* does to an APPROVED read (NB-07).

    A qualified label, a dash separator or a table row of three or more cells.
    Unlike a bare declaration it disagrees only when its value OPENS with a
    verdict that is not an approval, or decides a denial — ``Final Verdict: FAIL``
    and ``| Verdict | FAIL | lap 2 |`` do; ``Test Status: 12 passing`` and a
    ``| Status | Count | Owner |`` header row do not.
    """
    value = _weak_declaration_value(body)
    if value is None:
        return None
    got = _opening_verdict(value, allow_aliases=True)
    if got is not None:
        if got == Verdict.APPROVED:
            return None
        return Verdict.CONDITIONAL if got == Verdict.CONDITIONAL else Verdict.UNDETERMINED
    if _is_decided_denial(value, declaration=True) or _undecided_reason(value) is not None:
        return Verdict.UNDETERMINED
    return None


def _weak_declaration_value(body: str) -> Optional[str]:
    """The value of a weak declaration *body* (plain text), or ``None`` (NB-07)."""
    if body.startswith("|"):
        cells = [c.strip() for c in body.strip().strip("|").split("|")]
        if (len(cells) < 3 or not cells[1]
                or not _DECLARATION_LABEL_RE.match(cells[0].strip(":").strip())):
            return None
        return cells[1]
    m = _WEAK_DECLARATION_RE.match(_strip_item_prefix(body))
    return m.group("value").strip() if m is not None else None


def _strip_item_prefix(body: str) -> str:
    """*body* without a bullet, blockquote or numbered-list prefix."""
    return _NUMBERED_PREFIX_RE.sub("", _DECLARATION_PREFIX_RE.sub("", body), count=1)


def _declaration_value(body: str) -> Optional[str]:
    """The value of a declaration *body* (plain text), or ``None`` when it is not one.

    A ``status``/``decision``/``verdict`` label with a bullet or quote prefix
    allowed, or a two-cell table row whose first cell is such a label.
    """
    if body.startswith("|"):
        cells = [c.strip() for c in body.strip().strip("|").split("|")]
        if (len(cells) != 2 or not cells[1]
                or not _DECLARATION_LABEL_RE.match(cells[0].strip(":").strip())):
            return None
        return cells[1]
    m = _DECLARATION_RE.match(_strip_item_prefix(body))
    if m is None or not m.group(2).strip():
        return None
    return m.group(2).strip()


def _is_conditions_heading(title: str) -> bool:
    """True when a normalised heading *title* introduces conditions on the approval."""
    return bool(title) and not _SUPERSEDED_RE.search(title) \
        and not _TECHNICAL_CONDITION_RE.search(title) \
        and _CONDITIONS_HEADING_RE.match(title) is not None


def _has_condition_body(lines: Iterable[str]) -> bool:
    """True when ANY content line under a conditions heading is not a none-value.

    Every line, not only the first (BUG-MSO-2026-0755 NB-08): ``None.`` followed by
    ``However F1 must land first.`` declares a condition. Thematic breaks are not
    content.
    """
    for line in lines:
        stripped = (line or "").strip()
        if not stripped or _HEADING_RE.match(stripped) or _RULE_LINE_RE.match(stripped):
            continue
        text = re.sub(r"^(?:[-+>]|\d+[.)])\s*", "", _plain(stripped)).strip()
        if not text:
            continue
        if _NONE_BODY_RE.match(text) is None:
            return True
    return False


#: Precedence tiers of decision-bearing text, highest first — the cascade's own
#: order. A disagreement only counts at the APPROVED source's tier or above.
_TIER_VERDICT, _TIER_SIGNOFF, _TIER_SUMMARY, _TIER_PREAMBLE = 1, 2, 3, 4
_PREAMBLE_SOURCE = "(document preamble)"


def _block_tier(title: str) -> Optional[int]:
    """The precedence tier of a section *title*, or ``None`` when it decides nothing."""
    if not title or _SUPERSEDED_RE.search(title):
        return None
    if _VERDICT_SECTION_RE.match(title) or re.search(
            r"(?<![A-Za-z])(?:decision|verdict)(?![A-Za-z])", title, re.IGNORECASE):
        return _TIER_VERDICT
    if _DECISION_BEARING_RE.search(title) and not _SUMMARY_SECTION_RE.search(title):
        return _TIER_SIGNOFF
    if _SUMMARY_SECTION_RE.search(title):
        return _TIER_SUMMARY
    return None


def _source_tier(source: str) -> int:
    """The tier the cascade read its verdict from (a heading, or the preamble)."""
    if source == _PREAMBLE_SOURCE:
        return _TIER_PREAMBLE
    m = _HEADING_RE.match((source or "").strip())
    tier = _block_tier(_normalise_heading(_plain(m.group(2)))) if m else None
    return tier if tier is not None else _TIER_PREAMBLE


def _document_disagreement(text: str, max_tier: int = _TIER_PREAMBLE, *,
                           min_tier: int = _TIER_VERDICT,
                           judge: Optional[Callable[[str], Optional[str]]] = None,
                           conditions_headings: bool = True,
                           tier_of: Optional[Callable[[str], Optional[int]]] = None,
                           ) -> Optional[Tuple[str, str, str]]:
    """``(verdict, line, where)`` for the first decision line that disagrees.

    *min_tier*, *judge*, *conditions_headings* and *tier_of* exist for the NB-05
    lower-tier pass (:func:`_lower_tier_contradiction`): the same section walk,
    restricted to the tiers below an approval, judged by
    :func:`_judge_lower_tier_line` and tiered by :func:`_declared_section_tier`.
    The defaults are the document allowlist, unchanged.

    Scans every decision-bearing section AT OR ABOVE *max_tier* (title names a
    decision, verdict, sign-off, signature or is a summary; prior/superseded
    sections excluded) — its heading and its lines, SKIPPING (not stopping at)
    each sub-section whose heading is neither decision-bearing, a declaration nor
    a conditions heading, so descriptive sub-sections (``### Threat Model``,
    ``### Rationale``) are not read but a later ``### Status: APPROVED``
    sub-section's ``**Conditions:**`` still is (QA DEF-028) — plus the document
    preamble when the approval itself came from there. Fenced/indented code is
    already blank in both.

    A conditions HEADING anywhere in the document (``## Conditions``,
    ``### Release Conditions``, ``### Required Actions Before Merge``) whose first
    body line is not a none-value qualifies the approval regardless of tier
    (QA DEF-024): it is the report declaring its conditions by structure.

    Why tiered: the cascade's precedence is the report's declared hierarchy (D3).
    A ``## Security Decision`` APPROVED is not undone by a stale preamble
    ``REJECTED`` from before a re-review, but a summary APPROVED IS undone by a
    verdict section, a sign-off or a sibling decision line that withholds it.
    """
    judge = judge or _judge_decision_line
    tier_of = tier_of or _block_tier
    superseded_at: Optional[int] = None
    for block in _blocks(text):
        if superseded_at is not None and block.level <= superseded_at:
            superseded_at = None
        if superseded_at is None and _SUPERSEDED_RE.search(block.title):
            superseded_at = block.level
        if (conditions_headings and superseded_at is None
                and _is_conditions_heading(block.title)
                and _has_condition_body(block.lines)):
            return Verdict.CONDITIONAL, block.raw_title, block.heading
        tier = tier_of(block.title)
        if tier is None or tier > max_tier or tier < min_tier:
            continue
        verdict = judge(block.raw_title)
        if verdict is not None:
            return verdict, block.raw_title, block.heading
        skip_at: Optional[int] = None
        skipping = False
        for line in block.lines:
            stripped = (line or "").strip()
            heading = _HEADING_RE.match(stripped)
            if heading is not None:
                level = len(heading.group(1))
                if skip_at is not None and level > skip_at:
                    continue  # still inside a superseded sub-section
                skip_at = None
                sub = _plain(heading.group(2))
                sub_title = _normalise_heading(sub)
                if _SUPERSEDED_RE.search(sub_title):
                    skip_at, skipping = level, True
                    continue
                skipping = not (_DECISION_BEARING_RE.search(sub_title)
                                or _DECLARATION_RE.match(sub)
                                or _is_conditions_heading(sub_title))
            if skipping:
                continue
            verdict = judge(stripped)
            if verdict is not None:
                return verdict, stripped, block.heading
    if max_tier >= _TIER_PREAMBLE:
        for line in _preamble(text):
            verdict = judge(line)
            if verdict is not None:
                return verdict, line.strip(), _PREAMBLE_SOURCE
    return None


def _verdict_cascade(text: str) -> Tuple[str, str, str, List[str]]:
    blocks = _blocks(text)
    scan = _VerdictScan()

    for block in blocks:
        if not _VERDICT_SECTION_RE.match(block.title):
            continue
        if ":" in block.title:
            value = block.title.split(":", 1)[1].strip()
            verdict = scan.check(value, block.heading, final=True) if value else None
            if verdict is not None:
                return verdict, value, block.heading, []
        hit = scan.from_declarations(block.lines, block.heading, final=True)
        if hit is not None:
            return hit[0], hit[1], block.heading, []
        hit = _opening_token_line(block.lines, block.heading)
        if hit is not None:
            return hit[0], hit[1], block.heading, []

    for pattern in (_SIGNOFF_SECTION_RE, _SUMMARY_SECTION_RE):
        for block in blocks:
            if not pattern.search(block.title):
                continue
            hit = scan.from_declarations(block.lines, block.heading)
            if hit is not None:
                return hit[0], hit[1], block.heading, []

    hit = scan.from_declarations(_preamble(text), "(document preamble)")
    if hit is not None:
        return hit[0], hit[1], "(document preamble)", []

    notes = ["No readable security verdict — no '## Security Decision' / "
             "'## Verdict' token and no declared status line naming APPROVED, "
             "CONDITIONAL, REJECTED or BLOCKED."]
    if scan.unrecognised is not None:
        value, where = scan.unrecognised
        notes.append(f"Declared status '{_clip(value)}' under '{where}' is not a "
                     "recognised verdict token; not interpreted.")
    return Verdict.UNDETERMINED, "", "", notes


def _clip(text: str, max_len: int = 160) -> str:
    text = " ".join((text or "").split())
    return text if len(text) <= max_len else text[: max_len - 1].rstrip() + "…"


# ---------------------------------------------------------------------------
# Findings written into SEC reports
# ---------------------------------------------------------------------------

def _finding_from_heading(raw_title: str) -> Optional[ReportedFinding]:
    """A :class:`ReportedFinding` from a heading like ``### F1 - MEDIUM: title``.

    Requires a finding id at the start of the heading. The ``FINDING n`` form is
    a finding by its own word; every other id form (``F10``, ``M-2``,
    ``F-0398-01``, ``SEC-0400-06``, ``1.``) must also carry a severity word, so
    ``### TM-5: Attacker forges a webhook signature`` (a threat-model entry) and
    ``### No CRITICAL Issues`` are not findings.

    Severity is read only from a SLOT — a bracketed group, or a separator-
    delimited segment that opens with the word — and only when exactly one
    severity is named there. ``L-1 (was MEDIUM/LOW)`` names two, so its severity
    is ``None`` rather than a pick.
    """
    title = _plain(raw_title)
    m = _FINDING_ID_RE.match(title)
    if m is None:
        return None
    ident = m.group(0).strip().rstrip(".")
    rest = title[m.end():]

    head, tail = _bracket_head(rest)
    groups = _BRACKET_GROUP_RE.findall(head)
    segments = [s.strip() for s in _SEGMENT_SPLIT_RE.split(rest) if s.strip()]
    slots = list(groups) + [s for s in segments if _SEVERITY_SLOT_RE.match(s)]
    named = {w for slot in slots for w in _SEVERITY_RE.findall(slot)}

    if not named and m.group("word") is None:
        return None
    severity = next(iter(named)) if len(named) == 1 else None

    cleaned = _BRACKET_GROUP_RE.sub(
        lambda g: "" if _SEVERITY_RE.search(g.group(1)) else g.group(0), head) + tail
    parts = [s.strip() for s in _SEGMENT_SPLIT_RE.split(cleaned) if s.strip()]
    while parts and _SEVERITY_SLOT_RE.match(parts[0]):
        lead = _SEVERITY_LEAD_RE.match(parts[0])
        if lead:
            parts[0] = lead.group("rest").strip()
            break
        parts.pop(0)
    # Leading hyphens are kept: a title can open with a flag (``--from``).
    finding_title = " — ".join(parts).lstrip(" —–:").rstrip(" -—–:") or None

    cwe = _CWE_RE.search(title)
    return ReportedFinding(id=ident, severity=severity, title=finding_title,
                           cwe=cwe.group(0) if cwe else None)


def _bracket_head(text: str) -> Tuple[str, str]:
    """*text* split just after its last closing bracket: ``(head, tail)``.

    No bracket group can extend past the last closer, so :data:`_BRACKET_GROUP_RE`
    finds exactly the same groups in *head* as in *text* — but in linear time,
    because every opener in *head* has a closer after it.
    """
    cut = max(text.rfind(")"), text.rfind("]")) + 1
    return text[:cut], text[cut:]


def extract_security_findings(text: str) -> List[ReportedFinding]:
    """Findings a SEC report declares in its own headings, in document order.

    Table-only findings (``| Severity | Category | Finding |``) are not read:
    those tables mix counts, summaries and per-finding rows under the same
    header, and a row misread as a finding is a fabricated finding. A report
    whose findings live only in a table therefore shows an empty list, which a
    surface must render as "none extracted", not "none found".
    """
    out: List[ReportedFinding] = []
    seen = set()
    for block in _blocks(text):
        finding = _finding_from_heading(block.raw_title)
        if finding is None or finding.id in seen:
            continue
        seen.add(finding.id)
        out.append(finding)
    return out


def _findings_from_json(items: object) -> List[ReportedFinding]:
    """Findings from a JSON SEC artefact, reading only the scanner's field names.

    Keys are matched against :func:`finding_dict_keys` rather than probed with
    ``hasattr``, so a key naming a method (``to_dict``) cannot shadow it
    (QA DEF-004) and an unknown key is ignored rather than attached.
    """
    out: List[ReportedFinding] = []
    if not isinstance(items, list):
        return out
    allowed = {_camel_to_snake(k) for k in finding_dict_keys()}
    for item in items:
        if not isinstance(item, dict):
            continue
        finding = ReportedFinding()
        for key, value in item.items():
            attr = _camel_to_snake(str(key))
            if attr in allowed:
                setattr(finding, attr, value)
        out.append(finding)
    return out


# ---------------------------------------------------------------------------
# SEC reports
# ---------------------------------------------------------------------------

def _identity_from_name(report_name: str) -> Tuple[str, str]:
    """``(order_id, variant)`` from ``SEC-{ORDER-ID}[-VARIANT].md``.

    ``SEC-BUG-MSO-2026-0409`` is about ``BUG-MSO-2026-0409``; ``SEC-MSO-2026-0182``
    is about the SEC-type order ``SEC-MSO-2026-0182`` itself. One search handles
    both, because the id pattern cannot match at offset 0 of the first.
    """
    stem = Path(report_name or "").stem.upper()
    m = _ORDER_ID_IN_TEXT_RE.search(stem)
    if m is None:
        return "", ""
    return m.group(1), stem[m.end():].strip("-")


def parse_security_report(text: str, order_id: str = "",
                          report_name: str = "") -> SecurityReportSummary:
    """Build a :class:`SecurityReportSummary` from a report's TEXT.

    Pure — no filesystem — and never raises. A ``.json`` SEC artefact (the
    dispatcher's ``SEC_ARTEFACT_MISSING`` gate accepts one) is read by its
    ``secDecision`` / ``decision`` / ``verdict`` / ``status`` field under the same
    token rules as a markdown declaration.
    """
    body = text if isinstance(text, str) else ""
    name_id, variant = _identity_from_name(report_name)
    resolved = (order_id or "").strip() or name_id or extract_order_id(body, report_name)
    summary = SecurityReportSummary(order_id=resolved, report_name=report_name,
                                    variant=variant)
    try:
        if report_name.lower().endswith(".json"):
            _parse_json_into(summary, body)
            summary.verdict_basis = BASIS_JSON
        else:
            verdict, raw, source, notes = extract_security_verdict(body)
            summary.verdict, summary.raw_verdict = verdict, raw
            summary.verdict_source = source
            summary.verdict_basis = (BASIS_FRONT_MATTER if _sec_verdict_field(body) is not None
                                     else BASIS_HEURISTIC)
            summary.parse_notes.extend(notes)
            summary.findings = extract_security_findings(body)
    except Exception as exc:  # pragma: no cover - defensive
        summary.verdict = Verdict.UNDETERMINED
        summary.raw_verdict = summary.verdict_source = summary.verdict_basis = ""
        summary.parse_notes.append(f"Reader error: {_error_text(exc)}")
    return summary


def _error_text(exc: BaseException) -> str:
    """An exception as a parse note, without the absolute path an ``OSError`` carries.

    ``str(OSError)`` is ``[Errno 13] Permission denied: 'C:\\Users\\<name>\\…'`` —
    the device's user name and layout — and parse notes are served ungated by the
    Hub (BUG-MSO-2026-0756, SEC-0735-02). Its ``strerror`` is the useful part.
    """
    if isinstance(exc, OSError):
        return f"{type(exc).__name__}: {exc.strerror or 'operating-system error'}"
    return f"{type(exc).__name__}: {exc}"


def _parse_json_into(summary: SecurityReportSummary, body: str) -> None:
    try:
        data = json.loads(body)
    except ValueError as exc:
        summary.parse_notes.append(f"SEC artefact is not valid JSON: {exc}")
        return
    if not isinstance(data, dict):
        summary.parse_notes.append("SEC artefact JSON is not an object.")
        return
    for key in _JSON_TOP_LEVEL_KEYS:
        value = data.get(key)
        container: Dict[str, object] = data
        nested_key: Optional[str] = None
        if isinstance(value, dict) and value:
            nested_key = next((k for k in _JSON_DECISION_KEYS
                               if isinstance(value.get(k), str) and value[k].strip()), None)
            if nested_key is not None:
                container, value = value, value[nested_key]
        if value is None or value in ("", [], {}):
            continue
        if not isinstance(value, str):
            # A non-empty decision field this reader cannot read (a list, a dict
            # with no status/decision/verdict string) still DECLARED something;
            # a lower field's APPROVED must not override it (QA DEF-023).
            summary.parse_notes.append(
                f"JSON '{key}' is a {type(value).__name__} with no readable decision "
                f"('{_clip(json.dumps(value, default=str))}'); not interpreted, and no "
                "lower-precedence field was consulted.")
            break
        if not value.strip():
            continue
        verdict = _opening_verdict(value, allow_aliases=True)
        if verdict == Verdict.APPROVED:
            # Every decision field of the decision object must itself approve
            # (QA DEF-029): {"status": "APPROVED", "verdict": "REJECTED"} decides nothing.
            # So must a TOP-LEVEL sibling (NB-10) — {"secDecision": "APPROVED",
            # "decision": "FAIL"} — and an "approved": false anywhere near it (NB-04).
            if nested_key is not None:
                where = f"{key}.{nested_key}"
                clash = _json_sibling_disagreement(container, nested_key)
                clash_where = f"{key}.{clash[0]}" if clash is not None else ""
            else:
                where = key
                clash = _json_sibling_disagreement(data, key, _JSON_TOP_LEVEL_KEYS, strict=False)
                clash_where = clash[0] if clash is not None else ""
            if clash is None:
                withheld = (_json_approval_withheld(container, f"{key}.")
                            if nested_key is not None else None) \
                    or _json_approval_withheld(data, "")
                if withheld is not None:
                    clash_where, clash = withheld[0], withheld
            if clash is not None:
                _sib_key, sib_value, sib_verdict = clash
                if sib_verdict != Verdict.CONDITIONAL:
                    summary.parse_notes.append(
                        f"JSON '{where}' reads APPROVED but '{clash_where}' "
                        f"declares '{_clip(json.dumps(sib_value, default=str))}'; read as "
                        "UNDETERMINED and no lower-precedence field was consulted.")
                    break
                verdict = Verdict.CONDITIONAL
                summary.parse_notes.append(
                    f"JSON '{where}' reads APPROVED but '{clash_where}' "
                    f"declares '{_clip(str(sib_value))}'; read as CONDITIONAL.")
        if verdict is not None:
            conditions = _json_conditions(container) or _json_conditions(data)
            if verdict == Verdict.APPROVED and conditions is not None:
                verdict = Verdict.CONDITIONAL
                summary.parse_notes.append(
                    f"JSON '{key}' reads APPROVED but the artefact declares conditions "
                    f"('{_clip(json.dumps(conditions, default=str))}'); read as CONDITIONAL.")
            summary.verdict, summary.raw_verdict = verdict, value.strip()
            summary.verdict_source = f"(json: {key})"
            break
        reason = _undecided_reason(value)
        if reason is not None:
            # A denial in a higher-precedence field ends the read (QA DEF-008).
            summary.parse_notes.append(
                f"JSON '{key}' value '{_clip(value)}' {reason}; read as UNDETERMINED "
                "and no lower-precedence field was consulted.")
            break
        # A declared non-verdict ("PENDING") ends the read too: a lower field's
        # APPROVED would be a stale approval overriding it (QA DEF-016).
        summary.parse_notes.append(
            f"JSON '{key}' value '{_clip(value)}' is not a recognised verdict token; "
            "not interpreted, and no lower-precedence field was consulted.")
        break
    if summary.verdict == Verdict.UNDETERMINED and not summary.parse_notes:
        summary.parse_notes.append("SEC artefact JSON declares no decision field.")
    summary.findings = _findings_from_json(data.get("findings"))


_JSON_DECISION_KEYS = ("status", "decision", "verdict")
_JSON_TOP_LEVEL_KEYS = ("secDecision", "decision", "verdict", "status")
#: Keys holding conditions on an approval, compared by :func:`_json_key` so case,
#: ``_`` and ``-`` do not matter — ``Conditions``, ``required_actions`` and
#: ``requiredActions`` are the same key (BUG-MSO-2026-0755 NB-04).
_JSON_CONDITION_KEYS = frozenset((
    "conditions", "condition", "caveats", "caveat", "reservations", "reservation",
    "requiredactions", "requiredaction", "blockers", "blocker", "openitems", "openitem"))


def _json_key(key: object) -> str:
    """*key* lower-cased with every non-alphanumeric character removed."""
    return "".join(ch for ch in str(key).lower() if ch.isalnum())


def _json_sibling_disagreement(container: Dict[str, object], chosen: str,
                               keys: Sequence[str] = _JSON_DECISION_KEYS,
                               strict: bool = True) -> Optional[Tuple[str, object, str]]:
    """``(key, value, verdict)`` for the first OTHER decision field of *container*
    that does not read APPROVED — ``CONDITIONAL`` or ``UNDETERMINED`` — else ``None``.

    *strict* (a decision object's own fields): any non-approving value disagrees,
    and so does a value that is not a string. Not *strict* (an artefact's top-level
    fields, NB-10): a top-level ``status`` is as often the ORDER's (``COMPLETE``) as
    the review's, so a string disagrees only when it opens with a verdict that is
    not an approval, decides a denial or names a disagreement (``PENDING``); a
    nested object is read by its own decision field; any other value is ignored.
    """
    for sib_key in keys:
        if sib_key == chosen:
            continue
        sib = container.get(sib_key)
        if sib is None or sib in ("", [], {}):
            continue
        if not strict and isinstance(sib, dict):
            text = next((sib[k] for k in _JSON_DECISION_KEYS
                         if isinstance(sib.get(k), str) and sib[k].strip()), None)
        elif isinstance(sib, str):
            text = sib
        elif strict:
            return sib_key, sib, Verdict.UNDETERMINED
        else:
            continue
        if text is None or not text.strip():
            continue
        got = _opening_verdict(text, allow_aliases=True)
        if got == Verdict.APPROVED:
            continue
        if got == Verdict.CONDITIONAL:
            return sib_key, sib, Verdict.CONDITIONAL
        if (strict or got is not None or _undecided_reason(text) is not None
                or _is_decided_denial(text, declaration=True)
                or _DISAGREEMENT_RE.search(text) is not None):
            return sib_key, sib, Verdict.UNDETERMINED
    return None


def _json_approval_withheld(obj: Dict[str, object], prefix: str
                            ) -> Optional[Tuple[str, object, str]]:
    """``(path, value, UNDETERMINED)`` for an ``approved`` field that says false (NB-04)."""
    for key, value in obj.items():
        if _json_key(key) != "approved":
            continue
        if value is False or (isinstance(value, str)
                              and value.strip().lower() in ("false", "no")):
            return f"{prefix}{key}", value, Verdict.UNDETERMINED
    return None


def _json_conditions(obj: Dict[str, object]) -> Optional[object]:
    """A non-empty condition-shaped value (see :data:`_JSON_CONDITION_KEYS`), or ``None``.

    ``false``, ``0``, an empty string/list/object and a none-value string
    (``"None"``, ``"N/A"``) declare no conditions.
    """
    for key, value in obj.items():
        if _json_key(key) not in _JSON_CONDITION_KEYS:
            continue
        if value is None or value is False or value in ("", [], {}):
            continue
        if isinstance(value, (int, float)) and not isinstance(value, bool) and value == 0:
            continue
        if isinstance(value, str) and _NONE_VALUE_RE.match(value.strip()):
            continue
        return value
    return None


def _is_sec_report(path: Path) -> bool:
    return path.name.upper().startswith(_SEC_PREFIX) and path.suffix.lower() in (".md", ".json")


def _is_scanner_run(path: Path) -> bool:
    return path.name.upper().startswith(_REVIEW_PREFIX) and path.suffix.lower() == ".md"


def _iso_mtime(path: Path) -> str:
    try:
        return datetime.fromtimestamp(path.stat().st_mtime, tz=timezone.utc).isoformat()
    except OSError:
        return ""


def _rel(mso: Path, path: Path) -> str:
    try:
        return path.relative_to(mso).as_posix()
    except ValueError:
        return path.name


def _summarise_sec_path(mso: Path, path: Path, order_id: str = "") -> SecurityReportSummary:
    try:
        text, size, truncated = _read_bounded(path)
    except OSError as exc:
        name_id, variant = _identity_from_name(path.name)
        summary = SecurityReportSummary(order_id=order_id or name_id,
                                        report_name=path.name, variant=variant)
        summary.report_rel = _rel(mso, path)
        summary.parse_notes.append(
            f"Report could not be read: {_error_text(exc)} ({summary.report_rel})")
        return summary
    summary = parse_security_report(text, order_id=order_id, report_name=path.name)
    summary.size, summary.truncated = size, truncated
    if truncated:
        summary.parse_notes.append(
            f"Report exceeds {MAX_ARTEFACT_BYTES} bytes and was read truncated; "
            "sections past the cap were not parsed.")
    summary.report_rel = _rel(mso, path)
    summary.modified = _iso_mtime(path)
    return summary


def read_security_reports(mso: Path, order_id: str) -> List[SecurityReportSummary]:
    """Every SEC document for *order_id* — canonical first, then variants by name.

    An order can carry several (``SEC-X.md``, ``SEC-X-LEAD-INDEPENDENT.md``,
    ``SEC-X-RETRY.md``) and they can disagree. All are returned, each with its
    own verdict and ``variant``; this function never picks a winner. An empty
    list means no SEC document exists. Never raises.
    """
    try:
        mso_path = Path(mso)
        paths = discover_report_paths(mso_path, order_id, kinds=("security",))
    except Exception:
        return []
    wanted = (order_id or "").strip().upper()
    matched = [p for _kind, _name, p in paths
               if p.is_file() and _is_sec_report(p)
               and _identity_from_name(p.name)[0] == wanted]
    matched.sort(key=lambda p: (_identity_from_name(p.name)[1] != "",
                                p.suffix.lower() != ".md", p.name))
    return [_summarise_sec_path(mso_path, p, wanted) for p in matched]


def read_security_report(mso: Path, order_id: str) -> Optional[SecurityReportSummary]:
    """The canonical ``SEC-{ORDER-ID}`` record, or ``None`` if the order has none.

    Falls back to the first variant only when no canonical file exists, and the
    returned record's ``variant`` says so. Callers that must show disagreement
    between documents use :func:`read_security_reports`.
    """
    reports = read_security_reports(mso, order_id)
    return reports[0] if reports else None


def list_security_reports(mso: Path, limit: Optional[int] = None,
                          ) -> Tuple[List[SecurityReportSummary], ParseCoverage]:
    """Every SEC document in the workspace, newest first, with parse coverage.

    ``REVIEW-*`` runs and one-off documents are NOT included and are NOT counted
    in the coverage — they are not per-order verdicts (plan §1.4).
    """
    mso_path = Path(mso)
    coverage = ParseCoverage()
    try:
        paths = [p for p in iter_report_paths(mso_path, "security") if _is_sec_report(p)]
    except Exception:
        return [], coverage
    try:
        paths.sort(key=lambda p: (-p.stat().st_mtime, p.name))
    except OSError:
        paths.sort(key=lambda p: p.name)
    if limit is not None and limit >= 0:
        paths = paths[:limit]
    out: List[SecurityReportSummary] = []
    for path in paths:
        summary = _summarise_sec_path(mso_path, path)
        out.append(summary)
        coverage.add(summary.decided)
    return out, coverage


def list_other_security_documents(mso: Path) -> List[str]:
    """Names under ``reports/security/`` that are neither SEC reports nor scanner runs.

    ``SECURITY-AUDIT-2026-07-08.md``, ``THREAT-MODEL-V6.md``: one-off documents a
    surface may LINK. They are not parsed, because there is no shape to parse.
    """
    try:
        paths = iter_report_paths(Path(mso), "security")
    except Exception:
        return []
    return [p.name for p in paths if not _is_sec_report(p) and not _is_scanner_run(p)]


# ---------------------------------------------------------------------------
# Scanner runs
# ---------------------------------------------------------------------------

def _scanner_findings(lines: Sequence[str], workspace_root: Optional[Path]
                      ) -> List[ReportedFinding]:
    findings: List[ReportedFinding] = []
    current: Optional[ReportedFinding] = None
    for raw in lines:
        line = raw.strip()
        head = _SCANNER_FINDING_HEAD_RE.match(line)
        if head:
            current = ReportedFinding(id=head.group(1),
                                      severity=head.group(2) if head.group(2) in _SEVERITIES else None,
                                      title=head.group(3).strip() or None)
            findings.append(current)
            continue
        if current is None:
            continue
        if line.startswith("## "):
            current = None
            continue
        bullet = _SCANNER_BULLET_RE.match(line)
        if not bullet:
            continue
        label, value = bullet.group(1).strip().lower(), bullet.group(2).strip()
        if label == "category":
            cwe = _CWE_RE.search(value)
            current.cwe = cwe.group(0) if cwe else (value or None)
        elif label == "location":
            _apply_location(current, value.strip("`"), workspace_root)
        elif label == "evidence":
            current.snippet = _strip_code_span(value)
        elif label == "remediation":
            current.remediation = value or None
    return findings


def _strip_code_span(value: str) -> str:
    text = value.strip()
    if len(text) >= 2 and text.startswith("`") and text.endswith("`"):
        return text[1:-1]
    return text


def _apply_location(finding: ReportedFinding, location: str,
                    workspace_root: Optional[Path]) -> None:
    file_part, _, line_part = location.rpartition(":")
    if file_part and line_part.isdigit():
        finding.file, finding.line = file_part, int(line_part)
    else:
        finding.file = location or None
    if finding.file and workspace_root is not None:
        finding.file = _relative_to_root(finding.file, workspace_root)


def _relative_to_root(file_text: str, root: Path) -> str:
    """A scanner location relative to the workspace root when it lies under it.

    The scanner writes absolute paths. Relativising keeps a device's filesystem
    layout off a wire response where that is possible; a path outside the root
    is left exactly as written rather than rewritten into something it is not.
    """
    try:
        candidate = PureWindowsPath(file_text) if "\\" in file_text else Path(file_text)
        root_norm = PureWindowsPath(str(root)) if "\\" in file_text else root
        rel = candidate.relative_to(root_norm)
        return rel.as_posix()
    except (ValueError, TypeError):
        return file_text


def _path_segments(file_text: str) -> List[str]:
    return [s.lower() for s in re.split(r"[\\/]+", file_text or "") if s]


def _trust_signatures(findings: Sequence[ReportedFinding]) -> List[str]:
    """Known false-positive signatures present in a run's own listed findings.

    Each returns one sentence naming a concrete example from the file, so the
    judgement is auditable against the report rather than asserted.
    """
    reasons: List[str] = []
    total = len(findings)

    ellipsis = [f for f in findings
                if (f.cwe == "CWE-22" or "path traversal" in (f.title or "").lower())
                and "..." in (f.snippet or "")
                and not _PATH_TRAVERSAL_REAL_RE.search(f.snippet or "")]
    if ellipsis:
        ex = ellipsis[0]
        reasons.append(
            f"{len(ellipsis)} of {total} examined findings are path-traversal hits "
            "on a literal '...' with no '../' or '..\\' — an ellipsis, not a path "
            f"(e.g. #{ex.id} at {ex.file}:{ex.line} on {_clip(ex.snippet or '', 80)!r})."
        )

    from maestro.workspace import MSO_DIR_NAME

    plane = [f for f in findings if MSO_DIR_NAME in _path_segments(f.file or "")]
    if plane:
        ex = plane[0]
        reasons.append(
            f"{len(plane)} of {total} examined findings are inside the Maestro "
            "artefact plane (.mso/), including crew worktree copies of the same "
            f"source — the scan counted the fleet's own bookkeeping (e.g. #{ex.id} "
            f"at {ex.file})."
        )

    # Evidence is part of the key: two different matches on one line are two
    # findings, not one counted twice (QA DEF-006).
    keyed: Dict[Tuple[str, Optional[int], str, str], List[str]] = {}
    for f in findings:
        if f.file:
            keyed.setdefault((f.file, f.line, f.title or "", f.snippet or ""),
                             []).append(f.id or "?")
    dupes = [ids for ids in keyed.values() if len(ids) > 1]
    if dupes:
        extra = sum(len(ids) - 1 for ids in dupes)
        reasons.append(
            f"{extra} of {total} examined findings repeat an identical file, line, "
            f"title and evidence already listed (e.g. #{', #'.join(dupes[0][:3])}) — one "
            "match is counted more than once."
        )
    return reasons


def parse_scanner_run(text: str, run_id: str = "", report_name: str = "",
                      workspace_root: Optional[Path] = None) -> ScannerRun:
    """Build a :class:`ScannerRun` from a ``REVIEW-*.md`` file's TEXT.

    Pure and never raises. Counts come from the ``## Scan Summary`` table only; a
    severity row that is absent stays absent from ``counts_by_severity`` (never
    filled with ``0``). ``counts_trustworthy`` is always ``False``.
    """
    body = text if isinstance(text, str) else ""
    stem = Path(report_name).stem if report_name else ""
    run = ScannerRun(run_id=run_id or stem, report_name=report_name,
                     caveat=_BASE_SCANNER_CAVEAT)
    try:
        _fill_scanner_run(run, body, workspace_root)
    except Exception as exc:  # pragma: no cover - defensive
        run.parse_notes.append(f"Reader error: {_error_text(exc)}")
    run.counts_trustworthy = False
    return run


def _fill_scanner_run(run: ScannerRun, body: str, workspace_root: Optional[Path]) -> None:
    lines = body.splitlines()
    for line in lines[:20]:
        m = _SCANNER_HEADER_RE.match(line.strip())
        if not m:
            continue
        label, value = m.group(1).strip().lower(), m.group(2).strip()
        if label == "generated":
            run.ran_at = value
        elif label == "files scanned":
            run.files_scanned = int(value) if value.isdigit() else None
        elif label == "diff target":
            run.diff_target = value.strip("`")
    if not run.ran_at:
        ts = _REVIEW_STEM_TS_RE.search(run.run_id or "")
        if ts:
            run.ran_at = datetime.strptime(ts.group(1), "%Y%m%dT%H%M%SZ").replace(
                tzinfo=timezone.utc).isoformat()
            run.parse_notes.append("No '**Generated**' line; run time taken from the "
                                   "timestamp in the report name.")
    if run.files_scanned is None:
        run.parse_notes.append("No readable '**Files scanned**' figure.")

    blocks = _blocks(body)
    summary = next((b for b in blocks if b.title.lower() == "scan summary"), None)
    if summary is not None:
        for table in _tables(summary.lines):
            header = _canonical_header(table[0], _SCAN_SUMMARY_COLUMNS) if table else {}
            if "severity" not in header or "count" not in header:
                continue
            for cells in table[1:]:
                sev = _cell(cells, header["severity"]).upper()
                count = _cell(cells, header["count"])
                if sev in _SEVERITIES and count.isdigit():
                    run.counts_by_severity[sev] = int(count)
            break
    if not run.counts_by_severity:
        run.parse_notes.append("No '## Scan Summary' severity/count table could be read; "
                               "counts are absent, not zero.")

    decision = next((b for b in blocks if _VERDICT_SECTION_RE.match(b.title)), None)
    if decision is not None:
        for _label, value in _declarations(decision.lines):
            verdict = _opening_verdict(value, allow_aliases=False)
            if verdict is not None:
                run.scanner_decision = verdict
                break

    findings = _scanner_findings(lines, workspace_root)
    run.sample_findings = findings[:SCANNER_SAMPLE_LIMIT]
    run.untrusted_reasons = _trust_signatures(findings)
    if run.untrusted_reasons:
        run.trust = ScannerTrust.KNOWN_UNTRUSTED
        run.caveat = (_BASE_SCANNER_CAVEAT + " This run's own findings carry known "
                      "false-positive signatures; its counts overstate risk.")
    listed_total = sum(run.counts_by_severity.values()) if run.counts_by_severity else None
    if listed_total is not None and len(findings) < listed_total:
        run.parse_notes.append(
            f"Trust signatures were checked over {len(findings)} of {listed_total} "
            "listed findings (the rest lie past the read cap or were not parseable).")


def _cell(cells: Sequence[str], idx: int) -> str:
    return (cells[idx] if idx < len(cells) else "").strip()


def _summarise_run_path(mso: Path, path: Path) -> ScannerRun:
    try:
        text, size, truncated = _read_bounded(path)
    except OSError as exc:
        run = ScannerRun(run_id=path.stem, report_name=path.name,
                         caveat=_BASE_SCANNER_CAVEAT)
        run.report_rel = _rel(mso, path)
        run.parse_notes.append(
            f"Report could not be read: {_error_text(exc)} ({run.report_rel})")
        return run
    run = parse_scanner_run(text, report_name=path.name, workspace_root=mso.parent)
    run.size, run.truncated = size, truncated
    if truncated:
        run.parse_notes.append(
            f"Report exceeds {MAX_ARTEFACT_BYTES} bytes and was read truncated.")
    run.report_rel = _rel(mso, path)
    run.modified = _iso_mtime(path)
    return run


def list_scanner_runs(mso: Path, limit: Optional[int] = None) -> List[ScannerRun]:
    """Every ``REVIEW-*.md`` scanner run, newest first by the run's own timestamp.

    Returns RUNS. There is intentionally no aggregate — no fleet-wide severity
    total, no latest-run posture — because every count here is known to be
    unreliable, and an aggregate would launder that into a headline. Never raises.
    """
    mso_path = Path(mso)
    try:
        paths = [p for p in iter_report_paths(mso_path, "security") if _is_scanner_run(p)]
    except Exception:
        return []
    paths.sort(key=lambda p: p.name, reverse=True)
    if limit is not None and limit >= 0:
        paths = paths[:limit]
    return [_summarise_run_path(mso_path, p) for p in paths]
