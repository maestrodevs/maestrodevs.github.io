# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""``maestro.reports`` — the report record core (PLAN-PLN-MSO-2026-0726).

**One core model, many surfaces.** This package computes what the fleet
*verified*, from artefacts already on disk, and hands the same record to every
surface that needs it: the Hub's ``/api/v1/reports/*`` routes (Order A2), the
CLI, and FTR-MSO-2026-0502's voyage-PR-body generator. Following
FTR-MSO-2026-0700's shape is not a stylistic choice — the alternative, measured
in the plan, is two QA parsers that drift until the PR body and the Hub disagree
about whether an order passed.

**Two hard rules, both mechanically tested:**

1. **No web framework, ever.** No FastAPI, no Pydantic, anywhere under this
   package. The Hub owns its wire shape in ``maestro/hub/models.py`` and adapts
   to these dataclasses; the moment a Pydantic model appears here, the CLI and
   the PR-body generator inherit a web dependency and the property is gone.
   ``tests/test_ftr_0728_reports_core.py`` asserts this over the package source.
2. **No new filesystem walker.** Report discovery is
   :mod:`maestro.hub.artefacts`'s job and stays there — its stem-contains rule
   already handles both the ``QA-{id}.md`` and ``{id}.md`` naming forms in live
   use, and a second walker would find a different set of files.

**The honesty rule (plan §7) is enforced at this layer.** Every reader returns
an explicit ``UNDETERMINED`` / ``NOT RECORDED`` rather than an optimistic
default, absent counts are ``None`` rather than ``0``, and what could not be
parsed is recorded on the record's ``parse_notes`` so a surface can caveat
instead of presenting a partial read as a complete one.

**Boundary with FTR-MSO-2026-0700's ``Blockage``** (plan §6): 0700 answers *why
is this order stuck*; this package answers *what did the fleet verify*. Neither
computes the other.

Delivered so far — Order A1: :mod:`maestro.reports.models` (every record shape,
including the ones B1/B3/B5 populate) and :mod:`maestro.reports.qa_reader`;
Order B1 (FTR-MSO-2026-0733): :mod:`maestro.reports.ac_reader`;
Order B3 (FTR-MSO-2026-0735): :mod:`maestro.reports.security_reader` — per-order
SEC verdicts and scanner runs as two separate models that are never merged into
one figure; Order B5 (FTR-MSO-2026-0737): :mod:`maestro.reports.voyage_reader` —
the voyage report composed on read from the manifest, the member orders' QA / AC
/ SEC records and the usage aggregator, with no producer artefact (D2).
"""

from __future__ import annotations

from maestro.reports.models import (
    ACBucket,
    ACConflict,
    ACCoverage,
    ACCriterionRow,
    ACOrderRollup,
    ACStatus,
    ParseCoverage,
    Provenance,
    QAReportSummary,
    ReportedFinding,
    ScannerRun,
    ScannerTrust,
    SecurityReportSummary,
    TestCategoryCounts,
    TestCounts,
    Verdict,
    VoyageReportSummary,
)
from maestro.reports.qa_reader import list_qa_reports, parse_qa_report, read_qa_report
from maestro.reports.ac_reader import build_ac_rollup, list_ac_rollups, read_order_ac
from maestro.reports.security_reader import (
    list_scanner_runs,
    list_security_reports,
    read_security_report,
    read_security_reports,
)
from maestro.reports.voyage_reader import list_voyage_reports, read_voyage_report

__all__ = [
    "ACBucket",
    "ACConflict",
    "ACCoverage",
    "ACCriterionRow",
    "ACOrderRollup",
    "ACStatus",
    "ParseCoverage",
    "Provenance",
    "QAReportSummary",
    "ReportedFinding",
    "ScannerRun",
    "ScannerTrust",
    "SecurityReportSummary",
    "TestCategoryCounts",
    "TestCounts",
    "Verdict",
    "VoyageReportSummary",
    "build_ac_rollup",
    "list_ac_rollups",
    "list_qa_reports",
    "list_scanner_runs",
    "list_security_reports",
    "list_voyage_reports",
    "parse_qa_report",
    "read_order_ac",
    "read_qa_report",
    "read_security_report",
    "read_security_reports",
    "read_voyage_report",
]
