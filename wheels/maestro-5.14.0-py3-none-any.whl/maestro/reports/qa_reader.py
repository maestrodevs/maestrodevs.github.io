# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Tolerant reader for ``reports/qa/*.md`` (FTR-MSO-2026-0728 — PLAN §5, Order A1).

**Why heading parsing and not front-matter (Captain decision D3).** The audit
this work came from concluded QA reports were "not reliably machine-readable"
because ``nodeVerdict:`` front-matter appears in 6 of 275 files. That yardstick
is wrong twice over: ``nodeVerdict`` is a *routing token with a lifecycle* —
``chart_routing._rewrite_verdict_consumed()`` rewrites ``FAIL`` to ``CONSUMED``
in place the moment routing acts on it — and the headings are the contract that
actually holds. Measured over the live plane at build time:

===============================================  =====  ======================
Heading                                          Files  Yield
===============================================  =====  ======================
``## Order Reference``                             269  identity
``## Test Summary``                                264  counts
``## QA Decision``                                 265  264 yield a verdict
``## Acceptance Criteria Verification``            265  a pipe table in each
``## Defects Found``                               260  112 carry a table
``## Tester Sign-off``                             266  —
===============================================  =====  ======================

So a tolerant heading parser is ~96% covered on day one, where a front-matter
mandate would start at 6 files. The mandate is still worth having *going
forward* (Order B6) — it is simply not a prerequisite, and this reader treats
front-matter strictly as a corroborating hint.

**Everything here is parsed BY COLUMN NAME, never positionally.** The AC table
has 6 canonical header families and a long tail of 30-odd parenthetical
variations (``| ID | Criterion (abridged) | Validation | Status |``, ``| # |
Criterion | Type | Status |``, ``| ID | Description | Result | Evidence |``);
the defect table has 21 observed headers, of which several — ``| ID | Severity |
Description | Location |``, ``| ID | Severity | Blocking | Description | File |``
— a positional reader gets *wrong* rather than merely incomplete (the last one
would read the blocking flag as the defect summary). Column-name keying with a
synonym map handles the whole census.

**How the honesty rule (plan §7) is enforced here.** Three mechanical rules,
each with a negative test:

1. No path returns a verdict it did not read from the file. Every failure to
   parse ends at :data:`~maestro.reports.models.Verdict.UNDETERMINED`; there is
   no default and no optimistic fallback.
2. A count that is absent is ``None``, never ``0`` — "no parseable test table"
   and "zero tests ran" are different claims.
3. What could not be read is recorded on
   :attr:`~maestro.reports.models.QAReportSummary.parse_notes`, so a surface can
   caveat rather than present a partial read as a whole one.

Discovery goes through :mod:`maestro.hub.artefacts` — this module contains no
filesystem walker of its own (plan §4).
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

from maestro.hub.artefacts import (
    MAX_ARTEFACT_BYTES,
    discover_report_paths,
    iter_report_paths,
)

# ``_strip_md`` is imported rather than copied ON PURPOSE. The AC table and the
# defect table are cells of the same markdown, and if the two were stripped by
# two different implementations they would eventually disagree about a cell
# like ``**PASS**`` or `` `file.py` ``. Reusing role_rejection's makes that
# impossible. It is private, which is the honest cost: a rename upstream breaks
# the import loudly at collection time rather than silently changing behaviour.
from maestro.core.role_rejection import _strip_md, parse_defects
from maestro.reports.models import (
    ACCriterionRow,
    ACStatus,
    ParseCoverage,
    Provenance,
    QAReportSummary,
    TestCategoryCounts,
    TestCounts,
    Verdict,
)

__all__ = [
    "extract_order_id",
    "extract_verdict",
    "list_qa_reports",
    "node_verdict_hint",
    "parse_ac_table",
    "parse_qa_report",
    "parse_report_defects",
    "parse_test_summary",
    "read_qa_report",
]


_HEADING_RE = re.compile(r"^(#{1,6})\s+(.*)$")

# A heading title's leading ordinal, as reports actually write it: ``## 8. QA
# Decision``, ``## 4) Acceptance Criteria``, ``## Phase 2 — Test Summary``.
# Stripped before matching, because the section is the same section whether or
# not its author numbered it (QA-BUG-MSO-2026-0691 numbers every heading, and
# would otherwise read as having no QA Decision at all).
_ORDINAL_PREFIX_RE = re.compile(
    r"^(?:phase\s+)?\d+(?:\.\d+)*\s*[.)\-—:]?\s+", re.IGNORECASE
)

_SEPARATOR_CELL_RE = re.compile(r"^:?-{2,}:?$")

# An explicit self-declared verdict line: ``**Status:** APPROVED``,
# ``**Status: CONDITIONAL**``, ``Verdict: PASS``, ``**Decision**: REJECTED``.
_DECLARATION_RE = re.compile(
    r"^\**\s*(status|decision|verdict|result|qa\s+decision|qa\s+verdict)"
    r"\s*\**\s*:\s*(.+)$",
    re.IGNORECASE,
)

# The same labels, as a whole-string match for a table key cell / heading title.
_DECLARATION_LABEL_RE = re.compile(
    r"^(status|decision|verdict|result|qa\s+decision|qa\s+verdict)$", re.IGNORECASE
)
# Heading-borne declarations exclude ``result`` — see :func:`_heading_declaration`.
_HEADING_DECLARATION_RE = re.compile(
    r"^\**\s*(status|decision|verdict|qa\s+decision|qa\s+verdict)"
    r"\s*\**\s*:\s*(.+)$",
    re.IGNORECASE,
)

_DIGIT_RE = re.compile(r"\d")

_VERDICT_TOKEN_RE = re.compile(
    r"\b(" + "|".join(Verdict.DECIDED) + r")\b", re.IGNORECASE
)
_VERDICT_ALIAS_RE = re.compile(
    r"\b(" + "|".join(sorted(Verdict.ALIASES, key=len, reverse=True)) + r")\b",
    re.IGNORECASE,
)

# Heading families that can carry a verdict, most specific first. The first two
# tiers differ in how much they are trusted — see :func:`extract_verdict`.
_VERDICT_SECTION_PATTERNS: Tuple[str, ...] = (
    r"^qa\s+decision$",
    r"^qa\s+verdict$",
    r"^(?:final\s+)?decision$",
    r"^(?:final\s+)?verdict$",
    r"^qa\s+(?:decision|verdict)\b",
    r"^decision\b",
    r"^verdict\b",
)
_SIGNOFF_SECTION_PATTERNS: Tuple[str, ...] = (
    r"sign-?off$",
    r"^conclusion",
    r"^summary$",
)

_AC_SECTION_RE = re.compile(r"acceptance\s+criteri", re.IGNORECASE)
_DEFECTS_SECTION_RE = re.compile(r"^defects?\b|^defects?\s+found\b", re.IGNORECASE)
_TEST_SUMMARY_SECTION_RE = re.compile(r"^test\s+summary\b|^test\s+results?\b",
                                       re.IGNORECASE)
_ORDER_REF_SECTION_RE = re.compile(r"^order\s+reference\b", re.IGNORECASE)

_ORDER_ID_IN_TEXT_RE = re.compile(
    r"\b((?:FTR|BUG|SEC|INV|PLN|DOC|TST|REL|NAV|VOY|CHT)-[A-Z]{2,5}-\d{4}-\d{4})\b"
)
_ORDER_ID_LINE_RE = re.compile(
    r"^[-*\s]*\**\s*order\s*id\s*\**\s*:\s*\**\s*([A-Za-z0-9\-]+)", re.IGNORECASE
)

_INT_RE = re.compile(r"-?\d+")


# ---------------------------------------------------------------------------
# Column-name synonym maps
# ---------------------------------------------------------------------------

# Every observed AC-table header name, mapped to the role it plays. Built from
# a census of the live plane rather than guessed; an unmapped name is simply
# ignored (an extra column never displaces a mapped one).
_AC_COLUMNS: Dict[str, str] = {
    "id": "id", "#": "id", "no": "id", "no.": "id", "num": "id",
    "ac": "id", "ac id": "id", "ac#": "id", "criterion id": "id", "item": "id",
    "criterion": "criterion", "criteria": "criterion",
    "acceptance criterion": "criterion", "acceptance criteria": "criterion",
    "description": "criterion", "requirement": "criterion",
    "status": "status", "result": "status", "outcome": "status",
    "verdict": "status", "assessment": "status",
    "validation": "validation", "validation type": "validation",
    "validationtype": "validation", "type": "validation", "method": "validation",
    "how verified": "validation", "evidence verified": "validation",
    "verification": "validation",
    "notes": "notes", "note": "notes", "comment": "notes", "comments": "notes",
    "evidence": "evidence", "tested by": "evidence", "proof": "evidence",
    "test": "evidence", "test evidence": "evidence",
}

# Defect-table header names. ``blocking`` is mapped and then applied by
# :func:`parse_report_defects` as an OVERRIDE — see that function's docstring
# for why folding it into the severity cell would be wrong.
_DEFECT_COLUMNS: Dict[str, str] = {
    "id": "id", "#": "id", "item": "id", "defect": "id", "defect id": "id",
    "cluster": "id", "no": "id", "no.": "id",
    "severity": "severity", "sev": "severity", "priority": "severity",
    "description": "description", "summary": "description", "issue": "description",
    "detail": "description", "details": "description", "finding": "description",
    "classification": "description", "root cause": "description",
    "observation": "description", "problem": "description", "note": "description",
    "file": "file", "files": "file", "location": "file", "where": "file",
    "path": "file", "file(s)": "file", "module": "file",
    "line": "line", "lines": "line", "line(s)": "line",
    "blocking": "blocking", "blocking?": "blocking", "blocks": "blocking",
    "blocks this order?": "blocking", "blocking (y/n)": "blocking",
}

_TEST_COLUMNS: Dict[str, str] = {
    "tests": "tests", "test": "tests", "total": "tests", "count": "tests",
    "passed": "passed", "pass": "passed", "passing": "passed",
    "failed": "failed", "fail": "failed", "failing": "failed", "failures": "failed",
}

_YES = ("YES", "Y", "TRUE", "BLOCKING", "BLOCKER")
_NO = ("NO", "N", "FALSE", "NON-BLOCKING", "NONBLOCKING", "NOT BLOCKING", "-", "")


# ---------------------------------------------------------------------------
# Section splitting
# ---------------------------------------------------------------------------

class _Section:
    """One markdown heading and the lines beneath it.

    A section ends at the next heading of the SAME OR SHALLOWER level, so a
    ``## Test Summary`` keeps its ``### Unit Tests`` subsections (which is where
    every count actually lives) while a ``## QA Decision`` still ends cleanly at
    the next ``##``.
    """

    __slots__ = ("level", "title", "raw_title", "lines")

    def __init__(self, level: int, raw_title: str) -> None:
        self.level = level
        self.raw_title = raw_title
        self.title = _normalise_heading(raw_title)
        self.lines: List[str] = []

    @property
    def text(self) -> str:
        return "\n".join(self.lines)

    @property
    def heading(self) -> str:
        return f"{'#' * self.level} {self.raw_title}".strip()


def _normalise_heading(raw: str) -> str:
    """A heading title reduced to something matchable.

    Strips markdown emphasis, a trailing anchor/colon and a leading ordinal, so
    ``## 8. **QA Decision**`` and ``## QA Decision`` are the same section.
    """
    text = _strip_md(raw or "").strip()
    text = _ORDINAL_PREFIX_RE.sub("", text).strip()
    return text.strip(" :#").strip()


def _split_sections(text: str) -> List[_Section]:
    sections: List[_Section] = []
    stack: List[_Section] = []
    for raw_line in (text or "").splitlines():
        m = _HEADING_RE.match(raw_line.strip())
        if m:
            level = len(m.group(1))
            section = _Section(level, m.group(2))
            while stack and stack[-1].level >= level:
                stack.pop()
            sections.append(section)
            stack.append(section)
            continue
        for parent in stack:
            parent.lines.append(raw_line)
    return sections


def _find_sections(sections: Sequence[_Section], pattern: str) -> List[_Section]:
    rx = re.compile(pattern, re.IGNORECASE)
    return [s for s in sections if rx.search(s.title)]


# ---------------------------------------------------------------------------
# Table parsing
# ---------------------------------------------------------------------------

def _tables(lines: Sequence[str]) -> List[List[List[str]]]:
    """Every pipe table in *lines*, as a list of ``[header, *rows]`` cell lists.

    Tables are split on any non-pipe line, which is what markdown itself does
    (a blank line terminates a table). Splitting matters more than it looks: a
    single ``## Acceptance Criteria Verification`` section routinely carries the
    AC table AND a follow-up evidence table, and a reader that just collects
    every pipe row in the section swallows the second table's header and rows as
    if they were criteria. That produced five phantom ``NOT RECORDED`` criteria
    on QA-BUG-MSO-2026-0501 and five on QA-BUG-MSO-2026-0714 — inventing
    unverified criteria out of an evidence table, i.e. exactly the class of
    fabrication plan §7 forbids, in the direction that makes the fleet look
    worse rather than better.
    """
    tables: List[List[List[str]]] = []
    current: List[List[str]] = []
    for line in lines:
        stripped = line.strip()
        if not stripped.startswith("|"):
            if current:
                tables.append(current)
                current = []
            continue
        cells = [_strip_md(c) for c in stripped.strip("|").split("|")]
        if cells and all(_SEPARATOR_CELL_RE.match(c.strip())
                         for c in cells if c.strip()):
            continue  # the |---|---| rule row is part of the same table
        if not any(c.strip() for c in cells):
            continue
        current.append(cells)
    if current:
        tables.append(current)
    return tables


def _canonical_header(cells: Sequence[str], synonyms: Dict[str, str]) -> Dict[str, int]:
    """Map a header row to ``{role: column index}`` by NAME.

    A parenthetical qualifier is dropped before lookup — ``Criterion
    (abridged)``, ``Criterion (order json ``acceptanceCriteria[n]``)`` and
    ``Criterion`` are one column. First mapping wins, so a table with both
    ``Notes`` and ``Comments`` keeps the leftmost.
    """
    out: Dict[str, int] = {}
    for idx, cell in enumerate(cells):
        name = (cell or "").strip().lower()
        name = name.split("(")[0].strip()
        name = name.strip(" *`_:")
        role = synonyms.get(name)
        if role and role not in out:
            out[role] = idx
    return out


def _first_table(section: _Section, synonyms: Dict[str, str],
                  required: Sequence[str]) -> Tuple[Dict[str, int], List[List[str]]]:
    """The first table in *section* whose header maps every role in *required*.

    Returns ``({}, [])`` when the section holds no such table — the caller then
    records a parse note rather than inventing rows. Rows are scoped to the
    matching table alone (see :func:`_tables`), never to the rest of the section.
    """
    for table in _tables(section.lines):
        if not table:
            continue
        header = _canonical_header(table[0], synonyms)
        if all(role in header for role in required):
            return header, table[1:]
    return {}, []


def _cell(cells: Sequence[str], header: Dict[str, int], role: str) -> str:
    idx = header.get(role)
    if idx is None or idx >= len(cells):
        return ""
    return (cells[idx] or "").strip()


def _to_int(text: str) -> Optional[int]:
    m = _INT_RE.search(text or "")
    if not m:
        return None
    try:
        return int(m.group(0))
    except ValueError:
        return None


# ---------------------------------------------------------------------------
# Verdict
# ---------------------------------------------------------------------------

def _first_token(text: str, allow_aliases: bool) -> Optional[Tuple[str, str]]:
    """The EARLIEST verdict token in *text*, as ``(canonical, literal)``.

    Earliest-by-position is the rule that makes multi-token declarations read
    correctly, and every multi-token case on the live plane is a declaration
    that names its own answer first and then explains itself:

    * ``CONDITIONAL — F1 and F3 APPROVED; F2 REJECTED`` -> CONDITIONAL
    * ``APPROVED (conditional on the CI re-run)``       -> APPROVED
    * ``APPROVED — conditional on the in-progress run`` -> APPROVED

    A "contains APPROVED" scan gets all three wrong in at least one direction.
    """
    body = text or ""
    best: Optional[Tuple[int, str, str]] = None
    for rx, is_alias in ((_VERDICT_TOKEN_RE, False), (_VERDICT_ALIAS_RE, True)):
        if is_alias and not allow_aliases:
            continue
        m = rx.search(body)
        if m is None:
            continue
        # An alias preceded by a number is a test count, not a verdict:
        # ``Result: 32 PASSED / 0 FAILED`` is a tally and reading it as an
        # approval would be inventing a judgement nobody made. The four
        # canonical tokens need no such guard — no report writes "32 APPROVED".
        if is_alias and _DIGIT_RE.search(body[: m.start()]):
            continue
        if best is None or m.start() < best[0]:
            best = (m.start(), Verdict.normalise(m.group(1)), m.group(1))
    if best is None:
        return None
    return best[1], best[2]


def _declaration(lines: Sequence[str]) -> Optional[Tuple[str, str]]:
    """The first self-declared verdict in *lines*, as ``(label, value)``.

    Two forms, both in live use:

    * a prose line — ``**Status:** APPROVED``, ``**Status: CONDITIONAL**``,
      ``Verdict: PASS``;
    * a two-cell key/value table row — ``| Verdict | **PASS** |`` — which the
      Hub-frontend QA reports use for their whole header block.
    """
    for line in lines:
        text = line.strip()
        if not text:
            continue
        if text.startswith("|"):
            cells = [_strip_md(c) for c in text.strip("|").split("|")]
            if len(cells) == 2:
                label = cells[0].strip().strip(":").lower()
                value = cells[1].strip()
                if value and _DECLARATION_LABEL_RE.match(label):
                    return label, value
            continue
        m = _DECLARATION_RE.match(text)
        if m:
            value = m.group(2).strip().strip("*").strip()
            if value:
                return m.group(1).strip(), value
    return None


def _heading_declaration(section: _Section) -> Optional[str]:
    """A verdict declared in the heading itself — ``## Status: BLOCKED — …``.

    Narrower than :func:`_declaration` on purpose: the label must be
    status/decision/verdict, never ``result``, because ``### Result: 32 PASSED /
    0 FAILED`` is a heading that reports a tally, not a decision.
    """
    m = _HEADING_DECLARATION_RE.match(_strip_md(section.raw_title).strip())
    if m is None:
        return None
    value = m.group(2).strip().strip("*").strip()
    return value or None


def extract_verdict(text: str) -> Tuple[str, str, str]:
    """``(verdict, raw_verdict, verdict_source)`` for a QA report's body.

    A cascade, most authoritative first, and every tier reads only what the
    report actually says:

    1. A verdict SECTION (``## QA Decision``, ``## Decision``, ``## Verdict``,
       numbered or not). Inside one, a self-declared ``**Status:** X`` line wins;
       failing that the earliest canonical token in the section's prose is taken,
       because a section whose whole job is to state the decision is entitled to
       state it in a sentence.
    2. A HEADING that is itself the declaration — ``## Status: BLOCKED —
       Coverage below threshold``, which is how the ADM-era reports wrote it.
    3. A SIGN-OFF section, or the document preamble before the first heading —
       both **declaration lines only**. This is where the hand-written and
       ADM-era reports keep ``**Verdict:** PASS``. Free prose is deliberately
       NOT scanned at this tier: "all tests PASS" in a sign-off paragraph is a
       statement about tests, not a verdict, and reading it as one is exactly the
       invention plan §7 forbids.
    4. Nothing matched -> ``UNDETERMINED`` with an empty source.

    ``PASS`` / ``FAIL`` are honoured only inside a declaration line, never in
    prose, for the same reason.
    """
    sections = _split_sections(text)

    for pattern in _VERDICT_SECTION_PATTERNS:
        for section in _find_sections(sections, pattern):
            decl = _declaration(section.lines)
            if decl is not None:
                hit = _first_token(decl[1], allow_aliases=True)
                if hit is not None:
                    return hit[0], decl[1], section.heading
            hit = _first_token(section.text, allow_aliases=False)
            if hit is not None:
                return hit[0], _condense(section.text), section.heading

    for section in sections:
        value = _heading_declaration(section)
        if value is None:
            continue
        hit = _first_token(value, allow_aliases=True)
        if hit is not None:
            return hit[0], value, section.heading

    for pattern in _SIGNOFF_SECTION_PATTERNS:
        for section in _find_sections(sections, pattern):
            decl = _declaration(section.lines)
            if decl is not None:
                hit = _first_token(decl[1], allow_aliases=True)
                if hit is not None:
                    return hit[0], decl[1], section.heading

    preamble = _preamble_lines(text)
    decl = _declaration(preamble)
    if decl is not None:
        hit = _first_token(decl[1], allow_aliases=True)
        if hit is not None:
            return hit[0], decl[1], "(document preamble)"

    # Last tier: a self-declaration anywhere in the document. Declaration forms
    # only — never prose — so this reaches a report that puts its verdict in a
    # key/value header block under an unrelated heading (the Hub-frontend QA
    # reports write ``| Verdict | **PASS** |`` under a feature-name heading)
    # without ever reading a sentence as a decision.
    decl = _declaration((text or "").splitlines())
    if decl is not None:
        hit = _first_token(decl[1], allow_aliases=True)
        if hit is not None:
            return hit[0], decl[1], "(declared inline)"

    return Verdict.UNDETERMINED, "", ""


def _preamble_lines(text: str) -> List[str]:
    """Lines before the first ``##`` heading, capped.

    A hand-written report often states its verdict immediately under the title
    (``# QA Report — FTR-MSO-2026-0322`` / ``**Verdict:** PASS``). The cap keeps
    this from becoming a whole-document scan by another name.
    """
    out: List[str] = []
    for line in (text or "").splitlines()[:40]:
        m = _HEADING_RE.match(line.strip())
        if m and len(m.group(1)) >= 2:
            break
        out.append(line)
    return out


def _condense(text: str, max_len: int = 240) -> str:
    condensed = " ".join((text or "").split())
    if len(condensed) > max_len:
        condensed = condensed[: max_len - 1].rstrip() + "…"
    return condensed


# ---------------------------------------------------------------------------
# Acceptance-criteria table
# ---------------------------------------------------------------------------

def parse_ac_table(text: str) -> Tuple[List[ACCriterionRow], List[str]]:
    """``(rows, parse_notes)`` from ``## Acceptance Criteria Verification``.

    Keyed entirely by column name (see :data:`_AC_COLUMNS`), so all six
    canonical header families and their parenthetical variants read identically.
    A table with no status-ish column still yields its criteria — as
    ``NOT RECORDED``, with a note — because the criteria themselves are real
    information and pretending they were verified is not an option (Captain
    decision D4).
    """
    notes: List[str] = []
    sections = [s for s in _split_sections(text) if _AC_SECTION_RE.search(s.title)]
    if not sections:
        return [], ["No '## Acceptance Criteria Verification' heading found."]

    rows: List[ACCriterionRow] = []
    for section in sections:
        header, data = _first_table(section, _AC_COLUMNS, required=("criterion",))
        if not header:
            continue
        if "status" not in header:
            notes.append(
                f"AC table under '{section.heading}' has no status/result column — "
                "criteria recorded as NOT RECORDED."
            )
        for cells in data:
            ident = _cell(cells, header, "id")
            criterion = _cell(cells, header, "criterion")
            if not ident and not criterion:
                continue
            # A '**Total**' / 'Summary' roll-up row is not a criterion.
            if not criterion and ident.lower() in ("total", "summary", "totals"):
                continue
            raw_status = _cell(cells, header, "status")
            rows.append(ACCriterionRow(
                id=ident,
                criterion=criterion,
                status=ACStatus.normalise(raw_status),
                raw_status=raw_status,
                validation=_cell(cells, header, "validation"),
                notes=_cell(cells, header, "notes"),
                evidence=_cell(cells, header, "evidence"),
                provenance=Provenance.QA_REPORT,
            ))
        if rows:
            break

    if not rows:
        notes.append("Acceptance-criteria section carried no parseable table.")
    return rows, notes


# ---------------------------------------------------------------------------
# Defects
# ---------------------------------------------------------------------------

def parse_report_defects(text: str) -> Tuple[List[Any], List[str]]:
    """``(defects, parse_notes)`` from ``## Defects Found``.

    **Delegates to** :func:`maestro.core.role_rejection.parse_defects` — that
    parser, with its two-tier explicit-vs-inferred blocking logic, is the one
    the dispatcher's own rejection routing uses, and a second implementation
    here would eventually disagree with it about whether an order was rejected.
    It is dispatch-critical and deliberately not modified (plan §4).

    What this wrapper adds is the two things that parser cannot do from where it
    sits, both of which are pure input normalisation:

    * **Column reordering.** ``parse_defects`` indexes cells positionally
      (``cells[0..4]`` = id, severity, description, file, line), correct for the
      dominant header and wrong for the tail: ``| ID | Severity | Description |
      Location |`` loses the file, and ``| ID | Severity | Blocking |
      Description | File |`` reads the blocking flag *as the summary*. This
      wrapper reads the header by name and rewrites each row into the canonical
      order before delegating.
    * **Numbered headings.** ``parse_defects`` anchors on ``^#+\\s+defects?
      found``, so ``## 7. Defects Found`` is invisible to it. The synthetic
      section this wrapper hands over always carries the canonical heading.

    A dedicated blocking column is applied as an OVERRIDE after delegation, not
    by folding ``Yes``/``No`` into the severity cell. Folding would misfire on
    the all-``No`` case: ``parse_defects`` only honours explicit markers when at
    least one row carries one, so a table where every row says "not blocking"
    would fall through to severity inference and mark a CRITICAL row blocking
    against its own report's explicit statement.
    """
    notes: List[str] = []
    sections = [s for s in _split_sections(text) if _DEFECTS_SECTION_RE.search(s.title)]
    if not sections:
        return [], ["No '## Defects Found' heading found."]

    for section in sections:
        header, data = _first_table(section, _DEFECT_COLUMNS,
                                     required=("id", "severity"))
        if not header:
            continue

        canonical: List[str] = ["## Defects Found", ""]
        canonical.append("| ID | Severity | Description | File | Line |")
        canonical.append("|----|----------|-------------|------|------|")
        blocking_flags: Dict[str, Optional[bool]] = {}
        offered: List[str] = []
        for cells in data:
            ident = _cell(cells, header, "id")
            if not ident:
                continue
            offered.append(ident)
            severity = _cell(cells, header, "severity")
            description = _cell(cells, header, "description")
            file_cell = _cell(cells, header, "file")
            line_cell = _cell(cells, header, "line")
            canonical.append(
                "| {} | {} | {} | {} | {} |".format(
                    _pipe_safe(ident), _pipe_safe(severity), _pipe_safe(description),
                    _pipe_safe(file_cell), _pipe_safe(line_cell),
                )
            )
            if "blocking" in header:
                blocking_flags[ident] = _tri_bool(_cell(cells, header, "blocking"))

        defects = parse_defects("\n".join(canonical) + "\n")
        for defect in defects:
            flag = blocking_flags.get(defect.id)
            if flag is not None:
                defect.blocking = flag

        # A row the delegate declined is REPORTED, never silently dropped.
        # ``role_rejection._DEFECT_ID_RE`` requires at least two characters
        # before the hyphen, so a report numbering its defects ``D-01`` (e.g.
        # QA-BUG-MSO-2026-0501) hands over three rows and gets back none. That
        # regex is dispatch-critical and out of scope to change here (plan §4
        # names extending it upstream as a separate order); what this reader owes
        # is that the gap is visible on the record instead of reading as "this
        # report found no defects".
        kept = {d.id for d in defects}
        dropped = [i for i in offered if i not in kept and not _is_placeholder_id(i)]
        if dropped:
            notes.append(
                "Defect rows not recognised as defect ids by "
                "role_rejection.parse_defects and therefore omitted: "
                + ", ".join(dropped[:10])
                + (" …" if len(dropped) > 10 else "")
            )
        return defects, notes

    # A section that exists and says "None." is a real, informative answer: the
    # tester looked and found nothing. Not a parse failure.
    body = " ".join(sections[0].text.split()).strip().rstrip(".").lower()
    if body and body not in ("none", "no defects", "none found", "n/a", "nil"):
        notes.append(
            f"'{sections[0].heading}' carried no parseable defect table "
            "(free-form prose)."
        )
    return [], notes


def _is_placeholder_id(text: str) -> bool:
    """Whether an id cell is a "nothing here" marker rather than a defect id.

    A ``## Defects Found`` table with a single ``| — | — | No defects found | — |``
    row is a *statement that there are none*, and reporting it as an omitted
    defect would be crying wolf on the very reports that are cleanest.
    """
    token = (text or "").strip().strip("*`").upper()
    if not token or token in ("—", "–", "-", "N/A", "NA", "NONE", "NIL", "TBD", "—"):
        return True
    return token.startswith("(")


def _pipe_safe(text: str) -> str:
    """A cell value that cannot break the synthetic table it is written into."""
    return (text or "").replace("|", "\\|").replace("\n", " ").strip()


def _tri_bool(text: str) -> Optional[bool]:
    token = (text or "").strip().strip("*`").upper()
    if token in _YES:
        return True
    if token in _NO:
        return False
    return None


# ---------------------------------------------------------------------------
# Test summary
# ---------------------------------------------------------------------------

def parse_test_summary(text: str) -> Tuple[TestCounts, List[str]]:
    """``(TestCounts, parse_notes)`` from ``## Test Summary``.

    Counts come from tables whose columns are NAMED ``Tests`` / ``Passed`` /
    ``Failed`` — the label column varies wildly (``Test Module``, ``Test
    Class``, ``Area``, ``Suite``, ``Test Group``) and is never relied on. Within
    one table a ``**Total**`` row is preferred over summing the data rows, so a
    report that provides both is not double-counted.

    Absence stays absent: a report with no numeric table yields
    ``TestCounts()`` — every field ``None`` — and a note. It never yields
    ``tests=0``, which would read as "the fleet ran no tests".
    """
    notes: List[str] = []
    sections = _split_sections(text)
    summary = next((s for s in sections if _TEST_SUMMARY_SECTION_RE.search(s.title)),
                    None)
    if summary is None:
        return TestCounts(), ["No '## Test Summary' heading found."]

    # Subsections strictly inside the summary section, in document order.
    start = sections.index(summary)
    children = []
    for s in sections[start + 1:]:
        if s.level <= summary.level:
            break
        children.append(s)

    scopes: List[Tuple[str, _Section]] = (
        [(c.title or c.raw_title, c) for c in children] if children
        else [(summary.title or "Test Summary", summary)]
    )

    categories: List[TestCategoryCounts] = []
    for name, section in scopes:
        counts = _counts_from_lines(section.lines)
        if counts is None:
            continue
        tests, passed, failed = counts
        categories.append(TestCategoryCounts(name=name, tests=tests,
                                              passed=passed, failed=failed))

    if not categories:
        return TestCounts(), [
            f"'{summary.heading}' carried no table with Tests/Passed/Failed columns."
        ]

    def _sum(attr: str) -> Optional[int]:
        values = [getattr(c, attr) for c in categories
                  if getattr(c, attr) is not None]
        return sum(values) if values else None

    return TestCounts(tests=_sum("tests"), passed=_sum("passed"),
                       failed=_sum("failed"), categories=categories), notes


_NEW_FAILURES_PHRASE = re.compile(r"new\s+failures?\s+introduced", re.IGNORECASE)
# A standalone integer: not part of an order id (``BUG-MSO-2026-0503``), a
# version (``3.13``) or a word.
_STANDALONE_INT = re.compile(r"(?<![\w.-])(\d{1,6})(?![\w-])")
_ZERO_WORDS = re.compile(r"^(none|zero|no)\b", re.IGNORECASE)
# A count written immediately BEFORE the phrase: ``Zero new failures introduced``,
# ``No new failures introduced``, ``3 new failures introduced``.
_LEADING_ZERO_WORD = re.compile(r"(?<![\w-])(none|zero|no)\s*$", re.IGNORECASE)
_LEADING_INT = re.compile(r"(?<![\w.-])(\d{1,6})\s*$")
# The end of the clause the phrase sits in. A ``.`` only counts when it is not
# a decimal point / version separator.
_CLAUSE_END = re.compile(r"[.!?;](?=\s|\*|\)|$)")
_LABEL_PUNCT = " :.-—–\t"


def _new_failures_clause(line: str, start: int, end: int) -> str:
    """The text after the phrase that can still be stating its figure.

    Stops at the closing ``**`` of a bold span the phrase opened inside (unless
    that span holds only the label's punctuation, as in
    ``**New failures introduced:** 0``), then at the end of the sentence. Without
    this bound, ``**Zero new failures introduced.** (Baseline: 893 passed …)``
    read as 893 (DEF-001, QA-FTR-MSO-2026-0502).
    """
    tail = line[end:]
    if line[:start].count("**") % 2 == 1:
        close = tail.find("**")
        if close != -1 and tail[:close].strip(_LABEL_PUNCT):
            tail = tail[:close]
    boundary = _CLAUSE_END.search(tail)
    if boundary:
        tail = tail[:boundary.start()]
    return tail


def parse_new_failures(text: str) -> Optional[int]:
    """The "New failures introduced" figure, or ``None`` when no line states one.

    ``maestro/roles/TST.md`` mandates ``- New failures introduced: {count}`` in
    ``## Test Summary``; the live plane writes it a dozen ways
    (``- **New failures introduced by this order: 0.**``,
    ``| New failures introduced | — | **0** |``,
    ``**Zero new failures introduced.**``). A count written immediately before
    the phrase wins (``zero`` / ``no`` / ``none`` → 0, or a bare integer).
    Otherwise the figure is the first standalone integer after the phrase within
    the same clause — never a digit run inside an order id, never a number from a
    following sentence — or ``0`` for an explicit ``none`` / ``zero`` / ``no``.
    An unrendered ``{count}`` placeholder states nothing and yields ``None``.
    When several lines state a figure the LARGEST is returned, so a report can
    never be read as understating its own failures. Never raises.

    FTR-MSO-2026-0502 (voyage PR bodies) is the consumer.
    """
    if not isinstance(text, str):
        return None
    found: List[int] = []
    for line in text.splitlines():
        match = _NEW_FAILURES_PHRASE.search(line)
        if not match:
            continue
        prefix = line[:match.start()]
        for ch in ("*", "`", "_"):
            prefix = prefix.replace(ch, " ")
        if _LEADING_ZERO_WORD.search(prefix):
            found.append(0)
            continue
        leading = _LEADING_INT.search(prefix)
        if leading:
            found.append(int(leading.group(1)))
            continue
        tail = _new_failures_clause(line, match.start(), match.end())
        for ch in ("*", "`", "|", "_"):
            tail = tail.replace(ch, " ")
        number = _STANDALONE_INT.search(tail)
        if number:
            found.append(int(number.group(1)))
        elif _ZERO_WORDS.match(tail.strip(" :.-—–\t")):
            found.append(0)
    return max(found) if found else None


def _is_total_label(label: str) -> bool:
    """Whether a table's first cell marks that row as the category roll-up.

    Matched on the LEADING word, not the whole cell, because reports qualify it:
    ``**Total (combined run)**``, ``Total — targeted suite``. An exact-match
    check missed those and then summed the roll-up row *on top of* the data rows
    it rolls up — QA-BUG-MSO-2026-0503 reported 672 tests where its own table
    says 331.
    """
    head = (label or "").strip().strip("*` ")
    for sep in ("(", "—", "–", ":", " - ", ","):
        head = head.split(sep)[0]
    return head.strip().lower() in ("total", "totals", "sum", "grand total",
                                     "subtotal", "combined")


def _counts_from_lines(
    lines: Sequence[str],
) -> Optional[Tuple[Optional[int], Optional[int], Optional[int]]]:
    """One scope's ``(tests, passed, failed)``, or ``None`` if it has no table."""
    header: Dict[str, int] = {}
    data: List[List[str]] = []
    for table in _tables(lines):
        if not table:
            continue
        candidate = _canonical_header(table[0], _TEST_COLUMNS)
        if "tests" in candidate and ("passed" in candidate or "failed" in candidate):
            header = candidate
            data = table[1:]
            break
    if not header:
        return None

    totals: Optional[List[Optional[int]]] = None
    summed: List[Optional[int]] = [None, None, None]
    for cells in data:
        label = " ".join(_strip_md(cells[0]).split()).lower() if cells else ""
        values = [_to_int(_cell(cells, header, role))
                  for role in ("tests", "passed", "failed")]
        if all(v is None for v in values):
            continue
        if _is_total_label(label):
            totals = values
            continue
        for idx, value in enumerate(values):
            if value is None:
                continue
            summed[idx] = (summed[idx] or 0) + value

    chosen = totals if totals is not None else summed
    if all(v is None for v in chosen):
        return None
    return chosen[0], chosen[1], chosen[2]


# ---------------------------------------------------------------------------
# Order identity
# ---------------------------------------------------------------------------

def extract_order_id(text: str, fallback_name: str = "") -> str:
    """The order this report is about.

    Prefers the report's own ``## Order Reference`` ``- Order ID: X`` line, then
    the first order id anywhere in its opening lines, then the id embedded in
    the filename (``QA-BUG-MSO-2026-0266.md``). Returns ``""`` rather than a
    guess when none of those yield one.
    """
    sections = _split_sections(text)
    for section in sections:
        if not _ORDER_REF_SECTION_RE.search(section.title):
            continue
        for line in section.lines:
            m = _ORDER_ID_LINE_RE.match(line.strip())
            if m:
                return m.group(1).strip().upper()

    head = "\n".join((text or "").splitlines()[:20])
    m = _ORDER_ID_IN_TEXT_RE.search(head.upper())
    if m:
        return m.group(1)

    m = _ORDER_ID_IN_TEXT_RE.search((fallback_name or "").upper())
    return m.group(1) if m else ""


def node_verdict_hint(value: Optional[str]) -> Optional[str]:
    """*value* as a corroborating hint, or ``None``.

    ``CONSUMED`` is treated as **absent** (Captain decision D3): the dispatcher
    writes it over a real ``FAIL`` once routing has acted on that verdict
    (``chart_routing._rewrite_verdict_consumed``), so it records that a verdict
    once existed and says nothing about what it was. Reporting it as a verdict
    would be reporting a bookkeeping stamp as a QA judgement.
    """
    token = (value or "").strip()
    if not token or token.upper() == "CONSUMED":
        return None
    return token


# ---------------------------------------------------------------------------
# The public readers
# ---------------------------------------------------------------------------

def parse_qa_report(text: str, order_id: str = "",
                     node_verdict: Optional[str] = None,
                     report_name: str = "") -> QAReportSummary:
    """Build a :class:`QAReportSummary` from a report's TEXT.

    Pure: no filesystem, no workspace, no clock — which is what makes the
    committed-corpus tests hermetic. :func:`read_qa_report` is the thin
    filesystem wrapper around it.

    Never raises. A malformed, empty or truncated body yields a summary whose
    verdict is ``UNDETERMINED`` and whose :attr:`parse_notes` say why; that is
    the contract every caller relies on, because a report reader that can throw
    turns one bad artefact into a failed page.
    """
    body = text if isinstance(text, str) else ""
    resolved_id = (order_id or "").strip() or extract_order_id(body, report_name)
    summary = QAReportSummary(order_id=resolved_id, report_name=report_name)
    summary.node_verdict = node_verdict_hint(node_verdict)

    try:
        verdict, raw, source = extract_verdict(body)
        summary.verdict = verdict
        summary.raw_verdict = raw
        summary.verdict_source = source
        if verdict == Verdict.UNDETERMINED:
            summary.parse_notes.append(
                "No readable verdict — no '## QA Decision' token and no "
                "declared status line."
            )

        ac_rows, ac_notes = parse_ac_table(body)
        summary.ac_rows = ac_rows
        summary.parse_notes.extend(ac_notes)

        defects, defect_notes = parse_report_defects(body)
        summary.defects = defects
        summary.parse_notes.extend(defect_notes)

        counts, count_notes = parse_test_summary(body)
        summary.test_counts = counts
        summary.parse_notes.extend(count_notes)
    except Exception as exc:  # pragma: no cover - defensive
        # A parser bug must degrade to UNDETERMINED, never propagate. The whole
        # value of this reader is that a surface can call it on 275 files
        # without any one of them being able to take the page down.
        summary.verdict = Verdict.UNDETERMINED
        summary.parse_notes.append(f"Reader error: {type(exc).__name__}: {exc}")

    return summary


def _read_bounded(path: Path) -> Tuple[str, int, bool]:
    """``(text, size, truncated)`` for *path*, capped at ``MAX_ARTEFACT_BYTES``.

    The same cap the Hub's artefact route uses, applied here so a CLI or a
    report list cannot be turned into a memory amplification by one oversized
    artefact either.
    """
    raw = path.read_bytes()
    truncated = len(raw) > MAX_ARTEFACT_BYTES
    head = raw[:MAX_ARTEFACT_BYTES] if truncated else raw
    return head.decode("utf-8", errors="replace"), len(raw), truncated


def _pick_report(order_id: str, paths: Sequence[Tuple[str, str, Path]]) -> Optional[Path]:
    """The one QA report to read for *order_id*, deterministically.

    ``QA-{ORDER-ID}.md`` first (the naming the TST role mandates), then
    ``{ORDER-ID}.md``, then the shortest remaining name — shortest because a
    longer stem containing the id is a narrower, derivative artefact
    (``QA-FTR-PSG-2026-0134-gap-report.md``) and the plain report is the one an
    operator means.
    """
    md = [p for _kind, _name, p in paths if p.suffix.lower() == ".md"]
    if not md:
        return None
    wanted = order_id.upper()
    for stem in (f"QA-{wanted}", wanted):
        for path in md:
            if path.stem.upper() == stem:
                return path
    return sorted(md, key=lambda p: (len(p.name), p.name))[0]


def read_qa_report(mso: Path, order_id: str) -> Optional[QAReportSummary]:
    """The QA record for *order_id*, or ``None`` if it has no QA report.

    ``None`` means exactly one thing — discovery found no ``reports/qa/`` file
    for this order — and it is distinct from a summary carrying
    ``verdict=UNDETERMINED``, which means a report exists and could not be
    read. A surface must render those differently: the first is "no QA has been
    done", the second is "QA was done and we cannot summarise it".

    **Never raises.** An unreadable file, a permission error or a parser bug all
    return a summary with the failure on :attr:`parse_notes`.
    """
    try:
        mso_path = Path(mso)
        paths = discover_report_paths(mso_path, order_id, kinds=("qa",))
    except Exception:
        return None

    path = _pick_report(order_id, paths)
    if path is None:
        return None

    return _summarise_path(mso_path, path, order_id)


def _summarise_path(mso: Path, path: Path, order_id: str = "") -> QAReportSummary:
    name = path.name
    try:
        text, size, truncated = _read_bounded(path)
    except OSError as exc:
        summary = QAReportSummary(order_id=order_id or extract_order_id("", name),
                                  report_name=name)
        summary.parse_notes.append(f"Report could not be read: {exc}")
        return summary

    node_verdict: Optional[str] = None
    try:
        # Reuse chart_routing's own front-matter reader (plan §4) rather than a
        # second copy, applied to the file discovery actually found — which is
        # more precise than its per-role candidate table, since that table
        # assumes the canonical filename and discovery does not.
        from maestro.core.chart_routing import _parse_node_verdict_frontmatter

        node_verdict = _parse_node_verdict_frontmatter(path)
    except Exception:
        node_verdict = None

    summary = parse_qa_report(text, order_id=order_id, node_verdict=node_verdict,
                               report_name=name)
    summary.size = size
    summary.truncated = truncated
    if truncated:
        summary.parse_notes.append(
            f"Report exceeds {MAX_ARTEFACT_BYTES} bytes and was read truncated; "
            "sections past the cap were not parsed."
        )
    try:
        summary.report_rel = path.relative_to(mso).as_posix()
    except ValueError:
        summary.report_rel = name
    try:
        from datetime import datetime, timezone

        summary.modified = datetime.fromtimestamp(
            path.stat().st_mtime, tz=timezone.utc).isoformat()
    except OSError:
        summary.modified = ""
    return summary


def list_qa_reports(mso: Path, limit: Optional[int] = None,
                     ) -> Tuple[List[QAReportSummary], ParseCoverage]:
    """Every QA report in the workspace, newest first, with parse coverage.

    ``coverage`` is the D3 drift alarm: it reports ``total`` / ``parsed`` /
    ``undetermined`` separately, so a heading-contract drift that quietly
    degrades this reader shows up as a falling ``parsed`` figure on the surface
    instead of as silently missing verdicts.

    ``limit`` bounds the response (the newest *limit* reports); ``coverage``
    always describes the reports that were actually parsed, never a larger set
    the caller did not receive.
    """
    mso_path = Path(mso)
    coverage = ParseCoverage()
    summaries: List[QAReportSummary] = []
    try:
        paths = iter_report_paths(mso_path, "qa")
    except Exception:
        return summaries, coverage

    md_paths = [p for p in paths if p.suffix.lower() == ".md"]
    try:
        md_paths.sort(key=lambda p: (-p.stat().st_mtime, p.name))
    except OSError:
        md_paths.sort(key=lambda p: p.name)
    if limit is not None and limit >= 0:
        md_paths = md_paths[:limit]

    for path in md_paths:
        summary = _summarise_path(mso_path, path)
        summaries.append(summary)
        coverage.add(summary.decided)
    return summaries, coverage
