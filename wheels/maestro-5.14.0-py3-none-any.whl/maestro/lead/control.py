# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""maestro/lead/control.py — the ONE start/stop/restart core for the resident
LEAD daemon (FTR-MSO-2026-0786).

``mso lead start|stop|restart`` (``cli.cmd_lead``) and the Hub's
``POST /api/v1/workspaces/{id}/lead/start|stop|restart`` both call the three
functions below, per CLAUDE.md "Shared cores — one implementation per
decision". Before this module the Hub had no way to start a stopped LEAD at
all: its strip rendered a disabled "Start to stand down" toggle naming an
action nothing in the Hub could perform, and an operator had to know to open
a terminal in the workspace's artefact root.

The contract every shared core obeys (``maestro/core/order_retry.py``):

* **Explicit paths, no CWD, no ``find_workspace()``.** Callers resolve the
  artefact root and workspace root and hand them in —
  :func:`lead_paths_for_workspace_root` for the CLI (which already chose a
  workspace root), :func:`lead_paths_for_entry` for the Hub (which holds a
  registry entry). Both resolve the artefact root through
  :func:`maestro.workspace.artefact_root_for`, so a solo-mode workspace gets
  the same ``.mso`` from either surface.
* **No printing, no ``sys.exit``.** The daemon lifecycle's sentences are
  collected onto :attr:`LeadControlResult.messages`; the CLI prints them, the
  Hub returns them. A stop that could not be confirmed is ``ok=False`` — the
  CLI exits non-zero on it, the Hub answers 500.
* **Runs inside** :func:`maestro.core.order_retry.workspace_scope`, so the
  lifecycle line this module writes lands in THIS workspace's
  ``logs/lifecycle.log`` even from a Hub process serving several. HTTP callers
  must therefore be sync ``def`` endpoints (see that function's docstring).

Licence tier gating stays at the call sites, exactly as
``maestro.lead.daemon``'s module docstring records: the CLI calls
``auth.require_tier``, the Hub calls ``_require_control_tier()``. ``stop`` is
never gated on either surface — turning LEAD off must always be possible.

Liveness is :func:`maestro.proc_identity.is_running` (PID **and** matching
create time) throughout, never the PID alone — the same check
``mso lead status`` and :mod:`maestro.lead.daemon` use.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from maestro import proc_identity
from maestro.lead import daemon as _daemon

__all__ = [
    "ACTOR_CLI",
    "ACTOR_HUB",
    "LeadControlResult",
    "lead_paths_for_entry",
    "lead_paths_for_workspace_root",
    "restart_lead",
    "start_lead",
    "stop_lead",
]

#: Who asked. Written into the lifecycle line and the audit metadata so an
#: operator reading ``lifecycle.log`` can tell a Hub click from a terminal.
ACTOR_CLI = "cli"
ACTOR_HUB = "hub"

# Lifecycle event types this module writes. Named in the past tense, like
# LEAD_RESUMED, because each is written only once the thing has happened.
EVENT_STARTED = "LEAD_STARTED"
EVENT_STOPPED = "LEAD_STOPPED"
EVENT_STOP_FAILED = "LEAD_STOP_FAILED"


@dataclass
class LeadControlResult:
    """What one start/stop/restart actually did.

    ``outcome`` is one of:

    * ``started`` — a daemon was launched (``pid`` is its PID when the record
      could be read back).
    * ``already_running`` — start on an identity-verified live daemon; nothing
      was launched. ``ok`` is True: the operator's goal already holds.
    * ``stopped`` — a live daemon was signalled and confirmed gone.
    * ``not_running`` — stop with no live daemon; nothing was signalled.
      ``ok`` is True for the same reason as ``already_running``.
    * ``restarted`` — the old daemon (if any) was confirmed gone and a
      replacement launched.
    * ``stop_failed`` — the daemon is still alive after the signal and the
      escalation (``ok`` False). On restart, no replacement was launched.
    """

    action: str
    outcome: str
    ok: bool
    pid: Optional[int] = None
    previous_pid: Optional[int] = None
    messages: list = field(default_factory=list)
    errors: list = field(default_factory=list)

    @property
    def summary(self) -> str:
        """One sentence for a toast or an HTTP ``message`` field."""
        if self.outcome == "started":
            return f"LEAD started (PID {self.pid})." if self.pid else "LEAD started."
        if self.outcome == "already_running":
            return f"LEAD is already running (PID {self.pid}) — nothing to start."
        if self.outcome == "stopped":
            return f"LEAD stopped (PID {self.previous_pid})."
        if self.outcome == "not_running":
            return "LEAD is not running — nothing to stop."
        if self.outcome == "restarted":
            return f"LEAD restarted (PID {self.pid})." if self.pid else "LEAD restarted."
        detail = " ".join(m.replace("[LEAD] ", "", 1) for m in self.errors) or (
            "the daemon is still alive after the stop signal and the escalation."
        )
        return f"LEAD could not be stopped: {detail}"


def lead_paths_for_workspace_root(workspace_root: Path) -> "tuple[Path, Path]":
    """``(artefact_root, workspace_root)`` for a KNOWN workspace root — the
    CLI's resolution (``cli._artefact_dir(ws)`` is this same call)."""
    from maestro.workspace import artefact_root_for

    workspace_root = Path(workspace_root)
    return artefact_root_for(workspace_root), workspace_root


def lead_paths_for_entry(entry: dict) -> "tuple[Path, Path]":
    """``(artefact_root, workspace_root)`` for a registry v2 entry — the Hub's
    resolution. The workspace root is
    :func:`maestro.workspace.artefact_parent_for_entry`, so a solo-mode
    workspace's daemon runs as ``--artefact-root <root>/.mso --workspace
    <root>``, exactly as ``mso lead start`` run from that root launches it."""
    from maestro.workspace import artefact_parent_for_entry

    return lead_paths_for_workspace_root(artefact_parent_for_entry(entry))


class _Collector:
    """The ``say`` sink handed to :mod:`maestro.lead.daemon`."""

    def __init__(self, result: LeadControlResult) -> None:
        self._result = result

    def __call__(self, message: str, err: bool = False) -> None:
        (self._result.errors if err else self._result.messages).append(message)


def _live_pid(artefact_root: Path) -> "tuple[bool, Optional[int]]":
    running, pid = proc_identity.is_running(_daemon._pid_file(artefact_root))
    return bool(running), (pid if running else None)


def _record(
    artefact_root: Path,
    workspace_root: Optional[Path],
    *,
    event_type: str,
    message: str,
    audit_action: str,
    actor: str,
    result: str,
    metadata: dict,
) -> None:
    """Write the lifecycle line and the audit entry. Never raises: a logging
    failure must not turn a daemon that DID start into a reported failure."""
    try:
        from maestro.core.fleet_runner import write_lifecycle_event

        write_lifecycle_event(event_type, message)
    except Exception:
        pass
    try:
        from maestro.audit import get_audit_log

        get_audit_log(workspace_root or artefact_root.parent).append(
            audit_action,
            target="lead",
            result=result,
            metadata={"via": actor, **metadata},
        )
    except Exception:
        pass


def start_lead(
    artefact_root: Path,
    workspace_root: Optional[Path] = None,
    *,
    force: bool = False,
    actor: str = ACTOR_CLI,
) -> LeadControlResult:
    """Start the LEAD daemon (``mso lead start``). Idempotent: an
    identity-verified live daemon is left alone unless *force*."""
    from maestro.core.order_retry import workspace_scope

    artefact_root = Path(artefact_root)
    with workspace_scope(artefact_root):
        was_running, prior_pid = _live_pid(artefact_root)
        result = LeadControlResult(action="start", outcome="started", ok=True, previous_pid=prior_pid)
        _daemon.start(artefact_root, workspace_root=workspace_root, force=force, say=_Collector(result))
        _, result.pid = _live_pid(artefact_root)

        if was_running and not force:
            result.outcome = "already_running"
            result.pid = prior_pid
            return result

        _record(
            artefact_root, workspace_root,
            event_type=EVENT_STARTED,
            message=f"LEAD daemon started by {actor} (PID {result.pid or 'unknown'})"
                    + (f", replacing PID {prior_pid} (--force)" if was_running else ""),
            audit_action="lead.start", actor=actor, result="ok",
            metadata={"pid": result.pid, "force": force},
        )
        return result


def stop_lead(artefact_root: Path, *, actor: str = ACTOR_CLI) -> LeadControlResult:
    """Stop the LEAD daemon (``mso lead stop``) and wait until it is confirmed
    gone. Never tier-gated by any caller."""
    from maestro.core.order_retry import workspace_scope

    artefact_root = Path(artefact_root)
    with workspace_scope(artefact_root):
        was_running, prior_pid = _live_pid(artefact_root)
        result = LeadControlResult(action="stop", outcome="stopped", ok=True, previous_pid=prior_pid)
        confirmed = _daemon.stop(artefact_root, say=_Collector(result))

        if not confirmed:
            result.outcome, result.ok, result.pid = "stop_failed", False, prior_pid
            _record(
                artefact_root, None,
                event_type=EVENT_STOP_FAILED,
                message=f"LEAD daemon stop requested by {actor} could not be confirmed "
                        f"(PID {prior_pid or 'unknown'} still running)",
                audit_action="lead.stop", actor=actor, result="error",
                metadata={"pid": prior_pid},
            )
        elif not was_running:
            result.outcome = "not_running"
        else:
            _record(
                artefact_root, None,
                event_type=EVENT_STOPPED,
                message=f"LEAD daemon stopped by {actor} (PID {prior_pid})",
                audit_action="lead.stop", actor=actor, result="ok",
                metadata={"pid": prior_pid},
            )
        return result


def restart_lead(
    artefact_root: Path,
    workspace_root: Optional[Path] = None,
    *,
    actor: str = ACTOR_CLI,
) -> LeadControlResult:
    """Stop-then-start (``mso lead restart``). No replacement is launched
    unless the old daemon was confirmed gone."""
    from maestro.core.order_retry import workspace_scope

    artefact_root = Path(artefact_root)
    with workspace_scope(artefact_root):
        was_running, prior_pid = _live_pid(artefact_root)
        result = LeadControlResult(action="restart", outcome="restarted", ok=True, previous_pid=prior_pid)
        replaced = _daemon.restart(artefact_root, workspace_root=workspace_root, say=_Collector(result))
        _, result.pid = _live_pid(artefact_root)

        if not replaced:
            result.outcome, result.ok, result.pid = "stop_failed", False, prior_pid
            _record(
                artefact_root, workspace_root,
                event_type=EVENT_STOP_FAILED,
                message=f"LEAD daemon restart requested by {actor} could not stop "
                        f"PID {prior_pid or 'unknown'}; no replacement launched",
                audit_action="lead.restart", actor=actor, result="error",
                metadata={"pid": prior_pid},
            )
            return result

        if was_running:
            _record(
                artefact_root, workspace_root,
                event_type=EVENT_STOPPED,
                message=f"LEAD daemon stopped by {actor} for restart (PID {prior_pid})",
                audit_action="lead.stop", actor=actor, result="ok",
                metadata={"pid": prior_pid, "restart": True},
            )
        _record(
            artefact_root, workspace_root,
            event_type=EVENT_STARTED,
            message=f"LEAD daemon started by {actor} for restart (PID {result.pid or 'unknown'})",
            audit_action="lead.restart", actor=actor, result="ok",
            metadata={"pid": result.pid, "previousPid": prior_pid},
        )
        return result
