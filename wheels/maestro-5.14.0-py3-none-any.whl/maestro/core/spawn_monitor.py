"""The ``spawnMonitor`` machine preference — ONE resolver, ONE writer.

FTR-MSO-2026-0406 built the switch that stops ``mso dispatch`` auto-spawning
the terminal status monitor (``fleet_monitor.py``)::

    env MAESTRO_SPAWN_MONITOR  >  ~/.maestro/config/settings.json `spawnMonitor`  >  True

FTR-MSO-2026-0635 exposes it in the Maestro Hub. The dispatcher
(``fleet_runner._spawn_monitor_enabled``) and the Hub
(``GET/PUT /api/v1/machine/spawn-monitor``) both call :func:`resolve` here, so
the value the Hub SHOWS and the value the next dispatch ACTS ON are one
computation, not two that can drift.

Scope is deliberately still MACHINE-LEVEL (option (a) of FTR-0635's scope
question). Whether a terminal window makes sense is a property of how this
device is used — a headless dispatch host driven via the Hub, or a desk with
a terminal open — not of which workspace happens to be dispatching. A
per-workspace override would let two projects on one device disagree about a
window, and would add a precedence layer an operator has to reason about for
the sake of a cosmetic preference. The Hub control states that scope before
the click.

Contract (the shared-core shape, see CLAUDE.md "Shared cores"):

- :func:`resolve` never raises. A missing, unreadable or malformed
  ``settings.json`` resolves to the default, exactly as FTR-0406 shipped, and
  the problem is REPORTED (``settings_error``) rather than swallowed.
- :func:`set_spawn_monitor` raises :class:`SpawnMonitorSettingError` rather
  than overwrite a ``settings.json`` it could not parse — the file is
  device-global and may carry keys this module does not own.
- No printing, no ``sys.exit``, no workspace resolution: the file lives under
  ``get_maestro_home()``, which is the only input.
- The setting is read fresh on every call; nothing is cached, so a change
  takes effect for the NEXT dispatch without restarting anything.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping, Optional

ENV_VAR = "MAESTRO_SPAWN_MONITOR"
SETTING_KEY = "spawnMonitor"

# FTR-0406's falsy spellings, verbatim. Any other non-empty value is truthy.
_ENV_FALSE_VALUES = ("0", "false", "False", "no", "off")

SOURCE_ENV = "env"
SOURCE_SETTINGS = "settings"
SOURCE_DEFAULT = "default"


class SpawnMonitorSettingError(Exception):
    """The machine settings file could not be safely rewritten."""


@dataclass(frozen=True)
class SpawnMonitorResolution:
    """Everything needed to report the preference honestly.

    ``effective`` is what the next dispatch run in THIS process's environment
    will do. ``source`` names which precedence layer decided it. ``saved_value``
    is the ``settings.json`` value (``None`` when the key or file is absent or
    unreadable) — reported separately so a UI can say "saved: off, but the
    environment forces on" instead of showing one number that hides the other.
    """

    effective: bool
    source: str
    env_value: Optional[str]
    saved_value: Optional[bool]
    settings_path: Path
    settings_error: Optional[str] = None


def settings_path() -> Path:
    """``~/.maestro/config/settings.json`` (``MAESTRO_HOME``-aware)."""
    from maestro.workspace import get_maestro_home

    return get_maestro_home() / "config" / "settings.json"


def _read_settings(path: Path) -> tuple[Optional[dict], Optional[str]]:
    """``(settings_dict_or_None, error_or_None)``. Absent file is not an error."""
    if not path.exists():
        return None, None
    try:
        cfg = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        return None, f"{path} could not be read ({exc.__class__.__name__}: {exc})"
    if not isinstance(cfg, dict):
        return None, f"{path} does not contain a JSON object"
    return cfg, None


def resolve(environ: Optional[Mapping[str, str]] = None) -> SpawnMonitorResolution:
    """Resolve the effective preference. Never raises."""
    env = os.environ if environ is None else environ
    env_raw = (env.get(ENV_VAR) or "").strip()

    try:
        path = settings_path()
    except Exception as exc:  # pragma: no cover - home resolution is trivial
        return SpawnMonitorResolution(
            effective=(env_raw not in _ENV_FALSE_VALUES) if env_raw else True,
            source=SOURCE_ENV if env_raw else SOURCE_DEFAULT,
            env_value=env_raw or None,
            saved_value=None,
            settings_path=Path("~/.maestro/config/settings.json"),
            settings_error=f"Maestro home could not be resolved: {exc}",
        )

    cfg, error = _read_settings(path)
    saved: Optional[bool] = None
    if cfg is not None and SETTING_KEY in cfg:
        # bool() on the raw value, exactly as FTR-0406 evaluated it.
        saved = bool(cfg[SETTING_KEY])

    if env_raw:
        effective, source = env_raw not in _ENV_FALSE_VALUES, SOURCE_ENV
    elif saved is not None:
        effective, source = saved, SOURCE_SETTINGS
    else:
        effective, source = True, SOURCE_DEFAULT

    return SpawnMonitorResolution(
        effective=effective,
        source=source,
        env_value=env_raw or None,
        saved_value=saved,
        settings_path=path,
        settings_error=error,
    )


def set_spawn_monitor(
    value: Optional[bool], environ: Optional[Mapping[str, str]] = None
) -> SpawnMonitorResolution:
    """Save (``True``/``False``) or clear (``None``) the machine preference.

    Every other key in ``settings.json`` is preserved. The write is atomic
    (sibling temp file + ``os.replace``). Returns the resolution read back
    AFTER the write, so a caller reports what is now true rather than what it
    asked for — including when an environment override means the saved value
    changes nothing.
    """
    if value is not None and not isinstance(value, bool):
        raise SpawnMonitorSettingError(f"{SETTING_KEY} must be true, false or null")

    path = settings_path()
    cfg, error = _read_settings(path)
    if error is not None:
        raise SpawnMonitorSettingError(
            f"Refusing to rewrite the machine settings file: {error}. "
            "Fix or remove the file, then retry."
        )
    cfg = dict(cfg or {})

    if value is None:
        if SETTING_KEY not in cfg:
            return resolve(environ)
        cfg.pop(SETTING_KEY)
    else:
        cfg[SETTING_KEY] = value

    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        tmp.write_text(json.dumps(cfg, indent=2) + "\n", encoding="utf-8")
        os.replace(tmp, path)
    finally:
        if tmp.exists():
            try:
                tmp.unlink()
            except OSError:
                pass

    return resolve(environ)
