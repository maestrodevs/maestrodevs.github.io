"""maestro.core.temp_paths — where ``$MAESTRO_TEMP`` points (BUG-MSO-2026-0701).

``MAESTRO_TEMP`` is the centralised scratch space every crew is told to use for
build output, local NuGet workarounds and other throwaway artefacts (see the
crew prompt in ``fleet_runner`` and the role docs). Until this bug it defaulted
to ``<installed package dir>/temp`` — i.e. INSIDE site-packages — which is:

* the exact directory shape the 2026-08-17 136 MB shadowing incident and
  BUG-MSO-2026-0614's 110 MB repeat both took, so ``machine.package-integrity``
  raised a CRITICAL finding on it on EVERY LEAD tick, permanently, with no
  action the operator could take. A permanently-critical finding nobody can act
  on is noise that hides real findings.
* unbounded: on 2026-09-08 a single crew's test run grew it from 287 files
  (18 MB) to 11,575 files (1.2 GB) inside the Python environment.
* wiped by any ``pip install``, and shared across every workspace on the machine.

The default is now ``<artefact root>/temp`` — the gitignored runtime plane that
already holds ``crews/``, ``logs/`` and ``state/``, and which resolves correctly
in embedded, solo and shared artefact-repo modes (``get_artefact_root()`` is the
one resolver that honours the ``artefacts`` block). An explicit ``MAESTRO_TEMP``
in the environment still wins — this module only supplies the DEFAULT.

The module also carries the leftover-reporting helpers used by the dispatcher
startup notice and by ``machine.package-integrity``, so both describe an old
``<package>/temp`` the same way and hand the operator the same delete command.
"""

from __future__ import annotations

import os
import tempfile
from pathlib import Path
from typing import Mapping, NamedTuple, Optional

#: Directory name used for the scratch space under whichever root wins.
TEMP_DIRNAME = "temp"

#: The order that fixed the in-package default. Named in operator-facing
#: messages so a leftover directory is traceable to why it is no longer grown.
FIXED_IN_ORDER = "BUG-MSO-2026-0701"


# ---------------------------------------------------------------------------
# Default resolution
# ---------------------------------------------------------------------------

def resolve_temp_dir(
    artefact_root: Optional[Path] = None,
    env: Optional[Mapping[str, str]] = None,
) -> Path:
    """Return the directory ``$MAESTRO_TEMP`` should point at.

    Resolution order:

    1. An explicit non-empty ``MAESTRO_TEMP`` in *env* (defaults to the real
       process environment) — the operator's choice always wins.
    2. ``<artefact root>/temp``. *artefact_root* is passed in by callers that
       have already resolved it (``crew.invoke_claude``, which must go through
       ``crew.get_artefact_root`` so tests monkeypatching ``get_workspace_dir``
       keep working); otherwise it is taken from the ``MAESTRO_ARTEFACT_ROOT``
       the dispatcher stamps into every crew env, and failing that resolved
       lazily via :func:`maestro.workspace.get_artefact_root`.
    3. ``<system temp>/maestro`` — a last-resort fallback used only when no
       workspace can be resolved at all (a bare ``crew.py`` invoked outside any
       ``.mso`` tree). Deliberately NOT the installed package directory: this
       function must never hand back a path inside site-packages, which is the
       whole point of the bug.

    Never raises.
    """
    source = os.environ if env is None else env
    explicit = (source.get("MAESTRO_TEMP") or "").strip()
    if explicit:
        try:
            return Path(explicit)
        except Exception:
            pass  # unusable value — fall through to the computed default

    if artefact_root is None:
        # The dispatcher stamps MAESTRO_ARTEFACT_ROOT into every crew env
        # (fleet_runner `crew_env`), so honour it before falling back to a
        # cwd-sensitive walk-up — a crew's cwd is its worktree, whose own
        # throwaway `.mso` mirror is NOT the artefact plane (BUG-MSO-2026-0465).
        stamped = (source.get("MAESTRO_ARTEFACT_ROOT") or "").strip()
        if stamped:
            try:
                artefact_root = Path(stamped)
            except Exception:
                artefact_root = None
    if artefact_root is None:
        try:
            from maestro.workspace import get_artefact_root

            artefact_root = get_artefact_root()
        except Exception:
            artefact_root = None

    if artefact_root is not None:
        try:
            return Path(artefact_root) / TEMP_DIRNAME
        except Exception:
            pass

    return Path(tempfile.gettempdir()) / "maestro"


def ensure_temp_dir(path: Path) -> Path:
    """Best-effort ``mkdir -p`` on the resolved temp dir, returning *path*.

    Crews are told to write into ``$MAESTRO_TEMP/<subdir>/``; creating the root
    up front means the first such write does not have to. A failure here is
    never fatal — the crew's own write will surface the real problem.
    """
    try:
        Path(path).mkdir(parents=True, exist_ok=True)
    except Exception:
        pass
    return path


# ---------------------------------------------------------------------------
# Leftover <package>/temp reporting
# ---------------------------------------------------------------------------

class LegacyTempReport(NamedTuple):
    """A leftover ``<installed package>/temp`` directory, measured."""

    path: Path
    entries: int
    size_bytes: int
    delete_command: str

    @property
    def size_mb(self) -> float:
        return self.size_bytes / (1024 * 1024)

    def one_line(self) -> str:
        """The single operator-facing sentence, identical wherever it is shown."""
        return (
            f"Leftover scratch directory inside the installed Maestro package: "
            f"{self.path} ({self.entries} entries, {self.size_mb:.1f} MB). "
            f"MAESTRO_TEMP no longer defaults there ({FIXED_IN_ORDER}) — nothing "
            f"writes to it any more, so it is safe to delete: {self.delete_command}"
        )


def dir_entry_count_and_size(path: Path) -> "tuple[int, int]":
    """``(entry count, total bytes)`` for *path*, best-effort.

    Unreadable entries are skipped rather than raising — this is used from a
    read-only patrol check and from dispatcher startup, neither of which may
    fail because of a permission error on someone else's debris.
    """
    count = 0
    size = 0
    try:
        for p in Path(path).rglob("*"):
            count += 1
            try:
                if p.is_file():
                    size += p.stat().st_size
            except OSError:
                pass
    except OSError:
        pass
    return count, size


def delete_command_for(path: Path) -> str:
    """The exact shell command to remove *path*, for the operator's platform."""
    if os.name == "nt":
        return f'Remove-Item -Recurse -Force "{path}"'
    # Org policy (no-recursive-force-remove): never hand the operator a
    # recursive force-delete string; a Python rmtree is the sanctioned form.
    return f"python3 -c \"import shutil; shutil.rmtree({str(path)!r})\""


def legacy_package_temp_dir(pkg_dir: Optional[Path] = None) -> Optional[Path]:
    """``<installed package dir>/temp`` — the pre-BUG-MSO-2026-0701 default.

    *pkg_dir* lets a caller that has already resolved the package directory
    (``check_package_integrity()``) pass it in rather than re-importing.
    Returns ``None`` when the package directory cannot be determined.
    """
    if pkg_dir is None:
        try:
            import maestro as _pkg

            pkg_file = getattr(_pkg, "__file__", None)
            if not pkg_file:
                return None
            pkg_dir = Path(pkg_file).resolve().parent
        except Exception:
            return None
    try:
        return Path(pkg_dir) / TEMP_DIRNAME
    except Exception:
        return None


def describe_legacy_package_temp(
    pkg_dir: Optional[Path] = None,
) -> Optional[LegacyTempReport]:
    """Measure a leftover ``<package>/temp``, or ``None`` if there isn't one.

    Never raises — a caller may run this on dispatcher startup or inside a
    patrol check, and neither is allowed to die over a stale directory.
    """
    try:
        path = legacy_package_temp_dir(pkg_dir)
        if path is None or not path.is_dir():
            return None
        entries, size = dir_entry_count_and_size(path)
        return LegacyTempReport(
            path=path,
            entries=entries,
            size_bytes=size,
            delete_command=delete_command_for(path),
        )
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Untracked top-level package entries (BUG-MSO-2026-0816)
# ---------------------------------------------------------------------------
#
# `<package>/temp` is only ONE shape of crew debris. PLAN-BUG-MSO-2026-0807 F3
# found root-level `*.log`, `csp-verify/` and `qa0701/` sitting directly in the
# installed package for a week, invisible to `mso doctor` because the check only
# ever looked at `temp/`. The installer's own manifest — the dist-info `RECORD`
# — is the authoritative list of what belongs there, so anything at the top
# level that no RECORD names is debris by definition. The same property is what
# made F1's diagnosis possible: a `pip uninstall` removes exactly the RECORD's
# files, so these untracked entries are also what survives one.

#: Top-level names never reported as untracked: bytecode caches are created at
#: import time on any install, and ``temp`` has its own, older report above.
_UNTRACKED_IGNORED = frozenset({"__pycache__", TEMP_DIRNAME})

#: How many entries the one-line description names before summarising the rest.
_UNTRACKED_NAMED_LIMIT = 10


class UntrackedEntry(NamedTuple):
    """One top-level package entry that no installer RECORD lists, measured."""

    path: Path
    is_dir: bool
    size_bytes: int


class UntrackedPackageReport(NamedTuple):
    """Top-level entries of the installed package dir absent from its RECORD."""

    pkg_dir: Path
    record_paths: "tuple[Path, ...]"
    entries: "tuple[UntrackedEntry, ...]"
    delete_command: str

    @property
    def size_bytes(self) -> int:
        return sum(e.size_bytes for e in self.entries)

    @property
    def size_mb(self) -> float:
        return self.size_bytes / (1024 * 1024)

    def one_line(self) -> str:
        """The single operator-facing sentence (no newlines)."""
        named = [
            f"{e.path.name}{'/' if e.is_dir else ''} ({_human_size(e.size_bytes)})"
            for e in self.entries[:_UNTRACKED_NAMED_LIMIT]
        ]
        more = len(self.entries) - len(named)
        if more > 0:
            named.append(f"and {more} more")
        return (
            f"{len(self.entries)} top-level entr{'y' if len(self.entries) == 1 else 'ies'} "
            f"in the installed Maestro package {self.pkg_dir} are not listed in the "
            f"installer's RECORD manifest, so no install put them there "
            f"({_human_size(self.size_bytes)} total): {', '.join(named)}. This is crew or "
            f"tool debris (BUG-MSO-2026-0816); safe to delete: {self.delete_command}"
        )


def _human_size(size_bytes: int) -> str:
    """``12.3 MB`` / ``4.0 KB`` — a small log must not read as ``0.0 MB``."""
    if size_bytes >= 1024 * 1024:
        return f"{size_bytes / (1024 * 1024):.1f} MB"
    return f"{size_bytes / 1024:.1f} KB"


def _record_files(pkg_dir: Path) -> "list[Path]":
    """``RECORD`` files of every dist-info beside *pkg_dir* that could own it.

    Matches ``<name>-*.dist-info`` and ``<name>_*.dist-info`` so both the
    private-index ``maestro-X.dist-info`` and the public ``maestro_fleet-X``
    distribution are found."""
    parent = Path(pkg_dir).parent
    name = Path(pkg_dir).name
    found: "list[Path]" = []
    for pattern in (f"{name}-*.dist-info", f"{name}_*.dist-info"):
        for d in sorted(parent.glob(pattern)):
            rec = d / "RECORD"
            if rec.is_file() and rec not in found:
                found.append(rec)
    return found


def _record_top_level_names(record: Path, pkg_name: str) -> "set[str]":
    """Top-level names under ``<pkg_name>/`` that *record* lists."""
    import csv

    names: "set[str]" = set()
    with open(record, "r", encoding="utf-8", newline="") as fh:
        for row in csv.reader(fh):
            if not row:
                continue
            parts = row[0].replace("\\", "/").split("/")
            if len(parts) >= 2 and parts[0] == pkg_name and parts[1]:
                names.add(parts[1])
    return names


def describe_untracked_package_entries(
    pkg_dir: Optional[Path],
) -> Optional[UntrackedPackageReport]:
    """Report top-level entries of *pkg_dir* that no installer RECORD lists.

    Returns ``None`` — reports nothing, never guesses — when there is no basis
    for the comparison: *pkg_dir* unknown or missing, no ``RECORD`` beside it
    (an editable/dev checkout, or a source tree), or a RECORD that lists
    nothing under the package (an editable install's RECORD only names its
    ``.pth``/finder shim, so treating every real module as untracked would be
    exactly wrong). Also ``None`` when nothing is untracked.

    ``temp/`` and ``__pycache__/`` are never included (see
    ``_UNTRACKED_IGNORED``). Never raises.
    """
    try:
        if pkg_dir is None:
            return None
        pkg_dir = Path(pkg_dir)
        if not pkg_dir.is_dir():
            return None
        records = _record_files(pkg_dir)
        if not records:
            return None
        tracked: "set[str]" = set()
        for rec in records:
            try:
                tracked |= _record_top_level_names(rec, pkg_dir.name)
            except (OSError, UnicodeDecodeError, ValueError):
                continue
        if not tracked:
            return None

        entries: "list[UntrackedEntry]" = []
        for child in sorted(pkg_dir.iterdir(), key=lambda p: p.name.lower()):
            if child.name in tracked or child.name in _UNTRACKED_IGNORED:
                continue
            try:
                if child.is_dir():
                    _, size = dir_entry_count_and_size(child)
                    entries.append(UntrackedEntry(child, True, size))
                else:
                    entries.append(UntrackedEntry(child, False, child.stat().st_size))
            except OSError:
                entries.append(UntrackedEntry(child, False, 0))
        if not entries:
            return None
        return UntrackedPackageReport(
            pkg_dir=pkg_dir,
            record_paths=tuple(records),
            entries=tuple(entries),
            delete_command=delete_command_for_many([e.path for e in entries]),
        )
    except Exception:
        return None


def delete_command_for_many(paths: "list[Path]") -> str:
    """One shell command removing every path in *paths* (files or dirs)."""
    if os.name == "nt":
        return "Remove-Item -Recurse -Force " + ", ".join(f'"{p}"' for p in paths)
    # Same org policy as delete_command_for: a Python rmtree, never a raw
    # recursive-force shell remove.
    listed = ", ".join(repr(str(p)) for p in paths)
    return (
        "python3 -c \"import os, shutil; "
        f"[shutil.rmtree(p) if os.path.isdir(p) else os.remove(p) for p in [{listed}]]\""
    )
