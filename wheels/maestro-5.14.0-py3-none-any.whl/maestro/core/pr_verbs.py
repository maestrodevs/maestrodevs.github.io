"""maestro/core/pr_verbs.py — the one implementation of ``mso pr …``.

FTR-MSO-2026-0760 / PLAN-PLN-MSO-2026-0747 §3 (D2). The voyage-level REL pass
reaches its PR only through these verbs — never through raw ``gh`` or a
provider's REST API — so the same instruction works on every SCM/CI provider,
and so the scope rules below are enforced in Python rather than guessed at by a
branch-guard regex over arbitrary shell commands:

1. **The PR comes from the voyage branch, never from an argument.** It is the
   PR for ``$MAESTRO_VOYAGE_BRANCH`` (legacy ``$MAESTRO_SPRINT_BRANCH``), read
   from this process's environment. No verb accepts a PR number. The
   environment alone does not bind the scope — a process can be started with
   any value — so for a crew the binding is the pretool branch guard, which
   inherits the environment the DISPATCHER set and refuses a command that
   re-points either variable for an ``mso pr`` call (BUG-MSO-2026-0778). Like
   every branch-guard rule that is a regex over a shell string, not a security
   boundary; rules 2 and 3 hold whichever branch is named.
2. **A thread must be on that PR.** ``reply`` and ``resolve`` refuse a thread
   id the provider does not list for it — including when the provider could
   not list threads at all (fail closed).
3. **Only automated reviewers' threads are resolvable.** ``resolve`` refuses a
   thread whose author is not in ``providers.scm.config.reviewBots`` (the
   provider's default when unset). A human reviewer's thread is the Captain's.

Nothing here lands, tags or publishes anything; the providers expose no such
capability to call.

Shared-core contract (see ``order_retry.py``): explicit workspace path, typed
exceptions, no printing, no ``sys.exit``.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Mapping, Optional

from maestro.providers.base import PR_KEYS, STATUS_OK, ActionResult

VOYAGE_BRANCH_ENV_VARS = ("MAESTRO_VOYAGE_BRANCH", "MAESTRO_SPRINT_BRANCH")


class PrVerbError(Exception):
    """Base for every refusal/failure a ``mso pr`` verb raises."""

    hint: Optional[str] = None

    def __init__(self, message: str, hint: Optional[str] = None) -> None:
        super().__init__(message)
        if hint is not None:
            self.hint = hint


class NoVoyageBranch(PrVerbError):
    hint = "Set MAESTRO_VOYAGE_BRANCH to the voyage branch (the dispatcher sets it for every crew)."


class ProviderUnavailable(PrVerbError):
    hint = "Run `mso doctor --explain` to see how providers resolved for this workspace."


class PrNotFound(PrVerbError):
    pass


class ProviderLookupFailed(PrVerbError):
    hint = ("The provider could not answer, which is NOT the same as 'none'. Check `gh auth status` "
            "and connectivity, then retry; until it answers, report this item as SKIPPED with the reason.")


class ThreadNotOnPr(PrVerbError):
    hint = "Run `mso pr threads` to list the threads on the voyage PR."


class ThreadNotResolvable(PrVerbError):
    hint = ("Only threads from automated reviewers listed in providers.scm.config.reviewBots "
            "may be resolved by `mso pr resolve`; a human reviewer's thread stays for the Captain.")


def voyage_branch(env: Optional[Mapping[str, str]] = None) -> str:
    source = os.environ if env is None else env
    for key in VOYAGE_BRANCH_ENV_VARS:
        value = (source.get(key) or "").strip()
        if value:
            return value
    raise NoVoyageBranch("no voyage branch: MAESTRO_VOYAGE_BRANCH is not set")


def _resolved(kind: str, workspace: Path):
    from maestro.providers import resolve_explain

    resolved = resolve_explain(kind, workspace=workspace)
    if not resolved.available or resolved.provider is None:
        raise ProviderUnavailable(f"{kind} provider unavailable: {resolved.reason}")
    return resolved


def voyage_pr(workspace: Path, env: Optional[Mapping[str, str]] = None):
    """``(resolved_scm, branch, pr)`` for the voyage branch, or raise."""
    branch = voyage_branch(env)
    scm = _resolved("scm", workspace)
    pr = scm.provider.get_pr_for_branch(branch)
    if not pr:
        raise PrNotFound(f"no pull request found for voyage branch '{branch}' via the '{scm.provider_id}' provider")
    return scm, branch, pr


def _checked(result, what: str, provider_id: str) -> list:
    items, err = result
    if items is None:
        raise ProviderLookupFailed(
            f"could not list {what} via the '{provider_id}' provider: {err or 'unknown error'}")
    return items


def _pr_summary(pr: dict) -> dict:
    return {key: pr.get(key) for key in PR_KEYS}


def pr_status(workspace: Path, env: Optional[Mapping[str, str]] = None) -> dict:
    scm, branch, pr = voyage_pr(workspace, env)
    return {"provider": scm.provider_id, "tier": scm.tier, "branch": branch, "pr": _pr_summary(pr)}


def pr_checks(workspace: Path, env: Optional[Mapping[str, str]] = None) -> dict:
    scm, branch, pr = voyage_pr(workspace, env)
    ci = _resolved("ci", workspace)
    return {
        "provider": ci.provider_id, "tier": ci.tier, "branch": branch, "pr": _pr_summary(pr),
        "checks": _checked(ci.provider.checks_for_pr_checked(pr), "CI checks", ci.provider_id),
    }


def pr_ci_log(workspace: Path, check: str, env: Optional[Mapping[str, str]] = None) -> ActionResult:
    _scm, _branch, pr = voyage_pr(workspace, env)
    ci = _resolved("ci", workspace)
    return ci.provider.failed_log(pr, check)


def _bot_set(scm) -> set[str]:
    return {b.casefold() for b in scm.provider.review_bots()}


def pr_threads(workspace: Path, env: Optional[Mapping[str, str]] = None) -> dict:
    scm, branch, pr = voyage_pr(workspace, env)
    bots = _bot_set(scm)
    threads = []
    for thread in _checked(scm.provider.pr_review_threads_checked(pr), "review threads", scm.provider_id):
        author = thread.get("author") or ""
        threads.append({**thread, "fromReviewBot": bool(author) and author.casefold() in bots})
    return {
        "provider": scm.provider_id, "branch": branch, "pr": _pr_summary(pr),
        "reviewBots": scm.provider.review_bots(), "threads": threads,
    }


def _thread_on_pr(scm, branch: str, pr: dict, thread_id: str) -> dict:
    threads = _checked(scm.provider.pr_review_threads_checked(pr), "review threads", scm.provider_id)
    for thread in threads:
        if thread.get("id") == thread_id:
            return thread
    raise ThreadNotOnPr(
        f"refused: thread '{thread_id}' is not a review thread on PR {pr.get('id')} for voyage "
        f"branch '{branch}' ({len(threads)} thread(s) listed)"
    )


def pr_reply(workspace: Path, thread_id: str, body: str, env: Optional[Mapping[str, str]] = None) -> ActionResult:
    scm, branch, pr = voyage_pr(workspace, env)
    _thread_on_pr(scm, branch, pr, thread_id)
    return scm.provider.reply_to_thread(pr, thread_id, body)


def pr_resolve(workspace: Path, thread_id: str, env: Optional[Mapping[str, str]] = None) -> ActionResult:
    scm, branch, pr = voyage_pr(workspace, env)
    thread = _thread_on_pr(scm, branch, pr, thread_id)
    author = thread.get("author") or ""
    if not author or author.casefold() not in _bot_set(scm):
        bots = ", ".join(scm.provider.review_bots()) or "none configured"
        raise ThreadNotResolvable(
            f"refused: thread '{thread_id}' was opened by '{author or 'unknown'}', which is not an "
            f"automated reviewer in reviewBots ({bots})"
        )
    if thread.get("isResolved"):
        return ActionResult(STATUS_OK, "thread was already resolved; nothing changed",
                            {"id": thread_id, "isResolved": True})
    return scm.provider.resolve_thread(pr, thread_id)
