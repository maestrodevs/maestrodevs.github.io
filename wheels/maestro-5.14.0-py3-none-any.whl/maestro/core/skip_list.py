"""Operator skip-list — shared reader (BUG-MSO-2026-0451).

``.mso/config/skipped-orders.json`` is written by ``mso order skip`` (via
``fleet_runner.add_skipped_order``) and consulted by the dispatcher
(``fleet_runner.scan_all_queues``) to silently drop an order from dispatch.
Out-of-process readers — ``mso status`` (fleet_monitor) and the Hub
aggregator — used to have NO knowledge of the skip list at all, so a
skipped order kept showing as plain "N pending": the same conflation GitHub
issue #202 reported for dependency-held orders (fixed for that case in
BUG-MSO-2026-0349 via ``dep_holds.py``).

This module holds the READ side of the skip-list schema (normalisation
across the two on-disk shapes — see BUG-MSO-2026-0433) as a small,
path-parameterised, side-effect-free function set, so every consumer applies
the IDENTICAL "is this order operator-skipped" rule instead of re-deriving
it — two implementations of "is this dispatchable" drift (the lesson of this
very bug). ``fleet_runner`` delegates its own ``load_skipped_orders()`` to
``normalise_skipped_orders()`` here rather than keeping a second copy.

Mutation (skip / unskip) lives here too, as of FTR-MSO-2026-0721 —
:func:`add_skipped_order` / :func:`remove_skipped_order`.  It used to live on
``fleet_runner``, which resolves its target through the process-global
``get_artefact_root()``; that is unusable from the Hub, which serves N
registered workspaces from ONE process and must name the plane it is writing
to.  Both functions here take an explicit ``workspace_dir``, exactly like the
readers above, and ``fleet_runner`` now delegates to them — so the CLI verb
``mso order skip`` and ``POST /api/v1/orders/{id}/skip`` write through the same
code, and a skip made on one surface is a skip everywhere.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional, Set


def skipped_orders_path(workspace_dir: Path) -> Path:
    """Path to the persisted operator skip list under a given workspace root."""
    return workspace_dir / "config" / "skipped-orders.json"


def normalise_skip_entry(value: Any) -> Dict[str, Any]:
    """Coerce one skip-list entry's metadata to a dict (BUG-MSO-2026-0433)."""
    if isinstance(value, dict):
        return value
    if isinstance(value, str) and value.strip():
        # A bare string in the value slot is most usefully read as the reason.
        return {"reason": value}
    return {}


def normalise_skipped_orders(doc: Any) -> Dict[str, Dict[str, Any]]:
    """Normalise any known on-disk skip-list shape to the canonical flat map.

    BUG-MSO-2026-0433: two schemas exist in the wild —

      A) flat map keyed by order id (what ``mso order skip`` writes):
         ``{"PLN-MSO-2026-0340": {"skippedAt": ..., "reason": ...}, ...}``
      B) wrapped list (seen in the live PSG workspace):
         ``{"skipped": [...]}`` where entries are either bare order-id
         strings or objects carrying an id field.

    Both normalise to ``{order_id: meta_dict}`` so callers only ever handle
    one shape. Anything unrecognised degrades to ``{}`` — a malformed
    operator config must never crash a read-only listing command.
    """
    if isinstance(doc, dict) and isinstance(doc.get("skipped"), list):
        doc = doc["skipped"]  # schema B — unwrap to the bare list below

    if isinstance(doc, list):
        out: Dict[str, Dict[str, Any]] = {}
        for entry in doc:
            if isinstance(entry, str) and entry.strip():
                out.setdefault(entry.strip(), {})
            elif isinstance(entry, dict):
                oid = (entry.get("id") or entry.get("orderId")
                       or entry.get("order_id") or entry.get("orderID") or "")
                if isinstance(oid, str) and oid.strip():
                    meta = {k: v for k, v in entry.items()
                            if k not in ("id", "orderId", "order_id", "orderID")}
                    out[oid.strip()] = meta
        return out

    if isinstance(doc, dict):
        # Schema A. Drop non-string keys and coerce each value to a dict.
        return {
            str(k): normalise_skip_entry(v)
            for k, v in doc.items()
            if isinstance(k, str) and k.strip()
        }

    return {}


def has_skip_content(doc: Any) -> bool:
    """True if the raw document looked like it held entries we failed to read."""
    if isinstance(doc, dict) and isinstance(doc.get("skipped"), list):
        return bool(doc["skipped"])
    if isinstance(doc, (dict, list)):
        return bool(doc)
    return doc is not None


def read_skipped_orders(workspace_dir: Path) -> Dict[str, Dict[str, Any]]:
    """Read + normalise the skip list at ``workspace_dir``. {} on any error.

    Pure read, no diagnostics — safe for a multi-workspace server context
    (the Hub aggregator reads many workspace roots per request). The
    operator-facing WARN on a malformed file stays on
    ``fleet_runner.load_skipped_orders()``, which wraps this with its own
    workspace resolution.
    """
    try:
        raw = skipped_orders_path(workspace_dir).read_text(encoding="utf-8")
    except OSError:
        return {}
    try:
        doc = json.loads(raw)
    except Exception:
        return {}
    return normalise_skipped_orders(doc)


def read_skipped_order_ids(workspace_dir: Path) -> Set[str]:
    """Return the set of order IDs in the skip list at ``workspace_dir``."""
    return set(read_skipped_orders(workspace_dir).keys())


# ---------------------------------------------------------------------------
# Mutation (FTR-MSO-2026-0721) — path-parameterised, shared by CLI and Hub
# ---------------------------------------------------------------------------

def write_skipped_orders(workspace_dir: Path, data: Dict[str, Dict[str, Any]]) -> None:
    """Persist the canonical flat skip map to ``workspace_dir``.

    Always writes schema A (the flat ``{order_id: meta}`` map). A workspace
    carrying the legacy wrapped ``{"skipped": [...]}`` shape is therefore
    migrated on its first write — entries preserved, not dropped, because the
    caller read them back through :func:`read_skipped_orders`, which
    normalises both shapes. Reads keep tolerating both forever, so migration
    is never something an operator has to do.
    """
    path = skipped_orders_path(workspace_dir)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")


def add_skipped_order(workspace_dir: Path, order_id: str, *,
                      reason: str = "",
                      voyage_id: str = "",
                      skipped_by: str = "cli",
                      now: Optional[str] = None) -> Dict[str, Any]:
    """Upsert *order_id* into ``workspace_dir``'s skip list (BUG-MSO-2026-0288).

    Idempotent: a re-skip preserves the ORIGINAL ``skippedAt``, so "how long
    has this been parked" stays answerable after a second skip. Returns the
    entry as written, which is what an HTTP caller echoes back to the
    operator — the Hub must never report a timestamp it did not persist.
    """
    data = read_skipped_orders(workspace_dir)
    existing = data.get(order_id) or {}
    entry = {
        "skippedAt": (existing.get("skippedAt")
                      or now
                      or datetime.now(timezone.utc).isoformat()),
        "skippedBy": skipped_by,
        "reason": reason,
        "voyageId": voyage_id,
    }
    data[order_id] = entry
    write_skipped_orders(workspace_dir, data)
    return entry


def remove_skipped_order(workspace_dir: Path, order_id: str) -> bool:
    """Drop *order_id* from ``workspace_dir``'s skip list.

    Returns True only when the order was actually present. A caller reports
    that verbatim rather than claiming success either way: FTR-MSO-2026-0617's
    honesty rule — un-skipping an order that was never skipped changed
    nothing, and saying "removed" would send an operator away believing a
    dispatch veto had been lifted that was never there.
    """
    data = read_skipped_orders(workspace_dir)
    if order_id not in data:
        return False
    del data[order_id]
    write_skipped_orders(workspace_dir, data)
    return True
