"""Best-effort desktop notification on the host (BUG-MSO-2026-0713).

Why a THIRD channel
--------------------
On 2026-09-09 the LEAD daemon's patrol raised ``lead.dispatcher-watch:
Dispatcher is STOPPED`` at ``critical`` — correctly, on the very next tick. It
went to ``state.json`` and to the Hub strip. **The Hub was dead.** The
dispatcher stayed down for 56 minutes with two finished crews waiting to be
finalised, and it was found by a human noticing by accident.

A critical finding raised while the only rendering surface is dead is
indistinguishable from no finding at all. The bridge (Slack) already exists as
an alternate, but a workspace with no bridge configured — most of them — has
none. This module is the channel that needs nothing configured and nothing else
running: the operator's own desktop.

Contract
---------
* **Never raises.** Every entry point returns a bool and swallows everything.
  A notification failure inside a LEAD tick must be invisible.
* **Never hangs.** Every subprocess is bounded by :data:`_TIMEOUT_SECONDS`. A
  toast backend that blocks for a user response would otherwise wedge the
  daemon.
* **Never the only channel.** It fails open on a headless host, over SSH, in a
  container, or wherever no notifier exists — which is why
  ``lead.agent._notify_critical_finding`` fans out to every channel
  independently rather than stopping at the first success.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
from typing import Optional

from maestro.core.proc import popen_hidden, run_hidden

#: Wall-clock cap for any notifier invocation. Small on purpose: a notification
#: is worthless if delivering it costs the tick that raised it.
_TIMEOUT_SECONDS = 10


def _run(cmd, **kwargs) -> bool:
    try:
        proc = run_hidden(
            cmd,
            timeout=_TIMEOUT_SECONDS,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            **kwargs,
        )
        return proc.returncode == 0
    except Exception:
        return False


def _ps_quote(text: str) -> str:
    """Single-quote a string for PowerShell (doubling embedded quotes).

    The message is assembled from a finding's title and detail, which are
    Maestro-generated but can carry an operator's own order title — never
    interpolated raw into a shell.
    """
    return "'" + str(text).replace("'", "''") + "'"


def _notify_windows(title: str, message: str) -> bool:
    # BurntToast is the reliable Windows 10/11 toast route but is not installed
    # by default; a message box needs nothing at all and cannot be missed. The
    # box is shown from a DETACHED PowerShell so it never blocks this process
    # waiting for a click — the whole point of _TIMEOUT_SECONDS would be lost
    # if delivery waited on a human.
    script = (
        "Add-Type -AssemblyName System.Windows.Forms; "
        "[System.Windows.Forms.MessageBox]::Show("
        f"{_ps_quote(message)}, {_ps_quote(title)}, 'OK', 'Warning') | Out-Null"
    )
    try:
        popen_hidden(
            ["powershell", "-NoProfile", "-NonInteractive", "-WindowStyle", "Hidden",
             "-Command", script],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=0x00000008 | 0x08000000,  # DETACHED_PROCESS | CREATE_NO_WINDOW
        )
        return True
    except Exception:
        return False


def _notify_macos(title: str, message: str) -> bool:
    if not shutil.which("osascript"):
        return False
    safe_title = str(title).replace('"', "'")
    safe_message = str(message).replace('"', "'")
    return _run([
        "osascript", "-e",
        f'display notification "{safe_message}" with title "{safe_title}"',
    ])


def _notify_linux(title: str, message: str) -> bool:
    if not shutil.which("notify-send"):
        return False
    # A headless box has no session bus; notify-send then fails and this
    # returns False, which is the honest answer, not an error.
    return _run(["notify-send", "-u", "critical", str(title), str(message)])


def available() -> bool:
    """Is a notifier plausibly present? Advisory only — :func:`notify` still
    tries and still fails open, since presence never guarantees delivery (a
    headless session, a locked screen, a container with no bus)."""
    try:
        if sys.platform == "win32":
            return shutil.which("powershell") is not None
        if sys.platform == "darwin":
            return shutil.which("osascript") is not None
        return shutil.which("notify-send") is not None
    except Exception:
        return False


def notify(title: str, message: str, *, max_message_chars: int = 400) -> bool:
    """Show one host notification. ``True`` only if a notifier accepted it.

    ``MAESTRO_NO_HOST_NOTIFY=1`` disables the channel entirely — for CI, for a
    server, and for the test suite, which must never pop a window on the
    machine running it.
    """
    try:
        if os.environ.get("MAESTRO_NO_HOST_NOTIFY"):
            return False
        text = str(message or "")
        if len(text) > max_message_chars:
            text = text[: max_message_chars - 1] + "…"
        if sys.platform == "win32":
            return _notify_windows(title, text)
        if sys.platform == "darwin":
            return _notify_macos(title, text)
        return _notify_linux(title, text)
    except Exception:
        return False
