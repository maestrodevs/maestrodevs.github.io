# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Operator explainability: one "why is this stuck" model (FTR-MSO-2026-0700).

What this module answers
------------------------
For a single order, or a single voyage: **what is stuck, why, what evidence
proves it, and what are my options** — as one record, computed on read, from
the facts that already exist on the artefact plane.

Why it exists
-------------
On 2026-09-09 (the VOY-MSO-2026-0163 recovery this order was filed from) four
crews ran overnight, two orders stuck, five sat dep-held behind them and the
dispatcher idle-reaped. **Every fact needed to unblock it was already on
disk** — ``order.verify.error`` and its ``logPath``, ``stalledReason`` /
``stalledCause``, ``salvageBranches[]``, the ``DEP_HELD`` lines, the LEAD's
deadlock finding, the crew timeout briefs — and it was scattered across the
order JSON, ``lifecycle.log``, ``.mso/crews/crewN/`` and the LEAD's state. No
surface held more than a piece of it, so the operator's only route to the
whole picture was asking a LEAD session "why did it stall?".

That is the gap this closes. Not new detection, not new remediation — a
single **assembly** of facts that were already true, plus the ordered list of
commands that act on them.

Design rules (PLAN-FTR-MSO-2026-0700 §13), all load-bearing
-----------------------------------------------------------
1. **No new state file.** Everything is computed on read. A snapshot would be
   a fifth plane for the truth to drift between — precisely the failure this
   exists to remove.
2. **Never raises.** ``mso status``, the patrol/LEAD tick and the Hub poller
   all call this on a hot path. Follows :mod:`maestro.core.deadlock`'s
   discipline verbatim: degraded return on failure, never an exception in a
   caller. A corrupt order JSON yields ``None``, not a traceback.
3. **Quote, never regenerate.** ``operatorNote`` (BUG-MSO-2026-0703),
   ``verify.operatorAction`` (BUG-MSO-2026-0695) and
   ``role_rejection.describe_rejection`` (BUG-MSO-2026-0705) already hold the
   correct remedy in the correct words. A paraphrase is a second string to
   keep in sync — the exact drift BUG-MSO-2026-0486 was.
4. **Never re-derive what a classifier already decided.** A voyage deadlock
   comes from :func:`maestro.core.deadlock.classify_voyage_deadlock` and is
   *wrapped*; salvage selection comes from
   :func:`maestro.core.salvage_record.select_salvage`; effective status comes
   from :func:`maestro.core.order_status.effective_order_status`. This module
   owns the assembly and the option list, and nothing else.
5. **core must not import hub.** ``order_status.py``'s docstring records that
   inverted layer as the reason BUG-MSO-2026-0699 could not reuse the Hub's
   resolution. Hub imports core; never the reverse. The ``hub_*`` fields on
   :class:`Option` are plain strings describing an endpoint — they create no
   import edge.

Honesty rules that outrank tidiness
-----------------------------------
- An unmeasured salvage branch renders ``"diff-stat unknown"``, never
  ``"0 files"`` — BUG-MSO-2026-0696's rule, preserved by delegating to
  :func:`~maestro.core.salvage_record.format_diff_stat` rather than formatting
  here.
- An **ambiguous** salvage selection yields NO ``recommended`` option and one
  option per candidate, each carrying the refusal reason. Presenting the
  choice is the whole point of 0696's refusal; pre-making it here would undo
  it one layer up.
- A ``SKIPPED`` blocker's option is ``mso order unskip``, never ``retry`` —
  retry re-queues an order the skip list still vetoes, which looks like the
  fix and changes nothing. Taken verbatim from
  :attr:`~maestro.core.deadlock.VoyageDeadlock.suggested_command`.
- ``VERIFY_PREEXISTING`` (BUG-MSO-2026-0707) is deliberately **not** a kind:
  that waiver means the order was *not* held and converged normally. It is
  not stuck, and saying it is would train operators to ignore the panel.
- **An order queued behind work the fleet is actively doing is not stuck.**
  ``DEP_HELD`` fires only when the chain roots in something that needs a human
  (see :func:`_needs_a_human`) — *not* merely because the dep-holds snapshot
  names the order, which it does for every unmet dependency. This narrows the
  plan's literal detection rule, deliberately: measured against the live MSO
  plane, the unnarrowed rule reported six healthy orders queued behind a
  RUNNING order as blocked. ``deadlock.py`` declines to call that shape stuck
  for exactly the same reason.
- ``recommended`` means "this is what the default command does" and is only
  ever set on an option that HAS a command. When
  :func:`~maestro.core.salvage_record.select_salvage` refuses to choose, NO
  option is recommended — see :func:`_finalise_options`.

Consumers (each its own follow-up order; this module is Order 1 of six)
-----------------------------------------------------------------------
- ``mso order why`` / ``mso voyage why`` + the ``mso status`` MISSION line
- ``maestro/patrol/checks/orders.py`` — ``orders.stuck`` (and so the LEAD)
- ``maestro/hub/server.py`` — two GET endpoints
- ``maestro-hub`` — the order-drawer panel and the voyage banner
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

from maestro.core.order_status import (
    classify_status,
    effective_order_status,
    load_ledger_view,
)

# ---------------------------------------------------------------------------
# Kinds
# ---------------------------------------------------------------------------

# A ``str``, not an Enum, deliberately: the wire shape, the CLI output and the
# TypeScript union are then the same literal, with no serialisation step that
# could disagree with any of them.
BlockageKind = str

KIND_VERIFY_FAILED = "VERIFY_FAILED"
KIND_VERIFY_DEPS_FAILED = "VERIFY_DEPS_FAILED"
KIND_STALLED = "STALLED"
KIND_CONVERGENCE_FAILED = "CONVERGENCE_FAILED"
KIND_AUTO_SERIALIZE = "AUTO_SERIALIZE"
KIND_TIMEOUT_REQUEUED = "TIMEOUT_REQUEUED"
KIND_DEP_HELD = "DEP_HELD"
KIND_REVIEW_PENDING = "REVIEW_PENDING"
KIND_SKIPPED = "SKIPPED"
KIND_DEADLOCKED = "DEADLOCKED"  # voyage subjects only

#: PLAN-PLN-MSO-2026-0747 Order 7. Both are specialisations of a STALLED
#: order at the REL role (``stalledCause == "BLOCKED_BY_ROLE"``) — REL itself
#: signalled BLOCKED rather than crashing or exhausting its requeue budget —
#: so they must be tried BEFORE ``KIND_STALLED`` in
#: :data:`ORDER_KIND_PRECEDENCE`, or the generic stall classifier would win
#: and the more useful, more specific diagnosis would never be reached.
KIND_REL_NOT_READY = "REL_NOT_READY"
KIND_PROVIDER_UNAVAILABLE = "PROVIDER_UNAVAILABLE"

#: Classification walks this ordered list and returns the FIRST match. The
#: order is deliberate: an operator-owned decision (skip, review) outranks a
#: machine failure, because telling someone their own parked order is "broken"
#: is the fastest way to make them stop reading the panel.
ORDER_KIND_PRECEDENCE: Tuple[BlockageKind, ...] = (
    KIND_SKIPPED,
    KIND_REVIEW_PENDING,
    KIND_VERIFY_DEPS_FAILED,
    KIND_VERIFY_FAILED,
    KIND_CONVERGENCE_FAILED,
    KIND_AUTO_SERIALIZE,
    # A misconfigured/unreachable provider is a more actionable, more precise
    # diagnosis than "REL said not ready" whenever REL could not even finish
    # its checklist because of it — tried first for that reason.
    KIND_PROVIDER_UNAVAILABLE,
    KIND_REL_NOT_READY,
    KIND_STALLED,
    KIND_TIMEOUT_REQUEUED,
    KIND_DEP_HELD,
)

#: Short phrase used by :meth:`Blockage.title` — ``"<ID> is stuck: <phrase>"``.
_KIND_TITLES: Dict[BlockageKind, str] = {
    KIND_VERIFY_FAILED: "the verify gate failed",
    KIND_VERIFY_DEPS_FAILED: "the verify gate could not run",
    KIND_STALLED: "stalled",
    KIND_CONVERGENCE_FAILED: "convergence failed",
    KIND_AUTO_SERIALIZE: "auto-serialized out of the voyage",
    KIND_TIMEOUT_REQUEUED: "timed out and was re-queued",
    KIND_DEP_HELD: "held on a dependency",
    KIND_REVIEW_PENDING: "waiting at a review gate",
    KIND_SKIPPED: "skipped by an operator",
    KIND_DEADLOCKED: "deadlocked",
    KIND_REL_NOT_READY: "REL recommended NOT READY",
    KIND_PROVIDER_UNAVAILABLE: "an SDLC provider was unavailable",
}

#: The verb :meth:`Blockage.title` uses. Not every kind is a fault — see that
#: method's docstring for why this is not cosmetic.
_KIND_VERBS: Dict[BlockageKind, str] = {
    KIND_REVIEW_PENDING: "is waiting",
    KIND_TIMEOUT_REQUEUED: "is recovering",
    KIND_SKIPPED: "is parked",
    KIND_DEP_HELD: "is held",
}

#: Patrol severity per kind. ``REVIEW_PENDING`` and ``TIMEOUT_REQUEUED`` are
#: ``medium`` on purpose — the first is a wait for a human decision (mirroring
#: the shipped ``orders.awaiting-approval`` severity so ``mso doctor``'s exit
#: code is unchanged), the second is a state the fleet recovers from by itself.
#: Calling either "high" would make the genuinely-stuck ones harder to see.
_KIND_SEVERITY: Dict[BlockageKind, str] = {
    KIND_VERIFY_FAILED: "high",
    KIND_VERIFY_DEPS_FAILED: "high",
    KIND_STALLED: "high",
    KIND_CONVERGENCE_FAILED: "high",
    KIND_AUTO_SERIALIZE: "high",
    KIND_TIMEOUT_REQUEUED: "medium",
    KIND_DEP_HELD: "medium",
    KIND_REVIEW_PENDING: "medium",
    KIND_SKIPPED: "low",
    KIND_DEADLOCKED: "high",
    # PLAN-PLN-MSO-2026-0747 Order 7 — explicit, not inherited: a voyage
    # cannot finalise while its REL order is open (D1, §2), so either kind
    # blocks the whole voyage exactly as a STALLED order does.
    KIND_REL_NOT_READY: "high",
    KIND_PROVIDER_UNAVAILABLE: "high",
}

#: Effective statuses that mean "a crew is on it right now" or "it is done".
#: Neither is stuck, and both must stay CHEAP to answer — ``None`` is the
#: common case on any healthy plane.
_NOT_STUCK_BUCKETS = frozenset({"complete", "inProgress"})

# How many trailing ``lifecycle.log`` lines to keep per order, and how much of
# the file's tail to read to find them. The log grows without bound; reading it
# whole on a 5-second ``mso status`` refresh is not acceptable.
LIFECYCLE_TAIL_BYTES = 512 * 1024
LIFECYCLE_LINES_PER_ORDER = 8


# ---------------------------------------------------------------------------
# Record types
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class Evidence:
    """One artefact that PROVES the cause, rather than restating it.

    ``detail`` is never fabricated: a diff-stat that could not be measured
    renders as ``"diff-stat unknown"`` (BUG-MSO-2026-0696), because an
    unmeasurable branch and an empty one are different facts that an operator
    acts on differently.
    """

    kind: str  # verifyLog | salvageBranch | timeoutBrief | lifecycle
    #            | crewOutput | artefact | operatorNote
    label: str
    path: str = ""          # absolute path, or "" for a branch/text evidence
    branch: str = ""        # salvage branch name, when applicable
    detail: str = ""        # "18 file(s), +864/-12 vs voyage/..." — or ""
    artefact_key: str = ""  # Hub GET /orders/{id}/artefacts/{key}, when readable

    def to_dict(self) -> Dict[str, Any]:
        return {
            "kind": self.kind,
            "label": self.label,
            "path": self.path,
            "branch": self.branch,
            "detail": self.detail,
            "artefactKey": self.artefact_key,
        }


@dataclass(frozen=True)
class Option:
    """One thing the operator can DO, with its cost stated up front.

    ``command`` is always populated when a CLI verb exists — a surface with no
    button can still show a copyable command. ``hub_action`` empty means
    CLI-only: the Hub renders the command as text rather than a button that
    would 404. ``capability`` names a key on the Hub's ``CapabilityMap`` so an
    unavailable action is shown DISABLED WITH ITS REASON, never hidden
    (FTR-MSO-2026-0617's honesty rule).
    """

    label: str
    command: str = ""
    hub_action: str = ""   # "" | orderRetry | orderSkip | review | dispatch
    hub_method: str = ""   # "POST"
    hub_path: str = ""
    capability: str = ""   # "" = no capability gate
    risk_note: str = ""    # "" when there is genuinely no risk — never padded
    #: "This is what you should do." Usually an option with a command; for
    #: TIMEOUT_REQUEUED it is deliberately the command-less "wait" option,
    #: because the honest answer there is to leave it alone. At most one option
    #: per Blockage carries it — see :func:`_finalise_options`.
    recommended: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "label": self.label,
            "command": self.command,
            "hubAction": self.hub_action,
            "hubMethod": self.hub_method,
            "hubPath": self.hub_path,
            "capability": self.capability,
            "riskNote": self.risk_note,
            "recommended": self.recommended,
        }


@dataclass(frozen=True)
class BlockerRef:
    """An order this subject is waiting on, carrying ITS OWN diagnosis.

    The point of the nested ``kind``/``cause`` is that "held on
    FTR-MSO-2026-0618" is not an answer — "held on FTR-MSO-2026-0618, which
    STALLED after 2 requeues at TST" is.
    """

    order_id: str
    status: str
    kind: str = ""
    cause: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "orderId": self.order_id,
            "status": self.status,
            "kind": self.kind,
            "cause": self.cause,
        }


@dataclass(frozen=True)
class Blockage:
    """Why one order or voyage is not moving, and what to do about it."""

    subject_id: str
    subject_kind: str  # "order" | "voyage"
    kind: BlockageKind
    cause: str                 # ONE plain-English sentence
    since: str = ""            # ISO8601 of the transition in, "" if unknown
    severity: str = "high"
    detail: str = ""           # the fuller paragraph LEAD/doctor render
    evidence: Tuple[Evidence, ...] = ()
    blockers: Tuple[BlockerRef, ...] = ()
    options: Tuple[Option, ...] = ()   # ORDERED, best first
    voyage_id: str = ""
    role: str = ""
    #: True when the FLEET will resolve this without an operator — an order
    #: simply queued behind work a crew is doing right now. Such a record is
    #: still a correct, useful answer to "why is this order not running", which
    #: is what an order drawer asks; it is NOT an answer to "what is stuck",
    #: which is what a sweep asks. :func:`scan_stuck_orders` therefore excludes
    #: it while :func:`classify_order_blockage` still returns it.
    #:
    #: This split exists because collapsing the two questions loses one of
    #: them: dropping the record entirely blinds the Hub panel, and listing it
    #: in ``mso doctor`` reports healthy queue order as a fault. PLAN
    #: FTR-MSO-2026-0700's own §5.4 guidance — narrow the doctor OUTPUT, never
    #: the model — is the rule being followed here.
    progressing: bool = False
    #: Set ONLY when an upstream classifier already owns the one-liner — the
    #: voyage wrapper passes ``VoyageDeadlock.summary()`` through verbatim so
    #: the Hub banner and the ``mso status`` MISSION line stay byte-identical
    #: to what BUG-MSO-2026-0699 shipped. Never set for an order.
    summary_override: str = ""

    def title(self) -> str:
        """``"<ID> is stuck: <phrase>"`` — the patrol Finding title.

        The VERB is kind-dependent, and deliberately so. Three of these kinds
        are not faults: a review gate is a wait for a human, a re-queued
        timeout is the fleet recovering by itself, and a skipped order is the
        operator's own decision. Reporting all three as "stuck" is how a panel
        earns the reputation that makes people stop reading it — the same
        reasoning that keeps ``VERIFY_PREEXISTING`` out of the kind list
        entirely.
        """
        if self.progressing:
            return f"{self.subject_id} is queued: waiting its turn"
        phrase = _KIND_TITLES.get(self.kind, self.kind.lower().replace("_", " "))
        return f"{self.subject_id} {_KIND_VERBS.get(self.kind, 'is stuck')}: {phrase}"

    def summary(self) -> str:
        """The one-liner for ``mso status``'s MISSION block and the Hub banner.

        Bounded: this lands on a single terminal row, so the cause is clipped
        rather than allowed to wrap the line into unreadability. The full text
        is always one ``mso order why`` away.
        """
        if self.summary_override:
            return self.summary_override
        head = f"{self.kind} — {_clip(self.cause, 150)}"
        command = self.suggested_command()
        if command:
            head += f" — `{command}`"
        return head

    def suggested_command(self) -> str:
        """``options[0].command``, or "" when the best option has no verb.

        ``mso doctor``'s ``suggestedCommand`` and the LEAD's proposed action
        both read this, so the command an operator is shown is the same one
        the check would run.
        """
        for opt in self.options:
            if opt.command:
                return opt.command
        return ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "subjectId": self.subject_id,
            "subjectKind": self.subject_kind,
            "kind": self.kind,
            "cause": self.cause,
            "since": self.since,
            "severity": self.severity,
            "detail": self.detail,
            "title": self.title(),
            "summary": self.summary(),
            "suggestedCommand": self.suggested_command(),
            "evidence": [e.to_dict() for e in self.evidence],
            "blockers": [b.to_dict() for b in self.blockers],
            "options": [o.to_dict() for o in self.options],
            "voyageId": self.voyage_id,
            "role": self.role,
            "progressing": self.progressing,
        }


# ---------------------------------------------------------------------------
# Small helpers
# ---------------------------------------------------------------------------

def _text(value: Any) -> str:
    return value.strip() if isinstance(value, str) else ""


def _first_sentence(value: Any, limit: int = 240) -> str:
    """The first line of a multi-line error, bounded — never a blind tail.

    A verify error's first line is the tool's own verdict; everything after it
    is usually the stack or the passing-test noise that made BUG-MSO-2026-0506
    necessary. The full text is always reachable through the log Evidence, so
    truncating HERE loses nothing.
    """
    text = _text(value)
    if not text:
        return ""
    line = text.splitlines()[0].strip()
    return line if len(line) <= limit else line[: limit - 1].rstrip() + "…"


def _clip(value: Any, limit: int) -> str:
    """Bound a sentence for a single-line surface, on a word boundary."""
    text = " ".join(_text(value).split())
    if len(text) <= limit:
        return text
    cut = text[:limit].rsplit(" ", 1)[0].rstrip(" ,;:—-")
    return (cut or text[:limit]) + "…"


def _finalise_options(options: Sequence[Option],
                      allow_fallback: bool = True) -> Tuple[Option, ...]:
    """Exactly one recommendation — or, when honesty demands it, none.

    Three rules, all learned from the run that first exercised this module:

    1. **At most one ``recommended``.** Two recommendations is not a stronger
       hint, it is an incoherent one — the surfaces render ``recommended`` as
       the default button, and two defaults means none.
    2. **The FALLBACK only ever marks something with a command.** When no
       classifier asserted a recommendation, the first option carrying a verb
       is marked — which is, by construction, what a bare ``mso order retry``
       would actually do, never a guess this module invented.

       A classifier may still assert a recommendation on a command-less
       option, and ``TIMEOUT_REQUEUED`` deliberately does: its best option is
       *"Wait — the dispatcher will re-dispatch it by itself"*, and there is no
       command because there is nothing to run. Recommending a retry there
       would tell an operator to intervene in something that is already
       recovering. So ``recommended`` means **"this is what you should do"**,
       which is usually a command and is sometimes, honestly, nothing.
       ``suggested_command()`` skips command-less options regardless, so
       ``mso doctor``'s ``suggestedCommand`` is always runnable.
    3. **``allow_fallback=False`` means NO recommendation, deliberately.**
       Passed when :func:`~maestro.core.salvage_record.select_salvage`
       REFUSED to choose between candidates. Rule 2's fallback would otherwise
       quietly re-make the exact decision BUG-MSO-2026-0696 exists to refuse —
       marking one branch as the default when the whole finding is that the
       system cannot tell which one holds the work. An unrecommended option
       list is the correct output there; the operator picks.

    Evidence-opening options (a log path, a plan) deliberately carry NO
    command, so they can never become the recommendation and can never leak
    into :meth:`Blockage.suggested_command` — a ``suggestedCommand`` that
    tells an operator to cat a log file is not a remedy, and ``mso doctor``
    renders that field as one.
    """
    out: List[Option] = []
    seen_recommended = False
    for opt in options:
        if opt.recommended and seen_recommended:
            out.append(Option(
                label=opt.label, command=opt.command, hub_action=opt.hub_action,
                hub_method=opt.hub_method, hub_path=opt.hub_path,
                capability=opt.capability, risk_note=opt.risk_note,
                recommended=False))
            continue
        seen_recommended = seen_recommended or opt.recommended
        out.append(opt)
    if not seen_recommended and allow_fallback:
        for index, opt in enumerate(out):
            if opt.command:
                out[index] = Option(
                    label=opt.label, command=opt.command,
                    hub_action=opt.hub_action, hub_method=opt.hub_method,
                    hub_path=opt.hub_path, capability=opt.capability,
                    risk_note=opt.risk_note, recommended=True)
                break
    return tuple(out)


def _parse_iso(value: Any) -> Optional[datetime]:
    text = _text(value)
    if not text:
        return None
    try:
        return datetime.fromisoformat(text.replace("Z", "+00:00"))
    except Exception:
        return None


def age_phrase(value: Any, now: Optional[datetime] = None) -> str:
    """``"3h 12m"`` / ``"2 days"`` / ``""`` when the timestamp is unreadable.

    An unparseable timestamp yields ``""`` and the caller drops the clause
    entirely, rather than rendering "held for unknown" — which reads as a
    second fault on top of the one being reported.
    """
    when = _parse_iso(value)
    if when is None:
        return ""
    try:
        reference = now
        if reference is None:
            reference = datetime.now(tz=when.tzinfo) if when.tzinfo else datetime.now()
        elif (reference.tzinfo is None) != (when.tzinfo is None):
            # Mixed naive/aware. The plane carries both shapes (the dispatcher
            # writes naive `datetime.now().isoformat()`, some fields carry
            # offsets), and a TypeError here would cost the whole diagnosis for
            # the sake of a clause. Drop the clause instead.
            return ""
        delta = reference - when
    except Exception:
        return ""
    seconds = int(delta.total_seconds())
    if seconds < 0:
        return ""
    if seconds < 90:
        return f"{seconds}s"
    minutes = seconds // 60
    if minutes < 60:
        return f"{minutes}m"
    hours, minutes = divmod(minutes, 60)
    if hours < 24:
        return f"{hours}h {minutes}m" if minutes else f"{hours}h"
    days, hours = divmod(hours, 24)
    return f"{days} day{'s' if days != 1 else ''}" + (f" {hours}h" if hours else "")


def _date_phrase(value: Any) -> str:
    when = _parse_iso(value)
    return when.strftime("%Y-%m-%d") if when else "an unrecorded date"


def _as_dict(value: Any) -> Dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _as_list(value: Any) -> List[Any]:
    if isinstance(value, (list, tuple)):
        return list(value)
    return []


def _int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except Exception:
        return default


def depends_on(data: Optional[Dict[str, Any]]) -> Tuple[str, ...]:
    """An order's declared dependencies, tolerating every shape in the wild."""
    if not isinstance(data, dict):
        return ()
    deps = data.get("dependsOn") or data.get("dependencies") or []
    if isinstance(deps, str):
        deps = [deps]
    if not isinstance(deps, (list, tuple)):
        return ()
    return tuple(str(d) for d in deps if d)


# ---------------------------------------------------------------------------
# Context — read the planes ONCE
# ---------------------------------------------------------------------------

@dataclass
class BlockageContext:
    """Every plane this module reads, resolved once and shared for a whole pass.

    ``mso doctor``, ``mso status`` and the Hub poller each classify N orders
    per invocation; without this they would pay N ledger replays and N archive
    scans. Same discipline :func:`maestro.core.deadlock.scan_voyage_members`
    adopted under BUG-MSO-2026-0708, for the same reason: on the live MSO plane
    a full archive scan reads ~700 JSON files and was measured at 0.4s a call.

    Construct with :meth:`load`. Every field degrades to empty rather than
    raising, so a workspace missing ``state/`` or ``orders/`` classifies as
    "nothing known", never as an error.
    """

    artefact_root: Path
    ledger_view: Any = None
    #: A LAZY, per-id view over ``orders/complete`` + ``orders/failed`` —
    #: ``deadlock._ArchivedOrders``, reused rather than reimplemented. It
    #: already exposes ``__contains__``/``__getitem__``, so it drops straight
    #: into :func:`~maestro.core.order_status.effective_order_status` in place
    #: of the dict that function expects, keeping the status-precedence rules
    #: in that ONE place. Eagerly indexing both directories instead costs ~0.6s
    #: on the live MSO plane (689 files) for every context — unacceptable for
    #: ``mso order why`` on a single order, and the exact cost BUG-MSO-2026-0708
    #: made this class lazy to avoid.
    archive_statuses: Any = None
    live_orders: Dict[str, Dict[str, Any]] = None  # type: ignore[assignment]
    dep_holds: Dict[str, Dict[str, Any]] = None  # type: ignore[assignment]
    skipped: Dict[str, Dict[str, Any]] = None  # type: ignore[assignment]
    _lifecycle_index: Optional[Dict[str, List[str]]] = None
    _status_cache: Optional[Dict[str, str]] = None

    def __post_init__(self) -> None:
        self.artefact_root = Path(self.artefact_root)
        if self.archive_statuses is None:
            self.archive_statuses = {}
        if self.live_orders is None:
            self.live_orders = {}
        if self.dep_holds is None:
            self.dep_holds = {}
        if self.skipped is None:
            self.skipped = {}
        if self._status_cache is None:
            self._status_cache = {}

    # -- construction -------------------------------------------------------

    @classmethod
    def load(cls, artefact_root: Optional[Path] = None) -> "BlockageContext":
        """Read every plane once. Never raises; degrades to an empty context."""
        try:
            if artefact_root is None:
                from maestro.workspace import get_artefact_root
                artefact_root = get_artefact_root()
            root = Path(artefact_root)
        except Exception:
            return cls(artefact_root=Path("."))

        ctx = cls(artefact_root=root)
        try:
            ctx.ledger_view = load_ledger_view(root)
        except Exception:
            ctx.ledger_view = None
        try:
            # Reuse the dispatcher-adjacent queue index rather than re-listing
            # the queue dirs here — two lists of "which dirs hold live orders"
            # drift, and this one is already the dispatcher's.
            from maestro.core.deadlock import _index_live_orders
            ctx.live_orders = _index_live_orders(root)
        except Exception:
            ctx.live_orders = {}
        try:
            from maestro.core.deadlock import _ArchivedOrders
            ctx.archive_statuses = _ArchivedOrders(root)
        except Exception:
            ctx.archive_statuses = {}
        try:
            from maestro.core.dep_holds import read_dep_holds
            ctx.dep_holds = read_dep_holds(root)
        except Exception:
            ctx.dep_holds = {}
        try:
            from maestro.core.skip_list import read_skipped_orders
            ctx.skipped = read_skipped_orders(root)
        except Exception:
            ctx.skipped = {}
        return ctx

    # -- lookups ------------------------------------------------------------

    def order_data(self, order_id: str) -> Optional[Dict[str, Any]]:
        """The order's JSON — the live queue copy first, then the archive.

        The archive lookup is a direct ``<ORDER-ID>.json`` probe, not a scan
        (see :attr:`archive_statuses`), so an id that is not archived costs two
        ``stat`` calls and is cached against a second probe.
        """
        live = self.live_orders.get(order_id)
        if live is not None:
            return live
        getter = getattr(self.archive_statuses, "data", None)
        if getter is not None:
            try:
                return getter(order_id)
            except Exception:
                return None
        return None

    def status_of(self, order_id: str,
                  data: Optional[Dict[str, Any]] = None) -> str:
        """Effective status: ledger TERMINAL > archive > live claim > file.

        Memoised for the life of the context. The dependency walk revisits the
        same ids across orders (a fan-in dependency is resolved once per
        dependent otherwise), and a context is by definition a single-pass
        snapshot — so caching cannot make it disagree with itself, which a
        second live read could.
        """
        cached = self._status_cache.get(order_id) if self._status_cache else None
        if cached is not None:
            return cached
        if data is None:
            data = self.order_data(order_id)
        fallback = _text((data or {}).get("status")) or None
        try:
            status = effective_order_status(
                order_id, fallback, self.ledger_view, self.archive_statuses)
        except Exception:
            status = (fallback or "PENDING").upper()
        if self._status_cache is not None:
            self._status_cache[order_id] = status
        return status

    def lifecycle_lines(self, order_id: str) -> List[str]:
        """The last few ``lifecycle.log`` lines naming *order_id*.

        Lazy and shared: the log's tail is read at most once per context, then
        indexed for every order in the pass. A missing or unreadable log is
        simply no evidence — the diagnosis never depends on it.
        """
        if self._lifecycle_index is None:
            self._lifecycle_index = _index_lifecycle_tail(self.artefact_root)
        return self._lifecycle_index.get(order_id, [])


def _index_lifecycle_tail(root: Path) -> Dict[str, List[str]]:
    """Map order id -> its last N lifecycle lines, from the log's tail only.

    The log is append-only and unbounded (the live MSO one is tens of MB), and
    ``mso status`` refreshes every 5 seconds, so only the last
    :data:`LIFECYCLE_TAIL_BYTES` are read. An order whose last event predates
    that window simply contributes no lifecycle Evidence — which is honest:
    the record scrolled out, and the order JSON's own fields still carry the
    diagnosis.
    """
    index: Dict[str, List[str]] = {}
    path = root / "logs" / "lifecycle.log"
    try:
        if not path.is_file():
            return index
        size = path.stat().st_size
        with path.open("rb") as handle:
            if size > LIFECYCLE_TAIL_BYTES:
                handle.seek(size - LIFECYCLE_TAIL_BYTES)
                handle.readline()  # discard the partial first line
            raw = handle.read()
        text = raw.decode("utf-8", errors="replace")
    except Exception:
        return index

    for line in text.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        for token in _order_ids_in(stripped):
            bucket = index.setdefault(token, [])
            bucket.append(stripped)
            if len(bucket) > LIFECYCLE_LINES_PER_ORDER:
                del bucket[0]
    return index


def _order_ids_in(line: str) -> Tuple[str, ...]:
    """Order ids mentioned in a lifecycle line, without a regex scan per order.

    Splitting on the delimiters an id can never contain is ~an order of
    magnitude cheaper than running one compiled pattern over every line, and
    the tail can be thousands of lines.
    """
    found: List[str] = []
    for token in line.replace("(", " ").replace(")", " ").replace(",", " ").split():
        candidate = token.strip(".:;'\"`[]<>")
        parts = candidate.split("-")
        if len(parts) == 4 and parts[0].isalpha() and parts[0].isupper() \
                and parts[2].isdigit() and parts[3].isdigit():
            if candidate not in found:
                found.append(candidate)
    return tuple(found)


# ---------------------------------------------------------------------------
# The retry-option builder (shared by VERIFY_*/CONVERGENCE/AUTO_SERIALIZE/STALLED)
# ---------------------------------------------------------------------------

def build_retry_options(order_id: str,
                        data: Optional[Dict[str, Any]],
                        role: str = "",
                        recommend_salvage: bool = False) -> List[Option]:
    """The retry verbs for one order, derived in exactly ONE place.

    Delegates every judgement about WHICH branch to arm to
    :func:`maestro.core.salvage_record.select_salvage`, so the option list an
    operator sees and the branch ``mso order retry`` would actually arm can
    never disagree.

    Three shapes come out of that delegation:

    * **A confident choice** — one option for the chosen branch, marked
      ``recommended`` when *recommend_salvage* (a convergence failure is
      BUG-MSO-2026-0273's fast path, where merging IS the completion).
    * **An ambiguous one** — NO recommended option and one option per
      candidate, each carrying ``select_salvage``'s refusal reason as its
      ``risk_note``. Presenting the choice is the entire point of
      BUG-MSO-2026-0696's refusal; pre-making it here would undo it.
    * **No candidates** — a plain retry, and nothing about salvage.

    A "retry fresh" option is always appended, and always names what it
    discards, because it is sometimes the right answer and must never be the
    silent default.
    """
    return _retry_options(order_id, data, role, recommend_salvage)[0]


def _retry_options(order_id: str,
                   data: Optional[Dict[str, Any]],
                   role: str = "",
                   recommend_salvage: bool = False
                   ) -> Tuple[List[Option], bool]:
    """:func:`build_retry_options` plus the flag its callers need.

    The extra return is ``ambiguous`` — True when ``select_salvage`` refused to
    choose. It exists because :func:`_finalise_options`' fallback would
    otherwise re-make that refused decision one layer up (rule 3 there), and
    re-deriving the answer with a second ``select_salvage`` call in every
    caller is how two implementations of one judgement start to drift.
    :func:`build_retry_options` stays the public, plan-specified signature.
    """
    options: List[Option] = []
    try:
        from maestro.core import salvage_record
        candidates = salvage_record.salvage_candidates(_as_dict(data))
        selection = salvage_record.select_salvage(candidates)
        format_diff_stat = salvage_record.format_diff_stat
    except Exception:
        candidates, selection, format_diff_stat = [], None, None

    def _describe(cand: Any) -> str:
        sha = _text(getattr(cand, "sha", "")) or ""
        head = sha[:8] if sha else _text(getattr(cand, "branch", "")) or "?"
        bits = []
        if format_diff_stat is not None:
            # Delegated, so an unmeasured branch reads "diff-stat unknown" and
            # NEVER "0 files" — BUG-MSO-2026-0696's honesty rule survives into
            # the UI by construction rather than by a second implementation.
            bits.append(format_diff_stat(getattr(cand, "diff_stat", None)))
        cand_role = _text(getattr(cand, "role", ""))
        if cand_role:
            bits.append(cand_role)
        reason = _text(getattr(cand, "reason", ""))
        if reason and not cand_role:
            bits.append(reason)
        return f"{head} ({', '.join(bits)})" if bits else head

    def _retry_option(cand: Any, *, recommended: bool, risk: str) -> Option:
        branch = _text(getattr(cand, "branch", ""))
        return Option(
            label=f"Retry from salvage {_describe(cand)}",
            command=f"mso order retry {order_id} --salvage {branch}",
            hub_action="orderRetry",
            hub_method="POST",
            hub_path=f"/api/v1/orders/{order_id}/retry?salvage={branch}",
            capability="orderRetry",
            risk_note=risk,
            recommended=recommended,
        )

    ambiguous = False
    if selection is not None and getattr(selection, "chosen", None) is not None:
        options.append(_retry_option(
            selection.chosen, recommended=bool(recommend_salvage), risk=""))
    elif selection is not None and _text(getattr(selection, "ambiguous", "")):
        # No recommendation, by design: the operator picks.
        ambiguous = True
        reason = _text(selection.ambiguous)
        for cand in candidates:
            options.append(_retry_option(cand, recommended=False, risk=reason))

    at_role = f" at {role}" if role else ""
    if candidates:
        options.append(Option(
            label=f"Retry fresh{at_role} (discard preserved work)",
            command=f"mso order retry {order_id} --no-salvage",
            hub_action="orderRetry",
            hub_method="POST",
            hub_path=f"/api/v1/orders/{order_id}/retry?salvage=none",
            capability="orderRetry",
            risk_note=(f"The role re-runs from the converged voyage branch. "
                       f"Discards {len(candidates)} preserved salvage branch"
                       f"{'es' if len(candidates) != 1 else ''}."),
        ))
    else:
        options.append(Option(
            label=f"Retry this order{at_role}",
            command=f"mso order retry {order_id}",
            hub_action="orderRetry",
            hub_method="POST",
            hub_path=f"/api/v1/orders/{order_id}/retry",
            capability="orderRetry",
            risk_note="The role re-runs from the converged voyage branch.",
        ))
    return options, ambiguous


def _serialize_retry(order_id: str,
                     data: Dict[str, Any]) -> Tuple[List[Option], bool]:
    """``(options, allow_fallback)`` for AUTO_SERIALIZE, ready to splat.

    Its whole option list IS the retry list — a serialized-out order has no
    log to open and no review to give — so this exists only to convert
    :func:`_retry_options`' ``ambiguous`` into
    :func:`_finalise_options`' ``allow_fallback``.
    """
    options, ambiguous = _retry_options(
        order_id, data, _text(data.get("targetRole")), recommend_salvage=True)
    return options, not ambiguous


def _salvage_evidence(data: Optional[Dict[str, Any]]) -> List[Evidence]:
    """One Evidence per recorded salvage branch, with its RECORDED diff-stat."""
    out: List[Evidence] = []
    try:
        from maestro.core import salvage_record
        for cand in salvage_record.salvage_candidates(_as_dict(data)):
            out.append(Evidence(
                kind="salvageBranch",
                label=f"Preserved work on {cand.branch}",
                branch=_text(cand.branch),
                detail=salvage_record.format_diff_stat(cand.diff_stat),
            ))
    except Exception:
        return []
    return out


# ---------------------------------------------------------------------------
# Per-kind classifiers
# ---------------------------------------------------------------------------

def _skipped(order_id: str, data: Dict[str, Any], ctx: BlockageContext,
             status: str) -> Optional[Blockage]:
    entry = ctx.skipped.get(order_id)
    if entry is None:
        return None
    entry = _as_dict(entry)
    reason = _text(entry.get("reason")) or "none recorded"
    skipped_at = _text(entry.get("skippedAt")) or _text(entry.get("at"))
    voyage = _text(data.get("voyageId"))

    options = [Option(
        label="Un-skip and re-queue",
        command=f"mso order unskip {order_id}",
        hub_action="orderSkip",
        hub_method="POST",
        hub_path=f"/api/v1/orders/{order_id}/unskip",
        capability="orderSkip",
        recommended=True,
    )]
    if voyage:
        options.append(Option(
            label="Remove from the voyage manifest",
            command=f"mso order remove {order_id} --from-voyage {voyage}",
            risk_note="Edits the voyage manifest; the order stays skipped.",
        ))

    evidence: List[Evidence] = []
    note = _text(data.get("operatorNote"))
    if note:
        evidence.append(Evidence(kind="operatorNote",
                                 label="Recorded operator note", detail=note))
    # FTR-MSO-2026-0719: the skip list itself. This is the ONE artefact that
    # proves the cause — the `detail`/`cause` above restate what it says, and
    # an operator who disagrees with the diagnosis needs the file, not the
    # sentence. Emitted only when it is actually on disk, per the module's
    # never-fabricate rule: a skip resolved from anywhere else contributes no
    # false path.
    skip_file = ctx.artefact_root / "config" / "skipped-orders.json"
    try:
        if skip_file.is_file():
            evidence.append(Evidence(
                kind="artefact", label="Operator skip list",
                path=str(skip_file),
                detail=f"the {order_id} entry records this skip"))
    except OSError:
        pass

    return Blockage(
        subject_id=order_id,
        subject_kind="order",
        kind=KIND_SKIPPED,
        cause=(f"Skipped by an operator on {_date_phrase(skipped_at)} — the "
               f"dispatcher will never pick it up. Reason: {reason}."),
        since=skipped_at,
        severity=_KIND_SEVERITY[KIND_SKIPPED],
        detail=(f"{order_id} is on the operator skip list "
                f"(config/skipped-orders.json), so `scan_all_queues` drops it "
                f"from every dispatch tick. Reason: {reason}. Anything that "
                f"depends on it is blocked for as long as the skip stands — "
                f"`mso order retry` will NOT move it, because the skip list "
                f"still vetoes the order after the re-queue."),
        evidence=tuple(evidence),
        options=_finalise_options(options),
        voyage_id=voyage,
        role=_text(data.get("targetRole")),
    )


def _review_pending(order_id: str, data: Dict[str, Any], ctx: BlockageContext,
                    status: str) -> Optional[Blockage]:
    if status != "NAV_REVIEW_PENDING":
        return None
    role = _text(data.get("targetRole")) or _text(data.get("role"))
    since = (_text(data.get("reviewRequestedAt"))
             or _text(data.get("heldAt"))
             or _text(data.get("reviewedAt")))
    age = age_phrase(since)
    plan_ref = _text(data.get("planRef")) or _text(data.get("planDocument"))

    evidence: List[Evidence] = []
    plan_name = f"PLAN-{order_id}.md"
    plan_path = ctx.artefact_root / "plans" / plan_name
    try:
        plan_exists = plan_path.is_file()
    except Exception:
        plan_exists = False
    if plan_exists:
        evidence.append(Evidence(kind="artefact", label="The plan under review",
                                 path=str(plan_path),
                                 artefact_key=f"plan:{plan_name}"))
    elif plan_ref:
        evidence.append(Evidence(kind="artefact", label="The plan under review",
                                 path=plan_ref))

    options = [
        Option(label="Approve and advance",
               command=f"mso review approve {order_id}",
               hub_action="review", hub_method="POST",
               hub_path=f"/api/v1/review/{order_id}/approve",
               capability="review", recommended=True),
        Option(label="Request changes",
               command=f"mso review revise {order_id}",
               hub_action="review", hub_method="POST",
               hub_path=f"/api/v1/review/{order_id}/revise",
               capability="review",
               risk_note="Sends the order back to its role for another pass."),
        Option(label="Reject",
               command=f"mso review reject {order_id}",
               hub_action="review", hub_method="POST",
               hub_path=f"/api/v1/review/{order_id}/reject",
               capability="review",
               risk_note="Archives the order as FAILED."),
    ]

    where = f"the {role} review gate" if role else "a review gate"
    return Blockage(
        subject_id=order_id,
        subject_kind="order",
        kind=KIND_REVIEW_PENDING,
        cause=(f"Paused at {where}{f' for {age}' if age else ''} — waiting on a "
               f"human decision. Nothing is wrong with it."),
        since=since,
        severity=_KIND_SEVERITY[KIND_REVIEW_PENDING],
        detail=(f"{order_id} is parked in queues/review/ awaiting an operator "
                f"decision at {where}. The fleet is behaving correctly and will "
                f"not dispatch it until someone approves, revises or rejects it. "
                f"Anything depending on it waits with it."),
        evidence=tuple(evidence),
        options=_finalise_options(options),
        voyage_id=_text(data.get("voyageId")),
        role=role,
    )


#: Error-text signatures that mean "the shell could not find the tool", used
#: ONLY when BUG-MSO-2026-0695's explicit ``verify.cause``/``gateRan`` fields
#: are absent — which, on this plane, is every order written to date.
#:
#: Every entry is a SHELL's own not-found message or a phrase 0695's writer
#: emits itself. Bare ``npm ci`` / ``npm install`` were tried and removed: they
#: appear in the captured output of perfectly ordinary build failures, and a
#: code failure misread as a toolchain fault sends the operator to install
#: something that is already there — the documented mis-step this whole split
#: exists to prevent. Erring toward VERIFY_FAILED costs a log read; erring the
#: other way costs a wild goose chase.
_DEPS_SIGNATURES: Tuple[str, ...] = (
    "is not recognized as an internal or external command",  # cmd.exe
    "command not found",                                     # sh/bash
    "is not recognized as the name of a cmdlet",             # PowerShell
    "dependency step",                                       # BUG-0695 writer
    "tool missing",                                          # BUG-0695 remedy
)


def _verify_block(data: Dict[str, Any]) -> Dict[str, Any]:
    return _as_dict(data.get("verify"))


def _verify_is_deps_failure(verify: Dict[str, Any]) -> bool:
    """True for a gate that COULD NOT RUN, as opposed to one the code failed.

    BUG-MSO-2026-0695 writes ``cause``/``gateRan`` explicitly, and those are
    authoritative when present. They are absent on every order written before
    that fix, so the error text is the fallback signal — matched on the two
    phrases 0695's own writer emits, not on a loose keyword, so an ordinary
    build error that happens to contain the word "install" is not misread as a
    toolchain fault. Misreading in this direction is the documented mis-step
    the whole VERIFY_DEPS_FAILED/VERIFY_FAILED split exists to prevent.
    """
    cause = _text(verify.get("cause")).upper()
    if cause:
        return cause == "DEPS"
    if verify.get("gateRan") is False:
        return True
    error = _text(verify.get("error")).lower()
    return any(sig in error for sig in _DEPS_SIGNATURES)


def _verify_common(order_id: str, data: Dict[str, Any], verify: Dict[str, Any]
                   ) -> Tuple[List[Evidence], str, str]:
    """(evidence, failedAt, operatorAction) shared by both verify kinds."""
    evidence: List[Evidence] = []
    log_path = _text(verify.get("logPath"))
    if log_path:
        evidence.append(Evidence(
            kind="verifyLog",
            label="Verify log (full stdout+stderr)",
            path=log_path,
            artefact_key=f"verify:{Path(log_path).name}",
        ))
    evidence.extend(_salvage_evidence(data))
    return evidence, _text(verify.get("failedAt")), _text(verify.get("operatorAction"))


def _verify_deps_failed(order_id: str, data: Dict[str, Any],
                        ctx: BlockageContext, status: str) -> Optional[Blockage]:
    verify = _verify_block(data)
    failed = bool(verify.get("failed")) or status == "VERIFY_DEPS_FAILED"
    if not failed or not _verify_is_deps_failure(verify):
        return None
    evidence, failed_at, operator_action = _verify_common(order_id, data, verify)
    error = _first_sentence(verify.get("error"))

    options: List[Option] = []
    if operator_action:
        # Quoted verbatim (rule 3) — 0695 already wrote the remedy as a
        # sentence, and a paraphrase would be a second string to keep in sync.
        # First, because it is the actual next step; command-less, because
        # installing a toolchain is not a Maestro verb. It is deliberately NOT
        # marked `recommended`: that flag drives the surfaces' default BUTTON,
        # and a button with no command is not one. The retry below inherits the
        # recommendation via _finalise_options, which is right — it is what the
        # operator runs once they have done what this line says.
        options.append(Option(label=operator_action, command=""))
    if evidence and evidence[0].kind == "verifyLog":
        options.append(Option(
            label=f"Open the install log ({evidence[0].path})", command=""))
    retry, ambiguous = _retry_options(order_id, data,
                                      _text(data.get("targetRole")))
    options.extend(retry)

    return Blockage(
        subject_id=order_id,
        subject_kind="order",
        kind=KIND_VERIFY_DEPS_FAILED,
        cause=("The verify gate could NOT RUN — the toolchain it invokes is "
               "missing. This is not a code failure."
               + (f" {error}" if error else "")),
        since=failed_at,
        severity=_KIND_SEVERITY[KIND_VERIFY_DEPS_FAILED],
        detail=("The dependency step could not deliver the tools the verify "
                "command invokes, so the gate never executed and the code was "
                "never judged. Responding to this as a broken build is the "
                "documented mis-step (BUG-MSO-2026-0695) — install the "
                "toolchain, then retry."
                + (f" Recorded remedy: {operator_action}" if operator_action else "")),
        evidence=tuple(evidence),
        options=_finalise_options(options, allow_fallback=not ambiguous),
        voyage_id=_text(data.get("voyageId")),
        role=_text(data.get("targetRole")),
    )


def _verify_failed(order_id: str, data: Dict[str, Any], ctx: BlockageContext,
                   status: str) -> Optional[Blockage]:
    verify = _verify_block(data)
    failed = bool(verify.get("failed")) or status == "VERIFY_FAILED"
    if not failed:
        return None
    evidence, failed_at, operator_action = _verify_common(order_id, data, verify)
    error = _first_sentence(verify.get("error"))

    options: List[Option] = []
    if evidence and evidence[0].kind == "verifyLog":
        options.append(Option(
            label=f"Open the verify log ({evidence[0].path})", command=""))
    if operator_action:
        options.append(Option(label=operator_action, command=""))
    retry, ambiguous = _retry_options(order_id, data,
                                      _text(data.get("targetRole")))
    options.extend(retry)

    return Blockage(
        subject_id=order_id,
        subject_kind="order",
        kind=KIND_VERIFY_FAILED,
        cause=("The verify gate RAN and the code failed it, so the work was "
               "held and never pushed." + (f" {error}" if error else "")),
        since=failed_at,
        severity=_KIND_SEVERITY[KIND_VERIFY_FAILED],
        detail=("The local verify command exited non-zero (or timed out), so "
                "convergence was withheld and the crew's work was preserved "
                "rather than pushed. The full stdout+stderr outlives the crew "
                "worktree — read the log named above rather than guessing from "
                "the excerpt (BUG-MSO-2026-0506)."
                + (f" Recorded remedy: {operator_action}" if operator_action else "")),
        evidence=tuple(evidence),
        options=_finalise_options(options, allow_fallback=not ambiguous),
        voyage_id=_text(data.get("voyageId")),
        role=_text(data.get("targetRole")),
    )


def _convergence_failed(order_id: str, data: Dict[str, Any],
                        ctx: BlockageContext, status: str) -> Optional[Blockage]:
    convergence = _as_dict(data.get("convergence"))
    failed = bool(convergence.get("failed")) or status == "CONVERGENCE_FAILED"
    if not failed:
        return None
    error = _first_sentence(convergence.get("error"))
    note = _text(data.get("operatorNote"))

    evidence = _salvage_evidence(data)
    if note:
        # BUG-MSO-2026-0703 already renders the whole recovery in one field.
        evidence.insert(0, Evidence(kind="operatorNote",
                                    label="Recorded recovery note", detail=note))

    # A convergence failure is BUG-MSO-2026-0273's fast path: the role FINISHED
    # and only the merge failed, so merging IS the completion.
    options, ambiguous = _retry_options(
        order_id, data, _text(data.get("targetRole")), recommend_salvage=True)

    return Blockage(
        subject_id=order_id,
        subject_kind="order",
        kind=KIND_CONVERGENCE_FAILED,
        cause=("The crew finished, but merging its work into the voyage branch "
               "failed. The work exists and is preserved."
               + (f" {error}" if error else "")),
        since=_text(convergence.get("failedAt")),
        severity=_KIND_SEVERITY[KIND_CONVERGENCE_FAILED],
        detail=("The role completed and its output was committed, then the "
                "crew-to-voyage merge failed. Nothing was lost: the work sits "
                "on the salvage branch named above. Because the role is "
                "finished, arming that salvage is itself the completion "
                "(BUG-MSO-2026-0273) — re-running the role would rebuild work "
                "that already exists."
                + (f" {note}" if note else "")),
        evidence=tuple(evidence),
        options=_finalise_options(options, allow_fallback=not ambiguous),
        voyage_id=_text(data.get("voyageId")),
        role=_text(data.get("targetRole")),
    )


def _auto_serialize(order_id: str, data: Dict[str, Any], ctx: BlockageContext,
                    status: str) -> Optional[Blockage]:
    block = _as_dict(data.get("autoSerialized"))
    if not block and status != "AUTO_SERIALIZE":
        return None
    files = [str(f) for f in _as_list(block.get("conflictFiles"))]
    conflict_phrase = ""
    if files:
        shown = ", ".join(files[:3])
        if len(files) > 3:
            shown += ", …"
        conflict_phrase = f" Conflicting files: {len(files)} ({shown})."

    evidence = _salvage_evidence(data)
    branch = _text(block.get("salvageBranch"))
    if branch and not any(e.branch == branch for e in evidence):
        evidence.append(Evidence(kind="salvageBranch",
                                 label=f"Serialized-out work on {branch}",
                                 branch=branch))

    return Blockage(
        subject_id=order_id,
        subject_kind="order",
        kind=KIND_AUTO_SERIALIZE,
        cause=("A genuine source conflict with another crew's work took this "
               "order out of the voyage. Its changes are on a salvage branch "
               "and were never merged." + conflict_phrase),
        since=_text(block.get("at")),
        severity=_KIND_SEVERITY[KIND_AUTO_SERIALIZE],
        detail=("Convergence hit a real source conflict (not the bookkeeping "
                "classes that auto-resolve), so this order was serialized out "
                "of the voyage and its work left on a salvage branch. This is "
                "the class where an order can read COMPLETE while its only code "
                "changes sit unmerged — check the branch before trusting the "
                "order's status." + conflict_phrase),
        evidence=tuple(evidence),
        options=_finalise_options(*_serialize_retry(order_id, data)),
        voyage_id=_text(data.get("voyageId")),
        role=_text(data.get("targetRole")),
    )


# ---------------------------------------------------------------------------
# REL voyage-completion stalls (PLAN-PLN-MSO-2026-0747 Order 7)
# ---------------------------------------------------------------------------

#: The ``## Merge Recommendation`` section of REL's voyage report
#: (``.mso/reports/voyage/VOYAGE-{ORDER-ID}.md``), through the next heading or
#: end of file. `maestro/roles/REL.md`'s template owns the exact wording; this
#: reads what REL actually wrote, never a re-derivation of the verdict.
_MERGE_RECOMMENDATION_RE = re.compile(
    r"##\s*Merge Recommendation[^\n]*\n(?P<body>.*?)(?=\n##\s|\Z)",
    re.IGNORECASE | re.DOTALL)

#: The provider roll-call line REL's template writes under ``## Voyage``:
#: ``Providers: scm=github, ci=github_actions, issues=none``. Read here so a
#: provider id comes from what REL itself recorded, never guessed.
_PROVIDERS_LINE_RE = re.compile(
    r"providers:\s*scm=(?P<scm>[^\s,]+)\s*,?\s*ci=(?P<ci>[^\s,]+)\s*,?\s*"
    r"issues=(?P<issues>[^\s,\n]+)", re.IGNORECASE)

#: REL.md's own degradation wording ("record it `SKIPPED — <reason>`") and the
#: `resolve("kind")` phrasing PLAN-PLN-MSO-2026-0747 §9 and crew.py's
#: `build_rel_guidance` both use for an unavailable provider.
_SKIPPED_REASON_RE = re.compile(r"SKIPPED\s*[—\-]\s*(?P<reason>[^\n]+)", re.IGNORECASE)
_PROVIDER_UNAVAILABLE_RE = re.compile(
    r"\bprovider\b[^\n]{0,80}\bunavailable\b"
    r"|\bunavailable\b[^\n]{0,80}\bprovider\b"
    r"|resolve\(\s*[\"']?(?P<kind>scm|ci|issues)[\"']?\s*\)[^\n]{0,80}unavailable",
    re.IGNORECASE)


def _rel_voyage_report_text(order_id: str, ctx: BlockageContext) -> str:
    """The voyage completion report REL wrote before signalling BLOCKED.

    ``""`` when it was never written (a crash before REL got that far) or is
    unreadable — the two classifiers below fall back to ``stalledReason`` in
    that case, never fabricate a report that is not on disk.
    """
    path = ctx.artefact_root / "reports" / "voyage" / f"VOYAGE-{order_id}.md"
    try:
        if path.is_file():
            return path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        pass
    return ""


def _rel_blocked_role(data: Dict[str, Any], status: str) -> str:
    """"REL" when this order is a STALLED order REL itself blocked on.

    ``stalledCause == "BLOCKED_BY_ROLE"`` (`STALLED_CAUSE_BY_STATUS` in
    ``fleet_runner.py``) is what distinguishes "REL deliberately signalled
    BLOCKED" from "REL crashed / ran out of requeues", which stays a plain
    :func:`_stalled` — this narrower kind exists for the FIRST case only.
    """
    if status != "STALLED":
        return ""
    if _text(data.get("stalledCause")).upper() != "BLOCKED_BY_ROLE":
        return ""
    stalled_by = _as_dict(data.get("stalledBy"))
    role = _text(stalled_by.get("role")) or _text(data.get("targetRole"))
    return role if role == "REL" else ""


def _rel_report_evidence(order_id: str, ctx: BlockageContext,
                         report_text: str, data: Dict[str, Any]) -> List[Evidence]:
    evidence: List[Evidence] = []
    if report_text:
        path = ctx.artefact_root / "reports" / "voyage" / f"VOYAGE-{order_id}.md"
        evidence.append(Evidence(
            kind="artefact", label="Voyage completion report",
            path=str(path), artefact_key=f"voyage:VOYAGE-{order_id}.md"))
    evidence.extend(_salvage_evidence(data))
    return evidence


def _provider_unavailable(order_id: str, data: Dict[str, Any],
                          ctx: BlockageContext, status: str) -> Optional[Blockage]:
    role = _rel_blocked_role(data, status)
    if not role:
        return None
    reason_text = _text(data.get("stalledReason"))
    report_text = _rel_voyage_report_text(order_id, ctx)
    haystack = f"{reason_text}\n{report_text}"
    match = _PROVIDER_UNAVAILABLE_RE.search(haystack)
    if not match:
        return None

    kind = _text(match.groupdict().get("kind")).lower()
    if not kind:
        km = re.search(r'resolve\(\s*["\']?(scm|ci|issues)["\']?\s*\)',
                       haystack, re.IGNORECASE)
        kind = _text(km.group(1)).lower() if km else ""
    kind_label = kind or "provider"

    provider_id = ""
    pm = _PROVIDERS_LINE_RE.search(report_text)
    if pm and kind in pm.groupdict():
        provider_id = _text(pm.group(kind))
    if not provider_id:
        idm = re.search(rf"{re.escape(kind)}\s*=\s*([^\s,\n]+)", haystack,
                        re.IGNORECASE) if kind else None
        provider_id = _text(idm.group(1)) if idm else ""
    id_label = provider_id or "unknown"

    reason = ""
    sm = _SKIPPED_REASON_RE.search(haystack)
    if sm:
        reason = _clip(sm.group("reason"), 200)
    if not reason:
        reason = _first_sentence(reason_text) or "did not respond when REL needed it"

    voyage = _text(data.get("voyageId"))
    evidence = _rel_report_evidence(order_id, ctx, report_text, data)

    options: List[Option] = [Option(
        label=f"Fix the {kind_label} provider ({id_label}) — credentials, "
              f"host allowlisting, or reachability",
        command="",
        risk_note="Not a code or review failure; REL could not complete its "
                  "checklist without this provider.",
    )]
    retry, ambiguous = _retry_options(order_id, data, "REL")
    options.extend(retry)

    return Blockage(
        subject_id=order_id,
        subject_kind="order",
        kind=KIND_PROVIDER_UNAVAILABLE,
        cause=(f"REL blocked because the {kind_label} provider ({id_label}) "
               f"was unavailable: {reason}."),
        since=_text(data.get("stalledAt")) or _text(_as_dict(data.get("stalledBy")).get("endTime")),
        severity=_KIND_SEVERITY[KIND_PROVIDER_UNAVAILABLE],
        detail=(f"REL resolved the {kind_label} provider as `{id_label}` and "
                f"it was unavailable — {reason}. This is a configuration or "
                f"connectivity gap, not a code or review outcome: fix the "
                f"provider, then re-dispatch REL — it re-runs the whole "
                f"voyage-completion checklist."),
        evidence=tuple(evidence),
        options=_finalise_options(options, allow_fallback=not ambiguous),
        voyage_id=voyage,
        role="REL",
    )


def _rel_not_ready(order_id: str, data: Dict[str, Any],
                   ctx: BlockageContext, status: str) -> Optional[Blockage]:
    role = _rel_blocked_role(data, status)
    if not role:
        return None
    reason_text = _text(data.get("stalledReason"))
    report_text = _rel_voyage_report_text(order_id, ctx)

    section = ""
    m = _MERGE_RECOMMENDATION_RE.search(report_text)
    if m:
        section = _text(m.group("body"))
    if "NOT READY" not in section.upper() and "NOT READY" not in reason_text.upper():
        return None

    unresolved = [
        line.strip().lstrip("-*").strip()
        for line in section.splitlines()
        if line.strip().startswith(("-", "*"))
    ]
    # Drop a bare "READY / NOT READY" bullet — the template's own verdict
    # line, not an unresolved item — so it does not duplicate `cause`'s own
    # "REL recommended NOT READY" clause.
    unresolved = [u for u in unresolved if u.upper() not in ("NOT READY", "READY / NOT READY")]
    if not unresolved and reason_text:
        unresolved = [reason_text]
    items_text = "; ".join(unresolved[:5]) if unresolved else _clip(section, 200) or "see the voyage report"

    voyage = _text(data.get("voyageId"))
    evidence = _rel_report_evidence(order_id, ctx, report_text, data)

    options: List[Option] = []
    retry, ambiguous = _retry_options(order_id, data, "REL")
    options.extend(retry)

    return Blockage(
        subject_id=order_id,
        subject_kind="order",
        kind=KIND_REL_NOT_READY,
        cause=f"REL recommended NOT READY: {items_text}.",
        since=_text(data.get("stalledAt")) or _text(_as_dict(data.get("stalledBy")).get("endTime")),
        severity=_KIND_SEVERITY[KIND_REL_NOT_READY],
        detail=(f"REL completed its voyage-completion pass and recommended "
                f"`NOT READY` rather than signing off, so the order was "
                f"archived STALLED. Unresolved: {items_text}. This is a "
                f"judgement call REL made deliberately, not a crash — fix "
                f"what is named (in the voyage report above) on the voyage "
                f"branch, then re-dispatch REL; it re-runs the whole "
                f"checklist against the branch's current state."),
        evidence=tuple(evidence),
        options=_finalise_options(options, allow_fallback=not ambiguous),
        voyage_id=voyage,
        role="REL",
    )


def _stalled(order_id: str, data: Dict[str, Any], ctx: BlockageContext,
             status: str) -> Optional[Blockage]:
    if status != "STALLED":
        return None
    stalled_by = _as_dict(data.get("stalledBy"))
    role = _text(stalled_by.get("role")) or _text(data.get("targetRole"))
    reason = _text(data.get("stalledReason"))
    cause_code = _text(data.get("stalledCause")).upper()
    requeues = _int(data.get("requeueCount"))
    note = _text(data.get("operatorNote"))
    voyage = _text(data.get("voyageId"))

    # BUG-MSO-2026-0705: a rejection stall is a DIFFERENT event from a crew
    # giving up, and its recovery is a re-run of the PREVIOUS role. Both the
    # sentence and the command are owned by role_rejection — quoted, never
    # re-worded, so `mso status`, `mso doctor` and the Hub all say one thing.
    rejection_line = ""
    rejection_command = ""
    try:
        from maestro.core import role_rejection
        rejection_line = _text(role_rejection.describe_rejection(data))
        if rejection_line:
            rejection_command = _text(role_rejection.retry_command(order_id, data))
    except Exception:
        rejection_line, rejection_command = "", ""

    if rejection_line:
        cause = (f"Rejected on review, not merely failed — {rejection_line}. "
                 f"The work is on the voyage branch AND was rejected; the "
                 f"rebuild has to happen.")
    else:
        cause = (f"Gave up after {requeues} requeue(s)"
                 f"{f' at {role}' if role else ''}"
                 f"{f': {reason}' if reason else ''}. Only a retry can move it.")

    evidence: List[Evidence] = []
    if note:
        evidence.append(Evidence(kind="operatorNote",
                                 label="Recorded recovery note", detail=note))
    evidence.extend(_salvage_evidence(data))

    briefs = _as_list(data.get("timeoutBriefs"))
    if briefs:
        last = _as_dict(briefs[-1])
        partial = _as_dict(last.get("partialWork"))
        detail_bits = [f"reason={_text(last.get('reason')) or '?'}"]
        if partial.get("evidence"):
            detail_bits.append(
                f"{len(_as_list(partial.get('evidence')))} piece(s) of partial work on disk")
        evidence.append(Evidence(
            kind="timeoutBrief",
            label=f"Last timeout brief (crew {last.get('crew') or '?'})",
            detail="; ".join(detail_bits)))

    crew_num = stalled_by.get("crew")
    if crew_num is not None:
        crew_dir = ctx.artefact_root / "crews" / f"crew{crew_num}"
        evidence.append(Evidence(kind="crewOutput",
                                 label=f"Crew {crew_num} output directory",
                                 path=str(crew_dir)))
    for line in ctx.lifecycle_lines(order_id)[-3:]:
        evidence.append(Evidence(kind="lifecycle", label="Lifecycle event",
                                 detail=line))

    options: List[Option] = []
    if rejection_command:
        options.append(Option(
            label=f"Rebuild against the rejection ({rejection_line})"
                  if rejection_line else "Rebuild against the rejection",
            command=rejection_command,
            hub_action="orderRetry", hub_method="POST",
            hub_path=f"/api/v1/orders/{order_id}/retry",
            capability="orderRetry",
            recommended=True,
        ))
    retry, ambiguous = _retry_options(order_id, data, role)
    options.extend(retry)
    dependents = _dependents_of(order_id, ctx)
    options.append(Option(
        label="Skip and release dependents",
        command=f"mso order skip {order_id}",
        hub_action="orderSkip", hub_method="POST",
        hub_path=f"/api/v1/orders/{order_id}/skip",
        capability="orderSkip",
        risk_note=(f"The {len(dependents)} order(s) waiting on it are released; "
                   f"this one is never dispatched again."
                   if dependents else
                   "This order is never dispatched again."),
    ))

    detail = (f"{order_id} exhausted its requeue budget"
              f"{f' at {role}' if role else ''} and was archived STALLED"
              f"{f' (cause {cause_code})' if cause_code else ''}. "
              f"The fleet will not touch it again by itself.")
    if rejection_line:
        detail = (f"{order_id} was archived STALLED because a reviewing role "
                  f"REJECTED it: {rejection_line}. This is a rejection, not a "
                  f"crash — the work merged and was judged insufficient, so the "
                  f"recovery is a rebuild by the previous role, not a plain "
                  f"retry.")
    if note:
        detail += f" {note}"

    return Blockage(
        subject_id=order_id,
        subject_kind="order",
        kind=KIND_STALLED,
        cause=cause,
        since=_text(data.get("stalledAt")) or _text(stalled_by.get("endTime")),
        severity=_KIND_SEVERITY[KIND_STALLED],
        detail=detail,
        evidence=tuple(evidence),
        options=_finalise_options(options, allow_fallback=not ambiguous),
        voyage_id=voyage,
        role=role,
    )


def _timeout_requeued(order_id: str, data: Dict[str, Any], ctx: BlockageContext,
                      status: str) -> Optional[Blockage]:
    if status not in ("PENDING", "REQUEUE", "REOPENED", "MAX_TURNS"):
        return None
    requeues = _int(data.get("requeueCount"))
    briefs = _as_list(data.get("timeoutBriefs"))
    if requeues <= 0 or not briefs:
        return None

    last = _as_dict(briefs[-1])
    role = _text(last.get("role")) or _text(data.get("targetRole"))
    reason = _text(last.get("reason")) or "TIMEOUT"
    partial = _as_dict(last.get("partialWork"))

    evidence: List[Evidence] = []
    detail_bits = [f"reason={reason}"]
    if partial.get("evidence"):
        detail_bits.append(
            f"{len(_as_list(partial.get('evidence')))} piece(s) of partial work on disk")
    evidence.append(Evidence(
        kind="timeoutBrief",
        label=f"Timeout brief (crew {last.get('crew') or '?'}, {reason})",
        detail="; ".join(detail_bits)))
    evidence.extend(_salvage_evidence(data))
    crew_num = last.get("crew")
    if crew_num is not None:
        evidence.append(Evidence(
            kind="crewOutput", label=f"Crew {crew_num} output directory",
            path=str(ctx.artefact_root / "crews" / f"crew{crew_num}")))

    ceiling = _int(data.get("timeoutMinutes"))
    options: List[Option] = [Option(
        label="Wait — the dispatcher will re-dispatch it by itself",
        command="",
        risk_note="One attempt remains before it STALLs.",
        recommended=True,
    )]
    if ceiling:
        options.append(Option(
            label=(f"Raise this order's ceiling above {ceiling}m "
                   f"(set `timeoutMinutes` on the order JSON)"),
            command="",
            risk_note="No CLI verb sets this yet — edit the order JSON.",
        ))
    else:
        options.append(Option(
            label="Give this order its own ceiling (set `timeoutMinutes` on the order JSON)",
            command="",
            risk_note="No CLI verb sets this yet — edit the order JSON.",
        ))
    retry, ambiguous = _retry_options(order_id, data, role)
    options.extend(retry)

    return Blockage(
        subject_id=order_id,
        subject_kind="order",
        kind=KIND_TIMEOUT_REQUEUED,
        cause=(f"Timed out{f' at {role}' if role else ''} and was re-queued "
               f"({requeues} attempt(s) used). The fleet will retry it by itself."),
        since=_text(last.get("timestamp")),
        severity=_KIND_SEVERITY[KIND_TIMEOUT_REQUEUED],
        detail=("This order is RECOVERING, not stuck: it was killed at its "
                "ceiling, its in-flight work was preserved, and the dispatcher "
                "will pick it up again on a following tick. The honest answer "
                "is usually 'nothing — leave it'. It becomes STALLED only if it "
                "exhausts its requeue budget."),
        evidence=tuple(evidence),
        options=_finalise_options(options, allow_fallback=not ambiguous),
        voyage_id=_text(data.get("voyageId")),
        role=role,
    )


def _dependents_of(order_id: str, ctx: BlockageContext) -> List[str]:
    """Live orders that declare *order_id* in their ``dependsOn``."""
    out: List[str] = []
    for oid, data in ctx.live_orders.items():
        if order_id in depends_on(data):
            out.append(oid)
    return sorted(out)


def _needs_a_human(order_id: str, status: str, ctx: "BlockageContext") -> bool:
    """True when this order cannot resolve without an operator.

    Three families qualify, and this boundary is what makes ``DEP_HELD`` useful
    rather than noisy:

    * a terminal non-COMPLETE status — judged by
      :func:`maestro.core.deadlock.is_blocker_status`, the SAME frozenset the
      deadlock classifier uses, so the two can never drift;
    * an operator-skipped order (never dispatched again);
    * ``NAV_REVIEW_PENDING`` — a decision only a person can give.

    That last one is deliberately WIDER than ``deadlock.py``'s blocker set, and
    correctly so: that module answers "can this voyage EVER finish by itself",
    where a pending approval is not fatal. This one answers "why is this order
    not running", where "someone has to approve its dependency" is exactly the
    answer the operator needs.

    Everything else — PENDING, RUNNING, CLAIMED — is the fleet working through
    its queue, and resolves on its own.
    """
    if order_id in ctx.skipped:
        return True
    upper = _text(status).upper()
    if upper == "NAV_REVIEW_PENDING":
        return True
    try:
        from maestro.core.deadlock import is_blocker_status
        return bool(is_blocker_status(upper))
    except Exception:
        return classify_status(upper) == "blocked"


def _root_blocker(order_id: str, ctx: "BlockageContext",
                  budget: int = 64) -> Optional[Tuple[str, str]]:
    """Walk ``dependsOn`` to the first dependency that needs a human.

    Returns ``(root_id, root_status)``, or ``None`` when every unsatisfied
    dependency in the chain is merely queued or in flight — i.e. when the fleet
    will get there by itself.

    Breadth-first, cycle-safe via a visited set, and hard-bounded by *budget*,
    so a pathological manifest costs a bounded walk rather than a hang. This is
    the "walked to its root for the blocker list (cheap, ids only)" half of the
    plan's depth rule — only the ROOT's full Blockage is ever computed.
    """
    seen = {order_id}
    frontier: List[str] = list(depends_on(ctx.order_data(order_id)))
    while frontier and budget > 0:
        budget -= 1
        current = frontier.pop(0)
        if current in seen:
            continue
        seen.add(current)
        current_data = ctx.order_data(current)
        current_status = ctx.status_of(current, current_data)
        if (classify_status(current_status) == "complete"
                and current not in ctx.skipped):
            continue  # satisfied
        if _needs_a_human(current, current_status, ctx):
            return current, current_status
        frontier.extend(d for d in depends_on(current_data) if d not in seen)
    return None


def _queued_behind_progress(order_id: str, data: Dict[str, Any],
                            ctx: BlockageContext,
                            blockers: "List[BlockerRef]",
                            hold: Dict[str, Any]) -> Optional[Blockage]:
    """The honest "you are in line" record: held, but the fleet is coming.

    Every unsatisfied dependency in this order's chain is PENDING, RUNNING or
    CLAIMED — the fleet will get to all of them, so there is nothing for an
    operator to do and no option worth offering beyond looking at what is
    ahead. Marked ``progressing`` so a sweep skips it and a drawer does not.
    """
    if not blockers:
        return None
    ahead = ", ".join(f"{b.order_id} ({b.status.lower()})" for b in blockers[:3])
    if len(blockers) > 3:
        ahead += ", …"
    age = age_phrase(_text(hold.get("heldSince")))
    return Blockage(
        subject_id=order_id,
        subject_kind="order",
        kind=KIND_DEP_HELD,
        cause=(f"Queued{f' for {age}' if age else ''} behind {len(blockers)} "
               f"dependency/ies the fleet is still working through: {ahead}. "
               f"Nothing is wrong and nothing is needed from you."),
        since=_text(hold.get("heldSince")),
        severity="low",
        detail=(f"{order_id} is dependency-held, but every order it waits on "
                f"is either queued or in flight — none of them needs an "
                f"operator, so this one will dispatch by itself once they "
                f"finish. It is reported here because 'why is this not "
                f"running' is a fair question with a real answer; it is "
                f"deliberately absent from `mso doctor` and the stuck sweep, "
                f"because it is not stuck."),
        blockers=tuple(blockers),
        options=(Option(label=f"Watch what it is waiting on ({blockers[0].order_id})",
                        command=f"mso order why {blockers[0].order_id}"),),
        voyage_id=_text(data.get("voyageId")),
        role=_text(data.get("targetRole")),
        progressing=True,
    )


def _dep_held(order_id: str, data: Dict[str, Any], ctx: BlockageContext,
              status: str, depth: int) -> Optional[Blockage]:
    hold = _as_dict(ctx.dep_holds.get(order_id))
    declared = depends_on(data)
    waiting_on = [str(w) for w in _as_list(hold.get("waitingOn"))]
    if not hold and not declared:
        return None

    # The direct unsatisfied dependencies — the "waiting on" list the operator
    # sees. Declared dependencies are the primary source because the
    # dispatcher's own `waitingOn` entries are ANNOTATED strings
    # ("FTR-... (STALLED)") rather than bare ids; the annotation is parsed only
    # as a fallback for a workspace whose order JSON has no dependsOn.
    blockers: List[BlockerRef] = []
    for dep in (declared or tuple(waiting_on)):
        dep_id = _order_id_token(dep)
        if not dep_id:
            continue
        dep_data = ctx.order_data(dep_id)
        dep_status = ctx.status_of(dep_id, dep_data)
        if classify_status(dep_status) == "complete" and dep_id not in ctx.skipped:
            continue  # satisfied
        blockers.append(BlockerRef(order_id=dep_id, status=dep_status))
    if not blockers:
        # Either the hold snapshot is stale (the dispatcher rewrites it on the
        # next scan tick) or every dependency completed. Not blocked.
        return None

    # Does this chain root in something that needs a human, or is this order
    # simply queued behind work the fleet is actively doing?
    #
    # Both are real answers to "why is this order not running" and the model
    # returns both — but they are NOT the same claim, and conflating them is
    # what made the first cut of this function report six healthy orders on
    # the live plane (FTR-0719/0720/0721/0722, DOC-0723, DOC-0624, every chain
    # rooting in a RUNNING order) as blocked. The dep-holds snapshot names all
    # of them, because the dispatcher records a hold for every unmet
    # dependency — "held" is simply not the same claim as "stuck".
    #
    # A queued-behind-progress record is marked `progressing`, which keeps it
    # out of `scan_stuck_orders` (and so out of `mso doctor`) while leaving it
    # available to the order drawer. See `Blockage.progressing`.
    root = _root_blocker(order_id, ctx)
    if root is None:
        return _queued_behind_progress(order_id, data, ctx, blockers, hold)
    root_id, root_status = root

    root_blockage = None
    if depth < 1:
        # Depth cap (plan section 3.9): exactly ONE full Blockage is computed
        # for the chain — the root's. The cap makes unbounded recursion on a
        # cyclic dependsOn structurally impossible rather than merely guarded.
        root_blockage = classify_order_blockage(
            root_id, ctx, data=ctx.order_data(root_id), _depth=depth + 1)

    if root_blockage is not None:
        blockers = [
            BlockerRef(order_id=b.order_id, status=b.status,
                       kind=root_blockage.kind if b.order_id == root_id else "",
                       cause=root_blockage.cause if b.order_id == root_id else "")
            for b in blockers
        ]

    age = age_phrase(_text(hold.get("heldSince")))
    ids = ", ".join(b.order_id for b in blockers)
    cause = (f"Held{f' for {age}' if age else ''} waiting on {len(blockers)} "
             f"dependency/ies: {ids}.")
    if root_blockage is not None:
        cause += f" {root_id} is itself {root_blockage.kind}: {root_blockage.cause}"
    else:
        cause += f" {root_id} is {root_status} and needs an operator."

    evidence: List[Evidence] = []
    # FTR-MSO-2026-0719: the dispatcher's own hold record, when there is one.
    # A held order's cause is a claim about what `scan_all_queues` decided;
    # this file is where it wrote that decision down, so it is the artefact an
    # operator opens to check the diagnosis rather than take it on trust.
    # Skipped entirely when the hold was derived from `dependsOn` alone — a
    # path to a file that does not name this order would be a false lead.
    if hold:
        hold_file = ctx.artefact_root / "state" / "dep-holds.json"
        try:
            if hold_file.is_file():
                evidence.append(Evidence(
                    kind="artefact", label="Dependency hold record",
                    path=str(hold_file),
                    detail=f"the {order_id} entry records this hold"))
        except OSError:
            pass
    for line in ctx.lifecycle_lines(order_id)[-2:]:
        evidence.append(Evidence(kind="lifecycle", label="Lifecycle event",
                                 detail=line))

    # Every option acts on the ROOT of the chain, never on this order. Acting
    # here would change nothing, and an option that changes nothing is worse
    # than no option at all — it costs the operator a round trip to discover
    # that the fleet was never going to move.
    options: List[Option] = []
    if root_blockage is not None:
        for opt in root_blockage.options[:3]:
            if not opt.command:
                continue
            options.append(Option(
                label=f"Unblock {root_id}: {opt.label}",
                command=opt.command, hub_action=opt.hub_action,
                hub_method=opt.hub_method, hub_path=opt.hub_path,
                capability=opt.capability, risk_note=opt.risk_note,
                recommended=opt.recommended))
    if not options:
        options.append(Option(
            label=f"Diagnose the blocking order {root_id}",
            command=f"mso order why {root_id}"))
    options.append(Option(
        label=f"Release this order by skipping {root_id}",
        command=f"mso order skip {root_id}",
        hub_action="orderSkip", hub_method="POST",
        hub_path=f"/api/v1/orders/{root_id}/skip",
        capability="orderSkip",
        risk_note=(f"{root_id} is then never dispatched again, and anything "
                   f"else waiting on it is released too."),
    ))

    detail = (f"{order_id} is dependency-held: `scan_all_queues` refuses to "
              f"dispatch it until {ids} "
              f"{'are' if len(blockers) > 1 else 'is'} satisfied. The chain "
              f"roots at {root_id} ({root_status}), which cannot resolve "
              f"without an operator. Acting on {order_id} itself changes "
              f"nothing — the action is on the root.")

    return Blockage(
        subject_id=order_id,
        subject_kind="order",
        kind=KIND_DEP_HELD,
        cause=cause,
        since=_text(hold.get("heldSince")),
        severity=_KIND_SEVERITY[KIND_DEP_HELD],
        detail=detail,
        evidence=tuple(evidence),
        blockers=tuple(blockers),
        options=_finalise_options(options),
        voyage_id=_text(data.get("voyageId")),
        role=_text(data.get("targetRole")),
    )


def _order_id_token(value: Any) -> str:
    """The bare order id inside a possibly-annotated ``waitingOn`` entry."""
    text = _text(value)
    if not text:
        return ""
    ids = _order_ids_in(text)
    return ids[0] if ids else text.split()[0]


# ---------------------------------------------------------------------------
# Public: order classification
# ---------------------------------------------------------------------------

def classify_order_blockage(order_id: str,
                            ctx: Optional[BlockageContext] = None,
                            data: Optional[Dict[str, Any]] = None,
                            artefact_root: Optional[Path] = None,
                            _depth: int = 0) -> Optional[Blockage]:
    """Why is this order stuck — or ``None`` when it is not.

    Walks :data:`ORDER_KIND_PRECEDENCE` and returns the FIRST match. ``None``
    is the common case (a COMPLETE, RUNNING or cleanly-PENDING order) and is
    kept cheap: the status bucket is checked before any classifier runs.

    Never raises. A corrupt order JSON, an unreadable plane or a missing
    directory yields ``None`` — the same degradation
    :func:`maestro.core.deadlock.classify_voyage_deadlock` guarantees, and for
    the same reason: every caller is on a hot path where an exception would
    take down a dashboard refresh or a patrol tick.
    """
    try:
        if ctx is None:
            ctx = BlockageContext.load(artefact_root)
        if data is None:
            data = ctx.order_data(order_id)
        if not isinstance(data, dict):
            return None

        status = ctx.status_of(order_id, data)

        # A skipped order is diagnosable whatever its status says — the skip is
        # the operator's decision and outranks it (precedence rule).
        if order_id not in ctx.skipped:
            if classify_status(status) in _NOT_STUCK_BUCKETS:
                return None

        for kind in ORDER_KIND_PRECEDENCE:
            handler = _ORDER_CLASSIFIERS.get(kind)
            if handler is None:
                continue
            try:
                if kind == KIND_DEP_HELD:
                    result = handler(order_id, data, ctx, status, _depth)
                else:
                    result = handler(order_id, data, ctx, status)
            except Exception:
                # One malformed block must not cost the whole diagnosis — the
                # next kind in precedence may still explain the order.
                continue
            if result is not None:
                return result
        return None
    except Exception:
        return None


_ORDER_CLASSIFIERS: Dict[BlockageKind, Callable[..., Optional[Blockage]]] = {
    KIND_SKIPPED: _skipped,
    KIND_REVIEW_PENDING: _review_pending,
    KIND_VERIFY_DEPS_FAILED: _verify_deps_failed,
    KIND_VERIFY_FAILED: _verify_failed,
    KIND_CONVERGENCE_FAILED: _convergence_failed,
    KIND_AUTO_SERIALIZE: _auto_serialize,
    KIND_PROVIDER_UNAVAILABLE: _provider_unavailable,
    KIND_REL_NOT_READY: _rel_not_ready,
    KIND_STALLED: _stalled,
    KIND_TIMEOUT_REQUEUED: _timeout_requeued,
    KIND_DEP_HELD: _dep_held,
}


# ---------------------------------------------------------------------------
# Public: voyage classification
# ---------------------------------------------------------------------------

def _wrap_deadlock(deadlock: Any, ctx: BlockageContext,
                   members: Sequence[Any] = ()) -> Blockage:
    """Wrap a :class:`~maestro.core.deadlock.VoyageDeadlock`, never re-derive it.

    ``summary()`` is passed through VERBATIM so the Hub banner and the
    ``mso status`` MISSION line stay byte-identical to what BUG-MSO-2026-0699
    shipped — this record is added information, never a substitution.
    """
    blockers: List[BlockerRef] = []
    for oid in (getattr(deadlock, "blocking_order_ids", ()) or ()):
        blocker_data = ctx.order_data(oid)
        nested = classify_order_blockage(oid, ctx, data=blocker_data, _depth=1)
        blockers.append(BlockerRef(
            order_id=oid,
            status=ctx.status_of(oid, blocker_data),
            kind=nested.kind if nested else "",
            cause=nested.cause if nested else "",
        ))

    primary = _text(getattr(deadlock, "blocking_order_id", ""))
    options: List[Option] = [Option(
        label=f"Recover the blocking order {primary}",
        command=_text(getattr(deadlock, "suggested_command", "")),
        hub_action="orderRetry", hub_method="POST",
        hub_path=f"/api/v1/orders/{primary}/retry",
        capability="orderRetry",
        recommended=True,
    )]
    primary_blockage = None
    if primary:
        primary_blockage = classify_order_blockage(
            primary, ctx, data=ctx.order_data(primary), _depth=1)
    if primary_blockage is not None:
        for opt in primary_blockage.options:
            if opt.command and opt.command != options[0].command:
                options.append(Option(
                    label=f"{primary}: {opt.label}",
                    command=opt.command,
                    hub_action=opt.hub_action, hub_method=opt.hub_method,
                    hub_path=opt.hub_path, capability=opt.capability,
                    risk_note=opt.risk_note,
                ))

    evidence: List[Evidence] = []
    for line in ctx.lifecycle_lines(primary)[-3:]:
        evidence.append(Evidence(kind="lifecycle", label="Lifecycle event",
                                 detail=line))

    # `cause` is the one-sentence slot and `detail` the paragraph one, so they
    # take the two renderings deadlock.py already offers rather than both
    # taking detail(). `blocker_label()` is quoted verbatim inside the frame —
    # it is the phrasing the Hub's phaseReason has always used, and BUG-0699
    # kept it deliberately so a deadlock reason still CONTAINS the reason the
    # board showed before.
    label = _text(getattr(deadlock, "blocker_label", lambda: "")())
    detail_text = _text(getattr(deadlock, "detail", lambda: "")())
    return Blockage(
        subject_id=_text(getattr(deadlock, "voyage_id", "")),
        subject_kind="voyage",
        kind=KIND_DEADLOCKED,
        cause=(f"Deadlocked behind {label} — every remaining order is held "
               f"behind it and the fleet cannot advance any of them."
               if label else detail_text),
        severity=_KIND_SEVERITY[KIND_DEADLOCKED],
        detail=detail_text,
        evidence=tuple(evidence),
        blockers=tuple(blockers),
        options=_finalise_options(options),
        voyage_id=_text(getattr(deadlock, "voyage_id", "")),
        role=_text(getattr(deadlock, "blocking_role", "")),
        summary_override=_text(getattr(deadlock, "summary", lambda: "")()),
    )


def classify_voyage_blockage(voyage_id: str,
                             ctx: Optional[BlockageContext] = None,
                             scan: Any = None,
                             artefact_root: Optional[Path] = None
                             ) -> Optional[Blockage]:
    """Why is this voyage not moving — or ``None`` when it is.

    Two shapes come out:

    * **DEADLOCKED** — :func:`maestro.core.deadlock.classify_voyage_deadlock`
      already said so. Wrapped verbatim (see :func:`_wrap_deadlock`); nothing
      is re-derived, so this can never disagree with ``mso status``, the
      patrol check or the Hub board.
    * **Not progressing** — not a deadlock (the fleet COULD still move it) but
      every remaining member is individually blocked and no crew is running.
      This is the VOY-MSO-2026-0163 shape that ``deadlock.py`` deliberately
      declines to call a deadlock — correctly, since approving a review or
      retrying one order would release it — and which still needs explaining.
      Its ``kind`` is the most common member kind, with one
      :class:`BlockerRef` per blocked member.

    A voyage with a dispatchable order, a running crew, or nothing left to do
    returns ``None``. Never raises.
    """
    try:
        if ctx is None:
            ctx = BlockageContext.load(artefact_root)

        if scan is None:
            try:
                from maestro.core.deadlock import scan_voyage_members
                for candidate in scan_voyage_members(ctx.artefact_root):
                    if candidate.voyage_id == voyage_id:
                        scan = candidate
                        break
            except Exception:
                scan = None
        if scan is None:
            return None

        deadlock = getattr(scan, "deadlock", None)
        if deadlock is not None:
            return _wrap_deadlock(deadlock, ctx, getattr(scan, "members", ()))

        if not getattr(scan, "in_flight", True):
            return None  # deliberately parked by an operator — not stuck

        members = list(getattr(scan, "members", ()) or ())
        remaining = [m for m in members
                     if classify_status(m.status) != "complete"]
        if not remaining:
            return None
        if any(classify_status(m.status) == "inProgress" for m in remaining):
            return None  # a crew is on it — the fleet is moving

        per_member: List[Tuple[Any, Blockage]] = []
        for member in remaining:
            blockage = classify_order_blockage(
                member.order_id, ctx, data=ctx.order_data(member.order_id),
                _depth=1)
            if blockage is None or blockage.progressing:
                # This member can still move on its own, so the voyage can.
                # `progressing` counts as movable here for the same reason it
                # is excluded from the stuck sweep: the fleet gets to it.
                return None
            per_member.append((member, blockage))
        if not per_member:
            return None

        counts: Dict[str, int] = {}
        for _, blockage in per_member:
            counts[blockage.kind] = counts.get(blockage.kind, 0) + 1
        # Ties break on SEVERITY, then on ORDER_KIND_PRECEDENCE. Severity first
        # because the common shape is a 1-of-each tie (VOY-MSO-2026-0163 was
        # exactly that), and precedence alone would then hand the voyage's
        # headline to SKIPPED — the least urgent member — while its severity
        # came from the worst one. A voyage labelled SKIPPED and coloured high
        # is a self-contradicting banner. Precedence remains the final
        # tie-break, so the reported kind is stable across refreshes rather
        # than dict-order dependent.
        def _dominance(kind: str) -> Tuple[int, int, int]:
            return (
                counts[kind],
                _severity_rank(_KIND_SEVERITY.get(kind, "high")),
                -(ORDER_KIND_PRECEDENCE.index(kind)
                  if kind in ORDER_KIND_PRECEDENCE else len(ORDER_KIND_PRECEDENCE)),
            )

        dominant = max(counts, key=_dominance)

        blockers = tuple(
            BlockerRef(order_id=m.order_id, status=m.status,
                       kind=b.kind, cause=b.cause)
            for m, b in per_member)

        breakdown = ", ".join(f"{n} {kind}" for kind, n in
                              sorted(counts.items(), key=lambda kv: -kv[1]))
        worst = max(per_member,
                    key=lambda pair: _severity_rank(pair[1].severity))[1]

        options: List[Option] = []
        for opt in worst.options[:3]:
            if opt.command:
                options.append(Option(
                    label=f"{worst.subject_id}: {opt.label}",
                    command=opt.command,
                    hub_action=opt.hub_action, hub_method=opt.hub_method,
                    hub_path=opt.hub_path, capability=opt.capability,
                    risk_note=opt.risk_note, recommended=opt.recommended,
                ))
        if not options:
            options.append(Option(
                label=f"Inspect {worst.subject_id}",
                command=f"mso order why {worst.subject_id}"))

        return Blockage(
            subject_id=voyage_id,
            subject_kind="voyage",
            kind=dominant,
            cause=(f"Not progressing: all {len(remaining)} remaining order(s) "
                   f"are blocked and no crew is running. Start with "
                   f"{worst.subject_id} ({worst.kind})."),
            severity=worst.severity,
            detail=(f"{voyage_id} has {len(remaining)} outstanding order(s), "
                    f"every one of them blocked ({breakdown}), and nothing in "
                    f"flight. This is NOT a deadlock: at least one of these can "
                    f"be released by an operator decision (an approval, a "
                    f"retry, an unskip) rather than needing the whole chain "
                    f"unwound — which is why `deadlock.py` correctly declines "
                    f"to call it one. Start with {worst.subject_id} — "
                    f"{worst.cause}"),
            blockers=blockers,
            options=_finalise_options(options),
            voyage_id=voyage_id,
        )
    except Exception:
        return None


def _severity_rank(severity: str) -> int:
    return {"critical": 4, "high": 3, "medium": 2, "low": 1}.get(
        _text(severity).lower(), 0)


# ---------------------------------------------------------------------------
# Public: whole-plane sweeps
# ---------------------------------------------------------------------------

def scan_stuck_orders(ctx: Optional[BlockageContext] = None,
                      artefact_root: Optional[Path] = None
                      ) -> List[Blockage]:
    """Every live order that is stuck, worst first, from ONE plane read.

    Only orders sitting in a scanned queue directory are swept: an archived
    COMPLETE order is finished, and an archived STALLED one is reachable by id
    through :func:`classify_order_blockage` (which is what
    ``mso order why <id>`` calls) without every sweep paying to re-diagnose the
    whole history.

    Never raises — a workspace it cannot read yields ``[]``.
    """
    try:
        if ctx is None:
            ctx = BlockageContext.load(artefact_root)
        out: List[Blockage] = []
        for order_id, data in sorted(ctx.live_orders.items()):
            blockage = classify_order_blockage(order_id, ctx, data=data)
            # `progressing` records answer "why is this not running" (the
            # drawer's question) but not "what is stuck" (this sweep's, and
            # `mso doctor`'s). Including them reports healthy queue order as a
            # fault; dropping the record from the model instead would blind the
            # drawer. See Blockage.progressing.
            if blockage is not None and not blockage.progressing:
                out.append(blockage)
        out.sort(key=lambda b: (-_severity_rank(b.severity), b.subject_id))
        return out
    except Exception:
        return []


def scan_voyage_blockages(ctx: Optional[BlockageContext] = None,
                          artefact_root: Optional[Path] = None
                          ) -> List[Blockage]:
    """Every active voyage that is not moving, worst first, from ONE plane read."""
    try:
        if ctx is None:
            ctx = BlockageContext.load(artefact_root)
        try:
            from maestro.core.deadlock import scan_voyage_members
            scans = scan_voyage_members(ctx.artefact_root)
        except Exception:
            scans = []
        out: List[Blockage] = []
        for scan in scans:
            blockage = classify_voyage_blockage(scan.voyage_id, ctx, scan=scan)
            if blockage is not None:
                out.append(blockage)
        out.sort(key=lambda b: (-_severity_rank(b.severity), b.subject_id))
        return out
    except Exception:
        return []
