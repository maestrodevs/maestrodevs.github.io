"""Per-role start/end history on the order schema (FTR-MSO-2026-0598).

Why this exists
----------------
An order today carries a single top-level ``startedAt``, overwritten on
every claim (dispatch, requeue, retry). That makes "did role X deliver
during X's own turn" unanswerable except for whichever role is CURRENT:

- PR #372's review found ``_voyage_report_present()`` matches on ``voyageId``
  with no recency filter, so one voyage-named report satisfies the gate for
  every REL order in the voyage, and for every requeue of the same order —
  there is no per-turn timestamp to filter against.
- ``_find_stall_origin_role()`` (``fleet_runner.py``) probes the UPSTREAM
  role's deliverable using the BLOCKED (downstream) role's ``startedAt``,
  so it blames the upstream role for a stall even when the upstream role
  delivered on time — the two roles' start times are indistinguishable
  once only one ``startedAt`` exists.

See PLAN-PLN-MSO-2026-0592 §2.6. This module is the prerequisite Order 4
plan calls for; the deliverable-gate rewrite that actually consumes it is
FTR-MSO-2026-0599 (Order 5).

Schema
------
``roleHistory`` is an append-only list living on the order JSON, one entry
per role TURN — a fresh claim of a role, including a second (or third, ...)
claim of the SAME role after a requeue opens a NEW entry rather than
reusing the last one::

    "roleHistory": [
        {"role": "PLN", "startedAt": "2026-08-28T10:00:00", "endedAt": "2026-08-28T10:40:00"},
        {"role": "BLD", "startedAt": "2026-08-28T10:40:05", "endedAt": null},
    ]

At most one entry is ever open (``endedAt is None``) at a time. The legacy
top-level ``startedAt``/``targetRole``/``assignedTo`` fields are UNCHANGED —
this module adds ``roleHistory`` alongside them, it does not replace them,
so every existing reader keeps working exactly as before.

Backwards compatibility (FTR-0598 AC2)
---------------------------------------
Every order archived before this shipped has no ``roleHistory`` key at all.
Every function here degrades on that shape: writers create the key lazily
(``setdefault``) and never raise if it is missing; readers return ``None``/
``[]`` rather than raising. Never a crash, never a fail-closed verdict on a
missing key — the whole point (per the order's description) is that months
of archived orders and every workspace's Hub keep reading correctly.

Consumption note for FTR-MSO-2026-0599 (Order 5)
--------------------------------------------------
``latest_started_at(data, role)`` is the replacement for
``data.get("startedAt")`` wherever a caller today assumes ``startedAt``
belongs to a specific role. In particular:

- ``_find_stall_origin_role()`` should call
  ``latest_started_at(data, upstream_role)`` instead of reading the
  (blocked, downstream) order's bare ``startedAt`` — that is the one-line
  fix for the misattribution in §2.6.
- Any recency-filtered deliverable check (``_voyage_report_present()``,
  ``_investigation_report_present()``, the future shared per-role artefact
  helper) should use ``latest_started_at(data, completing_role)`` as its
  ``since`` floor instead of the order-wide ``startedAt`` — that closes the
  "one report satisfies every requeue" gap (§2.5).

On a legacy order (no ``roleHistory``), ``latest_started_at`` falls back to
today's exact behaviour (the bare ``startedAt``, only when it belongs to the
order's current role) — so Order 5's rewrite is safe to ship against
archived orders without a migration.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional


def open_role_turn(data: Dict[str, Any], role: str, at_iso: Optional[str] = None) -> str:
    """Start a new ``roleHistory`` turn for *role* on *data* (mutated in place).

    Closes any still-open turn first (defensive — every legitimate call site
    already closes the prior turn before opening the next one; this just
    keeps the invariant "at most one open entry" true even if a future call
    site forgets). Returns the ISO timestamp used, so a caller that also
    stamps the legacy ``data["startedAt"]`` can share one value.
    """
    at_iso = at_iso or datetime.now().isoformat()
    close_role_turn(data, at_iso=at_iso)
    history = data.setdefault("roleHistory", [])
    history.append({"role": role, "startedAt": at_iso, "endedAt": None})
    return at_iso


def close_role_turn(data: Dict[str, Any], at_iso: Optional[str] = None) -> None:
    """Close the most recently opened ``roleHistory`` turn on *data*, if any.

    No-op when ``roleHistory`` is absent (legacy order) or has no open
    entry — safe to call at every requeue/hold/stall/advance/archive site
    unconditionally, including ones a legacy order will hit before it ever
    gains a ``roleHistory`` key.
    """
    history = data.get("roleHistory")
    if not history:
        return
    for entry in reversed(history):
        if entry.get("endedAt") is None:
            entry["endedAt"] = at_iso or datetime.now().isoformat()
            return


def entries_for_role(data: Dict[str, Any], role: str) -> List[Dict[str, Any]]:
    """All recorded ``roleHistory`` turns for *role*, oldest first.

    ``[]`` when ``roleHistory`` is absent or *role* never ran — never raises.
    """
    history = data.get("roleHistory") or []
    return [entry for entry in history if entry.get("role") == role]


def latest_started_at(data: Dict[str, Any], role: str) -> Optional[str]:
    """The ``startedAt`` of *role*'s most recent turn.

    Prefers ``roleHistory`` when present. Falls back to the legacy
    top-level ``startedAt`` ONLY when ``roleHistory`` is entirely absent
    (a pre-FTR-0598 order) and the order's current assignment names *role*
    — i.e. exactly today's pre-roleHistory behaviour. A legacy order that
    never ran *role* as its current one carries no way to know when a past
    turn of *role* started, and this returns ``None`` rather than guessing.
    """
    entries = entries_for_role(data, role)
    if entries:
        return entries[-1].get("startedAt")
    if "roleHistory" in data:
        return None
    assigned_role = (data.get("assignedTo") or {}).get("role")
    if assigned_role == role or data.get("targetRole") == role:
        return data.get("startedAt")
    return None


def run_started_at(data: Dict[str, Any], role: str) -> Optional[str]:
    """The ``startedAt`` of the FIRST turn in *role*'s current run of attempts
    (BUG-MSO-2026-0657).

    A "run" is the unbroken tail of consecutive ``roleHistory`` entries for
    *role* ending at *role*'s most recent turn — i.e. every requeue/retry of
    the SAME role since that role was last entered. A turn of a DIFFERENT role
    in between (a rejection lap TST -> BLD -> TST, a chart onFail edge) ends
    the run, so the floor resets to the re-entered role's first new turn: a
    report written before the rebuild must not vouch for the work after it.

    Where :func:`latest_started_at` answers "when did THIS attempt start",
    this answers "when did this role start working on this order this time
    round" — the right floor for an ORDER-KEYED artefact, which an earlier
    attempt of the same role legitimately wrote (BUG-MSO-2026-0650: QA report
    APPROVED at 12:14 during TST attempt 1, stalled at 16:25 as "produced
    nothing" because attempt 3's floor was 15:55).

    Falls back to :func:`latest_started_at` whenever ``roleHistory`` carries no
    turn for *role* (legacy orders) — unchanged pre-0657 behaviour.
    """
    history = data.get("roleHistory") or []
    last = None
    for idx in range(len(history) - 1, -1, -1):
        if history[idx].get("role") == role:
            last = idx
            break
    if last is None:
        return latest_started_at(data, role)
    first = last
    while first > 0 and history[first - 1].get("role") == role:
        first -= 1
    return history[first].get("startedAt") or latest_started_at(data, role)


def current_run_turns(data: Dict[str, Any], role: str) -> List[Dict[str, Any]]:
    """The full list of *role*'s ``roleHistory`` entries in its current run
    (BUG-MSO-2026-0609/0657 reconciliation) — the same "unbroken tail of
    consecutive entries for *role*" :func:`run_started_at` walks to find the
    first one, returned here as the whole list, oldest first.

    Lets a caller distinguish "written during an EARLIER TURN's own active
    window" (BUG-0657: a QA/investigation report from a killed earlier
    attempt of this same run must still count) from "written in the IDLE
    GAP between two turns, while no crew was running" (BUG-0609: a report
    dropped between a requeue and the next dispatch must NOT count) — a
    single floor timestamp cannot express that distinction; the per-turn
    window can. Empty when *role* has no entry in ``roleHistory`` at all.
    """
    history = data.get("roleHistory") or []
    last = None
    for idx in range(len(history) - 1, -1, -1):
        if history[idx].get("role") == role:
            last = idx
            break
    if last is None:
        return []
    first = last
    while first > 0 and history[first - 1].get("role") == role:
        first -= 1
    return list(history[first:last + 1])
