# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""maestro/core/plan_links.py — planning voyage <-> build voyage links.

BUG-MSO-2026-0775. A plan is usually approved in its own PLANNING voyage
(one plan-only PLN order) and then cut into one or more separate BUILD
voyages. Nothing recorded that relationship: VOY-MSO-2026-0725 read in the
Hub as "COMPLETE, one plan order, nothing built" while the 14 orders cut from
its plan were shipping in VOY-MSO-2026-0727 and VOY-MSO-2026-0732. The only
trace was a commit message and two free-text descriptions.

The link is first-class and lives on BOTH manifests, using the field names the
LEAD wrote by hand for PLAN-PLN-MSO-2026-0747 on 2026-09-14:

* planning voyage: ``buildVoyages: ["VOY-...", ...]``
* build voyage:    ``planOrder: "PLN-..."`` and ``planVoyage: "VOY-..."``

Build ORDERS cut from a plan carry ``planOrder`` too (already the hand-written
convention on FTR-MSO-2026-0760..0772).

ONE WRITER, ONE READER, like every other shared core:

* :func:`link_build_voyage` is the only writer. It is ADDITIVE ONLY: it sets a
  field that is absent and appends an id that is missing, and never overwrites
  or removes anything. A build voyage that already names a different plan keeps
  it — the second plan's planning voyage still gains the id in its
  ``buildVoyages``. That property is what makes it safe to run against an
  archived (``voyages/complete``) manifest: a link is not a mutation of the
  completion record, it is a missing cross-reference.
* :func:`plan_link_index` is the only reader. It reads BOTH directions, so a
  link written from one side only (a hand edit, or a reverse write that failed)
  still renders on both voyages.

Callers: ``voyage_core.create_voyage`` and ``voyage_core.create_order_on_voyage``
(``mso voyage create --plan-order``, ``mso order create --plan-order`` and the
Hub's two create endpoints), ``review_core.approve_order`` (voyages already cut
before the plan was approved), ``scripts/backfill_plan_links.py``. Readers: the
Hub aggregator, the phase engine and ``mso doctor``'s
``voyages.planned-no-work``.

Contract (the shared-cores contract in CLAUDE.md): explicit ``mso`` path, typed
exceptions (``OrderValidationError`` 400 / ``VoyageNotFound`` 404), no
printing, no git.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

PLAN_ORDER_FIELD = "planOrder"
PLAN_VOYAGE_FIELD = "planVoyage"
BUILD_VOYAGES_FIELD = "buildVoyages"

_ARCHIVE_SUBDIRS = ("orders/complete", "orders/failed")
_VOYAGE_SUBDIRS = ("voyages/active", "voyages/complete")


@dataclass
class PlanLink:
    """What a plan link resolves to, validated before anything is written."""

    plan_order_id: str = ""
    plan_voyage_id: str = ""


@dataclass
class LinkResult:
    """Result of :func:`link_build_voyage`."""

    build_voyage_id: str
    plan_order_id: str = ""
    plan_voyage_id: str = ""
    #: Fields actually added, as ``"<voyage>.<field>"`` — empty when both
    #: manifests already said everything (the call is idempotent).
    added: List[str] = field(default_factory=list)

    @property
    def changed(self) -> bool:
        return bool(self.added)


# ---------------------------------------------------------------------------
# Lookup
# ---------------------------------------------------------------------------

def _load_json(path: Path) -> Optional[Dict[str, Any]]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return data if isinstance(data, dict) else None


def _write_json(path: Path, data: Dict[str, Any]) -> None:
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
    tmp.replace(path)


def find_order(mso: Path, order_id: str) -> Optional[Dict[str, Any]]:
    """*order_id*'s JSON from the queues or the archive, or ``None``.

    A plan order is normally ARCHIVED by the time its build voyages are cut
    (plan approval archives it COMPLETE), so the queue-only
    ``order_create.find_order_file`` is not enough on its own.
    """
    from maestro.core.order_create import find_order_file

    mso = Path(mso)
    for sub in _ARCHIVE_SUBDIRS:
        data = _load_json(mso / sub / f"{order_id}.json")
        if data is not None:
            return data
    path = find_order_file(mso, order_id)
    if path is not None:
        return _load_json(path)
    for sub in _ARCHIVE_SUBDIRS:
        d = mso / sub
        if not d.exists():
            continue
        for jf in d.glob("*.json"):
            data = _load_json(jf)
            if data and (data.get("orderId") or data.get("id")) == order_id:
                return data
    return None


def resolve_plan_link(mso: Path, *, plan_order_id: str = "",
                      plan_voyage_id: str = "") -> Optional[PlanLink]:
    """Validate a requested plan link BEFORE anything is allocated or written.

    Returns ``None`` when no link was asked for. A named plan order that does
    not exist, or a named plan voyage that does not exist, is a caller error
    (``OrderValidationError`` / ``VoyageNotFound``) — raised here so a create
    that names a bad plan writes nothing and burns no id. The plan voyage
    defaults to the plan order's own ``voyageId``; a plan voyage that
    disagrees with it is refused.
    """
    from maestro.core.order_ids import OrderValidationError
    from maestro.core.voyage_core import load_voyage

    plan_order_id = (plan_order_id or "").strip()
    plan_voyage_id = (plan_voyage_id or "").strip()
    if not plan_order_id and not plan_voyage_id:
        return None

    if plan_order_id:
        order = find_order(mso, plan_order_id)
        if order is None:
            raise OrderValidationError(
                f"planOrder '{plan_order_id}' was not found in the queues or "
                "orders/complete|failed")
        order_voyage = str(order.get("voyageId") or "").strip()
        if plan_voyage_id and order_voyage and plan_voyage_id != order_voyage:
            raise OrderValidationError(
                f"planVoyage '{plan_voyage_id}' disagrees with planOrder "
                f"{plan_order_id}'s voyage '{order_voyage}' - omit it and the "
                "plan order's voyage is used")
        plan_voyage_id = plan_voyage_id or order_voyage

    if plan_voyage_id:
        plan_voyage_id = load_voyage(mso, plan_voyage_id).voyage_id
    return PlanLink(plan_order_id=plan_order_id, plan_voyage_id=plan_voyage_id)


# ---------------------------------------------------------------------------
# Writer
# ---------------------------------------------------------------------------

def link_build_voyage(mso: Path, build_voyage_id: str, *,
                      plan_order_id: str = "",
                      plan_voyage_id: str = "") -> LinkResult:
    """Record that *build_voyage_id* was cut from a plan. Additive; idempotent.

    Writes ``planOrder``/``planVoyage`` onto the build voyage when absent and
    appends the build voyage to the planning voyage's ``buildVoyages`` when
    missing. Nothing is overwritten or removed. Linking a voyage to itself (a
    plan whose first wave is cut into its own planning voyage, as
    PLAN-PLN-MSO-2026-0747's Wave A was) records nothing — that voyage's own
    orders already say it.

    Both manifests are loaded before either is written, so a missing voyage
    leaves no half-link. Runs under ``lock_for_allocation`` because the same
    manifests are rewritten by ``voyage_core.attach_order``; callers must not
    already hold that lock.
    """
    from maestro.core.order_ids import lock_for_allocation
    from maestro.core.order_retry import workspace_scope
    from maestro.core.voyage_core import load_voyage

    mso = Path(mso)
    link = resolve_plan_link(mso, plan_order_id=plan_order_id,
                             plan_voyage_id=plan_voyage_id) or PlanLink()

    with workspace_scope(mso):
        with lock_for_allocation(mso):
            build = load_voyage(mso, build_voyage_id)
            result = LinkResult(build_voyage_id=build.voyage_id,
                                plan_order_id=link.plan_order_id,
                                plan_voyage_id=link.plan_voyage_id)
            if not link.plan_order_id and not link.plan_voyage_id:
                return result
            if link.plan_voyage_id == build.voyage_id:
                return result

            plan = (load_voyage(mso, link.plan_voyage_id)
                    if link.plan_voyage_id else None)

            build_data = build.voyage
            for key, value in ((PLAN_ORDER_FIELD, link.plan_order_id),
                               (PLAN_VOYAGE_FIELD, link.plan_voyage_id)):
                if value and not build_data.get(key):
                    build_data[key] = value
                    result.added.append(f"{build.voyage_id}.{key}")
            if result.added:
                _write_json(build.path, build_data)

            if plan is not None:
                plan_data = plan.voyage
                existing = plan_data.get(BUILD_VOYAGES_FIELD)
                ids = [str(v) for v in existing] if isinstance(existing, list) else []
                if build.voyage_id not in ids:
                    ids.append(build.voyage_id)
                    plan_data[BUILD_VOYAGES_FIELD] = ids
                    _write_json(plan.path, plan_data)
                    result.added.append(f"{plan.voyage_id}.{BUILD_VOYAGES_FIELD}")
    return result


def link_voyages_cut_from_plan(mso: Path, plan_order_id: str,
                               plan_voyage_id: str = "") -> List[str]:
    """Link every voyage already holding work cut from *plan_order_id*.

    Called at plan approval. A build voyage cut BEFORE the plan was approved
    (orders filed PROPOSED against it) is found by either signal: a voyage
    whose manifest names ``planOrder``, or a voyage holding an order that names
    ``planOrder`` or lists the plan order in ``dependsOn``. The plan's own
    voyage is excluded. Returns the build voyage ids linked (already-linked
    ones included). Never raises: approval has already happened, and a link
    that cannot be written must not undo it — the caller reports it instead.
    """
    mso = Path(mso)
    plan_order_id = (plan_order_id or "").strip()
    if not plan_order_id:
        return []
    candidates: List[str] = []

    for vid, data in load_voyage_manifests(mso).items():
        if str(data.get(PLAN_ORDER_FIELD) or "") == plan_order_id:
            candidates.append(vid)

    queue_dirs = [p for p in (mso / "queues").glob("*") if p.is_dir()] if (mso / "queues").exists() else []
    for d in queue_dirs + [p for p in (mso / "queues" / "requests").glob("*") if p.is_dir()] \
            + [mso / sub for sub in _ARCHIVE_SUBDIRS]:
        if not d.exists():
            continue
        for jf in d.glob("*.json"):
            data = _load_json(jf)
            if not data:
                continue
            vid = str(data.get("voyageId") or "").strip()
            if not vid:
                continue
            deps = data.get("dependsOn") or []
            if (str(data.get(PLAN_ORDER_FIELD) or "") == plan_order_id
                    or (isinstance(deps, list) and plan_order_id in deps)):
                candidates.append(vid)

    linked: List[str] = []
    for vid in candidates:
        if vid == plan_voyage_id or vid in linked:
            continue
        try:
            link_build_voyage(mso, vid, plan_order_id=plan_order_id,
                              plan_voyage_id=plan_voyage_id)
        except Exception:   # noqa: BLE001 - see docstring: never undo an approval
            continue
        linked.append(vid)
    return linked


# ---------------------------------------------------------------------------
# Reader
# ---------------------------------------------------------------------------

def load_voyage_manifests(mso: Path) -> Dict[str, Dict[str, Any]]:
    """Every voyage manifest in ``voyages/active|complete``, keyed by id."""
    out: Dict[str, Dict[str, Any]] = {}
    for sub in _VOYAGE_SUBDIRS:
        d = Path(mso) / sub
        if not d.exists():
            continue
        for jf in sorted(d.glob("*.json")):
            data = _load_json(jf)
            if not data:
                continue
            vid = str(data.get("id") or data.get("voyageId") or jf.stem)
            out.setdefault(vid, data)
    return out


def _id_list(value: Any) -> List[str]:
    if not isinstance(value, list):
        return []
    return [str(v).strip() for v in value if isinstance(v, str) and v.strip()]


def plan_link_index(voyages: Dict[str, Dict[str, Any]]) -> Dict[str, List[str]]:
    """``{planning voyage id: [build voyage ids]}``, read from BOTH directions.

    A planning voyage's build voyages are its own ``buildVoyages`` list plus
    every voyage whose ``planVoyage`` names it, in that order, de-duplicated. A
    self-reference is dropped. Planning voyages with no build voyages are
    absent from the result.
    """
    index: Dict[str, List[str]] = {}

    def _add(plan_id: str, build_id: str) -> None:
        if not plan_id or not build_id or plan_id == build_id:
            return
        ids = index.setdefault(plan_id, [])
        if build_id not in ids:
            ids.append(build_id)

    for vid, data in voyages.items():
        for bid in _id_list(data.get(BUILD_VOYAGES_FIELD)):
            _add(vid, bid)
    for vid, data in voyages.items():
        _add(str(data.get(PLAN_VOYAGE_FIELD) or "").strip(), vid)
    return index


def plan_voyage_of(voyage_id: str, voyages: Dict[str, Dict[str, Any]],
                   index: Optional[Dict[str, List[str]]] = None) -> str:
    """The planning voyage *voyage_id* was cut from, or "" — both directions."""
    data = voyages.get(voyage_id) or {}
    own = str(data.get(PLAN_VOYAGE_FIELD) or "").strip()
    if own and own != voyage_id:
        return own
    for plan_id, build_ids in (index if index is not None
                               else plan_link_index(voyages)).items():
        if voyage_id in build_ids:
            return plan_id
    return ""


def build_voyages_for(mso: Path, voyage_id: str) -> List[str]:
    """Convenience: the build voyages linked to *voyage_id* in workspace *mso*."""
    return list(plan_link_index(load_voyage_manifests(mso)).get(voyage_id, []))


def build_voyage_phases(build_ids: Iterable[str],
                        phase_of: Dict[str, str]) -> List[Tuple[str, str]]:
    """Pair each build voyage id with its derived phase, dropping unknown ids.

    A build voyage the reader cannot see (deleted, or filtered out) says
    nothing about whether the plan was built, so it is left out of the phase
    decision rather than counted as open forever.
    """
    return [(bid, phase_of[bid]) for bid in build_ids if bid in phase_of]
