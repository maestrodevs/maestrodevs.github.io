# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""The voyage PR body — FTR-MSO-2026-0502.

**One implementation for every call site.** ``fleet_runner`` used to build the
voyage PR body in three places (the provider path, the crew-completion GitHub
path and the post-voyage GitHub path), each emitting the same two empty
checkboxes and none of the evidence the fleet had already written. Every
surface now calls :func:`render_voyage_pr_body` — the BUG-MSO-2026-0426
one-implementation-per-decision principle.

**What goes in.** Nothing is re-parsed here. Per order, the context is composed
from :mod:`maestro.reports` — the same QA / acceptance-criteria / SEC readers
the Hub uses — so the PR body and the Hub can never disagree about whether an
order passed:

* acceptance criteria with a per-criterion result (``order.acResults`` joined
  with the QA report's own AC table, conflicts kept visible);
* test counts from the QA report's ``## Test Summary``, plus the
  "new failures introduced" figure;
* every SEC document for the order, with its verdict and per-severity finding
  counts.

**Honesty rule.** A missing QA report (or a missing SEC report on an order whose
``roleSequence`` includes SEC) is rendered as missing, never omitted — omission
reads as "nothing to report". Anything that makes a voyage unsafe to merge is
hoisted into :data:`blocking` and computed over EVERY order, including orders
the order cap kept out of the per-order section.

**Template resolution** (highest authority first, first CONFIGURED tier wins)::

    signed policy bundle (prBody.template)
      > division pack (pack.json prBodyTemplate)
        > workspace (completion.voyagePr.bodyTemplate, else config/pr-body.md.j2)
          > shipped default (maestro/templates/pr-body.md.j2)

A governed (bundle) template is AUTHORITATIVE: a workspace or pack template
cannot override it — the point of a governed template is that a team cannot
quietly drop the security section. See ``maestro/docs/PR-BODY-TEMPLATES.md``.

**Fail-safe.** A configured template that is missing, unreadable, malformed,
raises at render time, or renders an empty body falls back to the SHIPPED
DEFAULT — never to a lower tier (breaking a governed template must not hand
control to a local one) — emits ``PR_BODY_TEMPLATE_FAILED``, and the rendered
body says so at its top. If the shipped default itself cannot render, a plain
Python body carrying the blocking/gap summary is returned. This module never
raises to its caller: PR creation must not fail because a template did.

**Size.** GitHub rejects PR bodies over 65536 characters, and the GitHub path
passes the body on the command line (Windows caps a command line at 32767), so
the default budget is 30000 characters (``completion.voyagePr.bodyMaxChars``,
clamped to 65000). Over budget, the body is first re-rendered with
``compact=True``; if still over, it is cut at a line boundary with a visible
note. Both emit ``PR_BODY_TRUNCATED``.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Tuple

#: Bumped only on a breaking change to the template variable contract.
CONTEXT_SCHEMA_VERSION = 1

TIER_BUNDLE = "bundle"
TIER_PACK = "pack"
TIER_WORKSPACE = "workspace"
TIER_DEFAULT = "default"
#: Resolution order, highest authority first.
TIER_ORDER = (TIER_BUNDLE, TIER_PACK, TIER_WORKSPACE, TIER_DEFAULT)

DEFAULT_TEMPLATE_NAME = "pr-body.md.j2"
#: Shown in the body instead of an absolute site-packages path.
DEFAULT_TEMPLATE_SOURCE = f"maestro/templates/{DEFAULT_TEMPLATE_NAME}"
#: Conventional workspace template, relative to the artefact root.
WORKSPACE_TEMPLATE_REL = "config/pr-body.md.j2"

DEFAULT_ORDER_CAP = 20
DEFAULT_BODY_MAX_CHARS = 30000
#: GitHub's hard PR-body limit, for reference.
GITHUB_BODY_HARD_LIMIT = 65536
BODY_MAX_CHARS_CEILING = 65000
BODY_MAX_CHARS_FLOOR = 2000
MAX_TEMPLATE_BYTES = 256 * 1024

EVENT_TEMPLATE_FAILED = "PR_BODY_TEMPLATE_FAILED"
EVENT_TRUNCATED = "PR_BODY_TRUNCATED"

#: Role codes (canonical + legacy nautical alias) that produce the evidence.
QA_ROLES = frozenset({"TST", "BOS"})
SEC_ROLES = frozenset({"SEC", "LKT"})

SEVERITIES = ("CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO")
UNSPECIFIED_SEVERITY = "UNSPECIFIED"

#: QA / SEC verdicts that block a merge.
BLOCKING_VERDICTS = ("REJECTED", "BLOCKED")

_CRITERION_SHORT_CHARS = 140
#: Bundle tiers in authority order (maestro/governance/loader.py docstring).
_BUNDLE_AUTHORITY = {"org": 0, "workspace": 1, "user": 2}

EventSink = Callable[[str, str], None]


class TemplateSourceError(Exception):
    """A configured template could not be read (missing, too large, undecodable,
    outside its pack)."""


# ---------------------------------------------------------------------------
# Jinja filters — part of the documented contract
# ---------------------------------------------------------------------------

def md_cell(value: Any) -> str:
    """Make *value* safe inside one markdown table cell / one quoted line:
    newlines collapse to spaces, ``|`` is escaped, ``None`` renders empty."""
    if value is None:
        return ""
    text = str(value).replace("\r", " ").replace("\n", " ")
    text = " ".join(text.split())
    return text.replace("|", "\\|")


def truncate_text(value: Any, length: int = 140) -> str:
    """Cut *value* to at most *length* characters, ending with ``...`` when cut."""
    text = "" if value is None else str(value)
    try:
        length = max(4, int(length))
    except (TypeError, ValueError):
        length = 140
    if len(text) <= length:
        return text
    return text[: length - 3].rstrip() + "..."


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

@dataclass
class PrBodyConfig:
    """``completion.voyagePr`` keys this module reads from ``workspace.json``."""

    body_template: str = ""
    order_cap: int = DEFAULT_ORDER_CAP
    body_max_chars: int = DEFAULT_BODY_MAX_CHARS
    report_link_base: str = ""
    notes: List[str] = field(default_factory=list)


def _positive_int(raw: Any, default: int, key: str, notes: List[str]) -> int:
    if raw is None:
        return default
    if isinstance(raw, bool) or not isinstance(raw, int) or raw <= 0:
        notes.append(f"completion.voyagePr.{key}={raw!r} is not a positive integer; "
                     f"using {default}")
        return default
    return raw


def load_pr_body_config(mso: Optional[Path]) -> PrBodyConfig:
    """Read the PR-body keys from ``<mso>/config/workspace.json``. Never raises."""
    cfg = PrBodyConfig()
    if mso is None:
        return cfg
    path = Path(mso) / "config" / "workspace.json"
    try:
        data = json.loads(path.read_text(encoding="utf-8")) if path.is_file() else {}
    except (OSError, ValueError) as exc:
        cfg.notes.append(f"workspace.json unreadable ({type(exc).__name__}); PR-body defaults used")
        return cfg
    completion = data.get("completion") if isinstance(data, dict) else None
    block = completion.get("voyagePr") if isinstance(completion, dict) else None
    if not isinstance(block, dict):
        return cfg
    template = block.get("bodyTemplate")
    if isinstance(template, str):
        cfg.body_template = template.strip()
    cfg.order_cap = _positive_int(block.get("bodyOrderCap"), DEFAULT_ORDER_CAP,
                                  "bodyOrderCap", cfg.notes)
    limit = _positive_int(block.get("bodyMaxChars"), DEFAULT_BODY_MAX_CHARS,
                          "bodyMaxChars", cfg.notes)
    clamped = min(max(limit, BODY_MAX_CHARS_FLOOR), BODY_MAX_CHARS_CEILING)
    if clamped != limit:
        cfg.notes.append(f"completion.voyagePr.bodyMaxChars={limit} clamped to {clamped}")
    cfg.body_max_chars = clamped
    base = block.get("reportLinkBase")
    if isinstance(base, str):
        cfg.report_link_base = base.strip()
    return cfg


# ---------------------------------------------------------------------------
# Order membership
# ---------------------------------------------------------------------------

def _strip_ref(branch: Any) -> str:
    return str(branch or "").replace("refs/heads/", "").strip()


def normalise_order_refs(refs: Iterable[Any]) -> List[Tuple[str, str]]:
    """``[(order_id, title)]``, de-duplicated, first occurrence wins.

    Accepts the dispatcher's ``"ID: title"`` strings, bare ids, and manifest
    dicts (``orderId`` / ``id`` + ``title``). A repeat contributes its title
    only if the first occurrence had none. This is the fix for PR #334 listing
    INV-MSO-2026-0472 twice: the dispatcher records an order once per role it
    dispatches.
    """
    out: List[Tuple[str, str]] = []
    index: Dict[str, int] = {}
    for ref in refs or []:
        if isinstance(ref, dict):
            oid = str(ref.get("orderId") or ref.get("id") or "").strip()
            title = str(ref.get("title") or "").strip()
        elif isinstance(ref, str):
            head, _, tail = ref.partition(":")
            oid, title = head.strip(), tail.strip()
        else:
            continue
        if not oid:
            continue
        if oid in index:
            pos = index[oid]
            if title and not out[pos][1]:
                out[pos] = (oid, title)
            continue
        index[oid] = len(out)
        out.append((oid, title))
    return out


def _load_json(path: Path) -> Optional[Dict[str, Any]]:
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return data if isinstance(data, dict) else None


def find_voyage_for_branch(mso: Optional[Path], branch: str) -> Optional[Dict[str, Any]]:
    """The voyage manifest whose ``branch`` / ``voyageBranch`` is *branch*
    (active voyages first), or ``None``. Never raises."""
    wanted = _strip_ref(branch)
    if mso is None or not wanted:
        return None
    try:
        from maestro.reports.voyage_reader import iter_voyage_manifests
        manifests = iter_voyage_manifests(Path(mso))
    except Exception:
        return None
    for _location, path in manifests:
        data = _load_json(path)
        if not data:
            continue
        if _strip_ref(data.get("branch") or data.get("voyageBranch")) == wanted:
            return data
    return None


def _manifest_refs(manifest: Optional[Dict[str, Any]]) -> List[Any]:
    if not manifest:
        return []
    refs: List[Any] = []
    for item in manifest.get("orders") or []:
        if isinstance(item, (str, dict)):
            refs.append(item)
    return refs


# ---------------------------------------------------------------------------
# Per-order record
# ---------------------------------------------------------------------------

def _issue(kind: str, order_id: str, message: str, report_path: Optional[str] = None
           ) -> Dict[str, Any]:
    return {"kind": kind, "order_id": order_id, "message": message,
            "report_path": report_path}


def _empty_record(order_id: str, title: str) -> Dict[str, Any]:
    return {
        "id": order_id,
        "title": title,
        "type": "",
        "status": "",
        "found": False,
        "role_sequence": [],
        "qa": {
            "expected": False, "present": False, "verdict": None, "raw_verdict": "",
            "decided": False, "blocking_defects": 0, "report_path": None,
            "report_url": None, "missing_reason": None,
        },
        "acceptance": {
            "has_criteria": False, "total": 0, "met": 0, "failed": 0, "partial": 0,
            "skipped": 0, "not_recorded": 0, "undetermined": 0, "conflicted": 0,
            "bucket": None, "rows": [], "failed_ids": [], "conflict_ids": [],
        },
        "tests": {
            "recorded": False, "total": None, "passed": None, "failed": None,
            "new_failures": None, "categories": [],
        },
        "security": {
            "required": False, "present": False, "verdict": None, "raw_verdict": "",
            "decided": False, "report_path": None, "report_url": None,
            "counts": {s: 0 for s in SEVERITIES + (UNSPECIFIED_SEVERITY,)},
            "findings_total": 0, "blocked": False, "critical_high": False,
            "disagreement": False, "reports": [], "missing_reason": None,
        },
        "blocking_issues": [],
        "gaps": [],
        "notes": [],
    }


def _link(cfg: PrBodyConfig, rel: Optional[str]) -> Optional[str]:
    if not rel or not cfg.report_link_base:
        return None
    return cfg.report_link_base.rstrip("/") + "/" + str(rel).lstrip("/")


def _role_sequence(data: Optional[Dict[str, Any]]) -> List[str]:
    if not data:
        return []
    roles = data.get("roleSequence")
    if not isinstance(roles, list):
        return []
    return [str(r).strip().upper() for r in roles if isinstance(r, str) and r.strip()]


def _new_failures(mso: Path, report_rel: str) -> Optional[int]:
    if not report_rel:
        return None
    try:
        from maestro.reports import qa_reader
        path = Path(mso) / report_rel
        limit = int(getattr(qa_reader, "MAX_ARTEFACT_BYTES", 512 * 1024))
        with open(path, "rb") as handle:
            raw = handle.read(limit)
        return qa_reader.parse_new_failures(raw.decode("utf-8", errors="replace"))
    except Exception:
        return None


_ICON_STATUSES = ("PASS", "FAIL", "PARTIAL", "SKIP", "NOT RECORDED", "UNDETERMINED", "CONFLICT")


def _fill_record(rec: Dict[str, Any], mso: Path, manifest: Optional[Dict[str, Any]],
                 cfg: PrBodyConfig) -> None:
    from maestro.hub.artefacts import find_order_file
    from maestro.reports import security_reader, voyage_reader

    order_id = rec["id"]
    entry, qa_summary, ac_rollup = voyage_reader.compose_order_entry(mso, order_id, manifest)
    data: Optional[Dict[str, Any]] = None
    try:
        path = find_order_file(mso, order_id)
    except Exception:
        path = None
    if path is not None:
        data = _load_json(path)

    rec["found"] = bool(entry.found)
    rec["title"] = entry.title or rec["title"]
    rec["type"] = entry.order_type
    rec["status"] = entry.status
    roles = _role_sequence(data)
    rec["role_sequence"] = roles

    # -- QA ------------------------------------------------------------------
    qa = rec["qa"]
    qa["expected"] = bool(QA_ROLES.intersection(roles))
    qa["present"] = bool(entry.qa_report_present)
    tests = rec["tests"]
    if qa_summary is not None:
        qa["verdict"] = qa_summary.verdict
        qa["raw_verdict"] = qa_summary.raw_verdict or ""
        qa["decided"] = bool(qa_summary.decided)
        qa["blocking_defects"] = int(entry.qa_blocking_defects or 0)
        qa["report_path"] = qa_summary.report_rel or None
        qa["report_url"] = _link(cfg, qa_summary.report_rel)
        counts = qa_summary.test_counts
        tests["recorded"] = bool(counts.recorded)
        tests["total"] = counts.tests
        tests["passed"] = counts.passed
        tests["failed"] = counts.failed
        tests["categories"] = [
            {"name": c.name, "tests": c.tests, "passed": c.passed, "failed": c.failed}
            for c in counts.categories
        ]
        tests["new_failures"] = _new_failures(mso, qa_summary.report_rel)
    elif qa["present"]:
        qa["verdict"] = "UNDETERMINED"
        rec["notes"].append("A QA report exists but could not be summarised.")

    # -- Acceptance criteria ---------------------------------------------------
    ac = rec["acceptance"]
    ac["has_criteria"] = bool(data and data.get("acceptanceCriteria"))
    if ac_rollup is not None:
        ac["has_criteria"] = bool(ac_rollup.has_criteria) or ac["has_criteria"]
        rows = []
        for n, row in enumerate(ac_rollup.rows, start=1):
            status = row.status if row.status in _ICON_STATUSES else "UNDETERMINED"
            rows.append({
                "id": row.id or f"#{n}",
                "criterion": row.criterion or "",
                "criterion_short": truncate_text(row.criterion or "", _CRITERION_SHORT_CHARS),
                "status": status,
                "provenance": row.provenance or "",
            })
        ac["rows"] = rows
        ac["total"] = len(rows)
        tally = {s: sum(1 for r in rows if r["status"] == s) for s in _ICON_STATUSES}
        ac["met"] = tally["PASS"]
        ac["failed"] = tally["FAIL"]
        ac["partial"] = tally["PARTIAL"]
        ac["skipped"] = tally["SKIP"]
        ac["not_recorded"] = tally["NOT RECORDED"]
        ac["undetermined"] = tally["UNDETERMINED"]
        ac["conflicted"] = tally["CONFLICT"]
        ac["bucket"] = ac_rollup.coverage_bucket
        ac["failed_ids"] = [r["id"] for r in rows if r["status"] == "FAIL"]
        ac["conflict_ids"] = [r["id"] for r in rows if r["status"] == "CONFLICT"]

    # -- Security --------------------------------------------------------------
    sec = rec["security"]
    sec["required"] = bool(SEC_ROLES.intersection(roles))
    try:
        reports = security_reader.read_security_reports(mso, order_id)
    except Exception:
        reports = []
    for s in reports:
        counts = {k: 0 for k in SEVERITIES + (UNSPECIFIED_SEVERITY,)}
        for finding in s.findings:
            sev = str(getattr(finding, "severity", "") or "").upper()
            counts[sev if sev in counts else UNSPECIFIED_SEVERITY] += 1
        sec["reports"].append({
            "name": s.report_name,
            "variant": s.variant,
            "verdict": s.verdict,
            "raw_verdict": s.raw_verdict or "",
            "decided": bool(s.decided),
            "report_path": s.report_rel or None,
            "report_url": _link(cfg, s.report_rel),
            "counts": counts,
            "findings_total": len(s.findings),
            "blocked": s.verdict in BLOCKING_VERDICTS,
            "critical_high": (counts["CRITICAL"] + counts["HIGH"]) > 0,
        })
    if sec["reports"]:
        primary = sec["reports"][0]
        sec["present"] = True
        for key in ("verdict", "raw_verdict", "decided", "report_path", "report_url",
                    "findings_total"):
            sec[key] = primary[key]
        sec["counts"] = dict(primary["counts"])
        sec["blocked"] = any(r["blocked"] for r in sec["reports"])
        sec["critical_high"] = any(r["critical_high"] for r in sec["reports"])
        sec["disagreement"] = len({r["verdict"] for r in sec["reports"]}) > 1


def _classify(rec: Dict[str, Any], reports_readable: bool) -> None:
    """Fill ``missing_reason``s, ``blocking_issues`` and ``gaps``."""
    oid = rec["id"]
    status = rec["status"] or "unknown"
    complete = status.upper() == "COMPLETE"
    qa, ac, tests, sec = rec["qa"], rec["acceptance"], rec["tests"], rec["security"]
    blocking, gaps = rec["blocking_issues"], rec["gaps"]

    if not reports_readable:
        qa["missing_reason"] = "reports could not be read (artefact root unresolved)"
        gaps.append(_issue("reports_unreadable", oid, qa["missing_reason"]))
        if sec["required"]:
            sec["missing_reason"] = qa["missing_reason"]
        return

    if not qa["present"]:
        if not rec["found"]:
            qa["missing_reason"] = ("no QA report - the order record was not found on the "
                                    "artefact plane")
        elif not qa["expected"] and rec["role_sequence"]:
            qa["missing_reason"] = "no QA report - roleSequence has no TST role"
        elif complete:
            qa["missing_reason"] = "no QA report - order is COMPLETE but no QA report exists"
        else:
            qa["missing_reason"] = f"no QA report - did not reach TST (order status {status})"
        if qa["expected"] or not rec["role_sequence"]:
            gaps.append(_issue("missing_qa", oid, qa["missing_reason"]))
    elif not qa["decided"]:
        gaps.append(_issue("qa_undetermined", oid,
                           "QA report present but its verdict could not be read",
                           qa["report_path"]))

    if sec["required"] and not sec["present"]:
        if complete:
            sec["missing_reason"] = ("no SEC report - roleSequence includes SEC but no SEC "
                                     "artefact exists (SEC_ARTEFACT_MISSING)")
        else:
            sec["missing_reason"] = ("no SEC report - roleSequence includes SEC; SEC has not "
                                     f"produced one yet (order status {status})")
        gaps.append(_issue("missing_sec", oid, sec["missing_reason"]))
    elif sec["present"] and not sec["decided"]:
        gaps.append(_issue("sec_undetermined", oid,
                           "SEC report present but its verdict could not be read",
                           sec["report_path"]))

    if ac["failed"]:
        blocking.append(_issue(
            "ac_failed", oid,
            f"{ac['failed']} acceptance criteria FAILED ({', '.join(ac['failed_ids'])})",
            qa["report_path"]))
    if ac["conflicted"]:
        blocking.append(_issue(
            "ac_conflict", oid,
            f"{ac['conflicted']} acceptance criteria have CONFLICTING results between the "
            f"order and the QA report ({', '.join(ac['conflict_ids'])})",
            qa["report_path"]))
    if qa["present"] and qa["verdict"] in BLOCKING_VERDICTS:
        blocking.append(_issue("qa_rejected", oid, f"QA verdict {qa['verdict']}",
                               qa["report_path"]))
    if qa["blocking_defects"]:
        blocking.append(_issue("qa_blocking_defects", oid,
                               f"QA report lists {qa['blocking_defects']} blocking defect(s)",
                               qa["report_path"]))
    if tests["new_failures"]:
        blocking.append(_issue("new_failures", oid,
                               f"QA report records {tests['new_failures']} new test failure(s) "
                               "introduced by this order", qa["report_path"]))
    for report in sec["reports"]:
        if report["blocked"]:
            blocking.append(_issue("sec_blocked", oid,
                                   f"SEC verdict {report['verdict']} ({report['name']})",
                                   report["report_path"]))
        if report["critical_high"]:
            blocking.append(_issue(
                "sec_critical_high", oid,
                f"{report['counts']['CRITICAL']} CRITICAL / {report['counts']['HIGH']} HIGH "
                f"finding(s) reported ({report['name']})",
                report["report_path"]))


def build_order_record(mso: Optional[Path], order_id: str, title: str = "",
                       manifest: Optional[Dict[str, Any]] = None,
                       config: Optional[PrBodyConfig] = None) -> Dict[str, Any]:
    """One order's template record (see the contract doc). Never raises."""
    cfg = config or PrBodyConfig()
    rec = _empty_record(order_id, title)
    readable = mso is not None
    if readable:
        try:
            _fill_record(rec, Path(mso), manifest, cfg)
        except Exception as exc:
            rec["notes"].append(f"reader error: {type(exc).__name__}: {exc}")
            rec["gaps"].append(_issue("reader_error", order_id,
                                      f"evidence could not be read ({type(exc).__name__})"))
    _classify(rec, readable)
    return rec


# ---------------------------------------------------------------------------
# Context
# ---------------------------------------------------------------------------

_BLOCKING_FLAG_KINDS = {
    "any_ac_failed": "ac_failed",
    "any_ac_conflict": "ac_conflict",
    "any_qa_rejected": "qa_rejected",
    "any_qa_blocking_defects": "qa_blocking_defects",
    "any_new_failures": "new_failures",
    "any_sec_blocked": "sec_blocked",
    "any_critical_high": "sec_critical_high",
}


def build_pr_body_context(mso: Optional[Path], *, branch: str,
                          order_refs: Sequence[Any] = (),
                          commits_ahead: Optional[int] = None,
                          config: Optional[PrBodyConfig] = None) -> Dict[str, Any]:
    """The full template context (``template`` is filled by the renderer).

    Membership is the voyage manifest's ``orders`` (when a manifest names this
    branch) followed by *order_refs* (the dispatcher's session list),
    de-duplicated. Never raises for a bad order — each record degrades on its own.
    """
    cfg = config or load_pr_body_config(mso)
    branch_ref = _strip_ref(branch)
    manifest = find_voyage_for_branch(mso, branch_ref)
    refs = normalise_order_refs(_manifest_refs(manifest) + list(order_refs or []))
    records = [build_order_record(mso, oid, title, manifest, cfg) for oid, title in refs]

    cap = max(1, int(cfg.order_cap or DEFAULT_ORDER_CAP))
    if len(records) > cap:
        # Keep the orders a reviewer most needs to see: blocking first, then gaps.
        ranked = sorted(range(len(records)),
                        key=lambda i: (0 if records[i]["blocking_issues"]
                                       else 1 if records[i]["gaps"] else 2, i))
        keep = set(ranked[:cap])
    else:
        keep = set(range(len(records)))
    rendered = [r for i, r in enumerate(records) if i in keep]
    omitted_ids = [r["id"] for i, r in enumerate(records) if i not in keep]

    blocking = [issue for r in records for issue in r["blocking_issues"]]
    gaps = [issue for r in records for issue in r["gaps"]]
    kinds = {issue["kind"] for issue in blocking}
    missing_qa = [r["id"] for r in records if any(g["kind"] == "missing_qa" for g in r["gaps"])]
    missing_sec = [r["id"] for r in records if any(g["kind"] == "missing_sec" for g in r["gaps"])]

    flags = {name: kind in kinds for name, kind in _BLOCKING_FLAG_KINDS.items()}
    flags.update({
        "any_missing_qa": bool(missing_qa),
        "any_missing_sec": bool(missing_sec),
        "any_blocking": bool(blocking),
        "any_gaps": bool(gaps),
        "attention_required": bool(blocking or gaps),
    })

    def _sum(section: str, key: str) -> Optional[int]:
        values = [r[section][key] for r in records if r[section][key] is not None]
        return sum(values) if values else None

    voyage = {
        "id": "", "title": "", "status": "", "branch": branch_ref,
        "commits_ahead": commits_ahead, "manifest_found": manifest is not None,
    }
    if manifest:
        voyage["id"] = str(manifest.get("voyageId") or manifest.get("id") or "")
        voyage["title"] = str(manifest.get("title") or "")
        voyage["status"] = str(manifest.get("status") or "")

    return {
        "schema_version": CONTEXT_SCHEMA_VERSION,
        "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "voyage": voyage,
        "orders": rendered,
        "all_orders": [
            {"id": r["id"], "title": r["title"], "status": r["status"],
             "rendered": i in keep, "blocking": bool(r["blocking_issues"]),
             "gaps": bool(r["gaps"])}
            for i, r in enumerate(records)
        ],
        "order_count": len(records),
        "orders_rendered": len(rendered),
        "orders_omitted": len(omitted_ids),
        "omitted_order_ids": omitted_ids,
        "flags": flags,
        "blocking": blocking,
        "gaps": gaps,
        "missing_qa": missing_qa,
        "missing_sec": missing_sec,
        "totals": {
            "ac_total": _sum("acceptance", "total"),
            "ac_met": _sum("acceptance", "met"),
            "ac_failed": _sum("acceptance", "failed"),
            "ac_not_recorded": _sum("acceptance", "not_recorded"),
            "tests_total": _sum("tests", "total"),
            "tests_failed": _sum("tests", "failed"),
            "new_failures": _sum("tests", "new_failures"),
            "sec_reports": sum(len(r["security"]["reports"]) for r in records),
        },
        "compact": False,
        "limits": {"order_cap": cap, "body_max_chars": cfg.body_max_chars},
        "template": {"tier": TIER_DEFAULT, "source": DEFAULT_TEMPLATE_SOURCE,
                     "shadowed": [], "failure": None},
        "notes": list(cfg.notes),
    }


# ---------------------------------------------------------------------------
# Template resolution
# ---------------------------------------------------------------------------

@dataclass
class ResolvedTemplate:
    """The template tier that won. ``error`` set means it was configured but
    could not be loaded — the renderer falls back to the shipped default."""

    tier: str
    source: str
    text: Optional[str] = None
    error: Optional[str] = None
    shadowed: List[str] = field(default_factory=list)


def default_template_path() -> Path:
    return Path(__file__).resolve().parent.parent / "templates" / DEFAULT_TEMPLATE_NAME


def _read_template_file(path: Path, root: Optional[Path] = None) -> str:
    path = Path(path)
    if root is not None:
        try:
            path.resolve().relative_to(Path(root).resolve())
        except ValueError:
            raise TemplateSourceError(f"template path escapes its pack directory: {path}")
    if not path.is_file():
        raise TemplateSourceError(f"template file not found: {path}")
    size = path.stat().st_size
    if size > MAX_TEMPLATE_BYTES:
        raise TemplateSourceError(f"template file is {size} bytes (limit {MAX_TEMPLATE_BYTES})")
    try:
        return path.read_bytes().decode("utf-8")
    except UnicodeDecodeError as exc:
        raise TemplateSourceError(f"template file is not UTF-8: {exc}")


def _probe_bundle(mso: Optional[Path], workspace: Optional[Path],
                  cfg: PrBodyConfig) -> Optional[ResolvedTemplate]:
    if workspace is None:
        return None
    from maestro.governance.loader import load_bundles

    bundles = load_bundles(workspace)
    ranked = sorted(bundles, key=lambda b: _BUNDLE_AUTHORITY.get(b.tier, 99))
    for bundle in ranked:
        block = getattr(bundle, "pr_body", None) or {}
        if not block:
            continue
        source = f"policy bundle '{bundle.bundle_id}' ({bundle.tier} tier) prBody.template"
        template = block.get("template") if isinstance(block, dict) else None
        if not isinstance(template, str) or not template.strip():
            return ResolvedTemplate(TIER_BUNDLE, source,
                                    error="prBody.template must be a non-empty string")
        if len(template.encode("utf-8")) > MAX_TEMPLATE_BYTES:
            return ResolvedTemplate(TIER_BUNDLE, source,
                                    error=f"prBody.template exceeds {MAX_TEMPLATE_BYTES} bytes")
        return ResolvedTemplate(TIER_BUNDLE, source, text=template)
    return None


def _probe_pack(mso: Optional[Path], workspace: Optional[Path],
                cfg: PrBodyConfig) -> Optional[ResolvedTemplate]:
    if workspace is None:
        return None
    from maestro import auth

    # Same gate as every other pack-carried operational config (lead/bands.py):
    # a community install never even resolves the enrolment profile.
    if not auth.has_tier({"pro", "team", "enterprise"}):
        return None
    from maestro.packs import load_builtin, resolve_profile_pack_pin

    pin = resolve_profile_pack_pin(workspace)
    if not pin or not pin.get("id"):
        return None
    pack = load_builtin(pin["id"])
    rel = getattr(pack, "pr_body_template", None)
    if not rel:
        return None
    source = f"division pack '{pack.id}' prBodyTemplate ({rel})"
    try:
        text = _read_template_file(pack.root / rel, root=pack.root)
    except TemplateSourceError as exc:
        return ResolvedTemplate(TIER_PACK, source, error=str(exc))
    return ResolvedTemplate(TIER_PACK, source, text=text)


def _probe_workspace(mso: Optional[Path], workspace: Optional[Path],
                     cfg: PrBodyConfig) -> Optional[ResolvedTemplate]:
    if mso is None:
        return None
    root = Path(mso)
    if cfg.body_template:
        configured = Path(cfg.body_template)
        path = configured if configured.is_absolute() else root / configured
        source = f"workspace.json completion.voyagePr.bodyTemplate ({cfg.body_template})"
    else:
        path = root / WORKSPACE_TEMPLATE_REL
        if not path.is_file():
            return None
        source = f"workspace {WORKSPACE_TEMPLATE_REL}"
    try:
        text = _read_template_file(path)
    except TemplateSourceError as exc:
        return ResolvedTemplate(TIER_WORKSPACE, source, error=str(exc))
    return ResolvedTemplate(TIER_WORKSPACE, source, text=text)


_PROBES = ((TIER_BUNDLE, _probe_bundle), (TIER_PACK, _probe_pack),
           (TIER_WORKSPACE, _probe_workspace))


def resolve_pr_body_template(mso: Optional[Path],
                             config: Optional[PrBodyConfig] = None) -> ResolvedTemplate:
    """The winning template tier (bundle > pack > workspace > default). Never raises.

    The FIRST configured tier wins even if it fails to load — the renderer then
    uses the shipped default, never a lower tier. A tier whose discovery itself
    raises (e.g. a policy bundle that fails verification) counts as a failed
    tier for the same reason: it may be hiding a governed template.
    Lower tiers that are also configured are recorded on ``shadowed``.
    """
    cfg = config or load_pr_body_config(mso)
    workspace = Path(mso).parent if mso is not None else None
    winner: Optional[ResolvedTemplate] = None
    for tier, probe in _PROBES:
        try:
            found = probe(mso, workspace, cfg)
        except Exception as exc:
            if winner is not None:
                continue
            found = ResolvedTemplate(
                tier, f"{tier} tier",
                error=f"{tier} tier could not be evaluated: {type(exc).__name__}: {exc}")
        if found is None:
            continue
        if winner is None:
            winner = found
        else:
            winner.shadowed.append(f"{found.tier}: {found.source}")
    if winner is not None:
        return winner
    try:
        return ResolvedTemplate(TIER_DEFAULT, DEFAULT_TEMPLATE_SOURCE,
                                text=_read_template_file(default_template_path()))
    except Exception as exc:
        return ResolvedTemplate(TIER_DEFAULT, DEFAULT_TEMPLATE_SOURCE,
                                error=f"{type(exc).__name__}: {exc}")


# ---------------------------------------------------------------------------
# Rendering
# ---------------------------------------------------------------------------

_BLANK_RUN = re.compile(r"\n[ \t]*\n(?:[ \t]*\n)+")


def _environment():
    from jinja2 import StrictUndefined
    from jinja2.sandbox import ImmutableSandboxedEnvironment

    # Sandboxed: a workspace or pack template is data, not code. StrictUndefined:
    # a typo'd variable must FAIL (and fall back) rather than silently render
    # empty — a quiet blank where the security verdict should be is exactly the
    # failure this feature exists to prevent.
    env = ImmutableSandboxedEnvironment(undefined=StrictUndefined, autoescape=False,
                                        trim_blocks=True, lstrip_blocks=True)
    env.filters["md_cell"] = md_cell
    env.filters["truncate_text"] = truncate_text
    return env


def render_template_text(text: str, context: Dict[str, Any]) -> str:
    """Render *text* with *context*. Raises on any template error."""
    out = _environment().from_string(text).render(**context)
    return _BLANK_RUN.sub("\n\n", out).strip() + "\n"


def _emit(sink: Optional[EventSink], event_type: str, message: str) -> None:
    if sink is None:
        return
    try:
        sink(event_type, message)
    except Exception:
        pass


def _one_line(text: Any, limit: int = 300) -> str:
    return truncate_text(" ".join(str(text).split()), limit)


def minimal_body(context: Optional[Dict[str, Any]], branch: str,
                 order_refs: Sequence[Any] = (), commits_ahead: Optional[int] = None,
                 error: str = "") -> str:
    """Last-resort body, no template engine. Still carries the blocking/gap summary."""
    lines: List[str] = []
    if error:
        lines += ["> [!WARNING]",
                  f"> **Maestro could not render this PR body from any template** ({md_cell(error)}). "
                  "This is the minimal fallback - read the QA and SEC reports directly.", ""]
    if context:
        if context.get("blocking"):
            lines += ["> [!CAUTION]",
                      f"> **Not safe to merge - {len(context['blocking'])} blocking issue(s):**"]
            lines += [f"> - **{i['order_id']}**: {md_cell(i['message'])}" for i in context["blocking"]]
            lines.append("")
        if context.get("gaps"):
            lines += ["> [!WARNING]", f"> **Evidence gaps - {len(context['gaps'])}:**"]
            lines += [f"> - **{i['order_id']}**: {md_cell(i['message'])}" for i in context["gaps"]]
            lines.append("")
    branch_ref = _strip_ref(branch)
    ahead = f" with {commits_ahead} commit(s)" if commits_ahead is not None else ""
    lines += ["## Summary", "", f"Voyage branch `{branch_ref}`{ahead}.", "", "### Orders"]
    if context:
        for o in context.get("orders", []):
            ac = o["acceptance"]
            lines.append(
                f"- {o['id']}: {md_cell(o['title'])} - QA {o['qa']['verdict'] or 'no report'}; "
                f"AC {ac['met']}/{ac['total']} PASS, {ac['failed']} FAIL; "
                f"SEC {o['security']['verdict'] or ('missing' if o['security']['required'] else 'n/a')}")
        if context.get("orders_omitted"):
            lines.append(f"- ... {context['orders_omitted']} more order(s) not listed: "
                         + ", ".join(context.get("omitted_order_ids", [])))
    else:
        for oid, title in normalise_order_refs(order_refs):
            lines.append(f"- {oid}: {title}" if title else f"- {oid}")
    lines += ["", "## Test plan", "- [ ] CI checks pass", "- [ ] Code review completed"]
    return "\n".join(lines) + "\n"


def _render_failsafe(resolved: ResolvedTemplate, ctx: Dict[str, Any],
                     on_event: Optional[EventSink], label: str
                     ) -> Tuple[str, Optional[str]]:
    """``(body, template_text_used)``; text is ``None`` for the minimal body."""
    ctx["template"] = {"tier": resolved.tier, "source": resolved.source,
                       "shadowed": list(resolved.shadowed), "failure": None}
    failure: Optional[str] = None
    if resolved.tier != TIER_DEFAULT:
        if resolved.error is not None:
            failure = resolved.error
        else:
            try:
                body = render_template_text(resolved.text or "", ctx)
                if not body.strip():
                    raise ValueError("template rendered an empty body")
                return body, resolved.text
            except Exception as exc:
                failure = f"{type(exc).__name__}: {exc}"
    if failure is not None:
        ctx["template"] = {
            "tier": TIER_DEFAULT, "source": DEFAULT_TEMPLATE_SOURCE,
            "shadowed": list(resolved.shadowed),
            "failure": {"tier": resolved.tier, "source": resolved.source,
                        "error": _one_line(failure)},
        }
        _emit(on_event, EVENT_TEMPLATE_FAILED,
              f"Voyage PR body for {label}: {resolved.tier} template ({resolved.source}) "
              f"failed - {_one_line(failure)}; rendered with the shipped default instead "
              "(FTR-MSO-2026-0502)")

    default_text = resolved.text if (resolved.tier == TIER_DEFAULT and failure is None) else None
    default_error = resolved.error if resolved.tier == TIER_DEFAULT else None
    if default_text is None and default_error is None:
        try:
            default_text = _read_template_file(default_template_path())
        except Exception as exc:
            default_error = f"{type(exc).__name__}: {exc}"
    if default_text is not None:
        try:
            return render_template_text(default_text, ctx), default_text
        except Exception as exc:
            default_error = f"{type(exc).__name__}: {exc}"
    _emit(on_event, EVENT_TEMPLATE_FAILED,
          f"Voyage PR body for {label}: the shipped default template failed - "
          f"{_one_line(default_error)}; minimal body used (FTR-MSO-2026-0502)")
    return minimal_body(ctx, ctx["voyage"]["branch"], (), ctx["voyage"]["commits_ahead"],
                        error=f"shipped default template failed: {default_error}"), None


_TRUNCATION_NOTE = (
    "\n\n---\n> [!WARNING]\n> **This PR body was truncated by Maestro:** {dropped} of {total} "
    "characters were dropped to fit the {limit}-character limit. The blocking issues and "
    "evidence gaps at the top cover every order; the full per-order evidence is in the QA "
    "and SEC reports.\n"
)


def hard_truncate(body: str, limit: int) -> str:
    """Cut *body* to at most *limit* characters at a line boundary, with a
    visible note saying how much was dropped."""
    total = len(body)
    if total <= limit:
        return body
    reserve = len(_TRUNCATION_NOTE.format(dropped=total, total=total, limit=limit)) + 8
    cut = body[: max(0, limit - reserve)]
    newline = cut.rfind("\n")
    if newline > len(cut) // 2:
        cut = cut[:newline]
    cut = cut.rstrip()
    return cut + _TRUNCATION_NOTE.format(dropped=total - len(cut), total=total, limit=limit)


def _fit_body(body: str, template_text: Optional[str], ctx: Dict[str, Any],
              limit: int, on_event: Optional[EventSink], label: str) -> str:
    if len(body) <= limit:
        return body
    original = len(body)
    if template_text is not None:
        compact_ctx = dict(ctx)
        compact_ctx["compact"] = True
        try:
            compact = render_template_text(template_text, compact_ctx)
        except Exception:
            compact = ""
        if compact.strip() and len(compact) < len(body):
            body = compact
    if len(body) <= limit:
        _emit(on_event, EVENT_TRUNCATED,
              f"Voyage PR body for {label}: {original} chars over the {limit}-char limit - "
              f"re-rendered compact ({len(body)} chars; passing AC rows and per-category test "
              "tables omitted) (FTR-MSO-2026-0502)")
        return body
    cut = hard_truncate(body, limit)
    _emit(on_event, EVENT_TRUNCATED,
          f"Voyage PR body for {label}: {original} chars (compact {len(body)}) over the "
          f"{limit}-char limit - cut to {len(cut)} chars with an in-body note "
          "(FTR-MSO-2026-0502)")
    return cut


def render_voyage_pr_body(mso: Optional[Path], *, branch: str,
                          order_refs: Sequence[Any] = (),
                          commits_ahead: Optional[int] = None,
                          on_event: Optional[EventSink] = None,
                          config: Optional[PrBodyConfig] = None) -> str:
    """THE voyage PR body. Never raises and never returns an empty string.

    *on_event* receives ``(event_type, message)`` for ``PR_BODY_TEMPLATE_FAILED``
    / ``PR_BODY_TRUNCATED`` / ``WARN`` — the dispatcher passes
    ``write_lifecycle_event``.
    """
    mso_path = Path(mso) if mso is not None else None
    branch_ref = _strip_ref(branch)
    try:
        cfg = config or load_pr_body_config(mso_path)
        ctx = build_pr_body_context(mso_path, branch=branch_ref, order_refs=order_refs,
                                    commits_ahead=commits_ahead, config=cfg)
    except Exception as exc:
        _emit(on_event, "WARN",
              f"Voyage PR body for {branch_ref}: context could not be built - "
              f"{type(exc).__name__}: {exc}; minimal body used (FTR-MSO-2026-0502)")
        return minimal_body(None, branch_ref, order_refs, commits_ahead,
                            error=f"{type(exc).__name__}: {exc}")
    try:
        resolved = resolve_pr_body_template(mso_path, cfg)
    except Exception as exc:  # pragma: no cover - resolve never raises
        resolved = ResolvedTemplate(TIER_DEFAULT, DEFAULT_TEMPLATE_SOURCE,
                                    error=f"{type(exc).__name__}: {exc}")
    try:
        body, used_text = _render_failsafe(resolved, ctx, on_event, branch_ref)
        return _fit_body(body, used_text, ctx, cfg.body_max_chars, on_event, branch_ref)
    except Exception as exc:  # pragma: no cover - defensive
        _emit(on_event, "WARN",
              f"Voyage PR body for {branch_ref}: rendering failed - {type(exc).__name__}: "
              f"{exc}; minimal body used (FTR-MSO-2026-0502)")
        return hard_truncate(minimal_body(ctx, branch_ref, order_refs, commits_ahead,
                                          error=f"{type(exc).__name__}: {exc}"),
                             cfg.body_max_chars)
