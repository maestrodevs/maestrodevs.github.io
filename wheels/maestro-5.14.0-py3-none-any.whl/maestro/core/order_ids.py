"""Shared order-creation validation and ID allocation (BUG-MSO-2026-0464).

SEC-MSO-2026-0461 FINDING 3: the bridge's ``_handle_order`` created FTR orders
with no description-length or priority validation, and allocated its sequence
number via ``len(existing) + 1`` over a single directory listing — not atomic
(two concurrent creations collide) and not correct once earlier orders have
been archived out of that directory (the count no longer reflects the highest
sequence). CLAUDE.md requires IDs to continue from the highest existing
sequence across ALL types and ALL order directories, never a re-count.

This module is the single allocator/validator both the CLI (``mso bug``) and
the bridge poller call, so the two rule sets cannot drift apart again.
"""

from __future__ import annotations

import os
import re
import time
from pathlib import Path
from typing import Optional, Sequence, TYPE_CHECKING

if TYPE_CHECKING:
    from maestro.core.artefact_sync import GitRunner

MAX_DESCRIPTION_LENGTH = 500
VALID_PRIORITIES = ("CRITICAL", "HIGH", "MEDIUM", "LOW")
DEFAULT_PRIORITY = "MEDIUM"

# Every directory an order JSON can live in across its lifecycle — active
# queues plus archives — so a sequence scan can never under-count because an
# earlier order moved out of queues/orders into orders/complete|failed.
ORDER_SCAN_SUBDIRS = (
    "queues/orders", "queues/bugs", "queues/security", "queues/defects",
    "queues/breakdown", "queues/high-level", "queues/requests",
    "orders/active", "orders/complete", "orders/failed",
)

# BUG-MSO-2026-0752: orders, voyages and charts share ONE sequence space per
# project/year (CLAUDE.md naming rule; PLAN-PLN-MSO-2026-0508 §3.1). Each
# allocator used to scan only its own artefact directories, so
# `mso voyage create` minted VOY-MSO-2026-0747 over PLN-MSO-2026-0747 (a review
# queue order + its plan and handoffs) and `mso order create` minted
# BUG-MSO-2026-0774 over VOY-MSO-2026-0774. This is every directory a
# sequenced artefact — or a file/directory named after one — can live in; every
# allocator scans all of it through :func:`highest_existing_sequence`.
# ``ORDER_SCAN_SUBDIRS`` stays the narrower "where order JSONs live" list.
SEQUENCE_SCAN_SUBDIRS = ORDER_SCAN_SUBDIRS + (
    "queues/review", "queues/proposed", "queues/explicit",
    "queues/cancelled", "queues/escalations",
    "voyages/active", "voyages/complete", "voyages/proposed",
    "charts", "plans", "handoffs",
)

_LOCK_STALE_SECONDS = 30
_LOCK_RETRY_INTERVAL_SECONDS = 0.05
_LOCK_TIMEOUT_SECONDS = 15


class OrderValidationError(ValueError):
    """Raised when order-creation input (description/priority) fails validation."""


def validate_description(description: Optional[str]) -> str:
    """Validate and normalise a description/title. Raises OrderValidationError."""
    description = (description or "").strip()
    if not description:
        raise OrderValidationError("Description is required")
    if len(description) > MAX_DESCRIPTION_LENGTH:
        raise OrderValidationError(
            f"Description exceeds {MAX_DESCRIPTION_LENGTH} characters "
            f"({len(description)} given)"
        )
    return description


def validate_priority(priority: Optional[str], default: str = DEFAULT_PRIORITY) -> str:
    """Validate and normalise a priority string. Raises OrderValidationError."""
    priority = (priority or default).strip().upper()
    if priority not in VALID_PRIORITIES:
        raise OrderValidationError(
            f"Invalid priority '{priority}' — must be one of {', '.join(VALID_PRIORITIES)}"
        )
    return priority


def _lock_path(mso_dir: Path) -> Path:
    return mso_dir / "state" / "order-id.lock"


class _CrossProcessLock:
    """Exclusive-create lockfile guarding order-ID allocation.

    ``os.O_CREAT | os.O_EXCL`` is atomic on both POSIX and Windows, so this
    works as a portable cross-process mutex without extra dependencies. A
    lock older than ``_LOCK_STALE_SECONDS`` is assumed to be left behind by a
    crashed holder and broken. If the lock cannot be acquired within
    ``_LOCK_TIMEOUT_SECONDS`` (wedged holder), allocation proceeds unlocked
    rather than blocking order creation forever — still far safer than the
    always-unlocked ``len(existing) + 1`` this replaces.
    """

    def __init__(self, path: Path):
        self.path = path
        self._acquired = False

    def __enter__(self) -> "_CrossProcessLock":
        self.path.parent.mkdir(parents=True, exist_ok=True)
        deadline = time.monotonic() + _LOCK_TIMEOUT_SECONDS
        while True:
            try:
                fd = os.open(str(self.path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                try:
                    os.write(fd, str(os.getpid()).encode("utf-8"))
                finally:
                    os.close(fd)
                self._acquired = True
                return self
            except (FileExistsError, PermissionError):
                # FileExistsError — a live holder owns the lock. Expected.
                #
                # PermissionError — Windows only, and the reason this clause is
                # not just FileExistsError. When the holder's __exit__ unlinks the
                # lock, Windows puts the file into a DELETE-PENDING state until the
                # last handle closes; os.open() against a delete-pending path
                # raises WinError 5 (PermissionError), not FileExistsError. Since
                # both are OSError subclasses but only one was caught, that race
                # escaped the retry loop and propagated out of __enter__, failing
                # order creation under exactly the contention this lock exists to
                # survive. Both conditions mean "someone else has it right now", so
                # both retry; a genuine permissions fault simply retries until the
                # deadline and then proceeds unlocked, the same degradation path a
                # wedged holder already takes.
                try:
                    if time.time() - self.path.stat().st_mtime > _LOCK_STALE_SECONDS:
                        self.path.unlink(missing_ok=True)
                        continue
                except OSError:
                    # stat() can itself fail on a delete-pending path — that just
                    # means the holder is releasing, so fall through and retry.
                    pass
                if time.monotonic() >= deadline:
                    return self
                time.sleep(_LOCK_RETRY_INTERVAL_SECONDS)

    def __exit__(self, exc_type, exc, tb) -> bool:
        if self._acquired:
            try:
                self.path.unlink(missing_ok=True)
            except OSError:
                pass
        return False


def lock_for_allocation(mso_dir: Path) -> _CrossProcessLock:
    """Context manager serialising order-ID allocation across processes.

    The scan-then-write critical section MUST happen entirely inside the
    ``with`` block — computing the ID and writing the order file both inside
    the lock is what makes two concurrent creations race-safe::

        with lock_for_allocation(mso_dir):
            order_id = allocate_order_id(mso_dir, "BUG", project, year)
            (orders_dir / f"{order_id}.json").write_text(...)
    """
    return _CrossProcessLock(_lock_path(mso_dir))


def sequence_id_pattern(project: str, year: str) -> "re.Pattern[str]":
    """Name regex for any sequenced artefact of (project, year), group 1 = seq.

    Matches order, voyage and chart JSONs (``BUG-P-Y-0001.json``,
    ``VOY-P-Y-0001.json``, ``CHT-P-Y-0001.json``), plan documents that embed an
    id (``PLAN-PLN-P-Y-0001.md``, legacy ``NAV-FTR-P-Y-0001.md``), proposal
    markdown (``FTR-P-Y-0001.md``) and handoff directories (``BUG-P-Y-0001``).
    Deliberately strict about the tail — a ``.bak``/``.txt`` copy or a
    ``-suffix`` name is not a real artefact and must not inflate the max.
    """
    return re.compile(
        rf'^(?:[A-Z]+-)+{re.escape(project)}-{re.escape(year)}-(\d+)'
        rf'(?:\.json|\.md)?$'
    )


def highest_existing_sequence(mso_dir: Path, project: str, year: str) -> int:
    """Highest existing sequence number for (project, year) across the WHOLE
    workspace — every order type, voyages, charts, plans and handoffs.

    This is the one local scan every ID allocator uses (orders, voyages,
    charts). BUG-MSO-2026-0570 widened it from one order type to all order
    types; BUG-MSO-2026-0752 widened it from orders to every artefact that
    shares the sequence space (:data:`SEQUENCE_SCAN_SUBDIRS`), because a
    voyage allocator that could not see orders — and an order allocator that
    could not see voyages — each minted numbers the other had already used.
    """
    pattern = sequence_id_pattern(project, year)
    highest = 0
    for sub in SEQUENCE_SCAN_SUBDIRS:
        d = mso_dir / sub
        if not d.is_dir():
            continue
        for f in d.iterdir():
            m = pattern.match(f.name)
            if m:
                highest = max(highest, int(m.group(1)))
    return highest


def fetch_remote_sequence_numbers(mso_dir: Path, subdirs: Sequence[str],
                                   id_pattern: "re.Pattern[str]", *,
                                   git: "Optional[GitRunner]" = None,
                                   timeout: int = 20) -> Optional[int]:
    """Highest sequence number matched by *id_pattern* (group 1 = digits)
    across *subdirs*, read from the artefact repo's FETCHED REMOTE TREE.

    FTR-MSO-2026-0574: a purely local scan (:func:`highest_existing_sequence`)
    cannot see a number another device already minted and pushed — two
    clones of one bare remote, each minting without pulling in between,
    compute the same next sequence (plan §2.3). Fetching first narrows that
    race to the fetch window rather than eliminating it (creation is a
    human-cadence action; the plan accepts this and backstops it with a
    post-allocation uniqueness assertion at the call sites).

    Returns ``None`` — meaning "nothing to add, proceed local-only" — when
    there is no ``.git`` repo, no configured remote, no resolvable branch, or
    the fetch itself fails (offline). This is a SILENT skip by design: it
    preserves FTR-MSO-2026-0366's deliberate offline tolerance rather than
    turning a disconnected laptop into a hard error. Generic over order-ID and
    voyage-ID shapes so ``mso bug`` and ``mso voyage create`` share one fetch
    mechanism rather than each inventing their own.
    """
    repo_root = mso_dir.parent
    if not (repo_root / ".git").exists():
        return None
    if git is None:
        from maestro.core.artefact_sync import GitRunner
        git = GitRunner(repo_root)
    if not git.has_remote():
        return None
    branch = git.current_branch()
    if not branch:
        return None
    fetch_r = git.run("fetch", "origin", branch, timeout=timeout)
    if not fetch_r.ok:
        return None

    ref = f"origin/{branch}"
    highest = 0
    for sub in subdirs:
        tree_spec = f"{ref}:{mso_dir.name}/{sub}"
        ls_r = git.run("ls-tree", "--name-only", tree_spec, timeout=timeout)
        if not ls_r.ok:
            # Path did not exist yet at that ref (e.g. a brand-new subdir) —
            # not a fetch failure, just nothing to add from this directory.
            continue
        for name in ls_r.stdout.splitlines():
            name = name.strip()
            if not name:
                continue
            m = id_pattern.match(name)
            if m:
                highest = max(highest, int(m.group(1)))
    return highest


def fetch_remote_max_sequence(mso_dir: Path, project: str, year: str, *,
                               git: "Optional[GitRunner]" = None,
                               timeout: int = 20) -> Optional[int]:
    """:func:`fetch_remote_sequence_numbers` over the same directories and name
    shape as :func:`highest_existing_sequence` — the whole workspace sequence
    space (BUG-MSO-2026-0752), so the local and remote halves of an allocation
    cannot disagree about what counts.
    """
    return fetch_remote_sequence_numbers(
        mso_dir, SEQUENCE_SCAN_SUBDIRS, sequence_id_pattern(project, year),
        git=git, timeout=timeout)


def allocate_order_id(mso_dir: Path, order_type: str, project: str, year: str, *,
                       fetch_remote: bool = True,
                       git: "Optional[GitRunner]" = None) -> str:
    """Allocate the next order ID for (order_type, project, year).

    The sequence number is drawn from the GLOBAL max across the whole
    workspace for this project/year — every order type (BUG-MSO-2026-0570)
    and every voyage, chart, plan and handoff (BUG-MSO-2026-0752) — only the
    type prefix below is type-specific.

    FTR-MSO-2026-0574: before computing the max, also fetches the artefact
    repo's remote (when one is configured) and folds the fetched remote
    tree's max sequence in too — see :func:`fetch_remote_max_sequence`. Skips
    SILENTLY (no error, no behaviour change) when offline, ungitted, or no
    remote is configured. Pass ``fetch_remote=False`` to force a local-only
    scan (e.g. a caller that already fetched/reset ``git`` to the remote tip
    moments ago and would otherwise redo the same fetch).

    Callers MUST invoke this inside a ``with lock_for_allocation(mso_dir):``
    block that also performs the resulting file write (see that function's
    docstring) — calling this alone is not race-safe.
    """
    local_max = highest_existing_sequence(mso_dir, project, year)
    remote_max = 0
    if fetch_remote:
        fetched = fetch_remote_max_sequence(mso_dir, project, year, git=git)
        if fetched is not None:
            remote_max = fetched
    seq = max(local_max, remote_max) + 1
    return f"{order_type}-{project}-{year}-{seq:04d}"
