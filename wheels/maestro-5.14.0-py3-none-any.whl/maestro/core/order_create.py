# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Shared order-creation core (FTR-MSO-2026-0620 / PLAN-PLN-MSO-2026-0556 §3.2).

Extracted from the THREE divergent order writers the shipped package carried —
``cli.cmd_bug``, ``bridge_poller._handle_order`` and
``bridge_poller._handle_bug_create`` — so the CLI, the Slack bridge and (from
Order 5) the Hub's ``POST /workspaces/{id}/orders`` share exactly ONE
implementation. ``maestro/core/review_core.py``'s docstring records what the
alternative costs: five silent behavioural drifts between the Hub's private
copy of the review logic and the CLI's, two of them order-destroying, none
found by reading either implementation alone (BUG-MSO-2026-0486).

The drift this module closes was already live and already measured
(PLAN-PLN-MSO-2026-0556 §5.4): the same engine emitted ``["SHP", "BOS"]`` from
``mso bug`` and ``["NAV", "SHP", "BOS", "SCR", "LKT"]`` from the bridge — two
vocabularies (legacy nautical vs canonical) and two different notions of what
a default role sequence is. Both vocabularies are valid aliases, which is
precisely why a free-form ``roleSequence`` is dangerous: a half-and-half
sequence gates against nothing, and the v8.2 role-sequence gate then blocks
dispatch on a prior role that will never complete. So role codes are
NORMALISED to the canonical set on write, and a code the engine does not know
is refused rather than persisted.

Module contract — copied verbatim from ``maestro/core/order_retry.py``
(PLAN-PLN-MSO-2026-0556 §3.3), not invented here:

* **Explicit ``mso: Path`` throughout. No ``find_workspace()``, no CWD.** The
  Hub serves N workspaces from one process; a core that resolves its workspace
  from the process is unusable there.
* **Typed exceptions, no printing, no ``sys.exit``.**
  :class:`~maestro.core.order_ids.OrderValidationError` -> HTTP 400 /
  ``MaestroUserError``; :class:`OrderNotFound` (a ``FileNotFoundError``) -> 404;
  :class:`OrderEditRefused` -> 409; ``CapabilityDenied`` -> 403.
* **Every mutation runs inside ``order_retry.workspace_scope(mso)``.** Not
  decorative: shared-mode allocation goes through
  ``artefact_sync.push_id_reservation``, which writes ``ID_RESERVED`` lifecycle
  events resolved from ``fleet_runner._MAESTRO_DIR_OVERRIDE`` — a process
  global. Unguarded, a Hub poller tick for workspace A can write into
  workspace B's lifecycle log.
* **The write happens under ``lock_for_allocation(mso)``, inside the same
  ``with`` block as the allocation** — ``order_ids.py`` is explicit that
  calling ``allocate_order_id`` outside that block is not race-safe.

``require_capability("order.create")`` is enforced here, which makes this a
NEW enforcement point for governed/enterprise workspaces (``cmd_bug`` had no
gate at all) and a no-op everywhere else — the same shape FTR-MSO-2026-0492
established when it moved ``order.dispatch`` inside ``retry_order()``.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

from maestro.core import undispatchable
from maestro.core.gates import canonical_role
from maestro.core.order_ids import (
    OrderValidationError,
    allocate_order_id,
    lock_for_allocation,
    validate_description,
    validate_priority,
)
from maestro.core.order_retry import workspace_scope
from maestro.roles.loader import CANONICAL_ROLE_CODES

# ---------------------------------------------------------------------------
# Vocabulary
# ---------------------------------------------------------------------------

#: Roles a crew can actually be dispatched at. ``LEAD`` is a canonical role
#: code but is the interactive partner — it is never dispatched, so a
#: roleSequence containing it strands the order at the role-sequence gate.
#: Refusing it at creation is cheaper than diagnosing it at dispatch.
DISPATCHABLE_ROLES: tuple = tuple(c for c in CANONICAL_ROLE_CODES if c != "LEAD")

#: Order-type prefix shape — it becomes the ID's prefix, so it must be the
#: same shape ``order_ids``' scan patterns match (``^[A-Z]+-{PRJ}-{YEAR}-...``).
_ORDER_TYPE_RE = re.compile(r"^[A-Z]{2,8}$")
#: Project acronym shape — likewise part of every ID this mints.
_PROJECT_RE = re.compile(r"^[A-Z][A-Z0-9]{1,9}$")

#: Queue directories an order may be created into. An allowlist, not a
#: free-form path segment: ``queue`` reaches a filesystem join, and these are
#: exactly the directories ``fleet_runner.scan_all_queues`` tiers over.
VALID_QUEUES: tuple = (
    "orders", "bugs", "security", "defects", "breakdown", "high-level", "explicit",
)
DEFAULT_QUEUE = "orders"

#: Statuses an order may be EDITED at (PLAN-PLN-MSO-2026-0556 Order 6): work
#: that has not yet been claimed by a crew. Anything else — RUNNING,
#: IN_PROGRESS, COMPLETE, STALLED — is either owned by a live crew right now or
#: already terminal, and editing it rewrites the premise a crew is working
#: from (or has already worked from).
EDITABLE_STATUSES: frozenset = frozenset({"PENDING", "BACKLOG", "PROPOSED"})

#: Statuses an order may be CREATED at (PLAN-PLN-MSO-2026-0556 Order 5).
#:
#: **Aliased to** :data:`EDITABLE_STATUSES` — the same object, not a second
#: list that happens to have the same members today. The rule it encodes is
#: that an order may only be created in a state it could also be EDITED in:
#: creating an order at a status the edit path would then refuse to touch
#: would mint something the operator cannot subsequently correct from the same
#: surface that made it. One list means the two can never drift into
#: disagreeing, and ``CREATABLE_STATUSES is EDITABLE_STATUSES`` is asserted
#: rather than left as a comment.
#:
#: Why this exists at all: the Hub's create drawer already had a Lane control
#: (``In Progress`` / ``Backlog``) that reached no server and changed nothing —
#: an inert control, which PLAN §6 forbids. The choice was to delete the
#: control or make it real; making it real is one constrained kwarg, and
#: ``BACKLOG`` is a state the engine already understands.
#:
#: BUG-MSO-2026-0741: membership here is NECESSARY, not sufficient.
#: ``PROPOSED`` additionally requires a non-empty ``dependsOn`` at creation —
#: see :mod:`maestro.core.undispatchable`, whose ``create_refusal()``
#: :func:`create_order` calls once the dependency list is normalised. Encoding
#: that as a cross-field check rather than by removing ``PROPOSED`` from this
#: set is deliberate: a PROPOSED order that names its dependency is a
#: perfectly good order, and this set is aliased to
#: :data:`EDITABLE_STATUSES`, where ``PROPOSED`` must stay (it is how an
#: operator hands an existing order to a Charts Phase 2 frontier node).
CREATABLE_STATUSES: frozenset = EDITABLE_STATUSES

#: What :func:`create_order` writes when no status is asked for. Every
#: pre-Order-5 caller passes nothing, so they are byte-identical to before.
DEFAULT_ORDER_STATUS = "PENDING"

#: Fields ``edit_order`` will change. An allowlist, so an edit can never reach
#: the load-bearing lifecycle fields (``status`` transitions owned by the
#: dispatcher, ``orderId``, ``createdAt``, the ledger-mirroring fields, the
#: salvage/convergence bookkeeping) through a caller passing extra keys.
EDITABLE_FIELDS: frozenset = frozenset({
    "title", "description", "priority", "roleSequence", "targetRole",
    "acceptanceCriteria", "dependsOn", "targetRepo", "voyageId", "voyageBranch",
    "timeoutMinutes", "model", "status",
})

#: Default role sequence per order type, in CANONICAL codes.
#:
#: These preserve what the shipped engine actually produced, canonicalised —
#: they are not a redesign. ``BUG`` is ``cmd_bug``/``_handle_bug_create``'s
#: ``["SHP", "BOS"]``; ``FTR`` is ``_handle_order``'s
#: ``["NAV", "SHP", "BOS", "SCR", "LKT"]``. The remaining types take the
#: engine's own default-role mapping (``fleet_runner``'s ``order_roles``) as
#: their first role, plus the build/verify tail that role implies.
#:
#: NOTE these deliberately differ from ``maestro/packs/sdlc/pack.json``'s
#: ``orderTypes`` (which routes BUG through PLN and REL as well). A workspace
#: that has installed a pack's order templates gets the PACK's sequence — see
#: :func:`resolve_role_sequence`, which consults
#: ``.mso/orders/templates/{TYPE}-template.json`` first. This map is the
#: fallback for the many workspaces that have no templates installed, and for
#: those, silently lengthening every bug's role chain would be a behaviour
#: change nobody asked for.
DEFAULT_ROLE_SEQUENCES: Dict[str, tuple] = {
    "FTR": ("PLN", "BLD", "TST", "DOC", "SEC"),
    "BUG": ("BLD", "TST"),
    "FIX": ("BLD", "TST"),
    "RFT": ("BLD", "TST"),
    "TEST": ("BLD", "TST"),
    "DEFECT": ("BLD", "TST"),
    "SEC": ("SEC", "BLD", "TST"),
    "INV": ("PLN",),
    "PLN": ("PLN",),
    "DOC": ("DOC",),
    "REL": ("REL",),
}

#: Used when an unknown order type is created and no template supplies a
#: sequence. Mirrors ``fleet_runner``'s own ``order_roles.get(order_type, "SHP")``
#: fallback — build then verify.
FALLBACK_ROLE_SEQUENCE: tuple = ("BLD", "TST")

#: Default priority per type. ``mso bug`` defaults BUG to HIGH; the bridge's
#: generic order defaults to MEDIUM (``order_ids.DEFAULT_PRIORITY``). Both are
#: preserved rather than averaged into one.
DEFAULT_PRIORITY_BY_TYPE: Dict[str, str] = {
    "BUG": "HIGH",
    "FIX": "HIGH",
    "DEFECT": "HIGH",
    "SEC": "HIGH",
}
FALLBACK_PRIORITY = "MEDIUM"

#: Fields :func:`create_order` computes and validates itself — ``extra`` may
#: not overwrite any of them.
_COMPUTED_FIELDS: frozenset = frozenset({
    "orderId", "type", "project", "title", "priority", "status", "targetRole",
    "roleSequence", "acceptanceCriteria", "acResults", "createdBy", "createdAt",
})


# ---------------------------------------------------------------------------
# Typed errors
# ---------------------------------------------------------------------------

class OrderNotFound(FileNotFoundError):
    """*order_id* is not in any queue directory of this workspace.

    A ``FileNotFoundError`` subclass so an HTTP caller can map it to 404 with
    the same ``except FileNotFoundError`` arm it already uses, per the module
    contract in the docstring above.
    """

    def __init__(self, order_id: str) -> None:
        self.order_id = order_id
        self.hint = (
            "Only queued orders can be edited. An archived order must be "
            f"reopened first: mso order retry {order_id}"
        )
        super().__init__(f"Order {order_id} not found in any queue.")


class OrderEditRefused(Exception):
    """The order exists but is not editable — a live crew owns it, or it is
    terminal. Maps to HTTP 409."""

    def __init__(self, order_id: str, message: str, hint: str = "") -> None:
        self.order_id = order_id
        self.hint = hint
        super().__init__(message)


@dataclass
class CreatedOrder:
    """Result of a successful :func:`create_order` call."""

    order_id: str
    path: Path
    order: Dict[str, Any]
    #: True when shared-mode push-as-mutex actually reserved the id upstream.
    reserved: bool = False
    #: ``push_id_reservation``'s outcome reason, or ``"local"`` in solo/embedded.
    reservation_reason: str = "local"


@dataclass
class EditedOrder:
    """Result of a successful :func:`edit_order` call."""

    order_id: str
    path: Path
    order: Dict[str, Any]
    changed_fields: List[str] = field(default_factory=list)
    #: The role ``edit_order`` re-anchored ``targetRole`` to on its own
    #: initiative, or ``""`` when it did not touch ``targetRole``. Empty for a
    #: caller-supplied ``targetRole`` — this field means "the edit changed this
    #: field and you did not ask it to", which ``changed_fields`` alone cannot
    #: say (BUG-MSO-2026-0742).
    reanchored_role: str = ""


# ---------------------------------------------------------------------------
# Role-code normalisation (PLAN-PLN-MSO-2026-0556 §5.4)
# ---------------------------------------------------------------------------

def normalise_role(role: Any, *, field_name: str = "targetRole") -> str:
    """Canonical dispatchable role code for *role*.

    Folds the legacy nautical aliases (NAV->PLN, SHP->BLD, BOS->TST, SCR->DOC,
    LKT->SEC, COX->REL) via :func:`maestro.core.gates.canonical_role` — the
    engine's existing normaliser, not a second copy of the alias table. Raises
    :class:`OrderValidationError` for anything that is not a dispatchable role
    afterwards, so an unknown code is refused at creation rather than
    stranding the order at the v8.2 role-sequence gate later.
    """
    code = canonical_role(role)
    if not code:
        raise OrderValidationError(f"{field_name} is required")
    if code not in DISPATCHABLE_ROLES:
        raise OrderValidationError(
            f"Invalid {field_name} '{role}' — must be one of "
            f"{', '.join(DISPATCHABLE_ROLES)} (legacy nautical aliases "
            f"NAV/SHP/BOS/SCR/LKT/COX are accepted and normalised)"
        )
    return code


def normalise_role_sequence(sequence: Sequence[Any]) -> List[str]:
    """Canonicalise a whole role sequence, preserving order and dropping
    consecutive duplicates introduced by normalisation (e.g. a hand-written
    ``["SHP", "BLD"]`` is one build role spelled two ways, not two roles).

    Raises :class:`OrderValidationError` on an empty sequence or an
    unrecognised code — a roleSequence is load-bearing, never free-form.
    """
    if isinstance(sequence, str) or not isinstance(sequence, (list, tuple)):
        raise OrderValidationError("roleSequence must be a list of role codes")
    out: List[str] = []
    for entry in sequence:
        code = normalise_role(entry, field_name="roleSequence entry")
        if not out or out[-1] != code:
            out.append(code)
    if not out:
        raise OrderValidationError("roleSequence must contain at least one role")
    return out


# ---------------------------------------------------------------------------
# Type-driven defaults
# ---------------------------------------------------------------------------

def _order_template_sequence(mso: Path, order_type: str) -> Optional[List[str]]:
    """The roleSequence a pack's installed order template declares for
    *order_type*, or ``None``.

    ``maestro/packs/scaffold.py:apply_pack`` copies a division pack's
    ``order-templates/*-template.json`` into ``.mso/orders/templates/``. That
    directory is the only workspace-visible record of the pack's order-type
    vocabulary (nothing stamps a pack id into ``workspace.json``), so it is
    what "the workspace's configured sequences" means in practice.
    """
    template = mso / "orders" / "templates" / f"{order_type}-template.json"
    if not template.exists():
        return None
    try:
        data = json.loads(template.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    seq = data.get("roleSequence") or (data.get("_meta") or {}).get("roleSequence")
    if not seq:
        return None
    try:
        return normalise_role_sequence(seq)
    except OrderValidationError:
        # A malformed template must not block order creation — fall through to
        # the built-in default rather than failing a create the operator can
        # do nothing about.
        return None


def resolve_role_sequence(mso: Path, order_type: str) -> List[str]:
    """The default roleSequence for *order_type* in workspace *mso*.

    Resolution order, most specific first:

    1. the workspace's installed order template for that type (a division
       pack's ``.mso/orders/templates/{TYPE}-template.json``);
    2. :data:`DEFAULT_ROLE_SEQUENCES` — the shipped engine's own behaviour,
       canonicalised;
    3. :data:`FALLBACK_ROLE_SEQUENCE`.

    Every caller (CLI, bridge, Hub) resolves through this one function, which
    is what makes the PLAN-PLN-MSO-2026-0556 §5.4 identity assertion — same
    type, same sequence, whichever surface created it — true by construction
    rather than by two implementations happening to agree.
    """
    order_type = (order_type or "").strip().upper()
    from_template = _order_template_sequence(mso, order_type)
    if from_template:
        return from_template
    return list(DEFAULT_ROLE_SEQUENCES.get(order_type, FALLBACK_ROLE_SEQUENCE))


def default_priority_for(order_type: str) -> str:
    """The default priority for *order_type* (preserves ``mso bug``'s HIGH and
    the bridge's MEDIUM rather than picking one for both)."""
    return DEFAULT_PRIORITY_BY_TYPE.get(
        (order_type or "").strip().upper(), FALLBACK_PRIORITY)


# ---------------------------------------------------------------------------
# Validation helpers
# ---------------------------------------------------------------------------

def validate_order_type(order_type: Optional[str]) -> str:
    """Validate and normalise an order-type prefix (FTR / BUG / SEC / ...)."""
    value = (order_type or "").strip().upper()
    if not value:
        raise OrderValidationError("Order type is required")
    if not _ORDER_TYPE_RE.match(value):
        raise OrderValidationError(
            f"Invalid order type '{order_type}' — must be 2-8 uppercase "
            "letters (e.g. FTR, BUG, SEC, INV, PLN, DOC)"
        )
    return value


def validate_project(project: Optional[str]) -> str:
    """Validate and normalise a project acronym (it becomes part of every ID)."""
    value = (project or "").strip().upper()
    if not value:
        raise OrderValidationError("Project acronym is required")
    if not _PROJECT_RE.match(value):
        raise OrderValidationError(
            f"Invalid project acronym '{project}' — must be 2-10 characters, "
            "starting with a letter, uppercase alphanumeric (e.g. MSO, PSG)"
        )
    return value


def validate_creatable_status(status: Optional[str]) -> str:
    """Validate a requested creation status against :data:`CREATABLE_STATUSES`.

    ``None``/empty means "the default" (:data:`DEFAULT_ORDER_STATUS`), which is
    what every caller written before PLAN-PLN-MSO-2026-0556 Order 5 passes.

    An unknown status is refused rather than written through: ``status`` is
    read by ``scan_all_queues``' dispatch gate, by the ledger, and by the
    sweep's outstanding-work guard, and a value none of them recognise is an
    order that sits in a queue forever while looking filed. The refusal names
    the accepted set, because an operator seeing it has typed a status they
    believed in.
    """
    value = (status or "").strip().upper()
    if not value:
        return DEFAULT_ORDER_STATUS
    if value not in CREATABLE_STATUSES:
        raise OrderValidationError(
            f"Invalid status '{status}' — an order may only be created at "
            f"{', '.join(sorted(CREATABLE_STATUSES))}"
        )
    return value


def known_order_types(mso: Path) -> List[str]:
    """Every order type this workspace can create, sorted.

    The union of :data:`DEFAULT_ROLE_SEQUENCES`' built-in vocabulary and any
    order templates a division pack has installed into
    ``.mso/orders/templates/`` — i.e. exactly the set for which
    :func:`resolve_role_sequence` has a real answer rather than the
    :data:`FALLBACK_ROLE_SEQUENCE` guess.

    This exists so a picker can be built over the workspace's OWN vocabulary
    instead of a second copy of it hard-coded in the frontend (PLAN §5.4). The
    drawer that prompted it offered four hard-coded buttons, one of which
    (``HANDOFF``) is not an order type at all — it passes the ``[A-Z]{2,8}``
    shape check, so pressing it would have minted ``HANDOFF-{PRJ}-{YEAR}-0001``
    into a queue with the fallback role chain and no engine anywhere expecting
    it. A list served from here cannot contain that.
    """
    mso = Path(mso)
    types = set(DEFAULT_ROLE_SEQUENCES)
    templates = mso / "orders" / "templates"
    try:
        entries = list(templates.glob("*-template.json"))
    except OSError:
        entries = []
    for tf in entries:
        name = tf.name[: -len("-template.json")].strip().upper()
        if _ORDER_TYPE_RE.match(name):
            types.add(name)
    return sorted(types)


def order_type_defaults(mso: Path, order_type: str) -> Dict[str, Any]:
    """Everything a caller needs to pre-fill a create form for *order_type*.

    Resolved through the SAME functions :func:`create_order` itself calls, so
    what a picker offers and what a create actually writes cannot disagree —
    which is the property that makes serving this cheaper than duplicating the
    vocabulary client-side.

    ``source`` says where the roleSequence came from (``"template"`` when the
    workspace has installed one for this type, else ``"builtin"``) so a
    surface can show the operator that their pack is in effect.
    """
    order_type = (order_type or "").strip().upper()
    return {
        "type": order_type,
        "roleSequence": resolve_role_sequence(mso, order_type),
        "priority": default_priority_for(order_type),
        "queue": DEFAULT_QUEUE,
        "source": ("template" if _order_template_sequence(mso, order_type)
                   else "builtin"),
    }


def validate_queue(queue: Optional[str]) -> str:
    """Validate the target queue directory against :data:`VALID_QUEUES`."""
    value = (queue or DEFAULT_QUEUE).strip().lower()
    if value not in VALID_QUEUES:
        raise OrderValidationError(
            f"Invalid queue '{queue}' — must be one of {', '.join(VALID_QUEUES)}"
        )
    return value


def _normalise_id_list(values: Optional[Sequence[Any]], field_name: str) -> List[str]:
    if values is None:
        return []
    if isinstance(values, str) or not isinstance(values, (list, tuple)):
        raise OrderValidationError(f"{field_name} must be a list of order IDs")
    out: List[str] = []
    for v in values:
        s = str(v or "").strip()
        if s and s not in out:
            out.append(s)
    return out


def _normalise_acceptance_criteria(values: Optional[Sequence[Any]]) -> List[Any]:
    if values is None:
        return []
    if isinstance(values, str) or not isinstance(values, (list, tuple)):
        raise OrderValidationError("acceptanceCriteria must be a list")
    return list(values)


# ---------------------------------------------------------------------------
# Order lookup
# ---------------------------------------------------------------------------

def find_order_file(mso: Path, order_id: str) -> Optional[Path]:
    """Path of *order_id*'s JSON in ``mso``'s queue tree, or ``None``.

    Same coverage as ``order_retry``'s stranded-order scan — ``queues/*/`` and
    ``queues/requests/*/`` — and the same id resolution (``orderId`` /``id`` /
    filename stem), so the two cores agree about which file IS an order.
    """
    queues_dir = mso / "queues"
    if not queues_dir.exists():
        return None
    for jf in (list(queues_dir.glob("*/*.json"))
               + list(queues_dir.glob("*/*/*.json"))):
        try:
            data = json.loads(jf.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if (data.get("orderId") or data.get("id") or jf.stem) == order_id:
            return jf
    return None


# ---------------------------------------------------------------------------
# create_order
# ---------------------------------------------------------------------------

def create_order(
    mso: Path,
    *,
    order_type: str,
    project: str,
    title: str,
    priority: Optional[str] = None,
    description: str = "",
    role_sequence: Optional[Sequence[Any]] = None,
    target_role: Optional[str] = None,
    acceptance_criteria: Optional[Sequence[Any]] = None,
    depends_on: Optional[Sequence[Any]] = None,
    voyage_id: str = "",
    voyage_branch: str = "",
    target_repo: str = "",
    queue: str = DEFAULT_QUEUE,
    status: Optional[str] = None,
    created_by: str = "cli",
    extra: Optional[Dict[str, Any]] = None,
) -> CreatedOrder:
    """Create an order of any type in workspace *mso* and return what landed.

    Sole implementation of order creation — ``mso bug``, ``mso order create``,
    the bridge's ``order``/``bug`` commands and (Order 5) the Hub's
    ``POST /workspaces/{id}/orders`` all call this.

    *role_sequence* / *target_role* default from the order TYPE
    (:func:`resolve_role_sequence`); when supplied they are normalised to
    canonical codes and validated, never persisted free-form. *target_role*
    defaults to the first role of the resolved sequence and must be a member
    of it — a targetRole outside its own sequence is the shape that strands an
    order at the role-sequence gate.

    *status* (PLAN Order 5) is constrained to :data:`CREATABLE_STATUSES` and
    defaults to :data:`DEFAULT_ORDER_STATUS`, so every caller that omits it —
    which is every caller written before Order 5 — writes exactly what it wrote
    before. It is a real parameter rather than an ``extra`` key because
    ``status`` is in :data:`_COMPUTED_FIELDS`: a forged status must not be able
    to reach the file through the caller-supplied passthrough, and the way to
    keep that true while still allowing ``BACKLOG`` is a validated argument.

    Raises :class:`~maestro.core.order_ids.OrderValidationError` on bad input
    and ``CapabilityDenied`` in a governed workspace whose caller lacks
    ``order.create``. Prints nothing; exits nothing.
    """
    from maestro.identity.gate import require_capability

    # PLAN-PLN-MSO-2026-0556 §4.2: `order.create` is declared in the capability
    # registry but was enforced NOWHERE — cmd_bug had no gate. Enforcing it in
    # the core (not in either wrapper) protects the CLI, the bridge and the Hub
    # identically, the same shape FTR-MSO-2026-0492 used for order.dispatch.
    # `mso` is the artefact .mso dir; the gate wants the WORKSPACE ROOT. A
    # no-op outside enterprise/governed workspaces.
    require_capability("order.create", workspace=Path(mso).parent)

    mso = Path(mso)
    order_type = validate_order_type(order_type)
    project = validate_project(project)
    queue = validate_queue(queue)
    title = validate_description(title)
    priority = validate_priority(priority, default=default_priority_for(order_type))
    status = validate_creatable_status(status)

    # `None` means "resolve it from the order type"; an explicitly EMPTY
    # sequence is a caller error, not a request for the default — an order with
    # no roles is never dispatchable, and silently substituting the default
    # would hide the mistake.
    sequence = (resolve_role_sequence(mso, order_type) if role_sequence is None
                else normalise_role_sequence(role_sequence))
    if target_role:
        role = normalise_role(target_role)
        if role not in sequence:
            raise OrderValidationError(
                f"targetRole '{role}' is not in roleSequence "
                f"{sequence} — the order would never be dispatched"
            )
    else:
        role = sequence[0]

    criteria = _normalise_acceptance_criteria(acceptance_criteria)
    dependencies = _normalise_id_list(depends_on, "dependsOn")

    # BUG-MSO-2026-0741: a release-gated status (PROPOSED/HELD) with no
    # dependsOn is an order nothing can ever select — every automatic release
    # route declines it for a documented reason, so it sits in a queue looking
    # filed forever. The refusal is safe HERE specifically because the id has
    # not been minted yet: no chart node and no other order's dependsOn can
    # reference an id that does not exist, so the one legitimate
    # dependency-free hold (a Charts Phase 2 frontier node) provably cannot
    # apply to a brand-new order. Editing an EXISTING order to PROPOSED stays
    # allowed for exactly that reason — see undispatchable.py's module
    # docstring, and `mso doctor`'s orders.undispatchable-proposed for the
    # report that covers the paths this refusal does not.
    refusal = undispatchable.create_refusal(status, dependencies)
    if refusal:
        raise OrderValidationError(refusal)

    now = datetime.now(timezone.utc)
    year = now.strftime("%Y")
    orders_dir = mso / "queues" / queue
    orders_dir.mkdir(parents=True, exist_ok=True)

    written: Dict[str, Any] = {}

    def _build(order_id: str) -> Dict[str, Any]:
        order: Dict[str, Any] = {
            "orderId": order_id,
            "type": order_type,
            "project": project,
            "title": title,
            "priority": priority,
            "status": status,
            "targetRole": role,
            "roleSequence": list(sequence),
            "acceptanceCriteria": criteria,
            "acResults": [],
            "createdBy": created_by,
            "createdAt": now.isoformat(),
        }
        if description:
            order["description"] = description
        if dependencies:
            order["dependsOn"] = dependencies
        if voyage_id:
            order["voyageId"] = voyage_id
        if voyage_branch:
            order["voyageBranch"] = voyage_branch
        if target_repo:
            order["targetRepo"] = target_repo
        for key, value in (extra or {}).items():
            # `extra` is for caller-specific fields this function does not model
            # (timeoutMinutes, model, gates, ...). It may never overwrite a field
            # this function computed — otherwise a caller could smuggle an
            # un-normalised roleSequence or a forged status straight past the
            # validation above, which is the whole point of having one core.
            if key not in _COMPUTED_FIELDS:
                order[key] = value
        return order

    def _write(order_id: str) -> Path:
        order = _build(order_id)
        path = orders_dir / f"{order_id}.json"
        path.write_text(json.dumps(order, indent=2), encoding="utf-8")
        written.clear()
        written.update(order)
        return path

    # workspace_scope: shared-mode reservation writes ID_RESERVED lifecycle
    # events through fleet_runner's process-global override (module docstring).
    # lock_for_allocation: the scan-then-write critical section must be ONE
    # locked block — order_ids.py is explicit that allocating outside it is not
    # race-safe.
    with workspace_scope(mso):
        with lock_for_allocation(mso):
            # FTR-MSO-2026-0574: allocate_order_id() already fetches the
            # artefact remote before computing the max in every mode (skipped
            # silently offline). In mode: shared ONLY, additionally reserve the
            # id via push-as-mutex — solo mode does not get this: an unsynced
            # solo device against a shared plane is a misconfiguration to
            # migrate away from, not something to arbitrate.
            from maestro.core.artefact_sync import get_mode, push_id_reservation

            if get_mode(mso) == "shared":
                outcome = push_id_reservation(
                    mso,
                    lambda git: allocate_order_id(
                        mso, order_type, project, year, git=git),
                    _write,
                )
                new_id = outcome.id
                reserved = bool(getattr(outcome, "pushed", False))
                reason = getattr(outcome, "reason", "") or "shared"
            else:
                new_id = allocate_order_id(mso, order_type, project, year)
                _write(new_id)
                reserved = False
                reason = "local"

    # Read the order back from the file that was actually written, rather than
    # returning the dict we intended to write — PLAN-PLN-MSO-2026-0556 §2.3's
    # rule for the Hub ("returns the ID read back from the file it just
    # wrote"), applied to the whole record. In shared mode the reservation
    # helper owns the write and may re-mint, so the intent and the outcome are
    # not guaranteed to be the same object.
    path = orders_dir / f"{new_id}.json"
    try:
        order_data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        order_data = dict(written) if written else _build(new_id)

    return CreatedOrder(
        order_id=new_id,
        path=path,
        order=order_data,
        reserved=reserved,
        reservation_reason=reason,
    )


# ---------------------------------------------------------------------------
# edit_order
# ---------------------------------------------------------------------------

def edit_order(
    mso: Path,
    order_id: str,
    updates: Dict[str, Any],
    *,
    edited_by: str = "cli",
) -> EditedOrder:
    """Apply *updates* to a not-yet-in-flight order and return what changed.

    Only the fields in :data:`EDITABLE_FIELDS` may be set, and only while the
    order's status is in :data:`EDITABLE_STATUSES` — an order a crew is
    running, or one already terminal, is refused with
    :class:`OrderEditRefused` (HTTP 409). This is the server-side half of the
    Hub ``OrderDrawer``'s locked-status rule: the client disables the form, but
    the rule that MATTERS is this one, since a client check is a courtesy and
    not a guarantee.

    Role codes in *updates* are normalised exactly as on create, so an edit can
    never reintroduce the legacy/canonical mix this module exists to close.

    When the edit leaves ``targetRole`` outside the resolved ``roleSequence``
    and the caller did not state a ``targetRole``, it is re-anchored to the
    sequence's first role — validated through :func:`normalise_role`, the same
    normaliser creation uses, so a non-role token sitting in an on-disk
    ``roleSequence`` is refused with the valid set named rather than written
    into ``targetRole`` (BUG-MSO-2026-0742). A re-anchor is reported on
    :attr:`EditedOrder.reanchored_role`; every other edit leaves ``targetRole``
    alone.
    """
    from maestro.identity.gate import require_capability

    require_capability("order.create", workspace=Path(mso).parent)

    mso = Path(mso)
    unknown = sorted(set(updates or {}) - EDITABLE_FIELDS)
    if unknown:
        raise OrderValidationError(
            f"Field(s) not editable: {', '.join(unknown)} — editable fields are "
            f"{', '.join(sorted(EDITABLE_FIELDS))}"
        )

    path = find_order_file(mso, order_id)
    if path is None:
        raise OrderNotFound(order_id)
    try:
        order = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise OrderEditRefused(order_id, f"Cannot read {path}: {exc}")

    current_status = (order.get("status") or "").upper()
    if current_status not in EDITABLE_STATUSES:
        raise OrderEditRefused(
            order_id,
            f"Order {order_id} is {current_status or 'UNKNOWN'} — only "
            f"{', '.join(sorted(EDITABLE_STATUSES))} orders can be edited.",
            f"A stranded order can be reopened first: mso order retry {order_id}",
        )

    resolved: Dict[str, Any] = {}
    for key, value in (updates or {}).items():
        if key == "title":
            resolved[key] = validate_description(value)
        elif key == "description":
            resolved[key] = str(value or "")
        elif key == "priority":
            resolved[key] = validate_priority(
                value, default=default_priority_for(order.get("type", "")))
        elif key == "roleSequence":
            resolved[key] = normalise_role_sequence(value)
        elif key == "targetRole":
            resolved[key] = normalise_role(value)
        elif key == "acceptanceCriteria":
            resolved[key] = _normalise_acceptance_criteria(value)
        elif key == "dependsOn":
            resolved[key] = _normalise_id_list(value, "dependsOn")
        elif key == "status":
            new_status = str(value or "").strip().upper()
            if new_status not in EDITABLE_STATUSES:
                raise OrderValidationError(
                    f"Cannot set status to '{value}' — an edit may only move an "
                    f"order between {', '.join(sorted(EDITABLE_STATUSES))}. "
                    "Dispatch and completion own every other transition."
                )
            resolved[key] = new_status
        elif key == "timeoutMinutes":
            try:
                minutes = int(value)
            except (TypeError, ValueError):
                raise OrderValidationError("timeoutMinutes must be an integer")
            if minutes <= 0:
                raise OrderValidationError("timeoutMinutes must be positive")
            resolved[key] = minutes
        else:
            resolved[key] = value

    # targetRole must stay inside roleSequence after the edit — a targetRole
    # outside its own sequence is the shape that strands an order at the v8.2
    # role-sequence gate.
    #
    # When the caller narrowed the SEQUENCE and left targetRole alone, the
    # right answer is to re-anchor targetRole rather than refuse: the order has
    # not started (EDITABLE_STATUSES guarantees that), so its start role is
    # derivable from the new sequence and nothing is being second-guessed.
    # Refusing that ordinary edit, or letting it through to strand later, are
    # both worse. An EXPLICIT targetRole outside the sequence is still refused
    # — there the caller stated an intention that cannot be honoured.
    final_sequence = resolved.get("roleSequence", order.get("roleSequence") or [])
    final_role = resolved.get("targetRole", order.get("targetRole") or "")
    reanchored = ""
    if final_sequence and final_role:
        try:
            final_role_c = normalise_role(final_role)
        except OrderValidationError:
            # The ON-DISK targetRole is not a dispatchable role at all, which is
            # "absent from the sequence" in the strongest sense — it re-anchors
            # like any other absent role rather than being left in place to
            # strand at the role-sequence gate. An EXPLICIT bad targetRole never
            # reaches here: `resolved["targetRole"]` was normalised in the loop
            # above and would already have raised (BUG-MSO-2026-0742).
            final_role_c = ""
        # A pre-existing order may carry legacy codes; compare canonically so an
        # untouched legacy order is not refused for a mix it already had.
        canonical_seq = [canonical_role(r) for r in final_sequence]
        if not final_role_c or final_role_c not in canonical_seq:
            if "targetRole" in resolved:
                raise OrderValidationError(
                    f"targetRole '{final_role}' is not in roleSequence "
                    f"{list(final_sequence)} — the order would never be dispatched"
                )
            # BUG-MSO-2026-0742: the re-anchor candidate comes off DISK, so —
            # unlike create's, which is always a `normalise_role_sequence`
            # output — it has never been validated. `gates.canonical_role`
            # deliberately passes an unknown code through uppercased rather than
            # exploding, so writing `canonical_seq[0]` unvalidated puts a
            # NON-ROLE into targetRole. That is the BUG-MSO-2026-0714 class
            # re-opened on the edit path, and it is reachable from a title-only
            # PATCH (no targetRole in `updates`, so the refusal above is
            # skipped). Validate through the SAME normaliser creation uses, and
            # refuse — naming the valid set — rather than write.
            try:
                reanchored = normalise_role(
                    canonical_seq[0], field_name="roleSequence entry")
            except OrderValidationError as exc:
                raise OrderValidationError(
                    f"Cannot re-anchor targetRole for {order_id}: its "
                    f"roleSequence {list(final_sequence)} starts with a token "
                    f"that is not a dispatchable role, so there is no valid "
                    f"role to anchor to. {exc}. Correct roleSequence in the "
                    f"same edit."
                )
            resolved["targetRole"] = reanchored

    changed = [k for k, v in resolved.items() if order.get(k) != v]
    order.update(resolved)
    if changed:
        order["editedBy"] = edited_by
        order["editedAt"] = datetime.now(timezone.utc).isoformat()

    with workspace_scope(mso):
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(order, indent=2), encoding="utf-8")
        tmp.replace(path)

    return EditedOrder(
        order_id=order_id,
        path=path,
        order=order,
        changed_fields=changed,
        reanchored_role=reanchored,
    )
