"""maestro/core/release.py — PLAN-PLN-MSO-2026-0747 Order 6 (FTR-MSO-2026-0763).

D4: the release chain is deliberately **out of REL's automatic scope** — it
spans several merged voyages, contains its own Captain-approved PR, and ends
in an irreversible tag push that triggers publication. This module gives REL
(and the Captain) a read-only report of whether a release is ready
(:func:`run_preflight`), and a Captain-invoked helper that performs the
mechanical version bump and opens the release PR, then stops
(:func:`cut_release`) — never running ``git tag``, ``git push --tags``,
``gh release create``, ``twine upload`` or ``npm publish``. Those remain text
for a human to run, exactly as ``CLAUDE.md``'s release-chain step 3 describes.

Neither function is reachable from a crew's ``roleSequence`` — REL.md's
``must_not`` items 6-8 (merge/tag/publish) apply regardless, and
``mso release cut`` is documented as Captain-invoked, never crew-invoked.
"""

from __future__ import annotations

import glob as _glob
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from maestro.core.proc import run_hidden

__all__ = [
    "PUBLISHED_WHEEL_REFRESH",
    "Finding",
    "PreflightResult",
    "ReleaseError",
    "ReleaseCutError",
    "find_release_repo_root",
    "read_versions",
    "run_preflight",
    "cut_release",
]

# The corrected refresh command (DOC-MSO-2026-0717 / CLAUDE.md Phase 3b) — an
# editable/repo-tree `pip install .` ships an EMPTY licence keyring
# (`maestro/licence/keys.py`'s public-mirror constraint), so the remedy is
# always the published wheel, never `pip install .`.
PUBLISHED_WHEEL_REFRESH = (
    'pip install --force-reinstall --no-deps "maestro=={version}" '
    "--extra-index-url https://maestrodevs.github.io/simple/\n"
    "mso licence revalidate"
)

# Files CLAUDE.md's release-chain step 3c pins concrete `maestro==<ver>` /
# `maestro-<ver>` references into. Deliberately NOT a broad "Maestro v<ver>"
# scan — CLAUDE.md's ship procedure only ever sed's these exact pin shapes in
# these exact files, and a broader scan would flag unrelated historical
# version mentions (changelogs-within-docs, footers) as false positives.
DOC_PIN_FILES = (
    "docs/QUICKSTART.md",
    "docs/ARCHITECTURE.md",
    "docs/OWNER-GUIDE.md",
    "maestro/docs/QUICKSTART.md",
    "maestro/docs/ARCHITECTURE.md",
    "maestro/docs/OWNER-GUIDE.md",
)

_PIN_RE = re.compile(r"maestro==([0-9]+\.[0-9]+\.[0-9]+)|maestro-([0-9]+\.[0-9]+\.[0-9]+)-")
_INIT_VERSION_RE = re.compile(r'__version__\s*=\s*"([^"]+)"')
_PYPROJECT_VERSION_RE = re.compile(r'(?m)^version\s*=\s*"([^"]+)"')
_INIT_DOCSTRING_VERSION_RE = re.compile(r"^Version:[ \t]*\S+", re.MULTILINE)
_CHANGELOG_HEADER_RE = re.compile(r"^##\s*\[([^\]]+)\]")
_SEMVER_RE = re.compile(r"^\d+\.\d+\.\d+$")


@dataclass
class Finding:
    """One preflight check's result. `ok=True, skipped=True` is how an
    absent named test file reports (PASS is never fabricated for a check
    that did not run — plan §5 D4's explicit requirement)."""

    id: str
    ok: bool
    detail: str
    skipped: bool = False

    def as_dict(self) -> dict:
        return {"id": self.id, "ok": self.ok, "skipped": self.skipped, "detail": self.detail}


@dataclass
class PreflightResult:
    findings: list = field(default_factory=list)

    @property
    def ok(self) -> bool:
        """Overall pass/fail. A skipped finding never counts against the
        result — it is neither a pass nor a failure, just absent evidence."""
        return all(f.ok for f in self.findings if not f.skipped)

    def as_dict(self) -> dict:
        return {"ok": self.ok, "findings": [f.as_dict() for f in self.findings]}


class ReleaseError(Exception):
    """The repo root could not be resolved, or (from `cut_release`) bad
    input or an inconsistent tree — refused before any file is touched or
    any git command is run."""

    def __init__(self, message: str, *, hint: Optional[str] = None) -> None:
        super().__init__(message)
        self.hint = hint


# Kept as the name `cut_release()` itself raises, for callers that only
# expect cut-time failures — `ReleaseCutError is ReleaseError`, not a
# separate hierarchy, so `except ReleaseError` still catches everything.
ReleaseCutError = ReleaseError


def find_release_repo_root(start: "Optional[Path]" = None) -> Path:
    """Walk up from *start* (default: cwd) looking for the Maestro
    framework repo root — recognised by carrying both `pyproject.toml` and
    `maestro/__init__.py` side by side.

    Deliberately NOT `.mso` workspace resolution (`find_workspace_dir`):
    this repo commits its own `.mso/` to every branch as its fleet's
    artefact plane (CLAUDE.md, BUG-MSO-2026-0465), and a crew worktree's
    copy of it is missing `config/`, so the ordinary workspace walk-up
    skips straight past the repo root to the external
    `$MAESTRO_ARTEFACT_ROOT` — a directory tree with no `maestro/` package
    or `pyproject.toml` in it at all. Release preflight/cut is about the
    package being released, not the orchestration workspace tracking the
    order that asked for it, so it resolves independently.
    """
    cur = Path(start or Path.cwd()).resolve()
    for candidate in (cur, *cur.parents):
        if (candidate / "pyproject.toml").is_file() and (candidate / "maestro" / "__init__.py").is_file():
            return candidate
    raise ReleaseError(
        "not inside the Maestro framework repo (no pyproject.toml + maestro/__init__.py found)",
        hint="run `mso release preflight`/`cut` from the repo root",
    )


def read_versions(repo_root: Path) -> tuple:
    """Return ``(init_version, pyproject_version)``, either ``None`` if the
    file is missing or the pattern is not found. Read-only."""
    init_version = None
    pyproject_version = None

    init_path = Path(repo_root) / "maestro" / "__init__.py"
    if init_path.is_file():
        m = _INIT_VERSION_RE.search(init_path.read_text(encoding="utf-8"))
        if m:
            init_version = m.group(1)

    pyproject_path = Path(repo_root) / "pyproject.toml"
    if pyproject_path.is_file():
        m = _PYPROJECT_VERSION_RE.search(pyproject_path.read_text(encoding="utf-8"))
        if m:
            pyproject_version = m.group(1)

    return init_version, pyproject_version


def _top_changelog_version(path: Path) -> Optional[str]:
    """The first non-"Unreleased" `## [X.Y.Z]` heading — CHANGELOG.md's most
    recent shipped section."""
    for line in path.read_text(encoding="utf-8").splitlines():
        m = _CHANGELOG_HEADER_RE.match(line.strip())
        if m:
            version = m.group(1)
            if version.strip().lower() == "unreleased":
                continue
            return version
    return None


def _check_version_lockstep(repo_root: Path) -> Finding:
    init_v, pyproject_v = read_versions(repo_root)
    if init_v is None or pyproject_v is None:
        return Finding(
            "version-lockstep", False,
            f"could not read a version (maestro/__init__.py={init_v!r}, "
            f"pyproject.toml={pyproject_v!r})",
        )
    if init_v != pyproject_v:
        return Finding(
            "version-lockstep", False,
            f"maestro/__init__.py __version__={init_v!r} disagrees with "
            f"pyproject.toml version={pyproject_v!r}",
        )
    changelog_path = Path(repo_root) / "CHANGELOG.md"
    if not changelog_path.is_file():
        return Finding("version-lockstep", False, "CHANGELOG.md not found")
    top = _top_changelog_version(changelog_path)
    if top != init_v:
        return Finding(
            "version-lockstep", False,
            f"CHANGELOG.md's top shipped section is {top!r}, expected {init_v!r}",
        )
    return Finding(
        "version-lockstep", True,
        f"{init_v} consistent across maestro/__init__.py, pyproject.toml, CHANGELOG.md",
    )


def _check_doc_pins(repo_root: Path, current_version: str) -> Finding:
    stale = []
    for rel in DOC_PIN_FILES:
        p = Path(repo_root) / rel
        if not p.is_file():
            continue
        text = p.read_text(encoding="utf-8")
        for m in _PIN_RE.finditer(text):
            pinned = m.group(1) or m.group(2)
            if pinned and pinned != current_version:
                stale.append(f"{rel}: {m.group(0)!r} (expected {current_version})")
    if stale:
        return Finding("doc-pins", False, "stale version pin(s): " + "; ".join(stale))
    return Finding(
        "doc-pins", True,
        "no stale maestro==<version> / maestro-<version>- pins found",
    )


def _run_pytest_file(repo_root: Path, rel_path: str, check_id: str) -> Finding:
    """Run one named test file. A test file that does not exist reports
    SKIPPED — never a pass, per this order's explicit acceptance criterion."""
    full = Path(repo_root) / rel_path
    if not full.is_file():
        return Finding(check_id, True, f"{rel_path} not present", skipped=True)
    try:
        proc = run_hidden(
            [sys.executable, "-m", "pytest", rel_path, "-q"],
            cwd=str(repo_root), capture_output=True, text=True, timeout=600,
        )
    except Exception as exc:  # pragma: no cover - defensive
        return Finding(check_id, False, f"failed to run pytest: {exc}")
    ok = proc.returncode == 0
    if ok:
        return Finding(check_id, True, f"{rel_path} passed")
    tail = "\n".join((proc.stdout + proc.stderr).splitlines()[-30:])
    return Finding(check_id, False, f"{rel_path} failed (exit {proc.returncode}):\n{tail}")


def _check_build_and_twine(repo_root: Path) -> Finding:
    """`python -m build` then `python -m twine check dist/*`. Neither
    mutates a tracked source file — build output lands under `dist/`/`build/`,
    which are gitignored, so this satisfies the "never mutates" AC (that AC
    names `__init__.py`/`pyproject.toml`/`CHANGELOG.md` and mutating git/gh
    invocations specifically)."""
    try:
        build_proc = run_hidden(
            [sys.executable, "-m", "build"],
            cwd=str(repo_root), capture_output=True, text=True, timeout=900,
        )
    except Exception as exc:  # pragma: no cover - defensive
        return Finding("build", False, f"python -m build failed to run: {exc}")
    if build_proc.returncode != 0:
        tail = "\n".join((build_proc.stdout + build_proc.stderr).splitlines()[-30:])
        return Finding("build", False, f"python -m build exited {build_proc.returncode}:\n{tail}")

    dist_files = sorted(_glob.glob(str(Path(repo_root) / "dist" / "*")))
    if not dist_files:
        return Finding("build", False, "python -m build produced no dist/ artifacts")
    try:
        twine_proc = run_hidden(
            [sys.executable, "-m", "twine", "check", *dist_files],
            cwd=str(repo_root), capture_output=True, text=True, timeout=120,
        )
    except Exception as exc:  # pragma: no cover - defensive
        return Finding("build", False, f"twine check failed to run: {exc}")
    if twine_proc.returncode != 0:
        tail = "\n".join((twine_proc.stdout + twine_proc.stderr).splitlines()[-30:])
        return Finding("build", False, f"twine check exited {twine_proc.returncode}:\n{tail}")
    return Finding("build", True, f"build + twine check passed ({len(dist_files)} artifact(s))")


def _installed_maestro_dir() -> Optional[Path]:
    try:
        import maestro as _maestro_pkg  # noqa: PLC0415
    except Exception:
        return None
    try:
        return Path(_maestro_pkg.__file__).resolve().parent
    except Exception:
        return None


def _installed_inside_git_worktree() -> bool:
    """Whether the CURRENTLY INSTALLED (imported) `maestro` package resolves
    inside a git working tree — an editable/repo-tree install, whose licence
    keyring is always empty (CLAUDE.md Phase 3c). Read-only (`git rev-parse`
    performs no mutation); never raises."""
    d = _installed_maestro_dir()
    if d is None:
        return False
    try:
        proc = run_hidden(
            ["git", "-C", str(d), "rev-parse", "--is-inside-work-tree"],
            capture_output=True, text=True, timeout=10,
        )
    except Exception:
        return False
    return proc.returncode == 0 and proc.stdout.strip() == "true"


def _check_keyring_trap(current_version: str) -> Finding:
    """Always `ok=True` — this is a WARNING, not a blocking finding (D4:
    "warn if the installed maestro resolves inside a git working tree"). When
    it fires, the message names the published-wheel refresh, never
    `pip install .` (this order's explicit acceptance criterion)."""
    if _installed_inside_git_worktree():
        return Finding(
            "keyring-trap", True,
            "WARNING: the installed maestro package resolves inside a git "
            "working tree (editable/repo-tree install) — its licence keyring "
            "is always empty (CLAUDE.md Phase 3c). Refresh with the "
            "published wheel; a repo-tree install is never enough:\n"
            + PUBLISHED_WHEEL_REFRESH.format(version=current_version),
        )
    return Finding(
        "keyring-trap", True,
        "installed maestro package does not resolve inside a git working tree",
    )


def run_preflight(repo_root: Path, *, skip_build: bool = False) -> PreflightResult:
    """Read-only release-readiness report. Never writes `__init__.py`,
    `pyproject.toml`, or `CHANGELOG.md`, and never runs a mutating git/gh
    command — every check here is a read (file reads, `git rev-parse
    --is-inside-work-tree`, `pytest`, `python -m build` + `twine check`,
    which write only to the gitignored `dist/`/`build/` directories).

    `skip_build` exists for callers (tests, a fast `--json` glance) that do
    not want to pay for a real `python -m build` — it is not exposed as a
    CLI flag; the CLI always runs the full report.
    """
    repo_root = Path(repo_root)
    init_v, pyproject_v = read_versions(repo_root)
    current_version = init_v or pyproject_v or "0.0.0"

    findings = [
        _check_version_lockstep(repo_root),
        _check_doc_pins(repo_root, current_version),
        _run_pytest_file(repo_root, "tests/test_pypi_readme_public_safe.py", "pypi-readme-safe"),
        _run_pytest_file(repo_root, "tests/test_docs_model_names_current.py", "docs-model-names"),
    ]
    if not skip_build:
        findings.append(_check_build_and_twine(repo_root))
    findings.append(_check_keyring_trap(current_version))

    return PreflightResult(findings=findings)


def _bump_version_files(repo_root: Path, old_version: str, new_version: str) -> list:
    """Write the new version into `maestro/__init__.py` and
    `pyproject.toml`. The only file-mutating step in this module — reachable
    only from `cut_release()`, never from `run_preflight()`."""
    changed = []

    init_path = Path(repo_root) / "maestro" / "__init__.py"
    text = init_path.read_text(encoding="utf-8")
    new_text = _INIT_VERSION_RE.sub(f'__version__ = "{new_version}"', text, count=1)
    new_text = _INIT_DOCSTRING_VERSION_RE.sub(f"Version: {new_version}", new_text, count=1)
    if new_text != text:
        init_path.write_text(new_text, encoding="utf-8")
        changed.append(str(init_path))

    pyproject_path = Path(repo_root) / "pyproject.toml"
    text = pyproject_path.read_text(encoding="utf-8")
    new_text = _PYPROJECT_VERSION_RE.sub(f'version = "{new_version}"', text, count=1)
    if new_text != text:
        pyproject_path.write_text(new_text, encoding="utf-8")
        changed.append(str(pyproject_path))

    return changed


def _resolve_scm(repo_root: Path):
    """Best-effort `resolve("scm")`. Returns `None` on any failure — a
    provider resolution problem must never crash `cut_release()`, it just
    means the PR-open step falls back to printed text."""
    try:
        from maestro.providers import resolve_explain  # noqa: PLC0415
        resolved = resolve_explain("scm", workspace=repo_root)
    except Exception:
        return None
    return resolved.provider if resolved.available else None


def cut_release(repo_root: Path, version: str, *, dry_run: bool = True) -> dict:
    """Bump the version files and (best-effort) open the release PR through
    `resolve("scm")`, then STOP — returning the remaining chain (branch push
    if not already done, PR review/merge, tag, publish) as printable TEXT,
    never executed.

    Captain-invoked only (per PLAN-PLN-MSO-2026-0747 §5 D4); no
    `roleSequence` dispatches this. Never builds a `git tag`, `git push
    --tags`, `git push origin v*`, `gh release create`, `twine upload`, or
    `npm publish` invocation under any code path — those are always returned
    as text in `remainingCommands`, matching REL.md `must_not` items 7-8.

    `dry_run=True` (the default) performs no writes and no git commands —
    it previews exactly what `dry_run=False` would do. This mirrors the
    `--dry-run` convention `mso voyage reconcile` already uses.
    """
    repo_root = Path(repo_root)
    if not _SEMVER_RE.match(version):
        raise ReleaseCutError(
            f"version {version!r} is not X.Y.Z semver",
            hint="pass a plain semantic version, e.g. 5.14.0",
        )

    init_v, pyproject_v = read_versions(repo_root)
    if init_v is None or pyproject_v is None:
        raise ReleaseCutError(
            "could not read the current version from maestro/__init__.py or pyproject.toml"
        )
    if init_v != pyproject_v:
        raise ReleaseCutError(
            f"tree is already inconsistent: maestro/__init__.py={init_v!r} "
            f"pyproject.toml={pyproject_v!r}",
            hint="run `mso release preflight` first",
        )
    if version == init_v:
        raise ReleaseCutError(f"{version} is already the current version")

    branch = f"release/v{version}"
    changed_files: list = []
    if not dry_run:
        changed_files = _bump_version_files(repo_root, init_v, version)

    pr_info: Optional[dict] = None
    pr_note = None
    if not dry_run:
        scm = _resolve_scm(repo_root)
        create_pr = getattr(scm, "create_pr", None) if scm is not None else None
        if callable(create_pr):
            try:
                result = create_pr(
                    head=branch, base="main",
                    title=f"release: bump {init_v} -> {version}",
                    body=f"Version bump {init_v} -> {version}.",
                    draft=False,
                )
                if getattr(result, "ok", False):
                    pr_info = result.data if isinstance(result.data, dict) else {"raw": result.data}
                else:
                    pr_note = f"{getattr(result, 'status', 'error')}: {getattr(result, 'detail', '')}"
            except Exception as exc:
                pr_note = f"create_pr raised: {exc}"
        else:
            pr_note = (
                "the resolved scm provider does not implement create_pr — "
                "open the release PR by hand with the command below"
            )

    remaining_commands = [
        f"git checkout -b {branch}",
        # The lockstep the bump above does NOT write — each needs a human/LEAD
        # summary or a targeted pin refresh, and preflight fails without them.
        f"# edit CHANGELOG.md: prepend a '## [{version}] — <YYYY-MM-DD>' section, one bullet per shipped FTR/BUG",
        (f"sed -i 's/maestro=={init_v}/maestro=={version}/g; s/maestro-{init_v}/maestro-{version}/g' "
         "docs/QUICKSTART.md docs/ARCHITECTURE.md docs/OWNER-GUIDE.md "
         "maestro/docs/QUICKSTART.md maestro/docs/ARCHITECTURE.md maestro/docs/OWNER-GUIDE.md"),
        f"sed -i 's/Version: {init_v}/Version: {version}/; s/Maestro v{init_v}/Maestro v{version}/' CLAUDE.md",
        "mso release preflight   # must pass version-lockstep before committing",
        "git add maestro/__init__.py pyproject.toml CHANGELOG.md CLAUDE.md docs/ maestro/docs/",
        f'git commit -m "release: bump {init_v} -> {version}"',
        f"git push -u origin {branch}",
        f'gh pr create --title "release: v{version} — ..." --body "..."',
        f"gh pr merge <REL_N> --squash --delete-branch",
        "git checkout main && git pull",
        f"git tag v{version}",
        f"git push origin v{version}",
    ]

    return {
        "version": version,
        "fromVersion": init_v,
        "branch": branch,
        "dryRun": dry_run,
        "filesChanged": changed_files,
        "prCreated": pr_info,
        "prNote": pr_note,
        "remainingCommands": remaining_commands,
        "keyringWarning": _check_keyring_trap(version).detail,
    }
