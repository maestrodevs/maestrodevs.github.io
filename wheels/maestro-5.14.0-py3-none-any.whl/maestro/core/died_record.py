"""A dead daemon leaves a trace (BUG-MSO-2026-0713).

The hole this closes
---------------------
On 2026-09-09 the dispatcher (PID 17140) and the Hub (PID 12908) both died
inside the same 30-second window and **neither left a single byte behind**. Both
were launched with ``stdout=DEVNULL, stderr=DEVNULL``, so the only artefact was
the launcher's own 106-byte banner file. The investigation
(``reports/investigation/INV-BUG-MSO-2026-0713.md`` §4.1) states the consequence
precisely:

    An unhandled exception, a ``MemoryError``, or an external ``taskkill`` all
    leave byte-identical evidence: none.

That is not a gap in diagnosis, it is a gap in *evidence*. §5 names two
competing hypotheses for the deaths and then notes that **nothing distinguishes
them, because a crash leaves no trace** — so the same incident could recur
indefinitely without ever becoming diagnosable.

The discriminating experiment
------------------------------
An exit code separates the hypotheses on the next occurrence with no ambiguity:

* ``0`` — the daemon chose to stop. Not a death.
* a Python traceback plus a non-zero code — an in-process crash. The tail names
  the exception.
* ``1`` / ``0xC000013A`` / a negative signal number with no traceback — the
  process was terminated from outside. Nothing in it ran.

An external kill runs no code inside the victim, so an in-process ``atexit``
hook can never observe it. Only a **separate process that is waiting on the
child** can. That is the supervisor: a tiny wrapper that spawns the real daemon,
captures its stderr, ``wait()``s, and writes the record. The daemon itself also
installs :func:`install_crash_hook` so an in-process crash is captured even if
the wrapper is somehow bypassed — belt and braces, because the two mechanisms
fail in different ways.

Design constraints
-------------------
* **The wrapper must not become the daemon's identity.** ``dispatcher.pid`` is
  written by the dispatcher itself (``os.getpid()``), which the wrapper does not
  change; ``_live_dispatcher_pid()``, the BUG-MSO-2026-0688 duplicate refusal,
  ``mso status``, the Hub aggregator and ``mso doctor``'s heartbeat check all
  keep naming the real dispatcher. The wrapper publishes its child's PID to a
  handshake file purely so the *launcher's banner* can keep printing the
  dispatcher's PID rather than the wrapper's. This is the single highest-risk
  property in the change; it has a dedicated test.
* **One implementation, both surfaces** — the ``dispatcher_heartbeat.py``
  precedent. ``mso status`` and ``mso hub status`` read the same record through
  :func:`read_died`, so they can never disagree about a death.
* **A clean stop must not read as a death.** Records carry ``clean``, and
  :func:`read_died` hides clean records by default: an operator who stopped the
  dispatcher on purpose is not shown a scary banner about it.
* **Best-effort throughout.** A record that cannot be written must never stop a
  daemon from starting, running, or exiting.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

#: Daemon kinds this module records. Kept as an explicit set so a typo produces
#: a file nobody reads rather than silently shadowing a real record.
KINDS = ("dispatcher", "hub")

DEFAULT_STDERR_TAIL_LINES = 50

#: BUG-MSO-2026-0751: the exit code of a daemon that STOPPED SERVING — its
#: listener died while the process kept running, and it exited (or was ended
#: by the supervisor's port watch) so it could be restarted. EX_TEMPFAIL:
#: distinct from uvicorn's startup failure (3) and from a crash (1).
EXIT_STOPPED_SERVING = 75

#: Supervisor port watch (BUG-MSO-2026-0751): probe every N seconds, and treat
#: this many consecutive refusals — after the port has accepted at least once —
#: as a daemon that stopped serving.
SERVE_WATCH_INTERVAL_SECONDS = 20.0
SERVE_WATCH_FAILURES_TO_TRIP = 3

#: How much of a captured stderr stream is kept. A runaway daemon can produce
#: megabytes; the tail is what identifies the death.
_MAX_CAPTURE_BYTES = 2 * 1024 * 1024


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _artefact_root() -> Path:
    from maestro.workspace import get_artefact_root
    return get_artefact_root()


def died_record_path(kind: str, workspace_dir: Optional[Path] = None) -> Path:
    root = Path(workspace_dir) if workspace_dir else _artefact_root()
    return root / "state" / f"died-{kind}.json"


def capture_path(kind: str, workspace_dir: Optional[Path] = None) -> Path:
    """Where the supervisor points the child's stdout+stderr.

    Under ``state/`` (gitignored runtime control plane) alongside the record it
    feeds, for the same reason ``order-ledger.jsonl`` lives there: runtime truth
    no git operation can rewind.
    """
    root = Path(workspace_dir) if workspace_dir else _artefact_root()
    return root / "state" / f"died-{kind}.capture.log"


# ---------------------------------------------------------------------------
# Write / read
# ---------------------------------------------------------------------------

def classify_exit(exit_code: Optional[int], stderr_tail: Optional[List[str]]) -> str:
    """A one-word cause from the evidence alone. Never a guess dressed as a fact.

    ``"clean"`` / ``"crash"`` / ``"terminated"`` / ``"unknown"``. The
    distinction that matters is the last two: a traceback in the tail means the
    daemon's own code raised, and its absence alongside a non-zero code means
    something outside it decided. When there is no exit code at all — the record
    was assembled from a PID file rather than from a ``wait()`` — the honest
    answer is ``"unknown"``, not a plausible-sounding one.
    """
    if exit_code is None:
        return "unknown"
    if exit_code == 0:
        return "clean"
    if exit_code == EXIT_STOPPED_SERVING:
        # Checked before the traceback test: the accept failure that precedes
        # it is itself logged with a traceback, and would read as a crash.
        return "stopped-serving"
    text = "\n".join(stderr_tail or [])
    if "Traceback (most recent call last)" in text:
        return "crash"
    return "terminated"


def write_died(
    kind: str,
    pid: Optional[int],
    exit_code: Optional[int],
    stderr_tail: Optional[List[str]] = None,
    started_at: Optional[str] = None,
    died_at: Optional[str] = None,
    workspace_dir: Optional[Path] = None,
    extra: Optional[Dict[str, Any]] = None,
) -> Optional[Path]:
    """Record a daemon's death. Atomic, best-effort, never raises."""
    try:
        tail = list(stderr_tail or [])
        cause = classify_exit(exit_code, tail)
        record: Dict[str, Any] = {
            "kind": kind,
            "pid": pid,
            "exitCode": exit_code,
            "cause": cause,
            "clean": cause == "clean",
            "startedAt": started_at,
            "diedAt": died_at or _now(),
            "stderrTail": tail,
            "recordedBy": "supervisor",
        }
        if extra:
            record.update(extra)
        path = died_record_path(kind, workspace_dir)
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(record, indent=2), encoding="utf-8")
        os.replace(str(tmp), str(path))
        return path
    except Exception:
        return None


def read_died(kind: str, workspace_dir: Optional[Path] = None,
              include_clean: bool = False) -> Optional[Dict[str, Any]]:
    """The last recorded death for *kind*, or ``None``.

    A CLEAN exit is hidden by default. The record is still written and still on
    disk (it answers "when did I stop it?"), but no surface should present a
    deliberate stop as a death — that is the "a clean stop leaves no misleading
    record" half of this feature. Pass ``include_clean=True`` to see everything.
    """
    try:
        path = died_record_path(kind, workspace_dir)
        if not path.exists():
            return None
        record = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(record, dict):
            return None
        if record.get("clean") and not include_clean:
            return None
        return record
    except Exception:
        return None


def clear_died(kind: str, workspace_dir: Optional[Path] = None) -> None:
    """Forget any previous death for *kind*.

    Called when a new daemon of that kind starts: the record describes the
    PREVIOUS run, and leaving it in place would let a later reader attribute an
    old death to the run that is currently healthy. Same reasoning as
    ``hub/logs.clear_exit_record()``.
    """
    try:
        died_record_path(kind, workspace_dir).unlink()
    except OSError:
        pass
    except Exception:
        pass


def describe_died(record: Optional[Dict[str, Any]]) -> str:
    """One operator-facing line. Empty string for no record."""
    if not record:
        return ""
    cause = record.get("cause") or "unknown"
    pid = record.get("pid")
    code = record.get("exitCode")
    when = record.get("diedAt") or "unknown time"
    kind = record.get("kind") or "daemon"
    if cause == "crash":
        what = "crashed (its own code raised)"
    elif cause == "terminated":
        what = "was terminated from outside (no traceback — nothing in it ran)"
    elif cause == "clean":
        what = "exited cleanly"
    elif cause == "stopped-serving":
        what = "stopped serving (its listener died while the process lived) and was ended so it can be restarted"
    else:
        what = "stopped for an unrecorded reason"
    code_part = f", exit code {code}" if code is not None else ", exit code not observed"
    return f"{kind} PID {pid} {what} at {when}{code_part}"


# ---------------------------------------------------------------------------
# In-process half — captures a crash even with no supervisor
# ---------------------------------------------------------------------------

_CRASH_HOOK_INSTALLED = set()


def install_crash_hook(kind: str, workspace_dir: Optional[Path] = None,
                       started_at: Optional[str] = None) -> None:
    """Have the daemon itself record an in-process death.

    This does NOT replace the supervisor and cannot: an external termination
    runs no code inside this process, so nothing installed here can observe one.
    It is the belt to the supervisor's braces — it covers a daemon launched
    without the wrapper (an operator running the script directly, an older
    launcher), which would otherwise be back to the pre-0713 silence.

    Records are marked ``recordedBy: "in-process"`` so a reader can tell which
    mechanism spoke; the supervisor's record, written later, supersedes it.
    """
    if kind in _CRASH_HOOK_INSTALLED:
        return
    _CRASH_HOOK_INSTALLED.add(kind)
    root = Path(workspace_dir) if workspace_dir else None
    start = started_at or _now()

    try:
        import faulthandler
        fh_path = capture_path(kind, root)
        fh_path.parent.mkdir(parents=True, exist_ok=True)
        # Appended, never truncated: a hard interpreter fault (segfault, stack
        # overflow) writes here, and it must not erase what the supervisor is
        # already capturing into the same file.
        faulthandler.enable(file=open(str(fh_path), "a", encoding="utf-8"), all_threads=True)
    except Exception:
        pass

    def _record_exit() -> None:
        try:
            exc = getattr(sys, "last_value", None)
            tail: List[str] = []
            code: Optional[int] = 0
            if exc is not None:
                import traceback
                tail = "".join(
                    traceback.format_exception(type(exc), exc, exc.__traceback__)
                ).splitlines()[-DEFAULT_STDERR_TAIL_LINES:]
                code = 1
            write_died(
                kind, os.getpid(), code, tail,
                started_at=start, workspace_dir=root,
                extra={"recordedBy": "in-process"},
            )
        except Exception:
            pass

    try:
        import atexit
        atexit.register(_record_exit)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Supervisor
# ---------------------------------------------------------------------------

def _tail_lines(path: Path, limit: int = DEFAULT_STDERR_TAIL_LINES) -> List[str]:
    try:
        if not path.is_file():
            return []
        size = path.stat().st_size
        with open(path, "rb") as fh:
            if size > _MAX_CAPTURE_BYTES:
                fh.seek(size - _MAX_CAPTURE_BYTES)
            data = fh.read()
        text = data.decode("utf-8", errors="replace")
        return [ln for ln in text.splitlines() if ln.strip()][-limit:]
    except Exception:
        return []


def write_handshake(path: Path, supervisor_pid: int, child_pid: int,
                    started_at: str) -> None:
    """Publish the CHILD's pid so the launcher's banner keeps naming the daemon.

    Written before the supervisor blocks in ``wait()`` so a launcher polling for
    it sees it within milliseconds of the spawn.
    """
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_text(json.dumps({
            "supervisorPid": supervisor_pid,
            "childPid": child_pid,
            "startedAt": started_at,
        }), encoding="utf-8")
        os.replace(str(tmp), str(path))
    except Exception:
        pass


def read_handshake(path: Path) -> Optional[Dict[str, Any]]:
    try:
        raw = json.loads(Path(path).read_text(encoding="utf-8"))
        return raw if isinstance(raw, dict) else None
    except Exception:
        return None


def await_child_pid(path: Path, timeout_seconds: float = 5.0) -> Optional[int]:
    """Poll the handshake for the supervised child's PID.

    Returns ``None`` on timeout rather than a fabricated number — a launcher
    that cannot learn the real PID must say so, never print the wrapper's and
    let an operator ``taskkill`` the wrong process.
    """
    import time
    deadline = time.monotonic() + max(0.0, timeout_seconds)
    while True:
        rec = read_handshake(path)
        pid = (rec or {}).get("childPid")
        if isinstance(pid, int) and pid > 0:
            return pid
        if time.monotonic() >= deadline:
            return None
        time.sleep(0.05)


def stopped_serving_record_path(kind: str, workspace_dir: Optional[Path] = None) -> Path:
    root = Path(workspace_dir) if workspace_dir else _artefact_root()
    return root / "state" / f"stopped-serving-{kind}.json"


def write_stopped_serving(kind: str, pid: Optional[int], port: int, failures: int,
                          workspace_dir: Optional[Path] = None) -> Optional[Path]:
    """Record the moment a live daemon was found no longer serving its port.

    A separate record from :func:`write_died` because it describes an event
    the process SURVIVED — the zombie state BUG-MSO-2026-0751 found, which an
    exit-only record could never show. Atomic, best-effort, never raises.
    """
    try:
        path = stopped_serving_record_path(kind, workspace_dir)
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps({
            "kind": kind,
            "pid": pid,
            "port": port,
            "at": _now(),
            "consecutiveRefusals": failures,
            "detectedBy": "supervisor",
        }, indent=2), encoding="utf-8")
        os.replace(str(tmp), str(path))
        return path
    except Exception:
        return None


def read_stopped_serving(kind: str, workspace_dir: Optional[Path] = None) -> Optional[Dict[str, Any]]:
    try:
        raw = json.loads(stopped_serving_record_path(kind, workspace_dir).read_text(encoding="utf-8"))
        return raw if isinstance(raw, dict) else None
    except Exception:
        return None


def port_accepts(port: int, timeout: float = 5.0) -> bool:
    """Does 127.0.0.1:*port* accept a TCP connection? A closed listener refuses at once."""
    import socket
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=timeout):
            return True
    except OSError:
        return False


def wait_watching_port(proc: "subprocess.Popen", port: int, *,
                       interval_seconds: float = SERVE_WATCH_INTERVAL_SECONDS,
                       failures_to_trip: int = SERVE_WATCH_FAILURES_TO_TRIP,
                       probe=None,
                       on_stopped_serving=None) -> "tuple[int, Optional[str]]":
    """``proc.wait()``, but end a child that stops serving *port* (BUG-MSO-2026-0751).

    The daemon's own guard is the first line; this is the backstop for a daemon
    too wedged to run it. Never trips before the port has accepted once, so a
    slow start is not a death. On a trip, *on_stopped_serving(failures)* is
    called, the child is terminated, and ``(exit_code, stopped_at)`` is
    returned; ``stopped_at`` is ``None`` when the child exited by itself.
    """
    probe = probe or (lambda: port_accepts(port))
    served = False
    failures = 0
    while True:
        try:
            return proc.wait(timeout=interval_seconds), None
        except subprocess.TimeoutExpired:
            pass
        try:
            ok = bool(probe())
        except Exception:
            ok = False
        if ok:
            served, failures = True, 0
            continue
        if not served:
            continue
        failures += 1
        if failures < max(1, failures_to_trip):
            continue
        stopped_at = _now()
        if on_stopped_serving is not None:
            try:
                on_stopped_serving(failures)
            except Exception:
                pass
        try:
            proc.terminate()
        except Exception:
            pass
        try:
            return proc.wait(timeout=30), stopped_at
        except subprocess.TimeoutExpired:
            try:
                proc.kill()
            except Exception:
                pass
            return proc.wait(), stopped_at


def supervise(child_cmd: List[str], kind: str, workspace_dir: Optional[Path] = None,
              handshake: Optional[Path] = None, cwd: Optional[str] = None,
              env: Optional[Dict[str, str]] = None,
              probe_port: Optional[int] = None) -> int:
    """Run *child_cmd* to completion and record how it ended. Returns its code.

    Runs in its own process, which is the entire point: it is still alive when
    the daemon is not, so it can observe an exit the daemon itself could never
    report.

    BUG-MSO-2026-0751: with *probe_port*, it also watches that the child keeps
    SERVING the port — a daemon whose listener died but whose process lives on
    never exits, so an exit-only supervisor recorded nothing. Such a child is
    recorded (``stopped-serving-{kind}.json``) and ended, and its death record
    carries ``cause: "stopped-serving"``.
    """
    started_at = _now()
    cap = capture_path(kind, workspace_dir)
    try:
        cap.parent.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass

    clear_died(kind, workspace_dir)

    try:
        capture_fh = open(str(cap), "w", encoding="utf-8", errors="replace")
    except Exception:
        capture_fh = None

    try:
        from maestro.core.proc import popen_hidden
        proc = popen_hidden(
            child_cmd,
            cwd=cwd,
            env=env,
            stdin=subprocess.DEVNULL,
            stdout=capture_fh if capture_fh is not None else subprocess.DEVNULL,
            stderr=subprocess.STDOUT if capture_fh is not None else subprocess.DEVNULL,
            close_fds=True,
        )
    except Exception as exc:
        if capture_fh is not None:
            try:
                capture_fh.close()
            except Exception:
                pass
        write_died(kind, None, None, [f"supervisor could not start the child: {exc!r}"],
                   started_at=started_at, workspace_dir=workspace_dir,
                   extra={"cause": "spawn-failed"})
        return 127

    if handshake is not None:
        write_handshake(handshake, os.getpid(), proc.pid, started_at)

    if capture_fh is not None:
        # The child holds its own duplicate; this copy must not stay open or the
        # tail read below (and any rotation) sees a file still locked on Windows.
        try:
            capture_fh.close()
        except Exception:
            pass

    stopped_at: Optional[str] = None
    try:
        if probe_port:
            code, stopped_at = wait_watching_port(
                proc, int(probe_port),
                on_stopped_serving=lambda failures: write_stopped_serving(
                    kind, proc.pid, int(probe_port), failures, workspace_dir),
            )
        else:
            code = proc.wait()
    except KeyboardInterrupt:
        code = proc.poll() if proc.poll() is not None else 130

    extra: Dict[str, Any] = {"capturePath": str(cap), "supervisorPid": os.getpid()}
    if stopped_at is not None:
        extra.update({"cause": "stopped-serving", "clean": False, "stoppedServingAt": stopped_at})
    write_died(
        kind, proc.pid, code, _tail_lines(cap),
        started_at=started_at, workspace_dir=workspace_dir,
        extra=extra,
    )
    return code if isinstance(code, int) else 1


def _main(argv: List[str]) -> int:
    """``python -m maestro.core.died_record supervise --kind K [...] -- cmd...``"""
    import argparse

    parser = argparse.ArgumentParser(prog="maestro.core.died_record")
    sub = parser.add_subparsers(dest="command", required=True)
    sup = sub.add_parser("supervise")
    sup.add_argument("--kind", required=True, choices=list(KINDS))
    sup.add_argument("--workspace", default=None)
    sup.add_argument("--handshake", default=None)
    sup.add_argument("--cwd", default=None)
    sup.add_argument("--probe-port", type=int, default=None)
    sup.add_argument("child", nargs=argparse.REMAINDER)

    args = parser.parse_args(argv)
    child = list(args.child or [])
    if child and child[0] == "--":
        child = child[1:]
    if not child:
        print("supervise: no child command given", file=sys.stderr)
        return 2

    workspace = Path(args.workspace) if args.workspace else None
    handshake = Path(args.handshake) if args.handshake else None
    return supervise(child, args.kind, workspace_dir=workspace,
                     handshake=handshake, cwd=args.cwd, probe_port=args.probe_port)


if __name__ == "__main__":  # pragma: no cover - process entry point
    raise SystemExit(_main(sys.argv[1:]))
