# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Orders that look filed and can never be selected (BUG-MSO-2026-0741).

The shape
---------
``PROPOSED`` is offered as a creatable status (CLI ``mso order create
--status``, the Hub's ``OrderDefaults.statuses``) with no requirement that the
order carry a ``dependsOn``. Nothing releases such an order:

* ``fleet_runner.scan_all_queues()`` only ever dispatches ``status ==
  "PENDING"``, so a PROPOSED order is invisible to dispatch by construction.
* ``fleet_runner.promote_ready_dependents()`` — the general BUG-MSO-2026-0499
  auto-release — ``continue``s on an empty ``dependsOn`` *on purpose*: "a
  PROPOSED order with no dependsOn is gated by the human plan-review flow ...
  and must not be auto-released here".
* ``plan_dependents.promote_proposed_dependents()`` — the plan-review flow that
  comment defers to — promotes only orders that name the approved plan order
  **in their own dependsOn**. An empty list can never match.

So the order sits in a queue forever, looking filed, and every automatic route
that could move it has a documented reason not to. This is the same class as
BUG-MSO-2026-0714 (a role name nothing rejected) and BUG-MSO-2026-0499 (a
dependent nothing promoted): a creation path producing an order the dispatcher
can never select, with no signal to the operator.

The one legitimate dependency-free hold
---------------------------------------
Charts Phase 2. ``chart_scheduler._release_node()`` releases a node's order out
of the SAME ``_AUTO_RELEASE_STATUSES = {PROPOSED, HELD}`` set, gated on the
chart's in-edges rather than on ``dependsOn`` — so for an order named by an
ACTIVE chart, dependency-free PROPOSED is exactly right, and a blanket ban
would break it. :func:`chart_gated_order_ids` is how the two are told apart.

Why the refusal is on CREATE and the report is on everything else
-----------------------------------------------------------------
At creation the order id has just been minted, so **nothing can reference it
yet** — not a chart node (charts name orders by id), not another order's
``dependsOn``. A dependency-free PROPOSED order is therefore *provably*
undispatchable at the moment of creation, and refusing it there costs no
legitimate workflow. Once the order exists that proof no longer holds: an
operator edits it to PROPOSED precisely *because* a chart now covers it. So
:func:`create_refusal` is a hard refusal at the one point where the answer is
certain, and :func:`undispatchable_reason` is the report — ``mso doctor``'s
``orders.undispatchable-proposed`` check and the Hub's ``dep_held`` attention
tag — everywhere it is not.

Pure except for :func:`chart_gated_order_ids`, which reads ``charts/`` and
never raises.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, Optional, Set

#: Statuses that mean "held, waiting for something to release me back to
#: PENDING". A verbatim mirror of ``fleet_runner._AUTO_RELEASE_STATUSES`` —
#: re-declared rather than imported so ``mso doctor``'s check and the Hub's
#: poller keep their existing freedom from a ``fleet_runner`` import (the same
#: deliberate, documented duplication ``patrol/checks/orders.py`` already makes
#: for ``_QUEUE_SUBDIRS``). Keep in sync if that set changes.
RELEASE_GATED_STATUSES = frozenset({"PROPOSED", "HELD"})


def order_depends_on(data: Dict[str, Any]) -> list:
    """The order's declared dependencies, under either spelling.

    Live artefacts carry both ``dependsOn`` and the older ``dependencies``;
    every reader in the engine accepts either, so this one does too rather
    than reporting an order gated by the legacy key as dependency-free.
    """
    deps = data.get("dependsOn")
    if deps is None:
        deps = data.get("dependencies")
    return deps if isinstance(deps, list) else []


def is_release_gated_without_deps(data: Dict[str, Any]) -> bool:
    """True when *data* is held at a release-gated status with no dependency
    that could ever satisfy it. Pure; never raises."""
    status = str(data.get("status") or "").strip().upper()
    if status not in RELEASE_GATED_STATUSES:
        return False
    return not order_depends_on(data)


def chart_gated_order_ids(artefact_root: Path) -> Set[str]:
    """Every order id named by a node of an **ACTIVE** chart on this plane.

    Best-effort: a workspace with no ``charts/`` directory — which is every
    workspace that has not opted into Charts Phase 2 — pays a single
    ``is_dir()`` and gets an empty set back, and a malformed chart is skipped
    rather than raised (``chart_schema.charts_for_voyage``'s own rule: one bad
    chart must never take down a scan of the rest).

    PAUSED and COMPLETE charts are deliberately excluded: neither releases a
    frontier node, so an order held only by one of those is as stuck as an
    order held by nothing.
    """
    try:
        charts_dir = Path(artefact_root) / "charts"
        if not charts_dir.is_dir():
            return set()
        from maestro.core.chart_schema import load_chart

        gated: Set[str] = set()
        for path in sorted(charts_dir.glob("*.json")):
            try:
                spec = load_chart(path)
            except Exception:
                continue
            if str(spec.status or "").upper() != "ACTIVE":
                continue
            for node in spec.nodes.values():
                if node.order:
                    gated.add(str(node.order))
        return gated
    except Exception:
        return set()


def undispatchable_reason(
    data: Dict[str, Any],
    *,
    chart_gated_ids: Optional[Set[str]] = None,
) -> Optional[str]:
    """Why this order can never be selected, or ``None`` if it can.

    *chart_gated_ids* is the pre-read result of :func:`chart_gated_order_ids`
    — passed in rather than read here so a caller scanning N orders reads
    ``charts/`` once. Omitted, chart coverage is not considered (correct for
    the create path, where the id is too new to be in any chart).
    """
    if not is_release_gated_without_deps(data):
        return None
    order_id = str(data.get("orderId") or data.get("id") or "")
    if chart_gated_ids and order_id in chart_gated_ids:
        return None
    status = str(data.get("status") or "").strip().upper()
    return (
        f"{status} with an empty dependsOn and no ACTIVE chart node — nothing "
        "can release it. The dispatcher only ever selects PENDING orders; "
        "promote_ready_dependents() skips an order with no dependsOn, and the "
        "plan-review promotion only releases orders that name the approved "
        "plan in their own dependsOn. Give it the dependency it is waiting on, "
        "or set it to PENDING (to dispatch it) or BACKLOG (to park it)."
    )


def create_refusal(status: str, dependencies: Any) -> Optional[str]:
    """The refusal message for :func:`maestro.core.order_create.create_order`,
    or ``None`` when the requested creation is fine.

    Separate from :func:`undispatchable_reason` because the create path knows
    something the report path does not: the id is being minted right now, so
    the chart carve-out cannot apply, and the remedy is phrased as flags the
    operator can retype rather than as a repair.
    """
    value = str(status or "").strip().upper()
    if value not in RELEASE_GATED_STATUSES or dependencies:
        return None
    return (
        f"Cannot create an order at {value} with no dependsOn — nothing would "
        "ever release it. The dispatcher only selects PENDING orders, and "
        f"{value} is released either by its dependencies completing "
        "(promote_ready_dependents), by approving the plan order it names as a "
        "dependency (mso review approve), or by an ACTIVE chart node — and a "
        "just-created order is in none of those, because no chart and no other "
        "order can reference an id that did not exist until now. Pass "
        "--depends-on <ORDER-ID>, or create it at PENDING (to dispatch it now) "
        "or BACKLOG (to park it)."
    )
