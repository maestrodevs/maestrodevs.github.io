"""Per-crew run history — the previous run's evidence survives the next dispatch
(BUG-MSO-2026-0713).

Why this exists
----------------
On 2026-09-09 the dispatcher and the Hub died inside the same 30-second window
and nothing recorded why. The one place that DID hold the evidence — what each
crew was executing at 22:12:36-22:13:06 — was ``.mso/crews/crewN/``, and it was
readable at 23:05 and gone at 23:12, because the 23:09 restart re-dispatched all
four slots and every crew-state file is written with truncating semantics. The
investigation (``reports/investigation/INV-BUG-MSO-2026-0713.md`` §4.2) measured
five separate sites that destroy it:

===========================================  ==========================================
Site                                          What it destroyed
===========================================  ==========================================
``fleet_runner._reset_crew_tracking()``       ``activity.jsonl``, ``activity.txt``,
                                              ``files_modified.json``, ``progress.md``
``fleet_runner`` crew.log open (mode ``w``)   ``crew.log``
``crew.init_progress()``                      the four hook files
``crew.cleanup_crew()``                       the four hook files, again
``crew.py``'s per-iteration output write      ``output_01.txt`` (a re-dispatch
                                              restarts the iteration counter at 1)
===========================================  ==========================================

**A system that loses the last run's output on the next dispatch cannot be
debugged after any restart** — and a restart is exactly what an operator does
first when something has gone wrong. So the retention has to be automatic and it
has to happen at dispatch time, not on an operator remembering to copy files out
before restarting.

What it does
-------------
:func:`rotate_crew_run` MOVES a crew slot's current run files into
``crews/crew{N}/history/{orderId}-{role}-{iter}-{YYYYmmdd-HHMMSS}/`` immediately
before the slot is reused. A move rather than a copy, so retention costs no
extra disk on the hot path and no I/O proportional to file size. The one
exception is :data:`COPY_ONLY_FILES` — ``state.json``, which other code polls
concurrently and which must therefore stay exactly where it is.

Two properties keep it from becoming a liability of its own:

* **It never blocks a dispatch.** Every operation is wrapped; any failure means
  the fleet proceeds exactly as it did before this module existed (the previous
  run's files are then overwritten as they always were). Losing forensics is bad;
  refusing to dispatch because forensics could not be filed would be worse.
* **It is bounded.** ``completion.crewHistory.maxRuns`` (default 10) and
  ``maxTotalMb`` (default 200) are enforced per crew slot after every rotation,
  pruning oldest-first, so an unattended fleet cannot fill a disk with history.

Rotation is also **self-limiting**: it only fires when at least one *evidence*
file (``output_*.txt``, ``activity.jsonl``, ``crew.log``) has real content. A
slot that has just been reset — where the hook files exist but are empty
templates — rotates nothing and creates no directory, so the several call sites
in the dispatch path do not each produce an empty history entry.
"""

from __future__ import annotations

import json
import os
import shutil
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

HISTORY_DIRNAME = "history"

DEFAULT_MAX_RUNS = 10
DEFAULT_MAX_TOTAL_MB = 200

#: Files whose presence-with-content justifies creating a history entry. These
#: are the forensics INV §4.2 measured as destroyed — what the crew was told and
#: what it did. Everything in :data:`CARRIED_FILES` rides along once one of these
#: has triggered a rotation, but none of them triggers one on its own (a
#: freshly-reset ``files_modified.json`` holding ``[]`` is not evidence).
EVIDENCE_GLOBS = ("output_*.txt", "activity.jsonl", "crew.log")

#: Everything else worth keeping alongside the evidence.
CARRIED_FILES = (
    "activity.txt",
    "files_modified.json",
    "notifications.log",
    "progress.md",
    "ralph-state.md",
    "state.json",
)

#: Retained by COPY rather than by move. ``state.json`` is polled concurrently
#: by ``worktrees._crew_worktree_occupied()``, the monitor, ``mso status`` and
#: the Hub aggregator, and it is what :func:`_identity_from_state` labels the
#: history directory from. Rotation must never be the reason one of those reads
#: a slot differently than it would have before this module existed — so the
#: live file stays exactly where it is and the history gets a copy. It is a few
#: hundred bytes; the certainty is worth more than the disk.
COPY_ONLY_FILES = frozenset({"state.json"})

#: Byte contents that mean "freshly reset template", not "evidence".
_EMPTY_CONTENTS = frozenset({b"", b"[]", b"[]\n", b"[]\r\n"})


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

def _load_limits(workspace_dir: Optional[Path] = None) -> tuple:
    """``(max_runs, max_total_bytes)`` from ``completion.crewHistory``.

    A missing block, a missing key, or a non-positive/non-numeric value each
    fall back to the documented default rather than disabling retention — an
    unreadable config must not silently turn the forensics off.
    """
    max_runs = DEFAULT_MAX_RUNS
    max_mb = DEFAULT_MAX_TOTAL_MB
    try:
        root = workspace_dir or _artefact_root()
        cfg_path = Path(root) / "config" / "workspace.json"
        if cfg_path.exists():
            cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
            block = (cfg.get("completion") or {}).get("crewHistory") or {}
            raw_runs = block.get("maxRuns")
            raw_mb = block.get("maxTotalMb")
            if isinstance(raw_runs, (int, float)) and raw_runs > 0:
                max_runs = int(raw_runs)
            if isinstance(raw_mb, (int, float)) and raw_mb > 0:
                max_mb = float(raw_mb)
    except Exception:
        pass
    return max_runs, int(max_mb * 1024 * 1024)


def _artefact_root() -> Path:
    from maestro.workspace import get_artefact_root
    return get_artefact_root()


def _crew_dir(crew_number: int, workspace_dir: Optional[Path] = None) -> Path:
    root = workspace_dir or _artefact_root()
    return Path(root) / "crews" / f"crew{crew_number}"


def history_dir(crew_number: int, workspace_dir: Optional[Path] = None) -> Path:
    """The retained-runs directory for one crew slot."""
    return _crew_dir(crew_number, workspace_dir) / HISTORY_DIRNAME


# ---------------------------------------------------------------------------
# Identity
# ---------------------------------------------------------------------------

def _sanitize(part: Any, fallback: str) -> str:
    text = str(part or "").strip()
    if not text:
        return fallback
    safe = "".join(ch if (ch.isalnum() or ch in "-_.") else "-" for ch in text)
    return safe.strip("-") or fallback


def _identity_from_state(crew_dir: Path) -> Dict[str, Any]:
    """Best-effort ``orderId`` / ``role`` / ``iteration`` from the slot's own
    ``state.json`` — the run being rotated is the one that WROTE that file, so
    its identity is the right label for the directory, not the incoming order's."""
    try:
        raw = json.loads((crew_dir / "state.json").read_text(encoding="utf-8"))
        if isinstance(raw, dict):
            return raw
    except Exception:
        pass
    return {}


def run_dir_name(order_id: Optional[str], role: Optional[str],
                 iteration: Optional[Any], when: Optional[datetime] = None) -> str:
    stamp = (when or datetime.now()).strftime("%Y%m%d-%H%M%S")
    try:
        iter_part = f"{int(iteration):02d}"
    except (TypeError, ValueError):
        iter_part = _sanitize(iteration, "00")
    return (
        f"{_sanitize(order_id, 'unknown-order')}-"
        f"{_sanitize(role, 'ROLE')}-"
        f"{iter_part}-{stamp}"
    )


# ---------------------------------------------------------------------------
# Rotation
# ---------------------------------------------------------------------------

def _is_substantive(path: Path) -> bool:
    try:
        if not path.is_file():
            return False
        if path.stat().st_size == 0:
            return False
        with open(path, "rb") as fh:
            head = fh.read(8)
        if len(head) <= 4 and head in _EMPTY_CONTENTS:
            return False
        return True
    except OSError:
        return False


def _evidence_files(crew_dir: Path) -> List[Path]:
    found: List[Path] = []
    for pattern in EVIDENCE_GLOBS:
        try:
            if "*" in pattern:
                found.extend(sorted(crew_dir.glob(pattern)))
            else:
                found.append(crew_dir / pattern)
        except OSError:
            continue
    return [p for p in found if _is_substantive(p)]


def _relocate(src: Path, dest: Path) -> bool:
    """Move *src* to *dest*, falling back to copy-then-unlink and then to a bare
    copy. On Windows a file another process still holds open (a crew.log whose
    writer has not fully exited) cannot be moved; keeping a copy is strictly
    better than losing the run."""
    try:
        shutil.move(str(src), str(dest))
        return True
    except Exception:
        pass
    try:
        shutil.copy2(str(src), str(dest))
    except Exception:
        return False
    try:
        src.unlink()
    except Exception:
        pass  # copy already succeeded — the retained evidence is what matters
    return True


def _copy_only(src: Path, dest: Path) -> bool:
    """Retain a file WITHOUT removing the original (see :data:`COPY_ONLY_FILES`)."""
    try:
        shutil.copy2(str(src), str(dest))
        return True
    except Exception:
        return False


def rotate_crew_run(
    crew_number: int,
    order_id: Optional[str] = None,
    role: Optional[str] = None,
    iteration: Optional[Any] = None,
    workspace_dir: Optional[Path] = None,
    include_crew_log: bool = True,
) -> Optional[Path]:
    """Retain the crew slot's CURRENT run before it is overwritten.

    Returns the history directory that was created, or ``None`` when there was
    nothing substantive to retain (or anything at all went wrong — this function
    never raises, by contract: see the module docstring).

    Identity for the directory name is taken from the slot's own ``state.json``
    when the caller does not supply it, because the run being rotated is the
    departing one, not the arriving one. A caller mid-dispatch that passes the
    INCOMING order's id would mislabel the outgoing run.

    *include_crew_log* exists for the one caller that runs while ``crew.log`` is
    still the live stdout target of a process it did not spawn.
    """
    try:
        crew_dir = _crew_dir(crew_number, workspace_dir)
        if not crew_dir.is_dir():
            return None

        evidence = _evidence_files(crew_dir)
        if not include_crew_log:
            evidence = [p for p in evidence if p.name != "crew.log"]
        if not evidence:
            return None  # nothing worth a directory

        state = _identity_from_state(crew_dir)
        order_id = order_id or state.get("orderId") or state.get("order_id")
        role = role or state.get("role")
        if iteration is None:
            iteration = state.get("iteration", state.get("currentIteration"))

        dest = history_dir(crew_number, workspace_dir) / run_dir_name(order_id, role, iteration)
        suffix = 1
        while dest.exists():
            suffix += 1
            dest = dest.with_name(f"{dest.name}-{suffix}")
        dest.mkdir(parents=True, exist_ok=True)

        moved = 0
        names: List[str] = [p.name for p in evidence]
        for extra in CARRIED_FILES:
            if extra not in names and (crew_dir / extra).is_file():
                names.append(extra)
        for name in names:
            src = crew_dir / name
            if not src.is_file():
                continue
            if name in COPY_ONLY_FILES:
                if _copy_only(src, dest / name):
                    moved += 1
            elif _relocate(src, dest / name):
                moved += 1

        if moved == 0:
            try:
                dest.rmdir()
            except OSError:
                pass
            return None

        _write_manifest(dest, crew_number, order_id, role, iteration, moved)
        prune_history(crew_number, workspace_dir=workspace_dir)
        return dest
    except Exception:
        return None  # fail open — retention must never block a dispatch


def _write_manifest(dest: Path, crew_number: int, order_id: Optional[str],
                    role: Optional[str], iteration: Optional[Any], files: int) -> None:
    try:
        (dest / "run.json").write_text(json.dumps({
            "crew": crew_number,
            "orderId": order_id,
            "role": role,
            "iteration": iteration,
            "retainedAt": datetime.now().isoformat(),
            "files": files,
        }, indent=2), encoding="utf-8")
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Pruning
# ---------------------------------------------------------------------------

def _dir_size(path: Path) -> int:
    total = 0
    try:
        for entry in path.rglob("*"):
            try:
                if entry.is_file():
                    total += entry.stat().st_size
            except OSError:
                continue
    except OSError:
        pass
    return total


def list_runs(crew_number: int, workspace_dir: Optional[Path] = None) -> List[Path]:
    """Retained run directories for a slot, OLDEST FIRST.

    Ordered by mtime rather than by name so a clock change or a de-duplication
    suffix cannot invert the pruning order.
    """
    try:
        base = history_dir(crew_number, workspace_dir)
        if not base.is_dir():
            return []
        runs = [p for p in base.iterdir() if p.is_dir()]
        runs.sort(key=lambda p: (_mtime(p), p.name))
        return runs
    except OSError:
        return []


def _mtime(path: Path) -> float:
    try:
        return path.stat().st_mtime
    except OSError:
        return 0.0


def prune_history(crew_number: int, workspace_dir: Optional[Path] = None) -> List[str]:
    """Enforce both caps, oldest-first. Returns the names removed. Never raises.

    The count cap is applied first and the size cap after it, and BOTH are hard:
    a single enormous run is removed by the size cap even when the count cap is
    satisfied. At least one run is always kept — a history that prunes itself to
    empty would defeat the purpose of having it.
    """
    removed: List[str] = []
    try:
        max_runs, max_bytes = _load_limits(workspace_dir)
        runs = list_runs(crew_number, workspace_dir)

        while len(runs) > max_runs:
            victim = runs.pop(0)
            if _remove_tree(victim):
                removed.append(victim.name)

        total = sum(_dir_size(r) for r in runs)
        while total > max_bytes and len(runs) > 1:
            victim = runs.pop(0)
            size = _dir_size(victim)
            if _remove_tree(victim):
                removed.append(victim.name)
                total -= size
            else:
                break
    except Exception:
        pass
    return removed


def _remove_tree(path: Path) -> bool:
    try:
        shutil.rmtree(str(path), ignore_errors=False)
        return True
    except Exception:
        try:
            shutil.rmtree(str(path), ignore_errors=True)
            return not path.exists()
        except Exception:
            return False


# ---------------------------------------------------------------------------
# Read side — ONE implementation, every surface
# ---------------------------------------------------------------------------

def latest_run_dir(crew_number: int, workspace_dir: Optional[Path] = None) -> Optional[Path]:
    """The most recently retained run for a slot, or ``None``.

    This is the read side ``mso doctor``'s crew check and the Hub's crew drawer
    both call, following the ``dispatcher_heartbeat`` precedent: one
    implementation so the two surfaces can never disagree about where the
    previous run's output is.
    """
    runs = list_runs(crew_number, workspace_dir)
    return runs[-1] if runs else None


def latest_run_summary(crew_number: int,
                       workspace_dir: Optional[Path] = None) -> Optional[Dict[str, Any]]:
    """``{path, orderId, role, iteration, retainedAt, files}`` for the most
    recent retained run, or ``None``. Reads ``run.json`` when present and falls
    back to parsing the directory name, so a manifest that failed to write does
    not make the run invisible."""
    run = latest_run_dir(crew_number, workspace_dir)
    if run is None:
        return None
    summary: Dict[str, Any] = {"path": str(run), "name": run.name}
    try:
        manifest = json.loads((run / "run.json").read_text(encoding="utf-8"))
        if isinstance(manifest, dict):
            summary.update(manifest)
    except Exception:
        parts = run.name.rsplit("-", 3)
        if len(parts) == 4:
            summary.setdefault("orderId", parts[0])
            summary.setdefault("role", parts[1])
            summary.setdefault("iteration", parts[2])
    try:
        summary["outputs"] = sorted(p.name for p in run.iterdir() if p.is_file())
    except OSError:
        summary["outputs"] = []
    return summary
