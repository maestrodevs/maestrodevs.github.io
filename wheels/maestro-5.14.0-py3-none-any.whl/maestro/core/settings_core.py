"""maestro/core/settings_core.py — the ONE writer of Maestro settings.

PLAN-PLN-MSO-2026-0792 §5 / Order 3 (FTR-MSO-2026-0799). ``mso settings``, the
Hub's workspace + device settings routes (Order 5a) and the setup wizard (Wave C)
all call the functions here; none of them touches a settings file itself.

**Why this exists (§1.7).** The Hub's config drawer was built as a *form* before
there was a *schema*: nothing recorded which keys exist, where they live, or which
engine code reads them, so fields shipped that nothing honoured (S4/S5/S7). The
class fix is a registry — :data:`SETTINGS` — in which every key names the engine
function that honours it (``SettingSpec.reader``). A key with no reader cannot be
registered, so it cannot be rendered. ``tests/test_settings_registry_readers.py``
imports every reader.

**Precedence, one rule for every key** (§5): env var (when the key declares one)
> signed policy bundle (enterprise) > ``workspace.json`` > device
``settings.json`` > built-in default. A key's ``scope`` decides which of the two
files may hold it (``device`` / ``workspace`` / ``both``). Two storages are
delegated rather than re-implemented, because their resolvers already exist and
must not move:

* ``persona`` writes the persona resolver's OWN files
  (``<product root>/.maestro/config/persona.json`` and
  ``<MAESTRO_HOME>/config/persona.json``) in the pointer form ``{"id": ...}``.
  ``maestro/personas/resolver.py`` is not changed.
* ``models.<ROLE>.{model,contextWindow,effort}`` writes
  ``<artefact root>/config/role-models.json`` (preserving ``_comment`` and every
  unknown key). The VALUE reported by :func:`effective` comes from
  ``crew.resolve_*_for`` itself — this module classifies the source, it never
  re-implements resolution. Note that role-models.json's own precedence is
  workspace file > ``MAESTRO_MODEL_<ROLE>`` env > role overlay > built-in, which
  is the resolver's (FTR-0129), not the generic rule above.
* ``providers.<kind>`` is delegated whole to ``maestro/providers/config.py`` — the
  one writer of the ``providers`` block. There is no second writer here.

**Shared-core contract** (``order_retry.py``): explicit ``mso: Path`` (the
``.mso`` artefact dir; ``None`` means "device only"), no CWD resolution, typed
exceptions (``SettingValidationError`` 400, ``SettingLockedError`` 409,
``CapabilityDenied`` 403), no printing, no ``sys.exit``, every workspace mutation
inside ``order_retry.workspace_scope(mso)``, and the ``settings.write`` identity
capability enforced here rather than per surface. No web-framework import — the
Hub maps these exceptions to HTTP.
"""

from __future__ import annotations

import importlib
import json
import os
import re
import threading
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterator, Optional

from maestro.core_constants import (
    DEFAULT_ROLE_CONTEXT_WINDOW,
    DEFAULT_ROLE_EFFORT,
    DEFAULT_ROLE_MODEL_IDS,
    MODEL_ID_LABELS,
    VALID_CONTEXT_WINDOWS,
    VALID_EFFORTS_CREW,
    get_model_display_name,
)
from maestro.core.dispatch_settings import (
    DEFAULT_MAX_CREWS,
    DEFAULT_MAX_TURNS,
    DEFAULT_TIMEOUT_MINUTES,
)
from maestro.providers import PROVIDER_KINDS

__all__ = [
    "SCOPE_DEVICE", "SCOPE_WORKSPACE", "SCOPE_BOTH",
    "SettingsError", "UnknownSettingError", "SettingValidationError",
    "SettingLockedError", "SettingStorageError",
    "SettingSpec", "Effective", "SETTINGS",
    "get_spec", "list_specs", "resolve_reader",
    "model_vocabulary", "model_generation",
    "effective", "effective_all", "set_setting", "unset_setting", "parse_value",
    "device_settings_path",
]

SCOPE_DEVICE = "device"
SCOPE_WORKSPACE = "workspace"
SCOPE_BOTH = "both"

SOURCE_ENV = "env"
SOURCE_BUNDLE = "bundle"
SOURCE_WORKSPACE = "workspace"
SOURCE_DEVICE = "device"
SOURCE_OVERLAY = "overlay"
SOURCE_DEFAULT = "default"

# Storage kinds (see module docstring).
_STORE_JSON = "json"
_STORE_PERSONA = "persona"
_STORE_ROLE_MODELS = "role-models"
_STORE_PROVIDERS = "providers"

# The model a new pin defaults to, and the first entry of the vocabulary
# (Captain, Revision 2: "We should be using opus 5 not opus 4.8").
PREFERRED_MODEL_ID = "claude-opus-5"


# ---------------------------------------------------------------------------
# Typed errors
# ---------------------------------------------------------------------------

class SettingsError(Exception):
    """Base for every refusal this module raises. ``http_status`` is the
    status a Hub route should map it to; the CLI exits 1."""

    http_status: int = 400
    hint: Optional[str] = None

    def __init__(self, message: str, hint: Optional[str] = None) -> None:
        super().__init__(message)
        if hint is not None:
            self.hint = hint


class UnknownSettingError(SettingsError):
    hint = "Run `mso settings list` to see every registered key."


class SettingValidationError(SettingsError):
    pass


class SettingLockedError(SettingsError):
    http_status = 409
    hint = "A signed policy bundle pins this setting; it cannot be changed here."


class SettingStorageError(SettingsError):
    """The file on disk is in a state this writer refuses to overwrite."""

    http_status = 409


# ---------------------------------------------------------------------------
# The registry
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class SettingSpec:
    key: str
    scope: str                      # device | workspace | both
    type: str                       # bool | int | str | enum | model | object
    default: Any
    reader: str                     # dotted path of the engine function that honours it
    description: str = ""
    storage: str = _STORE_JSON
    env: Optional[str] = None
    choices: tuple = ()
    minimum: Optional[int] = None
    nullable: bool = False
    tier: str = "pro"               # D2: settings writes are Pro/Team/Enterprise
    restart_required: bool = False

    def to_dict(self) -> dict:
        return {
            "key": self.key,
            "scope": self.scope,
            "type": self.type,
            "default": self.default,
            "reader": self.reader,
            "description": self.description,
            "storage": self.storage,
            "env": self.env,
            "choices": list(_choices(self)),
            "minimum": self.minimum,
            "nullable": self.nullable,
            "tier": self.tier,
            "restartRequired": self.restart_required,
        }


_FR = "maestro.core.fleet_runner"
_COMPLETION_READER = f"{_FR}.load_completion_config"
_LEAD_READER = "maestro.lead.agent.load_lead_config"
_DISPATCH_READER = "maestro.core.dispatch_settings.resolve_dispatch_limits"


def _model_specs() -> list[SettingSpec]:
    specs: list[SettingSpec] = []
    for role in DEFAULT_ROLE_MODEL_IDS:
        specs.append(SettingSpec(
            f"models.{role}.model", SCOPE_WORKSPACE, "model", DEFAULT_ROLE_MODEL_IDS[role],
            "maestro.core.crew.resolve_model_for", storage=_STORE_ROLE_MODELS,
            description=f"Claude model {role} crews run on.",
        ))
        specs.append(SettingSpec(
            f"models.{role}.contextWindow", SCOPE_WORKSPACE, "enum",
            DEFAULT_ROLE_CONTEXT_WINDOW.get(role, "standard"),
            "maestro.core.crew.resolve_context_window_for", storage=_STORE_ROLE_MODELS,
            choices=tuple(sorted(VALID_CONTEXT_WINDOWS)),
            description=f"Context-window tier for {role} crews.",
        ))
        specs.append(SettingSpec(
            f"models.{role}.effort", SCOPE_WORKSPACE, "enum", DEFAULT_ROLE_EFFORT.get(role, "high"),
            "maestro.core.crew.resolve_effort_for", storage=_STORE_ROLE_MODELS,
            choices=_CREW_EFFORTS,
            description=f"Reasoning effort for {role} crews.",
        ))
    return specs


# Crew dispatch accepts these (max/ultracode are interactive-LEAD only), in ladder order.
_CREW_EFFORTS = tuple(e for e in ("low", "medium", "high", "xhigh", "max") if e in VALID_EFFORTS_CREW)


SETTINGS: tuple[SettingSpec, ...] = tuple([
    SettingSpec(
        "spawnMonitor", SCOPE_DEVICE, "bool", True, f"{_FR}._spawn_monitor_enabled",
        env="MAESTRO_SPAWN_MONITOR",
        description="Open the terminal Maestro Monitor window when a dispatcher starts "
                    "(FTR-0406; a device property per FTR-0635).",
    ),
    SettingSpec(
        "persona", SCOPE_BOTH, "enum", "default", "maestro.personas.resolver.resolve",
        storage=_STORE_PERSONA, env="MAESTRO_PERSONA", restart_required=True,
        description="Persona vocabulary for CLI, Hub and crew prompts.",
    ),
    SettingSpec(
        "defaultGitHubOrg", SCOPE_WORKSPACE, "str", None, f"{_FR}._load_workspace_org",
        nullable=True, description="GitHub organisation voyage branches and PRs are created in.",
    ),
    SettingSpec(
        "verifyCommand", SCOPE_WORKSPACE, "str", "", f"{_FR}.load_verify_config",
        description="Command run in the crew worktree before a convergence push; empty disables "
                    "the local verify gate.",
    ),
    SettingSpec(
        "verifyTimeoutMinutes", SCOPE_WORKSPACE, "int", 20, f"{_FR}.load_verify_config",
        minimum=1, description="Wall-clock cap for verifyCommand.",
    ),
    SettingSpec(
        "completion.voyagePr.draft", SCOPE_WORKSPACE, "bool", True, _COMPLETION_READER,
        description="Open the voyage PR as a draft so intermediate pushes do not run CI.",
    ),
    SettingSpec(
        "completion.voyagePr.promoteOnFinalisation", SCOPE_WORKSPACE, "bool", True,
        _COMPLETION_READER,
        description="Mark the voyage PR ready for review when its last order completes.",
    ),
    SettingSpec(
        "completion.voyageRel.enabled", SCOPE_WORKSPACE, "bool", False, _COMPLETION_READER,
        description="File one voyage-level REL order when a voyage's last order completes.",
    ),
    SettingSpec(
        "completion.idleWatchdog.enabled", SCOPE_WORKSPACE, "bool", True, _COMPLETION_READER,
        restart_required=True,
        description="Act when every crew is idle and no work is pending.",
    ),
    SettingSpec(
        "completion.idleWatchdog.idleMinutes", SCOPE_WORKSPACE, "int", 30, _COMPLETION_READER,
        minimum=1, restart_required=True,
        description="Minutes of all-crews-idle before the watchdog acts.",
    ),
    SettingSpec(
        "completion.idleWatchdog.action", SCOPE_WORKSPACE, "enum", "cleanup", _COMPLETION_READER,
        choices=("cleanup", "warn", "none"), restart_required=True,
        description="cleanup = clear stale state and exit; warn = log IDLE_TIMEOUT; none.",
    ),
    SettingSpec(
        "lead.enabled", SCOPE_WORKSPACE, "bool", True, _LEAD_READER,
        description="Whether the resident LEAD agent is enabled for this workspace.",
    ),
    SettingSpec(
        "lead.tokenCeiling.dailyTokens", SCOPE_WORKSPACE, "int", 200_000, _LEAD_READER,
        minimum=1,
        description="Daily token ceiling for the LEAD daemon (an abnormal backstop, D8).",
    ),
    # BUG-MSO-2026-0800 (Order 4): honoured by `mso dispatch` and the Hub's Dispatch
    # button. An explicit CLI flag still wins; the community crew cap applies last.
    SettingSpec(
        "dispatch.maxCrews", SCOPE_BOTH, "int", DEFAULT_MAX_CREWS, _DISPATCH_READER,
        minimum=1, restart_required=True,
        description="Concurrent crews a dispatcher launches (community tier is capped at 2).",
    ),
    SettingSpec(
        "dispatch.maxTurns", SCOPE_BOTH, "int", DEFAULT_MAX_TURNS, _DISPATCH_READER,
        minimum=1, restart_required=True,
        description="Claude turn cap per crew iteration.",
    ),
    SettingSpec(
        "dispatch.timeoutMinutes", SCOPE_BOTH, "int", DEFAULT_TIMEOUT_MINUTES, _DISPATCH_READER,
        minimum=1, restart_required=True,
        description="Wall-clock ceiling per crew iteration, in minutes (the activity watchdog "
                    "is the primary hang control).",
    ),
    *[
        SettingSpec(
            f"providers.{kind}", SCOPE_WORKSPACE, "object", None,
            "maestro.providers.resolve_explain", storage=_STORE_PROVIDERS, nullable=True,
            description=f"SDLC {kind} provider — written by maestro/providers/config.py.",
        )
        for kind in PROVIDER_KINDS
    ],
    *_model_specs(),
])

_SPECS_BY_KEY: dict[str, SettingSpec] = {s.key: s for s in SETTINGS}


def get_spec(key: str) -> SettingSpec:
    spec = _SPECS_BY_KEY.get(key)
    if spec is None:
        raise UnknownSettingError(f"unknown setting: {key!r}")
    return spec


def list_specs(*, scope: Optional[str] = None) -> tuple[SettingSpec, ...]:
    """Every registered spec, or only those a *scope* file may hold."""
    if scope is None:
        return SETTINGS
    if scope == SCOPE_DEVICE:
        return tuple(s for s in SETTINGS if s.scope in (SCOPE_DEVICE, SCOPE_BOTH))
    if scope == SCOPE_WORKSPACE:
        return tuple(s for s in SETTINGS if s.scope in (SCOPE_WORKSPACE, SCOPE_BOTH))
    raise SettingValidationError(f"unknown scope: {scope!r} (expected device or workspace)")


def resolve_reader(spec: SettingSpec) -> Callable[..., Any]:
    """Import and return the engine function a spec declares as its reader."""
    module_name, _, attr = spec.reader.rpartition(".")
    return getattr(importlib.import_module(module_name), attr)


# ---------------------------------------------------------------------------
# Model vocabulary (Revision 2) — derived from core_constants, never hand-typed
# ---------------------------------------------------------------------------

_MODEL_VERSION_RE = re.compile(r"^claude-[a-z]+-(\d+)(?:-(\d{1,2}))?(?:-\d{8})?$")


def _model_version(model_id: str) -> tuple[int, int]:
    m = _MODEL_VERSION_RE.match(model_id)
    if not m:
        return (0, 0)
    return (int(m.group(1)), int(m.group(2) or 0))


def _generations() -> dict[str, str]:
    """``{model_id: "current"|"previous"}`` — the newest version of each family
    (Opus/Sonnet/Haiku/Fable, from ``MODEL_ID_LABELS``) is current."""
    newest: dict[str, tuple[int, int]] = {}
    for model_id, family in MODEL_ID_LABELS.items():
        newest[family] = max(newest.get(family, (0, 0)), _model_version(model_id))
    return {
        model_id: "current" if _model_version(model_id) == newest[family] else "previous"
        for model_id, family in MODEL_ID_LABELS.items()
    }


def model_generation(model_id: str) -> Optional[str]:
    """``"current"``, ``"previous"``, or ``None`` for an unsupported id."""
    return _generations().get((model_id or "").removesuffix("[1m]"))


def model_vocabulary() -> list[dict]:
    """``[{id, label, generation}]`` — ``claude-opus-5`` first, then every other
    current-generation id, then the previous generation. Only ``current`` ids
    may be chosen as a new pin (:func:`set_setting` refuses the rest)."""
    gens = _generations()
    ids = list(MODEL_ID_LABELS)
    ordered = (
        [i for i in ids if i == PREFERRED_MODEL_ID and gens[i] == "current"]
        + [i for i in ids if gens[i] == "current" and i != PREFERRED_MODEL_ID]
        + [i for i in ids if gens[i] == "previous"]
    )
    return [
        {"id": i, "label": get_model_display_name(i), "generation": gens[i]}
        for i in ordered
    ]


def _choices(spec: SettingSpec) -> tuple:
    if spec.type == "model":
        return tuple(m["id"] for m in model_vocabulary() if m["generation"] == "current")
    if spec.storage == _STORE_PERSONA:
        try:
            from maestro.personas.loader import builtin_names
            return tuple(builtin_names())
        except Exception:
            return ()
    return spec.choices


# ---------------------------------------------------------------------------
# Effective value
# ---------------------------------------------------------------------------

@dataclass
class Effective:
    key: str
    value: Any
    source: str
    source_detail: str
    default: Any
    scope: str
    type: str
    locked: bool = False
    locked_reason: Optional[str] = None
    restart_required: bool = False
    extra: dict = field(default_factory=dict)

    def __iter__(self) -> Iterator[Any]:
        """``value, source = effective(mso, key)`` — §5's documented shape."""
        yield self.value
        yield self.source

    def to_dict(self) -> dict:
        out = {
            "key": self.key,
            "value": self.value,
            "source": self.source,
            "sourceDetail": self.source_detail,
            "default": self.default,
            "scope": self.scope,
            "type": self.type,
            "locked": self.locked,
            "lockedReason": self.locked_reason,
            "restartRequired": self.restart_required,
        }
        out.update(self.extra)
        return out


_MISSING = object()


def device_settings_path() -> Path:
    from maestro.workspace import get_maestro_home

    return get_maestro_home() / "config" / "settings.json"


def _workspace_json_path(mso: Path) -> Path:
    return Path(mso) / "config" / "workspace.json"


def _role_models_path(mso: Path) -> Path:
    return Path(mso) / "config" / "role-models.json"


def _product_root(mso: Path) -> Path:
    """The directory the persona resolver's walk-up reaches from a dispatcher
    cwd: the product repo. Embedded mode: ``mso.parent``. Solo/shared: the
    configured product repo, falling back to ``mso.parent`` if unresolvable."""
    mso = Path(mso)
    try:
        from maestro.workspace import _artefacts_block, get_product_repo, workspace_override

        if _artefacts_block(mso).get("mode") in ("solo", "shared"):
            with workspace_override(mso):
                return Path(get_product_repo())
    except Exception:
        pass
    return mso.parent


def _persona_path(mso: Optional[Path], scope: str) -> Path:
    from maestro.workspace import MAESTRO_HOME_DIR_NAME, get_maestro_home

    if scope == SCOPE_DEVICE:
        return get_maestro_home() / "config" / "persona.json"
    return _product_root(mso) / MAESTRO_HOME_DIR_NAME / "config" / "persona.json"


def _read_json_lenient(path: Path) -> dict:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def _read_json_for_write(path: Path) -> dict:
    """A present-but-unreadable file RAISES rather than degrading to ``{}`` —
    otherwise a write would replace every other key with just ours (the PR
    #427 finding against providers/config.py)."""
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise SettingStorageError(
            f"{path} exists but could not be read ({exc}) - refusing to write over it.",
            hint="Fix or remove the file, then retry.",
        ) from exc
    if not isinstance(data, dict):
        raise SettingStorageError(f"{path} does not hold a JSON object - refusing to write over it.")
    return data


def _atomic_write_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f".{path.name}.{os.getpid()}.{threading.get_ident()}.tmp")
    tmp.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    os.replace(str(tmp), str(path))


def _dig(data: Any, dotted: str) -> Any:
    node = data
    for part in dotted.split("."):
        if not isinstance(node, dict) or part not in node:
            return _MISSING
        node = node[part]
    return node


def _plant(data: dict, dotted: str, value: Any, path: Path) -> None:
    parts = dotted.split(".")
    node = data
    for part in parts[:-1]:
        child = node.get(part)
        if child is None:
            child = node[part] = {}
        elif not isinstance(child, dict):
            raise SettingStorageError(
                f"{path}: '{part}' holds {type(child).__name__}, not an object - "
                f"refusing to overwrite it to set {dotted}."
            )
        node = child
    node[parts[-1]] = value


def _pluck(data: dict, dotted: str) -> bool:
    """Remove *dotted*; prune parents this removal left empty."""
    parts = dotted.split(".")
    trail: list[tuple[dict, str]] = []
    node: Any = data
    for part in parts[:-1]:
        if not isinstance(node, dict) or not isinstance(node.get(part), dict):
            return False
        trail.append((node, part))
        node = node[part]
    if not isinstance(node, dict) or parts[-1] not in node:
        return False
    del node[parts[-1]]
    for parent, part in reversed(trail):
        if parent[part]:
            break
        del parent[part]
    return True


def _read_persona_file(path: Path) -> tuple[Any, bool]:
    """``(persona id | _MISSING, is_pointer_form)``."""
    if not path.exists():
        return _MISSING, False
    data = _read_json_lenient(path)
    pointer = list(data.keys()) == ["id"]
    pid = data.get("id")
    return (pid if isinstance(pid, str) and pid else _MISSING), pointer


def _bundle_settings(mso: Optional[Path]) -> dict:
    """Settings pinned by the workspace's signed policy bundle, flat by key.

    Same tier and the same already-verified read ``providers._bundle_providers``
    uses: enterprise-gated, ``governance.loader.load_bundles`` fails closed on a
    tampered/unsigned bundle, and any failure means "no bundle tier" — a
    malformed bundle must never silently grant a lock value either.
    """
    if mso is None:
        return {}
    try:
        from maestro import auth

        if not auth.has_tier({"enterprise"}):
            return {}
        from maestro.governance.loader import load_bundles

        load_bundles(Path(mso).parent)
        bundle_path = Path(mso) / "config" / "policy-bundle.json"
        if not bundle_path.exists():
            return {}
        data = json.loads(bundle_path.read_text(encoding="utf-8"))
        settings = data.get("settings") if isinstance(data, dict) else None
        return settings if isinstance(settings, dict) else {}
    except Exception:
        return {}


def _parse_env(spec: SettingSpec, raw: str) -> Any:
    if spec.type == "bool":
        # FTR-0406's rule, preserved verbatim: anything but an explicit "off" is on.
        return raw not in ("0", "false", "False", "no", "off")
    if spec.type == "int":
        try:
            return int(raw)
        except ValueError:
            return raw
    return raw


def _read_scoped(spec: SettingSpec, mso: Optional[Path], scope: str) -> tuple[Any, str]:
    if spec.storage == _STORE_PERSONA:
        path = _persona_path(mso, scope)
        value, _pointer = _read_persona_file(path)
        return value, str(path)
    path = device_settings_path() if scope == SCOPE_DEVICE else _workspace_json_path(mso)
    return _dig(_read_json_lenient(path), spec.key), str(path)


def _needs_workspace(spec: SettingSpec) -> SettingValidationError:
    return SettingValidationError(
        f"{spec.key} is a workspace setting and needs a workspace",
        hint="Run inside a workspace (or pass --project); drop --device.",
    )


def effective(mso: Optional[Path], key: str) -> Effective:
    """The value the engine will honour for *key*, and where it came from.

    *mso* is the workspace's ``.mso`` artefact dir, or ``None`` to resolve a
    device/both key against the device file alone.
    """
    spec = get_spec(key)
    mso = Path(mso) if mso is not None else None
    if spec.storage == _STORE_PROVIDERS:
        return _effective_provider(mso, spec)
    if spec.storage == _STORE_ROLE_MODELS:
        return _effective_model(mso, spec)
    if spec.scope == SCOPE_WORKSPACE and mso is None:
        raise _needs_workspace(spec)

    bundle = _bundle_settings(mso)
    locked = key in bundle
    bundle_path = str(Path(mso) / "config" / "policy-bundle.json") if mso is not None else ""
    lock_reason = f"pinned by the signed policy bundle ({bundle_path})" if locked else None

    def _out(value: Any, source: str, detail: str) -> Effective:
        return Effective(
            key=key, value=value, source=source, source_detail=detail,
            default=spec.default, scope=spec.scope, type=spec.type,
            locked=locked, locked_reason=lock_reason,
            restart_required=spec.restart_required,
        )

    if spec.env:
        raw = os.environ.get(spec.env, "").strip()
        if raw:
            return _out(_parse_env(spec, raw), SOURCE_ENV, f"${spec.env}")
    if locked:
        return _out(bundle[key], SOURCE_BUNDLE, bundle_path)
    if spec.scope in (SCOPE_WORKSPACE, SCOPE_BOTH) and mso is not None:
        value, detail = _read_scoped(spec, mso, SCOPE_WORKSPACE)
        if value is not _MISSING:
            return _out(value, SOURCE_WORKSPACE, detail)
    if spec.scope in (SCOPE_DEVICE, SCOPE_BOTH):
        value, detail = _read_scoped(spec, None, SCOPE_DEVICE)
        if value is not _MISSING:
            return _out(value, SOURCE_DEVICE, detail)
    return _out(spec.default, SOURCE_DEFAULT, "built-in default")


def _effective_provider(mso: Optional[Path], spec: SettingSpec) -> Effective:
    if mso is None:
        raise _needs_workspace(spec)
    from maestro.providers import config as providers_config

    kind = spec.key.split(".", 1)[1]
    info = providers_config.list_providers(mso.parent)[kind]
    locked_by = info["lockedBy"]
    configured = info["configured"]
    if locked_by:
        value, source, detail = {"id": locked_by}, SOURCE_BUNDLE, "signed policy bundle"
    elif configured is not None:
        value, source, detail = configured, SOURCE_WORKSPACE, str(_workspace_json_path(mso))
    else:
        value, source, detail = None, SOURCE_DEFAULT, "shipped default"
    return Effective(
        key=spec.key, value=value, source=source, source_detail=detail,
        default=spec.default, scope=spec.scope, type=spec.type,
        locked=bool(locked_by),
        locked_reason=(f"locked to '{locked_by}' by a signed policy bundle" if locked_by else None),
        extra={"installed": info["installed"]},
    )


_MODEL_FIELDS = {
    # field: (resolver name, env prefix, overlay attribute)
    "model": ("resolve_model_for", "MAESTRO_MODEL_", "model"),
    "contextWindow": ("resolve_context_window_for", "MAESTRO_CONTEXT_", "context_window"),
    "effort": ("resolve_effort_for", "MAESTRO_EFFORT_", "effort"),
}


def _split_model_key(key: str) -> tuple[str, str]:
    _, role, fld = key.split(".")
    return role, fld


def _stored_model_field(mso: Path, role: str, fld: str) -> Any:
    models = _read_json_lenient(_role_models_path(mso)).get("models")
    entry = models.get(role) if isinstance(models, dict) else None
    if isinstance(entry, dict):
        return entry.get(fld) or _MISSING
    if fld == "model" and isinstance(entry, str) and entry:
        return entry  # legacy string form
    return _MISSING


def _effective_model(mso: Optional[Path], spec: SettingSpec) -> Effective:
    """Value from ``crew.resolve_*_for`` — never re-derived here — plus the
    source it came from, labelled the way ``mso config models`` labels it."""
    if mso is None:
        raise _needs_workspace(spec)
    from maestro.core import crew
    from maestro.core.order_retry import workspace_scope
    from maestro.workspace import MSO_DIR_NAME

    role, fld = _split_model_key(spec.key)
    resolver_name, env_prefix, overlay_attr = _MODEL_FIELDS[fld]
    stored = _stored_model_field(mso, role, fld)
    error = None
    overlay = None
    with workspace_scope(mso):
        try:
            value = getattr(crew, resolver_name)(role)
        except ValueError as exc:
            value = None if stored is _MISSING else stored
            error = str(exc)
        try:
            # load_effective_role merges the shipped CORE role too, whose own
            # frontmatter carries a model — that is the built-in default, and
            # `mso config models` labels it so. Only a workspace overlay file
            # counts as the overlay source.
            from maestro.roles.loader import _overlay_roles_dir, load_effective_role

            if (_overlay_roles_dir(mso) / f"{role}.md").exists():
                overlay = getattr(load_effective_role(role, mso), overlay_attr, None)
        except Exception:
            overlay = None

    env_var = f"{env_prefix}{role}"
    if stored is not _MISSING:
        source, detail = SOURCE_WORKSPACE, f"{MSO_DIR_NAME}/config/role-models.json"
    elif os.environ.get(env_var, ""):
        source, detail = SOURCE_ENV, f"${env_var}"
    elif overlay:
        source, detail = SOURCE_OVERLAY, "role overlay"
    else:
        source, detail = SOURCE_DEFAULT, "built-in default"

    extra: dict = {}
    if fld == "model":
        extra["generation"] = model_generation(value) if isinstance(value, str) else None
    if error:
        extra["error"] = error
    return Effective(
        key=spec.key, value=value, source=source, source_detail=detail,
        default=spec.default, scope=spec.scope, type=spec.type, extra=extra,
    )


def effective_all(mso: Optional[Path]) -> list[Effective]:
    """Every key applicable to *mso* (all keys), or to the device when ``None``."""
    specs = SETTINGS if mso is not None else list_specs(scope=SCOPE_DEVICE)
    return [effective(mso, spec.key) for spec in specs]


# ---------------------------------------------------------------------------
# Validation + parsing
# ---------------------------------------------------------------------------

def _validate(spec: SettingSpec, value: Any) -> Any:
    if value is None:
        if spec.nullable:
            return None
        raise SettingValidationError(f"{spec.key} may not be null")
    t = spec.type
    if t == "bool":
        if not isinstance(value, bool):
            raise SettingValidationError(f"{spec.key} must be true or false, got {value!r}")
    elif t == "int":
        if isinstance(value, bool) or not isinstance(value, int):
            raise SettingValidationError(f"{spec.key} must be an integer, got {value!r}")
        if spec.minimum is not None and value < spec.minimum:
            raise SettingValidationError(f"{spec.key} must be >= {spec.minimum}, got {value}")
    elif t == "str":
        if not isinstance(value, str):
            raise SettingValidationError(f"{spec.key} must be a string, got {value!r}")
    elif t == "enum":
        choices = _choices(spec)
        if not isinstance(value, str) or value not in choices:
            raise SettingValidationError(
                f"{spec.key} must be one of {', '.join(choices)}; got {value!r}"
            )
    elif t == "model":
        _validate_model_pin(spec, value)
    elif t == "object":
        if not isinstance(value, dict):
            raise SettingValidationError(f"{spec.key} must be an object, got {value!r}")
    return value


def _validate_model_pin(spec: SettingSpec, value: Any) -> None:
    current = [m["id"] for m in model_vocabulary() if m["generation"] == "current"]
    if not isinstance(value, str) or not value:
        raise SettingValidationError(f"{spec.key} must be a model id, got {value!r}")
    if value.endswith("[1m]"):
        raise SettingValidationError(
            f"{spec.key} takes a bare model id; set the 1M context window with "
            f"{spec.key.rsplit('.', 1)[0]}.contextWindow=1m instead."
        )
    generation = model_generation(value)
    if generation is None:
        raise SettingValidationError(
            f"unknown model {value!r} for {spec.key}. Choose one of: {', '.join(current)}"
        )
    if generation == "previous":
        raise SettingValidationError(
            f"{value} is a previous-generation model: it is still honoured where it is "
            f"already pinned, but it cannot be chosen as a new pin. "
            f"Choose one of: {', '.join(current)}"
        )


_TRUE = {"true", "1", "yes", "on"}
_FALSE = {"false", "0", "no", "off"}


def parse_value(spec_or_key: "SettingSpec | str", raw: str) -> Any:
    """Parse a CLI string into the typed value :func:`set_setting` expects."""
    spec = get_spec(spec_or_key) if isinstance(spec_or_key, str) else spec_or_key
    text = raw.strip()
    if spec.nullable and text.lower() in ("null", "none"):
        return None
    if spec.type == "bool":
        if text.lower() in _TRUE:
            return True
        if text.lower() in _FALSE:
            return False
        raise SettingValidationError(f"{spec.key} must be true or false, got {raw!r}")
    if spec.type == "int":
        try:
            return int(text)
        except ValueError as exc:
            raise SettingValidationError(f"{spec.key} must be an integer, got {raw!r}") from exc
    if spec.type == "object":
        try:
            return json.loads(text)
        except ValueError as exc:
            raise SettingValidationError(f"{spec.key} must be a JSON object: {exc}") from exc
    if spec.type in ("enum", "model"):
        return text
    return raw


# ---------------------------------------------------------------------------
# Writers
# ---------------------------------------------------------------------------

_WRITE_LOCK = threading.RLock()


def _target_scope(spec: SettingSpec, scope: Optional[str], mso: Optional[Path]) -> str:
    if scope is None:
        target = SCOPE_DEVICE if spec.scope == SCOPE_DEVICE else SCOPE_WORKSPACE
    elif scope in (SCOPE_DEVICE, SCOPE_WORKSPACE):
        target = scope
    else:
        raise SettingValidationError(f"unknown scope: {scope!r} (expected device or workspace)")
    if target == SCOPE_DEVICE and spec.scope == SCOPE_WORKSPACE:
        raise SettingValidationError(
            f"{spec.key} is a workspace setting; it cannot be set for the device",
            hint="Drop --device and run inside the workspace.",
        )
    if target == SCOPE_WORKSPACE and spec.scope == SCOPE_DEVICE:
        raise SettingValidationError(
            f"{spec.key} is a device setting (it applies to every project on this device)",
            hint="Pass --device.",
        )
    if target == SCOPE_WORKSPACE and mso is None:
        raise _needs_workspace(spec)
    return target


def _refuse_if_locked(spec: SettingSpec, mso: Optional[Path]) -> None:
    if spec.key in _bundle_settings(mso):
        raise SettingLockedError(
            f"{spec.key} is pinned by the workspace's signed policy bundle and cannot be changed here"
        )


def _gate_workspace_write(mso: Path) -> None:
    from maestro.identity.gate import require_capability

    require_capability("settings.write", workspace=Path(mso).parent)


def _write_persona(path: Path, value: Optional[str]) -> bool:
    """Write (or, with ``None``, remove) a pointer-form persona file. A
    hand-authored full persona definition is never overwritten or deleted."""
    if path.exists():
        _, pointer = _read_persona_file(path)
        if not pointer:
            raise SettingStorageError(
                f"{path} holds a custom persona definition, not a pointer to a built-in - "
                "refusing to overwrite it.",
                hint="Move or remove that file by hand, then retry.",
            )
    if value is None:
        if path.exists():
            path.unlink()
            return True
        return False
    _atomic_write_json(path, {"id": value})
    return True


def _write_role_model(mso: Path, role: str, fld: str, value: Any) -> bool:
    """Set (or, with ``_MISSING``, remove) ``models.<role>.<fld>`` in
    role-models.json, preserving ``_comment`` and every other key."""
    path = _role_models_path(mso)
    data = _read_json_for_write(path)
    models = data.get("models")
    if models is None:
        if value is _MISSING:
            return False
        models = data["models"] = {}
    elif not isinstance(models, dict):
        raise SettingStorageError(f"{path}: 'models' is not an object - refusing to overwrite it.")
    entry = models.get(role)

    if value is _MISSING:
        if isinstance(entry, str):
            if fld != "model":
                return False
            del models[role]
        elif isinstance(entry, dict) and fld in entry:
            del entry[fld]
            if not entry:
                del models[role]
        else:
            return False
    elif fld == "model" and isinstance(entry, str):
        models[role] = value  # keep the legacy string shape where it already is
    else:
        if isinstance(entry, str):
            entry = {"model": entry}
        elif not isinstance(entry, dict):
            entry = {}
        entry[fld] = value
        models[role] = entry
    _atomic_write_json(path, data)
    return True


def _write_json_key(path: Path, key: str, value: Any) -> bool:
    data = _read_json_for_write(path)
    if value is _MISSING:
        if not _pluck(data, key):
            return False
    else:
        _plant(data, key, value, path)
    _atomic_write_json(path, data)
    return True


def _store(spec: SettingSpec, mso: Optional[Path], target: str, value: Any) -> bool:
    """Apply one write (``value is _MISSING`` = unset). Returns whether disk changed."""
    if spec.storage == _STORE_PERSONA:
        return _write_persona(_persona_path(mso, target), None if value is _MISSING else value)
    if spec.storage == _STORE_ROLE_MODELS:
        role, fld = _split_model_key(spec.key)
        return _write_role_model(mso, role, fld, value)
    path = device_settings_path() if target == SCOPE_DEVICE else _workspace_json_path(mso)
    return _write_json_key(path, spec.key, value)


def _mutate(mso: Optional[Path], spec: SettingSpec, target: str, value: Any) -> bool:
    if target == SCOPE_WORKSPACE:
        _refuse_if_locked(spec, mso)
        _gate_workspace_write(mso)
        from maestro.core.order_retry import workspace_scope

        with workspace_scope(mso), _WRITE_LOCK:
            return _store(spec, mso, target, value)
    with _WRITE_LOCK:
        return _store(spec, None, target, value)


def _provider_call(fn: Callable[[], Any]) -> Any:
    from maestro.providers import config as providers_config

    try:
        return fn()
    except providers_config.ProviderLockedError as exc:
        raise SettingLockedError(str(exc), hint=exc.hint) from exc
    except providers_config.ProviderConfigError as exc:
        raise SettingValidationError(str(exc), hint=exc.hint) from exc


def _read_back(mso: Optional[Path], spec: SettingSpec, target: str, changed: bool) -> Effective:
    result = effective(mso, spec.key)
    result.extra["changed"] = changed
    result.extra["writtenScope"] = target
    return result


def set_setting(mso: Optional[Path], key: str, value: Any, *, scope: Optional[str] = None) -> Effective:
    """Validate and write *key* = *value* to *scope*'s file (default: the key's
    natural file — device for device keys, workspace otherwise). Atomic;
    preserves every other key. Returns the effective value read back from disk
    (which may still come from a higher-precedence source, e.g. an env var)."""
    spec = get_spec(key)
    mso = Path(mso) if mso is not None else None
    target = _target_scope(spec, scope, mso)

    if spec.storage == _STORE_PROVIDERS:
        if not isinstance(value, dict) or not isinstance(value.get("id"), str):
            raise SettingValidationError(
                f"{key} must be an object {{\"id\": <provider id>, \"config\": {{...}}}}"
            )
        from maestro.providers import config as providers_config

        kind = key.split(".", 1)[1]
        with _WRITE_LOCK:
            _provider_call(lambda: providers_config.set_provider(
                mso.parent, kind, value["id"], value.get("config")))
        return _read_back(mso, spec, target, True)

    value = _validate(spec, value)
    changed = _mutate(mso, spec, target, value)
    return _read_back(mso, spec, target, changed)


def unset_setting(mso: Optional[Path], key: str, *, scope: Optional[str] = None) -> Effective:
    """Remove *key* from *scope*'s file so it falls back to the next source."""
    spec = get_spec(key)
    mso = Path(mso) if mso is not None else None
    target = _target_scope(spec, scope, mso)

    if spec.storage == _STORE_PROVIDERS:
        from maestro.providers import config as providers_config

        kind = key.split(".", 1)[1]
        with _WRITE_LOCK:
            result = _provider_call(lambda: providers_config.unset_provider(mso.parent, kind))
        return _read_back(mso, spec, target, bool(result.get("removed")))

    changed = _mutate(mso, spec, target, _MISSING)
    return _read_back(mso, spec, target, changed)
