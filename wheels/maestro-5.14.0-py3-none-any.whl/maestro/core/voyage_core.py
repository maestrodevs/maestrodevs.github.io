# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Shared voyage-creation core (FTR-MSO-2026-0618 / PLAN-PLN-MSO-2026-0556 §3.2).

There was never ONE voyage-create implementation to reuse. There were TWO, and
they had already drifted before anyone proposed a third for the Hub
(PLAN-PLN-MSO-2026-0556 §2.2, measured during planning):

===================  ===============================  =================================
                     ``cli.cmd_voyage`` ("create")    ``bridge_poller._handle_voyage_create``
===================  ===============================  =================================
Manifest primary key ``id``                           ``voyageId``
Sequence source      ``max(seq)+1`` over ``active``   ``len(existing)+1`` over
                     **and** ``complete``             ``active`` **only**
``branch`` field     written (``voyage/{id}``)        absent
``priority`` field   ``MEDIUM``                       absent
Allocation lock      ``lock_for_allocation``          none
                     (BUG-MSO-2026-0571)
Remote fetch         yes (FTR-MSO-2026-0574)          none
Git side effect      ``git checkout -b`` in cwd       ``git checkout -b`` in
                                                      artefact parent
===================  ===============================  =================================

Two defects fall straight out of that table:

1. ``len(existing) + 1`` is *precisely* the bug SEC-MSO-2026-0461 Finding 3
   fixed for orders. ``order_ids.py``'s module docstring exists to record why
   counting a directory is wrong — it under-counts the moment anything is
   archived out of it, and it is not atomic. The fix landed for orders and was
   never applied to voyages in either allocator. Here it is deleted: the
   sequence is the max over ``voyages/active`` **and** ``voyages/complete``
   (plus the fetched remote tree), so a completed voyage's number is never
   re-used.
2. The ``id`` / ``voyageId`` split was already costing the engine money in
   defensive reads — ``cmd_voyage status`` reads
   ``v.get('id') or v.get('voyageId') or voyage_id`` (added by
   BUG-MSO-2026-0300 after a bare ``v['id']`` crashed), and
   ``voyages_outstanding_work`` reads ``voyage.get("voyageId", stem)``. This
   module writes **both** keys, so the drift is closed going forward without
   breaking either existing reader.

``maestro/core/review_core.py``'s docstring records what leaving two copies
alone costs: five silent behavioural drifts between the Hub's private copy of
the review logic and the CLI's, two of them order-destroying, none found by
reading either implementation alone (BUG-MSO-2026-0486). The drift above was
found the same way — by putting the two side by side — and it *predates* the
Hub. Adding a third allocator would not have been a new risk to manage; it
would have been a repeat.

Module contract — copied verbatim from ``maestro/core/order_retry.py``
(PLAN-PLN-MSO-2026-0556 §3.3), not invented here:

* **Explicit ``mso: Path`` throughout. No ``find_workspace()``, no CWD.** The
  Hub serves N workspaces from one process; a core that resolves its workspace
  from the process is unusable there.
* **Typed exceptions, no printing, no ``sys.exit``.**
  :class:`~maestro.core.order_ids.OrderValidationError` -> HTTP 400 /
  ``MaestroUserError``; :class:`VoyageNotFound` (a ``FileNotFoundError``) ->
  404; :class:`VoyageIdCollision` -> 409; ``CapabilityDenied`` -> 403.
* **Every mutation runs inside ``order_retry.workspace_scope(mso)``.** Not
  decorative: shared-mode allocation goes through
  ``artefact_sync.push_id_reservation``, which writes ``ID_RESERVED`` lifecycle
  events resolved from ``fleet_runner._MAESTRO_DIR_OVERRIDE`` — a process
  global. Unguarded, a Hub poller tick for workspace A can write into
  workspace B's lifecycle log.
* **The write happens under ``lock_for_allocation(mso)``, inside the same
  ``with`` block as the allocation** — ``order_ids.py`` is explicit that
  allocating outside that block is not race-safe. The lock file is the *same*
  ``state/order-id.lock`` orders use, deliberately: voyage and order IDs are
  minted from one workspace sequence space (CLAUDE.md, "MSO Order Naming
  Convention"), so a second lock would serialise the wrong thing.

**No git side effect by default (§3.4, Captain decision D4).**
:func:`create_voyage` takes ``create_branch: bool = False`` and performs no git
operation unless asked. ``fleet_runner.ensure_voyage_branch_exists()`` already
creates the voyage branch **on the remote via ``gh api``, with no clone and no
checkout**, lazily at first crew dispatch — so both callers'
``git checkout -b`` was redundant, and in the primary workspace checkout it was
actively hazardous (CLAUDE.md's ``CONVERGENCE_PRIMARY_PROTECTED`` is an entire
bug class caused by unexpected primary-checkout mutation). The manifest records
the branch *name*; the machinery that needs the branch creates it when it needs
it. ``mso voyage create`` keeps today's behaviour behind a deprecated
``--checkout``; the bridge poller does **not**, because a background daemon
switching the operator's working tree is the sharpest form of the objection
§3.4 raises against doing it from the Hub.

``require_capability("voyage.create")`` is enforced here rather than in the CLI
wrapper, so the CLI, the bridge and (from Order 3) the Hub inherit the gate
together — the shape FTR-MSO-2026-0492 established for ``order.dispatch``.
"""

from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

from maestro.core.order_create import validate_project
from maestro.core.order_ids import (
    SEQUENCE_SCAN_SUBDIRS,
    OrderValidationError,
    fetch_remote_sequence_numbers,
    highest_existing_sequence,
    lock_for_allocation,
    sequence_id_pattern,
    validate_description,
    validate_priority,
)
from maestro.core.order_retry import workspace_scope

# ---------------------------------------------------------------------------
# Vocabulary
# ---------------------------------------------------------------------------

#: Every directory a voyage manifest can live in across its lifecycle. Scanning
#: only ``active`` is how sequence numbers get re-used: ``voyage reconcile``
#: moves a merged voyage to ``complete/``, and a scan that cannot see it mints
#: its number again for a different voyage.
VOYAGE_SCAN_SUBDIRS: tuple = ("voyages/active", "voyages/complete")

#: Voyages are always created PLANNED (Captain decision D3). ``voyage.status``
#: gates no dispatch — ``scan_all_queues`` never reads it — so a
#: Planned/Active selector was inert, and the ORDER plane is where
#: "created but not started" is actually expressed.
DEFAULT_VOYAGE_STATUS = "PLANNED"

#: The CLI wrote MEDIUM and the bridge wrote nothing. Converged on the CLI's
#: value, always present.
DEFAULT_VOYAGE_PRIORITY = "MEDIUM"

#: Fields :func:`create_voyage` computes and validates itself — ``extra`` may
#: not overwrite any of them. Mirrors ``order_create._COMPUTED_FIELDS``: a
#: caller must not be able to smuggle a forged id, status or branch past the
#: validation above, which is the entire point of having one core.
_COMPUTED_FIELDS: frozenset = frozenset({
    "id", "voyageId", "title", "status", "priority", "branch", "project",
    "orders", "createdBy", "createdAt",
})


# ---------------------------------------------------------------------------
# Typed errors
# ---------------------------------------------------------------------------

class VoyageNotFound(FileNotFoundError):
    """*voyage_id* has no manifest in this workspace.

    A ``FileNotFoundError`` subclass so an HTTP caller maps it to 404 through
    the same ``except FileNotFoundError`` arm it already uses, per the module
    contract above.
    """

    def __init__(self, voyage_id: str) -> None:
        self.voyage_id = voyage_id
        self.hint = "Check 'mso voyage list' for active voyages."
        super().__init__(
            f"Voyage {voyage_id} not found in voyages/active or voyages/complete."
        )


class VoyageIdCollision(Exception):
    """A freshly-minted voyage ID already exists on disk.

    The last line of defence if :func:`~maestro.core.order_ids.lock_for_allocation`
    ever degraded to unlocked — its ``_CrossProcessLock`` proceeds unlocked
    rather than blocking forever when a wedged holder outlives the timeout.
    Maps to HTTP 409; the remedy is simply to retry.
    """

    def __init__(self, voyage_id: str, path: Path) -> None:
        self.voyage_id = voyage_id
        self.path = path
        self.hint = (
            "Retry — this indicates a concurrent allocation raced past the lock."
        )
        super().__init__(f"Voyage ID collision: {voyage_id} already exists at {path}")


class VoyageOrderRefused(Exception):
    """An attach/detach could not be applied as asked. Maps to HTTP 409."""

    def __init__(self, voyage_id: str, order_id: str, message: str,
                 hint: str = "") -> None:
        self.voyage_id = voyage_id
        self.order_id = order_id
        self.hint = hint
        super().__init__(message)


class VoyageArchived(VoyageOrderRefused):
    """:func:`create_order_on_voyage` was pointed at an archived voyage.

    Raised BEFORE any id is allocated, so nothing is written. Maps to HTTP 409.
    """

    def __init__(self, voyage_id: str) -> None:
        super().__init__(
            voyage_id, "",
            "Voyage {} is archived - its manifest is a completion record, not "
            "a work queue. Create a new voyage for further work.".format(voyage_id),
            hint="Create a new voyage for further work.",
        )


class OrderNotWritten(Exception):
    """``create_order`` reported an order whose file is not on the plane.

    ``create_order`` falls back to the dict it INTENDED to write when its own
    re-read fails; this is the guard that stops that fallback being reported
    as a success. Raised before any voyage manifest is touched. Maps to 500.
    """

    def __init__(self, order_id: str, path: Path) -> None:
        self.order_id = order_id
        self.path = path
        super().__init__(
            "Order {} reported created but no file is present at {} - nothing "
            "was created. Check the artefact plane's permissions.".format(
                order_id, path))


class VoyageAttachFailed(Exception):
    """An order was created but could not be attached, and was rolled back.

    *cause* is the exception ``attach_order`` raised, or ``None`` when it
    returned without the manifest listing the order. A caller maps it by
    *cause*: ``FileNotFoundError`` (the voyage vanished) 404, any other
    ``OSError`` (the plane went away) 503, anything else 409, ``None`` 500.
    *rollback_incomplete* is "" when the rollback fully succeeded, otherwise
    the sentence saying which half of it did not.
    """

    def __init__(self, message: str, *, order_id: str, voyage_id: str,
                 cause: Optional[BaseException] = None,
                 rollback_incomplete: str = "") -> None:
        self.order_id = order_id
        self.voyage_id = voyage_id
        self.cause = cause
        self.rollback_incomplete = rollback_incomplete
        super().__init__(message)


# ---------------------------------------------------------------------------
# Results
# ---------------------------------------------------------------------------

@dataclass
class LoadedVoyage:
    """Result of :func:`load_voyage`."""

    voyage_id: str
    path: Path
    voyage: Dict[str, Any]
    #: True when the manifest was found in ``voyages/complete`` rather than
    #: ``voyages/active`` — an archived voyage is readable but not mutable.
    archived: bool = False


@dataclass
class CreatedVoyage:
    """Result of a successful :func:`create_voyage` call."""

    voyage_id: str
    path: Path
    voyage: Dict[str, Any]
    branch: str = ""
    #: True when shared-mode push-as-mutex actually reserved the id upstream.
    reserved: bool = False
    #: ``push_id_reservation``'s outcome reason, or ``"local"`` in solo/embedded.
    reservation_reason: str = "local"
    #: Populated only when ``create_branch=True`` and the git call failed. The
    #: voyage itself is still created — a branch that the dispatcher will
    #: create anyway is not worth failing a creation over.
    branch_error: str = ""
    #: BUG-MSO-2026-0775: populated only when a plan link was requested and the
    #: planning voyage's ``buildVoyages`` could not be written. The new voyage
    #: already carries ``planOrder``/``planVoyage``, and the reader follows
    #: either direction, so the link still renders — this says the reverse
    #: half is missing from the planning manifest.
    plan_link_error: str = ""


@dataclass
class UpdatedVoyage:
    """Result of :func:`attach_order` / :func:`detach_order`."""

    voyage_id: str
    path: Path
    voyage: Dict[str, Any]
    order_ids: List[str] = field(default_factory=list)
    #: False when the manifest already said what was asked for (attaching an
    #: order that is already attached) — the call is idempotent, and the caller
    #: deserves to know nothing changed rather than being told it did.
    changed: bool = True


@dataclass
class CreatedVoyageOrder:
    """Result of :func:`create_order_on_voyage`."""

    #: The ``order_create.CreatedOrder`` — read back from the file written.
    created: Any
    #: The resolved voyage id, or "" when the order was created on no voyage.
    voyage_id: str = ""
    #: True only when the manifest, read back after the attach, lists the order.
    attached: bool = False
    voyage_order_ids: List[str] = field(default_factory=list)
    #: BUG-MSO-2026-0775: the plan link recorded because the order named a
    #: ``planOrder`` and was created on a voyage other than the plan's own
    #: (``plan_links.LinkResult``), or ``None``.
    plan_link: Any = None
    #: Set when that link could not be written. The order and its attach
    #: stand either way; a missing cross-reference is not a failed create.
    plan_link_error: str = ""


# ---------------------------------------------------------------------------
# ID allocation
# ---------------------------------------------------------------------------

def voyage_id_pattern(project: str, year: str) -> "re.Pattern[str]":
    """Filename regex for this project/year's voyage manifests, group 1 = seq.

    Recognises a voyage manifest. NOT the allocation scan — a new voyage id
    continues past every artefact in the workspace, not just voyages (see
    :func:`highest_voyage_sequence`).
    """
    return re.compile(
        rf'^VOY-{re.escape(project)}-{re.escape(year)}-(\d+)\.json$'
    )


def highest_voyage_sequence(mso: Path, project: str, year: str) -> int:
    """Highest local sequence a new voyage id must continue past.

    BUG-MSO-2026-0752: that is the WORKSPACE-wide max — orders, voyages,
    charts, plans and handoffs share one sequence space — so this delegates to
    :func:`~maestro.core.order_ids.highest_existing_sequence`, the same scan
    the order allocator uses. Scanning only ``voyages/active|complete`` is how
    ``mso voyage create`` minted VOY-MSO-2026-0747 over PLN-MSO-2026-0747.
    (Kept as this module's own name so the allocation race tests can widen
    the scan-then-write window at it.)
    """
    return highest_existing_sequence(Path(mso), project, year)


def allocate_voyage_id(mso: Path, project: str, year: str, *,
                       fetch_remote: bool = True, git: Any = None) -> str:
    """Allocate the next voyage ID for (project, year).

    Mirrors :func:`~maestro.core.order_ids.allocate_order_id` exactly, over the
    same workspace-wide sequence space (BUG-MSO-2026-0752): fold the artefact
    repo's fetched remote tree in with the local max (FTR-MSO-2026-0574), then
    add one. The fetch skips SILENTLY when
    there is no repo, no remote or no connectivity — FTR-MSO-2026-0366's
    deliberate offline tolerance, not an error path.

    Callers MUST invoke this inside a ``with lock_for_allocation(mso):`` block
    that also performs the resulting file write — calling it alone is not
    race-safe.
    """
    local_max = highest_voyage_sequence(mso, project, year)
    remote_max = 0
    if fetch_remote:
        fetched = fetch_remote_sequence_numbers(
            Path(mso), SEQUENCE_SCAN_SUBDIRS, sequence_id_pattern(project, year),
            git=git)
        if fetched is not None:
            remote_max = fetched
    seq = max(local_max, remote_max) + 1
    return f"VOY-{project}-{year}-{seq:04d}"


def assert_voyage_id_available(mso: Path, voyage_id: str) -> None:
    """Raise :class:`VoyageIdCollision` if *voyage_id* already exists.

    Post-allocation uniqueness assertion, run inside the allocation lock. See
    :class:`VoyageIdCollision` for why it exists despite the lock.
    """
    for sub in VOYAGE_SCAN_SUBDIRS:
        existing = Path(mso) / sub / f"{voyage_id}.json"
        if existing.exists():
            raise VoyageIdCollision(voyage_id, existing)


# ---------------------------------------------------------------------------
# Lookup
# ---------------------------------------------------------------------------

def find_voyage_file(mso: Path, voyage_id: str) -> Optional[Path]:
    """Path of *voyage_id*'s manifest, active first then archived, or ``None``.

    Resolves by filename and by the manifest's own id keys (``id`` OR
    ``voyageId`` — the §2.2 drift means a workspace can legitimately hold both
    shapes), so an older manifest whose filename and id disagree is still
    found.
    """
    mso = Path(mso)
    for sub in VOYAGE_SCAN_SUBDIRS:
        d = mso / sub
        if not d.exists():
            continue
        direct = d / f"{voyage_id}.json"
        if direct.exists():
            return direct
    for sub in VOYAGE_SCAN_SUBDIRS:
        d = mso / sub
        if not d.exists():
            continue
        for jf in sorted(d.glob("*.json")):
            try:
                data = json.loads(jf.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            if not isinstance(data, dict):
                continue
            if (data.get("id") or data.get("voyageId") or jf.stem) == voyage_id:
                return jf
    return None


def voyage_order_ids(voyage: Dict[str, Any]) -> List[str]:
    """Order ids in a manifest's ``orders[]``, which may hold strings or dicts.

    Same tolerance as ``fleet_runner._voyage_order_ids`` — the two must agree
    about what an ``orders[]`` entry is, or an order this core attaches is one
    the dispatcher does not see.
    """
    ids: List[str] = []
    for entry in voyage.get("orders", []) or []:
        if isinstance(entry, str):
            oid = entry
        elif isinstance(entry, dict):
            oid = entry.get("orderId") or entry.get("id") or ""
        else:
            oid = ""
        if oid:
            ids.append(oid)
    return ids


def load_voyage(mso: Path, voyage_id: str) -> LoadedVoyage:
    """Read *voyage_id*'s manifest from workspace *mso*.

    Raises :class:`VoyageNotFound` (a ``FileNotFoundError``) when there is no
    manifest, and :class:`~maestro.core.order_ids.OrderValidationError` when the
    file exists but is not readable JSON — a corrupt manifest is a 400-class
    input problem, not a missing resource.
    """
    path = find_voyage_file(mso, voyage_id)
    if path is None:
        raise VoyageNotFound(voyage_id)
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise OrderValidationError(
            f"Cannot read voyage file {path}: {exc}") from exc
    if not isinstance(data, dict):
        raise OrderValidationError(
            f"Voyage file {path} does not contain a JSON object")
    return LoadedVoyage(
        voyage_id=data.get("id") or data.get("voyageId") or path.stem,
        path=path,
        voyage=data,
        archived=path.parent.name == "complete",
    )


# ---------------------------------------------------------------------------
# create_voyage
# ---------------------------------------------------------------------------

def _checkout_branch(repo_root: Path, branch: str) -> str:
    """``git checkout -b`` in *repo_root*; returns "" on success, else the error.

    Only ever reached via ``create_branch=True`` (``mso voyage create
    --checkout``). Deprecated — see §3.4 in the module docstring.
    """
    from maestro.core.proc import run_hidden

    try:
        result = run_hidden(
            ["git", "checkout", "-b", branch],
            cwd=str(repo_root), capture_output=True, text=True, timeout=30,
        )
    except Exception as exc:  # noqa: BLE001 — reported, never raised onward
        return str(exc)
    if getattr(result, "returncode", 1) == 0:
        return ""
    return (getattr(result, "stderr", "") or "").strip() or "git checkout failed"


def create_voyage(
    mso: Path,
    *,
    project: str,
    title: str,
    priority: Optional[str] = None,
    status: str = DEFAULT_VOYAGE_STATUS,
    description: str = "",
    orders: Optional[Sequence[Any]] = None,
    created_by: str = "cli",
    create_branch: bool = False,
    repo_root: Optional[Path] = None,
    extra: Optional[Dict[str, Any]] = None,
    plan_order: str = "",
    plan_voyage: str = "",
) -> CreatedVoyage:
    """Create a voyage in workspace *mso* and return what actually landed.

    Sole implementation of voyage creation — ``mso voyage create``, the Slack
    bridge's ``voyage_create`` command and (Order 3) the Hub's
    ``POST /workspaces/{id}/voyages`` all call this. The manifest carries
    **both** ``id`` and ``voyageId`` (§2.2), a ``branch`` name, and a
    ``priority``, so the two historic shapes converge without breaking either
    existing reader.

    ``create_branch`` defaults to ``False`` and no git command runs unless it is
    set — see §3.4 / D4 in the module docstring. When it is set, *repo_root*
    (defaulting to ``mso.parent``) is where ``git checkout -b`` runs, and a
    failure is reported in :attr:`CreatedVoyage.branch_error` rather than
    raised: the dispatcher creates the branch on the remote anyway.

    *plan_order* / *plan_voyage* (BUG-MSO-2026-0775) mark this as a BUILD
    voyage cut from a plan. They are validated before an id is allocated (an
    unknown plan order or voyage writes nothing), written onto the new manifest
    as ``planOrder``/``planVoyage``, and the planning voyage gains this id in
    its ``buildVoyages`` via ``plan_links.link_build_voyage``.

    Raises :class:`~maestro.core.order_ids.OrderValidationError` on bad input,
    :class:`VoyageIdCollision` (409) if an allocated id is somehow already
    taken, and ``CapabilityDenied`` (403) in a governed workspace whose caller
    lacks ``voyage.create``. Prints nothing; exits nothing.
    """
    from maestro.identity.gate import require_capability

    # `mso` is the artefact `.mso` dir; the gate wants the WORKSPACE ROOT.
    # A no-op outside enterprise/governed workspaces. Enforced HERE rather than
    # in cmd_voyage so the bridge and the Hub inherit the same gate — the shape
    # FTR-MSO-2026-0492 established for order.dispatch.
    require_capability("voyage.create", workspace=Path(mso).parent)

    mso = Path(mso)
    project = validate_project(project)
    title = validate_description(title)
    priority = validate_priority(priority, default=DEFAULT_VOYAGE_PRIORITY)
    status = (status or DEFAULT_VOYAGE_STATUS).strip().upper() or DEFAULT_VOYAGE_STATUS

    initial_orders: List[Any] = list(orders or [])

    # BUG-MSO-2026-0775: resolve-before-allocate, the same rule as the voyage
    # an order is created in — a bad plan reference burns no id.
    from maestro.core import plan_links
    plan_link = plan_links.resolve_plan_link(
        mso, plan_order_id=plan_order, plan_voyage_id=plan_voyage)

    now = datetime.now(timezone.utc)
    year = now.strftime("%Y")
    voyages_dir = mso / "voyages" / "active"
    voyages_dir.mkdir(parents=True, exist_ok=True)

    written: Dict[str, Any] = {}

    def _build(voyage_id: str) -> Dict[str, Any]:
        voyage: Dict[str, Any] = {
            # BOTH keys, deliberately (§2.2). `id` first because that is the
            # order the CLI's manifests have always had and every `.get('id')
            # or .get('voyageId')` reader in the engine tries `id` first.
            "id": voyage_id,
            "voyageId": voyage_id,
            "title": title,
            "status": status,
            "priority": priority,
            "branch": f"voyage/{voyage_id}",
            "project": project,
            "orders": initial_orders,
            "createdBy": created_by,
            "createdAt": now.isoformat(),
        }
        if description:
            voyage["description"] = description
        for key, value in (extra or {}).items():
            if key not in _COMPUTED_FIELDS:
                voyage[key] = value
        if plan_link is not None:
            if plan_link.plan_order_id:
                voyage[plan_links.PLAN_ORDER_FIELD] = plan_link.plan_order_id
            if plan_link.plan_voyage_id:
                voyage[plan_links.PLAN_VOYAGE_FIELD] = plan_link.plan_voyage_id
        return voyage

    def _mint(git: Any) -> str:
        candidate = allocate_voyage_id(mso, project, year, git=git)
        assert_voyage_id_available(mso, candidate)
        return candidate

    def _write(voyage_id: str) -> Path:
        voyage = _build(voyage_id)
        path = voyages_dir / f"{voyage_id}.json"
        path.write_text(json.dumps(voyage, indent=2), encoding="utf-8")
        written.clear()
        written.update(voyage)
        return path

    # workspace_scope: shared-mode reservation writes ID_RESERVED lifecycle
    # events through fleet_runner's process-global override (module docstring).
    # lock_for_allocation: the scan-then-write critical section must be ONE
    # locked block. This is the lock the bridge never had.
    with workspace_scope(mso):
        with lock_for_allocation(mso):
            # FTR-MSO-2026-0574: in mode: shared ONLY, reserve the id via
            # push-as-mutex. Solo mode does not get this — an unsynced solo
            # device against a shared plane is a misconfiguration to migrate
            # away from, not something to arbitrate.
            from maestro.core.artefact_sync import get_mode, push_id_reservation

            if get_mode(mso) == "shared":
                outcome = push_id_reservation(mso, _mint, _write)
                new_id = outcome.id
                reserved = bool(getattr(outcome, "pushed", False))
                reason = getattr(outcome, "reason", "") or "shared"
            else:
                new_id = _mint(None)
                _write(new_id)
                reserved = False
                reason = "local"

    # Read the manifest back from the file that was actually written rather
    # than returning the dict we intended to write — §2.3's rule for the Hub
    # ("returns the ID read back from the file it just wrote"), applied to the
    # whole record. In shared mode the reservation helper owns the write and
    # may re-mint, so intent and outcome are not guaranteed to be the same
    # object.
    path = voyages_dir / f"{new_id}.json"
    try:
        voyage_data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        voyage_data = dict(written) if written else _build(new_id)

    branch = voyage_data.get("branch") or f"voyage/{new_id}"
    branch_error = ""
    if create_branch:
        branch_error = _checkout_branch(
            Path(repo_root) if repo_root else mso.parent, branch)

    # The reverse half of the link, written after the allocation lock is
    # released (link_build_voyage takes it itself). Reported, never raised:
    # the voyage exists and names its plan either way.
    plan_link_error = ""
    if plan_link is not None and plan_link.plan_voyage_id:
        try:
            plan_links.link_build_voyage(
                mso, new_id, plan_order_id=plan_link.plan_order_id,
                plan_voyage_id=plan_link.plan_voyage_id)
            voyage_data = json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:   # noqa: BLE001 - reported on the result
            plan_link_error = str(exc) or type(exc).__name__

    return CreatedVoyage(
        voyage_id=new_id,
        path=path,
        voyage=voyage_data,
        branch=branch,
        reserved=reserved,
        reservation_reason=reason,
        branch_error=branch_error,
        plan_link_error=plan_link_error,
    )


# ---------------------------------------------------------------------------
# attach_order / detach_order
# ---------------------------------------------------------------------------

def _save_voyage(path: Path, voyage: Dict[str, Any]) -> None:
    """Write *voyage* to *path* atomically (BUG-MSO-2026-0621 concurrency fix).

    A plain ``path.write_text()`` truncates the file before writing the new
    content, leaving a window where a concurrent, unlocked ``load_voyage()``
    (from another request's read path, not the attach path itself — see
    ``attach_order``'s own ``workspace_scope`` above) can observe an EMPTY
    file and raise ``Cannot read voyage file ...: Expecting value: line 1
    column 1 (char 0)``. Same tmp-file + ``os.replace()`` pattern already used
    by ``registry.py``'s ``_atomic_write_with_backup`` and
    ``crew.py``'s state-file writer (BUG-MSO-2026-0387/0636): a reader either
    sees the old complete file or the new complete file, never a partial one.
    """
    tmp = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    tmp.write_text(json.dumps(voyage, indent=2), encoding="utf-8")
    os.replace(tmp, path)


def attach_order(mso: Path, voyage_id: str, order_id: str, *,
                 title: str = "") -> UpdatedVoyage:
    """Add *order_id* to *voyage_id*'s ``orders[]``. Idempotent.

    Entries are written as dicts (``{"orderId": ..., "title": ...}``) — the
    richer of the two shapes ``fleet_runner._voyage_order_ids`` accepts, and the
    one ``mso voyage status`` renders a title from. An order already present is
    left exactly as it is and ``changed=False`` is returned; re-attaching must
    not rewrite an entry another surface authored.

    Raises :class:`VoyageNotFound` (404), :class:`VoyageOrderRefused` (409) for
    an archived voyage, and
    :class:`~maestro.core.order_ids.OrderValidationError` (400) for an empty
    order id.
    """
    order_id = (order_id or "").strip()
    if not order_id:
        raise OrderValidationError("Order ID is required")

    with workspace_scope(Path(mso)):
        loaded = load_voyage(mso, voyage_id)
        if loaded.archived:
            raise VoyageOrderRefused(
                loaded.voyage_id, order_id,
                f"Voyage {loaded.voyage_id} is archived — its manifest is a "
                "completion record, not a work queue.",
                hint="Create a new voyage for further work.",
            )
        voyage = loaded.voyage
        existing = voyage_order_ids(voyage)
        if order_id in existing:
            return UpdatedVoyage(
                voyage_id=loaded.voyage_id, path=loaded.path, voyage=voyage,
                order_ids=existing, changed=False)

        entry: Dict[str, Any] = {"orderId": order_id}
        if title:
            entry["title"] = title
        voyage.setdefault("orders", [])
        voyage["orders"].append(entry)
        _save_voyage(loaded.path, voyage)
        return UpdatedVoyage(
            voyage_id=loaded.voyage_id, path=loaded.path, voyage=voyage,
            order_ids=voyage_order_ids(voyage), changed=True)


# ---------------------------------------------------------------------------
# create_order_on_voyage — "create an order IN a voyage", one implementation
# ---------------------------------------------------------------------------

# BUG-MSO-2026-0744 — the two ways a created-order rollback can be INCOMPLETE.
# They are different facts with different remedies and are never collapsed into
# one message: "still on this disk" is fixed with a delete, "gone here but
# still on the shared plane" is fixed on the artefact repo and is the one an
# operator has no way to discover from the response otherwise.
ROLLBACK_LOCAL_FAILED = (
    "AND the order file could not be removed ({path}: {error}). It exists but "
    "its voyage cannot see it; delete it by hand."
)
ROLLBACK_REMOTE_FAILED = (
    "The rollback could not be published to the SHARED artefact plane "
    "({reason}: {detail}) - so {order_id}'s reservation commit is still on "
    "origin and every other device still sees an order its voyage does not "
    "list. Commit the deletion of {path} in the artefact repo and push it "
    "(or revert the reservation commit there), then retry."
)


def rollback_created_order(mso: Path, created: Any) -> str:
    """Undo an order whose voyage attach failed. Returns "" or what is left.

    This is a ROLLBACK, not a deletion of anyone's work: the file has existed
    for microseconds, nothing has read it, and the alternative is an order that
    names a voyage whose manifest does not list it - invisible to
    ``voyages_outstanding_work`` and to the BUG-MSO-2026-0303 completion guard,
    both of which read the MANIFEST and not the order's own claim of
    membership. An invisible order is worse than no order: it looks filed and
    produces a false finish later.

    **How far "undo" has to reach depends on the artefact mode**
    (BUG-MSO-2026-0744). In solo/embedded mode the create only ever wrote a
    file, so unlinking it is the whole rollback. In ``artefacts.mode: shared``
    the create went through ``artefact_sync.push_id_reservation``, which
    COMMITS the order file and PUSHES it: the push is the reservation, so
    deleting the local file undoes nothing anyone else can see. Shared mode
    therefore goes through ``release_id_reservation``, which commits the
    deletion and pushes it too.

    A rollback that is INCOMPLETE - either half - returns a sentence saying
    which half, naming the path. "Removed here, still on the remote" is a
    different remedy from "still on disk", so the two are never collapsed.
    Never raises.
    """
    from maestro.core import artefact_sync

    path = created.path
    order_id = created.order_id
    try:
        shared = artefact_sync.get_mode(mso) == "shared"
    except Exception:   # noqa: BLE001 - an unreadable config is not shared
        shared = False

    if not shared:
        try:
            path.unlink()
            return ""
        except OSError as exc:
            return ROLLBACK_LOCAL_FAILED.format(path=path, error=exc)

    try:
        outcome = artefact_sync.release_id_reservation(mso, path, order_id)
    except Exception as exc:    # noqa: BLE001 - never raise from a rollback
        return ROLLBACK_LOCAL_FAILED.format(path=path, error=exc)

    remote = "" if outcome.remote_clean else ROLLBACK_REMOTE_FAILED.format(
        order_id=order_id, path=path, reason=outcome.reason,
        detail=outcome.detail or "no detail from git")
    if outcome.released:
        return remote
    # Both halves failed: the file is still on this disk AND still on the
    # plane. Two facts, two remedies, both said.
    local = ROLLBACK_LOCAL_FAILED.format(
        path=path, error=outcome.detail or outcome.reason)
    return (local + " " + remote).strip() if remote else local


def create_order_on_voyage(mso: Path, *, voyage_id: str = "",
                           voyage_branch: str = "",
                           plan_order: str = "",
                           **create_kwargs: Any) -> CreatedVoyageOrder:
    """Create an order and, when *voyage_id* is given, attach it to that voyage.

    The ONE implementation of "create an order in a voyage" - ``mso order
    create --voyage`` and the Hub's ``POST /workspaces/{id}/orders`` both call
    it (BUG-MSO-2026-0754; before it, only the Hub attached, so the CLI wrote
    ``voyageId`` with no ``voyageBranch`` and no manifest entry - an order its
    voyage could not see). *create_kwargs* go to ``order_create.create_order``
    unchanged; that core's own contract ("record ``voyageId``, do not resolve
    it") is deliberately left alone.

    TWO WRITES, ONE OUTCOME, AND NO ORPHAN BETWEEN THEM:

    1. **The voyage is resolved BEFORE anything is allocated.** A missing
       (:class:`VoyageNotFound`), corrupt (``OrderValidationError``) or
       archived (:class:`VoyageArchived`) voyage writes nothing and burns no id.
    2. **``voyageBranch`` is derived from the manifest.** A caller-supplied
       *voyage_branch* that disagrees with the manifest's is refused
       (``OrderValidationError``) - a branch that disagrees with its voyage is
       how an order strands (BUG-ADM-2026-0004). A caller branch is used only
       when the manifest records none; with no *voyage_id* it passes through.
    3. **The created file is verified** (:class:`OrderNotWritten`) before any
       manifest is touched.
    4. **The attach runs under** ``lock_for_allocation`` so two concurrent
       creators cannot lose each other's manifest entry, and **a failed attach
       rolls the order back** (:func:`rollback_created_order`, which reaches
       the remote in shared mode) and raises :class:`VoyageAttachFailed`.
       ``attached`` is read from the manifest, never inferred from the absence
       of an exception.

    *plan_order* (BUG-MSO-2026-0775) names the plan this order was cut from.
    It is validated with the voyage (an unknown plan order writes nothing),
    recorded on the order as ``planOrder``, and — when the order's voyage is
    not the plan's own — links that voyage to the plan's voyage in both
    directions via ``plan_links.link_build_voyage``. A link that cannot be
    written is reported on the result, not raised: the order and its attach
    already stand.
    """
    from maestro.core import order_create, plan_links
    from maestro.core.order_ids import lock_for_allocation

    voyage_id = (voyage_id or "").strip()
    voyage_branch = (voyage_branch or "").strip()
    plan_link = plan_links.resolve_plan_link(mso, plan_order_id=plan_order)
    if plan_link is not None:
        extra = dict(create_kwargs.get("extra") or {})
        extra[plan_links.PLAN_ORDER_FIELD] = plan_link.plan_order_id
        create_kwargs["extra"] = extra

    if voyage_id:
        loaded = load_voyage(mso, voyage_id)
        if loaded.archived:
            raise VoyageArchived(loaded.voyage_id)
        voyage_id = loaded.voyage_id
        manifest_branch = str(loaded.voyage.get("branch") or "").strip()
        if manifest_branch:
            if voyage_branch and voyage_branch != manifest_branch:
                raise OrderValidationError(
                    f"voyageBranch '{voyage_branch}' disagrees with voyage "
                    f"{voyage_id}'s branch '{manifest_branch}' - omit it and "
                    "the manifest's branch is used")
            voyage_branch = manifest_branch

    created = order_create.create_order(
        mso, voyage_id=voyage_id, voyage_branch=voyage_branch, **create_kwargs)

    # `create_order` falls back to the dict it INTENDED to write if its re-read
    # fails. Right for its own contract, not right for a caller about to tell
    # an operator the order exists - and never a reason to touch a manifest.
    if not Path(created.path).exists():
        raise OrderNotWritten(created.order_id, created.path)

    if not voyage_id:
        return CreatedVoyageOrder(created=created)

    try:
        with lock_for_allocation(Path(mso)):
            updated = attach_order(
                mso, voyage_id, created.order_id,
                title=str(created.order.get("title") or ""))
    except Exception as exc:   # noqa: BLE001 - re-raised as VoyageAttachFailed
        undo_failed = rollback_created_order(mso, created)
        message = "Order {} could not be attached to {}: {} - {}".format(
            created.order_id, voyage_id, exc,
            undo_failed or "nothing was created.")
        raise VoyageAttachFailed(
            message, order_id=created.order_id, voyage_id=voyage_id,
            cause=exc, rollback_incomplete=undo_failed) from exc

    order_ids = list(updated.order_ids)
    if created.order_id not in order_ids:
        # attach_order returned without raising and the manifest still does not
        # list the order. Never a success: an operator told an order is in a
        # voyage that cannot see it is BUG-MSO-2026-0555 moved one layer down.
        undo_failed = rollback_created_order(mso, created)
        raise VoyageAttachFailed(
            "Voyage {}'s manifest does not list {} after attaching - check "
            "{}. {}".format(voyage_id, created.order_id, updated.path,
                            undo_failed or "Nothing was created."),
            order_id=created.order_id, voyage_id=voyage_id, cause=None,
            rollback_incomplete=undo_failed)

    result = CreatedVoyageOrder(created=created, voyage_id=voyage_id,
                                attached=True, voyage_order_ids=order_ids)
    if (plan_link is not None and plan_link.plan_voyage_id
            and plan_link.plan_voyage_id != voyage_id):
        try:
            result.plan_link = plan_links.link_build_voyage(
                mso, voyage_id, plan_order_id=plan_link.plan_order_id,
                plan_voyage_id=plan_link.plan_voyage_id)
        except Exception as exc:   # noqa: BLE001 - reported on the result
            result.plan_link_error = str(exc) or type(exc).__name__
    return result


def detach_order(mso: Path, voyage_id: str, order_id: str, *,
                 missing_ok: bool = False) -> UpdatedVoyage:
    """Remove *order_id* from *voyage_id*'s ``orders[]``.

    Removes string and dict entries alike, so a manifest hand-written in either
    shape detaches correctly. An order that is not in the manifest raises
    :class:`VoyageOrderRefused` (409) — matching ``mso order remove
    --from-voyage``'s existing refusal, which exists so a typo'd id is not
    silently reported as removed — unless *missing_ok* is set, which returns
    ``changed=False`` instead.

    This function does **not** touch the skip list; ``mso order remove`` layers
    ``fleet_runner.add_skipped_order`` on top, because detaching from a manifest
    and vetoing dispatch are two different decisions.
    """
    order_id = (order_id or "").strip()
    if not order_id:
        raise OrderValidationError("Order ID is required")

    with workspace_scope(Path(mso)):
        loaded = load_voyage(mso, voyage_id)
        if loaded.archived:
            raise VoyageOrderRefused(
                loaded.voyage_id, order_id,
                f"Voyage {loaded.voyage_id} is archived — its manifest is a "
                "completion record and must not be rewritten.",
            )
        voyage = loaded.voyage
        kept: List[Any] = []
        found = False
        for entry in voyage.get("orders", []) or []:
            if isinstance(entry, str):
                eid = entry
            elif isinstance(entry, dict):
                eid = entry.get("orderId") or entry.get("id") or ""
            else:
                eid = ""
            if eid == order_id:
                found = True
            else:
                kept.append(entry)

        if not found:
            if missing_ok:
                return UpdatedVoyage(
                    voyage_id=loaded.voyage_id, path=loaded.path, voyage=voyage,
                    order_ids=voyage_order_ids(voyage), changed=False)
            raise VoyageOrderRefused(
                loaded.voyage_id, order_id,
                f"Order {order_id} not found in {loaded.voyage_id} orders[].",
                hint=f"Check the voyage manifest with 'mso voyage status "
                     f"{loaded.voyage_id}'",
            )

        voyage["orders"] = kept
        _save_voyage(loaded.path, voyage)
        return UpdatedVoyage(
            voyage_id=loaded.voyage_id, path=loaded.path, voyage=voyage,
            order_ids=voyage_order_ids(voyage), changed=True)


# ---------------------------------------------------------------------------
# record_voyage_supersession (BUG-MSO-2026-0637)
# ---------------------------------------------------------------------------

class VoyageSupersessionConflict(Exception):
    """The voyage already records a DIFFERENT superseding PR (-> HTTP 409).

    Re-pointing a recorded supersession is a correction, not a routine write,
    so it takes ``force=True`` rather than silently overwriting the record.
    """

    def __init__(self, voyage_id: str, recorded: int, requested: int) -> None:
        self.voyage_id = voyage_id
        self.recorded = recorded
        self.requested = requested
        super().__init__(
            f"Voyage {voyage_id} already records PR #{recorded} as its superseding "
            f"PR, not #{requested}.")


@dataclass
class SupersededVoyage:
    voyage_id: str
    path: Path
    voyage: Dict[str, Any]
    supersession: Dict[str, Any]
    repo: str
    changed: bool


# Flags reconcile wrote BECAUSE the original PR closed unmerged. Recording that
# the closure was a supersession explains them away; if the superseding PR is
# also closed unmerged, the next reconcile re-flags the voyage from scratch.
_CLOSED_PR_FLAGS = ("closedWithoutMerge", "needsAttention", "attentionReason")


def record_voyage_supersession(mso: Path, voyage_id: str, superseding_pr: Any, *,
                               superseding_url: str = "", note: str = "",
                               repo: str = "", force: bool = False) -> SupersededVoyage:
    """Record that *voyage_id*'s work shipped under PR *superseding_pr*.

    Writes the canonical ``pr_supersession`` shape: ``prNumber``/``prUrl`` name
    the superseding PR and ``supersededPrNumber``/``supersededPrUrl`` keep the
    original visible. Merge state is NOT written here — ``mso voyage
    reconcile`` resolves it from the superseding PR through the one resolver
    (``fleet_runner.resolve_voyage_merge_state``), so an unmerged or closed
    superseding PR is refused exactly as the original would have been.

    Allowed on an archived voyage: a supersession corrects which PR the
    completion record names, which is precisely the record that was wrong
    (VOY-MSO-2026-0151/0155/0157). Idempotent when the same PR is recorded
    again.

    For a multi-repo voyage *repo* is required and the record goes on that
    ``prUrls[repo]`` entry. Raises ``OrderValidationError`` (400),
    :class:`VoyageNotFound` (404), :class:`VoyageSupersessionConflict` (409) and
    ``CapabilityDenied`` (403, governed workspaces lacking ``voyage.create``).
    """
    from maestro.core.pr_supersession import (
        _as_pr_int, _url_number, pr_url_with_number, stamp_supersession,
        supersession_of,
    )
    from maestro.identity.gate import require_capability

    # Recording a supersession rewrites a voyage manifest's PR linkage — the
    # same authoring authority as creating the voyage.
    require_capability("voyage.create", workspace=Path(mso).parent)

    new = _as_pr_int(superseding_pr)
    if new is None:
        raise OrderValidationError(
            f"Superseding PR must be a positive PR number, got {superseding_pr!r}")
    superseding_url = (superseding_url or "").strip()
    if superseding_url and _url_number(superseding_url) != new:
        raise OrderValidationError(
            f"--url {superseding_url} does not end in PR number {new}")
    repo = (repo or "").strip()

    with workspace_scope(Path(mso)):
        loaded = load_voyage(mso, voyage_id)
        voyage = loaded.voyage

        slugs: List[str] = []
        for r in list(voyage.get("targetRepos") or []) + list(
                (voyage.get("prUrls") or {}).keys() if isinstance(voyage.get("prUrls"), dict) else []):
            if isinstance(r, str) and r and r not in slugs:
                slugs.append(r)
        multi = len(slugs) > 1
        if multi and not repo:
            raise OrderValidationError(
                f"Voyage {loaded.voyage_id} spans {len(slugs)} repos — name the repo "
                f"whose PR was superseded (--repo; one of: {', '.join(slugs)})")
        if repo and slugs and repo not in slugs:
            raise OrderValidationError(
                f"Voyage {loaded.voyage_id} has no repo '{repo}' (repos: {', '.join(slugs)})")

        prurls = voyage.get("prUrls") if isinstance(voyage.get("prUrls"), dict) else {}
        target_repo = repo or (slugs[0] if len(slugs) == 1 else "")
        entry = prurls.get(target_repo) if target_repo and isinstance(
            prurls.get(target_repo), dict) else None
        record = entry if multi else voyage

        existing = supersession_of(record)
        if existing is None and not multi and entry is not None:
            existing = supersession_of(entry)
        if existing is not None and existing["supersedingPrNumber"] != new and not force:
            raise VoyageSupersessionConflict(
                loaded.voyage_id, existing["supersedingPrNumber"], new)

        if existing is not None:
            original = existing["originalPrNumber"]
            original_url = existing["originalPrUrl"]
        else:
            original = (_as_pr_int(record.get("prNumber"))
                        or _as_pr_int(record.get("mergedPR"))
                        or _url_number(record.get("prUrl")))
            original_url = record.get("prUrl") if _url_number(record.get("prUrl")) == original else None
        if original is None:
            raise OrderValidationError(
                f"Voyage {loaded.voyage_id} has no PR recorded"
                f"{f' for {repo}' if repo else ''} — there is nothing to supersede. "
                "Link the PR the work shipped under instead.")
        if original == new:
            raise OrderValidationError(
                f"PR #{new} is already the voyage's own PR — a PR cannot supersede itself")

        sup = {
            "originalPrNumber": original,
            "originalPrUrl": original_url or pr_url_with_number(superseding_url, original),
            "supersedingPrNumber": new,
            "supersedingPrUrl": superseding_url or pr_url_with_number(original_url, new),
            "note": (note or "").strip() or (existing or {}).get("note"),
        }

        changed = stamp_supersession(record, sup)
        if not multi and entry is not None and entry.get("prNumber") in (None, original, new):
            # Keep a single-repo voyage's one prUrls entry naming the same PR
            # as its flat fields — the drift LEAD's hand correction left behind.
            changed = stamp_supersession(entry, sup) or changed
        for key in _CLOSED_PR_FLAGS:
            if key in voyage:
                del voyage[key]
                changed = True
        if changed:
            _save_voyage(loaded.path, voyage)
        return SupersededVoyage(
            voyage_id=loaded.voyage_id, path=loaded.path, voyage=voyage,
            supersession=sup, repo=target_repo, changed=changed)
