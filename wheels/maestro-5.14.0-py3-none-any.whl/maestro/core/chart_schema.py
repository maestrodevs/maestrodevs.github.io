"""maestro/core/chart_schema.py — Maestro Charts Phase 2: the chart artefact schema.

FTR-MSO-2026-0517 (PLAN-PLN-MSO-2026-0508 section 3, order 1 of 8). Defines the
durable chart artefact (``.mso/charts/CHT-{PRJ}-{YEAR}-{SEQ}.json``) that later
orders in this phase read and mutate: the frontier scheduler, the typed
failure-edge router, and the carry-context resolver. This module ships
strictly the model + loader + validator — no dispatch code path is touched or
imported from here, and nothing in this module is called from the dispatch
loop (mirrors the read-only promise ``charts.py`` makes for Phase 1, though
this module is not itself read-only — it is simply never *called* from
dispatch yet; that wiring is order 4, behind ``charts.enabled``).

Three entry points, per the plan:

  * :func:`load_chart` — parse a chart JSON file into a :class:`ChartSpec`.
    A pure, offline parse; it does not validate and does not touch the
    workspace beyond reading the one file.
  * :func:`validate` — run rules V1-V10 (plan section 3.3) against a loaded
    :class:`ChartSpec`, returning a list of :class:`ValidationIssue`. Most
    rules are purely structural (offline); V5/V6 (role-sequence membership)
    and the cross-file half of V8 (one ACTIVE chart per voyage) additionally
    consult the workspace when *workspace_dir* is supplied — when it is not,
    those specific checks are skipped rather than guessed at, so a bare
    ``validate(chart)`` call always stays offline-safe (plan section 8: "a
    chart must stay validatable offline"). V4 (order-id existence) is
    deliberately never checked here at all — the plan reserves that for load
    time in a later order, not validation.
  * :func:`charts_for_voyage` — list every chart on the artefact plane whose
    ``voyageId`` matches, for the frontier scheduler (order 4) to consume.

Field reference, validation rules, and execution semantics are documented in
full in PLAN-PLN-MSO-2026-0508.md sections 3.2-3.3 — this module implements
that specification field for field; where anything here needed a judgement
call the plan left implicit, it is called out in a comment at the point of
the decision.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

# ---------------------------------------------------------------------------
# Schema constants (plan section 3.2 field reference)
# ---------------------------------------------------------------------------

SCHEMA_VERSION = 1

CHART_ID_RE = re.compile(r"^CHT-[A-Z0-9]{2,10}-\d{4}-\d{4,}$")
# Syntactic order-id shape only (V4) — TYPE-PRJ-YEAR-SEQ, e.g. FTR-MSO-2026-0601
# or the legacy FTR-ADM-2026-0034. Existence is deliberately not this module's
# job (plan section 8).
ORDER_ID_RE = re.compile(r"^[A-Z]{2,6}-[A-Z0-9]{2,10}-\d{4}-\d{4,}$")
VOYAGE_ID_RE = re.compile(r"^VOY-[A-Z0-9]{2,10}-\d{4}-\d{4,}$")

EDGE_TYPES = frozenset({"onSuccess", "onFail"})
# Phase 3 vocabulary (plan section 3.2) — refused by name, never a shrug (V9).
_PHASE3_EDGE_TYPES = frozenset({"onVerdict", "fanIn", "panel"})

CAUSES = frozenset({"VERIFY_FAILED", "VERDICT_FAIL", "ANY"})
DEFAULT_CAUSE = "ANY"

CARRY_KINDS = frozenset({"none", "verifyLog", "qaReport", "handoff"})
DEFAULT_CARRY = "none"

ON_EXHAUSTED_KINDS = frozenset({"humanGate", "stalled"})
DEFAULT_ON_EXHAUSTED = "humanGate"

CHART_STATUSES = frozenset({"ACTIVE", "PAUSED", "COMPLETE"})
DEFAULT_STATUS = "ACTIVE"

RESERVED_SINKS = frozenset({"@humanGate", "@stalled"})

MAX_LAPS_MIN = 1
MAX_LAPS_MAX = 5

CHARTS_SUBDIR = "charts"


# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------

@dataclass
class ChartNode:
    """One chart node ("waypoint"): a single role-step of a single order."""

    order: str
    role: str

    def to_dict(self) -> Dict[str, Any]:
        return {"order": self.order, "role": self.role}

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ChartNode":
        return cls(order=str(data.get("order", "")), role=str(data.get("role", "")))


@dataclass
class ChartEdge:
    """One chart edge ("leg"). ``to`` keeps its raw JSON shape (a single
    nodeKey, a fan-out list, or a reserved ``@`` sink) so round-tripping
    through :meth:`to_dict` never rewrites an author's file; :attr:`targets`
    normalises it to a list for graph algorithms."""

    from_node: str
    to: Union[str, List[str]]
    type: str
    cause: str = DEFAULT_CAUSE
    max_laps: Optional[int] = None
    carry: str = DEFAULT_CARRY
    on_exhausted: str = DEFAULT_ON_EXHAUSTED

    @property
    def targets(self) -> List[str]:
        raw = self.to if isinstance(self.to, list) else [self.to]
        # A well-formed target is always a nodeKey string. A hand-authored
        # "to" list can carry any JSON type per element (number, bool, null,
        # a nested object/array) — none of those can ever match a declared
        # nodeKey, but an unstringified dict/list is unhashable and crashes
        # every `t in chart.nodes` membership check below (V3/V6/V7/V8/V10).
        # Stringify anything non-str so it stays hashable and V3 reports it
        # as an unresolved target instead of raising.
        return [t if isinstance(t, str) else repr(t) for t in raw]

    def to_dict(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {"from": self.from_node, "to": self.to, "type": self.type}
        if self.cause != DEFAULT_CAUSE:
            d["cause"] = self.cause
        if self.max_laps is not None:
            d["maxLaps"] = self.max_laps
        if self.carry != DEFAULT_CARRY:
            d["carry"] = self.carry
        if self.on_exhausted != DEFAULT_ON_EXHAUSTED:
            d["onExhausted"] = self.on_exhausted
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ChartEdge":
        to_raw = data.get("to")
        return cls(
            from_node=str(data.get("from", "")),
            to=list(to_raw) if isinstance(to_raw, list) else str(to_raw or ""),
            type=str(data.get("type", "")),
            cause=str(data.get("cause", DEFAULT_CAUSE)),
            max_laps=data.get("maxLaps"),
            carry=str(data.get("carry", DEFAULT_CARRY)),
            on_exhausted=str(data.get("onExhausted", DEFAULT_ON_EXHAUSTED)),
        )


@dataclass
class ChartSpec:
    """A schema-v1 chart artefact — the durable, hand-authored (until Phase 4)
    unit the frontier scheduler and failure router read."""

    chart_id: str
    schema_version: int
    voyage_id: str
    nodes: Dict[str, ChartNode] = field(default_factory=dict)
    edges: List[ChartEdge] = field(default_factory=list)
    title: str = ""
    status: str = DEFAULT_STATUS

    def to_dict(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {
            "chartId": self.chart_id,
            "schemaVersion": self.schema_version,
            "voyageId": self.voyage_id,
            "status": self.status,
            "nodes": {k: v.to_dict() for k, v in self.nodes.items()},
            "edges": [e.to_dict() for e in self.edges],
        }
        if self.title:
            d["title"] = self.title
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ChartSpec":
        nodes = {
            str(k): ChartNode.from_dict(v)
            for k, v in (data.get("nodes") or {}).items()
        }
        edges = [ChartEdge.from_dict(e) for e in (data.get("edges") or [])]
        return cls(
            chart_id=str(data.get("chartId", "")),
            schema_version=int(data.get("schemaVersion") or 0),
            voyage_id=str(data.get("voyageId", "")),
            nodes=nodes,
            edges=edges,
            title=str(data.get("title", "")),
            status=str(data.get("status") or DEFAULT_STATUS),
        )


@dataclass
class ValidationIssue:
    """One V1-V10 rule violation."""

    rule: str
    message: str

    def __str__(self) -> str:  # pragma: no cover - trivial
        return f"{self.rule}: {self.message}"


# ---------------------------------------------------------------------------
# load_chart — pure, offline parse
# ---------------------------------------------------------------------------

def load_chart(path: Union[str, Path]) -> ChartSpec:
    """Parse a chart JSON file into a :class:`ChartSpec`. Does not validate."""
    p = Path(path)
    data = json.loads(p.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError(f"chart file {p} does not contain a JSON object")
    return ChartSpec.from_dict(data)


# ---------------------------------------------------------------------------
# Offline order-role helpers (V5/V6) — best-effort, workspace_dir optional
# ---------------------------------------------------------------------------

def _resolve_workspace_role_sequences(ws: Path) -> "tuple[Dict[str, List[str]], Optional[str]]":
    """Resolve *ws*'s own ``orders/templates`` role-sequence default map —
    computed ONCE per :func:`validate` call and threaded down to every node,
    never re-derived per node.

    BUG-MSO-2026-0608 finding 2: the pre-fix code called
    ``charts.resolve_role_sequence(order_data)`` with no ``role_sequences``
    map at all, so it fell back to fleet_runner's PROCESS-GLOBAL
    ``ROLE_SEQUENCES`` cache (reintroducing BUG-MSO-2026-0515) — reading
    whichever workspace happened to populate that cache first, or raising
    ``get_artefact_root()``'s ``FileNotFoundError`` when nothing had, which a
    blanket ``except Exception`` then swallowed into a silent skip. This
    helper always goes through ``charts._workspace_role_sequences``, which
    threads *ws* explicitly into ``fleet_runner.load_role_sequences`` and so
    never touches the process global and never calls ``get_artefact_root()``.

    Returns ``(role_sequences, error)`` — *error* is ``None`` on success.
    A non-``None`` *error* means the workspace's OWN templates could not be
    read (a genuine infrastructure failure, not "this one order wasn't
    found") — the caller reports this as a single V5/V6 issue rather than
    silently resolving nothing for every node in the chart (AC: "V5/V6 are
    never silently skipped ... an unresolvable workspace is reported, not
    swallowed").
    """
    from maestro.core import charts as _charts

    try:
        return _charts._workspace_role_sequences(ws), None
    except Exception as exc:
        return {}, str(exc)


def _resolve_order_role_sequence(order_id: str, workspace_dir: Optional[Path],
                                  role_sequences: Dict[str, List[str]]) -> List[str]:
    """Resolve *order_id*'s real roleSequence by loading its order file,
    against the ALREADY-RESOLVED *role_sequences* workspace map (see
    :func:`_resolve_workspace_role_sequences` — the caller computes this once
    and reports a failure there, never here).

    Returns ``[]`` if *workspace_dir* is not supplied or the order itself
    cannot be found/loaded — the caller treats that as "cannot verify this
    one order", never as a chart violation. This is deliberately the ONLY
    remaining best-effort swallow in this path: an order-lookup failure is a
    legitimate "nothing to check" (the order may not exist yet, or may have
    been archived/skipped), unlike a workspace-level template-read failure,
    which is reported by the caller instead.
    """
    if workspace_dir is None:
        return []
    from maestro.core import charts as _charts

    try:
        order_data = _charts._load_order_data(order_id, workspace_dir)
    except Exception:
        return []
    if order_data is None:
        return []
    return _charts.resolve_role_sequence(order_data, role_sequences)


# ---------------------------------------------------------------------------
# Cycle detection — Tarjan SCC (V7, V10)
# ---------------------------------------------------------------------------

def _tarjan_scc(node_keys: List[str], adjacency: Dict[str, List[str]]) -> Dict[str, int]:
    """Iterative Tarjan's strongly-connected-components algorithm.

    Returns ``{node_key: component_id}``. Iterative (explicit stack of
    resumable iterators) rather than recursive so an unusually large chart
    can never hit Python's recursion limit.
    """
    index_of: Dict[str, int] = {}
    lowlink: Dict[str, int] = {}
    on_stack: Dict[str, bool] = {}
    tstack: List[str] = []
    comp_of: Dict[str, int] = {}
    counter = [0]
    next_comp = [0]

    for root in node_keys:
        if root in index_of:
            continue
        index_of[root] = counter[0]
        lowlink[root] = counter[0]
        counter[0] += 1
        tstack.append(root)
        on_stack[root] = True
        frames: List[Any] = [(root, iter(adjacency.get(root, [])))]

        while frames:
            v, it = frames[-1]
            descended = False
            for w in it:
                if w not in index_of:
                    index_of[w] = counter[0]
                    lowlink[w] = counter[0]
                    counter[0] += 1
                    tstack.append(w)
                    on_stack[w] = True
                    frames.append((w, iter(adjacency.get(w, []))))
                    descended = True
                    break
                elif on_stack.get(w):
                    lowlink[v] = min(lowlink[v], index_of[w])
            if descended:
                continue
            frames.pop()
            if frames:
                parent = frames[-1][0]
                lowlink[parent] = min(lowlink[parent], lowlink[v])
            if lowlink[v] == index_of[v]:
                cid = next_comp[0]
                next_comp[0] += 1
                while True:
                    w = tstack.pop()
                    on_stack[w] = False
                    comp_of[w] = cid
                    if w == v:
                        break

    return comp_of


def _build_adjacency(chart: ChartSpec, types: Optional[frozenset] = None) -> Dict[str, List[str]]:
    """Adjacency over declared node keys only — reserved ``@`` sinks and any
    target that does not resolve to a declared node (a separate V3 violation)
    can never participate in a graph-cycle check."""
    adj: Dict[str, List[str]] = {k: [] for k in chart.nodes}
    for e in chart.edges:
        if types is not None and e.type not in types:
            continue
        if e.from_node not in chart.nodes:
            continue
        for t in e.targets:
            if t in chart.nodes:
                adj[e.from_node].append(t)
    return adj


def _cyclic_components(comp_of: Dict[str, int], adjacency: Dict[str, List[str]]) -> frozenset:
    """Component ids that are genuinely cyclic: size > 1, or a single node
    with a self-loop (Tarjan alone cannot distinguish a self-loop singleton
    from an ordinary acyclic singleton)."""
    members: Dict[int, List[str]] = {}
    for node, cid in comp_of.items():
        members.setdefault(cid, []).append(node)
    self_loop_nodes = {n for n, targets in adjacency.items() if n in targets}
    cyclic = set()
    for cid, ms in members.items():
        if len(ms) > 1 or (len(ms) == 1 and ms[0] in self_loop_nodes):
            cyclic.add(cid)
    return frozenset(cyclic)


# ---------------------------------------------------------------------------
# validate() — V1-V10
# ---------------------------------------------------------------------------

def validate(
    chart: ChartSpec,
    path: Optional[Union[str, Path]] = None,
    workspace_dir: Optional[Union[str, Path]] = None,
) -> List[ValidationIssue]:
    """Run rules V1-V10 (plan section 3.3) against *chart*.

    *path* enables the filename-stem half of V1. *workspace_dir* enables the
    workspace-consulting parts of V5/V6 (role-sequence membership) and V8
    (one ACTIVE chart per voyageId across ``charts/``); omitting it skips
    exactly those sub-checks rather than guessing — every other rule is
    checked unconditionally and purely from *chart* itself.
    """
    path_p = Path(path) if path is not None else None
    ws_p = Path(workspace_dir) if workspace_dir is not None else None

    issues: List[ValidationIssue] = []
    issues.extend(_check_v1_chart_id(chart, path_p))
    issues.extend(_check_v2_schema_version(chart))
    issues.extend(_check_v3_edge_targets(chart))
    issues.extend(_check_v4_order_id_syntax(chart))
    issues.extend(_check_v5_role_membership(chart, ws_p))
    issues.extend(_check_v6_forward_routing(chart, ws_p))
    issues.extend(_check_v7_v10_cycles(chart))
    issues.extend(_check_v8_entry_reachability_and_voyage_uniqueness(chart, ws_p))
    issues.extend(_check_v9_enum_membership(chart))
    return issues


def _check_v1_chart_id(chart: ChartSpec, path: Optional[Path]) -> List[ValidationIssue]:
    issues: List[ValidationIssue] = []
    if not CHART_ID_RE.match(chart.chart_id or ""):
        issues.append(ValidationIssue(
            "V1", f"chartId '{chart.chart_id}' is not well-formed "
                  f"(expected CHT-{{PRJ}}-{{YEAR}}-{{SEQ}})"))
    elif path is not None and path.stem != chart.chart_id:
        issues.append(ValidationIssue(
            "V1", f"chartId '{chart.chart_id}' does not match filename stem "
                  f"'{path.stem}'"))
    return issues


def _check_v2_schema_version(chart: ChartSpec) -> List[ValidationIssue]:
    if chart.schema_version == SCHEMA_VERSION:
        return []
    if chart.schema_version > SCHEMA_VERSION:
        msg = (f"schemaVersion {chart.schema_version} requires a newer Maestro "
               f"release (this build supports schema v{SCHEMA_VERSION})")
    else:
        msg = f"unsupported schemaVersion {chart.schema_version} (must be {SCHEMA_VERSION})"
    return [ValidationIssue("V2", msg)]


def _check_v3_edge_targets(chart: ChartSpec) -> List[ValidationIssue]:
    issues: List[ValidationIssue] = []
    for e in chart.edges:
        if e.from_node not in chart.nodes:
            issues.append(ValidationIssue(
                "V3", f"edge from '{e.from_node}' does not resolve to a declared "
                      f"nodeKey"))
        for t in e.targets:
            if t in chart.nodes or t in RESERVED_SINKS:
                continue
            issues.append(ValidationIssue(
                "V3", f"edge {e.from_node}->{t} does not resolve to a declared "
                      f"nodeKey or a reserved sink"))
        # BUG-MSO-2026-0551 Finding 4: onFail has no fan-out semantics — a
        # failing node has exactly one next destination (a lap target or a
        # sink), unlike onSuccess's "wait for ALL in-edges" model, which is
        # what makes fan-out meaningful there. chart_routing.route_failure
        # only ever acted on targets[0] and silently discarded the rest;
        # rather than leave that discard implicit, reject a multi-target
        # onFail edge outright at validation time so an author gets a named
        # error instead of quietly-dropped destinations. Split into separate
        # onFail edges (e.g. one per cause) if a chart genuinely needs more
        # than one failure destination.
        if e.type == "onFail" and len(e.targets) > 1:
            issues.append(ValidationIssue(
                "V3", f"onFail edge from '{e.from_node}' has {len(e.targets)} "
                      f"targets {list(e.targets)} — onFail supports exactly "
                      f"one target (fan-out is only defined for onSuccess); "
                      f"split into separate onFail edges instead"))
        # BUG-MSO-2026-0608 finding 7: the sibling gap to the check above —
        # an onFail edge authored with an EMPTY target list (``"to": []``)
        # produced ZERO V3 issues (the old rule only ever rejected MORE than
        # one target, never zero), then chart_routing.route_failure's
        # ``edge.targets[0]`` raised IndexError at runtime, swallowed by its
        # own blanket except into a silent no-op. onFail requires exactly
        # one target — reject zero exactly as symmetrically as more-than-one.
        elif e.type == "onFail" and len(e.targets) == 0:
            issues.append(ValidationIssue(
                "V3", f"onFail edge from '{e.from_node}' has no targets — "
                      f"onFail requires exactly one target (a nodeKey or a "
                      f"reserved sink); an edge with an empty 'to' list can "
                      f"never route at runtime"))
    return issues


def _check_v4_order_id_syntax(chart: ChartSpec) -> List[ValidationIssue]:
    issues: List[ValidationIssue] = []
    for key, node in chart.nodes.items():
        if not ORDER_ID_RE.match(node.order or ""):
            issues.append(ValidationIssue(
                "V4", f"node '{key}' order '{node.order}' is not a syntactically "
                      f"valid order id"))
    return issues


def _check_v5_role_membership(chart: ChartSpec, ws: Optional[Path]) -> List[ValidationIssue]:
    issues: List[ValidationIssue] = []

    # Offline half: no two nodes may share the same (order, role) pair.
    seen: Dict[tuple, List[str]] = {}
    for key, node in chart.nodes.items():
        seen.setdefault((node.order, node.role), []).append(key)
    for (order, role), keys in seen.items():
        if len(keys) > 1:
            issues.append(ValidationIssue(
                "V5", f"nodes {keys} all declare order '{order}' role '{role}' — "
                      f"a role-step may only appear once per chart"))

    # Workspace half: role must be a member of the order's resolved roleSequence.
    if ws is not None:
        role_sequences, ws_error = _resolve_workspace_role_sequences(ws)
        if ws_error is not None:
            issues.append(ValidationIssue(
                "V5", f"could not resolve role-sequence templates for "
                      f"workspace '{ws}' ({ws_error}) — role membership was "
                      f"NOT checked for any node in this chart"))
        else:
            for key, node in chart.nodes.items():
                sequence = _resolve_order_role_sequence(node.order, ws, role_sequences)
                if sequence and node.role not in sequence:
                    issues.append(ValidationIssue(
                        "V5", f"node '{key}' role '{node.role}' is not in order "
                              f"'{node.order}'s roleSequence {sequence}"))
    return issues


def _check_v6_forward_routing(chart: ChartSpec, ws: Optional[Path]) -> List[ValidationIssue]:
    """A chart routes BETWEEN an order's existing role-steps; it never
    invents a jump. For an onSuccess edge whose endpoints share the same
    order, the target role must come strictly after the source role in that
    order's own roleSequence — only onFail may go backward (V10 makes the
    complementary claim about full cycles)."""
    issues: List[ValidationIssue] = []
    if ws is None:
        return issues
    role_sequences, ws_error = _resolve_workspace_role_sequences(ws)
    if ws_error is not None:
        issues.append(ValidationIssue(
            "V6", f"could not resolve role-sequence templates for "
                  f"workspace '{ws}' ({ws_error}) — forward-routing was NOT "
                  f"checked for any edge in this chart"))
        return issues
    for e in chart.edges:
        if e.type != "onSuccess" or e.from_node not in chart.nodes:
            continue
        from_node = chart.nodes[e.from_node]
        for t in e.targets:
            if t not in chart.nodes:
                continue
            to_node = chart.nodes[t]
            if to_node.order != from_node.order:
                continue
            sequence = _resolve_order_role_sequence(from_node.order, ws, role_sequences)
            if not sequence or from_node.role not in sequence or to_node.role not in sequence:
                continue
            if sequence.index(to_node.role) <= sequence.index(from_node.role):
                issues.append(ValidationIssue(
                    "V6", f"onSuccess edge {e.from_node}->{t} does not advance "
                          f"order '{from_node.order}'s roleSequence {sequence} "
                          f"(role '{to_node.role}' does not come after "
                          f"'{from_node.role}')"))
    return issues


def _check_v7_v10_cycles(chart: ChartSpec) -> List[ValidationIssue]:
    issues: List[ValidationIssue] = []
    node_keys = list(chart.nodes.keys())

    full_adj = _build_adjacency(chart)
    full_comp = _tarjan_scc(node_keys, full_adj)
    full_cyclic = _cyclic_components(full_comp, full_adj)

    # V7 requires maxLaps to be PRESENT only on the edge that CLOSES the
    # cycle, not on every edge merely contained in the same SCC. A cyclic SCC
    # formed by a forward onSuccess edge plus a backward onFail edge (the
    # ordinary revision-loop shape — plan section 3.2's own canonical
    # example) never puts maxLaps on the forward onSuccess leg; only onFail
    # edges close a cycle at all (V10), so only onFail edges are checked
    # here for the "must be present" half.
    #
    # BUG-MSO-2026-0608 finding 6: the type/range checks below used to run
    # ONLY inside this cycle-closing branch, so a one-way onFail reroute (no
    # cycle — nothing REQUIRES it to declare maxLaps at all) that nonetheless
    # hand-authored a bad value — e.g. a quoted ``"maxLaps": "2"`` — passed
    # validation clean, then chart_routing._route_failure_inner's
    # ``current_laps >= max_laps`` raised TypeError comparing int against
    # str, swallowed by route_failure's own blanket except into total
    # silence. A malformed maxLaps is malformed regardless of whether the
    # edge happens to close a cycle, so every onFail edge that DECLARES a
    # maxLaps at all (present, non-None) now gets the same type/range check —
    # only the "must be present" requirement stays scoped to cycle-closing
    # edges (plan §3.2 never requires a one-way reroute to declare one).
    flagged_edges: set = set()
    for e in chart.edges:
        if e.type != "onFail" or e.from_node not in chart.nodes:
            continue
        for t in e.targets:
            if t not in chart.nodes:
                continue
            key = (e.from_node, t, e.type, e.cause)
            if key in flagged_edges:
                continue
            closes_cycle = (
                full_comp.get(e.from_node) == full_comp.get(t)
                and full_comp.get(e.from_node) in full_cyclic
            )
            ml = e.max_laps
            if ml is None:
                if closes_cycle:
                    issues.append(ValidationIssue(
                        "V7", f"edge {e.from_node}->{t} closes a cycle but "
                              f"has no maxLaps in {MAX_LAPS_MIN}..{MAX_LAPS_MAX}"))
                    flagged_edges.add(key)
                continue  # non-cycle edge with no maxLaps: nothing required
            if not isinstance(ml, int) or isinstance(ml, bool):
                # A hand-typed chart can put any JSON type on maxLaps (a
                # quoted "2" is the expected slip — plan §6 makes
                # hand-authoring the supported story until Phase 4). Ordering
                # int against a non-int (e.g. str) raises TypeError, so the
                # type must be checked before the range comparison below.
                issues.append(ValidationIssue(
                    "V7", f"edge {e.from_node}->{t} maxLaps must be an integer "
                          f"in {MAX_LAPS_MIN}..{MAX_LAPS_MAX}, got "
                          f"{type(ml).__name__} {ml!r}"))
                flagged_edges.add(key)
            elif not (MAX_LAPS_MIN <= ml <= MAX_LAPS_MAX):
                issues.append(ValidationIssue(
                    "V7", f"edge {e.from_node}->{t} maxLaps {ml} is out of "
                          f"range {MAX_LAPS_MIN}..{MAX_LAPS_MAX}"))
                flagged_edges.add(key)

    onsuccess_adj = _build_adjacency(chart, types=frozenset({"onSuccess"}))
    onsuccess_comp = _tarjan_scc(node_keys, onsuccess_adj)
    onsuccess_cyclic = _cyclic_components(onsuccess_comp, onsuccess_adj)

    flagged_v10: set = set()
    for e in chart.edges:
        if e.type != "onSuccess" or e.from_node not in chart.nodes:
            continue
        for t in e.targets:
            if t not in chart.nodes:
                continue
            if onsuccess_comp.get(e.from_node) != onsuccess_comp.get(t):
                continue
            if onsuccess_comp[e.from_node] not in onsuccess_cyclic:
                continue
            key = (e.from_node, t)
            if key in flagged_v10:
                continue
            issues.append(ValidationIssue(
                "V10", f"onSuccess edge {e.from_node}->{t} closes a cycle — "
                       f"only onFail edges may close a cycle"))
            flagged_v10.add(key)

    return issues


def _check_v8_entry_reachability_and_voyage_uniqueness(
    chart: ChartSpec, ws: Optional[Path]
) -> List[ValidationIssue]:
    issues: List[ValidationIssue] = []
    node_keys = list(chart.nodes.keys())

    onsuccess_adj = _build_adjacency(chart, types=frozenset({"onSuccess"}))
    indegree: Dict[str, int] = {k: 0 for k in node_keys}
    for src, targets in onsuccess_adj.items():
        for t in targets:
            indegree[t] = indegree.get(t, 0) + 1
    entries = [k for k in node_keys if indegree.get(k, 0) == 0]

    if len(entries) != 1:
        issues.append(ValidationIssue(
            "V8", f"expected exactly one entry node (in-degree 0 across onSuccess "
                  f"edges), found {len(entries)}: {sorted(entries)}"))
    else:
        entry = entries[0]
        full_adj = _build_adjacency(chart)
        reached = {entry}
        frontier = [entry]
        while frontier:
            cur = frontier.pop()
            for nxt in full_adj.get(cur, []):
                if nxt not in reached:
                    reached.add(nxt)
                    frontier.append(nxt)
        unreached = sorted(set(node_keys) - reached)
        if unreached:
            issues.append(ValidationIssue(
                "V8", f"node(s) {unreached} are not reachable from entry '{entry}'"))

    if ws is not None and chart.status == "ACTIVE" and chart.voyage_id:
        charts_dir = ws / CHARTS_SUBDIR
        if charts_dir.is_dir():
            for f in sorted(charts_dir.glob("*.json")):
                if f.stem == chart.chart_id:
                    continue
                try:
                    other = load_chart(f)
                except Exception:
                    continue
                if other.status == "ACTIVE" and other.voyage_id == chart.voyage_id:
                    issues.append(ValidationIssue(
                        "V8", f"voyage '{chart.voyage_id}' already has an ACTIVE "
                              f"chart '{other.chart_id}' — only one ACTIVE chart "
                              f"per voyage is allowed"))
    return issues


def _check_v9_enum_membership(chart: ChartSpec) -> List[ValidationIssue]:
    issues: List[ValidationIssue] = []
    for e in chart.edges:
        edge_label = f"{e.from_node}->{e.targets}"
        if e.type not in EDGE_TYPES:
            if e.type in _PHASE3_EDGE_TYPES:
                issues.append(ValidationIssue(
                    "V9", f"edge {edge_label} type '{e.type}' is a Phase 3 feature "
                          f"— not available until Phase 3"))
            else:
                issues.append(ValidationIssue(
                    "V9", f"edge {edge_label} has invalid type '{e.type}' "
                          f"(expected one of {sorted(EDGE_TYPES)})"))
        if e.cause not in CAUSES:
            issues.append(ValidationIssue(
                "V9", f"edge {edge_label} has invalid cause '{e.cause}' "
                      f"(expected one of {sorted(CAUSES)})"))
        if e.carry not in CARRY_KINDS:
            issues.append(ValidationIssue(
                "V9", f"edge {edge_label} has invalid carry '{e.carry}' "
                      f"(expected one of {sorted(CARRY_KINDS)})"))
        if e.on_exhausted not in ON_EXHAUSTED_KINDS:
            issues.append(ValidationIssue(
                "V9", f"edge {edge_label} has invalid onExhausted '{e.on_exhausted}' "
                      f"(expected one of {sorted(ON_EXHAUSTED_KINDS)})"))
    return issues


# ---------------------------------------------------------------------------
# charts_for_voyage — durable-plane lookup for later orders (frontier scheduler)
# ---------------------------------------------------------------------------

def charts_for_voyage(voyage_id: str, workspace_dir: Optional[Union[str, Path]] = None) -> List[ChartSpec]:
    """Every chart on the artefact plane whose ``voyageId`` matches
    *voyage_id*, sorted by ``chartId`` for a deterministic order. A chart
    file that fails to parse is skipped rather than raised — a single
    malformed chart must never take down a scan of the rest (mirrors the
    ``_load_order_data``/``_load_voyage_data`` best-effort pattern in
    charts.py). This module never calls this from dispatch itself (order 1
    ships inert); it exists for the frontier scheduler (order 4) to call."""
    if workspace_dir is not None:
        ws = Path(workspace_dir)
    else:
        from maestro.core.fleet_runner import get_artefact_root
        ws = get_artefact_root()

    charts_dir = ws / CHARTS_SUBDIR
    if not charts_dir.is_dir():
        return []

    results: List[ChartSpec] = []
    for f in sorted(charts_dir.glob("*.json")):
        try:
            spec = load_chart(f)
        except Exception:
            continue
        if spec.voyage_id == voyage_id:
            results.append(spec)
    results.sort(key=lambda c: c.chart_id)
    return results


# ---------------------------------------------------------------------------
# Authoring helpers (order 3 — `mso chart new --from-voyage`)
# ---------------------------------------------------------------------------

_NODE_KEY_RE = re.compile(r"[^a-z0-9-]+")


def next_chart_id(workspace_dir: Union[str, Path], project: str, year: str) -> str:
    """Allocate the next ``CHT-{project}-{year}-{seq}`` id, continuing past the
    highest existing sequence in the WHOLE workspace (plan section 3.1:
    "charts share the workspace sequence space with orders and voyages").

    BUG-MSO-2026-0752: this used to scan ``charts/`` alone, so a chart could
    mint a number an order or voyage already held. It now uses
    ``order_ids.highest_existing_sequence`` — the one scan the order and
    voyage allocators use too. Callers should mint and write inside
    ``order_ids.lock_for_allocation`` (``mso chart new`` does).
    """
    from maestro.core.order_ids import highest_existing_sequence

    highest = highest_existing_sequence(Path(workspace_dir), project, str(year))
    return f"CHT-{project}-{year}-{highest + 1:04d}"


def _node_key_for(order_id: str, role: str, used: set) -> str:
    """A chart-local nodeKey (``^[a-z0-9][a-z0-9-]{0,31}$``) derived from an
    ``order:role`` waypoint id, collision-safe within one chart."""
    base = _NODE_KEY_RE.sub("-", f"{order_id}-{role}".lower()).strip("-")[:32]
    if not base or base[0] not in "abcdefghijklmnopqrstuvwxyz0123456789":
        base = ("n-" + base)[:32]
    key = base
    suffix_n = 2
    while key in used:
        suffix = f"-{suffix_n}"
        key = base[: 32 - len(suffix)] + suffix
        suffix_n += 1
    used.add(key)
    return key


def from_compiled_chart(compiled: Any, chart_id: str, voyage_id: str, title: str = "") -> ChartSpec:
    """Serialise a Phase 1 ``charts.Chart`` (compiled via
    ``charts.compile_voyage_chart``) into a schema-v1 :class:`ChartSpec` —
    the ``mso chart new --from-voyage`` authoring path (plan section 6).

    Every edge is emitted as ``onSuccess`` regardless of the compiled
    chart's own leg type (``onSuccess`` role-chain legs and ``dependsOn``
    cross-order legs alike) — schema v1 has no ``dependsOn`` edge type, and
    a fresh chart with no hand-added ``onFail`` edges IS the degenerate,
    all-onSuccess chart the plan describes ("the boring 90% of a chart is
    generated from what the voyage already declares"). The operator then
    hand-adds ``onFail`` edges on top of this starting point.
    """
    key_by_node_id: Dict[str, str] = {}
    used_keys: set = set()
    nodes: Dict[str, ChartNode] = {}
    for nid, waypoint in compiled.nodes.items():
        key = _node_key_for(waypoint.order_id, waypoint.role, used_keys)
        key_by_node_id[nid] = key
        nodes[key] = ChartNode(order=waypoint.order_id, role=waypoint.role)

    edges: List[ChartEdge] = []
    for leg in compiled.edges:
        from_key = key_by_node_id.get(leg.from_node)
        to_key = key_by_node_id.get(leg.to_node)
        if from_key is None or to_key is None:
            continue
        edges.append(ChartEdge(from_node=from_key, to=to_key, type="onSuccess"))

    return ChartSpec(
        chart_id=chart_id,
        schema_version=SCHEMA_VERSION,
        voyage_id=voyage_id,
        nodes=nodes,
        edges=edges,
        title=title or f"Compiled from {voyage_id}",
        status=DEFAULT_STATUS,
    )
