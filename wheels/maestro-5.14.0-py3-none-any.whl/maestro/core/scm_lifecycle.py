"""maestro/core/scm_lifecycle.py — how the dispatcher resolves its SCM provider.

FTR-MSO-2026-0772 (PLAN-PLN-MSO-2026-0747 Order 14a). The dispatcher's PR
lifecycle (voyage branch, voyage PR, ready-for-review, merge detection) moves
onto ``resolve("scm")`` in Orders 14b/14c. This module is the dispatcher-side
half of that seam, kept out of ``fleet_runner.py`` with an explicit,
injectable surface (the ``salvage_arming`` / ``order_retry`` precedent):

* :func:`dispatcher_scm` — which provider the dispatcher uses, and whether the
  caller keeps its GitHub-only auxiliary ``gh`` calls.
* :func:`warn_once` — a process-level "say it once" registry. The caller
  passes the emitter, so this module never imports ``fleet_runner``.
* :func:`pr_record` — a provider PR dict adapted to the gh-shaped record
  ``fleet_runner`` already consumes.
* :func:`remote_branch_exists` / :func:`commits_ahead` /
  :func:`changed_file_count` — host-neutral git answers for the auxiliary
  checks the provider contract deliberately does not define (plan §2.1).

**Deliberate difference from ``resolve_explain``.** With no ``providers``
block, ``resolve_explain`` picks ``github`` only after a ``gh auth status``
probe, and ``none`` without it — right for the patrol, which reports a skip.
The dispatcher never probed: it runs ``gh`` and handles the failure. So here
an unconfigured (or ``github``-configured) workspace gets a GitHub provider
with NO probe and no ``available()`` call, which keeps the dispatcher's argv
sequence byte-identical (``tests/test_ftr_0772_golden_argv.py``).

**Imports.** ``maestro.providers`` is imported inside functions only:
``maestro/providers/scm/github.py`` imports :data:`GH_PR_BY_NUMBER_JQ` from
here, and a module-level import back would be a cycle.
"""

from __future__ import annotations

import re
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable, Hashable, Optional

if TYPE_CHECKING:  # pragma: no cover
    from maestro.providers.base import ScmProvider

#: The ``--jq`` projection ``fleet_runner._gh_pr_by_number`` asks GitHub for
#: (plan §1, G4). It lives here rather than in the GitHub provider because
#: ``tests/test_ftr_0760_provider_capabilities.py::TestNoMergePath`` audits
#: ``maestro/providers`` for any ``merge`` token other than ``merged``, and
#: this READ-only projection names GitHub's ``merge_commit_sha`` field. It is
#: the gh-shaped record's key set, which this module owns (:func:`pr_record`).
GH_PR_BY_NUMBER_JQ = (
    "{state:.state,merged:.merged,mergedAt:.merged_at,"
    "mergeCommit:.merge_commit_sha,number:.number,url:.html_url,"
    "baseRefName:.base.ref}"
)

#: The gh-shaped record's merge-commit key, and Bitbucket Cloud's documented
#: ``pullrequest.merge_commit.hash`` path (FTR-MSO-2026-0783, plan §2.6). They
#: live here, not in ``maestro/providers/scm/bitbucket.py``, for the same
#: ``TestNoMergePath`` / ``TestNoLandingPath`` source-scan reason as
#: :data:`GH_PR_BY_NUMBER_JQ`: provider source names no ``merge`` token other
#: than ``merged``. Both are READ-only field names.
PR_COMMIT_KEY = "mergeCommit"
BITBUCKET_CLOUD_COMMIT_PATH = ("merge_commit", "hash")

#: How long a non-GitHub resolution is reused. Bitbucket's ``available()`` is
#: an HTTP GET, which must not run on every dispatcher tick.
RESOLVE_TTL_SECONDS = 120.0

_GIT_TIMEOUT = 30
_FETCH_TIMEOUT = 120

_MEMO: dict[tuple[str, str], tuple[float, Any]] = {}
_WARNED: set = set()
_LOCK = threading.Lock()


@dataclass(frozen=True)
class DispatcherScm:
    """What :func:`dispatcher_scm` decided.

    ``provider`` is ``None`` whenever the lifecycle op must be SKIPPED — the
    dispatcher never guesses on an unusable provider — and ``reason`` then
    says why. ``github`` is True when the caller keeps its GitHub-only
    auxiliary ``gh`` calls (compare, pr list, pr comment)."""

    provider_id: str
    tier: str
    provider: Optional["ScmProvider"]
    reason: str
    github: bool


def reset_for_tests() -> None:
    """Clear the resolution memo and the warn-once registry."""
    with _LOCK:
        _MEMO.clear()
        _WARNED.clear()


def _workspace_key(workspace: Optional[Path]) -> str:
    if workspace is None:
        return ""
    try:
        return str(Path(workspace).resolve())
    except Exception:
        return str(workspace)


def _configured_repo_name(config: Any) -> Optional[str]:
    """The bare repository name a single-repo provider config points at."""
    if not isinstance(config, dict):
        return None
    slug = str(config.get("slug") or "").strip().strip("/")
    if slug:
        return slug.rsplit("/", 1)[-1] or None
    repo = str(config.get("repo") or "").strip()
    return repo or None


def dispatcher_scm(
    workspace: Optional[Path],
    *,
    runner: Callable[..., Any],
    repo_slug: Optional[str] = None,
    repo_path: Optional[Path] = None,
    clock: Callable[[], float] = time.monotonic,
) -> DispatcherScm:
    """Resolve the SCM provider the dispatcher's PR lifecycle uses.

    *workspace* is the directory holding the durable ``.mso`` plane — the
    dispatcher passes ``get_artefact_root().parent`` because
    ``resolve_artefact_dir`` is not solo-mode aware. *runner* is injected into
    a GitHub provider so a caller's own ``run_hidden`` patch intercepts it.
    *repo_slug* / *repo_path* are the per-call repository (the dispatcher is
    multi-repo); a non-GitHub provider is configured for exactly one repository
    and ignores *repo_path*.

    Rules (plan §2.2), in order:

    1. no ``providers.scm`` entry → GitHub, no probe;
    2. ``github`` → GitHub with the configured config underneath the per-call
       slug/path (the per-call values win), no probe;
    3. ``none`` → skipped, ``"no scm provider configured"``;
    4. anything else → ``resolve_explain`` (memoised for
       :data:`RESOLVE_TTL_SECONDS`); unavailable → skipped with its reason;
       a *repo_slug* naming a different repository than the provider's → skipped.

    Never raises.
    """
    try:
        from maestro import providers
        from maestro.providers.scm.github import GithubScmProvider
    except Exception as exc:  # noqa: BLE001
        return DispatcherScm("", "default", None, f"scm providers unavailable: {exc}", False)

    ws = Path(workspace) if workspace is not None else None
    try:
        tier, configured_id, config = providers.configured_entry("scm", ws)
    except Exception as exc:  # noqa: BLE001 — e.g. a non-object `config` value
        return DispatcherScm("", "workspace", None,
                             f"scm provider configuration unreadable: {type(exc).__name__}: {exc}", False)

    if configured_id in (None, "github"):
        cfg: dict[str, Any] = dict(config) if configured_id == "github" else {}
        if repo_slug:
            cfg["slug"] = repo_slug
        if repo_path is not None:
            cfg["repoPath"] = str(repo_path)
        try:
            provider = GithubScmProvider(cfg, runner=runner)
        except Exception as exc:  # noqa: BLE001
            return DispatcherScm("github", tier, None, f"github provider failed to initialise: {exc}", False)
        return DispatcherScm("github", tier, provider, "", True)

    if configured_id == "none":
        return DispatcherScm("none", tier, None, "no scm provider configured", False)

    key = (_workspace_key(ws), str(configured_id))
    with _LOCK:
        hit = _MEMO.get(key)
    if hit is not None and clock() - hit[0] < RESOLVE_TTL_SECONDS:
        resolved = hit[1]
    else:
        try:
            resolved = providers.resolve_explain("scm", ws)
        except Exception as exc:  # noqa: BLE001 — resolve_explain never raises; belt and braces
            return DispatcherScm(str(configured_id), tier, None, f"scm resolution failed: {exc}", False)
        with _LOCK:
            _MEMO[key] = (clock(), resolved)

    if not resolved.available or resolved.provider is None:
        return DispatcherScm(resolved.provider_id, resolved.tier, None, resolved.reason, False)

    if repo_slug:
        provider_config = getattr(resolved.provider, "config", None)
        configured_repo = _configured_repo_name(provider_config) or _configured_repo_name(config)
        wanted = str(repo_slug).strip().strip("/").rsplit("/", 1)[-1]
        if configured_repo and wanted.casefold() != configured_repo.casefold():
            return DispatcherScm(
                resolved.provider_id, resolved.tier, None,
                f"{resolved.provider_id} provider is configured for '{configured_repo}', "
                f"not '{repo_slug}' — multi-repo voyages need a per-repo provider (out of scope)",
                False,
            )

    return DispatcherScm(resolved.provider_id, resolved.tier, resolved.provider, "", False)


def warn_once(key: Hashable, emit: Callable[[], Any]) -> bool:
    """Call *emit* the first time *key* is seen in this process.

    Returns True when it emitted. A key whose *emit* raised is not recorded,
    so the next call tries again. Never raises."""
    with _LOCK:
        if key in _WARNED:
            return False
    try:
        emit()
    except Exception:  # noqa: BLE001
        return False
    with _LOCK:
        if key in _WARNED:
            return False
        _WARNED.add(key)
    return True


_CLOSED_STATES = frozenset({"CLOSED", "DECLINED", "SUPERSEDED"})


def pr_record(pr: Any, scm: Any, shape: str) -> Optional[dict]:
    """Adapt a provider PR dict to the gh-shaped record ``fleet_runner`` reads.

    ``shape="by_number"`` → ``_gh_pr_by_number``'s ``{state, merged, mergedAt,
    mergeCommit, number, url, baseRefName}`` (``state`` in GitHub's REST form:
    lowercase ``open``/``closed``, a merged PR being ``closed``).
    ``shape="view"`` → ``_gh_pr_view``'s ``{state, mergeCommit: {"oid"},
    mergedAt, number, mergeable, url}``.

    ``merged`` comes from ``scm.pr_is_merged(pr)``. ``mergedAt`` and
    ``mergeCommit`` come only from those keys on the PR dict — never derived
    from any other timestamp — and are ``None`` when absent. An unrecognised
    state is ``""``, which every consumer already reads as unknown.
    Returns ``None`` for a non-dict *pr*.
    """
    if shape not in ("by_number", "view"):
        raise ValueError(f"unknown pr_record shape: {shape!r}")
    if not isinstance(pr, dict):
        return None
    try:
        merged = bool(scm.pr_is_merged(pr))
    except Exception:  # noqa: BLE001
        merged = False

    raw_state = str(pr.get("state") or "").strip().upper()
    if merged:
        state = "MERGED"
    elif raw_state == "OPEN":
        state = "OPEN"
    elif raw_state in _CLOSED_STATES:
        state = "CLOSED"
    else:
        state = ""

    merged_at = pr.get("mergedAt") or None
    commit = pr.get("mergeCommit")
    if isinstance(commit, dict):
        commit = commit.get("oid")
    commit = commit if isinstance(commit, str) and commit else None
    number = pr.get("number") or pr.get("id")
    url = pr.get("url") or None

    if shape == "by_number":
        return {
            "state": {"MERGED": "closed", "OPEN": "open", "CLOSED": "closed"}.get(state, ""),
            "merged": merged,
            "mergedAt": merged_at,
            "mergeCommit": commit,
            "number": number,
            "url": url,
            "baseRefName": pr.get("baseRefName") or pr.get("baseRef") or None,
        }
    return {
        "state": state,
        "mergeCommit": {"oid": commit} if commit else None,
        "mergedAt": merged_at,
        "number": number,
        "mergeable": None,
        "url": url,
    }


# ---------------------------------------------------------------------------
# Host-neutral git helpers (plan §2.1). Each returns None when the answer
# cannot be determined — never a guessed 0/False.
# ---------------------------------------------------------------------------

_UNSAFE_REF = re.compile(r"[\x00-\x20\x7f~^:?*\[\\]|\.\.|@\{")


def _safe_ref(name: Any) -> bool:
    """A branch name that cannot be read as a git option or a revision range."""
    return isinstance(name, str) and bool(name) and not name.startswith("-") \
        and not _UNSAFE_REF.search(name)


def _run_git(runner: Optional[Callable[..., Any]], repo_path: Path, args: list[str],
             timeout: int) -> Any:
    if runner is None:
        from maestro.core.proc import run_hidden as runner  # noqa: PLC0415
    try:
        return runner(["git", "-C", str(repo_path)] + args,
                      capture_output=True, text=True, timeout=timeout)
    except Exception:  # noqa: BLE001
        return None


def _fetch(runner, repo_path: Path, remote: str, branches: list[str]) -> None:
    refspecs = [f"+refs/heads/{b}:refs/remotes/{remote}/{b}" for b in branches]
    _run_git(runner, repo_path, ["fetch", "--quiet", remote] + refspecs, _FETCH_TIMEOUT)


def remote_branch_exists(repo_path: Path, branch: str, *,
                         runner: Optional[Callable[..., Any]] = None,
                         remote: str = "origin") -> Optional[bool]:
    """Whether *branch* exists on *remote* (``git ls-remote --heads``)."""
    if not _safe_ref(branch) or not _safe_ref(remote):
        return None
    r = _run_git(runner, repo_path, ["ls-remote", "--heads", remote, f"refs/heads/{branch}"],
                 _FETCH_TIMEOUT)
    if r is None or r.returncode != 0:
        return None
    return bool((r.stdout or "").strip())


def commits_ahead(repo_path: Path, base: str, head: str, *,
                  runner: Optional[Callable[..., Any]] = None,
                  remote: str = "origin", fetch: bool = True) -> Optional[int]:
    """Commits on ``<remote>/<head>`` not on ``<remote>/<base>``, after a
    best-effort fetch of both."""
    if not (_safe_ref(base) and _safe_ref(head) and _safe_ref(remote)):
        return None
    if fetch:
        _fetch(runner, repo_path, remote, [base, head])
    r = _run_git(runner, repo_path, ["rev-list", "--count", f"{remote}/{base}..{remote}/{head}"],
                 _GIT_TIMEOUT)
    if r is None or r.returncode != 0:
        return None
    try:
        return int((r.stdout or "").strip())
    except ValueError:
        return None


def changed_file_count(repo_path: Path, base: str, head: str, *,
                       runner: Optional[Callable[..., Any]] = None,
                       remote: str = "origin", fetch: bool = False) -> Optional[int]:
    """Files changed on ``<remote>/<head>`` since it left ``<remote>/<base>``
    (``git diff --name-only base...head``)."""
    if not (_safe_ref(base) and _safe_ref(head) and _safe_ref(remote)):
        return None
    if fetch:
        _fetch(runner, repo_path, remote, [base, head])
    r = _run_git(runner, repo_path, ["diff", "--name-only", f"{remote}/{base}...{remote}/{head}"],
                 _GIT_TIMEOUT)
    if r is None or r.returncode != 0:
        return None
    return len([ln for ln in (r.stdout or "").splitlines() if ln.strip()])
