"""PR supersession — a voyage whose work shipped under a DIFFERENT PR (BUG-MSO-2026-0637).

A long-lived voyage branch goes DIRTY when the default branch advances beneath
it, and the branch guard (BUG-ADM-2026-0004) forbids a crew pushing to another
voyage's branch. The recovery is a merge-resolution order that delivers the
combined result on its OWN branch, which becomes a new PR; the original PR is
then closed unmerged. The work is on main — but the manifest still names the
original PR, which is closed-and-never-merged, so merge detection correctly
refuses to confirm it and the Hub parks the voyage in Final Review forever.

"Closed because superseded, and here is where the work went" is a different
FACT from "closed without merging". This module is the one reader of that fact.
It never derives merge state — ``fleet_runner.resolve_voyage_merge_state`` stays
the one derivation (Captain decision D3(a)); it only tells that derivation which
PR number to ask about. Closed-unmerged still refuses completion (FTR-MSO-2026-
0600 rule 1, GH #375): if the SUPERSEDING PR is not merged either, the voyage is
exactly as unfinished as before.

Two manifest shapes are accepted, on a voyage manifest or on one ``prUrls[repo]``
entry:

* **Canonical** (what ``voyage_core.record_voyage_supersession`` writes, and the
  shape LEAD hand-corrected VOY-MSO-2026-0151/0155/0157 into on 2026-09-05)::

      "prNumber": 393,                 # the PR the work SHIPPED under
      "prUrl": ".../pull/393",
      "supersededPrNumber": 365,       # the original, closed as superseded
      "supersededPrUrl": ".../pull/365",   # optional
      "supersededNote": "..."              # optional

* **Forward declaration** (convenient to hand-write before re-pointing)::

      "prNumber": 365,                 # still the original
      "supersededBy": {"prNumber": 393, "prUrl": "...", "note": "..."}
      # or "supersededBy": 393, or "supersededByPrNumber": 393

Both normalise to the same :func:`supersession_of` record, so neither reader
nor writer has to care which one it was handed.
"""

from __future__ import annotations

from typing import Any, Dict, Optional

__all__ = [
    "supersession_of",
    "effective_pr_number",
    "stamp_supersession",
    "pr_url_with_number",
]


def _as_pr_int(value: Any) -> Optional[int]:
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value if value > 0 else None
    if isinstance(value, str) and value.strip().isdigit():
        n = int(value.strip())
        return n if n > 0 else None
    return None


def _url_number(url: Any) -> Optional[int]:
    if not isinstance(url, str) or not url.strip():
        return None
    return _as_pr_int(url.strip().rstrip("/").rsplit("/", 1)[-1])


def pr_url_with_number(url: Any, number: int) -> Optional[str]:
    """*url* with its trailing PR number replaced by *number*, or None when
    *url* does not end in a PR number (nothing safe to rewrite)."""
    if _url_number(url) is None:
        return None
    base = url.strip().rstrip("/").rsplit("/", 1)[0]
    return f"{base}/{number}"


def supersession_of(record: Any) -> Optional[Dict[str, Any]]:
    """The supersession recorded on a voyage manifest or ``prUrls`` entry.

    Returns ``{"originalPrNumber", "originalPrUrl", "supersedingPrNumber",
    "supersedingPrUrl", "note"}`` (URLs/note may be None), or None when no
    usable supersession is recorded. A record naming the same PR on both sides,
    or missing either side, is not a supersession — never guess one.
    """
    if not isinstance(record, dict):
        return None

    by = record.get("supersededBy")
    superseding: Optional[int] = None
    superseding_url: Optional[str] = None
    note: Optional[str] = None
    if isinstance(by, dict):
        superseding = _as_pr_int(by.get("prNumber"))
        superseding_url = by.get("prUrl") if isinstance(by.get("prUrl"), str) else None
        note = by.get("note") if isinstance(by.get("note"), str) else None
    else:
        superseding = _as_pr_int(by)
    if superseding is None:
        superseding = _as_pr_int(record.get("supersededByPrNumber"))

    recorded = _as_pr_int(record.get("prNumber"))
    recorded_url = record.get("prUrl") if isinstance(record.get("prUrl"), str) else None
    original = _as_pr_int(record.get("supersededPrNumber"))

    if superseding is None:
        # Canonical shape: prNumber already names the superseding PR.
        if original is None:
            return None
        superseding = recorded
    elif original is None:
        # Forward declaration: prNumber still names the original.
        original = recorded

    if superseding is None or original is None or superseding == original:
        return None

    if superseding_url is None and _url_number(recorded_url) == superseding:
        superseding_url = recorded_url
    original_url = record.get("supersededPrUrl")
    if not isinstance(original_url, str) or not original_url:
        original_url = recorded_url if _url_number(recorded_url) == original else None
    # A hand-repointed prNumber commonly leaves prUrl naming the original —
    # derive the missing side from whichever URL is known.
    if superseding_url is None:
        superseding_url = pr_url_with_number(original_url or recorded_url, superseding)
    if original_url is None:
        original_url = pr_url_with_number(superseding_url or recorded_url, original)

    if note is None and isinstance(record.get("supersededNote"), str):
        note = record.get("supersededNote")

    return {
        "originalPrNumber": original,
        "originalPrUrl": original_url,
        "supersedingPrNumber": superseding,
        "supersedingPrUrl": superseding_url,
        "note": note or None,
    }


def effective_pr_number(record: Any) -> Optional[int]:
    """The PR a record's merge state must be resolved FROM: the superseding PR
    when a supersession is recorded, else the record's own ``prNumber``."""
    sup = supersession_of(record)
    if sup is not None:
        return sup["supersedingPrNumber"]
    if isinstance(record, dict):
        return _as_pr_int(record.get("prNumber"))
    return None


def stamp_supersession(record: Dict[str, Any], sup: Optional[Dict[str, Any]]) -> bool:
    """Write *sup* onto *record* in the canonical shape. Returns True if changed.

    Called wherever a writer re-points ``prNumber``/``prUrl`` at the PR that
    merged, so the original PR is never silently swapped out of the record —
    an operator looking for it must still be able to see where it went.
    """
    if not isinstance(record, dict) or not sup:
        return False
    wanted = {
        "prNumber": sup["supersedingPrNumber"],
        "supersededPrNumber": sup["originalPrNumber"],
    }
    if sup.get("supersedingPrUrl"):
        wanted["prUrl"] = sup["supersedingPrUrl"]
    if sup.get("originalPrUrl"):
        wanted["supersededPrUrl"] = sup["originalPrUrl"]
    if sup.get("note"):
        wanted["supersededNote"] = sup["note"]
    changed = False
    for key, value in wanted.items():
        if record.get(key) != value:
            record[key] = value
            changed = True
    # The forward-declaration keys are now redundant — the canonical fields
    # carry everything, and a stale forward key could disagree later.
    for key in ("supersededBy", "supersededByPrNumber"):
        if key in record:
            del record[key]
            changed = True
    return changed
