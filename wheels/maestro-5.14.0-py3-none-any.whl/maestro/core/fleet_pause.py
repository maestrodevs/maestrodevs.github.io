# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Clean fleet pause — DRAIN, not freeze (FTR-MSO-2026-0498).

What this is
------------
``mso pause`` asks the running dispatcher to stop claiming new work, let every
in-flight crew reach its natural terminal state (a crew process runs exactly
ONE Claude session since BUG-MSO-2026-0438, so "finish the current iteration"
IS "finish"), process those completions normally, and then exit cleanly.
``mso resume`` (or a plain ``mso dispatch``) starts it again with no
``mso cleanup`` and no ``mso order retry``, because nothing was killed and
nothing was left inconsistent.

FREEZE — stop now, preserve state — already exists as ``mso cleanup`` / the
Hub's Stop / Ctrl-C (kill + salvage + requeue) and gets no second verb here.

The drain is bounded by the longest-remaining running crew: its wall-clock
ceiling (``state.json`` ``startTime`` + ``timeoutMinutes``) plus the verify
gate at convergence (``verifyTimeoutMinutes``, default 20; a cold frontend
``npm ci`` can add ``verify.frontendInstallTimeoutMinutes``, default 30). With
defaults that is roughly 80–110 minutes worst case. :func:`estimate_drain`
computes the per-crew figure; the escalation for "I need it stopped NOW" is
``mso cleanup``.

Signalling
----------
The dispatcher is a detached process with no graceful signal on Windows, and
SIGINT/SIGTERM are already bound to the kill path. So the request is a file,
``<artefact root>/state/fleet-pause.json`` (gitignored runtime plane, the same
home as ``order-ledger.jsonl`` and ``died-*.json``), which the dispatcher
reads on every tick. Writes are atomic (tmp + ``os.replace``).

Isolation (the rule that keeps an unclean stop recovering exactly as today)
--------------------------------------------------------------------------
Exactly three readers may consult this file: the dispatcher's dispatch gate,
the dispatcher's drain-complete exit, and the status overlay
(:func:`overlay_dispatcher_state`, shared by ``mso status`` and the Hub).
Queue scanning, the order ledger, completion processing, salvage arming,
``order_retry`` and stale-state clearing must never read it, and no order
JSON, crew ``state.json`` or ledger event gains a pause field. The file is
advisory display state plus one gate — a kill or power loss at any moment
leaves orders, crews and the ledger in a state today's recovery machinery
already understands.

Shared-core contract: explicit ``mso: Path`` on every function; no
``find_workspace()``, no cwd, no process globals. Reads never raise.
"""

from __future__ import annotations

import json
import os
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

PAUSING = "PAUSING"
PAUSED = "PAUSED"
PAUSE_FILE_NAME = "fleet-pause.json"

#: Lifecycle event names (documented in CLAUDE.md's lifecycle table).
EVENT_PAUSE_REQUESTED = "FLEET_PAUSE_REQUESTED"
EVENT_PAUSED = "FLEET_PAUSED"
EVENT_PAUSE_CANCELLED = "FLEET_PAUSE_CANCELLED"
EVENT_RESUMED = "FLEET_RESUMED"
EVENT_PAUSE_DISCARDED = "FLEET_PAUSE_DISCARDED"

#: Crew statuses that mean "a process is (supposed to be) working in this
#: slot". Same set the Hub aggregator uses (``_CREW_LIVE_STATUSES``).
LIVE_CREW_STATUSES = frozenset({"RUNNING", "ACTIVE", "HUNG"})

DEFAULT_TIMEOUT_MINUTES = 60
DEFAULT_VERIFY_TIMEOUT_MINUTES = 20

#: Defaults a relaunch falls back to when neither the pause record nor an
#: explicit CLI flag supplies a value — they mirror ``mso dispatch``'s parser.
DEFAULT_DISPATCH_ARGS: Dict[str, int] = {
    "maxCrews": 5,
    "staggerDelay": 30,
    "timeout": 60,
    "maxTurns": 200,
}

INTERRUPTED_DETAIL = (
    "pause interrupted — dispatcher exited before drain completed; "
    "normal recovery applies"
)


class PauseStateError(OSError):
    """The pause request could not be persisted.

    Raised only by the operator-invoked writer (:func:`request_pause`): a
    pause that silently failed to record would leave ``mso pause`` claiming
    something untrue. Dispatcher-side writes stay best-effort.
    """


# ---------------------------------------------------------------------------
# Paths, read, write
# ---------------------------------------------------------------------------

def pause_path(mso: Path) -> Path:
    return Path(mso) / "state" / PAUSE_FILE_NAME


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _as_int(value: Any) -> Optional[int]:
    try:
        return int(value) if value is not None else None
    except (TypeError, ValueError):
        return None


def read_pause_state(mso: Path) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    """``(record, error)`` — never raises.

    ``(None, None)`` means no pause file. A file that exists but cannot be
    used returns ``(None, reason)``: callers treat it as ABSENT for gating
    (fail-open to running — a corrupt advisory file must never hold a fleet)
    and may render *reason* as a warning.
    """
    path = pause_path(mso)
    try:
        if not path.exists():
            return None, None
        raw = path.read_text(encoding="utf-8")
    except OSError as exc:
        return None, f"pause file unreadable ({exc})"
    try:
        record = json.loads(raw)
    except ValueError:
        return None, "pause file is not valid JSON"
    if not isinstance(record, dict) or record.get("status") not in (PAUSING, PAUSED):
        return None, "pause file has no recognised status"
    return record, None


def read_pause(mso: Path) -> Optional[Dict[str, Any]]:
    """The pause record, or ``None`` when absent or unusable."""
    return read_pause_state(mso)[0]


def _write(mso: Path, record: Dict[str, Any]) -> bool:
    """Atomic write. Returns False instead of raising."""
    try:
        path = pause_path(mso)
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(record, indent=2), encoding="utf-8")
        os.replace(str(tmp), str(path))
        return True
    except Exception:
        return False


def write_event(mso: Path, event_type: str, message: str) -> None:
    """Append one ``lifecycle.log`` line for a CLI/Hub-side pause transition.

    Same line format as ``fleet_runner.write_lifecycle_event`` but anchored at
    an explicit *mso*, so a caller outside the dispatcher process (the CLI
    today, the Hub later) never resolves the log from its own cwd. Best-effort.
    """
    try:
        from maestro.core.lifecycle_log import sanitize_lifecycle_message
        log_dir = Path(mso) / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        line = f"{ts} | {event_type:<10} | {sanitize_lifecycle_message(message)}\n"
        with open(str(log_dir / "lifecycle.log"), "a", encoding="utf-8") as fh:
            fh.write(line)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Dispatcher identity
# ---------------------------------------------------------------------------

def live_dispatcher(mso: Path) -> Optional[Tuple[int, Optional[int]]]:
    """``(pid, createTime)`` of the live dispatcher recorded under *mso*, else None.

    PID + creation time, the BUG-MSO-2026-0685 rule: ``dispatcher.pid`` names
    the process and the ``dispatcher.identity.json`` sidecar, when present,
    disproves a recycled PID. An unparseable lock yields ``None`` — for pause
    that only means "nothing to pause", which writes nothing and is harmless.
    """
    try:
        pid = int((Path(mso) / "dispatcher.pid").read_text(encoding="utf-8").strip())
    except (OSError, ValueError):
        return None
    if pid <= 0:
        return None
    try:
        from maestro import proc_identity
        current = proc_identity.process_create_time(pid)
        if current is None:
            return None
        rec = proc_identity.read_identity_record(Path(mso) / "dispatcher.identity.json")
    except Exception:
        return None
    if rec is not None:
        rec_pid, rec_ct = rec
        if rec_pid == pid and rec_ct is not None and rec_ct != current:
            return None
    return pid, current


def _same_process(record: Dict[str, Any], pid: Optional[int],
                  create_time: Optional[int]) -> bool:
    """Does *record* name process (*pid*, *create_time*)?

    A missing create time on either side cannot DISPROVE a match, so it is
    not treated as a mismatch — the PID must still agree.
    """
    rec_pid = _as_int(record.get("dispatcherPid"))
    if rec_pid is None or pid is None or rec_pid != int(pid):
        return False
    rec_ct = _as_int(record.get("dispatcherPidCreateTime"))
    if rec_ct is None or create_time is None:
        return True
    return rec_ct == int(create_time)


# ---------------------------------------------------------------------------
# Transitions
# ---------------------------------------------------------------------------

def request_pause(mso: Path, dispatcher_pid: int,
                  dispatcher_create_time: Optional[int] = None,
                  actor: str = "cli") -> Tuple[Dict[str, Any], bool]:
    """Ask the live dispatcher *dispatcher_pid* to drain and exit.

    Returns ``(record, newly_requested)``; idempotent — a second request for
    the same dispatcher returns the existing record with ``False``. Raises
    :class:`PauseStateError` if the request could not be written.
    """
    existing = read_pause(mso)
    if (existing and existing.get("status") == PAUSING
            and _same_process(existing, dispatcher_pid, dispatcher_create_time)):
        return existing, False
    record: Dict[str, Any] = {
        "status": PAUSING,
        "requestedAt": _now_iso(),
        "requestedBy": actor,
        "dispatcherPid": int(dispatcher_pid),
        "dispatcherPidCreateTime": dispatcher_create_time,
        "pausedAt": None,
        "dispatchArgs": None,
        "pendingAtPause": None,
    }
    if not _write(mso, record):
        raise PauseStateError(f"could not write {pause_path(mso)}")
    return record, True


def cancel_pause(mso: Path) -> Optional[Dict[str, Any]]:
    """Withdraw a PAUSING request. Returns the withdrawn record, else None.

    A PAUSED record is not "cancelled" — its dispatcher is already gone and
    the only way forward is a relaunch, which clears it at startup.
    """
    record = read_pause(mso)
    if not record or record.get("status") != PAUSING:
        return None
    try:
        pause_path(mso).unlink()
    except FileNotFoundError:
        pass
    except OSError:
        return None
    return record


def is_pause_requested_for(mso: Path, pid: int,
                           create_time: Optional[int] = None) -> bool:
    """True only for a PAUSING request naming THIS dispatcher process.

    A PAUSED record, a request naming another/dead dispatcher, or an unusable
    file all read False — a stale file can never hold a fresh dispatcher.
    """
    record = read_pause(mso)
    return bool(record and record.get("status") == PAUSING
                and _same_process(record, pid, create_time))


def note_dispatcher_observed(mso: Path, dispatch_args: Dict[str, Any]) -> bool:
    """Dispatcher side: record the args it runs with, so resume can reuse them.

    Returns True the first time (the args were not yet on the record).
    Best-effort — a failed write just means resume falls back to defaults.
    """
    record = read_pause(mso)
    if not record or record.get("status") != PAUSING:
        return False
    if record.get("dispatchArgs") == dispatch_args:
        return False
    record["dispatchArgs"] = dict(dispatch_args)
    record["observedAt"] = _now_iso()
    return _write(mso, record)


def mark_paused(mso: Path, dispatch_args: Optional[Dict[str, Any]] = None,
                pending: int = 0) -> Optional[Dict[str, Any]]:
    """Dispatcher side: the drain is complete — record PAUSED. Best-effort."""
    record = read_pause(mso) or {"requestedAt": None, "requestedBy": None}
    record["status"] = PAUSED
    record["pausedAt"] = _now_iso()
    record["pendingAtPause"] = int(pending or 0)
    if dispatch_args:
        record["dispatchArgs"] = dict(dispatch_args)
    return record if _write(mso, record) else None


def clear_pause(mso: Path, reason: str = "") -> Optional[Dict[str, Any]]:
    """Remove the pause file. Returns what was there, or None if nothing was.

    An unusable file is removed too and reported as
    ``{"status": "UNREADABLE", "error": ...}`` so the caller can log it.
    *reason* is accepted for call-site readability; the caller owns the event.
    """
    record, error = read_pause_state(mso)
    path = pause_path(mso)
    try:
        existed = path.exists()
        if existed:
            path.unlink()
    except OSError:
        return None
    if not existed:
        return None
    if record is not None:
        return record
    return {"status": "UNREADABLE", "error": error}


# ---------------------------------------------------------------------------
# Drain estimate
# ---------------------------------------------------------------------------

def _verify_timeout_minutes(mso: Path) -> int:
    try:
        cfg = json.loads((Path(mso) / "config" / "workspace.json").read_text(encoding="utf-8"))
        value = int(cfg.get("verifyTimeoutMinutes", DEFAULT_VERIFY_TIMEOUT_MINUTES))
        return value if value > 0 else DEFAULT_VERIFY_TIMEOUT_MINUTES
    except Exception:
        return DEFAULT_VERIFY_TIMEOUT_MINUTES


def _parse_local(value: Any) -> Optional[datetime]:
    """Parse an ISO timestamp to a NAIVE LOCAL datetime (crew state is local)."""
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(str(value))
    except ValueError:
        return None
    if dt.tzinfo is not None:
        dt = dt.astimezone().replace(tzinfo=None)
    return dt


def estimate_drain(mso: Path, max_crews: int = 5,
                   check_alive: bool = False) -> List[Dict[str, Any]]:
    """One entry per crew slot still working, with its latest possible finish.

    ``latestFinish`` (naive local datetime, or None when ``startTime`` is
    unreadable) = ``startTime + timeoutMinutes + verifyTimeoutMinutes``. With
    *check_alive*, slots whose recorded PID is not a live process are skipped
    — they are not draining, they are already dead (normal recovery applies).
    """
    verify = _verify_timeout_minutes(mso)
    entries: List[Dict[str, Any]] = []
    for n in range(1, max(5, int(max_crews or 0)) + 1):
        try:
            state = json.loads((Path(mso) / "crews" / f"crew{n}" / "state.json")
                               .read_text(encoding="utf-8"))
        except Exception:
            continue
        if not isinstance(state, dict):
            continue
        if str(state.get("status", "")).upper() not in LIVE_CREW_STATUSES:
            continue
        if check_alive:
            pid = _as_int(state.get("pid"))
            try:
                from maestro import proc_identity
                if not pid or proc_identity.process_create_time(pid) is None:
                    continue
            except Exception:
                continue
        timeout = _as_int(state.get("timeoutMinutes")) or DEFAULT_TIMEOUT_MINUTES
        start = _parse_local(state.get("startTime"))
        entries.append({
            "crew": n,
            "orderId": state.get("orderId") or "-",
            "role": state.get("role") or "-",
            "timeoutMinutes": timeout,
            "verifyMinutes": verify,
            "startTime": start,
            "latestFinish": start + timedelta(minutes=timeout + verify) if start else None,
        })
    return entries


def latest_finish(entries: List[Dict[str, Any]]) -> Optional[datetime]:
    finishes = [e["latestFinish"] for e in entries if e.get("latestFinish")]
    return max(finishes) if finishes else None


# ---------------------------------------------------------------------------
# Status overlay — ONE implementation for `mso status` and the Hub
# ---------------------------------------------------------------------------

def _fmt_local_time(iso_value: Any) -> str:
    dt = _parse_local(iso_value)
    return dt.strftime("%Y-%m-%d %H:%M") if dt else "unknown time"


def describe_pausing(mso: Path, max_crews: int = 5) -> str:
    entries = estimate_drain(mso, max_crews)
    if not entries:
        return "no crews running — dispatcher exits on its next tick"
    latest = latest_finish(entries)
    text = f"{len(entries)} crew(s) draining"
    if latest is not None:
        text += f", est. by {latest.strftime('%H:%M')}"
    return text


def describe_paused(record: Dict[str, Any]) -> str:
    pending = _as_int(record.get("pendingAtPause"))
    text = f"paused since {_fmt_local_time(record.get('pausedAt'))}"
    if pending is not None:
        text += f"; {pending} order(s) pending"
    return text + " — resume with `mso resume`"


def overlay_dispatcher_state(base_state: str, pid_alive: bool, mso: Path,
                             dispatcher_pid: Optional[int] = None,
                             max_crews: int = 5) -> Tuple[str, str]:
    """Apply pause state on top of an existing RUNNING/WEDGED/STOPPED verdict.

    ============ ================================== ===========================
    base         pause file                         result
    ============ ================================== ===========================
    WEDGED       any                                WEDGED (a stuck loop cannot
                                                    drain)
    RUNNING      PAUSING for the live dispatcher    PAUSING (+ draining detail)
    RUNNING      PAUSED, or PAUSING for another PID RUNNING (stale; the live
                                                    dispatcher cleared/ignores
                                                    it)
    STOPPED      PAUSED                             PAUSED (since pausedAt)
    STOPPED      PAUSING                            STOPPED + "pause
                                                    interrupted" detail
    any          absent                             unchanged
    any          unusable                           unchanged + warning detail
    ============ ================================== ===========================

    When the PID is not visible (containerised Hub: *pid_alive* False while
    the heartbeat keeps *base_state* RUNNING), a PAUSING request cannot be
    matched against a PID and is accepted, exactly as the heartbeat fallback
    already accepts the dispatcher itself. Returns ``(state, detail)``.
    """
    record, error = read_pause_state(mso)
    if error:
        return base_state, f"pause file ignored — {error}"
    if record is None or base_state == "WEDGED":
        return base_state, ""
    status = record.get("status")
    if base_state == "RUNNING":
        if status != PAUSING:
            return "RUNNING", ""
        if pid_alive and dispatcher_pid:
            ct = None
            try:
                from maestro import proc_identity
                ct = proc_identity.process_create_time(int(dispatcher_pid))
            except Exception:
                ct = None
            if not _same_process(record, int(dispatcher_pid), ct):
                return "RUNNING", ""
        return PAUSING, describe_pausing(mso, max_crews)
    if base_state == "STOPPED":
        if status == PAUSED:
            return PAUSED, describe_paused(record)
        return "STOPPED", INTERRUPTED_DETAIL
    return base_state, ""


def state_is_running(state: str) -> bool:
    """The yes/no answer for a derived state: a PAUSING dispatcher is alive
    and ticking; PAUSED is stopped (deliberately — but stopped)."""
    return state in ("RUNNING", PAUSING)


def resolve_dispatch_args(record: Optional[Dict[str, Any]],
                          overrides: Optional[Dict[str, Any]] = None) -> Dict[str, int]:
    """Relaunch args: explicit *overrides* > recorded ``dispatchArgs`` > defaults."""
    merged = dict(DEFAULT_DISPATCH_ARGS)
    recorded = (record or {}).get("dispatchArgs") or {}
    if isinstance(recorded, dict):
        for key in DEFAULT_DISPATCH_ARGS:
            value = _as_int(recorded.get(key))
            if value is not None:
                merged[key] = value
    for key, value in (overrides or {}).items():
        if key in DEFAULT_DISPATCH_ARGS and value is not None:
            merged[key] = int(value)
    return merged
