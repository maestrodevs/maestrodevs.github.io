"""Unacknowledged critical LEAD findings, for the ``mso status`` MISSION banner
(BUG-MSO-2026-0713).

``mso status`` is what an operator has open when the fleet is misbehaving, and
until this module it said **nothing** about LEAD findings — ``grep -n "MISSION"
maestro/core/dashboard.py`` returned zero matches. On 2026-09-09 that mattered
concretely: ``lead.dispatcher-watch`` raised "Dispatcher is STOPPED" at
``critical`` on the very next tick, and the two places it went — ``state.json``
and the Hub strip — were, respectively, a file nobody was reading and a daemon
that was itself dead. Nobody was told for 56 minutes.

The record lives in the gitignored ``state/`` control plane, alongside
``order-ledger.jsonl`` and ``scan-disagreement.json``, for the same reason those
do: it must be readable **off-process**, by a ``mso status`` with no dispatcher
running, no Hub running, and no LEAD daemon running.

Shape::

    {
      "updatedAt": "<iso8601>",
      "findings": {
        "<fingerprint>": {
          "checkId": "...", "title": "...", "detail": "...",
          "suggestedCommand": "...", "firstSeenAt": "...", "lastSeenAt": "..."
        }
      }
    }

Entries are keyed by the patrol fingerprint so a finding re-raised on every tick
updates in place rather than accumulating. :func:`clear_critical` removes one
when it is resolved or acknowledged; :func:`clear_all` is for a clean slate.
Every write is atomic and every function is best-effort — a banner that cannot
be written must never fail a LEAD tick, and a banner that cannot be read must
never fail ``mso status``.
"""

from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

BANNER_RELPATH = Path("state") / "lead-critical.json"

#: Beyond this, the banner is summarised rather than listed. A status screen
#: that scrolls is a status screen nobody reads.
MAX_BANNER_ITEMS = 3


def banner_path(artefact_root: Optional[Path] = None) -> Path:
    root = Path(artefact_root) if artefact_root else _default_root()
    return root / BANNER_RELPATH


def _default_root() -> Path:
    from maestro.workspace import get_artefact_root
    return get_artefact_root()


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _read(artefact_root: Optional[Path]) -> Dict[str, Any]:
    try:
        path = banner_path(artefact_root)
        if not path.exists():
            return {}
        raw = json.loads(path.read_text(encoding="utf-8"))
        return raw if isinstance(raw, dict) else {}
    except Exception:
        return {}


def _write(artefact_root: Optional[Path], data: Dict[str, Any]) -> bool:
    try:
        path = banner_path(artefact_root)
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
        os.replace(str(tmp), str(path))
        return True
    except Exception:
        return False


def record_critical(artefact_root: Optional[Path], fingerprint: str, *,
                    title: str, detail: str, check_id: str = "",
                    suggested_command: Optional[str] = None) -> bool:
    """Add or refresh one critical finding. Returns whether the write landed."""
    data = _read(artefact_root)
    findings = data.get("findings")
    if not isinstance(findings, dict):
        findings = {}
    existing = findings.get(fingerprint) or {}
    now = _now()
    findings[fingerprint] = {
        "checkId": check_id or existing.get("checkId", ""),
        "title": title,
        "detail": detail,
        "suggestedCommand": suggested_command,
        # firstSeenAt survives a refresh — "this has been true for two hours"
        # is a materially different claim from "this just started".
        "firstSeenAt": existing.get("firstSeenAt") or now,
        "lastSeenAt": now,
    }
    data["findings"] = findings
    data["updatedAt"] = now
    return _write(artefact_root, data)


def clear_critical(artefact_root: Optional[Path], fingerprint: str) -> bool:
    data = _read(artefact_root)
    findings = data.get("findings")
    if not isinstance(findings, dict) or fingerprint not in findings:
        return False
    findings.pop(fingerprint, None)
    data["findings"] = findings
    data["updatedAt"] = _now()
    return _write(artefact_root, data)


def clear_all(artefact_root: Optional[Path] = None) -> None:
    try:
        banner_path(artefact_root).unlink()
    except OSError:
        pass
    except Exception:
        pass


def open_critical(artefact_root: Optional[Path] = None) -> List[Dict[str, Any]]:
    """Every unacknowledged critical finding, newest first. ``[]`` when none."""
    data = _read(artefact_root)
    findings = data.get("findings")
    if not isinstance(findings, dict):
        return []
    items = [dict(v, fingerprint=k) for k, v in findings.items() if isinstance(v, dict)]
    items.sort(key=lambda f: str(f.get("lastSeenAt") or ""), reverse=True)
    return items


def banner_lines(artefact_root: Optional[Path] = None,
                 limit: int = MAX_BANNER_ITEMS) -> List[str]:
    """Ready-to-render one-liners for the MISSION banner. ``[]`` when none.

    The rendering surface only has to decide colour and placement — the
    wording lives here so ``mso status`` and any future surface cannot drift
    into describing the same finding two different ways.
    """
    items = open_critical(artefact_root)
    if not items:
        return []
    lines: List[str] = []
    for item in items[:limit]:
        title = str(item.get("title") or item.get("checkId") or "critical finding")
        cmd = item.get("suggestedCommand")
        lines.append(f"{title} — {cmd}" if cmd else title)
    if len(items) > limit:
        lines.append(f"+{len(items) - limit} more critical finding(s)")
    return lines
