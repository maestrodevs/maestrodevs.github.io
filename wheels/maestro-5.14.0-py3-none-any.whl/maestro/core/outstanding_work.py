# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Why an outstanding order is outstanding, and what actually unsticks it.

BUG-MSO-2026-0740
-----------------
``fleet_runner.voyages_outstanding_work()`` answers ONE question — "is this
manifest order COMPLETE?" — and everything that is not COMPLETE comes back in
a single undifferentiated list. The dispatcher then told the operator, every
time, in one line:

    Eight Bells withheld — N order(s) not COMPLETE: <ids>. Recover stranded
    orders with `mso order retry <ID>` (BUG-0303).

That advice is right for exactly one of the reasons an order can be on that
list. `mso order retry` on a BACKLOG order the operator parked on purpose puts
it straight back into dispatch — the opposite of what they decided; on a
PROPOSED order waiting for its ``dependsOn`` it is noise, because
``promote_ready_dependents()`` will release it automatically the moment the
dependency completes; on an order whose file has vanished from every queue it
cannot work at all.

BUG-MSO-2026-0625 made this land: it widened the guard's REACH from
``("ACTIVE", "IN_PROGRESS")`` to ``_SWEEPABLE_VOYAGE_STATUSES`` (which adds
PLANNED — the status ``mso voyage create`` writes and nothing promotes), so
for the first time nearly every voyage on a plane can put its parked orders on
that list. On the live MSO plane that is VOY-MSO-2026-0716 (2 BACKLOG orders)
and VOY-MSO-2026-0732 (6), deliberately parked, permanently "outstanding".

What this module changes, and what it deliberately does NOT
-----------------------------------------------------------
It does not change **which** orders withhold Eight Bells. Whether a parked
order should hold the bell is a completion-semantics decision that Charts
Phase 2 already made and relies on: FTR-MSO-2026-0520's ``CHART_NODE_UNRESOLVED``
guarantee is precisely that a voyage stuck behind an unresolvable node "never
falsely reaches Eight Bells", and its acceptance proof
(``tests/test_charts_phase2_equivalence.py``) asserts a BACKLOG dead-end order
keeps its voyage outstanding. Narrowing the gate here would silently undo that.

It changes what the operator is TOLD: one line per outstanding order naming
its status, the class of hold it is in, and the remedy that is correct for
*that* class — and a throttle keyed per order (the BUG-MSO-2026-0597 pattern)
in place of the single global 300s timer, so one order's re-emission can no
longer swallow a different order's first warning, and a deliberately parked
order says its piece once instead of every five minutes forever.

Pure by construction: no filesystem, no globals, no clock (the throttle takes
``now`` from its caller). ``fleet_runner`` does the I/O and hands the resolved
status in — the same split :mod:`maestro.core.deadlock` uses between its
classifier and its plane reader.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, Optional, Sequence, Tuple

# ---------------------------------------------------------------------------
# Status vocabulary
# ---------------------------------------------------------------------------

#: Terminal-and-not-COMPLETE: the order will never move again on its own.
#: Mirrors :data:`maestro.core.deadlock.DEADLOCK_BLOCKER_STATUSES` plus the two
#: queue-limbo statuses BUG-MSO-2026-0307 established as the same family
#: (``BLOCKED``/``ESCALATED``), which is the set ``_STRANDED_QUEUE_STATUSES``
#: already surfaces straight out of the queues.
STRANDED_ORDER_STATUSES = frozenset({
    "STALLED", "FAILED", "CONVERGENCE_FAILED", "VERIFY_FAILED",
    "VERIFY_DEPS_FAILED", "AUTO_SERIALIZE", "BLOCKED", "ESCALATED",
})

#: An operator parked this deliberately. ``fleet_runner._AUTO_RELEASE_STATUSES``
#: excludes exactly these from automatic release for that reason ("an
#: auto-release would override a deliberate decision"), so the remedy must
#: never be a command that puts the order back into dispatch behind their back.
PARKED_ORDER_STATUSES = frozenset({
    "BACKLOG", "DRAFT", "PAUSED", "DEFERRED", "REJECTED", "CANCELLED",
})

#: Waiting on a dependency, and released automatically once it is satisfied
#: (``promote_ready_dependents``, the ``AUTOQUEUE`` lifecycle event).
DEP_GATED_ORDER_STATUSES = frozenset({"PROPOSED", "HELD", "HOLD", "ON_HOLD"})

#: Waiting on a human at the review gate.
REVIEW_ORDER_STATUSES = frozenset({"NAV_REVIEW_PENDING", "AWAITING_APPROVAL"})

#: A crew owns it right now.
RUNNING_ORDER_STATUSES = frozenset({
    "RUNNING", "IN_PROGRESS", "CLAIMED", "DISPATCHED", "ACTIVE",
})

# Hold classes (the `hold_class` field).
HOLD_STRANDED = "stranded"
HOLD_PARKED = "parked"
HOLD_DEP_HELD = "dep-held"
HOLD_REVIEW = "review-gated"
HOLD_RUNNING = "running"
HOLD_MISSING = "missing"
HOLD_PENDING = "pending"

#: Classes whose warning is a NAG — the work is stuck and a human has to act,
#: so the line repeats on the throttle interval until the situation changes.
#: Everything else says its piece once per distinct status (see
#: :class:`OutstandingWarnThrottle`): re-telling an operator every five minutes
#: that the order they parked is still parked is the log-flood BUG-MSO-2026-0597
#: was filed about, one function away.
REPEATING_HOLD_CLASSES = frozenset({HOLD_STRANDED, HOLD_MISSING, HOLD_PENDING})

#: The pseudo-voyage id ``voyages_outstanding_work()`` files queue-only
#: stranded orders under (BUG-MSO-2026-0307).
QUEUE_PSEUDO_VOYAGE = "(queue)"


# ---------------------------------------------------------------------------
# One outstanding order
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class OutstandingOrder:
    """One non-COMPLETE voyage member, with the reason and the remedy.

    ``status`` is the EFFECTIVE status (ledger TERMINAL > archived order file >
    live ledger claim > the queue file's own), resolved by the caller through
    :func:`maestro.core.order_status.effective_order_status` so this module and
    ``mso status`` / ``mso doctor`` / the Hub cannot disagree about it.
    """

    voyage_id: str
    order_id: str
    status: str
    hold_class: str
    unsatisfied_deps: Tuple[str, ...] = ()
    blocking_dep_status: str = ""
    in_queue: bool = True

    # -- presentation ------------------------------------------------------

    @property
    def repeats(self) -> bool:
        """True when this line should re-emit on the throttle interval."""
        return self.hold_class in REPEATING_HOLD_CLASSES

    @property
    def remedy(self) -> str:
        """The action that is actually correct for THIS hold class.

        Every command named here exists (``mso order retry|remove|unskip``,
        ``mso review approve``, ``mso doctor``) — naming a plausible-sounding
        command that does not exist would be the same defect as naming the
        wrong one.
        """
        oid, vid = self.order_id, self.voyage_id
        if self.hold_class == HOLD_STRANDED:
            return (f"stranded and cannot clear on its own — "
                    f"`mso order retry {oid}`")
        if self.hold_class == HOLD_PARKED:
            drop = (f"`mso order remove {oid} --from-voyage {vid}`"
                    if vid and vid != QUEUE_PSEUDO_VOYAGE
                    else f"`mso order skip {oid}`")
            return (f"parked deliberately, not stranded — release it (set its "
                    f"status to PENDING) if it should run, or take it out of the "
                    f"voyage with {drop}. `mso order retry` would override the "
                    f"decision to park it")
        if self.hold_class == HOLD_DEP_HELD:
            if self.unsatisfied_deps:
                deps = ", ".join(self.unsatisfied_deps[:3])
                more = " …" if len(self.unsatisfied_deps) > 3 else ""
                dep_state = (f" ({self.blocking_dep_status})"
                             if self.blocking_dep_status else "")
                tail = (f" — recover it with `mso order retry "
                        f"{self.unsatisfied_deps[0]}`"
                        if self.blocking_dep_status in STRANDED_ORDER_STATUSES
                        else " — releases itself (AUTOQUEUE) once that completes")
                return (f"held on {deps}{more}{dep_state}{tail}. Retrying "
                        f"{oid} itself changes nothing")
            return (f"PROPOSED with no dependsOn — released by the plan-review "
                    f"gate (`mso review queue`, then `mso review approve {oid}`), "
                    f"or file the build orders it stands in for")
        if self.hold_class == HOLD_REVIEW:
            return (f"waiting on a human at the review gate — "
                    f"`mso review approve|revise|reject {oid}`")
        if self.hold_class == HOLD_RUNNING:
            return "a crew is on it right now — no action needed"
        if self.hold_class == HOLD_MISSING:
            drop = (f"`mso order remove {oid} --from-voyage {vid}`"
                    if vid and vid != QUEUE_PSEUDO_VOYAGE
                    else f"`mso order skip {oid}`")
            return (f"named by the voyage manifest but present in no queue and "
                    f"no archive — re-file the order, or {drop}")
        # HOLD_PENDING
        return (f"PENDING but the scan did not select it — see `mso doctor` "
                f"(dispatcher.scan-disagreement) for which filter excluded it")

    def where(self) -> str:
        if not self.voyage_id or self.voyage_id == QUEUE_PSEUDO_VOYAGE:
            return "in a queue, no active voyage manifest"
        return self.voyage_id

    def warning(self) -> str:
        """The operator-facing lifecycle line.

        BUG-MSO-2026-0506's rule: the load-bearing part goes FIRST, because
        ``sanitize_lifecycle_message`` truncates. Order id, status and remedy
        all sit ahead of anything decorative, and one line covers one order —
        a rolled-up line for N orders is the thing that gets truncated into
        uselessness.
        """
        return (f"Eight Bells withheld — {self.order_id} is {self.status} "
                f"[{self.hold_class}]: {self.remedy} ({self.where()}, BUG-0303)")


def classify_order_hold(
    voyage_id: str,
    order_id: str,
    status: Optional[str],
    *,
    in_queue: bool = True,
    unsatisfied_deps: Sequence[str] = (),
    blocking_dep_status: Optional[str] = "",
) -> OutstandingOrder:
    """Classify ONE outstanding order. Pure; never raises.

    Precedence is deliberate. A stranded status wins over an unsatisfied
    dependency (the order is broken in its own right — the dependency is not
    why it is stuck), and a parked status wins over a dependency hold (the
    operator's decision is the live fact about that order, whatever its
    ``dependsOn`` happens to say). An unrecognised status falls through to
    ``pending``, whose remedy points at ``mso doctor`` rather than guessing —
    the conservative answer, since the bell is withheld either way and a wrong
    remedy is worse than an honest "look here".
    """
    s = (status or "PENDING").strip().upper()
    deps = tuple(str(d) for d in (unsatisfied_deps or ()) if d)
    dep_state = (blocking_dep_status or "").strip().upper()

    if s in STRANDED_ORDER_STATUSES:
        hold = HOLD_STRANDED
    elif s in PARKED_ORDER_STATUSES:
        hold = HOLD_PARKED
    elif s in REVIEW_ORDER_STATUSES:
        hold = HOLD_REVIEW
    elif s in RUNNING_ORDER_STATUSES:
        hold = HOLD_RUNNING
    elif s in DEP_GATED_ORDER_STATUSES or deps:
        hold = HOLD_DEP_HELD
    elif not in_queue:
        hold = HOLD_MISSING
    else:
        hold = HOLD_PENDING

    return OutstandingOrder(
        voyage_id=voyage_id,
        order_id=order_id,
        status=s,
        hold_class=hold,
        unsatisfied_deps=deps,
        blocking_dep_status=dep_state,
        in_queue=in_queue,
    )


# ---------------------------------------------------------------------------
# Throttle
# ---------------------------------------------------------------------------

@dataclass
class OutstandingWarnThrottle:
    """Per-order emission gate for the "Eight Bells withheld" WARN.

    Replaces the single module-level ``_last_outstanding_warn`` timer, which
    had the exact defect BUG-MSO-2026-0597 fixed for ``SWEEP_STALLED_ORDER``
    one function away: a global gate means the first warning about a NEWLY
    stranded order is silently swallowed for up to five minutes by an
    unrelated order's re-emission. Keyed per order id, so it is not.

    Two tiers, because the two situations are not the same:

    * A **repeating** class (stranded / missing / unselected-PENDING) re-emits
      every ``interval_seconds`` — the work is stuck and the nag is the point.
    * Every other class emits ONCE per distinct status. A deliberately parked
      voyage therefore cannot emit the same line every 120s forever; it emits
      it when the dispatcher first sees it, and again only if the status
      actually changes (e.g. BACKLOG → PENDING → STALLED), which is exactly
      when the operator wants to hear about it again.

    Deliberately holds no clock: callers pass ``now``, which is what makes the
    behaviour testable without sleeping.
    """

    interval_seconds: int = 300
    _last: Dict[str, Tuple[str, datetime]] = field(default_factory=dict)

    def should_emit(self, entry: OutstandingOrder, now: datetime) -> bool:
        prev = self._last.get(entry.order_id)
        if prev is None:
            return True
        prev_status, prev_at = prev
        if prev_status != entry.status:
            return True  # the situation changed — always say so
        if not entry.repeats:
            return False  # said once; nothing new to tell
        return (now - prev_at).total_seconds() >= self.interval_seconds

    def record(self, entry: OutstandingOrder, now: datetime) -> None:
        self._last[entry.order_id] = (entry.status, now)

    def forget(self, live_order_ids) -> None:
        """Drop bookkeeping for orders that are no longer outstanding.

        Without this, an order that is recovered and later strands again would
        be judged against a stale "already told them" record and its first new
        warning suppressed — the same swallowed-first-warning failure the
        per-order keying exists to prevent.
        """
        live = {str(o) for o in live_order_ids}
        for oid in [k for k in self._last if k not in live]:
            self._last.pop(oid, None)


def emit_outstanding_warnings(entries, throttle, now, write_event) -> int:
    """Emit one throttled WARN per outstanding order. Returns the count emitted.

    ``write_event`` is ``fleet_runner.write_lifecycle_event`` in production and
    a recorder in tests. Never raises: a bad entry must not take the dispatcher
    loop down with it.
    """
    entries = list(entries or [])
    throttle.forget([e.order_id for e in entries])
    emitted = 0
    for entry in entries:
        try:
            if not throttle.should_emit(entry, now):
                continue
            write_event("WARN", entry.warning())
            throttle.record(entry, now)
            emitted += 1
        except Exception:
            continue
    return emitted
