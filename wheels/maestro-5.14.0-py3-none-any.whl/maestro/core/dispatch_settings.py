"""maestro/core/dispatch_settings.py — the limits a dispatcher is launched with.

BUG-MSO-2026-0800 (PLAN-PLN-MSO-2026-0792 §1.7 S3/S4, Order 4).

**Why this exists.** Before this module nothing read a configured crew count,
turn cap or timeout at dispatch time: the Hub's Dispatch button always spawned
``mso dispatch --max-crews 5``, and ``mso dispatch`` only knew its own argparse
defaults. Those defaults also disagreed with ``fleet_runner.py``'s (turns 200 vs
25; timeout 60 vs 25) and were bridged by ``!=`` sentinels in ``cmd_dispatch``
that did not match the parser — so ``--timeout`` silently ran at fleet_runner's
25, not the 60 its help text and FTR-MSO-2026-0299's Captain directive named.

**One resolution rule for every surface** (``mso dispatch`` and the Hub):

    explicit flag > ``dispatch.*`` effective setting (settings_core precedence:
    bundle > workspace.json > device settings.json) > legacy
    ``<mso>/config/fleet-settings.json`` ``maxCrews`` (crews only) > built-in.

The caller always forwards all three resolved values to ``fleet_runner.py``, so
its own parser defaults are never what a dispatcher silently runs with.

The community crew cap is NOT applied here: it stays in
``fleet_runner.run_dispatcher`` (``auth.community_crew_cap``), the single choke
point every launch path goes through, so it always applies last.

This module never raises: an unreadable or invalid stored value falls through
to the next tier, because a bad settings file must never stop a dispatch.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

__all__ = [
    "DEFAULT_MAX_CREWS", "DEFAULT_MAX_TURNS", "DEFAULT_TIMEOUT_MINUTES",
    "SOURCE_FLAG", "SOURCE_LEGACY", "SOURCE_DEFAULT",
    "DispatchLimits", "resolve_dispatch_limits",
]

DEFAULT_MAX_CREWS = 5
# The value `mso dispatch` has effectively run with since VOY-0062 (PR #118):
# cli.py's default, forwarded on every launch. fleet_runner.py's parser said 25.
DEFAULT_MAX_TURNS = 200
# FTR-MSO-2026-0299 (Captain directive): the activity watchdog is the primary
# hang control; the wall-clock ceiling is a generous 60-minute backstop.
DEFAULT_TIMEOUT_MINUTES = 60

SOURCE_FLAG = "flag"
SOURCE_LEGACY = "legacy"
SOURCE_DEFAULT = "default"

# (DispatchLimits attribute, settings_core key, built-in default)
_FIELDS = (
    ("max_crews", "dispatch.maxCrews", DEFAULT_MAX_CREWS),
    ("max_turns", "dispatch.maxTurns", DEFAULT_MAX_TURNS),
    ("timeout_minutes", "dispatch.timeoutMinutes", DEFAULT_TIMEOUT_MINUTES),
)


@dataclass(frozen=True)
class DispatchLimits:
    max_crews: int
    max_turns: int
    timeout_minutes: int
    # attribute -> where the value came from: flag | env | bundle | workspace |
    # device | legacy | default
    sources: dict = field(default_factory=dict)

    def argv(self) -> list[str]:
        """The fleet_runner/`mso dispatch` flags that launch with these limits."""
        return [
            "--max-crews", str(self.max_crews),
            "--max-turns", str(self.max_turns),
            "--timeout", str(self.timeout_minutes),
        ]

    def describe(self) -> str:
        return (
            f"max crews {self.max_crews} ({self.sources.get('max_crews')}), "
            f"max turns {self.max_turns} ({self.sources.get('max_turns')}), "
            f"timeout {self.timeout_minutes}m ({self.sources.get('timeout_minutes')})"
        )


def _positive_int(value: Any) -> Optional[int]:
    if isinstance(value, bool) or not isinstance(value, int):
        return None
    return value if value >= 1 else None


def _from_settings(mso: Optional[Path], key: str) -> tuple[Optional[int], Optional[str]]:
    try:
        from maestro.core import settings_core

        eff = settings_core.effective(mso, key)
    except Exception:
        return None, None
    if eff.source == settings_core.SOURCE_DEFAULT:
        return None, None
    value = _positive_int(eff.value)
    return (value, eff.source) if value is not None else (None, None)


def _legacy_max_crews(mso: Optional[Path]) -> Optional[int]:
    if mso is None:
        return None
    try:
        data = json.loads((Path(mso) / "config" / "fleet-settings.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return _positive_int(data.get("maxCrews")) if isinstance(data, dict) else None


def resolve_dispatch_limits(
    mso: Optional[Path],
    *,
    max_crews: Optional[int] = None,
    max_turns: Optional[int] = None,
    timeout_minutes: Optional[int] = None,
) -> DispatchLimits:
    """Resolve the crew count, turn cap and timeout a dispatcher launches with.

    *mso* is the workspace's ``.mso`` artefact dir (``None`` resolves against
    the device settings file alone). A non-``None`` keyword is an explicit flag
    and wins outright.
    """
    explicit = {"max_crews": max_crews, "max_turns": max_turns, "timeout_minutes": timeout_minutes}
    mso = Path(mso) if mso is not None else None
    values: dict[str, int] = {}
    sources: dict[str, str] = {}
    for attr, key, default in _FIELDS:
        if explicit[attr] is not None:
            values[attr], sources[attr] = explicit[attr], SOURCE_FLAG
            continue
        value, source = _from_settings(mso, key)
        if value is None and attr == "max_crews":
            value = _legacy_max_crews(mso)
            source = SOURCE_LEGACY if value is not None else None
        if value is None:
            value, source = default, SOURCE_DEFAULT
        values[attr], sources[attr] = value, source
    return DispatchLimits(sources=sources, **values)
