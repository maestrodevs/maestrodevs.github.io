# When a voyage is stuck

`mso docs when-a-voyage-is-stuck`

Work has stopped. No crew is running, nothing is failing loudly, and the board
has not moved in an hour. This page is what to do about that.

Maestro answers **"why is this not moving, and what are my options?"** once, and
shows you the same answer wherever you happen to be looking — the terminal, the
Hub, the patrol report. You never have to reconcile two surfaces that disagree,
because there is only ever one answer.

---

## Contents

- [Start here](#start-here)
- [Reading the answer in the terminal](#reading-the-answer-in-the-terminal)
- [Reading the answer in the Hub](#reading-the-answer-in-the-hub)
- [The eleven answers](#the-eleven-answers)
  - [Nothing is wrong](#nothing-is-wrong--three-answers-that-are-not-failures)
    - [Waiting at a review gate](#waiting-at-a-review-gate)
    - [Timed out and re-queued](#timed-out-and-re-queued)
    - [Queued behind work in progress](#queued-behind-work-in-progress)
  - [You parked it](#you-parked-it)
    - [Skipped](#skipped)
  - [Something failed](#something-failed)
    - [The verify gate could not run](#the-verify-gate-could-not-run)
    - [The verify gate failed](#the-verify-gate-failed)
    - [Convergence failed](#convergence-failed)
    - [Auto-serialised out of the voyage](#auto-serialised-out-of-the-voyage)
    - [Stalled](#stalled)
  - [Waiting on something else](#waiting-on-something-else)
    - [Held on a dependency](#held-on-a-dependency)
    - [Deadlocked](#deadlocked-voyages-only)
- [Your options, and why one may be greyed out](#your-options-and-why-one-may-be-greyed-out)
- [The evidence list](#the-evidence-list)
- [Scripting it](#scripting-it)
- [Quick reference](#quick-reference)

---

## Start here

Two commands, in this order. Start at the voyage, because a voyage answer names
the one order worth looking at and saves you guessing which of six to open.

```bash
mso voyage why VOY-ACME-2026-0163     # why can't this voyage advance?
mso order why  FTR-ACME-2026-0617     # why is this one order not moving?
```

Both are **read-only**. Neither changes an order, a voyage or the queue. Every
command they suggest is one you run yourself, after reading it.

Both exit **0** when nothing is wrong — a clean answer is a successful answer,
not an error:

```
$ mso order why FTR-ACME-2026-0620
FTR-ACME-2026-0620 is not blocked (PENDING).
```

An id that does not exist is the only failure case.

In the Hub, the same two answers arrive without you asking: a **panel at the top
of the order drawer**, and a **banner on the voyage row**. Both are described
[below](#reading-the-answer-in-the-hub).

---

## Reading the answer in the terminal

```
$ mso order why FTR-ACME-2026-0617

  FTR-ACME-2026-0617 is stuck: the verify gate failed
  ----------------------------------------------------------------------------
  The verify gate RAN and the code failed it, so the work was held and never
  pushed. verify command exit 1: 3 tests failed

  Kind:     VERIFY_FAILED
  Severity: high
  Since:    2026-09-08T14:22:10+00:00  (2 days)
  Voyage:   VOY-ACME-2026-0163
  Role:     BLD

  Detail:
  The local verify command exited non-zero (or timed out), so convergence was
  withheld and the crew's work was preserved rather than pushed.

  Evidence:
    - Verify log (full stdout+stderr)
      /home/you/acme/.mso/reports/verify/VERIFY-FTR-ACME-2026-0617-20260908.log
    - Preserved work on salvage/FTR-ACME-2026-0617-ca7cdb66
      branch: salvage/FTR-ACME-2026-0617-ca7cdb66
      18 file(s), +864/-12

  Options:
    1. Retry from salvage ca7cdb66 (18 file(s), +864/-12, BLD)   [recommended]
       mso order retry FTR-ACME-2026-0617 --salvage salvage/FTR-ACME-2026-0617-ca7cdb66
    2. Retry fresh at BLD (discard preserved work)
       mso order retry FTR-ACME-2026-0617 --no-salvage
       risk: The role re-runs from the converged voyage branch. Discards
             1 preserved salvage branch.
```

Six parts, always in this order:

| Part | What it is |
|------|-----------|
| **Title line** | The one-sentence verdict. The verb changes with the answer — *is stuck*, *is waiting*, *is recovering*, *is parked*, *is held*. Three of the eleven answers are not faults, and the title says so before you read anything else. |
| **Cause** | Plain English first, then whatever the tool that failed actually said, quoted rather than paraphrased. |
| **Kind / Severity / Since / Voyage / Role** | `Kind` is the machine word — the same one the Hub shows as a small chip, and the one this page's headings map to. `Since` carries a human age (`2 days`) beside the timestamp. |
| **Detail** | The fuller paragraph. The same text the Hub panel and the patrol report show — not a terminal-only rewrite. |
| **Evidence** | The files, branches and records that prove the verdict. Every path prints **on its own line, unwrapped**, so you can copy it straight into an editor. |
| **Options** | Ordered, best first. Each command is on its own line, and anything an option would cost you is printed with it as a `risk:` line — never as a footnote further down that you could act before reading. |

A **voyage** answer adds a **Blocked by** block: each blocking order with *its
own* diagnosis. "Held on FTR-ACME-2026-0618" is not an answer; "held on
FTR-ACME-2026-0618, which stalled after two retries at TST" is.

---

## Reading the answer in the Hub

### The order panel

Open any order the board has flagged — anything under **Needs Attention**,
**In Review** or **Blocked** — and the panel is the first thing in the drawer,
above the title field and above the footer's Retry button.

It **replaces nothing.** The Retry button, the recorded recovery note and the
lock banners all stay exactly where they were. The panel is the explanation
around them.

Top to bottom, it carries the same parts as the terminal:

- **the verdict**, with the machine word beside it as a small chip;
- **the cause sentence**, then the fuller detail paragraph in dimmer text;
- **Since**, when the transition time is known;
- **Waiting on** — each blocking order as a clickable row that opens *that*
  order's drawer, so you can follow a chain without going back to the board;
- **Evidence** — each item's label, its path or branch in monospace, and an
  **Open** button on anything the Hub can serve you inline (the verify log, a
  QA report, a plan). No Open button means the Hub cannot serve that file — the
  path is still there to copy;
- **Your options** — one row each, best first, with the top one badged
  **Recommended**.

A healthy order shows **no panel at all**. Nothing renders while the answer is
still loading, either: a placeholder that later vanishes is worse than a panel
that simply appears. If the answer genuinely cannot be fetched you get a short
line saying so — that one is never hidden.

### The voyage banner

A voyage row the board marks as needing attention grows a one-line banner
directly beneath it:

```
⚠  Deadlocked behind FTR-ACME-2026-0618 — every remaining order is held behind
   it and the fleet cannot advance any of them.   [ Why? ]
```

Click **Why?** and the full panel expands inline — same cause, same blocking
chain, same options, all acting on the blocking order rather than on the voyage.
Click again to collapse.

That one-line summary is **byte-identical** to the line `mso status` prints for
the same voyage. If you have both open, they cannot disagree.

### Acting from the panel

Every option with a Hub endpoint behind it is a real button — retry, skip,
unskip, approve, request changes, decline. Click it and the panel re-asks the
question afterwards, rather than leaving a stale diagnosis on screen next to a
button that just worked.

Options that exist only as a command render as a **copyable command block**, not
a dead button. Installing a missing toolchain is not something the Hub can do
for you; showing you the exact line to run is.

---

## The eleven answers

Ten can apply to an order. One — [deadlocked](#deadlocked-voyages-only) — applies
only to a voyage.

They are checked in a fixed order, and you are told the **first** one that fits.
That order is deliberate: a decision *you* made (skipping, review) is reported
ahead of any machine failure, because telling someone their own parked order is
"broken" is the fastest way to make them stop reading the panel.

### Nothing is wrong — three answers that are not failures

#### Waiting at a review gate

> `REVIEW_PENDING` · severity medium · *"… is waiting: waiting at a review gate"*

**What it means.** The order is paused at a review gate for a human decision.
The fleet is behaving correctly and will not dispatch it until someone
approves, revises or rejects it.

**What it does not mean.** Nothing failed. Nothing is at risk.

**What to do.** Decide. From the Hub, use the drawer's review action bar
(Approve / Request change / Decline). From the terminal:

```bash
mso review approve  ORDER-ID     # advance it
mso review revise   ORDER-ID     # send it back for changes
mso review reject   ORDER-ID     # archive it as failed
```

The answer also links **the plan under review**, so you can read what you are
approving without going hunting for it.

#### Timed out and re-queued

> `TIMEOUT_REQUEUED` · severity medium · *"… is recovering: timed out and was re-queued"*

**What it means.** A crew was killed at its time ceiling, its in-flight work was
preserved, and the dispatcher will pick the order up again on a later tick.

**What to do — usually nothing.** The recommended option is literally
*"Wait — the dispatcher will re-dispatch it by itself"*, and it carries the one
fact you need to judge that: **how many attempts remain before it stalls for
good.** This is the answer where the honest response is often "leave it alone",
and saying so is the point.

If it keeps timing out, the order is too heavy for its ceiling. Give that one
order more room by setting `timeoutMinutes` on it — the answer says so, and
tells you plainly that there is no CLI verb for it yet, so you edit the order.

#### Queued behind work in progress

> `DEP_HELD` · severity low · *"… is held: held on a dependency"*

**What it means.** This order waits on others, and every one of those is either
queued or actively in flight. None of them needs you. This order will dispatch
by itself once they finish.

**What it does not mean.** It is not stuck. This answer is deliberately kept out
of `mso doctor` and out of the stuck sweep for exactly that reason — it appears
only when *you* ask about this specific order, because "why is this not running"
is a fair question with a real answer.

**What to do.** Nothing. The only option offered is to look at what it is
waiting on.

### You parked it

#### Skipped

> `SKIPPED` · severity high · *"… is parked: skipped by an operator"*

**What it means.** Someone put this order on the skip list. The dispatcher drops
it from every dispatch tick and will never pick it up.

**What to do.**

```bash
mso order unskip ORDER-ID                          # put it back in the queue
mso order remove ORDER-ID --from-voyage VOY-ID     # take it out of the voyage
```

**Retrying a skipped order does nothing.** It re-queues an order the skip list
still vetoes — it looks like the fix and changes nothing. That is why the
recommended option here is always *un-skip*, never *retry*, in the terminal and
in the Hub alike.

### Something failed

#### The verify gate could not run

> `VERIFY_DEPS_FAILED` · severity high · *"… is stuck: the verify gate could not run"*

**What it means.** The toolchain your verify command invokes is missing, so the
gate never executed and **the code was never actually judged**.

**What it does not mean.** This is *not* a broken build. Reading it as one, and
going looking for a code bug that is not there, is the documented mis-step.

**What to do.** The answer's first option is the recorded remedy, quoted word
for word from the run that failed — usually "install X, then retry". Install the
toolchain, then:

```bash
mso order retry ORDER-ID
```

The install log is linked as evidence. Open that first: it says which tool was
missing and what the install step actually did.

#### The verify gate failed

> `VERIFY_FAILED` · severity high · *"… is stuck: the verify gate failed"*

**What it means.** The verify command **ran**, the code failed it, and the work
was held rather than pushed. That is the gate doing its job: a broken build never
reached CI and never cost you a run.

**What to do.** Read the log, fix the code, retry.

The evidence names a **full stdout+stderr log** — not the excerpt you may have
seen scroll past in the dispatcher output. It is written outside the crew's
working copy, so it survives the crew being torn down. Go straight to that path;
the excerpt is a convenience, the log is the record.

Then take an option: retry from the preserved work, or retry fresh and discard
it. Both are offered, and the second says exactly how much work it throws away.

#### Convergence failed

> `CONVERGENCE_FAILED` · severity high · *"… is stuck: convergence failed"*

**What it means.** The crew **finished**. Merging its work into the voyage branch
is what failed. The work exists and is preserved on a salvage branch.

**What to do.** Merge it. Because the role is already finished, arming that
preserved branch *is* the completion — re-running the role would rebuild work
that already exists, at full cost. That is why the salvage option is the
recommended one here, unlike everywhere else:

```bash
mso order retry ORDER-ID --salvage salvage/ORDER-ID-<sha>
```

If a recovery note was recorded when it failed, the answer quotes it verbatim
rather than writing a second version of the same advice.

#### Auto-serialised out of the voyage

> `AUTO_SERIALIZE` · severity high · *"… is stuck: auto-serialized out of the voyage"*

**What it means.** A genuine source conflict with another crew's work took this
order out of the voyage. Its changes sit on a salvage branch and were **never
merged**. The answer names how many files conflicted and the first few by name.

**Read this one carefully.** This is the case where an order can read
**COMPLETE while its only code changes are unmerged.** Check the branch before
trusting the status.

**What to do.** Retry from the preserved branch, or retry fresh — the same two
options as above, with the same stated costs.

#### Stalled

> `STALLED` · severity high · *"… is stuck: stalled"*

**What it means.** The fleet used up its retry budget and gave up. **It will not
touch this order again by itself.** Only you can move it.

There are two shapes, and the answer distinguishes them, because the recovery is
different:

- **It gave up.** *"Gave up after 2 requeue(s) at TST: … Only a retry can move
  it."* Retry it — from preserved work if there is any, fresh if not.
- **It was rejected on review.** A reviewing role judged the work insufficient
  and said why. The work is on the voyage branch **and** was rejected, so the
  rebuild has to happen. The answer names the rejecting role, the blocking
  defects, and gives you the exact retry that re-runs the *previous* role rather
  than the one that did the rejecting. A plain retry here re-runs the reviewer
  and gets you rejected again.

**Evidence to read first**, in order: the recorded recovery note, the preserved
branches with their sizes, the last timeout brief, and the crew's own output
directory.

**One other option**, offered here and nowhere else: *skip and release
dependents*. It tells you how many other orders are waiting on this one and
would be freed — and that this one is then never dispatched again.

### Waiting on something else

#### Held on a dependency

> `DEP_HELD` · severity high · *"… is held: held on a dependency"*

**What it means.** This order waits on others, and the chain roots in something
that **cannot resolve without you** — a stall, a failed gate, a skip.

**The options act on the root of the chain, never on the order you asked
about.** Retrying this order changes nothing: the dependency gate holds it right
back. So the options read *"Unblock FTR-ACME-2026-0618: retry from salvage …"*,
each one the *root's* recommended action carried up to you.

You also get *"Release this order by skipping &lt;root&gt;"* — which frees this
order and everything else waiting on that root, and never dispatches the root
again.

The chain is walked to its root for the **list** of blockers, but only the root
gets a full diagnosis. Run `mso order why` on any blocker id in the list — or
click its row in the Hub panel — to go one level deeper yourself.

> Compare [queued behind work in progress](#queued-behind-work-in-progress),
> which is the *same* dependency hold with a healthy root. Same word, very
> different answer — "held" is simply not the same claim as "stuck", and
> conflating the two is what makes a panel people stop reading.

#### Deadlocked (voyages only)

> `DEADLOCKED` · severity high · *"… is stuck: deadlocked"*

**What it means.** Every remaining order in the voyage is held behind one order
that cannot resolve on its own. The voyage cannot advance at all until that one
is dealt with.

**What to do.** Recover the blocking order. The first option names it and gives
you the correct verb for *its* state — an unskip if it was skipped, a retry if
it stalled. The blocking chain is listed beneath, each entry with its own cause.

### And one more shape: a voyage that is simply not progressing

Not every stopped voyage is deadlocked. When every remaining order is blocked and
no crew is running, but at least one of those orders could be released by a
decision you make — an approval, a retry, an unskip — the voyage answer says so:

```
Not progressing: all 5 remaining order(s) are blocked and no crew is running.
Start with FTR-ACME-2026-0618 (STALLED).
```

It reports the **most common** reason across the remaining orders, colours itself
by the **worst** one, lists every member with its own cause, and points you at
the single order worth starting with. This is deliberately **not** called a
deadlock: the chain does not need unwinding, it needs one decision.

---

## Your options, and why one may be greyed out

Options are **ordered, best first**, and at most one is ever marked
**Recommended**. Two recommendations is not a stronger hint, it is an incoherent
one.

Sometimes there is **no** recommendation, and that is deliberate. When more than
one preserved branch could hold the work and Maestro cannot tell which, it
refuses to pick — you get one option per branch, each stating why the choice is
ambiguous, and you decide. A confident-looking default there would be a guess
dressed as an answer.

Every option that would cost you something says so, next to the option, before
you act on it:

```
    2. Retry fresh at BLD (discard preserved work)
       mso order retry FTR-ACME-2026-0617 --no-salvage
       risk: The role re-runs from the converged voyage branch. Discards
             1 preserved salvage branch.
```

In the Hub, an option that **cannot run in this deployment** is shown
**disabled, with the reason** — never hidden, and never a button that fails
after you click it. The two reasons you will meet:

| You see | It means |
|---------|----------|
| *"This Hub is an observe-only deployment…"* | This Hub can watch but not act. Run the command from a host session instead. |
| *"Maestro Hub dispatch control requires a Team or Enterprise licence."* | The control action is above your licence tier. The equivalent CLI command still works. |

The reason shown *before* you click is the same sentence the endpoint would give
you *after*, so the pre-click explanation and the post-click refusal cannot
disagree. And an option with no endpoint at all is never a dead button — it is a
copyable command, because you can still act on it.

---

## The evidence list

Everything in the evidence list is a real file, branch or record that already
existed. Nothing is generated for the panel.

| Evidence | What it is | Read it when |
|----------|-----------|--------------|
| **Verify log** | The complete stdout and stderr of the verify run, written outside the crew's working copy so it outlives the crew. | Always, for either verify answer. The excerpt is a convenience; this is the record. |
| **Preserved work on a branch** | A branch holding work a crew produced before it was killed, or before a merge failed, with its size. | Before choosing between retrying from it and retrying fresh. |
| **Recorded recovery note** | The recovery advice written at the moment the order was archived, quoted verbatim. | First — it is often the whole answer. |
| **Timeout brief** | What a crew left behind when it was killed, including whether partial work reached disk. | When an order has timed out more than once. |
| **Crew output directory** | The crew's own progress file, activity log and iteration state. | When you want to know what the crew *thought* it was doing. |
| **Lifecycle events** | The last few recorded events naming this order. | For the sequence of what happened, in order. |
| **The plan under review** | The plan document a review gate is waiting on. | Before approving or rejecting. |
| **Dependency hold record** | What the dispatcher recorded about this order's hold, and when. | When a hold looks stale. |

A size that could not be measured says **"diff-stat unknown"**. It never says
"0 files" — that would read as *"the crew produced nothing"*, which is a very
different and possibly false claim.

---

## Scripting it

Both verbs take `--json` and emit the same record the Hub serves, so a script
can consume either surface without knowing which one produced the answer:

```bash
mso order why  ORDER-ID --json
mso voyage why VOY-ID   --json
```

A blocked subject emits the full record — cause, evidence, blockers, options.
An unblocked one emits:

```json
{ "subjectId": "FTR-ACME-2026-0620", "blocked": false, "status": "PENDING" }
```

The exit code is **0** for both. Check `blocked`, not the exit code.

---

## Quick reference

| The answer | Severity | Is anything wrong? | What you do |
|------------|----------|--------------------|-------------|
| Skipped | high | No — you parked it | `mso order unskip` (never *retry*) |
| Waiting at a review gate | medium | No | Approve, revise or reject |
| The verify gate could not run | high | Yes — tooling, not code | Install the toolchain, then retry |
| The verify gate failed | high | Yes — the code | Read the full log, fix, retry |
| Convergence failed | high | Yes — the merge, not the work | Retry **from the preserved branch** |
| Auto-serialised | high | Yes — a real conflict | Check the branch; the status may read COMPLETE |
| Stalled | high | Yes — the fleet gave up | Retry, rebuild against the rejection, or skip |
| Timed out and re-queued | medium | No — it is recovering | Usually nothing; raise its ceiling if it recurs |
| Held on a dependency | high | Yes — at the root | Act on the **root**, not on this order |
| Queued behind work in progress | low | No | Nothing |
| Deadlocked *(voyage)* | high | Yes | Recover the one blocking order |

---

## Where else the same answer appears

The verdict is computed **once** and rendered everywhere, in the same words:

- `mso order why` and `mso voyage why` — the full answer.
- `mso status` — the one-line verdict on a voyage that is not progressing,
  identical to the Hub's banner line.
- The Hub — the order drawer's panel and the voyage row's banner.
- `mso doctor` — a stuck-order finding whose suggested command is the same
  first option the panel recommends.
- The resident LEAD agent's findings — the same title and detail, not a
  paraphrase of them.

If two of those ever disagreed about why something was stuck, you would have to
work out which one to believe. Sharing one answer is how that question never
comes up.

---

## See also

- [CLI-REFERENCE.md](CLI-REFERENCE.md#mso-order-why--mso-voyage-why) — flags and
  the exact output shape for both verbs.
- [TROUBLESHOOTING.md](TROUBLESHOOTING.md) — errors with a specific message to
  match, especially dispatch and crew failures.
- [HUB.md](HUB.md#board-buckets-and-inline-review-actions) — the board buckets
  that decide which orders get a panel.
- [ORDERS-AND-VOYAGES.md](ORDERS-AND-VOYAGES.md) — order states and the
  lifecycle they move through.
