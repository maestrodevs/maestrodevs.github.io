# Settings

Maestro has **one list of settings**, **two files** that hold them, and **one
rule** for deciding which value wins. `mso settings`, the Hub's workspace
settings drawer and the Hub's **Settings** page all read and write through that
same list, so a value set in one place is exactly what the other two show.

```bash
mso settings list                    # every key: effective value + where it came from
mso settings get dispatch.maxCrews   # one key: value, source, default, scope, lock
mso settings set verifyTimeoutMinutes 30
mso settings unset verifyTimeoutMinutes
mso settings set --device spawnMonitor false
```

Every value is always shown **with its source**, e.g.
`false  (env: $MAESTRO_SPAWN_MONITOR)`. You never see "on" while an environment
variable is actually forcing "off".

---

## The rule: which value wins

For every key, the first source that has a value decides:

1. **Environment variable**, but only for keys that declare one (see the tables below).
2. **Signed policy bundle** (Enterprise). A bundle-pinned key is **locked**: it
   cannot be changed from the CLI or the Hub, and the lock reason names the bundle.
3. **Workspace file**: `<artefact root>/config/workspace.json`.
4. **Device file**: `~/.maestro/config/settings.json`.
5. **Built-in default.**

A key's **scope** decides which of the two files may hold it:

| Scope | Lives in | Meaning |
|-------|----------|---------|
| `device` | device file only | A property of this machine. Applies to every project on it. |
| `workspace` | workspace file only | A property of the project. It travels with the project's artefact plane. |
| `both` | either | A device default that one project can override. The workspace value wins. |

Three kinds of key keep their own existing storage and precedence. They are
listed under [Keys with their own storage](#keys-with-their-own-storage) below.

---

## The two files

| File | Holds | Committed? |
|------|-------|------------|
| `<artefact root>/config/workspace.json` | `workspace` and `both` keys for one project | Travels with the artefact plane: the `.mso/` directory in embedded mode, or the artefact repo in solo/shared mode ([ARTEFACT-REPO.md](ARTEFACT-REPO.md)). |
| `~/.maestro/config/settings.json` | `device` and `both` keys for this machine | Never. It is device-local. `$MAESTRO_HOME` moves it. |

Both files are ordinary JSON. Dotted keys are nested objects: `completion.voyagePr.draft`
is stored as `{"completion": {"voyagePr": {"draft": ...}}}`.

**A write changes only the key you name.** Every other key in the file is kept,
including keys that are not in the settings list. A file that exists but cannot
be parsed is **refused rather than overwritten**. Fix or remove it, then retry.

> **Keys outside the list still work.** Settings such as `completion.roleTimeouts`,
> `completion.supervision.*`, `completion.roleRejection.*`, `verify.*` and `charts`
> are honoured when you edit `workspace.json` by hand. `mso settings` and the Hub
> neither show nor write them yet.

---

## Every key

`Restart` means the value is read when a process starts. A running dispatcher
(or, for `persona`, any running `mso` process) keeps its old value until it is
restarted.

### Device

| Key | Type | Default | Env | Restart | What it does |
|-----|------|---------|-----|---------|--------------|
| `spawnMonitor` | bool | `true` | `MAESTRO_SPAWN_MONITOR` | | Open the terminal Maestro Monitor window when a dispatcher starts. With the env var, anything except `0`/`false`/`no`/`off` means on. |

### Device or workspace (`both`)

| Key | Type | Default | Env | Restart | What it does |
|-----|------|---------|-----|---------|--------------|
| `persona` | enum | `default` | `MAESTRO_PERSONA` | yes | Persona vocabulary for the CLI, the Hub and crew prompts. One of the built-in persona ids (`mso settings get persona` lists them). See [PERSONAS.md](PERSONAS.md). |
| `dispatch.maxCrews` | int ≥ 1 | `5` | | yes | Concurrent crews a dispatcher launches. The community tier is capped at 2 whatever this says. |
| `dispatch.maxTurns` | int ≥ 1 | `200` | | yes | Claude turn cap per crew iteration. |
| `dispatch.timeoutMinutes` | int ≥ 1 | `60` | | yes | Wall-clock ceiling per crew iteration. The activity watchdog (`completion.supervision.stallMinutes`) is the primary hang control; this is the backstop. |

**How `dispatch.*` is applied.** `mso dispatch` and the Hub's **Dispatch** button
resolve each limit the same way:

1. an explicit flag (`--max-crews`, `--max-turns`, `--timeout`);
2. the effective `dispatch.*` setting;
3. for crews only, a legacy `maxCrews` in `<artefact root>/config/fleet-settings.json`;
4. the built-in default.

The community crew cap applies last. A per-order `timeoutMinutes`, or
`completion.roleTimeouts`, still overrides the timeout for that order or role.

### Workspace

| Key | Type | Default | Restart | What it does |
|-----|------|---------|---------|--------------|
| `defaultGitHubOrg` | str or null | `null` | | GitHub organisation voyage branches and PRs are created in. |
| `verifyCommand` | str | `""` | | Command run in the crew worktree before a convergence push. Empty disables the local verify gate. |
| `verifyTimeoutMinutes` | int ≥ 1 | `20` | | Wall-clock cap for `verifyCommand`. |
| `completion.voyagePr.draft` | bool | `true` | | Open the voyage PR as a draft, so intermediate pushes do not run CI. |
| `completion.voyagePr.promoteOnFinalisation` | bool | `true` | | Mark the voyage PR ready for review when its last order completes. |
| `completion.voyageRel.enabled` | bool | `false` | | File one voyage-level REL order when a voyage's last order completes. |
| `completion.idleWatchdog.enabled` | bool | `true` | yes | Act when every crew is idle and no work is pending. |
| `completion.idleWatchdog.idleMinutes` | int ≥ 1 | `30` | yes | Minutes of all-crews-idle before the watchdog acts. |
| `completion.idleWatchdog.action` | enum | `cleanup` | yes | `cleanup` clears stale state and exits; `warn` logs `IDLE_TIMEOUT`; `none` does nothing. |
| `lead.enabled` | bool | `true` | | Whether the resident LEAD agent is enabled for this workspace. |
| `lead.tokenCeiling.dailyTokens` | int ≥ 1 | `200000` | | Daily token ceiling for the LEAD daemon. It is an abnormal backstop, not a routine limit. |
| `providers.scm` / `.ci` / `.issues` / `.deploy` | object or null | none | | The SDLC provider for each kind. See [Keys with their own storage](#keys-with-their-own-storage). |
| `models.<ROLE>.model` | model id | the role's default | | Claude model the role's crews run on. |
| `models.<ROLE>.contextWindow` | enum | `standard` | | `standard` or `1m`. |
| `models.<ROLE>.effort` | enum | the role's default | | `low`, `medium`, `high` or `xhigh`. |

`<ROLE>` is one of `PLN`, `BLD`, `TST`, `DOC`, `SEC`, `REL`, `LEAD`: 21 model keys in all.
Built-in defaults (regenerate with `python scripts/render_model_table.py` if they change):

| Role | `model` | `contextWindow` | `effort` |
|------|---------|-----------------|----------|
| PLN | `claude-opus-5` | `standard` | `medium` |
| BLD | `claude-sonnet-5` | `standard` | `high` |
| TST | `claude-sonnet-5` | `standard` | `high` |
| DOC | `claude-sonnet-5` | `standard` | `high` |
| SEC | `claude-haiku-4-5-20251001` | `standard` | `high` |
| REL | `claude-opus-5` | `standard` | `medium` |
| LEAD | `claude-opus-5` | `standard` | `medium` |

---

## Keys with their own storage

These keys keep the files and precedence they already had. `mso settings` writes
them into those same files, so nothing about how they are honoured has changed.

### `persona`

The persona is **not** stored in `workspace.json` or `settings.json`. It lives
in the persona files the persona resolver has always read:

| Scope | File |
|-------|------|
| workspace | `<product repo>/.maestro/config/persona.json` |
| device | `~/.maestro/config/persona.json` |

`mso settings set persona nautical` writes the pointer form `{"id": "nautical"}`.
The resolver's order is unchanged: `MAESTRO_PERSONA` > workspace file > device
file > built-in `default`.

If a persona file holds a **full custom persona definition** rather than a
pointer, Maestro refuses to overwrite or remove it. Move it aside by hand first.

A `persona` key inside `workspace.json` is **not read** by anything.

### `models.<ROLE>.*`

Role models live in `<artefact root>/config/role-models.json`, the same file
`mso config models` reports on ([CONFIG-MODELS.md](CONFIG-MODELS.md)). A write
preserves the file's `_comment` and every other entry. The value and source
shown are the ones the crew resolver itself produces. Their precedence is the
resolver's own:

1. a `model` field on the order itself;
2. `role-models.json` (source `workspace`);
3. `MAESTRO_MODEL_<ROLE>`, `MAESTRO_CONTEXT_<ROLE>` or `MAESTRO_EFFORT_<ROLE>` (source `env`);
4. a role overlay in `.mso/config/roles/<CODE>.md` (source `overlay`);
5. the built-in default.

**Only current-generation models may be chosen.** The model list is taken from
the models this Maestro version supports. The newest model of each family counts
as current, and `claude-opus-5` is offered first.

Previous-generation ids such as `claude-opus-4-8` and `claude-sonnet-4-6` are
still **supported**. A pin that already names one keeps working, and is shown
flagged `previous generation`. They are **not offered** as a new choice:
`mso settings set models.PLN.model claude-opus-4-8` is refused, with the list of
current ids.

A bare model id is required. To use the 1M context window, set
`models.<ROLE>.contextWindow` to `1m` rather than appending `[1m]` to the id.

### `providers.<kind>`

Provider settings are written by the provider configuration code, into the
`providers` block of `workspace.json`. The value is an object:

```bash
mso settings set providers.ci '{"id": "jenkins", "config": {"url": "https://ci.example.com"}}'
```

A provider locked by a signed policy bundle is reported as locked, and cannot be
changed. In the Hub these keys appear in the **SDLC Providers** section, not in
the generic settings form. See [PROVIDERS.md](PROVIDERS.md).

---

## `mso settings`

```
mso settings [--project ACRONYM] list  [--device] [--json]
mso settings [--project ACRONYM] get   KEY [--device] [--json]
mso settings [--project ACRONYM] set   KEY VALUE [--device]
mso settings [--project ACRONYM] unset KEY [--device]
```

| Action | What it does |
|--------|--------------|
| `list` | Every key with its effective value and source. Inside a workspace this is every key; with `--device` it is only the `device` and `both` keys, resolved without a workspace. |
| `get KEY` | One key: value, source, default, scope, and whether it needs a restart or is locked. |
| `set KEY VALUE` | Write the key. By default a `device` key goes to the device file and every other key to the workspace file. `--device` writes a `both` key to the device file instead. |
| `unset KEY` | Remove the key from that file, so the next source in the rule applies. |

`--project ACRONYM` picks a registered workspace when you are not inside one.

**Values** are parsed by type:
- bool: `true`/`false`, `yes`/`no`, `on`/`off`, `1`/`0`;
- int: a whole number;
- nullable key: `null`;
- object: JSON.

**After a write** the command prints the effective value read back from disk.
If a higher source still wins, for example an environment variable, the output
says so. A write to a restart key reminds you to restart.

**Errors** exit `1` with a reason and, where there is one, a hint. The errors are:
- an unknown key;
- a value of the wrong type or out of range;
- a `workspace` key with `--device`;
- a `device` key without `--device`;
- a locked key;
- a file Maestro refuses to overwrite.

In a **governed** workspace, writing a workspace setting also requires the
`settings.write` identity capability.

---

## In the Hub

- **Workspace settings drawer** (a workspace's **Settings** button). It shows every
  `workspace` and `both` key for that project and saves to its workspace file.
- **Settings page** (sidebar → **Settings**, headed *Applies to every project on
  this device*). It shows the `device` and `both` keys and saves to the device file.

Both screens are generated from the settings list. A key appears in the Hub
only if Maestro knows which code honours it.

What you will see:

- **A source badge on every field**: `workspace`, `device`, `env`, `bundle`,
  `overlay` or `default`. A workspace value overrides a device value.
- **Read-only fields, with the reason shown.** A field whose value comes from an
  environment variable or a policy bundle, or that is locked, cannot be edited
  in the Hub. Change the environment variable or the bundle instead.
- **A `restart` chip** on keys that take effect at the next dispatcher start.
- **Save sends only the keys you changed**, one request per key, then re-reads.
  If some writes fail, the message names the keys that were not written.
- **Repositories are read-only.** Change a workspace's repositories with
  `mso migrate import-workspace` ([MULTI-REPO.md](MULTI-REPO.md)).

Saving from the Hub requires a **Pro, Team or Enterprise** licence. Save is
also unavailable in an observe-only (containerised) Hub. The reason is shown on
the control before you click. Reading settings is never gated. Endpoints and
capability fields: [HUB.md](HUB.md#settings-workspace-and-device).

The drawer no longer shows `maxIterations`, `autoDispatch` or `tokenDailyCap`.
Nothing in Maestro ever read them. Use `dispatch.maxCrews`, `dispatch.maxTurns`
and `dispatch.timeoutMinutes` for dispatch limits.
