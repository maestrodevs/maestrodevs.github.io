# Configuring per-role models

Maestro assigns a Claude model to each role based on what the role does:

| Role | Default model | Default effort | Why |
|------|---------------|----------------|-----|
| **PLN** — Planner (NAV) | `claude-opus-5` | `medium` | Planning & architecture — high-leverage, low-volume; a better plan prevents downstream rework |
| **BLD** — Builder (SHP) | `claude-sonnet-5` | `high` | Implementation — highest-volume role; Sonnet is strong here. Promote individual hard orders via the per-order `model` override |
| **TST** — Tester (BOS) | `claude-sonnet-5` | `high` | QA, testing |
| **DOC** — Docs writer (SCR) | `claude-sonnet-5` | `high` | Documentation |
| **SEC** — Security (LKT) | `claude-haiku-4-5-20251001` | `high` | Fast investigation, scanning — independent adversarial reviewer |
| **REL** — Releaser (COX) | `claude-opus-5` | `medium` | Integration review + release — last role in the chain; best judgement matters most |
| **LEAD** | `claude-opus-5` | `medium` | Interactive orchestration & judgement |

In short: **PLN Opus 5, BLD/TST/DOC Sonnet 5, SEC Haiku 4.5, REL Opus 5.** These values are `DEFAULT_ROLE_MODEL_IDS` and `DEFAULT_ROLE_EFFORT` in `maestro/core_constants.py`; `mso config models` prints what your workspace actually resolves.

Selection principle: **high-stakes × low-volume → Opus**. PLN/REL/LEAD run infrequently but their decisions propagate, so they get Opus; the high-volume production roles (BLD/TST/DOC) stay on Sonnet, and SEC on Haiku.

## Available models

Every model below can be selected for any role or any order. No role defaults to Fable.

| Model | ID | Notes |
|-------|----|-------|
| Fable 5.1 | `claude-fable-5-1` | Highest-capability tier. Reserve for individual hard orders — see [Choosing Fable 5.1](#choosing-fable-51-for-an-order-or-a-role) |
| Fable 5 | `claude-fable-5` | |
| Opus 5 | `claude-opus-5` | Default for PLN / REL / LEAD |
| Sonnet 5 | `claude-sonnet-5` | Default for BLD / TST / DOC |
| Haiku 4.5 | `claude-haiku-4-5-20251001` | Default for SEC |
| Opus 4.8 / 4.7 / 4.6 | `claude-opus-4-8`, `claude-opus-4-7`, `claude-opus-4-6` | Previous generation, still supported (historical pricing and transcripts resolve) |
| Sonnet 4.6 | `claude-sonnet-4-6` | Previous generation, still supported |

This set is `SUPPORTED_MODELS` in `maestro/core/crew.py`. Maestro refuses to dispatch against a model ID it can't price (no `PRICING` entry in `maestro/core/fleet_usage_tracker.py`) — an unknown ID at any override layer raises an error naming the supported set, rather than silently dispatching. Adding a new model means updating both `SUPPORTED_MODELS` and `PRICING` in the framework — file an FTR if you need one Maestro doesn't have.

A model ID may carry the `[1m]` context-window suffix (e.g. `claude-opus-5[1m]`); it is stripped before validation. See [Context window](#context-window) below.

## How a role's model is resolved

Five layers, evaluated from highest to lowest priority — the first one that sets a model wins:

1. **Per-order** — order JSON `model` field (one-off, for a hard order)
2. **Workspace config** — `.mso/config/role-models.json` (per-project, persistent)
3. **Env var** — `MAESTRO_MODEL_<ROLE>` (per-shell, fastest to test)
4. **Role overlay** — `model` in `.mso/config/roles/<CODE>.md` frontmatter (per-project, travels with the role's other customisations)
5. **Built-in default** — the table at the top of this page

### Opus 5 at medium effort for the Opus roles (FTR-MSO-2026-0419)

PLN/REL/LEAD default to **`claude-opus-5` at `medium` effort** (formerly `claude-opus-4-8` at `high`). This is the narrow policy retune supported by the [INV-MSO-2026-0417 A/B measurement](../../.mso/reports/investigation/INV-MSO-2026-0417/INV-MSO-2026-0417-opus5-ab.md). What the data showed:

- **Model swap at equal effort is cheaper.** Replacing the historical Opus 4.8 default with Opus 5 at the *same* effort measured **~0.82×** the cost on an M-class order (0405) and **~0.76×** on a class-S order (0411), both passing the quality gate.
- **The effort ladder is flat on quality but steep on cost.** Across low → medium → high → xhigh, quality was flat while cost rose ~**2.3×** (0405: low $3.50, medium $3.32, high $4.80, xhigh $7.72).
- **The saving inverts if you raise effort.** Opus 5 at `high` cost **~1.19×** and at `xhigh` **~1.92×** the historical Opus 4.8/medium baseline — *more* expensive for no measured quality gain. **The economy win comes from dropping effort, not merely from switching model. Do NOT reflexively raise effort on Opus 5.**

**Honesty caveat (read before trusting these numbers).** Every measured run **timed out at a bounded 15-minute ceiling** (none signalled completion within budget), and the quality gate was **import-smoke** — "do the touched files still import" — not a full acceptance-criteria check. So "quality flat" means **"nothing obviously broke"**, not "output is equivalent". Treat the ratios as directional. The change is fully reversible by reverting the `DEFAULT_ROLE_MODEL_IDS` and `DEFAULT_ROLE_EFFORT` entries for PLN/REL/LEAD in `maestro/core_constants.py`.

**Not part of the A/B:** BLD/TST/DOC and SEC. BLD/TST/DOC were later moved from Sonnet 4.6 (formerly their default) to Sonnet 5 at identical list price — a generation refresh, not a cost decision. SEC stays on Haiku 4.5. Opus 5 was never measured against Sonnet in the production roles, and SEC is the independent adversarial reviewer — assuming Opus 5 wins there is unmeasured speculation.

These defaults are tuned for the typical AU/NZ price-and-quality envelope.

## Inspecting the active configuration

```bash
mso config models
```

Prints a table showing the resolved model for each role and the source that decided it. The per-order layer can't be displayed in a static table (it depends on the order being dispatched), so this command shows the layers below it.

## Layer 1 — Per-order override

Add a `model` field to an order JSON. Highest priority — beats every other layer.

```json
{
  "orderId": "FTR-PSG-2026-0042",
  "type": "FTR",
  "role": "BLD",
  "title": "Refactor the auth flow",
  "model": "claude-opus-5"
}
```

Use this when one specific order needs a different model — e.g. a particularly thorny BLD refactor that benefits from Opus, while the rest of the fleet stays on Sonnet for cost.

## Layer 2 — Workspace config

Create `.mso/config/role-models.json` in your workspace:

```json
{
  "models": {
    "BLD": "claude-opus-5",
    "TST": "claude-opus-5"
  }
}
```

Only the roles you list are overridden — everything else falls through to the lower layers. Survives across shells, runs, and dispatcher restarts. Per-project: each project workspace can have its own.

## Layer 3 — Env var

```powershell
# PowerShell
$env:MAESTRO_MODEL_BLD = "claude-opus-5"
```

```bash
# bash / WSL
export MAESTRO_MODEL_BLD=claude-opus-5
```

Lives only in the shell that set it — useful for one-off testing or CI where you want different routing without touching files. Linux/macOS env vars are case-sensitive (must be uppercase `MAESTRO_MODEL_BLD`); Windows is case-insensitive at the OS level.

## Layer 4 — Role overlay

Set `model` in the role's overlay frontmatter at `.mso/config/roles/<CODE>.md`. Useful when the model choice belongs with the other customisations you've made to that role. See [ROLE-OVERLAYS.md](ROLE-OVERLAYS.md) for the full overlay format.

```markdown
---
{
  "role_code": "REL",
  "role_name": "Releaser",
  "extends": "core",
  "model": "claude-opus-5"
}
---
```

An overlay's `model` sits **below** the workspace config and env var layers, so a `role-models.json` entry or `MAESTRO_MODEL_<ROLE>` for the same role still wins.

## Choosing Fable 5.1 for an order or a role

`claude-fable-5-1` (Fable 5.1) is the highest-capability model Maestro supports. It lists at **$10 / $50 per MTok** (input / output) against Opus 5's $5 / $25 (`PRICING` in `maestro/core/fleet_usage_tracker.py`), and no role defaults to it. It is best reserved for individual hard orders — architecture-level design, a hard concurrency bug — not used as a role-wide default.

**For one order** (recommended) — add the per-order `model` field:

```json
{
  "orderId": "PLN-PSG-2026-0107",
  "type": "PLN",
  "role": "PLN",
  "title": "Design the multi-region replication architecture",
  "model": "claude-fable-5-1"
}
```

**For every order a role runs, via a role overlay** — create `.mso/config/roles/PLN.md`:

```markdown
---
{
  "role_code": "PLN",
  "role_name": "Planner",
  "extends": "core",
  "model": "claude-fable-5-1"
}
---
```

Then check that it took effect:

```bash
mso roles validate            # overlay parses and the model ID is recognised
mso config models             # PLN now resolves to claude-fable-5-1
```

**For every order a role runs, via workspace config** — `.mso/config/role-models.json`, which beats an overlay:

```json
{
  "models": {
    "PLN": {"model": "claude-fable-5-1", "effort": "medium"}
  }
}
```

Fable accepts the same effort values as Opus, including `xhigh`, so the effort guidance below applies to it too.

## Context window & reasoning effort (FTR-MSO-2026-0281)

Maestro supports two additional per-role/per-order dispatch parameters.

### Context window

| Value | Meaning |
|-------|------|
| `standard` (default) | Normal context — no extra cost |
| `1m` | 1M context window — higher input token volume |

The `1m` selector appends as a suffix to `--model` (e.g. `claude-opus-5[1m]`), never as a separate flag. Use `1m` ONLY when many files must be held resident simultaneously.

### Reasoning effort

| Value | When to use |
|-------|------|
| `low` | Trivial/mechanical tasks |
| `medium` | Simple single-file tasks — and the default for the Opus roles (PLN/REL/LEAD) |
| `high` | Normal stories — the default for BLD/TST/DOC/SEC |
| `xhigh` | Opus/Fable only; complex long-horizon/high-risk work |
| `max` | **Interactive LEAD only** — rejected for crew dispatch |
| `ultracode` | **Interactive LEAD only** — rejected for crew dispatch |

### Object-form workspace config

```json
{
  "models": {
    "PLN": {"model": "claude-opus-5", "contextWindow": "1m", "effort": "xhigh"},
    "BLD": {"model": "claude-sonnet-5", "effort": "high"},
    "TST": "claude-sonnet-5"
  }
}
```

Bare-string values remain fully supported.

### Env vars

```bash
export MAESTRO_CONTEXT_PLN=1m
export MAESTRO_EFFORT_PLN=xhigh
```

### Cost guardrails

- Built-in defaults: contextWindow=standard for all roles; effort=`medium` for PLN/REL/LEAD and `high` for BLD/TST/DOC/SEC.
- Crew dispatch rejects effort=max and effort=ultracode (reserved for interactive LEAD).
- `1m` raises input token VOLUME; `xhigh` raises output+thinking tokens.

## Cost trade-offs

List prices per million tokens, input / output, from `PRICING` in `maestro/core/fleet_usage_tracker.py`:

| Tier | Models | Input | Output |
|------|--------|-------|--------|
| Fable | Fable 5.1, Fable 5 | $10.00 | $50.00 |
| Opus | Opus 5 (and the previous-generation Opus 4.x IDs) | $5.00 | $25.00 |
| Sonnet | Sonnet 5 (and the previous-generation Sonnet 4.6) | $3.00 | $15.00 |
| Haiku | Haiku 4.5 | $0.80 | $4.00 |

Opus costs about 1.7× Sonnet per token, Fable 2× Opus, and Haiku a little over a quarter of Sonnet. The defaults already exploit this asymmetry — Opus is reserved for the high-leverage, low-volume roles (PLN/REL/LEAD) where a mistake is costliest and the role runs infrequently, while the high-volume production roles (BLD/TST/DOC) stay on Sonnet. Most workspaces never need to override; for a one-off hard build, set a per-order `model` rather than moving BLD to Opus globally.

If your operators are seeing budget pressure, the cheapest first move is to drop the Opus roles back to Sonnet for non-critical projects — e.g. `.mso/config/role-models.json` with `{"models": {"PLN": "claude-sonnet-5", "REL": "claude-sonnet-5"}}`. That reclaims the Opus premium while keeping Sonnet's strong planning/coding quality. Run `mso usage --voyage <ID>` after a voyage to see whether the change paid off.
