"""4-step persona resolution: env var → workspace → user-global → built-in default."""

import json
import logging
import os
from pathlib import Path
from typing import Optional

import jinja2.exceptions

from .loader import PersonaSchemaError, load_builtin, load_persona_from_file
from .models import Persona

logger = logging.getLogger(__name__)

_DEFAULT_ID = "default"
_cached: Optional[Persona] = None


def _find_workspace_config() -> Optional[Path]:
    """Walk upward from cwd looking for a ``.maestro/config/persona.json``.

    The user-global home (``~/.maestro`` or ``$MAESTRO_HOME``) is deliberately
    NEVER matched here — it belongs to Step 3, not the workspace step. Without
    this guard the walk-up treats the global home as a "workspace" whenever cwd
    sits below it (e.g. any temp dir under the user home), silently reading the
    operator's real global persona and defeating MAESTRO_HOME isolation
    (BUG-MSO-2026-0387).
    """
    from maestro.workspace import get_maestro_home, MAESTRO_HOME_DIR_NAME
    # The global home in both its resolved (MAESTRO_HOME) and default
    # (~/.maestro) locations. Matching either while walking UP the tree is the
    # leak: it adopts the operator's real global state as a "workspace".
    global_homes = {get_maestro_home(), Path.home() / MAESTRO_HOME_DIR_NAME}
    cwd = Path.cwd()
    for parent in [cwd, *cwd.parents]:
        home_dir = parent / ".maestro"
        # Never adopt the global home found by walking UP as a workspace
        # (BUG-MSO-2026-0387). An explicit .maestro AT cwd is still honoured —
        # that is a deliberate workspace, not an incidental walk into ~/.maestro.
        is_global_via_walkup = home_dir in global_homes and parent != cwd
        if not is_global_via_walkup:
            candidate = home_dir / "config" / "persona.json"
            if candidate.exists():
                return candidate
        # Stop at filesystem root
        if parent == parent.parent:
            break
    return None


def _load_safe(path: Path, label: str) -> Optional[Persona]:
    """Try to load a persona from *path*; return None and log a warning on failure.

    Supports the pointer form ``{"id": "<built-in>"}`` so the setup wizard can
    record a persona selection without snapshotting every vocabulary/role field
    of the built-in into the workspace.
    """
    try:
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise PersonaSchemaError(f"Cannot read persona file ({path}): {exc}") from exc

        if isinstance(data, dict) and list(data.keys()) == ["id"]:
            persona = load_builtin(data["id"])
        else:
            persona = load_persona_from_file(path)

        # Probe the userAddressing template (most commonly rendered) to detect
        # sandboxed-template violations before the persona enters active use.
        persona.address_user()
        return persona
    except (PersonaSchemaError, OSError, jinja2.exceptions.SecurityError) as exc:
        logger.warning("Persona load failed (%s): %s — falling back to default", label, exc)
        return None


def resolve() -> Persona:
    """Resolve and return the active persona following the 4-step order.

    Result is cached for the process lifetime. Call reset() to clear the cache.
    """
    global _cached
    if _cached is not None:
        return _cached

    _cached = _resolve_uncached()
    return _cached


def _resolve_uncached() -> Persona:
    return resolve_with_workspace_file(_find_workspace_config())


def resolve_with_workspace_file(ws_path: Optional[Path]) -> Persona:
    """The same 4-step resolution as :func:`resolve`, uncached, with the Step 2
    workspace file named explicitly instead of found by walking up from cwd.

    FTR-MSO-2026-0801: the Hub serves many workspaces from one process whose
    cwd belongs to none of them, so it cannot use the cwd walk-up or the
    process-wide cache. Precedence is unchanged — :func:`resolve` itself runs
    through here. A *ws_path* that does not exist is skipped, as the walk-up
    skips a workspace with no persona file.
    """
    # Step 1 — MAESTRO_PERSONA env var
    env_id = os.environ.get("MAESTRO_PERSONA", "").strip()
    if env_id:
        try:
            return load_builtin(env_id)
        except PersonaSchemaError:
            logger.warning(
                "MAESTRO_PERSONA='%s' is unknown or invalid — falling back to default", env_id
            )
        # Env var set but unresolvable → fall through to default (never crash)

    # Step 2 — workspace .maestro/config/persona.json
    if ws_path is not None and Path(ws_path).exists():
        persona = _load_safe(ws_path, "workspace")
        if persona is not None:
            return persona

    # Step 3 — user-global ~/.maestro/config/persona.json (env-aware home)
    from maestro.workspace import get_maestro_home
    user_path = get_maestro_home() / "config" / "persona.json"
    if user_path.exists():
        persona = _load_safe(user_path, "user-global")
        if persona is not None:
            return persona

    # Step 4 — built-in default
    return load_builtin(_DEFAULT_ID)


def reset() -> None:
    """Clear the cached persona (useful in tests)."""
    global _cached
    _cached = None
