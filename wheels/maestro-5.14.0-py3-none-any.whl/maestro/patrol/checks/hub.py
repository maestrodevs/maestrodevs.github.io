"""maestro/patrol/checks/hub.py — Hub daemon liveness.

BUG-MSO-2026-0712. The resident LEAD's patrol had a ``dispatcher.heartbeat``
check and nothing at all for the Hub, so on 2026-09-09 it watched the
dashboard die and said nothing — the Captain found it by opening the page
two hours later. That was the second daemon death that day discovered by a
human rather than by Maestro.

``scope="machine"``, not ``"workspace"``: the Hub is a GLOBAL daemon serving
every registered workspace from one process and one PID file
(``~/.maestro/hub.pid``). Reporting it once per workspace would produce N
copies of one finding, which is why ``maestro.patrol.run_patrol``'s
machine-scope lease exists — this check joins ``machine.orphan-processes``
and ``machine.package-integrity`` under it and therefore fires at most once
per ``mso doctor`` invocation regardless of how many fleets are scanned.

Two firing conditions, and deliberately no third:

1. **A PID file whose PID is dead.** The record surviving IS the signal — a
   clean ``mso hub stop`` removes it, so a dead PID next to a live record
   means the daemon crashed rather than being stopped.
2. **A live PID whose port does not answer within 5 s.** A wedged Hub holds
   its listening socket and its PID, so PID liveness alone would call it
   healthy — the same alive-but-not-working shape ``dispatcher.heartbeat``
   exists to name for the dispatcher.

**No PID file at all is silent, on purpose.** A machine where nobody has
ever run ``mso hub start`` is not a fault, and a check that fired there
would put a permanent HIGH on every workspace that does not use the Hub —
alarm fatigue that buries the two real conditions above. This mirrors
``test_dispatcher_check_dead_pid_no_finding``'s rule that a never-started
daemon is unremarkable; "I watched it running and it is now gone" is a
different, louder claim, and one only the LEAD daemon's own cross-tick
state can make.
"""

from __future__ import annotations

from maestro.patrol.registry import CheckContext, Finding, check

# The AC's number, named rather than inlined so the check, the probe helper
# and any future test all read from one place.
_PORT_TIMEOUT_SECONDS = 5.0
_LOG_TAIL_LINES = 5


def _evidence_lines(evidence: dict) -> str:
    """The hub.log tail as an indented block, or an explicit statement that
    there is none. Never an empty string — "no log" and "a log I did not
    read" must not look the same to whoever reads this finding."""
    tail = evidence.get("logTail") or []
    if not tail:
        return "  (hub.log is absent or empty — no output was captured)"
    return "\n".join("  | " + line for line in tail)


@check(id="hub.alive", severity="high", scope="machine")
def hub_alive(context: CheckContext) -> "list[Finding]":
    # Imported lazily: maestro.hub pulls in the Hub's own module tree, and a
    # patrol run must never fail (or pay the import) on a machine that has no
    # Hub extra installed.
    try:
        from maestro.hub import daemon as hub_daemon
    except Exception:  # noqa: BLE001 — no Hub package means nothing to check
        return []

    pid_file = hub_daemon._hub_pid_file()
    if not pid_file.exists():
        return []  # never started here — see this module's docstring

    running, pid = hub_daemon._is_hub_running(pid_file)
    evidence = hub_daemon.death_evidence(tail_lines=_LOG_TAIL_LINES)

    if not running:
        exit_code = evidence.get("exitCode")
        exit_line = (
            f"exit code {exit_code}"
            + (f" ({evidence['exitError']})" if evidence.get("exitError") else "")
            if exit_code is not None
            else "no exit code was recorded — the daemon was killed without a "
                 "chance to write one (hard kill, console-session teardown, or OOM)"
        )
        died_qualifier = (
            "" if evidence.get("diedAtSource") == "exit-record"
            else " (PID-file mtime — an upper bound, not the moment of death)"
        )
        return [
            Finding(
                check_id="hub.alive",
                subject_id="machine:hub",
                severity="high",
                title=f"Maestro Hub is not running — recorded PID {pid} is dead",
                detail=(
                    f"{pid_file} still records PID {pid}, but no such process is alive. "
                    "A clean `mso hub stop` removes that record, so its survival means the "
                    "Hub CRASHED rather than being stopped.\n"
                    f"Started: {evidence.get('startedAt') or '(not recorded)'}\n"
                    f"Died:    {evidence.get('diedAt') or '(unknown)'}{died_qualifier}\n"
                    f"Exit:    {exit_line}\n"
                    f"Log:     {evidence.get('logPath')}\n"
                    f"{_evidence_lines(evidence)}"
                ),
                firstSeenAt=context.now.isoformat(),
                suggestedCommand="mso hub start",
                scope="machine",
                requires=(),
            )
        ]

    # BUG-MSO-2026-0751: the same classifier `mso hub status` uses, so the two
    # can never disagree about a live PID with no listener (NOT_SERVING).
    state = hub_daemon.serving_state(timeout=_PORT_TIMEOUT_SECONDS)
    port = state["port"]
    if state["state"] != "NOT_SERVING":
        return []

    not_serving = hub_daemon.not_serving_evidence(pid=pid)
    cause_line = (
        "Cause: the asyncio accept loop died (\"Accept failed on a socket\") and closed the "
        "listening socket while the process kept running (BUG-MSO-2026-0751).\n"
        if not_serving.get("acceptLoopDied") else ""
    )
    capture = not_serving.get("captureTail") or []
    capture_block = (
        "Supervisor captured:\n" + "\n".join("  | " + line for line in capture) + "\n"
        if capture else ""
    )

    return [
        Finding(
            check_id="hub.alive",
            subject_id="machine:hub",
            severity="high",
            title=f"Maestro Hub process is alive (PID {pid}) but port {port} is not answering",
            detail=(
                f"PID {pid} is live and its identity matches {pid_file}, but "
                f"http://127.0.0.1:{port}/api/v1/ping did not answer within "
                f"{_PORT_TIMEOUT_SECONDS:.0f}s. The dashboard is unreachable even though the "
                "process has not exited — the same alive-but-not-working shape "
                "`dispatcher.heartbeat` names for the dispatcher. `mso hub start` alone will "
                "report it as already running; stop it first.\n"
                f"{cause_line}"
                f"{capture_block}"
                f"Log: {evidence.get('logPath')}\n"
                f"{_evidence_lines(evidence)}"
            ),
            firstSeenAt=context.now.isoformat(),
            # Not a bare `mso hub start`: by this check's own firing condition
            # the process IS alive, and start_hub() short-circuits with
            # "Already running" — the same class of dead-end suggestion
            # BUG-MSO-2026-0691 F3 fixed for the dispatcher checks.
            suggestedCommand="mso hub stop && mso hub start",
            scope="machine",
            requires=(),
        )
    ]
