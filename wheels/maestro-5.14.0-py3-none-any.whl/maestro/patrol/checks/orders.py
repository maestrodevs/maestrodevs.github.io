"""maestro/patrol/checks/orders.py — order-level hygiene.

PLAN-PLN-MSO-2026-0504 §4 evidence: "an order is waiting on human approval"
is ENGINE work — the collectors already exist
(``fleet_monitor.get_pending_review_items`` for NAV_REVIEW_PENDING orders,
``fleet_monitor.get_approval_items`` for voyage/plan/requirement
AWAITING_APPROVAL artefacts); the gap was notification, not detection (§4.8 —
tracked separately as a dead-import bug, not this check's job). Reused here
rather than re-scanned, matching the same union `build_dashboard_state()`
already renders as one `approvals` list.

Age-based severity escalation and the `ageMinutes` threshold from the shipped
patrol default are noise-control concerns that land with patrol definitions
(plan orders 2/3, which also wire per-check params through `CheckContext`);
this check reports every currently-outstanding item on every run.

FTR-MSO-2026-0535 (plan order 5) adds `orders.dep-satisfied-unreleased` — a
DELIBERATELY THIN regression detector for BUG-MSO-2026-0499 (PROPOSED/HELD
orders whose full `dependsOn` set is archived complete never getting
released back to PENDING). The real fix is
`fleet_runner.promote_ready_dependents()`, called from every completion route
and every dispatcher tick; this check does not call it, does not release
anything, and does not replicate its STALLED-cause nuance in full — it only
re-derives "is every dependency satisfied" from the on-disk archive so a
reintroduction of 0499 is caught even with the dispatcher stopped. It fires
on exactly the DOC-MSO-2026-0484 shape verified live in the plan's evidence
(§4.3): a PROPOSED order with a non-empty `dependsOn`, every entry archived
COMPLETE, sitting untouched past `graceMinutes`.

FTR-MSO-2026-0720 (PLAN-FTR-MSO-2026-0700 §5.4) adds `orders.stuck`, which is
deliberately NOT a detector of its own: it renders
`maestro.core.blockage.scan_stuck_orders()` — the one function that answers "why
is this stuck, and what are my options?" — so `mso doctor`, the resident LEAD's
`LEAD_FINDING` line, `mso order why` and the Hub panel all state the same
verdict in the same words. Adding a fourth local re-derivation here is exactly
what that plan exists to stop.

BUG-MSO-2026-0741 adds `orders.undispatchable-proposed`, the complement of
that check rather than a variant of it: an order held at PROPOSED/HELD with
NO `dependsOn` at all and no ACTIVE chart node covering it. Nothing in the
engine can release such an order — `promote_ready_dependents()` skips it by
design, and the plan-review promotion it defers to only releases orders that
name the approved plan in their own `dependsOn` — so it is not a regression
detector but a report on an order that was filed (or edited) into a state the
dispatcher can never select from. `maestro.core.order_create` now refuses to
create one; this covers everything already on the plane.
"""

from __future__ import annotations

import json
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

from maestro.core.fleet_monitor import get_approval_items, get_pending_review_items
from maestro.patrol.registry import CheckContext, Finding, check
from maestro.roles.validation import validate_order_roles


@check(id="orders.awaiting-approval", severity="medium")
def orders_awaiting_approval(context: CheckContext) -> "list[Finding]":
    findings: "list[Finding]" = []

    for item in get_pending_review_items(context.artefact_root):
        order_id = item["order_id"]
        findings.append(
            Finding(
                check_id="orders.awaiting-approval",
                subject_id=order_id,
                severity="medium",
                title=f"{order_id} is waiting on human review",
                detail=(
                    f"Voyage {item['voyage_id']}, paused NAV_REVIEW_PENDING for {item['age']}. "
                    "Resolve with `mso review approve|revise|reject` or the Hub /review page."
                ),
                firstSeenAt=context.now.isoformat(),
                suggestedCommand=f"mso review show {order_id}",
                scope="workspace",
                requires=(),
            )
        )

    for item in get_approval_items(context.artefact_root):
        findings.append(
            Finding(
                check_id="orders.awaiting-approval",
                subject_id=item["id"],
                severity="medium",
                title=f"{item['type']} {item['id']} is awaiting approval",
                detail=(
                    f"{item.get('project', '?')}: {item.get('title') or item['id']} "
                    f"— {item.get('path', '')}"
                ),
                firstSeenAt=context.now.isoformat(),
                suggestedCommand=None,
                scope="workspace",
                requires=(),
            )
        )

    return findings


# ---------------------------------------------------------------------------
# orders.dep-satisfied-unreleased (FTR-MSO-2026-0535 / BUG-MSO-2026-0499)
# ---------------------------------------------------------------------------

# Same live-queue directory set as fleet_runner._ORDER_QUEUE_SUBDIRS /
# _iter_queue_order_files() / promote_ready_dependents() — a thin, independent
# re-listing (this module deliberately has no import dependency on
# fleet_runner) rather than a call into it. Keep in sync if that tuple changes.
_QUEUE_SUBDIRS = (
    "orders", "explicit", "high-level", "bugs", "defects", "security", "breakdown",
)
_RELEASE_GATED_STATUSES = {"PROPOSED", "HELD"}
_DEP_HARD_SATISFYING_STATUSES = {"COMPLETE", "MAX_ITERATIONS"}


def _load_json_safe(path: Path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def _parse_iso(value: object) -> Optional[datetime]:
    """Parse an ISO-8601 plane timestamp, PRESERVING its timezone shape.

    The shape is load-bearing and the plane carries both. The dispatcher
    writes naive HOST-LOCAL ``datetime.now().isoformat()`` for the fields
    these checks lean on hardest — a 2026-09-10 census of 400 archived MSO
    orders found ``stalledAt`` 27/27 naive, ``startedAt`` 289/289 naive and
    ``completedAt`` 304/367 naive — while some fields carry an offset.

    This function used to finish with ``dt.replace(tzinfo=timezone.utc)``,
    which reads a local ``10:47`` on a UTC+10 host as ``10:47`` UTC: ten
    hours in the FUTURE of ``context.now`` (aware UTC). Every age then came
    out negative, every ``(now - since) < grace`` held, and both grace-gated
    checks in this module went silent — ``orders.stuck`` reporting nothing
    for ten hours after each transition with ``mso doctor`` exiting 0
    (FTR-MSO-2026-0720 DEF-001), and ``orders.dep-satisfied-unreleased``'s
    BUG-MSO-2026-0499 regression detector suppressed the same way (DEF-002).
    ``graceMinutes: 0`` was no escape, because a negative age is below zero
    too.

    ``maestro.core.blockage._parse_iso`` / ``age_phrase`` already measured the
    same values correctly by comparing like with like; that is the shape
    followed here. Do not subtract a parsed value from ``context.now`` by
    hand — use :func:`_age_since`, which owns the shape reconciliation and
    the never-negative invariant.
    """
    if not isinstance(value, str) or not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


def _age_since(when: Optional[datetime], now: datetime) -> Optional[timedelta]:
    """How long ago ``when`` was, measured in ITS OWN timezone shape.

    ``None`` means UNMEASURABLE: no timestamp, an unparseable one, or a
    reading that places the event in the future. Callers must treat ``None``
    as "report it, don't wait" — an unknown age is not evidence of freshness,
    and **a negative age must never satisfy a grace window** (the invariant
    DEF-001 violated: a negative age sits below every threshold, so no
    ``graceMinutes`` value could defeat the suppression).

    A naive value is reconciled against host-local time rather than UTC,
    because naive on this plane means the dispatcher's own
    ``datetime.now()``. Mixed pairs are converted, never assumed away — the
    same reasoning as ``blockage.age_phrase``, which drops its clause rather
    than mis-measure one.
    """
    if when is None:
        return None
    reference = now
    if (when.tzinfo is None) != (reference.tzinfo is None):
        if when.tzinfo is None:
            reference = reference.astimezone().replace(tzinfo=None)
        else:
            # A naive reference is host-local by the same convention;
            # `astimezone` reads it that way and converts.
            reference = reference.astimezone(when.tzinfo)
    try:
        delta = reference - when
    except Exception:
        return None
    return None if delta.total_seconds() < 0 else delta


def _iter_queue_files(artefact_root: Path):
    queues_dir = artefact_root / "queues"
    for sub in _QUEUE_SUBDIRS:
        d = queues_dir / sub
        if not d.exists():
            continue
        for f in d.glob("*.json"):
            yield f
    requests_dir = queues_dir / "requests"
    if requests_dir.exists():
        for sub in requests_dir.iterdir():
            if sub.is_dir():
                yield from sub.glob("*.json")


def _dep_status_and_completed_at(artefact_root: Path, dep_id: str) -> "tuple[bool, Optional[datetime]]":
    """``(satisfied, completedAt)`` for one dependency, read from
    ``orders/complete/<dep_id>.json`` only — a dependency that hasn't
    archived at all is trivially unsatisfied. Mirrors
    ``fleet_runner.check_dependencies_satisfied``'s COMPLETE/STALLED rule in
    miniature (no ``fleet_runner`` import — see module docstring); this is
    the "thin" half of "thin regression detector", so a dependency's
    non-ERROR STALLED archive still counts, matching the engine's own
    "partial work exists" allowance.
    """
    data = _load_json_safe(artefact_root / "orders" / "complete" / f"{dep_id}.json")
    if not data:
        return False, None
    status = str(data.get("status") or "").upper()
    if status in _DEP_HARD_SATISFYING_STATUSES:
        satisfied = True
    elif status == "STALLED":
        satisfied = data.get("stalledCause", "MAX_ITERATIONS") != "ERROR"
    else:
        satisfied = False
    return satisfied, _parse_iso(data.get("completedAt"))


@check(id="orders.dep-satisfied-unreleased", severity="high")
def orders_dep_satisfied_unreleased(context: CheckContext) -> "list[Finding]":
    findings: "list[Finding]" = []
    grace = timedelta(minutes=context.params_for("orders.dep-satisfied-unreleased").get("graceMinutes", 15))

    for order_file in _iter_queue_files(context.artefact_root):
        data = _load_json_safe(order_file)
        if not data:
            continue
        status = str(data.get("status") or "").upper()
        if status not in _RELEASE_GATED_STATUSES:
            continue
        deps = data.get("dependsOn") or data.get("dependencies") or []
        if not deps:
            continue  # not dependency-gated — the human plan-review flow owns this, not 0499

        completed_ats: "list[datetime]" = []
        all_satisfied = True
        for dep_id in deps:
            satisfied, completed_at = _dep_status_and_completed_at(context.artefact_root, dep_id)
            if not satisfied:
                all_satisfied = False
                break
            if completed_at is not None:
                completed_ats.append(completed_at)
        if not all_satisfied:
            continue

        # Give promote_ready_dependents() its normal reaction window before
        # treating a still-fresh completion as a stall — avoids a
        # false-positive fired the instant the last dependency archives. The
        # freshest completion is the smallest measurable age; an unmeasurable
        # one is skipped rather than counted as fresh (DEF-002 — see
        # `_age_since`), so a future-looking `completedAt` can no longer
        # suppress the finding indefinitely.
        dep_ages = [
            age for age in (_age_since(c, context.now) for c in completed_ats)
            if age is not None
        ]
        if dep_ages and min(dep_ages) < grace:
            continue

        order_id = data.get("orderId") or data.get("id") or order_file.stem
        findings.append(
            Finding(
                check_id="orders.dep-satisfied-unreleased",
                subject_id=order_id,
                severity="high",
                title=f"{order_id}: dependencies satisfied but still {status}",
                detail=(
                    f"All of {order_id}'s dependsOn ({', '.join(deps)}) are archived "
                    f"complete, but the order itself is still {status} — nothing has "
                    "released it to PENDING (BUG-MSO-2026-0499). This is a regression "
                    "detector only; the fix is `promote_ready_dependents()` running on "
                    "every completion route and dispatcher tick, not this check."
                ),
                firstSeenAt=context.now.isoformat(),
                suggestedCommand=None,
                scope="workspace",
                requires=(),
            )
        )

    return findings


# ---------------------------------------------------------------------------
# orders.invalid-role (BUG-MSO-2026-0714)
# ---------------------------------------------------------------------------

#: Statuses worth reporting. An order the dispatcher has already refused is
#: INVALID; one nobody has scanned yet is still PENDING/OPEN/PROPOSED/HELD and
#: is exactly what this check exists to catch BEFORE a dispatcher touches it —
#: `mso doctor` works with the dispatcher stopped, which is the whole point.
_ROLE_CHECKED_STATUSES = {
    "PENDING", "OPEN", "PROPOSED", "HELD", "INVALID", "IN_PROGRESS", "QUEUED",
}


@check(id="orders.invalid-role", severity="high")
def orders_invalid_role(context: CheckContext) -> "list[Finding]":
    """Report queued orders whose ``roleSequence``/``targetRole`` names
    something that is not a role.

    BUG-MSO-2026-0713 was filed with ``roleSequence: ["INV", "BLD", "TST"]`` —
    ``INV`` is an order TYPE. Nothing rejected it: the dispatcher selected the
    order, launched ``crew.py --role INV``, argparse exited 2, and the failure
    surfaced as "returned no PID" and then as advice to check the installed
    package's integrity. The package was fine.

    ``fleet_runner.scan_all_queues()`` is now the enforcing gate (it marks such
    an order INVALID and never dispatches it). This check is the OFF-PROCESS
    half: it finds the same orders with no dispatcher running, which is when a
    human is most likely to be looking, and it keeps reporting an order already
    marked INVALID until someone actually fixes the file.
    """
    findings: "list[Finding]" = []

    for order_file in _iter_queue_files(context.artefact_root):
        data = _load_json_safe(order_file)
        if not data:
            continue
        status = str(data.get("status") or "PENDING").upper()
        if status not in _ROLE_CHECKED_STATUSES:
            continue
        result = validate_order_roles(data)
        if result.ok:
            continue

        order_id = data.get("orderId") or data.get("id") or order_file.stem
        already_held = status == "INVALID"
        findings.append(
            Finding(
                check_id="orders.invalid-role",
                subject_id=order_id,
                severity="high",
                title=f"{order_id} names a role that does not exist",
                detail=(
                    f"{result.message} "
                    + ("The dispatcher has already refused it (status INVALID); "
                       "it stays refused until the file is corrected. "
                       if already_held else
                       "It has not been scanned yet — a dispatcher would refuse "
                       "it (ORDER_INVALID) rather than dispatch it. ")
                    + f"File: {order_file}"
                ),
                firstSeenAt=context.now.isoformat(),
                suggestedCommand=f"mso order retry {order_id} --role <VALID-ROLE>",
                scope="workspace",
                requires=(),
            )
        )

    return findings


# ---------------------------------------------------------------------------
# orders.stuck (FTR-MSO-2026-0720 / PLAN-FTR-MSO-2026-0700 §5.4)
# ---------------------------------------------------------------------------

#: Only blockage kinds at or above this severity reach `mso doctor`.
#:
#: `run_patrol` REWRITES every finding's severity to the check's resolved one
#: (`patrol/__init__.py`: `replace(f, severity=target_severity)`), so one check
#: id cannot carry three tiers: a `medium` REVIEW_PENDING record emitted here
#: arrives in the output as `high`, and `_doctor_exit_code` fails at `high` —
#: which would make `mso doctor` exit non-zero for a workspace whose only
#: remark is "someone parked an order" or "a plan is awaiting approval". That
#: is the exact outcome PLAN-FTR-MSO-2026-0700 §3.2's severity note exists to
#: prevent ("mirrors `orders.awaiting-approval`'s shipped severity so
#: `mso doctor`'s exit code is unchanged").
#:
#: So the narrowing is applied to the DOCTOR OUTPUT, never to the model —
#: §5.4's own rule, stated there for `REVIEW_PENDING` and followed here for
#: every non-fault kind. Each one the filter drops is already surfaced
#: elsewhere: `REVIEW_PENDING` by `orders.awaiting-approval` (at `medium`),
#: `DEP_HELD` by `voyages.deadlocked` / `voyages.stalled-order-deadlock` and
#: the `DEP_HELD` lifecycle event, `SKIPPED` by `mso order list`, and
#: `TIMEOUT_REQUEUED` by the fleet itself — the model titles it
#: "is recovering" because nothing needs doing. `mso order why <id>` and the
#: Hub panel still render all twelve kinds, because they ask "why is this
#: order not moving", not "what is broken".
#:
#: PLAN-PLN-MSO-2026-0747 Order 7: `KIND_REL_NOT_READY` and
#: `KIND_PROVIDER_UNAVAILABLE` are explicitly listed here (imported by name
#: below, not merely reachable because `blockage.py`'s `_KIND_SEVERITY` map
#: happens to resolve them to `"high"`) — a voyage cannot finalise while its
#: REL order is open (D1, §2), so both are genuine faults and belong at the
#: same `mso doctor` visibility as `VERIFY_FAILED`/`STALLED`/etc, never among
#: the non-fault kinds this constant narrows out.
#:
#: If patrol ever stops flattening per-finding severity, widening this back to
#: the whole model is a one-constant change — and the test that pins it should
#: change with it, not around it.
_STUCK_MIN_SEVERITY = "high"


@check(id="orders.stuck", severity="high")
def orders_stuck(context: CheckContext) -> "list[Finding]":
    """Report every live order the blockage model calls stuck.

    The verdict is NOT re-derived here. PLAN-FTR-MSO-2026-0700's whole point
    is that "why is this stuck" is answered once, in
    `maestro.core.blockage`, and rendered identically on every surface — so
    this check is a thin adapter: one `scan_stuck_orders()` sweep (one plane
    read for N orders), one `Finding` per `Blockage`, carrying that record's
    own `title()`, `detail` and `suggested_command()` verbatim.

    That verbatim pass-through is the string-equality contract (§2.1): the
    LEAD daemon already writes `LEAD_FINDING` as `f"{f.title} — {f.detail}"`
    (`maestro/lead/agent.py`) from the very `Finding` this check returns, and
    `mso doctor` renders the same object. There is no second string to keep in
    sync, which is why neither surface needed a change to satisfy the AC.

    `suggestedCommand` is `Blockage.suggested_command()` rather than a bare
    `options[0].command`: the two agree whenever the best option carries a
    verb, and where they differ the model is deliberately right —
    evidence-opening options (open the verify log, open the plan) carry NO
    command precisely so they can never surface as a `suggestedCommand`, a
    field `mso doctor` prints as a remedy ("suggested: ..."). See
    `blockage._finalise_options`' docstring.

    Read-only, like every check: `BlockageContext.load` reads the ledger,
    the archive, the queues, the dep-hold and skip files and the lifecycle
    tail, and writes nothing (`test_checks_have_no_writer_end_to_end`).
    """
    from maestro.core.blockage import (
        KIND_PROVIDER_UNAVAILABLE,
        KIND_REL_NOT_READY,
        scan_stuck_orders,
    )
    from maestro.patrol.registry import severity_rank

    # PLAN-PLN-MSO-2026-0747 Order 7's acceptance criterion, verbatim: both
    # kinds must appear in this filter "by explicit listing" — named here
    # rather than left as an emergent property of `severity_rank` alone, so a
    # future change to either constant's severity in `blockage.py` cannot
    # silently drop it out of `mso doctor` unnoticed (see `_STUCK_MIN_SEVERITY`'s
    # docstring above).
    _EXPLICIT_HIGH_KINDS = (KIND_REL_NOT_READY, KIND_PROVIDER_UNAVAILABLE)

    params = context.params_for("orders.stuck")
    grace = timedelta(minutes=params.get("graceMinutes", 15))
    floor = severity_rank(_STUCK_MIN_SEVERITY)

    findings: "list[Finding]" = []
    for blockage in scan_stuck_orders(artefact_root=context.artefact_root):
        if blockage.kind not in _EXPLICIT_HIGH_KINDS \
                and severity_rank(blockage.severity) < floor:
            continue

        # The fleet's own reaction window, same shape as
        # `orders.dep-satisfied-unreleased`'s: a transition still seconds old
        # is not yet a fault — the requeue, the dep-gate promotion or the
        # convergence retry may be mid-flight. An UNREADABLE, absent or
        # future-dated `since` is reported immediately (`_age_since` returns
        # None for all three): an unknown age is not evidence of freshness,
        # and a blockage the model could not timestamp is the last one worth
        # hiding. A naive local `since` — the dominant shape on the plane —
        # is measured against local time, not misread as UTC; see
        # `_age_since` for what that used to cost (DEF-001).
        age = _age_since(_parse_iso(blockage.since), context.now)
        if age is not None and age < grace:
            continue

        findings.append(
            Finding(
                check_id="orders.stuck",
                # A bare order id — `patrol._STABLE_SUBJECT_ID_RE` matches it,
                # so `run_single_check` filters per subject and the
                # acknowledgement/delta machinery works with no extra wiring.
                subject_id=blockage.subject_id,
                severity=blockage.severity,
                title=blockage.title(),
                detail=blockage.detail,
                firstSeenAt=context.now.isoformat(),
                suggestedCommand=blockage.suggested_command() or None,
                scope="workspace",
                requires=(),
            )
        )

    return findings


# ---------------------------------------------------------------------------
# orders.undispatchable-proposed (BUG-MSO-2026-0741)
# ---------------------------------------------------------------------------


@check(id="orders.undispatchable-proposed", severity="high")
def orders_undispatchable_proposed(context: CheckContext) -> "list[Finding]":
    """Report queued orders held at PROPOSED/HELD with no ``dependsOn`` and no
    ACTIVE chart node — i.e. nothing that can ever release them.

    The sibling check above (``orders.dep-satisfied-unreleased``) deliberately
    skips these: it detects a dependency-gated order whose gate has *opened*
    and nothing acted on. This one covers the opposite shape — an order with no
    gate at all, which is not a regression in ``promote_ready_dependents()``
    but an order that was filed that way. ``maestro.core.order_create`` now
    refuses to CREATE one, so what reaches here is an order edited into the
    state, one filed by an older build, or one whose chart was paused or
    completed out from under it.

    Works with the dispatcher stopped, which is the whole point: nothing in the
    running fleet ever touches such an order, so no lifecycle event will ever
    mention it.
    """
    from maestro.core.undispatchable import chart_gated_order_ids, undispatchable_reason

    findings: "list[Finding]" = []
    chart_gated = chart_gated_order_ids(context.artefact_root)

    for order_file in _iter_queue_files(context.artefact_root):
        data = _load_json_safe(order_file)
        if not data:
            continue
        reason = undispatchable_reason(data, chart_gated_ids=chart_gated)
        if not reason:
            continue

        order_id = data.get("orderId") or data.get("id") or order_file.stem
        status = str(data.get("status") or "").upper()
        findings.append(
            Finding(
                check_id="orders.undispatchable-proposed",
                subject_id=order_id,
                severity="high",
                title=f"{order_id} is {status} with no dependency — nothing can release it",
                detail=f"{reason} File: {order_file}",
                firstSeenAt=context.now.isoformat(),
                # `mso order retry` is the sanctioned way past the ledger veto
                # and puts the order back to PENDING, which is exactly the
                # remedy when the operator meant it to run. An operator who
                # meant to PARK it wants BACKLOG instead — named in `reason`,
                # not here, because only one command fits a suggestedCommand.
                suggestedCommand=f"mso order retry {order_id}",
                scope="workspace",
                requires=(),
            )
        )

    return findings
