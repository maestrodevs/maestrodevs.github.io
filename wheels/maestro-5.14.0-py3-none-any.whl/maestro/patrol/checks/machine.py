"""maestro/patrol/checks/machine.py — machine-wide backstop checks.

PLAN-PLN-MSO-2026-0504 §7: these two checks are ``scope="machine"`` —
attributed to the MACHINE, not to any one project, and (via the lease
wired into ``maestro.patrol.run_patrol``) run and report ONCE per `mso
doctor` invocation regardless of how many workspaces are scanned
(FTR-MSO-2026-0535's own acceptance criteria). Both are explicitly a "cheap
backstop", never the fix:

- `machine.orphan-processes` — §4.4: reaping crew descendants is
  BUG-MSO-2026-0500's job (`maestro.core.descendant_reaper`, Windows Job
  Objects / POSIX process groups). That fix is scoped to processes a crew
  explicitly tracked; this check is a best-effort, MACHINE-WIDE scan for the
  exact process-name shape that was measured live on 2026-08-17 (`find`,
  `MSBuild`, `VBCSCompiler`, `dotnet`) whose parent process no longer exists.
  It never kills anything — a check never remediates (registry.py); it only
  counts and reports.

- `machine.package-integrity` — §4.7: `import maestro` resolving to a
  shadowing, debris-filled directory broke `mso version` outright on
  2026-08-17 (CLAUDE.md's "Shadowing" note). Two checks, cheapest-signal
  first: (a) the resolved package directory carries the markers a real
  install always has (`__init__.py`, `cli.py`, `core/`); (b) no `temp/`
  directory sits directly under the package root — a real wheel install
  never ships one.

  BUG-MSO-2026-0701 fixed the CAUSE of (b): `MAESTRO_TEMP` no longer
  defaults inside site-packages, it defaults to `<artefact root>/temp`. What
  remains is inert LEFTOVER debris from before that fix, with a one-command
  remedy — worth telling the operator once, not worth a CRITICAL on every
  LEAD tick forever, which is noise that hides real findings.

- `machine.package-debris` — (b) above, split out of
  `machine.package-integrity` into its OWN check id registered at HIGH.

  The split is not cosmetic. `maestro.patrol.run_patrol` applies the
  *check's* policy severity over every Finding it returns
  (`replace(f, severity=target_severity)`), and `registry.check`'s contract
  is explicit that "the check itself never decides its own severity
  dynamically" — so a per-Finding downgrade inside a check pinned at
  `critical` is discarded before `mso doctor` or the LEAD daemon ever sees
  it. Severity is per-CHECK policy, so a finding that needs a different
  severity needs a different check. It matches the semantics anyway: "the
  installed package is broken" and "there is leftover scratch here" are
  different subjects with different remedies, and splitting also stops the
  two from sharing `check_id`/`subject_id` fingerprint space in
  `patrol/state.py`. The markers half stays CRITICAL.

  BUG-MSO-2026-0816 widened it beyond `temp/`: every top-level entry of the
  package dir that no `maestro*.dist-info/RECORD` lists is reported too (one
  finding, with sizes and a delete command). With no RECORD to compare
  against — an editable/dev install — that half reports nothing.
"""

from __future__ import annotations

import json
import os

from maestro.core.package_integrity import check_package_integrity
from maestro.core.temp_paths import (  # BUG-MSO-2026-0701
    FIXED_IN_ORDER,
    describe_legacy_package_temp,
    describe_untracked_package_entries,  # BUG-MSO-2026-0816
)
from maestro.core.proc import run_hidden
from maestro.patrol.registry import CheckContext, Finding, check

# ---------------------------------------------------------------------------
# machine.orphan-processes
# ---------------------------------------------------------------------------

# The exact process shapes measured orphaned on 2026-08-17 (PLAN §4.4: 8
# `find` processes, 14-15 dotnet/MSBuild workers, one VBCSCompiler). Matched
# case-insensitively against the bare process name (no path, no args).
_WATCHED_NAMES = {"find", "find.exe", "msbuild", "msbuild.exe", "vbcscompiler",
                  "vbcscompiler.exe", "dotnet", "dotnet.exe"}


def _list_processes() -> "list[dict]":
    """Best-effort machine-wide process snapshot:
    ``[{"pid": int, "ppid": int, "name": str}, ...]``.

    Returns ``[]`` on ANY failure — this check is a cheap backstop (§4.4),
    never load-bearing, and must never crash `mso doctor` in an environment
    where process enumeration isn't available (a locked-down CI runner, a
    container without `ps`, etc.). Kept as a standalone module-level function
    (rather than inlined) specifically so tests can monkeypatch it directly
    instead of mocking a subprocess call.
    """
    try:
        if os.name == "nt":
            ps_script = (
                "Get-CimInstance Win32_Process | "
                "Select-Object ProcessId,ParentProcessId,Name | ConvertTo-Json -Compress"
            )
            r = run_hidden(
                ["powershell", "-NoProfile", "-Command", ps_script],
                capture_output=True, text=True, timeout=20,
            )
            if r.returncode != 0 or not (r.stdout or "").strip():
                return []
            raw = json.loads(r.stdout)
            if isinstance(raw, dict):
                raw = [raw]
            out = []
            for p in raw:
                pid, ppid, name = p.get("ProcessId"), p.get("ParentProcessId"), p.get("Name")
                if pid is None or name is None:
                    continue
                out.append({"pid": int(pid), "ppid": int(ppid) if ppid is not None else None, "name": str(name)})
            return out
        else:
            r = run_hidden(["ps", "-eo", "pid,ppid,comm"], capture_output=True, text=True, timeout=20)
            if r.returncode != 0:
                return []
            out = []
            for line in (r.stdout or "").splitlines()[1:]:
                parts = line.split(None, 2)
                if len(parts) < 3:
                    continue
                try:
                    out.append({"pid": int(parts[0]), "ppid": int(parts[1]), "name": parts[2]})
                except ValueError:
                    continue
            return out
    except Exception:
        return []


@check(id="machine.orphan-processes", severity="high", scope="machine")
def machine_orphan_processes(context: CheckContext) -> "list[Finding]":
    processes = _list_processes()
    if not processes:
        return []

    all_pids = {p["pid"] for p in processes if p.get("pid") is not None}
    orphans = [
        p for p in processes
        if str(p.get("name") or "").lower() in _WATCHED_NAMES
        and p.get("ppid") not in all_pids
    ]
    if not orphans:
        return []

    names = sorted({p["name"] for p in orphans})
    return [
        Finding(
            check_id="machine.orphan-processes",
            subject_id="machine:orphans",
            severity="high",
            title=f"{len(orphans)} orphaned Maestro-adjacent process(es) found machine-wide",
            detail=(
                f"{len(orphans)} process(es) ({', '.join(names)}) with a parent PID that no "
                "longer exists were found across the whole machine. The reaping fix is "
                "BUG-MSO-2026-0500 (descendant-group reap via Job Objects/process groups); "
                "this is a cheap, best-effort backstop for whatever slips past it, not the "
                "fix itself — it never terminates anything."
            ),
            firstSeenAt=context.now.isoformat(),
            suggestedCommand=None,
            scope="machine",
            requires=(),
        )
    ]


# ---------------------------------------------------------------------------
# machine.package-integrity
# ---------------------------------------------------------------------------


@check(id="machine.package-integrity", severity="critical", scope="machine")
def machine_package_integrity(context: CheckContext) -> "list[Finding]":
    # BUG-MSO-2026-0614: the importable/markers-intact half of this check is
    # shared with the dispatcher's startup gate (fleet_runner.run_dispatcher)
    # via maestro.core.package_integrity — one implementation, two consumers
    # (report here, hard-refuse-to-start there).
    result = check_package_integrity()

    if not result.ok and result.pkg_dir is None:
        return [
            Finding(
                check_id="machine.package-integrity",
                subject_id="machine:import-maestro",
                severity="critical",
                title="`import maestro` did not resolve to an on-disk package",
                detail=result.reason,
                firstSeenAt=context.now.isoformat(),
                suggestedCommand=None,
                scope="machine",
                requires=(),
            )
        ]

    if not result.ok:
        pkg_dir = result.pkg_dir
        missing = result.missing_markers
        return [
            Finding(
                check_id="machine.package-integrity",
                subject_id=f"machine:{pkg_dir}",
                severity="critical",
                title=f"`import maestro` resolved to {pkg_dir}, which is missing {', '.join(missing)}",
                detail=result.reason + " See CLAUDE.md's 'Shadowing' note.",
                firstSeenAt=context.now.isoformat(),
                suggestedCommand=None,
                scope="machine",
                requires=(),
            )
        ]

    # The leftover-`temp/` half lives in `machine.package-debris` below — it
    # needs a different severity, and severity is per-check policy.
    return []


# ---------------------------------------------------------------------------
# machine.package-debris
# ---------------------------------------------------------------------------

# A `temp/` directory under the installed package root is the exact
# 136MB-of-crew-debris shape from CLAUDE.md's "Shadowing" note — a shipped
# wheel never includes one. Pre-BUG-MSO-2026-0701 it was actively grown,
# because MAESTRO_TEMP defaulted there; post-fix it can only be leftover.
# Measuring + describing it is shared with the dispatcher's own startup
# notice (maestro.core.temp_paths) so both say the same thing and hand over
# the same delete command.


@check(id="machine.package-debris", severity="high", scope="machine")
def machine_package_debris(context: CheckContext) -> "list[Finding]":
    # Reuses check_package_integrity() purely to learn WHERE the installed
    # package is; a broken install is `machine.package-integrity`'s subject,
    # not this one, so an unresolvable package dir just means there is
    # nothing here to measure (describe_legacy_package_temp falls back to
    # resolving `import maestro` itself and returns None if it cannot).
    pkg_dir = check_package_integrity().pkg_dir
    findings: "list[Finding]" = []

    report = describe_legacy_package_temp(pkg_dir)
    if report is not None:
        findings.append(
            Finding(
                check_id="machine.package-debris",
                subject_id=f"machine:{report.path}",
                # HIGH, not CRITICAL: nothing writes here any more, so this is
                # inert leftover debris with a one-command remedy.
                severity="high",
                title=f"Leftover pre-{FIXED_IN_ORDER} temp dir in the installed package: {report.path}",
                detail=report.one_line(),
                firstSeenAt=context.now.isoformat(),
                suggestedCommand=report.delete_command,
                scope="machine",
                requires=(),
            )
        )

    # BUG-MSO-2026-0816: `temp/` is not the only debris shape — root-level
    # logs and scratch dirs sat in the installed package for a week unseen
    # (PLAN-BUG-MSO-2026-0807 F3). Anything at the top level that no installer
    # RECORD lists was not put there by an install. No RECORD (editable/dev
    # checkout) means no basis for the comparison, so nothing is reported.
    untracked = describe_untracked_package_entries(pkg_dir)
    if untracked is not None:
        findings.append(
            Finding(
                check_id="machine.package-debris",
                subject_id=f"machine:{untracked.pkg_dir}:untracked",
                severity="high",
                title=(
                    f"{len(untracked.entries)} untracked entr"
                    f"{'y' if len(untracked.entries) == 1 else 'ies'} in the installed "
                    f"package not listed in its RECORD: {untracked.pkg_dir}"
                ),
                detail=untracked.one_line(),
                firstSeenAt=context.now.isoformat(),
                suggestedCommand=untracked.delete_command,
                scope="machine",
                requires=(),
            )
        )
    return findings
