"""Licence record storage at ~/.maestro/licence.json.

Two schemas share this one file, discriminated by the on-disk
``schema_version`` field (FTR-MSO-2026-0452, PLAN-PLN-MSO-2026-0450 §4.4):

- **schema_version 1** (legacy, Polar-backed) — HMAC-SHA256 signature over
  the canonical JSON of all signed fields, keyed by a per-customer secret
  stored in the OS keychain (so a stolen licence.json on its own is useless
  without the secret on the source machine). Kept **bit-for-bit unchanged**
  per the plan's explicit "resist tidying it" directive — this code path is
  retired wholesale in a later order (FTR-MSO-2026-0456), not edited here.
- **schema_version 2** (``MSO1.`` token-backed) — the verbatim signed token
  is the integrity anchor; there is nothing left for an HMAC or a keychain
  secret to protect (editing the cached convenience fields is self-defeating
  — they're ignored, and altering the token itself breaks its Ed25519
  signature, checked by ``maestro.licence.token.verify`` whenever it
  matters). No keychain, no per-customer secret, no cross-machine-copy
  defence needed — a v2 record is *meant* to be portable between the
  licensee's own machines (§5.4 D5 — no machine binding).

``load_record()`` returns whichever dataclass matches the file's schema.
Callers branch on ``.schema_version``.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import os
import random
import threading
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Optional

from maestro.licence.errors import LicenceMissing, LicenceTampered
from maestro.workspace import get_maestro_home


SCHEMA_VERSION = 1
SCHEMA_VERSION_V2 = 2
KEYCHAIN_SERVICE = "maestro-licence"

# Fields included in the signed payload (order matters for canonical JSON).
SIGNED_FIELDS = (
    "schema_version",
    "licence_key",
    "tier",
    "product_id",
    "customer_id",
    "issued_at",
    "expires_at",
    "last_validated_at",
    "offline_grace_until",
)


@dataclass
class LicenceRecord:
    licence_key: str
    tier: str
    product_id: str
    customer_id: str
    issued_at: str
    expires_at: str
    last_validated_at: str
    offline_grace_until: str
    schema_version: int = SCHEMA_VERSION
    # Transient, in-memory only. Never roundtrip to disk; not part of
    # the signed payload. Set by validate() so the CLI can render a
    # warning banner when grace fallback is active.
    signing_secret: Optional[str] = field(default=None, repr=False)
    used_grace: bool = field(default=False, repr=False)
    grace_remaining_days: int = field(default=0, repr=False)
    # Note: signing_secret is set when we receive a fresh secret from
    # Polar at activate-time. It's *consumed once* — written to keychain
    # then cleared from memory. Not part of the on-disk record.

    def to_signed_payload(self) -> dict:
        return {k: getattr(self, k) for k in SIGNED_FIELDS}


# Fields cached verbatim from the token payload on disk (FTR-MSO-2026-0452,
# §4.4). None of these are trusted on their own — ``maestro.licence.token
# .verify()`` is re-run against ``token`` itself whenever the record's
# validity actually matters (licence.validate() / licence.status()). They
# exist so a cold read (e.g. ``mso licence status --json`` right after
# activation) doesn't need a fresh verify just to print what was last
# confirmed.
TOKEN_CACHE_FIELDS = (
    "schema_version",
    "token",
    "tier",
    "licence_id",
    "licensee_name",
    "issued_at",
    "expires_at",
    "key_id",
    "is_trial",
    "activated_at",
    "last_verified_at",
)


@dataclass
class TokenLicenceRecord:
    """schema_version 2 — a verbatim ``MSO1.`` token plus a read cache.

    No HMAC, no keychain entry: the token's own Ed25519 signature is the
    integrity anchor (§4.4). ``tier`` is the RAW tier carried by the token;
    ``effective_tier`` is what's actually in force after any tier-dependent
    expiry decision (§D3b — trial/pro downgrade to community, team/enterprise
    stop). The two differ only while downgraded. Everything below
    ``last_verified_at`` is transient — set by ``licence.validate()`` on each
    call, never round-tripped as part of the *authoritative* record (the
    cache write only persists the ``TOKEN_CACHE_FIELDS`` subset).
    """

    token: str
    tier: str
    licence_id: str
    licensee_name: str
    issued_at: str
    expires_at: str
    key_id: str
    is_trial: bool
    activated_at: str
    last_verified_at: str
    schema_version: int = SCHEMA_VERSION_V2
    # Transient — recomputed by licence.validate() every call, per §D3b.
    effective_tier: str = field(default="", repr=False)
    stopped: bool = field(default=False, repr=False)
    downgraded: bool = field(default=False, repr=False)
    downgraded_from: Optional[str] = field(default=None, repr=False)
    warning: Optional[str] = field(default=None, repr=False)
    used_grace: bool = field(default=False, repr=False)
    grace_remaining_days: int = field(default=0, repr=False)

    def to_cache_payload(self) -> dict:
        return {k: getattr(self, k) for k in TOKEN_CACHE_FIELDS}


# ---------------------------------------------------------------------------
# Keychain helpers
# ---------------------------------------------------------------------------

def _keychain_set(customer_id: str, secret: str) -> None:
    """Store the per-customer signing secret in the OS keychain."""
    try:
        import keyring  # type: ignore
        keyring.set_password(KEYCHAIN_SERVICE, customer_id, secret)
    except Exception:
        # Fallback: write to ~/.maestro/secrets/<customer_id>.key with mode 0600.
        # Less secure than keychain but functional on systems without keyring.
        secrets_dir = _mso_dir() / "secrets"
        secrets_dir.mkdir(parents=True, exist_ok=True)
        f = secrets_dir / f"{customer_id}.key"
        f.write_text(secret, encoding="utf-8")
        _set_perms(f, 0o600)


def _keychain_get(customer_id: str) -> Optional[str]:
    try:
        import keyring  # type: ignore
        return keyring.get_password(KEYCHAIN_SERVICE, customer_id)
    except Exception:
        f = _mso_dir() / "secrets" / f"{customer_id}.key"
        if f.exists():
            return f.read_text(encoding="utf-8")
        return None


def _keychain_delete(customer_id: str) -> None:
    try:
        import keyring  # type: ignore
        keyring.delete_password(KEYCHAIN_SERVICE, customer_id)
    except Exception:
        f = _mso_dir() / "secrets" / f"{customer_id}.key"
        if f.exists():
            f.unlink()


# ---------------------------------------------------------------------------
# File helpers
# ---------------------------------------------------------------------------

def _mso_dir() -> Path:
    """The global Maestro home (``~/.maestro`` or ``$MAESTRO_HOME``) — created
    on demand. Independent of the project workspace. Routed through the central
    resolver so MAESTRO_HOME redirects licence storage (BUG-MSO-2026-0387)."""
    return get_maestro_home(create=True)


_adm_dir = _mso_dir  # legacy alias kept for test monkeypatching


def _record_path() -> Path:
    return _mso_dir() / "licence.json"


def _set_perms(path: Path, mode: int) -> None:
    """Best-effort chmod. Windows file ACLs aren't equivalent — we accept
    that and rely on per-user home directory permissions there.
    """
    try:
        os.chmod(path, mode)
    except OSError:
        pass


# BUG-MSO-2026-0784: licence.json is read concurrently by many processes on
# one host (the Hub on every request, dispatchers, LEAD daemons, crews, every
# `mso` call) and rewritten on every re-verification. A plain write_text
# truncates then writes, so a reader landing in that window parsed empty or
# partial JSON, raised LicenceTampered and resolved to community tier — the
# Hub then 403'd dispatch on a valid Enterprise licence. Writes now go to a
# sibling temp file and are swapped in with os.replace (atomic on one volume,
# POSIX and Windows); reads retry briefly before calling a bad parse tampered.

# os.replace on Windows fails with PermissionError while another process holds
# the target open (Python opens files without FILE_SHARE_DELETE). Each reader
# holds it briefly, but many processes reading in a loop can keep it open
# almost continuously, so a deliberate save retries for a while with jittered
# sleeps (fixed backoff can stay in step with the readers and starve).
_REPLACE_RETRY_SECONDS = 10.0
# The re-verification cache refresh (licence.validate) runs inside every
# has_tier() call, including Hub requests. It is best-effort: it gives up
# quickly and the caller keeps the verified record (QA DEF-001).
CACHE_REFRESH_RETRY_SECONDS = 0.25
# Total wait a reader spends on a transiently unreadable file before it is
# classified LicenceTampered (the order's <=250ms budget).
_READ_RETRY_DELAYS = (0.01, 0.02, 0.04, 0.08, 0.1)


def _atomic_write_text(
    path: Path, text: str, mode: int = 0o600, *, replace_retry_seconds: Optional[float] = None
) -> None:
    """Replace ``path`` with ``text`` so no reader ever sees a partial file.

    The temp file is created with ``mode`` up front (never briefly wider),
    flushed and fsynced, then ``os.replace``d onto ``path``. The temp file is
    removed if anything fails before the swap. ``replace_retry_seconds``
    defaults to ``_REPLACE_RETRY_SECONDS``.
    """
    if replace_retry_seconds is None:
        replace_retry_seconds = _REPLACE_RETRY_SECONDS
    tmp = path.with_name(
        f".{path.name}.{os.getpid()}.{threading.get_ident()}.{uuid.uuid4().hex}.tmp"
    )
    data = text.encode("utf-8")
    try:
        fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_BINARY", 0), mode)
        with os.fdopen(fd, "wb") as fh:
            fh.write(data)
            fh.flush()
            os.fsync(fh.fileno())
        _set_perms(tmp, mode)

        deadline = time.monotonic() + replace_retry_seconds
        delay = 0.005
        while True:
            try:
                os.replace(str(tmp), str(path))
                break
            except PermissionError:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise
                time.sleep(min(random.uniform(0.001, delay), remaining))
                delay = min(delay * 2, 0.05)
    except BaseException:
        try:
            tmp.unlink()
        except OSError:
            pass
        raise
    _set_perms(path, mode)


# ---------------------------------------------------------------------------
# Signing
# ---------------------------------------------------------------------------

def _canonical_json(payload: dict) -> bytes:
    """Stable serialisation: sorted keys, no whitespace, UTF-8."""
    return json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")


def _sign(payload: dict, secret: str) -> str:
    return hmac.new(
        secret.encode("utf-8"), _canonical_json(payload), hashlib.sha256
    ).hexdigest()


def _verify(payload: dict, secret: str, expected: str) -> bool:
    return hmac.compare_digest(_sign(payload, secret), expected)


# ---------------------------------------------------------------------------
# Public read/write API
# ---------------------------------------------------------------------------

def save_record(record: LicenceRecord) -> None:
    """Persist `record` to ~/.maestro/licence.json.

    Side-effect: stores `record.signing_secret` in the OS keychain on
    first save, then clears it from the in-memory dataclass.
    """
    if record.signing_secret:
        _keychain_set(record.customer_id, record.signing_secret)
        record.signing_secret = None

    secret = _keychain_get(record.customer_id)
    if not secret:
        # Should never happen — we just wrote it. Defensive only.
        raise RuntimeError("Keychain write succeeded but read failed.")

    payload = record.to_signed_payload()
    # Field name follows the pinned PLAN-VOY-0031 schema (`validated_signature`).
    on_disk = {**payload, "validated_signature": _sign(payload, secret)}
    _atomic_write_text(_record_path(), json.dumps(on_disk, indent=2), 0o600)


# Required signed fields (a subset of SIGNED_FIELDS that must be non-empty).
# `schema_version` has a default and is allowed to be implicit.
_REQUIRED_FIELDS = (
    "licence_key", "tier", "product_id", "customer_id",
    "issued_at", "expires_at", "last_validated_at", "offline_grace_until",
)

_REQUIRED_TOKEN_FIELDS = ("token",)


def _load_record_v1(on_disk: dict) -> LicenceRecord:
    """Load + verify a schema_version-1 (legacy Polar/HMAC) record.

    Raises LicenceTampered if signature doesn't match, the keychain
    entry is missing (cross-machine theft), or the on-disk file is
    truncated/missing required fields. Bit-for-bit the pre-FTR-MSO-2026-0452
    behaviour — see the module docstring for why this path is frozen.
    """
    # Honour the canonical schema field name first; fall back to the
    # legacy `signature` key for any record written by a pre-rename build.
    sig = on_disk.pop("validated_signature", "") or on_disk.pop("signature", "")
    if not sig:
        raise LicenceTampered()

    customer_id = on_disk.get("customer_id", "")
    secret = _keychain_get(customer_id)
    if not secret:
        # Keychain entry missing — this is the cross-machine-copy attack.
        raise LicenceTampered()

    # Verify only the canonical signed payload — unknown future fields
    # are ignored so forward-compat works as intended.
    known = {k: v for k, v in on_disk.items() if k in SIGNED_FIELDS}
    if not _verify(known, secret, sig):
        raise LicenceTampered()

    # Truncated / edited file: required fields missing → tampered, not a
    # bare TypeError on the dataclass constructor.
    missing = [f for f in _REQUIRED_FIELDS if not known.get(f)]
    if missing:
        raise LicenceTampered()

    return LicenceRecord(**known)


def _load_record_v2(on_disk: dict) -> TokenLicenceRecord:
    """Deserialise a schema_version-2 (token-backed) record.

    Pure I/O — deliberately does NOT call ``token.verify()``. The token's
    Ed25519 signature is re-checked by ``licence.validate()`` /
    ``licence.status()`` whenever the record's *validity* actually matters
    (§4.4 "verification is re-run from the token on every load" — "load" in
    the operational sense of every ``mso`` invocation, not every raw
    deserialisation). A missing/empty ``token`` field is the one thing this
    layer treats as corruption, since without it there is nothing to verify.
    """
    missing = [f for f in _REQUIRED_TOKEN_FIELDS if not on_disk.get(f)]
    if missing:
        raise LicenceTampered()
    known = {k: on_disk.get(k, "") for k in TOKEN_CACHE_FIELDS if k != "schema_version"}
    known["is_trial"] = bool(on_disk.get("is_trial", False))
    return TokenLicenceRecord(**known)


def _read_record_json(p: Path) -> dict:
    """Parse licence.json, tolerating a write that is in flight right now.

    Empty/partial JSON, undecodable bytes, or a sharing violation (Windows,
    mid-``os.replace``) are retried over ``_READ_RETRY_DELAYS`` (~250ms total)
    — a pre-BUG-MSO-2026-0784 writer, or another tool, can still truncate the
    file in place. A file that is STILL unreadable after the window is
    genuinely corrupt and raises LicenceTampered, exactly as before.
    """
    last_exc: Optional[BaseException] = None
    for delay in (*_READ_RETRY_DELAYS, None):
        try:
            on_disk = json.loads(p.read_text(encoding="utf-8"))
            if isinstance(on_disk, dict):
                return on_disk
            # Valid JSON but not an object — not an in-flight state; tampered.
            raise LicenceTampered()
        except (json.JSONDecodeError, UnicodeDecodeError, PermissionError) as exc:
            last_exc = exc
        except FileNotFoundError as exc:
            # Deleted between the exists() check and the read (deactivate).
            raise LicenceMissing() from exc
        except OSError as exc:
            raise LicenceTampered() from exc
        if delay is not None:
            time.sleep(delay)
    raise LicenceTampered() from last_exc


def load_record() -> "LicenceRecord | TokenLicenceRecord":
    """Load the stored record, whichever schema it is.

    Raises LicenceMissing if no file present.
    Raises LicenceTampered if the file is unreadable/corrupt, or (v1 only)
    the HMAC signature doesn't match / the keychain entry is missing.
    """
    p = _record_path()
    if not p.exists():
        raise LicenceMissing()

    on_disk = _read_record_json(p)

    if on_disk.get("schema_version") == SCHEMA_VERSION_V2:
        return _load_record_v2(on_disk)
    return _load_record_v1(on_disk)


def save_token_record(
    token: str,
    payload: dict,
    *,
    activated_at: str,
    last_verified_at: str,
    replace_retry_seconds: Optional[float] = None,
) -> TokenLicenceRecord:
    """Persist a schema_version-2 record: the verbatim token + a read cache.

    No keychain, no HMAC — see the module docstring. ``payload`` is the
    already-verified token payload (``maestro.licence.token.verify()`` /
    ``.decode()``); this function trusts its caller, it does not re-verify.
    ``replace_retry_seconds`` is forwarded to ``_atomic_write_text``.
    """
    record = TokenLicenceRecord(
        token=token,
        tier=payload.get("tier", ""),
        licence_id=payload.get("licenceId", ""),
        licensee_name=(payload.get("licensee") or {}).get("name", ""),
        issued_at=payload.get("issuedAt", ""),
        expires_at=payload.get("expiresAt", ""),
        key_id=payload.get("keyId", ""),
        is_trial=bool(payload.get("isTrial", False)),
        activated_at=activated_at,
        last_verified_at=last_verified_at,
    )
    p = _record_path()
    cache = record.to_cache_payload()
    if _only_verified_at_is_fresher(p, cache):
        return record
    _atomic_write_text(
        p, json.dumps(cache, indent=2), 0o600, replace_retry_seconds=replace_retry_seconds
    )
    return record


# A re-verification that changes nothing but last_verified_at by less than
# this is not persisted — the Hub re-verifies on every request, so without it
# licence.json is rewritten many times a second (BUG-MSO-2026-0784).
_VERIFIED_AT_REWRITE_INTERVAL_SECONDS = 60


def _only_verified_at_is_fresher(p: Path, cache: dict) -> bool:
    """True when the on-disk v2 record already matches ``cache`` except for a
    ``last_verified_at`` less than the rewrite interval older. Any read or
    parse problem answers False, so the caller writes."""
    from datetime import datetime

    try:
        on_disk = json.loads(p.read_text(encoding="utf-8"))
        if not isinstance(on_disk, dict):
            return False
        if any(on_disk.get(k) != cache.get(k) for k in cache if k != "last_verified_at"):
            return False
        old = datetime.fromisoformat(on_disk["last_verified_at"])
        new = datetime.fromisoformat(cache["last_verified_at"])
        return 0 <= (new - old).total_seconds() < _VERIFIED_AT_REWRITE_INTERVAL_SECONDS
    except Exception:
        return False


def delete_record() -> None:
    """Remove the licence file and the keychain entry."""
    p = _record_path()
    customer_id = ""
    if p.exists():
        try:
            on_disk = json.loads(p.read_text(encoding="utf-8"))
            customer_id = on_disk.get("customer_id", "")
        except Exception:
            pass
        p.unlink()
    if customer_id:
        _keychain_delete(customer_id)
