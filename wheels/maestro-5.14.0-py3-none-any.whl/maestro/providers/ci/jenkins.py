"""maestro/providers/ci/jenkins.py — the ``jenkins`` CI provider.

PLAN-PLN-MSO-2026-0747 Order 12 (FTR-MSO-2026-0770). A thin wrapper over the
Jenkins REST API for **multibranch pipeline** jobs — the same shape every
provider in this seam follows (``scm/github.py`` / ``ci/github_actions.py``):
thin, never-raise, ``available()`` reports WHY it cannot run rather than
crashing or fabricating a pass (§10.3).

A multibranch pipeline job exposes one sub-job per discovered branch:

    <host>/job/<jobPath segments.../>job/<branchJobName>/lastBuild/api/json

and a PR build (branch-discovery + PR strategy enabled) typically appears as
its own ``PR-<n>`` branch job. Jenkins keeps no commit-sha index, so
``checks_for_pr`` tries ``headRef`` first (the plan's literal wording: "finds
a build by headRef") — the PR's own head branch name, then a synthesised
``PR-<id>`` job name — and only falls back to a bounded scan of each
candidate job's recent builds for one whose git-plugin-reported revision
matches ``headSha``. Neither match found is reported honestly (``[]`` plus a
reason via :meth:`JenkinsCiProvider.checks_for_pr_checked`) — never a
fabricated pass (Order 12 AC).

Jenkins has no per-check breakdown the way a GitHub Actions run does — one
build is one pass/fail unit — so ``checks_for_pr`` reports a single synthetic
check (name ``config.checkName``, default ``"jenkins"``) in the same
``{"name", "status", "conclusion"}`` shape every other CI provider returns
(``base.py``), so ``voyages.pr-ci-state`` and ``mso pr checks`` need no
Jenkins-specific branch.

Credentials (D9): ``config.user`` + ``config.apiToken`` — the latter is an
``env:``/``secret://`` reference, enforced by ``providers/config.py`` before
this class ever sees a literal value; this module only ever reads whatever
:func:`maestro.providers.resolve_explain` hands it (already resolved at the
use site, exactly like every other provider). Basic Auth is skipped when
either is absent, which a protected Jenkins answers with 401/403 — surfaced
through :meth:`available`, never silently treated as "read succeeded".

Egress (D9 / plan §13): ``config.host`` is checked against
``dataResidency.allowedDestinations`` exactly like ``scm/github.py`` — a
local/LAN Jenkins is allowlisted the same way any other host is, with no
special-casing (a permissive/non-enterprise workspace, the default, imposes
no restriction at all; `egress/diagram.py` already lists `localhost` as a
local service for the restrictive/air-gapped cases).
"""

from __future__ import annotations

import base64
import json
import re
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Optional
from urllib.parse import quote, urlparse

from maestro.providers.base import STATUS_ERROR, STATUS_OK, ActionResult, CiProvider

# A credential value still carrying its own unresolved reference (D9's
# env:/secret:// scheme) must never be sent on the wire literally — that
# sends the reference NAME, not a secret, but it is still a wrong value
# masquerading as a working credential (PR #427 review).
_UNRESOLVED_REF_RE = re.compile(r"^(?:env:|secret://)")
_ENV_REF_RE = re.compile(r"^env:([A-Za-z_][A-Za-z0-9_]*)$")
_CONTROL_RE = re.compile(r"[\x00-\x1f\x7f]")


class _RefuseRedirects(urllib.request.HTTPRedirectHandler):
    """Returning None makes urllib raise HTTPError(3xx) instead of following —
    so the Authorization header is never re-sent to a redirect target on a
    different host (PR #427 review; mirrors scm/bitbucket.py's ``_RefuseRedirects``).

    Installed as the process's DEFAULT opener (below), rather than built
    per-call and used via ``opener.open(...)`` — the existing test suite
    patches ``urllib.request.urlopen`` directly (module docstring), which a
    per-call custom opener's own ``.open()`` never goes through. Installing
    it as the default means every plain ``urllib.request.urlopen(...)`` call
    in this process — the one every test here already intercepts — is
    protected, with no change to the call site."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):  # noqa: D401, ANN001
        return None


urllib.request.install_opener(urllib.request.build_opener(_RefuseRedirects()))

_TIMEOUT = 30
_LOG_TIMEOUT = 60
_MAX_BUILDS_SCANNED = 20  # per branch job, when falling back to a headSha scan

# `builds[...]` tree fields for the headSha fallback scan — kept narrow so a
# job with a long build history stays a cheap call.
_BUILDS_TREE = "builds[number,url,building,result,actions[lastBuiltRevision[SHA1]]]"


def _job_url(host: str, job_path: str, branch_job: str) -> str:
    """``<host>/job/<seg1>/job/<seg2>/.../job/<branchJobName>/`` — every path
    segment individually quoted (a branch name can carry ``/``, e.g.
    ``feature/x``, which Jenkins itself encodes as ``feature%2Fx`` in the job
    URL)."""
    segments = [s for s in job_path.split("/") if s] if job_path else []
    segments.append(branch_job)
    parts = "/".join(f"job/{quote(seg, safe='')}" for seg in segments)
    return f"{host.rstrip('/')}/{parts}/"


class JenkinsCiProvider(CiProvider):
    id = "jenkins"

    def __init__(self, config: dict[str, Any] | None = None, workspace: Optional[Path] = None) -> None:
        super().__init__(config)
        self._cwd = Path(self.config.get("repoPath") or workspace or Path.cwd())

    def _host(self) -> str:
        return str(self.config.get("host") or "").rstrip("/")

    def _job_path(self) -> str:
        return str(self.config.get("jobPath") or "")

    def _check_name(self) -> str:
        return str(self.config.get("checkName") or "jenkins")

    def _credential_problem(self) -> str:
        """``""`` when ``user``/``apiToken`` are usable, else why not.

        Catches an UNRESOLVED ``env:``/``secret://`` reference reaching here
        literally (the reference name would otherwise go out as the password)
        and control characters in either field (header injection)."""
        user = self.config.get("user")
        token = self.config.get("apiToken")
        if not user or not token:
            return "no credential configured (config.user / config.apiToken)"
        for label, value in (("user", user), ("apiToken", token)):
            if isinstance(value, str) and _UNRESOLVED_REF_RE.match(value.strip()):
                m = _ENV_REF_RE.match(value.strip())
                name = m.group(1) if m else value.strip()
                return f"config.{label} is an unresolved reference ('{name}') — it was never substituted"
        if (isinstance(user, str) and _CONTROL_RE.search(user)) or (
                isinstance(token, str) and _CONTROL_RE.search(token)):
            return "config.user / config.apiToken contains control characters"
        return ""

    def _auth_header(self) -> dict[str, str]:
        if self._credential_problem():
            return {}
        user = self.config.get("user")
        token = self.config.get("apiToken")
        raw = f"{user}:{token}".encode("utf-8")
        return {"Authorization": "Basic " + base64.b64encode(raw).decode("ascii")}

    def _request(self, url: str, timeout: int = _TIMEOUT) -> tuple[Optional[bytes], str]:
        """One GET. ``(body_bytes, "")`` on success, ``(None, reason)``
        otherwise — never raises, matching every other provider's contract."""
        problem = self._credential_problem()
        if problem:
            return None, problem
        req = urllib.request.Request(url, headers=self._auth_header(), method="GET")
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return resp.read(), ""
        except urllib.error.HTTPError as exc:
            if exc.code in (401, 403):
                return None, f"HTTP {exc.code}"
            if exc.code == 404:
                return None, "404 not found"
            if 300 <= exc.code < 400:
                return None, f"HTTP {exc.code} (redirect refused — credential not re-sent cross-host)"
            return None, f"HTTP {exc.code}"
        except urllib.error.URLError as exc:
            return None, f"unreachable: {exc.reason}"
        except Exception as exc:  # noqa: BLE001 — the capability contract is never-raise
            return None, str(exc)

    def available(self) -> tuple[bool, str]:
        host = self._host()
        if not host:
            return False, "no host configured"

        try:
            from maestro.egress.filter import EgressFilter
            hostname = urlparse(host).hostname or host
            ef = EgressFilter.from_workspace(self._cwd)
            if not ef.is_allowed(hostname):
                # Mirrors scm/github.py's "host not permitted" marker — the
                # phrase resolve_explain() recognises to skip its generic
                # "<kind> provider '<id>' unavailable: ..." wrapping.
                return False, f"host not permitted: '{hostname}' is not in allowedDestinations"
        except ImportError:
            pass  # the egress package itself is absent (community/pro) — no restriction applies
        except Exception as exc:  # noqa: BLE001
            # An egress check that raised is a check that could not answer,
            # not one that answered "allowed" — fail CLOSED (PR #427 review;
            # a swallowed exception here was a silent bypass of the enterprise
            # egress allowlist, unlike scm/bitbucket.py's own check, which
            # already fails closed).
            return False, f"egress check failed ({exc}) — refusing rather than assuming the host is allowed"

        if not self.config.get("user") or not self.config.get("apiToken"):
            return False, "no credential configured (config.user / config.apiToken)"

        body, err = self._request(f"{host}/api/json", timeout=10)
        if body is None:
            if err in ("HTTP 401", "HTTP 403"):
                return False, f"jenkins authentication failed ({err})"
            return False, f"jenkins unreachable ({err})"
        return True, ""

    def _candidate_branch_jobs(self, pr: dict) -> list[str]:
        """Branch-job names to try, in order: the PR's own ``headRef``, then a
        synthesised ``PR-<id>`` — the job name a multibranch job with PR
        discovery enabled gives a pull request build."""
        candidates: list[str] = []
        head_ref = pr.get("headRef")
        if head_ref:
            candidates.append(str(head_ref))
        pr_id = pr.get("id")
        if pr_id:
            synthetic = f"PR-{pr_id}"
            if synthetic not in candidates:
                candidates.append(synthetic)
        return candidates

    def _lookup_build_by_branch(self, branch_job: str) -> tuple[Optional[dict], str]:
        url = _job_url(self._host(), self._job_path(), branch_job) + "lastBuild/api/json"
        body, err = self._request(url)
        if body is None:
            return None, err
        try:
            data = json.loads(body)
        except Exception:
            return None, "jenkins returned non-JSON output"
        return (data if isinstance(data, dict) else None), ""

    def _lookup_build_by_sha(self, branch_job: str, head_sha: str) -> tuple[Optional[dict], str]:
        """Scan the branch job's recent builds for one whose
        ``actions[].lastBuiltRevision.SHA1`` (the git plugin's own reported
        shape) matches *head_sha*. Bounded — Jenkins keeps no sha index, so
        this is a scan, not a targeted lookup."""
        url = f"{_job_url(self._host(), self._job_path(), branch_job)}api/json?tree={quote(_BUILDS_TREE, safe='[],')}"
        body, err = self._request(url)
        if body is None:
            return None, err
        try:
            data = json.loads(body)
        except Exception:
            return None, "jenkins returned non-JSON output"
        builds = (data or {}).get("builds") or [] if isinstance(data, dict) else []
        head_sha_lower = head_sha.lower()
        # Every element/field is untrusted server JSON — a non-dict build or
        # actions entry must be skipped, never raise (PR #427 review; the
        # capability contract is never-raise).
        for build in builds[:_MAX_BUILDS_SCANNED]:
            if not isinstance(build, dict):
                continue
            for action in build.get("actions") or []:
                if not isinstance(action, dict):
                    continue
                sha1 = (action.get("lastBuiltRevision") or {}).get("SHA1")
                if isinstance(sha1, str) and sha1 and (
                        sha1.lower() == head_sha_lower or sha1.lower().startswith(head_sha_lower[:7])):
                    return build, ""
        return None, ""

    @staticmethod
    def _is_transport_failure(err: str) -> bool:
        """True when *err* means the REQUEST could not be completed (auth
        rejected, host unreachable, unexpected status, unparseable body) —
        as opposed to a plain 404, which is jenkins' routine answer for a
        branch job it has never built yet, a legitimate empty result."""
        if not err or err.startswith("404 not found"):
            return False
        return True

    def _find_build(self, pr: dict) -> tuple[Optional[dict], str, bool]:
        """``(build, reason, transport_failed)``. ``transport_failed`` tells
        :meth:`checks_for_pr_checked` whether every lookup that ran actually
        FAILED to ask (auth/network/malformed response) rather than asking
        and getting a routine "no build here yet" — the two must never be
        reported the same way (PR #427 review): a Jenkins outage or a
        rejected credential must surface as "could not ask", never as "no
        failing checks", which would let a broken/red build sail through."""
        head_ref = pr.get("headRef")
        head_sha = pr.get("headSha")
        if not head_ref and not head_sha:
            return None, "the PR record carries neither headRef nor headSha — nothing to look up", False

        last_err = ""
        transport_failed = False
        for branch_job in self._candidate_branch_jobs(pr):
            build, err = self._lookup_build_by_branch(branch_job)
            if build is not None:
                return build, "", False
            if self._is_transport_failure(err):
                transport_failed = True
            last_err = err or last_err

        if head_sha:
            for branch_job in self._candidate_branch_jobs(pr):
                build, err = self._lookup_build_by_sha(branch_job, head_sha)
                if build is not None:
                    return build, "", False
                if self._is_transport_failure(err):
                    transport_failed = True
                last_err = err or last_err

        reason = (f"no jenkins build found for headRef '{head_ref}' or headSha '{head_sha}'"
                  + (f" ({last_err})" if last_err else ""))
        return None, reason, transport_failed

    def _build_to_check(self, build: dict) -> dict:
        name = self._check_name()
        if build.get("building"):
            return {"name": name, "status": "IN_PROGRESS", "conclusion": None}
        result = str(build.get("result") or "").upper()
        conclusion_map = {
            "SUCCESS": "SUCCESS",
            "UNSTABLE": "FAILURE",
            "FAILURE": "FAILURE",
            "ABORTED": "CANCELLED",
            "NOT_BUILT": "CANCELLED",
        }
        conclusion = conclusion_map.get(result)
        status = "COMPLETED" if conclusion else "PENDING"
        return {"name": name, "status": status, "conclusion": conclusion}

    def checks_for_pr(self, pr: dict) -> list[dict]:
        checks, _err = self.checks_for_pr_checked(pr)
        return checks or []

    def checks_for_pr_checked(self, pr: dict) -> tuple[Optional[list[dict]], str]:
        build, err, transport_failed = self._find_build(pr)
        if build is None:
            # A failed ASK is not a clean "no checks" — see _find_build's
            # docstring (PR #427 review, HIGH: this used to always return
            # ([], err), so an unreachable/misauthenticated Jenkins read as
            # "no failing checks" instead of "could not ask").
            return (None if transport_failed else []), err
        return [self._build_to_check(build)], ""

    def failed_log(self, pr: dict, check: str) -> ActionResult:
        build, err, _transport_failed = self._find_build(pr)
        if build is None:
            return ActionResult(STATUS_ERROR, err)

        build_url = str(build.get("url") or "").rstrip("/")
        if not build_url:
            return ActionResult(STATUS_ERROR, "jenkins build record carries no url")

        body, log_err = self._request(f"{build_url}/consoleText", timeout=_LOG_TIMEOUT)
        if body is None:
            return ActionResult(STATUS_ERROR, f"jenkins console log fetch failed: {log_err}")
        text = body.decode("utf-8", errors="replace")
        detail = "" if text.strip() else "jenkins build has no console output"
        return ActionResult(STATUS_OK, detail, text)
