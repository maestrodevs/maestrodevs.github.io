"""maestro/providers/ci/github_actions.py — the ``github_actions`` CI provider.

Thin wrapper over ``gh pr checks`` and ``gh run view`` (PLAN-PLN-MSO-2026-0504
§10.4 — no second implementation of the same call).

FTR-MSO-2026-0760 corrected the ``gh pr checks`` field list. It used to
request ``conclusion``, which ``gh pr checks --json`` does not accept (its
fields are ``bucket, completedAt, description, event, link, name, startedAt,
state, workflow``) — so every call exited non-zero and this provider reported
no checks for every PR, which ``voyages.pr-ci-state`` reads as "unknown". The
``status``/``conclusion`` shape callers read is now derived from ``state`` and
``bucket``.
"""

from __future__ import annotations

import json
import re
import shutil
from pathlib import Path
from typing import Any, Optional

from maestro.core.proc import run_hidden
from maestro.providers.base import STATUS_ERROR, STATUS_OK, STATUS_UNSUPPORTED, ActionResult, CiProvider

_TIMEOUT = 30
_LOG_TIMEOUT = 120
_DEFAULT_HOST = "github.com"
_MAX_ERR = 500

_CHECK_FIELDS = "name,state,bucket,link"

# `gh pr checks` links a GitHub Actions check to its run, and usually its job:
# https://github.com/<o>/<r>/actions/runs/<run>/job/<job>
_RUN_LINK = re.compile(r"/actions/runs/(\d+)(?:/job/(\d+))?")

# `state` values that mean a failure even when gh's `bucket` is absent.
_FAILING_STATES = {"FAILURE", "ERROR", "CANCELLED", "TIMED_OUT", "ACTION_REQUIRED", "STARTUP_FAILURE"}


def _map_check(raw: dict) -> dict:
    """``gh pr checks`` record -> ``{"name", "status", "conclusion", "link"}``.

    A pending check has ``conclusion`` None and keeps gh's ``state`` as its
    status; a finished one has status ``COMPLETED`` and its ``state`` as the
    conclusion (``ERROR`` is reported as ``FAILURE`` — the patrol's failing
    set has no ``error``)."""
    bucket = str(raw.get("bucket") or "").lower()
    state = str(raw.get("state") or "").upper()
    base = {"name": raw.get("name"), "link": raw.get("link") or None}
    if bucket == "pending" or (not bucket and state in {"PENDING", "QUEUED", "IN_PROGRESS", "WAITING", "REQUESTED"}):
        return {**base, "status": state or "PENDING", "conclusion": None}
    conclusion = "FAILURE" if state == "ERROR" else (state or None)
    if bucket == "fail" and state not in _FAILING_STATES:
        conclusion = "FAILURE"
    elif bucket == "cancel":
        conclusion = "CANCELLED"
    return {**base, "status": "COMPLETED", "conclusion": conclusion}


class GithubActionsCiProvider(CiProvider):
    id = "github_actions"

    def __init__(self, config: dict[str, Any] | None = None, workspace: Optional[Path] = None) -> None:
        super().__init__(config)
        self._cwd = Path(self.config.get("repoPath") or workspace or Path.cwd())
        self._slug: Optional[str] = self.config.get("slug") or None

    def _host(self) -> str:
        return str(self.config.get("host") or _DEFAULT_HOST)

    def _repo_args(self) -> list[str]:
        return ["--repo", self._slug] if self._slug else []

    def available(self) -> tuple[bool, str]:
        if shutil.which("gh") is None:
            return False, "gh CLI not installed"

        host = self._host()
        try:
            from maestro.egress.filter import EgressFilter
            ef = EgressFilter.from_workspace(self._cwd)
            if not ef.is_allowed(host):
                return False, f"host not permitted: '{host}' is not in allowedDestinations"
        except Exception:
            pass

        try:
            r = run_hidden(["gh", "auth", "status"], capture_output=True, text=True, timeout=10)
        except Exception as exc:
            return False, f"gh auth status failed ({exc})"
        if r.returncode != 0:
            return False, "gh not authenticated"
        return True, ""

    def _raw_checks(self, number: Any) -> Optional[list[dict]]:
        raw, _err = self._raw_checks_checked(number)
        return raw

    def _raw_checks_checked(self, number: Any) -> tuple[Optional[list[dict]], str]:
        args = ["gh", "pr", "checks", str(number), "--json", _CHECK_FIELDS] + self._repo_args()
        try:
            r = run_hidden(args, capture_output=True, text=True, timeout=_TIMEOUT, cwd=str(self._cwd))
        except Exception as exc:
            return None, f"`gh pr checks` failed to run ({exc})"
        # `gh pr checks` exits 8 while checks are still pending and 1 when any
        # failed — both with valid JSON on stdout — so the exit code alone is
        # not a failure signal; unparseable or empty output is. The one empty-
        # stdout answer that IS an answer is gh's "no checks reported".
        if not (r.stdout or "").strip():
            stderr = (r.stderr or "").strip()
            if "no checks reported" in stderr.lower():
                return [], ""
            return None, stderr[:300] or f"`gh pr checks` produced no output (exit {r.returncode})"
        try:
            raw = json.loads(r.stdout)
        except Exception:
            return None, "`gh pr checks` returned non-JSON output"
        if not isinstance(raw, list):
            return None, "`gh pr checks` returned an unexpected payload"
        return [c for c in raw if isinstance(c, dict)], ""

    def checks_for_pr(self, pr: dict) -> list[dict]:
        checks, _err = self.checks_for_pr_checked(pr)
        return checks or []

    def checks_for_pr_checked(self, pr: dict) -> tuple[Optional[list[dict]], str]:
        number = pr.get("number") or pr.get("id")
        if not number:
            return None, "the PR record carries no number"
        raw, err = self._raw_checks_checked(number)
        if raw is None:
            return None, err
        return [_map_check(c) for c in raw], ""

    def failed_log(self, pr: dict, check: str) -> ActionResult:
        number = pr.get("number") or pr.get("id")
        if not number:
            return ActionResult(STATUS_ERROR, "the PR record carries no number")
        if not check:
            return ActionResult(STATUS_ERROR, "no check name given")
        try:
            raw = self._raw_checks(number)
            if raw is None:
                return ActionResult(STATUS_ERROR, f"could not read checks for PR #{number}")
            matches = [c for c in raw if c.get("name") == check]
            if not matches:
                names = ", ".join(sorted({str(c.get("name")) for c in raw})) or "none"
                return ActionResult(STATUS_ERROR, f"no check named '{check}' on PR #{number} (checks: {names})")
            # A matrix can repeat a name; the failing instance is the one wanted.
            entry = next((c for c in matches if str(c.get("bucket") or "").lower() == "fail"), matches[0])
            link = str(entry.get("link") or "")
            m = _RUN_LINK.search(link)
            if not m:
                return ActionResult(
                    STATUS_UNSUPPORTED,
                    f"check '{check}' is not a GitHub Actions run (link: {link or 'none'}); "
                    "its log is not reachable through gh",
                )
            run_id, job_id = m.groups()
            args = ["gh", "run", "view"] + (["--job", job_id] if job_id else [run_id])
            args += ["--log-failed"] + self._repo_args()
            r = run_hidden(args, capture_output=True, text=True, encoding="utf-8", errors="replace",
                           timeout=_LOG_TIMEOUT, cwd=str(self._cwd))
            if r.returncode != 0:
                err = (r.stderr or r.stdout or "").strip()[:_MAX_ERR]
                return ActionResult(STATUS_ERROR, f"gh run view failed: {err or f'exit {r.returncode}'}")
            text = r.stdout or ""
            detail = "" if text.strip() else f"check '{check}' has no failed-step log (state: {entry.get('state')})"
            return ActionResult(STATUS_OK, detail, text)
        except Exception as exc:  # noqa: BLE001 — the capability contract is never-raise
            return ActionResult(STATUS_ERROR, f"failed-log lookup failed: {exc}")
