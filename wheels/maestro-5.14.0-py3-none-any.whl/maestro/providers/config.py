"""maestro/providers/config.py — the ONE writer of workspace.json's `providers` block.

PLAN-PLN-MSO-2026-0747 Order 8 (D8/D9). ``mso providers list|show|set|unset|test``
(cli.py), the new ``mso setup`` step (Order 9) and the Hub's Providers section
(Orders 10a/10b) all call the functions here — none of them touches
``workspace.json`` itself. This is the same shared-core shape
``order_retry.py``/``review_core.py`` already established: explicit
``workspace: Path``, typed exceptions, no printing, no ``sys.exit``.

**Credentials never live here as values (D9).** A provider config field whose
NAME looks like a credential (token/password/secret/key/credential/auth/PAT)
must hold a reference — ``env:NAME`` (all tiers) or ``secret://...``
(enterprise) — never a literal. ``set_provider`` refuses anything else before
it ever reaches disk; the actual resolution of either reference scheme still
happens once, at the use site, in ``maestro.secrets.refs.resolve_secret_refs``
(called by ``providers.resolve_explain``) — this module does not resolve
anything, it only guards what gets WRITTEN.

**Signed-bundle tier wins (D8).** A kind pinned by a signed policy bundle
(the same tier ``providers.resolve_explain`` already consults — see
``providers.__init__._bundle_providers``) is reported locked and every write
to that kind is refused, regardless of caller (CLI, setup, Hub).
"""

from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Any, Optional

from maestro.identity.gate import require_capability
from maestro.providers import PROVIDER_KINDS, resolve_explain

__all__ = [
    "ProviderConfigError",
    "UnknownProviderKindError",
    "UnknownProviderIdError",
    "InvalidCredentialError",
    "ProviderLockedError",
    "installed_ids",
    "is_credential_field",
    "list_providers",
    "show_provider",
    "set_provider",
    "unset_provider",
    "test_provider",
]


class ProviderConfigError(Exception):
    """Base for every refusal this module raises."""

    hint: Optional[str] = None

    def __init__(self, message: str, hint: Optional[str] = None) -> None:
        super().__init__(message)
        if hint is not None:
            self.hint = hint


class UnknownProviderKindError(ProviderConfigError):
    pass


class UnknownProviderIdError(ProviderConfigError):
    pass


class InvalidCredentialError(ProviderConfigError):
    hint = (
        "Set the value as an environment variable and reference it with 'env:NAME' "
        "(any tier), or 'secret://provider/namespace/key' on an enterprise workspace."
    )


class ProviderLockedError(ProviderConfigError):
    hint = "A signed policy bundle pins this provider; workspace.json cannot override it."


# A config field NAME that looks like a credential (case-insensitive). This is
# a name-based check, not a value-shape scan: it is what stops a literal
# token/password ever reaching disk in the first place, regardless of what
# the literal looks like. Mirrors the keyword set
# `maestro/hooks/secret_patterns.py`'s `_ENTROPY_KEYWORDS` already uses for
# the same judgment call elsewhere in the codebase.
_CREDENTIAL_FIELD_RE = re.compile(
    r"(?i)(token|secret|password|passwd|apikey|api[_-]?key|credential|\bpat\b|auth)"
)

# The two reference schemes D9 permits for a credential field's value.
_ENV_REF_RE = re.compile(r"^env:[A-Za-z_][A-Za-z0-9_]*$")
_SECRET_REF_RE = re.compile(r"^secret://[^/]+/[^/]+/[^/\s]+$")


def _check_kind(kind: str) -> None:
    if kind not in PROVIDER_KINDS:
        raise UnknownProviderKindError(
            f"unknown provider kind: {kind!r} (expected one of {PROVIDER_KINDS})"
        )


def installed_ids(kind: str) -> list[str]:
    """Provider ids installed for *kind*, from the one registry
    ``providers.resolve_explain`` itself reads — never a second list that
    could drift from what actually resolves."""
    _check_kind(kind)
    from maestro.providers import _REGISTRY  # single source of truth

    return sorted(_REGISTRY.get(kind, {}).keys())


def is_credential_field(field_name: str) -> bool:
    return bool(_CREDENTIAL_FIELD_RE.search(field_name))


def _validate_credential_value(field_name: str, value: Any) -> None:
    if not is_credential_field(field_name):
        return
    if isinstance(value, str) and (_ENV_REF_RE.match(value) or _SECRET_REF_RE.match(value)):
        return
    raise InvalidCredentialError(
        f"config field '{field_name}' looks like a credential and must be a reference "
        "('env:NAME' or 'secret://provider/namespace/key'), not a literal value"
    )


def _validate_credential_tree(prefix: str, value: Any) -> None:
    """Walk *value* recursively, applying :func:`_validate_credential_value`
    to every string leaf against ITS OWN key name.

    PR #427 review (HIGH): the flat, one-level ``cfg.items()`` loop in
    :func:`set_provider` never looked inside a nested dict, so
    ``{"jira": {"apiToken": "<literal>"}}`` - a nested per-flavour config
    shape - wrote a real credential to the git-tracked ``workspace.json``
    verbatim. ``maestro.secrets.refs._walk`` already recurses to RESOLVE
    nested refs; this makes the write-time guard symmetric with that read.
    """
    if isinstance(value, dict):
        for key, sub in value.items():
            if is_credential_field(str(key)):
                _validate_credential_value(str(key), sub)
            else:
                _validate_credential_tree(str(key), sub)
    elif isinstance(value, list):
        for item in value:
            _validate_credential_tree(prefix, item)
    elif is_credential_field(prefix):
        _validate_credential_value(prefix, value)


def _workspace_json_path(workspace: Path) -> Path:
    from maestro.workspace import resolve_artefact_dir

    return resolve_artefact_dir(Path(workspace)) / "config" / "workspace.json"


def _read_workspace_json(workspace: Path) -> dict:
    path = _workspace_json_path(workspace)
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except (json.JSONDecodeError, OSError):
        return {}


def _read_workspace_json_for_write(workspace: Path) -> dict:
    """Like :func:`_read_workspace_json`, but a present-and-unreadable file
    RAISES instead of degrading to ``{}``.

    PR #427 review (MEDIUM): ``set_provider``/``unset_provider`` used the
    lenient read, then wrote the merged result straight over the same path -
    a transiently unreadable/corrupt ``workspace.json`` was silently replaced
    by a file containing ONLY the ``providers`` key, destroying every other
    key (``governance``, ``dataResidency``, ...). A read-only caller
    (``list_providers`` / ``show_provider``) keeps the lenient degrade - it
    never writes, so there is nothing to clobber."""
    path = _workspace_json_path(workspace)
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as exc:
        raise ProviderConfigError(
            f"{path} exists but could not be read ({exc}) - refusing to write over it. "
            "Fix or remove the file, then retry."
        ) from exc
    return data if isinstance(data, dict) else {}


def _write_workspace_json(workspace: Path, data: dict) -> Path:
    """Read-combine-write, one key touched — mirrors
    ``maestro.lead.agent.set_stand_down`` / ``governance.authoring.write_governed_mode``.

    Atomic (write-temp + ``os.replace``, PR #427 review) so a concurrent
    reader (the Hub, ``mso doctor``, a live dispatcher re-resolving providers)
    never sees a torn file - the same pattern ``core/dep_holds.py`` and
    ``core/died_record.py`` already use for workspace-adjacent state.
    """
    path = _workspace_json_path(workspace)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    os.replace(str(tmp), str(path))
    return path


def _bundle_lock(kind: str, workspace: Path) -> Optional[str]:
    """The provider id a signed bundle pins for *kind*, or None.

    Reuses ``providers.__init__._bundle_providers`` — the SAME already
    signature/tamper-verified read ``resolve_explain`` itself uses — rather
    than re-implementing bundle verification a second time.
    """
    from maestro.providers import _bundle_providers

    bundle = _bundle_providers(Path(workspace))
    if isinstance(bundle, dict) and kind in bundle:
        entry = bundle[kind]
        if isinstance(entry, dict):
            locked_id = entry.get("id")
            return str(locked_id) if locked_id else None
    return None


def list_providers(workspace: Path) -> dict[str, Any]:
    """Every kind: installed ids, the configured entry (if any, verbatim —
    references are never resolved here), and any bundle lock."""
    ws_data = _read_workspace_json(workspace)
    ws_providers = ws_data.get("providers")
    ws_providers = ws_providers if isinstance(ws_providers, dict) else {}

    out: dict[str, Any] = {}
    for kind in PROVIDER_KINDS:
        entry = ws_providers.get(kind)
        out[kind] = {
            "installed": installed_ids(kind),
            "configured": entry if isinstance(entry, dict) else None,
            "lockedBy": _bundle_lock(kind, workspace),
        }
    return out


def show_provider(workspace: Path, kind: str) -> dict[str, Any]:
    """One kind's configured entry plus its resolved outcome (tier/available/
    reason) — "configured X, but skipped — host not permitted" is visible
    from one call (D8: "effective vs configured")."""
    _check_kind(kind)
    ws_data = _read_workspace_json(workspace)
    ws_providers = ws_data.get("providers")
    ws_providers = ws_providers if isinstance(ws_providers, dict) else {}
    entry = ws_providers.get(kind)

    resolved = resolve_explain(kind, workspace=workspace)
    return {
        "kind": kind,
        "installed": installed_ids(kind),
        "configured": entry if isinstance(entry, dict) else None,
        "lockedBy": _bundle_lock(kind, workspace),
        "resolved": {
            "providerId": resolved.provider_id,
            "tier": resolved.tier,
            "available": resolved.available,
            "reason": resolved.reason,
        },
    }


def set_provider(
    workspace: Path, kind: str, provider_id: str, config: Optional[dict[str, Any]] = None
) -> dict[str, Any]:
    """Write ``providers.<kind> = {"id": provider_id, "config": config}``,
    touching no other key in ``workspace.json`` (round-trip AC).

    Refuses (never writes): an unknown kind, an unknown provider_id (naming
    the installed ids), a bundle-locked kind, or any credential-shaped field
    whose value is not an ``env:``/``secret://`` reference.
    """
    _check_kind(kind)

    installed = installed_ids(kind)
    if provider_id not in installed:
        raise UnknownProviderIdError(
            f"unknown {kind} provider '{provider_id}' — installed ids: "
            f"{', '.join(installed) if installed else '(none)'}"
        )

    locked = _bundle_lock(kind, workspace)
    if locked is not None:
        raise ProviderLockedError(
            f"{kind} provider is locked to '{locked}' by a signed policy bundle "
            "and cannot be changed here"
        )

    require_capability("config.modify", workspace=Path(workspace))

    cfg = dict(config or {})
    for field_name, value in cfg.items():
        _validate_credential_tree(field_name, value)

    data = _read_workspace_json_for_write(workspace)
    providers_block = data.get("providers")
    providers_block = dict(providers_block) if isinstance(providers_block, dict) else {}
    providers_block[kind] = {"id": provider_id, "config": cfg}
    data["providers"] = providers_block
    _write_workspace_json(workspace, data)

    return {"kind": kind, "id": provider_id, "config": cfg}


def unset_provider(workspace: Path, kind: str) -> dict[str, Any]:
    """Remove ``providers.<kind>`` entirely, reverting that kind to its
    shipped default. A bundle lock refuses this too — a locked kind cannot be
    unset any more than it can be changed."""
    _check_kind(kind)

    locked = _bundle_lock(kind, workspace)
    if locked is not None:
        raise ProviderLockedError(
            f"{kind} provider is locked to '{locked}' by a signed policy bundle "
            "and cannot be changed here"
        )

    data = _read_workspace_json(workspace)
    providers_block = data.get("providers")
    providers_block = dict(providers_block) if isinstance(providers_block, dict) else {}
    removed = kind in providers_block
    if removed:
        del providers_block[kind]
        data["providers"] = providers_block
        _write_workspace_json(workspace, data)

    return {"kind": kind, "removed": removed}


def test_provider(workspace: Path, kind: str):
    """The resolved outcome for *kind* — the SAME call ``mso doctor
    --explain`` makes (AC6: identical tier/available/reason), so there is no
    second reporting path for "is this provider working"."""
    _check_kind(kind)
    return resolve_explain(kind, workspace=workspace)
