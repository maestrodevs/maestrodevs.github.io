"""maestro/providers/base.py — the Provider seam.

PLAN-PLN-MSO-2026-0504 §10.1: a narrow capability protocol per tool kind
(``scm``, ``ci``, ``issues``, ``deploy``), driven by what the patrol checks
actually need — not a speculative superset of every API a real SCM/CI/issue
tracker exposes.

Every provider declares ``id`` and ``kind`` and implements ``available()``,
which must never raise — a provider that cannot reach its backend (no
credentials, host not reachable, egress-denied) reports that as a
``(False, reason)`` pair so a caller can render ``skipped — <reason>``
(§10.3) instead of crashing or silently reporting a pass.

PLAN-PLN-MSO-2026-0747 Order 3 (FTR-MSO-2026-0760) adds the three outward
capabilities the voyage-level REL pass needs — ``CiProvider.failed_log``,
``ScmProvider.reply_to_thread`` and ``ScmProvider.resolve_thread`` — and fixes
the PR dict every ``ScmProvider`` returns to one provider-neutral shape
(:data:`PR_KEYS`). Two rules govern those additions:

* **They are not abstract.** A provider that does not offer a capability
  answers :data:`STATUS_UNSUPPORTED` through :class:`ActionResult` — it never
  raises and never pretends to have acted. The base-class default IS that
  answer, so a provider added later (Bitbucket Data Center cannot resolve a
  thread on every server version) inherits the honest reply rather than
  failing to construct.
* **No provider class exposes a method that lands a PR, tags, or publishes.**
  That absence is the primary control on those actions (plan §3 point 3):
  there is no code path in this package a crew can call to perform one. It is
  a control, not an omission — do not add such a method.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Optional

# The four provider kinds this seam supports (§10.1). Additional kinds are a
# later order, not a runtime extension point — adding one means adding a
# subpackage here, not registering a plugin.
PROVIDER_KINDS = ("scm", "ci", "issues", "deploy")

# The provider-neutral keys every ScmProvider PR dict carries (plan D10). A
# provider may keep its own raw keys alongside them, but a caller that must
# work on every SCM reads only these. ``id`` is the PR's human-facing number
# (the one in its URL), not an opaque node id. A value the backend could not
# supply is ``None``, never a guess.
PR_KEYS = ("id", "url", "headRef", "baseRef", "headSha", "isDraft", "merged")

STATUS_OK = "ok"
STATUS_UNSUPPORTED = "unsupported"
STATUS_ERROR = "error"


@dataclass(frozen=True)
class ActionResult:
    """The outcome of a provider capability call that can legitimately be
    absent: ``status`` is one of :data:`STATUS_OK`, :data:`STATUS_UNSUPPORTED`
    or :data:`STATUS_ERROR`; ``detail`` says why whenever it is not ``ok``;
    ``data`` carries the payload (a log's text, a reply's id/url)."""

    status: str
    detail: str = ""
    data: Any = None

    @property
    def ok(self) -> bool:
        return self.status == STATUS_OK

    @classmethod
    def unsupported(cls, provider_id: str, capability: str) -> "ActionResult":
        return cls(STATUS_UNSUPPORTED, f"{provider_id or 'this'} provider does not support {capability}")

    def as_dict(self) -> dict:
        return {"status": self.status, "detail": self.detail, "data": self.data}


class Provider(ABC):
    """Base class for every provider, regardless of kind.

    ``id`` and ``kind`` are class attributes (not just instance state) so
    :func:`maestro.providers.resolve` can report which id/kind it *tried*
    even when construction itself is what fails.
    """

    id: str = ""
    kind: str = ""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config: dict[str, Any] = dict(config or {})

    @abstractmethod
    def available(self) -> tuple[bool, str]:
        """``(True, "")`` if this provider can be used right now, else
        ``(False, reason)``. Must never raise — a provider that cannot even
        determine its own availability should catch internally and report
        ``(False, "<what went wrong>")``.
        """
        raise NotImplementedError


class ScmProvider(Provider):
    """§10.1 capability table — the methods `voyages.pr-ci-state` and
    `mso pr` actually call."""

    kind = "scm"

    #: Automated reviewers whose threads ``mso pr resolve`` may close when the
    #: workspace's ``providers.scm.config.reviewBots`` names none. Empty here:
    #: on an SCM with no known review bot every thread is a human's, and a
    #: human's thread is the Captain's to close (plan §3 point 2).
    DEFAULT_REVIEW_BOTS: tuple[str, ...] = ()

    @abstractmethod
    def get_pr_for_branch(self, branch: str) -> Optional[dict]:
        """The open (or most recent) PR for *branch*, or None if none exists.

        The dict carries every key in :data:`PR_KEYS`."""
        raise NotImplementedError

    @abstractmethod
    def pr_is_draft(self, pr: dict) -> bool:
        raise NotImplementedError

    @abstractmethod
    def pr_review_threads(self, pr: dict) -> list[dict]:
        """Review threads on the PR, each carrying at least ``id``,
        ``isResolved`` and ``author``."""
        raise NotImplementedError

    def pr_review_threads_checked(self, pr: dict) -> tuple[Optional[list[dict]], str]:
        """``(threads, "")``, or ``(None, reason)`` when the lookup FAILED.

        :meth:`pr_review_threads` returns ``[]`` for both "no threads" and
        "could not ask", which is fine for a patrol glance but not for REL's
        READY decision — ``mso pr threads`` calls this instead. Providers that
        can tell the two apart override it; the default cannot, so it trusts
        the lenient list."""
        return list(self.pr_review_threads(pr) or []), ""

    @abstractmethod
    def pr_is_merged(self, pr: dict) -> bool:
        raise NotImplementedError

    def review_bots(self) -> list[str]:
        """The configured ``reviewBots`` list, else :attr:`DEFAULT_REVIEW_BOTS`.

        An explicitly configured empty list means "no automated reviewers" and
        is honoured as such — it does not fall back to the default."""
        configured = self.config.get("reviewBots")
        if isinstance(configured, (list, tuple)):
            return [b for b in configured if isinstance(b, str) and b]
        return list(self.DEFAULT_REVIEW_BOTS)

    def reply_to_thread(self, pr: dict, thread_id: str, body: str) -> ActionResult:
        """Post *body* as a reply on review thread *thread_id* of *pr*.
        ``data`` on success: ``{"id": ..., "url": ...}`` of the new comment."""
        return ActionResult.unsupported(self.id, "replying to review threads")

    def resolve_thread(self, pr: dict, thread_id: str) -> ActionResult:
        """Mark review thread *thread_id* of *pr* resolved."""
        return ActionResult.unsupported(self.id, "resolving review threads")

    # PLAN-PLN-MSO-2026-0747 Order 14 lifecycle contract, defined by
    # FTR-MSO-2026-0769 (Order 11) so the Bitbucket provider could implement it
    # before Order 14 migrates the dispatcher onto it. Non-abstract with honest
    # defaults, exactly like Order 3's capabilities above.

    def get_pr_by_id(self, pr_id: int | str) -> Optional[dict]:
        """The PR with this provider-neutral ``id`` (the number in its URL), normalised
        (``PR_KEYS`` + ``number``), or None when absent / lookup failed. Authoritative
        merged-state read for reconcile (FTR-MSO-2026-0426's "look it up BY NUMBER")."""
        return None

    def create_branch(self, branch: str, from_ref: str) -> ActionResult:
        """Create ``branch`` on the remote at ``from_ref`` (a branch name or full sha).
        IDEMPOTENT: an existing branch is STATUS_OK with ``data={"name": branch,
        "existed": True}``; a new one ``data={"name": branch, "existed": False,
        "sha": <sha or None>}``. Never checks out, never clones."""
        return ActionResult.unsupported(self.id, "creating branches")

    def create_pr(self, head: str, base: str, title: str, body: str, draft: bool = False) -> ActionResult:
        """Open a PR head→base. ``data`` on success is the normalised PR dict.
        When ``draft=True`` and the backend cannot open drafts, return
        STATUS_UNSUPPORTED with a detail containing the word "draft" — the caller
        (Order 14) retries with draft=False, preserving fleet_runner's existing
        draft→normal fallback. An already-open PR for head→base is STATUS_ERROR
        naming its id, never a second PR."""
        return ActionResult.unsupported(self.id, "opening pull requests")

    def mark_ready(self, pr: dict) -> ActionResult:
        """Take a draft PR out of draft. A PR that is already not a draft is
        STATUS_OK with detail "already ready for review" (the backstop call in
        finalisation must be a no-op). A backend with no draft concept is
        STATUS_UNSUPPORTED — Order 14 logs that once and does not fail finalisation."""
        return ActionResult.unsupported(self.id, "marking pull requests ready for review")

    def update_pr_body(self, pr: dict, body: str) -> ActionResult:
        """Replace the PR's description with *body* (FTR-MSO-2026-0502: the voyage
        PR body is re-rendered at finalisation, once QA and SEC reports exist).
        A backend that cannot edit a description is STATUS_UNSUPPORTED — the
        dispatcher logs that once and never fails finalisation over it."""
        return ActionResult.unsupported(self.id, "updating pull request descriptions")


class CiProvider(Provider):
    kind = "ci"

    @abstractmethod
    def checks_for_pr(self, pr: dict) -> list[dict]:
        """``[{"name": str, "status": str, "conclusion": str | None}, ...]``."""
        raise NotImplementedError

    def checks_for_pr_checked(self, pr: dict) -> tuple[Optional[list[dict]], str]:
        """``(checks, "")``, or ``(None, reason)`` when the lookup FAILED —
        see :meth:`ScmProvider.pr_review_threads_checked` for why."""
        return list(self.checks_for_pr(pr) or []), ""

    def failed_log(self, pr: dict, check: str) -> ActionResult:
        """The failure output of the check named *check* on *pr*; ``data`` is
        the log text on success."""
        return ActionResult.unsupported(self.id, "fetching failed-check logs")


class IssuesProvider(Provider):
    kind = "issues"

    @abstractmethod
    def get_issue(self, ref: str) -> Optional[dict]:
        raise NotImplementedError

    @abstractmethod
    def update_issue(self, ref: str, **fields: Any) -> bool:
        raise NotImplementedError

    @abstractmethod
    def close_issue(self, ref: str) -> bool:
        raise NotImplementedError


class DeployProvider(Provider):
    kind = "deploy"

    @abstractmethod
    def last_deployment(self, env: str) -> Optional[dict]:
        """``{"status": str, "ref": str, "at": str} | None``."""
        raise NotImplementedError


KIND_BASE_CLASSES: dict[str, type] = {
    "scm": ScmProvider,
    "ci": CiProvider,
    "issues": IssuesProvider,
    "deploy": DeployProvider,
}
