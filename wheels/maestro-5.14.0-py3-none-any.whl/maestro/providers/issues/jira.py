"""maestro/providers/issues/jira.py — the ``jira`` issues provider.

PLAN-PLN-MSO-2026-0747 Order 13 (D10). Jira Cloud and Jira Data Center, over
each product's REST API. Unlike GitHub, no CLI owns a Jira token the way
``gh`` owns a GitHub one (plan Finding D / D9), so this provider talks HTTP
directly through ``urllib.request`` — the same zero-dependency approach
``maestro/core/bridge_notifier.py``'s Slack call already uses — gated by the
same :class:`~maestro.egress.filter.EgressFilter` every other outward call in
this codebase goes through.

Config (``providers.issues.config``):
    host                 - base URL, e.g. ``https://yourorg.atlassian.net``
                            (Cloud) or ``https://jira.example.com`` (Data
                            Center). Required.
    flavour              - ``"cloud"`` (default) or ``"datacenter"``. Selects
                            the REST API version (v3 vs v2) Jira itself
                            versions the two products under.
    email                - Cloud: the Atlassian account email paired with
                            ``apiToken`` for HTTP Basic auth.
    apiToken             - Cloud: the API token paired with ``email``.
                            Data Center: a bearer token, if ``pat`` is unset.
    pat                  - Data Center: a Personal Access Token (bearer auth,
                            takes priority over ``apiToken`` when both are set).
    closeTransitionName  - the workflow transition name :meth:`close_issue`
                            looks for (case-insensitive substring match).
                            Default ``"done"``.

Every credential field here (``apiToken``, ``pat``) is a name
``maestro.providers.config``'s credential regex already matches (``token``,
``\\bpat\\b``) — so ``set_provider`` refuses it as a literal before it ever
reaches disk (D9); this module only ever sees the value already resolved by
``maestro.secrets.refs.resolve_secret_refs`` at ``resolve_explain`` time.

D10 / plan §8 item 10: nothing in this codebase calls :meth:`update_issue` or
:meth:`close_issue` from a crew's own context. They are implemented because
the :class:`~maestro.providers.base.IssuesProvider` interface requires them
(and a future PM-sync feature may use them), but REL only ever calls
:meth:`get_issue` and reports state — moving a ticket is the Captain's call.
"""

from __future__ import annotations

import json
import logging
import re
import urllib.error
import urllib.request
from base64 import b64encode
from pathlib import Path
from typing import Any, Optional
from urllib.parse import urlparse

from maestro.providers.base import IssuesProvider

logger = logging.getLogger(__name__)

# A credential still carrying its own unresolved reference (env:/secret://)
# must never be sent on the wire literally (PR #427 review) - resolution
# happens upstream (module docstring), but a missing env var leaves the
# reference string in place rather than raising.
_UNRESOLVED_REF_RE = re.compile(r"^(?:env:|secret://)")
_ENV_REF_RE = re.compile(r"^env:([A-Za-z_][A-Za-z0-9_]*)$")


class _RefuseRedirects(urllib.request.HTTPRedirectHandler):
    """Returning None makes urllib raise HTTPError(3xx) instead of following -
    so the Authorization header is never re-sent to a redirect target on a
    different host (PR #427 review; mirrors scm/bitbucket.py's ``_RefuseRedirects``).

    Installed as the process's DEFAULT opener (below), rather than built
    per-call and used via ``opener.open(...)`` - the existing test suite
    patches ``urllib.request.urlopen`` directly (module docstring), which a
    per-call custom opener's own ``.open()`` never goes through. Installing
    it as the default means every plain ``urllib.request.urlopen(...)`` call
    in this process - the one every test here already intercepts - is
    protected, with no change to the call site."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):  # noqa: D401, ANN001
        return None


urllib.request.install_opener(urllib.request.build_opener(_RefuseRedirects()))

_TIMEOUT = 15
_DEFAULT_FLAVOUR = "cloud"
_DEFAULT_CLOSE_TRANSITION = "done"
_VALID_FLAVOURS = ("cloud", "datacenter")

# Standard Jira issue-key shape: a project key (one leading letter, then
# letters/digits), a literal '-', then the numeric id — e.g. "PROJ-123".
# `\b` on both ends keeps a key from matching as a substring of a longer
# token (a URL segment, a longer identifier).
ISSUE_KEY_RE = re.compile(r"\b[A-Z][A-Z0-9]{1,9}-\d+\b")

# The record fields REL's Linked Issues step (plan §6 step 11) scans by
# default. Deliberately only top-level string fields on a voyage/order JSON —
# never a recursive walk of the whole record, so a nested path/handoff
# reference or another provider's URL can't be mistaken for an issue key.
DEFAULT_ISSUE_REF_FIELDS = ("title", "description", "summary")


def detect_issue_refs(record: dict, fields: tuple[str, ...] = DEFAULT_ISSUE_REF_FIELDS) -> list[str]:
    """Jira issue keys found in *record*'s named string fields.

    Order-preserving and de-duplicated. Used against voyage and order JSON
    records to find the tickets a voyage's REL pass should read and report
    on (plan §6 step 11) — this function only detects refs; it never
    resolves them (that is :meth:`JiraIssuesProvider.get_issue`'s job) and
    never runs against anything but the caller-supplied record.
    """
    seen: list[str] = []
    for field in fields:
        value = record.get(field) if isinstance(record, dict) else None
        if not isinstance(value, str):
            continue
        for match in ISSUE_KEY_RE.findall(value):
            if match not in seen:
                seen.append(match)
    return seen


class JiraIssuesProvider(IssuesProvider):
    id = "jira"

    def __init__(self, config: dict[str, Any] | None = None, workspace: Optional[Path] = None) -> None:
        super().__init__(config)
        self._workspace = Path(workspace) if workspace else None

    # -- config helpers ---------------------------------------------------

    def _host(self) -> str:
        return str(self.config.get("host") or "").rstrip("/")

    def _flavour(self) -> str:
        flavour = str(self.config.get("flavour") or _DEFAULT_FLAVOUR).lower()
        return flavour if flavour in _VALID_FLAVOURS else _DEFAULT_FLAVOUR

    def _api_base(self) -> str:
        # Cloud versions its REST API at v3; Data Center still ships v2 (v3
        # is Cloud-only). Both expose the same issue/transitions shapes this
        # provider reads, which is why one implementation covers both.
        version = "3" if self._flavour() == "cloud" else "2"
        return f"{self._host()}/rest/api/{version}"

    @staticmethod
    def _unresolved_ref_problem(label: str, value: Any) -> str:
        if isinstance(value, str) and _UNRESOLVED_REF_RE.match(value.strip()):
            m = _ENV_REF_RE.match(value.strip())
            name = m.group(1) if m else value.strip()
            return f"config.{label} is an unresolved reference ('{name}') - it was never substituted"
        return ""

    def _auth_header(self) -> Optional[str]:
        pat = self.config.get("pat")
        if pat:
            if self._unresolved_ref_problem("pat", pat):
                logger.warning(self._unresolved_ref_problem("pat", pat))
                return None
            return f"Bearer {pat}"
        email = self.config.get("email")
        token = self.config.get("apiToken")
        if email and token:
            if self._unresolved_ref_problem("apiToken", token):
                logger.warning(self._unresolved_ref_problem("apiToken", token))
                return None
            basic = b64encode(f"{email}:{token}".encode("utf-8")).decode("ascii")
            return f"Basic {basic}"
        if token and self._flavour() == "datacenter":
            if self._unresolved_ref_problem("apiToken", token):
                logger.warning(self._unresolved_ref_problem("apiToken", token))
                return None
            # Data Center also accepts a bearer token with no paired email.
            return f"Bearer {token}"
        return None

    # -- transport ----------------------------------------------------------

    def _request(self, method: str, path: str, body: Optional[dict] = None) -> tuple[Optional[dict], str]:
        """``(payload, "")`` on success, ``(None, reason)`` on any failure.

        Never raises — every failure class (no host, no credential, host not
        allowlisted, unreachable, 401/403, 404, any other HTTP error) is
        caught and reported as a reason string, per the ``available()``
        contract every provider in this package follows.
        """
        host = self._host()
        if not host:
            return None, "no host configured"

        auth = self._auth_header()
        if not auth:
            return None, (
                "no credential configured (set 'apiToken' with 'email' for Cloud, "
                "or 'pat' for Data Center)"
            )

        try:
            from maestro.egress.filter import EgressFilter
            ef = EgressFilter.from_workspace(self._workspace or Path.cwd())
            hostname = urlparse(host).hostname or host
            if not ef.is_allowed(hostname):
                return None, f"host not permitted: '{hostname}' is not in allowedDestinations"
        except ImportError:
            pass  # the egress package itself is absent (community/pro) - no restriction applies
        except Exception as exc:  # noqa: BLE001
            # A check that raised is a check that could not answer, not one
            # that answered "allowed" - fail CLOSED (PR #427 review: a
            # swallowed exception here silently bypassed the enterprise
            # egress allowlist).
            return None, f"egress check failed ({exc}) - refusing rather than assuming the host is allowed"

        url = f"{self._api_base()}{path}"
        data = json.dumps(body).encode("utf-8") if body is not None else None
        headers = {"Authorization": auth, "Accept": "application/json"}
        if data is not None:
            headers["Content-Type"] = "application/json"
        req = urllib.request.Request(url, data=data, method=method, headers=headers)

        try:
            with urllib.request.urlopen(req, timeout=_TIMEOUT) as resp:
                raw = resp.read()
        except urllib.error.HTTPError as exc:
            if exc.code in (401, 403):
                return None, f"authentication failed (HTTP {exc.code})"
            if exc.code == 404:
                return None, "not found"
            if 300 <= exc.code < 400:
                return None, f"HTTP {exc.code} (redirect refused - credential not re-sent cross-host)"
            return None, f"HTTP {exc.code}"
        except urllib.error.URLError as exc:
            return None, f"unreachable ({exc.reason})"
        except Exception as exc:  # noqa: BLE001 — the capability contract is never-raise
            return None, f"request failed: {exc}"

        if not raw:
            return {}, ""
        try:
            payload = json.loads(raw.decode("utf-8"))
        except Exception:
            return None, "response was not valid JSON"
        return (payload if isinstance(payload, dict) else {}), ""

    # -- Provider interface ---------------------------------------------

    def available(self) -> tuple[bool, str]:
        _, err = self._request("GET", "/myself")
        if err:
            return False, err
        return True, ""

    def get_issue(self, ref: str) -> Optional[dict]:
        data, err = self._request("GET", f"/issue/{ref}")
        if err or not data:
            return None
        fields = data.get("fields") if isinstance(data.get("fields"), dict) else {}
        status_field = fields.get("status")
        status = status_field.get("name") if isinstance(status_field, dict) else None
        key = data.get("key") or ref
        return {
            "key": key,
            "summary": fields.get("summary"),
            "status": status,
            "url": f"{self._host()}/browse/{key}",
        }

    def update_issue(self, ref: str, **fields: Any) -> bool:
        # Only "summary" is written — a Jira description is Atlassian
        # Document Format (ADF) on Cloud's v3 API but a plain string on Data
        # Center's v2, and D10 already restricts crew usage to reading
        # (`get_issue`); this method exists to satisfy the interface, not to
        # carry a second rich-text format translator no caller needs.
        summary = fields.get("summary")
        if summary is None:
            return False
        _, err = self._request("PUT", f"/issue/{ref}", {"fields": {"summary": summary}})
        return not err

    def close_issue(self, ref: str) -> bool:
        data, err = self._request("GET", f"/issue/{ref}/transitions")
        if err or not data:
            return False
        transitions = data.get("transitions")
        transitions = transitions if isinstance(transitions, list) else []
        wanted = str(self.config.get("closeTransitionName") or _DEFAULT_CLOSE_TRANSITION).lower()
        match = next(
            (t for t in transitions if isinstance(t, dict) and wanted in str(t.get("name", "")).lower()),
            None,
        )
        if not isinstance(match, dict) or not match.get("id"):
            return False
        _, err = self._request("POST", f"/issue/{ref}/transitions", {"transition": {"id": match["id"]}})
        return not err
