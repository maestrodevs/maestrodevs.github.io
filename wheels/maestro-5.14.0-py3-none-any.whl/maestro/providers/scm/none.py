"""maestro/providers/scm/none.py — the explicit no-op SCM provider.

PLAN-PLN-MSO-2026-0504 §10.3: an org running no SCM integration (or one this
Maestro version does not yet speak — Bitbucket/Jira are later orders) still
gets a real, resolvable provider rather than a crash or a silent pass. This
provider is always *unavailable* — its whole purpose is to make "unconfigured"
an explicit, reportable state instead of an absence.

FTR-MSO-2026-0760: the outward capabilities are overridden explicitly (not
merely inherited) so "none answers ``unsupported`` for every capability" is
visible here rather than implied by the base class.
"""

from __future__ import annotations

from typing import Optional

from maestro.providers.base import ActionResult, ScmProvider


class NoneScmProvider(ScmProvider):
    id = "none"

    def available(self) -> tuple[bool, str]:
        return False, "no scm provider configured"

    def get_pr_for_branch(self, branch: str) -> Optional[dict]:
        return None

    def pr_is_draft(self, pr: dict) -> bool:
        return False

    def pr_review_threads(self, pr: dict) -> list[dict]:
        return []

    def pr_is_merged(self, pr: dict) -> bool:
        return False

    def reply_to_thread(self, pr: dict, thread_id: str, body: str) -> ActionResult:
        return ActionResult.unsupported(self.id, "replying to review threads")

    def resolve_thread(self, pr: dict, thread_id: str) -> ActionResult:
        return ActionResult.unsupported(self.id, "resolving review threads")

    # FTR-MSO-2026-0769: the Order 14 lifecycle capabilities, overridden
    # explicitly for the same reason as the two above.

    def get_pr_by_id(self, pr_id: int | str) -> Optional[dict]:
        return None

    def create_branch(self, branch: str, from_ref: str) -> ActionResult:
        return ActionResult.unsupported(self.id, "creating branches")

    def create_pr(self, head: str, base: str, title: str, body: str, draft: bool = False) -> ActionResult:
        return ActionResult.unsupported(self.id, "opening pull requests")

    def mark_ready(self, pr: dict) -> ActionResult:
        return ActionResult.unsupported(self.id, "marking pull requests ready for review")

    def update_pr_body(self, pr: dict, body: str) -> ActionResult:
        return ActionResult.unsupported(self.id, "updating pull request descriptions")
