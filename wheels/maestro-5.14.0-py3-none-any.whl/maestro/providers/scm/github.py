"""maestro/providers/scm/github.py — the ``github`` SCM provider.

PLAN-PLN-MSO-2026-0504 §10.4: this is a THIN WRAPPER over the ``gh`` CLI, the
same tool ``maestro/core/fleet_runner.py`` relies on for its authoritative
PR-state logic (``_gh_pr_view`` / ``_gh_pr_by_number`` — FTR-MSO-2026-0426's
"PR record is authoritative" rule: the merged state is strategy-blind, so
squash, rebase and plain commits all resolve correctly).

The Order 14 lifecycle methods (``get_pr_by_id``, ``create_branch``,
``create_pr``, ``mark_ready`` — FTR-MSO-2026-0772) issue EXACTLY the ``gh``
argv, timeouts and cwd ``fleet_runner.py`` issues today, so moving its call
sites here (Orders 14b/14c) changes no invocation; ``tests/
test_ftr_0772_golden_argv.py`` pins that. Every subprocess call goes through
:meth:`GithubScmProvider._invoke`, which uses a runner injected at
construction (the dispatcher passes one that resolves ``fleet_runner.run_hidden``
at call time, so the suites that patch that name keep intercepting) or else
this module's ``run_hidden``, looked up at call time.

Every read is best-effort and never raises: a missing ``gh`` binary, an
unauthenticated session, or an API error yields ``None``/``[]``/``False``,
exactly like ``fleet_runner._gh_pr_view``'s "enrichment only, never
load-bearing" contract. Only :meth:`available` distinguishes *why* nothing
came back, for the patrol's skip reporting (§10.3). The outward capabilities
(FTR-MSO-2026-0760) never raise either: they return an
:class:`~maestro.providers.base.ActionResult` carrying the reason.

FTR-MSO-2026-0760 also corrected the ``gh pr view`` field list. It used to
request ``merged``, which ``gh pr view --json`` does not accept — so every
call exited non-zero and this provider reported "no PR" for every branch. The
merged state is now derived from ``state``/``mergedAt``, which it does accept.
"""

from __future__ import annotations

import json
import re
import shutil
import subprocess
from pathlib import Path
from typing import Any, Callable, Optional

from maestro.core.proc import run_hidden
from maestro.core.scm_lifecycle import GH_PR_BY_NUMBER_JQ
from maestro.providers.base import (
    STATUS_ERROR,
    STATUS_OK,
    STATUS_UNSUPPORTED,
    ActionResult,
    ScmProvider,
)

_TIMEOUT = 30
_PR_CREATE_TIMEOUT = 60
_SHA40 = re.compile(r"^[0-9a-fA-F]{40}$")
_PR_NUMBER_IN_URL = re.compile(r"/pull/(\d+)")
_PR_URL_ANYWHERE = re.compile(r"https?://\S+/pull/\d+")
_DEFAULT_HOST = "github.com"

# Every field here is one `gh pr view --json` accepts (checked against the
# field list gh prints for `gh pr view --json`). Requesting an unknown field
# fails the whole call.
_PR_VIEW_FIELDS = "number,title,state,isDraft,mergedAt,url,headRefName,baseRefName,headRefOid"

_PR_URL = re.compile(r"^https?://[^/]+/([^/]+)/([^/]+)/pull/\d+")

_MAX_ERR = 500


def _merged_from(raw: dict) -> bool:
    if "merged" in raw:
        return bool(raw.get("merged"))
    return raw.get("state") == "MERGED" or bool(raw.get("mergedAt"))


def normalise_pr(raw: dict) -> dict:
    """Add the provider-neutral keys (``base.PR_KEYS``) to a ``gh pr view`` record.

    The raw gh keys stay alongside them — ``number`` is still what
    ``gh pr checks`` and the patrol read — while a provider-neutral caller
    (``mso pr``, a CI provider keying on ``headRef``/``headSha``) reads only
    the normalised ones.
    """
    pr = dict(raw)
    pr["id"] = raw.get("number")
    pr["url"] = raw.get("url") or None
    pr["headRef"] = raw.get("headRefName") or None
    pr["baseRef"] = raw.get("baseRefName") or None
    pr["headSha"] = raw.get("headRefOid") or None
    pr["isDraft"] = bool(raw.get("isDraft", False))
    pr["merged"] = _merged_from(raw)
    return pr


#: Review-thread pages (100 each) before `pr_review_threads_checked` refuses
#: rather than return a silently truncated list.
_MAX_THREAD_PAGES = 20


class GithubScmProvider(ScmProvider):
    id = "github"

    # PLAN-PLN-MSO-2026-0747 D2: Copilot's automated review is the one bot
    # whose threads REL may close by default on GitHub.
    DEFAULT_REVIEW_BOTS = ("copilot-pull-request-reviewer",)

    def __init__(
        self,
        config: dict[str, Any] | None = None,
        workspace: Optional[Path] = None,
        runner: Optional[Callable[..., Any]] = None,
    ) -> None:
        super().__init__(config)
        self._cwd = Path(self.config.get("repoPath") or workspace or Path.cwd())
        self._slug: Optional[str] = self.config.get("slug") or None
        self._runner = runner

    def _invoke(self, *args: Any, **kwargs: Any) -> Any:
        # Looked up at CALL time, not bound in __init__: a patch of this
        # module's run_hidden made after construction must still apply.
        return (self._runner or run_hidden)(*args, **kwargs)

    def _host(self) -> str:
        return str(self.config.get("host") or _DEFAULT_HOST)

    def available(self) -> tuple[bool, str]:
        if shutil.which("gh") is None:
            return False, "gh CLI not installed"

        host = self._host()
        try:
            from maestro.egress.filter import EgressFilter
            ef = EgressFilter.from_workspace(self._cwd)
            if not ef.is_allowed(host):
                # PLAN-PLN-MSO-2026-0504 §10.2 / order-4 AC: a non-allowlisted
                # host surfaces as "skipped — host not permitted" — the
                # "host not permitted" prefix is a marker resolve_explain()
                # recognises to skip its normal "<kind> provider '<id>'
                # unavailable: ..." wrapping for this specific case.
                return False, f"host not permitted: '{host}' is not in allowedDestinations"
        except Exception:
            pass  # egress module unavailable/misconfigured — do not block on a non-security-relevant failure

        try:
            r = self._invoke(["gh", "auth", "status"], capture_output=True, text=True, timeout=10)
        except Exception as exc:
            return False, f"gh auth status failed ({exc})"
        if r.returncode != 0:
            return False, "gh not authenticated"
        return True, ""

    def _repo_args(self) -> list[str]:
        return ["--repo", self._slug] if self._slug else []

    def _hostname_args(self) -> list[str]:
        host = self._host()
        return [] if host == _DEFAULT_HOST else ["--hostname", host]

    def _owner_repo(self, pr: dict) -> Optional[tuple[str, str]]:
        """``(owner, repo)`` from the configured slug, else from the PR's URL —
        so a workspace that never configured a slug can still list and act on
        its threads."""
        slug = self._slug
        if slug and "/" in slug:
            owner, _, repo = slug.partition("/")
            return owner, repo
        m = _PR_URL.match(str(pr.get("url") or ""))
        return (m.group(1), m.group(2)) if m else None

    def _graphql(
        self, query: str, raw_fields: dict[str, str], typed_fields: Optional[dict[str, Any]] = None,
    ) -> tuple[Optional[dict], str]:
        """Run one ``gh api graphql`` call. Returns ``(data, "")`` or ``(None, error)``.

        ``raw_fields`` go as ``-f`` (always strings — a reply body is never
        type-coerced or read as ``@file``); ``typed_fields`` go as ``-F``."""
        args = ["gh", "api", "graphql"] + self._hostname_args() + ["-f", f"query={query}"]
        for key, value in (typed_fields or {}).items():
            args += ["-F", f"{key}={value}"]
        for key, value in raw_fields.items():
            args += ["-f", f"{key}={value}"]
        try:
            r = self._invoke(args, capture_output=True, text=True, encoding="utf-8", errors="replace",
                             timeout=_TIMEOUT, cwd=str(self._cwd))
        except Exception as exc:
            return None, f"gh api graphql failed ({exc})"
        if r.returncode != 0:
            err = (r.stderr or r.stdout or "").strip()[:_MAX_ERR]
            return None, err or f"gh api graphql exited {r.returncode}"
        try:
            data = json.loads(r.stdout)
        except Exception:
            return None, "gh api graphql returned non-JSON output"
        if not isinstance(data, dict):
            return None, "gh api graphql returned an unexpected payload"
        errors = data.get("errors")
        if errors:
            first = errors[0] if isinstance(errors, list) and errors else errors
            message = first.get("message") if isinstance(first, dict) else str(first)
            return None, str(message)[:_MAX_ERR]
        return data, ""

    def get_pr_for_branch(self, branch: str) -> Optional[dict]:
        args = ["gh", "pr", "view", branch, "--json", _PR_VIEW_FIELDS] + self._repo_args()
        try:
            r = self._invoke(args, capture_output=True, text=True, timeout=_TIMEOUT, cwd=str(self._cwd))
        except Exception:
            return None
        if r.returncode != 0:
            return None
        try:
            raw = json.loads(r.stdout)
        except Exception:
            return None
        return normalise_pr(raw) if isinstance(raw, dict) else None

    def pr_is_draft(self, pr: dict) -> bool:
        return bool(pr.get("isDraft", False))

    def pr_is_merged(self, pr: dict) -> bool:
        return _merged_from(pr)

    def pr_review_threads(self, pr: dict) -> list[dict]:
        """Review threads via the same GraphQL query as the documented PR-ship
        procedure (CLAUDE.md "Phase 2 — Resolve Copilot comments"), plus the
        opening comment's body and location so a reviewer can triage it.
        ``[]`` on any failure — use :meth:`pr_review_threads_checked` where
        "could not ask" must not read as "none"."""
        threads, _err = self.pr_review_threads_checked(pr)
        return threads or []

    def pr_review_threads_checked(self, pr: dict) -> tuple[Optional[list[dict]], str]:
        owner_repo = self._owner_repo(pr)
        number = pr.get("number") or pr.get("id")
        if not owner_repo:
            return None, "could not determine the PR's owner/repo"
        if not number:
            return None, "the PR record carries no number"
        owner, repo = owner_repo
        query = (
            "query($o:String!,$r:String!,$p:Int!,$after:String){"
            "repository(owner:$o,name:$r){pullRequest(number:$p){"
            "reviewThreads(first:100,after:$after){pageInfo{hasNextPage endCursor} "
            "nodes{id isResolved path line "
            "comments(first:1){nodes{author{login} body url}}}}}}}"
        )
        threads: list[dict] = []
        cursor: Optional[str] = None
        for _page in range(_MAX_THREAD_PAGES):
            raw_fields = {"after": cursor} if cursor else {}
            try:
                data, err = self._graphql(query, raw_fields, {"o": owner, "r": repo, "p": int(number)})
            except Exception as exc:
                return None, f"review-thread lookup raised: {exc}"
            if data is None:
                return None, err or "review-thread lookup failed"
            try:
                block = data["data"]["repository"]["pullRequest"]["reviewThreads"]
                nodes = block.get("nodes") or []
                page_info = block.get("pageInfo") or {}
            except Exception:
                return None, "review-thread lookup returned an unexpected payload"
            for node in nodes:
                comments = (node.get("comments") or {}).get("nodes") or []
                first = comments[0] if comments else {}
                threads.append({
                    "id": node.get("id"),
                    "isResolved": bool(node.get("isResolved")),
                    "author": (first.get("author") or {}).get("login") if first else None,
                    "body": first.get("body") if first else None,
                    "url": first.get("url") if first else None,
                    "path": node.get("path"),
                    "line": node.get("line"),
                })
            cursor = page_info.get("endCursor")
            if not page_info.get("hasNextPage") or not cursor:
                return threads, ""
        return None, (f"PR has more than {_MAX_THREAD_PAGES * 100} review threads; "
                      f"refusing to report a truncated list")

    def reply_to_thread(self, pr: dict, thread_id: str, body: str) -> ActionResult:
        if not thread_id:
            return ActionResult(STATUS_ERROR, "no review thread id given")
        if not body or not body.strip():
            return ActionResult(STATUS_ERROR, "reply body is empty")
        query = (
            "mutation($t:ID!,$b:String!){addPullRequestReviewThreadReply("
            "input:{pullRequestReviewThreadId:$t,body:$b}){comment{id url}}}"
        )
        try:
            data, err = self._graphql(query, {"t": thread_id, "b": body})
            if data is None:
                return ActionResult(STATUS_ERROR, f"reply failed: {err}")
            comment = (
                (data.get("data") or {}).get("addPullRequestReviewThreadReply") or {}
            ).get("comment") or {}
            if not comment.get("id"):
                return ActionResult(STATUS_ERROR, "reply failed: GitHub returned no comment")
            return ActionResult(STATUS_OK, "", {"id": comment.get("id"), "url": comment.get("url")})
        except Exception as exc:  # noqa: BLE001 — the capability contract is never-raise
            return ActionResult(STATUS_ERROR, f"reply failed: {exc}")

    def resolve_thread(self, pr: dict, thread_id: str) -> ActionResult:
        if not thread_id:
            return ActionResult(STATUS_ERROR, "no review thread id given")
        query = (
            "mutation($t:ID!){resolveReviewThread(input:{threadId:$t})"
            "{thread{id isResolved}}}"
        )
        try:
            data, err = self._graphql(query, {"t": thread_id})
            if data is None:
                return ActionResult(STATUS_ERROR, f"resolve failed: {err}")
            thread = (
                (data.get("data") or {}).get("resolveReviewThread") or {}
            ).get("thread") or {}
            if not thread.get("isResolved"):
                return ActionResult(STATUS_ERROR, "resolve failed: GitHub did not report the thread resolved")
            return ActionResult(STATUS_OK, "", {"id": thread.get("id"), "isResolved": True})
        except Exception as exc:  # noqa: BLE001
            return ActionResult(STATUS_ERROR, f"resolve failed: {exc}")

    # -- Order 14 lifecycle (FTR-MSO-2026-0772) -----------------------------
    # Each method issues the argv, timeout and cwd fleet_runner.py issues
    # today (plan §1: G4, G7, the `pr create` step of G8/G9, G1), and its
    # failure details are fleet_runner's own strings, so a migrated call site
    # passes `detail` straight through. No method here retries: the caller
    # owns fleet_runner's draft -> normal fallback (base.py create_pr).

    def get_pr_by_id(self, pr_id: int | str) -> Optional[dict]:
        try:
            num = int(pr_id)  # type: ignore[arg-type]
        except (TypeError, ValueError):
            return None
        if num <= 0:
            return None
        slug = self._slug or "{owner}/{repo}"
        try:
            r = self._invoke(
                ["gh", "api", f"repos/{slug}/pulls/{num}", "--jq", GH_PR_BY_NUMBER_JQ],
                capture_output=True, text=True, timeout=_TIMEOUT, cwd=str(self._cwd))
        except Exception:  # noqa: BLE001
            return None
        if r.returncode != 0:
            return None
        try:
            data = json.loads(r.stdout)
        except Exception:  # noqa: BLE001
            return None
        # Shape guard (FTR-MSO-2026-0426): a payload with no `merged` key is not
        # a real by-number PR record — never hand it on as a verdict.
        if not isinstance(data, dict) or "merged" not in data:
            return None
        return normalise_pr(data)

    def create_branch(self, branch: str, from_ref: str) -> ActionResult:
        slug = self._slug
        if not slug:
            return ActionResult(STATUS_ERROR, "github provider needs a repository slug to create a branch")
        try:
            exists = self._invoke(
                ["gh", "api", f"repos/{slug}/branches/{branch}", "--jq", ".name"],
                capture_output=True, text=True, timeout=_TIMEOUT)
            if exists.returncode == 0 and (exists.stdout or "").strip():
                return ActionResult(STATUS_OK, "", {"name": branch, "existed": True})

            if _SHA40.match(from_ref or ""):
                sha = from_ref
            else:
                sha_result = self._invoke(
                    ["gh", "api", f"repos/{slug}/git/refs/heads/{from_ref}", "--jq", ".object.sha"],
                    capture_output=True, text=True, timeout=_TIMEOUT)
                if sha_result.returncode != 0 or not (sha_result.stdout or "").strip():
                    stderr = (sha_result.stderr or "").strip() or "no SHA returned"
                    return ActionResult(
                        STATUS_ERROR,
                        f"could not resolve default branch '{from_ref}' SHA — {stderr[:200]}")
                sha = sha_result.stdout.strip()

            created = self._invoke(
                ["gh", "api", f"repos/{slug}/git/refs",
                 "-f", f"ref=refs/heads/{branch}",
                 "-f", f"sha={sha}"],
                capture_output=True, text=True, timeout=_TIMEOUT)
            if created.returncode == 0:
                return ActionResult(STATUS_OK, "", {"name": branch, "existed": False, "sha": sha})
            return ActionResult(STATUS_ERROR,
                                f"branch creation failed — {(created.stderr or '').strip()[:200]}")
        except subprocess.TimeoutExpired:
            return ActionResult(STATUS_ERROR, "timeout calling gh api (network or auth issue)")
        except Exception as exc:  # noqa: BLE001
            return ActionResult(STATUS_ERROR, f"unexpected error — {type(exc).__name__}: {exc}")

    def create_pr(self, head: str, base: str, title: str, body: str, draft: bool = False) -> ActionResult:
        slug = self._slug
        if not slug:
            return ActionResult(STATUS_ERROR, "github provider needs a repository slug to open a pull request")
        args = [
            "gh", "pr", "create",
            "--repo", slug,
            "--base", base,
            "--head", head,
            "--title", title,
            "--body", body,
        ]
        if draft:
            args.append("--draft")
        try:
            r = self._invoke(args, capture_output=True, text=True, timeout=_PR_CREATE_TIMEOUT)
        except subprocess.TimeoutExpired:
            return ActionResult(STATUS_ERROR, "timed out")
        except Exception as exc:  # noqa: BLE001
            return ActionResult(STATUS_ERROR, f"{type(exc).__name__}: {exc}")

        stderr = r.stderr or ""
        if r.returncode == 0:
            url = (r.stdout or "").strip()
            m = _PR_NUMBER_IN_URL.search(url)
            return ActionResult(STATUS_OK, "", normalise_pr({
                "url": url,
                "number": int(m.group(1)) if m else None,
                "headRefName": head,
                "baseRefName": base,
                "isDraft": bool(draft),
            }))
        if draft and "draft" in stderr.lower():
            return ActionResult(STATUS_UNSUPPORTED, stderr.strip())
        existing = _PR_URL_ANYWHERE.search(stderr)
        if existing and "already exists" in stderr.lower():
            number = _PR_NUMBER_IN_URL.search(existing.group(0))
            return ActionResult(
                STATUS_ERROR,
                f"a pull request is already open for {head} -> {base}: "
                f"#{number.group(1) if number else '?'} {existing.group(0)}")
        return ActionResult(STATUS_ERROR, stderr.strip()[:200])

    def mark_ready(self, pr: dict) -> ActionResult:
        record = pr if isinstance(pr, dict) else {}
        ref = record.get("headRef") or record.get("headRefName") or record.get("number") or record.get("id")
        if ref is None or ref == "":
            return ActionResult(STATUS_ERROR, "the PR record carries no head branch or number")
        kwargs: dict[str, Any] = {"capture_output": True, "text": True, "timeout": _TIMEOUT}
        if not self._slug:
            # fleet_runner passes a cwd only on its no-repo path (gh resolves the
            # repository from that checkout's origin); with --repo it passes none.
            kwargs["cwd"] = str(self._cwd)
        try:
            r = self._invoke(["gh", "pr", "ready", str(ref)] + self._repo_args(), **kwargs)
        except subprocess.TimeoutExpired:
            return ActionResult(STATUS_ERROR, "timed out")
        except Exception as exc:  # noqa: BLE001
            return ActionResult(STATUS_ERROR, f"{type(exc).__name__}: {exc}"[:150])
        if r.returncode == 0:
            return ActionResult(STATUS_OK, "")
        return ActionResult(STATUS_ERROR, (r.stderr or "").strip()[:150])

    def update_pr_body(self, pr: dict, body: str) -> ActionResult:
        record = pr if isinstance(pr, dict) else {}
        ref = record.get("number") or record.get("headRef") or record.get("headRefName") or record.get("id")
        if ref is None or ref == "":
            return ActionResult(STATUS_ERROR, "the PR record carries no number or head branch")
        # The body goes over stdin, not argv: a voyage PR body can be tens of
        # thousands of characters and Windows caps a command line at 32767.
        kwargs: dict[str, Any] = {"capture_output": True, "text": True, "timeout": _TIMEOUT,
                                  "input": body if isinstance(body, str) else "",
                                  "encoding": "utf-8", "errors": "replace"}
        if not self._slug:
            kwargs["cwd"] = str(self._cwd)
        try:
            r = self._invoke(["gh", "pr", "edit", str(ref), "--body-file", "-"] + self._repo_args(),
                             **kwargs)
        except subprocess.TimeoutExpired:
            return ActionResult(STATUS_ERROR, "timed out")
        except Exception as exc:  # noqa: BLE001
            return ActionResult(STATUS_ERROR, f"{type(exc).__name__}: {exc}"[:150])
        if r.returncode == 0:
            return ActionResult(STATUS_OK, "")
        return ActionResult(STATUS_ERROR, (r.stderr or "").strip()[:150])
