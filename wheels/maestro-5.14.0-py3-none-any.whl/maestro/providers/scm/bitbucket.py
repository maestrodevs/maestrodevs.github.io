"""maestro/providers/scm/bitbucket.py — the ``bitbucket`` SCM provider.

PLAN-PLN-MSO-2026-0747 Order 11 (FTR-MSO-2026-0769). One provider for both
Bitbucket **Cloud** (``https://api.bitbucket.org/2.0``) and Bitbucket **Data
Center** (``<scheme>://<host><contextPath>/rest/api/latest``), selected by
``config.flavour``. Unlike ``scm/github.py`` there is no CLI that owns a token,
so this module speaks REST itself over stdlib ``urllib`` and carries the
credential. Most of what follows exists to make sure that credential only
ever reaches the configured host:

* **One transport seam.** :func:`_open` is the only place bytes leave the
  process, and tests patch it. Its opener refuses redirects, so a 3xx is never
  followed with the ``Authorization`` header attached.
* **Egress is checked before every request**, not only in :meth:`available`.
  The private opener bypasses the globally installed egress handler, so this
  module has to ask itself. If the egress policy cannot be evaluated, it
  fails CLOSED. That differs from ``scm/github.py``, which fails open, and
  the difference is deliberate: ``gh`` holds its own token, whereas this
  module would be the thing sending one.
* **Pagination stays on the configured API base.** Cloud returns absolute
  ``next`` links, and one pointing anywhere else is refused, not followed.
* **Plain ``http`` is allowed only to a local host.** TLS verification cannot
  be turned off; ``caBundle`` (a private CA's PEM file) is the only TLS knob.
* **Credentials come by reference (D9).** ``config.token`` is an ``env:NAME``
  or ``secret://`` reference, already resolved by ``resolve_explain``. A value
  that still looks like a reference did NOT resolve, so it means "no
  credential" and is never sent. When ``config.user`` is set the provider
  uses HTTP Basic (Cloud: the Atlassian account email plus an API token);
  otherwise it uses a Bearer token. Error text carries only the vendor's
  message, never headers, the query string, or the token.

Every read is best-effort and never raises (``None``/``[]``, with the reason on
the ``_checked`` variants). Every write returns an
:class:`~maestro.providers.base.ActionResult`.

**Data Center gaps, deliberate.** Two DC REST fields could not be confirmed
against the vendor reference when this was built: ``threadResolved`` on a
comment update (8.9+) and ``draft`` on a pull request (8.18+). A server
silently ignores an unknown field, so guessing either would report success
for an action that never happened. On Data Center, :meth:`resolve_thread`,
opening a *draft* PR, and taking a draft out of draft therefore answer
``unsupported``. ``tests/fixtures/providers/bitbucket/README.md`` records the
same.

No method here lands, declines, tags, or triggers anything. That absence is
the primary control (plan §3 point 3), and the provider is not missing it by
accident.
"""

from __future__ import annotations

import base64
import json
import re
import ssl
import urllib.error
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional
from urllib.parse import quote, urlencode, urlparse

from maestro.core.scm_lifecycle import BITBUCKET_CLOUD_COMMIT_PATH, PR_COMMIT_KEY
from maestro.providers.base import (
    STATUS_ERROR,
    STATUS_OK,
    STATUS_UNSUPPORTED,
    ActionResult,
    ScmProvider,
)

_CLOUD_HOST = "api.bitbucket.org"
_PROBE_TIMEOUT = 10
_TIMEOUT = 30
_MAX_BODY = 5 * 1024 * 1024
_MAX_ERR = 500
#: Comment/activity pages before a thread lookup refuses to report a
#: truncated list (mirrors ``scm/github.py:_MAX_THREAD_PAGES``).
_MAX_PAGES = 20

_ID_RE = re.compile(r"^\d{1,19}$")
_SHA40_RE = re.compile(r"^[0-9a-fA-F]{40}$")
_HEX_RE = re.compile(r"^[0-9a-fA-F]{4,40}$")
_ENV_REF_RE = re.compile(r"^env:([A-Za-z_][A-Za-z0-9_]*)$")
_CONTROL_RE = re.compile(r"[\x00-\x1f\x7f]")
_CONTEXT_PATH_RE = re.compile(r"^[A-Za-z0-9._~/-]*$")
_SEGMENT_RE = re.compile(r"^[A-Za-z0-9._~-]+$")

_FLAVOURS = {"cloud": "cloud", "datacenter": "datacenter", "server": "datacenter", "dc": "datacenter"}

# DC (and Cloud) branch/PR conflict wording worth recognising in vendor text.
_EXISTS_WORDS = ("already exists", "already exist")


class _RefuseRedirects(urllib.request.HTTPRedirectHandler):
    """Returning None makes urllib raise HTTPError(3xx) instead of following —
    so the Authorization header is never re-sent to the Location target."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):  # noqa: D401, ANN001
        return None


def _open(request: urllib.request.Request, timeout: float, context: ssl.SSLContext) -> tuple[int, dict, bytes]:
    """The ONE network call in this module. Tests patch this name.

    Returns ``(status, headers, body)``; an HTTP error status is returned, not
    raised. Connection-level failures (``URLError``, timeouts, TLS errors)
    propagate to :meth:`BitbucketScmProvider._request`, which maps them."""
    opener = urllib.request.build_opener(_RefuseRedirects(), urllib.request.HTTPSHandler(context=context))
    try:
        with opener.open(request, timeout=timeout) as resp:
            return int(resp.status), dict(resp.headers.items()), resp.read(_MAX_BODY + 1)
    except urllib.error.HTTPError as exc:
        try:
            body = exc.read(_MAX_BODY + 1) or b""
        except Exception:  # noqa: BLE001
            body = b""
        try:
            headers = dict(exc.headers.items()) if exc.headers is not None else {}
        except Exception:  # noqa: BLE001
            headers = {}
        return int(exc.code), headers, body


def _dig(obj: Any, *keys: Any) -> Any:
    for key in keys:
        if isinstance(key, int):
            if not isinstance(obj, list) or len(obj) <= key:
                return None
            obj = obj[key]
        else:
            if not isinstance(obj, dict):
                return None
            obj = obj.get(key)
    return obj


def _q(segment: Any) -> str:
    return quote(str(segment), safe="")


def _pr_id(value: Any) -> Optional[str]:
    """A validated numeric PR/comment id as a string, else None."""
    if isinstance(value, bool):
        return None
    if isinstance(value, int) and value > 0:
        return str(value)
    if isinstance(value, str) and _ID_RE.match(value):
        return value
    return None


def _usable_name(value: Any) -> bool:
    return isinstance(value, str) and bool(value.strip()) and not _CONTROL_RE.search(value)


def _vendor_message(payload: Any) -> str:
    """Cloud ``{"error": {"message": …}}`` or DC ``{"errors": [{"message": …}]}``."""
    message = _dig(payload, "error", "message") or _dig(payload, "errors", 0, "message")
    return str(message) if message else ""


def _dc_merged_at(raw: dict) -> Optional[str]:
    """ISO-8601 UTC ``mergedAt`` for a Data Center PR, else None.

    FTR-MSO-2026-0783 (plan §2.6): ``RestPullRequest.closedDate`` is the
    documented close time (int64; Data Center timestamps are epoch
    milliseconds). It is when the PR merged only when ``state == "MERGED"`` —
    a DECLINED PR's close time is never reported as ``mergedAt``."""
    if raw.get("state") != "MERGED":
        return None
    closed = raw.get("closedDate")
    if isinstance(closed, bool) or not isinstance(closed, int) or closed <= 0:
        return None
    try:
        return datetime.fromtimestamp(closed / 1000, tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    except (OverflowError, OSError, ValueError):
        return None


def normalise_cloud_pr(raw: dict) -> dict:
    """Add the provider-neutral keys (``base.PR_KEYS`` plus ``number``) to a
    Bitbucket Cloud pull request record. The raw keys stay alongside them.

    FTR-MSO-2026-0783 (plan §2.6): the landed-commit key
    (``scm_lifecycle.PR_COMMIT_KEY``) is the documented commit hash at
    ``BITBUCKET_CLOUD_COMMIT_PATH``, which may be abbreviated. ``mergedAt`` is
    never set: the Cloud ``pullrequest`` schema documents no merged or closed
    timestamp, and ``updated_on`` is not one (BUG-MSO-2026-0569). Both default
    to None and never overwrite a value already on *raw*."""
    pr = dict(raw)
    pr_id = raw.get("id") if isinstance(raw.get("id"), int) else None
    pr["id"] = pr_id
    pr["number"] = pr_id
    pr["url"] = _dig(raw, "links", "html", "href") or None
    pr["headRef"] = _dig(raw, "source", "branch", "name") or None
    pr["baseRef"] = _dig(raw, "destination", "branch", "name") or None
    pr["headSha"] = _dig(raw, "source", "commit", "hash") or None
    pr["isDraft"] = bool(raw.get("draft", False))
    pr["merged"] = raw.get("state") == "MERGED"
    commit = _dig(raw, *BITBUCKET_CLOUD_COMMIT_PATH)
    if isinstance(commit, str) and commit:
        pr[PR_COMMIT_KEY] = commit
    else:
        pr.setdefault(PR_COMMIT_KEY, None)
    pr.setdefault("mergedAt", None)
    pr["flavour"] = "cloud"
    return pr


def normalise_dc_pr(raw: dict) -> dict:
    """Add the provider-neutral keys to a Bitbucket Data Center pull request."""
    pr = dict(raw)
    pr_id = raw.get("id") if isinstance(raw.get("id"), int) else None
    pr["id"] = pr_id
    pr["number"] = pr_id
    pr["url"] = _dig(raw, "links", "self", 0, "href") or None
    pr["headRef"] = _dig(raw, "fromRef", "displayId") or None
    pr["baseRef"] = _dig(raw, "toRef", "displayId") or None
    pr["headSha"] = _dig(raw, "fromRef", "latestCommit") or None
    pr["isDraft"] = bool(raw.get("draft", False))
    pr["merged"] = raw.get("state") == "MERGED"
    # FTR-MSO-2026-0783 (plan §2.6): RestPullRequest documents no landed-commit
    # field, so that key only ever defaults; mergedAt is the documented
    # closedDate of a MERGED PR. Neither overwrites a value already on *raw*.
    pr.setdefault(PR_COMMIT_KEY, None)
    merged_at = _dc_merged_at(raw)
    if merged_at:
        pr["mergedAt"] = merged_at
    else:
        pr.setdefault("mergedAt", None)
    pr["flavour"] = "datacenter"
    return pr


def _cloud_thread(c: dict) -> dict:
    user = c.get("user") if isinstance(c.get("user"), dict) else {}
    return {
        "id": str(c.get("id")),
        "isResolved": c.get("resolution") is not None,
        "author": user.get("nickname") or user.get("display_name") or None,
        "authorId": user.get("account_id"),
        "body": _dig(c, "content", "raw"),
        "url": _dig(c, "links", "html", "href"),
        "path": _dig(c, "inline", "path"),
        "line": _dig(c, "inline", "to"),
    }


def _dc_thread(c: dict) -> dict:
    author = c.get("author") if isinstance(c.get("author"), dict) else {}
    return {
        "id": str(c.get("id")),
        "isResolved": bool(c.get("threadResolved")) or c.get("state") == "RESOLVED",
        "author": author.get("slug") or author.get("name") or None,
        "body": c.get("text"),
        "url": None,  # DC gives no per-comment link; never build one
        "path": _dig(c, "anchor", "path"),
        "line": _dig(c, "anchor", "line"),
        "version": c.get("version"),
    }


def _dc_reply_ids(comment: Any, into: set[str]) -> None:
    for reply in (comment.get("comments") or []) if isinstance(comment, dict) else []:
        if isinstance(reply, dict) and reply.get("id") is not None:
            into.add(str(reply["id"]))
            _dc_reply_ids(reply, into)


@dataclass(frozen=True)
class _Target:
    flavour: str
    hostname: str
    api_base: str      # …/2.0 (Cloud) or …/rest/api/latest (DC)
    branch_base: str   # …/rest/branch-utils/latest (DC only; "" on Cloud)
    repo_path: str     # /repositories/{ws}/{repo} or /projects/{p}/repos/{r}
    owner: str
    repo: str
    context: ssl.SSLContext


class BitbucketScmProvider(ScmProvider):
    id = "bitbucket"

    # Plan D2: no known automated reviewer on Bitbucket — every thread is a
    # human's unless the workspace names bots in reviewBots.
    DEFAULT_REVIEW_BOTS: tuple[str, ...] = ()

    def __init__(self, config: dict[str, Any] | None = None, workspace: Optional[Path] = None) -> None:
        super().__init__(config)
        # The resolved credential is kept off the public config dict so a
        # caller that renders provider.config never shows it.
        self._token_value: Any = self.config.pop("token", None)
        self._workspace = Path(self.config.get("repoPath") or workspace or Path.cwd())
        self._target_cache: Optional[_Target] = None

    # -- configuration -----------------------------------------------------

    def _target(self) -> tuple[Optional[_Target], str]:
        if self._target_cache is not None:
            return self._target_cache, ""
        cfg = self.config
        raw_flavour = str(cfg.get("flavour") or "").strip().lower()
        if not raw_flavour:
            return None, "no bitbucket flavour configured (set flavour to cloud or datacenter)"
        flavour = _FLAVOURS.get(raw_flavour)
        if flavour is None:
            return None, f"unknown bitbucket flavour '{raw_flavour[:40]}' (expected cloud or datacenter)"

        host = str(cfg.get("host") or "").strip()
        if not host:
            if flavour == "datacenter":
                return None, "no host configured: Bitbucket Data Center needs providers.scm.config.host"
            host = _CLOUD_HOST
        if "/" in host or "@" in host or _CONTROL_RE.search(host) or " " in host:
            return None, "invalid host: give a hostname (optionally :port), not a URL"
        try:
            parsed = urlparse("//" + host)
            hostname = parsed.hostname or ""
            parsed.port  # noqa: B018 — raises ValueError on a bad port
        except ValueError:
            return None, "invalid host: bad port"
        if not hostname:
            return None, "invalid host: give a hostname (optionally :port), not a URL"

        scheme = "https"
        context_path = ""
        if flavour == "datacenter":
            scheme = str(cfg.get("scheme") or "https").strip().lower()
            if scheme not in ("https", "http"):
                return None, f"unsupported scheme '{scheme[:20]}' (expected https or http)"
            if scheme == "http":
                from maestro.egress.filter import is_local

                if not is_local(hostname):
                    return None, "refusing to send credentials over plain http to a non-local host"
            context_path = str(cfg.get("contextPath") or "").strip().strip("/")
            if not _CONTEXT_PATH_RE.match(context_path) or ".." in context_path:
                return None, "invalid contextPath"
            context_path = f"/{context_path}" if context_path else ""

        owner, repo = self._owner_repo(flavour)
        if not owner or not repo:
            pair = "workspace + repo" if flavour == "cloud" else "project + repo"
            return None, f"no repository configured: set slug (owner/repo) or {pair}"

        ca_bundle = cfg.get("caBundle")
        try:
            context = ssl.create_default_context(cafile=str(ca_bundle) if ca_bundle else None)
        except Exception as exc:  # noqa: BLE001
            return None, f"caBundle could not be loaded ({type(exc).__name__})"

        root = f"{scheme}://{host}{context_path}"
        if flavour == "cloud":
            api_base, branch_base = f"https://{host}/2.0", ""
            repo_path = f"/repositories/{_q(owner)}/{_q(repo)}"
        else:
            api_base, branch_base = f"{root}/rest/api/latest", f"{root}/rest/branch-utils/latest"
            repo_path = f"/projects/{_q(owner)}/repos/{_q(repo)}"
        self._target_cache = _Target(flavour, hostname, api_base, branch_base, repo_path, owner, repo, context)
        return self._target_cache, ""

    def _owner_repo(self, flavour: str) -> tuple[str, str]:
        cfg = self.config
        slug = str(cfg.get("slug") or "").strip()
        if slug:
            owner, _, repo = slug.partition("/")
        else:
            owner = str(cfg.get("workspace" if flavour == "cloud" else "project") or "").strip()
            repo = str(cfg.get("repo") or "").strip()
        if not (_SEGMENT_RE.match(owner) and _SEGMENT_RE.match(repo)):
            return "", ""
        return owner, repo

    def _credential(self) -> tuple[Optional[str], str]:
        token = self._token_value
        if not isinstance(token, str) or not token.strip():
            return None, "no credential configured: set providers.scm.config.token to an env:NAME reference"
        token = token.strip()
        if token.startswith("env:"):
            m = _ENV_REF_RE.match(token)
            name = m.group(1) if m else "(invalid variable name)"
            return None, f"credential reference env:{name} is not set in this environment"
        if token.startswith("secret://"):
            return None, ("secret:// references need an enterprise workspace (or the secret could not "
                          "be resolved); use env:NAME")
        user = self.config.get("user")
        if _CONTROL_RE.search(token) or (isinstance(user, str) and _CONTROL_RE.search(user)):
            return None, "credential or user contains control characters"
        if isinstance(user, str) and user.strip():
            raw = f"{user.strip()}:{token}".encode("utf-8")
            return "Basic " + base64.b64encode(raw).decode("ascii"), ""
        return "Bearer " + token, ""

    def _egress_ok(self, hostname: str) -> tuple[bool, str]:
        try:
            from maestro.egress.filter import EgressFilter

            allowed = EgressFilter.from_workspace(self._workspace).is_allowed(hostname)
        except Exception as exc:  # noqa: BLE001 — fail CLOSED: a credential is about to be sent
            return False, (f"host not permitted: egress policy could not be evaluated "
                           f"({type(exc).__name__}); refusing to send credentials")
        if not allowed:
            # The "host not permitted" prefix is the marker resolve_explain()
            # surfaces unwrapped (same as scm/github.py).
            return False, f"host not permitted: '{hostname}' is not in allowedDestinations"
        return True, ""

    # -- transport ---------------------------------------------------------

    def _scrub(self, text: str) -> str:
        token = self._token_value
        if isinstance(token, str) and len(token.strip()) >= 4:
            text = text.replace(token.strip(), "***")
        return text[:_MAX_ERR]

    def _request(
        self, method: str, path_or_url: str, *, body: Any = None, api: str = "core", timeout: float = _TIMEOUT,
    ) -> tuple[Optional[int], Any, str]:
        """``(status, parsed_json_or_None, error)``; ``status`` is None when no
        response was obtained (and no request may have been sent). Never raises."""
        target, err = self._target()
        if target is None:
            return None, None, err
        auth, err = self._credential()
        if auth is None:
            return None, None, err
        try:
            base = target.branch_base if api == "branch-utils" else target.api_base
            if "://" in path_or_url:
                # Only a pagination link, and only one that stays on the API base.
                if not path_or_url.startswith(target.api_base + "/"):
                    return None, None, "refusing to follow a pagination link outside the configured Bitbucket API"
                url = path_or_url
            elif path_or_url.startswith("/") and base:
                url = base + path_or_url
            else:
                return None, None, "internal error: unexpected request path"
            ok, err = self._egress_ok(target.hostname)
            if not ok:
                return None, None, err
            headers = {"Accept": "application/json", "Authorization": auth, "User-Agent": _user_agent()}
            data = None
            if body is not None:
                data = json.dumps(body).encode("utf-8")
                headers["Content-Type"] = "application/json"
            if target.flavour == "datacenter" and method in ("POST", "PUT", "DELETE"):
                headers["X-Atlassian-Token"] = "no-check"  # DC XSRF protection rejects writes without it
            request = urllib.request.Request(url, data=data, headers=headers, method=method)
            status, _headers, raw = _open(request, timeout, target.context)
        except urllib.error.URLError as exc:
            return None, None, self._scrub(
                f"Bitbucket host '{target.hostname}' unreachable: {type(exc).__name__}: {str(exc.reason)[:120]}")
        except OSError as exc:  # timeouts and TLS errors
            return None, None, self._scrub(
                f"Bitbucket host '{target.hostname}' unreachable: {type(exc).__name__}: {str(exc)[:120]}")
        except Exception as exc:  # noqa: BLE001 — never echo the message: it may quote a header value
            return None, None, f"request failed: {type(exc).__name__}"

        raw = raw or b""
        if len(raw) > _MAX_BODY:
            return status, None, "Bitbucket response exceeded 5 MB; refused"
        payload: Any = None
        if raw.strip():
            try:
                payload = json.loads(raw.decode("utf-8", errors="replace"))
            except ValueError:
                payload = None
                if 200 <= status < 300:
                    return status, None, "Bitbucket returned non-JSON output"
        if 300 <= status < 400:
            return status, None, f"Bitbucket answered HTTP {status} (redirect refused; credentials are never re-sent)"
        if 200 <= status < 300:
            return status, payload, ""
        message = _vendor_message(payload)
        return status, payload, self._scrub(f"HTTP {status}" + (f": {message}" if message else ""))

    # -- availability ------------------------------------------------------

    def available(self) -> tuple[bool, str]:
        try:
            target, err = self._target()
            if target is None:
                return False, err
            auth, err = self._credential()
            if auth is None:
                return False, err
            ok, err = self._egress_ok(target.hostname)
            if not ok:
                return False, err
            status, payload, err = self._request("GET", target.repo_path, timeout=_PROBE_TIMEOUT)
            if status is None:
                return False, err
            if 200 <= status < 300:
                return True, ""
            if status == 401:
                return False, ("authentication failed (HTTP 401): check the token and, on Cloud, that user "
                               "is the Atlassian account email")
            if status == 403:
                return False, "forbidden (HTTP 403): the token lacks repository read permission"
            if status == 404:
                return False, (f"repository '{target.owner}/{target.repo}' not found or not visible "
                               f"to this credential (HTTP 404)")
            if status == 429:
                return False, "rate limited by Bitbucket (HTTP 429)"
            message = _vendor_message(payload) if not (300 <= status < 400) else "redirect refused"
            return False, self._scrub(f"Bitbucket returned HTTP {status}: {message or 'no message'}")
        except Exception as exc:  # noqa: BLE001
            return False, f"availability check failed: {type(exc).__name__}"

    # -- PR reads ----------------------------------------------------------

    def _normalise(self, target: _Target, raw: Any) -> Optional[dict]:
        if not isinstance(raw, dict):
            return None
        if target.flavour == "datacenter":
            return normalise_dc_pr(raw)
        pr = normalise_cloud_pr(raw)
        self._expand_cloud_sha(target, pr)
        return pr

    def _expand_cloud_sha(self, target: _Target, pr: dict) -> None:
        """Cloud PR payloads carry an abbreviated ``source.commit.hash``; a CI
        provider keying on ``headSha`` needs all 40 characters. On failure the
        short hash is kept and flagged — never a fabricated full sha."""
        short = pr.get("headSha")
        if not isinstance(short, str) or _SHA40_RE.match(short) or not _HEX_RE.match(short):
            return
        status, payload, _err = self._request("GET", f"{target.repo_path}/commit/{_q(short)}")
        full = _dig(payload, "hash") if status is not None and 200 <= status < 300 else None
        if isinstance(full, str) and _SHA40_RE.match(full) and full.lower().startswith(short.lower()):
            pr["headSha"] = full
        else:
            pr["headShaAbbreviated"] = True

    def get_pr_for_branch(self, branch: str) -> Optional[dict]:
        try:
            if not _usable_name(branch):
                return None
            target, _err = self._target()
            if target is None:
                return None
            if target.flavour == "cloud":
                escaped = branch.replace("\\", "\\\\").replace('"', '\\"')
                params = [("q", f'source.branch.name="{escaped}"'), ("state", "OPEN"), ("state", "MERGED"),
                          ("state", "DECLINED"), ("state", "SUPERSEDED"), ("sort", "-updated_on"),
                          ("pagelen", "50")]
                path = f"{target.repo_path}/pullrequests?{urlencode(params)}"
            else:
                params = [("at", f"refs/heads/{branch}"), ("direction", "OUTGOING"), ("state", "ALL"),
                          ("order", "NEWEST"), ("limit", "50")]
                path = f"{target.repo_path}/pull-requests?{urlencode(params)}"
            status, payload, _err = self._request("GET", path)
            if status is None or not 200 <= status < 300:
                return None
            values = [v for v in (_dig(payload, "values") or []) if isinstance(v, dict)]
            if target.flavour == "cloud":
                values = [v for v in values if _dig(v, "source", "branch", "name") == branch]
            else:
                values = [v for v in values if _dig(v, "fromRef", "id") == f"refs/heads/{branch}"]
            if not values:
                return None
            chosen = next((v for v in values if v.get("state") == "OPEN"), values[0])
            return self._normalise(target, chosen)
        except Exception:  # noqa: BLE001
            return None

    def get_pr_by_id(self, pr_id: int | str) -> Optional[dict]:
        try:
            pid = _pr_id(pr_id)
            target, _err = self._target()
            if pid is None or target is None:
                return None
            collection = "pullrequests" if target.flavour == "cloud" else "pull-requests"
            status, payload, _err = self._request("GET", f"{target.repo_path}/{collection}/{pid}")
            if status is None or not 200 <= status < 300:
                return None
            return self._normalise(target, payload)
        except Exception:  # noqa: BLE001
            return None

    def pr_is_draft(self, pr: dict) -> bool:
        return bool(pr.get("isDraft", pr.get("draft", False)))

    def pr_is_merged(self, pr: dict) -> bool:
        if "merged" in pr:
            return bool(pr.get("merged"))
        return pr.get("state") == "MERGED"

    # -- review threads ----------------------------------------------------

    def pr_review_threads(self, pr: dict) -> list[dict]:
        """``[]`` on any failure — use :meth:`pr_review_threads_checked` where
        "could not ask" must not read as "none"."""
        threads, _err = self.pr_review_threads_checked(pr)
        return threads or []

    def pr_review_threads_checked(self, pr: dict) -> tuple[Optional[list[dict]], str]:
        try:
            target, err = self._target()
            if target is None:
                return None, err
            pid = _pr_id((pr or {}).get("id") or (pr or {}).get("number"))
            if pid is None:
                return None, "the PR record carries no id"
            if target.flavour == "cloud":
                return self._cloud_threads(target, pid)
            return self._dc_threads(target, pid)
        except Exception as exc:  # noqa: BLE001
            return None, f"review-thread lookup raised: {type(exc).__name__}"

    def _cloud_threads(self, target: _Target, pid: str) -> tuple[Optional[list[dict]], str]:
        url = f"{target.repo_path}/pullrequests/{pid}/comments?pagelen=100"
        threads: list[dict] = []
        for _page in range(_MAX_PAGES):
            status, payload, err = self._request("GET", url)
            if status is None or not 200 <= status < 300 or not isinstance(payload, dict):
                return None, err or "review-thread lookup returned an unexpected payload"
            for c in payload.get("values") or []:
                # A thread is a root comment: no parent, not deleted.
                if isinstance(c, dict) and c.get("id") is not None and not c.get("parent") and not c.get("deleted"):
                    threads.append(_cloud_thread(c))
            nxt = payload.get("next")
            if not nxt:
                return threads, ""
            url = str(nxt)
        return None, (f"PR has more than {_MAX_PAGES} pages of comments; "
                      f"refusing to report a truncated list")

    def _dc_threads(self, target: _Target, pid: str) -> tuple[Optional[list[dict]], str]:
        # …/activities, not …/comments: on DC the latter needs a path param
        # and misses general (non-file) comments.
        roots: dict[str, dict] = {}
        reply_ids: set[str] = set()
        start = 0
        for _page in range(_MAX_PAGES):
            path = f"{target.repo_path}/pull-requests/{pid}/activities?limit=100&start={start}"
            status, payload, err = self._request("GET", path)
            if status is None or not 200 <= status < 300 or not isinstance(payload, dict):
                return None, err or "review-thread lookup returned an unexpected payload"
            for activity in payload.get("values") or []:
                if not isinstance(activity, dict):
                    continue
                if activity.get("action") != "COMMENTED" or activity.get("commentAction") != "ADDED":
                    continue
                c = activity.get("comment")
                if not isinstance(c, dict) or c.get("id") is None:
                    continue
                _dc_reply_ids(c, reply_ids)
                if c.get("parent"):
                    reply_ids.add(str(c["id"]))
                    continue
                roots.setdefault(str(c["id"]), c)
            if payload.get("isLastPage", True):
                return [_dc_thread(c) for cid, c in roots.items() if cid not in reply_ids], ""
            nxt = payload.get("nextPageStart")
            if not isinstance(nxt, int) or isinstance(nxt, bool) or nxt <= start:
                return None, "review-thread lookup returned an unexpected pagination cursor"
            start = nxt
        return None, (f"PR has more than {_MAX_PAGES} pages of activity; "
                      f"refusing to report a truncated list")

    def _write_preamble(self, pr: dict, thread_id: Any) -> tuple[Optional[tuple[_Target, str]], Optional[ActionResult]]:
        if not isinstance(thread_id, str) or not _ID_RE.match(thread_id):
            return None, ActionResult(STATUS_ERROR, f"not a Bitbucket comment id: {str(thread_id)[:40]!r}")
        pid = _pr_id((pr or {}).get("id") or (pr or {}).get("number"))
        if pid is None:
            return None, ActionResult(STATUS_ERROR, "the PR record carries no id")
        target, err = self._target()
        if target is None:
            return None, ActionResult(STATUS_ERROR, err)
        return (target, pid), None

    def reply_to_thread(self, pr: dict, thread_id: str, body: str) -> ActionResult:
        try:
            if not isinstance(thread_id, str) or not _ID_RE.match(thread_id):
                return ActionResult(STATUS_ERROR, f"not a Bitbucket comment id: {str(thread_id)[:40]!r}")
            if not isinstance(body, str) or not body.strip():
                return ActionResult(STATUS_ERROR, "reply body is empty")
            ready, refusal = self._write_preamble(pr, thread_id)
            if refusal is not None:
                return refusal
            target, pid = ready
            if target.flavour == "cloud":
                path = f"{target.repo_path}/pullrequests/{pid}/comments"
                payload_out = {"content": {"raw": body}, "parent": {"id": int(thread_id)}}
            else:
                path = f"{target.repo_path}/pull-requests/{pid}/comments"
                payload_out = {"text": body, "parent": {"id": int(thread_id)}}
            status, payload, err = self._request("POST", path, body=payload_out)
            if status is None or not 200 <= status < 300:
                return ActionResult(STATUS_ERROR, f"reply failed: {err}")
            new_id = _dig(payload, "id")
            if new_id is None:
                return ActionResult(STATUS_ERROR, "reply failed: Bitbucket returned no comment")
            url = _dig(payload, "links", "html", "href") if target.flavour == "cloud" else None
            return ActionResult(STATUS_OK, "", {"id": str(new_id), "url": url})
        except Exception as exc:  # noqa: BLE001 — the capability contract is never-raise
            return ActionResult(STATUS_ERROR, f"reply failed: {type(exc).__name__}")

    def resolve_thread(self, pr: dict, thread_id: str) -> ActionResult:
        try:
            ready, refusal = self._write_preamble(pr, thread_id)
            if refusal is not None:
                return refusal
            target, pid = ready
            if target.flavour == "datacenter":
                # threadResolved is unverified against the DC REST reference (module docstring).
                return ActionResult.unsupported(self.id, "resolving review threads on Data Center")
            path = f"{target.repo_path}/pullrequests/{pid}/comments/{thread_id}/resolve"
            status, payload, err = self._request("POST", path)
            if status is not None and 200 <= status < 300 and isinstance(payload, dict):
                return ActionResult(STATUS_OK, "", {"id": thread_id, "isResolved": True})
            if status == 409 or (status in (400, 422) and "already resolved" in err.lower()):
                return ActionResult(STATUS_OK, "thread was already resolved; nothing changed",
                                    {"id": thread_id, "isResolved": True})
            return ActionResult(STATUS_ERROR, f"resolve failed: {err or 'Bitbucket did not confirm the resolution'}")
        except Exception as exc:  # noqa: BLE001
            return ActionResult(STATUS_ERROR, f"resolve failed: {type(exc).__name__}")

    # -- Order 14 lifecycle ------------------------------------------------

    def create_branch(self, branch: str, from_ref: str) -> ActionResult:
        try:
            if not _usable_name(branch) or not _usable_name(from_ref):
                return ActionResult(STATUS_ERROR, "branch and from_ref must be non-empty names without control characters")
            target, err = self._target()
            if target is None:
                return ActionResult(STATUS_ERROR, err)
            if target.flavour == "cloud":
                return self._cloud_create_branch(target, branch, from_ref)
            start_point = from_ref if (_SHA40_RE.match(from_ref) or from_ref.startswith("refs/")) \
                else f"refs/heads/{from_ref}"
            path = f"/projects/{_q(target.owner)}/repos/{_q(target.repo)}/branches"
            status, payload, err = self._request("POST", path, body={"name": branch, "startPoint": start_point},
                                                 api="branch-utils")
            if status is not None and 200 <= status < 300:
                return ActionResult(STATUS_OK, "", {"name": branch, "existed": False,
                                                    "sha": _dig(payload, "latestCommit")})
            if status == 409 or (status == 400 and any(w in err.lower() for w in _EXISTS_WORDS)):
                return ActionResult(STATUS_OK, "branch already exists", {"name": branch, "existed": True})
            return ActionResult(STATUS_ERROR, f"branch creation failed: {err}")
        except Exception as exc:  # noqa: BLE001
            return ActionResult(STATUS_ERROR, f"branch creation failed: {type(exc).__name__}")

    def _cloud_create_branch(self, target: _Target, branch: str, from_ref: str) -> ActionResult:
        branches = f"{target.repo_path}/refs/branches"
        status, payload, err = self._request("GET", f"{branches}/{_q(branch)}")
        if status is not None and 200 <= status < 300:
            return ActionResult(STATUS_OK, "branch already exists",
                                {"name": branch, "existed": True, "sha": _dig(payload, "target", "hash")})
        if status is None:
            return ActionResult(STATUS_ERROR, f"branch creation failed: {err}")
        sha = from_ref if _SHA40_RE.match(from_ref) else None
        if sha is None:
            status, payload, err = self._request("GET", f"{branches}/{_q(from_ref)}")
            sha = _dig(payload, "target", "hash") if status is not None and 200 <= status < 300 else None
            if not isinstance(sha, str) or not sha:
                return ActionResult(STATUS_ERROR, f"could not resolve '{from_ref[:80]}' to a commit: {err or 'no hash'}")
        status, payload, err = self._request("POST", branches, body={"name": branch, "target": {"hash": sha}})
        if status is not None and 200 <= status < 300:
            return ActionResult(STATUS_OK, "", {"name": branch, "existed": False,
                                                "sha": _dig(payload, "target", "hash") or sha})
        if status in (400, 409) and any(w in err.lower() for w in _EXISTS_WORDS):
            return ActionResult(STATUS_OK, "branch already exists", {"name": branch, "existed": True})
        return ActionResult(STATUS_ERROR, f"branch creation failed: {err}")

    def create_pr(self, head: str, base: str, title: str, body: str, draft: bool = False) -> ActionResult:
        try:
            if not _usable_name(head) or not _usable_name(base):
                return ActionResult(STATUS_ERROR, "head and base must be non-empty branch names")
            if not isinstance(title, str) or not title.strip():
                return ActionResult(STATUS_ERROR, "pull request title is empty")
            target, err = self._target()
            if target is None:
                return ActionResult(STATUS_ERROR, err)
            description = body if isinstance(body, str) else ""
            if target.flavour == "cloud":
                path = f"{target.repo_path}/pullrequests"
                payload_out: dict = {"title": title, "description": description,
                                     "source": {"branch": {"name": head}},
                                     "destination": {"branch": {"name": base}}, "draft": bool(draft)}
            else:
                if draft:
                    # The DC draft field is unverified (module docstring); never guess it.
                    return ActionResult(STATUS_UNSUPPORTED, "draft pull requests are not supported by the "
                                                            "bitbucket provider on Data Center")
                repo_ref = {"slug": target.repo, "project": {"key": target.owner}}
                path = f"{target.repo_path}/pull-requests"
                payload_out = {"title": title, "description": description,
                               "fromRef": {"id": f"refs/heads/{head}", "repository": repo_ref},
                               "toRef": {"id": f"refs/heads/{base}", "repository": repo_ref}}
            status, payload, err = self._request("POST", path, body=payload_out)
            if status is not None and 200 <= status < 300:
                pr = self._normalise(target, payload)
                if pr is None or pr.get("id") is None:
                    return ActionResult(STATUS_ERROR, "pull request creation failed: Bitbucket returned no pull request")
                return ActionResult(STATUS_OK, "", pr)
            if status is None:
                return ActionResult(STATUS_ERROR, f"pull request creation failed: {err}")
            if draft and status == 400 and "draft" in err.lower():
                return ActionResult(STATUS_UNSUPPORTED, f"draft pull requests not supported: {err}")
            existing = _dig(payload, "errors", 0, "existingPullRequest", "id")
            if existing is None and status in (400, 409):
                found = self.get_pr_for_branch(head)
                if found and found.get("state") == "OPEN" and found.get("baseRef") == base:
                    existing = found.get("id")
            if existing is not None:
                return ActionResult(STATUS_ERROR, f"a pull request is already open for {head} -> {base}: #{existing}")
            return ActionResult(STATUS_ERROR, f"pull request creation failed: {err}")
        except Exception as exc:  # noqa: BLE001
            return ActionResult(STATUS_ERROR, f"pull request creation failed: {type(exc).__name__}")

    def mark_ready(self, pr: dict) -> ActionResult:
        try:
            if not self.pr_is_draft(pr or {}):
                return ActionResult(STATUS_OK, "already ready for review")
            pid = _pr_id(pr.get("id") or pr.get("number"))
            if pid is None:
                return ActionResult(STATUS_ERROR, "the PR record carries no id")
            target, err = self._target()
            if target is None:
                return ActionResult(STATUS_ERROR, err)
            if target.flavour == "datacenter":
                return ActionResult.unsupported(self.id, "marking pull requests ready for review on Data Center")
            path = f"{target.repo_path}/pullrequests/{pid}"
            status, payload, err = self._request("PUT", path, body={"draft": False})
            if status is not None and 200 <= status < 300 and isinstance(payload, dict) \
                    and payload.get("draft") is False:
                return ActionResult(STATUS_OK, "", self._normalise(target, payload))
            if status is None:
                return ActionResult(STATUS_ERROR, f"mark ready failed: {err}")
            # Cloud PUT has been reported to need the title alongside the flag: retry once with it.
            status, current, err = self._request("GET", path)
            title = _dig(current, "title") if status is not None and 200 <= status < 300 else None
            if not isinstance(title, str):
                return ActionResult(STATUS_ERROR, f"mark ready failed: {err or 'could not read the PR title'}")
            status, payload, err = self._request("PUT", path, body={"title": title, "draft": False})
            if status is not None and 200 <= status < 300 and isinstance(payload, dict) \
                    and payload.get("draft") is False:
                return ActionResult(STATUS_OK, "", self._normalise(target, payload))
            return ActionResult(STATUS_ERROR, f"mark ready failed: {err or 'Bitbucket still reports a draft'}")
        except Exception as exc:  # noqa: BLE001
            return ActionResult(STATUS_ERROR, f"mark ready failed: {type(exc).__name__}")

    def update_pr_body(self, pr: dict, body: str) -> ActionResult:
        try:
            pid = _pr_id((pr or {}).get("id") or (pr or {}).get("number"))
            if pid is None:
                return ActionResult(STATUS_ERROR, "the PR record carries no id")
            target, err = self._target()
            if target is None:
                return ActionResult(STATUS_ERROR, err)
            if target.flavour == "datacenter":
                # A DC update needs the PR's optimistic-lock version; unverified here
                # (module docstring), so never guessed.
                return ActionResult.unsupported(self.id, "updating pull request descriptions on Data Center")
            path = f"{target.repo_path}/pullrequests/{pid}"
            # Cloud PUT has been reported to need the title alongside other fields.
            status, current, err = self._request("GET", path)
            title = _dig(current, "title") if status is not None and 200 <= status < 300 else None
            if not isinstance(title, str):
                return ActionResult(STATUS_ERROR, f"description update failed: {err or 'could not read the PR title'}")
            status, payload, err = self._request(
                "PUT", path, body={"title": title, "description": body if isinstance(body, str) else ""})
            if status is not None and 200 <= status < 300:
                return ActionResult(STATUS_OK, "", self._normalise(target, payload))
            return ActionResult(STATUS_ERROR, f"description update failed: {err}")
        except Exception as exc:  # noqa: BLE001
            return ActionResult(STATUS_ERROR, f"description update failed: {type(exc).__name__}")


def _user_agent() -> str:
    try:
        from maestro import __version__

        return f"maestro/{__version__}"
    except Exception:  # noqa: BLE001
        return "maestro"
