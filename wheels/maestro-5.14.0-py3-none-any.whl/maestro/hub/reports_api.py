# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""The Hub's report routes (FTR-MSO-2026-0729 — PLAN-PLN-MSO-2026-0726 §5, Order A2).

**What this module is, and what it deliberately is not.** It is the thin
adapter between :mod:`maestro.reports` — the framework-agnostic report record
core delivered by Order A1 — and FastAPI. It parses nothing, walks no
directories, and knows no report file format. Every fact on a response here was
computed by :mod:`maestro.reports.qa_reader`; this module's whole job is
workspace fan-out, bounding, and turning dataclasses into the wire models in
:mod:`maestro.hub.models`.

That boundary is the plan's "one core model, many surfaces" rule (§4) made
structural: the CLI and FTR-MSO-2026-0502's PR-body generator consume the same
records, so a parsing change made *here* would be a second QA parser drifting
away from the first — which is the exact failure the core package exists to
prevent.

**Ungated, by Captain decision D1.** These routes carry no
``_require_control_tier()`` call, matching every other read-only route in the
Hub (``/api/v1/usage*``, ``/orders/{id}/artefacts``,
``/orders/{id}/salvage-candidates``) and unlike every mutating one. The
decisive point recorded in the plan: ``GET /api/v1/orders/{id}/artefacts/{key}``
already serves the full raw bytes of every QA report, ungated, today — gating a
*parsed summary* of files whose *raw text* is already open would be theatre, and
would make the Hub inconsistent with itself. The Hub's confidentiality boundary
is per-deployment (``MAESTRO_HUB_TOKEN``, allowed hosts/origins), not
per-endpoint tier; tiers gate capability, not confidentiality.

**Registration by injection, not by re-implementation.** ``create_app()`` owns
``_validate_order_id`` and ``_iter_workspaces`` as closures, and
:func:`register_report_routes` takes them as arguments rather than growing local
copies. An order id reaching these routes is therefore validated by *the same
function object* the artefact and review routes use — a hardening change to that
regex cannot leave a report route behind, which a second copy silently would.

**No content read happens here.** ``MAX_ARTEFACT_BYTES`` (512 KB) is applied by
``qa_reader._read_bounded`` at the point of every file read, so the bound holds
for this surface because this surface performs no reads of its own. There is
nothing to re-cap and nothing that could be capped inconsistently.

**FastAPI is imported lazily**, inside :func:`register_report_routes`, for the
same reason ``server.py`` does it: ``import maestro.hub.reports_api`` must never
fail when the ``[hub]`` extra is absent.
"""

from __future__ import annotations

import re
from typing import Any, Callable, Iterable, List, Optional, Tuple

#: Default number of QA reports returned by the list route.
#:
#: The live MSO workspace holds 274 of them; an unbounded list would parse every
#: one on every request, and the page that consumes this shows a table. A caller
#: that genuinely wants everything asks for it explicitly, up to
#: :data:`MAX_QA_LIMIT`.
DEFAULT_QA_LIMIT = 100

#: Hard ceiling on ``?limit=``. FastAPI rejects a larger value at validation
#: (``le=MAX_QA_LIMIT``), and :func:`list_qa` clamps defensively for its
#: non-HTTP callers, so the bound holds on both paths.
MAX_QA_LIMIT = 500


# ---------------------------------------------------------------------------
# Read functions — no FastAPI, so they are callable from a test (or a CLI)
# without an HTTP round-trip.
# ---------------------------------------------------------------------------

def _mso_dirs(iter_workspaces: Callable[[], Iterable[Tuple[str, Any]]],
              workspace_id: Optional[str] = None) -> List[Tuple[str, Any]]:
    """``(workspace_id, mso_dir)`` for every registered workspace, or just one.

    A workspace whose artefact root cannot be resolved (an unregistered path, a
    stale mount) is skipped rather than failing the whole response — the same
    tolerance ``_find_order_workspace_any`` applies. It then appears nowhere in
    the response's ``workspaces`` list, so an operator can see it was not read.
    """
    from maestro.hub.review import _get_mso_dir

    out: List[Tuple[str, Any]] = []
    for ws_id, ws_root in iter_workspaces():
        if workspace_id is not None and ws_id != workspace_id:
            continue
        try:
            out.append((ws_id, _get_mso_dir(ws_root)))
        except Exception:
            continue
    return out


def _qa_model(summary: Any, workspace_id: str = ""):
    """Wire model for one :class:`~maestro.reports.models.QAReportSummary`.

    Built by splatting the record's own ``to_dict()``, so the wire shape is the
    core shape by construction. A field added to the record and not to the model
    is dropped by Pydantic rather than crashing the route; a field added to the
    model and not to the record takes its declared default. Neither can silently
    invent a value.
    """
    from maestro.hub.models import QAReportModel

    payload = summary.to_dict()
    payload["workspaceId"] = workspace_id
    return QAReportModel(**payload)


def list_qa(iter_workspaces: Callable[[], Iterable[Tuple[str, Any]]],
            workspace_id: Optional[str] = None,
            limit: int = DEFAULT_QA_LIMIT):
    """Every QA report across the registered workspaces, newest first, bounded.

    ``limit`` is clamped to ``[0, MAX_QA_LIMIT]``. Each workspace is asked for
    at most ``limit`` records (its own newest), the merged set is re-sorted by
    modification time and trimmed to ``limit`` — so the response is the globally
    newest ``limit`` reports, not the first workspace's share of them.

    ``available`` counts the QA report FILES the scanned workspaces hold, read
    from the directory listing rather than from the parsed set, so a bounded
    response always states how much it left out. ``parseCoverage`` is recomputed
    over exactly the trimmed set: it must describe the records the caller
    received and never a larger set they did not (plan §7).
    """
    from maestro.hub.artefacts import iter_report_paths
    from maestro.hub.models import ParseCoverageModel, QAReportList
    from maestro.reports import list_qa_reports
    from maestro.reports.models import ParseCoverage

    try:
        limit = int(limit)
    except (TypeError, ValueError):
        limit = DEFAULT_QA_LIMIT
    limit = max(0, min(limit, MAX_QA_LIMIT))

    scanned: List[str] = []
    available = 0
    rows: List[Tuple[str, str, Any]] = []   # (modified, workspace_id, summary)

    for ws_id, mso in _mso_dirs(iter_workspaces, workspace_id):
        scanned.append(ws_id)
        try:
            available += sum(1 for p in iter_report_paths(mso, "qa")
                             if p.suffix.lower() == ".md")
        except Exception:
            pass
        if limit == 0:
            continue
        try:
            summaries, _coverage = list_qa_reports(mso, limit=limit)
        except Exception:
            # `list_qa_reports` is documented never to raise, but a workspace
            # that somehow breaks it must not take the other workspaces' reports
            # down with it.
            continue
        for summary in summaries:
            rows.append((summary.modified or "", ws_id, summary))

    # Newest first. `modified` is an ISO-8601 UTC string from the same producer
    # for every row, so it sorts lexicographically; the report name breaks ties
    # deterministically. An empty `modified` (an unreadable stat) sorts last,
    # which is the honest place for the record we know least about.
    rows.sort(key=lambda r: (r[0], r[2].report_name), reverse=True)
    rows = rows[:limit]

    coverage = ParseCoverage()
    reports = []
    for _modified, ws_id, summary in rows:
        coverage.add(summary.decided)
        reports.append(_qa_model(summary, ws_id))

    return QAReportList(
        reports=reports,
        parseCoverage=ParseCoverageModel(**coverage.to_dict()),
        workspaceId=workspace_id,
        limit=limit,
        returned=len(reports),
        available=available,
        workspaces=scanned,
    )


def qa_detail(iter_workspaces: Callable[[], Iterable[Tuple[str, Any]]],
              order_id: str,
              workspace_id: Optional[str] = None):
    """The QA record for *order_id*, or ``None`` when no workspace has one.

    ``None`` means discovery found no ``reports/qa/`` file for this order in any
    scanned workspace. It is NOT the same as a record carrying
    ``verdict=UNDETERMINED``, which means a report exists and could not be read
    — the route maps the first to 404 and returns the second as a 200, because
    "no QA has been done" and "QA was done and we cannot summarise it" are
    different answers and a surface must be able to tell them apart.
    """
    from maestro.reports import read_qa_report

    for ws_id, mso in _mso_dirs(iter_workspaces, workspace_id):
        try:
            summary = read_qa_report(mso, order_id)
        except Exception:
            continue
        if summary is not None:
            return _qa_model(summary, ws_id)
    return None


# ---------------------------------------------------------------------------
# Acceptance-criteria reads (FTR-MSO-2026-0734 — PLAN-PLN-MSO-2026-0726 §5 B2)
# ---------------------------------------------------------------------------

#: Default number of AC order records returned by the list route. The live MSO
#: workspace holds ~570 orders carrying criteria or results; the page asks for
#: :data:`MAX_AC_LIMIT` explicitly so it can bucket client-side.
DEFAULT_AC_LIMIT = 200

#: Hard ceiling on ``?limit=``. Unlike the QA list, bounding here does not save
#: the parse — the coverage headline needs every order read regardless — it only
#: bounds the response body.
MAX_AC_LIMIT = 1000

_ORDER_SEQ_RE = re.compile(r"-(\d{4})-(\d+)$")


def _order_sort_key(order_id: str) -> Tuple[int, int, str]:
    """Newest-first key for an order id: ``(year, sequence, id)``.

    AC records carry no timestamp of their own, and the workspace sequence space
    is shared across types (CLAUDE.md naming rules), so year + sequence is the
    creation order. An id that does not match sorts after every one that does.
    """
    m = _ORDER_SEQ_RE.search(order_id or "")
    if not m:
        return (-1, -1, order_id or "")
    return (int(m.group(1)), int(m.group(2)), order_id)


def _ac_model(rollup: Any, workspace_id: str = ""):
    """Wire model for one :class:`~maestro.reports.models.ACOrderRollup`.

    Splats the record's own ``to_dict()``, exactly like :func:`_qa_model`.
    """
    from maestro.hub.models import ACOrderRollupModel

    payload = rollup.to_dict()
    payload["workspaceId"] = workspace_id
    return ACOrderRollupModel(**payload)


def list_ac(iter_workspaces: Callable[[], Iterable[Tuple[str, Any]]],
            workspace_id: Optional[str] = None,
            bucket: Optional[str] = None,
            limit: int = DEFAULT_AC_LIMIT):
    """The AC coverage headline plus a bounded, newest-first order list.

    ``coverage`` is an :class:`~maestro.reports.models.ACCoverage` re-accumulated
    over EVERY rollup from every scanned workspace — before the ``bucket``
    filter and before the ``limit`` trim — so the headline always describes the
    fleet, never the page (see ``ACReportList``). ``bucket`` must be one of
    :data:`ACBucket.ALL` or ``None``; anything else raises ``ValueError``, which
    the route maps to 400 rather than silently returning an unfiltered list.
    """
    from maestro.hub.models import ACCoverageModel, ACReportList
    from maestro.reports import list_ac_rollups
    from maestro.reports.models import ACBucket, ACCoverage

    if bucket is not None and bucket not in ACBucket.ALL:
        raise ValueError(
            f"Unknown bucket '{bucket}'; expected one of {', '.join(ACBucket.ALL)}")

    try:
        limit = int(limit)
    except (TypeError, ValueError):
        limit = DEFAULT_AC_LIMIT
    limit = max(0, min(limit, MAX_AC_LIMIT))

    scanned: List[str] = []
    rows: List[Tuple[str, Any]] = []   # (workspace_id, rollup)
    for ws_id, mso in _mso_dirs(iter_workspaces, workspace_id):
        scanned.append(ws_id)
        try:
            rollups, _coverage = list_ac_rollups(mso)
        except Exception:
            # Documented never to raise; one broken workspace must not take the
            # others' records down with it.
            continue
        rows.extend((ws_id, r) for r in rollups)

    coverage = ACCoverage()
    for _ws_id, rollup in rows:
        coverage.add(rollup)

    matching = [(w, r) for w, r in rows
                if bucket is None or r.coverage_bucket == bucket]
    matching.sort(key=lambda wr: _order_sort_key(wr[1].order_id), reverse=True)
    page = matching[:limit]

    return ACReportList(
        coverage=ACCoverageModel(**coverage.to_dict()),
        rollups=[_ac_model(r, w) for w, r in page],
        workspaceId=workspace_id,
        bucket=bucket,
        limit=limit,
        returned=len(page),
        available=len(matching),
        considered=len(rows),
        workspaces=scanned,
    )


def ac_detail(iter_workspaces: Callable[[], Iterable[Tuple[str, Any]]],
              order_id: str,
              workspace_id: Optional[str] = None):
    """*order_id*'s AC record, or ``None`` when no workspace holds that order.

    ``None`` means the ORDER could not be found. An order that exists with no
    recorded result is a 200 whose rows read NOT RECORDED — "no such order" and
    "nothing was recorded for it" are different answers.
    """
    from maestro.reports import read_order_ac

    for ws_id, mso in _mso_dirs(iter_workspaces, workspace_id):
        try:
            rollup = read_order_ac(mso, order_id)
        except Exception:
            continue
        if rollup is not None:
            return _ac_model(rollup, ws_id)
    return None


# ---------------------------------------------------------------------------
# Security reads (FTR-MSO-2026-0736 — PLAN-PLN-MSO-2026-0726 §5 B4)
# ---------------------------------------------------------------------------
# Two families on two read functions, and no function that combines them
# (plan §1.4): per-order SEC verdicts, and `REVIEW-*` scanner runs whose counts
# are known to be wrong by orders of magnitude. Neither response carries a
# severity total.

#: Default number of SEC documents returned. The live MSO workspace holds ~36.
DEFAULT_SECURITY_LIMIT = 200
MAX_SECURITY_LIMIT = 500

#: Default number of scanner runs returned. Each run is a multi-megabyte file
#: read under the 512 KB cap, so this bound is also the parse bound.
DEFAULT_SCANNER_RUN_LIMIT = 50
MAX_SCANNER_RUN_LIMIT = 200

# An absolute filesystem path inside a string (SEC-FTR-MSO-2026-0735 finding
# SEC-0735-02). A Windows drive path, a UNC path, or a POSIX path under a
# directory that only ever holds device-local layout. POSIX is deliberately a
# prefix list rather than "anything starting with /": `/api/v1/...` and
# `.mso/reports/...` are not device paths and must survive. Linear: one fixed
# prefix alternation followed by a single negated character class.
_ABSOLUTE_PATH_RE = re.compile(
    r"(?:(?<![\w/\\])[A-Za-z]:[\\/]|\\\\[^\s\\/'\"`]+[\\/]"
    r"|(?<![\w.~/-])/(?:home|Users|root|tmp|var|opt|srv|mnt|private|repos)/)"
    r"[^\s'\"`<>|]*")


#: A drive-letter or UNC prefix: roots of this shape are matched case-insensitively.
_WINDOWS_ROOT_RE = re.compile(r"^(?:[A-Za-z]:[\\/]|\\\\)")


def _redact_absolute(match: "re.Match[str]") -> str:
    text = match.group(0).rstrip(".,;:)]")
    tail = match.group(0)[len(text):]
    name = re.split(r"[\\/]", text)[-1]
    return f"…/{name}{tail}" if name else f"…{tail}"


def _scrub_value(value: Any, roots: List[Tuple[str, str]]) -> Any:
    """*value* with every absolute device path made non-absolute.

    A path under a scanned workspace keeps its workspace-relative form
    (``reports/security/SEC-X.md``) — the useful part, and exactly what
    ``reportRel`` already exposes. Any other absolute path is reduced to its
    final component. Recurses through dicts and lists; non-strings pass through.
    """
    if isinstance(value, str):
        if not value:
            return value
        out = value
        for root, replacement in roots:
            if not root:
                continue
            if _WINDOWS_ROOT_RE.match(root):
                # Windows paths are case-insensitive: a report that spells the
                # workspace `c:\repos\...` must still keep its relative form
                # rather than falling through to the "…/name" redaction.
                out = re.sub(re.escape(root), lambda _m, r=replacement: r, out, flags=re.IGNORECASE)
            elif root in out:
                out = out.replace(root, replacement)
        return _ABSOLUTE_PATH_RE.sub(_redact_absolute, out)
    if isinstance(value, dict):
        return {k: _scrub_value(v, roots) for k, v in value.items()}
    if isinstance(value, list):
        return [_scrub_value(v, roots) for v in value]
    return value


def _path_roots(mso: Any) -> List[Tuple[str, str]]:
    """``(absolute prefix, replacement)`` pairs for one workspace, longest first.

    Both separator spellings of both the artefact root and its parent, each
    with a trailing separator, so ``C:\\ws\\.mso\\reports\\x.md`` becomes
    ``reports/x.md``-shaped rather than leaking the device layout.
    """
    from pathlib import PurePosixPath, PureWindowsPath

    pairs: List[Tuple[str, str]] = []
    try:
        raw = str(mso)
        # Parse a drive-letter or UNC root as a WINDOWS path on every platform.
        # `Path(r"C:\ws\.mso")` on POSIX is one opaque name: no forward-slash
        # spelling, and `.parent` is "." - so a Windows workspace path in a
        # report (or a test run on Linux CI) was never matched and fell through
        # to the "…/name" redaction instead of keeping its relative form.
        windows = bool(re.match(r"^(?:[A-Za-z]:[\\/]|\\\\)", raw))
        mso_path = PureWindowsPath(raw) if windows else PurePosixPath(raw.replace("\\", "/"))
        for base, repl in ((mso_path, ""), (mso_path.parent, "")):
            text = str(base)
            for spelling in {text, text.replace("\\", "/"), text.replace("/", "\\")}:
                if spelling and len(spelling) > 3:
                    pairs.append((spelling.rstrip("\\/") + "\\", repl))
                    pairs.append((spelling.rstrip("\\/") + "/", repl))
    except Exception:
        return []
    pairs = list(dict.fromkeys(pairs))
    pairs.sort(key=lambda p: len(p[0]), reverse=True)
    return pairs


def _security_payload(record: Any, workspace_id: str, mso: Any) -> dict:
    payload = _scrub_value(record.to_dict(), _path_roots(mso))
    payload["workspaceId"] = workspace_id
    return payload


def _security_model(summary: Any, workspace_id: str, mso: Any):
    """Wire model for one :class:`~maestro.reports.models.SecurityReportSummary`.

    Splats the record's own ``to_dict()`` like :func:`_qa_model`, after
    scrubbing absolute device paths out of every string (SEC-0735-02: an
    ``OSError`` message in ``parseNotes`` carries the full path, and this
    surface is ungated).
    """
    from maestro.hub.models import SecurityReportModel

    return SecurityReportModel(**_security_payload(summary, workspace_id, mso))


def _scanner_run_model(run: Any, workspace_id: str, mso: Any):
    """Wire model for one :class:`~maestro.reports.models.ScannerRun`, scrubbed.

    A scanner location outside the workspace root is left absolute by the
    reader on purpose; this boundary is where it stops being absolute.
    """
    from maestro.hub.models import ScannerRunModel

    return ScannerRunModel(**_security_payload(run, workspace_id, mso))


def _clamp(limit: Any, default: int, ceiling: int) -> int:
    try:
        limit = int(limit)
    except (TypeError, ValueError):
        limit = default
    return max(0, min(limit, ceiling))


def list_security(iter_workspaces: Callable[[], Iterable[Tuple[str, Any]]],
                  workspace_id: Optional[str] = None,
                  limit: int = DEFAULT_SECURITY_LIMIT):
    """Every SEC document across the registered workspaces, newest first, bounded.

    Same bounding rules as :func:`list_qa`: ``available`` is read from the
    directory listing, and ``parseCoverage`` / ``verdictCounts`` are recomputed
    over exactly the trimmed set. ``REVIEW-*`` runs are neither listed nor
    counted here.
    """
    from maestro.hub.artefacts import iter_report_paths
    from maestro.hub.models import (
        ParseCoverageModel,
        SecurityOtherDocumentModel,
        SecurityReportList,
    )
    from maestro.reports.models import ParseCoverage
    from maestro.reports.security_reader import (
        _is_sec_report,
        list_other_security_documents,
        list_security_reports,
    )

    limit = _clamp(limit, DEFAULT_SECURITY_LIMIT, MAX_SECURITY_LIMIT)

    scanned: List[str] = []
    available = 0
    others = []
    rows: List[Tuple[str, str, Any, Any]] = []   # (modified, ws_id, mso, summary)

    for ws_id, mso in _mso_dirs(iter_workspaces, workspace_id):
        scanned.append(ws_id)
        try:
            available += sum(1 for p in iter_report_paths(mso, "security")
                             if _is_sec_report(p))
        except Exception:
            pass
        try:
            others.extend(SecurityOtherDocumentModel(name=name, workspaceId=ws_id)
                          for name in list_other_security_documents(mso))
        except Exception:
            pass
        if limit == 0:
            continue
        try:
            summaries, _coverage = list_security_reports(mso, limit=limit)
        except Exception:
            continue
        for summary in summaries:
            rows.append((summary.modified or "", ws_id, mso, summary))

    rows.sort(key=lambda r: (r[0], r[3].report_name), reverse=True)
    rows = rows[:limit]

    coverage = ParseCoverage()
    verdict_counts: dict = {}
    reports = []
    for _modified, ws_id, mso, summary in rows:
        coverage.add(summary.decided)
        verdict_counts[summary.verdict] = verdict_counts.get(summary.verdict, 0) + 1
        reports.append(_security_model(summary, ws_id, mso))

    return SecurityReportList(
        reports=reports,
        parseCoverage=ParseCoverageModel(**coverage.to_dict()),
        verdictCounts=verdict_counts,
        otherDocuments=others,
        workspaceId=workspace_id,
        limit=limit,
        returned=len(reports),
        available=available,
        workspaces=scanned,
    )


# Voyage report reads (FTR-MSO-2026-0737 — PLAN-PLN-MSO-2026-0726 §5 B5)
# ---------------------------------------------------------------------------

#: Default number of voyage index entries. Index entries are manifest-only (no
#: QA / AC / usage read), so the whole workspace fits comfortably; the bound
#: exists so the response body cannot grow without limit.
DEFAULT_VOYAGE_LIMIT = 500

#: Hard ceiling on ``?limit=`` for the voyage index.
MAX_VOYAGE_LIMIT = 2000


def _workspace_roots(iter_workspaces: Callable[[], Iterable[Tuple[str, Any]]],
                     workspace_id: Optional[str] = None) -> List[Tuple[str, Any, Any]]:
    """``(workspace_id, ws_root, mso_dir)`` — :func:`_mso_dirs` plus the root.

    The voyage report needs the workspace root as well as the artefact dir,
    because the usage aggregator it composes over is keyed on the root (exactly
    as ``/api/v1/usage/voyages/{id}`` calls it). Same skip-on-unresolvable
    tolerance as :func:`_mso_dirs`.
    """
    from maestro.hub.review import _get_mso_dir

    out: List[Tuple[str, Any, Any]] = []
    for ws_id, ws_root in iter_workspaces():
        if workspace_id is not None and ws_id != workspace_id:
            continue
        try:
            out.append((ws_id, ws_root, _get_mso_dir(ws_root)))
        except Exception:
            continue
    return out


def _voyage_model(summary: Any, workspace_id: str = ""):
    """Wire model for one :class:`~maestro.reports.models.VoyageReportSummary`.

    Splats the record's own ``to_dict()``, exactly like :func:`_qa_model`.
    """
    from maestro.hub.models import VoyageReportModel

    payload = summary.to_dict()
    payload["workspaceId"] = workspace_id
    return VoyageReportModel(**payload)


def list_voyages(iter_workspaces: Callable[[], Iterable[Tuple[str, Any]]],
                 workspace_id: Optional[str] = None,
                 limit: int = DEFAULT_VOYAGE_LIMIT):
    """Every voyage across the scanned workspaces as manifest-only index entries.

    Newest first by the latest date each manifest records (a voyage recording
    none sorts last), trimmed to ``limit``; ``available`` is the untrimmed count.
    """
    from maestro.hub.models import VoyageReportList
    from maestro.reports import list_voyage_reports

    try:
        limit = int(limit)
    except (TypeError, ValueError):
        limit = DEFAULT_VOYAGE_LIMIT
    limit = max(0, min(limit, MAX_VOYAGE_LIMIT))

    scanned: List[str] = []
    rows: List[Tuple[str, Any]] = []
    for ws_id, _ws_root, mso in _workspace_roots(iter_workspaces, workspace_id):
        scanned.append(ws_id)
        try:
            summaries = list_voyage_reports(mso)
        except Exception:
            # Documented never to raise; one broken workspace must not take the
            # others' voyages down with it.
            continue
        rows.extend((ws_id, s) for s in summaries)

    rows.sort(key=lambda ws: (ws[1].sort_key(), ws[0]), reverse=True)
    page = rows[:limit]
    return VoyageReportList(
        voyages=[_voyage_model(s, w) for w, s in page],
        workspaceId=workspace_id,
        limit=limit,
        returned=len(page),
        available=len(rows),
        workspaces=scanned,
    )


def security_detail(iter_workspaces: Callable[[], Iterable[Tuple[str, Any]]],
                    order_id: str,
                    workspace_id: Optional[str] = None):
    """Every SEC document for *order_id*, or ``None`` when no workspace has one.

    ``None`` means no SEC document exists for the order — a different answer
    from a document whose verdict is UNDETERMINED, which is returned (200).
    """
    from maestro.hub.models import SecurityOrderReports
    from maestro.reports.security_reader import read_security_reports

    for ws_id, mso in _mso_dirs(iter_workspaces, workspace_id):
        try:
            summaries = read_security_reports(mso, order_id)
        except Exception:
            continue
        if summaries:
            return SecurityOrderReports(
                orderId=summaries[0].order_id or order_id,
                reports=[_security_model(s, ws_id, mso) for s in summaries],
            )
    return None


def list_scanner_run_records(iter_workspaces: Callable[[], Iterable[Tuple[str, Any]]],
                             workspace_id: Optional[str] = None,
                             limit: int = DEFAULT_SCANNER_RUN_LIMIT):
    """Every ``REVIEW-*`` scanner run, newest first, bounded — runs only.

    There is intentionally no aggregate over the runs' severity counts (see
    :class:`~maestro.hub.models.ScannerRunList`). ``trustCounts`` counts RUNS.
    """
    from maestro.hub.artefacts import iter_report_paths
    from maestro.hub.models import ScannerRunList
    from maestro.reports.security_reader import _is_scanner_run, list_scanner_runs

    limit = _clamp(limit, DEFAULT_SCANNER_RUN_LIMIT, MAX_SCANNER_RUN_LIMIT)

    scanned: List[str] = []
    available = 0
    rows: List[Tuple[str, str, Any, Any]] = []   # (sort key, ws_id, mso, run)

    for ws_id, mso in _mso_dirs(iter_workspaces, workspace_id):
        scanned.append(ws_id)
        try:
            available += sum(1 for p in iter_report_paths(mso, "security")
                             if _is_scanner_run(p))
        except Exception:
            pass
        if limit == 0:
            continue
        try:
            runs = list_scanner_runs(mso, limit=limit)
        except Exception:
            continue
        for run in runs:
            rows.append((run.ran_at or run.run_id or "", ws_id, mso, run))

    rows.sort(key=lambda r: (r[0], r[3].run_id), reverse=True)
    rows = rows[:limit]

    trust_counts: dict = {}
    out = []
    for _key, ws_id, mso, run in rows:
        trust_counts[run.trust] = trust_counts.get(run.trust, 0) + 1
        out.append(_scanner_run_model(run, ws_id, mso))

    return ScannerRunList(
        runs=out,
        trustCounts=trust_counts,
        workspaceId=workspace_id,
        limit=limit,
        returned=len(out),
        available=available,
        workspaces=scanned,
    )


def voyage_detail(iter_workspaces: Callable[[], Iterable[Tuple[str, Any]]],
                  voyage_id: str,
                  workspace_id: Optional[str] = None):
    """*voyage_id*'s composed report, or ``None`` when no workspace holds it.

    ``None`` means no manifest names the voyage. A voyage that exists and left
    no usage / QA / AC record is a 200 whose absences say so.
    """
    from maestro.reports import read_voyage_report

    for ws_id, ws_root, mso in _workspace_roots(iter_workspaces, workspace_id):
        try:
            report = read_voyage_report(mso, voyage_id, ws_root=ws_root)
        except Exception:
            continue
        if report is not None:
            return _voyage_model(report, ws_id)
    return None


# ---------------------------------------------------------------------------
# Route registration
# ---------------------------------------------------------------------------

def register_report_routes(app, *, validate_order_id, iter_workspaces) -> None:
    """Attach the ``/api/v1/reports/*`` routes to *app*.

    Called once from ``create_app()`` AFTER every pre-existing route is
    registered. It adds routes and touches none of them — the report surface
    sits alongside the artefact routes, never on top of them (plan §4, "DO NOT
    MODIFY").

    *validate_order_id* and *iter_workspaces* are ``create_app()``'s own
    closures, passed in rather than re-created here (see the module docstring).
    """
    import fastapi

    from maestro.hub.models import (
        ACOrderRollupModel,
        ACReportList,
        QAReportList,
        QAReportModel,
    )

    # -----------------------------------------------------------------------
    # QA report endpoints (FTR-MSO-2026-0729) — read-only, ungated
    # -----------------------------------------------------------------------

    @app.get("/api/v1/reports/qa", response_model=QAReportList)
    async def list_qa_reports_route(
        workspace_id: Optional[str] = fastapi.Query(default=None),
        limit: int = fastapi.Query(default=DEFAULT_QA_LIMIT, ge=0, le=MAX_QA_LIMIT),
    ):
        """QA reports across every registered workspace, newest first.

        Read-only, ungated — matches `/api/v1/usage` (Captain decision D1).

        workspace_id: restrict to one registered workspace (default: all)
        limit: bound on the number of reports returned (default 100, max 500)

        The response carries `parseCoverage` — {total, parsed, undetermined} —
        so a drift in the QA heading contract shows up as a falling `parsed`
        instead of as silently missing verdicts.
        """
        return list_qa(iter_workspaces, workspace_id=workspace_id, limit=limit)

    @app.get("/api/v1/reports/qa/{order_id}", response_model=QAReportModel)
    async def get_qa_report_route(order_id: str):
        """One order's QA record. Read-only, ungated — matches `/api/v1/usage`.

        *order_id* is validated by `create_app()`'s own `_validate_order_id`, so
        a traversal attempt is a 400 before any filesystem access, and a
        well-formed id nothing has a report for is a 404 whose detail names only
        the id the caller already supplied.
        """
        validate_order_id(order_id)
        report = qa_detail(iter_workspaces, order_id)
        if report is None:
            raise fastapi.HTTPException(
                status_code=404,
                detail=f"No QA report found for order '{order_id}'")
        return report

    # -----------------------------------------------------------------------
    # Acceptance-criteria endpoints (FTR-MSO-2026-0734) — read-only, ungated
    # -----------------------------------------------------------------------
    # Plain `def`, not `async def`: the coverage headline has to read EVERY
    # order JSON plus its QA report (~570 orders, several seconds on the live
    # MSO plane). FastAPI runs a sync handler in its threadpool; an async one
    # would run that parse on the event loop and stall every other Hub request,
    # the lifecycle websocket included, for its duration.

    @app.get("/api/v1/reports/ac", response_model=ACReportList)
    def list_ac_reports_route(
        workspace_id: Optional[str] = fastapi.Query(default=None),
        bucket: Optional[str] = fastapi.Query(default=None),
        limit: int = fastapi.Query(default=DEFAULT_AC_LIMIT, ge=0, le=MAX_AC_LIMIT),
    ):
        """AC coverage headline plus per-order records, newest first.

        Read-only, ungated — matches `/api/v1/usage` (Captain decision D1).

        workspace_id: restrict to one registered workspace (default: all)
        bucket: met | partial | outstanding | not-covered | no-criteria
        limit: bound on the number of order records returned (default 200, max 1000)

        `coverage` describes every order in the scanned workspaces — never just
        the returned page — because its headline is COVERAGE ("N of M orders
        with criteria have a recorded verification"), not a pass rate (D4).
        """
        try:
            return list_ac(iter_workspaces, workspace_id=workspace_id,
                           bucket=bucket, limit=limit)
        except ValueError as exc:
            raise fastapi.HTTPException(status_code=400, detail=str(exc))

    @app.get("/api/v1/reports/ac/{order_id}", response_model=ACOrderRollupModel)
    def get_ac_report_route(order_id: str):
        """One order's AC record. Read-only, ungated — matches `/api/v1/usage`.

        Validated by `create_app()`'s own `_validate_order_id`. 404 only when no
        workspace holds the ORDER; an order with nothing recorded is a 200 whose
        rows read NOT RECORDED.
        """
        validate_order_id(order_id)
        rollup = ac_detail(iter_workspaces, order_id)
        if rollup is None:
            raise fastapi.HTTPException(
                status_code=404,
                detail=f"No order found for '{order_id}'")
        return rollup

    # -----------------------------------------------------------------------
    # Security endpoints (FTR-MSO-2026-0736) — read-only, ungated
    # -----------------------------------------------------------------------
    # Two families, two list routes, no route that combines them (plan §1.4).
    # Plain `def` for the AC routes' reason: a scanner run is a large file read
    # under the byte cap, and fifteen of them take over a second to parse.
    # `/scanner-runs` is registered BEFORE `/{order_id}` so the literal segment
    # is never captured as an order id.

    from maestro.hub.models import (
        ScannerRunList,
        SecurityOrderReports,
        SecurityReportList,
    )

    @app.get("/api/v1/reports/security", response_model=SecurityReportList)
    def list_security_reports_route(
        workspace_id: Optional[str] = fastapi.Query(default=None),
        limit: int = fastapi.Query(default=DEFAULT_SECURITY_LIMIT, ge=0,
                                   le=MAX_SECURITY_LIMIT),
    ):
        """Per-order SEC verdicts across every registered workspace, newest first.

        Read-only, ungated — matches `/api/v1/usage` (Captain decision D1).

        workspace_id: restrict to one registered workspace (default: all)
        limit: bound on the number of SEC documents returned (default 200, max 500)

        UNDETERMINED is a first-class verdict and is counted under its own key,
        never as a pass. Scanner runs are not included — see
        `/api/v1/reports/security/scanner-runs`.
        """
        return list_security(iter_workspaces, workspace_id=workspace_id, limit=limit)

    @app.get("/api/v1/reports/security/scanner-runs", response_model=ScannerRunList)
    def list_scanner_runs_route(
        workspace_id: Optional[str] = fastapi.Query(default=None),
        limit: int = fastapi.Query(default=DEFAULT_SCANNER_RUN_LIMIT, ge=0,
                                   le=MAX_SCANNER_RUN_LIMIT),
    ):
        """`REVIEW-*` scanner runs, newest first. Read-only, ungated.

        RUNS, not a risk posture: the response carries no severity total, and
        every run's counts are marked untrustworthy with the false-positive
        evidence read from its own findings.
        """
        return list_scanner_run_records(iter_workspaces, workspace_id=workspace_id,
                                        limit=limit)

    @app.get("/api/v1/reports/security/{order_id}", response_model=SecurityOrderReports)
    def get_security_report_route(order_id: str):
        """Every SEC document for one order. Read-only, ungated.

        Validated by `create_app()`'s own `_validate_order_id`. 404 only when no
        workspace holds a SEC document for the order; a document whose verdict
        could not be read is a 200 reading UNDETERMINED.
        """
        validate_order_id(order_id)
        reports = security_detail(iter_workspaces, order_id)
        if reports is None:
            raise fastapi.HTTPException(
                status_code=404,
                detail=f"No security report found for order '{order_id}'")
        return reports

    # Voyage report endpoints (FTR-MSO-2026-0737) — read-only, ungated
    # -----------------------------------------------------------------------
    # Plain `def` for the same reason as the AC routes: the detail route parses
    # every member order's QA report and walks the usage records, which must not
    # run on the event loop.

    from maestro.hub.models import VoyageReportList, VoyageReportModel

    @app.get("/api/v1/reports/voyage", response_model=VoyageReportList)
    def list_voyage_reports_route(
        workspace_id: Optional[str] = fastapi.Query(default=None),
        limit: int = fastapi.Query(default=DEFAULT_VOYAGE_LIMIT, ge=0, le=MAX_VOYAGE_LIMIT),
    ):
        """The voyage index, newest first. Read-only, ungated — matches `/api/v1/usage`.

        workspace_id: restrict to one registered workspace (default: all)
        limit: bound on the number of voyages returned (default 500, max 2000)

        Entries are manifest-only (`composed: false`): member orders and spend
        are read by the detail route, never here.
        """
        return list_voyages(iter_workspaces, workspace_id=workspace_id, limit=limit)

    @app.get("/api/v1/reports/voyage/{voyage_id}", response_model=VoyageReportModel)
    def get_voyage_report_route(voyage_id: str):
        """One voyage's report, composed on read (Captain decision D2).

        Read-only, ungated — matches `/api/v1/usage`. *voyage_id* is validated by
        `create_app()`'s own `_validate_order_id`, as the voyage blockage route
        does. 404 only when no workspace holds a manifest for the voyage.
        """
        validate_order_id(voyage_id)
        report = voyage_detail(iter_workspaces, voyage_id)
        if report is None:
            raise fastapi.HTTPException(
                status_code=404,
                detail=f"No voyage found for '{voyage_id}'")
        return report


__all__ = [
    "DEFAULT_AC_LIMIT",
    "DEFAULT_QA_LIMIT",
    "DEFAULT_SCANNER_RUN_LIMIT",
    "DEFAULT_SECURITY_LIMIT",
    "DEFAULT_VOYAGE_LIMIT",
    "MAX_AC_LIMIT",
    "MAX_QA_LIMIT",
    "MAX_SCANNER_RUN_LIMIT",
    "MAX_SECURITY_LIMIT",
    "MAX_VOYAGE_LIMIT",
    "ac_detail",
    "list_ac",
    "list_qa",
    "list_scanner_run_records",
    "list_security",
    "list_voyages",
    "qa_detail",
    "register_report_routes",
    "security_detail",
    "voyage_detail",
]
