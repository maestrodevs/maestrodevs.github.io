# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Entry point: python -m maestro.hub [--port N]

BUG-MSO-2026-0712: this is the daemon's ONLY chance to say why it is going
away. ``run_hub`` wraps the uvicorn call so an unhandled backend exception
lands in ``~/.maestro/logs/hub.log`` with its full traceback, and every exit
this process can observe about itself (clean, ``SystemExit``, or crash) is
recorded in ``~/.maestro/hub.exit.json`` for the next ``mso hub status`` to
read back. Nothing here can catch a hard kill — that case is reported from
the PID file's mtime instead, and is never dressed up as a recorded exit.

BUG-MSO-2026-0751: the server runs on ``maestro.hub.serving``'s event loop,
whose accept survives a client aborting mid-handshake, and under a
``ServingGuard`` — a Hub whose listener dies anyway exits with
``EXIT_STOPPED_SERVING`` instead of living on as a process nobody can reach.
"""

import argparse
import os
import sys

# BUG-MSO-2026-0712 — MUST run before the first `maestro` import below.
#
# BUG-MSO-2026-0516 launches this file BY PATH so the operator's cwd cannot
# shadow `import maestro`, and that half works. What it does not do is make
# `import maestro` resolve to the tree this file physically lives in: running
# `python <script>.py` puts only the SCRIPT'S OWN directory (maestro/hub/) on
# sys.path, so `import maestro` falls through to whatever site-packages holds.
# A daemon could therefore run `maestro/hub/__main__.py` from one install and
# `maestro/hub/server.py` from another — two halves of two Maestro versions in
# one process, silently, with DEVNULL swallowing the evidence.
#
# Pinning the parent of THIS file's own package tree makes the process
# coherent by construction. It does NOT reintroduce 0516's defect: the path
# inserted is derived from `__file__`, never from the cwd, so a decoy package
# sitting in the working directory still cannot win.
_PACKAGE_PARENT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if _PACKAGE_PARENT not in sys.path:
    sys.path.insert(0, _PACKAGE_PARENT)

import uvicorn

from maestro.hub import logs, serving
from maestro.hub.server import create_app

#: How long a tripped Hub lets its stopped-serving log line and exit record
#: settle before the guard ends the process.
STOPPED_SERVING_GRACE_SECONDS = 1.0


def _record_stopped_serving(reason: str) -> None:
    logs.write_exit_record(
        serving.EXIT_STOPPED_SERVING, error=serving.HubStoppedServing(reason),
    )


def run_hub(port: int) -> int:
    """Run the backend, returning the process exit code.

    Ordering matters: the start banner is written BEFORE ``create_app()``,
    because app construction is itself a place the daemon can die (a bad
    registry, a missing static bundle, an import error in a route module) —
    a banner written afterwards would be missing from exactly the runs that
    most need explaining.

    BUG-MSO-2026-0751: a tripped guard writes the exit record itself and ends
    the process with ``EXIT_STOPPED_SERVING``. There is no graceful shutdown to
    wait for — the listener is already gone, and ``uvicorn.run`` offers no
    handle to request one — so the record is written first and the guard's
    backstop exits after a short grace.
    """
    logs.write_start_banner(port)
    guard = serving.ServingGuard(
        port, log=logs.append_line, on_trip=_record_stopped_serving,
        grace_seconds=STOPPED_SERVING_GRACE_SECONDS,
    )
    try:
        app = create_app()
        serving.install_guard(guard)
        guard.start()
        uvicorn.run(app, host="127.0.0.1", port=port, log_level="warning",
                    loop=serving.HUB_LOOP_SPEC)
        if guard.tripped:
            # uvicorn returned inside the grace window — same exit, same record.
            return serving.EXIT_STOPPED_SERVING
    except SystemExit as exc:  # noqa: PERF203 — distinct, deliberate exit path
        code = exc.code if isinstance(exc.code, int) else (0 if exc.code is None else 1)
        logs.write_exit_record(code)
        return code
    except KeyboardInterrupt:
        # An operator-initiated stop, not a fault. Recorded as a clean exit
        # with no traceback: dressing every `mso hub stop` up as an
        # "UNHANDLED EXCEPTION" would bury the real crashes this log exists
        # to surface under routine noise.
        logs.append_line("=== Hub daemon interrupted (KeyboardInterrupt) — clean stop ===")
        logs.write_exit_record(0)
        return 0
    except BaseException as exc:  # noqa: BLE001 — the whole point: never die silently
        logs.log_unhandled_exception(exc, port=port)
        logs.write_exit_record(1, error=exc)
        return 1
    finally:
        guard.stop()
        serving.install_guard(None)
    logs.write_exit_record(0)
    return 0


def main() -> None:
    ap = argparse.ArgumentParser(description="Maestro Hub server")
    ap.add_argument("--port", type=int, default=3847, help="Port to bind (default 3847)")
    args = ap.parse_args()
    sys.exit(run_hub(args.port))


if __name__ == "__main__":
    main()
