# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Workspace-parameterised attention classifier (FTR-MSO-2026-0487).

PLAN-PLN-MSO-2026-0468 §3.3: BUG-MSO-2026-0451's ``fleet_monitor.
get_held_breakdown()`` already named the taxonomy this module surfaces to the
Hub — review-gated / stranded / dep-held / skipped — but the function itself
is bound to process-global workspace state (it and ``fleet_runner``'s
``voyages_outstanding_work()`` both bottom out at a module-global
``get_artefact_root()``). The Hub's poller (maestro/hub/poller.py) serves N
registered workspaces from ONE process; calling the global-resolving form
there would return whichever workspace the process happened to have resolved,
silently wrong per workspace, with no error. "Reuse the taxonomy" therefore
means: keep the four category NAMES (do not invent a fifth, or rename these
four — that is the "parallel taxonomy" the plan warns against), but classify
each workspace from data this module reads itself, given an EXPLICIT
``mso: Path`` — no ``find_workspace()``, no CWD, no globals.

Per-category source of truth (mirrors get_held_breakdown()'s own docstring):

  - review_gated: any order whose *status* is ``NAV_REVIEW_PENDING`` —
    read from the already-built order index (cheap: no extra file I/O).
  - stranded:     any order whose *status* is one of the seven PLAN §2
    values (CONVERGENCE_FAILED / BLOCKED / AUTO_SERIALIZE / ESCALATED /
    STALLED / VERIFY_FAILED / FAILED) — also read from the order index.
    BUG-MSO-2026-0703: its ``reason`` is the order's own ``operatorNote``
    (already parsed into ``Order.operator_note``, so still no extra I/O) —
    the salvage branch, its diff-stat, the ancestry found, and the retry
    command. That note is the whole point of the tag: a stranded order is
    the one category whose verb is "do something", and the Hub previously
    showed only the status.
  - dep_held:     order IDs in ``.mso/state/dep-holds.json`` (BUG-0349) —
    NOT visible in order status (the order stays e.g. PENDING while held),
    so this needs the dedicated dep-holds reader.
    BUG-MSO-2026-0741 adds a SECOND source to the same bucket: an order held
    at PROPOSED/HELD with no ``dependsOn`` and no ACTIVE chart node, which
    nothing in the engine can ever release. It belongs here rather than in a
    fifth category — the order genuinely is held, waiting for a release — and
    the ``reason`` is what tells the operator the release can never arrive.
    A real dep-holds entry names the blocking ids and keeps precedence.
  - skipped:      order IDs in the operator skip list (BUG-0288) — likewise
    invisible in order status.

Deliberately does NOT call ``fleet_runner.voyages_outstanding_work()`` for
"stranded", unlike ``get_held_breakdown()``'s own CLI-dashboard figure.
That function answers "is this voyage fully finished yet" (BUG-0303 Eight
Bells) — ANY non-archived order in an active voyage counts as "outstanding",
including one a crew is healthily mid-flight on right now. Taken as a
per-ORDER tag (not a workspace-level "why does the fleet look idle" count)
that would mislabel ordinary PENDING/IN_PROGRESS work as "Needs Attention"
and offer a Retry button on an order nothing is wrong with. The status-list
in PLAN §2 is the more precise rule for tagging INDIVIDUAL orders, and the
order index already has every order's current status parsed and cached
(BUG-0422) — no extra read, and no dependency on fleet_runner's
process-global ``_MAESTRO_DIR_OVERRIDE`` escape hatch (which get_held_breakdown
now uses for parity with `mso status`; see its docstring). This is a
deliberate, narrower design than the CLI figure — flagged here and in the
BLD handoff for TST/Captain awareness, not a silent divergence.

BUG-MSO-2026-0743 — ``skipped`` is ORTHOGONAL, not a fifth bucket. The
``attention`` tag above is single-valued by design (an order renders in exactly
one board bucket, Captain Decision D1), and the precedence below deliberately
lets stranded/dep-held/review-gated overwrite it. That is right for a BUCKET and
wrong for a FACT: an operator skips an order *precisely because* it is stranded,
so "skipped" and "stranded" are the common intersection, not the impossible one
this module's precedence note originally assumed. Deriving "is this order
skipped" from ``attention == 'skipped'`` therefore answers "no" for every order
an operator is most likely to have skipped — which made the Hub's Restore
(unskip) control unreachable for exactly those orders (FTR-MSO-2026-0622's
control regressed to a second Remove button).

So the skip list gets its OWN carrier: ``Order.is_skipped`` / ``Order.skip_reason``,
stamped by ``apply_skip_state()`` straight from ``maestro.core.skip_list`` — the
same one shared reader ``classify_orders`` uses — and never derived from, or
overwritable by, the attention tag. The tag keeps its existing precedence
verbatim (no bucket/count regression); consumers asking "is this skipped" ask
``is_skipped``.

Known gap: orders archived to ``orders/failed/`` (terminal FAILED) are not
in the order index aggregator.py builds (its search dirs cover
``orders/complete`` but not ``orders/failed``), so a FAILED order will not
currently surface under Needs Attention. Widening the index's search dirs is
an aggregator.py-level, cache-sensitive change judged out of scope for this
order — see the BLD handoff.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, Iterable, Optional

if TYPE_CHECKING:
    from maestro.hub.models import AttentionBreakdown, Order

# BUG-MSO-2026-0451's four category names — reused verbatim, never renamed.
ATTENTION_REVIEW_GATED = "review_gated"
ATTENTION_STRANDED = "stranded"
ATTENTION_DEP_HELD = "dep_held"
ATTENTION_SKIPPED = "skipped"

# PLAN-PLN-MSO-2026-0468 §2 — the exact status list ruled onto "Needs Attention".
STRANDED_STATUSES = frozenset({
    "CONVERGENCE_FAILED", "BLOCKED", "AUTO_SERIALIZE", "ESCALATED",
    "STALLED", "VERIFY_FAILED", "FAILED",
})

_REVIEW_GATED_STATUS = "NAV_REVIEW_PENDING"


class OrderAttention:
    """One order's attention tag — category name + optional human-readable detail."""

    __slots__ = ("category", "reason")

    def __init__(self, category: str, reason: str = "") -> None:
        self.category = category
        self.reason = reason


def read_skip_records(mso: Path) -> Dict[str, Dict[str, Any]]:
    """Return ``{order_id: skip_meta}`` from *mso*'s operator skip list.

    BUG-MSO-2026-0743: a thin, never-raising wrapper over the shared reader
    (``maestro.core.skip_list.read_skipped_orders`` — BUG-MSO-2026-0433's
    schema normalisation lives there and is not re-implemented here) so a
    caller can read the list ONCE and hand the same map to both
    ``classify_orders()`` and ``apply_skip_state()``. Without this the two
    would each open the file per poll cycle, breaking this module's
    no-extra-I/O contract to fix a bug about consistency.
    """
    from maestro.core.skip_list import read_skipped_orders

    try:
        return read_skipped_orders(mso)
    except Exception:
        return {}


def _is_release_gated_without_deps(order: "Order") -> bool:
    """BUG-MSO-2026-0741 candidate test, over an ``Order`` rather than raw
    order JSON. Pure — the index already carries both fields, so this adds no
    read; it exists so the (potentially file-touching) chart lookup runs only
    for a workspace that actually has a candidate.

    ``depends_on`` is ``Optional[list[str]]`` on the model and
    ``aggregator._map_order`` leaves it ``None`` for an order carrying no
    dependencies at all — so ``None`` and ``[]`` mean the same thing here, and
    both are dependency-free.
    """
    from maestro.core.undispatchable import RELEASE_GATED_STATUSES

    status = (getattr(order, "status", "") or "").strip().upper()
    if status not in RELEASE_GATED_STATUSES:
        return False
    return not (getattr(order, "depends_on", None) or [])


def classify_orders(
    mso: Path,
    order_index: Dict[str, "Order"],
    *,
    skipped: Optional[Dict[str, Dict[str, Any]]] = None,
) -> Dict[str, OrderAttention]:
    """Return ``{order_id: OrderAttention}`` for every held/gated order in *mso*.

    *order_index* is the caller's already-built ``{order_id: Order}`` map
    (``aggregator._build_order_index`` — reused, not re-read, so this adds no
    I/O beyond the two small state files below).

    *skipped* is an optional pre-read skip map (``read_skip_records()``), so a
    caller that also needs it for ``apply_skip_state()`` reads the file once.
    Omitted, it is read here exactly as before.

    Precedence when an id (in practice, should not happen — the four sources
    are disjoint by construction) appears in more than one source: skipped is
    applied first, then dep-held, then stranded, then review-gated last — so
    review-gated (the clearest "a human must decide" signal) always wins a
    clash, matching §2's ruling that it is the one bucket whose verb is
    authorisation rather than recovery or self-resolution.
    """
    from maestro.core.dep_holds import read_dep_holds

    tags: Dict[str, OrderAttention] = {}

    skip_records = read_skip_records(mso) if skipped is None else skipped
    for order_id in skip_records:
        tags[order_id] = OrderAttention(ATTENTION_SKIPPED)

    try:
        dep_holds = read_dep_holds(mso)
    except Exception:
        dep_holds = {}
    for order_id, hold in dep_holds.items():
        waiting_on = hold.get("waitingOn") or []
        reason = ", ".join(str(w) for w in waiting_on) if waiting_on else ""
        tags[order_id] = OrderAttention(ATTENTION_DEP_HELD, reason)

    # BUG-MSO-2026-0741: an order held at PROPOSED/HELD with NO dependsOn and
    # no ACTIVE chart node is in no bucket at all today — it is not in
    # dep-holds.json (that file records orders waiting on a dependency, and
    # this one has none), its status is in neither STRANDED_STATUSES nor
    # NAV_REVIEW_PENDING, and nothing in the engine will ever release it. So
    # the Hub showed it as ordinary queued work, indistinguishable from an
    # order about to be picked up.
    #
    # Tagged `dep_held` rather than a fifth category, per this module's own
    # rule above ("keep the four category NAMES, do not invent a fifth"). The
    # bucket is right — the order IS held, waiting for a release — and
    # `attention_reason`, which already exists to carry per-order detail, is
    # what says the release can never come. A dep-holds entry is more specific
    # and keeps precedence.
    #
    # The candidate sweep below is pure (status + depends_on off the already
    # built index, no I/O). `charts/` is read ONLY if a candidate exists, and
    # only once for the whole workspace — so the overwhelmingly common case, a
    # workspace with no dependency-free held orders, still adds no I/O at all.
    undispatchable_candidates = [
        (order_id, order)
        for order_id, order in order_index.items()
        if _is_release_gated_without_deps(order)
        and not (order_id in tags and tags[order_id].category == ATTENTION_DEP_HELD)
    ]
    if undispatchable_candidates:
        from maestro.core.undispatchable import (
            chart_gated_order_ids,
            undispatchable_reason,
        )

        chart_gated = chart_gated_order_ids(mso)
        for order_id, order in undispatchable_candidates:
            reason = undispatchable_reason(
                {"orderId": order_id,
                 "status": order.status,
                 "dependsOn": list(order.depends_on or [])},
                chart_gated_ids=chart_gated,
            )
            if reason:
                tags[order_id] = OrderAttention(ATTENTION_DEP_HELD, reason)

    for order_id, order in order_index.items():
        status = (order.status or "").upper()
        if status in STRANDED_STATUSES:
            # BUG-MSO-2026-0703: a stranded order's `operatorNote` IS the reason
            # a human is being asked to look — the salvage branch, its diff-stat,
            # the ancestry the guard found, and the retry command. Surfacing it
            # here is what lets the Hub show the next step; without it the
            # operator saw a bare CONVERGENCE_FAILED and had to ask a LEAD to
            # read lifecycle.log for them.
            #
            # BUG-MSO-2026-0705 (AC3): when that stall was a role REJECTION, the
            # fleet has a SHARPER reason than the note — its own QA verdict,
            # "rejected by TST: DEF-001 <summary>" — so the headline wins and
            # the Hub shows the verdict rather than an unexplained STALLED chip.
            # Both are mapped onto the Order by aggregator._map_order, so this
            # stays within the module's own no-extra-reads rule. An order nothing
            # rejected has no headline and keeps its 0703 note exactly as before.
            reason = (getattr(order, "rejection_headline", None)
                      or getattr(order, "operator_note", "") or "")
            tags[order_id] = OrderAttention(ATTENTION_STRANDED, reason)

    for order_id, order in order_index.items():
        status = (order.status or "").upper()
        if status == _REVIEW_GATED_STATUS:
            tags[order_id] = OrderAttention(ATTENTION_REVIEW_GATED)

    return tags


def apply_attention(orders, tags: Dict[str, OrderAttention]) -> None:
    """Stamp ``order.attention`` / ``order.attention_reason`` in place from *tags*.

    *orders* is any iterable of ``Order`` — callers pass both the order index's
    values and the separately-built live-queue ``orders`` list (aggregator.py
    builds each independently), so tagging is a single small pass over
    whichever Order objects the caller already has, not a second classification.
    """
    for order in orders:
        tag = tags.get(order.id)
        if tag is None:
            continue
        order.attention = tag.category
        order.attention_reason = tag.reason or None


_SKIP_REASON_KEYS = ("reason", "note", "why", "comment")


def skip_reason_from_meta(meta: Any) -> Optional[str]:
    """Best-effort human-readable reason out of one skip-list entry's metadata.

    The skip list's value slot is operator-authored and shape-loose
    (BUG-MSO-2026-0433 normalises it to a dict, but its KEYS are not a schema),
    so this looks for the conventional ones ``mso order skip --reason`` writes
    and degrades to ``None`` rather than guessing. A missing reason must never
    make an order look un-skipped — ``is_skipped`` is the fact, the reason is
    decoration.
    """
    if not isinstance(meta, dict):
        return None
    for key in _SKIP_REASON_KEYS:
        value = meta.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return None


def apply_skip_state(orders: Iterable["Order"], skipped: Dict[str, Dict[str, Any]]) -> None:
    """Stamp ``order.is_skipped`` / ``order.skip_reason`` in place from *skipped*.

    BUG-MSO-2026-0743: the skip list is the ONLY source consulted here — never
    ``order.attention``, which ``classify_orders()`` may legitimately have
    overwritten with ``stranded`` / ``dep_held`` / ``review_gated`` for the very
    same order. Stamps ``False`` (not ``None``) for an order that is absent, so
    a consumer can trust the field rather than treating "missing" as unknown.

    Mirrors ``apply_attention()``'s contract deliberately: *orders* is any
    iterable of ``Order``, and the aggregator makes one pass over each of its
    two independently-built collections.
    """
    for order in orders:
        meta = skipped.get(order.id)
        if meta is None:
            order.is_skipped = False
            order.skip_reason = None
            continue
        order.is_skipped = True
        order.skip_reason = skip_reason_from_meta(meta)


def breakdown_from_tags(tags: Dict[str, OrderAttention]) -> "AttentionBreakdown":
    """Roll a ``classify_orders()`` result up into a workspace-level ``AttentionBreakdown``."""
    from maestro.hub.models import AttentionBreakdown

    counts = {
        ATTENTION_REVIEW_GATED: 0,
        ATTENTION_STRANDED: 0,
        ATTENTION_DEP_HELD: 0,
        ATTENTION_SKIPPED: 0,
    }
    for tag in tags.values():
        if tag.category in counts:
            counts[tag.category] += 1
    return AttentionBreakdown(
        review_gated=counts[ATTENTION_REVIEW_GATED],
        stranded=counts[ATTENTION_STRANDED],
        dep_held=counts[ATTENTION_DEP_HELD],
        skipped=counts[ATTENTION_SKIPPED],
        needs_you=counts[ATTENTION_REVIEW_GATED] + counts[ATTENTION_STRANDED],
    )


def compute_attention(mso: Path, order_index: Dict[str, "Order"]) -> "AttentionBreakdown":
    """Convenience wrapper: classify + roll up in one call (no per-order tags returned)."""
    return breakdown_from_tags(classify_orders(mso, order_index))
