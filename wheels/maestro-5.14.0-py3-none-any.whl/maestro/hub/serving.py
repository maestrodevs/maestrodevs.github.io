# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""A Hub that stops serving must never outlive its listener (BUG-MSO-2026-0751).

The zombie
----------
On v5.13.0 the Hub stopped serving four times in ~9 hours while its process
stayed alive. Every capture showed the same two lines::

    OSError: [WinError 64] The specified network name is no longer available
    Accept failed on a socket ... laddr=('127.0.0.1', 3847)

The cause is in CPython, not in Maestro's launch path. On Windows uvicorn runs
on ``asyncio.ProactorEventLoop``, whose accept loop
(``asyncio/proactor_events.py`` ``_start_serving.loop``) treats ANY ``OSError``
from ``accept`` as fatal: it logs "Accept failed on a socket" and **closes the
listening socket**. ``WinError 64`` (``ERROR_NETNAME_DELETED``) is what
``AcceptEx`` reports when a CLIENT resets its connection before the accept
completes, so a browser tab closing mid-request is enough to take the whole
Hub off the network. The event loop itself keeps running, so the process
lives on with nothing listening.

Reproduced by this order's driver (8 threads of RST-aborted connects against
an isolated Hub on a high port): the listener was lost within ~7.5 s under
all three launch variants the order named — the v5.12.2 direct launch, the
supervisor with a bare ``Popen`` and the shipped supervisor with
``popen_hidden`` — so the launch path is not the cause.

Why not just use the selector loop
-----------------------------------
The selector loop does not close its listener on an accept error, and it
survived 84 000 aborted connections in the same driver — then died with
``ValueError: too many file descriptors in select()``. Windows ``select()`` is
capped at 512 sockets, so swapping loops trades a zombie for a crash under
load. The proactor loop is kept and its accept is hardened instead.

Three layers, because they fail in different ways
-------------------------------------------------
1. :func:`harden_proactor_accept` — the root-cause fix. A client-abort error
   from one ``AcceptEx`` re-arms the accept on the same listener instead of
   surfacing to CPython's loop, which would close it.
2. :class:`ServingGuard` — the self-heal. If the accept loop dies anyway
   (an error class not recognised above, a future CPython change), the loop's
   exception handler sees "Accept failed on a socket" and the Hub shuts down
   with :data:`EXIT_STOPPED_SERVING`; a periodic self-probe of its own port
   catches a dead listener no handler reported. Either way the process exits
   non-zero, so the supervisor records the death and ``mso hub start`` works.
3. The supervisor's own port watch (``died_record.supervise(probe_port=...)``)
   — the backstop for a Hub too wedged to run layer 2.
"""

from __future__ import annotations

import asyncio
import os
import socket
import sys
import threading
import time
from datetime import datetime, timezone
from typing import Callable, Optional

from maestro.core.died_record import EXIT_STOPPED_SERVING

__all__ = [
    "ACCEPT_FAILED_MESSAGE",
    "CLIENT_ABORT_WINERRORS",
    "EXIT_STOPPED_SERVING",
    "HUB_LOOP_SPEC",
    "HubStoppedServing",
    "ServingGuard",
    "harden_proactor_accept",
    "hub_loop_factory",
    "install_guard",
    "is_client_abort",
    "winerror_of",
    "port_accepts",
]

#: The exact message CPython's proactor accept loop passes to the loop's
#: exception handler immediately before it closes the listening socket.
ACCEPT_FAILED_MESSAGE = "Accept failed on a socket"

#: Windows error codes an ``AcceptEx`` completes with when the CLIENT went away
#: before the accept finished. None of them says anything about the listener.
#: 64 ERROR_NETNAME_DELETED, 1236 ERROR_CONNECTION_ABORTED,
#: 10053 WSAECONNABORTED, 10054 WSAECONNRESET.
#: ERROR_OPERATION_ABORTED (995) is deliberately absent: that is what an accept
#: completes with when the LISTENER was closed, which must still propagate.
CLIENT_ABORT_WINERRORS = frozenset({64, 1236, 10053, 10054})

SELF_PROBE_INTERVAL_SECONDS = 15.0
SELF_PROBE_FAILURES_TO_TRIP = 3
SELF_PROBE_TIMEOUT_SECONDS = 5.0
#: How long a tripped Hub gets to shut down gracefully before the guard ends
#: the process itself. A zombie that cannot even shut down must still exit.
SHUTDOWN_GRACE_SECONDS = 15.0

#: Import string handed to ``uvicorn.Config(loop=...)``.
HUB_LOOP_SPEC = "maestro.hub.serving:hub_loop_factory"


class HubStoppedServing(RuntimeError):
    """Recorded as the exit-record error when the guard shuts the Hub down."""


def _stamp() -> str:
    return datetime.now(timezone.utc).isoformat()


def winerror_of(exc: BaseException) -> Optional[int]:
    """The Windows error code carried by *exc*, or ``None``.

    ``OSError.winerror`` is only populated on Windows. An ``OSError`` built
    with a fourth ``winerror`` argument elsewhere (as this module's tests do,
    so the accept hardening is exercised on Linux CI too) keeps that code only
    in ``args[3]``. A real POSIX socket error never carries a fourth argument,
    so the fallback cannot misclassify anything on a non-Windows host.
    """
    code = getattr(exc, "winerror", None)
    if code is not None:
        return code
    args = getattr(exc, "args", ())
    if isinstance(exc, OSError) and len(args) >= 4 and isinstance(args[3], int):
        return args[3]
    return None


def is_client_abort(exc: BaseException) -> bool:
    """Is *exc* a client going away mid-accept, rather than a listener fault?"""
    if isinstance(exc, (ConnectionResetError, ConnectionAbortedError)):
        return True
    return isinstance(exc, OSError) and winerror_of(exc) in CLIENT_ABORT_WINERRORS


def is_accept_abort_noise(context: dict) -> bool:
    """Is this loop-exception *context* the leftover of a client abort we re-armed?

    CPython wraps every ``AcceptEx`` in an ``accept_coro`` task that only
    handles cancellation, so each client abort also leaves a task whose
    ``OSError`` nobody retrieves, and asyncio logs a full traceback for it at
    GC. Under this order's reproduction driver that was 84 893 tracebacks
    (62 MB) in two minutes — enough to fill the supervisor capture log on its
    own. Only that exact shape is dropped: an unretrieved client-abort error
    from an accept task. Everything else is still logged.
    """
    if context.get("message") != "Task exception was never retrieved":
        return False
    exc = context.get("exception")
    return exc is not None and is_client_abort(exc) and "accept_coro" in repr(context.get("future"))


def port_accepts(port: int, timeout: float = SELF_PROBE_TIMEOUT_SECONDS) -> bool:
    """Does something accept a TCP connection on 127.0.0.1:*port*?

    A bare connect, not an HTTP request, on purpose: the failure this guards
    against is a CLOSED listener, which refuses at once, while a busy Hub
    still completes a connect from its backlog. An HTTP probe would read a
    slow request under load as a death and restart a healthy Hub.
    """
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=timeout):
            return True
    except OSError:
        return False


# ---------------------------------------------------------------------------
# Layer 1 — keep a client abort from closing the listener
# ---------------------------------------------------------------------------

def harden_proactor_accept(loop: asyncio.AbstractEventLoop) -> bool:
    """Wrap *loop*'s IOCP ``accept`` so a client abort re-arms the accept.

    CPython's accept loop only ever sees the future this returns. When the
    underlying ``AcceptEx`` fails with a client-abort error while the listener
    is still open, a fresh accept is started on the same listener and its
    outcome is forwarded instead — the loop never sees the error, so it never
    closes the socket. Every other outcome (a real connection, a genuine
    listener error, cancellation at server shutdown) is forwarded unchanged.

    Returns ``True`` when the wrapper was installed, ``False`` when *loop* has
    no proactor to wrap (a non-Windows loop) or is already hardened.
    """
    proactor = getattr(loop, "_proactor", None)
    real_accept = getattr(proactor, "accept", None)
    if real_accept is None or getattr(real_accept, "_maestro_hardened", False):
        return False

    def accept(listener):
        # The first attempt is called straight through, so a synchronous
        # failure (e.g. the listener is already closed) reaches CPython's loop
        # exactly as it would without this wrapper.
        first = real_accept(listener)
        outer = loop.create_future()
        current = [first]

        def cancel_inner(fut) -> None:
            if fut.cancelled():
                current[0].cancel()

        def forward(inner) -> None:
            if outer.done():
                return
            if inner.cancelled():
                outer.cancel()
                return
            exc = inner.exception()
            if exc is None:
                outer.set_result(inner.result())
                return
            if is_client_abort(exc) and listener.fileno() != -1:
                try:
                    retry = real_accept(listener)
                except BaseException as again:  # noqa: BLE001 — forwarded, never swallowed
                    outer.set_exception(again)
                    return
                current[0] = retry
                retry.add_done_callback(forward)
                return
            outer.set_exception(exc)

        outer.add_done_callback(cancel_inner)
        first.add_done_callback(forward)
        return outer

    accept._maestro_hardened = True  # type: ignore[attr-defined]
    proactor.accept = accept
    return True


# ---------------------------------------------------------------------------
# Layer 2 — a Hub that stops serving exits so it can be restarted
# ---------------------------------------------------------------------------

class ServingGuard:
    """Trips when the Hub's listener is dead, and makes the process exit.

    Every collaborator is injectable so the trip path can be driven without
    sockets, threads or real timing: *probe* answers "is my port accepting?",
    *on_trip* runs once with the reason (``run_hub`` writes the exit record
    there), *exit_process* ends the process after *grace_seconds*, and *log*
    writes one line to ``hub.log``. Pass ``grace_seconds=None`` to disable the
    exit (the caller then owns shutdown).
    """

    def __init__(
        self,
        port: int,
        *,
        probe: Optional[Callable[[], bool]] = None,
        on_trip: Optional[Callable[[str], None]] = None,
        exit_process: Callable[[int], None] = os._exit,
        log: Optional[Callable[[str], None]] = None,
        interval_seconds: float = SELF_PROBE_INTERVAL_SECONDS,
        failures_to_trip: int = SELF_PROBE_FAILURES_TO_TRIP,
        grace_seconds: Optional[float] = SHUTDOWN_GRACE_SECONDS,
    ) -> None:
        self.port = port
        self._probe = probe or (lambda: port_accepts(port))
        self.on_trip = on_trip
        self._exit_process = exit_process
        self._log = log or (lambda line: None)
        self.interval_seconds = interval_seconds
        self.failures_to_trip = max(1, int(failures_to_trip))
        self.grace_seconds = grace_seconds

        self.tripped_reason: Optional[str] = None
        self.tripped_at: Optional[str] = None
        self.served_once = False
        self.consecutive_failures = 0

        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._backstop: Optional[threading.Timer] = None

    @property
    def tripped(self) -> bool:
        return self.tripped_reason is not None

    # -- signals ------------------------------------------------------------

    def handle_loop_exception(self, loop: asyncio.AbstractEventLoop, context: dict) -> None:
        """Event-loop exception handler: log as usual, trip on a dead accept loop."""
        try:
            loop.default_exception_handler(context)
        except Exception:  # noqa: BLE001 — logging must never stop the trip below
            pass
        if context.get("message") == ACCEPT_FAILED_MESSAGE:
            exc = context.get("exception")
            detail = f"{type(exc).__name__}: {exc}" if exc is not None else "no exception attached"
            self.trip(
                f"asyncio accept loop died on port {self.port} ({detail}) — "
                "the listening socket was closed while the process kept running"
            )

    def check_once(self) -> bool:
        """One self-probe. Returns whether the port accepted.

        Never trips before the port has accepted at least once: a Hub still
        binding (or one whose bind failed, which uvicorn already exits for)
        is not a Hub that stopped serving.
        """
        try:
            ok = bool(self._probe())
        except Exception:  # noqa: BLE001 — a probe that raises did not see a listener
            ok = False
        if ok:
            self.served_once = True
            self.consecutive_failures = 0
            return True
        if not self.served_once:
            return False
        self.consecutive_failures += 1
        if self.consecutive_failures >= self.failures_to_trip:
            self.trip(
                f"self-probe: port {self.port} refused {self.consecutive_failures} consecutive "
                f"connections after it had been serving — the listener is gone"
            )
        return False

    # -- the trip -----------------------------------------------------------

    def trip(self, reason: str) -> None:
        """Record why, request shutdown, and arm the last-resort exit. Idempotent."""
        with self._lock:
            if self.tripped_reason is not None:
                return
            self.tripped_reason = reason
            self.tripped_at = _stamp()
        self._log(
            f"=== [{self.tripped_at}] Hub daemon STOPPED SERVING pid={os.getpid()} "
            f"port={self.port} — exiting with code {EXIT_STOPPED_SERVING} so it can be "
            f"restarted (BUG-MSO-2026-0751) ===\n{reason}"
        )
        self._stop.set()
        if self.on_trip is not None:
            try:
                self.on_trip(reason)
            except Exception:  # noqa: BLE001 — the backstop below still ends the process
                pass
        if self.grace_seconds is not None:
            timer = threading.Timer(self.grace_seconds, self._force_exit)
            timer.daemon = True
            self._backstop = timer
            timer.start()

    def _force_exit(self) -> None:
        self._log(
            f"=== [{_stamp()}] Hub daemon did not shut down within {self.grace_seconds:.0f}s "
            f"of stopping serving — forcing exit code {EXIT_STOPPED_SERVING} ==="
        )
        self._exit_process(EXIT_STOPPED_SERVING)

    # -- lifecycle ----------------------------------------------------------

    def start(self) -> None:
        """Run :meth:`check_once` every *interval_seconds* on a daemon thread."""
        if self._thread is not None:
            return

        def run() -> None:
            while not self._stop.wait(self.interval_seconds):
                self.check_once()

        self._thread = threading.Thread(target=run, name="hub-serving-guard", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        """Stop probing and disarm the last-resort exit (the Hub is exiting anyway)."""
        self._stop.set()
        if self._backstop is not None:
            self._backstop.cancel()


# ---------------------------------------------------------------------------
# Event loop factory handed to uvicorn
# ---------------------------------------------------------------------------

_ACTIVE_GUARD: Optional[ServingGuard] = None


def install_guard(guard: Optional[ServingGuard]) -> None:
    """Make *guard* the exception handler of the loop :func:`hub_loop_factory` builds."""
    global _ACTIVE_GUARD
    _ACTIVE_GUARD = guard


def hub_loop_factory() -> asyncio.AbstractEventLoop:
    """The Hub's event loop: uvicorn's own choice, with layers 1 and 2 attached.

    On Windows that is the proactor loop with its accept hardened. Elsewhere it
    is whatever uvicorn's ``auto`` factory picks (uvloop when installed), so a
    Linux/Docker Hub runs exactly the loop it ran before.
    """
    if sys.platform == "win32":
        loop: asyncio.AbstractEventLoop = asyncio.ProactorEventLoop()
        harden_proactor_accept(loop)
    else:
        from uvicorn.loops.auto import auto_loop_factory

        loop = auto_loop_factory(use_subprocess=False)()
    loop.set_exception_handler(hub_exception_handler)
    return loop


def hub_exception_handler(loop: asyncio.AbstractEventLoop, context: dict) -> None:
    """Drop re-armed accept noise, then hand everything else to the active guard."""
    if is_accept_abort_noise(context):
        return
    guard = _ACTIVE_GUARD
    if guard is not None:
        guard.handle_loop_exception(loop, context)
    else:
        loop.default_exception_handler(context)
