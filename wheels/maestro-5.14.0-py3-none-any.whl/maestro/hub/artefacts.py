# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Order-location + artefact-discovery core (FTR-MSO-2026-0492).

Mirrors ``maestro/hub/attention.py``'s shape and docstring discipline for a
Hub-callable module serving N registered workspaces from one process:
explicit ``mso: Path`` throughout, no ``find_workspace()``, no CWD, no
globals.

Discovery rules — verified against the live MSO workspace, not invented
(PLAN-FTR-MSO-2026-0492 §3):

  - plan:          plans/PLAN-{ORDER-ID}.md, exact filename
  - handoff:       handoffs/{ORDER-ID}/*.md, every file in that dir
  - qa/security/
    investigation/
    voyage/verify:  reports/{kind}/, filename STEM CONTAINS the order id
                    (case-insensitive) — mirrors fleet_runner.
                    sec_artefact_present's `oid in report.stem.upper()`
                    rule; both `QA-{id}.md` and `{id}.md` naming forms are
                    in live use, so a prefix-only match would miss half.
                    A report subdirectory whose NAME contains the order id
                    (e.g. an INV-type order's own folder) is recursed ONE
                    level.
  - order:         wherever the order JSON currently lives (always present
                    by construction — find_order_file() is how the caller
                    located the workspace in the first place).

``reports/compliance/`` and ``reports/usage/`` are deliberately excluded —
they are timestamp-named workspace-level artefacts, never order-scoped.

FTR-MSO-2026-0721 / PLAN-FTR-MSO-2026-0700 §7.2 added ``verify``.
BUG-MSO-2026-0506 persists the FULL stdout+stderr of a failed verify gate to
``reports/verify/VERIFY-{ORDER-ID}-{ts}.log`` and names that path in the
``VERIFY_FAILED`` lifecycle event — making it the single most useful piece of
evidence a stuck order has. It was undiscoverable from the Hub: ``verify`` was
absent from the report kinds AND ``.log`` was absent from the accepted
extensions, so the panel could name a file the operator then had to open in a
terminal. Both are fixed here. The ``.log`` extension is granted to the
``verify`` kind ONLY (see :data:`_REPORT_EXTENSIONS`) rather than to every
report dir: nothing else writes ``.log`` files under ``reports/``, and a
narrower rule cannot start serving something later that nobody reviewed.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, List, Optional, Sequence, Tuple

if TYPE_CHECKING:
    from maestro.hub.models import ArtefactContent, ArtefactRef

# Bounded read cap (§5.5) — an unbounded read of an arbitrary on-disk file
# into a JSON response is a trivial memory amplification against a
# single-worker backend.
MAX_ARTEFACT_BYTES = 512 * 1024

_REPORT_KINDS = ("qa", "security", "investigation", "voyage", "verify")

#: Accepted file extensions per report kind (FTR-MSO-2026-0721). Kinds absent
#: from this map take :data:`_DEFAULT_REPORT_EXTENSIONS`.
_DEFAULT_REPORT_EXTENSIONS = (".md", ".json")
_REPORT_EXTENSIONS = {
    # BUG-MSO-2026-0506 writes plain-text logs, never markdown.
    "verify": (".log", ".md", ".json"),
}


def _accepted_extensions(kind: str):
    return _REPORT_EXTENSIONS.get(kind, _DEFAULT_REPORT_EXTENSIONS)


class ArtefactNotFound(Exception):
    """*key* does not match any artefact discovery currently finds for *order_id*."""

    def __init__(self, order_id: str, key: str) -> None:
        self.order_id = order_id
        self.key = key
        super().__init__(f"Artefact {key!r} not found for order {order_id!r}")


def _iso(mtime: float) -> str:
    return datetime.fromtimestamp(mtime, tz=timezone.utc).isoformat()


def find_order_file(mso: Path, order_id: str) -> Optional[Path]:
    """Locate *order_id*'s JSON wherever it currently lives.

    Probes, in order: ``orders/complete/``, ``orders/failed/``, then every
    queue dir (``queues/*/`` and the ``queues/requests/*/`` tier). Same
    coverage as ``maestro.core.order_retry.retry_order``'s own resolution —
    lifted, not re-derived, so retry and inspection can never disagree about
    where an order is.
    """
    for sub in ("complete", "failed"):
        candidate = mso / "orders" / sub / f"{order_id}.json"
        if candidate.exists():
            return candidate

    queues_dir = mso / "queues"
    if queues_dir.exists():
        for jf in list(queues_dir.glob("*/*.json")) + list(queues_dir.glob("*/*/*.json")):
            try:
                d = json.loads(jf.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            if (d.get("orderId") or d.get("id") or jf.stem) == order_id:
                return jf
    return None


def iter_order_files(mso: Path) -> List[Path]:
    """Every order JSON :func:`find_order_file` can resolve, in its precedence.

    ``orders/complete/``, ``orders/failed/``, then ``queues/*/`` and the
    ``queues/*/*/`` tier — the same directories, in the same order, so a caller
    that keeps the FIRST file per order id shadows a stale queue copy of an
    archived order exactly as :func:`find_order_file` does. Added for
    :mod:`maestro.reports.ac_reader` (FTR-MSO-2026-0733), which lists AC records
    workspace-wide and must not carry a walker of its own (plan §4).
    """
    out: List[Path] = []
    for sub in ("complete", "failed"):
        d = mso / "orders" / sub
        if d.is_dir():
            out.extend(sorted(d.glob("*.json")))
    queues_dir = mso / "queues"
    if queues_dir.is_dir():
        out.extend(sorted(queues_dir.glob("*/*.json")))
        out.extend(sorted(queues_dir.glob("*/*/*.json")))
    return out


def iter_voyage_files(mso: Path) -> List[Tuple[str, Path]]:
    """``(location, path)`` for every voyage manifest, ``active`` before ``complete``.

    Added for :mod:`maestro.reports.voyage_reader` (FTR-MSO-2026-0737), which
    composes the voyage report on read and — like the AC reader before it —
    must not carry a directory walker of its own (plan §4). The precedence is
    ``aggregator.aggregate_usage_for_voyage``'s own probe order, so a stale
    active copy of an archived voyage resolves identically in both.
    """
    out: List[Tuple[str, Path]] = []
    for location in ("active", "complete"):
        d = mso / "voyages" / location
        if d.is_dir():
            out.extend((location, p) for p in sorted(d.glob("*.json")) if p.is_file())
    return out


def _ref(kind: str, key: str, name: str, path: Path) -> Tuple["ArtefactRef", Path]:
    from maestro.hub.models import ArtefactRef

    st = path.stat()
    return ArtefactRef(key=key, kind=kind, name=name, size=st.st_size,
                        modified=_iso(st.st_mtime)), path


def _discover(mso: Path, order_id: str) -> List[Tuple["ArtefactRef", Path]]:
    """Discovery, paired with the on-disk Path each ref resolves to.

    The Path is kept internal (never serialised) — :func:`read_artefact`
    re-runs THIS function and matches the client-supplied key against it, so
    a client can never name a file discovery did not itself find.
    """
    pairs: List[Tuple["ArtefactRef", Path]] = []

    order_file = find_order_file(mso, order_id)
    if order_file is not None:
        pairs.append(_ref("order", f"order:{order_file.name}", order_file.name, order_file))

    plan_file = mso / "plans" / f"PLAN-{order_id}.md"
    if plan_file.is_file():
        pairs.append(_ref("plan", f"plan:{plan_file.name}", plan_file.name, plan_file))

    handoff_dir = mso / "handoffs" / order_id
    if handoff_dir.is_dir():
        for f in sorted(handoff_dir.glob("*.md")):
            pairs.append(_ref("handoff", f"handoff:{f.name}", f.name, f))

    for kind, rel_name, path in discover_report_paths(mso, order_id):
        pairs.append(_ref(kind, f"{kind}:{rel_name}", rel_name, path))

    return pairs


def discover_report_paths(
    mso: Path, order_id: str, kinds: Optional[Sequence[str]] = None,
) -> List[Tuple[str, str, Path]]:
    """The report-discovery rule, as ``(kind, display_name, path)`` triples.

    Factored out of :func:`_discover` (FTR-MSO-2026-0728) so there is exactly
    ONE implementation of "which files under ``reports/<kind>/`` belong to this
    order" — the rule documented in this module's header — and two callers with
    different needs can share it:

    * :func:`_discover` wraps each triple in an :class:`~maestro.hub.models.
      ArtefactRef` for the Hub's manifest routes;
    * :mod:`maestro.reports` needs the ``Path`` and nothing else, and must stay
      free of any web-framework import (PLAN-PLN-MSO-2026-0726 §5 A1) — which
      building an ``ArtefactRef`` would defeat, since that is a Pydantic model.

    Ordering, extension filter and one-level subdirectory recursion are
    byte-identical to the pre-refactor loop; ``tests/test_hub_artefacts.py``
    pins the manifest that depends on it.
    """
    out: List[Tuple[str, str, Path]] = []
    oid = order_id.upper()
    wanted = tuple(kinds) if kinds is not None else _REPORT_KINDS

    for kind in wanted:
        report_dir = mso / "reports" / kind
        if not report_dir.is_dir():
            continue
        accepted = _accepted_extensions(kind)
        for entry in sorted(report_dir.iterdir()):
            if entry.is_file():
                if entry.suffix.lower() not in accepted:
                    continue
                if oid in entry.stem.upper():
                    out.append((kind, entry.name, entry))
            elif entry.is_dir() and oid in entry.name.upper():
                # One-level recursion into a matching report subdirectory
                # (e.g. reports/investigation/INV-MSO-2026-0417/*.md).
                for f in sorted(entry.iterdir()):
                    if f.is_file() and f.suffix.lower() in accepted:
                        out.append((kind, f"{entry.name}/{f.name}", f))

    return out


def iter_report_paths(mso: Path, kind: str) -> List[Path]:
    """Every report file directly under ``reports/<kind>/``, sorted by name.

    The workspace-level counterpart to :func:`discover_report_paths`'s
    order-scoped match, for a surface that lists a whole report family rather
    than one order's artefacts (FTR-MSO-2026-0728). Kept here, beside the
    order-scoped rule, so this module stays the only place that knows how
    ``reports/<kind>/`` is laid out — the alternative is a second filesystem
    walker that drifts from the first.

    Subdirectories are NOT recursed into: a listing is a listing of the family,
    and the one-level recursion in :func:`discover_report_paths` exists to
    attach an INV-type order's own folder to *that order*, which is a different
    question. ``.log`` files and the ``charters/`` subdirectory the live MSO
    ``reports/qa/`` carries are excluded by the same extension filter used
    above.
    """
    report_dir = mso / "reports" / kind
    if not report_dir.is_dir():
        return []
    return [p for p in sorted(report_dir.iterdir())
            if p.is_file() and p.suffix.lower() in (".md", ".json")]


def discover_artefacts(mso: Path, order_id: str) -> List["ArtefactRef"]:
    """Return every artefact's manifest entry (no content) for *order_id*."""
    return [ref for ref, _path in _discover(mso, order_id)]


def read_artefact(mso: Path, order_id: str, key: str) -> "ArtefactContent":
    """Read one artefact's content, bounded at :data:`MAX_ARTEFACT_BYTES`.

    *key* is validated by re-running discovery and matching, never by
    joining a client-supplied string onto a path — a forged key (path
    traversal, an absolute path, a real file outside the manifest) matches
    nothing and raises :class:`ArtefactNotFound`.
    """
    from maestro.hub.models import ArtefactContent

    match = next((pair for pair in _discover(mso, order_id) if pair[0].key == key), None)
    if match is None:
        raise ArtefactNotFound(order_id, key)
    ref, path = match

    try:
        raw = path.read_bytes()
    except OSError as exc:
        raise ArtefactNotFound(order_id, key) from exc

    truncated = len(raw) > MAX_ARTEFACT_BYTES
    body = raw[:MAX_ARTEFACT_BYTES] if truncated else raw
    return ArtefactContent(
        key=ref.key, kind=ref.kind, name=ref.name,
        content=body.decode("utf-8", errors="replace"),
        truncated=truncated, size=len(raw),
    )
