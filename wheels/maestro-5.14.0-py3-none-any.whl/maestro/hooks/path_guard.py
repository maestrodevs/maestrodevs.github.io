"""
Worktree path-confinement guard for crew file mutations (BUG-MSO-2026-0282).

The branch guard (``branch_guard.py``) confines crew *git/gh* mutations to the
order's voyage branch, but it never sees plain ``Edit``/``Write``/``NotebookEdit``
or ``Bash`` file-writes whose target PATH lands in a different working tree. A
crew that resolves an absolute path into the main checkout (or ``cd``'s there)
could mutate files in the wrong tree — observed in FTR-MSO-2026-0281, where a
crew left 722 lines of uncommitted edits in the main repo working tree.

This guard denies file-mutating tool calls whose resolved target lies in the
**danger zone**: under the main repo root but OUTSIDE the crew's own worktree
(i.e. the main checkout or a sibling voyage worktree). Scratch writes to
unrelated locations (``/tmp``, ``$TEMP``, …) are deliberately NOT blocked — only
cross-tree contamination of the same repo is.

Relative targets are resolved against the tool call's effective working
directory (the hook ``cwd``) — NOT assumed to be the worktree — so a crew that
``cd``s into the main checkout and then writes a relative path is still caught.

It only acts in crew context (``MAESTRO_REPO_PATH`` set) and is bypassable via
``MAESTRO_PATH_GUARD_BYPASS=1`` (or ``MAESTRO_BRANCH_GUARD_BYPASS=1``) for LEAD
manual-recovery sessions. Fail-open: any path-resolution uncertainty allows the
operation (worktrees remain the primary isolation layer).

FTR-MSO-2026-0368 — split artefact/product topology (solo/shared mode)
======================================================================
In solo/shared mode the crew's deliverables (plans, handoffs, reports, prompts,
usage) live in a SEPARATE artefact repo (``MAESTRO_ARTEFACT_ROOT``) while
``MAESTRO_REPO_PATH`` still points at the product worktree. The pure
product-confinement denylist above would either wrongly deny those artefact
writes (the worktree lives under the artefact repo's ``.mso/worktrees`` tree, so
the old ``_main_repo_root`` heuristic resolves the artefact repo as "main" and
denies everything outside the worktree) or provide no role/runtime discipline.

So in solo/shared mode this guard adds a ROLE-SCOPED ALLOWLIST for writes landing
inside the artefact repo:

* the crew's own worktree (``MAESTRO_REPO_PATH``) — always allowed (product work);
* the crew's own runtime dir ``crews/crew{N}/`` — always allowed (``progress.md``);
* the durable-plane dirs appropriate to the crew's role (PLN→plans, TST→reports/qa,
  SEC→reports/security, DOC→docs) plus the shared durable dirs every role writes
  (handoffs, usage, prompts/complete) — allowed;
* everything else inside the artefact repo — the runtime plane
  (logs/state/temp/bridge/worktrees of OTHER crews) and cross-role durable dirs
  (a PLN write into reports/security, …) — DENIED.

Embedded mode (artefact root == workspace) is byte-identical to the pre-0368
behaviour: the artefact allowlist never engages and only the product-confinement
denylist runs.

BUG-MSO-2026-0465 — own-worktree .mso mirror
=============================================
Independent of embedded/solo mode: the product repo commits ``.mso/`` artefacts
to every branch, so every crew worktree checkout carries its OWN nested
``.mso/`` mirror. Before either rule above runs, a target inside
``<worktree>/.mso/`` that is not the true artefact root (``MAESTRO_ARTEFACT_ROOT``)
is denied outright — otherwise the "own worktree, always allow (product work)"
exemption below would silently accept a misdirected relative artefact write
(e.g. a SEC report written to ``.mso/reports/security/...`` resolved against the
crew's cwd) and it would be discarded when the worktree is pruned.

BUG-MSO-2026-0470 — solo-mode detection had its own MAESTRO_DIR fail-open
==========================================================================
The FTR-0368 allowlist above only engages when ``_is_solo_mode()`` returns
True. That check used to call ``maestro.workspace.get_artefact_mode()`` with
no argument — resolving the workspace via ``MAESTRO_DIR`` then a walk-up from
``cwd``, entirely independent of the ``art_mso`` this module already resolved
from ``MAESTRO_ARTEFACT_ROOT``. In the normal FTR-MSO-2026-0364 topology (crew
worktree nested inside the artefact repo's own ``.mso/worktrees/``), when
``MAESTRO_DIR`` is absent from the hook's env and ``cwd`` has no ancestor
``.mso``, that resolution silently reports "embedded" — the allowlist never
engages, and a sanctioned SEC report/handoff write gets caught by the plain
BUG-0282 product-confinement fallback instead (it resolves inside
``_main_repo_root`` — which recognises the ``.mso/worktrees`` segment and
lands on the artefact repo itself — but outside the crew's own worktree).
``_is_solo_mode()`` now takes ``art_mso`` and reads that root's own
``config/workspace.json`` directly, with no env/cwd resolution of its own.

BUG-MSO-2026-0614 — installed package / site-packages confinement
===================================================================
Every guard above confines a crew to a git working tree of the SAME repo —
none of them ever considered the Python environment Maestro itself runs
from. Twice now (the 2026-08-17 "Shadowing" incident in CLAUDE.md, then this
bug, five days later) a crew wrote scratch output — test logs, repro
bundles — to a relative or unexpectedly-resolved path that landed inside
``site-packages/maestro/``, overwriting the installed package with debris and
taking the whole fleet down: every subsequent crew launch spawns a fresh
``python crew.py`` process that needs to import ``maestro`` from disk, and a
shadowed/emptied package directory makes that import fail immediately.

``check_environment_confinement()`` denies any crew file mutation whose
target resolves (via the same ``Path.resolve()`` real-path resolution used
throughout this module — so a relative path, a symlink, or a ``..``
traversal cannot evade it) inside the INSTALLED maestro package directory or
the active Python environment's site-packages (resolved via ``sysconfig``,
not a guessed parent-directory name). This is independent of, and evaluated
before, the worktree-membership exemption below — the installed package is
never a legitimate write target for a crew, regardless of what else is true
about the resolved path.

BUG-TST-0614-A — protected roots must never be resolved via a live import
===========================================================================
The first cut of ``_protected_environment_roots()`` computed "the installed
maestro package directory" by doing a live ``import maestro`` inside the hook
subprocess itself and reading ``maestro.__file__``. That subprocess runs as
``python -m maestro.hooks.pretool`` (``.claude/settings.json``) with
``cwd`` == the crew's own worktree (``maestro/core/crew.py``'s
``start_crew_process`` passes ``cwd=str(work_dir)``; Claude Code hook
subprocesses inherit it), and Python's ``-m`` puts ``''`` (cwd) at
``sys.path[0]``. Because this repository is Maestro's own dogfood workspace,
every crew worktree already contains its OWN ``maestro/`` product-code
directory — so that import resolved to the crew's own in-progress copy, not
the real installed package, and the guard denied every legitimate
``maestro/**`` edit unconditionally (TST reproduced this three ways: a
cwd-mimicking probe, an in-process ``pretool.main()`` call, and the real
``python -m maestro.hooks.pretool`` subprocess — see
``.mso/reports/qa/QA-BUG-MSO-2026-0614.md``, defect BUG-TST-0614-A).

The fix: both ``_protected_environment_roots()`` and
``_protected_environment_temp_exemptions()`` now derive the installed
package location by joining ``sysconfig.get_paths()``'s ``purelib``/
``platlib`` (plus any ``sys.path`` entry literally named ``site-packages``/
``dist-packages``) with ``"maestro"`` — the same environment-configuration
values already used, unconditionally, for the plain site-packages roots.
Neither function imports ``maestro`` anywhere. ``sysconfig``/``sys.path``
describe the Python environment's configuration and are independent of the
calling process's ``cwd``, so a crew's own worktree can never make its local
copy look like the installed package, no matter what directory the hook
subprocess happens to be running from.

BUG-MSO-2026-0816 — expanded write targets, and pip against the active env
===========================================================================
PLAN-BUG-MSO-2026-0807 found two gaps the BUG-0614 confinement left open:

* **Unexpanded variables.** A Bash write target is raw command text, so
  ``echo x > $MAESTRO_TEMP/../f.log`` was resolved as a literal relative path
  (``<cwd>/$MAESTRO_TEMP/../f.log``) and never compared against the protected
  roots at all. :func:`check_environment_confinement` now checks BOTH the
  literal and its ``os.path.expandvars``/``expanduser`` form, denying when
  either lands inside a protected root. A single-quoted token is not expanded,
  matching the shell. Only the environment check expands — the worktree
  confinement keeps its pre-0816 behaviour, since crews are told to write
  durable artefacts as ``$MAESTRO_ARTEFACT_ROOT/...`` and expanding that in
  embedded mode would deny the sanctioned path.

* **pip mutating the active environment.** Nothing recognised ``pip install``
  / ``pip uninstall`` / ``python -m pip …`` as a write to the environment the
  installed package lives in. F1 of that plan traced the 2026-09-15 fleet-wide
  crew-launch stall to exactly that shape: a pip uninstall of the ``maestro``
  distribution. :func:`check_pip_environment_mutation` denies those in crew
  context unless the install is redirected (``--target``/``-t``, ``--prefix``,
  ``--root``) or runs from a separately created virtual environment — a
  path-qualified interpreter/pip inside a venv, an activated venv earlier in
  the same command, or a ``VIRTUAL_ENV`` distinct from this hook's own
  ``sys.prefix``. "Separately created" means a ``pyvenv.cfg`` is present.
"""
from __future__ import annotations

import json
import os
import re
import sys
import sysconfig
from pathlib import Path
from typing import List, Optional, Tuple

from maestro.env import (
    artefact_root as _artefact_root_env,
    path_guard_bypass as _bypass,
    repo_path as _repo_path,
)
from maestro.workspace import MSO_DIR_NAME


# Canonical role code per legacy alias (state.json may carry either).
_ROLE_ALIASES = {
    "NAV": "PLN", "SHP": "BLD", "BOS": "TST",
    "SCR": "DOC", "LKT": "SEC", "COX": "REL", "QM": "LEAD",
}

# Durable-plane dirs (relative to the artefact ``.mso`` dir) every role may write.
_SHARED_ARTEFACT_DIRS = ("handoffs", "usage", "prompts/complete")

# Role-specific durable-plane dirs (relative to the artefact ``.mso`` dir).
# Mirrors the plan risk-register mitigation verbatim: PLN→plans/handoffs,
# TST→reports/qa + handoffs, SEC→reports/security, DOC→docs dirs.
_ROLE_ARTEFACT_DIRS = {
    "PLN": ("plans",),
    "BLD": (),
    "TST": ("reports/qa",),
    # BUG-MSO-2026-0459: SEC also owns the INV-type deliverable, which lives in
    # reports/investigation/ (see maestro/roles/SEC.md OUTPUT Locations, and the
    # BUG-MSO-2026-0444 SEC_ARTEFACT_MISSING gate which searches BOTH dirs).
    # pretool.SEC_WRITE_ALLOWED already permits it; this guard must agree or
    # solo/shared mode denies the write that embedded mode allows.
    "SEC": ("reports/security", "reports/investigation"),
    "DOC": ("docs",),
    "REL": ("reports/voyage",),
    "LEAD": (),
}


_FILE_MUTATING_TOOLS = {"Write", "Edit", "MultiEdit", "NotebookEdit"}

# Conservative Bash write-target extraction. Best-effort defence-in-depth on top
# of the structured-tool guard; the worktree remains the primary isolation layer.
# A single quoted/unquoted shell token.
_TOKEN = re.compile(r""""[^"]+"|'[^']+'|[^\s;&|<>]+""")
# Output redirections: optional fd number or `&`, `>`/`>>`, optional `|` (clobber),
# optional whitespace, then the target. Matches `>f`, `> f`, `2>f`, `&>f`, `>|f`,
# `2>>f`. Negative lookbehind skips arrow-like tokens (`->`, `=>`, `<>`).
_REDIRECT = re.compile(r"""(?<![-=<])(?:\d+|&)?>>?\|?\s*("[^"]+"|'[^']+'|[^\s;&|<>]+)""")
# `tee [flags] f1 f2 ...` — capture the whole arg run; files split out below.
_TEE = re.compile(r"""\btee\b((?:\s+(?:"[^"]+"|'[^']+'|[^\s;&|<>]+))+)""")
# `dd of=PATH` (and any `of=` form).
_OF = re.compile(r"""\bof=("[^"]+"|'[^']+'|[^\s;&|<>]+)""")


def _resolve_worktree() -> Optional[Path]:
    rp = _repo_path().strip()
    if not rp:
        return None
    try:
        return Path(rp).resolve()
    except Exception:
        return None


def _resolve_artefact_mso() -> Optional[Path]:
    """Return the artefact repo's ``.mso`` dir from ``MAESTRO_ARTEFACT_ROOT``,
    or None when unset/unresolvable (embedded/legacy dispatch → guard no-op)."""
    v = _artefact_root_env().strip()
    if not v:
        return None
    try:
        return Path(v).resolve()
    except Exception:
        return None


def _is_solo_mode(art_mso: Path) -> bool:
    """True when *art_mso*'s OWN workspace.json declares solo/shared mode.

    BUG-MSO-2026-0470 (nested-worktree regression): this used to call
    ``maestro.workspace.get_artefact_mode()`` with no argument, which resolves
    the workspace via ``get_workspace_dir(None)`` — ``MAESTRO_DIR`` first, else
    a walk-up from ``cwd`` — entirely independent of *art_mso* (already
    resolved from ``MAESTRO_ARTEFACT_ROOT`` by the caller). When ``MAESTRO_DIR``
    is absent from the hook's env (this bug's whole reproduction condition) and
    ``cwd`` has no ancestor ``.mso``, that resolution fails and mode silently
    reports "embedded" — so the solo role-scoped allowlist below never engages,
    and the crew's own worktree, when nested inside the artefact repo's
    ``.mso/worktrees/`` (FTR-MSO-2026-0364's normal topology), gets wrongly
    caught by the BUG-0282 product-confinement fallback: a sanctioned SEC
    report/handoff write resolves inside `main_root` (== the artefact repo,
    since ``_main_repo_root`` recognises the ``.mso/worktrees`` segment) but
    outside the crew's worktree, and gets denied. This is the exact same
    MAESTRO_DIR-fail-open class already fixed in ``pretool.py`` STEP 4 for the
    SEC role-scope check — never applied here. Reading *art_mso*'s own config
    directly (no env/cwd resolution at all) closes it identically.

    Fail-open to embedded (``False``) on any resolution error — the caller then
    keeps the pre-0368 product-confinement behaviour."""
    try:
        cfg = json.loads((art_mso / "config" / "workspace.json").read_text(encoding="utf-8"))
    except Exception:
        return False
    if not isinstance(cfg, dict):
        return False
    block = cfg.get("artefacts")
    mode = block.get("mode") if isinstance(block, dict) else None
    return mode in ("solo", "shared")


def _crew_role(art_mso: Path) -> str:
    """Resolve the current crew's canonical role from its state.json under the
    artefact root, or '' when it can't be determined (guard then fails open for
    artefact writes so a missing state file never blocks a working crew)."""
    crew = os.environ.get("MAESTRO_CREW", "").strip()
    if not crew:
        return ""
    state_file = art_mso / "crews" / f"crew{crew}" / "state.json"
    try:
        data = json.loads(state_file.read_text(encoding="utf-8"))
    except Exception:
        return ""
    role = str(data.get("role", "")).strip().upper()
    return _ROLE_ALIASES.get(role, role)


def _artefact_write_allowed(rel_to_mso: str, role: str, crew: str) -> bool:
    """Whether a write at ``rel_to_mso`` (POSIX-relative to the artefact ``.mso``
    dir) is permitted for *role*. Own crew runtime dir + role-scoped durable dirs
    + shared durable dirs pass; runtime plane and cross-role durable dirs fail."""
    rel = rel_to_mso.replace("\\", "/").lstrip("/")
    if not rel:
        return False
    # The crew's own runtime dir (progress.md, crew-local scratch) is always fine.
    if crew and (rel == f"crews/crew{crew}" or rel.startswith(f"crews/crew{crew}/")):
        return True
    allowed = set(_SHARED_ARTEFACT_DIRS) | set(_ROLE_ARTEFACT_DIRS.get(role, ()))
    for d in allowed:
        if rel == d or rel.startswith(d + "/"):
            return True
    return False


def _rel_under(path: Path, root: Path) -> Optional[str]:
    """POSIX-relative path of *path* under *root*, or None if not contained."""
    try:
        return path.relative_to(root).as_posix()
    except ValueError:
        return None


def _main_repo_root(worktree: Path) -> Optional[Path]:
    """Derive the main repo root from a Maestro worktree path.

    Dispatcher worktrees live at ``<root>/.mso/worktrees/<VOY>/crew<N>``
    (FTR-MSO-2026-0364), or at the legacy
    ``<root>/.mso/voyages/active/<VOY>/.worktree[-crewN]`` (or the legacy
    ``.adm`` prefix), so the segment before ``.mso``/``.adm`` is the main root.
    Returns None if the layout isn't recognised (caller then fails open).
    """
    parts = worktree.parts
    for i, seg in enumerate(parts):
        if (seg in (MSO_DIR_NAME, ".adm") and i + 1 < len(parts)
                and parts[i + 1] in ("voyages", "worktrees")):
            if i > 0:
                return Path(*parts[:i])
    return None


def _within(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False


def _resolve_target(target: str, base: Path) -> Optional[Path]:
    """Resolve a (possibly relative/quoted) target path against *base*.

    Relative paths resolve against *base* (the tool's effective cwd), so a crew
    that ``cd``'d out of its worktree is still evaluated correctly. Returns None
    on any uncertainty (caller fails open)."""
    if not target:
        return None
    t = target.strip().strip('"').strip("'")
    if not t:
        return None
    try:
        p = Path(t)
        if not p.is_absolute():
            p = base / p
        return p.resolve()
    except Exception:
        return None


# Shell separators that end one simple command.
_SEG_SPLIT = re.compile(r"(?:;|&&|\|\||\||&|\n)")
# Leading tokens that wrap/prefix a command without being the command itself.
_CMD_PREFIXES = {"sudo", "env", "command", "nice", "nohup", "time", "then", "do", "exec"}


def _writer_targets(command: str) -> List[str]:
    """Extract destination paths for common non-redirection file writers.

    Audit finding H13: the redirection/tee/of= extractor missed ordinary file
    writers (`cp`, `mv`, `install`, `sed -i`, `ln`), so a crew could write into
    the main checkout with e.g. `cp evil.py /main/repo/src/x.py` undetected.
    This is still best-effort heuristic parsing (the residual is documented;
    OS-level confinement is the real control), but it closes the common cases.
    """
    targets: List[str] = []
    for seg in _SEG_SPLIT.split(command):
        toks = _TOKEN.findall(seg.strip())
        if not toks:
            continue
        # Skip leading env-assignments (FOO=bar) and command wrappers (sudo …).
        i = 0
        while i < len(toks) and (
            (("=" in toks[i]) and not toks[i].startswith("-"))
            or toks[i].strip("\"'") in _CMD_PREFIXES
        ):
            i += 1
        if i >= len(toks):
            continue
        cmd0 = toks[i].strip("\"'").split("/")[-1]
        rest = toks[i + 1:]
        nonflag = [t for t in rest if not t.startswith("-")]
        if cmd0 in ("cp", "mv", "install"):
            # Destination is the last non-flag argument (cp SRC... DST).
            if len(nonflag) >= 2:
                targets.append(nonflag[-1])
        elif cmd0 == "ln":
            # Link name is the last non-flag argument.
            if nonflag:
                targets.append(nonflag[-1])
        elif cmd0 == "sed":
            # In-place edit: -i / -i.bak. First non-flag is the script; the
            # remainder are the files being rewritten.
            if any(t.startswith("-i") for t in rest) and len(nonflag) >= 2:
                targets.extend(nonflag[1:])
        elif cmd0 == "truncate":
            if nonflag:
                targets.append(nonflag[-1])
    return targets


def _bash_write_targets(command: str) -> List[str]:
    if not command:
        return []
    targets: List[str] = []
    for m in _REDIRECT.finditer(command):
        targets.append(m.group(1))
    for m in _TEE.finditer(command):
        for tok in _TOKEN.findall(m.group(1)):
            if tok.startswith("-"):  # skip tee flags (-a, --append, ...)
                continue
            targets.append(tok)
    for m in _OF.finditer(command):
        targets.append(m.group(1))
    targets.extend(_writer_targets(command))
    return targets


def _mutation_targets(tool_name: str, tool_input: dict) -> List[str]:
    """Extract the raw (unresolved) write-target string(s) a tool call names,
    shared between :func:`check_path_confinement` and
    :func:`check_environment_confinement` so both see identical targets."""
    if tool_name in _FILE_MUTATING_TOOLS:
        fp = (
            tool_input.get("file_path")
            or tool_input.get("filePath")
            or tool_input.get("notebook_path")
            or ""
        )
        return [fp] if fp else []
    if tool_name == "Bash":
        return _bash_write_targets(tool_input.get("command", ""))
    return []


# ---------------------------------------------------------------------------
# Installed package / site-packages confinement (BUG-MSO-2026-0614)
# ---------------------------------------------------------------------------

def _site_packages_dirs() -> List[Path]:
    """Real (resolved) site-packages/dist-packages directories for the
    ACTIVE Python environment.

    Computed exclusively from ``sysconfig``/``sys.path`` — deliberately NEVER
    via ``import maestro`` (BUG-TST-0614-A). A live import inside this hook
    subprocess resolves relative to the subprocess's own ``cwd``, which —
    in this self-hosted repo, where every crew worktree already contains its
    own ``maestro/`` product-code directory — would silently resolve to the
    crew's OWN copy instead of the real installed package. ``sysconfig`` and
    ``sys.path`` describe the environment's configuration and never depend on
    the calling process's cwd, so they stay correct across a plain venv
    install, a system install, and an editable/dev checkout regardless of
    where the hook happens to be invoked from. Returns ``[]`` on total
    failure (fail-open, matching this module's other guards) rather than
    ever raising.
    """
    dirs: set = set()
    try:
        paths = sysconfig.get_paths()
        for key in ("purelib", "platlib"):
            p = paths.get(key)
            if p:
                try:
                    dirs.add(Path(p).resolve())
                except Exception:
                    pass
    except Exception:
        pass
    try:
        for p in sys.path:
            if not p:
                continue
            try:
                rp = Path(p).resolve()
            except Exception:
                continue
            if rp.name.lower() in ("site-packages", "dist-packages"):
                dirs.add(rp)
    except Exception:
        pass
    return list(dirs)


def _protected_environment_roots() -> List[Path]:
    """Real (fully-resolved) directories a crew must never write into: the
    installed ``maestro`` package directory, and the active Python
    environment's site-packages location(s) themselves.

    The installed package root is ``<site-packages-dir>/maestro`` for each
    resolved site-packages dir — joined by name, never by importing
    ``maestro`` (see :func:`_site_packages_dirs` and the BUG-TST-0614-A
    module-docstring note). Returns ``[]`` on total failure (fail-open,
    matching this module's other guards) rather than ever raising.
    """
    roots: set = set()
    site_dirs = _site_packages_dirs()
    roots.update(site_dirs)
    for base in site_dirs:
        try:
            roots.add((base / "maestro").resolve())
        except Exception:
            pass
    return list(roots)


def _explicit_temp_dir() -> Optional[Path]:
    """The crew's ACTUAL ``$MAESTRO_TEMP``, resolved, or ``None``.

    Set by the dispatcher for every crew (``maestro.core.crew.invoke_claude``
    via ``maestro.core.temp_paths.resolve_temp_dir``); a crew cannot choose it
    for itself. Read from the environment only — never by importing ``maestro``
    to locate the installed package (BUG-TST-0614-A)."""
    try:
        from maestro.env import temp_dir as _temp_dir_env
        v = _temp_dir_env().strip()
        if v:
            return Path(v).resolve()
    except Exception:
        pass
    return None


def _sanctioned_temp_dirs(art_mso: Optional[Path] = None) -> List[Path]:
    """Scratch roots a crew is EXPECTED to write into (BUG-MSO-2026-0701).

    Every role prompt tells crews to keep build output, local NuGet caches and
    other throwaway files under ``$MAESTRO_TEMP`` rather than scattering them —
    so the guards must not then refuse the write. Two entries, both outside the
    crew worktree since 0701 moved the default out of site-packages:

    * the resolved ``$MAESTRO_TEMP`` itself, and
    * ``<artefact root>/temp`` — 0701's default — included even when the env var
      is missing (a hook subprocess launched without it) so the sanctioned
      location never depends on env plumbing surviving.
    """
    dirs: List[Path] = []
    explicit = _explicit_temp_dir()
    if explicit is not None:
        dirs.append(explicit)
    if art_mso is not None:
        try:
            dirs.append((art_mso / "temp").resolve())
        except Exception:
            pass
    return dirs


def _protected_environment_temp_exemptions() -> List[Path]:
    """The one carve-out inside the protected roots: the crew's ACTUAL
    ``$MAESTRO_TEMP``, on the rare occasions it still lands in there.

    Since BUG-MSO-2026-0701 ``MAESTRO_TEMP`` defaults to
    ``<artefact root>/temp`` (``maestro.core.temp_paths``), which sits outside
    every protected root — so this normally exempts nothing at all. The
    previous unconditional ``<site-packages>/maestro/temp`` exemption is
    deliberately GONE, because a write there is no longer something Maestro
    itself asks for. What remains is honouring an operator who has explicitly
    pointed ``MAESTRO_TEMP`` somewhere inside the environment anyway: their
    stated scratch space stays writable, while every other location inside the
    protected roots is still denied.

    Reads the env var only — like :func:`_protected_environment_roots`, this
    never imports ``maestro`` to locate the installed package
    (BUG-TST-0614-A)."""
    explicit = _explicit_temp_dir()
    return [explicit] if explicit is not None else []


def check_environment_confinement(
    tool_name: str, tool_input: dict, cwd: Optional[str] = None
) -> Tuple[bool, str]:
    """Return ``(allow, reason)``. Denies a crew file mutation whose target
    resolves inside the INSTALLED maestro package or the active Python
    environment's site-packages (BUG-MSO-2026-0614).

    Independent of worktree membership — unlike the danger-zone checks in
    :func:`check_path_confinement`, this never exempts a target merely
    because it also happens to fall inside the crew's own worktree (an
    editable/dev install can make the two overlap). Only acts in crew
    context (``MAESTRO_REPO_PATH`` set); fails open on any path-resolution
    uncertainty, matching this module's other guards."""
    if _bypass():
        from maestro.governance.breakglass import honor_bypass
        return honor_bypass("path_guard", cwd)
    worktree = _resolve_worktree()
    if worktree is None:
        return True, ""  # not a crew dispatch

    try:
        base = Path(cwd).resolve() if cwd else worktree
    except Exception:
        base = worktree

    # BUG-MSO-2026-0816: pip install/uninstall is a write to the environment
    # even though it names no target path.
    allow, reason = check_pip_environment_mutation(tool_name, tool_input, base)
    if not allow:
        return allow, reason

    roots = _protected_environment_roots()
    if not roots:
        return True, ""
    temp_exemptions = _protected_environment_temp_exemptions()

    for t in _mutation_targets(tool_name, tool_input):
        for candidate in _target_candidates(t):
            reason = _environment_deny_reason(
                tool_name, t, candidate, base, roots, temp_exemptions, worktree)
            if reason:
                return False, reason
    return True, ""


def _target_candidates(target: str) -> List[str]:
    """The raw target, plus its variable/``~``-expanded form when that differs
    (BUG-MSO-2026-0816). The literal is always kept so expansion can only ever
    ADD a denial, never remove one. A single-quoted token is not expanded —
    the shell would not expand it either."""
    candidates = [target]
    raw = (target or "").strip()
    if not raw or raw.startswith("'"):
        return candidates
    unquoted = raw.strip('"')
    try:
        expanded = os.path.expanduser(os.path.expandvars(unquoted))
    except Exception:
        return candidates
    if expanded and expanded != unquoted:
        candidates.append(expanded)
    return candidates


def _environment_deny_reason(
    tool_name: str,
    t: str,
    candidate: str,
    base: Path,
    roots: List[Path],
    temp_exemptions: List[Path],
    worktree: Path,
) -> str:
    """Deny reason when *candidate* (the literal target *t*, or its expansion)
    resolves inside a protected environment root; ``""`` otherwise."""
    resolved = _resolve_target(candidate, base)
    if resolved is None:
        return ""  # fail-open on resolution uncertainty
    if any(_within(resolved, ex) for ex in temp_exemptions):
        return ""  # sanctioned MAESTRO_TEMP scratch space
    shown = t if candidate == t else f"{t}` (expands to `{candidate}"
    for root in roots:
        if _within(resolved, root):
            return (
                f"Path guard: refusing {tool_name} write to `{shown}` — it resolves "
                f"inside the INSTALLED Maestro package / active Python "
                f"environment at `{root}`. Writing there corrupts the very tool "
                "executing this write and has taken the whole fleet down twice "
                "(the 2026-08-17 136MB shadowing incident, then BUG-MSO-2026-0614's "
                "110MB repeat) — this location is never a legitimate write target "
                "for a crew, no matter what the write was intended to be. If you "
                "need scratch space, write inside your own worktree "
                f"(`{worktree}`) or under $MAESTRO_TEMP instead. Set "
                "MAESTRO_PATH_GUARD_BYPASS=1 in the parent shell for manual recovery."
            )
    return ""


# ---------------------------------------------------------------------------
# pip install/uninstall against the active environment (BUG-MSO-2026-0816)
# ---------------------------------------------------------------------------

#: Named in every deny reason, so a crew (and a reviewer) can see which rule fired.
PIP_RULE_ID = "pip-environment-mutation"

_PIP_EXE_RE = re.compile(r"^pip(?:\d+(?:\.\d+)*)?(?:\.exe)?$", re.IGNORECASE)
_PYTHON_EXE_RE = re.compile(r"^(?:python(?:\d+(?:\.\d+)*)?w?|py)(?:\.exe)?$", re.IGNORECASE)
_ACTIVATE_RE = re.compile(r"^activate(?:\.bat|\.ps1|\.fish|\.csh)?$", re.IGNORECASE)
_SHELLS_WITH_C = {"bash", "sh", "zsh", "dash", "bash.exe", "sh.exe"}
# pip's own subcommand vocabulary — used to find the subcommand past global
# options that take a value (`pip --cache-dir X install`), without having to
# know which options take one.
_PIP_SUBCOMMANDS = {
    "install", "uninstall", "download", "freeze", "inspect", "list", "show",
    "check", "config", "search", "cache", "index", "wheel", "hash",
    "completion", "debug", "help", "lock",
}
_PIP_MUTATING = {"install", "uninstall"}
# Options that send an install somewhere other than the active environment.
_PIP_REDIRECT_OPTS = ("--target", "--prefix", "--root")

_TOOLS_WITH_COMMANDS = {"Bash", "PowerShell"}


def _unquote(tok: str) -> str:
    return tok.strip().strip("\"'")


def _basename(tok: str) -> str:
    return re.split(r"[\\/]", _unquote(tok))[-1]


def _is_path_qualified(tok: str) -> bool:
    return bool(re.search(r"[\\/]", _unquote(tok)))


def _hook_prefix() -> Optional[Path]:
    try:
        return Path(sys.prefix).resolve()
    except Exception:
        return None


def _is_distinct_venv(root: Optional[Path]) -> bool:
    """A separately created virtual environment: has ``pyvenv.cfg`` and is not
    the environment this hook (and so the installed Maestro) runs from."""
    if root is None:
        return False
    try:
        r = root.resolve()
        if not (r / "pyvenv.cfg").is_file():
            return False
        return r != _hook_prefix()
    except Exception:
        return False


def _venv_root_of_executable(tok: str, base: Path) -> Optional[Path]:
    """``<venv>`` for a path-qualified ``<venv>/bin/x`` or ``<venv>/Scripts/x``."""
    try:
        p = Path(_unquote(tok))
        if not p.is_absolute():
            p = base / p
        parent = p.parent
        if parent.name.lower() in ("bin", "scripts"):
            return parent.parent
    except Exception:
        pass
    return None


def _pip_args(cmd_tok: str, rest: List[str]) -> Optional[List[str]]:
    """The arguments after ``pip`` when this simple command runs pip, else None."""
    cmd0 = _basename(cmd_tok)
    if _PIP_EXE_RE.match(cmd0):
        return rest
    if not _PYTHON_EXE_RE.match(cmd0):
        return None
    j = 0
    while j < len(rest):
        tk = _unquote(rest[j])
        if tk == "-m":
            if j + 1 < len(rest) and _PIP_EXE_RE.match(_unquote(rest[j + 1])):
                return rest[j + 2:]
            return None
        if tk.startswith("-m") and len(tk) > 2:
            return rest[j + 1:] if _PIP_EXE_RE.match(tk[2:]) else None
        if not tk.startswith("-"):
            return None  # a script path — not `-m pip`
        j += 1
    return None


def _pip_install_redirected(args: List[str]) -> bool:
    for a in args:
        tk = _unquote(a)
        if tk in _PIP_REDIRECT_OPTS or any(tk.startswith(o + "=") for o in _PIP_REDIRECT_OPTS):
            return True
        if tk == "-t" or (tk.startswith("-t") and not tk.startswith("--")):
            return True
    return False


def _unsafe_pip_segment(command: str, base: Path, depth: int = 0) -> Optional[str]:
    """The first simple command in *command* that runs ``pip install`` or
    ``pip uninstall`` against the active environment, or None."""
    venv_activated = False
    for seg in _SEG_SPLIT.split(command or ""):
        seg = seg.strip()
        toks = _TOKEN.findall(seg)
        if not toks:
            continue
        i = 0
        while i < len(toks) and (
            (("=" in toks[i]) and not toks[i].startswith("-"))
            or _unquote(toks[i]) in _CMD_PREFIXES
        ):
            i += 1
        if i >= len(toks):
            continue
        cmd_tok, rest = toks[i], toks[i + 1:]
        cmd0 = _basename(cmd_tok).lower()

        # `source <venv>/bin/activate`, `. <venv>/bin/activate`, or running the
        # activate script directly (Windows `<venv>\Scripts\activate`).
        activate_tok = None
        if cmd0 in ("source", ".") and rest:
            activate_tok = rest[0]
        elif _ACTIVATE_RE.match(cmd0):
            activate_tok = cmd_tok
        if activate_tok is not None:
            if _ACTIVATE_RE.match(_basename(activate_tok)) and _is_distinct_venv(
                    _venv_root_of_executable(activate_tok, base)):
                venv_activated = True
            continue

        # `bash -c "pip uninstall -y maestro"` — look inside, bounded.
        if cmd0 in _SHELLS_WITH_C:
            if depth < 2 and "-c" in rest:
                j = rest.index("-c")
                if j + 1 < len(rest):
                    hit = _unsafe_pip_segment(_unquote(rest[j + 1]), base, depth + 1)
                    if hit:
                        return hit
            continue

        args = _pip_args(cmd_tok, rest)
        if args is None:
            continue
        sub = next((_unquote(a).lower() for a in args
                    if _unquote(a).lower() in _PIP_SUBCOMMANDS), None)
        if sub not in _PIP_MUTATING:
            continue
        if sub == "install" and _pip_install_redirected(args):
            continue
        if _is_path_qualified(cmd_tok):
            # An explicit interpreter/pip decides the environment by itself —
            # VIRTUAL_ENV or an earlier activation does not change it.
            if _is_distinct_venv(_venv_root_of_executable(cmd_tok, base)):
                continue
            return seg
        if venv_activated:
            continue
        env_venv = os.environ.get("VIRTUAL_ENV", "").strip()
        if env_venv and _is_distinct_venv(Path(env_venv)):
            continue
        return seg
    return None


def check_pip_environment_mutation(
    tool_name: str, tool_input: dict, cwd: Optional[Path] = None
) -> Tuple[bool, str]:
    """Return ``(allow, reason)``. Denies ``pip install|uninstall`` (including
    ``python -m pip …`` and ``pip install -e``) in crew context when it would
    change the ACTIVE Python environment — the one the installed Maestro
    package and this hook run from (BUG-MSO-2026-0816).

    Allowed: an install redirected with ``--target``/``-t``, ``--prefix`` or
    ``--root``; or pip run from a separately created venv (see
    :func:`_unsafe_pip_segment`). Only acts in crew context; bypassable like
    the other path guards."""
    if tool_name not in _TOOLS_WITH_COMMANDS:
        return True, ""
    if _bypass():
        from maestro.governance.breakglass import honor_bypass
        return honor_bypass("path_guard", str(cwd) if cwd else None)
    worktree = _resolve_worktree()
    if worktree is None:
        return True, ""  # not a crew dispatch
    try:
        base = Path(cwd).resolve() if cwd else worktree
    except Exception:
        base = worktree
    seg = _unsafe_pip_segment(tool_input.get("command", "") or "", base)
    if seg is None:
        return True, ""
    return False, (
        f"Path guard [rule: {PIP_RULE_ID}, BUG-MSO-2026-0816]: refusing `{seg}` — "
        f"pip install/uninstall in crew context changes the ACTIVE Python "
        f"environment (`{sys.prefix}`), which is where the installed Maestro "
        "package and this hook run from. A pip uninstall of the maestro "
        "distribution is what wiped the installed package on 2026-09-15 and "
        "stalled every crew launch fleet-wide (PLAN-BUG-MSO-2026-0807 F1). "
        "Allowed instead: redirect the install with --target <dir>, --prefix "
        "<dir> or --root <dir> (e.g. under $MAESTRO_TEMP), or create a separate "
        "virtual environment in one command (`python -m venv <dir>`) and run pip "
        "from it in the next (`<dir>/Scripts/python -m pip install ...`, or "
        "`<dir>/bin/...` on POSIX) — the venv must already exist when this guard "
        "checks the command. Set "
        "MAESTRO_PATH_GUARD_BYPASS=1 in the parent shell for manual recovery."
    )


def check_path_confinement(
    tool_name: str, tool_input: dict, cwd: Optional[str] = None
) -> Tuple[bool, str]:
    """Return ``(allow, reason)``. ``allow=False`` denies a crew file mutation
    whose target is in the danger zone (another working tree of the same repo).

    *cwd* is the tool call's effective working directory (the hook ``cwd``), used
    to resolve relative targets; falls back to the worktree when unavailable."""
    if _bypass():
        # FTR-MSO-2026-0398: governed-mode bypass is a break-glass event
        # (identity-authorised, justified, audited). Non-governed workspaces get
        # (True, "") unconditionally — unchanged from before.
        from maestro.governance.breakglass import honor_bypass
        return honor_bypass("path_guard", cwd)
    worktree = _resolve_worktree()
    if worktree is None:
        return True, ""  # not a crew dispatch (no MAESTRO_REPO_PATH)

    # FTR-MSO-2026-0368: in solo/shared mode the artefact repo is distinct from the
    # product worktree and gets a role-scoped allowlist. Resolved once per call.
    art_mso = _resolve_artefact_mso()
    solo = art_mso is not None and _is_solo_mode(art_mso)
    art_repo_root = art_mso.parent if (solo and art_mso is not None) else None
    role = _crew_role(art_mso) if solo else ""
    crew = os.environ.get("MAESTRO_CREW", "").strip()

    main_root = _main_repo_root(worktree)
    if main_root is None and not solo:
        return True, ""  # unrecognised layout, embedded — fail open

    # Resolve relative targets against the crew's actual cwd, not an assumed
    # worktree — this is what closes the "crew cd's into the main checkout" gap.
    try:
        base = Path(cwd).resolve() if cwd else worktree
    except Exception:
        base = worktree

    targets: List[str] = _mutation_targets(tool_name, tool_input)

    # BUG-MSO-2026-0465: the crew's own worktree is a checkout of this (or a
    # sibling) repo, and the product repo commits .mso/ artefacts to every
    # branch — so the worktree carries its OWN nested .mso/ mirror, distinct
    # from the TRUE artefact root. Resolved once; None when no artefact root is
    # known (embedded dispatch predating this fix, or a non-Maestro test
    # fixture) — the check below then never engages and behaviour is unchanged.
    own_mso = (worktree / MSO_DIR_NAME).resolve() if art_mso is not None else None

    # BUG-MSO-2026-0501: the crew's OWN runtime dir (crews/crew{N}/ — progress.md,
    # crew-local scratch) is the one exception to the 0465 rule above. It is
    # never a durable artefact that needs the TRUE artefact root (it is
    # .gitignore'd everywhere this repo cares, and merge-time conflicts on it
    # already auto-resolve — see worktrees._is_crew_telemetry_path), so writing
    # it into the worktree's own .mso mirror is always fine. Without this
    # carve-out here, the 0465 check denied the exact relative path every crew
    # is instructed to use (crew.py build_prompt(): ".mso/crews/crew{N}/
    # progress.md") for EVERY role in EVERY workspace — the crew then fell back
    # to a bare "progress.md" write, which (having no .mso/ prefix at all) hit
    # no guard, landed at the WORKTREE ROOT, and got committed (root progress.md
    # is not gitignored), producing a content conflict on every convergence
    # whose crew branches wrote different progress notes. This mirrors the
    # carve-out `_artefact_write_allowed()` already grants for solo/shared mode
    # (line ~181) — that allowlist only engages for writes landing in the TRUE
    # artefact repo, so it never covered this worktree-mirror path.
    own_mso_crew_dir = (
        (own_mso / "crews" / f"crew{crew}") if (own_mso is not None and crew) else None
    )

    # BUG-MSO-2026-0701: resolved once per call, like the roots above.
    temp_dirs = _sanctioned_temp_dirs(art_mso)

    for t in targets:
        resolved = _resolve_target(t, base)
        if resolved is None:
            continue  # fail-open on resolution uncertainty

        # A write that syntactically targets the crew's OWN worktree copy of
        # .mso/ (not the true artefact root) is almost never legitimate product
        # work — it is a misdirected artefact write (report, handoff, plan, ...)
        # that would otherwise be silently accepted below as "inside my own
        # worktree" and then discarded when the worktree is pruned (observed on
        # SEC-MSO-2026-0461: a completed 42-turn security review vanished this
        # way, twice). Catch it BEFORE the worktree exemption — except the
        # crew's own runtime dir (BUG-MSO-2026-0501, see own_mso_crew_dir above).
        if (
            own_mso is not None and own_mso != art_mso and _within(resolved, own_mso)
            and not (own_mso_crew_dir is not None and _within(resolved, own_mso_crew_dir))
        ):
            return False, (
                f"Path guard: refusing {tool_name} write to `{t}` — it resolves "
                f"inside this crew's OWN worktree copy of {MSO_DIR_NAME}/ at "
                f"`{own_mso}`, not the artefact root. This product repo commits "
                f"{MSO_DIR_NAME}/ artefacts to every branch, so every worktree "
                f"checkout carries its own throwaway mirror; artefact paths "
                f"(reports, handoffs, plans, prompts, usage, ...) resolved there "
                f"are lost when the worktree is pruned (BUG-MSO-2026-0465). Write "
                f"to the ARTEFACT ROOT instead — use an absolute path under "
                f"$MAESTRO_ARTEFACT_ROOT (or $MAESTRO_DIR), e.g. "
                f"\"$MAESTRO_ARTEFACT_ROOT/reports/security/...\", not a bare "
                f"\"{MSO_DIR_NAME}/reports/security/...\" path resolved against "
                f"this worktree's cwd."
            )

        # BUG-MSO-2026-0701: the crew's sanctioned scratch space. $MAESTRO_TEMP
        # now defaults to `<artefact root>/temp` instead of a directory inside
        # site-packages, which puts it INSIDE the product repo (embedded mode)
        # and inside the artefact repo's denied runtime plane (solo/shared) —
        # both of which the checks below would otherwise refuse. Every role
        # prompt instructs crews to write scratch there ("DO NOT create temp
        # directories outside $MAESTRO_TEMP"), so refusing it would deny the
        # exact path Maestro itself hands them. Checked after the 0465
        # own-worktree-mirror rule so a misdirected artefact write is still
        # caught first, and before the confinement rules that would deny it.
        if any(_within(resolved, d) for d in temp_dirs):
            continue

        # Writes inside the crew's own worktree are always allowed (product work).
        if _within(resolved, worktree):
            continue

        # Solo/shared: the artefact repo is governed by the role-scoped allowlist.
        if art_repo_root is not None and _within(resolved, art_repo_root):
            rel_to_mso = _rel_under(resolved, art_mso)
            # An unresolvable role (missing state.json) fails OPEN so a working
            # crew is never blocked; a resolvable role enforces the allowlist.
            if not role or (rel_to_mso is not None
                            and _artefact_write_allowed(rel_to_mso, role, crew)):
                continue
            return False, (
                f"Path guard: refusing {tool_name} write to `{t}` — it resolves "
                f"inside the ARTEFACT repo at `{art_repo_root}` but is not a durable "
                f"artefact path this role ({role or '?'}) may write. Solo/shared mode "
                f"scopes artefact writes to the role's durable-plane dirs "
                f"(e.g. plans, reports/qa, reports/security, docs), the shared dirs "
                f"(handoffs, usage, prompts/complete), and the crew's own "
                f"crews/crew{crew or 'N'}/ dir; the runtime plane "
                f"(logs/state/temp/bridge/worktrees) and other roles' dirs are "
                f"denied (FTR-MSO-2026-0368). Use a role-appropriate path, or set "
                f"MAESTRO_PATH_GUARD_BYPASS=1 in the parent shell for manual recovery."
            )

        # Product-repo confinement (BUG-MSO-2026-0282) — unchanged in both modes.
        if main_root is not None and _within(resolved, main_root):
            return False, (
                f"Path guard: refusing {tool_name} write to `{t}` — it resolves "
                f"inside the repo at `{main_root}` but OUTSIDE this crew's worktree "
                f"`{worktree}`. Crews must confine file mutations to their own "
                f"MAESTRO_REPO_PATH worktree; writing into the main checkout or a "
                f"sibling voyage worktree causes cross-tree contamination "
                f"(BUG-MSO-2026-0282). Use a path inside the worktree, or set "
                f"MAESTRO_PATH_GUARD_BYPASS=1 in the parent shell for manual recovery."
            )
    return True, ""


# ---------------------------------------------------------------------------
# Unbounded `find /` guard (BUG-MSO-2026-0500)
# ---------------------------------------------------------------------------
# Complements maestro.core.descendant_reaper (which reaps whatever a crew
# spawns, however long it ran) with prevention: refuse the specific pattern
# that burned the most CPU BEFORE it was ever reaped. A `find /` on
# Windows/Git-Bash walks every mounted volume and routinely never finishes in
# useful time — measured running 8.7 HOURS in BUG-MSO-2026-0500, the longest
# of eight concurrent instances. Reaping it at crew-end is correct but still
# wastes the crew's entire iteration/stall budget; refusing it up front means
# that budget goes to real work instead. The two mechanisms are independent
# defence-in-depth: this guard only ever sees a `find` invoked directly via
# the Bash tool — an unbounded scan issued from deeper inside a shell script,
# a subprocess, or a build tool is outside what a command-text guard can see,
# and still relies on descendant_reaper's reap-at-crew-end as the backstop.
#
# Matches `find` whose FIRST path argument is exactly `/` (root), optionally
# preceded by find's own flags (-L/-H/-P/-O<n>/-D...). Deliberately does NOT
# match an absolute path that happens to start with `/` and continues further
# (e.g. `find /c/Repos/MSO-Maestro/...`, the normal Git-Bash form of a
# worktree path) — only the bare root token trips it.
_UNBOUNDED_FIND_RE = re.compile(
    r"(?:^|[;&|]\s*)find\s+(?:-[A-Za-z][\w-]*\s+)*/(?:\s|$)"
)


def check_unbounded_find(tool_name: str, tool_input: dict) -> Tuple[bool, str]:
    """Return ``(allow, reason)``. Denies a Bash ``find`` search rooted at the
    filesystem root. Only engages in crew context (``MAESTRO_REPO_PATH`` set);
    fails open on any resolution error — worktrees/reaping remain the primary
    safety net, this is a cheap up-front deterrent, not the last line of
    defence."""
    if tool_name != "Bash":
        return True, ""
    if _bypass():
        from maestro.governance.breakglass import honor_bypass
        return honor_bypass("path_guard", None)
    worktree = _resolve_worktree()
    if worktree is None:
        return True, ""  # not a crew dispatch
    command = tool_input.get("command", "") or ""
    if not command or not _UNBOUNDED_FIND_RE.search(command):
        return True, ""
    return False, (
        "Path guard: refusing `find /` — it scans the ENTIRE filesystem (every "
        "mounted volume on Windows/Git-Bash) and can run for hours without "
        "finishing (BUG-MSO-2026-0500: one instance ran 8.7 hours). What you're "
        f"looking for is almost always inside your worktree — search there "
        f"instead, e.g. `find \"{worktree}\" -iname '...'`, or use the Glob/Grep "
        "tools, which are faster and already scoped correctly. Set "
        "MAESTRO_PATH_GUARD_BYPASS=1 in the parent shell for manual recovery."
    )
