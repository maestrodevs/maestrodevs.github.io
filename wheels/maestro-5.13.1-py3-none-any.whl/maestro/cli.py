"""maestro.cli — primary entry point for the mso CLI."""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from maestro.launch.sandbox import spawn as _spawn
from datetime import datetime, timezone
from pathlib import Path

from maestro.personas import current_persona
from maestro.workspace import (
    MSO_DIR_NAME,
    artefact_root_for,
    find_workspace_dir,
    resolve_artefact_dir,
)
from maestro.cli_argparse import FriendlyArgumentParser
from maestro.errors import MaestroError, MaestroUserError, MaestroConfigError
from maestro.cli_ui import print_error, print_unexpected


# ---------------------------------------------------------------------------
# Workspace resolution
# ---------------------------------------------------------------------------

def find_workspace(project: str | None = None) -> Path:
    """Locate a Maestro workspace root.

    Resolution order:
      1. Walk up from cwd looking for ``.mso/config/``.
      2. If a @PRJ argument is provided, look it up in the global registry.

    Returns the workspace root path.
    Raises SystemExit with a helpful message if not found.
    """
    # 1. Local detection (walk up from cwd via the central resolver)
    mso = find_workspace_dir(Path.cwd())
    if mso is not None:
        return mso.parent

    # 2. Global registry lookup via @PRJ
    if project:
        acronym = project.lstrip("@").upper()
        from maestro.registry import get_project_path
        ws = get_project_path(acronym)
        if ws:
            return ws
        raise MaestroConfigError(
            f"Project '{acronym}' not found in global registry.",
            hint="Run 'mso projects list' to see registered projects.",
        )

    _prod = current_persona().term("product")
    raise MaestroConfigError(
        f"Could not find a {_prod} workspace in this directory or any parent.",
        hint=(
            "Options:\n"
            "  1. Run this command from your workspace root (where .mso/ lives).\n"
            "  2. Use @PRJ to reference a registered project: mso status --project @MSO\n"
            "  3. Scaffold a new workspace: mso init --project MYPROJECT"
        ),
    )


def _artefact_dir(ws: Path) -> Path:
    """Resolve the artefact ``.mso`` dir for workspace root *ws*, honouring the
    solo/shared ``artefacts`` pointer (BUG-MSO-2026-0425).

    ``find_workspace()`` walks up from cwd and returns the *product-repo* root in
    solo mode, whose ``.mso`` is the frozen, stale plane. Commands that read/write
    ARTEFACTS (orders, queues, voyages, usage, review, status) must resolve
    through here so they hit the artefact repo. Anchored at *ws* (the workspace
    find_workspace() already chose) so an ambient MAESTRO_DIR can't retarget it.
    In embedded mode this is byte-identical to ``resolve_artefact_dir(ws)``.
    """
    return artefact_root_for(ws)


def _split_csv(value) -> "list[str] | None":
    """Split a comma-separated CLI value into a clean list, or ``None``.

    ``None`` (not ``[]``) when the flag was omitted, so a core that treats
    ``None`` as "use the type default" and ``[]`` as "explicitly empty" can
    tell the two apart (FTR-MSO-2026-0620: ``--role-sequence`` omitted means
    "resolve it from the order type", never "no roles").
    """
    if value is None:
        return None
    parts = [p.strip() for p in str(value).split(",")]
    return [p for p in parts if p]


def _resolve_explicit_mso_dir(explicit_dir: str) -> Path:
    """Resolve a ``--maestro-dir`` argv value to the actual ``.mso`` directory.

    BUG-MSO-2026-0686 F4: every ``--maestro-dir`` call site treats the value it
    is handed AS the ``.mso`` directory itself (matching ``MAESTRO_DIR``'s own
    contract — see ``maestro.workspace.get_workspace_dir``), but the flag was
    help-texted as "Explicit artefact root", a phrase equally readable as "the
    root of my workspace" (i.e. the ``.mso``'s *parent*, what ``find_workspace()``
    normally returns). Nothing validated which one was actually passed: handing
    the workspace root by mistake silently produced a ``mso_dir`` that resolves
    ``.mso``-shaped subpaths (``logs/``, ``state/``, ``identity/``) into
    directories that don't exist yet, or into unrelated ones an unlucky repo
    layout happens to already have — so ``mso cleanup``'s destructive Step 1
    could run and report success against the wrong location, and the auto-backup
    afterwards could zip up a near-empty directory while printing "Auto-backup
    created" (the operator's only signal that anything went right or wrong).

    Accepts EITHER form and normalises to the real ``.mso`` dir:
      1. *explicit_dir* already looks like a ``.mso`` dir (has a ``config``
         subdirectory) — used as-is.
      2. *explicit_dir* looks like the WORKSPACE root instead (its
         ``.mso/config`` subdirectory exists) — ``.mso`` is appended.
      3. Neither — refuses outright (:class:`MaestroUserError`) rather than
         silently proceeding against a directory that isn't a real Maestro
         workspace either way. Failing fast here, before Step 1 of a
         destructive command ever runs, is the whole point: a garbage path
         must never be allowed to look like a successful run.
    """
    candidate = Path(explicit_dir).resolve()
    if (candidate / "config").is_dir():
        return candidate
    if (candidate / MSO_DIR_NAME / "config").is_dir():
        return candidate / MSO_DIR_NAME
    raise MaestroUserError(
        f"--maestro-dir {candidate} is not a Maestro workspace: neither "
        f"{candidate / 'config'} nor {candidate / MSO_DIR_NAME / 'config'} exists.",
        hint=(
            "--maestro-dir takes the .mso artefact directory itself (the same "
            "value MAESTRO_DIR would resolve to) — pass either that .mso "
            "directory or its parent workspace root; both are accepted and "
            "normalised."
        ),
    )


def _run(script: str, extra_args: list[str], workspace: Path,
         artefact_dir: Path | None = None) -> None:
    """Run a Maestro core script via the current Python interpreter.

    *artefact_dir*, when given, is exported as ``MAESTRO_DIR`` in the child so a
    script that resolves the artefact plane by walking up from cwd lands on the
    right ``.mso`` in solo/shared mode (BUG-MSO-2026-0425) — cwd is the product
    repo there, whose ``.mso`` is stale. Mirrors the BUG-0407 monitor spawn.
    """
    script_path: Path | None = None
    try:
        import importlib.resources as pkg_resources
        import contextlib
        with contextlib.suppress(Exception):
            ref = pkg_resources.files("maestro") / "core" / script
            p = Path(str(ref))
            if p.exists():
                script_path = p
    except Exception:
        pass

    if not script_path.exists():
        raise MaestroConfigError(
            f"Script not found: {script}",
            hint=(
                "Ensure the maestro-fleet pip package is installed:\n"
                "  pip install maestro-fleet"
            ),
        )
    child_env = None
    if artefact_dir is not None:
        child_env = os.environ.copy()
        child_env["MAESTRO_DIR"] = str(artefact_dir)
    try:
        result = subprocess.run(
            [sys.executable, str(script_path)] + extra_args,
            cwd=workspace,
            env=child_env,
        )
    except KeyboardInterrupt:
        sys.exit(0)
    sys.exit(result.returncode)


def _resolve_script_path(script: str, workspace: Path) -> Path:
    """Resolve a Maestro core script path."""
    try:
        import importlib.resources as pkg_resources
        import contextlib
        with contextlib.suppress(Exception):
            ref = pkg_resources.files("maestro") / "core" / script
            p = Path(str(ref))
            if p.exists():
                return p
    except Exception:
        pass
    return resolve_artefact_dir(workspace) / "core" / script


def _run_detached(script: str, extra_args: list[str], workspace: Path) -> None:
    """Launch a Maestro script as a fully detached background process.

    The process is independent of this CLI session — it survives after `mso dispatch`
    returns. Used for the dispatcher so it keeps running even when called from a
    non-interactive session (IDE terminal, CI, Claude Code bash tool).

    On Windows uses DETACHED_PROCESS + CREATE_NEW_PROCESS_GROUP.
    On POSIX uses start_new_session=True.
    """
    import os

    script_path = _resolve_script_path(script, workspace)
    if not script_path.exists():
        raise SystemExit(
            f"\n[Maestro] Script not found: {script}\n"
            "Ensure the maestro-fleet pip package is installed:\n"
            "  pip install maestro-fleet\n"
        )

    child_cmd = [sys.executable, str(script_path)] + extra_args

    # BUG-MSO-2026-0713: the dispatcher runs under a supervisor wrapper instead
    # of being launched with stdout/stderr=DEVNULL. On 2026-09-09 this process
    # died and left NOTHING behind — an unhandled exception, an OOM and an
    # external taskkill were byte-for-byte indistinguishable, which is why the
    # mechanism of that incident can never now be determined. The wrapper is a
    # separate process that outlives its child, so it observes an exit the
    # dispatcher itself could not possibly have reported.
    #
    # The wrapper deliberately changes NOTHING about the dispatcher's identity:
    # dispatcher.pid is written by the dispatcher from its own os.getpid(), so
    # _live_dispatcher_pid(), the BUG-MSO-2026-0688 duplicate refusal, mso
    # status, the Hub aggregator and mso doctor's heartbeat check all keep
    # naming the same process they always did. The handshake file exists only so
    # the banner below can print the DISPATCHER's pid rather than the wrapper's.
    handshake = None
    cmd = child_cmd
    try:
        from maestro.core import died_record
        artefact_root = resolve_artefact_dir(workspace)
        handshake = artefact_root / "state" / "dispatcher.supervisor.json"
        try:
            handshake.unlink()
        except OSError:
            pass
        cmd = [
            # By resolved FILE path, never `-m` (BUG-MSO-2026-0516): `-m` puts the
            # cwd first on sys.path, so a source checkout would shadow the wheel.
            sys.executable, str(Path(died_record.__file__).resolve()), "supervise",
            "--kind", "dispatcher",
            "--workspace", str(artefact_root),
            "--handshake", str(handshake),
            "--cwd", str(workspace),
            "--",
        ] + child_cmd
    except Exception:
        # A supervisor that cannot be set up is a reason to lose the forensics,
        # never a reason to refuse to dispatch — fall back to the direct launch.
        handshake = None
        cmd = child_cmd

    if os.name == "nt":
        DETACHED_PROCESS = 0x00000008
        CREATE_NEW_PROCESS_GROUP = 0x00000200
        proc = _spawn(
            cmd,
            identity="cli_dispatch",
            workspace=workspace,
            cwd=str(workspace),
            creationflags=DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP,
            close_fds=True,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    else:
        proc = _spawn(
            cmd,
            identity="cli_dispatch",
            workspace=workspace,
            cwd=str(workspace),
            start_new_session=True,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

    dispatcher_pid = proc.pid
    if handshake is not None:
        try:
            from maestro.core import died_record
            dispatcher_pid = died_record.await_child_pid(handshake, timeout_seconds=5.0)
        except Exception:
            dispatcher_pid = None
        # None here means the handshake never appeared. Print no PID at all
        # rather than the wrapper's — an operator would taskkill the wrong
        # process, and dispatcher.pid remains the authoritative answer anyway.

    _prod = current_persona().term("product")
    if dispatcher_pid is None:
        print(f"\n  [{_prod}] Dispatcher launched under supervisor (PID {proc.pid}) — "
              f"its own PID is recorded in dispatcher.pid.")
    else:
        print(f"\n  [{_prod}] Dispatcher launched (PID {dispatcher_pid}) — running in background.")
    print(f"  Monitor with: mso status\n")


# ---------------------------------------------------------------------------
# Command implementations
# ---------------------------------------------------------------------------

def _maybe_dispatch_preflight(ws: Path) -> None:
    """Optionally run the Claude CLI preflight smoke test before dispatch.

    Activated by setting `preflight_check: true` in workspace.json (default
    false — opt-in). On failure: warn and continue (a transient API hiccup
    should not block the whole fleet). The failure is logged to lifecycle.log
    as a WARN event.
    """
    try:
        import json as _json
        ws_cfg_path = resolve_artefact_dir(ws) / "config" / "workspace.json"
        if not ws_cfg_path.exists():
            return
        ws_cfg = _json.loads(ws_cfg_path.read_text(encoding="utf-8"))
        if not ws_cfg.get("preflight_check", False):
            return
    except Exception:
        return

    from maestro.core.crew import run_preflight_check, find_claude_cli
    _prod = current_persona().term("product")
    print(f"[{_prod}] Running Claude CLI preflight check (preflight_check=true)...")
    result = run_preflight_check(claude_cli=find_claude_cli())
    if result["ok"]:
        print(f"[{_prod}] Preflight PASS.")
    else:
        msg = result.get("error", "unknown error")
        print(f"[{_prod}] Preflight WARN — Claude CLI check failed: {msg}")
        print(f"[{_prod}] Continuing dispatch (crews will handle errors via REQUEUE).")
        try:
            from datetime import datetime as _dt
            # Copilot review (PR #87): use the ws already passed in, not
            # get_workspace_dir() (which re-resolves via MAESTRO_DIR/cwd and can point
            # at a different workspace — or raise — when dispatching from outside the repo).
            log_dir = resolve_artefact_dir(ws) / "logs"
            log_dir.mkdir(parents=True, exist_ok=True)
            log_file = log_dir / "lifecycle.log"
            ts = _dt.now().strftime("%Y-%m-%d %H:%M:%S")
            with open(str(log_file), "a", encoding="utf-8") as lf:
                lf.write(f"{ts} | WARN               | preflight_check failed: {msg}\n")
        except Exception:
            pass


def cmd_dispatch(args: argparse.Namespace) -> None:
    """Launch fleet crews from the dispatch queue."""
    ws = find_workspace(getattr(args, "project", None))
    from maestro.identity.gate import require_capability
    require_capability("fleet.dispatch", workspace=ws)
    _maybe_dispatch_preflight(ws)
    # BUG-MSO-2026-0448: this MUST be the solo/shared-aware artefact dir, not
    # the raw resolve_artefact_dir(ws) (the product-repo's frozen .mso in solo
    # mode). fleet_runner._MAESTRO_DIR_OVERRIDE takes this value as gospel and
    # outranks solo-mode retargeting entirely, so a raw path here sent every
    # crew/logs/state write to the wrong plane — invisible to `mso status`.
    mso_dir = _artefact_dir(ws)
    extra: list[str] = ["--maestro-dir", str(mso_dir)]
    if args.cleanup:
        extra.append("--cleanup")
    extra += ["--dispatch", "--max-crews", str(args.max_crews)]
    if args.stagger_delay != 30:
        extra += ["--stagger-delay", str(args.stagger_delay)]
    # FTR-MSO-2026-0299: default ceiling raised 25 -> 120 (activity watchdog
    # is the primary hang control). Sentinel must match the parser default.
    if args.timeout != 60:
        extra += ["--timeout", str(args.timeout)]
    if args.max_turns != 25:
        extra += ["--max-turns", str(args.max_turns)]
    if hasattr(args, "convergence_timeout") and args.convergence_timeout is not None:
        extra += ["--convergence-timeout", str(args.convergence_timeout)]
    from maestro.audit import get_audit_log
    get_audit_log(ws).append(
        "fleet.dispatch",
        target=str(args.project or ws.name),
        metadata={"max_crews": args.max_crews},
    )
    # Launch dispatcher as a detached background process so it survives after
    # this CLI call returns (critical for IDE terminals, Claude Code, and CI).
    _run_detached("fleet_runner.py", extra, ws)


def cmd_cleanup(args: argparse.Namespace) -> None:
    """Clean up rogue processes and stale crew state."""
    # BUG-MSO-2026-0675 F1: an explicit --maestro-dir argv is the
    # authoritative signal a headless caller (the Hub's LEAD Run button, via
    # run_verbs._handle_dispatcher_cleanup) hands this command directly —
    # exactly the same treatment BUG-MSO-2026-0672 F1 gave cmd_doctor's
    # --single-check branch, and for the identical reason: find_workspace()
    # below deliberately IGNORES MAESTRO_DIR (BUG-MSO-2026-0425) and instead
    # walks up from cwd, which on a headless host can be absent a
    # .mso/config entirely (raises, permanently refusing every Run) or — far
    # worse — resolve a DIFFERENT fleet's workspace above cwd, letting this
    # command's own destructive Step 1 kill THAT fleet's live crews. This is
    # the sixth occurrence of this exact workspace-contamination class
    # (BUG-0601/0638/0643/0656/0672). The caller sets cwd to the product
    # repo before spawning this process (mirroring cmd_doctor's own
    # workspace_for_policy=Path.cwd() fallback), so cwd doubles as the
    # workspace root below for the capability gate and the fleet_runner.py
    # invocation. A direct `mso cleanup` with no --maestro-dir (the ordinary
    # interactive case) falls back to find_workspace() unchanged.
    explicit_dir = getattr(args, "maestro_dir", None)
    if explicit_dir:
        ws = Path.cwd()
        # BUG-MSO-2026-0686 F4: validate + normalise rather than trusting the
        # raw argv value as the .mso dir — a wrong value here (the workspace
        # root instead of its .mso) used to let Step 1 "succeed" against a
        # nonexistent location and the auto-backup zip a near-empty directory
        # while still printing "Auto-backup created".
        mso_dir = _resolve_explicit_mso_dir(explicit_dir)
    else:
        ws = find_workspace(getattr(args, "project", None))
        # BUG-MSO-2026-0448: same fix as cmd_dispatch — must be the solo/shared-aware
        # artefact dir so the cleanup subprocess's --maestro-dir targets the real
        # runtime plane, not a stale product-repo .mso.
        mso_dir = _artefact_dir(ws)
    # BUG-MSO-2026-0463: cleanup kills rogue crew processes and resets fleet
    # state — the most destructive operation this CLI exposes. Gate it the
    # same way dispatch is gated (fleet.dispatch); pass-through outside
    # enterprise/governed-enforce mode, so a solo operator never needs
    # identity configuration for this.
    # BUG-MSO-2026-0682 F3: the gate must evaluate against `mso_dir.parent`
    # (the artefact plane's own root), never `ws` directly — on the
    # --maestro-dir path `ws` is `Path.cwd()` (the product repo), whose own
    # `.mso` is only the frozen solo/shared pointer stub (BUG-MSO-2026-0425).
    # `require_capability()` re-derives the identity dir via
    # `resolve_artefact_dir(workspace)` (a plain `workspace / ".mso"` join,
    # not solo-pointer-aware — same as `backup()`), so it must be handed the
    # root whose `.mso` IS `mso_dir`, i.e. `mso_dir.parent`, not `mso_dir`
    # itself (which already ends in `.mso` and would double-join). This is
    # the exact same reasoning BUG-MSO-2026-0677 F1 applied to the auto-backup
    # call three lines below it in this same function — left behind here.
    # `mso_dir.parent` is safe in BOTH branches: in the non-explicit branch
    # `mso_dir = _artefact_dir(ws)` always ends in `.mso`, so `mso_dir.parent`
    # is the artefact root regardless of solo/shared redirection, and in
    # embedded mode (no redirection) it is byte-identical to `ws`.
    from maestro.identity.gate import require_capability
    require_capability("fleet.cleanup", workspace=mso_dir.parent)
    _prod = current_persona().term("product")

    # --- Step 1: kill rogue processes + reset state (always runs first) ---
    script_path = _resolve_script_path("fleet_runner.py", ws)
    cleanup_argv = [sys.executable, str(script_path), "--maestro-dir", str(mso_dir), "--cleanup"]
    if getattr(args, "force", False):
        # BUG-MSO-2026-0681 F2: bypass the BUG-MSO-2026-0673 F1 live-dispatcher
        # refusal — the escape hatch for a WEDGED (alive but not ticking)
        # dispatcher, which otherwise had no CLI recovery path at all.
        cleanup_argv.append("--force")
    result = subprocess.run(
        cleanup_argv,
        cwd=ws,
    )

    # BUG-MSO-2026-0688 F5: a REFUSED cleanup (BUG-MSO-2026-0673 F1 / 0685 F3's
    # live-dispatcher / live-demo refusals — exit 1, nothing was actually
    # touched) must not still zip the workspace and print "Auto-backup
    # created" / fall through to "cleanup still complete". BUG-MSO-2026-0681
    # F1 fixed the subprocess's OWN exit code for a refusal; this caller was
    # never taught to read it, so step 2 ran unconditionally regardless of
    # whether step 1 actually did anything.
    if result.returncode != 0:
        sys.exit(result.returncode)

    # --- Step 2: auto-backup (runs after kill; skipped on --no-backup) ---
    no_backup = getattr(args, "no_backup", False)
    if not no_backup:
        try:
            from maestro import backup as _backup
            # BUG-MSO-2026-0677 F1: must be `mso_dir.parent` (the artefact
            # plane's root — the directory whose `.mso` the --maestro-dir flag
            # above just targeted), not `ws`. In solo/shared mode `ws` is the
            # product-repo root, whose own `.mso` is only the frozen pointer
            # stub (BUG-MSO-2026-0425) — backing THAT up produces a restore
            # point containing none of the state `--cleanup` just wiped.
            # `backup()` re-derives its own `.mso` via `resolve_artefact_dir`
            # (a plain `workspace / ".mso"` join, not solo-pointer-aware), so
            # it must be handed the artefact repo's root, not `mso_dir` itself
            # (which already ends in `.mso` and would double-join).
            path = _backup.backup(workspace=mso_dir.parent)
            if path is None:
                print(f"[{_prod}] Auto-backup skipped (workspace too large — use 'mso backup' manually)")
            else:
                print(f"[{_prod}] Auto-backup created: {path}")
        except Exception as exc:
            # BUG-MSO-2026-0662 F2: this used to be the ONLY record of a lost
            # restore point — a bare stdout line nothing downstream reads.
            # `mso cleanup` takes this backup on every run specifically to
            # guarantee a restore point exists; a caller that only checks
            # this process's exit code (it deliberately still exits on
            # fleet_runner's own returncode, never this one) or that only
            # inspects stdout on a NONZERO exit (the Hub's Run button — see
            # run_verbs._handle_dispatcher_cleanup) would never see this.
            # The AUTO-BACKUP-FAILED marker is matched verbatim there so a
            # successful cleanup whose backup failed is reported as such,
            # not as an unqualified success. Also logged to lifecycle.log so
            # it survives being scrolled past and is greppable/auditable the
            # same way every other lifecycle WARN is.
            print(f"[{_prod}] AUTO-BACKUP-FAILED (cleanup still complete, but NO restore point was created): {exc}")
            try:
                log_dir = mso_dir / "logs"
                log_dir.mkdir(parents=True, exist_ok=True)
                ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                with open(str(log_dir / "lifecycle.log"), "a", encoding="utf-8") as lf:
                    lf.write(f"{ts} | WARN               | AUTO-BACKUP-FAILED during cleanup — no restore point created: {exc}\n")
            except Exception:
                pass

    sys.exit(result.returncode)


def cmd_worktree(args: argparse.Namespace) -> None:
    """Manage crew/voyage worktrees directly.

    BUG-MSO-2026-0680: the Captain's 2026-09-06 ruling narrowing the LEAD's
    `worktree.prune` action to OBSERVE-only (BUG-MSO-2026-0644) explicitly
    assumed "an operator runs the same command by hand" once the guard is
    trusted (maestro/lead/bands.py) — but no such command existed anywhere
    in the CLI, so the escape hatch the ruling relied on was never reachable.
    This subcommand IS that escape hatch: it calls the identical, occupancy-
    guarded `prune_stale_worktrees_ex()` the dispatcher runs unattended at
    startup and the LEAD's OBSERVE action only ever proposes — a deliberate,
    human-invoked action, never something the LEAD triggers on its own.

    BUG-MSO-2026-0684 (F1): `prune_stale_worktrees_ex`'s durable-plane scan
    resolves via `_worktrees_artefact_root()`, which honours
    `fleet_runner._MAESTRO_DIR_OVERRIDE` when set — the LEAD's own call
    (`execute_action` in `maestro/lead/bands.py`) works only because it enters
    `workspace_scope(ctx.artefact_root)` around the action body. This command
    called `prune_stale_worktrees_ex` bare, so the artefact plane fell back to
    the process cwd instead of the resolved `--project` workspace — the
    escape hatch the OBSERVE-only narrowing depends on silently pruned
    nothing when run from outside a workspace. Scope it the same way `mso
    order retry/skip/remove` already do (see below).

    BUG-MSO-2026-0689 (F2): `repo_root=ws` (the `find_workspace()` root) is
    the ARTEFACT repo in solo/shared artefact-repo mode, but the worktrees
    this command targets are registered in the PRODUCT repo's `.git` — the
    exact BUG-MSO-2026-0389 distinction the dispatcher's own startup prune
    already respects via `solo_worktree_repo_root()`
    (`fleet_runner.py`, `run_dispatcher`). Passing the wrong repo meant every
    `git worktree remove`/`prune` in this command ran against a repo that had
    no record of the worktree at all, failed, and (before the companion fix
    in `worktrees.py`) had its return code silently discarded while
    `_robust_rmtree` deleted the directory anyway — leaving an orphaned
    `.git/worktrees/<name>` entry in the PRODUCT repo that wedges the next
    `git worktree add` at that path.

    BUG-MSO-2026-0692 (F1): that resolution now lives in ONE place —
    `maestro.core.worktrees.resolve_worktree_prune_root()` — shared with the
    LEAD daemon's `worktree.prune` action (`maestro/lead/bands.py`), which
    had NOT received 0689's fix and was still passing the artefact repo (and,
    when its workspace was `None`, nothing at all, sending git to the
    daemon's ambient cwd). Seven consecutive PR #406 rounds have been one fix
    reaching some call sites and not all of them; a shared resolver is what
    stops this one drifting again. Do not reintroduce a local copy here.

    The resolver's tiers, and why `ws` is one of them: the product repo in
    solo/shared mode, else `ws`, else the `.mso` artefact root's parent —
    never the ambient cwd. `solo_worktree_repo_root()` returns `None` for
    embedded mode on the documented assumption that "the dispatcher's cwd IS
    the product repo", which only holds for the dispatcher's own startup call
    (always launched with `cwd=ws` — see `cmd_dispatch`/`cmd_cleanup`
    spawning `fleet_runner.py`). This CLI command carries no such guarantee:
    it is invoked from wherever the operator's shell happens to be, which is
    the entire reason `find_workspace()` walks up looking for `.mso` in the
    first place — an operator standing in an unrelated git repo (or no git
    repo at all) must still prune the `--project` workspace, not whatever
    `git worktree` finds at the ambient cwd
    (`TestWorktreePruneEndToEndOutsideWorkspace`, BUG-MSO-2026-0684 F1,
    proves this end-to-end). `ws` IS the correct git cwd in embedded mode
    (`find_workspace()`'s embedded contract); only solo/shared mode needs
    the resolved product repo instead. An unresolvable product repo in
    solo/shared mode is now REPORTED (exit 1), not silently downgraded to
    the artefact checkout — the repo that by definition has no record of the
    worktrees.
    """
    ws = find_workspace(getattr(args, "project", None))
    if args.worktree_action == "prune":
        from maestro.identity.gate import require_capability
        require_capability("fleet.cleanup", workspace=ws)
        from maestro.core.worktrees import (
            WorktreeRepoRootUnresolved,
            prune_stale_worktrees_ex,
            resolve_worktree_prune_root,
        )
        from maestro.core.order_retry import workspace_scope
        _prod = current_persona().term("product")
        _mso = _artefact_dir(ws)
        with workspace_scope(_mso):
            # BUG-MSO-2026-0692 (F1): the `solo_worktree_repo_root() or ws`
            # resolution BUG-MSO-2026-0689 landed here now lives in ONE
            # function shared with the LEAD daemon's `worktree.prune` action
            # (`maestro/lead/bands.py`), so the two can no longer drift — the
            # drift itself was 0692's F1. Behaviour change on the error path
            # only: an unresolvable PRODUCT repo in solo/shared mode is now
            # reported, not silently downgraded to the artefact checkout,
            # which is exactly the repo that has no record of the worktrees
            # (BUG-MSO-2026-0389).
            try:
                _prune_root = resolve_worktree_prune_root(
                    workspace=ws, artefact_root=_mso,
                )
            except WorktreeRepoRootUnresolved as exc:
                print_error(f"[{_prod}] worktree prune: {exc}")
                sys.exit(1)
            result = prune_stale_worktrees_ex(repo_root=_prune_root)
        print(f"[{_prod}] worktree prune: {result.removed} worktree(s) removed")
        if result.refused:
            print(f"[{_prod}] {len(result.refused)} worktree(s) refused (occupied, or no longer archived):")
            for reason in result.refused:
                print(f"  - {reason}")


def cmd_backup(args: argparse.Namespace) -> None:
    """Create a backup of project state, or list existing backups."""
    ws = find_workspace(getattr(args, "project", None))
    # BUG-MSO-2026-0682 F1: resolve the solo/shared-aware artefact plane
    # (`_artefact_dir`), not `ws` directly. `ws` is the product-repo root —
    # in solo/shared mode its own `.mso` is only the frozen pointer stub
    # (BUG-MSO-2026-0425), and `_backup.backup()`/`list_backups()` join
    # against whatever `workspace` they're handed with a PLAIN, non-pointer-
    # aware `workspace / ".mso"` (see `_backup.backup()`'s own
    # `resolve_artefact_dir` call). `mso cleanup`'s auto-backup already
    # writes to `mso_dir.parent / "maestro-backups"` (BUG-MSO-2026-0677 F1);
    # `artefact_root` here resolves to that SAME directory, so a manually
    # created backup, `--list`, and `restore` all agree with the auto-backup
    # on where backups live. In embedded mode (no solo/shared pointer),
    # `artefact_root` is byte-identical to `ws` — no behaviour change there.
    mso_dir = _artefact_dir(ws)
    artefact_root = mso_dir.parent
    from maestro import backup as _backup
    from maestro.identity.gate import require_capability
    if not args.list:
        require_capability("backup.create", workspace=artefact_root)
    if args.list:
        backup_dir = Path(args.output) if args.output else artefact_root / "maestro-backups"
        entries = _backup.list_backups(backup_dir)
        _prod = current_persona().term("product")
        if not entries:
            print(f"[{_prod}] No backups found in {backup_dir}")
            return
        for e in entries:
            if "error" in e:
                print(f"  {e['file'].name}  [unreadable: {e['error']}]")
            else:
                print(
                    f"  {e['file'].name}  |  {e['created_at']}  |  "
                    f"{e['file_count']} files  |  v{e.get('maestro_version', '?')}"
                )
        return
    path = _backup.backup(
        workspace=artefact_root,
        project=args.project,
        output_dir=Path(args.output) if args.output else None,
    )
    _prod = current_persona().term("product")
    print(f"[{_prod}] Backup created: {path}")


def cmd_restore(args: argparse.Namespace) -> None:
    """Restore project state from a backup ZIP."""
    ws = find_workspace(getattr(args, "project", None))
    # BUG-MSO-2026-0682 F1: same fix as cmd_backup above — restore must
    # extract into the artefact plane the backup's `.mso/...` archive names
    # came from, not the product repo's frozen pointer-stub `.mso`.
    mso_dir = _artefact_dir(ws)
    artefact_root = mso_dir.parent
    from maestro import backup as _backup
    from maestro.identity.gate import require_capability
    require_capability("backup.restore", workspace=artefact_root)
    _backup.restore(
        backup_file=Path(args.backup_file),
        workspace=artefact_root,
        project=args.project,
        force=args.force,
        merge=args.merge,
        dry_run=args.dry_run,
    )


def cmd_status(args: argparse.Namespace) -> None:
    """Display fleet status dashboard."""
    ws = find_workspace(getattr(args, "project", None))
    extra = ["--once"] if args.once else []
    if args.compact:
        extra.append("--compact")
    # BUG-MSO-2026-0425: point the monitor at the artefact plane (solo/shared),
    # not the product repo's frozen .mso.
    _run("fleet_monitor.py", extra, ws, artefact_dir=_artefact_dir(ws))


def _doctor_finding_payload(f) -> dict:
    return {
        "checkId": f.check_id,
        "subjectId": f.subject_id,
        "severity": f.severity,
        "title": f.title,
        "detail": f.detail,
        "firstSeenAt": f.firstSeenAt,
        "suggestedCommand": f.suggestedCommand,
        "scope": f.scope,
        "requires": list(f.requires),
    }


def _doctor_exit_code(
    findings, severity_rank, fail_at: str = "high", *, definition_invalid: bool = False,
) -> int:
    # PLAN-PLN-MSO-2026-0504 §5.5 point 4 (FTR-MSO-2026-0532): a patrol
    # definition that failed to resolve must fail the run even when every
    # check that DID run (against the shipped-default fallback) passed —
    # "healthy" must never look identical to "silently ran a shorter list".
    if definition_invalid:
        return 1
    threshold = severity_rank(fail_at)
    return 1 if any(severity_rank(f.severity) >= threshold for f in findings) else 0


def _print_doctor_finding(label: str, f) -> None:
    print(f"\n[{label}/{f.severity.upper()}] {f.check_id} — {f.title}")
    print(f"  {f.detail}")
    if f.suggestedCommand:
        print(f"  suggested: {f.suggestedCommand}")


def cmd_doctor(args: argparse.Namespace) -> None:
    """Run the patrol — deterministic fleet-health checks, no LLM required.

    PLAN-PLN-MSO-2026-0504 §3 (Dimension A3): every check is a pure read of
    on-disk artefact state, so this works identically whether the dispatcher
    is running, wedged, or was never started — unlike `mso status`, it never
    shells out to a monitor process.

    §5 (patrol-definition resolution, FTR-MSO-2026-0532): which checks run,
    and at what severity, is governed by the four-tier resolved definition
    (bundle > pack > workspace.json > shipped default) rather than every
    registered check running unconditionally at its registered severity.
    `--explain` shows which tier supplied each check; a definition that
    failed to resolve prints a banner and forces a non-zero exit even when
    the checks that DID run (against the shipped-default fallback) are all
    clean.

    §6 (noise control, FTR-MSO-2026-0533): findings are compared against the
    persisted patrol state so the default text output shows only what
    changed (NEW / RESOLVED / ESCALATED) instead of repeating every finding
    on every tick. A tick where nothing changed prints nothing at all and
    only records a heartbeat — `--all` bypasses delta filtering for on-demand
    inspection. `--json` always returns the full current picture (findings +
    delta + resolution) since it is the machine-consumer contract, not the
    human one.

    §7 (multi-fleet scope, FTR-MSO-2026-0535): `--all-projects` is handled by
    a separate function entirely — see `_cmd_doctor_all_projects` — since its
    output shape (one section per registered project plus one machine
    section) is not just this function's payload repeated N times.
    """
    if getattr(args, "all_projects", False):
        _cmd_doctor_all_projects(args)
        return

    # BUG-MSO-2026-0672 F1: `--single-check` is reached ONLY via a headless
    # subprocess spawn (hub/server.py's `_run_single_check_subprocess`) — it
    # is never invoked interactively. That subprocess used to hand the
    # target workspace ONLY through the ambient MAESTRO_DIR env var, on the
    # false assumption (this branch's own prior comment claimed it, wrongly)
    # that `find_workspace()` — used by every OTHER branch of this function —
    # would honour it. It does not: `find_workspace()` deliberately walks up
    # from cwd and ignores MAESTRO_DIR (BUG-MSO-2026-0425) — correct for an
    # interactive `mso doctor`, where cwd is the product repo and an ambient
    # MAESTRO_DIR must not retarget it, but wrong here, in two concrete ways
    # verified empirically:
    #   (a) cwd's own .mso/config can be absent entirely — find_workspace()
    #       then raises, and since it used to run UNCONDITIONALLY before
    #       this branch was ever reached, that made every LEAD Run in that
    #       deployment permanently refused, while the button still renders
    #       enabled.
    #   (b) cwd's own .mso/config can be stale or belong to a different
    #       fleet — find_workspace() happily resolves THAT workspace,
    #       silently letting this safety gate (added by BUG-MSO-2026-0662 F1
    #       specifically to stop `mso cleanup` firing at a healthy
    #       dispatcher) be satisfied by another fleet's state instead of the
    #       one actually being acted on — the workspace-contamination class
    #       (BUG-0601/0638/0643/0656).
    # An ambient env var is also the wrong SHAPE of fix on its own — it is
    # silently subject to whatever else in the process environment happens
    # to set MAESTRO_DIR (test isolation fixtures do exactly this). The
    # explicit `--maestro-dir` argument below is what "pass the workspace
    # explicitly in a form cmd_doctor actually honours" means: an argv value
    # this one branch reads directly, never inferred from cwd or from
    # ambient environment. `_run_single_check_subprocess` now passes it. A
    # direct `--single-check` invocation with no `--maestro-dir` (there is
    # no other real caller, but this keeps the primitive usable standalone)
    # falls back to the ordinary find_workspace() resolution unchanged.
    single_check_id = getattr(args, "single_check", None)
    if single_check_id:
        from maestro.patrol import run_single_check

        explicit_dir = getattr(args, "maestro_dir", None)
        if explicit_dir:
            # BUG-MSO-2026-0686 F4: validate + normalise, not a raw Path().resolve().
            artefact_root = _resolve_explicit_mso_dir(explicit_dir)
            workspace_for_policy = Path.cwd()
        else:
            ws = find_workspace(getattr(args, "project", None))
            artefact_root = _artefact_dir(ws)
            workspace_for_policy = ws

        single_result = run_single_check(
            artefact_root, single_check_id, getattr(args, "subject_id", "") or "",
            workspace=workspace_for_policy,
        )
        print(json.dumps({
            "verified": single_result.verified,
            "stillOpen": single_result.still_open,
            "reason": single_result.reason,
        }))
        return

    ws = find_workspace(getattr(args, "project", None))
    # BUG-MSO-2026-0425: read the artefact plane (solo/shared), not the
    # product repo's frozen .mso.
    artefact_root = _artefact_dir(ws)

    from maestro.patrol import run_patrol
    from maestro.patrol.registry import severity_rank
    from maestro.patrol.state import compute_delta, default_state_path, load_state, save_state

    # `workspace=ws` (the product-repo root) is what lets the resolver reach
    # the division-pack pin and governance policy bundles for the pack/bundle
    # tiers (FTR-MSO-2026-0532, PLAN-PLN-MSO-2026-0504 §5) — both live
    # relative to the product repo, not the artefact plane.
    result = run_patrol(artefact_root, workspace=ws)
    now = datetime.now(timezone.utc)

    state_path = default_state_path(artefact_root)
    previous_state = load_state(state_path)
    delta, new_state = compute_delta(previous_state, result.findings, now=now)
    save_state(state_path, new_state)

    open_findings = delta.open_findings()
    show_all = getattr(args, "all", False)
    explain = getattr(args, "explain", False)
    definition_invalid = bool(result.definition is not None and result.definition.invalid)
    banner = result.definition.banner if (definition_invalid and result.definition.banner) else None

    if args.json:
        # PLAN-PLN-MSO-2026-0584 Dimension D: the fingerprint is what
        # `mso lead ack --fingerprint <fp>` needs — surfaced here (and on
        # every delta sub-list) so an operator can go from "I see this
        # finding" to "I can acknowledge it" without a second tool.
        from maestro.patrol.state import is_acknowledged as _is_acked
        payload = {
            "generatedAt": result.generated_at,
            "checksRun": result.checks_run,
            "findings": [
                {**_doctor_finding_payload(d.finding), "fingerprint": d.fingerprint,
                 "acknowledged": _is_acked(new_state, d.fingerprint, d.finding.severity, now=now)}
                for d in delta.open_delta_findings()
            ],
            "delta": {
                "new": [{**_doctor_finding_payload(d.finding), "fingerprint": d.fingerprint} for d in delta.new],
                "resolved": [{**_doctor_finding_payload(d.finding), "fingerprint": d.fingerprint} for d in delta.resolved],
                "escalated": [{**_doctor_finding_payload(d.finding), "fingerprint": d.fingerprint} for d in delta.escalated],
                "unchangedCount": len(delta.unchanged),
            },
            "skipped": [
                {"checkId": s.check_id, "reason": s.reason} for s in result.skipped
            ],
        }
        if result.definition is not None and result.definition.banner:
            payload["definitionInvalid"] = result.definition.banner
        if explain and result.definition is not None:
            payload["resolution"] = {
                "checks": {
                    cid: {
                        "tier": rc.source_tier, "enabled": rc.enabled,
                        "severity": rc.severity, "scope": rc.scope, "params": rc.params,
                    }
                    for cid, rc in sorted(result.definition.checks.items())
                },
                "unknownChecks": list(result.definition.unknown_warnings),
                "refusals": list(result.definition.refusals),
            }
        if explain:
            # FTR-MSO-2026-0534: resolved-provider explain is independent of
            # whether the patrol definition itself resolved, so it is not
            # gated on result.definition like the "checks" block above.
            payload.setdefault("resolution", {})["providers"] = [
                {
                    "kind": r.kind, "providerId": r.provider_id, "tier": r.tier,
                    "available": r.available, "reason": r.reason,
                }
                for r in _resolve_providers_explain(ws)
            ]
        print(json.dumps(payload, indent=2))
    elif show_all:
        _prod = current_persona().term("product")
        if banner:
            print(f"[{_prod}] doctor: ⚠ {banner}")
        if not open_findings:
            print(f"[{_prod}] doctor: {result.checks_run} check(s) run, no findings.")
        else:
            print(
                f"[{_prod}] doctor: {result.checks_run} check(s) run, "
                f"{len(open_findings)} finding(s)."
            )
            for f in sorted(open_findings, key=lambda x: -severity_rank(x.severity)):
                _print_doctor_finding("OPEN", f)
        if delta.resolved:
            print(f"\n{len(delta.resolved)} finding(s) resolved since the last run:")
            for d in delta.resolved:
                print(f"  {d.finding.check_id} — {d.finding.title}")
        if result.skipped:
            print(f"\n{len(result.skipped)} check(s) skipped:")
            for s in result.skipped:
                print(f"  {s.check_id}: {s.reason}")
    elif delta.has_changes:
        _prod = current_persona().term("product")
        if banner:
            print(f"[{_prod}] doctor: ⚠ {banner}")
        print(
            f"[{_prod}] doctor: {len(delta.new)} new, {len(delta.escalated)} escalated, "
            f"{len(delta.resolved)} resolved, {len(delta.unchanged)} unchanged."
        )
        for f in sorted((d.finding for d in delta.new), key=lambda x: -severity_rank(x.severity)):
            _print_doctor_finding("NEW", f)
        for f in sorted(
            (d.finding for d in delta.escalated), key=lambda x: -severity_rank(x.severity)
        ):
            _print_doctor_finding("ESCALATED", f)
        for d in delta.resolved:
            print(f"\n[RESOLVED] {d.finding.check_id} — {d.finding.title}")
        if result.skipped:
            print(f"\n{len(result.skipped)} check(s) skipped:")
            for s in result.skipped:
                print(f"  {s.check_id}: {s.reason}")
    else:
        # a no-change tick (PLAN §6 point 4) — print NOTHING beyond the
        # definition-invalid banner above, if any. The heartbeat was already
        # recorded via save_state(); "the patrol itself has stopped running"
        # stays detectable without the operator being nagged about findings
        # that have not moved since the last tick.
        _prod = current_persona().term("product")
        if banner:
            print(f"[{_prod}] doctor: ⚠ {banner}")

    if explain and result.definition is not None and not args.json:
        # --json already folds this into payload["resolution"] above — a
        # second, human-formatted printout here would corrupt the JSON output
        # with trailing non-JSON text.
        print("\nResolved patrol definition (mso doctor --explain):")
        for cid, rc in sorted(result.definition.checks.items()):
            state = "enabled " if rc.enabled else "disabled"
            params = f" params={rc.params}" if rc.params else ""
            print(f"  {cid:<32} tier={rc.source_tier:<9} {state} severity={rc.severity}{params}")
        for w in result.definition.unknown_warnings:
            print(f"  WARN: {w}")
        for r in result.definition.refusals:
            print(f"  REFUSED: {r}")

    if explain and not args.json:
        # FTR-MSO-2026-0534: independent of the patrol-definition section
        # above — providers resolve regardless of whether the patrol
        # definition itself resolved.
        print("\nResolved providers (mso doctor --explain):")
        for r in _resolve_providers_explain(ws):
            if r.available:
                print(f"  {r.kind:8s} -> {r.provider_id} (tier: {r.tier})")
            else:
                print(f"  {r.kind:8s} -> {r.provider_id} (tier: {r.tier}) — {r.reason}")

    sys.exit(_doctor_exit_code(
        open_findings, severity_rank, definition_invalid=definition_invalid,
    ))


def _resolve_providers_explain(ws: Path) -> list:
    """Resolve every provider kind for ``mso doctor --explain``
    (FTR-MSO-2026-0534 acceptance criteria: "prints the resolved provider per
    kind"). Shared by both the JSON and text branches of ``cmd_doctor``.
    """
    from maestro.providers import PROVIDER_KINDS, resolve_explain

    return [resolve_explain(kind, workspace=ws) for kind in PROVIDER_KINDS]


def _cmd_doctor_all_projects(args: argparse.Namespace) -> None:
    """`mso doctor --all-projects` — PLAN-PLN-MSO-2026-0504 §7 / FTR-MSO-2026-0535.

    Scans every project registered in ``~/.maestro/projects.json``
    (``registry.list_projects()``), producing one section per fleet plus one
    machine-scope section — NEVER once per workspace (§7's whole point: three
    fleets on one box must not each report the same 8 orphaned processes).
    Each project's own ``run_patrol()`` call and the machine-scope lease it
    acquires internally (wired into ``maestro.patrol.run_patrol`` — see that
    module) are what make this work: only the first project to reach a
    machine-scope check each tick actually runs and reports it, and every
    later project's identical attempt is recorded as skipped rather than
    silently repeated.

    Each project keeps its OWN persisted patrol state
    (``<project's artefact_root>/state/patrol-state.json``), so delta/age
    tracking stays correctly scoped per fleet exactly as it is for a normal
    single-workspace `mso doctor` run.
    """
    from maestro import registry
    from maestro.patrol import run_patrol
    from maestro.patrol.registry import severity_rank
    from maestro.patrol.state import compute_delta, default_state_path, load_state, save_state

    now = datetime.now(timezone.utc)
    _prod = current_persona().term("product")

    sections: list[dict] = []
    for acronym, entry in sorted(registry.list_projects().items()):
        path = entry.get("path")
        if not path:
            continue
        proj_ws = Path(path)
        if not proj_ws.exists():
            continue
        try:
            artefact_root = _artefact_dir(proj_ws)
        except Exception:
            continue

        result = run_patrol(artefact_root, now=now, workspace=proj_ws)
        state_path = default_state_path(artefact_root)
        previous_state = load_state(state_path)
        delta, new_state = compute_delta(previous_state, result.findings, now=now)
        save_state(state_path, new_state)

        open_findings = delta.open_findings()
        definition_invalid = bool(result.definition is not None and result.definition.invalid)
        banner = (
            result.definition.banner
            if (definition_invalid and result.definition and result.definition.banner)
            else None
        )
        sections.append({
            "acronym": acronym,
            "result": result,
            "delta": delta,
            "workspace_findings": [f for f in open_findings if f.scope != "machine"],
            "machine_findings": [f for f in open_findings if f.scope == "machine"],
            "banner": banner,
            "definition_invalid": definition_invalid,
        })

    exit_nonzero = any(
        s["definition_invalid"]
        or any(
            severity_rank(f.severity) >= severity_rank("high")
            for f in s["workspace_findings"] + s["machine_findings"]
        )
        for s in sections
    )

    if args.json:
        payload = {
            "generatedAt": now.isoformat(),
            "allProjects": True,
            "projects": {
                s["acronym"]: {
                    "checksRun": s["result"].checks_run,
                    "findings": [_doctor_finding_payload(f) for f in s["workspace_findings"]],
                    "delta": {
                        "new": [_doctor_finding_payload(d.finding) for d in s["delta"].new
                                if d.finding.scope != "machine"],
                        "resolved": [_doctor_finding_payload(d.finding) for d in s["delta"].resolved
                                     if d.finding.scope != "machine"],
                        "escalated": [_doctor_finding_payload(d.finding) for d in s["delta"].escalated
                                      if d.finding.scope != "machine"],
                        "unchangedCount": len(
                            [d for d in s["delta"].unchanged if d.finding.scope != "machine"]
                        ),
                    },
                    "skipped": [
                        {"checkId": sk.check_id, "reason": sk.reason} for sk in s["result"].skipped
                    ],
                    **({"definitionInvalid": s["banner"]} if s["banner"] else {}),
                }
                for s in sections
            },
            "machine": {
                "findings": [
                    _doctor_finding_payload(f) for s in sections for f in s["machine_findings"]
                ],
            },
        }
        print(json.dumps(payload, indent=2))
    else:
        for s in sections:
            print(f"\n=== [{s['acronym']}] ===")
            if s["banner"]:
                print(f"[{_prod}] doctor: ⚠ {s['banner']}")
            wf = s["workspace_findings"]
            if not wf:
                print(f"[{_prod}] doctor: {s['result'].checks_run} check(s) run, no findings.")
            else:
                print(f"[{_prod}] doctor: {s['result'].checks_run} check(s) run, {len(wf)} finding(s).")
                for f in sorted(wf, key=lambda x: -severity_rank(x.severity)):
                    _print_doctor_finding("OPEN", f)

        machine_findings = [f for s in sections for f in s["machine_findings"]]
        print("\n=== [machine] ===")
        if machine_findings:
            for f in sorted(machine_findings, key=lambda x: -severity_rank(x.severity)):
                _print_doctor_finding("OPEN", f)
        else:
            print(f"[{_prod}] doctor: no machine-scope findings.")

    sys.exit(1 if exit_nonzero else 0)


def cmd_usage(args: argparse.Namespace) -> None:
    """Report token usage and estimated cost."""
    ws = find_workspace(getattr(args, "project", None))
    # BUG-MSO-2026-0201: tell the tracker which workspace to read usage from,
    # otherwise it reads its own package dir and reports 0 orders.
    # BUG-MSO-2026-0425: _artefact_dir honours the solo/shared pointer so usage
    # is read from the artefact plane, not the product repo's frozen .mso.
    extra: list[str] = ["--maestro-dir", str(_artefact_dir(ws))]
    # BUG-MSO-2026-0446: --project (and the new --project-path) were resolved
    # locally via find_workspace() but never forwarded to the tracker subprocess,
    # so the transcript auto-detection path never saw them — the error hint
    # ("pass --project @MSO") had no effect. Forward unconditionally so every
    # usage form (summary/report/voyage/order) can honour an explicit override.
    if getattr(args, "project", None):
        extra += ["--project", args.project.lstrip("@")]
    if getattr(args, "project_path", None):
        extra += ["--project-path", args.project_path]
    if args.voyage:
        extra += ["--voyage", args.voyage]
    elif args.order:
        extra += ["--order", args.order]
    elif args.report:
        extra.append("--report")
        if args.output:
            extra += ["--output", args.output]
    else:
        extra.append("--summary")
    _run("fleet_usage_tracker.py", extra, ws)


def cmd_crew(args: argparse.Namespace) -> None:
    """Operate an individual crew instance."""
    ws = find_workspace(getattr(args, "project", None))
    extra = ["--crew", str(args.crew)]
    if args.status:
        extra.append("--status")
    if args.watch:
        extra.append("--watch")
    if args.cleanup:
        extra.append("--cleanup")
    _run("crew.py", extra, ws)


def cmd_verify(args: argparse.Namespace) -> None:
    """Run post-voyage build and test verification."""
    ws = find_workspace(getattr(args, "project", None))
    extra: list[str] = []
    if args.voyage:
        extra += ["--voyage", args.voyage]
    if args.skip_tests:
        extra.append("--skip-tests")
    _run("post_voyage_verify.py", extra, ws)


def cmd_bridge(args: argparse.Namespace) -> None:
    """Manage the Mobile Command Bridge."""
    ws = find_workspace()
    from maestro import bridge as _bridge
    from maestro.identity.gate import require_capability
    from maestro.audit import get_audit_log

    action = args.bridge_action
    _audit = get_audit_log(ws)

    if action == "start":
        require_capability("bridge.start", workspace=ws)
        _bridge.start_poller(ws)
        _bridge.start_bot(ws)
        _audit.append("bridge.command", target="bridge", metadata={"action": "start"})
    elif action == "stop":
        require_capability("bridge.stop", workspace=ws)
        _bridge.stop_poller(ws)
        _bridge.stop_bot(ws)
        _audit.append("bridge.command", target="bridge", metadata={"action": "stop"})
    elif action == "status":
        _bridge.print_status(ws)
    elif action == "test":
        if not args.project:
            raise MaestroUserError(
                "--project required for 'bridge test'",
                hint="mso bridge test --project ADM",
            )
        _bridge.send_test(ws, args.project)
    elif action == "poller-start":
        _bridge.start_poller(ws)
        _audit.append("bridge.command", target="bridge", metadata={"action": "poller-start"})
    elif action == "poller-stop":
        _bridge.stop_poller(ws)
        _audit.append("bridge.command", target="bridge", metadata={"action": "poller-stop"})
    elif action == "bot-start":
        _bridge.start_bot(ws)
        _audit.append("bridge.command", target="bridge", metadata={"action": "bot-start"})
    elif action == "bot-stop":
        _bridge.stop_bot(ws)
        _audit.append("bridge.command", target="bridge", metadata={"action": "bot-stop"})
    elif action == "restart":
        require_capability("bridge.start", workspace=ws)
        require_capability("bridge.stop", workspace=ws)
        _bridge.restart(ws)
        _audit.append("bridge.command", target="bridge", metadata={"action": "restart"})
    elif action == "setup":
        require_capability("bridge.start", workspace=ws)
        _bridge.setup_wizard(ws)
        _audit.append("bridge.command", target="bridge", metadata={"action": "setup"})


def cmd_hub(args: argparse.Namespace) -> None:
    """Manage the Maestro Hub dashboard server."""
    from maestro import auth
    from maestro.hub import daemon as _hub
    action = args.hub_action
    if action == "start":
        auth.require_tier(auth.HUB_TIERS, feature="Maestro Hub")
        _hub.start_hub(port=args.port, open_browser=args.open, force=getattr(args, "force", False))
    elif action == "setup":
        auth.require_tier(auth.HUB_TIERS, feature="Maestro Hub")
        from maestro.hub import setup as _setup
        _setup.run_setup(
            mode=args.mode,
            output_dir=args.output_dir,
            dry_run=args.dry_run,
            force=getattr(args, "force", False),
        )
    elif action == "stop":
        if not _hub.stop_hub():
            sys.exit(1)
    elif action == "status":
        _hub.print_status(port=args.port)


def cmd_lead(args: argparse.Namespace) -> None:
    """Manage the resident LEAD sub-agent (PLAN-PLN-MSO-2026-0504 §3,
    FTR-MSO-2026-0536). Pro/Team/Enterprise — gated on `start`/`restart`/`run`
    (the actions that actually launch or execute the agent), never on the
    read-only `status` or the always-available `stop`, mirroring the Hub's
    shape of gating only the actions that spend resources.

    `stand-down` (PLAN-PLN-MSO-2026-0584 Dimension A) joins `stop` as
    deliberately ungated: turning LEAD OFF must always be possible on a
    community-tier workspace. `resume` — turning it back ON — is gated,
    same as `start`/`restart`."""
    from maestro import auth
    from maestro.lead import daemon as _lead

    # Usage validation BEFORE workspace resolution: `mso lead run` without
    # --once is a malformed invocation, and telling the operator "no workspace
    # found" first is both wrong and unhelpful — the flag is missing whether or
    # not they are standing in a workspace.
    if args.lead_action == "run" and not getattr(args, "once", False):
        raise MaestroUserError(
            "'mso lead run' requires --once (foreground single pass).",
            hint="mso lead run --once",
        )

    ws = find_workspace(getattr(args, "project", None))
    artefact_root = _artefact_dir(ws)
    action = args.lead_action

    if action == "start":
        auth.require_tier(auth.LEAD_AGENT_TIERS, feature="The resident LEAD agent")
        _lead.start(artefact_root, workspace_root=ws, force=getattr(args, "force", False))
    elif action == "stop":
        # BUG-MSO-2026-0724: `stop()` now blocks until the daemon is CONFIRMED
        # gone and returns False if it could not be. Exiting non-zero there
        # (mirroring `mso hub stop` since BUG-MSO-2026-0516) is what stops a
        # script — or an operator — reading "stop succeeded" off a daemon that
        # is still alive.
        if not _lead.stop(artefact_root):
            sys.exit(1)
    elif action == "restart":
        auth.require_tier(auth.LEAD_AGENT_TIERS, feature="The resident LEAD agent")
        if not _lead.restart(artefact_root, workspace_root=ws):
            sys.exit(1)
    elif action == "status":
        _lead.print_status(artefact_root)
    elif action == "run":
        auth.require_tier(auth.LEAD_AGENT_TIERS, feature="The resident LEAD agent")
        # FTR-MSO-2026-0585 (RC-2): `ws` (the product-repo root, already
        # resolved above) is threaded through so a foreground pass's
        # checks_run matches `mso doctor`'s on this same workspace.
        result = _lead.run_foreground_once(artefact_root, workspace_root=ws)
        print(f"[LEAD] {result.outcome.value}: {result.summary}")
        if result.detail and result.detail != result.summary:
            print(f"  {result.detail}")
    elif action == "stand-down":
        from maestro.lead.agent import set_stand_down
        set_stand_down(artefact_root, True)
        print("[LEAD] Standing down — ticks will be skipped until resumed "
              "(the daemon process itself is left running).")
    elif action == "resume":
        auth.require_tier(auth.LEAD_AGENT_TIERS, feature="The resident LEAD agent")
        from maestro.lead.agent import set_stand_down
        set_stand_down(artefact_root, False)
        print("[LEAD] Resumed — ticks will run again.")
    elif action == "ack":
        # PLAN-PLN-MSO-2026-0584 Dimension D: deliberately UNGATED, mirroring
        # `stand-down`/`stop` — acknowledging a finding is an observability
        # action on data the operator can already see, not a resource-
        # spending action like start/restart/run/resume.
        fp = getattr(args, "fingerprint", None)
        if not fp:
            raise MaestroUserError(
                "'mso lead ack' requires --fingerprint <fp>.",
                hint="mso lead status  # lists open findings with their fingerprints",
            )
        import getpass
        from maestro.patrol.state import ACK_TTL_DAYS_DEFAULT, UnknownFindingError, acknowledge_finding
        by = getattr(args, "by", None) or getpass.getuser()
        days = getattr(args, "days", None) or ACK_TTL_DAYS_DEFAULT
        try:
            entry = acknowledge_finding(
                artefact_root, fp, by=by, note=getattr(args, "note", None) or "", ttl_days=days,
            )
        except (UnknownFindingError, ValueError) as exc:
            raise MaestroUserError(str(exc))
        print(
            f"[LEAD] Acknowledged {fp} by {by} at severity={entry['severity']} — "
            f"expires {entry['expiresAt']}. Escalation past {entry['severity']} or "
            f"expiry makes it visible again; it stays counted in the strip either way."
        )
    elif action == "unack":
        fp = getattr(args, "fingerprint", None)
        if not fp:
            raise MaestroUserError(
                "'mso lead unack' requires --fingerprint <fp>.",
                hint="mso lead status  # lists open findings with their fingerprints",
            )
        from maestro.patrol.state import unacknowledge_finding
        existed = unacknowledge_finding(artefact_root, fp)
        if existed:
            print(f"[LEAD] Un-acknowledged {fp} — it will be delivered again if NEW/ESCALATED.")
        else:
            print(f"[LEAD] No acknowledgement found for {fp} — nothing to do.")


def cmd_chart(args: argparse.Namespace) -> None:
    """Manage charts — the Phase 1 read-only "X-ray" (``show``) plus the
    Phase 2 authoring story (``new``/``validate`` — FTR-MSO-2026-0519,
    PLAN-PLN-MSO-2026-0508 section 6).
    """
    action = args.chart_action
    if action == "show":
        _cmd_chart_show(args)
    elif action == "new":
        _cmd_chart_new(args)
    elif action == "validate":
        _cmd_chart_validate(args)


def _cmd_chart_show(args: argparse.Namespace) -> None:
    """Render a chart — the Phase 1 "X-ray" compiled from roleSequence,
    dependsOn, gates.json, and the ledger (FTR-MSO-2026-0496).

    Community-tier per PLAN-0143 ruling 0a#3: chart visualization is the
    marketing surface and must work without a licence, so this gates
    through ``auth.require_tier`` and nothing else — it never touches token
    validation directly (ruling §6).
    """
    from maestro import auth
    from maestro.core import charts as _charts

    auth.require_tier(auth.CHART_VIEW_TIERS, feature="mso chart show")

    ws = find_workspace(getattr(args, "project", None))
    # Charts read orders/voyages — an artefact-plane read, so this must
    # resolve through _artefact_dir() (BUG-MSO-2026-0425), not the raw
    # resolve_artefact_dir(ws), or a solo/shared-mode workspace would
    # compile against the product repo's frozen, stale .mso/ instead of the
    # actual artefact repo.
    mso_dir = _artefact_dir(ws)
    target = args.target

    if target.startswith("VOY-"):
        chart = _charts.compile_voyage_chart(target, workspace_dir=mso_dir)
    else:
        chart = _charts.compile_order_chart(target, workspace_dir=mso_dir)

    if not chart.nodes:
        raise MaestroUserError(
            f"No chart data found for '{target}'.",
            hint="Check the voyage/order id and that it exists under .mso/voyages or .mso/queues|orders.",
        )

    fmt = args.format
    if fmt == "mermaid":
        print(_charts.render_mermaid(chart))
    elif fmt == "json":
        print(json.dumps(chart.to_dict(), indent=2))
    else:
        print(_charts.render_ascii(chart))


def _cmd_chart_new(args: argparse.Namespace) -> None:
    """``mso chart new --from-voyage VOY-ID [-o path]`` — compile a voyage's
    chart (Phase 1's ``compile_voyage_chart``) and serialise it as a schema-v1
    chart file under ``charts/`` (plan section 6). Pro tier and above: this
    authors a durable artefact, unlike the community-tier ``show``.
    """
    import re as _re

    from maestro import auth
    from maestro.core import charts as _charts
    from maestro.core import chart_schema

    auth.require_tier(auth.CHART_EXEC_TIERS, feature="mso chart new")

    ws = find_workspace(getattr(args, "project", None))
    mso_dir = _artefact_dir(ws)

    voyage_id = args.from_voyage
    m = _re.match(r"^VOY-([A-Z0-9]{2,10})-(\d{4})-\d{4,}$", voyage_id)
    if not m:
        raise MaestroUserError(
            f"Invalid voyage id: {voyage_id!r}",
            hint="Expected VOY-{PRJ}-{YEAR}-{SEQ}, e.g. VOY-MSO-2026-0144",
        )
    project = m.group(1)

    compiled = _charts.compile_voyage_chart(voyage_id, workspace_dir=mso_dir)
    if not compiled.nodes:
        raise MaestroUserError(
            f"No chart data found for voyage '{voyage_id}'.",
            hint="Check the voyage id and that it has orders under .mso/voyages or .mso/queues|orders.",
        )

    year = datetime.now(timezone.utc).strftime("%Y")
    chart_id = chart_schema.next_chart_id(mso_dir, project, year)
    spec = chart_schema.from_compiled_chart(compiled, chart_id, voyage_id)

    if getattr(args, "output", None):
        out_path = Path(args.output)
    else:
        out_path = mso_dir / chart_schema.CHARTS_SUBDIR / f"{chart_id}.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(spec.to_dict(), indent=2) + "\n", encoding="utf-8")

    print(f"[Chart] Created {chart_id} from {voyage_id} -> {out_path}")

    issues = chart_schema.validate(spec, path=out_path, workspace_dir=mso_dir)
    if issues:
        print(f"[Chart] {len(issues)} validation issue(s) to resolve before "
              f"enabling charts.enabled:")
        for i, issue in enumerate(issues, 1):
            print(f"  {i}. {issue}")


def _cmd_chart_validate(args: argparse.Namespace) -> None:
    """``mso chart validate [<file>|--all]`` — run V1-V10 against one chart
    file or every chart under ``charts/``, exit 1 on any error. Offline;
    validation never requires a licence (plan section 6 — "a validator that
    requires a licence is a support burden").
    """
    from maestro.core import chart_schema

    ws = find_workspace(getattr(args, "project", None))
    mso_dir = _artefact_dir(ws)

    if getattr(args, "all", False):
        charts_dir = mso_dir / chart_schema.CHARTS_SUBDIR
        paths = sorted(charts_dir.glob("*.json")) if charts_dir.is_dir() else []
        if not paths:
            print("[Chart] No charts found under charts/.")
            return
    else:
        if not getattr(args, "file", None):
            raise MaestroUserError(
                "A chart file or --all is required.",
                hint="mso chart validate <file> | mso chart validate --all",
            )
        paths = [Path(args.file)]

    any_errors = False
    for p in paths:
        try:
            spec = chart_schema.load_chart(p)
        except Exception as exc:
            print(f"[Chart] {p}: FAILED TO PARSE — {exc}")
            any_errors = True
            continue
        issues = chart_schema.validate(spec, path=p, workspace_dir=mso_dir)
        if not issues:
            print(f"[Chart] {p}: OK")
        else:
            any_errors = True
            print(f"[Chart] {p}: {len(issues)} error(s)")
            for i, issue in enumerate(issues, 1):
                print(f"  {i}. {issue}")

    if any_errors:
        raise SystemExit(1)


# ---------------------------------------------------------------------------
# `mso order why` / `mso voyage why` — FTR-MSO-2026-0719 (PLAN-FTR-MSO-2026-0700 §5.1)
# ---------------------------------------------------------------------------
#
# One renderer, two verbs. The model itself lives in `maestro/core/blockage.py`
# (FTR-MSO-2026-0700) and is READ here, never re-derived: an order's cause,
# evidence and options are computed in exactly one place so this CLI, the Hub
# panel, `mso doctor` and the LEAD daemon cannot disagree about why something
# is stuck. A second opinion rendered in a terminal is worse than no opinion.

def _blockage_wrap(text: str, indent: str = "    ", width: int = 84) -> "list[str]":
    """Wrap a paragraph for the terminal, preserving deliberate line breaks."""
    import textwrap
    out: "list[str]" = []
    for para in (text or "").splitlines():
        if not para.strip():
            out.append("")
            continue
        out.extend(textwrap.wrap(para.strip(), width=width,
                                 initial_indent=indent,
                                 subsequent_indent=indent) or [indent])
    return out


def _render_blockage(blockage) -> None:
    """Print one `Blockage` — title, cause, evidence, blockers, options.

    Every evidence path is on a line of its own and UNWRAPPED, so it can be
    copy-pasted into an editor; every option's command likewise. An operator
    reading this has already lost time to the thing being stuck, and a path
    they have to reassemble from two wrapped fragments costs them more.
    """
    from maestro.core.blockage import age_phrase

    print()
    print(f"  {blockage.title()}")
    print("  " + "-" * 76)
    for line in _blockage_wrap(blockage.cause, indent="  "):
        print(line)
    print()

    meta = [("Kind", blockage.kind), ("Severity", blockage.severity)]
    if blockage.since:
        age = age_phrase(blockage.since)
        meta.append(("Since", f"{blockage.since}  ({age})" if age else blockage.since))
    if blockage.voyage_id and blockage.voyage_id != blockage.subject_id:
        meta.append(("Voyage", blockage.voyage_id))
    if blockage.role:
        meta.append(("Role", blockage.role))
    for label, value in meta:
        print(f"  {label + ':':<10}{value}")

    if blockage.detail and blockage.detail != blockage.cause:
        print()
        print("  Detail:")
        for line in _blockage_wrap(blockage.detail):
            print(line)

    if blockage.evidence:
        print()
        print("  Evidence:")
        for ev in blockage.evidence:
            print(f"    - {ev.label}")
            # Path / branch print RAW and unwrapped — see the docstring.
            if ev.path:
                print(f"      {ev.path}")
            if ev.branch:
                print(f"      branch: {ev.branch}")
            if ev.detail:
                for line in _blockage_wrap(ev.detail, indent="      "):
                    print(line)

    if blockage.blockers:
        print()
        print("  Blocked by:")
        for ref in blockage.blockers:
            head = f"    - {ref.order_id}"
            if ref.status:
                head += f"  [{ref.status}]"
            if ref.kind:
                head += f"  {ref.kind}"
            print(head)
            if ref.cause:
                for line in _blockage_wrap(ref.cause, indent="      "):
                    print(line)

    if blockage.options:
        print()
        print("  Options:")
        for idx, opt in enumerate(blockage.options, start=1):
            label = opt.label + ("   [recommended]" if opt.recommended else "")
            print(f"    {idx}. {label}")
            if opt.command:
                print(f"       {opt.command}")
            if opt.risk_note:
                # BUG-MSO-2026-0696's honesty rule reaches the terminal here:
                # the cost of an option is printed WITH it, never a footnote
                # further down that an operator can act before reading.
                wrapped = _blockage_wrap(opt.risk_note, indent="", width=68)
                print(f"       risk: {wrapped[0].strip()}" if wrapped else "")
                for line in wrapped[1:]:
                    print(f"             {line.strip()}")
    print()


def _emit_blockage(blockage, subject_id: str, subject_kind: str, status: str,
                   as_json: bool) -> None:
    """Render, or emit the wire shape verbatim under `--json`.

    Under `--json` a blocked subject emits EXACTLY `Blockage.to_dict()` — the
    same dict the Hub endpoints serve — so a caller can round-trip it without
    knowing which surface produced it. "Not blocked" is a successful answer,
    not an error: exit 0, `{"blocked": false}`, and a plain sentence for a
    human. A verb that exits non-zero for "nothing is wrong" trains operators
    to stop reading its exit code.
    """
    if as_json:
        if blockage is None:
            print(json.dumps({
                "subjectId": subject_id,
                "subjectKind": subject_kind,
                "blocked": False,
                "status": status,
            }, indent=2))
        else:
            print(json.dumps(blockage.to_dict(), indent=2))
        return

    if blockage is None:
        suffix = f" ({status})" if status else ""
        print(f"{subject_id} is not blocked{suffix}.")
        return

    _render_blockage(blockage)


def cmd_voyage(args: argparse.Namespace) -> None:
    """Manage voyages."""
    # BUG-MSO-2026-0690: required-argument checks must run BEFORE any
    # --maestro-dir validation below. `--project` is required for `create`;
    # `--maestro-dir` is optional (and only ever exposed on the `reconcile`
    # subparser in real argv — see the next comment). A missing required
    # argument must be reported as such, not masked by an unrelated optional-
    # argument complaint. Kept action-scoped (`voyage_action == "create"`)
    # since `list`/`status`/`reconcile` have no required args of their own.
    if args.voyage_action == "create":
        if not args.project:
            raise MaestroUserError(
                "--project required for 'voyage create'",
                hint="mso voyage create 'My voyage' --project MSO",
            )
        _create_title = " ".join(args.title)
        if not _create_title:
            raise MaestroUserError(
                "<title> required for 'voyage create'",
                hint="mso voyage create 'My voyage title' --project MSO",
            )

    # BUG-MSO-2026-0675 F1: --maestro-dir is only exposed on the `reconcile`
    # subparser — the same explicit-argv treatment BUG-MSO-2026-0672 F1 gave
    # cmd_doctor's --single-check branch and cmd_cleanup gets above, for the
    # identical reason (find_workspace() deliberately ignores MAESTRO_DIR,
    # BUG-MSO-2026-0425, and can otherwise resolve a DIFFERENT fleet above
    # cwd or raise). `create`/`list`/`status` never set this attribute, so
    # getattr below is always None for them and their behaviour is
    # unchanged. The caller (run_verbs._handle_voyage_reconcile) sets cwd to
    # the product repo before spawning this process, so cwd doubles as the
    # workspace root below.
    explicit_dir = getattr(args, "maestro_dir", None)
    if explicit_dir:
        ws = Path.cwd()
        # BUG-MSO-2026-0686 F4: same validate-and-normalise treatment as
        # cmd_cleanup — the raw argv value is no longer trusted as-is.
        mso_dir = _resolve_explicit_mso_dir(explicit_dir)
    else:
        ws = find_workspace(getattr(args, "project", None))
        # BUG-MSO-2026-0682: found via this order's mandated `ws` enumeration,
        # not one of the three named findings. This was a PLAIN
        # `resolve_artefact_dir(ws)` (`ws / ".mso"`, no solo/shared pointer
        # resolution — see that function's own docstring) rather than
        # `_artefact_dir(ws)` (`artefact_root_for(ws)`, the pointer-aware
        # helper `cmd_cleanup`/`cmd_order`/`cmd_backup`/`cmd_restore` all use).
        # In solo/shared mode `ws` is the product-repo root, whose own `.mso`
        # is only the frozen pointer stub (BUG-MSO-2026-0425) — so
        # `voyage create`/`list`/`status`, and a directly-invoked (no
        # `--maestro-dir`) `voyage reconcile`, all wrote/read voyage JSON
        # against the STALE local mirror instead of the real artefact plane,
        # invisible to the dispatcher. Byte-identical to the old behaviour in
        # embedded mode (no pointer to follow).
        mso_dir = _artefact_dir(ws)

    if args.voyage_action == "create":
        # FTR-MSO-2026-0618 / PLAN-PLN-MSO-2026-0556 Order 2: the whole
        # scan-allocate-assert-write block that used to live here is now
        # maestro/core/voyage_core.py, so `mso voyage create`, the Slack
        # bridge and (Order 3) the Hub share ONE implementation. The bridge's
        # copy had already drifted — `voyageId` instead of `id`,
        # `len(existing)+1` over voyages/active only, no branch field, no
        # priority, no lock — which is exactly the shape review_core.py's
        # docstring records the cost of (BUG-MSO-2026-0486). Everything
        # BUG-MSO-2026-0571 (allocation lock) and FTR-MSO-2026-0574 (remote
        # fetch + shared-mode reservation) added is preserved inside the core,
        # where the other two callers finally inherit it too.
        #
        # `require_capability("voyage.create")` moved into the core with it —
        # the FTR-MSO-2026-0492 shape — so it is not re-checked here.
        from maestro.core.order_ids import OrderValidationError
        from maestro.core.voyage_core import VoyageIdCollision, create_voyage

        # --project / <title> are validated up-front, before --maestro-dir
        # resolution — see the BUG-MSO-2026-0690 comment at the top of this
        # function. `_create_title` is that same already-validated value.
        title = _create_title

        # D4: no git side effect by default. ensure_voyage_branch_exists()
        # already creates the branch on the REMOTE at first dispatch with no
        # checkout, so the old unconditional `git checkout -b` was redundant
        # and — in the primary workspace checkout — actively hazardous (the
        # CONVERGENCE_PRIMARY_PROTECTED bug class). --checkout preserves the
        # old behaviour for anyone who relied on it, and is deprecated.
        want_checkout = bool(getattr(args, "checkout", False))
        try:
            created = create_voyage(
                mso_dir,
                project=args.project,
                title=title,
                created_by="cli",
                create_branch=want_checkout,
                repo_root=ws,
            )
        except VoyageIdCollision as exc:
            raise MaestroUserError(str(exc), hint=exc.hint)
        except OrderValidationError as exc:
            raise MaestroUserError(str(exc))

        if not want_checkout:
            print(f"[Voyage] Created {created.voyage_id} — branch: "
                  f"{created.branch} (created at first dispatch)")
        elif created.branch_error:
            print(f"[Voyage] Created {created.voyage_id} (branch already "
                  f"exists or git error: {created.branch_error})")
        else:
            print(f"[Voyage] Created {created.voyage_id} — branch: {created.branch}")
        if want_checkout:
            print("[Voyage] Note: --checkout is deprecated. The voyage branch "
                  "is created on the remote at first dispatch; a local "
                  "checkout is not required.")
    elif args.voyage_action == "list":
        voyages_dir = mso_dir / "voyages" / "active"
        if not voyages_dir.exists():
            print("[Voyage] No active voyages found")
            return
        entries = sorted(voyages_dir.glob("*.json"))
        if not entries:
            print("[Voyage] No active voyages found")
            return
        for f in entries:
            try:
                v = json.loads(f.read_text(encoding="utf-8"))
                if args.project and v.get("project") != args.project:
                    continue
                order_count = len(v.get("orders", []))
                print(f"  {v['id']}  |  {v.get('status', '?'):8s}  |  {order_count} orders  |  {v.get('title', '')}")
            except Exception:
                continue

    elif args.voyage_action == "status":
        voyage_id = args.voyage_id
        voyages_dir = mso_dir / "voyages" / "active"
        voyage_path = voyages_dir / f"{voyage_id}.json"
        if not voyage_path.exists():
            raise MaestroUserError(f"Voyage not found: {voyage_id}")
        v = json.loads(voyage_path.read_text(encoding="utf-8"))
        # BUG-MSO-2026-0300 (GKT F6): bare v['id'] crashed on manifests without
        # an 'id' field — every other field here already uses .get().
        print(f"\n  VOYAGE: {v.get('id') or v.get('voyageId') or voyage_id}")
        print(f"  Title:   {v.get('title', '')}")
        print(f"  Status:  {v.get('status', '')}")
        print(f"  Branch:  {v.get('branch', '')}")
        print(f"  Project: {v.get('project', '')}")
        # FTR-MSO-2026-0379: a voyage may span several repos (one PR per repo).
        # Render a per-repo branch/PR line, tolerating BOTH manifest shapes —
        # the new prUrls map {repo: {prNumber, prUrl}} and the legacy flat
        # prNumber/prUrl (single-repo). BUG-0348 lesson: never assume one shape.
        _branch = v.get("branch", "")
        _prurls = v.get("prUrls") if isinstance(v.get("prUrls"), dict) else {}
        _repos = v.get("targetRepos")
        if not isinstance(_repos, list):
            _repos = []
        # Union of repos named in targetRepos and any prUrls keys.
        _all_repos = list(_repos)
        for _r in _prurls:
            if _r not in _all_repos:
                _all_repos.append(_r)
        if _all_repos:
            print(f"  Repos ({len(_all_repos)}):")
            for _r in _all_repos:
                _entry = _prurls.get(_r) if isinstance(_prurls.get(_r), dict) else {}
                _num = _entry.get("prNumber")
                _url = _entry.get("prUrl", "")
                _state = _entry.get("state", "")
                if _num or _url:
                    _pr = f"PR #{_num}" if _num else "PR"
                    _pr += f" ({_state})" if _state else ""
                    _pr += f" {_url}" if _url else ""
                else:
                    _pr = "no PR recorded"
                print(f"    - {_r}: {_branch} — {_pr}")
        elif v.get("prUrl") or v.get("prNumber"):
            # Legacy single-repo flat linkage.
            _num = v.get("prNumber")
            _pr = f"PR #{_num}" if _num else "PR"
            _pr += f" {v.get('prUrl')}" if v.get("prUrl") else ""
            print(f"  PR:      {_pr}")
        orders = v.get("orders", [])
        if orders:
            print(f"  Orders ({len(orders)}):")
            # BUG-MSO-2026-0348 (issue #201): manifests store orders as either a
            # flat list of order-ID strings (the `mso voyage create` default) or
            # a list of dicts — tolerate both, as `mso order remove` does.
            for o in orders:
                if isinstance(o, str):
                    print(f"    - {o}")
                else:
                    print(f"    - {o.get('orderId') or o.get('id') or '?'}: {o.get('title', '')}")
        print()

    elif args.voyage_action == "why":
        # FTR-MSO-2026-0719 / PLAN-FTR-MSO-2026-0700 §5.1. Two shapes come back
        # from `classify_voyage_blockage`: a DEADLOCKED voyage (wrapping
        # `deadlock.VoyageDeadlock` verbatim, so this can never disagree with
        # `mso status`) and a not-progressing one whose every remaining member
        # is individually blocked. Both render the blocking CHAIN — the point
        # of the verb is that "held on FTR-...-0618" is not an answer, but
        # "held on FTR-...-0618, which STALLED after 2 requeues at TST" is.
        from maestro.core.blockage import BlockageContext, classify_voyage_blockage

        voyage_id = args.voyage_id
        manifest = None
        for _sub in ("active", "complete"):
            _path = mso_dir / "voyages" / _sub / f"{voyage_id}.json"
            if _path.exists():
                try:
                    manifest = json.loads(_path.read_text(encoding="utf-8"))
                except (OSError, ValueError):
                    # A manifest we cannot parse is still a voyage that EXISTS —
                    # the blockage below is derived from the resolved plane, not
                    # from this file, so refusing here would withhold a
                    # diagnosis over a field this branch only uses for a label.
                    manifest = {}
                if not isinstance(manifest, dict):
                    manifest = {}
                break
        if manifest is None:
            raise MaestroUserError(
                f"Voyage not found: {voyage_id}",
                hint="Check 'mso voyage list' for active voyages.",
            )

        ctx = BlockageContext.load(mso_dir)
        blockage = classify_voyage_blockage(voyage_id, ctx)
        _emit_blockage(blockage, voyage_id, "voyage",
                       (manifest.get("status") or "").upper() or "IN_FLIGHT",
                       getattr(args, "json", False))

    elif args.voyage_action == "reconcile":
        # FTR-MSO-2026-0426: both this command and the Hub's sweep button go
        # through run_housekeeping_sweep — one implementation, identical results.
        from maestro.core.fleet_runner import run_housekeeping_sweep
        import maestro.core.fleet_runner as _fr
        # Point fleet_runner at the resolved workspace for this CLI invocation
        _old_override = _fr._MAESTRO_DIR_OVERRIDE
        _fr._MAESTRO_DIR_OVERRIDE = mso_dir
        dry_run = getattr(args, "dry_run", False)
        as_json = getattr(args, "json", False)
        try:
            result = run_housekeeping_sweep(
                dry_run=dry_run,
                voyage_id_filter=getattr(args, "voyage_id", None),
                repo_filter=getattr(args, "repo", None),
            )
        finally:
            _fr._MAESTRO_DIR_OVERRIDE = _old_override

        if as_json:
            print(json.dumps(result, indent=2))
            return

        count, annotated = result["archived"], result["annotated"]
        if dry_run:
            print(f"[Voyage] dry-run complete — {count} voyage(s) would be archived, "
                  f"{annotated} completed voyage(s) would be annotated with merge metadata")
        else:
            print(f"[Voyage] reconcile complete — {count} voyage(s) archived, "
                  f"{annotated} completed voyage(s) annotated with merge metadata")
        # Report what changed AND what was refused, with reasons — a silent
        # "0 archived" used to leave the operator with no idea why.
        for entry in result["changes"]:
            label = f"would {entry['action']}" if dry_run else entry["action"]
            print(f"  [{label}] {entry['voyage']}: {entry['reason']}")
        if result["refusals"]:
            print(f"[Voyage] {len(result['refusals'])} item(s) left untouched:")
            for entry in result["refusals"]:
                print(f"  [skipped] {entry['voyage']}: {entry['reason']}")


def cmd_order(args: argparse.Namespace) -> None:
    """Manage orders (skip / remove / unskip / list)."""
    ws = find_workspace(getattr(args, "project", None))
    # BUG-MSO-2026-0425: resolve the artefact plane (honours the solo/shared
    # pointer); the override below then makes the whole skip/remove/retry path
    # read/write the artefact repo, not the product repo's frozen .mso.
    mso_dir = _artefact_dir(ws)

    import maestro.core.fleet_runner as _fr
    from maestro.core.order_retry import workspace_scope
    with workspace_scope(mso_dir):
        if args.order_action == "create":
            # FTR-MSO-2026-0620 / PLAN-PLN-MSO-2026-0556 Order 4: the generic
            # creation verb the CLI never had — `mso bug` could only ever mint
            # a BUG. Routes through maestro/core/order_create.py, the SAME
            # implementation the bridge and the Hub call, so an order created
            # here is indistinguishable from one created there.
            from maestro.core.order_create import create_order
            from maestro.core.order_ids import OrderValidationError

            hint = ("mso order create 'Title' --type FTR --project MSO "
                    "[--priority HIGH] [--voyage VOY-MSO-2026-0001]")
            try:
                created = create_order(
                    mso_dir,
                    order_type=args.type,
                    project=args.project,
                    title=" ".join(args.title),
                    priority=getattr(args, "priority", None),
                    description=getattr(args, "description", "") or "",
                    role_sequence=_split_csv(getattr(args, "role_sequence", None)),
                    target_role=getattr(args, "target_role", None),
                    depends_on=_split_csv(getattr(args, "depends_on", None)),
                    voyage_id=getattr(args, "voyage_id", "") or "",
                    voyage_branch=getattr(args, "voyage_branch", "") or "",
                    target_repo=getattr(args, "target_repo", "") or "",
                    queue=getattr(args, "queue", "orders") or "orders",
                    status=getattr(args, "status", None),
                    created_by="cli",
                )
            except OrderValidationError as exc:
                raise MaestroUserError(str(exc), hint=hint)

            print(f"[Order] Created {created.order_id}: {created.order['title']}")
            print(f"        type={created.order['type']} "
                  f"priority={created.order['priority']} "
                  f"roles={'->'.join(created.order['roleSequence'])}")
            print(f"        {created.path}")

        elif args.order_action == "skip":
            _fr.add_skipped_order(
                args.order_id,
                reason=getattr(args, "reason", "") or "",
                skipped_by="cli",
            )
            print(f"[Order] {args.order_id} added to skip list.")

        elif args.order_action == "remove":
            voyage_id = args.voyage_id
            voyage_path = mso_dir / "voyages" / "active" / f"{voyage_id}.json"
            if not voyage_path.exists():
                raise MaestroUserError(
                    f"Voyage file not found: {voyage_path}",
                    hint=f"Check 'mso voyage list' for active voyages.",
                )
            try:
                voyage = json.loads(voyage_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError) as exc:
                raise MaestroUserError(
                    f"Cannot read voyage file {voyage_path}: {exc}"
                )
            orders = voyage.get("orders", [])
            new_orders = []
            found = False
            for entry in orders:
                if isinstance(entry, str):
                    eid = entry
                else:
                    eid = entry.get("orderId") or entry.get("id") or ""
                if eid == args.order_id:
                    found = True
                else:
                    new_orders.append(entry)
            if not found:
                raise MaestroUserError(
                    f"Order {args.order_id} not found in {voyage_id} orders[].",
                    hint="Check the voyage manifest with 'mso voyage status {}'".format(voyage_id),
                )
            voyage["orders"] = new_orders
            voyage_path.write_text(json.dumps(voyage, indent=2), encoding="utf-8")
            _fr.add_skipped_order(
                args.order_id,
                reason="removed from manifest",
                voyage_id=voyage_id,
                skipped_by="cli",
            )
            print(f"[Order] {args.order_id} removed from {voyage_id} and added to skip list.")

        elif args.order_action == "retry":
            # BUG-MSO-2026-0297 (GKT F2): sanctioned reopen of a terminal order.
            # Without this, a STALLED order is unrecoverable — the runtime
            # ledger vetoes re-dispatch forever and the scanner self-heal
            # re-archives any manual file move.
            # BUG-MSO-2026-0344: also the recovery verb for orders stranded IN
            # A QUEUE (CONVERGENCE_FAILED / VERIFY_FAILED / BLOCKED / ...) —
            # the BUG-0303 WARN recommends `mso order retry`, which used to
            # dead-end on queued ids ("not found in orders/complete|failed").
            # FTR-MSO-2026-0492: the implementation itself lives in
            # maestro/core/order_retry.py — shared verbatim with the Hub's
            # POST /orders/{id}/retry endpoint, so the CLI and the Hub can
            # never disagree about recovery semantics.
            from maestro.core import order_retry

            try:
                outcome = order_retry.retry_order(
                    mso_dir,
                    args.order_id,
                    role=getattr(args, "role", None),
                    reason=getattr(args, "reason", "") or "",
                    force=getattr(args, "force", False),
                    no_salvage=getattr(args, "no_salvage", False),
                    force_salvage=getattr(args, "force_salvage", False),
                    salvage=getattr(args, "salvage", None),
                )
            except (order_retry.OrderNotFound, order_retry.RetryRefused) as exc:
                raise MaestroUserError(str(exc), hint=exc.hint or None)

            print(f"[Order] {outcome.order_id} reopened: "
                  f"{outcome.new_status}@{outcome.target_role}{outcome.salvage_note}")
            # BUG-MSO-2026-0696: print EVERY candidate and mark the armed one.
            # The three recurrences of this trap all shared one shape — the
            # operator was never shown that a second, better salvage existed,
            # so there was nothing to notice. Listing them costs two lines and
            # removes the whole class of silent wrong-branch arming.
            if outcome.salvage_candidates:
                armed = outcome.salvage_branch
                print(f"        Salvage candidates ({len(outcome.salvage_candidates)}):")
                for cand in outcome.salvage_candidates:
                    marker = "->" if cand.get("branch") == armed else "  "
                    print(f"          {marker} {cand.get('summary', cand.get('branch'))}")
                if armed:
                    print(f"        ARMED: {armed}"
                          + ("  (named with --salvage)" if outcome.salvage_explicit
                             else "  (newest; override with --salvage <branch>)"))
                else:
                    print("        ARMED: none — the role will be re-run from scratch.")
            print("        A running dispatcher will pick it up on its next scan tick;")
            print("        otherwise dispatch with: mso dispatch")

        elif args.order_action == "unskip":
            removed = _fr.remove_skipped_order(args.order_id)
            if removed:
                print(f"[Order] {args.order_id} removed from skip list.")
            else:
                print(f"[Order] {args.order_id} was not in the skip list (no-op).")

        elif args.order_action == "why":
            # FTR-MSO-2026-0719 / PLAN-FTR-MSO-2026-0700 §5.1. Reads the model,
            # renders it; every cause, evidence path and option comes from
            # `maestro/core/blockage.py` so this verb and the Hub's panel say
            # the same words about the same order by construction.
            from maestro.core.blockage import (
                BlockageContext, classify_order_blockage)

            ctx = BlockageContext.load(mso_dir)
            data = ctx.order_data(args.order_id)
            if data is None:
                raise MaestroUserError(
                    f"Order not found: {args.order_id}",
                    hint=("Checked the live queues and orders/complete|failed. "
                          "Run 'mso status' to see what is queued."),
                )
            _emit_blockage(
                classify_order_blockage(args.order_id, ctx, data=data),
                args.order_id, "order",
                ctx.status_of(args.order_id, data),
                getattr(args, "json", False),
            )

        elif args.order_action == "list":
            skipped = _fr.load_skipped_orders()
            if not skipped:
                print("[Order] Skip list is empty.")
            else:
                print(f"[Order] Skip list ({len(skipped)} entries):")
                for oid, meta in skipped.items():
                    reason = meta.get("reason", "")
                    voyage = meta.get("voyageId", "")
                    at = meta.get("skippedAt", "")
                    parts = [f"  {oid}"]
                    if reason:
                        parts.append(f"reason={reason!r}")
                    if voyage:
                        parts.append(f"voyage={voyage}")
                    if at:
                        parts.append(f"at={at}")
                    print("  ".join(parts))


def cmd_bug(args: argparse.Namespace) -> None:
    """Create a BUG order.

    FTR-MSO-2026-0620: the implementation lives in
    ``maestro/core/order_create.py`` — shared verbatim with ``mso order
    create``, the Slack bridge and (Order 5) the Hub's order endpoint, so no
    two surfaces can disagree about what a BUG order's roleSequence, priority
    default or id allocation is. This wrapper resolves the workspace, maps the
    core's typed errors onto ``MaestroUserError`` and prints; it decides
    nothing.
    """
    from maestro.core.order_create import create_order
    from maestro.core.order_ids import OrderValidationError

    ws = find_workspace(getattr(args, "project", None))
    mso_dir = resolve_artefact_dir(ws)
    if not args.project:
        raise MaestroUserError(
            "--project required for 'bug'",
            hint="mso bug 'Login crashes on mobile' --project ADM",
        )
    try:
        created = create_order(
            mso_dir,
            order_type="BUG",
            project=args.project,
            title=" ".join(args.title),
            priority=getattr(args, "priority", None),
            created_by="cli",
        )
    except OrderValidationError as exc:
        raise MaestroUserError(
            str(exc), hint="mso bug '<title>' --project ADM [--priority HIGH]")

    print(f"[Bug] Created {created.order_id}: {created.order['title']}")


def cmd_security_review(args: argparse.Namespace) -> None:
    """Run a security review: scan + unified report."""
    from maestro.security.review import run_review
    ws = find_workspace(getattr(args, "project", None))
    from maestro.workspace import resolve_artefact_dir
    mso_root = resolve_artefact_dir(ws)
    exit_code = run_review(args, ws, mso_root)
    raise SystemExit(exit_code)


def cmd_security(args: argparse.Namespace) -> None:
    """Run the OWASP/CWE security scanner manually."""
    import glob as _glob

    ws = find_workspace(getattr(args, "project", None))
    mso_root = resolve_artefact_dir(ws)
    reports_dir = mso_root / "reports" / "security"

    try:
        from maestro.security.owasp_patterns import OWASPScanner, Severity
    except ImportError:
        raise MaestroConfigError(
            "OWASP scanner not found — ensure maestro-fleet is installed.",
            hint="pip install maestro-fleet",
        )

    # Resolve files to scan
    files_to_scan: list[Path] = []

    if args.order:
        # Scan files recorded as modified for this order
        crew_dirs = list((mso_root / "crews").glob("crew*")) if (mso_root / "crews").exists() else []
        for cd in crew_dirs:
            fmod = cd / "files_modified.json"
            if fmod.exists():
                try:
                    paths = json.loads(fmod.read_text(encoding="utf-8"))
                    files_to_scan.extend(Path(p) for p in paths)
                except Exception:
                    pass
    elif args.voyage:
        # Scan based on voyage's orders' modified files
        voyage_files = list((mso_root / "voyages").rglob(f"{args.voyage}.json"))
        order_ids: set[str] = set()
        for vf in voyage_files:
            try:
                vdata = json.loads(vf.read_text(encoding="utf-8"))
                for order in vdata.get("orders", []):
                    # BUG-MSO-2026-0348: orders[] may be flat ID strings
                    if isinstance(order, str):
                        order_id = order
                    else:
                        order_id = order.get("orderId") or order.get("id")
                    if order_id:
                        order_ids.add(order_id)
            except Exception:
                pass
        # Fall back to scanning all modified files tracked in crews
        crew_dirs = list((mso_root / "crews").glob("crew*")) if (mso_root / "crews").exists() else []
        for cd in crew_dirs:
            fmod = cd / "files_modified.json"
            if fmod.exists():
                try:
                    paths = json.loads(fmod.read_text(encoding="utf-8"))
                    files_to_scan.extend(Path(p) for p in paths)
                except Exception:
                    pass
    elif args.since:
        # Find .py files modified since date
        from datetime import datetime as _dt
        try:
            since_ts = _dt.fromisoformat(args.since).timestamp()
        except ValueError:
            raise MaestroUserError(
                f"Invalid --since date: {args.since}",
                hint="Use ISO format: YYYY-MM-DD",
            )
        for py_file in ws.rglob("*.py"):
            try:
                if py_file.stat().st_mtime >= since_ts:
                    files_to_scan.append(py_file)
            except Exception:
                pass
    else:
        # Default: scan entire workspace Python files
        files_to_scan = list(ws.rglob("*.py"))

    # Deduplicate and filter to existing .py files
    seen: set[str] = set()
    unique_files: list[str] = []
    for f in files_to_scan:
        p = Path(f)
        if not p.suffix == ".py":
            continue
        key = str(p.resolve())
        if key in seen:
            continue
        seen.add(key)
        if p.exists():
            unique_files.append(str(p))

    if not unique_files:
        print("[Security] No Python files found to scan.")
        return

    print(f"[Security] Scanning {len(unique_files)} file(s)...")
    scanner = OWASPScanner(language="python")
    all_findings = scanner.scan_files(unique_files)

    # Apply severity threshold filter
    severity_order = ["INFO", "LOW", "MEDIUM", "HIGH", "CRITICAL"]
    threshold = (args.severity_threshold or "INFO").upper()
    if threshold not in severity_order:
        raise MaestroUserError(
            f"Invalid --severity-threshold: {threshold}",
            hint=f"Valid values: {', '.join(severity_order)}",
        )
    min_idx = severity_order.index(threshold)
    filtered = [f for f in all_findings if severity_order.index(f.severity.value) >= min_idx]

    if args.json:
        summary = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0, "INFO": 0}
        for f in filtered:
            summary[f.severity.value] = summary.get(f.severity.value, 0) + 1
        output = {
            "scannedFiles": len(unique_files),
            "totalFindings": len(filtered),
            "summary": summary,
            "findings": [f.to_dict() for f in filtered],
        }
        print(json.dumps(output, indent=2))
        return

    # Human-readable output
    if not filtered:
        print("[Security] No findings above threshold.")
        return

    summary: dict[str, int] = {}
    for f in filtered:
        summary[f.severity.value] = summary.get(f.severity.value, 0) + 1

    print(f"\n  Findings: {len(filtered)}")
    for sev in ("CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"):
        if summary.get(sev):
            print(f"    {sev}: {summary[sev]}")

    print()
    for i, f in enumerate(filtered, 1):
        print(f"  {i}. [{f.severity.value}] {f.title}")
        print(f"     CWE: {f.cwe}  File: {f.file}:{f.line}")
        print(f"     Snippet: {f.snippet[:80]}")
        print(f"     Fix: {f.remediation}")
        print()

    # Optionally write report to .mso/reports/security/
    if args.order:
        reports_dir.mkdir(parents=True, exist_ok=True)
        from maestro.hooks.posttool import _write_md_report
        report_data = {
            "orderId": args.order,
            "generatedAt": datetime.now(timezone.utc).isoformat(),
            "findings": [f.to_dict() for f in filtered],
            "summary": summary,
        }
        # BUG-MSO-2026-0465: don't double the SEC- prefix for a SEC-type order id.
        from maestro.workspace import artefact_report_stem
        report_stem = artefact_report_stem("SEC", args.order)
        json_path = reports_dir / f"{report_stem}.json"
        json_path.write_text(json.dumps(report_data, indent=2), encoding="utf-8")
        md_path = reports_dir / f"{report_stem}.md"
        _write_md_report(md_path, report_data)
        print(f"  Report written: {json_path}")
        print(f"  Report written: {md_path}")


def cmd_projects(args: argparse.Namespace) -> None:
    """List or manage registered projects in the global registry."""
    from maestro.registry import list_projects, unregister_project

    action = args.projects_action

    if action == "list":
        projects = list_projects()
        if not projects:
            print("[Maestro] No projects registered. Run 'mso init --project ACRONYM' to register one.")
            return
        print(f"{'ACRONYM':<12}  {'PATH':<60}  {'MODE':<10}  REGISTERED")
        print("-" * 102)
        for acronym, entry in sorted(projects.items()):
            path = entry.get("path", "?")
            # v2 fields are optional — absence means embedded (schema v1 entries
            # are normalised by list_projects but never carry these).
            mode = entry.get("artefactMode") or "embedded"
            registered = entry.get("registered", "?")[:19].replace("T", " ")
            print(f"{acronym:<12}  {path:<60}  {mode:<10}  {registered}")

    elif action == "remove":
        acronym = args.acronym.upper()
        _prod = current_persona().term("product")
        if unregister_project(acronym):
            print(f"[{_prod}] Removed '{acronym}' from global registry.")
        else:
            print(f"[{_prod}] Project '{acronym}' not found in registry.")


def _resolve_pack_arg(pack_arg: str, *, workspace: Path | None = None) -> "object":
    """Resolve a ``--pack NAME|PATH|URL`` argument to a loaded Pack.

    A path to an existing directory loads via ``load_pack_from_dir`` and is
    UNGATED — the pack-authoring/evaluation loop (PLAN-PLN-MSO-2026-0449
    §6.3), and it touches only the author's own machine. A bare name loads as
    a built-in and keeps the existing ``is_free()`` / ``require_tier`` gate
    (FTR-MSO-2026-0383) — non-free division packs need Team/Enterprise.
    MAESTRO_SKIP_AUTH is honoured via ``has_tier``. Shared by `cmd_init`
    (`init --pack`) and `cmd_packs`'s `apply` action so the two never drift.

    An ``http(s)://`` URL is a REMOTE signed pack archive (FTR-MSO-2026-0481,
    Captain ruling D4): tarball + SHA-256 manifest + detached Ed25519
    signature, verified against the trusted-key registry
    (``maestro.packs.remote.load_pack_from_url``). Unlike a local directory,
    a remote pack is ALWAYS gated at Team/Enterprise regardless of its own
    ``tier`` field — the field is author-asserted and worthless as a security
    control for customer-authored content; D4 gates on transport (network
    fetch), which the author cannot forge. ``workspace`` is passed through
    for workspace-tier trusted-key pin resolution (may be ``None`` — vendor +
    home keyring pins still apply).
    """
    from maestro import auth
    from maestro.packs import PackSchemaError, SignedPackError, builtin_names, load_builtin, load_pack_from_dir

    if pack_arg.startswith("http://") or pack_arg.startswith("https://"):
        from maestro.governance.schema import GovernanceError
        from maestro.packs import load_pack_from_url

        try:
            pack = load_pack_from_url(pack_arg, workspace=workspace)
        except (SignedPackError, GovernanceError) as exc:
            raise SystemExit(
                f"[Maestro] Signed pack fetch/verify failed for '{pack_arg}': {exc}"
            ) from exc
        auth.require_tier({"team", "enterprise"}, feature=f"Remote signed pack '{pack.id}'")
        return pack

    candidate = Path(pack_arg)
    if candidate.is_dir():
        try:
            return load_pack_from_dir(candidate)
        except PackSchemaError as exc:
            raise SystemExit(f"[Maestro] Invalid pack directory '{pack_arg}': {exc}") from exc

    try:
        pack = load_builtin(pack_arg)
    except PackSchemaError as exc:
        available = ", ".join(builtin_names()) or "(none)"
        raise SystemExit(
            f"[Maestro] Unknown pack '{pack_arg}': {exc}\nAvailable packs: {available}"
        ) from exc
    if not pack.is_free():
        auth.require_tier(auth.HUB_TIERS, feature=f"Division pack '{pack.id}'")
    return pack


def cmd_init(args: argparse.Namespace) -> None:
    """Scaffold a new Maestro workspace. (Auth check bypassed — see auth.py.)"""
    from maestro.init import scaffold_workspace

    pack = None
    pack_name = getattr(args, "pack", None)
    if pack_name:
        directory = Path(args.directory) if args.directory else Path.cwd()
        pack = _resolve_pack_arg(pack_name, workspace=directory)

    scaffold_workspace(
        project=args.project,
        directory=Path(args.directory) if args.directory else Path.cwd(),
        force=args.force,
        enterprise=getattr(args, "enterprise", False),
        pack=pack,
        non_interactive=getattr(args, "non_interactive", False),
    )


def cmd_quickstart(args: argparse.Namespace) -> None:
    """Run the guided first-run experience."""
    from maestro.quickstart import run_quickstart
    run_quickstart(args)


def cmd_demo(args: argparse.Namespace) -> None:
    """Run the Squad Monitor dashboard PVT (simulated fleet, no token spend)."""
    from maestro.demo import run_demo
    ws = find_workspace(getattr(args, "project", None))
    mso_root = resolve_artefact_dir(ws)
    # Pin workspace resolution for the in-process demo (and its threads)
    os.environ["MAESTRO_DIR"] = str(mso_root)
    raise SystemExit(run_demo(
        headless=getattr(args, "headless", False),
        time_scale=0.1 if getattr(args, "fast", False) else 1.0,
        keep=getattr(args, "keep", False),
    ))


def cmd_setup(args: argparse.Namespace) -> None:
    """Prerequisite validation and interactive setup wizard."""
    from maestro.setup import (
        run_all_checks,
        format_check_report,
        check_mode_exit_code,
        interactive_setup,
    )

    check = getattr(args, "check", False)
    repair = getattr(args, "repair", False)
    show = getattr(args, "show", None)

    if show:
        # BUG fixed via Copilot review on PR #67: previously each section just
        # printed a static hint string ("Run `mso setup --check` to see ...").
        # Now `--show <section>` returns the actual data for that section.
        valid = {"prereqs", "project", "workspace", "templates", "persona"}
        if show not in valid:
            print(f"Unknown section '{show}'. Valid sections: {', '.join(sorted(valid))}")
            sys.exit(2)

        if show == "prereqs":
            results = run_all_checks()
            print(format_check_report(results, verbose=True))
            return

        if show == "project":
            try:
                from maestro.project_analysis import analyse_project
                analysis = analyse_project(Path.cwd())
                print(f"  Language    : {analysis.primary_language}")
                if analysis.secondary_languages:
                    print(f"  Also uses   : {', '.join(analysis.secondary_languages)}")
                print(f"  Framework   : {analysis.framework}")
                print(f"  Source root : {analysis.source_root}")
                print(f"  Test layout : {', '.join(analysis.test_layouts) or 'none detected'}")
                print(f"  README      : {'yes' if analysis.has_readme else 'no'}")
                print(f"  docs/       : {'yes' if analysis.has_docs_dir else 'no'}")
                print(f"  CI          : {', '.join(analysis.ci_systems) if analysis.ci_systems else 'none detected'}")
                print(f"  Activity    : {analysis.recent_activity}")
                print(f"  Branches    : {analysis.branch_model}")
            except Exception as exc:
                print(f"  ⚠ Project analysis failed: {exc}")
            return

        if show == "workspace":
            import json as _json
            from maestro.setup import _find_mso_dir
            adm_dir = _find_mso_dir()
            if adm_dir is None:
                print("  No Maestro workspace (.mso/) found in current directory or any parent.")
                print("  Run `mso init --project <PRJ>` to scaffold one.")
                return
            ws_path = adm_dir / "config" / "workspace.json"
            print(f"  Workspace root : {adm_dir.parent}")
            print(f"  Config dir     : {adm_dir / 'config'}")
            if ws_path.exists():
                try:
                    ws = _json.loads(ws_path.read_text(encoding="utf-8"))
                    print(f"  workspace.json : {ws_path}")
                    for key, val in ws.items():
                        print(f"    {key}: {val}")
                except Exception as exc:
                    print(f"  ⚠ workspace.json present but unreadable: {exc}")
            else:
                print(f"  workspace.json : MISSING — run `mso init --project <PRJ>`")
            return

        if show == "templates":
            from maestro.templates_loader import (
                list_builtin_templates,
                list_custom_templates,
            )
            from maestro.setup import _find_mso_dir
            adm_dir = _find_mso_dir()
            builtins = list_builtin_templates()
            print("  Built-in templates:")
            for name in builtins:
                print(f"    • {name}")
            if adm_dir is not None:
                custom = list_custom_templates(adm_dir)
                if custom:
                    print("  Custom templates:")
                    for name in custom:
                        marker = " (overrides built-in)" if name in builtins else ""
                        print(f"    • {name}{marker}")
                else:
                    print("  Custom templates: (none)")
            else:
                print("  Custom templates: (no Maestro workspace found)")
            return

        if show == "persona":
            from maestro.personas import current_persona, reset_persona_cache
            from maestro.personas.resolver import _find_workspace_config
            import os
            reset_persona_cache()
            p = current_persona()
            env_id = os.environ.get("MAESTRO_PERSONA", "").strip()
            if env_id:
                source = f"MAESTRO_PERSONA env var ('{env_id}')"
            else:
                ws_path = _find_workspace_config()
                if ws_path:
                    source = f"workspace config ({ws_path})"
                else:
                    from maestro.workspace import get_maestro_home
                    user_path = get_maestro_home() / "config" / "persona.json"
                    if user_path.exists():
                        source = f"user-global config ({user_path})"
                    else:
                        source = "built-in default"
            print(f"  Persona  : {p.id}")
            print(f"  Title    : {p.vocabulary.get('userTitle', p.id)}")
            print(f"  Source   : {source}")
            return

    if check:
        results = run_all_checks()
        if getattr(args, "json", False):
            import json as _json
            payload = {
                "prereqs": [
                    {"name": r.name, "status": r.status, "message": r.message,
                     "remediation": r.remediation}
                    for r in results
                ],
                "exit_code": check_mode_exit_code(results),
            }
            print(_json.dumps(payload, indent=2))
        else:
            print(format_check_report(results, verbose=True))
        sys.exit(check_mode_exit_code(results))

    if repair:
        from maestro.setup import PrereqCheck
        results = run_all_checks()
        print(format_check_report(results, verbose=True))
        repaired = 0
        for r in results:
            if r.status in ("FAIL", "WARN") and r.repair_fn:
                print(f"\n  Repairing '{r.name}'...")
                try:
                    r.repair_fn()
                    repaired += 1
                    print(f"  ✓ Done")
                except Exception as exc:
                    print(f"  ✗ Failed: {exc}")
        if repaired:
            print(f"\n  {repaired} repair(s) attempted. Re-run `mso setup --check` to verify.")
        else:
            print("\n  Nothing to repair.")
        return

    answers_file = getattr(args, "answers", None)
    answers = None
    if answers_file:
        from maestro.setup import _parse_answers_file
        answers = _parse_answers_file(answers_file)

    interactive_setup(
        profile=getattr(args, "profile", None),
        non_interactive=getattr(args, "non_interactive", False),
        answers=answers,
    )
    _run_setup_preflight()


def _run_setup_preflight() -> None:
    """Run the Claude CLI preflight smoke test as the final step of mso setup.

    Blocks setup completion on failure (PLN-0192 Part E). Skipped when
    MAESTRO_SKIP_AUTH is set (CI environments without a live Claude account).
    """
    from maestro.core.crew import run_preflight_check, find_claude_cli
    _prod = current_persona().term("product")
    print(f"\n[{_prod}] Running Claude CLI preflight check...")
    result = run_preflight_check(claude_cli=find_claude_cli())
    if result["ok"]:
        print(f"[{_prod}] Preflight PASS — Claude CLI is reachable.")
    else:
        print(f"[{_prod}] Preflight FAIL — Claude CLI is not working correctly.")
        if result["error"]:
            print(f"  Error: {result['error']}")
        print("  Fix the issue above before dispatching crews.")
        sys.exit(1)


def cmd_update(args: argparse.Namespace) -> None:
    """Propagate Maestro schema updates to an existing workspace."""
    from maestro.update import update_workspace
    update_workspace(
        workspace=Path(args.directory) if args.directory else Path.cwd(),
        dry_run=args.dry_run,
        force=args.force,
    )


def cmd_migrate(args: argparse.Namespace) -> None:
    """Migrate an embedded workspace's durable plane into a dedicated artefact repo."""
    action = getattr(args, "migrate_action", None)
    if action not in ("artefact-repo", "import-workspace"):
        print_error("Usage: mso migrate artefact-repo [--project ACR] [--dest PATH] "
                    "[--name NAME] [--remote URL] [--clean-product] [--dry-run] [--rollback]\n"
                    "   or: mso migrate import-workspace <source> --into <target> "
                    "--sub-acronym <SUB> [--target-acronym ACR] [--dry-run]")
        raise SystemExit(2)

    from maestro import migrate as _migrate

    if action == "import-workspace":
        source = Path(args.source).expanduser()
        into = Path(args.into).expanduser()
        try:
            _migrate.import_workspace(
                source,
                into,
                args.sub_acronym,
                target_acronym=getattr(args, "target_acronym", None),
                dry_run=args.dry_run,
            )
        except _migrate.MigrationError as exc:
            print_error(str(exc))
            raise SystemExit(1)
        return

    ws = find_workspace(getattr(args, "project", None))
    dest = Path(args.dest).expanduser() if args.dest else None

    if getattr(args, "rollback", False):
        if dest is None:
            print_error("--rollback requires --dest PATH (the artefact repo to remove).")
            raise SystemExit(2)
        acronym = _migrate.resolve_acronym(ws, getattr(args, "project", None))
        _migrate.rollback_migration(ws, dest.resolve(), acronym)
        return

    try:
        _migrate.migrate_artefact_repo(
            ws,
            dest=dest,
            name=args.name,
            remote=args.remote,
            clean_product=args.clean_product,
            dry_run=args.dry_run,
            project=getattr(args, "project", None),
        )
    except _migrate.MigrationError as exc:
        print_error(str(exc))
        raise SystemExit(1)


def cmd_hooks(args: argparse.Namespace) -> None:
    """Install or uninstall global Maestro hooks in ~/.claude/settings.json."""
    import copy

    settings_path = Path.home() / ".claude" / "settings.json"

    # The hook entries Maestro manages (keyed by a sentinel command for idempotency)
    MAESTRO_HOOKS: dict = {
        "PreToolUse": [
            {
                # FTR-MSO-2026-0392: Bash + NotebookEdit added so the governance
                # gate (and the branch/path/secret/PR guards that already parse
                # Bash internally) actually fire for shell commands and notebook
                # cells — closing the SS1.1 "Bash not in matcher" bypass class.
                "matcher": "Edit|MultiEdit|Write|Bash|NotebookEdit",
                "hooks": [
                    {
                        "type": "command",
                        "command": "python -m maestro.hooks.pretool",
                        "timeout": 10,
                    }
                ],
            },
            {
                "matcher": "AskUserQuestion",
                "hooks": [
                    {
                        "type": "command",
                        "command": "python -m maestro.hooks.bridge_question",
                        "timeout": 10,
                    }
                ],
            },
        ],
        "PostToolUse": [
            {
                "matcher": "Edit|MultiEdit|Write|Bash|Read|Glob|Grep|Task",
                "hooks": [
                    {
                        "type": "command",
                        "command": "python -m maestro.hooks.posttool",
                        "timeout": 10,
                    }
                ],
            }
        ],
        "Stop": [
            {
                "matcher": "",
                "hooks": [
                    {
                        "type": "command",
                        "command": "python -m maestro.hooks.stop",
                        "timeout": 30,
                    }
                ],
            }
        ],
        "Notification": [
            {
                "matcher": "",
                "hooks": [
                    {
                        "type": "command",
                        "command": "python -m maestro.hooks.notification",
                        "timeout": 10,
                    }
                ],
            }
        ],
    }

    # Collect all maestro module commands for lookup
    def _maestro_commands() -> set:
        cmds: set = set()
        for entries in MAESTRO_HOOKS.values():
            for entry in entries:
                for h in entry.get("hooks", []):
                    cmds.add(h.get("command", ""))
        return cmds

    def _entry_key(entry: dict) -> str:
        """Stable identity key for a hook group entry (matcher + first command)."""
        hooks = entry.get("hooks", [])
        first_cmd = hooks[0].get("command", "") if hooks else ""
        return f"{entry.get('matcher', '')}|{first_cmd}"

    # Load existing settings
    settings: dict = {}
    if settings_path.exists():
        try:
            settings = json.loads(settings_path.read_text(encoding="utf-8"))
        except Exception:
            settings = {}

    if args.hooks_action == "install":
        merged = copy.deepcopy(settings)
        merged.setdefault("hooks", {})
        maestro_cmds = _maestro_commands()

        for event, new_entries in MAESTRO_HOOKS.items():
            existing_entries: list = merged["hooks"].setdefault(event, [])
            existing_keys = {_entry_key(e) for e in existing_entries}

            for new_entry in new_entries:
                key = _entry_key(new_entry)
                if key not in existing_keys:
                    existing_entries.append(copy.deepcopy(new_entry))

        settings_path.parent.mkdir(parents=True, exist_ok=True)
        settings_path.write_text(json.dumps(merged, indent=2), encoding="utf-8")
        _prod = current_persona().term("product")
        print(f"[{_prod}] Hooks installed in {settings_path}")
        print("  Restart Claude Code to activate.")

    elif args.hooks_action == "uninstall":
        if not settings_path.exists():
            _prod = current_persona().term("product")
            print(f"[{_prod}] No ~/.claude/settings.json found — nothing to uninstall.")
            return

        maestro_cmds = _maestro_commands()
        modified = copy.deepcopy(settings)
        hooks_section: dict = modified.get("hooks", {})

        for event in list(hooks_section.keys()):
            kept = []
            for entry in hooks_section[event]:
                entry_cmds = {h.get("command", "") for h in entry.get("hooks", [])}
                if entry_cmds & maestro_cmds:
                    continue  # Drop this entry
                kept.append(entry)
            if kept:
                hooks_section[event] = kept
            else:
                del hooks_section[event]

        settings_path.write_text(json.dumps(modified, indent=2), encoding="utf-8")
        _prod = current_persona().term("product")
        print(f"[{_prod}] Hooks removed from {settings_path}")


def cmd_mcp(args: argparse.Namespace) -> None:
    """Manage the MCP server registry."""
    import os
    from maestro.mcp import (
        load_registry, validate_registry, get_active_mcp_servers,
        add_server, remove_server, get_server,
        McpSchemaError, McpMissingServerError, McpRegistryError,
    )

    ws = find_workspace(getattr(args, "project", None))
    action = args.mcp_action

    if action == "list":
        registry = load_registry(ws)
        if registry is None:
            print("[MCP] No registry found at .mso/config/mcp-servers.json")
            print("      Run 'mso mcp add' to add a server, or 'mso init' to scaffold one.")
            return
        servers = registry.get("servers", [])
        if not servers:
            print("[MCP] Registry is empty — no servers registered.")
            return
        fmt = f"{'NAME':<20}  {'RISK':<10}  {'ALLOWED ROLES':<30}  ENV REQUIRED"
        print(fmt)
        print("-" * 85)
        for s in servers:
            name = s.get("name", "?")
            risk = s.get("risk_level", "medium")
            ar = s.get("allowed_roles", [])
            roles_str = "*" if ar == "*" else ", ".join(ar)
            envs = s.get("env_required", [])
            env_str = ", ".join(envs) if envs else "—"
            print(f"{name:<20}  {risk:<10}  {roles_str:<30}  {env_str}")

    elif action == "show":
        registry = load_registry(ws)
        if registry is None:
            raise MaestroConfigError(
                "No MCP registry found at .mso/config/mcp-servers.json",
                hint="Run 'mso mcp add' to add a server, or 'mso init' to scaffold one.",
            )
        entry = get_server(registry, args.name)
        if entry is None:
            raise MaestroUserError(f"MCP server '{args.name}' not found in registry")
        print(json.dumps(entry, indent=2))

    elif action == "add":
        if args.json:
            import pathlib
            raw = pathlib.Path(args.json).read_text(encoding="utf-8")
            entry = json.loads(raw)
        else:
            if not args.name:
                raise MaestroUserError("--name is required for 'mcp add'")
            if not args.command:
                raise MaestroUserError("--command is required for 'mcp add'")
            if not args.allowed_roles:
                raise MaestroUserError("--allowed-roles is required for 'mcp add'")
            ar_raw = args.allowed_roles
            if ar_raw == "*":
                allowed_roles: str | list = "*"
            else:
                # Strip and drop empty items so "BOS," doesn't yield ['BOS', '']
                # which then fails schema validation with a confusing
                # "unknown role ''" error.
                allowed_roles = [r.strip() for r in ar_raw.split(",") if r.strip()]
            entry = {
                "name": args.name,
                "command": args.command,
                "allowed_roles": allowed_roles,
            }
            if args.args:
                entry["args"] = args.args
            if args.risk_level:
                entry["risk_level"] = args.risk_level
            if args.env_required:
                entry["env_required"] = args.env_required
            if args.description:
                entry["description"] = args.description
            if args.notes:
                entry["notes"] = args.notes

        try:
            add_server(ws, entry)
            print(f"[MCP] Added server '{entry['name']}' to registry.")
        except (McpSchemaError, McpRegistryError) as e:
            raise MaestroUserError(str(e)) from e

    elif action == "remove":
        active = get_active_mcp_servers(ws)
        if args.name in active:
            print(
                f"[MCP] WARNING: '{args.name}' is still present in .claude/settings.json mcpServers. "
                "Remove it manually — Maestro does not modify .claude/settings.json."
            )
        try:
            remove_server(ws, args.name)
            print(f"[MCP] Removed server '{args.name}' from registry.")
        except McpMissingServerError as e:
            raise MaestroUserError(str(e)) from e

    elif action == "validate":
        registry = load_registry(ws)
        if registry is None:
            print("[MCP] WARNING: No registry at .mso/config/mcp-servers.json — permissive mode.")
            print("      Run 'mso mcp add' or 'mso init' to create one.")
            sys.exit(0)

        errors: list[str] = []

        # Schema validation
        try:
            validate_registry(registry)
        except McpSchemaError as e:
            errors.append(f"Schema error: {e}")

        # Env var checks
        if not errors:
            for s in registry.get("servers", []):
                for env_var in s.get("env_required", []):
                    if env_var not in os.environ:
                        errors.append(
                            f"Server '{s['name']}' requires env var '{env_var}' (not set)"
                        )

        # Informational: active servers not in registry
        active = get_active_mcp_servers(ws)
        reg_names = {s.get("name") for s in registry.get("servers", [])}
        unregistered = [n for n in active if n not in reg_names]
        if unregistered:
            print("[MCP] INFO: Active servers not in registry (will be blocked at dispatch):")
            for n in unregistered:
                print(f"  - {n}")

        if errors:
            print("[MCP] Validation FAILED:")
            for e in errors:
                print(f"  ✗ {e}")
            sys.exit(1)
        else:
            print("[MCP] Registry is valid.")
            sys.exit(0)


def _warn_acl_unsigned(ws: Path) -> None:
    """FTR-MSO-2026-0482 / plan §7.4: every `mso identity` mutation leaves the
    integrity manifest unsigned (mutation commands write the legacy hash
    manifest, never a signature). In enforce mode the ACL is untrusted until
    re-signed — an admin who forgets to re-sign silently breaks break-glass
    for everyone. Print a loud, impossible-to-miss reminder after every
    mutation. Silent at community/pro/ungoverned-team (§7.5) — gated on
    either the legacy `enterprise` flag or any active governed mode, so a
    workspace with neither sees nothing."""
    from maestro.identity.gate import _load_enterprise_flag
    from maestro.governance import resolve_governed_mode
    if not _load_enterprise_flag(ws) and resolve_governed_mode(ws) == "off":
        return
    print(
        "[Identity] ⚠ ACL IS NOW UNSIGNED — run `mso identity sign-acl` "
        "to restore a trusted integrity manifest.",
        file=sys.stderr,
    )


def cmd_identity(args: argparse.Namespace) -> None:
    """Manage enterprise identity, groups, and ACL."""
    ws = find_workspace(getattr(args, "project", None))
    identity_dir = resolve_artefact_dir(ws) / "identity"
    users_dir = identity_dir / "users"
    groups_dir = identity_dir / "groups"
    acl_path = identity_dir / "access.json"

    from maestro.identity.gate import require_capability
    from maestro.identity import (
        UserRecord, GroupRecord, AclEntry,
        load_user, load_acl, load_group,
        save_user, save_group, save_acl,
        list_users, list_groups,
        resolve_caller, effective_capabilities,
    )

    action = args.identity_action

    if action == "init":
        require_capability("identity.write", workspace=ws)
        _identity_init(identity_dir, users_dir, groups_dir, acl_path)
        encryption = getattr(args, "encryption", None)
        if encryption and encryption != "none":
            from maestro.identity.encryption import encryption_init_wizard
            encryption_init_wizard(ws, identity_dir, encryption)
        _warn_acl_unsigned(ws)

    elif action == "rights":
        _identity_rights(args, ws, identity_dir)

    elif action == "add-user":
        require_capability("identity.write", workspace=ws)
        from datetime import datetime, timezone
        email = args.email
        display_name = args.display_name
        groups = args.group or []
        public_key: str | None = None
        if args.public_key:
            pk_path = Path(args.public_key)
            if not pk_path.exists():
                raise SystemExit(f"[Identity] Public key file not found: {pk_path}")
            public_key = pk_path.read_text(encoding="utf-8").strip()

        existing = load_user(users_dir, email)
        if existing:
            raise SystemExit(f"[Identity] User already exists: {email}. Use set-group to modify.")

        record = UserRecord(
            email=email,
            display_name=display_name,
            groups=list(groups),
            public_key=public_key,
            enrolled_at=datetime.now(timezone.utc).isoformat(),
        )
        save_user(users_dir, record)

        # Add user to requested groups
        for grp_name in groups:
            grp = load_group(groups_dir, grp_name)
            if grp is None:
                grp = GroupRecord(name=grp_name, members=[])
            if email not in grp.members:
                grp.members.append(email)
            save_group(groups_dir, grp)

        print(f"[Identity] Added user: {email} (groups: {', '.join(groups) or 'none'})")
        _warn_acl_unsigned(ws)

    elif action == "add-group":
        require_capability("identity.write", workspace=ws)
        name = args.name
        if load_group(groups_dir, name):
            raise SystemExit(f"[Identity] Group already exists: {name}")
        record = GroupRecord(name=name, members=[])
        save_group(groups_dir, record)
        print(f"[Identity] Added group: {name}")
        _warn_acl_unsigned(ws)

    elif action == "set-group":
        require_capability("identity.write", workspace=ws)
        email = args.email
        grp_name = args.group
        user = load_user(users_dir, email)
        if user is None:
            raise SystemExit(f"[Identity] User not found: {email}")
        grp = load_group(groups_dir, grp_name)
        if grp is None:
            grp = GroupRecord(name=grp_name, members=[])
        if email not in grp.members:
            grp.members.append(email)
        if grp_name not in user.groups:
            user.groups.append(grp_name)
        save_group(groups_dir, grp)
        save_user(users_dir, user)
        print(f"[Identity] Added {email} to group {grp_name}")
        _warn_acl_unsigned(ws)

    elif action == "remove-user":
        require_capability("identity.write", workspace=ws)
        email = args.email
        path = users_dir / f"{email}.json"
        if not path.exists():
            raise SystemExit(f"[Identity] User not found: {email}")
        # Remove from all groups
        for grp in list_groups(groups_dir):
            if email in grp.members:
                grp.members.remove(email)
                save_group(groups_dir, grp)
        path.unlink()
        from maestro.identity.integrity import remove_from_manifest
        remove_from_manifest(path, identity_dir)
        print(f"[Identity] Removed user: {email}")
        _warn_acl_unsigned(ws)

    elif action == "sign-acl":
        _identity_sign_acl(args, ws, identity_dir, require_capability)

    elif action == "show":
        require_capability("identity.read", workspace=ws)
        if args.email:
            email = args.email
        else:
            actor = resolve_caller(ws)
            email = actor.removeprefix("user:")
        caps = effective_capabilities(f"user:{email}", acl_path, groups_dir)
        print(f"\n  User: {email}")
        if not caps:
            print("  No capabilities granted.")
        else:
            print(f"  {'CAPABILITY':<30}  SCOPE")
            print("  " + "-" * 50)
            for cap, scope in sorted(caps):
                print(f"  {cap:<30}  {scope}")
        print()

    elif action == "acl":
        _identity_acl(args, ws, acl_path, require_capability, load_acl, save_acl, AclEntry)

    elif action == "user":
        _identity_user(args, ws, users_dir, groups_dir, require_capability,
                       UserRecord, GroupRecord, load_user, load_group,
                       save_user, save_group, list_users)

    elif action == "group":
        _identity_group(args, ws, groups_dir, acl_path, require_capability,
                        GroupRecord, AclEntry, load_group, load_acl,
                        save_group, save_acl, list_groups)

    elif action == "assign":
        require_capability("identity.write", workspace=ws)
        email = args.email
        grp_name = args.to_group
        user = load_user(users_dir, email)
        if user is None:
            raise SystemExit(f"[Identity] User not found: {email}")
        grp = load_group(groups_dir, grp_name)
        if grp is None:
            grp = GroupRecord(name=grp_name, members=[])
        if email not in grp.members:
            grp.members.append(email)
        if grp_name not in user.groups:
            user.groups.append(grp_name)
        save_group(groups_dir, grp)
        save_user(users_dir, user)
        print(f"[Identity] Assigned {email} to group {grp_name}")
        _warn_acl_unsigned(ws)


def _identity_sign_acl(
    args: argparse.Namespace,
    ws: Path,
    identity_dir: Path,
    require_capability,
) -> None:
    """Sign the identity integrity manifest with the org Ed25519 key.

    BUG-MSO-2026-0410: in governed **enforce** mode the identity ACL is trusted
    only when ``integrity.json`` is an Ed25519-signed manifest verified against a
    key pinned OUTSIDE the workspace. The ``mso identity`` mutation commands
    (add-user/add-group/acl set/...) write only an UNSIGNED manifest — so after
    editing the ACL an operator MUST run this command to produce a
    break-glass-usable signed manifest. The signing seed lives off-client (the org
    holds it) and is supplied here via ``--key-file`` or ``MAESTRO_IDENTITY_SIGNING_KEY``;
    it is never written into the workspace.
    """
    require_capability("identity.write", workspace=ws)

    from maestro.identity.integrity import (
        resolve_signing_seed,
        write_signed_manifest,
        SIGNING_SEED_ENV,
    )
    from maestro.governance import verify as _verify
    import base64 as _b64

    if not identity_dir.exists():
        raise SystemExit(
            f"[Identity] No identity store at {identity_dir}. Run 'mso identity init' first."
        )

    key_id = args.key_id
    try:
        seed = resolve_signing_seed(getattr(args, "key_file", None))
    except ValueError as exc:
        raise SystemExit(f"[Identity] Cannot sign ACL: {exc}")

    manifest_path = write_signed_manifest(identity_dir, seed, key_id)
    public_key_b64 = _b64.b64encode(_verify.public_key_from_seed(seed)).decode("ascii")

    print(f"[Identity] Signed integrity manifest written: {manifest_path}")
    print(f"[Identity]   keyId:     {key_id}")
    print(f"[Identity]   publicKey: {public_key_b64}")
    print(
        "[Identity] To make this ACL trusted at runtime, pin the PUBLIC key "
        "out-of-workspace (never the seed):\n"
        "  ~/.maestro/trusted-keys.json:\n"
        f'    {{ "keys": {{ "{key_id}": {{ "algorithm": "ed25519", '
        f'"publicKey": "{public_key_b64}", "status": "active" }} }} }}\n'
        "  Keep the signing seed off-client. Re-run 'mso identity sign-acl' after "
        "any identity/ACL change (the mutation commands leave the manifest unsigned)."
    )


def _identity_user(
    args: argparse.Namespace,
    ws: Path,
    users_dir: Path,
    groups_dir: Path,
    require_capability,
    UserRecord,
    GroupRecord,
    load_user,
    load_group,
    save_user,
    save_group,
    list_users,
) -> None:
    from datetime import datetime, timezone

    user_action = args.user_action

    if user_action == "add":
        require_capability("identity.write", workspace=ws)
        email = args.email
        display_name = args.display_name
        public_key: str | None = None
        if getattr(args, "public_key", None):
            pk_path = Path(args.public_key)
            if not pk_path.exists():
                raise SystemExit(f"[Identity] Public key file not found: {pk_path}")
            public_key = pk_path.read_text(encoding="utf-8").strip()

        existing = load_user(users_dir, email)
        if existing:
            raise SystemExit(f"[Identity] User already exists: {email}. Use 'identity assign' to modify groups.")

        record = UserRecord(
            email=email,
            display_name=display_name,
            groups=[],
            public_key=public_key,
            enrolled_at=datetime.now(timezone.utc).isoformat(),
        )
        save_user(users_dir, record)
        print(f"[Identity] Added user: {email}")
        _warn_acl_unsigned(ws)

    elif user_action == "remove":
        require_capability("identity.write", workspace=ws)
        email = args.email
        path = users_dir / f"{email}.json"
        if not path.exists():
            raise SystemExit(f"[Identity] User not found: {email}")
        from maestro.identity import list_groups as _list_groups, save_group as _save_group
        for grp in _list_groups(groups_dir):
            if email in grp.members:
                grp.members.remove(email)
                _save_group(groups_dir, grp)
        path.unlink()
        from maestro.identity.integrity import remove_from_manifest
        remove_from_manifest(path, users_dir.parent)
        print(f"[Identity] Removed user: {email}")
        _warn_acl_unsigned(ws)

    elif user_action == "list":
        require_capability("identity.read", workspace=ws)
        users = list_users(users_dir)
        if not users:
            print("[Identity] No users enrolled.")
            return
        print(f"  {'EMAIL':<40}  {'DISPLAY NAME':<30}  GROUPS")
        print("  " + "-" * 90)
        for u in users:
            print(f"  {u.email:<40}  {u.display_name:<30}  {', '.join(u.groups) or '—'}")


def _identity_group(
    args: argparse.Namespace,
    ws: Path,
    groups_dir: Path,
    acl_path: Path,
    require_capability,
    GroupRecord,
    AclEntry,
    load_group,
    load_acl,
    save_group,
    save_acl,
    list_groups,
) -> None:
    group_action = args.group_action

    if group_action == "add":
        require_capability("identity.write", workspace=ws)
        name = args.name
        if load_group(groups_dir, name):
            raise SystemExit(f"[Identity] Group already exists: {name}")
        record = GroupRecord(name=name, members=[])
        save_group(groups_dir, record)

        caps_raw = getattr(args, "capabilities", None)
        scope = getattr(args, "scope", "*") or "*"
        if caps_raw:
            entries = load_acl(acl_path)
            for cap in [c.strip() for c in caps_raw.split(",") if c.strip()]:
                new_entry = AclEntry(f"group:{name}", cap, scope)
                if not any(e.principal == new_entry.principal and e.capability == new_entry.capability and e.scope == new_entry.scope for e in entries):
                    entries.append(new_entry)
            save_acl(acl_path, entries)
            print(f"[Identity] Added group: {name} (capabilities: {caps_raw}, scope: {scope})")
        else:
            print(f"[Identity] Added group: {name}")
        _warn_acl_unsigned(ws)

    elif group_action == "remove":
        require_capability("identity.write", workspace=ws)
        name = args.name
        path = groups_dir / f"{name}.json"
        if not path.exists():
            raise SystemExit(f"[Identity] Group not found: {name}")
        path.unlink()
        from maestro.identity.integrity import remove_from_manifest
        remove_from_manifest(path, groups_dir.parent)
        entries = load_acl(acl_path)
        before = len(entries)
        entries = [e for e in entries if e.principal != f"group:{name}"]
        if len(entries) < before:
            save_acl(acl_path, entries)
        print(f"[Identity] Removed group: {name}")
        _warn_acl_unsigned(ws)

    elif group_action == "list":
        require_capability("identity.read", workspace=ws)
        groups = list_groups(groups_dir)
        if not groups:
            print("[Identity] No groups defined.")
            return
        print(f"  {'GROUP':<30}  {'MEMBERS':<6}  DESCRIPTION")
        print("  " + "-" * 70)
        for g in groups:
            desc = g.description or "—"
            print(f"  {g.name:<30}  {len(g.members):<6}  {desc}")


def _identity_init(
    identity_dir: Path,
    users_dir: Path,
    groups_dir: Path,
    acl_path: Path,
) -> None:
    from maestro.identity import seed_identity
    result = seed_identity(identity_dir, users_dir, groups_dir, acl_path)

    print(f"[Identity] Initialised {identity_dir} with default groups and access.json")
    print(f"  Groups created: {', '.join(result['default_groups'])}")
    print(f"  ACL seeded: {result['acl_path']}")
    print(f"  Signing key: {result['signing_key_path']}")
    print("  Add users with: mso identity add-user --email <email> --display-name <name>")


def _identity_rights(args: argparse.Namespace, ws: Path, identity_dir: Path) -> None:
    from maestro.identity.gate import require_capability
    from maestro.identity.rights import (
        rights_export, rights_forget, rights_restrict, export_classification_csv,
    )

    rights_action = args.rights_action
    require_capability("identity.read", workspace=ws)

    if rights_action == "export":
        report = rights_export(args.email, ws)
        print(json.dumps(report, indent=2))

    elif rights_action == "forget":
        require_capability("identity.write", workspace=ws)
        dry_run = not getattr(args, "execute", False)
        plan = rights_forget(args.email, ws, dry_run=dry_run)
        print(json.dumps(plan, indent=2))
        if dry_run:
            print("\n[Identity] Dry-run complete. Pass --execute to perform identity-layer deletions.")
            print("  NOTE: git history rewrite requires manual steps (see plan.manual_steps).")

    elif rights_action == "restrict":
        require_capability("identity.write", workspace=ws)
        result = rights_restrict(args.email, ws)
        print(json.dumps(result, indent=2))

    elif rights_action == "export-classification":
        csv_output = export_classification_csv(ws)
        print(csv_output)


def _identity_acl(
    args: argparse.Namespace,
    ws: Path,
    acl_path: Path,
    require_capability,
    load_acl,
    save_acl,
    AclEntry,
) -> None:
    acl_action = args.acl_action

    if acl_action in ("list", "show"):
        require_capability("identity.read", workspace=ws)
        entries = load_acl(acl_path)
        if not entries:
            print("[Identity] No ACL entries.")
            return
        if args.principal:
            entries = [e for e in entries if e.principal == args.principal]
        print(f"  {'PRINCIPAL':<40}  {'CAPABILITY':<25}  SCOPE")
        print("  " + "-" * 80)
        for e in entries:
            print(f"  {e.principal:<40}  {e.capability:<25}  {e.scope}")

    elif acl_action == "set":
        require_capability("identity.write", workspace=ws)
        entries = load_acl(acl_path)
        new_entry = AclEntry(args.principal, args.capability, args.scope)
        # Avoid duplicates
        for e in entries:
            if e.principal == new_entry.principal and e.capability == new_entry.capability and e.scope == new_entry.scope:
                print(f"[Identity] Entry already exists.")
                return
        entries.append(new_entry)
        save_acl(acl_path, entries)
        from maestro.audit import get_audit_log
        get_audit_log(ws).append(
            "config.modify",
            target="identity/access.json",
            metadata={"op": "acl.set", "principal": args.principal, "capability": args.capability, "scope": args.scope},
        )
        print(f"[Identity] ACL entry added: {args.principal} → {args.capability} ({args.scope})")
        _warn_acl_unsigned(ws)

    elif acl_action == "remove":
        require_capability("identity.write", workspace=ws)
        entries = load_acl(acl_path)
        before = len(entries)
        entries = [
            e for e in entries
            if not (e.principal == args.principal and e.capability == args.capability and e.scope == args.scope)
        ]
        if len(entries) == before:
            print("[Identity] No matching entry found.")
            return
        save_acl(acl_path, entries)
        from maestro.audit import get_audit_log
        get_audit_log(ws).append(
            "config.modify",
            target="identity/access.json",
            metadata={"op": "acl.remove", "principal": args.principal, "capability": args.capability, "scope": args.scope},
        )
        print(f"[Identity] ACL entry removed: {args.principal} → {args.capability} ({args.scope})")
        _warn_acl_unsigned(ws)


def cmd_secrets(args: argparse.Namespace) -> None:
    """Secrets operator tooling: doctor, rotate, scrub, list."""
    action = args.secrets_action
    ws = find_workspace(getattr(args, "project", None))

    try:
        from maestro.secrets.registry import get_provider, _load_enterprise_flag
    except ImportError:
        raise SystemExit("[Secrets] Secrets module not available. Ensure maestro is installed.")

    if action == "doctor":
        _secrets_doctor(ws)
    elif action == "rotate":
        _secrets_rotate(ws, args.key)
    elif action == "scrub":
        _secrets_scrub(ws)
    elif action == "list":
        _secrets_list(ws)
    else:
        raise SystemExit(f"[Secrets] Unknown action: {action}")


def _secrets_doctor(ws: Path) -> None:
    """Verify every secret:// reference in workspace config resolves cleanly."""
    import re as _re

    try:
        from maestro.secrets.registry import get_provider
        from maestro.secrets.refs import parse_ref
    except ImportError:
        raise SystemExit("[Secrets] Secrets module not available.")

    config_dir = resolve_artefact_dir(ws) / "config"
    if not config_dir.is_dir():
        print(f"[Secrets] No config/ directory found at {config_dir}.")
        raise SystemExit(2)

    ref_pattern = _re.compile(r"secret://[^\s\"']+")
    findings: list[tuple[str, str, str]] = []  # (ref, status, detail)

    for cfg_file in sorted(config_dir.glob("*.json")):
        try:
            text = cfg_file.read_text(encoding="utf-8", errors="replace")
        except Exception as exc:
            print(f"[Secrets] Could not read {cfg_file}: {exc}")
            continue
        for match in ref_pattern.finditer(text):
            ref_str = match.group(0)
            ref = parse_ref(ref_str)
            if ref is None:
                findings.append((ref_str, "invalid", str(cfg_file)))
                continue
            try:
                provider = get_provider(ws)
                value = provider.get(ref.key)
                if value is None:
                    findings.append((ref_str, "missing", str(cfg_file)))
                else:
                    findings.append((ref_str, "resolved", str(cfg_file)))
            except PermissionError:
                findings.append((ref_str, "permission-denied", str(cfg_file)))
            except OSError as exc:
                findings.append((ref_str, "network-error", str(exc)))
            except Exception as exc:
                findings.append((ref_str, "error", str(exc)))

    if not findings:
        print("[Secrets] No secret:// references found in workspace config.")
        raise SystemExit(0)

    failures = [f for f in findings if f[1] != "resolved"]
    for ref_str, status, detail in findings:
        icon = "✓" if status == "resolved" else "✗"
        print(f"  {icon} [{status:17s}] {ref_str}")
        if status != "resolved":
            print(f"              → {detail}")

    if failures:
        print(f"\n[Secrets] doctor: {len(failures)} reference(s) failed to resolve.")
        raise SystemExit(1)

    print(f"\n[Secrets] doctor: all {len(findings)} reference(s) resolved cleanly.")
    raise SystemExit(0)


def _secrets_rotate(ws: Path, key: str | None) -> None:
    """Kick a rotation workflow for the given key."""
    if not key:
        print("[Secrets] --key KEY is required for rotate.")
        raise SystemExit(2)

    try:
        from maestro.secrets.registry import get_provider
    except ImportError:
        raise SystemExit("[Secrets] Secrets module not available.")

    try:
        provider = get_provider(ws)
    except Exception as exc:
        print(f"[Secrets] Config error: {exc}")
        raise SystemExit(2)

    provider_type = type(provider).__name__
    rotate_hook = getattr(provider, "rotate_hook", None)
    if callable(rotate_hook):
        try:
            rotate_hook(key)
            print(f"[Secrets] Rotation hook completed for key: {key}")
            raise SystemExit(0)
        except SystemExit:
            raise
        except Exception as exc:
            print(f"[Secrets] Rotation hook failed: {exc}")
            raise SystemExit(1)

    # No hook — print provider-specific documented steps
    steps = {
        "EnvSecretsProvider": [
            f"1. Generate a new value for the secret.",
            f"2. Update the environment variable: export {key}=<new-value>",
            f"3. Restart any services that consume this variable.",
            f"4. Invalidate the old value in your secrets store.",
        ],
        "OsKeyringSecretsProvider": [
            f"1. Generate a new value for the secret.",
            f"2. Run: python -c \"import keyring; keyring.set_password('maestro', '{key}', '<new-value>')\"",
            f"3. Restart any processes that loaded the old value.",
        ],
        "AzureKeyVaultSecretsProvider": [
            f"1. In Azure Portal → Key Vault → Secrets, select '{key}'.",
            f"2. Click 'New Version' and enter the new secret value.",
            f"3. Update any consumers to use the new version or rely on 'latest'.",
            f"4. Disable/delete the old version after a soak period.",
        ],
        "AwsSecretsManagerProvider": [
            f"1. Run: aws secretsmanager put-secret-value --secret-id {key} --secret-string <new-value>",
            f"2. AWS Secrets Manager automatically versions; update rotation schedule if needed.",
            f"3. Verify consumers pick up the new version.",
        ],
        "HashiCorpVaultProvider": [
            f"1. Run: vault kv put <mount>/<path>/{key} value=<new-value>",
            f"2. Vault creates a new secret version automatically.",
            f"3. Update lease TTLs or rotation policies as needed.",
        ],
        "OnePasswordConnectProvider": [
            f"1. Open 1Password and locate the item containing '{key}'.",
            f"2. Edit the field and save a new value.",
            f"3. The Connect API will return the updated value on next request.",
        ],
    }
    provider_steps = steps.get(provider_type, [
        f"1. Generate a new value for '{key}' in your secrets provider ({provider_type}).",
        f"2. Update the value in the provider's management interface.",
        f"3. Restart any consumers that loaded the old value.",
    ])

    print(f"[Secrets] Manual rotation steps for '{key}' (provider: {provider_type}):")
    for step in provider_steps:
        print(f"  {step}")
    raise SystemExit(0)


def _secrets_scrub(ws: Path) -> None:
    """Scan config and log files for likely cleartext secrets."""
    try:
        from maestro.hooks.secret_patterns import Scanner
    except ImportError:
        raise SystemExit("[Secrets] secret_patterns module not available.")

    scan_targets: list[Path] = []

    artefact_dir = resolve_artefact_dir(ws)
    config_dir = artefact_dir / "config"
    if config_dir.is_dir():
        scan_targets.extend(sorted(config_dir.glob("*.json")))

    claude_settings = ws / ".claude" / "settings.json"
    if claude_settings.exists():
        scan_targets.append(claude_settings)

    log_dir = artefact_dir / "logs"
    if log_dir.is_dir():
        scan_targets.extend(sorted(log_dir.glob("*.log")))

    if not scan_targets:
        print("[Secrets] No files found to scrub.")
        raise SystemExit(0)

    scanner = Scanner(workspace_root=ws)
    all_findings: list[tuple[Path, object]] = []

    for path in scan_targets:
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except Exception as exc:
            print(f"[Secrets] Could not read {path}: {exc}")
            continue
        rel = path.relative_to(ws) if path.is_relative_to(ws) else path
        matches = scanner.scan(text, field_label=str(rel), rel_path=str(rel))
        for m in matches:
            all_findings.append((path, m))

    if not all_findings:
        print(f"[Secrets] scrub: {len(scan_targets)} file(s) scanned — no findings.")
        raise SystemExit(0)

    print(f"[Secrets] scrub: {len(scan_targets)} file(s) scanned, {len(all_findings)} finding(s):\n")
    for path, m in all_findings:
        rel = path.relative_to(ws) if path.is_relative_to(ws) else path
        print(f"  [{m.severity:8s}] {rel}")
        print(f"           pattern: {m.pattern_name}")
        print(f"           fix:     replace value with a secret:// reference in workspace.json secretsProvider")
        print()

    raise SystemExit(1)


def _secrets_list(ws: Path) -> None:
    """List keys (never values) exposed by the active provider — gated by ACL secrets.list."""
    try:
        from maestro.secrets.registry import get_provider, _load_enterprise_flag
    except ImportError:
        raise SystemExit("[Secrets] Secrets module not available.")

    if not _load_enterprise_flag(ws):
        print("[Secrets] list requires enterprise mode. Set enterprise: true in workspace.json.")
        raise SystemExit(2)

    try:
        from maestro.identity.gate import require_capability
        require_capability("secrets.list", workspace=ws)
    except ImportError:
        pass  # identity gate not available — allow
    except Exception as exc:
        print(f"[Secrets] Access denied: {exc}")
        raise SystemExit(1)

    try:
        provider = get_provider(ws)
        keys = provider.list()
    except Exception as exc:
        print(f"[Secrets] Provider error: {exc}")
        raise SystemExit(1)

    if not keys:
        print("[Secrets] No keys found in active provider.")
        raise SystemExit(0)

    print(f"[Secrets] {len(keys)} key(s) in active provider:\n")
    for k in sorted(keys):
        print(f"  {k}")
    raise SystemExit(0)


def cmd_audit(args: argparse.Namespace) -> None:
    """Audit log operations: tail, verify, export."""
    ws = find_workspace(getattr(args, "project", None))
    from maestro.identity.gate import require_capability
    from maestro.audit import get_audit_log

    action = args.audit_action
    require_capability("audit.read", workspace=ws)

    log = get_audit_log(ws)

    if action == "tail":
        import time
        log_path = resolve_artefact_dir(ws) / "audit" / "log.jsonl"
        if not log_path.exists():
            print("[Audit] No audit log found at", log_path)
            return
        n = getattr(args, "lines", 20)
        lines: list[str] = []
        with open(log_path, encoding="utf-8") as fh:
            for line in fh:
                lines.append(line)
        for line in lines[-n:]:
            line = line.strip()
            if line:
                _print_audit_line(line)
        if not getattr(args, "no_follow", False):
            print("[Audit] Following log (Ctrl-C to stop)...")
            with open(log_path, encoding="utf-8") as fh:
                fh.seek(0, 2)
                try:
                    while True:
                        line = fh.readline()
                        if line:
                            line = line.strip()
                            if line:
                                _print_audit_line(line)
                        else:
                            time.sleep(0.5)
                except KeyboardInterrupt:
                    pass

    elif action == "verify":
        ok, errors = log.verify_chain()
        if ok:
            print("[Audit] Chain verified — no tampering detected.")
            raise SystemExit(0)
        else:
            print(f"[Audit] Chain FAILED verification ({len(errors)} error(s)):")
            for e in errors:
                print(f"  ✗ {e}")
            raise SystemExit(1)

    elif action == "export":
        import csv as _csv
        import io

        since = None
        if args.since:
            try:
                from datetime import datetime, timezone
                since = datetime.fromisoformat(args.since).replace(tzinfo=timezone.utc)
            except Exception:
                raise SystemExit(f"[Audit] Invalid --since date: {args.since}  (use YYYY-MM-DD)")

        entries = list(log.iterate(since=since))
        fmt = getattr(args, "format", "jsonl")

        if fmt == "jsonl":
            for entry in entries:
                print(json.dumps(entry.to_dict(), separators=(",", ":")))
        elif fmt == "json":
            print(json.dumps([e.to_dict() for e in entries], indent=2))
        elif fmt == "csv":
            out = io.StringIO()
            writer = _csv.writer(out)
            writer.writerow(["seq", "timestamp", "actor", "action", "target", "result", "prevHash", "hash"])
            for e in entries:
                writer.writerow([e.seq, e.timestamp, e.actor, e.action, e.target, e.result, e.prev_hash, e.hash])
            print(out.getvalue(), end="")
        else:
            raise SystemExit(f"[Audit] Unknown format: {fmt}")

    elif action == "anchor":
        from maestro.audit.anchor import load_provider
        from maestro.audit.anchor.scheduler import record_anchor
        from pathlib import Path as _Path

        require_capability("audit.anchor", workspace=ws)

        auto_mode = getattr(args, "auto", False)

        if auto_mode:
            # Read provider and config path from workspace.json
            try:
                _ws_data = json.loads((resolve_artefact_dir(ws) / "config" / "workspace.json").read_text(encoding="utf-8"))
                _audit_cfg = _ws_data.get("audit", {})
                provider_name = _audit_cfg.get("anchorProvider", "fs")
                _cfg_path = _audit_cfg.get("anchorConfig")
                config_file = _Path(_cfg_path) if _cfg_path else None
            except Exception as exc:
                raise SystemExit(f"[Audit] Cannot read workspace.json for --auto mode: {exc}")
        else:
            provider_name = getattr(args, "provider", "fs")
            config_file = None
            if getattr(args, "config", None):
                config_file = _Path(args.config)
                if not config_file.exists():
                    raise SystemExit(f"[Audit] Config file not found: {config_file}")

        if config_file is not None and not config_file.exists():
            raise SystemExit(f"[Audit] Anchor config file not found: {config_file}")

        try:
            provider = load_provider(provider_name, config_file)
        except ValueError as exc:
            raise SystemExit(f"[Audit] {exc}")

        # Get current root hash (last entry's hash)
        last_entry = None
        for last_entry in log.iterate():
            pass
        if last_entry is None:
            raise SystemExit("[Audit] No audit log entries found — nothing to anchor.")

        root_hash = last_entry.hash
        print(f"[Audit] Anchoring root hash {root_hash[:24]}… via {provider_name}")

        try:
            receipt = provider.anchor(root_hash, metadata={"seq": last_entry.seq})
        except RuntimeError as exc:
            raise SystemExit(f"[Audit] Anchor failed: {exc}")

        # Record anchor time before writing the audit entry (unblocks freshness gate)
        record_anchor(ws)

        # Write receipt back into the audit log
        log.append(
            action="audit.anchor",
            target=receipt.location,
            result="ok",
            metadata=receipt.to_dict(),
        )

        print(f"[Audit] Anchor receipt stored at: {receipt.location}")
        print(f"[Audit] Anchor event written to audit log.")


def _print_audit_line(line: str) -> None:
    try:
        d = json.loads(line)
        print(
            f"  [{d.get('seq', '?'):>6}]  {d.get('timestamp', '')}  "
            f"{d.get('actor', ''):<35}  {d.get('action', ''):<25}  "
            f"{d.get('target', ''):<20}  {d.get('result', '')}"
        )
    except Exception:
        print(line)


def cmd_roles(args: argparse.Namespace) -> None:
    """Implement the ``mso roles`` subcommand family."""
    from maestro.roles.loader import (
        CANONICAL_ROLE_CODES, load_core_role, load_effective_role,
        load_overlay, validate_all,
    )
    import difflib, json as _json, warnings as _warnings

    ws: Path | None = None
    try:
        ws = find_workspace()
    except SystemExit:
        pass

    action = args.roles_action

    if action == "list":
        for code in CANONICAL_ROLE_CODES:
            try:
                rd = load_effective_role(code, ws)
                overlay_flag = "" if rd.is_core else " [overlay]"
                model = rd.model or "—"
                print(f"{code:<6}  {rd.role_name:<25}  ({model}){overlay_flag}")
            except Exception as exc:
                print(f"{code:<6}  ERROR: {exc}")

    elif action == "show":
        code = args.code.upper()
        try:
            if args.core:
                rd = load_core_role(code)
            elif args.overlay_only:
                if ws is None:
                    raise SystemExit("[Maestro] No workspace found — cannot load overlay.")
                rd = load_overlay(code, ws)
                if rd is None:
                    print(f"No overlay found for {code}.")
                    return
            else:
                rd = load_effective_role(code, ws)

            if args.json:
                print(_json.dumps(rd.to_dict(), indent=2))
            else:
                print(rd.to_markdown())
        except Exception as exc:
            raise SystemExit(f"[Maestro] roles show failed: {exc}") from exc

    elif action == "validate":
        if ws is None:
            raise SystemExit("[Maestro] No workspace found for validate.")
        results = validate_all(ws)
        any_invalid = False
        for file_path, diags in results.items():
            if diags:
                any_invalid = True
                print(f"INVALID  {file_path}")
                for d in diags:
                    print(f"  {d}")
            else:
                print(f"ok       {file_path}")
        raise SystemExit(1 if any_invalid else 0)

    elif action == "diff":
        code = args.code.upper()
        try:
            core = load_core_role(code)
            if ws is None:
                raise SystemExit("[Maestro] No workspace found — cannot compute diff.")
            effective = load_effective_role(code, ws)
            core_md = core.to_markdown().splitlines(keepends=True)
            eff_md = effective.to_markdown().splitlines(keepends=True)
            diff = difflib.unified_diff(
                core_md, eff_md,
                fromfile=f"{code}.md (core)",
                tofile=f"{code}.md (effective)",
            )
            sys.stdout.writelines(diff)
        except Exception as exc:
            raise SystemExit(f"[Maestro] roles diff failed: {exc}") from exc

    elif action == "migrate-paths":
        print("[Maestro] Migration: copy role files from role-paths.json paths to "
              f"{MSO_DIR_NAME}/config/roles/<CODE>.md overlays.")
        print("See DOC-MSO-2026-0187 for the full migration guide.")


def cmd_packs(args: argparse.Namespace) -> None:
    """Implement the ``mso packs`` subcommand family (FTR-MSO-2026-0383/0384)."""
    from maestro import auth
    from maestro.packs import (
        PackSchemaError, builtin_names, builtin_pack_root, load_all_builtin,
        load_builtin, validate_all_packs, validate_pack_dir,
    )

    action = args.packs_action

    if action == "list":
        packs = load_all_builtin()
        if not packs:
            print("No packs found.")
            return
        print(f"  {'Pack':<20} {'Tier':<12} {'Access':<9} Description")
        print(f"  {'----':<20} {'----':<12} {'------':<9} -----------")
        for p in sorted(packs, key=lambda x: x.id):
            if p.is_free():
                access = "yes"
            else:
                access = "yes" if auth.has_tier(auth.HUB_TIERS) else "upgrade"
            print(f"  {p.id:<20} {p.tier:<12} {access:<9} {p.description}")

    elif action == "show":
        name = args.pack
        try:
            p = load_builtin(name)
        except PackSchemaError as exc:
            available = ", ".join(builtin_names()) or "(none)"
            raise SystemExit(
                f"[Maestro] Unknown pack '{name}': {exc}\nAvailable packs: {available}"
            ) from exc

        if getattr(args, "json", False):
            print(json.dumps(p.manifest, indent=2))
            return

        print(f"Pack:         {p.id}")
        print(f"Name:         {p.display_name}")
        print(f"Description:  {p.description}")
        print(f"Tier:         {p.tier}")
        print(f"Persona:      {p.persona}")
        if p.roles:
            print(f"Roles:        {', '.join(p.roles)}")

        if p.order_types:
            print("\nOrder types:")
            for code, spec in p.order_types.items():
                seq = " -> ".join(spec.get("roleSequence", []))
                desc = spec.get("description", "")
                print(f"  {code:<6} [{seq}]" + (f"  — {desc}" if desc else ""))

        # Anatomy — which optional assets ship on disk
        print("\nAnatomy (shipped assets):")
        overlays = [f.name for f in p.role_overlay_files()]
        templates = [f.name for f in p.order_template_files()]
        print(f"  persona.json           : {'yes' if p.persona_file.exists() else 'no (uses ' + p.persona + ')'}")
        print(f"  role overlays          : {', '.join(overlays) if overlays else 'none (core archetypes)'}")
        print(f"  order-templates        : {', '.join(templates) if templates else 'none'}")
        print(f"  gates.json             : {'yes' if p.gates_file.exists() else 'no'}")
        print(f"  workspace-defaults.json: {'yes' if p.workspace_defaults_file.exists() else 'no'}")
        print(f"  requirements/          : {'yes' if p.requirements_dir.is_dir() else 'no'}")
        print(f"  QUICKSTART.md          : {'yes' if p.quickstart_file.exists() else 'no'}")

    elif action == "validate":
        path_arg = getattr(args, "path", None)
        pack_arg = getattr(args, "pack", None)

        if path_arg:
            target = Path(path_arg)
            pack_results = {str(target): validate_pack_dir(target)}
        elif pack_arg:
            pack_dir = builtin_pack_root(pack_arg)
            if not (pack_dir / "pack.json").exists():
                available = ", ".join(builtin_names()) or "(none)"
                raise SystemExit(
                    f"[Maestro] Unknown pack '{pack_arg}'.\nAvailable packs: {available}"
                )
            pack_results = {pack_arg: validate_pack_dir(pack_dir)}
        else:
            pack_results = validate_all_packs()
            if not pack_results:
                print("No packs found.")
                raise SystemExit(0)

        any_invalid = False
        for pack_id, file_results in pack_results.items():
            print(f"[{pack_id}]")
            for file_path, diags in file_results.items():
                if diags:
                    any_invalid = True
                    print(f"  INVALID  {file_path}")
                    for d in diags:
                        print(f"    {d}")
                else:
                    print(f"  ok       {file_path}")
        raise SystemExit(1 if any_invalid else 0)

    elif action == "apply":
        from maestro.packs import apply_pack, describe_pack_scaffold_result

        base = find_workspace(getattr(args, "project", None))
        pack = _resolve_pack_arg(args.pack, workspace=base)
        force = getattr(args, "force", False)

        # Enrolment-profile pack pin (PLAN-PLN-MSO-2026-0449 §3.4/§6.2). Gated
        # on tier per §3.2a rule 1 — community never even probes for a
        # profile. A broken profile is reported but does not abort the apply
        # (this command's job is packs, not full profile application).
        pin = None
        if auth.has_tier({"pro", "team", "enterprise"}):
            try:
                from maestro.packs import resolve_profile_pack_pin
                pin = resolve_profile_pack_pin(base)
            except Exception as exc:  # noqa: BLE001
                print(
                    f"[Maestro] ⚠ Could not resolve the enrolment profile's pack "
                    f"pin: {exc}",
                    file=sys.stderr,
                )

        if pin and pin.get("locked") and pin.get("id") and pin["id"] != pack.id and not force:
            raise SystemExit(
                f"[Maestro] Refusing to apply pack '{pack.id}' — this workspace is "
                f"locked to pack '{pin['id']}' by its enrolment profile. "
                f"Pass --force to override."
            )

        preview = apply_pack(pack, base, dry_run=True)
        if not preview.changed():
            print(f"[Maestro] Pack '{pack.id}' preview: no changes beyond the current workspace.")
        else:
            print(f"[Maestro] Pack '{pack.id}' preview:")
            for line in describe_pack_scaffold_result(pack, preview):
                print(f"    {line}")

        if getattr(args, "dry_run", False):
            return

        result = apply_pack(pack, base)
        if result.changed():
            print(f"\n[Maestro] Pack '{pack.id}' applied.")
        else:
            print(f"\n[Maestro] Pack '{pack.id}' applied (no changes beyond the current workspace).")

    else:
        raise SystemExit(f"[Maestro] Unknown packs action: {action}")


def cmd_policy(args: argparse.Namespace) -> None:
    """Implement the ``mso policy`` group (FTR-MSO-2026-0397, governance Phase 2).

    Signed-policy-bundle distribution + verification. Enterprise-tier feature.
    """
    from maestro import auth
    from maestro.governance import (
        pull_bundle,
        verify_signed_bundle,
        is_signed,
        GovernanceError,
    )
    from maestro.governance import rollback as _rollback
    from maestro.governance import keys as _keys
    from maestro.workspace import get_workspace_dir, get_artefact_root

    action = args.policy_action

    try:
        # BUG-MSO-2026-0425 audit: governance operates on the REPO checkout (the
        # .mso parent), so the walk-up get_workspace_dir().parent is the intended
        # target here — NOT the artefact plane. The policy bundle path below
        # correctly uses get_artefact_root() for the artefact-side file.
        workspace = get_workspace_dir().parent
    except Exception:
        workspace = Path.cwd()

    if action == "pull":
        # Signed-bundle distribution is an Enterprise-tier capability.
        auth.require_tier({"enterprise"}, "Signed policy bundles (mso policy pull)")
        try:
            result = pull_bundle(workspace=workspace, url=getattr(args, "url", None))
        except GovernanceError as exc:
            raise SystemExit(f"[Maestro] policy pull refused: {exc}")
        marker = "✓" if result.source == "network" else "⚠"
        print(f"{marker} {result.message}")
        if result.source == "network":
            print(f"  bundle:  {result.bundle_id} v{result.version}  (key {result.key_id})")
            print(f"  written: {result.path}")
        return

    if action == "verify":
        # Phase 5 (FTR-MSO-2026-0400): `--ci` runs the CI diff-evaluator
        # enforcement backstop instead of Ed25519 signature verification. Same
        # subcommand, distinct mode — a bypassed client-side rule still fails
        # the merge here. See `mso docs governance-trust-boundary`.
        if getattr(args, "ci", False):
            from maestro.governance.ci_verify import run_ci_verify
            repo = Path(getattr(args, "repo", None) or Path.cwd())
            raise SystemExit(run_ci_verify(args, workspace, repo))

        bundle_path = Path(getattr(args, "bundle", None) or
                           (get_artefact_root() / "config" / "policy-bundle.json"))
        if not bundle_path.exists():
            raise SystemExit(f"[Maestro] no policy bundle at {bundle_path}")
        try:
            raw = json.loads(bundle_path.read_text(encoding="utf-8"))
        except Exception as exc:  # noqa: BLE001
            raise SystemExit(f"[Maestro] bundle unreadable ({bundle_path}): {exc}")
        if not is_signed(raw):
            print(f"⚠ {bundle_path} is UNSIGNED (Phase-1 / integrity-manifest bundle).")
            return
        try:
            # Verify without advancing the anti-rollback floor (read-only check).
            out = verify_signed_bundle(raw, workspace=workspace, record=False)
        except GovernanceError as exc:
            raise SystemExit(f"[Maestro] ✗ signature verification FAILED: {exc}")
        print(f"✓ signature verified: {out.bundle_id} v{out.version} (key {out.key_id})")
        return

    if action == "show":
        artefact_root = get_artefact_root()
        bundle_path = artefact_root / "config" / "policy-bundle.json"
        print(f"Workspace policy bundle: {bundle_path}")
        if bundle_path.exists():
            try:
                raw = json.loads(bundle_path.read_text(encoding="utf-8"))
                signed = "signed" if is_signed(raw) else "unsigned"
                print(f"  bundleId:   {raw.get('bundleId', '?')}")
                print(f"  version:    {raw.get('version', '?')}  ({signed})")
                print(f"  issuer:     {raw.get('issuer', '-')}")
                print(f"  expiresAt:  {raw.get('expiresAt', '-')}")
            except Exception as exc:  # noqa: BLE001
                print(f"  (unreadable: {exc})")
        else:
            print("  (none — Phase-1 / non-Enterprise workspace)")

        try:
            trusted = _keys.load_trusted_keys(workspace)
            print(f"Pinned trusted keys ({len(trusted)}):")
            for kid, k in sorted(trusted.items()):
                print(f"  {kid:<24} {k.status:<9} [{k.source}]")
        except GovernanceError as exc:
            print(f"  (key registry error: {exc})")

        try:
            ledger = _rollback.load_ledger(artefact_root)
            floors = ledger.get("bundles", {})
            if floors:
                print("Anti-rollback version floors:")
                for bid, entry in sorted(floors.items()):
                    print(f"  {bid:<24} v{entry.get('version', '?')}  "
                          f"lastVerified={entry.get('lastVerifiedAt', '-')}")
        except GovernanceError as exc:
            print(f"  (version ledger error: {exc})")
        return

    if action == "report":
        # FTR-MSO-2026-0399 (governance Phase 4): SOC2/ISO compliance evidence
        # assembled from live policy state + the hash-chained audit log.
        from maestro.governance import collect_evidence, write_report

        as_json = bool(getattr(args, "json", False))
        output = getattr(args, "output", None)
        if as_json:
            import json as _json
            evidence = collect_evidence(workspace, verify=True)
            print(_json.dumps(evidence, indent=2, sort_keys=True))
            return
        out_path, evidence = write_report(
            workspace, verify=True, output=Path(output) if output else None,
        )
        totals = evidence["audit"]["totals"]
        print(f"✓ compliance evidence written: {out_path}")
        print(f"  governed mode: {evidence['governedMode']}  "
              f"bundles: {len(evidence['bundles'])}  "
              f"rules: {len(evidence['ruleInventory'])}")
        print(f"  audit events — eval:{totals['policy.eval']} "
              f"deny:{totals['policy.deny']} breakglass:{totals['policy.breakglass']}")
        if not evidence["audit"]["active"]:
            print("  (audit log inactive — statistics zeroed; see the report's note)")
        return

    # -----------------------------------------------------------------------
    # Admin policy-authoring surface (FTR-MSO-2026-0479, PLAN-PLN-MSO-2026-0449
    # §5.2-5.4). `keygen`/`init`/`lint`/`sign` are ungated — an evaluator must
    # be able to author and sign a trial bundle before buying anything.
    # `trust add`/`trust rotate`/`enable`/`publish` arm governance on a device
    # and are Team/Enterprise-gated (governance is a Team/Enterprise capability,
    # PLAN-PLN-MSO-2026-0450 D3).
    # -----------------------------------------------------------------------
    from maestro.governance import authoring

    if action == "keygen":
        import base64 as _b64
        out_dir = Path(getattr(args, "out", None) or Path.cwd())
        try:
            seed, public_key = authoring.generate_keypair()
            seed_path = authoring.write_seed_file(out_dir, args.key_id, seed)
        except GovernanceError as exc:
            raise SystemExit(f"[Maestro] policy keygen refused: {exc}")
        print(f"✓ generated Ed25519 keypair '{args.key_id}'")
        print(f"  seed (KEEP SECRET, off-client only): {seed_path}")
        print("  public key (pin this with `mso policy trust add`):")
        print(f"    {_b64.b64encode(public_key).decode('ascii')}")
        return

    if action == "init":
        from_packs = [p for p in (getattr(args, "from_packs", None) or "").split(",") if p.strip()]
        try:
            draft = authoring.draft_bundle(
                args.bundle_id, from_packs=from_packs, governed_mode=args.governed_mode,
            )
        except GovernanceError as exc:
            raise SystemExit(f"[Maestro] policy init refused: {exc}")
        out_path = Path(args.out)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(json.dumps(draft, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        print(f"✓ draft bundle written: {out_path}  ({len(draft['rules'])} rule(s))")
        print(f"  Edit it, then: mso policy lint {out_path}")
        return

    if action == "lint":
        bundle_path = Path(args.bundle)
        if not bundle_path.exists():
            raise SystemExit(f"[Maestro] no bundle at {bundle_path}")
        try:
            raw = json.loads(bundle_path.read_text(encoding="utf-8"))
        except Exception as exc:  # noqa: BLE001
            raise SystemExit(f"[Maestro] {bundle_path} is not valid JSON: {exc}")
        try:
            parsed = authoring.lint_bundle(raw)
        except GovernanceError as exc:
            raise SystemExit(f"[Maestro] ✗ lint FAILED: {exc}")
        signed_note = " (already signed — signing again will re-sign)" if is_signed(raw) else ""
        print(f"✓ {bundle_path} is a valid draft: {parsed.bundle_id} v{parsed.version}, "
              f"{len(parsed.rules)} rule(s){signed_note}")
        return

    if action == "sign":
        from maestro.governance.signing import sign_bundle
        bundle_path = Path(args.bundle)
        if not bundle_path.exists():
            raise SystemExit(f"[Maestro] no bundle at {bundle_path}")
        try:
            raw = json.loads(bundle_path.read_text(encoding="utf-8"))
        except Exception as exc:  # noqa: BLE001
            raise SystemExit(f"[Maestro] {bundle_path} is not valid JSON: {exc}")
        try:
            authoring.lint_bundle(raw)  # refuse to sign a structurally-invalid draft
        except GovernanceError as exc:
            raise SystemExit(f"[Maestro] ✗ refusing to sign an invalid bundle: {exc}")
        try:
            seed = authoring.resolve_signing_seed(getattr(args, "key_file", None))
        except ValueError as exc:
            raise SystemExit(f"[Maestro] {exc}")
        signed = sign_bundle(raw, seed, args.key_id)
        out_path = Path(getattr(args, "out", None) or bundle_path)
        out_path.write_text(json.dumps(signed, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        print(f"✓ signed: {out_path}  (bundleId={signed['bundleId']}, keyId={args.key_id})")
        print(f"  verify with: mso policy verify --bundle {out_path}")
        return

    if action == "publish":
        auth.require_tier({"team", "enterprise"}, "Publishing a signed policy bundle (mso policy publish)")
        bundle_path = Path(args.bundle)
        if not bundle_path.exists():
            raise SystemExit(f"[Maestro] no bundle at {bundle_path}")
        try:
            raw = json.loads(bundle_path.read_text(encoding="utf-8"))
        except Exception as exc:  # noqa: BLE001
            raise SystemExit(f"[Maestro] {bundle_path} is not valid JSON: {exc}")
        if not is_signed(raw):
            raise SystemExit(
                f"[Maestro] {bundle_path} is UNSIGNED — sign it first with `mso policy sign` "
                "before publishing (an unsigned bundle must never be distributed as if trusted)."
            )
        dest = getattr(args, "out", None)
        if dest:
            dest_path = Path(dest)
            dest_path.parent.mkdir(parents=True, exist_ok=True)
            dest_path.write_text(bundle_path.read_text(encoding="utf-8"), encoding="utf-8")
            print(f"✓ copied to {dest_path} — upload it to your HTTPS host, then set "
                  "governance.pullUrl (or MAESTRO_POLICY_PULL_URL) to its URL.")
        else:
            print(f"✓ {bundle_path} is signed and ready to publish. Host it over HTTPS, then "
                  "set governance.pullUrl (or MAESTRO_POLICY_PULL_URL) to its URL so devices "
                  "can `mso policy pull` it.")
        return

    if action == "enable":
        auth.require_tier({"team", "enterprise"}, "Enabling governance (mso policy enable)")
        try:
            path = authoring.write_governed_mode(workspace, args.governed_mode)
        except GovernanceError as exc:
            raise SystemExit(f"[Maestro] {exc}")
        print(f"✓ governance.governedMode = {args.governed_mode!r} written to {path}")
        return

    if action == "trust-add":
        auth.require_tier({"team", "enterprise"}, "Pinning a trusted signing key (mso policy trust add)")
        try:
            path = _keys.write_home_trusted_key(
                args.key_id, args.public_key,
                status=args.status, not_after=getattr(args, "not_after", None),
            )
        except GovernanceError as exc:
            raise SystemExit(f"[Maestro] {exc}")
        print(f"✓ trusted key '{args.key_id}' pinned ({args.status}) → {path}")
        return

    if action == "trust-rotate":
        auth.require_tier({"team", "enterprise"}, "Rotating a trusted signing key (mso policy trust rotate)")
        try:
            path = _keys.rotate_home_trusted_key(
                args.retire_id, args.activate_id,
                activate_public_key_b64=getattr(args, "public_key", None),
                not_after=getattr(args, "not_after", None),
            )
        except GovernanceError as exc:
            raise SystemExit(f"[Maestro] {exc}")
        print(f"✓ rotated: '{args.retire_id}' → retiring, '{args.activate_id}' → active. ({path})")
        return


def cmd_docs(args: argparse.Namespace) -> None:
    """Browse documentation topics shipped with Maestro."""
    docs_dir = Path(__file__).parent / "docs"
    topic: str | None = getattr(args, "topic", None)

    if not docs_dir.exists():
        print("Documentation not found in this installation.")
        return

    all_docs = sorted(docs_dir.glob("*.md"), key=lambda p: p.stem.lower())

    if not topic:
        print("Available topics (use 'mso docs <topic>' to read):\n")
        for p in all_docs:
            print(f"  {p.stem.lower()}")
        return

    # Exact match (case-insensitive)
    exact = [p for p in all_docs if p.stem.lower() == topic.lower()]
    if exact:
        print(exact[0].read_text(encoding="utf-8"))
        return

    # Partial / substring match
    partial = [p for p in all_docs if topic.lower() in p.stem.lower()]
    if len(partial) == 1:
        print(partial[0].read_text(encoding="utf-8"))
        return
    if len(partial) > 1:
        matches = ", ".join(p.stem.lower() for p in partial)
        print(f"Ambiguous topic '{topic}'. Matches: {matches}")
        return

    available = ", ".join(p.stem.lower() for p in all_docs)
    print(f"Unknown topic '{topic}'.\nAvailable: {available}")


def cmd_version(args: argparse.Namespace) -> None:
    """Print Maestro version. (Auth check bypassed — see auth.py.)"""
    from maestro import __version__, __title__
    print(f"{__title__} v{__version__}")


def cmd_config_models(args: argparse.Namespace) -> None:
    """`mso config models` — show the resolved model, context-window, and
    effort for each role with the override source that decided each value
    (FTR-ADM-2026-0129, extended by FTR-MSO-2026-0281).

    Resolution order: per-order → workspace config → env var → role overlay → built-in.
    The per-order layer can't be displayed in a static table (it depends on
    the order being dispatched), so this command shows the next three.

    Copilot review: derives the role list dynamically (from ROLE_MODELS +
    workspace + env vars) so future roles or unfamiliar workspace overrides
    show up automatically. Exits 1 if any displayed value is unsupported,
    so scripts can rely on `mso config models` as a config doctor.
    """
    import os as _os
    import sys as _sys
    from maestro.core.crew import (
        ROLE_MODELS, DEFAULT_MODEL, SUPPORTED_MODELS,
        _load_workspace_role_models,
        resolve_context_window_for,
        resolve_effort_for,
    )
    from maestro.core_constants import VALID_CONTEXT_WINDOWS, VALID_EFFORTS_ALL

    workspace = _load_workspace_role_models()

    # Build role list dynamically: built-in defaults ∪ workspace overrides ∪
    # any role that has a MAESTRO_MODEL_*, MAESTRO_CONTEXT_*, or
    # MAESTRO_EFFORT_* env var set. This way custom roles or roles only seen
    # in config still appear without a doc-update lag.
    env_roles = {
        var.removeprefix("MAESTRO_MODEL_")
        for var in _os.environ
        if var.startswith("MAESTRO_MODEL_")
    } | {
        var.removeprefix("MAESTRO_CONTEXT_")
        for var in _os.environ
        if var.startswith("MAESTRO_CONTEXT_")
    } | {
        var.removeprefix("MAESTRO_EFFORT_")
        for var in _os.environ
        if var.startswith("MAESTRO_EFFORT_")
    }
    roles = sorted(set(ROLE_MODELS.keys()) | set(workspace.keys()) | env_roles)

    print("\nMaestro role-model resolution (FTR-ADM-2026-0129 / FTR-MSO-2026-0281)")
    print("Order: per-order > workspace config > env var > role overlay > built-in default\n")
    print(f"  {'Role':<6} {'Model':<32} {'Context':<10} {'Effort':<8} Source")
    print(f"  {'----':<6} {'-----':<32} {'-------':<10} {'------':<8} ------")
    has_unknown = False
    for role in roles:
        env_var = f"MAESTRO_MODEL_{role}"
        env_val = _os.environ.get(env_var, "")
        ws_val = workspace.get(role, "")
        # ws_val may be a string (legacy) or a dict (object form — FTR-MSO-2026-0281)
        if ws_val:
            if isinstance(ws_val, dict):
                model = ws_val.get("model", DEFAULT_MODEL) or DEFAULT_MODEL
            else:
                model = ws_val
            source = f"{MSO_DIR_NAME}/config/role-models.json"
        elif env_val:
            model, source = env_val, f"${env_var}"
        else:
            model, source = ROLE_MODELS.get(role, DEFAULT_MODEL), "built-in default"

        # Resolve context window and effort via the full 5-layer chain
        try:
            context = resolve_context_window_for(role)
        except Exception:
            context = "standard"
        try:
            effort = resolve_effort_for(role)
        except Exception:
            effort = "high"

        model_valid = "" if model in SUPPORTED_MODELS else "  (UNKNOWN MODEL!)"
        if model_valid:
            has_unknown = True

        context_valid = "" if context in VALID_CONTEXT_WINDOWS else "  (UNKNOWN CONTEXT!)"
        if context_valid:
            has_unknown = True

        effort_valid = "" if effort in VALID_EFFORTS_ALL else "  (UNKNOWN EFFORT!)"
        if effort_valid:
            has_unknown = True

        flags = model_valid or context_valid or effort_valid
        print(f"  {role:<6} {model:<32} {context:<10} {effort:<8} {source}{flags}")

    print(
        f"\nSupported model IDs: {', '.join(sorted(SUPPORTED_MODELS))}\n"
        f"Valid context windows: {', '.join(sorted(VALID_CONTEXT_WINDOWS))}\n"
        f"Valid effort tiers:    {', '.join(sorted(VALID_EFFORTS_ALL))}\n"
        f"To override:\n"
        f"  - Env var (model):    set MAESTRO_MODEL_SHP=claude-opus-4-7\n"
        f"  - Env var (context):  set MAESTRO_CONTEXT_BLD=1m\n"
        f"  - Env var (effort):   set MAESTRO_EFFORT_BLD=high\n"
        f"  - Workspace (object form):\n"
        f"      edit .mso/config/role-models.json\n"
        f"      {{\"models\": {{\"BLD\": {{\"model\": \"claude-opus-4-7\", \"contextWindow\": \"1m\", \"effort\": \"high\"}}}}}}\n"
        f"  - Per-order:  add `model`, `contextWindow`, or `effort` fields to the order JSON\n"
    )

    # Copilot review: exit non-zero if any displayed value is unsupported so
    # scripts (CI doctors, dispatcher pre-flight) can rely on a clean exit.
    if has_unknown:
        print(
            "ERROR: One or more roles resolve to an unsupported model, context window, "
            "or effort tier. Dispatch will refuse to launch crews against these values — "
            "fix the override source shown above before running `mso dispatch`.",
            file=_sys.stderr,
        )
        _sys.exit(1)


def cmd_licence(args: argparse.Namespace) -> None:
    """`mso licence <activate|status|deactivate|revalidate>` — VOY-0031,
    reworked for the token schema (FTR-MSO-2026-0451/0452, PLAN-PLN-MSO-2026-0450).

    Handles both schemas: legacy `adm_lic_…` Polar keys (schema_version 1,
    untouched) and the new `MSO1.` offline tokens (schema_version 2). A
    licence-less install is community tier, not an error (§D3a) — `status`
    reports that plainly instead of exiting non-zero.
    """
    import json as _json
    import os as _os
    from maestro import licence as _licence
    from maestro.licence.errors import (
        LicenceError, LicenceMissing, LicenceInvalid, LicenceRevoked,
        LicenceExpired, LicenceTampered, LicenceMalformed, LicenceUntrusted,
        LicenceForged,
    )
    from maestro.licence.client import PolarError

    sub = args.licence_cmd

    if sub == "activate":
        key = args.key or _os.environ.get("MAESTRO_LICENCE_KEY", "")
        if not key:
            print(
                "Error: provide a key as `mso licence activate <KEY>` "
                "or set MAESTRO_LICENCE_KEY.",
                file=sys.stderr,
            )
            sys.exit(1)
        try:
            rec = _licence.activate(key)
        except LicenceInvalid as exc:
            print(f"Activation refused: {exc}", file=sys.stderr)
            sys.exit(1)
        except (LicenceMalformed, LicenceUntrusted, LicenceForged) as exc:
            print(f"Activation refused — token failed verification: {exc}", file=sys.stderr)
            sys.exit(1)
        except LicenceExpired as exc:
            print(f"Activation refused — token is not currently valid: {exc}", file=sys.stderr)
            sys.exit(1)
        except PolarError as exc:
            if exc.status == 0:
                print(
                    f"Couldn't reach the licence backend: {exc.reason}\n"
                    "Activation requires online verification — try again with a live network.",
                    file=sys.stderr,
                )
                sys.exit(2)
            print(f"Polar API error {exc.status}: {exc.reason}", file=sys.stderr)
            sys.exit(1)
        if rec.schema_version == 2:
            trial_note = " (trial)" if rec.is_trial else ""
            print(f"Licence activated  ({rec.tier}{trial_note} tier, expires {rec.expires_at})")
        else:
            print(f"Licence activated  ({rec.tier} tier, expires {rec.expires_at})")
        return

    if sub == "status":
        state = _licence.resolve_state()
        if args.json:
            print(_json.dumps({
                "tier": state.tier,
                "effective_tier": state.effective_tier,
                "schema": state.schema,
                "is_trial": state.is_trial,
                "expires_at": state.expires_at,
                "stopped": state.stopped,
                "downgraded": state.downgraded,
                "downgraded_from": state.downgraded_from,
                "used_grace": state.used_grace,
                "grace_remaining_days": state.grace_remaining_days,
                "warning": state.warning,
            }, indent=2))
            return
        if state.schema is None:
            print(f"No licence activated — running at {state.effective_tier} tier (this is not an error).")
            print("Run `mso licence activate <TOKEN>` to activate a paid licence.")
            return
        if state.schema == 1:
            from maestro.licence import config as _licence_config
            rec = state.record
            test_mode = _licence_config.is_test_mode()
            fake_active = _os.environ.get("MAESTRO_LICENCE_FAKE_ACTIVATION") == "1"
            is_fake_record = rec.customer_id.startswith("cust_FAKE_")
            if is_fake_record:
                print("[FAKE ACTIVATION] Synthetic licence — Polar bypass; not for production.")
            elif test_mode:
                print("[TEST MODE] Polar sandbox — no real billing.")
            print(f"Tier:               {rec.tier}")
            print(f"Customer:           {rec.customer_id}")
            print(f"Issued:             {rec.issued_at}")
            print(f"Expires:            {rec.expires_at}")
            print(f"Last validated:     {rec.last_validated_at}")
            print(f"Offline grace ends: {rec.offline_grace_until}")
            print(f"Manage subscription: {_licence_config.POLAR_PORTAL_URL}")
            if state.warning:
                print(state.warning, file=sys.stderr)
            return
        # schema == 2 — the new token record
        rec = state.record
        print(f"Tier:               {state.tier}{' (trial)' if state.is_trial else ''}")
        if state.downgraded:
            print(f"Effective tier:     {state.effective_tier}  (DOWNGRADED from {state.downgraded_from})")
        elif state.stopped:
            print(f"Effective tier:     STOPPED  (was {state.tier})")
        else:
            print(f"Effective tier:     {state.effective_tier}")
        print(f"Licensee:           {rec.licensee_name or '(none recorded)'}")
        print(f"Licence ID:         {rec.licence_id}")
        print(f"Issued:             {rec.issued_at}")
        print(f"Expires:            {rec.expires_at}")
        print(f"Last verified:      {rec.last_verified_at}")
        if state.used_grace:
            print(f"Grace remaining:    {state.grace_remaining_days} day(s)")
        if state.warning:
            print(state.warning, file=sys.stderr)
        return

    if sub == "deactivate":
        rec = _licence.status()
        _licence.deactivate()
        if rec is not None and getattr(rec, "schema_version", 1) == 1:
            from maestro.licence import config as _licence_config
            print(
                "Licence record removed (Polar subscription unaffected — manage at "
                f"{_licence_config.POLAR_PORTAL_URL})."
            )
        else:
            print("Licence record removed. Running at community tier.")
        return

    if sub == "revalidate":
        # FTR-0120 — test-only flag. Rewind last_validated_at to force the
        # next CLI invocation through the offline-grace path. v1-only (the
        # v2 token has no "last validated" concept to rewind — use
        # `licence.resolve_state(now=...)` in tests instead). Requires the
        # operator to opt in via MAESTRO_LICENCE_TEST_FLAGS=1 in the
        # parent shell so it can't be set inside a crew session or by a
        # customer who happened to read --help output.
        if getattr(args, "offline_mark_stale", False):
            if _os.environ.get("MAESTRO_LICENCE_TEST_FLAGS") != "1":
                print(
                    "Refused: --offline-mark-stale is a test-only flag. Set "
                    "MAESTRO_LICENCE_TEST_FLAGS=1 in the operator shell "
                    "before running this.",
                    file=sys.stderr,
                )
                sys.exit(1)
            from maestro.licence import storage as _storage
            from datetime import datetime as _dt, timedelta as _td, timezone as _tz
            try:
                rec = _storage.load_record()
            except LicenceMissing:
                print("No licence to mark stale. Run `mso licence activate <KEY>` first.", file=sys.stderr)
                sys.exit(1)
            except LicenceTampered as exc:
                print(f"Licence tampered: {exc}", file=sys.stderr)
                sys.exit(1)
            if getattr(rec, "schema_version", 1) != 1:
                print(
                    "--offline-mark-stale only applies to legacy (schema_version 1) "
                    "records. For a token licence, pass `now=` to "
                    "`licence.resolve_state()` in a test instead.",
                    file=sys.stderr,
                )
                sys.exit(1)
            stale = (_dt.now(_tz.utc) - _td(hours=25)).isoformat()
            rec.last_validated_at = stale
            _storage.save_record(rec)
            print(
                f"Marked licence record stale (last_validated_at={stale}). "
                "The next `mso` run will hit the offline-grace path."
            )
            return
        try:
            rec = _licence.validate(strict=True)
        except LicenceMissing:
            print("No licence to revalidate — running at community tier (this is not an error).", file=sys.stderr)
            sys.exit(1)
        except LicenceTampered as exc:
            print(f"Licence tampered: {exc}", file=sys.stderr)
            sys.exit(1)
        except (LicenceRevoked, LicenceExpired) as exc:
            print(f"Licence rejected: {exc}", file=sys.stderr)
            sys.exit(1)
        except (LicenceMalformed, LicenceUntrusted, LicenceForged) as exc:
            print(f"Licence token failed verification: {exc}", file=sys.stderr)
            sys.exit(1)
        except LicenceError as exc:
            print(f"Licence error: {exc}", file=sys.stderr)
            sys.exit(1)
        if getattr(rec, "stopped", False):
            print(getattr(rec, "warning", None) or f"Licence STOPPED ({rec.tier} past grace).", file=sys.stderr)
            sys.exit(1)
        if getattr(rec, "used_grace", False):
            remaining = getattr(rec, "grace_remaining_days", 0)
            print(
                f"⚠  Couldn't reach the licence backend; running on offline grace "
                f"({remaining} days remaining). Reconnect to revalidate.",
                file=sys.stderr,
            )
        effective = getattr(rec, "effective_tier", None) or rec.tier
        print(f"Licence still valid ({effective} tier, expires {rec.expires_at})")
        return

    if sub == "keygen":
        from maestro.licence.issue import LicenceIssueError, keygen
        try:
            _seed, public_key_b64 = keygen(args.out)
        except LicenceIssueError as exc:
            print(f"[Licence] Cannot generate key: {exc}", file=sys.stderr)
            sys.exit(1)
        print(f"[Licence] Signing seed written: {args.out}")
        print("[Licence] Keep this file OFFLINE — password manager or a sealed offline "
              "backup. Nothing else should hold it.")
        print(f"[Licence] publicKey (ed25519): {public_key_b64}")
        print(
            "[Licence] To make tokens signed with this key verifiable, add it to "
            "maestro/licence/keys/licence-keys.json under a chosen keyId and ship a "
            "release:\n"
            '    { "keys": { "<keyId>": { "algorithm": "ed25519", '
            f'"publicKey": "{public_key_b64}", "status": "active" }} }}'
        )
        return

    if sub == "issue":
        from maestro.licence.issue import (
            LicenceIssueError, append_to_register, issue as issue_licence,
            resolve_signing_seed,
        )
        try:
            seed = resolve_signing_seed(getattr(args, "key_file", None))
        except LicenceIssueError as exc:
            print(f"[Licence] Cannot issue: {exc}", file=sys.stderr)
            sys.exit(1)

        entitlements = None
        if getattr(args, "entitlements", None):
            entitlements = [e.strip() for e in args.entitlements.split(",") if e.strip()]

        try:
            issued = issue_licence(
                tier=args.tier,
                licensee_name=args.licensee,
                contact=args.contact,
                key_id=args.key_id,
                seed=seed,
                seats=args.seats,
                entitlements=entitlements,
                term_days=args.term_days,
                expires_at=getattr(args, "expires", None),
                not_before=getattr(args, "not_before", None),
                licence_id=getattr(args, "licence_id", None),
            )
        except LicenceIssueError as exc:
            print(f"[Licence] Cannot issue: {exc}", file=sys.stderr)
            sys.exit(1)

        record = append_to_register(args.register, issued)
        print(issued.token)
        print(
            f"[Licence] Issued {issued.payload['tier']} licence "
            f"{issued.payload['licenceId']} to {args.licensee} "
            f"(expires {issued.payload['expiresAt']}).",
            file=sys.stderr,
        )
        print(f"[Licence] Recorded in register: {args.register} "
              f"(tokenSha256={record['tokenSha256'][:12]}…)", file=sys.stderr)
        return


def _cmd_review(action: str, args: argparse.Namespace) -> None:
    """Dispatch to the appropriate review handler."""
    from maestro import review as _review
    handler = {
        "queue": _review.cmd_review_queue,
        "show": _review.cmd_review_show,
        "approve": _review.cmd_review_approve,
        "revise": _review.cmd_review_revise,
        "reject": _review.cmd_review_reject,
    }[action]
    handler(args)


def cmd_data_flow(args: argparse.Namespace) -> None:
    """Generate a data-flow diagram of all outbound destinations."""
    from maestro.egress.diagram import generate_diagram

    workspace = find_workspace(getattr(args, "project", None))
    fmt = getattr(args, "format", "mermaid") or "mermaid"
    mode = getattr(args, "mode", None) or None
    output_path = None
    if getattr(args, "output", None):
        output_path = Path(args.output)

    diagram = generate_diagram(workspace, fmt=fmt, output=output_path, mode=mode)

    if output_path:
        _prod = current_persona().term("product")
        print(f"[{_prod}] Data-flow diagram written to: {output_path}")
    else:
        print(diagram)


# ---------------------------------------------------------------------------
# CLI definition
# ---------------------------------------------------------------------------

def build_parser() -> FriendlyArgumentParser:
    parser = FriendlyArgumentParser(
        prog="mso",
        description="Maestro — AI-powered multi-agent Claude Code orchestration",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
commands:
  dispatch    Launch fleet crews from the dispatch queue
  cleanup     Stop rogue processes and reset stale state (auto-backup)
  status      Show fleet status dashboard
  usage       Token usage and cost reporting
  crew        Operate an individual crew
  verify      Post-voyage build/test verification
  bridge      Manage the Mobile Command Bridge (Slack + poller)
  hub         Manage the Maestro Hub dashboard server (enterprise/team)
  chart       Render a chart — read-only graph X-ray (community tier)
  voyage      Create and manage voyages
  bug         Create a BUG order
  backup      Create or list project state backups
  restore     Restore project state from a backup ZIP
  init        Scaffold a new Maestro workspace
  update      Propagate schema updates to an existing workspace
  projects    List or manage registered projects
  version     Print version

examples:
  mso dispatch --max-crews 3
  mso status --once
  mso usage --voyage VOY-OTM-2026-0700
  mso bridge restart
  mso chart show VOY-ADM-2026-0001
  mso voyage create "My new voyage" --project ADM
  mso voyage list --project ADM
  mso voyage status VOY-ADM-2026-0001
  mso bug "Login crashes on mobile" --project ADM
  mso backup --project OTM
  mso backup --list
  mso restore maestro-backups/maestro-backup-all-2026-03-30-120000.zip --dry-run
  mso init --project MYPROJECT --directory ./my-workspace
  mso update
  mso update --dry-run
  mso projects list
  mso projects remove PSG
        """,
    )

    parser.add_argument(
        "--debug",
        action="store_true",
        default=False,
        help="Show full traceback on errors (also enabled by MAESTRO_DEBUG=1)",
    )

    sub = parser.add_subparsers(
        dest="command",
        metavar="<command>",
        parser_class=FriendlyArgumentParser,
    )
    sub.required = True

    # -- dispatch --
    p = sub.add_parser("dispatch", help="Launch fleet crews")
    p.add_argument("--max-crews", type=int, default=5, metavar="N",
                   help="Maximum concurrent crews (default: 5)")
    p.add_argument("--cleanup", action="store_true",
                   help="Run cleanup before dispatching")
    p.add_argument("--stagger-delay", type=int, default=30,
                   help="Seconds between crew launches (default: 30)")
    p.add_argument("--timeout", type=int, default=60,
                   help="Per-iteration timeout in minutes (default: 25)")
    p.add_argument("--max-turns", type=int, default=200,
                   help="Max Claude turns per crew iteration (default: 200)")
    p.add_argument("--convergence-timeout", type=int, default=None, metavar="SECS",
                   help="Per-op timeout for convergence git network ops in seconds "
                        "(default: 60; also configurable via workspace.json "
                        "completion.convergenceNetworkTimeout)")
    p.add_argument("--project", metavar="@PRJ",
                   help="Registered project acronym (e.g. @ADM)")
    p.set_defaults(func=cmd_dispatch)

    # -- cleanup --
    p = sub.add_parser("cleanup", help="Stop rogue processes and reset stale state")
    p.add_argument("--project", metavar="@PRJ",
                   help="Registered project acronym (e.g. @ADM)")
    p.add_argument("--no-backup", action="store_true", dest="no_backup",
                   help="Skip auto-backup (fast recovery path)")
    p.add_argument("--force", action="store_true",
                   help="Proceed even though a live dispatcher is running (BUG-MSO-2026-0673 "
                        "F1's refusal) — the escape hatch for a dispatcher that is alive but "
                        "WEDGED (see `mso doctor`'s dispatcher.heartbeat check), not for a "
                        "healthy one (BUG-MSO-2026-0681 F2). Also clears a recycled/stale "
                        "demo.pid lock (BUG-MSO-2026-0683 F4)")
    p.add_argument("--maestro-dir", metavar="PATH", dest="maestro_dir",
                   help="Explicit path to the .mso artefact directory (its parent "
                        "workspace root is also accepted and normalised), bypassing "
                        "workspace auto-detection (BUG-MSO-2026-0675 F1 — the "
                        "authoritative signal a headless caller, e.g. the Hub's LEAD "
                        "Run dispatcher.cleanup handler, hands this command "
                        "explicitly, since find_workspace() deliberately ignores "
                        "MAESTRO_DIR)")
    p.set_defaults(func=cmd_cleanup)

    # -- worktree -- (BUG-MSO-2026-0680: the manual escape hatch the
    # worktree.prune OBSERVE-only narrowing (BUG-MSO-2026-0644) assumed an
    # operator could reach by hand — it did not exist until this command)
    p = sub.add_parser("worktree", help="Manage crew/voyage worktrees directly",
                       formatter_class=argparse.RawDescriptionHelpFormatter,
                       epilog="""
actions:
  prune   Remove worktrees whose voyage has archived to voyages/complete/ —
          the same occupancy-guarded prune the dispatcher runs at startup
          and the LEAD's OBSERVE-only worktree.prune action only proposes
          (never executes unattended, per Captain ruling 2026-09-06)

examples:
  mso worktree prune
""")
    worktree_sub = p.add_subparsers(dest="worktree_action", metavar="<action>")
    worktree_sub.required = True
    wp = worktree_sub.add_parser("prune", help="Remove stale worktrees for archived voyages")
    wp.add_argument("--project", metavar="@PRJ", help="Registered project acronym (e.g. @ADM)")
    p.set_defaults(func=cmd_worktree)

    # -- status --
    p = sub.add_parser("status", help="Show fleet status dashboard")
    p.add_argument("--once", action="store_true", default=False,
                   help="One-shot display (no loop; default is live-updating)")
    p.add_argument("--compact", action="store_true",
                   help="One-line summary per crew")
    p.add_argument("--project", metavar="@PRJ",
                   help="Registered project acronym (e.g. @ADM)")
    p.set_defaults(func=cmd_status)

    # -- doctor --
    p = sub.add_parser(
        "doctor",
        help="Run deterministic fleet-health checks (no LLM, no dispatcher required)",
    )
    p.add_argument("--json", action="store_true", help="Machine-readable JSON output")
    p.add_argument("--all", action="store_true",
                   help="Show all current findings, including unchanged ones "
                        "(bypasses delta-only reporting)")
    p.add_argument("--explain", action="store_true",
                   help="Also print the resolved patrol definition (which tier "
                        "supplied each check, PLAN-PLN-MSO-2026-0504 §5.5) and the "
                        "resolved provider per kind (scm/ci/issues/deploy, §10)")
    p.add_argument("--project", metavar="@PRJ",
                   help="Registered project acronym (e.g. @ADM)")
    p.add_argument("--all-projects", action="store_true", dest="all_projects",
                   help="Scan every project registered in ~/.maestro/projects.json "
                        "(PLAN-PLN-MSO-2026-0504 §7) — one section per fleet plus one "
                        "machine-scope section, reported once regardless of fleet count")
    p.add_argument("--single-check", metavar="CHECK-ID", dest="single_check",
                   help="Run exactly one patrol check and print {verified, stillOpen, "
                        "reason} JSON, bypassing the full patrol run and never touching "
                        "patrol-state.json — used by the Hub's LEAD Run pre-flight "
                        "re-check as a killable subprocess (BUG-MSO-2026-0670 F1)")
    p.add_argument("--subject-id", metavar="ID", dest="subject_id", default="",
                   help="Subject id to check against (only meaningful with --single-check)")
    p.add_argument("--maestro-dir", metavar="PATH", dest="maestro_dir",
                   help="Explicit path to the .mso artefact directory (its parent "
                        "workspace root is also accepted and normalised), bypassing "
                        "workspace auto-detection (only meaningful with "
                        "--single-check; BUG-MSO-2026-0672 F1 — the authoritative "
                        "signal a headless caller, e.g. the Hub's pre-flight "
                        "subprocess, hands this one branch explicitly, since "
                        "find_workspace() deliberately ignores MAESTRO_DIR)")
    p.set_defaults(func=cmd_doctor)

    # -- usage --
    p = sub.add_parser("usage", help="Token usage and cost reporting")
    grp = p.add_mutually_exclusive_group()
    grp.add_argument("--summary", action="store_true",
                     help="Workspace-wide summary (also the default when no flag is given)")
    grp.add_argument("--voyage", metavar="VOY-ID",
                     help="Per-voyage breakdown")
    grp.add_argument("--order", metavar="ORDER-ID",
                     help="Per-order breakdown")
    grp.add_argument("--report", action="store_true",
                     help="Generate full markdown report")
    p.add_argument("--output", metavar="PATH",
                   help="Output path for --report")
    p.add_argument("--project", metavar="@PRJ",
                   help="Registered project acronym (e.g. @ADM). Also disambiguates "
                        "Claude Code transcript directories for auto-detected usage.")
    p.add_argument("--project-path", metavar="PATH",
                   help="Explicit Claude Code transcript directory, bypassing auto-detection")
    p.set_defaults(func=cmd_usage)

    # -- squad / crew --
    p = sub.add_parser("squad", aliases=["crew"], help="Operate a squad (aka crew)")
    p.add_argument("--crew", type=int, required=True, choices=range(1, 6),
                   metavar="{1-5}", help="Crew number")
    p.add_argument("--status", action="store_true", help="Show crew status")
    p.add_argument("--watch", action="store_true", help="Watch crew progress live")
    p.add_argument("--cleanup", action="store_true", help="Stop this crew's process")
    p.add_argument("--project", metavar="@PRJ",
                   help="Registered project acronym (e.g. @ADM)")
    p.set_defaults(func=cmd_crew)

    # -- verify --
    p = sub.add_parser("verify", help="Post-voyage build/test verification")
    p.add_argument("--voyage", metavar="VOY-ID",
                   help="Voyage ID to verify")
    p.add_argument("--skip-tests", action="store_true",
                   help="Reuse existing test results")
    p.add_argument("--project", metavar="@PRJ",
                   help="Registered project acronym (e.g. @ADM)")
    p.set_defaults(func=cmd_verify)

    # -- init --
    p = sub.add_parser("init", help="Scaffold a new Maestro workspace")
    p.add_argument("--project", metavar="ACRONYM", required=True,
                   help="Project acronym (e.g. OTM, PSG)")
    p.add_argument("--directory", metavar="PATH",
                   help="Workspace directory (default: current directory)")
    p.add_argument("--force", action="store_true",
                   help="Overwrite existing .mso/ if present")
    p.add_argument("--enterprise", action="store_true",
                   help="Enable enterprise mode — walks through anchor provider configuration")
    p.add_argument("--pack", metavar="NAME|PATH|URL",
                   help="Division pack to scaffold — a built-in id (e.g. sdlc, "
                        "test-engineering), a path to a custom pack directory "
                        "(ungated), or an https:// URL to a signed custom-pack "
                        "archive (Team/Enterprise — FTR-MSO-2026-0481). Omit for "
                        "the default SDLC workspace (== --pack sdlc).")
    p.add_argument(
        "--non-interactive", action="store_true", dest="non_interactive",
        help="Never prompt (e.g. --enterprise anchor provider) — fail rather than "
             "default to the filesystem anchor. Requires MAESTRO_ANCHOR_PROVIDER "
             "when combined with --enterprise (FTR-MSO-2026-0478 §3.5).",
    )
    p.set_defaults(func=cmd_init)

    # -- quickstart --
    p = sub.add_parser(
        "quickstart",
        help="Run the guided first-run experience",
        description="Verify environment, scaffold a workspace, and dispatch a demo voyage.",
    )
    p.add_argument("--project", default="DEMO", metavar="ACRONYM",
                   help="Project acronym for the demo workspace (default: DEMO)")
    p.add_argument("--no-demo", action="store_true",
                   help="Skip demo voyage; only verify environment and init workspace")
    p.add_argument("--crews", type=int, default=1, metavar="N",
                   help="Number of crews to dispatch (default: 1)")
    p.add_argument("--skip-checks", action="store_true",
                   help="Skip pre-flight checks (for CI use)")
    p.add_argument("--repo", metavar="ORG/NAME",
                   help="Link demo to a GitHub repo (mode B — explicit)")
    p.add_argument("--no-link-repo", action="store_true",
                   help="Run in local-only mode without linking a GitHub repo (mode C)")
    p.add_argument("--force", action="store_true",
                   help="Overwrite existing repo config in projects.json")
    p.set_defaults(func=cmd_quickstart)

    # -- demo --
    p = sub.add_parser(
        "demo",
        help="Dashboard PVT — simulated 6-order fleet with live dashboard",
        description=(
            "Run the Squad Monitor PVT: 6 demo orders (2x20s, 2x40s, 2x60s) "
            "across 3 simulated crews, rendered on the live dashboard, ending "
            "with a PVT report (plus a real security scan, backlog review, and "
            "activity summary) and full cleanup. No Claude invocations, no "
            "token spend. Refuses to run while a real fleet is active."
        ),
    )
    p.add_argument("--headless", action="store_true",
                   help="No live dashboard — run the simulation and print the report (CI/PVT mode)")
    p.add_argument("--fast", action="store_true",
                   help="Scale all timings to 10%% (full run in ~10s) for quick checks")
    p.add_argument("--keep", action="store_true",
                   help="Keep demo artefacts after the run (debugging; crew state is still restored)")
    p.add_argument("--project", metavar="@PRJ",
                   help="Project alias if not run from inside a workspace")
    p.set_defaults(func=cmd_demo)

    # -- setup --
    p = sub.add_parser(
        "setup",
        help="Prerequisite validation and interactive setup wizard",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
examples:
  mso setup                  Interactive wizard (default)
  mso setup --check          Non-interactive audit; exits non-zero on WARN/FAIL
  mso setup --repair         Auto-fix repairable issues
  mso setup --show prereqs   Read-only view of prerequisite status
  mso setup --show persona   Show active persona and resolution source
        """,
    )
    p.add_argument(
        "--check", action="store_true",
        help="Non-interactive: run checks and exit with code (0=OK, 1=FAIL, 2=WARN)",
    )
    p.add_argument(
        "--repair", action="store_true",
        help="Detect and automatically repair repairable issues",
    )
    p.add_argument(
        "--show", metavar="SECTION",
        choices=["prereqs", "project", "workspace", "templates", "persona"],
        help="Read-only inspection of one config section",
    )
    p.add_argument(
        "--json", action="store_true",
        help="JSON output (use with --check for CI parsing)",
    )
    p.add_argument(
        "--profile", metavar="PATH_OR_URL",
        help="Explicit enrolment profile (highest precedence — FTR-MSO-2026-0478 §3.3)",
    )
    p.add_argument(
        "--non-interactive", action="store_true", dest="non_interactive",
        help="Never prompt; fail with a named missing key instead of asking (unattended imaging)",
    )
    p.add_argument(
        "--answers", metavar="FILE",
        help="Flat KEY=VALUE answers file consumed in --non-interactive mode",
    )
    p.set_defaults(func=cmd_setup)

    # -- bridge --
    p = sub.add_parser("bridge", help="Manage the Mobile Command Bridge",
                       formatter_class=argparse.RawDescriptionHelpFormatter,
                       epilog="""
actions:
  setup         Interactive setup wizard — creates bridge-settings.json
  start         Start both poller and Slack bot
  stop          Stop both poller and Slack bot
  restart       Stop then start both poller and Slack bot
  status        Show bridge component status
  test          Send a test Slack notification
  poller-start  Start only the command poller
  poller-stop   Stop only the command poller
  bot-start     Start only the Slack bot
  bot-stop      Stop only the Slack bot

examples:
  mso bridge setup
  mso bridge start
  mso bridge restart
  mso bridge status
  mso bridge test --project ADM
        """)
    p.add_argument("bridge_action", metavar="<action>",
                   choices=["setup", "start", "stop", "restart", "status", "test",
                            "poller-start", "poller-stop",
                            "bot-start", "bot-stop"],
                   help="Bridge action to perform")
    p.add_argument("--project", metavar="ACRONYM",
                   help="Project acronym (required for 'test')")
    p.set_defaults(func=cmd_bridge)

    # -- hub --
    p = sub.add_parser("hub", help="Manage the Maestro Hub dashboard server (enterprise/team)",
                       formatter_class=argparse.RawDescriptionHelpFormatter,
                       epilog="""
actions:
  start    Start the hub HTTP server (default :3847)
  setup    Generate device-local Hub deployment config from your own registry
  stop     Stop the hub server
  status   Show hub running state + port

examples:
  mso hub start
  mso hub start --port 4000 --open
  mso hub status
  mso hub setup                          # local mode: validate registry, print start command
  mso hub setup --mode docker            # generate docker/ overlay + container registry
  mso hub setup --mode docker --dry-run  # preview both artefacts, write nothing
  mso hub setup --mode docker --force    # regenerate over existing files
""")
    p.add_argument("hub_action", metavar="<action>", choices=["start", "setup", "stop", "status"])
    p.add_argument("--port", type=int, default=3847, help="Port to bind (default 3847)")
    p.add_argument("--open", action="store_true", help="Open the dashboard in a browser")
    p.add_argument("--force", action="store_true",
                   help="start: launch even if a stale/recycled PID record claims 'already running'; "
                        "setup: overwrite existing generated files")
    p.add_argument("--mode", choices=["local", "docker"], default="local",
                   help="setup: 'local' (default) validates the registry and prints the start "
                        "command; 'docker' generates the compose overlay + container registry")
    p.add_argument("--output-dir", metavar="DIR",
                   help="setup --mode docker: where to write the generated files "
                        "(default: the repo docker/ dir, else MAESTRO_HOME/hub-docker/)")
    p.add_argument("--dry-run", action="store_true",
                   help="setup --mode docker: print both artefacts without writing them")
    p.set_defaults(func=cmd_hub)

    # -- lead -- (PLAN-PLN-MSO-2026-0504, FTR-MSO-2026-0536; Pro/Team/Enterprise)
    p = sub.add_parser("lead", help="Manage the resident LEAD sub-agent (Pro/Team/Enterprise)",
                       formatter_class=argparse.RawDescriptionHelpFormatter,
                       epilog="""
actions:
  start       Start the detached per-workspace LEAD daemon
  stop        Stop the LEAD daemon
  restart     Stop then start the LEAD daemon
  status      Show LEAD daemon running state + last tick
  run         Run one wake cycle in the foreground (requires --once)
  stand-down  Skip ticks until resumed (daemon process stays running; never tier-gated)
  resume      Resume a stood-down daemon
  ack         Acknowledge an open finding (--fingerprint, never tier-gated)
  unack       Clear an acknowledgement early (--fingerprint, never tier-gated)

examples:
  mso lead start
  mso lead status
  mso lead run --once
  mso lead stand-down
  mso lead resume
  mso lead ack --fingerprint 3f2a9c1e... --note "known, tracked in BUG-1234"
  mso lead unack --fingerprint 3f2a9c1e...
  mso lead stop
""")
    p.add_argument("lead_action", metavar="<action>",
                   choices=["start", "stop", "restart", "status", "run", "stand-down", "resume",
                            "ack", "unack"],
                   help="LEAD action to perform")
    p.add_argument("--project", metavar="ACRONYM", help="Registered project acronym")
    p.add_argument("--force", action="store_true",
                   help="start: launch even if a stale/recycled PID record claims 'already running'")
    p.add_argument("--once", action="store_true",
                   help="run: a single foreground wake cycle, no daemon spawned")
    p.add_argument("--fingerprint", metavar="FP",
                   help="ack/unack: the finding's stable fingerprint (see `mso lead status` "
                        "or `mso doctor --json`)")
    p.add_argument("--note", metavar="TEXT",
                   help="ack: optional free-text note (e.g. a tracking bug id)")
    p.add_argument("--by", metavar="NAME",
                   help="ack: who is acknowledging (default: the current OS user)")
    p.add_argument("--days", type=int, metavar="N",
                   help="ack: expiry in days (default: 7 — an ack always expires; "
                        "permanent suppression belongs in the patrol definition)")
    p.set_defaults(func=cmd_lead)

    # -- chart -- (FTR-MSO-2026-0496 show; FTR-MSO-2026-0519 new/validate —
    # PLAN-VOY-MSO-2026-0143 Phase 1 part 2 / PLAN-PLN-MSO-2026-0508 section 6)
    p = sub.add_parser("chart", help="Render (community) or author (pro+) a chart",
                       formatter_class=argparse.RawDescriptionHelpFormatter,
                       epilog="""
actions:
  show      Render a voyage's (or a single order's) compiled chart
  new       Compile a voyage's chart into a schema-v1 chart file (pro+)
  validate  Validate a chart file against schema v1 rules V1-V10

examples:
  mso chart show VOY-MSO-2026-0144
  mso chart show VOY-MSO-2026-0144 --format mermaid
  mso chart show FTR-MSO-2026-0496 --format json
  mso chart new --from-voyage VOY-MSO-2026-0144
  mso chart validate .mso/charts/CHT-MSO-2026-0001.json
  mso chart validate --all
""")
    p.add_argument("--project", metavar="ACRONYM", help="Registered project acronym")
    chart_sub = p.add_subparsers(dest="chart_action", metavar="<action>", required=True)

    cp = chart_sub.add_parser("show", help="Render a voyage or order chart (ASCII/mermaid/JSON)")
    cp.add_argument("target", metavar="VOY-ID|ORDER-ID",
                     help="A voyage id (e.g. VOY-MSO-2026-0144) or a single order id — "
                          "an order with no chart compiles to its own degenerate roleSequence chain")
    cp.add_argument("--format", choices=["ascii", "mermaid", "json"], default="ascii",
                     help="Output format (default: ascii)")
    cp.set_defaults(func=cmd_chart)

    cp = chart_sub.add_parser("new", help="Compile a voyage's chart into a schema-v1 chart file (pro+)")
    cp.add_argument("--from-voyage", metavar="VOY-ID", required=True, dest="from_voyage",
                     help="Voyage id to compile (e.g. VOY-MSO-2026-0144)")
    cp.add_argument("-o", "--output", metavar="PATH",
                     help="Output path (default: <artefact-root>/charts/<chartId>.json)")
    cp.set_defaults(func=cmd_chart)

    cp = chart_sub.add_parser("validate", help="Validate a chart file against schema v1 rules V1-V10")
    cp.add_argument("file", nargs="?", metavar="FILE", help="Chart JSON file to validate")
    cp.add_argument("--all", action="store_true", help="Validate every chart under charts/")
    cp.set_defaults(func=cmd_chart)

    # -- backup --
    p = sub.add_parser("backup", help="Create or list project state backups")
    p.add_argument("--project", metavar="ACRONYM",
                   help="Filter to a specific project acronym (default: all)")
    p.add_argument("--output", metavar="PATH",
                   help="Output directory (default: ./maestro-backups/)")
    p.add_argument("--list", action="store_true",
                   help="List available backups instead of creating one")
    p.set_defaults(func=cmd_backup)

    # -- restore --
    p = sub.add_parser("restore", help="Restore project state from a backup ZIP")
    p.add_argument("backup_file", metavar="BACKUP_FILE",
                   help="Path to the backup ZIP file")
    p.add_argument("--project", metavar="ACRONYM",
                   help="Restore only files for a specific project")
    p.add_argument("--force", action="store_true",
                   help="Overwrite existing files")
    p.add_argument("--merge", action="store_true",
                   help="Keep the newer file by modification time")
    p.add_argument("--dry-run", action="store_true",
                   help="Print what would be written without writing anything")
    p.set_defaults(func=cmd_restore)

    # -- sprint / voyage --
    p = sub.add_parser("sprint", aliases=["voyage"], help="Manage sprints (aka voyages)",
                       formatter_class=argparse.RawDescriptionHelpFormatter,
                       epilog="""
actions:
  create     Create a new sprint/voyage and git branch
  list       List active sprints/voyages
  status     Show sprint/voyage details
  reconcile  Archive voyages whose PR has been merged
  why        Explain why a voyage is not moving

examples:
  mso sprint create "Bridge v2 overhaul" --project ADM
  mso sprint list --project ADM
  mso sprint status VOY-ADM-2026-0001
  mso voyage reconcile [--dry-run] [--voyage VOY-ID]
  mso voyage why VOY-ADM-2026-0001 [--json]
  mso voyage create "Bridge v2 overhaul" --project ADM  (alias)
        """)
    voyage_sub = p.add_subparsers(dest="voyage_action", metavar="<action>")
    voyage_sub.required = True

    vp = voyage_sub.add_parser("create", help="Create a new voyage")
    vp.add_argument("title", nargs="+", help="Voyage title")
    vp.add_argument("--project", metavar="ACRONYM", required=True,
                    help="Project acronym (e.g. ADM, OTM)")
    # FTR-MSO-2026-0618 / PLAN-PLN-MSO-2026-0556 D4: voyage creation no longer
    # has a git side effect. ensure_voyage_branch_exists() creates the branch
    # on the REMOTE at first crew dispatch with no checkout, so switching the
    # operator's working tree here was redundant — and in the primary workspace
    # checkout it was the CONVERGENCE_PRIMARY_PROTECTED hazard. Deprecated,
    # retained only so anyone scripted against the old behaviour is not broken.
    vp.add_argument("--checkout", action="store_true",
                    help="DEPRECATED: also run 'git checkout -b' for the "
                         "voyage branch locally. Not required — the branch is "
                         "created on the remote at first dispatch.")

    vp = voyage_sub.add_parser("list", help="List active voyages")
    vp.add_argument("--project", metavar="ACRONYM",
                    help="Filter by project acronym")

    vp = voyage_sub.add_parser("status", help="Show voyage details")
    vp.add_argument("voyage_id", metavar="VOY-ID", help="Voyage ID")

    vp = voyage_sub.add_parser(
        "why", help="Explain why a voyage is not moving, and what to do about it")
    vp.add_argument("voyage_id", metavar="VOY-ID", help="Voyage ID")
    vp.add_argument("--json", action="store_true",
                    help="Emit the blockage record as JSON (the same wire shape "
                         "the Hub's /voyages/{id}/blockage endpoint serves)")

    vp = voyage_sub.add_parser("reconcile", help="Archive voyages whose PR has been merged")
    vp.add_argument("--dry-run", action="store_true", help="Show what would be archived without making changes")
    vp.add_argument("--json", action="store_true",
                    help="Emit the housekeeping report as JSON (what changed + what was refused)")
    vp.add_argument("--voyage", dest="voyage_id", metavar="VOY-ID", default=None,
                    help="Only reconcile this voyage ID")
    vp.add_argument("--repo", dest="repo", metavar="REPO-SLUG", default=None,
                    help="For a multi-repo voyage, only check this repo's PR "
                         "(a subset never triggers whole-voyage archival)")
    vp.add_argument("--maestro-dir", metavar="PATH", dest="maestro_dir",
                    help="Explicit path to the .mso artefact directory (its parent "
                         "workspace root is also accepted and normalised), bypassing "
                         "workspace auto-detection (BUG-MSO-2026-0675 F1 — same "
                         "treatment BUG-MSO-2026-0672 F1 gave cmd_doctor's "
                         "--single-check branch; used by the Hub's LEAD Run "
                         "voyage.reconcile handler)")

    p.set_defaults(func=cmd_voyage)

    # -- order --
    p = sub.add_parser("order", help="Manage orders (why / create / retry / skip / remove / unskip / list)",
                       formatter_class=argparse.RawDescriptionHelpFormatter,
                       epilog="""
actions:
  create  Create an order of any type (FTR / BUG / SEC / INV / PLN / DOC / ...)
  why     Explain why an order is stuck: the cause, the evidence that proves
          it, and the ordered options for unsticking it (--json for the wire
          shape). Exits 0 with a plain sentence when nothing is wrong.
  retry   Reopen an archived STALLED/FAILED order, or reset a stranded queued
          order (CONVERGENCE_FAILED / VERIFY_FAILED / BLOCKED / ...) to PENDING
          for re-dispatch (BUG-0297 / BUG-0344)
  skip    Add an order to the persistent skip list (survives dispatcher write cycles)
  remove  Remove an order from a voyage manifest and add it to the skip list
  unskip  Remove an order from the skip list
  list    Show all orders currently in the skip list

examples:
  mso order why BUG-MSO-2026-0141                  # why is this not moving, and what can I do?
  mso order why BUG-MSO-2026-0141 --json
  mso order create "Add CSV export" --type FTR --project MSO
  mso order create "Fix login crash" --type BUG --project MSO --priority CRITICAL
  mso order create "Chart the migration" --type PLN --project MSO --voyage VOY-MSO-2026-0163
  mso order retry BUG-MSO-2026-0141                # reopen a STALLED order (uses salvage fast path)
  mso order retry BUG-MSO-2026-0141 --role BLD --reason "timeout cap raised"
  mso order retry BUG-MSO-2026-0141 --salvage salvage/BUG-MSO-2026-0141-ca7cdb66
  mso order skip BUG-MSO-2026-0099 --reason "stale from prior voyage"
  mso order remove BUG-MSO-2026-0099 --from-voyage VOY-MSO-2026-0042
  mso order unskip BUG-MSO-2026-0099
  mso order list

retry clears the order's TERMINAL verdict and any lingering claim in the runtime
ledger (REOPENED event), moves an archived order back to queues/orders/ as
PENDING (a stranded queued order is reset in place), and defaults to
fast-converging the newest salvage/* branch so preserved work is not re-run.
A running dispatcher picks the reopened order up on its next scan tick.
Genuinely COMPLETE orders (and queued IN_PROGRESS orders) require --force.

BUG-MSO-2026-0615: before arming the salvage fast-path, the salvage branch is
checked against the CURRENT voyage tip (ancestry + content, not age). If
replaying it would revert commits the tip already has, the fast-path is
refused automatically (same as --no-salvage) and the printed note names how
many commits it predates and why. Use --force-salvage to arm it anyway.

create routes through maestro/core/order_create.py — the same implementation the
Slack bridge and the Maestro Hub call (FTR-MSO-2026-0620), so an order created
here is indistinguishable from one created there. Role codes are normalised to
the canonical set (PLN/BLD/TST/DOC/SEC/REL); legacy nautical aliases are
accepted as input. Omitting --role-sequence resolves the workspace's configured
sequence for that order type.

BUG-MSO-2026-0696: EVERY recorded salvage branch is listed with its role,
reason and diff-stat, and the armed one is marked. Where the default pick is
untrustworthy — candidates from two different roles, or an earlier branch that
contributes more than the newest — retry REFUSES rather than guessing, and
--salvage <branch> is how you answer it.

Skip list is persisted to .mso/config/skipped-orders.json and honoured by
scan_all_queues() (no re-dispatch, no WARN) and sweep_decks() (treated as satisfied).

DISPATCH ORDER (BUG-MSO-2026-0711) — how the next free crew slot is filled:
  1. priority "critical" overrides the queue tier: a critical order in ANY
     queue dispatches before every non-critical order in every other queue.
  2. Otherwise the queue directory decides (explicit > security > bugs >
     requests > orders > defects > breakdown > high-level).
  3. Within a tier, high > medium/normal > low.
Priority is matched case-insensitively; an absent or unrecognised value is
medium. `mso status`'s QUEUE block prints the next three orders in this exact
order with their queue, tier and priority. Set priority to critical to jump
the queue — moving the file into queues/explicit/ by hand is not required.
        """)
    order_sub = p.add_subparsers(dest="order_action", metavar="<action>")
    order_sub.required = True

    op = order_sub.add_parser("create", help="Create an order of any type (FTR-MSO-2026-0620)")
    op.add_argument("title", nargs="+", help="Order title")
    op.add_argument("--type", metavar="TYPE", required=True,
                    help="Order type prefix: FTR, BUG, SEC, INV, PLN, DOC, ... "
                         "(a division pack may define more)")
    op.add_argument("--project", metavar="ACRONYM", required=True,
                    help="Project acronym (e.g. MSO, PSG)")
    op.add_argument("--priority", choices=["CRITICAL", "HIGH", "MEDIUM", "LOW"],
                    default=None,
                    help="Priority (default: per type — HIGH for BUG/FIX/SEC/DEFECT, else MEDIUM)")
    op.add_argument("--description", metavar="TEXT", default="",
                    help="Longer body for the crew (the title alone is often enough)")
    op.add_argument("--role-sequence", dest="role_sequence", metavar="ROLES", default=None,
                    help="Comma-separated role chain, e.g. PLN,BLD,TST. Legacy nautical "
                         "codes (NAV/SHP/BOS/SCR/LKT/COX) are accepted and normalised. "
                         "Default: the workspace's configured sequence for this type.")
    op.add_argument("--target-role", dest="target_role", metavar="ROLE", default=None,
                    help="Role to start at (default: the first role of the sequence). "
                         "Must be a member of the sequence.")
    op.add_argument("--voyage", dest="voyage_id", metavar="VOY-ID", default="",
                    help="Voyage this order belongs to")
    op.add_argument("--voyage-branch", dest="voyage_branch", metavar="BRANCH", default="",
                    help="Voyage branch the crew must work on (default: set at dispatch)")
    op.add_argument("--target-repo", dest="target_repo", metavar="REPO", default="",
                    help="Target repo name in a multi-repo workspace")
    op.add_argument("--depends-on", dest="depends_on", metavar="IDS", default=None,
                    help="Comma-separated order IDs this order depends on")
    op.add_argument("--queue", metavar="QUEUE", default="orders",
                    help="Queue directory to create into (default: orders)")
    # FTR-MSO-2026-0621 / PLAN Order 5. Added in the same commit as the Hub's
    # create endpoint so the Hub cannot do something the CLI cannot: the
    # drawer's Lane control files a real BACKLOG status, and there must be a
    # CLI verb for it. Constrained to order_create.CREATABLE_STATUSES.
    op.add_argument("--status", choices=["PENDING", "BACKLOG", "PROPOSED"],
                    default=None,
                    help="Status to create at (default: PENDING). BACKLOG "
                         "parks the order; PROPOSED waits on its dependencies "
                         "and therefore REQUIRES --depends-on (BUG-MSO-2026-0741: "
                         "nothing releases a dependency-free PROPOSED order).")

    op = order_sub.add_parser("retry", help="Reopen an archived or stranded-queued order (BUG-0297/BUG-0344)")
    op.add_argument("order_id", metavar="ORDER-ID", help="Order ID to reopen")
    op.add_argument("--role", metavar="ROLE", default=None,
                    help="Role to retry at (default: the role it stalled in)")
    op.add_argument("--reason", metavar="TEXT", default="", help="Why the order is being retried")
    op.add_argument("--force", action="store_true",
                    help="Required to retry an order archived as COMPLETE or queued IN_PROGRESS")
    # BUG-MSO-2026-0696: a REAL mutually-exclusive group, not just a claim in
    # the help text. Accepting both and silently letting --no-salvage win would
    # discard the branch the operator explicitly named — the same
    # silently-did-something-else failure this whole order exists to remove.
    _salv_grp = op.add_mutually_exclusive_group()
    _salv_grp.add_argument("--no-salvage", action="store_true", dest="no_salvage",
                    help="Re-run the role from scratch instead of fast-converging the newest salvage branch")
    _salv_grp.add_argument("--salvage", metavar="BRANCH", default=None,
                    help="Arm THIS salvage branch explicitly (BUG-MSO-2026-0696). Required when "
                         "the recorded candidates are ambiguous — two roles, or an earlier branch "
                         "bigger than the newest. Mutually exclusive with --no-salvage.")
    op.add_argument("--force-salvage", action="store_true", dest="force_salvage",
                    help="Arm the salvage fast-path even if it is detected as stale (BUG-MSO-2026-0615) "
                         "— i.e. would revert commits already on the voyage branch")

    op = order_sub.add_parser("skip", help="Add an order to the skip list")
    op.add_argument("order_id", metavar="ORDER-ID", help="Order ID to skip")
    op.add_argument("--reason", metavar="TEXT", default="", help="Optional reason for skipping")

    op = order_sub.add_parser("remove", help="Remove an order from a voyage manifest and skip list")
    op.add_argument("order_id", metavar="ORDER-ID", help="Order ID to remove")
    op.add_argument("--from-voyage", dest="voyage_id", metavar="VOY-ID", required=True,
                    help="Voyage ID whose manifest to strip the order from")

    op = order_sub.add_parser("unskip", help="Remove an order from the skip list")
    op.add_argument("order_id", metavar="ORDER-ID", help="Order ID to unskip")

    op = order_sub.add_parser(
        "why", help="Explain why an order is stuck, and what to do about it")
    op.add_argument("order_id", metavar="ORDER-ID", help="Order ID to diagnose")
    op.add_argument("--json", action="store_true",
                    help="Emit the blockage record as JSON (the same wire shape "
                         "the Hub's /orders/{id}/blockage endpoint serves)")

    order_sub.add_parser("list", help="Show all skipped orders")

    p.set_defaults(func=cmd_order)

    # -- bug --
    p = sub.add_parser("bug", help="Create a BUG order",
                       formatter_class=argparse.RawDescriptionHelpFormatter,
                       epilog="""
examples:
  mso bug "Login page crashes on mobile" --project ADM
        """)
    p.add_argument("title", nargs="+", help="Bug title")
    p.add_argument("--project", metavar="ACRONYM", required=True,
                   help="Project acronym (e.g. ADM, OTM)")
    p.add_argument("--priority", choices=["CRITICAL", "HIGH", "MEDIUM", "LOW"],
                   default="HIGH",
                   help="Priority (default: HIGH). CRITICAL overrides the queue tier and "
                        "dispatches ahead of every non-critical order in every queue; below "
                        "that the queue directory decides first, then priority within it. "
                        "See `mso order --help`.")
    p.set_defaults(func=cmd_bug)

    # -- security --
    p = sub.add_parser("security", help="Run OWASP/CWE security scanner",
                       formatter_class=argparse.RawDescriptionHelpFormatter,
                       epilog="""
subcommands:
  scan      Run the OWASP/CWE static analysis scanner
  review    Run a full security review and write a unified report

examples:
  mso security scan --order FTR-ADM-2026-0046
  mso security scan --voyage VOY-ADM-2026-0024
  mso security scan --since 2026-04-01
  mso security scan --json
  mso security scan --severity-threshold HIGH
  mso security review
  mso security review --against origin/main --json
  mso security review --staged
        """)
    security_sub = p.add_subparsers(dest="security_action", metavar="<subcommand>")
    security_sub.required = True

    sp = security_sub.add_parser("scan", help="Scan files for OWASP/CWE vulnerabilities")
    sp.add_argument("--order", metavar="ORDER-ID",
                    help="Tag the resulting SEC-*.json report with this order ID. "
                         "Note: scans all crew-tracked modified files (per-order file tagging is not yet implemented).")
    sp.add_argument("--voyage", metavar="VOY-ID",
                    help="Tag the resulting report with this voyage ID. "
                         "Same caveat as --order — scans all crew-tracked modified files.")
    sp.add_argument("--since", metavar="DATE",
                    help="Scan files modified since this date (ISO format: YYYY-MM-DD)")
    sp.add_argument("--severity-threshold", metavar="LEVEL", default="INFO",
                    choices=["INFO", "LOW", "MEDIUM", "HIGH", "CRITICAL"],
                    help="Minimum severity to report (default: INFO)")
    sp.add_argument("--json", action="store_true",
                    help="Output results as JSON")
    sp.add_argument("--project", metavar="ACRONYM",
                    help="Workspace project acronym for registry lookup")

    rp = security_sub.add_parser("review", help="Run a full security review and write a unified REVIEW-*.md report")
    rp.add_argument("--against", metavar="REF", default="origin/main",
                    help="Diff base ref (default: origin/main). Ignored when --staged is set.")
    rp.add_argument("--staged", action="store_true",
                    help="Review staged changes (git diff --staged) instead of branch diff")
    rp.add_argument("--severity-threshold", metavar="LEVEL", default="MEDIUM",
                    choices=["INFO", "LOW", "MEDIUM", "HIGH", "CRITICAL"],
                    help="Minimum severity to include in report (default: MEDIUM)")
    rp.add_argument("--json", action="store_true",
                    help="Output report summary as JSON")
    rp.add_argument("--project", metavar="ACRONYM",
                    help="Workspace project acronym for registry lookup")
    rp.set_defaults(func=cmd_security_review)

    p.set_defaults(func=cmd_security)

    # -- projects --
    p = sub.add_parser("projects", help="List or manage registered projects",
                       formatter_class=argparse.RawDescriptionHelpFormatter,
                       epilog="""
actions:
  list    Show all registered projects with paths
  remove  Unregister a project by acronym

examples:
  mso projects list
  mso projects remove PSG
        """)
    projects_sub = p.add_subparsers(dest="projects_action", metavar="<action>")
    projects_sub.required = True

    pp = projects_sub.add_parser("list", help="Show all registered projects")

    pp = projects_sub.add_parser("remove", help="Unregister a project")
    pp.add_argument("acronym", metavar="ACRONYM", help="Project acronym to remove (e.g. PSG)")

    p.set_defaults(func=cmd_projects)

    # -- update --
    p = sub.add_parser("update", help="Propagate schema updates to an existing workspace")
    p.add_argument("--dry-run", action="store_true",
                   help="Show changes without applying them")
    p.add_argument("--force", action="store_true",
                   help="Overwrite files that would otherwise be skipped")
    p.add_argument("--directory", metavar="PATH",
                   help="Workspace directory (default: current directory)")
    p.set_defaults(func=cmd_update)

    # -- migrate --
    p = sub.add_parser("migrate", help="Migrate a workspace's artefact layout",
                       formatter_class=argparse.RawDescriptionHelpFormatter,
                       epilog="""
actions:
  artefact-repo   Move the durable artefact plane into a dedicated artefact repo
                  (solo mode): copy-fresh, mandatory backup + pre-flight cleanup
                  gate, manifest hash-diff verify, registry v2 + workspace.json.
  import-workspace  Amalgamate an existing workspace into a target's artefact repo,
                  renaming imported IDs with a sub-acronym prefix
                  (<SOURCE>-* → <TARGET>-<SUB>-*) and rewriting all cross-references.

examples:
  mso migrate artefact-repo --dry-run
  mso migrate artefact-repo --project MSO --dry-run   # multi-project: pick the acronym explicitly
  mso migrate artefact-repo --dest C:/Repos/MSO-Platform
  mso migrate artefact-repo --name GKT-Platform --remote git@github.com:org/GKT-Platform.git
  mso migrate artefact-repo --clean-product
  mso migrate artefact-repo --rollback --dest C:/Repos/MSO-Platform
  mso migrate import-workspace C:/Repos/GKT-Portal --into C:/Repos/GKT-Platform --sub-acronym POR --dry-run
  mso migrate import-workspace C:/Repos/GKT-Web --into C:/Repos/GKT-Platform --sub-acronym WEB
""")
    migrate_sub = p.add_subparsers(dest="migrate_action", metavar="<action>")
    iw = migrate_sub.add_parser(
        "import-workspace",
        help="Amalgamate a workspace into a target's artefact repo (ID renaming)")
    iw.add_argument("source", metavar="SOURCE",
                    help="Source workspace root (dir containing .mso/) to import")
    iw.add_argument("--into", metavar="TARGET", required=True,
                    help="Target artefact repo / workspace root (dir containing .mso/)")
    iw.add_argument("--sub-acronym", metavar="SUB", required=True,
                    help="Sub-acronym for the imported namespace (e.g. POR, WEB); "
                         "imported IDs become <TARGET>-<SUB>-*")
    iw.add_argument("--target-acronym", metavar="ACR",
                    help="Override the target acronym (default: resolved from the "
                         "target workspace.json / dir name)")
    iw.add_argument("--dry-run", action="store_true",
                    help="Print the action table + full rename map without mutating anything")
    mp = migrate_sub.add_parser("artefact-repo",
                                help="Migrate durable plane into a dedicated artefact repo")
    mp.add_argument("--dest", metavar="PATH",
                    help="Destination artefact repo directory "
                         "(default: sibling <ACRONYM>-Platform)")
    mp.add_argument("--name", metavar="NAME",
                    help="Artefact repo name (default: <ACRONYM>-Platform)")
    mp.add_argument("--remote", metavar="URL",
                    help="Optional git remote to wire as origin on the artefact repo")
    mp.add_argument("--clean-product", action="store_true",
                    help="After cutover, git rm --cached .mso from the product repo "
                         "and add a sweep commit (keeps files on disk)")
    mp.add_argument("--dry-run", action="store_true",
                    help="Print the action table without mutating anything")
    mp.add_argument("--rollback", action="store_true",
                    help="Undo a migration: delete --dest repo + revert registry to embedded")
    mp.add_argument("--project", metavar="ACR",
                    help="Project acronym for this migration (names <ACR>-Platform "
                         "and the registry entry). Overrides MAESTRO_PROJECT and "
                         "projects.json defaultProject. Also used to locate the "
                         "workspace when run outside one.")
    p.set_defaults(func=cmd_migrate)

    # -- hooks --
    p = sub.add_parser("hooks", help="Install or uninstall global Maestro hooks",
                       formatter_class=argparse.RawDescriptionHelpFormatter,
                       epilog="""
actions:
  install    Write hook entries to ~/.claude/settings.json (idempotent)
  uninstall  Remove Maestro hook entries from ~/.claude/settings.json

examples:
  mso hooks install
  mso hooks uninstall
        """)
    p.add_argument("hooks_action", metavar="<action>", choices=["install", "uninstall"],
                   help="Action to perform")
    p.set_defaults(func=cmd_hooks)

    # -- mcp --
    p = sub.add_parser("mcp", help="Manage the MCP server registry",
                       formatter_class=argparse.RawDescriptionHelpFormatter,
                       epilog="""
actions:
  list      List all registered servers with risk level and allowed roles
  show      Pretty-print full entry for one server
  add       Add a server entry (interactive flags or --json <file>)
  remove    Remove a server from the registry
  validate  Validate registry against JSON Schema and check env vars

examples:
  mso mcp list
  mso mcp show filesystem
  mso mcp add --name filesystem --command npx --allowed-roles "*" --risk-level low
  mso mcp add --name github --command npx --allowed-roles COX,QM --risk-level high --env-required GITHUB_TOKEN --description "GitHub API" --notes "COX/QM only"
  mso mcp add --json my-server.json
  mso mcp remove github
  mso mcp validate
    """)
    mcp_sub = p.add_subparsers(dest="mcp_action", metavar="<action>")
    mcp_sub.required = True

    mp = mcp_sub.add_parser("list", help="List all registered servers")
    mp.add_argument("--project", metavar="@PRJ", help="Registered project acronym")

    mp = mcp_sub.add_parser("show", help="Show full entry for one server")
    mp.add_argument("name", metavar="NAME", help="Server name")
    mp.add_argument("--project", metavar="@PRJ", help="Registered project acronym")

    mp = mcp_sub.add_parser("add", help="Add a server to the registry")
    mp.add_argument("--name", help="Server name (must match .claude/settings.json key)")
    mp.add_argument("--command", help="Executable name or full command")
    mp.add_argument("--args", action="append", metavar="ARG", help="CLI arg (repeatable)")
    mp.add_argument("--allowed-roles", metavar="ROLES", help="Comma-separated role codes or '*'")
    mp.add_argument("--risk-level", choices=["low", "medium", "high", "critical"],
                    help="Risk level (default: medium)")
    mp.add_argument("--env-required", action="append", metavar="VAR",
                    help="Required env var name (repeatable)")
    mp.add_argument("--description", help="Human-readable purpose")
    mp.add_argument("--notes", help="Operator notes or audit trail")
    mp.add_argument("--json", metavar="FILE", help="Import entry from a JSON file")
    mp.add_argument("--project", metavar="@PRJ", help="Registered project acronym")

    mp = mcp_sub.add_parser("remove", help="Remove a server from the registry")
    mp.add_argument("name", metavar="NAME", help="Server name to remove")
    mp.add_argument("--project", metavar="@PRJ", help="Registered project acronym")

    mp = mcp_sub.add_parser("validate", help="Validate registry and check env vars")
    mp.add_argument("--project", metavar="@PRJ", help="Registered project acronym")

    p.set_defaults(func=cmd_mcp)

    # -- identity --
    p = sub.add_parser("identity", help="Manage enterprise identity, groups, and ACL",
                       formatter_class=argparse.RawDescriptionHelpFormatter,
                       epilog="""
actions:
  init                     Seed .mso/identity/ with default groups and access.json
  add-user                 Enrol a new user
  add-group                Create a new group
  set-group                Add a user to a group
  remove-user              Remove a user from the identity store
  sign-acl                 Sign the integrity manifest (governed enforce mode)
  show                     Show effective capabilities for a user
  rights export EMAIL      Article 15 — export all data for a subject
  rights forget EMAIL      Article 17 — erasure dry-run plan (add --execute to apply)
  rights restrict EMAIL    Article 18 — restrict processing for a subject
  rights export-classification  Dump data-classification CSV for compliance audit
  acl list                 List ACL entries
  acl set                  Add an ACL entry
  acl remove               Remove an ACL entry

examples:
  mso identity init
  mso identity init --encryption git-crypt
  mso identity add-user --email alice@acme.com --display-name "Alice" --group captains
  mso identity add-group --name auditors
  mso identity set-group --email alice@acme.com --group fleet_operators
  mso identity sign-acl --key-id acme-2026-q3 --key-file ~/keys/org-seed.b64
  mso identity show --email alice@acme.com
  mso identity rights export alice@acme.com
  mso identity rights forget alice@acme.com --dry-run
  mso identity rights restrict alice@acme.com
  mso identity acl list
  mso identity acl set --principal group:contributors --capability voyage.create --scope "*"
  mso identity acl remove --principal group:contributors --capability voyage.create --scope "*"
        """)
    p.add_argument("--project", metavar="@PRJ", help="Registered project acronym")
    id_sub = p.add_subparsers(dest="identity_action", metavar="<action>")
    id_sub.required = True

    ip = id_sub.add_parser("init", help="Seed identity store with defaults")
    ip.add_argument(
        "--encryption",
        choices=["git-crypt", "sops", "none"],
        default="none",
        help="Optional at-rest encryption for identity files (default: none)",
    )

    ip = id_sub.add_parser("rights", help="GDPR data-subject-rights tooling")
    rights_sub = ip.add_subparsers(dest="rights_action", metavar="<action>")
    rights_sub.required = True

    rp = rights_sub.add_parser("export", help="Article 15 — export all data for a subject")
    rp.add_argument("email", metavar="EMAIL", help="Data subject email address")

    rp = rights_sub.add_parser("forget", help="Article 17 — erasure plan (dry-run by default)")
    rp.add_argument("email", metavar="EMAIL", help="Data subject email address")
    rp.add_argument("--execute", action="store_true",
                    help="Execute identity-layer deletions (git history rewrite is still manual)")

    rp = rights_sub.add_parser("restrict", help="Article 18 — restrict processing for a subject")
    rp.add_argument("email", metavar="EMAIL", help="Data subject email address")

    rp = rights_sub.add_parser("export-classification", help="Export data-classification CSV for all user records")

    ip = id_sub.add_parser("add-user", help="Enrol a new user")
    ip.add_argument("--email", required=True, help="User email address")
    ip.add_argument("--display-name", required=True, dest="display_name", help="Display name")
    ip.add_argument("--group", action="append", metavar="GROUP", help="Group to add user to (repeatable)")
    ip.add_argument("--public-key", dest="public_key", metavar="PATH", help="Path to SSH Ed25519 public key file")

    ip = id_sub.add_parser("add-group", help="Create a new group")
    ip.add_argument("--name", required=True, help="Group name")

    ip = id_sub.add_parser("set-group", help="Add a user to a group")
    ip.add_argument("--email", required=True, help="User email address")
    ip.add_argument("--group", required=True, help="Group name")

    ip = id_sub.add_parser("remove-user", help="Remove a user")
    ip.add_argument("--email", required=True, help="User email address")

    ip = id_sub.add_parser(
        "sign-acl",
        help="Sign the identity integrity manifest with the org Ed25519 key "
             "(required after ACL edits in governed enforce mode)",
    )
    ip.add_argument("--key-id", required=True, dest="key_id",
                    help="Signing key id (must match the out-of-workspace pinned public key)")
    ip.add_argument("--key-file", dest="key_file", metavar="PATH",
                    help="Path to the org Ed25519 seed (base64/hex, 32 bytes). "
                         "Defaults to the MAESTRO_IDENTITY_SIGNING_KEY env var.")

    ip = id_sub.add_parser("show", help="Show effective capabilities for a user")
    ip.add_argument("--email", help="User email (default: current caller)")

    ip = id_sub.add_parser("acl", help="Manage ACL entries")
    acl_sub = ip.add_subparsers(dest="acl_action", metavar="<action>")
    acl_sub.required = True

    ap = acl_sub.add_parser("list", help="List ACL entries")
    ap.add_argument("--principal", help="Filter by principal (e.g. group:captains)")

    ap = acl_sub.add_parser("set", help="Add an ACL entry")
    ap.add_argument("--principal", required=True, help="Principal (user:<email> or group:<name>)")
    ap.add_argument("--capability", required=True, help="Capability name")
    ap.add_argument("--scope", required=True, help="Scope (* | project:<acronym> | voyage:<id> | role:<code>)")

    ap = acl_sub.add_parser("remove", help="Remove an ACL entry")
    ap.add_argument("--principal", required=True, help="Principal")
    ap.add_argument("--capability", required=True, help="Capability name")
    ap.add_argument("--scope", required=True, help="Scope")

    ap = acl_sub.add_parser("show", help="Show the full effective ACL (alias for list)")
    ap.add_argument("--principal", help="Filter by principal (e.g. group:captains)")

    # -- identity user --
    ip = id_sub.add_parser("user", help="User management (add / remove / list)")
    user_sub = ip.add_subparsers(dest="user_action", metavar="<action>")
    user_sub.required = True

    up = user_sub.add_parser("add", help="Enrol a new user")
    up.add_argument("email", help="User email address")
    up.add_argument("--display-name", required=True, dest="display_name", help="Display name")
    up.add_argument("--public-key", dest="public_key", metavar="PATH", help="Path to SSH Ed25519 public key file")

    up = user_sub.add_parser("remove", help="Remove a user")
    up.add_argument("email", help="User email address")

    up = user_sub.add_parser("list", help="List all enrolled users")

    # -- identity group --
    ip = id_sub.add_parser("group", help="Group management (add / remove / list)")
    group_sub = ip.add_subparsers(dest="group_action", metavar="<action>")
    group_sub.required = True

    gp = group_sub.add_parser("add", help="Create a new group")
    gp.add_argument("name", help="Group name")
    gp.add_argument("--capabilities", metavar="CAP1,CAP2", help="Comma-separated capabilities to grant")
    gp.add_argument("--scope", default="*", help="Scope for the capability grants (default: *)")

    gp = group_sub.add_parser("remove", help="Remove a group and its ACL entries")
    gp.add_argument("name", help="Group name")

    gp = group_sub.add_parser("list", help="List all groups")

    # -- identity assign --
    ip = id_sub.add_parser("assign", help="Assign a user to a group")
    ip.add_argument("email", help="User email address")
    ip.add_argument("--to-group", required=True, dest="to_group", help="Target group name")

    p.set_defaults(func=cmd_identity)

    # -- audit --
    p = sub.add_parser("audit", help="Audit log operations",
                       formatter_class=argparse.RawDescriptionHelpFormatter,
                       epilog="""
actions:
  tail      Live-tail the audit log (default: last 20 lines then follow)
  verify    Walk the hash chain and return non-zero on tamper detection
  export    Dump entries to stdout in json, jsonl, or csv format
  anchor    Write current root hash to external immutable storage (enterprise only)

examples:
  mso audit tail
  mso audit tail --lines 50 --no-follow
  mso audit verify
  mso audit export --format csv --since 2026-01-01
  mso audit anchor --provider fs
  mso audit anchor --provider s3 --config /etc/mso/anchor-s3.json

scheduled anchoring (systemd):
  ExecStart=mso audit anchor --provider s3 --config /etc/mso/anchor-s3.json
  (add to a .timer unit — see maestro docs anchor)
        """)
    p.add_argument("--project", metavar="@PRJ", help="Registered project acronym")
    audit_sub = p.add_subparsers(dest="audit_action", metavar="<action>")
    audit_sub.required = True

    ap = audit_sub.add_parser("tail", help="Live-tail the audit log")
    ap.add_argument("--lines", "-n", type=int, default=20, help="Lines to show before following (default: 20)")
    ap.add_argument("--no-follow", action="store_true", dest="no_follow", help="Print tail and exit (no follow)")

    ap = audit_sub.add_parser("verify", help="Verify the hash chain")

    ap = audit_sub.add_parser("export", help="Export audit entries")
    ap.add_argument("--since", metavar="DATE", help="Start date (ISO: YYYY-MM-DD)")
    ap.add_argument("--format", choices=["json", "jsonl", "csv"], default="jsonl",
                    help="Output format (default: jsonl)")

    ap = audit_sub.add_parser("anchor", help="Anchor current root hash to external immutable storage")
    ap.add_argument(
        "--provider", "-p",
        choices=["s3", "azure", "s3-compat", "fs"],
        default="fs",
        help="Anchor provider (default: fs — filesystem, dev/test only)",
    )
    ap.add_argument(
        "--config", metavar="FILE",
        help="JSON config file for provider (alternative to env vars)",
    )
    ap.add_argument(
        "--auto", action="store_true",
        help="Read provider and config from workspace.json audit settings (for cron/Task Scheduler use)",
    )

    p.set_defaults(func=cmd_audit)

    # -- data-flow --
    p = sub.add_parser("data-flow", help="Generate egress data-flow diagram (Mermaid or Graphviz)",
                       formatter_class=argparse.RawDescriptionHelpFormatter,
                       epilog="""
Generate a diagram of all outbound HTTP destinations this workspace calls.

Enterprise workspaces with dataResidency.allowedDestinations configured will
show only the allowlisted hosts.  Solo (permissive) workspaces show all
known static destinations (GitHub API, Slack, etc.).

workspace.json enterprise egress config example:
  {
    "enterprise": true,
    "dataResidency": {
      "mode": "restrictive",
      "allowedDestinations": ["api.github.com", "slack.com", "*.azure.com"]
    }
  }

examples:
  mso data-flow
  mso data-flow --format graphviz
  mso data-flow --output egress.md
  mso data-flow --project @ADM --output docs/data-flow.mmd
    """)
    p.add_argument("--format", choices=["mermaid", "graphviz"], default="mermaid",
                   help="Diagram format (default: mermaid)")
    p.add_argument("--mode", choices=["permissive", "restrictive", "air-gapped"],
                   metavar="MODE",
                   help="Override egress mode for rendering: permissive, restrictive, air-gapped")
    p.add_argument("--output", metavar="PATH",
                   help="Write diagram to this file (default: stdout)")
    p.add_argument("--project", metavar="@PRJ",
                   help="Registered project acronym (e.g. @ADM)")
    p.set_defaults(func=cmd_data_flow)

    # -- secrets --
    p = sub.add_parser("secrets", help="Secrets operator tooling",
                       formatter_class=argparse.RawDescriptionHelpFormatter,
                       epilog="""
actions:
  doctor  Verify every secret:// reference in workspace config resolves cleanly
  rotate  Kick a rotation workflow for a named key
  scrub   Scan config and logs for likely cleartext secrets
  list    List keys (never values) exposed by the active provider

exit codes:
  0  clean / success
  1  at least one finding or failure
  2  config error / missing argument

examples:
  mso secrets doctor
  mso secrets rotate --key MY_API_KEY
  mso secrets scrub
  mso secrets list
    """)
    secrets_sub = p.add_subparsers(dest="secrets_action", metavar="<action>")
    secrets_sub.required = True

    sp = secrets_sub.add_parser("doctor", help="Verify all secret:// refs resolve")
    sp.add_argument("--project", metavar="@PRJ", help="Registered project acronym")
    sp.set_defaults(func=cmd_secrets)

    sp = secrets_sub.add_parser("rotate", help="Kick rotation workflow for a key")
    sp.add_argument("--key", metavar="KEY", help="Secret key to rotate")
    sp.add_argument("--project", metavar="@PRJ", help="Registered project acronym")
    sp.set_defaults(func=cmd_secrets)

    sp = secrets_sub.add_parser("scrub", help="Scan for cleartext secrets in config and logs")
    sp.add_argument("--project", metavar="@PRJ", help="Registered project acronym")
    sp.set_defaults(func=cmd_secrets)

    sp = secrets_sub.add_parser("list", help="List secret keys (never values)")
    sp.add_argument("--project", metavar="@PRJ", help="Registered project acronym")
    sp.set_defaults(func=cmd_secrets)

    # -- licence --
    p = sub.add_parser(
        "licence",
        aliases=["license"],
        help="Manage your Maestro licence (activate / status / deactivate)",
    )
    licence_sub = p.add_subparsers(dest="licence_cmd", metavar="<licence-cmd>", required=True)

    lp = licence_sub.add_parser("activate", help="Activate a licence key or MSO1. token")
    lp.add_argument("key", nargs="?", help="Licence key or MSO1. token (or set MAESTRO_LICENCE_KEY)")

    lp = licence_sub.add_parser("status", help="Show the locally-cached licence state")
    lp.add_argument("--json", action="store_true", help="Emit JSON instead of human text")

    lp = licence_sub.add_parser("deactivate", help="Drop the local licence record + keychain entry")

    lp = licence_sub.add_parser("revalidate", help="Force an online re-check now (ignore the 24h fast path)")
    lp.add_argument(
        "--offline-mark-stale",
        action="store_true",
        help=(
            "TEST ONLY: rewind last_validated_at to >24h ago so the next "
            "`mso` run exercises the offline-grace path. Refuses to run "
            "unless MAESTRO_LICENCE_TEST_FLAGS=1 is set in the operator "
            "shell. Used for FTR-0123 step 7 of the live-test plan."
        ),
    )

    # -- admin-only issuer tooling (FTR-MSO-2026-0453) --
    # For a Maestro Admin (someone with access to Maestro's private source)
    # only. Ordinary customers never run these — they receive a token by
    # email and run `mso licence activate <TOKEN>`.
    lp = licence_sub.add_parser(
        "keygen",
        help="[ADMIN] Generate a new Ed25519 licence-signing keypair (private "
             "half written off-repo; public half printed for the vendor keyring)",
    )
    lp.add_argument(
        "--out", required=True, metavar="PATH",
        help="Where to write the signing SEED. Refused if the path is inside "
             "a git working tree or a .mso/ workspace — generate it somewhere "
             "safe (password manager, offline store), never inside a clone "
             "of this repo.",
    )

    lp = licence_sub.add_parser(
        "issue",
        help="[ADMIN] Mint a signed licence token for a customer "
             "(pro / team / enterprise — community requires no licence)",
    )
    lp.add_argument("--tier", required=True, choices=["pro", "team", "enterprise"],
                     help="Licence tier. 'community' is refused — it requires no licence at all.")
    lp.add_argument("--licensee", required=True, metavar="NAME", help="Licensee / organisation name")
    lp.add_argument("--contact", required=True, metavar="EMAIL", help="Licensee contact email")
    lp.add_argument("--key-id", required=True, metavar="KEY-ID",
                     help="keyId this token is signed under — must match an entry "
                          "the vendor keyring will ship (maestro/licence/keys/licence-keys.json)")
    lp.add_argument("--key-file", metavar="PATH",
                     help="Path to the signing seed. Falls back to MAESTRO_LICENCE_SIGNING_KEY.")
    lp.add_argument("--seats", type=int, default=1, help="Seat count (recorded, not enforced). Default: 1.")
    lp.add_argument("--entitlements", metavar="a,b,c",
                     help="Comma-separated entitlement list. Defaults to a sane "
                          "per-tier set when omitted.")
    lp.add_argument("--expires", metavar="ISO-DATE",
                     help="Explicit expiry (ISO-8601). Overrides --term-days when given.")
    lp.add_argument("--term-days", type=int, default=365,
                     help="Term length in days from --not-before (or now). Default: 365.")
    lp.add_argument("--not-before", metavar="ISO-DATE",
                     help="Explicit notBefore (ISO-8601). Default: now — lets a renewal "
                          "be mailed ahead of expiry and activate with no gap.")
    lp.add_argument("--licence-id", metavar="ID", help="Override the auto-generated licenceId.")
    lp.add_argument("--register", required=True, metavar="PATH",
                     help="Append-only JSONL issuance register to record this issuance in "
                          "(§11.3) — point this at the private Maestro-Admin artefact store, "
                          "never the public repo or the wheel.")

    p.set_defaults(func=cmd_licence)

    # -- config -- (FTR-ADM-2026-0129)
    p = sub.add_parser("config", help="Inspect Maestro configuration (FTR-0129)")
    config_sub = p.add_subparsers(dest="config_action", required=True)

    cm = config_sub.add_parser(
        "models",
        help="Show the model assigned to each role (with override source)",
    )
    cm.set_defaults(func=cmd_config_models)

    # -- review --
    p = sub.add_parser(
        "review",
        help="Human review queue for gate-paused orders",
        description=(
            "Manage orders paused at a human review gate. A gate may sit on any\n"
            "role transition — configure them under `transitions` in\n"
            # BUG-MSO-2026-0439 / FTR-MSO-2026-0362: build the workspace-dir literal
            # from MSO_DIR_NAME rather than hardcoding ".mso" (the audit's policy for
            # unavoidable literals in prompt/help text).
            f"{MSO_DIR_NAME}/config/gates.json, keyed '<FROM>-><TO>' (e.g. 'BLD->REL' for a\n"
            "pre-deploy approval, '*->REL' for every hand-off into release). The\n"
            "legacy `post_nav_review` key still governs the planning exit.\n"
            "Orders sit in .mso/queues/review/ until approved, revised, or rejected;\n"
            "`queue` shows the gate each one is held at. `revise` sends an order back\n"
            "to the role that triggered its gate."
        ),
    )
    p.add_argument("--project", metavar="@PRJ", help="Registered project acronym")
    review_sub = p.add_subparsers(dest="review_action", metavar="<action>", required=True)

    rp = review_sub.add_parser("queue", help="List orders awaiting review")
    rp.set_defaults(func=lambda a: _cmd_review("queue", a))

    rp = review_sub.add_parser("show", help="Open the NAV plan in $EDITOR (or print to stdout)")
    rp.add_argument("order_id", metavar="ORDER-ID", help="Order to show")
    rp.add_argument("--editor", metavar="CMD", help="Editor command (overrides $EDITOR)")
    rp.set_defaults(func=lambda a: _cmd_review("show", a))

    rp = review_sub.add_parser("approve", help="Approve order and advance to next role")
    rp.add_argument("order_id", metavar="ORDER-ID", help="Order to approve")
    rp.set_defaults(func=lambda a: _cmd_review("approve", a))

    rp = review_sub.add_parser("revise", help="Send order back to NAV with revision notes")
    rp.add_argument("order_id", metavar="ORDER-ID", help="Order to revise")
    rp.add_argument("--notes", metavar="TEXT", help="Revision notes (required)")
    rp.set_defaults(func=lambda a: _cmd_review("revise", a))

    rp = review_sub.add_parser("reject", help="Reject order and archive as FAILED")
    rp.add_argument("order_id", metavar="ORDER-ID", help="Order to reject")
    rp.add_argument("--notes", metavar="TEXT", help="Rejection reason (required)")
    rp.set_defaults(func=lambda a: _cmd_review("reject", a))

    # -- roles --
    p = sub.add_parser("roles", help="Inspect and validate role definitions",
                       formatter_class=argparse.RawDescriptionHelpFormatter,
                       description="Manage Maestro role definitions and overlays.",
                       epilog="""
subcommands:
  list            List all 7 canonical roles with code, name, and model
  show CODE       Print the effective (merged) role as Markdown
  validate        Validate all role files and overlays
  diff CODE       Show a unified diff between core and effective role
  migrate-paths   Guidance for migrating from legacy role-paths.json

examples:
  mso roles list
  mso roles show TST
  mso roles show TST --core
  mso roles show TST --json
  mso roles validate
  mso roles diff TST
""")
    p.set_defaults(func=cmd_roles)
    roles_sub = p.add_subparsers(dest="roles_action", metavar="<subcommand>")
    roles_sub.required = True

    rp = roles_sub.add_parser("list", help="List all canonical roles")
    rp.set_defaults(func=cmd_roles, roles_action="list")

    rp = roles_sub.add_parser("show", help="Print effective role definition")
    rp.add_argument("code", metavar="CODE", help="Role code (e.g. TST)")
    rp.add_argument("--core", action="store_true", default=False,
                    help="Show core role only (ignore overlay)")
    rp.add_argument("--overlay-only", action="store_true", default=False,
                    help="Show user overlay file only (if present)")
    rp.add_argument("--json", action="store_true", default=False,
                    help="Print parsed RoleDefinition as JSON")
    rp.set_defaults(func=cmd_roles, roles_action="show")

    rp = roles_sub.add_parser("validate",
                               help="Validate all role files and overlays (exit 0 = all valid)")
    rp.set_defaults(func=cmd_roles, roles_action="validate")

    rp = roles_sub.add_parser("diff", help="Diff core vs effective merged role")
    rp.add_argument("code", metavar="CODE", help="Role code (e.g. TST)")
    rp.set_defaults(func=cmd_roles, roles_action="diff")

    rp = roles_sub.add_parser("migrate-paths",
                               help="Guidance for migrating from legacy role-paths.json")
    rp.set_defaults(func=cmd_roles, roles_action="migrate-paths")

    # -- packs (FTR-MSO-2026-0383) --
    p = sub.add_parser("packs", help="Inspect Maestro division packs",
                       formatter_class=argparse.RawDescriptionHelpFormatter,
                       description="Discover and inspect division packs — templated "
                                   "persona + role + order-type sets for non-SDLC teams.",
                       epilog="""
subcommands:
  list                List built-in packs with tier badges
  show PACK           Show a pack's manifest, order types, and anatomy
  validate [PACK]     Validate manifest + role overlays + persona + order
                       templates + gates/workspace-defaults; all packs if
                       PACK is omitted. Non-zero exit on any failure (CI-usable).
  apply PACK          Apply a pack onto the CURRENT workspace — prints a
                       preview, then applies (unless --dry-run). PACK may be
                       a built-in id, a path to a custom pack directory, or
                       an https:// URL to a signed custom-pack archive
                       (Team/Enterprise — FTR-MSO-2026-0481).
                       Refuses if the enrolment profile has locked this
                       workspace to a different pack, unless --force.

examples:
  mso packs list
  mso packs show sdlc
  mso packs show sdlc --json
  mso packs validate
  mso packs validate sdlc
  mso packs validate --path ./my-pack
  mso packs apply test-engineering
  mso packs apply ./my-pack --dry-run
  mso packs apply https://packs.example.com/secops.json
  mso init --project QA1 --pack test-engineering
  mso init --project QA1 --pack ./my-pack
  mso init --project QA1 --pack https://packs.example.com/secops.json
""")
    p.set_defaults(func=cmd_packs)
    packs_sub = p.add_subparsers(dest="packs_action", metavar="<subcommand>")
    packs_sub.required = True

    pp = packs_sub.add_parser("list", help="List built-in packs")
    pp.set_defaults(func=cmd_packs, packs_action="list")

    pp = packs_sub.add_parser("show", help="Show a pack's manifest and anatomy")
    pp.add_argument("pack", metavar="PACK", help="Pack id (e.g. sdlc)")
    pp.add_argument("--json", action="store_true", default=False,
                    help="Print the raw pack.json manifest as JSON")
    pp.set_defaults(func=cmd_packs, packs_action="show")

    pp = packs_sub.add_parser("validate",
                              help="Validate pack manifest + content (CI-usable, exit 0/1)")
    pp.add_argument("pack", metavar="PACK", nargs="?", default=None,
                    help="Pack id to validate (default: validate all built-in packs)")
    pp.add_argument("--path", default=None,
                    help="Validate an arbitrary pack directory instead of a built-in pack")
    pp.set_defaults(func=cmd_packs, packs_action="validate")

    pp = packs_sub.add_parser(
        "apply",
        help="Apply a pack onto the current workspace (preview shown first)")
    pp.add_argument("pack", metavar="PACK",
                    help="Pack id (e.g. sdlc), a path to a custom pack directory, "
                         "or an https:// URL to a signed custom-pack archive "
                         "(Team/Enterprise — FTR-MSO-2026-0481)")
    pp.add_argument("--force", action="store_true", default=False,
                    help="Apply even if the enrolment profile has locked this "
                         "workspace to a different pack")
    pp.add_argument("--dry-run", action="store_true", default=False,
                    help="Show the preview only — do not apply")
    pp.add_argument("--project", metavar="@PRJ",
                    help="Registered project acronym (e.g. @ADM)")
    pp.set_defaults(func=cmd_packs, packs_action="apply")

    # -- policy (governance Phase 2, FTR-MSO-2026-0397) --
    p = sub.add_parser("policy", help="Signed policy bundles (governance, enterprise)",
                       formatter_class=argparse.RawDescriptionHelpFormatter,
                       description="Distribute + verify Ed25519-signed governance policy "
                                   "bundles. Signed bundles let an org ship guardrails a "
                                   "local engineer cannot silently relax.",
                       epilog="""
subcommands:
  pull [--url URL]   Fetch the signed bundle from the artefact channel, verify its
                     Ed25519 signature + anti-rollback version, and install it into
                     .mso/config/policy-bundle.json. Honours offline grace. (Enterprise)
  verify [--bundle PATH]
                     Verify a bundle's signature without advancing the version floor
                     (read-only). Defaults to the workspace bundle.
  verify --ci        CI ENFORCEMENT backstop — re-evaluate a committed diff against
                     the governed packs; exit non-zero on any violation, so a
                     locally-bypassed rule still fails the merge. Run it in CI.
                     See `mso docs governance-trust-boundary`.
  show               Show the installed bundle, pinned trusted keys, and version floors.
  report [--json] [--output PATH]
                     Produce a SOC2/ISO-mappable compliance evidence document from
                     live policy state + the hash-chained audit log (policy inventory,
                     eval/deny/break-glass statistics, bundle provenance).

admin authoring (FTR-MSO-2026-0479 — keygen/init/lint/sign are ungated;
trust add/rotate, enable, and publish require Team/Enterprise):
  keygen --key-id ID [--out DIR]
                     Generate an org Ed25519 signing keypair. The seed is written
                     off-client (refused inside a git tree or a .mso/ workspace);
                     the public key prints to stdout for `trust add`.
  init --bundle-id ID [--from PACKS] [--out PATH] [--mode MODE]
                     Draft an unsigned bundle, optionally seeded with rules copied
                     from named built-in packs.
  lint PATH          Schema-validate an unsigned draft bundle.
  sign PATH --key-id ID [--key-file PATH] [--out PATH]
                     Sign a draft with the org seed (--key-file or
                     MAESTRO_POLICY_SIGNING_KEY).
  publish PATH [--out PATH]
                     Validate a bundle is signed and hand it off for HTTPS hosting.
  trust add --key-id ID --public-key B64 [--status S] [--not-after ISO]
                     Pin a signing key into $MAESTRO_HOME/trusted-keys.json.
  trust rotate --retire ID --activate ID [--public-key B64]
                     Retire one home-pinned key and activate another.
  enable --mode enforce|warn|off
                     Write governance.governedMode into workspace.json.

examples:
  mso policy pull
  mso policy pull --url https://acme.example/policy-bundle.json
  mso policy verify
  mso policy verify --ci --base origin/main
  mso policy show
  mso policy report
  mso policy report --json
  mso policy report --output evidence.md
  mso policy keygen --key-id acme-2026-q3 --out ~/keys/
  mso policy init --from protected-branch,secret-handling --bundle-id acme-standard --out acme-policy.json
  mso policy lint acme-policy.json
  mso policy sign acme-policy.json --key-id acme-2026-q3 --key-file ~/keys/acme-2026-q3.seed
  mso policy trust add --key-id acme-2026-q3 --public-key <b64>
  mso policy trust rotate --retire acme-2026-q2 --activate acme-2026-q3
  mso policy enable --mode enforce
""")
    policy_sub = p.add_subparsers(dest="policy_action", metavar="<subcommand>")
    policy_sub.required = True

    pp = policy_sub.add_parser("pull", help="Fetch + verify + install the signed bundle")
    pp.add_argument("--url", default=None, help="Override the bundle source URL")
    pp.set_defaults(func=cmd_policy, policy_action="pull")

    pp = policy_sub.add_parser(
        "verify",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        help="Verify a bundle signature (read-only), or re-evaluate a diff with --ci",
        description="Two modes:\n"
                    "  (default) verify a signed bundle's Ed25519 signature (read-only).\n"
                    "  --ci      re-evaluate a committed diff against the governed packs —\n"
                    "            the CI ENFORCEMENT backstop. Exits non-zero on any violation,\n"
                    "            so a locally-bypassed rule still fails the merge. Runs off the\n"
                    "            engineer's machine; needs no licence (MAESTRO_SKIP_AUTH ok).",
        epilog="""
examples:
  mso policy verify                              # verify the signed bundle (Phase 2)
  mso policy verify --ci                         # diff origin/main...HEAD in CWD
  mso policy verify --ci --base origin/main      # explicit PR base
  mso policy verify --ci --staged                # staged changes
  mso policy verify --ci --diff-file changes.patch
  git diff origin/main...HEAD | mso policy verify --ci --diff-file -
  mso policy verify --ci --json                  # machine-readable report
  mso policy verify --ci --warn-only             # report but never block
""",
    )
    # Phase 2 — signed-bundle verification.
    pp.add_argument("--bundle", default=None, help="Path to a bundle JSON (default: workspace bundle)")
    # Phase 5 (FTR-MSO-2026-0400) — CI diff-evaluator backstop.
    pp.add_argument("--ci", action="store_true",
                    help="Re-evaluate a committed diff against the governed packs (CI backstop)")
    pp.add_argument("--base", "--against", dest="base", metavar="REF",
                    help="[--ci] Diff base ref for base...HEAD (default: origin/main)")
    pp.add_argument("--head", metavar="REF", default=None,
                    help="[--ci] Diff head ref (default: HEAD)")
    pp.add_argument("--staged", action="store_true",
                    help="[--ci] Evaluate staged changes (git diff --staged) instead of a branch diff")
    pp.add_argument("--diff-file", metavar="PATH", dest="diff_file",
                    help="[--ci] Read a pre-computed unified diff from PATH ('-' = stdin)")
    pp.add_argument("--repo", metavar="PATH",
                    help="[--ci] Repository directory to run git in (default: current directory)")
    pp.add_argument("--exclude", metavar="GLOB", action="append",
                    help="[--ci] Skip paths matching GLOB (repeatable; adds to the defaults)")
    pp.add_argument("--include", metavar="GLOB", action="append",
                    help="[--ci] Restrict evaluation to paths matching GLOB (repeatable)")
    pp.add_argument("--no-default-excludes", action="store_true", dest="no_default_excludes",
                    help="[--ci] Do not apply the built-in doc/pack exclude set")
    pp.add_argument("--warn-only", action="store_true", dest="warn_only",
                    help="[--ci] Report violations without failing (exit 0)")
    pp.add_argument("--json", action="store_true",
                    help="[--ci] Emit a machine-readable JSON report")
    pp.set_defaults(func=cmd_policy, policy_action="verify")

    pp = policy_sub.add_parser("show", help="Show installed bundle + trusted keys + floors")
    pp.set_defaults(func=cmd_policy, policy_action="show")

    pp = policy_sub.add_parser(
        "report",
        help="Produce a SOC2/ISO compliance evidence document from live audit data")
    pp.add_argument("--json", action="store_true",
                    help="Emit the raw evidence as JSON to stdout instead of writing a Markdown file")
    pp.add_argument("--output", default=None,
                    help="Write the Markdown evidence to this path "
                         "(default: .mso/reports/compliance/POLICY-EVIDENCE-<stamp>.md)")
    pp.set_defaults(func=cmd_policy, policy_action="report")

    # -- admin authoring (FTR-MSO-2026-0479) --
    # keygen/init/lint/sign are UNGATED: an evaluator must be able to author
    # and sign a trial bundle before buying anything (§5.4). trust add/rotate,
    # enable, and publish arm governance on a device and are Team/Enterprise-gated.
    pp = policy_sub.add_parser("keygen", help="Generate an org Ed25519 signing keypair")
    pp.add_argument("--key-id", required=True, dest="key_id",
                    help="Identifier for this key, e.g. acme-2026-q3")
    pp.add_argument("--out", default=None,
                    help="Directory to write the seed file (default: cwd; refused inside "
                         "a git tree or a .mso/ workspace)")
    pp.set_defaults(func=cmd_policy, policy_action="keygen")

    pp = policy_sub.add_parser("init", help="Draft an unsigned policy bundle")
    pp.add_argument("--from", dest="from_packs", default=None,
                    help="Comma-separated built-in pack names to seed rules from "
                         "(e.g. protected-branch,secret-handling)")
    pp.add_argument("--out", default="policy-draft.json",
                    help="Output path for the draft bundle (default: policy-draft.json)")
    pp.add_argument("--bundle-id", required=True, dest="bundle_id", help="bundleId for the draft")
    pp.add_argument("--mode", dest="governed_mode", default="enforce",
                    choices=["enforce", "warn", "off"],
                    help="governedMode to stamp on the draft (default: enforce)")
    pp.set_defaults(func=cmd_policy, policy_action="init")

    pp = policy_sub.add_parser("lint", help="Schema-validate an unsigned draft bundle")
    pp.add_argument("bundle", metavar="PATH", help="Path to the draft bundle JSON")
    pp.set_defaults(func=cmd_policy, policy_action="lint")

    pp = policy_sub.add_parser("sign", help="Sign a draft bundle with the org Ed25519 seed")
    pp.add_argument("bundle", metavar="PATH",
                    help="Path to the draft bundle JSON (signed in place unless --out is given)")
    pp.add_argument("--key-id", required=True, dest="key_id",
                    help="keyId to stamp into the signature envelope")
    pp.add_argument("--key-file", default=None, dest="key_file",
                    help="Path to the seed file (base64/hex); default: "
                         "MAESTRO_POLICY_SIGNING_KEY env var")
    pp.add_argument("--out", default=None,
                    help="Write the signed bundle here instead of overwriting the input")
    pp.set_defaults(func=cmd_policy, policy_action="sign")

    pp = policy_sub.add_parser(
        "publish", help="Validate + hand off a signed bundle for HTTPS distribution (Team/Enterprise)")
    pp.add_argument("bundle", metavar="PATH", help="Path to the signed bundle JSON")
    pp.add_argument("--out", default=None,
                    help="Copy the signed bundle to this path (e.g. a web-server-served directory)")
    pp.set_defaults(func=cmd_policy, policy_action="publish")

    pp = policy_sub.add_parser(
        "enable", help="Write governance.governedMode into workspace.json (Team/Enterprise)")
    pp.add_argument("--mode", required=True, dest="governed_mode",
                    choices=["enforce", "warn", "off"])
    pp.set_defaults(func=cmd_policy, policy_action="enable")

    tp_top = policy_sub.add_parser("trust", help="Manage the home trusted-key registry (Team/Enterprise)")
    trust_sub = tp_top.add_subparsers(dest="trust_action", metavar="<subcommand>")
    trust_sub.required = True

    tp = trust_sub.add_parser("add", help="Pin a signing key into the home trusted-key registry")
    tp.add_argument("--key-id", required=True, dest="key_id")
    tp.add_argument("--public-key", required=True, dest="public_key",
                    help="Base64 or hex 32-byte Ed25519 public key")
    tp.add_argument("--status", default="active", choices=["active", "retiring", "revoked"])
    tp.add_argument("--not-after", default=None, dest="not_after", help="ISO-8601 hard expiry")
    tp.set_defaults(func=cmd_policy, policy_action="trust-add")

    tp = trust_sub.add_parser("rotate", help="Retire one home-pinned key and activate another")
    tp.add_argument("--retire", required=True, dest="retire_id")
    tp.add_argument("--activate", required=True, dest="activate_id")
    tp.add_argument("--public-key", default=None, dest="public_key",
                    help="Public key for --activate, if it is not already pinned")
    tp.add_argument("--not-after", default=None, dest="not_after")
    tp.set_defaults(func=cmd_policy, policy_action="trust-rotate")

    # -- version --
    p = sub.add_parser("version", help="Print version")
    p.set_defaults(func=cmd_version)

    # -- docs --
    p = sub.add_parser("docs", help="Browse documentation topics")
    p.add_argument("topic", nargs="?", help="Topic to display (omit to list all topics)")
    p.set_defaults(func=cmd_docs)

    return parser


def _debug_enabled(args: argparse.Namespace | None = None) -> bool:
    """Return True if --debug flag or MAESTRO_DEBUG env var is set."""
    if os.environ.get("MAESTRO_DEBUG"):
        return True
    return args is not None and getattr(args, "debug", False)


def _invoked_command(args: argparse.Namespace | None = None) -> str:
    """Return the subcommand name from parsed args, or 'mso'."""
    if args is None:
        return "mso"
    return getattr(args, "command", None) or "mso"


def _force_utf8_streams() -> None:
    """Force UTF-8 on stdout/stderr (BUG-MSO-2026-0526).

    Stored document prose (role definitions, plans, handoffs) legitimately
    contains non-ASCII characters (arrows, em-dashes, box-drawing). On a
    non-UTF-8 console codepage (e.g. Windows cp1252), the default stdout
    encoding raises UnicodeEncodeError and aborts the command. Reconfiguring
    once at the entry point — with errors="replace" so a still-unencodable
    glyph degrades to a placeholder instead of crashing — fixes every command
    that prints stored text, not just the one that happened to be reported.
    """
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if callable(reconfigure):
            try:
                reconfigure(encoding="utf-8", errors="replace")
            except Exception:
                pass


def main() -> None:
    _force_utf8_streams()
    args = None
    try:
        parser = build_parser()
        args = parser.parse_args()
        if _debug_enabled(args):
            os.environ["MAESTRO_DEBUG"] = "1"
        args.func(args)
    except MaestroError as exc:
        print_error(str(exc), hint=exc.hint)
        sys.exit(exc.exit_code)
    except KeyboardInterrupt:
        sys.exit(130)
    except SystemExit:
        raise
    except Exception as exc:
        if _debug_enabled(args):
            raise
        print_unexpected(exc, command=_invoked_command(args))
        sys.exit(1)


if __name__ == "__main__":
    main()
