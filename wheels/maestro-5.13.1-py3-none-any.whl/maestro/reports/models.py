# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Framework-agnostic report records (FTR-MSO-2026-0728 — PLAN-PLN-MSO-2026-0726 §5, Order A1).

**This module imports no web framework, and must never grow one.** It carries
plain :mod:`dataclasses` only — no FastAPI, no Pydantic. That is the whole
point: this package follows FTR-MSO-2026-0700's one-core-model-many-surfaces
shape, so *one* function computes a report record and the Hub API, the CLI and
FTR-MSO-2026-0502's PR-body generator all consume the same one. The moment a
Pydantic model appears here that property is gone — the Hub owns the wire shape
(``maestro/hub/models.py``) and adapts to these records, never the reverse.
``tests/test_ftr_0728_reports_core.py`` asserts the absence mechanically so it
cannot regress quietly.

**The honesty rule (plan §7) lives at this layer, not only at the page layer.**
Every status vocabulary below carries an explicit "we do not know" member, and
no reader is permitted to default to the optimistic answer:

* :data:`Verdict.UNDETERMINED` — the report exists but declares no verdict we
  can read. Never rendered, counted or defaulted as an approval.
* :data:`ACStatus.NOT_RECORDED` — a criterion with no recorded result (Captain
  decision D4). A first-class status, never folded into ``met`` or ``failed``.
* :data:`Provenance.NOT_RECORDED` — the absence itself is attributable, so a
  surface can say *where* it looked rather than implying nothing exists.

Counts are :class:`typing.Optional` throughout for the same reason: a report
with no parseable test-summary table has ``tests=None``, which is a different
claim from ``tests=0`` ("the fleet ran no tests"). A surface that cannot tell
those apart cannot be honest about either.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


# ---------------------------------------------------------------------------
# Vocabularies
# ---------------------------------------------------------------------------

class Verdict:
    """The QA / security verdict tokens, plus the honest unknown.

    ``APPROVED / CONDITIONAL / REJECTED / BLOCKED`` are the four tokens the
    live plane actually writes (measured over 275 MSO QA reports at build
    time — plan §1.3). ``PASS`` / ``FAIL`` also appear, exclusively in
    hand-written and ADM-era reports declaring ``**Verdict:** PASS``; they are
    the same claim in different words and are aliased, never invented — and the
    literal text is always preserved on :attr:`QAReportSummary.raw_verdict`, so
    a normalisation can be audited against its source.
    """

    APPROVED = "APPROVED"
    CONDITIONAL = "CONDITIONAL"
    REJECTED = "REJECTED"
    BLOCKED = "BLOCKED"
    UNDETERMINED = "UNDETERMINED"

    #: Decided tokens, in the order a scan prefers them when a declaration
    #: line names more than one (see
    #: :func:`maestro.reports.qa_reader.extract_verdict`).
    DECIDED = (APPROVED, CONDITIONAL, REJECTED, BLOCKED)

    ALL = DECIDED + (UNDETERMINED,)

    #: Aliases seen in the wild, mapped to the canonical token. Deliberately
    #: tiny and explicit — an unrecognised word yields UNDETERMINED, not a guess.
    ALIASES = {
        "PASS": APPROVED,
        "PASSED": APPROVED,
        "FAIL": REJECTED,
        "FAILED": REJECTED,
    }

    @classmethod
    def normalise(cls, token: Optional[str]) -> str:
        """Map *token* to a canonical verdict, or ``UNDETERMINED``."""
        text = (token or "").strip().upper()
        if text in cls.DECIDED:
            return text
        return cls.ALIASES.get(text, cls.UNDETERMINED)

    @classmethod
    def is_decided(cls, token: Optional[str]) -> bool:
        return (token or "") in cls.DECIDED


class ACStatus:
    """Acceptance-criterion result vocabulary.

    ``NOT_RECORDED`` is Captain decision D4 made structural: absence of a
    result is never a pass, and it is never folded into a pass/fail total. A
    status word that cannot be classified at all yields ``UNDETERMINED`` — also
    not a pass. The two are distinct on purpose: ``NOT_RECORDED`` means nobody
    wrote anything down, ``UNDETERMINED`` means somebody did and it cannot be
    read.
    """

    PASS = "PASS"
    FAIL = "FAIL"
    PARTIAL = "PARTIAL"
    SKIP = "SKIP"
    NOT_RECORDED = "NOT RECORDED"
    UNDETERMINED = "UNDETERMINED"

    #: Statuses that count as a positive verification. Exactly one member, and
    #: that is the point — PARTIAL and SKIP are not passes.
    MET = (PASS,)

    ALL = (PASS, FAIL, PARTIAL, SKIP, NOT_RECORDED, UNDETERMINED)

    _ALIASES = {
        "PASS": PASS, "PASSED": PASS, "PASSES": PASS, "OK": PASS,
        "MET": PASS, "VERIFIED": PASS, "YES": PASS, "DONE": PASS,
        "FAIL": FAIL, "FAILED": FAIL, "FAILS": FAIL, "NOT MET": FAIL, "NO": FAIL,
        "PARTIAL": PARTIAL, "PARTIALLY": PARTIAL, "CONDITIONAL": PARTIAL,
        "SKIP": SKIP, "SKIPPED": SKIP, "N/A": SKIP, "NA": SKIP,
        "NOT APPLICABLE": SKIP, "DEFERRED": SKIP,
        "NOT RECORDED": NOT_RECORDED, "NOT-RECORDED": NOT_RECORDED,
    }

    #: Decoration reports actually put in a status cell. Stripped before
    #: matching so a tick beside a word does not defeat the lookup.
    _DECORATION = (
        "*", "`", "_", "✅", "✔", "☑", "✓", "❌",
        "✗", "✘", "⚠", "️", "\U0001f7e1", "\U0001f7e2",
        "\U0001f534",
    )

    @classmethod
    def normalise(cls, token: Optional[str]) -> str:
        """Map a raw status cell to a canonical status.

        Tolerant of the decoration reports actually use — a leading tick or
        cross, bold markers, and a trailing qualifier after an em dash or
        parenthesis (``PASS — see note``, ``PASS (with caveat)``). An empty
        cell is ``NOT_RECORDED``; an unrecognised word is ``UNDETERMINED``.
        Never ``PASS`` by default.
        """
        text = (token or "").strip()
        if not text:
            return cls.NOT_RECORDED
        for ch in cls._DECORATION:
            text = text.replace(ch, " ")
        text = " ".join(text.split()).upper()
        if not text:
            # The cell held only a decoration glyph. Honest answer: a tick is
            # not a word, and guessing which of PASS/SKIP it stood for would be
            # exactly the invention the honesty rule forbids.
            return cls.UNDETERMINED
        # Strip a trailing qualifier: "PASS — with caveat", "PASS (see ac-04)".
        head = text
        for sep in ("—", "–", "(", ",", ";", ":", " - "):
            head = head.split(sep)[0]
        head = head.strip()
        for candidate in (head, text):
            if candidate in cls._ALIASES:
                return cls._ALIASES[candidate]
        # A leading recognised word still decides ("PASS with caveat").
        first = head.split(" ")[0] if head else ""
        return cls._ALIASES.get(first, cls.UNDETERMINED)


class Provenance:
    """Where a record's value came from.

    Carried per AC row (Captain decision D4b: the QA report's own AC table is a
    legitimate *second* source alongside ``order.acResults``, with explicit
    provenance so the two can be shown side by side when they disagree rather
    than one silently winning).
    """

    ORDER_RESULTS = "order.acResults"
    QA_REPORT = "QA report"
    NOT_RECORDED = "not recorded"
    SECURITY_REPORT = "SEC report"
    SCANNER_RUN = "scanner run"
    VOYAGE_RECORD = "voyage record"
    USAGE_ROLLUP = "usage rollup"


# ---------------------------------------------------------------------------
# QA
# ---------------------------------------------------------------------------

@dataclass
class TestCategoryCounts:
    """One ``### <category> Tests`` subsection's counts.

    ``None`` means the subsection carried no numeric table — not zero.
    """

    name: str
    tests: Optional[int] = None
    passed: Optional[int] = None
    failed: Optional[int] = None

    def to_dict(self) -> Dict[str, Any]:
        return {"name": self.name, "tests": self.tests,
                "passed": self.passed, "failed": self.failed}


@dataclass
class TestCounts:
    """A report's ``## Test Summary`` rollup.

    Every figure is optional. ``tests=None`` says "this report has no parseable
    count", which a surface must render differently from ``tests=0``.
    """

    tests: Optional[int] = None
    passed: Optional[int] = None
    failed: Optional[int] = None
    categories: List[TestCategoryCounts] = field(default_factory=list)

    @property
    def recorded(self) -> bool:
        return (self.tests is not None or self.passed is not None
                or self.failed is not None)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "tests": self.tests, "passed": self.passed, "failed": self.failed,
            "recorded": self.recorded,
            "categories": [c.to_dict() for c in self.categories],
        }


@dataclass
class ACCriterionRow:
    """One acceptance criterion and its recorded result.

    Produced by the QA reader from a report's ``## Acceptance Criteria
    Verification`` table, and by Order B1's ``ac_reader`` from an order's
    ``acceptanceCriteria`` / ``acResults`` fields — the same row shape either
    way, distinguished by :attr:`provenance`.
    """

    id: str = ""
    criterion: str = ""
    status: str = ACStatus.NOT_RECORDED
    raw_status: str = ""
    validation: str = ""
    notes: str = ""
    evidence: str = ""
    provenance: str = Provenance.NOT_RECORDED

    @property
    def met(self) -> bool:
        """True only for an affirmative recorded pass. Absence is never a pass."""
        return self.status in ACStatus.MET

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "criterion": self.criterion, "status": self.status,
            "rawStatus": self.raw_status, "validation": self.validation,
            "notes": self.notes, "evidence": self.evidence,
            "provenance": self.provenance, "met": self.met,
        }


@dataclass
class QAReportSummary:
    """The machine-readable record of one ``reports/qa/*.md`` report.

    Built by :func:`maestro.reports.qa_reader.read_qa_report`. Every field is
    derived from text actually present in the file; a missing section yields an
    empty collection or ``None``, never a fabricated value, and
    :attr:`parse_notes` records what could not be read so a surface can say so
    out loud.
    """

    order_id: str
    verdict: str = Verdict.UNDETERMINED
    #: The literal declaration text the verdict was read from, e.g.
    #: ``"CONDITIONAL — F1 and F3 APPROVED; F2 REJECTED"``. Preserved verbatim
    #: so a normalisation can always be audited against the source.
    raw_verdict: str = ""
    #: Which heading (or document-level declaration) supplied the verdict —
    #: e.g. ``"## QA Decision"``. Empty when the verdict is UNDETERMINED.
    verdict_source: str = ""
    #: ``nodeVerdict`` front-matter, when present and not ``CONSUMED``.
    #: A CORROBORATING HINT ONLY (Captain decision D3) — the dispatcher
    #: rewrites this field to ``CONSUMED`` the moment routing acts on it
    #: (``chart_routing._rewrite_verdict_consumed``), so it is a routing token
    #: with a lifecycle, not a report field. Never the source of truth.
    node_verdict: Optional[str] = None
    ac_rows: List[ACCriterionRow] = field(default_factory=list)
    #: ``maestro.core.role_rejection.Defect`` rows from ``## Defects Found``,
    #: parsed by that module's own parser (never a reimplementation).
    defects: List[Any] = field(default_factory=list)
    test_counts: TestCounts = field(default_factory=TestCounts)
    #: Report file identity — relative to the artefact root, never absolute
    #: (an absolute path on a wire response leaks the operator's filesystem).
    report_name: str = ""
    report_rel: str = ""
    modified: str = ""
    size: int = 0
    truncated: bool = False
    #: Human-readable notes about what could NOT be parsed. Rendered by a
    #: surface as a caveat; never empty-and-silent about a real gap.
    parse_notes: List[str] = field(default_factory=list)

    @property
    def decided(self) -> bool:
        return Verdict.is_decided(self.verdict)

    @property
    def blocking_defects(self) -> List[Any]:
        return [d for d in self.defects if getattr(d, "blocking", False)]

    @property
    def ac_met(self) -> int:
        return sum(1 for r in self.ac_rows if r.met)

    @property
    def ac_not_recorded(self) -> int:
        return sum(1 for r in self.ac_rows if r.status == ACStatus.NOT_RECORDED)

    @property
    def node_verdict_corroborates(self) -> Optional[bool]:
        """Whether :attr:`node_verdict` agrees with :attr:`verdict`.

        ``None`` when there is nothing to compare — no front-matter verdict, or
        an undecided heading verdict. Exposed so a surface can flag a
        disagreement rather than silently preferring one source (plan §7).
        """
        if not self.node_verdict or not self.decided:
            return None
        nv = self.node_verdict.strip().upper()
        if nv in ("PASS", "APPROVED", "OK"):
            return self.verdict in (Verdict.APPROVED, Verdict.CONDITIONAL)
        if nv in ("FAIL", "REJECTED", "BLOCKED"):
            return self.verdict in (Verdict.REJECTED, Verdict.BLOCKED)
        return None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "orderId": self.order_id,
            "verdict": self.verdict,
            "rawVerdict": self.raw_verdict,
            "verdictSource": self.verdict_source,
            "nodeVerdict": self.node_verdict,
            "nodeVerdictCorroborates": self.node_verdict_corroborates,
            "decided": self.decided,
            "acRows": [r.to_dict() for r in self.ac_rows],
            "acMet": self.ac_met,
            "acNotRecorded": self.ac_not_recorded,
            "defects": [d.to_dict() for d in self.defects if hasattr(d, "to_dict")],
            "blockingDefectCount": len(self.blocking_defects),
            "testCounts": self.test_counts.to_dict(),
            "reportName": self.report_name,
            "reportRel": self.report_rel,
            "modified": self.modified,
            "size": self.size,
            "truncated": self.truncated,
            "parseNotes": list(self.parse_notes),
        }


@dataclass
class ParseCoverage:
    """How much of a set of reports actually parsed (plan §3, D3's mitigation).

    Exposed on every list response so parser drift against a heading contract
    nobody enforces becomes *visible* rather than silent. ``undetermined`` is
    reported as its own figure, never subtracted away.
    """

    total: int = 0
    parsed: int = 0
    undetermined: int = 0

    def add(self, decided: bool) -> None:
        self.total += 1
        if decided:
            self.parsed += 1
        else:
            self.undetermined += 1

    def to_dict(self) -> Dict[str, Any]:
        return {"total": self.total, "parsed": self.parsed,
                "undetermined": self.undetermined}


# ---------------------------------------------------------------------------
# AC rollup (populated by Order B1's ac_reader; the shape is fixed here so the
# Hub, the CLI and the PR-body generator agree on it from the start)
# ---------------------------------------------------------------------------

@dataclass
class ACOrderRollup:
    """One order's acceptance-criteria verification record.

    Coverage semantics are Captain decision D4 and are load-bearing:
    :attr:`met` / :attr:`failed` / :attr:`partial` are computed over rows that
    have a *recorded* result, and :attr:`not_recorded` is its own bucket. A
    caller must never derive "outstanding" as ``total - met``: that silently
    converts an unrecorded criterion into a failure, the mirror image of the
    error the rule forbids.
    """

    order_id: str
    title: str = ""
    voyage_id: str = ""
    rows: List[ACCriterionRow] = field(default_factory=list)
    #: Sources that contributed rows, in :class:`Provenance` terms.
    sources: List[str] = field(default_factory=list)
    #: Criterion ids where the order JSON and the QA report disagree. Shown as
    #: a conflict, never resolved by preferring one side.
    conflicts: List[str] = field(default_factory=list)

    @property
    def total(self) -> int:
        return len(self.rows)

    @property
    def recorded(self) -> int:
        return sum(1 for r in self.rows if r.status != ACStatus.NOT_RECORDED)

    @property
    def met(self) -> int:
        return sum(1 for r in self.rows if r.status == ACStatus.PASS)

    @property
    def failed(self) -> int:
        return sum(1 for r in self.rows if r.status == ACStatus.FAIL)

    @property
    def partial(self) -> int:
        return sum(1 for r in self.rows if r.status == ACStatus.PARTIAL)

    @property
    def not_recorded(self) -> int:
        return sum(1 for r in self.rows if r.status == ACStatus.NOT_RECORDED)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "orderId": self.order_id, "title": self.title,
            "voyageId": self.voyage_id,
            "rows": [r.to_dict() for r in self.rows],
            "sources": list(self.sources), "conflicts": list(self.conflicts),
            "total": self.total, "recorded": self.recorded, "met": self.met,
            "failed": self.failed, "partial": self.partial,
            "notRecorded": self.not_recorded,
        }


# ---------------------------------------------------------------------------
# Security (populated by Order B3's security_reader)
# ---------------------------------------------------------------------------

@dataclass
class SecurityReportSummary:
    """One hand-written ``reports/security/SEC-{ORDER-ID}.md`` record.

    Deliberately separate from :class:`ScannerRun`. Plan §1.4 measured these as
    three incompatible populations, and the SEC family is the weak one: no
    front-matter at all, ``## Security Decision`` in 20 of 35 files, verdict
    prose ranging from ``**Status**: Secure`` to
    ``**Status**: PARTIALLY MODERNISED``. ``UNDETERMINED`` will be the honest
    answer for a real fraction of them, and that is the intended output — not a
    defect in the reader.
    """

    order_id: str
    verdict: str = Verdict.UNDETERMINED
    raw_verdict: str = ""
    verdict_source: str = ""
    findings: List[Any] = field(default_factory=list)
    report_name: str = ""
    report_rel: str = ""
    modified: str = ""
    parse_notes: List[str] = field(default_factory=list)

    @property
    def decided(self) -> bool:
        return Verdict.is_decided(self.verdict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "orderId": self.order_id, "verdict": self.verdict,
            "rawVerdict": self.raw_verdict, "verdictSource": self.verdict_source,
            "decided": self.decided,
            "findings": [f.to_dict() for f in self.findings if hasattr(f, "to_dict")],
            "reportName": self.report_name, "reportRel": self.report_rel,
            "modified": self.modified, "parseNotes": list(self.parse_notes),
        }


@dataclass
class ScannerRun:
    """One ``reports/security/REVIEW-{timestamp}.md`` scanner run.

    A **run record**, never a fleet risk posture. Plan §1.1 pinned why: a
    sampled HIGH from ``REVIEW-20260807T214608Z.md`` was *"Literal path
    traversal sequence in string"* fired on the ``...`` inside
    ``print("Loading scanner counts...")``, and the run scanned the artefact
    plane including its own tooling. The counts are real numbers about a real
    execution and are simultaneously wrong by orders of magnitude about risk.
    :attr:`counts_trustworthy` exists so no surface can quietly forget that —
    it defaults to ``False``, and Order B4's acceptance criteria forbid deriving
    a severity KPI from these.
    """

    run_id: str
    ran_at: str = ""
    files_scanned: Optional[int] = None
    counts_by_severity: Dict[str, int] = field(default_factory=dict)
    report_name: str = ""
    report_rel: str = ""
    counts_trustworthy: bool = False
    caveat: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "runId": self.run_id, "ranAt": self.ran_at,
            "filesScanned": self.files_scanned,
            "countsBySeverity": dict(self.counts_by_severity),
            "reportName": self.report_name, "reportRel": self.report_rel,
            "countsTrustworthy": self.counts_trustworthy, "caveat": self.caveat,
        }


# ---------------------------------------------------------------------------
# Voyage (populated by Order B5's voyage_reader)
# ---------------------------------------------------------------------------

@dataclass
class VoyageReportSummary:
    """A voyage report COMPOSED ON READ (Captain decision D2).

    There is no producer artefact and there must not be one: every input
    already exists on disk (``voyages/{active,complete}/*.json`` for the
    manifest and PR state, ``aggregator.aggregate_usage_for_voyage`` for spend,
    this package's QA reader for verdicts), and composing lights up *every*
    voyage in the workspace on day one where a new artefact would cover only
    voyages closing after it shipped.

    A genuinely unavailable field stays ``None`` / empty. Per plan §6, if
    FTR-MSO-2026-0700's ``Blockage`` has not landed, B5 **omits** blockage
    rather than reimplementing it — :attr:`blockages` simply stays empty.
    """

    voyage_id: str
    title: str = ""
    branch: str = ""
    status: str = ""
    pr_number: Optional[int] = None
    merged: Optional[bool] = None
    started_date: str = ""
    completed_date: str = ""
    order_ids: List[str] = field(default_factory=list)
    qa_summaries: List[QAReportSummary] = field(default_factory=list)
    ac_rollups: List[ACOrderRollup] = field(default_factory=list)
    usage: Optional[Dict[str, Any]] = None
    blockages: List[Any] = field(default_factory=list)
    parse_notes: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "voyageId": self.voyage_id, "title": self.title,
            "branch": self.branch, "status": self.status,
            "prNumber": self.pr_number, "merged": self.merged,
            "startedDate": self.started_date,
            "completedDate": self.completed_date,
            "orderIds": list(self.order_ids),
            "qaSummaries": [q.to_dict() for q in self.qa_summaries],
            "acRollups": [a.to_dict() for a in self.ac_rollups],
            "usage": self.usage,
            "parseNotes": list(self.parse_notes),
        }


__all__ = [
    "ACCriterionRow", "ACOrderRollup", "ACStatus", "ParseCoverage",
    "Provenance", "QAReportSummary", "ScannerRun", "SecurityReportSummary",
    "TestCategoryCounts", "TestCounts", "Verdict", "VoyageReportSummary",
]
