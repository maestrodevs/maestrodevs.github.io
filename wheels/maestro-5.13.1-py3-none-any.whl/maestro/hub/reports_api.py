# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""The Hub's report routes (FTR-MSO-2026-0729 — PLAN-PLN-MSO-2026-0726 §5, Order A2).

**What this module is, and what it deliberately is not.** It is the thin
adapter between :mod:`maestro.reports` — the framework-agnostic report record
core delivered by Order A1 — and FastAPI. It parses nothing, walks no
directories, and knows no report file format. Every fact on a response here was
computed by :mod:`maestro.reports.qa_reader`; this module's whole job is
workspace fan-out, bounding, and turning dataclasses into the wire models in
:mod:`maestro.hub.models`.

That boundary is the plan's "one core model, many surfaces" rule (§4) made
structural: the CLI and FTR-MSO-2026-0502's PR-body generator consume the same
records, so a parsing change made *here* would be a second QA parser drifting
away from the first — which is the exact failure the core package exists to
prevent.

**Ungated, by Captain decision D1.** These routes carry no
``_require_control_tier()`` call, matching every other read-only route in the
Hub (``/api/v1/usage*``, ``/orders/{id}/artefacts``,
``/orders/{id}/salvage-candidates``) and unlike every mutating one. The
decisive point recorded in the plan: ``GET /api/v1/orders/{id}/artefacts/{key}``
already serves the full raw bytes of every QA report, ungated, today — gating a
*parsed summary* of files whose *raw text* is already open would be theatre, and
would make the Hub inconsistent with itself. The Hub's confidentiality boundary
is per-deployment (``MAESTRO_HUB_TOKEN``, allowed hosts/origins), not
per-endpoint tier; tiers gate capability, not confidentiality.

**Registration by injection, not by re-implementation.** ``create_app()`` owns
``_validate_order_id`` and ``_iter_workspaces`` as closures, and
:func:`register_report_routes` takes them as arguments rather than growing local
copies. An order id reaching these routes is therefore validated by *the same
function object* the artefact and review routes use — a hardening change to that
regex cannot leave a report route behind, which a second copy silently would.

**No content read happens here.** ``MAX_ARTEFACT_BYTES`` (512 KB) is applied by
``qa_reader._read_bounded`` at the point of every file read, so the bound holds
for this surface because this surface performs no reads of its own. There is
nothing to re-cap and nothing that could be capped inconsistently.

**FastAPI is imported lazily**, inside :func:`register_report_routes`, for the
same reason ``server.py`` does it: ``import maestro.hub.reports_api`` must never
fail when the ``[hub]`` extra is absent.
"""

from __future__ import annotations

from typing import Any, Callable, Iterable, List, Optional, Tuple

#: Default number of QA reports returned by the list route.
#:
#: The live MSO workspace holds 274 of them; an unbounded list would parse every
#: one on every request, and the page that consumes this shows a table. A caller
#: that genuinely wants everything asks for it explicitly, up to
#: :data:`MAX_QA_LIMIT`.
DEFAULT_QA_LIMIT = 100

#: Hard ceiling on ``?limit=``. FastAPI rejects a larger value at validation
#: (``le=MAX_QA_LIMIT``), and :func:`list_qa` clamps defensively for its
#: non-HTTP callers, so the bound holds on both paths.
MAX_QA_LIMIT = 500


# ---------------------------------------------------------------------------
# Read functions — no FastAPI, so they are callable from a test (or a CLI)
# without an HTTP round-trip.
# ---------------------------------------------------------------------------

def _mso_dirs(iter_workspaces: Callable[[], Iterable[Tuple[str, Any]]],
              workspace_id: Optional[str] = None) -> List[Tuple[str, Any]]:
    """``(workspace_id, mso_dir)`` for every registered workspace, or just one.

    A workspace whose artefact root cannot be resolved (an unregistered path, a
    stale mount) is skipped rather than failing the whole response — the same
    tolerance ``_find_order_workspace_any`` applies. It then appears nowhere in
    the response's ``workspaces`` list, so an operator can see it was not read.
    """
    from maestro.hub.review import _get_mso_dir

    out: List[Tuple[str, Any]] = []
    for ws_id, ws_root in iter_workspaces():
        if workspace_id is not None and ws_id != workspace_id:
            continue
        try:
            out.append((ws_id, _get_mso_dir(ws_root)))
        except Exception:
            continue
    return out


def _qa_model(summary: Any, workspace_id: str = ""):
    """Wire model for one :class:`~maestro.reports.models.QAReportSummary`.

    Built by splatting the record's own ``to_dict()``, so the wire shape is the
    core shape by construction. A field added to the record and not to the model
    is dropped by Pydantic rather than crashing the route; a field added to the
    model and not to the record takes its declared default. Neither can silently
    invent a value.
    """
    from maestro.hub.models import QAReportModel

    payload = summary.to_dict()
    payload["workspaceId"] = workspace_id
    return QAReportModel(**payload)


def list_qa(iter_workspaces: Callable[[], Iterable[Tuple[str, Any]]],
            workspace_id: Optional[str] = None,
            limit: int = DEFAULT_QA_LIMIT):
    """Every QA report across the registered workspaces, newest first, bounded.

    ``limit`` is clamped to ``[0, MAX_QA_LIMIT]``. Each workspace is asked for
    at most ``limit`` records (its own newest), the merged set is re-sorted by
    modification time and trimmed to ``limit`` — so the response is the globally
    newest ``limit`` reports, not the first workspace's share of them.

    ``available`` counts the QA report FILES the scanned workspaces hold, read
    from the directory listing rather than from the parsed set, so a bounded
    response always states how much it left out. ``parseCoverage`` is recomputed
    over exactly the trimmed set: it must describe the records the caller
    received and never a larger set they did not (plan §7).
    """
    from maestro.hub.artefacts import iter_report_paths
    from maestro.hub.models import ParseCoverageModel, QAReportList
    from maestro.reports import list_qa_reports
    from maestro.reports.models import ParseCoverage

    try:
        limit = int(limit)
    except (TypeError, ValueError):
        limit = DEFAULT_QA_LIMIT
    limit = max(0, min(limit, MAX_QA_LIMIT))

    scanned: List[str] = []
    available = 0
    rows: List[Tuple[str, str, Any]] = []   # (modified, workspace_id, summary)

    for ws_id, mso in _mso_dirs(iter_workspaces, workspace_id):
        scanned.append(ws_id)
        try:
            available += sum(1 for p in iter_report_paths(mso, "qa")
                             if p.suffix.lower() == ".md")
        except Exception:
            pass
        if limit == 0:
            continue
        try:
            summaries, _coverage = list_qa_reports(mso, limit=limit)
        except Exception:
            # `list_qa_reports` is documented never to raise, but a workspace
            # that somehow breaks it must not take the other workspaces' reports
            # down with it.
            continue
        for summary in summaries:
            rows.append((summary.modified or "", ws_id, summary))

    # Newest first. `modified` is an ISO-8601 UTC string from the same producer
    # for every row, so it sorts lexicographically; the report name breaks ties
    # deterministically. An empty `modified` (an unreadable stat) sorts last,
    # which is the honest place for the record we know least about.
    rows.sort(key=lambda r: (r[0], r[2].report_name), reverse=True)
    rows = rows[:limit]

    coverage = ParseCoverage()
    reports = []
    for _modified, ws_id, summary in rows:
        coverage.add(summary.decided)
        reports.append(_qa_model(summary, ws_id))

    return QAReportList(
        reports=reports,
        parseCoverage=ParseCoverageModel(**coverage.to_dict()),
        workspaceId=workspace_id,
        limit=limit,
        returned=len(reports),
        available=available,
        workspaces=scanned,
    )


def qa_detail(iter_workspaces: Callable[[], Iterable[Tuple[str, Any]]],
              order_id: str,
              workspace_id: Optional[str] = None):
    """The QA record for *order_id*, or ``None`` when no workspace has one.

    ``None`` means discovery found no ``reports/qa/`` file for this order in any
    scanned workspace. It is NOT the same as a record carrying
    ``verdict=UNDETERMINED``, which means a report exists and could not be read
    — the route maps the first to 404 and returns the second as a 200, because
    "no QA has been done" and "QA was done and we cannot summarise it" are
    different answers and a surface must be able to tell them apart.
    """
    from maestro.reports import read_qa_report

    for ws_id, mso in _mso_dirs(iter_workspaces, workspace_id):
        try:
            summary = read_qa_report(mso, order_id)
        except Exception:
            continue
        if summary is not None:
            return _qa_model(summary, ws_id)
    return None


# ---------------------------------------------------------------------------
# Route registration
# ---------------------------------------------------------------------------

def register_report_routes(app, *, validate_order_id, iter_workspaces) -> None:
    """Attach the ``/api/v1/reports/*`` routes to *app*.

    Called once from ``create_app()`` AFTER every pre-existing route is
    registered. It adds routes and touches none of them — the report surface
    sits alongside the artefact routes, never on top of them (plan §4, "DO NOT
    MODIFY").

    *validate_order_id* and *iter_workspaces* are ``create_app()``'s own
    closures, passed in rather than re-created here (see the module docstring).
    """
    import fastapi

    from maestro.hub.models import QAReportList, QAReportModel

    # -----------------------------------------------------------------------
    # QA report endpoints (FTR-MSO-2026-0729) — read-only, ungated
    # -----------------------------------------------------------------------

    @app.get("/api/v1/reports/qa", response_model=QAReportList)
    async def list_qa_reports_route(
        workspace_id: Optional[str] = fastapi.Query(default=None),
        limit: int = fastapi.Query(default=DEFAULT_QA_LIMIT, ge=0, le=MAX_QA_LIMIT),
    ):
        """QA reports across every registered workspace, newest first.

        Read-only, ungated — matches `/api/v1/usage` (Captain decision D1).

        workspace_id: restrict to one registered workspace (default: all)
        limit: bound on the number of reports returned (default 100, max 500)

        The response carries `parseCoverage` — {total, parsed, undetermined} —
        so a drift in the QA heading contract shows up as a falling `parsed`
        instead of as silently missing verdicts.
        """
        return list_qa(iter_workspaces, workspace_id=workspace_id, limit=limit)

    @app.get("/api/v1/reports/qa/{order_id}", response_model=QAReportModel)
    async def get_qa_report_route(order_id: str):
        """One order's QA record. Read-only, ungated — matches `/api/v1/usage`.

        *order_id* is validated by `create_app()`'s own `_validate_order_id`, so
        a traversal attempt is a 400 before any filesystem access, and a
        well-formed id nothing has a report for is a 404 whose detail names only
        the id the caller already supplied.
        """
        validate_order_id(order_id)
        report = qa_detail(iter_workspaces, order_id)
        if report is None:
            raise fastapi.HTTPException(
                status_code=404,
                detail=f"No QA report found for order '{order_id}'")
        return report


__all__ = [
    "DEFAULT_QA_LIMIT",
    "MAX_QA_LIMIT",
    "list_qa",
    "qa_detail",
    "register_report_routes",
]
