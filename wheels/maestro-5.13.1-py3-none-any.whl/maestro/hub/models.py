# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Pydantic models for the Maestro Hub API (all phases in one module).

Field names here are chosen to serialize to JSON that matches the frontend
TypeScript interfaces in `maestro-hub/app/types/index.ts` EXACTLY (the
authoritative data contract). Top-level entity fields are snake_case to match
the TS interfaces; the WorkspaceConfig sub-object intentionally keeps camelCase
keys (maxCrews, completion.idleWatchdog...) because the frontend reads them
straight from .mso/config/workspace.json shapes.
"""

from __future__ import annotations

from typing import Any, List, Optional

from pydantic import BaseModel, ConfigDict, Field


# ---- Phase 1 ----------------------------------------------------------------

class HealthResponse(BaseModel):
    status: str = "ok"
    version: str
    workspaces: int = 0
    # BUG-MSO-2026-0467: was the poller's first full scan pass complete when
    # this response was built? False during the cold-start window — lets a
    # caller distinguish "workspaces: 0, still scanning" from "workspaces: 0,
    # genuinely nothing registered" without a second endpoint round-trip.
    poller_ready: bool = True
    # BUG-MSO-2026-0627: `version` above is `maestro.__version__` as PINNED at
    # process start (Python caches the import for the process lifetime) — the
    # code this Hub process is actually RUNNING, which can silently fall
    # behind after a `pip install --upgrade` if the daemon isn't restarted
    # (the FTR-MSO-2026-0577/0578 route-table gap this order traces to).
    # `installedVersion` is read FRESH on every request via
    # `importlib.metadata` (never cached in `sys.modules`), so it reflects
    # what's on disk right now even without a restart — the same
    # runningVersion/installedVersion split FTR-MSO-2026-0588 gave the LEAD
    # daemon, done here as a live self-check since the Hub has no per-tick
    # state file to persist a reader-independent snapshot into.
    installedVersion: Optional[str] = None
    versionMismatch: bool = False
    # BUG-MSO-2026-0712: when THIS backend process started, and how long it has
    # been up. Measured by the process about itself (a module-level stamp taken
    # at `create_app()`), not read back from the PID record — so a restart is
    # visible in the dashboard header the moment the new process answers,
    # without the reader having to trust a file some other process wrote. The
    # 2026-09-09 death was noticed only because a human opened the dashboard;
    # an uptime that resets to seconds is what makes the NEXT one self-evident.
    startedAt: Optional[str] = None
    uptimeSeconds: Optional[float] = None


class PollerStatus(BaseModel):
    """Poller readiness — the authoritative source for the initialising-vs-empty
    distinction (BUG-MSO-2026-0467). See WorkspacePoller.status()."""
    state: str = "ready"   # "initialising" | "ready"
    ready: bool = True
    scanned: int = 0
    total: int = 0


class AttentionBreakdown(BaseModel):
    """Per-workspace rollup of BUG-MSO-2026-0451's held/dispatchable taxonomy,
    computed workspace-by-workspace by ``maestro.hub.attention``
    (FTR-MSO-2026-0487 / PLAN-PLN-MSO-2026-0468 §2 — reuses the four category
    NAMES ``get_held_breakdown()`` already established; this is not a second,
    competing taxonomy).

    Bucket mapping (§2): review_gated -> "In Review" (a human decision),
    stranded -> "Needs Attention" (a recovery), dep_held -> "Blocked"
    (resolves itself), skipped -> "Skipped" (operator-intended invisibility).
    """
    review_gated: int = 0
    stranded: int = 0
    dep_held: int = 0
    skipped: int = 0
    # needs_you = review_gated + stranded — the two buckets a human must act
    # on. Excludes dep_held (self-resolving) and skipped (operator-intended),
    # matching §2's ruling that both merge only at this summary level, never
    # in the per-bucket lists.
    needs_you: int = 0


class WorkspaceSummary(BaseModel):
    id: str
    name: str
    path: str
    online: bool = True
    dispatcher_running: bool = False
    active_voyage_count: int = 0
    pending_order_count: int = 0
    active_crew_count: int = 0
    review_pending_count: int = 0
    # Frontend Workspace interface uses `pending_review_count`; mirror it so the
    # overview cards can read either name. (Kept additive — review_pending_count
    # above is preserved so existing consumers/tests don't break.)
    pending_review_count: int = 0
    # BUG-MSO-2026-0451: orders excluded from pending_order_count because the
    # dispatcher is holding them (dep-held or operator-skipped) — the Hub-card
    # counterpart of `mso status`'s "N held" figure, so a fixed pending count
    # doesn't just make skipped/dep-held work silently vanish from the card.
    held_order_count: int = 0
    # FTR-MSO-2026-0487: the named breakdown behind held_order_count, plus the
    # review-gated + stranded categories held_order_count never counted (it
    # only ever covered dep-held + skipped). This is the one figure the
    # workspace card needs for "Needs you: N".
    attention: AttentionBreakdown = Field(default_factory=AttentionBreakdown)
    # FTR-MSO-2026-0539: forward-referenced (LeadPip is defined further down
    # this module, alongside LeadStatus) — `from __future__ import
    # annotations` at the top of this file makes the forward reference safe.
    lead: Optional["LeadPip"] = None


# ---- Phase 2 ----------------------------------------------------------------

class ClaimedBy(BaseModel):
    """The FTR-MSO-2026-0374 shared-mode claim-by-commit stamp.

    Matches the frontend `ClaimedBy` interface. Mirrors the shape
    `_stamp_claim()` (maestro/core/artefact_sync.py) writes onto the durable
    order JSON — engineer identity, host, pid, and claim timestamp.
    """
    engineer: str = ""
    host: str = ""
    pid: Optional[int] = None
    at: str = ""


class Order(BaseModel):
    """Matches the frontend `Order` interface (app/types/index.ts)."""
    id: str
    title: str = ""
    description: Optional[str] = None
    status: str = "PENDING"
    role: str = ""
    target_role: Optional[str] = None
    voyage_id: Optional[str] = None
    workspace_id: str = ""
    # BUG-MSO-2026-0711: 'critical' is its own value, not folded into 'high' —
    # it is the priority that overrides the queue tier.
    priority: Optional[str] = None  # 'critical' | 'high' | 'normal' | 'low'
    created_at: str = ""
    updated_at: Optional[str] = None
    started_at: Optional[str] = None
    completed_at: Optional[str] = None
    depends_on: Optional[list[str]] = None
    role_sequence: list[str] = Field(default_factory=list)
    # FTR-MSO-2026-0622: the order's acceptance criteria, carried through to
    # the frontend RAW (only the id/description shape is normalised — see
    # aggregator._map_order). The `Order` contract never carried this field,
    # so the Hub's OrderDrawer rendered an EMPTY acceptance-criteria list for
    # every order, including the 551 live ones that have criteria — a false
    # impression of an order's own definition, and (once Save became real)
    # the shape that would have let an edit overwrite criteria the operator
    # was never shown.
    #
    # Untyped `list` on purpose. Live artefacts carry two shapes (bare strings
    # AND dicts) and the dicts carry keys the Hub does not model
    # (`validationType`, `command`, `status`, `verifiedBy`, `note`). Modelling
    # a subset here would silently drop the rest on the round trip through an
    # edit, so the entries pass through unchanged and the drawer merges by id.
    acceptance_criteria: Optional[list] = None
    timeout_minutes: Optional[int] = None
    iteration: Optional[int] = None
    max_iterations: Optional[int] = None
    target_repo: Optional[str] = None
    # FTR-MSO-2026-0376: shared-mode multi-engineer visibility. Field names
    # are camelCase by order spec (mirrors Voyage.phaseReason above); absent
    # in embedded/solo mode where the order was never claimed-by-commit.
    claimedBy: Optional[ClaimedBy] = None
    claimedAt: Optional[str] = None
    # FTR-MSO-2026-0487: BUG-MSO-2026-0451 taxonomy tag — one of
    # 'review_gated' | 'stranded' | 'dep_held' | 'skipped', or None when the
    # order is plainly dispatchable/running/complete. Computed per workspace
    # by maestro.hub.attention.classify_orders (never re-derived client-side —
    # PLAN-PLN-MSO-2026-0468 §3.3's "reuse, don't copy the category list").
    attention: Optional[str] = None
    # Human-readable detail for the tag above — e.g. the blocking order id(s)
    # for a dep_held order. Empty/None for categories with no extra detail.
    # BUG-MSO-2026-0703: for a `stranded` order this carries the dispatcher's
    # `operatorNote` — the salvage branch, its diff-stat, the ancestry found,
    # and the exact recovery command — so the Hub shows the NEXT STEP rather
    # than the bare status a stranded order used to be reduced to.
    attention_reason: Optional[str] = None
    # BUG-MSO-2026-0703: the order JSON's `operatorNote` verbatim, whatever the
    # attention category (a stranded order sets it, but so does a STALLED
    # archival — BUG-MSO-2026-0301/0445). None when the order carries none.
    operator_note: Optional[str] = None
    # BUG-MSO-2026-0705: the fleet's OWN QA verdict when this order's stall was
    # a role REJECTION — "rejected by TST: DEF-001 (HIGH) <summary>" — plus the
    # command that resumes it. Mapped straight off the order JSON's `rejection`
    # block (parsed once, at archival, by maestro.core.role_rejection), so the
    # Hub board can show WHY an order is stranded and what to do about it
    # instead of a bare STALLED. None for every order nothing rejected.
    rejection_headline: Optional[str] = None
    rejection_command: Optional[str] = None
    # BUG-MSO-2026-0743: whether this order is on the operator skip list
    # (`.mso/config/skipped-orders.json` — `mso order skip`). Deliberately its
    # OWN field rather than `attention == 'skipped'`: the attention tag is
    # single-valued, and stranded/dep_held/review_gated legitimately overwrite
    # the skipped tag for the same order — so the tag answers "no" for exactly
    # the orders an operator most often skips (a stranded one). Reading skip
    # state off the tag made the Hub's Restore (unskip) control unreachable for
    # every skipped CONVERGENCE_FAILED / BLOCKED / AUTO_SERIALIZE / dep-held
    # order, leaving a second Remove button in its place. Stamped by
    # maestro.hub.attention.apply_skip_state straight from
    # maestro.core.skip_list — the one shared reader — never re-derived.
    is_skipped: bool = False
    # The operator's `--reason` for the skip, when they gave one. Decoration
    # only: a skip with no reason is still a skip, so this being None never
    # implies `is_skipped is False`.
    skip_reason: Optional[str] = None


class VoyagePrEntry(BaseModel):
    """One repo's PR linkage within a voyage's ``prUrls`` map (FTR-MSO-2026-0380).

    Mirrors the per-repo entry ``_apply_pr_linkage``/``_reconcile_multi_repo_voyage``
    write onto ``voyage["prUrls"][repo_slug]`` (maestro/core/fleet_runner.py).
    Field names are camelCase to match the manifest verbatim (same convention
    as Voyage.phaseReason / Order.claimedBy above).
    """
    prNumber: Optional[int] = None
    prUrl: Optional[str] = None
    state: Optional[str] = None
    mergeCommit: Optional[str] = None
    mergedAt: Optional[str] = None


class VoyageOrderRollup(BaseModel):
    """Effective member-order counts backing the derived voyage phase
    (FTR-MSO-2026-0351). Keys are camelCase by contract (order spec)."""
    total: int = 0
    complete: int = 0
    blocked: int = 0
    inProgress: int = 0
    pending: int = 0
    held: int = 0


class Voyage(BaseModel):
    """Matches the frontend `Voyage` interface."""
    id: str
    title: str = ""
    status: str = "PLANNED"
    branch: str = ""
    order_count: int = 0
    complete_count: int = 0
    orders: Optional[list[Order]] = None
    created_at: str = ""
    pr_url: Optional[str] = None
    # BUG-MSO-2026-0394: sibling flat field to pr_url — the manifest's
    # flat prNumber (written by ``_apply_pr_linkage``), or the single
    # entry's prNumber when the manifest only ever wrote a prUrls map.
    # Ambiguous (left None) for a genuine multi-repo voyage with >1 PR
    # linked — per-repo numbers are available via prUrls in that case.
    pr_number: Optional[int] = None
    workspace_id: str = ""
    repo: str = ""
    worktree: str = ""
    # FTR-MSO-2026-0351: derived lifecycle phase from ledger + archive + PR
    # state (the stored `status` above is kept as-is for back-compat).
    phase: str = "backlog"
    phaseReason: str = ""
    rollup: VoyageOrderRollup = Field(default_factory=VoyageOrderRollup)
    # FTR-MSO-2026-0380: multi-repo voyage reality (FTR-0379 manifest shape).
    # `repo`/`pr_url` above remain the back-compat flat fields (unchanged
    # derivation — most-common targetRepo / best-effort last-recorded PR);
    # these carry the REAL per-repo set so the Hub can render one pill per
    # repo instead of collapsing to a single value. Empty for a legacy/
    # single-repo voyage that never wrote targetRepos/prUrls. camelCase by
    # order spec (mirrors phaseReason/claimedBy — matches the manifest keys
    # verbatim).
    targetRepos: list[str] = Field(default_factory=list)
    prUrls: dict[str, VoyagePrEntry] = Field(default_factory=dict)


class CrewState(BaseModel):
    """Matches the frontend `CrewState` interface."""
    slot: int
    name: str = ""
    status: str = "IDLE"
    role: Optional[str] = None
    current_order_id: Optional[str] = None
    current_order_title: Optional[str] = None
    iteration: Optional[int] = None
    max_iterations: Optional[int] = None
    # FTR-MSO-2026-0632: same state.json keys fleet_monitor.py already reads
    # (liveTurn/maxTurns, FTR-MSO-2026-0227) — turns are the activity signal
    # that actually moves within an iteration; None (not 0) when the crew's
    # state predates these fields or carries no live state at all.
    live_turn: Optional[int] = None
    max_turns: Optional[int] = None
    # BUG-MSO-2026-0698: the crew's RESOLVED wall-clock ceiling (minutes).
    # Turn and iteration counters say how far through its budget a crew is on
    # two axes but not on the third, which is the one that actually kills it.
    # None when the crew's state predates the field (or carries no live state).
    timeout_minutes: Optional[int] = None
    activity_age_seconds: Optional[int] = None
    pid: Optional[int] = None
    session_id: Optional[str] = None
    maestro_session_id: Optional[str] = None


class CrewActivityEntry(BaseModel):
    """One structured entry from a crew's ``activity.jsonl`` (FTR-MSO-2026-0577).

    Mirrors what ``maestro/hooks/posttool.py`` appends on every tool call.
    ``target`` is redacted via ``maestro.hooks.secret_patterns.redact_text``
    before this model is constructed — it can carry a Bash command or a file
    path a crew read/echoed.
    """
    timestamp: str = ""
    tool: str = ""
    action: str = ""
    target: str = ""


class CrewDetail(BaseModel):
    """``GET /api/v1/workspaces/{id}/crews/{slot}/detail`` — FTR-MSO-2026-0577.

    The read-only "what is this crew busy with" view the Hub's crew-drawer
    needs. Deliberately never carries ``output_01.txt``/``output_final.txt``
    (raw Claude transcript — 639 KB+ and unbounded on a real fleet);
    ``activity`` is the structured record of the same work and bounded by
    the aggregator. ``activity_line``/``progress_markdown``/``target`` on
    each ``activity`` entry are all redacted before this model is built.

    An IDLE slot (a crew directory that exists but has no live state) still
    returns a well-formed record with empty/default fields — never an error.
    A slot with no directory at all resolves to ``None`` in the aggregator,
    which the endpoint turns into a 404.
    """
    slot: int
    name: str = ""
    status: str = "IDLE"
    role: Optional[str] = None
    current_order_id: Optional[str] = None
    current_order_title: Optional[str] = None
    iteration: Optional[int] = None
    max_iterations: Optional[int] = None
    # FTR-MSO-2026-0632: see CrewState.live_turn/max_turns above.
    live_turn: Optional[int] = None
    max_turns: Optional[int] = None
    activity_line: str = ""
    activity: list[CrewActivityEntry] = Field(default_factory=list)
    progress_markdown: str = ""
    files_modified: list[str] = Field(default_factory=list)
    # BUG-MSO-2026-0713: where the slot's PREVIOUS run was retained. Every
    # field above describes the run currently in the slot; when a crew has
    # died and been replaced, that is precisely the run an operator does not
    # need. `previous_run_path` names the directory the prior run's
    # output_*.txt / activity.jsonl were moved to at re-dispatch, so the
    # drawer can point at evidence that used to be truncated in place. It is
    # a PATH, not content — the drawer never inlines a raw transcript, for the
    # same reason this model never carries output_01.txt.
    previous_run_path: Optional[str] = None
    previous_run_order_id: Optional[str] = None
    previous_run_role: Optional[str] = None
    previous_run_retained_at: Optional[str] = None


class Repo(BaseModel):
    """Matches the frontend `Repo` interface."""
    id: str
    name: str
    path: str
    default_branch: str = "main"


class IdleWatchdogConfig(BaseModel):
    enabled: bool = False
    idleMinutes: int = 30
    action: str = "none"


class OnVoyageCompleteConfig(BaseModel):
    archiveVoyageOnMerge: bool = True
    archiveOrders: bool = True
    autoRelease: bool = False


class CompletionConfig(BaseModel):
    idleWatchdog: Optional[IdleWatchdogConfig] = None
    onVoyageComplete: Optional[OnVoyageCompleteConfig] = None
    roleTimeouts: Optional[dict[str, int]] = None


class WorkspaceConfig(BaseModel):
    """Matches the frontend `WorkspaceConfig` interface (camelCase preserved)."""
    persona: Optional[str] = None
    project: Optional[str] = None
    maxCrews: Optional[int] = None
    completion: Optional[CompletionConfig] = None
    # FTR-MSO-2026-0328: per-workspace dispatch defaults (null = not configured)
    maxIterations: Optional[int] = None
    maxTurns: Optional[int] = None
    timeoutMinutes: Optional[int] = None
    autoDispatch: Optional[bool] = None
    requirePlanReview: Optional[bool] = None
    tokenDailyCap: Optional[int] = None


class UsagePoint(BaseModel):
    """One data point in a workspace token-usage history series."""
    date: str          # ISO date string (YYYY-MM-DD)
    tokens: int = 0
    cost_usd: float = 0.0


class WorkspaceUsage(BaseModel):
    """Aggregated token-usage metrics for a workspace (FTR-MSO-2026-0330)."""
    total_tokens: int = 0
    estimated_cost_usd: float = 0.0
    order_count: int = 0                        # number of orders with usage data
    history: list[UsagePoint] = Field(default_factory=list)  # per-day series (newest last)


class WorkspaceDetail(BaseModel):
    """Matches the frontend `WorkspaceDetail` (extends Workspace) interface."""
    id: str
    name: str
    path: str
    dispatcher_running: bool = False
    active_crew_count: int = 0
    active_voyage_count: int = 0
    pending_review_count: int = 0
    pending_order_count: int = 0
    held_order_count: int = 0  # BUG-MSO-2026-0451: dep-held + operator-skipped
    # FTR-MSO-2026-0487: see WorkspaceSummary.attention — same rollup, full detail view.
    attention: AttentionBreakdown = Field(default_factory=AttentionBreakdown)
    persona: Optional[str] = None
    project: Optional[str] = None
    config: WorkspaceConfig = Field(default_factory=WorkspaceConfig)
    voyages: list[Voyage] = Field(default_factory=list)
    crews: list[CrewState] = Field(default_factory=list)
    queue_summary: dict[str, int] = Field(default_factory=dict)
    orders: list[Order] = Field(default_factory=list)
    repos: list[Repo] = Field(default_factory=list)
    usage: Optional[WorkspaceUsage] = None
    # FTR-MSO-2026-0376: 'embedded' | 'solo' | 'shared' (maestro.workspace
    # ARTEFACT_MODES) — lets the frontend show a SHARED indicator without
    # inferring it from claimedBy presence alone. camelCase by order spec.
    artefactMode: str = "embedded"
    # FTR-MSO-2026-0492 §4.4: the exact `mso dispatch` command for a backlog
    # voyage, computed server-side from the PRODUCT repo path (never `path`
    # above, which is the artefact parent in solo/shared mode) — a
    # frontend-assembled `cd {path}` would print a command that fails on the
    # operator's machine. Empty when unknown (e.g. offline_detail()).
    dispatchCommand: str = ""


class LifecycleEvent(BaseModel):
    """Matches the frontend `LifecycleEvent` interface (WebSocket stream)."""
    workspace_id: str
    workspace_name: str
    line: str = ""              # raw log line (kept for backward-compat)
    message: str = ""           # parsed message — frontend contract field
    timestamp: str = ""
    event_type: str = ""
    order_id: Optional[str] = None
    crew_slot: Optional[int] = None
    role: Optional[str] = None
    subtype: Optional[str] = None


# ---- Phase 3 ----------------------------------------------------------------

class ReviewItem(BaseModel):
    """Matches the frontend `ReviewItem` interface (BARE-ARRAY endpoint)."""
    order_id: str
    workspace_id: str
    workspace_name: str = ""
    order_title: str = ""
    role: str = ""
    voyage_id: Optional[str] = None
    plan_markdown: Optional[str] = None
    created_at: str = ""
    paused_at: Optional[str] = None
    priority: Optional[str] = None


class PlanResponse(BaseModel):
    workspace_id: str
    order_id: str
    plan_markdown: str = ""
    has_plan_file: bool = False
    order: dict


class ReviseRequest(BaseModel):
    feedback: str


class RejectRequest(BaseModel):
    reason: str


class AckRequest(BaseModel):
    """Body for ``POST .../lead/findings/{fingerprint}/ack`` (PLAN-PLN-MSO-2026-0584
    Dimension D). ``by`` is optional — an unauthenticated Hub deployment has
    no operator identity to read, so it defaults to ``"hub"`` server-side
    rather than requiring the frontend to invent one. ``days`` is optional
    and, when omitted, resolves to ``maestro.patrol.state.ACK_TTL_DAYS_DEFAULT``
    (7) — there is deliberately no way to request a non-expiring ack."""
    note: str = ""
    by: Optional[str] = None
    days: Optional[int] = None


class ActionResult(BaseModel):
    ok: bool
    order_id: str
    new_status: str = ""
    message: str = ""


# ---- Artefacts + Retry (FTR-MSO-2026-0492) ----------------------------------

class ArtefactRef(BaseModel):
    """One discovered artefact's manifest entry — no content.

    ``key`` is an opaque, server-issued token (``discover_artefacts``'s
    ``{kind}:{name}`` form); a client cannot construct one that resolves to a
    file discovery did not itself find (maestro/hub/artefacts.py §4.2).
    """
    key: str
    kind: str
    name: str
    size: int = 0
    modified: str = ""


class OrderArtefacts(BaseModel):
    """Response for ``GET /orders/{id}/artefacts`` — manifest only, no content."""
    order_id: str
    workspace_id: str
    artefacts: list[ArtefactRef] = Field(default_factory=list)


class ArtefactContent(BaseModel):
    """Response for ``GET /orders/{id}/artefacts/{key}`` — one artefact's body.

    Bounded at ``artefacts.MAX_ARTEFACT_BYTES`` (512 KB, §5.5); ``truncated``
    is set and ``size`` still carries the true on-disk size when the read was
    capped.
    """
    key: str
    kind: str
    name: str
    content: str = ""
    truncated: bool = False
    size: int = 0


class SalvageCandidateModel(BaseModel):
    """One salvage branch ``mso order retry`` could arm (BUG-MSO-2026-0696).

    Mirrors ``maestro.core.salvage_record.SalvageCandidate.to_dict()`` field for
    field. The Hub and the CLI read the SAME candidate list from the SAME core
    function — AC-4's no-drift requirement is structural here, not a convention
    to remember: neither surface computes candidates of its own.
    """
    branch: str
    sha: Optional[str] = None
    reason: str = ""
    crew: Optional[int] = None
    role: str = ""
    timestamp: str = ""
    diff_stat: Optional[dict] = Field(default=None, alias="diffStat")
    source: str = "salvageBranches"
    index: Optional[int] = None
    summary: str = ""

    model_config = {"populate_by_name": True}


class SalvageCandidates(BaseModel):
    """Response for ``GET /orders/{id}/salvage-candidates`` (BUG-MSO-2026-0696).

    Read-only preview of what a retry WOULD arm — so an operator (or the Hub
    UI) can see the choice, and the ambiguity verdict, before spending one.
    """
    order_id: str
    candidates: List[SalvageCandidateModel] = Field(default_factory=list)
    would_arm: Optional[str] = None
    ambiguous: str = ""


class RetryResult(BaseModel):
    """Response for ``POST /orders/{id}/retry``."""
    ok: bool
    order_id: str
    new_status: str = ""
    target_role: str = ""
    salvage_branch: Optional[str] = None
    # BUG-MSO-2026-0696 (AC-4): the same candidate list the CLI prints, so the
    # Hub can never show a narrower view of what was available than the CLI.
    salvage_candidates: List[SalvageCandidateModel] = Field(default_factory=list)
    salvage_explicit: bool = False
    message: str = ""


# ---- Order edit + skip (FTR-MSO-2026-0622, PLAN-PLN-MSO-2026-0556 Order 6) --

class OrderEditRequest(BaseModel):
    """Body for ``PATCH /orders/{id}`` — every field optional, none defaulted.

    Field names are the ORDER JSON's own camelCase keys, not the snake_case
    read models above, because they are handed STRAIGHT to
    ``order_create.edit_order``'s ``updates`` mapping, whose keys are checked
    against :data:`maestro.core.order_create.EDITABLE_FIELDS` — the artefact's
    vocabulary. Translating them here would create a second name table to keep
    in step with that allowlist, which is the drift this plan exists to close.

    ``None`` means UNSET, never "clear this field": a PATCH carries only what
    the operator changed, and a body that omitted ``dependsOn`` must not wipe
    an order's dependencies. Callers read :meth:`updates`, which drops unset
    keys via ``exclude_unset`` rather than by testing for ``None`` — so an
    explicit ``"description": ""`` (a real clear) still reaches the core,
    while an absent key never does.
    """
    # `extra="forbid"` so a field name this endpoint does not offer is a 422
    # naming it, never a silently ignored key that returns "no fields to edit"
    # and leaves the operator guessing which half of their body landed.
    model_config = ConfigDict(extra="forbid")

    title: Optional[str] = None
    description: Optional[str] = None
    priority: Optional[str] = None
    targetRole: Optional[str] = None
    roleSequence: Optional[list] = None
    acceptanceCriteria: Optional[list] = None
    dependsOn: Optional[list] = None
    targetRepo: Optional[str] = None
    timeoutMinutes: Optional[int] = None
    model: Optional[str] = None
    status: Optional[str] = None

    # DELIBERATELY ABSENT, though ``order_create.EDITABLE_FIELDS`` allows them
    # to the CLI: ``voyageId`` and ``voyageBranch``. They are the two fields
    # that STRAND an order when they disagree — ``voyageBranch`` is
    # load-bearing for the whole branch discipline (BUG-ADM-2026-0004; the
    # pretool guard denies any mutation targeting another branch), and setting
    # a ``voyageId`` without the manifest entry that goes with it is the
    # detach-without-skip failure PLAN §5.3 defers item 12 over. Voyage
    # attachment belongs to ``voyage_core.attach_order`` (PLAN Order 5), which
    # writes BOTH sides. Until that lands the Hub does not offer half of it.

    def updates(self) -> dict:
        """The fields the caller actually sent, as ``edit_order`` updates.

        No filtering of values, only of presence — validation belongs to the
        core (one implementation), and a request model that quietly dropped a
        value it disliked would refuse an edit without saying so.
        """
        return self.model_dump(exclude_unset=True)


class OrderEditResult(BaseModel):
    """Response for ``PATCH /orders/{id}``.

    ``changed_fields`` is read back from the order the core WROTE, not from
    the request — PLAN §6.2's backend half: the response reports what landed
    on disk, never what was asked for. An edit whose values all matched the
    existing order returns ``ok=True`` with an empty list, which is the honest
    answer (nothing changed) rather than a manufactured success.

    ``reanchored_role`` names a ``targetRole`` the CORE changed on its own
    initiative — because the edit left the previous one outside the resolved
    ``roleSequence`` — and is empty otherwise. ``changed_fields`` cannot say
    this on its own: it lists ``targetRole`` identically whether the caller
    asked for it or the re-anchor supplied it, and an edit that silently moves
    the role an order starts at is exactly what BUG-MSO-2026-0742 was about.
    """
    ok: bool
    order_id: str
    status: str = ""
    changed_fields: list[str] = Field(default_factory=list)
    reanchored_role: str = ""
    message: str = ""


class OrderSkipRequest(BaseModel):
    """Body for ``POST /orders/{id}/skip`` — an optional operator reason.

    Recorded verbatim in ``config/skipped-orders.json`` alongside the id, the
    same field ``mso order skip --reason`` writes.
    """
    reason: str = ""


class OrderSkipResult(BaseModel):
    """Response for ``POST /orders/{id}/skip`` and ``/unskip``.

    ``skipped`` is the order's state AFTER the call (True after skip, False
    after unskip) — read back from the persisted list, not assumed from the
    verb. ``changed`` says whether this call was the one that moved it: an
    unskip of an order that was never skipped is ``ok=True, changed=False``,
    because refusing an already-correct state as an error would be a lie in
    the other direction.
    """
    ok: bool
    order_id: str
    skipped: bool
    changed: bool = True
    message: str = ""


# ---- Voyage creation (FTR-MSO-2026-0619, PLAN-PLN-MSO-2026-0556 Order 3) ----

class CreateVoyageRequest(BaseModel):
    """Body for ``POST /workspaces/{id}/voyages``.

    NOTE WHAT IS *NOT* HERE, because the absences are the order:

    * **No ``id``.** BUG-MSO-2026-0555's toast named an id the browser had
      computed by regexing ``max()+1`` over the voyages it happened to hold —
      a snapshot that cannot see ``voyages/complete/``, cannot lock, and is
      already stale by one poll interval (PLAN §2.1, refuted outright). The id
      is minted server-side under ``order_ids.lock_for_allocation`` and comes
      back in the response. A field here would be a way to ask for one.
    * **No ``project``.** The acronym is resolved from the workspace's own
      ``config/workspace.json`` (falling back to the registry key, exactly as
      ``aggregator._read_config`` already does for every read model). A
      client-supplied acronym is the same class of defect as a
      client-supplied id: it lets the browser decide which sequence space a
      manifest is minted into.
    * **No ``status``.** Captain decision D3. ``voyage.status`` gates no
      dispatch anywhere in the engine (PLAN §1.1 traced every consumer), so a
      Planned/Active choice changed nothing — a second inert control on the
      button that prompted this plan. Every voyage is created ``PLANNED``,
      byte-identical to what ``mso voyage create`` writes.
    * **No ``branch``.** ``voyage_core._COMPUTED_FIELDS`` contains it: the
      manifest's branch is always ``voyage/{id}``, and since the id is not
      knowable before the call the branch is not either. The dispatcher
      creates that branch on the remote at first crew dispatch
      (``ensure_voyage_branch_exists``) — no git runs here (§3.4 / D4).
    """
    model_config = ConfigDict(extra="forbid")

    title: str
    description: str = ""


class VoyageCreated(BaseModel):
    """Response for ``POST /workspaces/{id}/voyages``.

    Every field is READ BACK FROM THE MANIFEST ON DISK, never echoed from the
    request. That distinction is the whole order: it is the difference between
    "we wrote this" and "we intended to write this", and the latter is
    precisely BUG-MSO-2026-0555. ``voyage_core.create_voyage`` re-reads the
    file it wrote before returning (its own §2.3 rule), and this model carries
    that record outward unchanged.

    ``path`` is included because an operator who is told a voyage exists
    should be able to go and look at it without guessing which of
    ``voyages/active`` or an artefact-repo mount it landed in.
    """
    ok: bool
    workspace_id: str
    voyage_id: str
    title: str = ""
    status: str = ""
    branch: str = ""
    path: str = ""
    message: str = ""


# ---- Order creation (FTR-MSO-2026-0621, PLAN-PLN-MSO-2026-0556 Order 5) ----

class CreateOrderRequest(BaseModel):
    """Body for ``POST /workspaces/{id}/orders``.

    As with :class:`CreateVoyageRequest`, the ABSENCES carry the design:

    * **No ``id``.** ``CreateItemDrawer`` used to render one from
      ``nextId()`` — ``max()+1`` regexed over the orders the browser happened
      to hold, blind to ``orders/complete/``, unlockable, with the year
      hard-coded. Ids are minted server-side under
      ``order_ids.lock_for_allocation`` and returned read back off the file.
    * **No ``project``.** Resolved from the workspace's own config, exactly as
      the voyage endpoint does. A client-chosen acronym picks which sequence
      space a file is minted into.
    * **No ``voyageBranch``.** ``extra="forbid"`` makes sending it a 422. The
      branch is DERIVED from the target voyage's manifest — a ``voyageBranch``
      that disagrees with its voyage is precisely how an order strands
      (BUG-ADM-2026-0004), and letting a browser supply one is the shape of
      that bug with a network hop in front of it.

    ``voyageId`` IS accepted, and is the only field here that causes a second
    write: the endpoint attaches the created order to that voyage's manifest
    via ``voyage_core.attach_order``. An order naming a voyage whose manifest
    does not list it is invisible to that voyage — ``voyages_outstanding_work``
    and the BUG-MSO-2026-0303 completion guard both read the MANIFEST, never
    the order's own claim of membership.
    """
    model_config = ConfigDict(extra="forbid")

    type: str
    title: str
    description: str = ""
    priority: Optional[str] = None
    targetRole: Optional[str] = None
    roleSequence: Optional[list[str]] = None
    acceptanceCriteria: Optional[list[Any]] = None
    dependsOn: Optional[list[str]] = None
    targetRepo: str = ""
    voyageId: str = ""
    #: One of ``order_create.CREATABLE_STATUSES``. Omitted ⇒ PENDING.
    status: Optional[str] = None


class OrderCreated(BaseModel):
    """Response for ``POST /workspaces/{id}/orders``.

    Every field is READ BACK from the order file the server wrote, and
    ``attached``/``voyageOrderIds`` are read back from the MANIFEST after the
    attach — never echoed from the request, and never inferred from "the call
    did not raise". The distinction is the whole plan: BUG-MSO-2026-0555 was a
    response describing an intention.

    ``attached`` is reported separately from ``ok`` because they answer
    different questions. ``ok`` means the order exists; ``attached`` means its
    voyage can see it.
    """
    ok: bool
    workspace_id: str
    order_id: str
    type: str = ""
    title: str = ""
    status: str = ""
    priority: str = ""
    targetRole: str = ""
    roleSequence: list[str] = Field(default_factory=list)
    voyageId: str = ""
    voyageBranch: str = ""
    #: True when this order is now in its voyage's ``orders[]``. False when no
    #: voyage was named — never True on the strength of the call not raising.
    attached: bool = False
    voyageOrderIds: list[str] = Field(default_factory=list)
    #: Where the order JSON actually landed, so "it exists" is checkable.
    path: str = ""
    message: str = ""


class OrderTypeDefault(BaseModel):
    """One order type, with what creating it would default to.

    Served by ``GET /workspaces/{id}/order-defaults`` and resolved through the
    same ``order_create`` functions ``create_order`` itself calls, so a picker
    built on this cannot offer something the create path refuses.
    """
    type: str
    roleSequence: list[str] = Field(default_factory=list)
    priority: str = ""
    queue: str = ""
    #: ``"template"`` when a division pack's order template supplied the
    #: sequence, else ``"builtin"``.
    source: str = "builtin"


class OrderDefaults(BaseModel):
    """Response for ``GET /workspaces/{id}/order-defaults``.

    A READ endpoint, and deliberately not tier-gated: a licence gates ACTING,
    never READING — the position ``GET .../lead`` already takes. Refusing to
    describe the vocabulary would leave a frontend with no honest choice but
    to hard-code its own copy, which is the drift PLAN §5.4 exists to prevent.
    """
    workspace_id: str
    project: str = ""
    types: list[OrderTypeDefault] = Field(default_factory=list)
    #: Every dispatchable canonical role — the constrained role picker's
    #: vocabulary (``LEAD`` is excluded: it is never dispatched).
    roles: list[str] = Field(default_factory=list)
    priorities: list[str] = Field(default_factory=list)
    #: ``order_create.CREATABLE_STATUSES``, sorted.
    statuses: list[str] = Field(default_factory=list)
    defaultStatus: str = ""


class ControlResult(BaseModel):
    """Result of a workspace dispatch/stop control action (Feature B)."""
    ok: bool
    workspace_id: str
    action: str = ""   # 'dispatch' | 'stop'
    message: str = ""


class RunResult(BaseModel):
    """Result of ``POST .../lead/findings/{fingerprint}/run`` (FTR-MSO-2026-0631).

    Mirrors ``ControlResult``'s ``ok``/``action``/``message`` shape rather than
    inventing an unrelated one. ``outcome`` is the honest three-way verdict the
    order requires — never an optimistic success:

      * ``"accepted"`` — the mapped verb ran and its underlying call succeeded.
      * ``"refused"``  — never attempted: blocked by the D6 must_not ceiling,
                          a licence-tier gate, a deployment capability gate
                          (e.g. sweep needs `gh`, which this Hub lacks), or
                          (BUG-MSO-2026-0662 F1) a PRE-flight re-check of the
                          finding's own condition that could not confirm it
                          — or confirmed it no longer holds.
      * ``"failed"``   — attempted, but the underlying call raised or reported
                          a business refusal (e.g. `RetryRefused`).

    ``conditionCleared``/``stillOpen`` normally report the POST-action
    RE-EVALUATION verdict, not the action's own success — reusing
    ``maestro.patrol.run_single_check`` to re-run ONLY the check that
    produced the finding (never a full LEAD tick — BUG-MSO-2026-0634 F1/F2)
    rather than optimistically assuming an accepted action fixed anything.
    Re-evaluation only runs after an "accepted" outcome; a "failed" run
    leaves `stillOpen=True` without spending one (nothing changed). The one
    exception is a "refused" outcome caused by BUG-MSO-2026-0662 F1's
    PRE-flight check itself finding the condition already cleared — that
    refusal DOES carry `conditionCleared=True`/`stillOpen=False`/
    `verified=True`, since a real check genuinely ran and confirmed it
    before anything else happened; every OTHER "refused" reason (D6/licence/
    capability gates, or the pre-check being unable to confirm anything at
    all) leaves `stillOpen=True` exactly as before.

    ``verified`` (BUG-MSO-2026-0634 F2) is the fail-closed half: it is False
    when re-evaluation could not actually confirm anything (an unknown/
    disabled/raising check) — in that case `conditionCleared` is always False
    and `stillOpen` is always True regardless of what the check last said,
    and the frontend renders a distinct "ran, could not confirm" tone rather
    than the optimistic "condition cleared" a swallowed failure used to imply.
    """
    ok: bool
    action: str = ""            # verb id, e.g. "order.retry"
    outcome: str = "failed"     # "accepted" | "refused" | "failed"
    message: str = ""
    conditionCleared: bool = False
    stillOpen: bool = True
    verified: bool = False


class SweepEntry(BaseModel):
    """One housekeeping decision — what was done, or refused, and why.

    FTR-MSO-2026-0426. Mirrors an entry produced by
    ``fleet_runner._sweep_note``.
    """
    voyage: str = ""
    action: str = ""      # archived | annotated | linked | skipped | flagged
    reason: str = ""
    prNumber: Optional[int] = None
    mergedAt: Optional[str] = None
    order: Optional[str] = None
    orderStatus: Optional[str] = None
    repos: Optional[list[str]] = None


class SweepResult(BaseModel):
    """Result of a workspace housekeeping sweep (FTR-MSO-2026-0426).

    Carries the same report ``mso voyage reconcile --json`` prints, so the Hub
    button and the CLI surface identical results.
    """
    ok: bool
    workspace_id: str
    action: str = "sweep"
    message: str = ""
    dryRun: bool = False
    archived: int = 0
    annotated: int = 0
    changes: list[SweepEntry] = Field(default_factory=list)
    refusals: list[SweepEntry] = Field(default_factory=list)


# ---- Capabilities (FTR-MSO-2026-0489) ---------------------------------------

# The authoring surface's "not yet available" reasons live HERE, not in
# server.py, so that the CapabilityMap field defaults below can carry them
# (FTR-MSO-2026-0617). server.py imports these names and re-exports them, so
# every existing reference keeps working and there remains exactly one string
# per action. Putting them in server.py and defaulting `reason=None` would have
# left the zero-configuration posture saying "unavailable" with no "why" — the
# precise half-truth this order exists to remove.
# FTR-MSO-2026-0619 (PLAN Order 3) shipped
# `POST /workspaces/{id}/voyages`, so this string stopped meaning "not yet
# built" and now means "not available HERE" — the fallback a deployment that
# cannot write the plane (and the zero-config default below) still needs. Same
# treatment FTR-MSO-2026-0622 gave the two below, for the same reason: the name
# is unchanged so every existing import keeps resolving, and the word "yet" is
# gone because telling an operator to wait for a feature that shipped is the
# same class of false statement this plan exists to remove, just inverted.
VOYAGE_CREATE_UNAVAILABLE_MESSAGE = (
    "Creating a voyage is unavailable from this Hub deployment — run "
    "`mso voyage create \"<title>\" --project <ACR>` from a host session."
)
# FTR-MSO-2026-0621 (PLAN Order 5) shipped `POST /workspaces/{id}/orders`, so
# this string stopped meaning "not yet built" and now means "not available
# HERE" — the fallback a deployment that cannot write the plane (and the
# zero-config default below) still needs. Same treatment, and for the same
# reason, as the three siblings: the name is unchanged so every existing import
# keeps resolving, and the word "yet" is gone because telling an operator to
# wait for a feature that shipped is the same class of false statement this
# plan exists to remove, just inverted. With this one the set is complete —
# all four authoring actions now back real endpoints.
ORDER_CREATE_UNAVAILABLE_MESSAGE = (
    "Creating an order is unavailable from this Hub deployment — run "
    "`mso order create \"<title>\" --type FTR --project <ACR>` (or "
    "`mso bug \"<description>\"`) from a host session."
)
# FTR-MSO-2026-0622 (PLAN Order 6) shipped the endpoints these two describe,
# so they stopped meaning "not yet built" and now mean "not available HERE" —
# the fallback a deployment that cannot write the plane (and the zero-config
# default below) still needs. The names are unchanged: one string per action,
# one home, and every existing import keeps resolving. The word "yet" is gone
# deliberately — telling an operator to wait for a feature that shipped is the
# same class of false statement this plan exists to remove, just inverted.
ORDER_EDIT_UNAVAILABLE_MESSAGE = (
    "Editing an order is unavailable from this Hub deployment — edit the "
    "order's JSON under `queues/` from a host session."
)
ORDER_SKIP_UNAVAILABLE_MESSAGE = (
    "Skipping an order is unavailable from this Hub deployment — run "
    "`mso order skip <ORDER-ID>` from a host session."
)


class CapabilityInfo(BaseModel):
    """Whether one mutating action is available in THIS deployment, and why not.

    PLAN-PLN-MSO-2026-0468 §4.5 / BUG-MSO-2026-0440: the reason a caller cannot
    act is declared here, before any click, so the frontend renders a disabled
    control with its reason instead of discovering a 409 after the fact.
    ``reason`` is populated only when ``available`` is False and is always the
    same server-side constant the corresponding endpoint's 409 uses.
    """
    available: bool = True
    reason: Optional[str] = None


class TierCapability(BaseModel):
    """Licence-tier gate shared by every mutating control action.

    Distinct from ``CapabilityInfo`` above: a deployment can be fully CAPABLE
    of an action (e.g. dispatch on a host session) and still be refused it for
    lacking a Team/Enterprise licence — two independent reasons to disable a
    button, both declared up front.
    """
    control: bool = False
    reason: Optional[str] = None


class CapabilityMap(BaseModel):
    """Response for ``GET /api/v1/capabilities`` — poller-independent, cheap.

    Declares, up front, which mutating actions this Hub deployment can
    actually perform, so the frontend disables a button WITH ITS REASON
    before the click rather than rendering it enabled-and-hopeful.
    """
    dispatch: CapabilityInfo = Field(default_factory=CapabilityInfo)
    sweep: CapabilityInfo = Field(default_factory=CapabilityInfo)
    review: CapabilityInfo = Field(default_factory=CapabilityInfo)
    orderRetry: CapabilityInfo = Field(default_factory=CapabilityInfo)

    # ---- Authoring surface (FTR-MSO-2026-0617, PLAN-PLN-MSO-2026-0556 §4.3) --
    #
    # These four declare the AUTHORING actions the Hub does not yet perform.
    # Unlike every field above, they default to ``available=False`` — an
    # authoring control has no backing endpoint until this plan's Orders 3/5/6
    # land, and the whole point of BUG-MSO-2026-0555 is that a control with no
    # endpoint must never render enabled. The default here is what makes the
    # honest posture the ZERO-CONFIGURATION one: a field that is never
    # populated reports "unavailable, and here is why", not "go ahead".
    #
    # When the endpoint lands, the server flips ``available`` to True in
    # ``get_capabilities()`` and NO frontend change is required (§7) — the
    # button already consumes this field through the LOADING_REASON path.
    # FTR-MSO-2026-0622 note: orderEdit and orderSkip now HAVE endpoints
    # (PLAN Order 6), and get_capabilities() reports them available on a
    # writable plane. Their DEFAULT here stays False on purpose — the default
    # answers "what does a map nobody populated claim?", and the safe answer
    # to that never changes with what shipped.
    voyageCreate: CapabilityInfo = Field(
        default_factory=lambda: CapabilityInfo(
            available=False, reason=VOYAGE_CREATE_UNAVAILABLE_MESSAGE))
    orderCreate: CapabilityInfo = Field(
        default_factory=lambda: CapabilityInfo(
            available=False, reason=ORDER_CREATE_UNAVAILABLE_MESSAGE))
    orderEdit: CapabilityInfo = Field(
        default_factory=lambda: CapabilityInfo(
            available=False, reason=ORDER_EDIT_UNAVAILABLE_MESSAGE))
    orderSkip: CapabilityInfo = Field(
        default_factory=lambda: CapabilityInfo(
            available=False, reason=ORDER_SKIP_UNAVAILABLE_MESSAGE))

    tier: TierCapability = Field(default_factory=TierCapability)


# ---- Blockage (FTR-MSO-2026-0721, PLAN-FTR-MSO-2026-0700 §5.2) --------------
#
# These models mirror ``maestro.core.blockage``'s ``to_dict()`` EXACTLY, field
# for field and name for name, so an endpoint can be written as
# ``BlockageResponse(blocked=True, **blockage.to_dict())`` rather than by
# re-listing the shape here. That is deliberate: a hand-copied wire shape is a
# second definition of the model that drifts from the first, which is the
# whole failure PLAN-FTR-MSO-2026-0700 exists to remove one level up.

class EvidenceModel(BaseModel):
    """One artefact that PROVES the cause — ``blockage.Evidence.to_dict()``.

    ``detail`` is passed through untouched: an unmeasurable diff-stat arrives
    here as ``"diff-stat unknown"`` and must be rendered as that, never
    normalised to ``"0 files"`` (BUG-MSO-2026-0696's honesty rule).
    ``artefactKey``, when non-empty, is a key
    ``GET /orders/{id}/artefacts/{key}`` will serve.
    """
    kind: str = ""
    label: str = ""
    path: str = ""
    branch: str = ""
    detail: str = ""
    artefactKey: str = ""


class OptionModel(BaseModel):
    """One thing the operator can do — ``blockage.Option.to_dict()`` plus the
    server's capability resolution.

    ``available`` / ``unavailableReason`` are NOT on the core dataclass: the
    core has no idea which deployment it is being rendered in. The server
    stamps them from the same values ``GET /api/v1/capabilities`` reports, so
    the reason shown before the click is the sentence the endpoint's 403/409
    would raise after it (FTR-MSO-2026-0617's honesty rule, PLAN §5.2).

    An option with an empty ``hubAction`` is CLI-only. It is reported
    ``available: true`` — the command is real and an operator can run it in a
    terminal; it simply has no button. Reporting it unavailable would be a
    lie about a working remedy.
    """
    label: str = ""
    command: str = ""
    hubAction: str = ""
    hubMethod: str = ""
    hubPath: str = ""
    capability: str = ""
    riskNote: str = ""
    recommended: bool = False
    available: bool = True
    unavailableReason: Optional[str] = None


class BlockerRefModel(BaseModel):
    """An order the subject waits on, carrying its OWN diagnosis —
    ``blockage.BlockerRef.to_dict()``."""
    orderId: str = ""
    status: str = ""
    kind: str = ""
    cause: str = ""


class BlockageResponse(BaseModel):
    """``GET /orders/{id}/blockage`` and ``GET /voyages/{id}/blockage``.

    ``blocked`` is the only field this adds to ``Blockage.to_dict()``. When it
    is False the subject is fine and every other field stays at its default —
    a "nothing is wrong" answer is a successful answer, not a 404 and not an
    empty body the caller has to guess at (PLAN §5.1's rule for the CLI verb,
    applied to the wire).
    """
    blocked: bool = False
    subjectId: str = ""
    subjectKind: str = ""
    kind: str = ""
    cause: str = ""
    since: str = ""
    severity: str = ""
    detail: str = ""
    title: str = ""
    summary: str = ""
    suggestedCommand: str = ""
    evidence: list[EvidenceModel] = Field(default_factory=list)
    blockers: list[BlockerRefModel] = Field(default_factory=list)
    options: list[OptionModel] = Field(default_factory=list)
    voyageId: str = ""
    role: str = ""
    progressing: bool = False
    workspace_id: str = ""


# ---- LEAD sub-agent (FTR-MSO-2026-0539, PLAN-PLN-MSO-2026-0504 §13) --------

class LeadFindingsBySeverity(BaseModel):
    """Open patrol findings for this workspace, tallied by severity.

    Sourced from the LEAD daemon's own persisted state (written once per
    heartbeat tick by ``maestro.lead.agent.run_once`` — the daemon is the
    only place ``mso doctor`` actually runs, per PLAN-PLN-MSO-2026-0504 §6's
    noise-control design), never re-derived by the Hub itself.
    """
    critical: int = 0
    high: int = 0
    medium: int = 0
    low: int = 0


class LeadAction(BaseModel):
    """Most recent ``LEAD_ACTION`` lifecycle event, if any.

    PLAN-PLN-MSO-2026-0504 §3.4 defines the act-and-inform band;
    PLAN-PLN-MSO-2026-0584 Dimension C (the finding-to-action mapping in
    ``maestro.lead.bands.dispatch_actions_for_findings``, wired into
    ``agent.run_once``) is what actually calls ``execute_action`` and
    produces ``LEAD_ACTION`` events in production. ``lastAction`` still
    resolves to ``None`` for a workspace whose daemon has never had a
    NEW/ESCALATED finding mapped to a D7 action — that is a correct "nothing
    to act on yet", not a missing wire-up.
    """
    type: str = ""
    detail: str = ""
    at: str = ""


class LeadStatus(BaseModel):
    """``GET /api/v1/workspaces/{id}/lead`` — PLAN-PLN-MSO-2026-0504 §13.

    ``available``/``reason`` mirror ``TierCapability``'s shape rather than a
    plain 403: a card pip and a workspace-detail strip both need SOMETHING
    to render for a community/non-Pro workspace (greyed, with ``reason`` as
    the upgrade affordance) — a raised HTTP exception gives neither surface
    anything to work with, matching the ``GET /api/v1/capabilities`` pattern
    at ``hub/server.py`` (declare availability up front, never a post-hoc
    403 as the only signal).
    """
    available: bool = False
    reason: Optional[str] = None
    state: str = "stopped"  # "running" | "stopped"
    # BUG-MSO-2026-0541 / PLAN-PLN-MSO-2026-0504 §4.1's lesson: a dead
    # dispatcher hid behind a boolean liveness flag for three ticks. Exposed
    # here as a NUMBER (seconds), never a boolean, for the same reason —
    # None only when the daemon has never completed a single tick.
    heartbeatAgeSeconds: Optional[float] = None
    findings: LeadFindingsBySeverity = Field(default_factory=LeadFindingsBySeverity)
    lastAction: Optional[LeadAction] = None
    # PLAN-PLN-MSO-2026-0584 Dimension A: extends (never replaces) the
    # states above — `state` stays exactly "running"/"stopped"; `standDown`
    # is an ORTHOGONAL fact so a stood-down daemon (state="running",
    # standDown=True — a live process deliberately doing no work) never
    # renders identically to a dead one (state="stopped"). Read from the
    # durable `lead.standDown` config, not state.json, so a toggle is
    # reflected immediately rather than after the daemon's next tick.
    standDown: bool = False
    # RC-5: the version the RUNNING daemon is actually executing (pinned at
    # process start — a `pip install` mid-run never reaches it), vs. the
    # version THIS Hub backend has installed right now. `versionMismatch`
    # is the pre-computed comparison so the frontend never has to string-
    # compare two optional fields itself.
    #
    # BUG-MSO-2026-0724: `runningVersion` and `versionMismatch` are now
    # `None`/`False` whenever `state != "running"` — a stopped daemon runs no
    # version, and the strip rendering "Running stale code (v5.12.1)" over a
    # STOPPED pill is what hid the 2026-09-10 PSG daemon death. What the last
    # tick wrote survives under `lastRanVersion`, which is populated whether
    # or not the daemon is up, so the strip can say "stopped — last ran
    # v5.12.1" instead.
    runningVersion: Optional[str] = None
    lastRanVersion: Optional[str] = None
    installedVersion: Optional[str] = None
    versionMismatch: bool = False


class LeadFindingDetail(BaseModel):
    """One persisted LEAD patrol finding (FTR-MSO-2026-0577).

    Mirrors the bounded shape ``maestro.lead.agent.run_once()`` persists into
    ``lastFindingsDetail`` in ``.mso/lead/state.json`` — the SAME tick
    ``LeadStatus.findings``'s counts were computed from (see ``LeadDetail``
    below for why that matters). ``title``/``detail``/``suggestedCommand``
    are redacted via ``maestro.hooks.secret_patterns.redact_text`` before
    this model is constructed.
    """
    checkId: str = ""
    subjectId: str = ""
    severity: str = "low"
    title: str = ""
    detail: str = ""
    firstSeenAt: str = ""
    suggestedCommand: Optional[str] = None
    scope: str = "workspace"
    # PLAN-PLN-MSO-2026-0584 Dimension D: the stable fingerprint the drawer's
    # ack/unack controls target — never derived client-side (it depends on
    # the check's fixed BASE severity, which the client never sees; only the
    # server, via maestro.patrol.state.fingerprint(), computes it correctly).
    fingerprint: Optional[str] = None
    # True only for a LIVE, unpierced acknowledgement (expiry + escalation-
    # pierce already applied server-side — maestro.patrol.state.is_acknowledged).
    # Suppresses delivery only; this finding is still counted in
    # LeadStatus.findings and still listed here regardless of this flag
    # (count-preserving suppression, PLAN Dimension D guard 3).
    acknowledged: bool = False
    acknowledgedBy: Optional[str] = None
    acknowledgedNote: Optional[str] = None
    acknowledgedExpiresAt: Optional[str] = None
    # FTR-MSO-2026-0631: computed server-side from the RAW (pre-redaction)
    # suggestedCommand via maestro.lead.run_verbs.parse_verb() — the closed
    # verb list lives entirely server-side, so the client never has to guess
    # whether a command is runnable. `runVerb` names which verb matched
    # (e.g. "order.retry") so the drawer can pick the right CapabilityInfo
    # from GET /api/v1/capabilities before rendering Run as enabled; `None`
    # whenever `runnable` is False.
    runnable: bool = False
    runVerb: Optional[str] = None


class LeadAuditEvent(BaseModel):
    """One LEAD-related lifecycle.log line, parsed via
    ``maestro.hub.lifecycle_tail`` — no second log parser.

    ``type`` is one of LEAD_TICK / LEAD_ACTION / LEAD_FINDING / LEAD_REPORTED
    / LEAD_CEILING_HIT.
    """
    type: str = ""
    message: str = ""
    at: str = ""


class LeadDetail(BaseModel):
    """``GET /api/v1/workspaces/{id}/lead/detail`` — FTR-MSO-2026-0577.

    ``available``/``reason`` mirror ``LeadStatus``'s shape (never a bare
    403), for the same reason: a drawer for a community/non-Pro workspace
    still needs something to render (greyed, with ``reason`` as the upgrade
    affordance).

    ``findings`` is read from the SAME persisted tick ``LeadStatus.findings``
    is computed from — never a fresh ``mso doctor`` pass triggered by opening
    the drawer. Running the patrol on drawer-open would let the drawer show
    (say) 17 findings under a strip that still says 19 from its last poll,
    with no explanation for the mismatch — worse than showing nothing,
    because it teaches the operator the numbers can't be trusted. One tick,
    one set of findings, one source, both surfaces.

    ``hasTicked``/``lastTickAt`` let a never-ticked daemon and a stopped one
    both render as an honest "here is what I know", not an empty list that
    reads as "nothing found" and not a spinner that never resolves.
    """
    available: bool = False
    reason: Optional[str] = None
    state: str = "stopped"  # "running" | "stopped"
    hasTicked: bool = False
    lastTickAt: Optional[str] = None
    findings: list[LeadFindingDetail] = Field(default_factory=list)
    # True total findings this tick found, and whether `findings` above (capped
    # at maestro.lead.agent.MAX_PERSISTED_FINDINGS) is a subset of it — lets
    # the drawer say "showing X of Y" instead of implying X is everything.
    findingsTotal: int = 0
    findingsTruncated: bool = False
    auditTail: list[LeadAuditEvent] = Field(default_factory=list)


class LeadPip(BaseModel):
    """Lightweight LEAD indicator embedded in ``WorkspaceSummary`` for the
    overview page's per-card pip (PLAN §13: "so one glance covers every
    fleet"). Deliberately NOT a full ``LeadStatus`` — the overview page
    polls every registered workspace on a short interval, so this carries
    only what the pip renders, sourced from the same cheap daemon-state read
    as ``LeadStatus`` (never a fresh patrol pass per card, per tick).
    """
    available: bool = False
    state: str = "stopped"  # "running" | "stopped"
    findings: LeadFindingsBySeverity = Field(default_factory=LeadFindingsBySeverity)


# ---- Charts (FTR-MSO-2026-0496, PLAN-VOY-MSO-2026-0143 Phase 1 part 2) ------
# Field names mirror maestro.core.charts.Waypoint/Leg/Chart.to_dict() exactly
# (the same shape `mso chart show --format json` prints) so the CLI and the
# Hub's read-only graph view can never disagree about the wire format.

class ChartWaypoint(BaseModel):
    """One compiled chart node — matches Waypoint.to_dict()."""
    order: str
    role: str
    state: str = "NOT_STARTED"
    humanGate: bool = False


class ChartLeg(BaseModel):
    """One compiled chart edge — matches Leg.to_dict(). ``from`` is a Python
    keyword, so the field is named ``from_`` with an alias; construct via
    ``ChartLeg(**leg.to_dict())`` (dict key ``"from"`` resolves via the alias)."""
    model_config = {"populate_by_name": True}

    from_: str = Field(alias="from")
    to: str
    type: str
    humanGate: bool = False


class ChartResponse(BaseModel):
    """A compiled voyage or order chart — matches Chart.to_dict()."""
    chartId: str
    voyage: str = ""
    nodes: dict[str, ChartWaypoint] = Field(default_factory=dict)
    edges: list[ChartLeg] = Field(default_factory=list)


# ---- Usage aggregation (FTR-MSO-2026-0333) ----------------------------------

class UsageBucket(BaseModel):
    """A single bucket in a grouped usage rollup.

    Matches the frontend UsageBucket interface in app/types/index.ts.
    """
    key: str                    # project_id / voyage_id / order_id / role code
    label: str = ""             # human-readable label (same as key when not set)
    total_tokens: int = 0
    estimated_cost_usd: float = 0.0
    order_count: int = 0        # number of distinct orders contributing to this bucket


class UsageSeriesPoint(BaseModel):
    """One point in a date-keyed time series.

    Matches the frontend UsageSeriesPoint interface in app/types/index.ts.
    Extends UsagePoint semantics but kept separate so UsagePoint (workspace
    sparkline) stays backward-compatible.
    """
    date: str           # YYYY-MM-DD
    tokens: int = 0
    cost_usd: float = 0.0


class UsageRollup(BaseModel):
    """Top-level response for grouped usage aggregation endpoints.

    Matches the frontend UsageRollup interface in app/types/index.ts.
    """
    from_date: Optional[str] = None     # inclusive date filter applied (YYYY-MM-DD)
    to_date: Optional[str] = None       # inclusive date filter applied (YYYY-MM-DD)
    group_by: str = "project"           # 'project' | 'voyage' | 'order' | 'role'
    total_tokens: int = 0
    estimated_cost_usd: float = 0.0
    buckets: list[UsageBucket] = Field(default_factory=list)
    series: list[UsageSeriesPoint] = Field(default_factory=list)  # per-day totals


class ModelUsage(BaseModel):
    """Per-model token breakdown for an order.

    Matches the frontend ModelUsage interface in app/types/index.ts.
    """
    input_tokens: int = 0
    output_tokens: int = 0
    cache_creation_input_tokens: int = 0
    cache_read_input_tokens: int = 0
    message_count: int = 0


class IterationUsage(BaseModel):
    """Usage record for one crew iteration (from per-iteration *.jsonl files).

    Matches the frontend IterationUsage interface in app/types/index.ts.
    """
    iteration: int = 0
    role: str = ""
    crew_number: int = 0
    total_tokens: int = 0
    estimated_cost_usd: float = 0.0
    timestamp: str = ""
    models: dict[str, ModelUsage] = Field(default_factory=dict)


class OrderUsageDetail(BaseModel):
    """Full usage breakdown for a single order (JSON + JSONL combined).

    Matches the frontend OrderUsageDetail interface in app/types/index.ts.
    """
    order_id: str
    voyage_id: Optional[str] = None
    total_tokens: int = 0
    estimated_cost_usd: float = 0.0
    models: dict[str, ModelUsage] = Field(default_factory=dict)
    role_buckets: list[UsageBucket] = Field(default_factory=list)   # from JSONL (empty if absent)
    iterations: list[IterationUsage] = Field(default_factory=list)  # from JSONL (empty if absent)
    timestamp: Optional[str] = None


# ---- Reports (FTR-MSO-2026-0729, PLAN-PLN-MSO-2026-0726 §5 Order A2) --------
# The wire shape for `maestro.reports`' framework-agnostic records.
#
# Every field name below mirrors the corresponding dataclass `to_dict()` key in
# `maestro/reports/models.py` EXACTLY, so a response is built as
# `QAReportModel(**summary.to_dict())` and the two shapes cannot drift: there is
# no hand-written field mapping to fall out of date. That direction is
# deliberate and is the plan's "one core model, many surfaces" rule (§4) — the
# core dataclasses know nothing about Pydantic, and the Hub adapts to them.
#
# These keys are camelCase, unlike the snake_case usage models above, because
# they mirror the core `to_dict()` rather than a hand-written TS interface. The
# same precedent already exists in this module for ChartWaypoint/ChartLeg, which
# mirror `maestro.core.charts`' own `to_dict()`.
#
# THE HONESTY RULE (plan §7) is structural here, not a convention:
#   * every count is Optional — `tests: None` ("no parseable count") is a
#     different claim from `tests: 0` ("the fleet ran no tests"), and a model
#     that defaulted them to 0 would erase that distinction on the wire;
#   * `verdict` carries UNDETERMINED and `status` carries NOT RECORDED as
#     first-class values (Captain decisions D3/D4) — never folded into a pass;
#   * `parseNotes` travels with every record so a surface can caveat what could
#     not be read instead of presenting a partial parse as a complete one.

class ParseCoverageModel(BaseModel):
    """How much of a report set actually parsed — the D3 parser-drift alarm.

    `undetermined` is reported as its own figure and is never subtracted away:
    a heading-contract drift shows up as a falling `parsed` against a steady
    `total`, which is exactly the signal a silent parser degradation otherwise
    hides. Mirrors `maestro.reports.models.ParseCoverage.to_dict()`.
    """
    total: int = 0
    parsed: int = 0
    undetermined: int = 0


class QAACRowModel(BaseModel):
    """One row of a QA report's `## Acceptance Criteria Verification` table.

    Mirrors `ACCriterionRow.to_dict()`. `met` is carried explicitly rather than
    left for a client to derive from `status`, so no surface can reinvent the
    D4 rule ("only an affirmative recorded PASS is met") and get it wrong.
    """
    id: str = ""
    criterion: str = ""
    status: str = "NOT RECORDED"
    rawStatus: str = ""
    validation: str = ""
    notes: str = ""
    evidence: str = ""
    provenance: str = "not recorded"
    met: bool = False


class QADefectModel(BaseModel):
    """One row of `## Defects Found` — mirrors `role_rejection.Defect.to_dict()`.

    Field names are that dataclass's verbatim, so the Hub's defect shape and the
    dispatcher's own lap-routing defect shape can never diverge.
    """
    id: str = ""
    severity: str = ""
    summary: str = ""
    file: str = ""
    line: str = ""
    blocking: bool = False


class QATestCategoryModel(BaseModel):
    """One `### <category> Tests` subsection's counts. All figures Optional."""
    name: str = ""
    tests: Optional[int] = None
    passed: Optional[int] = None
    failed: Optional[int] = None


class QATestCountsModel(BaseModel):
    """A report's `## Test Summary` rollup — mirrors `TestCounts.to_dict()`.

    `recorded` says whether ANY figure was parseable, so a client can render
    "not recorded" without having to test three Optionals itself.
    """
    tests: Optional[int] = None
    passed: Optional[int] = None
    failed: Optional[int] = None
    recorded: bool = False
    categories: list[QATestCategoryModel] = Field(default_factory=list)


class QAReportModel(BaseModel):
    """One QA report's machine-readable record — mirrors `QAReportSummary.to_dict()`.

    `reportRel` is relative to the artefact root and `reportName` is a bare
    filename: neither is ever an absolute path, because an absolute path on a
    wire response leaks the operator's filesystem layout (the same rule the
    artefact routes already follow).

    `nodeVerdict` is a CORROBORATING HINT ONLY (Captain decision D3) — the
    dispatcher rewrites that front-matter field to CONSUMED once routing acts on
    it, so it is a routing token with a lifecycle, not a report field.
    `nodeVerdictCorroborates` is tri-state (`None` = nothing to compare), so a
    surface can flag a disagreement rather than silently preferring one source.
    """
    orderId: str
    verdict: str = "UNDETERMINED"
    rawVerdict: str = ""
    verdictSource: str = ""
    nodeVerdict: Optional[str] = None
    nodeVerdictCorroborates: Optional[bool] = None
    decided: bool = False
    acRows: list[QAACRowModel] = Field(default_factory=list)
    acMet: int = 0
    acNotRecorded: int = 0
    defects: list[QADefectModel] = Field(default_factory=list)
    blockingDefectCount: int = 0
    testCounts: QATestCountsModel = Field(default_factory=QATestCountsModel)
    reportName: str = ""
    reportRel: str = ""
    modified: str = ""
    size: int = 0
    truncated: bool = False
    parseNotes: list[str] = Field(default_factory=list)
    #: Which registered workspace this report was read from. Added by the Hub
    #: (the core record is workspace-agnostic), so a cross-workspace list stays
    #: attributable row by row.
    workspaceId: str = ""


class QAReportList(BaseModel):
    """`GET /api/v1/reports/qa` — a bounded list plus its parse coverage.

    `limit` / `returned` / `available` are all reported because a truncated list
    that did not say so would be indistinguishable from a complete one:
    `available` is how many QA reports the scanned workspaces actually hold,
    `returned` is how many are in this response.

    `coverage` describes exactly the records in `reports` — never a larger set
    the caller did not receive.
    """
    reports: list[QAReportModel] = Field(default_factory=list)
    parseCoverage: ParseCoverageModel = Field(default_factory=ParseCoverageModel)
    workspaceId: Optional[str] = None   # the filter applied, when one was
    limit: int = 0
    returned: int = 0
    available: int = 0
    #: Workspaces that were scanned for this response, so a caller can tell an
    #: empty list caused by "nothing registered" from one caused by a filter.
    workspaces: list[str] = Field(default_factory=list)
