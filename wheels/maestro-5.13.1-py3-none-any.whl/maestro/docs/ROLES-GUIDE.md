# Roles Guide

Maestro assigns each unit of work to a **role**. The role determines which Claude model runs, what files the crew can read and write, and what commands it can execute.

Understanding roles helps you assign orders correctly and get consistent, high-quality output from your fleet.

---

## Contents

- [Role Overview](#role-overview)
- [Customising for your organisation](#customising-for-your-organisation)
- [Navigator / Planner (NAV / PLN)](#navigator-nav)
- [Shipwright / Builder (SHP / BLD)](#shipwright-shp)
- [Bosun / Tester (BOS / TST)](#bosun-bos)
- [Scribe / Documenter (SCR / DOC)](#scribe-scr)
- [Lookout / Security Auditor (LKT / SEC)](#lookout-lkt)
- [Coxswain / Releaser (COX / REL)](#coxswain-cox)
- [Choosing the Right Role](#choosing-the-right-role)
- [Role Handoffs](#role-handoffs)

---

## Role Overview

| Role | Canonical code | Nautical alias | Default model | Responsibility |
|------|---------------|---------------|---------------|---------------|
| Planner | PLN | NAV (Navigator) | Opus 5 | Planning & architecture |
| Builder | BLD | SHP (Shipwright) | Sonnet 5 | Development & implementation |
| Tester | TST | BOS (Bosun) | Sonnet 5 | QA & testing |
| Documenter | DOC | SCR (Scribe) | Sonnet 5 | Documentation |
| Security Auditor | SEC | LKT (Lookout) | Haiku 4.5 | Security & investigation |
| Releaser | REL | COX (Coxswain) | Opus 5 | Integration & deployment |

Both the canonical codes (`PLN`, `BLD`, `TST`, `DOC`, `SEC`, `REL`) and the nautical aliases (`NAV`, `SHP`, `BOS`, `SCR`, `LKT`, `COX`) are accepted wherever a role code is used.

**Model rationale:** high-stakes × low-volume gets Opus. The Planner and Releaser run on Opus 5 — they run infrequently, but a plan or a release decision propagates to everything downstream. Sonnet 5 handles the high-volume production roles (BLD, TST, DOC). Haiku 4.5 is used for Security Auditor tasks, which are read-only review where the cheapest tier suffices.

**Available models:** Fable 5.1, Fable 5, Opus 5, Sonnet 5 and Haiku 4.5, plus the previous generation, still supported (Opus 4.8, Opus 4.7, Opus 4.6, Sonnet 4.6). Every role's model is a default, not a fixed assignment — override it per order (the order's `model` field) or per role (a role overlay); see [CONFIG-MODELS.md](CONFIG-MODELS.md).

**Community tier:** dispatching an order is limited to Investigator, Planner, Builder and Tester (`INV`/`PLN`/`BLD`/`TST`). Documenter, Security Auditor and Releaser (`DOC`/`SEC`/`REL`) require a Pro, Team or Enterprise licence — an order whose role sequence includes one of these is refused with a licence message naming the tier, before any crew work is spent on it. See [LICENCE.md](LICENCE.md#tier-limits-enforced-in-code-not-just-advertised) for the full set of enforced tier limits.

---

## Customising for your organisation

All 7 roles can be customised per-organisation without forking the core definitions. See [ROLE-OVERLAYS.md](ROLE-OVERLAYS.md) for the full guide.

Quick reference:

- `mso roles list` — see all roles and which have overlays applied
- `mso roles show TST` — see the effective merged config for a role
- Edit `.mso/config/roles/{CODE}.md` to layer org-specific extensions
- `mso roles validate` to check your overlay parses correctly
- `mso roles diff TST` to preview exactly what your overlay changed

---

## Navigator (NAV)

**What it does:** The Navigator analyses the codebase and order requirements, then produces a structured implementation plan. It does not write production code — its output is a plan document that guides the Shipwright.

**When to use it:** Before any significant development order. Use a NAV order when:

- The implementation path is not obvious
- Multiple approaches are possible and trade-offs need documenting
- You want the Shipwright to follow a pre-approved plan rather than improvise
- The order spans multiple files or subsystems

**What it reads:** Full codebase, active orders, existing plans, requirements

**What it writes:** Plan documents (`.maestro/plans/`), handoff documents (`.maestro/handoffs/{ORDER-ID}/`)

**What it cannot write:** Source code, tests, documentation files, production directories

**Example order types:** `DOC-MYPROJ-2026-0001` with `"role": "NAV"` to plan a feature before implementation

---

## Shipwright (SHP)

**What it does:** The Shipwright implements the production code. It reads the Navigator's plan (if one exists) or works directly from the order description, then writes source code.

**When to use it:** Any order that involves writing or modifying production source code — new features, bug fixes, refactoring.

**What it reads:** Navigator handoffs and plans, source code, documentation, solution/project files

**What it writes:** Production source code

**What it cannot write:** Test files, documentation, plans, reports

**Example order types:** `FTR-MYPROJ-2026-0001` with `"role": "SHP"` to implement a new feature

---

## Bosun (BOS)

**What it does:** The Bosun writes and runs tests to verify that the Shipwright's code meets the order's acceptance criteria. It reads the implementation and produces test coverage.

**When to use it:** After a Shipwright order, when the order requires test coverage. You can also use the Bosun for standalone testing work — adding missing coverage to existing features, or writing regression tests for known issues.

**What it reads:** Shipwright handoffs, source code, existing tests, solution files

**What it writes:** Test code (in the project's `tests/` directory), QA reports

**What it cannot write:** Production source code, documentation, plans

**Commands it runs:** Build and test commands (e.g. `dotnet test`)

**Example order types:** `FTR-MYPROJ-2026-0002` with `"role": "BOS"` that `dependsOn` the Shipwright order

---

## Scribe (SCR)

**What it does:** The Scribe writes and updates documentation. This includes user guides, API references, architecture documents, changelogs, and any other markdown or documentation content.

**When to use it:** Any order that involves creating or updating documentation — whether for users, developers, or internal stakeholders.

**What it reads:** Handoffs and plans, source code (for understanding what to document), existing documentation

**What it writes:** Documentation files (in the project's `docs/` directory and root markdown files)

**What it cannot write:** Source code, tests, plans, reports

**Example order types:** `DOC-MYPROJ-2026-0001` with `"role": "SCR"` to write a getting started guide

---

## Lookout (LKT)

**What it does:** The Lookout investigates and reports — on security vulnerabilities, dependency issues, code patterns, or anything requiring analysis without code changes. It produces structured investigation and security reports.

**When to use it:** Security audits, dependency scanning, code investigation, root-cause analysis on complex bugs where you want a written report before committing to a fix.

**What it reads:** Full codebase, source code, configuration files, authentication and security subsystems, controllers and middleware, existing reports

**What it writes:** Security reports (`.maestro/reports/security/`), investigation reports (`.maestro/reports/investigation/`)

**What it cannot write:** Source code, tests, documentation, plans

**Commands it runs:** Package vulnerability scans

**Why Haiku 4.5:** Lookout tasks are typically read-heavy and produce structured reports. Haiku 4.5 is faster and more cost-efficient for this pattern, delivering comparable quality for investigative work.

**Example order types:** `SEC-MYPROJ-2026-0001` with `"role": "LKT"` to audit authentication endpoints

---

## Coxswain (COX)

**What it does:** The Coxswain handles integration and deployment. It synthesises outputs from all other roles, verifies the build, runs the full test suite, and produces voyage completion reports. It has the broadest read access and runs the most commands.

**When to use it:** End-of-voyage integration, deployment steps, final verification, or any order that requires a holistic view of all recent crew work.

**What it reads:** Full codebase, all reports, all handoffs, active order state, solution files

**What it writes:** Voyage reports, order status updates

**What it cannot write:** Source code, tests, documentation, plans

**Commands it runs:** Build, test, format verification, security scan

**Why Opus 5:** Integration and deployment are high-stakes and run once per voyage. The Coxswain uses an Opus-tier model to minimise the risk of missing a critical issue during final verification. For an exceptionally high-stakes release you can move it to Fable 5.1 with a role overlay — see [CONFIG-MODELS.md](CONFIG-MODELS.md).

**Example order types:** `INT-MYPROJ-2026-0001` with `"role": "COX"` to close out a voyage

---

## Choosing the Right Role

| You want to... | Use role |
|----------------|---------|
| Plan a complex feature before building it | NAV |
| Implement a feature or fix a bug | SHP |
| Write or update tests | BOS |
| Write documentation | SCR |
| Audit for security issues | LKT |
| Investigate a complex bug (report only) | LKT |
| Integrate and verify a completed voyage | COX |
| Deploy to staging or production | COX |

### Common multi-role sequences

**Standard feature development:**
```
NAV (plan)  →  SHP (implement)  →  BOS (test)
```

**Feature with documentation:**
```
NAV (plan)  →  SHP (implement)  →  BOS (test)  →  SCR (docs)
```

**Security-first feature:**
```
LKT (audit existing code)  →  SHP (fix issues)  →  BOS (test fixes)
```

**Voyage close-out:**
```
... (feature orders)  →  COX (integrate + verify)
```

Use the `dependsOn` field in your order JSON to enforce the sequence. See [ORDERS-AND-VOYAGES.md](ORDERS-AND-VOYAGES.md) for details.

---

## Role Handoffs

When one role completes and another role needs to continue the work, the first role leaves a handoff document in `.maestro/handoffs/{ORDER-ID}/`. The naming convention is `{FROM-ROLE}-to-{TO-ROLE}.md` — for example, `NAV-to-SHP.md`.

The downstream role reads this handoff as its primary input, picking up exactly where the previous role left off.

**Handoff content typically includes:**

- Summary of what was done
- Key decisions made and rationale
- What the next role needs to do
- Any risks or open questions

Handoff documents are written automatically by crews when they complete their portion of the work. You do not need to author them manually.

---

*Maestro Maestro v2.0.0 — For licensing enquiries, contact [tavisbasing](https://github.com/tavisbasing).*
