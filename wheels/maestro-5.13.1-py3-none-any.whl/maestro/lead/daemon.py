# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""maestro/lead/daemon.py — LEAD daemon lifecycle (PLAN-PLN-MSO-2026-0504 §3.1).

A per-workspace detached process, supervised by nothing, discoverable by an
identity-verified PID record — the same shape as `maestro/hub/daemon.py`
(BUG-MSO-2026-0424), but per-WORKSPACE (PID file under the workspace's own
artefact root) rather than global, and via `maestro.proc_identity` directly
since this module has no legacy call sites to preserve.

Deliberately NOT a crew slot and NOT a dispatcher child (§3.1/§3.2):

  * It must outlive the dispatcher — the whole point is to still be there,
    and still able to report, after the dispatcher exits. §3.2 point 2 also
    notes the inversion this implies: the LEAD supervises the dispatcher
    (via the patrol's dispatcher-liveness checks), not the reverse.
  * `get_available_crews()` (fleet_runner.py) enumerates `crews/crew{1..5}`
    only; this daemon never touches that directory, so it structurally
    cannot consume a crew slot — there is nothing here for that function to
    see.

Tier gating (`auth.require_tier(auth.LEAD_AGENT_TIERS, ...)`) happens at the
CLI call site (`cli.cmd_lead`), mirroring where `cmd_hub` gates `hub.start()`
— this module stays licence-agnostic so its lifecycle can be exercised in
tests without licence machinery.
"""

from __future__ import annotations

import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Optional

from maestro import proc_identity
from maestro.launch.sandbox import spawn as _spawn

# Module reference (not bare-name imports) so tests can patch
# `maestro.proc_identity.process_create_time` ONCE and have it take effect
# both here (start()'s direct call) and inside proc_identity.is_running()'s
# own internal call — a bare-name import would freeze this module's copy at
# import time, requiring a second patch target for the same fake.


# BUG-MSO-2026-0724 — how long `stop()` waits for a signalled daemon to
# actually exit before escalating, and how long it then waits after the
# escalation. Mirrors maestro/hub/daemon.py:stop_hub()'s 10s/5s budgets.
STOP_TIMEOUT_SECONDS = 10.0
STOP_ESCALATION_SECONDS = 5.0
STOP_POLL_INTERVAL_SECONDS = 0.25


def _pid_file(artefact_root: Path) -> Path:
    return artefact_root / "lead" / "lead.pid"


def start(artefact_root: Path, workspace_root: Optional[Path] = None, force: bool = False) -> None:
    """Start the LEAD daemon for the workspace rooted at *artefact_root*.

    Idempotent: a genuinely running daemon (identity-verified) is left
    alone unless *force*. A stale record (dead PID, recycled PID, or a
    different process entirely) is cleared and a fresh daemon started —
    never signalled, per the BUG-MSO-2026-0424 rule that no signal is ever
    sent to a PID that fails identity verification.

    BUG-MSO-2026-0724: "already running" is decided by
    :func:`proc_identity.is_running` — PID **and** matching creation time,
    the same check ``mso lead status`` uses — and never by the mere
    PRESENCE of ``lead.pid``. A pid file left behind by a crashed or
    force-killed daemon is a stale record, not a live one, and clearing it
    now says so out loud instead of silently: an operator who sees
    "Started" with no explanation has no way to tell a clean start from a
    recovery after a death nobody noticed.
    """
    pid_file = _pid_file(artefact_root)
    running, existing_pid = proc_identity.is_running(pid_file)
    if running and not force:
        print(f"[LEAD] Already running (PID: {existing_pid})")
        return
    if not running and pid_file.exists():
        print(f"[LEAD] Clearing stale PID record (PID {existing_pid} is not this daemon "
              "— dead, recycled, or a different process); no signal sent.")
        pid_file.unlink()

    cmd = [sys.executable, "-m", "maestro.lead", "--artefact-root", str(artefact_root)]
    if workspace_root is not None:
        # FTR-MSO-2026-0585 (RC-2): *workspace_root* was previously only
        # handed to _spawn()'s own `workspace=` kwarg (sandbox env-building /
        # audit — never the child's argv), so the daemon process itself had
        # no idea where the product repo was. Thread it onto the child's
        # command line too, so __main__.py's argparse actually receives it.
        cmd += ["--workspace", str(workspace_root)]
    pid_file.parent.mkdir(parents=True, exist_ok=True)

    if os.name == "nt":
        DETACHED_PROCESS = 0x00000008
        CREATE_NEW_PROCESS_GROUP = 0x00000200
        proc = _spawn(
            cmd,
            identity="lead",
            workspace=workspace_root,
            creationflags=DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    else:
        proc = _spawn(
            cmd,
            identity="lead",
            workspace=workspace_root,
            start_new_session=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

    proc_identity.write_identity_record(pid_file, proc.pid, proc_identity.process_create_time(proc.pid))
    print(f"[LEAD] Started (PID {proc.pid})")


def stop(
    artefact_root: Path,
    *,
    timeout: float = STOP_TIMEOUT_SECONDS,
    poll_interval: float = STOP_POLL_INTERVAL_SECONDS,
) -> bool:
    """Stop the LEAD daemon and BLOCK until it has actually exited.

    BUG-MSO-2026-0724: the previous implementation sent a signal, slept a
    flat one second, and cleared the PID record only if the process HAPPENED
    to be gone by then — printing "Stop signal sent" either way. That made
    ``mso lead restart`` (a bare ``stop(); start()``) race itself: on
    2026-09-10 the PSG daemon was signalled, ``start()`` read the still-alive
    PID record a moment later and refused with "[LEAD] Already running
    (PID: 11228)", and the daemon then died — leaving the workspace with NO
    LEAD supervision behind success-shaped output. The same class of silent
    "signal sent is not stopped" bug was closed for the Hub daemon by
    BUG-MSO-2026-0516; this brings the LEAD daemon in line.

    Returns ``True`` once the daemon is confirmed gone (or was never
    running), ``False`` if it is still alive after the signal and the
    escalation — in which case the PID record is deliberately LEFT IN PLACE,
    because it still describes a live process, and the caller
    (``cli.cmd_lead``) exits non-zero.
    """
    pid_file = _pid_file(artefact_root)
    running, pid = proc_identity.is_running(pid_file)
    if not running:
        # Not our daemon (dead, recycled PID, or a different process
        # entirely). Send NO signal, always clear the stale record.
        print("[LEAD] Not running")
        if pid_file.exists():
            print(f"[LEAD]   (clearing stale PID record for PID {pid} — no signal sent)")
            pid_file.unlink()
        return True

    def _signal(escalated: bool) -> None:
        try:
            if os.name == "nt":
                # /F (force) on BOTH passes: the daemon is a plain background
                # loop with no window/console message pump, so a non-forced
                # taskkill (the WM_CLOSE-style request maestro/hub/daemon.py
                # sends first) has nothing to receive it and the process is
                # left running — verified empirically while building this
                # module. There is therefore no gentler first pass to make on
                # Windows; the escalation is simply a second attempt.
                subprocess.run(["taskkill", "/F", "/PID", str(pid)], capture_output=True, timeout=10)
            else:
                os.kill(pid, 9 if escalated else 15)  # SIGKILL : SIGTERM
        except Exception as exc:
            kind = "force-kill" if escalated else "stop"
            print(f"[LEAD] Failed to send {kind} signal: {exc}", file=sys.stderr)

    def _wait_for_exit(budget_seconds: float) -> bool:
        # Iteration-counted rather than deadline-based so a patched
        # ``time.sleep`` (tests) cannot turn this into a real wall-clock wait.
        iterations = max(1, int(budget_seconds / poll_interval))
        for _ in range(iterations):
            if not proc_identity.is_running(pid_file)[0]:
                return True
            time.sleep(poll_interval)
        return not proc_identity.is_running(pid_file)[0]

    def _confirm_stopped(note: str = "") -> bool:
        if pid_file.exists():
            pid_file.unlink()
        print(f"[LEAD] Stopped (PID: {pid}){note}")
        return True

    _signal(escalated=False)
    if _wait_for_exit(timeout):
        return _confirm_stopped()

    print(
        f"[LEAD] PID {pid} still running {timeout:.0f}s after the stop signal — escalating",
        file=sys.stderr,
    )
    _signal(escalated=True)
    if _wait_for_exit(STOP_ESCALATION_SECONDS):
        return _confirm_stopped(", required escalation")

    print(
        f"[LEAD] Failed to stop (PID {pid} is still running after the stop signal "
        "and the escalation). The PID record is left in place because it still "
        "describes a live process.",
        file=sys.stderr,
    )
    return False


def restart(artefact_root: Path, workspace_root: Optional[Path] = None) -> bool:
    """Stop-then-start, with the WAIT in between (BUG-MSO-2026-0724).

    :func:`stop` now blocks until the old process is confirmed gone and
    removes the PID record itself, so by the time :func:`start` looks there
    is nothing left for it to mistake for a live daemon. If the stop could
    NOT be confirmed, no second daemon is launched — two LEAD daemons on one
    workspace would both tick, both act within their band, and both write
    the same state file.

    Returns ``True`` when the old daemon was confirmed stopped and a
    replacement was launched — deliberately NOT a claim that the replacement
    is still alive a second later, which only ``mso lead status`` can
    honestly answer.
    """
    if not stop(artefact_root):
        print(
            "[LEAD] Not starting a replacement: the previous daemon could not be "
            "confirmed stopped, and two daemons on one workspace would both tick "
            "and both act. Investigate the PID above, then `mso lead start`.",
            file=sys.stderr,
        )
        return False
    start(artefact_root, workspace_root)
    return True


def _installed_version() -> Optional[str]:
    try:
        import maestro
        return getattr(maestro, "__version__", None)
    except Exception:
        return None


def status(artefact_root: Path) -> dict:
    from maestro.lead.agent import load_lead_config, load_state

    running, pid = proc_identity.is_running(_pid_file(artefact_root))
    state = load_state(artefact_root)
    cfg = load_lead_config(artefact_root)

    # PLAN-PLN-MSO-2026-0584 Dimension A: read from the DURABLE config, not
    # state.json — a toggle must render immediately, not only after the
    # daemon's next tick has had a chance to persist it. A daemon that is
    # currently STOPPED can still carry `standDown=true` here (it was stood
    # down before it was stopped) — `running` is what tells "off by choice"
    # (running + standDown) apart from "not running at all".
    stand_down = bool(cfg.get("standDown", False))

    # RC-5: the daemon pins its code at process START. `runningVersion` is
    # what the LAST tick actually wrote (persisted even by a skipped,
    # stood-down tick — see agent.run_once) — absent on a daemon that has
    # never ticked since this order landed. `installedVersion` is what THIS
    # reader (the CLI process or the Hub backend) resolves right now, which
    # may differ from a long-running daemon after a `pip install`.
    #
    # BUG-MSO-2026-0724: `runningVersion` means "the version the LIVE process
    # is executing" and is therefore `None` when nothing is running — a
    # STOPPED daemon has no running version, and reporting the last tick's
    # one under that name is what made the Hub's LEAD strip render a dead
    # PSG daemon as "Running stale code (v5.12.1)" on 2026-09-10 while the
    # pill next to it correctly said STOPPED. What the last tick wrote is
    # still worth knowing — a stopped daemon that last ran an old version is
    # a different situation from one that never ticked — so it keeps its own
    # name, `lastRanVersion`, which is always populated regardless of
    # liveness. `versionMismatch` likewise means "the RUNNING process is
    # behind what is installed", so it can only ever be true while running.
    last_ran_version = state.get("runningVersion")
    installed_version = _installed_version()
    running_version = last_ran_version if running else None
    version_mismatch = bool(running_version) and running_version != installed_version

    return {
        "running": running,
        "pid": pid if running else None,
        "standDown": stand_down,
        "runningVersion": running_version,
        "lastRanVersion": last_ran_version,
        "installedVersion": installed_version,
        "versionMismatch": version_mismatch,
        "lastTickAt": state.get("lastTickAt"),
        "lastOutcome": state.get("lastOutcome"),
        "lastReason": state.get("lastReason"),
        "dispatcherState": state.get("lastDispatcherState"),
        "lastFindingsCount": state.get("lastFindingsCount"),
        # FTR-MSO-2026-0539: severity breakdown behind lastFindingsCount,
        # written by agent.run_once(). Absent on a daemon that has never
        # ticked — callers must not assume the key exists.
        "lastFindingsBySeverity": state.get("lastFindingsBySeverity"),
        # PLAN-PLN-MSO-2026-0584 Dimension C3: distinguishes "nothing needed
        # doing" from "the action path is broken" — see
        # bands.ActionTickSummary's docstring. Absent on a daemon that has
        # never ticked since this order landed.
        "lastActions": state.get("actions"),
        # Only set on a tick that actually executed or errored an action
        # (see agent.run_once) — otherwise carried forward unchanged, so
        # this is the TRUE last-fired timestamp across ticks, never "now" on
        # every quiet one.
        "lastActionAt": state.get("lastActionAt"),
        # PLAN-PLN-MSO-2026-0584 Dimension D: per-finding fingerprint +
        # acknowledgement metadata (attached by agent._apply_acknowledgement_detail),
        # so `mso lead status` can show operators which fingerprint to hand
        # to `mso lead ack` without a separate `mso doctor --json` round trip.
        "lastFindingsDetail": state.get("lastFindingsDetail"),
        "lastAckSuppressed": state.get("lastAckSuppressed"),
    }


def print_status(artefact_root: Path) -> None:
    s = status(artefact_root)
    print("\n  LEAD — STATUS")
    print("  " + "-" * 40)
    if s["running"]:
        # PLAN-PLN-MSO-2026-0584 Dimension A: "a stood-down daemon is NOT a
        # stopped one" — a live, heartbeating process deliberately doing no
        # work must never render identically to a dead one.
        if s.get("standDown"):
            print(f"  Status:  RUNNING — STOOD DOWN (PID: {s['pid']})")
        else:
            print(f"  Status:  RUNNING (PID: {s['pid']})")
    else:
        print("  Status:  STOPPED")
    if s["running"]:
        version_line = f"  Running version: {s.get('runningVersion') or '(never ticked)'}"
        if s.get("versionMismatch"):
            version_line += f"  [STALE — installed is {s.get('installedVersion')}]"
    else:
        # BUG-MSO-2026-0724: a stopped daemon is running NO version. Naming
        # the last tick's version under "Running version" (with a [STALE]
        # badge, no less) reads as a live process on old code — the exact
        # misreading that hid the 2026-09-10 PSG daemon death.
        last_ran = s.get("lastRanVersion")
        version_line = (
            f"  Last ran version: {last_ran} (not running — start it to run "
            f"the installed {s.get('installedVersion')})"
            if last_ran
            else "  Last ran version: (never ticked)"
        )
    print(version_line)
    print(f"  Last tick:      {s['lastTickAt'] or '(never)'}")
    print(f"  Last outcome:   {s['lastOutcome'] or '(none)'}"
          + (f" ({s['lastReason']})" if s.get("lastReason") else ""))
    print(f"  Dispatcher:     {s['dispatcherState'] or 'unknown'}")
    print(f"  Last findings:  {s['lastFindingsCount'] if s['lastFindingsCount'] is not None else '-'}")
    actions = s.get("lastActions") or {}
    print(
        "  Last actions:   "
        f"considered={actions.get('considered', 0)} eligible={actions.get('eligible', 0)} "
        f"executed={actions.get('executed', 0)} refused={actions.get('refused', 0)} "
        # BUG-MSO-2026-0636 (F5): precondition_refused (a distinct case from
        # 'refused' — see ActionTickSummary's docstring) was persisted but
        # never actually shown here.
        f"precondition_refused={actions.get('precondition_refused', 0)} "
        f"errors={actions.get('errors', 0)}"
    )
    print(f"  Last LEAD_ACTION: {s['lastActionAt'] or '(never)'}")
    if s.get("lastAckSuppressed"):
        print(f"  Ack-suppressed:   {s['lastAckSuppressed']} finding(s) this tick")
    findings_detail = s.get("lastFindingsDetail") or []
    if findings_detail:
        print("  Open findings (fingerprint — for `mso lead ack --fingerprint <fp>`):")
        for f in findings_detail:
            fp = f.get("fingerprint") or "?"
            fp_short = fp[:12] if fp != "?" else fp
            tag = ""
            if f.get("acknowledged"):
                tag = f"  [ACKED by {f.get('acknowledgedBy') or '?'} until {f.get('acknowledgedExpiresAt') or '?'}]"
            print(
                f"    [{f.get('severity', '?').upper():<8}] {fp_short}…  "
                f"{f.get('title') or f.get('checkId') or '(untitled)'}{tag}"
            )
    print("  " + "-" * 40)
    print()


def run_foreground_once(artefact_root: Path, workspace_root: Optional[Path] = None) -> "object":
    """`mso lead run --once` — a single foreground pass, no daemon spawned.
    Also what a B2 interactive session calls (plan §3, B2 tier).

    *workspace_root* (FTR-MSO-2026-0585 / RC-2): threaded through to
    ``run_once`` exactly like the resident daemon's own ``--workspace`` —
    so a foreground pass's ``checks_run`` matches ``mso doctor``'s on the
    same workspace, not the ambiently-rooted daemon's undercount. ``None``
    preserves the prior no-workspace behaviour for any existing caller.
    """
    from maestro.lead.agent import run_once
    if workspace_root is not None:
        return run_once(artefact_root, workspace=workspace_root)
    return run_once(artefact_root)
