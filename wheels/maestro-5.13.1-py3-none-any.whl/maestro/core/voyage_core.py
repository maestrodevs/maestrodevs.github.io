# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Shared voyage-creation core (FTR-MSO-2026-0618 / PLAN-PLN-MSO-2026-0556 §3.2).

There was never ONE voyage-create implementation to reuse. There were TWO, and
they had already drifted before anyone proposed a third for the Hub
(PLAN-PLN-MSO-2026-0556 §2.2, measured during planning):

===================  ===============================  =================================
                     ``cli.cmd_voyage`` ("create")    ``bridge_poller._handle_voyage_create``
===================  ===============================  =================================
Manifest primary key ``id``                           ``voyageId``
Sequence source      ``max(seq)+1`` over ``active``   ``len(existing)+1`` over
                     **and** ``complete``             ``active`` **only**
``branch`` field     written (``voyage/{id}``)        absent
``priority`` field   ``MEDIUM``                       absent
Allocation lock      ``lock_for_allocation``          none
                     (BUG-MSO-2026-0571)
Remote fetch         yes (FTR-MSO-2026-0574)          none
Git side effect      ``git checkout -b`` in cwd       ``git checkout -b`` in
                                                      artefact parent
===================  ===============================  =================================

Two defects fall straight out of that table:

1. ``len(existing) + 1`` is *precisely* the bug SEC-MSO-2026-0461 Finding 3
   fixed for orders. ``order_ids.py``'s module docstring exists to record why
   counting a directory is wrong — it under-counts the moment anything is
   archived out of it, and it is not atomic. The fix landed for orders and was
   never applied to voyages in either allocator. Here it is deleted: the
   sequence is the max over ``voyages/active`` **and** ``voyages/complete``
   (plus the fetched remote tree), so a completed voyage's number is never
   re-used.
2. The ``id`` / ``voyageId`` split was already costing the engine money in
   defensive reads — ``cmd_voyage status`` reads
   ``v.get('id') or v.get('voyageId') or voyage_id`` (added by
   BUG-MSO-2026-0300 after a bare ``v['id']`` crashed), and
   ``voyages_outstanding_work`` reads ``voyage.get("voyageId", stem)``. This
   module writes **both** keys, so the drift is closed going forward without
   breaking either existing reader.

``maestro/core/review_core.py``'s docstring records what leaving two copies
alone costs: five silent behavioural drifts between the Hub's private copy of
the review logic and the CLI's, two of them order-destroying, none found by
reading either implementation alone (BUG-MSO-2026-0486). The drift above was
found the same way — by putting the two side by side — and it *predates* the
Hub. Adding a third allocator would not have been a new risk to manage; it
would have been a repeat.

Module contract — copied verbatim from ``maestro/core/order_retry.py``
(PLAN-PLN-MSO-2026-0556 §3.3), not invented here:

* **Explicit ``mso: Path`` throughout. No ``find_workspace()``, no CWD.** The
  Hub serves N workspaces from one process; a core that resolves its workspace
  from the process is unusable there.
* **Typed exceptions, no printing, no ``sys.exit``.**
  :class:`~maestro.core.order_ids.OrderValidationError` -> HTTP 400 /
  ``MaestroUserError``; :class:`VoyageNotFound` (a ``FileNotFoundError``) ->
  404; :class:`VoyageIdCollision` -> 409; ``CapabilityDenied`` -> 403.
* **Every mutation runs inside ``order_retry.workspace_scope(mso)``.** Not
  decorative: shared-mode allocation goes through
  ``artefact_sync.push_id_reservation``, which writes ``ID_RESERVED`` lifecycle
  events resolved from ``fleet_runner._MAESTRO_DIR_OVERRIDE`` — a process
  global. Unguarded, a Hub poller tick for workspace A can write into
  workspace B's lifecycle log.
* **The write happens under ``lock_for_allocation(mso)``, inside the same
  ``with`` block as the allocation** — ``order_ids.py`` is explicit that
  allocating outside that block is not race-safe. The lock file is the *same*
  ``state/order-id.lock`` orders use, deliberately: voyage and order IDs are
  minted from one workspace sequence space (CLAUDE.md, "MSO Order Naming
  Convention"), so a second lock would serialise the wrong thing.

**No git side effect by default (§3.4, Captain decision D4).**
:func:`create_voyage` takes ``create_branch: bool = False`` and performs no git
operation unless asked. ``fleet_runner.ensure_voyage_branch_exists()`` already
creates the voyage branch **on the remote via ``gh api``, with no clone and no
checkout**, lazily at first crew dispatch — so both callers'
``git checkout -b`` was redundant, and in the primary workspace checkout it was
actively hazardous (CLAUDE.md's ``CONVERGENCE_PRIMARY_PROTECTED`` is an entire
bug class caused by unexpected primary-checkout mutation). The manifest records
the branch *name*; the machinery that needs the branch creates it when it needs
it. ``mso voyage create`` keeps today's behaviour behind a deprecated
``--checkout``; the bridge poller does **not**, because a background daemon
switching the operator's working tree is the sharpest form of the objection
§3.4 raises against doing it from the Hub.

``require_capability("voyage.create")`` is enforced here rather than in the CLI
wrapper, so the CLI, the bridge and (from Order 3) the Hub inherit the gate
together — the shape FTR-MSO-2026-0492 established for ``order.dispatch``.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

from maestro.core.order_create import validate_project
from maestro.core.order_ids import (
    OrderValidationError,
    fetch_remote_sequence_numbers,
    lock_for_allocation,
    validate_description,
    validate_priority,
)
from maestro.core.order_retry import workspace_scope

# ---------------------------------------------------------------------------
# Vocabulary
# ---------------------------------------------------------------------------

#: Every directory a voyage manifest can live in across its lifecycle. Scanning
#: only ``active`` is how sequence numbers get re-used: ``voyage reconcile``
#: moves a merged voyage to ``complete/``, and a scan that cannot see it mints
#: its number again for a different voyage.
VOYAGE_SCAN_SUBDIRS: tuple = ("voyages/active", "voyages/complete")

#: Voyages are always created PLANNED (Captain decision D3). ``voyage.status``
#: gates no dispatch — ``scan_all_queues`` never reads it — so a
#: Planned/Active selector was inert, and the ORDER plane is where
#: "created but not started" is actually expressed.
DEFAULT_VOYAGE_STATUS = "PLANNED"

#: The CLI wrote MEDIUM and the bridge wrote nothing. Converged on the CLI's
#: value, always present.
DEFAULT_VOYAGE_PRIORITY = "MEDIUM"

#: Fields :func:`create_voyage` computes and validates itself — ``extra`` may
#: not overwrite any of them. Mirrors ``order_create._COMPUTED_FIELDS``: a
#: caller must not be able to smuggle a forged id, status or branch past the
#: validation above, which is the entire point of having one core.
_COMPUTED_FIELDS: frozenset = frozenset({
    "id", "voyageId", "title", "status", "priority", "branch", "project",
    "orders", "createdBy", "createdAt",
})


# ---------------------------------------------------------------------------
# Typed errors
# ---------------------------------------------------------------------------

class VoyageNotFound(FileNotFoundError):
    """*voyage_id* has no manifest in this workspace.

    A ``FileNotFoundError`` subclass so an HTTP caller maps it to 404 through
    the same ``except FileNotFoundError`` arm it already uses, per the module
    contract above.
    """

    def __init__(self, voyage_id: str) -> None:
        self.voyage_id = voyage_id
        self.hint = "Check 'mso voyage list' for active voyages."
        super().__init__(
            f"Voyage {voyage_id} not found in voyages/active or voyages/complete."
        )


class VoyageIdCollision(Exception):
    """A freshly-minted voyage ID already exists on disk.

    The last line of defence if :func:`~maestro.core.order_ids.lock_for_allocation`
    ever degraded to unlocked — its ``_CrossProcessLock`` proceeds unlocked
    rather than blocking forever when a wedged holder outlives the timeout.
    Maps to HTTP 409; the remedy is simply to retry.
    """

    def __init__(self, voyage_id: str, path: Path) -> None:
        self.voyage_id = voyage_id
        self.path = path
        self.hint = (
            "Retry — this indicates a concurrent allocation raced past the lock."
        )
        super().__init__(f"Voyage ID collision: {voyage_id} already exists at {path}")


class VoyageOrderRefused(Exception):
    """An attach/detach could not be applied as asked. Maps to HTTP 409."""

    def __init__(self, voyage_id: str, order_id: str, message: str,
                 hint: str = "") -> None:
        self.voyage_id = voyage_id
        self.order_id = order_id
        self.hint = hint
        super().__init__(message)


# ---------------------------------------------------------------------------
# Results
# ---------------------------------------------------------------------------

@dataclass
class LoadedVoyage:
    """Result of :func:`load_voyage`."""

    voyage_id: str
    path: Path
    voyage: Dict[str, Any]
    #: True when the manifest was found in ``voyages/complete`` rather than
    #: ``voyages/active`` — an archived voyage is readable but not mutable.
    archived: bool = False


@dataclass
class CreatedVoyage:
    """Result of a successful :func:`create_voyage` call."""

    voyage_id: str
    path: Path
    voyage: Dict[str, Any]
    branch: str = ""
    #: True when shared-mode push-as-mutex actually reserved the id upstream.
    reserved: bool = False
    #: ``push_id_reservation``'s outcome reason, or ``"local"`` in solo/embedded.
    reservation_reason: str = "local"
    #: Populated only when ``create_branch=True`` and the git call failed. The
    #: voyage itself is still created — a branch that the dispatcher will
    #: create anyway is not worth failing a creation over.
    branch_error: str = ""


@dataclass
class UpdatedVoyage:
    """Result of :func:`attach_order` / :func:`detach_order`."""

    voyage_id: str
    path: Path
    voyage: Dict[str, Any]
    order_ids: List[str] = field(default_factory=list)
    #: False when the manifest already said what was asked for (attaching an
    #: order that is already attached) — the call is idempotent, and the caller
    #: deserves to know nothing changed rather than being told it did.
    changed: bool = True


# ---------------------------------------------------------------------------
# ID allocation
# ---------------------------------------------------------------------------

def voyage_id_pattern(project: str, year: str) -> "re.Pattern[str]":
    """Filename regex for this project/year's voyage manifests, group 1 = seq.

    The same shape ``fetch_remote_sequence_numbers`` matches against a fetched
    remote tree, so the local and remote scans cannot disagree about what
    counts as a voyage file.
    """
    return re.compile(
        rf'^VOY-{re.escape(project)}-{re.escape(year)}-(\d+)\.json$'
    )


def highest_voyage_sequence(mso: Path, project: str, year: str) -> int:
    """Highest local voyage sequence for (project, year) across
    :data:`VOYAGE_SCAN_SUBDIRS`.

    Scanning ``complete`` as well as ``active`` is the half the bridge's
    ``len(existing) + 1`` allocator got wrong twice over — it neither looked in
    the archive nor read the numbers it did see.
    """
    pattern = voyage_id_pattern(project, year)
    highest = 0
    for sub in VOYAGE_SCAN_SUBDIRS:
        d = Path(mso) / sub
        if not d.exists():
            continue
        for f in d.iterdir():
            m = pattern.match(f.name)
            if m:
                highest = max(highest, int(m.group(1)))
    return highest


def allocate_voyage_id(mso: Path, project: str, year: str, *,
                       fetch_remote: bool = True, git: Any = None) -> str:
    """Allocate the next voyage ID for (project, year).

    Mirrors :func:`~maestro.core.order_ids.allocate_order_id` exactly, over the
    voyage directories: fold the artefact repo's fetched remote tree in with the
    local max (FTR-MSO-2026-0574), then add one. The fetch skips SILENTLY when
    there is no repo, no remote or no connectivity — FTR-MSO-2026-0366's
    deliberate offline tolerance, not an error path.

    Callers MUST invoke this inside a ``with lock_for_allocation(mso):`` block
    that also performs the resulting file write — calling it alone is not
    race-safe.
    """
    local_max = highest_voyage_sequence(mso, project, year)
    remote_max = 0
    if fetch_remote:
        fetched = fetch_remote_sequence_numbers(
            Path(mso), VOYAGE_SCAN_SUBDIRS, voyage_id_pattern(project, year),
            git=git)
        if fetched is not None:
            remote_max = fetched
    seq = max(local_max, remote_max) + 1
    return f"VOY-{project}-{year}-{seq:04d}"


def assert_voyage_id_available(mso: Path, voyage_id: str) -> None:
    """Raise :class:`VoyageIdCollision` if *voyage_id* already exists.

    Post-allocation uniqueness assertion, run inside the allocation lock. See
    :class:`VoyageIdCollision` for why it exists despite the lock.
    """
    for sub in VOYAGE_SCAN_SUBDIRS:
        existing = Path(mso) / sub / f"{voyage_id}.json"
        if existing.exists():
            raise VoyageIdCollision(voyage_id, existing)


# ---------------------------------------------------------------------------
# Lookup
# ---------------------------------------------------------------------------

def find_voyage_file(mso: Path, voyage_id: str) -> Optional[Path]:
    """Path of *voyage_id*'s manifest, active first then archived, or ``None``.

    Resolves by filename and by the manifest's own id keys (``id`` OR
    ``voyageId`` — the §2.2 drift means a workspace can legitimately hold both
    shapes), so an older manifest whose filename and id disagree is still
    found.
    """
    mso = Path(mso)
    for sub in VOYAGE_SCAN_SUBDIRS:
        d = mso / sub
        if not d.exists():
            continue
        direct = d / f"{voyage_id}.json"
        if direct.exists():
            return direct
    for sub in VOYAGE_SCAN_SUBDIRS:
        d = mso / sub
        if not d.exists():
            continue
        for jf in sorted(d.glob("*.json")):
            try:
                data = json.loads(jf.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            if not isinstance(data, dict):
                continue
            if (data.get("id") or data.get("voyageId") or jf.stem) == voyage_id:
                return jf
    return None


def voyage_order_ids(voyage: Dict[str, Any]) -> List[str]:
    """Order ids in a manifest's ``orders[]``, which may hold strings or dicts.

    Same tolerance as ``fleet_runner._voyage_order_ids`` — the two must agree
    about what an ``orders[]`` entry is, or an order this core attaches is one
    the dispatcher does not see.
    """
    ids: List[str] = []
    for entry in voyage.get("orders", []) or []:
        if isinstance(entry, str):
            oid = entry
        elif isinstance(entry, dict):
            oid = entry.get("orderId") or entry.get("id") or ""
        else:
            oid = ""
        if oid:
            ids.append(oid)
    return ids


def load_voyage(mso: Path, voyage_id: str) -> LoadedVoyage:
    """Read *voyage_id*'s manifest from workspace *mso*.

    Raises :class:`VoyageNotFound` (a ``FileNotFoundError``) when there is no
    manifest, and :class:`~maestro.core.order_ids.OrderValidationError` when the
    file exists but is not readable JSON — a corrupt manifest is a 400-class
    input problem, not a missing resource.
    """
    path = find_voyage_file(mso, voyage_id)
    if path is None:
        raise VoyageNotFound(voyage_id)
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise OrderValidationError(
            f"Cannot read voyage file {path}: {exc}") from exc
    if not isinstance(data, dict):
        raise OrderValidationError(
            f"Voyage file {path} does not contain a JSON object")
    return LoadedVoyage(
        voyage_id=data.get("id") or data.get("voyageId") or path.stem,
        path=path,
        voyage=data,
        archived=path.parent.name == "complete",
    )


# ---------------------------------------------------------------------------
# create_voyage
# ---------------------------------------------------------------------------

def _checkout_branch(repo_root: Path, branch: str) -> str:
    """``git checkout -b`` in *repo_root*; returns "" on success, else the error.

    Only ever reached via ``create_branch=True`` (``mso voyage create
    --checkout``). Deprecated — see §3.4 in the module docstring.
    """
    from maestro.core.proc import run_hidden

    try:
        result = run_hidden(
            ["git", "checkout", "-b", branch],
            cwd=str(repo_root), capture_output=True, text=True, timeout=30,
        )
    except Exception as exc:  # noqa: BLE001 — reported, never raised onward
        return str(exc)
    if getattr(result, "returncode", 1) == 0:
        return ""
    return (getattr(result, "stderr", "") or "").strip() or "git checkout failed"


def create_voyage(
    mso: Path,
    *,
    project: str,
    title: str,
    priority: Optional[str] = None,
    status: str = DEFAULT_VOYAGE_STATUS,
    description: str = "",
    orders: Optional[Sequence[Any]] = None,
    created_by: str = "cli",
    create_branch: bool = False,
    repo_root: Optional[Path] = None,
    extra: Optional[Dict[str, Any]] = None,
) -> CreatedVoyage:
    """Create a voyage in workspace *mso* and return what actually landed.

    Sole implementation of voyage creation — ``mso voyage create``, the Slack
    bridge's ``voyage_create`` command and (Order 3) the Hub's
    ``POST /workspaces/{id}/voyages`` all call this. The manifest carries
    **both** ``id`` and ``voyageId`` (§2.2), a ``branch`` name, and a
    ``priority``, so the two historic shapes converge without breaking either
    existing reader.

    ``create_branch`` defaults to ``False`` and no git command runs unless it is
    set — see §3.4 / D4 in the module docstring. When it is set, *repo_root*
    (defaulting to ``mso.parent``) is where ``git checkout -b`` runs, and a
    failure is reported in :attr:`CreatedVoyage.branch_error` rather than
    raised: the dispatcher creates the branch on the remote anyway.

    Raises :class:`~maestro.core.order_ids.OrderValidationError` on bad input,
    :class:`VoyageIdCollision` (409) if an allocated id is somehow already
    taken, and ``CapabilityDenied`` (403) in a governed workspace whose caller
    lacks ``voyage.create``. Prints nothing; exits nothing.
    """
    from maestro.identity.gate import require_capability

    # `mso` is the artefact `.mso` dir; the gate wants the WORKSPACE ROOT.
    # A no-op outside enterprise/governed workspaces. Enforced HERE rather than
    # in cmd_voyage so the bridge and the Hub inherit the same gate — the shape
    # FTR-MSO-2026-0492 established for order.dispatch.
    require_capability("voyage.create", workspace=Path(mso).parent)

    mso = Path(mso)
    project = validate_project(project)
    title = validate_description(title)
    priority = validate_priority(priority, default=DEFAULT_VOYAGE_PRIORITY)
    status = (status or DEFAULT_VOYAGE_STATUS).strip().upper() or DEFAULT_VOYAGE_STATUS

    initial_orders: List[Any] = list(orders or [])

    now = datetime.now(timezone.utc)
    year = now.strftime("%Y")
    voyages_dir = mso / "voyages" / "active"
    voyages_dir.mkdir(parents=True, exist_ok=True)

    written: Dict[str, Any] = {}

    def _build(voyage_id: str) -> Dict[str, Any]:
        voyage: Dict[str, Any] = {
            # BOTH keys, deliberately (§2.2). `id` first because that is the
            # order the CLI's manifests have always had and every `.get('id')
            # or .get('voyageId')` reader in the engine tries `id` first.
            "id": voyage_id,
            "voyageId": voyage_id,
            "title": title,
            "status": status,
            "priority": priority,
            "branch": f"voyage/{voyage_id}",
            "project": project,
            "orders": initial_orders,
            "createdBy": created_by,
            "createdAt": now.isoformat(),
        }
        if description:
            voyage["description"] = description
        for key, value in (extra or {}).items():
            if key not in _COMPUTED_FIELDS:
                voyage[key] = value
        return voyage

    def _mint(git: Any) -> str:
        candidate = allocate_voyage_id(mso, project, year, git=git)
        assert_voyage_id_available(mso, candidate)
        return candidate

    def _write(voyage_id: str) -> Path:
        voyage = _build(voyage_id)
        path = voyages_dir / f"{voyage_id}.json"
        path.write_text(json.dumps(voyage, indent=2), encoding="utf-8")
        written.clear()
        written.update(voyage)
        return path

    # workspace_scope: shared-mode reservation writes ID_RESERVED lifecycle
    # events through fleet_runner's process-global override (module docstring).
    # lock_for_allocation: the scan-then-write critical section must be ONE
    # locked block. This is the lock the bridge never had.
    with workspace_scope(mso):
        with lock_for_allocation(mso):
            # FTR-MSO-2026-0574: in mode: shared ONLY, reserve the id via
            # push-as-mutex. Solo mode does not get this — an unsynced solo
            # device against a shared plane is a misconfiguration to migrate
            # away from, not something to arbitrate.
            from maestro.core.artefact_sync import get_mode, push_id_reservation

            if get_mode(mso) == "shared":
                outcome = push_id_reservation(mso, _mint, _write)
                new_id = outcome.id
                reserved = bool(getattr(outcome, "pushed", False))
                reason = getattr(outcome, "reason", "") or "shared"
            else:
                new_id = _mint(None)
                _write(new_id)
                reserved = False
                reason = "local"

    # Read the manifest back from the file that was actually written rather
    # than returning the dict we intended to write — §2.3's rule for the Hub
    # ("returns the ID read back from the file it just wrote"), applied to the
    # whole record. In shared mode the reservation helper owns the write and
    # may re-mint, so intent and outcome are not guaranteed to be the same
    # object.
    path = voyages_dir / f"{new_id}.json"
    try:
        voyage_data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        voyage_data = dict(written) if written else _build(new_id)

    branch = voyage_data.get("branch") or f"voyage/{new_id}"
    branch_error = ""
    if create_branch:
        branch_error = _checkout_branch(
            Path(repo_root) if repo_root else mso.parent, branch)

    return CreatedVoyage(
        voyage_id=new_id,
        path=path,
        voyage=voyage_data,
        branch=branch,
        reserved=reserved,
        reservation_reason=reason,
        branch_error=branch_error,
    )


# ---------------------------------------------------------------------------
# attach_order / detach_order
# ---------------------------------------------------------------------------

def _save_voyage(path: Path, voyage: Dict[str, Any]) -> None:
    path.write_text(json.dumps(voyage, indent=2), encoding="utf-8")


def attach_order(mso: Path, voyage_id: str, order_id: str, *,
                 title: str = "") -> UpdatedVoyage:
    """Add *order_id* to *voyage_id*'s ``orders[]``. Idempotent.

    Entries are written as dicts (``{"orderId": ..., "title": ...}``) — the
    richer of the two shapes ``fleet_runner._voyage_order_ids`` accepts, and the
    one ``mso voyage status`` renders a title from. An order already present is
    left exactly as it is and ``changed=False`` is returned; re-attaching must
    not rewrite an entry another surface authored.

    Raises :class:`VoyageNotFound` (404), :class:`VoyageOrderRefused` (409) for
    an archived voyage, and
    :class:`~maestro.core.order_ids.OrderValidationError` (400) for an empty
    order id.
    """
    order_id = (order_id or "").strip()
    if not order_id:
        raise OrderValidationError("Order ID is required")

    with workspace_scope(Path(mso)):
        loaded = load_voyage(mso, voyage_id)
        if loaded.archived:
            raise VoyageOrderRefused(
                loaded.voyage_id, order_id,
                f"Voyage {loaded.voyage_id} is archived — its manifest is a "
                "completion record, not a work queue.",
                hint="Create a new voyage for further work.",
            )
        voyage = loaded.voyage
        existing = voyage_order_ids(voyage)
        if order_id in existing:
            return UpdatedVoyage(
                voyage_id=loaded.voyage_id, path=loaded.path, voyage=voyage,
                order_ids=existing, changed=False)

        entry: Dict[str, Any] = {"orderId": order_id}
        if title:
            entry["title"] = title
        voyage.setdefault("orders", [])
        voyage["orders"].append(entry)
        _save_voyage(loaded.path, voyage)
        return UpdatedVoyage(
            voyage_id=loaded.voyage_id, path=loaded.path, voyage=voyage,
            order_ids=voyage_order_ids(voyage), changed=True)


def detach_order(mso: Path, voyage_id: str, order_id: str, *,
                 missing_ok: bool = False) -> UpdatedVoyage:
    """Remove *order_id* from *voyage_id*'s ``orders[]``.

    Removes string and dict entries alike, so a manifest hand-written in either
    shape detaches correctly. An order that is not in the manifest raises
    :class:`VoyageOrderRefused` (409) — matching ``mso order remove
    --from-voyage``'s existing refusal, which exists so a typo'd id is not
    silently reported as removed — unless *missing_ok* is set, which returns
    ``changed=False`` instead.

    This function does **not** touch the skip list; ``mso order remove`` layers
    ``fleet_runner.add_skipped_order`` on top, because detaching from a manifest
    and vetoing dispatch are two different decisions.
    """
    order_id = (order_id or "").strip()
    if not order_id:
        raise OrderValidationError("Order ID is required")

    with workspace_scope(Path(mso)):
        loaded = load_voyage(mso, voyage_id)
        if loaded.archived:
            raise VoyageOrderRefused(
                loaded.voyage_id, order_id,
                f"Voyage {loaded.voyage_id} is archived — its manifest is a "
                "completion record and must not be rewritten.",
            )
        voyage = loaded.voyage
        kept: List[Any] = []
        found = False
        for entry in voyage.get("orders", []) or []:
            if isinstance(entry, str):
                eid = entry
            elif isinstance(entry, dict):
                eid = entry.get("orderId") or entry.get("id") or ""
            else:
                eid = ""
            if eid == order_id:
                found = True
            else:
                kept.append(entry)

        if not found:
            if missing_ok:
                return UpdatedVoyage(
                    voyage_id=loaded.voyage_id, path=loaded.path, voyage=voyage,
                    order_ids=voyage_order_ids(voyage), changed=False)
            raise VoyageOrderRefused(
                loaded.voyage_id, order_id,
                f"Order {order_id} not found in {loaded.voyage_id} orders[].",
                hint=f"Check the voyage manifest with 'mso voyage status "
                     f"{loaded.voyage_id}'",
            )

        voyage["orders"] = kept
        _save_voyage(loaded.path, voyage)
        return UpdatedVoyage(
            voyage_id=loaded.voyage_id, path=loaded.path, voyage=voyage,
            order_ids=voyage_order_ids(voyage), changed=True)
