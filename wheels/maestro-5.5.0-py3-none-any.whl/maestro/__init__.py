# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""
Maestro — AI-orchestrated multi-agent coding for Claude Code.

Version: 5.5.0
Repository: https://github.com/tavisbasing/Maestro
"""

__version__ = "5.5.0"
__title__ = "Maestro"

__all__ = ["__version__", "__title__"]
