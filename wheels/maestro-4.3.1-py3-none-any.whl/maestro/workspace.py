"""maestro.workspace — workspace directory resolution (.mso/ only)."""

from __future__ import annotations

import logging
import os
from pathlib import Path

_log = logging.getLogger(__name__)

_MSO_DIR = ".mso"


def find_workspace_dir(start: Path | None = None) -> Path | None:
    """Walk up from *start* (default: cwd) looking for a ``.mso/`` workspace dir.

    Returns the ``.mso/`` directory or ``None`` if not found.
    """
    root = Path(start) if start is not None else Path.cwd()
    for path in [root, *root.parents]:
        mso = path / _MSO_DIR
        if (mso / "config").is_dir():
            return mso
    return None


def get_workspace_dir(start: Path | None = None) -> Path:
    """Return the workspace directory.

    Resolution order:
    1. ``MAESTRO_DIR`` environment variable (preferred)
    2. Walk up from *start* (default: cwd) looking for ``.mso/config``

    Raises :class:`FileNotFoundError` if no workspace is found.
    """
    env_dir = os.environ.get("MAESTRO_DIR")
    if env_dir:
        return Path(env_dir).resolve()

    root = Path(start) if start is not None else Path.cwd()
    for path in [root, *root.parents]:
        mso = path / _MSO_DIR
        if (mso / "config").is_dir():
            return mso

    raise FileNotFoundError(
        "No Maestro workspace found in the current directory or any parent. "
        "Run `mso init --project <PRJ>` to create one."
    )


# Legacy alias kept for callers that imported from here before the rename.
_find_adm_dir = find_workspace_dir


def resolve_artefact_dir(workspace: Path) -> Path:
    """Return the canonical workspace artefact dir under *workspace*.

    Returns the ``.mso/`` path (creating it via `.mkdir()` at the call site
    if needed).
    """
    mso = workspace / _MSO_DIR
    if mso.is_dir():
        return mso
    return mso
