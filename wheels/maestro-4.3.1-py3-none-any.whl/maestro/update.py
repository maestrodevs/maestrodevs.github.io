"""
mso update — Propagate schema and template changes into an existing workspace.

Patches an existing .mso/ workspace to bring it up to the current package version,
preserving all user data (orders, voyages, plans, etc.).

Unlike `adm init`, this command never creates a workspace from scratch.
"""

from __future__ import annotations

import copy
import json
from pathlib import Path
from typing import Any


# ---------------------------------------------------------------------------
# Current package version (authoritative)
# ---------------------------------------------------------------------------

def _package_version() -> str:
    from maestro import __version__
    return __version__


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def update_workspace(workspace: Path, dry_run: bool = False, force: bool = False) -> None:
    """Propagate Maestro schema updates into an existing .mso/ workspace.

    Args:
        workspace: Path to the workspace root (where .mso/ lives).
        dry_run:   Print what would change without writing anything.
        force:     Overwrite files that would otherwise be skipped
                   (e.g. .mso/claude.md with no generated markers).
    """
    workspace = workspace.resolve()
    from maestro.workspace import resolve_artefact_dir
    adm_dir = resolve_artefact_dir(workspace)

    if not adm_dir.exists():
        print(f"[mso update] ERROR: No Maestro workspace (.mso/) found at {workspace}")
        print("  Run 'mso init --project <ACRONYM>' to scaffold a new workspace.")
        raise SystemExit(1)

    pkg_version = _package_version()
    ws_version = _read_schema_version(adm_dir)

    if dry_run:
        print("[adm update] Dry-run mode — no files will be modified.\n")

    if ws_version == pkg_version:
        print(f"[adm update] Already up to date (schemaVersion {pkg_version}).")
        return

    print(f"[adm update] Workspace schemaVersion: {ws_version}  ->  {pkg_version}")
    print()

    actions: list[tuple[str, str, str]] = []  # (verb, path_display, detail)

    # -----------------------------------------------------------------------
    # 1. Ensure all scaffold directories exist
    # -----------------------------------------------------------------------
    from maestro.init import DIRS
    for rel in DIRS:
        d = workspace / rel
        if not d.exists():
            actions.append(("WOULD CREATE" if dry_run else "CREATE", rel + "/", "missing directory"))
            if not dry_run:
                d.mkdir(parents=True, exist_ok=True)
                runtime = {".mso/crews", ".mso/logs", ".mso/temp", ".mso/bridge"}
                if not any(rel.startswith(r) for r in runtime):
                    gitkeep = d / ".gitkeep"
                    if not any(d.iterdir()):
                        gitkeep.touch()

    # -----------------------------------------------------------------------
    # 2. .gitignore Maestro block
    # -----------------------------------------------------------------------
    gitignore_path = workspace / ".gitignore"
    gitignore_action = _check_gitignore(gitignore_path)
    if gitignore_action:
        actions.append(("WOULD REPLACE" if dry_run else "REPLACE", ".gitignore", "Maestro block"))
        if not dry_run:
            from maestro.init import _update_gitignore, GITIGNORE_BLOCK_START, GITIGNORE_BLOCK_END, GITIGNORE_ADDITIONS
            _replace_gitignore_block(gitignore_path, GITIGNORE_BLOCK_START, GITIGNORE_BLOCK_END, GITIGNORE_ADDITIONS)
    else:
        actions.append(("NO CHANGE", ".gitignore", "Maestro block current"))

    # -----------------------------------------------------------------------
    # 3. .mso/config/role-paths.json — deep merge: add missing keys
    # -----------------------------------------------------------------------
    role_paths_path = adm_dir / "config" / "role-paths.json"
    default_role_paths = _load_default_role_paths()
    if default_role_paths:
        rp_action, rp_detail = _check_json_merge(role_paths_path, default_role_paths)
        if rp_action == "update":
            actions.append(("WOULD UPDATE" if dry_run else "UPDATE",
                            ".mso/config/role-paths.json", rp_detail))
            if not dry_run:
                _apply_json_merge(role_paths_path, default_role_paths)
        else:
            actions.append(("NO CHANGE", ".mso/config/role-paths.json", "no new keys"))

    # -----------------------------------------------------------------------
    # 4. .claude/settings.json hooks — union merge by command value
    # -----------------------------------------------------------------------
    settings_path = workspace / ".claude" / "settings.json"
    hooks_action, hooks_detail = _check_hooks_merge(settings_path)
    if hooks_action == "update":
        actions.append(("WOULD UPDATE" if dry_run else "UPDATE",
                        ".claude/settings.json", hooks_detail))
        if not dry_run:
            _apply_hooks_merge(settings_path)
    else:
        actions.append(("NO CHANGE", ".claude/settings.json", hooks_detail))

    # -----------------------------------------------------------------------
    # 5. .mso/config/mcp-servers.json — migrate from .claude/settings.json
    # -----------------------------------------------------------------------
    mcp_registry_path = adm_dir / "config" / "mcp-servers.json"
    mcp_action, mcp_detail = _check_mcp_migration(settings_path, mcp_registry_path, force)
    if mcp_action == "update":
        actions.append(("WOULD UPDATE" if dry_run else "UPDATE",
                        ".mso/config/mcp-servers.json", mcp_detail))
        if not dry_run:
            _apply_mcp_migration(settings_path, mcp_registry_path, force)
    else:
        actions.append(("NO CHANGE", ".mso/config/mcp-servers.json", mcp_detail))

    # -----------------------------------------------------------------------
    # 6. .mso/claude.md — replace generated sections (or skip/force)
    # -----------------------------------------------------------------------
    claude_md_path = adm_dir / "claude.md"
    cm_action, cm_detail = _check_claude_md(claude_md_path, force)
    if cm_action == "replace":
        actions.append(("WOULD REPLACE" if dry_run else "REPLACE",
                        ".mso/claude.md", cm_detail))
        if not dry_run:
            _apply_claude_md(claude_md_path, adm_dir)
    elif cm_action == "skip":
        actions.append(("WOULD SKIP" if dry_run else "SKIP",
                        ".mso/claude.md", cm_detail))
    else:
        actions.append(("NO CHANGE", ".mso/claude.md", cm_detail))

    # -----------------------------------------------------------------------
    # 7. workspace.json schemaVersion bump
    # -----------------------------------------------------------------------
    ws_json_path = adm_dir / "config" / "workspace.json"
    if ws_version != pkg_version:
        actions.append(("WOULD BUMP" if dry_run else "BUMP",
                        "workspace.json schemaVersion",
                        f"{ws_version} -> {pkg_version}"))
        if not dry_run:
            _bump_schema_version(ws_json_path, pkg_version)

    # -----------------------------------------------------------------------
    # Print summary
    # -----------------------------------------------------------------------
    col_verb = max(len(a[0]) for a in actions) if actions else 12
    col_path = max(len(a[1]) for a in actions) if actions else 40
    for verb, path, detail in actions:
        print(f"  {verb:<{col_verb}}  {path:<{col_path}}  ({detail})")

    print()
    if dry_run:
        print("Run without --dry-run to apply.")
    else:
        print(f"[adm update] Workspace updated to schemaVersion {pkg_version}.")


# ---------------------------------------------------------------------------
# Schema version helpers
# ---------------------------------------------------------------------------

def _read_schema_version(adm_dir: Path) -> str:
    ws_json = adm_dir / "config" / "workspace.json"
    if not ws_json.exists():
        return "0.0.0"
    try:
        data = json.loads(ws_json.read_text(encoding="utf-8"))
        return data.get("schemaVersion", "0.0.0")
    except (json.JSONDecodeError, OSError):
        return "0.0.0"


def _bump_schema_version(ws_json_path: Path, new_version: str) -> None:
    if not ws_json_path.exists():
        return
    try:
        data = json.loads(ws_json_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        data = {}
    data["schemaVersion"] = new_version
    ws_json_path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


# ---------------------------------------------------------------------------
# .gitignore helpers
# ---------------------------------------------------------------------------

def _check_gitignore(gitignore_path: Path) -> bool:
    """Return True if the gitignore block needs updating."""
    from maestro.init import GITIGNORE_BLOCK_START, GITIGNORE_ADDITIONS
    if not gitignore_path.exists():
        return True
    content = gitignore_path.read_text(encoding="utf-8")
    # Replace if block is absent OR if block content differs
    if GITIGNORE_BLOCK_START not in content:
        return True
    # Check if current block matches expected
    from maestro.init import GITIGNORE_BLOCK_END
    start_idx = content.find(GITIGNORE_BLOCK_START)
    end_idx = content.find(GITIGNORE_BLOCK_END)
    if start_idx == -1 or end_idx == -1:
        return True
    existing_block = content[start_idx:end_idx + len(GITIGNORE_BLOCK_END)]
    expected = GITIGNORE_ADDITIONS.strip()
    return existing_block.strip() != expected


def _replace_gitignore_block(
    gitignore_path: Path,
    block_start: str,
    block_end: str,
    new_block: str,
) -> None:
    """Replace the delimited Maestro block in .gitignore."""
    if gitignore_path.exists():
        content = gitignore_path.read_text(encoding="utf-8")
        start_idx = content.find(block_start)
        end_idx = content.find(block_end)
        if start_idx != -1 and end_idx != -1:
            # Replace the block
            before = content[:start_idx]
            after = content[end_idx + len(block_end):]
            new_content = before + new_block.strip() + after
            gitignore_path.write_text(new_content, encoding="utf-8")
            return
        # Block start exists but end doesn't — append fresh block
        if not content.endswith("\n"):
            content += "\n"
        gitignore_path.write_text(content + "\n" + new_block, encoding="utf-8")
    else:
        from maestro.init import _default_gitignore
        gitignore_path.write_text(_default_gitignore() + "\n" + new_block, encoding="utf-8")


# ---------------------------------------------------------------------------
# JSON deep-merge helpers
# ---------------------------------------------------------------------------

def _load_default_role_paths() -> dict | None:
    """Load the bundled role-paths-default.json from the package."""
    try:
        import importlib.resources as pkg_resources
        ref = pkg_resources.files("maestro") / "config" / "role-paths-default.json"
        content = ref.read_text(encoding="utf-8")
        return json.loads(content)
    except Exception:
        return None


def _deep_merge(base: dict, defaults: dict) -> tuple[dict, list[str]]:
    """Merge defaults into base, adding missing keys at any depth.

    Returns (merged_dict, list_of_added_keys).
    Existing values in base are never overwritten.
    """
    added: list[str] = []
    result = copy.deepcopy(base)

    def _merge(dst: dict, src: dict, path: str = "") -> None:
        for key, value in src.items():
            full_key = f"{path}.{key}" if path else key
            if key not in dst:
                dst[key] = copy.deepcopy(value)
                added.append(full_key)
            elif isinstance(dst[key], dict) and isinstance(value, dict):
                _merge(dst[key], value, full_key)

    _merge(result, defaults)
    return result, added


def _check_json_merge(path: Path, defaults: dict) -> tuple[str, str]:
    """Return ('update', detail) or ('no_change', detail)."""
    if not path.exists():
        return "update", "file missing — will create"
    try:
        existing = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return "update", "unreadable — will recreate"
    _, added = _deep_merge(existing, defaults)
    if added:
        keys_preview = ", ".join(added[:3])
        if len(added) > 3:
            keys_preview += f" +{len(added) - 3} more"
        return "update", f"add key(s): {keys_preview}"
    return "no_change", ""


def _apply_json_merge(path: Path, defaults: dict) -> None:
    """Write merged JSON to path."""
    if path.exists():
        try:
            existing = json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            existing = {}
    else:
        existing = {}
    merged, _ = _deep_merge(existing, defaults)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(merged, indent=2) + "\n", encoding="utf-8")


# ---------------------------------------------------------------------------
# Hooks merge helpers
# ---------------------------------------------------------------------------

def _admiralty_hooks() -> dict:
    """Return the canonical Maestro hooks definition (same as cmd_hooks)."""
    return {
        "PreToolUse": [
            {
                "matcher": "Edit|MultiEdit|Write",
                "hooks": [{"type": "command", "command": "python -m maestro.hooks.pretool", "timeout": 10}],
            },
            {
                "matcher": "AskUserQuestion",
                "hooks": [{"type": "command", "command": "python -m maestro.hooks.bridge_question", "timeout": 10}],
            },
        ],
        "PostToolUse": [
            {
                "matcher": "Edit|MultiEdit|Write|Bash|Read|Glob|Grep|Task",
                "hooks": [{"type": "command", "command": "python -m maestro.hooks.posttool", "timeout": 10}],
            }
        ],
        "Stop": [
            {
                "matcher": "",
                "hooks": [{"type": "command", "command": "python -m maestro.hooks.stop", "timeout": 30}],
            }
        ],
        "Notification": [
            {
                "matcher": "",
                "hooks": [{"type": "command", "command": "python -m maestro.hooks.notification", "timeout": 10}],
            }
        ],
    }


def _hooks_entry_key(entry: dict) -> str:
    hooks = entry.get("hooks", [])
    first_cmd = hooks[0].get("command", "") if hooks else ""
    return f"{entry.get('matcher', '')}|{first_cmd}"


def _check_hooks_merge(settings_path: Path) -> tuple[str, str]:
    """Return ('update', detail) or ('no_change', detail)."""
    if not settings_path.exists():
        return "update", "settings.json missing — will create with hooks"
    try:
        settings = json.loads(settings_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return "update", "unreadable — will create with hooks"

    hooks_section = settings.get("hooks", {})
    new_hooks = _admiralty_hooks()
    missing_count = 0

    for event, new_entries in new_hooks.items():
        existing_entries = hooks_section.get(event, [])
        existing_keys = {_hooks_entry_key(e) for e in existing_entries}
        for entry in new_entries:
            if _hooks_entry_key(entry) not in existing_keys:
                missing_count += 1

    if missing_count:
        return "update", f"add {missing_count} hook(s)"
    return "no_change", "hooks current"


def _apply_hooks_merge(settings_path: Path) -> None:
    """Union-merge Maestro hooks into settings.json."""
    if settings_path.exists():
        try:
            settings = json.loads(settings_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            settings = {}
    else:
        settings = {}

    merged = copy.deepcopy(settings)
    merged.setdefault("hooks", {})
    new_hooks = _admiralty_hooks()

    for event, new_entries in new_hooks.items():
        existing_entries: list = merged["hooks"].setdefault(event, [])
        existing_keys = {_hooks_entry_key(e) for e in existing_entries}
        for entry in new_entries:
            if _hooks_entry_key(entry) not in existing_keys:
                existing_entries.append(copy.deepcopy(entry))

    settings_path.parent.mkdir(parents=True, exist_ok=True)
    settings_path.write_text(json.dumps(merged, indent=2) + "\n", encoding="utf-8")


# ---------------------------------------------------------------------------
# .mso/claude.md helpers
# ---------------------------------------------------------------------------

CLAUDE_MD_GEN_START = "<!-- adm:generated:start -->"
CLAUDE_MD_GEN_END = "<!-- adm:generated:end -->"


def _resolve_project_acronym(adm_dir: Path) -> str:
    """Resolve project acronym for template rendering.

    Single-project workspaces set workspace.json["project"].
    Multi-project workspaces declare projects.json["defaultProject"].
    Falls back to the workspace directory name if neither is set.
    """
    ws_json = adm_dir / "config" / "workspace.json"
    if ws_json.exists():
        try:
            ws = json.loads(ws_json.read_text(encoding="utf-8"))
            if ws.get("project"):
                return ws["project"]
        except Exception:
            pass

    projects_json = adm_dir / "config" / "projects.json"
    if projects_json.exists():
        try:
            projects = json.loads(projects_json.read_text(encoding="utf-8"))
            if projects.get("defaultProject"):
                return projects["defaultProject"]
        except Exception:
            pass

    return adm_dir.parent.name.upper()


def _check_claude_md(path: Path, force: bool) -> tuple[str, str]:
    """Return ('replace', detail), ('skip', detail), or ('no_change', detail)."""
    if not path.exists():
        return "replace", "file missing — will create"
    content = path.read_text(encoding="utf-8")
    if CLAUDE_MD_GEN_START in content and CLAUDE_MD_GEN_END in content:
        return "replace", "replace generated section"
    # No markers — fully customised
    if force:
        return "replace", "no markers but --force specified"
    return "skip", "no generated markers — use --force to overwrite"


def _apply_claude_md(path: Path, adm_dir: Path) -> None:
    """Replace generated section (or full file) in .mso/claude.md."""
    from maestro.init import _render_template, _default_claude_md

    # Determine project acronym:
    #   1. Single-project workspaces: workspace.json["project"]
    #   2. Multi-project workspaces: projects.json["defaultProject"]
    project = _resolve_project_acronym(adm_dir)

    new_content = _render_template("claude-adm.md.j2", {"project_acronym": project})
    if not new_content:
        new_content = _default_claude_md(project)

    if path.exists():
        existing = path.read_text(encoding="utf-8")
        start_idx = existing.find(CLAUDE_MD_GEN_START)
        end_idx = existing.find(CLAUDE_MD_GEN_END)
        if start_idx != -1 and end_idx != -1:
            before = existing[:start_idx]
            after = existing[end_idx + len(CLAUDE_MD_GEN_END):]
            replaced = before + CLAUDE_MD_GEN_START + "\n" + new_content + "\n" + CLAUDE_MD_GEN_END + after
            path.write_text(replaced, encoding="utf-8")
            return

    # Full overwrite (force mode or file missing)
    path.write_text(new_content, encoding="utf-8")


# ---------------------------------------------------------------------------
# MCP registry migration helpers
# ---------------------------------------------------------------------------

MCP_REGISTRY_DEFAULTS: dict[str, Any] = {
    "$schema": "../../../maestro/config/mcp-servers.schema.json",
    "schemaVersion": "1.0",
    "description": "MCP server allowlist",
    "servers": [],
}


def _read_settings_mcp_servers(settings_path: Path) -> dict[str, dict]:
    """Return the mcpServers dict from .claude/settings.json, or {}."""
    if not settings_path.exists():
        return {}
    try:
        settings = json.loads(settings_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}
    servers = settings.get("mcpServers", {})
    if not isinstance(servers, dict):
        return {}
    return servers


def _settings_entry_to_registry(name: str, settings_entry: dict) -> dict:
    """Transform a .claude/settings.json mcpServers entry into a registry entry.

    Conservative defaults: risk_level=medium, allowed_roles="*".
    env_required is derived from the names (keys) of the settings entry's env block.

    Raises:
        ValueError: If the source settings entry is missing a non-empty string
            command — writing the entry anyway would produce a registry that
            violates the schema (`command` has minLength: 1) and break dispatch
            enforcement.
    """
    command = settings_entry.get("command")
    if not isinstance(command, str) or not command.strip():
        raise ValueError(
            f"Cannot migrate MCP server {name!r}: .claude/settings.json entry must "
            "define a non-empty string 'command'. Fix the settings entry and "
            "re-run 'mso update'."
        )
    entry: dict[str, Any] = {
        "name": name,
        "command": command,
        "allowed_roles": "*",
        "risk_level": "medium",
    }
    args = settings_entry.get("args")
    if isinstance(args, list) and args:
        entry["args"] = [str(a) for a in args]
    env = settings_entry.get("env")
    if isinstance(env, dict) and env:
        entry["env_required"] = sorted(env.keys())
    return entry


def _load_or_default_registry(registry_path: Path) -> dict:
    """Load the registry or return a fresh default."""
    if registry_path.exists():
        try:
            data = json.loads(registry_path.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                data.setdefault("schemaVersion", "1.0")
                data.setdefault("servers", [])
                return data
        except (json.JSONDecodeError, OSError):
            pass
    return copy.deepcopy(MCP_REGISTRY_DEFAULTS)


def _plan_mcp_migration(
    settings_path: Path,
    registry_path: Path,
    force: bool,
) -> tuple[dict, list[str], list[str]]:
    """Compute the migrated registry without writing.

    Returns (new_registry, added_names, replaced_names).
    """
    source = _read_settings_mcp_servers(settings_path)
    registry = _load_or_default_registry(registry_path)
    servers = registry.setdefault("servers", [])
    existing_by_name = {s.get("name"): i for i, s in enumerate(servers) if s.get("name")}

    added: list[str] = []
    replaced: list[str] = []

    for name, settings_entry in source.items():
        new_entry = _settings_entry_to_registry(name, settings_entry)
        if name in existing_by_name:
            if force:
                servers[existing_by_name[name]] = new_entry
                replaced.append(name)
        else:
            servers.append(new_entry)
            existing_by_name[name] = len(servers) - 1
            added.append(name)

    return registry, added, replaced


def _check_mcp_migration(
    settings_path: Path,
    registry_path: Path,
    force: bool,
) -> tuple[str, str]:
    """Return ('update', detail) or ('no_change', detail)."""
    source = _read_settings_mcp_servers(settings_path)
    if not source and registry_path.exists():
        return "no_change", "no mcpServers in settings.json"

    _, added, replaced = _plan_mcp_migration(settings_path, registry_path, force)

    if not registry_path.exists():
        if added or replaced:
            preview = ", ".join((added + replaced)[:3])
            count = len(added) + len(replaced)
            if count > 3:
                preview += f" +{count - 3} more"
            return "update", f"create registry with {count} server(s): {preview}"
        return "update", "create empty registry"

    if not added and not replaced:
        skipped = [n for n in source if n not in {*added, *replaced}]
        if skipped and not force:
            preview = ", ".join(skipped[:3])
            if len(skipped) > 3:
                preview += f" +{len(skipped) - 3} more"
            return "no_change", f"skip {len(skipped)} already-registered server(s): {preview} (use --force to overwrite)"
        return "no_change", "registry already in sync"

    parts: list[str] = []
    if added:
        parts.append(f"add {len(added)} ({', '.join(added[:3])}{' +' + str(len(added) - 3) + ' more' if len(added) > 3 else ''})")
    if replaced:
        parts.append(f"replace {len(replaced)} ({', '.join(replaced[:3])}{' +' + str(len(replaced) - 3) + ' more' if len(replaced) > 3 else ''})")
    return "update", "; ".join(parts)


def _apply_mcp_migration(
    settings_path: Path,
    registry_path: Path,
    force: bool,
) -> None:
    """Write the migrated registry to disk."""
    registry, _, _ = _plan_mcp_migration(settings_path, registry_path, force)
    registry_path.parent.mkdir(parents=True, exist_ok=True)
    registry_path.write_text(json.dumps(registry, indent=2) + "\n", encoding="utf-8")
