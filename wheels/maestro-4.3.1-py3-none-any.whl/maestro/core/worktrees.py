"""Worktree lifecycle primitives for parallel voyage isolation.

Provides prepare/cleanup/prune operations for git worktrees scoped to
voyage working directories under .mso/voyages/active/<voyage_id>/.worktree/.
"""

from __future__ import annotations

import subprocess
import threading
from pathlib import Path
from typing import Optional

from maestro.workspace import resolve_artefact_dir as _resolve_artefact_dir

from maestro.core.fleet_runner import _robust_rmtree

# Module-level lock to serialize concurrent prepare calls for the same worktree
_prepare_lock = threading.Lock()


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class WorktreeError(Exception):
    """Base class for worktree lifecycle errors."""


class WorktreeBranchConflict(WorktreeError):
    """Branch is already checked out in another worktree."""


class WorktreeDirExists(WorktreeError):
    """Worktree directory exists but is not registered with git."""


class WorktreeMissingBranch(WorktreeError):
    """The requested branch does not exist and cannot be created."""


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _repo_root() -> Path:
    """Return the root of the git repository."""
    result = subprocess.run(
        ["git", "rev-parse", "--show-toplevel"],
        capture_output=True, text=True
    )
    if result.returncode != 0:
        raise WorktreeError(f"Not inside a git repository: {result.stderr.strip()}")
    return Path(result.stdout.strip())


def _registered_worktrees() -> set[Path]:
    """Return the set of resolved paths currently registered with git worktree."""
    result = subprocess.run(
        ["git", "worktree", "list", "--porcelain"],
        capture_output=True, text=True
    )
    paths = set()
    for line in result.stdout.splitlines():
        if line.startswith("worktree "):
            raw = line[len("worktree "):].strip()
            # Use Path to normalise slashes; resolve() canonicalises on real FS
            p = Path(raw)
            paths.add(p)
    return paths


def _branch_exists_local(branch: str) -> bool:
    """Check whether ``refs/heads/<branch>`` exists in the local repo."""
    result = subprocess.run(
        ["git", "rev-parse", "--verify", f"refs/heads/{branch}"],
        capture_output=True
    )
    return result.returncode == 0


def _branch_exists_remote(branch: str, remote: str = "origin") -> bool:
    """Check whether ``refs/remotes/<remote>/<branch>`` exists in the local repo.

    Returns True if the remote-tracking ref is present locally. Does not call
    ``git fetch`` — use :func:`_fetch_remote_branch` first if you need to
    refresh the local view of the remote.
    """
    result = subprocess.run(
        ["git", "rev-parse", "--verify", f"refs/remotes/{remote}/{branch}"],
        capture_output=True
    )
    return result.returncode == 0


def _fetch_remote_branch(branch: str, remote: str = "origin") -> bool:
    """Fetch a single branch from *remote* into the matching remote-tracking ref.

    BUG-MSO-2026-0027: the dispatcher creates voyage branches via ``gh api``,
    which only touches the GitHub remote — the local repo has no record of
    the new ref until something fetches. Without this, ``git worktree add``
    fails because ``refs/heads/<branch>`` doesn't exist.
    """
    result = subprocess.run(
        ["git", "fetch", remote, f"{branch}:refs/remotes/{remote}/{branch}"],
        capture_output=True, text=True, timeout=30
    )
    return result.returncode == 0


# Backward-compat alias; new callers should use the explicit local/remote form.
def _branch_exists(branch: str) -> bool:
    return _branch_exists_local(branch)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def worktree_path_for(voyage_id: str) -> Path:
    """Return the canonical worktree path for a voyage (no I/O)."""
    return _resolve_artefact_dir(_repo_root()) / "voyages" / "active" / voyage_id / ".worktree"


def prepare_voyage_worktree(voyage_id: str, voyage_branch: str) -> Path:
    """Create (or reuse) the git worktree for a voyage.

    Idempotent: if the worktree already exists and is registered, returns its path.
    Handles orphaned dirs from crashed PREPARING state by removing and recreating.

    Raises:
        WorktreeBranchConflict: branch is checked out in another worktree.
        WorktreeMissingBranch: branch does not exist.
        WorktreeError: git worktree add failed for another reason.
    """
    with _prepare_lock:
        worktree_path = worktree_path_for(voyage_id)
        registered = _registered_worktrees()

        # Happy path: already ready
        if worktree_path.exists() and worktree_path in registered:
            return worktree_path

        # Orphaned dir (PREPARING crash): remove and recreate
        if worktree_path.exists() and worktree_path not in registered:
            _robust_rmtree(worktree_path, label=f"worktree orphan {voyage_id}")

        # BUG-MSO-2026-0027: the dispatcher creates voyage branches via
        # ``gh api`` (remote-only). Resolve in three tiers:
        #   1. Local branch ref present → standard ``git worktree add <path> <branch>``.
        #   2. Remote-tracking ref already present → fetch is unnecessary; create
        #      the local branch via ``git worktree add -b <branch> <path> origin/<branch>``.
        #   3. Neither present → ``git fetch`` the specific branch from origin
        #      and retry the tracking-branch worktree add.
        # Fail loudly with WorktreeMissingBranch only if all three fail.
        local_branch = _branch_exists_local(voyage_branch)
        if not local_branch:
            if not _branch_exists_remote(voyage_branch):
                _fetch_remote_branch(voyage_branch)
            if not _branch_exists_remote(voyage_branch):
                raise WorktreeMissingBranch(
                    f"Branch '{voyage_branch}' does not exist locally or on origin. "
                    "Create it before calling prepare_voyage_worktree()."
                )

        worktree_path.parent.mkdir(parents=True, exist_ok=True)

        if local_branch:
            cmd = ["git", "worktree", "add", str(worktree_path), voyage_branch]
        else:
            # Create local branch tracking origin/<branch> in the same step.
            cmd = [
                "git", "worktree", "add",
                "-b", voyage_branch,
                str(worktree_path),
                f"origin/{voyage_branch}",
            ]

        result = subprocess.run(cmd, capture_output=True, text=True)

        if result.returncode == 0:
            return worktree_path

        stderr = result.stderr.strip()

        if "already checked out" in stderr or "already used by worktree" in stderr:
            raise WorktreeBranchConflict(
                f"Branch '{voyage_branch}' is already checked out in another worktree. "
                f"git error: {stderr}"
            )

        if "No space left" in stderr or "disk full" in stderr.lower():
            raise WorktreeError(f"Disk full while creating worktree: {stderr}")

        # Already registered (e.g. path comparison miss in concurrent scenario)
        if "already registered" in stderr and worktree_path.exists():
            return worktree_path

        raise WorktreeError(f"git worktree add failed: {stderr}")


def cleanup_voyage_worktree(voyage_id: str) -> bool:
    """Remove the worktree for a voyage.

    Returns True on clean removal, False if removal failed (caller should log).
    No-op (returns False) if the worktree directory does not exist.
    """
    worktree_path = worktree_path_for(voyage_id)

    if not worktree_path.exists():
        # Still prune in case git has stale refs
        subprocess.run(["git", "worktree", "prune"], capture_output=True)
        return False

    result = subprocess.run(
        ["git", "worktree", "remove", "--force", str(worktree_path)],
        capture_output=True, text=True
    )

    if result.returncode != 0:
        # Fall back to manual removal + prune
        removed = _robust_rmtree(worktree_path, label=f"worktree cleanup {voyage_id}")
        subprocess.run(["git", "worktree", "prune"], capture_output=True)
        return removed

    # Belt-and-suspenders: remove any lingering dir
    if worktree_path.exists():
        _robust_rmtree(worktree_path, label=f"worktree cleanup {voyage_id}")

    return True


def prune_stale_worktrees() -> int:
    """Remove worktrees whose voyage has moved to voyages/complete/.

    Also runs `git worktree prune` to clean broken git refs.
    Returns the count of worktrees pruned.
    """
    subprocess.run(["git", "worktree", "prune"], capture_output=True)

    repo_root = _repo_root()
    artefact_dir = _resolve_artefact_dir(repo_root)
    active_dir = artefact_dir / "voyages" / "active"
    complete_dir = artefact_dir / "voyages" / "complete"

    if not active_dir.exists():
        return 0

    completed_voyage_ids = {p.name for p in complete_dir.iterdir()} if complete_dir.exists() else set()

    pruned = 0
    for voyage_dir in active_dir.iterdir():
        if not voyage_dir.is_dir():
            continue
        voyage_id = voyage_dir.name
        if voyage_id not in completed_voyage_ids:
            continue
        worktree_path = voyage_dir / ".worktree"
        if worktree_path.exists():
            subprocess.run(
                ["git", "worktree", "remove", "--force", str(worktree_path)],
                capture_output=True
            )
            _robust_rmtree(worktree_path, label=f"prune stale worktree {voyage_id}")
            pruned += 1

    return pruned
