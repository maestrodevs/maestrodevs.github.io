"""maestro/core/chart_routing.py — Maestro Charts Phase 2: typed failure edges.

FTR-MSO-2026-0521 (PLAN-PLN-MSO-2026-0508 §4.1/§4.2, order 5 of 8). This is
the module that makes a chart's ``onFail`` edges actually fire. It sits
beside ``chart_scheduler.py`` (order 4, the ``onSuccess`` frontier pass) —
same guarded-by-``charts.enabled``, defensive-by-construction posture, same
release primitive (``fleet_runner.release_order_to_pending``), imported
lazily from ``fleet_runner`` rather than at module level so the existing
eager ``fleet_runner -> chart_scheduler``/``chart_routing`` import stays
acyclic (mirrors ``chart_scheduler.py``'s own import shape exactly).

Two entry points, both called from exactly two guarded sites in
``fleet_runner`` (plan §4.1, this order's acceptance criteria):

  * :func:`route_failure` — given a node failure (``order_id``, the role
    that just failed, and a ``cause`` token), find the order's ACTIVE
    chart's matching ``onFail`` edge and act on it: lap the order forward to
    the edge's target (§4.2 steps 1-4) or, once ``maxLaps`` is exhausted,
    apply ``onExhausted`` via the existing ``_maybe_hold_transition_for_
    review``-equivalent hold or ``archive_stalled_order`` machinery. Returns
    ``True`` iff the chart handled the failure — callers MUST NOT also run
    their own default hold/requeue logic in that case, since this function
    is then the sole writer of the order's queue file for this event.
    Returns ``False`` for every case where default (pre-Phase-2, or
    chart-less) behaviour must run unchanged — including a matched lap edge
    that could not actually release its target (BUG-MSO-2026-0551 Finding
    2: "handled" means a write happened, not merely "an edge matched"), a
    sink write (``@stalled``/``@humanGate``, direct or via ``onExhausted``)
    that failed for the same reason (BUG-MSO-2026-0558 Finding 1's fix
    extends Finding 2's "write happened" discipline to every branch, not
    just the lap one — see :func:`_consume_if_handled`), or a licence tier
    below ``auth.CHART_EXEC_TIERS`` (BUG-MSO-2026-0558 Finding 2). A
    ``VERDICT_FAIL`` cause's report ``nodeVerdict`` field is consumed if and
    only if this function is about to return ``True`` for that cause —
    never on a match alone (the round-1 fix's bug: it consumed on match,
    before the write outcome was known, so a failed write silently erased
    the only record that a rejection had happened).
  * :func:`read_node_verdict` — the ``nodeVerdict`` front-matter reader
    (plan §4.1): TST/SEC write ``nodeVerdict: FAIL`` into their QA/security
    report on an explicit REJECTED sign-off (maestro/roles/TST.md, SEC.md).
    Called at role completion, before the ordinary roleSequence advance, so
    a REJECTED verdict can route through :func:`route_failure` with cause
    ``VERDICT_FAIL`` instead of silently advancing (or, chart-less,
    behaving exactly as it does today — REJECTED sign-offs are recorded but
    nothing currently acts on them, per plan §2.3).

Phase 2 recognises exactly two failure causes (plan §4.1) — everything else
(``<promise>BLOCKED</promise>``, crew crash/HUNG/MAX_TURNS, convergence
conflict, AUTO_SERIALIZE) is deliberately NOT routed here; those keep their
existing requeue/salvage/stall paths verbatim, and neither fleet_runner call
site nor this module ever passes those as *cause*.

Wrapped defensively throughout per the plan's "Notes for Builder": a chart
failure must never crash the dispatcher, and ledger/lifecycle writes are
best-effort.

FTR-MSO-2026-0522 (plan §4.3, order 6 of 8) adds ``carry``: when
:func:`route_failure` laps an order forward (never on a sink/exhaustion
route — there is no "next lap" to carry into), the edge's ``carry`` kind
(``verifyLog`` / ``qaReport`` / ``handoff`` / ``none``) is resolved to an
artefact-plane path and appended to the TARGET order's ``carriedContext``
list, in the same JSON write ``_apply_lap`` already makes via
``release_order_to_pending``. ``fleet_runner.generate_prompt_for_item``
renders that list as a ``## Carried Context`` prompt section (plan §4.3:
"immediately after the existing prior-role-deliverables block"). A missing
artefact degrades EXPLICITLY — ``CARRY_DEGRADED`` naming the kind and the
path that was not found, carrying nothing onward. It never injects a
truncated/fabricated substitute; a crew that believes it has evidence it
does not have is worse than a crew that knows it has none.
"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional

from maestro.core import chart_scheduler as _chart_scheduler
from maestro.core import order_ledger as _order_ledger
from maestro.core.chart_schema import (
    ChartEdge,
    ChartNode,
    ChartSpec,
    RESERVED_SINKS,
    load_chart,
)

CAUSE_VERIFY_FAILED = "VERIFY_FAILED"
CAUSE_VERDICT_FAIL = "VERDICT_FAIL"

_SINK_HUMANGATE = "@humanGate"
_SINK_STALLED = "@stalled"

# BUG-MSO-2026-0558 Finding 2: onFail routing must be gated on the SAME
# auth.CHART_EXEC_TIERS floor (pro+) chart_scheduler.release_chart_frontier
# already enforces for the onSuccess frontier — this module previously
# checked only charts_enabled(), so a community-tier workspace got onFail
# routing with no onSuccess frontier at all (half a chart engine, matching
# neither the code's intent nor maestro/docs/LICENCE.md, which states chart
# EXECUTION as a whole — not just the frontier — is Pro and above). Own
# once-per-process dedup flag, separate from chart_scheduler's
# ``_TIER_DENIED_WARNED`` — the two modules log the same event type
# independently, exactly as they already independently check the flag via
# their own ``charts_enabled()`` calls.
_TIER_DENIED_WARNED = False

# Front-matter candidate locations per role (plan §4.1: "the role writes
# nodeVerdict: FAIL into its handoff/report front-matter"; TST's existing
# REJECTED sign-off already lives at reports/qa/QA-{ORDER-ID}.md, and SEC's
# at reports/security|investigation/{SEC|INV}-{ORDER-ID}.md — see
# maestro/roles/TST.md / SEC.md's OUTPUT tables for the exact naming this
# mirrors). A role with no entry here never has a node-verdict source and
# read_node_verdict short-circuits to None for it.
_VERDICT_CANDIDATES = {
    "TST": (("reports/qa", "QA-{oid}.md"),),
    "SEC": (
        ("reports/security", "SEC-{oid}.md"),
        ("reports/investigation", "INV-{oid}.md"),
    ),
}


def _default_workspace_dir() -> Path:
    from maestro.core.fleet_runner import get_artefact_root
    return get_artefact_root()


def _write_event(event_type: str, message: str) -> None:
    """Best-effort lifecycle write — never raises (mirrors chart_scheduler's
    own ``_note_charts_disabled``/``_warn_node_unresolved`` pattern)."""
    try:
        from maestro.core.fleet_runner import write_lifecycle_event
        write_lifecycle_event(event_type, message)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# route_failure — the typed failure-edge router
# ---------------------------------------------------------------------------

def route_failure(order_id: str, role: str, cause: str, *,
                   crew_num: int = 0,
                   crew_state: Optional[Dict[str, Any]] = None,
                   workspace_dir: Optional[Path] = None,
                   verify_log_path: Optional[Path] = None) -> bool:
    """Route a node failure at ``(order_id, role)`` with the given *cause*
    through the order's ACTIVE chart, if any.

    Returns ``True`` iff the chart handled the failure (routed onward via a
    lap, or applied ``onExhausted``) — the caller must NOT also run its own
    default hold/requeue logic. Returns ``False`` — meaning "run existing
    behaviour unchanged" — when: ``charts.enabled`` is false (the default),
    the licence tier is below ``auth.CHART_EXEC_TIERS`` (BUG-MSO-2026-0558
    Finding 2 — same floor the onSuccess frontier enforces), the order/role
    pair is not a node in any ACTIVE chart, or that node has no ``onFail``
    edge matching *cause*.

    *verify_log_path* (FTR-MSO-2026-0522, plan §4.3) is the full verify-gate
    log :func:`~maestro.core.fleet_runner._persist_verify_log` (BUG-MSO-2026-
    0506) already persisted for THIS failure at the caller's own
    ``VERIFY_FAILED`` site — passed straight through rather than re-derived,
    so a ``carry: "verifyLog"`` edge threads the exact log this failure
    produced, not a best-effort glob for "the most recent one". Callers
    routing a ``VERDICT_FAIL`` (no verify log exists for that cause) simply
    omit it; the ``verifyLog`` carry kind then falls back to the newest
    persisted log for *order_id*, if any.

    Never raises. *crew_state* defaults to ``{}`` — every field the
    ``onExhausted=stalled`` path (``archive_stalled_order``) reads from it
    (``role``, ``iteration``, ``startTime``, ``endTime``) tolerates absence.
    """
    global _TIER_DENIED_WARNED
    if not _chart_scheduler.charts_enabled():
        return False
    try:
        from maestro import auth
        if not auth.has_tier(auth.CHART_EXEC_TIERS):
            if not _TIER_DENIED_WARNED:
                _TIER_DENIED_WARNED = True
                _write_event(
                    "CHART_TIER_DENIED",
                    "charts.enabled is true but the licence tier is below the "
                    "chart-execution floor (pro+) — onFail routing behaving as "
                    "flag-off"
                )
            return False
    except Exception:
        # A licence-resolution failure must never crash the dispatcher, and
        # must never fail OPEN into routing a failure through a chart either.
        return False
    try:
        ws = Path(workspace_dir) if workspace_dir is not None else _default_workspace_dir()
        return _route_failure_inner(order_id, role, cause, crew_num,
                                     crew_state or {}, ws, verify_log_path)
    except Exception as exc:
        # BUG-MSO-2026-0608: reviewed per the order's instruction to
        # distinguish legitimate best-effort silence from a swallowed
        # malformed-chart failure. This except stays — "Never raises" (this
        # module's documented dispatch-loop safety contract, see the module
        # and function docstrings) is deliberate and correct: a chart bug
        # must never crash the dispatcher mid-scan of every OTHER order. A
        # read that legitimately finds nothing (no ACTIVE chart for this
        # order/role, no matching onFail edge, licence tier below the
        # execution floor) never reaches this except at all — those are
        # ordinary `return False`s inside `_route_failure_inner` itself, not
        # exceptions. What DOES land here is the case findings 6/7 identified
        # (a chart that passed validation yet still raised at runtime — e.g.
        # the pre-fix empty-targets IndexError or non-cycle bad-maxLaps
        # TypeError) or a genuine code bug — previously indistinguishable
        # from an ordinary no-op because nothing was logged. The behaviour
        # (return False, run the caller's default hold/requeue) is
        # unchanged; what changes is that it is no longer silent.
        _write_event(
            "WARN",
            f"{order_id} chart onFail routing for role '{role}' cause "
            f"'{cause}' raised {type(exc).__name__}: {exc} — falling back to "
            f"default hold/requeue (expected only for a chart that slipped "
            f"past validation, or a genuine bug)"
        )
        return False


def _find_owning_chart_and_node(order_id: str, role: str, ws: Path):
    """Scan every ACTIVE chart under ``charts/`` for a node matching
    ``(order_id, role)``. Deliberately does not consult the order's own
    ``voyageId`` field first (unlike ``chart_scheduler``, which is
    voyage-driven from the chart side already) — a failure event only ever
    concerns one specific order/role pair, so searching charts directly for
    that pair is both simpler and does not depend on every order JSON
    carrying a ``voyageId`` field. A malformed chart file is skipped, never
    fatal to the scan (mirrors ``chart_schema.charts_for_voyage``)."""
    charts_dir = Path(ws) / "charts"
    if not charts_dir.is_dir():
        return None
    for f in sorted(charts_dir.glob("*.json")):
        try:
            chart = load_chart(f)
        except Exception:
            continue
        if chart.status != "ACTIVE":
            continue
        for key, node in chart.nodes.items():
            if node.order == order_id and node.role == role:
                return chart, key
    return None


def _find_onfail_edge(chart: ChartSpec, from_key: str, cause: str) -> Optional[ChartEdge]:
    """The matching ``onFail`` edge out of *from_key*: an exact *cause*
    match wins over an ``ANY`` edge (plan §3.2 field reference — ``cause``
    "which failure signal fires this edge")."""
    exact: Optional[ChartEdge] = None
    any_match: Optional[ChartEdge] = None
    for e in chart.edges:
        if e.type != "onFail" or e.from_node != from_key:
            continue
        if e.cause == cause and exact is None:
            exact = e
        elif e.cause == "ANY" and any_match is None:
            any_match = e
    return exact if exact is not None else any_match


def _route_failure_inner(order_id: str, role: str, cause: str, crew_num: int,
                          crew_state: Dict[str, Any], ws: Path,
                          verify_log_path: Optional[Path] = None) -> bool:
    found = _find_owning_chart_and_node(order_id, role, ws)
    if found is None:
        return False
    chart, from_key = found

    edge = _find_onfail_edge(chart, from_key, cause)
    if edge is None:
        return False

    # BUG-MSO-2026-0551 Finding 4: V3 now rejects an onFail edge authored
    # with more than one target (schema-time), but a chart file can still
    # reach here without having been re-validated (hand-edited, or authored
    # before the V3 rule existed) — defend at runtime too rather than
    # silently dropping targets[1:]. onFail intentionally has no fan-out
    # semantics (a failing node has exactly one next destination, unlike
    # onSuccess's "wait for all in-edges"), so extra targets are refused
    # here with a named warning instead of being silently ignored.
    if len(edge.targets) > 1:
        _write_event(
            "WARN",
            f"{order_id} chart {chart.chart_id} edge {from_key}->{edge.targets} "
            f"is an onFail edge with {len(edge.targets)} targets — onFail "
            f"supports exactly one target (V3), extra targets "
            f"{edge.targets[1:]} are ignored; re-author as separate onFail "
            f"edges if multiple destinations are needed"
        )

    raw_target = edge.targets[0]

    # Direct-to-sink edge (schema §3.2: `to` may itself be a reserved sink).
    # No node to release, no lap budget to enforce — V7 only requires
    # maxLaps on an edge that CLOSES A CYCLE, and a sink has no outgoing
    # edge, so it can never be part of one. Every occurrence of this cause
    # on this node goes straight to the sink.
    if raw_target in RESERVED_SINKS:
        sink_kind = "stalled" if raw_target == _SINK_STALLED else "humanGate"
        edge_label = f"{from_key}->{raw_target}"
        reason = (f"chart {chart.chart_id} edge {edge_label} routes {cause} "
                  f"directly to {raw_target}")
        handled = _apply_sink(order_id, sink_kind, chart, edge_label, role,
                               role, crew_num, crew_state, ws, reason)
        return _consume_if_handled(order_id, role, cause, ws, handled)

    target_node = chart.nodes.get(raw_target)
    if target_node is None:
        # V3 would have caught a dangling edge target at validation time;
        # defensive only — never crash a live dispatch on a bad chart file.
        return False
    to_role = target_node.role
    edge_label = f"{from_key}->{raw_target}"

    ledger_view = _order_ledger.load_view(ws)
    current_laps = ledger_view.lap_count(order_id, edge_label)
    # An onFail edge that does not close a cycle (a one-way reroute, e.g.
    # straight to a terminal node) is never required to declare maxLaps
    # (V7) — it can structurally never be traversed a second time for the
    # same order, so a single-lap default is exactly "always route, this
    # can't repeat" rather than an arbitrary cap.
    max_laps = edge.max_laps if edge.max_laps is not None else 1

    if current_laps >= max_laps:
        reason = (f"chart {chart.chart_id} edge {edge_label} exhausted its "
                  f"maxLaps ({max_laps}) for cause {cause}")
        _write_event("LAP_EXHAUSTED", f"{order_id} {reason}")
        handled = _apply_sink(order_id, edge.on_exhausted, chart, edge_label,
                               role, to_role, crew_num, crew_state, ws, reason)
        return _consume_if_handled(order_id, role, cause, ws, handled)

    # BUG-MSO-2026-0551 Finding 2: _apply_lap's return value now means "I
    # actually released the target order" — propagate it. Returning True
    # here unconditionally (the old behaviour) told the caller "the chart
    # handled this" even when nothing was written (e.g. the target order has
    # no live queue file), which suppressed the caller's own hold/requeue
    # and stranded the failing order at IN_PROGRESS forever with no
    # operator-visible signal. False lets the caller's default path run.
    handled = _apply_lap(order_id, chart, target_node, to_role, edge_label,
                          current_laps, max_laps, ws, edge.carry, role,
                          verify_log_path)
    return _consume_if_handled(order_id, role, cause, ws, handled)


def _consume_if_handled(order_id: str, role: str, cause: str, ws: Path,
                         handled: bool) -> bool:
    """BUG-MSO-2026-0558 Finding 1 (BLOCKING): consume the report's
    ``nodeVerdict`` field ONLY once *handled* confirms the routing outcome
    actually took effect (an order was released, or a sink write actually
    landed) — never merely because an edge matched.

    The round-1 fix (BUG-MSO-2026-0551 Finding 3) consumed unconditionally,
    the instant an edge matched, before ``_apply_lap``/``_apply_sink`` had
    even run. That is the defect: if the write then failed (target order
    archived/unwritable, review-queue write hits an OSError, ...),
    ``route_failure`` returns ``False`` — telling the caller "run your
    default hold/requeue" — but the FAIL verdict had already been erased.
    The caller's default path has no idea a rejection ever happened, so the
    order proceeds through its ordinary roleSequence advance exactly as if
    TST/SEC had approved it. A rejection silently became an approval.

    Rejected the alternative of making consume-and-route a single atomic
    write: the verdict lives in a DIFFERENT file (the role's report, e.g.
    ``reports/qa/QA-{oid}.md``) than the one ``_apply_lap``/``_apply_sink``
    write (the order JSON, possibly for a different target order entirely
    in the lap case) — there is no single filesystem transaction that could
    cover both without a two-phase-commit protocol this codebase has nowhere
    else, for a best-effort, defensively-wrapped module that must never
    raise. Sequencing the consume strictly AFTER a confirmed-successful
    write gets the same guarantee (a FAIL verdict is never lost while its
    routing outcome is unknown or failed) with no new failure mode: the
    single window this leaves open — the process dying between a
    successful write and this consume call — reproduces the ALREADY-ACCEPTED
    pre-existing risk of a stale verdict re-firing once more (Finding 3's own
    documented worst case), never a silent approval, because a route that
    never got its outcome recorded also never advanced the order.

    A passing re-run must still not re-fire the same edge a second time
    (Finding 3's own regression guard) — that holds here unchanged, since
    the only path that reaches this function with ``handled=True`` is one
    where the edge's write already landed, which is exactly when consumption
    is required to prevent a second, stale fire.
    """
    if handled and cause == CAUSE_VERDICT_FAIL:
        _consume_node_verdict(order_id, role, ws)
    return handled


def _apply_lap(order_id: str, chart: ChartSpec, target_node: ChartNode,
                to_role: str, edge_label: str, current_laps: int,
                max_laps: int, ws: Path, carry_kind: str, from_role: str,
                verify_log_path: Optional[Path]) -> bool:
    """§4.2 step 4: resolve carry, record the lap, and release the target
    node's order. Reuses ``fleet_runner.release_order_to_pending`` — the
    SAME BUG-0499 writer ``chart_scheduler``'s onSuccess frontier uses — so
    an onFail lap and an onSuccess release are indistinguishable to every
    downstream gate (plan §4.4's own argument, extended to failure edges).
    The failing node's own work is untouched here — the caller
    (fleet_runner) is responsible for salvage-preserving it BEFORE calling
    :func:`route_failure`, exactly as it already does for the plain
    VERIFY_FAILED hold.

    ``carriedContext`` (plan §4.3) is appended to the target order's own
    ``data`` dict BEFORE :func:`~maestro.core.fleet_runner.
    release_order_to_pending` writes it — one JSON write, not two — so a
    write failure can never leave status/targetRole released with the carry
    silently dropped, or vice versa.

    Returns ``True`` iff the target order was actually released — the
    caller (``route_failure``) propagates this straight through as its own
    return value (BUG-MSO-2026-0551 Finding 2). ``False`` means nothing was
    written: no lap is recorded (the budget is not spent on a no-op) and no
    ``LAPPED`` event fires, so a later retry of the same edge still sees the
    pre-attempt lap count.
    """
    from maestro.core.fleet_runner import _find_order_json_file, release_order_to_pending

    new_lap = current_laps + 1
    released = False
    carried = False
    json_file = _find_order_json_file(target_node.order, ws)
    if json_file is None:
        _write_event(
            "WARN",
            f"{order_id} chart {chart.chart_id} edge {edge_label} could not "
            f"lap — target order {target_node.order} has no live queue file "
            f"(already archived/skipped/missing); nothing released, no lap "
            f"spent — falling back to default hold/requeue"
        )
        return False
    try:
        data = json.loads(json_file.read_text(encoding="utf-8"))
        carry_entry = _resolve_carry(
            order_id, from_role, to_role, carry_kind, new_lap, ws,
            verify_log_path)
        if carry_entry is not None:
            existing = data.get("carriedContext")
            if not isinstance(existing, list):
                existing = []
            existing.append(carry_entry)
            data["carriedContext"] = existing
            carried = True
        released = release_order_to_pending(
            json_file, data, target_node.order, target_role=to_role)
    except Exception:
        released = False

    if not released:
        _write_event(
            "WARN",
            f"{order_id} chart {chart.chart_id} edge {edge_label} could not "
            f"lap — release_order_to_pending failed writing "
            f"{target_node.order}; nothing released, no lap spent — "
            f"falling back to default hold/requeue"
        )
        return False

    # Best-effort ledger writes — a chart failure must never crash the
    # dispatcher (plan "Notes for Builder"); both writers already swallow
    # their own I/O errors, this is belt-and-braces around the caller side.
    try:
        _order_ledger.record_lapped(order_id, edge_label, new_lap, max_laps,
                                     workspace_dir=ws)
    except Exception:
        pass
    try:
        # BUG-MSO-2026-0551 Finding 1: without this, the ledger's `roles`
        # map still remembers the FAILING role from its own CLAIMED event
        # (the dispatcher always records one when it launches a crew), so
        # scan_all_queues's BUG-0248 advance-loss guard sees the file's
        # freshly-lapped targetRole disagree with the ledger's stale role
        # and overrides it straight back — the lap silently reverts on the
        # very next scan. Recording ADVANCED here is exactly what every
        # ordinary roleSequence advance already does for the same guard;
        # an onFail lap is no different from that guard's point of view.
        _order_ledger.record_advanced(target_node.order, from_role, to_role,
                                      workspace_dir=ws)
    except Exception:
        pass

    # BUG-MSO-2026-0607 finding 5: a CROSS-ORDER lap (the edge's target node
    # belongs to a DIFFERENT order than the one that just failed) only ever
    # writes the TARGET order's file above — the FAILING order's own queue
    # file is never touched, so it is left at IN_PROGRESS with `assignedTo`
    # still set. `route_failure` returning True tells every caller "do not
    # also run your own default hold/requeue for this event", so nothing
    # else releases it either — it is only recovered once the orphan scan
    # eventually notices the stale claim and re-dispatches the same failing
    # role, which is exactly the delay/staleness this fix closes. A
    # same-order lap (the ordinary case, e.g. TST -> BLD within one order)
    # needs no extra write: `released` above already flipped THIS order's
    # own file to PENDING/targetRole=to_role.
    if target_node.order != order_id:
        _release_stranded_failing_order(order_id, from_role, chart, edge_label, ws)

    _write_event(
        "LAPPED",
        f"{order_id} chart {chart.chart_id} edge {edge_label} lap "
        f"{new_lap}/{max_laps} — {target_node.order}:{to_role} released to "
        f"PENDING (released={released}, carried={carried})"
    )
    return True


def _release_stranded_failing_order(order_id: str, from_role: str, chart: ChartSpec,
                                     edge_label: str, ws: Path) -> None:
    """BUG-MSO-2026-0607 finding 5: release the FAILING order's own claim and
    queue file back to PENDING at the role it just failed, instead of
    leaving it stranded IN_PROGRESS for the orphan scan to eventually
    recover. Reuses ``fleet_runner.release_order_to_pending`` — the SAME
    BUG-0499 writer every other release in this module goes through — rather
    than a second hand-rolled write, so this also gets that writer's own
    BUG-MSO-2026-0557 Finding 1 fix (clearing a stale ``roleSucceededAt``/
    ``roleSucceededBy`` checkpoint) for free: the VERIFY_FAILED cause reaches
    this AFTER ``_mark_role_succeeded`` has already checkpointed *order_id*
    for this crew's own COMPLETE-reported iteration, so its file can carry a
    checkpoint that would otherwise misdescribe a role that has not, in
    fact, finished.

    Best-effort throughout — a chart failure must never crash the
    dispatcher, and this is cleanup around a lap that has already
    successfully landed for the target order; a failure here must never be
    reported as a lap failure."""
    try:
        from maestro.core.fleet_runner import _find_order_json_file, release_order_to_pending
        json_file = _find_order_json_file(order_id, ws)
        if json_file is None:
            return
        data = json.loads(json_file.read_text(encoding="utf-8"))
        data.pop("assignedTo", None)
        data.pop("startedAt", None)
        if not release_order_to_pending(json_file, data, order_id, target_role=from_role):
            return
    except Exception:
        return
    try:
        _order_ledger.record_released(
            order_id,
            f"cross-order lap: chart {chart.chart_id} edge {edge_label} routed "
            f"failure onward to a different order — releasing this order's own "
            f"claim instead of leaving it stranded IN_PROGRESS",
            workspace_dir=ws,
        )
    except Exception:
        pass
    _write_event(
        "WARN",
        f"{order_id} released back to PENDING/{from_role} after a cross-order "
        f"chart lap (edge {edge_label}) routed the failure to a different "
        f"order — not left stranded IN_PROGRESS for the orphan scan "
        f"(BUG-MSO-2026-0607 finding 5)"
    )


# ---------------------------------------------------------------------------
# carry — resolve edge.carry (plan §4.3) to a carriedContext entry
# ---------------------------------------------------------------------------

def _resolve_carry(order_id: str, from_role: str, to_role: str,
                    carry_kind: str, lap: int, ws: Path,
                    verify_log_path: Optional[Path]) -> Optional[Dict[str, Any]]:
    """Resolve *carry_kind* to a ``carriedContext`` entry, or ``None``.

    ``"none"`` (the default — an edge with no ``carry`` field) never
    produces an entry; that is ordinary lap routing with nothing to carry,
    not a degradation. Any other kind resolves to an artefact-plane path; a
    MISSING artefact degrades explicitly (plan §4.3: "Degradation is
    explicit... It never injects a truncated tail — silently carrying
    garbage is worse than carrying nothing") — emits ``CARRY_DEGRADED``
    naming the kind and the path that was not found, and returns ``None`` so
    the caller carries nothing rather than fabricating a substitute.
    """
    if not carry_kind or carry_kind == "none":
        return None

    path = _carry_artefact_path(carry_kind, order_id, from_role, to_role, ws,
                                 verify_log_path)
    if path is None or not path.is_file():
        _write_event(
            "CARRY_DEGRADED",
            f"{order_id} carry kind '{carry_kind}' (from {from_role}) — "
            f"artefact not found at "
            f"{path if path is not None else '<no resolvable path>'} — "
            f"carrying nothing into lap {lap}"
        )
        return None

    from maestro.core import charts as _charts
    try:
        rel_path = path.relative_to(ws).as_posix()
    except ValueError:
        rel_path = path.as_posix()

    return {
        "kind": carry_kind,
        "fromNode": _charts.node_id(order_id, from_role),
        "path": rel_path,
        "lap": lap,
    }


def _carry_artefact_path(carry_kind: str, order_id: str, from_role: str,
                          to_role: str, ws: Path,
                          verify_log_path: Optional[Path]) -> Optional[Path]:
    """Per-kind path resolution (plan §4.3's table).

    ``verifyLog`` prefers the log the caller already persisted for THIS
    failure (*verify_log_path*, threaded through from the
    ``VERIFY_FAILED`` call site); absent that, it falls back to the newest
    persisted ``VERIFY-{order_id}-*.log`` under ``reports/verify/`` — e.g.
    for a ``VERDICT_FAIL`` edge that also declares ``carry: verifyLog``
    (unusual, but not forbidden by the schema). ``qaReport`` and
    ``handoff`` resolve to the fixed artefact-plane locations those roles
    already write to (BLD.md/TST.md's own OUTPUT tables), keyed on
    *order_id* — the source node's order, since that is whose report/handoff
    the failing role produced.
    """
    if carry_kind == "verifyLog":
        if verify_log_path is not None:
            return Path(verify_log_path)
        return _latest_verify_log(order_id, ws)
    if carry_kind == "qaReport":
        return ws / "reports" / "qa" / f"QA-{order_id}.md"
    if carry_kind == "handoff":
        return ws / "handoffs" / order_id / f"{from_role}-to-{to_role}.md"
    return None


def _latest_verify_log(order_id: str, ws: Path) -> Optional[Path]:
    """Newest ``VERIFY-{order_id}-*.log`` under ``reports/verify/`` — the
    persisted-log filename timestamp (``%Y%m%dT%H%M%S``,
    ``_persist_verify_log``) sorts lexicographically in time order, so the
    max of a plain name sort is the most recent. Returns ``None`` when the
    directory or no matching file exists — the caller then treats this the
    same as any other missing artefact (``CARRY_DEGRADED``)."""
    log_dir = ws / "reports" / "verify"
    if not log_dir.is_dir():
        return None
    candidates = sorted(log_dir.glob(f"VERIFY-{order_id}-*.log"))
    return candidates[-1] if candidates else None


def _apply_sink(order_id: str, sink_kind: str, chart: ChartSpec,
                 edge_label: str, from_role: str, to_role: str,
                 crew_num: int, crew_state: Dict[str, Any], ws: Path,
                 reason: str) -> bool:
    """Returns ``True`` iff the sink action actually wrote something —
    propagated by the caller (BUG-MSO-2026-0558 Finding 1) so a verdict is
    only ever consumed once its routing outcome is confirmed, the same
    discipline Finding 2 already established for ``_apply_lap``."""
    if sink_kind == "stalled":
        return _route_to_stalled(order_id, crew_num, crew_state, reason)
    return _route_to_human_gate(order_id, chart, edge_label, from_role,
                                 to_role, crew_num, ws, reason)


def _route_to_stalled(order_id: str, crew_num: int, crew_state: Dict[str, Any],
                       reason: str) -> bool:
    """``onExhausted: stalled`` (or a direct ``@stalled`` edge) — the
    existing ``archive_stalled_order`` path (plan §4.2 step 3), same as a
    BLOCKED/MAX_ITERATIONS escalation. ``stalled_cause="ERROR"`` per
    BUG-MSO-2026-0443's contract — this is not a MAX_ITERATIONS/BLOCKED/
    CIRCUIT_BREAKER status, so it must not take that default.

    Returns ``archive_stalled_order``'s own success bool (it already
    reports whether it found and archived the order)."""
    try:
        from maestro.core.fleet_runner import archive_stalled_order
        return bool(archive_stalled_order(order_id, crew_num, crew_state, reason,
                                           stalled_cause="ERROR"))
    except Exception:
        return False


def _route_to_human_gate(order_id: str, chart: ChartSpec, edge_label: str,
                          from_role: str, to_role: str, crew_num: int,
                          ws: Path, reason: str) -> bool:
    """``onExhausted: humanGate`` (or a direct ``@humanGate`` edge) — parks
    the order in ``queues/review/`` as ``NAV_REVIEW_PENDING`` using the same
    fields/directory ``_maybe_hold_transition_for_review`` writes (plan
    §4.2 step 3: "the existing _maybe_hold_transition_for_review machinery
    ... mso review approve|revise|reject works on it with zero changes"),
    applied unconditionally rather than via that function's gates.json
    lookup — a chart's ``onExhausted: humanGate`` is itself the author's
    explicit gate decision for this edge, a different (and orthogonal)
    mechanism from the per-transition config ``gates.json`` drives.

    Returns ``True`` iff the order was actually parked in the review queue —
    ``False`` for every early-return (no queue file, unreadable JSON, a
    write/unlink that raised ``OSError``)."""
    try:
        from maestro.core.fleet_runner import _find_order_json_file
    except Exception:
        return False
    json_file = _find_order_json_file(order_id, ws)
    if json_file is None:
        return False
    try:
        data = json.loads(json_file.read_text(encoding="utf-8"))
    except Exception:
        return False

    review_dir = ws / "queues" / "review"
    review_dir.mkdir(parents=True, exist_ok=True)
    data["status"] = "NAV_REVIEW_PENDING"
    data["targetRole"] = to_role or from_role
    data["reviewGate"] = f"{from_role}->{to_role}" if to_role and to_role != from_role else from_role
    data["reviewGateFrom"] = from_role
    data["reviewGateTo"] = to_role or from_role
    data["navReviewPausedAt"] = datetime.now().isoformat()
    data["chartHold"] = {"chartId": chart.chart_id, "edge": edge_label, "reason": reason}
    data.pop("assignedTo", None)
    data.pop("startedAt", None)
    # BUG-MSO-2026-0680 (F1): the same BUG-MSO-2026-0644 F1 gap on the
    # sibling non-chart hold branch (fleet_runner.py's own
    # _check_verdict_fail_at_role_completion, the "no ACTIVE chart routed
    # it" NAV_REVIEW_PENDING park) applies here too — a
    # roleSucceededAt/roleSucceededBy checkpoint can already be genuine
    # and set when this park runs (e.g. via _resume_finalization_guard,
    # BUG-MSO-2026-0641, whose call sites load `data` fresh AFTER
    # _mark_role_succeeded has already written it for `from_role`), and
    # review_core.approve_order() releases this order back to PENDING with
    # no field of its own to detect a stale checkpoint. Left attached, a
    # later crash's orphan scan would trust THIS rejected attempt's
    # checkpoint instead of the freshly re-dispatched crew's own — the
    # BUG-MSO-2026-0641 failure mode. Popped unconditionally (a no-op when
    # absent).
    data.pop("roleSucceededAt", None)
    data.pop("roleSucceededBy", None)

    review_file = review_dir / json_file.name
    try:
        review_file.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
        json_file.unlink()
    except OSError:
        return False

    # BUG-MSO-2026-0607 finding 3: unlike the lap path (record_advanced) and
    # @stalled (record_terminal, via archive_stalled_order), this park wrote
    # NO ledger event — leaving a dangling CLAIMED behind exactly like the
    # BUG-MSO-2026-0350 stale-claim WARN this PR fixes elsewhere. Release the
    # durable claim so the order is no longer "live-claimed" once parked for
    # human review. Best-effort: the write above already landed, so a ledger
    # failure here must not turn a successful park into a reported failure.
    try:
        _order_ledger.record_released(
            order_id,
            f"chart {chart.chart_id} edge {edge_label} routed to human review: {reason}",
            workspace_dir=ws,
        )
    except Exception:
        pass

    _write_event("NAV_REVIEW_PENDING",
                 f"{order_id} {reason} -> paused for human review (Crew {crew_num})")
    return True


# ---------------------------------------------------------------------------
# read_node_verdict — the nodeVerdict front-matter reader
# ---------------------------------------------------------------------------

def read_node_verdict(order_id: str, role: str,
                       workspace_dir: Optional[Path] = None) -> Optional[str]:
    """Read the ``nodeVerdict`` front-matter field from *role*'s report for
    *order_id* (plan §4.1). Returns the token (e.g. ``"FAIL"``) or ``None``
    if the role has no known report location, no candidate file exists, or
    none carries the field. Best-effort — any read/parse failure is treated
    as "no verdict", never raised.

    BUG-MSO-2026-0608: reviewed alongside :func:`route_failure`'s blanket
    except and deliberately kept silent, unlike that one. The difference is
    call frequency and what "no verdict" means: this function runs at EVERY
    role completion on EVERY order (fleet_runner's advance path calls it
    unconditionally before the ordinary roleSequence advance) and "no file /
    no field" is the overwhelmingly common, entirely legitimate case — most
    completions never write a REJECTED sign-off. Logging on every miss would
    flood the lifecycle log with noise on the routine path, drowning out the
    genuinely rare signal. Nothing this function's own try/except can catch
    represents a malformed CHART the way findings 6/7 did — it never reads
    chart files at all, only a role's own report; the only exception paths
    reachable here are ``_default_workspace_dir()`` raising (no
    *workspace_dir* passed and the process cwd has no workspace — every
    fleet_runner call site passes ``get_artefact_root()`` explicitly, so
    this is unreached in practice) and read/parse failures already caught
    one layer down by :func:`_parse_node_verdict_frontmatter`.

    BUG-MSO-2026-0607 finding 0: guarded by ``charts_enabled()`` exactly like
    :func:`route_failure`, so a chartless workspace is structurally inert
    here too. Before this fix, the only reason this function was a no-op on
    a flag-off workspace was that no report happened to carry a
    ``nodeVerdict`` field — off-by-absence-of-data, not off-by-flag. A
    copied template, a doc example, or a crew writing the field
    speculatively would have read a real ``"FAIL"`` back on a workspace that
    never opted into charts."""
    if not _chart_scheduler.charts_enabled():
        return None
    return read_node_verdict_unguarded(order_id, role, workspace_dir)


def read_node_verdict_unguarded(order_id: str, role: str,
                                 workspace_dir: Optional[Path] = None) -> Optional[str]:
    """:func:`read_node_verdict` without the ``charts_enabled()`` gate.

    BUG-MSO-2026-0705: the DEFAULT (chart-less) pipeline now reads the same
    ``nodeVerdict: FAIL`` sign-off TST/SEC already write, to route a role
    rejection back one role (``maestro/core/role_rejection.py``). That
    consumer must NOT be gated on ``charts.enabled`` — it is the whole point
    that it works on a workspace with no chart — but it must also not
    re-implement the front-matter reader or the per-role candidate table,
    which are this module's and would then drift. So the flag gate stays on
    :func:`read_node_verdict` (BUG-MSO-2026-0607 finding 0's guarantee for
    the CHART consumer is untouched) and the flag-independent body lives
    here, called by both.
    """
    try:
        ws = Path(workspace_dir) if workspace_dir is not None else _default_workspace_dir()
        for sub_dir, name_tpl in _VERDICT_CANDIDATES.get((role or "").upper(), ()):
            path = ws / Path(sub_dir) / name_tpl.format(oid=order_id)
            if not path.is_file():
                continue
            verdict = _parse_node_verdict_frontmatter(path)
            if verdict:
                return verdict
    except Exception:
        pass
    return None


def verdict_report_path(order_id: str, role: str, ws: Path) -> Optional[Path]:
    """The first existing verdict-report candidate for ``(order_id, role)``,
    or ``None``. BUG-MSO-2026-0705: lets ``role_rejection`` name the report
    it read the verdict from (for the operator note and the carried prompt
    context) without owning a second copy of ``_VERDICT_CANDIDATES``."""
    try:
        for sub_dir, name_tpl in _VERDICT_CANDIDATES.get((role or "").upper(), ()):
            path = ws / Path(sub_dir) / name_tpl.format(oid=order_id)
            if path.is_file():
                return path
    except Exception:
        pass
    return None


def consume_node_verdict(order_id: str, role: str, ws: Path) -> None:
    """Public alias of :func:`_consume_node_verdict` (BUG-MSO-2026-0705).

    A default-pipeline rejection lap has exactly the same stale-verdict
    problem a chart lap does — the report is not rewritten by the lap, so
    without consumption the same ``FAIL`` re-fires at the next role
    completion. Same invariant, same writer, one implementation.
    """
    _consume_node_verdict(order_id, role, ws)


def _parse_node_verdict_frontmatter(path: Path) -> Optional[str]:
    """Minimal ``key: value`` front-matter reader scoped to the single
    ``nodeVerdict`` field — mirrors the lightweight style
    ``fleet_monitor._read_md_frontmatter`` / ``hooks.stop.parse_yaml_
    frontmatter`` already use for their own markdown artefacts (each module
    keeps its own small copy rather than a shared dependency; a real YAML
    parser would be overkill for a single enum token)."""
    try:
        lines = path.read_text(encoding="utf-8").splitlines()[:15]
    except Exception:
        return None
    if not lines or lines[0].strip() != "---":
        return None
    for line in lines[1:]:
        stripped = line.strip()
        if stripped == "---":
            break
        if ":" in stripped:
            key, _, value = stripped.partition(":")
            if key.strip() == "nodeVerdict":
                value = value.strip().strip("\"'")
                return value or None
    return None


# ---------------------------------------------------------------------------
# _consume_node_verdict — BUG-MSO-2026-0551 Finding 3: invalidate a FAIL
# verdict once it has been acted on, so a later role completion that reads
# a report the role never rewrote cannot re-fire the same onFail edge.
# ---------------------------------------------------------------------------

def _consume_node_verdict(order_id: str, role: str, ws: Path) -> None:
    """Stamp *role*'s report ``nodeVerdict`` field CONSUMED for *order_id*,
    right after a ``VERDICT_FAIL`` cause has been matched to an onFail edge
    (called from :func:`_route_failure_inner`, unconditionally on the
    branch taken). Best-effort — a write failure here must never crash the
    dispatcher; the worst case is simply the pre-fix behaviour (a stale FAIL
    can re-fire once more before something eventually rewrites the report).
    """
    try:
        for sub_dir, name_tpl in _VERDICT_CANDIDATES.get((role or "").upper(), ()):
            path = ws / Path(sub_dir) / name_tpl.format(oid=order_id)
            if path.is_file() and _rewrite_verdict_consumed(path):
                return
    except Exception:
        pass


def _rewrite_verdict_consumed(path: Path) -> bool:
    """Rewrite the ``nodeVerdict: FAIL`` front-matter line in *path* to
    ``nodeVerdict: CONSUMED`` in place — everything else in the file
    (including the rest of the front-matter and the report body) is left
    byte-identical. Returns ``True`` iff the field was found and rewritten.
    Mirrors :func:`_parse_node_verdict_frontmatter`'s own line-scoped,
    15-line-cap reading style rather than a full YAML round-trip."""
    try:
        lines = path.read_text(encoding="utf-8").splitlines(keepends=True)
    except Exception:
        return False
    if not lines or lines[0].strip() != "---":
        return False
    for i, line in enumerate(lines[1:16], start=1):
        stripped = line.strip()
        if stripped == "---":
            break
        if ":" in stripped:
            key, _, _ = stripped.partition(":")
            if key.strip() == "nodeVerdict":
                newline = "\n" if line.endswith("\n") else ""
                lines[i] = f"nodeVerdict: CONSUMED{newline}"
                try:
                    path.write_text("".join(lines), encoding="utf-8")
                    return True
                except Exception:
                    return False
    return False
