# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Shared order-status vocabulary + effective-status resolution.

Why this module exists (BUG-MSO-2026-0699)
------------------------------------------
"What is this order's REAL status" is a three-plane question — runtime
order-ledger (git-immune, BUG-MSO-2026-0294) > archived order file
(orders/complete|failed) > live ledger claim > the queue/manifest status the
caller already has — and the answer is needed by four consumers that do not
share a layer:

- ``mso status``            (``maestro/core/fleet_monitor.py``)
- ``mso doctor``            (``maestro/patrol/checks/voyages.py``)
- the resident LEAD daemon  (via the same patrol checks)
- the Hub board             (``maestro/hub/phase.py``)

The resolution originally lived in ``maestro/hub/phase.py``, which made it
reachable only by importing the Hub from core — an inverted layer (core must
never depend on hub) and the reason BUG-MSO-2026-0699's deadlock classifier
could not simply reuse it. It now lives here, in core, and ``hub/phase.py``
re-exports every name verbatim so existing importers (and the Hub's own call
sites) are unchanged.

This module holds NO deadlock logic — see ``maestro/core/deadlock.py`` for
that. It answers only "what status is this order in, and which rollup bucket
does that status belong to".
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

# ---------------------------------------------------------------------------
# Status bucket classification
# ---------------------------------------------------------------------------

# Raw on-disk vocabulary AND the Hub's normalised contract statuses both appear
# here — effective statuses come from three different planes (ledger, archived
# files, queue files) and are not guaranteed to be pre-normalised.
COMPLETE_STATUSES = frozenset({
    "COMPLETE", "COMPLETED", "COMPLETE_PENDING_STAGING",
    "COMPLETE_WITH_CONDITIONS", "RELEASE_APPROVED",
})
BLOCKED_STATUSES = frozenset({
    "STALLED", "FAILED", "CONVERGENCE_FAILED", "VERIFY_FAILED",
    "AUTO_SERIALIZE", "BLOCKED",
})
IN_PROGRESS_STATUSES = frozenset({
    "RUNNING", "IN_PROGRESS", "CLAIMED", "DISPATCHED", "ACTIVE",
})
HELD_STATUSES = frozenset({
    "NAV_REVIEW_PENDING", "AWAITING_APPROVAL", "ON_HOLD", "HOLD", "HELD",
    "BACKLOG", "SKIPPED", "REJECTED",
    # BUG-MSO-2026-0499: PROPOSED is the standalone-plan-review-gate default a
    # dependent order carries until its dependsOn is satisfied; scan_all_queues
    # only ever dispatches status=="PENDING", so a PROPOSED order is invisible
    # to the dispatcher and cannot be "pending" (dispatchable-soon) work — it
    # needs its own dependsOn released (auto_queue_unblocked_orders /
    # promote_ready_dependents) or a human review approval before it can ever
    # be picked up. Bucketing it as "held" (not the "pending" fallthrough)
    # stops it from being miscounted as fleet-advanceable pending work.
    "PROPOSED",
})
# HELD was previously missing here — only "HOLD" was recognised, so an order
# whose status literally read "HELD" (the operator/dep-gate hold convention
# documented at docs/TROUBLESHOOTING.md#e09) fell through to "pending"
# instead of "held" (BUG-MSO-2026-0499).
# Everything else (PENDING, REQUEUE, REOPENED, MAX_TURNS, unknown) → pending.


def classify_status(status: Optional[str]) -> str:
    """Map an effective order status onto a rollup bucket name.

    One of ``complete`` | ``blocked`` | ``inProgress`` | ``held`` | ``pending``.
    """
    s = (status or "PENDING").strip().upper()
    if s in COMPLETE_STATUSES:
        return "complete"
    if s in BLOCKED_STATUSES:
        return "blocked"
    if s in IN_PROGRESS_STATUSES:
        return "inProgress"
    if s in HELD_STATUSES:
        return "held"
    return "pending"


# ---------------------------------------------------------------------------
# Effective per-order status (ledger + archive + queue)
# ---------------------------------------------------------------------------

def load_json_safe(path: Path) -> Optional[dict]:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def load_ledger_view(mso: Path):
    """Replay the runtime order ledger; None when absent or unreadable."""
    try:
        from maestro.core.order_ledger import load_view
        return load_view(mso)
    except Exception:
        return None


def read_archive_statuses(mso: Path) -> "dict[str, str]":
    """Index archived order statuses by id from orders/complete + orders/failed.

    The archive DIRECTORY is only the default — the file's own ``status``
    wins when present, because BUG-MSO-2026-0296 established that files in
    orders/complete can legitimately carry STALLED.
    """
    out: "dict[str, str]" = {}
    for sub, default in (("complete", "COMPLETE"), ("failed", "FAILED")):
        d = mso / "orders" / sub
        if not d.is_dir():
            continue
        for f in d.glob("*.json"):
            data = load_json_safe(f) or {}
            oid = data.get("orderId") or data.get("id") or f.stem
            out[str(oid)] = str(data.get("status") or default).strip().upper()
    return out


def effective_order_status(
    order_id: str,
    fallback_status: Optional[str],
    ledger_view,
    archive_statuses: "dict[str, str]",
) -> str:
    """Resolve one order's effective status (uppercase).

    Precedence: ledger TERMINAL verdict (git-immune truth) > archived order
    file > live ledger claim (a crew is on it right now) > the queue/manifest
    status the caller already has.
    """
    if ledger_view is not None:
        try:
            if ledger_view.is_terminal(order_id):
                return str(ledger_view.terminal.get(order_id) or "COMPLETE").upper()
        except Exception:
            pass
    if order_id in archive_statuses:
        return archive_statuses[order_id]
    if ledger_view is not None:
        try:
            if ledger_view.live_claim(order_id):
                return "RUNNING"
        except Exception:
            pass
    return (fallback_status or "PENDING").strip().upper()
