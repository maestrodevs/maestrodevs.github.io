# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""maestro/core/role_rejection.py — BUG-MSO-2026-0705: a QA rejection is a
routable event, not a dead end.

Two defects, one module.

**(A) Misreporting.** ``fleet_runner.archive_stalled_order`` chose a STALLED
order's ``operatorNote`` from ONE fact — "was the crew's work converged?" —
and said *"already on the voyage branch, no recovery needed"* whenever it
was. For a ``stalledCause=BLOCKED_BY_ROLE`` stall that sentence is exactly
backwards: the work is merged AND rejected, and the recovery (a BLD pass
against the named defect) is precisely what IS needed. On 2026-09-09 an
operator reading `mso status` on BUG-MSO-2026-0701 saw *STALLED (BLOCKED) —
no recovery needed* while a TST crew's 62 tests, a strict xfail encoding the
defect, and a precise fix brief sat three files away. :func:`build_operator_note`
makes the note cause-aware, so "no recovery needed" is never written for a
cause that needs recovery.

**(B) No self-correction.** Charts Phase 2 already defines the exact
mechanism for routing a typed failure back one role — an ``onFail`` edge, a
``maxLaps`` ceiling, ledger-durable lap counts, ``LAPPED`` /
``LAP_EXHAUSTED`` events, ``carry: qaReport``. But ``charts.enabled``
defaults false, so on every default workspace a TST ``FAIL`` verdict has no
route back to BLD at all: every rejection is a human-gated stall, even when
the QA report is machine-readable. :func:`maybe_auto_lap` gives the default
pipeline the SAME bounded behaviour for the one transition that provably
needs it — one lap back to the previous role carrying the QA report, then a
stall for a human on the second rejection.

Design rules this module holds itself to:

* **Reuse the Phase 2 bookkeeping, do not reinvent it.** Lap counts go
  through ``order_ledger.record_lapped`` / ``LedgerView.lap_count`` — the
  same git-immune, compaction-aware store chart laps use, so a lap survives
  a ``git reset --hard`` exactly as ``terminal``/``claimed`` do. The release
  itself goes through ``fleet_runner.release_order_to_pending``, the shared
  BUG-MSO-2026-0499 writer (which also clears the stale
  ``roleSucceededAt`` checkpoint a BACKWARD lap would otherwise strand —
  BUG-MSO-2026-0557 Finding 1, a bug this module would have reintroduced
  wholesale with a hand-rolled write). The carried evidence goes into
  ``carriedContext``, rendered by ``generate_prompt_for_item``'s existing
  ``## Carried Context`` section.
* **A chart still wins.** When ``charts.enabled`` is true and the failing
  node has a matching ``onFail`` edge, :func:`maybe_auto_lap` hands the
  rejection to ``chart_routing.route_failure`` and defers to whatever it
  decides. The author's chart is the more specific instruction; this
  module is the default for workspaces that have not written one.
* **Evidence, not inference.** A lap fires only on an explicit
  ``nodeVerdict: FAIL`` front-matter block (the sign-off TST.md already
  mandates on REJECTED) plus at least one blocking defect parsed out of the
  report's own ``## Defects Found`` table. A crew that is genuinely blocked
  on its environment writes no such verdict and stalls immediately, with
  the reason lifted from its handoff — never lapped into a rebuild that
  cannot help.
* **Never raises.** Every public entry point is defensively wrapped: a
  malformed report, an unreadable ledger or a missing handoff degrades to
  "no rejection detected" (i.e. today's behaviour), never a dispatcher
  crash.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

from maestro.core import chart_routing as _chart_routing
from maestro.core import order_ledger as _order_ledger
from maestro.core import role_history as _role_history

# ---------------------------------------------------------------------------
# Config — completion.roleRejection
# ---------------------------------------------------------------------------

#: Default for ``completion.roleRejection.autoLap``. TRUE: a rejection that
#: names a blocking defect is a machine-actionable instruction, and the
#: manual recovery it replaces (read the QA report, write the defect into
#: the description, ``mso order retry --role BLD``) is exactly what a lap
#: does — the LEAD was already performing it by hand, one order at a time.
AUTO_LAP_DEFAULT = True

#: Default for ``completion.roleRejection.maxLaps``. ONE: the first
#: rejection is a defect the fleet can plausibly fix from the brief it was
#: handed; a SECOND rejection of the same order means the brief was not
#: enough, and grinding further burns crew budget on a problem that has
#: already demonstrated it needs a human. Matches the ceiling a hand-authored
#: chart edge would most commonly declare.
MAX_LAPS_DEFAULT = 1

#: Ledger edge-label namespace. Deliberately distinct from a chart's
#: ``"{fromNode}->{toNode}"`` labels so a workspace that later adopts a
#: chart over the same transition starts from a fresh, independent lap
#: budget instead of silently inheriting one spent by the default pipeline
#: (two different authors' ceilings, two different counters).
EDGE_PREFIX = "roleRejection"

_CONFIG_DEFAULTS = {"autoLap": AUTO_LAP_DEFAULT, "maxLaps": MAX_LAPS_DEFAULT}


def load_config(ws: Optional[Path] = None) -> Dict[str, Any]:
    """Read ``completion.roleRejection`` from *ws*'s ``config/workspace.json``.

    Read fresh on every call and uncached, matching ``load_charts_config``'s
    own reasoning: the flag must be observable mid-voyage without a
    dispatcher restart. An absent block, a non-dict block, or an unreadable
    file all resolve to the documented defaults — "config absent == the
    documented default behaviour", never "config absent == inert".
    """
    cfg = dict(_CONFIG_DEFAULTS)
    try:
        ws_path = Path(ws) if ws is not None else _default_workspace_dir()
        raw = json.loads((ws_path / "config" / "workspace.json").read_text(encoding="utf-8"))
        block = (raw.get("completion") or {}).get("roleRejection")
        if not isinstance(block, dict):
            return cfg
        if "autoLap" in block:
            cfg["autoLap"] = bool(block.get("autoLap"))
        max_laps = block.get("maxLaps")
        if isinstance(max_laps, bool):
            # `True` is an int in Python; a bool here is a config typo, not a
            # ceiling of 1. Fall back rather than silently honour it.
            pass
        elif isinstance(max_laps, int) and max_laps >= 0:
            cfg["maxLaps"] = max_laps
    except Exception:
        pass
    return cfg


def _default_workspace_dir() -> Path:
    from maestro.core.fleet_runner import get_artefact_root
    return get_artefact_root()


def _write_event(event_type: str, message: str) -> None:
    """Best-effort lifecycle write — never raises (same posture as
    ``chart_routing._write_event``)."""
    try:
        from maestro.core.fleet_runner import write_lifecycle_event
        write_lifecycle_event(event_type, message)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Defect-table parsing
# ---------------------------------------------------------------------------

#: A defect row's ID cell, tolerant of the two forms in the wild: TST.md's
#: template writes ``BUG-001``, real reports write ``DEF-001``. Bold markers
#: and backticks are stripped first.
_DEFECT_ID_RE = re.compile(r"^([A-Z][A-Z0-9]{1,15}-\d{1,4})$")

_DEFECTS_HEADING_RE = re.compile(r"^#{1,6}\s+defects?\s+found\b", re.IGNORECASE)
_HEADING_RE = re.compile(r"^#{1,6}\s+")

#: Severities that block sign-off when the report does not mark blocking
#: explicitly. ``H`` covers TST.md's ``{H/M/L}`` template shorthand.
_BLOCKING_SEVERITIES = frozenset({"CRITICAL", "HIGH", "H", "BLOCKER"})


def _strip_md(cell: str) -> str:
    """Strip the markdown emphasis/code markers a defect table routinely
    wraps its cells in (``**HIGH — BLOCKING**``, `` `file.py` ``).

    Only MATCHED wrappers are removed. A cell that merely STARTS with a
    marker — a description opening with an inline-code path, which is the
    common shape of a defect summary — keeps its text intact; stripping one
    end of an unmatched pair silently edits the operator's evidence.
    """
    text = cell.strip()
    for _ in range(3):
        for marker in ("**", "*", "_"):
            if len(text) > 2 * len(marker) and text.startswith(marker) and text.endswith(marker):
                text = text[len(marker): -len(marker)].strip()
                break
        else:
            break
    # A backtick pair is only a wrapper when it is the ONLY pair in the cell;
    # `a` and `b` is two inline spans, and unwrapping it would mangle the text.
    if len(text) > 2 and text.startswith("`") and text.endswith("`") and text.count("`") == 2:
        text = text[1:-1].strip()
    return text


@dataclass
class Defect:
    """One row of a QA report's ``## Defects Found`` table."""

    id: str
    severity: str
    summary: str
    file: str = ""
    line: str = ""
    blocking: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "severity": self.severity, "summary": self.summary,
            "file": self.file, "line": self.line, "blocking": self.blocking,
        }

    def one_line(self, max_len: int = 160) -> str:
        summary = " ".join(self.summary.split())
        if len(summary) > max_len:
            summary = summary[: max_len - 1].rstrip() + "…"
        return f"{self.id} ({self.severity}) {summary}" if self.severity else f"{self.id} {summary}"


def parse_defects(text: str) -> List[Defect]:
    """Parse the ``## Defects Found`` table out of a QA/security report.

    Scoped to that one section (from its heading to the next heading of any
    level) so an AC table, a test-summary table or a prose ``| a | b |``
    elsewhere in the report can never contribute a phantom defect. Rows are
    accepted only when the first cell parses as a defect id, which also
    skips the header and the ``|---|---|`` separator without special-casing
    either.

    **Blocking is decided in two tiers.** If ANY row marks itself blocking
    explicitly (``BLOCKING`` in the severity cell, and not ``NON-BLOCKING``),
    only the explicitly-marked rows block — the report's author has told us
    which ones matter, and a HIGH they deliberately did not mark is a HIGH
    they judged non-blocking. Only when no row marks itself at all does the
    severity fall back to deciding it (CRITICAL/HIGH/H/BLOCKER block;
    MEDIUM/LOW do not), which is what TST.md's ``{H/M/L}`` template produces.
    Getting this wrong in either direction is costly: over-reading turns a
    LOW documentation nit into an automatic rebuild, under-reading turns a
    genuine rejection into a silent stall.
    """
    defects: List[Defect] = []
    try:
        lines = text.splitlines()
    except Exception:
        return defects

    in_section = False
    for raw_line in lines:
        line = raw_line.rstrip()
        if _DEFECTS_HEADING_RE.match(line.strip()):
            in_section = True
            continue
        if in_section and _HEADING_RE.match(line.strip()):
            break  # next heading of any level ends the section
        if not in_section:
            continue
        stripped = line.strip()
        if not stripped.startswith("|"):
            continue
        cells = [c for c in stripped.strip("|").split("|")]
        if len(cells) < 3:
            continue
        did = _strip_md(cells[0])
        if not _DEFECT_ID_RE.match(did):
            continue
        severity = _strip_md(cells[1])
        summary = " ".join(_strip_md(cells[2]).split())
        file_cell = _strip_md(cells[3]) if len(cells) > 3 else ""
        line_cell = _strip_md(cells[4]) if len(cells) > 4 else ""
        defects.append(Defect(id=did, severity=severity, summary=summary,
                              file=file_cell, line=line_cell))

    explicit = [d for d in defects if _marks_blocking_explicitly(d.severity)]
    if explicit:
        for d in defects:
            d.blocking = _marks_blocking_explicitly(d.severity)
    else:
        for d in defects:
            d.blocking = _severity_token(d.severity) in _BLOCKING_SEVERITIES
    return defects


def _marks_blocking_explicitly(severity: str) -> bool:
    text = (severity or "").upper().replace("_", "-")
    if "NON-BLOCKING" in text or "NONBLOCKING" in text or "NOT BLOCKING" in text:
        return False
    return "BLOCKING" in text or "BLOCKER" in text


def _severity_token(severity: str) -> str:
    """The leading severity word of a cell like ``HIGH — BLOCKING`` or
    ``H``, upper-cased. Splits on the punctuation reports use to append a
    qualifier, so the qualifier never changes the severity."""
    text = (severity or "").upper()
    for sep in ("—", "–", "-", "/", ",", "("):
        text = text.split(sep)[0]
    return text.strip()


# ---------------------------------------------------------------------------
# Rejection detection
# ---------------------------------------------------------------------------

@dataclass
class Rejection:
    """A role's explicit ``nodeVerdict: FAIL`` sign-off for one order."""

    order_id: str
    role: str
    verdict: str
    report_path: Optional[Path] = None
    report_rel: str = ""
    handoff_rel: str = ""
    defects: List[Defect] = field(default_factory=list)

    @property
    def blocking_defects(self) -> List[Defect]:
        return [d for d in self.defects if d.blocking]

    @property
    def actionable(self) -> bool:
        """True iff this rejection carries a machine-readable instruction a
        rebuild could act on — a FAIL verdict AND at least one blocking
        defect. A FAIL with no defect table is a rejection a human must
        interpret, not one the fleet can route."""
        return self.verdict.upper() == "FAIL" and bool(self.blocking_defects)

    def headline(self) -> str:
        """``rejected by TST: DEF-001 (HIGH — BLOCKING) <summary>`` — the one
        line `mso status`, `mso doctor` and the Hub show in place of a bare
        ``STALLED`` (AC3)."""
        blocking = self.blocking_defects
        if blocking:
            first = blocking[0].one_line()
            more = f" (+{len(blocking) - 1} more)" if len(blocking) > 1 else ""
            return f"rejected by {self.role}: {first}{more}"
        return f"rejected by {self.role}: verdict FAIL, no blocking defect named"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "role": self.role,
            "verdict": self.verdict,
            "reportPath": self.report_rel,
            "handoffPath": self.handoff_rel,
            "defects": [d.to_dict() for d in self.defects],
            "blockingDefectIds": [d.id for d in self.blocking_defects],
            "headline": self.headline(),
            "detectedAt": datetime.now().isoformat(),
        }


def read_rejection(order_id: str, role: str,
                   ws: Optional[Path] = None) -> Optional[Rejection]:
    """Read *role*'s verdict sign-off for *order_id*, or ``None``.

    ``None`` means "no explicit rejection on disk" — no report, no
    ``nodeVerdict`` front-matter, or a verdict other than ``FAIL`` (an
    already-``CONSUMED`` one included, which is how a lap that has already
    fired is prevented from firing twice off the same report). Never raises.
    """
    try:
        ws_path = Path(ws) if ws is not None else _default_workspace_dir()
        verdict = _chart_routing.read_node_verdict_unguarded(order_id, role, ws_path)
        if not verdict or verdict.strip().upper() != "FAIL":
            return None
        report = _chart_routing.verdict_report_path(order_id, role, ws_path)
        defects: List[Defect] = []
        report_rel = ""
        if report is not None:
            report_rel = _rel_to(report, ws_path)
            try:
                defects = parse_defects(report.read_text(encoding="utf-8", errors="replace"))
            except Exception:
                defects = []
        return Rejection(
            order_id=order_id, role=(role or "").upper(), verdict="FAIL",
            report_path=report, report_rel=report_rel,
            handoff_rel=_find_handoff_rel(order_id, role, ws_path),
            defects=defects,
        )
    except Exception:
        return None


def _rel_to(path: Path, ws: Path) -> str:
    """*path* relative to the artefact root, forward-slashed. Falls back to
    the absolute path when it lies outside (never raises)."""
    try:
        return path.relative_to(ws).as_posix()
    except Exception:
        return str(path)


def _find_handoff_rel(order_id: str, role: str, ws: Path) -> str:
    """The newest ``handoffs/{ORDER-ID}/{ROLE}-to-*.md`` the rejecting role
    wrote, relative to the artefact root — ``""`` when it wrote none."""
    try:
        d = ws / "handoffs" / order_id
        if not d.is_dir():
            return ""
        matches = sorted(d.glob(f"{(role or '').upper()}-to-*.md"),
                         key=lambda p: p.stat().st_mtime)
        return _rel_to(matches[-1], ws) if matches else ""
    except Exception:
        return ""


def read_blocker_reason(order_id: str, role: str, ws: Path,
                        max_len: int = 400) -> str:
    """The blocking crew's own explanation, lifted from its handoff.

    AC4: a ``BLOCKED`` with no FAIL verdict is a crew genuinely stuck (a
    missing tool, an unreachable service, a decision only the operator can
    make) and must stall IMMEDIATELY with *that* reason in front of the
    operator — not a generic "BLOCKED". The crew's exit status carries no
    free-text reason (``crew.py`` records only the promise token), so the
    handoff it was told to write is where the reason actually lives.

    Prefers the first paragraph under a heading mentioning "block"; falls
    back to the document's first substantive paragraph. ``""`` when there is
    no handoff at all — which is itself worth saying to the operator, and
    :func:`build_operator_note` does.
    """
    try:
        rel = _find_handoff_rel(order_id, role, ws)
        if not rel:
            return ""
        text = (ws / rel).read_text(encoding="utf-8", errors="replace")
    except Exception:
        return ""

    paragraphs = _paragraphs_after_blocker_heading(text)
    if not paragraphs:
        paragraphs = _first_body_paragraphs(text)
    if not paragraphs:
        return ""
    reason = " ".join(paragraphs[0].split())
    if len(reason) > max_len:
        reason = reason[: max_len - 1].rstrip() + "…"
    return reason


def _paragraphs_after_blocker_heading(text: str) -> List[str]:
    lines = text.splitlines()
    for i, line in enumerate(lines):
        stripped = line.strip()
        if _HEADING_RE.match(stripped) and "block" in stripped.lower():
            body = []
            for follow in lines[i + 1:]:
                if _HEADING_RE.match(follow.strip()):
                    break
                body.append(follow)
            return _split_paragraphs("\n".join(body))
    return []


def _first_body_paragraphs(text: str) -> List[str]:
    lines = [ln for ln in text.splitlines()
             if not _HEADING_RE.match(ln.strip()) and not ln.strip().startswith("|")]
    return _split_paragraphs("\n".join(lines))


def _split_paragraphs(block: str) -> List[str]:
    out = []
    for chunk in re.split(r"\n\s*\n", block):
        chunk = chunk.strip()
        if chunk and not chunk.startswith("---"):
            out.append(chunk)
    return out


# ---------------------------------------------------------------------------
# Stamping the rejection onto the order JSON
# ---------------------------------------------------------------------------

def annotate_rejection(data: Dict[str, Any], rejection: Rejection) -> None:
    """Stamp *rejection* onto the order dict as a ``rejection`` block.

    Every downstream surface (the operator note, `mso status`,
    `mso doctor`, the Hub) then reads ONE parsed block off the order JSON
    rather than each re-parsing the markdown report — the report may have
    been rewritten, consumed or archived by the time they look, and three
    independent parsers would be three chances to disagree about what TST
    said.
    """
    try:
        data["rejection"] = rejection.to_dict()
    except Exception:
        pass


def rejection_block(data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """The stored ``rejection`` block, or ``None``. Tolerates a legacy or
    hand-edited order whose block is missing or the wrong type."""
    block = (data or {}).get("rejection")
    return block if isinstance(block, dict) else None


def describe_rejection(data: Dict[str, Any]) -> Optional[str]:
    """``"rejected by TST: DEF-001 (HIGH — BLOCKING) <summary>"`` for an
    order whose stall was a role rejection, else ``None`` (AC3).

    Shared by `mso status`, `mso doctor` and the Hub so all three say the
    same sentence — the alternative (three renderings of the same block)
    is how the Hub's review actions drifted from the CLI's in BUG-0486.
    """
    block = rejection_block(data)
    if not block:
        return None
    headline = block.get("headline")
    if isinstance(headline, str) and headline.strip():
        return headline.strip()
    role = block.get("role") or "?"
    ids = block.get("blockingDefectIds") or []
    if ids:
        return f"rejected by {role}: {', '.join(str(i) for i in ids)}"
    return f"rejected by {role}"


# ---------------------------------------------------------------------------
# Role sequence helpers
# ---------------------------------------------------------------------------

def previous_role(data: Dict[str, Any], role: str) -> Optional[str]:
    """The role immediately before *role* in the order's ``roleSequence``,
    or ``None`` when *role* is absent from it or is the first entry (there
    is nowhere to lap back TO — such an order stalls for a human)."""
    seq = (data or {}).get("roleSequence") or []
    if not isinstance(seq, list):
        return None
    role = (role or "").upper()
    upper = [str(r).upper() for r in seq]
    if role not in upper:
        return None
    idx = upper.index(role)
    return upper[idx - 1] if idx > 0 else None


def retry_command(order_id: str, data: Dict[str, Any],
                  rejecting_role: str = "") -> str:
    """The exact recovery command for this order's stall (AC1).

    A rejection's recovery is a re-run of the PREVIOUS role against the
    defect, with ``--no-salvage`` so the rebuild starts from the converged
    voyage branch rather than fast-converging a salvage branch that predates
    the rejection. Anything else is a plain retry.
    """
    role = rejecting_role or ((rejection_block(data) or {}).get("role") or "")
    prev = previous_role(data, role) if role else None
    if prev:
        return f"mso order retry {order_id} --role {prev} --no-salvage"
    return f"mso order retry {order_id}"


# ---------------------------------------------------------------------------
# (A) The cause-aware operator note
# ---------------------------------------------------------------------------

#: Per-cause recovery sentence. Keyed by ``stalledCause``; a cause absent
#: from this map keeps the pre-BUG-0705 note verbatim (see
#: :func:`build_operator_note`).
_CAUSE_SUMMARY = {
    "BLOCKED_BY_ROLE": "the {role} role declined to sign off",
    "MAX_ITERATIONS": "the order exhausted its iteration budget before finishing",
    "CIRCUIT_BREAKER": "the dispatcher's circuit breaker tripped on repeated failures",
    "ERROR": "the crew failed with zero progress",
}


def _work_location_clause(converged: bool, converged_into: str,
                          salvages: List[Dict[str, Any]]) -> str:
    """Where the crew's work ended up — merged, salvaged, or nowhere.

    BUG-MSO-2026-0301's point survives BUG-0705 intact: an operator seeing
    "STALLED, $0, 0 turns" read it as total loss while salvage branches held
    the full deliverable. What changes is only that saying where the work is
    no longer implies no recovery is needed.
    """
    if converged and converged_into:
        return f"Work is already merged into {converged_into} (nothing stranded on a salvage branch)."
    if salvages:
        newest = salvages[-1].get("branch", "?")
        return (f"Work preserved on {newest} "
                f"({len(salvages)} salvage branch(es) total).")
    return "No crew work was preserved — nothing was committed."


def build_operator_note(order_id: str, data: Dict[str, Any], *,
                        stalled_cause: str,
                        converged: bool,
                        converged_into: str = "",
                        salvages: Optional[List[Dict[str, Any]]] = None,
                        role: str = "",
                        reason: str = "",
                        ws: Optional[Path] = None) -> str:
    """The ``operatorNote`` for a STALLED order — chosen by ``stalledCause``
    AND convergence, not convergence alone (defect A).

    The pre-BUG-0705 note is preserved verbatim for any cause outside
    :data:`_CAUSE_SUMMARY` (including the bare ``"BLOCKED"`` string some
    callers and tests pass), so this fix cannot silently rewrite a note for
    a path it was not reasoned about.
    """
    salvages = salvages or []
    cause = (stalled_cause or "").upper()
    location = _work_location_clause(converged, converged_into, salvages)

    if cause not in _CAUSE_SUMMARY:
        # Pre-BUG-0705 behaviour, untouched.
        if converged:
            return (f"Work merged into {converged_into} before STALLED archival "
                    f"— already on the voyage branch, no recovery needed.")
        if salvages:
            newest = salvages[-1].get("branch", "?")
            return (f"Work preserved on {newest} "
                    f"({len(salvages)} salvage branch(es) total). "
                    f"Retry with: mso order retry {order_id}")
        return f"Retry with: mso order retry {order_id}"

    if cause == "BLOCKED_BY_ROLE":
        return _blocked_by_role_note(order_id, data, role=role, reason=reason,
                                     location=location, ws=ws)

    summary = _CAUSE_SUMMARY[cause].format(role=role or "crew")
    return (f"STALLED ({cause}) — {summary}. {location} "
            f"Recovery: `mso order retry {order_id}`")


def _blocked_by_role_note(order_id: str, data: Dict[str, Any], *, role: str,
                          reason: str, location: str,
                          ws: Optional[Path]) -> str:
    """The BLOCKED_BY_ROLE note — the one this bug was filed about.

    Two shapes, because a ``BLOCKED`` means two very different things:
    a QA REJECTION (a verdict with named defects — the fleet knows what to
    do next) and a genuine BLOCKER (the crew could not proceed — a human
    must clear the way). The note must never present one as the other.
    """
    role = (role or "").upper() or "the crew"
    block = rejection_block(data)

    if block:
        defects = [d for d in (block.get("defects") or []) if isinstance(d, dict)]
        blocking = [d for d in defects if d.get("blocking")]
        listed = "; ".join(
            f"{d.get('id', '?')} ({d.get('severity', '?')}) "
            f"{' '.join(str(d.get('summary', '')).split())}"
            for d in blocking[:3]
        ) or "no blocking defect was named in the report"
        if len(blocking) > 3:
            listed += f"; +{len(blocking) - 3} more"
        paths = []
        if block.get("reportPath"):
            paths.append(f"QA report: {block['reportPath']}")
        if block.get("handoffPath"):
            paths.append(f"handoff: {block['handoffPath']}")
        paths_text = (" " + ". ".join(paths) + ".") if paths else ""

        lap = block.get("lap")
        laps_text = ""
        if block.get("lapExhausted"):
            laps_text = (f" The automatic lap back to "
                         f"{block.get('lappedTo') or 'the previous role'} has already been "
                         f"used ({lap}/{block.get('maxLaps')}) — this is a repeat rejection "
                         f"and needs a human decision.")

        return (f"REJECTED by {role} — this order was NOT abandoned, it was "
                f"rejected on review: {listed}.{paths_text} {location}{laps_text} "
                f"Recovery: address the defect(s) above, then "
                f"`{retry_command(order_id, data, role)}`.")

    detail = ""
    if ws is not None:
        detail = read_blocker_reason(order_id, role, Path(ws))
    if detail:
        detail_text = f' The {role} crew reported: "{detail}"'
    else:
        detail_text = (f" No QA verdict and no {role} handoff were found on disk, so the "
                       f"crew's own reason is unrecorded — check "
                       f"`.mso/crews/` and the lifecycle log.")

    return (f"BLOCKED by {role} — a crew-reported blocker, NOT a QA rejection "
            f"(no `nodeVerdict: FAIL` sign-off on disk).{detail_text} {location} "
            f"Recovery: clear the blocker, then `mso order retry {order_id}`."
            + (f" (stall reason recorded as: {reason})" if reason and reason != "BLOCKED" else ""))


# ---------------------------------------------------------------------------
# (B) The auto-lap
# ---------------------------------------------------------------------------

#: Re-entrancy guard. ``chart_routing.route_failure``'s ``@stalled`` sink
#: calls ``archive_stalled_order`` — the very function that calls us — so
#: without this a chart whose onFail edge (or onExhausted) routes to
#: ``stalled`` would recurse: archive -> lap attempt -> chart -> archive.
#: The INNER call sees the id here, skips the lap attempt entirely and
#: archives normally; the outer call then returns without archiving a
#: second time.
_LAPPING_ORDERS: Set[str] = set()


def maybe_auto_lap(order_id: str, data: Dict[str, Any], json_file: Path,
                   crew_num: int, crew_state: Dict[str, Any],
                   ws: Path, *, rejection: Optional[Rejection] = None) -> bool:
    """Route a role rejection back one role instead of stalling it.

    Returns ``True`` iff the order has been handled here — released back to
    the previous role, or handed to a chart that handled it — in which case
    the caller must NOT archive it. ``False`` means "stall exactly as
    before", which is the answer for every case the fleet cannot act on by
    itself: auto-lap disabled, no FAIL verdict, no blocking defect, no
    previous role, or the lap budget already spent.

    Never raises: any failure below degrades to ``False``, i.e. today's
    stall.
    """
    if order_id in _LAPPING_ORDERS:
        return False
    _LAPPING_ORDERS.add(order_id)
    try:
        return _maybe_auto_lap_inner(order_id, data, json_file, crew_num,
                                     crew_state, ws, rejection)
    except Exception as exc:
        _write_event(
            "WARN",
            f"{order_id} role-rejection auto-lap aborted: {exc} — falling back "
            f"to the ordinary STALLED archival (BUG-0705)"
        )
        return False
    finally:
        _LAPPING_ORDERS.discard(order_id)


def _maybe_auto_lap_inner(order_id: str, data: Dict[str, Any], json_file: Path,
                          crew_num: int, crew_state: Dict[str, Any], ws: Path,
                          rejection: Optional[Rejection]) -> bool:
    role = (crew_state.get("role") or data.get("targetRole") or "").upper()

    # A chart is the more specific instruction. Hand the rejection to
    # chart_routing first and defer to whatever it decides — a workspace
    # that authored an onFail edge over this transition keeps ITS routing,
    # ITS maxLaps ceiling and ITS carry kind. On a chart-less workspace
    # (charts.enabled false, the default) this returns False immediately
    # without touching the filesystem.
    if rejection is not None and rejection.verdict.upper() == "FAIL":
        try:
            if _chart_routing.route_failure(
                    order_id, role, _chart_routing.CAUSE_VERDICT_FAIL,
                    crew_num=crew_num, crew_state=crew_state, workspace_dir=ws):
                _write_event(
                    "DISPATCH",
                    f"{order_id} {role} rejection routed by an active chart — "
                    f"default auto-lap stood down (BUG-0705)"
                )
                return True
        except Exception:
            pass

    # Deliberately checked AFTER the chart offer above: `autoLap` governs THIS
    # module's default-pipeline lap, not a chart. An operator who authored an
    # onFail edge has given an explicit routing instruction, and switching off
    # the default must not silently switch that off too.
    cfg = load_config(ws)
    if not cfg.get("autoLap", AUTO_LAP_DEFAULT):
        return False

    if rejection is None or not rejection.actionable:
        # AC4: a BLOCKED with no FAIL verdict (or a FAIL naming no blocking
        # defect) is a crew genuinely stuck, not a machine-actionable
        # rejection — it stalls immediately, as it always has.
        return False

    to_role = previous_role(data, role)
    if not to_role:
        _write_event(
            "WARN",
            f"{order_id} {role} rejected the work but has no earlier role in "
            f"roleSequence to lap back to — stalling for a human (BUG-0705)"
        )
        return False

    edge = f"{EDGE_PREFIX}:{role}->{to_role}"
    max_laps = int(cfg.get("maxLaps", MAX_LAPS_DEFAULT))
    current_laps = _order_ledger.load_view(ws).lap_count(order_id, edge)

    if current_laps >= max_laps:
        # Second rejection: the brief the fleet was handed was not enough.
        _stamp_lap_metadata(data, lap=current_laps, max_laps=max_laps,
                            to_role=to_role, exhausted=True)
        _write_event(
            "LAP_EXHAUSTED",
            f"{order_id} role-rejection edge {edge} exhausted its maxLaps "
            f"({max_laps}) — {role} rejected the work again; stalling for a "
            f"human (BUG-0705)"
        )
        return False

    new_lap = current_laps + 1

    # Everything the STALL path stamped on `data` before we were called is
    # now wrong — the order is going back into the queue, not to the
    # archive. Clear it rather than leaving a PENDING order carrying
    # stalledAt/stalledCause, which every status surface reads.
    for key in ("stalledAt", "stalledReason", "stalledCause", "stalledBy",
                "convergedAt", "convergedInto", "operatorNote"):
        data.pop(key, None)
    data.pop("assignedTo", None)

    _stamp_lap_metadata(data, lap=new_lap, max_laps=max_laps, to_role=to_role,
                        exhausted=False)
    _append_carried_rejection(data, rejection, new_lap, ws)
    _role_history.close_role_turn(data)

    from maestro.core.fleet_runner import release_order_to_pending
    if not release_order_to_pending(json_file, data, order_id, target_role=to_role):
        _write_event(
            "WARN",
            f"{order_id} role-rejection lap could not write {json_file.name} — "
            f"nothing released, no lap spent; falling back to the ordinary "
            f"STALLED archival (BUG-0705)"
        )
        return False

    # Ledger writes are best-effort individually but each matters:
    #  * LAPPED is the durable, git-immune lap count the ceiling is read from
    #    (a `git reset --hard` must not hand the order a fresh budget);
    #  * ADVANCED keeps scan_all_queues's BUG-0248 advance-loss guard from
    #    reading the file's new (earlier) targetRole as a rewind and putting
    #    it straight back — the same write chart_routing._apply_lap makes,
    #    and for the same reason;
    #  * RELEASED drops the dispatcher's live claim so the order is
    #    re-dispatchable on the very next tick rather than after an orphan
    #    scan.
    for writer in (
        lambda: _order_ledger.record_lapped(order_id, edge, new_lap, max_laps, workspace_dir=ws),
        lambda: _order_ledger.record_advanced(order_id, role, to_role, workspace_dir=ws),
        lambda: _order_ledger.record_released(
            order_id, f"role-rejection lap {new_lap}/{max_laps} {role}->{to_role}",
            workspace_dir=ws),
    ):
        try:
            writer()
        except Exception:
            pass

    # Consume the verdict LAST — strictly after the release is confirmed, so
    # a failed write can never erase the only record that a rejection
    # happened (BUG-MSO-2026-0558 Finding 1's discipline, same reasoning).
    try:
        _chart_routing.consume_node_verdict(order_id, role, ws)
    except Exception:
        pass

    ids = ", ".join(d.id for d in rejection.blocking_defects) or "unnamed"
    _write_event(
        "LAPPED",
        f"{order_id} rejected by {role} ({ids}) — lap {new_lap}/{max_laps} on "
        f"{edge}: released to PENDING at {to_role} carrying "
        f"{rejection.report_rel or 'the QA report'} (BUG-0705)"
    )
    return True


def _stamp_lap_metadata(data: Dict[str, Any], *, lap: int, max_laps: int,
                        to_role: str, exhausted: bool) -> None:
    block = rejection_block(data)
    if block is None:
        block = {}
        data["rejection"] = block
    block["lap"] = lap
    block["maxLaps"] = max_laps
    block["lappedTo"] = to_role
    block["lapExhausted"] = exhausted


def _append_carried_rejection(data: Dict[str, Any], rejection: Rejection,
                              lap: int, ws: Path) -> None:
    """Append the QA report to ``carriedContext`` so the rebuilding role's
    prompt contains the verdict and the defect table, not just a path.

    Uses the SAME ``carriedContext`` list and entry shape
    ``chart_routing._resolve_carry`` writes (FTR-MSO-2026-0522), so
    ``generate_prompt_for_item``'s existing ``## Carried Context`` renderer
    handles both with no branching. The extra ``summary`` field is the
    parsed blocking-defect table: the report is long (the one that motivated
    this bug ran past 500 lines) and its ``## Defects Found`` section sits
    well beyond the excerpt bound, so an excerpt alone would carry the
    headline and lose the instruction.

    A missing report degrades explicitly — ``CARRY_DEGRADED``, carrying
    nothing, never a fabricated substitute (FTR-MSO-2026-0522's rule).
    """
    if rejection.report_path is None or not rejection.report_path.is_file():
        _write_event(
            "CARRY_DEGRADED",
            f"{rejection.order_id} role-rejection lap {lap}: qaReport carry "
            f"found no report at {rejection.report_rel or '(unresolved)'} — "
            f"lapping with the defect summary only (BUG-0705)"
        )

    lines = [f"**Rejected by {rejection.role}** — you are being asked to fix "
             f"the blocking defect(s) below and hand back to {rejection.role}."]
    if rejection.blocking_defects:
        lines.append("")
        lines.append("| ID | Severity | Defect | File | Line |")
        lines.append("|----|----------|--------|------|------|")
        for d in rejection.blocking_defects:
            summary = " ".join(d.summary.split()).replace("|", "\\|")
            lines.append(f"| {d.id} | {d.severity} | {summary} | {d.file} | {d.line} |")
    if rejection.handoff_rel:
        lines.append("")
        lines.append(f"Full reviewer handoff: `{rejection.handoff_rel}`")

    entry = {
        "kind": "qaReport",
        "fromNode": f"{rejection.order_id}:{rejection.role}",
        "path": rejection.report_rel,
        "lap": lap,
        "summary": "\n".join(lines),
    }
    existing = data.get("carriedContext")
    if not isinstance(existing, list):
        existing = []
    existing.append(entry)
    data["carriedContext"] = existing
