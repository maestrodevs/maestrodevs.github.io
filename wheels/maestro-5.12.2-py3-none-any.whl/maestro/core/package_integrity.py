"""Shared installed-package integrity check (BUG-MSO-2026-0614).

Resolves where ``import maestro`` currently points ON DISK and verifies it
still looks like a real installed package rather than a debris-filled
shadowing directory (CLAUDE.md's "Shadowing" note; BUG-MSO-2026-0503's
136MB incident, then this bug's 110MB repeat). The check deliberately reads
FILESYSTEM STATE (``Path.exists()``) rather than trusting the fact that
``import maestro`` already succeeded in this process: the caller here
typically already has ``maestro`` cached in ``sys.modules``, so a bare
``import maestro`` would silently keep succeeding even after another
process has overwritten the package directory on disk out from under it —
exactly BUG-MSO-2026-0614's failure mode, where the running dispatcher kept
reporting "alive" while every NEW ``python crew.py`` subprocess it spawned
died on import.

Used by BOTH:
  - ``maestro.patrol.checks.machine`` (``machine.package-integrity``, a
    REPORT-only ``mso doctor`` finding, machine-scoped)
  - ``maestro.core.fleet_runner`` (``run_dispatcher()`` startup gate) —
    refuses to start the dispatcher loop rather than entering the tight
    "Crew N failed to start" cycle this bug measured looping every ~11
    seconds while reporting itself alive.

A stray ``temp/`` directory under the package root (machine.py's separate
debris check) is deliberately NOT treated as a startup blocker here: its
mere presence is not proof of corruption the way missing package markers
are. Since BUG-MSO-2026-0701 ``MAESTRO_TEMP`` no longer defaults inside
site-packages, so such a directory is inert leftover debris — the
dispatcher names it once at startup with its size and a delete command
(``fleet_runner._report_legacy_package_temp``) instead of refusing to run.
"""
from __future__ import annotations

from pathlib import Path
from typing import NamedTuple, Optional, Tuple

_EXPECTED_MARKERS = ("__init__.py", "cli.py", "core")


class PackageIntegrityResult(NamedTuple):
    ok: bool
    pkg_dir: Optional[Path]
    missing_markers: Tuple[str, ...]
    reason: str


def check_package_integrity() -> PackageIntegrityResult:
    """Return a :class:`PackageIntegrityResult` describing whether the
    installed ``maestro`` package is importable and structurally intact.

    ``ok=False`` covers: the import itself raising, ``maestro.__file__``
    being unset (namespace/frozen/zip install), or the resolved package
    directory missing one of the markers every real install always has
    (``__init__.py``, ``cli.py``, ``core/``)."""
    try:
        import maestro as _pkg
    except Exception as exc:
        return PackageIntegrityResult(
            ok=False, pkg_dir=None, missing_markers=(),
            reason=f"`import maestro` raised {type(exc).__name__}: {exc}",
        )

    pkg_file = getattr(_pkg, "__file__", None)
    if not pkg_file:
        return PackageIntegrityResult(
            ok=False, pkg_dir=None, missing_markers=(),
            reason=(
                "maestro.__file__ is unset — the import resolved to a namespace "
                "package or a frozen/zip install, not a normal on-disk package."
            ),
        )

    pkg_dir = Path(pkg_file).resolve().parent
    missing = tuple(m for m in _EXPECTED_MARKERS if not (pkg_dir / m).exists())
    if missing:
        return PackageIntegrityResult(
            ok=False, pkg_dir=pkg_dir, missing_markers=missing,
            reason=(
                f"maestro.__file__ points at {pkg_dir}, but expected marker(s) "
                f"{', '.join(missing)} are absent — this looks like a shadowing "
                "directory (crew-written debris with no proper package contents), "
                "not the real installed package."
            ),
        )

    return PackageIntegrityResult(ok=True, pkg_dir=pkg_dir, missing_markers=(), reason="")
