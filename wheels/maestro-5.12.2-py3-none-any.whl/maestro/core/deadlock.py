# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Voyage deadlock classification (BUG-MSO-2026-0699).

What a deadlock is
------------------
A voyage is DEADLOCKED when every one of its remaining (non-complete) orders
is transitively held behind a **terminal non-COMPLETE** order — STALLED,
FAILED, CONVERGENCE_FAILED, VERIFY_FAILED, VERIFY_DEPS_FAILED, AUTO_SERIALIZE,
or operator-skipped — and no crew is working on any of them. The fleet cannot
advance such a voyage by itself, ever, no matter how long it is left running.
Only a human can (``mso order retry <blocking order>``).

Why it needed its own module
----------------------------
On 2026-09-09 (the VOY-MSO-2026-0163 recovery this bug was filed from) four
crews ran overnight, FTR-MSO-2026-0618 archived STALLED at 02:16, five orders
sat dep-held behind it, and at 02:46 the dispatcher IDLE_REAP'd with
``ignored held work: review-gated=2, dep-held=5, stranded=7`` — a tally, not a
diagnosis. ``mso status`` drew a silent 0% progress bar. The Hub board showed
the held orders as held. The word "deadlocked" appeared in exactly one place,
the LEAD daemon's own finding, and nowhere the operator was looking.

Every one of those surfaces had a *piece* of the picture and none of them had
the verdict, because there was no verdict — each surface re-derived "is this
order held" locally and none of them ever asked "can this voyage still
finish". This module is that one question, answered once:

- :func:`classify_voyage_deadlock` — the pure classifier (members in, verdict
  out). No filesystem, no globals, no clock; every consumer that already has
  member state calls this directly.
- :func:`scan_voyage_members` — the artefact-plane reader that resolves every
  active voyage's members to their effective statuses and runs the classifier
  over the in-flight ones, for the consumers that do not already hold that
  state. Its :class:`VoyageScan` results carry the resolved members out, so a
  caller that also needs progress counts (``mso status``) gets them from the
  same pass rather than a second scan or a stale manifest snapshot
  (BUG-MSO-2026-0708).
- :func:`detect_deadlocked_voyages` — the verdicts alone, from a scan the
  caller supplies or one taken here.

Consumers (AC1 of BUG-MSO-2026-0699), all sharing this one implementation:

- ``maestro/core/fleet_runner.py``     — idle-watchdog ``holdOnDeadlock``, IDLE_REAP text
- ``maestro/core/fleet_monitor.py``    — ``mso status`` MISSION/VOYAGE block
- ``maestro/patrol/checks/voyages.py`` — ``voyages.deadlocked`` (and so the LEAD finding)
- ``maestro/hub/phase.py``             — ``needs_attention`` with the blocking order named

Deliberately NOT a deadlock
---------------------------
- **Merely dep-held.** Orders waiting on a dependency that is PENDING or
  RUNNING are waiting on the *fleet*, which will get there. Not a deadlock.
- **Progressing.** If ANY remaining order is dispatchable (all its
  dependencies complete) or in progress, the voyage can still advance on its
  own — even when some other order is stalled. Not a deadlock.
- **Review-gated with a way forward.** A NAV_REVIEW_PENDING order that does
  not depend on a blocker is waiting on an approval the operator can give
  today; the voyage is not structurally stuck. (One that DOES depend on a
  blocker is held behind it like anything else, and approving it changes
  nothing — that one counts.)

That strictness is the point: a DEADLOCKED verdict has to mean "this will
never move without you", or an operator learns to ignore it.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterable, Optional, Sequence

from maestro.core.order_status import classify_status, load_json_safe

# Terminal, non-COMPLETE order statuses that can never resolve themselves.
# Each requires an operator (`mso order retry <id>`, or a deliberate skip /
# removal) before anything downstream of it can move.
#
# AUTO_SERIALIZE and CONVERGENCE_FAILED are included alongside the four the
# order named because BUG-MSO-2026-0303 already established them as the same
# family — the statuses that make Eight Bells refuse to ring. REJECTED and the
# ordinary holds (ON_HOLD / BACKLOG / PROPOSED) are deliberately absent: those
# are decisions or waits, not failures, and an operator parking their own work
# should never have it reported back to them as a broken voyage.
DEADLOCK_BLOCKER_STATUSES = frozenset({
    "STALLED",
    "FAILED",
    "CONVERGENCE_FAILED",
    "VERIFY_FAILED",
    "VERIFY_DEPS_FAILED",
    "AUTO_SERIALIZE",
    "SKIPPED",
})

# Voyage `status` values that describe an in-flight voyage. Mirrors
# `fleet_runner._SWEEPABLE_VOYAGE_STATUSES` — a voyage an operator has
# deliberately parked (HELD / PAUSED / AWAITING_APPROVAL) is not deadlocked,
# it is waiting on them on purpose. Resolved from fleet_runner at call time
# where possible so the two never drift; this literal is only the fallback.
_IN_FLIGHT_VOYAGE_STATUSES = frozenset({"PLANNED", "ACTIVE", "IN_PROGRESS"})

_ORDER_QUEUE_DIRS = (
    "queues/orders", "queues/bugs", "queues/security", "queues/defects",
    "queues/requests", "queues/breakdown", "queues/high-level",
    "queues/review", "queues/proposed", "queues/escalations",
)


@dataclass(frozen=True)
class DeadlockMember:
    """One voyage member order, reduced to what the classifier needs.

    Structurally compatible with ``maestro.hub.phase.MemberState`` (same field
    names), so the Hub hands its own member list straight to
    :func:`classify_voyage_deadlock` rather than building a second one.
    """

    order_id: str
    status: str                                  # effective status, uppercase
    depends_on: "tuple[str, ...]" = ()
    role: str = ""


@dataclass(frozen=True)
class VoyageDeadlock:
    """The verdict: this voyage cannot finish without a human.

    ``blocking_order_id`` is the single order an operator should act on first
    — chosen deterministically (see :func:`classify_voyage_deadlock`) so the id
    they are shown does not shuffle between ``mso status`` refreshes or differ
    between surfaces.
    """

    voyage_id: str
    blocking_order_id: str
    blocking_cause: str                          # e.g. "STALLED"
    blocking_order_ids: "tuple[str, ...]" = ()   # every root blocker
    held_order_ids: "tuple[str, ...]" = ()       # what is stuck behind them
    blocking_role: str = ""                      # the blocker's role, when known

    @property
    def suggested_command(self) -> str:
        """The one command that unsticks this voyage.

        A SKIPPED blocker takes ``mso order unskip`` — ``retry`` would put the
        order back in the queue while the skip list still vetoes it, which
        looks like the fix and changes nothing. Everything else takes
        ``mso order retry``, the sanctioned way past the BUG-MSO-2026-0294
        ledger veto.
        """
        if self.blocking_cause.strip().upper() == "SKIPPED":
            return f"mso order unskip {self.blocking_order_id}"
        return f"mso order retry {self.blocking_order_id}"

    def summary(self) -> str:
        """The operator-facing one-liner for `mso status`'s MISSION block (AC3).

        ``DEADLOCKED - blocked by <ORDER> (<cause>) - `mso order retry <ORDER>```
        (rendered with em-dashes).
        """
        return (
            f"DEADLOCKED — blocked by {self.blocking_order_id} "
            f"({self.blocking_cause.lower()}) — `{self.suggested_command}`"
        )

    def blocker_label(self) -> str:
        """``<ORDER-ID> <CAUSE>`` plus ``at <ROLE>`` when the role is known.

        This exact phrasing predates BUG-MSO-2026-0699 — it is what
        ``_blocked_reason()`` has always put in the Hub's ``phaseReason`` — and
        is kept verbatim so a deadlock reason still *contains* the reason the
        board showed before, rather than replacing it. The DEADLOCKED verdict
        is added information, never a substitution.
        """
        label = f"{self.blocking_order_id} {self.blocking_cause}"
        if self.blocking_role:
            label += f" at {self.blocking_role}"
        return label

    def detail(self) -> str:
        """A fuller sentence for lifecycle lines, patrol findings and the Hub."""
        head = f"{self.voyage_id} is " if self.voyage_id else ""
        bits = [
            f"{head}DEADLOCKED — {self.blocker_label()}; every remaining order "
            "is held behind it and the fleet cannot advance any of them"
        ]
        others = [o for o in self.blocking_order_ids if o != self.blocking_order_id]
        if others:
            bits.append(f" (also blocking: {', '.join(others)})")
        if self.held_order_ids:
            bits.append(
                f"; {len(self.held_order_ids)} order(s) held: "
                f"{', '.join(self.held_order_ids)}"
            )
        bits.append(f". Recover with `{self.suggested_command}`.")
        return "".join(bits)


@dataclass(frozen=True)
class VoyageScan:
    """One active voyage read off the artefact plane, resolved once.

    BUG-MSO-2026-0708. :func:`detect_deadlocked_voyages` already resolved every
    member's EFFECTIVE status (ledger TERMINAL > archived order file > live
    ledger claim > the manifest's own snapshot) and then threw all of it away
    except the deadlock verdict — while ``mso status`` computed its
    ``complete / total`` from the manifest snapshot alone. On the live MSO
    plane that manifest is a bare list of order ids with no ``orderStatuses``
    map at all, so the MISSION bar read ``0 / 13 orders  ·  0%`` all day with
    four orders archived COMPLETE and TERMINAL in the ledger.

    This carries the resolved members out alongside the verdict so both
    consumers read the same numbers by construction. The rollup buckets come
    from :func:`~maestro.core.order_status.classify_status` — the same
    vocabulary the Hub board's rollup uses — so the CLI and the Hub cannot
    disagree about what "complete" means.
    """

    voyage_id: str
    members: "tuple[DeadlockMember, ...]" = ()
    deadlock: Optional[VoyageDeadlock] = None
    in_flight: bool = True

    def _bucket_count(self, bucket: str) -> int:
        return sum(1 for m in self.members if classify_status(m.status) == bucket)

    @property
    def orders_total(self) -> int:
        return len(self.members)

    @property
    def orders_complete(self) -> int:
        return self._bucket_count("complete")

    @property
    def orders_blocked(self) -> int:
        """Members in a terminal-and-not-COMPLETE state (STALLED, FAILED,
        CONVERGENCE_FAILED, VERIFY_FAILED, AUTO_SERIALIZE, BLOCKED).

        Rendered as "N stalled" on the MISSION line so such an order is shown
        as stuck rather than silently counted as merely "not done yet".
        """
        return self._bucket_count("blocked")


def is_blocker_status(status: Optional[str]) -> bool:
    """True when *status* is terminal-and-not-COMPLETE (never self-resolving)."""
    return (status or "").strip().upper() in DEADLOCK_BLOCKER_STATUSES


def classify_voyage_deadlock(
    voyage_id: str,
    members: "Sequence[DeadlockMember]",
    dep_status: Optional[Callable[[str], str]] = None,
    skipped_ids: Iterable[str] = (),
) -> Optional[VoyageDeadlock]:
    """Return a :class:`VoyageDeadlock` when *voyage_id* is deadlocked, else ``None``.

    Pure: no filesystem, no globals, no clock. *members* may be
    :class:`DeadlockMember` or any object exposing ``order_id`` / ``status`` /
    ``depends_on`` (``maestro.hub.phase.MemberState`` qualifies).

    *dep_status* resolves a dependency id that may live OUTSIDE this voyage to
    its effective status; it defaults to looking only within *members*, so an
    unknown dependency reads as PENDING — i.e. "the fleet may still get to it",
    the conservative answer, because a false DEADLOCKED is worse than a missed
    one.

    *skipped_ids* are operator-skipped orders (``mso order skip``). They never
    dispatch again, so they block their dependents exactly like a STALLED order
    does — but they are not themselves outstanding work.
    """
    skipped = {str(s) for s in skipped_ids}
    by_id = {m.order_id: m for m in members}

    if dep_status is None:
        def dep_status(oid: str) -> str:  # noqa: F811 — deliberate default
            m = by_id.get(oid)
            return m.status if m is not None else "PENDING"

    def _status_of(oid: str) -> str:
        m = by_id.get(oid)
        return (m.status if m is not None else dep_status(oid)) or "PENDING"

    def _is_blocker(oid: str) -> bool:
        return oid in skipped or is_blocker_status(_status_of(oid))

    # A skipped order is not outstanding work in its own right — the operator
    # removed it deliberately. It still matters as a BLOCKER of something else,
    # which the dependency walk below picks up regardless.
    remaining = [
        m for m in members
        if classify_status(m.status) != "complete" and m.order_id not in skipped
    ]
    if not remaining:
        return None  # nothing left to do — finished, not deadlocked

    # A live crew means the fleet is still moving. Never call that deadlocked,
    # however stuck the rest of the manifest looks.
    if any(classify_status(m.status) == "inProgress" for m in remaining):
        return None

    # `_roots_blocking(oid)` -> the root blocker ids reachable from oid's deps
    # (or `(oid,)` when oid is itself a blocker). Memoised and cycle-safe: a
    # dependency cycle is its own pathology (see scan_all_queues' `circular-dep`
    # filter) and yields NO roots here, so a cycle can never masquerade as a
    # terminal-order deadlock.
    _memo: "dict[str, tuple[str, ...]]" = {}

    def _roots_blocking(oid: str, seen: "frozenset[str]" = frozenset()) -> "tuple[str, ...]":
        if oid in _memo:
            return _memo[oid]
        if oid in seen:
            return ()  # cycle — not a terminal-order deadlock
        if _is_blocker(oid):
            _memo[oid] = (oid,)
            return _memo[oid]
        m = by_id.get(oid)
        deps = tuple(m.depends_on or ()) if m is not None else ()
        roots: "list[str]" = []
        truncated = False
        for dep in deps:
            if dep in seen or dep == oid:
                truncated = True
                continue
            for r in _roots_blocking(dep, seen | {oid}):
                if r not in roots:
                    roots.append(r)
        result = tuple(roots)
        if not truncated:
            # Only memoise a result the cycle guard did not truncate — a
            # truncated one is correct for THIS path but not in general.
            _memo[oid] = result
        return result

    root_blockers: "list[str]" = []
    held: "list[str]" = []
    for m in remaining:
        roots = _roots_blocking(m.order_id)
        if not roots:
            return None  # this order can still move → the voyage is not deadlocked
        if m.order_id not in roots:
            held.append(m.order_id)
        for r in roots:
            if r not in root_blockers:
                root_blockers.append(r)

    if not root_blockers:
        return None

    # Deterministic pick: sorted, so the same id is named on every surface and
    # on every refresh. A shuffling "retry this one" is worse than none at all.
    root_blockers.sort()
    primary = root_blockers[0]
    cause = "SKIPPED" if primary in skipped else (_status_of(primary).upper() or "STALLED")
    primary_member = by_id.get(primary)

    return VoyageDeadlock(
        voyage_id=voyage_id,
        blocking_order_id=primary,
        blocking_cause=cause,
        blocking_order_ids=tuple(root_blockers),
        held_order_ids=tuple(sorted(held)),
        blocking_role=getattr(primary_member, "role", "") or "",
    )


# ---------------------------------------------------------------------------
# Artefact-plane reader
# ---------------------------------------------------------------------------

def _in_flight_voyage_statuses() -> "frozenset[str]":
    """``fleet_runner._SWEEPABLE_VOYAGE_STATUSES`` when importable, else the
    local fallback — imported lazily so ``mso status`` never drags the whole
    dispatcher module in just to read a frozenset."""
    try:
        from maestro.core.fleet_runner import _SWEEPABLE_VOYAGE_STATUSES
        return frozenset(_SWEEPABLE_VOYAGE_STATUSES)
    except Exception:
        return _IN_FLIGHT_VOYAGE_STATUSES


def _index_live_orders(artefact_root: Path) -> "dict[str, dict]":
    """Every order JSON currently sitting in a scanned queue dir, by id."""
    out: "dict[str, dict]" = {}
    for sub in _ORDER_QUEUE_DIRS:
        d = artefact_root / sub
        if not d.is_dir():
            continue
        for f in sorted(d.glob("*.json")):
            data = load_json_safe(f)
            if not data:
                continue
            oid = str(data.get("orderId") or data.get("id") or f.stem)
            out.setdefault(oid, data)
    return out


class _ArchivedOrders:
    """Lazy, per-id view over ``orders/complete`` + ``orders/failed``.

    ``read_archive_statuses()`` answers the same question by scanning BOTH
    directories in full. That is right for the Hub, which reads a workspace
    once per poll, and wrong here: ``mso status`` calls
    :func:`detect_deadlocked_voyages` on every refresh (5s by default), and on
    the live MSO plane that scan reads 668 JSON files — measured at 0.4s a
    call, twice over (once for statuses, once for ``dependsOn``), which is
    most of the 2.9s the first cut of this function cost. A voyage has a
    handful of members, so resolving those ids directly is the right shape.

    Exposes ``__contains__``/``__getitem__`` so it drops straight into
    :func:`~maestro.core.order_status.effective_order_status` in place of the
    dict it expects — the status-precedence rules stay in that ONE function
    (ledger > archive > live claim > fallback); only the lookup gets cheaper.
    Archived orders are stored as ``<ORDER-ID>.json``, the same direct-lookup
    assumption ``voyages.stalled-order-deadlock`` already makes.
    """

    def __init__(self, artefact_root: Path):
        self._root = artefact_root
        self._cache: "dict[str, tuple[Optional[dict], Optional[str]]]" = {}

    def _resolve(self, order_id: str) -> "tuple[Optional[dict], Optional[str]]":
        """(order data, effective archived status) — both None when not archived."""
        hit = self._cache.get(order_id)
        if hit is not None:
            return hit
        result: "tuple[Optional[dict], Optional[str]]" = (None, None)
        for sub, default in (("complete", "COMPLETE"), ("failed", "FAILED")):
            f = self._root / "orders" / sub / f"{order_id}.json"
            if not f.is_file():
                continue
            data = load_json_safe(f) or {}
            # BUG-MSO-2026-0296: the file's own status wins over the directory
            # — orders/complete legitimately holds STALLED records.
            result = (data, str(data.get("status") or default).strip().upper())
            break
        self._cache[order_id] = result
        return result

    def data(self, order_id: str) -> Optional[dict]:
        return self._resolve(order_id)[0]

    def __contains__(self, order_id: object) -> bool:
        return self._resolve(str(order_id))[1] is not None

    def __getitem__(self, order_id: str) -> str:
        status = self._resolve(order_id)[1]
        if status is None:
            raise KeyError(order_id)
        return status


def _depends_on(data: Optional[dict]) -> "tuple[str, ...]":
    if not data:
        return ()
    deps = data.get("dependsOn") or data.get("dependencies") or []
    if isinstance(deps, str):
        deps = [deps]
    if not isinstance(deps, (list, tuple)):
        return ()
    return tuple(str(d) for d in deps if d)


def _member_id(entry) -> str:
    if isinstance(entry, dict):
        return str(entry.get("orderId") or entry.get("id") or "")
    return str(entry or "")


def scan_voyage_members(
    artefact_root: Optional[Path] = None,
) -> "list[VoyageScan]":
    """Read every ACTIVE voyage on the artefact plane, once (BUG-MSO-2026-0708).

    Returns one :class:`VoyageScan` per voyage manifest, each carrying its
    members resolved to their EFFECTIVE statuses (ledger TERMINAL > archived
    order file > live ledger claim > the manifest snapshot) plus the deadlock
    verdict for the in-flight ones.

    This is the plane read :func:`detect_deadlocked_voyages` used to do inline.
    It was split out so ``mso status`` can take its ``complete / total`` from
    the SAME resolution in the SAME pass, instead of re-deriving progress from
    the manifest snapshot (which on the live MSO plane is a bare list of ids
    with no statuses at all — the 0%-all-day defect) and instead of paying for
    a second full scan of the plane on every 5-second refresh.

    A voyage the operator has deliberately parked (a ``status`` outside
    ``fleet_runner._SWEEPABLE_VOYAGE_STATUSES``) is still SCANNED — the
    dashboard renders it and needs its counts — but is never classified as
    deadlocked, exactly as before.

    Never raises: a malformed manifest, an unreadable ledger or a missing
    directory yields fewer scans, never an exception in a caller. Both the
    dispatcher's idle watchdog and ``mso status`` call this on a hot path.
    """
    from maestro.core.order_status import effective_order_status, load_ledger_view

    try:
        if artefact_root is None:
            from maestro.workspace import get_artefact_root
            artefact_root = get_artefact_root()
        artefact_root = Path(artefact_root)

        voyages_dir = artefact_root / "voyages" / "active"
        if not voyages_dir.is_dir():
            return []

        try:
            from maestro.core.skip_list import read_skipped_order_ids
            skipped_ids = read_skipped_order_ids(artefact_root)
        except Exception:
            skipped_ids = set()

        ledger_view = load_ledger_view(artefact_root)
        archive_statuses = _ArchivedOrders(artefact_root)
        live_orders = _index_live_orders(artefact_root)
        in_flight = _in_flight_voyage_statuses()

        def _order_data(oid: str) -> Optional[dict]:
            return live_orders.get(oid) or archive_statuses.data(oid)

        def _fallback_status(oid: str, manifest_status: Optional[str]) -> Optional[str]:
            data = _order_data(oid)
            if data and data.get("status"):
                return str(data["status"])
            return manifest_status

        def _dep_status(oid: str) -> str:
            return effective_order_status(
                oid, _fallback_status(oid, None), ledger_view, archive_statuses)

        results: "list[VoyageScan]" = []
        for vf in sorted(voyages_dir.glob("*.json")):
            data = load_json_safe(vf)
            if not data:
                continue
            v_status = str(data.get("status") or "").upper()
            voyage_in_flight = not v_status or v_status in in_flight
            voyage_id = str(data.get("id") or data.get("voyageId") or vf.stem)

            manifest_statuses = data.get("orderStatuses") or {}
            members: "list[DeadlockMember]" = []
            for entry in (data.get("orders") or []):
                oid = _member_id(entry)
                if not oid:
                    continue
                manifest_status = (
                    entry.get("status") if isinstance(entry, dict)
                    else manifest_statuses.get(oid)
                )
                od = _order_data(oid)
                members.append(DeadlockMember(
                    order_id=oid,
                    status=effective_order_status(
                        oid, _fallback_status(oid, manifest_status),
                        ledger_view, archive_statuses),
                    depends_on=_depends_on(od),
                    role=str((od or {}).get("targetRole") or ""),
                ))

            verdict = None
            if members and voyage_in_flight:
                verdict = classify_voyage_deadlock(
                    voyage_id, members, dep_status=_dep_status,
                    skipped_ids=skipped_ids)
            results.append(VoyageScan(
                voyage_id=voyage_id,
                members=tuple(members),
                deadlock=verdict,
                in_flight=voyage_in_flight,
            ))
        return results
    except Exception:
        return []


def detect_deadlocked_voyages(
    artefact_root: Optional[Path] = None,
    scans: "Optional[Sequence[VoyageScan]]" = None,
) -> "list[VoyageDeadlock]":
    """Classify every in-flight voyage on the artefact plane; return the stuck ones.

    Reads the same three planes ``effective_order_status`` does (ledger >
    archive > live claim > queue file) so a verdict here agrees with the Hub
    board and ``mso doctor`` by construction rather than by coincidence.

    Pass *scans* (from :func:`scan_voyage_members`) when the caller has already
    read the plane this refresh — ``mso status`` does, for its progress counts
    — so the verdicts cost no second scan. Omit it and the plane is read here,
    exactly as before.

    Never raises — a malformed manifest, an unreadable ledger or a missing
    directory yields fewer verdicts, never an exception in a caller. Both the
    dispatcher's idle watchdog and ``mso status`` call this on a hot path.
    """
    try:
        if scans is None:
            scans = scan_voyage_members(artefact_root)
        return [s.deadlock for s in scans if s.deadlock is not None]
    except Exception:
        return []
