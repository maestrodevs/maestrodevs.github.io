# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""ONE salvage record per order (BUG-MSO-2026-0696).

Before this module, salvage bookkeeping was split across four unrelated
fields written by six different code paths:

===========================  ==========================================
Path                          Where it recorded the salvage
===========================  ==========================================
TIMEOUT / HUNG requeue        ``order.salvageBranches[]``  (append)
STALLED archival              ``order.salvageBranches[]``  (append)
VERIFY_FAILED                 ``order.verify.salvageBranch``   (OVERWRITE)
VERIFY_DEPS_FAILED            ``order.verify.salvageBranch``   (OVERWRITE)
CONVERGENCE_FAILED            ``order.convergence.salvageBranch`` (OVERWRITE)
convergence-network retry     ``order.convergenceRetry.salvageBranch``
auto-serialize                ``order.autoSerialized.salvageBranch``
===========================  ==========================================

``order_retry._newest_salvage_branch()`` read ``salvageBranches[-1]`` first and
only consulted the scalar fields when that list was empty — so an order that
timed out (partial work -> ``salvageBranches[0]``) and *then* failed the verify
gate (finished work -> ``verify.salvageBranch``) armed the PARTIAL branch and
never even mentioned the finished one. That is FTR-MSO-2026-0617, observed on
2026-09-09; had the LEAD not checked by hand, ``mso order retry`` would have
fast-converged 8542cb51 (partial) over ca7cdb66 (the finished build).

The rule this module enforces: **every SALVAGE event appends to
``order.salvageBranches[]``, whatever path emits it.** The scalar fields remain
(nothing that reads them breaks) but are now *pointers* into that list — each
carries a ``salvageIndex`` alongside the branch name.

Each entry carries enough for an operator to CHOOSE between candidates without
running git themselves::

    {"branch": "salvage/FTR-MSO-2026-0617-ca7cdb66",
     "sha": "ca7cdb66...",
     "reason": "VERIFY_FAILED",
     "crew": 2,
     "role": "BLD",
     "timestamp": "2026-09-09T01:12:44",
     "diffStat": {"files": 14, "insertions": 812, "deletions": 37,
                  "base": "voyage/VOY-MSO-2026-0163-..."}}

``diffStat`` is measured against the voyage branch **at salvage time** — the
size of the work the branch would contribute — and is best-effort: a workspace
with no resolvable git checkout records ``None`` rather than a guess. Callers
must treat a missing diff-stat as "unknown", never as "empty".

No printing, no ``sys.exit``, no workspace globals — this module is called from
the dispatcher (``fleet_runner``), the CLI and the Hub alike.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

# The scalar salvage fields that predate BUG-MSO-2026-0696, in the order
# ``_newest_salvage_branch()`` historically consulted them. Retained as
# fallbacks so an order JSON written by an OLDER Maestro (whose salvages never
# reached ``salvageBranches[]``) still yields candidates.
LEGACY_SALVAGE_BLOCKS = ("convergence", "verify", "convergenceRetry", "autoSerialized")

_SHORTSTAT_RE = re.compile(
    r"(?:(\d+)\s+files?\s+changed)?"
    r"(?:,\s*(\d+)\s+insertions?\(\+\))?"
    r"(?:,\s*(\d+)\s+deletions?\(-\))?"
)


@dataclass
class SalvageCandidate:
    """One branch ``mso order retry`` could fast-converge.

    ``source`` names where the record was found — ``"salvageBranches"`` for the
    canonical list, or the legacy block name for a pre-BUG-0696 order JSON.
    ``index`` is the position in ``salvageBranches[]`` (``None`` for a legacy
    scalar with no corresponding list entry).
    """

    branch: str
    sha: Optional[str] = None
    reason: str = ""
    crew: Optional[int] = None
    role: str = ""
    timestamp: str = ""
    diff_stat: Optional[Dict[str, Any]] = None
    source: str = "salvageBranches"
    index: Optional[int] = None

    @property
    def size(self) -> Optional[int]:
        """Comparable magnitude of the work on this branch, or None if unknown.

        Insertions is the honest proxy for "how much work is here" — a salvage
        that ADDS 812 lines is the finished build; one that adds 40 is the
        partial. Files-changed is the fallback when a diff-stat recorded no
        insertions (a pure-deletion or rename-only branch).
        """
        if not self.diff_stat:
            return None
        ins = self.diff_stat.get("insertions")
        if ins is not None:
            return int(ins)
        files = self.diff_stat.get("files")
        return int(files) if files is not None else None

    def describe(self) -> str:
        """One-line operator-facing summary (used by the CLI and the Hub)."""
        bits = []
        if self.role:
            bits.append(f"role={self.role}")
        if self.crew is not None:
            bits.append(f"crew={self.crew}")
        if self.reason:
            bits.append(f"reason={self.reason}")
        if self.diff_stat:
            files = self.diff_stat.get("files")
            ins = self.diff_stat.get("insertions")
            dels = self.diff_stat.get("deletions")
            bits.append(
                f"diff={files if files is not None else '?'} files "
                f"+{ins if ins is not None else '?'}/-{dels if dels is not None else '?'}"
            )
        else:
            bits.append("diff=unknown")
        if self.timestamp:
            bits.append(f"at={self.timestamp}")
        if self.source != "salvageBranches":
            bits.append(f"src={self.source}")
        return f"{self.branch}  ({', '.join(bits)})"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "branch": self.branch,
            "sha": self.sha,
            "reason": self.reason,
            "crew": self.crew,
            "role": self.role,
            "timestamp": self.timestamp,
            "diffStat": self.diff_stat,
            "source": self.source,
            "index": self.index,
            "summary": self.describe(),
        }


@dataclass
class SalvageSelection:
    """Outcome of :func:`select_salvage`.

    ``chosen`` is the branch that will be armed (``None`` when there is nothing
    to arm, or when ``ambiguous`` is set). ``ambiguous`` carries the reason the
    choice was refused — the caller turns it into a refusal, never a guess.
    """

    chosen: Optional[SalvageCandidate] = None
    candidates: List[SalvageCandidate] = field(default_factory=list)
    ambiguous: str = ""
    explicit: bool = False


# ---------------------------------------------------------------------------
# Recording — every SALVAGE path funnels through here
# ---------------------------------------------------------------------------

def compute_diff_stat(repo_root: Optional[Path], branch: str,
                      base_branch: str) -> Optional[Dict[str, Any]]:
    """Diff-stat of *branch* against *base_branch*, or None if undeterminable.

    Three-dot (``base...branch``) so the stat describes what the SALVAGE adds
    since the two diverged — not everything the base has gained meanwhile.

    Best-effort by construction: a missing git binary, an unresolvable ref, a
    workspace with no checkout at all (every unit-test fixture) returns None.
    Callers record None and describe it as "unknown"; nothing here may raise.
    """
    if not repo_root or not branch or not base_branch:
        return None
    try:
        from maestro.core import fleet_runner as _fr

        base_ref = None
        for cand in (f"refs/remotes/origin/{base_branch}", base_branch):
            if _fr._git_rev(cand, repo_root):
                base_ref = cand
                break
        head_ref = None
        for cand in (branch, f"refs/remotes/origin/{branch}"):
            if _fr._git_rev(cand, repo_root):
                head_ref = cand
                break
        if not base_ref or not head_ref:
            return None
        r = _fr._git_capture(
            ["diff", "--shortstat", f"{base_ref}...{head_ref}"], repo_root, timeout=20)
        if r is None or r.returncode != 0:
            return None
        line = (r.stdout or "").strip()
        if not line:
            # A real, successful diff of two identical trees — genuinely empty,
            # which is information (an empty salvage is never the right pick).
            return {"files": 0, "insertions": 0, "deletions": 0, "base": base_branch}
        m = _SHORTSTAT_RE.search(line)
        if not m:
            return None
        files, ins, dels = m.group(1), m.group(2), m.group(3)
        return {
            "files": int(files) if files else 0,
            "insertions": int(ins) if ins else 0,
            "deletions": int(dels) if dels else 0,
            "base": base_branch,
        }
    except Exception:
        return None


def build_salvage_entry(salvage: Optional[Dict[str, Any]], *,
                        reason: str,
                        crew: Optional[int] = None,
                        role: str = "",
                        repo_root: Optional[Path] = None,
                        voyage_branch: str = "") -> Optional[Dict[str, Any]]:
    """Build one ``salvageBranches[]`` entry, or None when there is no branch.

    *salvage* is the ``{"salvageBranch": ..., "strandedSha": ...}`` dict every
    salvage producer already returns (``preserve_failed_crew_branch`` /
    ``commit_or_salvage_crew_worktree``) — this function is the single place
    that turns one into the canonical record shape.
    """
    branch = (salvage or {}).get("salvageBranch")
    if not branch:
        return None
    return {
        "branch": branch,
        "sha": (salvage or {}).get("strandedSha"),
        "reason": reason or "",
        "crew": crew,
        "role": role or "",
        "timestamp": datetime.now().isoformat(),
        "diffStat": compute_diff_stat(repo_root, branch, voyage_branch),
    }


def append_salvage_entry(data: Dict[str, Any],
                         entry: Optional[Dict[str, Any]]) -> Optional[int]:
    """Append *entry* to ``data['salvageBranches']``; return its index.

    Idempotent on ``(branch, sha)``: re-recording the same salvage (the same
    preserved ref is legitimately reported by more than one path in a single
    failure cascade — e.g. an auto-commit refusal *and* the convergence failure
    it causes) UPDATES the existing entry in place instead of appending a
    duplicate the operator would then have to disambiguate by hand.

    Returns ``None`` when *entry* is None (nothing was salvaged).
    """
    if not entry or not entry.get("branch"):
        return None
    branches = data.get("salvageBranches")
    if not isinstance(branches, list):  # absent, or hand-edited/corrupt JSON
        branches = []
        data["salvageBranches"] = branches
    for i, existing in enumerate(branches):
        if not isinstance(existing, dict):
            continue
        if existing.get("branch") != entry["branch"]:
            continue
        if existing.get("sha") and entry.get("sha") and existing["sha"] != entry["sha"]:
            continue  # same ref name, different commit — a genuinely new salvage
        # Merge: keep the FIRST timestamp (when the work was preserved) but take
        # any newly-resolved detail (a diff-stat the earlier path could not
        # compute, a role the earlier path did not know).
        for key in ("sha", "role", "crew", "diffStat"):
            if entry.get(key) is not None and not existing.get(key):
                existing[key] = entry[key]
        if entry.get("reason") and entry["reason"] not in (existing.get("reason") or ""):
            existing["reason"] = (
                f"{existing['reason']}; {entry['reason']}" if existing.get("reason")
                else entry["reason"]
            )
        return i
    branches.append(entry)
    return len(branches) - 1


def record_salvage(data: Dict[str, Any],
                   salvage: Optional[Dict[str, Any]], *,
                   reason: str,
                   crew: Optional[int] = None,
                   role: str = "",
                   repo_root: Optional[Path] = None,
                   repo_root_factory: Optional[Any] = None,
                   voyage_branch: str = "") -> Optional[int]:
    """Build + append in one call. Returns the ``salvageBranches`` index.

    THE entry point for every SALVAGE-emitting path in the dispatcher. Falls
    back to the order's own ``assignedTo`` / ``targetRole`` / ``voyageBranch``
    for any context the caller did not pass, so a call site that never had
    role/crew to hand still produces a complete record.

    ``repo_root_factory`` is a zero-arg callable resolving the product-repo
    checkout LAZILY — used by call sites where resolution is itself expensive
    (``fleet_runner._salvage_repo_root_for`` can reach
    ``ensure_repo_checkout``). It is invoked only once there is a branch worth
    recording, so the common no-salvage case costs nothing. Ignored when
    ``repo_root`` is given.
    """
    if not (salvage or {}).get("salvageBranch"):
        return None
    if repo_root is None and repo_root_factory is not None:
        try:
            repo_root = repo_root_factory()
        except Exception:
            repo_root = None
    if not role:
        role = ((data.get("assignedTo") or {}).get("role")
                or data.get("targetRole") or data.get("role") or "")
    if crew is None:
        crew = (data.get("assignedTo") or {}).get("crew")
    if not voyage_branch:
        voyage_branch = data.get("voyageBranch") or ""
    entry = build_salvage_entry(salvage, reason=reason, crew=crew, role=role,
                                repo_root=repo_root, voyage_branch=voyage_branch)
    return append_salvage_entry(data, entry)


def format_diff_stat(diff_stat: Optional[Dict[str, Any]]) -> str:
    """Human phrase for a ``diffStat`` block, or an honest 'unknown'.

    A missing diff-stat is NEVER rendered as "0 files" — an unmeasurable
    branch and an empty one are different facts and the operator acts on them
    differently (see the module docstring).
    """
    if not diff_stat:
        return "diff-stat unknown"
    files = diff_stat.get("files")
    ins = diff_stat.get("insertions")
    dels = diff_stat.get("deletions")
    base = diff_stat.get("base")
    phrase = (f"{files if files is not None else '?'} file(s), "
              f"+{ins if ins is not None else '?'}/-{dels if dels is not None else '?'}")
    return f"{phrase} vs {base}" if base else phrase


def build_operator_note(order_id: str,
                        entry: Optional[Dict[str, Any]], *,
                        role: str = "",
                        ancestry_detail: str = "",
                        headline: str = "") -> str:
    """BUG-MSO-2026-0703: the next step, in one field, with no LEAD required.

    A held order used to surface as ``CONVERGENCE_FAILED`` and nothing else —
    recovering it meant a human reading the guard's lifecycle WARN, verifying
    ancestry with `git merge-base` by hand, and working out which salvage branch
    held the work. Everything needed for that is already known at the moment of
    the refusal; this renders it into ``order.operatorNote``.

    *entry* is a ``salvageBranches[]`` record (so the diff-stat is the one
    actually recorded, never re-measured); ``None`` when nothing could be
    salvaged, which is itself said plainly rather than omitted.
    """
    parts: List[str] = []
    if headline:
        parts.append(headline.rstrip(". ") + ".")
    if entry and entry.get("branch"):
        branch = entry["branch"]
        sha = (entry.get("sha") or "")[:8]
        sha_note = f" ({sha})" if sha else ""
        parts.append(
            f"Work preserved on {branch}{sha_note} — {format_diff_stat(entry.get('diffStat'))}."
        )
    else:
        parts.append("No salvage branch was captured — check the crew worktree "
                     "before it is pruned.")
    if ancestry_detail:
        parts.append(f"Ancestry: {ancestry_detail}.")
    retry = f"mso order retry {order_id}"
    if role:
        retry += f" --role {role}"
    if entry and entry.get("branch"):
        parts.append(
            f"Recover: `{retry} --salvage {entry['branch']}` (fast-converges that "
            f"branch), or take it by hand with "
            f"`git cherry-pick {(entry.get('sha') or entry['branch'])}` onto the "
            f"voyage branch / `git checkout {entry['branch']} -- <path>` for "
            f"individual files."
        )
    else:
        parts.append(f"Recover: `{retry}`.")
    return " ".join(parts)


# ---------------------------------------------------------------------------
# Reading — what `mso order retry` and the Hub see
# ---------------------------------------------------------------------------

def salvage_candidates(data: Dict[str, Any]) -> List[SalvageCandidate]:
    """Every salvage branch recorded on *data*, oldest first.

    Reads the canonical ``salvageBranches[]`` list, and folds in any legacy
    scalar block whose branch is NOT already in it — so an order JSON written
    by a pre-BUG-0696 Maestro still surfaces its verify/convergence salvage
    rather than being silently invisible to the selector.

    **Legacy-only entries come FIRST, so the canonical list still outranks
    them.** "Last is newest" is what :func:`select_salvage` defaults to, and a
    branch that appears ONLY in a scalar block was necessarily written by a
    build predating this module — every post-0696 path appends to
    ``salvageBranches[]`` as well. Listing them last would invert
    BUG-MSO-2026-0344's documented precedence (``salvageBranches[]`` wins over
    ``convergence``/``verify``) and hand the default pick to the oldest record
    on the order.
    """
    canonical: List[SalvageCandidate] = []
    legacy: List[SalvageCandidate] = []
    seen = set()
    raw = data.get("salvageBranches") or []
    if isinstance(raw, list):
        for i, item in enumerate(raw):
            if not isinstance(item, dict):
                continue
            branch = item.get("branch")
            if not branch:
                continue
            canonical.append(SalvageCandidate(
                branch=branch,
                sha=item.get("sha"),
                reason=item.get("reason") or "",
                crew=item.get("crew"),
                role=item.get("role") or "",
                timestamp=item.get("timestamp") or "",
                diff_stat=item.get("diffStat"),
                source="salvageBranches",
                index=i,
            ))
            seen.add(branch)
    for key in LEGACY_SALVAGE_BLOCKS:
        block = data.get(key)
        if not isinstance(block, dict):
            continue
        branch = block.get("salvageBranch")
        if not branch or branch in seen:
            continue
        seen.add(branch)
        legacy.append(SalvageCandidate(
            branch=branch,
            sha=block.get("strandedSha"),
            reason=key,
            crew=None,
            role="",
            timestamp=block.get("failedAt") or block.get("at") or "",
            diff_stat=None,
            source=key,
            index=block.get("salvageIndex"),
        ))
    return legacy + canonical


def select_salvage(candidates: List[SalvageCandidate],
                   requested: Optional[str] = None) -> SalvageSelection:
    """Decide WHICH salvage branch to arm — or refuse to decide.

    The default is the newest recorded candidate (last in the list). Two
    situations make that default untrustworthy, and both REFUSE rather than
    guess (BUG-MSO-2026-0696 acceptance criterion 3):

    1. **Different roles.** Candidates from two different roles are two
       different pieces of work, not two attempts at one — arming either
       silently discards the other. FTR-MSO-2026-0618's shape.
    2. **A bigger candidate that is not the newest.** If some earlier candidate
       contributes strictly more than the one about to be armed, the "newest"
       is very likely the partial one. FTR-MSO-2026-0617's shape exactly: a
       TIMEOUT salvage (partial) and a VERIFY_FAILED salvage (the finished
       build), ordered by whichever path happened to write last rather than by
       which holds the work.

    *requested* (``--salvage <branch>``) is the operator's explicit answer to
    both: it selects by branch name and bypasses the ambiguity check entirely.
    An unmatched *requested* is itself a refusal — never a silent fallback to
    the default, which would arm exactly the branch the operator was trying to
    avoid.
    """
    sel = SalvageSelection(candidates=list(candidates))
    if not candidates:
        return sel

    if requested:
        for cand in candidates:
            if cand.branch == requested:
                sel.chosen = cand
                sel.explicit = True
                return sel
        sel.ambiguous = (
            f"--salvage '{requested}' does not match any recorded salvage branch "
            f"for this order ({len(candidates)} candidate(s) recorded)"
        )
        return sel

    newest = candidates[-1]
    if len(candidates) > 1:
        roles = {c.role for c in candidates if c.role}
        if len(roles) > 1:
            sel.ambiguous = (
                f"{len(candidates)} salvage branches from DIFFERENT roles "
                f"({', '.join(sorted(roles))}) — arming one silently discards "
                f"the other's work"
            )
            return sel
        newest_size = newest.size
        if newest_size is not None:
            bigger = [c for c in candidates[:-1]
                      if c.size is not None and c.size > newest_size]
            if bigger:
                biggest = max(bigger, key=lambda c: c.size or 0)
                sel.ambiguous = (
                    f"the newest salvage '{newest.branch}' (+{newest_size}) "
                    f"contributes LESS than '{biggest.branch}' (+{biggest.size}) "
                    f"— the newest is probably the partial one"
                )
                return sel
    sel.chosen = newest
    return sel


def format_candidates(candidates: List[SalvageCandidate],
                      chosen: Optional[SalvageCandidate] = None) -> List[str]:
    """Operator-facing lines listing every candidate and marking the choice."""
    lines: List[str] = []
    for cand in candidates:
        marker = "->" if (chosen is not None and cand.branch == chosen.branch) else "  "
        lines.append(f"  {marker} {cand.describe()}")
    return lines
