"""Dispatch ordering — the ONE rule, and a read-only preview of it (BUG-MSO-2026-0711).

Why this exists
---------------
``priority`` is the lever every operator surface presents: the Hub's order
drawer has a Priority select, ``mso order``/``mso bug`` take ``--priority``,
and the order JSON carries a ``priority`` field. Until this module existed,
that lever did almost nothing:

1. **The queue TIER dwarfed it.** ``scan_all_queues`` sorted on
   ``tier_offset + priority_sub``, with tier offsets 100 apart
   (explicit 0, security 100, bugs 200, requests 300, orders 400, defects 500,
   breakdown 600, high-level 700) and a priority range of only 30
   (CRITICAL 0 .. LOW 30). A ``critical`` order in ``queues/orders`` (400)
   therefore sorted *behind* a ``low`` bug in ``queues/bugs`` (230). The only
   way to jump the tiers was to know about ``queues/explicit`` and ``git mv``
   the file by hand.
2. **The lookup was case-sensitive.** Real orders are written with lowercase
   priorities (``"priority": "critical"``), and ``{"CRITICAL": 0, ...}.get(...)``
   fell through to the MEDIUM default for every one of them — so priority did
   not even order *within* a tier.

The incident: 2026-09-09 20:52. DOC-MSO-2026-0710 was set ``critical`` and the
next free crew slot went to BUG-MSO-2026-0708 (``medium``) anyway.

The rule, as it now stands
--------------------------
Dispatch order is::

    (critical band, queue tier, priority within tier)

* **CRITICAL is a cross-queue override.** A ``critical`` order in ANY queue
  dispatches before every non-critical order in EVERY queue. This is the
  behaviour the operator surfaces have always implied.
* **Within the critical band, the queue tier still orders** — a critical
  security item goes before a critical high-level one.
* **Below critical, the queue tier decides first**, then HIGH > MEDIUM/NORMAL
  > LOW inside the tier. Nothing about the pre-existing tier ordering changed
  for non-critical work.
* **Priority is matched case-insensitively.** ``critical``, ``Critical`` and
  ``CRITICAL`` are one value; an unrecognised string is MEDIUM, as before.

``dispatch_rank()`` is the single source of truth. ``fleet_runner``'s scan
calls it; so does the read-only ``preview_dispatch_order()`` that ``mso status``
renders, so the QUEUE block's "next up" list can never drift from what the
dispatcher will actually pick.

The preview is deliberately read-only
-------------------------------------
``mso status`` runs in a separate process from the dispatcher and must never
mutate the plane. ``preview_dispatch_order()` therefore re-derives eligibility
from on-disk state only (status field, skip list, dep-hold snapshot, archive,
runtime ledger) and writes nothing, logs nothing, and heals nothing. It is an
operator *hint*: the dispatcher applies further gates (role sequence, voyage
escalations, review gates, network backoff) that this preview does not, so a
previewed order can still be held. It never claims otherwise.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional

# --------------------------------------------------------------------------
# The rule
# --------------------------------------------------------------------------

#: Priority sub-ordering within a band. Lower dispatches first.
PRIORITY_SUB: Dict[str, int] = {
    "CRITICAL": 0,
    "HIGH": 10,
    "MEDIUM": 20,
    "NORMAL": 20,
    "LOW": 30,
}

#: What an absent or unrecognised ``priority`` is treated as.
DEFAULT_PRIORITY = "MEDIUM"

#: Queue directory -> tier offset. Lower dispatches first. Mirrors
#: ``fleet_runner.scan_all_queues``'s ``tier_configs`` (which imports these).
QUEUE_TIERS: Dict[str, int] = {
    "explicit": 0,
    "security": 100,
    "bugs": 200,
    "requests": 300,
    "orders": 400,
    "defects": 500,
    "breakdown": 600,
    "high-level": 700,
}

#: Ranks are banded so a single int keeps the full ordering. Every critical
#: order lands in [0, 700]; every non-critical one in [1000, 1730]. The bands
#: cannot overlap, which is the whole point — the tier gap can no longer
#: outweigh the priority.
CRITICAL_BAND = 0
STANDARD_BAND = 1000

#: Request subdirectory -> default role, shared by the scan and the preview.
REQUEST_ROLES: Dict[str, str] = {
    "planning": "NAV",
    "investigation": "LKT",
    "qa": "BOS",
    "security-scan": "LKT",
    "documentation": "SCR",
}


def normalise_priority(value: Any) -> str:
    """Canonical upper-case priority label.

    Real order JSON carries lowercase (``"priority": "critical"``); the
    case-sensitive lookup this replaces silently downgraded every one of
    them to MEDIUM.
    """
    if not isinstance(value, str):
        return DEFAULT_PRIORITY
    label = value.strip().upper()
    return label if label in PRIORITY_SUB else DEFAULT_PRIORITY


def priority_sub(value: Any) -> int:
    """Sub-order for a priority label (0 = most urgent)."""
    return PRIORITY_SUB[normalise_priority(value)]


def is_critical(value: Any) -> bool:
    """True when this priority triggers the cross-queue override."""
    return normalise_priority(value) == "CRITICAL"


def tier_offset(queue_name: str) -> int:
    """Tier offset for a queue directory name (``requests/qa`` -> requests)."""
    base = (queue_name or "").split("/", 1)[0]
    return QUEUE_TIERS.get(base, QUEUE_TIERS["orders"])


def dispatch_rank(tier: int, priority: Any) -> int:
    """The dispatch sort key. Lower dispatches first.

    ``critical`` sorts into its own band ahead of every other order in every
    queue, and keeps the tier ordering *inside* that band.
    """
    if is_critical(priority):
        return CRITICAL_BAND + tier
    return STANDARD_BAND + tier + priority_sub(priority)


def describe_rank(queue_name: str, priority: Any) -> str:
    """One-line human description, e.g. ``bugs(200) · CRITICAL``."""
    base = (queue_name or "").split("/", 1)[0]
    return f"{queue_name or base}({tier_offset(queue_name)}) · {normalise_priority(priority)}"


# --------------------------------------------------------------------------
# Read-only preview (what mso status renders)
# --------------------------------------------------------------------------

def _load_json(path: Path) -> Optional[dict]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        try:
            data = json.loads(path.read_text(encoding="utf-8-sig", errors="replace"))
        except Exception:
            return None
    return data if isinstance(data, dict) else None


def _archived_order_ids(artefact_root: Path) -> set:
    """Ids already archived terminal — never re-dispatched (BUG-MSO-2026-0263)."""
    ids = set()
    for sub in ("complete", "failed"):
        d = artefact_root / "orders" / sub
        if not d.exists():
            continue
        try:
            for f in d.glob("*.json"):
                ids.add(f.stem)
        except OSError:
            pass
    return ids


def _excluded_ids(artefact_root: Path) -> Dict[str, str]:
    """Ids the dispatcher will not pick, mapped to the reason — best-effort.

    Every source is optional: a missing/unreadable one simply contributes no
    exclusions rather than failing the preview.
    """
    excluded: Dict[str, str] = {}
    try:
        from maestro.core.skip_list import read_skipped_order_ids
        for oid in read_skipped_order_ids(artefact_root):
            excluded[oid] = "skipped"
    except Exception:
        pass
    try:
        from maestro.core.dep_holds import read_dep_holds
        for oid in read_dep_holds(artefact_root):
            excluded.setdefault(oid, "dep-held")
    except Exception:
        pass
    for oid in _archived_order_ids(artefact_root):
        excluded.setdefault(oid, "archived-terminal")
    try:
        from maestro.core import order_ledger
        view = order_ledger.load_view(artefact_root)
        for oid, _status in getattr(view, "terminal", {}).items():
            excluded.setdefault(oid, "ledger-terminal")
        for oid in getattr(view, "claimed", {}):
            if view.live_claim(oid):
                excluded.setdefault(oid, "ledger-claim")
    except Exception:
        pass
    return excluded


def _pending(data: dict, queue_name: str) -> bool:
    status = data.get("status", "PENDING")
    if queue_name == "defects":
        return status in ("OPEN", "PENDING")
    return status == "PENDING"


def preview_dispatch_order(
    artefact_root: Optional[Path] = None,
    limit: int = 3,
) -> List[Dict[str, Any]]:
    """The next ``limit`` orders in ACTUAL dispatch order — read-only.

    Returns dicts with ``id``, ``queue``, ``tier``, ``priority``, ``role`` and
    ``rank``. Writes nothing. See the module docstring for why this is a hint
    rather than a guarantee: the dispatcher applies gates (role sequence,
    escalation blocks, review gates, network backoff) that this does not.
    """
    if artefact_root is None:
        from maestro.workspace import get_artefact_root
        artefact_root = get_artefact_root()
    artefact_root = Path(artefact_root)
    queues_dir = artefact_root / "queues"
    if not queues_dir.exists():
        return []

    excluded = _excluded_ids(artefact_root)
    items: List[Dict[str, Any]] = []

    def _collect(queue_path: Path, queue_name: str, default_role: str) -> None:
        try:
            files = sorted(queue_path.glob("*.json"))
        except OSError:
            return
        for json_file in files:
            data = _load_json(json_file)
            if data is None or not _pending(data, queue_name.split("/", 1)[0]):
                continue
            item_id = data.get("orderId") or data.get("id") or json_file.stem
            if item_id in excluded:
                continue
            priority = data.get("priority")
            if priority is None and queue_name == "defects":
                priority = data.get("severity")
            role = data.get("targetRole") or data.get("role") or ""
            if not role:
                seq = data.get("roleSequence") or []
                role = seq[0] if seq else default_role
            tier = tier_offset(queue_name)
            items.append({
                "id": item_id,
                "queue": queue_name,
                "tier": tier,
                "priority": normalise_priority(priority),
                "role": role,
                "rank": dispatch_rank(tier, priority),
            })

    for queue_name in QUEUE_TIERS:
        if queue_name == "requests":
            continue
        queue_path = queues_dir / queue_name
        if queue_path.exists():
            _collect(queue_path, queue_name, "SHP")
    requests_dir = queues_dir / "requests"
    if requests_dir.exists():
        for subdir_name, role in REQUEST_ROLES.items():
            subdir = requests_dir / subdir_name
            if subdir.exists():
                _collect(subdir, f"requests/{subdir_name}", role)

    items.sort(key=lambda x: (x["rank"], x["id"]))
    return items[:limit] if limit and limit > 0 else items


def format_preview_line(item: Dict[str, Any]) -> str:
    """``BUG-MSO-2026-0711  bugs(200) · MEDIUM  BLD`` — one preview row."""
    return (
        f"{item['id']}  {item['queue']}({item['tier']}) · "
        f"{item['priority']}  {item['role']}"
    )
