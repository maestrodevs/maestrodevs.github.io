# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Shared order-retry core (BUG-MSO-2026-0297 / BUG-MSO-2026-0344).

Extracted from ``maestro/cli.py``'s ``mso order retry`` branch
(PLAN-FTR-MSO-2026-0492 §4.1) so the Hub's ``POST /orders/{id}/retry``
endpoint and the CLI share exactly ONE implementation of the framework's
only recovery verb for a terminal/stranded order — never two copies that
can silently drift apart.

Explicit ``mso: Path`` throughout, no ``find_workspace()``, no CWD — matches
the discipline ``maestro/hub/attention.py`` established for a Hub-callable
module serving N workspaces from one process. Typed exceptions, no
printing, no ``sys.exit`` — callers (CLI, HTTP) map these to their own
presentation.
"""

from __future__ import annotations

import contextlib
import json
import threading
from dataclasses import dataclass, field as dc_field
from datetime import datetime
from pathlib import Path
from typing import Optional

from maestro.core import role_history  # FTR-MSO-2026-0598: per-role startedAt/endedAt history
from maestro.roles.validation import (  # BUG-MSO-2026-0714: one role vocabulary
    is_valid_role,
    valid_roles_message,
)
from maestro.core import salvage_record  # BUG-MSO-2026-0696: ONE salvage record per order
from maestro.core import salvage_arming  # BUG-MSO-2026-0702: one way to arm a salvage fast-converge

# Serialises every workspace_scope() use across this process. The Hub's
# poller serves N workspaces concurrently from one process; an UNGUARDED
# set/restore of fleet_runner._MAESTRO_DIR_OVERRIDE would let a poller tick
# for workspace A write into workspace B's lifecycle log while a retry for B
# holds the override. RLock (not Lock) so retry_order()'s own use nests
# safely inside a caller that already holds the scope (cli.py's cmd_order).
_SCOPE_LOCK = threading.RLock()


@contextlib.contextmanager
def workspace_scope(mso: Path):
    """Serialise + scope EVERY workspace-resolution path this process has, to
    *mso*, for the duration of the ``with`` block.

    ``fleet_runner.write_lifecycle_event`` / ``_commit_lifecycle_transition`` /
    ``add_skipped_order`` / ``remove_skipped_order`` resolve their target
    workspace from ``fleet_runner._MAESTRO_DIR_OVERRIDE``, a module global —
    none of the four take a workspace argument. ``cli.py``'s ``mso order``
    command sets the override around the whole command, which is correct
    there (one process, one workspace, single-threaded). The Hub is neither:
    its poller (``maestro/hub/poller.py``) serves N registered workspaces
    concurrently, so a bare set/restore here would race it — this is
    PLAN-PLN-MSO-2026-0468 §3.3's trap, relocated from ``fleet_monitor`` to
    ``fleet_runner``. The lock makes this scope the sole writer of the
    override for its duration; the ``finally``-restore makes it safe even
    when the wrapped body raises.

    BUG-MSO-2026-0656 (the 4th recurrence of this class, after BUG-0601,
    BUG-0638 and BUG-0643): pinning ``_MAESTRO_DIR_OVERRIDE`` alone is only
    HALF the resolution path. ``fleet_runner.get_product_repo()`` in
    solo/shared artefact mode delegates to ``maestro.workspace.get_product_repo(
    start=_MAESTRO_DIR_OVERRIDE.parent)``, which resolves via
    ``maestro.workspace.get_workspace_dir()`` — and that function's *second*
    resolution tier prefers the AMBIENT ``MAESTRO_DIR`` environment variable
    over its ``start=`` hint. So an ambient ``MAESTRO_DIR`` left pointing at a
    different workspace (e.g. the Hub process's own launch-time env) would
    win over this scope's *mso* for that one call, resolving the wrong
    product repo while ``get_artefact_root()`` (which honours the override
    directly) correctly resolved *mso*. This scope pins BOTH mechanisms so
    every workspace-resolution path a caller might reach agrees on *mso*, not
    just half of them.

    BUG-MSO-2026-0686 F3: the second mechanism is pinned via
    ``maestro.workspace.workspace_override()`` — a ``ContextVar`` that
    ``get_workspace_dir()`` consults ahead of the env var — NOT by mutating
    ``os.environ["MAESTRO_DIR"]`` as the BUG-0656 fix originally did.
    ``maestro/workspace.py`` explicitly documents that a stray ``MAESTRO_DIR``
    in the Hub's own environment must never leak into every workspace's
    resolution; an env-var write is exactly that stray value, visible to
    every thread of this process (a concurrent poller tick for a DIFFERENT
    workspace) and inherited by any subprocess spawned without an explicit
    ``env=``. It was latent only because every current caller happens to pass
    an explicit root — safe by convention, not by construction. The
    ContextVar scopes the pin to this call chain alone.

    Correctness requirement for HTTP callers: any endpoint that (directly or
    via :func:`retry_order`) enters this scope MUST be a sync ``def``, not
    ``async def`` — FastAPI runs a sync path operation in its threadpool, so
    the lock only blocks other threadpool work. An ``async def`` would hold
    the lock on the event loop itself and stall every other request.
    """
    import maestro.core.fleet_runner as _fr
    from maestro.workspace import workspace_override

    with _SCOPE_LOCK:
        prior_override = _fr._MAESTRO_DIR_OVERRIDE
        _fr._MAESTRO_DIR_OVERRIDE = mso
        try:
            with workspace_override(mso):
                yield
        finally:
            _fr._MAESTRO_DIR_OVERRIDE = prior_override


class OrderNotFound(Exception):
    """*order_id* is not in ``orders/complete/``, ``orders/failed/``, or any queue."""

    def __init__(self, order_id: str) -> None:
        self.order_id = order_id
        self.hint = (
            "Check the ID with 'mso status' — retry reopens archived orders "
            "and resets stranded queued orders to PENDING."
        )
        super().__init__(
            f"Order {order_id} not found in orders/complete/, "
            "orders/failed/ or any queue."
        )


class RetryRefused(Exception):
    """Retry refused: archived COMPLETE without --force, or IN_PROGRESS without --force."""

    def __init__(self, order_id: str, message: str, hint: str = "") -> None:
        self.order_id = order_id
        self.hint = hint
        super().__init__(message)


class SalvageAmbiguous(RetryRefused):
    """BUG-MSO-2026-0696: retry refused because WHICH salvage to arm is unclear.

    Carries the full candidate list so a caller can show the operator every
    branch — with role, reason and diff-stat — rather than a bare refusal they
    then have to investigate with git by hand. That investigation-by-hand is
    precisely what this bug is about: on 2026-09-09 the LEAD had to do it, and
    the two previous times nobody did.

    A ``RetryRefused`` subclass so every existing caller (the CLI's
    ``except (OrderNotFound, RetryRefused)``, the Hub's 409 mapping) keeps
    working unchanged and merely gains the richer detail.
    """

    def __init__(self, order_id: str, reason: str,
                 candidates: "list[salvage_record.SalvageCandidate]") -> None:
        self.candidates = list(candidates)
        lines = salvage_record.format_candidates(self.candidates)
        super().__init__(
            order_id,
            f"Order {order_id} has {len(self.candidates)} salvage branches and "
            f"Maestro will not guess between them: {reason}.\n"
            + "\n".join(lines),
            hint=(
                "Pick one explicitly: mso order retry {oid} --salvage <branch>\n"
                "        ...or re-run the role from scratch: "
                "mso order retry {oid} --no-salvage".format(oid=order_id)
            ),
        )


@dataclass
class RetryOutcome:
    """Result of a successful :func:`retry_order` call."""

    order_id: str
    prior_state: str
    new_status: str
    target_role: str
    salvage_note: str
    salvage_branch: Optional[str]
    reason: str
    # BUG-MSO-2026-0696: every candidate considered, and whether the armed one
    # was named by the operator (``--salvage``) rather than picked by default.
    # Populated for the CLI's listing and the Hub's response alike — the two
    # surfaces must never show different candidate sets.
    salvage_candidates: list = dc_field(default_factory=list)
    salvage_explicit: bool = False


def _newest_salvage_branch(d: dict) -> Optional[str]:
    """The branch a bare ``mso order retry`` would arm, or None.

    Retained (BUG-MSO-2026-0696) as the thin compatibility wrapper over
    :func:`salvage_record.select_salvage` — several tests and the staleness
    pre-check ask only "which branch?" and have no use for the ambiguity
    verdict. Returns the DEFAULT pick even when the choice is ambiguous;
    :func:`_select_salvage_for_retry` is the caller that refuses.

    BUG-MSO-2026-0702: the automatic requeue path resolves its salvage through
    :func:`maestro.core.salvage_arming.newest_salvage_record`, which delegates
    to the SAME :func:`salvage_record.select_salvage` — so the two paths can
    never disagree about which branch is the one worth arming.
    """
    candidates = salvage_record.salvage_candidates(d)
    if not candidates:
        return None
    sel = salvage_record.select_salvage(candidates)
    return sel.chosen.branch if sel.chosen else candidates[-1].branch


def _select_salvage_for_retry(order_id: str, d: dict,
                              requested: Optional[str],
                              no_salvage: bool = False) -> salvage_record.SalvageSelection:
    """Resolve WHICH salvage branch this retry arms, or raise SalvageAmbiguous.

    BUG-MSO-2026-0696 AC-3. The refusal is the point: silently arming the
    wrong branch fast-converges partial work OVER finished work, and the
    operator has no way to notice until the next crew builds on it.

    Under ``no_salvage`` the candidates are still enumerated (the operator is
    told what they are declining to reuse, and the RETRY lifecycle event still
    records what existed) but nothing is chosen and nothing can be ambiguous —
    ``--no-salvage`` is already an unambiguous answer.
    """
    candidates = salvage_record.salvage_candidates(d)
    if no_salvage:
        return salvage_record.SalvageSelection(candidates=candidates)
    sel = salvage_record.select_salvage(candidates, requested=requested)
    if sel.ambiguous:
        raise SalvageAmbiguous(order_id, sel.ambiguous, candidates)
    return sel


def _arm_salvage_fast_path(d: dict, no_salvage: bool,
                           branch: Optional[str] = None) -> str:
    """BUG-MSO-2026-0301: wire the chosen salvage branch into the fast-converge
    path so the next dispatch merges the preserved work
    (CONVERGENCE_RETRY_FROM_SALVAGE) instead of re-running the role.

    *branch* (BUG-MSO-2026-0696) is the branch the selector resolved — passed
    in rather than re-derived here so the branch listed to the operator and the
    branch actually armed can never disagree. ``None`` falls back to the
    default pick, keeping every pre-0696 caller working.

    BUG-MSO-2026-0702: the arming itself is now the ONE shared operation,
    :func:`maestro.core.salvage_arming.arm_salvage_fast_path`, which the
    automatic requeue path uses too. It stays in ``advance`` mode here — ``mso
    order retry`` reopens an order whose role is TERMINAL (COMPLETE / STALLED /
    CONVERGENCE_FAILED), so merging the salvage IS its completion. The requeue
    path's ``resume`` mode is for the other case: a role killed mid-flight,
    where a crew must still run.

    Returns a human-readable note for operator output ('' if none).
    """
    if no_salvage:
        # --no-salvage promises a from-scratch re-run: actively clear any
        # pre-existing fast-converge arming so the dispatcher does NOT merge
        # previously-salvaged work — including a `resumeFromSalvage` record an
        # earlier automatic requeue left behind, which would otherwise still
        # tell the crew its predecessor's work is waiting for it.
        salvage_arming.clear_salvage_arming(d)
        return ""
    if branch is None:
        branch = _newest_salvage_branch(d)
    record = salvage_arming.arm_salvage_fast_path(
        d, branch=branch,
        mode=salvage_arming.MODE_ADVANCE,
        armed_by=salvage_arming.ARMED_BY_RETRY,
    )
    if record is None:
        return ""
    return f" (will fast-converge salvaged work from {record['branch']})"


def _resolve_repo_root_for_staleness_check(d: dict) -> Optional[Path]:
    """Best-effort resolution of the product-repo checkout to run the
    BUG-MSO-2026-0615 salvage staleness check against.

    Returns ``None`` when unresolvable (a test fixture with no real git
    checkout, an unconfigured/unknown multi-repo target, etc.) — callers
    MUST treat ``None`` as "cannot verify", never as evidence of safety.

    Mirrors the same tiers ``dispatch_squad`` uses to pick a crew's
    worktree source (multi-repo ``repos`` map -> single-repo/solo product
    repo), but read-only: no worktree is created here, only the checkout
    ``ensure_repo_checkout``/``get_base_dir`` already resolve for other
    purposes. Must be called from inside ``workspace_scope(mso)`` — the
    ``fleet_runner`` helpers below resolve against its process-global
    ``_MAESTRO_DIR_OVERRIDE``.
    """
    from maestro.core import fleet_runner as _fr

    target_repo = d.get("targetRepo", "")
    try:
        if target_repo and _fr._repos_map_configured():
            entry = _fr._resolve_repo_map_entry(target_repo)
            if entry is None:
                return None
            return _fr.ensure_repo_checkout(
                target_repo, project_acronym=d.get("project", ""))
        return _fr.get_base_dir()
    except Exception:
        return None


def _arm_salvage_fast_path_checked(
    mso: Path, d: dict, no_salvage: bool, force_salvage: bool,
    chosen_branch: Optional[str] = None,
) -> str:
    """BUG-MSO-2026-0615: check the newest salvage branch against the CURRENT
    voyage tip before arming the fast-path, and refuse to arm it (falling
    back to the ``--no-salvage`` behaviour) when replaying it would revert
    work already on the tip.

    The staleness test is ancestry-and-content based
    (:func:`maestro.core.fleet_runner.check_salvage_staleness`), not
    elapsed time. When the check itself is undeterminable (no resolvable
    git checkout — e.g. these unit tests' bare ``.mso`` fixtures, or an
    unconfigured multi-repo target) this is a no-op: the pre-BUG-0615
    behaviour (arm unconditionally) is preserved rather than guessing.

    ``force_salvage`` is the explicit operator override in the OTHER
    direction from ``--no-salvage`` — arm anyway despite a detected
    staleness risk, with a loud warning note.

    ``chosen_branch`` (BUG-MSO-2026-0696) is the branch
    :func:`_select_salvage_for_retry` resolved — including an explicit
    ``--salvage``. The staleness check runs against THAT branch, not against
    the default pick: checking one branch and then arming another would be
    worse than not checking at all.
    """
    effective_no_salvage = no_salvage
    staleness_note = ""
    if not no_salvage:
        branch = chosen_branch if chosen_branch is not None else _newest_salvage_branch(d)
        voyage_branch = d.get("voyageBranch", "")
        if branch and voyage_branch:
            from maestro.core import fleet_runner as _fr

            with workspace_scope(mso):
                repo_root = _resolve_repo_root_for_staleness_check(d)
                result = (
                    _fr.check_salvage_staleness(repo_root, branch, voyage_branch)
                    if repo_root is not None
                    else {"checked": False, "stale": False}
                )
            if result.get("checked") and result.get("stale"):
                commits_ahead = result.get("commits_ahead", 0)
                reason = result.get("reason", "")
                if force_salvage:
                    staleness_note = (
                        f" (WARNING: salvage '{branch}' predates {commits_ahead} "
                        f"commit(s) on {voyage_branch} and would revert them — "
                        f"{reason} — forcing fast-path anyway per --force-salvage)"
                    )
                else:
                    effective_no_salvage = True
                    staleness_note = (
                        f" (salvage '{branch}' predates {commits_ahead} commit(s) "
                        f"on {voyage_branch} and would revert them — {reason} — "
                        f"retrying WITHOUT salvage; use --force-salvage to override)"
                    )
    note = _arm_salvage_fast_path(d, effective_no_salvage, chosen_branch)
    return (note or "") + staleness_note


def retry_order(
    mso: Path,
    order_id: str,
    *,
    role: Optional[str] = None,
    reason: str = "",
    force: bool = False,
    no_salvage: bool = False,
    force_salvage: bool = False,
    salvage: Optional[str] = None,
) -> RetryOutcome:
    """Reopen a terminal/stranded order in workspace *mso* for re-dispatch.

    Sole implementation of ``mso order retry`` semantics (BUG-MSO-2026-0297 /
    BUG-MSO-2026-0344) — ``cli.py``'s ``retry`` branch and the Hub's
    ``POST /orders/{id}/retry`` endpoint both call this. Explicit ``mso: Path``,
    no globals of its own; the four ``fleet_runner`` calls this makes are
    scoped via :func:`workspace_scope`.

    ``salvage`` (BUG-MSO-2026-0696) names the salvage branch to arm
    explicitly — the ``--salvage <branch>`` selector. Without it the newest
    recorded salvage is armed, EXCEPT where that default cannot be trusted
    (candidates from different roles, or an earlier candidate that contributes
    more than the newest), in which case :class:`SalvageAmbiguous` is raised
    with the full candidate list rather than a branch being guessed.

    Raises :class:`OrderNotFound` / :class:`RetryRefused` (typed, no
    printing, no ``sys.exit``) and, from the capability gate,
    ``maestro.identity.gate.CapabilityDenied``.
    """
    from maestro.core import fleet_runner as _fr
    from maestro.core import order_ledger as _ledger
    from maestro.identity.gate import require_capability

    # PLAN-FTR-MSO-2026-0492 §5.1: the gate belongs in the core, not in
    # either wrapper, so every caller (CLI and Hub) is protected identically.
    # `mso` is the artefact `.mso` dir; the gate wants the WORKSPACE ROOT
    # (its parent), matching every other require_capability() call site's
    # find_workspace() return. A no-op outside enterprise/governed
    # workspaces (require_capability short-circuits there).
    require_capability("order.dispatch", workspace=mso.parent)

    # BUG-MSO-2026-0696: --salvage names a branch to fast-converge; --no-salvage
    # promises a from-scratch re-run. Asking for both is not a preference to
    # resolve — it is two contradictory instructions, and either reading
    # silently discards what the operator asked for.
    # BUG-MSO-2026-0714: `--role` is operator input that becomes the order's
    # targetRole verbatim, so this is a FILING-TIME gate in every sense that
    # matters — and it is reached from the very command the CREW_LAUNCH_FAILED
    # advice tells an operator to run. Refusing here means a typo is answered
    # with a message naming the valid set, instead of being written to the
    # order file and rediscovered as argparse exit 2 inside a detached crew
    # process two dispatch ticks later. Applies to the Hub's
    # POST /orders/{id}/retry too — same core, one behaviour.
    if role is not None and str(role).strip() and not is_valid_role(role):
        raise RetryRefused(
            order_id,
            f"--role {role!r} is not a role — {valid_roles_message()}. "
            "FTR/BUG/SEC/INV/PLN/DOC are ORDER TYPES, not roles.",
            "Re-run naming one of the roles above.",
        )

    if salvage and no_salvage:
        raise RetryRefused(
            order_id,
            "--salvage and --no-salvage are mutually exclusive: one arms a "
            "specific salvage branch, the other refuses to arm any.",
            "Drop whichever you did not mean.",
        )

    archive_file: Optional[Path] = None
    for sub in ("complete", "failed"):
        candidate = mso / "orders" / sub / f"{order_id}.json"
        if candidate.exists():
            archive_file = candidate
            break

    queue_file: Optional[Path] = None
    queue_data: Optional[dict] = None
    if archive_file is None:
        # BUG-MSO-2026-0344: fall back to the queue tree (same coverage as
        # the stranded-order scan: queues/*/ and queues/requests/*/).
        queues_dir = mso / "queues"
        if queues_dir.exists():
            for jf in (list(queues_dir.glob("*/*.json"))
                       + list(queues_dir.glob("*/*/*.json"))):
                try:
                    d = json.loads(jf.read_text(encoding="utf-8"))
                except (OSError, json.JSONDecodeError):
                    continue
                if (d.get("orderId") or d.get("id") or jf.stem) == order_id:
                    queue_file = jf
                    queue_data = d
                    break
        if queue_file is None:
            raise OrderNotFound(order_id)

    if archive_file is not None:
        try:
            data = json.loads(archive_file.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise RetryRefused(order_id, f"Cannot read {archive_file}: {exc}")

        status = (data.get("status") or "").upper()
        if status in ("COMPLETE", "COMPLETED") and not force:
            raise RetryRefused(
                order_id,
                f"Order {order_id} is archived COMPLETE — retrying completed "
                "work re-runs and re-converges it.",
                f"If you really mean it: mso order retry {order_id} --force",
            )

        retry_role = (role or (data.get("stalledBy") or {}).get("role")
                      or data.get("targetRole") or data.get("role") or "BLD")
        data["status"] = "PENDING"
        data["targetRole"] = retry_role
        data.pop("assignedTo", None)
        data.pop("startedAt", None)
        # FTR-MSO-2026-0598: close any turn left open by the archived/stranded
        # terminal state (defensive — most archival paths already close it;
        # this guarantees the NEXT dispatch opens a fresh, distinguishable
        # turn for retry_role rather than appending onto a dangling one).
        role_history.close_role_turn(data)
        # BUG-MSO-2026-0641: a roleSucceededAt/roleSucceededBy checkpoint
        # (BUG-0222) belongs to whichever attempt wrote it, not to this reopened
        # one. _record_convergence_failure() clears it on the CONVERGENCE_FAILED
        # path, but this is the belt-and-braces backstop for every other way an
        # order can reach retry (archived terminal, hand-edited, a crash that hit
        # a code path predating that fix) — without it, a resume-finalization
        # scan on the NEXT dispatch tick could trust a checkpoint from an attempt
        # this retry is explicitly discarding, and advance/archive as though the
        # OLD attempt's work landed rather than dispatching retry_role fresh.
        data.pop("roleSucceededAt", None)
        data.pop("roleSucceededBy", None)
        data.pop("requeueCount", None)
        data.pop("networkRetry", None)  # FTR-MSO-2026-0359: reset network-retry track too
        data["retriedAt"] = datetime.now().isoformat()
        data["retriedReason"] = reason or "operator retry"
        # BUG-MSO-2026-0696: resolve the candidate set + the pick BEFORE arming,
        # so an ambiguous choice refuses the whole retry (nothing mutated) rather
        # than arming a guess. Raises SalvageAmbiguous.
        _sel = _select_salvage_for_retry(order_id, data, salvage, no_salvage)
        salvage_note = _arm_salvage_fast_path_checked(
            mso, data, no_salvage, force_salvage,
            _sel.chosen.branch if _sel.chosen else None)
        salvage_branch = (data.get("convergenceRetry") or {}).get("salvageBranch")

        queue_file = mso / "queues" / "orders" / f"{order_id}.json"
        queue_file.parent.mkdir(parents=True, exist_ok=True)
        queue_file.write_text(json.dumps(data, indent=2), encoding="utf-8")
        archive_file.unlink()
        commit_paths = [queue_file, archive_file]
        prior_state = status or "archived"
    else:
        # BUG-MSO-2026-0344: stranded queued order — reset it to PENDING in
        # place (it already sits in a scanned queue dir).
        status = (queue_data.get("status") or "").upper()
        if status == "IN_PROGRESS" and not force:
            raise RetryRefused(
                order_id,
                f"Order {order_id} is IN_PROGRESS in "
                f"queues/{queue_file.parent.name}/ — a crew may still own it.",
                f"If the crew is dead: mso order retry {order_id} --force",
            )

        data = queue_data
        # Preserve the order's own role progression unless overridden.
        retry_role = (role or data.get("targetRole") or data.get("role") or "BLD")
        data["status"] = "PENDING"
        data["targetRole"] = retry_role
        data.pop("assignedTo", None)
        data.pop("startedAt", None)
        role_history.close_role_turn(data)  # FTR-MSO-2026-0598 (see note above)
        # BUG-MSO-2026-0641: same backstop as the archived branch above — a
        # stranded/CONVERGENCE_FAILED order's roleSucceededAt/roleSucceededBy
        # checkpoint must not outlive the retry that reopens it (see the
        # sibling comment above for the full reasoning).
        data.pop("roleSucceededAt", None)
        data.pop("roleSucceededBy", None)
        data.pop("requeueCount", None)
        data.pop("networkRetry", None)  # FTR-MSO-2026-0359: reset network-retry track too
        data["retriedAt"] = datetime.now().isoformat()
        data["retriedReason"] = reason or "operator retry"
        # BUG-MSO-2026-0696: resolve the candidate set + the pick BEFORE arming,
        # so an ambiguous choice refuses the whole retry (nothing mutated) rather
        # than arming a guess. Raises SalvageAmbiguous.
        _sel = _select_salvage_for_retry(order_id, data, salvage, no_salvage)
        salvage_note = _arm_salvage_fast_path_checked(
            mso, data, no_salvage, force_salvage,
            _sel.chosen.branch if _sel.chosen else None)
        salvage_branch = (data.get("convergenceRetry") or {}).get("salvageBranch")

        tmp = queue_file.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
        tmp.replace(queue_file)
        commit_paths = [queue_file]
        prior_state = status or "queued"

    # REOPENED clears the ledger TERMINAL verdict AND any lingering claim —
    # claims carry the dispatcher's pid, so without this a RUNNING dispatcher
    # silently skips the order until restarted. record_reopened takes an
    # explicit workspace_dir already (no global to scope); the two
    # fleet_runner calls below are what need workspace_scope().
    # BUG-MSO-2026-0696: name EVERY candidate in the RETRY event, not just the
    # one armed. `mso order retry` printing them is only half the fix — the
    # lifecycle log is what a later post-mortem (or the LEAD daemon) reads, and
    # "which branches existed at the moment of the retry" is exactly the fact
    # the three recurrences of this trap each had to reconstruct by hand.
    _cand_note = ""
    if _sel.candidates:
        _cand_note = (
            f" [salvage candidates: "
            + "; ".join(c.describe() for c in _sel.candidates)
            + (f"; ARMED={_sel.chosen.branch}" if _sel.chosen else "; ARMED=none")
            + ("; selector=--salvage" if _sel.explicit else "")
            + "]"
        )
    _ledger.record_reopened(order_id, data["retriedReason"], workspace_dir=mso)
    with workspace_scope(mso):
        _fr.remove_skipped_order(order_id)  # a retried order must not stay skip-listed
        _fr.write_lifecycle_event(
            "RETRY",
            f"{order_id} reopened by operator ({data['retriedReason']}) — "
            f"{prior_state} -> PENDING@{retry_role}{salvage_note}{_cand_note} "
            f"(BUG-0297/BUG-0344/BUG-0696)"
        )
        _fr._commit_lifecycle_transition(
            commit_paths,
            f"lifecycle: retry {order_id} ({prior_state} -> PENDING@{retry_role})",
        )

    return RetryOutcome(
        order_id=order_id,
        prior_state=prior_state,
        new_status="PENDING",
        target_role=retry_role,
        salvage_note=salvage_note,
        salvage_branch=salvage_branch,
        reason=data["retriedReason"],
        salvage_candidates=[c.to_dict() for c in _sel.candidates],
        salvage_explicit=_sel.explicit,
    )
