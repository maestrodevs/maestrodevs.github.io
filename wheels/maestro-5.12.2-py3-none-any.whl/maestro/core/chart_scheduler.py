"""maestro/core/chart_scheduler.py — Maestro Charts Phase 2: the frontier scheduler.

FTR-MSO-2026-0520 (PLAN-PLN-MSO-2026-0508 §4.4, order 4 of 8). This is the
first Phase 2 module that touches the dispatch path — everything before it
(chart_schema.py, order_ledger's LAPPED event) shipped inert. It imports
``charts.py`` (Phase 1's read-only compiler/resolver) but is never imported
BY charts.py, so charts.py's own module docstring promise — "never writes a
file, never mutates ledger state, and is never called from the dispatch
loop" — stays literally true.

Two entry points, both called from exactly one guarded site in
``fleet_runner.scan_all_queues`` (§4.4):

  * :func:`charts_enabled` — the flag read. Delegates to
    ``fleet_runner.load_charts_config()`` (the workspace-config reader
    living beside ``load_completion_config``). Absent config == False.
  * :func:`release_chart_frontier` — the frontier pass itself. For every
    ACTIVE chart on a voyage with at least one referencing order in the
    live queues, compute node states via ``charts.resolve_node_states``
    (reused, never re-derived) and release every node whose ``onSuccess``
    in-edges are all satisfied and which has not itself started, to
    ``status=PENDING`` / ``targetRole=<node role>`` — via
    ``fleet_runner.release_order_to_pending``, the same writer
    BUG-MSO-2026-0499's dependent-promotion path uses. This function
    constructs no dispatch item, picks no crew, and returns only a count;
    ``scan_all_queues``'s own body runs downstream, entirely unchanged, over
    whatever this released — every existing gate (ledger veto, dependsOn,
    skip list, review gate, tool scoping, ...) still applies (§4.4's own
    argument for why this is one scheduler, not two).

Tier gating (``auth.CHART_EXEC_TIERS``, pro and above) is deliberately
NON-FATAL here: a licence tier must never crash a running dispatcher. Below
pro, this behaves exactly as flag-off and logs ``CHART_TIER_DENIED`` once
per process (the ``_BUG0263_WARNED`` once-per-process dedup pattern —
``scan_all_queues`` runs about every 10 seconds). The hard ``require_tier``
exit lives on the authoring CLI only (order 3, ``mso chart new``), not here.

Everything in this module is wrapped defensively per the plan's "Notes for
Builder": a chart failure must never crash the dispatcher.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List

from maestro.core import charts as _charts
from maestro.core import order_ledger as _order_ledger
from maestro.core.chart_schema import ChartSpec, charts_for_voyage, load_chart

# Once-per-process dedup sets — mirrors fleet_runner's `_BUG0263_WARNED`
# pattern so a per-tick scan never floods the lifecycle log.
_TIER_DENIED_WARNED = False
_NODE_UNRESOLVED_WARNED: set = set()   # {(chart_id, node_key), ...}
_CHART_DISABLED_WARNED: set = set()    # {chart_id, ...} — CHART_DISABLED already emitted
_LAST_KNOWN_ENABLED: bool = False      # for detecting a True -> False flip (§4.5)
_NODE_PARKED_WARNED: set = set()       # {(chart_id, node_key), ...} — BUG-MSO-2026-0607 finding 1


def charts_enabled() -> bool:
    """True iff ``charts.enabled`` is set in workspace.json's ``charts``
    block. Default False — an absent block is flag-off (plan §7).

    This is the ONE call ``scan_all_queues`` makes every tick regardless of
    the flag's value, so it also carries the §4.5 mid-voyage-disable
    detection: a True -> False transition observed within this process's
    lifetime emits ``CHART_DISABLED`` once per ACTIVE chart still on disk.
    A process that starts with the flag already off never fires it — there
    is no transition to observe, which is correct (nothing changed).
    """
    global _LAST_KNOWN_ENABLED
    from maestro.core.fleet_runner import load_charts_config
    try:
        enabled = bool(load_charts_config().get("enabled", False))
    except Exception:
        enabled = False

    if _LAST_KNOWN_ENABLED and not enabled:
        _note_charts_disabled()
    _LAST_KNOWN_ENABLED = enabled
    return enabled


def _note_charts_disabled() -> None:
    """§4.5: "Emit CHART_DISABLED once when the flag flips off with an
    ACTIVE chart present, so the transition is visible in the lifecycle log
    rather than inferred." Best-effort — a scan/log failure here must never
    affect the flag read itself, so every failure mode is swallowed."""
    try:
        from maestro.core.fleet_runner import get_artefact_root, write_lifecycle_event
        charts_dir = get_artefact_root() / "charts"
        if not charts_dir.is_dir():
            return
        for f in sorted(charts_dir.glob("*.json")):
            try:
                spec = load_chart(f)
            except Exception:
                continue
            if spec.status != "ACTIVE" or spec.chart_id in _CHART_DISABLED_WARNED:
                continue
            _CHART_DISABLED_WARNED.add(spec.chart_id)
            write_lifecycle_event(
                "CHART_DISABLED",
                f"charts.enabled switched off with chart {spec.chart_id} (voyage "
                f"{spec.voyage_id}) ACTIVE — orders already released continue on "
                f"their ordinary roleSequence to completion; the frontier pass and "
                f"onFail routing stop until re-enabled"
            )
    except Exception:
        pass


def _voyage_ids_referenced(workspace_dir: Path) -> List[str]:
    """Distinct ``voyageId``s across every chart file under ``charts/``,
    parse failures skipped (a single malformed chart must never block a scan
    of the rest — mirrors ``charts_for_voyage``'s own best-effort contract)."""
    charts_dir = Path(workspace_dir) / "charts"
    if not charts_dir.is_dir():
        return []
    seen: List[str] = []
    seen_set: set = set()
    for f in sorted(charts_dir.glob("*.json")):
        try:
            spec = load_chart(f)
        except Exception:
            continue
        if spec.voyage_id and spec.voyage_id not in seen_set:
            seen_set.add(spec.voyage_id)
            seen.append(spec.voyage_id)
    return seen


def release_chart_frontier(workspace_dir: Path) -> int:
    """The frontier pass. Returns the count of orders released this call.

    Callers are expected to have already checked :func:`charts_enabled` —
    this function does not re-check the flag itself (plan §4.4 step 1 splits
    "flag off" from "no charts dir / no ACTIVE chart", and the flag check is
    the guard at the call site so a chart-less workspace never even imports
    this module's heavier path).
    """
    global _TIER_DENIED_WARNED
    workspace_dir = Path(workspace_dir)
    charts_dir = workspace_dir / "charts"
    if not charts_dir.is_dir():
        return 0

    try:
        from maestro import auth
        if not auth.has_tier(auth.CHART_EXEC_TIERS):
            if not _TIER_DENIED_WARNED:
                _TIER_DENIED_WARNED = True
                from maestro.core.fleet_runner import write_lifecycle_event
                write_lifecycle_event(
                    "CHART_TIER_DENIED",
                    "charts.enabled is true but the licence tier is below the "
                    "chart-execution floor (pro+) — behaving as flag-off"
                )
            return 0
    except Exception:
        # A licence-resolution failure must never crash the dispatcher, and
        # must never fail OPEN into executing charts either.
        return 0

    released_total = 0
    try:
        for voyage_id in _voyage_ids_referenced(workspace_dir):
            released_total += _release_frontier_for_voyage(workspace_dir, voyage_id)
    except Exception:
        return released_total
    return released_total


def _release_frontier_for_voyage(workspace_dir: Path, voyage_id: str) -> int:
    charts = [c for c in charts_for_voyage(voyage_id, workspace_dir) if c.status == "ACTIVE"]
    if not charts:
        return 0
    # V8 (chart_schema.validate) enforces at most one ACTIVE chart per
    # voyage; if that invariant is somehow violated on disk, the frontier
    # pass takes the first (chartId-sorted) rather than guessing further.
    chart = charts[0]

    ledger_view = _order_ledger.load_view(workspace_dir)
    node_state = _resolve_all_node_states(chart, workspace_dir, ledger_view)

    onsuccess_in_edges: Dict[str, List[Any]] = {k: [] for k in chart.nodes}
    for e in chart.edges:
        if e.type != "onSuccess":
            continue
        for t in e.targets:
            if t in onsuccess_in_edges:
                onsuccess_in_edges[t].append(e)

    released = 0
    for key, node in chart.nodes.items():
        if node_state.get(key) != _charts.NODE_NOT_STARTED:
            continue
        in_edges = onsuccess_in_edges.get(key, [])
        if not in_edges:
            continue  # entry node (in-degree 0) — the ordinary dispatcher already owns it
        if not all(node_state.get(e.from_node) == _charts.NODE_DONE for e in in_edges):
            continue  # frontier requires ALL onSuccess in-edges satisfied

        if _release_node(workspace_dir, chart, key, node):
            released += 1
            node_state[key] = _charts.NODE_QUEUED  # so a later node in this pass sees it as advanced

    return released


def _resolve_all_node_states(chart: ChartSpec, workspace_dir: Path,
                              ledger_view: "_order_ledger.LedgerView") -> Dict[str, str]:
    # BUG-MSO-2026-0608 finding 2 (same omission as chart_schema.py:245):
    # resolve_role_sequence(order_data) with no role_sequences map falls back
    # to fleet_runner's PROCESS-GLOBAL ROLE_SEQUENCES cache, resolved from
    # get_artefact_root() — i.e. whatever workspace the caller's cwd happens
    # to resolve to, not necessarily *workspace_dir*. Resolve *workspace_dir*'s
    # own templates once (never per node) and thread that map through
    # instead, exactly as charts.py's own chart-compiling callers already do.
    role_sequences = _charts._workspace_role_sequences(workspace_dir)
    states: Dict[str, str] = {}
    for key, node in chart.nodes.items():
        order_data = _charts._load_order_data(node.order, workspace_dir)
        sequence = _charts.resolve_role_sequence(order_data, role_sequences)
        if not sequence or node.role not in sequence:
            _warn_node_unresolved(chart, key, node)
            states[key] = "UNRESOLVED"
            continue
        role_states = _charts.resolve_node_states(node.order, sequence, order_data, ledger_view)
        states[key] = role_states.get(node.role, _charts.NODE_NOT_STARTED)
    return states


def _warn_node_unresolved(chart: ChartSpec, key: str, node) -> None:
    marker = (chart.chart_id, key)
    if marker in _NODE_UNRESOLVED_WARNED:
        return
    _NODE_UNRESOLVED_WARNED.add(marker)
    try:
        from maestro.core.fleet_runner import write_lifecycle_event
        write_lifecycle_event(
            "CHART_NODE_UNRESOLVED",
            f"chart {chart.chart_id} node '{key}' ({node.order}:{node.role}) could "
            f"not be resolved (order missing/skipped, or role not in its "
            f"roleSequence) — treated as a dead end, never satisfies a frontier edge"
        )
    except Exception:
        pass


def _warn_node_parked(chart: ChartSpec, key: str, node, status: str) -> None:
    """BUG-MSO-2026-0607 finding 1: log once (per chart/node) that a
    frontier-satisfied node was deliberately left alone rather than
    force-released, so the decision to respect an operator park is visible
    in the lifecycle log instead of a silent no-op — mirrors
    :func:`_warn_node_unresolved`'s own once-per-process dedup pattern
    (this can otherwise repeat on every ~10s scan tick for as long as the
    order stays parked)."""
    marker = (chart.chart_id, key)
    if marker in _NODE_PARKED_WARNED:
        return
    _NODE_PARKED_WARNED.add(marker)
    try:
        from maestro.core.fleet_runner import write_lifecycle_event
        write_lifecycle_event(
            "WARN",
            f"chart {chart.chart_id} node '{key}' ({node.order}:{node.role}) "
            f"is frontier-satisfied but its order's status={status!r} is not "
            f"an auto-release status (PROPOSED/HELD) — treated as a "
            f"deliberate operator park, NOT force-released "
            f"(BUG-MSO-2026-0607 finding 1)"
        )
    except Exception:
        pass


def _release_node(workspace_dir: Path, chart: ChartSpec, key: str, node) -> bool:
    """Release *node*'s order to PENDING/targetRole=node.role via the shared
    BUG-MSO-2026-0499 writer. Returns True iff a write actually happened
    (already-PENDING is a no-op, not a failure, so repeated ticks don't
    needlessly rewrite the file)."""
    from maestro.core.fleet_runner import (
        _AUTO_RELEASE_STATUSES, _find_order_json_file, release_order_to_pending,
    )

    json_file = _find_order_json_file(node.order, workspace_dir)
    if json_file is None:
        return False
    try:
        data = json.loads(json_file.read_text(encoding="utf-8"))
    except Exception:
        return False

    status = str(data.get("status", "")).strip().upper()
    if status == "PENDING" and data.get("targetRole") == node.role:
        return False  # already released — nothing to do this tick

    # BUG-MSO-2026-0607 finding 1: the sibling caller of this same writer
    # (fleet_runner.promote_ready_dependents) restricts auto-release to
    # _AUTO_RELEASE_STATUSES = {PROPOSED, HELD} — this function used to flip
    # the node's order to PENDING whatever its current status was. A node
    # whose order a LEAD deliberately parked as BACKLOG/BLOCKED/DRAFT/PAUSED
    # (fleet_runner.py's own "operator parked this on purpose, an
    # auto-release would override a deliberate decision" convention, right
    # above _AUTO_RELEASE_STATUSES) resolves to NOT_STARTED chart-side (no
    # ledger history yet) exactly the same as a genuinely fresh, never-
    # touched node — so without this check, satisfying the node's in-edges
    # silently overwrote the operator's decision. Same restriction, not a
    # second rule.
    if status not in _AUTO_RELEASE_STATUSES:
        _warn_node_parked(chart, key, node, status)
        return False

    ok = release_order_to_pending(json_file, data, node.order, target_role=node.role)
    if ok:
        # BUG-MSO-2026-0551 Finding 1 (chart_routing._apply_lap's SAME gap):
        # without an ADVANCED ledger event, a `node.order` that already has
        # ANY prior ledger role (a live/past CLAIMED or ADVANCED for a
        # different role) gets reverted straight back to it by
        # scan_all_queues's BUG-0248 advance-loss guard on the very next
        # tick — the frontier release silently does not stick. Recording
        # ADVANCED is exactly what an ordinary roleSequence advance already
        # does for the same guard; a frontier release is no different from
        # that guard's point of view.
        try:
            prior_role = _order_ledger.load_view(workspace_dir).current_role(node.order)
        except Exception:
            prior_role = None
        try:
            _order_ledger.record_advanced(node.order, prior_role, node.role,
                                          workspace_dir=workspace_dir)
        except Exception:
            pass
        try:
            from maestro.core.fleet_runner import write_lifecycle_event
            write_lifecycle_event(
                "AUTOQUEUE",
                f"{node.order} released -> PENDING/targetRole={node.role} — chart "
                f"{chart.chart_id} node '{key}' frontier satisfied (FTR-MSO-2026-0520)"
            )
        except Exception:
            pass
    return ok
