# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Salvage fast-converge arming — the ONE way to wire preserved work back in.

BUG-MSO-2026-0702. Before this module, "arm the salvage fast-path" was a
verb only ``mso order retry`` knew how to say, spelled inline in
``order_retry._arm_salvage_fast_path``, and it took TWO fields to say it:

* ``convergenceRetry.salvageBranch`` — the branch to merge, and
* ``convergenceRetryCount`` — a counter whose ONLY job at the dispatch
  gate was to be ``> 0``.

Nothing documented that pairing, so the obvious operator/LEAD action —
hand-editing ``convergenceRetry.salvageBranch`` onto a PENDING order — was
silently INERT (the order's own addendum: BUG-MSO-2026-0698 was
re-dispatched 2026-09-09 09:45:25 with the branch armed, no fast-converge,
and a resume note that told the crew its work was already in the worktree
when it was not). Meanwhile the automatic REQUEUE-after-TIMEOUT path — the
one that CREATES salvage branches, several times a day — never armed
anything at all, so a crew that timed out 95% done was replaced by a fresh
crew that started from the voyage tip knowing nothing about it.

Everything that arms a salvage now goes through :func:`arm_salvage_fast_path`
here: ``fleet_runner.recover_orphaned_order`` (automatic requeue),
``order_retry.retry_order`` (``mso order retry`` AND the Hub's
``POST /orders/{id}/retry``, which share that core), and any operator edit
— because ``dispatch_squad``'s gate now honours a bare
``convergenceRetry.salvageBranch`` regardless of the counter (and WARNs
naming the field it self-healed).

Two MODES, because the two callers mean different things by "the work is
already done":

``advance`` (:data:`MODE_ADVANCE`, the legacy BUG-MSO-2026-0273 semantic,
    and the default when ``mode`` is absent — every pre-0702 order JSON
    reads back exactly as it did)
    The role FINISHED and only its convergence failed. Merging the salvage
    IS the role's completion: no crew is launched, the order advances.

``resume`` (:data:`MODE_RESUME`, new)
    The role was KILLED mid-flight (TIMEOUT/HUNG) with partial work. The
    salvage is merged into the voyage branch BEFORE the crew's worktree is
    cut, so the replacement crew opens onto its predecessor's work — but the
    role is NOT done, so a crew still runs. Its prompt (the
    ``resumeFromSalvage`` record this module writes, rendered by
    ``fleet_runner.generate_prompt_for_item``) tells it which branch was
    merged, its diff-stat, and that its job is to VERIFY against the ACs and
    finish gaps rather than rebuild from scratch.

Pure dict-in/dict-out: no git, no filesystem, no logging. Callers own their
own persistence and their own lifecycle events, so this module is safe to
import from ``fleet_runner``, ``order_retry``, the Hub and the CLI alike
without a cycle, and is exhaustively testable without a repo.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, Optional

from maestro.core import salvage_record  # BUG-MSO-2026-0696: ONE salvage record per order

__all__ = [
    "MODE_ADVANCE",
    "MODE_RESUME",
    "ARMED_BY_REQUEUE",
    "ARMED_BY_RETRY",
    "ARMED_BY_OPERATOR",
    "newest_salvage_record",
    "arm_salvage_fast_path",
    "clear_salvage_arming",
    "armed_salvage",
    "arming_mode",
    "resume_record",
    "record_resume_outcome",
    "format_diff_stat",
]

#: Merging the salvage completes the role — no crew runs (BUG-MSO-2026-0273).
MODE_ADVANCE = "advance"
#: Merging the salvage only SEEDS the next crew — a crew still runs (BUG-0702).
MODE_RESUME = "resume"

ARMED_BY_REQUEUE = "requeue"
ARMED_BY_RETRY = "order-retry"
ARMED_BY_OPERATOR = "operator"


def _canonical(role: Any) -> str:
    """Canonical role code for comparison, folding the legacy nautical aliases.

    An order whose ``roleSequence`` spells BLD as the legacy ``SHP`` would
    otherwise never match a record written from a canonical ``targetRole`` (or
    vice versa), and :func:`resume_record` would fail SILENTLY — dropping the
    preserved-work section from the prompt of the very crew that needs it.
    Silence is the failure mode this whole module exists to end, so the
    comparison folds aliases rather than trusting the two spellings to agree.
    Degrades to a plain uppercase compare if gates cannot be imported.
    """
    try:
        from maestro.core.gates import canonical_role
        return canonical_role(role)
    except Exception:
        return role.strip().upper() if isinstance(role, str) else ""


def format_diff_stat(diff_stat: Optional[Dict[str, Any]]) -> str:
    """Render a diff-stat dict as ``"7 files, +864/-12"`` (``""`` if unknown).

    Used verbatim in the REQUEUE lifecycle line (so ``mso status`` and the Hub
    show the size of the preserved work without opening the order JSON) and in
    the crew prompt.
    """
    if not isinstance(diff_stat, dict):
        return ""
    files = diff_stat.get("files")
    ins = diff_stat.get("insertions")
    dels = diff_stat.get("deletions")
    if files is None and ins is None and dels is None:
        return ""
    parts = []
    if files is not None:
        parts.append(f"{files} file{'' if files == 1 else 's'}")
    if ins is not None or dels is not None:
        parts.append(f"+{ins or 0}/-{dels or 0}")
    return ", ".join(parts)


def newest_salvage_record(d: Dict[str, Any],
                          branch: Optional[str] = None) -> Optional[Dict[str, Any]]:
    """Return the salvage record this order would arm, or ``None``.

    Delegates to BUG-MSO-2026-0696's :mod:`maestro.core.salvage_record` —
    :func:`~maestro.core.salvage_record.salvage_candidates` to enumerate every
    recorded branch (the canonical ``salvageBranches[]`` history plus the
    legacy ``convergence`` / ``verify`` scalar blocks a pre-0696 order JSON
    carries), then :func:`~maestro.core.salvage_record.select_salvage` to pick
    between them.

    **This is deliberately NOT ``salvageBranches[-1]``.** "Newest" is the
    default answer, not the rule: FTR-MSO-2026-0617 recorded a TIMEOUT salvage
    (partial work) and then a VERIFY_FAILED salvage (the finished build), and
    taking the last-written entry would have armed the partial one. When the
    selector refuses to choose (candidates from different roles, or an earlier
    candidate that contributes strictly more), this falls back to the newest so
    the requeue path still hands the crew SOMETHING to inspect — the refusal is
    ``mso order retry``'s to make, because only an operator can be asked; a
    crew re-dispatch that mentions no preserved work at all is the failure this
    order exists to end.

    *branch* selects a specific recorded branch by name instead (used by
    :func:`arm_salvage_fast_path` to enrich a caller-supplied branch with the
    sha, role and diff-stat already on the order). An unmatched name resolves
    to ``None`` rather than falling back — a caller that named a branch must
    never be silently handed a different one.

    Always returns a dict shaped like a ``salvageBranches[]`` entry
    (``branch`` / ``sha`` / ``role`` / ``crew`` / ``reason`` / ``diffStat``),
    never a bare string — callers need the sha for the cherry-pick instruction
    the crew gets when the merge conflicts.
    """
    candidates = salvage_record.salvage_candidates(d)
    if not candidates:
        return None
    if branch:
        chosen = next((c for c in candidates if c.branch == branch), None)
        if chosen is None:
            return None
    else:
        sel = salvage_record.select_salvage(candidates)
        chosen = sel.chosen or candidates[-1]
    return {
        "branch": chosen.branch,
        "sha": chosen.sha,
        "role": chosen.role,
        "crew": chosen.crew,
        "reason": chosen.reason,
        "diffStat": chosen.diff_stat,
    }


def arm_salvage_fast_path(
    d: Dict[str, Any],
    *,
    branch: Optional[str] = None,
    sha: Optional[str] = None,
    role: str = "",
    crew: Optional[int] = None,
    mode: str = MODE_ADVANCE,
    armed_by: str = "",
    diff_stat: Optional[Dict[str, Any]] = None,
    voyage_branch: str = "",
) -> Optional[Dict[str, Any]]:
    """Arm *d* so the next dispatch merges preserved work before doing anything else.

    *branch* / *sha* default to :func:`newest_salvage_record`'s answer (which
    is BUG-MSO-2026-0696's selector, not ``salvageBranches[-1]``), so the
    common call is simply ``arm_salvage_fast_path(order, mode=MODE_RESUME,
    armed_by=ARMED_BY_REQUEUE)``. A caller-supplied *branch* is looked up in
    the same records, so it is enriched rather than left bare.

    Writes BOTH halves of the arming contract, which is the whole point of
    this function existing:

    * ``convergenceRetry`` — ``{salvageBranch, strandedSha, mode, armedBy,
      armedAt}``, the block ``dispatch_squad``'s fast-path gate reads.
    * ``convergenceRetryCount`` — bumped to at least 1. The gate no longer
      REQUIRES it (BUG-0702 made a bare ``salvageBranch`` sufficient), but it
      is still what every pre-0702 reader looks at, so we keep writing it.
    * ``resumeFromSalvage`` — in :data:`MODE_RESUME` only: the durable record
      the crew prompt renders. It survives the ``convergenceRetry`` block
      being consumed and cleared at dispatch, which is exactly what makes the
      "never re-dispatched with no mention of preserved work" guarantee hold
      even when the merge itself fails.

    Returns the ``resumeFromSalvage``-shaped record that was armed (also
    returned in ``advance`` mode, where it is not persisted, so callers get a
    uniform handle for their log line), or ``None`` when there is no salvage
    branch to arm — an unarmed order is left completely untouched.
    """
    # Resolve the record ONCE, whether the caller named a branch or not: a
    # caller that supplies only a name (``mso order retry``'s selector, an
    # operator edit) still gets the sha, role, crew and diff-stat the order
    # already recorded for it. Without that, `convergenceRetry.strandedSha`
    # would be None on exactly the path where the crew needs it most — the
    # cherry-pick instruction it is given when the merge conflicts.
    found = newest_salvage_record(d, branch=branch)
    if found:
        branch = branch or found.get("branch")
        sha = sha or found.get("sha")
        role = role or found.get("role") or ""
        if crew is None:
            crew = found.get("crew")
        if not diff_stat:
            diff_stat = found.get("diffStat")
    if not branch:
        return None

    now = datetime.now().isoformat()
    d["convergenceRetry"] = {
        "salvageBranch": branch,
        "strandedSha": sha,
        "mode": mode,
        "armedBy": armed_by or ARMED_BY_OPERATOR,
        "armedAt": now,
    }
    # The dispatch gate no longer depends on this counter, but `mso status`,
    # the Hub and the _CONVERGENCE_RETRY_CAP ceiling all still read it — a
    # `convergenceRetry` block with a zero count would be a lie about how
    # many times this order has been re-armed.
    try:
        count = int(d.get("convergenceRetryCount") or 0)
    except (TypeError, ValueError):
        count = 0
    d["convergenceRetryCount"] = max(count, 1)

    record = {
        "branch": branch,
        "sha": sha,
        "role": role,
        "crew": crew,
        "mode": mode,
        "armedBy": armed_by or ARMED_BY_OPERATOR,
        "armedAt": now,
        "voyageBranch": voyage_branch or d.get("voyageBranch", ""),
        "diffStat": diff_stat or {},
        # Filled in at dispatch by record_resume_outcome(): did the merge land?
        "merged": None,
    }
    if mode == MODE_RESUME:
        d["resumeFromSalvage"] = record
    return record


def clear_salvage_arming(d: Dict[str, Any], *, keep_resume_record: bool = False) -> None:
    """Disarm *d* — the inverse of :func:`arm_salvage_fast_path`.

    ``mso order retry --no-salvage`` promises a from-scratch re-run, so it
    must actively clear a PRE-EXISTING arming (e.g. one this order's automatic
    requeue path armed an hour earlier) rather than merely declining to add
    one. *keep_resume_record* is for the dispatch path, which consumes the
    ``convergenceRetry`` block but must leave ``resumeFromSalvage`` in place —
    that is what the crew prompt reads.
    """
    d.pop("convergenceRetry", None)
    d.pop("convergenceRetryCount", None)
    if not keep_resume_record:
        d.pop("resumeFromSalvage", None)


def armed_salvage(d: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Return *d*'s ``convergenceRetry`` block iff it actually names a branch.

    Named ``armed_salvage`` rather than ``salvage_arming`` so a caller that
    imports the MODULE (``from maestro.core import salvage_arming``) never has
    to write ``salvage_arming.salvage_arming(...)``.
    """
    block = d.get("convergenceRetry")
    if isinstance(block, dict) and block.get("salvageBranch"):
        return block
    return None


def arming_mode(d: Dict[str, Any]) -> str:
    """Resolve the arming mode of *d*, defaulting to :data:`MODE_ADVANCE`.

    An order JSON written before BUG-MSO-2026-0702 carries no ``mode`` key —
    it must keep meaning what it always meant (merge the salvage, advance the
    order, launch no crew), so the absent value can never be RESUME.
    """
    block = armed_salvage(d) or {}
    mode = block.get("mode")
    return MODE_RESUME if mode == MODE_RESUME else MODE_ADVANCE


def resume_record(d: Dict[str, Any], role: str = "") -> Optional[Dict[str, Any]]:
    """Return *d*'s ``resumeFromSalvage`` record, optionally scoped to *role*.

    ``generate_prompt_for_item`` passes the role it is generating for: a BLD
    crew's preserved work is not the TST crew's business, and rendering a
    stale BLD resume note into a TST prompt would tell that crew its work is
    already in the worktree when it never started any. A record with no
    recorded role (an operator-armed one, say) matches every role rather than
    vanishing — silence is the failure mode this order exists to end.
    """
    record = d.get("resumeFromSalvage")
    if not isinstance(record, dict) or not record.get("branch"):
        return None
    recorded = record.get("role")
    if role and recorded and _canonical(recorded) != _canonical(role):
        return None
    return record


def record_resume_outcome(
    d: Dict[str, Any],
    *,
    merged: bool,
    error: str = "",
    diff_stat: Optional[Dict[str, Any]] = None,
) -> None:
    """Stamp the result of the pre-dispatch merge onto *d*'s resume record.

    ``merged=False`` is NOT a failure to report and forget: it is precisely
    the case where the crew prompt must switch from "your predecessor's work
    is already in your worktree" to "it is NOT — inspect ``git show <sha>`` /
    cherry-pick it first". A no-op when nothing is armed.
    """
    record = d.get("resumeFromSalvage")
    if not isinstance(record, dict):
        return
    record["merged"] = bool(merged)
    record["mergeAttemptedAt"] = datetime.now().isoformat()
    if error:
        record["mergeError"] = error
    else:
        record.pop("mergeError", None)
    if diff_stat:
        record["diffStat"] = diff_stat
