# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""maestro/lead/daemon.py — LEAD daemon lifecycle (PLAN-PLN-MSO-2026-0504 §3.1).

A per-workspace detached process, supervised by nothing, discoverable by an
identity-verified PID record — the same shape as `maestro/hub/daemon.py`
(BUG-MSO-2026-0424), but per-WORKSPACE (PID file under the workspace's own
artefact root) rather than global, and via `maestro.proc_identity` directly
since this module has no legacy call sites to preserve.

Deliberately NOT a crew slot and NOT a dispatcher child (§3.1/§3.2):

  * It must outlive the dispatcher — the whole point is to still be there,
    and still able to report, after the dispatcher exits. §3.2 point 2 also
    notes the inversion this implies: the LEAD supervises the dispatcher
    (via the patrol's dispatcher-liveness checks), not the reverse.
  * `get_available_crews()` (fleet_runner.py) enumerates `crews/crew{1..5}`
    only; this daemon never touches that directory, so it structurally
    cannot consume a crew slot — there is nothing here for that function to
    see.

Tier gating (`auth.require_tier(auth.LEAD_AGENT_TIERS, ...)`) happens at the
CLI call site (`cli.cmd_lead`), mirroring where `cmd_hub` gates `hub.start()`
— this module stays licence-agnostic so its lifecycle can be exercised in
tests without licence machinery.
"""

from __future__ import annotations

import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Optional

from maestro import proc_identity
from maestro.launch.sandbox import spawn as _spawn

# Module reference (not bare-name imports) so tests can patch
# `maestro.proc_identity.process_create_time` ONCE and have it take effect
# both here (start()'s direct call) and inside proc_identity.is_running()'s
# own internal call — a bare-name import would freeze this module's copy at
# import time, requiring a second patch target for the same fake.


def _pid_file(artefact_root: Path) -> Path:
    return artefact_root / "lead" / "lead.pid"


def start(artefact_root: Path, workspace_root: Optional[Path] = None, force: bool = False) -> None:
    """Start the LEAD daemon for the workspace rooted at *artefact_root*.

    Idempotent: a genuinely running daemon (identity-verified) is left
    alone unless *force*. A stale record (dead PID, recycled PID, or a
    different process entirely) is cleared and a fresh daemon started —
    never signalled, per the BUG-MSO-2026-0424 rule that no signal is ever
    sent to a PID that fails identity verification.
    """
    pid_file = _pid_file(artefact_root)
    running, existing_pid = proc_identity.is_running(pid_file)
    if running and not force:
        print(f"[LEAD] Already running (PID: {existing_pid})")
        return
    if not running and pid_file.exists():
        pid_file.unlink()

    cmd = [sys.executable, "-m", "maestro.lead", "--artefact-root", str(artefact_root)]
    if workspace_root is not None:
        # FTR-MSO-2026-0585 (RC-2): *workspace_root* was previously only
        # handed to _spawn()'s own `workspace=` kwarg (sandbox env-building /
        # audit — never the child's argv), so the daemon process itself had
        # no idea where the product repo was. Thread it onto the child's
        # command line too, so __main__.py's argparse actually receives it.
        cmd += ["--workspace", str(workspace_root)]
    pid_file.parent.mkdir(parents=True, exist_ok=True)

    if os.name == "nt":
        DETACHED_PROCESS = 0x00000008
        CREATE_NEW_PROCESS_GROUP = 0x00000200
        proc = _spawn(
            cmd,
            identity="lead",
            workspace=workspace_root,
            creationflags=DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    else:
        proc = _spawn(
            cmd,
            identity="lead",
            workspace=workspace_root,
            start_new_session=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

    proc_identity.write_identity_record(pid_file, proc.pid, proc_identity.process_create_time(proc.pid))
    print(f"[LEAD] Started (PID {proc.pid})")


def stop(artefact_root: Path) -> None:
    pid_file = _pid_file(artefact_root)
    running, pid = proc_identity.is_running(pid_file)
    if not running:
        # Not our daemon (dead, recycled PID, or a different process
        # entirely). Send NO signal, always clear the stale record.
        print("[LEAD] Not running")
        if pid_file.exists():
            pid_file.unlink()
        return

    try:
        if os.name == "nt":
            # /F (force): the daemon is a plain background loop with no
            # window/console message pump, so a non-forced taskkill (the
            # WM_CLOSE-style request maestro/hub/daemon.py sends) has
            # nothing to receive it and the process is left running —
            # verified empirically while building this module. SIGTERM on
            # POSIX has no such gap (Python's default handler always acts
            # on it), so only the Windows branch needs the stronger flag.
            subprocess.run(["taskkill", "/F", "/PID", str(pid)], capture_output=True, timeout=10)
        else:
            os.kill(pid, 15)  # SIGTERM
        print(f"[LEAD] Stop signal sent (PID: {pid})")
    except Exception as exc:
        print(f"[LEAD] Failed to stop: {exc}", file=sys.stderr)

    time.sleep(1)
    if pid_file.exists() and not proc_identity.is_running(pid_file)[0]:
        pid_file.unlink()


def restart(artefact_root: Path, workspace_root: Optional[Path] = None) -> None:
    stop(artefact_root)
    start(artefact_root, workspace_root)


def _installed_version() -> Optional[str]:
    try:
        import maestro
        return getattr(maestro, "__version__", None)
    except Exception:
        return None


def status(artefact_root: Path) -> dict:
    from maestro.lead.agent import load_lead_config, load_state

    running, pid = proc_identity.is_running(_pid_file(artefact_root))
    state = load_state(artefact_root)
    cfg = load_lead_config(artefact_root)

    # PLAN-PLN-MSO-2026-0584 Dimension A: read from the DURABLE config, not
    # state.json — a toggle must render immediately, not only after the
    # daemon's next tick has had a chance to persist it. A daemon that is
    # currently STOPPED can still carry `standDown=true` here (it was stood
    # down before it was stopped) — `running` is what tells "off by choice"
    # (running + standDown) apart from "not running at all".
    stand_down = bool(cfg.get("standDown", False))

    # RC-5: the daemon pins its code at process START. `runningVersion` is
    # what the LAST tick actually wrote (persisted even by a skipped,
    # stood-down tick — see agent.run_once) — absent on a daemon that has
    # never ticked since this order landed. `installedVersion` is what THIS
    # reader (the CLI process or the Hub backend) resolves right now, which
    # may differ from a long-running daemon after a `pip install`.
    running_version = state.get("runningVersion")
    installed_version = _installed_version()
    version_mismatch = bool(running_version) and running_version != installed_version

    return {
        "running": running,
        "pid": pid if running else None,
        "standDown": stand_down,
        "runningVersion": running_version,
        "installedVersion": installed_version,
        "versionMismatch": version_mismatch,
        "lastTickAt": state.get("lastTickAt"),
        "lastOutcome": state.get("lastOutcome"),
        "lastReason": state.get("lastReason"),
        "dispatcherState": state.get("lastDispatcherState"),
        "lastFindingsCount": state.get("lastFindingsCount"),
        # FTR-MSO-2026-0539: severity breakdown behind lastFindingsCount,
        # written by agent.run_once(). Absent on a daemon that has never
        # ticked — callers must not assume the key exists.
        "lastFindingsBySeverity": state.get("lastFindingsBySeverity"),
        # PLAN-PLN-MSO-2026-0584 Dimension C3: distinguishes "nothing needed
        # doing" from "the action path is broken" — see
        # bands.ActionTickSummary's docstring. Absent on a daemon that has
        # never ticked since this order landed.
        "lastActions": state.get("actions"),
        # Only set on a tick that actually executed or errored an action
        # (see agent.run_once) — otherwise carried forward unchanged, so
        # this is the TRUE last-fired timestamp across ticks, never "now" on
        # every quiet one.
        "lastActionAt": state.get("lastActionAt"),
        # PLAN-PLN-MSO-2026-0584 Dimension D: per-finding fingerprint +
        # acknowledgement metadata (attached by agent._apply_acknowledgement_detail),
        # so `mso lead status` can show operators which fingerprint to hand
        # to `mso lead ack` without a separate `mso doctor --json` round trip.
        "lastFindingsDetail": state.get("lastFindingsDetail"),
        "lastAckSuppressed": state.get("lastAckSuppressed"),
    }


def print_status(artefact_root: Path) -> None:
    s = status(artefact_root)
    print("\n  LEAD — STATUS")
    print("  " + "-" * 40)
    if s["running"]:
        # PLAN-PLN-MSO-2026-0584 Dimension A: "a stood-down daemon is NOT a
        # stopped one" — a live, heartbeating process deliberately doing no
        # work must never render identically to a dead one.
        if s.get("standDown"):
            print(f"  Status:  RUNNING — STOOD DOWN (PID: {s['pid']})")
        else:
            print(f"  Status:  RUNNING (PID: {s['pid']})")
    else:
        print("  Status:  STOPPED")
    version_line = f"  Running version: {s.get('runningVersion') or '(never ticked)'}"
    if s.get("versionMismatch"):
        version_line += f"  [STALE — installed is {s.get('installedVersion')}]"
    print(version_line)
    print(f"  Last tick:      {s['lastTickAt'] or '(never)'}")
    print(f"  Last outcome:   {s['lastOutcome'] or '(none)'}"
          + (f" ({s['lastReason']})" if s.get("lastReason") else ""))
    print(f"  Dispatcher:     {s['dispatcherState'] or 'unknown'}")
    print(f"  Last findings:  {s['lastFindingsCount'] if s['lastFindingsCount'] is not None else '-'}")
    actions = s.get("lastActions") or {}
    print(
        "  Last actions:   "
        f"considered={actions.get('considered', 0)} eligible={actions.get('eligible', 0)} "
        f"executed={actions.get('executed', 0)} refused={actions.get('refused', 0)} "
        # BUG-MSO-2026-0636 (F5): precondition_refused (a distinct case from
        # 'refused' — see ActionTickSummary's docstring) was persisted but
        # never actually shown here.
        f"precondition_refused={actions.get('precondition_refused', 0)} "
        f"errors={actions.get('errors', 0)}"
    )
    print(f"  Last LEAD_ACTION: {s['lastActionAt'] or '(never)'}")
    if s.get("lastAckSuppressed"):
        print(f"  Ack-suppressed:   {s['lastAckSuppressed']} finding(s) this tick")
    findings_detail = s.get("lastFindingsDetail") or []
    if findings_detail:
        print("  Open findings (fingerprint — for `mso lead ack --fingerprint <fp>`):")
        for f in findings_detail:
            fp = f.get("fingerprint") or "?"
            fp_short = fp[:12] if fp != "?" else fp
            tag = ""
            if f.get("acknowledged"):
                tag = f"  [ACKED by {f.get('acknowledgedBy') or '?'} until {f.get('acknowledgedExpiresAt') or '?'}]"
            print(
                f"    [{f.get('severity', '?').upper():<8}] {fp_short}…  "
                f"{f.get('title') or f.get('checkId') or '(untitled)'}{tag}"
            )
    print("  " + "-" * 40)
    print()


def run_foreground_once(artefact_root: Path, workspace_root: Optional[Path] = None) -> "object":
    """`mso lead run --once` — a single foreground pass, no daemon spawned.
    Also what a B2 interactive session calls (plan §3, B2 tier).

    *workspace_root* (FTR-MSO-2026-0585 / RC-2): threaded through to
    ``run_once`` exactly like the resident daemon's own ``--workspace`` —
    so a foreground pass's ``checks_run`` matches ``mso doctor``'s on the
    same workspace, not the ambiently-rooted daemon's undercount. ``None``
    preserves the prior no-workspace behaviour for any existing caller.
    """
    from maestro.lead.agent import run_once
    if workspace_root is not None:
        return run_once(artefact_root, workspace=workspace_root)
    return run_once(artefact_root)
