# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""maestro/lead/agent.py — one LEAD wake cycle, with an explicit terminal state.

Captain ruling D8 (2026-08-25, on FTR-MSO-2026-0536's own order text) re-framed
what looked like a spend-cap question into a termination-condition requirement:

    "the important element is knowing what tasks the Lead is responsible for
    and not to just keep working forever, there needs to be a point when the
    task is done or the lead needs to report back to the captain"

So every :class:`Task` this module runs has exactly two exits — reflected in
:class:`TaskOutcome`:

  * ``DONE``          — the task's own definition of done was reached.
  * ``REPORTED_BACK``  — it was not (or could not be) reached, and why is
                        recorded in :attr:`TaskResult.reason` /
                        :attr:`TaskResult.detail`. A hit token ceiling is
                        classified here too, not as a third exit — the
                        ceiling is a BACKSTOP against runaway spend, never a
                        routine way for work to end, so it is always logged
                        as an ABNORMAL report-back (`LEAD_CEILING_HIT`), never
                        folded silently into "done".

The only task type this order wires up is a patrol tick — read `mso doctor`'s
findings and report them, plus a small transition-based check of its own
(§ below) that a shared, stateless patrol check structurally cannot express.
It is a single bounded subprocess-free read, so it always reaches DONE on its
own; the ceiling short-circuits BEFORE it runs, so the "cannot end only by
exhausting a budget" guarantee is visible even though this task type could
never itself exhaust one. Later orders (plan §14 order 7) add task types that
actually spend tokens — they plug into this same two-exit contract rather
than inventing a second one.

Token accounting: nothing in this order actually spends a token (patrol
reads are pure subprocess-free disk reads), so :func:`record_token_spend` has
no caller yet — it exists so a later order's LLM-invoking task type has
somewhere to report spend without a second ceiling mechanism appearing next
to this one.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Optional

from maestro.core.lifecycle_log import sanitize_lifecycle_message

# ---------------------------------------------------------------------------
# Defaults — named here, ONCE, and only ever read through load_lead_config().
# No other module may hardcode a heartbeat interval or a token ceiling.
# ---------------------------------------------------------------------------

# PLAN-PLN-MSO-2026-0504 §12.1: "one cheap continuous heartbeat... default 5
# min, configurable."
DEFAULT_HEARTBEAT_SECONDS = 300

# FTR-MSO-2026-0577: state.json is read on every Hub poll, and one tick on
# the MSO fleet already produced 19 findings (200+ is plausible on a bigger
# one) — so the persisted per-finding DETAIL (as opposed to the severity
# counts, which are never bounded) is capped. Highest severities are kept
# first; the true total and a truncation flag are persisted alongside so a
# client can say "showing 50 of 200" instead of silently implying 50 is all
# there is.
MAX_PERSISTED_FINDINGS = 50

# Captain ruling D8 (2026-08-25): "This should be configurable, as it depends
# on the volume of work" — a NUMBER still has to ship as the shipped default
# (§5.2's "useful with zero configuration" precedent), so one is chosen here,
# conservatively, and named in this order's handoff so it can be changed
# knowingly. 200,000 tokens/day is roughly what a handful of short Sonnet
# completions cost — enough headroom for the "delta non-empty" invocations
# §6's noise-control addendum describes, not enough to bankroll a runaway
# agentic loop unnoticed for a day.
DEFAULT_DAILY_TOKEN_CEILING = 200_000

_STATE_FILENAME = "state.json"


class TaskOutcome(str, Enum):
    """The only two ways a LEAD task ends (Captain ruling D8). Never a third."""

    DONE = "done"
    REPORTED_BACK = "reported_back"


@dataclass(frozen=True)
class TaskResult:
    outcome: TaskOutcome
    summary: str
    reason: Optional[str] = None
    findings_count: int = 0
    tokens_spent: int = 0
    detail: str = ""


# ---------------------------------------------------------------------------
# Config resolution — mirrors fleet_runner.load_completion_config()'s shape:
# read config/workspace.json, fall back to the shipped defaults on any
# absence/malformed content (fail-safe, never an exception to the caller).
# ---------------------------------------------------------------------------

def load_lead_config(artefact_root: Path) -> dict:
    """Resolve the ``lead`` block of ``config/workspace.json``.

    Returns a dict with keys ``enabled``, ``heartbeatSeconds``,
    ``tokenCeiling.dailyTokens``, ``standDown``. Absent/unreadable/malformed
    config, or a missing ``lead`` block entirely, all resolve to the shipped
    defaults — the block being absent enables sane behaviour, it never
    disables the daemon outright (same fail-safe shape as ``completion`` in
    ``load_completion_config``).

    ``standDown`` (PLAN-PLN-MSO-2026-0584 Dimension A) is the durable,
    per-workspace on/off switch: ``lead.standDown: true`` in
    ``workspace.json`` is read fresh on every loop iteration (see
    ``maestro.lead.__main__``), so a toggle survives a daemon restart with
    no extra plumbing — this function is the ONLY reader, mirroring
    ``enabled``'s own (previously inert) shape.
    """
    ws_file = artefact_root / "config" / "workspace.json"
    try:
        data = json.loads(ws_file.read_text(encoding="utf-8"))
        raw = data.get("lead", {}) or {}
    except Exception:
        raw = {}

    ceiling = raw.get("tokenCeiling", {}) or {}

    return {
        "enabled": bool(raw.get("enabled", True)),
        "heartbeatSeconds": int(raw.get("heartbeatSeconds", DEFAULT_HEARTBEAT_SECONDS)),
        "tokenCeiling": {
            "dailyTokens": int(ceiling.get("dailyTokens", DEFAULT_DAILY_TOKEN_CEILING)),
        },
        "standDown": bool(raw.get("standDown", False)),
        # BUG-MSO-2026-0712: may the LEAD bring the (global) Hub daemon back
        # up unattended when `hub.alive` finds it dead or wedged? Default
        # FALSE — the order is explicit that restarting the Hub is NOT added
        # to Captain ruling D7's default act-and-inform band without a
        # Captain ruling. Read by `maestro.lead.bands.apply_config_opt_in`,
        # which promotes `hub.restart` for this workspace only, and only
        # when no policy tier has pinned a band of its own.
        "hubAutoRestart": bool(raw.get("hubAutoRestart", False)),
    }


def set_stand_down(artefact_root: Path, value: bool) -> Path:
    """Idempotently set ``lead.standDown`` in ``config/workspace.json`` —
    the durable source of truth both the CLI (``mso lead stand-down`` /
    ``resume``) and the Hub's stand-down endpoints write to
    (PLAN-PLN-MSO-2026-0584 Dimension A). Mirrors
    ``maestro.governance.authoring.write_governed_mode``'s read-merge-write
    shape: an absent/corrupt file starts from ``{}`` rather than failing,
    and only the ``lead`` key is touched — every other config block (and any
    other ``lead.*`` key, e.g. ``heartbeatSeconds``) survives untouched.
    """
    ws_file = artefact_root / "config" / "workspace.json"
    data: dict = {}
    if ws_file.exists():
        try:
            data = json.loads(ws_file.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                data = {}
        except (json.JSONDecodeError, OSError):
            data = {}
    lead_block = data.get("lead", {}) or {}
    lead_block["standDown"] = bool(value)
    data["lead"] = lead_block
    ws_file.parent.mkdir(parents=True, exist_ok=True)
    ws_file.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    return ws_file


def _running_version() -> str:
    """The version of ``maestro`` THIS process is executing (RC-5) — pinned
    at daemon process start (Python module caching), so a ``pip install``
    mid-run never reaches an already-running daemon. Persisted into
    ``state.json`` every tick (even a skipped/stood-down one) so a reader
    (``mso lead status`` / the Hub strip) can compare it against ITS OWN
    ``maestro.__version__`` and surface "your daemon is running stale code"
    instead of that fact staying silent, as it did for PID 680 on
    2026-08-27."""
    import maestro
    return getattr(maestro, "__version__", "unknown")


# ---------------------------------------------------------------------------
# Persisted daemon state — `.mso/lead/state.json` (gitignored runtime plane,
# same class as `.mso/state/order-ledger.jsonl`). Tracks what the daemon
# reported last time so a stateless re-derivation on every tick can't
# distinguish "always been stopped" (not alarming) from "just stopped"
# (alarming) — see `_dispatcher_watch_finding` below.
# ---------------------------------------------------------------------------

def _state_file(artefact_root: Path) -> Path:
    return artefact_root / "lead" / _STATE_FILENAME


def load_state(artefact_root: Path) -> dict:
    try:
        return json.loads(_state_file(artefact_root).read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save_state(artefact_root: Path, state: dict) -> None:
    f = _state_file(artefact_root)
    f.parent.mkdir(parents=True, exist_ok=True)
    f.write_text(json.dumps(state, indent=2), encoding="utf-8")


def _today(now: datetime) -> str:
    return now.astimezone(timezone.utc).date().isoformat()


def _daily_tokens_spent_so_far(artefact_root: Path, now: datetime) -> int:
    state = load_state(artefact_root)
    if state.get("dailyWindowDate") != _today(now):
        return 0
    return int(state.get("dailyTokensSpent", 0) or 0)


def record_token_spend(artefact_root: Path, tokens: int, *, now: Optional[datetime] = None) -> int:
    """Add *tokens* to today's spend counter and return the new total.

    Rolls the counter over at UTC midnight. No caller exists yet in this
    order (see module docstring) — this is the single accounting surface a
    later, LLM-invoking task type reports into, so the ceiling this module
    enforces and the spend a future task records are never two mechanisms.
    """
    now = now or datetime.now(timezone.utc)
    today = _today(now)
    state = load_state(artefact_root)
    if state.get("dailyWindowDate") != today:
        spent = 0
    else:
        spent = int(state.get("dailyTokensSpent", 0) or 0)
    spent += max(0, int(tokens))
    state["dailyWindowDate"] = today
    state["dailyTokensSpent"] = spent
    _save_state(artefact_root, state)
    return spent


def _write_lifecycle_event(artefact_root: Path, event_type: str, message: str) -> None:
    """Append a lifecycle.log line without depending on fleet_runner's
    ambient workspace resolution — this module always has an explicit
    *artefact_root* (the daemon is a separately-spawned process, not
    guaranteed to share the dispatcher's cwd/env resolution)."""
    log_dir = artefact_root / "logs"
    try:
        log_dir.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        line = f"{timestamp} | {event_type:<10} | {sanitize_lifecycle_message(message)}\n"
        with open(str(log_dir / "lifecycle.log"), "a", encoding="utf-8") as f:
            f.write(line)
    except OSError:
        pass


# ---------------------------------------------------------------------------
# Persisted finding DETAIL (FTR-MSO-2026-0577) — the substance behind the
# severity counts, bounded so state.json stays cheap to read on every Hub
# poll.
# ---------------------------------------------------------------------------

def _findings_detail_payload(findings, cap: int = MAX_PERSISTED_FINDINGS) -> tuple[list[dict], int, bool]:
    """Bounded, severity-ranked finding detail for ``state.json``.

    Returns ``(detail, total, truncated)``. When *findings* exceeds *cap*,
    the HIGHEST severities are kept (never a positional/arbitrary slice) so
    the drawer's truncated list is still the set an operator would act on
    first. ``total`` is the TRUE count (matches ``lastFindingsCount``,
    already persisted uncapped) — the Hub says "showing X of Y" from these
    two numbers rather than inferring Y from ``len(detail)``.
    """
    from maestro.patrol.registry import severity_rank

    total = len(findings)
    # `f.check_id or ""` / `f.subject_id or ""`: defensive against
    # BUG-MSO-2026-0576 (findings observed with a null check_id) — a sort
    # key must never mix None and str, whether or not that bug is still
    # live when this runs.
    ordered = sorted(
        findings,
        key=lambda f: (-severity_rank(f.severity), f.check_id or "", f.subject_id or ""),
    )
    capped = ordered[:cap]
    detail = [
        {
            "checkId": f.check_id,
            "subjectId": f.subject_id,
            "severity": f.severity,
            "title": f.title,
            "detail": f.detail,
            "firstSeenAt": f.firstSeenAt,
            "suggestedCommand": f.suggestedCommand,
            "scope": f.scope,
        }
        for f in capped
    ]
    return detail, total, total > cap


def _apply_acknowledgement_detail(
    detail: "list[dict]", delta_findings, patrol_state: dict, now: datetime,
) -> "list[dict]":
    """Attach ``fingerprint`` + acknowledgement metadata to each entry
    ``_findings_detail_payload`` already built (PLAN-PLN-MSO-2026-0584
    Dimension D) — kept as a separate post-processing step, rather than
    folded into ``_findings_detail_payload`` itself, so that function's
    existing signature/behaviour (and the tests calling it directly with a
    bare ``Finding`` list) is untouched.

    Matched by ``(checkId, subjectId, severity)`` — the same identity
    ``_findings_detail_payload`` already serialises per entry, and unique
    enough within one tick's open-findings set for this purpose (two
    distinct findings sharing all three would also share a fingerprint,
    which is check_id + subject_id + BASE severity — a coincidence this
    module has no reason to guard against separately from that).
    """
    from maestro.patrol.state import get_acknowledgement, is_acknowledged

    fp_by_key = {
        (d.finding.check_id, d.finding.subject_id, d.finding.severity): d.fingerprint
        for d in delta_findings
    }
    for entry in detail:
        fp = fp_by_key.get((entry.get("checkId"), entry.get("subjectId"), entry.get("severity")))
        entry["fingerprint"] = fp
        ack = get_acknowledgement(patrol_state, fp) if fp else None
        if ack is not None:
            entry["acknowledged"] = is_acknowledged(patrol_state, fp, entry.get("severity"), now=now)
            entry["acknowledgedBy"] = ack.get("by")
            entry["acknowledgedNote"] = ack.get("note") or ""
            entry["acknowledgedExpiresAt"] = ack.get("expiresAt")
        else:
            entry["acknowledged"] = False
    return detail


# ---------------------------------------------------------------------------
# The one task type this order wires up: a patrol tick.
# ---------------------------------------------------------------------------

def _dispatcher_watch_finding(dispatcher_status: dict, prior_state: dict, now: datetime):
    """A ``Finding`` for "the dispatcher I am watching has died", built fresh
    every tick for as long as that stays true (PLAN-PLN-MSO-2026-0584
    Dimension B) — this is the fix for the old edge-triggered detector's
    silence after its first tick: the overnight 2026-08-27/28 incident
    stayed wedged for eight hours and was reported once, then never again.
    Folding this into a proper ``Finding`` (rather than writing a bare
    string straight to the lifecycle log, as the pre-Dimension-B version
    did) means it gets a stable fingerprint and flows through
    ``compute_delta`` exactly like every other patrol finding: NEW once,
    then UNCHANGED (still visible in every tick's open-findings count/
    detail) for as long as the dispatcher stays down, never re-delivered.

    Scope is deliberately STOPPED only, not WEDGED — `dispatcher.heartbeat`
    (maestro.patrol.checks.dispatcher) already reports WEDGED as a
    `critical` Finding with a pid-stable subject_id, and that finding
    already flows through the same delta this function's output joins.
    Once severity-tiered delivery is wired onto that shared delta, the
    heartbeat check's own finding already gets exactly the "report once,
    stay visible, one Slack ever" treatment the wedge evidence calls for —
    duplicating that here as a second, differently-fingerprinted finding
    for the SAME real-world incident would mean two independent Slack
    messages for one wedge. STOPPED (dead pid) is the one dispatcher state
    `dispatcher.heartbeat` deliberately never reports (its own
    test_dispatcher_check_dead_pid_no_finding invariant), and is exactly
    what this daemon's own cross-tick memory ("I watched it running, and
    now it is gone") was built for.

    Returns ``None`` for a dispatcher that was simply never started — a
    dead PID looks identical on disk to one that exited cleanly, and
    neither is an alarm — gated on ``dispatcherEverRunning``, a one-way
    sticky flag set the first time this daemon observes the dispatcher
    RUNNING (never reset, so a later genuine STOPPED event, however long
    after the daemon itself started, still fires).
    """
    from maestro.patrol.registry import Finding

    current_state = dispatcher_status["state"]
    if current_state != "STOPPED":
        return None
    if not prior_state.get("dispatcherEverRunning"):
        return None

    pid = dispatcher_status.get("pid")
    if prior_state.get("lastDispatcherState") == "RUNNING":
        detail = (
            f"Dispatcher was RUNNING as of the previous LEAD tick and is now "
            f"{current_state} (pid={pid}). It will not make progress on pending "
            f"work until it is restarted."
        )
    else:
        detail = (
            f"Dispatcher remains {current_state} (pid={pid}) — still not making "
            f"progress on pending work."
        )
    return Finding(
        check_id="lead.dispatcher-watch",
        subject_id="dispatcher",
        severity="critical",
        title=f"Dispatcher is {current_state}",
        detail=detail,
        firstSeenAt=now.isoformat(),
        suggestedCommand=None,
        scope="workspace",
    )


# ---------------------------------------------------------------------------
# Severity-tiered delivery (PLAN-PLN-MSO-2026-0584 Dimension B).
#
#   critical   -> interrupt: a LEAD_FINDING lifecycle event AND Slack via
#                 BridgeNotifier (fingerprint-deduped, permanently, in the
#                 SAME notified.json the dispatcher's own approval/
#                 escalation notifications already use — BUG-MSO-2026-0426
#                 forbids a second notifier), when the bridge is configured.
#                 `dispatcher.heartbeat` is already `severity: critical` in
#                 patrol/default.json, so a genuine wedge lands here with no
#                 extra tuning.
#   high       -> loud where the operator already looks: a LEAD_FINDING
#                 lifecycle event only. No Slack.
#   medium/low -> passive: counts + drawer detail only (already true via
#                 `open_findings()` in run_once). Must never interrupt.
#
# Only NEW / ESCALATED findings are ever delivered (delta gating) —
# UNCHANGED findings already stay visible via counts/detail and nothing
# else. This is what turns dozens of identical ticks into a handful of
# meaningful ones, and what stops a recurring low finding from drowning a
# new critical.
# ---------------------------------------------------------------------------

_DELIVERY_TIER_CRITICAL = "critical"
_DELIVERY_TIER_HIGH = "high"


def _notify_critical_finding(artefact_root: Path, fingerprint: str, finding) -> bool:
    """Slack for one critical finding, reusing BridgeNotifier's own
    notified.json dedup (BUG-MSO-2026-0426: no second notifier). An
    unconfigured/disabled bridge, or any error building/sending the
    notification, is a silent no-op — never a reason for the tick to fail.
    """
    try:
        from maestro.core.bridge_notifier import BridgeNotifier
        notifier = BridgeNotifier(artefact_root)
        project = os.environ.get("MAESTRO_PROJECT", "")
        return notifier.notify_lead_finding(
            fingerprint=fingerprint,
            title=finding.title,
            detail=finding.detail,
            severity=finding.severity,
            project=project,
        )
    except Exception:  # noqa: BLE001 — delivery must never fail the tick
        return False


def _deliver_findings(artefact_root: Path, delta, patrol_state: dict, now: datetime) -> "tuple[dict, int]":
    """Deliver this tick's NEW/ESCALATED findings per the severity tiers
    above. Returns ``(counts, acknowledged_count)`` — *counts* keeps its
    original ``{"critical", "high", "notified"}`` shape (persisted verbatim
    as state.json's ``lastDelivery``, unchanged since FTR-MSO-2026-0589, so
    every existing assertion on that exact dict keeps passing) and
    *acknowledged_count* is reported separately as ``lastAckSuppressed`` —
    the same "distinguishable from broken" principle Dimension C applies to
    actions, applied here: a tick with findings present but nothing
    delivered because they were legitimately acknowledged must not look
    identical to a tick where delivery itself is broken.

    PLAN-PLN-MSO-2026-0584 Dimension D (count-preserving suppression): a
    finding that would otherwise be delivered this tick, but currently has a
    LIVE, unpierced acknowledgement (see ``maestro.patrol.state.is_acknowledged``
    — expiry and escalation-pierce are both checked there), is skipped here
    ONLY — it was already counted in ``open_findings``/``findings_by_severity``
    upstream in ``run_once``, untouched by this function.
    """
    from maestro.patrol.state import is_acknowledged

    counts = {"critical": 0, "high": 0, "notified": 0}
    acknowledged_count = 0
    for d in (*delta.new, *delta.escalated):
        f = d.finding
        if is_acknowledged(patrol_state, d.fingerprint, f.severity, now=now):
            acknowledged_count += 1
            continue
        if f.severity == _DELIVERY_TIER_CRITICAL:
            _write_lifecycle_event(artefact_root, "LEAD_FINDING", f"{f.title} — {f.detail}")
            counts["critical"] += 1
            if _notify_critical_finding(artefact_root, d.fingerprint, f):
                counts["notified"] += 1
        elif f.severity == _DELIVERY_TIER_HIGH:
            _write_lifecycle_event(artefact_root, "LEAD_FINDING", f"{f.title} — {f.detail}")
            counts["high"] += 1
    return counts, acknowledged_count


def run_once(
    artefact_root: Path,
    *,
    config: Optional[dict] = None,
    now: Optional[datetime] = None,
    workspace: Optional[Path] = None,
) -> TaskResult:
    """Run one LEAD wake cycle. Always returns — never loops, never blocks
    on anything beyond a single ``mso doctor`` pass.

    Definition of DONE for this task type: the patrol pass completed and its
    result was recorded. REPORTED_BACK covers a hit token ceiling (checked
    BEFORE any work runs, per Captain ruling D8 — the backstop aborts the
    tick rather than letting it run over budget) and a patrol pass that
    itself raised.

    *workspace* (FTR-MSO-2026-0585 / RC-2) is the product-repo root — passed
    straight through to ``run_patrol`` (so workspace-scoped checks stop
    self-skipping, matching ``mso doctor``'s own ``run_patrol(artefact_root,
    workspace=ws)`` call) and is the same root a later D7 action dispatch
    would hand to ``ActionContext``. ``None`` (a daemon started without
    ``--workspace`, or any other pre-existing caller) reproduces exactly
    today's behaviour — a caller that never had a workspace to give still
    doesn't need one.
    """
    now = now or datetime.now(timezone.utc)
    cfg = config or load_lead_config(artefact_root)
    prior_state = load_state(artefact_root)
    running_version = _running_version()

    # PLAN-PLN-MSO-2026-0584 Dimension A (RC-4): `lead.standDown` was loaded
    # and never consulted before this order. Checked at the TOP of the tick,
    # before the token-ceiling check or any patrol work — a stood-down tick
    # does nothing at all, not even a read. Transition-edge-triggered
    # (`was_standing_down` compares against the LAST tick's persisted state,
    # the same shape `_dispatcher_watch_finding` already uses below) so
    # `LEAD_STAND_DOWN` fires exactly once per stand-down, not every skipped
    # tick — the plan order's own acceptance criterion. The second
    # checkpoint ("between actions, never mid-git") lives in
    # `maestro.lead.bands.dispatch_actions_for_findings`, which re-reads
    # this same config before dispatching each D7 action group.
    stand_down = bool(cfg.get("standDown", False))
    was_standing_down = bool(prior_state.get("standDown"))

    if stand_down:
        if not was_standing_down:
            _write_lifecycle_event(
                artefact_root, "LEAD_STAND_DOWN",
                "LEAD stood down (lead.standDown=true in workspace.json) — "
                "ticks will be skipped until resumed.",
            )
        _save_state(artefact_root, {
            **prior_state,
            "standDown": True,
            "runningVersion": running_version,
            "lastTickAt": now.isoformat(),
            "lastOutcome": TaskOutcome.DONE.value,
            "lastReason": "stand_down",
        })
        return TaskResult(
            TaskOutcome.DONE,
            summary="Stood down — tick skipped.",
            reason="stand_down",
        )

    if was_standing_down:
        _write_lifecycle_event(
            artefact_root, "LEAD_RESUMED",
            "LEAD resumed (lead.standDown cleared in workspace.json) — ticks running again.",
        )

    ceiling = cfg["tokenCeiling"]["dailyTokens"]
    spent = _daily_tokens_spent_so_far(artefact_root, now)
    if spent >= ceiling:
        detail = (
            f"Daily token ceiling ({ceiling}) reached ({spent} spent) before "
            f"this tick ran. This is a backstop, not a routine stopping "
            f"point — reporting back instead of running."
        )
        _write_lifecycle_event(artefact_root, "LEAD_CEILING_HIT", detail)
        _save_state(artefact_root, {
            **prior_state,
            "standDown": False,
            "runningVersion": running_version,
            "lastTickAt": now.isoformat(),
            "lastOutcome": TaskOutcome.REPORTED_BACK.value,
            "lastReason": "token_ceiling",
        })
        return TaskResult(
            TaskOutcome.REPORTED_BACK,
            summary=f"Token ceiling reached ({spent}/{ceiling}) — reported back without running.",
            reason="token_ceiling",
            tokens_spent=spent,
            detail=detail,
        )

    try:
        from maestro.patrol import run_patrol
        # workspace is passed conditionally, not as workspace=workspace
        # unconditionally, so a caller with no workspace reproduces the
        # EXACT prior single-argument call — not merely the same runtime
        # behaviour (run_patrol's own workspace default is already None).
        if workspace is not None:
            result = run_patrol(artefact_root, workspace=workspace)
        else:
            result = run_patrol(artefact_root)
    except Exception as exc:
        detail = f"Patrol pass failed: {exc}"
        _write_lifecycle_event(artefact_root, "LEAD_REPORTED", detail)
        _save_state(artefact_root, {
            **prior_state,
            "standDown": False,
            "runningVersion": running_version,
            "lastTickAt": now.isoformat(),
            "lastOutcome": TaskOutcome.REPORTED_BACK.value,
            "lastReason": "error",
        })
        return TaskResult(
            TaskOutcome.REPORTED_BACK,
            summary="Patrol pass failed — reported back.",
            reason="error",
            detail=detail,
        )

    # FTR-MSO-2026-0585 (RC-2) / PLAN-PLN-MSO-2026-0584 Dimension B: the
    # dispatcher's live status is read ONCE, up front, so both the
    # dispatcher-watch finding built below AND the tick's persisted
    # `lastDispatcherState` come from the exact same read.
    from maestro.core.fleet_monitor import get_dispatcher_status
    dispatcher_status = get_dispatcher_status(artefact_root)
    current_dispatcher_state = dispatcher_status["state"]

    # PLAN-PLN-MSO-2026-0584 Dimension B — fixing the edge-triggered
    # silence: the dispatcher-watch finding is built BEFORE compute_delta
    # and folded into the SAME findings list run_patrol produced, so it
    # gets a stable fingerprint and participates in delta / escalation /
    # delivery exactly like every other patrol finding. A persistently
    # STOPPED dispatcher therefore stays visible (UNCHANGED) in every
    # tick's open findings instead of being reported once and then
    # forgotten — see `_dispatcher_watch_finding`'s docstring for why this
    # is scoped to STOPPED only (WEDGED is already the shared
    # `dispatcher.heartbeat` check's job, and that finding already flows
    # through this same delta with no help needed here).
    watch_finding = _dispatcher_watch_finding(dispatcher_status, prior_state, now)
    all_findings = list(result.findings)
    if watch_finding is not None:
        all_findings.append(watch_finding)

    # dispatcher_note: the human-readable "I watched this happen" sentence
    # for the tick summary, populated ONLY on the exact tick of a
    # RUNNING -> STOPPED transition (unchanged behaviour from before this
    # order). This is NOT a second write path — watch_finding carries this
    # same text as its `detail`, so the transition still produces exactly
    # one LEAD_FINDING event, written by `_deliver_findings` below via the
    # generic critical-severity tier, never a separate call here.
    dispatcher_note = (
        watch_finding.detail
        if watch_finding is not None and prior_state.get("lastDispatcherState") == "RUNNING"
        else None
    )

    # FTR-MSO-2026-0586 (RC-3 / Dimension D): compare this tick's findings
    # against the persisted patrol state instead of reporting the raw list
    # every tick — the same sequence `mso doctor` already uses
    # (maestro/cli.py:452-470's `run_patrol` -> `compute_delta` ->
    # `save_state`), reused verbatim rather than re-derived. This is what
    # turned 94 identical ticks into a delta that actually goes quiet when
    # nothing changed, and what makes `firstSeenAt` the TRUE first-seen
    # timestamp instead of "this tick" on every single read.
    #
    # State-file ownership (PLAN-PLN-MSO-2026-0584 Dimension D): `mso doctor`
    # and this daemon deliberately SHARE `state/patrol-state.json` — both
    # resolve it via the same `default_state_path(artefact_root)` against the
    # same artefact root, so a finding's first-seen timestamp does not depend
    # on which surface happened to observe it first. See this order's handoff
    # for the full reasoning already recorded in the plan.
    from maestro.patrol.state import compute_delta, default_state_path
    from maestro.patrol.state import load_state as _load_patrol_state
    from maestro.patrol.state import save_state as _save_patrol_state

    patrol_state_path = default_state_path(artefact_root)
    previous_patrol_state = _load_patrol_state(patrol_state_path)
    delta, new_patrol_state = compute_delta(previous_patrol_state, all_findings, now=now)
    _save_patrol_state(patrol_state_path, new_patrol_state)

    # Every currently-open finding (new + escalated + unchanged), severity
    # already reflecting age escalation and firstSeenAt already the TRUE
    # first-seen timestamp — this is what feeds the counts and the drawer.
    # UNCHANGED findings stay in this list (PLAN Dimension D guard: delta
    # gating is a DELIVERY concept, never a counting/visibility one), so the
    # strip and drawer are never quieter than the raw patrol pass. This is
    # also what makes "continues to be reported after the first tick" true
    # for a persistently-dead dispatcher: watch_finding keeps re-entering
    # `all_findings` every tick the condition holds, so it stays counted
    # here (as UNCHANGED) long after its one-time NEW delivery below.
    open_findings = delta.open_findings()

    # PLAN-PLN-MSO-2026-0584 Dimension C (RC-1): map NEW/ESCALATED findings to
    # the D7 act-and-inform actions via the explicit check_id -> action_id
    # table and execute each mapped action AT MOST ONCE this tick. This is
    # the join FTR-MSO-2026-0536/0537 shipped the two ends of but never
    # connected — execute_action() (bands.py) is the ONLY call site that ever
    # runs an action body, so the must_not ceiling is exercised exactly as
    # any other caller hits it, never bypassed by this new path.
    from maestro.lead.bands import dispatch_actions_for_findings

    action_summary = dispatch_actions_for_findings(
        list(delta.new) + list(delta.escalated),
        artefact_root=artefact_root,
        workspace=workspace,
    )

    summary = (
        f"Patrol tick complete — {result.checks_run} check(s), {len(open_findings)} finding(s) "
        f"({len(delta.new)} new, {len(delta.resolved)} resolved, {len(delta.escalated)} escalated, "
        f"{len(delta.unchanged)} unchanged)."
    )
    if action_summary.considered:
        summary += (
            f" Actions: considered={action_summary.considered} eligible={action_summary.eligible} "
            f"executed={action_summary.executed} refused={action_summary.refused} "
            # BUG-MSO-2026-0636 (F5): precondition_refused was tracked in
            # ActionTickSummary (BUG-MSO-2026-0633) but never actually
            # printed anywhere — a refusal-only tick logged
            # "executed=0 refused=0 errors=0", indistinguishable from the
            # action path being broken (exactly the signature
            # FTR-MSO-2026-0587 introduced these counters to tell apart).
            f"precondition_refused={action_summary.precondition_refused} "
            f"errors={action_summary.errors}."
        )
    if dispatcher_note:
        summary += " " + dispatcher_note
    _write_lifecycle_event(artefact_root, "LEAD_TICK", summary)

    # PLAN-PLN-MSO-2026-0584 Dimension B: severity-tiered delivery — critical
    # findings get a LEAD_FINDING event plus one-per-fingerprint Slack (when
    # the bridge is configured); high gets the lifecycle event only; medium
    # and low stay passive (counts/detail above, never delivered). Only NEW
    # and ESCALATED findings are ever delivered — see _deliver_findings.
    # PLAN-PLN-MSO-2026-0584 Dimension D: a NEW/ESCALATED finding with a
    # LIVE, unpierced acknowledgement is excluded from delivery here ONLY —
    # it was already counted above in findings_by_severity/open_findings,
    # untouched by acknowledgement (count-preserving suppression).
    delivered, ack_suppressed = _deliver_findings(artefact_root, delta, new_patrol_state, now)

    # PLAN-PLN-MSO-2026-0504 §13 / FTR-MSO-2026-0539: persisted alongside
    # lastFindingsCount so the Hub's LEAD status endpoint can read a
    # severity breakdown without running its own patrol pass on every HTTP
    # poll — the daemon's own heartbeat (this tick) is the single place
    # `mso doctor` actually runs, exactly as §6's noise-control design
    # intends. Unrecognised severities never occur (patrol.registry.Finding
    # is always built from SEVERITIES), so no "other" bucket is needed.
    # Severities here are the DELTA's (age-escalated) severities, not the
    # checks' raw base severities — a `low` finding open 24h+ is counted and
    # displayed as `medium`, matching what `mso doctor` itself would show.
    findings_by_severity = {"critical": 0, "high": 0, "medium": 0, "low": 0}
    for f in open_findings:
        if f.severity in findings_by_severity:
            findings_by_severity[f.severity] += 1

    # FTR-MSO-2026-0577: the bounded finding DETAIL behind the counts above —
    # persisted from this SAME tick's open findings, never recomputed by a
    # later reader. The Hub's lead/detail endpoint reads this instead of
    # running its own patrol pass, so the drawer can never show a finding
    # count that disagrees with the strip's lastFindingsBySeverity. Each
    # entry's `firstSeenAt` is now the delta's true first-seen timestamp
    # (FTR-MSO-2026-0586) — carried forward from the tick a finding first
    # appeared, not stamped "now" on every tick.
    findings_detail, findings_total, findings_truncated = _findings_detail_payload(open_findings)
    # PLAN-PLN-MSO-2026-0584 Dimension D: attach each entry's stable
    # fingerprint (needed by the CLI/Hub ack surfaces to name WHICH finding
    # they're acknowledging) and current acknowledgement metadata, if any —
    # both the Hub drawer and `mso lead status` read this straight from
    # state.json, never a fresh patrol pass.
    findings_detail = _apply_acknowledgement_detail(
        findings_detail, delta.open_delta_findings(), new_patrol_state, now,
    )

    # PLAN-PLN-MSO-2026-0584 Dimension C3: `lastActionAt` is updated only
    # when an action was actually EXECUTED or ERRORED this tick (the two
    # outcomes execute_action() itself logs as LEAD_ACTION) — a tick with
    # nothing to act on leaves it untouched via `**prior_state`, so it reads
    # as the true last-fired timestamp across ticks, never reset to "now" on
    # every quiet tick.
    state_update = {
        **prior_state,
        "standDown": False,
        "runningVersion": running_version,
        "lastTickAt": now.isoformat(),
        "lastOutcome": TaskOutcome.DONE.value,
        "lastReason": None,
        "lastDispatcherState": current_dispatcher_state,
        # One-way sticky flag (PLAN-PLN-MSO-2026-0584 Dimension B): once the
        # daemon has observed the dispatcher RUNNING, this stays True even
        # across a later genuine STOPPED reading, so `_dispatcher_watch_finding`
        # keeps reporting a persistently-dead dispatcher instead of the old
        # edge-only detector's silence after tick one. Never reset to False —
        # a dispatcher that was ever seen running is always alarming once it
        # stops, no matter how long ago that was.
        "dispatcherEverRunning": bool(prior_state.get("dispatcherEverRunning")) or current_dispatcher_state == "RUNNING",
        "lastFindingsCount": len(open_findings),
        "lastFindingsBySeverity": findings_by_severity,
        "lastFindingsDetail": findings_detail,
        "lastFindingsTotal": findings_total,
        "lastFindingsTruncated": findings_truncated,
        # FTR-MSO-2026-0586: bounded delta counts (never the full finding
        # lists — those already live in patrol-state.json) so a caller can
        # tell "nothing changed" (all zero) from "the fleet is on fire" (a
        # large `new`/`escalated` count) without re-running the patrol.
        "lastDelta": {
            "new": len(delta.new),
            "resolved": len(delta.resolved),
            "escalated": len(delta.escalated),
            "unchanged": len(delta.unchanged),
        },
        # PLAN-PLN-MSO-2026-0584 Dimension B: what was actually delivered
        # this tick (critical/high LEAD_FINDING counts, and how many of the
        # critical ones reached Slack) — distinguishes "nothing needed
        # delivering" (all zero) from "delivery is broken" (findings
        # present, nothing sent), the same principle Dimension C applies to
        # actions.
        "lastDelivery": delivered,
        # PLAN-PLN-MSO-2026-0584 Dimension D: how many NEW/ESCALATED findings
        # this tick were withheld from delivery by a live acknowledgement —
        # kept SEPARATE from `lastDelivery` (whose shape is unchanged since
        # FTR-MSO-2026-0589) so "nothing needed delivering" (all-zero
        # lastDelivery, ackSuppressed=0) reads differently from "findings
        # were present but suppressed by ack" (ackSuppressed>0) rather than
        # looking identical to a broken delivery path.
        "lastAckSuppressed": ack_suppressed,
        # PLAN-PLN-MSO-2026-0584 Dimension C3: distinguishes "nothing needed
        # doing" (considered=0) from "the action path is broken"
        # (eligible>0, executed=0) — see bands.ActionTickSummary's docstring.
        "actions": {
            "considered": action_summary.considered,
            "eligible": action_summary.eligible,
            "executed": action_summary.executed,
            "refused": action_summary.refused,
            # BUG-MSO-2026-0636 (F5): persisted alongside the other counters
            # so `mso lead status` / the Hub strip can show it — previously
            # computed but dropped on the floor here, matching the same gap
            # in the LEAD_TICK summary string above.
            "precondition_refused": action_summary.precondition_refused,
            "errors": action_summary.errors,
        },
    }
    # BUG-MSO-2026-0636 (F4): `action_summary.acted` also covers a "refused"
    # tick that still did partial destructive work (e.g. worktree.prune
    # removing some worktrees before hitting an occupied one) — `executed`
    # alone missed that case, so `mso lead status` showed "(never)" for a
    # tick that demonstrably changed the filesystem.
    if action_summary.acted or action_summary.errors:
        state_update["lastActionAt"] = now.isoformat()

    _save_state(artefact_root, state_update)

    return TaskResult(
        TaskOutcome.DONE,
        summary=summary,
        findings_count=len(open_findings),
        detail=dispatcher_note or "",
    )
