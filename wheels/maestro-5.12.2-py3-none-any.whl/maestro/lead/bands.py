# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""maestro/lead/bands.py — the three-band proactivity envelope.

PLAN-PLN-MSO-2026-0504 §3.4, Captain ruling D7 (2026-08-25). The Captain
wants the LEAD "more proactive"; §8's rule that a patrol *check* may never
remediate is unchanged (``maestro.patrol.registry`` hands a check no
writer). What is new is that the LEAD — a separate actor reading findings —
may perform a named, reversible action and report it. Three bands:

  * ``OBSERVE``           — detect and report only. The default for
                             everything not explicitly named otherwise, and
                             (as of the narrowing below) ``worktree.prune``.
  * ``ACT_AND_INFORM``    — safe, reversible, idempotent housekeeping,
                             performed then reported. Captain ruling D7
                             (2026-08-25) fixed the default membership at
                             EXACTLY three: ``voyage.reconcile``,
                             ``worktree.prune``, ``artefact.sweep``. PR
                             draft->ready promotion (``pr.promote-draft``)
                             is deliberately excluded from the default — it
                             starts CI, which spends money — and stays
                             ``OBSERVE`` unless an org opts it in explicitly.
  * ``PROPOSE_AND_WAIT``  — anything in ``maestro/roles/LEAD.md``'s
                             ``must_not``: merging, approving, scope
                             changes, resolving security findings. This is
                             the CEILING, not a default an org configures
                             into — see :func:`apply_must_not_ceiling`.

CAPTAIN RULING 2026-09-06 (BUG-MSO-2026-0644): ``worktree.prune`` is REMOVED
from the D7 default act-and-inform membership and moved to ``OBSERVE``. This
NARROWS D7's default set from three members to two (``voyage.reconcile``,
``artefact.sweep``) — a deliberate exception to D1's "may tighten, never
loosen" framing, made by the Captain directly rather than through the
tiered-override mechanism, and recorded here (and in the top-level project
CLAUDE.md's ``LEAD_ACTION`` lifecycle-event row) precisely so it is not
silently widened back by a later change that only reads the D7 prose above
without reading this paragraph. Two independent reasons, either sufficient
alone:

1. Four remediation rounds (BUG-MSO-2026-0633/0636/0640/0644) still did not
   converge on a correct re-validation guard for ``prune_stale_worktrees_ex``
   — each round closed one hole and opened or exposed another. A design that
   needs a fifth attempt to be provably safe should not be running
   unattended in the meantime.
2. BUG-MSO-2026-0644's finding F4 showed the shipped guard was not merely
   imperfect but PERMANENTLY INERT: ``_foreign_live_dispatcher_reason()`` (a
   workspace-wide "is any dispatcher alive" check) was OR'd into every CREW
   worktree's occupancy check, so ``worktree.prune`` refused literally every
   candidate whenever any dispatcher was running — the fleet's ordinary
   healthy state. The action delivered zero value while still carrying the
   exact risk that started this bug family (BUG-MSO-2026-0633: the LEAD
   destroyed two worktrees nine seconds after a heartbeat reporting
   ``crews_busy=3``).

Observe-only removes that risk BY CONSTRUCTION — the LEAD still detects and
reports an orphaned worktree via the ``hygiene.stale-worktrees`` patrol
check, and ``execute_action`` still resolves and surfaces ``worktree.prune``
as a proposal, but the action body (``_worktree_prune`` below) never runs
unattended. An operator runs the identical code path by hand via
``mso worktree prune`` (BUG-MSO-2026-0680 — the finding's own
``suggestedCommand``) once the guard's own re-validation is trusted.
Before BUG-MSO-2026-0680, no such command existed anywhere in the CLI or
the Hub: the narrowing above removed the LEAD's unattended capability while
this docstring, ``CLAUDE.md``, ``LEAD.md`` and the ``hygiene.stale-worktrees``
finding's own detail text all kept asserting an operator escape hatch that
was not actually reachable. ``voyage.reconcile`` and ``artefact.sweep`` are
UNAFFECTED — neither deletes anything, and the Captain's ruling deliberately
did not touch them.

F4 (and the guard's other holes) are fixed by BUG-MSO-2026-0651, split off
this order so the band narrowing above could land on its own — see
``maestro/core/worktrees.py``'s ``_worktree_busy_reason``. The fix does not
change the band decision above: an operator-invoked ``mso worktree prune``
(or a future re-promotion to ``ACT_AND_INFORM`` once the guard has proven
itself) executes the identical code path, so the guard still has to be
correct on its own merits, independent of which band gates it.

BUG-MSO-2026-0692 (F1): that "identical code path" claim was FALSE AS
WRITTEN for the one thing it most needed to be true about. ``mso worktree
prune`` resolved the product repo the git ops run in via
``solo_worktree_repo_root() or ws`` (BUG-MSO-2026-0689 F2); ``_worktree_prune``
below passed ``ctx.workspace`` bare, which is the ARTEFACT repo in
solo/shared mode and ``None``-able besides, so the LEAD's prune ran git
against a repo with no record of the worktree — or at the daemon's ambient
cwd. Both now call the SAME
:func:`maestro.core.worktrees.resolve_worktree_prune_root`, so the claim
holds by construction rather than by assertion. Any future change to how
that repo is resolved must be made in that one function; do not reintroduce
a second copy here.

Band membership is DATA, resolved through the identical four-tier mechanism
patrol checks already use (PLAN §5: bundle > pack > workspace.json >
default — ``maestro.patrol.resolver``), because §3.4 point 1 says so
explicitly: "The band is a property of the action, configured per
organisation through the same four-tier resolution as the patrol
definition". D1's monotonic-tightening rule (§5.4) applies here too (§3.4
point 2): a lower tier may TIGHTEN a governed band (move toward
``PROPOSE_AND_WAIT``) but never LOOSEN it (move toward ``ACT_AND_INFORM``)
without a breakglass grant — "An org that governs `voyage.reconcile:
observe` cannot have a division promote it."

The ``must_not`` ceiling (§3.4 point 3 / §8) is DIFFERENT from D1's
governed-tightening refusal: it is not breakglass-eligible, and it is
applied unconditionally AFTER every tier has resolved — no tier, including
a signed policy bundle, may configure a ``must_not``-mapped action as
anything looser than ``PROPOSE_AND_WAIT``. See
:func:`apply_must_not_ceiling`.

This module intentionally reuses, rather than duplicates, three existing
mechanisms: ``maestro.governance.breakglass`` (D1's escape hatch — §5.4
point 3: "Patrol should reuse [breakglass] verbatim rather than inventing a
second escape hatch"), ``maestro.roles.loader.load_effective_role`` with
``resident=True`` (the D6-protected, extend-only resolution of LEAD's
``must_not`` section — FTR-MSO-2026-0543), and
``maestro.lead.agent._write_lifecycle_event`` (the same lifecycle-log
writer the daemon's own tick already uses, so ``LEAD_ACTION`` lines land in
the identical format as ``LEAD_TICK``/``LEAD_CEILING_HIT``/``LEAD_FINDING``).
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Optional

from maestro.lead.agent import _write_lifecycle_event, load_lead_config

__all__ = [
    "Band",
    "band_rank",
    "ActionContext",
    "ActionSpec",
    "ActionExecutionResult",
    "ActionPreconditionRefused",
    "ResolvedAction",
    "ActionResolution",
    "action",
    "get_action",
    "all_actions",
    "clear_registry",
    "resolve_action_bands",
    "is_forbidden_by_must_not",
    "apply_must_not_ceiling",
    "apply_config_opt_in",
    "execute_action",
    "FINDING_ACTION_MAP",
    "ActionTickSummary",
    "dispatch_actions_for_findings",
]


class ActionPreconditionRefused(Exception):
    """Raised by an ACT_AND_INFORM action's own ``func`` when a precondition
    that held when its triggering finding was computed no longer holds at
    execution time (BUG-MSO-2026-0633 — the LEAD's ``worktree.prune``
    destroyed a live crew's worktree because the D7 band re-validates
    NOTHING at execution time by default, only at finding time).

    ``execute_action`` catches this SEPARATELY from a generic exception: the
    outcome is ``"refused"`` (a correct, deliberate safety decision), never
    ``"error"`` (which reads as something having gone wrong). Per §3.4's
    "act never means quietly", a refusal is logged as loudly as an
    execution — the message passed here becomes the ``LEAD_ACTION`` detail
    and MUST name what changed since the finding was computed, not just that
    something did.

    ``acted`` (BUG-MSO-2026-0636 F4): a refusal can still follow REAL
    destructive work — ``worktree.prune`` removes every unoccupied candidate
    before it ever gets to one it must refuse, so a "partial" tick both
    mutated the workspace AND refused. Set ``acted=True`` in that case so
    ``execute_action`` can mark the result as having done something, even
    though ``outcome`` correctly stays ``"refused"`` — without this,
    ``agent.run_once``'s ``lastActionAt`` bookkeeping (gated on
    executed/errors) never learns that worktrees were actually destroyed,
    and ``mso lead status`` reports "(never)" for a tick that demonstrably
    changed the filesystem.
    """

    def __init__(self, message: str, *, acted: bool = False):
        super().__init__(message)
        self.acted = acted


# ---------------------------------------------------------------------------
# Band enum + monotonic-tightening rank
# ---------------------------------------------------------------------------

class Band(str, Enum):
    OBSERVE = "observe"
    ACT_AND_INFORM = "act_and_inform"
    PROPOSE_AND_WAIT = "propose_and_wait"


# Rank purely for MONOTONIC-TIGHTENING comparisons (D1 applied to actions,
# §3.4 point 2) — NOT a claim that PROPOSE_AND_WAIT is universally "worse"
# than OBSERVE on every axis. Lower rank = the LEAD may do LESS without
# asking = tighter. "Loosening" means moving to a HIGHER rank.
_BAND_RANK = {Band.PROPOSE_AND_WAIT: 0, Band.OBSERVE: 1, Band.ACT_AND_INFORM: 2}


def band_rank(band: "str | Band") -> int:
    return _BAND_RANK[Band(band)]


def _is_looser_band(candidate: "str | Band", floor: "str | Band") -> bool:
    """True when *candidate* relaxes *floor* — a higher rank than the floor."""
    return band_rank(candidate) > band_rank(floor)


# ---------------------------------------------------------------------------
# Action registry — the code side. Mirrors maestro.patrol.registry's shape
# (a decorator-populated dict keyed by id) deliberately: a check is
# ``(context) -> list[Finding]`` with no writer; an action is
# ``(context) -> str`` (a short human summary) WITH a writer, because
# executing the real remediation is exactly what an action is for. The two
# registries are kept structurally distinct so "a check may never remediate"
# (§8) stays enforceable by construction rather than by convention — nothing
# in maestro.patrol.checks ever imports this module.
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class ActionContext:
    """Read-write inputs handed to an action's ``func``. ``subject`` carries
    whatever the action-specific remediation needs beyond the workspace
    (e.g. ``pr.promote-draft`` needs the voyage dict ``promote_voyage_pr_ready``
    already expects) — deliberately loose-typed rather than widening every
    action's signature for one action's needs."""

    artefact_root: Path
    workspace: Optional[Path] = None
    subject: Any = None


ActionFunc = Callable[[ActionContext], str]


@dataclass(frozen=True)
class ActionSpec:
    id: str
    func: ActionFunc
    default_band: Band
    must_not_keyword: Optional[str] = None
    description: str = ""


_REGISTRY: "dict[str, ActionSpec]" = {}


def action(
    id: str,
    default_band: "str | Band",
    must_not_keyword: Optional[str] = None,
    description: str = "",
) -> Callable[[ActionFunc], ActionFunc]:
    """Decorator registering an action function under *id*.

    *default_band* is the CODE-level fallback used when neither
    ``maestro/patrol/default.json`` nor any higher tier mentions this action
    id at all (see :func:`resolve_action_bands`) — for the four actions
    listed in ``default.json``'s ``actions`` array it is informational only
    (the data file is the real tier-4 source); for ``pr.merge`` (deliberately
    never listed in ``default.json`` — see its registration below) it is the
    ONLY seed.

    *description* is mandatory and non-empty — Captain ruling D8: "every
    LEAD task carries an explicit definition of done... a task registered
    without a completion condition is a defect, not a long-running task."
    For an action, the completion condition IS structural (``func`` is a
    single synchronous call that returns a summary or raises — there is no
    way to register one that runs indefinitely), but the WHAT/WHY still has
    to be stated in the open, not left to the reader to infer from the
    function body — this decorator refuses to register an action that
    skips that statement, rather than merely documenting the convention.
    """
    if not description or not description.strip():
        raise ValueError(
            f"LEAD action {id!r} must declare a non-empty description — "
            "an action with no stated definition of done is refused at "
            "registration, not merely discouraged by convention (D8)."
        )

    def _decorate(func: ActionFunc) -> ActionFunc:
        if id in _REGISTRY:
            raise ValueError(f"duplicate LEAD action id: {id!r}")
        _REGISTRY[id] = ActionSpec(
            id=id,
            func=func,
            default_band=Band(default_band),
            must_not_keyword=must_not_keyword,
            description=description,
        )
        return func

    return _decorate


def all_actions() -> "list[ActionSpec]":
    return sorted(_REGISTRY.values(), key=lambda spec: spec.id)


def get_action(action_id: str) -> Optional[ActionSpec]:
    return _REGISTRY.get(action_id)


def clear_registry() -> None:
    """Test-only: reset registration state between isolated test modules."""
    _REGISTRY.clear()


# ---------------------------------------------------------------------------
# The four D7 catalogue entries.
# ---------------------------------------------------------------------------

@action(
    "voyage.reconcile",
    default_band=Band.ACT_AND_INFORM,
    description=(
        "mso voyage reconcile — archive merged voyages + annotate completed "
        "voyage PR merges. Idempotent, reversible, pull-based by design "
        "(FTR-MSO-2026-0426) — Captain ruling D7's first default member."
    ),
)
def _voyage_reconcile(ctx: ActionContext) -> str:
    from maestro.core.fleet_runner import run_housekeeping_sweep
    from maestro.core.order_retry import workspace_scope

    # BUG-MSO-2026-0633 audit: NOT vulnerable to the same act-on-stale-
    # finding defect as worktree.prune. run_housekeeping_sweep() takes no
    # finding-derived data at all (this func passes it nothing but the
    # workspace root) — it re-scans voyages/active/ and re-queries live PR
    # merge state (FTR-MSO-2026-0426: "PR state is AUTHORITATIVE... looked
    # up BY NUMBER, reading `merged`") FRESH on every call. Its own decision
    # of what to archive is therefore always current-as-of-this-instant,
    # never a replay of a precondition computed at finding time. It is also
    # non-destructive on a stale positive: archiving a voyage is a durable
    # git-tracked JSON move (active/ -> complete/), trivially reversible by
    # `mso order retry`, unlike worktree removal which destroys uncommitted
    # working-tree content outright. No change made here.
    #
    # FTR-MSO-2026-0585 (RC-2): root-pinned to ctx.artefact_root via the same
    # workspace_scope() primitive run_housekeeping_sweep()'s own
    # artefact_root= parameter uses internally — never the ambient
    # resolution a detached daemon's arbitrary cwd would otherwise fall back
    # to (the multi-workspace hazard this order closes).
    with workspace_scope(ctx.artefact_root):
        report = run_housekeeping_sweep(dry_run=False)
    return (
        f"reconcile: {report['archived']} voyage(s) archived, "
        f"{report['annotated']} PR-merge annotation(s) applied"
    )


@action(
    "worktree.prune",
    default_band=Band.OBSERVE,
    description=(
        "Remove worktrees whose voyage has completed, plus a git worktree "
        "prune of broken refs. NOT idempotent-and-safe against an OCCUPIED "
        "worktree, which is exactly why prune_stale_worktrees_ex "
        "re-validates 'voyage archived' and 'worktree unoccupied' at "
        "execution time and refuses (BUG-MSO-2026-0633) rather than acting "
        "on what a finding believed minutes or days earlier. Formerly "
        "Captain ruling D7's second default act-and-inform member; MOVED TO "
        "OBSERVE by Captain ruling 2026-09-06 (BUG-MSO-2026-0644) after four "
        "remediation rounds still had not converged on a correct guard, and "
        "the guard as shipped before this order (BUG-MSO-2026-0640's F4) "
        "made the action permanently inert whenever any dispatcher was "
        "running — see this module's docstring for the full reasoning. The "
        "LEAD still detects and proposes this action; a human executes it."
    ),
)
def _worktree_prune(ctx: ActionContext) -> str:
    from maestro.core.worktrees import (
        WorktreeRepoRootUnresolved,
        prune_stale_worktrees_ex,
        resolve_worktree_prune_root,
    )

    # BUG-MSO-2026-0692 (F1): this used to pass `repo_root=ctx.workspace`
    # bare. In solo/shared artefact-repo mode `ctx.workspace` is the ARTEFACT
    # repo, so every `git worktree remove`/`git worktree prune` below ran
    # against a repo holding no record of the worktree at all — byte-for-byte
    # the defect BUG-MSO-2026-0689 (F2) fixed in `cli.py::cmd_worktree` and
    # which `run_dispatcher` already avoided, left un-fixed on this path even
    # though this module's own docstring asserts both "execute the identical
    # code path". Worse, `ctx.workspace` is Optional: a `None` sent git to
    # the DAEMON's ambient cwd — unbounded, and the LEAD daemon is a detached
    # long-lived process whose cwd is nobody's deliberate choice.
    #
    # `resolve_worktree_prune_root` is now the single resolution point BOTH
    # callers use (see its docstring), so the "identical code path" claim is
    # true by construction rather than by assertion — the correction seven
    # consecutive PR #406 rounds of this same class have needed. It NEVER
    # returns an ambient-cwd answer: it resolves explicitly through
    # solo_worktree_repo_root() → ctx.workspace → the `.mso` artefact root's
    # parent, and raises when none of those name a repo.
    try:
        prune_root = resolve_worktree_prune_root(
            workspace=ctx.workspace, artefact_root=ctx.artefact_root,
        )
    except WorktreeRepoRootUnresolved as exc:
        # A refusal, not an error — nothing went wrong; the action declined
        # to act because it could not name the repo to act in. Same class as the
        # BUG-MSO-2026-0633 occupancy refusals, and `acted=False` because
        # this fires before anything is touched.
        raise ActionPreconditionRefused(
            f"cannot resolve the product repo to prune worktrees in: {exc}",
            acted=False,
        ) from exc

    result = prune_stale_worktrees_ex(repo_root=prune_root)
    if result.refused:
        detail = "; ".join(result.refused)
        if result.removed:
            detail += f" ({result.removed} other worktree(s) still pruned)"
        # BUG-MSO-2026-0636 (F4): a partial tick — some worktrees genuinely
        # removed before this refusal — must be distinguishable, upstream,
        # from a pure refusal that changed nothing. `acted=bool(result.removed)`
        # is that signal; see ActionPreconditionRefused's docstring.
        raise ActionPreconditionRefused(
            f"{len(result.refused)} worktree(s) refused — occupied or no "
            f"longer archived: {detail}",
            acted=bool(result.removed),
        )
    return f"worktree prune: {result.removed} worktree(s) removed"


@action(
    "artefact.sweep",
    default_band=Band.ACT_AND_INFORM,
    description=(
        "Push pending artefact-plane lifecycle commits to origin (solo/"
        "shared artefact-repo mode — a no-op, never an error, in embedded "
        "mode where bookkeeping already rides the product repo's normal PR "
        "flow). Captain ruling D7's third default member; LEAD.md must_do "
        "#6 already names this an obligation."
    ),
)
def _artefact_sweep(ctx: ActionContext) -> str:
    from maestro.core.fleet_runner import flush_artefact_push
    from maestro.core.order_retry import workspace_scope

    # BUG-MSO-2026-0633 audit: NOT vulnerable. Like _voyage_reconcile above,
    # this func carries no finding-derived data — flush_artefact_push()
    # re-checks its OWN live state (the `_ARTEFACT_PUSH_STATE["pending"]`
    # flag, the artefact repo's actual current branch, whether `origin` is
    # even configured) at call time, not anything decided when a finding
    # was computed. A stale-precondition replay is harmless by construction:
    # nothing pending -> no-op; something pending -> pushes exactly the
    # commits that exist right now. `git push` is additive/idempotent — it
    # cannot destroy live work the way removing a worktree can, and a
    # genuine divergence (another writer) is refused by git itself and
    # surfaces as PLANE_DIVERGED, not silently forced through. No change
    # made here.
    #
    # FTR-MSO-2026-0585 (RC-2): root-pinned to ctx.artefact_root — see
    # _voyage_reconcile above.
    with workspace_scope(ctx.artefact_root):
        pushed = flush_artefact_push(force=True)
    return f"artefact sweep: {'pushed' if pushed else 'nothing pending / embedded mode'}"


@action(
    "pr.promote-draft",
    default_band=Band.OBSERVE,
    description=(
        "Promote a voyage's draft PR to ready-for-review. Deliberately "
        "EXCLUDED from the D7 default — it starts CI, which spends money — "
        "and stays OBSERVE unless an org opts it in explicitly via the same "
        "four-tier resolution."
    ),
)
def _pr_promote_draft(ctx: ActionContext) -> str:
    from maestro.core.fleet_runner import promote_voyage_pr_ready

    if not isinstance(ctx.subject, dict):
        raise ValueError("pr.promote-draft requires a voyage dict as ActionContext.subject")
    promoted = promote_voyage_pr_ready(ctx.subject)
    return f"PR draft->ready: {'promoted' if promoted else 'no-op (disabled, or nothing to promote)'}"


@action(
    "hub.restart",
    default_band=Band.OBSERVE,
    description=(
        "mso hub start — bring the global Maestro Hub daemon back up after "
        "the `hub.alive` check found it dead or wedged (BUG-MSO-2026-0712). "
        "OBSERVE by default and DELIBERATELY NOT a member of Captain ruling "
        "D7's default act-and-inform band: adding it there is a Captain "
        "decision, not a code one. The per-workspace opt-in is "
        "`lead.hubAutoRestart` in workspace.json (see "
        ":func:`apply_config_opt_in`), which promotes it for that workspace "
        "only and only when no tier has pinned a band of its own."
    ),
)
def _hub_restart(ctx: ActionContext) -> str:
    from maestro import auth
    from maestro.hub import daemon as hub_daemon

    # `mso hub start` is Team/Enterprise-gated (cmd_hub -> require_tier), and
    # an unattended action must answer to the same gate. Checked with
    # `has_tier`, NOT `require_tier`: the latter calls sys.exit(1), whose
    # SystemExit is a BaseException that `execute_action`'s `except Exception`
    # would not catch — a licence tier must never be able to kill a LEAD tick.
    if not auth.has_tier(auth.HUB_TIERS):
        raise ActionPreconditionRefused(
            "Maestro Hub requires a Team or Enterprise licence — not restarting "
            "a feature this workspace's tier does not include."
        )

    pid_file = hub_daemon._hub_pid_file()
    running, pid = hub_daemon._is_hub_running(pid_file)
    port = hub_daemon.recorded_port()

    if running and hub_daemon.port_answers(port):
        # BUG-MSO-2026-0633's lesson applied to this action: re-validate at
        # EXECUTION time, never trust the finding. The Hub is global, so a
        # second workspace's LEAD daemon (or an operator) may already have
        # restarted it between the finding and this call.
        raise ActionPreconditionRefused(
            f"Hub is already serving on port {port} (PID {pid}) — it was restarted "
            "between the finding and this action; nothing to do."
        )

    if running:
        # Alive but not answering: start_hub() would short-circuit on
        # "already running", so the wedged process must go first. This is the
        # one destructive step, and it targets a PID whose identity has just
        # been re-verified against the record (never a bare PID number).
        if not hub_daemon.stop_hub():
            raise ActionPreconditionRefused(
                f"Hub PID {pid} is wedged on port {port} and could not be stopped "
                "(graceful signal and force-kill both failed) — not restarting over "
                "a process that still holds the port."
            )
        hub_daemon.start_hub(port=port)
        return f"Hub was wedged on port {port} (PID {pid}) — stopped and restarted."

    hub_daemon.start_hub(port=port)
    return f"Hub was dead (recorded PID {pid}) — restarted on port {port}."


@action(
    "pr.merge",
    default_band=Band.ACT_AND_INFORM,
    must_not_keyword="auto-merge",
    description=(
        "STRUCTURAL SAFETY-NET ENTRY, not a real housekeeping action. "
        "Registered with default_band=ACT_AND_INFORM DELIBERATELY, so the "
        "must_not ceiling (apply_must_not_ceiling) is proven to refuse it "
        "even though its OWN default — not merely a misconfigured override "
        "— claims act-and-inform (order AC: 'an action mapped to a "
        "must_not item is REFUSED even when configured as act-and-inform'). "
        "LEAD.md must_not item #1 ('Auto-merge PRs without explicit "
        "Captain approval') maps to it via must_not_keyword='auto-merge'. "
        "Deliberately absent from maestro/patrol/default.json — no tier "
        "should be able to believe this is a legitimately configurable "
        "housekeeping action."
    ),
)
def _pr_merge_unreachable(ctx: ActionContext) -> str:
    raise RuntimeError(
        "pr.merge executed — this must be unreachable. The must_not "
        "ceiling in execute_action()/apply_must_not_ceiling() failed to "
        "refuse it."
    )


# ---------------------------------------------------------------------------
# Four-tier resolution — bundle > pack > workspace.json > default, mirroring
# maestro.patrol.resolver's shape for a single field (`band` vs. checks'
# enabled/severity/scope/params). Kept as a SEPARATE, smaller resolver
# rather than generalising patrol.resolver itself: that module is already
# shipped and tested (FTR-MSO-2026-0532) and touching it is outside this
# order's file list — flagged as a follow-up refactor candidate in the
# handoff (the ~150-line shape below is genuinely similar to resolver.py's,
# which is the kind of duplication BUG-MSO-2026-0426 warns against; the
# single-field case is simple enough that duplicating it once is a smaller
# risk than widening an already-shipped resolver's contract).
# ---------------------------------------------------------------------------

_SCHEMA_PATH = Path(__file__).parent.parent / "patrol" / "_schema.json"
_DEFAULT_PATH = Path(__file__).parent.parent / "patrol" / "default.json"


class ActionDefinitionError(Exception):
    """Raised internally by a single tier's loader. Always caught by
    :func:`resolve_action_bands` — never escapes this module. Mirrors
    ``maestro.patrol.resolver.PatrolDefinitionError``."""

    def __init__(self, tier: str, path: str, error: str):
        super().__init__(f"[{tier}] {path}: {error}")
        self.tier = tier
        self.path = path
        self.error = error


@dataclass(frozen=True)
class ResolvedAction:
    id: str
    band: Band
    source_tier: str = "code-default"


@dataclass(frozen=True)
class ActionResolution:
    actions: "dict[str, ResolvedAction]"
    unknown_warnings: tuple = ()
    refusals: tuple = ()


def _validate_doc(data: dict, *, tier: str, source: str) -> None:
    import jsonschema

    schema = json.loads(_SCHEMA_PATH.read_text(encoding="utf-8"))
    try:
        jsonschema.validate(data, schema)
    except jsonschema.ValidationError as exc:
        raise ActionDefinitionError(tier, source, f"schema-invalid: {exc.message}") from exc


def _load_default_action_overrides() -> "dict[str, dict]":
    """Tier 4 — ``maestro/patrol/default.json``'s ``actions`` array (the
    SAME document ``checks`` lives in — order 7's own instruction is
    "modify default.json (actions block)", not a second file)."""
    try:
        raw = json.loads(_DEFAULT_PATH.read_text(encoding="utf-8"))
        _validate_doc(raw, tier="default", source=str(_DEFAULT_PATH))
    except Exception:  # noqa: BLE001 — a broken shipped default must not crash resolution
        raw = {}
    return {a["id"]: a for a in raw.get("actions", []) if "id" in a}


def _load_workspace_action_overrides(artefact_root: Path) -> "dict[str, dict]":
    """Tier 3 — the ``patrol`` block's ``actions`` array in
    ``<artefact_root>/config/workspace.json``, inline or via the same
    ``{"file": "..."}`` pointer ``checks`` already supports."""
    ws_path = artefact_root / "config" / "workspace.json"
    if not ws_path.exists():
        return {}
    try:
        cfg = json.loads(ws_path.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001
        raise ActionDefinitionError("workspace", str(ws_path), f"invalid JSON: {exc}") from exc

    block = cfg.get("patrol")
    if not block or not isinstance(block, dict):
        return {}

    file_ref = block.get("file")
    if file_ref:
        ref_path = Path(file_ref)
        if not ref_path.is_absolute():
            ref_path = artefact_root / ref_path
        if not ref_path.exists():
            return {}
        try:
            doc = json.loads(ref_path.read_text(encoding="utf-8"))
        except Exception as exc:  # noqa: BLE001
            raise ActionDefinitionError("workspace", str(ref_path), f"invalid JSON: {exc}") from exc
        _validate_doc(doc, tier="workspace", source=str(ref_path))
        return {a["id"]: a for a in doc.get("actions", []) if "id" in a}

    actions = block.get("actions", [])
    if not actions:
        return {}
    _validate_doc({"actions": actions}, tier="workspace", source=f"{ws_path}#patrol")
    return {a["id"]: a for a in actions if "id" in a}


def _load_pack_action_overrides(workspace: Optional[Path]) -> "dict[str, dict]":
    """Tier 2 — the active division pack's ``patrol.actions``."""
    if workspace is None:
        return {}

    from maestro import auth

    if not auth.has_tier({"pro", "team", "enterprise"}):
        return {}

    from maestro.packs import load_builtin, resolve_profile_pack_pin

    try:
        pin = resolve_profile_pack_pin(workspace)
    except Exception as exc:  # noqa: BLE001 — "a resolver that raises"
        raise ActionDefinitionError(
            "pack", "enrolment profile pack pin", f"{type(exc).__name__}: {exc}"
        ) from exc

    if not pin or not pin.get("id"):
        return {}

    pack_id = pin["id"]
    try:
        pack = load_builtin(pack_id)
    except Exception as exc:  # noqa: BLE001
        raise ActionDefinitionError(
            "pack", f"pack '{pack_id}'", f"{type(exc).__name__}: {exc}"
        ) from exc

    actions = (pack.patrol or {}).get("actions", [])
    return {a["id"]: a for a in actions if "id" in a}


def _load_bundle_action_overrides(workspace: Optional[Path]) -> "dict[str, dict]":
    """Tier 1 — the highest-authority governance policy bundle's
    ``patrol.actions`` (org > workspace > user, ``TIER_RANK``)."""
    if workspace is None:
        return {}

    from maestro.governance.loader import load_bundles
    from maestro.governance.schema import TIER_RANK, GovernanceError

    try:
        bundles = load_bundles(workspace)
    except GovernanceError as exc:
        raise ActionDefinitionError("bundle", "governance policy bundle", str(exc)) from exc
    except Exception as exc:  # noqa: BLE001
        raise ActionDefinitionError(
            "bundle", "governance policy bundle", f"{type(exc).__name__}: {exc}"
        ) from exc

    ordered = sorted(bundles, key=lambda b: -TIER_RANK.get(b.tier, 99))
    merged: "dict[str, dict]" = {}
    for bundle in ordered:
        patrol = bundle.patrol or {}
        actions = patrol.get("actions", [])
        if not actions:
            continue
        _validate_doc({"actions": actions}, tier="bundle", source=f"bundle '{bundle.bundle_id}'")
        for a in actions:
            if "id" in a:
                merged[a["id"]] = a
    return merged


def _apply_governed_tier(
    resolved: "dict[str, ResolvedAction]",
    overrides: "dict[str, dict]",
    tier: str,
    governed: "dict[str, dict]",
    refusals: list,
    workspace: Optional[Path],
    env: dict,
) -> None:
    """Layer *overrides* (tier "workspace" or "pack") onto *resolved*,
    refusing any band that loosens a bundle-governed floor unless a
    breakglass grant is present (D1 — §5.4, §3.4 point 2)."""
    from maestro.governance.breakglass import breakglass_grant, record_policy_event

    for action_id, ov in overrides.items():
        if action_id not in resolved or "band" not in ov:
            continue
        candidate = Band(ov["band"])
        floor_entry = governed.get(action_id)
        floor_band = Band(floor_entry["band"]) if floor_entry and "band" in floor_entry else None

        if floor_band is not None and _is_looser_band(candidate, floor_band):
            granted, actor, reason = breakglass_grant(workspace, env)
            if granted:
                resolved[action_id] = ResolvedAction(id=action_id, band=candidate, source_tier=tier)
                record_policy_event(
                    workspace, "lead.action.breakglass", action_id, result="granted",
                    metadata={"tier": tier, "value": candidate.value, "reason": reason},
                    actor=actor,
                )
            else:
                refusals.append(
                    f"action '{action_id}' band override {candidate.value!r} from tier "
                    f"'{tier}' refused — governed floor is {floor_band.value!r} (D1 "
                    "monotonic; no breakglass grant present); governed value used."
                )
                record_policy_event(
                    workspace, "lead.action.override", action_id, result="refused",
                    metadata={"tier": tier, "attempted": candidate.value, "governed": floor_band.value},
                    actor=actor,
                )
            continue

        resolved[action_id] = ResolvedAction(id=action_id, band=candidate, source_tier=tier)


# ---------------------------------------------------------------------------
# Named per-action config opt-ins (BUG-MSO-2026-0712)
#
# ONE entry, and it should stay small. `hub.restart` is not a band an org
# tunes through the four-tier mechanism above — it is a single boolean an
# OPERATOR flips for their own machine ("may the LEAD bring my Hub back up
# unattended?"), which is why the order specifies it as
# `lead.hubAutoRestart` in workspace.json rather than as an `actions` entry.
#
# It is applied AFTER the four tiers and only to an action still sitting at
# its `code-default`, so it can never loosen a band any tier deliberately
# pinned — a governed bundle (or a pack, or an explicit workspace `actions`
# entry) saying `hub.restart: observe` still wins, and D1's
# tighten-never-loosen rule survives intact. `apply_must_not_ceiling` runs
# later still, in `execute_action`, so this cannot climb over that ceiling
# either.
#
# Adding a second entry here means asking whether the four-tier mechanism
# should have handled it instead; two config surfaces for one decision is
# how a band ends up meaning different things in different places.
# ---------------------------------------------------------------------------

_CONFIG_OPT_IN_ACTIONS: "dict[str, tuple[str, Band]]" = {
    "hub.restart": ("hubAutoRestart", Band.ACT_AND_INFORM),
}


def apply_config_opt_in(resolved: "dict[str, ResolvedAction]", artefact_root: Path) -> None:
    """Promote each opt-in action whose `lead.*` flag is set, in place.

    Never raises and never demotes: an unreadable config, an absent flag or
    a flag set to false all leave the resolution exactly as the four tiers
    left it, which for `hub.restart` is the registered OBSERVE default.
    """
    if not _CONFIG_OPT_IN_ACTIONS:
        return
    try:
        config = load_lead_config(Path(artefact_root))
    except Exception:  # noqa: BLE001 — per-tier isolation, see resolve_action_bands
        return
    for action_id, (flag, band) in _CONFIG_OPT_IN_ACTIONS.items():
        current = resolved.get(action_id)
        if current is None or current.source_tier != "code-default":
            continue  # a tier spoke deliberately — never override it
        if config.get(flag):
            resolved[action_id] = ResolvedAction(
                id=action_id, band=band, source_tier=f"lead.{flag}"
            )


def resolve_action_bands(
    *,
    artefact_root: Path,
    workspace: Optional[Path] = None,
    env: Optional[dict] = None,
    registry: Optional["dict[str, ActionSpec]"] = None,
) -> ActionResolution:
    """Resolve the effective band for every registered LEAD action.

    Seeded BELOW tier 4 by each action's code-registered ``default_band``
    (so ``pr.merge`` — deliberately absent from ``default.json`` — still
    resolves to something), then layered bundle > pack > workspace.json >
    default.json exactly as ``maestro.patrol.resolver`` does for checks.

    Never raises: a tier's loader failing drops only THAT tier's
    contribution (never the whole resolution) — the three always-safe D7
    default actions must keep resolving even if, say, a division pack pin
    is broken. This is intentionally more forgiving than
    ``patrol.resolver``'s "any tier failing ⇒ full fallback" rule: an
    action-band resolution failure has a much smaller blast radius (one
    action stays at its code default) than a checks-resolution failure
    (which would otherwise silently run a shorter *set of checks*).
    """
    reg = registry if registry is not None else _REGISTRY
    env = env if env is not None else os.environ
    refusals: list = []

    def _safe(loader, *a, **k):
        try:
            return loader(*a, **k)
        except Exception:  # noqa: BLE001 — see docstring: per-tier isolation
            return {}

    default_overrides = _safe(_load_default_action_overrides)
    governed = _safe(_load_bundle_action_overrides, workspace)
    workspace_overrides = _safe(_load_workspace_action_overrides, artefact_root)
    pack_overrides = _safe(_load_pack_action_overrides, workspace)

    resolved: "dict[str, ResolvedAction]" = {
        action_id: ResolvedAction(id=action_id, band=spec.default_band, source_tier="code-default")
        for action_id, spec in reg.items()
    }

    for action_id, ov in default_overrides.items():
        if action_id in resolved and "band" in ov:
            resolved[action_id] = ResolvedAction(id=action_id, band=Band(ov["band"]), source_tier="default")

    # Tier 1 (bundle) is the authoritative floor — applied unconditionally,
    # exactly like resolver.py's `_apply_plain(resolved, governed, "bundle")`.
    for action_id, ov in governed.items():
        if action_id in resolved and "band" in ov:
            resolved[action_id] = ResolvedAction(id=action_id, band=Band(ov["band"]), source_tier="bundle")

    # Tier 3 (workspace) then tier 2 (pack) — pack outranks workspace.
    _apply_governed_tier(resolved, workspace_overrides, "workspace", governed, refusals, workspace, env)
    _apply_governed_tier(resolved, pack_overrides, "pack", governed, refusals, workspace, env)

    apply_config_opt_in(resolved, artefact_root)

    unknown_ids = {
        action_id
        for source in (default_overrides, workspace_overrides, pack_overrides, governed)
        for action_id in source
        if action_id not in reg
    }
    unknown_warnings = tuple(sorted(f"unknown LEAD action '{aid}' — ignored" for aid in unknown_ids))

    return ActionResolution(actions=resolved, unknown_warnings=unknown_warnings, refusals=tuple(refusals))


# ---------------------------------------------------------------------------
# The must_not ceiling (§3.4 point 3 / §8) — separate from, and applied
# AFTER, the D1 four-tier resolution above. Not breakglass-eligible: D1's
# override is about an ORG choosing to be stricter or looser than a
# governed policy; must_not is the fixed proactivity ceiling every LEAD
# action answers to regardless of policy, the same way a crew's
# `ROLE_DISALLOWED_TOOLS` scoping is not something a workspace overlay can
# negotiate away.
# ---------------------------------------------------------------------------

def _load_must_not_text(workspace: Optional[Path]) -> str:
    from maestro.roles.loader import load_effective_role

    role = load_effective_role("LEAD", workspace, resident=True)
    section = role.sections.get("must_not")
    return section.body if section else ""


def is_forbidden_by_must_not(spec: ActionSpec, workspace: Optional[Path]) -> bool:
    """True when *spec* is mapped (via ``must_not_keyword``) to a
    ``LEAD.md`` ``must_not`` item that is actually present in the resolved
    (D6-protected, resident) must_not text.

    Fails CLOSED for an action that declares a ``must_not_keyword``: if the
    role text cannot be loaded at all (a corrupted install), the action is
    treated as forbidden rather than silently unrestricted — the ceiling is
    a safety mechanism, so an inability to verify it must not read as
    permission. Actions with no ``must_not_keyword`` never call this at
    all, and are unaffected by any role-loading failure.
    """
    if not spec.must_not_keyword:
        return False
    try:
        text = _load_must_not_text(workspace)
    except Exception:  # noqa: BLE001 — fail closed, see docstring
        return True
    return spec.must_not_keyword.lower() in text.lower()


def apply_must_not_ceiling(
    resolved: ResolvedAction, spec: ActionSpec, workspace: Optional[Path]
) -> ResolvedAction:
    """The band ceiling is ``LEAD.md``'s ``must_not`` (order AC): an action
    mapped to a ``must_not`` item is forced to ``PROPOSE_AND_WAIT``
    regardless of what any tier — including a signed policy bundle —
    configured it as. Unconditional; no breakglass parameter exists here on
    purpose."""
    if resolved.band != Band.PROPOSE_AND_WAIT and is_forbidden_by_must_not(spec, workspace):
        return ResolvedAction(id=resolved.id, band=Band.PROPOSE_AND_WAIT, source_tier="must_not_ceiling")
    return resolved


# ---------------------------------------------------------------------------
# Execution — the only place an action's `func` (the writer) is ever called.
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class ActionExecutionResult:
    action_id: str
    band: Band
    executed: bool
    outcome: str  # "executed" | "observed" | "proposed" | "refused" | "error"
    detail: str
    source_tier: str = "code-default"
    # BUG-MSO-2026-0636 (F4): True whenever this call actually mutated the
    # workspace, INCLUDING a "refused" outcome that followed real partial
    # work (see ActionPreconditionRefused.acted). Deliberately separate from
    # `executed`/`outcome` — `outcome` keeps naming the SAFETY verdict
    # ("refused" is still correct and logged as such), while `acted` is what
    # `dispatch_actions_for_findings`/`agent.run_once` need to avoid
    # reporting a tick that destroyed worktrees as "(never) acted".
    acted: bool = False


def execute_action(
    action_id: str,
    *,
    artefact_root: Path,
    workspace: Optional[Path] = None,
    env: Optional[dict] = None,
    subject: Any = None,
    finding_id: str = "",
    why: str = "",
    registry: Optional["dict[str, ActionSpec]"] = None,
) -> ActionExecutionResult:
    """Resolve *action_id*'s band and, only when it lands at
    ``ACT_AND_INFORM`` after the must_not ceiling has been applied, run it.

    §3.4 point 3: "Every act-and-inform action is logged as a lifecycle
    event (`LEAD_ACTION`) with what, why, and the finding that triggered
    it... 'Act' never means 'quietly'." — so a `LEAD_ACTION` line is written
    for ``executed``, ``refused``, and ``error`` outcomes (the LEAD actually
    acted, tried to and found its precondition had gone stale, or tried to
    and failed); ``observed``/``proposed`` are silent here — the patrol's
    own finding reporting already carries those, and logging a lifecycle
    line on every OBSERVE-band resolution would be exactly the "reports
    every tick" noise §6 exists to prevent. ``refused`` (BUG-MSO-2026-0633)
    is DIFFERENT from ``proposed``: ``proposed`` means the band itself
    requires Captain approval and the action body never ran at all;
    ``refused`` means the band cleared it to run, the action body started,
    and it declined to act because its own execution-time precondition
    check (re-validated fresh, never trusted from finding time) failed.

    Unregistered *action_id* is a caller bug (the whole action catalogue is
    code-defined, never data-supplied at the call site) — raises
    ``KeyError`` rather than fabricating a result.
    """
    reg = registry if registry is not None else _REGISTRY
    spec = reg.get(action_id)
    if spec is None:
        raise KeyError(f"unknown LEAD action id: {action_id!r}")

    resolution = resolve_action_bands(
        artefact_root=artefact_root, workspace=workspace, env=env, registry=reg,
    )
    resolved = resolution.actions.get(
        action_id, ResolvedAction(id=action_id, band=spec.default_band)
    )
    resolved = apply_must_not_ceiling(resolved, spec, workspace)

    acted = False
    if resolved.band == Band.PROPOSE_AND_WAIT:
        outcome, executed = "proposed", False
        detail = f"'{action_id}' requires explicit Captain approval (band source: {resolved.source_tier})."
    elif resolved.band == Band.OBSERVE:
        outcome, executed = "observed", False
        detail = f"'{action_id}' observed only (band=observe)."
    else:  # ACT_AND_INFORM
        try:
            ctx = ActionContext(artefact_root=Path(artefact_root), workspace=workspace, subject=subject)
            # BUG-MSO-2026-0601 (GH #376): scope fleet_runner's process-global
            # artefact-root override to THIS action's root for the duration of
            # the call. worktree.prune (maestro.core.worktrees) and the other
            # D7 actions ultimately resolve paths via that override when set —
            # without entering the scope here, a caller serving more than one
            # workspace from one process (the LEAD daemon across ticks, the
            # Hub's poller, a multi-workspace CLI scan) could act on whichever
            # workspace a PRIOR call happened to leave the override pointing
            # at, or fall back to deriving from the process's own cwd — either
            # way, potentially the wrong fleet. Composes with FTR-MSO-2026-0585
            # rather than duplicating it: same primitive
            # (order_retry.workspace_scope), applied once at this single choke
            # point so every current and future action registered here — not
            # just worktree.prune — is correctly scoped by construction.
            from maestro.core.order_retry import workspace_scope

            with workspace_scope(ctx.artefact_root):
                summary = spec.func(ctx)
            outcome, executed, detail = "executed", True, summary
            acted = True
        except ActionPreconditionRefused as exc:
            # BUG-MSO-2026-0633: a deliberate, correct safety decision — the
            # action's OWN execution-time re-check found its precondition
            # had gone stale since the finding was computed. Never an
            # "error" (nothing went wrong; the refusal IS the system working).
            # BUG-MSO-2026-0636 (F4): `exc.acted` carries whether real
            # destructive work happened before this refusal (a partial
            # worktree.prune tick) — kept separate from `outcome`, which
            # stays "refused" either way.
            outcome, executed, detail = "refused", False, str(exc)
            acted = exc.acted
        except Exception as exc:  # noqa: BLE001 — an action failing must not crash the tick
            outcome, executed, detail = "error", False, f"{type(exc).__name__}: {exc}"

    if outcome in ("executed", "refused", "error"):
        message = (
            f"action={action_id} band={resolved.band.value} outcome={outcome} "
            f"why={why or '(unspecified)'} finding={finding_id or '(none)'} detail={detail}"
        )
        _write_lifecycle_event(Path(artefact_root), "LEAD_ACTION", message)

    return ActionExecutionResult(
        action_id=action_id,
        band=resolved.band,
        executed=executed,
        outcome=outcome,
        detail=detail,
        source_tier=resolved.source_tier,
        acted=acted,
    )


# ---------------------------------------------------------------------------
# Finding -> action mapping (RC-1 / Dimension C, PLAN-PLN-MSO-2026-0584).
#
# `hygiene.stale-worktrees` emits `suggestedCommand="mso worktree prune"`
# (BUG-MSO-2026-0680) for a human to run directly, but the mapping below is
# still declared explicitly rather than inferred from that string — this map
# drives which LEAD *action id* a finding dispatches to, not what an operator
# should type. Kept small and explicit on purpose: this is EXACTLY Captain
# ruling D7's three
# named actions (two still resolving ACT_AND_INFORM by default —
# `voyage.reconcile`, `artefact.sweep` — and `worktree.prune`, narrowed to
# OBSERVE by the 2026-09-06 ruling, see this module's top docstring) and no
# more. Adding a check id here does NOT widen the band on its own — the
# mapped action still resolves through `execute_action` ->
# `resolve_action_bands` -> `apply_must_not_ceiling` every time, so a
# mapped-but-OBSERVE (or must_not-ceilinged) action is still correctly a
# no-op — which is exactly the mechanism that keeps `worktree.prune` here
# safe post-narrowing: the finding still maps to it, `execute_action` still
# resolves it, and it still only ever reaches outcome="observed". `pr.promote-
# draft` is deliberately never a value here (D7 excludes it — it spends
# money) and `pr.merge` is deliberately never a value here in production
# data; a test may still override the map with `action_map=` to prove the
# ceiling is reachable through this path.
# ---------------------------------------------------------------------------

FINDING_ACTION_MAP: "dict[str, str]" = {
    "hygiene.stale-worktrees": "worktree.prune",
    "voyages.merged-not-archived": "voyage.reconcile",
    "artefacts.unpushed": "artefact.sweep",
    # BUG-MSO-2026-0712. Mapping a finding here does NOT widen a band — see
    # this comment block above — so `hub.restart` reaching outcome="observed"
    # on an untouched workspace is the mechanism working, exactly as
    # `worktree.prune` does post-narrowing. It only ever acts where the
    # operator set `lead.hubAutoRestart: true` (apply_config_opt_in).
    "hub.alive": "hub.restart",
}


@dataclass(frozen=True)
class ActionTickSummary:
    """One tick's finding -> action dispatch result (PLAN-PLN-MSO-2026-0584
    Dimension C3). Makes "nothing needed doing" distinguishable from "the
    action path is broken", which is exactly how 94 ticks of zero
    `LEAD_ACTION` events went unnoticed:

      * ``considered=0``                    -> nothing needed doing (no
                                                NEW/ESCALATED findings at all).
      * ``eligible=0``                       -> considered findings, but none
                                                mapped to an action currently
                                                resolving to ACT_AND_INFORM.
      * ``eligible>0, executed=0``           -> something SHOULD have acted
                                                and didn't — investigate
                                                ``errors``/``refused``/
                                                ``precondition_refused``.

    ``refused`` counts outcome ``"proposed"`` — the BAND itself required
    Captain approval, so the action body never ran. ``precondition_refused``
    (BUG-MSO-2026-0633) counts outcome ``"refused"`` — a DIFFERENT case: the
    band cleared the action to run, but its own execution-time re-check
    found the precondition its triggering finding relied on had gone stale
    (e.g. a worktree the finding believed unoccupied now has a live crew
    PID). Kept as a separate counter rather than folded into ``refused`` so
    "Captain approval required" and "a live safety check fired" never look
    like the same event in the tick summary.
    """

    considered: int = 0
    eligible: int = 0
    executed: int = 0
    refused: int = 0
    precondition_refused: int = 0
    errors: int = 0
    # BUG-MSO-2026-0636 (F4): count of action groups that mutated the
    # workspace this tick, INCLUDING a "refused" group that did partial
    # destructive work before its refusal (e.g. worktree.prune removing some
    # worktrees before hitting an occupied one). `executed` alone misses
    # that case; `agent.run_once`'s `lastActionAt` bookkeeping needs this to
    # avoid reporting "(never)" for a tick that demonstrably acted.
    acted: int = 0
    results: "tuple[ActionExecutionResult, ...]" = ()


def dispatch_actions_for_findings(
    findings: "list[Any]",
    *,
    artefact_root: Path,
    workspace: Optional[Path] = None,
    env: Optional[dict] = None,
    action_map: Optional["dict[str, str]"] = None,
) -> ActionTickSummary:
    """Map NEW/ESCALATED findings to D7 actions and execute each mapped,
    still-registered action AT MOST ONCE per tick — order AC: "15 findings
    from one check produce exactly ONE action execution, not 15."

    *findings* are duck-typed as anything exposing ``.finding.check_id``,
    ``.finding.title`` and ``.fingerprint`` — deliberately NOT typed against
    ``maestro.patrol.state.DeltaFinding`` so this module stays decoupled
    from the patrol state engine's own dataclass (agent.py is the only
    caller that has both).

    Grouped by mapped action id first, so ``execute_action`` — the ONLY call
    site that ever runs an action's body — is invoked exactly once per
    unique action id present this tick. Because a resolved band is a
    property of the ACTION, not of any one finding, every finding in a group
    shares the group's outcome; ``eligible`` is the count of FINDINGS whose
    action resolved to ``ACT_AND_INFORM`` (so ``eligible=15, executed=0``
    reads as broken even though a healthy tick would show ``executed=1``,
    not ``15``, once dedup kicks in). This is the NEW caller the must_not
    ceiling has to be proven to still refuse through — it never bypasses
    ``execute_action``.
    """
    m = action_map if action_map is not None else FINDING_ACTION_MAP
    considered = len(findings)

    groups: "dict[str, list[Any]]" = {}
    for f in findings:
        action_id = m.get(f.finding.check_id)
        if action_id is None or get_action(action_id) is None:
            continue
        groups.setdefault(action_id, []).append(f)

    eligible = executed = refused = precondition_refused = errors = acted = 0
    results: "list[ActionExecutionResult]" = []
    for action_id, group in groups.items():
        # PLAN-PLN-MSO-2026-0584 Dimension A: the second of stand-down's two
        # cooperative checkpoints ("at the top of each tick and between
        # actions within a tick, never as a wait loop" — never mid-git). A
        # stand-down requested WHILE this tick is dispatching multiple D7
        # action groups is honoured before starting the NEXT one; an action
        # already in flight always finishes. Re-read live rather than a
        # frozen snapshot, so a stand-down that arrives between groups takes
        # effect immediately rather than waiting for the next tick.
        if load_lead_config(artefact_root).get("standDown"):
            break
        representative = group[0]
        result = execute_action(
            action_id,
            artefact_root=artefact_root,
            workspace=workspace,
            env=env,
            why=representative.finding.title,
            finding_id=representative.fingerprint,
        )
        results.append(result)
        if result.band == Band.ACT_AND_INFORM:
            eligible += len(group)
        if result.outcome == "executed":
            executed += 1
        elif result.outcome == "error":
            errors += 1
        elif result.outcome == "proposed":
            refused += 1
        elif result.outcome == "refused":
            precondition_refused += 1
        if result.acted:
            acted += 1

    return ActionTickSummary(
        considered=considered,
        eligible=eligible,
        executed=executed,
        refused=refused,
        precondition_refused=precondition_refused,
        acted=acted,
        errors=errors,
        results=tuple(results),
    )
