# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""maestro/lead/run_verbs.py — the closed verb list behind the Hub's LEAD
"Run" button (FTR-MSO-2026-0631).

The Captain asked for a Run button next to a LEAD finding's suggested
command, so acting on a finding doesn't require leaving the Hub for a
terminal. The naive implementation — POST the command string, run it in a
shell — would hand any Hub viewer arbitrary command execution on the
operator's machine. This module is the alternative: a CLOSED, ENUMERATED
list of (regex pattern -> handler) pairs, derived from what the patrol
checks actually emit as ``Finding.suggestedCommand`` (see
``maestro.patrol.checks.*`` — read those, never guessed). A command that
does not match one of the patterns below is not runnable, full stop; no
fallback path exists that would execute it another way.

Each handler calls the exact function (or, for ``dispatcher.cleanup``, the
exact CLI subprocess invocation) an existing tier-gated Hub endpoint already
calls — never a second implementation of the verb:

    order.retry        -> maestro.core.order_retry.retry_order()
                           (same core POST /api/v1/orders/{id}/retry uses)
    voyage.reconcile    -> subprocess: `mso voyage reconcile --json --maestro-dir <mso>`
                           (same subprocess invocation POST
                           /api/v1/workspaces/{id}/sweep already runs — see
                           BUG-MSO-2026-0648 F1 below for why this must be a
                           killable OS process, never an in-process call.
                           `--maestro-dir` is an explicit argv value, not
                           just the `MAESTRO_DIR` env var — see
                           BUG-MSO-2026-0675 F1 below.)
    dispatcher.cleanup  -> subprocess: `mso cleanup --maestro-dir <mso>`
                           (NOT `mso cleanup --no-backup` — see
                           BUG-MSO-2026-0643 F1 below. `--maestro-dir` is
                           likewise an explicit argv value — BUG-MSO-2026-0675 F1.)

BUG-MSO-2026-0643 F1: the finding's ``suggestedCommand`` for this verb is the
literal text ``mso cleanup`` — the operator clicks Run believing that is what
executes. ``POST /api/v1/workspaces/{id}/stop`` (the Hub's "Stop" button)
legitimately passes ``--no-backup`` there: Stop is a routine, frequent,
low-stakes action with its own honest button label ("Stop"), and taking a
full backup on every start/stop cycle would be wasteful. This verb is
different — `cmd_cleanup` itself documents cleanup as "the most destructive
operation this CLI exposes" and takes an auto-backup specifically because of
that, and the finding text the operator approved says `mso cleanup`, not
`mso cleanup --no-backup`. Silently dropping the restore point here would be
both a lie (the button doesn't do what it says) and a safety regression (the
one recovery path a botched cleanup would need is gone). So this handler runs
the command AS DISPLAYED, backup included — never `--no-backup`.

``pr.merge`` is a structural safety-net entry, not a real housekeeping verb
— it mirrors ``maestro.lead.bands``'s own ``pr.merge`` registration. No
patrol check ever emits its command text, so it is unreachable from a real
finding; it exists purely so :func:`is_forbidden` (and therefore the D6
``must_not`` ceiling) is provably reachable through THIS path, exercised
directly by a test, rather than merely asserted by inspection.

The D6 ``must_not`` ceiling itself is not reimplemented here —
:func:`is_forbidden` calls ``maestro.lead.bands.is_forbidden_by_must_not``,
the exact function the autonomous LEAD's ``execute_action()`` calls, so a
human-clicked Run is refused identically to the autonomous daemon for any
verb mapped to a ``LEAD.md`` ``must_not`` item.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional

from maestro.lead.bands import ActionSpec, Band, is_forbidden_by_must_not

__all__ = [
    "RunOutcome",
    "VerbSpec",
    "VerbMatch",
    "parse_verb",
    "is_runnable",
    "verb_id_for",
    "is_forbidden",
]

# Same shape as server.py's own `_ORDER_ID_RE` (hub/server.py) — kept as a
# local constant rather than imported, since server.py defines its copy
# inside a FastAPI closure (create_app()) and isn't importable from here.
_ORDER_ID = r"[A-Za-z0-9][A-Za-z0-9._-]{0,64}"


@dataclass(frozen=True)
class RunOutcome:
    """What a handler actually did. ``ok=False`` means the action was
    attempted and failed (or refused itself, e.g. `RetryRefused`) — the
    caller reports this as outcome ``"failed"``, never an optimistic
    success. A handler that cannot proceed at all should return this rather
    than raise, where the failure is an ordinary, expected outcome (e.g. no
    product-repo checkout to run `mso cleanup` in); a handler MAY still let
    an unexpected exception propagate — the endpoint's own catch-all
    classifies that as ``"failed"`` too.

    ``still_open``/``verified`` (BUG-MSO-2026-0643 F3): a handler that already
    knows, from the REAL work it just did, whether the finding's condition is
    now cleared may set these instead of leaving them ``None``. The endpoint
    then reports that directly rather than spending a SECOND re-evaluation
    call — load-bearing for ``voyage.reconcile``, whose re-evaluation check
    (``voyages.merged-not-archived``) is itself gh-backed: without this, one
    Run click fired the gh-backed sweep twice (once for real, once again as a
    dry run to re-check), unbounded. Leaving both ``None`` (every other
    handler) preserves the original generic re-evaluation-via-single-check
    behaviour unchanged."""

    ok: bool
    message: str
    still_open: Optional[bool] = None
    verified: Optional[bool] = None


RunHandler = Callable[[dict, Path, Optional[Path]], RunOutcome]


@dataclass(frozen=True)
class VerbSpec:
    id: str
    pattern: "re.Pattern[str]"
    handler: RunHandler
    arg_names: tuple = ()
    must_not_keyword: Optional[str] = None
    description: str = ""


# ---------------------------------------------------------------------------
# Handlers — each one is a thin wrapper around the SAME call an existing
# tier-gated Hub endpoint (or the CLI itself) already makes. No handler
# builds a shell command from the raw suggestedCommand text; only the
# regex-captured, already-shape-validated arguments (e.g. an order id) are
# ever passed through, and only into a typed Python call or a hard-coded
# argv list — never into a string handed to a shell.
# ---------------------------------------------------------------------------

def _handle_order_retry(args: dict, mso: Path, product_repo: Optional[Path]) -> RunOutcome:
    from maestro.core import order_retry

    order_id = args["order_id"]
    outcome = order_retry.retry_order(
        mso, order_id, reason="operator run via Hub Run button (LEAD finding)"
    )
    return RunOutcome(
        ok=True,
        message=(
            f"Order {order_id} reopened: {outcome.new_status}@{outcome.target_role}"
            f"{outcome.salvage_note}"
        ),
    )


# BUG-MSO-2026-0643 F3: wall-clock ceiling for the one real, gh-backed sweep
# this handler runs — same 300s the Hub's own POST /workspaces/{id}/sweep
# bounds identical work at.
#
# BUG-MSO-2026-0648 F1: a KILLABLE SUBPROCESS, never an in-process thread. A
# thread that called run_housekeeping_sweep(artefact_root=mso) directly used
# to enter order_retry.workspace_scope(), which holds the PROCESS-GLOBAL
# _SCOPE_LOCK and pins fleet_runner._MAESTRO_DIR_OVERRIDE for the sweep's
# duration. A Python thread cannot be killed — abandoning one on timeout left
# that lock held and the override pinned in the Hub's own long-lived process
# forever: every later workspace_scope acquirer (the next order-retry POST,
# any voyage patrol check) blocked on an untimed lock, every unscoped
# fleet_runner resolution in the process resolved to the wrong workspace, and
# the abandoned dry_run=False sweep kept running in the background and could
# still archive voyages / commit lifecycle transitions after the operator was
# told "No changes were reported."
#
# BUG-MSO-2026-0686 F1: a plain `subprocess.run(timeout=)` only calls
# `.kill()` on the DIRECT child — the `mso voyage reconcile` process itself.
# The gh/git GRANDCHILD it can be genuinely stuck on (a hanging PR lookup)
# SURVIVES that kill, so the 300s ceiling was not a real bound: the operator
# was told "timed out" while the underlying gh call kept running unsupervised
# in the background, exactly the BUG-MSO-2026-0661 finding for a different
# call site. Spawned via Popen (not subprocess.run) specifically so a timeout
# can reach the WHOLE tree via `_kill_process_tree` — the same helper
# `_handle_dispatcher_cleanup` below already uses for the identical
# claude->node / mso->gh grandchild problem (BUG-MSO-2026-0206,
# BUG-MSO-2026-0653 F1). On POSIX the child is put in its own session
# (`start_new_session=True`) so `os.killpg` reaches the grandchild without
# ALSO reaching this Hub process's own group.
_VOYAGE_RECONCILE_TIMEOUT_SECONDS = 300


def _handle_voyage_reconcile(args: dict, mso: Path, product_repo: Optional[Path]) -> RunOutcome:
    import json as _json
    import os
    import subprocess
    import sys

    from maestro.core.crew import _kill_process_tree
    from maestro.core.proc import popen_hidden

    if product_repo is None:
        return RunOutcome(
            ok=False,
            message="Cannot resolve the product repo checkout for this workspace.",
        )

    # BUG-MSO-2026-0675 F1: `--maestro-dir` is the AUTHORITATIVE workspace
    # signal, passed as an explicit argv value — exactly the treatment
    # BUG-MSO-2026-0672 F1 gave `mso doctor --single-check` for the identical
    # reason. `cmd_voyage`'s `reconcile` action resolves via `find_workspace()`,
    # which deliberately IGNORES the `MAESTRO_DIR` env var below (BUG-MSO-2026-0425)
    # and instead walks up from cwd — an absent `.mso/config` above cwd used to
    # raise (permanently refusing this Run), and a stale/foreign one let this
    # action silently operate on a DIFFERENT fleet's workspace. The `env=`
    # MAESTRO_DIR kwarg is kept as a harmless secondary signal for anything
    # else in the subprocess that might read it ambiently; it is no longer
    # what makes this resolve correctly.
    cmd = [
        sys.executable, "-m", "maestro.cli", "voyage", "reconcile", "--json",
        "--maestro-dir", str(mso),
    ]
    popen_kwargs: dict = dict(
        cwd=str(product_repo),
        env={**os.environ, "MAESTRO_DIR": str(mso)},
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )
    if os.name != "nt":
        popen_kwargs["start_new_session"] = True
    try:
        proc = popen_hidden(cmd, **popen_kwargs)
    except OSError as exc:
        # Same class of failure as BUG-MSO-2026-0643 F4 in the cleanup
        # handler below — a moved/deleted product-repo checkout.
        return RunOutcome(
            ok=False,
            message=(
                f"Cannot resolve the product repo checkout for this workspace "
                f"— {product_repo} does not exist (moved or deleted?): {exc}"
            ),
        )

    try:
        stdout, _ = proc.communicate(timeout=_VOYAGE_RECONCILE_TIMEOUT_SECONDS)
    except subprocess.TimeoutExpired:
        # The naive `proc.kill()` subprocess.run would have done here only
        # reaches the direct `mso voyage reconcile` child — the gh/git
        # grandchild it's stuck on survives it. Kill the WHOLE tree instead,
        # mirroring `_handle_dispatcher_cleanup` below and
        # hub/server.py's sweep_workspace 504 message for the identical
        # failure mode.
        _kill_process_tree(proc.pid)
        try:
            # Drain the now-closed pipe so this process doesn't leak a
            # zombie/handle; the tree is already dead, so this returns fast.
            proc.communicate(timeout=15)
        except Exception:
            pass
        return RunOutcome(
            ok=False,
            message=(
                f"Housekeeping sweep timed out after "
                f"{_VOYAGE_RECONCILE_TIMEOUT_SECONDS // 60} minutes (a PR "
                "lookup may be hanging) — the sweep process tree was killed. "
                "No changes were reported."
            ),
        )

    if proc.returncode != 0:
        detail = (stdout or "").strip()[-500:]
        return RunOutcome(
            ok=False,
            message=f"Housekeeping sweep failed: {detail or 'unknown error'}",
        )

    try:
        out = stdout or ""
        report = _json.loads(out[out.index("{"):])
    except (ValueError, _json.JSONDecodeError):
        return RunOutcome(ok=False, message="Housekeeping sweep produced no readable report.")

    # BUG-MSO-2026-0643 F3: derive still_open/verified from THIS real run's
    # own report rather than triggering a second, dry-run sweep through the
    # generic re-evaluation path — a voyage this run just archived can no
    # longer be "merged but not archived", which is exactly what a fresh dry
    # run would (redundantly) confirm.
    subject_id = args.get("_subject_id") or ""
    archived_ids = {
        entry.get("voyage") for entry in report.get("changes", [])
        if entry.get("action") == "archived"
    }
    return RunOutcome(
        ok=True,
        message=f"{report.get('archived', 0)} voyage(s) archived, {report.get('annotated', 0)} annotated",
        still_open=(subject_id not in archived_ids) if subject_id else None,
        verified=True if subject_id else None,
    )


def _handle_dispatcher_cleanup(args: dict, mso: Path, product_repo: Optional[Path]) -> RunOutcome:
    import os
    import subprocess
    import sys

    from maestro.core.crew import _kill_process_tree
    from maestro.core.proc import popen_hidden

    # product_repo_for_entry() ALWAYS returns a Path (`entry.get("productRepo")`
    # or else `entry["path"]`, both `.resolve()`d) — never None in production.
    # This check is retained as a harmless defensive fallback (e.g. a future
    # caller passing None directly, as the tests below do), but BUG-MSO-2026-0643
    # F4 is a DIFFERENT, actually-reachable failure: the resolved path existing
    # in the registry but no longer existing on disk (a moved/deleted checkout).
    # That raised subprocess.run's raw NotADirectoryError/FileNotFoundError
    # straight through the endpoint's catch-all instead of a message naming
    # what's actually wrong — caught explicitly below, around the call that
    # can raise it.
    if product_repo is None:
        return RunOutcome(
            ok=False,
            message="Cannot resolve the product repo checkout for this workspace.",
        )
    # BUG-MSO-2026-0643 F1: run the command AS DISPLAYED to the operator —
    # the finding's suggestedCommand text is `mso cleanup`, not
    # `mso cleanup --no-backup`. cmd_cleanup takes its own auto-backup
    # specifically because cleanup is "the most destructive operation this
    # CLI exposes" (see cli.py:cmd_cleanup); silently dropping `--no-backup`
    # here would both misrepresent what Run does and remove that restore
    # point without telling anyone. This is deliberately NOT identical to
    # POST /api/v1/workspaces/{id}/stop (hub/server.py:stop_workspace), which
    # legitimately keeps --no-backup for its own distinct, frequent,
    # honestly-labelled ("Stop") action — see the module docstring.
    #
    # 120s, not stop_workspace's 60s: this invocation does real backup work
    # stop_workspace's --no-backup skips; cmd_backup.backup() already
    # self-limits (skips with a message, never hangs, on an oversized
    # workspace) so this is headroom, not a sign backup can run unbounded.
    #
    # BUG-MSO-2026-0653 F1: `python -m maestro.cli cleanup` (cmd_cleanup) itself
    # blocks on its OWN `fleet_runner.py --cleanup` grandchild (Step 1) before
    # ever reaching the auto-backup step. A plain `subprocess.run(timeout=)`
    # only calls `.kill()` on the DIRECT child on timeout — the grandchild is
    # left running, unsupervised, and can keep killing crews / resetting fleet
    # state while this handler reports the run as "failed" (inviting a second,
    # concurrent Run from an operator who was told nothing happened). This is
    # spawned via Popen (not subprocess.run) specifically so a timeout can
    # reach for the WHOLE tree via ``_kill_process_tree`` — the exact helper
    # ``invoke_claude``'s own timeout path already uses for an identical
    # claude->node->MCP grandchild problem (BUG-MSO-2026-0206). On POSIX the
    # child is put in its own session (``start_new_session=True``, mirroring
    # ``invoke_claude``'s pattern) so ``os.killpg`` reaches the grandchild
    # without ALSO reaching this Hub process's own group. A genuinely reliable
    # process-tree kill already exists and is production-proven for the same
    # class of problem — removing dispatcher.cleanup from the verb list
    # (the AC's stated fallback) was therefore not chosen; see the handoff.
    #
    # BUG-MSO-2026-0675 F1: `--maestro-dir` is the AUTHORITATIVE workspace
    # signal, passed as an explicit argv value — exactly the treatment
    # BUG-MSO-2026-0672 F1 gave `mso doctor --single-check` for the identical
    # reason. `cmd_cleanup` resolves via `find_workspace()`, which
    # deliberately IGNORES the `MAESTRO_DIR` env var below (BUG-MSO-2026-0425)
    # and instead walks up from cwd — an absent `.mso/config` above cwd used
    # to raise (permanently refusing this Run), and a stale/foreign one let
    # this command's own destructive Step 1 kill a DIFFERENT fleet's live
    # crews (the sixth occurrence of this workspace-contamination class —
    # BUG-0601/0638/0643/0656/0672). The `env=` MAESTRO_DIR kwarg is kept as
    # a harmless secondary signal for anything else in the subprocess that
    # might read it ambiently; it is no longer what makes this resolve
    # correctly.
    popen_kwargs: dict = dict(
        cwd=str(product_repo),
        env={**os.environ, "MAESTRO_DIR": str(mso)},
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )
    if os.name != "nt":
        popen_kwargs["start_new_session"] = True
    try:
        proc = popen_hidden(
            [sys.executable, "-m", "maestro.cli", "cleanup", "--maestro-dir", str(mso)],
            **popen_kwargs,
        )
    except OSError as exc:
        # BUG-MSO-2026-0643 F4: subprocess raises this (NotADirectoryError
        # / FileNotFoundError, platform-dependent) when `cwd` doesn't exist —
        # a moved or deleted product-repo checkout since the registry entry
        # was last written. Caught here, at the one place it can actually
        # happen, rather than the unreachable `product_repo is None` check
        # above — the operator gets the intended message, not a raw OS
        # exception surfacing through the endpoint's generic catch-all.
        return RunOutcome(
            ok=False,
            message=(
                f"Cannot resolve the product repo checkout for this workspace "
                f"— {product_repo} does not exist (moved or deleted?): {exc}"
            ),
        )

    try:
        stdout, _ = proc.communicate(timeout=120)
    except subprocess.TimeoutExpired:
        # The naive `proc.kill()` subprocess.run would have done here only
        # reaches `mso cleanup` itself — the fleet_runner.py --cleanup
        # grandchild survives it. Kill the WHOLE tree instead.
        _kill_process_tree(proc.pid)
        try:
            # Drain the now-closed pipe so this process doesn't leak a
            # zombie/handle; the tree is already dead, so this returns fast.
            proc.communicate(timeout=15)
        except Exception:
            pass
        return RunOutcome(
            ok=False,
            message="Cleanup timed out after 120s — the cleanup process tree was killed.",
        )
    # BUG-MSO-2026-0634 F3: a non-zero exit (e.g. a governed-workspace
    # require_capability("fleet.cleanup") denial) previously still reported
    # ok=True with "rogue processes killed, stale state cleared" — none of
    # which happened. The exit code is the only honest signal here; report
    # failure and the command's own tail rather than assuming success.
    if proc.returncode != 0:
        output = stdout or ""
        tail = output.strip().splitlines()[-5:]
        detail = " ".join(tail).strip()
        # BUG-MSO-2026-0675 F3 (third attempt at this gap — BUG-MSO-2026-0662
        # F2, then BUG-MSO-2026-0670 F2): `cmd_cleanup` does NOT escalate its
        # exit code on an auto-backup failure — it still ends with
        # `sys.exit(result.returncode)`, which is fleet_runner's own Step 1
        # returncode alone (cli.py:cmd_cleanup). So a non-zero exit here
        # means Step 1 itself failed; it says nothing about whether the
        # auto-backup afterwards also failed. When BOTH happen — a real
        # Step-1 failure AND a lost restore point — this Run path is the one
        # place that only surfaces captured output on a NON-zero exit, so
        # without this branch the operator got the same generic "nothing was
        # cleared" text either way, with no mention the restore point was
        # ALSO lost. Detected by the exact verbatim marker `cmd_cleanup`
        # prints on this path (`AUTO-BACKUP-FAILED` — see cli.py:cmd_cleanup),
        # not by re-deriving it from the exit code alone (a plain `1` is
        # ambiguous between this case and any other single-digit failure).
        # The previous case-sensitive match on "Auto-backup failed" could
        # never fire: this same PR renamed the marker to `AUTO-BACKUP-FAILED`.
        if "AUTO-BACKUP-FAILED" in output:
            message = (
                f"Cleanup exited {proc.returncode} — nothing was cleared — "
                "AND the auto-backup failed, so NO restore point was created."
            )
            if detail:
                message += f" {detail}"
            return RunOutcome(ok=False, message=message)
        message = f"Cleanup exited {proc.returncode} — nothing was cleared."
        if detail:
            message += f" {detail}"
        return RunOutcome(ok=False, message=message)
    # BUG-MSO-2026-0662 F2: a zero exit here only proves fleet_runner's own
    # `--cleanup` step succeeded — cmd_cleanup deliberately still exits on
    # THAT returncode even when its own auto-backup step (run afterwards)
    # raised. Before this, a Run click that killed rogue processes but lost
    # the restore point was reported with the exact same "ran, stale state
    # cleared" success message as a run that also backed up cleanly — the
    # operator had no way to tell a restore point was lost short of reading
    # this process's own stdout, which the Hub never surfaces on a zero
    # exit. Scan for cli.py's verbatim AUTO-BACKUP-FAILED marker and report
    # it plainly rather than silently dropping it.
    if "AUTO-BACKUP-FAILED" in (stdout or ""):
        backup_line = next(
            (line.strip() for line in (stdout or "").splitlines() if "AUTO-BACKUP-FAILED" in line),
            "AUTO-BACKUP-FAILED",
        )
        return RunOutcome(
            ok=True,
            message=(
                "Cleanup ran — rogue processes killed, stale state cleared. "
                f"WARNING: the auto-backup failed — no restore point was created. {backup_line}"
            ),
        )
    # BUG-MSO-2026-0670 F2: `backup()` returning None (workspace over
    # backup.BACKUP_MAX_FILES) is a DIFFERENT exit path from the exception
    # above — cli.py's cmd_cleanup prints "Auto-backup skipped (workspace too
    # large — use 'mso backup' manually)" and still exits 0, since skipping is
    # not itself an error. That path survived BUG-0662 F2 untouched: it isn't
    # an exception (nothing raised) and it isn't the AUTO-BACKUP-FAILED
    # marker (that string is only ever printed from the except branch), so it
    # fell through to the same unqualified "Cleanup ran — ... stale state
    # cleared" success message as a run that actually took a restore point.
    # Same honesty gap BUG-0662 F2 set out to close, surviving through a
    # second, distinct exit path — detect this marker too.
    if "Auto-backup skipped" in (stdout or ""):
        skip_line = next(
            (line.strip() for line in (stdout or "").splitlines() if "Auto-backup skipped" in line),
            "Auto-backup skipped",
        )
        return RunOutcome(
            ok=True,
            message=(
                "Cleanup ran — rogue processes killed, stale state cleared. "
                f"WARNING: no restore point was taken — {skip_line}"
            ),
        )
    return RunOutcome(ok=True, message="Cleanup ran — rogue processes killed, stale state cleared.")


def _handle_pr_merge_unreachable(args: dict, mso: Path, product_repo: Optional[Path]) -> RunOutcome:
    raise RuntimeError(
        "pr.merge executed via the Run path — this must be unreachable; the "
        "must_not ceiling failed to refuse it."
    )


# ---------------------------------------------------------------------------
# The closed list.
# ---------------------------------------------------------------------------

_VERBS: "tuple[VerbSpec, ...]" = (
    VerbSpec(
        id="order.retry",
        pattern=re.compile(rf"^mso order retry ({_ORDER_ID})$"),
        handler=_handle_order_retry,
        arg_names=("order_id",),
        description=(
            "mso order retry <ID> — reopen a stranded/terminal order. Emitted by "
            "voyages.stalled-order-deadlock, voyages.deadlocked (BUG-MSO-2026-0699) "
            "and (conditionally) dispatcher.scan-disagreement. Note "
            "voyages.deadlocked emits `mso order unskip <ID>` instead when the "
            "blocker is an operator-skipped order — deliberately NOT on this "
            "closed list, so that one is shown but never one-click runnable."
        ),
    ),
    VerbSpec(
        id="voyage.reconcile",
        pattern=re.compile(r"^mso voyage reconcile$"),
        handler=_handle_voyage_reconcile,
        description=(
            "mso voyage reconcile — archive merged voyages. Emitted by "
            "voyages.merged-not-archived."
        ),
    ),
    VerbSpec(
        id="dispatcher.cleanup",
        pattern=re.compile(r"^mso cleanup$"),
        handler=_handle_dispatcher_cleanup,
        description=(
            "mso cleanup — kill rogue processes, clear stale state (with its "
            "own auto-backup; see BUG-MSO-2026-0643 F1). Emitted by "
            "dispatcher.heartbeat, crews.all-crashed and (conditionally) "
            "dispatcher.scan-disagreement."
        ),
    ),
    # Structural safety-net entry — see module docstring. Never emitted by any
    # patrol check; exists so the must_not ceiling is provably reachable
    # through this path, not merely reused in principle.
    VerbSpec(
        id="pr.merge",
        pattern=re.compile(rf"^mso pr merge ({_ORDER_ID})$"),
        handler=_handle_pr_merge_unreachable,
        arg_names=("voyage_id",),
        must_not_keyword="auto-merge",
        description=(
            "STRUCTURAL SAFETY-NET ENTRY — unreachable in production (no check "
            "emits this command). Proves the must_not ceiling refuses a "
            "mapped verb identically to the autonomous LEAD's own pr.merge "
            "entry in maestro.lead.bands."
        ),
    ),
)


@dataclass(frozen=True)
class VerbMatch:
    spec: VerbSpec
    args: dict


def parse_verb(command: Optional[str]) -> Optional[VerbMatch]:
    """Parse *command* into a known, runnable verb — or ``None``.

    The closed list IS the security boundary: a command that does not
    exactly match one of ``_VERBS``'s patterns is never runnable, regardless
    of how plausible it looks. There is no fallback execution path for an
    unmatched command.
    """
    # BUG-MSO-2026-0634 F8: a non-string suggestedCommand (a check bug, or a
    # future check returning something unexpected) must degrade to "not
    # runnable" here, not raise — this is the FIRST line of defence; the
    # caller (aggregator._lead_findings_from_state) also degrades per-finding
    # rather than trusting this alone.
    if not command or not isinstance(command, str):
        return None
    text = command.strip()
    for spec in _VERBS:
        m = spec.pattern.match(text)
        if m:
            return VerbMatch(spec=spec, args=dict(zip(spec.arg_names, m.groups())))
    return None


def is_runnable(command: Optional[str]) -> bool:
    return parse_verb(command) is not None


def verb_id_for(command: Optional[str]) -> Optional[str]:
    match = parse_verb(command)
    return match.spec.id if match else None


def is_forbidden(spec: VerbSpec, workspace: Optional[Path]) -> bool:
    """D6 ``must_not`` ceiling for a human-clicked Run.

    Delegates to ``maestro.lead.bands.is_forbidden_by_must_not`` — the exact
    function the autonomous LEAD's ``execute_action()`` calls — so a verb
    mapped to a ``LEAD.md`` ``must_not`` item is refused identically here,
    for a human clicking Run in the Hub, as it is for the daemon (order AC).
    Wraps *spec* in a throwaway ``bands.ActionSpec`` purely to reuse that
    function's signature; ``func``/``default_band`` are never consulted by
    it (only ``must_not_keyword`` is read).
    """
    action_spec = ActionSpec(
        id=spec.id,
        func=lambda ctx: "",
        default_band=Band.OBSERVE,
        must_not_keyword=spec.must_not_keyword,
        description=spec.description,
    )
    return is_forbidden_by_must_not(action_spec, workspace)
