# Orders and Voyages

Orders and voyages are how you define and organise work in Maestro.

- An **order** is a discrete unit of work assigned to a single role.
- A **voyage** is a collection of related orders — the equivalent of a sprint or a feature release.

---

## Contents

- [Orders](#orders)
  - [Order Format](#order-format)
  - [Order ID Convention](#order-id-convention)
  - [Roles Are Not Order Types](#roles-are-not-order-types)
  - [Order Types](#order-types)
  - [Order Lifecycle](#order-lifecycle)
  - [Creating an Order](#creating-an-order)
  - [Dependencies](#dependencies)
- [Voyages](#voyages)
  - [Voyage Format](#voyage-format)
  - [Voyage ID Convention](#voyage-id-convention)
  - [Voyage Lifecycle](#voyage-lifecycle)
  - [Archiving a Voyage After Its PR Merges](#archiving-a-voyage-after-its-pr-merges)
  - [Creating a Voyage](#creating-a-voyage)
- [Queue Tiers](#queue-tiers)
- [Escalations](#escalations)
- [Checking Status](#checking-status)

---

## Orders

### Order Format

An order is a JSON file. Here is the full format:

```json
{
  "orderId": "FTR-MYPROJ-2026-0001",
  "project": "MYPROJ",
  "type": "FTR",
  "role": "BLD",
  "roleSequence": ["PLN", "BLD", "TST", "DOC", "SEC", "REL"],
  "title": "Add user authentication",
  "description": "Implement JWT-based login and registration. Use the existing User model in src/Models/User.cs. Endpoints: POST /auth/login returns a JWT; POST /auth/register creates a user. Return 401 on invalid credentials.",
  "acceptanceCriteria": [
    "POST /auth/login returns 200 with a valid JWT on correct credentials",
    "POST /auth/register creates user and returns 201",
    "Invalid credentials return 401 with a clear error message",
    "No changes to the User model schema"
  ],
  "dependsOn": [],
  "voyageId": "VOY-MYPROJ-2026-0001",
  "targetFiles": [
    "my-project/src/Controllers/AuthController.cs",
    "my-project/src/Services/AuthService.cs"
  ],
  "status": "QUEUED",
  "maxIterations": 25
}
```

**Field reference:**

| Field | Required | Type | Description |
|-------|----------|------|-------------|
| `orderId` | Yes | string | Unique ID following the naming convention below. |
| `project` | Yes | string | Project acronym matching your `projects.json` registration. |
| `type` | Yes | string | Order type code (FTR, BUG, DOC, INT, SEC, etc.). |
| `role` | Yes | string | The role that starts this order. One of `PLN`, `BLD`, `TST`, `DOC`, `SEC`, `REL`, `LEAD` (legacy nautical spellings `NAV`, `SHP`, `BOS`, `SCR`, `LKT`, `COX`, `QM` are still accepted). Also spelled `targetRole`. **Not an order type** — see [Roles Are Not Order Types](#roles-are-not-order-types). |
| `roleSequence` | No | array of strings | The roles this order passes through, in order. Same vocabulary as `role`. Omit it to get the default for the order's type (below). |
| `title` | Yes | string | Short human-readable title. |
| `description` | Yes | string | Full description of the work. Be specific — this is the crew's primary instruction. |
| `acceptanceCriteria` | Yes | array of strings | What "done" looks like. Used by crews to verify their output. |
| `dependsOn` | No | array of strings | Order IDs that must reach `COMPLETE` before this order dispatches. |
| `voyageId` | No | string | The voyage this order belongs to. |
| `targetFiles` | No | array of strings | Suggested files the crew should focus on. |
| `status` | Yes | string | Initial status. Always set to `"QUEUED"` when creating. |
| `maxIterations` | No | integer | Override the default 25 iteration limit for this order. |

### Order ID Convention

```
{TYPE}-{PROJECT}-{YEAR}-{SEQUENCE}
```

Examples:
- `FTR-MYPROJ-2026-0001` — first feature order for MYPROJ in 2026
- `BUG-MYPROJ-2026-0015` — fifteenth bug order
- `DOC-MYPROJ-2026-0003` — third documentation order

Keep sequences zero-padded to four digits.

### Roles Are Not Order Types

This is the single most common way to file an order that cannot run.

**Roles** are who does the work. There are exactly seven:

| Canonical | Legacy nautical | Does |
|-----------|-----------------|------|
| `PLN` | `NAV` | Planning, architecture, investigation |
| `BLD` | `SHP` | Implementation |
| `TST` | `BOS` | Testing, QA |
| `DOC` | `SCR` | Documentation |
| `SEC` | `LKT` | Security review |
| `REL` | `COX` | Integration, release |
| `LEAD` | `QM` | Interactive partner |

**Order types** are what kind of work it is — `FTR`, `BUG`, `SEC`, `INV`, `PLN`,
`DOC` and whatever else your process pack defines. Three of those (`SEC`, `PLN`,
`DOC`) are spelled the same as a role, and `INV` is spelled like neither, which
is exactly why the two get mixed up.

Putting an order type in `role`/`targetRole`/`roleSequence` does not work, and
since BUG-MSO-2026-0714 it does not silently half-work either:

- `mso bug` and `mso order retry --role ...` **refuse** the order outright, naming
  the bad value and the valid set.
- A dispatcher scanning the queue marks such an order **`INVALID`** on disk, logs
  an `ORDER_INVALID` lifecycle event naming the bad value and the valid set, and
  never dispatches it. `INVALID` is not `PENDING`, so fixing the roles alone is
  not enough — correct them, then `mso order retry <ORDER-ID> --role <ROLE>` (or
  set `status` back to `PENDING` by hand) to put it back in rotation.
- `mso doctor`'s **`orders.invalid-role`** check reports it whether or not a
  dispatcher is running.

#### Default `roleSequence` per order type

Omit `roleSequence` and the order gets the default for its type. These come from
the built-in `sdlc` process pack (`maestro/packs/sdlc/pack.json`); a workspace
template under `orders/templates/` overrides them per type.

| Order type | Default `roleSequence` |
|------------|------------------------|
| `FTR` | `["PLN", "BLD", "TST", "DOC", "SEC", "REL"]` |
| `BUG` | `["PLN", "BLD", "TST", "REL"]` |
| `SEC` | `["SEC", "BLD", "TST", "REL"]` |
| `INV` | `["PLN"]` |
| `PLN` | `["PLN"]` |
| `DOC` | `["DOC"]` |

**`INV` runs at `PLN`.** An investigation is planner work — it is a single-role
order whose deliverable is a report under `reports/investigation/` rather than a
plan document. There is no "INV role" to route it to. (Filing an `INV` order with
`roleSequence: ["INV", ...]` is the exact mistake this section exists to prevent.)

### Order Types

| Type | Description |
|------|-------------|
| `FTR` | New feature |
| `BUG` | Bug fix |
| `DOC` | Documentation |
| `INT` | Integration or deployment |
| `SEC` | Security fix or audit |
| `QA` | Quality assurance / test coverage |
| `REF` | Refactoring |

You can use any type code that is meaningful to your project — the dispatcher does not validate type codes against an enumeration.

### Order Lifecycle

Orders move through these states:

```
QUEUED  →  ACTIVE  →  COMPLETE
                  ↘  FAILED
```

| State | Location | Description |
|-------|---------|-------------|
| `QUEUED` | `.maestro/queues/{tier}/` | Awaiting dispatch. |
| `ACTIVE` | `.maestro/orders/active/` | Currently being worked by a crew. |
| `COMPLETE` | `.maestro/orders/complete/` | Crew signalled completion and order was verified. |
| `FAILED` | `.maestro/orders/failed/` | Crew failed or timed out. |

The dispatcher moves files between these directories automatically. You should not move them manually while a dispatch session is running.

### Creating an Order

1. Write the order JSON using the format above.
2. Save it to the appropriate queue directory (usually `.maestro/queues/orders/`).
3. Run `mso dispatch` — the Fleet Admiral will pick it up.

**Example:**

```bash
# Create the order file
cat > .maestro/queues/orders/FTR-MYPROJ-2026-0001.json << 'EOF'
{
  "orderId": "FTR-MYPROJ-2026-0001",
  "project": "MYPROJ",
  "type": "FTR",
  "role": "BLD",
  "title": "Add CSV export endpoint",
  "description": "Add GET /api/reports/export that returns the current report data as a CSV file. Use the existing ReportService to fetch data. Set Content-Disposition: attachment; filename=report.csv.",
  "acceptanceCriteria": [
    "GET /api/reports/export returns a valid CSV with correct column headers",
    "Response has Content-Type: text/csv and Content-Disposition: attachment",
    "Empty result set returns a CSV with headers only (no 500 error)"
  ],
  "dependsOn": [],
  "voyageId": "VOY-MYPROJ-2026-0002",
  "status": "QUEUED"
}
EOF

# Dispatch
mso dispatch --max-crews 3
```

### Dependencies

Use `dependsOn` to ensure orders run in the right sequence. The dispatcher will not assign an order to a crew until all orders in its `dependsOn` array are `COMPLETE`.

```json
{
  "orderId": "BUG-MYPROJ-2026-0002",
  "dependsOn": ["FTR-MYPROJ-2026-0001"]
}
```

**Common patterns:**

Sequential feature + test:
```json
// SHP order
{ "orderId": "FTR-MYPROJ-2026-0005", "role": "SHP", "dependsOn": [] }

// BOS order waits for SHP
{ "orderId": "FTR-MYPROJ-2026-0006", "role": "BOS", "dependsOn": ["FTR-MYPROJ-2026-0005"] }
```

Plan-first workflow:
```json
// NAV plans first
{ "orderId": "FTR-MYPROJ-2026-0010", "role": "NAV", "dependsOn": [] }

// SHP waits for the plan
{ "orderId": "FTR-MYPROJ-2026-0011", "role": "SHP", "dependsOn": ["FTR-MYPROJ-2026-0010"] }
```

---

## Voyages

### Voyage Format

```json
{
  "voyageId": "VOY-MYPROJ-2026-0001",
  "project": "MYPROJ",
  "title": "Authentication feature",
  "description": "Implement login, registration, and JWT token management.",
  "orders": [
    "FTR-MYPROJ-2026-0001",
    "FTR-MYPROJ-2026-0002",
    "FTR-MYPROJ-2026-0003"
  ],
  "branch": "voyage/VOY-MYPROJ-2026-0001",
  "status": "ACTIVE",
  "createdAt": "2026-03-30"
}
```

**Field reference:**

| Field | Required | Type | Description |
|-------|----------|------|-------------|
| `voyageId` | Yes | string | Unique ID following the naming convention. |
| `project` | Yes | string | Project acronym. |
| `title` | Yes | string | Short description of the voyage goal. |
| `description` | No | string | Full description of the voyage scope. |
| `orders` | Yes | array of strings | All order IDs that belong to this voyage. |
| `branch` | No | string | The git branch crews commit to during this voyage. |
| `status` | Yes | string | `ACTIVE` or `COMPLETE`. |
| `createdAt` | No | string | ISO date string. |

### Voyage ID Convention

```
VOY-{PROJECT}-{YEAR}-{SEQUENCE}
```

Examples:
- `VOY-MYPROJ-2026-0001`
- `VOY-MYPROJ-2026-0002`

### Voyage Lifecycle

```
ACTIVE  →  COMPLETE
```

| State | Location |
|-------|---------|
| `ACTIVE` | `.maestro/voyages/active/` |
| `COMPLETE` | `.maestro/voyages/complete/` |

A voyage is complete when all its orders have reached `COMPLETE`. You can run `mso verify` to confirm the build and tests pass before marking the voyage complete.

### Archiving a Voyage After Its PR Merges

Moving a voyage from `active/` to `complete/` is **pull-based housekeeping**, not
something Maestro detects on its own. In practice you review and merge the voyage
PR yourself, often after the dispatcher has exited — so Maestro never observes the
merge, and the voyage stays in `active/` until something asks.

Trigger it either way:

```bash
mso voyage reconcile --dry-run   # preview
mso voyage reconcile             # apply
```

or click the broom button in the [Maestro Hub](HUB.md#housekeeping-sweep). Both
run the same implementation. It also runs automatically at dispatcher startup when
`completion.onVoyageComplete.archiveVoyageOnMerge` is enabled.

**Merge state comes from the pull request, not from commit history.** When a
voyage records a `prNumber`, Maestro reads that PR's `merged` field, which is
blind to merge strategy — squash, rebase and merge-commit all resolve correctly. A
squash merge in particular lands one *new* commit on the base branch, so the
voyage branch's own commits never become ancestors of the base; anything reasoning
from commit ancestry would call such a voyage unmerged forever. Raw-git detection
remains the fallback for voyages with no PR and for offline operation, and an
undeterminable state stays *unknown* — reconcile leaves the voyage alone rather
than assuming a merge.

The archived voyage manifest records the outcome:

| Field | Meaning |
|-------|---------|
| `mergedAt` | Merge timestamp from the PR record. |
| `mergedPR` | PR number. |
| `mergeDetectedBy` | Which path decided — `"pr"` or `"git"`. |

Full flag and report reference:
[`mso voyage reconcile`](CLI-REFERENCE.md#mso-voyage-reconcile).

### Creating a Voyage

1. Create the voyage JSON and save it to `.maestro/voyages/active/`.
2. Create all associated orders and save them to the appropriate queues.
3. Dispatch the fleet.

**Tip:** Create orders and voyages in a batch before dispatching. The dispatcher handles ordering and dependency resolution automatically.

---

## Dispatch order

When a crew slot frees up, the dispatcher picks the next order using two
things: the **queue directory** the order sits in (its *tier*), and the
order's **`priority`** field. The rule, in full:

1. **`critical` overrides the tier.** An order with `"priority": "critical"`
   dispatches before every non-critical order in *every* queue — a `critical`
   order in `queues/orders/` goes ahead of a `high` bug in `queues/bugs/`.
   This is the one lever that jumps the whole board.
2. **Among orders of the same urgency, the queue tier decides** (table below).
   That applies inside the critical band too: a `critical` security item goes
   before a `critical` high-level one.
3. **Within a tier, `high` beats `medium`/`normal` beats `low`.**

Priority is matched case-insensitively — `critical`, `Critical` and `CRITICAL`
are the same value. An absent or unrecognised priority is treated as `medium`.

`mso status`'s QUEUE block prints the next three orders in this exact order,
each annotated with its queue, tier and priority, so you can see what a free
slot will really pick up rather than inferring it.

### Queue Tiers

Place an order in a specific queue directory to set its tier.

| Directory | Tier | Use For |
|-----------|------|---------|
| `queues/explicit/` | Highest | Emergency or manually-forced dispatch |
| `queues/security/` | High | Security vulnerabilities and fixes |
| `queues/bugs/` | High | Bug fixes |
| `queues/requests/` | Medium-High | Crew-generated requests for follow-on work |
| `queues/orders/` | Medium | Normal feature work (default) |
| `queues/defects/` | Medium-Low | Defects identified in QA |
| `queues/breakdown/` | Low | Sub-tasks broken down from higher-level orders |
| `queues/high-level/` | Lowest | NAV planning tasks and high-level requirements |
| `queues/escalations/` | Not dispatched | Requires Captain/QM review before proceeding |

For most orders, `queues/orders/` is the right choice. To jump the queue, set
`priority` to `critical` — you do not need to move the file.

---

## Escalations

A crew that encounters a blocking issue it cannot resolve will write an escalation to `.maestro/queues/escalations/`. Escalations with `"blocking": true` halt all subsequent orders in the same voyage until the Captain or Quartermaster resolves them.

**To resolve an escalation:**

1. Read the escalation JSON in `.maestro/queues/escalations/`
2. Investigate the issue described
3. Set `"status": "RESOLVED"` and add a `"resolution"` string explaining what to do
4. Save the file — the dispatcher will unblock the voyage automatically on the next run

```json
{
  "escalationId": "ESC-MYPROJ-2026-0001",
  "orderId": "FTR-MYPROJ-2026-0005",
  "blocking": true,
  "issue": "Cannot find the User model at the path specified in the order. src/Models/User.cs does not exist.",
  "status": "RESOLVED",
  "resolution": "User model is at src/Domain/User.cs — update targetFiles in the order and re-queue."
}
```

---

## Checking Status

**Fleet-wide status:**
```bash
mso status --once
```

**Token usage per voyage:**
```bash
mso usage --voyage VOY-MYPROJ-2026-0001
```

**View completed orders:**
```bash
ls .maestro/orders/complete/
```

**View failed orders:**
```bash
ls .maestro/orders/failed/
```

**View an individual crew's progress:**
```bash
cat .maestro/crews/crew1/progress.md
```

---

*Maestro Maestro v2.0.0 — For licensing enquiries, contact [tavisbasing](https://github.com/tavisbasing).*
