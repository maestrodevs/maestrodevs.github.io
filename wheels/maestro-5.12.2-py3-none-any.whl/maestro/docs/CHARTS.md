# Maestro Charts

A chart is a graph view of a voyage's work — which order/role pairs exist and
how they connect. **Viewing** a chart is free, on every tier, always available.
**Authoring** a chart that changes how the dispatcher routes work is a
licensed, opt-in feature.

There are two layers:

- **X-ray (Phase 1)** — `mso chart show`, read-only. Renders the graph your
  voyage already implies from its orders' `roleSequence` and `dependsOn`
  fields. Changes nothing, requires no configuration, works at every tier
  including unlicensed community.
- **Authoring & routing (Phase 2, this doc)** — a hand-authored chart file
  that can add typed **failure routing** (e.g. "if Tester rejects, send the
  work back to Builder instead of parking it for a human") and **bounded
  revision cycles** on top of the ordinary role sequence. Off by default,
  and gated at the Pro tier and above once you turn it on.

## Viewing a chart

```bash
mso chart show VOY-MSO-2026-0144
mso chart show VOY-MSO-2026-0144 --format mermaid
mso chart show FTR-MSO-2026-0496 --format json
```

Works on any voyage or any single order, at every licence tier, including
unlicensed community. This never requires a chart file — it always renders
the graph the voyage's own orders already imply.

## Authoring a chart

Requires **Pro, Team, or Enterprise**. Community and unlicensed installs can
still view charts (above) and validate a hand-edited chart file (below), but
cannot generate or execute one.

```bash
mso chart new --from-voyage VOY-MSO-2026-0144
```

This compiles the named voyage's existing role sequence into a starting-point
chart file under `.mso/charts/CHT-{PROJECT}-{YEAR}-{SEQ}.json` — every edge
comes out as `onSuccess` (the "degenerate" chart: it says nothing your voyage
wasn't already going to do). You then hand-edit the file to add the routing
you actually want — typically one or two `onFail` edges. `mso chart new`
writes the file even if the result isn't fully valid yet (e.g. a multi-order
voyage whose orders aren't fully connected); it prints the validation issues
it found so you know what's left to fix before enabling the chart.

```bash
mso chart validate .mso/charts/CHT-MSO-2026-0001.json
mso chart validate --all
```

Validates a chart file against the schema rules and exits non-zero on any
error. This is offline and needs no licence at all — check a chart is
well-formed before you rely on it.

### Chart shape

A chart is a set of **nodes** (each one an `order` + `role` pair — the same
identity a voyage's own role sequence already uses) connected by **edges**:

```json
{
  "chartId": "CHT-MSO-2026-0001",
  "schemaVersion": 1,
  "voyageId": "VOY-MSO-2026-0150",
  "title": "build-verify-revise",
  "status": "ACTIVE",
  "nodes": {
    "build": {"order": "FTR-MSO-2026-0601", "role": "BLD"},
    "test":  {"order": "FTR-MSO-2026-0601", "role": "TST"},
    "docs":  {"order": "FTR-MSO-2026-0601", "role": "DOC"}
  },
  "edges": [
    {"from": "build", "to": "test", "type": "onSuccess"},
    {"from": "test",  "to": "docs", "type": "onSuccess"},
    {"from": "test",  "to": "build", "type": "onFail",
     "cause": "VERDICT_FAIL", "maxLaps": 2, "carry": "qaReport",
     "onExhausted": "humanGate"}
  ]
}
```

- `onSuccess` edges describe the ordinary path — the chart's version of a
  role sequence.
- `onFail` edges are the new thing: they fire on a specific kind of failure
  and reroute the order instead of falling through to the default hold. Two
  failure signals exist: a local build/verify check failing
  (`"cause": "VERIFY_FAILED"`), and a role explicitly rejecting the work
  (`"cause": "VERDICT_FAIL"` — set when a Tester or Security reviewer signs
  off with a REJECTED decision). Omit `cause` (or use `"ANY"`) to match
  either.
- An `onFail` edge can also route straight to a fixed outcome instead of
  another node — `"to": "@humanGate"` pauses the order for you to review
  (same mechanism as [Human Review Gates](HUMAN-REVIEW-GATES.md)); `"to":
  "@stalled"` archives it as needing attention. Neither of those consumes a
  lap.

Only nodes and edges your chart lists are affected. Everything else about
the voyage — its other orders, the roles a chart doesn't mention — dispatches
exactly as it always has.

### Bounded revision cycles (`maxLaps`)

Any `onFail` edge that creates a loop (e.g. Tester routes back to Builder,
which will eventually reach Tester again) **must** declare `maxLaps`, an
integer from 1 to 5. Each trip around that edge is a "lap." Once an edge has
lapped `maxLaps` times for a given order, the next failure on it is treated
as **exhausted** instead of routed again:

- `"onExhausted": "humanGate"` (the default) — pauses the order for your
  review, same as `mso review queue`/`approve`/`revise`/`reject` already
  handles.
- `"onExhausted": "stalled"` — archives the order as needing attention,
  the same outcome an unrecoverable crew failure produces today.

A chart can never retry forever by accident — every cycle has a ceiling, and
running out of laps always surfaces to a human rather than looping silently.
Lap counts are tracked durably (they survive a `git reset`/branch rewind the
same way completed-order state already does) so the budget can't be reset by
accident.

### Carrying context into the next lap (`carry`)

An `onFail` edge that reroutes an order (not a direct `@humanGate`/`@stalled`
route) can attach evidence from the failure to the prompt the next crew
receives, via `"carry"`:

| `carry` value | What gets attached |
|---|---|
| `verifyLog` | The failing build/verify command's full output |
| `qaReport` | The rejecting role's QA/security report |
| `handoff` | The handoff document the failing role wrote |
| `none` (default) | Nothing |

The carried content is embedded directly into the next crew's prompt (not
just referenced by path), under a "Carried Context" section — so, for
example, a Builder that gets work routed back to it because Tester rejected
it actually sees why, without having to go dig up the QA report itself.

**If the artefact a `carry` value points at no longer exists on disk** (a
report got overwritten, a log was cleaned up), the lap still proceeds — it
just carries nothing rather than fabricating a substitute or attaching a
truncated fragment. This is intentional: a crew that believes it has evidence
it doesn't have is worse off than one that knows it has none. Look for a
`CARRY_DEGRADED` entry in `.mso/logs/lifecycle.log` if a carry you expected
didn't show up.

## Turning it on: `charts.enabled`

Everything above this section works with the flag off — authoring and
validating a chart file doesn't require enabling anything. The flag only
controls whether the dispatcher actually **acts** on a chart's routing.

```json
{
  "charts": {
    "enabled": false
  }
}
```

in `.mso/config/workspace.json`. **Default is `false`.** Omitting the
`charts` block entirely is identical to `{"enabled": false}` — a workspace
with no chart files and no `charts` block behaves exactly as it did before
this feature existed.

Flipping it to `true` also requires a **Pro, Team, or Enterprise** licence to
actually take effect — below that tier, `charts.enabled: true` behaves
exactly as if it were `false` (nothing crashes; the dispatcher just doesn't
act on the chart). A `CHART_TIER_DENIED` entry appears once in
`.mso/logs/lifecycle.log` if that happens, so you know why nothing is
routing.

### Current status: merged, not finished

As of v5.12.0, Phase 2 is merged and its own equivalence suite proves the flag-off behaviour is
byte-identical to a pre-Phase-2 build, but **do not turn `charts.enabled` on for any real workspace
yet.** An investigation (INV-MSO-2026-0560) concluded that chart routing writes completion state
through paths the single "did a role finish, and how" chokepoint in the dispatcher does not own — a
structural problem, not a bug in the chart model itself. The completion-path audit that followed
(BUG-MSO-2026-0630) confirms it concretely: several of the functions charts routing depends on
(`_apply_lap`, `_release_node`, `release_order_to_pending`) are recorded with honest **FAIL** rows
against the invariants that keep a Tester REJECTED verdict from silently becoming an approval, or a
release from ever going un-ledgered. Those FAIL rows are not hidden — they are the point of the
audit — but they mean the feature is not yet safe to run live. It becomes finishable once a
dedicated chokepoint refactor (`resolve_completion_outcome` / `apply_outcome`) lands; that work has
not started. Watch for it before flipping this flag anywhere but a disposable test workspace.

## What changes once a chart is active

With `charts.enabled: true` and an `ACTIVE` chart present for a voyage:

- Nodes become eligible to dispatch (`PENDING`, at the right role) once their
  `onSuccess` predecessors are done — same as today's ordinary role-sequence
  advance, just driven by the chart's graph instead of (or alongside) the
  order's own `roleSequence`.
- A matching `onFail` edge reroutes a failure instead of the ordinary
  hold-for-a-human outcome — the headline case this feature exists for is a
  Tester's REJECTED verdict routing straight back to the Builder, bounded by
  `maxLaps`, with the QA report carried into the retry's prompt.
- Every other safeguard still applies to whatever a chart releases or
  reroutes — dependency checks, the review gate, per-role tool scoping, the
  build/verify gate, and everything else the dispatcher already enforces.
  A chart can change *when* and *where* an order goes next; it cannot skip
  any of the checks that already run once it gets there.

## Turning `charts.enabled` off mid-voyage

Nothing is rolled back:

- The chart stops releasing new nodes and stops rerouting failures.
- Any order the chart already released keeps going — it's sitting at an
  ordinary `PENDING`/role state, so it dispatches, advances, and completes
  through the normal pipeline exactly as if the chart had never been
  involved.
- Crews already running are untouched.
- A `CHART_DISABLED` entry appears once in `.mso/logs/lifecycle.log` the
  moment the flag flips off with an active chart present, so the transition
  is visible rather than something you have to infer.

The voyage always finishes even if you turn charts off partway through it.

## If a chart points at an order that's gone

Orders occasionally get skipped or removed from a voyage after a chart was
written against them. If a chart node's order can't be resolved (skipped,
removed, or the role isn't actually in that order's sequence), that node is
treated as a permanent dead end — it never satisfies anything downstream of
it, but it also never blocks any other branch of the chart. A
`CHART_NODE_UNRESOLVED` entry appears once per affected node in
`.mso/logs/lifecycle.log`.

There's no special "chart incomplete" status to look for — an order stuck
behind an unresolved chart node simply never reaches its own completion, and
the voyage's existing completion check (the same one that already withholds
"all done" for any order that hasn't genuinely finished) accounts for it. If
a voyage with a chart isn't finishing, check `.mso/logs/lifecycle.log` for
`CHART_NODE_UNRESOLVED` before assuming something else is wrong.

## Lifecycle events to watch

All in `.mso/logs/lifecycle.log`:

| Event | Meaning |
|---|---|
| `LAPPED` | An `onFail` edge routed an order forward for another attempt. |
| `LAP_EXHAUSTED` | An `onFail` edge hit its `maxLaps` ceiling; `onExhausted` applied. |
| `CHART_DISABLED` | `charts.enabled` flipped off with an active chart still present. |
| `CHART_NODE_UNRESOLVED` | A chart node's order/role couldn't be found — treated as a dead end. |
| `CHART_TIER_DENIED` | `charts.enabled` is true but the licence tier is below Pro — behaves as if off. |
| `CARRY_DEGRADED` | A `carry` edge's target artefact was missing — the lap proceeded without it. |

## See also

- [Human Review Gates](HUMAN-REVIEW-GATES.md) — the `humanGate` outcome a
  chart's `onExhausted`/sink routing reuses.
- [LICENCE.md](LICENCE.md) — the full tier table.
- [CLI-REFERENCE.md](CLI-REFERENCE.md) — general command reference.
