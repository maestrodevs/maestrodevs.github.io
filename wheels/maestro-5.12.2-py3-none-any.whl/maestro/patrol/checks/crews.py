"""maestro/patrol/checks/crews.py — crew-slot dispatchability.

PLAN-PLN-MSO-2026-0504 §4.2: five crashed crew slots plus six dispatchable
orders is pure threshold logic over ``crews/crew{N}/state.json`` — nothing
said so on 2026-08-17. Auto-remediation (running `mso cleanup` automatically)
is Captain decision D3 (deferred, "never — propose only" for v1); this check
only detects and suggests.
"""

from __future__ import annotations

from pathlib import Path

from maestro.core.fleet_monitor import get_settings, is_process_alive, load_json_safe
from maestro.patrol.registry import CheckContext, Finding, check


def _effective_crew_status(crews_dir: Path, slot: int) -> str:
    """Read-only mirror of fleet_monitor's orphan-repair read (BUG-MSO-2026-0403):
    a crew recorded RUNNING/ACTIVE with a dead PID is effectively CRASHED,
    without writing that back to disk. A check never mutates state — see
    ``maestro.patrol.registry`` — so this recomputes the same verdict
    in-memory rather than calling ``fleet_monitor.cleanup_orphaned_crew``.
    """
    state = load_json_safe(crews_dir / f"crew{slot}" / "state.json")
    if not state:
        return "IDLE"
    status = str(state.get("status") or "UNKNOWN").upper()
    pid = state.get("pid")
    if status in ("RUNNING", "ACTIVE") and pid and not is_process_alive(pid):
        return "CRASHED"
    return status


@check(id="crews.all-crashed", severity="critical")
def crews_all_crashed(context: CheckContext) -> "list[Finding]":
    settings = get_settings(context.artefact_root)
    max_crews = settings.get("maxCrews", 5)
    crews_dir = context.artefact_root / "crews"

    statuses = [_effective_crew_status(crews_dir, slot) for slot in range(1, max_crews + 1)]
    if not statuses or not all(s == "CRASHED" for s in statuses):
        return []

    return [
        Finding(
            check_id="crews.all-crashed",
            subject_id="crews:all",
            severity="critical",
            title="All crew slots are crashed",
            detail=(
                f"All {max_crews} configured crew slot(s) are CRASHED — the dispatcher "
                "cannot launch any new work until the slots are cleared, regardless of "
                "how many orders are dispatchable."
            ),
            firstSeenAt=context.now.isoformat(),
            # BUG-MSO-2026-0691 F5: "all crew slots crashed but nothing
            # self-recovers" is precisely the situation where the dispatcher
            # process is still alive (a dead dispatcher's crews would have
            # been reset already, on next startup) -- so a bare `mso cleanup`
            # hits the BUG-MSO-2026-0673 F1 live-dispatcher refusal every
            # time this finding fires. `--force` is the escape hatch: it
            # runs the crew-state reset this finding needs while leaving the
            # dispatcher process itself alone, matching the `dispatcher.
            # heartbeat` / `dispatcher.scan-disagreement` siblings' fix.
            suggestedCommand="mso cleanup --force",
            scope="workspace",
            requires=(),
        )
    ]
