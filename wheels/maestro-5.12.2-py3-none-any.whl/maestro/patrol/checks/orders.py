"""maestro/patrol/checks/orders.py — order-level hygiene.

PLAN-PLN-MSO-2026-0504 §4 evidence: "an order is waiting on human approval"
is ENGINE work — the collectors already exist
(``fleet_monitor.get_pending_review_items`` for NAV_REVIEW_PENDING orders,
``fleet_monitor.get_approval_items`` for voyage/plan/requirement
AWAITING_APPROVAL artefacts); the gap was notification, not detection (§4.8 —
tracked separately as a dead-import bug, not this check's job). Reused here
rather than re-scanned, matching the same union `build_dashboard_state()`
already renders as one `approvals` list.

Age-based severity escalation and the `ageMinutes` threshold from the shipped
patrol default are noise-control concerns that land with patrol definitions
(plan orders 2/3, which also wire per-check params through `CheckContext`);
this check reports every currently-outstanding item on every run.

FTR-MSO-2026-0535 (plan order 5) adds `orders.dep-satisfied-unreleased` — a
DELIBERATELY THIN regression detector for BUG-MSO-2026-0499 (PROPOSED/HELD
orders whose full `dependsOn` set is archived complete never getting
released back to PENDING). The real fix is
`fleet_runner.promote_ready_dependents()`, called from every completion route
and every dispatcher tick; this check does not call it, does not release
anything, and does not replicate its STALLED-cause nuance in full — it only
re-derives "is every dependency satisfied" from the on-disk archive so a
reintroduction of 0499 is caught even with the dispatcher stopped. It fires
on exactly the DOC-MSO-2026-0484 shape verified live in the plan's evidence
(§4.3): a PROPOSED order with a non-empty `dependsOn`, every entry archived
COMPLETE, sitting untouched past `graceMinutes`.
"""

from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

from maestro.core.fleet_monitor import get_approval_items, get_pending_review_items
from maestro.patrol.registry import CheckContext, Finding, check
from maestro.roles.validation import validate_order_roles


@check(id="orders.awaiting-approval", severity="medium")
def orders_awaiting_approval(context: CheckContext) -> "list[Finding]":
    findings: "list[Finding]" = []

    for item in get_pending_review_items(context.artefact_root):
        order_id = item["order_id"]
        findings.append(
            Finding(
                check_id="orders.awaiting-approval",
                subject_id=order_id,
                severity="medium",
                title=f"{order_id} is waiting on human review",
                detail=(
                    f"Voyage {item['voyage_id']}, paused NAV_REVIEW_PENDING for {item['age']}. "
                    "Resolve with `mso review approve|revise|reject` or the Hub /review page."
                ),
                firstSeenAt=context.now.isoformat(),
                suggestedCommand=f"mso review show {order_id}",
                scope="workspace",
                requires=(),
            )
        )

    for item in get_approval_items(context.artefact_root):
        findings.append(
            Finding(
                check_id="orders.awaiting-approval",
                subject_id=item["id"],
                severity="medium",
                title=f"{item['type']} {item['id']} is awaiting approval",
                detail=(
                    f"{item.get('project', '?')}: {item.get('title') or item['id']} "
                    f"— {item.get('path', '')}"
                ),
                firstSeenAt=context.now.isoformat(),
                suggestedCommand=None,
                scope="workspace",
                requires=(),
            )
        )

    return findings


# ---------------------------------------------------------------------------
# orders.dep-satisfied-unreleased (FTR-MSO-2026-0535 / BUG-MSO-2026-0499)
# ---------------------------------------------------------------------------

# Same live-queue directory set as fleet_runner._ORDER_QUEUE_SUBDIRS /
# _iter_queue_order_files() / promote_ready_dependents() — a thin, independent
# re-listing (this module deliberately has no import dependency on
# fleet_runner) rather than a call into it. Keep in sync if that tuple changes.
_QUEUE_SUBDIRS = (
    "orders", "explicit", "high-level", "bugs", "defects", "security", "breakdown",
)
_RELEASE_GATED_STATUSES = {"PROPOSED", "HELD"}
_DEP_HARD_SATISFYING_STATUSES = {"COMPLETE", "MAX_ITERATIONS"}


def _load_json_safe(path: Path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def _parse_iso(value: object) -> Optional[datetime]:
    if not isinstance(value, str) or not value:
        return None
    try:
        dt = datetime.fromisoformat(value)
    except ValueError:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt


def _iter_queue_files(artefact_root: Path):
    queues_dir = artefact_root / "queues"
    for sub in _QUEUE_SUBDIRS:
        d = queues_dir / sub
        if not d.exists():
            continue
        for f in d.glob("*.json"):
            yield f
    requests_dir = queues_dir / "requests"
    if requests_dir.exists():
        for sub in requests_dir.iterdir():
            if sub.is_dir():
                yield from sub.glob("*.json")


def _dep_status_and_completed_at(artefact_root: Path, dep_id: str) -> "tuple[bool, Optional[datetime]]":
    """``(satisfied, completedAt)`` for one dependency, read from
    ``orders/complete/<dep_id>.json`` only — a dependency that hasn't
    archived at all is trivially unsatisfied. Mirrors
    ``fleet_runner.check_dependencies_satisfied``'s COMPLETE/STALLED rule in
    miniature (no ``fleet_runner`` import — see module docstring); this is
    the "thin" half of "thin regression detector", so a dependency's
    non-ERROR STALLED archive still counts, matching the engine's own
    "partial work exists" allowance.
    """
    data = _load_json_safe(artefact_root / "orders" / "complete" / f"{dep_id}.json")
    if not data:
        return False, None
    status = str(data.get("status") or "").upper()
    if status in _DEP_HARD_SATISFYING_STATUSES:
        satisfied = True
    elif status == "STALLED":
        satisfied = data.get("stalledCause", "MAX_ITERATIONS") != "ERROR"
    else:
        satisfied = False
    return satisfied, _parse_iso(data.get("completedAt"))


@check(id="orders.dep-satisfied-unreleased", severity="high")
def orders_dep_satisfied_unreleased(context: CheckContext) -> "list[Finding]":
    findings: "list[Finding]" = []
    grace = timedelta(minutes=context.params_for("orders.dep-satisfied-unreleased").get("graceMinutes", 15))

    for order_file in _iter_queue_files(context.artefact_root):
        data = _load_json_safe(order_file)
        if not data:
            continue
        status = str(data.get("status") or "").upper()
        if status not in _RELEASE_GATED_STATUSES:
            continue
        deps = data.get("dependsOn") or data.get("dependencies") or []
        if not deps:
            continue  # not dependency-gated — the human plan-review flow owns this, not 0499

        completed_ats: "list[datetime]" = []
        all_satisfied = True
        for dep_id in deps:
            satisfied, completed_at = _dep_status_and_completed_at(context.artefact_root, dep_id)
            if not satisfied:
                all_satisfied = False
                break
            if completed_at is not None:
                completed_ats.append(completed_at)
        if not all_satisfied:
            continue

        if completed_ats and (context.now - max(completed_ats)) < grace:
            # Give promote_ready_dependents() its normal reaction window
            # before treating a still-fresh completion as a stall — avoids a
            # false-positive fired the instant the last dependency archives.
            continue

        order_id = data.get("orderId") or data.get("id") or order_file.stem
        findings.append(
            Finding(
                check_id="orders.dep-satisfied-unreleased",
                subject_id=order_id,
                severity="high",
                title=f"{order_id}: dependencies satisfied but still {status}",
                detail=(
                    f"All of {order_id}'s dependsOn ({', '.join(deps)}) are archived "
                    f"complete, but the order itself is still {status} — nothing has "
                    "released it to PENDING (BUG-MSO-2026-0499). This is a regression "
                    "detector only; the fix is `promote_ready_dependents()` running on "
                    "every completion route and dispatcher tick, not this check."
                ),
                firstSeenAt=context.now.isoformat(),
                suggestedCommand=None,
                scope="workspace",
                requires=(),
            )
        )

    return findings


# ---------------------------------------------------------------------------
# orders.invalid-role (BUG-MSO-2026-0714)
# ---------------------------------------------------------------------------

#: Statuses worth reporting. An order the dispatcher has already refused is
#: INVALID; one nobody has scanned yet is still PENDING/OPEN/PROPOSED/HELD and
#: is exactly what this check exists to catch BEFORE a dispatcher touches it —
#: `mso doctor` works with the dispatcher stopped, which is the whole point.
_ROLE_CHECKED_STATUSES = {
    "PENDING", "OPEN", "PROPOSED", "HELD", "INVALID", "IN_PROGRESS", "QUEUED",
}


@check(id="orders.invalid-role", severity="high")
def orders_invalid_role(context: CheckContext) -> "list[Finding]":
    """Report queued orders whose ``roleSequence``/``targetRole`` names
    something that is not a role.

    BUG-MSO-2026-0713 was filed with ``roleSequence: ["INV", "BLD", "TST"]`` —
    ``INV`` is an order TYPE. Nothing rejected it: the dispatcher selected the
    order, launched ``crew.py --role INV``, argparse exited 2, and the failure
    surfaced as "returned no PID" and then as advice to check the installed
    package's integrity. The package was fine.

    ``fleet_runner.scan_all_queues()`` is now the enforcing gate (it marks such
    an order INVALID and never dispatches it). This check is the OFF-PROCESS
    half: it finds the same orders with no dispatcher running, which is when a
    human is most likely to be looking, and it keeps reporting an order already
    marked INVALID until someone actually fixes the file.
    """
    findings: "list[Finding]" = []

    for order_file in _iter_queue_files(context.artefact_root):
        data = _load_json_safe(order_file)
        if not data:
            continue
        status = str(data.get("status") or "PENDING").upper()
        if status not in _ROLE_CHECKED_STATUSES:
            continue
        result = validate_order_roles(data)
        if result.ok:
            continue

        order_id = data.get("orderId") or data.get("id") or order_file.stem
        already_held = status == "INVALID"
        findings.append(
            Finding(
                check_id="orders.invalid-role",
                subject_id=order_id,
                severity="high",
                title=f"{order_id} names a role that does not exist",
                detail=(
                    f"{result.message} "
                    + ("The dispatcher has already refused it (status INVALID); "
                       "it stays refused until the file is corrected. "
                       if already_held else
                       "It has not been scanned yet — a dispatcher would refuse "
                       "it (ORDER_INVALID) rather than dispatch it. ")
                    + f"File: {order_file}"
                ),
                firstSeenAt=context.now.isoformat(),
                suggestedCommand=f"mso order retry {order_id} --role <VALID-ROLE>",
                scope="workspace",
                requires=(),
            )
        )

    return findings
