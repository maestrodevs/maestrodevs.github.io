"""maestro/patrol/checks/voyages.py — voyage-level hygiene.

PLAN-PLN-MSO-2026-0504 §4.6: BUG-MSO-2026-0476 is fixed at source (`mso
review approve` releases pre-filed dependents; it never created them) but the
residual duty survives: a voyage whose only order(s) are a completed,
standalone plan, with nothing else ever filed, still needs a Captain to cut
build orders. `maestro.hub.phase.compute_voyage_phase()` already carries this
exact rule for the Hub's own `needs_attention` phase — this check reuses its
`_is_plan_only` / `classify_status` building blocks (the BUG-MSO-2026-0426
one-implementation principle) rather than re-deriving "is this order
plan-only and complete" a second time.

Five real MSO voyages hit exactly this shape before being manually resolved —
VOY-MSO-2026-0094/0100/0130/0145/0147 — and are used as the regression test
fixtures (now archived to `voyages/complete/`, so they no longer reproduce
live; the fixtures recreate their PLANNED-and-stuck shape from their real
ids/titles/orders).

FTR-MSO-2026-0535 (plan order 5) adds two more voyage-family checks:

- `voyages.pr-ci-state` — goes through the `scm`/`ci` providers (§10) rather
  than shelling `gh` directly, and raises `CheckSkipped` (never returns an
  empty, pass-shaped list) when either provider is unavailable — §10.3's
  "skipped, never a false green" rule, and this order's own AC.
- `voyages.merged-not-archived` — calls
  `maestro.core.fleet_runner.run_housekeeping_sweep(dry_run=True)` verbatim
  (no second implementation of merge/archive detection) and reports every
  voyage its dry run says it WOULD archive. That function resolves its own
  workspace via the process-wide `get_artefact_root()` rather than accepting
  an explicit root, so this check temporarily points that resolution at
  `context.artefact_root` for the duration of the call — otherwise every
  section of a `mso doctor --all-projects` run would report whichever
  workspace the process happened to start in, not each project's own state.
  BUG-MSO-2026-0643 F2: this MUST go through
  `maestro.core.order_retry.workspace_scope()` (a locked context manager
  around `fleet_runner._MAESTRO_DIR_OVERRIDE`), never a bare
  `os.environ["MAESTRO_DIR"]` set/restore — `_resolve_workspace_dir` checks
  the override BEFORE the env var, so an unlocked env-var write here can lose
  a race to a concurrent Hub Run for a different workspace and compute this
  check's verdict (including a real archive-affecting dry run) against the
  WRONG workspace's plane. `workspace_scope()` is the one primitive every
  other caller of this override already shares (order_retry itself, and
  `bands.py`'s D7 `voyage.reconcile`/`artefact.sweep` actions).

BUG-MSO-2026-0604 (PLAN-PLN-MSO-2026-0592 §3.4, plan order 11) adds the
inverse pair to `voyages.merged-not-archived` — that check watches "merged
but not archived"; these watch the two ways an archived/annotated manifest's
merge claim can itself be wrong:

- `voyages.archived-not-merged` — a voyage sits in `voyages/complete/`
  claiming its PR merged, but re-deriving the merge state via
  `maestro.core.fleet_runner.resolve_voyage_merge_state()` (FTR-MSO-2026-0600,
  Captain decision D3(a) — the ONE resolver every merge-state consumer must
  share) disagrees. GH #375's exact shape.
- `voyages.merged-missing-mergedat` — a voyage manifest carries `merged:
  true` with no `mergedAt` — the impossible-record / empty-string-sentinel
  shape that let GH #375's corrupted record defeat every downstream presence
  check (FTR-MSO-2026-0600 rule 3: `null`, never `""`).

Both consume `resolve_voyage_merge_state()` and derive no merge state of
their own — the entire point of Captain decision D3(a) is one derivation,
and a doctor check with its own copy would reintroduce exactly what
FTR-MSO-2026-0600 removed. Both use the same `workspace_scope()` override as
`voyages.merged-not-archived`, since `resolve_voyage_merge_state()` also
resolves its workspace via `get_artefact_root()`.
"""

from __future__ import annotations

import json
from pathlib import Path

from maestro.hub.phase import _is_plan_only, classify_status, merge_metadata_trustworthy
from maestro.patrol.registry import CheckContext, CheckSkipped, Finding, check

_ORDER_QUEUE_DIRS = (
    "queues/orders", "queues/bugs", "queues/security", "queues/defects",
    "queues/requests", "queues/breakdown", "queues/high-level",
    "queues/review", "queues/proposed", "queues/escalations",
)


def _load_json_safe(path: Path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def _order_status_and_role_sequence(artefact_root: Path, order_id: str) -> "tuple[str, list]":
    """Best-effort ``(status, roleSequence)`` for *order_id*.

    Archive first (an order's terminal record), then the live queues. This is
    deliberately simpler than `hub.phase`'s full ledger-aware resolution — a
    patrol check reads on-disk artefacts only, with no runtime process
    dependency (works with the dispatcher stopped, per this order's own
    acceptance criteria), so it does not replay the order ledger.
    """
    for sub, default in (("orders/complete", "COMPLETE"), ("orders/failed", "FAILED")):
        data = _load_json_safe(artefact_root / sub / f"{order_id}.json")
        if data:
            return str(data.get("status") or default).upper(), data.get("roleSequence") or []
    for sub in _ORDER_QUEUE_DIRS:
        data = _load_json_safe(artefact_root / sub / f"{order_id}.json")
        if data:
            return str(data.get("status") or "PENDING").upper(), data.get("roleSequence") or []
    return "PENDING", []


def _order_id_of(entry) -> str:
    if isinstance(entry, dict):
        return str(entry.get("orderId") or entry.get("id") or "")
    return str(entry)


@check(id="voyages.planned-no-work", severity="high")
def voyages_planned_no_work(context: CheckContext) -> "list[Finding]":
    findings: "list[Finding]" = []
    voyages_dir = context.artefact_root / "voyages" / "active"
    if not voyages_dir.exists():
        return findings

    for voyage_file in sorted(voyages_dir.glob("*.json")):
        data = _load_json_safe(voyage_file)
        if not data:
            continue

        voyage_id = data.get("id") or data.get("voyageId") or voyage_file.stem
        order_ids = [oid for oid in (_order_id_of(o) for o in (data.get("orders") or [])) if oid]
        if not order_ids:
            continue

        members = [
            (oid, *_order_status_and_role_sequence(context.artefact_root, oid))
            for oid in order_ids
        ]
        all_plan_only = all(_is_plan_only(role_seq) for _, _, role_seq in members)
        all_complete = all(classify_status(status) == "complete" for _, status, _ in members)
        # BUG-MSO-2026-0569: an inconsistent merged=true/mergedAt="" record
        # must not silently suppress this finding.
        pr_merged = merge_metadata_trustworthy(data)

        if not (all_plan_only and all_complete and not pr_merged):
            continue

        findings.append(
            Finding(
                check_id="voyages.planned-no-work",
                subject_id=voyage_id,
                severity="high",
                title=f"{voyage_id}: plan approved but no build orders were filed",
                detail=(
                    f"All {len(order_ids)} order(s) on this voyage "
                    f"({', '.join(order_ids)}) are standalone plan-only orders and are "
                    "complete, but no PR was ever merged for it — the plan was approved "
                    "and nothing was queued to build it (BUG-MSO-2026-0476)."
                ),
                firstSeenAt=context.now.isoformat(),
                suggestedCommand=None,
                scope="workspace",
                requires=(),
            )
        )

    return findings


# ---------------------------------------------------------------------------
# voyages.pr-ci-state (FTR-MSO-2026-0535)
# ---------------------------------------------------------------------------

# gh's own CI conclusion vocabulary that means "this run did not succeed" —
# matched case-insensitively since the shipped `github_actions` provider
# passes `gh pr checks --json`'s raw `conclusion` field straight through.
_FAILING_CONCLUSIONS = {"failure", "cancelled", "timed_out", "action_required", "startup_failure"}
# Values of the raw `status`/`state` field that mean "still running" — a
# check whose conclusion is unset and whose state is one of these is normal,
# transient "pending" and is not itself a finding.
_IN_PROGRESS_STATES = {"in_progress", "queued", "pending", "requested", "waiting"}


def _pr_ci_state(checks_list: "list[dict]") -> str:
    """Classify a PR's overall CI state from a `ci` provider's
    `checks_for_pr()` output. Returns one of "green", "pending", "failing",
    "unknown" — deliberately never silently returning "green" for an
    inconclusive input (order-5 AC: "degrades to unknown, never a false
    green")."""
    if not checks_list:
        return "unknown"

    conclusions = [str(c.get("conclusion") or "").lower() for c in checks_list]
    if any(c in _FAILING_CONCLUSIONS for c in conclusions):
        return "failing"

    statuses = [str(c.get("status") or "").lower() for c in checks_list]
    if any(not conclusion and status in _IN_PROGRESS_STATES for conclusion, status in zip(conclusions, statuses)):
        return "pending"
    if all(conclusions) and all(c not in _FAILING_CONCLUSIONS for c in conclusions):
        return "green"
    return "unknown"


@check(id="voyages.pr-ci-state", severity="high", requires=("scm", "ci"))
def voyages_pr_ci_state(context: CheckContext) -> "list[Finding]":
    from maestro.providers import resolve_explain

    scm = resolve_explain("scm", workspace=context.workspace)
    ci = resolve_explain("ci", workspace=context.workspace)
    if not scm.available or not ci.available:
        reasons = [r.reason for r in (scm, ci) if not r.available]
        raise CheckSkipped(" ; ".join(reasons))

    findings: "list[Finding]" = []
    voyages_dir = context.artefact_root / "voyages" / "active"
    if not voyages_dir.exists():
        return findings

    for voyage_file in sorted(voyages_dir.glob("*.json")):
        data = _load_json_safe(voyage_file)
        if not data:
            continue
        voyage_id = data.get("id") or data.get("voyageId") or voyage_file.stem
        branch = data.get("branch")
        if not branch:
            continue

        pr = scm.provider.get_pr_for_branch(branch)
        if pr is None or scm.provider.pr_is_merged(pr):
            # No PR yet, or already merged — merge/CI-conclusion state is a
            # different check's concern (§12.3/§12.5 are LEAD-event-driven,
            # not part of this heartbeat-scope check).
            continue

        state = _pr_ci_state(ci.provider.checks_for_pr(pr))
        if state in ("green", "pending"):
            continue

        findings.append(
            Finding(
                check_id="voyages.pr-ci-state",
                subject_id=voyage_id,
                severity="high",
                title=f"{voyage_id}: PR CI is {state}",
                detail=(
                    f"PR #{pr.get('number')} ({pr.get('url', '') or branch}) for "
                    f"{voyage_id}'s branch '{branch}' reports CI state '{state}' via the "
                    f"'{ci.provider_id}' provider."
                ),
                firstSeenAt=context.now.isoformat(),
                suggestedCommand=None,
                scope="workspace",
                requires=("scm", "ci"),
            )
        )

    return findings


# ---------------------------------------------------------------------------
# voyages.stalled-order-deadlock (BUG-MSO-2026-0597)
# ---------------------------------------------------------------------------

def _dependents_held_behind(artefact_root: Path, stalled_id: str) -> "list[str]":
    """Order ids currently sitting in the live queues whose `dependsOn` /
    `dependencies` names *stalled_id* — the operator-actionable "what is
    this actually blocking" half of the deadlock that a bare
    `SWEEP_STALLED_ORDER` log line never named (BUG-MSO-2026-0597)."""
    held: "list[str]" = []
    for sub in _ORDER_QUEUE_DIRS:
        d = artefact_root / sub
        if not d.exists():
            continue
        for f in sorted(d.glob("*.json")):
            data = _load_json_safe(f)
            if not data:
                continue
            deps = data.get("dependsOn") or data.get("dependencies") or []
            if stalled_id in deps:
                held.append(str(data.get("orderId") or data.get("id") or f.stem))
    return held


@check(id="voyages.stalled-order-deadlock", severity="high")
def voyages_stalled_order_deadlock(context: CheckContext) -> "list[Finding]":
    """BUG-MSO-2026-0597: the operator-actionable half of what used to be
    ONLY a heartbeat-cadence log line. `fleet_runner.sweep_decks()` refuses
    to finalise a voyage that has a manifest order archived STALLED (not
    COMPLETE) and used to say so via an unthrottled `SWEEP_STALLED_ORDER`
    line on every dispatcher heartbeat — 121 identical copies were measured
    in one eight-hour window on the live MSO fleet (PLAN-PLN-MSO-2026-0592
    §6.4), which is now throttled to the same 300s cadence
    BUG-MSO-2026-0303's Eight-Bells-withheld WARN already uses. A throttled
    log line is still not a finding: nothing aggregates it, nothing ages it,
    and it never named what the stall was actually blocking downstream. This
    check reads the same on-disk state sweep_decks() does — reusing
    `fleet_runner._SWEEPABLE_VOYAGE_STATUSES` so "is this voyage in-flight"
    is answered identically in both places — and additionally names every
    dependent order held behind the stall.

    Each finding's ``subject_id`` is the stalled order's own id, which
    matches ``patrol.__init__._STABLE_SUBJECT_ID_RE`` (BUG-MSO-2026-0662 F3 /
    BUG-MSO-2026-0675 F2 — that regex, not a per-check opt-in, is the single
    source of truth for which subject ids ``run_single_check`` filters
    per-subject) — durable across re-checks, so re-running via `mso order
    retry <id>`'s Run button confirms THAT order specifically. Before the
    original fix, retrying one of several stalled orders reported "condition
    still present" (some OTHER order was still stalled) and left that
    order's own Run button wrongly enabled.
    """
    from maestro.core.fleet_runner import _SWEEPABLE_VOYAGE_STATUSES

    findings: "list[Finding]" = []
    voyages_dir = context.artefact_root / "voyages" / "active"
    if not voyages_dir.exists():
        return findings

    complete_dir = context.artefact_root / "orders" / "complete"

    for voyage_file in sorted(voyages_dir.glob("*.json")):
        data = _load_json_safe(voyage_file)
        if not data:
            continue

        voyage_status = (data.get("status") or "").upper()
        if voyage_status and voyage_status not in _SWEEPABLE_VOYAGE_STATUSES:
            continue  # deliberately parked (HELD/PAUSED/...) — not a deadlock

        voyage_id = data.get("id") or data.get("voyageId") or voyage_file.stem
        order_ids = [oid for oid in (_order_id_of(o) for o in (data.get("orders") or [])) if oid]

        for order_id in order_ids:
            order_data = _load_json_safe(complete_dir / f"{order_id}.json")
            if not order_data:
                continue
            if str(order_data.get("status") or "").upper() != "STALLED":
                continue

            dependents = _dependents_held_behind(context.artefact_root, order_id)

            # BUG-MSO-2026-0705 (AC3): a stall whose cause is a ROLE REJECTION
            # is not a generic STALLED — the fleet's own QA verdict named the
            # defect and the role that found it, and the recovery is a re-run
            # of the PREVIOUS role, not a bare retry. Reuse `role_rejection`'s
            # single describer/command pair so `mso doctor`, `mso status` and
            # the Hub all say the same sentence.
            from maestro.core import role_rejection

            rejection_desc = role_rejection.describe_rejection(order_data)
            command = (role_rejection.retry_command(order_id, order_data)
                       if rejection_desc else f"mso order retry {order_id}")

            if rejection_desc:
                title = f"{voyage_id}: {order_id} {rejection_desc}"
                detail = (
                    f"{order_id} is archived STALLED in {voyage_id}'s manifest, but it was "
                    f"REJECTED on review, not abandoned — {rejection_desc}. The voyage "
                    "cannot finalise while it stays that way."
                )
                report = (role_rejection.rejection_block(order_data) or {}).get("reportPath")
                if report:
                    detail += f" Reviewer's report: {report}."
            else:
                title = f"{voyage_id}: queued work deadlocked behind STALLED order {order_id}"
                detail = (
                    f"{order_id} is archived STALLED in {voyage_id}'s manifest — the "
                    "voyage cannot finalise while it stays that way."
                )
            if dependents:
                detail += (
                    f" {len(dependents)} dependent order(s) are held behind it: "
                    f"{', '.join(dependents)}."
                )
            detail += f" Recover with `{command}`."

            findings.append(
                Finding(
                    check_id="voyages.stalled-order-deadlock",
                    subject_id=order_id,
                    severity="high",
                    title=title,
                    detail=detail,
                    firstSeenAt=context.now.isoformat(),
                    suggestedCommand=command,
                    scope="workspace",
                    requires=(),
                )
            )

    return findings


# ---------------------------------------------------------------------------
# voyages.deadlocked (BUG-MSO-2026-0699)
# ---------------------------------------------------------------------------

@check(id="voyages.deadlocked", severity="high")
def voyages_deadlocked(context: CheckContext) -> "list[Finding]":
    """BUG-MSO-2026-0699: a voyage that can NEVER finish without an operator.

    Distinct from `voyages.stalled-order-deadlock` above, which reports one
    STALLED order and what it happens to block. This reports the VOYAGE-level
    verdict — every remaining order is transitively held behind a terminal
    non-COMPLETE order (STALLED / FAILED / CONVERGENCE_FAILED / VERIFY_FAILED /
    VERIFY_DEPS_FAILED / AUTO_SERIALIZE / operator-skipped) and no crew is on
    any of them. That is the thing the Captain could not see on 2026-09-09: the
    Hub board showed the held orders as held, `mso status` drew a 0% bar, and
    nothing anywhere said the voyage was finished as far as the fleet was
    concerned. A stalled order in a voyage that still has dispatchable work is
    NOT this finding — the fleet will keep going, and the per-order check above
    already covers it.

    Derives NOTHING of its own: the verdict comes from
    `maestro.core.deadlock.detect_deadlocked_voyages()`, the one shared
    classifier this order's AC1 requires, which `mso status`, the dispatcher's
    idle watchdog and `hub/phase.py` also call. A second copy here would
    reintroduce exactly the per-surface divergence that made the incident
    invisible.

    ``subject_id`` is the VOYAGE id — durable across re-checks
    (`patrol.__init__._STABLE_SUBJECT_ID_RE`), so the Hub's per-subject Run
    button re-confirms this voyage specifically rather than reporting "still
    present" because some other voyage is also stuck.
    """
    from maestro.core.deadlock import detect_deadlocked_voyages

    findings: "list[Finding]" = []
    for verdict in detect_deadlocked_voyages(context.artefact_root):
        findings.append(
            Finding(
                check_id="voyages.deadlocked",
                subject_id=verdict.voyage_id,
                severity="high",
                title=(
                    f"{verdict.voyage_id}: DEADLOCKED — blocked by "
                    f"{verdict.blocking_order_id} ({verdict.blocking_cause})"
                ),
                detail=verdict.detail(),
                firstSeenAt=context.now.isoformat(),
                suggestedCommand=verdict.suggested_command,
                scope="workspace",
                requires=(),
            )
        )
    return findings


# ---------------------------------------------------------------------------
# voyages.merged-not-archived (FTR-MSO-2026-0535)
# ---------------------------------------------------------------------------

@check(id="voyages.merged-not-archived", severity="low")
def voyages_merged_not_archived(context: CheckContext) -> "list[Finding]":
    from maestro.core.fleet_runner import run_housekeeping_sweep
    from maestro.core.order_retry import workspace_scope

    # See module docstring: run_housekeeping_sweep() resolves its own
    # workspace via the process-wide get_artefact_root() rather than an
    # explicit root parameter. Reusing it verbatim (this order's AC forbids a
    # second implementation) means pointing that resolution at THIS check's
    # artefact_root for the duration of the call.
    #
    # BUG-MSO-2026-0643 F2: this used to be a bare, unlocked
    # os.environ["MAESTRO_DIR"] set/restore. fleet_runner._resolve_workspace_dir
    # checks the process-global _MAESTRO_DIR_OVERRIDE BEFORE the env var, so a
    # concurrent Hub Run for another workspace holding workspace_scope() (or
    # order_retry itself) would win the race and this check would compute its
    # verdict — including a real `mso voyage reconcile` dry run — against the
    # WRONG workspace's plane. workspace_scope() is the one locked primitive
    # every other caller of this override (order_retry, bands.py's
    # voyage.reconcile/artefact.sweep D7 actions) already uses; using anything
    # else here reintroduces exactly the race order_retry.workspace_scope's
    # own docstring says must not happen in the Hub.
    try:
        with workspace_scope(context.artefact_root):
            report = run_housekeeping_sweep(dry_run=True)
    except Exception as exc:  # noqa: BLE001 — a broken sweep must self-skip, not crash the patrol
        raise CheckSkipped(f"skipped — housekeeping sweep unavailable: {exc}") from exc

    findings: "list[Finding]" = []
    for entry in report.get("changes", []):
        if entry.get("action") != "archived":
            continue
        voyage_id = entry.get("voyage") or "?"
        findings.append(
            Finding(
                check_id="voyages.merged-not-archived",
                subject_id=voyage_id,
                severity="low",
                title=f"{voyage_id}: merged but not yet archived",
                detail=(
                    f"{entry.get('reason', 'PR merged')} — `mso voyage reconcile` would "
                    "archive it now; nothing has run reconcile since the merge."
                ),
                firstSeenAt=context.now.isoformat(),
                suggestedCommand="mso voyage reconcile",
                scope="workspace",
                requires=(),
            )
        )
    return findings


# ---------------------------------------------------------------------------
# voyages.archived-not-merged / voyages.merged-missing-mergedat
# (BUG-MSO-2026-0604 — PLAN-PLN-MSO-2026-0592 §3.4, plan order 11)
# ---------------------------------------------------------------------------

def _voyage_claims_merged(voyage: dict) -> bool:
    """True if *voyage*'s manifest asserts its PR merged — the flat
    ``merged`` boolean, a linked ``mergedPR``, or a non-empty ``mergedAt``.
    Any one of these is a claim of completion; ``resolve_voyage_merge_state``
    is what checks whether the claim still holds."""
    if voyage.get("merged") is True:
        return True
    if voyage.get("mergedPR") is not None:
        return True
    if voyage.get("mergedAt"):
        return True
    return False


@check(id="voyages.archived-not-merged", severity="high")
def voyages_archived_not_merged(context: CheckContext) -> "list[Finding]":
    """GH #375's exact shape: a voyage sits in ``voyages/complete/`` claiming
    its PR merged, but re-deriving the merge state via THE one resolver
    (``resolve_voyage_merge_state`` — FTR-MSO-2026-0600, Captain decision
    D3(a)) disagrees. This check derives no merge state of its own — it
    calls the shared resolver and compares against the archived claim.

    An ``UNKNOWN`` re-derivation (gh/git unavailable, offline, rate-limited)
    is deliberately NOT a finding — absence of evidence is never evidence of
    absence (the plan's tri-state rule, §2.4: INDETERMINATE always fails
    open). Only a definite contradiction — ``CLOSED_UNMERGED``, ``OPEN`` or
    ``WRONG_BASE`` — fires.
    """
    from maestro.core.fleet_runner import resolve_voyage_merge_state
    from maestro.core.order_retry import workspace_scope

    findings: "list[Finding]" = []
    complete_dir = context.artefact_root / "voyages" / "complete"
    if not complete_dir.exists():
        return findings

    # BUG-MSO-2026-0643 F2: workspace_scope(), not a bare unlocked
    # os.environ["MAESTRO_DIR"] set/restore — see voyages_merged_not_archived
    # above for why the override (which _resolve_workspace_dir ranks ABOVE
    # the env var) needs the shared lock.
    #
    # BUG-MSO-2026-0670 F3: scope is entered PER ITERATION, not once around
    # the whole loop. `resolve_voyage_merge_state()` makes a gh/git round-trip
    # per voyage, and the prior "one `with` around the whole `for`" held the
    # process-global `_SCOPE_LOCK` (an RLock — cheap to re-acquire once per
    # voyage) for the sum of every voyage's network latency instead of one
    # voyage's — on an O(N)-voyage workspace that is O(N) times longer that
    # every other `workspace_scope()` caller in this process (a concurrent
    # Hub Run click, an order-retry POST) sits blocked. Per-iteration scoping
    # keeps the exact race-fix this lock exists for (BUG-0643 F2, BUG-0656
    # F1's both-mechanisms pinning) — the override is still pinned for every
    # resolver call — while shrinking the hold to one gh round-trip at a time
    # WORSE case: a concurrent scope-holder can now interleave BETWEEN this
    # check's voyages, so two different callers' `_MAESTRO_DIR_OVERRIDE`
    # pins can alternate voyage-by-voyage instead of one caller finishing
    # first — harmless here since each iteration reads its own already-loaded
    # `data`/`voyage_id` before entering the scope and only the resolver call
    # itself needs the pin.
    for voyage_file in sorted(complete_dir.glob("*.json")):
        data = _load_json_safe(voyage_file)
        if not data or not _voyage_claims_merged(data):
            continue

        voyage_id = data.get("id") or data.get("voyageId") or voyage_file.stem
        try:
            with workspace_scope(context.artefact_root):
                resolved = resolve_voyage_merge_state(data)
        except Exception:
            continue  # a broken re-derivation for one voyage must not sink the rest

        state = resolved.get("state")
        if state not in ("CLOSED_UNMERGED", "OPEN", "WRONG_BASE"):
            continue  # MERGED confirms the claim; UNKNOWN is indeterminate — fail open

        findings.append(
            Finding(
                check_id="voyages.archived-not-merged",
                subject_id=voyage_id,
                severity="high",
                title=f"{voyage_id}: archived as merged, but the PR was never merged",
                detail=(
                    "This voyage is archived in voyages/complete/ claiming its PR "
                    f"merged, but resolve_voyage_merge_state() now reports "
                    f"'{state}' — GH #375's exact shape (a side-channel merge, or "
                    "a manifest written before the PR/git contradiction was "
                    "resolvable, recorded completion the PR record does not "
                    "support). Confirm what actually happened before treating "
                    "this voyage's work as shipped."
                ),
                firstSeenAt=context.now.isoformat(),
                suggestedCommand=None,
                scope="workspace",
                requires=(),
            )
        )

    return findings


@check(id="voyages.merged-missing-mergedat", severity="medium")
def voyages_merged_missing_mergedat(context: CheckContext) -> "list[Finding]":
    """The impossible-record shape (PLAN-PLN-MSO-2026-0592 §3.3 rule 3):
    ``merged: true`` with no ``mergedAt`` — the empty-string-sentinel bug
    that let GH #375's corrupted record survive every downstream presence
    check. Scans both ``voyages/active/`` (annotated mid-flight) and
    ``voyages/complete/`` (the archive path) — the flat ``merged`` boolean is
    written by both. Consumes ``resolve_voyage_merge_state`` to attach the
    currently-resolvable ``mergedAt`` to the finding rather than re-deriving
    the presence check itself; the resolver's outcome never gates whether
    this fires — a manifest self-contradiction is a finding regardless of
    whether live evidence can now backfill it.
    """
    from maestro.core.fleet_runner import resolve_voyage_merge_state
    from maestro.core.order_retry import workspace_scope

    findings: "list[Finding]" = []
    # BUG-MSO-2026-0643 F2: workspace_scope(), not a bare unlocked
    # os.environ["MAESTRO_DIR"] set/restore — see voyages_merged_not_archived
    # above for why the override (which _resolve_workspace_dir ranks ABOVE
    # the env var) needs the shared lock.
    #
    # BUG-MSO-2026-0670 F3: scope PER ITERATION (per voyage's resolver call),
    # not once around both directories' whole nested loop — see the matching
    # note in voyages_archived_not_merged above for the full trade-off
    # (shrinks the global-lock hold from O(N) gh round-trips to one at a
    # time; worse case is a concurrent scope-holder can now interleave
    # between voyages, which is harmless since each iteration's `data`/
    # `voyage_id` are already loaded before the scope is entered).
    for sub in ("active", "complete"):
        voyages_dir = context.artefact_root / "voyages" / sub
        if not voyages_dir.exists():
            continue
        for voyage_file in sorted(voyages_dir.glob("*.json")):
            data = _load_json_safe(voyage_file)
            if not data:
                continue
            if data.get("merged") is not True:
                continue
            if data.get("mergedAt"):
                continue  # present and non-empty — the record is sound

            voyage_id = data.get("id") or data.get("voyageId") or voyage_file.stem
            resolved_at = None
            try:
                with workspace_scope(context.artefact_root):
                    resolved_at = resolve_voyage_merge_state(data).get("mergedAt")
            except Exception:
                pass

            backfill = (
                f"resolve_voyage_merge_state() currently resolves "
                f"mergedAt={resolved_at!r} — the manifest can be backfilled "
                "with that value."
                if resolved_at else
                "resolve_voyage_merge_state() cannot currently re-derive a "
                "mergedAt either (gh/git unavailable, or the PR record itself "
                "never carried one)."
            )

            findings.append(
                Finding(
                    check_id="voyages.merged-missing-mergedat",
                    subject_id=voyage_id,
                    severity="medium",
                    title=f"{voyage_id}: merged=true but mergedAt is missing",
                    detail=(
                        "This voyage's manifest asserts merged=true with no "
                        "mergedAt — the impossible-record shape that let GH "
                        "#375's corrupted record defeat every downstream "
                        "presence check (rule 3: null, never \"\"). " + backfill
                    ),
                    firstSeenAt=context.now.isoformat(),
                    suggestedCommand=None,
                    scope="workspace",
                    requires=(),
                )
            )

    return findings
