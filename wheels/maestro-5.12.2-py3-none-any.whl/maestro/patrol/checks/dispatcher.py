"""maestro/patrol/checks/dispatcher.py — dispatcher liveness.

PLAN-PLN-MSO-2026-0504 §4.1 / BUG-MSO-2026-0541: a dispatcher whose PID is
alive but whose heartbeat has gone stale is WEDGED, not RUNNING, and must be
reported as a distinct, alarming state rather than folded into "healthy" —
that fold is exactly what let a dead/stuck MSO dispatcher go unnoticed for
three ticks on 2026-08-17. Reuses
``maestro.core.fleet_monitor.get_dispatcher_status`` (the BUG-MSO-2026-0426
one-implementation principle) rather than re-deriving liveness here.

BUG-MSO-2026-0681 F2: this check's own `suggestedCommand` is plain `mso
cleanup` for a PID that, by this check's own definition, IS alive — which
BUG-MSO-2026-0673 F1 refuses outright ("a live dispatcher is running").
`--force` is the escape hatch BUG-MSO-2026-0681 F2 added specifically for
this WEDGED (alive-but-stale) shape, so the suggestion here must carry it —
otherwise the one tool that names this exact failure recommends a command
that cannot act on it.

BUG-MSO-2026-0691 F3: the SIBLING check in this same file
(`dispatcher.scan-disagreement`) still carried the plain `mso cleanup` the
paragraph above rejects — the fix reached one check and not the other. Both
now suggest `mso cleanup --force`; if a third dispatcher check is ever added
here, it inherits the same rule (any suggestion made while the dispatcher
process is, by the check's own firing condition, alive must carry `--force`).
"""

from __future__ import annotations

from datetime import datetime, timezone

from maestro.core.fleet_monitor import get_dispatcher_status
from maestro.core.scan_disagreement import (
    exclusion_category, read_scan_disagreement_state,
)
from maestro.patrol.registry import CheckContext, Finding, check


@check(id="dispatcher.heartbeat", severity="critical")
def dispatcher_heartbeat(context: CheckContext) -> "list[Finding]":
    status = get_dispatcher_status(context.artefact_root)
    if status["state"] != "WEDGED":
        return []

    age = status.get("heartbeatAgeSeconds")
    age_desc = f"{age:.0f}s" if isinstance(age, (int, float)) else "unknown"
    pid = status.get("pid")

    return [
        Finding(
            check_id="dispatcher.heartbeat",
            subject_id=f"dispatcher:pid={pid}",
            severity="critical",
            title="Dispatcher is wedged — process alive, heartbeat stale",
            detail=(
                f"dispatcher.pid ({pid}) is alive, but neither fleet-runner-state.json nor "
                f"logs/lifecycle.log's HEARTBEAT line has been refreshed in {age_desc} — the "
                "dispatcher looks running but is not ticking. It cannot make progress on "
                "pending work until it is restarted."
            ),
            firstSeenAt=context.now.isoformat(),
            suggestedCommand="mso cleanup --force",
            scope="workspace",
            requires=(),
        )
    ]


# ---------------------------------------------------------------------------
# dispatcher.scan-disagreement (FTR-MSO-2026-0603 / INV-MSO-2026-0602 / GH #203)
# ---------------------------------------------------------------------------

_DEFAULT_MAX_AGE_MINUTES = 15


@check(id="dispatcher.scan-disagreement", severity="high")
def dispatcher_scan_disagreement(context: CheckContext) -> "list[Finding]":
    """The operator-visible half of #203: the dispatcher's own view can be
    audited against what is actually on disk. Reads the snapshot
    ``scan_all_queues`` writes every tick (``scan_disagreement.py``) rather
    than re-deriving the dispatcher's filter chain — this check WORKS WITH
    THE DISPATCHER STOPPED, same requirement as ``dispatcher.heartbeat``: a
    missing or stale snapshot is "nothing recorded", not an alarm.

    Deliberately complementary to, and never a substitute for,
    ``dispatcher.heartbeat``: that check answers "is the loop turning", this
    one answers "is it selecting correctly" — a fresh heartbeat must never
    be treated as evidence the scan itself is correct (INV-MSO-2026-0602
    §5's corollary; the 2026-08-17 incident is the concrete case this
    guards against).

    Fires ONLY on exclusion reasons that are NOT one of the known legitimate
    filters (dep-held, review-gated-away-from-PENDING, skipped,
    ledger-terminal, archived-terminal, live-crew-inflight, circular-dep,
    escalation-blocked, mid-transition, role-gate) — those already have
    their own visibility elsewhere and firing on them here would just be
    alarm-fatigue noise on ordinary holds.

    Each finding's ``subject_id`` is the excluded order's own id, unlike
    ``dispatcher.heartbeat``'s pid-embedding subject_id — a bare order id
    matches ``patrol.__init__._STABLE_SUBJECT_ID_RE`` (BUG-MSO-2026-0662 F3 /
    BUG-MSO-2026-0675 F2 — that regex, not a per-check opt-in, is the single
    source of truth for which subject ids ``run_single_check`` filters
    per-subject), so a `mso order retry <id>` Run re-check confirms THAT
    order specifically among however many this check currently reports.
    """
    max_age_minutes = context.params_for("dispatcher.scan-disagreement").get(
        "maxAgeMinutes", _DEFAULT_MAX_AGE_MINUTES
    )
    state = read_scan_disagreement_state(context.artefact_root)
    if not state:
        return []

    updated_at = state.get("updatedAt")
    if updated_at:
        try:
            ts = datetime.fromisoformat(updated_at)
            if ts.tzinfo is None:
                ts = ts.replace(tzinfo=timezone.utc)
            age_minutes = (context.now - ts).total_seconds() / 60.0
            if age_minutes > max_age_minutes:
                return []  # stale snapshot — the dispatcher may not even be running
        except (ValueError, TypeError):
            return []

    illegitimate = state.get("illegitimate") or {}
    if not illegitimate:
        return []

    findings: "list[Finding]" = []
    naive_pending = state.get("naivePending", "?")
    dispatch_eligible = state.get("dispatchEligible", "?")
    for order_id, reason in sorted(illegitimate.items()):
        category = exclusion_category(reason)
        # BUG-MSO-2026-0691 F3: a ledger-claim disagreement only ever fires
        # while the claim's recorded pid IS live (order_ledger.live_claim()
        # excludes a dead one) -- and this check's own snapshot-age gate
        # above (`_DEFAULT_MAX_AGE_MINUTES`) only lets a finding through when
        # the dispatcher was ticking within the last 15 minutes, i.e. is
        # very likely still alive right now. A bare `mso cleanup` therefore
        # hits the exact same BUG-MSO-2026-0673 F1 live-dispatcher refusal
        # its sibling `dispatcher.heartbeat` above already carries `--force`
        # for -- this check must match it instead of recommending a command
        # guaranteed to refuse.
        suggested = "mso cleanup --force"
        recovery = "restarting the dispatcher clears a process-local ledger claim"
        if category == "ledger-terminal":
            suggested = f"mso order retry {order_id}"
            recovery = "the ledger records this order TERMINAL — that veto is by design"

        findings.append(
            Finding(
                check_id="dispatcher.scan-disagreement",
                subject_id=order_id,
                severity="high",
                title=f"{order_id}: dispatcher's view disagrees with the on-disk queue",
                detail=(
                    f"Last scan reported dispatch-eligible={dispatch_eligible} vs naive "
                    f"on-disk PENDING={naive_pending}. {order_id} is PENDING on disk but was "
                    f"excluded for reason '{reason}', which is not one of the dispatcher's "
                    f"known legitimate holds (dep-held/skipped/review-gated/terminal/etc) — "
                    f"this is the #203 shape: the dispatcher may silently never dispatch this "
                    f"order again while it looks perfectly healthy. {recovery}."
                ),
                firstSeenAt=context.now.isoformat(),
                suggestedCommand=suggested,
                scope="workspace",
                requires=(),
            )
        )
    return findings
