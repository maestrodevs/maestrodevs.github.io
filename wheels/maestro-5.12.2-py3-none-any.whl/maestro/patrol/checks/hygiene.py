"""maestro/patrol/checks/hygiene.py — worktree and runtime-version hygiene.

PLAN-PLN-MSO-2026-0504 (plan order 5, FTR-MSO-2026-0535):

- `hygiene.stale-worktrees` — §1/§4.7 "Worktree cleanup" is ENGINE, partly
  exists: `maestro.core.worktrees.prune_stale_worktrees()` removes a completed
  voyage's worktrees at dispatcher startup, or on demand via the operator-run
  `mso worktree prune` (BUG-MSO-2026-0680) — it is NOT invoked by
  `mso voyage reconcile`. **The LEAD's `worktree.prune` action is OBSERVE-only
  (Captain ruling 2026-09-06, BUG-MSO-2026-0644) and never runs this
  unattended** — it only proposes; a human must run `mso worktree prune`
  (that CLI command, and this finding's `suggestedCommand`, are what
  BUG-MSO-2026-0680 added — the escape hatch the OBSERVE-only ruling assumed
  existed did not, until then). This check is a READ-ONLY mirror of that
  function's own "voyage archived to voyages/complete/ but its worktree
  still exists" rule. It never calls `git worktree remove` itself, or any
  git command at all — a check never remediates (registry.py) — it only
  reports what the next prune pass would clear. BUG-MSO-2026-0594: before
  that fix, `prune_stale_worktrees()` compared a `"<VID>.json"` filename
  against bare directory names and could never match — it had never pruned
  anything, ever, on any workspace. This check's own scan was never affected
  (it always used `.stem` / `glob("*.json")` correctly); only the
  remediation text's promise that a stale worktree "will be pruned
  automatically" was false.

- `hygiene.unreachable-crew-commits` — BUG-MSO-2026-0706. Crew branches are
  named per SLOT (`crew/<voyage>-<N>`), and a slot is reused within seconds of
  a requeue, so a crew branch that is discarded without a salvage ref leaves
  its commits reachable from nothing at all — alive only until the next
  `git gc`. On 2026-09-09 that cost BUG-MSO-2026-0702 five committed,
  verified commits (7 files, +1899, 2h40 / $29 of crew time); the LEAD
  recovered them by listing loose objects under `.git/objects` by mtime and
  matching commit subjects. This check IS that recovery, run every tick: it
  reports recent unreachable commit objects whose subject names an order id
  this workspace knows, and hands back the `git branch salvage/… <sha>`
  command that pins them. The engine-side fix (preserve before discard) is in
  `maestro.core.worktrees`; this is the independent second opinion — a check
  that only ever reports, and never the thing that was supposed to have
  prevented the loss.

- `hygiene.runtime-version` — §4.5/D5: compares the installed `mso` version
  against the newest `vX.Y.Z` git tag reachable in the product repo. D5(b):
  ALWAYS states the fleet's current dispatcher state alongside the gap, so
  the operator knows whether a refresh is even actionable yet. Per the
  BUG-MSO-2026-0503 caveat, this NEVER prints the documented
  `pip install . --no-deps` reinstall command — that refresh currently wipes
  the licence signing keyring and silently downgrades the install to
  community. It only ever reports that a refresh is needed and why it must
  wait for an IDLE fleet, never how to run it. Deliberately an OFFLINE git-tag
  comparison rather than a wheel-index/PyPI query: `mso doctor` must stay
  fast and work with no network reachable (§3, "no LLM, no dispatcher, no
  network required" is the same spirit as the dispatcher-stopped guarantee),
  and a git tag is already the release chain's own source of truth (CLAUDE.md
  "Standard PR ship procedure" step 6: `git tag v<NEW>` triggers publish).
"""

from __future__ import annotations

import re
import time
from pathlib import Path
from typing import Optional

from maestro.core.fleet_monitor import get_dispatcher_status
from maestro.core.proc import run_hidden
from maestro.patrol.registry import CheckContext, Finding, check

_VERSION_TAG_RE = re.compile(r"^v(\d+)\.(\d+)\.(\d+)$")


def _version_tuple(v: str) -> "Optional[tuple[int, int, int]]":
    v = v.strip()
    if v.startswith("v"):
        v = v[1:]
    parts = v.split(".")
    if len(parts) < 3:
        return None
    try:
        return (int(parts[0]), int(parts[1]), int(parts[2]))
    except ValueError:
        return None


# ---------------------------------------------------------------------------
# hygiene.stale-worktrees
# ---------------------------------------------------------------------------

@check(id="hygiene.stale-worktrees", severity="low")
def hygiene_stale_worktrees(context: CheckContext) -> "list[Finding]":
    findings: "list[Finding]" = []
    complete_dir = context.artefact_root / "voyages" / "complete"
    if not complete_dir.exists():
        return findings
    completed_voyage_ids = {p.stem for p in complete_dir.glob("*.json")}
    if not completed_voyage_ids:
        return findings

    stale_ids: "set[str]" = set()

    # Legacy home: voyages/active/<VID>/.worktree(-crew*)
    active_dir = context.artefact_root / "voyages" / "active"
    if active_dir.exists():
        for voyage_dir in active_dir.iterdir():
            if not voyage_dir.is_dir() or voyage_dir.name not in completed_voyage_ids:
                continue
            has_admin_worktree = (voyage_dir / ".worktree").exists()
            has_crew_worktree = any(
                c.is_dir() and c.name.startswith(".worktree-crew") for c in voyage_dir.iterdir()
            )
            if has_admin_worktree or has_crew_worktree:
                stale_ids.add(voyage_dir.name)

    # Canonical home: worktrees/<VID>/{admin,crew*,convergence-*}
    wt_root = context.artefact_root / "worktrees"
    if wt_root.exists():
        for voyage_home in wt_root.iterdir():
            if not voyage_home.is_dir() or voyage_home.name not in completed_voyage_ids:
                continue
            if any(c.is_dir() for c in voyage_home.iterdir()):
                stale_ids.add(voyage_home.name)

    for voyage_id in sorted(stale_ids):
        findings.append(
            Finding(
                check_id="hygiene.stale-worktrees",
                subject_id=voyage_id,
                severity="low",
                title=f"{voyage_id}: worktree(s) survived voyage archival",
                detail=(
                    f"{voyage_id} is archived to voyages/complete/ but still has a "
                    "worktree checked out (worktrees/, or the legacy voyages/active/ "
                    "home) — it will be pruned automatically at the next dispatcher "
                    "startup. The LEAD's worktree.prune action is OBSERVE-only "
                    "(Captain ruling 2026-09-06, BUG-MSO-2026-0644) — it proposes "
                    "this prune but never runs it unattended. Run `mso worktree "
                    "prune` by hand to clear it now. `mso voyage reconcile` does "
                    "NOT clear worktrees."
                ),
                firstSeenAt=context.now.isoformat(),
                suggestedCommand="mso worktree prune",
                scope="workspace",
                requires=(),
            )
        )
    return findings


# ---------------------------------------------------------------------------
# hygiene.runtime-version
# ---------------------------------------------------------------------------

def _installed_version() -> Optional[str]:
    try:
        from maestro import __version__
        return __version__
    except Exception:
        return None


def _latest_git_tag(repo_root: Path) -> Optional[str]:
    """Best-effort newest ``vX.Y.Z`` tag reachable in *repo_root*'s git
    history. Never raises — no git, no tags, or a repo that isn't a git
    checkout at all simply yields ``None`` and the check declines to guess."""
    try:
        r = run_hidden(
            ["git", "tag", "--list", "v*", "--sort=-v:refname"],
            capture_output=True, text=True, timeout=10, cwd=str(repo_root),
        )
    except Exception:
        return None
    if r.returncode != 0:
        return None
    for line in (r.stdout or "").splitlines():
        line = line.strip()
        if _VERSION_TAG_RE.match(line):
            return line
    return None


@check(id="hygiene.runtime-version", severity="medium")
def hygiene_runtime_version(context: CheckContext) -> "list[Finding]":
    if context.workspace is None:
        return []  # no product-repo root to hand — never guess (§10.3's spirit applied here too)

    installed = _installed_version()
    installed_t = _version_tuple(installed) if installed else None
    if installed_t is None:
        return []

    repo_root = Path(context.workspace)
    if not (repo_root / ".git").exists():
        return []
    latest_tag = _latest_git_tag(repo_root)
    if latest_tag is None:
        return []

    latest_t = _version_tuple(latest_tag)
    if latest_t is None or latest_t <= installed_t:
        return []  # up to date, or ahead (a dev/pre-release install) — nothing to report

    status = get_dispatcher_status(context.artefact_root)
    fleet_state = status.get("state", "UNKNOWN")

    return [
        Finding(
            check_id="hygiene.runtime-version",
            subject_id="runtime:mso",
            severity="medium",
            title=f"Installed mso v{installed} is behind the repo's newest tag {latest_tag}",
            detail=(
                f"The running install (v{installed}) is behind {latest_tag} — fleet is "
                f"currently {fleet_state}. This finding intentionally does NOT suggest a "
                "refresh command: the documented `pip install . --no-deps` refresh "
                "currently wipes the licence signing keyring and silently downgrades the "
                "install to community (BUG-MSO-2026-0503, still open). A refresh must wait "
                "for the fleet to be IDLE and follow CLAUDE.md's Phase 3b/3c procedure by "
                "hand — never while crews are RUNNING, and never via this finding alone."
            ),
            firstSeenAt=context.now.isoformat(),
            suggestedCommand=None,
            scope="workspace",
            requires=(),
        )
    ]


# ---------------------------------------------------------------------------
# hygiene.unreachable-crew-commits (BUG-MSO-2026-0706)
# ---------------------------------------------------------------------------

#: Order ids as they appear in a commit subject — `{TYPE}-{PRJ}-{YEAR}-{SEQ}`,
#: covering the legacy `ADM` acronym alongside `MSO` and any consumer project.
_ORDER_ID_IN_SUBJECT_RE = re.compile(r"\b([A-Z]{2,4}-[A-Z]{2,6}-\d{4}-\d{3,5})\b")

_LOOSE_DIR_RE = re.compile(r"^[0-9a-f]{2}$")
_LOOSE_FILE_RE = re.compile(r"^[0-9a-f]{38}$")

#: Hard ceilings. `mso doctor` must stay fast and must work with the
#: dispatcher stopped (§3) — a check that walks an entire object store on a
#: large repo is a check operators turn off. Both are generous next to what a
#: day of crew activity actually produces (measured on this workspace: ~4,800
#: loose objects in 7 days, of which ~360 are commits and a handful name an
#: order).
_MAX_LOOSE_OBJECTS = 20000
#: Capped at 250 for a second reason beyond runtime: the shas go on the
#: command line (``rev-list --no-walk <shas> --not --all``), and 250 * 41
#: chars leaves ample room under Windows' ~32k argv limit. Reading them from
#: `--stdin` instead would make the `--not --all` exclusion's association with
#: the positive revs ambiguous, which is a worse trade than a cap.
_MAX_REACHABILITY_PROBES = 250


def _git(repo_root: Path, args: "list[str]", timeout: int = 30,
         stdin_text: Optional[str] = None):
    """Run git in *repo_root*; return the CompletedProcess or None. Never raises."""
    try:
        kwargs = dict(capture_output=True, text=True, timeout=timeout,
                      cwd=str(repo_root))
        if stdin_text is not None:
            kwargs["input"] = stdin_text
        return run_hidden(["git", *args], **kwargs)
    except Exception:
        return None


def _git_common_dir(repo_root: Path) -> Optional[Path]:
    r = _git(repo_root, ["rev-parse", "--git-common-dir"], timeout=10)
    if r is None or r.returncode != 0:
        return None
    raw = (r.stdout or "").strip()
    if not raw:
        return None
    path = Path(raw)
    if not path.is_absolute():
        path = (repo_root / path).resolve()
    return path if path.exists() else None


def _recent_loose_shas(git_dir: Path, max_age_days: float) -> "list[str]":
    """Loose object shas touched within *max_age_days*, newest first.

    Deliberately mtime-filtered rather than exhaustive: the LEAD's hand
    recovery used exactly this signal, and it is what keeps the scan bounded
    on a repo with a long history.
    """
    objects = git_dir / "objects"
    if not objects.is_dir():
        return []
    cutoff = time.time() - (max_age_days * 86400)
    found: "list[tuple[float, str]]" = []
    try:
        entries = list(objects.iterdir())
    except OSError:
        return []
    for shard in entries:
        if not _LOOSE_DIR_RE.match(shard.name):
            continue
        try:
            children = list(shard.iterdir())
        except OSError:
            continue
        for obj in children:
            if not _LOOSE_FILE_RE.match(obj.name):
                continue
            try:
                mtime = obj.stat().st_mtime
            except OSError:
                continue
            if mtime < cutoff:
                continue
            found.append((mtime, shard.name + obj.name))
            if len(found) >= _MAX_LOOSE_OBJECTS:
                break
        if len(found) >= _MAX_LOOSE_OBJECTS:
            break
    found.sort(reverse=True)
    return [sha for _, sha in found]


def _known_order_ids(artefact_root: Path) -> "set[str]":
    """Every order id this workspace has on disk (queued, active or archived).

    Filenames only — no JSON is parsed. "Known" is the filter that separates a
    crew's lost commit from an ordinary unreferenced object, so it has to be
    cheap enough to run on every tick.
    """
    ids: "set[str]" = set()
    roots = [artefact_root / "queues", artefact_root / "orders"]
    for root in roots:
        if not root.is_dir():
            continue
        try:
            for path in root.rglob("*.json"):
                ids.add(path.stem)
        except OSError:
            continue
    return ids


def _commit_subjects(repo_root: Path, shas: "list[str]") -> "list[tuple[str, str, str]]":
    """``(sha, subject, iso-date)`` for every *sha* that is a commit object.

    Two batched git calls for the whole candidate set, never one per object:
    ``cat-file --batch-check`` to keep only commits, then ``log --stdin`` for
    their subjects.
    """
    if not shas:
        return []
    r = _git(repo_root, ["cat-file", "--batch-check"], timeout=60,
             stdin_text="\n".join(shas) + "\n")
    if r is None or r.returncode != 0:
        return []
    commits = []
    for line in (r.stdout or "").splitlines():
        parts = line.split()
        if len(parts) >= 2 and parts[1] == "commit":
            commits.append(parts[0])
    if not commits:
        return []
    r = _git(repo_root,
             ["log", "--no-walk", "--stdin", "--format=%H%x1f%s%x1f%aI"],
             timeout=60, stdin_text="\n".join(commits) + "\n")
    if r is None or r.returncode != 0:
        return []
    out: "list[tuple[str, str, str]]" = []
    for line in (r.stdout or "").splitlines():
        parts = line.split("\x1f")
        if len(parts) == 3:
            out.append((parts[0], parts[1], parts[2]))
    return out


def _unreachable_subset(repo_root: Path, shas: "list[str]") -> Optional[set]:
    """Which of *shas* no ref can reach — in ONE git call; None if unanswerable.

    ``rev-list --no-walk <shas> --not --all`` yields exactly the given commits
    that are not reachable from any branch, tag or remote-tracking ref.
    Deliberately batched: the obvious per-commit form
    (``for-each-ref --contains``) costs a full ref walk EACH TIME, and measured
    ~0.35s per probe on this workspace's few hundred refs — 14 s for one check
    on a command that runs twenty of them every LEAD tick. One call is ~0.4 s
    for the whole set.

    ``None`` is reported as nothing rather than as a finding: this check exists
    to end silent data loss, and a fabricated loss report would spend an
    operator's attention exactly as badly as a missed one.
    """
    if not shas:
        return set()
    r = _git(repo_root, ["rev-list", "--no-walk", *shas, "--not", "--all"],
             timeout=120)
    if r is None or r.returncode != 0:
        return None
    return {ln.strip() for ln in (r.stdout or "").splitlines() if ln.strip()}


@check(id="hygiene.unreachable-crew-commits", severity="high")
def hygiene_unreachable_crew_commits(context: CheckContext) -> "list[Finding]":
    if context.workspace is None:
        return []  # no product repo to read — skip rather than guess (§10.3)
    repo_root = Path(context.workspace)
    git_dir = _git_common_dir(repo_root)
    if git_dir is None:
        return []

    params = context.params_for("hygiene.unreachable-crew-commits")
    try:
        max_age_days = float(params.get("maxAgeDays", 7))
    except (TypeError, ValueError):
        max_age_days = 7.0
    if max_age_days <= 0:
        max_age_days = 7.0

    shas = _recent_loose_shas(git_dir, max_age_days)
    if not shas:
        return []

    known = _known_order_ids(context.artefact_root)
    if not known:
        return []

    # Group by order id, keeping the NEWEST commit per order — that is the tip
    # an operator pins, and pinning it keeps its ancestors alive too.
    by_order: "dict[str, list[tuple[str, str, str]]]" = {}
    for sha, subject, when in _commit_subjects(repo_root, shas):
        m = _ORDER_ID_IN_SUBJECT_RE.search(subject or "")
        if not m or m.group(1) not in known:
            continue
        by_order.setdefault(m.group(1), []).append((sha, subject, when))

    if not by_order:
        return []

    candidates = [e[0] for entries in by_order.values() for e in entries]
    unreachable = _unreachable_subset(repo_root, candidates[:_MAX_REACHABILITY_PROBES])
    if not unreachable:
        return []  # all reachable, or git could not answer — never guess

    findings: "list[Finding]" = []
    for order_id in sorted(by_order):
        entries = sorted(by_order[order_id], key=lambda e: e[2], reverse=True)
        orphans = [e for e in entries if e[0] in unreachable]
        if not orphans:
            continue
        tip_sha, tip_subject, tip_when = orphans[0]
        shown = "; ".join(f"{s[:8]} {subj}" for s, subj, _ in orphans[:5])
        more = f" (+{len(orphans) - 5} more)" if len(orphans) > 5 else ""
        findings.append(
            Finding(
                check_id="hygiene.unreachable-crew-commits",
                subject_id=order_id,
                severity="high",
                title=(f"{order_id}: {len(orphans)} committed crew commit(s) are "
                       "reachable from no ref"),
                detail=(
                    f"{len(orphans)} recent commit object(s) naming {order_id} exist in "
                    f"{git_dir} but are contained by no branch, remote-tracking ref or "
                    f"tag — the shape a discarded crew branch leaves behind "
                    f"(BUG-MSO-2026-0706). Newest: {tip_sha[:8]} at {tip_when}. "
                    f"Commits: {shown}{more}. "
                    "THIS WORK IS ONE `git gc` AWAY FROM GONE — git prunes unreachable "
                    "loose objects (default: after two weeks, immediately with "
                    "`--prune=now`), and an automatic gc can run behind any ordinary "
                    "git command. Pin the newest commit with the command below (its "
                    "ancestors are preserved with it), then hand it to the order with "
                    f"`mso order retry {order_id}`. Inspect first with "
                    f"`git show --stat {tip_sha[:8]}`."
                ),
                firstSeenAt=context.now.isoformat(),
                suggestedCommand=f"git branch salvage/{order_id}-{tip_sha[:8]} {tip_sha}",
                scope="workspace",
                requires=(),
            )
        )
    return findings
