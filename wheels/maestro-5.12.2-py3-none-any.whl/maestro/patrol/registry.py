"""maestro/patrol/registry.py — the check registry and Finding record.

PLAN-PLN-MSO-2026-0504 §8: "a check may never remediate." A check is a pure
function ``(context) -> list[Finding]``. ``CheckContext`` carries only
read-only inputs — there is no writer object anywhere in this module for a
check to be handed, which is what makes ``test_checks_have_no_writer``
enforceable rather than just documented convention.

Remediation is a *proposal* in the output (``Finding.suggestedCommand``),
surfaced by a human or a separately-banded LEAD action (§3.4) — never
performed by the check itself.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Optional, Sequence

# Ordered low -> high. Findings at "high" or above fail `mso doctor`'s exit
# code by default (§5.5 / FTR-MSO-2026-0531 acceptance criteria).
SEVERITIES = ("low", "medium", "high", "critical")


def severity_rank(severity: str) -> int:
    """Numeric rank for *severity* — unrecognised values sort as "low".

    Deliberately never a boolean comparison: age-escalation (a later order)
    and the exit-code gate both need an ordered scale, not a yes/no.
    """
    try:
        return SEVERITIES.index(severity)
    except ValueError:
        return 0


@dataclass(frozen=True)
class Finding:
    """One patrol finding. Immutable — a check builds these and returns them;
    nothing downstream mutates a Finding in place."""

    check_id: str
    subject_id: str
    severity: str
    title: str
    detail: str
    firstSeenAt: str
    suggestedCommand: Optional[str] = None
    scope: str = "workspace"
    requires: tuple = ()


@dataclass(frozen=True)
class CheckContext:
    """Read-only inputs handed to every check.

    No writer methods live here by design — a check that can mutate state is
    not a check (PLAN-PLN-MSO-2026-0504 §8). ``artefact_root`` is the ``.mso``
    directory to read; passing it explicitly (rather than each check
    re-resolving a global workspace) is what lets a ``--all-projects``
    invocation (§7 / FTR-MSO-2026-0535) run every check once per project
    without mutating process-wide state between projects.
    """

    artefact_root: Path
    now: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    # PLAN-PLN-MSO-2026-0504 §5 / FTR-MSO-2026-0531 handoff: the resolved
    # patrol definition's per-check `params` (plan order 2), keyed by check
    # id, so a check MAY consult its resolved thresholds without widening the
    # `(context) -> list[Finding]` signature.
    patrol_params: dict = field(default_factory=dict)
    # FTR-MSO-2026-0535: the PRODUCT-repo root (the `.mso` parent) — needed by
    # checks that resolve a provider (§10, e.g. `voyages.pr-ci-state`) or that
    # read the product repo directly (e.g. `hygiene.runtime-version`'s git-tag
    # lookup). ``None`` when the caller has no product-repo root to hand (e.g.
    # a unit test exercising a check in isolation) — such a check must skip
    # rather than guess, exactly like `resolve_patrol_definition`'s own
    # ``workspace=None`` degrade.
    workspace: Optional[Path] = None

    def params_for(self, check_id: str) -> dict:
        """This check's resolved `params` dict, or ``{}`` if none apply."""
        return self.patrol_params.get(check_id, {})


class CheckSkipped(Exception):
    """Raise from within a check to voluntarily report itself as skipped —
    never a pass, never a silent omission (PLAN-PLN-MSO-2026-0504 §10.3): a
    check that needs a provider (``scm``, ``ci``, ...) which is unconfigured,
    unavailable, or unknown raises this instead of returning ``[]``, which
    would otherwise be indistinguishable from "ran clean". Caught specially
    by :func:`maestro.patrol.run_patrol`, which records the message verbatim
    as a :class:`~maestro.patrol.SkippedCheck` reason rather than wrapping it
    in the generic "check raised ..." text used for a genuine bug.
    """


CheckFunc = Callable[[CheckContext], "list[Finding]"]


@dataclass(frozen=True)
class CheckSpec:
    id: str
    func: CheckFunc
    severity: str
    scope: str = "workspace"
    requires: tuple = ()


_REGISTRY: dict[str, CheckSpec] = {}


def check(id: str, severity: str, scope: str = "workspace",
          requires: Sequence[str] = ()) -> Callable[[CheckFunc], CheckFunc]:
    """Decorator registering a check function under *id*.

    *severity* is the check's default/shipped severity — a future patrol
    definition (plan order 2) may override it per-tier; the check itself
    never decides its own severity dynamically.

    BUG-MSO-2026-0675 F2: a check has no say over whether
    ``maestro.patrol.run_single_check`` filters its re-evaluation down to one
    ``subject_id`` — a prior ``subject_id_stable`` opt-in existed on
    ``CheckSpec``/here but was never read by ``run_single_check``, which
    decides per-subject filtering PURELY from ``_STABLE_SUBJECT_ID_RE``
    (patrol/__init__.py): a ``subject_id`` shaped like a bare order/voyage id
    (no ``:`` or ``=``) is treated as durable and filtered per-subject; an
    ephemeral/scoped id (``dispatcher:pid={pid}``, ``crews:all``) is not.
    Removed rather than wired up, since the regex already governs every
    check's behaviour correctly today (including the two that had opted in)
    and is the single, checkable source of truth — see that module's
    docstring for the full rationale.
    """

    def _decorate(func: CheckFunc) -> CheckFunc:
        if id in _REGISTRY:
            raise ValueError(f"duplicate patrol check id: {id!r}")
        _REGISTRY[id] = CheckSpec(
            id=id, func=func, severity=severity, scope=scope,
            requires=tuple(requires),
        )
        return func

    return _decorate


def all_checks() -> "list[CheckSpec]":
    """Every registered check, sorted by id for deterministic output order."""
    return sorted(_REGISTRY.values(), key=lambda spec: spec.id)


def get_check(check_id: str) -> Optional[CheckSpec]:
    return _REGISTRY.get(check_id)


def clear_registry() -> None:
    """Test-only: reset registration state between isolated test modules."""
    _REGISTRY.clear()
