# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""maestro/proc_identity.py — process-identity (PID + creation-time) helpers.

Promoted out of ``maestro/hub/daemon.py`` (BUG-MSO-2026-0424) so every
per-workspace daemon — the Hub, and now the LEAD resident agent
(PLAN-PLN-MSO-2026-0504 §3.1, FTR-MSO-2026-0536) — verifies liveness the
same way: a live process with the recorded PID AND a matching creation
time. A bare PID is not a stable identity (operating systems recycle PIDs),
and a process NAME match is worse still — the 2026-08-17 incident this
guards against was exactly that: MSO's dead dispatcher was judged alive
because a DIFFERENT fleet's dispatcher process satisfied a name-based
liveness check. Comparing (pid, create_time) makes a recycled PID or an
unrelated process's PID read as "not running" instead of "our process".

``maestro/hub/daemon.py`` keeps its own ``_is_hub_running`` wrapper (rather
than delegating to :func:`is_running` here) so its existing test suite's
``monkeypatch.setattr(daemon, "_process_create_time", ...)`` fixtures keep
working unchanged — those tests patch the NAME as it resolves in
``hub.daemon``'s own module globals, which only works if the function that
looks it up (``_is_hub_running``) is also defined there. New callers (LEAD)
have no such legacy coupling and should use :func:`is_running` directly.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Optional, Tuple


def process_create_time(pid: int) -> Optional[int]:
    """Return an opaque, stable process-creation-time token for *pid*, or
    ``None`` if no such process exists (or the value cannot be determined).

    The token is only ever compared for equality against another token
    produced by this same function, so its units/epoch are irrelevant — only
    that it is stable for the life of one process and differs for a recycled
    PID. Windows uses ``GetProcessTimes`` (100 ns ticks since 1601); POSIX
    reads ``/proc/<pid>/stat`` field 22 (starttime in clock ticks); systems
    without procfs (e.g. macOS) fall back to ``psutil`` if present.
    """
    if not pid or pid <= 0:
        return None
    try:
        if os.name == "nt":
            import ctypes
            from ctypes import wintypes
            PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            kernel32 = ctypes.windll.kernel32
            handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
            if not handle:
                return None
            try:
                creation = wintypes.FILETIME()
                exited = wintypes.FILETIME()
                kern = wintypes.FILETIME()
                user = wintypes.FILETIME()
                ok = kernel32.GetProcessTimes(
                    handle,
                    ctypes.byref(creation),
                    ctypes.byref(exited),
                    ctypes.byref(kern),
                    ctypes.byref(user),
                )
                if not ok:
                    return None
                return (creation.dwHighDateTime << 32) | creation.dwLowDateTime
            finally:
                kernel32.CloseHandle(handle)
        else:
            try:
                with open(f"/proc/{pid}/stat", "r", encoding="utf-8") as fh:
                    data = fh.read()
                # comm (field 2) may itself contain spaces/parens; it is wrapped
                # in parens, so split on the text AFTER the final ')'. In that
                # tail, field indices are: [0]=state (overall field 3) …
                # starttime is overall field 22 → tail index 19.
                tail = data[data.rfind(")") + 2:].split()
                # BUG-MSO-2026-0516 follow-up: a ZOMBIE is not running.
                # /proc/<pid>/stat survives until the parent reaps the child, so
                # a killed-but-unreaped process still reports a matching
                # starttime and would read as alive. That made hub stop_hub()
                # exhaust both its graceful and force-kill budgets and return
                # False for a daemon it had already killed. Production rarely
                # hits it (start_new_session detaches the terminal but does NOT
                # reparent to init, so the child only lingers while its spawner
                # lives); an in-process spawn-and-kill hits it every time, which
                # is why it failed on Linux CI and passed on Windows, where
                # there is no zombie state.
                if tail and tail[0] == "Z":
                    return None
                return int(tail[19])
            except (FileNotFoundError, ProcessLookupError, OSError, ValueError, IndexError):
                try:
                    import psutil  # type: ignore
                    return int(psutil.Process(pid).create_time() * 1_000_000)
                except Exception:
                    return None
    except (OSError, ValueError):
        return None


def read_identity_record(pid_file: Path) -> Optional[Tuple[int, Optional[int]]]:
    """Read a PID-identity record → ``(pid, recorded_create_time)`` or ``None``.

    Accepts both the current JSON form ``{"pid": N, "createTime": T}`` and a
    legacy bare-integer form (``recorded_create_time`` is then ``None``,
    which forces the identity check to fail — the safe outcome for an
    un-verifiable record).
    """
    if not pid_file.exists():
        return None
    try:
        raw = pid_file.read_text(encoding="utf-8").strip()
    except OSError:
        return None
    if not raw:
        return None
    try:
        obj = json.loads(raw)
        if isinstance(obj, dict):
            pid = int(obj.get("pid", 0))
            ct = obj.get("createTime")
            return (pid, int(ct) if ct is not None else None)
    except (ValueError, TypeError):
        pass
    # Legacy bare-integer form → PID with no recorded identity.
    try:
        return (int(raw), None)
    except ValueError:
        return None


def read_record_dict(pid_file: Path) -> Optional[dict]:
    """The FULL record as written, or ``None`` for a missing/legacy/corrupt
    file. :func:`read_identity_record` above is the identity-only view every
    liveness check uses; this is for callers that also wrote ``extra`` keys
    (BUG-MSO-2026-0712 — the Hub records its ``port`` and ``startedAt`` here
    so a later reader can probe the right port and report an uptime without
    a second state file to keep in sync with this one)."""
    if not pid_file.exists():
        return None
    try:
        obj = json.loads(pid_file.read_text(encoding="utf-8").strip() or "null")
    except (OSError, ValueError, TypeError):
        return None
    return obj if isinstance(obj, dict) else None


def write_identity_record(
    pid_file: Path,
    pid: int,
    create_time: Optional[int],
    extra: Optional[dict] = None,
) -> None:
    """Write ``{"pid": N, "createTime": T}``, plus any *extra* keys.

    ``extra`` never overwrites ``pid``/``createTime`` — those two ARE the
    identity every liveness check reads, and a caller's incidental metadata
    must not be able to shadow them. :func:`read_identity_record` ignores
    unknown keys, so adding them is invisible to existing readers.
    """
    record = {"pid": pid, "createTime": create_time}
    for key, value in (extra or {}).items():
        if key not in ("pid", "createTime"):
            record[key] = value
    pid_file.parent.mkdir(parents=True, exist_ok=True)
    pid_file.write_text(json.dumps(record), encoding="utf-8")


def is_running(pid_file: Path) -> Tuple[bool, Optional[int]]:
    """Identity-verified liveness for a PID-identity record at *pid_file*.

    Returns ``(running, pid)``. ``running`` is ``True`` only when the
    recorded PID belongs to a live process whose creation time matches the
    recorded identity. A recycled PID (same number, different — later —
    process), a different process entirely (e.g. a different fleet's
    dispatcher, the 2026-08-17 failure class), or a legacy record with no
    recorded identity is classified as NOT running, so no termination
    signal is ever sent to an unrelated process.
    """
    rec = read_identity_record(pid_file)
    if rec is None:
        return (False, None)
    pid, recorded_ct = rec
    if not pid or pid <= 0 or recorded_ct is None:
        return (False, pid or None)
    current_ct = process_create_time(pid)
    if current_ct is None or current_ct != recorded_ct:
        return (False, pid)
    return (True, pid)
