"""
maestro/demo.py — `mso demo`: Squad Monitor dashboard PVT.

A production verification test for the v5.0 dashboard. Creates a demo voyage
with 6 demo orders (2× 20s, 2× 40s, 2× 60s) and drives them through 3
simulated crew slots on a staggered schedule, writing the SAME workspace
state files a real fleet writes. At order pickup only the order's queue JSON
and a lifecycle event are written; crew state.json, activity.txt, and usage
files are written at COMPLETE (and, in non-headless mode, on each per-tick
RUNNING snapshot in between — see below). BUG-MSO-2026-0655 F4: this
docstring used to claim the crew state.json/activity.txt/usage files were
also written "at order pickup", which the pickup code (`_drive_order`) does
not do.

In the default (non-headless) mode the live dashboard also renders
in-process while the simulation runs, driven by an additional per-tick
RUNNING snapshot write (same state.json/activity.txt/usage files, mid-flight
values) so every dashboard metric is exercised:

  - voyage progress bar + ETA draining 0/6 → 6/6
  - RUNNING crews with iteration bars, live turn counters, files, tokens, ETAs
  - COMPLETE transitions with durations, IDLE slots, staggered pickup
  - a mid-run ESCALATION that appears and resolves
  - a mid-run PENDING REVIEW item that appears and clears
  - QUEUE drain with role breakdown, LIFECYCLE events, SPEND line, footer counts

`--headless` (CI/PVT mode) skips that per-tick RUNNING write — there is no
dashboard watching it — and only the pickup/COMPLETE state writes above
happen; the PVT report's "RUNNING metrics" coverage line reflects this and
is only ticked when the per-tick write actually ran.

While the simulation runs, the demo gathers REAL local findings — an OWASP
pattern scan of the project's Python files, an outstanding-backlog review,
and a last-activity summary — and folds them into the final PVT report at
.mso/reports/demo/.

Everything the demo creates is removed afterwards; pre-existing crew state
files are backed up and restored byte-for-byte. No git mutations, no Claude
invocations, no token spend.
"""

from __future__ import annotations

import json
import os
import threading
import time
import traceback
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from maestro.core.lifecycle_log import sanitize_lifecycle_message  # BUG-MSO-2026-0474: one-line-per-event guard
from maestro.workspace import get_artefact_root  # BUG-MSO-2026-0425: demo artefact plane

DEMO_PROJECT = "DEMO"
DEMO_BUDGET_USD = 5.00          # synthetic budget for the SPEND line
TOLERANCE = 0.35                # PVT pass band: actual within ±35% of planned
# BUG-MSO-2026-0629 / 0649 tried to widen this band for the shortest simulated
# order (20s base -> 0.4s at the FAST test scale) with a separate absolute
# floor, MIN_ABS_DRIFT_SECONDS, evaluated via max() alongside the percentage
# term. BUG-MSO-2026-0652 removed it: planned_seconds is ALWAYS
# ctx.scaled(20|40|60), so the percentage term is always 0.35 * 20 * scale =
# 7*scale at minimum, while any floor scaled the same way (BUG-0649) is a
# FIXED FRACTION of that percentage term at every scale — it can never be the
# max()-winner, at any time_scale, for any order. An unscaled floor (the
# original BUG-0629 shape) large enough to ever win at FAST scale (>0.14s,
# 35% of the 0.4s shortest order) is large enough to pass a genuine ~50%
# regression of that same order silently — the exact failure BUG-0649 was
# filed to close. There is no floor value that is both reachable and safe.
#
# Direct measurement of the real headless tick loop (maestro/demo.py's
# _drive_order, including live coverage.py tracing — the condition
# sys.settrace(None) was dropped for in _crew_thread, see BUG-MSO-2026-0645)
# across 8 full runs / 48 simulated orders put the worst observed drift for
# the 0.4s (shortest) order at ~10% of planned — see the
# BUG-MSO-2026-0652 handoff for the measurement script and raw numbers. That
# leaves 3-4x headroom under the existing 35% band with no extra mechanism.
# The percentage band alone is the tolerance model; nothing else is needed.

# Crew slot → list of (role, type, planned seconds, title, activity script)
# 6 orders: 2× 20s, 2× 40s, 2× 60s across 3 crews, two waves each.
DEMO_PLAN: Dict[int, List[dict]] = {
    1: [
        {"role": "SEC", "type": "SEC", "seconds": 20,
         "title": "Security review of the application (OWASP pattern scan)",
         "activities": [
             "Scanning Python sources for OWASP patterns",
             "Checking secret/credential patterns",
             "Compiling severity counts",
         ]},
        {"role": "BLD", "type": "FTR", "seconds": 60,
         "title": "Demo build task — simulated implementation flow",
         "activities": [
             "Reading plan and acceptance criteria",
             "Editing demo module (simulated)",
             "Running unit tests (simulated)",
             "Committing work to demo branch (simulated)",
         ]},
    ],
    2: [
        {"role": "PLN", "type": "PLN", "seconds": 40,
         "title": "Review outstanding tickets, orders and bugs",
         "activities": [
             "Scanning queues for PENDING orders",
             "Reviewing bug queue ages",
             "Drafting backlog recommendations",
         ]},
        {"role": "TST", "type": "TST", "seconds": 40,
         "title": "Demo verification task — simulated QA flow",
         "activities": [
             "Collecting changed files",
             "Executing verification suite (simulated)",
             "Writing QA verdict",
         ]},
    ],
    3: [
        {"role": "DOC", "type": "DOC", "seconds": 20,
         "title": "Report last fleet activity",
         "activities": [
             "Tailing lifecycle log",
             "Summarising recent completions",
         ]},
        {"role": "REL", "type": "REL", "seconds": 60,
         "title": "Compile PVT report and recommended tasks",
         "activities": [
             "Aggregating PVT metrics",
             "Composing recommendations",
             "Finalising demo report",
         ]},
    ],
}

STAGGER_SECONDS = 4             # delay between crew starts (shows pickup flow)
ORDER_GAP_SECONDS = 4           # idle gap between a crew's two orders
ESCALATION_AT = 12              # T+12s: escalation appears
ESCALATION_RESOLVE_AT = 34      # T+34s: escalation resolves (visible ~22s)
REVIEW_AT = 22                  # T+22s: pending-review item appears
REVIEW_CLEAR_AT = 50            # T+50s: review item clears


# ---------------------------------------------------------------------------
# Lifecycle log (same format as fleet_runner.write_lifecycle_event)
# ---------------------------------------------------------------------------

def _write_lifecycle(event_type: str, message: str) -> None:
    """BUG-MSO-2026-0474: *message* is sanitized to a single physical line,
    matching every other lifecycle writer."""
    log_dir = get_artefact_root() / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(str(log_dir / "lifecycle.log"), "a", encoding="utf-8") as f:
        f.write(f"{timestamp} | {event_type:<10} | {sanitize_lifecycle_message(message)}\n")


def _log_exc(prefix: str, suffix: str, exc: BaseException) -> None:
    """BUG-MSO-2026-0654 F3: a genuine exception used to reach lifecycle.log
    (and the console, via `crash_detail`) as only `repr(exc)` — no frame,
    file, or line survived, because `except (KeyboardInterrupt, Exception)`
    widened the catch without ever importing `traceback`. Preserve the raise
    site (and the full trace, subject to the sanitizer's existing one-line/
    500-char cap like any other lifecycle message) for anything that isn't a
    plain Ctrl+C, which carries no useful trace of its own."""
    if isinstance(exc, KeyboardInterrupt):
        _write_lifecycle("WARN", f"{prefix} ({exc!r}) — {suffix}")
        return
    tb = traceback.extract_tb(exc.__traceback__)
    location = f"{tb[-1].filename}:{tb[-1].lineno} in {tb[-1].name}" if tb else "?"
    trace_text = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
    _write_lifecycle("WARN", f"{prefix} ({exc!r}) at {location} — {suffix}\n{trace_text}")


# ---------------------------------------------------------------------------
# Demo artefact bookkeeping
# ---------------------------------------------------------------------------

@dataclass
class OrderRun:
    """One demo order's identity, schedule, and observed PVT timings."""
    order_id: str
    role: str
    crew: int
    planned_seconds: float
    title: str
    activities: List[str]
    started_at: Optional[float] = None      # time.monotonic()
    completed_at: Optional[float] = None
    final_tokens: int = 0
    final_cost: float = 0.0
    final_files: int = 0
    final_iter: int = 0

    @property
    def actual_seconds(self) -> Optional[float]:
        if self.started_at is None or self.completed_at is None:
            return None
        return self.completed_at - self.started_at


@dataclass
class DemoContext:
    """Shared state across the demo run: paths created, backups, results."""
    mso: Path
    voyage_id: str = ""
    time_scale: float = 1.0
    headless: bool = False
    orders: List[OrderRun] = field(default_factory=list)
    created_paths: List[Path] = field(default_factory=list)
    crew_backups: Dict[Path, Optional[bytes]] = field(default_factory=dict)
    stop: threading.Event = field(default_factory=threading.Event)
    lock: threading.Lock = field(default_factory=threading.Lock)
    coverage: Dict[str, bool] = field(default_factory=dict)
    findings: Dict[str, object] = field(default_factory=dict)
    t0: float = 0.0

    def scaled(self, seconds: float) -> float:
        return seconds * self.time_scale

    def track(self, path: Path) -> Path:
        """Register a path for cleanup."""
        if path not in self.created_paths:
            self.created_paths.append(path)
        return path

    def demo_spend(self) -> float:
        return round(sum(o.final_cost for o in self.orders), 2)


# ---------------------------------------------------------------------------
# Safety checks
# ---------------------------------------------------------------------------

def check_fleet_idle(mso: Path) -> Optional[str]:
    """Return a refusal reason if a real fleet is active, else None."""
    from maestro.core.fleet_monitor import is_process_alive, load_json_safe

    pid_file = mso / "dispatcher.pid"
    if pid_file.exists():
        try:
            pid = int(pid_file.read_text(encoding="utf-8").strip())
            if is_process_alive(pid):
                return (f"the dispatcher is running (PID {pid}). "
                        "Stop it first — the demo writes to the same crew state files.")
        except (ValueError, OSError):
            pass

    # BUG-MSO-2026-0655 F1: the crew-slot RUNNING/ACTIVE scan below is BLIND
    # to a concurrent HEADLESS `mso demo` — headless mode never writes a
    # RUNNING/ACTIVE state.json mid-run (see _write_live_tick's call site in
    # _drive_order, skipped entirely `if not ctx.headless`, by design per
    # BUG-MSO-2026-0629/0645). Two overlapping headless runs previously went
    # fully undetected by this guard and would cross-restore each other's
    # backup_crew_state() snapshots over the operator's real crew files at
    # cleanup time. A dedicated demo.pid lock does not depend on what the
    # other run is currently writing to crew state — only that a demo
    # process is alive — so it covers headless, non-headless, and any mix.
    #
    # BUG-MSO-2026-0659 F1: this is a fast, FRIENDLY pre-check only — a plain
    # read with no claim — so a racing second run can still slip past it and
    # reach run_demo()'s actual lock acquisition. `_acquire_demo_lock()` is
    # the real gate (O_CREAT|O_EXCL, so at most one racing claim can ever
    # win); this check exists purely to give a clean early refusal message
    # in the common (non-racing) case before any backup/artefact work starts.
    demo_pid_file = mso / "demo.pid"
    if demo_pid_file.exists():
        try:
            pid = int(demo_pid_file.read_text(encoding="utf-8").strip())
            if is_process_alive(pid):
                return (f"another `mso demo` is already running (PID {pid}). "
                        "Only one demo can run at a time — it shares crew "
                        "slots 1-3 with any other demo or real dispatch. If no "
                        "demo is actually running and this PID was recycled by "
                        "an unrelated process, run 'mso cleanup --force' to "
                        "clear the stale demo.pid lock (BUG-MSO-2026-0683 F4).")
        except (ValueError, OSError):
            pass

    for slot in (1, 2, 3):
        state = load_json_safe(mso / "crews" / f"crew{slot}" / "state.json") or {}
        if state.get("status") in ("RUNNING", "ACTIVE"):
            pid = state.get("pid")
            if pid and is_process_alive(pid):
                return (f"crew {slot} is RUNNING (PID {pid}). "
                        "The demo needs crew slots 1-3 idle.")
    return None


def _acquire_demo_lock(mso: Path) -> Optional[str]:
    """Atomically claim demo.pid. Returns a refusal reason if a live demo
    already holds it, else None — the lock is now held by this process.

    BUG-MSO-2026-0659 F1: closes a genuine cross-restore race in the
    previous acquisition (a plain `write_text()` call after
    `check_fleet_idle()`'s own non-atomic read of the same file). Two `mso
    demo` runs starting close together could both observe no live demo.pid
    in `check_fleet_idle()`, then both `write_text()` the lock — the second
    silently overwriting the first's pid with no error — so the FIRST
    process's eventual `cleanup()` unlinked a file that no longer named it,
    releasing a lock the SECOND process still believed it held exclusively.
    `O_CREAT|O_EXCL` makes the actual claim atomic: at most one of two
    racing opens can ever succeed.

    BUG-MSO-2026-0659 F4: a lock left behind by an unclean kill (SIGKILL,
    crash, power loss — the residual exposure the BUG-MSO-2026-0655 audit
    note itself named) must not permanently wedge every future `mso demo`
    once the pid is recycled. On a losing `FileExistsError`, validate the
    recorded pid's liveness — the same "trust a live PID, not a file's mere
    existence" rule `check_fleet_idle()` already applies to crew state — and
    clear + retry once if it is stale, rather than refusing forever.

    BUG-MSO-2026-0667 F5: `O_CREAT|O_EXCL` made the CREATE atomic, but the
    CLAIM was not — the pid was written via a separate `os.fdopen(fd,
    "w").write(...)` call, so a window existed where `lock_path` existed but
    was still empty. A racing second claimant hitting `FileExistsError` in
    that window would read the empty file, fail to parse a pid,
    `existing_pid = None`, and fall through to the "stale, clear it" branch
    below — unlinking a lock that was not stale at all, just mid-
    construction, and creating its own lock so BOTH demos ran concurrently.
    Fixed two ways: the pid bytes are now written with a single `os.write()`
    directly on the just-opened fd before it is closed, shrinking the empty-
    file window to the smallest an implementation at this level can manage;
    and — the actual atomicity fix — an unparseable/empty existing lock is
    no longer treated as evidence of staleness at all. Only a lock naming a
    pid `is_process_alive()` can affirmatively confirm is DEAD is ever
    cleared; a lock this process cannot verify is held-but-unreadable, not
    abandoned, and is refused rather than silently recycled.
    """
    from maestro.core.fleet_monitor import is_process_alive

    lock_path = mso / "demo.pid"
    cleared_once = False
    while True:
        try:
            fd = os.open(str(lock_path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except FileExistsError:
            try:
                existing_pid = int(lock_path.read_text(encoding="utf-8").strip())
            except (ValueError, OSError):
                # Unreadable/empty/partial content is NOT proof of
                # abandonment — it is exactly what a lock mid-construction
                # by a racing claimant looks like. Treat as held, not stale.
                return ("could not verify the demo lock (demo.pid) — it exists "
                        "but its contents could not be read. If no `mso demo` "
                        "is actually running, remove it manually and retry.")
            if is_process_alive(existing_pid):
                return (f"another `mso demo` is already running (PID {existing_pid}). "
                        "Only one demo can run at a time — it shares crew "
                        "slots 1-3 with any other demo or real dispatch. If no "
                        "demo is actually running and this PID was recycled by "
                        "an unrelated process, run 'mso cleanup --force' to "
                        "clear the stale demo.pid lock (BUG-MSO-2026-0683 F4).")
            if cleared_once:
                return "could not acquire the demo lock (demo.pid) — try again."
            cleared_once = True
            # BUG-MSO-2026-0673 F2: re-confirm the file still names the SAME
            # dead pid immediately before unlinking it. Two runs racing over
            # one stale lock can otherwise each independently reach this
            # point believing the SAME dead pid is what's on disk — but a
            # racing claimant may have already unlinked that stale lock and
            # replaced it with its own fresh, LIVE one in the window between
            # our read above and this unlink. Unlinking unconditionally would
            # delete that fresh lock instead of the stale one we inspected,
            # so BOTH racers loop back, both find the file gone, and both
            # win the next os.open() — exactly the cross-restore corruption
            # this lock exists to prevent. This is the same class of bug as
            # BUG-MSO-2026-0665 F1, BUG-MSO-2026-0668 F1, BUG-MSO-2026-0669
            # and BUG-MSO-2026-0672 F3: acting on a belief without
            # re-confirming it still holds at the moment of acting.
            try:
                current = lock_path.read_text(encoding="utf-8").strip()
            except OSError:
                current = None
            if current == str(existing_pid):
                try:
                    lock_path.unlink()
                except OSError:
                    pass
            # else: someone else already replaced (or removed) this exact
            # stale lock — leave whatever is there now alone and let the
            # next loop iteration re-evaluate it fresh.
            continue
        else:
            try:
                os.write(fd, str(os.getpid()).encode("utf-8"))
            finally:
                os.close(fd)
            return None


def _post_claim_dispatcher_refusal(mso: Path) -> Optional[str]:
    """Return a refusal reason if dispatcher.pid now names a live (or
    unverifiable) dispatcher, re-checked immediately after `run_demo()`
    claims its own demo.pid lock — else None.

    BUG-MSO-2026-0691 F1: `run_dispatcher()` re-checks `_demo_lock_refusal_
    reason()` right after claiming dispatcher.pid (BUG-MSO-2026-0685 F5) —
    closing the race where a demo's claim lands in the gap between the
    dispatcher's pre-claim demo.pid probe and its own lock write. `run_demo()`
    never got the mirror: `check_fleet_idle()` reads dispatcher.pid only
    ONCE, before `_acquire_demo_lock()` is even called, and never again. A
    dispatcher whose own claim lands in THAT gap runs CONCURRENTLY with the
    demo, sharing crew slots 1-3, and this demo's eventual `cleanup()`
    restores its pre-demo crew-state snapshot OVER the live fleet the
    dispatcher just started managing — the exact corruption both locks
    exist to prevent, from the other direction.

    Per BUG-MSO-2026-0669, an unparseable/empty lock is treated as HELD, not
    absent — it is exactly what a lock mid-construction by a racing
    dispatcher looks like, not proof no dispatcher is starting.
    """
    from maestro.core.fleet_monitor import is_process_alive

    dispatcher_lock = mso / "dispatcher.pid"
    if not dispatcher_lock.exists():
        return None
    try:
        pid = int(dispatcher_lock.read_text(encoding="utf-8").strip())
    except (ValueError, OSError):
        return (
            "could not verify the dispatcher lock (dispatcher.pid) — it "
            "exists but its contents could not be read. This is treated as "
            "held, not stale (BUG-MSO-2026-0669): if no dispatcher is "
            "actually running, run 'mso cleanup --force' to clear the "
            "unreadable lock (BUG-MSO-2026-0691 F7), then retry."
        )
    if is_process_alive(pid):
        return (
            f"the dispatcher started running (PID {pid}) while the demo "
            "lock was being claimed. Stop it first — the demo writes to "
            "the same crew state files."
        )
    return None


def _release_demo_lock(mso: Path) -> None:
    """Release demo.pid only if it still names THIS process.

    BUG-MSO-2026-0659 F1: the previous `cleanup()` unlinked demo.pid
    unconditionally, with no ownership check — if a second demo's
    `_acquire_demo_lock()` had already overwritten the file (a race the
    atomic acquire above now prevents, but defence in depth costs nothing
    here), an unconditional unlink would release a lock a NEWER demo still
    believes it holds exclusively.
    """
    lock_path = mso / "demo.pid"
    try:
        held_pid = int(lock_path.read_text(encoding="utf-8").strip())
    except (ValueError, OSError):
        return
    if held_pid == os.getpid():
        try:
            lock_path.unlink()
        except OSError:
            pass


# ---------------------------------------------------------------------------
# Setup: demo voyage + orders + crew-state backups
# ---------------------------------------------------------------------------

def _next_demo_seq(mso: Path, year: int) -> int:
    """First sequence number with no existing *-DEMO-{year}-* collisions."""
    import re
    pattern = re.compile(rf"-{DEMO_PROJECT}-{year}-(\d{{4}})")
    highest = 0
    for sub in ("queues/orders", "orders/complete", "voyages/active",
                "voyages/complete", "usage/orders"):
        d = mso / sub
        if d.exists():
            for f in d.glob(f"*-{DEMO_PROJECT}-{year}-*.json"):
                m = pattern.search(f.stem)
                if m:
                    highest = max(highest, int(m.group(1)))
    return highest + 1


_CREW_FILES = ("state.json", "activity.txt", "activity.jsonl",
               "ralph-state.md", "progress.md")


def backup_crew_state(ctx: DemoContext) -> None:
    """Snapshot crew slot 1-3 files so cleanup can restore them byte-for-byte."""
    for slot in (1, 2, 3):
        crew_dir = ctx.mso / "crews" / f"crew{slot}"
        for name in _CREW_FILES:
            path = crew_dir / name
            ctx.crew_backups[path] = path.read_bytes() if path.exists() else None
            # Stale ralph-state.md would override the demo's iteration counter
            # in the dashboard's collector — clear it for the run.
            if name in ("ralph-state.md",) and path.exists():
                path.unlink()


def create_demo_artefacts(ctx: DemoContext) -> None:
    """Materialise the demo voyage + 6 queued orders."""
    year = datetime.now().year
    seq = _next_demo_seq(ctx.mso, year)
    ctx.voyage_id = f"VOY-{DEMO_PROJECT}-{year}-{seq:04d}"
    voyage_branch = f"demo/{ctx.voyage_id}"

    queues_dir = ctx.mso / "queues" / "orders"
    queues_dir.mkdir(parents=True, exist_ok=True)

    order_entries = []
    n = 0
    for crew_slot, plan in DEMO_PLAN.items():
        for spec in plan:
            n += 1
            order_id = f"{spec['type']}-{DEMO_PROJECT}-{year}-{seq + n:04d}"
            run = OrderRun(
                order_id=order_id,
                role=spec["role"],
                crew=crew_slot,
                planned_seconds=ctx.scaled(spec["seconds"]),
                title=spec["title"],
                activities=spec["activities"],
            )
            ctx.orders.append(run)
            order_json = {
                "id": order_id,
                "orderId": order_id,
                "type": spec["type"],
                "project": DEMO_PROJECT,
                "title": spec["title"],
                "status": "PENDING",
                "priority": "NORMAL",
                "role": spec["role"],
                "targetRole": spec["role"],
                "roleSequence": [spec["role"]],
                "voyageId": ctx.voyage_id,
                "voyageBranch": voyage_branch,
                "demo": True,
            }
            path = ctx.track(queues_dir / f"{order_id}.json")
            path.write_text(json.dumps(order_json, indent=2), encoding="utf-8")
            order_entries.append({"orderId": order_id, "status": "PENDING",
                                  "title": spec["title"]})

    voyage = {
        "id": ctx.voyage_id,
        "voyageId": ctx.voyage_id,
        "project": DEMO_PROJECT,
        "title": "Squad Monitor PVT — dashboard demo voyage",
        "status": "active",
        "createdAt": datetime.now().isoformat(),
        "orders": order_entries,           # dict shape — exercises that parser
        "voyageBranch": voyage_branch,
        "demo": True,
    }
    voyages_dir = ctx.mso / "voyages" / "active"
    voyages_dir.mkdir(parents=True, exist_ok=True)
    vpath = ctx.track(voyages_dir / f"{ctx.voyage_id}.json")
    vpath.write_text(json.dumps(voyage, indent=2), encoding="utf-8")

    # Mark the order-complete archive dir for cleanup tracking
    (ctx.mso / "orders" / "complete").mkdir(parents=True, exist_ok=True)

    _write_lifecycle("DEMO", f"PVT demo started — {ctx.voyage_id} (6 orders, 3 crews)")


# ---------------------------------------------------------------------------
# Simulated crew driver
# ---------------------------------------------------------------------------

def _update_voyage_order_status(ctx: DemoContext, order_id: str, status: str) -> None:
    vpath = ctx.mso / "voyages" / "active" / f"{ctx.voyage_id}.json"
    with ctx.lock:
        try:
            data = json.loads(vpath.read_text(encoding="utf-8"))
            for entry in data.get("orders", []):
                if entry.get("orderId") == order_id:
                    entry["status"] = status
            vpath.write_text(json.dumps(data, indent=2), encoding="utf-8")
        except (OSError, json.JSONDecodeError):
            pass


def _write_live_tick(state_file: Path, activity_file: Path, usage_file: Path,
                     run: OrderRun, frac: float, max_iter: int, max_turns: int,
                     started: datetime, files: int, tokens: int,
                     cost: float) -> None:
    """One live-dashboard RUNNING snapshot: state/activity/usage.

    Only called from the non-headless tick loop in `_drive_order` — extracted
    (BUG-MSO-2026-0645) so it has direct unit coverage independent of the
    headless-only test suite, which otherwise never executes it at all.
    """
    iteration = max(1, round(frac * max_iter))
    live_turn = max(1, round(frac * max_turns))
    state = {
        "status": "RUNNING",
        "role": run.role,
        "orderId": run.order_id,
        "iteration": iteration,
        "maxIterations": max_iter,
        "liveTurn": live_turn,
        "maxTurns": max_turns,
        "subagentCount": 0,
        "startTime": started.isoformat(),
        "filesChangedTotal": files,
        "pid": os.getpid(),
        "timeoutMinutes": 30,
        "demo": True,
    }
    state_file.write_text(json.dumps(state, indent=2), encoding="utf-8")
    activity = run.activities[min(len(run.activities) - 1,
                                  int(frac * len(run.activities)))]
    activity_file.write_text(activity, encoding="utf-8")
    usage_file.write_text(json.dumps({
        "orderId": run.order_id,
        "crewNumber": run.crew,
        "timestamp": datetime.now().isoformat(),
        "total_tokens": tokens,
        "estimated_cost_usd": cost,
        "demo": True,
    }, indent=2), encoding="utf-8")


def _drive_order(ctx: DemoContext, crew_dir: Path, run: OrderRun) -> None:
    """Simulate one order: queue pickup → RUNNING ticks → COMPLETE + archive."""
    state_file = crew_dir / "state.json"
    activity_file = crew_dir / "activity.txt"
    queue_file = ctx.mso / "queues" / "orders" / f"{run.order_id}.json"
    usage_file = ctx.mso / "usage" / "orders" / f"{run.order_id}.json"
    usage_file.parent.mkdir(parents=True, exist_ok=True)
    ctx.track(usage_file)

    duration = run.planned_seconds
    max_iter = max(3, int(run.planned_seconds / ctx.time_scale / 5))  # ~1 iter / 5s
    max_turns = max_iter * 8
    # BUG-MSO-2026-0611: the floor used to be 0.2s regardless of time_scale.
    # At real-time scale (interactive dashboard, time_scale=1.0) that's a
    # no-op — ctx.scaled(1.0) is already >= 0.2 there, so this floor only
    # ever bound the HEADLESS/test path. At the test's FAST=0.02 scale the
    # shortest simulated order (20s -> 0.4s) got only ~2 ticks against that
    # 0.2s floor, leaving near-zero margin against ordinary thread-scheduler
    # jitter (e.g. coverage.py's tracer overhead in CI) before a single
    # delayed tick blew the PVT's 35% drift tolerance. Flooring at 0.02s
    # instead (same granularity as the compressed time unit itself) gives
    # that order ~20 ticks and shrinks worst-case overshoot proportionally,
    # while leaving the interactive cadence (time_scale=1.0) unchanged.
    tick = max(0.02, ctx.scaled(1.0))
    started = datetime.now()
    run.started_at = time.monotonic()

    # Queue order → IN_PROGRESS (drains the PENDING count on the dashboard)
    try:
        oj = json.loads(queue_file.read_text(encoding="utf-8"))
        oj["status"] = "IN_PROGRESS"
        queue_file.write_text(json.dumps(oj, indent=2), encoding="utf-8")
    except (OSError, json.JSONDecodeError):
        pass
    _update_voyage_order_status(ctx, run.order_id, "IN_PROGRESS")
    _write_lifecycle("DISPATCH", f"[DEMO] crew{run.crew} picked up {run.order_id} ({run.role})")

    elapsed = 0.0
    files = 0
    tokens = 0
    cost = 0.0
    while elapsed < duration and not ctx.stop.is_set():
        frac = min(1.0, elapsed / duration)
        if int(elapsed) % 7 == 3:
            files += 1
        tokens = int(frac * run.planned_seconds / ctx.time_scale * 950)
        cost = round(tokens / 1_000_000 * 12.0, 4)

        # BUG-MSO-2026-0629: these per-tick writes exist ONLY to feed the live
        # Rich dashboard (`frame()` in run_demo, non-headless path) — headless
        # mode never reads them mid-run. The final COMPLETE state below (and
        # the unconditional usage write alongside it, BUG-MSO-2026-0645) and
        # the in-memory tokens/cost/files bookkeeping above (kept unconditional)
        # are what actually feed the PVT report. But this loop's own
        # wall-clock timing is exactly what evaluate_pvt() checks against a
        # drift tolerance, at a compressed test scale where the shortest order
        # is well under a second — three synchronous disk writes + JSON
        # encodes per tick, times up to 4 concurrently ticking threads, is
        # real self-inflicted GIL/IO contention with no payoff in headless
        # mode. BUG-MSO-2026-0611 widened the tick floor instead of removing
        # this write volume, and the flakiness recurred within days. Skip the
        # writes entirely when headless instead of doing them faster.
        if not ctx.headless:
            _write_live_tick(state_file, activity_file, usage_file, run,
                              frac, max_iter, max_turns, started, files,
                              tokens, cost)
            # BUG-MSO-2026-0649: mark coverage only when the write actually
            # ran — headless skips this call entirely, and evaluate_pvt used
            # to green-tick "RUNNING metrics" from in-memory final_tokens
            # regardless, so a break in this write path would pass the PVT
            # silently. A concurrent dict assignment across crew threads is
            # safe under the GIL; only ever set to True.
            ctx.coverage["running_metrics"] = True

        ctx.stop.wait(tick)
        elapsed = time.monotonic() - run.started_at

    if ctx.stop.is_set():
        return

    # COMPLETE
    run.completed_at = time.monotonic()
    run.final_tokens, run.final_cost = tokens, cost
    run.final_files, run.final_iter = files, max_iter
    ended = datetime.now()
    state = {
        "status": "COMPLETE",
        "role": run.role,
        "orderId": run.order_id,
        "iteration": max_iter,
        "maxIterations": max_iter,
        "liveTurn": max_turns,
        "maxTurns": max_turns,
        "startTime": started.isoformat(),
        "endTime": ended.isoformat(),
        "filesChangedTotal": files,
        "pid": os.getpid(),
        "demo": True,
    }
    state_file.write_text(json.dumps(state, indent=2), encoding="utf-8")
    activity_file.write_text("Done", encoding="utf-8")
    # BUG-MSO-2026-0645: unconditional (unlike the per-tick write above, which
    # stays headless-skipped) — headless mode was left with NO usage write at
    # all, contradicting CLI-REFERENCE.md and this module's own docstring. One
    # write per order at COMPLETE is the same cost tier as the state/activity
    # writes on the two lines above and adds no per-tick contention.
    usage_file.write_text(json.dumps({
        "orderId": run.order_id,
        "crewNumber": run.crew,
        "timestamp": ended.isoformat(),
        "total_tokens": tokens,
        "estimated_cost_usd": cost,
        "demo": True,
    }, indent=2), encoding="utf-8")

    # Archive queue order → orders/complete (drains the queue file itself)
    complete_path = ctx.mso / "orders" / "complete" / f"{run.order_id}.json"
    try:
        oj = json.loads(queue_file.read_text(encoding="utf-8"))
        oj["status"] = "COMPLETE"
        oj["completedAt"] = ended.isoformat()
        complete_path.write_text(json.dumps(oj, indent=2), encoding="utf-8")
        ctx.track(complete_path)
        queue_file.unlink()
    except (OSError, json.JSONDecodeError):
        pass
    _update_voyage_order_status(ctx, run.order_id, "COMPLETE")
    _write_lifecycle("COMPLETE",
                     f"[DEMO] {run.order_id} complete on crew{run.crew} "
                     f"({run.actual_seconds:.0f}s)")


def _crew_thread(ctx: DemoContext, crew_slot: int) -> None:
    # BUG-MSO-2026-0629 disabled this thread's tracer (sys.settrace(None)) to
    # stop coverage.py / a debugger's per-instruction overhead from skewing
    # actual_seconds against planned_seconds. BUG-MSO-2026-0645: that also
    # silently killed coverage measurement for this thread's own statements
    # (92 lines lost under COVERAGE_CORE=ctrace) and would disable a real
    # user's profiler/debugger during an actual `mso demo`. The real
    # contention was the per-tick disk writes (now skipped in headless mode,
    # see _drive_order) and the findings scan racing these threads for the
    # GIL (now run after they join, see run_demo) — with those removed,
    # tracer overhead is no longer a contention source worth disabling
    # tracing globally for. BUG-MSO-2026-0652 measured it directly: a full
    # headless run under live coverage.py tracing (`python -m pytest --cov`'s
    # exact condition) drifts the shortest simulated order by ~10% of
    # planned in the worst case observed, comfortably inside evaluate_pvt's
    # 35% TOLERANCE band with no separate floor needed (see that constant's
    # comment — an earlier absolute-floor cushion here was removed because it
    # could never engage without also being large enough to mask a real
    # regression).
    crew_dir = ctx.mso / "crews" / f"crew{crew_slot}"
    crew_dir.mkdir(parents=True, exist_ok=True)

    # Staggered start so the dashboard shows crews picking up one by one
    ctx.stop.wait(ctx.scaled((crew_slot - 1) * STAGGER_SECONDS))

    runs = [o for o in ctx.orders if o.crew == crew_slot]
    for i, run in enumerate(runs):
        if ctx.stop.is_set():
            return
        _drive_order(ctx, crew_dir, run)
        if i < len(runs) - 1 and not ctx.stop.is_set():
            # Brief IDLE gap between the crew's orders
            (crew_dir / "state.json").write_text(
                json.dumps({"status": "IDLE", "demo": True}), encoding="utf-8")
            ctx.stop.wait(ctx.scaled(ORDER_GAP_SECONDS))
    # leave final COMPLETE state visible; cleanup restores the original


def _events_thread(ctx: DemoContext) -> None:
    """Mid-run escalation + pending-review items (appear, then clear)."""
    # BUG-MSO-2026-0645: see _crew_thread's comment — no sys.settrace(None)
    # here either, for the same reason (coverage + user tooling must not be
    # disabled).
    esc_dir = ctx.mso / "queues" / "escalations"
    rev_dir = ctx.mso / "queues" / "review"
    esc_path = esc_dir / f"ESC-{DEMO_PROJECT}-PVT-0001.json"
    rev_path = rev_dir / f"PLN-{DEMO_PROJECT}-PVT-0001.json"

    ctx.stop.wait(ctx.scaled(ESCALATION_AT))
    if ctx.stop.is_set():
        return
    esc_dir.mkdir(parents=True, exist_ok=True)
    ctx.track(esc_path).write_text(json.dumps({
        "id": f"ESC-{DEMO_PROJECT}-PVT-0001",
        "title": "Demo escalation — dashboard PVT (auto-resolves)",
        "status": "PENDING",
        "blocking": True,
        "demo": True,
    }, indent=2), encoding="utf-8")
    ctx.coverage["escalation_shown"] = True
    _write_lifecycle("WARN", "[DEMO] escalation raised (PVT — auto-resolves)")

    ctx.stop.wait(ctx.scaled(REVIEW_AT - ESCALATION_AT))
    if ctx.stop.is_set():
        return
    rev_dir.mkdir(parents=True, exist_ok=True)
    ctx.track(rev_path).write_text(json.dumps({
        "id": f"PLN-{DEMO_PROJECT}-PVT-0001",
        "voyageId": ctx.voyage_id,
        "navReviewPausedAt": datetime.now().isoformat(),
        "demo": True,
    }, indent=2), encoding="utf-8")
    ctx.coverage["review_shown"] = True

    ctx.stop.wait(ctx.scaled(ESCALATION_RESOLVE_AT - REVIEW_AT))
    if not ctx.stop.is_set() and esc_path.exists():
        try:
            data = json.loads(esc_path.read_text(encoding="utf-8"))
            data["status"] = "RESOLVED"
            esc_path.write_text(json.dumps(data, indent=2), encoding="utf-8")
            _write_lifecycle("DEMO", "[DEMO] escalation resolved")
        except (OSError, json.JSONDecodeError):
            pass

    ctx.stop.wait(ctx.scaled(REVIEW_CLEAR_AT - ESCALATION_RESOLVE_AT))
    if not ctx.stop.is_set() and rev_path.exists():
        try:
            rev_path.unlink()
        except OSError:
            pass


# ---------------------------------------------------------------------------
# Real findings (local, no Claude, no tokens)
# ---------------------------------------------------------------------------

def gather_security_findings(ctx: DemoContext, max_files: int = 40) -> None:
    """OWASP pattern scan over the project's Python files (capped for speed)."""
    try:
        from maestro.security.owasp_patterns import OWASPScanner
    except ImportError:
        ctx.findings["security"] = {"error": "OWASP scanner unavailable"}
        return

    root = ctx.mso.parent
    candidates: List[Path] = []
    for base in (root / "maestro", root / "src", root):
        if base.exists():
            candidates = [p for p in sorted(base.rglob("*.py"))
                          if "__pycache__" not in p.parts
                          and ".venv" not in p.parts][:max_files]
            if candidates:
                break

    scanner = OWASPScanner(language="python")
    findings = scanner.scan_files([str(p) for p in candidates])
    by_severity: Dict[str, int] = {}
    for f in findings:
        sev = getattr(getattr(f, "severity", None), "value", None) or str(
            getattr(f, "severity", "UNKNOWN"))
        by_severity[sev] = by_severity.get(sev, 0) + 1
    # Top distinct patterns with counts + one example site each
    grouped: Dict[str, dict] = {}
    for f in findings:
        title = getattr(f, "title", "?")
        entry = grouped.setdefault(title, {
            "name": title,
            "severity": getattr(getattr(f, "severity", None), "value", "?"),
            "count": 0,
            "file": getattr(f, "file", "?"),
            "line": getattr(f, "line", 0),
        })
        entry["count"] += 1
    top = sorted(grouped.values(), key=lambda e: -e["count"])[:5]
    ctx.findings["security"] = {
        "files_scanned": len(candidates),
        "total": len(findings),
        "by_severity": by_severity,
        "top": top,
    }


def gather_backlog_review(ctx: DemoContext) -> None:
    """Real outstanding-work review: PENDING orders/bugs per queue with ages."""
    queues = ctx.mso / "queues"
    review: Dict[str, dict] = {}
    demo_ids = {o.order_id for o in ctx.orders}
    now = time.time()
    for qdir in sorted(queues.glob("*")) if queues.exists() else []:
        if not qdir.is_dir():
            continue
        items = []
        for f in qdir.rglob("*.json"):
            if f.stem in demo_ids or "-DEMO-" in f.stem:
                continue
            try:
                data = json.loads(f.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            status = data.get("status", "PENDING")
            if status in ("PENDING", ""):
                # BUG-MSO-2026-0659 F6: f.read_text() above succeeding proves
                # the file existed a moment ago, not that it still does — a
                # real dispatcher can archive/delete a queue JSON between
                # that read and this stat() call. An unguarded OSError here
                # used to turn a clean 6/6 demo run into "PVT CRASHED rc 1".
                # Skip the item rather than crash; it is no longer a stable
                # observation of a pending item once it has disappeared
                # mid-scan.
                try:
                    age_days = round((now - f.stat().st_mtime) / 86400, 1)
                except OSError:
                    continue
                items.append({
                    "id": data.get("id", f.stem),
                    "title": (data.get("title") or "")[:60],
                    "age_days": age_days,
                })
        if items:
            items.sort(key=lambda x: -x["age_days"])
            review[qdir.name] = {"count": len(items), "oldest": items[:3]}
    ctx.findings["backlog"] = review


def gather_last_activity(ctx: DemoContext, pre_demo_lifecycle: List[str]) -> None:
    """Recent completions + pre-demo lifecycle tail."""
    complete_dir = ctx.mso / "orders" / "complete"
    demo_ids = {o.order_id for o in ctx.orders}
    recent = []
    if complete_dir.exists():
        # BUG-MSO-2026-0659 F6: the same TOCTOU as gather_backlog_review's
        # f.stat() call, but inside a sort key — an unguarded OSError there
        # (a completed order archived/moved between the glob() listing and
        # this stat()) crashes the whole sort, not just one item. A vanished
        # file sorts as oldest (mtime 0.0) instead of raising; nothing below
        # this line calls stat() again, so a stale Path is otherwise harmless.
        def _mtime_or_zero(f: Path) -> float:
            try:
                return f.stat().st_mtime
            except OSError:
                return 0.0
        files = sorted(complete_dir.glob("*.json"),
                       key=_mtime_or_zero, reverse=True)
        for f in files:
            if f.stem in demo_ids or "-DEMO-" in f.stem:
                continue
            recent.append(f.stem)
            if len(recent) >= 5:
                break
    ctx.findings["activity"] = {
        "recent_completions": recent,
        "lifecycle_tail": pre_demo_lifecycle[-5:],
    }


def gather_recommendations(ctx: DemoContext) -> None:
    recs: List[str] = []
    backlog = ctx.findings.get("backlog") or {}
    total_pending = sum(v["count"] for v in backlog.values()) if backlog else 0
    if total_pending:
        oldest_age = max((i["age_days"] for v in backlog.values()
                          for i in v["oldest"]), default=0)
        recs.append(f"{total_pending} item(s) pending across "
                    f"{len(backlog)} queue(s) — oldest is {oldest_age:.0f} days old. "
                    "Consider `mso dispatch` or `mso order skip` for stale items.")
    sec = ctx.findings.get("security") or {}
    if sec.get("total"):
        recs.append(f"Security scan found {sec['total']} pattern match(es) "
                    f"across {sec['files_scanned']} files — review with "
                    "`mso security scan` and triage real positives.")
    if not (ctx.mso / "dispatcher.pid").exists():
        recs.append("No dispatcher running — start one with `mso dispatch` "
                    "when work is queued.")
    if not recs:
        recs.append("Workspace is clean: no pending backlog, no scanner hits.")
    ctx.findings["recommendations"] = recs


# ---------------------------------------------------------------------------
# PVT verdicts + report
# ---------------------------------------------------------------------------

def evaluate_pvt(ctx: DemoContext) -> Tuple[bool, List[dict]]:
    rows = []
    all_pass = True
    for run in ctx.orders:
        actual = run.actual_seconds
        if actual is None:
            verdict = "FAIL (did not complete)"
            all_pass = False
        else:
            drift = abs(actual - run.planned_seconds) / run.planned_seconds
            fail = drift > TOLERANCE
            verdict = f"FAIL (drift {drift:.0%})" if fail else "PASS"
            if fail:
                all_pass = False
        rows.append({
            "order": run.order_id, "role": run.role, "crew": run.crew,
            "planned": run.planned_seconds, "actual": actual,
            "tokens": run.final_tokens, "files": run.final_files,
            "verdict": verdict,
        })

    ctx.coverage.setdefault("escalation_shown", False)
    ctx.coverage.setdefault("review_shown", False)
    # BUG-MSO-2026-0649: don't derive this from in-memory final_tokens — that
    # bookkeeping happens unconditionally regardless of headless mode, so it
    # green-ticked a write path (_write_live_tick's per-tick RUNNING state)
    # that headless never executes. _drive_order now sets this True only
    # when the write itself actually ran; setdefault leaves it False (the
    # tick correctly unclaimed) for a headless run, where it never does.
    ctx.coverage.setdefault("running_metrics", False)
    ctx.coverage["all_orders_complete"] = all(
        o.actual_seconds is not None for o in ctx.orders)
    ctx.coverage["voyage_progress"] = True
    if not ctx.coverage["all_orders_complete"]:
        all_pass = False
    return all_pass, rows


def pvt_verdict(passed: bool, interrupted: bool, crashed: bool) -> str:
    """Single source of truth for the PVT result word — shared by the durable
    report and the console summary so a crash can never read CRASHED on the
    console and FAIL (interrupted) in the report (BUG-MSO-2026-0654 F2)."""
    if crashed:
        return "CRASHED"
    if passed and not interrupted:
        return "PASS"
    if interrupted:
        return "ABORTED"
    return "FAIL"


def write_report(ctx: DemoContext, passed: bool, rows: List[dict],
                 interrupted: bool, crashed: bool = False) -> Path:
    reports_dir = ctx.mso / "reports" / "demo"
    reports_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    path = reports_dir / f"DEMO-PVT-{stamp}.md"

    lines = [
        f"# Squad Monitor PVT report — {ctx.voyage_id}",
        "",
        f"- **Date:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"- **Result:** {pvt_verdict(passed, interrupted, crashed)}",
        f"- **Crews:** 3 simulated · **Orders:** {len(ctx.orders)} "
        f"(2× 20s, 2× 40s, 2× 60s, scale ×{ctx.time_scale:g})",
        f"- **Simulated spend:** ${ctx.demo_spend():.2f} "
        f"(synthetic — no real tokens were used)",
        "",
        "## Order timings",
        "",
        "| Order | Role | Crew | Planned | Actual | Tokens | Files | Verdict |",
        "|---|---|---|---|---|---|---|---|",
    ]
    for r in rows:
        actual = f"{r['actual']:.1f}s" if r["actual"] is not None else "—"
        lines.append(
            f"| {r['order']} | {r['role']} | {r['crew']} | "
            f"{r['planned']:.0f}s | {actual} | {r['tokens']:,} | "
            f"{r['files']} | {r['verdict']} |")

    lines += ["", "## Dashboard coverage", ""]
    labels = {
        "all_orders_complete": "All 6 orders reached COMPLETE",
        "voyage_progress": "Voyage progress bar 0/6 → 6/6",
        "running_metrics": "RUNNING metrics (iter, turns, files, tokens, ETA)",
        "escalation_shown": "ESCALATIONS block appeared and resolved",
        "review_shown": "PENDING REVIEW block appeared and cleared",
    }
    for key, label in labels.items():
        mark = "x" if ctx.coverage.get(key) else " "
        lines.append(f"- [{mark}] {label}")

    # BUG-MSO-2026-0655 F3: each gather_* call sets its own ctx.findings key
    # only once it actually completes (see gather_security_findings/
    # gather_backlog_review/gather_last_activity/gather_recommendations
    # below). Gating each section's body on the key's PRESENCE — not just
    # truthiness — is what tells a genuine zero-result scan ("we looked,
    # found nothing") apart from a scan that never ran at all (interrupted
    # before it started, or raised partway through the chain per F2 above).
    # The old code used `ctx.findings.get(...) or {}` unconditionally, so an
    # incomplete/failed gather silently rendered as "Scanned 0 Python files",
    # "All queues empty.", "Recent completions: none." under headings
    # labelled "(real)" — indistinguishable from an actual measurement.
    lines += ["", "## Security review (real — OWASP pattern scan)", ""]
    if "security" not in ctx.findings:
        lines.append("_Gathering did not complete this run — no scan data available._")
    else:
        sec = ctx.findings["security"] or {}
        if sec.get("error"):
            lines.append(f"_{sec['error']}_")
        else:
            lines.append(f"Scanned **{sec.get('files_scanned', 0)}** Python files — "
                         f"**{sec.get('total', 0)}** pattern match(es).")
            if sec.get("by_severity"):
                lines.append("")
                lines.append("| Severity | Count |")
                lines.append("|---|---|")
                for sev, count in sorted(sec["by_severity"].items()):
                    lines.append(f"| {sev} | {count} |")
            for t in sec.get("top", []):
                lines.append(f"- {t['name']} ({t['severity']}) — {t['count']}× "
                             f"(e.g. `{t['file']}:{t['line']}`)")
            lines.append("")
            lines.append("> Pattern matches are leads, not verdicts — triage with "
                         "`mso security scan` / `mso security review`.")

    lines += ["", "## Outstanding backlog (real)", ""]
    if "backlog" not in ctx.findings:
        lines.append("_Gathering did not complete this run — backlog was not reviewed._")
    else:
        backlog = ctx.findings["backlog"] or {}
        if not backlog:
            lines.append("All queues empty.")
        else:
            for queue, info in backlog.items():
                lines.append(f"- **{queue}**: {info['count']} pending")
                for item in info["oldest"]:
                    lines.append(f"  - {item['id']} — {item['title']} "
                                 f"(age {item['age_days']}d)")

    lines += ["", "## Last fleet activity (real)", ""]
    if "activity" not in ctx.findings:
        lines.append("_Gathering did not complete this run — activity was not reviewed._")
    else:
        activity = ctx.findings["activity"] or {}
        recent = activity.get("recent_completions") or []
        lines.append("Recent completions: " + (", ".join(recent) if recent else "none."))
        for event in activity.get("lifecycle_tail", []):
            lines.append(f"- `{event}`")

    lines += ["", "## Recommended tasks", ""]
    if "recommendations" not in ctx.findings:
        lines.append("_Gathering did not complete this run — no recommendations available._")
    else:
        for rec in ctx.findings["recommendations"]:
            lines.append(f"- {rec}")

    lines += ["", "---", "_Generated by `mso demo` — all demo artefacts were "
              "removed after this run; this report is the only thing left behind._"]

    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


# ---------------------------------------------------------------------------
# Cleanup
# ---------------------------------------------------------------------------

def cleanup(ctx: DemoContext, keep: bool = False) -> int:
    """Remove every demo artefact; restore pre-demo crew state. Returns count removed."""
    removed = 0
    if not keep:
        for path in ctx.created_paths:
            try:
                if path.exists():
                    path.unlink()
                    removed += 1
            except OSError:
                pass

    # Restore crew files byte-for-byte (even with --keep: crew slots are live
    # operational state, not demo artefacts).
    for path, original in ctx.crew_backups.items():
        try:
            if original is None:
                if path.exists():
                    path.unlink()
            else:
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(original)
        except OSError:
            pass

    # Release the concurrency lock (BUG-MSO-2026-0655 F1) — a lock file, not
    # a demo artefact the operator might want to inspect with --keep, so this
    # always runs regardless of `keep`. BUG-MSO-2026-0659 F1: released via
    # `_release_demo_lock()`, which only unlinks if the file still names THIS
    # process, instead of an unconditional unlink. BUG-MSO-2026-0667 F4:
    # released AFTER the crew_backups restore above, not before — the whole
    # point of this lock (BUG-MSO-2026-0655 F1's cross-restore race) is to
    # cover the restore window; releasing it first reopens exactly that
    # window, letting a second demo/dispatcher observe an unlocked
    # crews/crew{N}/* mid-restore.
    _release_demo_lock(ctx.mso)

    _write_lifecycle("DEMO", f"PVT demo finished — {ctx.voyage_id} "
                             f"({removed} demo artefact(s) removed)")
    return removed


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def run_demo(headless: bool = False, time_scale: float = 1.0,
             keep: bool = False) -> int:
    """Run the dashboard PVT. Returns process exit code (0 = PASS)."""
    from maestro.core import fleet_monitor as fm

    mso = get_artefact_root()
    refusal = check_fleet_idle(mso)
    if refusal:
        print(f"\n  mso demo: refusing to run — {refusal}\n")
        return 1

    ctx = DemoContext(mso=mso, time_scale=time_scale, headless=headless)

    # BUG-MSO-2026-0659 F1: acquire the concurrency lock atomically — see
    # `_acquire_demo_lock()`'s docstring for the exact race this closes.
    # Nothing has been created yet, so a refusal here needs no cleanup —
    # matches `check_fleet_idle()`'s refusal above.
    lock_refusal = _acquire_demo_lock(mso)
    if lock_refusal:
        print(f"\n  mso demo: refusing to run — {lock_refusal}\n")
        return 1

    # BUG-MSO-2026-0691 F1: mirrors run_dispatcher()'s post-claim re-check
    # (BUG-MSO-2026-0685 F5) — the other half of the same check-then-write
    # race. check_fleet_idle() above only reads dispatcher.pid ONCE, before
    # this process even attempted to claim demo.pid; re-verify now that WE
    # hold the lock so a dispatcher that claimed in that gap cannot run
    # concurrently with this demo. Still nothing besides demo.pid itself has
    # been created, so backing off here needs no cleanup beyond releasing it.
    post_claim_refusal = _post_claim_dispatcher_refusal(mso)
    if post_claim_refusal:
        _release_demo_lock(mso)
        print(f"\n  mso demo: refusing to run — {post_claim_refusal}\n")
        return 1

    interrupted = False
    crashed = False
    crash_detail = ""
    findings_done = False
    findings_attempted = False
    threads: List[threading.Thread] = []
    # BUG-MSO-2026-0683 F3: bound BEFORE the try for the same reason as
    # `original_notifier` below — `fm.get_lifecycle_log(8)` is itself inside
    # the try, so a Ctrl+C or OSError landing during that call left this
    # name unbound. The finally block's fallback gather (below) references
    # it whenever `findings_attempted` is still False — exactly the case a
    # Ctrl+C this early produces — so the fallback's own
    # `gather_last_activity(ctx, pre_demo_lifecycle)` raised UnboundLocalError,
    # which the local `except Exception` handler recorded as a crash,
    # overwriting a plain user abort with "PVT CRASHED — ERROR:
    # UnboundLocalError(...)" (BUG-MSO-2026-0652 F3 already ruled a user
    # abort must never be reported as a crash). An empty list is a safe,
    # meaningful default: it means no pre-demo lifecycle tail was captured.
    pre_demo_lifecycle: List[str] = []
    # BUG-MSO-2026-0659 F3 / BUG-MSO-2026-0681 F3: the lock acquisition above
    # is the ONLY thing outside this try (and a refusal there needs no
    # cleanup — nothing was created). Everything that DOES create state or
    # mutate shared process state — the crew-state backup, the demo
    # voyage/order artefacts, the banner pause the demo itself advertises as
    # interruptible ("Ctrl+C aborts and cleans up"), the pre-demo lifecycle
    # snapshot, and the bridge-notifier monkeypatch — must sit inside this
    # try. A Ctrl+C or OSError hitting any of them outside the try (as the
    # lifecycle-log read and notifier patch used to, until BUG-MSO-2026-0681)
    # skips `cleanup()` entirely, leaking demo.pid forever and — for the
    # notifier — leaving `fm._get_bridge_notifier` permanently stubbed to
    # `lambda: None` for the rest of the process, silently swallowing every
    # real escalation page for as long as the interpreter lives.
    # BUG-MSO-2026-0683 F2: read (not yet patch) the notifier BEFORE the try
    # opens, so `original_notifier` is bound no matter what happens inside
    # the try. It used to be assigned as the try's first statement — a
    # failure racing that exact assignment (however narrow the window) left
    # `original_notifier` unbound, and the unconditional restore in `finally`
    # then raised UnboundLocalError, which ESCAPES run_demo entirely and
    # skips the nested `cleanup()` call below it — leaking demo.pid (now a
    # HARD dispatch blocker per BUG-MSO-2026-0683 F4) and leaving
    # `fm._get_bridge_notifier` unrestored for the rest of the process.
    original_notifier = fm._get_bridge_notifier
    try:
        # The demo must never page the bridge (Slack) about its synthetic
        # escalation — disable the notifier for the duration.
        fm._get_bridge_notifier = lambda: None
        pre_demo_lifecycle = fm.get_lifecycle_log(8)

        backup_crew_state(ctx)
        create_demo_artefacts(ctx)

        print(f"\n  Squad Monitor PVT — {ctx.voyage_id}")
        print(f"  6 demo orders (2x20s 2x40s 2x60s, scale x{time_scale:g}) "
              "across 3 simulated crews. No tokens are spent.")
        if not headless:
            print("  The live dashboard takes over this terminal; "
                  "Ctrl+C aborts and cleans up.\n")
        time.sleep(0 if headless else min(2.0, ctx.scaled(2.0)))

        threads = [threading.Thread(target=_crew_thread, args=(ctx, slot), daemon=True)
                   for slot in DEMO_PLAN]
        threads.append(threading.Thread(target=_events_thread, args=(ctx,), daemon=True))

        ctx.t0 = time.monotonic()
        for t in threads:
            t.start()

        if headless:
            # BUG-MSO-2026-0629: join FIRST, gather AFTER. Gathering used to
            # run concurrently with the sim so a headless run bore some
            # resemblance to the live-dashboard's mid-run collection, but
            # unlike the live path (which renders a UI a human is watching,
            # so a bit of real concurrency is the point) headless has no
            # observer — the concurrency bought nothing but contention: real
            # CPU+I/O work (an OWASP file scan, a queue walk) racing the
            # crew/events threads for the GIL while their wall-clock accuracy
            # is the exact thing evaluate_pvt's drift check depends on. There
            # is nothing left running by the time gathering starts, so it
            # can no longer skew a single tick.
            for t in threads:
                while t.is_alive():
                    t.join(timeout=0.5)
            findings_attempted = True
            gather_security_findings(ctx)
            gather_backlog_review(ctx)
            gather_last_activity(ctx, pre_demo_lifecycle)
            findings_done = True
        else:
            from rich.console import Console
            from rich.live import Live
            from maestro.core.dashboard import render_dashboard

            console = Console()
            width = max(64, console.width - 2)
            settings = {"maxCrews": 3}

            def frame():
                state = fm.build_dashboard_state(settings, refresh_seconds=1)
                # Demo always demonstrates the API-billing visuals, scoped to
                # demo-order spend only (never the workspace's real history).
                state.billing_mode = "api"
                state.spend_usd = ctx.demo_spend()
                state.budget_usd = DEMO_BUDGET_USD
                return render_dashboard(state, width=width)

            with Live(frame(), console=console, refresh_per_second=2,
                      screen=True) as live:
                while any(t.is_alive() for t in threads):
                    time.sleep(max(0.25, ctx.scaled(1.0)))
                    live.update(frame())
                    if not findings_done:
                        # Cheap local gathering, once, mid-run
                        findings_attempted = True
                        gather_security_findings(ctx)
                        gather_backlog_review(ctx)
                        gather_last_activity(ctx, pre_demo_lifecycle)
                        findings_done = True
                # Hold the final frame briefly so 6/6 + all-done is visible
                live.update(frame())
                time.sleep(min(3.0, ctx.scaled(3.0)))
    except (KeyboardInterrupt, Exception) as exc:
        # BUG-MSO-2026-0649: a gather call in the PRIMARY headless path (not
        # just the finally-block retry below) can itself raise — that must
        # reach `finally` exactly like Ctrl+C does, so cleanup still runs
        # and `mso demo` exits cleanly instead of leaving a raw traceback in
        # place of an ABORTED/FAIL verdict.
        interrupted = True
        ctx.stop.set()
        for t in threads:
            t.join(timeout=2)
        # BUG-MSO-2026-0652 F3: a genuine crash (e.g. an AttributeError from
        # render_dashboard, or a real bug in a gather_* call) used to share
        # this branch's `interrupted = True` with an actual user Ctrl+C,
        # so both printed the identical "PVT ABORTED" wording — the first
        # thing a new operator sees would lie about whether they caused it.
        # `crashed` keeps the exit-code/cleanup handling identical (still
        # `interrupted`) while giving the crash its own verdict word and
        # putting the exception text on the console, not only lifecycle.log.
        if not isinstance(exc, KeyboardInterrupt):
            crashed = True
            crash_detail = repr(exc)
        _log_exc("[DEMO] simulation failed", "aborting to cleanup", exc)
    finally:
        fm._get_bridge_notifier = original_notifier
        # BUG-MSO-2026-0645: a Ctrl+C during either path above (most likely
        # while joining/waiting, before gathering ran) must still gather real
        # findings before the report is written — the report's "(real)"
        # section headings are a promise, not a suggestion. An interrupted
        # run that skipped straight to `write_report` used to print
        # "Scanned 0 Python files" / "All queues empty" regardless of the
        # workspace's actual state.
        #
        # BUG-MSO-2026-0649: gathering/report generation can ITSELF raise (a
        # second Ctrl+C during the scan, a FileNotFoundError from an
        # unguarded f.stat() TOCTOU in gather_backlog_review, an OWASP
        # scanner failure) — that must never skip cleanup() below, or a
        # failed run leaves demo data in the LIVE crew state files and
        # *-DEMO-* orders in queues/orders/ for the next `mso dispatch` to
        # pick up. Nest the fallible part so cleanup() always runs in its
        # own finally, regardless of what happens above it.
        #
        # BUG-MSO-2026-0652 F2: this used to be `except Exception`, which
        # cannot catch KeyboardInterrupt — a second Ctrl+C during this very
        # gather retry (the realistic moment for one: the operator already
        # pressed Ctrl+C once and is waiting on a synchronous OWASP scan)
        # escaped past this handler entirely, skipping the WARN log, the
        # cleanup() call's sibling console summary below, and the PVT report.
        # `cleanup()` itself never depended on this catch (the nested
        # `finally` runs regardless of what escapes the `try`), so
        # BUG-MSO-2026-0649's cleanup guarantee held even with the old code —
        # this closes the reporting gap alongside it, not the restore path.
        #
        # BUG-MSO-2026-0654 F1: gate the fallback attempt on `findings_attempted`,
        # not `findings_done`. The gather calls above may have already run once
        # in the primary path (headless, or the live per-tick branch) and failed
        # partway through — `findings_done` stays False in that case, so the old
        # `if not findings_done` re-invoked the exact same (possibly
        # deterministic) failing call here, and a repeat failure skipped
        # gather_recommendations/evaluate_pvt/write_report entirely: zero PVT
        # reports written even though every order completed. `findings_attempted`
        # is set True the moment the primary path *starts* its one gather
        # attempt, so a failed attempt is never retried — evaluate_pvt/write_report
        # still run against whatever ctx.findings ended up holding (possibly
        # partial, possibly empty; every write_report section already tolerates
        # that via `.get(...) or {}`). The one case this block still gathers is
        # when NO attempt was made yet (e.g. Ctrl+C while joining threads, or a
        # crash before the live per-tick gather ever fired) — that is the
        # original BUG-MSO-2026-0645 guarantee, unchanged.
        passed, rows, report_path = False, [], None
        try:
            # BUG-MSO-2026-0655 F2: gather_recommendations() (and, when the
            # primary path never got that far, the earlier gather_* calls
            # retried here too) used to sit in the SAME try as
            # evaluate_pvt()/write_report() below — a raise from ANY of them
            # discarded the entire PVT report, even for a clean 6/6 run whose
            # only failure was a bug in the cheap, last gather step
            # (BUG-MSO-2026-0654 F1 only closed this for the two calls it
            # named, not the chain as a whole). A plain Exception here is now
            # caught locally so evaluate_pvt()/write_report() still run
            # against whatever ctx.findings ended up holding — every
            # write_report section already tolerates partial/missing findings
            # via `.get(...) or {}` (see F3 below). A genuine SECOND
            # KeyboardInterrupt landing while this retry is in flight is
            # deliberately NOT caught here — it keeps propagating to the
            # outer handler below, unchanged from before this fix (see
            # BUG-MSO-2026-0652 F2's test coverage for that path).
            try:
                if not findings_attempted:
                    gather_security_findings(ctx)
                    gather_backlog_review(ctx)
                    gather_last_activity(ctx, pre_demo_lifecycle)
                gather_recommendations(ctx)
            except Exception as exc:
                interrupted = True
                if not crashed:
                    crashed = True
                    crash_detail = repr(exc)
                _log_exc("[DEMO] findings gathering failed",
                         "continuing to PVT evaluation/report with partial findings", exc)
            passed, rows = evaluate_pvt(ctx)
            # BUG-MSO-2026-0654 F2: pass `crashed` through so the durable report
            # can say CRASHED instead of misreporting a crash as "FAIL
            # (interrupted)" — `pvt_verdict()` is the single formula shared with
            # the console summary below, so the two can no longer disagree.
            report_path = write_report(ctx, passed, rows, interrupted, crashed=crashed)
        except (KeyboardInterrupt, Exception) as exc:
            interrupted = True
            if not isinstance(exc, KeyboardInterrupt) and not crashed:
                crashed = True
                crash_detail = repr(exc)
            _log_exc("[DEMO] findings/report generation failed",
                     "demo cleanup still ran, no report was written", exc)
        finally:
            removed = cleanup(ctx, keep=keep)

    # Console summary (printed after the Live alt buffer exits)
    verdict = pvt_verdict(passed, interrupted, crashed)
    print(f"\n  PVT {verdict} — {ctx.voyage_id}")
    if crashed:
        print(f"  ERROR: {crash_detail}")
    for r in rows:
        actual = f"{r['actual']:.1f}s" if r["actual"] is not None else "—"
        print(f"    crew{r['crew']}  {r['order']:<22} {r['role']:<4} "
              f"planned {r['planned']:>5.0f}s  actual {actual:>7}  {r['verdict']}")
    # BUG-MSO-2026-0659 F5: gate on PRESENCE of the findings key, same fix
    # BUG-MSO-2026-0655 F3 already applied to write_report() — this console
    # summary was never updated alongside it, so it kept printing "0
    # match(es) in 0 files" / "0 pending item(s)" whenever gathering never
    # completed, directly contradicting the report's own "_Gathering did not
    # complete_" wording one line below on the same terminal.
    if "security" not in ctx.findings:
        print("    security scan: gathering did not complete this run")
    else:
        sec = ctx.findings["security"] or {}
        if not sec.get("error"):
            print(f"    security scan: {sec.get('total', 0)} match(es) in "
                  f"{sec.get('files_scanned', 0)} files")
    if "backlog" not in ctx.findings:
        print("    outstanding backlog: gathering did not complete this run")
    else:
        backlog = ctx.findings["backlog"] or {}
        pending = sum(v["count"] for v in backlog.values()) if backlog else 0
        print(f"    outstanding backlog: {pending} pending item(s)")
    print(f"    cleanup: {removed} demo artefact(s) removed"
          + (" (--keep: artefacts retained)" if keep else ""))
    if report_path is not None:
        print(f"\n  Full report: {report_path}\n")
    else:
        print("\n  Full report: not generated — see lifecycle.log\n")
    return 0 if (passed and not interrupted) else 1
