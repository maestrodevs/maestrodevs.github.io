"""maestro.roles.loader — parse role files into structured RoleDefinition objects.

Reads JSON-frontmatter (between ``---`` delimiters) and splits the Markdown body
into named sections keyed by H2 headings.  Validates frontmatter against the
overlay schema from SEC-0185 Part C.
"""

from __future__ import annotations

import copy
import json
import re
import warnings
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

CANONICAL_ROLE_CODES = ("PLN", "BLD", "TST", "DOC", "SEC", "REL", "LEAD")
LEGACY_ALIASES = {"NAV": "PLN", "SHP": "BLD", "BOS": "TST", "SCR": "DOC",
                  "LKT": "SEC", "COX": "REL", "QM": "LEAD"}
# Recognised model IDs for role-overlay frontmatter validation (warning-only).
# Keep in sync with SUPPORTED_MODELS in maestro/core/crew.py — that set is the
# dispatch gate; this one only decides whether a role file gets a warning.
# Trailing entries are legacy IDs kept so older overlays don't warn.
KNOWN_MODELS = {
    "claude-fable-5-1",
    "claude-fable-5",
    "claude-opus-5",
    "claude-opus-4-8", "claude-opus-4-7", "claude-opus-4-6",
    "claude-sonnet-5", "claude-sonnet-4-6", "claude-haiku-4-5-20251001",
    "claude-sonnet-4-5", "claude-opus-4-5",
}
VALID_MERGE_DIRECTIVES = {"extend", "override", "replace"}

# D6 (PLAN-PLN-MSO-2026-0504 §3.3, Captain ruling 2026-08-25): `must_not` is the
# LEAD's proactivity ceiling. Under RESIDENT-agent resolution only, an overlay
# may `extend` a protected section but not `replace`/`override` it -- doing so
# would let a workspace-local overlay silently widen what an autonomous LEAD
# may do without asking. Interactive resolution (resident=False) and every
# other role/section are unaffected -- this is a narrow, monotonic tightening,
# the same shape as D1's governed-check override policy.
RESIDENT_PROTECTED_SECTIONS: dict[str, tuple[str, ...]] = {
    "LEAD": ("must_not",),
}
RESIDENT_REFUSED_DIRECTIVES = {"replace", "override"}

CANONICAL_SECTIONS = (
    "overview", "responsibilities", "permissions", "paths",
    "must_do", "must_not", "deliverables", "prompt_preamble",
    "transitions", "quality_checklist", "branch_discipline",
)

# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------


class RoleFileValidationError(ValueError):
    """Raised when a role file fails schema validation."""

    def __init__(self, path: Path, diagnostics: list[str]) -> None:
        self.path = path
        self.diagnostics = diagnostics
        joined = "\n".join(f"  {d}" for d in diagnostics)
        super().__init__(f"Role file validation failed: {path}\n{joined}")


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------


@dataclass
class SectionContent:
    name: str          # normalised heading key (lower, underscored)
    heading: str       # original heading text
    body: str          # raw Markdown body (stripped)


@dataclass
class RoleDefinition:
    frontmatter: dict[str, Any]
    sections: dict[str, SectionContent]
    path: Path
    is_core: bool

    @property
    def role_code(self) -> str:
        return self.frontmatter.get("role_code", "")

    @property
    def role_name(self) -> str:
        return self.frontmatter.get("role_name", self.role_code)

    @property
    def model(self) -> str | None:
        return self.frontmatter.get("model")

    @property
    def context_window(self) -> str | None:
        return self.frontmatter.get("context_window")

    @property
    def effort(self) -> str | None:
        return self.frontmatter.get("effort")

    @property
    def tools(self) -> list[str]:
        return self.frontmatter.get("tools", [])

    def to_dict(self) -> dict[str, Any]:
        return {
            "frontmatter": self.frontmatter,
            "sections": {k: {"heading": v.heading, "body": v.body}
                         for k, v in self.sections.items()},
            "path": str(self.path),
            "is_core": self.is_core,
        }

    def to_markdown(self) -> str:
        """Reconstruct the role as Markdown (frontmatter + sections)."""
        lines = ["---", json.dumps(self.frontmatter, indent=2), "---", ""]
        for sec in self.sections.values():
            lines.append(f"## {sec.heading}")
            lines.append("")
            if sec.body:
                lines.append(sec.body)
                lines.append("")
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Parsing helpers
# ---------------------------------------------------------------------------

_FRONTMATTER_RE = re.compile(
    r"^\s*---\s*\n(.*?)\n---\s*\n", re.DOTALL
)
_H2_RE = re.compile(r"^##\s+(.+)$", re.MULTILINE)


def _section_key(heading: str) -> str:
    """Normalise a heading to a section key."""
    return re.sub(r"[^a-z0-9]+", "_", heading.lower().strip()).strip("_")


def _parse_frontmatter(text: str, path: Path) -> tuple[dict[str, Any], str, int]:
    """Extract JSON frontmatter block.

    Returns (frontmatter_dict, body_after_frontmatter, frontmatter_line_count).
    Raises RoleFileValidationError if the block is missing or invalid JSON.
    """
    m = _FRONTMATTER_RE.match(text)
    if not m:
        raise RoleFileValidationError(path, [
            "line 1: Missing JSON frontmatter block (expected --- ... --- at top of file)"
        ])
    raw = m.group(1)
    body = text[m.end():]
    frontmatter_lines = raw.count("\n") + 3  # two --- lines + content
    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise RoleFileValidationError(path, [
            f"line {exc.lineno}: Invalid JSON in frontmatter: {exc.msg}"
        ]) from exc
    return data, body, frontmatter_lines


def _parse_sections(body: str) -> dict[str, SectionContent]:
    """Split body into sections keyed by H2 headings."""
    sections: dict[str, SectionContent] = {}
    # Split on H2 headings; keep delimiters
    parts = _H2_RE.split(body)
    # parts[0] is content before first H2 (usually empty or preamble)
    # then alternating: heading, content, heading, content, ...
    i = 1
    while i < len(parts) - 1:
        heading = parts[i].strip()
        content = parts[i + 1].strip()
        key = _section_key(heading)
        sections[key] = SectionContent(name=key, heading=heading, body=content)
        i += 2
    return sections


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------


def _validate_frontmatter(data: dict[str, Any], path: Path, is_core: bool) -> list[str]:
    """Validate frontmatter fields.  Returns list of diagnostic strings."""
    diags: list[str] = []

    # Required fields
    if "role_code" not in data:
        diags.append("frontmatter: missing required field 'role_code'")
    else:
        code = data["role_code"]
        if code not in CANONICAL_ROLE_CODES:
            diags.append(
                f"frontmatter: 'role_code' must be one of {CANONICAL_ROLE_CODES}, got '{code}'"
            )

    if "role_name" not in data:
        diags.append("frontmatter: missing required field 'role_name'")

    # Optional but validated fields
    if "model" in data and data["model"] not in KNOWN_MODELS:
        diags.append(
            f"frontmatter: 'model' '{data['model']}' is not a recognised Claude model "
            f"(known: {sorted(KNOWN_MODELS)}); continuing with warning"
        )

    if "context_window" in data:
        try:
            from maestro.core_constants import VALID_CONTEXT_WINDOWS
            if data["context_window"] not in VALID_CONTEXT_WINDOWS:
                diags.append(
                    f"frontmatter: 'context_window' '{data['context_window']}' is not a recognised value "
                    f"(known: {sorted(VALID_CONTEXT_WINDOWS)}); continuing with warning"
                )
        except ImportError:
            pass

    if "effort" in data:
        try:
            from maestro.core_constants import VALID_EFFORTS_ALL
            if data["effort"] not in VALID_EFFORTS_ALL:
                diags.append(
                    f"frontmatter: 'effort' '{data['effort']}' is not a recognised value "
                    f"(known: {sorted(VALID_EFFORTS_ALL)}); continuing with warning"
                )
        except ImportError:
            pass

    if "extends" in data:
        ext = data["extends"]
        if ext != "core" and not Path(ext).is_absolute():
            diags.append(
                f"frontmatter: 'extends' must be 'core' or an absolute path, got '{ext}'"
            )

    if "sections" in data:
        if not isinstance(data["sections"], dict):
            diags.append("frontmatter: 'sections' must be an object")
        else:
            for sec_name, directive in data["sections"].items():
                if directive not in VALID_MERGE_DIRECTIVES:
                    diags.append(
                        f"frontmatter: unknown merge directive '{directive}' for section "
                        f"'{sec_name}'; must be one of {sorted(VALID_MERGE_DIRECTIVES)}"
                    )

    if "tools" in data and not isinstance(data["tools"], list):
        diags.append("frontmatter: 'tools' must be a list")

    if "test_categories" in data:
        tc = data["test_categories"]
        if not isinstance(tc, dict):
            diags.append("frontmatter: 'test_categories' must be an object")
        else:
            for key in ("mandatory", "optional"):
                if key in tc and not isinstance(tc[key], list):
                    diags.append(f"frontmatter: 'test_categories.{key}' must be a list")

    return diags


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def parse_role_file(path: Path, *, is_core: bool = False,
                    strict: bool = True) -> RoleDefinition:
    """Parse a role file at *path* into a RoleDefinition.

    Args:
        path: Path to the .md role file.
        is_core: Whether this is a core (pip-package) role file.
        strict: If True, raise on validation errors; if False, collect warnings only.

    Raises:
        RoleFileValidationError: If the file fails schema validation and strict=True.
    """
    text = path.read_text(encoding="utf-8")
    frontmatter, body, _ = _parse_frontmatter(text, path)
    diags = _validate_frontmatter(frontmatter, path, is_core)
    # Model-unknown is a warning — filter it for strict error check
    hard_diags = [d for d in diags if "not a recognised Claude model" not in d]
    if hard_diags and strict:
        raise RoleFileValidationError(path, diags)

    sections = _parse_sections(body)
    return RoleDefinition(
        frontmatter=frontmatter,
        sections=sections,
        path=path,
        is_core=is_core,
    )


def _core_roles_dir() -> Path:
    """Return the directory containing core role .md files (pip package)."""
    return Path(__file__).parent


def _overlay_roles_dir(workspace_dir: Path) -> Path:
    from maestro.workspace import resolve_artefact_dir
    return resolve_artefact_dir(workspace_dir) / "config" / "roles"


def _legacy_role_paths_file(workspace_dir: Path) -> Path:
    from maestro.workspace import resolve_artefact_dir
    return resolve_artefact_dir(workspace_dir) / "config" / "role-paths.json"


_warned_legacy: set[str] = set()


def _warn_legacy_once(workspace_dir: Path) -> None:
    key = str(workspace_dir)
    if key not in _warned_legacy:
        _warned_legacy.add(key)
        import warnings
        warnings.warn(
            f"[Maestro] Falling back to legacy role-paths.json at "
            f"{_legacy_role_paths_file(workspace_dir)}.  "
            "Migrate to .mso/config/roles/<ROLE>.md overlays.  "
            "See: mso roles migrate-paths",
            DeprecationWarning,
            stacklevel=4,
        )


def load_core_role(role_code: str) -> RoleDefinition:
    """Load a core role from the pip package roles directory."""
    code = LEGACY_ALIASES.get(role_code.upper(), role_code.upper())
    path = _core_roles_dir() / f"{code}.md"
    if not path.exists():
        raise FileNotFoundError(f"Core role file not found: {path}")
    return parse_role_file(path, is_core=True)


def load_overlay(role_code: str, workspace_dir: Path) -> RoleDefinition | None:
    """Load a user overlay for *role_code* from the workspace, or None."""
    code = LEGACY_ALIASES.get(role_code.upper(), role_code.upper())
    overlay_path = _overlay_roles_dir(workspace_dir) / f"{code}.md"
    if overlay_path.exists():
        return parse_role_file(overlay_path, is_core=False)
    return None


def _refuse_resident_directive(core: RoleDefinition, overlay: RoleDefinition) -> RoleDefinition:
    """D6: strip any `replace`/`override` directive on a resident-protected
    section, so `merge_overlay`'s default (a section undeclared in
    ``frontmatter['sections']`` keeps the core body verbatim) applies -- the
    core list is used, unaltered. `extend` on the same section is left alone
    and continues to work normally. Every refusal is warned and logged.
    """
    protected = RESIDENT_PROTECTED_SECTIONS.get(core.role_code.upper())
    if not protected:
        return overlay

    section_directives: dict[str, str] = overlay.frontmatter.get("sections", {})
    offending = {
        sec: directive
        for sec, directive in section_directives.items()
        if sec in protected and directive in RESIDENT_REFUSED_DIRECTIVES
    }
    if not offending:
        return overlay

    new_frontmatter = copy.deepcopy(overlay.frontmatter)
    new_directives = dict(new_frontmatter.get("sections", {}))
    for sec, directive in offending.items():
        new_directives.pop(sec, None)
        _log_resident_directive_refusal(core.role_code.upper(), sec, directive, overlay.path)
    new_frontmatter["sections"] = new_directives

    return RoleDefinition(
        frontmatter=new_frontmatter,
        sections=overlay.sections,
        path=overlay.path,
        is_core=overlay.is_core,
    )


def _log_resident_directive_refusal(role_code: str, section: str, directive: str, overlay_path: Path) -> None:
    """Warn + write a lifecycle.log record of a D6 refusal.

    Logging is best-effort: a lifecycle-log failure (no artefact root
    resolvable, e.g. an ad-hoc/test invocation) must never block role
    resolution.
    """
    message = (
        f"[D6] resident-agent overlay refused '{directive}' on {role_code} "
        f"section '{section}' ({overlay_path}); '{section}' is extend-only for "
        f"the resident agent -- using the core section unchanged."
    )
    warnings.warn(message, UserWarning, stacklevel=4)
    try:
        from maestro.core.fleet_runner import write_lifecycle_event
        write_lifecycle_event("WARN", message)
    except Exception:
        pass


def load_effective_role(
    role_code: str,
    workspace_dir: Path | None = None,
    *,
    resident: bool = False,
) -> RoleDefinition:
    """Load the effective (merged core + overlay) role definition.

    Resolution:
      1. Load core role from pip package.
      2. Check for overlay at .mso/config/roles/<CODE>.md — merge if present.
      3. If no overlay and legacy role-paths.json exists — warn + return core.

    ``resident`` (D6): when True, the caller is resolving the role for a
    RESIDENT agent (e.g. the LEAD daemon, FTR-MSO-2026-0504 §3.3) rather than
    an interactive session. Under resident resolution, `RESIDENT_PROTECTED_SECTIONS`
    accepts `extend` only -- `replace`/`override` are refused, the core section
    is used, and the refusal is logged. Interactive resolution (the default)
    and every role/section outside that map are unaffected.
    """
    from maestro.roles.overlay import merge_overlay  # avoid circular at module level

    core = load_core_role(role_code)

    if workspace_dir is None:
        # BUG-MSO-2026-0425: role overlays live under the ARTEFACT plane
        # (config/roles/) → artefact root, honouring the solo/shared pointer.
        from maestro.workspace import get_artefact_root
        try:
            workspace_dir = get_artefact_root()
        except Exception:
            return core

    overlay = load_overlay(role_code, workspace_dir)
    if overlay is not None:
        if resident:
            overlay = _refuse_resident_directive(core, overlay)
        return merge_overlay(core, overlay)

    # Legacy fallback
    legacy = _legacy_role_paths_file(workspace_dir)
    if legacy.exists():
        _warn_legacy_once(workspace_dir)

    return core


def validate_all(workspace_dir: Path) -> dict[str, list[str]]:
    """Validate all core role files and any overlays.

    Returns a dict mapping file path strings to lists of diagnostic strings.
    An empty list means the file is valid.
    """
    results: dict[str, list[str]] = {}

    # Core files
    for code in CANONICAL_ROLE_CODES:
        path = _core_roles_dir() / f"{code}.md"
        if not path.exists():
            results[str(path)] = [f"File not found: {path}"]
            continue
        try:
            parse_role_file(path, is_core=True, strict=True)
            results[str(path)] = []
        except RoleFileValidationError as exc:
            results[str(path)] = exc.diagnostics

    # Overlay files
    overlay_dir = _overlay_roles_dir(workspace_dir)
    if overlay_dir.is_dir():
        for md_file in sorted(overlay_dir.glob("*.md")):
            try:
                parse_role_file(md_file, is_core=False, strict=True)
                results[str(md_file)] = []
            except RoleFileValidationError as exc:
                results[str(md_file)] = exc.diagnostics

    return results
