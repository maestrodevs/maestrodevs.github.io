"""maestro.roles.validation — the one place that answers "is this a role?".

BUG-MSO-2026-0714. BUG-MSO-2026-0713 was filed with
``roleSequence: ["INV", "BLD", "TST"]``. ``INV`` is an ORDER TYPE, not a crew
ROLE — but nothing between the filing and ``crew.py``'s argparse knew the
difference, so the dispatcher selected the order, launched
``crew.py --role INV``, argparse exited 2, and the failure was recorded as
"start_crew_process returned no PID" and eventually escalated to STALLED with
advice to check the installed package's integrity. The package was fine. The
role was not a role.

This module is the single vocabulary every *filing-time* and *scan-time* gate
consults, so an unlaunchable role is refused where a human can still read the
message, not at the argparse boundary of a detached background process whose
stderr goes to a log nobody is watching.

Two rules it deliberately encodes:

* **The vocabulary is canonical codes PLUS the legacy nautical aliases.**
  ``NAV``/``SHP``/``BOS``/``SCR``/``LKT``/``COX``/``QM`` remain valid order
  content by documented policy (CLAUDE.md: "legacy codes remain valid aliases
  in order JSON, role-paths config, and CLI flags"), and ``mso bug`` still
  writes ``["SHP", "BOS"]`` today. A validator that accepted only the seven
  canonical codes would reject orders the system itself creates.
* **Validity means launchable.** :data:`DISPATCHABLE_ROLE_CODES` is what the
  crew launcher must accept, so this module and ``crew.py``'s ``--role``
  choices cannot drift apart — that drift is the whole bug.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable, Mapping, Optional

from maestro.roles.loader import CANONICAL_ROLE_CODES, LEGACY_ALIASES

__all__ = [
    "CANONICAL_ROLE_CODES",
    "LEGACY_ALIASES",
    "DISPATCHABLE_ROLE_CODES",
    "BUILTIN_TYPE_ROLE_SEQUENCES",
    "RoleProblem",
    "OrderRoleValidation",
    "normalise_role",
    "is_valid_role",
    "valid_roles_message",
    "validate_order_roles",
    "default_role_sequence_for_type",
]


#: Every role spelling the fleet accepts in order JSON and on ``crew.py --role``:
#: the seven canonical codes plus their legacy nautical aliases. Sorted so the
#: argparse ``choices`` list (and therefore ``--help``) is stable.
DISPATCHABLE_ROLE_CODES: tuple = tuple(CANONICAL_ROLE_CODES) + tuple(
    sorted(LEGACY_ALIASES)
)

#: Built-in order-type -> roleSequence defaults, mirroring
#: ``maestro/packs/sdlc/pack.json`` (pack #0, "the default behaviour,
#: formalised"). Consulted only when an order declares NO ``roleSequence`` of
#: its own and the workspace has no template for its type.
#:
#: ``INV: ["PLN"]`` is the mapping BUG-MSO-2026-0714 AC3 asks to be documented
#: and applied: an investigation runs entirely at the PLANNER role (see
#: ``fleet_runner``'s BUG-MSO-2026-0609 note — its deliverable is a report
#: under ``reports/investigation/`` rather than a plan document, but the role
#: that produces it is PLN). The old inference table in ``fleet_runner`` mapped
#: ``INV -> LKT`` instead, which contradicted the pack, and — because SEC is
#: tier-gated while INV/PLN/BLD/TST are not — made an INV order undispatchable
#: on a community licence for a second, unrelated-looking reason.
BUILTIN_TYPE_ROLE_SEQUENCES: dict = {
    "FTR": ["PLN", "BLD", "TST", "DOC", "SEC", "REL"],
    "BUG": ["PLN", "BLD", "TST", "REL"],
    "SEC": ["SEC", "BLD", "TST", "REL"],
    "INV": ["PLN"],
    "PLN": ["PLN"],
    "DOC": ["DOC"],
}


def normalise_role(value: Any) -> Optional[str]:
    """The canonical role code for *value*, or ``None`` if it is not a role.

    Accepts either spelling and any case/whitespace. ``None`` is the "not a
    role" answer — callers must not fall back to passing the raw string on to
    the launcher, which is exactly how ``--role INV`` was reached.
    """
    if not isinstance(value, str):
        return None
    code = value.strip().upper()
    if not code:
        return None
    if code in CANONICAL_ROLE_CODES:
        return code
    return LEGACY_ALIASES.get(code)


def is_valid_role(value: Any) -> bool:
    """True if *value* names a role the crew launcher will accept."""
    return normalise_role(value) is not None


def valid_roles_message() -> str:
    """The valid set, spelled out for an error message a human will read."""
    legacy = ", ".join(f"{alias}={canon}" for alias, canon in sorted(LEGACY_ALIASES.items()))
    return (
        f"valid roles are {', '.join(CANONICAL_ROLE_CODES)} "
        f"(legacy aliases: {legacy})"
    )


@dataclass(frozen=True)
class RoleProblem:
    """One bad role value and the field it came from."""

    field: str
    value: str

    def __str__(self) -> str:  # pragma: no cover - trivial
        return f"{self.field}={self.value!r}"


@dataclass(frozen=True)
class OrderRoleValidation:
    """Result of :func:`validate_order_roles`. Falsy when the order is invalid."""

    ok: bool
    problems: tuple = ()
    message: str = ""

    def __bool__(self) -> bool:  # pragma: no cover - trivial
        return self.ok


def _describe(order_id: str, problems: Iterable) -> str:
    bits = ", ".join(str(p) for p in problems)
    subject = f"{order_id}: " if order_id else ""
    return (
        f"{subject}unknown role {bits} — {valid_roles_message()}. "
        "Note that FTR/BUG/SEC/INV/PLN/DOC are ORDER TYPES, not roles "
        "(BUG-MSO-2026-0714)."
    )


def validate_order_roles(order_data: Mapping) -> OrderRoleValidation:
    """Validate an order's ``targetRole``/``role`` and every ``roleSequence``
    entry against the role vocabulary.

    Absent fields are NOT a problem — plenty of legitimate orders declare
    neither and let the dispatcher infer a role from the order type. Only a
    value that is *present and not a role* fails, so this can be applied to
    every order in a queue without inventing failures for the ones that were
    always fine.
    """
    problems: list = []
    if not isinstance(order_data, Mapping):
        return OrderRoleValidation(ok=True)

    target = order_data.get("targetRole") or order_data.get("role")
    field_name = "targetRole" if order_data.get("targetRole") else "role"
    if isinstance(target, str) and target.strip() and not is_valid_role(target):
        problems.append(RoleProblem(field_name, target))

    sequence = order_data.get("roleSequence")
    if isinstance(sequence, (list, tuple)):
        for index, entry in enumerate(sequence):
            if isinstance(entry, str) and entry.strip() and not is_valid_role(entry):
                problems.append(RoleProblem(f"roleSequence[{index}]", entry))

    if not problems:
        return OrderRoleValidation(ok=True)

    order_id = str(order_data.get("orderId") or order_data.get("id") or "")
    return OrderRoleValidation(
        ok=False,
        problems=tuple(problems),
        message=_describe(order_id, problems),
    )


def default_role_sequence_for_type(order_type: Any) -> list:
    """The built-in default ``roleSequence`` for *order_type*, or ``[]``.

    Workspace templates (``orders/templates/*-template.json``, loaded into
    ``fleet_runner.ROLE_SEQUENCES``) take precedence over this — it is the
    floor, not the authority, and exists so a workspace with no template for
    a type still gets the pack's documented answer rather than a hardcoded
    single-role guess.
    """
    if not isinstance(order_type, str):
        return []
    return list(BUILTIN_TYPE_ROLE_SEQUENCES.get(order_type.strip().upper(), []))
