"""
Maestro backup & restore — project state archiving.

Provides backup(), restore(), and list_backups() for creating and extracting
versioned ZIP archives of .mso/ project state.
"""

from __future__ import annotations

import json
import os
import re
import time
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Optional

from maestro.workspace import MSO_DIR_NAME


BACKUP_INCLUDES = [
    "orders/active",
    "orders/complete",
    "orders/failed",
    "voyages/active",
    "voyages/complete",
    "prompts/active",
    "plans",
    "handoffs",
    "requirements",
    "reports",
    "usage/orders",
    "config",
]

BACKUP_EXCLUDES = {
    "core", "hooks", "crews", "logs", "temp", "queues",
}

# Directory names that are always skipped when walking include paths.
# These can be enormous (node_modules) or fully reconstructable (.worktree,
# __pycache__, build artefacts) and must never block a backup/cleanup.
BACKUP_EXCLUDE_DIRS = {
    "node_modules",
    ".next",
    ".worktree",
    "worktrees",
    "dist",
    "build",
    ".venv",
    "venv",
    "__pycache__",
    ".git",
}

# Abort the auto-backup and log a warning instead of hanging when the
# workspace contains more than this many candidate files.
BACKUP_MAX_FILES = 50_000

_ROOT_FILES = [
    "CLAUDE.md",
    f"{MSO_DIR_NAME}/BACKLOG.md",
    f"{MSO_DIR_NAME}/VOYAGE-STATUS.md",
    f"{MSO_DIR_NAME}/config/workspace.json",
    f"{MSO_DIR_NAME}/config/projects.json",
]


def _matches_project(filename: str, project: str) -> bool:
    """Return True if filename belongs to the given project."""
    tag = project.upper()
    return f"-{tag}-" in filename or filename.startswith(f"{tag}.")


# BUG-MSO-2026-0662 F2: an in-flight backup's tmp file is named
# ``{zip_name}.{owning_pid}.tmp`` (see ``backup()`` below) specifically so a
# concurrent sweep can tell "mine" from "someone else's" instead of treating
# every ``*.zip.tmp`` in the directory as fair game. A file from BEFORE this
# fix (or a foreign tool) carries no pid segment at all — it is judged on age
# alone, same as a pid-bearing file whose owner cannot be confirmed dead.
_TMP_NAME_RE = re.compile(
    r"^maestro-backup-.+-(?P<ts>\d{4}-\d{2}-\d{2}-\d{6})\.zip(?:\.(?P<pid>\d+))?\.tmp$"
)

# No real backup this codebase runs takes anywhere near this long (even a
# worst-case near-BACKUP_MAX_FILES archive is a matter of seconds) — ten
# minutes is a wide margin against false "abandoned" positives while still
# being a firm, well-clear-of-any-legitimate-run cutoff for a truly stale
# file (e.g. one whose owning pid was reused by an unrelated process).
_STALE_TMP_AGE_SECONDS = 600


def _is_pid_alive(pid: int) -> bool:
    """Self-contained, cross-platform liveness check.

    Deliberately does not import ``maestro.core.fleet_runner`` (which has an
    equivalent ``is_process_alive``) — mirrors ``maestro/migrate.py``'s own
    ``_process_alive`` helper and its stated reason: this module stays a
    light, dependency-free leaf so ``mso backup``/``mso cleanup`` never pull
    in the whole dispatcher just to check a pid.
    """
    if pid <= 0:
        return False
    try:
        if os.name == "nt":
            import ctypes

            PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            STILL_ACTIVE = 259
            ERROR_ACCESS_DENIED = 5
            kernel32 = ctypes.windll.kernel32
            handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
            if not handle:
                # BUG-MSO-2026-0677 F2: an ERROR_ACCESS_DENIED OpenProcess
                # failure means the process EXISTS and is owned by another
                # user/session — the Windows analogue of POSIX EPERM, and the
                # identical "cannot confirm == absent" inference
                # BUG-MSO-2026-0672 F3 fixed on the POSIX branch just below.
                # Any other failure (e.g. ERROR_INVALID_PARAMETER for a pid
                # that never existed or has already been reaped) genuinely
                # means no such process — return False for those.
                return ctypes.GetLastError() == ERROR_ACCESS_DENIED
            try:
                exit_code = ctypes.c_ulong()
                if kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code)):
                    return exit_code.value == STILL_ACTIVE
                return False
            finally:
                kernel32.CloseHandle(handle)
        else:
            os.kill(pid, 0)
            return True
    except ProcessLookupError:
        # errno ESRCH — no such process. This is the ONLY POSIX outcome that
        # confirms the process is actually gone.
        return False
    except PermissionError:
        # BUG-MSO-2026-0672 F3: errno EPERM means signal delivery was denied
        # — the process EXISTS and is owned by another user, the OPPOSITE of
        # dead. The prior blanket `except (..., PermissionError, ...):
        # return False` mapped "I could not verify because I lack
        # permission" to "absent", which let `_sweep_stale_zip_tmp_files`
        # delete a LIVE foreign-owned backup's in-flight `.tmp`,
        # reintroducing the BUG-MSO-2026-0662 F2 race this pid segment
        # exists to close. Same inference bug as BUG-MSO-2026-0665 F1,
        # BUG-MSO-2026-0668 F1 and BUG-MSO-2026-0669: "cannot confirm" is
        # never "absent" — treat the owner as alive.
        return True
    except OSError:
        # Any other, rarer failure (e.g. a transient kernel error) is also
        # "cannot confirm" — fail toward PRESENT, not toward "dead and safe
        # to delete", for the same reason as the PermissionError branch.
        return True


def _sweep_stale_zip_tmp_files(output_dir: Path) -> None:
    """BUG-MSO-2026-0656 F3 / BUG-MSO-2026-0662 F2: delete only a leftover
    ``*.zip*.tmp`` that is genuinely abandoned, never one a concurrent
    backup still owns.

    ``backup()``'s own ``except BaseException`` below cannot help with a
    hard kill (``mso cleanup``'s ``_kill_process_tree`` -> ``taskkill /F`` /
    ``SIGKILL``) — that terminates the process immediately, before ANY
    Python exception handler runs, so a timed-out cleanup's partial archive
    is never cleaned up by the code that wrote it. Sweeping stale ``.tmp``
    files on the NEXT backup run bounds the leak instead of relying on a
    handler the killing path structurally cannot reach.

    The original (0656 F3) version unlinked EVERY ``*.zip.tmp`` unconditionally
    — so a second, concurrent backup (e.g. `mso cleanup` triggered twice back
    to back, or a Hub Run click racing an operator's own `mso cleanup`)
    deleted the FIRST backup's still-being-written temp file out from under
    it: the first backup's ``tmp_path.replace(zip_path)`` then raised
    ``FileNotFoundError``, destroying the very restore point the auto-backup
    exists to guarantee. A file is only swept when it is either (a) owned by
    a pid that is no longer alive, or (b) old enough — by its OWN embedded
    backup timestamp, not filesystem mtime, which a slow/networked
    filesystem or a copy operation can perturb — that no real backup could
    still be legitimately writing it. Best-effort throughout: a file that
    disappears or is still locked mid-sweep is not this run's problem.
    """
    if not output_dir.exists():
        return
    now = datetime.now()
    own_pid = os.getpid()
    for stale in output_dir.iterdir():
        if not stale.is_file():
            continue
        match = _TMP_NAME_RE.match(stale.name)
        if not match:
            continue

        # Age is computed FIRST and, if certainly-abandoned, wins outright —
        # never gated behind the pid-liveness check below. A pid can be
        # reused by an unrelated process after the original owner exits; if
        # that happened, treating the reused pid as "still live" would
        # otherwise wedge this file un-sweepable forever (every future sweep
        # would keep seeing a "live" owner). Once a file is old enough that
        # no real backup could possibly still be writing it, whether its pid
        # happens to be held by *something* right now is irrelevant.
        age_seconds: Optional[float] = None
        try:
            age_seconds = (now - datetime.strptime(match.group("ts"), "%Y-%m-%d-%H%M%S")).total_seconds()
        except ValueError:
            pass
        if age_seconds is None:
            try:
                age_seconds = time.time() - stale.stat().st_mtime
            except OSError:
                continue
        certainly_abandoned = age_seconds >= _STALE_TMP_AGE_SECONDS

        owner_pid = int(match.group("pid")) if match.group("pid") else None
        owned_by_self = owner_pid == own_pid
        owned_by_dead_process = (
            owner_pid is not None and not owned_by_self and not _is_pid_alive(owner_pid)
        )
        if not (certainly_abandoned or owned_by_self or owned_by_dead_process):
            continue  # young, and either unowned or owned by a live process — leave it

        try:
            stale.unlink()
        except OSError:
            pass


def backup(
    workspace: Path,
    project: Optional[str] = None,
    output_dir: Optional[Path] = None,
) -> Optional[Path]:
    """
    Create a versioned ZIP archive of project state files.

    Args:
        workspace:  Workspace root (directory containing .mso/).
        project:    If set, only include files for this project acronym.
        output_dir: Directory to write the ZIP to (default: workspace/maestro-backups/).

    Returns:
        Path to the created ZIP archive.
    """
    from maestro import __version__ as maestro_version

    if output_dir is None:
        output_dir = workspace / "maestro-backups"
    output_dir.mkdir(parents=True, exist_ok=True)
    _sweep_stale_zip_tmp_files(output_dir)

    timestamp = datetime.now().strftime("%Y-%m-%d-%H%M%S")
    tag = project.upper() if project else "all"
    zip_name = f"maestro-backup-{tag}-{timestamp}.zip"
    zip_path = output_dir / zip_name

    collected: list[tuple[Path, str]] = []  # (absolute_path, archive_name)

    from maestro.workspace import resolve_artefact_dir
    mso_dir = resolve_artefact_dir(workspace)
    for rel in BACKUP_INCLUDES:
        target_dir = mso_dir / rel
        if not target_dir.exists():
            continue
        for file_path in sorted(target_dir.rglob("*")):
            if not file_path.is_file():
                continue
            # Skip any file whose path passes through an excluded directory.
            if any(part in BACKUP_EXCLUDE_DIRS for part in file_path.parts):
                continue
            if project and not _matches_project(file_path.name, project):
                continue
            archive_name = str(file_path.relative_to(workspace)).replace("\\", "/")
            collected.append((file_path, archive_name))
            if len(collected) > BACKUP_MAX_FILES:
                import warnings
                warnings.warn(
                    f"[Maestro] Auto-backup skipped: workspace contains more than "
                    f"{BACKUP_MAX_FILES} files (likely a large node_modules or build "
                    f"artefact tree). Run 'mso backup' manually after excluding large dirs.",
                    stacklevel=2,
                )
                return None

    # Also glob per-project config files
    projects_config_dir = mso_dir / "config" / "projects"
    if projects_config_dir.exists():
        for file_path in sorted(projects_config_dir.glob("*.json")):
            if not file_path.is_file():
                continue
            archive_name = str(file_path.relative_to(workspace)).replace("\\", "/")
            # Avoid duplicates (config/ is already in BACKUP_INCLUDES)
            if not any(arc == archive_name for _, arc in collected):
                if not project or _matches_project(file_path.name, project):
                    collected.append((file_path, archive_name))

    # Root files — always included regardless of project filter
    for rel_str in _ROOT_FILES:
        file_path = workspace / rel_str
        if file_path.exists() and file_path.is_file():
            archive_name = rel_str.replace("\\", "/")
            if not any(arc == archive_name for _, arc in collected):
                collected.append((file_path, archive_name))

    manifest = {
        "version": 1,
        "created_at": datetime.now().isoformat(),
        "workspace": str(workspace),
        "projects_included": [project.upper()] if project else ["ALL"],
        "maestro_version": maestro_version,
        "file_count": len(collected),
    }

    # BUG-MSO-2026-0653 F2: write to a same-directory temp file and rename
    # into place only once the archive is fully written. A process killed
    # mid-write (e.g. the Hub's dispatcher.cleanup Run handler hitting its
    # timeout during this exact step) used to leave a TRUNCATED, corrupt ZIP
    # sitting at `zip_path` — the one restore point cleanup's own auto-backup
    # exists to guarantee. `Path.replace()` is an atomic same-filesystem
    # rename on both Windows and POSIX, so `zip_path` now either never
    # appears (killed before the rename) or appears complete — never half
    # written.
    #
    # BUG-MSO-2026-0662 F2: the owning pid is embedded in the tmp filename
    # (matched by _TMP_NAME_RE above) so a concurrent backup's sweep can tell
    # this file is still LIVE-OWNED rather than deleting it out from under
    # this call — see _sweep_stale_zip_tmp_files's docstring.
    tmp_path = zip_path.parent / f"{zip_path.name}.{os.getpid()}.tmp"
    try:
        with zipfile.ZipFile(tmp_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("manifest.json", json.dumps(manifest, indent=2))
            for abs_path, arc_name in collected:
                zf.write(abs_path, arc_name)
        tmp_path.replace(zip_path)
    except BaseException:
        tmp_path.unlink(missing_ok=True)
        raise

    return zip_path


def restore(
    backup_file: Path,
    workspace: Path,
    project: Optional[str] = None,
    force: bool = False,
    merge: bool = False,
    dry_run: bool = False,
) -> None:
    """
    Extract files from a backup ZIP with conflict resolution.

    Conflict resolution (default = skip existing):
        --force  Overwrite all existing files.
        --merge  Keep whichever file is newer by mtime.
        --dry-run  Print actions without writing anything.
    """
    if not backup_file.exists():
        raise SystemExit(f"[Maestro] Backup file not found: {backup_file}")

    with zipfile.ZipFile(backup_file, "r") as zf:
        names = zf.namelist()
        if "manifest.json" not in names:
            raise SystemExit(
                f"[Maestro] Invalid backup — manifest.json missing in {backup_file}"
            )

        extracted = skipped = overwritten = 0

        for zi in zf.infolist():
            if zi.filename == "manifest.json":
                continue
            if project and not _matches_project(Path(zi.filename).name, project):
                continue

            dest = workspace / zi.filename
            if dest.exists():
                if force:
                    action = "OVERWRITE"
                elif merge:
                    # Compare mtimes
                    arc_mtime = datetime(*zi.date_time).timestamp()
                    dest_mtime = dest.stat().st_mtime
                    if dest_mtime >= arc_mtime:
                        action = "KEEP-EXISTING"
                    else:
                        action = "EXTRACT"
                else:
                    action = "SKIP"
            else:
                action = "EXTRACT"

            print(f"  [{action}] {zi.filename}")

            if dry_run:
                if action in ("EXTRACT", "OVERWRITE"):
                    extracted += 1
                elif action == "KEEP-EXISTING":
                    skipped += 1
                else:
                    skipped += 1
                continue

            if action in ("EXTRACT", "OVERWRITE"):
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(zf.read(zi.filename))
                if action == "OVERWRITE":
                    overwritten += 1
                else:
                    extracted += 1
            else:
                skipped += 1

    prefix = "[DRY RUN] " if dry_run else ""
    print(
        f"\n{prefix}[Maestro] Restore complete — "
        f"extracted: {extracted}, overwritten: {overwritten}, skipped: {skipped}"
    )


def list_backups(backup_dir: Path) -> list[dict]:
    """
    Return metadata for all backup ZIPs in backup_dir.

    Each dict contains manifest fields plus a 'file' key (Path).
    Sorted by created_at descending. ZIPs without a valid manifest
    are returned with just {'file': ..., 'error': '...'}.
    """
    if not backup_dir.exists():
        return []

    results: list[dict] = []
    for zip_path in sorted(backup_dir.glob("*.zip")):
        try:
            with zipfile.ZipFile(zip_path, "r") as zf:
                if "manifest.json" not in zf.namelist():
                    raise ValueError("no manifest.json")
                manifest = json.loads(zf.read("manifest.json"))
            manifest["file"] = zip_path
            results.append(manifest)
        except Exception as exc:
            results.append({"file": zip_path, "error": str(exc)})

    results.sort(
        key=lambda d: d.get("created_at", ""),
        reverse=True,
    )
    return results
