"""
Maestro exception taxonomy.

Domain code raises these instead of bare RuntimeError / SystemExit so the
central CLI handler can present a consistent, user-friendly error surface.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Callable


class MaestroError(Exception):
    """Base class for all Maestro user-facing errors.

    Attributes:
        hint  -- optional actionable next step shown below the error message
        exit_code -- process exit code (default 1)
    """

    exit_code: int = 1

    def __init__(self, message: str, *, hint: str | None = None) -> None:
        super().__init__(message)
        self.hint = hint


class MaestroUserError(MaestroError):
    """Bad user input or invocation mistake — exit 2."""

    exit_code = 2


class MaestroConfigError(MaestroError):
    """Workspace / config / licence not set up correctly — exit 1."""

    exit_code = 1


class MaestroNoWorkError(MaestroError):
    """Nothing to do (e.g. empty queue, no pending orders) — exit 3."""

    exit_code = 3


class MaestroAmbiguityError(MaestroUserError):
    """Multiple candidates match; user must disambiguate — exit 2 (inherits MaestroUserError)."""


def run_cli(main_fn: "Callable[[], None]", command: str = "") -> None:
    """Entry-point wrapper for subprocess-dispatched core scripts.

    Catches MaestroError → clean message + correct exit code.
    Catches unexpected exceptions → concise message; full traceback only under MAESTRO_DEBUG.
    Catches KeyboardInterrupt → silent clean exit (code 0) for interactive-quit gestures.

    BUG-MSO-2026-0681 F1: `main_fn()`'s own return value is now propagated as
    the process exit code when it is a non-zero int. Before this fix the
    return value was discarded entirely — every `main()` in this codebase
    (fleet_runner.py, fleet_monitor.py, fleet_usage_tracker.py,
    post_voyage_verify.py) already `return`s 0/1/a subprocess returncode with
    exit-code semantics (e.g. `mso cleanup`'s live-dispatcher refusal does
    `return 1`), but the interpreter always exited 0 unless an exception
    escaped — so a refused `mso cleanup` reported success to `mso cleanup &&
    mso dispatch` chains and to the Slack bridge's return-code classification
    alike. A `None`/`0` return still exits 0, so every existing caller that
    never explicitly returns keeps its current (correct) exit-0 behaviour.
    """
    import os
    import sys
    import traceback
    from maestro.cli_ui import print_error, print_unexpected

    cmd = command or (main_fn.__name__ if hasattr(main_fn, "__name__") else "maestro")
    try:
        result = main_fn()
    except MaestroError as exc:
        print_error(str(exc), hint=exc.hint)
        sys.exit(exc.exit_code)
    except KeyboardInterrupt:
        sys.exit(0)
    except SystemExit:
        raise
    except Exception as exc:
        if os.environ.get("MAESTRO_DEBUG"):
            traceback.print_exc()
        else:
            print_unexpected(exc, cmd)
        sys.exit(1)
    else:
        if isinstance(result, int) and result != 0:
            sys.exit(result)
