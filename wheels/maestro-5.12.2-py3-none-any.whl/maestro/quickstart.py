"""
maestro/quickstart.py — Guided first-run experience for Admiralty.

Phases:
  0  Pre-flight checks
  1  Workspace init
  2  Demo voyage creation
  3  Fleet dispatch (streams crew output)
  4  Completion summary
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

from maestro.workspace import MSO_DIR_NAME

# ---------------------------------------------------------------------------
# Demo voyage content (embedded — immune to template drift)
# ---------------------------------------------------------------------------

# Order templates — orderId is filled in at runtime once we know
# {project} / {year} / {seq}. dependsOn references use the same template.
DEMO_ORDER_TEMPLATES: list[dict] = [
    {
        "orderIdTemplate": "NAV-{project}-{year}-{seq}",
        "type": "NAV",
        "title": "Draft a hello-world plan",
        "description": (
            "Write a one-page plan for a Python script that prints "
            "'Hello from Admiralty!'. Save the plan to "
            + MSO_DIR_NAME + "/plans/PLAN-{project}-{year}-{seq}.md. The plan must include: "
            "purpose, one implementation step, and success criteria."
        ),
        "priority": "NORMAL",
        "targetRole": "NAV",
        "dependsOnTemplates": [],
    },
    {
        "orderIdTemplate": "FTR-{project}-{year}-{seq}",
        "type": "FTR",
        "title": "Implement hello.py",
        "description": (
            "Read the plan at .mso/plans/PLAN-{project}-{year}-{seq}.md. Create "
            "a file hello.py in the current directory that prints "
            "'Hello from Admiralty!' when run with `python hello.py`. The file "
            "must be executable and contain a __main__ guard."
        ),
        "priority": "NORMAL",
        "targetRole": "SHP",
        "dependsOnTemplates": ["NAV-{project}-{year}-{seq}"],
    },
    {
        "orderIdTemplate": "BOS-{project}-{year}-{seq}",
        "type": "BOS",
        "title": "Verify hello.py",
        "description": (
            "Run `python hello.py` and confirm the output is exactly "
            "'Hello from Admiralty!'. Write a one-sentence QA report to "
            + MSO_DIR_NAME + "/reports/qa/QA-{project}-{year}-{seq}.md stating PASS or FAIL "
            "with the actual output observed."
        ),
        "priority": "NORMAL",
        "targetRole": "BOS",
        "dependsOnTemplates": ["FTR-{project}-{year}-{seq}"],
    },
]


# ---------------------------------------------------------------------------
# Pre-flight checks
# ---------------------------------------------------------------------------

def check_api_key() -> None:
    """Verify the operator has SOME path to Claude.

    Two auth paths are supported (BUG-ADM-2026-0006):

      A. Claude Code subscription auth — `claude /login` browser OAuth.
         The `claude` CLI manages its own credentials; no env var
         needed. This is how a Pro / Team / Enterprise subscriber pays
         for usage.

      B. Anthropic API key — pay-per-token. Set ANTHROPIC_API_KEY in
         the operator's shell; Claude Code picks it up automatically.

    A is sufficient by itself. B is sufficient by itself. We don't
    require both. We can't easily probe whether `claude` is logged in
    (no stable `claude auth status` API yet), so we let `claude --version`
    in check_claude_cli() be the proxy: if Claude Code responds, we
    trust whichever auth path the customer has set up. If a crew later
    fails because auth is broken, Claude Code surfaces that error
    directly with a helpful message.

    Set MAESTRO_REQUIRE_API_KEY=1 to opt back into the strict check
    (rare — useful for CI runs that intentionally use API-key auth).
    """
    require_api_key = os.environ.get("MAESTRO_REQUIRE_API_KEY") == "1"
    has_api_key = bool(os.environ.get("ANTHROPIC_API_KEY"))

    if require_api_key and not has_api_key:
        print(
            "\nError: ANTHROPIC_API_KEY is not set "
            "(MAESTRO_REQUIRE_API_KEY=1 is on).\n\n"
            "  Set your API key before running quickstart:\n\n"
            "    set ANTHROPIC_API_KEY=sk-ant-...      # Windows cmd\n"
            '    $env:ANTHROPIC_API_KEY="sk-ant-..."   # PowerShell\n'
            "    export ANTHROPIC_API_KEY=sk-ant-...   # macOS / Linux / WSL\n\n"
            "  Get a key at: https://console.anthropic.com/settings/keys",
            file=sys.stderr,
        )
        sys.exit(1)

    # Default path: trust check_claude_cli() to verify Claude Code is
    # callable. Print an info note so the operator knows which auth
    # path is active.
    if has_api_key:
        print("✓ ANTHROPIC_API_KEY found — crews will use API-key billing")
    else:
        print(
            "✓ Using Claude Code subscription auth (no ANTHROPIC_API_KEY set).\n"
            "  If `claude /login` succeeded, crews will run on your subscription.\n"
            "  To use API-key billing instead: set ANTHROPIC_API_KEY=sk-ant-..."
        )


def check_claude_cli() -> None:
    if sys.platform == "win32" and shutil.which("claude") is None:
        print(
            "\nError: Claude Code is not available natively on Windows.\n\n"
            "  Admiralty on Windows requires WSL2 (Windows Subsystem for Linux).\n\n"
            "  Setup steps:\n"
            "    1. Install WSL2:  wsl --install\n"
            "    2. Open a WSL terminal and install Admiralty inside it:\n"
            "         pip install maestro-fleet\n"
            "    3. Run from WSL: adm quickstart\n\n"
            "  See: https://learn.microsoft.com/windows/wsl/install",
            file=sys.stderr,
        )
        sys.exit(1)

    if shutil.which("claude") is None:
        print(
            "\nError: Claude Code CLI not found on PATH.\n\n"
            "  Admiralty crews run inside Claude Code sessions.\n"
            "  Install Claude Code first:\n\n"
            "    npm install -g @anthropic-ai/claude-code   # requires Node 18+\n\n"
            "  Then re-run: adm quickstart\n\n"
            "  Docs: https://docs.anthropic.com/claude-code",
            file=sys.stderr,
        )
        sys.exit(1)

    # Verify claude responds
    try:
        result = subprocess.run(
            ["claude", "--version"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            raise RuntimeError("non-zero exit")
        version = result.stdout.strip() or result.stderr.strip()
        print(f"✓ Claude Code detected ({version})")
    except Exception:
        print(
            "\nError: Claude Code CLI found but did not respond to --version.\n\n"
            "  Try: claude --version\n"
            "  If that fails, reinstall Claude Code:\n"
            "    npm install -g @anthropic-ai/claude-code",
            file=sys.stderr,
        )
        sys.exit(1)


def check_python_version() -> None:
    # Track pyproject.toml `requires-python = ">=3.9"`; bump both together.
    if sys.version_info < (3, 9):
        print(
            f"\nError: Python 3.9+ required (found {sys.version}).\n"
            "  Upgrade Python and re-run: adm quickstart",
            file=sys.stderr,
        )
        sys.exit(1)


def check_no_running_fleet(adm_dir: Path) -> None:
    """Warn if a dispatcher lock is present, naming a remedy that actually works.

    BUG-MSO-2026-0691 F3/F4/F5 (same class, found by this order's required
    enumeration): this warning suggested `adm cleanup` — a command that has
    not existed since the v4.0 cutover removed the `adm` console-script
    entry point — and it fired on the mere EXISTENCE of dispatcher.pid, so
    even the correct `mso` spelling would have been wrong much of the time:
    against a genuinely LIVE dispatcher, plain `mso cleanup` refuses outright
    (BUG-MSO-2026-0673 F1), and `--force` still never stops the dispatcher
    PROCESS. Three states, three different remedies — say which one applies
    rather than naming one command that cannot work in two of the three.
    """
    from maestro.core.fleet_monitor import is_process_alive

    pid_file = adm_dir / "dispatcher.pid"
    if not pid_file.exists():
        return
    try:
        pid = int(pid_file.read_text(encoding="utf-8").strip())
    except (ValueError, OSError):
        # BUG-MSO-2026-0691 F7: unverifiable == HELD (dispatch will refuse),
        # and `mso cleanup --force` is the one command that clears it.
        print(
            "\nWarning: the dispatcher lock exists but its contents could "
            f"not be read ({pid_file}).\n"
            "  It is treated as held, so dispatch will refuse. Clear it "
            "with: mso cleanup --force\n"
            "  Or proceed at your own risk — crews may conflict.",
        )
        return
    if is_process_alive(pid):
        kill_cmd = f"taskkill /F /PID {pid}" if os.name == "nt" else f"kill {pid}"
        print(
            f"\nWarning: a dispatcher is already running (PID {pid}).\n"
            f"  Stop it first (Ctrl+C the dispatcher, or {kill_cmd}) — "
            "`mso cleanup` refuses against a live dispatcher, and --force "
            "does not stop the process either.\n"
            "  Or proceed at your own risk — crews may conflict.",
        )
        return
    print(
        f"\nWarning: a STALE dispatcher lock was left behind (PID {pid} is "
        f"no longer running: {pid_file}).\n"
        "  Clear it with: mso cleanup\n"
        "  Or proceed at your own risk — crews may conflict.",
    )


def run_preflight(adm_dir: Path, skip: bool = False) -> None:
    if skip:
        print("⚡ Pre-flight checks skipped (--skip-checks).")
        return

    check_api_key()  # prints its own status line (subscription vs API-key)

    check_claude_cli()  # prints its own success line

    check_python_version()
    print("✓ Python version OK")

    check_no_running_fleet(adm_dir)

    print("✓ Environment ready\n")


# ---------------------------------------------------------------------------
# Phase 1 — Workspace init
# ---------------------------------------------------------------------------

def init_workspace(project: str, directory: Path) -> None:
    from maestro.init import scaffold_workspace
    from maestro.workspace import resolve_artefact_dir

    adm_dir = resolve_artefact_dir(directory)
    if adm_dir.exists():
        print(f"⚠  Workspace already initialised at {adm_dir} — continuing.")
    else:
        print("Initialising demo workspace...")
        scaffold_workspace(project=project, directory=directory, force=False)
        print("✓ Workspace initialised (.mso/)\n")


# ---------------------------------------------------------------------------
# Phase 1.5 — Repo link
# ---------------------------------------------------------------------------

_PLACEHOLDER_ORG = "your-org"

# Per-commit identity for the local-mode bootstrap commit.
# Avoids depending on the user's global git config — a fresh machine
# without `user.name`/`user.email` would otherwise fail `git commit`
# and crash quickstart.
_DEMO_COMMIT_NAME = "Admiralty Demo"
_DEMO_COMMIT_EMAIL = "demo@admiraltyai.com"


def _compute_voyage_branch(project: str, year: int, seq: str) -> str:
    return f"voyage/VOY-{project}-{year}-{seq}"


def _prompt_repo() -> str | None:
    """Ask the user if they want to link a GitHub repo; return org/name or None."""
    try:
        answer = input("Link this demo to a GitHub repo for end-to-end testing? (Y/n): ").strip()
    except EOFError:
        return None
    if answer.lower() in ("n", "no"):
        return None
    try:
        repo = input("Enter the repo (org/name): ").strip()
    except EOFError:
        return None
    return repo or None


def _validate_repo(repo: str) -> None:
    """Validate org/name via gh api. Raises RuntimeError on failure."""
    if shutil.which("gh") is None:
        raise RuntimeError(
            "GitHub CLI (gh) is required for repo linking.\n"
            "  Install: https://cli.github.com/\n"
            "  Or use --no-link-repo for local-only mode."
        )
    auth = subprocess.run(["gh", "auth", "status"], capture_output=True, text=True)
    if auth.returncode != 0:
        raise RuntimeError(
            "Not authenticated with GitHub CLI.\n"
            "  Run: gh auth login\n"
            "  Or use --no-link-repo for local-only mode."
        )
    result = subprocess.run(
        ["gh", "api", f"repos/{repo}"],
        capture_output=True, text=True,
    )
    if result.returncode != 0:
        raise RuntimeError(
            f"Repo '{repo}' not found or insufficient access (gh api returned {result.returncode}).\n"
            "  Check the repo name and your GitHub permissions.\n"
            "  Or use --no-link-repo for local-only mode."
        )


def _link_repo_remote(
    repo: str, project: str, adm_dir: Path, voyage_branch: str, force: bool = False
) -> None:
    """Update .mso/config/projects.json with the real repo."""
    projects_json = adm_dir / "config" / "projects.json"
    data: dict = {}
    if projects_json.exists():
        try:
            data = json.loads(projects_json.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            data = {}

    projects = data.get("projects", {})
    existing = projects.get(project, {})
    current_repo = existing.get("repo", "")

    if current_repo and not current_repo.startswith(_PLACEHOLDER_ORG) and not force:
        raise RuntimeError(
            f"projects.json already has a repo configured: '{current_repo}'\n"
            "  Use --force to overwrite."
        )

    org, name = (repo.split("/", 1) + [""])[:2]
    existing.update({
        "repo": repo,
        "org": org,
        "name": name,
        "cloneProtocol": "https",
    })
    projects[project] = existing
    data["projects"] = projects
    projects_json.write_text(json.dumps(data, indent=2), encoding="utf-8")
    print(f"✓ Repo linked: {repo}")


def _link_repo_local(adm_dir: Path, voyage_branch: str) -> None:
    """Ensure a local git repo + voyage branch exist (no push, no PR)."""
    if shutil.which("git") is None:
        raise RuntimeError(
            "Git is required for local-only mode but was not found on PATH.\n"
            "  Install Git: https://git-scm.com/downloads\n"
            "  Then re-run: adm quickstart --no-link-repo"
        )

    cwd = adm_dir.parent

    # Check if already a git repo
    is_git = subprocess.run(
        ["git", "rev-parse", "--git-dir"],
        capture_output=True, cwd=str(cwd),
    ).returncode == 0

    if not is_git:
        subprocess.run(["git", "init"], check=True, capture_output=True, cwd=str(cwd))
        # Ensure HEAD is real before creating voyage branch
        gitkeep = cwd / ".gitkeep"
        gitkeep.write_text("", encoding="utf-8")
        subprocess.run(["git", "add", ".gitkeep"], check=True, capture_output=True, cwd=str(cwd))
        # Per-commit identity flags so a fresh machine without
        # global user.name / user.email doesn't crash the bootstrap.
        subprocess.run(
            ["git",
             "-c", f"user.name={_DEMO_COMMIT_NAME}",
             "-c", f"user.email={_DEMO_COMMIT_EMAIL}",
             "commit", "-m", "chore: init for Admiralty demo"],
            check=True, capture_output=True, cwd=str(cwd),
        )

    # Create voyage branch (ignore error if it already exists)
    result = subprocess.run(
        ["git", "checkout", "-b", voyage_branch],
        capture_output=True, cwd=str(cwd),
    )
    if result.returncode != 0:
        # Branch may already exist — check it out
        subprocess.run(
            ["git", "checkout", voyage_branch],
            check=True, capture_output=True, cwd=str(cwd),
        )

    print(f"✓ Local-only mode — demo runs on branch {voyage_branch} (no push, no PR)")


def link_demo_repo(args, project: str, adm_dir: Path) -> tuple[str | None, str]:
    """Phase 1.5 — determine and set up the repo + branch for the demo voyage.

    Returns (target_repo | None, voyage_branch).
    """
    from datetime import datetime, timezone

    now = datetime.now(timezone.utc)
    year = now.year
    seq = _next_demo_seq(adm_dir, project, year)
    voyage_branch = _compute_voyage_branch(project, year, seq)

    no_link = getattr(args, "no_link_repo", False)
    repo_flag = getattr(args, "repo", None)
    force = getattr(args, "force", False)
    is_tty = sys.stdin.isatty()

    if repo_flag:  # Mode B — explicit repo
        _validate_repo(repo_flag)
        _link_repo_remote(repo_flag, project, adm_dir, voyage_branch, force=force)
        return repo_flag, voyage_branch

    if no_link or not is_tty:  # Mode C — local only
        _link_repo_local(adm_dir, voyage_branch)
        return None, voyage_branch

    # Mode A — interactive
    print(
        "\nRepo link (optional)\n"
        "  Linking a GitHub repo lets crews commit artefacts, open PRs, and produce\n"
        "  visible end-to-end results. Skip to run in local-only mode instead.\n"
    )
    user_repo = _prompt_repo()
    if user_repo:
        try:
            _validate_repo(user_repo)
            _link_repo_remote(user_repo, project, adm_dir, voyage_branch, force=force)
            return user_repo, voyage_branch
        except RuntimeError as exc:
            print(f"\nWarning: Could not link repo — {exc}\nFalling back to local-only mode.\n")

    _link_repo_local(adm_dir, voyage_branch)
    return None, voyage_branch


# ---------------------------------------------------------------------------
# Phase 2 — Demo voyage creation
# ---------------------------------------------------------------------------

def _next_demo_seq(adm_dir: Path, project: str, year: int) -> str:
    """Pick a 4-digit sequence that doesn't collide with existing demo artefacts.

    Scans queues + orders + voyages for `*-{project}-{year}-NNNN.json` and returns
    one greater than the highest match (or 0001 if none).
    """
    import re

    pattern = re.compile(rf"-{re.escape(project)}-{year}-(\d{{4}})")
    highest = 0
    for sub in ("queues/orders", "queues/proposed", "orders/active",
                "orders/complete", "voyages/active", "voyages/complete"):
        d = adm_dir / sub
        if not d.exists():
            continue
        for f in d.glob(f"*-{project}-{year}-*.json"):
            m = pattern.search(f.stem)
            if m:
                highest = max(highest, int(m.group(1)))
    return f"{highest + 1:04d}"


def create_demo_voyage(
    project: str,
    adm_dir: Path,
    target_repo: str | None = None,
    voyage_branch: str | None = None,
) -> tuple[str, list[str]]:
    """Materialise the demo voyage + orders into the dispatcher's queue.

    Returns (voyage_id, [order_id, ...]) for callers that need to poll completion.
    target_repo is set on each order when provided (modes A/B only).
    voyage_branch is REQUIRED — without it the dispatcher falls through a
    non-functional path and the demo silently produces no work
    (the original FTR-ADM-2026-0128 root cause).
    """
    if not voyage_branch:
        raise ValueError(
            "create_demo_voyage(): voyage_branch is required. "
            "Call link_demo_repo() first to compute one — passing None or "
            "an empty string regresses BUG/FTR-ADM-2026-0128 (silent demo failure)."
        )

    from datetime import datetime, timezone

    now = datetime.now(timezone.utc)
    year = now.year
    seq = _next_demo_seq(adm_dir, project, year)

    fmt = {"project": project, "year": year, "seq": seq}
    voyage_id = f"VOY-{project}-{year}-{seq}"

    # Materialise each order from its template, preserving template→ID mapping
    # so dependsOn references stay correct after substitution.
    orders: list[dict] = []
    for tpl in DEMO_ORDER_TEMPLATES:
        order_id = tpl["orderIdTemplate"].format(**fmt)
        order: dict = {
            "orderId": order_id,
            "type": tpl["type"],
            "project": project,
            "title": tpl["title"],
            "description": tpl["description"].format(**fmt),
            "priority": tpl["priority"],
            "status": "PENDING",
            "voyageId": voyage_id,
            "targetRole": tpl["targetRole"],
            "role": tpl["targetRole"],
            "roleSequence": [tpl["targetRole"]],
            "dependsOn": [d.format(**fmt) for d in tpl["dependsOnTemplates"]],
            "voyageBranch": voyage_branch,
        }
        if target_repo:
            order["targetRepo"] = target_repo
        orders.append(order)

    # Write voyage JSON
    voyage: dict = {
        "voyageId": voyage_id,
        "project": project,
        "title": "Admiralty Demo",
        "status": "ACTIVE",
        "createdAt": now.isoformat(),
        "orders": [o["orderId"] for o in orders],
        "voyageBranch": voyage_branch,
    }
    if target_repo:
        voyage["targetRepo"] = target_repo
    voyages_dir = adm_dir / "voyages" / "active"
    voyages_dir.mkdir(parents=True, exist_ok=True)
    (voyages_dir / f"{voyage_id}.json").write_text(
        json.dumps(voyage, indent=2), encoding="utf-8"
    )

    # Write orders into the dispatcher's queue (it scans .mso/queues/**, not
    # .mso/orders/active/, so PENDING here is the only thing that actually runs).
    queues_dir = adm_dir / "queues" / "orders"
    queues_dir.mkdir(parents=True, exist_ok=True)
    for order in orders:
        (queues_dir / f"{order['orderId']}.json").write_text(
            json.dumps(order, indent=2), encoding="utf-8"
        )

    order_ids = [o["orderId"] for o in orders]
    print(f"✓ Demo voyage created  ({voyage_id})")
    print(f"✓ 3 orders queued      ({' · '.join(order_ids)})\n")
    return voyage_id, order_ids


# ---------------------------------------------------------------------------
# Phase 3 — Dispatch
# ---------------------------------------------------------------------------

QUICKSTART_TIMEOUT_SECONDS = 600  # 10 min cap on the demo run


def stream_dispatch(
    crews: int,
    adm_dir: Path,
    expected_order_ids: list[str] | None = None,
) -> float:
    """Kick `mso dispatch` (which detaches) and wait for the demo orders to land
    in `.mso/orders/complete/`. Returns elapsed seconds.

    The dispatcher launches detached so its stdout is unreachable; instead
    we poll the filesystem for terminal-state evidence.
    """
    crews = max(1, min(crews, 3))
    print(f"Dispatching {crews} crew(s)… (Ctrl-C to detach — crews keep running)\n")

    cmd = [sys.executable, "-m", "maestro.cli", "dispatch", "--max-crews", str(crews)]
    subprocess.run(cmd, check=False)

    t0 = time.monotonic()
    complete_dir = adm_dir / "orders" / "complete"
    expected = list(expected_order_ids or [])
    expected_count = len(expected) or 3
    last_done = -1
    metric_recorded = False

    try:
        while time.monotonic() - t0 < QUICKSTART_TIMEOUT_SECONDS:
            if complete_dir.exists():
                done_files = (
                    [f for f in complete_dir.glob("*.json") if f.stem in expected]
                    if expected
                    else list(complete_dir.glob("*.json"))
                )
            else:
                done_files = []
            done = len(done_files)
            if done != last_done:
                print(f"  {done}/{expected_count} demo orders complete")
                last_done = done
                if done >= 1 and not metric_recorded:
                    _record_first_output_metric(adm_dir, int((time.monotonic() - t0) * 1000))
                    metric_recorded = True
            if done >= expected_count:
                return time.monotonic() - t0
            time.sleep(2)
    except KeyboardInterrupt:
        print("\n⚡ Detached — crews are still running. Monitor with: adm status")
        sys.exit(0)

    print("  ⚠ Timed out after 10 min. Run `mso status` to inspect crew state.")
    return time.monotonic() - t0


def _record_first_output_metric(adm_dir: Path, first_ms: int) -> None:
    usage_dir = adm_dir / "usage" / "orders"
    usage_dir.mkdir(parents=True, exist_ok=True)
    metric_file = usage_dir / "QS-FIRST-OUTPUT.json"
    metric_file.write_text(
        json.dumps({"quickstart_phase3_first_output_ms": first_ms}, indent=2),
        encoding="utf-8",
    )


# ---------------------------------------------------------------------------
# Phase 4 — Completion banner
# ---------------------------------------------------------------------------

def print_completion_banner(elapsed: float, orders: int) -> None:
    mins = int(elapsed // 60)
    secs = int(elapsed % 60)
    elapsed_str = f"{mins}m {secs}s" if mins else f"{secs}s"

    print(
        "\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        " Admiralty quickstart complete! 🎉\n\n"
        f" {orders} orders completed in {elapsed_str}\n"
        " Results: .mso/orders/complete/\n\n"
        " Next steps:\n"
        "   adm status          — monitor a real fleet\n"
        "   adm docs            — full documentation\n"
        "   adm voyage create   — start a real voyage\n"
        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    )


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def run_quickstart(args) -> None:
    project = args.project.upper()
    directory = Path.cwd()
    from maestro.workspace import resolve_artefact_dir
    adm_dir = resolve_artefact_dir(directory)

    run_preflight(adm_dir, skip=getattr(args, "skip_checks", False))

    init_workspace(project, directory)
    # init_workspace may have just created .mso/ — re-resolve in case
    # the artefact dir has moved (e.g. artefact dir resolution).
    adm_dir = resolve_artefact_dir(directory)

    if getattr(args, "no_demo", False):
        print("✓ Environment verified. Run `mso dispatch` to start a real fleet.")
        return

    target_repo, voyage_branch = link_demo_repo(args, project, adm_dir)

    _voyage_id, order_ids = create_demo_voyage(
        project, adm_dir, target_repo=target_repo, voyage_branch=voyage_branch
    )

    elapsed = stream_dispatch(
        getattr(args, "crews", 1), adm_dir, expected_order_ids=order_ids
    )

    print_completion_banner(elapsed, len(order_ids))
