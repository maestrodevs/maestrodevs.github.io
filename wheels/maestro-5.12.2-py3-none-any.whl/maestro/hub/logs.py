# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""maestro/hub/logs.py — the Hub daemon's log file and exit record.

BUG-MSO-2026-0712. Until this module existed the Hub backend was spawned
with ``stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL`` and wrote no
log anywhere, so a daemon that died left NO evidence of any kind: on
2026-09-09 the Hub started at 19:43 (PID 13792) and was found dead at 21:40
by an operator opening the dashboard, with ``mso hub status`` able to say
only ``STOPPED``. Every candidate cause — a uvicorn/FastAPI exception, a
Windows console-session teardown of the ``DETACHED_PROCESS`` child, a test
suite reaching the real ``~/.maestro/hub.pid``, a licence re-verification
failing the tier gate — would have been a single line in a log file that
did not exist.

The Hub is a GLOBAL daemon, not a per-workspace one, so it has no
``.mso/logs/lifecycle.log`` to write to; its evidence lives beside its PID
file under the Maestro home (``~/.maestro`` by default, redirected by
``MAESTRO_HOME`` — so tests never touch an operator's real files)::

    ~/.maestro/logs/hub.log        combined stdout+stderr of the daemon
    ~/.maestro/logs/hub.log.1..N   rotated backups
    ~/.maestro/hub.exit.json       last recorded exit (code, time, traceback)

Two DIFFERENT sources of evidence, deliberately kept separate:

* ``hub.log`` is captured at the OS file-descriptor level (the spawned
  process's real stdout/stderr handles), so it catches output no in-process
  Python logging handler could — a native-level crash, an import failure
  before any handler is installed, uvicorn's own startup diagnostics.
* ``hub.exit.json`` is written by the daemon itself
  (:mod:`maestro.hub.__main__`) on the way out, so it carries the exit code
  and traceback for the causes a process CAN observe about itself. A hard
  kill (``taskkill /F``, a console-session teardown, an OOM) records
  nothing here — which is why :func:`read_exit_record` results are always
  reported as "if the daemon recorded one", never assumed present.

Rotation is checked at daemon START, and only there. That is not a
shortcut, it is the only moment the file is guaranteed not to be held open
by a live daemon — Windows cannot rename an open file, so rotating from a
reader (``mso hub status``, the ``hub.alive`` patrol check) would fail or,
worse, race a running Hub. A healthy Hub runs with ``log_level="warning"``
and no access log, so it writes almost nothing between restarts; the file
grows on errors, which is exactly what a size cap is for.
"""

from __future__ import annotations

import json
import os
import traceback as _traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import IO, Optional

from maestro.workspace import get_maestro_home

# 2 MiB per file, three backups — enough to hold every restart of a
# crash-looping Hub for a working day without ever becoming a disk problem.
HUB_LOG_MAX_BYTES = 2 * 1024 * 1024
HUB_LOG_BACKUPS = 3


def hub_log_dir() -> Path:
    """``<maestro home>/logs`` — resolved live so ``MAESTRO_HOME`` redirects
    it (BUG-MSO-2026-0387), exactly like ``daemon._hub_pid_file``."""
    return get_maestro_home() / "logs"


def hub_log_path() -> Path:
    return hub_log_dir() / "hub.log"


def exit_record_path() -> Path:
    return get_maestro_home() / "hub.exit.json"


# ---------------------------------------------------------------------------
# Rotation + writing
# ---------------------------------------------------------------------------

def rotate_if_needed(
    path: Optional[Path] = None,
    *,
    max_bytes: int = HUB_LOG_MAX_BYTES,
    backups: int = HUB_LOG_BACKUPS,
) -> bool:
    """Roll ``hub.log`` -> ``hub.log.1`` -> ... when it has reached
    *max_bytes*. Returns ``True`` when a rotation happened.

    Never raises: losing a rotation must never stop the Hub from starting.
    A failure here simply means the current file keeps growing, which is
    strictly better than the pre-0712 behaviour of no file at all.
    """
    log = Path(path) if path is not None else hub_log_path()
    try:
        if not log.exists() or log.stat().st_size < max_bytes:
            return False
        oldest = log.with_name(log.name + ".{}".format(backups))
        if oldest.exists():
            oldest.unlink()
        for index in range(backups - 1, 0, -1):
            src = log.with_name(log.name + ".{}".format(index))
            if src.exists():
                src.replace(log.with_name(log.name + ".{}".format(index + 1)))
        log.replace(log.with_name(log.name + ".1"))
        return True
    except OSError:
        return False


def open_log_for_append() -> IO[bytes]:
    """Open ``hub.log`` for binary append, rotating first, and return the
    handle the daemon's stdout/stderr are wired to.

    Binary append is deliberate: the handle is inherited by a detached child
    whose writes must land even if it dies without flushing a Python-level
    text buffer.
    """
    hub_log_dir().mkdir(parents=True, exist_ok=True)
    rotate_if_needed()
    return open(hub_log_path(), "ab")


def _stamp() -> str:
    return datetime.now(timezone.utc).isoformat()


def append_line(text: str) -> None:
    """Append one already-formatted line to ``hub.log``. Best-effort."""
    try:
        hub_log_dir().mkdir(parents=True, exist_ok=True)
        with open(hub_log_path(), "a", encoding="utf-8", errors="replace") as fh:
            fh.write(text.rstrip("\n") + "\n")
            fh.flush()
    except OSError:
        pass


def write_start_banner(port: int, pid: Optional[int] = None, version: Optional[str] = None) -> None:
    """First line of every run — the anchor a reader uses to tell one
    daemon's output from the previous one's in a shared, rotating file."""
    pid = pid if pid is not None else os.getpid()
    if version is None:
        try:
            import maestro
            version = getattr(maestro, "__version__", None)
        except Exception:  # noqa: BLE001 — a banner must never break startup
            version = None
    append_line(
        "=== [{}] Hub daemon START pid={} port={} version={} ===".format(
            _stamp(), pid, port, version or "unknown"
        )
    )


def tail(lines: int = 5, path: Optional[Path] = None) -> "list[str]":
    """Last *lines* non-empty lines of ``hub.log``, oldest first.

    Returns ``[]`` for a missing/unreadable/empty log — "no evidence" is
    reported as emptiness by every caller, never as a fabricated line.
    """
    log = Path(path) if path is not None else hub_log_path()
    try:
        raw = log.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []
    content = [ln.rstrip("\r\n") for ln in raw.splitlines() if ln.strip()]
    if lines <= 0:
        return []
    return content[-lines:]


# ---------------------------------------------------------------------------
# Exit record — what the daemon itself managed to say on the way out
# ---------------------------------------------------------------------------

def write_exit_record(
    exit_code: Optional[int],
    *,
    pid: Optional[int] = None,
    error: Optional[BaseException] = None,
) -> Optional[Path]:
    """Record how THIS process is exiting, for a later ``mso hub status``.

    Best-effort by construction: it is called on the way out of a dying
    process, so a failure to write it must never mask the original cause of
    death. Returns the path on success, ``None`` otherwise.
    """
    record = {
        "pid": pid if pid is not None else os.getpid(),
        "exitCode": exit_code,
        "at": _stamp(),
    }
    if error is not None:
        record["error"] = "{}: {}".format(type(error).__name__, error)
        try:
            record["traceback"] = "".join(
                _traceback.format_exception(type(error), error, error.__traceback__)
            )
        except Exception:  # noqa: BLE001
            record["traceback"] = None
    try:
        path = exit_record_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
        return path
    except OSError:
        return None


def read_exit_record() -> Optional[dict]:
    """The last recorded exit, or ``None`` when the daemon never got to
    record one (a hard kill, a console-session teardown, an OOM) — the
    common case this module is careful never to paper over."""
    try:
        raw = exit_record_path().read_text(encoding="utf-8")
    except OSError:
        return None
    try:
        data = json.loads(raw)
    except (ValueError, TypeError):
        return None
    return data if isinstance(data, dict) else None


def clear_exit_record() -> None:
    """Drop any previous run's exit record at start, so a status read can
    never attribute an OLD death to the run that is starting now."""
    try:
        exit_record_path().unlink()
    except OSError:
        pass


def log_unhandled_exception(error: BaseException, *, port: Optional[int] = None) -> None:
    """Write *error*'s full traceback into ``hub.log`` before the process
    goes away — the "an unhandled backend exception is logged with
    traceback before exit" half of BUG-MSO-2026-0712's contract.

    Written through :func:`append_line` (a fresh handle) rather than through
    the inherited stderr fd, so it lands even when the failure IS the
    inherited handle.
    """
    try:
        text = "".join(_traceback.format_exception(type(error), error, error.__traceback__))
    except Exception:  # noqa: BLE001
        text = "{}: {}".format(type(error).__name__, error)
    where = " port={}".format(port) if port is not None else ""
    append_line(
        "=== [{}] Hub daemon UNHANDLED EXCEPTION pid={}{} ===\n".format(_stamp(), os.getpid(), where)
        + text.rstrip("\n")
    )
