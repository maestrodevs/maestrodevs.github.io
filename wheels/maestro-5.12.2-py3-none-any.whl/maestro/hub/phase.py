# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Derived voyage lifecycle phase (FTR-MSO-2026-0351).

The stored voyage ``status`` field is static ('PLANNED') and the manifest's
embedded order statuses go stale, so the Hub could not tell operators which
voyages actually need them. This module computes a derived ``phase`` from the
authoritative sources instead:

- per-order effective status: runtime order-ledger (replayed) > archived
  order files (orders/complete|failed) > live ledger claim > queue/manifest
  status
- voyage PR merge state: manifest merge metadata (mergedPR/mergedAt, written
  by ``mso voyage reconcile``) or archival to voyages/complete WITH NO PR ever
  linked (auto-finalised, no code deliverable — BUG-MSO-2026-0394)

Phase precedence (checked top-down):
1. ``merged``          — voyage PR merged, OR an operator manually confirmed
                          it complete (``mergeDetectedBy: "manual"``), OR its
                          PR closed without merging but carried no code
                          deliverable (``closedNoCodeDeliverable`` —
                          BUG-MSO-2026-0471), OR voyage archived with no PR
                          ever linked (nothing for a human to review)
2. ``needs_attention`` — DEADLOCKED (BUG-MSO-2026-0699: every remaining order
                          is transitively held behind a terminal non-COMPLETE
                          one — reason names the blocking order and the command
                          that unsticks it, via the shared
                          ``maestro.core.deadlock`` classifier), OR >=1 order
                          blocked (STALLED/FAILED/...) and nothing the fleet
                          can advance without a human, OR its PR closed without
                          merging and real work was abandoned
                          (``closedWithoutMerge`` — FTR-MSO-2026-0373 /
                          BUG-MSO-2026-0471)
3. ``final_review``    — all orders terminal-COMPLETE, not yet merged (this
                          also covers an archived voyage whose PR is still
                          open — FTR-MSO-2026-0287 archives a voyage to
                          voyages/complete once all orders finish, which is
                          NOT the same event as the PR merging)
4. ``underway``        — >=1 order progressing / fleet can still advance
5. ``backlog``         — nothing started
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Iterable, Optional

PHASE_MERGED = "merged"
PHASE_NEEDS_ATTENTION = "needs_attention"
PHASE_FINAL_REVIEW = "final_review"
PHASE_UNDERWAY = "underway"
PHASE_BACKLOG = "backlog"


# ---------------------------------------------------------------------------
# Status bucket classification  (moved to core — BUG-MSO-2026-0699)
# ---------------------------------------------------------------------------
#
# The status vocabulary and the three-plane effective-status resolution below
# used to be DEFINED here. BUG-MSO-2026-0699 needed the same answers in core
# (the dispatcher's idle watchdog, `mso status`, `mso doctor`), and core must
# never import the Hub, so they moved down to `maestro/core/order_status.py`
# and are re-exported here VERBATIM. Every existing importer of
# `maestro.hub.phase` — the Hub aggregator, the patrol voyage checks, the test
# suite — keeps working unchanged; there is still exactly one implementation.
#
# The private `_`-prefixed set names are kept as aliases for the same reason.

from maestro.core.order_status import (  # noqa: E402  (re-export)
    BLOCKED_STATUSES as _BLOCKED_STATUSES,
    COMPLETE_STATUSES as _COMPLETE_STATUSES,
    HELD_STATUSES as _HELD_STATUSES,
    IN_PROGRESS_STATUSES as _IN_PROGRESS_STATUSES,
    classify_status,
    effective_order_status,
    load_json_safe as _load_json_safe,
    load_ledger_view,
    read_archive_statuses,
)

def merge_metadata_trustworthy(data: dict) -> bool:
    """True when a voyage manifest's recorded merge state should be trusted
    as "PR merged" (BUG-MSO-2026-0569).

    A genuinely merged GitHub PR always carries a ``mergedAt`` timestamp. If
    the manifest carries an explicit ``merged`` boolean AND a ``mergedAt``
    key that is present but EMPTY, that combination did not learn its claim
    from the PR record — it was inferred or defaulted, most likely by
    raw-git content-equality detection with no gh corroboration available
    (see ``_annotate_completed_multi_repo_voyage`` / ``reconcile_completed_
    voyage_pr_merges`` in ``maestro/core/fleet_runner.py``, which now refuse
    to WRITE that shape — this is the matching read-side guard for a record
    that slipped through before the fix, or was hand-edited). Such a claim
    is treated as NOT merged rather than trusted.

    A ``mergedAt`` key that is simply ABSENT (as opposed to present-and-empty)
    is not penalised — that is the shape of a legitimate hand-set
    ``merged: true`` signal (an operator/manual override with no PR timestamp
    to record), which every writer in this codebase already treats as
    trustworthy. Only an empty value that was actively WRITTEN is the
    inconsistency tell this guards against.

    BUG-MSO-2026-0612-01 / Captain ruling D3(a): trustworthiness is decided
    by the verdict's PROVENANCE, not by the presence of ``mergedAt``. A
    raw-git-ancestry verdict (``mergeDetectedBy == "git"``, written by
    ``reconcile_completed_voyage_pr_merges`` / ``_annotate_completed_multi_
    repo_voyage`` in ``maestro/core/fleet_runner.py``) is a legitimate merge
    determination that simply has no timestamp to offer (GitLab/Bitbucket/
    no-gh environments never produce one) — those two facts are not in
    tension, so a null/absent ``mergedAt`` under ``"git"`` provenance is
    trusted. A PR-sourced verdict (``mergeDetectedBy`` anything else,
    including absent) still fails the empty-``mergedAt`` check below: a
    genuine GitHub merge always carries a timestamp, so an empty one there
    remains the GH #375 inconsistency tell.

    Older/writer paths that never set the ``merged`` boolean at all (only
    ``mergedAt``/``mergedPR``/``mergeCommit``) fall back to the legacy
    any-of-these-truthy signal — those are never written inconsistently
    (mergedAt is always the real timestamp when present), so no extra check
    is needed for that shape.
    """
    if "merged" in data:
        merged = bool(data.get("merged"))
        if (merged and "mergedAt" in data and not data.get("mergedAt")
                and data.get("mergeDetectedBy") != "git"):
            return False  # claims merged but its own evidence field is empty
        return merged
    return bool(
        data.get("mergedPR") or data.get("mergedAt")
        or data.get("prMerged") or data.get("mergeCommit")
    )


# ---------------------------------------------------------------------------
# Phase computation
# ---------------------------------------------------------------------------

@dataclass
class MemberState:
    """One voyage member order, reduced to what the phase engine needs."""
    order_id: str
    status: str                      # effective status, uppercase
    role: str = ""                   # current/target role (reason strings)
    depends_on: list[str] = field(default_factory=list)
    # BUG-MSO-2026-0476: the order's full roleSequence, used to recognise a
    # standalone plan-approval order (roleSequence == [<planning role>], no
    # BLD/TST/etc. after it) — such an order's completion delivers no code.
    role_sequence: list[str] = field(default_factory=list)


def _is_plan_only(role_sequence: list[str]) -> bool:
    """True when *role_sequence* is exactly one planning role.

    A standalone plan-approval order (BUG-MSO-2026-0205) never gets a next
    role — its roleSequence is popped down to just the planning role. A
    normal order that merely STARTS with a planning role (e.g. PLN, BLD, TST)
    has more than one entry and is not plan-only.
    """
    from maestro.core.gates import is_planning_role
    return len(role_sequence) == 1 and is_planning_role(role_sequence[0])


@dataclass
class VoyagePhase:
    phase: str
    reason: str
    rollup: dict[str, int]


def _voyage_deadlock(members, dep_status, voyage_id, skipped_ids):
    """The shared deadlock verdict for these members, or ``None``.

    BUG-MSO-2026-0699: `MemberState` is structurally compatible with
    `maestro.core.deadlock.DeadlockMember` (order_id / status / depends_on), so
    the classifier consumes this list directly — the Hub does not build, and
    must not build, a second member model. Best-effort: a classifier failure
    degrades to the pre-0699 phase precedence rather than breaking the board.
    """
    try:
        from maestro.core.deadlock import classify_voyage_deadlock
        return classify_voyage_deadlock(
            voyage_id or "", members, dep_status=dep_status,
            skipped_ids=skipped_ids or (),
        )
    except Exception:
        return None


def _blocked_reason(blocked: list[MemberState]) -> str:
    parts = []
    for m in blocked[:2]:
        part = f"{m.order_id} {m.status}"
        if m.role:
            part += f" at {m.role}"
        parts.append(part)
    extra = len(blocked) - len(parts)
    reason = "; ".join(parts)
    if extra > 0:
        reason += f" (+{extra} more)"
    return reason


def compute_voyage_phase(
    members: list[MemberState],
    pr_merged: bool = False,
    voyage_archived: bool = False,
    dep_status: Optional[Callable[[str], str]] = None,
    closed_without_merge: bool = False,
    pr_linked: bool = False,
    closed_no_code_deliverable: bool = False,
    manually_resolved: bool = False,
    voyage_id: str = "",
    skipped_ids: "Optional[Iterable[str]]" = None,
) -> VoyagePhase:
    """Derive (phase, reason, rollup) for one voyage.

    ``dep_status`` resolves a dependency order id (possibly outside this
    voyage) to its effective status; used to decide whether a PENDING member
    is actually dispatchable. Defaults to looking within *members*.

    ``closed_without_merge`` (FTR-MSO-2026-0373): reconcile detected that the
    voyage's PR was CLOSED without merging (remote branch deleted, changes
    absent from base). Such a voyage needs a human even though its orders may
    all be COMPLETE — surface it as ``needs_attention`` (unless it has actually
    merged/archived, which always wins).

    ``pr_linked`` (BUG-MSO-2026-0394): a PR is recorded for at least one repo
    on the manifest (flat prUrl/prNumber, or a non-empty prUrls map), even
    though no merge metadata has been recorded yet. ``voyage_archived`` alone
    means "sitting in voyages/complete/" — which FTR-MSO-2026-0287 also does
    the moment all of a voyage's orders finish, well before its PR is
    reviewed/merged. So an archived voyage with a PR still linked (open) must
    NOT collapse to ``merged`` — it falls through to the normal precedence
    below, landing on ``final_review``. Only an archived voyage with NO PR
    ever linked (auto-finalised, no code deliverable) keeps the pre-existing
    shortcut straight to ``merged``.

    ``closed_no_code_deliverable`` (BUG-MSO-2026-0471): reconcile determined
    that an archived voyage's PR was CLOSED without merging, but the branch
    carried no real code deliverable beyond artefact-plane bookkeeping (a
    planning-only voyage) — closing it lost nothing, so this is a correct
    terminal state, not an operator problem. It wins the same way ``pr_merged``
    does, REGARDLESS of ``pr_linked`` (the whole point is that this voyage
    still carries a ``prNumber`` — that's what made rule 1's old ``not
    pr_linked`` shortcut miss it in the first place). Mutually exclusive with
    ``closed_without_merge`` in practice — reconcile sets exactly one — but if
    a caller somehow set both, this (the "safe" outcome) is checked first, so
    ``merged`` wins over ``needs_attention``.

    ``voyage_id`` / ``skipped_ids`` (BUG-MSO-2026-0699): passed through to
    ``maestro.core.deadlock.classify_voyage_deadlock()`` — the ONE shared
    deadlock classifier, so the Hub's ``needs_attention`` reason names the
    blocking order and its retry command in the same words `mso status`,
    `mso doctor` and the LEAD finding use. Both are optional: with no
    ``voyage_id`` the verdict is still computed (the reason text simply has no
    voyage id to quote), and with no ``skipped_ids`` an operator-skipped
    blocker is missed but nothing is misreported.

    ``manually_resolved`` (BUG-MSO-2026-0471): the manifest's
    ``mergeDetectedBy`` field reads ``"manual"`` — an operator's explicit
    hand-recorded completion signal (as opposed to the automated ``"pr"``/
    ``"git"`` detection paths). Previously written but never read by the Hub.
    Treated with the same top precedence as ``pr_merged``: an operator saying
    "this is done" is not second-guessed by the derived phase.
    """
    rollup = {"total": len(members), "complete": 0, "blocked": 0,
              "inProgress": 0, "pending": 0, "held": 0}
    buckets: dict[str, list[MemberState]] = {
        "complete": [], "blocked": [], "inProgress": [], "pending": [], "held": [],
    }
    for m in members:
        b = classify_status(m.status)
        rollup[b] += 1
        buckets[b].append(m)

    # BUG-MSO-2026-0476: a voyage whose members are ALL standalone plan-only
    # orders, all complete, has delivered no code — nothing to build was ever
    # filed. Left unchecked this is indistinguishable from a finished voyage
    # (falls straight into final_review, or merged if auto-archived with no
    # PR ever linked). Refuse both shortcuts unless a human actually decided
    # otherwise — a merged PR, an operator confirmation, or a reconcile
    # determination that there was no code deliverable (BUG-MSO-2026-0471).
    # Those three ARE the "genuine, reviewed decision" this guard defers to.
    all_plan_only = bool(members) and all(_is_plan_only(m.role_sequence) for m in members)
    if (all_plan_only and rollup["complete"] == rollup["total"]
            and not pr_merged and not manually_resolved
            and not closed_no_code_deliverable):
        return VoyagePhase(
            PHASE_NEEDS_ATTENTION,
            "plan approved but no build orders were filed for this voyage "
            "— cut BLD/FTR orders to continue",
            rollup,
        )

    if pr_merged or manually_resolved or closed_no_code_deliverable or (
            voyage_archived and not pr_linked):
        reason = "PR merged" if pr_merged else (
            "operator manually confirmed complete" if manually_resolved else (
                "PR closed without merging — no code deliverable" if closed_no_code_deliverable
                else "voyage archived"))
        return VoyagePhase(PHASE_MERGED, reason, rollup)

    # FTR-MSO-2026-0373: a closed-without-merge voyage needs an operator
    # decision regardless of its (possibly all-complete) order rollup.
    if closed_without_merge:
        return VoyagePhase(
            PHASE_NEEDS_ATTENTION,
            "PR closed without merging — reopen/re-dispatch or archive manually",
            rollup,
        )

    total = rollup["total"]
    if total == 0:
        return VoyagePhase(PHASE_BACKLOG, "no orders", rollup)

    if dep_status is None:
        local = {m.order_id: m.status for m in members}
        def dep_status(oid: str) -> str:  # noqa: F811 — deliberate default
            return local.get(oid, "PENDING")

    def _dispatchable(m: MemberState) -> bool:
        return all(
            classify_status(dep_status(d)) == "complete"
            for d in (m.depends_on or [])
        )

    dispatchable_pending = [m for m in buckets["pending"] if _dispatchable(m)]

    # 2a. needs_attention — DEADLOCKED (BUG-MSO-2026-0699). Checked BEFORE the
    # generic blocked branch below so the reason names the blocking order and
    # the command that unsticks it, rather than the bare "ORD-1 STALLED at BLD"
    # rollup the Hub board showed the Captain on 2026-09-09. Same verdict,
    # same wording, one implementation — `maestro/core/deadlock.py`.
    deadlock = _voyage_deadlock(members, dep_status, voyage_id, skipped_ids)
    if deadlock is not None:
        return VoyagePhase(PHASE_NEEDS_ATTENTION, deadlock.detail(), rollup)

    # 2b. needs_attention — something is stuck AND the fleet cannot advance
    # anything else on its own (held orders also need a human, so they don't
    # rescue the voyage from this phase).
    if rollup["blocked"] >= 1 and rollup["inProgress"] == 0 and not dispatchable_pending:
        return VoyagePhase(
            PHASE_NEEDS_ATTENTION, _blocked_reason(buckets["blocked"]), rollup)

    # BUG-MSO-2026-0499: a PROPOSED/HELD dependent (the "held" bucket) whose
    # own dependsOn is unmet — or was met but not yet released by the
    # dispatcher's auto-queue pass — cannot be picked up by the fleet, same
    # as a blocked order. Left unchecked, reaching rule 4 below with
    # complete/blocked >= 1 (some UPSTREAM order finished) and no in-progress
    # crew falls straight into "underway" even though nothing can actually
    # happen next — the exact false-positive this bug reports (a voyage
    # showing Underway while a dependency-satisfied dependent sits stranded
    # at PROPOSED/HELD indefinitely). Gated on complete/blocked >= 1 so a
    # voyage that has genuinely never started (only held/review-gated
    # orders, nothing has run yet) still falls through to plain `backlog`
    # below rather than a false attention alarm.
    if (
        rollup["held"] >= 1
        and rollup["inProgress"] == 0
        and not dispatchable_pending
        and (rollup["complete"] >= 1 or rollup["blocked"] >= 1)
    ):
        return VoyagePhase(
            PHASE_NEEDS_ATTENTION, _blocked_reason(buckets["held"]), rollup)

    # 3. final_review — everything done, awaiting PR review + merge.
    if rollup["complete"] == total:
        return VoyagePhase(
            PHASE_FINAL_REVIEW,
            f"all {total} orders complete — awaiting PR review + merge",
            rollup,
        )

    # 4. underway — a crew is on it, or work has progressed / can progress.
    # Reaching here with blocked >= 1 means dispatchable pending work exists,
    # so the fleet can still advance the voyage on its own.
    if rollup["inProgress"] >= 1 or rollup["complete"] >= 1 or rollup["blocked"] >= 1:
        bits = [f"{rollup['complete']}/{total} complete"]
        if rollup["inProgress"]:
            bits.append(f"{rollup['inProgress']} in progress")
        if rollup["blocked"]:
            bits.append(f"{rollup['blocked']} blocked")
        return VoyagePhase(PHASE_UNDERWAY, ", ".join(bits), rollup)

    # 5. backlog — nothing started.
    return VoyagePhase(
        PHASE_BACKLOG, f"none of {total} orders started", rollup)
