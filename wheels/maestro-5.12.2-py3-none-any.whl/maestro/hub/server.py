# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Maestro Hub FastAPI application.

FastAPI and uvicorn are imported lazily inside create_app() so that
`import maestro.hub.server` never fails when the [hub] extra is absent.
"""

# Poll interval (seconds) for the WebSocket lifecycle stream. Patchable in tests.
_WS_POLL_INTERVAL: float = 2.0

# BUG-MSO-2026-0395 — dispatch guard messages (kept as module constants so the
# backend and its tests share one source of truth).
OBSERVE_ONLY_MESSAGE = (
    "This Hub is an observe-only deployment — it cannot launch a usable "
    "dispatcher here. Dispatch from a host session (`mso dispatch`) or run the "
    "Hub natively (`mso hub start`)."
)
STALE_MOUNT_MESSAGE = (
    "Workspace registry is temporarily unreadable (stale mount / I/O error). "
    "Restart the Hub containers (e.g. `docker compose restart`) and retry."
)
# BUG-MSO-2026-0440 — housekeeping (broom) has its OWN capability requirement,
# which is not the dispatcher's. See _sweep_unavailable_reason().
SWEEP_UNAVAILABLE_MESSAGE = (
    "Housekeeping needs the GitHub CLI (`gh`) to read authoritative PR merge "
    "state, and `gh` is not available in this Hub deployment. Run "
    "`mso voyage reconcile` from a host session instead — it is the same code "
    "path and needs no dispatcher."
)
# FTR-MSO-2026-0489: single source of truth for the licence-tier gate shared by
# every mutating control endpoint (dispatch/stop/sweep/review) AND by
# /api/v1/capabilities — the 403 an operator meets after clicking and the
# reason /capabilities showed before the click must be the same sentence.
CONTROL_TIER_MESSAGE = (
    "Maestro Hub dispatch control requires a Team or Enterprise licence."
)


def _env_truthy(name: str) -> bool:
    """True when env var *name* is set to a truthy value (1/true/yes/on)."""
    import os
    return os.environ.get(name, "").strip().lower() in ("1", "true", "yes", "on")


def _in_container() -> bool:
    """Best-effort container detection (the Docker runtime drops /.dockerenv)."""
    import os
    try:
        return os.path.exists("/.dockerenv")
    except OSError:
        return False


def _is_observe_only() -> bool:
    """Return True when this backend cannot spawn a usable host dispatcher.

    Primary signal: the ``MAESTRO_HUB_CONTAINERIZED`` env flag, set in
    ``docker/hub/Dockerfile.backend`` — a containerized backend has no Claude
    CLI and only sees container-registry paths, so a spawned dispatcher is a
    silent no-op (BUG-MSO-2026-0395). Fallback heuristic: running inside a
    container with no ``claude`` on PATH. The heuristic is gated on container
    detection so a native host that merely lacks ``claude`` on PATH (e.g. CI)
    is NOT misclassified as observe-only.
    """
    import shutil
    if _env_truthy("MAESTRO_HUB_CONTAINERIZED"):
        return True
    if _in_container() and shutil.which("claude") is None:
        return True
    return False


def _live_installed_version():
    """Freshly resolve the version actually installed on disk right now.

    BUG-MSO-2026-0627: `maestro.__version__` is cached in ``sys.modules`` at
    first import and stays FROZEN for the rest of the process's life — a
    long-running Hub daemon can serve stale code for days after a `pip
    install --upgrade` and have no way to notice on its own. `importlib.
    metadata.version()` reads the installed distribution's metadata straight
    off disk on every call (it is not part of the frozen module cache), so it
    picks up a reinstall without needing this process to restart — the same
    property that lets ``pip list --outdated``-style tooling work inside a
    long-lived interpreter. Tries both the private-channel distribution name
    (``maestro``) and the public PyPI one (``maestro-fleet``, see CLAUDE.md's
    install section) since either could be the one actually installed.
    Returns ``None`` (never raises) if neither distribution is found — a
    dev checkout with no installed distribution metadata is not an error.
    """
    import importlib.metadata as _metadata

    for dist_name in ("maestro", "maestro-fleet"):
        try:
            return _metadata.version(dist_name)
        except _metadata.PackageNotFoundError:
            continue
        except Exception:
            continue
    return None


def _sweep_unavailable_reason():
    """Why housekeeping cannot run in this deployment, or None if it can.

    BUG-MSO-2026-0440: the sweep endpoint was gated on ``_is_observe_only()``,
    which answers a DIFFERENT question — "can this backend spawn a usable
    dispatcher?" — and answers it by probing for the Claude CLI. Housekeeping
    needs neither a dispatcher nor the Claude CLI; FTR-MSO-2026-0426 is explicit
    that it is pull-based precisely so it works without one. Gating it on the
    dispatcher check refused the broom button for the wrong reason and returned
    OBSERVE_ONLY_MESSAGE, which tells the operator to run ``mso dispatch`` —
    advice that has nothing to do with housekeeping and cannot resolve it.

    What sweep actually needs is ``gh``: FTR-MSO-2026-0426 made the GitHub PR
    record AUTHORITATIVE for merge detection (raw-git ancestry is only the
    offline fallback, and deliberately degrades to "unknown" rather than risk a
    false "merged"). Without ``gh`` a sweep would still run but could not resolve
    any PR-backed voyage, so refusing remains correct — the fix is to refuse for
    the TRUE reason and to name the action that actually works.
    """
    import shutil
    if shutil.which("gh") is None:
        return SWEEP_UNAVAILABLE_MESSAGE
    return None


# BUG-MSO-2026-0670 F1: bound for the LEAD Run endpoint's pre-flight
# condition re-check, run as a killable subprocess (see
# _run_single_check_subprocess below). Matches run_verbs.py's own
# _VOYAGE_RECONCILE_TIMEOUT_SECONDS deliberately: the one check that costs
# real time — voyages.merged-not-archived — runs the EXACT SAME gh-backed
# dry-run sweep the real reconcile handler this pre-check gates also runs.
# A shorter bound would spuriously refuse a click the real action would
# have completed within its own 300s budget. Every other check
# (dispatcher.heartbeat, voyages.stalled-order-deadlock, ...) is a pure
# on-disk read and returns in well under a second regardless of this
# ceiling — the cost of this bound is paid only in the gh-backed case.
_PRE_CHECK_TIMEOUT_SECONDS = 300


def _run_single_check_subprocess(mso, check_id: str, subject_id: str, product_repo):
    """Re-run exactly ONE patrol check as a killable OS subprocess and report
    whether *subject_id* is still open.

    This is the out-of-process replacement for calling ``maestro.patrol.
    run_single_check()`` directly on the request thread, which is what the
    LEAD Run endpoint's pre-flight re-check (BUG-MSO-2026-0662 F1) did until
    now. That direct call is CORRECT to keep — re-confirming a finding's
    condition immediately before acting on it is what stops a stale
    ``dispatcher.heartbeat`` finding from firing ``mso cleanup`` against a
    now-healthy dispatcher and killing live crews — but running it IN-PROCESS
    was the expensive way, and for a gh-backed check
    (``voyages.merged-not-archived``, which itself runs a full
    ``run_housekeeping_sweep(dry_run=True)``) that meant:

      * entering ``order_retry.workspace_scope()`` and holding the
        PROCESS-GLOBAL ``_SCOPE_LOCK`` — on THIS Hub process — for the full
        duration of a gh round trip. Every other concurrent
        ``workspace_scope()`` acquirer (another Run click, an order-retry
        POST) blocked on an UNBOUNDED lock for as long as gh took to answer;
      * no timeout at all — the exact in-process-sweep hazard
        ``run_verbs.py``'s own BUG-MSO-2026-0648 F1 note forbids for the
        Hub's real action handlers, just not (until this fix) for this
        pre-check;
      * restoring, in effect, the double-gh-sweep-per-click cost
        BUG-MSO-2026-0643 F3 removed from the action path — one gh sweep for
        the pre-check, another for the action itself, and this one blocking
        the whole Hub while it ran.

    A subprocess is a genuinely separate OS process — its own
    ``_SCOPE_LOCK``, its own ``_MAESTRO_DIR_OVERRIDE`` — and
    ``subprocess.run``'s own timeout handling actually KILLS it
    (``process.kill()``) rather than merely giving up waiting on it, exactly
    like ``run_verbs._handle_voyage_reconcile`` already does for the real
    action. Delegates to ``mso doctor --single-check`` (see
    ``maestro.cli.cmd_doctor``), which wraps ``run_single_check()`` and never
    touches ``patrol-state.json`` or the LEAD daemon's own ``state.json`` —
    same guarantee the in-process call had, so this remains safe to call
    concurrently with a running LEAD daemon.

    WORSE, and how it's bounded: this call can now take up to
    ``_PRE_CHECK_TIMEOUT_SECONDS`` (300s) by itself for a gh-backed check, on
    top of Python subprocess start-up (well under a second — negligible next
    to a gh round trip). A Run click against such a finding can therefore
    take up to 300s for the pre-check plus up to another 300s for the
    action's own bound (``run_verbs._VOYAGE_RECONCILE_TIMEOUT_SECONDS``)
    before the operator sees a result — worse, for THAT ONE CLICK, than the
    old in-process call usually was. That cost is paid only by the requester
    who clicked Run and is fully bounded/killable; it is never paid by any
    OTHER concurrent Hub caller, which is the actual outage this fixes. If
    the subprocess cannot complete within its bound, this returns
    ``verified=False`` — the caller (the Run endpoint) already fails CLOSED
    on that, refusing the action rather than proceeding on unconfirmed state.

    BUG-MSO-2026-0686 F2: spawned via ``Popen`` (never ``subprocess.run``),
    with a timeout that kills the WHOLE process tree via
    ``_kill_process_tree`` on expiry — identical to the fix applied to
    ``run_verbs._handle_voyage_reconcile`` (F1) and to the pre-existing
    ``run_verbs._handle_dispatcher_cleanup``. A plain
    ``subprocess.run(timeout=)`` only kills the DIRECT child — the gh/git
    GRANDCHILD `mso doctor --single-check` can be stuck on (for the same
    ``voyages.merged-not-archived`` check `_handle_voyage_reconcile` itself
    runs) survives it, so the 300s ceiling was not a real bound: every
    refused-then-retried Run leaked another orphaned gh process.
    """
    import json as _json
    import os
    import subprocess
    import sys

    from maestro.core.crew import _kill_process_tree
    from maestro.core.proc import popen_hidden
    from maestro.patrol import SingleCheckResult

    cmd = [
        sys.executable, "-m", "maestro.cli", "doctor",
        "--single-check", check_id, "--subject-id", subject_id or "",
        "--maestro-dir", str(mso),
    ]
    # cwd prefers the product repo (needed for the pack/bundle policy tiers
    # of the resolved patrol definition, same as run_patrol's own
    # `workspace=` parameter) but falls back to the artefact root itself
    # when no product-repo checkout is registered. BUG-MSO-2026-0672 F1:
    # this comment used to claim "find_workspace() in the subprocess still
    # resolves the right .mso either way via MAESTRO_DIR below" — false, the
    # sixth false justification found in this PR family. `cmd_doctor`'s
    # normal path resolves via `find_workspace()`, which deliberately
    # IGNORES MAESTRO_DIR (BUG-MSO-2026-0425) and instead walks up from cwd
    # — so an absent `.mso/config` above cwd made every LEAD Run permanently
    # refused, and a stale/foreign one let this safety gate be satisfied by
    # another fleet's state, regardless of the `env=` MAESTRO_DIR below.
    # `--maestro-dir` above is the real fix: `cmd_doctor`'s `--single-check`
    # branch reads that ARGV VALUE directly (never inferred from cwd, and
    # never from ambient environment, which is silently subject to whatever
    # else in the process environment happens to set MAESTRO_DIR — e.g. this
    # very Hub process's own). The `env=` MAESTRO_DIR kwarg below is kept as
    # a harmless secondary signal for anything else in the subprocess that
    # might read it ambiently; it is no longer what makes this resolve
    # correctly.
    cwd = str(product_repo) if product_repo is not None else str(mso)
    popen_kwargs: dict = dict(
        cwd=cwd,
        env={**os.environ, "MAESTRO_DIR": str(mso)},
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )
    if os.name != "nt":
        popen_kwargs["start_new_session"] = True
    try:
        proc = popen_hidden(cmd, **popen_kwargs)
    except OSError as exc:
        # Same class of failure as run_verbs.py's BUG-MSO-2026-0643 F4 — a
        # moved/deleted product-repo checkout since the registry entry was
        # last written.
        return SingleCheckResult(
            verified=False, still_open=True,
            reason=f"Pre-check subprocess could not start: {exc}",
        )

    try:
        stdout, _ = proc.communicate(timeout=_PRE_CHECK_TIMEOUT_SECONDS)
    except subprocess.TimeoutExpired:
        # The naive `proc.kill()` subprocess.run would have done here only
        # reaches the direct `mso doctor` child — the gh/git grandchild it's
        # stuck on survives it. Kill the WHOLE tree instead. "Could not
        # confirm" to the caller, same as run_single_check()'s own
        # unconfirmable-check contract.
        _kill_process_tree(proc.pid)
        try:
            # Drain the now-closed pipe so this process doesn't leak a
            # zombie/handle; the tree is already dead, so this returns fast.
            proc.communicate(timeout=15)
        except Exception:
            pass
        return SingleCheckResult(
            verified=False, still_open=True,
            reason=(
                f"Pre-check subprocess timed out after "
                f"{_PRE_CHECK_TIMEOUT_SECONDS}s — the process tree was killed."
            ),
        )

    if proc.returncode != 0:
        detail = (stdout or "").strip()[-500:]
        return SingleCheckResult(
            verified=False, still_open=True,
            reason=f"Pre-check subprocess failed: {detail or 'unknown error'}",
        )

    try:
        out = stdout or ""
        payload = _json.loads(out[out.index("{"):])
    except (ValueError, _json.JSONDecodeError):
        return SingleCheckResult(
            verified=False, still_open=True,
            reason="Pre-check subprocess produced no readable result.",
        )

    return SingleCheckResult(
        verified=bool(payload.get("verified", False)),
        still_open=bool(payload.get("stillOpen", True)),
        reason=str(payload.get("reason", "")),
    )


def create_app():
    """Build and return the FastAPI application."""
    from contextlib import asynccontextmanager

    from typing import Optional

    import fastapi
    from fastapi.middleware.cors import CORSMiddleware

    import maestro
    from maestro.hub.models import (
        AckRequest,
        ActionResult,
        ArtefactContent,
        CapabilityInfo,
        CapabilityMap,

        ChartResponse,
        ControlResult,
        SweepResult,
        CrewDetail,
        CrewState,
        HealthResponse,
        LeadDetail,
        LeadStatus,
        OrderArtefacts,
        OrderUsageDetail,
        PlanResponse,
        PollerStatus,
        RejectRequest,
        RetryResult,
        ReviewItem,
        SalvageCandidateModel,
        SalvageCandidates,
        ReviseRequest,
        RunResult,
        TierCapability,
        UsageRollup,
        WorkspaceDetail,
        WorkspaceSummary,
    )
    from maestro.hub.poller import WorkspacePoller

    @asynccontextmanager
    async def lifespan(app: fastapi.FastAPI):
        poller = WorkspacePoller(interval=5.0)
        poller.start()
        app.state.poller = poller
        try:
            yield
        finally:
            poller.stop()

    import os
    import re
    import time as _time
    from datetime import datetime as _datetime, timezone as _timezone

    # BUG-MSO-2026-0712: when this backend process came up. Wall-clock for the
    # display stamp, monotonic for the elapsed measurement — a system clock
    # adjustment must never make a Hub that has been up for hours report a
    # negative or wildly wrong uptime, which is precisely the kind of nonsense
    # that teaches an operator to stop trusting the header line.
    _process_started_monotonic = _time.monotonic()
    _process_started_at = _datetime.now(_timezone.utc).isoformat()

    def app_started_at_and_uptime():
        return _process_started_at, round(_time.monotonic() - _process_started_monotonic, 3)

    app = fastapi.FastAPI(
        title="Maestro Hub",
        version=maestro.__version__,
        lifespan=lifespan,
    )

    # --- Security configuration (audit findings H4/H5/H6) -------------------
    # The Hub binds to 127.0.0.1, but a wildcard CORS policy + no Host/Origin
    # validation previously made it a browser-reachable, DNS-rebindable control
    # plane. We now: (1) allow only explicit localhost origins for CORS, (2)
    # validate the Host header to defeat DNS rebinding, and (3) enforce a bearer
    # token when one is configured (env MAESTRO_HUB_TOKEN or ~/.maestro/hub.token).
    # The token is opt-in so the existing localhost frontend keeps working; it is
    # strongly recommended on shared/multi-user hosts (see docs/security).
    def _configured_origins():
        raw = os.environ.get("MAESTRO_HUB_ALLOWED_ORIGINS", "").strip()
        if raw:
            return [o.strip() for o in raw.split(",") if o.strip()]
        return [
            "http://localhost:3000", "http://127.0.0.1:3000",
            "http://localhost:3847", "http://127.0.0.1:3847",
        ]

    def _allowed_hosts():
        # localhost forms + the Starlette TestClient sentinel ("testserver").
        # A DNS-rebinding attacker uses their OWN hostname (which resolves to
        # 127.0.0.1), so it is still blocked; "testserver" is never a real host.
        base = {"127.0.0.1", "localhost", "::1", "[::1]", "testserver", ""}
        raw = os.environ.get("MAESTRO_HUB_ALLOWED_HOSTS", "").strip()
        if raw:
            base |= {h.strip() for h in raw.split(",") if h.strip()}
        return base

    def _expected_token():
        tok = os.environ.get("MAESTRO_HUB_TOKEN", "").strip()
        if tok:
            return tok
        try:
            from maestro.workspace import get_maestro_home
            p = get_maestro_home() / "hub.token"
            if p.exists():
                return p.read_text(encoding="utf-8").strip() or None
        except Exception:
            pass
        return None

    _ORIGINS = _configured_origins()

    app.add_middleware(
        CORSMiddleware,
        allow_origins=_ORIGINS,
        allow_credentials=False,
        allow_methods=["GET", "POST", "OPTIONS"],
        allow_headers=["Authorization", "Content-Type"],
    )

    @app.middleware("http")
    async def _host_and_auth_guard(request, call_next):
        # Host-header allowlist — defeats DNS rebinding against the localhost bind.
        host = (request.headers.get("host") or "").rsplit(":", 1)[0].strip("[]")
        if host and host not in {h.strip("[]") for h in _allowed_hosts()}:
            return fastapi.responses.JSONResponse(
                status_code=403, content={"detail": f"Host '{host}' not allowed"})
        # Bearer token — enforced only when configured; /health and /ping stay
        # open for liveness (the container healthcheck presents no token).
        token = _expected_token()
        if token and request.url.path.startswith("/api/") \
                and request.url.path not in ("/api/v1/health", "/api/v1/ping"):
            auth = request.headers.get("authorization", "")
            presented = auth[7:].strip() if auth.lower().startswith("bearer ") else ""
            import hmac as _hmac
            if not presented or not _hmac.compare_digest(presented, token):
                return fastapi.responses.JSONResponse(
                    status_code=401, content={"detail": "missing or invalid bearer token"})
        return await call_next(request)

    _ORDER_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,64}$")

    def _validate_order_id(order_id: str):
        """Reject order ids that could escape the review directory (H-M path traversal)."""
        if not order_id or ".." in order_id or "/" in order_id or "\\" in order_id \
                or not _ORDER_ID_RE.match(order_id):
            raise fastapi.HTTPException(status_code=400, detail="invalid order id")

    # maestro.patrol.state.fingerprint() always produces a sha256 hex digest —
    # a fixed-shape identifier with no filesystem meaning, but validated the
    # same defensive way as _ORDER_ID_RE since it flows straight into a
    # dict-key lookup against JSON read from disk.
    _FINGERPRINT_RE = re.compile(r"^[A-Za-z0-9]{8,128}$")

    def _validate_fingerprint(fp: str):
        if not fp or not _FINGERPRINT_RE.match(fp):
            raise fastapi.HTTPException(status_code=400, detail="invalid fingerprint")

    @app.get("/api/v1/ping")
    async def ping():
        """Cheap liveness probe — touches no registry, filesystem, or poller.

        Used by the container healthcheck (docker/docker-compose.yml) so that a
        heavy workspace scan behind /api/v1/health can never flag the container
        unhealthy while it is serving traffic (BUG-MSO-2026-0390).
        """
        return {"ok": True}

    @app.get("/api/v1/health", response_model=HealthResponse)
    async def health():
        poller: WorkspacePoller = app.state.poller
        summaries = poller.summaries()
        running_version = maestro.__version__
        installed_version = _live_installed_version()
        # BUG-MSO-2026-0712: this process's OWN start time, measured by the
        # process about itself at app construction — never read back from the
        # PID record, which a crashed-and-restarted daemon may not have
        # rewritten and which a reader cannot verify belongs to whoever is
        # actually answering this request.
        started_at, uptime = app_started_at_and_uptime()
        return HealthResponse(
            status="ok",
            version=running_version,
            workspaces=len(summaries),
            poller_ready=poller.is_ready(),
            installedVersion=installed_version,
            versionMismatch=bool(installed_version) and installed_version != running_version,
            startedAt=started_at,
            uptimeSeconds=uptime,
        )

    @app.get("/api/v1/workspaces/status", response_model=PollerStatus)
    async def workspaces_status():
        """Poller readiness (BUG-MSO-2026-0467).

        The UI polls this alongside GET /workspaces so an empty/partial list
        during the cold-start window renders as "connecting" rather than as
        an empty fleet — ``state == "initialising"`` while the first pass is
        still scanning, ``"ready"`` once every registered workspace has been
        scanned at least once.
        """
        poller: WorkspacePoller = app.state.poller
        return PollerStatus(**poller.status())

    @app.get("/api/v1/workspaces", response_model=list[WorkspaceSummary])
    async def list_workspaces():
        poller: WorkspacePoller = app.state.poller
        return poller.summaries()

    @app.get("/api/v1/workspaces/{workspace_id}", response_model=WorkspaceDetail)
    async def get_workspace_detail(workspace_id: str):
        poller: WorkspacePoller = app.state.poller
        detail = poller.detail(workspace_id)
        if detail is not None:
            return detail
        # BUG-MSO-2026-0467: not yet in the cache. That's ambiguous — either
        # the id is genuinely unknown (real 404), or it's registered but the
        # poller hasn't scanned it yet (the poll pass runs sequentially, so a
        # workspace late in the registry order can lag behind /crews below,
        # which always resolves live and never consulted this cache at all).
        # Resolve the registry directly to tell the two apart, and when it IS
        # known, compute the detail on demand — the same live path /crews
        # already takes — so the two endpoints can never disagree about
        # whether a workspace exists.
        import maestro.registry as registry
        projects = registry.list_projects()
        entry = projects.get(workspace_id)
        if entry is None:
            raise fastapi.HTTPException(status_code=404, detail=f"Workspace '{workspace_id}' not found")
        from maestro.hub import aggregator
        from maestro.workspace import artefact_parent_for_entry, product_repo_for_entry
        ws_root = artefact_parent_for_entry(entry)
        product_repo = product_repo_for_entry(entry)
        return aggregator.build_workspace_detail(ws_root, workspace_id, product_repo=product_repo)

    @app.get("/api/v1/workspaces/{workspace_id}/crews", response_model=list[CrewState])
    async def get_workspace_crews(workspace_id: str):
        from maestro.hub import aggregator
        from maestro.workspace import artefact_parent_for_entry

        entry = _resolve_workspace_entry(workspace_id)
        ws_root = artefact_parent_for_entry(entry)
        return aggregator.build_crew_list(ws_root, workspace_id)

    @app.get("/api/v1/workspaces/{workspace_id}/crews/{slot}/detail", response_model=CrewDetail)
    async def get_crew_detail(workspace_id: str, slot: int):
        """One crew slot's read-only detail (FTR-MSO-2026-0577) — current
        order/role, a bounded newest-first activity.jsonl tail, the current
        activity line, progress.md, and files_modified.json. Never the raw
        output_01.txt/output_final.txt transcript. A slot outside
        maxCrews, or one with no crew directory on disk, is a clean 404.
        """
        from maestro.hub import aggregator
        from maestro.workspace import artefact_parent_for_entry

        entry = _resolve_workspace_entry(workspace_id)
        ws_root = artefact_parent_for_entry(entry)
        detail = aggregator.build_crew_detail(ws_root, workspace_id, slot)
        if detail is None:
            raise fastapi.HTTPException(
                status_code=404, detail=f"Crew slot {slot} not found")
        return detail

    @app.get("/api/v1/workspaces/{workspace_id}/lead", response_model=LeadStatus)
    async def get_workspace_lead(workspace_id: str):
        """LEAD sub-agent status (FTR-MSO-2026-0539, PLAN-PLN-MSO-2026-0504 §13).

        ``available``/``reason`` gate the strip/pip render for a community or
        non-Pro workspace — greyed with the reason as the upgrade affordance
        — rather than a 403, mirroring ``GET /api/v1/capabilities`` (declare
        up front, never a post-hoc-only 403). The underlying data is still
        returned even when ``available`` is False, same as `mso lead status`
        itself being ungated on the CLI side (cli.py:cmd_lead) — a licence
        check gates ACTING, never READING.
        """
        from maestro.hub import aggregator
        from maestro.workspace import artefact_parent_for_entry

        entry = _resolve_workspace_entry(workspace_id)
        ws_root = artefact_parent_for_entry(entry)
        return aggregator.build_lead_status(ws_root, workspace_id)

    @app.get("/api/v1/workspaces/{workspace_id}/lead/detail", response_model=LeadDetail)
    async def get_workspace_lead_detail(workspace_id: str):
        """LEAD finding detail + audit tail (FTR-MSO-2026-0577).

        ``findings`` come from the SAME persisted tick ``GET .../lead``'s
        counts reflect — reading ``.mso/lead/state.json`` only, never
        triggering a fresh ``mso doctor`` pass (see
        ``aggregator.build_lead_detail`` / ``models.LeadDetail`` docstrings).
        ``available``/``reason`` mirror ``LeadStatus``'s shape, same as the
        sibling endpoint above.
        """
        from maestro.hub import aggregator
        from maestro.workspace import artefact_parent_for_entry

        entry = _resolve_workspace_entry(workspace_id)
        ws_root = artefact_parent_for_entry(entry)
        return aggregator.build_lead_detail(ws_root, workspace_id)

    @app.post("/api/v1/workspaces/{workspace_id}/lead/stand-down", response_model=ControlResult)
    async def stand_down_lead(workspace_id: str):
        """Stand the LEAD daemon down for a workspace (PLAN-PLN-MSO-2026-0584
        Dimension A). Deliberately UNGATED by tier — turning LEAD OFF must
        always be possible on a community-tier workspace, mirroring `mso
        lead stop`'s ungated shape (only turning it back ON, via `resume`
        below, is gated). Writes `lead.standDown: true` into workspace.json
        — durable, so it survives a daemon restart — and is a no-op if the
        daemon is not currently running: the next time it IS started, the
        first tick reads the flag and skips.
        """
        from maestro.lead.agent import set_stand_down
        from maestro.workspace import artefact_parent_for_entry, resolve_artefact_dir

        entry = _resolve_workspace_entry(workspace_id)
        mso = resolve_artefact_dir(artefact_parent_for_entry(entry))
        set_stand_down(mso, True)
        return ControlResult(
            ok=True, workspace_id=workspace_id, action="lead.stand-down",
            message="LEAD standing down — ticks will be skipped until resumed.",
        )

    @app.post("/api/v1/workspaces/{workspace_id}/lead/resume", response_model=ControlResult)
    async def resume_lead(workspace_id: str):
        """Resume a stood-down LEAD daemon. Gated (turning LEAD back ON,
        unlike stand-down) — on an insufficient tier this returns the SAME
        structured 409 `GET .../lead`'s `reason` already shows, never a bare
        403 (PLAN-PLN-MSO-2026-0584 Dimension A: 'the stand-down endpoints
        gate on auth.LEAD_AGENT_TIERS and return a structured 409 carrying
        the same sentence /capabilities shows')."""
        from maestro import auth
        from maestro.hub.aggregator import _LEAD_TIER_MESSAGE
        from maestro.lead.agent import set_stand_down
        from maestro.workspace import artefact_parent_for_entry, resolve_artefact_dir

        if not auth.has_tier(auth.LEAD_AGENT_TIERS):
            raise fastapi.HTTPException(status_code=409, detail=_LEAD_TIER_MESSAGE)

        entry = _resolve_workspace_entry(workspace_id)
        mso = resolve_artefact_dir(artefact_parent_for_entry(entry))
        set_stand_down(mso, False)
        return ControlResult(
            ok=True, workspace_id=workspace_id, action="lead.resume",
            message="LEAD resumed — ticks will run again.",
        )

    @app.post(
        "/api/v1/workspaces/{workspace_id}/lead/findings/{fingerprint}/ack",
        response_model=ControlResult,
    )
    async def ack_lead_finding(workspace_id: str, fingerprint: str, body: Optional[AckRequest] = None):
        """Acknowledge one open LEAD finding (PLAN-PLN-MSO-2026-0584 Dimension D).

        Deliberately UNGATED by tier, mirroring `stand-down` — acknowledging a
        finding the operator can already see is an observability action, not
        a resource-spending one. `body.days` is optional; when omitted it
        resolves to `maestro.patrol.state.ACK_TTL_DAYS_DEFAULT` (7) — there is
        no way to request a non-expiring ack through this endpoint, by design.
        A fingerprint with no matching open finding is a 404, not a silent
        no-op acknowledgement of nothing.
        """
        from maestro.patrol.state import UnknownFindingError, acknowledge_finding
        from maestro.workspace import artefact_parent_for_entry, resolve_artefact_dir

        _validate_fingerprint(fingerprint)
        entry = _resolve_workspace_entry(workspace_id)
        mso = resolve_artefact_dir(artefact_parent_for_entry(entry))
        body = body or AckRequest()
        try:
            ack = acknowledge_finding(
                mso, fingerprint, by=body.by or "hub", note=body.note or "",
                **({"ttl_days": body.days} if body.days else {}),
            )
        except UnknownFindingError as exc:
            raise fastapi.HTTPException(status_code=404, detail=str(exc))
        except ValueError as exc:
            raise fastapi.HTTPException(status_code=400, detail=str(exc))
        return ControlResult(
            ok=True, workspace_id=workspace_id, action="lead.ack",
            message=f"Acknowledged at severity={ack['severity']} — expires {ack['expiresAt']}.",
        )

    @app.post(
        "/api/v1/workspaces/{workspace_id}/lead/findings/{fingerprint}/unack",
        response_model=ControlResult,
    )
    async def unack_lead_finding(workspace_id: str, fingerprint: str):
        """Clear an acknowledgement early. Deliberately UNGATED, same reasoning
        as ``ack_lead_finding`` above. A no-op (not an error) when there was
        nothing to clear — `ok` still reports True, `message` says so."""
        from maestro.patrol.state import unacknowledge_finding
        from maestro.workspace import artefact_parent_for_entry, resolve_artefact_dir

        _validate_fingerprint(fingerprint)
        entry = _resolve_workspace_entry(workspace_id)
        mso = resolve_artefact_dir(artefact_parent_for_entry(entry))
        existed = unacknowledge_finding(mso, fingerprint)
        return ControlResult(
            ok=True, workspace_id=workspace_id, action="lead.unack",
            message="Un-acknowledged." if existed else "No acknowledgement found — nothing to do.",
        )

    @app.post(
        "/api/v1/workspaces/{workspace_id}/lead/findings/{fingerprint}/run",
        response_model=RunResult,
    )
    def run_lead_finding(workspace_id: str, fingerprint: str):
        """Run the mapped action behind a LEAD finding's suggested command
        (FTR-MSO-2026-0631) — the Hub's "Run" button.

        NOT a command executor: ``maestro.lead.run_verbs.parse_verb()``
        matches the finding's persisted ``suggestedCommand`` against a
        closed, enumerated list of regex patterns; a command that doesn't
        match is refused with a 400 here (the frontend never renders Run for
        one — this is the defence-in-depth backstop, matching the
        capabilities-gate pattern every other mutating control uses). Each
        matched verb's handler calls the SAME function or CLI invocation an
        existing tier-gated endpoint already uses — see run_verbs.py's
        module docstring for the map.

        Tier-gated exactly like dispatch/stop/sweep/review (`_require_control_
        tier()`) — the frontend is expected to have already consulted
        `GET /api/v1/capabilities`'s `tier`/`sweep`/`orderRetry` shape before
        rendering Run as enabled; this call is the backstop, not the primary
        gate. The D6 must_not ceiling is a SEPARATE, unconditional check
        (`run_verbs.is_forbidden`) — refused there is reported as outcome
        "refused" in a 200 response (an expected, renderable business
        outcome), never a bare exception.

        BUG-MSO-2026-0634 F1/F2: re-evaluation calls ``maestro.patrol.
        run_single_check()`` for ONLY the check that produced this finding —
        never ``maestro.lead.agent.run_once()`` (a full LEAD tick). A full
        tick dispatches D7 act-and-inform actions (actively dangerous per
        BUG-MSO-2026-0633, which is why LEAD is stood down on this very
        workspace) and does an unlocked read-modify-write of
        patrol-state.json / the LEAD daemon's own state.json concurrently
        with a possibly-running daemon. ``run_single_check`` touches neither
        file and dispatches nothing. A check that cannot be confirmed
        (unknown/disabled/raising) reports ``verified=False`` and this
        endpoint FAILS CLOSED — "ran, could not confirm" — never the old
        swallowed-exception path that silently reported "condition cleared"
        for a re-evaluation that verified nothing.

        BUG-MSO-2026-0662 F1: the SAME check-re-run PRINCIPLE also runs ONCE
        MORE, before the handler, as a pre-flight condition check — a
        persisted finding is only as fresh as the ``state.json`` it was read
        from, which nothing refreshes while the LEAD daemon is stood down
        (this workspace's normal state) or simply hasn't ticked recently.
        Without it, a stale ``dispatcher.heartbeat`` finding could survive
        long past the real dispatcher recovering on its own, and clicking
        Run would fire ``mso cleanup`` against a NOW-HEALTHY dispatcher —
        killing whatever crews it has live — with the post-hoc reevaluate
        below then honestly reporting "condition cleared" only because the
        action itself just cleared it by destroying the healthy thing it
        found. The pre-check fails CLOSED identically to the post-hoc one:
        unconfirmable or already-cleared both refuse rather than run.

        BUG-MSO-2026-0670 F1: the pre-flight check itself runs via
        ``_run_single_check_subprocess`` — a KILLABLE OS SUBPROCESS bounded
        by a timeout — NOT the ``run_single_check`` primitive directly on
        this request thread the way it first shipped. The gh-backed check
        behind ``voyage.reconcile`` findings otherwise held the
        process-global ``order_retry._SCOPE_LOCK`` for an unbounded gh round
        trip, blocking every other concurrent Run click and order-retry POST
        on this Hub for as long as gh took to answer.

        BUG-MSO-2026-0686 F5: the post-hoc reevaluate below is NOT unaffected
        — the claim that the one gh-backed check "always short-circuits via
        precomputed from the handler's own real work and never falls through
        to it" was false whenever the finding's own ``subjectId`` is empty or
        missing: ``_handle_voyage_reconcile`` only sets ``still_open``/
        ``verified`` (and therefore ``precomputed``) when ``_subject_id`` is
        non-empty, so an empty subject fell through to this branch and called
        ``run_single_check`` DIRECTLY on the request thread — re-holding
        ``_SCOPE_LOCK`` across an unbounded gh round trip, exactly the hazard
        BUG-MSO-2026-0670 F1 was filed to close. This branch therefore now
        routes through the SAME bounded ``_run_single_check_subprocess`` the
        pre-flight check uses, never the raw ``run_single_check`` primitive,
        for every check this endpoint re-evaluates.

        Sync ``def``, not ``async def`` — order.retry's handler enters
        ``order_retry.workspace_scope()``, which (per that module's own
        docstring) must run in FastAPI's threadpool, not the event loop.
        """
        _validate_fingerprint(fingerprint)
        _require_control_tier()

        from maestro.lead import run_verbs
        from maestro.lead.agent import _write_lifecycle_event
        from maestro.lead.agent import load_state as _load_lead_state
        from maestro.workspace import (
            artefact_parent_for_entry, product_repo_for_entry, resolve_artefact_dir,
        )

        entry = _resolve_workspace_entry(workspace_id)
        try:
            ws_root = artefact_parent_for_entry(entry)
            mso = resolve_artefact_dir(ws_root)
            product_repo = product_repo_for_entry(entry)
        except OSError:
            raise fastapi.HTTPException(status_code=503, detail=STALE_MOUNT_MESSAGE)

        state = _load_lead_state(mso)
        found = next(
            (
                e for e in (state.get("lastFindingsDetail") or [])
                if isinstance(e, dict) and e.get("fingerprint") == fingerprint
            ),
            None,
        )
        if found is None:
            raise fastapi.HTTPException(
                status_code=404,
                detail="No open LEAD finding with this fingerprint — it may already be resolved.",
            )

        command = found.get("suggestedCommand")
        match = run_verbs.parse_verb(command) if command else None
        if match is None:
            raise fastapi.HTTPException(
                status_code=400,
                detail="This finding's suggested command is not a runnable action — copy it and run it yourself.",
            )

        action_id = match.spec.id

        try:
            from maestro.identity.auth import resolve_caller
            who = resolve_caller(ws_root)
        except Exception:
            who = "hub"

        def _finish(
            *, outcome: str, message: str, ok: bool, reevaluate: bool,
            precomputed: "Optional[tuple]" = None,
        ) -> RunResult:
            _write_lifecycle_event(
                mso, "LEAD_ACTION",
                f"action={action_id} trigger=human-run outcome={outcome} who={who} "
                f"finding={fingerprint} detail={message}",
            )
            try:
                from maestro.audit import get_audit_log
                get_audit_log(ws_root).append(
                    action=f"lead.run.{action_id}",
                    target=fingerprint,
                    result=outcome,
                    metadata={"checkId": found.get("checkId", ""), "command": command},
                    actor=who,
                )
            except Exception:
                pass

            # BUG-MSO-2026-0648 F2: verified starts FALSE, not True — a
            # refused/failed outcome (reevaluate=False, precomputed=None)
            # falls through both branches below untouched, and no check has
            # actually run for it. The old True default meant EVERY refused
            # or failed response claimed verified=true/stillOpen=true —
            # a confirmed re-check that never happened — contradicting
            # RunResult's own documented contract and BUG-MSO-2026-0634 F2's
            # fail-closed principle. still_open stays True (unknown/unchanged,
            # never optimistically cleared); only precomputed or an actual
            # reevaluate run may set verified=True below.
            still_open, condition_cleared, verified = True, False, False
            if precomputed is not None:
                # BUG-MSO-2026-0643 F3: the handler already knows this from
                # the REAL work it just did (see run_verbs.RunOutcome's
                # still_open/verified docstring) — use it directly rather
                # than spending a second re-evaluation call. Load-bearing for
                # voyage.reconcile, whose re-evaluation check
                # (voyages.merged-not-archived) is itself gh-backed: without
                # this, one Run click fired the gh-backed sweep twice.
                still_open, verified = precomputed
                condition_cleared = bool(verified) and not still_open
            elif reevaluate:
                # BUG-MSO-2026-0686 F5: routed through the same BOUNDED,
                # KILLABLE subprocess the pre-flight check uses — never
                # ``run_single_check`` directly on this request thread. An
                # empty/missing subjectId (this handler's defensive
                # fallback) used to fall through here for the gh-backed
                # ``voyages.merged-not-archived`` check, re-holding
                # ``order_retry._SCOPE_LOCK`` across an unbounded gh round
                # trip — exactly what BUG-MSO-2026-0670 F1 was filed to stop.
                check_id = found.get("checkId") or ""
                subject_id = found.get("subjectId") or ""
                if not check_id:
                    verified = False
                else:
                    single = _run_single_check_subprocess(mso, check_id, subject_id, product_repo)
                    verified = single.verified
                    if verified:
                        still_open = single.still_open
                        condition_cleared = not still_open
                    # verified is False: leave still_open=True,
                    # condition_cleared=False — fail CLOSED, never an
                    # optimistic "cleared" for a check that couldn't confirm.

            return RunResult(
                ok=ok, action=action_id, outcome=outcome, message=message,
                conditionCleared=condition_cleared, stillOpen=still_open,
                verified=verified,
            )

        if run_verbs.is_forbidden(match.spec, product_repo):
            return _finish(
                outcome="refused",
                message=(
                    f"'{action_id}' is on the LEAD's must_not list — this "
                    "requires explicit Captain approval and cannot be run "
                    "from the Hub."
                ),
                ok=False, reevaluate=False,
            )

        if action_id == "voyage.reconcile":
            blocked = _sweep_unavailable_reason()
            if blocked:
                return _finish(outcome="refused", message=blocked, ok=False, reevaluate=False)

        # BUG-MSO-2026-0634 F4: dispatcher.cleanup needs the SAME
        # observe-only gate `dispatch_workspace` already applies — a
        # containerized/observe-only Hub has no usable host process and
        # would run cleanup against the mounted `.mso` while crews are still
        # live on the HOST (BUG-MSO-2026-0395's failure mode). voyage.
        # reconcile was already gated (above); dispatcher.cleanup was not.
        if action_id == "dispatcher.cleanup":
            if _is_observe_only():
                return _finish(outcome="refused", message=OBSERVE_ONLY_MESSAGE, ok=False, reevaluate=False)

        # BUG-MSO-2026-0662 F1: re-confirm the finding's condition BEFORE
        # running the handler, not only after. A LEAD finding is only as
        # fresh as the state.json it was read from, and that file is
        # refreshed exclusively by daemon ticks — while the daemon is stood
        # down (this workspace's normal state; see LEAD_STAND_DOWN) or has
        # simply not ticked recently, a persisted finding can describe a
        # condition that no longer holds. Concretely: a stale
        # dispatcher.heartbeat finding sits in state.json; the dispatcher
        # recovers on its own; an operator clicks Run; without this check
        # `mso cleanup` would fire against a NOW-HEALTHY dispatcher and kill
        # live crews, and the post-hoc reevaluate below would then honestly
        # report "condition cleared" — because the action itself cleared it
        # by destroying the healthy thing it found. Re-running the SAME
        # check (never a full LEAD tick — see the module docstring above on
        # why that would be actively dangerous here too) before the mutation
        # is the only way "condition cleared" is ever a meaningful claim.
        #
        # Fails CLOSED on an unconfirmable check (unknown/disabled/raising —
        # same semantics as the post-hoc reevaluate branch below): if the
        # pre-check cannot positively confirm the condition still holds, the
        # safer default is to refuse, not to proceed on stale trust.
        #
        # BUG-MSO-2026-0670 F1: run via ``_run_single_check_subprocess`` — a
        # KILLABLE OS SUBPROCESS bounded by ``_PRE_CHECK_TIMEOUT_SECONDS`` —
        # never ``run_single_check()`` called directly here on the request
        # thread. The direct call was fine for the cheap, disk-only checks
        # (dispatcher.heartbeat, voyages.stalled-order-deadlock) but for the
        # one gh-backed check reachable through this endpoint
        # (voyages.merged-not-archived, which runs a full
        # ``run_housekeeping_sweep(dry_run=True)``) it held the
        # PROCESS-GLOBAL ``order_retry._SCOPE_LOCK`` — on THIS Hub process —
        # for an unbounded gh round trip, blocking every concurrent Run click
        # and order-retry POST for as long as gh took to answer. See
        # ``_run_single_check_subprocess``'s own docstring for the full
        # before/after trace and the latency this fix deliberately trades
        # for it (bounded to this one click, never to any other caller).
        pre_check_id = found.get("checkId") or ""
        pre_subject_id = found.get("subjectId") or ""
        pre_check = None
        if pre_check_id:
            try:
                pre_check = _run_single_check_subprocess(
                    mso, pre_check_id, pre_subject_id, product_repo,
                )
            except Exception:  # noqa: BLE001 — fail closed, never crash the endpoint
                pre_check = None
        if pre_check is None or not pre_check.verified:
            # BUG-MSO-2026-0672 F2: `pre_check.reason` used to be computed by
            # `_run_single_check_subprocess` (or `run_single_check` before
            # it) and then discarded here — every refusal on this branch
            # returned the SAME fixed generic sentence regardless of why the
            # pre-check couldn't confirm. That made "the check genuinely
            # could not confirm the condition" (e.g. it raised, or is
            # disabled) indistinguishable from "the subprocess cannot start
            # on this deployment at all" (BUG-MSO-2026-0672 F1(a)) — an
            # operator hitting F1(a) saw a refusal that told them nothing
            # about why. Surface the real reason when one was captured; the
            # `except Exception` branch above still leaves `pre_check` as
            # `None`, with no reason to report, so the generic sentence
            # remains the fallback for a truly unexpected failure.
            reason = (pre_check.reason if pre_check is not None else "").strip()
            detail = f" ({reason})" if reason else ""
            return _finish(
                outcome="refused",
                message=(
                    "Could not re-confirm this finding's condition just before "
                    "running it — refusing for safety rather than acting on "
                    f"possibly-stale state{detail}. Re-check the fleet and try again."
                ),
                ok=False, reevaluate=False,
            )
        if not pre_check.still_open:
            return _finish(
                outcome="refused",
                message=(
                    "This finding's condition is no longer present — nothing "
                    "to do. The board will catch up on the next patrol tick."
                ),
                ok=False, reevaluate=False,
                precomputed=(False, True),
            )

        # BUG-MSO-2026-0643 F3: pass the finding's own subject_id through so a
        # handler that can determine the post-run condition from its OWN real
        # work (voyage.reconcile — see run_verbs._handle_voyage_reconcile) can
        # do so without a second, redundant re-evaluation call. Every other
        # handler ignores an unrecognised dict key.
        handler_args = dict(match.args)
        handler_args["_subject_id"] = pre_subject_id

        try:
            result = match.spec.handler(handler_args, mso, product_repo)
        except Exception as exc:  # noqa: BLE001 — must report, never crash the endpoint
            return _finish(
                outcome="failed", message=f"{type(exc).__name__}: {exc}",
                ok=False, reevaluate=False,
            )

        precomputed = (
            (result.still_open, result.verified) if result.verified is not None else None
        )
        return _finish(
            outcome="accepted" if result.ok else "failed",
            message=result.message, ok=result.ok, reevaluate=result.ok,
            precomputed=precomputed,
        )

    # -----------------------------------------------------------------------
    # Capabilities (FTR-MSO-2026-0489) — declare BEFORE the click, never 409
    # -----------------------------------------------------------------------

    @app.get("/api/v1/capabilities", response_model=CapabilityMap)
    async def get_capabilities():
        """Declare which mutating actions this Hub deployment can perform.

        PLAN-PLN-MSO-2026-0468 §4.5, generalising the BUG-MSO-2026-0440 sweep
        fix: an action that cannot work here must be disabled WITH ITS REASON
        before the click, never discovered as a post-hoc 409. This endpoint is
        deliberately workspace-independent (dispatch/sweep availability is a
        property of THIS BACKEND's deployment, not of any one workspace) and
        does not touch the poller, so it is cheap enough to consult before
        rendering every control button.

        The server-side 409s on dispatch/stop/sweep/review remain as a
        defence-in-depth backstop — this endpoint is the primary mechanism,
        not a replacement for it. Reason strings are the SAME module constants
        those 409s raise, so the explanation shown before the click and the
        one raised if it happens anyway can never disagree.
        """
        from maestro import auth

        dispatch_blocked = _is_observe_only()
        sweep_blocked = _sweep_unavailable_reason()
        control_ok = auth.has_tier(auth.HUB_TIERS)

        return CapabilityMap(
            dispatch=CapabilityInfo(
                available=not dispatch_blocked,
                reason=OBSERVE_ONLY_MESSAGE if dispatch_blocked else None,
            ),
            sweep=CapabilityInfo(
                available=sweep_blocked is None,
                reason=sweep_blocked,
            ),
            # Reads and mutations of order JSON (approve/decline/request-change/
            # retry/skip) are file-plane, not process-spawn — they work in a
            # container today (PLAN-0468 §4.1). Licence gating is reported
            # separately via `tier`, uniformly, for every mutating action.
            review=CapabilityInfo(available=True),
            orderRetry=CapabilityInfo(available=True),
            tier=TierCapability(
                control=control_ok,
                reason=None if control_ok else CONTROL_TIER_MESSAGE,
            ),
        )

    # Charts — read-only graph X-ray (FTR-MSO-2026-0496, PLAN-VOY-MSO-2026-0143
    # Phase 1 part 2). Community tier: visualization must work without a
    # licence (ruling 0a#3), gated through auth.has_tier and nothing else —
    # never touches token validation directly (ruling §6).
    # -----------------------------------------------------------------------

    def _require_chart_tier():
        from maestro import auth
        if not auth.has_tier(auth.CHART_VIEW_TIERS):
            raise fastapi.HTTPException(
                status_code=403,
                detail="Maestro chart visualization is unavailable for this licence state.",
            )

    @app.get("/api/v1/workspaces/{workspace_id}/voyages/{voyage_id}/chart", response_model=ChartResponse)
    async def get_voyage_chart(workspace_id: str, voyage_id: str):
        """Compiled chart for one voyage — same compiler and wire shape as
        `mso chart show --format json` (maestro.core.charts.Chart.to_dict()),
        so the CLI and this read-only Hub view can never disagree."""
        _require_chart_tier()
        _validate_order_id(voyage_id)
        from maestro.core import charts as _charts
        from maestro.workspace import artefact_parent_for_entry, resolve_artefact_dir

        entry = _resolve_workspace_entry(workspace_id)
        mso_dir = resolve_artefact_dir(artefact_parent_for_entry(entry))
        chart = _charts.compile_voyage_chart(voyage_id, workspace_dir=mso_dir)
        return ChartResponse(**chart.to_dict())

    # -----------------------------------------------------------------------
    # Dispatch control endpoints (Feature B) — localhost-only by binding
    # -----------------------------------------------------------------------

    def _resolve_workspace_entry(workspace_id: str) -> dict:
        """Return the raw registry v2 entry for *workspace_id* or raise 404.

        Callers derive paths via ``maestro.workspace.artefact_parent_for_entry``
        (artefacts: voyages/orders/queues/review/usage/logs) and
        ``product_repo_for_entry`` (dispatch/stop subprocess cwd, branch/PR
        context) — never read ``entry["path"]`` directly (FTR-MSO-2026-0369).
        """
        import maestro.registry as registry
        projects = registry.list_projects()
        if workspace_id not in projects:
            raise fastapi.HTTPException(
                status_code=404, detail=f"Workspace '{workspace_id}' not found")
        return projects[workspace_id]

    def _require_control_tier():
        """Tier gate matching the CLI `hub` command — Team/Enterprise only.

        Uses auth.has_tier (non-exiting) so an HTTP 403 is returned instead of
        the CLI's sys.exit. has_tier returns True when MAESTRO_SKIP_AUTH=1.
        """
        from maestro import auth
        if not auth.has_tier(auth.HUB_TIERS):
            raise fastapi.HTTPException(status_code=403, detail=CONTROL_TIER_MESSAGE)

    @app.post("/api/v1/workspaces/{workspace_id}/dispatch", response_model=ControlResult)
    async def dispatch_workspace(workspace_id: str):
        """Start the dispatcher for a workspace as a detached background process."""
        import os
        import subprocess
        import sys
        from maestro.hub import aggregator
        from maestro.workspace import (
            artefact_parent_for_entry, product_repo_for_entry, resolve_artefact_dir,
        )

        _require_control_tier()
        # Observe-only (containerized) backends cannot launch a usable host
        # dispatcher — fail loudly with a structured 409 the UI surfaces,
        # instead of spawning a no-op dispatcher inside the container and
        # returning a misleading "starting" (BUG-MSO-2026-0395).
        if _is_observe_only():
            raise fastapi.HTTPException(status_code=409, detail=OBSERVE_ONLY_MESSAGE)
        # Registry/workspace reads can raise a raw OSError (e.g. Errno 5 on a
        # stale Docker bind-mount after a Docker Desktop restart). Degrade to a
        # 503 with a "restart containers" hint rather than leaking a traceback.
        try:
            entry = _resolve_workspace_entry(workspace_id)
            ws_root = artefact_parent_for_entry(entry)
            mso = resolve_artefact_dir(ws_root)
            # The dispatch subprocess's cwd must be the PRODUCT repo — in
            # solo/shared artefact mode ws_root/mso are the artefact repo, which
            # carries no source checkout for git worktree/branch operations to
            # run against (FTR-MSO-2026-0369). MAESTRO_DIR below still points the
            # dispatcher at the correct artefact plane regardless of cwd.
            product_repo = product_repo_for_entry(entry)
        except OSError:
            raise fastapi.HTTPException(status_code=503, detail=STALE_MOUNT_MESSAGE)

        # Don't spawn a duplicate if one is already running.
        try:
            if aggregator._dispatcher_running(mso):
                return ControlResult(
                    ok=True, workspace_id=workspace_id, action="dispatch",
                    message="Dispatcher already running",
                )
        except Exception:
            pass

        env = {**os.environ, "MAESTRO_DIR": str(mso)}
        cmd = [sys.executable, "-m", "maestro.cli", "dispatch", "--max-crews", "5"]
        kwargs = dict(
            cwd=str(product_repo),
            env=env,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        if os.name == "nt":
            DETACHED_PROCESS = 0x00000008
            CREATE_NEW_PROCESS_GROUP = 0x00000200
            kwargs["creationflags"] = DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
            kwargs["close_fds"] = True
        else:
            kwargs["start_new_session"] = True
        subprocess.Popen(cmd, **kwargs)
        return ControlResult(
            ok=True, workspace_id=workspace_id, action="dispatch",
            message="Dispatcher starting",
        )

    @app.post("/api/v1/workspaces/{workspace_id}/stop", response_model=ControlResult)
    async def stop_workspace(workspace_id: str):
        """Stop (hold) the dispatcher + crews for a workspace via scoped cleanup."""
        import os
        import subprocess
        import sys
        from maestro.workspace import (
            artefact_parent_for_entry, product_repo_for_entry, resolve_artefact_dir,
        )

        _require_control_tier()
        try:
            entry = _resolve_workspace_entry(workspace_id)
            ws_root = artefact_parent_for_entry(entry)
            mso = resolve_artefact_dir(ws_root)
            product_repo = product_repo_for_entry(entry)
        except OSError:
            raise fastapi.HTTPException(status_code=503, detail=STALE_MOUNT_MESSAGE)

        env = {**os.environ, "MAESTRO_DIR": str(mso)}
        try:
            # BUG-MSO-2026-0682 F2: `--maestro-dir` must be an explicit argv
            # value, not just the `MAESTRO_DIR` env kwarg below — `cmd_cleanup`
            # resolves via `find_workspace()`, which deliberately IGNORES
            # `MAESTRO_DIR` (BUG-MSO-2026-0425) and instead walks up from cwd.
            # `run_verbs._handle_dispatcher_cleanup` already fixed this exact
            # gap for the LEAD Run button (BUG-MSO-2026-0675 F1); this endpoint
            # (the Hub's Stop button) spawns the identical command and was
            # left behind. `env=` MAESTRO_DIR is kept as a harmless secondary
            # signal for anything else in the subprocess that reads it
            # ambiently — it is not what makes this resolve correctly.
            subprocess.run(
                [sys.executable, "-m", "maestro.cli", "cleanup", "--no-backup",
                 "--maestro-dir", str(mso)],
                cwd=str(product_repo),
                env=env,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=60,
            )
        except subprocess.TimeoutExpired:
            return ControlResult(
                ok=False, workspace_id=workspace_id, action="stop",
                message="Cleanup timed out",
            )
        return ControlResult(
            ok=True, workspace_id=workspace_id, action="stop",
            message="Dispatcher stopped",
        )

    @app.post("/api/v1/workspaces/{workspace_id}/sweep", response_model=SweepResult)
    async def sweep_workspace(workspace_id: str, dry_run: bool = False):
        """Run the housekeeping reconcile for a workspace (FTR-MSO-2026-0426).

        The human approves and merges the voyage PR most of the time, so
        Maestro never observes the merge event — housekeeping has to be
        PULL-based. This is that pull: validate every voyage's PR state,
        archive the merged ones, annotate merge metadata, reconcile
        archived-but-not-COMPLETE orders, and report what was REFUSED and why.

        Runs ``mso voyage reconcile --json`` as a subprocess so the button and
        the CLI execute literally the same code path (``run_housekeeping_sweep``)
        and cannot drift. Does NOT require a running dispatcher.

        Same protections as the other control endpoints: Team/Enterprise tier
        gate, the shared CORS/origin allow-list, the observe-only 409 (merge
        detection needs git + gh against the product repo, which a containerized
        observe-only backend does not have) and the stale-mount 503.
        """
        import json as _json
        import os
        import subprocess
        import sys
        from maestro.workspace import (
            artefact_parent_for_entry, product_repo_for_entry, resolve_artefact_dir,
        )

        _require_control_tier()
        # BUG-MSO-2026-0440: gate on what HOUSEKEEPING needs (gh), not on
        # whether a dispatcher could be spawned (Claude CLI).
        _sweep_blocked = _sweep_unavailable_reason()
        if _sweep_blocked:
            raise fastapi.HTTPException(status_code=409, detail=_sweep_blocked)
        try:
            entry = _resolve_workspace_entry(workspace_id)
            ws_root = artefact_parent_for_entry(entry)
            mso = resolve_artefact_dir(ws_root)
            # cwd must be the PRODUCT repo: merge detection probes git refs and
            # resolves `gh` against the product remote. In solo/shared artefact
            # mode the artefact repo has neither.
            product_repo = product_repo_for_entry(entry)
        except OSError:
            raise fastapi.HTTPException(status_code=503, detail=STALE_MOUNT_MESSAGE)

        # BUG-MSO-2026-0682 F2: `--maestro-dir` must be an explicit argv
        # value — `cmd_voyage`'s `reconcile` action resolves via
        # `find_workspace()`, which deliberately IGNORES `MAESTRO_DIR`
        # (BUG-MSO-2026-0425) and instead walks up from cwd.
        # `run_verbs._handle_voyage_reconcile` already fixed this exact gap
        # for the LEAD Run button (BUG-MSO-2026-0675 F1); this endpoint (the
        # Hub's sweep/broom button) spawns the identical command and was left
        # behind. `env=` MAESTRO_DIR below is kept as a harmless secondary
        # signal for anything else in the subprocess that reads it ambiently
        # — it is not what makes this resolve correctly.
        cmd = [sys.executable, "-m", "maestro.cli", "voyage", "reconcile", "--json",
               "--maestro-dir", str(mso)]
        if dry_run:
            cmd.append("--dry-run")
        try:
            proc = subprocess.run(
                cmd,
                cwd=str(product_repo),
                env={**os.environ, "MAESTRO_DIR": str(mso)},
                stdin=subprocess.DEVNULL,
                capture_output=True,
                text=True,
                timeout=300,
            )
        except subprocess.TimeoutExpired:
            raise fastapi.HTTPException(
                status_code=504,
                detail="Housekeeping sweep timed out after 5 minutes (a PR "
                       "lookup may be hanging). No changes were reported.")

        if proc.returncode != 0:
            detail = (proc.stderr or proc.stdout or "").strip()[-500:]
            raise fastapi.HTTPException(
                status_code=500,
                detail=f"Housekeeping sweep failed: {detail or 'unknown error'}")
        try:
            # The CLI prints the JSON report last; tolerate any leading output.
            out = proc.stdout or ""
            payload = _json.loads(out[out.index("{"):])
        except (ValueError, _json.JSONDecodeError):
            raise fastapi.HTTPException(
                status_code=500,
                detail="Housekeeping sweep produced no readable report.")

        archived = payload.get("archived", 0)
        annotated = payload.get("annotated", 0)
        refusals = payload.get("refusals", []) or []
        verb = "would be " if dry_run else ""
        parts = [f"{archived} voyage(s) {verb}archived",
                 f"{annotated} {verb}annotated"]
        if refusals:
            parts.append(f"{len(refusals)} left untouched")
        return SweepResult(
            ok=True,
            workspace_id=workspace_id,
            action="sweep",
            message=("Dry run — " if dry_run else "") + ", ".join(parts),
            dryRun=bool(payload.get("dryRun", dry_run)),
            archived=archived,
            annotated=annotated,
            changes=payload.get("changes", []) or [],
            refusals=refusals,
        )

    # -----------------------------------------------------------------------
    # Phase 3 — Review queue endpoints
    # -----------------------------------------------------------------------

    def _iter_workspaces():
        """Yield (workspace_id, artefact_root_parent) for every registered workspace."""
        import maestro.registry as registry
        from maestro.workspace import artefact_parent_for_entry
        for ws_id, entry in registry.list_projects().items():
            yield ws_id, artefact_parent_for_entry(entry)

    def _find_order_workspace(order_id: str):
        """Return (workspace_id, workspace_path) for an order in any review queue.

        Raises HTTPException 404 if not found in any registered workspace.
        """
        _validate_order_id(order_id)
        from maestro.hub.review import _get_mso_dir
        for ws_id, ws_root in _iter_workspaces():
            try:
                mso = _get_mso_dir(ws_root)
                if (mso / "queues" / "review" / f"{order_id}.json").exists():
                    return ws_id, ws_root
            except Exception:
                pass
        raise fastapi.HTTPException(status_code=404, detail=f"Order '{order_id}' not found in any review queue")

    @app.get("/api/v1/review/queue", response_model=list[ReviewItem])
    async def review_queue():
        """List all NAV_REVIEW_PENDING orders across all registered workspaces.

        Returns a BARE ARRAY of ReviewItem (frontend api.ts contract).
        """
        from maestro.hub.review import find_review_pending_orders
        items: list[ReviewItem] = []
        for ws_id, ws_root in _iter_workspaces():
            try:
                orders = find_review_pending_orders(ws_root)
            except Exception:
                continue
            for data in orders:
                order_id = data.get("id") or data.get("orderId") or ""
                role = "PLN" if data.get("planApprovalOnly") else (data.get("targetRole") or data.get("role") or "")
                # BUG-MSO-2026-0711: "critical" survives normalisation here too —
                # the review list must not report a tier-overriding order as HIGH.
                priority = (str(data.get("priority")).lower() if data.get("priority") else None)
                if priority in ("medium", "med", "default"):
                    priority = "normal"
                elif priority == "urgent":
                    priority = "high"
                items.append(ReviewItem(
                    order_id=order_id,
                    workspace_id=ws_id,
                    workspace_name=ws_id,
                    order_title=data.get("title", "") or "",
                    role=role,
                    voyage_id=data.get("voyageId") or None,
                    created_at=data.get("createdAt", "") or "",
                    paused_at=data.get("navReviewPausedAt") or None,
                    priority=priority if priority in ("critical", "high", "normal", "low") else None,
                ))
        return items

    @app.get("/api/v1/review/{order_id}/plan", response_model=PlanResponse)
    async def review_get_plan(order_id: str):
        """Return plan markdown (or order description as fallback) plus order JSON."""
        from maestro.hub.review import get_plan_content
        ws_id, ws_root = _find_order_workspace(order_id)
        plan_md, has_plan, order_data = get_plan_content(ws_root, order_id)
        if order_data is None:
            raise fastapi.HTTPException(status_code=404, detail=f"Order '{order_id}' not found")
        return PlanResponse(
            workspace_id=ws_id,
            order_id=order_id,
            plan_markdown=plan_md or "",
            has_plan_file=has_plan,
            order=order_data,
        )

    @app.post("/api/v1/review/{order_id}/approve", response_model=ActionResult)
    async def review_approve(order_id: str):
        """Approve a NAV_REVIEW_PENDING order — moves to queues/orders/ with status PENDING."""
        _require_control_tier()
        from maestro.hub.review import approve_order
        ws_id, ws_root = _find_order_workspace(order_id)
        try:
            result = approve_order(ws_root, order_id)
        except FileNotFoundError as exc:
            raise fastapi.HTTPException(status_code=404, detail=str(exc))
        except ValueError as exc:
            raise fastapi.HTTPException(status_code=409, detail=str(exc))
        except PermissionError as exc:
            raise fastapi.HTTPException(status_code=403, detail=str(exc))
        # BUG-MSO-2026-0476: a plan approved with no dependent orders filed
        # gets a loud, distinct message instead of the generic one — the
        # operator needs to know a voyage now has no path to completion.
        message = f"Order {order_id} approved"
        if result.get("warning"):
            message = f"Order {order_id} approved — WARNING: {result['warning']}"
        return ActionResult(ok=True, order_id=order_id, new_status=result["new_status"],
                            message=message)

    @app.post("/api/v1/review/{order_id}/revise", response_model=ActionResult)
    async def review_revise(order_id: str, body: ReviseRequest):
        """Request revision — re-queues the order to the gated role (BUG-MSO-2026-0486 D2:
        previously left it stranded, unlabelled, in the review queue)."""
        _require_control_tier()
        from maestro.hub.review import revise_order
        ws_id, ws_root = _find_order_workspace(order_id)
        try:
            result = revise_order(ws_root, order_id, body.feedback)
        except FileNotFoundError as exc:
            raise fastapi.HTTPException(status_code=404, detail=str(exc))
        except ValueError as exc:
            raise fastapi.HTTPException(status_code=409, detail=str(exc))
        except PermissionError as exc:
            raise fastapi.HTTPException(status_code=403, detail=str(exc))
        return ActionResult(ok=True, order_id=order_id, new_status=result["new_status"],
                            message=f"Order {order_id} sent for revision")

    @app.post("/api/v1/review/{order_id}/reject", response_model=ActionResult)
    async def review_reject(order_id: str, body: RejectRequest):
        """Reject an order — marks FAILED, moves to orders/failed/ (BUG-MSO-2026-0486 D3:
        previously a Hub-only REJECTED/queues/review/rejected/ vocabulary that
        nothing else in the system scanned)."""
        _require_control_tier()
        from maestro.hub.review import reject_order
        ws_id, ws_root = _find_order_workspace(order_id)
        try:
            result = reject_order(ws_root, order_id, body.reason)
        except FileNotFoundError as exc:
            raise fastapi.HTTPException(status_code=404, detail=str(exc))
        except ValueError as exc:
            raise fastapi.HTTPException(status_code=409, detail=str(exc))
        except PermissionError as exc:
            raise fastapi.HTTPException(status_code=403, detail=str(exc))
        return ActionResult(ok=True, order_id=order_id, new_status=result["new_status"],
                            message=f"Order {order_id} rejected")

    # -----------------------------------------------------------------------
    # Order artefacts + retry (FTR-MSO-2026-0492) — voyage inspection/recovery
    # -----------------------------------------------------------------------

    def _find_order_workspace_any(order_id: str):
        """Return (workspace_id, workspace_path) for an order ANYWHERE — archived
        complete/failed, or live in any queue — not just queues/review/.

        Sibling to `_find_order_workspace()` (review-scoped) rather than a
        widening of it: BUG-MSO-2026-0486 rewrites `hub/review.py` and the
        review endpoints and is unmerged (PLAN-FTR-MSO-2026-0492 §4.5) — a
        conflict on an authorisation code path is exactly how a security fix
        gets silently dropped in merge resolution.
        """
        _validate_order_id(order_id)
        from maestro.hub.artefacts import find_order_file
        from maestro.hub.review import _get_mso_dir
        for ws_id, ws_root in _iter_workspaces():
            try:
                mso = _get_mso_dir(ws_root)
                if find_order_file(mso, order_id) is not None:
                    return ws_id, ws_root
            except Exception:
                pass
        raise fastapi.HTTPException(
            status_code=404, detail=f"Order '{order_id}' not found in any workspace")

    @app.get("/api/v1/orders/{order_id}/artefacts", response_model=OrderArtefacts)
    async def get_order_artefacts(order_id: str):
        """Discover every artefact belonging to *order_id* — manifest only, no
        content (§4.2). Read-only, ungated — matches `/review/{id}/plan`."""
        from maestro.hub import artefacts as _artefacts
        from maestro.hub.review import _get_mso_dir

        ws_id, ws_root = _find_order_workspace_any(order_id)
        mso = _get_mso_dir(ws_root)
        refs = _artefacts.discover_artefacts(mso, order_id)
        return OrderArtefacts(order_id=order_id, workspace_id=ws_id, artefacts=refs)

    @app.get("/api/v1/orders/{order_id}/artefacts/{key:path}", response_model=ArtefactContent)
    async def get_order_artefact_content(order_id: str, key: str):
        """Read one artefact's content, bounded at 512 KB (§5.5).

        *key* is re-validated by re-running discovery and matching — never by
        joining the client-supplied string onto a path (§4.2 / Builder note 4).
        A forged key (path traversal, an absolute path, a real file outside the
        manifest) matches nothing discovery finds and 404s, never leaks content.
        """
        from maestro.hub import artefacts as _artefacts
        from maestro.hub.review import _get_mso_dir

        _validate_order_id(order_id)
        ws_id, ws_root = _find_order_workspace_any(order_id)
        mso = _get_mso_dir(ws_root)
        try:
            return _artefacts.read_artefact(mso, order_id, key)
        except _artefacts.ArtefactNotFound as exc:
            raise fastapi.HTTPException(status_code=404, detail=str(exc))

    @app.get("/api/v1/orders/{order_id}/salvage-candidates",
             response_model=SalvageCandidates)
    def order_salvage_candidates(order_id: str):
        """Every salvage branch a retry could arm, and which one it would pick.

        BUG-MSO-2026-0696 AC-4: read-only preview of the SAME core selection
        the CLI and `POST .../retry` use — `salvage_record.salvage_candidates()`
        plus `select_salvage()`. Nothing here re-derives candidates, so the Hub
        cannot drift into showing a different set from the CLI's.

        Ungated: this reads order JSON and decides nothing. `ambiguous` carries
        the reason a bare retry would REFUSE, so a UI can require a selection
        up front instead of surfacing a 409 after the operator has committed.
        """
        import json as _json

        from maestro.core import salvage_record
        from maestro.hub.artefacts import find_order_file
        from maestro.hub.review import _get_mso_dir

        _validate_order_id(order_id)
        ws_id, ws_root = _find_order_workspace_any(order_id)
        mso = _get_mso_dir(ws_root)
        order_file = find_order_file(mso, order_id)
        if order_file is None:
            raise fastapi.HTTPException(
                status_code=404, detail=f"Order {order_id} not found in {ws_id}.")
        try:
            data = _json.loads(order_file.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            raise fastapi.HTTPException(
                status_code=503, detail=f"Cannot read {order_file}: {exc}")
        candidates = salvage_record.salvage_candidates(data)
        sel = salvage_record.select_salvage(candidates)
        return SalvageCandidates(
            order_id=order_id,
            candidates=[SalvageCandidateModel(**c.to_dict()) for c in candidates],
            would_arm=sel.chosen.branch if sel.chosen else None,
            ambiguous=sel.ambiguous,
        )

    @app.post("/api/v1/orders/{order_id}/retry", response_model=RetryResult)
    def retry_order_endpoint(
        order_id: str,
        salvage: str | None = fastapi.Query(default=None),
        no_salvage: bool = fastapi.Query(default=False),
        force_salvage: bool = fastapi.Query(default=False),
    ):
        """Reopen a stranded/terminal order — `mso order retry` over HTTP.

        PLAN-FTR-MSO-2026-0492 §4.1: this MUST be a sync `def`, not `async def`.
        `order_retry.retry_order()` holds `order_retry._SCOPE_LOCK` for its
        duration to guard `fleet_runner`'s process-global artefact-root
        override; FastAPI runs a sync path operation in its threadpool, so the
        lock only ever blocks other threadpool work. An `async def` would hold
        the lock on the event loop itself and stall every other request —
        correctness, not style.

        BUG-MSO-2026-0696 AC-4: `salvage` / `no_salvage` / `force_salvage` are
        the same three selectors the CLI exposes, passed straight through to the
        shared core. An ambiguous salvage choice raises `SalvageAmbiguous` — a
        `RetryRefused` subclass, so it already maps to the 409 below, and its
        message carries the full candidate listing rather than a bare refusal.
        """
        _require_control_tier()
        _validate_order_id(order_id)
        from maestro.core import order_retry
        from maestro.hub.review import _get_mso_dir
        from maestro.identity.gate import CapabilityDenied

        ws_id, ws_root = _find_order_workspace_any(order_id)
        mso = _get_mso_dir(ws_root)
        try:
            outcome = order_retry.retry_order(
                mso, order_id, reason="operator retry (hub)",
                salvage=salvage, no_salvage=no_salvage,
                force_salvage=force_salvage)
        except order_retry.OrderNotFound as exc:
            raise fastapi.HTTPException(status_code=404, detail=str(exc))
        except order_retry.RetryRefused as exc:
            raise fastapi.HTTPException(status_code=409, detail=str(exc))
        except CapabilityDenied as exc:
            raise fastapi.HTTPException(status_code=403, detail=str(exc))
        except OSError:
            raise fastapi.HTTPException(status_code=503, detail=STALE_MOUNT_MESSAGE)

        return RetryResult(
            ok=True,
            order_id=order_id,
            new_status=outcome.new_status,
            target_role=outcome.target_role,
            salvage_branch=outcome.salvage_branch,
            salvage_candidates=[SalvageCandidateModel(**c)
                                for c in outcome.salvage_candidates],
            salvage_explicit=outcome.salvage_explicit,
            message=f"Order {order_id} reopened: "
                    f"{outcome.new_status}@{outcome.target_role}{outcome.salvage_note}",
        )

    # -----------------------------------------------------------------------
    # Usage aggregation endpoints (FTR-MSO-2026-0333) — read-only, ungated
    # -----------------------------------------------------------------------

    @app.get("/api/v1/usage", response_model=UsageRollup)
    async def get_usage_rollup(
        from_: str | None = fastapi.Query(default=None, alias="from"),
        to: str | None = fastapi.Query(default=None),
        group_by: str = fastapi.Query(default="project"),
    ):
        """Cross-workspace usage rollup, optionally filtered by date range.

        group_by: 'project' | 'voyage' | 'order' | 'role'
        from / to: inclusive date range in YYYY-MM-DD format
        """
        from maestro.hub.aggregator import aggregate_usage_cross_workspace
        if group_by not in ("project", "voyage", "order", "role"):
            raise fastapi.HTTPException(
                status_code=400,
                detail=f"Invalid group_by '{group_by}'. Must be one of: project, voyage, order, role",
            )
        return aggregate_usage_cross_workspace(
            from_date=from_,
            to_date=to,
            group_by=group_by,
        )

    @app.get("/api/v1/usage/projects/{project_id}", response_model=UsageRollup)
    async def get_project_usage(
        project_id: str,
        from_: str | None = fastapi.Query(default=None, alias="from"),
        to: str | None = fastapi.Query(default=None),
    ):
        """Per-project usage with voyage/order breakdown."""
        import maestro.registry as registry
        from maestro.hub.aggregator import aggregate_usage_for_project
        from maestro.workspace import artefact_parent_for_entry

        projects = registry.list_projects()
        if project_id not in projects:
            raise fastapi.HTTPException(status_code=404, detail=f"Project '{project_id}' not found")
        ws_root = artefact_parent_for_entry(projects[project_id])
        return aggregate_usage_for_project(project_id, ws_root, from_date=from_, to_date=to)

    @app.get("/api/v1/usage/voyages/{voyage_id}", response_model=UsageRollup)
    async def get_voyage_usage(
        voyage_id: str,
        from_: str | None = fastapi.Query(default=None, alias="from"),
        to: str | None = fastapi.Query(default=None),
    ):
        """Per-voyage usage: orders breakdown (+ role breakdown if FTR-0332 data present)."""
        import maestro.registry as registry
        from maestro.hub.aggregator import aggregate_usage_for_voyage, _get_mso_dir
        from maestro.workspace import artefact_parent_for_entry

        projects = registry.list_projects()
        for ws_id, entry in projects.items():
            ws_root = artefact_parent_for_entry(entry)
            try:
                mso = _get_mso_dir(ws_root)
            except Exception:
                continue
            for sub in ("active", "complete"):
                if (mso / "voyages" / sub / f"{voyage_id}.json").exists():
                    return aggregate_usage_for_voyage(voyage_id, ws_root, from_date=from_, to_date=to)
        # No workspace claims the voyage — return a zero rollup (not an error)
        return UsageRollup(from_date=from_, to_date=to, group_by="order")

    @app.get("/api/v1/usage/orders/{order_id}", response_model=OrderUsageDetail)
    async def get_order_usage(order_id: str):
        """Per-order usage: roles/iterations/models breakdown."""
        from maestro.hub.aggregator import _find_order_usage_dir, get_order_usage_detail

        usage_dir = _find_order_usage_dir(order_id)
        if usage_dir is None:
            # Order not found in any workspace — return a zero detail (not an error)
            return OrderUsageDetail(order_id=order_id)
        return get_order_usage_detail(order_id, usage_dir)

    @app.websocket("/api/v1/lifecycle/stream")
    async def lifecycle_stream(websocket: fastapi.WebSocket):
        import asyncio
        import maestro.registry as registry
        import maestro.hub.server as _server_mod
        from maestro.hub.lifecycle_tail import (
            LifecycleTail, _parse_event_type, _parse_timestamp, _parse_message,
            _parse_order_id, _parse_role, _parse_crew_slot, _parse_subtype,
        )
        from maestro.hub.models import LifecycleEvent
        from maestro.workspace import artefact_parent_for_entry

        def _build_event(ws_id: str, ws_name: str, line: str) -> LifecycleEvent:
            return LifecycleEvent(
                workspace_id=ws_id,
                workspace_name=ws_name,
                line=line,
                message=_parse_message(line),
                timestamp=_parse_timestamp(line),
                event_type=_parse_event_type(line),
                order_id=_parse_order_id(line),
                crew_slot=_parse_crew_slot(line),
                role=_parse_role(line),
                subtype=_parse_subtype(line),
            )

        # Audit finding H6: WebSockets bypass CORS, so validate the Origin
        # against the allowlist and enforce the bearer token (query param) BEFORE
        # accepting — otherwise any web page could open ws:// to the localhost
        # Hub and live-tail every workspace's lifecycle log.
        origin = websocket.headers.get("origin")
        if origin and origin not in _ORIGINS:
            await websocket.close(code=1008)
            return
        _tok = _expected_token()
        if _tok:
            import hmac as _hmac
            presented = websocket.query_params.get("token", "")
            if not presented or not _hmac.compare_digest(presented, _tok):
                await websocket.close(code=1008)
                return

        await websocket.accept()
        try:
            projects = registry.list_projects()
            # Optional ?workspace_id=<ID> scopes the stream to one workspace
            # (the detail page passes it); absent → stream all (overview page).
            only = websocket.query_params.get("workspace_id")
            if only:
                projects = {k: v for k, v in projects.items() if k == only}
            tails: dict[str, tuple[str, LifecycleTail]] = {
                ws_id: (ws_id, LifecycleTail(artefact_parent_for_entry(entry)))
                for ws_id, entry in projects.items()
            }

            # Backfill: send last 20 lines per workspace on connect
            for ws_id, (ws_name, tail) in tails.items():
                for line in tail.read_last_n(20):
                    await websocket.send_json(_build_event(ws_id, ws_name, line).model_dump())
                tail.seek_to_end()

            # Poll loop: push new lines every _WS_POLL_INTERVAL seconds
            while True:
                await asyncio.sleep(_server_mod._WS_POLL_INTERVAL)
                for ws_id, (ws_name, tail) in tails.items():
                    for line in tail.read_new_lines():
                        await websocket.send_json(_build_event(ws_id, ws_name, line).model_dump())
        except Exception:
            pass  # client disconnected or connection error

    # -----------------------------------------------------------------------
    # API namespace 404 fallback (BUG-MSO-2026-0627)
    # -----------------------------------------------------------------------
    # Registered AFTER every other /api/... route above and BEFORE the static
    # UI mount below — route order is match order in Starlette, so this only
    # ever catches a path under /api that nothing more specific matched.
    #
    # Without this, an unmatched /api/... request falls all the way through
    # FastAPI's routing and is served by the StaticFiles("/") mount at the
    # bottom of this function as the SPA's OWN 404 page — a ~20KB HTML
    # document (markup, script tags, inline CSS) delivered with a 200-shaped
    # body to a caller that expected JSON. That HTML then propagates raw
    # through the frontend's error-handling chain (apiFetch -> Error message
    # -> drawer/toast) because nothing along that chain expected non-JSON.
    # The reported case: the LEAD drawer calling a route (`/lead/detail`)
    # that a stale, not-yet-restarted Hub process didn't have yet.
    #
    # The static mount is correct for UI routes and wrong for the /api
    # namespace; this route draws that boundary explicitly instead of
    # relying on route-registration order to (accidentally) get it right.
    @app.api_route(
        "/api/{full_path:path}",
        methods=["GET", "POST", "PUT", "PATCH", "DELETE"],
        include_in_schema=False,
    )
    async def _api_route_not_found(full_path: str):
        raise fastapi.HTTPException(
            status_code=404, detail=f"API route not found: /api/{full_path}")

    # --- Static UI bundle (FTR-MSO-2026-0421) -------------------------------
    # The LOCAL, no-Docker Hub serves the statically-exported frontend from the
    # backend on the SAME origin/port — no Node, no second daemon. The bundle is
    # shipped in the wheel at `maestro/hub/static/` (package-data; the publish
    # workflow runs `npm run build` and copies `maestro-hub/out/` there before
    # the wheel build). Mounted at "/" AFTER every API route, so the explicit
    # `/api/...` routes still match first and the mount is the SPA fallback.
    #
    # A source checkout with no built bundle degrades gracefully: the mount is
    # skipped and "/" returns a clear, machine-readable message pointing at the
    # build step — the API stays fully available under /api/v1/.
    from pathlib import Path as _Path

    _static_dir = _Path(__file__).resolve().parent / "static"
    if (_static_dir / "index.html").is_file():
        from fastapi.staticfiles import StaticFiles

        app.mount("/", StaticFiles(directory=str(_static_dir), html=True), name="hub-ui")
    else:
        # BUG-MSO-2026-0516: name the resolved path checked. Without it, an
        # operator has no way to tell "genuinely installed wheel missing its
        # bundle" apart from "this is a source checkout, which never ships one
        # by design" — both looked identical before this fix, and the latter
        # is the far more common case (it's exactly what running `mso hub
        # start` from inside a Maestro checkout produces).
        _UI_MISSING_MESSAGE = (
            "Maestro Hub API is running, but the web UI bundle is not built. "
            f"Checked for a built bundle at: {_static_dir} — if that path is "
            "inside a Maestro source checkout rather than an installed wheel's "
            "site-packages, this is expected: checkouts never carry a built "
            "bundle (it's produced by CI at publish time). The API is fully "
            "available under /api/v1/. To serve the UI, either install a "
            "released wheel (which ships the built bundle at "
            "maestro/hub/static/), run `npm ci && npm run build` in maestro-hub/ "
            "and copy the resulting out/ to maestro/hub/static/, or use the "
            "Docker frontend container."
        )

        @app.get("/", include_in_schema=False)
        async def _ui_bundle_missing():
            return fastapi.responses.JSONResponse(
                status_code=200,
                content={"ui": "unavailable", "message": _UI_MISSING_MESSAGE},
            )

    return app
