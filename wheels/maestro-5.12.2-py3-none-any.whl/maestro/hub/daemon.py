# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Hub daemon PID management (mirrors maestro/bridge.py pattern exactly).

The hub is a GLOBAL daemon (not per-workspace) — PID file at ~/.maestro/hub.pid.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import time
import webbrowser
from datetime import datetime, timezone
from pathlib import Path

# FTR-MSO-2026-0536 promoted this to maestro/proc_identity.py so the LEAD
# daemon and the Hub daemon share ONE identity implementation. Imported
# under the original private name so existing tests that monkeypatch
# `daemon._process_create_time` keep working unchanged.
from maestro.proc_identity import (
    process_create_time as _process_create_time,
    read_identity_record as _read_record,
    read_record_dict as _read_record_dict,
    write_identity_record as _write_record,
)
from typing import Optional, Tuple

from maestro.hub import logs as _logs
from maestro.launch.sandbox import spawn as _spawn
from maestro.workspace import get_maestro_home

DEFAULT_PORT = 3847


def _hub_pid_file() -> Path:
    """Global Hub PID file, resolved live so MAESTRO_HOME redirects it
    (BUG-MSO-2026-0387). Default ``~/.maestro/hub.pid``."""
    return get_maestro_home() / "hub.pid"


# ---------------------------------------------------------------------------
# Process-identity helpers (BUG-MSO-2026-0424)
#
# A bare PID is NOT a stable process identity — operating systems recycle PIDs,
# so after the hub dies uncleanly the recorded number can be reassigned to
# unrelated software. We therefore record the process CREATION TIME alongside
# the PID and treat a record as "our hub" only when a process with that PID
# exists AND its creation time matches. A recycled PID always has a later start
# time, so the check is decisive and needs no third-party dependency.
# ---------------------------------------------------------------------------

def _read_pid(pid_file: Path) -> Optional[int]:
    """Backwards-compatible PID accessor (identity NOT verified)."""
    rec = _read_record(pid_file)
    return rec[0] if rec else None


def _is_process_alive(pid: int) -> bool:
    """Bare liveness — does SOME process hold *pid*? Kept for callers that only
    need existence; the hub lifecycle uses :func:`_is_hub_running` instead,
    which also verifies process identity."""
    return _process_create_time(pid) is not None


def _is_hub_running(pid_file: Path) -> Tuple[bool, Optional[int]]:
    """Identity-verified hub liveness.

    Returns ``(running, pid)``. ``running`` is ``True`` only when the recorded
    PID belongs to a live process whose creation time matches the recorded
    identity. A recycled PID (same number, different — later — process) or a
    legacy record with no recorded identity is classified as NOT running, so no
    termination signal is ever sent to an unrelated process.
    """
    rec = _read_record(pid_file)
    if rec is None:
        return (False, None)
    pid, recorded_ct = rec
    if not pid or pid <= 0 or recorded_ct is None:
        return (False, pid or None)
    current_ct = _process_create_time(pid)
    if current_ct is None or current_ct != recorded_ct:
        return (False, pid)
    return (True, pid)


# ---------------------------------------------------------------------------
# Dep check
# ---------------------------------------------------------------------------

def _ensure_hub_deps() -> None:
    try:
        import fastapi  # noqa: F401
        import uvicorn  # noqa: F401
    except ImportError:
        print(
            "[Hub] FastAPI/uvicorn not installed.\n"
            "      Install the hub extra:  pip install 'maestro-fleet[hub]'",
            file=sys.stderr,
        )
        sys.exit(1)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def _hub_entry_point() -> Path:
    """Absolute path to ``maestro/hub/__main__.py`` (BUG-MSO-2026-0516).

    ``python -m maestro.hub`` puts the SUBPROCESS'S OWN cwd at ``sys.path[0]``.
    Since the single most likely place an operator runs ``mso hub start`` from
    is a Maestro source checkout, that checkout's own (bundle-less) ``maestro/``
    package silently shadows the installed wheel — the daemon comes up
    correctly, but serving from the wrong package tree, with no built UI
    bundle to mount, so it degrades to the API-only payload while looking
    identical to the real thing.

    Launching by this RESOLVED FILE PATH instead sidesteps the trap entirely:
    running ``python <script>.py`` puts the script's own directory at
    ``sys.path[0]``, never the cwd. Because that directory is derived from
    ``__file__`` of THIS already-imported module — the same import that
    resolved the currently-running ``mso`` process's own ``maestro`` package —
    the spawned daemon is guaranteed to import that exact same package,
    regardless of what the operator's cwd happens to be. This makes cwd
    irrelevant to package resolution rather than merely picking a "safer" cwd
    (a plain ``cwd=`` override would still leave any *other* cwd-sensitive
    code path — see the sibling BUG-MSO-2026-0515 — exposed).
    """
    return Path(__file__).resolve().parent / "__main__.py"


def _child_env_pinned_to_this_package(base_env: Optional[dict] = None) -> dict:
    """Child environment with THIS process's ``maestro`` package parent
    prepended to ``PYTHONPATH``.

    BUG-MSO-2026-0712 found that :func:`_hub_entry_point`'s guarantee — "the
    spawned daemon is guaranteed to import that exact same package" — did not
    actually hold. Launching by file path puts ``maestro/hub/`` on the child's
    ``sys.path[0]``, which correctly stops the CWD from shadowing anything but
    does NOT make ``import maestro`` resolve to the parent's tree: the child
    falls through to whatever is installed in site-packages. Parent and child
    therefore ran DIFFERENT Maestro versions whenever the two differed (a
    source checkout, a repo-relative import, a stale install), and the child
    won silently.

    This was latent until this order added ``maestro.hub.logs``: a child
    resolving an older installed package died at import with
    ``ImportError: cannot import name 'logs'`` — and, before this same order,
    with its stderr going to ``DEVNULL``, so ``mso hub start`` printed
    "Started ... (PID N)" for a process that was already gone. Pinning the
    path makes the docstring's claim true by construction rather than by
    hope; when parent and child would have agreed anyway (an ordinary wheel
    install) it prepends the directory the child was going to use regardless,
    and changes nothing.
    """
    env = dict(base_env if base_env is not None else os.environ)
    try:
        import maestro
        package_parent = str(Path(maestro.__file__).resolve().parent.parent)
    except Exception:  # noqa: BLE001 — an unpinnable parent is not a reason to refuse to start
        return env
    existing = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = (
        package_parent + os.pathsep + existing if existing else package_parent
    )
    return env


def start_hub(port: int = DEFAULT_PORT, open_browser: bool = False, force: bool = False) -> None:
    hub_pid = _hub_pid_file()
    running, existing_pid = _is_hub_running(hub_pid)
    if running and not force:
        print(f"[Hub] Already running (PID: {existing_pid}) on http://127.0.0.1:{port}")
        if open_browser:
            webbrowser.open(f"http://127.0.0.1:{port}")
        return
    if not running and hub_pid.exists():
        # Stale / recycled-PID / legacy record — clear it and start clean.
        # NB: no signal is ever sent here; the old PID may now belong to
        # unrelated software (BUG-MSO-2026-0424).
        hub_pid.unlink()

    _ensure_hub_deps()

    cmd = [sys.executable, str(_hub_entry_point()), "--port", str(port)]
    hub_pid.parent.mkdir(parents=True, exist_ok=True)

    # BUG-MSO-2026-0712: the child's stdout+stderr go to ~/.maestro/logs/hub.log,
    # never DEVNULL. Rotation is checked HERE, at the one moment no live daemon
    # holds the file open (Windows cannot rename an open file) — see
    # maestro/hub/logs.py's module docstring. Any previous run's exit record is
    # cleared first so a later `mso hub status` can never attribute an OLD death
    # to the run starting now.
    _logs.clear_exit_record()
    log_path = _logs.hub_log_path()
    try:
        log_handle = _logs.open_log_for_append()
    except OSError as exc:
        # A log we cannot open is a reason to say so, not a reason to refuse
        # to start — the Hub being up matters more than its log, and the
        # pre-0712 behaviour was no log at all.
        print(f"[Hub] WARNING: could not open {log_path} ({exc}) — starting without capture",
              file=sys.stderr)
        log_handle = None

    stream = log_handle if log_handle is not None else subprocess.DEVNULL
    child_env = _child_env_pinned_to_this_package()
    try:
        if os.name == "nt":
            DETACHED_PROCESS = 0x00000008
            CREATE_NEW_PROCESS_GROUP = 0x00000200
            flags = DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
            proc = _spawn(
                cmd,
                identity="hub",
                env=child_env,
                creationflags=flags,
                stdout=stream,
                stderr=subprocess.STDOUT if log_handle is not None else subprocess.DEVNULL,
            )
        else:
            proc = _spawn(
                cmd,
                identity="hub",
                env=child_env,
                start_new_session=True,
                stdout=stream,
                stderr=subprocess.STDOUT if log_handle is not None else subprocess.DEVNULL,
            )
    finally:
        # The child inherited its own duplicate of the handle; this parent's
        # copy must not be held open, or a later rotation could not rename the
        # file on Windows even after the daemon has gone.
        if log_handle is not None:
            try:
                log_handle.close()
            except OSError:
                pass

    _write_record(
        hub_pid,
        proc.pid,
        _process_create_time(proc.pid),
        extra={
            "port": port,
            "startedAt": datetime.now(timezone.utc).isoformat(),
            "logPath": str(log_path),
        },
    )
    print(f"[Hub] Started on http://127.0.0.1:{port} (PID {proc.pid})")
    print(f"[Hub] Log: {log_path}")
    if open_browser:
        webbrowser.open(f"http://127.0.0.1:{port}")


def stop_hub(*, timeout: float = 10.0, poll_interval: float = 0.5) -> bool:
    """Stop the Hub daemon and BLOCK until it has actually exited.

    BUG-MSO-2026-0516: the previous implementation printed "Stop signal sent"
    on the strength of having SENT a signal — never confirming the process
    actually died — so ``mso hub stop`` could report success while the daemon
    (and its hold on the port) lived on. This version waits for the
    identity-verified record to go not-running, escalates to a force-kill if
    the graceful signal doesn't land within ``timeout`` seconds, and returns
    ``False`` (with a truthful failure message) if the process still could not
    be stopped — "signal sent" is never printed as though it meant "stopped".

    Returns ``True`` once the daemon is confirmed gone (or was never running).
    """
    hub_pid = _hub_pid_file()
    running, pid = _is_hub_running(hub_pid)
    if not running:
        # Not our hub (dead, recycled PID, or legacy record). Send NO signal —
        # the recorded PID may now belong to unrelated software
        # (BUG-MSO-2026-0424) — and always clear the stale record.
        print("[Hub] Not running")
        if hub_pid.exists():
            # BUG-MSO-2026-0712: this record surviving next to a dead PID means
            # the hub CRASHED. Clearing it here is correct (the operator asked
            # to stop), but doing so silently would destroy the only signal
            # that says so — say what happened before the evidence goes.
            ev = death_evidence(tail_lines=3)
            print(f"[Hub]   (PID {ev.get('pid')} had crashed — died {ev.get('diedAt')}"
                  f", exit {ev.get('exitCode') if ev.get('exitCode') is not None else 'not recorded'})")
            print(f"[Hub]   Log: {ev.get('logPath')}")
            hub_pid.unlink()
        return True

    def _signal(force: bool) -> None:
        try:
            if os.name == "nt":
                cmd = ["taskkill", "/PID", str(pid)]
                if force:
                    cmd.append("/F")
                subprocess.run(cmd, capture_output=True, timeout=10)
            else:
                os.kill(pid, 9 if force else 15)  # SIGKILL : SIGTERM
        except Exception as exc:
            kind = "force-kill" if force else "stop"
            print(f"[Hub] Failed to send {kind} signal: {exc}", file=sys.stderr)

    def _wait_for_exit(budget_seconds: float) -> bool:
        iterations = max(1, int(budget_seconds / poll_interval))
        for _ in range(iterations):
            if not _is_hub_running(hub_pid)[0]:
                return True
            time.sleep(poll_interval)
        return not _is_hub_running(hub_pid)[0]

    def _confirm_stopped(note: str = "") -> bool:
        if hub_pid.exists():
            hub_pid.unlink()
        print(f"[Hub] Stopped (PID: {pid}){note}")
        return True

    _signal(force=False)
    if _wait_for_exit(timeout):
        return _confirm_stopped()

    print(
        f"[Hub] PID {pid} still running after {timeout:.0f}s — escalating to force-kill",
        file=sys.stderr,
    )
    _signal(force=True)
    if _wait_for_exit(5.0):
        return _confirm_stopped(", required force-kill")

    print(
        f"[Hub] Failed to stop (PID: {pid} still running after stop signal + force-kill)",
        file=sys.stderr,
    )
    return False


def _installed_version() -> Optional[str]:
    """This reader's own fresh import — used ONLY as a fallback when the
    live Hub process can't be reached to ask it about itself (see
    ``hub_status`` below). Mirrors ``maestro.lead.daemon._installed_version``.
    """
    try:
        import maestro
        return getattr(maestro, "__version__", None)
    except Exception:
        return None


def _fetch_health(port: int, timeout: float = 2.0) -> Optional[dict]:
    """Best-effort GET of the running Hub's own /api/v1/health.

    BUG-MSO-2026-0627: `/api/v1/health` is exempt from the bearer-token gate
    (see `hub/server.py`'s auth guard — `/health` and `/ping` stay open for
    liveness probes), so no token handling is needed here. The health
    response already carries `version` (this process's pinned code version)
    and `installedVersion`/`versionMismatch` (a live self-check computed
    fresh on every call via `importlib.metadata`, so it reflects a `pip
    install --upgrade` done after this daemon started, without needing a
    restart) — `hub_status()` below just relays what the live process
    already knows about itself. Returns ``None`` on any failure (backend not
    responding on this port, connection refused, timeout, bad JSON): a
    version-unknown Hub is reported honestly, never guessed.
    """
    import json as _json
    import urllib.request

    try:
        with urllib.request.urlopen(
            f"http://127.0.0.1:{port}/api/v1/health", timeout=timeout
        ) as resp:
            return _json.loads(resp.read().decode("utf-8"))
    except Exception:
        return None


def recorded_port(default: int = DEFAULT_PORT) -> int:
    """The port the CURRENT PID record was started on, falling back to
    *default*.

    BUG-MSO-2026-0712: a reader that assumes ``DEFAULT_PORT`` reports a Hub
    started with ``--port 4000`` as unreachable — a false alarm that would
    make the new ``hub.alive`` patrol check worse than no check at all. The
    port is written into the PID record at start (one file, no second piece
    of state to fall out of sync), so a record written by an older Maestro
    simply has no ``port`` key and degrades to *default* exactly as before.
    """
    record = _read_record_dict(_hub_pid_file()) or {}
    value = record.get("port")
    try:
        return int(value) if value is not None else default
    except (TypeError, ValueError):
        return default


def death_evidence(*, tail_lines: int = 5) -> dict:
    """Everything knowable about a Hub that is no longer running.

    Deliberately assembled from THREE independent sources, because no single
    one covers every way a daemon dies (BUG-MSO-2026-0712):

    * ``startedAt`` / ``pid`` — the PID record the last ``mso hub start``
      wrote. Left in place by a crash; only a clean ``mso hub stop`` removes
      it, so its presence next to a dead PID IS the crash signal.
    * ``diedAt`` — the exit record's own timestamp when the daemon managed
      to write one, otherwise the PID file's mtime. ``diedAtSource`` says
      which, because the second is only ever an upper bound ("no later
      than"), never the moment of death — a hard kill leaves the mtime at
      the START time, and reporting that as the death time would be a
      fabrication.
    * ``exitCode`` / ``error`` / ``traceback`` — present only when the
      daemon observed its own exit. ``None`` is the honest answer for a
      ``taskkill /F``, a console-session teardown or an OOM.
    """
    pid_file = _hub_pid_file()
    record = _read_record_dict(pid_file) or {}
    exit_record = _logs.read_exit_record() or {}

    pid = record.get("pid")
    # An exit record from a DIFFERENT process is a previous run's death, not
    # this one's — reported as such rather than silently misattributed.
    exit_pid = exit_record.get("pid")
    exit_is_for_this_pid = bool(exit_record) and (exit_pid is None or exit_pid == pid)

    died_at = None
    died_at_source = None
    if exit_is_for_this_pid and exit_record.get("at"):
        died_at, died_at_source = exit_record["at"], "exit-record"
    else:
        try:
            died_at = datetime.fromtimestamp(
                pid_file.stat().st_mtime, tz=timezone.utc
            ).isoformat()
            died_at_source = "pid-file-mtime"
        except OSError:
            pass

    return {
        "pidFile": str(pid_file),
        "pidFileExists": pid_file.exists(),
        "pid": pid,
        "startedAt": record.get("startedAt"),
        "diedAt": died_at,
        "diedAtSource": died_at_source,
        "exitCode": exit_record.get("exitCode") if exit_is_for_this_pid else None,
        "exitError": exit_record.get("error") if exit_is_for_this_pid else None,
        "exitRecordedForPid": exit_pid if exit_record else None,
        "exitRecordIsStale": bool(exit_record) and not exit_is_for_this_pid,
        "logPath": str(_logs.hub_log_path()),
        "logTail": _logs.tail(tail_lines),
    }


PORT_PROBE_TIMEOUT_SECONDS = 5.0


def port_answers(port: int, timeout: float = PORT_PROBE_TIMEOUT_SECONDS) -> bool:
    """Does a live Hub actually SERVE on *port* within *timeout* seconds?

    Probes ``/api/v1/ping`` — the auth-exempt liveness route that touches no
    registry, filesystem or poller (BUG-MSO-2026-0390) — deliberately rather
    than a bare TCP connect: the kernel accepts a connection into the listen
    backlog even when the server behind it is wedged, so a socket-level check
    would call a hung Hub healthy. ``/api/v1/health`` is the wrong probe for
    the opposite reason: it walks every registered workspace, so a slow scan
    on a big fleet would read as a fault.

    Returns ``False`` on any failure — the caller reports "did not answer",
    which is exactly what a would-be dashboard user experiences.
    """
    import urllib.request

    try:
        with urllib.request.urlopen(
            f"http://127.0.0.1:{port}/api/v1/ping", timeout=timeout
        ) as resp:
            return 200 <= getattr(resp, "status", 200) < 400
    except Exception:  # noqa: BLE001 — any failure means "not answering"
        return False


def hub_status(port: int = DEFAULT_PORT) -> dict:
    running, pid = _is_hub_running(_hub_pid_file())
    health = _fetch_health(port) if running else None
    if health:
        running_version = health.get("version")
        installed_version = health.get("installedVersion") or _installed_version()
        version_mismatch = bool(health.get("versionMismatch"))
    else:
        # Backend unreachable (wrong port, unresponsive, or genuinely not
        # running) — report what we honestly know: nothing about the running
        # process, only this reader's own fresh import as a best-effort
        # installed-version hint.
        running_version = None
        installed_version = _installed_version()
        version_mismatch = False
    status = {
        "running": running,
        "pid": pid if running else None,
        "port": port,
        "runningVersion": running_version,
        "installedVersion": installed_version,
        "versionMismatch": version_mismatch,
        "logPath": str(_logs.hub_log_path()),
        "startedAt": (_read_record_dict(_hub_pid_file()) or {}).get("startedAt") if running else None,
    }
    # BUG-MSO-2026-0712: a STOPPED hub whose PID file survives is a CRASHED
    # hub — a clean `mso hub stop` always removes the record. That distinction
    # is the whole finding, so the evidence rides on the status dict rather
    # than being left for the operator to go and dig up.
    if not running and _hub_pid_file().exists():
        status["crashed"] = True
        status["evidence"] = death_evidence()
    else:
        status["crashed"] = False
        status["evidence"] = None
    return status


def _describe_age(iso_timestamp: Optional[str]) -> str:
    """``"2026-09-09T21:40:11+00:00 (1h 57m ago)"`` — or the raw value when it
    cannot be parsed, never a guess."""
    if not iso_timestamp:
        return "(unknown)"
    try:
        stamp = datetime.fromisoformat(iso_timestamp)
        if stamp.tzinfo is None:
            stamp = stamp.replace(tzinfo=timezone.utc)
    except (TypeError, ValueError):
        return str(iso_timestamp)
    seconds = int((datetime.now(timezone.utc) - stamp).total_seconds())
    if seconds < 0:
        return f"{iso_timestamp} (in the future — clock skew?)"
    if seconds < 60:
        ago = f"{seconds}s ago"
    elif seconds < 3600:
        ago = f"{seconds // 60}m ago"
    else:
        ago = f"{seconds // 3600}h {(seconds % 3600) // 60}m ago"
    return f"{iso_timestamp} ({ago})"


def print_status(port: int = DEFAULT_PORT) -> None:
    s = hub_status(port=port)
    print("\n  MAESTRO HUB — STATUS")
    print("  " + "-" * 40)
    if s["running"]:
        print(f"  Status:  RUNNING (PID: {s['pid']})")
        print(f"  URL:     http://127.0.0.1:{s['port']}")
        if s.get("startedAt"):
            print(f"  Started: {_describe_age(s['startedAt'])}")
        version_line = f"  Running version: {s.get('runningVersion') or '(unknown — health check unreachable)'}"
        if s.get("versionMismatch"):
            version_line += f"  [STALE — installed is {s.get('installedVersion')}]"
        print(version_line)
        print(f"  Log:     {s.get('logPath')}")
    elif s.get("crashed"):
        # BUG-MSO-2026-0712: STOPPED-with-a-PID-file is a CRASH, and saying
        # only "STOPPED" here is what left the 2026-09-09 death unexplainable.
        ev = s["evidence"] or {}
        print(f"  Status:  STOPPED — crashed (PID {ev.get('pid')} is gone, PID file survives)")
        if ev.get("startedAt"):
            print(f"  Started: {_describe_age(ev['startedAt'])}")
        died_source = {
            "exit-record": "recorded by the daemon",
            "pid-file-mtime": "PID-file mtime — an upper bound, not the moment of death",
        }.get(ev.get("diedAtSource") or "", "source unknown")
        print(f"  Died:    {_describe_age(ev.get('diedAt'))}  [{died_source}]")
        if ev.get("exitCode") is not None:
            print(f"  Exit:    code {ev['exitCode']}"
                  + (f" — {ev['exitError']}" if ev.get("exitError") else ""))
        else:
            print("  Exit:    not recorded — the daemon was killed without a chance to "
                  "write one (hard kill, console teardown, or OOM)")
        print(f"  Log:     {ev.get('logPath')}")
        log_tail = ev.get("logTail") or []
        if log_tail:
            print("  Last log lines:")
            for line in log_tail:
                print(f"    | {line}")
        else:
            print("  Last log lines: (none — log absent or empty)")
        print("  Restart: mso hub start")
    else:
        print("  Status:  STOPPED")
        print(f"  Log:     {s.get('logPath')}")
    print("  " + "-" * 40)
    print()
