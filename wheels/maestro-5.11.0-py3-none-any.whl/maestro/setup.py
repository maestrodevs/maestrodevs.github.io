"""
maestro/setup.py — Prerequisite validation and interactive setup wizard.

Provides:
  - PrereqCheck dataclass
  - 8 validator functions
  - run_all_checks() -> list[PrereqCheck]
  - format_check_report(results, verbose=False) -> str
  - interactive_setup()
  - check_mode_exit_code(results) -> int
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Literal

from maestro.personas import current_persona
from maestro.workspace import MSO_DIR_NAME, find_workspace_dir


StatusT = Literal["OK", "WARN", "FAIL"]


@dataclass
class PrereqCheck:
    name: str
    status: StatusT
    message: str
    remediation: str = ""
    repair_fn: Callable[[], None] | None = field(default=None, repr=False)


# ---------------------------------------------------------------------------
# Validators
# ---------------------------------------------------------------------------

def check_python_version() -> PrereqCheck:
    if sys.version_info >= (3, 9):
        return PrereqCheck(
            name="python_version",
            status="OK",
            message=f"Python {sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
        )
    vi = sys.version_info
    major, minor = (vi[0], vi[1]) if isinstance(vi, tuple) else (vi.major, vi.minor)
    return PrereqCheck(
        name="python_version",
        status="FAIL",
        message=f"Python {major}.{minor} — 3.9+ required",
        remediation="Upgrade Python: https://www.python.org/downloads/",
    )


def check_claude_cli() -> PrereqCheck:
    if sys.platform == "win32" and shutil.which("claude") is None:
        return PrereqCheck(
            name="claude_cli",
            status="FAIL",
            message="Claude Code CLI not found (Windows requires WSL2)",
            remediation=(
                "Install WSL2 then install Claude Code inside it:\n"
                "  wsl --install\n"
                "  npm install -g @anthropic-ai/claude-code"
            ),
        )
    if shutil.which("claude") is None:
        return PrereqCheck(
            name="claude_cli",
            status="FAIL",
            message="Claude Code CLI not found on PATH",
            remediation="npm install -g @anthropic-ai/claude-code  (requires Node 18+)",
        )
    # On Windows, the npm-installed `claude` is a .CMD shim. subprocess.run with
    # a bare ["claude", ...] argv triggers CreateProcess, which does NOT consult
    # PATHEXT and fails with [WinError 2]. Resolving via shutil.which first hands
    # subprocess the actual .CMD path and works cross-platform.
    claude_path = shutil.which("claude") or "claude"
    try:
        result = subprocess.run(
            [claude_path, "--version"],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode == 0:
            version = (result.stdout.strip() or result.stderr.strip()).splitlines()[0]
            return PrereqCheck(
                name="claude_cli",
                status="OK",
                message=f"Claude Code {version}",
            )
    except Exception:
        pass
    return PrereqCheck(
        name="claude_cli",
        status="FAIL",
        message="Claude Code CLI found but did not respond to --version",
        remediation="Try: npm install -g @anthropic-ai/claude-code",
    )


def check_git() -> PrereqCheck:
    if shutil.which("git") is None:
        return PrereqCheck(
            name="git",
            status="FAIL",
            message="git not found on PATH",
            remediation="Install Git: https://git-scm.com/downloads",
        )
    try:
        result = subprocess.run(
            ["git", "--version"],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode == 0:
            version = result.stdout.strip()
            return PrereqCheck(name="git", status="OK", message=version)
    except Exception:
        pass
    return PrereqCheck(
        name="git",
        status="FAIL",
        message="git found but did not respond",
        remediation="Reinstall Git: https://git-scm.com/downloads",
    )


def check_gh_cli() -> PrereqCheck:
    if shutil.which("gh") is None:
        return PrereqCheck(
            name="gh_cli",
            status="WARN",
            message="GitHub CLI (gh) not found — required for PR workflows",
            remediation="Install gh: https://cli.github.com/",
        )
    try:
        result = subprocess.run(
            ["gh", "--version"],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode == 0:
            version = result.stdout.strip().splitlines()[0]
            # Check auth status
            auth = subprocess.run(
                ["gh", "auth", "status"],
                capture_output=True, text=True, timeout=10,
            )
            if auth.returncode != 0:
                return PrereqCheck(
                    name="gh_cli",
                    status="WARN",
                    message=f"{version} — not authenticated",
                    remediation="Run: gh auth login",
                )
            return PrereqCheck(name="gh_cli", status="OK", message=version)
    except Exception:
        pass
    return PrereqCheck(
        name="gh_cli",
        status="WARN",
        message="gh found but did not respond",
        remediation="Reinstall gh: https://cli.github.com/",
    )


def check_anthropic_auth() -> PrereqCheck:
    if os.environ.get("ANTHROPIC_API_KEY"):
        return PrereqCheck(
            name="anthropic_auth",
            status="OK",
            message="ANTHROPIC_API_KEY set",
        )
    # Claude Code subscription auth is also valid — we can't probe it
    # directly, but if claude CLI is available we assume it may be logged in.
    if shutil.which("claude") is not None:
        return PrereqCheck(
            name="anthropic_auth",
            status="OK",
            message="Claude Code subscription auth (no ANTHROPIC_API_KEY — crews use subscription billing)",
        )
    return PrereqCheck(
        name="anthropic_auth",
        status="WARN",
        message="No ANTHROPIC_API_KEY and Claude Code CLI not found",
        remediation=(
            "Set API key: export ANTHROPIC_API_KEY=sk-ant-...\n"
            "  or install Claude Code: npm install -g @anthropic-ai/claude-code"
        ),
    )


def check_workspace_scaffold() -> PrereqCheck:
    mso = find_workspace_dir(Path.cwd())
    if mso is not None:
        ws_json = mso / "config" / "workspace.json"
        if not ws_json.exists():
            return PrereqCheck(
                name="workspace_scaffold",
                status="WARN",
                message=f"{MSO_DIR_NAME}/ found at {mso.parent} but workspace.json is missing",
                remediation="Run: mso init --project <PRJ>",
            )
        return PrereqCheck(
            name="workspace_scaffold",
            status="OK",
            message=f"Workspace at {mso}",
        )

    def _repair():
        from maestro.init import scaffold_workspace
        try:
            project = input("    Project acronym (e.g. PSG): ").strip().upper()
        except EOFError:
            project = ""
        if not project:
            print("    No project acronym supplied — skipping scaffold.")
            return
        scaffold_workspace(project, Path.cwd())

    return PrereqCheck(
        name="workspace_scaffold",
        status="FAIL",
        message="No Maestro workspace (.mso/) found in current directory or any parent",
        remediation="Run: mso init --project <PRJ>",
        repair_fn=_repair,
    )


# ---------------------------------------------------------------------------
# Aggregator
# ---------------------------------------------------------------------------

def check_repo_config() -> PrereqCheck:
    """Warn when projects.json / workspace.json still hold placeholder values."""
    mso_dir = _find_mso_dir()
    if mso_dir is None:
        return PrereqCheck(
            name="repo_config",
            status="OK",
            message="No .mso/ workspace found — skipping repo config check",
        )

    from maestro.core.fleet_runner import validate_placeholder_repo_config
    errors = validate_placeholder_repo_config()
    if errors:
        detail = "; ".join(errors[:2])
        return PrereqCheck(
            name="repo_config",
            status="WARN",
            message=f"Placeholder repo config detected: {detail}",
            remediation=(
                "Edit .mso/config/workspace.json and .mso/config/projects.json, "
                "then re-run `mso setup --check`."
            ),
        )
    return PrereqCheck(name="repo_config", status="OK", message="Repo config looks real")


def check_unsigned_acl_manifest() -> PrereqCheck:
    """8th validator (FTR-MSO-2026-0482, plan §7.4/§7.5): in a GOVERNED
    (enforce-mode) workspace only, FAIL when identity records exist but the
    integrity manifest is missing or unsigned. Never fires at community, pro,
    or an ungoverned team/enterprise workspace — those have no manifest to
    sign, and this check's whole precondition is governed-enforce mode."""
    mso_dir = _find_mso_dir()
    if mso_dir is None:
        return PrereqCheck(
            name="acl_signed",
            status="OK",
            message="No .mso/ workspace found — skipping unsigned-ACL check",
        )

    ws_root = mso_dir.parent
    from maestro.governance import resolve_governed_mode
    mode = resolve_governed_mode(ws_root)
    if mode != "enforce":
        return PrereqCheck(
            name="acl_signed",
            status="OK",
            message=f"Governed mode is {mode!r} — unsigned-ACL check only applies in 'enforce' mode",
        )

    identity_dir = mso_dir / "identity"
    has_identity_records = identity_dir.is_dir() and any(
        p for p in identity_dir.rglob("*.json") if p.name != "integrity.json"
    )
    if not has_identity_records:
        return PrereqCheck(
            name="acl_signed",
            status="OK",
            message="Governed workspace has no identity records yet — nothing to sign",
        )

    from maestro.identity.integrity import manifest_is_signed
    if not manifest_is_signed(identity_dir):
        return PrereqCheck(
            name="acl_signed",
            status="FAIL",
            message=f"Identity integrity manifest at {identity_dir / 'integrity.json'} is "
                    "missing or UNSIGNED in a governed (enforce) workspace — the ACL is "
                    "untrusted until re-signed (§7.4).",
            remediation="Run `mso identity sign-acl --key-id <id> --key-file <path>` "
                        "(or set MAESTRO_IDENTITY_SIGNING_KEY) with the org's off-client "
                        "Ed25519 seed to produce a trusted signed manifest.",
        )
    return PrereqCheck(
        name="acl_signed",
        status="OK",
        message="Identity integrity manifest is signed",
    )


def run_all_checks() -> list[PrereqCheck]:
    return [
        check_python_version(),
        check_claude_cli(),
        check_git(),
        check_gh_cli(),
        check_anthropic_auth(),
        check_workspace_scaffold(),
        check_repo_config(),
        check_unsigned_acl_manifest(),
    ]


# ---------------------------------------------------------------------------
# Formatting
# ---------------------------------------------------------------------------

_STATUS_SYMBOLS = {"OK": "✓", "WARN": "⚠", "FAIL": "✗"}
_STATUS_LABELS = {"OK": "OK  ", "WARN": "WARN", "FAIL": "FAIL"}

# ANSI colour codes (disabled on Windows without ENABLE_VIRTUAL_TERMINAL_PROCESSING
# or when not a TTY — callers that need plain output pass colour=False).
_COLOURS = {
    "OK": "\033[32m",    # green
    "WARN": "\033[33m",  # yellow
    "FAIL": "\033[31m",  # red
    "RESET": "\033[0m",
}

def _colour_supported() -> bool:
    return sys.stdout.isatty() and os.environ.get("NO_COLOR") is None


def format_check_report(results: list[PrereqCheck], verbose: bool = False) -> str:
    use_colour = _colour_supported()
    lines: list[str] = []
    for r in results:
        sym = _STATUS_SYMBOLS[r.status]
        label = _STATUS_LABELS[r.status]
        if use_colour:
            c = _COLOURS[r.status]
            reset = _COLOURS["RESET"]
            prefix = f"{c}{sym} [{label}]{reset}"
        else:
            prefix = f"{sym} [{label}]"
        lines.append(f"  {prefix}  {r.name}: {r.message}")
        if verbose and r.remediation and r.status != "OK":
            for rem_line in r.remediation.splitlines():
                lines.append(f"             {rem_line}")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Exit-code helper
# ---------------------------------------------------------------------------

def check_mode_exit_code(results: list[PrereqCheck]) -> int:
    """0=all OK, 1=any FAIL, 2=any WARN (no FAIL), 3=internal error."""
    try:
        statuses = {r.status for r in results}
        if "FAIL" in statuses:
            return 1
        if "WARN" in statuses:
            return 2
        return 0
    except Exception:
        return 3


# ---------------------------------------------------------------------------
# Interactive wizard
# ---------------------------------------------------------------------------

def _find_mso_dir() -> Path | None:
    """Walk up from cwd looking for a Maestro workspace (.mso/)."""
    return find_workspace_dir(Path.cwd())


@dataclass
class SetupContext:
    """Shared state threaded through a wizard run (FTR-MSO-2026-0478).

    ``tier`` is resolved ONCE, at entry, via ``licence.resolve_state()`` —
    read only; nothing in the wizard sets, caches, or infers a tier (§3.2a
    rule 2). ``results`` / ``analysis`` let later steps (e.g. the cheatsheet)
    see earlier steps' findings without relying on ``locals()`` inspection.
    """

    tier: str
    non_interactive: bool = False
    profile_path: "str | None" = None
    answers: dict = field(default_factory=dict)
    licence_state: "object | None" = None
    results: list = field(default_factory=list)
    analysis: "object | None" = None
    errors: list = field(default_factory=list)

    def fail(self, message: str) -> None:
        self.errors.append(message)


@dataclass
class SetupStep:
    """One entry in the wizard's step registry.

    ``applies_to`` is a tier predicate: ``None`` means every tier (the six
    original steps — §3.3), a ``set[str]`` restricts the step to those
    tiers. Community never resolves an enrolment profile or sees a licence
    prompt because neither step's ``applies_to`` includes ``"community"`` —
    enforced structurally here, not by a runtime branch inside the step.
    """

    key: str
    title: str
    run: "Callable[[SetupContext], None]"
    applies_to: "set[str] | None" = None


def _parse_answers_file(path: "str | Path") -> dict:
    """Parse a flat ``KEY=VALUE`` answers file for ``mso setup --answers FILE``
    (§3.5 — the third unattended mode, for orgs without an enrolment profile).
    Blank lines and ``#``-comments are skipped.
    """
    p = Path(path)
    if not p.exists():
        print(f"[Maestro] --answers file not found: {p}", file=sys.stderr)
        sys.exit(1)
    answers: dict = {}
    for line in p.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        answers[key.strip()] = value.strip()
    return answers


# ---------------------------------------------------------------------------
# STEP 0 — persona
# ---------------------------------------------------------------------------

def _step_persona(ctx: "SetupContext") -> None:
    print("[STEP 0] Workstation setup — persona\n")
    from maestro.personas import load_persona, reset_persona_cache
    from maestro.personas.loader import builtin_names
    from maestro.personas.resolver import _find_workspace_config

    _p = current_persona()
    env_persona = os.environ.get("MAESTRO_PERSONA", "").strip()
    if env_persona:
        print(f"  Active persona: {_p.id} (set via MAESTRO_PERSONA env var — not changed here)")
    else:
        ws_config = _find_workspace_config()
        if ws_config:
            print(f"  Active persona: {_p.id} (from {ws_config})")
        else:
            print(f"  Active persona: {_p.id} (built-in default)")

        names = builtin_names()
        print(f"\n  Available personas: {', '.join(names)}")
        if not ctx.non_interactive and _ask("  Change persona for this workspace?"):
            print()
            for i, name in enumerate(names, 1):
                try:
                    px = load_persona(name)
                    print(f"    {i}. {name} — {px.vocabulary.get('userTitle', name)}")
                except Exception:
                    print(f"    {i}. {name}")
            raw = input("  Enter persona name or number (blank to skip): ").strip()
            chosen = None
            if raw.isdigit():
                idx = int(raw) - 1
                if 0 <= idx < len(names):
                    chosen = names[idx]
            elif raw in names:
                chosen = raw
            if chosen:
                # Write to the workspace root (found by walking up from cwd),
                # not always cwd — previously a dead `if False:` branch meant
                # this silently landed in cwd whenever `mso setup` ran from a
                # subdirectory (FTR-MSO-2026-0478 §4.4 persona-location bug).
                mso_dir = _find_mso_dir()
                ws_root = mso_dir.parent if mso_dir is not None else Path.cwd()
                config_dir = ws_root / ".maestro" / "config"
                config_dir.mkdir(parents=True, exist_ok=True)
                persona_file = config_dir / "persona.json"
                import json as _json
                persona_file.write_text(_json.dumps({"id": chosen}, indent=2), encoding="utf-8")
                reset_persona_cache()
                _p = current_persona()
                print(f"  ✓ Persona set to '{chosen}' at {persona_file}")
            else:
                print("  (skipped — keeping current persona)")
    print()


# ---------------------------------------------------------------------------
# STEP 1 — prerequisite checks
# ---------------------------------------------------------------------------

def _step_prereqs(ctx: "SetupContext") -> None:
    print("[STEP 1] Prerequisite checks\n")
    results = run_all_checks()
    ctx.results = results
    print(format_check_report(results, verbose=True))
    print()

    for check in results:
        if check.status in ("WARN", "FAIL") and check.remediation:
            print(f"  → {check.name}: {check.remediation}")
            if check.repair_fn and check.status == "FAIL" and not ctx.non_interactive:
                if _ask(f"  Attempt automatic repair for '{check.name}'?"):
                    try:
                        check.repair_fn()
                        print(f"  ✓ Repair attempted. Re-run `mso setup` to verify.")
                    except Exception as exc:
                        print(f"  ✗ Repair failed: {exc}")


# ---------------------------------------------------------------------------
# LICENCE — new in FTR-MSO-2026-0478, pro/team/enterprise only (§3.2a rule 1:
# community never sees a licence prompt, warning, or licence-shaped absence).
# ---------------------------------------------------------------------------

def _step_licence(ctx: "SetupContext") -> None:
    print("\n[LICENCE] Licence\n")
    state = ctx.licence_state
    line = f"  Tier   : {state.effective_tier}"
    if state.downgraded:
        line += f" (downgraded from {state.downgraded_from})"
    print(line)
    if state.expires_at:
        print(f"  Expires: {state.expires_at}")
    if state.warning:
        print(f"  {state.warning}")


# ---------------------------------------------------------------------------
# STEP 2 — project analysis
# ---------------------------------------------------------------------------

def _step_project_analysis(ctx: "SetupContext") -> None:
    print("\n[STEP 2] Project analysis\n")
    try:
        from pathlib import Path as _Path
        from maestro.project_analysis import analyse_project

        analysis = analyse_project(_Path.cwd())
        ctx.analysis = analysis
        print(f"  Language   : {analysis.primary_language}")
        if analysis.secondary_languages:
            print(f"  Also uses  : {', '.join(analysis.secondary_languages)}")
        print(f"  Framework  : {analysis.framework}")
        print(f"  Source root: {analysis.source_root}")
        print(f"  Test layout: {', '.join(analysis.test_layouts) or 'none detected'}")
        print(f"  Docs       : {'README ✓' if analysis.has_readme else 'no README'}"
              f"{', docs/ ✓' if analysis.has_docs_dir else ''}")
        print(f"  CI         : {', '.join(analysis.ci_systems) if analysis.ci_systems else 'none detected'}")
        print(f"  Git        : activity={analysis.recent_activity}, branches={analysis.branch_model}")
    except Exception as exc:
        print(f"  ⚠ Project analysis failed: {exc}")


# ---------------------------------------------------------------------------
# STEP 3 — workspace configuration
# ---------------------------------------------------------------------------

def _configure_workspace(ctx: "SetupContext") -> None:
    """Step 3: confirm/update workspace.json.

    FTR-MSO-2026-0478 §4.4: this step can now WRITE a correction
    (``defaultGitHubOrg``, project acronym) instead of only telling the
    operator to edit the file themselves. The default ("keep as-is") path is
    byte-identical to before — the write path is reached only when the
    operator declines it (or, non-interactively, via ``--answers``).
    """
    import json

    adm_dir = _find_mso_dir()
    if adm_dir is None:
        print("  ⚠ No Maestro workspace (.mso/) found — skipping workspace configuration.")
        print("    Run `mso init --project <PRJ>` first.")
        return

    ws_path = adm_dir / "config" / "workspace.json"
    if ws_path.exists():
        try:
            ws = json.loads(ws_path.read_text(encoding="utf-8"))
            project = ws.get("project", "UNKNOWN")
            print(f"  Current project : {project}")
            print(f"  workspace.json  : {ws_path}")
            if ctx.non_interactive:
                _apply_workspace_answers(ws, ws_path, ctx)
            elif not _ask("  Configuration looks correct. Keep it as-is?", default="y"):
                _edit_workspace_interactively(ws, ws_path)
        except Exception as exc:
            print(f"  ⚠ Could not read workspace.json: {exc}")
    else:
        print("  ⚠ workspace.json not found.")
        print("    Run `mso init --project <PRJ>` to create it.")


def _edit_workspace_interactively(ws: dict, ws_path: Path) -> None:
    """The write path for a "no, it's not right" answer to STEP 3."""
    import json
    try:
        new_project = input(f"  Project acronym [{ws.get('project', '')}]: ").strip()
    except EOFError:
        new_project = ""
    if new_project:
        ws["project"] = new_project.upper()
    try:
        new_org = input(f"  Default GitHub org [{ws.get('defaultGitHubOrg') or ''}]: ").strip()
    except EOFError:
        new_org = ""
    if new_org:
        ws["defaultGitHubOrg"] = new_org
    ws_path.write_text(json.dumps(ws, indent=2) + "\n", encoding="utf-8")
    print(f"  ✓ workspace.json updated at {ws_path}")


def _apply_workspace_answers(ws: dict, ws_path: Path, ctx: "SetupContext") -> None:
    """Non-interactive STEP 3: apply ``--answers`` overrides, or leave as-is."""
    import json
    changed = False
    project_answer = ctx.answers.get("workspace.project")
    if project_answer:
        ws["project"] = str(project_answer).upper()
        changed = True
    org_answer = ctx.answers.get("workspace.defaultGitHubOrg")
    if org_answer:
        ws["defaultGitHubOrg"] = org_answer
        changed = True
    if changed:
        ws_path.write_text(json.dumps(ws, indent=2) + "\n", encoding="utf-8")
        print(f"  ✓ workspace.json updated from --answers at {ws_path}")
    else:
        print("  Configuration kept as-is (non-interactive; no --answers overrides supplied).")


# ---------------------------------------------------------------------------
# STEP 3a — division pack selection (PLAN-PLN-MSO-2026-0449 §6.2, Order 4)
# ---------------------------------------------------------------------------

def _select_pack(ctx: "SetupContext") -> None:
    """Step 3a: tier-filtered division-pack selection (PLAN-PLN-MSO-2026-0449 §6.2).

    Defaults to `sdlc` — byte-identical to a plain init, so this step is a
    no-op at the default answer for every tier (plan §4.1 anti-leak guarantee
    #1). Selectable packs are filtered to what this tier can reach; WITHHELD
    packs are still NAMED ("Also available on Team/Enterprise"), never just
    dropped from the list — a community user should see what they are
    missing, not a shorter list with no explanation.

    Community must never even probe for an enrolment profile (plan §3.2a rule
    1: "must not even stat these paths") — the profile-pin lookup below is
    gated on ``ctx.tier in ("pro", "team", "enterprise")`` (the same
    once-resolved tier every other step uses, §3.2a rule 2) and is skipped
    entirely otherwise, so a community run of this step never mentions a
    profile, licence, or upgrade path.

    ``ctx.non_interactive`` never calls ``input()`` — a supplied
    ``--answers pack.id=...`` overrides the (possibly profile-pinned)
    default when it names a pack selectable at this tier; otherwise the
    default is applied silently, matching ``_apply_workspace_answers``.
    """
    from maestro import auth
    from maestro.packs import apply_pack, describe_pack_scaffold_result, load_all_builtin

    mso_dir = _find_mso_dir()
    if mso_dir is None:
        print("  ⚠ No Maestro workspace (.mso/) found — skipping pack selection.")
        print("    Run `mso init --project <PRJ>` first.")
        return
    base = mso_dir.parent

    packs = sorted(load_all_builtin(), key=lambda p: p.id)
    if not packs:
        print("  ⚠ No division packs found — skipping.")
        return

    hub_tier = ctx.tier in auth.HUB_TIERS
    selectable = [p for p in packs if p.is_free() or hub_tier]
    withheld = [p for p in packs if p not in selectable]
    selectable_ids = {p.id for p in selectable}

    # Enrolment-profile pack pin — only probed at pro/team/enterprise
    # (community: rule 1, above). A broken profile is reported but does not
    # abort the step; this is the pack-selection step, not full profile
    # application (a different order's job — see maestro/enrolment/apply.py).
    pin = None
    if ctx.tier in ("pro", "team", "enterprise"):
        try:
            from maestro.packs import resolve_profile_pack_pin
            pin = resolve_profile_pack_pin(base)
        except Exception as exc:  # noqa: BLE001
            print(f"  ⚠ Could not resolve the enrolment profile's pack pin: {exc}")

    default_id = "sdlc" if "sdlc" in selectable_ids else (selectable[0].id if selectable else "sdlc")
    locked = False
    if pin and pin.get("id"):
        pinned_id = pin["id"]
        if pinned_id in selectable_ids:
            default_id = pinned_id
            locked = bool(pin.get("locked"))
        else:
            print(f"  ⚠ Enrolment profile pins pack '{pinned_id}', which needs a "
                  f"higher tier than this device has — keeping '{default_id}'.")

    print("  Division packs available at your tier:")
    for p in selectable:
        marker = " (default)" if p.id == default_id else ""
        print(f"    • {p.id:<20} {p.description}{marker}")
    if withheld:
        print("\n  Also available on Team/Enterprise:")
        for p in withheld:
            print(f"    • {p.id:<20} {p.description}")

    chosen_id = default_id
    if locked:
        print(f"\n  This workspace is locked to the '{chosen_id}' pack by your "
              f"organisation's enrolment profile.")
    elif ctx.non_interactive:
        answer = ctx.answers.get("pack.id")
        if answer:
            if answer not in selectable_ids:
                print(f"  ✗ '{answer}' is not available at your tier — keeping '{chosen_id}'.")
            else:
                chosen_id = answer
    elif not _ask(f"\n  Apply the '{chosen_id}' pack?", default="y"):
        print("  Enter pack id (blank to keep default): ", end="", flush=True)
        try:
            raw = input().strip()
        except EOFError:
            raw = ""
        if raw:
            if raw not in selectable_ids:
                print(f"  ✗ '{raw}' is not available at your tier — keeping '{chosen_id}'.")
            else:
                chosen_id = raw

    pack = next(p for p in packs if p.id == chosen_id)
    preview = apply_pack(pack, base, dry_run=True)
    if not preview.changed():
        print(f"\n  Pack '{pack.id}' contributes nothing beyond the current workspace — no changes.")
        return

    print(f"\n  Preview — pack '{pack.id}' would change:")
    for line in describe_pack_scaffold_result(pack, preview):
        print(f"    {line}")
    apply_pack(pack, base)
    print(f"\n  ✓ Pack '{pack.id}' applied.")


# ---------------------------------------------------------------------------
# PROFILE — new in FTR-MSO-2026-0478, pro/team/enterprise only. LOOKUP only:
# precedence resolution + detection, mirroring governance.distribution's
# _resolve_url shape. Actual application (workspace/governance/trustedKeys/
# secrets/identity) is the ENTERPRISE step below (FTR-MSO-2026-0482,
# team/enterprise only) — pro still stops at "detected" here (§3.2a: pro
# gets the core wizard + optional profile lookup, not the enterprise steps).
# ---------------------------------------------------------------------------

_ENROLMENT_PROFILE_ENV = "MAESTRO_ENROLMENT_PROFILE"


def _resolve_enrolment_profile_path(ctx: "SetupContext") -> "tuple[str | None, str]":
    """Precedence chain (§3.3): --profile > env var > ~/.maestro/enrolment.json
    > .mso/config/enrolment.json > none. Never called for community — gated
    structurally by this step's ``applies_to``, so community performs no
    filesystem/env probe at all (§12 AC)."""
    if ctx.profile_path:
        return str(ctx.profile_path), "--profile"
    env = os.environ.get(_ENROLMENT_PROFILE_ENV, "").strip()
    if env:
        return env, _ENROLMENT_PROFILE_ENV
    from maestro.workspace import maestro_home_file
    home_profile = maestro_home_file("enrolment.json")
    if home_profile.exists():
        return str(home_profile), "~/.maestro/enrolment.json"
    adm_dir = _find_mso_dir()
    if adm_dir is not None:
        ws_profile = adm_dir / "config" / "enrolment.json"
        if ws_profile.exists():
            return str(ws_profile), f"{MSO_DIR_NAME}/config/enrolment.json"
    return None, ""


def _step_profile_lookup(ctx: "SetupContext") -> None:
    print("\n[PROFILE] Enrolment profile\n")
    path, source = _resolve_enrolment_profile_path(ctx)
    if path is None:
        if ctx.tier == "enterprise":
            print(
                "  ⚠ No enrolment profile found — running ungoverned. An Enterprise "
                "device should have one; see maestro/docs/ENTERPRISE-SETUP.md."
            )
        else:
            print(
                "  No enrolment profile found — core setup only. An admin-authored "
                "profile can automate the rest."
            )
        return
    print(f"  Profile detected: {path} (via {source})")
    if ctx.tier in ("team", "enterprise"):
        print("  Applying enterprise settings from the profile next (secrets, identity, governance)…")
    else:
        print(
            "  This tier does not apply enrolment-profile settings automatically "
            "(only team/enterprise do) — detected only."
        )


# ---------------------------------------------------------------------------
# ENTERPRISE SECURITY — new in FTR-MSO-2026-0482, team/enterprise only.
# Applies the resolved+verified enrolment profile (workspace/governance/
# trustedKeys/secrets — maestro.enrolment.apply.apply_profile) and, when the
# profile requests it, seeds identity (maybe_seed_identity). §3.2a: these
# steps are appended only when a profile actually resolves — an absent
# profile is a silent no-op here (profile_lookup already printed the
# pointer/warning above), never a half-configured governance state (§4.2
# team guarantee: zero governance.* keys written when no profile is found).
# ---------------------------------------------------------------------------

def _step_enterprise_security(ctx: "SetupContext") -> None:
    from maestro.enrolment.loader import resolve_profile
    from maestro.enrolment.schema import EnrolmentError
    from maestro.enrolment.apply import apply_profile, maybe_seed_identity, ApplyError
    from maestro.governance.schema import GovernanceError

    adm_dir = _find_mso_dir()
    ws_root = adm_dir.parent if adm_dir is not None else Path.cwd()

    try:
        resolved = resolve_profile(source=ctx.profile_path, workspace=ws_root)
    except (EnrolmentError, GovernanceError) as exc:
        msg = f"enrolment profile rejected: {exc}"
        print(f"\n[ENTERPRISE] ✗ {msg}")
        ctx.fail(msg)
        return

    if resolved is None:
        return  # no profile found — core setup only, nothing to apply (§4.2)

    profile = resolved.profile
    print(f"\n[ENTERPRISE] Applying enrolment profile '{profile.bundle_id}' (source: {resolved.source})\n")

    try:
        apply_profile(profile, workspace=ws_root, current_tier=ctx.tier)
    except (ApplyError, EnrolmentError) as exc:
        msg = f"enrolment profile '{profile.bundle_id}' refused: {exc}"
        print(f"  ✗ {msg}")
        ctx.fail(msg)
        return

    print("  ✓ Profile applied to workspace.json.")

    if profile.secrets:
        print("\n  Secrets provider configured from profile — running `mso secrets doctor`:")
        from maestro.cli import _secrets_doctor
        try:
            _secrets_doctor(ws_root)
        except SystemExit as exc:
            code = exc.code if isinstance(exc.code, int) else 1
            if code != 0:
                print(f"  ⚠ secrets doctor reported issues (exit {code}) — see above.")

    try:
        seed_result = maybe_seed_identity(profile, workspace=ws_root)
    except Exception as exc:  # noqa: BLE001 — never abort the wizard on this optional step
        print(f"\n  ⚠ Identity seeding failed: {exc}")
        seed_result = None
    if seed_result is not None:
        print(f"\n  ✓ Identity seeded at {seed_result['identity_dir']}.")


# ---------------------------------------------------------------------------
# STEP 4 — requirement templates
# ---------------------------------------------------------------------------

def _offer_template_generation(ctx: "SetupContext") -> None:
    """Step 4: offer to generate a starter order from a requirement template."""
    import datetime

    from maestro.templates_loader import (
        list_builtin_templates,
        list_custom_templates,
        render_template,
    )

    adm_dir = _find_mso_dir()
    if adm_dir is None:
        print("  ⚠ No Maestro workspace (.mso/) found — skipping template generation.")
        return

    builtin = list_builtin_templates()
    custom = list_custom_templates(adm_dir)
    all_templates = builtin + [t for t in custom if t not in builtin]

    print("  Available built-in templates:")
    for name in builtin:
        print(f"    • {name}")
    if custom:
        print("  Custom templates:")
        for name in custom:
            marker = " (overrides built-in)" if name in builtin else ""
            print(f"    • {name}{marker}")

    if ctx.non_interactive or not _ask("\n  Generate a starter order from a template?", default="n"):
        return

    print("\n  Enter template name (or press Enter to skip): ", end="", flush=True)
    try:
        chosen = input().strip()
    except EOFError:
        chosen = ""

    if not chosen:
        return

    if chosen not in all_templates:
        print(f"  ✗ Unknown template '{chosen}'. Skipping.")
        return

    # Collect minimal fields
    print(f"\n  Filling in '{chosen}' template fields (press Enter to use placeholder):\n")
    def _field(label: str, placeholder: str = "TBD") -> str:
        try:
            val = input(f"    {label} [{placeholder}]: ").strip()
        except EOFError:
            val = ""
        return val or placeholder

    title = _field("Title", "New order title")
    scope = _field("Scope / affected component", "TBD")
    background = _field("Background", "TBD")
    notes = _field("Additional notes", "")

    # Derive type from template name
    _type_map = {
        "new-feature": "FTR",
        "project-setup": "FTR",
        "security-review": "SEC",
        "test-coverage": "FTR",
        "doc-audit": "DOC",
        "bug-report": "BUG",
        "performance": "FTR",
        "refactor": "FTR",
    }
    order_type = _type_map.get(chosen, "FTR")

    # Determine project and next sequence
    import json as _json
    project = "PRJ"
    ws_path = adm_dir / "config" / "workspace.json"
    if ws_path.exists():
        try:
            ws = _json.loads(ws_path.read_text(encoding="utf-8"))
            project = ws.get("project", "PRJ")
        except Exception:
            pass

    year = datetime.datetime.now().year
    proposed_dir = adm_dir / "queues" / "proposed"
    proposed_dir.mkdir(parents=True, exist_ok=True)
    existing = sorted(proposed_dir.glob(f"*-{project}-{year}-*.md"))
    seq = len(existing) + 1
    order_id = f"{order_type}-{project}-{year}-{seq:04d}"

    context = {
        "order_id": order_id,
        "title": title,
        "scope": scope,
        "background": background,
        "notes": notes,
    }

    try:
        rendered = render_template(chosen, context, adm_dir)
    except Exception as exc:
        print(f"  ✗ Render failed: {exc}")
        return

    out_path = proposed_dir / f"{order_id}.md"
    out_path.write_text(rendered, encoding="utf-8")
    print(f"\n  ✓ Starter order written to: {out_path}")
    print("    Review and edit it, then use `mso order` to promote it to the queue.")


def _ask(prompt: str, default: str = "y") -> bool:
    """Prompt yes/no; returns True for yes."""
    indicator = "[Y/n]" if default.lower() == "y" else "[y/N]"
    try:
        answer = input(f"{prompt} {indicator}: ").strip().lower()
    except EOFError:
        return default.lower() == "y"
    if not answer:
        return default.lower() == "y"
    return answer in ("y", "yes")


# ---------------------------------------------------------------------------
# STEP 5 — contextual next-steps cheatsheet
# ---------------------------------------------------------------------------

def _step_next_steps(ctx: "SetupContext") -> None:
    # BUG fixed via Copilot review on PR #67: previous wizard never surfaced
    # the cheatsheet rules from FTR-ADM-2026-0110, so operators saw zero
    # contextual guidance after setup. Now we always print it before signing off.
    print("\n[STEP 5] Suggested next steps\n")
    try:
        from maestro.setup_cheatsheet import generate_cheatsheet
        print(generate_cheatsheet(ctx.analysis, ctx.results))
    except Exception as exc:
        print(f"  ⚠ Cheatsheet generation failed: {exc}")


def _step_workspace_config(ctx: "SetupContext") -> None:
    print("\n[STEP 3] Workspace configuration\n")
    _configure_workspace(ctx)


def _step_pack_selection(ctx: "SetupContext") -> None:
    print("\n[STEP 3a] Division pack selection\n")
    _select_pack(ctx)


def _step_templates(ctx: "SetupContext") -> None:
    print("\n[STEP 4] Requirement templates\n")
    _offer_template_generation(ctx)


# ---------------------------------------------------------------------------
# The step registry (FTR-MSO-2026-0478 §3.3).
#
# The six original steps carry ``applies_to=None`` (every tier) and are
# provably byte-identical in content and order to pre-refactor `main` — each
# still prints its own hardcoded "[STEP N]" header exactly as before. LICENCE,
# PROFILE, and ENTERPRISE_SECURITY are new, tier-restricted, and use distinct
# (non-numeric) headers, so they never renumber or otherwise perturb the
# original six.
#
# PACK_SELECTION (FTR-MSO-2026-0480, PLAN-PLN-MSO-2026-0449 §6.2) is also new
# but, unlike LICENCE/PROFILE/ENTERPRISE_SECURITY, carries ``applies_to=None``
# — every tier, including community, sees this step by design: a community
# user should see what division packs they are missing, not a shorter step
# list with no explanation (§6.2). It is byte-identical to a no-op at its
# default answer ('sdlc') for every tier (plan §4.1 anti-leak guarantee #1),
# and never itself probes for an enrolment profile at community tier (§3.2a
# rule 1 — delegated to ``_select_pack``'s own tier gate). Community's
# filtered step list is therefore the original six PLUS this one, in the
# order below — the golden-transcript no-regression guarantee for the
# original six's own content/order still falls out of this structure.
# ---------------------------------------------------------------------------

SETUP_STEPS: "list[SetupStep]" = [
    SetupStep("persona", "Workstation setup — persona", _step_persona, applies_to=None),
    SetupStep("prereqs", "Prerequisite checks", _step_prereqs, applies_to=None),
    SetupStep("licence", "Licence", _step_licence, applies_to={"pro", "team", "enterprise"}),
    SetupStep("project_analysis", "Project analysis", _step_project_analysis, applies_to=None),
    SetupStep("workspace_config", "Workspace configuration", _step_workspace_config, applies_to=None),
    SetupStep("pack_selection", "Division pack selection", _step_pack_selection, applies_to=None),
    SetupStep("profile_lookup", "Enrolment profile", _step_profile_lookup, applies_to={"pro", "team", "enterprise"}),
    SetupStep("enterprise_security", "Enterprise security onboarding", _step_enterprise_security, applies_to={"team", "enterprise"}),
    SetupStep("templates", "Requirement templates", _step_templates, applies_to=None),
    SetupStep("next_steps", "Suggested next steps", _step_next_steps, applies_to=None),
]


def interactive_setup(
    *,
    profile: "str | None" = None,
    non_interactive: bool = False,
    answers: "dict | None" = None,
) -> None:
    """Run the setup wizard.

    FTR-MSO-2026-0478: tier is resolved ONCE here, via
    ``licence.resolve_state()`` — read only (§3.2a rule 2) — and then used to
    filter :data:`SETUP_STEPS` by ``applies_to``. A STOPPED licence (Team/
    Enterprise past its 14-day grace, §D3b) refuses before any step runs,
    matching ``auth.check()``'s existing behaviour.

    ``non_interactive=True`` must never call ``input()`` — every step that
    would otherwise prompt is gated on this flag instead.
    """
    from maestro import __version__
    from maestro.licence import resolve_state

    _p = current_persona()

    print(f"\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print(f" {_p.term('product')} Setup Wizard — v{__version__}")
    print(f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n")

    state = resolve_state()
    if state.stopped:
        print(state.warning or f"Maestro {state.tier} licence STOPPED.")
        sys.exit(1)

    ctx = SetupContext(
        tier=state.effective_tier,
        non_interactive=non_interactive,
        profile_path=profile,
        answers=answers or {},
        licence_state=state,
    )

    for step in SETUP_STEPS:
        if step.applies_to is not None and ctx.tier not in step.applies_to:
            continue
        step.run(ctx)

    if ctx.errors:
        print("\n[Maestro] Setup could not complete non-interactively:")
        for err in ctx.errors:
            print(f"  ✗ {err}")
        sys.exit(1)

    print(f"\nSetup complete. Run `mso status` to see your {_p.term('team').lower()}.")
