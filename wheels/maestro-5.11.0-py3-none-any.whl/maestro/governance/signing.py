"""
Signed-bundle orchestration — verify + anti-rollback + freshness, in one place.

FTR-MSO-2026-0397 (PLAN-PLN-MSO-2026-0372 §3.4, §3.5).

Ties together the three Phase-2 primitives:

  * :mod:`maestro.governance.verify`   — Ed25519 detached-signature math
  * :mod:`maestro.governance.keys`     — pinned vendor/org key resolution + rotation
  * :mod:`maestro.governance.rollback` — monotonic version floor + offline freshness

Structural model: ``maestro/licence/storage.py`` (canonical-JSON payload + detached
signature + verify-before-use). A *signed bundle* is an ordinary policy bundle JSON
with one extra envelope field::

    "signature": {
        "algorithm": "ed25519",
        "keyId": "acme-2026-q3",
        "value": "<base64 Ed25519 signature over the canonical, signature-stripped payload>"
    }

Phase-1 (unsigned, SHA-256-manifest) bundles have no ``signature`` field and flow
through untouched — non-Enterprise workspaces keep exactly the Phase-1 behaviour
(AC4). Verification is triggered ONLY by the presence of the envelope (or an
explicit ``require_signature``).
"""
from __future__ import annotations

import base64
import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from maestro.governance.schema import GovernanceError
from maestro.governance import verify as _verify
from maestro.governance import keys as _keys
from maestro.governance import rollback as _rollback


@dataclass(frozen=True)
class VerifyOutcome:
    signed: bool
    bundle_id: str = ""
    version: int = 0
    key_id: str = ""
    verified: bool = False       # True once a signature verified OK
    reason: str = ""             # human note (e.g. "unsigned", "verified")
    # BUG-MSO-2026-0528: the anti-rollback ledger is a per-workspace artefact-
    # plane record; a caller with no workspace in scope (e.g. `mso policy
    # verify --bundle FILE` run outside any workspace) can still verify the
    # SIGNATURE, but the rollback check cannot run. rollback_checked is False
    # in exactly that case — never a stand-in for "check passed".
    rollback_checked: bool = True
    rollback_skip_reason: str = ""


def is_signed(bundle: dict[str, Any]) -> bool:
    return isinstance(bundle.get(_verify.SIGNATURE_FIELD), dict)


def _extract_envelope(bundle: dict[str, Any]) -> tuple[str, str, bytes]:
    """Return (algorithm, keyId, signature_bytes) from the signature envelope."""
    env = bundle.get(_verify.SIGNATURE_FIELD)
    if not isinstance(env, dict):
        raise GovernanceError("bundle has no signature envelope")
    algo = env.get("algorithm", "ed25519")
    if algo != _verify.ALGORITHM:
        raise GovernanceError(f"unsupported signature algorithm '{algo}'")
    key_id = env.get("keyId") or bundle.get("issuer") or ""
    if not key_id:
        raise GovernanceError("signature envelope missing 'keyId' (and no 'issuer' to fall back on)")
    value = env.get("value")
    if not isinstance(value, str) or not value:
        raise GovernanceError("signature envelope missing base64 'value'")
    try:
        sig = base64.b64decode(value, validate=True)
    except Exception as exc:  # noqa: BLE001
        raise GovernanceError(f"signature 'value' is not valid base64: {exc}") from exc
    if len(sig) != 64:
        raise GovernanceError(f"Ed25519 signature must be 64 bytes, got {len(sig)}")
    return algo, key_id, sig


def verify_signed_bundle(
    bundle: dict[str, Any],
    *,
    workspace: Path | None = None,
    now: Optional[datetime] = None,
    record: bool = True,
    require_signature: bool = False,
    artefact_root: Path | None = None,
) -> VerifyOutcome:
    """Verify a bundle's signature, enforce anti-rollback, and stamp freshness.

    Behaviour:
      * Unsigned bundle + ``require_signature=False`` → returns ``signed=False``
        (Phase-1 pass-through; the caller applies its own policy).
      * Unsigned bundle + ``require_signature=True``  → GovernanceError.
      * Signed bundle → resolve key (rotation-aware) → Ed25519 verify → reject a
        version below the recorded floor (anti-rollback) → record the new floor +
        freshness stamp (when ``record``). Any failure raises GovernanceError, the
        fail-closed signal governed enforce mode denies on.
    """
    now = now or datetime.now(timezone.utc)
    bundle_id = bundle.get("bundleId", "")
    version = bundle.get("version", 0)

    if not is_signed(bundle):
        if require_signature:
            raise GovernanceError(
                f"bundle '{bundle_id or '<unknown>'}' is unsigned but a signature is "
                "required in this workspace (governance.requireSignature)."
            )
        return VerifyOutcome(signed=False, bundle_id=bundle_id,
                             version=version if isinstance(version, int) else 0,
                             reason="unsigned")

    if not isinstance(version, int):
        raise GovernanceError(f"signed bundle '{bundle_id}' has non-integer 'version'")
    if not bundle_id:
        raise GovernanceError("signed bundle missing 'bundleId'")

    _algo, key_id, sig = _extract_envelope(bundle)
    key = _keys.resolve_key(key_id, workspace, now=now)

    if not _verify.verify_bundle(bundle, key.public_key, sig):
        raise GovernanceError(
            f"signature verification FAILED for bundle '{bundle_id}' (keyId={key_id}). "
            "The bundle has been tampered with, or was signed by a different key — "
            "refusing to trust it."
        )

    # Anti-rollback: reject a version below the recorded floor BEFORE recording.
    #
    # BUG-MSO-2026-0528: the ledger lives on the artefact plane and needs a
    # workspace to locate (maestro.workspace.get_artefact_root), but signature
    # verification itself does not — a caller may have named an explicit
    # --bundle FILE with no workspace in scope at all. DESIGN DECISION: shape
    # (a) — verify the signature (which needs no workspace) and report the
    # rollback check as explicitly NOT PERFORMED, rather than (b) requiring a
    # workspace for every verify call. Rejected (b) because --bundle takes a
    # standalone file path, and the CLI-facing 'verify' semantics for that flag
    # imply a pure file check; a security control that silently disappears is
    # far worse than a crash, so this is reported (printed) here, not swallowed.
    rollback_checked = True
    rollback_skip_reason = ""
    try:
        _rollback.check_not_rollback(bundle_id, version, artefact_root)
    except _rollback.NoWorkspaceForRollbackError as exc:
        rollback_checked = False
        rollback_skip_reason = str(exc)
        print(
            f"⚠ anti-rollback check SKIPPED for bundle '{bundle_id}': no Maestro "
            "workspace in scope for the anti-rollback ledger. Signature verified; "
            "the downgrade (rollback) check was NOT performed.",
            file=sys.stderr,
        )
    else:
        if record:
            _rollback.record_version(
                bundle_id, version,
                key_id=key_id,
                verified_at=now,
                expires_at=bundle.get("expiresAt"),
                offline_grace_days=int(bundle.get("offlineGraceDays", 0) or 0),
                artefact_root=artefact_root,
            )

    reason = "verified" if rollback_checked else "verified; rollback check NOT performed (no workspace in scope)"
    return VerifyOutcome(
        signed=True, bundle_id=bundle_id, version=version,
        key_id=key_id, verified=True, reason=reason,
        rollback_checked=rollback_checked, rollback_skip_reason=rollback_skip_reason,
    )


# ---------------------------------------------------------------------------
# Workspace-level pre-dispatch validation
# ---------------------------------------------------------------------------

_WORKSPACE_BUNDLE_RELPATH = ("config", "policy-bundle.json")


def _workspace_bundle_path(workspace: Path) -> Path:
    """Locate the workspace policy bundle (accepts a repo root or the .mso dir)."""
    from maestro.workspace import MSO_DIR_NAME
    ws = Path(workspace)
    for base in (ws / MSO_DIR_NAME, ws):
        candidate = base.joinpath(*_WORKSPACE_BUNDLE_RELPATH)
        if candidate.exists():
            return candidate
    return (ws / MSO_DIR_NAME).joinpath(*_WORKSPACE_BUNDLE_RELPATH)


def require_signature_for(workspace: Path | None, *, enforce: bool = False) -> bool:
    """Whether ``governance.requireSignature`` is set for ``workspace``.

    SEC-FTR-MSO-2026-0397 F4: a corrupt/unreadable workspace.json must NOT
    silently resolve to ``False`` (which would disable the signature requirement).
    In ``enforce`` mode a broken config is a fail-closed integrity signal and
    raises GovernanceError; outside enforce it stays conservative (False) so a
    Phase-1 / non-governed workspace with an unrelated config error is unaffected.
    """
    if workspace is None:
        return False
    from maestro.workspace import MSO_DIR_NAME
    ws = Path(workspace)
    for cfg in (ws / MSO_DIR_NAME / "config" / "workspace.json", ws / "config" / "workspace.json"):
        if cfg.exists():
            try:
                import json
                data = json.loads(cfg.read_text(encoding="utf-8"))
            except Exception as exc:  # noqa: BLE001
                if enforce:
                    raise GovernanceError(
                        f"workspace.json is unreadable ({cfg}): {exc}. In enforce "
                        "mode a broken governance config fails CLOSED — refusing to "
                        "assume signatures are not required."
                    ) from exc
                return False
            return bool((data.get("governance", {}) or {}).get("requireSignature", False))
    return False


def validate_workspace_bundle(
    workspace: Path,
    *,
    enforce: bool,
    now: Optional[datetime] = None,
    artefact_root: Path | None = None,
) -> VerifyOutcome:
    """Pre-dispatch validation of the workspace's distributed policy bundle.

    Called by the dispatcher (``fleet_runner``) before launching a crew in
    governed mode. Semantics:

      * No bundle on disk → nothing to validate (Phase-1 workspaces). Returns
        ``signed=False``.
      * Bundle present + signed → verify signature + anti-rollback + freshness.
        In ``enforce`` a stale (past offline grace) bundle raises.
      * Bundle present but unsigned while ``governance.requireSignature`` is set →
        raises.

    Raises GovernanceError on any tamper / rollback / staleness — the dispatcher
    turns that into a refuse-to-launch (order held).
    """
    now = now or datetime.now(timezone.utc)
    import json

    path = _workspace_bundle_path(workspace)
    require_sig = require_signature_for(workspace, enforce=enforce)
    if not path.exists():
        if require_sig:
            raise GovernanceError(
                "governance.requireSignature is set but no signed policy bundle is "
                f"present at {path}. Run `mso policy pull` to fetch it."
            )
        return VerifyOutcome(signed=False, reason="no-bundle")

    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001
        raise GovernanceError(f"workspace policy bundle unreadable ({path}): {exc}") from exc

    outcome = verify_signed_bundle(
        raw, workspace=workspace, now=now, record=True,
        require_signature=require_sig, artefact_root=artefact_root,
    )

    # Freshness / offline-grace: only meaningful for a signed, expiring bundle.
    if outcome.signed and raw.get("expiresAt"):
        fresh, reason = _rollback.is_fresh(
            outcome.bundle_id, now=now, artefact_root=artefact_root
        )
        if not fresh and enforce:
            raise GovernanceError(
                f"signed bundle '{outcome.bundle_id}' is stale: {reason}. "
                "Re-run `mso policy pull` to refresh it (offline grace exhausted)."
            )

    return outcome


# ---------------------------------------------------------------------------
# Authoring / test helper — sign a bundle (never used by the client runtime)
# ---------------------------------------------------------------------------

def sign_bundle(bundle: dict[str, Any], seed: bytes, key_id: str) -> dict[str, Any]:
    """Attach an Ed25519 ``signature`` envelope to ``bundle`` and return a new dict.

    For maintainers producing vendor packs and for the test suite — signing keys
    live off-client, so this is an authoring convenience, not a runtime path.
    """
    payload = _verify.canonical_payload(bundle)
    sig = _verify.sign(seed, _verify.canonical_bytes(payload))
    signed = dict(payload)
    signed[_verify.SIGNATURE_FIELD] = {
        "algorithm": _verify.ALGORITHM,
        "keyId": key_id,
        "value": base64.b64encode(sig).decode("ascii"),
    }
    return signed
