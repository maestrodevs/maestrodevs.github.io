"""
Admin-side policy-authoring workflows — ``mso policy keygen|init|lint|sign``,
plus the ``enable`` workspace writer.

FTR-MSO-2026-0479 (PLAN-PLN-MSO-2026-0449 Order 3, §5.2-5.4). This is the
authoring half of the Ed25519 signed-bundle story; ``governance/signing.py``
and ``governance/verify.py`` already ship the client-side verify half.

Seed custody mirrors the pattern already shipped for identity-manifest
signing (``maestro.identity.integrity`` — off-client seed, refuse to write
inside a git tree or a ``.mso/`` workspace, supplied only via ``--key-file``
or an env var, never persisted). Per PLAN-PLN-MSO-2026-0449 §5.3 ("copy the
pattern, not the module") and PLAN-PLN-MSO-2026-0450 D2 (isolate trust
roots), the seed-decode helper below is a deliberate small duplication
rather than a cross-package import — this module must not create a
governance→identity dependency, and must never touch
``maestro/licence/keys.py``, which is a separate, vendor-only keyring.
"""
from __future__ import annotations

import base64
import binascii
import json
import os
from pathlib import Path
from typing import Any, Optional

from maestro.governance.schema import GovernanceError, PolicyBundle, VALID_MODES
from maestro.governance import verify as _verify
from maestro.governance.loader import BUILTIN_PACKS

# Env channel carrying the org Ed25519 POLICY-SIGNING SEED (32-byte private
# key) for `mso policy sign`. Distinct from identity's
# MAESTRO_IDENTITY_SIGNING_KEY and from the licence issuer's signing channel —
# three separate trust roots, one shared pattern (§5.3).
SIGNING_SEED_ENV = "MAESTRO_POLICY_SIGNING_KEY"


# ---------------------------------------------------------------------------
# Seed decode (small deliberate duplicate of identity.integrity.decode_seed —
# see module docstring for why this is not shared)
# ---------------------------------------------------------------------------

def _decode_seed(raw: str) -> bytes:
    """Decode a base64 or hex string into a 32-byte Ed25519 signing seed.

    Raises ``ValueError`` on any input that does not resolve to exactly 32
    bytes — a fail-closed signal so a bad seed never silently mis-signs a
    bundle.
    """
    if not isinstance(raw, str) or not raw.strip():
        raise ValueError("signing seed is empty")
    s = raw.strip()
    data: bytes | None = None
    for decoder in (
        lambda: base64.b64decode(s, validate=True),
        lambda: base64.urlsafe_b64decode(s + "=" * (-len(s) % 4)),
        lambda: bytes.fromhex(s),
    ):
        try:
            candidate = decoder()
        except (binascii.Error, ValueError):
            continue
        if len(candidate) == 32:
            data = candidate
            break
    if data is None:
        raise ValueError("signing seed must decode (base64 or hex) to exactly 32 bytes")
    return data


# ---------------------------------------------------------------------------
# Keygen — off-client Ed25519 seed generation
# ---------------------------------------------------------------------------

def refuse_if_protected(path: Path) -> None:
    """Raise GovernanceError if *path* resolves inside a git working tree or a
    ``.mso/`` workspace. A signing seed must never land in either — both are
    locations anyone with repo/workspace access (including a dispatched crew)
    can read.
    """
    resolved = Path(path).resolve()

    from maestro.workspace import find_workspace_dir
    if find_workspace_dir(resolved) is not None:
        raise GovernanceError(
            f"refusing to write a signing seed inside a .mso/ workspace ({resolved}) — "
            "pass --out pointing somewhere outside any Maestro workspace (e.g. ~/keys/)."
        )

    for candidate in [resolved, *resolved.parents]:
        if (candidate / ".git").exists():
            raise GovernanceError(
                f"refusing to write a signing seed inside a git working tree ({resolved}, "
                f"repo root {candidate}) — pass --out pointing somewhere outside any repo."
            )


def generate_keypair() -> tuple[bytes, bytes]:
    """Generate a fresh Ed25519 ``(seed, public_key)`` pair. ``os.urandom`` is
    the platform CSPRNG — no extra dependency, matching ``verify.py``'s
    zero-new-dependency discipline.
    """
    seed = os.urandom(32)
    public_key = _verify.public_key_from_seed(seed)
    return seed, public_key


def write_seed_file(out_dir: Path, key_id: str, seed: bytes) -> Path:
    """Write *seed* (base64) to ``<out_dir>/<key_id>.seed`` at mode 0600.

    Refuses (via :func:`refuse_if_protected`) when *out_dir* is inside a git
    working tree or a ``.mso/`` workspace.
    """
    refuse_if_protected(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    seed_path = out_dir / f"{key_id}.seed"
    seed_path.write_text(base64.b64encode(seed).decode("ascii") + "\n", encoding="utf-8")
    try:
        seed_path.chmod(0o600)
    except OSError:
        pass  # best-effort — limited effect on Windows
    return seed_path


def resolve_signing_seed(
    key_file: "str | Path | None" = None,
    env: "dict | None" = None,
) -> bytes:
    """Resolve the org Ed25519 policy-signing seed from a file or the env
    channel. Resolution order: ``--key-file`` > ``MAESTRO_POLICY_SIGNING_KEY``.
    """
    env = env if env is not None else os.environ
    if key_file is not None:
        p = Path(key_file)
        if not p.exists():
            raise ValueError(f"signing key file not found: {p}")
        return _decode_seed(p.read_text(encoding="utf-8"))

    raw = env.get(SIGNING_SEED_ENV, "")
    if raw.strip():
        return _decode_seed(raw)

    raise ValueError(
        "no signing seed provided — pass --key-file PATH or set "
        f"{SIGNING_SEED_ENV} to the org Ed25519 seed (base64 or hex, 32 bytes)"
    )


# ---------------------------------------------------------------------------
# init / lint — draft an unsigned bundle, optionally from built-in packs
# ---------------------------------------------------------------------------

def _library_dir() -> Path:
    return Path(__file__).resolve().parent / "library"


def _builtin_bundle_dict(name: str) -> dict[str, Any]:
    """Load one built-in pack's raw JSON by its file stem (e.g. 'protected-branch')."""
    filename = f"{name}.json"
    path = _library_dir() / filename
    if filename not in BUILTIN_PACKS or not path.exists():
        available = ", ".join(sorted(p.removesuffix(".json") for p in BUILTIN_PACKS))
        raise GovernanceError(f"unknown built-in pack '{name}'. Available: {available}")
    return json.loads(path.read_text(encoding="utf-8"))


def draft_bundle(
    bundle_id: str,
    *,
    from_packs: "list[str] | None" = None,
    governed_mode: str = "enforce",
    default_action: str = "allow",
) -> dict[str, Any]:
    """Build an unsigned draft bundle dict, optionally merging rules from named
    built-in packs. Duplicate rule ids across sources are left for
    :func:`lint_bundle` to catch — schema validation already refuses them.
    """
    if governed_mode not in VALID_MODES:
        raise GovernanceError(f"governedMode must be one of {VALID_MODES}, got {governed_mode!r}")
    rules: list[dict[str, Any]] = []
    for name in from_packs or []:
        name = name.strip()
        if not name:
            continue
        rules.extend(_builtin_bundle_dict(name).get("rules", []))
    return {
        "schemaVersion": "1.0",
        "bundleId": bundle_id,
        "version": 1,
        "issuer": "",
        "tier": "org",
        "governedMode": governed_mode,
        "defaultAction": default_action,
        "rules": rules,
    }


def lint_bundle(raw: dict[str, Any]) -> PolicyBundle:
    """Schema-validate an unsigned draft bundle. Raises GovernanceError on any
    structural problem — same validator the runtime loader uses, so a draft
    that lints clean is guaranteed loadable.
    """
    return PolicyBundle.from_dict(raw)


# ---------------------------------------------------------------------------
# enable — write governance.governedMode into workspace.json (idempotent)
# ---------------------------------------------------------------------------

def _workspace_json_path(workspace: Path) -> Path:
    from maestro.workspace import MSO_DIR_NAME
    ws = Path(workspace)
    for candidate in (
        ws / MSO_DIR_NAME / "config" / "workspace.json",
        ws / "config" / "workspace.json",
    ):
        if candidate.exists():
            return candidate
    return ws / MSO_DIR_NAME / "config" / "workspace.json"


def write_governed_mode(workspace: Path, mode: str) -> Path:
    """Idempotently set ``governance.governedMode`` in workspace.json.

    Mirrors ``init.py``'s ``_bootstrap_enterprise`` read-merge-write shape —
    an absent/corrupt file starts from ``{}`` rather than failing, and only
    the ``governance`` key is touched.
    """
    if mode not in VALID_MODES:
        raise GovernanceError(f"governedMode must be one of {VALID_MODES}, got {mode!r}")
    path = _workspace_json_path(workspace)
    data: dict[str, Any] = {}
    if path.exists():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                data = {}
        except (json.JSONDecodeError, OSError):
            data = {}
    gov = data.get("governance", {}) or {}
    gov["governedMode"] = mode
    data["governance"] = gov
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    return path
