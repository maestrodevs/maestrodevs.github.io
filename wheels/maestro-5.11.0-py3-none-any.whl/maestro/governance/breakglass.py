"""
Break-glass gate + governance→audit bridge — FTR-MSO-2026-0398
(PLAN-PLN-MSO-2026-0372 S9 row 3).

Two related concerns live here, both sitting between the governance layer and the
hash-chained audit log (``maestro/audit/log.py``):

1. ``honor_bypass`` — the identity-gated break-glass flow for the guard bypass
   env vars (``MAESTRO_BRANCH_GUARD_BYPASS`` / ``MAESTRO_PATH_GUARD_BYPASS``).
   The pretool guards call it whenever a bypass var is set:

     * **Non-governed workspace** → the bypass is honoured with ZERO extra
       requirements, exactly as before this feature existed. Governance is off
       by default, so the vast majority of workspaces see no behaviour change.
     * **Governed ``enforce`` mode** → the bypass is refused unless ALL of:
       (a) a justification (``MAESTRO_BREAKGLASS_REASON``) is supplied;
       (b) the caller identity is **credential-backed / verified** (a gh- or
       OIDC-verified email) in an **enterprise** workspace — where the identity
       ACL is integrity-verified on load; and (c) that verified caller holds the
       ``governance.breakglass`` capability. The grant is then honoured ONLY once
       a tamper-evident audit record has durably landed. Every grant and refusal
       is recorded (who / when / why).
     * **Governed ``warn`` mode** → the bypass is honoured (warn never blocks)
       but the attempt is still audited so the trail exists.

2. ``record_policy_event`` — a best-effort helper that lands ``policy.eval`` /
   ``policy.deny`` governance-engine decisions in the audit log (previously they
   were print/lifecycle-only).

Trust-anchor rework (FTR-MSO-2026-0398 rework 2 — Captain "fail-closed now +
track anchor", per the independent SEC review):
  * The break-glass DECISION LOGIC (env-var-alone-never-relaxes, reason-mandatory,
    capability-required, no-persistent-relaxation) was already sound. The gap was
    the TRUST ANCHOR: the capability gate rested on identity/ACL state that a
    local-write attacker can forge (``ADM_USER`` + a hand-written ``access.json``).
  * FIX: in enforce mode the bypass is honoured only for a VERIFIED caller in an
    ENTERPRISE workspace, so the capability check runs against an
    integrity-verified ACL and an unauthenticated caller can no longer
    self-authorise (F1/F2). NET effect: non-enterprise / unverified-identity
    governed-enforce mode now REFUSES all bypasses (safe). The env-var hatch keeps
    working only when governance is OFF (unchanged).
  * The tamper-evident audit append MUST succeed before a grant returns; an
    audit-write failure is treated as REFUSE (fail-closed), not best-effort (F4).
  * A bypass var set while governed mode cannot be positively resolved (a
    workspace exists but its config is unreadable) fails closed rather than
    downgrading to ``off`` → allow (F7).
  * The DEEPER anchor — the ACL/identity integrity being forgeable even in
    enterprise mode — is tracked separately as BUG-MSO-2026-0409. This fix makes
    break-glass fail closed when it cannot trust identity, so it is SAFE before
    0409 lands.

Design notes:
  * The governance ENGINE (``engine.evaluate``) stays pure and side-effect-free;
    all audit I/O is bridged here, at the hook boundary, never inside the engine.
  * Audit writes for REFUSALS are best-effort (a refusal that fails to audit is
    still a refusal — safe). The audit write for a GRANT is strict (F4).
  * Once we know a workspace is governed, any *internal* error while evaluating
    break-glass fails CLOSED (the bypass is refused) — an unauthorised bypass is
    never silently honoured.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Optional, Tuple

# The env var carrying the operator's justification for a break-glass bypass.
REASON_ENV = "MAESTRO_BREAKGLASS_REASON"

# The identity capability a caller must hold to break glass in governed mode.
BREAKGLASS_CAPABILITY = "governance.breakglass"


def _resolve_workspace(cwd: Optional[str]) -> Optional[Path]:
    """Resolve the workspace root from *cwd* (or the process cwd)."""
    try:
        from maestro.hooks import find_mso_root
        return find_mso_root(cwd or os.getcwd())
    except Exception:
        return None


def _resolve_governed_mode(workspace: Optional[Path], env: dict) -> str:
    try:
        from maestro.governance import resolve_governed_mode
        return resolve_governed_mode(workspace, env)
    except Exception:
        # If we cannot even determine governed mode, treat as non-governed so
        # non-governed workspaces (the default) keep behaving exactly as today.
        return "off"


def _resolve_actor(workspace: Optional[Path]) -> str:
    if workspace is None:
        return "anonymous"
    try:
        from maestro.identity.auth import resolve_caller
        return resolve_caller(workspace)
    except Exception:
        return "anonymous"


def _has_breakglass_capability(workspace: Optional[Path], actor: str) -> bool:
    """True when *actor* holds ``governance.breakglass`` and is not restricted."""
    if workspace is None or actor == "anonymous":
        return False
    try:
        from maestro.workspace import resolve_artefact_dir
        from maestro.identity.acl import resolve_capability

        identity_dir = resolve_artefact_dir(workspace) / "identity"
        allowed = resolve_capability(
            actor=actor,
            capability=BREAKGLASS_CAPABILITY,
            scope="*",
            acl_path=identity_dir / "access.json",
            groups_dir=identity_dir / "groups",
        )
        if not allowed:
            return False

        # A GDPR-restricted identity may not break glass (mirrors the gate).
        try:
            from maestro.identity.rights import is_restricted
            email = actor.removeprefix("user:")
            if is_restricted(email, workspace):
                return False
        except Exception:
            pass
        return True
    except Exception:
        # Fail closed: an error resolving the capability in governed mode must
        # not grant the bypass.
        return False


def _enterprise_enabled(workspace: Optional[Path]) -> bool:
    """True when the workspace runs in enterprise mode.

    Enterprise mode is what triggers the identity ACL integrity check on load
    (``maestro.identity.loader._integrity_check``). Break-glass is honoured only
    in enterprise mode so the capability decision rests on an integrity-verified
    ACL rather than forgeable local state.
    """
    if workspace is None:
        return False
    try:
        from maestro.identity.gate import _load_enterprise_flag
        return _load_enterprise_flag(workspace)
    except Exception:
        return False


def _resolve_verified_actor(workspace: Optional[Path]) -> str:
    """Resolve a CREDENTIAL-BACKED caller identity, or ``anonymous``.

    Delegates to :func:`maestro.identity.auth.resolve_verified_caller`, which
    trusts an identity only when proven by a real credential (gh/OIDC verified),
    never an ``ADM_USER`` hint alone. Used to gate the break-glass grant so an
    unauthenticated caller cannot self-authorise a bypass.
    """
    if workspace is None:
        return "anonymous"
    try:
        from maestro.identity.auth import resolve_verified_caller
        return resolve_verified_caller(workspace)
    except Exception:
        return "anonymous"


def _config_unreadable(workspace: Optional[Path]) -> bool:
    """True when a workspace EXISTS but its ``workspace.json`` cannot be parsed.

    This distinguishes an attacker-corrupted (or otherwise unreadable) governance
    config — where governed mode cannot be positively resolved, so the bypass
    path must fail closed (F7) — from the genuinely non-governed case (no
    workspace at all, or a clean config with no governance block), which keeps
    the env-var hatch unchanged.
    """
    if workspace is None:
        return False
    try:
        from maestro.workspace import MSO_DIR_NAME
        ws = Path(workspace)
        for cand in (
            ws / MSO_DIR_NAME / "config" / "workspace.json",
            ws / "config" / "workspace.json",
        ):
            if cand.exists():
                try:
                    json.loads(cand.read_text(encoding="utf-8"))
                    return False  # parsed cleanly — positively resolvable
                except Exception:
                    return True   # exists but unreadable — cannot resolve
        return False  # no config file → genuinely no governance
    except Exception:
        return False


def _append_audit_strict(
    workspace: Optional[Path],
    action: str,
    target: str,
    result: str,
    metadata: dict,
    actor: str,
) -> bool:
    """Append to the hash-chained audit log; return True ONLY on a durable write.

    Used for the break-glass GRANT path (F4): the grant is honoured only when the
    tamper-evident record actually lands. ``AuditLog.append`` returns the written
    entry on success and ``None`` on a no-op (audit inactive); any backend error
    raises and is caught here. Either falsey outcome means the caller must fail
    closed rather than honour an unrecorded bypass.
    """
    if workspace is None:
        return False
    try:
        from maestro.audit import get_audit_log

        entry = get_audit_log(workspace).append(
            action=action,
            target=target,
            result=result,
            metadata=metadata or {},
            actor=actor,
        )
        return entry is not None
    except Exception:
        return False


def _lifecycle_line(workspace: Optional[Path], event: str, detail: str) -> None:
    """Guaranteed-trace lifecycle log line (best-effort, never raises).

    Written regardless of the enterprise flag so a governed-but-not-enterprise
    workspace still records break-glass use even though the audit log no-ops.
    """
    try:
        if workspace is None:
            return
        import datetime as _dt
        from maestro.workspace import resolve_artefact_dir

        log_dir = resolve_artefact_dir(workspace) / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        ts = _dt.datetime.now(_dt.timezone.utc).isoformat()
        with open(log_dir / "lifecycle.log", "a", encoding="utf-8") as lf:
            lf.write(f"{ts} | {event} | {detail}".rstrip() + "\n")
    except Exception:
        pass


def record_policy_event(
    workspace: Optional[Path],
    action: str,
    target: str,
    result: str = "ok",
    metadata: Optional[dict] = None,
    actor: Optional[str] = None,
) -> None:
    """Best-effort: land a governance policy event in the hash-chained audit log.

    Used by the pretool gate to record ``policy.eval`` / ``policy.deny`` /
    ``policy.breakglass`` decisions. A no-op when the audit log is inactive
    (non-enterprise) or on any error — it must never break the hook. The
    metadata NEVER carries a secret payload (rule ids, severities, reasons only).
    """
    if workspace is None:
        return
    try:
        from maestro.audit import get_audit_log

        get_audit_log(workspace).append(
            action=action,
            target=target,
            result=result,
            metadata=metadata or {},
            actor=actor,
        )
    except Exception:
        pass


def breakglass_grant(
    workspace: Optional[Path],
    env: Optional[dict] = None,
) -> Tuple[bool, str, str]:
    """Guard-agnostic breakglass check: does the caller hold ``governance.breakglass``
    and supply a reason?

    Factors out steps 1-3 of :func:`honor_bypass` (reason mandatory, verified
    identity in an enterprise workspace, capability held) for callers that are
    not one of the branch/path tool guards -- e.g. patrol's D1 monotonic-override
    refusal (PLAN-PLN-MSO-2026-0504 §5.4 point 3: "Patrol should reuse
    [breakglass] verbatim rather than inventing a second escape hatch"). Unlike
    ``honor_bypass``, this performs NO audit write itself and enforces no
    guard-specific "grant must be durably audited before proceeding" strictness
    -- the caller decides its own audit action (e.g. via ``record_policy_event``)
    and, for a config-time decision like a patrol definition, there is no
    single "operation" to hold open pending a durable write the way a live tool
    call has.

    Returns ``(granted, actor, reason)``. ``actor`` is ``"anonymous"`` and
    ``reason`` is ``""`` when nothing was even attempted (no reason supplied).
    """
    env = env if env is not None else os.environ
    reason = env.get(REASON_ENV, "").strip()
    if not reason:
        return False, "anonymous", ""

    verified_actor = _resolve_verified_actor(workspace)
    if not _enterprise_enabled(workspace) or verified_actor == "anonymous":
        return False, verified_actor, reason

    if not _has_breakglass_capability(workspace, verified_actor):
        return False, verified_actor, reason

    return True, verified_actor, reason


def honor_bypass(
    guard: str,
    cwd: Optional[str] = None,
    env: Optional[dict] = None,
) -> Tuple[bool, str]:
    """Decide whether a requested guard bypass should be honoured.

    Called by the branch/path guards when a bypass env var is set.

    Args:
        guard: short label of the calling guard ("branch_guard" | "path_guard"),
               recorded in the audit/lifecycle trail.
        cwd:   the hook's effective working directory (used to resolve the
               workspace and the calling identity).
        env:   env mapping (defaults to ``os.environ``).

    Returns:
        ``(honored, reason)``. ``honored=True`` → the guard proceeds to allow the
        operation as before. ``honored=False`` → the guard must DENY, surfacing
        *reason* to the crew so it knows how to recover (grant the capability /
        supply a justification).
    """
    env = env if env is not None else os.environ
    workspace = _resolve_workspace(cwd)
    mode = _resolve_governed_mode(workspace, env)

    # Non-governed: the bypass behaves EXACTLY as it did before this feature —
    # UNLESS a workspace exists whose governance config is unreadable, in which
    # case governed mode cannot be positively confirmed as "off" and the bypass
    # path fails closed (F7) rather than silently downgrading a possibly-governed
    # workspace to allow. A genuinely absent workspace or a clean non-governed
    # config is unchanged (the env-var hatch still works).
    if mode == "off":
        if _config_unreadable(workspace):
            return False, (
                f"BREAK-GLASS REFUSED [{guard}]: a guard-bypass request was made "
                "but the governance configuration could not be read, so governed "
                "mode cannot be positively confirmed as off. Refusing the bypass "
                "(fail-closed). Repair the workspace configuration and retry."
            )
        return True, ""

    actor = _resolve_actor(workspace)
    reason = env.get(REASON_ENV, "").strip()

    # warn mode never blocks; audit the attempt and allow.
    if mode == "warn":
        _lifecycle_line(
            workspace, "POLICY_BREAKGLASS",
            f"guard={guard} actor={actor} mode=warn result=allowed "
            f"reason={reason or '(none)'}",
        )
        record_policy_event(
            workspace, "policy.breakglass", guard, result="warn-allowed",
            metadata={"guard": guard, "mode": "warn", "reason": reason},
            actor=actor,
        )
        return True, ""

    # enforce mode: reason required, VERIFIED identity + enterprise required,
    # capability required, and the grant is audited tamper-evidently before it is
    # honoured.

    # 1. Justification is mandatory.
    if not reason:
        _lifecycle_line(
            workspace, "POLICY_BREAKGLASS",
            f"guard={guard} actor={actor} mode=enforce result=denied-no-reason",
        )
        record_policy_event(
            workspace, "policy.breakglass", guard, result="denied-no-reason",
            metadata={"guard": guard, "mode": "enforce"},
            actor=actor,
        )
        return False, (
            f"BREAK-GLASS REFUSED [{guard}]: a guard bypass in governed mode "
            f"requires a justification. Set {REASON_ENV}='<why>' in the parent "
            "shell (recorded in the audit log with your identity) and retry."
        )

    # 2. Trust anchor (F1/F2): honour the bypass only for a credential-backed,
    #    verified identity in an enterprise workspace — where the identity ACL is
    #    integrity-verified on load. When identity cannot be verified against a
    #    real credential (the default non-enterprise / unverified-hint case), the
    #    bypass is REFUSED, because the capability gate would otherwise rest on
    #    forgeable local state (the very local-write attacker this guard exists to
    #    counter). The claimed (best-effort) actor is still recorded on the trail.
    verified_actor = _resolve_verified_actor(workspace)
    enterprise = _enterprise_enabled(workspace)
    if not enterprise or verified_actor == "anonymous":
        _lifecycle_line(
            workspace, "POLICY_BREAKGLASS",
            f"guard={guard} actor={actor} mode=enforce "
            f"result=denied-untrusted-identity reason={reason}",
        )
        record_policy_event(
            workspace, "policy.breakglass", guard,
            result="denied-untrusted-identity",
            metadata={"guard": guard, "mode": "enforce", "reason": reason,
                      "enterprise": enterprise},
            actor=actor,
        )
        return False, (
            f"BREAK-GLASS REFUSED [{guard}]: a guard bypass in governed enforce "
            "mode is honoured only for a credential-backed, verified identity in "
            "an enterprise workspace (so the identity ACL is integrity-verified). "
            "The caller could not be verified against a real credential "
            "(GitHub / OIDC), so the bypass is refused. Governance-off workspaces "
            "keep the env-var hatch unchanged."
        )

    # 3. Capability against the integrity-verified ACL, using the VERIFIED actor.
    if not _has_breakglass_capability(workspace, verified_actor):
        _lifecycle_line(
            workspace, "POLICY_BREAKGLASS",
            f"guard={guard} actor={verified_actor} mode=enforce "
            f"result=denied-no-capability reason={reason}",
        )
        record_policy_event(
            workspace, "policy.breakglass", guard, result="denied-no-capability",
            metadata={"guard": guard, "mode": "enforce", "reason": reason},
            actor=verified_actor,
        )
        return False, (
            f"BREAK-GLASS REFUSED [{guard}]: caller '{verified_actor}' lacks the "
            f"'{BREAKGLASS_CAPABILITY}' capability required to bypass this guard "
            "in governed mode. Ask a Captain to grant it in the identity ACL "
            "at .mso/identity/access.json (the captain group holds it by default)."
        )

    # 4. Authorised break-glass. Land the tamper-evident record FIRST (F4): the
    #    grant is honoured only when the audit write durably succeeds — an
    #    unrecorded bypass is refused rather than honoured best-effort.
    audited = _append_audit_strict(
        workspace, "policy.breakglass", guard, "granted",
        {"guard": guard, "mode": "enforce", "reason": reason},
        verified_actor,
    )
    if not audited:
        _lifecycle_line(
            workspace, "POLICY_BREAKGLASS",
            f"guard={guard} actor={verified_actor} mode=enforce "
            f"result=denied-audit-failed reason={reason}",
        )
        return False, (
            f"BREAK-GLASS REFUSED [{guard}]: the tamper-evident audit record for "
            "this break-glass could not be written, so the bypass cannot be safely "
            "honoured (fail-closed). Check the audit-log backend and retry."
        )

    _lifecycle_line(
        workspace, "POLICY_BREAKGLASS",
        f"guard={guard} actor={verified_actor} mode=enforce result=granted "
        f"reason={reason}",
    )
    return True, ""
