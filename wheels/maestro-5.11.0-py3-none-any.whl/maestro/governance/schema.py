"""
Governance policy schema — PolicyBundle / PolicyRule dataclasses + validation.

FTR-MSO-2026-0392 (PLAN-PLN-MSO-2026-0372 Phase 1).

A *policy bundle* is a versioned JSON artefact describing deny/allow/warn rules
that the governance engine evaluates against a crew action. Phase 1 ships the
schema + a dependency-free structural validator (no external jsonschema dep);
Phase 2 adds Ed25519 signature verification on top of the same shape.

The dataclasses here are deliberately pure data — no I/O, no evaluation logic —
so the engine (``engine.py``) can stay a side-effect-free pure function of
``(rules, context) -> decision`` and be reused unchanged by the Phase 5 CI
backstop.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

# Valid enum-ish values ---------------------------------------------------------
VALID_ACTIONS = ("deny", "allow", "warn")
VALID_TIERS = ("org", "workspace", "user")
VALID_MODES = ("enforce", "warn", "off")
VALID_DEFAULT_ACTIONS = ("allow", "deny")

# Tier precedence: lower rank == higher authority. An org DENY (rank 0) can only
# be overridden by an ALLOW at rank <= 0 (i.e. another org rule). This is the
# mechanism that makes "local config cannot relax an org policy" true.
TIER_RANK = {"org": 0, "workspace": 1, "user": 2}


class GovernanceError(RuntimeError):
    """Raised for any governance load / schema / integrity failure.

    In governed (``MAESTRO_GOVERNED=1``) mode the pretool hook treats this as a
    FAIL-CLOSED signal: mutating tools are denied rather than silently allowed.
    """


@dataclass(frozen=True)
class RuleMatch:
    """The match predicate of a policy rule.

    All present conditions must hold (logical AND) for the rule to fire.
    """

    tool: tuple[str, ...] = ()          # Claude tool names, e.g. ("Bash",)
    tool_pattern: str | None = None     # regex on the tool NAME (e.g. "^mcp__" for any MCP tool)
    command_pattern: str | None = None  # regex, searched against the subject text
    env_class: tuple[str, ...] = ()     # optional narrowing on context.env_class

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "RuleMatch":
        tool = data.get("tool", [])
        if isinstance(tool, str):
            tool = [tool]
        ctx = data.get("context", {}) or {}
        env_class = ctx.get("envClass", [])
        if isinstance(env_class, str):
            env_class = [env_class]
        return RuleMatch(
            tool=tuple(tool),
            tool_pattern=data.get("toolPattern"),
            command_pattern=data.get("commandPattern"),
            env_class=tuple(env_class),
        )


@dataclass(frozen=True)
class PolicyRule:
    """A single governance rule."""

    id: str
    action: str                          # deny | allow | warn
    match: RuleMatch
    reason: str = ""
    severity: str = "medium"
    exceptions: tuple[str, ...] = ()     # rule-ids this ALLOW carves out (higher-tier only)
    # tier is stamped by the loader from the owning bundle, not the rule JSON.
    tier: str = "org"

    @staticmethod
    def from_dict(data: dict[str, Any], tier: str = "org") -> "PolicyRule":
        rid = data.get("id")
        if not rid or not isinstance(rid, str):
            raise GovernanceError(f"policy rule missing string 'id': {data!r}")
        action = data.get("action")
        if action not in VALID_ACTIONS:
            raise GovernanceError(
                f"rule '{rid}': action must be one of {VALID_ACTIONS}, got {action!r}"
            )
        match_raw = data.get("match")
        if not isinstance(match_raw, dict):
            raise GovernanceError(f"rule '{rid}': 'match' must be an object")
        exc = data.get("exceptions", []) or []
        if isinstance(exc, str):
            exc = [exc]
        return PolicyRule(
            id=rid,
            action=action,
            match=RuleMatch.from_dict(match_raw),
            reason=data.get("reason", ""),
            severity=data.get("severity", "medium"),
            exceptions=tuple(exc),
            tier=tier,
        )


@dataclass
class PolicyBundle:
    """A parsed, validated policy bundle."""

    bundle_id: str
    version: int
    tier: str
    rules: list[PolicyRule] = field(default_factory=list)
    schema_version: str = "1.0"
    issuer: str = ""
    governed_mode: str = "enforce"
    default_action: str = "allow"
    # PLAN-PLN-MSO-2026-0504 §5.3 tier 1: a signed policy bundle may ALSO carry
    # a `patrol` block -- checks overrides for `mso doctor` -- alongside its
    # tool-action `rules`. Deliberately untyped/unvalidated here (just the raw
    # dict as authored); `maestro.patrol.resolver` validates it against
    # `maestro/patrol/_schema.json` at resolution time, and a validation
    # failure there triggers the patrol fail-safe (§5.5), not a GovernanceError
    # here -- a bundle with a bad `patrol` block but good `rules` must still
    # load for tool-action governance to keep working.
    patrol: dict[str, Any] = field(default_factory=dict)

    @staticmethod
    def from_dict(data: dict[str, Any], tier: str | None = None) -> "PolicyBundle":
        if not isinstance(data, dict):
            raise GovernanceError("policy bundle must be a JSON object")

        bundle_id = data.get("bundleId")
        if not bundle_id or not isinstance(bundle_id, str):
            raise GovernanceError("policy bundle missing string 'bundleId'")

        version = data.get("version", 1)
        if not isinstance(version, int):
            raise GovernanceError(f"bundle '{bundle_id}': 'version' must be an integer")

        resolved_tier = tier or data.get("tier", "org")
        if resolved_tier not in VALID_TIERS:
            raise GovernanceError(
                f"bundle '{bundle_id}': tier must be one of {VALID_TIERS}, got {resolved_tier!r}"
            )

        governed_mode = data.get("governedMode", "enforce")
        if governed_mode not in VALID_MODES:
            raise GovernanceError(
                f"bundle '{bundle_id}': governedMode must be one of {VALID_MODES}"
            )

        default_action = data.get("defaultAction", "allow")
        if default_action not in VALID_DEFAULT_ACTIONS:
            raise GovernanceError(
                f"bundle '{bundle_id}': defaultAction must be one of {VALID_DEFAULT_ACTIONS}"
            )

        rules_raw = data.get("rules", [])
        if not isinstance(rules_raw, list):
            raise GovernanceError(f"bundle '{bundle_id}': 'rules' must be a list")

        rules = [PolicyRule.from_dict(r, tier=resolved_tier) for r in rules_raw]

        # Duplicate rule-id detection within a bundle (deterministic evaluation).
        seen: set[str] = set()
        for r in rules:
            if r.id in seen:
                raise GovernanceError(
                    f"bundle '{bundle_id}': duplicate rule id '{r.id}'"
                )
            seen.add(r.id)

        patrol_raw = data.get("patrol", {})
        if patrol_raw and not isinstance(patrol_raw, dict):
            raise GovernanceError(f"bundle '{bundle_id}': 'patrol' must be an object")

        return PolicyBundle(
            bundle_id=bundle_id,
            version=version,
            tier=resolved_tier,
            rules=rules,
            schema_version=data.get("schemaVersion", "1.0"),
            issuer=data.get("issuer", ""),
            governed_mode=governed_mode,
            default_action=default_action,
            patrol=patrol_raw,
        )


def validate_bundle_dict(data: dict[str, Any]) -> PolicyBundle:
    """Parse + validate a raw bundle dict, raising GovernanceError on any problem."""
    return PolicyBundle.from_dict(data)
