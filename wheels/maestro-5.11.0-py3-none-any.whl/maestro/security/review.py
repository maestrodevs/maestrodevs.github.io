"""
Security review CLI implementation — wraps mso security scan and produces a
unified REVIEW-{timestamp}.md report.

Does NOT invoke Claude. Claude analysis is reserved for the /security-review
slash-command path inside an active Claude Code session.

Exit codes:
  0 — no CRITICAL or HIGH findings
  1 — one or more CRITICAL or HIGH findings
  2 — scan error (import failure, no files found, etc.)
"""

from __future__ import annotations

import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import argparse


def run_review(args: "argparse.Namespace", ws: Path, mso_root: Path) -> int:
    """Run the security review and return an exit code (0, 1, or 2)."""
    try:
        from maestro.security.owasp_patterns import OWASPScanner, Severity
    except ImportError:
        print(
            "[Security Review] OWASP scanner not found. "
            "Ensure maestro-fleet is installed:\n"
            "  pip install maestro-fleet",
            file=sys.stderr,
        )
        return 2

    # Resolve diff target for the report header
    if getattr(args, "staged", False):
        diff_target = "--staged"
        diff_label = "staged changes"
    else:
        against = getattr(args, "against", None) or "origin/main"
        diff_target = f"{against}...HEAD"
        diff_label = f"{against}...HEAD"

    # Resolve files to scan — same logic as `mso security scan` default path
    files_to_scan: list[Path] = list(ws.rglob("*.py"))

    seen: set[str] = set()
    unique_files: list[str] = []
    for f in files_to_scan:
        p = Path(f)
        key = str(p.resolve())
        if key in seen:
            continue
        seen.add(key)
        if p.exists():
            unique_files.append(str(p))

    if not unique_files:
        print("[Security Review] No Python files found to scan.", file=sys.stderr)
        return 2

    if not getattr(args, "json", False):
        print(f"[Security Review] Scanning {len(unique_files)} file(s) against {diff_label}...")

    scanner = OWASPScanner(language="python")
    all_findings = scanner.scan_files(unique_files)

    # Apply severity threshold (default: MEDIUM for review subcommand)
    severity_order = ["INFO", "LOW", "MEDIUM", "HIGH", "CRITICAL"]
    threshold = (getattr(args, "severity_threshold", None) or "MEDIUM").upper()
    if threshold not in severity_order:
        print(f"[Security Review] Invalid --severity-threshold: {threshold}", file=sys.stderr)
        return 2
    min_idx = severity_order.index(threshold)
    filtered = [f for f in all_findings if severity_order.index(f.severity.value) >= min_idx]

    # Build summary
    summary: dict[str, int] = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0, "INFO": 0}
    for f in filtered:
        summary[f.severity.value] = summary.get(f.severity.value, 0) + 1

    has_critical_or_high = summary["CRITICAL"] > 0 or summary["HIGH"] > 0

    # Determine security decision
    if has_critical_or_high:
        decision = "REJECTED"
    elif summary["MEDIUM"] > 0:
        decision = "CONDITIONAL"
    else:
        decision = "APPROVED"

    # Produce report
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    reports_dir = mso_root / "reports" / "security"
    reports_dir.mkdir(parents=True, exist_ok=True)
    report_path = reports_dir / f"REVIEW-{timestamp}.md"

    lines = [
        f"# Security Review — {timestamp}",
        "",
        f"**Diff target**: `{diff_label}`  ",
        f"**Files scanned**: {len(unique_files)}  ",
        f"**Generated**: {datetime.now(timezone.utc).isoformat()}  ",
        "",
        "## Scan Summary",
        "",
        f"| Severity | Count |",
        f"|----------|-------|",
    ]
    for sev in ("CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"):
        lines.append(f"| {sev} | {summary[sev]} |")

    lines += ["", "## Findings", ""]

    if not filtered:
        lines.append("No findings above threshold.")
    else:
        for i, f in enumerate(filtered, 1):
            lines += [
                f"### {i}. [{f.severity.value}] {f.title}",
                "",
                f"- **Severity**: {f.severity.value}",
                f"- **Category**: {f.cwe}",
                f"- **Location**: `{f.file}:{f.line}`",
                f"- **Finding**: {f.title}",
                f"- **Evidence**: `{f.snippet[:120]}`",
                f"- **Remediation**: {f.remediation}",
                "",
            ]

    lines += [
        "## Security Decision",
        "",
        f"**Status**: {decision}",
        "",
    ]
    if has_critical_or_high:
        lines.append(
            "CRITICAL or HIGH findings present — must be remediated before merge."
        )

    report_path.write_text("\n".join(lines), encoding="utf-8")

    if getattr(args, "json", False):
        output = {
            "diffTarget": diff_label,
            "scannedFiles": len(unique_files),
            "totalFindings": len(filtered),
            "summary": summary,
            "decision": decision,
            "reportPath": str(report_path),
            "findings": [f.to_dict() for f in filtered],
        }
        print(json.dumps(output, indent=2))
    else:
        print(f"\n[Security Review] {decision}")
        print(f"  CRITICAL: {summary['CRITICAL']}  HIGH: {summary['HIGH']}  "
              f"MEDIUM: {summary['MEDIUM']}  LOW: {summary['LOW']}")
        print(f"  Report: {report_path}")

    return 1 if has_critical_or_high else 0
