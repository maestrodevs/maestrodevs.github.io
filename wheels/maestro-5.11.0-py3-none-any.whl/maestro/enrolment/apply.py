# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. See LICENSE for full terms.

"""
maestro.enrolment.apply — idempotent application of a verified enrolment profile.

PLAN-PLN-MSO-2026-0449 §3.4 (Order FTR-MSO-2026-0477, extended by Order
FTR-MSO-2026-0482 §7.3/§7.4 — secrets provider + identity seeding).

Applies a `schema.EnrolmentProfile` — already resolved and signature-verified
by `maestro.enrolment.loader.resolve_profile` — to the local workspace:

  * `workspace.json` top-level fields (`profile.workspace`, e.g. `project` /
    `defaultGitHubOrg` — the same keys `mso init` itself scaffolds).
  * `workspace.json` `governance.governedMode` / `governance.pullUrl` — the
    org's governance gate.
  * `workspace.json` `governance.trustedKeys` — merges the profile's org
    signing keys into the workspace-tier trust pin
    (`governance/keys.py` precedence: env < workspace < home < vendor).
  * `workspace.json` `secretsProvider` — the org's secrets backend
    (`profile.secrets`, §7.3). NOT a D3(b) security-sensitive key (schema.py
    `SECURITY_SENSITIVE_KEYS`) — an unsigned profile may carry it, same as
    `workspace`/`pack`/`mcp`/`hooks`/`prompts`.

Identity seeding (`profile.identity.seed`, §7.4) is a SEPARATE step —
:func:`maybe_seed_identity` — because it writes files under the identity
directory, not `workspace.json`. `identity` IS a D3(b) security-sensitive
key, so `check_unsigned_allowed` (called by `apply_profile` below) already
refuses the whole profile before an unsigned one could reach this function.

Refuses — and applies NOTHING — rather than partially writing, on:

  * `minimumTier` refusal (`schema.check_minimum_tier`).
  * An unsigned profile carrying a security-sensitive key
    (`schema.check_unsigned_allowed`).
  * A `trustedKeys` entry whose `keyId` collides with a VENDOR-pinned key.
    The vendor baseline always wins a collision (`governance/keys.py`), so an
    enrolment profile introducing the same id would be indistinguishable
    from an attempt to shadow it — refused outright rather than silently
    losing to the vendor entry.
  * A malformed `trustedKeys` entry (bad algorithm / not-32-byte key / bad
    status) — validated with the SAME shape-check the governance keyring
    uses when it later loads these keys, so a bad entry is caught at apply
    time rather than the next time governance tries to resolve a signature.

Idempotent: re-applying the same profile is a plain dict merge (not append)
and never errors on a value already present.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

from maestro.enrolment.schema import (
    EnrolmentProfile,
    check_minimum_tier,
    check_unsigned_allowed,
    resolve_current_tier,
)
from maestro.governance.schema import GovernanceError


class ApplyError(RuntimeError):
    """Raised when an enrolment profile cannot be safely applied."""


# Provider `type` values understood by `maestro.secrets.registry.get_provider`.
# An unrecognised type falls through to the `env` default there — fine for a
# hand-edited workspace.json, but a silent downgrade is exactly the failure
# mode §3.5 forbids for profile-driven config, so `apply_profile` refuses
# instead of letting a typo'd org profile quietly land on `env`.
KNOWN_SECRETS_PROVIDER_TYPES = frozenset(
    {"env", "os_keyring", "azure_keyvault", "aws_secrets", "vault", "one_password"}
)


def _workspace_config_path(workspace: Path) -> Path:
    from maestro.workspace import MSO_DIR_NAME
    ws = Path(workspace)
    for candidate in (ws / MSO_DIR_NAME / "config" / "workspace.json", ws / "config" / "workspace.json"):
        if candidate.exists():
            return candidate
    return ws / MSO_DIR_NAME / "config" / "workspace.json"


def _load_workspace_config(path: Path) -> dict:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001
        raise ApplyError(f"workspace.json unreadable ({path}): {exc}") from exc


def _vendor_key_ids() -> set[str]:
    """KeyIds currently pinned by the vendor baseline (always wins a collision)."""
    from maestro.governance.keys import load_trusted_keys
    return {kid for kid, key in load_trusted_keys(workspace=None).items() if key.source == "vendor"}


def apply_profile(
    profile: EnrolmentProfile,
    *,
    workspace: Path,
    current_tier: Optional[str] = None,
    write: bool = True,
) -> dict:
    """Apply a verified `profile` to `workspace`. Returns the merged config dict.

    All refusal checks run BEFORE any write (see module docstring) — a
    refusal leaves `workspace.json` byte-for-byte unchanged.
    """
    tier = current_tier if current_tier is not None else resolve_current_tier()
    check_minimum_tier(profile, tier)
    check_unsigned_allowed(profile)

    if profile.trusted_keys:
        from maestro.governance.keys import _keys_from_map
        try:
            _keys_from_map(profile.trusted_keys, f"enrolment profile '{profile.bundle_id}'")
        except GovernanceError as exc:
            raise ApplyError(str(exc)) from exc

        colliding = sorted(set(profile.trusted_keys) & _vendor_key_ids())
        if colliding:
            raise ApplyError(
                f"enrolment profile '{profile.bundle_id}' trustedKeys collide "
                f"with vendor-pinned key id(s) {colliding} — refusing to apply. "
                "A vendor keyId can never be shadowed by an org or workspace pin."
            )

    secrets_provider_type = None
    if profile.secrets:
        secrets_provider_type = profile.secrets.get("type", "env")
        if secrets_provider_type not in KNOWN_SECRETS_PROVIDER_TYPES:
            raise ApplyError(
                f"enrolment profile '{profile.bundle_id}' sets secrets.type="
                f"{secrets_provider_type!r}, which is not a known secrets provider "
                f"type {sorted(KNOWN_SECRETS_PROVIDER_TYPES)} — refusing to apply "
                "rather than silently falling back to the less-secure 'env' default "
                "(§3.5: never silently select the insecure option under automation)."
            )

    cfg_path = _workspace_config_path(workspace)
    cfg = _load_workspace_config(cfg_path)

    if profile.workspace:
        cfg.update(profile.workspace)

    gov = dict(cfg.get("governance") or {})
    if "governedMode" in profile.governance:
        gov["governedMode"] = profile.governance["governedMode"]
    if "pullUrl" in profile.governance:
        gov["pullUrl"] = profile.governance["pullUrl"]
    if profile.trusted_keys:
        merged_keys = dict(gov.get("trustedKeys") or {})
        merged_keys.update(profile.trusted_keys)
        gov["trustedKeys"] = merged_keys
    if gov:
        cfg["governance"] = gov

    if profile.secrets:
        cfg["secretsProvider"] = {
            "type": secrets_provider_type,
            "config": dict(profile.secrets.get("config") or {}),
        }

    if write:
        cfg_path.parent.mkdir(parents=True, exist_ok=True)
        cfg_path.write_text(json.dumps(cfg, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    return cfg


def maybe_seed_identity(profile: EnrolmentProfile, *, workspace: Path) -> Optional[dict]:
    """Seed the identity store when the profile requests it (`identity.seed`, §7.4).

    Returns `None` when the profile does not request seeding (the common
    case — team/enterprise devices with a profile that only sets
    workspace/governance/secrets). Idempotent — safe to call on every
    `mso setup` run, mirroring `mso identity init`'s own idempotence.

    `identity` is a D3(b) security-sensitive key (`schema.SECURITY_SENSITIVE_KEYS`):
    by the time a caller can reach this function it must already have called
    `apply_profile` successfully, which refuses an unsigned profile that sets
    `identity` before either function runs — this function does not re-check
    signing itself.
    """
    if not profile.identity or not profile.identity.get("seed"):
        return None

    from maestro.workspace import MSO_DIR_NAME
    identity_dir = Path(workspace) / MSO_DIR_NAME / "identity"
    users_dir = identity_dir / "users"
    groups_dir = identity_dir / "groups"
    acl_path = identity_dir / "access.json"

    from maestro.identity.loader import seed_identity
    result = seed_identity(identity_dir, users_dir, groups_dir, acl_path)

    encryption = profile.identity.get("encryption")
    if encryption and encryption != "none":
        from maestro.identity.encryption import encryption_init_wizard
        try:
            encryption_init_wizard(Path(workspace), identity_dir, encryption)
            result["encryption"] = encryption
        except Exception as exc:  # noqa: BLE001 — optional enhancement, never fatal
            result["encryption_error"] = str(exc)

    return result
