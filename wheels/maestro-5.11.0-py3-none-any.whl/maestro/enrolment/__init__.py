# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. See LICENSE for full terms.

"""
maestro.enrolment — signed enrolment-profile schema, resolution, and application.

PLAN-PLN-MSO-2026-0449 §3.2-§3.4 (Order FTR-MSO-2026-0477). An *enrolment
profile* is the admin-authored artefact that carries org configuration onto a
device (the "option C" design in the plan): an admin authors and signs it
once, and ``mso setup`` looks for it and applies it, prompting only for what
the profile leaves open.

Three modules, one responsibility each:

  * :mod:`maestro.enrolment.schema` — the profile shape, structural
    validation, the D3(b) unsigned-key restriction, and the ``minimumTier``
    refusal.
  * :mod:`maestro.enrolment.loader` — the §3.3 precedence chain (explicit >
    env > home keyring > workspace), fetch (file or URL), and signature
    verification (delegated unchanged to
    :func:`maestro.governance.signing.verify_signed_bundle`).
  * :mod:`maestro.enrolment.apply` — idempotent application of a verified
    profile to ``workspace.json`` (workspace fields, the governance gate, and
    trusted keys).

None of this is wired into ``mso setup`` yet — that is
PLAN-PLN-MSO-2026-0449 Order 2 (the tier-aware setup wizard). This package is
usable standalone in the meantime (and by that order once it lands).
"""
from __future__ import annotations

from maestro.enrolment.apply import ApplyError, apply_profile
from maestro.enrolment.loader import PRECEDENCE, ResolvedProfile, resolve_profile
from maestro.enrolment.schema import (
    EnrolmentError,
    EnrolmentProfile,
    SECURITY_SENSITIVE_KEYS,
    TIER_RANK,
    VALID_TIERS,
    check_minimum_tier,
    check_unsigned_allowed,
    parse_profile,
    resolve_current_tier,
)

__all__ = [
    "ApplyError",
    "apply_profile",
    "PRECEDENCE",
    "ResolvedProfile",
    "resolve_profile",
    "EnrolmentError",
    "EnrolmentProfile",
    "SECURITY_SENSITIVE_KEYS",
    "TIER_RANK",
    "VALID_TIERS",
    "check_minimum_tier",
    "check_unsigned_allowed",
    "parse_profile",
    "resolve_current_tier",
]
