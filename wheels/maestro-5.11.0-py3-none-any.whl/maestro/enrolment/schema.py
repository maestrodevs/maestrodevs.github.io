# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. See LICENSE for full terms.

"""
maestro.enrolment.schema — enrolment-profile shape, parsing, and structural validation.

PLAN-PLN-MSO-2026-0449 §3.4 (Order FTR-MSO-2026-0477).

Field-name decision — ``bundleId``, not ``profileId``
------------------------------------------------------
The plan's §3.4 sketch is explicitly a "sketch — schema to be finalised in
the FTR" and illustrates the identity field as ``profileId``. This module
finalises it as ``bundleId`` instead, so an enrolment profile reuses the
EXACT same signed-envelope shape as a policy bundle
(``governance/schema.py``'s ``bundleId`` / ``version`` / ``signature``
fields). That is what lets
:func:`maestro.enrolment.loader.resolve_profile` delegate verification to
:func:`maestro.governance.signing.verify_signed_bundle` completely
unmodified — no field-renaming shim, no risk of the bytes verified diverging
from the bytes an authoring tool actually signed (the whole payload, minus
``signature``, is hashed verbatim — see ``governance/verify.py``). A
consequence worth knowing for later orders: the anti-rollback ledger
(``governance/rollback.py``) is keyed by this same ``bundleId``/``version``
pair and is SHARED with policy bundles, since verification is fully
delegated. A real collision would require an admin naming a policy bundle
and an enrolment profile identically — a naming-hygiene footgun, not a
security bypass (worst case is an overly-conservative false rollback
rejection; trust resolution itself is unaffected). Flagged for the admin
policy-authoring order (Order 3) to consider a naming convention.

Unsigned-profile restriction (D3(b), plan §3.4)
------------------------------------------------
An unsigned profile is a convenience only — never a security assertion. It
must not carry any of the SECURITY-SENSITIVE keys (``governance.
governedMode``, ``trustedKeys``, ``audit``, ``identity``); doing so would let
a workspace-local writer mint a trust root or silently flip governance on
without ever proving who authored it. See :func:`check_unsigned_allowed`.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional


class EnrolmentError(RuntimeError):
    """Raised for any enrolment-profile schema / integrity / policy failure."""


SCHEMA_VERSION = "1.0"

# Tier ordering, lowest -> highest authority. Mirrors the four tiers named
# throughout PLAN-PLN-MSO-2026-0449 (community/pro/team/enterprise).
#
# NOTE: as of this order, `maestro.licence` has NOT shipped a
# `resolve_state()` / `COMMUNITY_TIER` concept — that lands under a
# different, unmerged plan (PLAN-PLN-MSO-2026-0450). `resolve_current_tier`
# below degrades gracefully to the tier vocabulary that IS shipped today
# (`LicenceRecord.tier` via `maestro.licence.status()`), treating "no
# licence" as `"community"` (matching the existing `maestro/auth.py:
# has_tier` default of "no licence = not in any paid tier"). When the
# four-tier licence core lands, only `resolve_current_tier` needs to change
# — everything else in this module operates on plain tier strings.
VALID_TIERS = ("community", "pro", "team", "enterprise")
TIER_RANK = {tier: rank for rank, tier in enumerate(VALID_TIERS)}

# The four D3(b) security-sensitive keys. `governedMode` is nested inside the
# `governance` object rather than being its own top-level key — see
# `check_unsigned_allowed`.
SECURITY_SENSITIVE_KEYS = ("governance.governedMode", "trustedKeys", "audit", "identity")

_DICT_FIELDS = (
    "workspace", "pack", "governance", "trustedKeys",
    "audit", "identity", "secrets", "mcp", "hooks", "prompts",
)


@dataclass(frozen=True)
class EnrolmentProfile:
    """A parsed (but not yet verified or applied) enrolment profile."""

    raw: dict[str, Any]
    bundle_id: str
    version: int
    org: str = ""
    schema_version: str = SCHEMA_VERSION
    minimum_tier: Optional[str] = None
    workspace: dict = field(default_factory=dict)
    pack: dict = field(default_factory=dict)
    governance: dict = field(default_factory=dict)
    trusted_keys: dict = field(default_factory=dict)
    audit: dict = field(default_factory=dict)
    identity: dict = field(default_factory=dict)
    secrets: dict = field(default_factory=dict)
    mcp: dict = field(default_factory=dict)
    hooks: dict = field(default_factory=dict)
    prompts: dict = field(default_factory=dict)

    @property
    def is_signed(self) -> bool:
        from maestro.governance.signing import is_signed as _is_signed
        return _is_signed(self.raw)


def parse_profile(data: dict[str, Any]) -> EnrolmentProfile:
    """Structurally validate + parse a raw enrolment-profile dict.

    Raises `EnrolmentError` on any structural problem. Does NOT verify a
    signature or apply the unsigned-key restriction — that is
    `maestro.enrolment.loader.resolve_profile`'s job (signature) and
    `check_unsigned_allowed` (the D3(b) restriction), both of which need the
    parsed `EnrolmentProfile` this function returns.
    """
    if not isinstance(data, dict):
        raise EnrolmentError("enrolment profile must be a JSON object")

    bundle_id = data.get("bundleId")
    if not bundle_id or not isinstance(bundle_id, str):
        raise EnrolmentError("enrolment profile missing string 'bundleId'")

    version = data.get("version", 1)
    if not isinstance(version, int):
        raise EnrolmentError(f"profile '{bundle_id}': 'version' must be an integer")

    org = data.get("org", "")
    if not isinstance(org, str):
        raise EnrolmentError(f"profile '{bundle_id}': 'org' must be a string")

    minimum_tier = data.get("minimumTier")
    if minimum_tier is not None and minimum_tier not in VALID_TIERS:
        raise EnrolmentError(
            f"profile '{bundle_id}': minimumTier must be one of {VALID_TIERS}, "
            f"got {minimum_tier!r}"
        )

    for key in _DICT_FIELDS:
        val = data.get(key)
        if val is not None and not isinstance(val, dict):
            raise EnrolmentError(f"profile '{bundle_id}': '{key}' must be an object")

    return EnrolmentProfile(
        raw=data,
        bundle_id=bundle_id,
        version=version,
        org=org,
        schema_version=data.get("schemaVersion", SCHEMA_VERSION),
        minimum_tier=minimum_tier,
        workspace=data.get("workspace") or {},
        pack=data.get("pack") or {},
        governance=data.get("governance") or {},
        trusted_keys=data.get("trustedKeys") or {},
        audit=data.get("audit") or {},
        identity=data.get("identity") or {},
        secrets=data.get("secrets") or {},
        mcp=data.get("mcp") or {},
        hooks=data.get("hooks") or {},
        prompts=data.get("prompts") or {},
    )


def check_unsigned_allowed(profile: EnrolmentProfile) -> None:
    """D3(b): an UNSIGNED profile must not carry a security-sensitive key.

    Raises `EnrolmentError` naming every offending key at once (not just the
    first) when the profile is unsigned and sets `governance.governedMode`,
    `trustedKeys`, `audit`, or `identity`. A signed profile may set any of
    these — the signature is what proves who authored them.
    """
    if profile.is_signed:
        return
    checks = {
        "governance.governedMode": profile.governance.get("governedMode") is not None,
        "trustedKeys": bool(profile.trusted_keys),
        "audit": bool(profile.audit),
        "identity": bool(profile.identity),
    }
    offending = [key for key in SECURITY_SENSITIVE_KEYS if checks[key]]
    if offending:
        raise EnrolmentError(
            f"enrolment profile '{profile.bundle_id}' is unsigned but sets "
            f"security-sensitive key(s) {offending} — an unsigned profile may "
            "only be a convenience (workspace / pack / secrets / mcp / hooks / "
            "prompts), never a security assertion. Sign the profile or remove "
            "these keys."
        )


def check_minimum_tier(profile: EnrolmentProfile, current_tier: str) -> None:
    """Refuse a profile whose `minimumTier` exceeds the device's current tier.

    Raises `EnrolmentError` naming both the required and the actual tier
    (§3.4) — the caller must treat this as "apply nothing", not "apply what
    you can".
    """
    if profile.minimum_tier is None:
        return
    if current_tier not in TIER_RANK:
        raise EnrolmentError(
            f"cannot evaluate minimumTier: unknown current tier {current_tier!r} "
            f"(expected one of {VALID_TIERS})"
        )
    if TIER_RANK[current_tier] < TIER_RANK[profile.minimum_tier]:
        raise EnrolmentError(
            f"enrolment profile '{profile.bundle_id}' requires a "
            f"'{profile.minimum_tier}' licence or higher; this device is at "
            f"'{current_tier}'. Activate a licence for the required tier, or "
            "run `mso setup` without this profile."
        )


def resolve_current_tier() -> str:
    """Best-effort current-tier resolution using what has actually shipped.

    `maestro.licence` does not yet expose a `resolve_state()` / four-tier
    concept (see the module-level note above `VALID_TIERS`). Until it does,
    "current tier" is read from the existing `licence.status()` record; an
    absent licence or an unrecognised tier string degrades to `"community"`
    rather than raising, matching this codebase's existing "no licence = no
    paid tier" default (`maestro/auth.py:has_tier`).

    Callers that need a specific tier for testing should pass
    `current_tier=` explicitly to `maestro.enrolment.apply.apply_profile`
    instead of relying on this resolver / monkeypatching `licence.status`.
    """
    try:
        from maestro.licence import status
        rec = status()
        if rec is not None and rec.tier in TIER_RANK:
            return rec.tier
    except Exception:
        pass
    return "community"
