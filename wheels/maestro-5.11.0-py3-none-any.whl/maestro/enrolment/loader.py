# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. See LICENSE for full terms.

"""
maestro.enrolment.loader — resolve, fetch, and verify an enrolment profile.

PLAN-PLN-MSO-2026-0449 §3.3 (precedence), §3.4 (bootstrapping), Order
FTR-MSO-2026-0477.

Precedence (§3.3), mirroring `governance/distribution.py:_resolve_url`,
highest to lowest authority:

  1. an explicit path or URL (the future `mso setup --profile` flag)
  2. `MAESTRO_ENROLMENT_PROFILE` env var (path or URL)
  3. `~/.maestro/enrolment.json` (laid down by MDM/imaging, out-of-workspace)
  4. `.mso/config/enrolment.json` (committed by the team into the workspace)
  5. none found -> `resolve_profile` returns `None` (today's no-profile
     behaviour, unchanged).

The FIRST candidate found in that order wins outright — a broken profile at
a higher-precedence location is a hard failure, never silently skipped in
favour of a lower-precedence one (a broken MDM push must not quietly degrade
to "no profile" or "the team's profile instead"). §3.2a's community-skip
rule ("must not even stat these paths") is the CALLER's responsibility, not
this module's — `resolve_profile` always looks; a community-aware caller
(the future tier-aware setup wizard) must not call it at all at that tier.

Verification delegates unchanged to
`maestro.governance.signing.verify_signed_bundle` — signature, anti-rollback,
and offline-freshness are exactly the policy-bundle semantics, reused as-is.
See `schema.py`'s module docstring for why the profile's identity field is
named `bundleId`, matching the policy-bundle envelope exactly.

Bootstrapping (§3.4): a signed profile's own signing key must already be
pinned OUTSIDE the profile itself (vendor keyring, home keyring, or a prior
profile's already-applied workspace pin) — this falls out for free from
`verify_signed_bundle`'s `resolve_key` call reading the CURRENT (pre-apply)
trust registry; the profile being verified has not been merged into
`workspace.json` yet, so it cannot supply the very key that authenticates it.

Offline grace (mirroring `governance/distribution.py:97`, per plan §15): a
URL fetch failure falls back to the last successfully-verified copy cached
at the artefact root, if that copy is still fresh. A local FILE candidate
that exists but fails to read is a hard error — the cache never masks a
broken on-disk profile.
"""
from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Optional

from maestro.enrolment.schema import EnrolmentProfile, check_unsigned_allowed, parse_profile
from maestro.governance.schema import GovernanceError

PRECEDENCE = ("explicit", "env", "home", "workspace")

_ENV_PROFILE = "MAESTRO_ENROLMENT_PROFILE"
_HOME_PROFILE_FILENAME = "enrolment.json"
_WORKSPACE_PROFILE_RELPATH = ("config", "enrolment.json")
_CACHE_RELPATH = ("config", "enrolment-cache.json")
_TIMEOUT_SECONDS = 20

Fetcher = Callable[[str], bytes]


@dataclass
class ResolvedProfile:
    profile: EnrolmentProfile
    source: str             # one of PRECEDENCE, or "cache"
    origin: str              # the path/URL it came from
    verified: bool
    signed: bool


def _is_url(source: str) -> bool:
    return source.startswith("http://") or source.startswith("https://")


def _default_fetch(url: str) -> bytes:
    req = urllib.request.Request(url, headers={"Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=_TIMEOUT_SECONDS) as resp:  # noqa: S310 (https default)
        return resp.read()


def _read_source(source: str, fetcher: Optional[Fetcher]) -> bytes:
    if _is_url(source):
        fetch = fetcher or _default_fetch
        return fetch(source)
    path = Path(source)
    if not path.exists():
        raise GovernanceError(f"enrolment profile source not found: {path}")
    return path.read_bytes()


def _candidate_sources(workspace: Optional[Path]) -> list[tuple[str, str]]:
    """`(tag, location)` pairs in precedence order for the env/home/workspace tiers.

    The `explicit` tier is prepended by `resolve_profile` itself since it is
    not filesystem-discoverable. Only candidates that already exist are
    included, so `resolve_profile`'s loop always either succeeds or raises —
    it never silently "moves on" from a found-but-broken candidate.
    """
    candidates: list[tuple[str, str]] = []

    env_val = os.environ.get(_ENV_PROFILE)
    if env_val:
        candidates.append(("env", env_val))

    try:
        from maestro.workspace import get_maestro_home
        home_path = get_maestro_home() / _HOME_PROFILE_FILENAME
        if home_path.exists():
            candidates.append(("home", str(home_path)))
    except Exception:
        pass

    if workspace is not None:
        from maestro.workspace import MSO_DIR_NAME
        ws = Path(workspace)
        ws_profile = ws.joinpath(MSO_DIR_NAME, *_WORKSPACE_PROFILE_RELPATH)
        if not ws_profile.exists():
            ws_profile = ws.joinpath(*_WORKSPACE_PROFILE_RELPATH)
        if ws_profile.exists():
            candidates.append(("workspace", str(ws_profile)))

    return candidates


def _cache_path(artefact_root: Path) -> Path:
    return artefact_root.joinpath(*_CACHE_RELPATH)


def resolve_profile(
    *,
    source: Optional[str] = None,
    workspace: Optional[Path] = None,
    artefact_root: Optional[Path] = None,
    fetcher: Optional[Fetcher] = None,
    now: Optional[datetime] = None,
    record: bool = True,
) -> Optional[ResolvedProfile]:
    """Resolve, fetch, parse, and verify an enrolment profile per §3.3.

    Returns `None` only when NO candidate exists anywhere in the chain
    (today's unchanged no-profile behaviour). Raises `GovernanceError` /
    `maestro.enrolment.schema.EnrolmentError` when a profile IS found but
    fails signature verification, structural validation, or the D3(b)
    unsigned-key restriction.
    """
    now = now or datetime.now(timezone.utc)
    if artefact_root is None and workspace is not None:
        try:
            from maestro.workspace import get_artefact_root
            artefact_root = get_artefact_root(Path(workspace))
        except Exception:
            artefact_root = None

    chain: list[tuple[str, str]] = []
    if source:
        chain.append(("explicit", source))
    chain.extend(_candidate_sources(workspace))

    if not chain:
        return None

    tag, origin = chain[0]

    try:
        raw_bytes = _read_source(origin, fetcher)
    except (urllib.error.URLError, urllib.error.HTTPError, OSError, TimeoutError) as exc:
        if _is_url(origin):
            cached = _try_cache(artefact_root, now)
            if cached is not None:
                return cached
        raise GovernanceError(
            f"could not read enrolment profile from {origin} ({tag}): {exc}"
        ) from exc

    try:
        data = json.loads(raw_bytes.decode("utf-8"))
    except Exception as exc:  # noqa: BLE001
        raise GovernanceError(
            f"enrolment profile at {origin} is not valid JSON: {exc}"
        ) from exc

    profile = parse_profile(data)
    outcome = _verify(profile, workspace, artefact_root, now, record)
    check_unsigned_allowed(profile)

    if artefact_root is not None:
        _write_cache(artefact_root, data)

    return ResolvedProfile(
        profile=profile, source=tag, origin=origin,
        verified=outcome.verified, signed=outcome.signed,
    )


def _verify(profile: EnrolmentProfile, workspace, artefact_root, now, record):
    from maestro.governance.signing import verify_signed_bundle
    return verify_signed_bundle(
        profile.raw, workspace=workspace, now=now, record=record,
        require_signature=False, artefact_root=artefact_root,
    )


def _try_cache(artefact_root: Optional[Path], now: datetime) -> Optional[ResolvedProfile]:
    """Offline-grace fallback: the last verified copy, if it is still fresh.

    Mirrors `governance/distribution.py:_offline_fallback` — a profile with
    no `expiresAt`/`offlineGraceDays` of its own has nothing to be "fresh"
    against and this returns `None` (fail-closed), exactly as an unreachable
    policy-bundle URL fails closed without those fields.
    """
    if artefact_root is None:
        return None
    cache_path = _cache_path(artefact_root)
    if not cache_path.exists():
        return None
    try:
        data = json.loads(cache_path.read_text(encoding="utf-8"))
        profile = parse_profile(data)
    except Exception:
        return None

    from maestro.governance import rollback as _rollback
    fresh, _reason = _rollback.is_fresh(profile.bundle_id, now=now, artefact_root=artefact_root)
    if not fresh:
        return None

    check_unsigned_allowed(profile)
    return ResolvedProfile(
        profile=profile, source="cache", origin=str(cache_path),
        verified=True, signed=profile.is_signed,
    )


def _write_cache(artefact_root: Path, data: dict) -> None:
    """Best-effort cache write — a failure here only costs a future offline fallback."""
    path = _cache_path(artefact_root)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    except OSError:
        pass
