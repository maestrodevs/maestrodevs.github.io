# Maestro — Quickstart

> From zero to a running demo fleet in under 5 minutes.

**Not sure which of the guides you need?** See [START-HERE.md](START-HERE.md) — Maestro has four
licence tiers and only one of them (**community**, free, no licence) needs nothing before you
begin. This page covers community and pro. Team/Enterprise: see
[ENTERPRISE-QUICKSTART.md](ENTERPRISE-QUICKSTART.md).

---

## 1. Install

```bash
pip install maestro-fleet
mso version
```

Expected output: the current `Maestro vX.Y.Z` (see [the latest release](https://github.com/tavisbasing/Maestro/releases/latest) for the active tag). Run `mso version` after any upgrade to confirm the wheel resolved correctly.

The public PyPI distribution name is `maestro-fleet` (the unrelated `maestro` package on PyPI predates the rebrand). The Python import name is unchanged — `from maestro import …` works after install. Source remains private; the runtime licence check is the gate.

**Recommended for everyday use: install globally** (no venv). When you mix PowerShell, bash, and IDE-spawned shells against the same project, a global install means every shell sees the same `mso` without having to re-activate a venv. That's friendlier than a per-shell venv for most operators.

**When to use a venv instead:**
- You're running multiple Maestro versions side-by-side (e.g. validating an unreleased fix)
- You need to keep Maestro's deps isolated from another Python project on the same machine
- Corporate policy disallows global pip installs

```powershell
# venv path (only if needed)
python -m venv ${env:USERPROFILE}.venvsmaestro
& "$env:USERPROFILE\.venvsmaestro\Scripts\Activate.ps1"
pip install maestro-fleet
```

**Upgrade from v3.x?** Run `pip install --upgrade maestro-fleet`. See [MIGRATION-v4.md](MIGRATION-v4.md) for the full upgrade guide.

**Airgapped / restricted-egress operators:** see [docs/AIR-GAPPED.md](AIR-GAPPED.md) for the private-index install pattern.

**Windows:** Maestro's CLI works natively in PowerShell and cmd.exe. Claude Code CLI itself requires WSL2 on Windows — install WSL2 first if `claude --version` fails.

---

## 2. Activate a licence — only if you're on a paid tier

**Skip this step entirely if you're on the free community tier.** Maestro works fully without a
licence — `mso setup` never asks for one, never warns that one is missing, and never suggests
upgrading at community tier. If you don't have a licence key, go straight to
[step 3](#3-set-your-api-key).

If you *are* on **pro**, **team**, or **enterprise** (you have a licence key from your purchase or
your organisation):

```bash
mso licence activate <YOUR-KEY>
mso licence status
```

Your licence key is issued via Polar at activation time — see [maestroai.com/pricing](https://maestroai.com/pricing) and the full guide in [docs/LICENCE.md](LICENCE.md). Activation requires the internet (one-shot online verification); after that, you have a 14-day offline grace window.

If you're operating in an air-gapped or restricted-egress environment, see [docs/AIR-GAPPED.md](AIR-GAPPED.md) for the staging-machine pattern.

Not sure which tier you're on? Run `mso licence status` — no licence activated prints `No licence
activated — running at community tier (this is not an error).`

---

## 3. Set your API key

Maestro crews call Claude via the Anthropic API.

```bash
export ANTHROPIC_API_KEY=sk-ant-...       # macOS / Linux / WSL
```

Get a key at [console.anthropic.com/settings/keys](https://console.anthropic.com/settings/keys).

---

## 4. Run the quickstart

```bash
mso quickstart
```

This single command:

1. **Pre-flight checks** — verifies Python 3.9+, Claude Code CLI, and your API key.
2. **Initialises a demo workspace** — scaffolds `.mso/` in the current directory.
3. **Creates a demo voyage** — three orders (NAV → SHP → BOS) that write and verify a `hello.py` script.
4. **Dispatches the fleet** — streams live crew output as each order executes.
5. **Prints a summary** — elapsed time, order count, and next-step commands.

### Optional flags

| Flag | Effect |
|------|--------|
| `--project ACRONYM` | Use a custom project acronym (default: `DEMO`) |
| `--crews N` | Number of parallel crews to dispatch (default: 1, max: 3) |
| `--repo ORG/NAME` | Link the demo to a GitHub repo (mode B — explicit, validates via `gh api`) |
| `--no-link-repo` | Local-only mode (mode C) — `git init` workspace, run demo on a local voyage branch, no push, no PR |
| `--force` | Overwrite an existing repo entry in `.mso/config/projects.json` |
| `--no-demo` | Skip the demo voyage; only verify environment and init workspace |
| `--skip-checks` | Skip pre-flight checks (for CI use) |

### Repo-link modes

The demo voyage runs against a real working tree so crews can commit, push, and open PRs end-to-end. Quickstart picks one of three modes:

| Mode | Trigger | What happens |
|------|---------|--------------|
| **A — Interactive** | TTY, no flags | Prompts: *"Link this demo to a GitHub repo? (Y/n)"*. If yes, asks for `org/name`, validates via `gh api`, writes to `projects.json`. If no, falls through to mode C. |
| **B — Explicit** | `--repo org/name` | Skips the prompt, validates, links. Errors fail the quickstart (use `--no-link-repo` to opt out). |
| **C — Local-only** | `--no-link-repo`, or no-TTY (CI) | Auto-`git init` if needed, creates a local `voyage/VOY-...` branch. No GitHub, no push, no PR. Ideal for CI and offline demos. |

All three modes set `voyageBranch` on the demo orders and voyage; modes A/B also set `targetRepo`. Without these, the dispatcher falls through a non-functional path and the demo silently produces no work — fixed in v2.5.4 (FTR-ADM-2026-0128).

---

## 5. What to expect

```
✓ API key found
✓ Claude Code detected (1.x.x)
✓ Python version OK
✓ Environment ready

Initialising demo workspace...
✓ Workspace initialised (.mso/)

✓ Demo voyage created  (VOY-DEMO-2026-0001)
✓ 3 orders queued      (NAV-DEMO-2026-0001 · FTR-DEMO-2026-0001 · BOS-DEMO-2026-0001)

Dispatching 1 crew(s)…
[NAV] Drafting hello-world plan…
[SHP] Implementing hello.py…
[BOS] Verifying hello.py…

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 Maestro quickstart complete! 🎉

 3 orders completed in 2m 34s
 Results: .mso/orders/complete/

 Next steps:
   mso status          — monitor a real fleet
   mso docs            — full documentation
   mso voyage create   — start a real voyage
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Troubleshooting

### `mso: command not found`

pip installed the entry point into a directory not on your `PATH`.

```bash
# Linux / macOS / WSL
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc && source ~/.bashrc

# Verify
mso version
```

On Windows, add `%APPDATA%\Python\PythonXX\Scripts` to your user `PATH` (replace `XX` with your Python version, e.g. `311`).

### `ANTHROPIC_API_KEY is not set`

Set the environment variable before running `mso quickstart`. See step 3 above.

### `Claude Code CLI not found on PATH`

Install Claude Code from [claude.ai/code](https://claude.ai/code), then verify:

```bash
claude --version
```

### `No licence found. Run mso licence activate <KEY>`

You haven't activated yet. Run `mso licence activate <YOUR-KEY>`. See [docs/LICENCE.md](LICENCE.md) for the full activation flow + recovery paths.

### `Python 3.9+ required`

Upgrade Python. On Ubuntu/Debian:

```bash
sudo apt update && sudo apt install python3.12
```

(macOS via Homebrew: `brew install python@3.12`. Windows: install from [python.org/downloads](https://www.python.org/downloads/).)

### Crew crashes immediately

Check `.mso/crews/` for error logs. Common causes: insufficient API quota, network timeout, or a rate limit on the Anthropic API. Wait a moment and re-run `mso quickstart`.

### Stale PID file from a previous run

```bash
rm .mso/dispatcher.pid    # remove stale lock
mso quickstart
```

---

## What's next?

| Topic | Document |
|-------|---------|
| Which tier am I, and what's my path? | [docs/START-HERE.md](START-HERE.md) |
| Deeper setup wizard (`mso setup`) | [docs/SETUP.md](SETUP.md) |
| Full setup walkthrough | [docs/GETTING-STARTED.md](GETTING-STARTED.md) |
| Team/Enterprise onboarding | [docs/ENTERPRISE-QUICKSTART.md](ENTERPRISE-QUICKSTART.md) |
| `mso licence` reference | [docs/LICENCE.md](LICENCE.md) |
| Air-gapped / restricted-egress | [docs/AIR-GAPPED.md](AIR-GAPPED.md) |
| All CLI commands | [docs/CLI-REFERENCE.md](CLI-REFERENCE.md) |
| Orders and voyages | [docs/ORDERS-AND-VOYAGES.md](ORDERS-AND-VOYAGES.md) |
| Crew roles | [docs/ROLES-GUIDE.md](ROLES-GUIDE.md) |
| Move `.mso/` bookkeeping into its own repo | [docs/ARTEFACT-REPO.md](ARTEFACT-REPO.md) |
| Troubleshooting (full) | [docs/TROUBLESHOOTING.md](TROUBLESHOOTING.md) |

---

*Maestro Maestro v2.5.0 · [maestroai.com](https://maestroai.com) · Licensing enquiries: [GitHub Issues](https://github.com/Maestrodevs).*
