# Configuring your stack (`providers`)

Maestro ships with GitHub support out of the box, but the patrol (`mso doctor`)
and the resident LEAD sub-agent don't hard-code GitHub — they ask for a
**capability** (source control, CI, issue tracking, deployment) and Maestro
resolves whichever provider your workspace is configured for. If your
organisation runs Bitbucket, Jenkins, or Jira instead, the checks that need
those capabilities degrade honestly instead of silently assuming GitHub.

## The four capability kinds

| Kind | What it's used for | Shipped today |
|------|---------------------|----------------|
| `scm` | Pull request state — open/merged/draft, review threads | `github` |
| `ci` | Build/check status for a pull request | `github_actions` |
| `issues` | Reading and updating a linked issue | `github_issues` |
| `deploy` | Last-deployment status for an environment | *(none shipped yet)* |

Every kind also has a built-in `none` provider — the honest default when a
capability isn't wired up. A check that depends on an unconfigured or
unreachable provider is always reported as **skipped, with a reason** — never
silently passed and never counted as a false success. Run `mso doctor
--explain` to see, per kind, which provider is currently resolved and which
configuration tier supplied it.

Bitbucket, Jenkins, Jira, and real deployment providers are on the roadmap.
Because every check talks to the capability interface and never to "GitHub"
by name, adding one of those is additive — it does not change how your
existing configuration or checks behave.

## Configuring a provider

Add a `providers` block to `.mso/config/workspace.json`:

```jsonc
{
  "providers": {
    "scm":    { "id": "github", "config": { "slug": "your-org/your-repo" } },
    "ci":     { "id": "github_actions" },
    "issues": { "id": "github_issues" },
    "deploy": { "id": "none" }
  }
}
```

Each entry takes an `id` (which provider to use for that kind) and an
optional `config` object with provider-specific settings. For the shipped
GitHub providers:

| Config key | Purpose |
|------------|---------|
| `slug` | `owner/repo` — inferred from the repository if omitted |
| `host` | Override the GitHub host (e.g. a GitHub Enterprise Server instance) |
| `repoPath` | Local checkout path, if it differs from the workspace root |

Omit the `providers` block entirely and Maestro picks a sensible default: for
`scm`/`ci`/`issues` it uses the GitHub providers if the `gh` CLI is installed
and authenticated, otherwise `none`. `deploy` has no shipped provider yet, so
it is always `none` until one exists. Nothing assumes GitHub is present —
absence is detected, never guessed.

## Where configuration comes from

A `providers` block resolves the same way the rest of your workspace's
governed settings do — the most specific applicable source wins:

1. A signed governance bundle (Enterprise only)
2. Your workspace's own `.mso/config/workspace.json`
3. The shipped default described above

A division/team pack applied at `mso init` time can pre-populate the
`workspace.json` entry for you, so day-to-day resolution is really "did a
bundle override this, otherwise use what's in `workspace.json`."

## Credentials

Provider credentials are never written as plaintext in `workspace.json`.
Use a `secret://` reference in the `config` block — the same secret-resolution
mechanism the rest of Maestro's integrations already use — and Maestro
resolves it at the point of use, never a second, provider-specific credential
path.

## Egress

A provider's host must be on your workspace's allowed outbound destinations
list if you run in restricted or air-gapped egress mode. A host that isn't
allowed surfaces as a skipped check naming the reason (`host not permitted`),
not a crash and not a silent pass — run `mso data-flow` to review and manage
that allowlist (see [CLI-REFERENCE.md](CLI-REFERENCE.md)).

## See also

- [PATROL.md](PATROL.md) — the fleet-health checks that consume these providers
- [ROLE-OVERLAYS.md](ROLE-OVERLAYS.md) — customising role behaviour, including the resident LEAD agent
