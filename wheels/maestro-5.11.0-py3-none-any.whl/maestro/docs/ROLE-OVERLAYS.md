# Maestro — Customising Roles for Your Organisation

> Maestro ships 7 canonical roles ([PLN](../roles/PLN.md), [BLD](../roles/BLD.md), [TST](../roles/TST.md), [DOC](../roles/DOC.md), [SEC](../roles/SEC.md), [REL](../roles/REL.md), [LEAD](../roles/LEAD.md)) as a foundation. This guide shows how to layer your organisation's specific responsibilities, tools, paths, and deliverable templates on top — without forking the core definitions.

---

## Contents

- [When to use overlays](#when-to-use-overlays)
- [When NOT to use overlays](#when-not-to-use-overlays)
- [Quickstart (5 minutes)](#quickstart-5-minutes)
- [Frontmatter reference](#frontmatter-reference)
- [Section-level merge directives](#section-level-merge-directives)
- [Worked examples](#worked-examples)
- [TST role specifics](#tst-role-specifics)
- [LEAD role specifics: the resident agent and `must_not`](#lead-role-specifics-the-resident-agent-and-must_not)
- [CLI reference](#cli-reference)
- [Migration from role-paths.json](#migration-from-role-pathsjson)
- [Common pitfalls](#common-pitfalls)
- [See also](#see-also)

---

## When to use overlays

Use overlays when you need to add org-specific behaviour on top of the canonical role definitions:

- Add compliance-mandated steps to the SEC role (e.g. PCI-DSS scan, internal pen-test gate)
- Add organisation-specific test infrastructure to the TST role (e.g. k6 load test against staging, your APM dashboard check)
- Replace generic permission paths with your monorepo's actual structure
- Swap the Claude model selection (e.g. use Opus 4.7 for a high-stakes REL role)
- Add your team's internal handoff conventions to the transition prose
- Extend the TST `test_categories` matrix with custom categories (e.g. mutation testing, contract testing)
- Add org-specific tools to a role's allowed tool list

---

## When NOT to use overlays

- **Renaming roles for stylistic flavour** — use the [persona system](PERSONAS.md) instead. The persona system renames roles workspace-wide without touching role files.
- **Project-specific path mapping only** — the simpler `.mso/config/role-paths.json` still works (legacy). Reserve overlays for richer customisation.
- **Removing required role behaviours** — overlays extend or replace sections; the merge system does not support deleting individual bullets from a core list. If you need to remove a core behaviour, use `replace` on the whole section.
- **Global config that applies to all roles** — use `workspace.json` instead.

---

## Quickstart (5 minutes)

The following example adds a custom load-testing step to the TST role.

**Step 1 — Dump the current core role to your overlay directory:**

```bash
mkdir -p .mso/config/roles
mso roles show TST --core > .mso/config/roles/TST.md
```

**Step 2 — Edit `.mso/config/roles/TST.md`.**

Add `"extends": "core"` to the JSON frontmatter and set the `sections` merge directives you intend to use. Keep only the sections you want to customise — delete the rest:

```markdown
---
{
  "role_code": "TST",
  "role_name": "Tester",
  "extends": "core",
  "sections": {
    "must_do": "extend"
  }
}
---

## must_do

- **Run k6 load tests** (when `qa.load: true` in workspace.json):
  ```bash
  k6 run tests/load/smoke.js --env BASE_URL=$STAGING_URL
  ```
```

**Step 3 — Validate the overlay:**

```bash
mso roles validate
# → exit 0 if all valid
```

**Step 4 — Preview what changed:**

```bash
mso roles diff TST
# → unified diff: core vs effective merged role
```

**Step 5 — Inspect the effective role the dispatcher will use:**

```bash
mso roles show TST
```

**Step 6 — Commit the overlay:**

```bash
git add .mso/config/roles/TST.md
git commit -m "role: extend TST with org-specific k6 load testing"
```

**Step 7 — Dispatch:**

```bash
mso dispatch
# TST crews now see your extended must_do list
```

---

## Frontmatter reference

Every role file (core or overlay) opens with a JSON block between `---` delimiters.

```markdown
---
{
  "role_code": "TST",
  ...
}
---
```

### Required fields

| Field | Type | Description |
|-------|------|-------------|
| `role_code` | string | One of `PLN`, `BLD`, `TST`, `DOC`, `SEC`, `REL`, `LEAD`. Must match the filename. |
| `role_name` | string | Human-readable role name. Overlays may override this for org-specific display names. |

### Optional fields (overlay-relevant)

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `extends` | `"core"` or absolute path | — | Signals this file is an overlay. Use `"core"` to extend from the pip-package role. |
| `model` | string | core value | Override the Claude model for this role. Must be a known model ID (see below). |
| `tools` | list of strings | core list | Additional tools to allow. The overlay list is **unioned** with the core list — existing core tools are always included. |
| `sections` | object | `{}` | Per-section merge directives. Keys are section names (lowercase + underscored); values are `"extend"`, `"override"`, or `"replace"`. |
| `test_categories` | object | core value | Override the TST role's mandatory/optional category matrix. Replaces the core matrix entirely. |

### Known model IDs

| Model | ID |
|-------|----|
| Claude Sonnet 4.6 | `claude-sonnet-4-6` |
| Claude Opus 4.7 | `claude-opus-4-7` |
| Claude Haiku 4.5 | `claude-haiku-4-5-20251001` |

### Frontmatter merge behaviour

When an overlay is applied, frontmatter fields merge as follows:

| Field | Merge behaviour |
|-------|----------------|
| `model` | Overlay value replaces core value |
| `tools` | Union: overlay tools appended after core tools (no duplicates) |
| `test_categories` | Overlay value replaces core value entirely |
| `role_name` | Overlay value replaces core value |
| `sections` | Overlay value replaces core `sections` map in the effective frontmatter |
| Any other field | Preserved as-is (overlay fields not in core are added) |

---

## Section-level merge directives

Each section in a role file is a Markdown block starting with an H2 heading (`## section_name`). The canonical section names are:

| Section | Typical content type | Description |
|---------|---------------------|-------------|
| `overview` | prose | One-paragraph role summary |
| `responsibilities` | bulleted list | What this role does |
| `permissions` | table | READ/WRITE/EXECUTE scopes |
| `paths` | subsections + tables | Input/output file locations |
| `must_do` | bulleted list | Mandatory steps, in order |
| `must_not` | bulleted list | Prohibited actions |
| `deliverables` | subsections | Required output artifacts with templates |
| `prompt_preamble` | prose | Instructions injected at session start |
| `transitions` | table or prose | Entry/exit conditions between roles |
| `quality_checklist` | bulleted list | Pre-completion checklist |
| `branch_discipline` | prose + code | Branch guard instructions |

You may also declare new sections not present in the core role — they are appended to the effective role.

### The three directives

#### `extend` — append to core

User content is appended after the core content. Behaviour depends on section type:

- **Bulleted list:** user bullets appended after core bullets
- **Table:** user data rows appended after core data rows (header not duplicated)
- **Prose:** user block appended after core block with a blank line separator
- **Subsections:** user subsection content appended after core subsections

Use `extend` when you want to **add** org-specific items without losing core items.

```markdown
---
{
  "role_code": "TST",
  "role_name": "Tester",
  "extends": "core",
  "sections": {
    "must_do": "extend"
  }
}
---

## must_do

- **Run your org's integration smoke test** after the standard suite:
  ```bash
  ./scripts/smoke-test.sh --env staging
  ```
```

#### `override` — selective replacement (tables) or full replacement (prose)

For **tables:** user rows are matched against core rows by first-column value. Matching rows are replaced; new rows are appended.

For **prose and subsections:** behaves the same as `replace`.

Use `override` when you want to **swap specific table rows** (e.g. replace a permission entry) while keeping the rest of the table.

```markdown
---
{
  "role_code": "SEC",
  "role_name": "Security Auditor",
  "extends": "core",
  "sections": {
    "permissions": "override"
  }
}
---

## permissions

| Permission | Scope | Details |
|------------|-------|---------|
| WRITE | Reports only | `.mso/reports/security/`, `.mso/reports/investigation/`, `compliance/pci-reports/` |
```

#### `replace` — discard core, use overlay body verbatim

The entire core section body is discarded and replaced with the overlay body.

Use `replace` when the core content does not apply to your org and you want to write the section from scratch.

```markdown
---
{
  "role_code": "TST",
  "role_name": "Tester",
  "extends": "core",
  "sections": {
    "paths": "replace"
  }
}
---

## paths

### INPUT Locations

| Resource | Path | Purpose |
|----------|------|---------|
| Builder Handoff | `.mso/handoffs/{ORDER-ID}/BLD-to-TST.md` | Files to test |
| Source Code | `src/`, `libs/`, `services/` | Monorepo layout |

### OUTPUT Locations

| Test Type | Path |
|-----------|------|
| Unit Tests | `src/{service}/tests/unit/` |
| Integration Tests | `src/{service}/tests/integration/` |
| QA Report | `.mso/reports/qa/QA-{ORDER-ID}.md` |
```

### Directive × section-type matrix

| Section type | `extend` | `override` | `replace` |
|--------------|----------|------------|-----------|
| `bulleted_list` | Append user bullets | Same as extend | Discard core, use user |
| `table` | Append user rows (skip header) | Match first col, replace/add rows | Discard core, use user |
| `prose` | Append user block after core | Same as replace | Discard core, use user |
| `subsections` | Append user subsections after core | Same as replace | Discard core, use user |

---

## Worked examples

### Example 1 — Extending TST with k6 load tests

This overlay adds k6 load testing as a SHOULD DO, gated on `workspace.json: qa.load: true`.

```markdown
---
{
  "role_code": "TST",
  "role_name": "Tester",
  "extends": "core",
  "sections": {
    "must_do": "extend",
    "quality_checklist": "extend"
  }
}
---

## must_do

- **Run k6 load tests** (when `qa.load: true` in workspace.json):
  ```bash
  k6 run tests/load/smoke.js --env BASE_URL=$STAGING_URL --vus 10 --duration 30s
  ```
  - Accept p95 latency ≤ 500 ms, error rate ≤ 1%
  - Write summary to `.mso/reports/qa/LOAD-{ORDER-ID}.txt`

## quality_checklist

- [ ] k6 smoke test executed (if `qa.load: true`) and p95 latency within threshold
- [ ] Load test summary saved to `.mso/reports/qa/LOAD-{ORDER-ID}.txt`
```

### Example 2 — Replacing SEC permissions for a monorepo layout

This overlay replaces the SEC role's `permissions` table and `paths` section with org-specific paths appropriate for a monorepo. The `responsibilities` section is extended with a mandatory cardholder data scan.

```markdown
---
{
  "role_code": "SEC",
  "role_name": "Security Auditor",
  "extends": "core",
  "sections": {
    "permissions": "replace",
    "paths": "replace",
    "responsibilities": "extend"
  }
}
---

## permissions

| Permission | Scope | Details |
|------------|-------|---------|
| READ | Full monorepo | `apps/`, `libs/`, `infra/`, `shared/` |
| WRITE | Reports only | `.mso/reports/security/`, `.mso/reports/investigation/`, `compliance/pci-reports/` |
| EXECUTE | Scans | `mso security scan`, `mso security review`, `./scripts/pci-scan.sh` |

**Explicitly NOT Permitted:**
- Fixing security issues (report only)
- Modifying any source, test, or infrastructure files

## paths

### INPUT Locations

| Resource | Path | Purpose |
|----------|------|---------|
| Handoff | `.mso/handoffs/{ORDER-ID}/` | Files to review |
| Cardholder data paths | `apps/payments/`, `libs/billing/` | PCI-scope code |
| Infrastructure | `infra/terraform/`, `infra/k8s/` | Cloud config review |

### OUTPUT Locations

| Report Type | Path | Naming |
|-------------|------|--------|
| Security Report | `.mso/reports/security/` | `SEC-{ORDER-ID}.md` |
| PCI Scan Report | `compliance/pci-reports/` | `PCI-{ORDER-ID}.md` |
| Investigation | `.mso/reports/investigation/` | `INV-{ORDER-ID}.md` |

## responsibilities

6. **PCI-DSS Cardholder Data Scan**
   - Run `./scripts/pci-scan.sh` against `apps/payments/` and `libs/billing/`
   - Document any cardholder data exposure findings in a PCI report at `compliance/pci-reports/PCI-{ORDER-ID}.md`
   - CRITICAL findings in PCI scope block voyage sign-off regardless of other gates
```

### Example 3 — Swapping Claude model for REL role

This minimal overlay swaps the REL role to Opus 4.7 for higher-stakes release verification. No sections are modified — only the model is overridden.

```markdown
---
{
  "role_code": "REL",
  "role_name": "Releaser",
  "extends": "core",
  "model": "claude-opus-4-7"
}
---
```

No section bodies are needed — the empty overlay inherits the full core REL definition and only changes the model.

---

## TST role specifics

### Test category matrix

The TST role has a two-tier category system controlled by `workspace.json`:

#### Mandatory (every order)

| Category | Minimum bar |
|----------|-------------|
| `unit` | All new functions and classes have unit tests |
| `integration` | Service boundaries exercised |
| `regression` | Full test suite passes; zero new failures introduced |

#### Optional (workspace.json gated)

| Category | workspace.json key | Default |
|----------|--------------------|---------|
| `e2e` | `qa.e2e` | `false` |
| `performance` | `qa.performance` | `false` |
| `load` | `qa.load` | `false` |
| `security` | `qa.security` | `false` |

To enable an optional category for all orders in your workspace:

```json
{
  "qa": {
    "load": true,
    "e2e": true
  }
}
```

### Adding a custom test category

Use a `test_categories` overlay to add org-specific categories. The overlay value **replaces** the core matrix entirely, so you must include the existing mandatory and optional lists:

```markdown
---
{
  "role_code": "TST",
  "role_name": "Tester",
  "extends": "core",
  "test_categories": {
    "mandatory": ["unit", "integration", "regression"],
    "optional": ["e2e", "performance", "load", "security", "mutation"]
  },
  "sections": {
    "must_do": "extend"
  }
}
---

## must_do

- **Run mutation tests** (when `qa.mutation: true` in workspace.json):
  ```bash
  mutmut run --paths-to-mutate src/
  mutmut results
  ```
  - Target mutation score ≥ 80%
  - Write summary to `.mso/reports/qa/MUTATION-{ORDER-ID}.txt`
```

Enable in workspace.json:

```json
{
  "qa": {
    "mutation": true
  }
}
```

---

## LEAD role specifics: the resident agent and `must_not`

Available on Pro, Team, and Enterprise: `mso lead start` runs the LEAD role as
a **resident sub-agent** — a local per-project background process that keeps
watching your fleet instead of only acting while you have an interactive
session open. It reads the same [patrol](PATROL.md) findings you'd see from
`mso doctor`, and within a narrow, reversible set of housekeeping actions it
may act on its own and report what it did afterward.

Because the resident agent can act without a person reading the result
first, its `must_not` section — the list of things LEAD never does
autonomously (auto-merge a PR, change scope, resolve a security finding
unattended, bypass the branch guard, modify production source directly) — is
treated differently from every other overlay:

| Directive on `must_not` | Interactive LEAD (your terminal session) | Resident LEAD (`mso lead start`) |
|---|---|---|
| `extend` | Applied normally | Applied normally — add your own org-specific prohibitions |
| `override` | Applied normally | **Refused** — the core `must_not` list is used, unchanged |
| `replace` | Applied normally | **Refused** — the core `must_not` list is used, unchanged |

A refused directive is not a validation failure — your overlay still loads,
and every other section (and every other role) still merges exactly as
declared. Only the `must_not` directive itself is dropped in favour of the
core list, a warning is printed, and the refusal is written to
`.mso/logs/lifecycle.log` so it's visible, not silent.

**Why this one section is special.** Every other overlay customises what a
role *does*. `must_not` on `LEAD` is the ceiling on what it may do *without
asking you first*. Letting a single workspace-local file quietly shorten that
list would mean a resident agent's autonomy could widen itself without
anyone deciding that on purpose — the same reasoning that governs a signed
policy bundle elsewhere in Maestro. If you want to add a prohibition specific
to your organisation, `extend` still works exactly as it does for any other
role; this restriction only blocks *shrinking* the list, and only for the
resident agent, and only for `LEAD`.

Community does not include the resident LEAD agent — Community workspaces
manage voyages and orders manually, through your interactive LEAD session
only, so this restriction doesn't apply there.

---

## CLI reference

| Command | Description |
|---------|-------------|
| `mso roles list` | List all 7 canonical roles — code, name, model, and whether an overlay is applied |
| `mso roles show {CODE}` | Print the effective merged role (core + overlay) |
| `mso roles show {CODE} --core` | Print the core role only (ignores any overlay) |
| `mso roles show {CODE} --overlay-only` | Print just the user overlay file (if present) |
| `mso roles show {CODE} --json` | Print the parsed RoleDefinition as JSON |
| `mso roles diff {CODE}` | Unified diff: core vs effective merged role |
| `mso roles validate` | Validate all role files (core + overlays); exit 0 if all valid |
| `mso roles migrate-paths` | Migrate legacy `role-paths.json` entries to per-role overlay files |

---

## Migration from `role-paths.json`

Prior to the overlay system, path customisation was done via `.mso/config/role-paths.json`. That file is still read but deprecated — a `DeprecationWarning` is emitted on each dispatch.

### Migration steps

**Step 1 — Run the automated migrator:**

```bash
mso roles migrate-paths
# Creates .mso/config/roles/{CODE}.md for each role that has entries in role-paths.json
# role-paths.json is left in place (not deleted) until you confirm the migration
```

**Step 2 — Review the generated overlays:**

```bash
mso roles validate   # should exit 0
mso roles diff TST   # confirm paths section looks right
```

**Step 3 — Remove the legacy file:**

```bash
git rm .mso/config/role-paths.json
git add .mso/config/roles/
git commit -m "role: migrate role-paths.json to per-role overlays"
```

### Manual mapping

If you prefer to migrate by hand, the mapping is:

| role-paths.json key | Overlay section | Directive |
|--------------------|-----------------|-----------|
| `{CODE}.input` | `paths` (INPUT table rows) | `override` |
| `{CODE}.output` | `paths` (OUTPUT table rows) | `override` |
| `{CODE}.prohibited` | `paths` (PROHIBITED table rows) | `override` |

Example — `role-paths.json` entry:

```json
{
  "TST": {
    "output": {
      "Unit Tests": "src/{service}/tests/unit/"
    }
  }
}
```

Equivalent overlay (`paths` section, `override` directive):

```markdown
---
{
  "role_code": "TST",
  "role_name": "Tester",
  "extends": "core",
  "sections": {
    "paths": "override"
  }
}
---

## paths

### OUTPUT Locations (Write Tests To)

| Test Type | Path | Naming Convention |
|-----------|------|-------------------|
| **Unit Tests** | `src/{service}/tests/unit/` | `test_{module}.py` |
```

The `override` directive matches on the first column (`Test Type`) — the `Unit Tests` row in core is replaced with your org-specific path; all other rows are kept.

---

## Common pitfalls

### Missing `role_code` or `role_name`

Both are required in every overlay file — even if you only want to change the model. The validator will reject the file without them.

### Section heading mismatch

The section key in `frontmatter.sections` must match the H2 heading in the file body after normalisation (lowercase, spaces/hyphens → underscores). The heading `## must_do` normalises to `must_do`; `## Must Do` and `## must do` also normalise correctly. Mismatch means the section body is never found and the core is used unchanged (with a warning).

Run `mso roles diff {CODE}` after editing — if your change doesn't appear, a heading mismatch is the most common cause.

### `tools` always extends, never replaces

Adding `"tools": ["k6"]` to your TST overlay gives the crew `[Glob, Grep, Read, Write, Edit, Bash, k6]` — not just `[k6]`. The tools list is always a union. There is no `tools_replace` option. If you genuinely need to restrict the core tool list, contact the Maestro maintainers — tool restriction is enforced at the CLI layer via `--disallowedTools`, not the overlay system.

### Model override ignored

The effective model is determined by `load_effective_role()` which merges the overlay. If `mso roles show {CODE} --json | jq .frontmatter.model` still shows the core model after adding `"model"` to your overlay, confirm the overlay file is at `.mso/config/roles/{CODE}.md` (exact uppercase code, no suffix).

### Conflicting model overrides

If both the overlay and `workspace.json` specify a model, the overlay wins at the role-definition layer. Project-level `workspace.json` settings that reference a specific model for dispatch may override again at dispatch time. Check the effective model with `mso roles show {CODE} --json` to confirm what the crew will actually use.

### Sections without bodies are silently skipped

Declaring a directive in `frontmatter.sections` with no matching body in the file produces a warning and falls back to the core. Always include the section body when you declare a directive for it.

### Forgot to commit the overlay

Overlays are picked up from the filesystem at dispatch time. If you add `.mso/config/roles/` to `.gitignore` by accident, other operators and CI won't see your customisations. Commit overlay files to the repository.

---

## See also

- [ROLES-GUIDE.md](ROLES-GUIDE.md) — canonical role reference with descriptions and handoff patterns
- [PERSONAS.md](PERSONAS.md) — for renaming roles via the persona system (orthogonal to overlays)
- [CHAIN-OF-COMMAND.md](CHAIN-OF-COMMAND.md) — role sequence + handoff conventions
- [CONFIG-MODELS.md](CONFIG-MODELS.md) — full model selection rationale per role
