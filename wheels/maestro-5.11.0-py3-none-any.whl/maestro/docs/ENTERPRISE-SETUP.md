# Maestro — Enterprise Setup Guide

This guide covers deploying Maestro for multi-team enterprise use: network requirements, data residency, compliance notes, and SSO configuration.

> **This guide applies to Team and Enterprise tier only.** For individual and small-team setup at
> community or pro tier, see [GETTING-STARTED.md](GETTING-STARTED.md). Not sure which tier you're
> on? Start at [START-HERE.md](START-HERE.md).
> For the enforced tier limits (community/pro/team/enterprise), see [LICENCE.md](LICENCE.md#tier-limits-enforced-in-code-not-just-advertised).
>
> **Getting a device onboarded quickly?** The day-to-day onboarding path for an individual
> engineer — activate licence, run `mso setup`, let the org's enrolment profile do the rest — is
> [ENTERPRISE-QUICKSTART.md](ENTERPRISE-QUICKSTART.md). *This* guide covers the surrounding
> deployment concerns: network, residency, compliance, and the governed-mode/break-glass mechanics
> in [§6](#6-governed-mode-and-break-glass). The admin-side authoring work (signing a policy
> bundle, authoring the enrolment profile devices consume, unattended imaging) is
> [ENTERPRISE-ADMIN-GUIDE.md](ENTERPRISE-ADMIN-GUIDE.md).
>
> **Version scope:** This guide targets **v2.5.0** enterprise features (licence keys via `mso licence activate`, `MAESTRO_LICENCE_KEY` for non-interactive). The legacy GitHub-collaborator PAT path is retained as a transitional fallback only. Sections referencing licence-key formats and offline-grace windows predate the four-tier licence core described in [LICENCE.md](LICENCE.md) and [START-HERE.md](START-HERE.md) — where the two disagree, treat `LICENCE.md` as authoritative for current `mso licence` behaviour.

---

## Contents

1. [Overview](#1-overview)
2. [Network Requirements](#2-network-requirements)
3. [Multi-Team Deployment](#3-multi-team-deployment)
4. [Data Residency](#4-data-residency)
5. [Compliance Notes](#5-compliance-notes)
6. [Governed Mode and Break-Glass](#6-governed-mode-and-break-glass)
7. [SSO (Enterprise IdP)](#7-sso-enterprise-idp)
8. [Licence Key Management](#8-licence-key-management)
9. [Air-Gap and Restricted Networks](#9-air-gap-and-restricted-networks)
10. [Deployment Checklist](#10-deployment-checklist)
11. [Onboarding via an Enrolment Profile](#11-onboarding-via-an-enrolment-profile)

---

## 1. Overview

Maestro is a local orchestration framework. The core system runs entirely on the developer's machine or CI host — there is no Maestro application server, no data sent to Maestro infrastructure, and no persistent cloud state.

**What runs locally:**
- `fleet-runner.py` (dispatcher)
- `fleet_monitor.py` (dashboard)
- All crew Claude Code sessions
- All workspace state (orders, voyages, plans, usage records)

**What leaves the local machine:**
- Claude Code API calls to Anthropic (via `ANTHROPIC_API_KEY`)
- Git operations (push/pull to your own source repositories)
- Licence key validation (local HMAC check — no server call by default; see [Section 9](#9-air-gap-and-restricted-networks))

Enterprise deployments typically involve:
- One Maestro workspace per team or department
- Shared source repositories accessed via crew managed clones
- Centralised API key management
- Workspace backup to a shared store

---

## 2. Network Requirements

### Outbound connections required

| Destination | Port | Purpose | Required |
|-------------|------|---------|---------|
| `api.anthropic.com` | 443 (HTTPS) | Claude Code API (crew sessions) | Yes |
| `github.com` (or your Git host) | 443 / 22 | Repo clone and push for crew work | Yes |
| `pypi.org` / GitHub | 443 | pip install (install time only) | Install only |

### Optional / non-mandatory

| Destination | Port | Purpose |
|-------------|------|---------|
| `github.com` API | 443 | GitHub collaborator auth fallback (not needed if using licence key) |

### Firewall configuration

At minimum, ensure outbound HTTPS to `api.anthropic.com` is permitted from the host(s) running Maestro. All Claude Code API traffic uses HTTPS (TLS 1.2 or later).

If your organisation uses a TLS-inspection proxy, ensure the proxy CA certificate is trusted on the Maestro host. Claude Code uses the system certificate store.

### Proxy support

Set standard proxy environment variables before running Maestro commands:

```bash
export HTTPS_PROXY=https://proxy.your-org.internal:8080
export HTTP_PROXY=http://proxy.your-org.internal:8080
export NO_PROXY=localhost,127.0.0.1,your-internal-git-host
```

These are inherited by all crew Claude Code subprocesses automatically.

---

## 3. Multi-Team Deployment

### One workspace per team (recommended)

Each team maintains its own Maestro workspace containing that team's projects, orders, and voyages. This provides clear ownership boundaries and prevents cross-team order interference.

```
/workspaces/
├── team-frontend/          # Frontend team workspace
│   ├── .maestro/
│   └── ...
├── team-backend/           # Backend team workspace
│   ├── .maestro/
│   └── ...
└── team-platform/          # Platform team workspace
    ├── .maestro/
    └── ...
```

### Shared source repositories

Each workspace references one or more source repositories via `projects.json`. Multiple teams can reference the same source repository — each workspace maintains its own voyage branch namespace to avoid conflicts.

Configure different `voyageBranchPattern` values per team to avoid branch collisions:

```json
{
  "projects": {
    "FRONTEND": {
      "repo": "your-org/frontend",
      "voyageBranchPattern": "voyage/frontend/{VOYAGE-ID}"
    }
  }
}
```

### CI/CD integration

Maestro can run in CI for automated order dispatch. Set the following in your CI environment:

```bash
# Required
export ANTHROPIC_API_KEY=<your-key>

# Legacy auth (transitional): GitHub collaborator PAT — kept as fallback
export MAESTRO_GITHUB_PAT=ghp_<your-pat>

# v2.5.0+: Licence-key auth (now the primary path)
# export MAESTRO_LICENCE_KEY=ADM-ENT-<hash>-<expiry>-<checksum>

# Recommended for CI
export MAESTRO_SKIP_AUTH=1    # Bypass auth for CI runs (if using trusted internal key)
```

The `MAESTRO_SKIP_AUTH=1` bypass is for trusted internal environments where auth has been handled upstream. Do not use this in publicly accessible environments.

### Resource limits

Each crew runs a Claude Code subprocess. Plan for:

| Teams | Max concurrent crews per team | Concurrent Claude sessions (worst case) |
|-------|-------------------------------|-----------------------------------------|
| 1 | 5 | 5 |
| 3 | 5 each | 15 |
| 5 | 5 each | 25 |

Anthropic API rate limits apply per API key. For large multi-team deployments, consider separate API keys per team or per workspace to distribute rate limits.

---

## 4. Data Residency

### Where workspace data lives

All Maestro workspace data is local to the machine or file server where the workspace is stored. Maestro does not transmit workspace content to any Maestro-operated service.

| Data type | Location | Leaves the machine? |
|-----------|----------|---------------------|
| Orders, voyages, plans | `\.maestro/` directories | No (unless you back up to cloud storage) |
| Crew prompts and context | `.maestro/crews/crewN/` | No |
| Token usage records | `.maestro/usage/` | No |
| Licence key | `~/.maestro/licence.json` | No |
| Source code changes | Your Git repositories | Yes (pushed to your Git host) |
| Claude API requests | Sent to `api.anthropic.com` | Yes — see below |

### Claude API data handling

Crew sessions send prompts (including order content and code context) to the Anthropic API. Anthropic's data handling policies apply. Review [Anthropic's privacy policy](https://www.anthropic.com/privacy) for details on:

- Data retention for API requests
- Training data opt-out (Enterprise API agreements)
- Data residency options (where available)

For workspaces containing sensitive code or data, review what context is included in crew prompts. Orders, file reads, and code snippets are sent as part of crew sessions.

### Backup data residency

`mso backup` creates ZIP archives in a local directory by default. If you copy these to cloud storage (S3, Azure Blob, etc.), the residency of backup data is governed by your cloud storage configuration — not by Maestro.

---

## 5. Compliance Notes

### Source code and IP

Maestro crews read and write source code in managed clones. All output is committed to your own Git repositories. No source code is retained by Maestro beyond the local crew working directories (which are wiped by `mso cleanup`).

### Audit trail

Maestro maintains the following audit-relevant records locally:

| Record | Location | Contents |
|--------|----------|---------|
| Order lifecycle | `.maestro/orders/` | Status, timestamps, completion metadata |
| Voyage history | `.maestro/voyages/` | Voyage ID, orders, completion status |
| Crew activity | `.maestro/crews/crewN/activity.jsonl` | Per-tool-call structured log |
| Token usage | `.maestro/usage/orders/` | Per-order token breakdown and cost |
| Lifecycle log | Fleet monitor output | Crew starts, completions, role transitions |

Enterprise tier includes **audit export** — a structured export of the above records for compliance tooling. See `mso usage --report` for token and cost reporting.

### Secrets and credentials

Maestro itself does not store secrets. The `ANTHROPIC_API_KEY` is passed as an environment variable to crew subprocesses. Do not commit your API key to workspace files or orders.

Crew sessions are configured via Claude Code's permissions system. Review `.claude/settings.json` to restrict what commands and file paths crew sessions may access.

### GDPR and PII

If your orders or source code contain personal data, ensure your Anthropic API usage agreement covers the relevant data categories. Maestro does not process or store PII independently — any PII in prompts is subject to Anthropic's API data handling terms.

---

## 6. Governed Mode and Break-Glass

Enterprise workspaces can run in **governed enforce mode** (`governance.governedMode: "enforce"` in `.mso/config/workspace.json`). This is Enterprise-only — the `governedMode` key is licence-tier gated where it is read, so setting it to `enforce`/`warn` on a community, Pro or Team workspace does not enable governed mode; it is ignored and Maestro prints why, rather than silently accepting the config. See [LICENCE.md](LICENCE.md#tier-limits-enforced-in-code-not-just-advertised). In enforce mode the guard-bypass escape hatches — `MAESTRO_BRANCH_GUARD_BYPASS` and `MAESTRO_PATH_GUARD_BYPASS` — are no longer honoured on their own. A bypass ("break-glass") is granted only when **all** of the following hold:

1. A justification is supplied via `MAESTRO_BREAKGLASS_REASON` (recorded in the audit log).
2. The caller is a **credential-backed / verified** identity (GitHub- or OIDC-verified) in an **enterprise** workspace.
3. That verified caller holds the `governance.breakglass` capability in the identity ACL.
4. The tamper-evident audit record lands durably first.

Every grant and refusal is written to the hash-chained audit log with the actor, timestamp, and reason.

### Break-glass requires a **signed** identity ACL

In enforce mode the identity ACL (`.mso/identity/access.json`) is trusted only when the identity integrity manifest (`.mso/identity/integrity.json`) is an **Ed25519-signed manifest** whose signature verifies against a key pinned **outside the workspace**. This closes a local-write forgery hole: an unsigned, self-adjacent manifest — the kind an on-host attacker could hand-write alongside a forged `access.json` — is refused.

> **Consequence:** the `mso identity` mutation commands (`add-user`, `add-group`, `set-group`, `acl set`, …) leave the manifest **unsigned**. Until the manifest is signed with your org key, the ACL is not trusted in enforce mode, so **break-glass will never grant** (and enterprise identity loads fail closed). After editing identity/ACL state you must re-sign.

### Signing the ACL

The signing key is an Ed25519 **seed** (32 bytes) that your organisation holds **off-client** — it is never stored in the workspace. Supply it only at signing time:

```bash
# The org seed as base64 (or hex), 32 bytes — kept off-client, e.g. in a secrets vault.
export MAESTRO_IDENTITY_SIGNING_KEY="<base64-or-hex-encoded-32-byte-seed>"

# ...or point at a file instead of the env var:
#   mso identity sign-acl --key-id acme-2026-q3 --key-file ~/keys/org-seed.b64

mso identity sign-acl --key-id acme-2026-q3
```

`sign-acl` recomputes the hash of every identity file, signs the manifest, writes `integrity.json`, and prints the **public** key to pin.

### Pinning the public key (runtime trust root)

At runtime Maestro resolves the manifest's signing key **only** from out-of-workspace locations — never from the workspace's own config (a local writer controls that). Pin the **public** half of your signing key in the OS-owned home keyring, `~/.maestro/trusted-keys.json`:

```json
{
  "keys": {
    "acme-2026-q3": {
      "algorithm": "ed25519",
      "publicKey": "<base64 32-byte Ed25519 public key printed by sign-acl>",
      "status": "active"
    }
  }
}
```

The `keyId` must match the `--key-id` you signed with. Rotate by publishing a new `active` key and marking the old one `retiring`, then `revoked` after the overlap window.

### End-to-end workflow

```bash
# 1. Grant a Captain the break-glass capability
mso identity acl set --principal group:captains --capability governance.breakglass --scope "*"

# 2. Sign the ACL with the org key (seed supplied off-client)
export MAESTRO_IDENTITY_SIGNING_KEY="<org-seed>"
mso identity sign-acl --key-id acme-2026-q3

# 3. Pin the printed public key in ~/.maestro/trusted-keys.json (once per machine)

# 4. A verified, capable operator can now break glass:
export MAESTRO_BREAKGLASS_REASON="prod incident #42"
export MAESTRO_BRANCH_GUARD_BYPASS=1
# ...the guarded operation is now honoured and audited.
```

> **Security note:** never weaken these requirements to unblock work. An unsigned manifest, a manifest signed by an unpinned key, a tampered ACL, or an unverifiable caller are all refused **by design** — that is the property that stops a local-write attacker from self-authorising a bypass.

---

## 7. SSO (Enterprise IdP)

> **Status:** Enterprise SSO integration is planned for a future release. Full IdP configuration is currently in rollout.

Enterprise licence holders can configure SSO authentication via their organisation's identity provider. When configured, crew session authentication is delegated to your IdP rather than the default local licence check.

### Supported IdP protocols (planned)

- SAML 2.0
- OIDC / OAuth 2.0

### Configuration placeholder

SSO configuration will be added to the per-workspace config when the integration is available. The `mso licence status` output shows the SSO placeholder note for Enterprise tier:

```
[Maestro Licence]
  Mode:    Licence key
  Tier:    Enterprise
  ...
  SSO:     Placeholder (open a GitHub Issue to configure)
```

### How to proceed

To configure SSO for your Enterprise licence:

1. Open a [GitHub Issue](https://github.com/Maestrodevs) with your licence key and IdP type
2. You will receive SSO configuration instructions specific to your IdP
3. Once configured, SSO replaces the local licence key check for all crew sessions in the workspace

---

## 8. Licence Key Management

### Activating an Enterprise key

```bash
mso licence activate ADM-ENT-<org_hash>-<expiry>-<checksum>
```

The key is stored in `~/.maestro/licence.json` on the activating machine. For multi-machine deployments, each machine must activate separately — seat registration is per-machine.

### Deploying via environment variable

For CI/CD or shared host deployments where writing `~/.maestro/licence.json` is not practical, set the key as an environment variable:

```bash
export MAESTRO_LICENCE_KEY=ADM-ENT-a1b2c3d4-20270331-x9y8z7
```

This takes precedence over `~/.maestro/licence.json`. Suitable for ephemeral CI containers.

### Key rotation

When you receive a renewed key:

```bash
# Deactivate the old key
mso licence deactivate

# Activate the new key
mso licence activate ADM-ENT-<new-key>
```

The 30-day offline grace period means a brief gap between expiry and renewal does not immediately interrupt operations.

### Viewing licence status

```bash
mso licence status
```

Sample output for an Enterprise key:

```
[Maestro Licence]
  Mode:           Licence key
  Tier:           Enterprise
  Expires:        2027-03-31 (365 days)
  Max crews:      5
  Max projects:   Unlimited
  Features:       dispatch, status, usage, backup, estimate, approve, roi-reporting,
                  priority-support, sso-placeholder, audit-export, custom-sla
  Seat:           Registered (machine: abc123def456, since 2026-04-01)
  Last validated: 2026-04-01
  SSO:            Placeholder (open a GitHub Issue to configure)
```

---

## 9. Air-Gap and Restricted Networks

Maestro's licence validation is local and offline-safe by design.

### Licence key validation

Licence key checksums are verified using an embedded HMAC — no server call is made for validation. The 30-day offline grace period means the licence remains active after the last successful network operation, even with no internet access.

### Fully air-gapped operation

For workspaces that cannot reach `api.anthropic.com`, crew sessions cannot run (Claude Code requires API access). However, all workspace management commands (`mso status`, `mso backup`, `mso restore`, `mso usage`) work offline.

If your network blocks `api.anthropic.com` but allows access via an internal proxy, configure the proxy as described in [Section 2](#2-network-requirements).

### Git in restricted networks

Crews clone source repositories using the `cloneProtocol` configured in `projects.json`. For internal Git hosts:

```json
{
  "projects": {
    "MYPROJ": {
      "repo": "your-internal-git.corp/my-project",
      "cloneProtocol": "https"
    }
  }
}
```

Ensure the Maestro host can reach your Git host on the configured protocol. SSH keys or Git credential helpers apply as normal.

---

## 10. Deployment Checklist

Use this checklist when setting up an Enterprise workspace.

### Pre-deployment

- [ ] Python 3.9+ installed on all Maestro hosts
- [ ] Claude Code installed and on PATH (`claude --version`)
- [ ] `ANTHROPIC_API_KEY` set (or confirmed via enterprise key agreement)
- [ ] Outbound HTTPS to `api.anthropic.com` permitted
- [ ] Git host accessible from Maestro hosts
- [ ] Enterprise licence key received (request via [GitHub Issues](https://github.com/Maestrodevs))

### Workspace setup

- [ ] `pip install maestro-fleet` run on each host
- [ ] `mso licence activate <key>` run on each machine
- [ ] `mso licence status` confirms Enterprise tier and correct expiry
- [ ] `mso init --project <ACRONYM>` run for each project
- [ ] `projects.json` updated with correct repo URLs and protocols
- [ ] Voyage branch patterns configured per team to avoid collision
- [ ] `.gitignore` reviewed — crew runtime files should not be committed

### Security baseline

- [ ] `ANTHROPIC_API_KEY` stored in secrets manager, not in workspace files
- [ ] `.claude/settings.json` reviewed for permitted commands and file paths
- [ ] Backup destination confirmed (local path or mounted share)
- [ ] `mso backup` tested and restore verified on staging

### Go-live

- [ ] Test order dispatched and completed successfully
- [ ] `mso status --once` shows correct crew slot and dispatcher state
- [ ] `mso usage --summary` returns expected output
- [ ] Token usage and cost within expected range for test order

---

## 11. Onboarding via an Enrolment Profile

The checklist in [§10](#10-deployment-checklist) describes onboarding as a sequence of manual
steps repeated per machine — `mso init --project <ACRONYM>`, hand-editing `projects.json`, setting
`governedMode`. That is still exactly what happens *under the hood*, but as of the tier-aware
setup wizard it does not need to be typed out by hand on every device.

An admin authors and signs a single **enrolment profile** once for the organisation — it carries
workspace defaults, the governance gate itself, trusted signing keys, a pinned division pack, a
secrets-provider configuration, and (optionally) identity seeding. Every device then runs plain
`mso setup`; if a profile resolves (per a fixed precedence chain — explicit path, env var, home
keyring, workspace-committed file), it is verified and applied automatically, and the wizard
prompts only for what the profile leaves open. An Enterprise device with no profile still
completes the full core wizard — it warns and points here rather than silently proceeding
ungoverned; a Team device with no profile completes silently (an ungoverned Team workspace is a
normal, supported state).

This does not replace anything in [§6](#6-governed-mode-and-break-glass) — governed mode, signed
ACL manifests, and break-glass all work exactly as documented there regardless of whether
`governedMode` was set by hand or by an applied profile. It replaces the *typing*, not the
mechanism.

- **Engineer's side** (activate, `mso setup`, done): [ENTERPRISE-QUICKSTART.md](ENTERPRISE-QUICKSTART.md)
- **Admin's side** (author, sign, publish, pin, rotate, prove, plus the unattended/imaging runbook): [ENTERPRISE-ADMIN-GUIDE.md](ENTERPRISE-ADMIN-GUIDE.md)
- **Full profile field reference**: [ENTERPRISE-ADMIN-GUIDE.md § Part B](ENTERPRISE-ADMIN-GUIDE.md#part-b--the-enrolment-profile)

---

*Maestro Maestro v2.5.0 — For Enterprise support and SSO configuration, open a [GitHub Issue](https://github.com/Maestrodevs).*
