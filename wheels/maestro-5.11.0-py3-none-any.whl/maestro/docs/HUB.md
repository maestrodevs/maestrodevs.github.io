# Maestro Hub

**New in v5.0.0.** The Maestro Hub is a real-time, multi-workspace fleet
dashboard. Where `mso status` shows one workspace in one terminal, the Hub gives
you a single pane of glass across **every registered project** — live voyages,
orders, crews, queue depth, token usage, the human-review queue, and the
streaming lifecycle log.

The Hub has two pieces:

| Piece | Ships in | What it is |
|-------|----------|------------|
| **Backend** | the `maestro` pip package (`maestro.hub`) | A FastAPI service exposing a versioned REST API (`/api/v1/...`) + a lifecycle WebSocket. Aggregates state from every workspace in the global registry. |
| **Frontend** | a static export **shipped inside the `maestro` wheel** at `maestro/hub/static/` | A Next.js dashboard that reads the backend API. In local mode the backend serves it on the same port — **no Node, no Docker.** (The `maestro-hub/` source is only needed to develop the UI or build the Docker frontend.) |

---

## Quick start

### Local (recommended) — no Docker, no Node

The Hub runs entirely from the pip package. The backend serves the dashboard UI
on its own port, so a fresh device needs nothing beyond `pip install maestro-fleet`:

```bash
mso hub setup          # validates your registered projects + confirms the UI bundle
mso hub start          # backend + dashboard UI on http://127.0.0.1:3847
```

Open <http://127.0.0.1:3847>. That's it — no second process, no Node runtime.
`mso hub setup --mode local` (the default) reports whether the built UI bundle
shipped with your install; a released wheel always includes it. If you installed
from a plain source checkout with no built bundle, the backend runs **API-only**
and `/` returns a message telling you how to build the UI (see
[Troubleshooting](#troubleshooting)).

> **Docker is an option, not a prerequisite.** Prefer Docker only when you want
> the frontend and backend in separate containers (a shared/multi-operator
> server). See [Docker deployment](#docker-deployment) below; otherwise the
> local flow above is all you need.

### Backend detail

There are two ways to run the backend.

**`mso hub start` — managed daemon (Team / Enterprise licence).**

```bash
mso hub start                 # background daemon on http://127.0.0.1:3847
mso hub start --port 4000 --open   # custom port + open a browser
mso hub status                # is it running? (PID + URL)
mso hub stop                  # stop the daemon
```

`mso hub start` is gated to **Team / Enterprise** licences (the Hub aggregates
multiple workspaces, a fleet-scale feature). FastAPI / uvicorn are installed on
first run if missing — or pre-install them with the `hub` extra:

```bash
pip install 'maestro-fleet[hub]'
```

Air-gapped / private-index installs: `pip install 'maestro[hub]' --extra-index-url https://maestrodevs.github.io/simple/` — see [AIR-GAPPED.md](AIR-GAPPED.md).

**`python -m maestro.hub` — direct, ungated (single-operator / dev).**

```bash
python -m maestro.hub --port 3847
```

This runs the same FastAPI app in the foreground with no licence gate — handy for
local development or a single-operator setup. (The write-control endpoints —
dispatch / hold — are still tier-gated at the HTTP layer; see
[Tier gating](#tier-gating).)

### Developing the frontend (optional)

Local mode already serves the built UI from the backend — you only need the
`maestro-hub/` source app if you are **changing** the dashboard. The dev server
runs on its own port and points back at the backend:

```bash
cd maestro-hub
npm install
NEXT_PUBLIC_HUB_URL=http://localhost:3847 npm run dev   # → http://localhost:3000
```

Open <http://localhost:3000>. The frontend polls the backend every few seconds
and subscribes to the lifecycle WebSocket for live updates.

To produce the static bundle the backend serves, run `npm run build` — it writes
`maestro-hub/out/`; copy that to `maestro/hub/static/` (the release/publish
workflow does this automatically before building the wheel).

### Docker deployment

Docker runs the frontend and backend as **separate containers** — useful for a
shared or multi-operator server, but not required for a single operator (use the
[local flow](#local-recommended--no-docker-no-node) instead). Generate your
device-local mounts, then bring the stack up:

```bash
mso hub setup --mode docker
docker compose -f docker/docker-compose.yml -f docker/docker-compose.local.yml up -d --build
```

The frontend container is a Next.js server build (`next start`) whose backend URL
is baked at build time via the `NEXT_PUBLIC_HUB_URL` compose build-arg. Full
operator reference: `docs/internal/DEPLOYMENT.md`.

---

## Provisioning: `mso hub setup`

**New in v5.2.0.** `mso hub setup` provisions the Hub from **your own** project
registry (`~/.maestro/projects.json`) — no hand-editing of config, no machine
paths committed anywhere. It has two modes, and it only ever *reads* your
registry: there is no new config surface to learn.

```bash
mso hub setup                          # local mode (default) — validate + print start command
mso hub setup --mode docker            # generate the Docker deployment config
mso hub setup --mode docker --dry-run  # preview both generated files, write nothing
mso hub setup --mode docker --force    # regenerate over existing generated files
```

Like `mso hub start`, `mso hub setup` needs a **Team / Enterprise** licence.
`mso hub stop` / `mso hub status` and the direct `python -m maestro.hub` entry
point stay ungated. If no projects are registered, setup stops with a hint to run
`mso init` first.

### Local mode (default) — no Docker

Local mode is the fast path: the native backend reads `~/.maestro` directly, so
there is **nothing to generate**. Setup validates the registry — checking that
each registered workspace path exists on this machine — **and confirms the
statically-exported dashboard UI bundle shipped with this install** (a released
wheel bundles it at `maestro/hub/static/`), then prints the start command:

```bash
mso hub setup     # → lists each project [ok]/[MISSING], reports the UI bundle, then:
mso hub start     # backend + dashboard on http://localhost:3847
```

A `[MISSING]` line means a registered workspace path is absent on this device;
the Hub simply won't show that project until the path is present. Setup also
reports the UI bundle: `[ok] Hub UI bundle present: …` when the built dashboard
shipped (so `mso hub start` serves the UI + API on one port), or `[MISSING] Hub
UI bundle not found …` when it did not — the backend then runs **API-only** until
you install a released wheel or build the UI from source
(`npm ci && npm run build` in `maestro-hub/`, then copy `out/` to
`maestro/hub/static/`). Nothing is written to disk in local mode.

### Docker mode — generate the deployment overlay

Docker mode generates the two **device-local** files the containerised Hub needs,
translating every host path in your registry into a container path
(`/repos/<basename>`):

| Generated file | What it is |
|----------------|------------|
| `docker/maestro-home/projects.json` | The container's copy of your registry, with every path field (top-level `path` / `productRepo` / `artefactRoot` **and** each nested `repos[].path`) rewritten to its `/repos/…` container path. `legacyAcronyms` / `artefactMode` and all other fields are preserved verbatim. |
| `docker/docker-compose.local.yml` | A Compose **overlay** whose `volumes` list bind-mounts each host repo to its container path. Compose merges it *additively* onto the tracked, host-path-free base file. |

Then setup prints the deploy command:

```bash
docker compose -f docker/docker-compose.yml -f docker/docker-compose.local.yml up -d --build
```

**Both `-f` files, always** — the tracked `docker/docker-compose.yml` carries no
host paths; the generated overlay supplies your workspace mounts. Run the command
from the repo root.

**Path handling.** Windows paths are normalised to forward slashes (Docker
Desktop accepts `C:/…`). Each host path maps to `/repos/<basename>`; if two
*different* host paths share a basename, the second gets a deterministic `-2`
(then `-3`, …) suffix and setup prints a warning naming both paths.

**Where the files land.** `--output-dir` defaults to the repo `docker/` directory
when a `docker/docker-compose.yml` is found by walking up from the current
directory; otherwise it falls back to `MAESTRO_HOME/hub-docker/` (for wheel-only
installs — building the images still needs the repo). Pass `--output-dir DIR` to
choose explicitly.

### Device-local, regenerable, never committed

Both generated files are **device-local and gitignored** — they carry your real
machine paths and must never be committed. Regenerate them at any time with
`mso hub setup --mode docker --force`; without `--force`, setup refuses to
overwrite existing generated files (so an accidental re-run can't clobber your
config). Use `--dry-run` to print exactly what *would* be written without
touching disk.

The tracked base — `docker/docker-compose.yml` and
`docker/maestro-home/projects.json.example` — stays generic and host-path-free,
so the repository can be shared without leaking any machine layout.

---

## What the Hub shows

- **Workspace overview** — one card per registered project: dispatcher
  running/stopped, active crews, active voyages, queued orders, pending reviews.
- **Voyage view** — voyages grouped into **Active / Proposed / Completed**
  accordions, each with a role-pipeline (PLN → BLD → TST → …) chip strip, the
  repo + worktree path, and a dependency-graph (DAG) of the orders.
- **Crew panels** — per-slot status, current order, iteration, activity age, PID.
- **Token usage** — cross-project token totals and estimated cost on the
  overview page; per-voyage badges on workspace detail; a dedicated **Token
  Usage report** at `/reports/usage` with drill-down (project → voyage → order →
  role) and CSV export. All surfaces read from `.mso/usage/orders/`.
- **Board buckets: In Review / Needs Attention / Blocked / Skipped** — every
  workspace board classifies its orders into these four lanes (alongside the
  ordinary In Progress / Backlog lanes) instead of leaving review-gated work
  indistinguishable from ordinary backlog. Approve / decline / request-change
  are one click away, inline, without leaving the board. See
  [Board buckets and inline review actions](#board-buckets-and-inline-review-actions).
- **`/review` page** — every order across every registered project that needs
  a human decision or a recovery action, grouped into the same four
  categories, each with its category-correct action. See
  [The /review page](#the-review-page).
- **Voyage inspection & retry** — a COMPLETE voyage's plan, handoffs, and
  reports are viewable read-only from the board; a stranded order gets a
  one-click **Retry**; a PENDING voyage shows a copy-able dispatch command.
  See [Voyage inspection & retry](#voyage-inspection--retry).
- **Live lifecycle stream** — the dispatcher's `lifecycle.log` events as they
  happen, scopeable to a single workspace.
- **Dispatch / Hold controls** — start or stop a workspace's dispatcher from the
  UI (tier-gated; see below).
- **Housekeeping sweep** — a broom button that clears voyages whose PR you have
  already merged, with a preview first. See
  [Housekeeping sweep](#housekeeping-sweep).
- **Multi-repo pills and badges** — for a workspace configured with a multi-repo `repos` map, the
  Hub shows per-repo PR pills on voyage cards, a per-repo review-and-merge CTA in the Final Review
  strip, and a repo badge on every order row/drawer. Single-repo workspaces are unaffected. See
  [MULTI-REPO.md](MULTI-REPO.md#the-hubs-multi-repo-ui) for the full breakdown.
- **`claimedBy` badges** — for a shared-mode (corporate) workspace, an order currently claimed by
  another engineer's dispatcher shows who claimed it and when. See
  [ARTEFACT-REPO.md](ARTEFACT-REPO.md#corporate-shared-mode).

---

## How workspaces appear in the Hub

The Hub reads the **global project registry** at `~/.maestro/projects.json`. Any
workspace registered there shows up automatically. Workspaces are registered when
you run `mso init` / `mso dispatch` in them, or you can manage the list with:

```bash
mso projects list             # show registered workspaces
mso projects remove <ACRONYM> # drop one from the registry
```

If the Hub shows a workspace you no longer use (or is missing one you do), prune
or re-register it via `mso projects`.

---

## Board buckets and inline review actions

Every workspace board classifies its orders with the workspace-parameterised
**attention classifier** (`maestro/hub/attention.py`) into exactly one of four
categories, plus the ordinary In Progress / Backlog lanes:

| Bucket | Source | Verb | Action |
|--------|--------|------|--------|
| **In Review** | `NAV_REVIEW_PENDING` orders (`queues/review/*.json`) | Authorising | Approve / Request change / Decline |
| **Needs Attention** | Stranded orders — `CONVERGENCE_FAILED`, `BLOCKED`, `AUTO_SERIALIZE`, `ESCALATED`, `STALLED`, `VERIFY_FAILED`, `FAILED` | Unsticking | Retry |
| **Blocked** | Dependency-held orders (`.mso/state/dep-holds.json`) | — | Informational; shows the blocking order id |
| **Skipped** | Orders on the operator skip list | — | Unskip. Collapsed by default — findable, but never counted in "Needs you". |

An order carries **at most one** attention tag — it renders in exactly one
bucket, never zero and never two. The classifier is computed **per
workspace** (not globally), so the Hub's multi-workspace poller never leaks
one workspace's held orders into another's counts. The workspace card and
sidebar show one rolled-up **"Needs you: N"** figure — In Review plus Needs
Attention, excluding Blocked and Skipped.

Before this classifier existed, a review-gated order rendered under
**Backlog**, indistinguishable from ordinary unstarted work — the operator
had no way to see, from the board, that something was waiting on them.

### Inline actions

Opening any **In Review** order's drawer replaces the ordinary edit form with
a **review action bar**: Approve, Request change, and Decline. Request
change and Decline both require a non-empty note (never optional) before
their Confirm button enables. These call the exact same
`POST /api/v1/review/{id}/{approve,revise,reject}` endpoints — and therefore
the same `review_core` implementation — as the [`/review` page](#the-review-page)
and `mso review approve|revise|reject`; there is no second, competing
mutation path.

A **Needs Attention** order's drawer instead shows a **Retry** button, enabled
only for a genuinely stranded order — disabled, with the CLI's own `--force`
hint text, for a `COMPLETE` order. There is no `--force` control in the UI;
force-retrying a completed order is a deliberate CLI-only action.

---

## The /review page

`/review` (linked from the sidebar) is the cross-workspace view of the same
four categories, spanning **every registered project** — not just the
workspace you happen to be looking at. Four tabs, same names and order as the
board's lanes: In Review / Needs Attention / Blocked / Skipped. Each tab
offers its category-correct action (the same review action bar, Retry,
informational, or Unskip), backed by `GET /api/v1/attention/queue`.

Acting on an item removes it from its category on the next poll — the tag
clear happens server-side, not as an optimistic UI-only update, so a
retried or unskipped order does not silently reappear in its old category.

---

## Capability preflight

Before this feature, an unavailable action (dispatch on a containerised Hub,
housekeeping without `gh`) was only discoverable by clicking it and reading a
`409`. `GET /api/v1/capabilities` inverts that: it declares, before any click,
whether Dispatch / Sweep / Review / Order-retry can actually work in **this**
deployment, and separately whether the caller's licence tier permits
mutating control actions at all.

```json
{
  "dispatch":   {"available": false, "reason": "This Hub runs in a container and cannot launch a usable dispatcher. Run `mso dispatch` from a host session."},
  "sweep":      {"available": true,  "reason": null},
  "review":     {"available": true,  "reason": null},
  "orderRetry": {"available": true,  "reason": null},
  "tier":       {"control": true,    "reason": null}
}
```

The frontend contract: an unavailable action renders **disabled**, with
`reason` as its tooltip (and, for the primary Dispatch action, as inline
helper text too). While `/capabilities` is loading, every mutating action
renders disabled — never enabled-and-hopeful. The server-side `409`/`403`s on
the underlying endpoints remain as a defence-in-depth backstop, not the
primary mechanism — the reason strings on both sides are the exact same
server-side constants, so the explanation the button shows before the click
and the one the API returns if it happens anyway can never disagree.

`review` and `orderRetry` are workspace-independent by design and currently
always report `available: true` for a non-governed deployment (both are
file-plane mutations — see [Housekeeping sweep](#housekeeping-sweep)'s "file
plane vs process spawn" distinction, which applies identically here). In a
**governed** workspace, a caller who fails the `voyage.approve` or
`order.dispatch` capability check is still correctly refused server-side
(`403`) — `/capabilities` does not yet widen to a per-workspace,
per-operator preflight for that case, so the governed refusal currently
surfaces as a `403` after the click rather than a disabled button before it.

---

## Voyage inspection & retry

Every order's drawer now has an **Artefacts** tab, backed by
`GET /api/v1/orders/{id}/artefacts` — read-only, works for an order in any
lifecycle state (COMPLETE, PENDING, archived, mid-voyage), and requires no
running dispatcher. It discovers the order's plan, every role handoff, and
every qa/security/investigation/voyage report, and renders their content
(escaped, never executed — an artefact is untrusted content) with a loading
state that gates the empty state, so a slow fetch never reads as "nothing
here".

A voyage in the **backlog** phase (created but never dispatched, or PENDING
with no live crew) shows a copy-able `mso dispatch` command block naming the
correct **product repo** path — not the artefact-repo path, which can differ
in [artefact-repo mode](ARTEFACT-REPO.md). This is deliberate, not a stopgap:
spawning a dispatcher needs a host process and a real Claude CLI session,
which a container cannot provide (see [Tier gating](#tier-gating) and the
[Capability preflight](#capability-preflight) `dispatch` reason above) — the
Hub tells you the exact command instead of pretending it can run it for you.

A **stranded** order's drawer offers **Retry** (see
[Board buckets and inline review actions](#board-buckets-and-inline-review-actions)
above) — `POST /api/v1/orders/{id}/retry`, the same semantics as
[`mso order retry`](CLI-REFERENCE.md#mso-order-retry), including the salvage
fast-path and the governed-mode `order.dispatch` capability gate. It works
identically with `MAESTRO_HUB_CONTAINERIZED=1`, because retry only ever
rewrites order JSON and the ledger — the dispatcher that eventually re-runs
the role is someone else's problem, later, on a host.

---

## Tier gating

| Action | Gate |
|--------|------|
| Read-only API (`GET /api/v1/...`), lifecycle stream | Ungated on the direct `python -m maestro.hub` entry point. |
| `mso hub start` (managed daemon) | **Team / Enterprise** licence (`auth.require_tier`). |
| `mso hub setup` (provision config) | **Team / Enterprise** licence, same gate as `start`. `mso hub stop` / `status` stay ungated. |
| `POST .../dispatch`, `POST .../stop` (Dispatch / Hold) | **Team / Enterprise** at the HTTP layer → `403` otherwise. |
| `POST .../sweep` (Housekeeping) | **Team / Enterprise** at the HTTP layer → `403` otherwise. |
| `POST /review/{id}/{approve,revise,reject}`, `POST /orders/{id}/retry`, `POST /orders/{id}/unskip` | **Team / Enterprise** at the HTTP layer → `403`. In a **governed** workspace, additionally gated per-operator by the `voyage.approve` (review) / `order.dispatch` (retry) identity capability → `403` with a different message. |
| `GET /orders/{id}/artefacts`, `GET /orders/{id}/artefacts/{key}` | Ungated reads (file-plane, container-safe) — same discipline as `/review/{id}/plan`. |
| `GET /capabilities`, `GET /attention/queue` | Ungated reads. |

Setting `MAESTRO_SKIP_AUTH=1` bypasses both the licence check and the tier gate
(used by CI and local single-operator development).

---

## Mobile access

The Hub UI is responsive: on a phone the sidebar collapses to a hamburger drawer
and the review screen stacks the queue above the plan/action pane, so approving,
revising, and rejecting gates all work from a mobile browser. What it is **not**
is a public internet service. Reach it the safe way:

> **Never expose the Hub directly to the public internet.** The native
> `mso hub start` binds `127.0.0.1` only — unreachable from another device by
> design. Making it reachable is a deliberate act; do it over a **private network**,
> not a port forward on your router.

**Recommended: private overlay network.** Put your phone and the Hub host on the
same [Tailscale](https://tailscale.com/) / WireGuard tailnet (or use an SSH /
`kubectl port-forward` tunnel back to `localhost:3847`). Then browse to the host's
private address. Nothing is exposed beyond the tailnet.

**When the Hub host is network-reachable** (e.g. the Docker image, which binds
`0.0.0.0` and `EXPOSE`s `3847`/`3000`), harden it — all three are read from the
environment by `maestro/hub/server.py`:

| Setting | Env var | Purpose |
|---------|---------|---------|
| Bearer token | `MAESTRO_HUB_TOKEN` (or `~/.maestro/hub.token`) | Required on every `/api/*` call except `/health` and `/ping`. Opt-in, so **set it** before exposing the host. |
| Host allowlist | `MAESTRO_HUB_ALLOWED_HOSTS` (comma-separated) | Added to the localhost base set; requests with any other `Host:` header get `403` (defeats DNS rebinding). Add your tailnet hostname/IP. |
| CORS origins | `MAESTRO_HUB_ALLOWED_ORIGINS` (comma-separated) | Origins the browser UI may call from. Default is localhost only. |
| Frontend → backend URL | `NEXT_PUBLIC_HUB_URL` | Point the Next.js UI at the private address the phone will use. |

Put the token in the `Authorization: Bearer <token>` header (the bundled UI reads
`NEXT_PUBLIC_HUB_URL`; a token-aware reverse proxy or a browser extension can inject
the header, or terminate TLS + auth at the proxy).

**Tier note.** The Hub — and every write endpoint (dispatch / stop / sweep,
approve / revise / reject) — is **Team / Enterprise** gated (see
[Tier gating](#tier-gating)). On other tiers, use the tier-independent
[Slack Mobile Command Bridge](bridge-setup-guide.md) for remote control; it needs no
open port at all (it relays through a GitHub Gist). The Hub is the richer,
sit-down surface; Slack is the always-on, zero-exposure daily driver.

---

## REST API reference

Base URL: `http://127.0.0.1:3847` (default port). All routes are under `/api/v1`.

| Method | Path | Returns |
|--------|------|---------|
| `GET` | `/health` | Service status, version, workspace count. |
| `GET` | `/workspaces` | Array of workspace summaries (the overview cards). |
| `GET` | `/workspaces/{id}` | Full workspace detail — voyages, orders, crews, queue summary, usage, config, repos. |
| `GET` | `/workspaces/{id}/crews` | Per-crew live state for one workspace. |
| `GET` | `/capabilities` | Declares, before any click, whether dispatch / sweep / review / order-retry can actually work in **this** Hub deployment, plus the caller's licence tier. Workspace-independent, poller-independent, cheap to poll. See [Capability preflight](#capability-preflight). |
| `POST` | `/workspaces/{id}/dispatch` | Start the workspace's dispatcher (tier-gated). |
| `POST` | `/workspaces/{id}/stop` | Stop the workspace's dispatcher (tier-gated). |
| `POST` | `/workspaces/{id}/sweep` | Run the [housekeeping sweep](#housekeeping-sweep) (tier-gated). Add `?dry_run=true` to preview. |
| `GET` | `/review/queue` | Cross-workspace **review-gated only** queue (bare array) — the original, narrower feed. Prefer `/attention/queue` for the full four-category view. |
| `GET` | `/review/{order_id}/plan` | The plan markdown for an order awaiting review. |
| `POST` | `/review/{order_id}/approve` | Approve a paused order (tier- and capability-gated). |
| `POST` | `/review/{order_id}/revise` | Send an order back with feedback (tier- and capability-gated; feedback is required). |
| `POST` | `/review/{order_id}/reject` | Reject a paused order (tier- and capability-gated; a reason is required). |
| `GET` | `/attention/queue` | Every order across every registered workspace needing attention — all four categories (review-gated / stranded / dep-held / skipped), bare `Order[]` array. Backs the [`/review` page](#the-review-page). |
| `GET` | `/orders/{order_id}/artefacts` | Discovers every artefact for an order (plan, handoffs, qa/security/investigation reports, the order JSON) — manifest only, no content. Ungated, works in any lifecycle state. |
| `GET` | `/orders/{order_id}/artefacts/{key}` | Reads one artefact's content (≤512 KB; larger content is truncated with `truncated: true`). `key` is re-validated against a fresh discovery pass, never joined onto a client-supplied path. |
| `POST` | `/orders/{order_id}/retry` | Reopen a stranded/archived order — `mso order retry` over HTTP, same [`order_retry`](CLI-REFERENCE.md#mso-order-retry) implementation. Works with `MAESTRO_HUB_CONTAINERIZED=1` (file-plane only). |
| `POST` | `/orders/{order_id}/unskip` | Remove an order from the skip list — `mso order unskip` over HTTP. |
| `GET` | `/usage` | Cross-workspace token/cost rollup. Optional: `?from=YYYY-MM-DD&to=YYYY-MM-DD&group_by=project\|voyage\|order\|role` |
| `GET` | `/usage/projects/{id}` | Per-project rollup with voyage-level buckets. Optional `from` / `to` date filters. |
| `GET` | `/usage/voyages/{voyage_id}` | Per-voyage rollup with order-level buckets (+ role breakdown when FTR-0332 data present). Optional `from` / `to`. |
| `GET` | `/usage/orders/{order_id}` | Full order usage: per-role buckets, per-iteration records, per-model breakdown. |
| `WS` | `/lifecycle/stream` | Live lifecycle events. Add `?workspace_id=<id>` to scope to one workspace. |

The JSON shapes are defined by the Pydantic models in `maestro/hub/models.py`
and serialize exactly to the frontend TypeScript interfaces in
`maestro-hub/app/types/index.ts` (the authoritative data contract).

---

## Housekeeping sweep

Each project's control row on the workspace detail page carries
a **broom button**, between **Dispatch** and **Settings**. It runs housekeeping
for that workspace: check every voyage's PR state, archive the ones whose PR has
merged, and report what it refused to touch.

### Why it exists

You approve and merge the voyage PR yourself most of the time — usually after the
dispatcher that produced the work has exited. Maestro therefore never *observes*
the merge event, and the voyage stays in `voyages/active/`, cluttering the **Final
Review** column indefinitely.

Housekeeping cannot be something that only happens when a dispatcher happens to be
running. It has to be **pull-based** — something you trigger. The broom button is
that trigger, and it needs **no running dispatcher**.

### Preview, then apply

Clicking the broom never mutates anything on the first click:

1. The first click runs a **dry run**. If there is anything to archive, it opens a
   confirm dialog listing **Will change** and **Will NOT touch**, each line naming
   the voyage and the reason. Nothing is written until you confirm — cancel and the
   workspace is untouched.
2. If there is nothing to change but voyages *were* refused (an open PR, a voyage
   with no PR, a PR closed without merging, an order archived but not `COMPLETE`),
   you get an informational dialog instead of a bare count — the same **Will NOT
   touch** lines the confirm dialog would have shown, labelled as a dry run so it's
   clear the workspace was inspected and nothing was mutated. There is nothing to
   apply, so it has a single dismiss, not a confirm/cancel choice.
3. If there is nothing to change *and* nothing was refused, you get a plain toast —
   *"everything is already up to date"* — since a dialog would be noise on a
   genuinely empty result.

The refusals are the point as much as the changes: an open PR, a voyage with no PR
at all, a PR closed without merging, or an order that is archived but not
`COMPLETE` is **reported with its reason**, never silently skipped.

### Same code as the CLI

The endpoint runs `mso voyage reconcile --json` — the button and the command
execute literally the same implementation, so they cannot drift or disagree. For
the full behaviour, the report shape and how merge state is resolved (PR record
first, raw git as the fallback), see
[`mso voyage reconcile`](CLI-REFERENCE.md#mso-voyage-reconcile).

### Requirements and limits

| Constraint | Detail |
|-----------|--------|
| **Tier** | Team / Enterprise, same as Dispatch / Hold. `403` otherwise (or set `MAESTRO_SKIP_AUTH=1` for local development). |
| **Origin / CORS** | Same allow-list and Host guard as the other control endpoints. |
| **Dispatcher** | Not required. |
| **Containerised Hub** | **Unavailable** — returns `409` with the observe-only message. Merge detection needs `git` and `gh` against the product repo, and a container has neither. Same constraint as the Dispatch button; run the sweep from a host session (`mso voyage reconcile`) or a native Hub (`mso hub start`). |
| **Timeout** | 5 minutes, then `504`. A hanging PR lookup is the usual cause; nothing is reported as changed. |

---

## Token usage & cost

The Hub surfaces token consumption and estimated cost across four levels: fleet
overview, workspace detail, the Token Usage report, and the REST API.

### Dashboard overview — CrossWorkspaceUsagePanel

On the Hub overview page (`/`), a **CrossWorkspaceUsagePanel** appears above the
workspace cards. It shows:

- **Total tokens** and **estimated cost** for all projects combined, for the
  selected date range.
- A **per-project breakdown table** sorted by spend (highest first), with each
  project's token total and cost.
- A **trend sparkline** driven by the daily series for the same period.
- A **date-range control** with 7d / 14d / 30d presets. Changing the preset
  re-fetches the overview and all workspace panels simultaneously.

When no usage has been recorded in the selected period, the panel shows
"No usage recorded in this period" — it never falls back to mock or example data.

### Workspace detail — WorkspaceUsagePanel and voyage badges

On a workspace detail page (`/workspaces/{id}`):

- A **WorkspaceUsagePanel** in the right sidebar shows the project-level token
  total and cost for the selected date range, with a sparkline.
- Each voyage row in the voyage list shows an inline **token/cost badge** when
  usage data exists for that voyage. The badge is omitted (not zeroed) when the
  voyage has no recorded usage.
- The **date-range control** (7d / 14d / 30d) drives both the sidebar panel and
  the per-voyage badges.

### Token Usage report

A dedicated **Token Usage report** is available at `/reports/usage` (linked from
the reports catalog at `/reports` with a "Live data" badge). It provides:

| Feature | Description |
|---------|-------------|
| **Drill-down navigation** | Start at the project level; click into a project to see its voyages; click a voyage to see its orders; click an order for role + model detail. A breadcrumb lets you navigate back up. |
| **TotalsPanel** | Shows total tokens, estimated cost, and order count for the current filter level, plus a trend sparkline. At order detail level the totals reflect that order's data. |
| **BreakdownTable** | Tabular list of buckets (projects / voyages / orders) sorted by tokens descending, with a "Drill in →" button on each row. |
| **Order detail view** | Shows per-role token/cost buckets (`role_buckets`, from FTR-0332 iteration JSONL) and a per-model breakdown (input / output / cache-read / cache-write / message count). Degrades gracefully when JSONL is absent. |
| **DailyTrendTable** | Per-day tokens and cost series shown below the main panel at project, voyage, and order-list levels. Hidden at the order detail level (no series available). |
| **CSV export** | Exports the current filtered view as a CSV file. At order level: role + model rows combined; at other levels: the current bucket list. |
| **Date-range control** | 7d / 14d / 30d presets re-fetch all panels at the current drill level. |
| **Empty/zero state** | "No usage data for the selected filters in this period" at every level — no fallback to mock data. |

### Data sources

All usage surfaces read from the files written by the Maestro stop hook:

| File type | Location | Contents |
|-----------|----------|----------|
| **Order summary** (`*.json`) | `.mso/usage/orders/{ORDER-ID}.json` | Cumulative per-order totals: `total_tokens`, `estimated_cost_usd`, per-model breakdown. One file per order; updated (merged, not overwritten) after each crew iteration by the stop hook. |
| **Iteration log** (`*.jsonl`) | `.mso/usage/orders/{ORDER-ID}.jsonl` | Append-only; one JSON line per completed crew iteration with `role`, `crew_number`, `iteration`, `total_tokens`, `estimated_cost_usd`, per-model breakdown, and `timestamp`. Present only when FTR-0332 is active. |

### Forward-looking caveats

> **Data availability:** Token-usage files are written by the Maestro stop hook.
> BUG-MSO-2026-0331 (fixed in v5.0.2) caused the stop hook to skip usage capture
> when running under `MAESTRO_ITER_MANAGED` — the mode used by all dispatched
> crews. As a result, **usage data is available only from the v5.0.2 deployment
> forward** (approximately 2026-06-27). Earlier orders have no recorded usage and
> will show zero or empty in all Hub views.

> **Role-level breakdown:** The per-role breakdown in the order detail view
> requires the per-iteration JSONL files introduced in FTR-MSO-2026-0332. Orders
> that completed before FTR-0332 was deployed have only the summary JSON (no JSONL)
> and will show "No role-level breakdown — requires FTR-0332 iteration files."
> rather than an error.

> **Cost estimates:** Estimated cost is calculated by the Maestro stop hook using
> a built-in per-model pricing table. It reflects published API list prices at the
> time of the release and is updated with each new Maestro version. Actual billing
> may differ due to promotional pricing, enterprise agreements, caching discounts,
> or model pricing changes that post-date the installed version.

---

## Configuration

| Setting | Where | Default |
|---------|-------|---------|
| Backend port | `--port` on `mso hub start` / `python -m maestro.hub` | `3847` |
| Frontend → backend URL | `NEXT_PUBLIC_HUB_URL` env (frontend) | `http://localhost:3847` |
| Workspace registry | `~/.maestro/projects.json` | — |
| Terminal monitor auto-spawn | `spawnMonitor` in `~/.maestro/config/settings.json`, or `MAESTRO_SPAWN_MONITOR=0/1` env | `true` (spawns) |

Per-workspace dispatch defaults shown in the Hub's settings drawer
(`maxIterations`, `maxTurns`, `timeoutMinutes`, `autoDispatch`,
`requirePlanReview`, `tokenDailyCap`, `roleTimeouts`) live in each workspace's
`.mso/config/workspace.json`.

**Running the Hub instead of the terminal Monitor?** `mso dispatch` normally
auto-spawns a separate visible "Maestro Monitor" terminal window on every
dispatch. When you're driving observation through the Hub, that window is
redundant. Set `spawnMonitor` to `false` in the **machine-level** (device-global,
not per-workspace) `~/.maestro/config/settings.json`:

```json
{
  "spawnMonitor": false
}
```

or set `MAESTRO_SPAWN_MONITOR=0` in the environment the dispatcher runs in — the
env var always wins over the machine config. This is a per-device display
preference, so it applies to every workspace dispatched from that machine. The
dispatcher and crews run unaffected either way; only the terminal window is
suppressed, and a one-line note is logged to `lifecycle.log` when it is.

---

## Troubleshooting

- **Opening `http://127.0.0.1:3847/` returns JSON `{"ui": "unavailable", …}`** —
  the backend is running API-only because no built UI bundle shipped with this
  install. A released `maestro` wheel always bundles the UI; a plain source
  checkout does not. Either install a released wheel, or build the UI from source
  (`npm ci && npm run build` in `maestro-hub/`, then copy `out/` to
  `maestro/hub/static/`), or use the Docker frontend. `mso hub setup` reports the
  bundle's presence up front.
- **Frontend shows "backend unreachable" / no live data** — confirm the backend
  is up (`mso hub status` or `curl http://127.0.0.1:3847/api/v1/health`). In
  local mode the UI is same-origin, so there is nothing to point at; in Docker
  confirm the frontend's `NEXT_PUBLIC_HUB_URL` build-arg names the right backend.
- **`mso hub start` refuses with a tier error** — `mso hub` requires a Team /
  Enterprise licence. For single-operator/dev use, run the backend directly with
  `python -m maestro.hub --port 3847`.
- **A workspace is missing or stale** — check `mso projects list`; register with
  `mso init` / `mso dispatch` in the workspace, or remove with
  `mso projects remove <ACRONYM>`.
- **Dispatch / Hold / broom buttons return 403** — those endpoints are tier-gated;
  use a Team / Enterprise licence or set `MAESTRO_SKIP_AUTH=1` for local
  development.
- **The broom button returns 409 "observe-only deployment"** — expected in a
  containerised Hub, which has no product repo, `git` or `gh` to check PR state
  with. Run `mso voyage reconcile` from a host session instead, or run the Hub
  natively. Same limitation as Dispatch.
- **Voyages stay in Final Review after their PR merged** — click the broom button
  (or run `mso voyage reconcile`). Maestro does not see merges you perform
  yourself; housekeeping is
  [pull-based](#housekeeping-sweep) by design.
