# Maestro — Enterprise Quickstart

> The Team/Enterprise onboarding path — five commands, one of which is `cd`. If you're the person
> authoring your org's policy bundle or enrolment profile rather than receiving one, you want
> [ENTERPRISE-ADMIN-GUIDE.md](ENTERPRISE-ADMIN-GUIDE.md) instead. If you're not sure which tier
> you're on, start at [START-HERE.md](START-HERE.md).

This guide assumes your organisation has already generated a licence key for you and — optionally
— authored an **enrolment profile** ([reference](ENTERPRISE-ADMIN-GUIDE.md#part-b--the-enrolment-profile)).
Neither is required to follow along: everything here degrades gracefully to the plain
[QUICKSTART.md](QUICKSTART.md) path if your org hasn't set up a profile yet.

---

## The five commands

```bash
pip install maestro-fleet                     # 1. install
mso licence activate <YOUR-KEY>                # 2. licence (or pre-activated by IT via MAESTRO_LICENCE_KEY)
cd /repos/your-product                         # 3. cd into your project repo
mso setup                                      # 4. detects the org profile (if any), scaffolds,
                                               #    applies the pinned pack, pins trusted keys,
                                               #    enables governance, configures secrets,
                                               #    seeds identity, runs preflight
mso quickstart                                 # 5. see it work — first demo dispatch
```

Each command in turn:

### 1 — Install

```bash
pip install maestro-fleet
mso version
```

Same install as every other tier — see [QUICKSTART.md §1](QUICKSTART.md#1-install) for venv
guidance, air-gapped installs, and Windows notes; none of that differs at Team/Enterprise.

### 2 — Activate your licence

```bash
mso licence activate <YOUR-KEY>
mso licence status
```

Unlike community, this step is not optional — Team and Enterprise both require an activated
licence. Your admin may instead have set `MAESTRO_LICENCE_KEY` in your provisioning environment,
in which case activation already happened and this step is a no-op check. Full reference:
[LICENCE.md](LICENCE.md).

### 3 — `cd` into your project

`mso setup` operates on the directory you run it from — point it at the repo (or the workspace
root) you actually want to configure.

### 4 — Run the wizard

```bash
mso setup
```

At Team/Enterprise, this runs the same seven core steps every tier gets (persona, prerequisite
checks, project analysis, workspace configuration, division-pack selection, requirement templates,
next-steps cheatsheet — see [SETUP.md](SETUP.md#tier-aware-step-registry)), plus:

| Step | What it does |
|---|---|
| `[LICENCE]` | Shows your resolved tier, expiry, and any warning (e.g. downgrade-in-progress). |
| `[STEP 3a] Division pack selection` | Full pack list at Team/Enterprise (not filtered) — or, if your profile pins one with `locked: true`, applied automatically with no prompt. |
| `[PROFILE] Enrolment profile` | Looks for a profile (§B2 precedence in the admin guide) and reports what it found. |
| `[ENTERPRISE] Applying enrolment profile` | Only runs if a profile actually resolved. Applies workspace/governance/trusted-key settings, configures your secrets provider and runs `mso secrets doctor`, and seeds identity if the profile requests it. |

**No profile found?** You still get the full core wizard — governance is never half-configured.
`mso setup` prints a pointer to [ENTERPRISE-SETUP.md](ENTERPRISE-SETUP.md) (Enterprise tier) or
just proceeds quietly (Team tier, since an ungoverned Team workspace is a normal, supported state).

Explicit profile placement, if your admin handed you a file directly rather than an MDM push:

```bash
mso setup --profile ~/Downloads/acme-enrolment.json
# or
export MAESTRO_ENROLMENT_PROFILE=https://policy.acme.example/enrolment.json
mso setup
```

### 5 — See it work

```bash
mso quickstart --crews 2
```

Scaffolds a demo workspace and dispatches a real multi-order fleet end to end — the fastest way to
confirm everything from step 4 actually took effect (governance, secrets, identity) before you
point Maestro at real work. `--crews N` runs more of the demo in parallel (no tier-based crew-count
restriction is enforced by any command today); see
[QUICKSTART.md §4](QUICKSTART.md#4-run-the-quickstart) for the full flag reference.

---

## What's different from the community/pro path

| | Community/Pro | Team/Enterprise (this guide) |
|---|---|---|
| Licence | none / required | required |
| Enrolment profile | never looked for (community) / detected only (pro) | resolved and **applied** |
| Division packs | `sdlc` only (both tiers — pack gating checks Team/Enterprise specifically) | full list, or profile-pinned |
| Governance | never touched | applied when a profile sets `governedMode` |
| Secrets provider | never configured by setup | applied from the profile, verified with `mso secrets doctor` |
| Identity | never seeded by setup | seeded when the profile requests it |
| `mso hub start` | refuses (Team/Enterprise licence required) | works — see [HUB.md](HUB.md) |

## Unattended (imaging many machines)

See the [unattended runbook](ENTERPRISE-ADMIN-GUIDE.md#part-c--unattended--imaging-runbook) in
the admin guide — `mso setup --non-interactive`, `--answers`, and the enterprise anchor-provider
requirements for `mso init --enterprise --non-interactive`.

## Troubleshooting

### `mso setup` says "No enrolment profile found — running ungoverned"

You're on Enterprise tier and no profile resolved through any precedence tier. This is a warning,
not a failure — the core wizard still completes. Confirm with your admin whether a profile should
exist and where it's meant to be placed (§B2/§B6 in the admin guide).

### A profile is refused with "requires a 'team' licence or higher; this device is at 'community'"

Your device hasn't activated a licence, or activated one below the profile's `minimumTier`. Run
`mso licence activate <KEY>` for the correct tier, or ask your admin whether this device should be
receiving that profile at all.

### `mso secrets doctor` reports issues right after `mso setup`

The profile-configured secrets provider couldn't resolve every `secret://` reference in your
workspace. This doesn't fail `mso setup` outright — fix the provider config or the missing secret,
then re-run `mso secrets doctor` directly to confirm.

## See also

- [START-HERE.md](START-HERE.md) — tier-aware routing
- [ENTERPRISE-ADMIN-GUIDE.md](ENTERPRISE-ADMIN-GUIDE.md) — authoring the policy bundle and enrolment profile
- [ENTERPRISE-SETUP.md](ENTERPRISE-SETUP.md) — network requirements, governed mode, break-glass, compliance
- [SETUP.md](SETUP.md) — every `mso setup` step, in full, at every tier
- [QUICKSTART.md](QUICKSTART.md) — the community/pro path
