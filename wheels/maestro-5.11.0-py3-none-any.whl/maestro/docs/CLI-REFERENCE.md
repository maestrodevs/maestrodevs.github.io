# Maestro CLI Reference

Detailed reference for the core `mso` commands. For the **complete, canonical command list** (including `roles`, `security`, `mcp`, `bridge`, `identity`, `audit`, `secrets`, `data-flow`, `config`, `quickstart`, `projects`, `review`, `sprint`, `bug`, `update`, `hooks`), see the [public CLI reference](https://github.com/Maestrodevs) or run `mso --help` / `mso <command> --help`.

> All commands use the `mso` prefix (the `adm` alias was removed in v4.0). `crew`/`voyage` are legacy aliases for `squad`/`sprint`.

---

## Contents

- [mso dispatch](#mso-dispatch)
- [mso cleanup](#mso-cleanup)
- [mso status](#mso-status)
- [mso demo](#mso-demo)
- [mso usage](#mso-usage)
- [mso squad / mso crew](#mso-squad--mso-crew)
- [mso verify](#mso-verify)
- [mso voyage reconcile](#mso-voyage-reconcile)
- [mso order](#mso-order)
- [mso backup](#mso-backup)
- [mso restore](#mso-restore)
- [mso init](#mso-init)
- [mso packs](#mso-packs)
- [mso policy](#mso-policy)
- [mso setup](#mso-setup)
- [mso licence](#mso-licence)
- [mso version](#mso-version)
- [Exit Codes](#exit-codes)
- [Environment Variables](#environment-variables)

---

## mso dispatch

Launch fleet crews from the dispatch queues.

```
mso dispatch [--max-crews N] [--cleanup] [--stagger-delay S] [--timeout M] [--retry-failed N]
```

### Flags

| Flag | Type | Default | Description |
|------|------|---------|-------------|
| `--max-crews N` | integer | `5` | Maximum number of crews to run concurrently. Valid range: 1–5. **Community tier is clamped to 2** regardless of what you request here — the clamp is enforced in the dispatcher itself (not this flag), so it also applies to the Hub's dispatch endpoint. See [LICENCE.md](LICENCE.md#tier-limits-enforced-in-code-not-just-advertised). |
| `--cleanup` | flag | `false` | Run cleanup before dispatching. Stops orphaned processes and resets stale lock files. |
| `--stagger-delay S` | integer | `30` | Seconds to wait between launching successive crew sessions. Reduces API rate pressure. |
| `--timeout M` | integer | `60` | Per-iteration wall-clock CEILING in minutes (a backstop, not the primary hang control). The primary hang control is the activity watchdog (`completion.supervision.stallMinutes`, default 10): a crew with no output for that long is killed as HUNG and its work salvaged + requeued, while a crew that keeps producing output is never killed before the ceiling. Both `--timeout` and `--max-turns` remain active simultaneously. |
| `--max-turns N` | integer | `200` | Claude Code internal turn cap per iteration. When hit, Claude Code exits with `subtype=error_max_turns` (terminal state: `MAX_TURNS`). Order is requeued with fresh context. Increase for complex orders that need more reasoning steps. |
| `--retry-failed N` | integer | `0` | **planned** — Auto-retry crashed orders up to N times. When 0 (default), crashed orders are retried indefinitely. |

### How dispatch works

1. Scans all queue directories in priority order (see [Queue Priority](#queue-priority) below)
2. Filters out orders with unsatisfied `dependsOn` dependencies
3. Assigns available orders to crew slots (crew1 through crew5)
4. Launches a Claude Code subprocess for each crew with the role, order, and project context injected
5. Monitors each crew through multiple iterations via the stop hook

### Queue priority

| Queue | Priority |
|-------|---------|
| `queues/explicit/` | Highest |
| `queues/security/` | High |
| `queues/bugs/` | High |
| `queues/requests/` | Medium-High |
| `queues/orders/` | Medium |
| `queues/defects/` | Medium-Low |
| `queues/breakdown/` | Low |
| `queues/high-level/` | Lowest |
| `queues/escalations/` | Not dispatched — requires manual review |

### Examples

```bash
# Launch up to 3 crews
mso dispatch --max-crews 3

# Clean stale state first, then dispatch
mso dispatch --cleanup --max-crews 5

# Slower stagger for large crews to reduce rate limiting
mso dispatch --max-crews 5 --stagger-delay 60

# Raise the wall-clock ceiling for unusually long iterations (default 60)
mso dispatch --max-crews 3 --timeout 120

# Auto-retry crashed orders up to 2 times before permanently failing them
mso dispatch --max-crews 3 --retry-failed 2
```

---

## mso cleanup

Stop orphaned crew processes and reset stale crew state.

```
mso cleanup
```

### What cleanup does

- Terminates any crew processes whose PID files no longer match a running process
- Reaps orphaned descendant processes of dead crews — not just the crew process itself, but anything it spawned (a filesystem search, a build command, a compiler process, a shell), however deep, that outlived it
- Removes stale `crew.lock` files
- Resets `state.json` for idle crew slots

Safe to run at any time — does not affect orders that are actively in progress. Descendant reaping only ever terminates processes traceable to a specific crew slot, never an unrelated process on the same machine.

### Flags

None.

### Example

```bash
mso cleanup
```

---

## mso status

Display the fleet status dashboard.

```
mso status [--once] [--compact]
```

### Flags

| Flag | Type | Default | Description |
|------|------|---------|-------------|
| `--once` | flag | `false` | Print status once and exit (pipe-friendly plain output). When omitted, the dashboard refreshes on a loop in the terminal's alternate buffer — exiting restores your scrollback. |
| `--compact` | flag | `false` | One-line-per-crew layout for narrow terminals or tmux panes. |

### Examples

```bash
# Live dashboard (loops, press Ctrl+C to exit)
mso status

# One-shot summary
mso status --once

# One-shot, compact view
mso status --once --compact
```

### Dashboard output

The status dashboard is the Squad Monitor v5.0 — a truecolor, indentation-based layout (no box-drawing characters; Unicode block bars `█░` and status dots `●○`). Colors degrade automatically on 256-color and legacy terminals, and output piped to a file is plain text. Sections, top to bottom:

**Header** — Persona product name, Maestro version (resolved dynamically from the installed package), and current timestamp.

**Voyage block** — Each active voyage with a progress bar, completed/total order counts, and an estimated time to completion. The first voyage gets a full block; additional parallel voyages render as condensed one-liners. On API billing, a SPEND line shows workspace cost against budget (from `.mso/usage/orders/`).

**ESCALATIONS** — Shown only when crews have raised blocking issues that require Captain/QM intervention.

**PENDING REVIEW** — Appears only when items require Captain sign-off: voyages/plans/requirements marked `AWAITING_APPROVAL`, plus orders paused at a human review gate. Hidden entirely when nothing is pending.

**Crews** — For each crew slot (persona-named):
- Status dot (ember = running, green = done, yellow = needs attention, red = failed, dim = idle)
- Role (PLN / BLD / TST / DOC / SEC / REL), model (Opus / Sonnet / Haiku), and assigned order ID
- Running crews: iteration progress bar, live turn counter, files changed, token spend, elapsed time, and a heuristic ETA (average iteration time × remaining iterations)
- Latest activity line with age (e.g. `> Edit maestro/cli.py (12s ago)`)

**QUEUE** — Pending order count with per-role breakdown (e.g. `BLD:3 TST:1`) and other queue tallies.

**LIFECYCLE** — Recent fleet lifecycle events (crew starts, completions, role transitions). Omitted in `--compact`.

**Footer** — Dispatcher status (active/stopped, PID, uptime), bridge status, aggregate crew counts, queue depth, and refresh interval.

---

## mso hub

**New in v5.0.0.** Manage the **Maestro Hub** — a real-time, multi-workspace
dashboard. Where `mso status` shows one workspace in one terminal, the Hub
aggregates live state across **every registered project**. In the default
**local mode** (FTR-MSO-2026-0421) one daemon serves both the REST API +
lifecycle WebSocket **and** the Next.js dashboard UI on a single port — **no
Docker, no Node.** The UI ships as a static export inside the wheel
(`maestro/hub/static/`); the backend serves it same-origin.

```bash
mso hub setup                      # local mode (default): validate registry + UI bundle, print start command
mso hub setup --mode docker        # generate device-local Docker deployment config
mso hub setup --mode docker --dry-run   # preview the generated files, write nothing
mso hub setup --mode docker --force     # regenerate over existing files
mso hub start                      # background daemon (backend + dashboard UI) on http://127.0.0.1:3847
mso hub start --port 4000 --open   # custom port; open a browser
mso hub status                     # running? PID + URL
mso hub stop                       # stop the daemon
```

`mso hub setup` provisions the Hub from your own `~/.maestro` registry (no
hand-edited config). **Local mode** (the default) validates the registry, confirms
the wheel-shipped UI bundle is present, and prints the start command — the native
backend reads `~/.maestro` directly, so it writes nothing. **Docker mode**
generates two device-local, gitignored files —
`docker/maestro-home/projects.json` (container registry with every host path
rewritten to `/repos/<basename>`) and `docker/docker-compose.local.yml` (the
Compose overlay) — then prints the `docker compose … up -d --build` command.
`--output-dir` overrides the target (default: the repo `docker/` dir, else
`MAESTRO_HOME/hub-docker/`); existing generated files are refused without
`--force`. Full walk-through: [HUB.md](HUB.md#provisioning-mso-hub-setup).

`mso hub setup` and `mso hub start` are gated to **Team / Enterprise** licences;
`mso hub stop` / `status` are not. For single-operator or development use, run the
backend ungated in the foreground (it still serves the bundled UI same-origin):

```bash
python -m maestro.hub --port 3847      # open http://127.0.0.1:3847
```

You only need the `maestro-hub/` source app when **developing** the dashboard —
local mode already serves the built UI. The dev server runs on its own port and
points back at the backend:

```bash
cd maestro-hub && NEXT_PUBLIC_HUB_URL=http://localhost:3847 npm run dev   # :3000
```

Prefer **Docker** only for a shared/multi-operator server (frontend and backend
in separate containers) — it is an option, not a prerequisite. A source checkout
with no built UI bundle degrades to API-only with a message at `/`.

Full guide — endpoints, tier gating, configuration, troubleshooting:
[HUB.md](HUB.md).

---

## mso demo

Run the Squad Monitor PVT — a simulated 6-order fleet that exercises every dashboard metric, then reports and cleans up after itself.

```
mso demo [--headless] [--fast] [--keep] [--project @PRJ]
```

The demo creates a demo voyage with 6 demo orders (2× 20s, 2× 40s, 2× 60s) and drives them through 3 simulated crew slots on a staggered schedule, writing the same workspace state files a real fleet writes. The live dashboard renders in-process while it runs, showing: voyage progress draining 0/6 → 6/6 with ETA, RUNNING crews with iteration bars / turn counters / token spend / heuristic ETAs, a mid-run escalation that resolves, a pending-review item that clears, queue drain with role breakdown, lifecycle events, and the SPEND line.

**No Claude invocations and no token spend** — the crews are simulated. While they run, the demo gathers *real* local findings for the final report: an OWASP pattern scan of the project's Python files, an outstanding-backlog review, a last-activity summary, and recommended next tasks.

The run ends with a PVT verdict (per-order timing tolerance ±35%, coverage checklist) written to `.mso/reports/demo/DEMO-PVT-<timestamp>.md`. Everything else the demo created is removed; pre-existing crew state files are restored byte-for-byte.

### Flags

| Flag | Type | Default | Description |
|------|------|---------|-------------|
| `--headless` | flag | `false` | Skip the live dashboard; run the simulation and print the report (CI / PVT mode). |
| `--fast` | flag | `false` | Scale all timings to 10% — full run in ~15s instead of ~100s. |
| `--keep` | flag | `false` | Keep the demo orders/voyage after the run for inspection. Crew state files are still restored. |
| `--project @PRJ` | string | — | Project alias if not run from inside a workspace. |

### Safety

`mso demo` refuses to run while the dispatcher is alive or any of crew slots 1–3 is RUNNING with a live process — it writes to the same crew state files a real fleet uses. Stale RUNNING states (dead PIDs) do not block it. The Slack bridge notifier is disabled for the duration so the synthetic escalation never pages anyone.

### Examples

```bash
# Full show — watch the dashboard drive itself for ~100 seconds
mso demo

# Quick smoke test (~15s, no dashboard) — exit code 0 on PVT PASS
mso demo --fast --headless
```

---

## mso usage

Report token usage and estimated API cost.

```
mso usage [--voyage VOY-ID | --order ORDER-ID | --summary | --report [--output PATH]]
```

### Flags

| Flag | Type | Description |
|------|------|-------------|
| *(none)* | — | Print overall summary across all projects |
| `--summary` | flag | Print overall summary (explicit form) |
| `--voyage VOY-ID` | string | Breakdown by order for a specific voyage |
| `--order ORDER-ID` | string | Token detail for a specific order |
| `--report` | flag | Generate full markdown usage report |
| `--output PATH` | string | File path for `--report` output. Defaults to stdout. |
| `--project ACRONYM` | string | Disambiguate when multiple Claude project directories match the workspace (e.g. `--project MSO` or `--project @MSO`). Can also be set via `MAESTRO_PROJECT=MSO`. |

### Examples

```bash
# Overall summary
mso usage --summary

# Voyage-level breakdown
mso usage --voyage VOY-MYPROJ-2026-0001

# Single order detail
mso usage --order FTR-MYPROJ-2026-0001

# Generate full report to a file
mso usage --report --output .mso/reports/usage-report.md
```

### Usage data source

Token counts are captured automatically at the end of each crew session by the stop hook. Usage data is stored per-order in `.mso/usage/orders/{ORDER-ID}.json`.

---

## mso squad / mso crew

Inspect or operate an individual squad (aka crew). `squad` is the primary command; `crew` is an alias — both work identically.

```
mso squad --crew N [--status | --watch | --cleanup]
mso crew  --crew N [--status | --watch | --cleanup]
```

### Flags

| Flag | Type | Required | Description |
|------|------|----------|-------------|
| `--crew N` | integer | Yes | Crew number. Valid range: 1–5. |
| `--status` | flag | No | Print crew status and last known state. |
| `--watch` | flag | No | Stream crew progress live from `progress.md`. |
| `--cleanup` | flag | No | Stop this specific crew's process and reset its state. |

### Examples

```bash
# Check squad 1 status
mso squad --crew 1 --status

# Watch squad 2 live
mso squad --crew 2 --watch

# Stop and reset squad 3 (crew alias also works)
mso crew --crew 3 --cleanup
```

---

## mso verify

Run post-voyage build and test verification.

```
mso verify [--voyage VOY-ID] [--skip-tests]
```

### Flags

| Flag | Type | Description |
|------|------|-------------|
| `--voyage VOY-ID` | string | Voyage ID to verify. Verifies all orders in the voyage. |
| `--skip-tests` | flag | Skip test execution; reuse existing test results from the build output. |

### Examples

```bash
# Verify a completed voyage
mso verify --voyage VOY-MYPROJ-2026-0001

# Verify but skip test re-run
mso verify --voyage VOY-MYPROJ-2026-0001 --skip-tests
```

### What verify checks

- Runs the configured build command for each project in the voyage
- Runs the configured test command
- Produces a verification report in `.mso/reports/voyage/`

---

## mso voyage reconcile

Housekeeping: check every voyage's pull-request state, archive the ones whose PR
has merged, and report what was left alone and why. Also available as the broom
button in the [Maestro Hub](HUB.md#housekeeping-sweep) — both run the same code.

```
mso voyage reconcile [--dry-run] [--json] [--voyage VOY-ID] [--repo REPO-SLUG]
```

`sprint reconcile` is the same command (`voyage` is the legacy alias for
`sprint`).

### Why you need it

In practice a human reviews and merges the voyage PR — often long after the
dispatcher that produced it has exited. Maestro therefore never *observes* the
merge, and the voyage sits in `voyages/active/` (and in the Hub's **Final
Review** column) indefinitely. Housekeeping is **pull-based**: you trigger it,
and it needs no running dispatcher. It also runs automatically at dispatcher
startup when `completion.onVoyageComplete.archiveVoyageOnMerge` is enabled.

### Flags

| Flag | Type | Description |
|------|------|-------------|
| `--dry-run` | flag | Report what *would* change without writing anything. Recommended first — reconcile mutates artefact state. |
| `--json` | flag | Emit the report as JSON instead of prose (see below). |
| `--voyage VOY-ID` | string | Reconcile only this voyage. |
| `--repo REPO-SLUG` | string | In a [multi-repo workspace](MULTI-REPO.md), only consider this repo's PR state. |

### What it does

For each voyage it can see:

1. **Resolves merge state** — see [How merge is detected](#how-merge-is-detected).
2. **Archives merged voyages** — voyage JSON moves from `voyages/active/` to
   `voyages/complete/` with merge metadata (`mergedAt`, `mergedPR`,
   `mergeDetectedBy`); its orders and prompts follow if
   `completion.onVoyageComplete.archiveOrders` is set.
3. **Backfills merge metadata** onto voyages already in `voyages/complete/`
   whose PR merged *after* they were finalised.
4. **Flags orders that are archived but not `COMPLETE`** — a stranded order is
   reported, never quietly treated as done.
5. **Reports every refusal with a reason** — an open PR, a voyage with no PR, a
   PR closed without merging, or a merge state it could not determine.

### Example output

```bash
$ mso voyage reconcile --dry-run
[Voyage] dry-run complete — 1 voyage(s) would be archived, 0 completed voyage(s) would be annotated with merge metadata
  [would archive] VOY-MSO-2026-0123: PR is merged (detected via pr)
[Voyage] 4 item(s) left untouched:
  [skipped] VOY-MSO-2026-0090: PR #181 is OPEN — refused to archive an unmerged voyage
  [skipped] VOY-MSO-2026-0121: no PR found for branch 'voyage/…' and the voyage is not finalisable
  [skipped] VOY-MSO-2026-0124: PR #285 is OPEN — refused to archive an unmerged voyage
  [skipped] VOY-MSO-2026-0100: already archived, but PR #218 is not merged — no merge metadata written
```

An earlier release printed only `0 voyage(s) archived`, which gave you nothing
to act on. Every decision now carries its reason.

### `--json` report shape

```json
{
  "dryRun": true,
  "archived": 1,
  "annotated": 0,
  "changes": [
    { "voyage": "VOY-MSO-2026-0123", "action": "archived",
      "reason": "PR is merged (detected via pr)", "prNumber": 284,
      "mergedAt": "2026-07-30T02:14:11Z" }
  ],
  "refusals": [
    { "voyage": "VOY-MSO-2026-0090", "action": "skipped",
      "reason": "PR #181 is OPEN — refused to archive an unmerged voyage",
      "prNumber": 181 }
  ],
  "entries": [ "… changes and refusals, in the order they were decided …" ]
}
```

| Field | Meaning |
|-------|---------|
| `dryRun` | Whether this run wrote anything. |
| `archived` / `annotated` | Counts of voyages archived and of completed voyages given merge metadata. |
| `changes` | Entries whose `action` is `archived`, `annotated` or `linked`. |
| `refusals` | Everything else — `skipped` and `flagged`. |
| `entries` | Both lists combined, in decision order. |

Every entry carries `voyage`, `action` and a human-readable `reason`, plus
`prNumber`, `mergedAt`, `order`, `orderStatus` or `repos` where relevant.

### How merge is detected

**The GitHub PR record is authoritative.** When a voyage records a `prNumber`,
Maestro looks that PR up **by number** and reads its `merged` field.

- Looking up by number (not by head branch) matters because GitHub deletes the
  head branch on merge — a branch-keyed lookup finds nothing precisely when the
  answer is "yes, merged".
- Reading `merged` (not `state`) matters because a merged PR reports
  `state: closed, merged: true`.
- `merged` is blind to merge strategy, so **squash, rebase and merge-commit all
  resolve correctly**. Squash was the case that used to fail: it lands one new
  commit on the base branch, so the voyage branch's own commits never become
  ancestors of the base and any ancestry-based check reported "unmerged"
  forever.

**Raw-git detection is the fallback** — used for voyages with no PR, and when
`gh` is unavailable, unauthenticated or offline. If neither path can decide, the
verdict is *unknown* and the voyage is left alone. Reconcile never reports a
merge it could not confirm, so an offline run degrades to doing less, never to
archiving unshipped work.

The `mergeDetectedBy` field on the archived voyage manifest records which path
decided: `"pr"` or `"git"`.

### When to run manually

- After you merged a voyage PR yourself (the common case)
- When the Hub still shows voyages in **Final Review** whose PRs are merged
- To clean up several stale voyages at once
- Before `mso status`, so the dashboard reflects current state

---

## mso order

Recover, hide, or inspect individual orders — the operator escape hatch for
the BUG-0294 ledger veto and the skip list.

```
mso order retry ORDER-ID [--role ROLE] [--reason TEXT] [--force] [--no-salvage]
mso order skip ORDER-ID [--reason TEXT]
mso order remove ORDER-ID --from-voyage VOY-ID
mso order unskip ORDER-ID
mso order list
```

Also available in the [Maestro Hub](HUB.md#voyage-inspection--retry) as a
**Retry** button on any order the board tags **Needs Attention** — both
surfaces call the same `maestro/core/order_retry.py` implementation
(FTR-MSO-2026-0492).

### `mso order retry`

Reopens an archived `STALLED`/`FAILED` order, or resets a stranded queued
order (`CONVERGENCE_FAILED` / `VERIFY_FAILED` / `BLOCKED` / …) to `PENDING`,
so the next `mso dispatch` picks it up again (BUG-MSO-2026-0297 /
BUG-MSO-2026-0344).

| Flag | Type | Description |
|------|------|-------------|
| `--role ROLE` | string | Role to retry at. Default: the role the order stalled in. |
| `--reason TEXT` | string | Why the order is being retried (recorded on the ledger `REOPENED` event). |
| `--force` | flag | Required to retry an order archived as `COMPLETE`, or a queued `IN_PROGRESS` order. |
| `--no-salvage` | flag | Re-run the role from scratch instead of fast-converging the newest `salvage/*` branch. |

What it does:

1. Clears the ledger's `TERMINAL` verdict and any lingering claim, and writes a
   `REOPENED` ledger event.
2. Moves an archived order back to `queues/orders/` as `PENDING` (a stranded
   queued order is reset in place) and fires the `RETRY` lifecycle event.
3. Arms the salvage fast path by default — the newest `salvage/<order>-<sha>`
   branch is fast-converged instead of the role re-running from a blank
   worktree. `--no-salvage` opts out.
4. Removes the order from the skip list, if present.

```bash
mso order retry BUG-MSO-2026-0141                # reopen a STALLED order (uses salvage fast path)
mso order retry BUG-MSO-2026-0141 --role BLD --reason "timeout cap raised"
mso order retry FTR-MSO-2026-0233 --force        # a COMPLETE order — needs --force
```

**Governed/enterprise workspaces (FTR-MSO-2026-0492):** retry now calls
`require_capability("order.dispatch")` — a gate `mso order retry` did not
enforce before this voyage. It is a no-op on other tiers; on a governed
workspace, a caller lacking the capability is refused. The Hub's retry
endpoint enforces the identical gate (403 on refusal) but — unlike Dispatch/
Sweep — cannot yet show it as a disabled button with a reason before the
click, because `/api/v1/capabilities` is workspace-independent and retry's
availability is not; the 403 is a real backstop here, not just defence in
depth, until a future order widens that contract per workspace.

### `mso order skip` / `remove` / `unskip` / `list`

| Command | Effect |
|---------|--------|
| `mso order skip ORDER-ID [--reason TEXT]` | Adds the order to the persistent skip list (`.mso/config/skipped-orders.json`). Honoured by `scan_all_queues()` (no re-dispatch, no WARN) and the housekeeping sweep (treated as satisfied). Survives dispatcher write cycles (BUG-MSO-2026-0288). |
| `mso order remove ORDER-ID --from-voyage VOY-ID` | Strips the order from a voyage's manifest **and** adds it to the skip list. |
| `mso order unskip ORDER-ID` | Removes the order from the skip list. Also reachable from the Hub's `/review` page **Skipped** tab. |
| `mso order list` | Shows every order currently in the skip list. |

---

## mso backup

Create a ZIP archive of workspace project state, or list available backups.

```
mso backup [--project ACRONYM] [--output PATH] [--list]
```

### Flags

| Flag | Type | Default | Description |
|------|------|---------|-------------|
| `--project ACRONYM` | string | all projects | Only include files for this project acronym (e.g. `OTM`). Files for other projects are excluded. |
| `--output PATH` | string | `./maestro-backups/` | Directory to write the backup archive. Created if it does not exist. |
| `--list` | flag | `false` | List available backups in the output directory instead of creating a new one. |

### What gets backed up

The following `\.mso/` subdirectories are included:

| Directory | Contents |
|-----------|---------|
| `orders/active/`, `orders/complete/`, `orders/failed/` | All order JSON files |
| `voyages/active/`, `voyages/complete/` | All voyage JSON files |
| `prompts/active/` | Active crew prompt files |
| `plans/` | Navigator planning documents |
| `handoffs/` | Inter-role handoff files |
| `requirements/` | Project requirements |
| `reports/` | Generated reports |
| `usage/orders/` | Token usage records |
| `config/` | `workspace.json`, `projects.json`, per-project configs |

Root workspace files also included: `CLAUDE.md`, `.mso/BACKLOG.md`, `.mso/VOYAGE-STATUS.md`.

The following directories are **excluded** (runtime/framework state — not project state):

| Excluded | Reason |
|---------|--------|
| `.mso/core/` | Framework scripts — provided by pip/submodule |
| `.mso/hooks/` | Framework hooks |
| `.mso/crews/` | Ephemeral crew runtime state |
| `.mso/logs/` | Ephemeral logs |
| `.mso/temp/` | Temp files |
| `.mso/queues/` | Regenerated by the dispatcher at runtime |

### Backup file format

Backups are ZIP archives named:

```
maestro-backup-{PROJECT_OR_ALL}-{YYYY-MM-DD-HHMMSS}.zip
```

For example: `maestro-backup-all-2026-03-30-143000.zip` or `maestro-backup-OTM-2026-03-30-143000.zip`.

Every archive contains a `manifest.json` at its root:

```json
{
  "version": 1,
  "created_at": "2026-03-30T14:30:00.000000",
  "workspace": "/path/to/workspace",
  "projects_included": ["OTM"],
  "maestro_version": "2.0.0",
  "file_count": 42
}
```

| Field | Description |
|-------|-------------|
| `version` | Backup format version (currently `1`) |
| `created_at` | ISO 8601 local timestamp |
| `workspace` | Absolute path to the workspace root at backup time |
| `projects_included` | List of project acronyms included (uppercase), or `["ALL"]` for a full backup |
| `maestro_version` | Maestro version that created the archive |
| `file_count` | Number of files in the archive (excluding `manifest.json`) |

### Per-project filtering

When `--project ACRONYM` is passed, only files whose names contain `-{ACRONYM}-` or start with `{ACRONYM}.` are included. Workspace-level files (`workspace.json`, `projects.json`, `CLAUDE.md`, etc.) are always included regardless of filter.

This is designed for multi-project workspaces where you want to extract or share the state of a single project without including others.

### Auto-backup before cleanup

`mso cleanup` automatically creates a full workspace backup before removing stale state. The backup path is printed so you know exactly where the snapshot was saved:

```
[Maestro] Auto-backup created: /workspace/maestro-backups/maestro-backup-all-2026-03-30-143000.zip
```

### Examples

```bash
# Full workspace backup (all projects)
mso backup

# Back up only the OTM project files
mso backup --project OTM

# Write backup to a custom directory
mso backup --output /mnt/backups/maestro/

# Back up OTM project to custom directory
mso backup --project OTM --output /mnt/backups/maestro/

# List available backups
mso backup --list

# List backups in a custom directory
mso backup --list --output /mnt/backups/maestro/
```

### Example --list output

```
[Maestro] Backups in /workspace/maestro-backups/:

  maestro-backup-all-2026-03-30-143000.zip
    Created:   2026-03-30T14:30:00+00:00
    Projects:  all
    Version:   2.0.0
    Files:     87

  maestro-backup-OTM-2026-03-29-090000.zip
    Created:   2026-03-29T09:00:00+00:00
    Projects:  OTM
    Version:   2.0.0
    Files:     34
```

---

## mso restore

Restore workspace project state from a backup archive.

```
mso restore BACKUP_FILE [--project ACRONYM] [--force] [--merge] [--dry-run]
```

### Flags

| Flag | Type | Default | Description |
|------|------|---------|-------------|
| `BACKUP_FILE` | positional | *(required)* | Path to the backup ZIP archive to restore from. |
| `--project ACRONYM` | string | all | Only restore files for this project acronym. Applies the same filename filter as `mso backup --project`. |
| `--force` | flag | `false` | Overwrite existing files unconditionally. |
| `--merge` | flag | `false` | Keep whichever copy has the later modification time. Skips the file if the destination is newer. |
| `--dry-run` | flag | `false` | Print what would be written without writing anything. |

### Conflict resolution

When a file from the archive already exists at the destination, the behaviour depends on the flags used:

| Mode | Flag | Behaviour |
|------|------|-----------|
| **Skip** | *(default, no flags)* | Leave the existing file untouched. Print `[SKIP] <file>`. |
| **Force** | `--force` | Overwrite the existing file unconditionally. |
| **Merge** | `--merge` | Compare modification times. Keep whichever copy is newer. Skip if the destination file is newer. |
| **Dry run** | `--dry-run` | Show the action for each file without writing anything. Summary line is prefixed `[DRY RUN]`. |

**Use-case guidance:**

- **Default (skip):** Safe for adding files from an older backup without touching anything already in place. Use when restoring into an active workspace where some state is current.
- **`--force`:** Use when restoring a clean snapshot to a fresh workspace, or when you want the backup to fully replace current state.
- **`--merge`:** Use when merging state from two separate workspaces (e.g. transferring project state to a new machine while keeping locally-modified orders).
- **`--dry-run`:** Always run `--dry-run` first when restoring into a workspace with active work to preview exactly what would change.

### Examples

```bash
# Restore from a backup (skip existing files by default)
mso restore maestro-backup-all-2026-03-30-143000.zip

# Preview what would be restored without writing anything
mso restore maestro-backup-all-2026-03-30-143000.zip --dry-run

# Restore only OTM project files from a full backup
mso restore maestro-backup-all-2026-03-30-143000.zip --project OTM

# Overwrite existing files unconditionally
mso restore maestro-backup-all-2026-03-30-143000.zip --force

# Keep the newer file when conflicts occur
mso restore maestro-backup-all-2026-03-30-143000.zip --merge

# Full path to archive
mso restore /mnt/backups/maestro/maestro-backup-OTM-2026-03-29-090000.zip --project OTM
```

### Example output

```
[Maestro] Restoring from: maestro-backup-all-2026-03-30-143000.zip
  Backup created: 2026-03-30T14:30:00+00:00
  Projects: all
  Maestro version: 2.0.0
  Files in archive: 87

[Maestro] Restore complete — extracted: 85, overwritten: 0, skipped: 2
```

---

## mso init

Scaffold a new Maestro workspace.

```
mso init --project ACRONYM [--directory PATH] [--force] [--pack NAME]
```

### Flags

| Flag | Type | Required | Default | Description |
|------|------|----------|---------|-------------|
| `--project ACRONYM` | string | Yes | — | Project acronym (2–8 uppercase letters, e.g. `OTM`, `MYPROJ`). |
| `--directory PATH` | string | No | current directory | Target directory for the workspace. Created if it does not exist. |
| `--force` | flag | No | `false` | Overwrite an existing `\.mso/` directory. Without this flag, init will not run if `\.mso/` already exists. |
| `--pack NAME` | string | No | `sdlc` | Division pack to scaffold — `sdlc`, `test-engineering`, `secops`, `tech-ba`, `devops`, or `ops-bpa`. Omit for the default SDLC workspace — `mso init` and `mso init --pack sdlc` are byte-identical. Non-`free` packs (every division pack except `sdlc`) require a matching licence tier (or `MAESTRO_SKIP_AUTH=1`). See [mso packs](#mso-packs) and [DIVISION-PACKS.md](DIVISION-PACKS.md). |

> **Community tier is limited to 1 registered project.** The gate is on *registering* a new, distinct project acronym — re-running `mso init --project ACRONYM` for an already-registered acronym (e.g. after moving the workspace) is always allowed. A second `--project` acronym is refused with a licence message rather than silently accepted and then unable to dispatch. See [LICENCE.md](LICENCE.md#tier-limits-enforced-in-code-not-just-advertised).

### Examples

```bash
# Scaffold in the current directory
mso init --project MYPROJ

# Scaffold in a specific directory
mso init --project MYPROJ --directory /path/to/my-workspace

# Re-scaffold (overwrite existing config)
mso init --project MYPROJ --force

# Scaffold with a division pack (Team/Enterprise tier)
mso init --project QA1 --pack test-engineering
```

### What init creates

| Path | Purpose |
|------|---------|
| `.mso/config/workspace.json` | Workspace-level settings |
| `.mso/config/projects.json` | Project registry |
| `.mso/config/projects/MYPROJ.json` | Per-project role path configuration |
| `.mso/orders/active/`, `complete/`, `failed/` | Order lifecycle directories |
| `.mso/voyages/active/`, `complete/` | Voyage lifecycle directories |
| `.mso/queues/orders/` and other queue tiers | Dispatch queues |
| `.mso/crews/crew1/` through `crew5/` | Per-crew working directories |
| `.mso/plans/`, `.mso/handoffs/` | Navigator artifacts |
| `CLAUDE.md` | Quartermaster configuration |
| `.gitignore` | Standard exclusions for crew runtime files |

---

## mso packs

Discover and inspect division packs — templated persona + role + order-type sets for non-SDLC
teams (`test-engineering`, `secops`, `tech-ba`, `devops`, `ops-bpa`, plus the built-in `sdlc`
pack). Full guide: **[DIVISION-PACKS.md](DIVISION-PACKS.md)**.

```
mso packs list
mso packs show PACK [--json]
mso packs validate [PACK] [--path DIR]
```

### Subcommands

| Subcommand | Description |
|------------|-------------|
| `list` | List built-in packs with tier and access ("yes" / "upgrade") badges. |
| `show PACK` | Print a pack's manifest, order types (`roleSequence` per type), and anatomy (which optional assets it ships). |
| `show PACK --json` | Print the raw `pack.json` manifest. |
| `validate [PACK]` | Validate a pack's manifest, role overlays, persona, order templates, gates, and workspace defaults. Validates every built-in pack if `PACK` is omitted. Exit `0` if all clean, `1` if any invalid (CI-usable). |
| `validate --path DIR` | Validate an arbitrary pack directory not on the built-in search path — useful while authoring a new pack before it ships. |

Role overlay files inside a pack are validated through the exact same code path as
`mso roles validate` (`maestro.roles.loader.parse_role_file`), so the two commands never drift
apart.

### Examples

```bash
mso packs list
mso packs show sdlc
mso packs show test-engineering --json
mso packs validate
mso packs validate test-engineering
mso packs validate --path ./my-pack
```

To scaffold a workspace with a pack applied, see `--pack` under [mso init](#mso-init).

---

## mso policy

Governance policy tooling. Two families of work share the `policy` group:

- **Signed bundles (Phase 2, enterprise):** `pull` / `verify` / `show` — distribute and verify
  Ed25519-signed policy bundles so an org can ship guardrails a local engineer cannot silently relax.
- **CI enforcement backstop (Phase 5):** `verify --ci` — re-evaluate a committed diff against the
  governed packs on infrastructure the engineer does not own. This is where governed-mode policy
  becomes **binding**: a rule bypassed on a developer's machine still fails the merge.

```
mso policy pull [--url URL]
mso policy verify [--bundle PATH]          # verify a signed bundle's signature (read-only)
mso policy verify --ci [options]           # CI backstop — evaluate a diff, fail on any violation
mso policy show
```

### `mso policy verify --ci`

Reuses the *same* pure engine the client-side pretool hook uses, so verdicts match. Every added line
of the diff is evaluated as a candidate command (Bash context) and each changed file's added content
as a candidate write (Write context); any `deny` rule that fires is a violation and the command exits
non-zero. Removed lines are never evaluated — they cannot execute.

| Flag | Description |
|------|-------------|
| `--ci` | Select CI diff-evaluation mode (vs. the default signed-bundle signature check). |
| `--base REF` / `--against REF` | Diff base for `base...HEAD` (default `origin/main`). |
| `--head REF` | Diff head (default `HEAD`). |
| `--staged` | Evaluate `git diff --staged` instead of a branch diff. |
| `--diff-file PATH` | Read a pre-computed unified diff (`-` = stdin). |
| `--repo PATH` | Repository directory to run git in (default: CWD). |
| `--exclude GLOB` | Skip paths matching GLOB (repeatable; **adds to** the defaults). |
| `--include GLOB` | Restrict evaluation to matching paths (repeatable). |
| `--no-default-excludes` | Scan everything — drop the built-in doc/pack exclude set. |
| `--warn-only` | Report violations but exit `0` (roll-out / observe mode). |
| `--json` | Emit a machine-readable report. |

**Default excludes** (authoring surfaces that legitimately contain trigger strings):
`*.md docs/* maestro/docs/* maestro/governance/library/* CHANGELOG* LICENSE*`. Note that `.github/*`
and `tests/*` are **scanned by default** (they execute in CI) — narrow with a targeted `--exclude`
only if your own workflows/fixtures embed trigger strings on purpose.

**Exit codes:** `0` clean (or `--warn-only`); `1` at least one governed-pack violation (**CI must
fail**); `2` operational error — bad diff source, git failure, tampered/unverifiable packs, or a
non-empty diff that did not parse cleanly (fail-closed).

```bash
mso policy verify --ci                                  # diff origin/main...HEAD
mso policy verify --ci --base origin/main --json        # machine-readable
git diff origin/main...HEAD | mso policy verify --ci --diff-file -
mso policy verify --ci --exclude 'tests/fixtures/*'     # narrow, documented exclude
```

A reusable composite GitHub Action ships at `.github/actions/policy-verify`, wired into this repo's
own `.github/workflows/policy-verify.yml` as a live example. Full trust-boundary model, the drop-in
snippet, and the client-vs-CI rationale: **[GOVERNANCE-TRUST-BOUNDARY.md](GOVERNANCE-TRUST-BOUNDARY.md)**
(`mso docs governance-trust-boundary`).

---

## mso setup

Run the interactive setup wizard, or perform a headless prerequisite check.

```
mso setup [--check]
```

The setup wizard runs three phases:

1. **Prerequisites** — Python version, Claude Code CLI, `ANTHROPIC_API_KEY`, Git, network reachability
2. **Project analysis** — scans the registered project for language, structure, CI config, and existing tooling
3. **Tailored suggestions** — prints recommended starting requirements and voyages based on your project

`setup` bypasses the standard auth check so new users can run it before activating a licence.

### Flags

| Flag | Type | Default | Description |
|------|------|---------|-------------|
| `--check` | flag | `false` | Run Phase 1 only. Exits `0` if all checks pass, `1` if any fail. No interactive output. |

### Examples

```bash
# Full interactive wizard
mso setup

# Headless prerequisite check (CI/CD, scripting)
mso setup --check
```

### Phase 1 — Prerequisite checks

| Check | Pass condition |
|-------|---------------|
| Python | 3.9 or later |
| Claude Code | `claude` on PATH and responds to `--version` |
| API key | `ANTHROPIC_API_KEY` set and non-empty |
| Git | `git` on PATH |
| Network | Can reach `api.anthropic.com` (optional — warns if offline) |

---

## mso licence

Manage the Maestro licence key for this machine.

```
mso licence <subcommand> [KEY]
```

### Subcommands

| Subcommand | Description |
|-----------|-------------|
| `activate <KEY>` | Parse, validate, and save a licence key to `~/.mso/licence.json`. |
| `status` | Show current licence mode: licence key, GitHub collaborator, or trial. |
| `deactivate` | Remove the stored licence key and free this machine's seat. |

This command is always available regardless of licence state — including after trial expiry.

### mso licence activate

```bash
mso licence activate ADM-TEAM-a1b2c3d4-20270331-x9y8z7
```

Validates the key format and HMAC checksum locally (no server call). On success, saves the key to `~/.mso/licence.json`. For Team and Enterprise keys, registers this machine as a seat.

**Output (Team tier):**

```
[Maestro] Licence activated.
  Tier:         Team
  Expires:      2027-03-31 (365 days)
  Max crews:    5
  Max projects: Unlimited
  Features:     dispatch, status, usage, backup, estimate, approve, roi-reporting, priority-support
  Seat:         Registered (machine: abc123def456)
```

### mso licence status

```bash
mso licence status
```

**Output (licence key active — Team tier):**

```
[Maestro Licence]
  Mode:           Licence key
  Tier:           Team
  Expires:        2027-03-31 (365 days)
  Max crews:      5
  Max projects:   Unlimited
  Features:       dispatch, status, usage, backup, estimate, approve, roi-reporting, priority-support
  Seat:           Registered (machine: abc123def456, since 2026-04-01)
  Last validated: 2026-04-01
```

**Output (Enterprise tier):** Includes an additional SSO line:

```
  SSO:            Placeholder (open a GitHub Issue to configure)
```

**Output (GitHub collaborator):**

```
[Maestro Licence]
  Mode:    GitHub collaborator
  User:    tavisbasing
  Access:  Contributor (unlimited)
  Note:    Licence key recommended for commercial use
```

**Output (trial mode):**

```
[Maestro Trial]
  Days remaining: 11/14
  Max crews:      3
  Max projects:   1
  To upgrade:     https://maestroai.com/pricing
```

### mso licence deactivate

```bash
mso licence deactivate
```

Removes `~/.mso/licence.json`. The machine will fall back to trial mode (or GitHub auth) on the next command.

**Output:**

```
[Maestro] Licence deactivated. Seat freed.
Machine will enter trial mode (or GitHub auth) on next command.
```

### Key format

Licence keys follow the format:

```
ADM-{TIER}-{ORG_HASH}-{EXPIRY}-{CHECKSUM}
```

| Component | Description |
|-----------|-------------|
| `TIER` | `TRIAL`, `SOLO`, `TEAM`, or `ENT` |
| `ORG_HASH` | 8 hex characters (organisation identifier, or `00000000` for Solo) |
| `EXPIRY` | `YYYYMMDD` — key expiry date |
| `CHECKSUM` | 6 alphanumeric characters (HMAC-SHA256 local validation) |

Example: `ADM-TEAM-a1b2c3d4-20270331-x9y8z7`

Validation is performed locally using an embedded HMAC — no network call is required.

---

## mso version

Print the installed Maestro version.

```
mso version
```

### Example

```bash
mso version
# Maestro Maestro v2.0.0
```

---

## Global Flags

These flags are accepted by every `mso` subcommand.

| Flag | Description |
|------|-------------|
| `--debug` | Show full tracebacks on unexpected errors. Also sets `MAESTRO_DEBUG=1` in child processes. Equivalent to running with `MAESTRO_DEBUG=1 mso ...`. |

---

## Exit Codes

| Code | Meaning |
|------|---------|
| `0` | Success |
| `1` | General error — configuration problem, licence issue, or unexpected runtime error |
| `2` | Usage / argument error — mistyped subcommand, wrong flags, ambiguous input |
| `3` | No work — command ran cleanly but nothing to do (empty queue, no matching data) |
| `130` | Interrupted — `Ctrl+C` at the top-level `mso` process |

For the full error taxonomy, debug mode reference, and did-you-mean behaviour, see [CLI-ERRORS.md](CLI-ERRORS.md).

---

## Environment Variables

These variables are injected by the Fleet Admiral into crew subprocesses. They are documented here for reference when debugging.

| Variable | Description |
|----------|-------------|
| `ANTHROPIC_API_KEY` | Required. Your Anthropic API key. Set in your shell profile. |
| `MAESTRO_LICENCE_KEY` | Licence key override. When set, takes precedence over `~/.mso/licence.json`. Suitable for CI/CD deployments. |
| `MAESTRO_CREW` | Crew number (1–5). Activates hook behaviour. Must not be set in interactive sessions. |
| `MAESTRO_ORDER` | Current order ID. |
| `MAESTRO_PROJECT` | Project acronym (e.g. `MYPROJ`, `ADM`). |
| `MAESTRO_REPO_PATH` | Managed repo clone path — the crew's working directory. |
| `MAESTRO_TEMP` | Centralized temp directory for crew-generated artifacts. |
| `MAESTRO_VOYAGE_BRANCH` | Voyage branch name used when committing crew output. |
| `MAESTRO_MAX_ITERATIONS` | Maximum stop-hook iterations before a crew is forcefully completed. Default: `25`. |
| `MAESTRO_COMPLETION_PROMISE` | Promise tag pattern the crew uses to signal task completion. |
| `MAESTRO_DEBUG` | Set to `1` to enable full traceback output for unexpected errors. Equivalent to passing `--debug`. Propagated to child processes by the CLI. |

---

*Maestro Maestro v2.0.0 — For licensing enquiries, contact [tavisbasing](https://github.com/tavisbasing).*
