# Install, upgrade, and uninstall

> Customer-facing reference for getting a clean Maestro install onto a machine, upgrading it, and
> removing it completely. If you only need the fast path, see
> [QUICKSTART.md](QUICKSTART.md) or [GETTING-STARTED.md](GETTING-STARTED.md) — this page exists
> for everything that goes wrong *around* `pip install`, not the happy path itself.

## The package was renamed

Maestro's PyPI package is **`maestro-fleet`**. It used to be published as `maestro` before the
rename; that name is retired. The Python import path is unaffected — `import maestro` still
works either way, because both packages install into the same `site-packages/maestro/`
directory and ship the same `mso` console script.

That last fact is exactly why a stale `maestro` install is dangerous: **`pip` does not know the
two package names are related**, so it will not remove one when you install the other. If you
still have `maestro` installed, running `pip install maestro-fleet` layers a second package
record on top of the first without cleaning it up — see [Detecting overlapping
installs](#detecting-overlapping-installs) below for what that looks like in practice and why it
silently produces a stale-version symptom that's hard to diagnose from the outside.

**If you have ever installed the old `maestro` package, remove it before installing
`maestro-fleet` — upgrading is not enough:**

```bash
pip uninstall maestro
pip install maestro-fleet
```

## Install (default path — PyPI)

```bash
pip install maestro-fleet
mso version
```

`mso version` should print the version you just installed. If it doesn't — or if `pip show
maestro-fleet` and `mso version` disagree — go straight to [Detecting overlapping
installs](#detecting-overlapping-installs); that mismatch is the signature of exactly this
problem.

To pin a version: `pip install maestro-fleet==5.8.0`.

> **Air-gapped / restricted-egress environments only:** a private wheel index
> (`https://maestrodevs.github.io/simple/`) mirrors the same wheels under the legacy `maestro`
> distribution name, for machines that can't reach public PyPI. This is the **exception**, not
> the default install path — most customers should never need
> `--extra-index-url`. If that's you, see [AIR-GAPPED.md](AIR-GAPPED.md) for the full staging
> and egress-allowlist pattern before using it.

## Upgrade

```bash
pip install --upgrade maestro-fleet
mso version
```

Your activated licence (`~/.maestro/licence.json`) is **not** touched by an upgrade — it lives
outside `site-packages` entirely. See [Licence survival across
installs](#licence-survival-across-installs) below for the one case where you do need to act
after an upgrade.

## Uninstall

There is no `mso uninstall` command — removal goes through `pip`, same as any other Python
package. The steps below cover the parts that are easy to miss.

### 1. Check what's actually installed, in every scope

`pip` maintains **separate** package records per interpreter scope. It is entirely possible —
and, on a machine with an elevated/admin install plus a later user-scope install, common — to
have more than one copy of Maestro installed at once, at different versions, each answering to
the same `mso` command depending on which one resolves first.

```bash
pip show maestro-fleet
pip show maestro          # the old name — check this too
```

If either command prints something, that scope has an install. Repeat with an elevated / admin
shell to check the **system** scope separately from your **user** scope — `pip show` only sees
the scope the current shell's `pip` resolves to, not every scope on the machine.

**Windows:** an elevated (Run as Administrator) `cmd`/PowerShell and a normal user shell can see
two entirely different installs. **macOS/Linux:** `sudo pip show ...` vs a plain `pip show ...`
likewise.

### 2. Know which one `mso` actually runs

`pip show`, `mso version`, and a bare `mso` command can each resolve to a **different** install
if more than one scope has a copy. This was the core confusion in the field report this page was
written to close: `pip show maestro` reported one version while `mso version` reported another,
because the two commands were resolving against different site-packages directories.

```bash
mso version                                  # what the CLI you actually run resolves to
python -c "import maestro, os; print(os.path.dirname(maestro.__file__), maestro.__version__)"
```

Run the `python -c` check from a directory that does **not** itself contain a `maestro/`
subfolder — running it from inside a Maestro source checkout will import that checkout instead
of the installed package (`import` puts the current directory on `sys.path` first). `mso
version` itself does not have this problem, since it resolves via the installed console-script
entry point rather than a cwd-sensitive import.

**A user-scope shadow is easy to miss.** If you (or a script, CI job, or service account) set
`PYTHONNOUSERSITE=1` or run with `python -s`, Python skips the user site-packages directory
entirely and falls back to whatever is left in the system scope — which can be an **older**
version than the one `mso version` reports in a normal shell, with no warning printed either way.
If you operate Maestro from a venv, CI runner, or service account, check that environment's own
`mso version` — do not assume it matches your interactive shell's.

### 3. Uninstall every scope that has a copy

```bash
pip uninstall maestro-fleet
pip uninstall maestro          # only if step 1 found it
```

If a system-scope copy was installed elevated, uninstalling it also requires elevation — an
ordinary shell will fail with a bare `Access is denied` (Windows) or `Permission denied`
(macOS/Linux) rather than a clear "needs admin" message. Re-run the same command from an elevated
/ `sudo` shell.

Repeat steps 1–3 until `pip show maestro-fleet` and `pip show maestro` both report nothing, in
**every** scope you checked.

### 4. Check for an orphaned package directory

`pip uninstall` removes files it has a record of, via the package's `RECORD` metadata. If a
machine has accumulated overlapping installs (e.g. an old `maestro` install whose `dist-info` was
itself later overwritten by a different tool or a partial upgrade), the actual `maestro/` package
directory in `site-packages` can end up **untracked by either package's `RECORD`** — so
uninstalling both packages cleanly leaves the directory behind, and neither `pip show` command
sees it because there's no metadata pointing at it any more.

After confirming both `pip show` commands report nothing, check the directory directly:

```bash
python -c "import site; print(site.getsitepackages())"   # system scope candidates
python -c "import site; print(site.getusersitepackages())"  # user scope
```

If a `maestro/` directory still exists under any of those paths after both `pip show` commands
come back empty, it's orphaned — remove it manually. It contains no user data (your workspace
artefacts live under your project's `.mso/`, never inside the package directory).

### 5. Confirm the CLI is really gone

```bash
mso version
```

This should now fail with "command not found" (or your shell's equivalent). If it still
resolves, another scope still has a copy — go back to step 1 and check scopes you haven't yet
(a shell restart can also be needed for `PATH` caching).

## Detecting overlapping installs

The single most useful diagnostic when Maestro is behaving inconsistently — commands seeming to
run an older version, `mso version` and `pip show` disagreeing, licence tier not matching what
you activated — is to check what's actually resolving:

```bash
pip show maestro-fleet
pip show maestro
mso version
python -c "import maestro, os; print(os.path.dirname(maestro.__file__), maestro.__version__)"
```

Run the `python -c` line from a directory with no `maestro/` subfolder of its own (see the note
in step 2 above). If these disagree, you have more than one install shadowing each other —
follow the [Uninstall](#uninstall) steps above to get to a single clean scope, then reinstall:

```bash
pip install maestro-fleet
mso version
```

## PATH / Scripts directory

`pip install` places the `mso` executable in your interpreter's scripts directory — on
Windows this is typically `...\Python3xx\Scripts\` (system scope) or
`%APPDATA%\Python\Python3xx\Scripts\` (user scope, i.e. `pip install --user`); on macOS/Linux
it's usually `~/.local/bin` for a user install. If `mso` is "not found" immediately after a
successful `pip install`, this directory is not on your `PATH` — `pip`'s own install output
usually warns about this at install time; scroll up and check.

## Licence survival across installs

**`~/.maestro/licence.json` lives outside `site-packages` and survives every install, upgrade,
and uninstall/reinstall cycle described on this page.** You do not need to re-activate just
because you reinstalled the package.

**The one thing that does *not* survive every install path: the in-package licence trust root.**
A correctly-published `maestro-fleet` wheel from PyPI (or the private index) always carries the
vendor's signing key baked in, so a normal install/upgrade verifies your existing licence file
with no action needed. But if you ever install from a **source checkout** (`pip install .
--no-deps` or `pip install -e .` against a clone of this repo, rather than a published wheel),
that install carries an **empty** trust root by design — the repo's own tracked keyring ships
`"keys": {}` — and your licence file will fail to verify even though it's still there and
otherwise valid. `mso licence status` prints a specific warning when this happens.

**The fix is always the same:**

```bash
mso licence activate <YOUR-EXISTING-KEY>
mso licence status
```

This doesn't touch your Polar subscription — it re-issues a fresh signed local record against
the key material your current install actually has. Full detail, including the two published
versions (5.6.4, 5.7.0) that briefly shipped this same empty-trust-root defect from a **release**
build rather than a source build: [LICENCE.md § Does an install or upgrade preserve my
licence?](LICENCE.md#does-an-install-or-upgrade-preserve-my-licence)

## More documentation

This page is one of the docs shipped inside the `maestro-fleet` wheel itself — every install
already has the full set on disk. List them and read any of them without leaving your terminal:

```bash
mso docs                    # list every shipped topic
mso docs install-upgrade-uninstall   # this page
mso docs troubleshooting    # broader error-code reference
mso docs licence            # full licence CLI reference
```

See also: [TROUBLESHOOTING.md](TROUBLESHOOTING.md) for numbered error codes (including licence
and PATH failures), and [AIR-GAPPED.md](AIR-GAPPED.md) for the private-index / offline path.
