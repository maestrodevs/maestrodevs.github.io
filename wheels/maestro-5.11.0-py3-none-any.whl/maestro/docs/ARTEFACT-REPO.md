# Maestro — Artefact Repository (Solo Mode)

> Audience: operators running a single-engineer / single-machine Maestro workspace who want to
> stop carrying Maestro's bookkeeping (orders, voyages, plans, reports) inside their product
> repository's git history.

## Contents

- [What this is](#what-this-is)
- [Why](#why)
- [How it works, in brief](#how-it-works-in-brief)
- [Enabling it: `mso migrate artefact-repo`](#enabling-it-mso-migrate-artefact-repo)
- [Naming convention](#naming-convention)
- [Config reference: the `artefacts` block](#config-reference-the-artefacts-block)
- [Solo mode against a shared remote: a refused misconfiguration](#solo-mode-against-a-shared-remote-a-refused-misconfiguration)
- [Corporate shared mode](#corporate-shared-mode)
- [Multi-device ID allocation](#multi-device-id-allocation)
- [Conflict handling: automated vs. human-resolved](#conflict-handling-automated-vs-human-resolved)
- [Pre-migration cleanup checklist](#pre-migration-cleanup-checklist)
- [Rollback](#rollback)
- [FAQ](#faq)
- [See also](#see-also)

---

## What this is

By default (**embedded mode**), Maestro's entire `.mso/` workspace — queues, orders, voyages,
plans, handoffs, reports, config, and the runtime crew/log state — lives inside your product
repository, next to your source code. Every order created, every role transition, every voyage
completion is a commit in the product repo's history.

**Solo artefact-repo mode** moves the *durable* part of that workspace (the part you'd want to
keep and read later — queues, orders, voyages, plans, handoffs, reports, usage, config) into a
**separate, dedicated git repository**. Your product repo goes back to carrying only your actual
source code, tests, and docs. The *runtime* part (crew scratch state, logs, the dispatch ledger,
worktrees, PID files) stays exactly where it always was conceptually — machine-local and
gitignored — it just now lives inside the new artefact repo's checkout instead of your product
repo's checkout.

Embedded mode remains the default for every existing and new workspace. Nothing changes unless
you opt in.

## Why

- **Live state off feature branches.** In embedded mode, an order or voyage created while a
  feature branch is checked out only exists on that branch until it's merged. Anyone looking at
  `main`, or working in a different worktree, doesn't see it. A dedicated artefact repo commits
  every lifecycle transition to its own default branch — there is no feature-branch equivalent,
  so the state is always current from anywhere.
- **No product-repo bloat.** Maestro's own bookkeeping commits, PR-review noise, and merge
  traffic no longer land in your product repository's history or its pull requests. Your product
  repo's `git log` goes back to being just your product's history.
- **Same layout, same paths.** The artefact repo's root looks exactly like your workspace root
  does today — it has a `.mso/` directory with all the same subdirectories underneath it. If
  you've used Maestro before, nothing about how you read or navigate `.mso/` changes.

## How it works, in brief

Once migrated, you have two repositories instead of one:

| Repo | Holds | You dispatch from here |
|---|---|---|
| **Artefact repo** (`<ACRONYM>-Platform`) | `.mso/` — queues, orders, voyages, plans, handoffs, reports, config, usage, plus the gitignored runtime state | ✅ yes |
| **Product repo** (your existing repo) | Your source code, tests, docs — no `.mso/` at all | crews still branch, commit, and open PRs here |

`mso` commands resolve the artefact repo and the product repo separately once solo mode is on —
you don't need to pass extra flags to `mso dispatch`, `mso status`, or `mso order` day to day.
Run them from the artefact repo directory, or from the product repo — unless you migrated with
`--clean-product`, the migration leaves a small pointer file in the product repo (see
[Config reference](#config-reference-the-artefacts-block)) that redirects Maestro to the
artefact repo automatically. With `--clean-product`, dispatch from the artefact repo directory.

Every order, voyage, or role-transition change commits to the artefact repo's default branch
automatically, and pushes to its remote on a short debounce (a few dispatch events in quick
succession become one push, not one push each) if you've configured a remote.

## Enabling it: `mso migrate artefact-repo`

```bash
# Preview what would happen — mutates nothing
mso migrate artefact-repo --dry-run

# Migrate into a sibling directory named <ACRONYM>-Platform (the default)
mso migrate artefact-repo

# Choose an explicit destination
mso migrate artefact-repo --dest C:/Repos/MSO-Platform

# Choose a custom repo name and wire a remote
mso migrate artefact-repo --name GKT-Platform --remote git@github.com:your-org/GKT-Platform.git

# After confirming the artefact repo looks right, detach .mso/ from the product repo's
# git index (files stay on disk; they're just no longer tracked there)
mso migrate artefact-repo --clean-product
```

| Flag | Description |
|---|---|
| `--dest PATH` | Destination artefact-repo directory. Default: a sibling directory named `<ACRONYM>-Platform`. |
| `--name NAME` | Artefact repo name, used when `--dest` isn't given. Default: `<ACRONYM>-Platform`. |
| `--remote URL` | Optional git remote to wire as `origin` on the new artefact repo. |
| `--clean-product` | After the migration succeeds, `git rm --cached` the `.mso/` directory from the product repo's index and add it to the product repo's `.gitignore`, with a sweep commit. Files stay on disk. |
| `--dry-run` | Print the full action table without mutating anything. |
| `--rollback` | Undo a migration: deletes the `--dest` artefact repo and reverts your project registration to embedded mode. Requires `--dest`. |
| `--project @PRJ` | Target a specific registered project by acronym, if you have more than one workspace registered. |

**What the migration does, step by step:**

1. **Pre-flight cleanup gate** — refuses to proceed if a dispatcher is currently running against
   the workspace, if any crew/voyage/salvage worktree still exists, if any voyage/crew/salvage
   branch carries `.mso` commits not yet merged to your default branch, or if you have
   uncommitted `.mso` changes. Every blocker is reported with the exact command to clear it — see
   [Pre-migration cleanup checklist](#pre-migration-cleanup-checklist).
2. **Backup** — takes a full workspace backup zip before touching anything.
3. **Provision** — creates the destination directory as a fresh git repository with the runtime
   `.gitignore` block and a generated `README.md`.
4. **Copy-fresh import** — copies every git-tracked file under your product repo's `.mso/` into
   the new repo and makes a single commit: `import: .mso from <product-repo>@<sha>`. Your
   product repo's `.mso` history is untouched and still readable there — this is a copy, not a
   move.
5. **Verify** — compares every file that landed in the new repo against its source, byte for
   byte (SHA-256). If anything doesn't match, the migration stops here with your product repo
   still fully functional in embedded mode; the partially-built artefact repo is left in place
   for inspection rather than silently discarded.
6. **Register** — updates your global project registration (`~/.maestro/projects.json`) and
   writes the `artefacts` config block into the new artefact repo's `workspace.json` (see
   [Config reference](#config-reference-the-artefacts-block)).
7. **Optional product-repo cleanup** — only with `--clean-product`: untracks `.mso/` from the
   product repo's git index (keeping the files on disk) and adds it to the product repo's
   `.gitignore`.

The migration is **idempotent** — running it again against an already-migrated workspace prints
its current status and does nothing further.

## Naming convention

Artefact repos are named `<ACRONYM>-Platform` by default — e.g. a workspace registered under the
acronym `GKT` migrates to `GKT-Platform`. This is deliberate: Maestro avoids naming a customer's
own repositories after "Maestro" itself. Override the name with `--name` or the full path with
`--dest` if you'd prefer something else.

## Config reference: the `artefacts` block

Written by the migration into the **artefact repo's** `.mso/config/workspace.json`:

```json
{
  "artefacts": {
    "mode": "solo",
    "root": "C:/Repos/MSO-Platform",
    "productRepo": "C:/Repos/Maestro",
    "pushDebounceSeconds": 30,
    "remote": "git@github.com:your-org/MSO-Platform.git"
  }
}
```

| Key | Default | Description |
|---|---|---|
| `mode` | *(absent = embedded)* | `"solo"` after migration. `"shared"` — see [Corporate shared mode](#corporate-shared-mode) below. |
| `root` | — | Absolute path to the artefact repo. |
| `productRepo` | — | Absolute path to your product repo. |
| `pushDebounceSeconds` | `30` | How long to wait after a lifecycle commit before pushing to `origin`, so a burst of dispatch activity produces one push instead of many. `0` pushes immediately after every commit. Applies in both `solo` and `shared` mode — shared mode's order **claims** are the one exception (they never debounce; see below). |
| `syncIntervalSeconds` | `60` | **Shared mode only.** How often the dispatcher fetches + rebases the artefact repo to pull in other machines' claims and completions. Ignored in `solo`/embedded mode. |
| `divergenceRetryThreshold` | `3` | Consecutive failed pushes (any cause — auth, network, non-fast-forward) before the generic sustained-divergence escalation fires (`ARTEFACT_PLANE_DIVERGED`). Applies in solo and shared mode alike. |
| `divergenceCommitThreshold` | `3` | Commits ahead OR behind `origin` before that same generic escalation fires, even if the retry count hasn't been reached — either signal is enough (OR, not AND). |
| `planeDivergedHaltRetries` | `3` | Consecutive **non-fast-forward** push rejections before dispatch halts for NEW crews — a sharper, exact-proof signal distinct from the two keys above. See [Solo mode against a shared remote](#solo-mode-against-a-shared-remote-a-refused-misconfiguration). |
| `remote` | *(absent)* | Present only if you passed `--remote`. A remote is **optional** in solo mode (**required** in shared mode) — see the [FAQ](#faq). |

A minimal pointer stub (`{"artefacts": {"mode": "solo", "root": "..."}}`) is also written into
your **product repo's** `workspace.json` (unless you used `--clean-product`), so that an
interactive session started from the product repo still finds the right workspace.

## Solo mode against a shared remote: a refused misconfiguration

**A remote artefact repo that more than one machine writes to requires `artefacts.mode:
"shared"`.** Pointing `mode: "solo"` at a remote another device also pushes to is not a smaller,
free version of shared mode — it is a misconfiguration, and Maestro detects and escalates it
rather than silently corrupting the plane.

Solo mode is **push-only by construction**: it has no pull, no rebase, and no cross-machine
claim. The fetch+rebase that makes another machine's work visible, and the cross-machine claim
mutex described under [Corporate shared mode](#corporate-shared-mode) below, are both gated to
`mode: "shared"` — solo mode never calls either. A solo dispatcher pointed at a shared remote
therefore never fetches (its view of queues/orders/voyages freezes at whenever a human last
pulled), never claims (nothing stops two devices dispatching the same order), and its own push is
the *only* remote operation it performs at all.

That last property is also what makes the misconfiguration exactly detectable. **Solo mode is the
plane's only writer by definition** — so if solo mode's own push is ever rejected
non-fast-forward, that is not a transient blip to retry quietly; it is direct proof some other
writer moved `origin` out from under it. Nothing else could have.

**What the operator sees.** The first non-fast-forward push rejection fires a `PLANE_DIVERGED`
lifecycle event immediately — no threshold, no accumulated evidence needed, unlike the generic
sustained-failure escalation described below. In solo mode the message says so explicitly:

> PLANE DIVERGED — a non-fast-forward push to origin/\<branch\> was rejected. Solo mode is
> push-only by construction (no pull, no rebase, no arbitration) and is the plane's ONLY writer
> by definition, so this rejection is direct proof THIS PLANE HAS ANOTHER WRITER that solo mode
> cannot coordinate with. Remedy: mso migrate artefact-repo --mode shared, or pull/reconcile — ...

Dispatch is **not** blocked on the first or second occurrence — an offline solo laptop with a
stale remote is a legitimate state, and FTR-MSO-2026-0366's offline tolerance is deliberately
preserved. But once the rejection repeats on **3 consecutive** push attempts
(`artefacts.planeDivergedHaltRetries`, default `3` — roughly 90 seconds at the existing capped
backoff, long past the point a genuine transient would have resolved), the dispatcher **halts new
crew dispatch** until a push succeeds again. Crews already running are never touched — only new
launches are held, the same fail-open shape as the existing offline/licence dispatch gates.
`mso status` surfaces the divergence throughout, via the same state file the generic escalation
below already writes.

**The remedy is always one of two things:** either genuinely intend to share this plane across
machines — in which case migrate with `mso migrate artefact-repo --mode shared` (Team/Enterprise;
see [Corporate shared mode](#corporate-shared-mode) below) so the pull/rebase/claim machinery solo
mode lacks comes online — or reconcile manually (pull the remote's changes into your local clone)
if this was genuinely meant to stay a single-writer plane and something pushed to it by mistake.

This sits alongside a second, independent, generic escalation (`ARTEFACT_PLANE_DIVERGED`,
BUG-MSO-2026-0548): any sustained push failure — auth, network, non-fast-forward, anything — that
persists past `artefacts.divergenceRetryThreshold` consecutive failures (default `3`) OR diverges
by `artefacts.divergenceCommitThreshold` commits ahead/behind (default `3`) also escalates from
the routine retry `WARN` to a louder, `mso status`-visible signal. That mechanism does not
distinguish *why* the push is failing and never halts dispatch by itself. The misconfiguration
signal above is a sharper, second layer specifically for the one failure mode that is exact proof
rather than a suspicion: a non-fast-forward rejection in solo mode.

## Corporate shared mode

> **Tier:** shared mode is gated to **Team / Enterprise** licences. Switching a workspace's
> `artefacts.mode` to `"shared"` on a lower tier refuses at dispatcher startup with an upgrade
> message (`MAESTRO_SKIP_AUTH=1` bypasses this for CI, as it does everywhere else).

Solo mode assumes one engineer, one machine, one dispatcher. **Shared mode** extends the same
artefact repo to **multiple engineers, each running their own dispatcher, against one shared
private remote** — with no server component. Concurrency safety is entirely git-native:

```json
{
  "artefacts": {
    "mode": "shared",
    "root": "C:/Repos/MSO-Platform",
    "productRepo": "C:/Repos/Maestro",
    "remote": "git@github.com:your-org/MSO-Platform.git",
    "pushDebounceSeconds": 30,
    "syncIntervalSeconds": 60
  }
}
```

**What "claim-by-commit" means operationally.** Before a dispatcher launches a crew on an order, it
stamps that order's file `IN_PROGRESS` with a `claimedBy: {engineer, host, pid, at}` field, commits,
and **pushes immediately** — claim pushes never wait for the debounce window; the push itself is the
cross-machine mutex. Two engineers' dispatchers picking up the same order at the same moment produce
a race at the `git push`: whichever push lands first wins the claim, and the other dispatcher's push
is rejected.

- **You lose the race:** your dispatcher fetches + rebases, sees the order is already claimed by
  someone else, releases its own attempt, and moves on to the next order — no crew is spawned, and
  nothing is reported as an error. This shows up in the lifecycle log as `RELEASED` with reason
  `lost-claim-race`.
- **You win the race:** your push succeeds and your crew launches. This shows up as `CLAIM_PUSHED`.
- Every other lifecycle transition (advance, archive, usage-write, review actions) only conflicts if
  two engineers' dispatchers happened to be working the *same* order — which claims already prevent,
  since an order is claimed before any crew touches it.

**Debounced sync.** Independent of claims, each dispatcher periodically fetches + rebases the
artefact repo (`artefacts.syncIntervalSeconds`, default **60** seconds) so that other machines'
claims and completions become visible to its own next dispatch scan. This is separate from — and in
addition to — the `pushDebounceSeconds` debounce that governs non-claim lifecycle commits.

**Offline behaviour.** Every remote git operation (claim push, rebase, sync fetch) is **fail-open**:
if the remote is unreachable, the dispatcher degrades to working **local-only** and emits a loud
`WARN` lifecycle event rather than blocking or crashing. A crew claimed while offline still launches
and does useful work; its claim/completion commits push automatically once connectivity returns. The
honest cost of this design is a **documented split-brain window** — while offline, your dispatcher
cannot see (or be seen by) other engineers' claims, so in rare cases two dispatchers could both claim
the same order while both are offline from each other. This resolves itself the same way a live race
does the moment both reconnect and rebase: one claim's push wins, the other releases.

**`claimedBy` in the Hub.** The Hub surfaces each claimed order's `claimedBy` metadata
(engineer/host/timestamp) wherever it shows order state, so a team can see at a glance who is
currently working which order across every machine's dispatcher — this needs no extra Hub
configuration once your project is registered against a shared-mode artefact repo.

## Multi-device ID allocation

Claim-by-commit (above) begins **after** an order already exists — it arbitrates *dispatch* of an
order, not the minting of its id. Creating an order (`mso bug`) or a voyage
(`mso voyage create`) is a separate, earlier step that claim-by-commit's mutex does not cover.
Two engineers on two devices, each unaware the other is about to run `mso bug`, could otherwise
mint the exact same `BUG-<PRJ>-<YEAR>-<NNNN>` id — a distinct problem from the dispatch race
claim-by-commit solves.

Two changes close most of this gap:

1. **Fetch-before-allocate, in every mode** (not shared-mode-only). Before minting an id, the
   allocator fetches the artefact repo's remote branch (bounded ~20s timeout) and scans the
   fetched remote-tracking tree alongside the local scan, folding both maxima together before
   choosing the next number. Any failure point — no git repo, no `origin` remote, no resolvable
   branch, an unreachable network, a subdirectory that doesn't exist yet at that ref — is skipped
   **silently**: allocation falls back to the local-only scan exactly as before this existed,
   never an error, never a block. This preserves FTR-MSO-2026-0366's deliberate offline-first
   contract. The scan is type-agnostic across the whole sequence space, so this closes the gap for
   orders *and* voyages together, not per type.
2. **Reservation push, `mode: shared` only.** In shared mode, minting additionally *commits and
   pushes immediately* — reusing claim-by-commit's push-as-mutex shape (not its literal code: a
   reservation collision has nothing to release, only a fresh number to re-mint). Push accepted →
   done. Push rejected (someone else's reservation landed first) → the local commit and file are
   undone, the remote is fetched and reset to, and a fresh number is re-minted against the new
   state — up to 3 attempts before falling back local-only (the same fail-open posture as
   claim-by-commit's own retry bound). Solo and embedded mode never take this path; they get the
   fetch above, not the reservation.

**What this does not close.** Fetch-before-allocate narrows the collision window to the fetch
itself — it does not eliminate it. Two `mso bug` calls on two solo/embedded devices, inside the
same few-second fetch window, can still collide; this is accepted because order/voyage creation
is a human action at human cadence, not a hot dispatch-loop path, and the reservation push (shared
mode only) is the fully race-free answer for teams that need one. If you are creating orders
concurrently often enough that this matters, that is itself a signal to migrate to
`mode: shared`.

## Conflict handling: automated vs. human-resolved

Not every conflict two devices can produce on a shared plane is something Maestro arbitrates —
and that split is deliberate, not a gap awaiting automation.

**What IS arbitrated automatically:**

- **Duplicate dispatch of the same order** — claim-by-commit, above.
- **A `COMPLETE` order regressed to a non-`COMPLETE` status by a device that hadn't yet learned
  it was already finished.** The dispatch ledger's TERMINAL-is-forever rule always refused this
  in mechanism; the fix was to stop the plane-reconciliation that feeds the ledger from running
  only once at ledger creation, and make it run on every dispatcher startup instead — so a device
  that pulls the plane always learns every other device's terminal verdicts, not just whatever
  existed at the moment its own ledger was first created. An order whose archive carries a
  `relSignOff` block is hard-refused from regression; the only sanctioned way past it is
  `mso order retry --force` (`COMPLETION_REGRESSION_REFUSED` in the lifecycle log names what was
  protected).

**What is NOT automated, on purpose:** add/add conflicts on narrative artefacts — two devices
each writing a different handoff (`handoffs/.../REL-to-LEAD.md`) or a different voyage report
(`reports/voyage/VOYAGE-....md`) for the same order. These remain genuine git conflicts requiring
human resolution, and that is the correct outcome — two people (or two crews) wrote different
prose about the same thing, and no automated rule can pick which one is right. Maestro surfaces
these as ordinary git merge conflicts for a human to resolve, exactly as it would for any other
untracked disagreement.

**Why not ship a `.gitattributes` with `merge=union` for these files? (considered and rejected)**
This was proposed and evaluated and rejected — recorded here, with the reasoning, so the idea
isn't re-proposed without it:

- **The files a union-merge rule would plausibly target — `.jsonl` ledgers, `.log` lifecycle
  files — aren't in the shared plane at all.** `.mso/state/` (the ledger), `.mso/logs/`, and
  `.mso/crews/` are runtime/device-local and gitignored; the artefact repo carries only the
  durable plane (`orders, queues, voyages, plans, handoffs, reports, usage, config`). A
  `merge=union` rule on those patterns would match nothing that ever syncs.
- **The files that actually conflicted in the field are `.md` narrative artefacts, and
  union-merging prose is actively harmful, not helpful.** `merge=union` concatenates both sides'
  lines rather than choosing one — for a handoff or voyage report, that silently produces a
  document containing two different, possibly contradictory accounts stitched together with no
  indication either existed, which is worse than an explicit conflict marker a human has to look
  at and resolve.
- **The existing 3-way merge for `.json` artefacts is correct as-is and should be preserved, not
  overridden.** Structured order/voyage JSON already merges sensibly under git's default strategy
  for the fields that matter; a blanket union rule risks corrupting those too.

Net: there was no file pattern for which `merge=union` would both have matched something real in
the plane and improved the outcome. The correct handling for the conflicts that do occur is human
review, not a merge strategy — which is what happens today.

## Pre-migration cleanup checklist

Because the migration takes a single, one-time copy of your `.mso/` state, **no artefact may be
stranded on a branch that hasn't been merged to your default branch when the copy is taken** —
otherwise that state is silently left behind. Before running `mso migrate artefact-repo`, make
sure:

- [ ] No dispatcher is currently running against this workspace (`mso cleanup` if unsure).
- [ ] No crew, voyage, salvage, or scratch worktree is still checked out
      (`git worktree list` from the product repo).
- [ ] Every voyage/crew/salvage branch that touched `.mso/` has been merged into your default
      branch. The migration will refuse and name the specific branch(es) if not.
- [ ] `git status` shows no uncommitted changes under `.mso/`.

If the migration refuses, it prints each blocker with the exact recovery command — run those,
then re-run `mso migrate artefact-repo --dry-run` to confirm the workspace is clean.

## Rollback

```bash
mso migrate artefact-repo --rollback --dest C:/Repos/MSO-Platform
```

Deletes the artefact repo at `--dest` and reverts your project registration to embedded mode.
Safe at any point — the original `.mso/` in your product repo was copied, never moved or
modified, so your product repo is immediately usable in embedded mode again. (If you had
already run `--clean-product`, restore `.mso/` from your last commit or from the pre-migration
backup zip before rolling back.)

## FAQ

**Do I need a remote for the artefact repo?**
No. In solo mode a remote is optional — recommended for backup, but Maestro dispatches and
reads state from your local checkout either way. If no `origin` is configured, lifecycle commits
still happen locally; there's simply nothing to push.

**What happens if the push fails (offline, no network)?**
Nothing blocks. A failed push is retried with backoff on a later lifecycle event or dispatcher
tick; your local commits are the durable record regardless of remote reachability.

**Does this change how I create orders or voyages?**
No — `mso order`, `mso voyage create`, `mso dispatch`, `mso status`, etc. all work exactly as
before. The only difference is which repository they read and write `.mso/` in.

**What about Maestro Hub?**
If you use the Hub dashboard, it resolves the artefact repo and product repo independently once
your project is registered in solo mode — no separate Hub configuration is needed.

**I'm on solo/shared mode from before this release — where are my worktrees now?**
Runtime worktrees (`.mso/worktrees/<voyage_id>/…`) are documented as living in the artefact
repo's checkout (see [What this is](#what-this-is) above), but before BUG-MSO-2026-0601 the code
did not consistently honour that for every caller — the dispatcher's own tick loop worked, but the
LEAD daemon's `worktree.prune` band, the Hub, and a multi-workspace CLI scan could each resolve the
worktree root from wherever the process's cwd happened to be, which in solo/shared mode is your
**product** repo, not the artefact repo. If you migrated to solo/shared mode before this fix, you
may have accumulated stray worktree directories under `<product repo>/.mso/worktrees/` that the
current code no longer looks at or writes to. They are inert (not referenced by anything) but not
automatically cleaned up by the fix itself — check with `git worktree list` from the product repo
and, for any that reference a completed voyage, remove them by hand
(`git worktree remove --force <path>`) or let a subsequent `mso cleanup` sweep them. Worktrees
created going forward land under the artefact repo's `.mso/worktrees/`, matching this doc, with no
migration step or config change required.

**Is this required?**
No. Embedded mode (today's default) remains fully supported indefinitely. Migrate only if the
product-repo bookkeeping noise or branch-visibility problem described in [Why](#why) actually
affects you.

**What about multiple product repos, or a shared team remote?**
Both build on solo mode and are available today:
- **Corporate / shared mode** (`artefacts.mode: "shared"`) — a shared remote artefact repo with
  multiple engineers and dispatchers working against it — see
  [Corporate shared mode](#corporate-shared-mode) above. **Team/Enterprise** tier.
- **Multi-repo workspaces** (one workspace, several product repos, one PR per repo per voyage) —
  see [MULTI-REPO.md](MULTI-REPO.md).

Both extend the same `artefacts` config block documented above without changing anything about
solo mode itself, and both can be combined (a multi-repo workspace can also run in `shared` mode).

## See also

- [MULTI-REPO.md](MULTI-REPO.md) — one workspace spanning multiple product repos
- [QUICKSTART.md](QUICKSTART.md) — first-run setup (embedded mode)
- [CLI-REFERENCE.md](CLI-REFERENCE.md) — full command reference
- [HUB.md](HUB.md) — Maestro Hub dashboard
