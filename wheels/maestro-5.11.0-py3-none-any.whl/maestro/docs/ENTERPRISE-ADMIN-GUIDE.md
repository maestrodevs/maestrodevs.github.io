# Enterprise Admin Guide — authoring org policy and enrolment

> **Audience:** the person authoring your organisation's governance policy and enrolment profile —
> not the engineer running `mso setup` on their own machine (see
> [ENTERPRISE-QUICKSTART.md](ENTERPRISE-QUICKSTART.md) for that side). If you're deciding which
> guide you need at all, start at [START-HERE.md](START-HERE.md).

Two artefacts, both Ed25519-signed, both distributed the same way (an admin authors + signs
locally, then hosts the file over HTTPS or lays it down via MDM/imaging):

1. **A policy bundle** — the rules a governed workspace evaluates at tool-call time
   (`governance.governedMode`). See [GOVERNANCE-TRUST-BOUNDARY.md](GOVERNANCE-TRUST-BOUNDARY.md)
   for what client-side governance actually enforces and its honest limits.
2. **An enrolment profile** — the org configuration a device picks up automatically on
   `mso setup`: workspace defaults, the governance gate itself, trusted keys, a pinned division
   pack, a secrets provider, and (optionally) identity seeding.

Everything in this guide is `mso policy` and `mso setup`/`mso init` CLI-and-artefact behaviour —
no engine internals.

---

## Contents

1. [Prerequisites and tier gates](#1-prerequisites-and-tier-gates)
2. [Part A — Policy bundle authoring](#part-a--policy-bundle-authoring)
3. [Part B — The enrolment profile](#part-b--the-enrolment-profile)
4. [Part C — Unattended / imaging runbook](#part-c--unattended--imaging-runbook)
5. [Key rotation and proving compliance](#5-key-rotation-and-proving-compliance)
6. [Security notes](#6-security-notes)

---

## 1. Prerequisites and tier gates

Every `mso policy` subcommand is gated individually — "Enterprise-gated" is too coarse a phrase
for a four-tier product, so here is the exact table:

| Command | Tier gate | Why |
|---|---|---|
| `mso policy keygen` \| `init` \| `lint` \| `sign` | **none** | You must be able to author and sign a trial bundle before buying anything. These touch only local files and your own key. |
| `mso policy trust add` \| `trust rotate` \| `enable` | Team / Enterprise | These arm governance on a device — governance itself is a Team/Enterprise capability. |
| `mso policy publish` | Team / Enterprise | Distribution is an org activity. |
| `mso policy pull` | Enterprise | Existing behaviour — see [the note below](#a-note-on-mso-policy-pull). |

You can run everything through **sign** at community tier to evaluate the whole authoring flow.
Arming it on a real device (`trust add`, `enable`) needs a Team or Enterprise licence on that
device.

---

## Part A — Policy bundle authoring

The end-to-end flow: **keygen → init → lint → sign → publish → pin → enable → prove**.

### A1. Generate your org's signing key

```bash
mso policy keygen --key-id acme-2026-q3 --out ~/keys/
```

```
✓ generated Ed25519 keypair 'acme-2026-q3'
  seed (KEEP SECRET, off-client only): /home/you/keys/acme-2026-q3.seed
  public key (pin this with `mso policy trust add`):
    Base64PublicKeyHere...
```

The seed file is written at file mode `0600` (best-effort on Windows). `--out` **refuses** to
write inside a git working tree or a `.mso/` workspace — anyone with repo or workspace access
(including a dispatched crew) can read either. Keep the seed off-client: a secrets vault, an HSM,
or at minimum a directory outside every repo and workspace you use with Maestro.

This is the same seed-custody pattern `mso licence keygen`/`issue` uses for licence signing and
`mso identity sign-acl` uses for the identity manifest — **three separate keyrings, one shared
pattern.** Policy-bundle trust (`governance/keys.py`), the licence keyring, and the identity
manifest key are deliberately isolated from one another. A policy signing key can never mint a
licence or forge an identity manifest, and vice versa.

### A2. Draft a bundle

```bash
mso policy init --bundle-id acme-standard-2026 \
  --from protected-branch,secret-handling \
  --mode enforce \
  --out acme-policy.json
```

`--from` seeds rules from one or more built-in packs (comma-separated). Omit it for an empty
draft you write by hand. `--mode` stamps `governedMode` on the draft (`enforce` / `warn` / `off`).

### A3. Validate before signing

```bash
mso policy lint acme-policy.json
```

```
✓ acme-policy.json is a valid draft: acme-standard-2026 v1, 4 rule(s)
```

Runs the same schema validator the runtime loader uses — a draft that lints clean is guaranteed
loadable. Edit `acme-policy.json` by hand to add/remove rules, then re-lint.

### A4. Sign it

```bash
mso policy sign acme-policy.json --key-id acme-2026-q3 --key-file ~/keys/acme-2026-q3.seed
```

Or supply the seed via the environment (useful for CI signing jobs):

```bash
export MAESTRO_POLICY_SIGNING_KEY="$(cat ~/keys/acme-2026-q3.seed)"
mso policy sign acme-policy.json --key-id acme-2026-q3
```

`sign` refuses to sign a structurally-invalid draft (it re-lints first) and refuses to sign
without a resolvable seed. Pass `--out` to write the signed copy elsewhere instead of overwriting
the draft in place. Verify what you just produced:

```bash
mso policy verify --bundle acme-policy.json
```

### A5. Publish

```bash
mso policy publish acme-policy.json --out /var/www/policy/policy-bundle.json
```

`publish` refuses an unsigned bundle outright — an unsigned bundle must never be distributed as if
trusted. With no `--out`, it just confirms the bundle is signed and ready; host it yourself over
HTTPS and set `governance.pullUrl` (or `MAESTRO_POLICY_PULL_URL`) on devices to its URL so they can
`mso policy pull` it.

### A6. Pin the public key on a device

```bash
mso policy trust add --key-id acme-2026-q3 --public-key <BASE64_PUBLIC_KEY> --status active
```

Writes into `$MAESTRO_HOME/trusted-keys.json` (the **home** keyring — one tier above
`workspace.json`'s own trust pin, one tier below the vendor-shipped baseline; resolution order is
env < workspace < home < vendor, and **vendor always wins a keyId collision**). This is the same
registry an enrolment profile's `trustedKeys` merges into (§Part B below) — one trust store serves
both artefact types.

### A7. Turn governance on

```bash
mso policy enable --mode enforce
```

Idempotently writes `governance.governedMode` into `workspace.json`. Modes: `enforce` (deny on
violation), `warn` (log, never deny), `off`.

### A note on `mso policy pull`

`pull` (fetch + verify + install a published bundle onto a device) is gated to `{"enterprise"}`
alone today, not `{"team", "enterprise"}` like the rest of the governance surface. This is a
known, tracked inconsistency (not a documentation error) — if your Team-tier devices need
`mso policy pull` and it refuses citing your tier, that is the current, as-shipped gate; there is
no workaround short of an Enterprise licence or fetching the bundle by another channel and placing
it at the workspace's policy-bundle path yourself.

---

## Part B — The enrolment profile

The enrolment profile is the artefact that carries your org's configuration onto a device
automatically — an admin authors and signs it once; every device's plain `mso setup` finds and
applies it, prompting only for what it leaves open.

### B1. Field reference

```jsonc
{
  "schemaVersion": "1.0",
  "bundleId": "acme-standard-2026",
  "version": 3,
  "org": "ACME Corp",
  "minimumTier": "team",

  "workspace":  { "project": "ACME", "defaultGitHubOrg": "acme-eng" },

  "pack":       { "id": "sdlc", "locked": true },

  "governance": { "governedMode": "enforce",
                  "pullUrl": "https://policy.acme.example/policy-bundle.json" },

  "trustedKeys": {
    "acme-2026-q3": { "algorithm": "ed25519", "publicKey": "<base64>", "status": "active" }
  },

  "audit":      { "anchorProvider": "s3", "anchorConfig": "/etc/acme/anchor.json",
                  "maxAnchorAgeMinutes": 60 },

  "identity":   { "seed": true, "encryption": "sops" },

  "secrets":    { "type": "azure_keyvault", "config": { "vault": "acme-maestro" } },

  "mcp":        {},
  "hooks":      {},
  "prompts":    {},

  "signature":  { "algorithm": "ed25519", "keyId": "acme-2026-q3", "value": "<base64>" }
}
```

| Field | Applied by `mso setup`? | Notes |
|---|---|---|
| `bundleId` / `version` / `schemaVersion` | — | Identity fields. **Note:** the field is `bundleId`, not `profileId` — see [why](#why-bundleid-not-profileid) below. |
| `org` | display only | Printed during resolution; not written anywhere. |
| `minimumTier` | refusal gate | Below §B3. |
| `workspace` | ✅ yes | Merged into `workspace.json` top-level (e.g. `project`, `defaultGitHubOrg`) — the same keys `mso init` itself scaffolds. |
| `governance.governedMode` / `governance.pullUrl` | ✅ yes | Written into `workspace.json`'s `governance` block. |
| `trustedKeys` | ✅ yes | Merged into `workspace.json`'s `governance.trustedKeys` (the workspace-tier pin). Refused outright if any `keyId` collides with a **vendor**-pinned key — a vendor id can never be shadowed. |
| `audit` | not applied by the profile path | Enterprise audit-anchor configuration is set via `mso init --enterprise` (interactive or `--non-interactive`, §Part C) — not read from the profile today. Present in the schema for forward compatibility. |
| `identity.seed` | ✅ yes, separately | Triggers identity seeding (`mso identity`'s own default groups/ACL/signing-key shape) — idempotent, safe to re-run every `mso setup`. `identity.encryption` (e.g. `sops`) is attempted best-effort and never aborts the wizard if the tool is missing. |
| `secrets` | ✅ yes | Written to `workspace.json`'s `secretsProvider`. `type` must be one of `env`, `os_keyring`, `azure_keyvault`, `aws_secrets`, `vault`, `one_password` — an unrecognised type (e.g. a typo) **refuses** rather than silently falling back to `env`. Immediately followed by `mso secrets doctor` as an onboarding acceptance check. |
| `pack.id` / `pack.locked` | ✅ yes, by the setup pack step | `locked: true` auto-applies the pinned pack with no prompt; `locked: false` only pre-selects it as the wizard's default. A pin naming a pack outside the device's tier falls back to `sdlc` with a warning, rather than crashing or silently applying a pack the tier can't reach. |
| `mcp` / `hooks` / `prompts` | **not yet applied** | Parsed and structurally accepted (so a profile carrying them is not rejected), but no current code path reads them. Reserved for a future order. |

#### Why `bundleId`, not `profileId`

The plan's original sketch called this field `profileId`. The shipped schema uses `bundleId`
instead so an enrolment profile is byte-for-byte the same signed envelope shape as a policy bundle
— which is what lets profile verification delegate completely, unmodified, to the same
`verify_signed_bundle` routine that verifies policy bundles. One consequence worth knowing: the
anti-rollback version floor is keyed by `bundleId`/`version` and is **shared** between policy
bundles and enrolment profiles. Naming a profile identically to a policy bundle you also maintain
is a hygiene footgun (worst case: an over-conservative rollback rejection), not a security issue —
but it's worth a naming convention, e.g. suffix profiles distinctly (`acme-enrolment-2026` vs
`acme-policy-2026`).

### B2. Resolution precedence

`mso setup` looks for a profile in this order — first candidate found wins outright (a broken
profile at a higher-precedence location is a hard failure, never silently skipped in favour of a
lower one):

1. `mso setup --profile <PATH|URL>` (explicit)
2. `MAESTRO_ENROLMENT_PROFILE` env var (path or URL)
3. `~/.maestro/enrolment.json` (laid down by MDM/imaging, out-of-workspace)
4. `.mso/config/enrolment.json` (committed by the team into the workspace)
5. none found → today's no-profile behaviour, unchanged

**Community never looks.** This precedence chain is not even consulted at community tier — no env
read, no filesystem stat. At pro, a profile is detected and reported but not applied (pro is
single-seat; the profile-application steps are team/enterprise only). At team/enterprise, a
resolved profile is verified and applied; an enterprise device with none resolved prints a warning
pointing at [ENTERPRISE-SETUP.md](ENTERPRISE-SETUP.md), rather than proceeding silently ungoverned.

A URL-sourced profile that becomes unreachable falls back to the last successfully-verified copy
cached locally, if that copy is still within its freshness window — mirroring the offline-grace
behaviour of `mso policy pull`. A local file candidate that exists but fails to read is a hard
error; the cache never masks a broken on-disk profile.

### B3. Refusal rules — applies nothing, not "applies what it can"

Every one of these refuses the **entire** profile before any write — `workspace.json` is left
byte-for-byte unchanged on any refusal:

- **`minimumTier`** — a profile requiring `team` applied on a `community` device is refused with a
  message naming both the required and the actual tier ("activate a licence for the required tier,
  or run `mso setup` without this profile").
- **Unsigned + security-sensitive.** An **unsigned** profile is a convenience only, never a
  security assertion. It may set `workspace`, `pack`, `secrets`, `mcp`, `hooks`, `prompts` — but if
  it sets any of `governance.governedMode`, `trustedKeys`, `audit`, or `identity`, it is refused
  outright, naming every offending key at once. Sign the profile (§B4) or drop those keys.
- **Vendor keyId collision.** A `trustedKeys` entry whose `keyId` matches a vendor-pinned key is
  refused — a vendor id can never be shadowed by an org profile, so a collision is treated as an
  attempted shadow rather than silently losing to the vendor entry.
- **Malformed `trustedKeys` shape.** A bad algorithm, a key that isn't exactly 32 bytes, or an
  invalid `status` value is caught at apply time (same shape-check governance uses when it loads
  keys), rather than surfacing later when a signature fails to resolve.

### B4. Signing a profile

There is currently **no dedicated `mso enrolment sign` command.** Because the profile deliberately
reuses the policy-bundle envelope (§B1), the existing `mso policy sign` works on a profile file
unmodified — its own lint step (`PolicyBundle` schema validation) only requires `bundleId` and
accepts everything else with defaults, so an enrolment-profile-shaped JSON lints and signs
successfully even though it isn't a policy bundle for evaluation purposes:

```bash
mso policy sign acme-enrolment.json --key-id acme-2026-q3 --key-file ~/keys/acme-2026-q3.seed
```

You'll see `mso policy lint` report `0 rule(s)` for a profile — that's expected; the tool is being
reused for its signing machinery, not for policy evaluation. This is a real, working path today,
not a documented-but-unbuilt aspiration — but it is admittedly a repurposed tool rather than a
purpose-built one. If your org authors many profiles, consider wrapping this in your own script
rather than relying on the coincidence surviving indefinitely.

### B5. Bootstrapping — the profile's key must already be trusted

A signed profile's own signing key must be pinned **outside** the profile itself before `mso
setup` will honour it — the profile being verified has not been merged into `workspace.json` yet,
so it cannot supply the very key that authenticates it. Pin it the same way as a policy-bundle
key, once per machine (or once per fleet, via MDM):

```bash
mso policy trust add --key-id acme-2026-q3 --public-key <BASE64_PUBLIC_KEY>
```

The vendor-shipped keyring and the home keyring you write to here are both consulted; whichever
already has the profile's `keyId` pinned satisfies bootstrapping.

### B6. Placing the profile

| Placement | Mechanism |
|---|---|
| Per-machine, MDM/imaging | Write `~/.maestro/enrolment.json` as part of your image or provisioning script |
| Per-machine, ad hoc | `mso setup --profile /path/to/profile.json` or `mso setup --profile https://…/profile.json` |
| Per-workspace, team-committed | Commit `.mso/config/enrolment.json` into the workspace (visible to anyone who clones it — do not put secrets in it; it's just config plus a signature) |
| Fleet-wide via env | Set `MAESTRO_ENROLMENT_PROFILE` to a path or URL in the provisioning environment |

---

## Part C — Unattended / imaging runbook

For an IT department imaging many machines: lay down credentials once per image, run two
commands, verify with a third.

```bash
# Laid down by MDM or the image, once — TIER-DEPENDENT:
#   ~/.maestro/trusted-keys.json      (public key pin — mso policy trust add)   [team/enterprise]
#   ~/.maestro/enrolment.json         (the signed profile, §B6)                 [team/enterprise]
#   MAESTRO_LICENCE_KEY                (env or vault)                          [pro/team/enterprise]
#                                                                              [community: lay down NOTHING]

pip install maestro-fleet
mso init --project ACME --non-interactive             # zero prompts; see below for enterprise mode
mso setup --non-interactive                            # zero prompts; exits non-zero on any unmet requirement
mso setup --check --json                               # machine-readable verification for the imaging pipeline
```

A **community** image lays down nothing extra and runs the same commands — `--non-interactive`
must succeed with no licence, no profile, and no licence-shaped output, and that is a tested
acceptance criterion, not a hope.

### `--non-interactive` semantics

`mso setup --non-interactive` never calls `input()`. Every wizard-step answer either comes from a
`--answers FILE` flat `KEY=VALUE` file (`workspace.project=ACME`, `workspace.defaultGitHubOrg=acme-eng`,
`pack.id=sdlc`, …) or falls back to that step's default silently — an unsupplied `--answers` key is
not an error, it just keeps the current value. The **enrolment profile's own refusal checks** are
the ones that hard-fail naming a specific key: `minimumTier` names both the required and the
actual tier; an unsigned profile setting a security-sensitive key names every offending key at
once; an unrecognised `secrets.type` names the bad value. Any of those exits non-zero with the
refusal message — never a hang waiting on stdin, but also never a silent partial apply.

```bash
mso setup --non-interactive --profile ~/.maestro/enrolment.json
mso setup --non-interactive --answers /etc/acme/setup-answers.txt
```

### `mso init --enterprise --non-interactive` — never defaults to the insecure anchor

The interactive enterprise bootstrap defaults to the filesystem audit anchor on a bare Enter — its
own warning text calls that anchor "NOT tamper-proof in production". Under `--non-interactive`,
silently picking that default would be the single worst behaviour in the onboarding path, so it
refuses instead:

```bash
mso init --project ACME --enterprise --non-interactive
# refuses: MAESTRO_ANCHOR_PROVIDER must be one of ['azure', 'fs', 's3', 's3-compat']
#          (got <unset>). Refusing to default to the filesystem anchor under automation.
```

Supply the provider explicitly (and its config path, for any provider other than `fs`):

```bash
export MAESTRO_ANCHOR_PROVIDER=s3
export MAESTRO_ANCHOR_CONFIG_PATH=/etc/acme/anchor-s3.json
export MAESTRO_ANCHOR_MAX_AGE_MINUTES=60   # optional; default 60
mso init --project ACME --enterprise --non-interactive
```

`fs` is the only provider that doesn't require `MAESTRO_ANCHOR_CONFIG_PATH` — and it's the one the
tool itself warns you not to run in production, so an unattended enterprise image should almost
always be setting one of `s3` / `azure` / `s3-compat` explicitly.

### CI verification of the imaged result

```bash
mso setup --check --json | jq .
```

Exit code `0` = all prerequisites OK, `1` = a FAIL present, `2` = only WARNs. Parse the JSON body
for per-check detail in your imaging pipeline's own reporting.

---

## 5. Key rotation and proving compliance

### Rotate a policy-signing key

```bash
mso policy trust rotate --retire acme-2026-q2 --activate acme-2026-q3 --public-key <BASE64>
```

Retires one home-pinned key and activates another in a single write. There is no built-in
"don't lock yourself out" guard — confirm the newly-activated key can actually verify your current
bundle before retiring the last key able to.

### Prove compliance

```bash
mso policy report                    # writes a SOC2/ISO evidence Markdown document
mso policy report --json             # same evidence, raw JSON to stdout
mso audit verify                     # verify the hash chain
mso audit anchor --auto              # anchor current root hash to external immutable storage
```

`mso policy show` gives a quick point-in-time view: installed bundle, pinned trusted keys, and
anti-rollback version floors.

---

## 6. Security notes

- **Seeds never touch a workspace or a repo.** `mso policy keygen --out` refuses to write inside a
  `.mso/` workspace or a git working tree. Supply seeds at signing time only, via `--key-file` or
  `MAESTRO_POLICY_SIGNING_KEY` — never persist one in a config file.
- **Three isolated trust roots, one shared pattern.** Policy-bundle trust
  (`governance/keys.py`), the licence keyring, and the identity-manifest signing key are separate
  registries by design. A key compromised in one cannot forge an artefact in another.
- **Vendor always wins a `keyId` collision** — in the trusted-key registry (env < workspace < home
  < vendor) and in an enrolment profile's `trustedKeys` (refused outright on collision, not
  silently shadowed).
- **`MAESTRO_GOVERNANCE_TRUSTED_KEYS` is test-mode-only** (gated on `MAESTRO_SKIP_AUTH` or running
  under pytest) — it is not a channel available in production to inject trust.
- **File permissions.** Seed files and the home trusted-key registry are written at mode `0600`
  (best-effort on Windows — rely on OS-level ACLs there, not the POSIX mode bit).
- **The trust boundary is honest, not absolute.** Nothing here claims to prevent a compromised or
  malicious device from reading its own source, spending its own token budget, or disabling its
  own hooks — see [GOVERNANCE-TRUST-BOUNDARY.md](GOVERNANCE-TRUST-BOUNDARY.md) for what
  client-side governance does and does not defend against. An enrolment profile **distributes**
  org configuration; tampering with the applied result is made *evident* (signature, audit), not
  *prevented*.

## See also

- [START-HERE.md](START-HERE.md) — tier-aware routing
- [ENTERPRISE-QUICKSTART.md](ENTERPRISE-QUICKSTART.md) — the engineer's side of onboarding
- [ENTERPRISE-SETUP.md](ENTERPRISE-SETUP.md) — network, deployment, break-glass, compliance
- [GOVERNANCE-TRUST-BOUNDARY.md](GOVERNANCE-TRUST-BOUNDARY.md) — what governance does and does not enforce
- [DIVISION-PACKS.md](DIVISION-PACKS.md) — `mso packs apply`, custom pack authoring, tier gates
