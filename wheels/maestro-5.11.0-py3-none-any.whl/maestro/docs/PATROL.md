# Fleet Patrol (`mso doctor`)

The patrol is a set of deterministic, read-only fleet-health checks you run
with `mso doctor`. Unlike `mso status`, it never talks to a running dispatcher
process — every check reads on-disk state directly, so it works identically
whether the fleet is running, wedged, or was never started.

## Quick start

```bash
mso doctor                  # human-readable report — only what changed since last run
mso doctor --all            # every current finding, including unchanged ones
mso doctor --json           # machine-readable output (findings, delta, skipped)
mso doctor --explain        # also show which config tier supplied each check
mso doctor --all-projects   # every registered project, plus one machine-scope section
```

A clean run with nothing new to report prints nothing beyond a definition
warning (if any) — the patrol is silent on no-change and loud on the thing
that matters. Findings at `high` severity or above make `mso doctor` exit
non-zero, so it's suitable for a CI or cron gate.

## What it checks

The shipped default covers six families:

| Family | What it watches for |
|--------|---------------------|
| **Dispatcher** | The dispatcher process is alive and its heartbeat is fresh |
| **Crews** | Whether every crew slot has crashed while work is still pending |
| **Orders** | Dependency-satisfied orders stuck unreleased; orders waiting too long for human review |
| **Voyages** | Stalled PR/CI state; a merged voyage not yet archived; a planned voyage with no work filed |
| **Hygiene** | Unpushed artefacts sitting in a worktree; a fleet running on a stale package install |
| **Machine** | Orphaned processes; package-integrity problems on the local machine |

Each finding carries a severity (`low` / `medium` / `high` / `critical`), a
plain-language explanation, and — where one exists — a **suggested** command
to resolve it. The patrol never runs that command itself; it only proposes
it. What (if anything) acts on a suggestion is a separate, explicitly
configured decision — see [Findings vs. action](#findings-vs-action) below.

## Configuring which checks run

An organisation can add, remove, re-tune severity, or reorder checks without
touching code. Configuration resolves through four tiers, each able to
override the ones below it:

1. A signed governance bundle (enterprise)
2. A division/team pack
3. This workspace's own `.mso/config/workspace.json`
4. The shipped default (always present as the floor)

A governed check may be tightened locally but never loosened silently — an
operator who wants to relax a governed check needs an explicit breakglass
grant, not just a local edit. If a definition fails to resolve at any tier,
`mso doctor` fails safe: it falls back to the full shipped default and prints
a loud banner rather than silently running with fewer checks than intended.

## Findings vs. action

The patrol itself only ever *detects and reports* — a check is a pure
function with no ability to change anything. What happens next is entirely
separate and is scoped by the same rules that govern the LEAD role generally:
some low-risk, reversible housekeeping may be acted on automatically and
reported afterward, but nothing the LEAD role is otherwise prohibited from
doing (merging, approving its own work, resolving security findings, and so
on) becomes permitted just because a patrol check surfaced it. See your
workspace's role documentation for the exact boundary — it is deliberately
not duplicated here.

## Using it from Claude Code

The `/fleet-patrol` skill runs `mso doctor --json` and presents an
interpreted report — open findings by severity, what's new or resolved since
the last run, and any skipped checks — without re-deriving fleet state by
reading files directly.

## Multi-project use

`mso doctor --all-projects` scans every project registered in your local
registry in one pass, plus a single machine-scope section (orphaned
processes, package integrity) that only needs to run once regardless of how
many fleets you operate.
