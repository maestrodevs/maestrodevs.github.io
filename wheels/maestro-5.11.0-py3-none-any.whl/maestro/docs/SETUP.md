# Maestro — `mso setup` deeper wizard

> The heavier configurator behind `mso quickstart`. Run `mso quickstart` for the friendly first-run; run `mso setup` when you want deeper control — prerequisite validation across 8 checks, fingerprint-based project analysis, 8 built-in requirement templates, contextual next-steps cheatsheet, and a non-interactive `--check` (or full `--non-interactive`) mode for CI and unattended imaging.
>
> **`mso setup` is tier-aware.** It resolves your licence tier once, at the start, and reads it —
> it never sets one. See [START-HERE.md](START-HERE.md) if you're not sure which tier you're on,
> or [§ Tier-aware step registry](#tier-aware-step-registry) below for exactly what changes per
> tier.

## When to use `mso quickstart` vs `mso setup`

| | `mso quickstart` | `mso setup` |
|---|---|---|
| **Audience** | First-time operator on a new machine | Anyone with an existing workspace |
| **Mode** | Demo voyage + dispatch | Audit + configure + analyse |
| **Touches** | Creates demo voyage + orders | Reads/repairs `.mso/config/workspace.json` |
| **CI-friendly** | No | Yes — `mso setup --check` exits 0/1/2/3 |

If you ran `mso quickstart` once already, run `mso setup` next.

## Seven modes

| Command | Purpose |
|---------|---------|
| `mso setup` | Interactive wizard — step-through prompts; configures `.mso/config/workspace.json` |
| `mso setup --check` | Non-interactive audit — exit 0/1/2/3, no prompts |
| `mso setup --check --json` | Machine-readable JSON output for CI parsing |
| `mso setup --repair` | Auto-fix repairable conditions (workspace.json regen, git init, etc.) |
| `mso setup --show <section>` | Read-only view of one section (`prereqs`, `project`, `workspace`, `templates`, `persona`) |
| `mso setup --non-interactive [--profile P] [--answers FILE]` | Zero prompts — every answer comes from an enrolment profile, an answers file, or a silent default. Fails naming the missing key rather than hanging on stdin. See [ENTERPRISE-ADMIN-GUIDE.md § unattended runbook](ENTERPRISE-ADMIN-GUIDE.md#part-c--unattended--imaging-runbook). |
| `mso setup --profile <PATH_OR_URL>` | Force resolution of a specific enrolment profile, overriding the normal precedence chain (highest precedence — team/enterprise/pro only; ignored at community). |

## 8 prerequisite validators

| # | Validator | What it checks | OK → | WARN → | FAIL → |
|---|-----------|---------------|------|--------|--------|
| 1 | `check_python_version` | `sys.version_info >= (3, 9)` | Python 3.9+ | — | < 3.9 |
| 2 | `check_claude_cli` | `claude --version` responds | found + responsive | found but slow | not found / errored |
| 3 | `check_git` | `git --version` + cwd is a repo | installed + repo | installed, no repo | not installed |
| 4 | `check_gh_cli` | `gh auth status` ok | authenticated | not authenticated | not installed |
| 5 | `check_anthropic_auth` | `ANTHROPIC_API_KEY` env OR `claude` responsive | set / subscription | placeholder-looking | neither |
| 6 | `check_workspace_scaffold` | `.mso/` + valid `workspace.json` | scaffolded + valid | exists but malformed | not scaffolded |
| 7 | `check_repo_config` | `workspace.json` / `projects.json` don't look like unfilled placeholders | looks real (or no workspace yet) | placeholder values left in | — (never fails; worst case is a WARN) |
| 8 | `check_unsigned_acl_manifest` | In a **governed, enforce-mode** workspace with identity records already present, is the manifest a signed envelope? | not governed, or no identity records yet, or manifest is signed | — (never warns) | governed + records exist + manifest missing/unsigned |

All validators have a 10-second timeout to avoid hanging the wizard on broken tools. Validator 8
is a structural shape check only (it does not perform cryptographic verification) and — by
construction — can never fire at community or pro, or in an ungoverned team workspace: it needs
`governedMode == "enforce"` to even run.

### Repairable conditions

`mso setup --repair` will automatically fix:
- `.mso/config/workspace.json` missing or invalid → regenerate from defaults
- `.mso/` directory partially scaffolded → fill in missing dirs

Non-repairable (`--repair` prints remediation only):
- Python < 3.9 — requires system intervention
- Claude Code / Git / `gh` not installed — requires installer
- `ANTHROPIC_API_KEY` env var unset — must be set in parent shell

## Tier-aware step registry

`mso setup` resolves your licence tier exactly once, at entry — read-only; nothing in the wizard
sets, caches, or infers a tier (that's `mso licence activate`'s job alone). Every step is an entry
in an ordered registry with a tier predicate; a step whose predicate excludes your tier simply
never runs, with no partial output and no runtime branch to notice:

| Header | Step | Runs at | What it does |
|---|---|---|---|
| `[STEP 0]` | Persona | every tier | Workstation persona selection. |
| `[STEP 1]` | Prerequisite checks | every tier | The 8 validators above. |
| `[LICENCE]` | Licence | pro / team / enterprise | Shows resolved tier, expiry, and any warning. **Never appears at community** — not shown, not mentioned as absent. |
| `[STEP 2]` | Project analysis | every tier | Language/framework/source-root/test-layout/CI fingerprinting (below). |
| `[STEP 3]` | Workspace configuration | every tier | Can now *write* `workspace.json` (project acronym, default GitHub org) — it used to only offer "go edit it yourself". |
| `[STEP 3a]` | Division pack selection | every tier, **including community** | Selectable packs are the free ones (`sdlc`) plus, at team/enterprise, the five Team-gated packs too — **pro sees the same selectable list as community** (`sdlc` only), since pack gating checks the Team/Enterprise tier set, not "any paid tier". Withheld packs are always *named* ("Also available on Team/Enterprise"), never just dropped. Defaults to `sdlc`, which is byte-identical to a plain `mso init` — a no-op at the default answer for every tier. See [DIVISION-PACKS.md](DIVISION-PACKS.md). |
| `[PROFILE]` | Enrolment profile lookup | pro / team / enterprise | Detects (and, at pro, only detects) an enrolment profile. **Community performs no filesystem or env probe at all** — the precedence chain isn't even consulted. |
| `[ENTERPRISE]` | Enterprise security onboarding | team / enterprise | Only runs anything if a profile actually resolved in the step above — applies workspace/governance/trusted-key settings, configures secrets (+ `mso secrets doctor`), seeds identity if requested. An absent profile means **zero** `governance.*` keys are ever written — never a half-configured state. |
| `[STEP 4]` | Requirement templates | every tier | Offer to generate a starter order from a template. |
| `[STEP 5]` | Next steps | every tier | Contextual cheatsheet (below). |

**The community guarantee is tested, not conventional:** a community run of `mso setup` (or `mso
setup --non-interactive`) produces **zero** occurrences of the words "licence", "license",
"profile", "enrolment", "trial", or "upgrade" anywhere in its output, and performs no enrolment
lookup of any kind. Full per-tier detail: [START-HERE.md](START-HERE.md#what-actually-changes-per-tier).

Detailed field reference for what an enrolment profile actually contains and how it's authored:
[ENTERPRISE-ADMIN-GUIDE.md § Part B](ENTERPRISE-ADMIN-GUIDE.md#part-b--the-enrolment-profile).

## Project analysis matrix

`mso setup` runs `maestro/project_analysis.py:analyze()` against the current directory. **Fingerprint-only — no recursive scan** — completes in <100ms even on large repos.

| Detector | Signals |
|----------|---------|
| **Language** | `pyproject.toml`/`setup.py`/`requirements.txt` → Python; `tsconfig.json`/`package.json`+TS → TypeScript; `go.mod` → Go; `Cargo.toml` → Rust; `*.csproj`/`*.sln` → C#; `pom.xml`/`build.gradle` → Java |
| **Framework** | `next.config.*` → Next.js; `manage.py` → Django; `fastapi` in deps → FastAPI; `flask` in deps → Flask; `Microsoft.AspNetCore` in `*.csproj` → ASP.NET |
| **Source root** | `src/` > `lib/` > `app/` > `packages/` > `.` (flat) |
| **Test layout** | `tests/`, `test/`, `__tests__/`, `*.test.*`, `*_test.go`, `spec/` |
| **Docs** | `README.md`, `docs/`, `mkdocs.yml`, `docusaurus.config.js`, `_docs/` |
| **Git history** | recent commit timestamp, branch count, CI presence (`.github/workflows/`, `.gitlab-ci.yml`, `Jenkinsfile`, `.circleci/`) |

Result is a `ProjectAnalysis` dataclass with `primary_language`, `secondary_languages`, `framework`, `source_root`, `test_layouts`, `has_readme`, `has_docs_dir`, `has_ci`, `ci_systems`, `recent_activity`, `branch_model`.

## 8 built-in requirement templates

Each template is a Jinja2 markdown file at `maestro/templates/requirements/*.md.j2`. Rendered output is a starter order JSON that operators can dispatch.

| Template | Purpose | Key sections |
|----------|---------|--------------|
| `new-feature` | Propose a new feature | Goal, User story, Acceptance criteria, Out of scope |
| `project-setup` | Initial project configuration | Stack, CI target, Branching strategy, Deployment target |
| `security-review` | Security audit | Threat model, OWASP concerns, Sensitive files, Auth mechanisms |
| `test-coverage` | Test gap analysis | Current coverage, Target %, Untested paths, Test strategy |
| `doc-audit` | Documentation review | Existing docs, Gaps, Target audience, Format |
| `bug-report` | Bug reproduction + fix | Steps to reproduce, Expected vs actual, Environment, Logs |
| `performance` | Performance investigation | Observed latency, Profiling baseline, Hotspot hypothesis, Target |
| `refactor` | Refactoring scope | Current pain points, Target structure, Risk surface, Rollback plan |

Variables injected at render time: `{{ project }}`, `{{ language }}`, `{{ framework }}`, `{{ source_root }}`, `{{ date }}`.

### Custom templates

Drop `.md.j2` files in `.mso/templates/requirements/` to extend the catalogue. Custom templates override built-ins with the same filename. List all available with:

```bash
mso setup --show templates
```

## Contextual cheatsheet (`mso setup` step 5)

After analysis + workspace config, `mso setup` runs `maestro/setup_cheatsheet.py:generate_cheatsheet()` and prints contextual next-steps. Rules include:

- No test layout → suggest `test-coverage` template
- No README + no docs/ → suggest `doc-audit` template
- No CI workflow → suggest scaffolding `.github/workflows/`
- Dormant repo (>180 days quiet) → suggest `project-setup` template
- `gh` not authenticated → walk through `gh auth login`
- Missing `ANTHROPIC_API_KEY` → environment-variable instructions
- Next.js detected → suggest `performance` template if you have measured slowness
- FastAPI detected → suggest `security-review` template early
- Django detected → confirm `manage.py check` + `migrate` in CI

10+ rules total. Heuristic, not exhaustive — treat suggestions as starting points.

## `--check` mode for CI/CD

Designed to be pipeline-friendly:

```bash
mso setup --check || exit 1
```

### Exit codes

| Code | Meaning |
|------|---------|
| 0 | All prereqs OK |
| 1 | Any FAIL |
| 2 | Only WARNs |
| 3 | Internal error (reserved) |

### JSON output

```bash
mso setup --check --json
```

Returns a stable JSON schema:

```json
{
  "prereqs": [
    {"name": "python_version", "status": "OK", "message": "Python 3.11 OK", "remediation": ""},
    {"name": "gh_cli", "status": "WARN", "message": "`gh` installed but not authenticated", "remediation": "Run `gh auth login`."}
  ],
  "exit_code": 2
}
```

### Sample GitHub Actions step

```yaml
- name: Validate Maestro setup
  run: |
    pip install maestro-fleet
    mso setup --check
```

## Operator workflow — typical day

```bash
# Day-1 onboarding to an existing repo
cd <repo>
mso setup                            # interactive wizard — see the tier-aware step registry above

# After config drifts (e.g. workspace.json hand-edited)
mso setup --check                    # quick audit
mso setup --repair                   # auto-fix anything fixable

# Generating starter orders from templates
mso setup                            # prompts you through template selection in step 4

# CI integration
mso setup --check --json | jq .      # parse status programmatically
```

## Migration note — FTR-ADM-2026-0009

The original `FTR-ADM-2026-0009` roadmap order (Apr 2026) called for both `mso quickstart` AND `mso setup`. **`mso quickstart` shipped in VOY-ADM-2026-0028** (delivered the friendly first-run slice). **VOY-ADM-2026-0035 (this voyage) delivers the deeper `mso setup` wizard** — the remaining scope of FTR-0009. Treat VOY-0035 as the authoritative delivery of FTR-0009.
