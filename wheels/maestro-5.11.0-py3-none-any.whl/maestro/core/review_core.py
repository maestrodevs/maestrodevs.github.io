# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""maestro/core/review_core.py — shared human-review-queue mutation logic.

Collapses the CLI (`mso review ...`, maestro/review.py) and Hub
(`maestro/hub/review.py`, POST /api/v1/review/...) surfaces onto one
implementation (BUG-MSO-2026-0486 / BUG-MSO-2026-0426: one implementation per
decision). The Hub's private reimplementation had drifted from the CLI on
five points:

  D1 capability gate  — Hub never checked ``voyage.approve``; any Team/
                         Enterprise Hub session could approve/revise/reject
                         regardless of ``.mso/identity/access.json`` (the
                         Hub's ``_require_control_tier()`` only checks
                         licence tier, a different axis entirely).
  D2 revise semantics — Hub set status=REVISION_REQUESTED and left the order
                         sitting in queues/review/ instead of re-queuing it
                         to the gated role. The dispatcher never saw it
                         again, and because status != NAV_REVIEW_PENDING
                         every later review action 409'd — the order was
                         stranded for good.
  D3 reject vocabulary — Hub used status=REJECTED / rejectionReason and
                         archived to queues/review/rejected/. The CLI (and
                         everything that scans orders/failed/ — mso status,
                         dashboards) uses FAILED / failureReason in
                         orders/failed/; a Hub-rejected order was invisible
                         to all of that.
  D4 ledger event     — Hub's approve never wrote the ADVANCED ledger event
                         (BUG-MSO-2026-0315). Without it the BUG-0248
                         advance-loss guard can rewind targetRole back to the
                         completed role and loop the approved crew forever.
  D5 gate derivation  — Hub read the raw ``reviewGate`` field (empty unless
                         explicitly set) and never fell back to the gated
                         role's handoff artefact (FTR-MSO-2026-0427); a
                         non-planning gate (e.g. BLD->REL) showed reviewers
                         the wrong document (or none).

Callers pass the already-resolved ``.mso`` artefact dir (``mso``), matching
the Hub's existing convention. ``maestro/review.py`` resolves it via
``artefact_root_for()``, ``maestro/hub/review.py`` via
``resolve_artefact_dir()`` — both already correct for solo/shared
artefact-repo mode (see their own docstrings); this module has no opinion on
that resolution.

Exception contract (deliberately typed, never printed — callers decide how
to surface a failure):
  FileNotFoundError  → order not in the review queue
  ValueError          → order isn't NAV_REVIEW_PENDING, or required
                         notes/feedback missing
  PermissionError      → capability denied (see ``_enforce_capability``)
"""

from __future__ import annotations

import json
import os
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional

from maestro.core.lifecycle_log import sanitize_lifecycle_message  # BUG-MSO-2026-0474: one-line-per-event guard
from maestro.core.plan_dependents import find_filed_dependents, promote_proposed_dependents
from maestro.core.proc import run_hidden  # FTR-MSO-2026-0408: no console flash under the detached dispatcher


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _review_dir(mso: Path) -> Path:
    return mso / "queues" / "review"


def _orders_dir(mso: Path) -> Path:
    return mso / "queues" / "orders"


def _write_atomic(path: Path, data: dict) -> None:
    """Write JSON to a temp file then rename — avoids partial writes."""
    content = json.dumps(data, indent=2)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(content, encoding="utf-8")
    tmp.replace(path)


def _write_lifecycle(mso: Path, event_type: str, message: str) -> None:
    """BUG-MSO-2026-0474: *message* is sanitized to a single physical line —
    operator-supplied free text (revise/reject notes) used to be written
    verbatim, breaking lifecycle.log's one-line-per-event contract."""
    log_dir = mso / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / "lifecycle.log"
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"{timestamp} | {event_type:<10} | {sanitize_lifecycle_message(message)}\n"
    try:
        with open(str(log_file), "a", encoding="utf-8") as f:
            f.write(line)
    except OSError:
        pass


def reviewer_identity() -> str:
    """Best-effort reviewer identity (git user or env fallback)."""
    try:
        result = run_hidden(
            ["git", "config", "user.email"],
            capture_output=True, text=True, timeout=5,
        )
        email = result.stdout.strip()
        if email:
            return email
    except Exception:
        pass
    return os.environ.get("USER", os.environ.get("USERNAME", "unknown"))


def _enforce_capability(mso: Path) -> None:
    """D1: gate every review mutation behind the ``voyage.approve`` capability.

    ``require_capability()`` is CLI-shaped: on denial it prints a formatted
    refusal to stderr and raises ``SystemExit(1)`` (its own docstring claims
    it raises ``CapabilityDenied``, but nothing in ``identity/gate.py``
    actually does that — a pre-existing gap, also present in
    ``order_retry.py``'s Hub wrapper, that is out of scope here). Translate
    the denial into ``PermissionError`` so this module's exception contract
    stays clean for both callers: the CLI lets it propagate to a normal
    process exit (the refusal text is already on stderr), the Hub catches it
    and returns 403.
    """
    from maestro.identity.gate import require_capability
    try:
        require_capability("voyage.approve", workspace=mso.parent)
    except SystemExit as exc:
        raise PermissionError("permission denied: voyage.approve required") from exc


def load_review_order(mso: Path, order_id: str) -> tuple[Path, Dict[str, Any]]:
    """Load order from queues/review/; raise FileNotFoundError if absent.

    Public — shared by ``mso review show`` (CLI) and the mutation functions
    below, so a missing order raises the same typed exception everywhere.
    """
    order_file = _review_dir(mso) / f"{order_id}.json"
    if not order_file.exists():
        raise FileNotFoundError(f"Order {order_id!r} not found in queues/review/")
    data = json.loads(order_file.read_text(encoding="utf-8"))
    return order_file, data


def _assert_nav_review_pending(order_id: str, data: Dict[str, Any]) -> None:
    status = (data.get("status") or "").upper()
    if status and status != "NAV_REVIEW_PENDING":
        raise ValueError(
            f"Order {order_id!r} has status {status!r}; expected NAV_REVIEW_PENDING"
        )


# ---------------------------------------------------------------------------
# FTR-MSO-2026-0427 gate derivation (D5 — previously CLI-only)
# ---------------------------------------------------------------------------

def gate_roles(data: Dict[str, Any]) -> tuple[str, str]:
    """The RAW (from_role, to_role) the order is gated at.

    Raw — spelled the way this order's own roleSequence spells them —
    because ``revise`` puts from_role straight back into ``targetRole`` and
    ``approve`` feeds both into the ADVANCED ledger event.

    Prefers the ``reviewGateFrom``/``reviewGateTo`` fields the dispatcher
    writes when parking the order, and falls back to deriving the
    predecessor from the order's roleSequence — which is how an order paused
    by a pre-0427 dispatcher (only ``targetRole`` recorded) still resolves
    correctly.
    """
    to_role = str(data.get("reviewGateTo") or data.get("targetRole") or "")
    from_role = str(data.get("reviewGateFrom") or "")
    if not from_role:
        sequence = data.get("roleSequence") or data.get("_meta", {}).get("roleSequence") or []
        if sequence and to_role in sequence:
            idx = sequence.index(to_role)
            if idx > 0:
                from_role = sequence[idx - 1]
    return from_role, to_role


def gate_label(data: Dict[str, Any]) -> str:
    """Human-facing label for the gate an order is held at.

    A planning gate — including the BUG-0205 standalone plan-approval hold,
    which has no next role to name — keeps rendering as ``NAV``, so existing
    operator muscle memory and log greps (``"rejected at NAV review"``) hold
    verbatim. Any gate that could not exist before FTR-MSO-2026-0427 renders
    as its canonical transition (``BLD->REL``).
    """
    from maestro.core.gates import canonical_role, is_planning_role

    from_role, to_role = gate_roles(data)
    if not from_role or not to_role or is_planning_role(from_role):
        return "NAV"
    return f"{canonical_role(from_role)}->{canonical_role(to_role)}"


def review_artefact(mso: Path, order_id: str, data: Dict[str, Any]) -> Optional[Path]:
    """The document a reviewer should read for this gate, if one exists.

    A planning gate is reviewed against the plan. FTR-MSO-2026-0427: any
    other gate is reviewed against the handoff the gated role wrote — for a
    BLD->REL gate there is no PLAN-<id>.md, and falling straight through to
    the order JSON/description tells the reviewer nothing about what is
    being approved for deploy. Shared by the CLI's ``mso review show`` and
    the Hub's plan endpoint (D5) so they resolve to the same document.
    """
    plan_path = mso / "plans" / f"PLAN-{order_id}.md"
    if plan_path.exists():
        return plan_path
    from_role, to_role = gate_roles(data)
    if from_role and to_role:
        handoff = mso / "handoffs" / order_id / f"{from_role}-to-{to_role}.md"
        if handoff.exists():
            return handoff
    return None


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def find_review_pending_orders(mso: Path) -> list[dict]:
    """Return all orders from queues/review/ (NAV_REVIEW_PENDING and unlabelled)."""
    review_dir = _review_dir(mso)
    if not review_dir.exists():
        return []

    results: list[dict] = []
    for f in sorted(review_dir.glob("*.json")):
        try:
            results.append(json.loads(f.read_text(encoding="utf-8")))
        except Exception:
            pass
    return results


def get_plan_content(mso: Path, order_id: str) -> tuple[Optional[str], bool, Optional[dict]]:
    """Return (markdown, has_artefact_file, order_data) for the review viewer.

    D5: falls back to the gated role's handoff document (via
    ``review_artefact``) before falling back to the order's raw description
    — matching the CLI's ``mso review show``. Returns (None, False, None)
    when the order is not found in the review queue.
    """
    order_file = _review_dir(mso) / f"{order_id}.json"
    if not order_file.exists():
        return None, False, None

    try:
        data = json.loads(order_file.read_text(encoding="utf-8"))
    except Exception:
        return None, False, None

    doc_path = review_artefact(mso, order_id, data)
    if doc_path is not None:
        try:
            return doc_path.read_text(encoding="utf-8"), True, data
        except Exception:
            pass

    return (data.get("description") or ""), False, data


def approve_order(mso: Path, order_id: str, *, reviewer: Optional[str] = None, source: str = "cli") -> dict:
    """Approve a NAV_REVIEW_PENDING order — mirrors ``mso review approve``.

    Two cases:
      * Intra-order (targetRole set): advance to the next role and re-queue
        to queues/orders/ for the dispatcher to pick up.
      * BUG-MSO-2026-0205 plan approval (planApprovalOnly): the standalone
        planning order has no next role — archive it as COMPLETE so its
        dependent FTR/BLD orders unblock (NAV_REVIEW_PENDING is not a
        satisfying dependency status).

    *source* tags the lifecycle-log entry (e.g. ``"hub"``) so operators can
    tell which surface performed the action; the CLI default leaves it bare.

    Raises FileNotFoundError / ValueError / PermissionError — see module
    docstring.
    """
    _enforce_capability(mso)
    order_file, data = load_review_order(mso, order_id)
    _assert_nav_review_pending(order_id, data)

    now = datetime.now().isoformat()
    reviewer = reviewer or reviewer_identity()
    tag = f" ({source})" if source != "cli" else ""

    data["reviewedAt"] = now
    data["reviewedBy"] = reviewer
    data.pop("navReviewPausedAt", None)

    if data.get("planApprovalOnly"):
        voyage_id = data.get("voyageId", "")
        data["status"] = "COMPLETE"
        data["completedAt"] = now
        data.pop("planApprovalOnly", None)
        archive_dir = mso / "orders" / "complete"
        archive_dir.mkdir(parents=True, exist_ok=True)
        dest = archive_dir / order_file.name
        _write_atomic(dest, data)
        order_file.unlink()

        # BUG-MSO-2026-0239 / BUG-MSO-2026-0476: shared dependent lookup so
        # the two review surfaces cannot drift out of parity on promotion.
        promoted = promote_proposed_dependents(mso, order_id, voyage_id, write_json=_write_atomic)
        filed = find_filed_dependents(mso, order_id, voyage_id)
        if promoted:
            promo_msg = f"promoted {promoted} build order(s) to PENDING"
        elif filed:
            promo_msg = f"{len(filed)} dependent(s) already filed, none PROPOSED to promote"
        else:
            promo_msg = "no PROPOSED dependents found to promote"
        _write_lifecycle(
            mso, "NAV_REVIEW_APPROVED",
            f"{order_id} plan approved by {reviewer} -> COMPLETE; {promo_msg}{tag}",
        )

        result: dict = {
            "new_status": "COMPLETE",
            "dependents_promoted": promoted,
            "dependents_filed": len(filed),
        }
        if not filed:
            # BUG-MSO-2026-0476: nothing was ever filed to unblock this plan.
            warning = (
                f"no dependent orders exist for {voyage_id or order_id} — "
                "build orders (FTR/BLD) must be filed before this voyage can finish"
            )
            _write_lifecycle(mso, "PLAN_ORPHANED", f"{order_id}: {warning}")
            result["warning"] = warning
        return result

    # Intra-order: advance to the next role (already set by fleet_runner) and re-queue.
    next_role = data.get("targetRole", "BLD")
    data["status"] = "PENDING"

    # FTR-MSO-2026-0281: copy PLN-recommended execution profile to authoritative
    # fields at the human approve gate. Only copy when the authoritative field is
    # unset (do not clobber operator choices).
    copied_profile = []
    for rec_key, auth_key in (
        ("recommendedModel", "model"),
        ("recommendedContextWindow", "contextWindow"),
        ("recommendedEffort", "effort"),
    ):
        rec_val = data.get(rec_key, "")
        auth_val = data.get(auth_key, "")
        if rec_val and not auth_val:
            data[auth_key] = rec_val
            copied_profile.append(f"{auth_key}={rec_val}")
    profile_note = f"; profile: {', '.join(copied_profile)}" if copied_profile else ""

    # BUG-MSO-2026-0315: derive from_role BEFORE the file move so we can record
    # the ADVANCED ledger event the BUG-0248 advance-loss guard requires.
    gate = gate_label(data)
    from_role, _ = gate_roles(data)

    # The gate has been satisfied — clear its markers so the released order
    # doesn't carry a stale gate label into its next role.
    for gate_field in ("reviewGate", "reviewGateFrom", "reviewGateTo"):
        data.pop(gate_field, None)

    orders_dir = _orders_dir(mso)
    orders_dir.mkdir(parents=True, exist_ok=True)
    dest = orders_dir / order_file.name
    _write_atomic(dest, data)
    order_file.unlink()

    # D4 / BUG-MSO-2026-0315: write the ADVANCED ledger event so the dispatch
    # gate sees the role progression after `mso cleanup` or a fresh dispatcher
    # session. Without this the ledger only has CLAIMED events (at the old
    # role) and the BUG-0248 guard rewinds targetRole back to the completed
    # role, looping the approved crew forever. The Hub path used to skip this
    # entirely.
    from maestro.core import order_ledger
    order_ledger.record_advanced(order_id, from_role, next_role, workspace_dir=mso)

    _write_lifecycle(
        mso, "NAV_REVIEW_APPROVED",
        f"{order_id} approved by {reviewer} at gate {gate} -> {next_role}{profile_note}{tag}",
    )
    return {"new_status": "PENDING", "target_role": next_role, "gate": gate}


def revise_order(mso: Path, order_id: str, notes: str, *, reviewer: Optional[str] = None, source: str = "cli") -> dict:
    """Send the order back to the gated role for revision, appending notes.

    FTR-MSO-2026-0427: "back" is the role that just completed and triggered
    the gate, not an unconditional NAV. An order held at BLD->REL goes back
    to BLD to redo the build; only when no transition can be recovered (a
    pre-0427 pause with an unhelpful roleSequence) does it fall back to NAV.

    D2: this re-queues the order (status=PENDING, targetRole=<gated role>,
    moved to queues/orders/) so the dispatcher picks it back up — exactly
    like ``mso review revise``. The Hub's prior implementation instead set
    status=REVISION_REQUESTED and left the file in queues/review/: the
    dispatcher never saw it again, and because status != NAV_REVIEW_PENDING
    every later review action 409'd. The order was stranded for good.

    Raises FileNotFoundError / ValueError (missing notes, or wrong status) /
    PermissionError — see module docstring.
    """
    _enforce_capability(mso)
    if not notes:
        raise ValueError("revision notes are required")

    order_file, data = load_review_order(mso, order_id)
    _assert_nav_review_pending(order_id, data)

    now = datetime.now().isoformat()
    reviewer = reviewer or reviewer_identity()
    tag = f" ({source})" if source != "cli" else ""

    gate = gate_label(data)
    revise_role, _ = gate_roles(data)
    revise_role = revise_role or "NAV"

    existing_desc = data.get("description", "") or ""
    data["description"] = f"{existing_desc}\n\n[Revision requested {now} by {reviewer}]: {notes}".strip()
    data["status"] = "PENDING"
    data["targetRole"] = revise_role
    data["reviewedAt"] = now
    data["reviewedBy"] = reviewer
    data.pop("navReviewPausedAt", None)
    for gate_field in ("reviewGate", "reviewGateFrom", "reviewGateTo"):
        data.pop(gate_field, None)

    orders_dir = _orders_dir(mso)
    orders_dir.mkdir(parents=True, exist_ok=True)
    dest = orders_dir / order_file.name
    _write_atomic(dest, data)
    order_file.unlink()

    _write_lifecycle(
        mso, "NAV_REVIEW_REVISED",
        f"{order_id} revised by {reviewer} at gate {gate} -> {revise_role}: {notes}{tag}",
    )
    return {"new_status": "PENDING", "target_role": revise_role, "gate": gate}


def reject_order(mso: Path, order_id: str, notes: str, *, reviewer: Optional[str] = None, source: str = "cli") -> dict:
    """Reject an order: mark it FAILED and archive to orders/failed/.

    D3: matches every other failure path in the system (status=FAILED,
    failureReason, orders/failed/). The Hub's prior implementation used
    status=REJECTED / rejectionReason and archived to
    queues/review/rejected/ — a location nothing else scans, so a
    Hub-rejected order was invisible to ``mso status`` and dashboards that
    read orders/failed/.

    Raises FileNotFoundError / ValueError (missing notes, or wrong status) /
    PermissionError — see module docstring.
    """
    _enforce_capability(mso)
    if not notes:
        raise ValueError("rejection notes are required")

    order_file, data = load_review_order(mso, order_id)
    _assert_nav_review_pending(order_id, data)

    now = datetime.now().isoformat()
    reviewer = reviewer or reviewer_identity()
    tag = f" ({source})" if source != "cli" else ""

    # FTR-MSO-2026-0427: name the gate that rejected it. gate_label renders
    # the planning gate as "NAV", so the legacy "rejected at NAV review"
    # phrasing is unchanged for every gate that existed before this feature.
    gate = gate_label(data)
    data["status"] = "FAILED"
    data["failureReason"] = f"rejected at {gate} review: {notes}"
    data["reviewedAt"] = now
    data["reviewedBy"] = reviewer
    data.pop("navReviewPausedAt", None)

    archive_dir = mso / "orders" / "failed"
    archive_dir.mkdir(parents=True, exist_ok=True)
    dest = archive_dir / order_file.name
    _write_atomic(dest, data)
    order_file.unlink()

    _write_lifecycle(mso, "NAV_REVIEW_REJECTED", f"{order_id} rejected by {reviewer}: {notes}{tag}")
    return {"new_status": "FAILED"}
