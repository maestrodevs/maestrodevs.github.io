"""Artefact-plane push divergence tracking (BUG-MSO-2026-0548).

GitHub #369, section 1. When the debounced artefact-repo push (FTR-MSO-2026-0366,
``fleet_runner.flush_artefact_push``) fails, the failure is intentionally
fail-open — a transient network blip must never halt the fleet. The defect
this module fixes is not the fail-open push itself but its SILENCE: before
this fix, a failing push just repeated the same WARN on an exponential-backoff
timer forever, with no escalation and no signal in ``mso status``. On one
live PSG fleet the plane drifted 4 local / 4 remote commits for hours with
nothing visibly wrong — ``mso status`` looked clean the whole time.

Why this matters more than a log line: the durable artefact plane (order
ledger, queue files, lifecycle log) is the git-immune dispatch gate
(BUG-MSO-2026-0294). If it has diverged from origin, dispatch decisions may
be made against a stale view of the fleet's own state.

This module owns:
  - the two escalation thresholds (retry count / commit-divergence size),
    both configurable via the ``artefacts`` block in workspace.json
  - a best-effort ``git fetch`` + ahead/behind measurement against origin
  - a small persisted state file (``.mso/state/artefact-divergence.json``)
    that ``mso status`` reads so divergence survives a dispatcher restart
    and is visible without grepping lifecycle.log

Threshold defaults (both overridable):
  - ``divergenceRetryThreshold`` = 3 consecutive failed pushes. The backoff
    sequence is 30s/60s/120s/... so 3 failures is ~90s of sustained failure —
    long enough that a single flaky-network blip (which recovers on the very
    next attempt and resets the counter to 0) can never trip it, but short
    enough that the operator is told well before the "hours" scenario from
    the field report.
  - ``divergenceCommitThreshold`` = 3 commits ahead OR behind origin. The
    field incident reached 4/4 before anyone noticed; 3 catches sustained
    divergence a beat earlier without firing on the kind of single-commit
    lag a debounce window ordinarily produces.

Escalation is OR, not AND (per the bug report): either signal firing is
enough — a wide divergence detected on the very first failed push (e.g. the
remote moved out from under a long-offline laptop) must not wait for 3
retries, and a narrow-but-persistent failure (divergence unmeasurable while
offline) must still escalate on retry count alone.
"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

from maestro.core.proc import run_hidden

DIVERGENCE_RETRY_THRESHOLD_DEFAULT = 3
DIVERGENCE_COMMIT_THRESHOLD_DEFAULT = 3

DIVERGENCE_DEFAULTS: Dict[str, int] = {
    "divergenceRetryThreshold": DIVERGENCE_RETRY_THRESHOLD_DEFAULT,
    "divergenceCommitThreshold": DIVERGENCE_COMMIT_THRESHOLD_DEFAULT,
}


def load_divergence_config(artefact_root: Path) -> Dict[str, int]:
    """Read escalation thresholds from the ``artefacts`` block, merged over defaults."""
    cfg = dict(DIVERGENCE_DEFAULTS)
    try:
        raw = json.loads((artefact_root / "config" / "workspace.json").read_text(encoding="utf-8"))
        block = raw.get("artefacts") or {}
        for key in DIVERGENCE_DEFAULTS:
            if block.get(key) is not None:
                cfg[key] = max(1, int(block[key]))
    except Exception:
        pass  # fail-open to defaults — a broken config must not crash the push path
    return cfg


def _state_file(artefact_root: Path) -> Path:
    return artefact_root / "state" / "artefact-divergence.json"


def read_divergence_state(artefact_root: Path) -> Dict[str, Any]:
    """Read the persisted divergence state; ``{}`` if absent/unreadable (never diverged)."""
    try:
        return json.loads(_state_file(artefact_root).read_text(encoding="utf-8"))
    except Exception:
        return {}


def write_divergence_state(artefact_root: Path, **fields: Any) -> None:
    """Merge-write the divergence state file (fail-open on IO errors)."""
    try:
        state = read_divergence_state(artefact_root)
        state.update(fields)
        state["updatedAt"] = datetime.now().isoformat()
        path = _state_file(artefact_root)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(state, indent=2), encoding="utf-8")
    except Exception:
        pass


def measure_divergence(repo: Path, branch: str, timeout: int = 15) -> Optional[Tuple[int, int]]:
    """Best-effort ``(behind, ahead)`` commit counts vs ``origin/<branch>``.

    Returns ``None`` when it cannot be determined (offline, no tracking ref,
    git error) — callers must treat that as UNKNOWN, never as zero, so an
    offline laptop never gets a false "not diverged" reading.
    """
    try:
        fetch_r = run_hidden(
            ["git", "fetch", "origin", branch],
            capture_output=True, text=True, cwd=str(repo), timeout=timeout)
        if fetch_r.returncode != 0:
            return None
        count_r = run_hidden(
            ["git", "rev-list", "--left-right", "--count", f"origin/{branch}...{branch}"],
            capture_output=True, text=True, cwd=str(repo), timeout=timeout)
        if count_r.returncode != 0:
            return None
        parts = (count_r.stdout or "").split()
        if len(parts) != 2:
            return None
        behind, ahead = int(parts[0]), int(parts[1])
        return behind, ahead
    except Exception:
        return None


def resolve_command(repo: Path, branch: str) -> str:
    """Command an operator runs to inspect + reconcile a diverged artefact plane."""
    return (
        f"git -C \"{repo}\" fetch origin && git -C \"{repo}\" status  "
        f"(inspect, then reconcile: git -C \"{repo}\" pull --rebase origin {branch} "
        f"&& git -C \"{repo}\" push origin {branch})"
    )


def build_escalation_message(branch: str, fail_count: int,
                             ahead: Optional[int], behind: Optional[int],
                             repo: Path) -> str:
    """The escalated lifecycle message: what happened, what it MEANS, how to fix it."""
    if ahead is not None and behind is not None:
        size_bit = f"{ahead} ahead / {behind} behind origin/{branch}"
    else:
        size_bit = "divergence size unknown (offline or fetch failed)"
    return (
        f"ARTEFACT PLANE DIVERGED from origin/{branch} — {size_bit}, "
        f"{fail_count} consecutive push failure(s). The order ledger, queue "
        f"files and lifecycle log are the git-immune dispatch gate "
        f"(BUG-MSO-2026-0294) — while diverged they may be STALE, and "
        f"dispatch decisions may be made against an out-of-date view of the "
        f"fleet's own state. Resolve: {resolve_command(repo, branch)}"
    )
