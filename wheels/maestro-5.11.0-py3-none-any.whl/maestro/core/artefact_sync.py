"""Corporate SHARED-mode artefact sync — FTR-MSO-2026-0374 (Phase 3a / FTR-H).

Shared mode: multiple engineers' dispatchers operate against clones of ONE
artefact repo with a shared private remote. Cross-machine dispatch safety is
achieved WITHOUT a server, git-natively (plan PLAN-PLN-MSO-2026-0358 §3.4/§3.5):

  * CLAIM-BY-COMMIT (first push wins): before a crew is launched the dispatcher
    stamps the order file IN_PROGRESS + ``claimedBy``, commits, and pushes the
    artefact repo *immediately* — claims never debounce, the push IS the mutex.
    A push rejection means someone else claimed first; fetch + rebase, re-evaluate,
    and if the order is now owned elsewhere RELEASE it locally
    (ledger ``RELEASED{lost-claim-race}``) and dispatch nothing — no crew, no error.

  * DEBOUNCED SYNC: a periodic fetch + rebase of the artefact repo
    (``artefacts.syncIntervalSeconds``, default 60) pulls in other machines'
    claims/completions so the local scan sees them. Non-claim lifecycle commits
    still push debounced (FTR-0366); claims push now.

  * FAIL-OPEN: every remote op degrades to local-only-with-loud-WARN on failure
    (an offline laptop keeps working — a documented split-brain window, plan risk
    register). The push mutex only protects when the remote is reachable.

  * TIER GATE: shared mode is Team/Enterprise only (Captain ruling 0a #5);
    ``MAESTRO_SKIP_AUTH`` is honoured for CI exactly as elsewhere.

The LOCAL gitignored ledger (:mod:`maestro.core.order_ledger`) remains the
per-machine race-proof gate exactly as in embedded/solo mode; this module adds
the CROSS-machine layer on top (plan 3.4 precedence: local ledger wins for local
dispatch decisions, the committed durable plane wins across machines).

Git operations are injected via :class:`GitRunner` so the claim state machine is
unit-testable with scripted push rejections — no real remote required.
"""

from __future__ import annotations

import json
import os
import socket
import subprocess
from maestro.core.proc import run_hidden, popen_hidden  # FTR-MSO-2026-0408: windowless subprocess
import threading
import time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Callable, Dict, Optional

from maestro.core import order_ledger
from maestro.core import role_history  # FTR-MSO-2026-0598: per-role startedAt/endedAt history

# Team/Enterprise gate — mirrors auth.HUB_TIERS (kept local so a licence-module
# import is never on the hot dispatch path).
SHARED_TIERS = {"team", "enterprise"}

DEFAULT_SYNC_INTERVAL_SECONDS = 60

# How many push→rebase→re-push cycles to attempt before giving up and releasing
# the order (safe: it stays PENDING for a later tick). Bounds a busy remote.
_CLAIM_PUSH_MAX_RETRIES = 3

# stderr substrings that mean "your push was REJECTED because the remote moved"
# (someone else claimed first) — as opposed to a network/transport failure.
_REJECTION_MARKERS = (
    "rejected",
    "non-fast-forward",
    "fetch first",
    "failed to push some refs",
    "[remote rejected]",
    "cannot lock ref",
)


# ---------------------------------------------------------------------------
# Injectable git wrapper (test seam)
# ---------------------------------------------------------------------------

@dataclass
class GitResult:
    returncode: int
    stdout: str = ""
    stderr: str = ""

    @property
    def ok(self) -> bool:
        return self.returncode == 0


class GitRunner:
    """Thin wrapper around ``git`` in a fixed cwd.

    Tests subclass this and override :meth:`run` to script a deterministic
    sequence of results (e.g. push rejected on the first attempt, accepted on
    the second) without touching a real remote.
    """

    def __init__(self, cwd: Path, timeout: int = 120):
        self.cwd = str(cwd)
        self.timeout = timeout

    def run(self, *args: str, timeout: Optional[int] = None) -> GitResult:
        try:
            cp = run_hidden(
                ["git", *args], cwd=self.cwd, capture_output=True, text=True,
                timeout=timeout or self.timeout)
            return GitResult(cp.returncode, cp.stdout or "", cp.stderr or "")
        except Exception as exc:  # timeout, git missing, etc. — treated as failure
            return GitResult(1, "", str(exc))

    # -- convenience helpers -------------------------------------------------

    def current_branch(self) -> Optional[str]:
        r = self.run("rev-parse", "--abbrev-ref", "HEAD", timeout=15)
        b = (r.stdout or "").strip()
        return b if r.ok and b and b != "HEAD" else None

    def has_remote(self, remote: str = "origin") -> bool:
        return self.run("remote", "get-url", remote, timeout=15).ok

    def identity(self) -> str:
        r = self.run("config", "user.email", timeout=15)
        return (r.stdout or "").strip() if r.ok else ""


def _is_rejection(result: GitResult) -> bool:
    """True when a failed push was REJECTED (remote moved) vs a transport error."""
    blob = f"{result.stderr}\n{result.stdout}".lower()
    return any(marker in blob for marker in _REJECTION_MARKERS)


# ---------------------------------------------------------------------------
# Config readers (read workspace.json directly; fail-open to defaults)
# ---------------------------------------------------------------------------

def _workspace_json(artefact_root: Path) -> dict:
    try:
        return json.loads(
            (artefact_root / "config" / "workspace.json").read_text(encoding="utf-8"))
    except Exception:
        return {}


def sync_interval_seconds(artefact_root: Path) -> int:
    """``artefacts.syncIntervalSeconds`` (default 60, clamped to >= 0)."""
    try:
        val = int((_workspace_json(artefact_root).get("artefacts") or {}).get(
            "syncIntervalSeconds", DEFAULT_SYNC_INTERVAL_SECONDS))
        return max(0, val)
    except Exception:
        return DEFAULT_SYNC_INTERVAL_SECONDS


def get_mode(artefact_root: Path) -> str:
    """``artefacts.mode`` for the workspace rooted at *artefact_root* (the
    ``.mso`` dir) — ``embedded`` | ``solo`` | ``shared``, defaulting to
    ``embedded`` (absent/unreadable block, fail-open).

    Anchored at a caller-known *artefact_root* rather than re-resolving from
    cwd (mirrors ``fleet_runner.get_artefact_mode()``'s own local reader) —
    ``mso bug`` / ``mso voyage create`` already have ``mso_dir`` resolved and
    must not risk re-walking to a different workspace.
    """
    mode = (_workspace_json(artefact_root).get("artefacts") or {}).get("mode")
    return mode if mode in ("solo", "shared") else "embedded"


# ---------------------------------------------------------------------------
# Tier gate (Captain ruling 0a #5 — shared mode is Team/Enterprise only)
# ---------------------------------------------------------------------------

def shared_tier_ok() -> bool:
    """True when the active licence tier permits shared mode. Never raises.

    Honours ``MAESTRO_SKIP_AUTH`` via :func:`auth.has_tier` (CI, as elsewhere).
    """
    try:
        from maestro import auth
        return auth.has_tier(SHARED_TIERS)
    except Exception:
        return False


def require_shared_tier(feature: str = "Shared artefact repo (corporate mode)") -> None:
    """``sys.exit(1)`` with an upgrade message unless the tier permits shared mode.

    Called at the ``mode: shared`` config switch (dispatcher startup). Honours
    ``MAESTRO_SKIP_AUTH`` — CI passes through.
    """
    from maestro import auth
    auth.require_tier(SHARED_TIERS, feature=feature)


# ---------------------------------------------------------------------------
# Lifecycle-event helper (lazy import to avoid a fleet_runner import cycle)
# ---------------------------------------------------------------------------

def _write_lifecycle_event(event_type: str, message: str) -> None:
    try:
        from maestro.core import fleet_runner
        fleet_runner.write_lifecycle_event(event_type, message)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Claim-by-commit
# ---------------------------------------------------------------------------

@dataclass
class ClaimOutcome:
    """Result of a shared-mode claim attempt.

    ``won``      — this dispatcher owns the order and MUST launch the crew.
    ``reason``   — machine-readable outcome tag (for logging/tests).
    ``degraded`` — True when the remote was unreachable and we proceeded
                   local-only (split-brain window; loud WARN already emitted).
    """
    won: bool
    reason: str
    degraded: bool = False


def _order_owner(path: Path) -> Optional[Dict]:
    """The ``claimedBy`` stamp on the order file, or None if unclaimed/absent."""
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None
    return data.get("claimedBy") or None


def _is_ours(owner: Optional[Dict], host: str, pid: int) -> bool:
    if not owner:
        return False
    return owner.get("host") == host and owner.get("pid") == pid


def _stamp_claim(path: Path, data: Dict, crew_num: int, role: str,
                 host: str, engineer: str, at_iso: str) -> None:
    """Write the durable claim stamp onto the order JSON (plan §3.5.2/§3.5.4)."""
    data["status"] = "IN_PROGRESS"
    data["assignedTo"] = {"crew": crew_num, "role": role}
    # FTR-MSO-2026-0598: opens a roleHistory turn with the SAME timestamp as
    # the legacy startedAt stamp below, so both fields agree.
    role_history.open_role_turn(data, role, at_iso)
    data["startedAt"] = at_iso
    data["claimedBy"] = {
        "engineer": engineer,
        "host": host,
        "pid": os.getpid(),
        "at": at_iso,
    }
    data["claimedAt"] = at_iso
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")


def claim_order_shared(item: Dict, crew_num: int, *,
                       workspace_dir: Path,
                       git: Optional[GitRunner] = None,
                       host: Optional[str] = None,
                       engineer: Optional[str] = None,
                       now: Optional[datetime] = None,
                       branch: Optional[str] = None) -> ClaimOutcome:
    """Claim *item* for *crew_num* under shared mode — the cross-machine mutex.

    Sequence:
      1. Stamp the order file IN_PROGRESS + ``claimedBy`` and record the LOCAL
         ledger CLAIMED (the per-machine gate, unchanged).
      2. Commit the stamp and PUSH IMMEDIATELY (claims never debounce).
      3. Push accepted  → we won; launch the crew.
         Push rejected  → someone claimed first: fetch + rebase.
             rebase conflicts (same order file) → theirs wins → reset to remote,
               ledger ``RELEASED{lost-claim-race}``, return ``won=False`` (no crew).
             rebase clean (unrelated change) → still ours → re-push (bounded).
         Push transport error → FAIL-OPEN: proceed local-only with a loud WARN
           (offline split-brain window); ``won=True, degraded=True``.

    Fully degrades in non-git / synthetic-item contexts (unit tests, embedded
    fallbacks): if there is no queue path or no ``.git``, it performs only the
    local stamp + ledger claim and returns ``won=True`` — identical to the
    solo/embedded claim.
    """
    role = item.get("role", "")
    host = host or socket.gethostname()
    at_iso = (now or datetime.now()).isoformat()
    ledger_ws = _ledger_ws_for_item(item, workspace_dir)

    raw_path = item.get("path")
    path = Path(raw_path) if raw_path else None

    # Repo root that carries the durable artefact plane = parent of the .mso dir.
    repo_root = Path(workspace_dir).parent
    git = git or GitRunner(repo_root)

    # --- Step 1: local claim (stamp + ledger) always happens first ----------
    data = item.get("data") or {}
    if not engineer:
        engineer = git.identity()
    if path is not None:
        try:
            # Re-read from disk if the in-memory copy is thin.
            if not data:
                data = json.loads(path.read_text(encoding="utf-8"))
            _stamp_claim(path, data, crew_num, role, host, engineer, at_iso)
            item["data"] = data
        except Exception as exc:
            _write_lifecycle_event(
                "WARN", f"{item.get('id')} claim stamp write failed: {exc}")
    if ledger_ws is not None:
        order_ledger.record_claimed(
            item.get("id", ""), role, crew_num, workspace_dir=ledger_ws)

    # No file on disk (synthetic/test item) → local-only claim, done.
    if path is None or not path.exists():
        return ClaimOutcome(True, "local-only-no-file")

    # Not a git repo (e.g. hermetic tmp workspace) → local-only claim, done.
    if not (repo_root / ".git").exists():
        return ClaimOutcome(True, "local-only-no-git")

    branch = branch or git.current_branch()
    if not branch:
        return ClaimOutcome(True, "local-only-no-branch")

    # --- Step 2: commit the claim -------------------------------------------
    order_id = item.get("id", "")
    add_r = git.run("add", "--", str(path), timeout=15)
    if not add_r.ok:
        return ClaimOutcome(True, "local-only-add-failed", degraded=True)
    commit_msg = f"lifecycle: claim {order_id} (crew {crew_num}, {engineer or host})"
    commit_r = git.run("commit", "-m", commit_msg, "--", str(path), timeout=30)
    if not commit_r.ok:
        # Nothing to commit / commit failed → nothing to push; keep local claim.
        return ClaimOutcome(True, "local-only-nothing-committed", degraded=True)

    # No remote configured → local-only (shared mode expects one, but never block).
    if not git.has_remote():
        _write_lifecycle_event(
            "WARN",
            f"{order_id} claimed but artefact repo has no 'origin' remote — "
            f"local-only claim (shared-mode split-brain risk, FTR-0374)")
        return ClaimOutcome(True, "local-only-no-remote", degraded=True)

    # --- Step 3: push-immediately with rebase-retry -------------------------
    return _push_claim_with_retry(
        git, item, order_id, branch, host, os.getpid(), ledger_ws)


def _push_claim_with_retry(git: GitRunner, item: Dict, order_id: str,
                           branch: str, host: str, pid: int,
                           ledger_ws: Optional[Path]) -> ClaimOutcome:
    path = Path(item["path"])
    for attempt in range(1, _CLAIM_PUSH_MAX_RETRIES + 1):
        push_r = git.run("push", "origin", branch, timeout=120)
        if push_r.ok:
            _write_lifecycle_event(
                "CLAIM_PUSHED",
                f"{order_id} claimed and pushed to origin/{branch} "
                f"(first-push-wins, FTR-0374)")
            return ClaimOutcome(True, "pushed")

        if not _is_rejection(push_r):
            # Transport/other error — FAIL-OPEN. Keep the local claim and run the
            # crew; the durable stamp will push once the remote returns.
            _write_lifecycle_event(
                "WARN",
                f"{order_id} claim push failed (not a rejection) — proceeding "
                f"local-only, split-brain window until reconnect (fail-open, "
                f"FTR-0374): {(push_r.stderr or push_r.stdout or '').strip()[:200]}")
            return ClaimOutcome(True, "fail-open-degraded", degraded=True)

        # Rejected: the remote moved — someone else pushed. Rebase onto it.
        git.run("fetch", "origin", branch, timeout=60)
        rebase_r = git.run("rebase", f"origin/{branch}", timeout=60)
        if not rebase_r.ok:
            # Conflict on the claim commit ⇒ same order claimed remotely first.
            # Theirs wins: abort, hard-reset to the remote tip, release locally.
            git.run("rebase", "--abort", timeout=30)
            git.run("reset", "--hard", f"origin/{branch}", timeout=30)
            return _release_lost(order_id, ledger_ws, "rebase-conflict")

        # Rebase clean (an UNRELATED change landed). Confirm we still own the
        # order after replaying our commit; if the remote content shows a
        # different owner, we lost. Otherwise loop and re-push.
        owner = _order_owner(path)
        if owner is not None and not _is_ours(owner, host, pid):
            git.run("reset", "--hard", f"origin/{branch}", timeout=30)
            return _release_lost(order_id, ledger_ws, "owner-changed")
        # else: still ours — retry the push (up to the cap).

    # Retries exhausted against a hot remote — release; a later tick retries.
    git.run("reset", "--hard", f"origin/{branch}", timeout=30)
    return _release_lost(order_id, ledger_ws, "push-retries-exhausted")


def _release_lost(order_id: str, ledger_ws: Optional[Path],
                  detail: str) -> ClaimOutcome:
    """Record the lost-claim race and return a losing outcome (no crew spawned)."""
    if ledger_ws is not None:
        try:
            order_ledger.record_released(
                order_id, "lost-claim-race", workspace_dir=ledger_ws)
        except Exception:
            pass
    _write_lifecycle_event(
        "RELEASED",
        f"{order_id} lost claim race ({detail}) — released locally, no crew "
        f"spawned (RELEASED{{lost-claim-race}}, FTR-0374)")
    return ClaimOutcome(False, "lost-claim-race")


# ---------------------------------------------------------------------------
# ID-minting reservation (FTR-MSO-2026-0574 — PLAN §2.3 Option B, shared mode
# ONLY). Reuses claim_order_shared's push-as-mutex shape rather than a second
# coordination mechanism: write the freshly allocated id's file, commit, push
# IMMEDIATELY. A rejected push means another device reserved a number first —
# fetch + reset to the remote tip and re-mint against the now-current state.
# ---------------------------------------------------------------------------

_ID_RESERVATION_MAX_REMINT = 3


@dataclass
class ReservationOutcome:
    """Result of a shared-mode ID-reservation attempt.

    ``id``       — the id that ended up written to disk (always set).
    ``pushed``   — True when the reservation commit reached the remote.
    ``degraded`` — True when coordination was skipped/short-circuited (no
                   remote, transport failure, or retries exhausted) — the id
                   is still minted and written, just without the cross-device
                   guarantee (fail-open, same posture as ``claim_order_shared``).
    """
    id: str
    pushed: bool
    reason: str
    degraded: bool = False


def push_id_reservation(mso_dir: Path, mint: Callable[[Optional[GitRunner]], str],
                        write_file: Callable[[str], Path], *,
                        git: Optional[GitRunner] = None,
                        branch: Optional[str] = None) -> ReservationOutcome:
    """Mint + reserve an id in shared mode via push-as-mutex.

    ``mint(git) -> id`` computes the next id — reusing *git* so the retry
    loop below doesn't redundantly re-fetch what a prior iteration's reset
    already synced. ``write_file(id) -> Path`` writes the order/voyage JSON
    for that id and returns the path it wrote — keeps this function agnostic
    of order-vs-voyage JSON shape (plan §2.3 explicitly wants ONE mechanism
    reused, not a parallel one per artefact kind).

    Only meaningful in ``artefacts.mode: shared`` — callers gate on
    :func:`get_mode` before calling this. Solo mode does NOT get reservation
    (plan §0: an unsynced solo device against a shared plane is a
    misconfiguration to migrate away from, not something to bolt a mutex
    onto) — solo/embedded callers should mint via ``mint(None)`` directly and
    skip this function entirely.

    Fully fails open: no git repo / no remote / transport failure / retries
    exhausted all fall back to a plain local mint-and-write (``degraded=True``,
    ``pushed=False``) rather than blocking order creation — consistent with
    ``claim_order_shared``'s fail-open posture.
    """
    repo_root = Path(mso_dir).parent
    git = git or GitRunner(repo_root)
    branch = branch or git.current_branch()

    if not branch or not (repo_root / ".git").exists() or not git.has_remote():
        new_id = mint(git)
        write_file(new_id)
        return ReservationOutcome(new_id, False, "local-only-no-coordination", degraded=True)

    new_id = ""
    for _attempt in range(1, _ID_RESERVATION_MAX_REMINT + 1):
        new_id = mint(git)
        path = write_file(new_id)

        add_r = git.run("add", "--", str(path), timeout=15)
        if not add_r.ok:
            return ReservationOutcome(new_id, False, "local-only-add-failed", degraded=True)
        commit_r = git.run(
            "commit", "-m", f"lifecycle: reserve {new_id}", "--", str(path), timeout=30)
        if not commit_r.ok:
            return ReservationOutcome(new_id, False, "local-only-nothing-committed", degraded=True)

        push_r = git.run("push", "origin", branch, timeout=120)
        if push_r.ok:
            _write_lifecycle_event(
                "ID_RESERVED",
                f"{new_id} reserved and pushed to origin/{branch} "
                f"(push-as-mutex, FTR-MSO-2026-0574)")
            return ReservationOutcome(new_id, True, "pushed")

        if not _is_rejection(push_r):
            _write_lifecycle_event(
                "WARN",
                f"{new_id} reservation push failed (not a rejection) — keeping "
                f"local allocation, split-brain window until reconnect "
                f"(fail-open, FTR-MSO-2026-0574): "
                f"{(push_r.stderr or push_r.stdout or '').strip()[:200]}")
            return ReservationOutcome(new_id, False, "fail-open-degraded", degraded=True)

        # Rejected: someone else reserved a number first. Undo our local
        # commit + file, sync to the remote tip, and re-mint against it.
        git.run("reset", "--hard", "HEAD~1", timeout=30)
        try:
            path.unlink(missing_ok=True)
        except OSError:
            pass
        git.run("fetch", "origin", branch, timeout=60)
        git.run("reset", "--hard", f"origin/{branch}", timeout=30)

    _write_lifecycle_event(
        "WARN",
        f"ID reservation exhausted {_ID_RESERVATION_MAX_REMINT} retries against a "
        f"hot remote (last attempt {new_id!r}) — proceeding local-only "
        f"(FTR-MSO-2026-0574)")
    return ReservationOutcome(new_id, False, "push-retries-exhausted", degraded=True)


def _ledger_ws_for_item(item: Dict, workspace_dir: Path) -> Optional[Path]:
    """Workspace dir for the item's ledger writes (mirrors fleet_runner._ws_for_item)."""
    raw = item.get("path")
    if not raw:
        return Path(workspace_dir) if workspace_dir else None
    try:
        for parent in Path(raw).parents:
            if parent.name == "queues":
                return parent.parent
    except Exception:
        pass
    return Path(workspace_dir) if workspace_dir else None


# ---------------------------------------------------------------------------
# Debounced sync loop (fetch + rebase the artefact repo)
# ---------------------------------------------------------------------------

_SYNC_LOCK = threading.Lock()
_SYNC_STATE = {"last_sync": 0.0}


def sync_pull_rebase(artefact_root: Path, *,
                     git: Optional[GitRunner] = None,
                     force: bool = False) -> bool:
    """Debounced fetch + rebase of the artefact repo's current branch.

    Makes other machines' claims/completions visible to the local scan. Called
    once per dispatcher tick; runs at most every ``artefacts.syncIntervalSeconds``
    (default 60) unless *force* is set. Fail-open: any error is a WARN and the
    dispatcher keeps running on its last-known state (offline degrades to solo).

    Returns True when a sync actually executed this call (regardless of whether
    new commits arrived).
    """
    interval = sync_interval_seconds(Path(artefact_root))
    with _SYNC_LOCK:
        now = time.monotonic()
        if not force and (now - _SYNC_STATE["last_sync"]) < interval:
            return False
        _SYNC_STATE["last_sync"] = now

    repo_root = Path(artefact_root).parent
    if not (repo_root / ".git").exists():
        return False
    git = git or GitRunner(repo_root)
    if not git.has_remote():
        return False
    branch = git.current_branch()
    if not branch:
        return False

    fetch_r = git.run("fetch", "origin", branch, timeout=60)
    if not fetch_r.ok:
        _write_lifecycle_event(
            "WARN",
            f"artefact sync fetch failed — running on last-known state "
            f"(fail-open, FTR-0374): {(fetch_r.stderr or '').strip()[:200]}")
        return True
    rebase_r = git.run("rebase", f"origin/{branch}", timeout=60)
    if not rebase_r.ok:
        # A local uncommitted/committed divergence conflicts with the remote.
        # Abort the rebase and keep the local tree intact — never wedge the
        # dispatcher; the next lifecycle push surfaces the divergence loudly.
        git.run("rebase", "--abort", timeout=30)
        _write_lifecycle_event(
            "WARN",
            f"artefact sync rebase onto origin/{branch} conflicted — aborted, "
            f"kept local state (fail-open, FTR-0374)")
        return True
    return True


def reset_sync_state() -> None:
    """Test hook: clear the debounce clock so the next sync runs immediately."""
    with _SYNC_LOCK:
        _SYNC_STATE["last_sync"] = 0.0
