"""Runtime order ledger — the git-immune dispatch gate (BUG-MSO-2026-0294).

Why this exists
---------------
The duplicate-dispatch / re-dispatch family recurred three times (BUG-0248
v4.3.5, BUG-0263 v4.3.9, PSG VOY-PSG-2026-0344 on v4.6.1) because every
prior guard anchored dispatch eligibility to git-rewindable state: the
in-progress claim lives in the queue JSON, and the BUG-0263 dedup reads
``orders/complete|failed`` — all uncommitted working-tree writes that a
single ``git reset --hard`` (see BUG-MSO-2026-0295) rewinds in one stroke,
resurrecting completed orders as PENDING and erasing the evidence the
guards relied on.

This module keeps an append-only JSONL ledger at
``.mso/state/order-ledger.jsonl``. The ``state/`` directory is gitignored
(runtime state, like ``crews/`` and ``logs/``), so NO git operation —
reset, checkout, pull, PR round-trip — can touch it. ``scan_all_queues``
consults the replayed ledger before anything else: an order with a
TERMINAL entry is never dispatched again regardless of what its queue file
claims, and an order CLAIMED by a live crew is never handed to a second
crew.

Event grammar (one JSON object per line)
----------------------------------------
    {"ts": iso8601, "event": "CLAIMED",  "orderId": id, "role": r, "crew": n, "pid": p}
    {"ts": iso8601, "event": "ADVANCED", "orderId": id, "fromRole": r1, "toRole": r2}
    {"ts": iso8601, "event": "TERMINAL", "orderId": id, "status": "COMPLETE"|"FAILED"|"STALLED"}
    {"ts": iso8601, "event": "RELEASED", "orderId": id, "reason": str}

Replay semantics: TERMINAL is forever. CLAIMED is cleared by a subsequent
ADVANCED or RELEASED (role advance re-queues the order for its next role;
release/requeue frees it for a fresh crew). A CLAIMED whose pid is dead is
treated as released — the crash-recovery path owns it.

All writes are best-effort: a ledger failure must never crash the
dispatcher (the file-based guards remain as the degraded fallback).

Durable-plane precedence (FTR-MSO-2026-0366 — solo/shared artefact-repo mode)
-----------------------------------------------------------------------------
In solo/shared mode the ledger lives — still gitignored, still git-immune —
inside the ARTEFACT repo checkout (``<artefact-repo>/.mso/state/``): the
default workspace resolution below routes through ``get_artefact_root()``,
so every reader/writer retargets automatically. Precedence per plan
PLAN-PLN-MSO-2026-0358 §3.4: the LOCAL ledger wins for local dispatch
decisions (microsecond-level gate, unchanged); the artefact repo's COMMITTED
state is the cross-machine record. The two meet in exactly two places, both
already retargeted by construction:

- :func:`reconcile_from_plane` (invoked by :func:`seed_if_missing` on every
  dispatcher startup, not just the first — BUG-MSO-2026-0573) learns
  terminal verdicts from ``orders/complete|failed`` — which in solo mode ARE
  the committed archives (lifecycle transitions are committed to the
  artefact repo on every move).
- The BUG-0294 veto's self-heal fallback (scan_all_queues re-archiving a
  stale PENDING copy) reads the same committed archive dirs.

Status-regression guard (BUG-MSO-2026-0573)
--------------------------------------------
A one-shot ``seed_if_missing`` meant a device whose ledger already existed
never learned a terminal verdict another device committed to the plane
afterwards — so the veto above had nothing to enforce against a since-
regressed local write (a COMPLETE order re-marked STALLED by a second,
out-of-sync device). Plan PLAN-PLN-MSO-2026-0549 §3.1/§3.2 traces the root
cause and the fix: reconciliation must be continuous, and :func:`record_terminal`
itself must refuse to move an order from COMPLETE to any other status —
HARD-refused, no override, when the archived order carries a ``relSignOff``
block. The only sanctioned reversal remains the explicit
``mso order retry [--force]`` path, which clears the verdict via
:func:`record_reopened` instead of calling :func:`record_terminal`, so it is
unaffected by this guard. A refusal emits a ``COMPLETION_REGRESSION_REFUSED``
lifecycle event.
"""

from __future__ import annotations

import json
import os
import threading
from datetime import datetime
from pathlib import Path
from typing import Dict, Optional

LEDGER_RELPATH = Path("state") / "order-ledger.jsonl"
COMPACT_THRESHOLD_LINES = 5000

# Serialises ledger file access within this process. The dispatcher is the
# only WRITER process, but it is not single-threaded (bridge notifier, demo
# drivers, tests) — and on Windows, concurrent appends through separate
# handles can interleave mid-line, corrupting the JSONL. Found by the
# stress suite (test_ledger_survives_concurrent_writers).
_WRITE_LOCK = threading.Lock()


def _workspace_dir() -> Path:
    # FTR-MSO-2026-0366: route through the artefact resolver so the ledger
    # follows the durable plane into the artefact repo in solo/shared mode
    # (identical to get_workspace_dir in embedded mode).
    from maestro.workspace import get_artefact_root
    return get_artefact_root()


def ledger_path(workspace_dir: Optional[Path] = None) -> Path:
    return (workspace_dir or _workspace_dir()) / LEDGER_RELPATH


# ---------------------------------------------------------------------------
# Writers (append-only, best-effort)
# ---------------------------------------------------------------------------

def _append(record: dict, workspace_dir: Optional[Path] = None) -> None:
    try:
        path = ledger_path(workspace_dir)
        path.parent.mkdir(parents=True, exist_ok=True)
        record = {"ts": datetime.now().isoformat(), **record}
        with _WRITE_LOCK:
            with open(str(path), "a", encoding="utf-8") as f:
                f.write(json.dumps(record) + "\n")
    except Exception:
        pass  # never let ledger I/O take down the dispatcher


def record_claimed(order_id: str, role: str, crew: int,
                   pid: Optional[int] = None,
                   workspace_dir: Optional[Path] = None) -> None:
    _append({"event": "CLAIMED", "orderId": order_id, "role": role,
             "crew": crew, "pid": pid or os.getpid()}, workspace_dir)


def record_advanced(order_id: str, from_role: str, to_role: str,
                    workspace_dir: Optional[Path] = None) -> None:
    _append({"event": "ADVANCED", "orderId": order_id,
             "fromRole": from_role, "toRole": to_role}, workspace_dir)


def record_terminal(order_id: str, status: str,
                    workspace_dir: Optional[Path] = None) -> bool:
    """Record *order_id* as TERMINAL with *status* (COMPLETE/FAILED/STALLED).

    BUG-MSO-2026-0573 status-regression guard: a write that would move an
    order already known TERMINAL COMPLETE to any other status is refused —
    unconditionally when the archived order carries a ``relSignOff`` block
    (the strongest completion evidence the system has), and refused
    regardless even without one. Completed work is not something a later
    write should be able to silently undo. The only sanctioned reversal is
    ``mso order retry [--force]``, which goes through :func:`record_reopened`
    instead of this function and is therefore untouched by this guard.

    Returns True if the TERMINAL event was written, False if refused (a
    ``COMPLETION_REGRESSION_REFUSED`` lifecycle event is emitted in that
    case). Best-effort — never raises.
    """
    ws = workspace_dir or _workspace_dir()
    if status != "COMPLETE":
        current = load_view(ws).terminal.get(order_id)
        if current == "COMPLETE":
            sign_off = _archived_rel_sign_off(order_id, ws)
            kind = "HARD-refused (relSignOff present)" if sign_off else "refused"
            _write_lifecycle_event(
                ws, "COMPLETION_REGRESSION_REFUSED",
                f"{order_id}: {kind} COMPLETE -> {status} - completed/signed-off work "
                f"is protected; use `mso order retry {order_id} --force` to reopen it."
            )
            return False
    _append({"event": "TERMINAL", "orderId": order_id, "status": status}, ws)
    return True


def _archived_rel_sign_off(order_id: str, workspace_dir: Path) -> bool:
    """True if *order_id*'s archived JSON (complete or failed) carries a
    truthy ``relSignOff`` field — the strongest completion evidence a REL
    role can leave behind (BUG-MSO-2026-0573)."""
    for sub in ("orders/complete", "orders/failed"):
        f = workspace_dir / sub / f"{order_id}.json"
        if not f.exists():
            continue
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if data.get("relSignOff"):
            return True
    return False


def _write_lifecycle_event(workspace_dir: Path, event_type: str, message: str) -> None:
    """Best-effort ``lifecycle.log`` append, scoped explicitly to *workspace_dir*.

    Duplicates the minimal shape of ``fleet_runner.write_lifecycle_event``
    (timestamp | EVENT_TYPE | message, BUG-MSO-2026-0474 sanitization)
    rather than importing it: that function resolves its target via
    ``get_artefact_root()`` (ambient env/cwd), which can differ from an
    explicit *workspace_dir* a caller passed here (e.g. the Hub serving
    several workspaces from one process). Writing directly against
    *workspace_dir* keeps a refusal in the SAME workspace's log as the
    ledger write that triggered it. Never raises.
    """
    try:
        from maestro.core.lifecycle_log import sanitize_lifecycle_message
        log_dir = workspace_dir / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        log_file = log_dir / "lifecycle.log"
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        line = f"{timestamp} | {event_type:<10} | {sanitize_lifecycle_message(message)}\n"
        with open(str(log_file), 'a', encoding='utf-8') as f:
            f.write(line)
    except Exception:
        pass  # never let lifecycle logging take down the dispatcher


def record_released(order_id: str, reason: str,
                    workspace_dir: Optional[Path] = None) -> None:
    _append({"event": "RELEASED", "orderId": order_id, "reason": reason},
            workspace_dir)


def record_reopened(order_id: str, reason: str,
                    workspace_dir: Optional[Path] = None) -> None:
    """BUG-MSO-2026-0297: sanctioned reopen of a TERMINAL order (`mso order retry`).

    The ONLY event that clears a TERMINAL verdict. Without it, a STALLED
    order is unrecoverable: the ledger vetoes re-dispatch forever and the
    scanner self-heal re-archives any manual file move (GKT F2).
    """
    _append({"event": "REOPENED", "orderId": order_id, "reason": reason},
            workspace_dir)


# ---------------------------------------------------------------------------
# Replay view
# ---------------------------------------------------------------------------

class LedgerView:
    """Replayed ledger state: per-order verdicts for the dispatch gate."""

    def __init__(self, terminal: Dict[str, str], claimed: Dict[str, dict],
                 roles: Optional[Dict[str, str]] = None,
                 reopened_at: Optional[Dict[str, str]] = None):
        self.terminal = terminal    # order_id -> terminal status
        self.claimed = claimed      # order_id -> {"crew": n, "pid": p, "role": r}
        self.roles = roles or {}    # order_id -> current expected role
        # order_id -> ts of its most recent REOPENED event (BUG-MSO-2026-0573):
        # reconcile_from_plane uses this to avoid resurrecting a terminal
        # verdict from a stale pre-reopen archive still sitting on disk.
        self.reopened_at = reopened_at or {}

    def is_terminal(self, order_id: str) -> bool:
        return order_id in self.terminal

    def current_role(self, order_id: str) -> Optional[str]:
        """The role the order should run NEXT, per the ledger.

        BUG-0248 / PSG bug 3 (advance-loss loop): the role advance is a
        working-tree write to a git-tracked queue file; a rewind reverts it
        and the order loops PLN↔BLD forever. The ledger's ADVANCED events
        are the durable record of how far the order really progressed —
        scan and complete_order reconcile the file against this.
        """
        return self.roles.get(order_id)

    def live_claim(self, order_id: str, is_alive=None) -> Optional[dict]:
        """Return the claim record if *order_id* is claimed by a LIVE crew.

        A claim whose pid is dead is NOT live — crash recovery owns it.
        ``is_alive`` is injectable for tests; defaults to the dispatcher's
        ctypes-based check.
        """
        claim = self.claimed.get(order_id)
        if not claim:
            return None
        if is_alive is None:
            from maestro.core.fleet_monitor import is_process_alive as is_alive
        pid = claim.get("pid")
        if pid and is_alive(pid):
            return claim
        return None


def load_view(workspace_dir: Optional[Path] = None) -> LedgerView:
    """Replay the ledger into a LedgerView. Corrupt lines are skipped."""
    terminal: Dict[str, str] = {}
    claimed: Dict[str, dict] = {}
    roles: Dict[str, str] = {}
    reopened_at: Dict[str, str] = {}
    path = ledger_path(workspace_dir)
    if path.exists():
        try:
            for line in path.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if not line:
                    continue
                try:
                    rec = json.loads(line)
                except json.JSONDecodeError:
                    continue
                oid = rec.get("orderId")
                event = rec.get("event")
                if not oid or not event:
                    continue
                if event == "TERMINAL":
                    terminal[oid] = rec.get("status", "COMPLETE")
                    claimed.pop(oid, None)
                elif event == "CLAIMED":
                    claimed[oid] = {"crew": rec.get("crew"),
                                    "pid": rec.get("pid"),
                                    "role": rec.get("role")}
                    if rec.get("role"):
                        roles[oid] = rec["role"]
                elif event == "ADVANCED":
                    claimed.pop(oid, None)
                    if rec.get("toRole"):
                        roles[oid] = rec["toRole"]
                elif event == "RELEASED":
                    claimed.pop(oid, None)
                elif event == "REOPENED":
                    # BUG-MSO-2026-0297: `mso order retry` — clears the terminal
                    # verdict AND the role memory (the reopened file's targetRole
                    # is authoritative; stale ledger role must not override it).
                    terminal.pop(oid, None)
                    claimed.pop(oid, None)
                    roles.pop(oid, None)
                    reopened_at[oid] = rec.get("ts", "")
        except OSError:
            pass
    return LedgerView(terminal, claimed, roles, reopened_at)


# ---------------------------------------------------------------------------
# Startup: seed + compact
# ---------------------------------------------------------------------------

def reconcile_from_plane(workspace_dir: Optional[Path] = None) -> int:
    """Idempotently learn TERMINAL verdicts from the committed archive plane.

    BUG-MSO-2026-0573: the previous one-shot seeding only ever reconciled
    once, the moment a device's ledger was first created — so a device
    whose ledger already existed never learned a terminal verdict another
    device committed to the plane afterwards, and the BUG-0294 veto had
    nothing to enforce against a since-regressed local write (plan
    PLAN-PLN-MSO-2026-0549 §3.1/§3.2). This function is safe to call on
    EVERY dispatcher startup: any order present in ``orders/complete`` or
    ``orders/failed`` that this ledger does not already hold as TERMINAL
    for that exact status is learned via :func:`record_terminal` — which
    means a genuine regression (the plane now shows a status different
    from an already-known TERMINAL COMPLETE) is refused by the same guard
    a live write would hit, not silently accepted just because it arrived
    via reconcile rather than a direct call.

    An order with a REOPENED event newer than the archive file's mtime is
    skipped — the reopen is the more recent, authoritative truth and the
    archive is a stale pre-reopen snapshot the plane has not caught up to
    yet (plan risk table: "reconcile resurrects TERMINAL verdicts an
    operator intentionally cleared with `mso order retry`").

    Returns the number of TERMINAL entries newly recorded this call.
    Best-effort — a scan/read failure just means fewer entries are learned
    this pass; never raises.
    """
    ws = workspace_dir or _workspace_dir()
    view = load_view(ws)
    learned = 0
    for sub, status in (("orders/complete", "COMPLETE"), ("orders/failed", "FAILED")):
        d = ws / sub
        if not d.exists():
            continue
        try:
            files = list(d.glob("*.json"))
        except OSError:
            continue
        for f in files:
            order_id = f.stem
            if view.terminal.get(order_id) == status:
                continue  # already known for this exact status — nothing to learn
            reopened_ts = view.reopened_at.get(order_id)
            if reopened_ts:
                try:
                    reopened_epoch = datetime.fromisoformat(reopened_ts).timestamp()
                    if f.stat().st_mtime <= reopened_epoch:
                        continue  # stale pre-reopen archive; the reopen wins
                except (OSError, ValueError):
                    pass
            if record_terminal(order_id, status, workspace_dir=ws):
                learned += 1
                view.terminal[order_id] = status
    return learned


def seed_if_missing(workspace_dir: Optional[Path] = None) -> bool:
    """Dispatcher-startup ledger maintenance (BUG-MSO-2026-0294 / BUG-MSO-2026-0573).

    Kept as the single dispatcher-startup entrypoint — the ``fleet_runner``
    call site is unchanged — but no longer one-shot: this ALWAYS reconciles
    terminal verdicts from the plane via :func:`reconcile_from_plane`, on
    every call, not only when the ledger file is missing. That is what lets
    a device that pulls another device's completion inherit its terminal
    verdict without ever needing to delete its own ledger.

    Only the crew-claim reconstruction (recovering in-flight ownership
    after a cleared/missing ledger) stays one-shot: a live ledger already
    tracks claims incrementally via :func:`record_claimed`/:func:`record_released`,
    so re-seeding them on every startup would be redundant, not merely safe.

    Returns True if anything new was learned or seeded this call.
    """
    ws = workspace_dir or _workspace_dir()
    path = ledger_path(ws)
    first_run = not path.exists()

    learned = reconcile_from_plane(ws)

    if not first_run:
        return learned > 0

    try:
        from maestro.core.fleet_monitor import is_process_alive, load_json_safe
        crews_dir = ws / "crews"
        if crews_dir.exists():
            for crew_dir in crews_dir.glob("crew*"):
                state = load_json_safe(crew_dir / "state.json") or {}
                if state.get("status") in ("RUNNING", "ACTIVE"):
                    pid = state.get("pid")
                    oid = state.get("orderId")
                    if oid and pid and is_process_alive(pid):
                        try:
                            crew_num = int(crew_dir.name.replace("crew", ""))
                        except ValueError:
                            crew_num = 0
                        record_claimed(oid, state.get("role", ""), crew_num, pid,
                                       workspace_dir=ws)
                        learned += 1
    except Exception:
        pass

    return learned > 0


def compact(workspace_dir: Optional[Path] = None,
            threshold: int = COMPACT_THRESHOLD_LINES) -> bool:
    """Rewrite the ledger as one latest-state line per order when it grows
    past *threshold* lines. Returns True if compacted."""
    ws = workspace_dir or _workspace_dir()
    path = ledger_path(ws)
    if not path.exists():
        return False
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError:
        return False
    if len(lines) <= threshold:
        return False

    with _WRITE_LOCK:
        view = load_view(ws)
        now = datetime.now().isoformat()
        records = [
            {"ts": now, "event": "TERMINAL", "orderId": oid, "status": status}
            for oid, status in sorted(view.terminal.items())
        ] + [
            {"ts": now, "event": "CLAIMED", "orderId": oid, **claim}
            for oid, claim in sorted(view.claimed.items())
        ] + [
            # Preserve role progression for in-flight-but-unclaimed orders
            # (BUG-0248 advance-loss reconciliation needs it across compactions).
            {"ts": now, "event": "ADVANCED", "orderId": oid, "toRole": role}
            for oid, role in sorted(view.roles.items())
            if oid not in view.terminal and oid not in view.claimed
        ]
        try:
            path.write_text("".join(json.dumps(r) + "\n" for r in records),
                            encoding="utf-8")
            return True
        except OSError:
            return False
