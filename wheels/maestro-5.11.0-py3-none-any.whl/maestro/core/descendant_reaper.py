"""BUG-MSO-2026-0500 — reap EVERY descendant of a crew, not just crew.py itself.

A crew's Claude subprocess spawns a deep, unpredictable descendant tree: bash
-> find, dotnet build -> MSBuild worker -> VBCSCompiler (Roslyn compiler
server), shells, whatever the model's tool calls happen to invoke. Two
independent, previously-unaddressed failure modes let members of that tree
outlive the crew that spawned them:

1. ``taskkill /F /T /PID <pid>`` (the existing kill path, see
   ``crew._kill_process_tree``) walks the LIVE parent-child tree at the
   moment it runs. A descendant that has already been reparented — or one
   spawned by MSYS/Git-Bash, whose OS-level parent linkage doesn't always
   match the shell's logical tree — falls outside that walk and survives.
2. If the crew.py process itself dies without ever reaching a kill call
   (external ``taskkill`` by PID only, a hard crash, a machine that killed
   the wrong PID first), nothing ever asks for the tree to be killed at all.

MEASURED IMPACT (2026-08-17): 8 orphaned ``find /`` processes (24.4 CPU-hours
cumulative, one running 8.7 hours) and, once measurement switched from
cumulative to LIVE sampling, 14-15 orphaned dotnet/MSBuild workers plus one
orphaned VBCSCompiler pinning 71% of an 8-core machine.

THE FIX, Windows: every process a Job-Object member later spawns
automatically joins the same job — this membership is transitive and
independent of the live parent-child walk ``taskkill /T`` depends on. Setting
``JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE`` means the OS itself terminates every
member the instant the job's last handle closes, including on an unhandled
crash of the owning process — no Python cleanup code has to run for this to
fire. This is the "structural fix" the BUG-MSO-2026-0302 sweep's docstring
already named as the gap it couldn't close (marker-on-commandline matching
never sees a `find`/`MSBuild` argv, since the marker only ever lived on
crew.py's own command line).

THE FIX, POSIX: ``popen_hidden(..., start_new_session=True)`` already makes
the spawned Claude process a new session/process-group leader, so its pid IS
the pgid. Persisting that pgid at spawn time (rather than looking it up later
via ``os.getpgid(pid)``, which fails once the leader itself has exited) lets
``os.killpg`` reach the whole group at ANY later point, orphaned or not — a
pgid stays live as long as any member remains in it, independent of whether
the original leader is still alive.

Both mechanisms are scoped exactly to processes THIS module explicitly
tracked (a job a crew's own Claude process was assigned to; a pgid a crew's
own Claude process led) — never a blast-radius wider than one crew's own
descendant tree, so an unrelated VS Code / Docker / sibling-fleet process is
never touched (BUG-MSO-2026-0500 AC: "must not touch unrelated user
processes").

Every public function here is best-effort and fails open (returns
None/False/[] rather than raising) — a reaping failure must never block a
crew from doing its actual work.
"""

from __future__ import annotations

import hashlib
import os
from pathlib import Path
from typing import Optional

from maestro.core.proc import run_hidden

IS_WINDOWS = os.name == "nt"

_SPAWN_PGID_FILENAME = "spawn_pgid.txt"

# ---------------------------------------------------------------------------
# Windows Job Object primitives (ctypes only — no pywin32 dependency)
# ---------------------------------------------------------------------------

if IS_WINDOWS:
    import ctypes
    from ctypes import wintypes

    _kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

    _JOB_OBJECT_ALL_ACCESS = 0x1F001F
    _PROCESS_TERMINATE = 0x0001
    _PROCESS_SET_QUOTA = 0x0100
    _JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE = 0x00002000
    _JobObjectExtendedLimitInformation = 9
    _JobObjectBasicProcessIdList = 3
    _MAX_TRACKED_PIDS = 256  # generous cap for QueryInformationJobObject reporting

    class _IO_COUNTERS(ctypes.Structure):
        _fields_ = [
            ("ReadOperationCount", ctypes.c_ulonglong),
            ("WriteOperationCount", ctypes.c_ulonglong),
            ("OtherOperationCount", ctypes.c_ulonglong),
            ("ReadTransferCount", ctypes.c_ulonglong),
            ("WriteTransferCount", ctypes.c_ulonglong),
            ("OtherTransferCount", ctypes.c_ulonglong),
        ]

    class _JOBOBJECT_BASIC_LIMIT_INFORMATION(ctypes.Structure):
        _fields_ = [
            ("PerProcessUserTimeLimit", ctypes.c_int64),
            ("PerJobUserTimeLimit", ctypes.c_int64),
            ("LimitFlags", wintypes.DWORD),
            ("MinimumWorkingSetSize", ctypes.c_size_t),
            ("MaximumWorkingSetSize", ctypes.c_size_t),
            ("ActiveProcessLimit", wintypes.DWORD),
            ("Affinity", ctypes.c_size_t),
            ("PriorityClass", wintypes.DWORD),
            ("SchedulingClass", wintypes.DWORD),
        ]

    class _JOBOBJECT_EXTENDED_LIMIT_INFORMATION(ctypes.Structure):
        _fields_ = [
            ("BasicLimitInformation", _JOBOBJECT_BASIC_LIMIT_INFORMATION),
            ("IoInfo", _IO_COUNTERS),
            ("ProcessMemoryLimit", ctypes.c_size_t),
            ("JobMemoryLimit", ctypes.c_size_t),
            ("PeakProcessMemoryUsed", ctypes.c_size_t),
            ("PeakJobMemoryUsed", ctypes.c_size_t),
        ]

    class _JOBOBJECT_BASIC_PROCESS_ID_LIST(ctypes.Structure):
        _fields_ = [
            ("NumberOfAssignedProcesses", wintypes.DWORD),
            ("NumberOfProcessIdsInList", wintypes.DWORD),
            ("ProcessIdList", ctypes.c_size_t * _MAX_TRACKED_PIDS),
        ]

    _kernel32.CreateJobObjectW.restype = wintypes.HANDLE
    _kernel32.CreateJobObjectW.argtypes = [wintypes.LPVOID, wintypes.LPCWSTR]
    _kernel32.OpenJobObjectW.restype = wintypes.HANDLE
    _kernel32.OpenJobObjectW.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.LPCWSTR]
    _kernel32.SetInformationJobObject.restype = wintypes.BOOL
    _kernel32.SetInformationJobObject.argtypes = [
        wintypes.HANDLE, ctypes.c_int, wintypes.LPVOID, wintypes.DWORD]
    _kernel32.QueryInformationJobObject.restype = wintypes.BOOL
    _kernel32.QueryInformationJobObject.argtypes = [
        wintypes.HANDLE, ctypes.c_int, wintypes.LPVOID, wintypes.DWORD,
        ctypes.POINTER(wintypes.DWORD)]
    _kernel32.AssignProcessToJobObject.restype = wintypes.BOOL
    _kernel32.AssignProcessToJobObject.argtypes = [wintypes.HANDLE, wintypes.HANDLE]
    _kernel32.TerminateJobObject.restype = wintypes.BOOL
    _kernel32.TerminateJobObject.argtypes = [wintypes.HANDLE, wintypes.UINT]
    _kernel32.OpenProcess.restype = wintypes.HANDLE
    _kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    _kernel32.CloseHandle.restype = wintypes.BOOL
    _kernel32.CloseHandle.argtypes = [wintypes.HANDLE]


def _create_kill_on_close_job(name: str):
    """Create (or reopen, if *name* already exists) a Job Object with
    KILL_ON_JOB_CLOSE set. Returns a handle or None on any failure."""
    if not IS_WINDOWS:
        return None
    try:
        handle = _kernel32.CreateJobObjectW(None, name)
        if not handle:
            return None
        info = _JOBOBJECT_EXTENDED_LIMIT_INFORMATION()
        info.BasicLimitInformation.LimitFlags = _JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
        ok = _kernel32.SetInformationJobObject(
            handle, _JobObjectExtendedLimitInformation,
            ctypes.byref(info), ctypes.sizeof(info),
        )
        if not ok:
            _kernel32.CloseHandle(handle)
            return None
        return handle
    except Exception:
        return None


def _open_job(name: str):
    if not IS_WINDOWS:
        return None
    try:
        handle = _kernel32.OpenJobObjectW(_JOB_OBJECT_ALL_ACCESS, False, name)
        return handle or None
    except Exception:
        return None


def _assign_process(job_handle, pid: int) -> bool:
    if not IS_WINDOWS or not job_handle:
        return False
    try:
        proc_handle = _kernel32.OpenProcess(_PROCESS_TERMINATE | _PROCESS_SET_QUOTA, False, pid)
        if not proc_handle:
            return False
        try:
            return bool(_kernel32.AssignProcessToJobObject(job_handle, proc_handle))
        finally:
            _kernel32.CloseHandle(proc_handle)
    except Exception:
        return False


def _query_job_pids(job_handle) -> list:
    """Best-effort snapshot of a job's current member PIDs (for reporting —
    e.g. proving a specific deliberately-orphaned test PID was reaped)."""
    if not IS_WINDOWS or not job_handle:
        return []
    try:
        info = _JOBOBJECT_BASIC_PROCESS_ID_LIST()
        returned = wintypes.DWORD(0)
        ok = _kernel32.QueryInformationJobObject(
            job_handle, _JobObjectBasicProcessIdList,
            ctypes.byref(info), ctypes.sizeof(info), ctypes.byref(returned))
        if not ok:
            return []
        n = min(int(info.NumberOfProcessIdsInList), _MAX_TRACKED_PIDS)
        return [int(info.ProcessIdList[i]) for i in range(n)]
    except Exception:
        return []


def _terminate_job(job_handle, exit_code: int = 1) -> bool:
    if not IS_WINDOWS or not job_handle:
        return False
    try:
        return bool(_kernel32.TerminateJobObject(job_handle, exit_code))
    except Exception:
        return False


def _close_job(job_handle) -> None:
    if not IS_WINDOWS or not job_handle:
        return
    try:
        _kernel32.CloseHandle(job_handle)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Naming — shared between the crew that creates a job and a later `mso
# cleanup` process that needs to reopen the SAME job by name.
# ---------------------------------------------------------------------------

def workspace_marker(artefact_root) -> str:
    """Stable per-workspace hash. Deliberately independent from
    ``fleet_runner._spawn_marker`` (same algorithm, separate implementation)
    so this module has no import dependency on fleet_runner — crew.py, which
    must call this at every Claude invocation, cannot risk a crew.py <->
    fleet_runner.py import cycle."""
    ws = str(artefact_root).lower().encode("utf-8", errors="replace")
    return f"mso-spawn-{hashlib.sha1(ws).hexdigest()[:12]}"


def _job_name(crew_number: int, marker: str) -> str:
    return f"mso-crew-{crew_number}-{marker}"


# ---------------------------------------------------------------------------
# Per-process job cache (Windows) — one job per crew slot, created lazily and
# reused across a crew's iterations so MSBuild/Roslyn node reuse WITHIN one
# order's iteration loop is unaffected; only torn down when the crew's own
# lifecycle ends (see ``reap_crew``).
# ---------------------------------------------------------------------------

_CREW_JOBS: dict = {}  # crew_number -> job handle, this process only


def track_spawn(crew_number: int, crew_dir: Path, pid: int, marker: Optional[str] = None) -> None:
    """Record a freshly spawned Claude subprocess as belonging to
    *crew_number*, so its entire descendant tree can be reaped as a unit
    later regardless of how deep it goes or whether it gets reparented.
    Best-effort: never raises.
    """
    marker = marker or os.environ.get("MAESTRO_SPAWN_MARKER") or "mso-spawn-unset"
    if IS_WINDOWS:
        handle = _CREW_JOBS.get(crew_number)
        if handle is None:
            handle = _create_kill_on_close_job(_job_name(crew_number, marker))
            if handle is not None:
                _CREW_JOBS[crew_number] = handle
        if handle is not None:
            _assign_process(handle, pid)
    else:
        # POSIX: popen_hidden was called with start_new_session=True, so *pid*
        # is the new session/process-group leader — its own pid IS the pgid.
        try:
            crew_dir.mkdir(parents=True, exist_ok=True)
            (crew_dir / _SPAWN_PGID_FILENAME).write_text(str(pid), encoding="utf-8")
        except Exception:
            pass


def reap_crew(crew_number: int, crew_dir: Optional[Path] = None) -> list:
    """Kill every process still tracked under *crew_number*'s descendant
    group, called from WITHIN the crew's own process (uses the in-process job
    cache). Returns the PIDs that were members at the moment of the kill
    (Windows: an accurate snapshot; POSIX: best-effort via pgrep).

    Call this whenever the crew's iteration loop ends for ANY reason
    (COMPLETE / ERROR / TIMEOUT / INTERRUPTED / MAX_ITERATIONS) — no crew
    descendant should outlive the crew that spawned it.
    """
    if IS_WINDOWS:
        handle = _CREW_JOBS.pop(crew_number, None)
        if handle is None:
            return []
        try:
            pids = _query_job_pids(handle)
            _terminate_job(handle)
            return pids
        finally:
            _close_job(handle)
    else:
        return _reap_pgid_file(crew_dir)


def reap_crew_by_name(crew_number: int, crew_dir: Optional[Path], marker: str) -> list:
    """Reap from a DIFFERENT process than the one that spawned the tree —
    e.g. `mso cleanup` reaping a crew that crashed before it ever reached its
    own ``reap_crew`` call. Windows: reopen the named job (the OS already
    auto-killed it via KILL_ON_JOB_CLOSE the instant the owning crew.py
    process's handle closed — including on a crash — so this is normally a
    no-op backstop, not the primary mechanism). POSIX: read the persisted
    pgid file directly.
    """
    if IS_WINDOWS:
        handle = _open_job(_job_name(crew_number, marker))
        if handle is None:
            return []
        try:
            pids = _query_job_pids(handle)
            _terminate_job(handle)
            return pids
        finally:
            _close_job(handle)
    else:
        return _reap_pgid_file(crew_dir)


def _reap_pgid_file(crew_dir: Optional[Path]) -> list:
    if crew_dir is None:
        return []
    pgid_file = crew_dir / _SPAWN_PGID_FILENAME
    if not pgid_file.exists():
        return []
    try:
        pgid = int(pgid_file.read_text(encoding="utf-8").strip())
    except (ValueError, OSError):
        try:
            pgid_file.unlink()
        except Exception:
            pass
        return []

    members = []
    try:
        r = run_hidden(["pgrep", "-g", str(pgid)], capture_output=True, text=True, timeout=10)
        members = [int(ln) for ln in (r.stdout or "").splitlines() if ln.strip().isdigit()]
    except Exception:
        pass

    try:
        os.killpg(pgid, 9)  # SIGKILL — group-wide, independent of leader liveness
    except (ProcessLookupError, PermissionError, OSError):
        pass

    try:
        pgid_file.unlink()
    except Exception:
        pass

    return members


def sweep_all(get_crew_dir, marker: str, max_crews: int = 5) -> dict:
    """`mso cleanup` entry point — reap every crew slot's descendant group
    unconditionally, mirroring how `mso cleanup` already force-kills every
    crew.py PID unconditionally (it is inherently a stop-the-fleet operation,
    not a "just tidy stale junk" one). Returns {crew_number: [pids]} for
    every slot that had something to reap.
    """
    reaped = {}
    for n in range(1, max_crews + 1):
        try:
            crew_dir = get_crew_dir(n)
        except Exception:
            crew_dir = None
        pids = reap_crew_by_name(n, crew_dir, marker)
        if pids:
            reaped[n] = pids
    return reaped
