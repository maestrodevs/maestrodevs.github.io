"""Scan-disagreement snapshot — makes the dispatcher's own view auditable
against what is actually on disk (FTR-MSO-2026-0603 / GH #203).

Why this exists
----------------
GH #203's whole complaint is that the dispatcher's internal dispatch-eligible
set and the on-disk queue disagreed all night, and NOTHING NOTICED: the
heartbeat stayed regular, ``mso status`` (a separate process reading the
queue directly) was right throughout, and only a restart made the dispatcher
right too. INV-MSO-2026-0602 traced the actual mechanism to the order
ledger's live-claim map (``order_ledger.LedgerView.live_claim``): a claim
left unreleased by a requeue path reads as held by a live process for as
long as the writing dispatcher's own PID stays alive, which makes an
on-disk-PENDING order silently invisible to ``scan_all_queues`` with no
lifecycle event of any kind.

``scan_all_queues`` now records, for every PENDING (or defect OPEN) queue
file it sees, either that the order reached the dispatch-eligible set or
exactly which filter excluded it (INV-MSO-2026-0602 §7.1's required
per-order reasons). Most exclusion reasons are legitimate and already have
their own visibility (``DEP_HELD``, the BUG-0263/BUG-0294 WARNs, the skip
list) — this module's job is not to duplicate those, but to make the
DISAGREEMENT itself — an exclusion reason that is NOT one of the known
legitimate filters, i.e. a ledger claim — visible off-process, the same way
``dep_holds.py`` (BUG-MSO-2026-0349) made DEP_HELD visible off-process.

The snapshot lives in the gitignored ``.mso/state/`` control plane (same
rationale as ``order-ledger.jsonl`` and ``dep-holds.json``): runtime truth
no git operation can rewind, read by ``mso doctor``'s
``dispatcher.scan-disagreement`` check running in a SEPARATE process,
possibly with no dispatcher running at all.

File shape::

    {
      "updatedAt": "<iso8601>",
      "naivePending": <int>,           # every PENDING/OPEN queue file seen this scan
      "dispatchEligible": <int>,       # len(dispatchable) this scan
      "exclusions": {"<ORDER-ID>": "<reason>", ...},      # every excluded id, all reasons
      "illegitimate": {"<ORDER-ID>": "<reason>", ...},    # the genuine-disagreement subset
    }

All writes are best-effort — a snapshot failure must never crash the
dispatcher. Readers treat a missing or corrupt file as "no disagreement
recorded"; the lifecycle log's ``SCAN_DISAGREEMENT`` event remains the audit
trail of record for when it happened.
"""

from __future__ import annotations

import json
import os
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional

SCAN_DISAGREEMENT_RELPATH = Path("state") / "scan-disagreement.json"

# Exclusion-reason categories that are EXPECTED, ordinary dispatch holds —
# each already has its own operator-visible signal elsewhere (DEP_HELD,
# BUG-0263/BUG-0294 WARNs, the skip list). A reason string may carry a
# parenthetical detail (e.g. "ledger-claim(pid=1234)") — only the part
# before "(" is the category.
LEGITIMATE_EXCLUSION_CATEGORIES = frozenset({
    "skipped",
    "network-backoff",
    "archived-terminal",
    "ledger-terminal",
    "live-crew-inflight",
    "circular-dep",
    "escalation-blocked",
    "dep-held",
    "mid-transition",
    "role-gate",
})


def exclusion_category(reason: str) -> str:
    """The bare category of an exclusion reason (strips any "(...)" detail)."""
    return reason.split("(", 1)[0]


def is_legitimate_exclusion(reason: str) -> bool:
    return exclusion_category(reason) in LEGITIMATE_EXCLUSION_CATEGORIES


def _workspace_dir() -> Path:
    from maestro.workspace import get_artefact_root
    return get_artefact_root()


def scan_disagreement_path(workspace_dir: Optional[Path] = None) -> Path:
    return (workspace_dir or _workspace_dir()) / SCAN_DISAGREEMENT_RELPATH


def write_scan_disagreement_state(
    naive_pending: int,
    dispatch_eligible: int,
    exclusions: Dict[str, str],
    workspace_dir: Optional[Path] = None,
) -> None:
    """Snapshot the current tick's exclusion map. Atomic (write-temp +
    replace) so a concurrent reader never sees a torn file. Never raises."""
    try:
        illegitimate = {
            oid: reason for oid, reason in exclusions.items()
            if not is_legitimate_exclusion(reason)
        }
        snapshot = {
            "updatedAt": datetime.now().isoformat(),
            "naivePending": naive_pending,
            "dispatchEligible": dispatch_eligible,
            "exclusions": dict(exclusions),
            "illegitimate": illegitimate,
        }
        path = scan_disagreement_path(workspace_dir)
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(snapshot, indent=2), encoding="utf-8")
        os.replace(str(tmp), str(path))
    except Exception:
        pass  # best-effort: the lifecycle log remains the audit trail


def read_scan_disagreement_state(workspace_dir: Optional[Path] = None) -> Dict[str, Any]:
    """Return the last-written snapshot, ``{}`` if absent/unreadable."""
    try:
        path = scan_disagreement_path(workspace_dir)
        if not path.exists():
            return {}
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}
