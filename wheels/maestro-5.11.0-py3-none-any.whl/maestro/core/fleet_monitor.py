#!/usr/bin/env python3
# Maestro Monitor v5.0
"""
Maestro Monitor v5.0 - Squad Monitor Dashboard

Single window shows: dispatcher status, voyage progress, crew status,
queue depth, lifecycle events — rendered with `rich` (Abyss & Ember brand
palette, indentation-based layout, alt-buffer live refresh).

This module is the ENTRY POINT and DATA LAYER. The pure render layer lives
in maestro/core/dashboard.py — `build_dashboard_state()` below maps the
workspace state files into a `DashboardState`, which `render_dashboard()`
turns into terminal output.

Features:
- PID lock prevents duplicate instances (.mso/monitor.pid)
- Auto-detects dispatcher via .mso/dispatcher.pid
- Reads lifecycle events from .mso/logs/lifecycle.log
- ctypes-based process checking (works from cmd.exe AND Git Bash)
- Orphan detection: marks RUNNING crews as CRASHED if PID is dead
- Heuristic ETAs (avg iteration time × remaining iterations)
- Token/cost per crew from .mso/usage/orders/
- v5.0: rich-based renderer replaces the v4.0 ANSI box-drawing layout
"""

import argparse
import atexit
import json
import os
import re
import sys
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from maestro.personas import current_persona  # noqa: E402 — must follow stdlib imports
from maestro.core.dispatcher_heartbeat import (  # noqa: E402
    DISPATCHER_HEARTBEAT_STALE_SECONDS as _DISPATCHER_HEARTBEAT_STALE_SECONDS,
    dispatcher_heartbeat_age_seconds as _dispatcher_heartbeat_age_seconds,
    last_dispatcher_heartbeat_line_age as _last_dispatcher_heartbeat_line_age,  # noqa: F401 — re-exported for callers/tests that read the dispatcher's own HEARTBEAT-line signal directly
)

# Fix Windows console encoding (rich handles ANSI/VT enablement itself)
if sys.platform == 'win32':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except:
        pass

# Defaults
DEFAULT_MAX_CREWS = 5
DEFAULT_ITERATION_TIMEOUT_MINUTES = 30

# Squad names and role-model labels are persona-driven — see maestro/core_constants.py
from maestro.core_constants import get_squad_name, get_role_model, get_model_label  # noqa: E402
from maestro.workspace import get_artefact_root as _resolve_artefact_root  # noqa: E402
from maestro.core.dep_holds import read_dep_holds  # noqa: E402 — BUG-MSO-2026-0349
from maestro.core.skip_list import read_skipped_order_ids  # noqa: E402 — BUG-MSO-2026-0451
from maestro.errors import run_cli  # noqa: E402
from maestro.core.dashboard import (  # noqa: E402
    Approval,
    Crew,
    DashboardState,
    Escalation,
    PersonaLabels,
    Voyage,
    render_dashboard,
)


# =============================================================================
# CORE HELPERS
# =============================================================================

def get_workspace_dir() -> Path:
    """Resolve the ARTEFACT plane the monitor reads (BUG-MSO-2026-0425).

    The monitor reads artefact state (queues, crews, logs, voyages, usage,
    config, state). In solo/shared artefact mode those live in the artefact
    repo, NOT the product repo's frozen ``.mso`` — so this resolves via
    :func:`maestro.workspace.get_artefact_root` (honours the ``artefacts``
    pointer). In embedded mode it is identical to the old walk-up resolver, so
    behaviour is byte-identical there.

    Kept under the name ``get_workspace_dir`` because it is the monitor's single
    resolution seam: the dispatcher-spawned monitor sets ``MAESTRO_DIR`` (BUG-0407)
    and the test-suite monkeypatches ``fleet_monitor.get_workspace_dir`` to point
    at a temp workspace — both continue to work through this one function.
    """
    return _resolve_artefact_root()


def resolve_version() -> str:
    """Resolve the package version from the installed maestro package or __init__.py."""
    try:
        import maestro
        return maestro.__version__
    except ImportError:
        pass

    script_path = Path(__file__).resolve()
    for candidate in [
        script_path.parent.parent.parent / "maestro" / "__init__.py",
        script_path.parent.parent / "maestro" / "__init__.py",
    ]:
        if candidate.exists():
            try:
                content = candidate.read_text(encoding="utf-8")
                m = re.search(r'^__version__\s*=\s*["\']([^"\']+)["\']', content, re.MULTILINE)
                if m:
                    return m.group(1)
            except Exception:
                pass

    return "unknown"


def get_base_dir() -> Path:
    # BUG-MSO-2026-0425: parent of the ARTEFACT plane (the repo that carries the
    # .mso/ artefacts), used only to render paths relative to it. In solo/shared
    # mode that is the artefact repo, not the product repo; in embedded mode both
    # coincide, so this is byte-identical there.
    return get_workspace_dir().parent


def load_json_safe(path: Path) -> Optional[Dict]:
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except:
        return None


def get_settings(workspace_dir: Optional[Path] = None) -> Dict:
    config_file = (workspace_dir or get_workspace_dir()) / "config" / "fleet-settings.json"
    settings = load_json_safe(config_file) or {}
    return {
        "maxCrews": settings.get("maxCrews", DEFAULT_MAX_CREWS),
        "iterationTimeoutMinutes": settings.get("iterationTimeoutMinutes", DEFAULT_ITERATION_TIMEOUT_MINUTES)
    }


def format_duration(seconds: float) -> str:
    if seconds < 0:
        return "--:--"
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = int(seconds % 60)
    if hours > 0:
        return f"{hours:02d}:{minutes:02d}:{secs:02d}"
    return f"{minutes:02d}:{secs:02d}"


def get_elapsed_seconds(start_time_str: str) -> float:
    try:
        if 'T' in start_time_str:
            start = datetime.fromisoformat(start_time_str.replace('Z', '+00:00'))
        else:
            start = datetime.strptime(start_time_str, '%Y-%m-%d')
        elapsed = datetime.now() - start.replace(tzinfo=None)
        return elapsed.total_seconds()
    except:
        return 0


# =============================================================================
# PROCESS DETECTION (ctypes - reliable on Windows)
# =============================================================================

def is_process_alive(pid: int) -> bool:
    """Check if a process with the given PID is still running.

    Uses ctypes OpenProcess on Windows for reliability (works from cmd.exe AND Git Bash).
    """
    if not pid or pid <= 0:
        return False
    try:
        if os.name == 'nt':
            import ctypes
            PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            STILL_ACTIVE = 259
            kernel32 = ctypes.windll.kernel32
            handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
            if handle == 0:
                return False
            try:
                exit_code = ctypes.c_ulong()
                if kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code)):
                    return exit_code.value == STILL_ACTIVE
                return False
            finally:
                kernel32.CloseHandle(handle)
        else:
            os.kill(pid, 0)
            return True
    except (ProcessLookupError, PermissionError, OSError):
        return False


# =============================================================================
# MONITOR PID LOCK
# =============================================================================

def check_monitor_lock() -> bool:
    """Check if another monitor instance is running. Returns True if lock acquired."""
    lock_file = get_workspace_dir() / "monitor.pid"
    if lock_file.exists():
        try:
            old_pid = int(lock_file.read_text(encoding='utf-8').strip())
            if is_process_alive(old_pid) and old_pid != os.getpid():
                return False  # Another monitor is running
        except:
            pass  # Stale/corrupt file, proceed

    # Acquire lock
    lock_file.parent.mkdir(parents=True, exist_ok=True)
    lock_file.write_text(str(os.getpid()), encoding='utf-8')
    return True


def release_monitor_lock():
    """Release the monitor PID lock."""
    lock_file = get_workspace_dir() / "monitor.pid"
    try:
        if lock_file.exists():
            stored_pid = int(lock_file.read_text(encoding='utf-8').strip())
            if stored_pid == os.getpid():
                lock_file.unlink()
    except:
        pass


# =============================================================================
# DATA GATHERING
# =============================================================================

# BUG-MSO-2026-0541: heartbeat staleness ceiling, matching the value already
# established for the Hub's dispatcher-liveness check (hub/aggregator.py's
# _HEARTBEAT_STALENESS_SECONDS, BUG-MSO-2026-0405).
#
# BUG-MSO-2026-0576: fleet-runner-state.json's "timestamp" field is NOT a
# heartbeat — the dispatcher only rewrites it when a crew/state ASSIGNMENT
# CHANGES (dispatch, completion, requeue...), not on a cadence. A fleet with
# 3 crews steadily grinding through long orders can leave it untouched for
# 30+ minutes while perfectly healthy — that read as WEDGED at critical
# severity, the patrol's only critical check, on the LEAD patrol's first real
# run. The dispatcher's actual cadence-guaranteed signal is the HEARTBEAT
# line it appends to logs/lifecycle.log every MAESTRO_HEARTBEAT_SECONDS
# (default 120s, fleet_runner.py's main loop) regardless of crew activity.
#
# BUG-MSO-2026-0581: reading that second signal from lifecycle.log's file
# MTIME (the original 0576 fix) is wrong — the log is MULTI-WRITER (crews,
# `mso voyage reconcile`, the Hub's sweep, the resident LEAD daemon), so its
# mtime stays warm even while the dispatcher itself is wedged. The fix reads
# the timestamp OF THE DISPATCHER'S OWN LAST HEARTBEAT LINE instead — a
# signal only the dispatcher's main loop can refresh.
#
# BUG-MSO-2026-0595: this whole computation — plus the Hub's copy of it — now
# lives in one place, maestro.core.dispatcher_heartbeat, imported above. See
# that module for the two signals' combination and the malformed-timestamp /
# UnicodeDecodeError handling.
def get_dispatcher_status(workspace_dir: Optional[Path] = None) -> Dict:
    """Get dispatcher status from PID file and fleet state.

    BUG-MSO-2026-0541: a dispatcher whose PID is alive but whose heartbeat has
    gone stale is WEDGED, not RUNNING — it held a live process while its tick
    loop was stuck, and that read as healthy for three ticks on 2026-08-17
    before anyone noticed. ``state`` is one of "RUNNING" / "WEDGED" /
    "STOPPED"; ``running`` (bool) stays True only for "RUNNING", so existing
    callers that just want a yes/no answer get the corrected verdict too. A
    dispatcher that hasn't written its first heartbeat yet (no timestamp on
    disk, no lifecycle.log yet) is treated as RUNNING, not WEDGED — that's a
    fresh start, not the "alive but stuck" failure this guards against.

    BUG-MSO-2026-0576/0581: heartbeat age is the freshest of two independent
    signals — see the module comment above and
    ``maestro.core.dispatcher_heartbeat`` for why a state-change marker or a
    shared log's mtime alone each false-positive in opposite directions.

    *workspace_dir* defaults to ``get_workspace_dir()``; passing it explicitly
    (FTR-MSO-2026-0531) lets a caller such as `maestro.patrol` read a given
    artefact root without depending on the ambient ``MAESTRO_DIR``/cwd
    resolution — mirrors the existing :func:`get_pending_review_items`
    FTR-MSO-2026-0487 pattern.
    """
    admiralty_dir = workspace_dir or get_workspace_dir()
    result = {
        "running": False,
        "state": "STOPPED",
        "pid": None,
        "heartbeatAgeSeconds": None,
        "maxCrews": 5,
        "staggerDelay": 30,
    }

    pid_file = admiralty_dir / "dispatcher.pid"
    pid_alive = False
    if pid_file.exists():
        try:
            pid = int(pid_file.read_text(encoding='utf-8').strip())
            if is_process_alive(pid):
                pid_alive = True
                result["pid"] = pid
        except:
            pass

    # Heartbeat age (seconds) — exposed as a NUMBER, never collapsed to a
    # bool before the liveness verdict is derived from it.
    heartbeat_age = _dispatcher_heartbeat_age_seconds(admiralty_dir)
    result["heartbeatAgeSeconds"] = heartbeat_age

    heartbeat_stale = heartbeat_age is not None and heartbeat_age > _DISPATCHER_HEARTBEAT_STALE_SECONDS

    if pid_alive and heartbeat_stale:
        result["state"] = "WEDGED"
    elif pid_alive:
        result["state"] = "RUNNING"
    else:
        result["state"] = "STOPPED"
    result["running"] = result["state"] == "RUNNING"

    return result


def get_crew_activity(crew_num: int) -> Dict:
    """Get detailed crew activity info from state and progress files."""
    crews_dir = get_workspace_dir() / "crews" / f"crew{crew_num}"
    state_file = crews_dir / "state.json"
    progress_file = crews_dir / "progress.md"

    state = load_json_safe(state_file)
    if not state:
        return {"status": "IDLE", "activity": "-", "pid": None, "role": "-", "order": "-"}

    # Read activity (priority order). FTR-MSO-2026-0310: state["activity"] is
    # the live, stream-derived action the crew loop writes on every turn —
    # always present (no dependency on Claude Code posttool hooks firing in the
    # crew environment, which is why a busy crew used to fall through to
    # progress.md's "(none yet)"). Prefer it; keep the hook/progress sources as
    # fallbacks for older crews / external hook integrations.
    activity = "Working..."
    activity_file = crews_dir / "activity.txt"
    activity_jsonl = crews_dir / "activity.jsonl"

    state_activity = (state.get("activity") or "").strip()
    if state_activity:
        activity = state_activity
    elif activity_file.exists():
        try:
            raw = activity_file.read_text(encoding='utf-8').strip()
            if raw:
                # Calculate time since last activity from file mtime
                mtime = activity_file.stat().st_mtime
                age_secs = int(time.time() - mtime)
                if age_secs < 60:
                    age_str = f"{age_secs}s"
                elif age_secs < 3600:
                    age_str = f"{age_secs // 60}m"
                else:
                    age_str = f"{age_secs // 3600}h"
                activity = f"{raw} ({age_str} ago)"
                if len(activity) > 50:
                    activity = activity[:47] + "..."
        except Exception:
            pass
    elif activity_jsonl.exists():
        try:
            content = activity_jsonl.read_text(encoding='utf-8').strip()
            lines = content.split('\n')
            if lines:
                last = json.loads(lines[-1])
                action = last.get("action", "Working")
                target = last.get("target", "")
                activity = f"{action} {target}"
                if len(activity) > 50:
                    activity = activity[:47] + "..."
        except Exception:
            pass
    elif progress_file.exists():
        # Legacy fallback: read progress.md
        try:
            content = progress_file.read_text(encoding='utf-8')
            plines = content.split('\n')
            for line in reversed(plines):
                line = line.strip()
                if line and not line.startswith('#') and not line.startswith('<') and len(line) > 3:
                    if line.startswith('- ['):
                        line = line[6:]
                    activity = line[:50] + "..." if len(line) > 50 else line
                    break
        except Exception:
            pass

    # v8.0: Read ralph-state.md for live iteration count (updated by stop hook)
    # Falls back to state.json iteration if ralph-state.md doesn't exist (pre-v8.0)
    iteration = state.get("iteration", 0)
    ralph_status = None
    ralph_state_file = crews_dir / "ralph-state.md"
    if ralph_state_file.exists():
        try:
            ralph_content = ralph_state_file.read_text(encoding='utf-8')
            iter_match = re.search(r'^iteration:\s*(\d+)', ralph_content, re.MULTILINE)
            if iter_match:
                iteration = int(iter_match.group(1))
            status_match = re.search(r'^status:\s*"?(\w+)"?', ralph_content, re.MULTILINE)
            if status_match:
                ralph_status = status_match.group(1)
        except Exception:
            pass

    return {
        "status": state.get("status", "UNKNOWN"),
        "role": state.get("role", "-"),
        "order": state.get("orderId", "-"),
        "iteration": iteration,
        "maxIterations": state.get("maxIterations", 0),
        "liveTurn": state.get("liveTurn", 0),       # FTR-MSO-2026-0227
        "maxTurns": state.get("maxTurns", 0),        # FTR-MSO-2026-0227
        "subagentCount": state.get("subagentCount", 0),  # FTR-MSO-2026-0227
        "startTime": state.get("startTime", ""),
        "endTime": state.get("endTime", ""),
        "activity": activity,
        "filesChanged": state.get("filesChangedTotal", 0),
        "pid": state.get("pid"),
        "timeout": state.get("timeoutMinutes", DEFAULT_ITERATION_TIMEOUT_MINUTES),
        "ralphStatus": ralph_status
    }


def get_queue_counts() -> Dict[str, Dict]:
    """Get counts of items in each queue.

    BUG-MSO-2026-0349: items the dispatcher is holding on unmet dependencies
    (per the .mso/state/dep-holds.json snapshot) are split out of the pending
    count into "held" / "held_details" so the dashboard can distinguish
    blocked work from dispatchable work. Cross-checked against the files
    actually present, so a stale snapshot entry for a departed order is inert.

    BUG-MSO-2026-0451: operator-skipped orders (``mso order skip``) are ALSO
    excluded here — they were previously invisible to this function entirely,
    so a skipped order kept a status of "PENDING" on disk and counted as
    dispatchable work in mso status while the dispatcher's own scan silently
    dropped it (GitHub #202 re-verification: "QUEUE 2 pending" when the
    dispatcher's heartbeat said pending=0). Reuses the same skip-list reader
    the dispatcher itself uses (maestro.core.skip_list), not a re-derived rule.
    """
    queues_dir = get_workspace_dir() / "queues"
    dep_holds = read_dep_holds()
    try:
        skipped_ids = read_skipped_order_ids(get_workspace_dir())
    except Exception:
        skipped_ids = set()

    def _mark_held(info: Dict, item_id: str) -> bool:
        hold = dep_holds.get(item_id)
        if hold is not None:
            info["held"] += 1
            info["held_details"][item_id] = ", ".join(hold.get("waitingOn", [])) or "unknown"
            return True
        if item_id in skipped_ids:
            info["held"] += 1
            info["held_details"][item_id] = "operator-skipped (mso order skip)"
            return True
        return False

    queue_info = {
        "requests": {"count": 0, "path": "requests", "details": {}},
        "orders": {"count": 0, "path": "orders", "details": {}},
        "explicit": {"count": 0, "path": "explicit", "details": {}},
        "high-level": {"count": 0, "path": "high-level", "details": {}},
        "defects": {"count": 0, "path": "defects", "details": {}},
        "security": {"count": 0, "path": "security", "details": {}},
        "bugs": {"count": 0, "path": "bugs", "details": {}},
        "breakdown": {"count": 0, "path": "breakdown", "details": {}},
        "escalations": {"count": 0, "path": "escalations", "details": {}},
    }
    for info in queue_info.values():
        info["held"] = 0
        info["held_details"] = {}

    for queue_name, info in queue_info.items():
        queue_path = queues_dir / info["path"]
        if queue_path.exists():
            if queue_name == "requests":
                for subdir in ["investigation", "qa", "documentation", "security-scan", "planning"]:
                    subpath = queue_path / subdir
                    if subpath.exists():
                        count = 0
                        for json_file in subpath.glob("*.json"):
                            if _mark_held(info, json_file.stem):
                                continue
                            count += 1
                        if count > 0:
                            info["details"][subdir] = count
                            info["count"] += count
            elif queue_name == "orders":
                # Count only PENDING orders (not IN_PROGRESS which are already dispatched)
                for json_file in queue_path.glob("*.json"):
                    try:
                        data = json.loads(json_file.read_text(encoding='utf-8'))
                        status = data.get("status", "PENDING")
                        if status == "PENDING":
                            order_id = data.get("id") or data.get("orderId") or json_file.stem
                            if _mark_held(info, order_id):
                                continue
                            info["count"] += 1
                            # v8.8: Resolve role from targetRole, role, or roleSequence[0]
                            otype = data.get("targetRole") or data.get("role") or ""
                            if not otype:
                                seq = data.get("roleSequence", [])
                                otype = seq[0] if seq else "UNK"
                            info["details"][otype] = info["details"].get(otype, 0) + 1
                    except:
                        info["count"] += 1  # Count unreadable files as pending
            else:
                for json_file in queue_path.glob("*.json"):
                    if _mark_held(info, json_file.stem):
                        continue
                    info["count"] += 1

    return queue_info


def get_held_breakdown(workspace_dir: Optional[Path] = None) -> Dict[str, int]:
    """Named counts across every non-dispatchable category (BUG-MSO-2026-0451).

    Mirrors the exact split the dispatcher already logs on IDLE_REAP
    ("review-gated=N, dep-held=N, stranded=N, skipped=N") so an operator can
    see WHY the fleet looks idle without grepping lifecycle.log. Each count
    reuses the dispatcher's own categorisation rather than re-deriving the
    dispatch-eligibility rules here:

      - review-gated: orders parked in queues/review/ (NAV_REVIEW_PENDING) —
        same directory scan_review_queue() and get_pending_review_items()
        already both read.
      - dep-held: the .mso/state/dep-holds.json snapshot (BUG-0349).
      - skipped: the operator skip list (maestro.core.skip_list).
      - stranded: orders in CONVERGENCE_FAILED / BLOCKED / AUTO_SERIALIZE /
        ESCALATED limbo, computed by calling fleet_runner's own
        voyages_outstanding_work() directly — that reconciliation (ledger +
        voyage manifests + queue-file statuses) is too involved to safely
        re-derive here without risking drift.

    FTR-MSO-2026-0487: *workspace_dir* parameterises the whole computation —
    previously every branch bottomed out at the module-global
    ``get_workspace_dir()`` (including transitively, via
    ``voyages_outstanding_work()``'s own ``get_artefact_root()``), so this
    function silently returned whichever workspace the CALLING PROCESS
    happened to have resolved. That is fine for `mso status` (one process,
    one workspace) but wrong for a multi-workspace poller (the Hub) serving
    N workspaces from a single process — calling it there would return the
    same workspace's counts for every entry, wrong per-workspace with no
    error (PLAN-PLN-MSO-2026-0468 §3.3). Omitting *workspace_dir* preserves
    the exact zero-arg CLI behaviour byte-for-byte. Passing it retargets
    ``voyages_outstanding_work()`` via fleet_runner's own
    ``_MAESTRO_DIR_OVERRIDE`` escape hatch — the same mechanism
    ``mso order retry`` / ``mso voyage reconcile`` already use to run a
    global-resolving fleet_runner call against an explicit workspace
    (maestro/cli.py) — restored in a ``finally`` so it never leaks.
    """
    ws = workspace_dir or get_workspace_dir()
    review_gated = len(get_pending_review_items(ws))
    dep_held = len(read_dep_holds(ws))
    try:
        skipped = len(read_skipped_order_ids(ws))
    except Exception:
        skipped = 0
    stranded = 0
    try:
        from maestro.core.fleet_runner import voyages_outstanding_work
        if workspace_dir is None:
            stranded = sum(len(oids) for _, oids in voyages_outstanding_work())
        else:
            import maestro.core.fleet_runner as _fr
            _old_override = _fr._MAESTRO_DIR_OVERRIDE
            _fr._MAESTRO_DIR_OVERRIDE = ws
            try:
                stranded = sum(len(oids) for _, oids in voyages_outstanding_work())
            finally:
                _fr._MAESTRO_DIR_OVERRIDE = _old_override
    except Exception:
        stranded = 0
    return {
        "review_gated": review_gated,
        "dep_held": dep_held,
        "stranded": stranded,
        "skipped": skipped,
    }


def format_held_breakdown(breakdown: Dict[str, int]) -> str:
    """Render get_held_breakdown()'s counts as 'review-gated N · dep-held N ·
    stranded N · skipped N', or '' if nothing is held anywhere."""
    if not any(breakdown.values()):
        return ""
    return (
        f"review-gated {breakdown['review_gated']} · "
        f"dep-held {breakdown['dep_held']} · "
        f"stranded {breakdown['stranded']} · "
        f"skipped {breakdown['skipped']}"
    )


def get_lifecycle_log(max_lines: int = 10) -> List[str]:
    """Read recent lifecycle events from the log file."""
    log_file = get_workspace_dir() / "logs" / "lifecycle.log"
    if not log_file.exists():
        return []
    try:
        lines = log_file.read_text(encoding='utf-8').strip().split('\n')
        # Return last N non-empty lines
        return [l for l in lines if l.strip()][-max_lines:]
    except:
        return []


def _read_md_frontmatter(path: Path) -> dict:
    """Read YAML-style frontmatter from the first 15 lines of a .md file.

    Looks for content between --- markers at the top of the file.
    Returns a dict of key-value pairs, or {} if no frontmatter found.
    """
    result = {}
    try:
        lines = path.read_text(encoding='utf-8').splitlines()[:15]
        if not lines or lines[0].strip() != '---':
            return result
        for line in lines[1:]:
            stripped = line.strip()
            if stripped == '---':
                break
            if ':' in stripped:
                key, _, value = stripped.partition(':')
                result[key.strip()] = value.strip().strip('"\'')
    except Exception:
        pass
    return result


def get_pending_review_items(workspace_dir: Optional[Path] = None) -> list:
    """Scan .mso/queues/review/ for orders awaiting human review.

    *workspace_dir* defaults to ``get_workspace_dir()`` (FTR-MSO-2026-0487) —
    see :func:`get_held_breakdown` for why an explicit path matters for a
    multi-workspace caller.

    Returns a list of dicts: { order_id, voyage_id, age }
    """
    admiralty_dir = workspace_dir or get_workspace_dir()
    items = []
    review_dir = admiralty_dir / "queues" / "review"
    if not review_dir.exists():
        return items
    for json_file in sorted(review_dir.glob("*.json")):
        try:
            data = json.loads(json_file.read_text(encoding='utf-8'))
            paused_at = data.get("navReviewPausedAt", "")
            age_str = "--"
            if paused_at:
                age_secs = get_elapsed_seconds(paused_at)
                if age_secs > 0:
                    age_str = format_duration(age_secs)
            items.append({
                "order_id": data.get("id", json_file.stem),
                "voyage_id": data.get("voyageId", "?"),
                "age": age_str,
            })
        except Exception:
            pass
    return items


def get_approval_items(workspace_dir: Optional[Path] = None) -> list:
    """Scan voyages/active, plans, and requirements for awaiting-approval items.

    *workspace_dir* defaults to ``get_workspace_dir()`` (mirrors the
    :func:`get_pending_review_items` FTR-MSO-2026-0487 pattern) — an explicit
    path lets a caller like `maestro.patrol` read a given artefact root
    without depending on the ambient ``MAESTRO_DIR``/cwd resolution, which
    matters once a single process scans more than one project.

    Returns a list of dicts:
      { type: 'VOYAGE'|'PLAN'|'REQ', id, project, title, note, path }
    """
    admiralty_dir = workspace_dir or get_workspace_dir()
    base_dir = admiralty_dir.parent if workspace_dir else get_base_dir()
    items = []

    # Voyages
    voyages_dir = admiralty_dir / "voyages" / "active"
    if voyages_dir.exists():
        for json_file in sorted(voyages_dir.glob("*.json")):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                if data.get("status") == "AWAITING_APPROVAL":
                    try:
                        rel_path = json_file.relative_to(base_dir).as_posix()
                    except ValueError:
                        rel_path = str(json_file)
                    items.append({
                        "type": "VOYAGE",
                        "id": data.get("id", json_file.stem),
                        "project": data.get("project", "?"),
                        "title": data.get("title", data.get("name", "")),
                        "note": data.get("approvalNote", ""),
                        "path": rel_path,
                    })
            except Exception:
                pass

    # Plans
    plans_dir = admiralty_dir / "plans"
    if plans_dir.exists():
        for md_file in sorted(plans_dir.glob("*.md")):
            fm = _read_md_frontmatter(md_file)
            if fm.get("status", "").lower() == "awaiting-approval":
                try:
                    rel_path = md_file.relative_to(base_dir).as_posix()
                except ValueError:
                    rel_path = str(md_file)
                items.append({
                    "type": "PLAN",
                    "id": md_file.name,
                    "project": fm.get("project", "?"),
                    "title": fm.get("title", ""),
                    "note": fm.get("approvalNote", ""),
                    "path": rel_path,
                })

    # Requirements
    reqs_dir = admiralty_dir / "requirements"
    if reqs_dir.exists():
        for md_file in sorted(reqs_dir.glob("*.md")):
            fm = _read_md_frontmatter(md_file)
            if fm.get("status", "").lower() == "awaiting-approval":
                try:
                    rel_path = md_file.relative_to(base_dir).as_posix()
                except ValueError:
                    rel_path = str(md_file)
                items.append({
                    "type": "REQ",
                    "id": md_file.name,
                    "project": fm.get("project", "?"),
                    "title": fm.get("title", ""),
                    "note": fm.get("approvalNote", ""),
                    "path": rel_path,
                })

    # Sort by project acronym, then by type
    items.sort(key=lambda x: (x["project"], x["type"], x["id"]))
    return items


def cleanup_orphaned_crew(crew_num: int):
    """Mark a RUNNING crew as CRASHED if its process is dead."""
    state_file = get_workspace_dir() / "crews" / f"crew{crew_num}" / "state.json"
    try:
        state = load_json_safe(state_file)
        if state:
            state["status"] = "CRASHED"
            state_file.write_text(json.dumps(state, indent=2), encoding='utf-8')
    except:
        pass


# =============================================================================
# DASHBOARD DISPLAY
# =============================================================================

def _get_bridge_notifier():
    """Lazy-load the BridgeNotifier singleton (None if unavailable).

    BUG-MSO-2026-0542: the import used to name a non-existent top-level
    ``bridge_notifier`` module (the real module is ``maestro.core.bridge_notifier``),
    so construction always raised and the notification path was silently inert.
    A construction failure is now reported via a lifecycle WARN instead of being
    swallowed, so a *future* break in this path (e.g. a bad bridge-settings.json)
    is visible rather than repeating this bug's own failure mode.
    """
    if not hasattr(_get_bridge_notifier, "_instance"):
        try:
            from maestro.core.bridge_notifier import BridgeNotifier
            _get_bridge_notifier._instance = BridgeNotifier(get_workspace_dir())
        except Exception as e:
            _get_bridge_notifier._instance = None
            try:
                from maestro.core.fleet_runner import write_lifecycle_event
                write_lifecycle_event(
                    "WARN",
                    f"_get_bridge_notifier: BridgeNotifier construction failed ({e}) — "
                    "approval/escalation Slack notifications are disabled",
                )
            except Exception:
                pass
    return _get_bridge_notifier._instance


_ETA_MIN_TURNS = 3  # need a few turns before the per-turn rate is meaningful


def _crew_eta_seconds(elapsed_sec: float, live_turn: int, max_turns: int) -> float:
    """Heuristic crew ETA from TURN burn-rate within the current iteration.

    FTR-MSO-2026-0310: the old heuristic projected to the Ralph iteration
    ceiling (`max_iterations`, default 25) — but that is a safety cap, not an
    expected count (most orders finish in 1–3 iterations), so one slow first
    iteration extrapolated to multi-hour ETAs. ETA is now the time to exhaust
    the remaining turns of THIS iteration at the observed per-turn rate, which
    tracks the same signal the progress bar shows (`live_turn / max_turns`).

    Returns -1 (sentinel → rendered as --:--) until at least `_ETA_MIN_TURNS`
    turns have streamed (rate not yet meaningful) or the turn cap is unknown.
    """
    if live_turn >= _ETA_MIN_TURNS and max_turns > 0:
        remaining = max_turns - live_turn
        if remaining <= 0:
            return 0
        return round((elapsed_sec / live_turn) * remaining)
    return -1


def _order_usage(order_id: str) -> Tuple[int, float]:
    """Read (total_tokens, estimated_cost_usd) from the order's usage file."""
    if not order_id or order_id == "-":
        return 0, 0.0
    usage = load_json_safe(
        get_workspace_dir() / "usage" / "orders" / f"{order_id}.json") or {}
    return usage.get("total_tokens", 0) or 0, usage.get("estimated_cost_usd", 0.0) or 0.0


def _workspace_spend() -> float:
    """Sum estimated_cost_usd across all order usage files."""
    usage_dir = get_workspace_dir() / "usage" / "orders"
    total = 0.0
    if usage_dir.exists():
        for f in usage_dir.glob("*.json"):
            data = load_json_safe(f) or {}
            try:
                total += float(data.get("estimated_cost_usd", 0) or 0)
            except (TypeError, ValueError):
                pass
    return round(total, 2)


def _detect_billing() -> Tuple[str, float]:
    """Detect billing mode: workspace.json billing block > API-key env > max plan.

    Returns (mode, budget_usd) where mode is "max" or "api".
    """
    ws = load_json_safe(get_workspace_dir() / "config" / "workspace.json") or {}
    billing = ws.get("billing") or {}
    mode = billing.get("mode")
    if mode in ("api", "max"):
        try:
            budget = float(billing.get("budgetTotal", 0) or 0)
        except (TypeError, ValueError):
            budget = 0.0
        return mode, budget
    if os.environ.get("ANTHROPIC_API_KEY"):
        return "api", 0.0
    return "max", 0.0


def _crew_duration_label(crew: Dict) -> str:
    """COMPLETE-crew wall-clock duration from state.json start/end times."""
    if crew.get("endTime") and crew.get("startTime"):
        try:
            start = datetime.fromisoformat(crew["startTime"])
            end = datetime.fromisoformat(crew["endTime"])
            return format_duration((end - start).total_seconds())
        except Exception:
            pass
    return ""


def _effective_role_model_label(role: str, order_id: str) -> str:
    """Resolve the model label a crew slot is ACTUALLY dispatched against.

    BUG-MSO-2026-0447: the dashboard used to read only the built-in
    DEFAULT_ROLE_MODELS table (get_role_model), so a workspace overriding a
    role via .mso/config/role-models.json or MAESTRO_MODEL_<ROLE> saw the
    wrong label here even though the dispatcher itself resolved correctly.
    Routes through crew.resolve_model_for — the same override chain the
    dispatcher uses (per-order > role-models.json > env var > role overlay >
    built-in) — so the label and the dispatch decision can never disagree.
    """
    if not role or role == "-":
        return ""
    try:
        from maestro.core.crew import resolve_model_for, _load_order_data_for
        order_data = _load_order_data_for(order_id) if order_id and order_id != "-" else {}
        model_id = resolve_model_for(role, order_data)
        return get_model_label(model_id)
    except Exception:
        # Resolution failure (e.g. unknown override) shouldn't take the
        # dashboard down — fall back to the built-in default label.
        return get_role_model(role)


def _build_crews(max_crews: int) -> List[Crew]:
    """Gather per-slot crew state, with orphan repair (RUNNING + dead PID → CRASHED)."""
    crews = []
    for i in range(1, max_crews + 1):
        raw = get_crew_activity(i)
        status = raw["status"]
        if status in ("RUNNING", "ACTIVE") and raw.get("pid") and not is_process_alive(raw["pid"]):
            cleanup_orphaned_crew(i)
            status = "CRASHED"

        order_id = raw.get("order", "-")
        tokens, cost = _order_usage(order_id)
        elapsed = get_elapsed_seconds(raw.get("startTime", "")) if raw.get("startTime") else 0
        activity = raw.get("activity", "")
        # Placeholder/legacy activity strings carry no signal — blank them so the
        # monitor shows nothing rather than e.g. "(none yet)" for a busy crew
        # whose live state["activity"] hasn't been written yet (FTR-0310).
        if activity.strip() in ("-", "Working...", "(none yet)", ""):
            activity = ""

        crews.append(Crew(
            slot=i,
            name=get_squad_name(i),
            status=status,
            role=raw.get("role", "-"),
            model=_effective_role_model_label(raw.get("role", ""), order_id) if status not in ("IDLE", "UNKNOWN") else "",
            order=order_id if order_id != "-" else "",
            iter=raw.get("iteration", 0),
            max_iter=raw.get("maxIterations", 0),
            live_turn=raw.get("liveTurn", 0),
            max_turns=raw.get("maxTurns", 0),
            elapsed_sec=elapsed,
            eta_sec=_crew_eta_seconds(elapsed, raw.get("liveTurn", 0),
                                      raw.get("maxTurns", 0))
            if status in ("RUNNING", "ACTIVE") else -1,
            files=raw.get("filesChanged", 0),
            tokens=tokens,
            cost_usd=cost,
            duration_label=_crew_duration_label(raw) if status == "COMPLETE" else "",
            activity=activity if status in ("RUNNING", "ACTIVE") else "",
            pid=raw.get("pid"),
        ))
    return crews


def _voyage_progress(data: Dict) -> Tuple[int, int, set]:
    """(orders_done, orders_total, order_ids) — handles both `orders` shapes:
    list of dicts with orderId+status, or list of ids + optional orderStatuses map.
    """
    orders = data.get("orders") or []
    statuses = data.get("orderStatuses") or {}
    done = 0
    ids = set()
    for o in orders:
        if isinstance(o, dict):
            oid = o.get("orderId") or o.get("id") or ""
            o_status = (o.get("status") or "").upper()
        else:
            oid = str(o)
            o_status = (statuses.get(oid) or "").upper()
        if oid:
            ids.add(oid)
        if o_status == "COMPLETE":
            done += 1
    return done, len(orders), ids


def _collect_voyages(crews: List[Crew]) -> List[Voyage]:
    """Active voyages (most recently modified first), excluding AWAITING_APPROVAL.

    Voyage ETA heuristic: mean COMPLETE-crew duration × remaining orders;
    falls back to the max running-crew ETA among crews working this voyage's
    orders; -1 (--:--) when neither signal exists.
    """
    voyages_dir = get_workspace_dir() / "voyages" / "active"
    if not voyages_dir.exists():
        return []

    done_durations = []
    for c in crews:
        if c.status == "COMPLETE" and c.duration_label:
            parts = [int(p) for p in c.duration_label.split(":")]
            secs = 0
            for p in parts:
                secs = secs * 60 + p
            done_durations.append(secs)
    avg_done = sum(done_durations) / len(done_durations) if done_durations else 0

    voyages = []
    files = sorted(voyages_dir.glob("*.json"),
                   key=lambda f: f.stat().st_mtime, reverse=True)
    for f in files:
        data = load_json_safe(f)
        if not data:
            continue
        if (data.get("status") or "").upper() == "AWAITING_APPROVAL":
            continue  # shown in the approvals block instead
        done, total, order_ids = _voyage_progress(data)

        eta = -1.0
        remaining = total - done
        if remaining > 0 and avg_done > 0:
            eta = round(avg_done * remaining)
        else:
            crew_etas = [c.eta_sec for c in crews
                         if c.order in order_ids and c.eta_sec >= 0]
            if crew_etas:
                eta = max(crew_etas)

        # FTR-MSO-2026-0310: count orders with a live crew so the mission line
        # can show "N done · M running" instead of a bare 0% that hides work.
        running = sum(1 for c in crews
                      if c.order in order_ids and c.status in ("RUNNING", "ACTIVE"))

        voyages.append(Voyage(
            id=data.get("id", f.stem),
            title=data.get("title", ""),
            orders_done=done,
            orders_total=total,
            orders_running=running,
            eta_sec=eta,
        ))
    return voyages


def _collect_escalations() -> Tuple[List[Escalation], List[Dict]]:
    """PENDING escalations as dataclasses plus the raw dicts (for the notifier)."""
    esc_path = get_workspace_dir() / "queues" / "escalations"
    items, raw_items = [], []
    if esc_path.exists():
        for esc_file in sorted(esc_path.glob("*.json")):
            data = load_json_safe(esc_file)
            if data and data.get("status") == "PENDING":
                raw_items.append(data)
                items.append(Escalation(
                    id=data.get("id", esc_file.stem),
                    title=data.get("title", "?"),
                    blocking=bool(data.get("blocking")),
                ))
    return items, raw_items


def _queue_breakdown(queues: Dict[str, Dict]) -> str:
    """Human-readable queue digest, e.g. 'BLD:3 TST:1 · requests 2 · defects 1'."""
    parts = []
    ord_details = queues.get("orders", {}).get("details", {})
    if ord_details:
        parts.append(" ".join(f"{k}:{v}" for k, v in ord_details.items()))
    for name, info in queues.items():
        if name in ("orders", "escalations"):
            continue  # orders shown above; escalations have their own block
        if info.get("count", 0) > 0:
            parts.append(f"{name} {info['count']}")
    return " · ".join(parts)


def _bridge_status_label(notifier) -> str:
    """'' (hidden) | 'on' | 'on (N pending)' | 'no token'."""
    if not notifier or not notifier.enabled:
        return ""
    try:
        bs = notifier.get_status()
    except Exception:
        return ""
    if bs.get("connected"):
        pending = bs.get("pending_notifications", 0)
        return f"on ({pending} pending)" if pending else "on"
    return "no token"


def _persona_labels() -> PersonaLabels:
    """Resolve persona vocabulary once per frame — keeps the renderer pure."""
    p = current_persona()
    try:
        names = list(p.squad_names())
    except Exception:
        names = []
    return PersonaLabels(
        product=p.term("product"),
        sprint=p.term("sprint"),
        squad=p.term("squad"),
        story=p.term("story"),
        user_title=p.term("userTitle"),
        lead_title=p.term("leadTitle"),
        crew_names=names,
    )


def build_dashboard_state(settings: Dict, refresh_seconds: int = 5) -> DashboardState:
    """Map the workspace state files into a DashboardState for render_dashboard()."""
    max_crews = settings["maxCrews"]
    crews = _build_crews(max_crews)
    dispatcher = get_dispatcher_status()
    queues = get_queue_counts()
    escalations, raw_escalations = _collect_escalations()
    approval_items = get_approval_items()

    # Approvals block merges AWAITING_APPROVAL artefacts and review-paused orders
    approvals = [
        Approval(story=item["id"], voyage=f"[{item['type']}] {item['project']}")
        for item in approval_items
    ] + [
        Approval(story=item["order_id"], voyage=item["voyage_id"], age=item["age"])
        for item in get_pending_review_items()
    ]

    # Bridge notifications — fire-and-forget thread so the refresh never stalls
    notifier = _get_bridge_notifier()
    if notifier and notifier.enabled:
        def _notify():
            try:
                notifier.check_and_notify(approval_items, raw_escalations)
            except Exception:
                pass
        threading.Thread(target=_notify, daemon=True).start()

    uptime = -1.0
    if dispatcher["running"] and dispatcher.get("startTime"):
        secs = get_elapsed_seconds(dispatcher["startTime"])
        if secs > 0:
            uptime = secs

    billing_mode, budget = _detect_billing()

    # BUG-MSO-2026-0349: dependency-held items surface separately from pending
    held_total = sum(info.get("held", 0) for info in queues.values())
    held_items = [
        f"{order_id} — waiting on {waiting}"
        for info in queues.values()
        for order_id, waiting in info.get("held_details", {}).items()
    ]

    # BUG-MSO-2026-0451: the NAMED breakdown across all four dispatcher-held
    # categories (review-gated / dep-held / stranded / skipped) — the same
    # split IDLE_REAP already logs, surfaced here instead of buried in
    # lifecycle.log.
    held_breakdown_str = format_held_breakdown(get_held_breakdown())

    # FTR-MSO-2026-0359: offline dispatch hold — written by the dispatcher's
    # connectivity gate to .mso/state/connectivity.json. Only shown while the
    # dispatcher is actually running (a stale hold from a dead dispatcher is
    # not actionable state).
    offline_hold = False
    offline_detail = ""
    if dispatcher["running"]:
        try:
            from maestro.core.connectivity import read_connectivity_state
            _conn = read_connectivity_state(get_workspace_dir())
            if _conn.get("holdActive"):
                offline_hold = True
                _riding = sum(1 for c in crews if (c.status or "").upper() == "RUNNING")
                offline_detail = (
                    f"OFFLINE — dispatch held, {_riding} crew(s) riding it out"
                )
        except Exception:
            pass

    # BUG-MSO-2026-0548: sustained artefact-plane push divergence — read
    # unconditionally (unlike offline_hold above), because a stale plane
    # stays stale even after the dispatcher that caused it has exited; the
    # operator needs to see it either way. {} (embedded mode, or solo/shared
    # never diverged) leaves both fields at their False/"" defaults.
    artefact_diverged = False
    artefact_divergence_detail = ""
    try:
        from maestro.core.artefact_divergence import read_divergence_state
        _div = read_divergence_state(get_workspace_dir())
        if _div.get("diverged"):
            artefact_diverged = True
            detail = _div.get("detail") or ""
            artefact_divergence_detail = (
                f"ARTEFACT PLANE DIVERGED — {detail}" if detail else "ARTEFACT PLANE DIVERGED"
            )
    except Exception:
        pass

    return DashboardState(
        version=resolve_version(),
        now=datetime.now(),
        dispatcher_running=dispatcher["running"],
        dispatcher_pid=dispatcher.get("pid"),
        dispatcher_uptime_sec=uptime,
        voyages=_collect_voyages(crews),
        crews=crews,
        approvals=approvals,
        escalations=escalations,
        billing_mode=billing_mode,
        spend_usd=_workspace_spend() if billing_mode == "api" else 0.0,
        budget_usd=budget,
        queued=queues.get("orders", {}).get("count", 0),
        queue_breakdown=_queue_breakdown(queues),
        held=held_total,
        held_items=held_items,
        lifecycle=get_lifecycle_log(8),
        labels=_persona_labels(),
        bridge_status=_bridge_status_label(notifier),
        refresh_seconds=refresh_seconds,
        max_crews=max_crews,
        held_breakdown=held_breakdown_str,
        offline_hold=offline_hold,
        offline_detail=offline_detail,
        dispatcher_state=dispatcher.get("state", ""),
        dispatcher_heartbeat_age_sec=(
            dispatcher["heartbeatAgeSeconds"]
            if dispatcher.get("heartbeatAgeSeconds") is not None else -1
        ),
        artefact_diverged=artefact_diverged,
        artefact_divergence_detail=artefact_divergence_detail,
    )


# =============================================================================
# MAIN
# =============================================================================

def _owning_dispatcher_pid() -> Optional[int]:
    """PID of the dispatcher that was alive when this monitor started, if any.

    BUG-MSO-2026-0403: `auto_launch_monitor()` spawns the monitor as a detached
    process tied to no particular dispatcher lifetime — if the dispatcher later
    idle-reaps or is stopped, nothing told the monitor to exit, and it (plus its
    console wrapper) was observed surviving as an orphan repeatedly. Recording
    the dispatcher PID once at startup lets the monitor loop notice when THAT
    dispatcher goes away and exit itself, without misfiring for a monitor
    started standalone (`mso status`) with no dispatcher running at all.
    """
    pid_file = get_workspace_dir() / "dispatcher.pid"
    if not pid_file.exists():
        return None
    try:
        pid = int(pid_file.read_text(encoding='utf-8').strip())
    except (ValueError, OSError):
        return None
    return pid if is_process_alive(pid) else None


def run_monitor(refresh_seconds: int = 5, once: bool = False, compact: bool = False):
    """Run the monitor loop.

    --once prints a single frame (pipe/NO_COLOR-safe via rich's own detection).
    The loop renders into the terminal's alternate buffer (Live screen=True),
    so the dashboard never pollutes scrollback.
    """
    from rich.console import Console
    from rich.live import Live

    settings = get_settings()
    console = Console()
    # Render to the console's own width so piped/narrow output never wraps.
    width = max(64, console.width - 2)

    if once:
        console.print(render_dashboard(
            build_dashboard_state(settings, refresh_seconds),
            compact=compact, width=width))
        return

    # BUG-MSO-2026-0403: tie this monitor's lifetime to the dispatcher that
    # owned it at launch, if any — see _owning_dispatcher_pid().
    owning_pid = _owning_dispatcher_pid()
    dispatcher_gone = False

    try:
        with Live(render_dashboard(build_dashboard_state(settings, refresh_seconds),
                                   compact=compact, width=width),
                  console=console, refresh_per_second=2, screen=True) as live:
            while True:
                time.sleep(refresh_seconds)
                if owning_pid is not None and not is_process_alive(owning_pid):
                    dispatcher_gone = True
                    break
                width = max(64, console.width - 2)  # track live resizes
                live.update(render_dashboard(
                    build_dashboard_state(settings, refresh_seconds),
                    compact=compact, width=width))
    except KeyboardInterrupt:
        pass
    # Printed AFTER the Live context exits — the alt buffer would swallow it.
    if dispatcher_gone:
        print(f"\n  Dispatcher (PID {owning_pid}) is gone — Monitor exiting (BUG-0403).\n")
    else:
        print(f"\n  {current_persona().term('product')} Monitor stopped.\n")


def main():
    parser = argparse.ArgumentParser(
        description=f"Maestro Monitor v{resolve_version()} - Squad Monitor Dashboard",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s                     # Default: 5s refresh, full dashboard
  %(prog)s --refresh 10        # Custom refresh interval
  %(prog)s --once              # One-shot display, then exit
  %(prog)s --compact           # One-line-per-crew layout for narrow terminals
        """
    )
    parser.add_argument("--refresh", type=int, default=5,
                       help="Refresh interval in seconds (default: 5)")
    parser.add_argument("--once", action="store_true",
                       help="Display once and exit (no loop)")
    parser.add_argument("--compact", action="store_true",
                       help="One-line-per-crew layout for narrow terminals")
    # Legacy positional argument support (old: python fleet_monitor.py 5)
    parser.add_argument("refresh_legacy", nargs="?", type=int, default=None,
                       help=argparse.SUPPRESS)

    args = parser.parse_args()

    # Support legacy positional refresh argument
    refresh = args.refresh
    if args.refresh_legacy is not None:
        refresh = args.refresh_legacy
        if refresh == 0:
            args.once = True

    # PID lock - prevent duplicate looping instances (one alt-buffer owner)
    if not args.once:
        if not check_monitor_lock():
            print("\n  Maestro Monitor is already running in another window.")
            print("  Kill the existing instance first, or check .mso/monitor.pid\n")
            return 1
        atexit.register(release_monitor_lock)

    run_monitor(refresh_seconds=refresh, once=args.once, compact=args.compact)
    return 0


if __name__ == "__main__":
    run_cli(main, command="mso status")


# ---------------------------------------------------------------------------
# Rebrand vocabulary (FTR-MSO-2026-0155) — new canonical names
# ---------------------------------------------------------------------------

class TeamMonitor:
    """Namespace sentinel for the fleet/team monitor subsystem."""


# Legacy alias — kept through v3.x, removed in v4.0
FleetMonitor = TeamMonitor  # legacy alias (v3.x); removed v4.0
