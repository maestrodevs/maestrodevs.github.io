# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""maestro/core/dispatcher_heartbeat.py — the ONE dispatcher-liveness
heartbeat-age computation, shared by the CLI (``maestro.core.fleet_monitor``)
and the Hub backend (``maestro.hub.aggregator``).

BUG-MSO-2026-0595 (code review of PR #378, findings 378-B/C/D): the Hub had
its own second copy of this logic that derived heartbeat age from
``logs/lifecycle.log``'s file MTIME. That log is MULTI-WRITER — crews,
``mso voyage reconcile``, the Hub's own sweep and the resident LEAD daemon
(``LEAD_TICK``, every ~300s) all append to it — so the file's mtime stays
warm even while the dispatcher's own tick loop is wedged, and the Hub could
never observe a WEDGED dispatcher that ``mso status`` correctly flagged. The
two surfaces disagreeing about the same dispatcher is the user-visible harm;
this module exists so there is exactly one implementation for both to call.

Deliberately dependency-light (stdlib only) so importing it does not pull in
either fleet_monitor's CLI/dashboard import graph or any Hub-specific state.
"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Optional

# Staleness ceiling (seconds) shared by every consumer of this module. The
# dispatcher's HEARTBEAT line and fleet-runner-state.json's "timestamp" field
# are both written on a cadence well under this, so a genuinely alive
# dispatcher never approaches it.
DISPATCHER_HEARTBEAT_STALE_SECONDS = 360


def last_dispatcher_heartbeat_line_age(log_file: Path) -> Optional[float]:
    """Age (seconds) of the most recent dispatcher ``HEARTBEAT`` line in
    *log_file*, or ``None`` if the file is missing/unreadable/undecodable or
    contains no such line yet.

    Deliberately reads the line's OWN timestamp, not the file's mtime —
    ``logs/lifecycle.log`` is appended to by crews, ``mso voyage reconcile``,
    the Hub's sweep, and the resident LEAD daemon as well as the dispatcher,
    so the file's mtime alone proves only that SOMETHING wrote to it
    recently, not that the dispatcher's own tick loop is still turning. The
    ``HEARTBEAT`` event type is written exclusively by the dispatcher's main
    loop (``fleet_runner.py``), so its timestamp is a signal only the
    dispatcher itself can refresh.

    BUG-MSO-2026-0595:
      - A malformed timestamp on one HEARTBEAT line ``continue``s to the next
        (older) HEARTBEAT line rather than discarding the whole signal via
        ``return None`` — an otherwise-parseable line further back in the
        file still answers the question, and the caller should not fall back
        to state-file age alone just because the newest line is corrupt.
      - ``UnicodeDecodeError`` is caught alongside ``OSError`` — a torn
        multi-writer append (or the non-atomic log rotation in
        ``fleet_runner.py``) must not crash the caller. Mirrors
        ``fleet_monitor.get_lifecycle_log``'s bare ``except`` for the same
        reason.
    """
    try:
        lines = log_file.read_text(encoding="utf-8").splitlines()
    except (OSError, UnicodeDecodeError):
        return None

    for line in reversed(lines):
        parts = line.split("|")
        if len(parts) < 2 or parts[1].strip() != "HEARTBEAT":
            continue
        try:
            ts = datetime.strptime(parts[0].strip(), "%Y-%m-%d %H:%M:%S")
        except ValueError:
            continue
        return max(0.0, (datetime.now() - ts).total_seconds())

    return None


def state_file_timestamp_age_seconds(state_file: Path) -> Optional[float]:
    """Age (seconds) of ``fleet-runner-state.json``'s own ``"timestamp"``
    field, or ``None`` if the file/field is missing, unreadable, undecodable,
    or unparsable.

    Reads the field the dispatcher writes into the file's CONTENT, not the
    file's mtime, so both signals this module combines are content-derived
    and neither is defeated by an unrelated process touching the file (e.g.
    a filesystem sync or backup tool bumping mtime without rewriting
    content).
    """
    try:
        raw = state_file.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return None
    try:
        state = json.loads(raw)
    except json.JSONDecodeError:
        return None
    if not isinstance(state, dict):
        return None
    ts = state.get("timestamp")
    if not ts:
        return None
    try:
        return max(0.0, (datetime.now() - datetime.fromisoformat(ts)).total_seconds())
    except (ValueError, TypeError):
        return None


def dispatcher_heartbeat_age_seconds(mso: Path) -> Optional[float]:
    """Age in seconds of the freshest of the dispatcher's two independent
    liveness signals, or ``None`` if neither is available.

    The two signals:
      - ``fleet-runner-state.json``'s ``"timestamp"`` field — a state-CHANGE
        marker, only rewritten when crew assignments change. Alone, this
        false-positives WEDGED on a dispatcher that is busy and healthy but
        has had no assignment change in a while (BUG-MSO-2026-0576).
      - The timestamp of the dispatcher's own last ``HEARTBEAT`` line in
        ``logs/lifecycle.log`` (BUG-MSO-2026-0581) — NOT that file's mtime;
        see :func:`last_dispatcher_heartbeat_line_age` for why a shared,
        multi-writer log's mtime cannot serve as a liveness signal for any
        one of its writers.

    Exposed as a NUMBER, never collapsed to a bool, so callers can apply
    their own staleness ceiling and distinguish "no heartbeat data yet" (a
    dispatcher that just started) from "heartbeat data exists and is stale"
    (a dispatcher whose tick loop has stalled).
    """
    state_age = state_file_timestamp_age_seconds(mso / "fleet-runner-state.json")
    heartbeat_line_age = last_dispatcher_heartbeat_line_age(mso / "logs" / "lifecycle.log")
    ages = [age for age in (state_age, heartbeat_line_age) if age is not None]
    return min(ages) if ages else None
