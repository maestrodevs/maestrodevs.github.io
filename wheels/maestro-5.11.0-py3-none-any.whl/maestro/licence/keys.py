"""
Vendor-only licence key resolver — the closed Ed25519 trust root for licence tokens.

FTR-MSO-2026-0451 (PLAN-PLN-MSO-2026-0450 §4.2, Captain ruling D2).

``maestro/governance/keys.py`` merges FOUR sources (env < workspace < home < vendor)
so an organisation can layer its own signing keys on top of the vendor baseline —
correct for policy bundles, where a customer legitimately signs their own policy.

That merge is exactly wrong for licences: if a workspace, a home-dir keyring, or an
env var could add a ``keyId`` here, a customer could pin their own public key and
self-issue an ENTERPRISE licence. So this module resolves from ONE file only —
``maestro/licence/keys/licence-keys.json``, baked into the package — and has no
env / workspace / home channel at all. There is deliberately no
``MAESTRO_LICENCE_TRUSTED_KEYS``-style environment variable: adding one would be
exactly the customer-writable channel this module exists to refuse.

Reuses the generic, already-CI-covered pieces of ``governance/keys.py`` — the
``TrustedKey`` dataclass and the ``_keys_from_map`` decoder — but never calls
``governance.keys.load_trusted_keys()`` or any of its per-source loaders.

Testing note: dependency injection, not an env channel. Pass an explicit
``keyring_path`` to :func:`load_licence_keys` / :func:`resolve_licence_key` (or
monkeypatch :func:`_vendor_keys_path`) to point a test at a throwaway keyring.
Production callers never pass ``keyring_path``, so the resolved keyring is always
the shipped vendor file.

BUG-MSO-2026-0503 — the file this module reads (``licence-keys/
licence-keys.json``) ships ``"keys": {}`` in every commit of this repo (a
hard constraint asserted by ``tests/test_licence_keys_repo_stays_empty.py``
— the repo is slated for a public mirror, so no key material may ever be
tracked). The real public key only ever exists in a CI secret, injected into
the wheel at build time by ``scripts/inject_licence_keys.py``. This means a
``pip install .`` from a plain clone with that secret not configured
produces an honestly-unlicensed (community-tier) build — the deliberate
trade-off of choosing build-time injection over any customer/local-writable
channel.

**Why not just preserve an existing installed keyring across reinstall
instead (make it survive a local ``pip install .`` unchanged)?** Considered
and rejected. That would make the trust root STICKY local state — surviving
independently of which release is actually installed — which is exactly the
property a closed trust root must not have: a key rotation or revocation
shipped in a new release could be silently undone by carrying an old
install's keyring forward, and "what does this machine trust" would no
longer be fully determined by the installed wheel. Sticky trust is a
security regression dressed as a convenience fix; rejected on that basis,
not because it would be hard to implement. See CLAUDE.md's "Phase 3c —
Restore the licensed keyring after refresh" for the actual (non-sticky)
local-refresh workflow, and :func:`maestro.auth.licence_keyring_warning`
for the companion fix that makes a wiped-keyring downgrade loud instead of
silent.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from maestro.governance.keys import TrustedKey, _keys_from_map
from maestro.licence.errors import LicenceUntrusted

_KEYS_DIRNAME = "keys"
_KEYS_FILENAME = "licence-keys.json"
_SOURCE = "licence-vendor"


def _vendor_keys_path() -> Path:
    return Path(__file__).resolve().parent / _KEYS_DIRNAME / _KEYS_FILENAME


def load_licence_keys(keyring_path: Path | None = None) -> dict[str, TrustedKey]:
    """Load the vendor-only licence keyring. No merge, no other source.

    An absent file resolves to no keys (fail-closed via :func:`resolve_licence_key`,
    which raises on an unknown ``keyId`` rather than trusting anything by default).
    """
    path = keyring_path or _vendor_keys_path()
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001 — a malformed vendor keyring fails closed
        raise LicenceUntrusted(f"licence keyring unreadable ({path}): {exc}") from exc
    if not isinstance(data, dict):
        raise LicenceUntrusted(f"licence keyring ({path}) must be a JSON object")
    return _keys_from_map(data.get("keys", {}), _SOURCE)


def resolve_licence_key(
    key_id: str,
    *,
    now: datetime | None = None,
    keyring_path: Path | None = None,
) -> TrustedKey:
    """Resolve + validate a usable licence-signing key for ``key_id``.

    Raises :class:`LicenceUntrusted` when the key is unknown, revoked, or past its
    ``notAfter`` — the only outcomes; there is no permissive default.
    """
    now = now or datetime.now(timezone.utc)
    keys = load_licence_keys(keyring_path)
    key = keys.get(key_id)
    if key is None:
        raise LicenceUntrusted(
            f"licence token references unknown signing key '{key_id}' — not present "
            "in the vendor licence keyring. This is not fixable by adding the key to "
            "a workspace, the user home, or an environment variable: the licence "
            "trust root is closed and ships only in the Maestro package."
        )
    usable, reason = key.is_usable(now)
    if not usable:
        raise LicenceUntrusted(f"licence signing key rejected: {reason}")
    return key
