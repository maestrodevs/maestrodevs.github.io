# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. See LICENSE for full terms.

"""
maestro.licence — licence-key activation / validation / storage.

Public API:
    activate(key) -> LicenceRecord | TokenLicenceRecord
                                       # v1 (legacy `adm_lic_...` keys): online
                                       # Polar verify + persist, unchanged.
                                       # v2 (`MSO1.` tokens, FTR-MSO-2026-0451/
                                       # 0452): fully offline — verify the
                                       # Ed25519 signature + trust root, persist
                                       # the token verbatim.
    validate(strict=False) -> LicenceRecord | TokenLicenceRecord
                                       # v1: unchanged (24h cache, online
                                       # re-validate, 14d offline grace).
                                       # v2: re-verify the token every call and
                                       # apply the tier-dependent expiry matrix
                                       # (§D3b) — trial/pro auto-downgrade to
                                       # community, team/enterprise STOP after
                                       # a 14-day grace (record.stopped=True,
                                       # never raised — see resolve_state()).
    deactivate() -> None               # local-side deactivation (both schemas)
    status() -> LicenceRecord | TokenLicenceRecord | None
                                       # read-only inspection; None means
                                       # "no usable licence" — which is the
                                       # community tier, not an error (§D3a).
    resolve_state(strict=False) -> LicenceState
                                       # the single source of truth auth.py /
                                       # cli.py use: what tier is in force
                                       # right now, plus any banner/stop
                                       # condition. Never raises for a missing
                                       # or unusable licence — community is
                                       # success. See LicenceState.

Backend: dual. Legacy Polar.sh-backed licences (schema_version 1, storage.py)
keep working bit-for-bit until their removal order (FTR-MSO-2026-0456). New
licences are self-issued, Ed25519-signed, offline-verifiable tokens (schema_
version 2, PLAN-PLN-MSO-2026-0450). Storage is at ~/.maestro/licence.json in
both cases — see maestro.licence.storage for the schema split.

Config (env vars):
    MAESTRO_LICENCE_API_BASE   default https://api.polar.sh/v1   (v1 only)
    MAESTRO_LICENCE_KEY        non-interactive activation (CI/CD; either
                                schema — the value's prefix decides the path)
    MAESTRO_LICENCE_GRACE_DAYS default 14 (test override only; both schemas)
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Optional

from maestro.licence.client import PolarClient, PolarError
from maestro.licence.errors import (
    LicenceError,
    LicenceExpired,
    LicenceForged,
    LicenceInvalid,
    LicenceMalformed,
    LicenceMissing,
    LicenceRevoked,
    LicenceTampered,
    LicenceUntrusted,
)
from maestro.licence.grace import (
    GRACE_DEFAULT_DAYS,
    grace_days,
    grace_remaining_days,
    in_grace_window,
    next_grace_until,
    parse_iso,
)
from maestro.licence.storage import (
    LicenceRecord,
    TokenLicenceRecord,
    delete_record,
    load_record,
    save_record,
    save_token_record,
)
from maestro.licence import token as _token


__all__ = [
    "activate",
    "validate",
    "deactivate",
    "status",
    "resolve_state",
    "LicenceState",
    "LicenceRecord",
    "TokenLicenceRecord",
    "LicenceError",
    "LicenceExpired",
    "LicenceInvalid",
    "LicenceRevoked",
    "LicenceTampered",
    "LicenceMissing",
    "LicenceMalformed",
    "LicenceUntrusted",
    "LicenceForged",
    "COMMUNITY_TIER",
    "RENEWAL_CONTACT_URL",
]


# §D6 (Captain ruling): "BLD should read it from one constant, not scatter the
# literal" — the Captain notes the final form URL may change. auth.py / cli.py
# import this rather than hard-coding it (replaces the old
# `polar.sh/tech127/portal` literal scattered across auth.py/cli.py).
RENEWAL_CONTACT_URL = "https://www.maestrodevs.com/contact/"

# §D3a — the tier every install runs at with no licence, or once an expired
# trial/Pro licence auto-downgrades. Free, permanent, no error.
COMMUNITY_TIER = "community"

_MSO1_PREFIX = _token.MSO1_PREFIX


# ---------------------------------------------------------------------------
# schema_version 1 (legacy Polar) — test-only fake-activation bypass.
# Unchanged by this order; retirement is FTR-MSO-2026-0456 once v2 issuance
# makes it obsolete (§7.4).
# ---------------------------------------------------------------------------

def _is_fake_activation_enabled() -> bool:
    """Test-only Polar bypass.

    Honoured ONLY when MAESTRO_LICENCE_FAKE_ACTIVATION=1 is set in the
    operator's parent shell. Used to verify the CLI install/activate/
    status/deactivate path on a fresh machine while Polar is under
    review or otherwise unreachable. Never accidentally on by default.
    """
    import os
    return os.environ.get("MAESTRO_LICENCE_FAKE_ACTIVATION") == "1"


def _fake_id_from_key(key: str) -> str:
    """Stable 14-hex-char digest of a licence key for synthetic IDs.

    Uses sha256 (NOT Python's built-in hash, which is salted per-process
    via PYTHONHASHSEED). This guarantees the same key produces the same
    `customer_id` across processes / machines — the "deterministic per
    key" property the fake-activation path advertises.
    """
    import hashlib
    return hashlib.sha256(key.encode("utf-8")).hexdigest()[:14]


# Records produced by the fake-activation path are tagged with this prefix
# on `customer_id`. The CLI status banner + the validate() bypass guard
# both branch on this marker — never on the env var alone.
_FAKE_CUSTOMER_PREFIX = "cust_FAKE_"


def _fake_payload(key: str) -> dict:
    """Synthetic Polar response for the fake-activation path."""
    from datetime import timedelta as _td
    from maestro.licence.config import POLAR_PRODUCT_PRO
    now = datetime.now(timezone.utc)
    digest = _fake_id_from_key(key)
    return {
        "customer_id": f"{_FAKE_CUSTOMER_PREFIX}{digest}",
        "tier": "pro",
        "product_id": POLAR_PRODUCT_PRO,
        "issued_at": now.isoformat(),
        "expires_at": (now + _td(days=365)).isoformat(),
        "signing_secret": f"fake-secret-for-{digest}",
    }


# ---------------------------------------------------------------------------
# activate()
# ---------------------------------------------------------------------------

def activate(key: str) -> "LicenceRecord | TokenLicenceRecord":
    """Activate `key` and persist the result.

    Branches on the key's own shape (FTR-MSO-2026-0452 §7.2 dual-validation
    window): an `MSO1.`-prefixed value is a new offline token — verified
    entirely locally (Ed25519 signature, vendor trust root, time window), no
    network round-trip. Anything else falls through to the legacy Polar
    online-activation path, byte-for-byte unchanged — no existing customer's
    activation command changes or breaks.

    Raises LicenceInvalid if the key is empty.
    v1: raises PolarError on network/5xx (does NOT cache — activation
        requires a successful online round-trip).
    v2: raises LicenceMalformed / LicenceUntrusted / LicenceForged /
        LicenceExpired if the token doesn't verify — activation requires a
        currently-valid token (a not-yet-valid `notBefore` or an already-
        expired token is refused at activation time, not silently accepted).
    """
    if not key or not key.strip():
        raise LicenceInvalid("Licence key is empty.")
    key = key.strip()

    if key.startswith(_MSO1_PREFIX):
        now = datetime.now(timezone.utc)
        payload = _token.verify(key, now=now)  # raises on any failure — see docstring
        return save_token_record(
            key,
            payload,
            activated_at=now.isoformat(),
            last_verified_at=now.isoformat(),
        )

    # --- legacy Polar path (unchanged) ---
    fake = _is_fake_activation_enabled()
    if fake:
        payload = _fake_payload(key)
    else:
        client = PolarClient()
        payload = client.validate(key)  # raises on 4xx/5xx/network

    now = datetime.now(timezone.utc)
    record = LicenceRecord(
        licence_key=key,
        tier=payload["tier"],
        product_id=payload["product_id"],
        customer_id=payload["customer_id"],
        issued_at=payload["issued_at"],
        expires_at=payload["expires_at"],
        last_validated_at=now.isoformat(),
        offline_grace_until=next_grace_until(now).isoformat(),
        signing_secret=payload["signing_secret"],  # consumed once → keychain
    )
    save_record(record)
    return record


# ---------------------------------------------------------------------------
# validate() — schema_version 1 (legacy Polar, unchanged)
# ---------------------------------------------------------------------------

def _validate_v1(record: LicenceRecord, strict: bool) -> LicenceRecord:
    """Bit-for-bit the pre-FTR-MSO-2026-0452 v1 validate() body.

    Kept as its own function (not inlined) so the schema branch in
    validate() reads cleanly; the logic itself is untouched — see the
    module-level note on why the Polar path stays frozen until its removal
    order.
    """
    now = datetime.now(timezone.utc)
    last = parse_iso(record.last_validated_at)
    cached_ok = (now - last).total_seconds() < 24 * 3600

    if cached_ok and not strict:
        if parse_iso(record.expires_at) <= now:
            raise LicenceExpired(record.expires_at)
        record.used_grace = False
        return record

    # Test-only bypass: refresh timestamps locally without hitting Polar.
    # Two guards before we'll skip Polar:
    #   1. The env var must be on (operator opt-in).
    #   2. The stored record must itself be synthetic (cust_FAKE_ prefix).
    # This means flipping the env var on a machine with a *real* licence
    # record will NOT keep that real record alive past Polar revocation —
    # the bypass only applies to records that were synthesised by
    # _fake_payload() in the first place.
    # Expiry is still enforced here (matches the cached-OK fast path).
    if _is_fake_activation_enabled() and record.customer_id.startswith(_FAKE_CUSTOMER_PREFIX):
        if parse_iso(record.expires_at) <= now:
            raise LicenceExpired(record.expires_at)
        record.last_validated_at = now.isoformat()
        record.offline_grace_until = next_grace_until(now).isoformat()
        save_record(record)
        record.used_grace = False
        return record

    try:
        payload = PolarClient().validate(record.licence_key)
        record.last_validated_at = now.isoformat()
        record.offline_grace_until = next_grace_until(now).isoformat()
        record.expires_at = payload.get("expires_at", record.expires_at)
        save_record(record)
        record.used_grace = False
        return record
    except PolarError as exc:
        if exc.status in (401, 403):
            if exc.is_revoked():
                raise LicenceRevoked(exc.reason or exc.polar_status) from exc
            raise LicenceExpired(exc.reason or "Polar marked the key as not granted") from exc
        if in_grace_window(now, record.offline_grace_until):
            record.used_grace = True
            record.grace_remaining_days = grace_remaining_days(now, record.offline_grace_until)
            return record
        raise LicenceExpired(
            f"Offline grace expired ({grace_remaining_days(now, record.offline_grace_until)} days remaining). "
            "Connect to the internet to revalidate."
        ) from exc


# ---------------------------------------------------------------------------
# validate() — schema_version 2 (token) — the new tier-dependent D3b matrix
# ---------------------------------------------------------------------------

# What's lost when a paid tier auto-downgrades to community (§D3a/§D3b) —
# printed in the downgrade banner so the message states what capability was
# lost, not merely that a licence expired (an explicit acceptance criterion).
_TIER_CAPABILITY_SUMMARY = {
    "pro": "unlimited concurrent crews and the DOC/SEC/REL roles",
    "team": "governance, multi-seat identity/ACLs, the Hub, and the DOC/SEC/REL roles",
    "enterprise": (
        "governance, audit anchoring, multi-repo/shared artefact mode, the Hub, "
        "and the DOC/SEC/REL roles"
    ),
}


def _expiry_soon_warning(expires_at_iso: Optional[str], now: datetime, tier: str) -> Optional[str]:
    """T-30d / T-7d banner (§9 D7), only while the token is still within its
    own validity window (no grace/downgrade in play yet)."""
    if not expires_at_iso:
        return None
    try:
        expires_at = parse_iso(expires_at_iso)
    except Exception:  # noqa: BLE001 — a bad cached timestamp just skips the banner
        return None
    days_left = (expires_at - now).days
    if days_left > 30 or days_left < 0:
        return None
    if days_left <= 7:
        return (
            f"⚠ Maestro {tier} licence expires in {days_left} day(s) ({expires_at_iso}). "
            f"Renew now — {RENEWAL_CONTACT_URL}"
        )
    return (
        f"⚠ Maestro {tier} licence expires in {days_left} days ({expires_at_iso}). "
        f"Renew at {RENEWAL_CONTACT_URL}"
    )


def _grace_message(tier: str, remaining_days: int) -> str:
    if tier in ("team", "enterprise"):
        outcome = (
            "no downgrade exists for this tier — Maestro will STOP working entirely "
            "(dispatch and crew execution refused; `mso licence activate`, `status`, "
            "`revalidate`, `version` and `--help` keep working)."
        )
    else:
        outcome = "Maestro will downgrade to the free community tier (2 crews; INV/PLN/BLD/TST only)."
    return (
        f"⚠ Maestro {tier} licence EXPIRED — running on a {remaining_days}-day grace period. "
        f"After grace: {outcome} Renew at {RENEWAL_CONTACT_URL}"
    )


def _downgrade_message(from_tier: str, to_tier: str, reason: str) -> str:
    lost = _TIER_CAPABILITY_SUMMARY.get(from_tier, f"your {from_tier} entitlements")
    return (
        f"⚠ Maestro downgraded from {from_tier} to {to_tier} ({reason}). "
        f"Lost: {lost}. {to_tier.capitalize()} keeps working (2 crews; INV/PLN/BLD/TST). "
        f"Renew at {RENEWAL_CONTACT_URL}"
    )


def _stop_message(tier: str) -> str:
    return (
        f"✗ Maestro {tier} licence EXPIRED and its grace period has ended. Maestro "
        f"has STOPPED (no automatic downgrade for {tier} — governance, identity and "
        f"audit state would be misrepresented at community tier). Apply a new licence "
        f"(`mso licence activate <TOKEN>`) or perform a clean install to run at "
        f"community. Renew at {RENEWAL_CONTACT_URL}\n"
        f"Still available while stopped: `mso licence activate|status|revalidate`, "
        f"`mso version`, `mso status`, `--help`."
    )


def _apply_expiry_policy(
    record: TokenLicenceRecord, payload: dict, now: datetime
) -> TokenLicenceRecord:
    """§D3b — expiry is NOT uniform. Called once ``token.verify()`` has
    confirmed the signature is authentic and the only remaining failure is
    the time window (``LicenceExpired``). Never raises: STOPPED is expressed
    as ``record.stopped = True``, not an exception — see ``LicenceState`` /
    ``resolve_state()`` for why (both CLI exit-on-refuse and "still show the
    record so status can explain itself" need the same data)."""
    tier = payload.get("tier", record.tier)
    is_trial = bool(payload.get("isTrial", False))
    expires_at_iso = payload.get("expiresAt")
    expires_at = parse_iso(expires_at_iso) if expires_at_iso else now

    record.tier = tier
    record.is_trial = is_trial
    record.expires_at = expires_at_iso or record.expires_at
    record.stopped = False
    record.downgraded = False
    record.downgraded_from = None
    record.used_grace = False
    record.grace_remaining_days = 0

    if is_trial:
        record.effective_tier = COMMUNITY_TIER
        record.downgraded = True
        record.downgraded_from = tier
        record.warning = _downgrade_message(tier, COMMUNITY_TIER, "your trial has ended")
        return record

    grace_until = expires_at + timedelta(days=grace_days())
    within_grace = now <= grace_until
    remaining = max(0, (grace_until - now).days)

    if tier == "pro":
        if within_grace:
            record.effective_tier = "pro"
            record.used_grace = True
            record.grace_remaining_days = remaining
            record.warning = _grace_message("pro", remaining)
            return record
        record.effective_tier = COMMUNITY_TIER
        record.downgraded = True
        record.downgraded_from = "pro"
        record.warning = _downgrade_message("pro", COMMUNITY_TIER, "your licence expired")
        return record

    if tier in ("team", "enterprise"):
        if within_grace:
            record.effective_tier = tier
            record.used_grace = True
            record.grace_remaining_days = remaining
            record.warning = _grace_message(tier, remaining)
            return record
        # §D3b: NO downgrade for team/enterprise. Stops, full stop.
        record.effective_tier = tier
        record.stopped = True
        record.warning = _stop_message(tier)
        return record

    # A `community`-tier token that itself carries an expiry (unlikely to
    # ever be issued, but not structurally forbidden) — expiring FROM
    # community just... stays community. Nothing to lose.
    record.effective_tier = COMMUNITY_TIER
    return record


def _validate_v2(record: TokenLicenceRecord, strict: bool, now: datetime) -> TokenLicenceRecord:
    try:
        payload = _token.verify(record.token, now=now)
    except LicenceExpired:
        # Signature + trust already confirmed by verify() before it reached
        # the time check — decode() here is a safe re-parse, not a re-trust.
        payload = _token.decode(record.token)
        record = _apply_expiry_policy(record, payload, now)
        save_token_record(
            record.token, payload,
            activated_at=record.activated_at, last_verified_at=now.isoformat(),
        )
        return record

    # Fully valid, no grace/downgrade in play.
    record.tier = payload["tier"]
    record.effective_tier = payload["tier"]
    record.is_trial = bool(payload.get("isTrial", False))
    record.expires_at = payload.get("expiresAt", record.expires_at)
    record.stopped = False
    record.downgraded = False
    record.downgraded_from = None
    record.used_grace = False
    record.grace_remaining_days = 0
    record.warning = _expiry_soon_warning(payload.get("expiresAt"), now, record.tier)
    record.last_verified_at = now.isoformat()
    save_token_record(
        record.token, payload,
        activated_at=record.activated_at, last_verified_at=record.last_verified_at,
    )
    return record


# ---------------------------------------------------------------------------
# validate() — public dispatcher
# ---------------------------------------------------------------------------

def validate(
    strict: bool = False, *, now: Optional[datetime] = None
) -> "LicenceRecord | TokenLicenceRecord":
    """Read the stored record, verify it, return a valid/current record.

    Raises LicenceMissing if no record is on disk (§D3a: this is community —
    callers must treat it as success, not failure).
    Raises LicenceTampered if the file is corrupt (v1: signature mismatch /
    missing keychain entry; v2: missing token field).

    ``now`` is a test-only injection point (production callers never pass
    it) for exercising the T-30d/T-7d banners and the grace/downgrade/stop
    matrix deterministically — mirrors ``token.verify(now=...)``.

    v1 (legacy): unchanged Polar-backed behaviour — may raise
        LicenceRevoked / LicenceExpired past grace. See _validate_v1.
        (``now`` has no effect on this path — it always uses wall-clock
        time, matching its pre-FTR-MSO-2026-0452 behaviour.)
    v2 (token): re-verifies the Ed25519 signature + trust root on every
        call. May raise LicenceMalformed / LicenceUntrusted / LicenceForged
        if the token itself is no longer trustworthy (tampered file, a
        vendor key rotation that revoked the signing key, …) — these are
        integrity failures, not expiry, and are NOT downgraded to community
        automatically by this function; callers (resolve_state()) decide.
        Never raises for plain time-window expiry — that's resolved into
        record.stopped / record.downgraded / record.warning (§D3b).
    """
    record = load_record()
    if getattr(record, "schema_version", 1) == 2:
        return _validate_v2(record, strict, now or datetime.now(timezone.utc))
    return _validate_v1(record, strict)


def deactivate() -> None:
    """Drop the local licence record (file + keychain entry, if any).

    Note: for a v1 record this does NOT cancel the Polar subscription —
    that's the customer's billing portal action. A v2 token has no
    "subscription" concept to cancel; deactivating just stops using it
    locally (the machine falls back to community).
    """
    delete_record()


def status() -> "LicenceRecord | TokenLicenceRecord | None":
    """Return the current record, or None if there's no *usable* licence.

    None is not an error — it means community tier (§D3a). Never raises.
    """
    try:
        record = load_record()
    except LicenceMissing:
        return None
    except LicenceTampered:
        return None

    if getattr(record, "schema_version", 1) == 1:
        return record  # unchanged v1 semantics — no expiry check at status()

    try:
        return validate()
    except (LicenceMalformed, LicenceUntrusted, LicenceForged):
        return None
    except LicenceMissing:
        return None
    except LicenceTampered:
        return None


# ---------------------------------------------------------------------------
# resolve_state() — the single source of truth for auth.py / cli.py
# ---------------------------------------------------------------------------

@dataclass
class LicenceState:
    """What tier is in force right now, and any banner/stop condition.

    Built by ``resolve_state()`` so ``auth.check()`` and ``cli.cmd_licence``
    share one decision instead of re-deriving it. Community (no licence at
    all, or downgraded-to-community) is success, never an error.
    """

    tier: str                      # the RAW tier of the underlying licence ("community" if none)
    effective_tier: str            # the tier actually in force (== tier unless downgraded)
    schema: Optional[int]          # 1, 2, or None (no licence on disk at all)
    is_trial: bool
    expires_at: Optional[str]
    stopped: bool                  # True only for Team/Enterprise past grace (§D3b)
    downgraded: bool
    downgraded_from: Optional[str]
    warning: Optional[str]
    used_grace: bool
    grace_remaining_days: int
    # Copilot review on PR #317: the comment already said 'or None', so the
    # annotation should say it too — Optional makes the None case checkable
    # rather than relying on a trailing comment.
    record: Optional[object]       # underlying LicenceRecord / TokenLicenceRecord, or None


def _community_state(warning: Optional[str] = None) -> LicenceState:
    return LicenceState(
        tier=COMMUNITY_TIER, effective_tier=COMMUNITY_TIER, schema=None,
        is_trial=False, expires_at=None, stopped=False, downgraded=False,
        downgraded_from=None, warning=warning, used_grace=False,
        grace_remaining_days=0, record=None,
    )


def resolve_state(strict: bool = False, *, now: Optional[datetime] = None) -> LicenceState:
    """The single source of truth: what tier is in force right now.

    Never raises for a missing/unusable licence — that resolves to the
    community LicenceState (§D3a: not an error). The one case a caller must
    still handle explicitly is ``state.stopped`` — a Team/Enterprise licence
    past its 14-day grace has NO downgrade (§D3b); ``auth.check()`` is the
    caller that turns that into an exit(1), subject to the always-available
    command floor (§D3b-i).

    ``now`` is a test-only injection point, forwarded to ``validate()``.
    """
    try:
        record = validate(strict=strict, now=now)
    except LicenceMissing:
        return _community_state()
    except LicenceTampered:
        return _community_state(
            "⚠ Stored licence record could not be read — running at community tier. "
            "Run `mso licence activate <TOKEN>` to restore your licence."
        )
    except (LicenceMalformed, LicenceUntrusted, LicenceForged) as exc:
        return _community_state(
            f"⚠ Licence token failed verification ({exc}) — running at community tier. "
            f"Run `mso licence activate <TOKEN>` with a valid token, or contact "
            f"{RENEWAL_CONTACT_URL}"
        )
    except LicenceRevoked:
        return _community_state(
            "⚠ Licence revoked — running at community tier. "
            f"Contact {RENEWAL_CONTACT_URL} for a replacement licence."
        )
    except LicenceExpired:
        # v1-only path (v2 never raises plain LicenceExpired from validate() —
        # see _validate_v2). The legacy Polar tier has no community/downgrade
        # concept; keep its existing hard-stop semantics but let callers show
        # the always-available floor rather than a bare crash.
        return LicenceState(
            tier=COMMUNITY_TIER, effective_tier=COMMUNITY_TIER, schema=1,
            is_trial=False, expires_at=None, stopped=True, downgraded=False,
            downgraded_from=None,
            warning=(
                "✗ Your legacy licence has expired past its offline grace. "
                f"Renew at {RENEWAL_CONTACT_URL}, or activate a new Maestro licence "
                "token (`mso licence activate <TOKEN>`)."
            ),
            used_grace=False, grace_remaining_days=0, record=None,
        )

    if getattr(record, "schema_version", 1) == 1:
        return LicenceState(
            tier=record.tier, effective_tier=record.tier, schema=1, is_trial=False,
            expires_at=record.expires_at, stopped=False, downgraded=False, downgraded_from=None,
            warning=(
                f"⚠ Couldn't reach the licence backend; running on offline grace "
                f"({record.grace_remaining_days} days remaining). Reconnect to revalidate."
                if getattr(record, "used_grace", False) else None
            ),
            used_grace=getattr(record, "used_grace", False),
            grace_remaining_days=getattr(record, "grace_remaining_days", 0),
            record=record,
        )

    return LicenceState(
        tier=record.tier, effective_tier=record.effective_tier, schema=2,
        is_trial=record.is_trial, expires_at=record.expires_at, stopped=record.stopped,
        downgraded=record.downgraded, downgraded_from=record.downgraded_from,
        warning=record.warning, used_grace=record.used_grace,
        grace_remaining_days=record.grace_remaining_days, record=record,
    )
