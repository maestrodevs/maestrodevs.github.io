"""maestro/providers — the tool-provider abstraction (PLAN-PLN-MSO-2026-0504 §10).

The measured problem: 30 hardcoded ``"gh"`` call sites across 9 modules
(§10, ``grep -rn '"gh"' maestro --include=*.py``). For an organisation on
Jira + Bitbucket + Jenkins, every check that shells out to ``gh`` directly is
not degraded — it is inoperative. ``resolve(kind)`` is the seam: callers ask
for a capability (``scm`` / ``ci`` / ``issues`` / ``deploy``), never for
"GitHub" by name.

**Scope of this order (§10.4 — read before extending this module).** Ships
``github`` + ``none`` only. Jira, Bitbucket, Jenkins and every real deploy
provider are separate, additive orders — the whole point of the seam is that
adding them means a new module under ``scm/``/``ci/``/``issues/``/``deploy/``,
never a rewrite of this package. **The dispatcher's own 18 ``gh`` call sites
in ``fleet_runner.py`` are NOT migrated to call through here in this order**
— that is convergence/PR machinery with a large, separate blast radius. The
``github`` providers ARE written as thin wrappers over the identical ``gh``
invocations ``fleet_runner.py`` / ``pr_merge.py`` already use, specifically so
that later migration is a call-site move, not a second implementation.
"""

from __future__ import annotations

import json
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

from maestro.providers.base import PROVIDER_KINDS, Provider
from maestro.providers.ci.github_actions import GithubActionsCiProvider
from maestro.providers.ci.none import NoneCiProvider
from maestro.providers.deploy.none import NoneDeployProvider
from maestro.providers.issues.github_issues import GithubIssuesProvider
from maestro.providers.issues.none import NoneIssuesProvider
from maestro.providers.scm.github import GithubScmProvider
from maestro.providers.scm.none import NoneScmProvider

__all__ = ["PROVIDER_KINDS", "ResolvedProvider", "resolve", "resolve_explain", "all_kinds"]

# id -> provider class, per kind. A provider id not present here resolves to
# "unknown provider" (§10.3), never a crash — an org's pack/bundle can name a
# provider this Maestro version doesn't ship yet (e.g. "jenkins") and the
# patrol degrades loudly rather than refusing to run at all (§5.3).
_REGISTRY: dict[str, dict[str, type]] = {
    "scm": {"github": GithubScmProvider, "none": NoneScmProvider},
    "ci": {"github_actions": GithubActionsCiProvider, "none": NoneCiProvider},
    "issues": {"github_issues": GithubIssuesProvider, "none": NoneIssuesProvider},
    "deploy": {"none": NoneDeployProvider},
}

# The shipped-default id per kind WHEN gh is authenticated (§10.2). `deploy`
# has no real provider yet, so it is always "none" regardless of gh.
_DEFAULT_ID_IF_GH_AUTHED = {
    "scm": "github", "ci": "github_actions", "issues": "github_issues", "deploy": "none",
}


@dataclass(frozen=True)
class ResolvedProvider:
    """What :func:`resolve_explain` found, and why — the ``--explain`` payload.

    ``provider`` is ``None`` whenever ``available`` is ``False``: a caller
    must branch on ``available``, never assume a truthy ``provider``.
    """

    kind: str
    provider_id: str
    tier: str                      # "bundle" | "workspace" | "default"
    available: bool
    reason: str                    # "" when available; always non-empty when not
    provider: Optional[Provider]


def _workspace_json(workspace: Optional[Path]) -> dict:
    if workspace is None:
        return {}
    try:
        from maestro.workspace import resolve_artefact_dir
        cfg_path = resolve_artefact_dir(Path(workspace)) / "config" / "workspace.json"
        if not cfg_path.exists():
            return {}
        data = json.loads(cfg_path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _bundle_providers(workspace: Optional[Path]) -> Optional[dict]:
    """Tier 1 — signed policy bundle override (§5.3 / §10.2), enterprise-gated.

    §10.2 is explicit that the ``providers`` block is per-workspace, never
    per-machine, so only the WORKSPACE-tier bundle
    (``.mso/config/policy-bundle.json``) is consulted — never the user-home
    tier. This reuses ``governance.loader.load_bundles()`` for the real
    integrity/signature verification (a tampered — or, under
    ``governance.requireSignature``, unsigned — bundle raises and its
    ``providers`` override is never trusted either) rather than
    re-implementing that check a second time. The ``providers`` key itself
    is then read from the SAME already-verified file, because
    ``governance.schema.PolicyBundle`` only models deny/allow/warn rules and
    has nowhere to carry arbitrary data — extending that schema is a
    separate, larger change than this order's scope.
    """
    if workspace is None:
        return None
    try:
        from maestro import auth
        if not auth.has_tier({"enterprise"}):
            return None
        from maestro.governance.loader import load_bundles
        from maestro.workspace import MSO_DIR_NAME

        load_bundles(workspace)  # fail closed: raises on tamper/invalid/unsigned-when-required
        bundle_path = Path(workspace) / MSO_DIR_NAME / "config" / "policy-bundle.json"
        if not bundle_path.exists():
            return None
        data = json.loads(bundle_path.read_text(encoding="utf-8"))
        providers = data.get("providers") if isinstance(data, dict) else None
        return providers if isinstance(providers, dict) else None
    except Exception:
        # A malformed/tampered bundle must not silently grant a provider
        # override — fail closed to "no bundle tier", same as §5.5's rule.
        return None


def _default_id(kind: str, workspace: Optional[Path]) -> str:
    """§10.2 shipped default: `github` for scm/ci/issues IF `gh` is
    authenticated, otherwise `none` — never a silent assumption that GitHub
    is present. `deploy` has no real provider in this order (§10.4)."""
    if kind == "deploy":
        return "none"
    if shutil.which("gh") is None:
        return "none"
    try:
        from maestro.core.proc import run_hidden
        r = run_hidden(["gh", "auth", "status"], capture_output=True, text=True, timeout=10)
        return _DEFAULT_ID_IF_GH_AUTHED[kind] if r.returncode == 0 else "none"
    except Exception:
        return "none"


def resolve_explain(kind: str, workspace: Optional[Path] = None) -> ResolvedProvider:
    """Resolve *kind* through the same tiers as §5's patrol-definition
    resolution: signed bundle > workspace.json > shipped default.

    ("Division pack" — §5.3's tier 2 — folds into the workspace.json tier
    here rather than being a separate live read: `maestro/packs/scaffold.py
    :apply_pack` already deep-merges a pack's `workspace-defaults.json` into
    `workspace.json` once, at `mso init --pack` time, exactly how
    `verifyCommand` resolves today. A pack that wants to recommend a
    `providers` block ships it in that same `workspace-defaults.json` — no
    new pack-schema plumbing needed. There is no live per-request
    "which pack is this workspace running" lookup anywhere in the codebase
    to hook into, so inventing one here — for `providers` alone — would be a
    second, divergent tiering mechanism ahead of Order 2's shared
    `maestro/patrol/resolver.py`, not a reuse of it.)

    Never raises. Unconfigured, unavailable, and unknown provider ids all
    resolve to `available=False` with a non-empty reason (§10.3) — a skip is
    always reported, never a silent pass and never a crash.
    """
    if kind not in PROVIDER_KINDS:
        raise ValueError(f"unknown provider kind: {kind!r} (expected one of {PROVIDER_KINDS})")

    entry: Optional[dict] = None
    tier = "default"

    bundle_providers = _bundle_providers(workspace)
    if isinstance(bundle_providers, dict) and kind in bundle_providers:
        entry = bundle_providers[kind]
        tier = "bundle"
    else:
        ws_data = _workspace_json(workspace)
        ws_providers = ws_data.get("providers") if isinstance(ws_data, dict) else None
        if isinstance(ws_providers, dict) and kind in ws_providers:
            entry = ws_providers[kind]
            tier = "workspace"

    if not isinstance(entry, dict):
        provider_id = _default_id(kind, workspace)
        config: dict[str, Any] = {}
    else:
        provider_id = entry.get("id") or _default_id(kind, workspace)
        config = dict(entry.get("config") or {})

    # Credentials: NO second credential path (order-4 AC) — resolved via
    # secrets.refs.resolve_secret_refs at the use site, exactly as
    # bridge-settings.json already does (core/bridge_notifier.py). A
    # non-enterprise workspace passes `secret://` strings through unchanged
    # (resolve_secret_refs's own feature gate), so this is a no-op there.
    try:
        from maestro.secrets.refs import resolve_secret_refs
        config = resolve_secret_refs(config, workspace=Path(workspace) if workspace else None)
    except Exception:
        pass

    provider_cls = _REGISTRY[kind].get(provider_id)
    if provider_cls is None:
        return ResolvedProvider(
            kind=kind, provider_id=str(provider_id), tier=tier, available=False,
            reason=f"skipped — unknown {kind} provider '{provider_id}' "
                   "(not installed in this Maestro version)",
            provider=None,
        )

    try:
        if provider_id == "none":
            instance = provider_cls(config)
        else:
            instance = provider_cls(config, workspace=Path(workspace) if workspace else None)
    except Exception as exc:
        return ResolvedProvider(
            kind=kind, provider_id=provider_id, tier=tier, available=False,
            reason=f"{kind} provider '{provider_id}' failed to initialise: {exc}",
            provider=None,
        )

    try:
        ok, detail = instance.available()
    except Exception as exc:  # noqa: BLE001 — a broken provider must not crash the resolver
        ok, detail = False, f"available() raised {type(exc).__name__}: {exc}"

    if ok:
        return ResolvedProvider(kind=kind, provider_id=provider_id, tier=tier,
                                 available=True, reason="", provider=instance)

    if provider_id == "none":
        composed = f"no {kind} provider configured"
    elif detail.startswith("host not permitted"):
        # §10.2 egress rule: surfaced as its own distinct reason rather than
        # wrapped in the generic "<kind> provider '<id>' unavailable:" shape,
        # per order-4 AC: "skipped — host not permitted".
        composed = detail
    else:
        composed = f"{kind} provider '{provider_id}' unavailable: {detail}"

    return ResolvedProvider(kind=kind, provider_id=provider_id, tier=tier,
                             available=False, reason=f"skipped — {composed}", provider=None)


def resolve(kind: str, workspace: Optional[Path] = None) -> Optional[Provider]:
    """``resolve(kind) -> Provider | None`` (§10.1's literal signature).

    Returns the working provider instance, or ``None`` when
    unconfigured/unavailable/unknown. Callers that must REPORT a skip (never
    silently omit it — §10.3) should call :func:`resolve_explain` instead,
    which carries the reason.
    """
    return resolve_explain(kind, workspace=workspace).provider


def all_kinds() -> tuple[str, ...]:
    return PROVIDER_KINDS
