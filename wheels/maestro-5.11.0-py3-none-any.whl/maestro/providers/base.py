"""maestro/providers/base.py — the Provider seam.

PLAN-PLN-MSO-2026-0504 §10.1: a narrow capability protocol per tool kind
(``scm``, ``ci``, ``issues``, ``deploy``), driven by what the patrol checks
actually need — not a speculative superset of every API a real SCM/CI/issue
tracker exposes.

Every provider declares ``id`` and ``kind`` and implements ``available()``,
which must never raise — a provider that cannot reach its backend (no
credentials, host not reachable, egress-denied) reports that as a
``(False, reason)`` pair so a caller can render ``skipped — <reason>``
(§10.3) instead of crashing or silently reporting a pass.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Optional

# The four provider kinds this seam supports (§10.1). Additional kinds are a
# later order, not a runtime extension point — adding one means adding a
# subpackage here, not registering a plugin.
PROVIDER_KINDS = ("scm", "ci", "issues", "deploy")


class Provider(ABC):
    """Base class for every provider, regardless of kind.

    ``id`` and ``kind`` are class attributes (not just instance state) so
    :func:`maestro.providers.resolve` can report which id/kind it *tried*
    even when construction itself is what fails.
    """

    id: str = ""
    kind: str = ""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config: dict[str, Any] = dict(config or {})

    @abstractmethod
    def available(self) -> tuple[bool, str]:
        """``(True, "")`` if this provider can be used right now, else
        ``(False, reason)``. Must never raise — a provider that cannot even
        determine its own availability should catch internally and report
        ``(False, "<what went wrong>")``.
        """
        raise NotImplementedError


class ScmProvider(Provider):
    """§10.1 capability table — the methods `voyages.pr-ci-state` and
    friends (a later order) actually call."""

    kind = "scm"

    @abstractmethod
    def get_pr_for_branch(self, branch: str) -> Optional[dict]:
        """The open (or most recent) PR for *branch*, or None if none exists."""
        raise NotImplementedError

    @abstractmethod
    def pr_is_draft(self, pr: dict) -> bool:
        raise NotImplementedError

    @abstractmethod
    def pr_review_threads(self, pr: dict) -> list[dict]:
        """Review threads on the PR, each carrying at least ``isResolved``."""
        raise NotImplementedError

    @abstractmethod
    def pr_is_merged(self, pr: dict) -> bool:
        raise NotImplementedError


class CiProvider(Provider):
    kind = "ci"

    @abstractmethod
    def checks_for_pr(self, pr: dict) -> list[dict]:
        """``[{"name": str, "status": str, "conclusion": str | None}, ...]``."""
        raise NotImplementedError


class IssuesProvider(Provider):
    kind = "issues"

    @abstractmethod
    def get_issue(self, ref: str) -> Optional[dict]:
        raise NotImplementedError

    @abstractmethod
    def update_issue(self, ref: str, **fields: Any) -> bool:
        raise NotImplementedError

    @abstractmethod
    def close_issue(self, ref: str) -> bool:
        raise NotImplementedError


class DeployProvider(Provider):
    kind = "deploy"

    @abstractmethod
    def last_deployment(self, env: str) -> Optional[dict]:
        """``{"status": str, "ref": str, "at": str} | None``."""
        raise NotImplementedError


KIND_BASE_CLASSES: dict[str, type] = {
    "scm": ScmProvider,
    "ci": CiProvider,
    "issues": IssuesProvider,
    "deploy": DeployProvider,
}
