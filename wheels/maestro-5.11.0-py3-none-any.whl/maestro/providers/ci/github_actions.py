"""maestro/providers/ci/github_actions.py — the ``github_actions`` CI provider.

Thin wrapper over ``gh pr checks``, the exact invocation
``maestro/core/pr_merge.py:run_gh`` already uses to gate a merge on CI state
(PLAN-PLN-MSO-2026-0504 §10.4 — no second implementation of the same call).
"""

from __future__ import annotations

import json
import shutil
from pathlib import Path
from typing import Any, Optional

from maestro.core.proc import run_hidden
from maestro.providers.base import CiProvider

_TIMEOUT = 30
_DEFAULT_HOST = "github.com"


class GithubActionsCiProvider(CiProvider):
    id = "github_actions"

    def __init__(self, config: dict[str, Any] | None = None, workspace: Optional[Path] = None) -> None:
        super().__init__(config)
        self._cwd = Path(self.config.get("repoPath") or workspace or Path.cwd())
        self._slug: Optional[str] = self.config.get("slug") or None

    def _host(self) -> str:
        return str(self.config.get("host") or _DEFAULT_HOST)

    def available(self) -> tuple[bool, str]:
        if shutil.which("gh") is None:
            return False, "gh CLI not installed"

        host = self._host()
        try:
            from maestro.egress.filter import EgressFilter
            ef = EgressFilter.from_workspace(self._cwd)
            if not ef.is_allowed(host):
                return False, f"host not permitted: '{host}' is not in allowedDestinations"
        except Exception:
            pass

        try:
            r = run_hidden(["gh", "auth", "status"], capture_output=True, text=True, timeout=10)
        except Exception as exc:
            return False, f"gh auth status failed ({exc})"
        if r.returncode != 0:
            return False, "gh not authenticated"
        return True, ""

    def checks_for_pr(self, pr: dict) -> list[dict]:
        number = pr.get("number")
        if not number:
            return []
        args = ["gh", "pr", "checks", str(number), "--json", "name,state,conclusion"]
        if self._slug:
            args += ["--repo", self._slug]
        try:
            r = run_hidden(args, capture_output=True, text=True, timeout=_TIMEOUT, cwd=str(self._cwd))
        except Exception:
            return []
        if r.returncode != 0 or not r.stdout.strip():
            return []
        try:
            raw = json.loads(r.stdout)
        except Exception:
            return []
        return [
            {
                "name": c.get("name"),
                "status": c.get("state"),
                "conclusion": c.get("conclusion"),
            }
            for c in raw
        ]
