"""maestro/providers/ci/none.py — the explicit no-op CI provider. See
maestro/providers/scm/none.py for the rationale (§10.3): "no CI configured"
is a reportable state, never a silent pass.
"""

from __future__ import annotations

from maestro.providers.base import CiProvider


class NoneCiProvider(CiProvider):
    id = "none"

    def available(self) -> tuple[bool, str]:
        return False, "no ci provider configured"

    def checks_for_pr(self, pr: dict) -> list[dict]:
        return []
