"""maestro/providers/issues/none.py — the explicit no-op issues provider."""

from __future__ import annotations

from typing import Any, Optional

from maestro.providers.base import IssuesProvider


class NoneIssuesProvider(IssuesProvider):
    id = "none"

    def available(self) -> tuple[bool, str]:
        return False, "no issues provider configured"

    def get_issue(self, ref: str) -> Optional[dict]:
        return None

    def update_issue(self, ref: str, **fields: Any) -> bool:
        return False

    def close_issue(self, ref: str) -> bool:
        return False
