"""maestro/providers/issues/github_issues.py — the ``github_issues`` provider.

Thin wrapper over ``gh issue view`` / ``gh issue edit`` / ``gh issue close`` —
the same ``gh`` subcommand family used elsewhere in the codebase (§10.4).
"""

from __future__ import annotations

import json
import shutil
from pathlib import Path
from typing import Any, Optional

from maestro.core.proc import run_hidden
from maestro.providers.base import IssuesProvider

_TIMEOUT = 30
_DEFAULT_HOST = "github.com"


class GithubIssuesProvider(IssuesProvider):
    id = "github_issues"

    def __init__(self, config: dict[str, Any] | None = None, workspace: Optional[Path] = None) -> None:
        super().__init__(config)
        self._cwd = Path(self.config.get("repoPath") or workspace or Path.cwd())
        self._slug: Optional[str] = self.config.get("slug") or None

    def _host(self) -> str:
        return str(self.config.get("host") or _DEFAULT_HOST)

    def _repo_args(self) -> list[str]:
        return ["--repo", self._slug] if self._slug else []

    def available(self) -> tuple[bool, str]:
        if shutil.which("gh") is None:
            return False, "gh CLI not installed"

        host = self._host()
        try:
            from maestro.egress.filter import EgressFilter
            ef = EgressFilter.from_workspace(self._cwd)
            if not ef.is_allowed(host):
                return False, f"host not permitted: '{host}' is not in allowedDestinations"
        except Exception:
            pass

        try:
            r = run_hidden(["gh", "auth", "status"], capture_output=True, text=True, timeout=10)
        except Exception as exc:
            return False, f"gh auth status failed ({exc})"
        if r.returncode != 0:
            return False, "gh not authenticated"
        return True, ""

    def get_issue(self, ref: str) -> Optional[dict]:
        args = ["gh", "issue", "view", str(ref), "--json",
                "number,title,state,url,closed"] + self._repo_args()
        try:
            r = run_hidden(args, capture_output=True, text=True, timeout=_TIMEOUT, cwd=str(self._cwd))
        except Exception:
            return None
        if r.returncode != 0:
            return None
        try:
            return json.loads(r.stdout)
        except Exception:
            return None

    def update_issue(self, ref: str, **fields: Any) -> bool:
        args = ["gh", "issue", "edit", str(ref)] + self._repo_args()
        body = fields.get("body")
        title = fields.get("title")
        if body is not None:
            args += ["--body", str(body)]
        if title is not None:
            args += ["--title", str(title)]
        if body is None and title is None:
            return False  # nothing to update — never a load-bearing no-op call
        try:
            r = run_hidden(args, capture_output=True, text=True, timeout=_TIMEOUT, cwd=str(self._cwd))
        except Exception:
            return False
        return r.returncode == 0

    def close_issue(self, ref: str) -> bool:
        args = ["gh", "issue", "close", str(ref)] + self._repo_args()
        try:
            r = run_hidden(args, capture_output=True, text=True, timeout=_TIMEOUT, cwd=str(self._cwd))
        except Exception:
            return False
        return r.returncode == 0
