"""maestro/providers/scm — source-control providers (github, none)."""
