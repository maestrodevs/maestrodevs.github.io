"""maestro/providers/scm/github.py — the ``github`` SCM provider.

PLAN-PLN-MSO-2026-0504 §10.4: this is a THIN WRAPPER over the same ``gh`` CLI
invocations ``maestro/core/fleet_runner.py`` already relies on for its
authoritative PR-state logic (``_gh_pr_view`` / ``_gh_pr_by_number`` —
FTR-MSO-2026-0426's "PR record is authoritative" rule: ``merged`` is
strategy-blind, so squash/rebase/merge-commit all resolve correctly). This
module mirrors that exact invocation shape rather than inventing a second one
— ``fleet_runner.py``'s 18 call sites are NOT migrated to call through here in
this order (§10.4 scope note); a later order moves them to be callers of this
provider instead of re-implementing it a third time.

Every method is best-effort and never raises: a missing ``gh`` binary, an
unauthenticated session, or an API error yields ``None``/``[]``/``False``,
exactly like ``fleet_runner._gh_pr_view``'s "enrichment only, never
load-bearing" contract. Only :meth:`available` distinguishes *why* nothing
came back, for the patrol's skip reporting (§10.3).
"""

from __future__ import annotations

import json
import shutil
from pathlib import Path
from typing import Any, Optional

from maestro.core.proc import run_hidden
from maestro.providers.base import ScmProvider

_TIMEOUT = 30
_DEFAULT_HOST = "github.com"


class GithubScmProvider(ScmProvider):
    id = "github"

    def __init__(self, config: dict[str, Any] | None = None, workspace: Optional[Path] = None) -> None:
        super().__init__(config)
        self._cwd = Path(self.config.get("repoPath") or workspace or Path.cwd())
        self._slug: Optional[str] = self.config.get("slug") or None

    def _host(self) -> str:
        return str(self.config.get("host") or _DEFAULT_HOST)

    def available(self) -> tuple[bool, str]:
        if shutil.which("gh") is None:
            return False, "gh CLI not installed"

        host = self._host()
        try:
            from maestro.egress.filter import EgressFilter
            ef = EgressFilter.from_workspace(self._cwd)
            if not ef.is_allowed(host):
                # PLAN-PLN-MSO-2026-0504 §10.2 / order-4 AC: a non-allowlisted
                # host surfaces as "skipped — host not permitted" — the
                # "host not permitted" prefix is a marker resolve_explain()
                # recognises to skip its normal "<kind> provider '<id>'
                # unavailable: ..." wrapping for this specific case.
                return False, f"host not permitted: '{host}' is not in allowedDestinations"
        except Exception:
            pass  # egress module unavailable/misconfigured — do not block on a non-security-relevant failure

        try:
            r = run_hidden(["gh", "auth", "status"], capture_output=True, text=True, timeout=10)
        except Exception as exc:
            return False, f"gh auth status failed ({exc})"
        if r.returncode != 0:
            return False, "gh not authenticated"
        return True, ""

    def _repo_args(self) -> list[str]:
        return ["--repo", self._slug] if self._slug else []

    def get_pr_for_branch(self, branch: str) -> Optional[dict]:
        args = [
            "gh", "pr", "view", branch, "--json",
            "number,title,state,isDraft,merged,mergedAt,mergeCommit,url,headRefName,baseRefName,mergeable",
        ] + self._repo_args()
        try:
            r = run_hidden(args, capture_output=True, text=True, timeout=_TIMEOUT, cwd=str(self._cwd))
        except Exception:
            return None
        if r.returncode != 0:
            return None
        try:
            return json.loads(r.stdout)
        except Exception:
            return None

    def pr_is_draft(self, pr: dict) -> bool:
        return bool(pr.get("isDraft", False))

    def pr_is_merged(self, pr: dict) -> bool:
        if "merged" in pr:
            return bool(pr.get("merged"))
        return pr.get("state") == "MERGED"

    def pr_review_threads(self, pr: dict) -> list[dict]:
        """Review threads via the same GraphQL query as the documented PR-ship
        procedure (CLAUDE.md "Phase 2 — Resolve Copilot comments")."""
        slug = self._slug
        number = pr.get("number")
        if not slug or not number or "/" not in slug:
            return []
        owner, _, repo = slug.partition("/")
        query = (
            "query($o:String!,$r:String!,$p:Int!){"
            "repository(owner:$o,name:$r){pullRequest(number:$p){"
            "reviewThreads(first:50){nodes{id isResolved "
            "comments(first:1){nodes{author{login} body}}}}}}}"
        )
        args = [
            "gh", "api", "graphql", "-f", f"query={query}",
            "-F", f"o={owner}", "-F", f"r={repo}", "-F", f"p={int(number)}",
        ]
        try:
            r = run_hidden(args, capture_output=True, text=True, timeout=_TIMEOUT, cwd=str(self._cwd))
        except Exception:
            return []
        if r.returncode != 0:
            return []
        try:
            data = json.loads(r.stdout)
            nodes = (
                data.get("data", {})
                .get("repository", {})
                .get("pullRequest", {})
                .get("reviewThreads", {})
                .get("nodes", [])
            )
        except Exception:
            return []
        threads: list[dict] = []
        for node in nodes:
            comments = node.get("comments", {}).get("nodes", [])
            author = comments[0].get("author", {}).get("login") if comments else None
            threads.append({
                "id": node.get("id"),
                "isResolved": bool(node.get("isResolved")),
                "author": author,
            })
        return threads
