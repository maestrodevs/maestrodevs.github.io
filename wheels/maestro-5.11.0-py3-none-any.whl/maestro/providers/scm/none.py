"""maestro/providers/scm/none.py — the explicit no-op SCM provider.

PLAN-PLN-MSO-2026-0504 §10.3: an org running no SCM integration (or one this
Maestro version does not yet speak — Bitbucket/Jira are later orders) still
gets a real, resolvable provider rather than a crash or a silent pass. This
provider is always *unavailable* — its whole purpose is to make "unconfigured"
an explicit, reportable state instead of an absence.
"""

from __future__ import annotations

from typing import Optional

from maestro.providers.base import ScmProvider


class NoneScmProvider(ScmProvider):
    id = "none"

    def available(self) -> tuple[bool, str]:
        return False, "no scm provider configured"

    def get_pr_for_branch(self, branch: str) -> Optional[dict]:
        return None

    def pr_is_draft(self, pr: dict) -> bool:
        return False

    def pr_review_threads(self, pr: dict) -> list[dict]:
        return []

    def pr_is_merged(self, pr: dict) -> bool:
        return False
