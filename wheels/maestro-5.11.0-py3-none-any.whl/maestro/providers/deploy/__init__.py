"""maestro/providers/deploy — deployment providers.

Only ``none`` ships in this order (PLAN-PLN-MSO-2026-0504 §10.4). Amplify,
GCP, Docker, OpenShift and Podman are named as later, additive orders — the
point of the seam is that adding them is a new module, not a rewrite.
"""
