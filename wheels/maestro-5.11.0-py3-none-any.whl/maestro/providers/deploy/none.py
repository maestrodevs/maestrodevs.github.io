"""maestro/providers/deploy/none.py — the explicit no-op deploy provider.

The only deploy provider shipped in this order — every real deploy target
(Amplify, GCP, Docker, OpenShift, Podman) is a later, additive order.
"""

from __future__ import annotations

from typing import Optional

from maestro.providers.base import DeployProvider


class NoneDeployProvider(DeployProvider):
    id = "none"

    def available(self) -> tuple[bool, str]:
        return False, "no deploy provider configured"

    def last_deployment(self, env: str) -> Optional[dict]:
        return None
