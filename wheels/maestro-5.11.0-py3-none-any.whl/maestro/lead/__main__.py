# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Entry point for the detached LEAD daemon process:

    python -m maestro.lead --artefact-root PATH

Spawned by :func:`maestro.lead.daemon.start`. Loops forever: run one wake
cycle (:func:`maestro.lead.agent.run_once`), sleep for the configured
heartbeat interval, repeat. There is no in-loop stop check by design — like
`maestro/hub/__main__.py`, termination is external (SIGTERM / taskkill from
:func:`maestro.lead.daemon.stop`), not a polled flag.

The per-tick termination contract (DONE / REPORTED_BACK — Captain ruling D8)
governs a single wake cycle, not this outer loop: the daemon process itself
is meant to run indefinitely (that is its entire purpose per §3.1 — durable
across dispatcher restarts and closed sessions), but every wake cycle it
runs is bounded and reports a terminal state rather than free-running.
"""

from __future__ import annotations

import argparse
import time
from pathlib import Path

from maestro.lead.agent import load_lead_config, run_once


def main() -> None:
    ap = argparse.ArgumentParser(description="Maestro LEAD resident daemon")
    ap.add_argument("--artefact-root", required=True, help="Path to the workspace's .mso/ dir")
    # FTR-MSO-2026-0585 (RC-2): the product-repo root, threaded from
    # maestro.lead.daemon.start()'s own workspace_root argument. Optional —
    # a daemon started without it (or spawned by an older caller) keeps
    # running exactly as before; run_once() simply gets workspace=None,
    # which is today's behaviour.
    ap.add_argument("--workspace", default=None, help="Product-repo root (RC-2 root-pinning)")
    args = ap.parse_args()

    artefact_root = Path(args.artefact_root)
    workspace = Path(args.workspace) if args.workspace else None

    while True:
        config = load_lead_config(artefact_root)
        # Passed conditionally, not as workspace=workspace unconditionally,
        # so a caller with no workspace reproduces the EXACT prior call
        # signature — not merely the same runtime behaviour.
        kwargs = {"config": config}
        if workspace is not None:
            kwargs["workspace"] = workspace
        run_once(artefact_root, **kwargs)
        time.sleep(max(1, config["heartbeatSeconds"]))


if __name__ == "__main__":
    main()
