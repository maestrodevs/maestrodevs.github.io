# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""maestro/lead — the resident per-workspace LEAD sub-agent.

PLAN-PLN-MSO-2026-0504 §3 (Dimension B4): a long-lived, local, per-workspace
process that wakes on a heartbeat (and, from a later order, lifecycle
events), calls `mso doctor`, and reports. It is a detached daemon
(:mod:`maestro.lead.daemon`) supervised by nothing and discoverable by an
identity-verified PID record — never a dispatcher child and never a crew
slot, because its whole purpose is to still be there when the dispatcher is
not (§3.1/§3.2).

:mod:`maestro.lead.agent` defines what one wake cycle actually DOES and,
per Captain ruling D8 (2026-08-25, FTR-MSO-2026-0536), the termination
contract every LEAD task must satisfy: it reaches DONE, or it REPORTS BACK.
A configurable token ceiling is a backstop against runaway spend, not the
condition that decides when work is finished — hitting it is itself an
abnormal report-back, never a routine exit.

This order (FTR-MSO-2026-0536) builds the daemon lifecycle, the process-
identity liveness check, the tier gate, and the task termination contract.
Later orders (plan §14, order 7 "LEAD bands + event catalogue") plug the
lifecycle-event tailer and the act-and-inform action bands into the same
contract — they do not need a second termination model.
"""

from __future__ import annotations
