"""
Identity file loader — FTR-ADM-2026-0054 / FTR-ADM-2026-0067.

FTR-ADM-2026-0067 (LKT T-1.4 / T-5.1): every identity file is verified against
the commit-based integrity guard before its contents are trusted.  Verification
is skipped when enterprise mode is disabled (workspace.json enterprise: false/absent).
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

from .types import UserRecord, GroupRecord, AclEntry


def _warn_integrity_dropped(path: Path, exc: Exception) -> None:
    """Emit a visible warning when a listing skips an identity file.

    BUG-MSO-2026-0409 F4/F5: ``list_users``/``list_groups`` used to silently drop any
    file that failed the integrity check (``except Exception: continue``), which MASKS
    tampering evidence — a forged/tampered file just vanished from the listing with no
    signal. Integrity failures are now logged to stderr so the operator sees that a file
    was refused (other parse errors are logged too, at a lower emphasis).
    """
    from .integrity import IdentityIntegrityError
    if isinstance(exc, IdentityIntegrityError):
        print(
            f"[Identity] WARNING: refusing tampered/unverifiable identity file "
            f"'{path.name}' — {exc.reason}. It is omitted from the listing "
            f"(BUG-MSO-2026-0409).",
            file=sys.stderr,
        )
    else:
        print(
            f"[Identity] WARNING: skipping unreadable identity file '{path.name}': {exc}",
            file=sys.stderr,
        )


def _integrity_check(path: Path, identity_dir: Path, workspace: Path) -> None:
    """Verify identity-file integrity when enterprise or governed-enforce mode is active.

    * Governed **enforce** mode (``resolve_governed_mode == "enforce"``) —
      BUG-MSO-2026-0409: the integrity anchor MUST be an Ed25519-signed manifest
      verified against an out-of-workspace key. A git-committed-but-forged file, or
      a forged/unsigned self-adjacent manifest, is refused. No auto-build of an
      (worthless) unsigned manifest happens here — enforce fails closed instead.
    * Plain enterprise (non-enforce) — legacy behaviour: git-committed OR unsigned
      hash-manifest, auto-building the manifest on first run.
    * Neither — no-op.
    """
    from .gate import _load_enterprise_flag
    from maestro.governance import resolve_governed_mode

    enterprise = _load_enterprise_flag(workspace)
    enforce = resolve_governed_mode(workspace) == "enforce"
    if not enterprise and not enforce:
        return

    # Resolve repo root (walk up to find .git)
    repo_root = workspace
    for candidate in [workspace, *workspace.parents]:
        if (candidate / ".git").exists():
            repo_root = candidate
            break

    from .integrity import verify_integrity, build_initial_manifest

    if enforce:
        # Tamper-resistant anchor required — do NOT fall back to git/unsigned.
        verify_integrity(
            path, repo_root, identity_dir, require_signed=True, workspace=workspace
        )
        return

    # Legacy enterprise path: build the unsigned manifest on first run, then verify.
    manifest_path = identity_dir / "integrity.json"
    if not manifest_path.exists():
        build_initial_manifest(identity_dir, repo_root)

    verify_integrity(path, repo_root, identity_dir)


def _resolve_workspace(users_or_groups_dir: Path) -> tuple[Path, Path]:
    """Return (identity_dir, workspace) given a users/ or groups/ dir."""
    identity_dir = users_or_groups_dir.parent
    workspace = identity_dir.parent.parent  # .mso/identity -> .mso -> workspace
    return identity_dir, workspace


def load_user(users_dir: Path, email: str) -> UserRecord | None:
    path = users_dir / f"{email}.json"
    if not path.exists():
        return None
    identity_dir, workspace = _resolve_workspace(users_dir)
    _integrity_check(path, identity_dir, workspace)
    data = json.loads(path.read_text(encoding="utf-8"))
    return UserRecord(
        email=data["email"],
        display_name=data["displayName"],
        groups=data.get("groups", []),
        providers=data.get("providers", {}),
        public_key=data.get("publicKey"),
        enrolled_at=data.get("enrolledAt"),
        last_seen_at=data.get("lastSeenAt"),
    )


def load_group(groups_dir: Path, name: str) -> GroupRecord | None:
    path = groups_dir / f"{name}.json"
    if not path.exists():
        return None
    identity_dir, workspace = _resolve_workspace(groups_dir)
    _integrity_check(path, identity_dir, workspace)
    data = json.loads(path.read_text(encoding="utf-8"))
    return GroupRecord(
        name=data["name"],
        members=data.get("members", []),
        description=data.get("description"),
    )


def load_acl(acl_path: Path) -> list[AclEntry]:
    if not acl_path.exists():
        return []
    # acl_path is identity_dir/access.json
    identity_dir = acl_path.parent
    workspace = identity_dir.parent.parent
    _integrity_check(acl_path, identity_dir, workspace)
    data = json.loads(acl_path.read_text(encoding="utf-8"))
    return [
        AclEntry(
            principal=e["principal"],
            capability=e["capability"],
            scope=e["scope"],
        )
        for e in data.get("entries", [])
    ]


def save_user(users_dir: Path, record: UserRecord) -> None:
    users_dir.mkdir(parents=True, exist_ok=True)
    # Preserve existing _meta (restricted flag, custom dataClassification, etc.)
    existing_meta: dict = {}
    existing_path = users_dir / f"{record.email}.json"
    if existing_path.exists():
        try:
            existing_meta = json.loads(existing_path.read_text(encoding="utf-8")).get("_meta", {})
        except Exception:
            pass
    data: dict = {
        "email": record.email,
        "displayName": record.display_name,
        "groups": record.groups,
    }
    if record.providers:
        data["providers"] = record.providers
    if record.public_key:
        data["publicKey"] = record.public_key
    if record.enrolled_at:
        data["enrolledAt"] = record.enrolled_at
    if record.last_seen_at:
        data["lastSeenAt"] = record.last_seen_at
    # Always write _meta with dataClassification for GDPR compliance
    existing_meta.setdefault("dataClassification", ["email", "displayName"])
    data["_meta"] = existing_meta
    path = users_dir / f"{record.email}.json"
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    _update_manifest_if_enterprise(path, identity_dir=users_dir.parent, workspace=users_dir.parent.parent)


def save_group(groups_dir: Path, record: GroupRecord) -> None:
    groups_dir.mkdir(parents=True, exist_ok=True)
    data: dict = {"name": record.name, "members": record.members}
    if record.description:
        data["description"] = record.description
    path = groups_dir / f"{record.name}.json"
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    _update_manifest_if_enterprise(path, identity_dir=groups_dir.parent, workspace=groups_dir.parent.parent)


def save_acl(acl_path: Path, entries: list[AclEntry]) -> None:
    acl_path.parent.mkdir(parents=True, exist_ok=True)
    data = {
        "entries": [
            {"principal": e.principal, "capability": e.capability, "scope": e.scope}
            for e in entries
        ]
    }
    acl_path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    identity_dir = acl_path.parent
    _update_manifest_if_enterprise(acl_path, identity_dir=identity_dir, workspace=identity_dir.parent.parent)


def _update_manifest_if_enterprise(path: Path, identity_dir: Path, workspace: Path) -> None:
    """After a save, update the integrity manifest when enterprise mode is active."""
    from .gate import _load_enterprise_flag
    if not _load_enterprise_flag(workspace):
        return
    from .integrity import update_manifest
    update_manifest(path, identity_dir)


# Default groups + ACL seeded by a fresh identity store. Shared by `mso
# identity init` (maestro/cli.py `_identity_init`) and profile-driven
# onboarding (`maestro.enrolment.apply.maybe_seed_identity`, §7.4).
_DEFAULT_GROUPS = ("captains", "fleet_operators", "contributors", "auditors")


def seed_identity(identity_dir: Path, users_dir: Path, groups_dir: Path, acl_path: Path) -> dict:
    """Idempotently seed default groups, a starter ACL, and the workspace
    signing key. Safe to call repeatedly — only creates what is missing.

    Returns a summary dict (`defaultGroups`, `createdGroups`, `aclSeeded`,
    `aclPath`, `signingKeyPath`, `signingKeyCreated`) describing what this
    call actually did, so callers can report it without re-deriving it.
    """
    import base64
    import os as _os
    import secrets as _secrets

    users_dir.mkdir(parents=True, exist_ok=True)
    groups_dir.mkdir(parents=True, exist_ok=True)

    created_groups = []
    for gname in _DEFAULT_GROUPS:
        grp_path = groups_dir / f"{gname}.json"
        if not grp_path.exists():
            save_group(groups_dir, GroupRecord(name=gname, members=[]))
            created_groups.append(gname)

    acl_seeded = False
    if not acl_path.exists():
        entries = [
            AclEntry("group:captains",        "*",               "*"),
            AclEntry("group:fleet_operators", "fleet.dispatch",  "*"),
            AclEntry("group:fleet_operators", "bridge.start",    "*"),
            AclEntry("group:fleet_operators", "bridge.stop",     "*"),
            AclEntry("group:fleet_operators", "backup.create",   "*"),
            AclEntry("group:fleet_operators", "audit.read",      "*"),
            AclEntry("group:contributors",    "order.create",    "*"),
            AclEntry("group:contributors",    "voyage.view",     "*"),
            AclEntry("group:contributors",    "audit.read",      "*"),
            AclEntry("group:auditors",        "audit.read",      "*"),
            AclEntry("group:auditors",        "audit.export",    "*"),
            AclEntry("group:auditors",        "audit.anchor",    "*"),
        ]
        save_acl(acl_path, entries)
        acl_seeded = True

    signing_key_path = identity_dir / "workspace-signing.key"
    signing_key_created = False
    if not signing_key_path.exists():
        key_bytes = _secrets.token_bytes(32)
        signing_key_path.write_text(
            base64.b64encode(key_bytes).decode("ascii") + "\n", encoding="utf-8"
        )
        try:
            _os.chmod(signing_key_path, 0o600)
        except Exception:
            pass
        signing_key_created = True

    return {
        "identity_dir": str(identity_dir),
        "default_groups": list(_DEFAULT_GROUPS),
        "created_groups": created_groups,
        "acl_seeded": acl_seeded,
        "acl_path": str(acl_path),
        "signing_key_path": str(signing_key_path),
        "signing_key_created": signing_key_created,
    }


def list_users(users_dir: Path) -> list[UserRecord]:
    if not users_dir.exists():
        return []
    records = []
    for path in sorted(users_dir.glob("*.json")):
        try:
            identity_dir, workspace = _resolve_workspace(users_dir)
            _integrity_check(path, identity_dir, workspace)
            data = json.loads(path.read_text(encoding="utf-8"))
            records.append(UserRecord(
                email=data["email"],
                display_name=data["displayName"],
                groups=data.get("groups", []),
                providers=data.get("providers", {}),
                public_key=data.get("publicKey"),
                enrolled_at=data.get("enrolledAt"),
            ))
        except Exception as exc:
            _warn_integrity_dropped(path, exc)
            continue
    return records


def list_groups(groups_dir: Path) -> list[GroupRecord]:
    if not groups_dir.exists():
        return []
    records = []
    for path in sorted(groups_dir.glob("*.json")):
        try:
            identity_dir, workspace = _resolve_workspace(groups_dir)
            _integrity_check(path, identity_dir, workspace)
            data = json.loads(path.read_text(encoding="utf-8"))
            records.append(GroupRecord(
                name=data["name"],
                members=data.get("members", []),
                description=data.get("description"),
            ))
        except Exception as exc:
            _warn_integrity_dropped(path, exc)
            continue
    return records
