"""
Identity file integrity guard — FTR-ADM-2026-0067 / LKT finding T-1.4 / T-5.1.

Two trust models, selected by the caller:

* **Legacy (non-enforce)** — every identity file must be either committed to git
  with no uncommitted modifications, OR present in ``integrity.json`` with a
  matching SHA-256 hash. Retained for backward compatibility with non-governed
  enterprise workspaces.

* **Enforce (governed) mode** — BUG-MSO-2026-0409 / SEC-FTR-0398 F3. The legacy
  model is forgeable by a *local-write* attacker: git-committing a forged
  ``access.json`` satisfies the git check, and a matching self-adjacent
  ``integrity.json`` satisfies the hash check (the manifest itself was unsigned).
  In enforce mode the trust anchor is instead an **Ed25519-signed manifest**
  whose signature is verified against a trusted key resolved from **outside the
  workspace** (env keyring + vendor keyring — never the workspace's own
  ``governance.trustedKeys`` pins, which a local attacker could swap). A forged
  file, a forged/unsigned manifest, or a manifest re-signed with an untrusted key
  are all REFUSED. This reuses the Phase-2 governance signing machinery
  (``maestro.governance.verify`` + ``maestro.governance.keys``).

Failing the active model raises IdentityIntegrityError, blocking identity load.
"""
from __future__ import annotations

import base64
import hashlib
import json
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path


INTEGRITY_MANIFEST = "integrity.json"

# Signed-manifest envelope keys (see sign_manifest / verify_signed_manifest).
_MANIFEST_KEY = "manifest"
_SIGNATURE_KEY = "signature"


class IdentityIntegrityError(RuntimeError):
    """Raised when an identity file fails both git-committed and hash-manifest checks."""

    def __init__(self, path: Path, reason: str) -> None:
        self.path = path
        self.reason = reason
        super().__init__(
            f"[Identity] Integrity check failed for {path}: {reason}. "
            "Refusing to load identity — fix by committing the file or running "
            "'adm identity' mutations to update the integrity manifest."
        )


@dataclass
class IntegrityResult:
    path: Path
    passed: bool
    method: str  # "git-committed" | "hash-manifest" | "signed-manifest" | "not-found" | "failed"
    reason: str


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    h.update(path.read_bytes())
    return h.hexdigest()


def _is_git_committed(path: Path, repo_root: Path) -> bool:
    """Return True if path is tracked by git and has no uncommitted changes."""
    try:
        rel = path.relative_to(repo_root).as_posix()
    except ValueError:
        return False

    # Check that the file is tracked (exits 0) and not modified/staged
    r1 = subprocess.run(
        ["git", "ls-files", "--error-unmatch", rel],
        capture_output=True,
        cwd=str(repo_root),
    )
    if r1.returncode != 0:
        return False

    r2 = subprocess.run(
        ["git", "status", "--porcelain", rel],
        capture_output=True,
        text=True,
        cwd=str(repo_root),
    )
    return r2.returncode == 0 and r2.stdout.strip() == ""


def _load_manifest(identity_dir: Path) -> dict[str, str]:
    manifest_path = identity_dir / INTEGRITY_MANIFEST
    if not manifest_path.exists():
        return {}
    try:
        return json.loads(manifest_path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def verify_integrity(
    path: Path,
    repo_root: Path,
    identity_dir: Path,
    *,
    require_signed: bool = False,
    workspace: Path | None = None,
) -> IntegrityResult:
    """
    Verify the integrity of *path*.

    ``require_signed=False`` (default, legacy / non-enforce): *path* passes if it
    is git-committed (clean) OR matches the (unsigned) hash manifest.

    ``require_signed=True`` (enforce / governed mode — BUG-MSO-2026-0409): the ONLY
    accepted proof is a match against a **signed** ``integrity.json`` whose Ed25519
    signature verifies against a trusted key resolved from OUTSIDE the workspace.
    git-committed alone is NOT accepted, and an unsigned / forged / untrusted-key
    manifest is refused. This is the tamper-resistant trust anchor a local-write
    attacker cannot forge.

    Raises IdentityIntegrityError when the active model's checks fail.
    Returns IntegrityResult describing which check passed.
    """
    if not path.exists():
        # Non-existent files trivially pass (load_* returns None anyway)
        return IntegrityResult(path=path, passed=True, method="not-found", reason="file does not exist")

    if require_signed:
        return _verify_signed(path, identity_dir, workspace=workspace)

    # Check 1: committed to git with no modifications
    if _is_git_committed(path, repo_root):
        return IntegrityResult(path=path, passed=True, method="git-committed", reason="tracked and clean")

    # Check 2: hash manifest
    manifest = _load_manifest(identity_dir)
    try:
        rel_key = path.relative_to(identity_dir).as_posix()
    except ValueError:
        rel_key = path.name

    recorded = manifest.get(rel_key)
    if recorded is not None:
        actual = _sha256(path)
        if actual == recorded:
            return IntegrityResult(path=path, passed=True, method="hash-manifest", reason="hash matches manifest")
        raise IdentityIntegrityError(
            path,
            f"SHA-256 mismatch (manifest={recorded[:12]}… actual={actual[:12]}…) — file may have been tampered",
        )

    # Neither check passed
    raise IdentityIntegrityError(
        path,
        "file is not committed to git and has no entry in integrity.json",
    )


# ---------------------------------------------------------------------------
# Signed-manifest trust anchor (enforce mode) — BUG-MSO-2026-0409 / SEC-FTR-0398 F3
#
# The manifest is an Ed25519-signed envelope:
#
#     {
#       "manifest": { "access.json": "<sha256>", "users/alice.json": "<sha256>", ... },
#       "signature": { "algorithm": "ed25519", "keyId": "<id>", "value": "<base64>" }
#     }
#
# The signature is verified against a key resolved from OUTSIDE the workspace
# (``resolve_key(key_id, workspace=None)`` → env keyring + vendor keyring). The
# workspace's own ``governance.trustedKeys`` pins are deliberately NOT consulted:
# a local-write attacker who can rewrite workspace.json must not be able to pin
# their own public key and self-sign a forged ACL.
# ---------------------------------------------------------------------------

def is_signed_manifest(raw: object) -> bool:
    """True when *raw* is a signed-manifest envelope (has both ``manifest`` +
    ``signature`` objects), as opposed to a legacy flat ``{rel_key: hash}`` map."""
    return (
        isinstance(raw, dict)
        and isinstance(raw.get(_MANIFEST_KEY), dict)
        and isinstance(raw.get(_SIGNATURE_KEY), dict)
    )


def _load_manifest_raw(identity_dir: Path) -> object | None:
    """Return the parsed integrity manifest (any shape), or None if absent/unreadable."""
    manifest_path = identity_dir / INTEGRITY_MANIFEST
    if not manifest_path.exists():
        return None
    try:
        return json.loads(manifest_path.read_text(encoding="utf-8"))
    except Exception:
        return None


def manifest_is_signed(identity_dir: Path) -> bool:
    """True when `identity_dir/integrity.json` exists and is a signed-manifest
    envelope. Structural shape check only (does not verify the Ed25519
    signature itself — that is `verify_signed_manifest`'s job, which needs a
    trusted key resolved and raises on any problem). Used by the FTR-MSO-2026-0482
    `mso setup --check` validator, which only needs to know whether the ACL
    is signed at all, not whether the signature verifies against a
    currently-pinned key."""
    raw = _load_manifest_raw(identity_dir)
    return raw is not None and is_signed_manifest(raw)


def verify_signed_manifest(raw: object, *, path: Path | None = None) -> str:
    """Verify the Ed25519 signature over a signed manifest envelope.

    The signing key is resolved from OUT-OF-WORKSPACE sources only (env + vendor
    keyring); the workspace's own pins are never trusted here. Returns the verified
    ``keyId`` on success; raises IdentityIntegrityError on any failure (fail closed).
    """
    from maestro.governance import verify as _gverify
    from maestro.governance import keys as _gkeys
    from maestro.governance.schema import GovernanceError

    ref = path if path is not None else Path(INTEGRITY_MANIFEST)

    if not is_signed_manifest(raw):
        raise IdentityIntegrityError(
            ref, "integrity manifest is not a signed envelope (missing 'manifest'/'signature')"
        )
    assert isinstance(raw, dict)  # narrowed by is_signed_manifest

    env = raw[_SIGNATURE_KEY]
    algo = env.get("algorithm", _gverify.ALGORITHM)
    if algo != _gverify.ALGORITHM:
        raise IdentityIntegrityError(ref, f"unsupported manifest signature algorithm '{algo}'")

    key_id = env.get("keyId")
    if not isinstance(key_id, str) or not key_id:
        raise IdentityIntegrityError(ref, "manifest signature envelope missing 'keyId'")

    value = env.get("value")
    if not isinstance(value, str) or not value:
        raise IdentityIntegrityError(ref, "manifest signature envelope missing base64 'value'")
    try:
        sig = base64.b64decode(value, validate=True)
    except Exception as exc:  # noqa: BLE001
        raise IdentityIntegrityError(ref, f"manifest signature 'value' is not valid base64: {exc}") from exc
    if len(sig) != 64:
        raise IdentityIntegrityError(ref, f"manifest Ed25519 signature must be 64 bytes, got {len(sig)}")

    # Resolve the trust anchor from OUTSIDE the workspace (workspace=None → env +
    # vendor keyring). This is the property a local-write attacker cannot forge.
    try:
        key = _gkeys.resolve_key(key_id, None)
    except GovernanceError as exc:
        raise IdentityIntegrityError(
            ref,
            f"manifest signing key '{key_id}' is not a trusted out-of-workspace key: {exc}",
        ) from exc

    if not _gverify.verify_bundle(raw, key.public_key, sig):
        raise IdentityIntegrityError(
            ref,
            f"manifest signature verification FAILED (keyId={key_id}) — the manifest "
            "was forged, tampered, or re-signed with a key not in the pinned trust root",
        )
    return key_id


def _verify_signed(path: Path, identity_dir: Path, *, workspace: Path | None = None) -> IntegrityResult:
    """Enforce-mode verification: *path*'s hash must match a signed manifest entry."""
    manifest_path = identity_dir / INTEGRITY_MANIFEST
    raw = _load_manifest_raw(identity_dir)
    if raw is None:
        raise IdentityIntegrityError(
            path,
            f"no readable integrity manifest at {manifest_path} — enforce mode requires "
            "an Ed25519-signed manifest anchored to an out-of-workspace key",
        )
    if not is_signed_manifest(raw):
        raise IdentityIntegrityError(
            path,
            "integrity manifest is UNSIGNED — enforce mode refuses the legacy self-adjacent "
            "manifest (it is forgeable by a local writer); sign it with the org key off-client",
        )

    key_id = verify_signed_manifest(raw, path=manifest_path)  # raises if signature is bad

    assert isinstance(raw, dict)
    hash_map = raw[_MANIFEST_KEY]
    try:
        rel_key = path.relative_to(identity_dir).as_posix()
    except ValueError:
        rel_key = path.name

    recorded = hash_map.get(rel_key)
    if not isinstance(recorded, str):
        raise IdentityIntegrityError(
            path,
            f"file has no entry in the signed integrity manifest (keyId={key_id}) — "
            "a file the org has not signed is not trusted",
        )
    actual = _sha256(path)
    if actual != recorded:
        raise IdentityIntegrityError(
            path,
            f"SHA-256 mismatch vs the signed manifest (signed={recorded[:12]}… "
            f"actual={actual[:12]}…, keyId={key_id}) — file has been tampered with",
        )
    return IntegrityResult(
        path=path, passed=True, method="signed-manifest",
        reason=f"hash matches signed manifest (keyId={key_id})",
    )


# ---------------------------------------------------------------------------
# Signed-manifest authoring (OFF-CLIENT — the org holds the Ed25519 seed)
#
# These helpers produce the signed manifest. The private seed lives off-client
# (exactly like policy-bundle signing in maestro.governance.signing.sign_bundle),
# so this is a maintainer/operator authoring path, not a runtime one.
# ---------------------------------------------------------------------------

def compute_hash_map(identity_dir: Path) -> dict[str, str]:
    """SHA-256 every identity JSON under *identity_dir* (excluding the manifest)."""
    out: dict[str, str] = {}
    for p in sorted(identity_dir.rglob("*.json")):
        if p.name == INTEGRITY_MANIFEST:
            continue
        try:
            rel_key = p.relative_to(identity_dir).as_posix()
        except ValueError:
            rel_key = p.name
        out[rel_key] = _sha256(p)
    return out


def sign_manifest(hash_map: dict[str, str], seed: bytes, key_id: str) -> dict:
    """Build a signed-manifest envelope over *hash_map*. Requires the org Ed25519 seed."""
    from maestro.governance import verify as _gverify

    payload = {_MANIFEST_KEY: dict(sorted(hash_map.items()))}
    sig = _gverify.sign(seed, _gverify.canonical_bytes(payload))
    signed = dict(payload)
    signed[_SIGNATURE_KEY] = {
        "algorithm": _gverify.ALGORITHM,
        "keyId": key_id,
        "value": base64.b64encode(sig).decode("ascii"),
    }
    return signed


def write_signed_manifest(identity_dir: Path, seed: bytes, key_id: str) -> Path:
    """Recompute all identity hashes, sign them, and write ``integrity.json`` atomically."""
    signed = sign_manifest(compute_hash_map(identity_dir), seed, key_id)
    manifest_path = identity_dir / INTEGRITY_MANIFEST
    _write_atomically(manifest_path, json.dumps(signed, indent=2, sort_keys=True))
    return manifest_path


# Env channel carrying the org Ed25519 SIGNING SEED (32-byte private key) for the
# `mso identity sign-acl` authoring command. The seed is a secret that lives
# off-client (the org holds it); it is supplied only at signing time and never
# persisted into the workspace. Distinct from MAESTRO_GOVERNANCE_TRUSTED_KEYS,
# which carries PUBLIC verification keys.
SIGNING_SEED_ENV = "MAESTRO_IDENTITY_SIGNING_KEY"


def decode_seed(raw: str) -> bytes:
    """Decode a base64 or hex string into a 32-byte Ed25519 signing seed.

    Accepts standard/url-safe base64 or hex. Raises ``ValueError`` on any input
    that does not resolve to exactly 32 bytes — a fail-closed signal for the
    signing command (a bad seed must never silently produce a mis-signed manifest).
    """
    if not isinstance(raw, str) or not raw.strip():
        raise ValueError("signing seed is empty")
    s = raw.strip()
    data: bytes | None = None
    # Try hex first only when it looks like hex (even length, hex alphabet);
    # otherwise base64 (some base64 strings are also valid hex-length).
    for decoder in (
        lambda: base64.b64decode(s, validate=True),
        lambda: base64.urlsafe_b64decode(s + "=" * (-len(s) % 4)),
        lambda: bytes.fromhex(s),
    ):
        try:
            candidate = decoder()
        except Exception:
            continue
        if len(candidate) == 32:
            data = candidate
            break
    if data is None:
        raise ValueError(
            "signing seed must decode (base64 or hex) to exactly 32 bytes"
        )
    return data


def resolve_signing_seed(
    key_file: "str | Path | None" = None,
    env: "dict | None" = None,
) -> bytes:
    """Resolve the org Ed25519 signing seed from a file or the env channel.

    Resolution order: ``--key-file`` path (if given) > ``MAESTRO_IDENTITY_SIGNING_KEY``
    env var. The file/var holds the 32-byte seed as base64 or hex. Raises
    ``ValueError`` when no seed source is available or the value is malformed —
    the caller (``mso identity sign-acl``) turns that into a clean CLI error.
    """
    import os as _os

    env = env if env is not None else _os.environ
    if key_file is not None:
        p = Path(key_file)
        if not p.exists():
            raise ValueError(f"signing key file not found: {p}")
        return decode_seed(p.read_text(encoding="utf-8"))

    raw = env.get(SIGNING_SEED_ENV, "")
    if raw.strip():
        return decode_seed(raw)

    raise ValueError(
        "no signing seed provided — pass --key-file PATH or set "
        f"{SIGNING_SEED_ENV} to the org Ed25519 seed (base64 or hex, 32 bytes)"
    )


# ---------------------------------------------------------------------------
# Manifest management (called by adm identity mutations)
# ---------------------------------------------------------------------------

def update_manifest(path: Path, identity_dir: Path) -> None:
    """Recompute the hash for *path* and write it into integrity.json atomically."""
    manifest_path = identity_dir / INTEGRITY_MANIFEST
    manifest: dict[str, str] = {}
    if manifest_path.exists():
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        except Exception:
            manifest = {}

    try:
        rel_key = path.relative_to(identity_dir).as_posix()
    except ValueError:
        rel_key = path.name

    manifest[rel_key] = _sha256(path)
    _write_atomically(manifest_path, json.dumps(manifest, indent=2, sort_keys=True))


def remove_from_manifest(path: Path, identity_dir: Path) -> None:
    """Remove *path*'s entry from integrity.json (called on delete mutations)."""
    manifest_path = identity_dir / INTEGRITY_MANIFEST
    if not manifest_path.exists():
        return
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except Exception:
        return

    try:
        rel_key = path.relative_to(identity_dir).as_posix()
    except ValueError:
        rel_key = path.name

    manifest.pop(rel_key, None)
    _write_atomically(manifest_path, json.dumps(manifest, indent=2, sort_keys=True))


def _write_atomically(dest: Path, content: str) -> None:
    """Write *content* to *dest* via a temp file to avoid partial writes."""
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = tempfile.NamedTemporaryFile(
        mode="w", encoding="utf-8", dir=dest.parent, delete=False, suffix=".tmp"
    )
    try:
        tmp.write(content)
        tmp.flush()
        tmp.close()
        Path(tmp.name).replace(dest)
    except Exception:
        Path(tmp.name).unlink(missing_ok=True)
        raise


# ---------------------------------------------------------------------------
# Migration helper
# ---------------------------------------------------------------------------

def build_initial_manifest(identity_dir: Path, repo_root: Path) -> None:
    """
    First-time migration: build integrity.json from all current identity files.

    All files must be committed to git; uncommitted files cause refusal (raise
    IdentityIntegrityError).  Only call this when integrity.json does not yet exist.
    """
    manifest_path = identity_dir / INTEGRITY_MANIFEST
    if manifest_path.exists():
        return  # Already initialised — do nothing.

    identity_files = [
        p for p in identity_dir.rglob("*.json")
        if p.name != INTEGRITY_MANIFEST
    ]

    for f in identity_files:
        if not _is_git_committed(f, repo_root):
            raise IdentityIntegrityError(
                f,
                "integrity.json does not exist yet (first-time migration) and this file "
                "is not committed to git — commit all identity files before running adm",
            )

    manifest: dict[str, str] = {}
    for f in identity_files:
        try:
            rel_key = f.relative_to(identity_dir).as_posix()
        except ValueError:
            rel_key = f.name
        manifest[rel_key] = _sha256(f)

    _write_atomically(manifest_path, json.dumps(manifest, indent=2, sort_keys=True))
    print(f"[Identity] Integrity manifest initialised with {len(manifest)} file(s).")
