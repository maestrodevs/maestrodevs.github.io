"""Signed custom-pack distribution — ``--pack <url>`` (FTR-MSO-2026-0481).

PLAN-PLN-MSO-2026-0449 Order 5, released under Captain ruling D4 (option a),
2026-08-18.

D4: a LOCAL DIRECTORY pack (``--pack ./my-pack``) is ungated — the
authoring/evaluation loop, and it only ever touches the author's own machine
(see ``_resolve_pack_arg`` in ``maestro/cli.py``). A REMOTE pack
(``--pack <url>``) crosses onto another machine and is the commercial line:
it requires a Team/Enterprise licence. The gate is on TRANSPORT (a network
fetch), never on the pack's own self-asserted ``tier`` field —
``Pack.is_free()`` is literally ``self.tier == "free"``, a field the pack
AUTHOR writes; a customer pack could trivially declare ``tier: "free"`` and
walk straight through a tier check keyed on it. Local-vs-remote cannot be
forged by the pack author, which is why D4 gates on it instead.

Vendor countersignature of customer packs was explicitly REJECTED by D4 — it
would make Maestro a gatekeeper on a customer's internal process. So this
module verifies a pack's OWN signature against the OWN trusted-key registry
(``maestro.governance.keys`` — vendor + home + workspace pins, whatever the
customer has chosen to trust), not a Maestro-controlled one.

Archive format — a single JSON envelope fetched over HTTP(S), reusing the
exact signed-bundle envelope shape ``maestro.governance.signing`` already
verifies (so this deliberately does NOT invent a second signature path):

    {
      "bundleId": "<pack id — must equal the extracted pack.json's own id>",
      "version": 1,
      "algorithm": "sha256",
      "archive": "<base64 tar.gz of the pack directory>",
      "files": {"pack.json": "<sha256 hex>", "roles/BLD.md": "<sha256 hex>", ...},
      "signature": {"algorithm": "ed25519", "keyId": "...", "value": "<base64 sig>"}
    }

Verification, in order (mirrors ``governance/loader.py:83`` ``_verify_pack``'s
verify-before-load shape, extended with the signature envelope):

  1. ``governance.signing.verify_signed_bundle`` — Ed25519 signature over the
     canonical (signature-stripped) envelope, key resolved from the SAME
     trusted-key registry signed policy bundles use, plus anti-rollback and a
     freshness stamp. ``require_signature=True``: an unsigned remote pack is
     refused outright, never silently loaded unverified.
  2. Per-file SHA-256 against the ``files`` manifest, once the archive is
     extracted — CRLF-normalised hash, the same BUG-001 lesson
     (``governance/loader.py``) that a benign line-ending transform must not
     trip integrity. Every extracted file must appear in the manifest (an
     archive member the signed manifest doesn't name is refused, not
     silently loaded) and every manifest entry must be present in the
     archive.

Scope (Captain, 2026-08-18, PLAN-0449 §7): this makes tampering EVIDENT, not
IMPOSSIBLE. On a developer-owned machine no client-side control achieves
absolute prevention — branch protection plus human review remain the
load-bearing control. This module is not, and must not become, anti-tamper
machinery.
"""
from __future__ import annotations

import base64
import hashlib
import io
import json
import tarfile
import tempfile
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Optional

from maestro.packs.loader import Pack, PackSchemaError, load_pack_from_dir

_TIMEOUT_SECONDS = 20

Fetcher = Callable[[str], bytes]


class SignedPackError(Exception):
    """Raised when a remote signed-pack archive fails fetch, format, or
    per-file integrity verification. Signature/trust failures raise
    ``maestro.governance.schema.GovernanceError`` instead (from
    ``verify_signed_bundle``) — callers typically catch both.
    """


def _default_fetch(url: str) -> bytes:
    req = urllib.request.Request(url, headers={"Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=_TIMEOUT_SECONDS) as resp:  # noqa: S310 (https default)
        return resp.read()


def _sha256_canonical(data: bytes) -> str:
    """CRLF-normalised SHA-256 — mirrors ``governance/loader.py``'s ``_sha256``."""
    return hashlib.sha256(data.replace(b"\r\n", b"\n")).hexdigest()


def _safe_extract(archive_bytes: bytes, dest: Path) -> None:
    """Extract a tar.gz into *dest*, refusing any member that would escape it.

    Rejects symlinks/hardlinks and anything that resolves outside *dest*
    (absolute paths, ``..`` traversal) BEFORE calling ``extractall`` — a
    minimal, version-portable guard rather than relying on the ``filter=``
    kwarg (Python 3.12+ only; this project's floor is 3.9).
    """
    dest.mkdir(parents=True, exist_ok=True)
    dest_resolved = dest.resolve()
    with tarfile.open(fileobj=io.BytesIO(archive_bytes), mode="r:gz") as tar:
        members = tar.getmembers()
        for member in members:
            if member.issym() or member.islnk():
                raise SignedPackError(
                    f"archive member '{member.name}' is a symlink/hardlink — refusing to extract"
                )
            if not (member.isfile() or member.isdir()):
                raise SignedPackError(
                    f"archive member '{member.name}' is not a regular file or directory"
                )
            member_path = (dest / member.name).resolve()
            if not member_path.is_relative_to(dest_resolved):
                raise SignedPackError(
                    f"archive member '{member.name}' escapes the extraction root — refusing to extract"
                )
        tar.extractall(dest, members=members)  # membership already vetted above


def build_pack_envelope(pack_dir: Path, *, bundle_id: str, version: int = 1) -> dict:
    """Build an UNSIGNED envelope (tarball + per-file SHA-256 manifest) from a
    pack directory on disk.

    Authoring/test helper only — mirrors ``governance.signing.sign_bundle``'s
    role: signing keys live off-client, so producing (and signing, via
    ``maestro.governance.signing.sign_bundle`` — reused as-is, not
    reimplemented here) a distributable pack archive is a maintainer/test
    fixture concern, never a client-runtime path.
    """
    files: dict[str, str] = {}
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as tar:
        for path in sorted(pack_dir.rglob("*")):
            if path.is_file():
                rel = path.relative_to(pack_dir).as_posix()
                files[rel] = _sha256_canonical(path.read_bytes())
                tar.add(path, arcname=rel)
    return {
        "bundleId": bundle_id,
        "version": version,
        "algorithm": "sha256",
        "archive": base64.b64encode(buf.getvalue()).decode("ascii"),
        "files": files,
    }


def load_pack_from_url(
    url: str,
    *,
    workspace: Optional[Path] = None,
    fetcher: Optional[Fetcher] = None,
    now: Optional[datetime] = None,
    artefact_root: Optional[Path] = None,
    extract_root: Optional[Path] = None,
) -> Pack:
    """Fetch, verify, and load a signed custom-pack archive from *url*.

    Raises ``SignedPackError`` on fetch/format/extraction/per-file-integrity
    failures, or ``maestro.governance.schema.GovernanceError`` on
    signature/trust/anti-rollback failures — both are hard failures, never a
    silent fall-through to "load anyway". Callers gate the TIER check
    (Team/Enterprise) themselves, same as ``_resolve_pack_arg`` does for the
    bare-name built-in path — this function's job is fetch + verify + load,
    not licensing.
    """
    from maestro.governance.signing import verify_signed_bundle

    now = now or datetime.now(timezone.utc)
    fetch = fetcher or _default_fetch

    try:
        raw_bytes = fetch(url)
    except (urllib.error.URLError, urllib.error.HTTPError, OSError, TimeoutError) as exc:
        raise SignedPackError(f"could not fetch signed pack from {url}: {exc}") from exc

    try:
        envelope = json.loads(raw_bytes.decode("utf-8"))
    except Exception as exc:  # noqa: BLE001
        raise SignedPackError(f"signed pack at {url} is not valid JSON: {exc}") from exc

    if not isinstance(envelope, dict):
        raise SignedPackError(f"signed pack at {url} is not a JSON object")

    # Signature + trusted-key resolution + anti-rollback + freshness stamp.
    # require_signature=True: an unsigned remote pack is refused outright.
    verify_signed_bundle(
        envelope, workspace=workspace, now=now, record=True,
        require_signature=True, artefact_root=artefact_root,
    )

    files = envelope.get("files")
    if not isinstance(files, dict) or not files:
        raise SignedPackError(f"signed pack at {url} has no 'files' integrity manifest")

    archive_b64 = envelope.get("archive")
    if not isinstance(archive_b64, str) or not archive_b64:
        raise SignedPackError(f"signed pack at {url} has no 'archive' payload")
    try:
        archive_bytes = base64.b64decode(archive_b64, validate=True)
    except Exception as exc:  # noqa: BLE001
        raise SignedPackError(f"signed pack at {url}: 'archive' is not valid base64: {exc}") from exc

    pack_id = envelope.get("bundleId")
    if not pack_id:
        raise SignedPackError(f"signed pack at {url} has no 'bundleId'")

    root = Path(extract_root) if extract_root is not None else Path(tempfile.mkdtemp(prefix="mso-pack-"))
    pack_dir = root / pack_id
    _safe_extract(archive_bytes, pack_dir)

    extracted_files = {
        p.relative_to(pack_dir).as_posix() for p in pack_dir.rglob("*") if p.is_file()
    }
    unmanifested = extracted_files - set(files)
    if unmanifested:
        raise SignedPackError(
            f"signed pack '{pack_id}': archive contains file(s) not in the signed "
            f"manifest — {sorted(unmanifested)}. Refusing to load."
        )

    for rel_path, expected_hash in files.items():
        member_path = pack_dir / rel_path
        if not member_path.is_file():
            raise SignedPackError(
                f"signed pack '{pack_id}': manifest lists '{rel_path}' but the "
                "archive does not contain it"
            )
        actual_hash = _sha256_canonical(member_path.read_bytes())
        if actual_hash != expected_hash:
            raise SignedPackError(
                f"signed pack '{pack_id}': file '{rel_path}' failed integrity check "
                f"(manifest={expected_hash[:12]}… actual={actual_hash[:12]}…) "
                "— archive may have been tampered."
            )

    try:
        return load_pack_from_dir(pack_dir)
    except PackSchemaError as exc:
        raise SignedPackError(f"signed pack '{pack_id}' failed manifest validation: {exc}") from exc
