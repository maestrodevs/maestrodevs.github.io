"""maestro.packs — division-pack loading, discovery, and workspace scaffolding.

A *division pack* templates Maestro's persona + role + order-type surface for a
non-SDLC delivery team (Test Engineering, SecOps, DevOps, …). A pack is pure
DATA and requires no engine change — see PLAN-PLN-MSO-2026-0371 section 5.

Public surface:
    load_builtin(id)        → Pack           (built-in pack by id)
    builtin_names()         → list[str]      (available built-in pack ids)
    load_all_builtin()      → list[Pack]     (every valid built-in pack)
    load_pack_from_dir(p)   → Pack           (pack in an arbitrary directory)
    load_pack_from_url(url) → Pack           (FTR-MSO-2026-0481 — signed remote pack archive)
    apply_pack(pack, base, dry_run=False) → PackScaffoldResult (scaffold a workspace)
    describe_pack_scaffold_result(pack, result) → list[str]  (report lines for a result)
    resolve_profile_pack_pin(workspace)   → dict | None  (enrolment profile's pack.id/locked pin)
    validate_pack_dir(p)    → dict[str, list[str]]  (full-content validation, one pack)
    validate_all_packs()    → dict[str, dict[str, list[str]]]  (every built-in pack)
    Pack, PackSchemaError, SignedPackError
"""

from .loader import (
    Pack,
    PackSchemaError,
    builtin_names,
    load_all_builtin,
    load_builtin,
    load_pack_from_dict,
    load_pack_from_dir,
    resolve_profile_pack_pin,
)
from .remote import SignedPackError, build_pack_envelope, load_pack_from_url
from .scaffold import PackScaffoldResult, apply_pack, describe_pack_scaffold_result
from .validate import builtin_pack_root, validate_all_packs, validate_pack_dir

__all__ = [
    "Pack",
    "PackSchemaError",
    "PackScaffoldResult",
    "SignedPackError",
    "apply_pack",
    "build_pack_envelope",
    "builtin_names",
    "builtin_pack_root",
    "describe_pack_scaffold_result",
    "load_all_builtin",
    "load_builtin",
    "load_pack_from_dict",
    "load_pack_from_dir",
    "load_pack_from_url",
    "resolve_profile_pack_pin",
    "validate_all_packs",
    "validate_pack_dir",
]
