"""maestro/patrol/resolver.py — four-tier patrol-definition resolution.

PLAN-PLN-MSO-2026-0504 §5 (Enterprise tailoring, following the FTR-MSO-2026-0502
precedent verbatim): a patrol definition is DATA, resolved

    signed policy bundle > division pack > workspace.json > shipped default

per-check (never whole-document replace — §5.3: "a tier that wants to change
one threshold does not have to restate all twelve"), with the 0502 fail-safe
rule on any malformed tier (§5.5: fall back to the FULL shipped default, never
a subset, and say so loudly) and Captain decision D1's monotonic governed
override (§5.4): a signed policy bundle's check settings are a FLOOR a lower
tier may only tighten, never loosen, without a breakglass grant — reusing
``maestro.governance.breakglass`` verbatim rather than inventing a second
escape hatch, per §5.4 point 3.

Resolution never raises. Any failure at any tier — missing file, invalid
JSON, schema-invalid, or the tier's own loader raising for any other reason —
collapses the WHOLE resolution to the full shipped default (never a partial
result) and is reported via ``PatrolResolution.invalid`` /
:func:`write_definition_invalid_event`, exactly as PLAN-PLN-MSO-2026-0504 §5.5
requires. This mirrors ``maestro.patrol.run_patrol``'s own per-check
isolation (one broken check must not blind the whole patrol) one layer up:
one broken TIER must not blind the whole resolution either — it just means
that tier's tailoring is unavailable this run, not that `mso doctor` stops
working.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from maestro.patrol.registry import get_check, severity_rank

__all__ = [
    "ResolvedCheck",
    "InvalidDefinition",
    "PatrolResolution",
    "resolve_patrol_definition",
    "write_definition_invalid_event",
]

_SCHEMA_PATH = Path(__file__).parent / "_schema.json"
_DEFAULT_PATH = Path(__file__).parent / "default.json"

# Belt-and-braces literal, used ONLY if maestro/patrol/default.json itself
# cannot be read/parsed/schema-validated (a broken install) — resolution must
# never crash `mso doctor` outright even in that case. Kept in sync with the
# four checks FTR-MSO-2026-0531 actually registered; the other eight ids in
# default.json are forward declarations for later orders and are harmless to
# drop here since a check the registry doesn't know about cannot run anyway.
_HARD_FALLBACK_DEFAULT: dict = {
    "id": "default",
    "checks": [
        {"id": "dispatcher.heartbeat", "enabled": True, "severity": "critical"},
        {"id": "crews.all-crashed", "enabled": True, "severity": "critical"},
        {"id": "orders.awaiting-approval", "enabled": True, "severity": "medium"},
        {"id": "voyages.planned-no-work", "enabled": True, "severity": "high"},
    ],
}


class PatrolDefinitionError(Exception):
    """Raised internally by a single tier's loader. Always caught by
    :func:`resolve_patrol_definition` and converted into the §5.5 fail-safe
    path — never escapes this module."""

    def __init__(self, tier: str, path: str, error: str):
        super().__init__(f"[{tier}] {path}: {error}")
        self.tier = tier
        self.path = path
        self.error = error


@dataclass(frozen=True)
class ResolvedCheck:
    """One check's resolved policy — the merged view a `mso doctor` run
    actually uses, plus which tier supplied it (`mso doctor --explain`)."""

    id: str
    enabled: bool = True
    severity: str = "low"
    scope: str = "workspace"
    params: dict = field(default_factory=dict)
    source_tier: str = "default"


@dataclass(frozen=True)
class InvalidDefinition:
    tier: str
    path: str
    error: str


@dataclass(frozen=True)
class PatrolResolution:
    """The outcome of resolving a patrol definition across all four tiers."""

    checks: "dict[str, ResolvedCheck]"
    unknown_warnings: tuple = ()
    refusals: tuple = ()
    invalid: Optional[InvalidDefinition] = None

    @property
    def banner(self) -> Optional[str]:
        """PLAN-PLN-MSO-2026-0504 §5.5 point 3 — a banner line, not a silent
        degrade. ``None`` when resolution succeeded."""
        if self.invalid is None:
            return None
        return (
            f"custom patrol definition at '{self.invalid.path}' "
            f"(tier: {self.invalid.tier}) failed to load ({self.invalid.error}); "
            f"running the shipped default ({len(self.checks)} checks)"
        )


# --------------------------------------------------------------------------
# Schema validation
# --------------------------------------------------------------------------

def _validate_doc(data: dict, *, tier: str, source: str) -> None:
    import jsonschema

    schema = json.loads(_SCHEMA_PATH.read_text(encoding="utf-8"))
    try:
        jsonschema.validate(data, schema)
    except jsonschema.ValidationError as exc:
        raise PatrolDefinitionError(tier, source, f"schema-invalid: {exc.message}") from exc


# --------------------------------------------------------------------------
# Tier 4 — shipped default
# --------------------------------------------------------------------------

def _load_default_checks() -> "dict[str, dict]":
    try:
        raw = json.loads(_DEFAULT_PATH.read_text(encoding="utf-8"))
        _validate_doc(raw, tier="default", source=str(_DEFAULT_PATH))
    except Exception:  # noqa: BLE001 — never let a broken shipped default crash resolution
        raw = _HARD_FALLBACK_DEFAULT
    return {c["id"]: c for c in raw.get("checks", [])}


# --------------------------------------------------------------------------
# Tier 3 — workspace.json
# --------------------------------------------------------------------------

def _load_workspace_overrides(artefact_root: Path) -> "dict[str, dict]":
    """Reads the `patrol` block of `<artefact_root>/config/workspace.json`.

    The block is EITHER inline (`{"checks": [...]}`, validated against this
    same schema) OR a pointer to a standalone patrol.json (`{"file": "..."}`,
    relative to *artefact_root* unless absolute) — the shape §5.1 shows,
    useful for sharing one definition across workspaces. An absent `patrol`
    key (the common case) is not an error: tier 3 simply contributes nothing.
    """
    ws_path = artefact_root / "config" / "workspace.json"
    if not ws_path.exists():
        return {}
    try:
        cfg = json.loads(ws_path.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001
        raise PatrolDefinitionError("workspace", str(ws_path), f"invalid JSON: {exc}") from exc

    block = cfg.get("patrol")
    if not block:
        return {}
    if not isinstance(block, dict):
        raise PatrolDefinitionError(
            "workspace", f"{ws_path}#patrol", "'patrol' must be an object"
        )

    file_ref = block.get("file")
    if file_ref:
        ref_path = Path(file_ref)
        if not ref_path.is_absolute():
            ref_path = artefact_root / ref_path
        if not ref_path.exists():
            raise PatrolDefinitionError(
                "workspace", str(ref_path), "referenced patrol definition file is missing"
            )
        try:
            doc = json.loads(ref_path.read_text(encoding="utf-8"))
        except Exception as exc:  # noqa: BLE001
            raise PatrolDefinitionError("workspace", str(ref_path), f"invalid JSON: {exc}") from exc
        _validate_doc(doc, tier="workspace", source=str(ref_path))
        return {c["id"]: c for c in doc.get("checks", [])}

    checks = block.get("checks", [])
    _validate_doc({"checks": checks}, tier="workspace", source=f"{ws_path}#patrol")
    return {c["id"]: c for c in checks}


# --------------------------------------------------------------------------
# Tier 2 — division pack
# --------------------------------------------------------------------------

def _load_pack_overrides(workspace: Optional[Path]) -> "dict[str, dict]":
    """The active pack's `patrol.checks`, resolved via the enrolment
    profile's pack pin (PLAN-PLN-MSO-2026-0449 §3.4/§6.2) — the existing,
    live-resolvable "which pack does this workspace run" mechanism, gated the
    same way `mso packs apply` already gates it (pro+; §11's role-restriction
    consistency note applies here too).
    """
    if workspace is None:
        return {}

    from maestro import auth

    if not auth.has_tier({"pro", "team", "enterprise"}):
        return {}

    from maestro.packs import PackSchemaError, load_builtin, resolve_profile_pack_pin

    try:
        pin = resolve_profile_pack_pin(workspace)
    except Exception as exc:  # noqa: BLE001 — "a resolver that raises"
        raise PatrolDefinitionError(
            "pack", "enrolment profile pack pin", f"{type(exc).__name__}: {exc}"
        ) from exc

    if not pin or not pin.get("id"):
        return {}

    pack_id = pin["id"]
    try:
        pack = load_builtin(pack_id)
    except PackSchemaError as exc:
        raise PatrolDefinitionError("pack", f"pack '{pack_id}'", str(exc)) from exc
    except Exception as exc:  # noqa: BLE001
        raise PatrolDefinitionError(
            "pack", f"pack '{pack_id}'", f"{type(exc).__name__}: {exc}"
        ) from exc

    checks = (pack.patrol or {}).get("checks", [])
    return {c["id"]: c for c in checks if "id" in c}


# --------------------------------------------------------------------------
# Tier 1 — signed policy bundle
# --------------------------------------------------------------------------

def _load_bundle_overrides(workspace: Optional[Path]) -> "dict[str, dict]":
    """The highest-authority policy bundle's `patrol.checks`
    (`maestro.governance.loader.load_bundles` — org > workspace > user).
    """
    if workspace is None:
        return {}

    from maestro.governance.loader import load_bundles
    from maestro.governance.schema import TIER_RANK, GovernanceError

    try:
        bundles = load_bundles(workspace)
    except GovernanceError as exc:
        raise PatrolDefinitionError("bundle", "governance policy bundle", str(exc)) from exc
    except Exception as exc:  # noqa: BLE001 — "a resolver that raises"
        raise PatrolDefinitionError(
            "bundle", "governance policy bundle", f"{type(exc).__name__}: {exc}"
        ) from exc

    # Least-authoritative first so the most authoritative bundle (lowest
    # TIER_RANK — org beats workspace beats user, engine.py's own precedence)
    # wins a same-check collision by being applied last.
    ordered = sorted(bundles, key=lambda b: -TIER_RANK.get(b.tier, 99))
    merged: "dict[str, dict]" = {}
    for bundle in ordered:
        patrol = bundle.patrol or {}
        if not patrol:
            continue
        checks = patrol.get("checks", [])
        _validate_doc({"checks": checks}, tier="bundle", source=f"bundle '{bundle.bundle_id}'")
        for c in checks:
            if "id" in c:
                merged[c["id"]] = c
    return merged


# --------------------------------------------------------------------------
# Merge
# --------------------------------------------------------------------------

def _is_looser(field_name: str, candidate: Any, floor: Any) -> bool:
    """True when *candidate* relaxes *floor* for the named field.

    ``enabled``: turning a governed-on check off is a loosen; turning a
    governed-off check on is additional scrutiny, never refused.
    ``severity``: a lower rank is a loosen.
    Numeric ``params``: every threshold this patrol ships (staleSeconds,
    graceMinutes, ageMinutes, …) is "how long before this is a problem" — a
    LARGER value is always more lenient, so a larger candidate is a loosen.
    """
    if field_name == "enabled":
        return floor is True and candidate is False
    if field_name == "severity":
        return severity_rank(candidate) < severity_rank(floor)
    return False


def _seed_from_default(default_checks: "dict[str, dict]") -> "dict[str, ResolvedCheck]":
    resolved: "dict[str, ResolvedCheck]" = {}
    for check_id, ov in default_checks.items():
        resolved[check_id] = ResolvedCheck(
            id=check_id,
            enabled=ov.get("enabled", True),
            severity=ov.get("severity", "low"),
            scope=ov.get("scope", "workspace"),
            params=dict(ov.get("params", {})),
            source_tier="default",
        )
    return resolved


def _apply_plain(resolved: "dict[str, ResolvedCheck]", overrides: "dict[str, dict]", tier: str) -> None:
    """Unconditional per-field overwrite — used for the bundle tier itself
    (it IS the authority, nothing to check it against) and for the accepted
    subset of a lower tier's override after D1 monotonicity has been applied.
    """
    for check_id, ov in overrides.items():
        base = resolved.get(check_id)
        enabled = ov.get("enabled", base.enabled if base else True)
        severity = ov.get("severity", base.severity if base else "low")
        scope = ov.get("scope", base.scope if base else "workspace")
        params = dict(base.params) if base else {}
        params.update(ov.get("params", {}))
        resolved[check_id] = ResolvedCheck(
            id=check_id, enabled=enabled, severity=severity, scope=scope,
            params=params, source_tier=tier,
        )


def _apply_governed(
    resolved: "dict[str, ResolvedCheck]",
    overrides: "dict[str, dict]",
    tier: str,
    governed: "dict[str, dict]",
    refusals: list,
    workspace: Optional[Path],
    env: dict,
) -> None:
    """Layer *overrides* (tier "workspace" or "pack") onto *resolved*,
    refusing any field that loosens a bundle-governed floor unless a
    breakglass grant is present (D1 — PLAN-PLN-MSO-2026-0504 §5.4)."""
    from maestro.governance.breakglass import breakglass_grant, record_policy_event

    for check_id, ov in overrides.items():
        floor = governed.get(check_id)
        accepted: "dict[str, Any]" = {}

        for f in ("enabled", "severity"):
            if f not in ov:
                continue
            fval = ov[f]
            if floor is not None and f in floor and _is_looser(f, fval, floor[f]):
                granted, actor, reason = breakglass_grant(workspace, env)
                if granted:
                    accepted[f] = fval
                    record_policy_event(
                        workspace, "patrol.breakglass", check_id, result="granted",
                        metadata={"field": f, "tier": tier, "value": fval, "reason": reason},
                        actor=actor,
                    )
                else:
                    refusals.append(
                        f"check '{check_id}' {f} override {fval!r} from tier '{tier}' "
                        f"refused — governed floor is {floor[f]!r} (D1 monotonic; no "
                        "breakglass grant present); governed value used."
                    )
                    record_policy_event(
                        workspace, "patrol.override", check_id, result="refused",
                        metadata={"field": f, "tier": tier, "attempted": fval, "governed": floor[f]},
                        actor=actor,
                    )
            else:
                accepted[f] = fval

        if "scope" in ov:
            accepted["scope"] = ov["scope"]

        if "params" in ov:
            floor_params = (floor or {}).get("params", {}) if floor else {}
            accepted_params: "dict[str, Any]" = {}
            for k, v in ov["params"].items():
                governed_v = floor_params.get(k)
                is_numeric_pair = (
                    isinstance(v, (int, float)) and not isinstance(v, bool)
                    and isinstance(governed_v, (int, float)) and not isinstance(governed_v, bool)
                )
                if governed_v is not None and is_numeric_pair and v > governed_v:
                    granted, actor, reason = breakglass_grant(workspace, env)
                    if granted:
                        accepted_params[k] = v
                        record_policy_event(
                            workspace, "patrol.breakglass", check_id, result="granted",
                            metadata={"field": f"params.{k}", "tier": tier, "value": v, "reason": reason},
                            actor=actor,
                        )
                    else:
                        refusals.append(
                            f"check '{check_id}' params.{k} override {v!r} from tier "
                            f"'{tier}' refused — governed floor is {governed_v!r} "
                            "(D1 monotonic; no breakglass grant present); governed value used."
                        )
                        record_policy_event(
                            workspace, "patrol.override", check_id, result="refused",
                            metadata={"field": f"params.{k}", "tier": tier, "attempted": v,
                                      "governed": governed_v},
                            actor=actor,
                        )
                else:
                    accepted_params[k] = v
            if accepted_params:
                accepted["params"] = accepted_params

        if accepted:
            _apply_plain(resolved, {check_id: accepted}, tier)


# --------------------------------------------------------------------------
# Entry point
# --------------------------------------------------------------------------

def _describe_error(exc: Exception) -> InvalidDefinition:
    if isinstance(exc, PatrolDefinitionError):
        return InvalidDefinition(tier=exc.tier, path=exc.path, error=exc.error)
    return InvalidDefinition(
        tier="unknown", path="<patrol resolution>", error=f"{type(exc).__name__}: {exc}"
    )


def _fallback(exc: Exception) -> PatrolResolution:
    return PatrolResolution(
        checks=_seed_from_default(_load_default_checks()),
        unknown_warnings=(),
        refusals=(),
        invalid=_describe_error(exc),
    )


def resolve_patrol_definition(
    artefact_root: Path,
    *,
    workspace: Optional[Path] = None,
    env: Optional[dict] = None,
) -> PatrolResolution:
    """Resolve the effective patrol definition for *artefact_root*.

    *workspace* is the PRODUCT-repo root (the `.mso` parent) — needed to
    resolve division-pack pins and governance policy bundles, both of which
    live relative to it, not to the artefact plane (which may be a separate
    repo in solo/shared artefact-repo mode). ``None`` skips tiers 1 and 2
    (bundle, pack) and resolves workspace.json + the shipped default only —
    the correct degrade for a caller that has no product-repo root to hand
    (e.g. a unit test exercising the default resolution in isolation).

    Never raises: any tier's loader failing collapses the whole resolution to
    the full shipped default (PLAN-PLN-MSO-2026-0504 §5.5).
    """
    artefact_root = Path(artefact_root)
    env = env if env is not None else os.environ
    refusals: list = []

    try:
        default_checks = _load_default_checks()
        governed = _load_bundle_overrides(workspace)
        workspace_overrides = _load_workspace_overrides(artefact_root)
        pack_overrides = _load_pack_overrides(workspace)
    except Exception as exc:  # noqa: BLE001 — §5.5: any tier failing => full fallback
        return _fallback(exc)

    resolved = _seed_from_default(default_checks)

    # Tier 1 (bundle) is the authoritative floor — applied first, unconditionally.
    _apply_plain(resolved, governed, "bundle")
    # Tier 3 (workspace) then tier 2 (pack) — pack outranks workspace, so it is
    # applied last among the two. Each is checked against the bundle FLOOR
    # only (D1), never against each other.
    _apply_governed(resolved, workspace_overrides, "workspace", governed, refusals, workspace, env)
    _apply_governed(resolved, pack_overrides, "pack", governed, refusals, workspace, env)

    unknown_ids = {
        check_id
        for source in (workspace_overrides, pack_overrides, governed)
        for check_id in source
        if get_check(check_id) is None
    }
    unknown_warnings = tuple(sorted(f"unknown check '{cid}' — ignored" for cid in unknown_ids))

    return PatrolResolution(
        checks=resolved,
        unknown_warnings=unknown_warnings,
        refusals=tuple(refusals),
        invalid=None,
    )


def write_definition_invalid_event(artefact_root: Path, invalid: InvalidDefinition) -> None:
    """Append the `PATROL_DEFINITION_INVALID` lifecycle event (§5.5 point 2).
    Best-effort — a logging failure must never crash `mso doctor`."""
    try:
        import datetime as _dt

        log_dir = Path(artefact_root) / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        ts = _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
        message = f"tier={invalid.tier} path={invalid.path} error={invalid.error}"
        line = f"{ts} | {'PATROL_DEFINITION_INVALID':<10} | {message}\n"
        with open(log_dir / "lifecycle.log", "a", encoding="utf-8") as fh:
            fh.write(line)
    except Exception:  # noqa: BLE001
        pass
