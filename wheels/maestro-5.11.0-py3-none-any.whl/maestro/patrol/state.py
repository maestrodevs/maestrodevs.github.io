"""maestro/patrol/state.py — noise control: fingerprints, delta, age escalation,
machine-scope lease.

PLAN-PLN-MSO-2026-0504 §6: a patrol that reports every finding on every tick
trains the operator to ignore it. This module implements the four mechanisms
that keep `mso doctor` quiet on repetition and loud on persistence:

1. **Stable finding identity** — :func:`fingerprint` hashes only
   ``check_id + subject_id + base severity``, deliberately excluding
   volatile fields (ages, free-text detail, counts) so a finding whose age
   advances keeps the same identity across ticks.
2. **Delta-only reporting** — :func:`compute_delta` compares the current
   findings against the persisted state and classifies each as NEW,
   RESOLVED, ESCALATED, or UNCHANGED. Callers report the first three in
   full and the last as a count only (`--all` overrides).
3. **Age escalation** — :func:`escalate_severity` raises a finding's
   reported severity the longer it stays open, so persistence increases
   volume instead of decaying into wallpaper.
4. **Machine-scope lease** — :func:`try_acquire_machine_lease` is the
   first-come, TTL-refreshed gate (`~/.maestro/patrol-machine.lock`) that
   stops N workspaces on one machine each reporting the same machine-wide
   finding (PLAN §7).

State (patrol-state.json) lives under the artefact plane's ``state/``
directory — same gitignored plane as the order ledger (BUG-MSO-2026-0294) —
so it is never committed and never shared across workspaces.
"""

from __future__ import annotations

import hashlib
import json
import os
from dataclasses import dataclass, replace
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

from maestro.patrol.registry import SEVERITIES, Finding, severity_rank
from maestro.workspace import get_maestro_home

STATE_FILENAME = "patrol-state.json"

# Age thresholds from PLAN §6 point 3: "unresolved for 1h -> +0, 24h -> +1
# band, 7d -> +2 bands". Beyond the first week, escalation continues at +1
# band per additional full week so a persistently-open finding keeps getting
# louder rather than freezing at "+2 bands forever" — this is what lets even
# a `low`-severity finding reach `critical` by day 21 (FTR-MSO-2026-0533 AC).
_AGE_BAND_24H = timedelta(hours=24)
_AGE_BAND_7D = timedelta(days=7)

# Machine-scope lease default TTL. Matches the ~5-minute heartbeat cadence
# described in PLAN §12.11 ("Cost shape") — long enough that a lease survives
# comfortably between ticks of the same holder, short enough that another
# workspace picks up machine-scope reporting reasonably soon after the
# holder goes away.
DEFAULT_LEASE_TTL_SECONDS = 300
MACHINE_LOCK_FILENAME = "patrol-machine.lock"


# ---------------------------------------------------------------------------
# Fingerprinting
# ---------------------------------------------------------------------------

def fingerprint(check_id: str, subject_id: str, base_severity: str) -> str:
    """Stable identity for a finding.

    Deliberately excludes everything that changes while a finding stays
    open — age, free-text title/detail, counts embedded in ``detail`` — so
    the SAME underlying problem keeps the SAME fingerprint from the tick it
    first appears until it resolves, even as its reported severity climbs
    via age escalation. ``base_severity`` is the check's own (fixed) verdict
    for this subject, never the age-escalated display severity — escalating
    a finding must never change its identity, or every tick would report it
    as "new" again (FTR-MSO-2026-0533 AC).
    """
    raw = f"{check_id}\x1f{subject_id}\x1f{base_severity}"
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


# ---------------------------------------------------------------------------
# Age escalation
# ---------------------------------------------------------------------------

def age_escalation_bands(age: timedelta) -> int:
    """Number of severity bands to add for a finding that has been open
    continuously for *age*.

    ``< 24h -> 0``, ``24h <= age < 7d -> 1``, ``age >= 7d -> 2`` plus one
    additional band per further full week — so a `low` finding reaches
    `critical` (3 bands) by day 21, matching the plan's worked example.
    """
    if age < _AGE_BAND_24H:
        return 0
    if age < _AGE_BAND_7D:
        return 1
    extra_weeks = (age.days - 7) // 7
    return 2 + extra_weeks


def escalate_severity(base_severity: str, age: timedelta) -> str:
    """Return *base_severity* raised by however many bands *age* earns it,
    clamped at the top of :data:`maestro.patrol.registry.SEVERITIES`."""
    bands = age_escalation_bands(age)
    rank = min(severity_rank(base_severity) + bands, len(SEVERITIES) - 1)
    return SEVERITIES[rank]


# ---------------------------------------------------------------------------
# Delta computation
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class DeltaFinding:
    """One finding as it should be reported this tick — severity already
    reflects age escalation; ``finding.firstSeenAt`` is the TRUE first-seen
    timestamp carried forward from state, not the check's own per-run
    timestamp (checks are pure functions of on-disk state and stamp
    ``firstSeenAt`` with "now" on every single run)."""

    finding: Finding
    fingerprint: str
    age_seconds: float


@dataclass(frozen=True)
class PatrolDelta:
    new: "tuple[DeltaFinding, ...]"
    resolved: "tuple[DeltaFinding, ...]"
    escalated: "tuple[DeltaFinding, ...]"
    unchanged: "tuple[DeltaFinding, ...]"
    generated_at: str

    @property
    def has_changes(self) -> bool:
        """True when there is anything worth telling the operator about.
        False is exactly a "no-change tick" (PLAN §6 point 4)."""
        return bool(self.new or self.resolved or self.escalated)

    def open_findings(self) -> "list[Finding]":
        """Every currently-open finding (new + escalated + unchanged),
        severity already reflecting age escalation. Used by ``--all`` and by
        exit-code computation, which must reflect reality even on a silent
        no-change tick."""
        return [d.finding for d in (*self.new, *self.escalated, *self.unchanged)]

    def open_delta_findings(self) -> "list[DeltaFinding]":
        """Every currently-open finding as its :class:`DeltaFinding` wrapper
        — the fingerprint-carrying counterpart to :meth:`open_findings`.
        Callers that need to key an acknowledgement (PLAN-PLN-MSO-2026-0584
        Dimension D) or any other per-finding identity to a specific finding
        need the stable fingerprint, which the plain ``Finding`` returned by
        ``open_findings`` does not carry."""
        return [*self.new, *self.escalated, *self.unchanged]


def _parse_iso(value: object) -> Optional[datetime]:
    if not isinstance(value, str) or not value:
        return None
    try:
        dt = datetime.fromisoformat(value)
    except ValueError:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt


def compute_delta(
    previous_state: Optional[dict],
    findings: "list[Finding]",
    now: Optional[datetime] = None,
) -> "tuple[PatrolDelta, dict]":
    """Classify *findings* against *previous_state* and return
    ``(delta, new_state)`` — *new_state* is what the caller should persist
    via :func:`save_state` for the next tick.
    """
    now = now or datetime.now(timezone.utc)
    prev_findings = {}
    if isinstance(previous_state, dict):
        prev_findings = previous_state.get("findings") or {}

    seen_fps: set = set()
    new_list: "list[DeltaFinding]" = []
    escalated_list: "list[DeltaFinding]" = []
    unchanged_list: "list[DeltaFinding]" = []
    updated_findings: dict = {}

    for f in findings:
        fp = fingerprint(f.check_id, f.subject_id, f.severity)
        seen_fps.add(fp)
        prev_entry = prev_findings.get(fp) if isinstance(prev_findings, dict) else None

        if prev_entry is None:
            first_seen_at = now
            is_new = True
            prev_reported_severity = f.severity
        else:
            first_seen_at = _parse_iso(prev_entry.get("firstSeenAt")) or now
            is_new = False
            prev_reported_severity = prev_entry.get("lastReportedSeverity", f.severity)

        age = now - first_seen_at
        if age.total_seconds() < 0:
            age = timedelta(0)
        reported_severity = escalate_severity(f.severity, age)

        display_finding = replace(
            f, severity=reported_severity, firstSeenAt=first_seen_at.isoformat()
        )
        delta_finding = DeltaFinding(
            finding=display_finding, fingerprint=fp, age_seconds=age.total_seconds()
        )

        updated_findings[fp] = {
            "checkId": f.check_id,
            "subjectId": f.subject_id,
            "baseSeverity": f.severity,
            "firstSeenAt": first_seen_at.isoformat(),
            "lastSeenAt": now.isoformat(),
            "lastReportedSeverity": reported_severity,
            "title": f.title,
            "detail": f.detail,
            "suggestedCommand": f.suggestedCommand,
            "scope": f.scope,
            "requires": list(f.requires),
        }

        if is_new:
            new_list.append(delta_finding)
        elif severity_rank(reported_severity) > severity_rank(prev_reported_severity):
            escalated_list.append(delta_finding)
        else:
            unchanged_list.append(delta_finding)

    resolved_list: "list[DeltaFinding]" = []
    if isinstance(prev_findings, dict):
        for fp, entry in prev_findings.items():
            if fp in seen_fps or not isinstance(entry, dict):
                continue
            resolved_finding = Finding(
                check_id=entry.get("checkId", ""),
                subject_id=entry.get("subjectId", ""),
                severity=entry.get("baseSeverity", "low"),
                title=entry.get("title", ""),
                detail=entry.get("detail", ""),
                firstSeenAt=entry.get("firstSeenAt", now.isoformat()),
                suggestedCommand=entry.get("suggestedCommand"),
                scope=entry.get("scope", "workspace"),
                requires=tuple(entry.get("requires") or ()),
            )
            resolved_list.append(
                DeltaFinding(finding=resolved_finding, fingerprint=fp, age_seconds=0.0)
            )

    delta = PatrolDelta(
        new=tuple(new_list),
        resolved=tuple(resolved_list),
        escalated=tuple(escalated_list),
        unchanged=tuple(unchanged_list),
        generated_at=now.isoformat(),
    )
    # Preserve every OTHER top-level key from previous_state verbatim (e.g.
    # "acknowledged" — PLAN-PLN-MSO-2026-0584 Dimension D) rather than
    # replacing the whole state wholesale. Both `mso doctor` and the LEAD
    # daemon call save_state(path, new_state) on this return value every
    # single tick — a new_state built from scratch would silently discard
    # any sibling data (like an operator's acknowledgement) on the very next
    # tick after it was written, regardless of which surface wrote it.
    new_state = dict(previous_state) if isinstance(previous_state, dict) else {}
    new_state["findings"] = updated_findings
    new_state["lastRunAt"] = now.isoformat()
    new_state["lastHeartbeatAt"] = now.isoformat()
    return delta, new_state


# ---------------------------------------------------------------------------
# Persisted state I/O
# ---------------------------------------------------------------------------

def default_state_path(artefact_root: Path) -> Path:
    """``<artefact_root>/state/patrol-state.json`` — the same gitignored
    ``state/`` plane as the order ledger (``.mso/state/`` is already
    unconditionally gitignored by ``maestro/init.py``)."""
    return Path(artefact_root) / "state" / STATE_FILENAME


def load_state(path: Path) -> dict:
    """Read persisted patrol state, or ``{}`` if absent/unreadable/corrupt.

    A missing or malformed state file must never crash `mso doctor` — the
    worst case is every current finding being (re)classified as NEW on the
    next tick, which is a noise regression, not a failure (mirrors the
    fail-safe posture PLAN §5.5 requires of patrol *definitions*).
    """
    try:
        raw = path.read_text(encoding="utf-8")
    except OSError:
        return {}
    try:
        data = json.loads(raw)
    except ValueError:
        return {}
    return data if isinstance(data, dict) else {}


def save_state(path: Path, state: dict) -> None:
    """Atomically persist *state* to *path* (write-tmp then ``os.replace``,
    matching ``maestro.core.dep_holds``'s pattern for this gitignored
    runtime plane)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(state, indent=2), encoding="utf-8")
    os.replace(str(tmp), str(path))


def write_heartbeat(path: Path, now: Optional[datetime] = None) -> None:
    """Record that the patrol ran, without touching finding state — the
    no-change-tick case (PLAN §6 point 4): "a patrol that dies silently is
    indistinguishable from a healthy fleet", so a live-but-quiet tick still
    has to leave a trace."""
    now = now or datetime.now(timezone.utc)
    state = load_state(path)
    if not isinstance(state, dict):
        state = {}
    state["lastRunAt"] = now.isoformat()
    state["lastHeartbeatAt"] = now.isoformat()
    save_state(path, state)


# ---------------------------------------------------------------------------
# Acknowledgement (PLAN-PLN-MSO-2026-0584 Dimension D).
#
# The risk is the point of the design: acknowledgement is how a monitoring
# system quietly goes blind, so THREE guards are enforced together, always,
# with no way to bypass any one of them from this module's public surface:
#
#   1. EXPIRY — an ack always lapses (`ttl_days`, default 7). There is no
#      "permanent" option here; permanent suppression is a *policy* decision
#      that belongs in the patrol definition (disabling a check, visibly),
#      never in a one-click operator ack (`acknowledge_finding` rejects
#      `ttl_days <= 0`).
#   2. ESCALATION PIERCES IT — the ack is recorded against the SEVERITY AT
#      ACK TIME (the current, already age-escalated display severity, not
#      the check's fixed base severity `fingerprint()` hashes on). If a
#      finding's escalated severity later climbs past that, the ack no
#      longer covers it. You may accept a `low`; you have not thereby
#      accepted the `critical` it becomes.
#   3. COUNT-PRESERVING — acknowledgement is consulted ONLY by delivery
#      logic (`maestro.lead.agent._deliver_findings`); it has no effect on
#      `compute_delta`, `open_findings()`, or any severity tally. An
#      acknowledged finding stays fully visible in every count and every
#      drawer/CLI listing — suppression means "stop interrupting me", never
#      "pretend it is gone" (the same distinction PLAN Dimension A draws
#      between a stood-down daemon and a dead one).
#
# Storage: a single ``acknowledged`` map at the top level of the SAME
# ``patrol-state.json`` `mso doctor` and the LEAD daemon already share
# (Dimension D's own "both writers, deliberately" decision) — keyed by the
# stable fingerprint, so it survives severity escalation (fingerprint
# excludes escalation by construction) but not the finding resolving and
# reopening as a fresh occurrence (a new fingerprint would be a different
# check_id/subject_id/base_severity triple).
# ---------------------------------------------------------------------------

ACK_TTL_DAYS_DEFAULT = 7


class UnknownFindingError(ValueError):
    """Raised by :func:`acknowledge_finding` when *fingerprint* has no entry
    in the persisted patrol state — it may already be resolved, or the
    fingerprint may simply be wrong. Never silently acks a finding that was
    never actually observed."""


def get_acknowledgement(state: dict, fp: str) -> Optional[dict]:
    """The raw acknowledgement entry for *fp*, or ``None`` if none exists —
    regardless of whether it has expired or been pierced by escalation.
    Callers wanting the LIVE suppression verdict want :func:`is_acknowledged`
    instead; this is for display (e.g. showing "acked by X, expired Y")."""
    acks = state.get("acknowledged") if isinstance(state, dict) else None
    entry = acks.get(fp) if isinstance(acks, dict) else None
    return entry if isinstance(entry, dict) else None


def is_acknowledged(
    state: dict, fp: str, current_severity: str, *, now: Optional[datetime] = None,
) -> bool:
    """True when *fp* has a LIVE, unpierced acknowledgement that should
    suppress delivery of *current_severity* right now.

    False whenever any of: no ack entry exists; the ack has expired
    (guard 1); or *current_severity* outranks the severity the finding was
    acknowledged at (guard 2, escalation pierces the ack). A missing/corrupt
    entry is simply "not acknowledged" — never an error, matching every
    other reader in this module (``load_state`` already fails safe the same
    way for the whole file).
    """
    entry = get_acknowledgement(state, fp)
    if entry is None:
        return False
    now = now or datetime.now(timezone.utc)
    expires_at = _parse_iso(entry.get("expiresAt"))
    if expires_at is None or now >= expires_at:
        return False
    acked_severity = entry.get("severity") or "low"
    return severity_rank(current_severity) <= severity_rank(acked_severity)


def acknowledge_finding(
    artefact_root: Path,
    fp: str,
    *,
    by: str,
    note: str = "",
    now: Optional[datetime] = None,
    ttl_days: int = ACK_TTL_DAYS_DEFAULT,
) -> dict:
    """Record an acknowledgement for *fp*, read-merge-write against the
    shared ``patrol-state.json`` (mirrors
    ``maestro.lead.agent.set_stand_down``'s shape for the same reason: an
    absent/corrupt file starts from ``{}`` rather than failing, and only the
    ``acknowledged`` key is touched — every finding entry and every other
    top-level key survives untouched).

    The severity recorded is the finding's CURRENT persisted
    ``lastReportedSeverity`` (i.e. already age-escalated) — read from the
    SAME ``findings`` map ``compute_delta`` maintains — never a
    caller-supplied value, so "the severity it was acked at" always means
    what the operator actually saw, not what they typed.

    Raises :class:`UnknownFindingError` if *fp* has no entry in the
    persisted ``findings`` map (nothing open with that identity to
    acknowledge) and :class:`ValueError` if *ttl_days* is not positive — an
    acknowledgement that never expires is not a feature this function will
    produce (permanent suppression belongs in the patrol definition,
    visibly, not here).
    """
    if ttl_days <= 0:
        raise ValueError(
            f"ttl_days must be positive (got {ttl_days}) — an acknowledgement "
            f"must always expire; permanent suppression belongs in the patrol "
            f"definition, not in an ack."
        )
    now = now or datetime.now(timezone.utc)
    path = default_state_path(artefact_root)
    state = load_state(path)
    findings = state.get("findings")
    entry = findings.get(fp) if isinstance(findings, dict) else None
    if not isinstance(entry, dict):
        raise UnknownFindingError(
            f"No open finding with fingerprint {fp!r} in the persisted patrol "
            f"state — it may already be resolved, or the fingerprint may be "
            f"wrong. Run `mso doctor --json` to list current fingerprints."
        )
    severity = entry.get("lastReportedSeverity") or entry.get("baseSeverity") or "low"
    acks = state.get("acknowledged") or {}
    ack_entry = {
        "by": by,
        "note": note or "",
        "severity": severity,
        "ackedAt": now.isoformat(),
        "expiresAt": (now + timedelta(days=ttl_days)).isoformat(),
    }
    acks[fp] = ack_entry
    state["acknowledged"] = acks
    save_state(path, state)
    return ack_entry


def unacknowledge_finding(artefact_root: Path, fp: str) -> bool:
    """Remove *fp*'s acknowledgement, if any. Returns whether one existed —
    lets callers (CLI/Hub) tell "cleared" from "nothing to clear" without a
    second read."""
    path = default_state_path(artefact_root)
    state = load_state(path)
    acks = state.get("acknowledged") or {}
    existed = fp in acks
    if existed:
        del acks[fp]
        state["acknowledged"] = acks
        save_state(path, state)
    return existed


# ---------------------------------------------------------------------------
# Machine-scope lease (PLAN §7)
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class MachineLease:
    holder: str
    acquired_at: str
    expires_at: str


def default_machine_lease_path() -> Path:
    """``~/.maestro/patrol-machine.lock`` — resolved via
    :func:`maestro.workspace.get_maestro_home`, never a hand-built
    ``Path.home()`` join (BUG-MSO-2026-0387 forbids that outside
    ``maestro/workspace.py``)."""
    return get_maestro_home() / MACHINE_LOCK_FILENAME


def _read_lease(path: Path) -> Optional[MachineLease]:
    try:
        raw = path.read_text(encoding="utf-8")
    except OSError:
        return None
    try:
        data = json.loads(raw)
    except ValueError:
        return None
    if not isinstance(data, dict):
        return None
    holder = data.get("holder")
    acquired_at = data.get("acquiredAt")
    expires_at = data.get("expiresAt")
    if not holder or not expires_at:
        return None
    return MachineLease(holder=holder, acquired_at=acquired_at or "", expires_at=expires_at)


def _write_lease(path: Path, lease: MachineLease) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".lock.tmp")
    tmp.write_text(
        json.dumps({
            "holder": lease.holder,
            "acquiredAt": lease.acquired_at,
            "expiresAt": lease.expires_at,
        }),
        encoding="utf-8",
    )
    os.replace(str(tmp), str(path))


def try_acquire_machine_lease(
    holder_id: str,
    *,
    ttl_seconds: int = DEFAULT_LEASE_TTL_SECONDS,
    now: Optional[datetime] = None,
    lease_path: Optional[Path] = None,
) -> bool:
    """Claim or renew the machine-scope patrol lease for *holder_id*.

    First-come, TTL-refreshed (PLAN §7): with three workspaces on one
    machine, only ONE holds a live lease at any moment, so only that
    workspace's machine-scope checks (orphan processes, package integrity)
    should be reported — the others must skip them rather than triple-
    reporting the same finding. Returns ``True`` when *holder_id* may run
    (and report) machine-scope checks this tick — either it already holds
    an unexpired lease, or no one else does, so it just claimed/renewed it.
    Returns ``False`` when a DIFFERENT holder's lease is still live.

    This is a best-effort dedup mechanism, not a hard mutex — a read/write
    race between two holders claiming an expired lease in the same instant
    is possible and acceptable (worst case: one tick's machine-scope finding
    is briefly reported twice, not corrupted state).
    """
    now = now or datetime.now(timezone.utc)
    path = lease_path or default_machine_lease_path()
    current = _read_lease(path)

    if current is not None and current.holder != holder_id:
        expires_at = _parse_iso(current.expires_at)
        if expires_at is not None and expires_at > now:
            return False  # someone else holds a live lease

    acquired_at = (
        current.acquired_at
        if current is not None and current.holder == holder_id and current.acquired_at
        else now.isoformat()
    )
    _write_lease(
        path,
        MachineLease(
            holder=holder_id,
            acquired_at=acquired_at,
            expires_at=(now + timedelta(seconds=ttl_seconds)).isoformat(),
        ),
    )
    return True


def release_machine_lease(holder_id: str, *, lease_path: Optional[Path] = None) -> None:
    """Release *holder_id*'s lease if it currently holds one. A no-op
    (never removes another holder's lease) if it does not."""
    path = lease_path or default_machine_lease_path()
    current = _read_lease(path)
    if current is not None and current.holder == holder_id:
        try:
            path.unlink()
        except OSError:
            pass


def filter_by_machine_lease(findings: "list[Finding]", lease_held: bool) -> "list[Finding]":
    """Drop ``scope == "machine"`` findings when *lease_held* is False.

    Workspace-scope findings are always kept — the lease only gates
    machine-scope reporting (PLAN §7). Consumed by whichever caller decides
    it holds the lease this tick (`mso doctor`, or a future resident LEAD
    daemon) — no machine-scope checks exist yet as of this order, so this is
    currently a no-op filter, kept ready for order 5's `machine.*` checks.
    """
    if lease_held:
        return list(findings)
    return [f for f in findings if f.scope != "machine"]
