"""maestro/patrol/checks/machine.py — machine-wide backstop checks.

PLAN-PLN-MSO-2026-0504 §7: these two checks are ``scope="machine"`` —
attributed to the MACHINE, not to any one project, and (via the lease
wired into ``maestro.patrol.run_patrol``) run and report ONCE per `mso
doctor` invocation regardless of how many workspaces are scanned
(FTR-MSO-2026-0535's own acceptance criteria). Both are explicitly a "cheap
backstop", never the fix:

- `machine.orphan-processes` — §4.4: reaping crew descendants is
  BUG-MSO-2026-0500's job (`maestro.core.descendant_reaper`, Windows Job
  Objects / POSIX process groups). That fix is scoped to processes a crew
  explicitly tracked; this check is a best-effort, MACHINE-WIDE scan for the
  exact process-name shape that was measured live on 2026-08-17 (`find`,
  `MSBuild`, `VBCSCompiler`, `dotnet`) whose parent process no longer exists.
  It never kills anything — a check never remediates (registry.py); it only
  counts and reports.

- `machine.package-integrity` — §4.7: `import maestro` resolving to a
  shadowing, debris-filled directory broke `mso version` outright on
  2026-08-17 (CLAUDE.md's "Shadowing" note). Two checks, cheapest-signal
  first: (a) the resolved package directory carries the markers a real
  install always has (`__init__.py`, `cli.py`, `core/`); (b) no `temp/`
  directory sits directly under the package root — a real wheel install
  never ships one; its presence is the exact 136MB crew-debris shape
  CLAUDE.md documents, because `MAESTRO_TEMP` defaults inside site-packages
  (a separately tracked follow-up, §4.7 — not fixed here).
"""

from __future__ import annotations

import json
import os
from pathlib import Path

from maestro.core.proc import run_hidden
from maestro.patrol.registry import CheckContext, Finding, check

# ---------------------------------------------------------------------------
# machine.orphan-processes
# ---------------------------------------------------------------------------

# The exact process shapes measured orphaned on 2026-08-17 (PLAN §4.4: 8
# `find` processes, 14-15 dotnet/MSBuild workers, one VBCSCompiler). Matched
# case-insensitively against the bare process name (no path, no args).
_WATCHED_NAMES = {"find", "find.exe", "msbuild", "msbuild.exe", "vbcscompiler",
                  "vbcscompiler.exe", "dotnet", "dotnet.exe"}


def _list_processes() -> "list[dict]":
    """Best-effort machine-wide process snapshot:
    ``[{"pid": int, "ppid": int, "name": str}, ...]``.

    Returns ``[]`` on ANY failure — this check is a cheap backstop (§4.4),
    never load-bearing, and must never crash `mso doctor` in an environment
    where process enumeration isn't available (a locked-down CI runner, a
    container without `ps`, etc.). Kept as a standalone module-level function
    (rather than inlined) specifically so tests can monkeypatch it directly
    instead of mocking a subprocess call.
    """
    try:
        if os.name == "nt":
            ps_script = (
                "Get-CimInstance Win32_Process | "
                "Select-Object ProcessId,ParentProcessId,Name | ConvertTo-Json -Compress"
            )
            r = run_hidden(
                ["powershell", "-NoProfile", "-Command", ps_script],
                capture_output=True, text=True, timeout=20,
            )
            if r.returncode != 0 or not (r.stdout or "").strip():
                return []
            raw = json.loads(r.stdout)
            if isinstance(raw, dict):
                raw = [raw]
            out = []
            for p in raw:
                pid, ppid, name = p.get("ProcessId"), p.get("ParentProcessId"), p.get("Name")
                if pid is None or name is None:
                    continue
                out.append({"pid": int(pid), "ppid": int(ppid) if ppid is not None else None, "name": str(name)})
            return out
        else:
            r = run_hidden(["ps", "-eo", "pid,ppid,comm"], capture_output=True, text=True, timeout=20)
            if r.returncode != 0:
                return []
            out = []
            for line in (r.stdout or "").splitlines()[1:]:
                parts = line.split(None, 2)
                if len(parts) < 3:
                    continue
                try:
                    out.append({"pid": int(parts[0]), "ppid": int(parts[1]), "name": parts[2]})
                except ValueError:
                    continue
            return out
    except Exception:
        return []


@check(id="machine.orphan-processes", severity="high", scope="machine")
def machine_orphan_processes(context: CheckContext) -> "list[Finding]":
    processes = _list_processes()
    if not processes:
        return []

    all_pids = {p["pid"] for p in processes if p.get("pid") is not None}
    orphans = [
        p for p in processes
        if str(p.get("name") or "").lower() in _WATCHED_NAMES
        and p.get("ppid") not in all_pids
    ]
    if not orphans:
        return []

    names = sorted({p["name"] for p in orphans})
    return [
        Finding(
            check_id="machine.orphan-processes",
            subject_id="machine:orphans",
            severity="high",
            title=f"{len(orphans)} orphaned Maestro-adjacent process(es) found machine-wide",
            detail=(
                f"{len(orphans)} process(es) ({', '.join(names)}) with a parent PID that no "
                "longer exists were found across the whole machine. The reaping fix is "
                "BUG-MSO-2026-0500 (descendant-group reap via Job Objects/process groups); "
                "this is a cheap, best-effort backstop for whatever slips past it, not the "
                "fix itself — it never terminates anything."
            ),
            firstSeenAt=context.now.isoformat(),
            suggestedCommand=None,
            scope="machine",
            requires=(),
        )
    ]


# ---------------------------------------------------------------------------
# machine.package-integrity
# ---------------------------------------------------------------------------

_EXPECTED_MARKERS = ("__init__.py", "cli.py", "core")
# MAESTRO_TEMP's questionable in-package default (§4.7) means a `temp/`
# directory can accumulate directly under the installed package root — a
# shipped wheel never includes one. Its presence there is the exact
# 136MB-of-crew-debris shape from CLAUDE.md's "Shadowing" note. Not fixing
# the MAESTRO_TEMP default itself — flagged there as a follow-up, out of
# scope for this voyage.
_DEBRIS_DIRNAME = "temp"


def _dir_entry_count_and_size(path: Path) -> "tuple[int, int]":
    count = 0
    size = 0
    try:
        for p in path.rglob("*"):
            count += 1
            if p.is_file():
                try:
                    size += p.stat().st_size
                except OSError:
                    pass
    except OSError:
        pass
    return count, size


@check(id="machine.package-integrity", severity="critical", scope="machine")
def machine_package_integrity(context: CheckContext) -> "list[Finding]":
    import maestro as _pkg

    pkg_file = getattr(_pkg, "__file__", None)
    if not pkg_file:
        return [
            Finding(
                check_id="machine.package-integrity",
                subject_id="machine:import-maestro",
                severity="critical",
                title="`import maestro` did not resolve to an on-disk package",
                detail=(
                    "maestro.__file__ is unset — the import resolved to a namespace "
                    "package or a frozen/zip install, not a normal on-disk package."
                ),
                firstSeenAt=context.now.isoformat(),
                suggestedCommand=None,
                scope="machine",
                requires=(),
            )
        ]

    pkg_dir = Path(pkg_file).resolve().parent
    missing = [m for m in _EXPECTED_MARKERS if not (pkg_dir / m).exists()]
    if missing:
        return [
            Finding(
                check_id="machine.package-integrity",
                subject_id=f"machine:{pkg_dir}",
                severity="critical",
                title=f"`import maestro` resolved to {pkg_dir}, which is missing {', '.join(missing)}",
                detail=(
                    f"maestro.__file__ points at {pkg_dir}, but expected marker(s) "
                    f"{', '.join(missing)} are absent — this looks like a shadowing "
                    "directory (crew-written debris with no proper package contents), not "
                    "the real installed package. See CLAUDE.md's 'Shadowing' note."
                ),
                firstSeenAt=context.now.isoformat(),
                suggestedCommand=None,
                scope="machine",
                requires=(),
            )
        ]

    findings: "list[Finding]" = []
    debris_dir = pkg_dir / _DEBRIS_DIRNAME
    if debris_dir.is_dir():
        count, size = _dir_entry_count_and_size(debris_dir)
        findings.append(
            Finding(
                check_id="machine.package-integrity",
                subject_id=f"machine:{debris_dir}",
                severity="critical",
                title=f"Debris directory found inside the installed package: {debris_dir}",
                detail=(
                    f"{debris_dir} contains {count} entr(y/ies) ({size / (1024 * 1024):.1f} MB) "
                    "— a shipped wheel never includes a 'temp/' directory under the package "
                    "root; this is the same shape as the 136MB crew-debris incident "
                    "(CLAUDE.md's Shadowing note, PLAN §4.7). MAESTRO_TEMP defaulting inside "
                    "site-packages is a known, separately-tracked follow-up — not fixed here."
                ),
                firstSeenAt=context.now.isoformat(),
                suggestedCommand=None,
                scope="machine",
                requires=(),
            )
        )
    return findings
