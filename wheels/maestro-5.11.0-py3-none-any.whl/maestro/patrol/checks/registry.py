"""maestro/patrol/checks/registry.py — global project-registry hygiene.

BUG-MSO-2026-0550 (detection half, reimplemented for BUG-MSO-2026-0561):
crew smoke tests (`mso init`, `mso doctor` verification runs) used to
register throwaway projects directly into the operator's REAL global
registry (``~/.maestro/projects.json``) and nothing ever removed them —
SMK/SMK2 (2026-08-25) and INF1/PLAIN1 (2026-07-30) were both this shape,
found only because the Captain happened to notice them in the Hub.
`start_crew_process` (``maestro/core/fleet_runner.py``) now isolates every
crew's ``MAESTRO_HOME`` so this can no longer happen going forward — this
module is the DETECTION half: flag debris that already exists (or slips
past that fix some other way, e.g. a manual smoke test run outside a crew)
so it does not sit undiscovered for a month again.

Every check here is ``scope="machine"`` — the registry lives at
``~/.maestro/projects.json``, one per machine, not tied to any one
project's ``artefact_root`` — so ``run_patrol``'s machine-lease gating
makes all four report ONCE per `mso doctor --all-projects` invocation
across N workspaces, not once per workspace.

DELIBERATELY conservative on severity and on WHEN a check is allowed to
fire, because the acceptance criterion is explicit: a temporarily
unmounted drive, a detached volume, or a deliberately scratch-located
project must never push an operator toward unregistering real work.

- ``registry.unreachable-path`` (low): a missing path alone is genuinely
  ambiguous — it is exactly the shape of a detached/unmounted drive, not
  just debris — so severity stays low regardless of how long the entry has
  been registered (age cannot resolve this ambiguity either way).
- ``registry.missing-workspace`` / ``registry.no-activity`` (low): both
  can describe a legitimate project that is mid-setup (registered, not yet
  `mso init`-ed / not yet worked). Each only fires once the registration
  is older than a grace window (default 60 minutes, per-check
  ``graceMinutes`` param) — "still mid-setup" stops being a plausible
  explanation once enough time has passed.
- ``registry.orphaned-temp-path`` (medium): a path resolving inside a
  system temp directory is a materially stronger signal on its own than
  either check above, but NOT unambiguous by itself — see "the fixture
  problem" below. It fires only on TWO signals together: temp-located AND
  no recorded activity (past the same grace window). A temp-located
  project that HAS real, archived voyages/orders is never flagged,
  regardless of where it lives.

THE FIXTURE PROBLEM (BUG-MSO-2026-0561). The first attempt at this check
(now stripped, see git history) fired on temp-location alone. That is
unsound on its own terms: a `pytest tmp_path` fixture is, by construction,
always inside the system temp directory, so ANY test asserting "a healthy
registry produces zero findings" against a temp-rooted fixture workspace
would trip this check purely from where pytest happened to put it — a
healthy workspace and a temp-located workspace are not mutually exclusive,
so a single-signal check cannot tell them apart. Requiring a SECOND,
independent signal (no recorded activity) resolves this without a test-only
workaround: a temp-located fixture that goes on to create real voyages/
orders (i.e. actually exercises the thing being tested) reads as healthy
and is silent; a temp-located registration that never does anything reads
as debris and fires. This is the same shape as
``orders.dep-satisfied-unreleased``'s grace window and
``hygiene.stale-worktrees``'s "only once archived" gate — every check in
this package treats ambiguity as a reason to require more evidence, not a
reason to guess.

No check here writes or removes anything — each only proposes
``mso projects remove <ACR>`` as a ``suggestedCommand`` for a human to run
(``registry.py``'s "a check may never remediate" rule,
``test_checks_have_no_writer_end_to_end``). Every artefact path is built
from ``maestro.workspace.MSO_DIR_NAME`` rather than a hand-written ``.mso``
literal (FTR-MSO-2026-0362's package-wide audit, `tests/
test_ftr_0362_mso_join_audit.py`) — the previous implementation hand-built
``.mso`` in three places and tripped that same audit.
"""

from __future__ import annotations

import os
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

from maestro import registry
from maestro.patrol.registry import CheckContext, Finding, check
from maestro.workspace import MSO_DIR_NAME

# Same activity signal as fleet_monitor's own archive scan: any archived
# voyage or order, of any status, counts as "this project has been used".
#
# BUG-MSO-2026-0566 finding 4: this list originally omitted "orders/active"
# and the queues/* tree entirely, so a real project with filed-but-not-yet-
# completed work older than the grace window read as "zero voyages or
# orders ever recorded" and was proposed for `mso projects remove` — exactly
# the module's own docstring promise ("must never push an operator toward
# unregistering real work") broken by the check meant to keep it. Filed
# work (an order sitting in queues/orders/, queues/bugs/, etc., or
# orders/active/) is just as much "this project has been used" as an
# archived one. "orders/active" is a flat dir of order JSONs, so it fits
# _has_activity()'s existing per-subdir glob; queues/* is one level deeper
# (queues/orders/*.json, queues/bugs/*.json, ...) and is handled by
# _has_activity() separately below.
_ACTIVITY_SUBDIRS = ("voyages/active", "voyages/complete", "orders/complete",
                     "orders/failed", "orders/active")

# How long a registration must age before "hasn't been set up/used yet"
# stops being a plausible explanation for missing-workspace/no-activity/
# orphaned-temp-path. Overridable per check via patrol_params.graceMinutes.
_DEFAULT_GRACE_MINUTES = 60


def _resolved_lower(path: "os.PathLike | str") -> str:
    """Best-effort ``.resolve()`` (symlinks + ``..`` collapsed) normalised to
    a lowercase string. Falls back to the unresolved path on any OSError
    (e.g. a permissions issue walking a symlink) rather than raising —
    resolution is a precision improvement, not a hard requirement.

    BUG-MSO-2026-0566 finding 5: register_project() stores registry paths
    ``.resolve()``d (maestro/registry.py), so comparing against UNRESOLVED
    temp roots silently fails wherever the temp root itself is a symlink —
    the canonical case being macOS, where ``/tmp`` resolves to
    ``/private/tmp`` and ``/var/folders/...`` to ``/private/var/folders/...``.
    Resolving both sides here (the temp-root candidates AND the path being
    tested) makes the comparison symlink-transparent on every platform.
    """
    try:
        return str(Path(path).resolve()).lower()
    except OSError:
        return str(Path(path)).lower()


def _system_temp_roots() -> "list[str]":
    """Known system temp directories, RESOLVED and normalised to lowercase
    absolute strings for a prefix comparison. Includes the platform default
    (``tempfile.gettempdir()``), the raw ``TEMP``/``TMP`` env vars (Windows
    commonly points both at the same place, but not always), and the
    conventional POSIX/ad-hoc locations named in the original bug report
    (``C:\\tmp`` — exactly where SMK/SMK2 and the devops-pack debris
    landed).
    """
    candidates = {tempfile.gettempdir()}
    for var in ("TEMP", "TMP"):
        val = os.environ.get(var)
        if val:
            candidates.add(val)
    candidates.update({"C:\\tmp", "C:/tmp", "/tmp", "/var/tmp"})
    return [_resolved_lower(c) for c in candidates if c]


def _is_system_temp_path(path: Path) -> bool:
    normalised = _resolved_lower(path)
    return any(
        normalised == root or normalised.startswith(root + os.sep) or normalised.startswith(root + "/")
        for root in _system_temp_roots()
    )


def _workspace_root_for(entry: dict) -> Optional[Path]:
    """The directory that HOLDS this entry's ``MSO_DIR_NAME`` — the
    artefact root in solo/shared mode (v2 ``artefactRoot``), else the
    registered workspace ``path`` itself (embedded mode, the default for
    every entry with no ``artefactRoot``). Never appends ``MSO_DIR_NAME``
    itself — callers do that, so the one join stays in one place."""
    base = entry.get("artefactRoot") or entry.get("path")
    return Path(base) if base else None


def _mso_dir_for(entry: dict) -> Optional[Path]:
    root = _workspace_root_for(entry)
    return (root / MSO_DIR_NAME) if root is not None else None


def _has_activity(mso_dir: Path) -> bool:
    if any(
        (mso_dir / sub).is_dir() and any((mso_dir / sub).glob("*.json"))
        for sub in _ACTIVITY_SUBDIRS
    ):
        return True
    # queues/ holds order JSONs one level deeper than the flat dirs above
    # (queues/orders/*.json, queues/bugs/*.json, queues/security/*.json,
    # ...) so it needs its own glob rather than a bare subdir name.
    queues_dir = mso_dir / "queues"
    return queues_dir.is_dir() and any(queues_dir.glob("*/*.json"))


def _registered_at(entry: dict) -> Optional[datetime]:
    raw = entry.get("registered")
    if not isinstance(raw, str) or not raw:
        return None
    try:
        dt = datetime.fromisoformat(raw)
    except ValueError:
        return None
    return dt if dt.tzinfo is not None else dt.replace(tzinfo=timezone.utc)


def _past_grace(entry: dict, context: CheckContext, check_id: str) -> bool:
    """True once *entry* is old enough that "hasn't been set up/used yet"
    stops being a plausible innocent explanation.

    An entry with no parseable ``registered`` timestamp (pre-FTR-MSO-2026-0363
    v1 entries never carried one) is treated as past grace — it cannot be
    "newly registered" if there is no record of when it arrived.
    """
    registered_at = _registered_at(entry)
    if registered_at is None:
        return True
    grace = timedelta(minutes=context.params_for(check_id).get("graceMinutes", _DEFAULT_GRACE_MINUTES))
    return (context.now - registered_at) >= grace


# ---------------------------------------------------------------------------
# registry.unreachable-path
# ---------------------------------------------------------------------------

@check(id="registry.unreachable-path", severity="low", scope="machine")
def registry_unreachable_path(context: CheckContext) -> "list[Finding]":
    findings: "list[Finding]" = []
    for acronym, entry in sorted(registry.list_projects().items()):
        path_str = entry.get("path")
        if not path_str or Path(path_str).exists():
            continue
        findings.append(
            Finding(
                check_id="registry.unreachable-path",
                subject_id=f"project:{acronym}",
                severity="low",
                title=f"{acronym}: registered path does not exist",
                detail=(
                    f"{acronym} is registered at {path_str}, which does not exist on "
                    "disk right now. This is genuinely ambiguous from the registry "
                    "alone — it reads identically whether the workspace was removed "
                    "without unregistering it (debris) or its drive/volume is simply "
                    "not mounted at the moment (a real project, temporarily "
                    "unreachable). Reported at low severity for exactly that reason: "
                    "it never trips `mso doctor`'s default 'fail at high' exit gate, "
                    "and must be verified by hand before removing."
                ),
                firstSeenAt=context.now.isoformat(),
                suggestedCommand=f"mso projects remove {acronym}",
                scope="machine",
                requires=(),
            )
        )
    return findings


# ---------------------------------------------------------------------------
# registry.missing-workspace
# ---------------------------------------------------------------------------

@check(id="registry.missing-workspace", severity="low", scope="machine")
def registry_missing_workspace(context: CheckContext) -> "list[Finding]":
    findings: "list[Finding]" = []
    for acronym, entry in sorted(registry.list_projects().items()):
        root = _workspace_root_for(entry)
        if root is None or not root.exists():
            continue  # registry.unreachable-path's signal, not this one
        mso_dir = root / MSO_DIR_NAME
        if (mso_dir / "config").is_dir():
            continue
        if not _past_grace(entry, context, "registry.missing-workspace"):
            continue
        findings.append(
            Finding(
                check_id="registry.missing-workspace",
                subject_id=f"project:{acronym}",
                severity="low",
                title=f"{acronym}: registered workspace has no {MSO_DIR_NAME}/ directory",
                detail=(
                    f"{acronym} resolves to {root}, which exists but has no "
                    f"`{MSO_DIR_NAME}/config` — either a project registered before "
                    "`mso init` scaffolded it, or debris left behind after the "
                    "workspace was torn down by hand. Reported at low severity, and "
                    "only once the registration is old enough that 'still mid-setup' "
                    "stops being a plausible explanation."
                ),
                firstSeenAt=context.now.isoformat(),
                suggestedCommand=f"mso projects remove {acronym}",
                scope="machine",
                requires=(),
            )
        )
    return findings


# ---------------------------------------------------------------------------
# registry.no-activity
# ---------------------------------------------------------------------------

@check(id="registry.no-activity", severity="low", scope="machine")
def registry_no_activity(context: CheckContext) -> "list[Finding]":
    findings: "list[Finding]" = []
    for acronym, entry in sorted(registry.list_projects().items()):
        mso_dir = _mso_dir_for(entry)
        if mso_dir is None or not (mso_dir / "config").is_dir():
            continue  # registry.missing-workspace's / unreachable-path's signal
        if _has_activity(mso_dir):
            continue
        if not _past_grace(entry, context, "registry.no-activity"):
            continue
        findings.append(
            Finding(
                check_id="registry.no-activity",
                subject_id=f"project:{acronym}",
                severity="low",
                title=f"{acronym}: registered with zero voyages or orders ever recorded",
                detail=(
                    f"{acronym} at {mso_dir} has never had a voyage or order archived "
                    "— checked across voyages/active, voyages/complete, "
                    "orders/complete and orders/failed. Reported at low severity and "
                    "only once past its grace window: a freshly registered, "
                    "legitimate project that hasn't started work yet looks identical "
                    "to debris for a while — this is informational, not a removal "
                    "instruction on its own."
                ),
                firstSeenAt=context.now.isoformat(),
                suggestedCommand=f"mso projects remove {acronym}",
                scope="machine",
                requires=(),
            )
        )
    return findings


# ---------------------------------------------------------------------------
# registry.orphaned-temp-path
# ---------------------------------------------------------------------------

@check(id="registry.orphaned-temp-path", severity="medium", scope="machine")
def registry_orphaned_temp_path(context: CheckContext) -> "list[Finding]":
    findings: "list[Finding]" = []
    for acronym, entry in sorted(registry.list_projects().items()):
        path_str = entry.get("path")
        if not path_str or not _is_system_temp_path(Path(path_str)):
            continue

        # Second signal (the fixture problem — see module docstring): a
        # temp-located project with REAL recorded activity is deliberately
        # scratch-located and in active use, not debris. Only the
        # combination of temp-location AND no activity fires.
        mso_dir = _mso_dir_for(entry)
        has_real_activity = (
            mso_dir is not None
            and (mso_dir / "config").is_dir()
            and _has_activity(mso_dir)
        )
        if has_real_activity:
            continue
        if not _past_grace(entry, context, "registry.orphaned-temp-path"):
            continue

        findings.append(
            Finding(
                check_id="registry.orphaned-temp-path",
                subject_id=f"project:{acronym}",
                severity="medium",
                title=f"{acronym}: registered inside a system temp directory with no recorded activity",
                detail=(
                    f"{acronym} is registered at {path_str}, inside a system temp "
                    "directory, AND has never recorded a voyage or order. Either "
                    "signal alone is ambiguous — a long-lived project can be "
                    "deliberately scratch-located, and a brand-new project honestly "
                    "has no activity yet — but together they are the exact shape of "
                    "the SMK/SMK2 and INF1/PLAIN1 incidents (crew/devops smoke-test "
                    "scaffolds left behind in the registry). A temp-located project "
                    "that HAS real voyages/orders archived is never flagged by this "
                    "check, regardless of where it lives."
                ),
                firstSeenAt=context.now.isoformat(),
                suggestedCommand=f"mso projects remove {acronym}",
                scope="machine",
                requires=(),
            )
        )
    return findings
