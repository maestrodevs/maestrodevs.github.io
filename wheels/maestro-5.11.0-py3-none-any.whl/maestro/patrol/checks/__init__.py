"""maestro/patrol/checks — one module per check family (PLAN-PLN-MSO-2026-0504,
Repository Impact Map: "checks/*.py — one module per family").

Importing this package does not itself register anything; ``maestro.patrol``
imports each family module explicitly for its ``@check`` side effects, so the
registry's contents don't depend on import order here.
"""
