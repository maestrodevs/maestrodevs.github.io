"""``mso hub setup`` — provision the Maestro Hub from the invoking user's own
project registry (FTR-MSO-2026-0415, Part 2a of PLAN-PLN-MSO-2026-0412).

Source of truth is ``~/.maestro/projects.json`` (registry v2) read via
:func:`maestro.registry.list_projects`. v1 entries arrive normalised to the v2
shape (``productRepo``/``repos`` defaulted), so nothing here branches on
v1-vs-v2. There is **no new config surface** — the generator only *reads* the
registry.

Two modes:

* **local** (default) — validate the registry (>=1 project, paths exist) and
  print the start command. The native backend already reads the real
  ``~/.maestro`` directly, so nothing is written.
* **docker** — generate the two device-local artefacts the Docker deployment
  needs, rewriting every host path to a ``/repos/<basename>`` container path:

  1. ``<output-dir>/maestro-home/projects.json`` — the container registry
     (same v2 schema, every path field rewritten, ``legacyAcronyms`` /
     ``artefactMode`` preserved verbatim).
  2. ``<output-dir>/docker-compose.local.yml`` — the gitignored compose overlay
     whose ``volumes`` list is merged additively onto the tracked base file.

The pure builders (:func:`build_mount_map`, :func:`build_container_registry`)
carry the interesting logic and are unit-tested directly. :func:`run_setup`
orchestrates I/O and CLI messaging.
"""

from __future__ import annotations

import json
from pathlib import Path, PureWindowsPath

from maestro import registry
from maestro.errors import MaestroConfigError, MaestroUserError
from maestro.init import _render_template
from maestro.workspace import get_maestro_home

#: Root under which every host repo is mounted inside the container.
CONTAINER_REPOS_ROOT = "/repos"


def ui_bundle_dir() -> Path:
    """Directory where the statically-exported Hub UI bundle is expected.

    FTR-MSO-2026-0421: the local no-Docker Hub ships the frontend inside the
    wheel at ``maestro/hub/static/`` and the backend serves it same-origin. This
    resolves that path relative to the installed package so ``setup --mode
    local`` can confirm the bundle is present (and the backend will serve a UI,
    not just the API).
    """
    return Path(__file__).resolve().parent / "static"


def ui_bundle_present() -> bool:
    """True when a built UI bundle (``static/index.html``) is on disk."""
    return (ui_bundle_dir() / "index.html").is_file()

#: Bundled overlay template (relative to ``maestro/templates/``).
TEMPLATE_NAME = "docker/docker-compose.local.yml.j2"


# ---------------------------------------------------------------------------
# Path helpers
# ---------------------------------------------------------------------------

def _normalise(host: str) -> str:
    """Return *host* as a forward-slash path (Docker Desktop accepts ``C:/…``).

    Uses ``PureWindowsPath``, which treats BOTH backslash and forward slash as
    separators, so a Windows-authored path normalises correctly whichever
    platform reads it. ``Path(host).as_posix()`` is NOT sufficient: ``Path`` is
    flavour-bound, so on POSIX a stored Windows path passes through untouched
    and ``_basename`` below then finds no ``/`` and returns the whole string —
    yielding container paths with the whole Windows path glued on. Not hypothetical:
    the containerised Hub reads a registry authored on Windows, which is what
    tests/test_hub_setup.py caught.
    """
    return PureWindowsPath(host).as_posix()


def _basename(host_posix: str) -> str:
    """Last path component of an already-normalised (posix) host path."""
    name = host_posix.rstrip("/").rsplit("/", 1)[-1]
    return name or "repo"


def _host_paths_for_entry(entry: dict) -> list[str]:
    """Ordered, raw host paths from one v2 entry that need a container mount.

    Collects ``path``, ``productRepo``, ``artefactRoot`` (if present) and every
    ``repos[name].path``. Top-level ``path`` is included alongside the
    plan-listed ``productRepo``/``artefactRoot``/``repos[].path`` so that EVERY
    field :func:`build_container_registry` rewrites has a mount mapping — in
    embedded mode ``path == productRepo`` so it dedupes to one mount; in
    artefact-repo mode the distinct workspace root is correctly mounted too.
    """
    paths: list[str] = []
    for key in ("path", "productRepo", "artefactRoot"):
        val = entry.get(key)
        if isinstance(val, str) and val.strip():
            paths.append(val)
    repos = entry.get("repos")
    if isinstance(repos, dict):
        for name, rentry in repos.items():
            rp = rentry.get("path") if isinstance(rentry, dict) else None
            if isinstance(rp, str) and rp.strip():
                paths.append(rp)
    return paths


# ---------------------------------------------------------------------------
# Pure builders
# ---------------------------------------------------------------------------

def build_mount_map(entries: dict) -> tuple[dict[str, str], list[str]]:
    """Map each distinct host path to a deterministic ``/repos/<basename>``.

    Returns ``(mount_map, warnings)`` where ``mount_map`` is keyed by the
    NORMALISED (posix) host path. Identical host paths dedupe to one mount.
    A basename collision across *different* host paths gets a deterministic
    ``-2`` (then ``-3`` …) suffix and a warning string.
    """
    mount_map: dict[str, str] = {}
    owner: dict[str, str] = {}  # container path -> host path that claimed it
    warnings: list[str] = []

    for entry in entries.values():
        for raw in _host_paths_for_entry(entry):
            host = _normalise(raw)
            if host in mount_map:
                continue
            base = _basename(host)
            container = f"{CONTAINER_REPOS_ROOT}/{base}"
            if container in owner and owner[container] != host:
                suffix = 2
                while f"{CONTAINER_REPOS_ROOT}/{base}-{suffix}" in owner:
                    suffix += 1
                collided_with = owner[container]
                container = f"{CONTAINER_REPOS_ROOT}/{base}-{suffix}"
                warnings.append(
                    f"basename collision: {host} and {collided_with} both map to "
                    f"{CONTAINER_REPOS_ROOT}/{base}; {host} -> {container}"
                )
            mount_map[host] = container
            owner[container] = host

    return mount_map, warnings


def _to_container(host: str, mount_map: dict[str, str]) -> str:
    """Container path for *host*; falls back to ``/repos/<basename>`` (never a
    host path) if — impossibly, given :func:`_host_paths_for_entry` collects
    every rewritten field — the mapping is absent, so no identifier can leak."""
    norm = _normalise(host)
    if norm in mount_map:
        return mount_map[norm]
    return f"{CONTAINER_REPOS_ROOT}/{_basename(norm)}"


def build_container_registry(entries: dict, mount_map: dict[str, str]) -> dict:
    """Return a v2 registry dict with every host path rewritten to its
    container path.

    Rewrites top-level ``path`` / ``productRepo`` / ``artefactRoot`` and each
    ``repos[name].path``. All other fields (``legacyAcronyms``,
    ``artefactMode``, ``schemaVersion``, ``slug``, ``registered`` …) are copied
    verbatim.
    """
    projects: dict = {}
    for acronym, entry in entries.items():
        new_entry = dict(entry)
        for key in ("path", "productRepo", "artefactRoot"):
            val = new_entry.get(key)
            if isinstance(val, str):
                new_entry[key] = _to_container(val, mount_map)
        repos = entry.get("repos")
        if isinstance(repos, dict) and repos:
            new_repos: dict = {}
            for name, rentry in repos.items():
                if isinstance(rentry, dict):
                    r = dict(rentry)
                    if isinstance(r.get("path"), str):
                        r["path"] = _to_container(r["path"], mount_map)
                    new_repos[name] = r
                else:
                    new_repos[name] = rentry
            new_entry["repos"] = new_repos
        projects[acronym] = new_entry
    return {"projects": projects, "version": registry.REGISTRY_SCHEMA_VERSION}


def build_mounts_block(mount_map: dict[str, str]) -> str:
    """The indented YAML volume lines for the overlay.

    Six-space indent so the block sits under ``services.hub-backend.volumes``
    (2 for the service, 4 for the key, 6 for each list item). The base compose
    file's ``./maestro-home:/data/maestro-home`` mount is merged additively by
    compose — only the host-repo mounts belong here.
    """
    return "\n".join(
        f'      - "{host}:{container}"'
        for host, container in mount_map.items()
    )


def render_overlay(mount_map: dict[str, str]) -> str:
    """Render the compose overlay from the bundled template."""
    rendered = _render_template(TEMPLATE_NAME, {"mounts": build_mounts_block(mount_map)})
    if rendered is None:
        raise MaestroConfigError(
            f"Hub overlay template not found: templates/{TEMPLATE_NAME}",
            hint="Reinstall maestro so the bundled templates are present.",
        )
    return rendered


# ---------------------------------------------------------------------------
# Output-dir resolution
# ---------------------------------------------------------------------------

def _default_output_dir() -> Path:
    """The repo ``docker/`` dir when a ``docker/docker-compose.yml`` is found by
    walking up from cwd; else ``MAESTRO_HOME/hub-docker/`` (wheel-only installs).
    """
    cwd = Path.cwd()
    for base in (cwd, *cwd.parents):
        if (base / "docker" / "docker-compose.yml").exists():
            return base / "docker"
    return get_maestro_home() / "hub-docker"


# ---------------------------------------------------------------------------
# Orchestration
# ---------------------------------------------------------------------------

def run_setup(
    *,
    mode: str = "local",
    output_dir: str | None = None,
    dry_run: bool = False,
    force: bool = False,
) -> None:
    """Provision the Hub for *mode*. Tier-gating is applied by the caller."""
    entries = registry.list_projects()
    if not entries:
        raise MaestroUserError(
            "No projects registered — nothing to configure the Hub from.",
            hint="Register a workspace first (e.g. `mso init --project ACME`), "
            "then re-run `mso hub setup`.",
        )

    if mode == "local":
        _run_local(entries)
    elif mode == "docker":
        _run_docker(entries, output_dir=output_dir, dry_run=dry_run, force=force)
    else:  # pragma: no cover - argparse constrains choices
        raise MaestroUserError(
            f"Unknown mode {mode!r} — expected 'local' or 'docker'."
        )


def _run_local(entries: dict) -> None:
    print(f"Maestro Hub — local mode ({len(entries)} project(s) registered):\n")
    missing: list[str] = []
    for acronym, entry in entries.items():
        path = entry.get("path", "")
        exists = bool(path) and Path(path).exists()
        print(f"  [{'ok' if exists else 'MISSING'}] {acronym}: {path}")
        if not exists:
            missing.append(acronym)
    print()
    if missing:
        print(
            "  Warning: the workspace path(s) above do not exist on this machine "
            "— the Hub cannot read those projects until they are present.\n"
        )
    print(
        "The native Hub backend reads ~/.maestro directly — no extra config is "
        "needed for local mode.\n"
    )

    # FTR-MSO-2026-0421: local mode serves the UI from the backend on :3847, so
    # verify the exported bundle shipped with this install. A released wheel
    # bundles it; a plain source checkout does not (the backend then degrades to
    # API-only until the frontend is built).
    if ui_bundle_present():
        print(f"  [ok] Hub UI bundle present: {ui_bundle_dir()}")
        print("       `mso hub start` will serve the dashboard + API on one port.\n")
    else:
        print(f"  [MISSING] Hub UI bundle not found at {ui_bundle_dir()}")
        print(
            "       The backend will run API-only. To get the dashboard, install a\n"
            "       released maestro wheel (which ships the built UI), or build it\n"
            "       from source: `npm ci && npm run build` in maestro-hub/ and copy\n"
            "       the resulting out/ to maestro/hub/static/.\n"
        )

    print("Start the Hub with:\n")
    print("    mso hub start\n")
    print("Then open http://localhost:3847  (or run `mso hub start --open`).")


def _run_docker(
    entries: dict,
    *,
    output_dir: str | None,
    dry_run: bool,
    force: bool,
) -> None:
    mount_map, warnings = build_mount_map(entries)
    for warning in warnings:
        print(f"Warning: {warning}")

    container_registry = build_container_registry(entries, mount_map)
    registry_json = json.dumps(container_registry, indent=2) + "\n"
    overlay = render_overlay(mount_map)

    out = Path(output_dir).expanduser() if output_dir else _default_output_dir()
    registry_path = out / "maestro-home" / "projects.json"
    overlay_path = out / "docker-compose.local.yml"

    if dry_run:
        print(f"# --- {registry_path} ---")
        print(registry_json.rstrip("\n"))
        print(f"\n# --- {overlay_path} ---")
        print(overlay.rstrip("\n"))
        print("\n# --dry-run: no files written.")
        return

    clashes = [p for p in (registry_path, overlay_path) if p.exists()]
    if clashes and not force:
        raise MaestroUserError(
            "Refusing to overwrite existing generated file(s):\n  "
            + "\n  ".join(str(p) for p in clashes),
            hint="Re-run with --force to regenerate them.",
        )

    registry_path.parent.mkdir(parents=True, exist_ok=True)
    registry_path.write_text(registry_json, encoding="utf-8")
    overlay_path.write_text(overlay, encoding="utf-8")

    print(f"Wrote {registry_path}")
    print(f"Wrote {overlay_path}\n")
    print("Deploy the Hub in Docker with:\n")
    print(
        "    docker compose -f docker/docker-compose.yml "
        "-f docker/docker-compose.local.yml up -d --build\n"
    )
    print("Run it from the repo root. See docs/internal/DEPLOYMENT.md.")
