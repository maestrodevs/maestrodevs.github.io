# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Hub review module — parameterised review action handlers.

BUG-MSO-2026-0486: this used to be a private reimplementation of
maestro/review.py's logic and had drifted from it on five points (missing
capability gate, a revise that stranded the order, a different reject
vocabulary/location, a missing ledger event on approve, and no FTR-0427
gate-label/artefact-fallback derivation — see maestro/core/review_core.py's
module docstring for the full list). It is now a thin adapter over
review_core: resolves the workspace-local ``.mso`` dir and translates
review_core's typed exceptions into this module's documented HTTP-mappable
contract.

Exception contract:
  FileNotFoundError  → 404 (order not in review queue for this workspace)
  ValueError          → 409 (order exists but is not in NAV_REVIEW_PENDING state)
  PermissionError      → 403 (caller lacks the voyage.approve capability)
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from maestro.core import review_core


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _get_mso_dir(workspace_path: Path) -> Path:
    """Resolve ``.mso`` under *workspace_path*.

    *workspace_path* is expected to already be the artefact root's parent —
    callers (``hub/server.py``'s ``_iter_workspaces``/``_find_order_workspace``)
    resolve the registry v2 entry (``workspace.artefact_parent_for_entry``,
    honouring ``artefactMode: solo|shared``) before reaching this module, so
    the review flow reads/writes the artefact repo's queue in solo mode
    without this module needing any registry awareness itself
    (FTR-MSO-2026-0369).
    """
    from maestro.workspace import resolve_artefact_dir
    return resolve_artefact_dir(workspace_path)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def find_review_pending_orders(workspace_path: Path) -> list[dict]:
    """Return all orders from queues/review/ (NAV_REVIEW_PENDING and unlabelled).

    Each dict contains the raw order JSON. Callers use workspace_id from the
    outer registry loop — this function does not add it.
    """
    mso = _get_mso_dir(workspace_path)
    return review_core.find_review_pending_orders(mso)


def get_plan_content(workspace_path: Path, order_id: str) -> tuple[Optional[str], bool, Optional[dict]]:
    """Return (plan_markdown, has_plan_file, order_data).

    plan_markdown is the reviewable artefact's content when has_plan_file=True
    (a PLAN-<id>.md, or — FTR-MSO-2026-0427, BUG-MSO-2026-0486 D5 — the gated
    role's handoff document when there is no plan file), or the order's
    description field when False. Returns (None, False, None) when the order
    is not found in the review queue.
    """
    mso = _get_mso_dir(workspace_path)
    return review_core.get_plan_content(mso, order_id)


def approve_order(workspace_path: Path, order_id: str) -> dict:
    """Approve a NAV_REVIEW_PENDING order — mirrors mso review approve.

    Intra-order: sets status→PENDING, moves to queues/orders/, and records the
    ADVANCED ledger event (BUG-MSO-2026-0486 D4 — previously skipped here).
    Plan-approval-only: sets status→COMPLETE, archives to orders/complete/.

    Returns {"new_status": <str>}.
    Raises FileNotFoundError (404), ValueError (409), or PermissionError (403).
    """
    mso = _get_mso_dir(workspace_path)
    return review_core.approve_order(mso, order_id, source="hub")


def revise_order(workspace_path: Path, order_id: str, feedback: str) -> dict:
    """Request revision — re-queues the order to the gated role for another pass.

    BUG-MSO-2026-0486 D2: previously wrote status=REVISION_REQUESTED and left
    the order sitting in queues/review/, where the dispatcher never picked it
    up again and every later review action 409'd. Now matches `mso review
    revise`: status→PENDING, targetRole→<gated role>, moved to queues/orders/.

    Returns {"new_status": "PENDING", "target_role": <str>}.
    Raises FileNotFoundError (404), ValueError (409 — includes missing
    feedback), or PermissionError (403).
    """
    mso = _get_mso_dir(workspace_path)
    return review_core.revise_order(mso, order_id, feedback, source="hub")


def reject_order(workspace_path: Path, order_id: str, reason: str) -> dict:
    """Reject an order — marks FAILED, archives to orders/failed/.

    BUG-MSO-2026-0486 D3: previously used status=REJECTED / rejectionReason
    and archived to queues/review/rejected/, a location nothing else in the
    system scans. Now matches `mso review reject`.

    Returns {"new_status": "FAILED"}.
    Raises FileNotFoundError (404), ValueError (409 — includes missing
    reason), or PermissionError (403).
    """
    mso = _get_mso_dir(workspace_path)
    return review_core.reject_order(mso, order_id, reason, source="hub")
