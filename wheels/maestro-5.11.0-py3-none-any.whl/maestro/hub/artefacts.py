# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Order-location + artefact-discovery core (FTR-MSO-2026-0492).

Mirrors ``maestro/hub/attention.py``'s shape and docstring discipline for a
Hub-callable module serving N registered workspaces from one process:
explicit ``mso: Path`` throughout, no ``find_workspace()``, no CWD, no
globals.

Discovery rules — verified against the live MSO workspace, not invented
(PLAN-FTR-MSO-2026-0492 §3):

  - plan:          plans/PLAN-{ORDER-ID}.md, exact filename
  - handoff:       handoffs/{ORDER-ID}/*.md, every file in that dir
  - qa/security/
    investigation/
    voyage:        reports/{kind}/, filename STEM CONTAINS the order id
                    (case-insensitive) — mirrors fleet_runner.
                    sec_artefact_present's `oid in report.stem.upper()`
                    rule; both `QA-{id}.md` and `{id}.md` naming forms are
                    in live use, so a prefix-only match would miss half.
                    A report subdirectory whose NAME contains the order id
                    (e.g. an INV-type order's own folder) is recursed ONE
                    level.
  - order:         wherever the order JSON currently lives (always present
                    by construction — find_order_file() is how the caller
                    located the workspace in the first place).

``reports/compliance/`` and ``reports/usage/`` are deliberately excluded —
they are timestamp-named workspace-level artefacts, never order-scoped.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, List, Optional, Tuple

if TYPE_CHECKING:
    from maestro.hub.models import ArtefactContent, ArtefactRef

# Bounded read cap (§5.5) — an unbounded read of an arbitrary on-disk file
# into a JSON response is a trivial memory amplification against a
# single-worker backend.
MAX_ARTEFACT_BYTES = 512 * 1024

_REPORT_KINDS = ("qa", "security", "investigation", "voyage")


class ArtefactNotFound(Exception):
    """*key* does not match any artefact discovery currently finds for *order_id*."""

    def __init__(self, order_id: str, key: str) -> None:
        self.order_id = order_id
        self.key = key
        super().__init__(f"Artefact {key!r} not found for order {order_id!r}")


def _iso(mtime: float) -> str:
    return datetime.fromtimestamp(mtime, tz=timezone.utc).isoformat()


def find_order_file(mso: Path, order_id: str) -> Optional[Path]:
    """Locate *order_id*'s JSON wherever it currently lives.

    Probes, in order: ``orders/complete/``, ``orders/failed/``, then every
    queue dir (``queues/*/`` and the ``queues/requests/*/`` tier). Same
    coverage as ``maestro.core.order_retry.retry_order``'s own resolution —
    lifted, not re-derived, so retry and inspection can never disagree about
    where an order is.
    """
    for sub in ("complete", "failed"):
        candidate = mso / "orders" / sub / f"{order_id}.json"
        if candidate.exists():
            return candidate

    queues_dir = mso / "queues"
    if queues_dir.exists():
        for jf in list(queues_dir.glob("*/*.json")) + list(queues_dir.glob("*/*/*.json")):
            try:
                d = json.loads(jf.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            if (d.get("orderId") or d.get("id") or jf.stem) == order_id:
                return jf
    return None


def _ref(kind: str, key: str, name: str, path: Path) -> Tuple["ArtefactRef", Path]:
    from maestro.hub.models import ArtefactRef

    st = path.stat()
    return ArtefactRef(key=key, kind=kind, name=name, size=st.st_size,
                        modified=_iso(st.st_mtime)), path


def _discover(mso: Path, order_id: str) -> List[Tuple["ArtefactRef", Path]]:
    """Discovery, paired with the on-disk Path each ref resolves to.

    The Path is kept internal (never serialised) — :func:`read_artefact`
    re-runs THIS function and matches the client-supplied key against it, so
    a client can never name a file discovery did not itself find.
    """
    pairs: List[Tuple["ArtefactRef", Path]] = []
    oid = order_id.upper()

    order_file = find_order_file(mso, order_id)
    if order_file is not None:
        pairs.append(_ref("order", f"order:{order_file.name}", order_file.name, order_file))

    plan_file = mso / "plans" / f"PLAN-{order_id}.md"
    if plan_file.is_file():
        pairs.append(_ref("plan", f"plan:{plan_file.name}", plan_file.name, plan_file))

    handoff_dir = mso / "handoffs" / order_id
    if handoff_dir.is_dir():
        for f in sorted(handoff_dir.glob("*.md")):
            pairs.append(_ref("handoff", f"handoff:{f.name}", f.name, f))

    for kind in _REPORT_KINDS:
        report_dir = mso / "reports" / kind
        if not report_dir.is_dir():
            continue
        for entry in sorted(report_dir.iterdir()):
            if entry.is_file():
                if entry.suffix.lower() not in (".md", ".json"):
                    continue
                if oid in entry.stem.upper():
                    pairs.append(_ref(kind, f"{kind}:{entry.name}", entry.name, entry))
            elif entry.is_dir() and oid in entry.name.upper():
                # One-level recursion into a matching report subdirectory
                # (e.g. reports/investigation/INV-MSO-2026-0417/*.md).
                for f in sorted(entry.iterdir()):
                    if f.is_file() and f.suffix.lower() in (".md", ".json"):
                        rel_name = f"{entry.name}/{f.name}"
                        pairs.append(_ref(kind, f"{kind}:{rel_name}", rel_name, f))

    return pairs


def discover_artefacts(mso: Path, order_id: str) -> List["ArtefactRef"]:
    """Return every artefact's manifest entry (no content) for *order_id*."""
    return [ref for ref, _path in _discover(mso, order_id)]


def read_artefact(mso: Path, order_id: str, key: str) -> "ArtefactContent":
    """Read one artefact's content, bounded at :data:`MAX_ARTEFACT_BYTES`.

    *key* is validated by re-running discovery and matching, never by
    joining a client-supplied string onto a path — a forged key (path
    traversal, an absolute path, a real file outside the manifest) matches
    nothing and raises :class:`ArtefactNotFound`.
    """
    from maestro.hub.models import ArtefactContent

    match = next((pair for pair in _discover(mso, order_id) if pair[0].key == key), None)
    if match is None:
        raise ArtefactNotFound(order_id, key)
    ref, path = match

    try:
        raw = path.read_bytes()
    except OSError as exc:
        raise ArtefactNotFound(order_id, key) from exc

    truncated = len(raw) > MAX_ARTEFACT_BYTES
    body = raw[:MAX_ARTEFACT_BYTES] if truncated else raw
    return ArtefactContent(
        key=ref.key, kind=ref.kind, name=ref.name,
        content=body.decode("utf-8", errors="replace"),
        truncated=truncated, size=len(raw),
    )
