# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Workspace-parameterised attention classifier (FTR-MSO-2026-0487).

PLAN-PLN-MSO-2026-0468 §3.3: BUG-MSO-2026-0451's ``fleet_monitor.
get_held_breakdown()`` already named the taxonomy this module surfaces to the
Hub — review-gated / stranded / dep-held / skipped — but the function itself
is bound to process-global workspace state (it and ``fleet_runner``'s
``voyages_outstanding_work()`` both bottom out at a module-global
``get_artefact_root()``). The Hub's poller (maestro/hub/poller.py) serves N
registered workspaces from ONE process; calling the global-resolving form
there would return whichever workspace the process happened to have resolved,
silently wrong per workspace, with no error. "Reuse the taxonomy" therefore
means: keep the four category NAMES (do not invent a fifth, or rename these
four — that is the "parallel taxonomy" the plan warns against), but classify
each workspace from data this module reads itself, given an EXPLICIT
``mso: Path`` — no ``find_workspace()``, no CWD, no globals.

Per-category source of truth (mirrors get_held_breakdown()'s own docstring):

  - review_gated: any order whose *status* is ``NAV_REVIEW_PENDING`` —
    read from the already-built order index (cheap: no extra file I/O).
  - stranded:     any order whose *status* is one of the seven PLAN §2
    values (CONVERGENCE_FAILED / BLOCKED / AUTO_SERIALIZE / ESCALATED /
    STALLED / VERIFY_FAILED / FAILED) — also read from the order index.
  - dep_held:     order IDs in ``.mso/state/dep-holds.json`` (BUG-0349) —
    NOT visible in order status (the order stays e.g. PENDING while held),
    so this needs the dedicated dep-holds reader.
  - skipped:      order IDs in the operator skip list (BUG-0288) — likewise
    invisible in order status.

Deliberately does NOT call ``fleet_runner.voyages_outstanding_work()`` for
"stranded", unlike ``get_held_breakdown()``'s own CLI-dashboard figure.
That function answers "is this voyage fully finished yet" (BUG-0303 Eight
Bells) — ANY non-archived order in an active voyage counts as "outstanding",
including one a crew is healthily mid-flight on right now. Taken as a
per-ORDER tag (not a workspace-level "why does the fleet look idle" count)
that would mislabel ordinary PENDING/IN_PROGRESS work as "Needs Attention"
and offer a Retry button on an order nothing is wrong with. The status-list
in PLAN §2 is the more precise rule for tagging INDIVIDUAL orders, and the
order index already has every order's current status parsed and cached
(BUG-0422) — no extra read, and no dependency on fleet_runner's
process-global ``_MAESTRO_DIR_OVERRIDE`` escape hatch (which get_held_breakdown
now uses for parity with `mso status`; see its docstring). This is a
deliberate, narrower design than the CLI figure — flagged here and in the
BLD handoff for TST/Captain awareness, not a silent divergence.

Known gap: orders archived to ``orders/failed/`` (terminal FAILED) are not
in the order index aggregator.py builds (its search dirs cover
``orders/complete`` but not ``orders/failed``), so a FAILED order will not
currently surface under Needs Attention. Widening the index's search dirs is
an aggregator.py-level, cache-sensitive change judged out of scope for this
order — see the BLD handoff.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Dict, Optional

if TYPE_CHECKING:
    from maestro.hub.models import AttentionBreakdown, Order

# BUG-MSO-2026-0451's four category names — reused verbatim, never renamed.
ATTENTION_REVIEW_GATED = "review_gated"
ATTENTION_STRANDED = "stranded"
ATTENTION_DEP_HELD = "dep_held"
ATTENTION_SKIPPED = "skipped"

# PLAN-PLN-MSO-2026-0468 §2 — the exact status list ruled onto "Needs Attention".
STRANDED_STATUSES = frozenset({
    "CONVERGENCE_FAILED", "BLOCKED", "AUTO_SERIALIZE", "ESCALATED",
    "STALLED", "VERIFY_FAILED", "FAILED",
})

_REVIEW_GATED_STATUS = "NAV_REVIEW_PENDING"


class OrderAttention:
    """One order's attention tag — category name + optional human-readable detail."""

    __slots__ = ("category", "reason")

    def __init__(self, category: str, reason: str = "") -> None:
        self.category = category
        self.reason = reason


def classify_orders(mso: Path, order_index: Dict[str, "Order"]) -> Dict[str, OrderAttention]:
    """Return ``{order_id: OrderAttention}`` for every held/gated order in *mso*.

    *order_index* is the caller's already-built ``{order_id: Order}`` map
    (``aggregator._build_order_index`` — reused, not re-read, so this adds no
    I/O beyond the two small state files below).

    Precedence when an id (in practice, should not happen — the four sources
    are disjoint by construction) appears in more than one source: skipped is
    applied first, then dep-held, then stranded, then review-gated last — so
    review-gated (the clearest "a human must decide" signal) always wins a
    clash, matching §2's ruling that it is the one bucket whose verb is
    authorisation rather than recovery or self-resolution.
    """
    from maestro.core.dep_holds import read_dep_holds
    from maestro.core.skip_list import read_skipped_order_ids

    tags: Dict[str, OrderAttention] = {}

    try:
        skipped_ids = read_skipped_order_ids(mso)
    except Exception:
        skipped_ids = set()
    for order_id in skipped_ids:
        tags[order_id] = OrderAttention(ATTENTION_SKIPPED)

    try:
        dep_holds = read_dep_holds(mso)
    except Exception:
        dep_holds = {}
    for order_id, hold in dep_holds.items():
        waiting_on = hold.get("waitingOn") or []
        reason = ", ".join(str(w) for w in waiting_on) if waiting_on else ""
        tags[order_id] = OrderAttention(ATTENTION_DEP_HELD, reason)

    for order_id, order in order_index.items():
        status = (order.status or "").upper()
        if status in STRANDED_STATUSES:
            tags[order_id] = OrderAttention(ATTENTION_STRANDED)

    for order_id, order in order_index.items():
        status = (order.status or "").upper()
        if status == _REVIEW_GATED_STATUS:
            tags[order_id] = OrderAttention(ATTENTION_REVIEW_GATED)

    return tags


def apply_attention(orders, tags: Dict[str, OrderAttention]) -> None:
    """Stamp ``order.attention`` / ``order.attention_reason`` in place from *tags*.

    *orders* is any iterable of ``Order`` — callers pass both the order index's
    values and the separately-built live-queue ``orders`` list (aggregator.py
    builds each independently), so tagging is a single small pass over
    whichever Order objects the caller already has, not a second classification.
    """
    for order in orders:
        tag = tags.get(order.id)
        if tag is None:
            continue
        order.attention = tag.category
        order.attention_reason = tag.reason or None


def breakdown_from_tags(tags: Dict[str, OrderAttention]) -> "AttentionBreakdown":
    """Roll a ``classify_orders()`` result up into a workspace-level ``AttentionBreakdown``."""
    from maestro.hub.models import AttentionBreakdown

    counts = {
        ATTENTION_REVIEW_GATED: 0,
        ATTENTION_STRANDED: 0,
        ATTENTION_DEP_HELD: 0,
        ATTENTION_SKIPPED: 0,
    }
    for tag in tags.values():
        if tag.category in counts:
            counts[tag.category] += 1
    return AttentionBreakdown(
        review_gated=counts[ATTENTION_REVIEW_GATED],
        stranded=counts[ATTENTION_STRANDED],
        dep_held=counts[ATTENTION_DEP_HELD],
        skipped=counts[ATTENTION_SKIPPED],
        needs_you=counts[ATTENTION_REVIEW_GATED] + counts[ATTENTION_STRANDED],
    )


def compute_attention(mso: Path, order_index: Dict[str, "Order"]) -> "AttentionBreakdown":
    """Convenience wrapper: classify + roll up in one call (no per-order tags returned)."""
    return breakdown_from_tags(classify_orders(mso, order_index))
