# SecOps pack — QUICKSTART

The SecOps pack templates Maestro's canonical-7 archetypes into a threat-detection and
compliance delivery process: threat intel, detection engineering, attack validation, baseline
hardening, and compliance/IR reporting. It is a **division pack** — content only, zero engine
change (see `PLAN-PLN-MSO-2026-0371` section 5). This is a **Team/Enterprise-tier** pack; `mso
init --pack secops` requires that licence tier (or `MAESTRO_SKIP_AUTH=1` for local trial).

## Scope limitation — read this before you start

**This pack is scoped to detection-as-code and hardening-as-code delivered through a git repo.
It does not deploy anything to a live SIEM, and it does not build a live-SIEM integration.**

Detection rules (Sigma/KQL/Splunk SPL) and hardening baselines/IaC are the industry-norm,
repo-shaped deliverables — Maestro's `git`/PR-centred delivery model round-trips cleanly onto
them. A live SIEM is a different kind of target: it has no comparably clean CLI-friendly
export/import/verify loop, and wiring one up would mean writing a genuine
`DeliveryBackend`/SaaS adapter (tracked as a deferred, demand-driven follow-up in the plan,
section 4c), not authoring pack content.

**Practical effect:**
- The Threat Intel Analyst's plan never scopes a live-SIEM deployment step — it flags one as a
  future adapter need instead, if it comes up.
- The Detection/Hardening Engineer implements and validates in lint/plan-only mode only —
  never `apply`, never a live rule push.
- The Attack Validator simulates triggers against a **non-production/sandbox target only**,
  never live production infrastructure or a live SIEM.
- The Compliance Auditor collects evidence from the repo/config under audit only — never from a
  live SIEM connection.
- If your organisation needs the rules/hardening actually deployed to a live SIEM by an agent,
  this pack is not yet the right tool for that step — the deployment itself stays a human/CI
  action outside Maestro until the adapter exists.

## What you get

| Archetype | Division title | Does |
|-----------|-----------------|------|
| PLN | Threat Intel Analyst | Intel briefs, ATT&CK-mapped threat models, prioritised backlog, incident scoping |
| BLD | Detection Engineer / Hardening Engineer | Sigma/KQL/Splunk detection-as-code, baseline/IaC hardening — both git-delivered |
| TST | Attack Validator | Simulated triggers (sandbox only), detection unit tests, false-positive analysis |
| DOC | Compliance & Runbook Writer | Stakeholder-facing compliance reports, IR runbooks |
| SEC | Compliance Auditor (read-only) | Control-by-control audit — reuses the core `SEC` archetype's read-only tool scoping (`ROLE_DISALLOWED_TOOLS` already denies Write/Edit/NotebookEdit), a ready-made compliance-auditor posture |

| Order type | Sequence | Use for |
|------------|----------|---------|
| `INT` | `[PLN]` | Intel — a single-role planning deliverable |
| `DET` | `[PLN, BLD, TST]` | Detection — plan, implement, validate |
| `HRD` | `[PLN, BLD, TST, SEC]` | Hardening — plan, implement, validate, independently audit |
| `CMP` | `[SEC, DOC]` | Compliance — audit, report |
| `IRP` | `[PLN, DOC]` | IR runbook — scope the incident, write the runbook |

## Cold start

```bash
# 1. Scaffold a new workspace with the pack
mso init --project SEC1 --pack secops

# (trial without a Team/Enterprise licence)
MAESTRO_SKIP_AUTH=1 mso init --project SEC1 --pack secops
```

This lands the persona (Threat Intel Analyst/Detection Engineer/Attack Validator/Compliance &
Runbook Writer/Compliance Auditor), the five role overlays at `.mso/config/roles/`, the five
order templates at `.mso/orders/templates/`, the human-review gate at `.mso/config/gates.json`,
workspace defaults (verify command, role timeouts, `secops.liveSiemDeploymentOutOfScope`)
merged into `.mso/config/workspace.json`, requirement templates at `.mso/requirements/`, the
extra scaffold dirs (`.mso/reports/security/intel/`, `.mso/reports/security/compliance/`,
`.mso/reports/security/runbooks/`), and this file at `.mso/QUICKSTART-secops.md`.

```bash
# 2. Confirm the pack landed correctly
mso packs show secops
mso roles show PLN     # renders the merged Threat Intel Analyst overlay
mso roles show BLD     # renders the merged Detection/Hardening Engineer overlay
mso roles show TST     # renders the merged Attack Validator overlay
mso roles show DOC     # renders the merged Compliance & Runbook Writer overlay
mso roles show SEC     # renders the merged Compliance Auditor overlay
```

```bash
# 3. Author your first INT order — copy the template and fill it in
cp .mso/orders/templates/INT-template.json .mso/queues/orders/INT-SEC1-2026-0001.json
# edit: orderId, title, description, voyageId, voyageBranch, createdBy, createdAt
```

An `INT` order is single-role (`PLN` only) — the Threat Intel Analyst reads it, produces an
Intel Brief at `.mso/plans/PLAN-INT-SEC1-2026-0001.md` (threat model, existing-coverage
inventory, prioritised backlog), and the order completes. No detection rule or hardening
change is written yet.

```bash
# 4. Turn the brief into your first DET voyage
mso voyage create "First detection pass" --project SEC1
cp .mso/orders/templates/DET-template.json .mso/queues/orders/DET-SEC1-2026-0002.json
# edit: fill in the same fields, plus targetRepo (the detections repo) and voyageId/voyageBranch
mso dispatch
```

The `DET` order runs Threat Intel Analyst → Detection Engineer → Attack Validator: the Analyst
refines the plan for this specific technique (or reuses INT-0001's brief), the Detection
Engineer implements Sigma/KQL/Splunk rules in the target repo, and the Attack Validator
simulates the proposed trigger against a sandbox target and writes detection unit tests +
false-positive analysis before the order completes. If `gates.json`'s `post_nav_review` is
enabled (it is, by default), the Intel Brief pauses for human review before the Detection
Engineer starts — approve with `mso review approve`.

A `CMP` order (starts at `SEC`, not `PLN`) audits a target repo against a named framework and
writes a stakeholder-facing report; an `HRD` order hardens a baseline and closes with an
independent `SEC` audit; an `IRP` order scopes an incident and produces a runbook — see the
role overlays above for each deliverable's exact shape.

## Notes and known gaps

- **Requirement templates location** — this pack's `requirements/*.md.j2` files land at
  `.mso/requirements/` on init (per the existing `apply_pack` scaffold step). They are not yet
  wired into the `mso order --template` custom-template resolution path, which currently reads
  `.mso/templates/requirements/` — a pre-existing gap in the pack scaffold shared with every
  pack, not specific to SecOps. Use them as copy-paste references for now.
- **`verifyCommand` is a well-formedness check, not a functional one** — the shipped default
  parses `detections/**/*.yml` (Sigma's native format) as YAML and nothing more. It does not
  validate Sigma semantics, KQL/Splunk SPL syntax, or hardening IaC. Swap in a real Sigma
  linter, `terraform validate`, or your target repo's actual CI check once the tooling choice
  from the Threat Intel Analyst's plan is known — see `workspace-defaults.json`'s
  `verifyNotes`.
- **No live-SIEM deployment support** — repeated here because it is the single most important
  thing to know before raising any order against this pack: see "Scope limitation" above.
