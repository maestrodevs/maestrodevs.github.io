"""Admiralty — legacy compatibility shim (BUG-MSO-2026-0278).

This distribution contains no framework code of its own. It declares a runtime
dependency on the real package (``maestro-fleet`` on public PyPI / ``maestro`` on
the private wheel index) and aliases that package as ``admiralty`` so that every
historical entry point keeps working:

    import admiralty                      # -> the maestro package
    from admiralty import __version__     # == maestro.__version__
    from admiralty import init            # -> maestro.init
    import admiralty.cli                  # -> maestro.cli

Aliasing the whole package object (rather than re-exporting a handful of names)
means submodule imports resolve through ``maestro``'s ``__path__``, so callers
that reach into ``admiralty.<submodule>`` continue to work unchanged.
"""
import sys

import maestro

# Replace this shim module with the real maestro package so attribute access and
# submodule imports (admiralty.cli, admiralty.init, ...) resolve to maestro.*.
sys.modules[__name__] = maestro
