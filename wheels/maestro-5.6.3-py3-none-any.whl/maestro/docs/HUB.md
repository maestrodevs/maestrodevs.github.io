# Maestro Hub

**New in v5.0.0.** The Maestro Hub is a real-time, multi-workspace fleet
dashboard. Where `mso status` shows one workspace in one terminal, the Hub gives
you a single pane of glass across **every registered project** — live voyages,
orders, crews, queue depth, token usage, the human-review queue, and the
streaming lifecycle log.

The Hub has two pieces:

| Piece | Ships in | What it is |
|-------|----------|------------|
| **Backend** | the `maestro` pip package (`maestro.hub`) | A FastAPI service exposing a versioned REST API (`/api/v1/...`) + a lifecycle WebSocket. Aggregates state from every workspace in the global registry. |
| **Frontend** | the `maestro-hub/` source app | A Next.js dashboard that reads the backend API. Run from source with `npm run dev`. |

---

## Quick start

### 1. Start the backend

There are two ways to run the backend.

**`mso hub start` — managed daemon (Team / Enterprise licence).**

```bash
mso hub start                 # background daemon on http://127.0.0.1:3847
mso hub start --port 4000 --open   # custom port + open a browser
mso hub status                # is it running? (PID + URL)
mso hub stop                  # stop the daemon
```

`mso hub start` is gated to **Team / Enterprise** licences (the Hub aggregates
multiple workspaces, a fleet-scale feature). FastAPI / uvicorn are installed on
first run if missing — or pre-install them with the `hub` extra:

```bash
pip install 'maestro[hub]' --extra-index-url https://maestrodevs.github.io/simple/
```

**`python -m maestro.hub` — direct, ungated (single-operator / dev).**

```bash
python -m maestro.hub --port 3847
```

This runs the same FastAPI app in the foreground with no licence gate — handy for
local development or a single-operator setup. (The write-control endpoints —
dispatch / hold — are still tier-gated at the HTTP layer; see
[Tier gating](#tier-gating).)

### 2. Start the frontend

The dashboard UI lives in the `maestro-hub/` source directory.

```bash
cd maestro-hub
npm install
NEXT_PUBLIC_HUB_URL=http://localhost:3847 npm run dev   # → http://localhost:3000
```

Open <http://localhost:3000>. The frontend polls the backend every few seconds
and subscribes to the lifecycle WebSocket for live updates.

---

## What the Hub shows

- **Workspace overview** — one card per registered project: dispatcher
  running/stopped, active crews, active voyages, queued orders, pending reviews.
- **Voyage view** — voyages grouped into **Active / Proposed / Completed**
  accordions, each with a role-pipeline (PLN → BLD → TST → …) chip strip, the
  repo + worktree path, and a dependency-graph (DAG) of the orders.
- **Crew panels** — per-slot status, current order, iteration, activity age, PID.
- **Token usage** — cross-project token totals and estimated cost on the
  overview page; per-voyage badges on workspace detail; a dedicated **Token
  Usage report** at `/reports/usage` with drill-down (project → voyage → order →
  role) and CSV export. All surfaces read from `.mso/usage/orders/`.
- **Review queue** — every order paused at a human-review gate, across all
  workspaces, with approve / revise / reject actions.
- **Live lifecycle stream** — the dispatcher's `lifecycle.log` events as they
  happen, scopeable to a single workspace.
- **Dispatch / Hold controls** — start or stop a workspace's dispatcher from the
  UI (tier-gated; see below).
- **Housekeeping sweep** — a broom button that clears voyages whose PR you have
  already merged, with a preview first. See
  [Housekeeping sweep](#housekeeping-sweep).
- **Multi-repo pills and badges** — for a workspace configured with a multi-repo `repos` map, the
  Hub shows per-repo PR pills on voyage cards, a per-repo review-and-merge CTA in the Final Review
  strip, and a repo badge on every order row/drawer. Single-repo workspaces are unaffected. See
  [MULTI-REPO.md](MULTI-REPO.md#the-hubs-multi-repo-ui) for the full breakdown.
- **`claimedBy` badges** — for a shared-mode (corporate) workspace, an order currently claimed by
  another engineer's dispatcher shows who claimed it and when. See
  [ARTEFACT-REPO.md](ARTEFACT-REPO.md#corporate-shared-mode).

---

## How workspaces appear in the Hub

The Hub reads the **global project registry** at `~/.maestro/projects.json`. Any
workspace registered there shows up automatically. Workspaces are registered when
you run `mso init` / `mso dispatch` in them, or you can manage the list with:

```bash
mso projects list             # show registered workspaces
mso projects remove <ACRONYM> # drop one from the registry
```

If the Hub shows a workspace you no longer use (or is missing one you do), prune
or re-register it via `mso projects`.

---

## Tier gating

| Action | Gate |
|--------|------|
| Read-only API (`GET /api/v1/...`), lifecycle stream | Ungated on the direct `python -m maestro.hub` entry point. |
| `mso hub start` (managed daemon) | **Team / Enterprise** licence (`auth.require_tier`). |
| `POST .../dispatch`, `POST .../stop` (Dispatch / Hold) | **Team / Enterprise** at the HTTP layer → `403` otherwise. |
| `POST .../sweep` (Housekeeping) | **Team / Enterprise** at the HTTP layer → `403` otherwise. |

Setting `MAESTRO_SKIP_AUTH=1` bypasses both the licence check and the tier gate
(used by CI and local single-operator development).

---

## REST API reference

Base URL: `http://127.0.0.1:3847` (default port). All routes are under `/api/v1`.

| Method | Path | Returns |
|--------|------|---------|
| `GET` | `/health` | Service status, version, workspace count. |
| `GET` | `/workspaces` | Array of workspace summaries (the overview cards). |
| `GET` | `/workspaces/{id}` | Full workspace detail — voyages, orders, crews, queue summary, usage, config, repos. |
| `GET` | `/workspaces/{id}/crews` | Per-crew live state for one workspace. |
| `POST` | `/workspaces/{id}/dispatch` | Start the workspace's dispatcher (tier-gated). |
| `POST` | `/workspaces/{id}/stop` | Stop the workspace's dispatcher (tier-gated). |
| `POST` | `/workspaces/{id}/sweep` | Run the [housekeeping sweep](#housekeeping-sweep) (tier-gated). Add `?dry_run=true` to preview. |
| `GET` | `/review/queue` | Cross-workspace human-review queue (bare array). |
| `GET` | `/review/{order_id}/plan` | The plan markdown for an order awaiting review. |
| `POST` | `/review/{order_id}/approve` | Approve a paused order. |
| `POST` | `/review/{order_id}/revise` | Send an order back with feedback. |
| `POST` | `/review/{order_id}/reject` | Reject a paused order. |
| `GET` | `/usage` | Cross-workspace token/cost rollup. Optional: `?from=YYYY-MM-DD&to=YYYY-MM-DD&group_by=project\|voyage\|order\|role` |
| `GET` | `/usage/projects/{id}` | Per-project rollup with voyage-level buckets. Optional `from` / `to` date filters. |
| `GET` | `/usage/voyages/{voyage_id}` | Per-voyage rollup with order-level buckets (+ role breakdown when FTR-0332 data present). Optional `from` / `to`. |
| `GET` | `/usage/orders/{order_id}` | Full order usage: per-role buckets, per-iteration records, per-model breakdown. |
| `WS` | `/lifecycle/stream` | Live lifecycle events. Add `?workspace_id=<id>` to scope to one workspace. |

The JSON shapes are defined by the Pydantic models in `maestro/hub/models.py`
and serialize exactly to the frontend TypeScript interfaces in
`maestro-hub/app/types/index.ts` (the authoritative data contract).

---

## Housekeeping sweep

Each project's control row on the workspace detail page carries
a **broom button**, between **Dispatch** and **Settings**. It runs housekeeping
for that workspace: check every voyage's PR state, archive the ones whose PR has
merged, and report what it refused to touch.

### Why it exists

You approve and merge the voyage PR yourself most of the time — usually after the
dispatcher that produced the work has exited. Maestro therefore never *observes*
the merge event, and the voyage stays in `voyages/active/`, cluttering the **Final
Review** column indefinitely.

Housekeeping cannot be something that only happens when a dispatcher happens to be
running. It has to be **pull-based** — something you trigger. The broom button is
that trigger, and it needs **no running dispatcher**.

### Preview, then apply

Clicking the broom never mutates anything on the first click:

1. The first click runs a **dry run** and opens a dialog listing
   **Will change** and **Will NOT touch**, each line naming the voyage and the
   reason.
2. Nothing is written until you confirm. Cancel and the workspace is untouched.
3. If there is nothing to change, you get a toast instead of a dialog — either
   *"nothing to archive — N item(s) left untouched"* or *"everything is already up
   to date"*.

The refusals are the point as much as the changes: an open PR, a voyage with no PR
at all, a PR closed without merging, or an order that is archived but not
`COMPLETE` is **reported with its reason**, never silently skipped.

### Same code as the CLI

The endpoint runs `mso voyage reconcile --json` — the button and the command
execute literally the same implementation, so they cannot drift or disagree. For
the full behaviour, the report shape and how merge state is resolved (PR record
first, raw git as the fallback), see
[`mso voyage reconcile`](CLI-REFERENCE.md#mso-voyage-reconcile).

### Requirements and limits

| Constraint | Detail |
|-----------|--------|
| **Tier** | Team / Enterprise, same as Dispatch / Hold. `403` otherwise (or set `MAESTRO_SKIP_AUTH=1` for local development). |
| **Origin / CORS** | Same allow-list and Host guard as the other control endpoints. |
| **Dispatcher** | Not required. |
| **Containerised Hub** | **Unavailable** — returns `409` with the observe-only message. Merge detection needs `git` and `gh` against the product repo, and a container has neither. Same constraint as the Dispatch button; run the sweep from a host session (`mso voyage reconcile`) or a native Hub (`mso hub start`). |
| **Timeout** | 5 minutes, then `504`. A hanging PR lookup is the usual cause; nothing is reported as changed. |

---

## Token usage & cost

The Hub surfaces token consumption and estimated cost across four levels: fleet
overview, workspace detail, the Token Usage report, and the REST API.

### Dashboard overview — CrossWorkspaceUsagePanel

On the Hub overview page (`/`), a **CrossWorkspaceUsagePanel** appears above the
workspace cards. It shows:

- **Total tokens** and **estimated cost** for all projects combined, for the
  selected date range.
- A **per-project breakdown table** sorted by spend (highest first), with each
  project's token total and cost.
- A **trend sparkline** driven by the daily series for the same period.
- A **date-range control** with 7d / 14d / 30d presets. Changing the preset
  re-fetches the overview and all workspace panels simultaneously.

When no usage has been recorded in the selected period, the panel shows
"No usage recorded in this period" — it never falls back to mock or example data.

### Workspace detail — WorkspaceUsagePanel and voyage badges

On a workspace detail page (`/workspaces/{id}`):

- A **WorkspaceUsagePanel** in the right sidebar shows the project-level token
  total and cost for the selected date range, with a sparkline.
- Each voyage row in the voyage list shows an inline **token/cost badge** when
  usage data exists for that voyage. The badge is omitted (not zeroed) when the
  voyage has no recorded usage.
- The **date-range control** (7d / 14d / 30d) drives both the sidebar panel and
  the per-voyage badges.

### Token Usage report

A dedicated **Token Usage report** is available at `/reports/usage` (linked from
the reports catalog at `/reports` with a "Live data" badge). It provides:

| Feature | Description |
|---------|-------------|
| **Drill-down navigation** | Start at the project level; click into a project to see its voyages; click a voyage to see its orders; click an order for role + model detail. A breadcrumb lets you navigate back up. |
| **TotalsPanel** | Shows total tokens, estimated cost, and order count for the current filter level, plus a trend sparkline. At order detail level the totals reflect that order's data. |
| **BreakdownTable** | Tabular list of buckets (projects / voyages / orders) sorted by tokens descending, with a "Drill in →" button on each row. |
| **Order detail view** | Shows per-role token/cost buckets (`role_buckets`, from FTR-0332 iteration JSONL) and a per-model breakdown (input / output / cache-read / cache-write / message count). Degrades gracefully when JSONL is absent. |
| **DailyTrendTable** | Per-day tokens and cost series shown below the main panel at project, voyage, and order-list levels. Hidden at the order detail level (no series available). |
| **CSV export** | Exports the current filtered view as a CSV file. At order level: role + model rows combined; at other levels: the current bucket list. |
| **Date-range control** | 7d / 14d / 30d presets re-fetch all panels at the current drill level. |
| **Empty/zero state** | "No usage data for the selected filters in this period" at every level — no fallback to mock data. |

### Data sources

All usage surfaces read from the files written by the Maestro stop hook:

| File type | Location | Contents |
|-----------|----------|----------|
| **Order summary** (`*.json`) | `.mso/usage/orders/{ORDER-ID}.json` | Cumulative per-order totals: `total_tokens`, `estimated_cost_usd`, per-model breakdown. One file per order; updated (merged, not overwritten) after each crew iteration by the stop hook. |
| **Iteration log** (`*.jsonl`) | `.mso/usage/orders/{ORDER-ID}.jsonl` | Append-only; one JSON line per completed crew iteration with `role`, `crew_number`, `iteration`, `total_tokens`, `estimated_cost_usd`, per-model breakdown, and `timestamp`. Present only when FTR-0332 is active. |

### Forward-looking caveats

> **Data availability:** Token-usage files are written by the Maestro stop hook.
> BUG-MSO-2026-0331 (fixed in v5.0.2) caused the stop hook to skip usage capture
> when running under `MAESTRO_ITER_MANAGED` — the mode used by all dispatched
> crews. As a result, **usage data is available only from the v5.0.2 deployment
> forward** (approximately 2026-06-27). Earlier orders have no recorded usage and
> will show zero or empty in all Hub views.

> **Role-level breakdown:** The per-role breakdown in the order detail view
> requires the per-iteration JSONL files introduced in FTR-MSO-2026-0332. Orders
> that completed before FTR-0332 was deployed have only the summary JSON (no JSONL)
> and will show "No role-level breakdown — requires FTR-0332 iteration files."
> rather than an error.

> **Cost estimates:** Estimated cost is calculated by the Maestro stop hook using
> a built-in per-model pricing table. It reflects published API list prices at the
> time of the release and is updated with each new Maestro version. Actual billing
> may differ due to promotional pricing, enterprise agreements, caching discounts,
> or model pricing changes that post-date the installed version.

---

## Configuration

| Setting | Where | Default |
|---------|-------|---------|
| Backend port | `--port` on `mso hub start` / `python -m maestro.hub` | `3847` |
| Frontend → backend URL | `NEXT_PUBLIC_HUB_URL` env (frontend) | `http://localhost:3847` |
| Workspace registry | `~/.maestro/projects.json` | — |
| Terminal monitor auto-spawn | `spawnMonitor` in `~/.maestro/config/settings.json`, or `MAESTRO_SPAWN_MONITOR=0/1` env | `true` (spawns) |

Per-workspace dispatch defaults shown in the Hub's settings drawer
(`maxIterations`, `maxTurns`, `timeoutMinutes`, `autoDispatch`,
`requirePlanReview`, `tokenDailyCap`, `roleTimeouts`) live in each workspace's
`.mso/config/workspace.json`.

**Running the Hub instead of the terminal Monitor?** `mso dispatch` normally
auto-spawns a separate visible "Maestro Monitor" terminal window on every
dispatch. When you're driving observation through the Hub, that window is
redundant. Set `spawnMonitor` to `false` in the **machine-level** (device-global,
not per-workspace) `~/.maestro/config/settings.json`:

```json
{
  "spawnMonitor": false
}
```

or set `MAESTRO_SPAWN_MONITOR=0` in the environment the dispatcher runs in — the
env var always wins over the machine config. This is a per-device display
preference, so it applies to every workspace dispatched from that machine. The
dispatcher and crews run unaffected either way; only the terminal window is
suppressed, and a one-line note is logged to `lifecycle.log` when it is.

---

## Troubleshooting

- **Frontend shows "backend unreachable" / no live data** — confirm the backend
  is up (`mso hub status` or `curl http://127.0.0.1:3847/api/v1/health`) and that
  `NEXT_PUBLIC_HUB_URL` points at the right port.
- **`mso hub start` refuses with a tier error** — `mso hub` requires a Team /
  Enterprise licence. For single-operator/dev use, run the backend directly with
  `python -m maestro.hub --port 3847`.
- **A workspace is missing or stale** — check `mso projects list`; register with
  `mso init` / `mso dispatch` in the workspace, or remove with
  `mso projects remove <ACRONYM>`.
- **Dispatch / Hold / broom buttons return 403** — those endpoints are tier-gated;
  use a Team / Enterprise licence or set `MAESTRO_SKIP_AUTH=1` for local
  development.
- **The broom button returns 409 "observe-only deployment"** — expected in a
  containerised Hub, which has no product repo, `git` or `gh` to check PR state
  with. Run `mso voyage reconcile` from a host session instead, or run the Hub
  natively. Same limitation as Dispatch.
- **Voyages stay in Final Review after their PR merged** — click the broom button
  (or run `mso voyage reconcile`). Maestro does not see merges you perform
  yourself; housekeeping is
  [pull-based](#housekeeping-sweep) by design.
