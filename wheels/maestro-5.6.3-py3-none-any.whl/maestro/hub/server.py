# Copyright (c) 2026 Tavis Basing (tavisbasing). All rights reserved.
# Proprietary and confidential. Unauthorized use, redistribution, or
# sublicensing is strictly prohibited. See LICENSE for full terms.

"""Maestro Hub FastAPI application.

FastAPI and uvicorn are imported lazily inside create_app() so that
`import maestro.hub.server` never fails when the [hub] extra is absent.
"""

# Poll interval (seconds) for the WebSocket lifecycle stream. Patchable in tests.
_WS_POLL_INTERVAL: float = 2.0

# BUG-MSO-2026-0395 — dispatch guard messages (kept as module constants so the
# backend and its tests share one source of truth).
OBSERVE_ONLY_MESSAGE = (
    "This Hub is an observe-only deployment — it cannot launch a usable "
    "dispatcher here. Dispatch from a host session (`mso dispatch`) or run the "
    "Hub natively (`mso hub start`)."
)
STALE_MOUNT_MESSAGE = (
    "Workspace registry is temporarily unreadable (stale mount / I/O error). "
    "Restart the Hub containers (e.g. `docker compose restart`) and retry."
)
# BUG-MSO-2026-0440 — housekeeping (broom) has its OWN capability requirement,
# which is not the dispatcher's. See _sweep_unavailable_reason().
SWEEP_UNAVAILABLE_MESSAGE = (
    "Housekeeping needs the GitHub CLI (`gh`) to read authoritative PR merge "
    "state, and `gh` is not available in this Hub deployment. Run "
    "`mso voyage reconcile` from a host session instead — it is the same code "
    "path and needs no dispatcher."
)


def _env_truthy(name: str) -> bool:
    """True when env var *name* is set to a truthy value (1/true/yes/on)."""
    import os
    return os.environ.get(name, "").strip().lower() in ("1", "true", "yes", "on")


def _in_container() -> bool:
    """Best-effort container detection (the Docker runtime drops /.dockerenv)."""
    import os
    try:
        return os.path.exists("/.dockerenv")
    except OSError:
        return False


def _is_observe_only() -> bool:
    """Return True when this backend cannot spawn a usable host dispatcher.

    Primary signal: the ``MAESTRO_HUB_CONTAINERIZED`` env flag, set in
    ``docker/hub/Dockerfile.backend`` — a containerized backend has no Claude
    CLI and only sees container-registry paths, so a spawned dispatcher is a
    silent no-op (BUG-MSO-2026-0395). Fallback heuristic: running inside a
    container with no ``claude`` on PATH. The heuristic is gated on container
    detection so a native host that merely lacks ``claude`` on PATH (e.g. CI)
    is NOT misclassified as observe-only.
    """
    import shutil
    if _env_truthy("MAESTRO_HUB_CONTAINERIZED"):
        return True
    if _in_container() and shutil.which("claude") is None:
        return True
    return False


def _sweep_unavailable_reason():
    """Why housekeeping cannot run in this deployment, or None if it can.

    BUG-MSO-2026-0440: the sweep endpoint was gated on ``_is_observe_only()``,
    which answers a DIFFERENT question — "can this backend spawn a usable
    dispatcher?" — and answers it by probing for the Claude CLI. Housekeeping
    needs neither a dispatcher nor the Claude CLI; FTR-MSO-2026-0426 is explicit
    that it is pull-based precisely so it works without one. Gating it on the
    dispatcher check refused the broom button for the wrong reason and returned
    OBSERVE_ONLY_MESSAGE, which tells the operator to run ``mso dispatch`` —
    advice that has nothing to do with housekeeping and cannot resolve it.

    What sweep actually needs is ``gh``: FTR-MSO-2026-0426 made the GitHub PR
    record AUTHORITATIVE for merge detection (raw-git ancestry is only the
    offline fallback, and deliberately degrades to "unknown" rather than risk a
    false "merged"). Without ``gh`` a sweep would still run but could not resolve
    any PR-backed voyage, so refusing remains correct — the fix is to refuse for
    the TRUE reason and to name the action that actually works.
    """
    import shutil
    if shutil.which("gh") is None:
        return SWEEP_UNAVAILABLE_MESSAGE
    return None


def create_app():
    """Build and return the FastAPI application."""
    from contextlib import asynccontextmanager

    import fastapi
    from fastapi.middleware.cors import CORSMiddleware

    import maestro
    from maestro.hub.models import (
        ActionResult,
        ControlResult,
        SweepResult,
        CrewState,
        HealthResponse,
        OrderUsageDetail,
        PlanResponse,
        RejectRequest,
        ReviewItem,
        ReviseRequest,
        UsageRollup,
        WorkspaceDetail,
        WorkspaceSummary,
    )
    from maestro.hub.poller import WorkspacePoller

    @asynccontextmanager
    async def lifespan(app: fastapi.FastAPI):
        poller = WorkspacePoller(interval=5.0)
        poller.start()
        app.state.poller = poller
        try:
            yield
        finally:
            poller.stop()

    import os
    import re

    app = fastapi.FastAPI(
        title="Maestro Hub",
        version=maestro.__version__,
        lifespan=lifespan,
    )

    # --- Security configuration (audit findings H4/H5/H6) -------------------
    # The Hub binds to 127.0.0.1, but a wildcard CORS policy + no Host/Origin
    # validation previously made it a browser-reachable, DNS-rebindable control
    # plane. We now: (1) allow only explicit localhost origins for CORS, (2)
    # validate the Host header to defeat DNS rebinding, and (3) enforce a bearer
    # token when one is configured (env MAESTRO_HUB_TOKEN or ~/.maestro/hub.token).
    # The token is opt-in so the existing localhost frontend keeps working; it is
    # strongly recommended on shared/multi-user hosts (see docs/security).
    def _configured_origins():
        raw = os.environ.get("MAESTRO_HUB_ALLOWED_ORIGINS", "").strip()
        if raw:
            return [o.strip() for o in raw.split(",") if o.strip()]
        return [
            "http://localhost:3000", "http://127.0.0.1:3000",
            "http://localhost:3847", "http://127.0.0.1:3847",
        ]

    def _allowed_hosts():
        # localhost forms + the Starlette TestClient sentinel ("testserver").
        # A DNS-rebinding attacker uses their OWN hostname (which resolves to
        # 127.0.0.1), so it is still blocked; "testserver" is never a real host.
        base = {"127.0.0.1", "localhost", "::1", "[::1]", "testserver", ""}
        raw = os.environ.get("MAESTRO_HUB_ALLOWED_HOSTS", "").strip()
        if raw:
            base |= {h.strip() for h in raw.split(",") if h.strip()}
        return base

    def _expected_token():
        tok = os.environ.get("MAESTRO_HUB_TOKEN", "").strip()
        if tok:
            return tok
        try:
            from maestro.workspace import get_maestro_home
            p = get_maestro_home() / "hub.token"
            if p.exists():
                return p.read_text(encoding="utf-8").strip() or None
        except Exception:
            pass
        return None

    _ORIGINS = _configured_origins()

    app.add_middleware(
        CORSMiddleware,
        allow_origins=_ORIGINS,
        allow_credentials=False,
        allow_methods=["GET", "POST", "OPTIONS"],
        allow_headers=["Authorization", "Content-Type"],
    )

    @app.middleware("http")
    async def _host_and_auth_guard(request, call_next):
        # Host-header allowlist — defeats DNS rebinding against the localhost bind.
        host = (request.headers.get("host") or "").rsplit(":", 1)[0].strip("[]")
        if host and host not in {h.strip("[]") for h in _allowed_hosts()}:
            return fastapi.responses.JSONResponse(
                status_code=403, content={"detail": f"Host '{host}' not allowed"})
        # Bearer token — enforced only when configured; /health and /ping stay
        # open for liveness (the container healthcheck presents no token).
        token = _expected_token()
        if token and request.url.path.startswith("/api/") \
                and request.url.path not in ("/api/v1/health", "/api/v1/ping"):
            auth = request.headers.get("authorization", "")
            presented = auth[7:].strip() if auth.lower().startswith("bearer ") else ""
            import hmac as _hmac
            if not presented or not _hmac.compare_digest(presented, token):
                return fastapi.responses.JSONResponse(
                    status_code=401, content={"detail": "missing or invalid bearer token"})
        return await call_next(request)

    _ORDER_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,64}$")

    def _validate_order_id(order_id: str):
        """Reject order ids that could escape the review directory (H-M path traversal)."""
        if not order_id or ".." in order_id or "/" in order_id or "\\" in order_id \
                or not _ORDER_ID_RE.match(order_id):
            raise fastapi.HTTPException(status_code=400, detail="invalid order id")

    @app.get("/api/v1/ping")
    async def ping():
        """Cheap liveness probe — touches no registry, filesystem, or poller.

        Used by the container healthcheck (docker/docker-compose.yml) so that a
        heavy workspace scan behind /api/v1/health can never flag the container
        unhealthy while it is serving traffic (BUG-MSO-2026-0390).
        """
        return {"ok": True}

    @app.get("/api/v1/health", response_model=HealthResponse)
    async def health():
        poller: WorkspacePoller = app.state.poller
        summaries = poller.summaries()
        return HealthResponse(
            status="ok",
            version=maestro.__version__,
            workspaces=len(summaries),
        )

    @app.get("/api/v1/workspaces", response_model=list[WorkspaceSummary])
    async def list_workspaces():
        poller: WorkspacePoller = app.state.poller
        return poller.summaries()

    @app.get("/api/v1/workspaces/{workspace_id}", response_model=WorkspaceDetail)
    async def get_workspace_detail(workspace_id: str):
        poller: WorkspacePoller = app.state.poller
        detail = poller.detail(workspace_id)
        if detail is None:
            raise fastapi.HTTPException(status_code=404, detail=f"Workspace '{workspace_id}' not found")
        return detail

    @app.get("/api/v1/workspaces/{workspace_id}/crews", response_model=list[CrewState])
    async def get_workspace_crews(workspace_id: str):
        from maestro.hub import aggregator
        from maestro.workspace import artefact_parent_for_entry

        entry = _resolve_workspace_entry(workspace_id)
        ws_root = artefact_parent_for_entry(entry)
        return aggregator.build_crew_list(ws_root, workspace_id)

    # -----------------------------------------------------------------------
    # Dispatch control endpoints (Feature B) — localhost-only by binding
    # -----------------------------------------------------------------------

    def _resolve_workspace_entry(workspace_id: str) -> dict:
        """Return the raw registry v2 entry for *workspace_id* or raise 404.

        Callers derive paths via ``maestro.workspace.artefact_parent_for_entry``
        (artefacts: voyages/orders/queues/review/usage/logs) and
        ``product_repo_for_entry`` (dispatch/stop subprocess cwd, branch/PR
        context) — never read ``entry["path"]`` directly (FTR-MSO-2026-0369).
        """
        import maestro.registry as registry
        projects = registry.list_projects()
        if workspace_id not in projects:
            raise fastapi.HTTPException(
                status_code=404, detail=f"Workspace '{workspace_id}' not found")
        return projects[workspace_id]

    def _require_control_tier():
        """Tier gate matching the CLI `hub` command — Team/Enterprise only.

        Uses auth.has_tier (non-exiting) so an HTTP 403 is returned instead of
        the CLI's sys.exit. has_tier returns True when MAESTRO_SKIP_AUTH=1.
        """
        from maestro import auth
        if not auth.has_tier(auth.HUB_TIERS):
            raise fastapi.HTTPException(
                status_code=403,
                detail="Maestro Hub dispatch control requires a Team or Enterprise licence.",
            )

    @app.post("/api/v1/workspaces/{workspace_id}/dispatch", response_model=ControlResult)
    async def dispatch_workspace(workspace_id: str):
        """Start the dispatcher for a workspace as a detached background process."""
        import os
        import subprocess
        import sys
        from maestro.hub import aggregator
        from maestro.workspace import (
            artefact_parent_for_entry, product_repo_for_entry, resolve_artefact_dir,
        )

        _require_control_tier()
        # Observe-only (containerized) backends cannot launch a usable host
        # dispatcher — fail loudly with a structured 409 the UI surfaces,
        # instead of spawning a no-op dispatcher inside the container and
        # returning a misleading "starting" (BUG-MSO-2026-0395).
        if _is_observe_only():
            raise fastapi.HTTPException(status_code=409, detail=OBSERVE_ONLY_MESSAGE)
        # Registry/workspace reads can raise a raw OSError (e.g. Errno 5 on a
        # stale Docker bind-mount after a Docker Desktop restart). Degrade to a
        # 503 with a "restart containers" hint rather than leaking a traceback.
        try:
            entry = _resolve_workspace_entry(workspace_id)
            ws_root = artefact_parent_for_entry(entry)
            mso = resolve_artefact_dir(ws_root)
            # The dispatch subprocess's cwd must be the PRODUCT repo — in
            # solo/shared artefact mode ws_root/mso are the artefact repo, which
            # carries no source checkout for git worktree/branch operations to
            # run against (FTR-MSO-2026-0369). MAESTRO_DIR below still points the
            # dispatcher at the correct artefact plane regardless of cwd.
            product_repo = product_repo_for_entry(entry)
        except OSError:
            raise fastapi.HTTPException(status_code=503, detail=STALE_MOUNT_MESSAGE)

        # Don't spawn a duplicate if one is already running.
        try:
            if aggregator._dispatcher_running(mso):
                return ControlResult(
                    ok=True, workspace_id=workspace_id, action="dispatch",
                    message="Dispatcher already running",
                )
        except Exception:
            pass

        env = {**os.environ, "MAESTRO_DIR": str(mso)}
        cmd = [sys.executable, "-m", "maestro.cli", "dispatch", "--max-crews", "5"]
        kwargs = dict(
            cwd=str(product_repo),
            env=env,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        if os.name == "nt":
            DETACHED_PROCESS = 0x00000008
            CREATE_NEW_PROCESS_GROUP = 0x00000200
            kwargs["creationflags"] = DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
            kwargs["close_fds"] = True
        else:
            kwargs["start_new_session"] = True
        subprocess.Popen(cmd, **kwargs)
        return ControlResult(
            ok=True, workspace_id=workspace_id, action="dispatch",
            message="Dispatcher starting",
        )

    @app.post("/api/v1/workspaces/{workspace_id}/stop", response_model=ControlResult)
    async def stop_workspace(workspace_id: str):
        """Stop (hold) the dispatcher + crews for a workspace via scoped cleanup."""
        import os
        import subprocess
        import sys
        from maestro.workspace import (
            artefact_parent_for_entry, product_repo_for_entry, resolve_artefact_dir,
        )

        _require_control_tier()
        try:
            entry = _resolve_workspace_entry(workspace_id)
            ws_root = artefact_parent_for_entry(entry)
            mso = resolve_artefact_dir(ws_root)
            product_repo = product_repo_for_entry(entry)
        except OSError:
            raise fastapi.HTTPException(status_code=503, detail=STALE_MOUNT_MESSAGE)

        env = {**os.environ, "MAESTRO_DIR": str(mso)}
        try:
            subprocess.run(
                [sys.executable, "-m", "maestro.cli", "cleanup", "--no-backup"],
                cwd=str(product_repo),
                env=env,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=60,
            )
        except subprocess.TimeoutExpired:
            return ControlResult(
                ok=False, workspace_id=workspace_id, action="stop",
                message="Cleanup timed out",
            )
        return ControlResult(
            ok=True, workspace_id=workspace_id, action="stop",
            message="Dispatcher stopped",
        )

    @app.post("/api/v1/workspaces/{workspace_id}/sweep", response_model=SweepResult)
    async def sweep_workspace(workspace_id: str, dry_run: bool = False):
        """Run the housekeeping reconcile for a workspace (FTR-MSO-2026-0426).

        The human approves and merges the voyage PR most of the time, so
        Maestro never observes the merge event — housekeeping has to be
        PULL-based. This is that pull: validate every voyage's PR state,
        archive the merged ones, annotate merge metadata, reconcile
        archived-but-not-COMPLETE orders, and report what was REFUSED and why.

        Runs ``mso voyage reconcile --json`` as a subprocess so the button and
        the CLI execute literally the same code path (``run_housekeeping_sweep``)
        and cannot drift. Does NOT require a running dispatcher.

        Same protections as the other control endpoints: Team/Enterprise tier
        gate, the shared CORS/origin allow-list, the observe-only 409 (merge
        detection needs git + gh against the product repo, which a containerized
        observe-only backend does not have) and the stale-mount 503.
        """
        import json as _json
        import os
        import subprocess
        import sys
        from maestro.workspace import (
            artefact_parent_for_entry, product_repo_for_entry, resolve_artefact_dir,
        )

        _require_control_tier()
        # BUG-MSO-2026-0440: gate on what HOUSEKEEPING needs (gh), not on
        # whether a dispatcher could be spawned (Claude CLI).
        _sweep_blocked = _sweep_unavailable_reason()
        if _sweep_blocked:
            raise fastapi.HTTPException(status_code=409, detail=_sweep_blocked)
        try:
            entry = _resolve_workspace_entry(workspace_id)
            ws_root = artefact_parent_for_entry(entry)
            mso = resolve_artefact_dir(ws_root)
            # cwd must be the PRODUCT repo: merge detection probes git refs and
            # resolves `gh` against the product remote. In solo/shared artefact
            # mode the artefact repo has neither.
            product_repo = product_repo_for_entry(entry)
        except OSError:
            raise fastapi.HTTPException(status_code=503, detail=STALE_MOUNT_MESSAGE)

        cmd = [sys.executable, "-m", "maestro.cli", "voyage", "reconcile", "--json"]
        if dry_run:
            cmd.append("--dry-run")
        try:
            proc = subprocess.run(
                cmd,
                cwd=str(product_repo),
                env={**os.environ, "MAESTRO_DIR": str(mso)},
                stdin=subprocess.DEVNULL,
                capture_output=True,
                text=True,
                timeout=300,
            )
        except subprocess.TimeoutExpired:
            raise fastapi.HTTPException(
                status_code=504,
                detail="Housekeeping sweep timed out after 5 minutes (a PR "
                       "lookup may be hanging). No changes were reported.")

        if proc.returncode != 0:
            detail = (proc.stderr or proc.stdout or "").strip()[-500:]
            raise fastapi.HTTPException(
                status_code=500,
                detail=f"Housekeeping sweep failed: {detail or 'unknown error'}")
        try:
            # The CLI prints the JSON report last; tolerate any leading output.
            out = proc.stdout or ""
            payload = _json.loads(out[out.index("{"):])
        except (ValueError, _json.JSONDecodeError):
            raise fastapi.HTTPException(
                status_code=500,
                detail="Housekeeping sweep produced no readable report.")

        archived = payload.get("archived", 0)
        annotated = payload.get("annotated", 0)
        refusals = payload.get("refusals", []) or []
        verb = "would be " if dry_run else ""
        parts = [f"{archived} voyage(s) {verb}archived",
                 f"{annotated} {verb}annotated"]
        if refusals:
            parts.append(f"{len(refusals)} left untouched")
        return SweepResult(
            ok=True,
            workspace_id=workspace_id,
            action="sweep",
            message=("Dry run — " if dry_run else "") + ", ".join(parts),
            dryRun=bool(payload.get("dryRun", dry_run)),
            archived=archived,
            annotated=annotated,
            changes=payload.get("changes", []) or [],
            refusals=refusals,
        )

    # -----------------------------------------------------------------------
    # Phase 3 — Review queue endpoints
    # -----------------------------------------------------------------------

    def _iter_workspaces():
        """Yield (workspace_id, artefact_root_parent) for every registered workspace."""
        import maestro.registry as registry
        from maestro.workspace import artefact_parent_for_entry
        for ws_id, entry in registry.list_projects().items():
            yield ws_id, artefact_parent_for_entry(entry)

    def _find_order_workspace(order_id: str):
        """Return (workspace_id, workspace_path) for an order in any review queue.

        Raises HTTPException 404 if not found in any registered workspace.
        """
        _validate_order_id(order_id)
        from maestro.hub.review import _get_mso_dir
        for ws_id, ws_root in _iter_workspaces():
            try:
                mso = _get_mso_dir(ws_root)
                if (mso / "queues" / "review" / f"{order_id}.json").exists():
                    return ws_id, ws_root
            except Exception:
                pass
        raise fastapi.HTTPException(status_code=404, detail=f"Order '{order_id}' not found in any review queue")

    @app.get("/api/v1/review/queue", response_model=list[ReviewItem])
    async def review_queue():
        """List all NAV_REVIEW_PENDING orders across all registered workspaces.

        Returns a BARE ARRAY of ReviewItem (frontend api.ts contract).
        """
        from maestro.hub.review import find_review_pending_orders
        items: list[ReviewItem] = []
        for ws_id, ws_root in _iter_workspaces():
            try:
                orders = find_review_pending_orders(ws_root)
            except Exception:
                continue
            for data in orders:
                order_id = data.get("id") or data.get("orderId") or ""
                role = "PLN" if data.get("planApprovalOnly") else (data.get("targetRole") or data.get("role") or "")
                priority = (str(data.get("priority")).lower() if data.get("priority") else None)
                if priority in ("medium", "med", "default"):
                    priority = "normal"
                elif priority in ("urgent", "critical"):
                    priority = "high"
                items.append(ReviewItem(
                    order_id=order_id,
                    workspace_id=ws_id,
                    workspace_name=ws_id,
                    order_title=data.get("title", "") or "",
                    role=role,
                    voyage_id=data.get("voyageId") or None,
                    created_at=data.get("createdAt", "") or "",
                    paused_at=data.get("navReviewPausedAt") or None,
                    priority=priority if priority in ("high", "normal", "low") else None,
                ))
        return items

    @app.get("/api/v1/review/{order_id}/plan", response_model=PlanResponse)
    async def review_get_plan(order_id: str):
        """Return plan markdown (or order description as fallback) plus order JSON."""
        from maestro.hub.review import get_plan_content
        ws_id, ws_root = _find_order_workspace(order_id)
        plan_md, has_plan, order_data = get_plan_content(ws_root, order_id)
        if order_data is None:
            raise fastapi.HTTPException(status_code=404, detail=f"Order '{order_id}' not found")
        return PlanResponse(
            workspace_id=ws_id,
            order_id=order_id,
            plan_markdown=plan_md or "",
            has_plan_file=has_plan,
            order=order_data,
        )

    @app.post("/api/v1/review/{order_id}/approve", response_model=ActionResult)
    async def review_approve(order_id: str):
        """Approve a NAV_REVIEW_PENDING order — moves to queues/orders/ with status PENDING."""
        _require_control_tier()
        from maestro.hub.review import approve_order
        ws_id, ws_root = _find_order_workspace(order_id)
        try:
            result = approve_order(ws_root, order_id)
        except FileNotFoundError as exc:
            raise fastapi.HTTPException(status_code=404, detail=str(exc))
        except ValueError as exc:
            raise fastapi.HTTPException(status_code=409, detail=str(exc))
        return ActionResult(ok=True, order_id=order_id, new_status=result["new_status"],
                            message=f"Order {order_id} approved")

    @app.post("/api/v1/review/{order_id}/revise", response_model=ActionResult)
    async def review_revise(order_id: str, body: ReviseRequest):
        """Request revision — writes feedback to order, leaves in review queue."""
        _require_control_tier()
        from maestro.hub.review import revise_order
        ws_id, ws_root = _find_order_workspace(order_id)
        try:
            result = revise_order(ws_root, order_id, body.feedback)
        except FileNotFoundError as exc:
            raise fastapi.HTTPException(status_code=404, detail=str(exc))
        except ValueError as exc:
            raise fastapi.HTTPException(status_code=409, detail=str(exc))
        return ActionResult(ok=True, order_id=order_id, new_status=result["new_status"],
                            message=f"Order {order_id} sent for revision")

    @app.post("/api/v1/review/{order_id}/reject", response_model=ActionResult)
    async def review_reject(order_id: str, body: RejectRequest):
        """Reject an order — marks REJECTED, moves to queues/review/rejected/."""
        _require_control_tier()
        from maestro.hub.review import reject_order
        ws_id, ws_root = _find_order_workspace(order_id)
        try:
            result = reject_order(ws_root, order_id, body.reason)
        except FileNotFoundError as exc:
            raise fastapi.HTTPException(status_code=404, detail=str(exc))
        except ValueError as exc:
            raise fastapi.HTTPException(status_code=409, detail=str(exc))
        return ActionResult(ok=True, order_id=order_id, new_status=result["new_status"],
                            message=f"Order {order_id} rejected")

    # -----------------------------------------------------------------------
    # Usage aggregation endpoints (FTR-MSO-2026-0333) — read-only, ungated
    # -----------------------------------------------------------------------

    @app.get("/api/v1/usage", response_model=UsageRollup)
    async def get_usage_rollup(
        from_: str | None = fastapi.Query(default=None, alias="from"),
        to: str | None = fastapi.Query(default=None),
        group_by: str = fastapi.Query(default="project"),
    ):
        """Cross-workspace usage rollup, optionally filtered by date range.

        group_by: 'project' | 'voyage' | 'order' | 'role'
        from / to: inclusive date range in YYYY-MM-DD format
        """
        from maestro.hub.aggregator import aggregate_usage_cross_workspace
        if group_by not in ("project", "voyage", "order", "role"):
            raise fastapi.HTTPException(
                status_code=400,
                detail=f"Invalid group_by '{group_by}'. Must be one of: project, voyage, order, role",
            )
        return aggregate_usage_cross_workspace(
            from_date=from_,
            to_date=to,
            group_by=group_by,
        )

    @app.get("/api/v1/usage/projects/{project_id}", response_model=UsageRollup)
    async def get_project_usage(
        project_id: str,
        from_: str | None = fastapi.Query(default=None, alias="from"),
        to: str | None = fastapi.Query(default=None),
    ):
        """Per-project usage with voyage/order breakdown."""
        import maestro.registry as registry
        from maestro.hub.aggregator import aggregate_usage_for_project
        from maestro.workspace import artefact_parent_for_entry

        projects = registry.list_projects()
        if project_id not in projects:
            raise fastapi.HTTPException(status_code=404, detail=f"Project '{project_id}' not found")
        ws_root = artefact_parent_for_entry(projects[project_id])
        return aggregate_usage_for_project(project_id, ws_root, from_date=from_, to_date=to)

    @app.get("/api/v1/usage/voyages/{voyage_id}", response_model=UsageRollup)
    async def get_voyage_usage(
        voyage_id: str,
        from_: str | None = fastapi.Query(default=None, alias="from"),
        to: str | None = fastapi.Query(default=None),
    ):
        """Per-voyage usage: orders breakdown (+ role breakdown if FTR-0332 data present)."""
        import maestro.registry as registry
        from maestro.hub.aggregator import aggregate_usage_for_voyage, _get_mso_dir
        from maestro.workspace import artefact_parent_for_entry

        projects = registry.list_projects()
        for ws_id, entry in projects.items():
            ws_root = artefact_parent_for_entry(entry)
            try:
                mso = _get_mso_dir(ws_root)
            except Exception:
                continue
            for sub in ("active", "complete"):
                if (mso / "voyages" / sub / f"{voyage_id}.json").exists():
                    return aggregate_usage_for_voyage(voyage_id, ws_root, from_date=from_, to_date=to)
        # No workspace claims the voyage — return a zero rollup (not an error)
        return UsageRollup(from_date=from_, to_date=to, group_by="order")

    @app.get("/api/v1/usage/orders/{order_id}", response_model=OrderUsageDetail)
    async def get_order_usage(order_id: str):
        """Per-order usage: roles/iterations/models breakdown."""
        from maestro.hub.aggregator import _find_order_usage_dir, get_order_usage_detail

        usage_dir = _find_order_usage_dir(order_id)
        if usage_dir is None:
            # Order not found in any workspace — return a zero detail (not an error)
            return OrderUsageDetail(order_id=order_id)
        return get_order_usage_detail(order_id, usage_dir)

    @app.websocket("/api/v1/lifecycle/stream")
    async def lifecycle_stream(websocket: fastapi.WebSocket):
        import asyncio
        import maestro.registry as registry
        import maestro.hub.server as _server_mod
        from maestro.hub.lifecycle_tail import (
            LifecycleTail, _parse_event_type, _parse_timestamp, _parse_message,
            _parse_order_id, _parse_role, _parse_crew_slot, _parse_subtype,
        )
        from maestro.hub.models import LifecycleEvent
        from maestro.workspace import artefact_parent_for_entry

        def _build_event(ws_id: str, ws_name: str, line: str) -> LifecycleEvent:
            return LifecycleEvent(
                workspace_id=ws_id,
                workspace_name=ws_name,
                line=line,
                message=_parse_message(line),
                timestamp=_parse_timestamp(line),
                event_type=_parse_event_type(line),
                order_id=_parse_order_id(line),
                crew_slot=_parse_crew_slot(line),
                role=_parse_role(line),
                subtype=_parse_subtype(line),
            )

        # Audit finding H6: WebSockets bypass CORS, so validate the Origin
        # against the allowlist and enforce the bearer token (query param) BEFORE
        # accepting — otherwise any web page could open ws:// to the localhost
        # Hub and live-tail every workspace's lifecycle log.
        origin = websocket.headers.get("origin")
        if origin and origin not in _ORIGINS:
            await websocket.close(code=1008)
            return
        _tok = _expected_token()
        if _tok:
            import hmac as _hmac
            presented = websocket.query_params.get("token", "")
            if not presented or not _hmac.compare_digest(presented, _tok):
                await websocket.close(code=1008)
                return

        await websocket.accept()
        try:
            projects = registry.list_projects()
            # Optional ?workspace_id=<ID> scopes the stream to one workspace
            # (the detail page passes it); absent → stream all (overview page).
            only = websocket.query_params.get("workspace_id")
            if only:
                projects = {k: v for k, v in projects.items() if k == only}
            tails: dict[str, tuple[str, LifecycleTail]] = {
                ws_id: (ws_id, LifecycleTail(artefact_parent_for_entry(entry)))
                for ws_id, entry in projects.items()
            }

            # Backfill: send last 20 lines per workspace on connect
            for ws_id, (ws_name, tail) in tails.items():
                for line in tail.read_last_n(20):
                    await websocket.send_json(_build_event(ws_id, ws_name, line).model_dump())
                tail.seek_to_end()

            # Poll loop: push new lines every _WS_POLL_INTERVAL seconds
            while True:
                await asyncio.sleep(_server_mod._WS_POLL_INTERVAL)
                for ws_id, (ws_name, tail) in tails.items():
                    for line in tail.read_new_lines():
                        await websocket.send_json(_build_event(ws_id, ws_name, line).model_dump())
        except Exception:
            pass  # client disconnected or connection error

    return app
