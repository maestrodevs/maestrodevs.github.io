# maestro.hooks — Claude Code hooks

from pathlib import Path

from maestro.workspace import find_workspace_dir


def find_mso_root(start_dir: str) -> "Path | None":
    """Walk up from start_dir to find a Maestro workspace root.

    Checks ``.mso/config/`` (v4.0) via the central
    :func:`maestro.workspace.find_workspace_dir` resolver (FTR-MSO-2026-0362).
    Returns the workspace root (the ``.mso`` parent), or None.
    """
    mso = find_workspace_dir(Path(start_dir).resolve())
    return mso.parent if mso is not None else None
