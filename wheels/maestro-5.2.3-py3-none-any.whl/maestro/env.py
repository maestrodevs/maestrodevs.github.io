"""maestro.env — canonical env-var reader (MAESTRO_* only, v4.0+).

Use MAESTRO_* env var names (v4.0+).
See MIGRATION-v4.md for the full mapping.
"""

from __future__ import annotations

import os


def _env(name: str, default: str = "") -> str:
    """Read a MAESTRO_* env var, returning *default* if unset."""
    v = os.environ.get(name)
    return v if v is not None else default


# ---------------------------------------------------------------------------
# Named accessors for every MAESTRO_* variable in the v4.0 surface.
# ---------------------------------------------------------------------------

def sprint_branch(default: str = "") -> str:
    return _env("MAESTRO_SPRINT_BRANCH", default)


def branch_guard_bypass() -> bool:
    return _env("MAESTRO_BRANCH_GUARD_BYPASS") == "1"


def path_guard_bypass() -> bool:
    """BUG-MSO-2026-0282: escape hatch for the worktree path-confinement guard.

    Honours the dedicated MAESTRO_PATH_GUARD_BYPASS as well as the broader
    MAESTRO_BRANCH_GUARD_BYPASS, so a single bypass var frees LEAD manual-recovery
    sessions from both discipline guards.
    """
    return _env("MAESTRO_PATH_GUARD_BYPASS") == "1" or branch_guard_bypass()


def squad_drain_seconds(default: str = "5") -> str:
    return _env("MAESTRO_SQUAD_DRAIN_SECONDS", default)


def skip_auth() -> bool:
    return _env("MAESTRO_SKIP_AUTH") == "1"


def repo_path(default: str = "") -> str:
    return _env("MAESTRO_REPO_PATH", default)


def artefact_root(default: str = "") -> str:
    """FTR-MSO-2026-0368: the artefact repo's ``.mso`` dir, set by the dispatcher
    from ``get_artefact_root()``.

    In embedded mode this equals the product repo's ``.mso``; in solo/shared mode
    it points at the SEPARATE artefact repo where crew deliverables (plans,
    handoffs, reports, prompts, usage) live. The hook guards read it to distinguish
    the two repos in the split topology.
    """
    return _env("MAESTRO_ARTEFACT_ROOT", default)


def temp_dir(default: str = "") -> str:
    return _env("MAESTRO_TEMP", default)


def slack_bot_token(default: str = "") -> str:
    return _env("MAESTRO_SLACK_BOT_TOKEN", default)


def slack_app_token(default: str = "") -> str:
    return _env("MAESTRO_SLACK_APP_TOKEN", default)


def bridge_gist_id(default: str = "") -> str:
    return _env("MAESTRO_BRIDGE_GIST_ID", default)


def github_token(default: str = "") -> str:
    return _env("MAESTRO_GITHUB_TOKEN", default)
