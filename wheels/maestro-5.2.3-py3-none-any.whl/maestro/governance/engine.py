"""
Governance evaluation engine — deterministic deny/allow/warn evaluator.

FTR-MSO-2026-0392 (PLAN-PLN-MSO-2026-0372 Phase 1).

The engine is a PURE, side-effect-free function of ``(policy, context) ->
Decision``. No I/O, no logging, no clock — so it is trivially unit-testable and
can be reused unchanged by the Phase 5 CI backstop (same evaluator run over a
committed diff).

Precedence (the "org DENY always wins" rule):
  * Tiers rank org (0) > workspace (1) > user (2).
  * A matching DENY is honoured unless an ALLOW at an equal-or-higher tier
    explicitly carves it out (rule id listed in the ALLOW's ``exceptions``).
  * A lower tier can only *tighten* (add DENYs); it can never relax a
    higher-tier DENY.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

from maestro.governance.schema import (
    TIER_RANK,
    PolicyBundle,
    PolicyRule,
)
from maestro.governance.context import EvalContext


@dataclass(frozen=True)
class MergedPolicy:
    """The merged rule set the engine evaluates (built by the loader)."""

    rules: tuple[PolicyRule, ...]
    default_action: str = "allow"          # allow | deny (posture when nothing matches)
    governed_mode: str = "enforce"         # enforce | warn


@dataclass(frozen=True)
class Decision:
    """The engine's verdict for one action."""

    allowed: bool
    action: str                # deny | allow | warn
    rule_id: str = ""
    reason: str = ""
    severity: str = ""
    tier: str = ""

    def as_dict(self) -> dict:
        return {
            "allowed": self.allowed,
            "action": self.action,
            "ruleId": self.rule_id,
            "reason": self.reason,
            "severity": self.severity,
            "tier": self.tier,
        }


def merged_policy_from_bundles(bundles: list[PolicyBundle]) -> MergedPolicy:
    """Flatten validated bundles into a single MergedPolicy.

    Rules retain their owning bundle's tier (stamped at parse time). The
    strictest ``governedMode`` and ``defaultAction`` across bundles win:
    any bundle asking to ``enforce`` makes the set enforcing, and any bundle
    defaulting to ``deny`` makes the merged default ``deny``.
    """
    rules: list[PolicyRule] = []
    governed_mode = "warn"
    default_action = "allow"
    for b in bundles:
        rules.extend(b.rules)
        if b.governed_mode == "enforce":
            governed_mode = "enforce"
        if b.default_action == "deny":
            default_action = "deny"
    # Deterministic ordering: by tier authority, then rule id.
    rules.sort(key=lambda r: (TIER_RANK.get(r.tier, 99), r.id))
    return MergedPolicy(
        rules=tuple(rules),
        default_action=default_action,
        governed_mode=governed_mode,
    )


def _rule_matches(rule: PolicyRule, ctx: EvalContext) -> bool:
    """True when every present condition of the rule holds against ctx."""
    m = rule.match

    # Tool gate — if the rule names tools, the context tool must be among them.
    if m.tool and ctx.tool not in m.tool:
        return False

    # Environment-class narrowing.
    if m.env_class and ctx.env_class not in m.env_class:
        return False

    # Command/subject pattern.
    if m.command_pattern:
        subject = ctx.subject_text
        if not subject:
            return False
        try:
            if re.search(m.command_pattern, subject) is None:
                return False
        except re.error:
            # A malformed pattern must not silently pass. Treat a broken DENY
            # pattern as matching (fail-closed for deny) and a broken
            # ALLOW/WARN pattern as non-matching (never relaxes on error).
            return rule.action == "deny"

    # A rule with no conditions at all matches nothing (avoids accidental
    # blanket rules); require at least one predicate to have been present.
    if not (m.tool or m.env_class or m.command_pattern):
        return False

    return True


def evaluate(policy: MergedPolicy, ctx: EvalContext) -> Decision:
    """Evaluate ``ctx`` against ``policy`` and return a Decision.

    Deterministic and side-effect-free.
    """
    matched_denies: list[PolicyRule] = []
    matched_allows: list[PolicyRule] = []
    matched_warns: list[PolicyRule] = []

    for rule in policy.rules:
        if not _rule_matches(rule, ctx):
            continue
        if rule.action == "deny":
            matched_denies.append(rule)
        elif rule.action == "allow":
            matched_allows.append(rule)
        elif rule.action == "warn":
            matched_warns.append(rule)

    # Honour DENYs in tier-authority order; a DENY stands unless an ALLOW at an
    # equal-or-higher tier explicitly lists it in `exceptions`.
    for deny in sorted(matched_denies, key=lambda r: TIER_RANK.get(r.tier, 99)):
        deny_rank = TIER_RANK.get(deny.tier, 99)
        carved_out = any(
            deny.id in allow.exceptions and TIER_RANK.get(allow.tier, 99) <= deny_rank
            for allow in matched_allows
        )
        if not carved_out:
            return Decision(
                allowed=False,
                action="deny",
                rule_id=deny.id,
                reason=deny.reason or f"Denied by governance rule '{deny.id}'.",
                severity=deny.severity,
                tier=deny.tier,
            )

    if matched_warns:
        w = matched_warns[0]
        return Decision(
            allowed=True,
            action="warn",
            rule_id=w.id,
            reason=w.reason or f"Governance warning from rule '{w.id}'.",
            severity=w.severity,
            tier=w.tier,
        )

    # Nothing denied. Fall back to the merged default posture.
    if policy.default_action == "deny":
        return Decision(
            allowed=False,
            action="deny",
            rule_id="",
            reason="Denied by governance default posture (deny-by-default).",
            severity="high",
            tier="",
        )

    return Decision(allowed=True, action="allow")
