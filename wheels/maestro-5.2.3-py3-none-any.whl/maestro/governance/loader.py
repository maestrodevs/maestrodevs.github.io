"""
Governance bundle loader — discovery, integrity verify, merge.

FTR-MSO-2026-0392 (PLAN-PLN-MSO-2026-0372 Phase 1).

Mirrors the verify-before-load shape of ``maestro/identity/integrity.py`` but
targets the built-in policy library that ships INSIDE the pip package (so a git
check is not applicable — client machines run from site-packages). Instead each
built-in pack is verified against a SHA-256 manifest (``library/integrity.json``)
that ships alongside the packs. A pack whose bytes do not match the manifest is
refused: in governed mode the pretool hook treats the resulting GovernanceError
as fail-closed.

Phase 2 swaps the hash manifest for an Ed25519 detached signature over the same
loader skeleton — the shape here is chosen to make that a drop-in upgrade.

Precedence order of merged bundles:  org (built-in) > workspace > user.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

from maestro.governance.schema import GovernanceError, PolicyBundle
from maestro.governance.engine import MergedPolicy, merged_policy_from_bundles

LIBRARY_DIRNAME = "library"
INTEGRITY_MANIFEST = "integrity.json"

# The built-in packs that ship with Maestro (Phase 1 scope: two packs).
BUILTIN_PACKS = ("destructive-data.json", "protected-branch.json")


def _library_dir() -> Path:
    return Path(__file__).resolve().parent / LIBRARY_DIRNAME


def _sha256(path: Path) -> str:
    """SHA-256 of the pack's *canonical* content (CRLF normalised to LF).

    BUG-001 (FTR-MSO-2026-0392): the manifest must survive a benign line-ending
    transform. The packs are committed LF, but a Windows checkout under
    ``core.autocrlf=true`` rewrites them to CRLF, which changes the raw-byte
    hash and — in governed ``enforce`` mode — fails closed against every mutating
    tool. Hashing the canonical (LF) content makes verification EOL-insensitive
    while still detecting genuine tampering: any content edit changes the
    normalised hash. Paired with a ``.gitattributes`` LF pin for defence in depth.
    """
    data = path.read_bytes().replace(b"\r\n", b"\n")
    return hashlib.sha256(data).hexdigest()


def _load_manifest(library_dir: Path) -> dict[str, str]:
    manifest_path = library_dir / INTEGRITY_MANIFEST
    if not manifest_path.exists():
        raise GovernanceError(
            f"governance library manifest missing: {manifest_path}. "
            "The built-in policy packs cannot be integrity-verified — refusing to load."
        )
    try:
        data = json.loads(manifest_path.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001 — any parse error is a hard integrity failure
        raise GovernanceError(
            f"governance library manifest unreadable ({manifest_path}): {exc}"
        ) from exc
    files = data.get("files", data) if isinstance(data, dict) else {}
    if not isinstance(files, dict):
        raise GovernanceError("governance library manifest has no 'files' map")
    return files


def _verify_pack(pack_path: Path, manifest: dict[str, str]) -> None:
    """Raise GovernanceError unless pack_path's SHA-256 matches the manifest."""
    key = pack_path.name
    recorded = manifest.get(key)
    if recorded is None:
        raise GovernanceError(
            f"policy pack '{key}' has no entry in the integrity manifest — refusing to load."
        )
    actual = _sha256(pack_path)
    if actual != recorded:
        raise GovernanceError(
            f"policy pack '{key}' failed integrity check "
            f"(manifest={recorded[:12]}… actual={actual[:12]}…) — file may have been tampered."
        )


def load_builtin_bundles(*, verify: bool = True) -> list[PolicyBundle]:
    """Load + integrity-verify the built-in policy packs (tier=org)."""
    library_dir = _library_dir()
    manifest = _load_manifest(library_dir) if verify else {}
    bundles: list[PolicyBundle] = []
    for name in BUILTIN_PACKS:
        pack_path = library_dir / name
        if not pack_path.exists():
            raise GovernanceError(f"built-in policy pack missing: {pack_path}")
        if verify:
            _verify_pack(pack_path, manifest)
        try:
            raw = json.loads(pack_path.read_text(encoding="utf-8"))
        except Exception as exc:  # noqa: BLE001
            raise GovernanceError(f"policy pack '{name}' is not valid JSON: {exc}") from exc
        # Built-in packs ship UNSIGNED (SHA-256-manifest verified above); this
        # hook is a no-op for them but verifies any future signed vendor pack.
        _maybe_verify_signature(raw, tier="org", verify=verify, workspace=None)
        bundles.append(PolicyBundle.from_dict(raw, tier="org"))
    return bundles


def _maybe_verify_signature(
    raw: dict, *, tier: str, verify: bool, workspace: Path | None
) -> None:
    """Phase-2 hook (FTR-MSO-2026-0397): if a bundle carries an Ed25519 signature
    envelope, verify it (+ anti-rollback + freshness stamp) before it is trusted.

    An UNSIGNED bundle is normally a no-op here — so non-Enterprise / Phase-1
    workspaces keep exactly the Phase-1 behaviour (AC4). BUT when the workspace
    sets ``governance.requireSignature`` the per-tool-call loader MUST refuse an
    unsigned (or signature-stripped) workspace bundle rather than silently pass it
    through (SEC-FTR-MSO-2026-0397 F2 — otherwise an attacker strips the signature
    envelope to dodge verification). ``verify_signed_bundle`` already implements
    that fail-closed check; this hook just has to feed it ``require_signature``.

    BUG-MSO-2026-0402 (SEC-FTR-MSO-2026-0397 F10 fast-follow): the resolution of
    ``requireSignature`` must ALSO fail closed on a corrupt/unreadable
    ``workspace.json`` — matching the launch-time dispatch gate, which already
    calls ``require_signature_for(ws, enforce=True)``. Without ``enforce=True``
    here, an attacker who corrupts ``workspace.json`` mid-session makes
    ``require_signature_for`` silently return ``False``, then presents a
    signature-stripped bundle that the per-tool evaluation trusts. Passing
    ``enforce=True`` is the safe default: an unreadable config encountered while
    loading a workspace bundle => require the signature (raise GovernanceError,
    which the pretool hook denies in enforce mode / logs-only in warn mode).

    Verification is skipped entirely when ``verify=False`` (the integrity-bypass
    path used by some unit tests), matching the manifest-verify skip above it.
    """
    if not verify:
        return
    from maestro.governance.signing import verify_signed_bundle, require_signature_for

    # The workspace tier resolves keys against the workspace config AND is the tier
    # a distributed policy bundle lands on, so it is where requireSignature applies.
    # The user tier (global ~/.maestro) resolves against vendor + env keys only.
    ws = workspace if tier == "workspace" else None
    # enforce=True => a broken workspace.json fails CLOSED (BUG-MSO-2026-0402 / F10),
    # so the per-tool load path can no longer be downgraded by corrupting config.
    require_sig = require_signature_for(ws, enforce=True) if tier == "workspace" else False
    verify_signed_bundle(raw, workspace=ws, record=True, require_signature=require_sig)


def _load_optional_bundle(
    path: Path, tier: str, *, verify: bool = True, workspace: Path | None = None
) -> PolicyBundle | None:
    """Load a workspace/user bundle if present. Malformed => GovernanceError."""
    if not path.exists():
        return None
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001
        raise GovernanceError(f"{tier} policy bundle unreadable ({path}): {exc}") from exc
    _maybe_verify_signature(raw, tier=tier, verify=verify, workspace=workspace)
    return PolicyBundle.from_dict(raw, tier=tier)


def load_bundles(workspace: Path | None = None, *, verify: bool = True) -> list[PolicyBundle]:
    """Discover and load all applicable bundles: built-in (org) > workspace > user."""
    bundles = load_builtin_bundles(verify=verify)

    if workspace is not None:
        from maestro.workspace import MSO_DIR_NAME
        ws_bundle = _load_optional_bundle(
            Path(workspace) / MSO_DIR_NAME / "config" / "policy-bundle.json", "workspace",
            verify=verify, workspace=workspace,
        )
        if ws_bundle is not None:
            bundles.append(ws_bundle)

    # BUG-002 (FTR-MSO-2026-0392): route the user-tier bundle path through the
    # single sanctioned owner of the ".maestro" home literal (BUG-MSO-2026-0387).
    # A raw ``Path.home() / ".maestro"`` join bypasses the MAESTRO_HOME override,
    # breaks test isolation, and fails the package-wide home-join guard.
    from maestro.workspace import get_maestro_home

    user_bundle = _load_optional_bundle(
        get_maestro_home() / "policy-bundle.json", "user",
        verify=verify, workspace=workspace,
    )
    if user_bundle is not None:
        bundles.append(user_bundle)

    return bundles


def load_policy(workspace: Path | None = None, *, verify: bool = True) -> MergedPolicy:
    """Load, verify, and merge all bundles into a single evaluable MergedPolicy.

    Raises GovernanceError on any integrity/schema failure — callers in governed
    mode must treat that as fail-closed.
    """
    bundles = load_bundles(workspace, verify=verify)
    return merged_policy_from_bundles(bundles)


# ---------------------------------------------------------------------------
# Manifest generation (maintenance helper — run when a built-in pack changes)
# ---------------------------------------------------------------------------

def build_library_manifest() -> Path:
    """Recompute library/integrity.json from the current pack bytes.

    Invoked by maintainers (and the unit tests' fixture builder) whenever a
    built-in pack is edited. Never called at runtime.
    """
    library_dir = _library_dir()
    files: dict[str, str] = {}
    for name in BUILTIN_PACKS:
        pack_path = library_dir / name
        files[name] = _sha256(pack_path)
    manifest = {
        "schemaVersion": "1.0",
        "algorithm": "sha256",
        "files": files,
    }
    manifest_path = library_dir / INTEGRITY_MANIFEST
    manifest_path.write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return manifest_path
