"""
Branch-discipline guard for crew git/gh operations.

Refuses any git/gh tool call that mutates state on a branch other than
MAESTRO_SPRINT_BRANCH.
Bypass with MAESTRO_BRANCH_GUARD_BYPASS=1
(operator manual-recovery sessions only — must be set explicitly in the
parent shell).

Background:
  - BUG-ADM-2026-0004. The dispatcher records `voyageBranch` on every
    order but historically nothing verified that crews actually operated
    on that branch. Crews running on the wrong branch produced
    cross-voyage contamination during the VOY-0028 / VOY-0030 batch1
    split (PR #30 → PR #31 + #32) and forced a `git push
    --force-with-lease` recovery. This module is the runtime enforcement.

  - BUG-ADM-2026-0009 (v2.5.7). The original implementation fell open
    when MAESTRO_SPRINT_BRANCH was unset, on the assumption that
    Captain interactive sessions and "loose" orders without a voyage
    needed an unmoderated path. That hatch was too permissive: a crew
    dispatched without a voyageBranch silently inherited whatever branch
    the dispatcher's parent shell happened to be on (in Captain's repro,
    `restructure/flatten-structure`) and pushed 3 commits there. The
    intended voyage branch missed the work. The fix below now refuses
    mutating git/gh tool calls when MAESTRO_SPRINT_BRANCH is unset,
    keeping non-mutating commands (status, diff, log) free. Operator
    manual-recovery sessions opt out via MAESTRO_BRANCH_GUARD_BYPASS=1
    in the parent shell.
"""

from __future__ import annotations

import os
import re
import subprocess
from pathlib import Path
from typing import Optional, Tuple

from maestro.env import (
    artefact_root as _artefact_root_env,
    branch_guard_bypass as _bypass,
    sprint_branch as _sprint_branch,
)


# Git commands that mutate state and therefore care about branch identity.
# Read-only commands (status, log, diff, fetch, ls-files) are not gated.
#
# BUG-MSO-2026-0241: the regex must match ``git -C <path> commit`` (and other
# option-prefixed forms).  Without the optional ``(?:-C\s+\S+\s+)*`` group,
# ``git -C /main/repo commit`` was invisible to the guard — ``is_mutating``
# was False, so the command was allowed even though it targeted a different repo.
# Lead context: start of line, whitespace, a shell separator, OR an opening
# subshell/group paren (audit finding H11: `(git push …)` previously bypassed).
_LEAD = r"(?:^|\s|;|&&|\|\||\(|\|)"
# The binary may be invoked by an absolute/relative path (`/usr/bin/git`,
# `./git`) — audit finding H11: a path-prefixed binary previously bypassed.
_GIT_BIN = r"(?:[^\s;&|()]*/)?git"
_GH_BIN = r"(?:[^\s;&|()]*/)?gh"
# Generic git global options that may precede the subcommand verb:
# `-C <path>`, `-c key=val`, `--no-pager`, `--git-dir=…`, etc. Previously only
# `-C` was tolerated, so `git -c core.pager=cat push` and `git --no-pager push`
# slipped past the mutation detector entirely (audit finding H11).
_GIT_GLOBAL_OPT = r"(?:-[cC]\s+\S+\s+|--[\w-]+(?:=\S+)?\s+|-p\s+)"
_GIT_MUTATING = re.compile(
    _LEAD + r"\s*" + _GIT_BIN + r"\s+"
    + _GIT_GLOBAL_OPT + r"*"  # any number of global options
    + r"(commit|push|checkout|switch|merge|rebase|reset|tag|am|cherry-pick|"
    r"branch\s+(?:-D|-d|-m|--delete|--move))\b"
)

_GH_MUTATING = re.compile(
    _LEAD + r"\s*" + _GH_BIN + r"\s+"
    r"(pr\s+create|pr\s+merge|pr\s+close|release\s+create|api\s+graphql)\b"
)

# Audit finding H12: `gh api` REST calls with a mutating HTTP method (POST /
# PATCH / PUT / DELETE via `-X` / `--method`) perform server-side merges and
# ref updates (e.g. `gh api -X POST repos/{o}/{r}/merges -f base=main`) with no
# guard involvement. Treat them as mutating.
_GH_API_MUTATING = re.compile(
    _LEAD + r"\s*" + _GH_BIN + r"\s+api\b[^\n;]*?"
    r"(?:-X|--method)(?:\s+|=)(?:POST|PUT|PATCH|DELETE)\b",
    re.IGNORECASE,
)

# Redacts inline credentials before the command is echoed in a deny reason.
# - userinfo in URLs:  https://user:token@github.com/... → https://user:***@github.com/...
# - bare token-looking flags: --token=ghp_xxx              → --token=***
_CRED_USERINFO = re.compile(r"(https?://[^/\s:]+:)([^@\s]+)(@)")
_CRED_FLAG = re.compile(r"(--(?:token|password|api[-_]?key)[ =])(\S+)", re.IGNORECASE)


def _redact(command: str) -> str:
    redacted = _CRED_USERINFO.sub(r"\1***\3", command)
    redacted = _CRED_FLAG.sub(r"\1***", redacted)
    return redacted


def _current_branch(cwd: Optional[str] = None) -> str:
    """Return git current-branch name for *cwd* (defaults to process cwd), or '' on failure."""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True,
            text=True,
            timeout=5,
            cwd=cwd,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except Exception:
        pass
    return ""


def _git_toplevel(cwd: Optional[str] = None) -> Optional[Path]:
    """Resolved git worktree toplevel for *cwd* (defaults to process cwd), or None.

    FTR-MSO-2026-0368: used to distinguish the ARTEFACT repo from the product repo
    by cwd/toplevel resolution rather than fragile path-string matching."""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            capture_output=True, text=True, timeout=5, cwd=cwd or None,
        )
        if result.returncode == 0 and result.stdout.strip():
            return Path(result.stdout.strip()).resolve()
    except Exception:
        pass
    return None


def _artefact_repo_root() -> Optional[Path]:
    """The artefact repo ROOT (parent of the ``.mso`` dir in
    ``MAESTRO_ARTEFACT_ROOT``), or None when unset/unresolvable."""
    v = _artefact_root_env().strip()
    if not v:
        return None
    try:
        return Path(v).resolve().parent
    except Exception:
        return None


def _is_solo_mode() -> bool:
    """True when the resolved workspace is in solo/shared artefact mode.
    Fail-open to embedded (``False``) on any resolution error."""
    try:
        from maestro.workspace import get_artefact_mode
        return get_artefact_mode() in ("solo", "shared")
    except Exception:
        return False


def _default_branch(cwd: Optional[str]) -> str:
    """Resolve the default branch of the repo at *cwd* (the artefact repo).

    The durable plane is linear-history by design on this branch. Resolution:
    ``origin/HEAD`` symbolic-ref → local ``main``/``master`` → ``main``."""
    try:
        r = subprocess.run(
            ["git", "symbolic-ref", "--short", "refs/remotes/origin/HEAD"],
            capture_output=True, text=True, timeout=5, cwd=cwd or None,
        )
        if r.returncode == 0 and r.stdout.strip():
            return r.stdout.strip().rsplit("/", 1)[-1]
    except Exception:
        pass
    for cand in ("main", "master"):
        try:
            r = subprocess.run(
                ["git", "rev-parse", "--verify", f"refs/heads/{cand}"],
                capture_output=True, text=True, timeout=5, cwd=cwd or None,
            )
            if r.returncode == 0:
                return cand
        except Exception:
            pass
    return "main"


def _check_artefact_repo_branch(command: str, cwd: Optional[str]) -> Tuple[bool, str]:
    """Branch discipline for git/gh mutations targeting the ARTEFACT repo.

    The durable plane is linear-history by design: mutations are permitted only on
    the artefact repo's default branch. Raw ``gh api`` mutations remain refused
    (unverifiable), as in the product repo."""
    if _GH_API_MUTATING.search(command):
        return False, (
            "Branch guard: refusing raw `gh api` mutation "
            f"`{_redact(command).strip()[:80]}` in the artefact repo. Server-side "
            "REST mutations cannot be validated; use `git`/`gh pr` on the artefact "
            "repo's default branch, or set MAESTRO_BRANCH_GUARD_BYPASS=1 in the "
            "parent shell for manual-recovery sessions."
        )
    is_mutating = bool(_GIT_MUTATING.search(command) or _GH_MUTATING.search(command))
    if not is_mutating:
        return True, ""

    default = _default_branch(cwd)
    actual = _current_branch(cwd=cwd)
    if not actual:
        return False, (
            "Branch guard: could not resolve the artefact repo's current branch; "
            "refusing git/gh mutation. Set MAESTRO_BRANCH_GUARD_BYPASS=1 only if "
            "you intentionally need to act outside the default branch."
        )
    if actual != default:
        return False, (
            f"Branch guard: refusing `{_redact(command).strip()[:80]}` — the artefact "
            f"repo's durable plane is linear-history on its default branch "
            f"`{default}`, but the current branch is `{actual}`. Switch to "
            f"`{default}` before mutating the artefact repo."
        )
    # On the default branch — still block an explicit checkout/switch/push away.
    target_violation = _explicit_target_branch_violation(command, default)
    if target_violation:
        return False, target_violation
    return True, ""


def _extract_git_dash_c(command: str) -> Optional[str]:
    """Return the path argument of the first ``git -C <path>`` flag, or None.

    Handles both ``git -C path cmd`` and ``git -C "path with spaces" cmd``.
    BUG-MSO-2026-0241: used so the branch check runs at the *targeted* repo
    rather than the hook process's cwd, preventing ``git -C /main/repo commit``
    from bypassing the guard.
    """
    if not re.search(r"\bgit\b", command):
        return None
    # Scan for -C (space or start) followed by an optional quoted or unquoted path.
    m = re.search(r"(?:^|\s)-C\s+(['\"]?)(\S+)\1", command)
    if m:
        return m.group(2)
    return None


def check_branch(tool_name: str, command: str,
                 cwd: Optional[str] = None) -> Tuple[bool, str]:
    """
    Decide whether to allow a tool invocation under branch discipline.

    *cwd* is the tool call's effective working directory (the hook ``cwd``), used
    to resolve which repo the command targets in the split artefact/product
    topology (FTR-MSO-2026-0368).

    Returns:
        (allow, reason)
        allow=True  → operation permitted; reason is empty.
        allow=False → operation must be denied; reason is human-readable
                      and surfaces to the crew so it knows how to recover.
    """
    if _bypass():
        return True, ""

    if tool_name != "Bash":
        return True, ""

    # FTR-MSO-2026-0368: in solo/shared mode, a git/gh mutation whose git toplevel
    # is the ARTEFACT repo follows the artefact-repo rule (default branch only),
    # NOT the product-repo voyage-branch rule. Distinguished by toplevel
    # resolution (cwd truth), never by path-string matching. Product-repo ops
    # (toplevel != artefact root) fall through to the unchanged logic below.
    art_root = _artefact_repo_root()
    if art_root is not None and _is_solo_mode():
        dash_c_path = _extract_git_dash_c(command)
        effective_cwd = dash_c_path or cwd
        toplevel = _git_toplevel(effective_cwd)
        if toplevel is not None and toplevel == art_root:
            return _check_artefact_repo_branch(command, effective_cwd)

    # Audit finding H12: a raw `gh api` mutation (POST/PATCH/PUT/DELETE) can
    # perform a server-side merge or ref update that the branch guard cannot
    # inspect for a target branch. Rather than let it through, refuse it and
    # steer the crew to `git push` / `gh pr` on the voyage branch, which the
    # guard CAN validate.
    if _GH_API_MUTATING.search(command):
        return False, (
            "Branch guard: refusing raw `gh api` mutation "
            f"`{_redact(command).strip()[:80]}`. Server-side REST mutations "
            "(merges, ref updates) cannot be validated against the voyage "
            "branch. Use `git push` or `gh pr` on the voyage branch instead, "
            "or set MAESTRO_BRANCH_GUARD_BYPASS=1 in the parent shell for "
            "manual-recovery sessions."
        )

    is_mutating = bool(_GIT_MUTATING.search(command) or _GH_MUTATING.search(command))
    if not is_mutating:
        return True, ""

    expected = _sprint_branch().strip()
    if not expected:
        # BUG-ADM-2026-0009: refuse loose mutations. Without MAESTRO_SPRINT_BRANCH
        # in the crew environment the guard has no way to verify which branch
        # the mutation should land on, and silently allowing the operation
        # caused 3 commits to land on a stale branch in the PSG retest.
        # Copilot review on PR #58: this hook can only see the env var, not
        # the order JSON — so the deny reason describes what the guard
        # actually observed (env unset) rather than guessing at order state.
        return False, (
            "Branch guard: refusing "
            f"`{_redact(command).strip()[:80]}` — no MAESTRO_SPRINT_BRANCH "
            "in the crew environment, so this mutation has no verified "
            "target branch. The dispatcher injects this var from the order's "
            "resolved voyageBranch; if it's missing, the order likely has no "
            "voyageBranch (and no parent voyage.branch / no operator-set env "
            "var), or the dispatcher failed to export it. Either set "
            "voyageBranch on the order (or branch on its parent voyage), "
            "re-dispatch, or set MAESTRO_BRANCH_GUARD_BYPASS=1 in the "
            "parent shell for manual-recovery sessions."
        )

    # BUG-MSO-2026-0241: if the command targets a different repo via ``git -C <path>``,
    # check the branch at *that* path — not the hook's inherited cwd.  Without this,
    # ``git -C /main/repo commit`` bypassed the guard because _current_branch() saw the
    # worktree's voyage branch, not main's HEAD.
    dash_c_path = _extract_git_dash_c(command)
    actual = _current_branch(cwd=dash_c_path) if dash_c_path else _current_branch()
    if not actual:
        return False, (
            "Branch guard: could not resolve current branch; refusing "
            "git/gh mutation. Set MAESTRO_BRANCH_GUARD_BYPASS=1 only "
            "if you intentionally need to act outside a voyage branch."
        )

    if actual != expected:
        return False, (
            f"Branch guard: refusing `{_redact(command).strip()[:80]}` because "
            f"current branch is `{actual}` but this order's voyageBranch "
            f"is `{expected}`. Switch to `{expected}` before mutating "
            "git state."
        )

    # We're on the right branch — but the *target* of the mutation can still
    # name a different branch. Catch those explicit cross-branch targets.
    target_violation = _explicit_target_branch_violation(command, expected)
    if target_violation:
        return False, target_violation

    return True, ""


# Branch-name token: anything except whitespace and shell separators.
_BRANCH_TOK = r"[^\s;&|<>]+"


def _strip_quotes(value: str) -> str:
    if len(value) >= 2 and value[0] == value[-1] and value[0] in ('"', "'"):
        return value[1:-1]
    return value


def _explicit_target_branch_violation(command: str, expected: str) -> str:
    """If `command` names an explicit non-`expected` branch as its target,
    return a deny-reason; otherwise return ''.

    Caught patterns (any of):
      git checkout <branch>            (when branch != expected)
      git switch [-c|-C|--create] <branch>
      git push <remote> <branch>       (where <branch> is a non-flag refspec)
      git push <remote> HEAD:<branch>
      gh pr create --head <branch>     and --head=<branch>
      gh pr create --head "<branch>"   (quoted)
    """
    cmd = command.strip()

    # gh pr create — both space and equals forms; tolerate quotes.
    if re.search(r"(?:^|\s|;|&&|\|\|)\s*gh\s+pr\s+create\b", cmd):
        m = re.search(r"--head(?:\s+|=)([^\s;&|<>]+)", cmd)
        if m:
            head = _strip_quotes(m.group(1))
            if head and head != expected:
                return (
                    f"Branch guard: `gh pr create --head {head}` does not "
                    f"match the order's voyageBranch `{expected}`."
                )

    # git checkout <branch>  (skip flag-only checkouts like `git checkout -- file`)
    m = re.search(
        r"(?:^|\s|;|&&|\|\|)\s*git\s+checkout(?:\s+(?:-b|-B|--track))?\s+(" + _BRANCH_TOK + r")",
        cmd,
    )
    if m:
        target = _strip_quotes(m.group(1))
        # Ignore commit-ish sentinels and pathspec separators.
        if target and target not in ("--", "HEAD", expected) and not target.startswith("-"):
            return (
                f"Branch guard: `git checkout {target}` would leave the "
                f"voyage branch `{expected}`. Stay on `{expected}` for "
                "the duration of this order."
            )

    # git switch [-c|-C|--create] <branch>
    m = re.search(
        r"(?:^|\s|;|&&|\|\|)\s*git\s+switch(?:\s+(?:-c|-C|--create|--detach))?\s+(" + _BRANCH_TOK + r")",
        cmd,
    )
    if m:
        target = _strip_quotes(m.group(1))
        if target and target != expected and not target.startswith("-"):
            return (
                f"Branch guard: `git switch {target}` would leave the "
                f"voyage branch `{expected}`."
            )

    # git push <remote> <branch>  or  git push <remote> HEAD:<branch>
    # Skip the read-only / metadata flags.
    push = re.search(
        r"(?:^|\s|;|&&|\|\|)\s*git\s+push\s+(\S+)(?:\s+(\S+))?",
        cmd,
    )
    if push:
        remote = push.group(1)
        refspec = push.group(2) or ""
        # If the second token is a flag (e.g. --tags) or absent, no target branch is named.
        if refspec and not refspec.startswith("-") and not remote.startswith("-"):
            target = refspec.split(":")[-1]  # "HEAD:other" → "other"; "main" → "main"
            target = _strip_quotes(target)
            if target and target != expected and target != "HEAD":
                return (
                    f"Branch guard: `git push {remote} {refspec}` targets "
                    f"`{target}`, which is not the voyage branch "
                    f"`{expected}`."
                )

    return ""
