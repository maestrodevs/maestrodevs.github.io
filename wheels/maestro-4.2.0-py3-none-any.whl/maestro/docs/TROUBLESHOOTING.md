# Maestro — Troubleshooting

Common errors and how to resolve them.

---

## Contents

- [Installation and PATH issues](#installation-and-path-issues)
  - [E01 — `mso: command not found`](#e01--mso-command-not-found)
  - [E02 — `claude: command not found`](#e02--claude-command-not-found)
  - [E03 — Wrong Python version](#e03--wrong-python-version)
- [Authentication and Licence](#authentication-and-licence)
  - [E04 — Licence key activation failed](#e04--licence-key-activation-failed)
  - [E05 — `ANTHROPIC_API_KEY` missing or invalid](#e05--anthropic_api_key-missing-or-invalid)
  - [E06 — Trial expired — access blocked](#e06--trial-expired--access-blocked)
  - [E07 — Licence expired or grace period exceeded](#e07--licence-expired-or-grace-period-exceeded)
- [Dispatch and Order Problems](#dispatch-and-order-problems)
  - [E08 — No orders found — dispatch exits immediately](#e08--no-orders-found--dispatch-exits-immediately)
  - [E09 — Orders held: unsatisfied dependencies](#e09--orders-held-unsatisfied-dependencies)
  - [E10 — Crew launches but immediately stops](#e10--crew-launches-but-immediately-stops)
  - [E11 — Crew stuck: no progress for a long time](#e11--crew-stuck-no-progress-for-a-long-time)
  - [E12 — Crew crashes: CRASHED or FAILED status](#e12--crew-crashes-crashed-or-failed-status)
  - [E13 — Trial: `--max-crews` capped unexpectedly](#e13--trial---max-crews-capped-unexpectedly)
  - [E14 — Trial: single-project cap exceeded](#e14--trial-single-project-cap-exceeded)
- [State and Stale Locks](#state-and-stale-locks)
  - [E15 — Stale lock files from a previous run](#e15--stale-lock-files-from-a-previous-run)
  - [E16 — Dispatcher shows STOPPED but process is running](#e16--dispatcher-shows-stopped-but-process-is-running)
- [Git and Repo Problems](#git-and-repo-problems)
  - [E17 — Crew fails: cannot push branch](#e17--crew-fails-cannot-push-branch)
  - [E18 — `mso init` fails: `\.mso/` already exists](#e18--mso-init-fails-mso-already-exists)
- [Monitoring and Usage](#monitoring-and-usage)
  - [E19 — `mso usage` shows no data](#e19--mso-usage-shows-no-data)
  - [E20 — `mso status` shows no crews or blank dashboard](#e20--mso-status-shows-no-crews-or-blank-dashboard)

---

## Installation and PATH issues

### E01 — `mso: command not found`

**Cause:** pip installed the `maestro` entry point into a `bin` or `Scripts` directory that is not on your `PATH`.

**Fix:**

*Linux / macOS:*
```bash
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
source ~/.bashrc
```

*Windows (PowerShell):*

Add `%APPDATA%\Python\PythonXX\Scripts` to your user `PATH` via System > Advanced system settings > Environment Variables. Replace `XX` with your Python version (e.g. `311` for Python 3.11).

*Virtual environment:*

If you installed into a virtual environment, activate it first:
```bash
source .venv/bin/activate   # Linux/macOS
.venv\Scripts\activate      # Windows
mso version
```

**Verify the fix:**
```bash
which mso       # Linux/macOS
where mso       # Windows
mso version
```

---

### E02 — `claude: command not found`

**Cause:** Claude Code is not installed or not on your `PATH`.

**Fix:**

Install Claude Code from [claude.ai/code](https://claude.ai/code) and follow the installation guide for your platform. After installation, verify:

```bash
claude --version
```

If `claude` still is not found, check the Claude Code documentation for PATH setup on your platform. Common locations:
- macOS: `~/.claude/bin/` or a path added during install
- Windows: check the installer output for the installation path

Maestro crew sessions invoke `claude` as a subprocess — if `claude` is not on PATH, all crew dispatch will fail.

---

### E03 — Wrong Python version

**Cause:** Maestro requires Python 3.9 or later. Some systems have Python 2 as the default `python` command.

**Fix:**

Check your version:
```bash
python --version
python3 --version
```

If your system uses `python3`, install Maestro with:
```bash
python3 -m pip install maestro --extra-index-url https://maestrodevs.github.io/simple/
```

Or create a virtual environment with the correct Python:
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install maestro --extra-index-url https://maestrodevs.github.io/simple/
```

---

## Authentication and Licence

> **Note:** v2.5.0+ uses the Polar.sh-backed licence-key system (`mso licence activate <KEY>`). The legacy GitHub-collaborator PAT path is retained as a transitional fallback only — see [docs/LICENCE.md](LICENCE.md) for the full activation flow, offline grace, and tamper-recovery paths.

### E04 — Licence key activation failed

**Symptom:**
```
Activation refused: <reason from Polar>
```
or
```
Couldn't reach the licence backend: <network error>
Activation requires online verification — try again with a live network.
```

**Cause:** The key string was entered incorrectly, the subscription was cancelled or expired, or the network couldn't reach `api.polar.sh` for verification.

**Fix:**

1. Copy the key exactly as Polar issued it — keys are case-sensitive and look like `adm_lic_<KEY>` (the key body is what Polar issues; treat the whole string as opaque).
2. Ensure there are no leading or trailing spaces.
3. Quote the key on the command line:
   ```bash
   mso licence activate "adm_lic_<KEY>"
   ```
4. Confirm your subscription is still active in the [Polar customer portal](https://polar.sh/maestro).
5. If activation fails with a network error, check that `api.polar.sh` is reachable (curl it). Activation requires the internet — there is no offline activation flow.
6. For ongoing offline operation after the first successful activation, see the 14-day grace window described in [docs/LICENCE.md](LICENCE.md).

If the key was recently issued and activation still fails, contact [maestro@tech127.com](mailto:maestro@tech127.com) with the exact error message.

---

### E05 — `ANTHROPIC_API_KEY` missing or invalid

**Symptom:** Crews start but immediately fail, or the dispatcher exits with an API authentication error.

**Cause:** The `ANTHROPIC_API_KEY` environment variable is not set, is set to a placeholder value, or the key does not have access to the required Claude models (Sonnet 4.6, Haiku 4.5, Opus 4.7).

**Fix:**

1. Verify the variable is set:
   ```bash
   echo $ANTHROPIC_API_KEY   # Linux/macOS
   echo %ANTHROPIC_API_KEY%  # Windows cmd
   ```
2. If blank, set it:
   ```bash
   export ANTHROPIC_API_KEY=sk-ant-api03-...
   ```
3. Add to your shell profile to persist across sessions:
   ```bash
   echo 'export ANTHROPIC_API_KEY=sk-ant-api03-...' >> ~/.bashrc
   source ~/.bashrc
   ```
4. Verify the key has model access in your [Anthropic Console](https://console.anthropic.com).

---

### E06 — Trial expired — access blocked

**Symptom:**
```
[Maestro Trial] Your 14-day trial has expired.
Only 'mso version' and 'mso licence' are available.
To continue: https://maestroai.com/pricing
```

**Cause:** The 14-day trial period has elapsed.

**Fix:**

Activate a licence key to resume all commands:
```bash
mso licence activate <YOUR-KEY>
```

If you do not have a key yet, see [PRICING.md](PRICING.md) for options. The `mso licence` and `mso version` commands remain available without a key.

---

### E07 — Licence expired or grace period exceeded

**Symptom:**
```
[Maestro] Licence expired: ADM-TEAM-... expired on 2026-12-31.
Renew at: https://maestroai.com/pricing
```

**Cause:** The licence key's expiry date has passed and the 30-day offline grace period has also elapsed.

**Fix:**

1. Obtain a renewed licence key from your account or contact [maestro@tech127.com](mailto:maestro@tech127.com)
2. Activate the new key:
   ```bash
   mso licence deactivate
   mso licence activate <NEW-KEY>
   ```

If you are within the 30-day grace period (last network validation was within 30 days), commands continue to work. The `mso licence status` output shows the days remaining in the grace period.

---

## Dispatch and Order Problems

### E08 — No orders found — dispatch exits immediately

**Symptom:** `mso dispatch` starts and immediately exits with:
```
[Maestro] No dispatchable orders found. Exiting.
```

**Cause:** One or more of the following:
- Queue directories are empty
- All queued orders have unsatisfied `dependsOn` dependencies
- Order files are not valid JSON or are in the wrong directory

**Fix:**

1. Verify the order file is in the correct queue directory:
   ```bash
   ls .maestro/queues/orders/
   ```
   Order files must be directly in the queue directory — not in a subdirectory.

2. Validate the order JSON:
   ```bash
   python -c "import json; json.load(open('.maestro/queues/orders/YOUR-ORDER-ID.json'))"
   ```

3. Check `dependsOn` — if an order lists an incomplete order as a dependency, it will not dispatch:
   ```bash
   cat .maestro/queues/orders/YOUR-ORDER-ID.json | python -c "import json,sys; print(json.load(sys.stdin).get('dependsOn'))"
   ```
   Check whether the listed dependency is in `.maestro/orders/complete/`.

4. Check all queue tiers, not just `queues/orders/`:
   ```bash
   ls .maestro/queues/bugs/
   ls .maestro/queues/requests/
   ```

---

### E09 — Orders held: unsatisfied dependencies

**Symptom:** The `QUEUES` panel in `mso status` shows orders pending, but dispatch does not pick them up. The lifecycle log may show `HELD: dependency not met`.

**Cause:** The order's `dependsOn` array references one or more orders that are not yet in `orders/complete/`.

**Fix:**

1. Identify which dependency is missing:
   ```bash
   cat .maestro/queues/orders/YOUR-ORDER-ID.json
   ```
   Check the `dependsOn` list.

2. Verify the dependency status:
   ```bash
   ls .maestro/orders/complete/   # should contain the dependency
   ls .maestro/orders/active/     # still in progress
   ls .maestro/orders/failed/     # failed — need to retry or remove dependency
   ```

3. If the dependency is in `failed/`, either fix and re-queue it or remove the dependency from the dependent order and re-queue.

---

### E10 — Crew launches but immediately stops

**Symptom:** A crew appears briefly in `mso status` then transitions to IDLE or FAILED within seconds.

**Cause:** Most commonly:
- `ANTHROPIC_API_KEY` not set (see [E05](#e05--anthropic_api_key-missing-or-invalid))
- `claude` not on PATH (see [E02](#e02--claude-command-not-found))
- Invalid or malformed order prompt
- Permission denied writing to crew directory

**Fix:**

1. Check the crew's state file:
   ```bash
   cat .maestro/crews/crew1/state.json
   ```
2. Check the crew's activity log:
   ```bash
   cat .maestro/crews/crew1/activity.txt
   ```
3. Check for errors in the crew's progress file:
   ```bash
   cat .maestro/crews/crew1/progress.md
   ```
4. Verify API key and Claude Code install as described in E05 and E02.

---

### E11 — Crew stuck: no progress for a long time

**Symptom:** A crew shows RUNNING status but the activity timestamp has not updated for 30+ minutes.

**Cause:** The crew may be:
- Waiting for a long API response
- In a loop retrying a failing action
- Blocked on a decision and unable to escalate

**Fix:**

1. Check recent activity:
   ```bash
   cat .maestro/crews/crew1/activity.txt
   ```
2. Check for escalations raised by the crew:
   ```bash
   ls .maestro/queues/escalations/
   ```
   If there is a blocking escalation, review and resolve it (see [OWNER-GUIDE.md](OWNER-GUIDE.md#75-captain-review-workflow-awaiting_approval)).
3. If the crew has genuinely stalled, stop and re-dispatch:
   ```bash
   mso crew --crew 1 --cleanup
   mso dispatch --max-crews 1
   ```

---

### E12 — Crew crashes: CRASHED or FAILED status

**Symptom:** `mso status` shows a crew in CRASHED or FAILED state.

**Cause:** The crew exceeded the maximum iteration count, hit an unrecoverable error, or the `claude` process exited unexpectedly.

**Fix:**

1. Check the ralph-state file for the final iteration count:
   ```bash
   cat .maestro/crews/crew1/ralph-state.md
   ```
2. Check the order's completion metadata:
   ```bash
   cat .maestro/orders/failed/YOUR-ORDER-ID.json
   ```
3. Review the progress file for the last known action:
   ```bash
   cat .maestro/crews/crew1/progress.md
   ```
4. Clean up and retry:
   ```bash
   mso cleanup
   # Move the order back to the queue if needed
   mv .maestro/orders/failed/YOUR-ORDER-ID.json .maestro/queues/orders/
   mso dispatch --max-crews 3
   ```

---

### E13 — Trial: `--max-crews` capped unexpectedly

**Symptom:**
```
[Maestro] Trial mode allows 3 max crews. Capping --max-crews from 5 to 3.
```

**Cause:** You are in trial mode and requested more crews than the trial limit (3).

**Fix:**

This is expected behaviour — not an error. Trial mode limits dispatch to 3 concurrent crews.

To remove this limit, activate a Team or Enterprise licence:
```bash
mso licence activate <YOUR-KEY>
```

Then re-dispatch with the desired crew count:
```bash
mso dispatch --max-crews 5
```

---

### E14 — Trial: single-project cap exceeded

**Symptom:**
```
[Maestro Trial] Single-project limit exceeded.
  Your workspace has 3 projects configured.
  Trial mode supports 1 project only.

  To unlock unlimited projects: https://maestroai.com/pricing
```

**Cause:** Your workspace `projects.json` contains more than 1 project and you are in trial mode.

**Fix:**

Either remove the extra projects from `projects.json` to stay within trial limits, or activate a paid licence key:
```bash
mso licence activate <YOUR-KEY>
```

Solo tier allows up to 3 projects; Team and Enterprise allow unlimited.

---

## State and Stale Locks

### E15 — Stale lock files from a previous run

**Symptom:** `mso status` shows crews as RUNNING but no actual crew processes are active, or `mso dispatch` skips slots that appear occupied.

**Cause:** A previous dispatcher run terminated without cleaning up `crew.lock` and `pid.txt` files.

**Fix:**

```bash
mso cleanup
```

This stops any orphaned processes and resets stale lock and state files. Safe to run at any time — does not affect orders that are genuinely in progress.

After cleanup:
```bash
mso dispatch --max-crews 5
```

---

### E16 — Dispatcher shows STOPPED but process is running

**Symptom:** `mso status` shows `DISPATCHER: STOPPED` but you know dispatch is running.

**Cause:** The dispatcher PID file is missing, stale, or the fleet monitor cannot read the dispatcher state file.

**Fix:**

1. Check whether the dispatcher process is actually running:
   ```bash
   ps aux | grep fleet-runner   # Linux/macOS
   tasklist | findstr fleet-runner   # Windows
   ```
2. If the process is running but the dashboard shows STOPPED, there may be a PID file issue. Run cleanup and re-dispatch:
   ```bash
   mso cleanup
   mso dispatch --max-crews 5
   ```

---

## Git and Repo Problems

### E17 — Crew fails: cannot push branch

**Symptom:** A crew's final step fails with a Git push error, or the order completes but no branch appears in the remote.

**Cause:** One or more of the following:
- The Maestro host does not have push permissions for the target repository
- SSH key or HTTPS credentials not configured
- The voyage branch already exists with conflicting history

**Fix:**

1. Verify push access from the Maestro host:
   ```bash
   git push origin HEAD --dry-run
   ```
2. For HTTPS remotes, ensure a credential helper is configured:
   ```bash
   git config --global credential.helper store
   ```
3. For SSH remotes, verify the SSH key is added to your Git host and the key is loaded:
   ```bash
   ssh -T git@github.com
   ```
4. If the voyage branch has a conflict, delete it from the remote and re-dispatch:
   ```bash
   git push origin --delete voyage/YOUR-VOYAGE-BRANCH
   ```

---

### E18 — `mso init` fails: `\.maestro/` already exists

**Symptom:**
```
[Maestro] .maestro/ already exists. Use --force to overwrite.
```

**Cause:** The workspace was already initialised.

**Fix:**

If you want to re-scaffold the workspace (this will overwrite existing config):
```bash
mso init --project MYPROJ --force
```

If you just need to add a new project to an existing workspace, edit `.maestro/config/projects.json` and `.maestro/config/projects/NEWPROJ.json` directly rather than re-running init.

---

## Monitoring and Usage

### E19 — `mso usage` shows no data

**Symptom:** `mso usage --summary` returns `No usage data found` or shows zero tokens and zero cost.

**Cause:** Usage data is captured by the stop hook at the end of each crew session. If the hook did not run (e.g. the crew was interrupted, or the hook script is missing), usage files will not exist.

**Fix:**

1. Check whether usage files were created for completed orders:
   ```bash
   ls .maestro/usage/orders/
   ```
2. Verify the stop hook is present and executable:
   ```bash
   ls .maestro/hooks/fleet-stop-hook.py
   ```
3. Ensure `MAESTRO_CREW` is set when dispatching — the stop hook only captures usage when this variable is set. This is injected automatically by the dispatcher.
4. If usage files are absent for a completed order, the session may have been terminated before the hook fired. No usage data is available for those orders — this is expected for interrupted sessions.

---

### E20 — `mso status` shows no crews or blank dashboard

**Symptom:** `mso status --once` shows an empty dashboard with no crew slots, or exits immediately.

**Cause:** One or more of the following:
- The crew directories do not exist (workspace not initialised)
- `mso status` is being run from the wrong directory
- The fleet monitor script is missing

**Fix:**

1. Ensure you are in the workspace root (where `\.maestro/` is a direct subdirectory):
   ```bash
   ls .maestro/
   ```
2. Verify crew directories exist:
   ```bash
   ls .maestro/crews/
   ```
   If not present, re-run `mso init --project <ACRONYM>`.
3. Verify the fleet monitor is present:
   ```bash
   ls .maestro/core/fleet_monitor.py
   ```
   If missing, re-install or update Maestro:
   ```bash
   pip install --upgrade git+https://github.com/tavisbasing/Maestro.git@main
   ```

---

*Maestro Maestro v2.5.0 — If your issue is not listed here, see [SUPPORT.md](SUPPORT.md) for how to get help.*
