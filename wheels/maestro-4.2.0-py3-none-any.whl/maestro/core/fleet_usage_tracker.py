#!/usr/bin/env python3
# Maestro - Usage Tracker
"""
Maestro - Usage Tracker

Tracks token usage across fleet crew sessions and QM-Captain interactions.
Parses Claude Code transcript JSONL files to extract actual API usage data
(input_tokens, output_tokens, cache_creation, cache_read) per model.

Usage:
    python -m maestro.core.fleet_usage_tracker --crew 1          # Show crew 1 usage
    python -m maestro.core.fleet_usage_tracker --order FTR-OTM-2026-0001  # Show order usage
    python -m maestro.core.fleet_usage_tracker --voyage VOY-OTM-2026-0100 # Aggregate voyage
    python -m maestro.core.fleet_usage_tracker --summary          # Grand totals
    python -m maestro.core.fleet_usage_tracker --report           # Generate usage report

Features:
  - Parse transcript JSONL for actual token usage (input, output, cache_creation, cache_read)
  - Per-order usage tracking stored in .mso/usage/orders/{ORDER-ID}.json
  - Per-crew session tracking stored in .mso/usage/crews/crew{N}.json
  - Voyage-level aggregation
  - Cost estimation using current API pricing
  - Integration with stop hook for automatic capture at session end
  - Dynamic version resolution from maestro package
"""

import json
import os
import re
import sys
import glob
import argparse
from datetime import datetime
from pathlib import Path
from collections import defaultdict

# ============================================================================
# CONFIGURATION
# ============================================================================

# API pricing per million tokens (as of 2026-04)
# Historical model IDs are retained so cost calculations on old transcripts still resolve.
PRICING = {
    "claude-opus-4-7": {
        "input": 15.00,
        "output": 75.00,
        "cache_creation": 18.75,
        "cache_read": 1.50,
    },
    "claude-opus-4-6": {
        "input": 15.00,
        "output": 75.00,
        "cache_creation": 18.75,
        "cache_read": 1.50,
    },
    "claude-sonnet-4-6": {
        "input": 3.00,
        "output": 15.00,
        "cache_creation": 3.75,
        "cache_read": 0.30,
    },
    "claude-haiku-4-5-20251001": {
        "input": 0.80,
        "output": 4.00,
        "cache_creation": 1.00,
        "cache_read": 0.08,
    },
}

# Model display names
MODEL_NAMES = {
    "claude-opus-4-7": "Opus 4.7",
    "claude-opus-4-6": "Opus 4.6",
    "claude-sonnet-4-6": "Sonnet 4.6",
    "claude-haiku-4-5-20251001": "Haiku 4.5",
}

SCRIPT_DIR = Path(os.path.dirname(os.path.abspath(__file__)))
MAESTRO_DIR = SCRIPT_DIR.parent
USAGE_DIR = MAESTRO_DIR / "usage"


def resolve_version() -> str:
    """Resolve the package version from the installed maestro package or __init__.py."""
    try:
        import maestro
        return maestro.__version__
    except ImportError:
        pass

    script_path = Path(__file__).resolve()
    for candidate in [
        script_path.parent.parent.parent / "maestro" / "__init__.py",
        script_path.parent.parent / "maestro" / "__init__.py",
    ]:
        if candidate.exists():
            try:
                content = candidate.read_text(encoding="utf-8")
                m = re.search(r'^__version__\s*=\s*["\']([^"\']+)["\']', content, re.MULTILINE)
                if m:
                    return m.group(1)
            except Exception:
                pass

    return "unknown"


def ensure_usage_dirs():
    """Create usage tracking directories if they don't exist."""
    (USAGE_DIR / "orders").mkdir(parents=True, exist_ok=True)
    (USAGE_DIR / "crews").mkdir(parents=True, exist_ok=True)
    (USAGE_DIR / "voyages").mkdir(parents=True, exist_ok=True)
    (USAGE_DIR / "sessions").mkdir(parents=True, exist_ok=True)


def parse_transcript(transcript_path: str) -> dict:
    """
    Parse a Claude Code transcript JSONL file and extract token usage.

    Returns:
        {
            "session_id": str,
            "start_time": str (ISO),
            "end_time": str (ISO),
            "message_count": int,
            "models": {
                "claude-opus-4-7": {
                    "input_tokens": int,
                    "output_tokens": int,
                    "cache_creation_input_tokens": int,
                    "cache_read_input_tokens": int,
                    "message_count": int,
                },
                ...
            },
            "total_tokens": int,
            "estimated_cost_usd": float,
        }
    """
    result = {
        "session_id": "",
        "start_time": None,
        "end_time": None,
        "message_count": 0,
        "models": {},
        "total_tokens": 0,
        "estimated_cost_usd": 0.0,
    }

    if not os.path.exists(transcript_path):
        return result

    first_ts = None
    last_ts = None
    models = defaultdict(lambda: {
        "input_tokens": 0,
        "output_tokens": 0,
        "cache_creation_input_tokens": 0,
        "cache_read_input_tokens": 0,
        "message_count": 0,
    })

    try:
        with open(transcript_path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    entry = json.loads(line)
                except json.JSONDecodeError:
                    continue

                ts = entry.get("timestamp")
                if ts and not first_ts:
                    first_ts = ts
                if ts:
                    last_ts = ts

                session_id = entry.get("sessionId", "")
                if session_id and not result["session_id"]:
                    result["session_id"] = session_id

                if entry.get("type") == "assistant":
                    msg = entry.get("message", {})
                    if not isinstance(msg, dict):
                        continue

                    usage = msg.get("usage", {})
                    model = msg.get("model", "unknown")

                    # Skip synthetic/unknown models
                    if model in ("<synthetic>", "unknown", ""):
                        continue

                    result["message_count"] += 1
                    models[model]["message_count"] += 1

                    for key in [
                        "input_tokens",
                        "output_tokens",
                        "cache_creation_input_tokens",
                        "cache_read_input_tokens",
                    ]:
                        models[model][key] += usage.get(key, 0)

    except Exception as e:
        print(f"Error parsing transcript: {e}", file=sys.stderr)
        return result

    result["start_time"] = first_ts
    result["end_time"] = last_ts
    result["models"] = dict(models)

    # Calculate totals and cost
    total_tokens = 0
    total_cost = 0.0
    for model, usage in models.items():
        model_total = sum(usage[k] for k in [
            "input_tokens", "output_tokens",
            "cache_creation_input_tokens", "cache_read_input_tokens",
        ])
        total_tokens += model_total

        pricing = PRICING.get(model, PRICING.get("claude-sonnet-4-6", {}))
        cost = (
            usage["input_tokens"] * pricing.get("input", 0)
            + usage["output_tokens"] * pricing.get("output", 0)
            + usage["cache_creation_input_tokens"] * pricing.get("cache_creation", 0)
            + usage["cache_read_input_tokens"] * pricing.get("cache_read", 0)
        ) / 1_000_000
        total_cost += cost

    result["total_tokens"] = total_tokens
    result["estimated_cost_usd"] = round(total_cost, 4)

    return result


def save_order_usage(order_id: str, usage_data: dict):
    """Save usage data for a specific order."""
    ensure_usage_dirs()
    path = USAGE_DIR / "orders" / f"{order_id}.json"

    record = {
        "orderId": order_id,
        "timestamp": datetime.now().isoformat(),
        **usage_data,
    }

    with open(path, "w", encoding="utf-8") as f:
        json.dump(record, f, indent=2)


def record_review_time(order_id: str, review_pending_at: str, approved_at: str) -> int:
    """Calculate and persist review time for an order.

    Reads the existing usage file (or creates a minimal one), writes
    reviewTimeSeconds, and returns the elapsed seconds.
    """
    ensure_usage_dirs()
    try:
        pending_dt = datetime.fromisoformat(review_pending_at.replace("Z", "+00:00")).replace(tzinfo=None)
        approved_dt = datetime.fromisoformat(approved_at.replace("Z", "+00:00")).replace(tzinfo=None)
        elapsed = int((approved_dt - pending_dt).total_seconds())
    except Exception:
        elapsed = 0

    path = USAGE_DIR / "orders" / f"{order_id}.json"
    if path.exists():
        try:
            with open(path, encoding="utf-8") as f:
                record = json.load(f)
        except Exception:
            record = {"orderId": order_id}
    else:
        record = {"orderId": order_id, "timestamp": datetime.now().isoformat()}

    record["reviewTimeSeconds"] = elapsed

    with open(path, "w", encoding="utf-8") as f:
        json.dump(record, f, indent=2)

    return elapsed


def save_crew_usage(crew_number: int, order_id: str, usage_data: dict):
    """Append usage data for a crew session."""
    ensure_usage_dirs()
    path = USAGE_DIR / "crews" / f"crew{crew_number}.jsonl"

    record = {
        "crewNumber": crew_number,
        "orderId": order_id,
        "timestamp": datetime.now().isoformat(),
        **usage_data,
    }

    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(record) + "\n")


def save_session_usage(session_id: str, usage_data: dict, session_type: str = "crew"):
    """Save usage data for any session (crew or QM)."""
    ensure_usage_dirs()
    path = USAGE_DIR / "sessions" / f"{session_id}.json"

    record = {
        "sessionId": session_id,
        "sessionType": session_type,
        "timestamp": datetime.now().isoformat(),
        **usage_data,
    }

    with open(path, "w", encoding="utf-8") as f:
        json.dump(record, f, indent=2)


def aggregate_voyage_usage(voyage_id: str) -> dict:
    """Aggregate usage across all orders in a voyage."""
    orders_dir = USAGE_DIR / "orders"
    if not orders_dir.exists():
        return {"voyage_id": voyage_id, "orders": [], "total_tokens": 0, "estimated_cost_usd": 0}

    # Load all order usage files and match voyage
    voyage_orders = []
    total_tokens = 0
    total_cost = 0.0
    total_review_seconds = 0
    review_order_count = 0
    models_agg = defaultdict(lambda: {
        "input_tokens": 0, "output_tokens": 0,
        "cache_creation_input_tokens": 0, "cache_read_input_tokens": 0,
        "message_count": 0,
    })

    for fpath in orders_dir.glob("*.json"):
        try:
            with open(fpath, encoding="utf-8") as f:
                data = json.load(f)
            voyage_orders.append(data)
            total_tokens += data.get("total_tokens", 0)
            total_cost += data.get("estimated_cost_usd", 0)
            if "reviewTimeSeconds" in data:
                total_review_seconds += data["reviewTimeSeconds"]
                review_order_count += 1

            for model, usage in data.get("models", {}).items():
                for key in models_agg[model]:
                    models_agg[model][key] += usage.get(key, 0)
        except Exception:
            continue

    return {
        "voyage_id": voyage_id,
        "order_count": len(voyage_orders),
        "models": dict(models_agg),
        "total_tokens": total_tokens,
        "estimated_cost_usd": round(total_cost, 4),
        "reviewTimeSeconds": total_review_seconds,
        "reviewOrderCount": review_order_count,
    }


def scan_all_project_sessions(project_path: str = None) -> list:
    """
    Scan all Claude Code transcript files for a project directory
    and return usage summaries.
    """
    if not project_path:
        # Auto-detect from ~/.claude/projects/
        home = Path.home()
        projects_dir = home / ".claude" / "projects"

        # Prefer an explicit MAESTRO_PROJECT identifier when available.
        admiralty_project = os.environ.get("MAESTRO_PROJECT")
        if admiralty_project:
            pattern = f"*{admiralty_project}*"
            candidates = list(projects_dir.glob(pattern))
        else:
            # Backwards-compatible default: prefer project dirs that match OTM
            candidates = list(projects_dir.glob("*OTM*"))

        # Fallback: any project directory if no preferred candidates were found
        if not candidates:
            candidates = list(projects_dir.glob("*"))

        if not candidates:
            return []

        if len(candidates) > 1:
            raise RuntimeError(
                f"Multiple Claude project directories found matching "
                f"'{admiralty_project or '*OTM*'}' in {projects_dir}. "
                "Please specify --project-path explicitly or set MAESTRO_PROJECT."
            )
        project_path = str(candidates[0])

    sessions = []
    for fpath in sorted(glob.glob(os.path.join(project_path, "*.jsonl"))):
        usage = parse_transcript(fpath)
        if usage["message_count"] > 0:
            usage["transcript_path"] = fpath
            sessions.append(usage)

    return sessions


def calculate_cost(model: str, usage: dict) -> float:
    """Calculate cost in USD for a given model and usage dict."""
    pricing = PRICING.get(model, PRICING.get("claude-sonnet-4-6", {}))
    return (
        usage.get("input_tokens", 0) * pricing.get("input", 0)
        + usage.get("output_tokens", 0) * pricing.get("output", 0)
        + usage.get("cache_creation_input_tokens", 0) * pricing.get("cache_creation", 0)
        + usage.get("cache_read_input_tokens", 0) * pricing.get("cache_read", 0)
    ) / 1_000_000


def format_tokens(n: int) -> str:
    """Format token count with K/M suffix."""
    if n >= 1_000_000:
        return f"{n / 1_000_000:.1f}M"
    elif n >= 1_000:
        return f"{n / 1_000:.1f}K"
    return str(n)


def _aggregate_review_time() -> tuple:
    """Sum reviewTimeSeconds across all order usage files. Returns (seconds, order_count)."""
    orders_dir = USAGE_DIR / "orders"
    if not orders_dir.exists():
        return 0, 0
    total_secs = 0
    count = 0
    for fpath in orders_dir.glob("*.json"):
        try:
            with open(fpath, encoding="utf-8") as f:
                data = json.load(f)
            if "reviewTimeSeconds" in data:
                total_secs += data["reviewTimeSeconds"]
                count += 1
        except Exception:
            continue
    return total_secs, count


def print_summary(sessions: list):
    """Print a formatted summary of all sessions."""
    grand_models = defaultdict(lambda: {
        "input_tokens": 0, "output_tokens": 0,
        "cache_creation_input_tokens": 0, "cache_read_input_tokens": 0,
        "message_count": 0,
    })
    grand_total_tokens = 0
    grand_total_cost = 0.0
    total_messages = 0

    for s in sessions:
        total_messages += s.get("message_count", 0)
        grand_total_tokens += s.get("total_tokens", 0)
        grand_total_cost += s.get("estimated_cost_usd", 0)
        for model, usage in s.get("models", {}).items():
            for key in grand_models[model]:
                grand_models[model][key] += usage.get(key, 0)

    review_secs, review_count = _aggregate_review_time()

    print("=" * 72)
    print("FLEET COMMAND — TOKEN USAGE SUMMARY")
    print("=" * 72)
    print(f"  Sessions:    {len(sessions)}")
    print(f"  Messages:    {total_messages:,}")
    print(f"  Tokens:      {format_tokens(grand_total_tokens)}")
    print(f"  Est. Cost:   ${grand_total_cost:,.2f}")
    if review_count > 0:
        review_mins = round(review_secs / 60, 1)
        print(f"  Operator review:  {review_mins} minutes across {review_count} order{'s' if review_count != 1 else ''}")
    print()

    print("BY MODEL:")
    print("-" * 72)
    print(f"  {'Model':<30} {'Input':>10} {'Output':>10} {'Cache':>12} {'Cost':>10}")
    print("-" * 72)

    for model in sorted(grand_models.keys()):
        if model in ("<synthetic>", "unknown"):
            continue
        u = grand_models[model]
        display = MODEL_NAMES.get(model, model)
        inp = u["input_tokens"]
        out = u["output_tokens"]
        cache = u["cache_creation_input_tokens"] + u["cache_read_input_tokens"]
        cost = calculate_cost(model, u)
        print(f"  {display:<30} {format_tokens(inp):>10} {format_tokens(out):>10} {format_tokens(cache):>12} ${cost:>9,.2f}")

    print("-" * 72)
    print(f"  {'TOTAL':<30} {'':>10} {'':>10} {'':>12} ${grand_total_cost:>9,.2f}")
    print()


def generate_usage_report(sessions: list, output_path: str = None):
    """Generate a markdown usage report."""
    grand_models = defaultdict(lambda: {
        "input_tokens": 0, "output_tokens": 0,
        "cache_creation_input_tokens": 0, "cache_read_input_tokens": 0,
        "message_count": 0,
    })
    grand_total_tokens = 0
    grand_total_cost = 0.0
    total_messages = 0

    for s in sessions:
        total_messages += s.get("message_count", 0)
        grand_total_tokens += s.get("total_tokens", 0)
        grand_total_cost += s.get("estimated_cost_usd", 0)
        for model, usage in s.get("models", {}).items():
            for key in grand_models[model]:
                grand_models[model][key] += usage.get(key, 0)

    now = datetime.now().strftime("%Y-%m-%d %H:%M")

    lines = [
        f"# Maestro — Token Usage Report",
        f"",
        f"**Generated:** {now}",
        f"**Sessions:** {len(sessions)}",
        f"**Total Messages:** {total_messages:,}",
        f"**Total Tokens:** {format_tokens(grand_total_tokens)}",
        f"**Estimated Cost:** ${grand_total_cost:,.2f}",
        f"",
        f"---",
        f"",
        f"## Usage by Model",
        f"",
        f"| Model | Input | Output | Cache Create | Cache Read | Total | Cost |",
        f"|-------|-------|--------|-------------|------------|-------|------|",
    ]

    for model in sorted(grand_models.keys()):
        if model in ("<synthetic>", "unknown"):
            continue
        u = grand_models[model]
        display = MODEL_NAMES.get(model, model)
        inp = u["input_tokens"]
        out = u["output_tokens"]
        cc = u["cache_creation_input_tokens"]
        cr = u["cache_read_input_tokens"]
        total = inp + out + cc + cr
        cost = calculate_cost(model, u)
        lines.append(
            f"| {display} | {format_tokens(inp)} | {format_tokens(out)} | "
            f"{format_tokens(cc)} | {format_tokens(cr)} | {format_tokens(total)} | ${cost:,.2f} |"
        )

    lines.append(f"| **Total** | | | | | **{format_tokens(grand_total_tokens)}** | **${grand_total_cost:,.2f}** |")
    lines.append("")

    # Per-session breakdown
    lines.extend([
        "---",
        "",
        "## Per-Session Breakdown",
        "",
        "| # | Date | Messages | Tokens | Model | Cost |",
        "|---|------|----------|--------|-------|------|",
    ])

    for i, s in enumerate(sessions, 1):
        date = s.get("start_time", "?")[:16] if s.get("start_time") else "?"
        msgs = s.get("message_count", 0)
        tokens = s.get("total_tokens", 0)
        cost = s.get("estimated_cost_usd", 0)
        primary_model = max(s.get("models", {}).items(), key=lambda x: sum(x[1].values()))[0] if s.get("models") else "?"
        display_model = MODEL_NAMES.get(primary_model, primary_model)
        lines.append(f"| {i} | {date} | {msgs} | {format_tokens(tokens)} | {display_model} | ${cost:,.2f} |")

    lines.append("")

    report = "\n".join(lines)

    if output_path:
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(report)
        print(f"Report written: {output_path}")
    else:
        print(report)


def main():
    parser = argparse.ArgumentParser(
        description=f"Maestro - Usage Tracker v{resolve_version()}"
    )
    parser.add_argument("--crew", type=int, help="Show usage for a specific crew")
    parser.add_argument("--order", type=str, help="Show usage for a specific order")
    parser.add_argument("--voyage", type=str, help="Aggregate usage for a voyage")
    parser.add_argument("--summary", action="store_true", help="Show grand total summary")
    parser.add_argument("--report", action="store_true", help="Generate markdown report")
    parser.add_argument("--output", type=str, help="Output path for report")
    parser.add_argument("--transcript", type=str, help="Parse a single transcript file")

    args = parser.parse_args()

    if args.transcript:
        usage = parse_transcript(args.transcript)
        print(json.dumps(usage, indent=2))
        return

    if args.order:
        usage_file = USAGE_DIR / "orders" / f"{args.order}.json"
        if usage_file.exists():
            with open(usage_file) as f:
                print(json.dumps(json.load(f), indent=2))
        else:
            print(f"No usage data for order {args.order}")
        return

    if args.voyage:
        agg = aggregate_voyage_usage(args.voyage)
        total_cost = agg.get("estimated_cost_usd", 0)
        review_secs = agg.get("reviewTimeSeconds", 0)
        review_count = agg.get("reviewOrderCount", 0)
        print("=" * 72)
        print(f"VOYAGE USAGE — {agg['voyage_id']}")
        print("=" * 72)
        print(f"  Orders:      {agg.get('order_count', 0)}")
        print(f"  Tokens:      {format_tokens(agg.get('total_tokens', 0))}")
        print(f"  Token cost:  ${total_cost:,.2f}")
        if review_count > 0:
            review_mins = round(review_secs / 60, 1)
            print(f"  Operator review:  {review_mins} minutes across {review_count} order{'s' if review_count != 1 else ''}")
        return

    # Default: scan all project sessions
    sessions = scan_all_project_sessions()

    if args.report:
        output = args.output or str(MAESTRO_DIR / "reports" / "usage" / f"usage-report-{datetime.now().strftime('%Y-%m-%d')}.md")
        os.makedirs(os.path.dirname(output), exist_ok=True)
        generate_usage_report(sessions, output)
    elif args.summary or not any([args.crew, args.order, args.voyage]):
        print_summary(sessions)


if __name__ == "__main__":
    main()
