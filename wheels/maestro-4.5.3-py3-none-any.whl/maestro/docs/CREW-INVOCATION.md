# Maestro — Crew Invocation Model

> Audience: operators, LEAD sessions, and contributors who need to understand how
> Maestro launches, bounds, observes, and recovers autonomous crew sessions.
>
> Implemented in: `maestro/core/crew.py` (v8.0+, VOY-MSO-2026-0054)

---

## Contents

1. [How a crew is launched](#1-how-a-crew-is-launched)
2. [JSON result contract](#2-json-result-contract)
3. [Terminal states](#3-terminal-states)
4. [Per-role tool scoping](#4-per-role-tool-scoping)
5. [Deterministic session IDs](#5-deterministic-session-ids)
6. [Resume vs. Ralph (fresh-context model)](#6-resume-vs-ralph-fresh-context-model)
7. [Claude CLI preflight check](#7-claude-cli-preflight-check)
8. [Why not /loop](#8-why-not-loop)

---

## 1. How a crew is launched

The fleet runner (`fleet_runner.py`) spawns each crew as a **detached subprocess** running `maestro/core/crew.py`. `crew.py` then invokes the Claude CLI once per iteration in a Python `for`-loop. The effective command for each iteration is:

```
claude \
  --print \
  --dangerously-skip-permissions \
  --model <model-id>[1m] \
  --output-format stream-json --verbose \
  --max-turns <N> \
  --session-id <uuid> \
  [--effort <low|medium|high|xhigh>] \
  [--disallowedTools <tool,...>]
```

### Flag-by-flag

| Flag | Set by | Purpose |
|------|--------|---------|
| `--print` | always | Non-interactive headless mode — reads prompt from stdin, writes result to stdout |
| `--dangerously-skip-permissions` | always | Suppresses interactive permission prompts; tool restrictions enforced via `--disallowedTools` instead |
| `--model` | `resolve_model_for(role)` | Per-role model selection (see [Roles guide](ROLES-GUIDE.md)) |
| `--effort` | `resolve_effort_for(role)` | Reasoning effort level; appended only when CLI supports it (capability probe in `find_claude_cli`); omitted when effort=high and CLI lacks the flag |
| `--output-format json` | always (FTR-0193) | Structured result object on stdout — replaces stdout string-grepping |
| `--max-turns N` | `--max-turns` dispatch flag (default 25) | Claude Code enforces an internal turn cap; hitting it produces `subtype=error_max_turns` |
| `--session-id <uuid>` | `make_session_id()` (FTR-0195) | Deterministic per-`(crew, order, iteration)` UUID for traceability |
| `--disallowedTools` | `ROLE_DISALLOWED_TOOLS[role]` (FTR-0194) | Per-role tool restriction list; omitted when the role's list is empty |

### Iteration loop

Each crew runs a Python `for`-loop (up to `--max-iterations`, default 25). On each iteration:

1. `advance_ralph_state()` — updates `.mso/crews/crewN/ralph-state.md` for fleet monitor visibility
2. `write_crew_lifecycle_event("CREW_ITER_BOUNDARY", ...)` — emits start event to lifecycle log
3. `make_session_id(crew, order, iteration)` — generates the deterministic session UUID
4. `invoke_claude(prompt, ...)` — calls the Claude CLI subprocess with the flags above
5. `parse_crew_result(stdout)` → `classify_json_terminal(json)` — classifies result; see §2 and §3
6. `write_crew_lifecycle_event("CREW_ITER_BOUNDARY", ...)` — emits end event with cost + turn count

The loop exits when any terminal state is reached (COMPLETE, MAX_TURNS, BLOCKED, TIMEOUT, ERROR) or when `max_iterations` is exhausted.

### Environment injected into crew subprocesses

| Variable | Value | Purpose |
|----------|-------|---------|
| `MAESTRO_CREW` | crew slot number | Stop hook uses this to find the right ralph-state file |
| `MAESTRO_ORDER` | order ID | Identifies which order the crew is working on |
| `MAESTRO_MAX_ITERATIONS` | iteration cap | Crew-side awareness of iteration budget |
| `MAESTRO_ITER_MANAGED` | `1` | Signals stop hook to exit cleanly (the Python for-loop owns iteration control) |
| `MAESTRO_TEMP` | `<maestro-root>/temp` | Centralised temp dir — prevents crews scattering artifacts across the workspace |
| `K2_TEST_HEADLESS` | `true` | Forces headless mode for browser tests (prevents popups on the operator's desktop) |
| `MAESTRO_REPO_PATH` | worktree path | Working directory for the Claude CLI subprocess |

---

## 2. JSON result contract

When invoked with `--output-format json`, the Claude CLI writes a single JSON object to stdout on exit. Maestro parses this object deterministically rather than grepping raw text output.

### Top-level fields Maestro uses

| Field | Type | Description |
|-------|------|-------------|
| `subtype` | string | Terminal reason: `"success"`, `"error_max_turns"`, or other error strings |
| `is_error` | bool | `true` when the session ended in an error condition |
| `result` | string | The assistant's final text output (used for `<promise>` tag detection) |
| `session_id` | string | Claude's own session UUID (stored as `claudeSessionId` in `state.json`) |
| `num_turns` | integer | Number of conversation turns used in this invocation |
| `total_cost_usd` | float | Estimated cost for this invocation in USD |

### Classification logic

```
parse_crew_result(stdout)  →  json_result dict
classify_json_terminal(json_result)  →  'COMPLETE' | 'ERROR' | 'MAX_TURNS'
```

| `subtype` | `is_error` | Classification |
|-----------|-----------|---------------|
| `"error_max_turns"` | (any) | `MAX_TURNS` |
| (any) | `true` | `ERROR` |
| `"success"` | `false` | `COMPLETE` |

### Malformed / timeout-kill fallback

When the process is killed mid-stream (wall-clock timeout fires before stdout flushes) or stdout is empty, `parse_crew_result()` returns a safe sentinel:

```json
{
  "subtype": "timeout_killed",
  "is_error": true,
  "result": "",
  "total_cost_usd": 0.0,
  "num_turns": 0,
  "session_id": "",
  "terminal_reason": "timeout_killed",
  "errors": ["No output captured (process killed before completion)"]
}
```

A JSON parse failure produces the same shape with `"subtype": "parse_error"` and `result` set to the first 2000 characters of raw stdout. Both sentinel forms are classified as `ERROR` and never as `COMPLETE`.

### Return code vs. JSON classification

`--output-format json` exits with code 1 for both genuine errors **and** for `error_max_turns`. Maestro uses the JSON `subtype` as the **primary** classification signal and treats the return code as a secondary check only:

```python
result["success"] = (proc.returncode == 0 and not json_result.get("is_error", False))
```

---

## 3. Terminal states

### Per-iteration states

| State | Source | Fleet-runner action |
|-------|--------|-------------------|
| `COMPLETE` | `<promise>COMPLETE</promise>` tag in `result` field | Order advances to next role in `roleSequence` |
| `MAX_TURNS` | `subtype == "error_max_turns"` in JSON | Order requeued with `MAX_TURNS` note in `timeoutBrief`; re-dispatched fresh |
| `BLOCKED` | `<promise>BLOCKED</promise>` tag in `result` field | Escalation created; order held pending Captain decision |
| `TIMEOUT` | Wall-clock `TimeoutExpired` — process killed | Timeout brief captured; order requeued; BUG-0023 silent-completion check runs first |
| `ERROR` | `is_error=true` in JSON or subprocess exception | Order requeued (or escalated after `circuit_breaker` consecutive failures) |
| `AUTH_ERROR` | `"authentication"` in error string | Escalated immediately; not requeued |

### MAX_TURNS vs. TIMEOUT distinction

- **MAX_TURNS**: Claude Code hit its internal turn cap (`--max-turns N`) with full structured output — the JSON result is well-formed. The crew used all allowed turns but did not complete the order. This is normal for large orders and the crew is requeued with fresh context.
- **TIMEOUT**: The wall-clock cap (`--timeout M`) killed the subprocess before Claude Code finished. Stdout may be partial or empty; `parse_crew_result()` returns the timeout-killed sentinel.

Both result in a requeue, but MAX_TURNS means "ran to completion of its turn budget" while TIMEOUT means "killed prematurely".

### Lifecycle log events

`CREW_ITER_BOUNDARY` events in `.mso/logs/lifecycle.log` carry both session IDs, the JSON subtype, cost, and turn count for each iteration. See [ARCHITECTURE.md](ARCHITECTURE.md) for the full lifecycle event vocabulary.

---

## 4. Per-role tool scoping

Each crew invocation passes `--disallowedTools` to restrict the Claude CLI to the tools appropriate for its role. This is a defence-in-depth layer on top of the workspace-level `settings.json` hardening. The two layers are **additive**: CLI scoping cannot grant tools that workspace settings have denied.

**Implementation:** `ROLE_DISALLOWED_TOOLS` dict in `maestro/core/crew.py`.

**Mechanism:** Under `--dangerously-skip-permissions`, bare tool names in `--disallowedTools` remove the tool entirely. Scoped rules like `Bash(rm:*)` are silently ignored at this flag — only bare names work.

### Tool scoping matrix

| Role | Disallowed tools | Rationale |
|------|-----------------|-----------|
| PLN | `NotebookEdit` | Needs Write/Edit for plan files; notebook editing out of scope |
| BLD | *(none)* | Full access required for implementation |
| TST | *(none)* | Full access required for test implementation |
| DOC | *(none)* | Full access required for documentation writing |
| SEC | `Write`, `Edit`, `NotebookEdit` | Read-only security review; reports written via the `sec-reviewer` subagent |
| REL | `NotebookEdit` | REL doesn't need notebook editing |
| LEAD | *(none)* | Interactive partner, unrestricted |

Roles with an empty disallowed list (`BLD`, `TST`, `DOC`, `LEAD`) receive no `--disallowedTools` flag — the argument is omitted entirely.

### Note on SEC

The SEC crew reads code and writes security report files to `.mso/reports/security/`. The read-only constraint here prevents direct code mutation. The `sec-reviewer` subagent (launched by SEC via the `Agent` tool) has its own restricted tool list defined separately.

---

## 5. Deterministic session IDs

Each crew invocation is tagged with two session UUIDs:

| ID | Field in `state.json` | Source | When written |
|----|----------------------|--------|-------------|
| `maestroSessionId` | `maestroSessionId` | `make_session_id(crew, order, iteration)` | Before `invoke_claude()` |
| `claudeSessionId` | `claudeSessionId` | `json_result["session_id"]` | After invocation completes |

### `make_session_id()` scheme

```python
_SESSION_NS = uuid.UUID("6ba7b810-9dad-11d1-80b4-00c04fd430c8")  # UUIDv5 DNS namespace

def make_session_id(crew_number: int, order_id: str, iteration: int) -> str:
    seed = f"maestro:crew{crew_number}:{order_id}:iter{iteration}"
    return str(uuid.uuid5(_SESSION_NS, seed))
```

Properties:
- **Deterministic**: same `(crew, order, iteration)` always yields the same UUID — stable for post-mortem correlation across re-runs
- **Unique per iteration**: different iterations produce different UUIDs — each Claude invocation is independently traceable
- **No collision with Claude's IDs**: `maestroSessionId` is a UUIDv5; `claudeSessionId` is Claude's own opaque UUID

Both IDs are emitted in `CREW_ITER_BOUNDARY` lifecycle events:

```
2026-05-21 10:30:00 | CREW_ITER_BOUNDARY   | crew1 | FTR-MSO-2026-0001 | iter 1/25 | role=BLD | DONE
  subtype=success cost=$0.0142 turns=8
  maestroSession=a3f7e2b1-... claudeSession=sess_01Ab...
```

---

## 6. Resume vs. Ralph (fresh-context model)

### The Ralph fresh-context model

Maestro uses the **Ralph model** for crew recovery: when an order is requeued (after TIMEOUT, MAX_TURNS, or ERROR), the next crew invocation starts with a **fresh context** — iteration 1, full prompt, no prior conversation history loaded.

This is the default and deliberate choice. The next crew sees:
- The current state of the codebase (via normal file reads)
- A "Previous Attempts" section in its prompt (from the `timeoutBrief` captured by the prior crew)
- No stale conversation context that could mislead it

### Why `--resume` was evaluated and deferred

The Claude CLI's `--resume <session-id>` flag can replay a prior session's conversation history before continuing. Maestro evaluated this for crew recovery (PLN-MSO-2026-0192, Part D) and deferred it for these reasons:

1. **Context bloat** — resuming replays the full prior conversation history before continuing, consuming turns and tokens on context the crew has already acted on
2. **BUG-0023 covers the main recovery case** — silent-completion detection (`SILENT_COMPLETION_DETECTED` lifecycle event) handles crews that committed work but timed out before signalling COMPLETE. The fleet runner detects the commit on the voyage branch and advances the order rather than requeueing
3. **`MAESTRO_ITER_MANAGED` interaction** — if the Python loop killed the process via `TimeoutExpired`, session state may be inconsistent; resuming into a partially-committed state could cause duplicate work

The Ralph model remains in effect. If future operators observe crews wasting significant turns re-reading context on requeue, `--resume` can be re-evaluated in a later voyage with empirical data.

---

## 7. Claude CLI preflight check

`claude doctor` is a TUI-interactive command that cannot be used headlessly (empirically confirmed in PLN-0192 Spike 5). Maestro uses a lightweight smoke test instead: `run_preflight_check()` in `maestro/core/crew.py`.

### What the preflight check does

Sends a trivial prompt to the Claude CLI and checks for a well-formed success response:

```
claude --print --dangerously-skip-permissions --output-format json --max-turns 1
< "Reply with the single word: OK"
```

A pass requires: exit code 0, valid JSON output, `subtype == "success"`, and `is_error == false`.

### Gate behaviour

| Location | When | On failure |
|----------|------|-----------|
| `mso setup` | Always, as the final setup step | Hard block — `sys.exit(1)` with error message |
| `mso dispatch` (pre-loop) | Only if `preflight_check: true` in `workspace.json` (default `false`) | Soft warn — failure logged to lifecycle log as `WARN`, dispatch continues |

### Opt-in for dispatch-time preflight

```json
{
  "preflight_check": true
}
```

Add this to `.mso/config/workspace.json` to enable the preflight gate before each dispatch run.

### CI bypass

Set `MAESTRO_SKIP_AUTH=1` to bypass the preflight check in environments without a live Claude account. The check returns `ok=True` immediately when this variable is set.

---

## 8. Why not /loop

Maestro's crew dispatch is **external orchestration** of headless Claude processes, not in-session self-pacing. Key distinctions:

| `/loop` | Maestro crew dispatch |
|---------|-----------------------|
| Runs inside a Claude Code session | Runs `claude --print` as a subprocess |
| Self-pacing within one session | Python for-loop in `crew.py` owns iteration control |
| Interactive — can ask questions | Fully headless — reads from stdin, writes to stdout |
| Single session, one context | Each iteration may have fresh context (Ralph model) |
| For interactive workflows | For autonomous fleet execution |

The `MAESTRO_ITER_MANAGED=1` environment variable signals the stop hook to exit cleanly instead of re-feeding prompts via `{"decision": "block"}` — a mechanism that silently fails on Windows in a detached process context (BUG-MSO-2026-0029). The Python for-loop in `crew.py` is the single source of truth for iteration control.

---

*See also: [ARCHITECTURE.md](ARCHITECTURE.md) · [ROLES-GUIDE.md](ROLES-GUIDE.md) · [TROUBLESHOOTING.md](TROUBLESHOOTING.md) · [CLI-REFERENCE.md](CLI-REFERENCE.md) · [PARALLEL-VOYAGES.md](PARALLEL-VOYAGES.md)*
