#!/usr/bin/env python3
"""
Maestro - Parallel Fleet Runner v2.0.0

Features:
- Pre-flight checks (clean state before starting)
- Rogue process detection and cleanup
- Stale state file cleanup
- Robust process tracking via PID files (no parent-child handles)
- Graceful shutdown handling
- WAVE SEQUENCING - Auto-promotes through waves when crews complete
- Bell ringing on voyage completion
- v5.0: Compatible with self-organizing crews and queue system
- v5.1: STAGGERED CREW LAUNCHES - configurable delay between crew starts
- v5.2: AUTO-DISPATCHER - Watches queues and auto-dispatches idle crews
        Priority: requests first, then orders. Never exceeds max concurrent crews.
- v6.0: INDEPENDENT PROCESS LAUNCH - Crews launch as fully detached processes
        (CREATE_NEW_CONSOLE | CREATE_NEW_PROCESS_GROUP).
        No CLI lock needed. Restores 5-crew concurrent capability.
- v7.0: DEPENDENCY-AWARE DISPATCH - 8-tier priority queues, escalation handling
- v7.3: TIMEOUT BRIEFING - captures iteration state on timeout, re-feeds to next crew
- v8.0: STOP HOOK ITERATION CONTROL - crew.py uses python -m maestro.hooks.stop (Ralph Wiggum
        pattern) for multi-pass iterations. Single Claude invocation per order.
        Hook intercepts Claude's natural exit and re-feeds prompts.
        Per-crew ralph-state.md tracks iteration count and status.
- v8.2: ROLE SEQUENCE GATES - Automatic enforcement of role ordering per voyage.
        Reads roleSequence from order templates, checks voyage-level completion
        status before dispatching. Quality gates (BOS/QA) can never be skipped.
        Usage: python fleet-runner.py --validate-sequences (dry-run check)
- v8.3: REQUIREMENTS TRACEABILITY GATE - QM can run scanner pre-flight or post-voyage.
        Usage: python fleet-runner.py --validate-traceability
        Runs: dotnet run --project Uplifted/Tools/RequirementsScanner -- --gate --min-coverage 80
- v8.6: DISPATCH LOG FIXES + POST-VOYAGE MATRIX UPDATE
        Fixed: priority showing '?' (wrong field name sort_priority→priority)
        Fixed: order title showing 'Unknown' (queue JSONs use orderId, no title field)
        Fixed: order ID resolution (orderId→id→filename fallback chain)
        Added: Post-voyage auto-refresh of REQUIREMENTS-MATRIX.md via update-matrix.py
- v8.13: POST-VOYAGE AUTO-PR CREATION
        Scans completed orders at Eight Bells, collects unique targetRepo values,
        creates PRs from voyage branch to main for each repo that had work done.
        Usage: automatic at Eight Bells, or manual: python fleet-runner.py --create-prs
- v2.0.0: MANAGED REPO LIFECYCLE
        Per-crew worktree: each crew runs in its own git worktree on the voyage branch.
        Post-completion: create/update PR immediately when each crew completes.
        Cleanup: remove voyage worktree at Eight Bells.
"""

import argparse
import atexit
import json
import os
import re
import shutil
import signal
import subprocess
from maestro.launch.sandbox import spawn as _spawn
from maestro.core.gates import load_gate_config, gate_check_post_nav, should_auto_approve
from maestro.personas import current_persona
import sys
import concurrent.futures
import threading
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Dict, Any, Optional, List

# Windows-specific process creation flags
if os.name == 'nt':
    CREATE_NEW_CONSOLE = 0x00000010
    DETACHED_PROCESS = 0x00000008
    CREATE_NEW_PROCESS_GROUP = 0x00000200

# Enable Windows console colors and UTF-8 output
if os.name == 'nt':
    os.system('chcp 65001 >nul 2>&1')
    os.system('')
    # Fix Python stdout/stderr encoding for Windows consoles (prevents charmap errors)
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    if hasattr(sys.stderr, 'reconfigure'):
        sys.stderr.reconfigure(encoding='utf-8', errors='replace')

from maestro import core_constants as _core_constants
from maestro.core import order_ledger  # BUG-MSO-2026-0294: git-immune dispatch gate
from maestro.errors import run_cli

def _get_crew_name(slot: int) -> str:
    """Return persona squad name for slot, falling back to 'Crew<slot>'."""
    return _core_constants.get_squad_name(slot) or f"Crew{slot}"

def _get_role_model_label(role: str) -> str:
    """Return short model label for role (Opus/Sonnet/Haiku), falling back to 'Sonnet'."""
    return _core_constants.get_role_model(role)


# Active voyage branch — set from MAESTRO_SPRINT_BRANCH env var
# Injected into all crew process environments so crews know where to push commits.
ACTIVE_VOYAGE_BRANCH: str = os.environ.get("MAESTRO_SPRINT_BRANCH", "")

# v8.13: Track target repos dispatched during this session (for post-voyage PR creation)
_SESSION_TARGET_REPOS: Dict[str, list] = {}  # repo -> [order titles]
# v2.0.2: Track voyage branch per repo (for per-repo PR creation)
_SESSION_REPO_BRANCHES: Dict[str, str] = {}  # repo -> voyage branch

# v7.1: Comprehensive terminal states — any state a crew can exit with that means "done"
# This must match ALL possible final_status values from crew.py
TERMINAL_STATES = {
    "COMPLETE", "BLOCKED", "ERROR", "MAX_ITERATIONS", "MAX_TURNS", "CRASHED",
    "CIRCUIT_BREAKER", "TIMEOUT", "AUTH_ERROR", "INTERRUPTED"
}

class C:
    """ANSI color codes."""
    RESET = '\033[0m'
    BOLD = '\033[1m'
    DIM = '\033[2m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    RED = '\033[91m'
    WHITE = '\033[97m'
    MAGENTA = '\033[95m'

# Global state
ACTIVE_PROCESSES: Dict[int, int] = {}  # crew_number -> PID (file-based monitoring, no process handles)
DRAINING_PROCESSES: Dict[int, Dict[str, Any]] = {}  # crew_number -> {pid, voyage_id, drained_at}
ORDERS_IN_TRANSITION: set = set()  # order IDs advanced to next role but not yet dispatched (BUG-MSO-2026-0017)
_BUG0263_WARNED: set = set()  # order IDs for which the BUG-0263 resurfaced-terminal WARN was already emitted this process (BUG-MSO-2026-0288)
LAST_ORDER_TERMINAL_AT: Optional[datetime] = None  # wall-clock of the most recent COMPLETE/STALLED archive (BUG-MSO-2026-0024)
# BUG-MSO-2026-0236: single-flight guard — set of (order_id, role) tuples currently
# being finalized in process_crew_completion(). Prevents a second dispatcher-loop
# iteration from entering finalization for the same (order, role) while the first
# finalization thread is still running.
_FINALIZING_ORDERS: set = set()
_FINALIZING_LOCK = threading.Lock()
# BUG-MSO-2026-0222: watchdog budget for post-crew finalization (advance/archive).
# If complete_order + auto_queue_unblocked_orders don't finish within this window,
# the dispatcher logs a warning and continues — the roleSucceededAt checkpoint ensures
# self-healing on the next restart.
FINALIZATION_WATCHDOG_SECONDS: int = 120
_CREW_LOG_HANDLES: Dict[int, Any] = {}  # crew_number -> file handle (for background mode log files)
FLEET_STATE_FILE: Optional[Path] = None
SHUTDOWN_REQUESTED = False
_MAESTRO_DIR_OVERRIDE: Optional[Path] = None
# BUG-MSO-2026-0268: CLI override for convergence network timeout; None = use workspace.json default.
_CONVERGENCE_TIMEOUT_CLI_OVERRIDE: Optional[int] = None


def _resolve_workspace_dir() -> Path:
    """Internal workspace resolver — honours _MAESTRO_DIR_OVERRIDE for test isolation."""
    if _MAESTRO_DIR_OVERRIDE is not None:
        return _MAESTRO_DIR_OVERRIDE
    from maestro.workspace import get_workspace_dir as _get_ws
    return _get_ws()

# Public alias so external callers (tests, crew.py) can import get_workspace_dir from here.
get_workspace_dir = _resolve_workspace_dir

def get_base_dir() -> Path:
    if _MAESTRO_DIR_OVERRIDE is not None:
        return _MAESTRO_DIR_OVERRIDE.parent
    return _resolve_workspace_dir().parent

def get_crew_dir(crew_number: int) -> Path:
    return _resolve_workspace_dir() / f"crews/crew{crew_number}"


def load_project_config(project_acronym=None):
    """Load project config from the project registry."""
    admiralty_dir = get_workspace_dir()
    projects_file = admiralty_dir / "config" / "projects.json"

    if not projects_file.exists():
        return None

    with open(projects_file, encoding='utf-8') as f:
        registry = json.load(f)

    if not project_acronym:
        project_acronym = registry.get("defaultProject", "OTM")

    project_info = registry.get("projects", {}).get(project_acronym)
    if not project_info:
        return None

    # Load per-project config if available
    config_file_rel = project_info.get("configFile", f"config/projects/{project_acronym}.json")
    config_file = admiralty_dir / config_file_rel

    if config_file.exists():
        with open(config_file, encoding='utf-8') as f:
            project_config = json.load(f)
        project_info["_config"] = project_config

    return project_info

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def print_header(title: str):
    """Print a section header."""
    print(f"\n  {C.CYAN}{C.BOLD}{'='*70}")
    print(f"  {title}")
    print(f"  {'='*70}{C.RESET}\n")

def print_ok(msg: str):
    print(f"  {C.GREEN}[OK]{C.RESET} {msg}")

def print_warn(msg: str):
    print(f"  {C.YELLOW}[!!]{C.RESET} {msg}")

def print_error(msg: str):
    print(f"  {C.RED}[XX]{C.RESET} {msg}")

def print_info(msg: str):
    print(f"  {C.DIM}[..]{C.RESET} {msg}")


def write_lifecycle_event(event_type: str, message: str):
    """Append a timestamped lifecycle event to the log file.

    Used by the unified Maestro Monitor to display recent events.
    Format: YYYY-MM-DD HH:MM:SS | EVENT_TYPE | message
    Auto-rotates when log exceeds 1000 lines.
    """
    log_dir = get_workspace_dir() / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / "lifecycle.log"

    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    line = f"{timestamp} | {event_type:<10} | {message}\n"

    try:
        with open(str(log_file), 'a', encoding='utf-8') as f:
            f.write(line)

        # Rotate if too large
        if log_file.stat().st_size > 100000:  # ~1000 lines
            lines = log_file.read_text(encoding='utf-8').split('\n')
            # Keep last 500 lines
            log_file.write_text('\n'.join(lines[-500:]), encoding='utf-8')
    except:
        pass


def _lifecycle_commit_enabled() -> bool:
    """BUG-MSO-2026-0295: `lifecycle.commitTransitions` in workspace.json (default ON)."""
    try:
        cfg = json.loads(
            (get_workspace_dir() / "config" / "workspace.json").read_text(encoding="utf-8"))
        return bool((cfg.get("lifecycle") or {}).get("commitTransitions", True))
    except Exception:
        return True


def _commit_lifecycle_transition(paths: List[Path], message: str) -> bool:
    """BUG-MSO-2026-0295: commit an order-lifecycle file transition (best-effort).

    Lifecycle moves (queue → orders/complete) used to live only in the working
    tree; any `git reset --hard` / checkout rewound them, resurrecting completed
    orders as PENDING and carrying stale queue snapshots through voyage PRs into
    the base branch (PSG VOY-PSG-2026-0344). Committing the transition puts the
    truth in history. Fail-open by design: not a git repo, nothing staged, or
    git missing → return False silently. The BUG-0294 ledger still gates
    dispatch regardless.
    """
    if not _lifecycle_commit_enabled():
        return False
    try:
        base = get_base_dir()
        if not (base / ".git").exists():
            return False
        rel = [str(p) for p in paths]
        add_r = subprocess.run(["git", "add", "--"] + rel,
                               capture_output=True, text=True,
                               cwd=str(base), timeout=15)
        if add_r.returncode != 0:
            return False
        commit_r = subprocess.run(
            ["git", "commit", "-m", message, "--"] + rel,
            capture_output=True, text=True, cwd=str(base), timeout=15)
        return commit_r.returncode == 0
    except Exception:
        return False


# BUG-MSO-2026-0022: story-sizing ceilings (soft gate — warns, does not block)
SIZING_CEILING_FILES = 30
SIZING_CEILING_LOC = 2000
SIZING_CEILING_TOOL_CALLS = 50

# BUG-MSO-2026-0206: bound how many times an orphaned/timed-out order may be
# re-queued before escalating to STALLED (human review). Prevents the infinite
# REQUEUE loop seen on validate-only roles whose hung crew committed nothing.
MAX_REQUEUES = 2

# BUG-MSO-2026-0024: Eight Bells must wait out a grace window after the most
# recent order COMPLETE/STALLED archive before firing. The BUG-0017 fix only
# covered ADVANCE->DISPATCH transitions (ORDERS_IN_TRANSITION); it missed the
# COMPLETE->DISPATCH case where an archived order freshly unblocks a dependent
# the dispatcher hasn't re-scanned yet (~3-10s gap). The grace window closes
# that race. Override with MAESTRO_EIGHT_BELLS_GRACE_SECONDS.
EIGHT_BELLS_GRACE_SECONDS = 30


def parse_plan_sizing(plan_path: "Path") -> dict:
    """Extract declared sizing estimates from a PLN/NAV plan or handoff file.

    Looks for lines matching:
        Estimated files changed: N
        Estimated LoC changed: N
        Estimated Edit/Write tool calls: N

    Returns a dict with keys 'files', 'loc', 'tool_calls' (int or None if not found).
    """
    import re
    result = {"files": None, "loc": None, "tool_calls": None}
    if plan_path is None or not plan_path.exists():
        return result
    try:
        text = plan_path.read_text(encoding="utf-8")
    except Exception:
        return result

    patterns = [
        ("files", r"Estimated files changed:\s*(\d+)"),
        ("loc", r"Estimated LoC changed:\s*(\d+)"),
        ("tool_calls", r"Estimated Edit/Write tool calls:\s*(\d+)"),
    ]
    for key, pat in patterns:
        m = re.search(pat, text, re.IGNORECASE)
        if m:
            result[key] = int(m.group(1))
    return result


def check_plan_sizing(order_id: str, workspace_dir: "Path") -> list:
    """Check all plan/handoff files for an order against sizing ceilings.

    Returns a list of warning strings (empty if all ceilings satisfied or no
    sizing data found). Emits OVERSIZED_STORY lifecycle events for each breach.
    """
    import glob as _glob
    warnings = []
    plans_dir = workspace_dir / "plans"
    handoffs_dir = workspace_dir / "handoffs" / order_id

    candidate_paths = []
    for d in [plans_dir, handoffs_dir]:
        if d.exists():
            candidate_paths.extend(d.glob("*.md"))

    sizing: dict = {"files": None, "loc": None, "tool_calls": None}
    for path in candidate_paths:
        found = parse_plan_sizing(path)
        for k in sizing:
            if found[k] is not None:
                sizing[k] = found[k]

    ceilings = [
        ("files", SIZING_CEILING_FILES, "files changed"),
        ("loc", SIZING_CEILING_LOC, "LoC changed"),
        ("tool_calls", SIZING_CEILING_TOOL_CALLS, "Edit/Write tool calls"),
    ]
    for key, ceil, label in ceilings:
        val = sizing[key]
        if val is not None and val > ceil:
            msg = (
                f"{order_id} plan estimates {val} {label} "
                f"(ceiling: {ceil}) — PLN must decompose into sub-stories"
            )
            warnings.append(msg)
            write_lifecycle_event("OVERSIZED_STORY", msg)

    return warnings


# =============================================================================
# PRE-FLIGHT CHECKS
# =============================================================================

def _spawn_marker() -> str:
    """BUG-MSO-2026-0302: stable per-workspace marker for spawned process trees."""
    import hashlib
    ws = str(get_workspace_dir()).lower().encode("utf-8", errors="replace")
    return f"mso-spawn-{hashlib.sha1(ws).hexdigest()[:12]}"


def sweep_marked_orphans() -> tuple:
    """BUG-MSO-2026-0302 (GKT: PID 28048 survived every cleanup): find and kill
    crew-descended processes that no PID file references.

    The PID-file reaper cannot reach a grandchild whose parent already died
    (taskkill /T needs a live tree root). This sweep enumerates processes
    whose CommandLine carries this workspace's spawn marker (stamped onto
    crew.py argv at launch) and kills them, then VERIFIES and reports any
    survivors loudly. Children that don't inherit the marker on their own
    command line (e.g. claude's node descendants) remain a known limitation —
    Windows Job Objects are the structural fix (documented in the order).

    Returns (reaped_pids, survivor_pids).
    """
    marker = _spawn_marker()
    my_pid = os.getpid()

    def _find() -> list:
        try:
            if os.name == "nt":
                # $PID/-notlike guards: the enumerating PowerShell's OWN command
                # line contains the marker — without exclusion the sweep finds
                # itself and reports a phantom survivor forever.
                ps = (
                    "Get-CimInstance Win32_Process | "
                    f"Where-Object {{ $_.CommandLine -like '*{marker}*' "
                    f"-and $_.ProcessId -ne $PID "
                    f"-and $_.CommandLine -notlike '*Get-CimInstance*' }} | "
                    "Select-Object -ExpandProperty ProcessId"
                )
                r = subprocess.run(["powershell", "-NoProfile", "-Command", ps],
                                   capture_output=True, text=True, timeout=30)
            else:
                r = subprocess.run(["pgrep", "-f", marker],
                                   capture_output=True, text=True, timeout=30)
            pids = []
            for line in (r.stdout or "").splitlines():
                line = line.strip()
                if line.isdigit() and int(line) != my_pid:
                    pids.append(int(line))
            return pids
        except Exception:
            return []

    targets = _find()
    for pid in targets:
        try:
            if os.name == "nt":
                subprocess.run(["taskkill", "/F", "/T", "/PID", str(pid)],
                               capture_output=True, timeout=10)
            else:
                os.kill(pid, 9)
        except Exception:
            pass

    # taskkill returns before the process fully tears down — poll briefly
    # so a normal kill isn't misreported as a survivor.
    survivors = []
    if targets:
        for _ in range(6):
            time.sleep(0.5)
            survivors = _find()
            if not survivors:
                break
    if survivors:
        write_lifecycle_event(
            "WARN",
            f"cleanup orphan sweep: {len(survivors)} marked process(es) SURVIVED "
            f"kill — PIDs {survivors}. Kill manually and report (BUG-0302)."
        )
    elif targets:
        write_lifecycle_event(
            "DISPATCH",
            f"cleanup orphan sweep reaped {len(targets)} marked process(es): {targets} (BUG-0302)"
        )
    return targets, survivors


def preflight_kill_rogue_processes() -> int:
    """Kill rogue crew.py and fleet-runner.py processes from previous runs.

    Uses PID-based approach (fast, reliable) from pid.txt files and fleet state.
    Does NOT use wmic commandline matching (slow, can hang on Git Bash).
    IMPORTANT: Does NOT kill the CURRENT fleet-runner process.
    """
    killed = 0
    my_pid = os.getpid()

    if os.name == 'nt':
        # 1. Kill old dispatcher by PID lock
        dispatcher_lock = get_workspace_dir() / "dispatcher.pid"
        if dispatcher_lock.exists():
            try:
                pid = int(dispatcher_lock.read_text(encoding='utf-8').strip())
                if pid != my_pid:
                    subprocess.run(['taskkill', '/F', '/T', '/PID', str(pid)],
                                 capture_output=True, timeout=5)
                    killed += 1
                dispatcher_lock.unlink()
            except:
                pass

        # 2. Clean stale monitor PID lock
        monitor_lock = get_workspace_dir() / "monitor.pid"
        if monitor_lock.exists():
            try:
                mpid = int(monitor_lock.read_text(encoding='utf-8').strip())
                if not is_process_alive(mpid):
                    monitor_lock.unlink()
            except:
                pass

        # 3. Kill by PID files in crew directories
        for crew_num in range(1, 6):
            pid = read_crew_pid(crew_num)
            if pid and pid != my_pid:
                try:
                    subprocess.run(['taskkill', '/F', '/T', '/PID', str(pid)],
                                 capture_output=True, timeout=5)
                    killed += 1
                except:
                    pass

        # 4. Kill by fleet state file (catches tracked crews)
        fleet_state = get_workspace_dir() / "fleet-runner-state.json"
        if fleet_state.exists():
            try:
                state = json.loads(fleet_state.read_text(encoding='utf-8'))
                for crew_num, pid in state.get("pids", {}).items():
                    if int(pid) != my_pid:
                        try:
                            subprocess.run(['taskkill', '/F', '/T', '/PID', str(pid)],
                                         capture_output=True, timeout=5)
                            killed += 1
                        except:
                            pass
            except:
                pass

    return killed

def preflight_clear_stale_states(preserve_complete: bool = False) -> int:
    """Clear stale state files from crew directories.

    Args:
        preserve_complete: If True, don't clear COMPLETE status states (for --continue mode)
    """
    cleared = 0

    for crew_num in range(1, 6):
        crew_dir = get_crew_dir(crew_num)
        if crew_dir.exists():
            # Clear state.json
            state_file = crew_dir / "state.json"
            if state_file.exists():
                should_clear = True

                # In continue mode, preserve COMPLETE states
                if preserve_complete:
                    try:
                        state = json.loads(state_file.read_text(encoding='utf-8'))
                        if state.get("status") == "COMPLETE":
                            should_clear = False
                            print_info(f"Preserving Crew {crew_num} COMPLETE state")
                    except:
                        pass

                if should_clear:
                    try:
                        state_file.unlink()
                        cleared += 1
                    except:
                        pass

            # v8.9: Clear ralph-state.md (prevents stale COMPLETE detection on re-dispatch)
            ralph_file = crew_dir / "ralph-state.md"
            if ralph_file.exists():
                should_clear_ralph = True
                if preserve_complete:
                    try:
                        content = ralph_file.read_text(encoding='utf-8')
                        if "status: \"COMPLETE\"" in content:
                            should_clear_ralph = False
                    except:
                        pass
                if should_clear_ralph:
                    try:
                        ralph_file.unlink()
                        cleared += 1
                    except:
                        pass

            # Clear any lock files
            for lock_file in crew_dir.glob("*.lock"):
                try:
                    lock_file.unlink()
                except:
                    pass

    # Clear fleet state file
    fleet_state = get_workspace_dir() / "fleet-runner-state.json"
    if fleet_state.exists():
        try:
            fleet_state.unlink()
            cleared += 1
        except:
            pass

    return cleared


def reset_orphaned_in_progress_orders() -> int:
    """Reset orphaned IN_PROGRESS orders back to PENDING (v8.2).

    After cleanup kills crew processes, orders they were working on remain
    stuck as IN_PROGRESS in the queues. This scans all queue directories
    and resets any IN_PROGRESS order whose assigned crew is no longer alive.
    """
    reset_count = 0
    queues_dir = get_queues_dir()

    if not queues_dir.exists():
        return 0

    for queue_subdir in queues_dir.iterdir():
        if not queue_subdir.is_dir():
            continue
        # Scan this tier's own *.json AND one level deeper (e.g. requests/<category>/*.json)
        # so checkpoint-based finalization resume works for nested subqueues too — matching
        # the requests-subdir search in recover_orphaned_order(). Completed-bug archives under
        # tiers like bugs/complete/ are caught by the */*.json pass but skipped by the
        # IN_PROGRESS guard below, so the wider scan is harmless.
        candidate_files = list(queue_subdir.glob("*.json")) + list(queue_subdir.glob("*/*.json"))
        for json_file in candidate_files:
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                if data.get("status") != "IN_PROGRESS":
                    continue

                # Check if assigned crew is still alive
                assigned = data.get("assignedTo", {})
                crew_num = assigned.get("crew")
                crew_alive = False

                if crew_num:
                    # Module-level tracking is authoritative — includes draining crews
                    # whose process may already be dead but whose order is still valid
                    if crew_num in ACTIVE_PROCESSES or crew_num in DRAINING_PROCESSES:
                        crew_alive = True
                    else:
                        pid = read_crew_pid(crew_num)
                        if pid and is_process_alive(pid):
                            crew_alive = True

                if not crew_alive:
                    order_id = data.get("orderId") or data.get("id") or json_file.stem

                    # BUG-MSO-2026-0222: if the crew succeeded but the dispatcher
                    # crashed before finalization completed, roleSucceededAt is set.
                    # Resume finalization (advance/archive) instead of re-dispatching
                    # the same role, which would cause an infinite re-run loop.
                    succeeded_by = data.get("roleSucceededBy", {})
                    if data.get("roleSucceededAt") and succeeded_by.get("role"):
                        succeeded_role = succeeded_by["role"]
                        orig_crew = succeeded_by.get("crew", crew_num)
                        write_lifecycle_event(
                            "FINALIZE",
                            f"{order_id} roleSucceededAt checkpoint found for role {succeeded_role} "
                            f"(orig Crew {orig_crew}) — resuming finalization instead of re-dispatching (BUG-0222)"
                        )
                        print_info(f"Order {order_id} role {succeeded_role} already succeeded — resuming finalization")
                        crew_state_resume = {
                            "role": succeeded_role,
                            "orderId": order_id,
                            "status": "COMPLETE",
                            "iteration": data.get("iteration", 0),
                            "crew": orig_crew,
                        }
                        try:
                            complete_order(order_id, orig_crew, crew_state_resume)
                            # Mirror the normal COMPLETE finalization path: complete_order
                            # advances/archives the order but does NOT itself queue
                            # dependents, so a crash-resumed completion must also release
                            # any orders whose dependencies are now satisfied — otherwise
                            # the "self-heal" archives this order but never dispatches its
                            # dependents.
                            auto_queue_unblocked_orders(order_id)
                        except Exception as exc:
                            write_lifecycle_event(
                                "WARN",
                                f"{order_id} finalization resume failed: {exc} — resetting to PENDING as fallback"
                            )
                            data["status"] = "PENDING"
                            data.pop("assignedTo", None)
                            data.pop("startedAt", None)
                            data.pop("roleSucceededAt", None)
                            data.pop("roleSucceededBy", None)
                            tmp_file = json_file.with_suffix('.tmp')
                            tmp_file.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')
                            tmp_file.replace(json_file)
                        reset_count += 1
                        continue

                    # Normal path: no checkpoint — reset to PENDING for re-dispatch
                    data["status"] = "PENDING"
                    data.pop("assignedTo", None)
                    data.pop("startedAt", None)

                    # Atomic write: temp file + rename
                    tmp_file = json_file.with_suffix('.tmp')
                    tmp_file.write_text(
                        json.dumps(data, indent=2, ensure_ascii=False),
                        encoding='utf-8'
                    )
                    tmp_file.replace(json_file)

                    # BUG-MSO-2026-0298: also release the durable ledger claim —
                    # without this, a cleanup-reset order stays vetoed as
                    # in-flight until the dead pid check happens to clear it.
                    order_ledger.record_released(
                        order_id, "cleanup: orphaned IN_PROGRESS reset",
                        workspace_dir=get_workspace_dir())

                    print_info(f"Reset orphaned order {order_id} -> PENDING")
                    reset_count += 1
            except Exception:
                pass

    # BUG-MSO-2026-0226 (AC-3): Scan orders/active/ for orders that have a roleSucceededAt
    # checkpoint but are no longer IN_PROGRESS and have no live crew — these are
    # partially-finalized half-advanced orders that slipped through the queue orphan scan
    # (e.g. dispatcher exited between advance write and archive step).
    active_orders_dir = get_workspace_dir() / "orders" / "active"
    if active_orders_dir.exists():
        for json_file in active_orders_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                if data.get("status") == "IN_PROGRESS":
                    continue  # already handled by the queue scan above
                if not data.get("roleSucceededAt"):
                    continue  # no checkpoint — not a partial-finalization orphan

                order_id = data.get("orderId") or data.get("id") or json_file.stem
                succeeded_by = data.get("roleSucceededBy", {})
                succeeded_role = succeeded_by.get("role")
                if not succeeded_role:
                    continue

                # Confirm no live crew holds this order
                assigned = data.get("assignedTo", {})
                crew_num = assigned.get("crew")
                crew_alive = False
                if crew_num:
                    if crew_num in ACTIVE_PROCESSES or crew_num in DRAINING_PROCESSES:
                        crew_alive = True
                    else:
                        pid = read_crew_pid(crew_num)
                        if pid and is_process_alive(pid):
                            crew_alive = True
                if crew_alive:
                    continue

                orig_crew = succeeded_by.get("crew", crew_num)
                write_lifecycle_event(
                    "FINALIZE",
                    f"{order_id} half-advanced orphan in orders/active/ — roleSucceededAt "
                    f"checkpoint for role {succeeded_role} (BUG-0226 AC-3) — resuming finalization"
                )
                print_info(f"Order {order_id} half-advanced in orders/active/ — resuming finalization")
                crew_state_resume = {
                    "role": succeeded_role,
                    "orderId": order_id,
                    "status": "COMPLETE",
                    "iteration": data.get("iteration", 0),
                    "crew": orig_crew,
                }
                try:
                    complete_order(order_id, orig_crew, crew_state_resume)
                    auto_queue_unblocked_orders(order_id)
                except Exception as exc:
                    write_lifecycle_event(
                        "WARN",
                        f"{order_id} orders/active/ finalization resume failed: {exc} — resetting to PENDING as fallback"
                    )
                    data["status"] = "PENDING"
                    data.pop("assignedTo", None)
                    data.pop("startedAt", None)
                    data.pop("roleSucceededAt", None)
                    data.pop("roleSucceededBy", None)
                    tmp_file = json_file.with_suffix('.tmp')
                    tmp_file.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')
                    tmp_file.replace(json_file)
                reset_count += 1
            except Exception:
                pass

    return reset_count


def _reclaim_inflight_from_crew_state() -> int:
    """BUG-MSO-2026-0018: Reconstruct ACTIVE_PROCESSES from crew state.json on startup.

    Scans .mso/crews/crewN/state.json for crews whose status is a non-terminal
    running state and whose PID is still alive.  Repopulates ACTIVE_PROCESSES so
    the first dispatcher tick does not re-dispatch orders that are already owned
    by a live crew.

    Dead-PID crews are skipped — their orders remain eligible for fresh dispatch
    via the normal reset_orphaned_in_progress_orders() path.

    Returns the number of crews reclaimed.
    """
    reclaimed = 0
    crews_dir = get_workspace_dir() / "crews"
    if not crews_dir.exists():
        return 0

    for crew_dir in sorted(crews_dir.iterdir()):
        if not crew_dir.is_dir() or not crew_dir.name.startswith("crew"):
            continue
        state_file = crew_dir / "state.json"
        if not state_file.exists():
            continue
        try:
            state = json.loads(state_file.read_text(encoding="utf-8"))
        except Exception:
            continue

        crew_num = state.get("crewNumber")
        pid = state.get("pid")
        status = state.get("status", "")
        order_id = state.get("orderId", "")

        if crew_num is None or pid is None:
            continue
        if status in TERMINAL_STATES:
            continue
        if not is_process_alive(pid):
            continue

        # Live crew with non-terminal status — reclaim it
        ACTIVE_PROCESSES[crew_num] = pid
        print_info(f"[reclaim] Crew {crew_num} (PID {pid}) reclaimed for {order_id} ({status})")
        reclaimed += 1

    return reclaimed


def preflight_verify_crew_dirs():
    """Ensure crew directories exist."""
    for crew_num in range(1, 6):
        crew_dir = get_crew_dir(crew_num)
        crew_dir.mkdir(parents=True, exist_ok=True)

# Legacy manifest mode removed in v2.0.4 — use --dispatch (queue-based) instead


# =============================================================================
# VOYAGE BRANCH MANAGEMENT
# =============================================================================

# Track which repos we've already verified/created branches for (avoid repeated API calls)
_VERIFIED_VOYAGE_BRANCHES: set = set()

# BUG-ADM-2026-0007: per-(repo,branch) failure cache so a missing-default-branch
# or auth-failure doesn't trigger a `gh api` storm on every dispatcher loop.
# Maps cache_key -> last_error_message for diagnostics.
_FAILED_VOYAGE_BRANCHES: dict = {}


def _resolve_full_repo_slug(target_repo: str, org: str) -> str:
    """Return a full `org/repo` slug regardless of whether `target_repo` is
    bare ("Admiralty") or already-qualified ("PlaneSales/Planes-Sales-Global-AI").

    BUG-ADM-2026-0007 (Copilot review): orders + project registry entries
    use BOTH conventions, and unconditionally prepending `org/` produced
    `repos/PlaneSales/PlaneSales/Planes-Sales-Global-AI/...` paths that
    404'd permanently and got cached as failures.
    """
    if "/" in target_repo:
        return target_repo
    return f"{org}/{target_repo}"


def _get_default_branch_for_repo(target_repo: str, project_acronym: str = "") -> str:
    """Resolve the default branch for a given target repo.

    BUG-ADM-2026-0013: PR-creation paths used to hardcode `main`, which 404s
    on repos like PSG (Planes-Sales-Global-AI) whose defaultBranch is `master`.
    This helper reads `defaultBranch` from `.mso/config/projects.json`.

    Resolution order:
      1. If project_acronym given → look it up directly
      2. Else if target_repo given → scan registry for a project whose
         `repo` matches (handles both bare "Maestro" and qualified
         "tavisbasing/Maestro" forms)
      3. Fall back to `main`

    Same pattern as BUG-0007's fix in `ensure_voyage_branch_exists`.
    """
    # Path 1: explicit project acronym
    try:
        if project_acronym:
            project_info = load_project_config(project_acronym)
            if project_info:
                branch = project_info.get("defaultBranch") or ""
                if branch:
                    return branch
    except Exception:
        pass

    # Path 2: reverse lookup by target_repo
    try:
        if target_repo:
            admiralty_dir = get_workspace_dir()
            projects_file = admiralty_dir / "config" / "projects.json"
            if projects_file.exists():
                registry = json.loads(projects_file.read_text(encoding='utf-8'))
                for _acronym, info in (registry.get("projects") or {}).items():
                    repo_value = info.get("repo", "")
                    # Match both bare and qualified slug forms
                    if repo_value == target_repo:
                        branch = info.get("defaultBranch") or ""
                        if branch:
                            return branch
                    # Tail of slug match (e.g. registry has "PlaneSales/PSG-AI",
                    # target_repo is just "PSG-AI")
                    if "/" in repo_value and repo_value.split("/", 1)[-1] == target_repo:
                        branch = info.get("defaultBranch") or ""
                        if branch:
                            return branch
    except Exception:
        pass

    # Path 3: fall back
    return "main"


def _load_workspace_org(project_acronym: str = None) -> str:
    """Load the GitHub org name from workspace.json or project registry.

    v4.0: reads `defaultGitHubOrg` from workspace.json. In multi-project mode,
    the project registry `org` field takes precedence. Raises ConfigurationError
    if no org is resolvable — callers must not fall back to a hardcoded default.
    """
    ws_file = get_workspace_dir() / "config" / "workspace.json"
    try:
        data = json.loads(ws_file.read_text(encoding='utf-8'))
        mode = data.get("mode", "single-project")
    except Exception:
        data = {}
        mode = "single-project"

    # In multi-project mode, check project registry first
    if mode == "multi-project":
        project_info = load_project_config(project_acronym)
        if project_info and project_info.get("org"):
            return project_info["org"]

    # Read defaultGitHubOrg (v4.0) or legacy 'org' field
    org = data.get("defaultGitHubOrg") or data.get("org")
    if not org:
        raise ValueError(
            "No GitHub org configured. Set `defaultGitHubOrg` in "
            f"{ws_file} and restart the dispatcher."
        )
    return org


_PLACEHOLDER_ORG = "your-org"
_PLACEHOLDER_REPO_PREFIX = "your-org/"


def validate_placeholder_repo_config() -> list[str]:
    """Return a list of human-readable errors if any placeholder repo config is detected.

    Checks:
      - workspace.json  defaultGitHubOrg (None / "your-org")
      - projects.json   <project>.repo   ("your-org/...")
      - projects.json   <project>.org    ("your-org")

    Returns an empty list when config looks real.  Callers raise / print as
    appropriate — this function only detects, it does not abort.
    """
    errors: list[str] = []

    ws_file = get_workspace_dir() / "config" / "workspace.json"
    try:
        ws_data = json.loads(ws_file.read_text(encoding="utf-8"))
    except Exception:
        ws_data = {}

    org_val = ws_data.get("defaultGitHubOrg")
    if not org_val or str(org_val).strip().lower() in ("null", _PLACEHOLDER_ORG, "none", ""):
        errors.append(
            f"workspace.json 'defaultGitHubOrg' is still the placeholder {org_val!r}. "
            f"Set it to your real GitHub organisation (e.g. \"my-org\")."
        )

    projects_file = get_workspace_dir() / "config" / "projects.json"
    if projects_file.exists():
        try:
            proj_data = json.loads(projects_file.read_text(encoding="utf-8"))
            projects = proj_data.get("projects", {})
            for proj_key, proj_cfg in projects.items():
                repo_val = proj_cfg.get("repo", "")
                if repo_val.startswith(_PLACEHOLDER_REPO_PREFIX) or repo_val == "":
                    errors.append(
                        f"projects.json[{proj_key!r}].repo is still the placeholder {repo_val!r}. "
                        f"Set it to <github-org>/<repo> (e.g. \"my-org/my-repo\")."
                    )
                org_proj = proj_cfg.get("org", "")
                if org_proj == _PLACEHOLDER_ORG or org_proj == "":
                    errors.append(
                        f"projects.json[{proj_key!r}].org is still the placeholder {org_proj!r}. "
                        f"Set it to your real GitHub organisation (e.g. \"my-org\")."
                    )
        except Exception:
            pass

    return errors


def load_completion_config() -> dict:
    """Load the ``completion`` block from workspace.json with safe defaults.

    Returns a dict with keys:
      idleWatchdog: {enabled, idleMinutes, action}
      onVoyageComplete: {archiveVoyageOnMerge, archiveOrders, autoRelease}

    Defaults (when the ``completion`` block is absent) ENABLE the new housekeeping
    behaviours — idleWatchdog.enabled=True (action=cleanup, idleMinutes=30) and
    onVoyageComplete.archiveVoyageOnMerge=True / archiveOrders=True. This is
    intentional (FTR-MSO-2026-0203): auto voyage-completion housekeeping is on by
    default. To restore the pre-FTR-0203 behaviour (dispatcher never self-exits on
    idle; no archive-on-merge), set those keys to false in the workspace.json
    ``completion`` block. autoRelease stays opt-in (default False).
    """
    ws_file = get_workspace_dir() / "config" / "workspace.json"
    try:
        data = json.loads(ws_file.read_text(encoding='utf-8'))
        raw = data.get("completion", {})
    except Exception:
        raw = {}

    watchdog = raw.get("idleWatchdog", {})
    on_complete = raw.get("onVoyageComplete", {})
    # FTR-MSO-2026-0287 (R1): voyage-PR draft + promote-on-finalisation.
    voyage_pr = raw.get("voyagePr", {})
    # BUG-MSO-2026-0268: per-op timeout for convergence git network ops (seconds).
    # CLI --convergence-timeout takes precedence over workspace.json.
    if _CONVERGENCE_TIMEOUT_CLI_OVERRIDE is not None:
        convergence_timeout = _CONVERGENCE_TIMEOUT_CLI_OVERRIDE
    else:
        convergence_timeout = int(raw.get("convergenceNetworkTimeout", 60))

    return {
        "idleWatchdog": {
            "enabled": watchdog.get("enabled", True),
            "idleMinutes": watchdog.get("idleMinutes", 30),
            "action": watchdog.get("action", "cleanup"),
        },
        "onVoyageComplete": {
            "archiveVoyageOnMerge": on_complete.get("archiveVoyageOnMerge", True),
            "archiveOrders": on_complete.get("archiveOrders", True),
            "autoRelease": on_complete.get("autoRelease", False),
        },
        # FTR-MSO-2026-0287 (R1): create the voyage PR as a draft (no CI on
        # intermediate convergence pushes) and promote it to ready-for-review
        # only when the voyage finalises (all orders complete). Defaults ON so
        # CI spend is bounded out-of-the-box; set draft=false to restore the
        # pre-0287 per-push-CI behaviour.
        "voyagePr": {
            "draft": voyage_pr.get("draft", True),
            "promoteOnFinalisation": voyage_pr.get("promoteOnFinalisation", True),
        },
        # BUG-MSO-2026-0285: optional per-ROLE default iteration timeout (minutes),
        # keyed by role code (PLN/BLD/TST/...). Used when an order has no explicit
        # timeoutMinutes. Empty = fall back to the global --timeout for every role.
        "roleTimeouts": raw.get("roleTimeouts", {}) if isinstance(raw.get("roleTimeouts", {}), dict) else {},
        "convergenceNetworkTimeout": convergence_timeout,
    }


def resolve_order_timeout(order_data: dict, global_timeout: int) -> int:
    """BUG-MSO-2026-0285: resolve the per-iteration timeout (minutes) for an order.

    The global ``--timeout`` is a CEILING, not a fixed wait — a 2-minute DOC order
    and a 40-minute docker+integration order should not share one number. Resolution
    order (first that yields a positive int wins):

        order.timeoutMinutes  >  completion.roleTimeouts[role]  >  global --timeout

    A non-numeric / non-positive override is ignored (falls through), so a config
    typo can never produce a 0/negative timeout that would insta-kill the crew.
    """
    # 1. order-level override
    ot = order_data.get("timeoutMinutes")
    if ot is not None:
        try:
            v = int(ot)
            if v > 0:
                return v
        except (TypeError, ValueError):
            pass
    # 2. per-role default from workspace config
    role = order_data.get("targetRole") or order_data.get("role")
    if role:
        try:
            rt = load_completion_config().get("roleTimeouts", {}).get(role)
            if rt is not None:
                v = int(rt)
                if v > 0:
                    return v
        except (TypeError, ValueError, Exception):
            pass
    # 3. global ceiling
    return global_timeout


def load_verify_config() -> dict:
    """Load the optional local-verify gate config from workspace.json.

    FTR-MSO-2026-0287 (R2). Returns ``{"command": str, "timeoutMinutes": int}``.
    ``command`` is a freeform shell command (e.g. ``dotnet build src/X.sln -c
    Release`` or ``python -m pytest -q``) run in the crew worktree BEFORE the
    convergence push. An empty command (the default) disables the gate entirely,
    so projects that don't configure it keep today's behaviour. This is the
    "only push/CI when the local build passes" guarantee.
    """
    ws_file = get_workspace_dir() / "config" / "workspace.json"
    try:
        data = json.loads(ws_file.read_text(encoding='utf-8'))
    except Exception:
        data = {}
    # Copilot (PR #140): guard a non-numeric verifyTimeoutMinutes (e.g. "5m",
    # null) so a config typo falls back to the default instead of raising into
    # process_crew_completion's convergence try/except and mis-escalating the
    # order as CONVERGENCE_FAILED.
    try:
        timeout = int(data.get("verifyTimeoutMinutes", 20))
    except (TypeError, ValueError):
        timeout = 20
    return {
        "command": (data.get("verifyCommand") or "").strip(),
        "timeoutMinutes": timeout,
    }


def run_verify_gate(worktree: "Path", command: str,
                    timeout_minutes: int = 20) -> tuple:
    """Run the project verify command in ``worktree`` (FTR-MSO-2026-0287 R2).

    Returns ``(ok: bool, detail: str)``. ``ok`` is True when the command exits 0
    (or when ``command`` is empty — gate disabled). On failure the detail carries
    the exit code plus a tail of stdout/stderr for the lifecycle event. Never
    raises — a launch/timeout problem is reported as ``ok=False`` so the caller
    can hold the order rather than crash the dispatcher.
    """
    if not command:
        return True, "no verifyCommand configured (gate disabled)"
    try:
        proc = subprocess.run(
            command, shell=True, cwd=str(worktree),
            capture_output=True, text=True, timeout=max(1, timeout_minutes) * 60,
        )
    except subprocess.TimeoutExpired:
        return False, f"verifyCommand timed out after {timeout_minutes}m"
    except Exception as exc:  # pragma: no cover - defensive
        return False, f"verifyCommand failed to launch: {exc}"
    if proc.returncode == 0:
        return True, "verify passed"
    tail = ((proc.stdout or "")[-1200:] + (proc.stderr or "")[-1200:]).strip()
    return False, f"verifyCommand exit {proc.returncode}: ...{tail}"


def promote_voyage_pr_ready(voyage: dict) -> bool:
    """Promote a voyage's draft PR to ready-for-review (FTR-MSO-2026-0287 R1).

    Called when a voyage finalises (all orders complete). Runs ``gh pr ready
    <branch>`` so the single end-of-voyage CI run fires before merge review. A
    no-op (returns False) when draft mode or promote-on-finalisation is disabled,
    or when the voyage has no resolvable branch/repo. Never raises.

    Copilot (PR #140): promotes the PR on EVERY repo in ``targetRepos`` (a voyage
    may target several repos, each with its own PR via create_pr_for_crew) so no
    repo's PR is left draft forever. Returns True if at least one was promoted.
    """
    try:
        cfg = load_completion_config().get("voyagePr", {})
        if not (cfg.get("draft", True) and cfg.get("promoteOnFinalisation", True)):
            return False
        branch = (voyage.get("branch") or "").replace("refs/heads/", "")
        repos = voyage.get("targetRepos") or []
        if not branch or not repos:
            return False
        project = voyage.get("project") or ""
        org = _load_workspace_org(project)
        vid = voyage.get("voyageId") or voyage.get("id") or branch
        promoted_any = False
        for repo in repos:
            full_repo = _resolve_full_repo_slug(repo, org)
            result = subprocess.run(
                ["gh", "pr", "ready", branch, "--repo", full_repo],
                capture_output=True, text=True, timeout=30,
            )
            if result.returncode == 0:
                write_lifecycle_event(
                    "PR",
                    f"Voyage {vid}: promoted PR to ready-for-review on finalisation "
                    f"({repo}@{branch})"
                )
                promoted_any = True
            else:
                write_lifecycle_event(
                    "WARN",
                    f"Voyage {vid}: gh pr ready failed for {repo}@{branch}: "
                    f"{(result.stderr or '').strip()[:150]}"
                )
        return promoted_any
    except Exception as exc:  # pragma: no cover - defensive
        write_lifecycle_event(
            "WARN",
            f"Voyage PR promote-on-finalisation error: {exc}"
        )
        return False


# BUG-MSO-2026-0292: statuses that legitimately mean "this order is done" and may
# be swept to orders/complete/ when its voyage's PR is merged. Anything else
# (PENDING / IN_PROGRESS / BACKLOG / NAV_REVIEW_PENDING / STALLED / ...) is an order
# that did NOT complete — reconcile must NOT fabricate its completion.
_RECONCILE_COMPLETE_STATUSES = {"COMPLETE", "COMPLETED"}


def _reconcile_archive_order(order_file: "Path", vid: str, order_id: str) -> bool:
    """Archive a voyage's order to orders/complete/ on PR-merge — ONLY if it
    already reached a completion status (BUG-MSO-2026-0292).

    A merged voyage PR does NOT mean every order in the manifest ran: a voyage can
    list orders that never dispatched (no crew, no metadata). The pre-0292 reconcile
    blindly stamped status=COMPLETE on every listed order and moved it — fabricating
    completion of work that never happened. Now: only an order already COMPLETE/
    COMPLETED is archived; any non-complete order is left in place with a loud WARN.
    Returns True if archived.
    """
    try:
        odata = json.loads(order_file.read_text(encoding="utf-8"))
    except Exception:
        return False
    st = str(odata.get("status") or "").upper()
    if st not in _RECONCILE_COMPLETE_STATUSES:
        write_lifecycle_event(
            "WARN",
            f"reconcile: voyage {vid} PR merged but order {order_id} is "
            f"status={st or 'UNKNOWN'} (not COMPLETE) — NOT archived / NOT marked "
            f"complete (would fabricate completion of an order that didn't run). "
            f"Left in place for investigation. (BUG-MSO-2026-0292)"
        )
        return False
    try:
        dest_o = get_workspace_dir() / "orders" / "complete" / order_file.name
        dest_o.parent.mkdir(parents=True, exist_ok=True)
        dest_o.write_text(json.dumps(odata, indent=2), encoding="utf-8")
        order_file.unlink()
        return True
    except Exception:
        return False


def reconcile_merged_voyages(
    on_complete_cfg: Optional[dict] = None,
    dry_run: bool = False,
    voyage_id_filter: Optional[str] = None,
) -> int:
    """Reconcile active voyages whose PR has been merged.

    Scans ``.mso/voyages/active/*.json``. For each voyage, resolves its branch
    PR via ``gh pr view``. If the PR is merged and ``archiveVoyageOnMerge`` is
    True:
      - Marks voyage COMPLETED with mergedPR/mergeCommit/mergedAt metadata
      - git-moves the JSON active/ -> complete/
      - Optionally sweeps order JSONs (orders/active -> orders/complete) and
        prompt files (prompts/active -> prompts/complete)

    Returns count of voyages archived (or, in dry-run, the count that WOULD be
    archived — no files are moved).
    Safe when ``gh`` is unavailable (skips with a WARN lifecycle event).
    Idempotent: voyages already in complete/ are ignored.
    """
    if on_complete_cfg is None:
        on_complete_cfg = load_completion_config()["onVoyageComplete"]

    archive_voyage = on_complete_cfg.get("archiveVoyageOnMerge", True)
    archive_orders = on_complete_cfg.get("archiveOrders", True)

    if not archive_voyage:
        return 0

    ws = get_workspace_dir()
    active_dir = ws / "voyages" / "active"
    complete_dir = ws / "voyages" / "complete"
    if not active_dir.exists():
        return 0

    complete_dir.mkdir(parents=True, exist_ok=True)

    archived = 0
    for voyage_file in sorted(active_dir.glob("*.json")):
        try:
            voyage = json.loads(voyage_file.read_text(encoding="utf-8"))
        except Exception:
            continue

        vid = voyage.get("id", voyage_file.stem)
        if voyage_id_filter and vid != voyage_id_filter:
            continue

        branch = voyage.get("branch", "")
        if not branch:
            continue

        # Check PR state via gh
        try:
            gh_result = subprocess.run(
                ["gh", "pr", "view", branch, "--json",
                 "state,mergeCommit,mergedAt,number,mergeable"],
                capture_output=True, text=True, timeout=30,
                cwd=str(ws.parent),  # repo root — so gh resolves the repo even when invoked from elsewhere
            )
            if gh_result.returncode != 0:
                # No PR found — skip (not an error)
                continue
            pr_data = json.loads(gh_result.stdout)
        except FileNotFoundError:
            write_lifecycle_event("WARN", "reconcile_merged_voyages: gh not available — skipping")
            return archived
        except Exception as exc:
            write_lifecycle_event("WARN", f"reconcile_merged_voyages: gh call failed for {vid}: {exc}")
            continue

        if pr_data.get("state") != "MERGED":
            # BUG-MSO-2026-0292/0290: an OPEN voyage PR that has gone CONFLICTING
            # is silently CI-dead — GitHub won't run pull_request CI on a PR whose
            # merge commit can't be computed, so a finished voyage can sit with an
            # unverifiable PR and no signal. Surface it (deduped via the voyage JSON
            # so we don't WARN every reconcile tick).
            if pr_data.get("state") == "OPEN" and pr_data.get("mergeable") == "CONFLICTING":
                if voyage.get("prConflictWarned") != pr_data.get("number"):
                    write_lifecycle_event(
                        "WARN",
                        f"Voyage {vid} PR #{pr_data.get('number')} is CONFLICTING — "
                        f"GitHub will not run its CI until the conflict is resolved "
                        f"(merge main into the voyage branch). (BUG-MSO-2026-0290)"
                    )
                    try:
                        voyage["prConflictWarned"] = pr_data.get("number")
                        voyage_file.write_text(json.dumps(voyage, indent=2), encoding="utf-8")
                    except Exception:
                        pass
            continue

        merge_commit = (pr_data.get("mergeCommit") or {}).get("oid", "")
        merged_at = pr_data.get("mergedAt", "")
        pr_number = pr_data.get("number")

        if dry_run:
            print_info(f"[dry-run] Would archive merged voyage {vid} (PR #{pr_number}, merged {merged_at})")
            archived += 1  # count would-be archives so the CLI's "N would be archived" is accurate
            continue

        # Update voyage JSON with merge metadata
        voyage["status"] = "COMPLETED"
        voyage["mergedPR"] = pr_number
        voyage["mergeCommit"] = merge_commit
        voyage["mergedAt"] = merged_at
        voyage["completedAt"] = datetime.now().isoformat()

        dest = complete_dir / voyage_file.name
        try:
            dest.write_text(json.dumps(voyage, indent=2), encoding="utf-8")
            voyage_file.unlink()
            write_lifecycle_event("COMPLETE",
                f"Reconcile archived merged voyage {vid} (PR #{pr_number})")
            archived += 1
        except Exception as exc:
            write_lifecycle_event("WARN", f"reconcile: failed to archive {vid}: {exc}")
            continue

        if not archive_orders:
            continue

        # Sweep order JSONs and prompt files
        order_ids: List[str] = []
        for order_ref in voyage.get("orders", []):
            if isinstance(order_ref, str):
                order_ids.append(order_ref)
            elif isinstance(order_ref, dict):
                oid = order_ref.get("orderId") or order_ref.get("id")
                if oid:
                    order_ids.append(oid)

        # Same queue set scan_all_queues() searches — including defects/breakdown/
        # high-level and every requests/<category>/ subdir. NOT escalations (those
        # aren't order files).
        queue_dirs = [ws / "queues" / q for q in
                      ("explicit", "security", "bugs", "orders",
                       "defects", "breakdown", "high-level")]
        requests_root = ws / "queues" / "requests"
        if requests_root.exists():
            queue_dirs += [d for d in requests_root.iterdir() if d.is_dir()]
        for queue_dir in queue_dirs:
            if not queue_dir.exists():
                continue
            for order_id in order_ids:
                order_file = queue_dir / f"{order_id}.json"
                if order_file.exists():
                    # BUG-MSO-2026-0292: only archive if already complete.
                    _reconcile_archive_order(order_file, vid, order_id)

        for order_id in order_ids:
            f = ws / "orders" / "active" / f"{order_id}.json"
            if f.exists():
                # BUG-MSO-2026-0292: only archive if already complete.
                _reconcile_archive_order(f, vid, order_id)

            # Prompt sweep — prompts are generated as {order_id}-{role}.md
            # (generate_prompt_for_item), so move ALL files for this order id, not
            # just a bare {order_id}.md (which never exists).
            prompts_active = ws / "prompts" / "active"
            if prompts_active.exists():
                matches = list(prompts_active.glob(f"{order_id}-*.md")) + \
                          list(prompts_active.glob(f"{order_id}.md"))
                for prompt_src in matches:
                    try:
                        dest_p = ws / "prompts" / "complete" / prompt_src.name
                        dest_p.parent.mkdir(parents=True, exist_ok=True)
                        prompt_src.replace(dest_p)  # BUG-MSO-2026-0291: overwrite-safe
                    except Exception:
                        pass

    return archived


def ensure_voyage_branch_exists(
    target_repo: str,
    voyage_branch: str,
    project_acronym: str = "",
) -> bool:
    """Ensure the voyage branch exists on the remote for the target repo.

    v8.12: Auto-creates voyage branches before crew dispatch.
    BUG-ADM-2026-0007 (v2.5.5): reads `defaultBranch` from the project
    registry (e.g. 'master' for PSG) instead of hardcoding 'main'. Caches
    failures so a missing default branch doesn't storm `gh api` on every
    dispatcher loop. Logs structured lifecycle events for every failure.

    Uses `gh api` to check and create branches — no local clone needed.

    Returns True if the branch exists (or was created), False on error.
    """
    if not target_repo or not voyage_branch:
        return True  # Nothing to do

    cache_key = f"{target_repo}:{voyage_branch}"
    if cache_key in _VERIFIED_VOYAGE_BRANCHES:
        return True  # Already verified this session
    if cache_key in _FAILED_VOYAGE_BRANCHES:
        # BUG-ADM-2026-0007: don't re-attempt failed branch ops every dispatcher
        # tick. The cached error gives the human operator something to act on.
        return False

    # BUG-ADM-2026-0007: resolve org + defaultBranch from the project registry
    # so single-project workspaces with non-main default branches (e.g. PSG on
    # 'master') don't 404 when looking up the default branch SHA.
    try:
        org = _load_workspace_org(project_acronym)
    except ValueError as exc:
        detail = str(exc)
        _FAILED_VOYAGE_BRANCHES[cache_key] = detail
        print_warn(
            f"Branch ensure failed for {target_repo}@{voyage_branch}: {detail}\n"
            f"  This failure is cached — re-attempts are suppressed until restart.\n"
            f"  Resolve manually and restart the dispatcher."
        )
        return False
    default_branch = "main"
    try:
        project_info = load_project_config(project_acronym) if project_acronym else None
        if project_info:
            default_branch = project_info.get("defaultBranch") or "main"
    except Exception:
        pass  # Best-effort — fall back to defaults

    full_repo = _resolve_full_repo_slug(target_repo, org)
    branch_ref = voyage_branch.replace("refs/heads/", "")

    def _record_failure(detail: str) -> bool:
        """Cache + log a structured failure so the operator can diagnose."""
        _FAILED_VOYAGE_BRANCHES[cache_key] = detail
        print_warn(
            f"Branch ensure failed for {full_repo}@{branch_ref}: {detail}\n"
            f"  This failure is cached — re-attempts are suppressed until restart.\n"
            f"  Resolve manually (push the branch, fix gh auth, fix project config) and restart the dispatcher."
        )
        try:
            write_lifecycle_event(
                "BRANCH_FAIL",
                f"{full_repo}@{branch_ref} (project={project_acronym or 'unknown'}, "
                f"default={default_branch}): {detail}"
            )
        except Exception:
            pass
        return False

    try:
        # Check if branch already exists
        result = subprocess.run(
            ["gh", "api", f"repos/{full_repo}/branches/{branch_ref}",
             "--jq", ".name"],
            capture_output=True, text=True, timeout=30
        )

        if result.returncode == 0 and result.stdout.strip():
            _VERIFIED_VOYAGE_BRANCHES.add(cache_key)
            return True

        # Branch doesn't exist — get the SHA of the project's default branch
        sha_result = subprocess.run(
            ["gh", "api", f"repos/{full_repo}/git/refs/heads/{default_branch}",
             "--jq", ".object.sha"],
            capture_output=True, text=True, timeout=30
        )

        if sha_result.returncode != 0 or not sha_result.stdout.strip():
            stderr = sha_result.stderr.strip() or "no SHA returned"
            return _record_failure(
                f"could not resolve default branch '{default_branch}' SHA — {stderr[:200]}"
            )

        default_sha = sha_result.stdout.strip()

        # Create the branch
        create_result = subprocess.run(
            ["gh", "api", f"repos/{full_repo}/git/refs",
             "-f", f"ref=refs/heads/{branch_ref}",
             "-f", f"sha={default_sha}"],
            capture_output=True, text=True, timeout=30
        )

        if create_result.returncode == 0:
            print_ok(f"Created voyage branch '{branch_ref}' on {target_repo} (from {default_branch})")
            try:
                write_lifecycle_event(
                    "BRANCH_CREATE",
                    f"{full_repo}@{branch_ref} created from {default_branch} "
                    f"(project={project_acronym or 'unknown'})"
                )
            except Exception:
                pass
            _VERIFIED_VOYAGE_BRANCHES.add(cache_key)
            return True
        else:
            return _record_failure(
                f"branch creation failed — {create_result.stderr.strip()[:200]}"
            )

    except subprocess.TimeoutExpired:
        return _record_failure("timeout calling gh api (network or auth issue)")
    except Exception as e:
        return _record_failure(f"unexpected error — {type(e).__name__}: {e}")


# =============================================================================
# v2.0.0: MANAGED REPO LIFECYCLE
# =============================================================================

def _robust_rmtree(path: Path, label: str = "", retries: int = 3, backoff: float = 2.0) -> bool:
    """Remove a directory tree robustly on Windows.

    v2.0.1: Handles Windows-specific issues:
    - Git marks .git/objects/ files read-only — clear the flag before removal
    - NTFS file handles linger after process kill — retry with exponential backoff
    - Falls back to 'rd /s /q' as a last resort on Windows
    Returns True if directory was removed, False otherwise.
    """
    import shutil as _shutil
    import stat

    if not path.exists():
        return True

    def _on_rm_error(func, fpath, exc_info):
        """Error handler: clear read-only flag and retry."""
        try:
            os.chmod(fpath, stat.S_IWRITE)
            func(fpath)
        except Exception:
            pass

    for attempt in range(retries):
        _shutil.rmtree(str(path), onerror=_on_rm_error)
        if not path.exists():
            return True
        wait = backoff * (attempt + 1)
        if label:
            print_info(f"{label}: Retry {attempt + 1}/{retries} — waiting {wait:.0f}s for NTFS handles...")
        time.sleep(wait)

    # Last resort on Windows: rd /s /q handles more edge cases than Python
    if os.name == 'nt' and path.exists():
        try:
            subprocess.run(
                ['cmd', '/c', 'rd', '/s', '/q', str(path)],
                capture_output=True, timeout=30
            )
        except Exception:
            pass

    return not path.exists()


def prepare_crew_repo(crew_num: int, target_repo: str, voyage_branch: str) -> Optional[Path]:
    """DEPRECATED (FTR-ADM-2026-0149): use prepare_voyage_worktree() instead.

    Kept functional for backwards compatibility with legacy callers (custom
    dispatchers, third-party scripts). Emits LEGACY_CREW_CLONE lifecycle event
    when invoked so operators can migrate.

    Returns Path to crew repo dir, or None on failure (crew self-manages as fallback).
    """
    try:
        write_lifecycle_event(
            "LEGACY_CREW_CLONE",
            f"prepare_crew_repo() called for crew {crew_num} / {target_repo} — "
            "this function is deprecated. Use prepare_voyage_worktree() instead."
        )
    except Exception:
        pass
    if not target_repo:
        return None

    crew_dir = get_crew_dir(crew_num)
    repo_dir = crew_dir / "repo"
    org = _load_workspace_org()

    # Load clone protocol from workspace config
    ws_file = get_workspace_dir() / "config" / "workspace.json"
    try:
        ws_data = json.loads(ws_file.read_text(encoding='utf-8'))
        protocol = ws_data.get("cloneProtocol", "ssh")
    except Exception:
        protocol = "ssh"

    if protocol == "ssh":
        clone_url = f"git@github.com:{org}/{target_repo}.git"
    else:
        clone_url = f"https://github.com/{org}/{target_repo}.git"

    branch_ref = voyage_branch.replace("refs/heads/", "")

    try:
        # Step 1: Clean existing repo if present
        if repo_dir.exists():
            print_info(f"Crew {crew_num}: Cleaning existing repo clone...")
            if not _robust_rmtree(repo_dir, label=f"Crew {crew_num}"):
                print_warn(f"Crew {crew_num}: Could not remove {repo_dir} — file locks?")
                return None

        # Step 2: Clone directly onto the voyage branch
        print_info(f"Crew {crew_num}: Cloning {target_repo} (branch: {branch_ref})...")
        clone_result = subprocess.run(
            ["git", "clone", "--branch", branch_ref, "--single-branch",
             clone_url, str(repo_dir)],
            capture_output=True, text=True, timeout=120
        )

        if clone_result.returncode != 0:
            # Voyage branch may have no commits yet — clone main, then checkout
            print_info(f"Crew {crew_num}: Direct branch clone failed, trying main + checkout...")
            clone_result = subprocess.run(
                ["git", "clone", clone_url, str(repo_dir)],
                capture_output=True, text=True, timeout=120
            )
            if clone_result.returncode != 0:
                print_warn(f"Crew {crew_num}: Clone failed: {clone_result.stderr.strip()[:200]}")
                return None

            # Checkout voyage branch (tracking remote)
            checkout_result = subprocess.run(
                ["git", "checkout", "-B", branch_ref, f"origin/{branch_ref}"],
                capture_output=True, text=True, timeout=30,
                cwd=str(repo_dir)
            )
            if checkout_result.returncode != 0:
                # Branch exists remote but no tracking — create local from current HEAD
                subprocess.run(
                    ["git", "checkout", "-b", branch_ref],
                    capture_output=True, text=True, timeout=30,
                    cwd=str(repo_dir)
                )

        # Step 3: Verify correct branch
        branch_check = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True, text=True, timeout=10,
            cwd=str(repo_dir)
        )
        current_branch = branch_check.stdout.strip()
        if current_branch != branch_ref:
            print_warn(f"Crew {crew_num}: Expected branch '{branch_ref}', got '{current_branch}'")

        print_ok(f"Crew {crew_num}: Repo ready (branch: {current_branch})")
        write_lifecycle_event("REPO", f"Crew {crew_num}: {target_repo} cloned on {branch_ref}")
        return repo_dir

    except subprocess.TimeoutExpired:
        print_warn(f"Crew {crew_num}: Clone timed out for {target_repo}")
        return None
    except Exception as e:
        print_warn(f"Crew {crew_num}: Repo preparation failed: {e}")
        return None


def verify_and_push_crew_work(crew_num: int, target_repo: str, voyage_branch: str) -> Dict[str, Any]:
    """Post-completion: verify commits were pushed, commit+push any uncommitted work.

    v2.0.0: Runs after crew process exits. Returns verification report.

    DEPRECATED (BUG-MSO-2026-0284): this targets the legacy pre-worktree path
    ``get_crew_dir(crew_num)/'repo'`` and has NO production call sites — it does
    not run in the current worktree-based dispatch model. The live equivalent is
    ``maestro.core.worktrees.commit_crew_worktree_if_dirty()``, called from
    ``process_crew_completion`` before convergence. Retained only because
    ``tests/test_verify_and_push_branch_guard.py`` (BUG-MSO-2026-0241) exercises
    its branch-safety check; do not wire it back in without re-pointing it at the
    crew worktree.
    """
    repo_dir = get_crew_dir(crew_num) / "repo"
    report = {"pushed": False, "commits_ahead": 0,
              "uncommitted_committed": False, "error": None}

    if not repo_dir.exists() or not (repo_dir / ".git").exists():
        report["error"] = f"No repo found at {repo_dir}"
        return report

    branch_ref = voyage_branch.replace("refs/heads/", "")

    try:
        # BUG-MSO-2026-0241: assert the repo is on the voyage branch before touching it.
        # verify_and_push_crew_work runs as dispatcher Python code (not via Claude's Bash
        # tool), so the branch_guard pretool hook does NOT intercept it.  Without this
        # check, if repo_dir happened to be on main, auto-commit would push to main.
        head_result = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True, text=True, timeout=10,
            cwd=str(repo_dir)
        )
        if head_result.returncode != 0 or head_result.stdout.strip() != branch_ref:
            actual_branch = head_result.stdout.strip() if head_result.returncode == 0 else "<unknown>"
            report["error"] = (
                f"Branch safety check failed: repo at {repo_dir} is on "
                f"`{actual_branch}`, not voyage branch `{branch_ref}`. "
                "Refusing auto-commit/push to prevent main contamination."
            )
            print_warn(f"Crew {crew_num}: {report['error']}")
            return report

        # Step 1: Check for uncommitted changes
        status = subprocess.run(
            ["git", "status", "--porcelain"],
            capture_output=True, text=True, timeout=30,
            cwd=str(repo_dir)
        )

        if status.stdout.strip():
            print_info(f"Crew {crew_num}: Found uncommitted changes, auto-committing...")
            subprocess.run(
                ["git", "add", "-A"],
                capture_output=True, text=True, timeout=30,
                cwd=str(repo_dir)
            )
            commit_result = subprocess.run(
                ["git", "commit", "-m",
                 f"[fleet] Auto-commit uncommitted work from Crew {crew_num}"],
                capture_output=True, text=True, timeout=30,
                cwd=str(repo_dir)
            )
            if commit_result.returncode == 0:
                report["uncommitted_committed"] = True
                print_ok(f"Crew {crew_num}: Uncommitted changes committed")

        # Step 2: Fetch remote state and check for unpushed commits
        subprocess.run(
            ["git", "fetch", "origin", branch_ref],
            capture_output=True, text=True, timeout=60,
            cwd=str(repo_dir)
        )

        ahead = subprocess.run(
            ["git", "rev-list", "--count", f"origin/{branch_ref}..HEAD"],
            capture_output=True, text=True, timeout=15,
            cwd=str(repo_dir)
        )

        commits_ahead = 0
        if ahead.returncode == 0:
            try:
                commits_ahead = int(ahead.stdout.strip())
            except ValueError:
                pass

        report["commits_ahead"] = commits_ahead

        if commits_ahead > 0:
            print_info(f"Crew {crew_num}: {commits_ahead} unpushed commit(s), pushing...")
            push_result = subprocess.run(
                ["git", "push", "origin", branch_ref],
                capture_output=True, text=True, timeout=120,
                cwd=str(repo_dir)
            )
            if push_result.returncode == 0:
                report["pushed"] = True
                print_ok(f"Crew {crew_num}: Pushed {commits_ahead} commit(s) to {target_repo}/{branch_ref}")
                write_lifecycle_event("REPO",
                    f"Crew {crew_num}: Pushed {commits_ahead} commit(s) to {target_repo}/{branch_ref}")
            else:
                report["error"] = f"Push failed: {push_result.stderr.strip()[:200]}"
                print_warn(f"Crew {crew_num}: {report['error']}")
        else:
            report["pushed"] = True  # Nothing to push = success

        return report

    except subprocess.TimeoutExpired:
        report["error"] = "Git operation timed out"
        return report
    except Exception as e:
        report["error"] = str(e)
        return report


def create_pr_for_crew(crew_num: int, target_repo: str, voyage_branch: str,
                       order_id: str, order_title: str,
                       project_acronym: str = "") -> Optional[str]:
    """Create or update a PR for the crew's completed work.

    v2.0.0: Called immediately when each crew completes.
    If PR already exists, adds a comment. Otherwise creates a new PR.
    Returns PR URL on success, None on failure.

    BUG-ADM-2026-0013: project_acronym threaded through so the base branch
    can be resolved from the project registry (`master` for PSG, `main` for
    framework). Falls back to `main` if registry missing.
    """
    if not target_repo or not voyage_branch:
        return None

    org = _load_workspace_org(project_acronym)
    full_repo = _resolve_full_repo_slug(target_repo, org)
    branch_ref = voyage_branch.replace("refs/heads/", "")
    default_branch = _get_default_branch_for_repo(target_repo, project_acronym)

    try:
        # Check if branch has commits ahead of the project's default branch
        compare = subprocess.run(
            ["gh", "api", f"repos/{full_repo}/compare/{default_branch}...{branch_ref}",
             "--jq", ".ahead_by"],
            capture_output=True, text=True, timeout=30
        )

        ahead_by = 0
        if compare.returncode == 0:
            try:
                ahead_by = int(compare.stdout.strip())
            except ValueError:
                pass

        if ahead_by == 0:
            print_info(f"Crew {crew_num}: No commits ahead of {default_branch} on {target_repo} — no PR needed")
            return None

        # Check for existing open PR
        pr_check = subprocess.run(
            ["gh", "pr", "list", "--repo", full_repo,
             "--head", branch_ref, "--state", "open",
             "--json", "number,url"],
            capture_output=True, text=True, timeout=30
        )

        if pr_check.returncode == 0 and pr_check.stdout.strip() not in ("", "[]"):
            prs = json.loads(pr_check.stdout)
            if prs:
                pr_number = prs[0]["number"]
                pr_url = prs[0]["url"]
                codename = _get_crew_name(crew_num)
                comment_body = f"Crew {crew_num} ({codename}) completed order `{order_id}`: {order_title}"
                subprocess.run(
                    ["gh", "pr", "comment", str(pr_number),
                     "--repo", full_repo, "--body", comment_body],
                    capture_output=True, text=True, timeout=30
                )
                print_ok(f"Crew {crew_num}: Commented on existing PR #{pr_number} for {target_repo}")
                return pr_url

        # No existing PR — create one
        orders = _SESSION_TARGET_REPOS.get(target_repo, [])
        body_lines = ["## Summary", ""]
        body_lines.append(f"Voyage branch `{branch_ref}` with {ahead_by} commit(s).")
        body_lines.append("")
        body_lines.append("### Orders Completed")
        for t in orders[:20]:
            body_lines.append(f"- {t}")
        body_lines.append("")
        body_lines.append("## Test plan")
        body_lines.append("- [ ] CI checks pass")
        body_lines.append("- [ ] Code review completed")

        pr_title = f"[{branch_ref}] {target_repo}"
        pr_body = "\n".join(body_lines)

        # FTR-MSO-2026-0287 (R1): create the voyage PR as a DRAFT so the
        # intermediate per-role convergence pushes don't re-trigger CI. The PR is
        # promoted to ready-for-review only when the voyage finalises (see the
        # all-orders-complete sweep). draft=false restores per-push CI.
        _use_draft = bool(load_completion_config().get("voyagePr", {}).get("draft", True))
        create_args = [
            "gh", "pr", "create",
            "--repo", full_repo,
            "--base", default_branch,
            "--head", branch_ref,
            "--title", pr_title,
            "--body", pr_body,
        ]
        if _use_draft:
            create_args.append("--draft")

        pr_result = subprocess.run(
            create_args, capture_output=True, text=True, timeout=60
        )

        # Some repos/plans don't permit draft PRs — fall back to a normal PR
        # rather than failing the finalisation.
        if (pr_result.returncode != 0 and _use_draft
                and "draft" in (pr_result.stderr or "").lower()):
            write_lifecycle_event(
                "WARN",
                f"Crew {crew_num}: draft PR not supported for {target_repo} — "
                f"retrying as a normal PR ({(pr_result.stderr or '').strip()[:120]})"
            )
            pr_result = subprocess.run(
                [a for a in create_args if a != "--draft"],
                capture_output=True, text=True, timeout=60
            )

        if pr_result.returncode == 0:
            pr_url = pr_result.stdout.strip()
            print_ok(f"Crew {crew_num}: PR created for {target_repo} -> {pr_url}")
            write_lifecycle_event("PR", f"Crew {crew_num}: PR created for {target_repo}: {pr_url}")
            return pr_url
        else:
            err = pr_result.stderr.strip()[:200]
            print_warn(f"Crew {crew_num}: PR creation failed for {target_repo}: {err}")
            write_lifecycle_event(
                "ERROR",
                f"Crew {crew_num}: PR creation failed for {target_repo}: {err}",
            )
            return None

    except subprocess.TimeoutExpired:
        print_warn(f"Crew {crew_num}: PR creation timed out for {target_repo}")
        write_lifecycle_event("ERROR", f"Crew {crew_num}: PR creation timed out for {target_repo}")
        return None
    except Exception as e:
        print_warn(f"Crew {crew_num}: PR creation error for {target_repo}: {e}")
        write_lifecycle_event("ERROR", f"Crew {crew_num}: PR creation error for {target_repo}: {e}")
        return None


def cleanup_crew_repo(crew_num: int):
    """Remove the crew's ephemeral repo clone after completion (legacy path).

    DEPRECATED (FTR-MSO-2026-0177): no-op in normal operation since crews run in worktrees.
    Kept callable for any legacy queue entries that used the per-crew clone path.
    """
    repo_dir = get_crew_dir(crew_num) / "repo"
    if repo_dir.exists():
        if _robust_rmtree(repo_dir, label=f"Crew {crew_num}"):
            print_info(f"Crew {crew_num}: Cleaned up ephemeral repo clone")
        else:
            print_warn(f"Crew {crew_num}: Failed to clean repo dir — will retry on next dispatch")


def reset_developer_repos():
    """Reset any repos/ checkouts back to their project's default branch.

    v2.0.0: Called at Eight Bells. Scans repos/ directory for any
    repos left on voyage branches and resets them to the resolved
    default branch (e.g. `master` for PSG, `main` for the framework).

    BUG-MSO-2026-0016 (v2.8.2): each repo's default branch is now
    resolved via `_get_default_branch_for_repo()` rather than hardcoded
    to `main`. Repos with a non-`main` default (PSG/master, anyone on
    develop/trunk) now reset to the correct branch.
    """
    repos_dir = get_base_dir() / "repos"
    if not repos_dir.exists():
        return

    reset_count = 0
    for repo_path in sorted(repos_dir.iterdir()):
        if not repo_path.is_dir() or not (repo_path / ".git").exists():
            continue

        try:
            branch = subprocess.run(
                ["git", "rev-parse", "--abbrev-ref", "HEAD"],
                capture_output=True, text=True, timeout=10,
                cwd=str(repo_path)
            )
            current = branch.stdout.strip()

            if current.startswith("voyage/"):
                # Check for uncommitted changes first
                status = subprocess.run(
                    ["git", "status", "--porcelain"],
                    capture_output=True, text=True, timeout=10,
                    cwd=str(repo_path)
                )
                if status.stdout.strip():
                    # Discard local changes (crew work should be in ephemeral clone)
                    subprocess.run(
                        ["git", "checkout", "--", "."],
                        capture_output=True, text=True, timeout=15,
                        cwd=str(repo_path)
                    )
                    subprocess.run(
                        ["git", "clean", "-fd"],
                        capture_output=True, text=True, timeout=15,
                        cwd=str(repo_path)
                    )

                repo_default_branch = _get_default_branch_for_repo(repo_path.name)
                result = subprocess.run(
                    ["git", "checkout", repo_default_branch],
                    capture_output=True, text=True, timeout=30,
                    cwd=str(repo_path)
                )
                if result.returncode == 0:
                    subprocess.run(
                        ["git", "pull", "--ff-only"],
                        capture_output=True, text=True, timeout=60,
                        cwd=str(repo_path)
                    )
                    reset_count += 1
        except Exception:
            continue

    if reset_count > 0:
        print_ok(f"Reset {reset_count} repo(s) in repos/ back to their default branch")


def _resolve_target_repo_from_project(data: dict) -> str:
    """Resolve targetRepo from order's project field via the project registry.

    v2.0.5: If an order has a 'project' field but no 'targetRepo', look up the
    repo name from the project registry.
    """
    project = data.get("project", "")
    if not project:
        return ""
    project_info = load_project_config(project)
    if project_info:
        return project_info.get("repo", "")
    return ""


def _get_target_repo_for_order(order_id: str) -> str:
    """Look up the targetRepo for an order from session tracking or queue files."""
    # Fast path: check session tracking (in-memory)
    for repo, orders in _SESSION_TARGET_REPOS.items():
        if any(order_id in o for o in orders):
            return repo

    # Fallback: scan queue files
    queues_dir = get_queues_dir()
    queue_names = ["orders", "explicit", "bugs", "security", "breakdown", "defects", "high-level"]
    for queue_name in queue_names:
        queue_dir = queues_dir / queue_name
        if not queue_dir.exists():
            continue
        for json_file in queue_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                file_id = data.get("orderId") or data.get("id") or json_file.stem
                if file_id == order_id:
                    repo = data.get("targetRepo", "")
                    # v2.0.5: Resolve from project field if targetRepo is missing
                    if not repo:
                        repo = _resolve_target_repo_from_project(data)
                    return repo
            except Exception:
                continue

    # Also check active orders
    active_dir = get_workspace_dir() / "orders" / "active"
    if active_dir.exists():
        for json_file in active_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                file_id = data.get("orderId") or data.get("id") or json_file.stem
                if file_id == order_id:
                    repo = data.get("targetRepo", "")
                    # v2.0.5: Resolve from project field if targetRepo is missing
                    if not repo:
                        repo = _resolve_target_repo_from_project(data)
                    return repo
            except Exception:
                continue

    return ""


def _get_project_for_order(order_id: str) -> str:
    """Look up an order's project acronym from queue files.

    BUG-ADM-2026-0013: PR-creation needs the project to resolve the
    default branch (PSG → master, ADM → main). Same scan pattern as
    _get_target_repo_for_order.
    """
    if not order_id:
        return ""
    queues_dir = get_queues_dir()
    queue_names = ["orders", "explicit", "bugs", "security",
                   "breakdown", "defects", "high-level", "proposed"]
    for queue_name in queue_names:
        queue_dir = queues_dir / queue_name
        if not queue_dir.exists():
            continue
        for json_file in queue_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                file_id = data.get("orderId") or data.get("id") or json_file.stem
                if file_id == order_id:
                    return data.get("project", "")
            except Exception:
                continue
    for sub in ("orders/active", "orders/complete", "orders/failed"):
        d = get_workspace_dir() / sub
        if not d.exists():
            continue
        for json_file in d.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                file_id = data.get("orderId") or data.get("id") or json_file.stem
                if file_id == order_id:
                    return data.get("project", "")
            except Exception:
                continue
    return ""


def _get_voyage_branch_for_order(order_id: str) -> str:
    """Look up the voyage branch for an order from its voyageId field.

    v2.0.1: Per-order voyage branch resolution. Converts voyageId (e.g. 'VOY-2026-0304')
    to a branch name (e.g. 'voyage/VOY-2026-0304'). Falls back to ACTIVE_VOYAGE_BRANCH
    if the order has no voyageId.
    """
    # Scan queue files and active orders for the voyageId
    search_dirs = []
    queues_dir = get_queues_dir()
    for queue_name in ["orders", "explicit", "bugs", "security", "breakdown", "defects", "high-level"]:
        qd = queues_dir / queue_name
        if qd.exists():
            search_dirs.append(qd)
    active_dir = get_workspace_dir() / "orders" / "active"
    if active_dir.exists():
        search_dirs.append(active_dir)
    # v2.0.2: Also search completed orders (order may already be archived)
    complete_dir = get_workspace_dir() / "orders" / "complete"
    if complete_dir.exists():
        search_dirs.append(complete_dir)

    for search_dir in search_dirs:
        for json_file in search_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                file_id = data.get("orderId") or data.get("id") or json_file.stem
                if file_id == order_id:
                    # v2.0.3: Check voyageBranch (full branch name) first, then voyageId
                    voyage_branch = data.get("voyageBranch", "")
                    if voyage_branch:
                        return voyage_branch
                    voyage_id = data.get("voyageId", "")
                    if voyage_id:
                        # Convert voyageId to branch name if not already prefixed
                        if voyage_id.startswith("voyage/"):
                            return voyage_id
                        return f"voyage/{voyage_id}"
            except Exception:
                continue

    return ""


def _get_voyage_id_for_order(order_id: str) -> str:
    """Look up the voyageId for an order from queue / complete files."""
    search_dirs = []
    queues_dir = get_queues_dir()
    for queue_name in ["orders", "explicit", "bugs", "security", "breakdown", "defects", "high-level"]:
        qd = queues_dir / queue_name
        if qd.exists():
            search_dirs.append(qd)
    for subdir in ["orders/active", "orders/complete"]:
        d = get_workspace_dir() / subdir
        if d.exists():
            search_dirs.append(d)

    for search_dir in search_dirs:
        for json_file in search_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding="utf-8"))
                file_id = data.get("orderId") or data.get("id") or json_file.stem
                if file_id == order_id:
                    return data.get("voyageId", "")
            except Exception:
                continue
    return ""


def _get_order_title(order_id: str) -> str:
    """Look up order title from queue files."""
    queues_dir = get_queues_dir()
    for queue_name in ["orders", "explicit", "bugs", "security", "breakdown", "defects", "high-level"]:
        queue_dir = queues_dir / queue_name
        if not queue_dir.exists():
            continue
        for json_file in queue_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                file_id = data.get("orderId") or data.get("id") or json_file.stem
                if file_id == order_id:
                    return data.get("title", order_id)
            except Exception:
                continue
    return order_id


# =============================================================================
# PROCESS MANAGEMENT
# =============================================================================

def start_crew_process(crew_number: int, role: str, order_id: str,
                       prompt_file: str, max_iterations: int,
                       timeout: int, voyage_branch: str = "",
                       repo_path: str = "",
                       project_acronym: str = "",
                       worktree_path: str = "",
                       max_turns: int = 200) -> Optional[int]:
    """Start a crew process as a fully detached independent process.

    v6.0: Mimics Ralph's Start-Process + Dispose() pattern.
    Each crew gets its own process group and console - no parent-child
    handle inheritance. This allows 5 crews to call Claude API
    concurrently without session-level rate limiting.

    Returns PID (int) or None on failure.
    """
    # Resolve crew.py: prefer script-relative (pip package), fall back to .mso/core/
    crew_py = Path(__file__).resolve().parent / "crew.py"
    if not crew_py.exists():
        crew_py = get_workspace_dir() / "core" / "crew.py"

    if not crew_py.exists():
        print_error(f"crew.py not found at {crew_py}")
        return None


    # Build the crew command
    crew_cmd = [
        sys.executable, str(crew_py),
        "--crew", str(crew_number),
        "--role", role,
        "--order", order_id,
        "--prompt", prompt_file,
        "--max-iterations", str(max_iterations),
        "--timeout", str(timeout),
        "--max-turns", str(max_turns),
        # BUG-MSO-2026-0302: command-line spawn marker — Win32_Process exposes
        # CommandLine (not env), so the marker must live in argv to make
        # orphaned crew processes discoverable by the cleanup sweep.
        "--spawn-marker", _spawn_marker(),
    ]

    try:
        # Build crew environment — inherit parent env, inject voyage branch if set.
        #
        crew_env = os.environ.copy()
        # Inject the workspace .mso path so crew.py uses the correct project dir
        # rather than resolving relative to the pip-installed package location.
        _mso_dir = str(get_workspace_dir())
        crew_env["MAESTRO_DIR"] = _mso_dir
        # BUG-MSO-2026-0302: discoverable spawn marker — lets the cleanup orphan
        # sweep find crew-descended processes that no PID file references
        # (a grandchild whose parent died is unreachable via taskkill /T).
        crew_env["MAESTRO_SPAWN_MARKER"] = _spawn_marker()
        _branch = voyage_branch or ACTIVE_VOYAGE_BRANCH
        if _branch:
            crew_env["MAESTRO_SPRINT_BRANCH"] = _branch

        # v2.0.0 / FTR-0149: Inject managed repo path so Claude CLI knows where to work.
        # worktree_path takes precedence — it is the per-voyage git worktree.
        _repo = worktree_path or repo_path
        if _repo:
            crew_env["MAESTRO_REPO_PATH"] = _repo

        # v2.0.5: Inject project acronym for multi-project awareness
        _project = project_acronym or os.environ.get("MAESTRO_PROJECT", "OTM")
        crew_env["MAESTRO_PROJECT"] = _project

        # We pass crew_env explicitly via env= so that the MAESTRO_* injections
        # above are forwarded to the crew process.
        # FTR-0149: use worktree_path as cwd when available (crew boots inside its
        # dedicated worktree); fall back to base dir for legacy/no-worktree paths.
        crew_cwd = worktree_path if worktree_path else str(get_base_dir())

        if os.name == 'nt':
            # v6.0: Background mode - no visible console window
            # DETACHED_PROCESS: No console allocated (runs silently)
            # CREATE_NEW_PROCESS_GROUP: Own process group (Ctrl+C isolation)
            # Monitor fleet via fleet_monitor.py instead of crew windows
            # Crew log: .mso/crews/crewN/crew.log (stdout/stderr)
            # Crew output: .mso/crews/crewN/output_N.txt (from Claude)
            flags = DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP

            # Open log file for crew stdout/stderr (stays open via inherited handle)
            log_path = get_crew_dir(crew_number) / "crew.log"
            log_path.parent.mkdir(parents=True, exist_ok=True)
            log_fh = open(str(log_path), 'w', encoding='utf-8')

            proc = _spawn(
                crew_cmd,
                identity="fleet_runner",
                workspace=get_base_dir(),
                creationflags=flags,
                stdout=log_fh,
                stderr=subprocess.STDOUT,
                stdin=subprocess.DEVNULL,
                cwd=crew_cwd,
                env=crew_env,
            )
            # Don't close log_fh yet - the child process inherits the fd
            # Store it so we can close after confirming launch
            _CREW_LOG_HANDLES[crew_number] = log_fh
        else:
            proc = _spawn(
                crew_cmd,
                identity="fleet_runner",
                workspace=get_base_dir(),
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                cwd=crew_cwd,
                start_new_session=True,  # Unix equivalent: own process group
                env=crew_env,
            )

        pid = proc.pid

        # Save PID to file for cleanup capability
        pid_file = get_crew_dir(crew_number) / "pid.txt"
        pid_file.parent.mkdir(parents=True, exist_ok=True)
        pid_file.write_text(str(pid), encoding='utf-8')

        # CRITICAL: Release the Popen object immediately (like Ralph's $proc.Dispose())
        # This severs the parent-child relationship
        del proc

        # Give it a moment to start
        time.sleep(1)

        # Verify it's running via PID check (not proc.poll())
        if not is_process_alive(pid):
            print_error(f"Crew {crew_number} process exited immediately")
            # Close log handle on failure
            if crew_number in _CREW_LOG_HANDLES:
                try: _CREW_LOG_HANDLES.pop(crew_number).close()
                except: pass
            return None

        # Close parent's copy of log handle - child has its own inherited copy
        if crew_number in _CREW_LOG_HANDLES:
            try: _CREW_LOG_HANDLES.pop(crew_number).close()
            except: pass

        return pid

    except Exception as e:
        print_error(f"Failed to start Crew {crew_number}: {e}")
        if crew_number in _CREW_LOG_HANDLES:
            try: _CREW_LOG_HANDLES.pop(crew_number).close()
            except: pass
        return None

def is_process_alive(pid: int) -> bool:
    """Check if a process with the given PID is still running.

    Uses ctypes OpenProcess on Windows for reliability (works from cmd.exe AND Git Bash).
    The old tasklist /FI approach fails from Git Bash because it translates /FI to a path.
    Falls back to os.kill(0) on other platforms.
    """
    if pid <= 0:
        return False
    try:
        if os.name == 'nt':
            import ctypes
            PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            STILL_ACTIVE = 259
            kernel32 = ctypes.windll.kernel32
            handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
            if handle == 0:
                return False  # Can't open = doesn't exist or no access
            try:
                exit_code = ctypes.c_ulong()
                if kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code)):
                    return exit_code.value == STILL_ACTIVE
                return False
            finally:
                kernel32.CloseHandle(handle)
        else:
            os.kill(pid, 0)  # Signal 0 = existence check
            return True
    except (ProcessLookupError, PermissionError, OSError):
        return False


def read_crew_pid(crew_number: int) -> Optional[int]:
    """Read crew PID from pid.txt file."""
    pid_file = get_crew_dir(crew_number) / "pid.txt"
    if pid_file.exists():
        try:
            return int(pid_file.read_text(encoding='utf-8').strip())
        except (ValueError, IOError):
            return None
    return None


def save_fleet_state():
    """Save current fleet state for crash recovery."""
    global FLEET_STATE_FILE

    if not FLEET_STATE_FILE:
        FLEET_STATE_FILE = get_workspace_dir() / "fleet-runner-state.json"

    state = {
        "pids": {},
        "timestamp": datetime.now().isoformat(),
        "status": "RUNNING"
    }

    # Collect PIDs from active tracking and pid.txt files
    for crew_num in range(1, 6):
        pid = ACTIVE_PROCESSES.get(crew_num)
        if not pid:
            pid = read_crew_pid(crew_num)
        if pid and is_process_alive(pid):
            state["pids"][str(crew_num)] = pid

    try:
        FLEET_STATE_FILE.write_text(json.dumps(state, indent=2), encoding='utf-8')
    except:
        pass

def cleanup_fleet(reason: str = "shutdown"):
    """Clean up all fleet processes."""
    global SHUTDOWN_REQUESTED
    SHUTDOWN_REQUESTED = True

    print(f"\n  {C.YELLOW}Cleaning up fleet ({reason})...{C.RESET}")

    # Kill by tracked PIDs
    for crew_num, pid in list(ACTIVE_PROCESSES.items()):
        if pid and is_process_alive(pid):
            try:
                if os.name == 'nt':
                    subprocess.run(
                        ['taskkill', '/F', '/T', '/PID', str(pid)],
                        capture_output=True, timeout=5
                    )
                else:
                    os.kill(pid, 9)
                print_info(f"Stopped Crew {crew_num} (PID {pid})")
            except:
                pass

    # Also check pid.txt files for any crews not in ACTIVE_PROCESSES
    for crew_num in range(1, 6):
        if crew_num not in ACTIVE_PROCESSES:
            pid = read_crew_pid(crew_num)
            if pid and is_process_alive(pid):
                try:
                    if os.name == 'nt':
                        subprocess.run(
                            ['taskkill', '/F', '/T', '/PID', str(pid)],
                            capture_output=True, timeout=5
                        )
                    print_info(f"Stopped orphaned Crew {crew_num} (PID {pid})")
                except:
                    pass

    ACTIVE_PROCESSES.clear()

    # Clear fleet state file
    if FLEET_STATE_FILE and FLEET_STATE_FILE.exists():
        try:
            FLEET_STATE_FILE.unlink()
        except:
            pass

    print(f"  {C.GREEN}Cleanup complete.{C.RESET}\n")

def signal_handler(signum, frame):
    """Handle interrupt signals."""
    cleanup_fleet("user interrupt")
    sys.exit(0)


# =============================================================================
# STATUS DISPLAY
# =============================================================================

def read_crew_state(crew_number: int) -> Optional[Dict[str, Any]]:
    """Read crew state from file."""
    state_file = get_crew_dir(crew_number) / "state.json"
    if state_file.exists():
        try:
            return json.loads(state_file.read_text(encoding='utf-8'))
        except:
            return None
    return None

    # Legacy manifest-mode print_status_board removed in v2.0.4


# =============================================================================
# WAVE SEQUENCING v4.0
# =============================================================================

def _mark_order_terminal_now() -> None:
    """Record that an order just reached a terminal archive (COMPLETE/STALLED).

    BUG-MSO-2026-0024: Eight Bells consults this timestamp so it cannot fire in
    the brief window after an order archives but before the dispatcher re-scans
    queues to notice a freshly-unblocked dependent.
    """
    global LAST_ORDER_TERMINAL_AT
    LAST_ORDER_TERMINAL_AT = datetime.now()


def _eight_bells_grace_elapsed() -> bool:
    """True if enough time has passed since the last order archive to ring Eight Bells.

    BUG-MSO-2026-0024: returns False during the grace window after a COMPLETE/STALLED
    archive, so a freshly-unblocked dependent gets a chance to be dispatched first.
    """
    if LAST_ORDER_TERMINAL_AT is None:
        return True
    try:
        grace = int(os.environ.get("MAESTRO_EIGHT_BELLS_GRACE_SECONDS", str(EIGHT_BELLS_GRACE_SECONDS)))
    except (TypeError, ValueError):
        grace = EIGHT_BELLS_GRACE_SECONDS
    if grace <= 0:
        return True
    return (datetime.now() - LAST_ORDER_TERMINAL_AT).total_seconds() >= grace


def ring_bell():
    """Ring the bell - voyage complete!"""
    print()
    print(f"  {C.GREEN}{C.BOLD}{'='*70}")
    print(f"  🔔🔔🔔  {current_persona().term('sprint').upper()} COMPLETE!  🔔🔔🔔")
    print(f"  {'='*70}{C.RESET}")
    print()
    try:
        import winsound
        # Three ascending bell tones for voyage complete
        winsound.Beep(800, 300)
        winsound.Beep(1000, 300)
        winsound.Beep(1200, 500)
    except Exception:
        pass


def ring_crew_bell(crew_num: int, order_id: str):
    """Ring a single bell - crew order complete!"""
    crew_name = _get_crew_name(crew_num)
    print(f"  {C.GREEN}🔔 BELL - {crew_name} completed {order_id}{C.RESET}")
    try:
        import winsound
        winsound.Beep(1000, 200)
    except Exception:
        pass


def run_post_voyage_matrix_update():
    """v8.6: Post-voyage — refresh REQUIREMENTS-MATRIX.md from current data.

    Runs .mso/tools/update-matrix.py to sync the matrix with
    _INDEX.md (specifications) and TRACEABILITY-REPORT.md (scanner counts).
    Non-blocking: logs warning on failure but does not halt the dispatcher.
    """
    update_script = get_workspace_dir() / "tools" / "update-matrix.py"
    if not update_script.exists():
        print_warn("Post-voyage matrix update skipped — update-matrix.py not found")
        return

    print_info("Post-voyage: Refreshing REQUIREMENTS-MATRIX.md...")
    try:
        result = subprocess.run(
            [sys.executable, str(update_script)],
            capture_output=True, text=True, timeout=60,
            cwd=str(get_workspace_dir().parent)
        )
        if result.returncode == 0:
            print_ok("Requirements matrix updated successfully")
            write_lifecycle_event("POST-VOYAGE", "REQUIREMENTS-MATRIX.md refreshed by update-matrix.py")
        else:
            print_warn(f"Matrix update exited with code {result.returncode}")
            if result.stderr:
                print_warn(f"  {result.stderr.strip()[:200]}")
    except subprocess.TimeoutExpired:
        print_warn("Matrix update timed out (60s) — skipping")
    except Exception as e:
        print_warn(f"Matrix update failed: {e}")


def run_post_voyage_pr_creation():
    """v8.13: Post-voyage -- auto-create PRs from voyage branch to main.

    Uses _SESSION_TARGET_REPOS (populated during dispatch) to know which repos
    had orders dispatched this session. Only checks those repos for commits
    ahead of the project's resolved default branch (e.g. `master` for PSG,
    `main` for the framework), avoiding API rate limits from scanning all
    historical orders.

    BUG-MSO-2026-0016 (v2.8.2): both the COMPARE check and the `gh pr create`
    call now resolve the base via `_get_default_branch_for_repo()` rather
    than hardcoded `main`. Operators on non-main-default repos (PSG) get
    PRs opened against the correct base.

    v2.0.2: Uses per-repo voyage branches from _SESSION_REPO_BRANCHES instead of
    the global ACTIVE_VOYAGE_BRANCH, supporting mixed-voyage dispatch sessions.

    Non-blocking: logs warning on failure but does not halt the dispatcher.
    Skips repos where no voyage branch exists or where a PR already exists.
    """
    # v2.0.2: Check if we have any per-repo branches OR a global branch
    if not ACTIVE_VOYAGE_BRANCH and not _SESSION_REPO_BRANCHES:
        print_warn("Post-voyage PR creation skipped -- no voyage branch set")
        return

    org = _load_workspace_org()

    # Use session-tracked repos (populated during dispatch_crew)
    if not _SESSION_TARGET_REPOS:
        print_info("Post-voyage PR creation: no repos dispatched this session")
        return

    order_summaries = _SESSION_TARGET_REPOS
    target_repos = set(order_summaries.keys())

    print_info(f"Post-voyage: Checking {len(target_repos)} repo(s) dispatched this session for PRs...")

    created = 0
    skipped = 0
    failed = 0

    for repo in sorted(target_repos):
        full_repo = f"{org}/{repo}"
        # v2.0.2: Per-repo voyage branch resolution
        repo_branch = _SESSION_REPO_BRANCHES.get(repo, ACTIVE_VOYAGE_BRANCH)
        if not repo_branch:
            print_info(f"  {repo}: no voyage branch known -- skipping")
            skipped += 1
            continue
        branch_ref = repo_branch.replace("refs/heads/", "")

        try:
            # v8.13: Small delay between repos to avoid GitHub secondary rate limits
            time.sleep(1)

            # Check if voyage branch exists on this repo
            check = subprocess.run(
                ["gh", "api", f"repos/{full_repo}/branches/{branch_ref}",
                 "--jq", ".name"],
                capture_output=True, text=True, timeout=30
            )
            if check.returncode != 0 or not check.stdout.strip():
                print_info(f"  {repo}: no voyage branch -- skipping")
                skipped += 1
                continue

            # Check if PR already exists for this branch
            pr_check = subprocess.run(
                ["gh", "pr", "list", "--repo", full_repo,
                 "--head", branch_ref, "--state", "open", "--json", "number"],
                capture_output=True, text=True, timeout=30
            )
            if pr_check.returncode == 0 and pr_check.stdout.strip() not in ("", "[]"):
                print_info(f"  {repo}: PR already exists -- skipping")
                skipped += 1
                continue

            # BUG-ADM-2026-0013: resolve base branch from project registry —
            # PSG uses `master`, framework uses `main`. Hardcoded `main` here
            # silently 404'd on PSG, so PRs never got opened.
            default_branch = _get_default_branch_for_repo(repo)

            # Check if branch has commits ahead of the project's default branch
            compare = subprocess.run(
                ["gh", "api", f"repos/{full_repo}/compare/{default_branch}...{branch_ref}",
                 "--jq", ".ahead_by"],
                capture_output=True, text=True, timeout=30
            )
            ahead_by = 0
            if compare.returncode == 0:
                try:
                    ahead_by = int(compare.stdout.strip())
                except ValueError:
                    pass
            else:
                print_warn(f"  {repo}: compare API failed against {default_branch} (rc={compare.returncode}) -- {compare.stderr.strip()[:100]}")

            if ahead_by == 0:
                print_info(f"  {repo}: no commits ahead of {default_branch} -- skipping")
                skipped += 1
                continue

            # v8.13.1: Check actual file diff to avoid empty PRs
            # (ahead_by can be > 0 for commits already merged via previous voyage)
            diff_check = subprocess.run(
                ["gh", "api", f"repos/{full_repo}/compare/{default_branch}...{branch_ref}",
                 "--jq", ".files | length"],
                capture_output=True, text=True, timeout=30
            )
            changed_files = 0
            if diff_check.returncode == 0:
                try:
                    changed_files = int(diff_check.stdout.strip())
                except ValueError:
                    pass

            if changed_files == 0:
                print_info(f"  {repo}: {ahead_by} commit(s) but 0 changed files -- skipping (already merged)")
                skipped += 1
                continue

            # Build PR body from order summaries
            orders = order_summaries.get(repo, [])
            body_lines = [f"## Summary", ""]
            body_lines.append(f"Voyage branch `{branch_ref}` with {ahead_by} commit(s).")
            body_lines.append("")
            body_lines.append("### Orders Completed")
            for t in orders[:20]:  # Cap at 20 to avoid huge PR bodies
                body_lines.append(f"- {t}")
            body_lines.append("")
            body_lines.append("## Test plan")
            body_lines.append("- [ ] CI checks pass")
            body_lines.append("- [ ] Code review completed")
            body_lines.append("")

            pr_body = "\n".join(body_lines)
            pr_title = f"[{branch_ref}] {repo} ({len(orders)} order(s))"
            if len(pr_title) > 70:
                pr_title = f"[{branch_ref}] {repo}"

            # Create the PR
            pr_result = subprocess.run(
                ["gh", "pr", "create",
                 "--repo", full_repo,
                 "--base", default_branch,
                 "--head", branch_ref,
                 "--title", pr_title,
                 "--body", pr_body],
                capture_output=True, text=True, timeout=60
            )

            if pr_result.returncode == 0:
                pr_url = pr_result.stdout.strip()
                print_ok(f"  {repo}: PR created -> {pr_url}")
                write_lifecycle_event("POST-VOYAGE", f"PR created for {repo}: {pr_url}")
                created += 1
            else:
                err = pr_result.stderr.strip()[:200]
                print_warn(f"  {repo}: PR creation failed -- {err}")
                failed += 1

        except subprocess.TimeoutExpired:
            print_warn(f"  {repo}: timeout -- skipping")
            failed += 1
        except Exception as e:
            print_warn(f"  {repo}: error -- {e}")
            failed += 1

    print_info(f"Post-voyage PRs: {created} created, {skipped} skipped, {failed} failed")
    write_lifecycle_event("POST-VOYAGE", f"Auto-PR: {created} created, {skipped} skipped, {failed} failed")


    # Legacy manifest-mode wave functions removed in v2.0.4


# =============================================================================
# AUTO-DISPATCHER v5.2
# =============================================================================

def get_queues_dir() -> Path:
    """Get the queues directory."""
    return get_workspace_dir() / "queues"


def scan_requests_queue() -> List[Dict[str, Any]]:
    """Scan requests queue for pending items. Returns list sorted by priority."""
    requests = []
    requests_dir = get_queues_dir() / "requests"

    # Priority order for request types
    request_priority = {
        "planning": 1,      # NAV planning - highest priority
        "investigation": 2, # LKT investigation
        "qa": 3,            # BOS QA
        "security-scan": 4, # LKT security
        "documentation": 5  # SCR documentation
    }

    # Role mapping for request types
    request_roles = {
        "planning": "NAV",
        "investigation": "LKT",
        "qa": "BOS",
        "security-scan": "LKT",
        "documentation": "SCR"
    }

    if not requests_dir.exists():
        return []

    for subdir in requests_dir.iterdir():
        if subdir.is_dir():
            req_type = subdir.name
            for json_file in subdir.glob("*.json"):
                try:
                    data = _read_order_file_tolerant(json_file)
                    status = data.get("status", "PENDING")
                    if status == "PENDING":
                        # v8.6: Resolve ID and title consistently
                        req_id = data.get("orderId") or data.get("id") or json_file.stem
                        req_title = data.get("title") or data.get("description", "")
                        if not req_title:
                            parts = req_id.split("-", 1)
                            req_title = parts[1] if len(parts) > 1 else req_id

                        requests.append({
                            "type": "REQUEST",
                            "subtype": req_type,
                            "id": req_id,
                            "title": req_title,
                            "priority": request_priority.get(req_type, 10),
                            "role": request_roles.get(req_type, "NAV"),
                            "path": str(json_file),
                            "data": data
                        })
                except Exception as e:
                    msg = f"Unreadable request file skipped: {json_file.name} — {e}"
                    print_warn(msg)
                    write_lifecycle_event("ERROR", msg)

    # Sort by priority (lower = higher priority)
    return sorted(requests, key=lambda x: x["priority"])


def scan_orders_queue() -> List[Dict[str, Any]]:
    """Scan orders queue for pending items. Returns list sorted by priority."""
    orders = []
    orders_dir = get_queues_dir() / "orders"

    # Priority mapping
    priority_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "NORMAL": 2}

    # Order type to role mapping (default role)
    order_roles = {
        "FIX": "SHP",
        "BUG": "SHP",
        "TEST": "SHP",  # Writing tests is SHP work
        "SEC": "LKT",   # Security starts with LKT
        "FTR": "NAV",   # Features start with NAV planning
        "RFT": "SHP",   # Refactor is SHP work
        "DOC": "SCR",   # Documentation is SCR work
        "INV": "LKT"    # Investigation is LKT work
    }

    if not orders_dir.exists():
        return []

    for json_file in orders_dir.glob("*.json"):
        try:
            data = _read_order_file_tolerant(json_file)
            status = data.get("status", "PENDING")
            if status == "PENDING":
                # v8.6.1: Backwards-compat — check both "orderType" and "type" fields
                order_type = data.get("orderType") or data.get("type", "FIX")
                # Normalize: if "type" was "ORDER", it's not a valid orderType — use "FIX"
                if order_type == "ORDER":
                    order_type = data.get("orderType", "FIX")
                priority_str = data.get("priority", "MEDIUM")
                # v8.8: Check targetRole, role, roleSequence[0], then infer from orderType
                target_role = data.get("targetRole") or data.get("role") or ""
                if not target_role:
                    seq = data.get("roleSequence", [])
                    target_role = seq[0] if seq else order_roles.get(order_type, "SHP")

                # v8.6: Resolve ID and title consistently
                item_id = data.get("orderId") or data.get("id") or json_file.stem
                item_title = data.get("title") or data.get("description", "")
                if not item_title:
                    parts = item_id.split("-", 1)
                    item_title = parts[1] if len(parts) > 1 else item_id

                orders.append({
                    "type": "ORDER",
                    "subtype": order_type,
                    "id": item_id,
                    "title": item_title,
                    "priority": priority_order.get(priority_str, 2),
                    "role": target_role,
                    "path": str(json_file),
                    "data": data
                })
        except Exception as e:
            msg = f"Unreadable order file skipped: {json_file.name} — {e}"
            print_warn(msg)
            write_lifecycle_event("ERROR", msg)

    # Sort by priority (lower = higher priority)
    return sorted(orders, key=lambda x: x["priority"])


# =============================================================================
# v8.2: Role Sequence Gate Enforcement
# =============================================================================

# Loaded from order templates at startup — maps orderType to roleSequence
ROLE_SEQUENCES: Dict[str, List[str]] = {}

# BUG-MSO-2026-0205: the post-plan human review gate must fire for the canonical
# planning role `PLN` as well as the legacy nautical alias `NAV`. The original
# gate only matched `"NAV"`, so canonical-role workspaces were never paused.
_PLANNING_ROLES = {"PLN", "NAV"}


def _is_planning_role(role: str) -> bool:
    """True if `role` is the planning role (canonical PLN or legacy NAV alias)."""
    return (role or "").upper() in _PLANNING_ROLES


def load_role_sequences():
    """Load roleSequence from all order templates (v8.2).

    Populates ROLE_SEQUENCES dict: {"FTR": ["NAV","SHP","BOS","SCR","LKT","COX"], ...}
    Called once at dispatcher startup.
    """
    global ROLE_SEQUENCES
    templates_dir = get_workspace_dir() / "orders" / "templates"
    if not templates_dir.exists():
        return
    for f in templates_dir.glob("*-template.json"):
        try:
            data = json.loads(f.read_text(encoding='utf-8'))
            meta = data.get("_meta", {})
            order_type = meta.get("orderType", "")
            sequence = meta.get("roleSequence", [])
            if order_type and sequence:
                ROLE_SEQUENCES[order_type] = sequence
        except Exception:
            pass


def resolve_order_fields(data: Dict[str, Any]) -> tuple:
    """v8.6.1: Resolve targetRole and orderType from order data with backwards-compat fallback.

    Orders may use "targetRole" or "role", and "orderType" or "type".
    This helper normalizes both to avoid role misassignment.

    Returns: (target_role: str, order_type: str)
    """
    order_type = data.get("orderType") or data.get("type", "")
    if order_type == "ORDER":
        order_type = data.get("orderType", "")
    target_role = data.get("targetRole") or data.get("role", "")
    return target_role, order_type


def build_voyage_role_status() -> Dict[str, Dict[str, str]]:
    """Build per-voyage map of role completion status (v8.2).

    Scans complete archive and active queues to determine, for each voyage,
    which roles have COMPLETE, IN_PROGRESS, or PENDING orders.

    Returns: {voyageId: {role: "COMPLETE"|"IN_PROGRESS"|"PENDING"}}
    Best status wins: COMPLETE > IN_PROGRESS > PENDING.
    Also tracks the primary orderType per voyage for sequence lookup.
    """
    # BUG-MSO-2026-0244: CONVERGENCE_FAILED is a started-but-not-complete state. It
    # MUST rank above 0 (the unknown-status default) or update_voyage() would never
    # record the role, making it look "not present" and letting later roles dispatch
    # past it. Rank it like IN_PROGRESS: occupied/blocking, definitely not COMPLETE.
    STATUS_RANK = {"COMPLETE": 3, "IN_PROGRESS": 2, "CONVERGENCE_FAILED": 2, "PENDING": 1}
    voyage_roles: Dict[str, Dict[str, str]] = {}  # {voyageId: {role: status}}
    voyage_types: Dict[str, str] = {}  # {voyageId: primary orderType}

    def update_voyage(voyage_id: str, role: str, status: str, order_type: str):
        if not voyage_id or not role:
            return
        if voyage_id not in voyage_roles:
            voyage_roles[voyage_id] = {}
        current = voyage_roles[voyage_id].get(role, "")
        if STATUS_RANK.get(status, 0) > STATUS_RANK.get(current, 0):
            voyage_roles[voyage_id][role] = status
        # Track primary order type (template-defined types take precedence)
        if order_type in ROLE_SEQUENCES:
            voyage_types[voyage_id] = order_type

    mso_dir = get_workspace_dir()

    # Scan completed orders archive
    complete_dir = mso_dir / "orders" / "complete"
    if complete_dir.exists():
        for f in complete_dir.glob("*.json"):
            try:
                data = json.loads(f.read_text(encoding='utf-8'))
                vid = data.get("voyageId", "")
                role, otype = resolve_order_fields(data)
                status = data.get("status", "COMPLETE")
                update_voyage(vid, role, status, otype)
            except Exception:
                pass

    # Scan all active queue directories
    queues_dir = get_queues_dir()
    queue_dirs = ["explicit", "security", "bugs", "orders", "defects",
                  "breakdown", "high-level"]
    for qname in queue_dirs:
        qpath = queues_dir / qname
        if not qpath.exists():
            continue
        for f in qpath.glob("*.json"):
            try:
                data = json.loads(f.read_text(encoding='utf-8'))
                vid = data.get("voyageId", "")
                role, otype = resolve_order_fields(data)
                status = data.get("status", "PENDING")
                update_voyage(vid, role, status, otype)
            except Exception:
                pass

    # Scan requests subdirectories
    requests_dir = queues_dir / "requests"
    if requests_dir.exists():
        for subdir in requests_dir.iterdir():
            if not subdir.is_dir():
                continue
            for f in subdir.glob("*.json"):
                try:
                    data = json.loads(f.read_text(encoding='utf-8'))
                    vid = data.get("voyageId", "")
                    role, otype = resolve_order_fields(data)
                    status = data.get("status", "PENDING")
                    update_voyage(vid, role, status, otype)
                except Exception:
                    pass

    # Scan orders/active/ directory (orders tracked but may not be in queues yet)
    active_dir = mso_dir / "orders" / "active"
    if active_dir.exists():
        for f in active_dir.glob("*.json"):
            try:
                data = json.loads(f.read_text(encoding='utf-8'))
                vid = data.get("voyageId", "")
                role, otype = resolve_order_fields(data)
                status = data.get("status", "PENDING")
                update_voyage(vid, role, status, otype)
            except Exception:
                pass

    # Attach primary type to each voyage's role map (under special key)
    for vid, ptype in voyage_types.items():
        if vid in voyage_roles:
            voyage_roles[vid]["__primaryType__"] = ptype

    return voyage_roles


def check_role_sequence_gate(order_data: Dict[str, Any],
                             voyage_roles: Dict[str, str]) -> tuple:
    """Check if prior roles in the sequence have completed for this voyage (v8.3.1).

    Returns (passed: bool, missing_roles: List[str])

    Pass-through cases (always pass):
    - No voyageId on the order
    - No roleSequence found for this order type
    - Single-role sequence (INV, DOC)
    - targetRole is the FIRST role in the sequence

    v8.3.1: Only enforce gate on roles that have orders in the voyage.
    If a prior role has no orders at all (not in voyage_roles), it is
    treated as not applicable and skipped. This prevents voyages without
    SCR/LKT orders from blocking COX dispatch.
    """
    # v8.6.1: Use resolve helper for backwards-compat
    target_role, resolved_type = resolve_order_fields(order_data)
    if not target_role:
        return True, []

    # Determine the role sequence to enforce
    # First try the order's own _meta, then fall back to template via orderType,
    # then fall back to the voyage's primary type
    sequence = None
    meta = order_data.get("_meta", {})
    if meta.get("roleSequence"):
        sequence = meta["roleSequence"]
    else:
        order_type = resolved_type
        if order_type in ROLE_SEQUENCES:
            sequence = ROLE_SEQUENCES[order_type]
        else:
            # Look up from voyage's primary type
            primary_type = voyage_roles.get("__primaryType__", "")
            if primary_type in ROLE_SEQUENCES:
                sequence = ROLE_SEQUENCES[primary_type]

    if not sequence or len(sequence) <= 1:
        return True, []  # Single-role or unknown — pass through

    # Find target role position in sequence
    if target_role not in sequence:
        return True, []  # Role not in known sequence — pass through

    role_index = sequence.index(target_role)
    if role_index == 0:
        return True, []  # First role in sequence — no prior roles to check

    # v8.9: If this order has already been advanced past the first role,
    # prior roles have already completed FOR THIS ORDER — pass through.
    # Checking voyage-wide role status would incorrectly block orders that
    # are mid-sequence when other orders in the same voyage are still at
    # earlier roles (e.g., FTR-0139 at SHP blocking BUG-0141 at BOS).
    first_role = sequence[0]
    if target_role != first_role:
        return True, []  # Already advanced — prior roles implicitly complete

    # Check PRIOR roles in the sequence that have orders in this voyage
    # v8.3.1: Roles with no orders (not in voyage_roles) are skipped —
    # only block on roles that exist but aren't COMPLETE yet
    missing = []
    for i in range(role_index):
        prior_role = sequence[i]
        prior_status = voyage_roles.get(prior_role, "")
        if not prior_status:
            continue  # No orders for this role in voyage — not applicable
        if prior_status != "COMPLETE":
            missing.append(f"{prior_role} ({prior_status})")

    return len(missing) == 0, missing


# =============================================================================
# v7.0: Dependency-Aware Dispatch
# =============================================================================

def check_dependencies_satisfied(order_data: Dict[str, Any]) -> tuple:
    """Check if all dependencies for an order are satisfied (v7.0, v8.7, BUG-0251).

    Returns (satisfied: bool, waiting_on: List[str])
    An order is dispatchable only when ALL dependencies are archived.

    v8.7: Accept COMPLETE or STALLED as satisfying a dependency.
    STALLED means the crew hit MAX_ITERATIONS but produced partial work.
    The QM wired the dependency chain deliberately, so downstream orders
    should proceed — they can build on or remediate the partial output.

    BUG-MSO-2026-0251: Do NOT treat ERROR-escalated STALLED as satisfying.
    An ERROR-escalation STALLED produced zero work (REQUEUE cap hit on cli_error
    or similar zero-turn failure). stalledCause="ERROR" marks this path.
    Only stalledCause="MAX_ITERATIONS" (or absent, for legacy records) satisfies.
    """
    depends_on = order_data.get("dependsOn", [])
    if not depends_on:
        return True, []

    # BUG-0251: STALLED only satisfies when stalledCause != "ERROR".
    # COMPLETE and MAX_ITERATIONS always satisfy.
    HARD_SATISFYING = {"COMPLETE", "MAX_ITERATIONS"}

    archive_dir = get_workspace_dir() / "orders" / "complete"
    waiting_on = []

    for dep_id in depends_on:
        satisfied = False
        # Check in completed orders archive
        dep_file = archive_dir / f"{dep_id}.json"
        if dep_file.exists():
            try:
                dep_data = json.loads(dep_file.read_text(encoding='utf-8'))
                dep_status = dep_data.get("status")
                if dep_status in HARD_SATISFYING:
                    satisfied = True
                elif dep_status == "STALLED":
                    # BUG-0251: only satisfy when the STALLED was caused by
                    # iteration exhaustion (partial work exists), not ERROR escalation.
                    # Legacy records without stalledCause default to MAX_ITERATIONS
                    # (pre-fix behaviour: STALLED always satisfied).
                    stalled_cause = dep_data.get("stalledCause", "MAX_ITERATIONS")
                    satisfied = stalled_cause != "ERROR"
            except Exception:
                pass
        if not satisfied:
            waiting_on.append(dep_id)

    return len(waiting_on) == 0, waiting_on


def detect_circular_dependencies(items: List[Dict[str, Any]]) -> List[List[str]]:
    """Detect circular dependency chains among pending items (v7.0).

    Uses iterative DFS. Returns list of cycles found.
    """
    # Build adjacency map
    dep_graph = {}
    for item in items:
        item_id = item.get("id", "")
        deps = item.get("data", {}).get("dependsOn", [])
        if deps:
            dep_graph[item_id] = deps

    if not dep_graph:
        return []

    cycles = []
    visited = set()
    rec_stack = set()

    for start_node in list(dep_graph.keys()):
        if start_node in visited:
            continue

        stack = [(start_node, iter(dep_graph.get(start_node, [])))]
        path = [start_node]
        rec_stack.add(start_node)

        while stack:
            node, neighbors = stack[-1]
            try:
                neighbor = next(neighbors)
                if neighbor in rec_stack:
                    # Found cycle
                    if neighbor in path:
                        cycle_start = path.index(neighbor)
                        cycles.append(path[cycle_start:] + [neighbor])
                elif neighbor not in visited and neighbor in dep_graph:
                    rec_stack.add(neighbor)
                    path.append(neighbor)
                    stack.append((neighbor, iter(dep_graph.get(neighbor, []))))
            except StopIteration:
                rec_stack.discard(node)
                if path:
                    path.pop()
                stack.pop()
                visited.add(node)

    return cycles


# v7.0: Track items waiting on dependencies (for display, not dispatched)
WAITING_ON_DEPS: Dict[str, List[str]] = {}

# BUG-MSO-2026-0274: remember the last waiting-on set we emitted a DEP_HELD event
# for, per item, so scan_all_queues (which runs every ~10s) logs DEP_HELD only on
# first hold or when the dependency set changes — not on every tick (log-flood).
# Persists across scans (NOT reset with WAITING_ON_DEPS).
_DEP_HELD_LOGGED: Dict[str, List[str]] = {}

# BUG-MSO-2026-0247: tracks order files that could not be read/parsed during a scan
_QUEUE_READ_ERRORS: List[str] = []


def _read_order_file_tolerant(json_file: "Path") -> dict:
    """Read an order JSON file with encoding tolerance (BUG-MSO-2026-0247).

    Tries UTF-8 first. On UnicodeDecodeError falls back to cp1252 — a single-byte
    codec that decodes ANY byte sequence, so a stray Windows-locale byte (e.g. an
    0x97 em-dash) can't hide an order from dispatch. When the cp1252 fallback
    succeeds the file is rewritten as UTF-8 in place so the mismatch doesn't recur.
    Raises json.JSONDecodeError on genuine JSON corruption (caller must handle);
    OSError if the file cannot be read at all.
    """
    raw: bytes = json_file.read_bytes()
    # cp1252 covers all 256 single-byte values, so it never raises UnicodeDecodeError
    # — it's the terminal fallback (no latin-1 needed; it would be unreachable).
    for enc in ("utf-8", "cp1252"):
        try:
            text = raw.decode(enc)
        except UnicodeDecodeError:
            continue
        data = json.loads(text)  # JSONDecodeError on genuine corruption propagates to caller
        if enc != "utf-8":
            # Normalise to UTF-8 so the mismatch doesn't recur
            json_file.write_bytes(text.encode("utf-8"))
            write_lifecycle_event(
                "WARN",
                f"Order file re-encoded {enc}→utf-8: {json_file.name}"
            )
        return data
    # Defensive only: cp1252 decodes any byte, so this is effectively unreachable.
    raise ValueError(f"Could not decode {json_file} with any known encoding")


def _terminal_order_ids() -> set:
    """Order IDs already archived as terminal (orders/complete/ or orders/failed/).

    BUG-MSO-2026-0263: a completed order is archived by moving its file
    queues/orders/X.json -> orders/complete/X.json in the working tree, and that move
    is not committed immediately (LEAD sweeps completions to main). If the working tree
    is reset to HEAD by concurrent git activity, the stale queue copy resurfaces and the
    dispatcher would re-dispatch an already-COMPLETE order (re-converging merged work).
    scan_all_queues() consults this set to veto re-selection regardless of a stale copy.
    """
    ids = set()
    ws = get_workspace_dir()
    for sub in ("orders/complete", "orders/failed"):
        d = ws / sub
        if d.exists():
            for f in d.glob("*.json"):
                ids.add(f.stem)
    return ids


def _live_crew_order_ids() -> set:
    """Order IDs currently owned by a crew whose process is alive.

    BUG-MSO-2026-0294 belt-and-braces alongside the ledger: the crew state
    files are gitignored runtime state, so they survive the git rewinds that
    erase the queue-file claim. Crews with dead pids are excluded — the
    crash-recovery path owns those.
    """
    ids = set()
    crews_dir = get_workspace_dir() / "crews"
    if not crews_dir.exists():
        return ids
    for state_file in crews_dir.glob("crew*/state.json"):
        try:
            state = json.loads(state_file.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if state.get("status") not in ("RUNNING", "ACTIVE"):
            continue
        pid = state.get("pid")
        oid = state.get("orderId")
        if oid and pid and is_process_alive(pid):
            ids.add(oid)
    return ids


def _self_heal_stale_queue_file(json_file: Path, data: dict, order_id: str,
                                terminal_status: str) -> None:
    """BUG-MSO-2026-0295: re-archive a queue file the ledger knows is terminal.

    A git rewind (or a stale snapshot round-tripping through a voyage PR) can
    resurrect a completed order's queue file. Instead of WARNing about it
    forever, converge the tree back to truth: restore/refresh the archive copy
    and remove the queue copy, committing the move when lifecycle commits are
    enabled. Fail-open — on any error the file simply stays vetoed by the
    ledger.
    """
    try:
        archive_dir = get_workspace_dir() / "orders" / "complete"
        archive_dir.mkdir(parents=True, exist_ok=True)
        archive_file = archive_dir / json_file.name
        if not archive_file.exists():
            data = dict(data)
            data["status"] = terminal_status
            data["rearchivedAt"] = datetime.now().isoformat()
            data["rearchivedBy"] = "BUG-0294 ledger self-heal"
            archive_file.write_text(json.dumps(data, indent=2), encoding="utf-8")
        json_file.unlink(missing_ok=True)
        _commit_lifecycle_transition(
            [archive_file, json_file],
            f"lifecycle: re-archive {order_id} ({terminal_status}) — ledger self-heal",
        )
    except Exception:
        pass


def _skipped_orders_path() -> Path:
    """Path to the persisted operator skip list (.mso/config/skipped-orders.json)."""
    return get_workspace_dir() / "config" / "skipped-orders.json"


def load_skipped_orders() -> dict:
    """Load the skip list as a dict keyed by order ID.

    Returns {} on any error (missing file, parse failure) — same tolerant
    pattern as load_completion_config().
    """
    try:
        return json.loads(_skipped_orders_path().read_text(encoding="utf-8"))
    except Exception:
        return {}


def load_skipped_order_ids() -> set:
    """Return the set of order IDs in the skip list."""
    return set(load_skipped_orders().keys())


def add_skipped_order(
    order_id: str,
    *,
    reason: str = "",
    voyage_id: str = "",
    skipped_by: str = "cli",
) -> None:
    """Upsert an order into the skip list (BUG-MSO-2026-0288).

    Preserves the existing ``skippedAt`` timestamp if the entry already exists
    (idempotent re-skip).  Creates ``config/`` if needed.
    """
    path = _skipped_orders_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    data = load_skipped_orders()
    existing = data.get(order_id, {})
    data[order_id] = {
        "skippedAt": existing.get("skippedAt", datetime.now(timezone.utc).isoformat()),
        "skippedBy": skipped_by,
        "reason": reason,
        "voyageId": voyage_id,
    }
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")


def remove_skipped_order(order_id: str) -> bool:
    """Remove an order from the skip list.

    Returns True if it was present (useful for ``mso order unskip`` reporting).
    """
    data = load_skipped_orders()
    if order_id not in data:
        return False
    del data[order_id]
    path = _skipped_orders_path()
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return True


def scan_all_queues() -> List[Dict[str, Any]]:
    """Scan ALL queue directories with tiered priority (v7.0).

    Priority tiers (lower = higher priority):
    T0: explicit/     (0)   - Captain's direct orders
    T1: security/     (100) - Security issues (LKT-generated)
    T2: bugs/         (200) - Bug reports (any crew)
    T3: requests/     (300) - Service requests
    T4: orders/       (400) - Standard orders
    T5: defects/      (500) - QA findings (BOS-generated)
    T6: breakdown/    (600) - Sub-orders from breakdown
    T7: high-level/   (700) - Needs NAV breakdown first
    """
    global WAITING_ON_DEPS, _QUEUE_READ_ERRORS
    WAITING_ON_DEPS = {}
    _QUEUE_READ_ERRORS = []
    all_items = []
    queues_dir = get_queues_dir()
    # BUG-MSO-2026-0263: orders already archived terminal must never be re-dispatched,
    # even if a stale PENDING copy resurfaced in a queue tier.
    terminal_ids = _terminal_order_ids()
    # BUG-MSO-2026-0294: the runtime ledger is the GIT-IMMUNE gate. The archive
    # dirs above are working-tree state a `git reset --hard` can rewind together
    # with the resurrected queue copy (how BUG-0263's guard was defeated at PSG);
    # the gitignored ledger survives any git operation.
    ledger_view = order_ledger.load_view(get_workspace_dir())
    # BUG-MSO-2026-0294: ids owned by LIVE crews right now (belt-and-braces for
    # claims the ledger missed — e.g. written by an older engine version).
    inflight_ids = _live_crew_order_ids()
    # BUG-MSO-2026-0288: operator-skipped orders are silently dropped (no dispatch, no WARN).
    skipped_ids = load_skipped_order_ids()

    # Priority sub-sort within tier
    priority_sub = {"CRITICAL": 0, "HIGH": 10, "MEDIUM": 20, "NORMAL": 20, "LOW": 30}

    # Order type to default role mapping
    order_roles = {
        "FIX": "SHP", "BUG": "SHP", "TEST": "SHP", "SEC": "LKT",
        "FTR": "NAV", "RFT": "SHP", "DOC": "SCR", "INV": "LKT"
    }

    # Tier definitions: (queue_name, tier_offset, item_type, default_role_override)
    tier_configs = [
        ("explicit",   0,   "EXPLICIT",   None),
        ("security",   100, "SECURITY",   "SHP"),
        ("bugs",       200, "BUG",        "SHP"),
        ("orders",     400, "ORDER",      None),
        ("defects",    500, "DEFECT",     "SHP"),
        ("breakdown",  600, "BREAKDOWN",  None),
        ("high-level", 700, "HIGH-LEVEL", "NAV"),
    ]

    for queue_name, tier_offset, item_type, default_role in tier_configs:
        queue_path = queues_dir / queue_name
        if not queue_path.exists():
            continue
        for json_file in queue_path.glob("*.json"):
            try:
                data = _read_order_file_tolerant(json_file)
                # v2.0.3: Normalize defect fields to standard order fields
                status = data.get("status", "PENDING")
                if queue_name == "defects":
                    # Defects use OPEN/CLOSED; treat OPEN as dispatchable
                    if status not in ("OPEN", "PENDING"):
                        continue
                    # Map defect-specific fields to standard order fields
                    if "defectId" in data and "orderId" not in data:
                        data["orderId"] = data["defectId"]
                    if "affectedRepo" in data and "targetRepo" not in data:
                        data["targetRepo"] = data["affectedRepo"]
                    if "affectedBranch" in data and "voyageBranch" not in data:
                        data["voyageBranch"] = data["affectedBranch"]
                    if "severity" in data and "priority" not in data:
                        data["priority"] = data["severity"]
                else:
                    if status != "PENDING":
                        continue

                priority_str = data.get("priority", "MEDIUM")
                sub_pri = priority_sub.get(priority_str, 20)
                # v8.6.1: Use resolve helper for backwards-compat
                resolved_role, resolved_type = resolve_order_fields(data)
                order_type = resolved_type or "FIX"

                # default_role is a fallback, not an override — order's own targetRole/role wins
                target_role = resolved_role or default_role or order_roles.get(order_type, "SHP")

                # v8.6: Resolve ID from orderId or id or filename stem
                item_id = data.get("orderId") or data.get("id") or json_file.stem
                # BUG-MSO-2026-0288: operator explicitly skipped — silent drop, no WARN.
                if item_id in skipped_ids:
                    continue
                # BUG-MSO-2026-0263: veto re-dispatch of an order already archived terminal
                # (resurfaced stale queue copy). Never re-run / re-converge completed work.
                # Emit the WARN at most once per dispatcher process (BUG-MSO-2026-0288).
                if item_id in terminal_ids:
                    if item_id not in _BUG0263_WARNED:
                        write_lifecycle_event(
                            "WARN",
                            f"{item_id} in queues/{queue_name} but already archived in "
                            f"orders/complete|failed — skipping re-dispatch (BUG-0263 dedup)"
                        )
                        _BUG0263_WARNED.add(item_id)
                    # BUG-MSO-2026-0295: converge the tree back to truth instead
                    # of WARNing about the stale copy forever.
                    _self_heal_stale_queue_file(json_file, data, item_id, "COMPLETE")
                    continue
                # BUG-MSO-2026-0294: ledger says TERMINAL — veto regardless of what
                # the (possibly git-resurrected) queue file claims, and self-heal
                # the tree by re-archiving the stale copy (BUG-MSO-2026-0295).
                if ledger_view.is_terminal(item_id):
                    if item_id not in _BUG0263_WARNED:
                        write_lifecycle_event(
                            "WARN",
                            f"{item_id} in queues/{queue_name} but ledger records it "
                            f"{ledger_view.terminal.get(item_id, 'TERMINAL')} — skipping "
                            f"re-dispatch and re-archiving stale queue copy (BUG-0294 ledger)"
                        )
                        _BUG0263_WARNED.add(item_id)
                    _self_heal_stale_queue_file(
                        json_file, data, item_id,
                        ledger_view.terminal.get(item_id, "COMPLETE"))
                    continue
                # BUG-MSO-2026-0294: a LIVE crew already owns this order (ledger claim
                # with live pid, or the crew's own state.json says so) — never hand it
                # to a second crew. Silent skip: this is normal in-flight state.
                if ledger_view.live_claim(item_id) or item_id in inflight_ids:
                    continue
                # BUG-0248 / PSG bug 3 (advance-loss loop): if a rewind reverted the
                # file's targetRole behind the ledger's durable role progression,
                # trust the LEDGER — dispatch at the real role and heal the file so
                # the order never loops back to an already-completed role.
                _ledger_role = ledger_view.current_role(item_id)
                if _ledger_role and _ledger_role != target_role:
                    if item_id not in _BUG0263_WARNED:
                        write_lifecycle_event(
                            "WARN",
                            f"{item_id} file targetRole={target_role} but ledger records "
                            f"progression to {_ledger_role} — dispatching at ledger role and "
                            f"healing file (BUG-0248 advance-loss)"
                        )
                        _BUG0263_WARNED.add(item_id)
                    target_role = _ledger_role
                    try:
                        data["targetRole"] = _ledger_role
                        json_file.write_text(json.dumps(data, indent=2), encoding="utf-8")
                    except OSError:
                        pass
                # v8.6: Derive title from data or order ID
                item_title = data.get("title") or data.get("description", "")
                if not item_title:
                    # Derive readable title from order ID (e.g. SHP-LOCK-091A → LOCK-091A)
                    parts = item_id.split("-", 1)
                    item_title = parts[1] if len(parts) > 1 else item_id

                all_items.append({
                    "type": item_type,
                    "subtype": order_type,
                    "id": item_id,
                    "title": item_title,
                    "priority": tier_offset + sub_pri,
                    "role": target_role,
                    "path": str(json_file),
                    "data": data,
                    "queue": queue_name,
                })
            except Exception as e:
                msg = f"Unreadable order file skipped: {json_file.name} — {e}"
                print_warn(msg)
                write_lifecycle_event("ERROR", msg)
                _QUEUE_READ_ERRORS.append(str(json_file))

    # Scan requests subdirectories (tier 300)
    requests_dir = queues_dir / "requests"
    request_roles = {
        "planning": "NAV", "investigation": "LKT", "qa": "BOS",
        "security-scan": "LKT", "documentation": "SCR"
    }
    if requests_dir.exists():
        for subdir_name, role in request_roles.items():
            subdir = requests_dir / subdir_name
            if not subdir.exists():
                continue
            for json_file in subdir.glob("*.json"):
                try:
                    data = _read_order_file_tolerant(json_file)
                    if data.get("status", "PENDING") != "PENDING":
                        continue
                    priority_str = data.get("priority", "MEDIUM")
                    sub_pri = priority_sub.get(priority_str, 20)
                    # v8.6: Resolve ID and title consistently
                    req_id = data.get("orderId") or data.get("id") or json_file.stem
                    # BUG-MSO-2026-0288: operator explicitly skipped — silent drop, no WARN.
                    if req_id in skipped_ids:
                        continue
                    # BUG-MSO-2026-0263: veto re-dispatch of an already-archived order.
                    # Emit the WARN at most once per dispatcher process (BUG-MSO-2026-0288).
                    if req_id in terminal_ids:
                        if req_id not in _BUG0263_WARNED:
                            write_lifecycle_event(
                                "WARN",
                                f"{req_id} in queues/requests/{subdir_name} but already archived "
                                f"in orders/complete|failed — skipping re-dispatch (BUG-0263 dedup)"
                            )
                            _BUG0263_WARNED.add(req_id)
                        continue
                    req_title = data.get("title") or data.get("description", "")
                    if not req_title:
                        parts = req_id.split("-", 1)
                        req_title = parts[1] if len(parts) > 1 else req_id

                    resolved_role, _ = resolve_order_fields(data)
                    all_items.append({
                        "type": "REQUEST",
                        "subtype": subdir_name.upper(),
                        "id": req_id,
                        "title": req_title,
                        "priority": 300 + sub_pri,
                        "role": resolved_role or role,
                        "path": str(json_file),
                        "data": data,
                        "queue": f"requests/{subdir_name}",
                    })
                except Exception as e:
                    msg = f"Unreadable request file skipped: {json_file.name} — {e}"
                    print_warn(msg)
                    write_lifecycle_event("ERROR", msg)
                    _QUEUE_READ_ERRORS.append(str(json_file))

    # Check for circular dependencies
    cycles = detect_circular_dependencies(all_items)
    circular_ids = set()
    for cycle in cycles:
        cycle_str = " -> ".join(cycle)
        print_error(f"CIRCULAR DEPENDENCY: {cycle_str}")
        write_lifecycle_event("ERROR", f"Circular dependency: {cycle_str}")
        circular_ids.update(cycle[:-1])  # Exclude the repeated last element

    # Filter: dependency check + escalation blocking + role sequence gates
    _, blocking_voyages = scan_escalations()

    # v8.2: Build voyage role status for gate enforcement
    voyage_role_status = build_voyage_role_status() if ROLE_SEQUENCES else {}

    dispatchable = []
    for item in all_items:
        item_id = item["id"]

        # Skip circular dependency items
        if item_id in circular_ids:
            continue

        # Skip items blocked by escalation
        voyage_id = item["data"].get("voyageId", "")
        if voyage_id and voyage_id in blocking_voyages:
            WAITING_ON_DEPS[item_id] = [f"ESCALATION (voyage {voyage_id} blocked)"]
            continue

        # Check dependencies
        satisfied, waiting_on = check_dependencies_satisfied(item["data"])
        if not satisfied:
            WAITING_ON_DEPS[item_id] = waiting_on
            # BUG-MSO-2026-0274: emit a DEP_HELD lifecycle event for EVERY
            # unmet-dependency hold (PENDING / IN_PROGRESS / NAV_REVIEW_PENDING /
            # absent dep), so a held candidate is observable — not only the
            # BUG-0251 STALLED(cause=ERROR) special case. Annotate each dep with
            # the reason it isn't satisfying where it's readable.
            archive_dir = get_workspace_dir() / "orders" / "complete"
            dep_notes = []
            for dep_id in waiting_on:
                note = dep_id
                dep_file = archive_dir / f"{dep_id}.json"
                if dep_file.exists():
                    try:
                        dep_data = json.loads(dep_file.read_text(encoding='utf-8'))
                        # BUG-MSO-2026-0251: a zero-progress ERROR escalation never
                        # satisfies a dependency — call it out explicitly.
                        if dep_data.get("status") == "STALLED" and dep_data.get("stalledCause") == "ERROR":
                            note = f"{dep_id}(STALLED,cause=ERROR — zero-progress; human review required)"
                        else:
                            note = f"{dep_id}(archived {dep_data.get('status')})"
                    except Exception:
                        pass
                dep_notes.append(note)
            # BUG-MSO-2026-0274: emit DEP_HELD only when this item FIRST becomes
            # held or when its waiting_on set changes — scan_all_queues runs every
            # ~10s, so logging on every tick would flood the (line-capped) log and
            # bury higher-signal events.
            if _DEP_HELD_LOGGED.get(item_id) != waiting_on:
                write_lifecycle_event(
                    "DEP_HELD",
                    f"{item_id} held: waiting on {', '.join(dep_notes)}"
                )
                _DEP_HELD_LOGGED[item_id] = list(waiting_on)
            continue

        # v8.5: Explicit dependencies take precedence over role sequence gate.
        # If an order has dependsOn and all deps are satisfied (checked above),
        # the QM's planned execution order is authoritative — skip the generic
        # template-based role gate. This prevents deadlocks when the dependency
        # chain order differs from the template role sequence (e.g., COX before SCR).
        has_explicit_deps = bool(item["data"].get("dependsOn"))

        # BUG-MSO-2026-0248: skip orders that are mid-transition (complete_order is
        # writing the next-role PENDING file but hasn't handed off to dispatch yet).
        # Defense-in-depth: the idempotency guard in complete_order is the primary fix;
        # this gate prevents even the transient PENDING window from being selected.
        # BUG-MSO-2026-0262: clear-on-settle — if the on-disk state is already PENDING
        # (transition has completed), discard the stale gate so subsequent ticks can
        # dispatch the next role.  The gate only needs to hold for the intra-tick race
        # window; surviving across ticks strands the order indefinitely.
        if item_id in ORDERS_IN_TRANSITION:
            if item["data"].get("status") == "PENDING":
                ORDERS_IN_TRANSITION.discard(item_id)
                write_lifecycle_event(
                    "DISPATCH",
                    f"{item_id} MID_TRANSITION gate cleared (transition settled to PENDING) — BUG-0262"
                )
            else:
                WAITING_ON_DEPS[item_id] = ["MID_TRANSITION"]
                continue

        # v8.2: Role sequence gate — ensure prior roles completed in this voyage
        # Only enforced for orders WITHOUT explicit dependencies.
        if not has_explicit_deps and voyage_id and voyage_id in voyage_role_status:
            gate_passed, missing = check_role_sequence_gate(
                item["data"], voyage_role_status[voyage_id]
            )
            if not gate_passed:
                WAITING_ON_DEPS[item_id] = [f"ROLE GATE: {r}" for r in missing]
                continue

        dispatchable.append(item)

    # BUG-MSO-2026-0274: drop DEP_HELD dedup entries for items no longer held, so
    # the map stays bounded and a genuine re-hold (held -> dispatched -> held) logs
    # afresh rather than being silently suppressed by a stale entry.
    for _stale in [k for k in _DEP_HELD_LOGGED if k not in WAITING_ON_DEPS]:
        _DEP_HELD_LOGGED.pop(_stale, None)

    return sorted(dispatchable, key=lambda x: x["priority"])


def scan_review_queue() -> List[Dict[str, Any]]:
    """Return all orders currently parked in queues/review/ (NAV_REVIEW_PENDING).

    BUG-MSO-2026-0226: Eight Bells must NOT fire while orders are held here,
    and the dispatcher status must surface this count explicitly.
    """
    review_dir = get_workspace_dir() / "queues" / "review"
    if not review_dir.exists():
        return []
    items = []
    for json_file in review_dir.glob("*.json"):
        try:
            data = json.loads(json_file.read_text(encoding='utf-8'))
            items.append({
                "id": data.get("orderId") or data.get("id") or json_file.stem,
                "title": data.get("title", json_file.stem),
                "role": data.get("targetRole", data.get("role", "?")),
                "status": data.get("status", "NAV_REVIEW_PENDING"),
            })
        except Exception:
            pass
    return items


# v7.0: Stale escalation threshold (minutes) — warn Captain if escalation pending too long
ESCALATION_STALE_MINUTES = 60

def scan_escalations() -> tuple:
    """Scan escalation queue (v7.0). Returns (pending_count, blocking_voyage_ids).

    Escalations are NOT dispatched - they need human (Captain/QM) review.
    Blocking escalations hold all orders for the same voyageId.
    Stale escalations (> ESCALATION_STALE_MINUTES) are logged as warnings.
    """
    esc_dir = get_queues_dir() / "escalations"
    if not esc_dir.exists():
        return 0, set()

    pending_count = 0
    blocking_voyages = set()
    now = datetime.now()

    for json_file in esc_dir.glob("*.json"):
        try:
            data = json.loads(json_file.read_text(encoding='utf-8'))
            if data.get("status") == "PENDING":
                pending_count += 1
                esc_id = data.get("id", json_file.stem)

                # Check for stale escalation
                created_at = data.get("createdAt", "")
                if created_at:
                    try:
                        created_time = datetime.fromisoformat(created_at)
                        age_minutes = (now - created_time).total_seconds() / 60
                        if age_minutes > ESCALATION_STALE_MINUTES:
                            block_tag = " [BLOCKING]" if data.get("blocking") else ""
                            _ep = current_persona()
                            print_warn(f"STALE ESCALATION{block_tag}: {esc_id} pending for {int(age_minutes)} minutes — requires {_ep.term('userTitle')}/{_ep.term('leadTitle')} resolution!")
                            write_lifecycle_event("ESCALATION", f"STALE: {esc_id} pending {int(age_minutes)}min{block_tag}")
                    except (ValueError, TypeError):
                        pass

                if data.get("blocking") and data.get("voyageId"):
                    blocking_voyages.add(data["voyageId"])
        except Exception:
            pass

    return pending_count, blocking_voyages


def get_available_crews(max_crews: int = 2) -> List[int]:
    """Get list of available crew numbers (not currently active).

    v7.1: If a crew is in ACTIVE_PROCESSES with a dead PID and unprocessed state,
    process completion first before marking as available. This prevents orphaning orders.
    """
    available = []

    for crew_num in range(1, 6):
        # Check if there's an active process
        pid = ACTIVE_PROCESSES.get(crew_num)
        if not pid:
            pid = read_crew_pid(crew_num)
        if pid and is_process_alive(pid):
            continue  # Still running

        # v7.1 FIX: If crew is tracked in ACTIVE_PROCESSES with a dead PID,
        # ensure completion is processed before making it available
        if crew_num in ACTIVE_PROCESSES:
            state = read_crew_state(crew_num)
            status = state.get("status", "") if state else ""
            if status and status != "RUNNING":
                # Dead PID with non-RUNNING state — process completion now
                if status not in TERMINAL_STATES:
                    print_warn(f"Crew {crew_num} dead with state '{status}' in get_available_crews - treating as CRASHED")
                    write_lifecycle_event("WARN", f"Crew {crew_num} dead with state '{status}' - forced CRASHED in get_available_crews")
                process_crew_completion(crew_num)
                del ACTIVE_PROCESSES[crew_num]
                # BUG-MSO-2026-0266: reset state to IDLE so the orphan scan later
                # in the same dispatcher tick doesn't re-call process_crew_completion
                # on the still-COMPLETE crew state, causing a spurious second convergence.
                _idle = {"crewNumber": crew_num, "status": "IDLE", "role": "-", "orderId": "-"}
                (get_crew_dir(crew_num) / "state.json").write_text(
                    json.dumps(_idle, indent=2), encoding='utf-8'
                )
            else:
                continue  # State is RUNNING or unknown — not safe to reuse yet

        # Check state file
        state = read_crew_state(crew_num)
        if state:
            status = state.get("status", "")
            if status == "RUNNING":
                continue  # State says running

        available.append(crew_num)

        # Stop once we have enough candidates
        if len(available) >= max_crews:
            break

    return available


def _ws_for_item(item: Dict[str, Any]) -> Optional[Path]:
    """Workspace dir for an item's ledger writes — derived from its queue path.

    BUG-MSO-2026-0294: queue files live at <ws>/queues/<tier>[/<sub>]/x.json.
    Deriving the workspace from the file's own location keeps ledger writes in
    the SAME workspace as the queue mutation (and keeps tests that point items
    at tmp dirs hermetic). Returns None for items WITHOUT a path (synthetic /
    already-moved) — the caller skips the ledger write; an item we cannot
    locate on disk cannot carry a durable claim anyway.
    """
    raw = item.get("path")
    if not raw:
        return None
    try:
        for parent in Path(raw).parents:
            if parent.name == "queues":
                return parent.parent
    except Exception:
        pass
    return get_workspace_dir()


def mark_work_item_in_progress(item: Dict[str, Any], crew_num: int):
    """Mark a work item as IN_PROGRESS."""
    try:
        path = Path(item["path"])
        data = item["data"]
        data["status"] = "IN_PROGRESS"
        data["assignedTo"] = {"crew": crew_num, "role": item["role"]}
        data["startedAt"] = datetime.now().isoformat()
        path.write_text(json.dumps(data, indent=2), encoding='utf-8')
    except Exception as e:
        print_warn(f"Could not update status for {item['id']}: {e}")
    # BUG-MSO-2026-0294: the file claim above is a working-tree write that a
    # git reset can erase — the ledger claim is the durable one.
    _ledger_ws = _ws_for_item(item)
    if _ledger_ws is not None:
        order_ledger.record_claimed(item["id"], item.get("role", ""), crew_num,
                                    workspace_dir=_ledger_ws)


def mark_work_item_failed(item: Dict[str, Any], reason: str = "") -> None:
    """Mark a work item as FAILED so the dispatcher loop stops re-attempting it.

    BUG-ADM-2026-0008 (v2.5.5): added so dispatch_crew can fail-fast on
    misconfigured orders (e.g. SHP/BOS without a resolvable targetRepo)
    rather than spinning the queue.
    """
    try:
        path = Path(item["path"])
        data = item["data"]
        data["status"] = "FAILED"
        data["failedAt"] = datetime.now().isoformat()
        if reason:
            data["failureReason"] = reason
        path.write_text(json.dumps(data, indent=2), encoding='utf-8')
        _ledger_ws = _ws_for_item(item)  # BUG-MSO-2026-0294
        if _ledger_ws is not None:
            order_ledger.record_terminal(item["id"], "FAILED", workspace_dir=_ledger_ws)
    except Exception as e:
        print_warn(f"Could not mark {item.get('id', '?')} FAILED: {e}")


def _build_repo_routing_rules(role: str, target_repo: str, docs_repo: str = "") -> str:
    """Build repo routing rules section for crew prompts (v8.10/v2.0.6).

    Enforces which repos each role can write to:
    - LKT/SCR: Reports and docs go to docs_repo ONLY (if configured), else target repo docs/
    - SHP/BOS: Code and tests go to the target service repo ONLY
    - NAV/COX: May write to both (plans touch docs, reviews touch code)
    - ALL roles: May always write to .mso/ (reports, handoffs, queues)

    docs_repo: optional separate documentation repo (e.g. "eml-documentation").
               If empty, SCR/LKT write to docs/ within the target repo.
    """
    # BUG-ADM-2026-0008: the previous fallback ("the target service repo") looked
    # like an unrendered placeholder and caused Sonnet 4.6 SHP crews to exit in
    # 1 iteration with no commits. The new fallback is unambiguously diagnostic
    # so an operator can see at a glance that the order is misconfigured.
    target_label = (
        f"repos/{target_repo}/" if target_repo
        else "<TARGET-REPO-NOT-RESOLVED — fix the order's `targetRepo` field "
             "or the project registry's `repo` entry>"
    )
    has_docs_repo = bool(docs_repo)
    docs_label = f"repos/{docs_repo}/" if has_docs_repo else f"{target_label}docs/"

    if has_docs_repo:
        lkt_rule = (
            f"You are a Lookout. Write ALL reports and investigation artifacts to "
            f"repos/{docs_repo}/ (following the existing folder structure). "
            f"You must NEVER create, modify, or add files to the target service repo. "
            f"You may read the target repo for investigation but must not write to it."
        )
        scr_rule = (
            f"You are a Scribe. Write ALL documentation to repos/{docs_repo}/ "
            f"(following the existing folder structure). "
            f"You must NEVER create or modify files in target service repos."
        )
        lkt_cannot = ["target"]
        scr_cannot = ["target"]
        shp_cannot = [docs_repo]
        bos_cannot = [docs_repo]
    else:
        lkt_rule = (
            f"You are a Lookout. Write ALL reports and investigation artifacts to "
            f"the docs/ directory within the target repo (`{target_label}docs/`). "
            f"You may read all files in the target repo for investigation."
        )
        scr_rule = (
            f"You are a Scribe. Write ALL documentation to the target repo (`{target_label}`). "
            f"Use the docs/ subdirectory for documentation files unless the order specifies otherwise."
        )
        lkt_cannot = []
        scr_cannot = []
        shp_cannot = []
        bos_cannot = []

    ROLE_REPO_RULES = {
        "LKT": {
            "rule": lkt_rule,
            "cannot_write_labels": [f"`{target_label}`"] if lkt_cannot else [],
        },
        "SCR": {
            "rule": scr_rule,
            "cannot_write_labels": [f"`{target_label}`"] if scr_cannot else [],
        },
        "SHP": {
            "rule": (
                f"You are a Shipwright. Write ALL code changes to the target service repo. "
                + (f"You must NEVER create or modify files in repos/{docs_repo}/. " if has_docs_repo else "")
                + "Documentation changes are the Scribe's responsibility."
            ),
            "cannot_write_labels": [f"`repos/{docs_repo}/`"] if shp_cannot else [],
        },
        "BOS": {
            "rule": (
                f"You are a Bosun. Write ALL test code and QA artifacts to the target service repo. "
                + (f"You must NEVER create or modify files in repos/{docs_repo}/." if has_docs_repo else "")
            ),
            "cannot_write_labels": [f"`repos/{docs_repo}/`"] if bos_cannot else [],
        },
        "NAV": {
            "rule": (
                f"You are a Navigator. You may write plans to the target repo"
                + (f" and repos/{docs_repo}/ as needed. Prefer documentation repo for "
                   f"architecture documents and the target repo for implementation plans."
                   if has_docs_repo else ".")
            ),
            "cannot_write_labels": [],
        },
        "COX": {
            "rule": (
                f"You are a Coxswain. You may write review artifacts to the target repo"
                + (f" and repos/{docs_repo}/ as needed." if has_docs_repo else ".")
            ),
            "cannot_write_labels": [],
        },
    }

    rules = ROLE_REPO_RULES.get(role, {})
    if not rules:
        return ""

    section = "\n## Repo Routing Rules (MANDATORY)\n\n"
    section += f"**Target Repo:** `{target_label}`\n"
    if has_docs_repo:
        section += f"**Documentation Repo:** `repos/{docs_repo}/`\n\n"
    else:
        section += f"**Documentation Repo:** `{target_label}docs/` (within target repo)\n\n"
    section += f"**YOUR RULE:** {rules['rule']}\n\n"

    if rules["cannot_write_labels"]:
        section += f"**DO NOT WRITE TO:** {', '.join(rules['cannot_write_labels'])}\n\n"

    section += "**Always allowed:** `.mso/` directory (reports, handoffs, queues, logs)\n"

    return section


def generate_prompt_for_item(item: Dict[str, Any]) -> str:
    """Generate a prompt file path for the work item.

    v8.8: Enhanced to inject all order metadata (references, tables, deliverables,
    requirementIds) into the active prompt so crews have full context.
    v8.10: Repo routing rules injected per role — enforces write boundaries.
    """
    prompts_dir = get_workspace_dir() / "prompts" / "active"
    prompts_dir.mkdir(parents=True, exist_ok=True)

    prompt_file = prompts_dir / f"{item['id']}-{item['role']}.md"

    # Generate prompt with full order context
    role = item["role"]
    item_id = item["id"]
    item_type = item["type"]
    subtype = item.get("subtype", "")
    title = item["title"]
    data = item["data"]
    description = data.get("description", "")

    # Get acceptance criteria if available
    # Supports both legacy string arrays and structured AC objects (PLAN-AC-SCHEMA)
    criteria = data.get("acceptanceCriteria", [])
    def _format_ac(c):
        if isinstance(c, dict):
            sev = f" [{c.get('severity', 'blocking')}]" if c.get('severity') else ""
            return f"- {c.get('description', str(c))}{sev}"
        return f"- {c}"
    criteria_text = "\n".join(_format_ac(c) for c in criteria) if criteria else "- Complete the task as described"

    # Get files if available
    files = data.get("files", [])
    files_text = "\n".join(f"- {f}" for f in files) if files else "- Determine relevant files"

    # v8.8: Requirement IDs
    req_ids = data.get("requirementIds", [])
    req_section = ""
    if req_ids:
        req_section = "\n## Requirement IDs\n"
        req_section += "\n".join(f"- `{r}`" for r in req_ids)
        req_section += "\n"

    # v8.8: References (reference implementations, target paths, etc.)
    references = data.get("references", {})
    ref_section = ""
    if references:
        ref_section = "\n## References\n"
        if isinstance(references, list):
            ref_section += "\n".join(f"- `{r}`" for r in references) + "\n"
        else:
            ref_section += "\n| Key | Path |\n|-----|------|\n"
            for key, val in references.items():
                ref_section += f"| {key} | `{val}` |\n"

    # v8.8: Oracle tables (domain-specific but critical for data persistence orders)
    oracle_tables = data.get("oracleTables", [])
    oracle_section = ""
    if oracle_tables:
        oracle_section = "\n## Oracle Tables\n"
        oracle_section += "\n| Table | Schema | Access | Notes |\n|-------|--------|--------|-------|\n"
        for t in oracle_tables:
            table = t.get("table", "?")
            schema = t.get("schema", "?")
            access = t.get("access", "?")
            note = t.get("note", "")
            oracle_section += f"| {table} | {schema} | {access} | {note} |\n"

    # v8.8: SQL Server database name
    sql_db = data.get("sqlServerDatabase", "")
    sql_section = ""
    if sql_db:
        sql_section = f"\n## SQL Server Database\n- `{sql_db}`\n"

    # v8.8: Deliverables checklist
    deliverables = data.get("deliverables", [])
    deliv_section = ""
    if deliverables:
        deliv_section = "\n## Expected Deliverables\n"
        deliv_section += "\n".join(f"- [ ] {d}" for d in deliverables)
        deliv_section += "\n"

    # v8.8: Depends-on (dependency tracking)
    depends_on = data.get("dependsOn", [])
    dep_section = ""
    if depends_on:
        dep_section = "\n## Dependencies\n"
        dep_section += "\n".join(f"- `{d}`" for d in depends_on)
        dep_section += "\n"

    # v8.9: Prior role deliverables (plan + handoffs) for downstream phases
    nav_plan = data.get("navPlan", "")
    nav_handoff = data.get("navHandoff", "")
    shp_handoff = data.get("shpHandoff", "")
    nav_section = ""
    if nav_plan or nav_handoff or shp_handoff:
        nav_section = "\n## Prior Role Deliverables\n"
        nav_section += "**READ THESE FIRST** — previous roles have explored and implemented. Review their handoffs before starting.\n\n"
        if shp_handoff:
            nav_section += f"- **Shipwright Handoff (what was built):** `{shp_handoff}`\n"
        if nav_handoff:
            nav_section += f"- **Navigator Handoff (original instructions):** `{nav_handoff}`\n"
        if nav_plan:
            nav_section += f"- **Navigator Plan (full detail):** `{nav_plan}`\n"
        nav_section += "\nThe handoffs contain file lists, warnings, and traceability requirements.\n"

    # v7.3: Include previous timeout briefs so next crew knows what was tried
    timeout_briefs = data.get("timeoutBriefs", [])
    briefs_section = ""
    if timeout_briefs:
        briefs_section = "\n## Previous Attempts (Timed Out)\n"
        briefs_section += "The following crews attempted this order but timed out. Review their briefs to avoid repeating work:\n\n"
        for tb in timeout_briefs:
            briefs_section += f"**{tb.get('timestamp', 'unknown')} — Crew {tb.get('crew', '?')} ({tb.get('crewName', '?')}) — {tb.get('reason', 'TIMEOUT')}**\n"
            briefs_section += tb.get("brief", "(no brief captured)") + "\n\n"

    # v8.10: Repo routing rules — enforce which repos each role can write to
    # v2.0.6: docs_repo is optional; absent = SCR/LKT write to target repo's docs/ dir
    # BUG-ADM-2026-0008 (v2.5.5): if targetRepo is omitted on the order, resolve
    # from the project registry. Previously the prompt fell through to the
    # literal fallback string "the target service repo", which Sonnet 4.6
    # interpreted as a placeholder and exited in 1 iteration with no commits.
    target_repo = data.get("targetRepo", "")
    if not target_repo:
        target_repo = _resolve_target_repo_from_project(data)
    docs_repo = data.get("documentationRepo", "")
    repo_rules = _build_repo_routing_rules(role, target_repo, docs_repo)

    # v2.0.0: Managed repo instructions
    # v2.0.1: Per-order voyage branch — prefer explicit voyageBranch, then voyageId, then global env var
    voyage_branch = data.get("voyageBranch", "")
    voyage_id = data.get("voyageId", "")
    if voyage_branch:
        order_branch = voyage_branch
    elif voyage_id:
        order_branch = f"voyage/{voyage_id}" if not voyage_id.startswith("voyage/") else voyage_id
    else:
        order_branch = ""
    branch_ref = (order_branch or ACTIVE_VOYAGE_BRANCH).replace("refs/heads/", "")
    managed_repo_section = ""
    if target_repo and branch_ref:
        managed_repo_section = f"""
## Working Directory (Managed Repo)

Your target repo `{target_repo}` has been **pre-cloned** to your crew working directory.
- **Path:** Available via `$MAESTRO_REPO_PATH` env var (resolves to the voyage worktree)
- **Branch:** `{branch_ref}` (already checked out — DO NOT create or switch branches)
- **DO NOT** clone the repo yourself — it is already ready
- **DO** commit and push your changes to `{branch_ref}` when complete
- **DO NOT** create temp directories (`.local-nuget/`, etc.) outside `$MAESTRO_TEMP`
- Use `$MAESTRO_TEMP/nuget-local/` for any local NuGet package workarounds
"""

    prompt_content = f"""# {item_type}: {item_id}

## Role: {role}
## Title: {title}

## Description
{description}
{req_section}{ref_section}{oracle_section}{sql_section}{nav_section}{deliv_section}{dep_section}
## Target Files
{files_text}

## Acceptance Criteria
{criteria_text}
{briefs_section}{managed_repo_section}{repo_rules}
## Instructions
Complete this {subtype or item_type} order following the established patterns in the codebase.
When complete, commit and push your changes, then update the order status and signal completion.
"""

    prompt_file.write_text(prompt_content, encoding='utf-8')
    return str(prompt_file)


def _voyage_branch_has_post_started_commit(order_data: Dict[str, Any]) -> bool:
    """BUG-MSO-2026-0023: detect 'silent completion' before re-queuing.

    The dispatcher's previous behaviour was to REQUEUE any order whose crew
    timed out / crashed, even if the crew had already committed its work to
    the voyage branch before the timeout fired (typical BLD flow: commit
    work → enter brief-generation tail → tail exceeds timeout → process killed
    after the commit already shipped). Re-queueing in that case wastes ~$0.10-
    $0.50 in fresh-crew Claude inference per occurrence and confuses operators
    who see REQUEUE/TIMEOUT messages for work that's actually done.

    This helper checks the order's voyageBranch for a commit referencing the
    order ID, authored after the order's startedAt timestamp. If found, the
    timeout-handler treats it as a 'silent completion' and ADVANCEs the order
    to its next role (or COMPLETEs it) instead of REQUEUE.

    Returns True if a post-startedAt commit referencing the order ID exists
    on the voyage branch (local or remote-tracking ref). False if the check
    can't be made (missing fields, git error) — the conservative path is
    REQUEUE, matching legacy behaviour.
    """
    order_id = order_data.get("orderId") or order_data.get("id")
    voyage_branch = order_data.get("voyageBranch")
    started_at = order_data.get("startedAt")

    if not (order_id and voyage_branch and started_at):
        return False

    # Prefer the local ref if it exists; fall back to refs/remotes/origin/.
    # Either is fine for `git log` — the SHA chain is the same regardless of
    # whether the local-tracking ref exists.
    candidate_refs = [voyage_branch, f"refs/remotes/origin/{voyage_branch}"]

    for ref in candidate_refs:
        try:
            verify = subprocess.run(
                ["git", "rev-parse", "--verify", "--quiet", ref],
                capture_output=True, timeout=5
            )
            if verify.returncode != 0:
                continue

            # --since accepts ISO-8601; restrict log to commits after startedAt.
            # %s prints only the subject line, which is where order IDs land
            # (e.g. `bug(BUG-MSO-2026-0023): ...` or `feat(FTR-MSO-...): ...`).
            log_result = subprocess.run(
                ["git", "log", "--format=%s", f"--since={started_at}", ref],
                capture_output=True, text=True, timeout=10
            )
            if log_result.returncode != 0:
                continue

            for subject in log_result.stdout.splitlines():
                if order_id in subject:
                    return True
            # Found a valid ref but no matching commit; no need to check the other.
            return False
        except (subprocess.TimeoutExpired, Exception):
            continue

    return False


def recover_orphaned_order(order_id: str, crew_num: int, reason: str):
    """Reset an orphaned IN_PROGRESS order back to PENDING for re-dispatch.

    BUG-MSO-2026-0023: before re-queuing, check whether the voyage branch
    already has a commit referencing this order ID, authored after the
    order's startedAt. If so, the crew silently completed its work (committed
    + pushed, then died in the brief-generation tail past the timeout). In
    that case route through complete_order() so the order ADVANCEs to the
    next role (or archives as COMPLETE) instead of being wastefully re-queued
    to a fresh crew that would just notice the existing commit and ADVANCE.

    v7.3: Reads timeout brief from crew state and appends it to the order's
    timeoutBriefs array before re-queuing. This preserves a record of what
    was attempted so the next crew can pick up where the previous one left off.
    """
    # v7.3: Read timeout brief from crew state before re-queuing
    crew_state = read_crew_state(crew_num)
    timeout_brief = None
    if crew_state:
        timeout_brief = crew_state.get("timeoutBrief")

    # BUG-MSO-2026-0276: a REQUEUE-after-crash must re-validate the order's CURRENT
    # on-disk eligibility, not blindly flip the cached IN_PROGRESS order back to
    # PENDING. While the crew was running, a LEAD recovering by hand may have changed
    # the status (e.g. to BACKLOG), added a dependsOn, or moved the file out of the
    # scanned queues. Honour those mutations and abort cleanly (REQUEUE_ABORTED)
    # instead of silently re-dispatching over the top of them. The scanned-dir set
    # MUST mirror scan_all_queues() so "dispatchable here" means the same in both paths.
    queues_dir = get_queues_dir()
    search_dirs = [
        queues_dir / "explicit", queues_dir / "security", queues_dir / "bugs",
        queues_dir / "orders", queues_dir / "defects", queues_dir / "breakdown",
        queues_dir / "high-level",
    ]
    # Mirror scan_all_queues() EXACTLY: it only dispatches a fixed set of request
    # categories, so the requeue eligibility check must scan the same fixed set
    # (not every subdir under requests/) or the two paths could disagree.
    requests_dir = queues_dir / "requests"
    for sub_name in ("planning", "investigation", "qa", "security-scan", "documentation"):
        sub = requests_dir / sub_name
        if sub.exists():
            search_dirs.append(sub)

    # Locate the order by ID across the scanned queues, regardless of status.
    found_file = None
    found_data = None
    for search_dir in search_dirs:
        if not search_dir.exists():
            continue
        for json_file in search_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
            except Exception as e:
                # v7.1 FIX: Log errors instead of silently swallowing them
                print_warn(f"Error reading queue file {json_file}: {e}")
                continue
            file_order_id = data.get("orderId") or data.get("id") or json_file.stem
            if file_order_id == order_id:
                found_file = json_file
                found_data = data
                break
        if found_file is not None:
            break

    # AC-3: file moved out of the scanned queues (e.g. parked in queues/proposed/)
    # or deleted entirely — the LEAD has taken it out of circulation; do not resurrect.
    if found_file is None:
        order_ledger.record_released(order_id, f"REQUEUE_ABORTED file-not-in-queues: {reason}", workspace_dir=get_workspace_dir())  # BUG-MSO-2026-0294
        print_warn(f"REQUEUE aborted for {order_id}: not found in any scanned queue (Crew {crew_num} {reason})")
        write_lifecycle_event(
            "REQUEUE_ABORTED",
            f"{order_id} not re-dispatched: file-not-in-queues — parked/moved out of "
            f"dispatcher-scanned dirs (Crew {crew_num} {reason})"
        )
        return

    # AC-1: a LEAD changed the status away from IN_PROGRESS (e.g. BACKLOG) — the
    # order is deliberately no longer dispatchable; respect the intervention.
    current_status = found_data.get("status")
    if current_status != "IN_PROGRESS":
        order_ledger.record_released(order_id, f"REQUEUE_ABORTED status-changed: {current_status}", workspace_dir=get_workspace_dir())  # BUG-MSO-2026-0294
        print_warn(f"REQUEUE aborted for {order_id}: on-disk status is {current_status}, not IN_PROGRESS (Crew {crew_num} {reason})")
        write_lifecycle_event(
            "REQUEUE_ABORTED",
            f"{order_id} not re-dispatched: status-changed (on-disk={current_status}) — "
            f"manual intervention respected (Crew {crew_num} {reason})"
        )
        return

    # BUG-MSO-2026-0023: check whether the crew silently completed its work
    # (committed to the voyage branch) before timing out in the brief-generation
    # tail. If so, route through the normal ADVANCE/COMPLETE path instead of REQUEUE.
    if _voyage_branch_has_post_started_commit(found_data):
        write_lifecycle_event(
            "SILENT_COMPLETION_DETECTED",
            f"{order_id} timeout ({reason}) but commit found on "
            f"{found_data.get('voyageBranch', '?')} after startedAt — "
            f"advancing instead of re-queueing (Crew {crew_num})"
        )
        print_ok(
            f"Silent completion detected for {order_id}: commit present on voyage "
            f"branch; advancing instead of REQUEUE."
        )
        # complete_order handles the role-sequence ADVANCE or final COMPLETE archive.
        complete_order(order_id, crew_num, crew_state or {})
        return

    # BUG-MSO-2026-0285: PRESERVE in-flight crew work before requeue/STALLED.
    # A crew killed at the timeout (or crashed) may have real uncommitted work in
    # its worktree that the silent-completion check above can't see (it's not on
    # the voyage branch). Commit it onto the crew branch, then rename that branch
    # to salvage/<order>-<sha> so it survives the worktree teardown — previously
    # this work was silently lost and needed manual LEAD recovery. We do NOT
    # auto-advance (the work may be partial); we just guarantee it's never lost.
    _salvage_vid = _get_voyage_id_for_order(order_id)
    if _salvage_vid:
        try:
            from maestro.core.worktrees import (
                commit_crew_worktree_if_dirty,
                preserve_failed_crew_branch,
            )
            commit_crew_worktree_if_dirty(_salvage_vid, crew_num, order_id)
            _salv = preserve_failed_crew_branch(_salvage_vid, crew_num, order_id)
            if _salv and _salv.get("salvageBranch"):
                found_data.setdefault("salvageBranches", []).append({
                    "branch": _salv.get("salvageBranch"),
                    "sha": _salv.get("strandedSha"),
                    "reason": reason,
                    "crew": crew_num,
                    "timestamp": datetime.now().isoformat(),
                })
                write_lifecycle_event(
                    "SALVAGE",
                    f"{order_id} in-flight crew work preserved on "
                    f"{_salv.get('salvageBranch')} before requeue "
                    f"(Crew {crew_num} {reason}, BUG-0285)"
                )
        except Exception as _salv_exc:
            write_lifecycle_event(
                "WARN",
                f"{order_id} timeout salvage failed: {_salv_exc} (Crew {crew_num})"
            )

    # AC-2: a dependsOn was added (or a dep regressed) since pickup — do not
    # re-dispatch into an unmet dependency. Reset to PENDING WITHOUT spending a
    # requeue attempt so the scan_all_queues dependency gate dispatches it later,
    # once the dependency is satisfied.
    deps_ok, waiting_on = check_dependencies_satisfied(found_data)
    if not deps_ok:
        found_data["status"] = "PENDING"
        found_data.pop("assignedTo", None)
        found_data.pop("startedAt", None)
        found_file.write_text(json.dumps(found_data, indent=2), encoding='utf-8')
        order_ledger.record_released(order_id, f"REQUEUE_ABORTED dep-unsatisfied: {waiting_on}", workspace_dir=get_workspace_dir())  # BUG-MSO-2026-0294
        _mark_order_terminal_now()
        print_warn(f"REQUEUE aborted for {order_id}: dependencies unsatisfied {waiting_on} (Crew {crew_num} {reason})")
        write_lifecycle_event(
            "REQUEUE_ABORTED",
            f"{order_id} not re-dispatched: dep-unsatisfied (waiting on {waiting_on}) — "
            f"reset to PENDING; dependency gate will dispatch when satisfied (Crew {crew_num} {reason})"
        )
        return

    # BUG-MSO-2026-0206: cap REQUEUEs so a crew that hangs/fails every time can
    # never loop indefinitely. After MAX_REQUEUES real attempts, escalate to STALLED
    # (archived for human review). STALLED is a satisfying status, so the voyage's
    # dependents are not blocked forever.
    requeue_count = int(found_data.get("requeueCount", 0))
    if requeue_count >= MAX_REQUEUES:
        write_lifecycle_event(
            "ESCALATE",
            f"{order_id} hit REQUEUE cap ({requeue_count}/{MAX_REQUEUES}) "
            f"after {reason} — escalating to STALLED for human review (Crew {crew_num})"
        )
        print_warn(
            f"Order {order_id} hit REQUEUE cap ({requeue_count}/{MAX_REQUEUES}); "
            f"escalating to STALLED instead of re-queuing."
        )
        archive_stalled_order(
            order_id, crew_num, crew_state or {},
            f"REQUEUE cap exceeded ({requeue_count}/{MAX_REQUEUES}); last reason: {reason}",
            stalled_cause="ERROR",
        )
        return

    # AC-4 happy path: order is genuinely eligible (IN_PROGRESS, in a scanned queue,
    # deps satisfied, under the cap) — reset to PENDING for a fresh crew.
    found_data["status"] = "PENDING"
    found_data["requeueCount"] = requeue_count + 1
    found_data.pop("assignedTo", None)
    found_data.pop("startedAt", None)

    # v7.3: Append timeout brief to order history
    if timeout_brief:
        found_data.setdefault("timeoutBriefs", []).append({
            "crew": crew_num,
            "crewName": _get_crew_name(crew_num),
            "reason": reason,
            "timestamp": datetime.now().isoformat(),
            "brief": timeout_brief,
        })
        print_info(f"  Timeout brief attached to {order_id}")

    found_file.write_text(json.dumps(found_data, indent=2), encoding='utf-8')
    # BUG-MSO-2026-0294: release the durable claim — a fresh crew may take it.
    order_ledger.record_released(order_id, f"REQUEUE: {reason}", workspace_dir=get_workspace_dir())
    # BUG-MSO-2026-0224: a REQUEUE->PENDING transition is in-flight work, not an
    # empty queue. Refresh the Eight Bells grace clock so the very next scan can't
    # ring a false "all work complete" bell (and fire a premature sweep_decks /
    # Auto-PR) in the window between pulling the order from IN_PROGRESS and the
    # dispatcher observing the PENDING write.
    _mark_order_terminal_now()
    print_warn(f"Re-queued orphaned order {order_id} (Crew {crew_num} {reason}) [attempt {requeue_count + 1}/{MAX_REQUEUES}]")
    write_lifecycle_event("REQUEUE", f"{order_id} re-queued (Crew {crew_num} {reason}) [attempt {requeue_count + 1}/{MAX_REQUEUES}]")


def _maybe_hold_plan_for_review(
    data: Dict[str, Any], source_file: Path, completed_role: str,
    crew_num: int, order_id: str, workspace_dir: Path,
) -> bool:
    """BUG-MSO-2026-0205: hold a completed standalone planning order for human review.

    The intra-order gate only fires when a planning role has a NEXT role in the
    SAME order's roleSequence. The current planning convention builds voyages as
    SEPARATE orders — a standalone `[PLN]` order whose plan is consumed by dependent
    FTR/BLD orders. Such an order has no next role, so it would archive COMPLETE
    immediately and its dependents would dispatch with no human checkpoint.

    When the gate is enabled (and the order isn't exempt / skip-overridden), route
    the planning order to queues/review/ as NAV_REVIEW_PENDING with `planApprovalOnly`.
    Because NAV_REVIEW_PENDING is NOT a satisfying status, dependents stay blocked
    until `mso review approve` archives the plan as COMPLETE.

    Returns True if the order was routed to review (caller must NOT archive it),
    False if it should proceed to normal COMPLETE archival.
    """
    if not _is_planning_role(completed_role):
        return False
    gate_cfg = load_gate_config(workspace_dir)
    if gate_check_post_nav(data, gate_cfg) != "pause":
        return False

    check_plan_sizing(order_id, workspace_dir)
    review_dir = workspace_dir / "queues" / "review"
    review_dir.mkdir(parents=True, exist_ok=True)
    data["status"] = "NAV_REVIEW_PENDING"
    data["planApprovalOnly"] = True  # no next role — approve archives as COMPLETE
    data["navReviewPausedAt"] = datetime.now().isoformat()
    data.pop("assignedTo", None)
    data.pop("startedAt", None)
    data.pop("targetRole", None)
    (review_dir / source_file.name).write_text(json.dumps(data, indent=2), encoding='utf-8')
    source_file.unlink()
    print_ok(f"Order {order_id} plan complete -> paused for human review (plan approval)")
    write_lifecycle_event(
        "NAV_REVIEW_PENDING",
        f"{order_id} planning complete -> queues/review/ (plan approval, Crew {crew_num})"
    )
    ring_crew_bell(crew_num, order_id)
    return True


def _mark_role_succeeded(order_id: str, role: str, crew_num: int) -> bool:
    """Write crash-safe finalization checkpoint to the in-queue order JSON.

    Called in process_crew_completion() BEFORE any blocking finalization calls
    (PR creation, file moves). If the dispatcher crashes between crew completion
    and the ADVANCE/archive write, reset_orphaned_in_progress_orders() will detect
    roleSucceededAt and resume finalization instead of re-dispatching the same role.
    BUG-MSO-2026-0222.

    Returns True if the checkpoint was written, False if the order was not found
    or was already past IN_PROGRESS (no write needed).
    """
    queues_dir = get_queues_dir()
    search_dirs = [
        queues_dir / "orders", queues_dir / "explicit", queues_dir / "high-level",
        queues_dir / "bugs", queues_dir / "defects", queues_dir / "security",
        queues_dir / "breakdown",
    ]
    requests_dir = queues_dir / "requests"
    if requests_dir.exists():
        for sub in requests_dir.iterdir():
            if sub.is_dir():
                search_dirs.append(sub)

    for search_dir in search_dirs:
        if not search_dir.exists():
            continue
        for json_file in search_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                file_order_id = data.get("orderId") or data.get("id") or json_file.stem
                if file_order_id != order_id:
                    continue
                if data.get("status") != "IN_PROGRESS":
                    return False  # already past IN_PROGRESS — checkpoint not needed
                data["roleSucceededAt"] = datetime.now().isoformat()
                data["roleSucceededBy"] = {"role": role, "crew": crew_num}
                tmp = json_file.with_suffix('.tmp')
                tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')
                tmp.replace(json_file)
                write_lifecycle_event(
                    "FINALIZE",
                    f"{order_id} role {role} succeeded — crash-safe checkpoint written (Crew {crew_num}, BUG-0222)"
                )
                return True
            except Exception:
                pass
    return False


def _record_convergence_failure(order_id: str, error_detail: str,
                                salvage: Optional[Dict[str, Any]] = None) -> bool:
    """Mark an order CONVERGENCE_FAILED in its queue JSON (BUG-MSO-2026-0244).

    Called from process_crew_completion() when the crew->voyage convergence merge
    fails. Sets a non-PENDING, non-IN_PROGRESS status so the order is:
      - NOT re-dispatched (scan_all_queues only returns PENDING), and
      - NOT auto-archived by the resume-finalization paths (which require
        IN_PROGRESS in a queue, or roleSucceededAt in orders/active/).
    The order is left in place for operator/recovery action, annotated with the
    salvage branch + stranded SHA so the work can be cherry-picked.

    Returns True if the order JSON was found and updated.
    """
    queues_dir = get_queues_dir()
    search_dirs = [
        queues_dir / "orders", queues_dir / "explicit", queues_dir / "high-level",
        queues_dir / "bugs", queues_dir / "defects", queues_dir / "security",
        queues_dir / "breakdown",
    ]
    requests_dir = queues_dir / "requests"
    if requests_dir.exists():
        for sub in requests_dir.iterdir():
            if sub.is_dir():
                search_dirs.append(sub)

    for search_dir in search_dirs:
        if not search_dir.exists():
            continue
        for json_file in search_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                file_order_id = data.get("orderId") or data.get("id") or json_file.stem
                if file_order_id != order_id:
                    continue
                data["status"] = "CONVERGENCE_FAILED"
                data["convergence"] = {
                    "failed": True,
                    "failedAt": datetime.now().isoformat(),
                    "error": error_detail,
                    "salvageBranch": (salvage or {}).get("salvageBranch"),
                    "strandedSha": (salvage or {}).get("strandedSha"),
                }
                # Drop the live-crew assignment so orphan scans treat it as settled.
                data.pop("assignedTo", None)
                tmp = json_file.with_suffix('.tmp')
                tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')
                tmp.replace(json_file)
                return True
            except Exception:
                pass
    return False


def _record_verify_failure(order_id: str, error_detail: str,
                           salvage: Optional[Dict[str, Any]] = None) -> bool:
    """Mark an order VERIFY_FAILED in its queue JSON (FTR-MSO-2026-0287 R2).

    Mirrors _record_convergence_failure: sets a non-PENDING, non-IN_PROGRESS
    status so the held order is neither re-dispatched nor auto-archived, and
    annotates it with the verify error + salvage branch. Used when the local
    verify gate fails BEFORE convergence, so the broken work is never pushed and
    no CI is spent on it.
    """
    queues_dir = get_queues_dir()
    search_dirs = [
        queues_dir / "orders", queues_dir / "explicit", queues_dir / "high-level",
        queues_dir / "bugs", queues_dir / "defects", queues_dir / "security",
        queues_dir / "breakdown",
    ]
    requests_dir = queues_dir / "requests"
    if requests_dir.exists():
        for sub in requests_dir.iterdir():
            if sub.is_dir():
                search_dirs.append(sub)

    for search_dir in search_dirs:
        if not search_dir.exists():
            continue
        for json_file in search_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                file_order_id = data.get("orderId") or data.get("id") or json_file.stem
                if file_order_id != order_id:
                    continue
                data["status"] = "VERIFY_FAILED"
                data["verify"] = {
                    "failed": True,
                    "failedAt": datetime.now().isoformat(),
                    "error": error_detail,
                    "salvageBranch": (salvage or {}).get("salvageBranch"),
                    "strandedSha": (salvage or {}).get("strandedSha"),
                }
                data.pop("assignedTo", None)
                tmp = json_file.with_suffix('.tmp')
                tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')
                tmp.replace(json_file)
                return True
            except Exception:
                pass
    return False


_AUTO_SERIALIZE_CAP = 1  # FTR-MSO-2026-0267: max auto-serialize retries before CONVERGENCE_FAILED
_CONVERGENCE_RETRY_CAP = 3  # BUG-MSO-2026-0268: max convergence-network retries before CONVERGENCE_FAILED


def _auto_serialize_order(order_id: str, conflict_files: list,
                          salvage: Optional[Dict[str, Any]] = None) -> bool:
    """Re-queue a content-conflicted order as PENDING (FTR-MSO-2026-0267).

    Called when merge_crew_branch_into_voyage raises WorktreeContentConflict.
    Increments ``serializeCount`` on the order JSON and re-sets status to PENDING
    so the dispatcher will re-dispatch it.  The fresh crew builds on the now-updated
    voyage branch (the winner already converged) and should merge cleanly.

    The salvage branch is retained unchanged — if this re-run also fails (because
    serializeCount reached _AUTO_SERIALIZE_CAP) the operator can still cherry-pick
    from it.

    Returns True if the order was found and updated, False otherwise.
    """
    queues_dir = get_queues_dir()
    search_dirs = [
        queues_dir / "orders", queues_dir / "explicit", queues_dir / "high-level",
        queues_dir / "bugs", queues_dir / "defects", queues_dir / "security",
        queues_dir / "breakdown",
    ]
    requests_dir = queues_dir / "requests"
    if requests_dir.exists():
        for sub in requests_dir.iterdir():
            if sub.is_dir():
                search_dirs.append(sub)

    for search_dir in search_dirs:
        if not search_dir.exists():
            continue
        for json_file in search_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                file_order_id = data.get("orderId") or data.get("id") or json_file.stem
                if file_order_id != order_id:
                    continue
                data["status"] = "PENDING"
                data["serializeCount"] = data.get("serializeCount", 0) + 1
                data["autoSerialized"] = {
                    "at": datetime.now().isoformat(),
                    "conflictFiles": conflict_files,
                    "salvageBranch": (salvage or {}).get("salvageBranch"),
                }
                # Drop live-crew assignment so the dispatcher treats it as ready to pick up.
                data.pop("assignedTo", None)
                tmp = json_file.with_suffix('.tmp')
                tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')
                tmp.replace(json_file)
                return True
            except Exception:
                pass
    return False


def _get_serialize_count_for_order(order_id: str) -> int:
    """Return the current serializeCount for an order (0 if never auto-serialized)."""
    queues_dir = get_queues_dir()
    search_dirs = [
        queues_dir / "orders", queues_dir / "explicit", queues_dir / "high-level",
        queues_dir / "bugs", queues_dir / "defects", queues_dir / "security",
        queues_dir / "breakdown",
    ]
    requests_dir = queues_dir / "requests"
    if requests_dir.exists():
        for sub in requests_dir.iterdir():
            if sub.is_dir():
                search_dirs.append(sub)
    for search_dir in search_dirs:
        if not search_dir.exists():
            continue
        for json_file in search_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                file_order_id = data.get("orderId") or data.get("id") or json_file.stem
                if file_order_id == order_id:
                    return int(data.get("serializeCount", 0))
            except Exception:
                pass
    return 0


def _get_convergence_retry_count(order_id: str) -> int:
    """Return the current convergenceRetryCount for an order (0 if never retried)."""
    queues_dir = get_queues_dir()
    search_dirs = [
        queues_dir / "orders", queues_dir / "explicit", queues_dir / "high-level",
        queues_dir / "bugs", queues_dir / "defects", queues_dir / "security",
        queues_dir / "breakdown",
    ]
    requests_dir = queues_dir / "requests"
    if requests_dir.exists():
        for sub in requests_dir.iterdir():
            if sub.is_dir():
                search_dirs.append(sub)
    for search_dir in search_dirs:
        if not search_dir.exists():
            continue
        for json_file in search_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                file_order_id = data.get("orderId") or data.get("id") or json_file.stem
                if file_order_id == order_id:
                    return int(data.get("convergenceRetryCount", 0))
            except Exception:
                pass
    return 0


def _requeue_for_convergence_retry(order_id: str, error_detail: str,
                                   salvage: Optional[Dict[str, Any]] = None) -> bool:
    """Re-queue an order as PENDING after a transient convergence network failure (BUG-MSO-2026-0268).

    Called when merge_crew_branch_into_voyage raises ConvergenceNetworkError.
    Increments ``convergenceRetryCount`` and resets status to PENDING so the
    dispatcher will attempt convergence again on the next cycle.

    The salvage branch (holding the crew's committed work) is retained unchanged
    so the retry can converge from it rather than re-running the role. If
    ``convergenceRetryCount`` reaches ``_CONVERGENCE_RETRY_CAP``, the caller
    falls through to ``_record_convergence_failure`` instead.

    Returns True if the order was found and updated.
    """
    queues_dir = get_queues_dir()
    search_dirs = [
        queues_dir / "orders", queues_dir / "explicit", queues_dir / "high-level",
        queues_dir / "bugs", queues_dir / "defects", queues_dir / "security",
        queues_dir / "breakdown",
    ]
    requests_dir = queues_dir / "requests"
    if requests_dir.exists():
        for sub in requests_dir.iterdir():
            if sub.is_dir():
                search_dirs.append(sub)

    for search_dir in search_dirs:
        if not search_dir.exists():
            continue
        for json_file in search_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                file_order_id = data.get("orderId") or data.get("id") or json_file.stem
                if file_order_id != order_id:
                    continue
                data["status"] = "PENDING"
                data["convergenceRetryCount"] = data.get("convergenceRetryCount", 0) + 1
                data["convergenceRetry"] = {
                    "at": datetime.now().isoformat(),
                    "error": error_detail,
                    "salvageBranch": (salvage or {}).get("salvageBranch"),
                    "strandedSha": (salvage or {}).get("strandedSha"),
                }
                data.pop("assignedTo", None)
                tmp = json_file.with_suffix('.tmp')
                tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')
                tmp.replace(json_file)
                return True
            except Exception:
                pass
    return False


def _clear_convergence_retry(order_id: str) -> bool:
    """Remove the convergenceRetry block from an order JSON after a successful fast-convergence.

    BUG-MSO-2026-0273: called by _fast_converge_salvage_branch on success so the
    next role dispatch does not re-fire the salvage fast-path.
    Returns True if the order was found and updated.
    """
    queues_dir = get_queues_dir()
    search_dirs = [
        queues_dir / "orders", queues_dir / "explicit", queues_dir / "high-level",
        queues_dir / "bugs", queues_dir / "defects", queues_dir / "security",
        queues_dir / "breakdown",
    ]
    requests_dir = queues_dir / "requests"
    if requests_dir.exists():
        for sub in requests_dir.iterdir():
            if sub.is_dir():
                search_dirs.append(sub)

    for search_dir in search_dirs:
        if not search_dir.exists():
            continue
        for json_file in search_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                file_order_id = data.get("orderId") or data.get("id") or json_file.stem
                if file_order_id != order_id:
                    continue
                data.pop("convergenceRetry", None)
                tmp = json_file.with_suffix('.tmp')
                tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')
                tmp.replace(json_file)
                return True
            except Exception:
                pass
    return False


def _fast_converge_salvage_branch(order_id: str, salvage_branch: str,
                                   voyage_branch: str, voyage_id: str) -> bool:
    """Converge a salvage branch directly into the voyage branch (BUG-MSO-2026-0273).

    Called by dispatch_squad when an order arrives with convergenceRetry.salvageBranch
    set, indicating that a prior crew completed its work but convergence failed transiently.
    Instead of re-running the role from scratch, we merge the salvage branch directly.

    Uses the voyage admin worktree (same as merge_crew_branch_into_voyage).

    Returns True  — fast-path took ownership (success, re-queued, or serialized).
    Returns False — salvage branch is absent; caller should fall through to normal dispatch.

    On ConvergenceNetworkError: re-queues the order (cap logic preserved) and returns True.
    On WorktreeContentConflict: auto-serializes and returns True.
    """
    from maestro.core.worktrees import (
        resolve_convergence_worktree,
        WorktreeContentConflict,
        ConvergenceNetworkError,
        WorktreeError,
        _retry_git_network_op,
        _merge_lock,
    )

    write_lifecycle_event(
        "CONVERGENCE_RETRY_FROM_SALVAGE",
        f"{order_id}: fast-path convergence of salvage branch '{salvage_branch}' "
        f"into '{voyage_branch}' (voyage={voyage_id})"
    )

    # Resolve admin worktree for merge operations. BUG-MSO-2026-0295: never the
    # primary workspace checkout — a detached scratch worktree is used when the
    # branch is held by the primary tree (on_branch=False → push HEAD:ref).
    try:
        admin_wt, on_branch = resolve_convergence_worktree(voyage_id, voyage_branch)
    except Exception as exc:
        write_lifecycle_event(
            "WARN",
            f"{order_id}: CONVERGENCE_RETRY_FROM_SALVAGE — worktree prep failed ({exc}); "
            f"falling through to normal role dispatch"
        )
        return False

    _completion_config = load_completion_config()
    _conv_timeout = _completion_config.get("convergenceNetworkTimeout", 60)

    def _run(cmd: list) -> subprocess.CompletedProcess:
        return subprocess.run(cmd, capture_output=True, text=True, cwd=str(admin_wt), timeout=60)

    def _run_net(cmd: list, timeout: Optional[int] = None) -> subprocess.CompletedProcess:
        return _retry_git_network_op(
            cmd, cwd=str(admin_wt),
            timeout=timeout if timeout is not None else _conv_timeout,
        )

    def _has_ref(ref: str) -> bool:
        return _run(["git", "rev-parse", "--verify", "--quiet", ref]).returncode == 0

    # BUG-MSO-2026-0273 review: serialize concurrent fast-converges against the
    # same voyage branch — parity with merge_crew_branch_into_voyage's lock.
    # Without this, a normal convergence and a fast-path convergence could race
    # on fetch/reset/merge/push.
    try:
        with _merge_lock:
            # Sync voyage branch to latest remote state.
            _run_net(["git", "fetch", "origin",
                      f"{voyage_branch}:refs/remotes/origin/{voyage_branch}"])

            # Resolve salvage branch — prefer local ref, fall back to origin.
            if _has_ref(f"refs/heads/{salvage_branch}"):
                merge_target = salvage_branch
            elif _has_ref(f"refs/remotes/origin/{salvage_branch}"):
                merge_target = f"origin/{salvage_branch}"
            else:
                # Try fetching from origin.
                try:
                    _run_net(["git", "fetch", "origin",
                              f"{salvage_branch}:refs/remotes/origin/{salvage_branch}"])
                except ConvergenceNetworkError:
                    raise  # transient — let the outer handler re-queue
                if _has_ref(f"refs/remotes/origin/{salvage_branch}"):
                    merge_target = f"origin/{salvage_branch}"
                else:
                    # Salvage branch is gone — fall through to normal role re-run.
                    write_lifecycle_event(
                        "WARN",
                        f"{order_id}: CONVERGENCE_RETRY_FROM_SALVAGE — salvage branch "
                        f"'{salvage_branch}' not found locally or on origin; "
                        f"falling through to normal role re-run"
                    )
                    return False

            # Reset admin worktree to latest voyage tip.
            reset_r = _run(["git", "reset", "--hard", f"origin/{voyage_branch}"])
            if reset_r.returncode != 0:
                raise WorktreeError(
                    f"git reset --hard origin/{voyage_branch} failed: {reset_r.stderr.strip()}"
                )

            # Merge salvage branch --no-ff to preserve history.
            merge_r = _run([
                "git", "merge", "--no-ff", merge_target,
                "-m",
                f"convergence: fast-converge salvage '{salvage_branch}' into "
                f"{voyage_branch} ({order_id})",
            ])
            if merge_r.returncode != 0:
                conflicts_r = _run(["git", "diff", "--name-only", "--diff-filter=U"])
                conflict_files = [f for f in conflicts_r.stdout.splitlines() if f.strip()]
                _run(["git", "merge", "--abort"])
                _detail = (merge_r.stdout.strip() + " " + merge_r.stderr.strip()).strip()
                _files = ", ".join(conflict_files) if conflict_files else "unknown"
                if conflict_files:
                    raise WorktreeContentConflict(
                        f"Fast-converge of '{salvage_branch}' into '{voyage_branch}' "
                        f"failed (content conflict). Conflicting files: {_files}. git: {_detail}",
                        conflict_files=conflict_files,
                    )
                raise WorktreeError(
                    f"Fast-converge of '{salvage_branch}' into '{voyage_branch}' "
                    f"failed: {_detail}"
                )

            # Push merged voyage branch. BUG-MSO-2026-0273 review (parity with
            # BUG-MSO-2026-0272): pushes upload pack data and need a longer
            # ceiling than fetches; use 2x convergence_timeout to match the
            # behaviour of merge_crew_branch_into_voyage's push.
            # BUG-MSO-2026-0295: detached scratch worktree pushes HEAD:ref.
            _push_ref = voyage_branch if on_branch else f"HEAD:refs/heads/{voyage_branch}"
            _run_net(["git", "push", "origin", _push_ref],
                     timeout=2 * _conv_timeout)
            if not on_branch:
                from maestro.core.worktrees import safe_ff_primary_checkout
                _run(["git", "fetch", "origin",
                      f"{voyage_branch}:refs/remotes/origin/{voyage_branch}"])
                safe_ff_primary_checkout(voyage_branch)

    except ConvergenceNetworkError as net_exc:
        _retry_count = _get_convergence_retry_count(order_id)
        if _retry_count < _CONVERGENCE_RETRY_CAP:
            _requeue_for_convergence_retry(
                order_id, str(net_exc),
                salvage={"salvageBranch": salvage_branch}
            )
            write_lifecycle_event(
                "CONVERGENCE_RETRY",
                f"{order_id}: CONVERGENCE_RETRY_FROM_SALVAGE network failure "
                f"(attempt {_retry_count + 1}/{_CONVERGENCE_RETRY_CAP}). "
                f"Re-queued PENDING. Salvage: {salvage_branch}. Error: {net_exc}"
            )
        else:
            _record_convergence_failure(
                order_id, str(net_exc),
                salvage={"salvageBranch": salvage_branch}
            )
            write_lifecycle_event(
                "ERROR",
                f"{order_id}: CONVERGENCE_RETRY_FROM_SALVAGE cap ({_CONVERGENCE_RETRY_CAP}) "
                f"reached — CONVERGENCE_FAILED. Salvage: {salvage_branch}"
            )
        return True

    except WorktreeContentConflict as conflict_exc:
        _serialize_count = _get_serialize_count_for_order(order_id)
        if _serialize_count < _AUTO_SERIALIZE_CAP:
            _auto_serialize_order(
                order_id, conflict_exc.conflict_files,
                salvage={"salvageBranch": salvage_branch}
            )
            write_lifecycle_event(
                "CONVERGENCE_RETRY",
                f"{order_id}: CONVERGENCE_RETRY_FROM_SALVAGE content conflict — "
                f"auto-serializing (attempt {_serialize_count + 1}/{_AUTO_SERIALIZE_CAP}). "
                f"Salvage: {salvage_branch}"
            )
        else:
            _record_convergence_failure(
                order_id, str(conflict_exc),
                salvage={"salvageBranch": salvage_branch}
            )
            write_lifecycle_event(
                "ERROR",
                f"{order_id}: CONVERGENCE_RETRY_FROM_SALVAGE serialize cap reached — "
                f"CONVERGENCE_FAILED. Salvage: {salvage_branch}"
            )
        return True

    except Exception as exc:
        write_lifecycle_event(
            "WARN",
            f"{order_id}: CONVERGENCE_RETRY_FROM_SALVAGE unexpected error ({exc}); "
            f"falling through to normal role re-run"
        )
        return False

    # SUCCESS: clear convergenceRetry so the next role dispatch is clean.
    _clear_convergence_retry(order_id)
    write_lifecycle_event(
        "CONVERGENCE_RETRY_FROM_SALVAGE",
        f"{order_id}: fast-convergence SUCCESS — salvage '{salvage_branch}' merged "
        f"into '{voyage_branch}'; convergenceRetry cleared. Advancing order."
    )

    # Advance the order to the next role (same logic as normal COMPLETE finalization).
    try:
        complete_order(order_id, 0, {"status": "COMPLETE", "role": "", "orderId": order_id})
        auto_queue_unblocked_orders(order_id)
    except Exception as adv_exc:
        write_lifecycle_event(
            "WARN",
            f"{order_id}: CONVERGENCE_RETRY_FROM_SALVAGE — advance/unblock failed: {adv_exc}"
        )

    return True


def complete_order(order_id: str, crew_num: int, crew_state: Dict[str, Any]):
    """Mark an order as COMPLETE and archive it out of the active queue.

    Lifecycle: PENDING -> IN_PROGRESS -> COMPLETE (archived)
    Searches queue directories first, then falls back to orders/active/.
    v8.5: Also archives from orders/active/ to fix dependency resolution
    when queue file is missing (e.g., cleaned up or pipe-hang scenario).
    """
    queues_dir = get_queues_dir()
    admiralty_dir = get_workspace_dir()

    # BUG-MSO-2026-0219: if the order is already parked for human review
    # (plan-approval hold, NAV_REVIEW_PENDING), a SECOND completion call must NOT
    # fabricate a COMPLETE archive entry — that would defeat the review gate and
    # prematurely unblock dependents. Treat as already-handled and return.
    if (admiralty_dir / "queues" / "review" / f"{order_id}.json").exists():
        write_lifecycle_event(
            "WARN",
            f"{order_id} already held in queues/review/ — skipping duplicate completion (Crew {crew_num})"
        )
        return

    # BUG-MSO-2026-0024: any completion (advance, archive, or sweep) may unblock a
    # dependent the dispatcher hasn't re-scanned yet — refresh the Eight Bells grace clock.
    _mark_order_terminal_now()

    archive_dir = admiralty_dir / "orders" / "complete"
    archive_dir.mkdir(parents=True, exist_ok=True)

    completion_metadata = {
        "status": "COMPLETE",
        "completedAt": datetime.now().isoformat(),
        "completedBy": {
            "crew": crew_num,
            "role": crew_state.get("role", "UNK"),
            "iterations": crew_state.get("iteration", 0),
            "startTime": crew_state.get("startTime", ""),
            "endTime": crew_state.get("endTime", "")
        }
    }

    # v7.0: Search ALL queue directories
    search_dirs = [
        queues_dir / "orders", queues_dir / "explicit", queues_dir / "high-level",
        queues_dir / "bugs", queues_dir / "defects", queues_dir / "security",
        queues_dir / "breakdown",
    ]
    # Also search all request subdirectories
    requests_dir = queues_dir / "requests"
    if requests_dir.exists():
        for sub in requests_dir.iterdir():
            if sub.is_dir():
                search_dirs.append(sub)

    found_in_queue = False
    for search_dir in search_dirs:
        if not search_dir.exists():
            continue
        for json_file in search_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                file_order_id = data.get("orderId") or data.get("id") or json_file.stem
                if file_order_id != order_id:
                    continue

                # BUG-MSO-2026-0236: extract completed_role before the status==COMPLETE
                # branch so we can check roleSequence in BOTH paths.
                completed_role = crew_state.get("role", "")

                # v8.9: If the queue file already has status=COMPLETE, it was
                # written by the crew but not yet moved to archive (e.g. due to
                # timing or a prior unlink failure).
                # BUG-MSO-2026-0236: MUST check roleSequence before archiving —
                # if the completed role is non-final, ADVANCE instead of archiving
                # so subsequent roles (TST, DOC, …) are not silently skipped.
                if data.get("status") == "COMPLETE":
                    meta_c = data.get("_meta", {})
                    order_type_c = data.get("orderType") or data.get("type", "")
                    sequence_c = (
                        data.get("roleSequence")
                        or meta_c.get("roleSequence")
                        or ROLE_SEQUENCES.get(order_type_c, [])
                    )
                    next_role_c = None
                    if sequence_c and completed_role in sequence_c:
                        idx_c = sequence_c.index(completed_role)
                        if idx_c + 1 < len(sequence_c):
                            next_role_c = sequence_c[idx_c + 1]

                    if next_role_c:
                        # Non-final role — advance rather than archive
                        # BUG-MSO-2026-0248: arm transition gate BEFORE writing the file so
                        # scan_all_queues can never see a PENDING item that isn't gated yet.
                        ORDERS_IN_TRANSITION.add(order_id)
                        data["status"] = "PENDING"
                        data["targetRole"] = next_role_c
                        data.pop("assignedTo", None)
                        data.pop("startedAt", None)
                        json_file.write_text(json.dumps(data, indent=2), encoding='utf-8')
                        found_in_queue = True
                        print_ok(
                            f"Order {order_id} COMPLETE-in-queue {completed_role} "
                            f"-> advancing to {next_role_c} (BUG-0236)"
                        )
                        write_lifecycle_event(
                            "ADVANCE",
                            f"{order_id} COMPLETE-in-queue {completed_role} -> {next_role_c} "
                            f"(Crew {crew_num}, BUG-0236)"
                        )
                        ring_crew_bell(crew_num, order_id)
                    else:
                        # Final role (or no sequence) — archive as COMPLETE
                        data.update(completion_metadata)
                        archive_file = archive_dir / json_file.name
                        archive_file.write_text(json.dumps(data, indent=2), encoding='utf-8')
                        json_file.unlink()
                        found_in_queue = True
                        print_ok(f"Order {order_id} already COMPLETE in queue -> swept to archive")
                        write_lifecycle_event("COMPLETE", f"{order_id} swept to archive from queue (Crew {crew_num})")
                        ring_crew_bell(crew_num, order_id)
                    break

                # Found the order in queue — check role sequence before archiving
                # (completed_role already extracted above, before the COMPLETE branch)

                # Idempotency guard: if the order was already advanced past completed_role
                # (status=PENDING waiting for dispatch, or status=IN_PROGRESS already claimed
                # by another crew), a stale complete_order call must not overwrite it.
                # BUG-MSO-2026-0015: original guard covered PENDING only.
                # BUG-MSO-2026-0248: extend to IN_PROGRESS — without this, a late BLD
                # complete_order would overwrite an already-dispatched IN_PROGRESS@TST order
                # back to PENDING@TST, causing a second crew to be dispatched for the same role.
                if data.get("status") in ("PENDING", "IN_PROGRESS") and data.get("targetRole") and data.get("targetRole") != completed_role:
                    # PSG bug 3 (advance-loss loop): a mismatch can mean the FILE
                    # was rewound BEHIND the crew, not that the crew is stale. The
                    # ledger's durable role progression disambiguates: if it confirms
                    # completed_role is the order's current role, the completion is
                    # legitimate — heal the file and fall through to the advance.
                    _ledger_role = order_ledger.load_view(get_workspace_dir()).current_role(order_id)
                    if _ledger_role == completed_role:
                        write_lifecycle_event(
                            "WARN",
                            f"{order_id} file says {data['targetRole']} but ledger confirms "
                            f"{completed_role} is current — file was rewound; accepting "
                            f"completion and healing (BUG-0248 advance-loss)"
                        )
                        data["targetRole"] = completed_role
                    else:
                        print_info(f"Order {order_id} already past {completed_role} -> {data['targetRole']} (status={data.get('status')}, skipping stale completion)")
                        write_lifecycle_event("WARN", f"{order_id} stale complete_order call for {completed_role} ignored — already at {data['targetRole']} status={data.get('status')} (BUG-0248)")
                        found_in_queue = True
                        break

                meta = data.get("_meta", {})
                order_type = data.get("orderType") or data.get("type", "")
                sequence = (
                    data.get("roleSequence")
                    or meta.get("roleSequence")
                    or ROLE_SEQUENCES.get(order_type, [])
                )
                next_role = None
                if sequence and completed_role in sequence:
                    idx = sequence.index(completed_role)
                    if idx + 1 < len(sequence):
                        next_role = sequence[idx + 1]

                if next_role:
                    # Post-PLN human review gate (BUG-MSO-2026-0205: match canonical
                    # PLN as well as the legacy NAV alias).
                    if _is_planning_role(completed_role):
                        # BUG-MSO-2026-0022: story-sizing soft gate
                        check_plan_sizing(order_id, get_workspace_dir())
                        gate_cfg = load_gate_config(get_workspace_dir())
                        decision = gate_check_post_nav(data, gate_cfg)
                        if decision == "pause":
                            review_dir = get_workspace_dir() / "queues" / "review"
                            review_dir.mkdir(parents=True, exist_ok=True)
                            data["status"] = "NAV_REVIEW_PENDING"
                            data["targetRole"] = next_role
                            data["navReviewPausedAt"] = datetime.now().isoformat()
                            data.pop("assignedTo", None)
                            data.pop("startedAt", None)
                            review_file = review_dir / json_file.name
                            review_file.write_text(json.dumps(data, indent=2), encoding='utf-8')
                            json_file.unlink()
                            found_in_queue = True
                            print_ok(f"Order {order_id} planning complete -> paused for human review")
                            write_lifecycle_event("NAV_REVIEW_PENDING", f"{order_id} planning complete -> queues/review/ (Crew {crew_num})")
                            ring_crew_bell(crew_num, order_id)
                            break

                    # Not the final role — advance to next role and re-queue
                    # BUG-MSO-2026-0248: arm transition gate BEFORE writing the file.
                    ORDERS_IN_TRANSITION.add(order_id)
                    data["status"] = "PENDING"
                    data["targetRole"] = next_role
                    data.pop("assignedTo", None)
                    data.pop("startedAt", None)
                    json_file.write_text(json.dumps(data, indent=2), encoding='utf-8')
                    found_in_queue = True
                    # BUG-MSO-2026-0294: clear the durable claim so the next
                    # role's dispatch isn't vetoed as in-flight. The ADVANCED
                    # event also records the role progression (PSG bug 3).
                    order_ledger.record_advanced(order_id, completed_role, next_role,
                                                  workspace_dir=get_workspace_dir())
                    # BUG-MSO-2026-0295: put the advance in history so a rewind
                    # can't revert the role (the PSG PLN<->BLD loop vector).
                    _commit_lifecycle_transition(
                        [json_file],
                        f"lifecycle: advance {order_id} {completed_role} -> {next_role}",
                    )
                    print_ok(f"Order {order_id} {completed_role} complete -> advancing to {next_role}")
                    write_lifecycle_event("ADVANCE", f"{order_id} {completed_role} complete -> {next_role} (Crew {crew_num})")
                    ring_crew_bell(crew_num, order_id)
                else:
                    # BUG-MSO-2026-0205: a standalone planning order ([PLN] with no next
                    # role) must still pause for human plan-approval when the gate is on,
                    # so its dependent FTR/BLD orders don't dispatch unreviewed.
                    if _maybe_hold_plan_for_review(data, json_file, completed_role, crew_num, order_id, get_workspace_dir()):
                        found_in_queue = True
                        break
                    # Final role — archive as COMPLETE
                    data.update(completion_metadata)
                    archive_file = archive_dir / json_file.name
                    archive_file.write_text(json.dumps(data, indent=2), encoding='utf-8')
                    json_file.unlink()
                    found_in_queue = True
                    # BUG-MSO-2026-0294: durable TERMINAL — survives any git rewind.
                    order_ledger.record_terminal(order_id, "COMPLETE", workspace_dir=get_workspace_dir())
                    # BUG-MSO-2026-0295: commit the archive transition so git
                    # history carries the truth (best-effort, config-gated).
                    _commit_lifecycle_transition(
                        [archive_file, json_file],
                        f"lifecycle: archive {order_id} (COMPLETE)",
                    )
                    print_ok(f"Order {order_id} COMPLETE -> archived to orders/complete/")
                    write_lifecycle_event("COMPLETE", f"{order_id} COMPLETE -> archived (Crew {crew_num})")
                    ring_crew_bell(crew_num, order_id)
                break

            except Exception as e:
                print_warn(f"Error processing {json_file}: {e}")
        if found_in_queue:
            break

    # v8.5: Also archive from orders/active/ to orders/complete/
    # This ensures dependency resolution works even if the queue file was
    # already cleaned up (pipe-hang scenario, manual cleanup, etc.)
    active_dir = admiralty_dir / "orders" / "active"
    active_file = active_dir / f"{order_id}.json"
    if active_file.exists():
        try:
            data = json.loads(active_file.read_text(encoding='utf-8'))
            if not found_in_queue:
                # Apply same advance-vs-archive logic as queue path
                completed_role = crew_state.get("role", "")
                meta = data.get("_meta", {})
                order_type = data.get("orderType") or data.get("type", "")
                sequence = (
                    data.get("roleSequence")
                    or meta.get("roleSequence")
                    or ROLE_SEQUENCES.get(order_type, [])
                )
                next_role = None
                if sequence and completed_role in sequence:
                    idx = sequence.index(completed_role)
                    if idx + 1 < len(sequence):
                        next_role = sequence[idx + 1]

                if next_role:
                    # Post-PLN human review gate (v8.5 fallback path; BUG-MSO-2026-0205
                    # matches canonical PLN as well as legacy NAV).
                    if _is_planning_role(completed_role):
                        # BUG-MSO-2026-0022: story-sizing soft gate
                        check_plan_sizing(order_id, admiralty_dir)
                        gate_cfg = load_gate_config(admiralty_dir)
                        decision = gate_check_post_nav(data, gate_cfg)
                        if decision == "pause":
                            review_dir = admiralty_dir / "queues" / "review"
                            review_dir.mkdir(parents=True, exist_ok=True)
                            data["status"] = "NAV_REVIEW_PENDING"
                            data["targetRole"] = next_role
                            data["navReviewPausedAt"] = datetime.now().isoformat()
                            data.pop("assignedTo", None)
                            data.pop("startedAt", None)
                            review_file = review_dir / active_file.name
                            review_file.write_text(json.dumps(data, indent=2), encoding='utf-8')
                            active_file.unlink()
                            print_ok(f"Order {order_id} planning complete -> paused for human review (v8.5 fallback)")
                            write_lifecycle_event("NAV_REVIEW_PENDING", f"{order_id} planning complete -> queues/review/ from active (Crew {crew_num}, v8.5)")
                            ring_crew_bell(crew_num, order_id)
                            return True

                    # Not the final role — move back to queue at next role
                    # BUG-MSO-2026-0248: arm transition gate BEFORE writing the file.
                    ORDERS_IN_TRANSITION.add(order_id)
                    queue_dir = admiralty_dir / "queues" / "orders"
                    queue_dir.mkdir(parents=True, exist_ok=True)
                    data["status"] = "PENDING"
                    data["targetRole"] = next_role
                    data.pop("assignedTo", None)
                    data.pop("startedAt", None)
                    queue_file = queue_dir / active_file.name
                    queue_file.write_text(json.dumps(data, indent=2), encoding='utf-8')
                    active_file.unlink()
                    order_ledger.record_advanced(order_id, completed_role, next_role, workspace_dir=admiralty_dir)  # BUG-MSO-2026-0294
                    _commit_lifecycle_transition(  # BUG-MSO-2026-0295 / PSG bug 3
                        [queue_file, active_file],
                        f"lifecycle: advance {order_id} {completed_role} -> {next_role}",
                    )
                    print_ok(f"Order {order_id} {completed_role} complete -> advancing to {next_role} (v8.5 fallback)")
                    write_lifecycle_event("ADVANCE", f"{order_id} {completed_role} -> {next_role} from active (Crew {crew_num}, v8.5)")
                    ring_crew_bell(crew_num, order_id)
                else:
                    # BUG-MSO-2026-0205: standalone planning order — hold for plan approval.
                    if _maybe_hold_plan_for_review(data, active_file, completed_role, crew_num, order_id, admiralty_dir):
                        return True
                    data.update(completion_metadata)
                    archive_file = archive_dir / active_file.name
                    archive_file.write_text(json.dumps(data, indent=2), encoding='utf-8')
                    active_file.unlink()
                    order_ledger.record_terminal(order_id, "COMPLETE", workspace_dir=admiralty_dir)  # BUG-MSO-2026-0294
                    _commit_lifecycle_transition(
                        [archive_file, active_file],
                        f"lifecycle: archive {order_id} (COMPLETE)",
                    )
                    print_ok(f"Order {order_id} COMPLETE -> archived from orders/active/ (v8.5 fallback)")
                    write_lifecycle_event("COMPLETE", f"{order_id} COMPLETE -> archived from active (Crew {crew_num}, v8.5)")
                    ring_crew_bell(crew_num, order_id)
            else:
                # Queue path already handled it — just clean up active copy if present
                active_file.unlink(missing_ok=True)
        except Exception as e:
            print_warn(f"Error archiving {order_id} from active: {e}")
        return True

    if found_in_queue:
        return True

    # v8.7: Check if already archived (e.g., pipe-hang fix already processed it)
    archive_check = archive_dir / f"{order_id}.json"
    if archive_check.exists():
        return True

    # BUG-MSO-2026-0219 (defense in depth): never synthesize a COMPLETE stub for an
    # order that is parked in review (plan-approval hold). It is not 'missing' — it is
    # deliberately held, and a COMPLETE stub here would unblock its dependents.
    if (admiralty_dir / "queues" / "review" / f"{order_id}.json").exists():
        return True

    # v8.5: Log warning when order not found anywhere
    print_warn(f"Order {order_id} not found in queues or active — creating archive entry from crew state")
    write_lifecycle_event("WARN", f"Order {order_id} not found in queues/active — synthesized archive entry (Crew {crew_num}, v8.5)")
    # Last resort: create a minimal archive entry so dependencies resolve
    archive_file = archive_dir / f"{order_id}.json"
    if not archive_file.exists():
        minimal_data = {"orderId": order_id, "id": order_id}
        minimal_data.update(completion_metadata)
        archive_file.write_text(json.dumps(minimal_data, indent=2), encoding='utf-8')
    ring_crew_bell(crew_num, order_id)
    return True


def process_crew_completion(crew_num: int):
    """Process a crew that has finished (COMPLETE, BLOCKED, ERROR, CRASHED, etc).

    v7.1: Handles ALL terminal states including AUTH_ERROR and INTERRUPTED.
    v2.0.0: Added post-completion repo verification, per-crew PR creation, and cleanup.

    Handles the full lifecycle:
    - COMPLETE: Verify+push, create PR, archive the order
    - CRASHED/ERROR/TIMEOUT/AUTH_ERROR/INTERRUPTED: Verify+push, re-queue for retry
    - BLOCKED/MAX_ITERATIONS/CIRCUIT_BREAKER: Verify+push, archive with failure status
    """
    state = read_crew_state(crew_num)
    if not state:
        return

    status = state.get("status", "")
    order_id = state.get("orderId", "")
    if not order_id:
        return

    # BUG-MSO-2026-0236: extract completed_role early so the single-flight guard
    # (below) can reference it regardless of whether target_repo/voyage_branch are set.
    completed_role = state.get("role", "")

    # v2.0.0: Post-completion repo verification (for ALL terminal states)
    target_repo = _get_target_repo_for_order(order_id)
    # v2.0.1: Per-order voyage branch resolution
    voyage_branch = _get_voyage_branch_for_order(order_id) or ACTIVE_VOYAGE_BRANCH

    if target_repo and voyage_branch:
        # Create/update PR on successful completion
        # BUG-ADM-2026-0013: pass project_acronym so create_pr_for_crew can
        # resolve the base branch from project registry (PSG → master).
        if status == "COMPLETE":
            # BUG-MSO-2026-0266: idempotency guard for the final-role convergence path.
            # If the order is already archived to orders/complete/, a duplicate
            # process_crew_completion call must not re-attempt convergence (crew branch
            # is already consumed/deleted — would raise REF_MISSING + spurious ESCALATE).
            _archive_check = get_workspace_dir() / "orders" / "complete" / f"{order_id}.json"
            if _archive_check.exists():
                write_lifecycle_event(
                    "WARN",
                    f"{order_id} already archived COMPLETE — skipping duplicate "
                    f"process_crew_completion (Crew {crew_num}, BUG-0266)"
                )
                return

            # BUG-MSO-2026-0222: write crash-safe checkpoint before any blocking call.
            # If the dispatcher dies between here and the ADVANCE/archive write,
            # reset_orphaned_in_progress_orders() will resume finalization on restart.
            _mark_role_succeeded(order_id, completed_role, crew_num)

            # BUG-MSO-2026-0240: merge per-crew branch into voyage branch so the
            # voyage branch PR reflects the crew's work BEFORE create_pr_for_crew.
            _voyage_id = _get_voyage_id_for_order(order_id)
            # BUG-MSO-2026-0268: load completion config once so convergence_timeout
            # is available inside the try/except block below.
            _completion_config = load_completion_config()
            if _voyage_id:
                try:
                    from maestro.core.worktrees import (
                        merge_crew_branch_into_voyage,
                        cleanup_crew_worktree,
                        commit_crew_worktree_if_dirty,
                        crew_worktree_path_for,
                        preserve_failed_crew_branch,
                    )
                    # BUG-MSO-2026-0284: a crew may finish (subtype=success) having
                    # WRITTEN artefacts (e.g. a PLN plan) but never run `git commit`.
                    # Convergence merges the crew BRANCH, so uncommitted worktree
                    # changes would be silently lost. Auto-commit them onto the crew
                    # branch FIRST so the merge below actually captures the work.
                    if commit_crew_worktree_if_dirty(_voyage_id, crew_num, order_id):
                        write_lifecycle_event(
                            "FINALIZE",
                            f"{order_id} auto-committed uncommitted crew artefacts "
                            f"before convergence (Crew {crew_num}, BUG-0284)"
                        )
                    # FTR-MSO-2026-0287 (R2): local verify gate. Run the project
                    # verifyCommand in the crew worktree BEFORE pushing. If it
                    # fails, hold the order (VERIFY_FAILED) and do NOT converge/
                    # push — so a broken build never reaches the remote and never
                    # spends a CI run. Empty verifyCommand = gate disabled.
                    _verify_cfg = load_verify_config()
                    if _verify_cfg["command"]:
                        _wt = crew_worktree_path_for(_voyage_id, crew_num)
                        _ok, _vdetail = run_verify_gate(
                            _wt, _verify_cfg["command"], _verify_cfg["timeoutMinutes"]
                        )
                        if not _ok:
                            _salvage = None
                            try:
                                _salvage = preserve_failed_crew_branch(
                                    _voyage_id, crew_num, order_id)
                            except Exception:
                                pass
                            _record_verify_failure(order_id, _vdetail, _salvage)
                            _salvage_ref = (_salvage or {}).get("salvageBranch", "<none>")
                            write_lifecycle_event(
                                "VERIFY_FAILED",
                                f"{order_id} local verify gate FAILED — NOT converged/"
                                f"pushed (no CI spent). Work preserved on {_salvage_ref}. "
                                f"Crew {crew_num}. Detail: {_vdetail[:300]}"
                            )
                            print_warn(
                                f"Crew {crew_num}: {order_id} verify gate failed — held "
                                f"VERIFY_FAILED (not pushed). Recover from {_salvage_ref}."
                            )
                            return
                        write_lifecycle_event(
                            "VERIFY_OK",
                            f"{order_id} local verify gate passed (Crew {crew_num}) — "
                            f"proceeding to convergence"
                        )
                    write_lifecycle_event(
                        "DISPATCH",
                        f"Crew {crew_num}: merging crew branch into {voyage_branch} "
                        f"(voyage={_voyage_id})"
                    )
                    # BUG-MSO-2026-0268: load convergence_timeout from workspace config
                    # so operators can tune it via workspace.json or --convergence-timeout.
                    _conv_timeout = _completion_config.get("convergenceNetworkTimeout", 60)
                    merge_crew_branch_into_voyage(
                        _voyage_id, crew_num, voyage_branch, order_id=order_id,
                        convergence_timeout=_conv_timeout,
                    )
                    cleanup_crew_worktree(_voyage_id, crew_num)
                except Exception as _merge_exc:
                    # BUG-MSO-2026-0244: convergence FAILURE must GATE completion — the
                    # crew's work is not on the voyage branch, so the order is NOT done.
                    # Preserve the stranded branch for recovery, mark the order
                    # CONVERGENCE_FAILED, ESCALATE, and RETURN without creating a PR or
                    # archiving. BUG-MSO-2026-0243: preserving + slot-freeing here also
                    # stops the stale crew worktree from wedging the next dispatch.
                    from maestro.core.worktrees import (
                        preserve_failed_crew_branch,
                        WorktreeContentConflict,
                        ConvergenceNetworkError,
                    )
                    _salvage = None
                    try:
                        _salvage = preserve_failed_crew_branch(_voyage_id, crew_num, order_id)
                    except Exception:
                        pass

                    # BUG-MSO-2026-0268: RETRYABLE path — transient network/timeout failure.
                    # Re-queue as PENDING for a convergence-only retry; the role's work is
                    # intact on the salvage branch. Dispatcher does NOT idle.
                    if isinstance(_merge_exc, ConvergenceNetworkError):
                        _retry_count = _get_convergence_retry_count(order_id)
                        if _retry_count < _CONVERGENCE_RETRY_CAP:
                            _requeued = _requeue_for_convergence_retry(
                                order_id, str(_merge_exc), salvage=_salvage
                            )
                            _salvage_ref = (_salvage or {}).get("salvageBranch", "<none>")
                            write_lifecycle_event(
                                "CONVERGENCE_RETRY",
                                f"{order_id} re-queued PENDING after transient convergence "
                                f"network failure (attempt {_retry_count + 1}/{_CONVERGENCE_RETRY_CAP}). "
                                f"Salvage: {_salvage_ref}. Crew {crew_num}. Error: {_merge_exc}"
                            )
                            print_warn(
                                f"Crew {crew_num}: {order_id} convergence network error — "
                                f"re-queued for retry "
                                f"(attempt {_retry_count + 1}/{_CONVERGENCE_RETRY_CAP})."
                            )
                            return
                        # Cap exceeded — fall through to CONVERGENCE_FAILED below.
                        write_lifecycle_event(
                            "WARN",
                            f"{order_id} convergence retry cap ({_CONVERGENCE_RETRY_CAP}) reached "
                            f"— escalating to CONVERGENCE_FAILED (Crew {crew_num})"
                        )

                    # FTR-MSO-2026-0267: auto-serialize on genuine content conflicts.
                    # REF_MISSING and push failures are NOT eligible (only WorktreeContentConflict).
                    if isinstance(_merge_exc, WorktreeContentConflict):
                        _serialize_count = _get_serialize_count_for_order(order_id)
                        if _serialize_count < _AUTO_SERIALIZE_CAP:
                            _conflict_files = _merge_exc.conflict_files
                            _serialized = _auto_serialize_order(
                                order_id, _conflict_files, salvage=_salvage
                            )
                            _salvage_ref = (_salvage or {}).get("salvageBranch", "<none>")
                            write_lifecycle_event(
                                "AUTO_SERIALIZE",
                                f"{order_id} re-queued PENDING after content conflict "
                                f"(serializeCount={_serialize_count + 1}/{_AUTO_SERIALIZE_CAP}). "
                                f"Conflicting files: {', '.join(_conflict_files)}. "
                                f"Salvage: {_salvage_ref}. Crew {crew_num}."
                            )
                            print_warn(
                                f"Crew {crew_num}: {order_id} auto-serialized — re-queued "
                                f"(attempt {_serialize_count + 1}/{_AUTO_SERIALIZE_CAP}). "
                                f"Files: {', '.join(_conflict_files)}"
                            )
                            return
                        # Cap exceeded — fall through to CONVERGENCE_FAILED below.
                        write_lifecycle_event(
                            "WARN",
                            f"{order_id} auto-serialize cap ({_AUTO_SERIALIZE_CAP}) reached "
                            f"— escalating to CONVERGENCE_FAILED (Crew {crew_num})"
                        )

                    _record_convergence_failure(order_id, str(_merge_exc), _salvage)
                    _salvage_ref = (_salvage or {}).get("salvageBranch", "<none>")
                    write_lifecycle_event(
                        "ESCALATE",
                        f"{order_id} convergence into {voyage_branch} FAILED — NOT archived "
                        f"(status=CONVERGENCE_FAILED). Work preserved on {_salvage_ref}. "
                        f"Crew {crew_num}. Detail: {_merge_exc}"
                    )
                    print_warn(
                        f"Crew {crew_num}: convergence for {order_id} failed — order held as "
                        f"CONVERGENCE_FAILED (not archived). Recover from {_salvage_ref}: {_merge_exc}"
                    )
                    return

            write_lifecycle_event(
                "FINALIZE",
                f"{order_id} finalization stage 1/3: PR creation (Crew {crew_num})"
            )
            order_title = _get_order_title(order_id)
            project_acronym = state.get("project") or _get_project_for_order(order_id) or ""
            create_pr_for_crew(crew_num, target_repo, voyage_branch, order_id,
                               order_title, project_acronym=project_acronym)

    if status == "COMPLETE":
        # BUG-MSO-2026-0236: single-flight guard — if another dispatcher iteration is
        # already finalizing this (order, role) pair, skip silently.  This prevents the
        # double-finalization that races the role-advance and archives before TST runs.
        _fin_key = (order_id, completed_role)
        with _FINALIZING_LOCK:
            if _fin_key in _FINALIZING_ORDERS:
                write_lifecycle_event(
                    "WARN",
                    f"{order_id} role {completed_role} finalization already in-flight — "
                    f"skipping duplicate process_crew_completion call (Crew {crew_num}, BUG-0236)"
                )
                return
            _FINALIZING_ORDERS.add(_fin_key)

        write_lifecycle_event(
            "FINALIZE",
            f"{order_id} finalization stage 2/3: advancing/archiving order (Crew {crew_num})"
        )

        # BUG-MSO-2026-0222: run advance+unblock on a watchdog thread so a blocked
        # file-system or git call can't freeze the dispatcher indefinitely.
        #
        # BUG-MSO-2026-0224: the watchdog MUST use a daemon thread joined with a
        # timeout — NOT `with ThreadPoolExecutor(...)`. A ThreadPoolExecutor's
        # context-manager exit calls shutdown(wait=True), which blocks forever on a
        # hung finalize task, defeating the watchdog AND hanging the interpreter at
        # exit (the pool's worker thread is non-daemon, so it pins process shutdown —
        # which is what hung pytest). A daemon thread is abandoned cleanly if it
        # overruns: join(timeout) returns, the dispatcher continues, and process exit
        # is never blocked.
        _fin_error: List[BaseException] = []

        def _do_finalize():
            try:
                complete_order(order_id, crew_num, state)
                # v2.0.5: Auto-queue dependent orders whose dependencies are now satisfied
                auto_queue_unblocked_orders(order_id)
            except BaseException as exc:  # noqa: BLE001 — surfaced to caller below
                _fin_error.append(exc)

        _fin_thread = threading.Thread(
            target=_do_finalize,
            name=f"finalize-{order_id}",
            daemon=True,
        )
        _fin_thread.start()
        _fin_thread.join(timeout=FINALIZATION_WATCHDOG_SECONDS)

        if _fin_thread.is_alive():
            write_lifecycle_event(
                "WARN",
                f"{order_id} finalization watchdog fired after {FINALIZATION_WATCHDOG_SECONDS}s "
                f"(Crew {crew_num}) — dispatcher continuing; roleSucceededAt checkpoint will "
                f"self-heal on next restart (BUG-0222)"
            )
            print_warn(
                f"Order {order_id} finalization timed out after {FINALIZATION_WATCHDOG_SECONDS}s — "
                f"will self-heal on next dispatcher restart"
            )
            # BUG-MSO-2026-0236: leave _fin_key in _FINALIZING_ORDERS while the
            # daemon thread is still running so no concurrent caller re-enters.
            # The self-heal path (reset_orphaned_in_progress_orders + roleSucceededAt
            # checkpoint) will complete the finalization on the next restart without
            # re-entering this single-flight guard.
        else:
            # Thread completed (success or error) — release the guard so that
            # self-heal paths can re-enter if needed after a dispatcher restart.
            with _FINALIZING_LOCK:
                _FINALIZING_ORDERS.discard(_fin_key)
            if _fin_error:
                write_lifecycle_event(
                    "WARN",
                    f"{order_id} finalization error: {_fin_error[0]} (Crew {crew_num})"
                )
                print_warn(f"Order {order_id} finalization error: {_fin_error[0]}")
            else:
                write_lifecycle_event(
                    "FINALIZE",
                    f"{order_id} finalization stage 3/3: complete (Crew {crew_num})"
                )

    elif status in ["CRASHED", "ERROR", "TIMEOUT", "AUTH_ERROR", "INTERRUPTED", "MAX_TURNS"]:
        # v7.1: Added AUTH_ERROR + INTERRUPTED — re-queue for retry
        # FTR-MSO-2026-0193: MAX_TURNS treated same as TIMEOUT — REQUEUE with
        # BUG-0023 silent-completion check (commit-detect may ADVANCE instead)
        recover_orphaned_order(order_id, crew_num, status)

    elif status in ["BLOCKED", "MAX_ITERATIONS", "CIRCUIT_BREAKER"]:
        # Stalled - archive with failure status so it doesn't clog the queue
        archive_stalled_order(order_id, crew_num, state, status)

    else:
        # v7.1: Unknown status — treat as crash, re-queue
        print_warn(f"Crew {crew_num} has unknown status '{status}' for {order_id} — re-queuing")
        write_lifecycle_event("WARN", f"Crew {crew_num} unknown status '{status}' for {order_id} — re-queuing")
        recover_orphaned_order(order_id, crew_num, f"UNKNOWN({status})")



def archive_stalled_order(order_id: str, crew_num: int, crew_state: Dict[str, Any], reason: str, stalled_cause: str = "MAX_ITERATIONS"):
    """Archive a stalled order (BLOCKED, MAX_ITERATIONS, CIRCUIT_BREAKER).

    These orders need human review - they go to orders/complete/ with a STALLED status
    so they don't sit in the active queue forever.
    """
    queues_dir = get_queues_dir()
    archive_dir = get_workspace_dir() / "orders" / "complete"
    archive_dir.mkdir(parents=True, exist_ok=True)

    # v7.0: Search ALL queue directories
    search_dirs = [
        queues_dir / "orders", queues_dir / "explicit", queues_dir / "high-level",
        queues_dir / "bugs", queues_dir / "defects", queues_dir / "security",
        queues_dir / "breakdown",
    ]
    requests_dir = queues_dir / "requests"
    if requests_dir.exists():
        for sub in requests_dir.iterdir():
            if sub.is_dir():
                search_dirs.append(sub)

    for search_dir in search_dirs:
        if not search_dir.exists():
            continue
        for json_file in search_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                file_order_id = data.get("orderId") or data.get("id") or json_file.stem
                if file_order_id != order_id:
                    continue

                data["status"] = "STALLED"
                data["stalledAt"] = datetime.now().isoformat()
                data["stalledReason"] = reason
                data["stalledCause"] = stalled_cause  # "MAX_ITERATIONS" | "ERROR" — used by dependency gate
                data["stalledBy"] = {
                    "crew": crew_num,
                    "role": crew_state.get("role", "UNK"),
                    "iterations": crew_state.get("iteration", 0),
                    "startTime": crew_state.get("startTime", ""),
                    "endTime": crew_state.get("endTime", "")
                }

                # BUG-MSO-2026-0298 (GKT F4): salvage BEFORE archival. The
                # requeue path salvages on every timeout, but work done after
                # the last requeue-salvage was unprotected at STALLED
                # escalation — and the falsely-finalised voyage's worktrees
                # were then pruned unsalvaged.
                _stall_vid = _get_voyage_id_for_order(order_id) or data.get("voyageId")
                if _stall_vid:
                    try:
                        from maestro.core.worktrees import (
                            commit_crew_worktree_if_dirty,
                            preserve_failed_crew_branch,
                        )
                        commit_crew_worktree_if_dirty(_stall_vid, crew_num, order_id)
                        _salv = preserve_failed_crew_branch(_stall_vid, crew_num, order_id)
                        if _salv and _salv.get("salvageBranch"):
                            data.setdefault("salvageBranches", []).append({
                                "branch": _salv.get("salvageBranch"),
                                "sha": _salv.get("strandedSha"),
                                "reason": f"STALLED: {reason}",
                                "crew": crew_num,
                                "timestamp": datetime.now().isoformat(),
                            })
                            write_lifecycle_event(
                                "SALVAGE",
                                f"{order_id} in-flight work preserved on "
                                f"{_salv.get('salvageBranch')} before STALLED archival "
                                f"(Crew {crew_num}, BUG-0298)"
                            )
                    except Exception as _stall_salv_exc:
                        write_lifecycle_event(
                            "WARN",
                            f"{order_id} STALLED salvage failed: {_stall_salv_exc} (Crew {crew_num})"
                        )

                # BUG-MSO-2026-0301 (GKT follow-up): the operator must SEE that
                # work survived — 'STALLED, $0, 0 turns' read as total loss in
                # the field when salvage branches held the full deliverable.
                _salvages = data.get("salvageBranches") or []
                if _salvages:
                    _newest = _salvages[-1].get("branch", "?")
                    data["operatorNote"] = (
                        f"Work preserved on {_newest} "
                        f"({len(_salvages)} salvage branch(es) total). "
                        f"Retry with: mso order retry {order_id}"
                    )
                    _salvage_msg = f" — work preserved on {_newest}"
                else:
                    data["operatorNote"] = f"Retry with: mso order retry {order_id}"
                    _salvage_msg = ""

                archive_file = archive_dir / json_file.name
                archive_file.write_text(json.dumps(data, indent=2), encoding='utf-8')
                json_file.unlink()
                # BUG-MSO-2026-0294/0295: STALLED is terminal for dispatch purposes.
                order_ledger.record_terminal(order_id, "STALLED", workspace_dir=get_workspace_dir())
                _commit_lifecycle_transition(
                    [archive_file, json_file],
                    f"lifecycle: archive {order_id} (STALLED)",
                )

                # BUG-MSO-2026-0024: STALLED is a satisfying status, so dependents
                # unblock — refresh the Eight Bells grace clock.
                _mark_order_terminal_now()
                print_warn(f"Order {order_id} STALLED ({reason}) -> archived for review{_salvage_msg}")
                write_lifecycle_event(
                    "STALLED",
                    f"{order_id} STALLED ({reason}) -> archived (Crew {crew_num})"
                    f"{_salvage_msg} — recover with `mso order retry {order_id}` (BUG-0301)"
                )
                # BUG-MSO-2026-0280 (defect B): fire auto-queue from EVERY terminal
                # archival path, not just the COMPLETE/advance path. Without this,
                # dependents of a STALLED order are never queued and the chain halts.
                #
                # Copilot PR #129: the order is ALREADY archived at this point, so
                # the archival must be reported as success (return True) regardless
                # of whether the dependent auto-queue succeeds. Wrap the auto-queue
                # in its own fail-open try/except so an exception here cannot fall
                # through to the outer handler and make us return False for an order
                # that is, in fact, archived. The heartbeat reconciliation pass
                # (reconcile_stranded_dependents) is the backstop if this misses.
                try:
                    auto_queue_unblocked_orders(order_id)
                except Exception as _aq_exc:
                    print_warn(f"Auto-queue after STALLED archival of {order_id} failed "
                               f"(non-fatal; reconciliation pass will recover): {_aq_exc}")
                return True

            except Exception as e:
                print_warn(f"Error processing {json_file}: {e}")

    return False


def archive_all_completed_orders() -> int:
    """Manual sweep: archive terminal-status orders from queues.

    CONSERVATIVE: Only archives orders with confirmed terminal status:
    - COMPLETE, PROCESSED -> archived as-is
    - IN_PROGRESS -> only if crew state confirms COMPLETE (enriches metadata)
    - PENDING, RUNNING -> always skipped (still active work)

    Matches crew state files to add completion metadata.
    Used via --archive-completed CLI command.
    """
    archived = 0
    queues_dir = get_queues_dir()
    archive_dir = get_workspace_dir() / "orders" / "complete"
    archive_dir.mkdir(parents=True, exist_ok=True)

    # Build a lookup of crew states by orderId for metadata enrichment
    crew_states = {}
    for crew_num in range(1, 6):
        state = read_crew_state(crew_num)
        if state and state.get("orderId"):
            crew_states[state["orderId"]] = state

    # Collect all queue directories to scan
    search_dirs = [queues_dir / "orders"]
    requests_dir = queues_dir / "requests"
    if requests_dir.exists():
        for sub in requests_dir.iterdir():
            if sub.is_dir():
                search_dirs.append(sub)

    for search_dir in search_dirs:
        if not search_dir.exists():
            continue
        for json_file in search_dir.glob("*.json"):
            try:
                data = json.loads(json_file.read_text(encoding='utf-8'))
                status = data.get("status", "PENDING")
                order_id = data.get("id", json_file.stem)

                # Only archive confirmed terminal statuses
                should_archive = False

                if status in ["COMPLETE", "PROCESSED"]:
                    # Already marked complete - safe to archive
                    should_archive = True

                elif status == "IN_PROGRESS":
                    # Check crew state - only archive if crew confirms COMPLETE
                    crew_state = crew_states.get(order_id, {})
                    crew_status = crew_state.get("status", "") if crew_state else ""

                    if crew_status == "COMPLETE":
                        # Crew finished - enrich and archive
                        data["status"] = "COMPLETE"
                        data["completedAt"] = datetime.now().isoformat()
                        data["completedBy"] = {
                            "crew": crew_state.get("crewNumber"),
                            "role": crew_state.get("role", "UNK"),
                            "iterations": crew_state.get("iteration", 0),
                            "startTime": crew_state.get("startTime", ""),
                            "endTime": crew_state.get("endTime", "")
                        }
                        should_archive = True
                    else:
                        # Crew still working, crashed, or reassigned - leave in queue
                        print_info(f"{order_id} IN_PROGRESS (crew: {crew_status or 'unknown'}) -> skipped")

                # PENDING, RUNNING, and unconfirmed IN_PROGRESS are always skipped

                if not should_archive:
                    continue

                # Archive it
                data["archivedAt"] = datetime.now().isoformat()
                archive_file = archive_dir / json_file.name
                archive_file.write_text(json.dumps(data, indent=2), encoding='utf-8')
                json_file.unlink()

                print_ok(f"{order_id} ({data['status']}) -> archived")
                archived += 1

            except Exception as e:
                print_warn(f"Error processing {json_file}: {e}")

    return archived


def auto_queue_unblocked_orders(completed_order_id: str):
    """v2.0.5: When an order completes, auto-queue any orders from orders/active/
    whose dependencies are now satisfied.

    This closes the critical gap where orders sat in orders/active/ but never
    made it into queues/orders/ because no one copied them there.

    Logic:
    1. Scan orders/active/ for orders with a 'dependencies' field
    2. For each, check if ALL dependencies exist in orders/complete/
    3. If satisfied and not already in a queue, copy to queues/orders/
    """
    admiralty_dir = get_workspace_dir()
    active_dir = admiralty_dir / "orders" / "active"
    complete_dir = admiralty_dir / "orders" / "complete"
    queue_dir = get_queues_dir() / "orders"
    queue_dir.mkdir(parents=True, exist_ok=True)

    if not active_dir.exists():
        return

    # Build set of completed order IDs for fast lookup
    completed_ids = set()
    if complete_dir.exists():
        for f in complete_dir.glob("*.json"):
            completed_ids.add(f.stem)

    # Statuses that mean "this order is finished — do not re-queue it"
    # Defends against complete/ lagging behind active/ across branches
    # (BUG-ADM-2026-0002): the rename from active/ to complete/ might not
    # have landed on the current branch yet, so the complete/ glob above
    # wouldn't catch it. In that case, the order's own status field is the
    # authoritative signal — include every terminal outcome that fleet_runner
    # treats as archived/complete elsewhere so all stalled-but-finished
    # variants are skipped consistently.
    TERMINAL_STATUSES = {
        "COMPLETE",
        "FAILED",
        "CANCELLED",
        "BLOCKED",
        "STALLED",
        "MAX_ITERATIONS",
        "PROCESSED",
    }

    queued_count = 0
    for order_file in list(active_dir.glob("*.json")):
        try:
            data = json.loads(order_file.read_text(encoding='utf-8'))
            order_id = data.get("orderId", order_file.stem)

            # Skip if already in a queue
            if (queue_dir / order_file.name).exists():
                continue

            # Skip if already completed (archive present)
            if order_id in completed_ids:
                continue

            # Skip if the order's own status says it's finished, even when
            # the archive isn't on this branch yet (BUG-ADM-2026-0002).
            if data.get("status", "").upper() in TERMINAL_STATUSES:
                continue

            # Check dependencies - support both 'dependencies' and 'dependsOn' fields
            deps = data.get("dependencies", data.get("dependsOn", []))
            if not deps:
                # No dependencies — queue immediately
                data["status"] = "PENDING"
                queue_file = queue_dir / order_file.name
                queue_file.write_text(json.dumps(data, indent=2), encoding='utf-8')
                queued_count += 1
                print_ok(f"Auto-queued {order_id} (no dependencies)")
                write_lifecycle_event("AUTOQUEUE", f"{order_id} auto-queued (no dependencies)")
                continue

            # Check if all dependencies are satisfied
            all_satisfied = True
            for dep_id in deps:
                if dep_id not in completed_ids:
                    all_satisfied = False
                    break

            if all_satisfied:
                data["status"] = "PENDING"
                queue_file = queue_dir / order_file.name
                queue_file.write_text(json.dumps(data, indent=2), encoding='utf-8')
                queued_count += 1
                print_ok(f"Auto-queued {order_id} (dependency {completed_order_id} satisfied)")
                write_lifecycle_event("AUTOQUEUE",
                    f"{order_id} auto-queued after {completed_order_id} completed")

        except Exception as e:
            print_warn(f"Error checking {order_file.name} for auto-queue: {e}")

    if queued_count > 0:
        print_ok(f"Auto-queued {queued_count} order(s) after {completed_order_id} completed")


def reconcile_stranded_dependents() -> int:
    """BUG-MSO-2026-0280: Heartbeat reconciliation pass.

    On every dispatcher tick, scan orders/active/ for orders whose full
    dependsOn set is satisfied by orders/complete/ but are not yet queued
    or in-progress. Queue any found with a RECONCILE_QUEUED lifecycle event.

    This is a self-healing safety net — it catches dependents that were
    stranded because the post-completion auto-queue event did not fire
    (e.g. order archived via BLOCKED/STALLED path, dispatcher crash, etc.).

    Returns the number of orders queued.
    """
    admiralty_dir = get_workspace_dir()
    active_dir = admiralty_dir / "orders" / "active"
    complete_dir = admiralty_dir / "orders" / "complete"
    queue_dir = get_queues_dir() / "orders"
    queue_dir.mkdir(parents=True, exist_ok=True)

    if not active_dir.exists():
        return 0

    # Build set of completed order IDs for fast lookup
    completed_ids: set = set()
    if complete_dir.exists():
        for f in complete_dir.glob("*.json"):
            completed_ids.add(f.stem)

    TERMINAL_STATUSES = {
        "COMPLETE", "FAILED", "CANCELLED", "BLOCKED",
        "STALLED", "MAX_ITERATIONS", "PROCESSED",
    }

    queued_count = 0
    for order_file in list(active_dir.glob("*.json")):
        try:
            data = json.loads(order_file.read_text(encoding="utf-8"))
            order_id = data.get("orderId", order_file.stem)

            # Already queued or in a terminal state — skip
            if (queue_dir / order_file.name).exists():
                continue
            if order_id in completed_ids:
                continue
            if data.get("status", "").upper() in TERMINAL_STATUSES:
                continue
            # Already in-progress — skip (these are actively being worked on)
            if data.get("status", "").upper() in {"IN_PROGRESS", "RUNNING"}:
                continue

            deps = data.get("dependencies", data.get("dependsOn", []))
            if not deps:
                continue  # no-dep orders handled by normal dispatch; skip here

            # Copilot PR #129: use the SAME status-aware dependency gate the
            # dispatcher uses (check_dependencies_satisfied), not bare presence
            # in complete/. BUG-MSO-2026-0251: an ERROR-escalated STALLED
            # dependency (stalledCause="ERROR", zero work) must NOT satisfy
            # dependsOn — existence-only would wrongly queue a dependent that is
            # still blocked by policy. Normalise to the `dependsOn` key the
            # checker expects so the legacy `dependencies` key is honoured too.
            satisfied, _waiting_on = check_dependencies_satisfied({**data, "dependsOn": deps})
            if satisfied:
                data["status"] = "PENDING"
                queue_file = queue_dir / order_file.name
                queue_file.write_text(json.dumps(data, indent=2), encoding="utf-8")
                queued_count += 1
                print_ok(f"Reconciled stranded dependent {order_id} -> PENDING")
                write_lifecycle_event(
                    "RECONCILE_QUEUED",
                    f"{order_id} queued by reconciliation pass — dependsOn satisfied in complete/ "
                    f"but order was stranded (BUG-MSO-2026-0280)"
                )

        except Exception as e:
            print_warn(f"reconcile_stranded_dependents: error checking {order_file.name}: {e}")

    return queued_count


def sweep_decks(quiet: bool = False) -> dict:
    """Automatic deck sweep: clean stale orders and complete finished voyages.

    v2.0.5: Called at Eight Bells and via --sweep-decks CLI command.
    BUG-MSO-2026-0289: also called on the dispatcher's heartbeat throttle (with
    quiet=True) so a voyage whose orders are ALL complete is finalised + its PR
    promoted PER-VOYAGE — not held hostage until the WHOLE workspace goes idle
    (Eight Bells). `quiet` suppresses the per-tick console chatter; the `SWEEP`
    lifecycle event still fires whenever real work is done.

    Actions:
    1. Remove stale duplicates from orders/active/ that already exist in orders/complete/
    2. Archive prompts/active/ files for completed orders to prompts/complete/
    3. Check all active voyages - if all orders are COMPLETE, mark voyage COMPLETE
       and move from voyages/active/ to voyages/complete/

    Returns a summary dict with counts of actions taken.
    """
    admiralty_dir = get_workspace_dir()
    active_orders_dir = admiralty_dir / "orders" / "active"
    complete_orders_dir = admiralty_dir / "orders" / "complete"
    active_voyages_dir = admiralty_dir / "voyages" / "active"
    complete_voyages_dir = admiralty_dir / "voyages" / "complete"
    complete_voyages_dir.mkdir(parents=True, exist_ok=True)

    summary = {"stale_orders_removed": 0, "prompts_archived": 0, "voyages_completed": 0, "errors": []}

    # --- Step 1: Remove stale active orders that have completed copies ---
    if active_orders_dir.exists() and complete_orders_dir.exists():
        completed_ids = {f.stem for f in complete_orders_dir.glob("*.json")}
        for order_file in list(active_orders_dir.glob("*.json")):
            if order_file.stem in completed_ids:
                try:
                    order_file.unlink()
                    summary["stale_orders_removed"] += 1
                    print_ok(f"Swept stale active order: {order_file.stem}")
                except Exception as e:
                    summary["errors"].append(f"Failed to remove {order_file.stem}: {e}")

    # --- Step 2: Archive prompts for completed orders ---
    active_prompts_dir = admiralty_dir / "prompts" / "active"
    complete_prompts_dir = admiralty_dir / "prompts" / "complete"
    if active_prompts_dir.exists() and complete_orders_dir.exists():
        complete_prompts_dir.mkdir(parents=True, exist_ok=True)
        completed_ids = {f.stem for f in complete_orders_dir.glob("*.json")}
        for prompt_file in list(active_prompts_dir.glob("*.md")):
            # Prompt files are named {ORDER-ID}-{ROLE}.md — extract order ID
            parts = prompt_file.stem.rsplit("-", 1)
            order_id = parts[0] if len(parts) == 2 else prompt_file.stem
            if order_id in completed_ids:
                try:
                    dest = complete_prompts_dir / prompt_file.name
                    prompt_file.replace(dest)  # BUG-MSO-2026-0291: overwrite-safe (rename raises WinError 183 if dest exists on Windows)
                    summary["prompts_archived"] += 1
                except Exception as e:
                    summary["errors"].append(f"Failed to archive prompt {prompt_file.name}: {e}")

    # --- Step 3: Complete finished voyages ---
    if active_voyages_dir.exists():
        for voyage_file in list(active_voyages_dir.glob("VOY-*.json")):
            try:
                voyage = json.loads(voyage_file.read_text(encoding='utf-8'))
                voyage_id = voyage.get("voyageId", voyage_file.stem)
                orders = voyage.get("orders", [])

                # BUG-ADM-2026-0012: only sweep ACTIVE voyages. The guard is
                # strict — any status that is not exactly "ACTIVE" (and not
                # None) is skipped. That covers HELD, PROPOSED, DRAFT,
                # PAUSED, PLANNED, APPROVED, COMPLETE, FAILED, ABANDONED,
                # and any custom workspace status. Operators relying on
                # non-ACTIVE statuses to pause / queue / hold a voyage need
                # the sweep to leave it alone. Legacy voyages without a
                # status field at all (status=None) fall through and remain
                # eligible for sweep — backwards compat for pre-status
                # voyage manifests.
                voyage_status = voyage.get("status")
                if voyage_status is not None and voyage_status != "ACTIVE":
                    continue

                if not orders:
                    continue

                # Check if ALL orders in this voyage have completed copies.
                # BUG-ADM-2026-0010: file presence alone is not enough — the
                # completed order must also be owned by THIS voyage. Without
                # this check, an order ID that happens to exist in
                # orders/complete/ from a prior voyage (cross-voyage ID
                # reuse, manual residue, fix-and-revert cycle) will falsely
                # mark the new voyage COMPLETE before its crews ever ran.
                # BUG-MSO-2026-0288: load the skip list once before the per-order loop.
                _sweep_skipped_ids = load_skipped_order_ids()
                all_complete = True
                for order_entry in orders:
                    # orders field may be a list of strings or a list of dicts
                    if isinstance(order_entry, str):
                        order_id = order_entry
                    else:
                        # BUG-ADM-2026-0012: schemas use both `orderId` and
                        # `id` in the wild (PSG manifests use `id`; framework
                        # manifests use `orderId`). Accept either — falling
                        # back to "" if neither is present.
                        order_id = (
                            order_entry.get("orderId")
                            or order_entry.get("id")
                            or ""
                        )
                    if not order_id:
                        # BUG-ADM-2026-0012: pre-fix this silently skipped an
                        # unidentifiable order entry. That left all_complete
                        # True for voyages with no recognisable order keys —
                        # they'd auto-archive without any crew ever running.
                        # Now: treat as not-complete (operator must fix the
                        # voyage manifest before sweep advances).
                        # Copilot review on PR #62: write_lifecycle_event
                        # already swallows exceptions internally, so the
                        # outer try/except is redundant.
                        all_complete = False
                        write_lifecycle_event(
                            "SWEEP_UNREADABLE_ORDER",
                            f"Voyage {voyage_id}: order entry has neither "
                            f"`orderId` nor `id` field — refusing to sweep. "
                            "Fix the voyage manifest's orders[] schema."
                        )
                        break
                    # BUG-MSO-2026-0288: a skipped stale order is treated as satisfied
                    # so it cannot strand a voyage as never-complete.
                    if order_id in _sweep_skipped_ids:
                        continue
                    completed_file = complete_orders_dir / f"{order_id}.json"
                    if not completed_file.exists():
                        all_complete = False
                        break

                    # BUG-ADM-2026-0010: ownership verification.
                    # Copilot review on PR #60: catch UnicodeDecodeError too
                    # (Path.read_text with explicit encoding raises it on
                    # invalid UTF-8). Without it, the error bubbles to the
                    # outer except Exception and aborts voyage processing
                    # rather than just refusing the sweep. Also record the
                    # specific blocker in summary + lifecycle log so
                    # operators can find the offending file.
                    try:
                        order_data = json.loads(completed_file.read_text(encoding='utf-8'))
                    except (OSError, json.JSONDecodeError, UnicodeDecodeError) as exc:
                        all_complete = False
                        err_msg = (
                            f"Voyage {voyage_id}: cannot read completed order "
                            f"{order_id} ({type(exc).__name__}: {str(exc)[:100]}) — "
                            "treating as not-complete (sweep refused)."
                        )
                        summary["errors"].append(err_msg)
                        try:
                            write_lifecycle_event("SWEEP_READ_ERROR", err_msg)
                        except Exception:
                            pass
                        break
                    completed_voyage_id = order_data.get("voyageId") or ""
                    if completed_voyage_id and completed_voyage_id != voyage_id:
                        all_complete = False
                        try:
                            write_lifecycle_event(
                                "SWEEP_OWNERSHIP_MISMATCH",
                                f"Voyage {voyage_id} references {order_id}, "
                                f"but the completed order is owned by "
                                f"{completed_voyage_id}. Refusing to sweep "
                                f"{voyage_id} as COMPLETE — fix the voyage's "
                                "orders[] reference or re-run the order under "
                                f"{voyage_id}."
                            )
                        except Exception:
                            pass
                        break

                    # BUG-MSO-2026-0296 (GKT F1): STALLED is NOT COMPLETE.
                    # archive_stalled_order files STALLED orders into
                    # orders/complete/ for dependency-resolution reasons, but
                    # file PRESENCE must not finalise the voyage — that
                    # falsely archived GKT's voyage and let the worktree
                    # pruner destroy unsalvaged work. Only genuine COMPLETE
                    # status counts toward voyage completion.
                    _archived_status = (order_data.get("status") or "COMPLETE").upper()
                    if _archived_status not in ("COMPLETE", "COMPLETED"):
                        all_complete = False
                        write_lifecycle_event(
                            "SWEEP_STALLED_ORDER",
                            f"Voyage {voyage_id}: {order_id} is archived with "
                            f"status={_archived_status}, not COMPLETE — refusing "
                            f"to finalise the voyage. Recover it with "
                            f"`mso order retry {order_id}` (BUG-0296)."
                        )
                        break

                if not all_complete:
                    continue

                # All orders complete - update voyage status and move to complete
                voyage["status"] = "COMPLETE"
                if not voyage.get("startedDate"):
                    voyage["startedDate"] = voyage.get("createdDate",
                        datetime.now().strftime("%Y-%m-%d"))
                if not voyage.get("completedDate"):
                    voyage["completedDate"] = datetime.now().strftime("%Y-%m-%d")

                for o in voyage.get("orders", []):
                    if isinstance(o, dict):
                        o["status"] = "COMPLETE"
                for p in voyage.get("phases", []):
                    p["status"] = "COMPLETE"
                for ac in voyage.get("acceptanceCriteria", []):
                    if ac.get("status") == "PENDING":
                        ac["status"] = "VERIFIED"
                for g in voyage.get("gates", {}).values():
                    if g.get("status") == "PENDING":
                        g["status"] = "PASSED"
                        if not g.get("verifiedAt"):
                            g["verifiedAt"] = voyage["completedDate"]

                dest = complete_voyages_dir / voyage_file.name
                dest.write_text(json.dumps(voyage, indent=2), encoding='utf-8')
                voyage_file.unlink()

                summary["voyages_completed"] += 1
                print_ok(f"Voyage {voyage_id} COMPLETE -> moved to voyages/complete/")
                write_lifecycle_event("SWEEP",
                    f"Voyage {voyage_id} auto-completed (all orders done)")

                # FTR-MSO-2026-0287 (R1): the voyage is done — promote its draft
                # PR to ready-for-review so the single end-of-voyage CI run fires
                # before merge review. No-op when draft mode is off.
                try:
                    promote_voyage_pr_ready(voyage)
                except Exception as _prx:
                    print_warn(f"PR promote-on-finalisation for {voyage_id} failed: {_prx}")

                # Clean up voyage worktree (admin) and any lingering crew worktrees
                try:
                    from maestro.core.worktrees import (
                        cleanup_voyage_worktree,
                        cleanup_all_crew_worktrees,
                    )
                    cleanup_all_crew_worktrees(voyage_id)
                    cleanup_voyage_worktree(voyage_id)
                except Exception as wt_exc:
                    print_warn(f"Worktree cleanup for {voyage_id} failed: {wt_exc}")

            except Exception as e:
                summary["errors"].append(f"Error processing voyage {voyage_file.name}: {e}")

    # Log summary
    total_actions = summary["stale_orders_removed"] + summary["prompts_archived"] + summary["voyages_completed"]
    if total_actions > 0:
        if not quiet:
            print_ok(f"Deck sweep: {summary['stale_orders_removed']} stale orders removed, "
                     f"{summary['prompts_archived']} prompts archived, "
                     f"{summary['voyages_completed']} voyages completed")
        write_lifecycle_event("SWEEP", f"Deck sweep: {summary['stale_orders_removed']} orders, "
                              f"{summary['prompts_archived']} prompts, "
                              f"{summary['voyages_completed']} voyages")
    elif not quiet:
        print_info("Deck sweep: all clear, nothing to clean")

    if summary["errors"]:
        for err in summary["errors"]:
            print_warn(f"Sweep error: {err}")

    return summary


def _validate_mcp_before_launch(item: Dict[str, Any], order_data: Dict[str, Any]) -> None:
    """
    Validate MCP server permissions before launching a crew.
    Raises RuntimeError (caught by dispatch_crew) with lifecycle log entry on
    violation. Logs a warning and continues in permissive mode when no registry
    is present.
    """
    try:
        from maestro.mcp import validate_mcp_permissions, load_registry
    except ImportError:
        return  # mcp module not available — skip silently

    role: str = item.get("role", "")
    workspace = Path(get_workspace_dir()).parent

    # Per-order override: order.data.mcpServers lists required server names.
    # order_data is untyped runtime data so the field could legally be any JSON
    # type; treat anything other than a list[str] as a schema error rather than
    # iterate characters of a string into validate_mcp_permissions.
    raw_order_mcp_servers = order_data.get("mcpServers")
    order_mcp_servers: Optional[List[str]]
    if raw_order_mcp_servers is None:
        order_mcp_servers = None
    elif (
        isinstance(raw_order_mcp_servers, list)
        and all(isinstance(s, str) for s in raw_order_mcp_servers)
    ):
        order_mcp_servers = raw_order_mcp_servers
    else:
        order_id = item.get("id", "?")
        error = "Invalid order schema: 'mcpServers' must be a list of strings"
        print_error(f"MCP validation failed for {order_id} ({role}): {error}")
        write_lifecycle_event(
            "MCP_BLOCK",
            f"Crew blocked — {order_id} ({role}): {error}",
        )
        raise RuntimeError(f"MCP validation failed: {error}")

    # Permissive-mode check: no registry → warn and allow
    registry = load_registry(workspace)
    if registry is None:
        print_warn(
            f"MCP registry not found (.mso/config/mcp-servers.json) — "
            f"running in permissive mode for {item.get('id', '?')}"
        )
        write_lifecycle_event(
            "MCP_WARN",
            f"No MCP registry — permissive mode for {item.get('id', '?')} ({role})",
        )
        return

    error = validate_mcp_permissions(role, workspace, server_names=order_mcp_servers)
    if error:
        order_id = item.get("id", "?")
        print_error(f"MCP validation failed for {order_id} ({role}): {error}")
        write_lifecycle_event(
            "MCP_BLOCK",
            f"Crew blocked — {order_id} ({role}): {error}",
        )
        raise RuntimeError(f"MCP validation failed: {error}")


_REQUIRES_TARGET_REPO_ROLES = {"SHP", "BOS", "BLD", "TST"}


def _load_voyage_by_id(voyage_id: str) -> Dict[str, Any]:
    """Look up a voyage's JSON across active and complete locations.

    BUG-ADM-2026-0009: needed by resolve_voyage_branch_for_order so an
    order without explicit voyageBranch can inherit from its parent voyage.
    Returns {} when not found.
    """
    if not voyage_id:
        return {}
    try:
        adm = get_workspace_dir()
    except Exception:
        return {}
    for sub in ("voyages/active", "voyages/complete"):
        path = adm / sub / f"{voyage_id}.json"
        if path.exists():
            try:
                return json.loads(path.read_text(encoding="utf-8"))
            except Exception:
                continue
    return {}


def resolve_voyage_branch_for_order(order_data: Dict[str, Any]) -> str:
    """Resolve voyageBranch for an order, walking the propagation chain:

      1. order.voyageBranch              (explicit on the order)
      2. parent_voyage.branch            (inherited from voyage)
      3. MAESTRO_SPRINT_BRANCH env       (operator-level, current shell)
      4. ""                              (loose — caller must refuse)

    BUG-ADM-2026-0009: this is the single source of truth for an order's
    branch identity. dispatch_crew calls it, persists the resolved value
    back to the order JSON if it came from layers 2 or 3, so every
    subsequent role in the order's roleSequence sees the same branch
    without re-resolving.

    Also emits a BRANCH_MISMATCH lifecycle event (defence-in-depth) when
    the order has an explicit voyageBranch that disagrees with its parent
    voyage's branch — operator-edited drift is the most likely cause.
    """
    if not isinstance(order_data, dict):
        return os.environ.get("MAESTRO_SPRINT_BRANCH", "").strip()

    explicit = (order_data.get("voyageBranch") or "").strip()
    voyage_id = order_data.get("voyageId") or ""
    voyage_branch = ""
    if voyage_id:
        voyage = _load_voyage_by_id(voyage_id)
        voyage_branch = (voyage.get("branch") or voyage.get("voyageBranch") or "").strip()

    if explicit:
        if voyage_branch and voyage_branch != explicit:
            try:
                write_lifecycle_event(
                    "BRANCH_MISMATCH",
                    f"{order_data.get('orderId', '?')}: order.voyageBranch="
                    f"`{explicit}` but voyage {voyage_id}.branch=`{voyage_branch}` "
                    "— honouring the order. Reconcile by hand if this drift is "
                    "unintentional."
                )
            except Exception:
                pass
        return explicit

    if voyage_branch:
        return voyage_branch

    return os.environ.get("MAESTRO_SPRINT_BRANCH", "").strip()


def _persist_voyage_branch_to_order(item: Dict[str, Any], voyage_branch: str) -> None:
    """Write the resolved voyageBranch back to the order JSON on disk.

    BUG-ADM-2026-0009: when resolve_voyage_branch_for_order pulls the
    branch from the parent voyage or the env var, persist it onto the
    order so the next role in roleSequence reads it directly. Single
    source of truth from this point onward — no re-resolution races.
    """
    try:
        path = Path(item["path"])
        data = item.get("data", {})
        if data.get("voyageBranch") == voyage_branch:
            return  # already up to date
        data["voyageBranch"] = voyage_branch
        path.write_text(json.dumps(data, indent=2), encoding="utf-8")
        item["data"] = data
    except Exception as exc:
        print_warn(
            f"Could not persist voyageBranch={voyage_branch} to {item.get('id', '?')}: {exc}"
        )


def _reset_crew_tracking(crew_num: int, order_id: str) -> None:
    """Reset crew tracking files for a fresh order dispatch (BUG-MSO-2026-0030).

    Overwrites files_modified.json, activity.jsonl, activity.txt, and progress.md
    so stale paths from previous orders/voyages don't carry forward.
    Files preserved intentionally: crew.log, ralph-state.md, state.json, heartbeat.txt
    (those are already reset elsewhere in the dispatch path).
    """
    crew_dir = get_crew_dir(crew_num)
    crew_dir.mkdir(parents=True, exist_ok=True)
    resets = {
        "files_modified.json": "[]\n",
        "activity.jsonl": "",
        "activity.txt": "",
        "progress.md": f"# Crew {crew_num} Progress — {order_id}\n\n## Status: RUNNING\n",
    }
    for filename, content in resets.items():
        target = crew_dir / filename
        try:
            target.write_text(content, encoding="utf-8")
        except OSError as e:
            print_warn(f"Crew {crew_num}: Failed to reset {filename}: {e}")


def dispatch_squad(crew_num: int, item: Dict[str, Any], max_iterations: int = 25,
                   timeout_minutes: int = 120, voyage_branch: str = "",
                   max_turns: int = 200) -> Optional[int]:
    """Dispatch a crew to work on a queue item. Returns PID or None."""
    codename = _get_crew_name(crew_num)

    print_info(f"Dispatching Crew {crew_num} ({codename}) as {item['role']} for {item['id']}...")

    order_data = item.get("data", {})
    role = item.get("role", "")

    # BUG-ADM-2026-0009: resolve voyageBranch via the order/voyage/env chain.
    # The chain takes precedence over the dispatcher's `voyage_branch`
    # parameter — callers (run_dispatcher) compute that argument from
    # voyageId pattern matching (e.g. `voyage/<id>`) which can disagree
    # with the voyage JSON's actual `branch` field (Copilot review on
    # PR #58). The order/voyage entry wins; the parameter is a fallback
    # used only when the chain returns empty.
    resolved_branch = resolve_voyage_branch_for_order(order_data)
    if resolved_branch:
        effective_branch = resolved_branch
        # If the caller passed an explicit voyage_branch argument that
        # disagrees with the resolved value, log it — the resolved value
        # wins but the drift might be intentional (operator one-shot).
        if voyage_branch and voyage_branch != resolved_branch:
            try:
                write_lifecycle_event(
                    "BRANCH_MISMATCH",
                    f"{item.get('id', '?')}: dispatch arg voyage_branch="
                    f"`{voyage_branch}` overridden by resolved value "
                    f"`{resolved_branch}` (order/voyage wins)."
                )
            except Exception:
                pass
    else:
        effective_branch = voyage_branch or ACTIVE_VOYAGE_BRANCH

    # Persist the resolved value back to the order JSON so the next role in
    # roleSequence sees it directly and downstream handoffs can carry it.
    if effective_branch and effective_branch != order_data.get("voyageBranch"):
        _persist_voyage_branch_to_order(item, effective_branch)
        order_data = item.get("data", order_data)

    target_repo = order_data.get("targetRepo", "")
    project_acronym = order_data.get("project", "")

    # BUG-MSO-2026-0245: per-order turn-budget override. A heavy order/role can raise
    # its turn budget above the dispatch-level --max-turns via order JSON fields:
    #   "maxTurnsByRole": {"TST": 120}   (per-role; wins for that role)
    #   "maxTurns": 120                  (whole-order; all roles)
    # Falls back to the dispatch-level max_turns when neither is set.
    effective_max_turns = max_turns
    _by_role = order_data.get("maxTurnsByRole") or {}
    try:
        if isinstance(_by_role, dict) and role in _by_role:
            effective_max_turns = int(_by_role[role])
        elif order_data.get("maxTurns"):
            effective_max_turns = int(order_data["maxTurns"])
    except (TypeError, ValueError):
        effective_max_turns = max_turns  # malformed override → ignore, keep default
    # A turn budget must be >= 1; a non-positive override (e.g. 0 or -5) would be
    # invalid / cause immediate termination, so ignore it and keep the default
    # (Copilot PR #110).
    if effective_max_turns < 1:
        effective_max_turns = max_turns
    if effective_max_turns != max_turns:
        write_lifecycle_event(
            "DISPATCH",
            f"{item['id']} ({role}): per-order turn budget {effective_max_turns} "
            f"(override of dispatch default {max_turns}) — BUG-0245"
        )
    if not target_repo:
        target_repo = _resolve_target_repo_from_project(order_data)

    # BUG-ADM-2026-0008 + BUG-ADM-2026-0009: combined dispatch guard.
    #   - All roles need a resolvable voyageBranch (BUG-0009 — every role
    #     writes some artefact and silent misrouting hits all of them)
    #   - SHP/BOS additionally need a resolvable targetRepo (BUG-0008 —
    #     code/test crews otherwise dispatch against a placeholder string
    #     and exit 1-iteration with no commits, burning ~$0.40 each)
    missing: list[str] = []
    if not effective_branch:
        missing.append("voyageBranch")
    if role in _REQUIRES_TARGET_REPO_ROLES and not target_repo:
        missing.append("targetRepo")

    if missing:
        msg = (
            f"Refusing to dispatch {role} for {item['id']}: "
            f"{', '.join(missing)} not resolvable "
            f"(project={project_acronym or 'unknown'}). "
            "Set order.voyageBranch (or voyage.branch on the parent voyage), "
            "and 'repo' under projects.json[<project>] for SHP/BOS roles."
        )
        print_error(msg)
        try:
            write_lifecycle_event("DISPATCH_BLOCK", msg)
        except Exception:
            pass
        try:
            mark_work_item_failed(item, reason=f"{', '.join(missing)} not resolved")
        except Exception:
            pass
        return None

    # BUG-MSO-2026-0273: fast-path convergence for orders with a pending salvage branch.
    # When _requeue_for_convergence_retry sets convergenceRetry.salvageBranch, the crew's
    # work is already done — skip role invocation and merge the salvage directly.
    _salvage_info = order_data.get("convergenceRetry") or {}
    _salvage_br = _salvage_info.get("salvageBranch")
    _retry_count_fp = order_data.get("convergenceRetryCount", 0)
    if _salvage_br and _retry_count_fp > 0 and effective_branch:
        _voyage_id_fp = order_data.get("voyageId", "")
        if _voyage_id_fp:
            print_info(
                f"Crew {crew_num}: fast-path convergence for {item['id']} "
                f"(salvage={_salvage_br})"
            )
            _handled = _fast_converge_salvage_branch(
                item["id"], _salvage_br, effective_branch, _voyage_id_fp
            )
            if _handled:
                # Fast-path took ownership — no crew needed.
                return None
            # _handled is False: salvage branch missing, fall through to normal dispatch.
            print_info(
                f"Crew {crew_num}: salvage branch absent for {item['id']} — "
                f"dispatching normal role re-run"
            )

    # Generate prompt
    prompt_file = generate_prompt_for_item(item)

    # Mark item as in progress
    mark_work_item_in_progress(item, crew_num)

    # BUG-MSO-2026-0294 defence-in-depth: re-validate the claim immediately
    # before launch. If the on-disk file no longer carries THIS dispatch's
    # claim (concurrent mutation, git rewind between selection and launch),
    # abort rather than launch a duplicate crew. Items without a queue file
    # (synthetic test items, already-moved files) skip the check.
    _claim_path = item.get("path")
    if _claim_path and Path(_claim_path).exists():
        try:
            _claim_check = json.loads(Path(_claim_path).read_text(encoding="utf-8"))
            _claimed_crew = (_claim_check.get("assignedTo") or {}).get("crew")
            if _claim_check.get("status") != "IN_PROGRESS" or _claimed_crew != crew_num:
                if _ws_for_item(item) is not None:
                    order_ledger.record_released(item["id"], "claim re-validation failed pre-launch",
                                                 workspace_dir=_ws_for_item(item))
                write_lifecycle_event(
                    "WARN",
                    f"{item['id']} claim re-validation failed pre-launch "
                    f"(status={_claim_check.get('status')}, assignedTo.crew={_claimed_crew}, "
                    f"expected crew {crew_num}) — aborting dispatch (BUG-0294)"
                )
                return None
        except (OSError, json.JSONDecodeError):
            pass  # unreadable file — existing error paths handle it

    # BUG-MSO-2026-0030: reset tracking files so stale data from previous
    # orders/voyages doesn't carry forward into this crew's run.
    _reset_crew_tracking(crew_num, item["id"])

    if effective_branch and target_repo:
        ensure_voyage_branch_exists(target_repo, effective_branch, project_acronym=project_acronym)

    # v8.13: Track dispatched repos for post-voyage PR creation
    if target_repo:
        title = item.get("title", item.get("id", ""))
        _SESSION_TARGET_REPOS.setdefault(target_repo, []).append(f"{item['id']}: {title}")
        # v2.0.2: Track voyage branch per repo
        if effective_branch:
            _SESSION_REPO_BRANCHES[target_repo] = effective_branch

    # BUG-MSO-2026-0240: Use per-crew git worktree on a per-crew branch so
    # concurrent crews of the same voyage never share a working tree or
    # git index.  Each crew gets:
    #   worktree: .mso/voyages/active/<voyage_id>/.worktree-crew<N>
    #   branch:   crew/<voyage_id>-<N>  (branched from voyage branch at dispatch time)
    # MAESTRO_SPRINT_BRANCH is set to the crew branch so the branch guard
    # allows mutations on that branch.  On order completion, fleet_runner
    # calls merge_crew_branch_into_voyage() to converge the crew's work back
    # onto the voyage branch before PR creation.
    voyage_id = order_data.get("voyageId", "")
    worktree_path = None
    _crew_branch = effective_branch  # fallback: branch guard armed with voyage branch
    if effective_branch and voyage_id:
        try:
            from maestro.core.worktrees import prepare_crew_worktree, crew_branch_name
            wt = prepare_crew_worktree(voyage_id, crew_num, effective_branch)
            worktree_path = str(wt)
            _crew_branch = crew_branch_name(voyage_id, crew_num)
            write_lifecycle_event(
                "DISPATCH",
                f"Crew {crew_num}: isolated worktree ready at {wt} "
                f"(voyage={voyage_id}, crew_branch={_crew_branch})"
            )
        except Exception as wt_exc:
            err_summary = f"{type(wt_exc).__name__}: {wt_exc}"[:300]
            print_warn(
                f"Crew {crew_num}: Per-crew worktree prepare failed ({err_summary}) — "
                "crew will self-manage (isolation not guaranteed)"
            )
            try:
                write_lifecycle_event(
                    "WORKTREE_FAIL",
                    f"Crew {crew_num} voyage={voyage_id} branch={effective_branch}: {err_summary}"
                )
            except Exception:
                pass

    # MCP registry validation — refuse if role is not permitted to use required servers
    try:
        _validate_mcp_before_launch(item, order_data)
    except RuntimeError:
        return None

    # v2.0.6.1: Clear stale ralph-state.md before dispatch.
    # Prevents v8.4 early-completion detection from reading the previous crew's
    # COMPLETE state in the same monitoring tick as the new dispatch, which caused
    # new orders to be immediately archived before the crew could do any work.
    ralph_file = get_crew_dir(crew_num) / "ralph-state.md"
    try:
        ralph_file.unlink(missing_ok=True)
    except OSError as e:
        # If we fail to unlink, log and fall back to truncating/overwriting the file
        print_warn(f"Crew {crew_num}: Failed to remove stale ralph-state.md at {ralph_file}: {e}. Falling back to truncate.")
        try:
            # Truncate/overwrite so that stale COMPLETE state cannot be read
            with open(ralph_file, "w", encoding="utf-8") as f:
                f.write("")
        except OSError as e2:
            print_warn(f"Crew {crew_num}: Failed to truncate ralph-state.md at {ralph_file}: {e2}. Stale state may persist.")

    # Start the crew (returns PID, fully detached).
    # BUG-ADM-2026-0009 (Copilot review on PR #58): pass `effective_branch`
    # — the resolved value from order/voyage/env — so MAESTRO_SPRINT_BRANCH
    # injected into the crew env is correct, keeping branch_guard armed.
    # BUG-MSO-2026-0240: MAESTRO_SPRINT_BRANCH = per-crew branch so branch guard
    # allows git mutations on the crew branch (not the voyage branch).
    pid = start_crew_process(
        crew_number=crew_num,
        role=role,
        order_id=item["id"],
        prompt_file=prompt_file,
        max_iterations=max_iterations,
        timeout=timeout_minutes,
        voyage_branch=_crew_branch,
        repo_path="",
        project_acronym=project_acronym,
        worktree_path=worktree_path or "",
        max_turns=effective_max_turns,
    )

    if pid:
        ACTIVE_PROCESSES[crew_num] = pid
        ORDERS_IN_TRANSITION.discard(item["id"])  # BUG-MSO-2026-0017: clear transition gate on dispatch
        print_ok(f"Crew {crew_num} ({codename}) dispatched - PID {pid}")
        print_info(f"  > {item['type']}: {item['id']} - {item['title'][:50]}")
        write_lifecycle_event("DISPATCH", f"Crew {crew_num} ({codename}) dispatched as {item['role']} for {item['id']}")
    else:
        print_error(f"Failed to dispatch Crew {crew_num}")
        write_lifecycle_event("ERROR", f"Crew {crew_num} failed to start for {item['id']}")

    return pid


def print_dispatcher_status(start_time: datetime, max_crews: int,
                           all_work: List[Dict],
                           review_held: Optional[List[Dict]] = None) -> int:
    """Print dispatcher status board (v7.0). Returns count of active crews."""
    clear_screen()

    elapsed = datetime.now() - start_time
    elapsed_str = str(elapsed).split('.')[0]

    _p = current_persona()
    print()
    print(f"  {C.CYAN}{C.BOLD}+=========================================================================+")
    print(f"  |           {_p.term('product').upper()} DISPATCHER (Auto-Dispatch Mode){' ' * (33 - len(_p.term('product')))}|")
    print(f"  +=========================================================================+{C.RESET}")
    print()

    # v7.0: Escalation banner
    esc_count, blocking_voyages = scan_escalations()
    if esc_count > 0:
        print(f"  {C.RED}{C.BOLD}!!! ESCALATIONS: {esc_count} pending (requires {_p.term('userTitle')}/{_p.term('leadTitle')} review) !!!{C.RESET}")
        if blocking_voyages:
            print(f"  {C.RED}    Blocking {_p.term('sprint').lower()}s: {', '.join(blocking_voyages)}{C.RESET}")
        print()

    print(f"  {C.WHITE}Max Concurrent {_p.term('squad').title()}s:{C.RESET} {max_crews}")
    print(f"  {C.WHITE}Started:{C.RESET}  {start_time.strftime('%Y-%m-%d %H:%M:%S')}  {C.DIM}(Elapsed: {elapsed_str}){C.RESET}")
    print()

    # Count active crews
    active_count = 0
    _squad_col = _p.term("squad").upper()
    print(f"  {C.BOLD}{_squad_col:<18} {'PID':<8} {'STATUS':<12} {'ROLE':<6} {'MODEL':<8} {'ORDER':<22}{C.RESET}")
    print(f"  {C.DIM}{'-'*75}{C.RESET}")

    for crew_num in range(1, 6):
        codename = _get_crew_name(crew_num)
        pid = ACTIVE_PROCESSES.get(crew_num)
        if not pid:
            pid = read_crew_pid(crew_num)
        proc_alive = pid and is_process_alive(pid)
        pid_str = str(pid) if proc_alive else "-"

        state = read_crew_state(crew_num)

        if state:
            status = state.get("status", "UNKNOWN")
            role = state.get("role", "-")
            order_id = state.get("orderId", "-")[:20]

            if not proc_alive and status == "RUNNING":
                status = "CRASHED"
        else:
            status = "IDLE"
            role = "-"
            order_id = "-"

        # v8.7: Resolve model label from role
        model_label = _get_role_model_label(role) if status != "IDLE" else "-"

        # Determine display
        if status == "COMPLETE":
            icon = f"{C.GREEN}[DONE]{C.RESET}"
            status_color = C.GREEN
        elif status == "RUNNING":
            icon = f"{C.YELLOW}[>>>>]{C.RESET}"
            status_color = C.YELLOW
            active_count += 1
        elif status in ["BLOCKED", "ERROR", "CRASHED"]:
            icon = f"{C.RED}[FAIL]{C.RESET}"
            status_color = C.RED
        else:
            icon = f"{C.DIM}[IDLE]{C.RESET}"
            status_color = C.DIM

        crew_label = f"{crew_num}. {codename}"
        print(f"  {icon} {crew_label:<11} {C.CYAN}{pid_str:<8}{C.RESET} "
              f"{status_color}{status:<12}{C.RESET} {role:<6} {model_label:<8} {C.DIM}{order_id}{C.RESET}")

    print(f"  {C.DIM}{'-'*70}{C.RESET}")
    print()

    # v7.0: Unified queue status
    # BUG-MSO-2026-0226: surface review-held count so operators see NAV_REVIEW_PENDING orders
    # Caller passes review_held from the same tick's scan_review_queue(); None = standalone call
    if review_held is None:
        review_held = scan_review_queue()
    print(f"  {C.BOLD}QUEUE STATUS{C.RESET}")
    print(f"  {C.GREEN}Dispatchable:{C.RESET} {len(all_work)} items")
    for item in all_work[:5]:
        queue_tag = item.get("queue", "orders")
        print(f"    {C.DIM}> [{queue_tag}] {item['id']}: {item['title'][:40]} ({item['role']}){C.RESET}")
    if len(all_work) > 5:
        print(f"    {C.DIM}... and {len(all_work)-5} more{C.RESET}")

    # v7.0 + v8.2: Dependency-waiting and gate-blocked items
    if WAITING_ON_DEPS:
        # Separate gate blocks from dependency waits
        gate_items = {k: v for k, v in WAITING_ON_DEPS.items()
                      if any("ROLE GATE:" in d for d in v)}
        dep_items = {k: v for k, v in WAITING_ON_DEPS.items()
                     if not any("ROLE GATE:" in d for d in v)}

        if gate_items:
            print(f"  {C.RED}Role sequence gates:{C.RESET} {len(gate_items)} blocked")
            for item_id, deps in list(gate_items.items())[:3]:
                deps_str = ", ".join(deps[:2])
                print(f"    {C.RED}[GATE]{C.RESET} {item_id} -> {deps_str}")
            if len(gate_items) > 3:
                print(f"    {C.DIM}... and {len(gate_items)-3} more gated{C.RESET}")

        if dep_items:
            print(f"  {C.YELLOW}Waiting on deps:{C.RESET} {len(dep_items)} items")
            for item_id, deps in list(dep_items.items())[:3]:
                deps_str = ", ".join(deps[:3])
                if len(deps) > 3:
                    deps_str += f" +{len(deps)-3} more"
                print(f"    {C.DIM}[WAIT] {item_id} -> {deps_str}{C.RESET}")
            if len(dep_items) > 3:
                print(f"    {C.DIM}... and {len(dep_items)-3} more waiting{C.RESET}")

    # BUG-MSO-2026-0226: show review-held orders so they are never silently absent
    if review_held:
        _p2 = current_persona()
        print(f"  {C.MAGENTA}Awaiting review:{C.RESET} {len(review_held)} order(s) — run `mso review` to approve/revise/reject")
        for item in review_held[:3]:
            print(f"    {C.MAGENTA}[REVIEW]{C.RESET} {item['id']}: {item['title'][:40]} (next: {item['role']})")
        if len(review_held) > 3:
            print(f"    {C.DIM}... and {len(review_held)-3} more awaiting review{C.RESET}")

    print()
    review_suffix = f" | {C.MAGENTA}Awaiting review:{C.RESET} {len(review_held)}" if review_held else ""
    print(f"  {C.WHITE}Active:{C.RESET} {C.YELLOW}{active_count}{C.RESET} | "
          f"{C.WHITE}Available:{C.RESET} {C.GREEN}{max_crews - active_count}{C.RESET} | "
          f"{C.WHITE}Dispatchable:{C.RESET} {len(all_work)} | "
          f"{C.WHITE}Waiting:{C.RESET} {len(WAITING_ON_DEPS)}{review_suffix}")
    if _QUEUE_READ_ERRORS:
        print(f"  {C.RED}[!!] {len(_QUEUE_READ_ERRORS)} unreadable order file(s) in queue — check lifecycle.log for details{C.RESET}")
    print()
    print(f"  {C.DIM}Press Ctrl+C to stop dispatcher.{C.RESET}")
    print()

    return active_count


def _tick_nav_review_auto_approve() -> None:
    """Promote orders in queues/review/ that have exceeded auto_approve_after_hours."""
    admiralty_dir = get_workspace_dir()
    review_dir = admiralty_dir / "queues" / "review"
    if not review_dir.exists():
        return
    try:
        gate_cfg = load_gate_config(admiralty_dir)
    except Exception:
        return
    orders_dir = admiralty_dir / "queues" / "orders"
    orders_dir.mkdir(parents=True, exist_ok=True)
    for json_file in list(review_dir.glob("*.json")):
        try:
            data = json.loads(json_file.read_text(encoding="utf-8"))
            paused_at = data.get("navReviewPausedAt", "")
            if not should_auto_approve(data, gate_cfg, paused_at):
                continue
            order_id = data.get("orderId") or data.get("id") or json_file.stem
            data.pop("navReviewPausedAt", None)
            # BUG-MSO-2026-0205: a standalone plan-approval order has no next role —
            # auto-approve archives it COMPLETE (releasing dependents), not re-queue.
            if data.get("planApprovalOnly"):
                data["status"] = "COMPLETE"
                data["completedAt"] = datetime.now().isoformat()
                data.pop("planApprovalOnly", None)
                archive_dir = admiralty_dir / "orders" / "complete"
                archive_dir.mkdir(parents=True, exist_ok=True)
                (archive_dir / json_file.name).write_text(json.dumps(data, indent=2), encoding="utf-8")
                json_file.unlink()
                _mark_order_terminal_now()
                print_ok(f"Order {order_id} plan auto-approved after timeout -> COMPLETE (dependents released)")
                write_lifecycle_event("NAV_REVIEW_AUTO_APPROVED", f"{order_id} plan auto-approved after timeout -> COMPLETE")
                continue
            data["status"] = "PENDING"
            dest = orders_dir / json_file.name
            dest.write_text(json.dumps(data, indent=2), encoding="utf-8")
            json_file.unlink()
            print_ok(f"Order {order_id} auto-approved after timeout -> advancing to {data.get('targetRole', '?')}")
            write_lifecycle_event("NAV_REVIEW_AUTO_APPROVED", f"{order_id} auto-approved after timeout -> {data.get('targetRole', '?')}")
        except Exception as e:
            print_warn(f"Auto-approve tick error for {json_file}: {e}")


def run_dispatcher(max_crews: int = 2, stagger_delay: int = 120,
                   max_iterations: int = 25, timeout_minutes: int = 120,
                   max_turns: int = 200):
    """Run the auto-dispatcher loop.

    Voyage branch comes from the MAESTRO_SPRINT_BRANCH environment variable
    set before launching fleet-runner (typically via Launch-FleetCommand.bat).
    """
    global SHUTDOWN_REQUESTED

    # Dispatcher PID lock - prevent duplicate dispatchers
    dispatcher_lock = get_workspace_dir() / "dispatcher.pid"
    if dispatcher_lock.exists():
        try:
            old_pid = int(dispatcher_lock.read_text(encoding='utf-8').strip())
            if is_process_alive(old_pid):
                print_error(f"Another dispatcher is already running (PID {old_pid})")
                print_info("Kill it first: taskkill /F /PID " + str(old_pid))
                return
        except:
            pass
    dispatcher_lock.write_text(str(os.getpid()), encoding='utf-8')

    # v8.2: Load role sequences from templates for gate enforcement
    load_role_sequences()

    print_header("AUTO-DISPATCHER v8.7 — ROLE SEQUENCE GATES")
    print_info(f"Max concurrent crews: {max_crews}")
    print_info(f"Stagger delay: {stagger_delay}s")
    print_info(f"Dispatcher PID: {os.getpid()}")
    print_info("Priority: Explicit > Security > Bugs > Requests > Orders > Defects > Breakdown > High-Level")
    print_info("Dependency checking: ENABLED")
    print_info("Escalation blocking: ENABLED")
    print_info(f"Role sequence gates: ENABLED ({len(ROLE_SEQUENCES)} sequences loaded)")
    print_info("Watching all queues...")
    print()
    write_lifecycle_event("DISPATCH", f"Dispatcher started (PID {os.getpid()}, max-crews={max_crews})")

    # BUG-MSO-2026-0018: Reconstruct in-flight claim table from crew state before first tick.
    # Prevents re-dispatching orders that already have a live crew after a dispatcher restart.
    reclaimed = _reclaim_inflight_from_crew_state()
    if reclaimed:
        print_info(f"Reclaimed {reclaimed} in-flight crew(s) from prior run — skipping their orders")
        write_lifecycle_event("DISPATCH", f"Reclaimed {reclaimed} in-flight crew(s) on startup")

    # BUG-MSO-2026-0294: runtime order ledger — seed on upgrade, compact when large.
    try:
        if order_ledger.seed_if_missing(get_workspace_dir()):
            print_info("Order ledger seeded from existing archives + live crew state (BUG-0294)")
            write_lifecycle_event("DISPATCH", "Order ledger seeded on startup (BUG-0294)")
        order_ledger.compact(get_workspace_dir())
    except Exception as ledger_exc:
        print_warn(f"Order ledger startup maintenance failed: {ledger_exc}")

    # FTR-0149: prune stale worktrees from prior runs before accepting new work
    try:
        from maestro.core.worktrees import prune_stale_worktrees
        pruned = prune_stale_worktrees()
        if pruned:
            print_info(f"Pruned {pruned} stale worktree(s) from prior runs")
            write_lifecycle_event("DISPATCH", f"Pruned {pruned} stale worktree(s) at startup")
    except Exception as prune_exc:
        print_warn(f"Worktree prune at startup failed: {prune_exc}")

    # Run startup reconcile of merged voyages (FTR-MSO-2026-0203)
    try:
        completion_cfg = load_completion_config()
        if completion_cfg["onVoyageComplete"]["archiveVoyageOnMerge"]:
            reconciled = reconcile_merged_voyages(completion_cfg["onVoyageComplete"])
            if reconciled:
                write_lifecycle_event("DISPATCH", f"Startup reconcile: archived {reconciled} merged voyage(s)")
    except Exception as _rec_exc:
        write_lifecycle_event("WARN", f"Startup voyage reconcile failed: {_rec_exc}")

    # Setup signal handlers
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    def cleanup_dispatcher():
        cleanup_fleet("dispatcher exit")
        try: dispatcher_lock.unlink()
        except: pass

    atexit.register(cleanup_dispatcher)

    start_time = datetime.now()
    last_dispatch_time = datetime.min
    voyage_bell_rung = False  # Only ring voyage bell once when all work completes
    # BUG-MSO-2026-0243: heartbeat so a wedged/livelocked loop is visible in
    # lifecycle.log instead of going silent. Emitted at most every HEARTBEAT_SECONDS.
    # Defensive parse (mirrors MAESTRO_EIGHT_BELLS_GRACE_SECONDS) + clamp to >=1s so a
    # misconfigured env var can neither crash startup nor spin a tight-loop heartbeat.
    last_heartbeat = datetime.min
    try:
        HEARTBEAT_SECONDS = int(os.environ.get("MAESTRO_HEARTBEAT_SECONDS", "120"))
    except (TypeError, ValueError):
        HEARTBEAT_SECONDS = 120
    if HEARTBEAT_SECONDS < 1:
        HEARTBEAT_SECONDS = 1

    # FTR-MSO-2026-0203: idle-watchdog
    _watchdog_cfg = load_completion_config()["idleWatchdog"]
    _idle_since: Optional[datetime] = None  # wall-clock when all-idle started

    try:
        while not SHUTDOWN_REQUESTED:
            # BUG-MSO-2026-0262: clear the intra-tick transition gate at the START of each
            # loop iteration. ORDERS_IN_TRANSITION is populated in process_crew_completion()
            # when an order advances to its next role (e.g. BLD->TST); its only job is to stop
            # scan from double-selecting an order mid-handoff within the tick that advanced it.
            # It was previously cleared ONLY on dispatch (dispatch_squad, BUG-0017), so an order
            # advanced while all crew slots were busy stayed gated forever and its next role
            # never dispatched (heartbeat pending=0 with idle crews). Clearing at tick start lets
            # the next scan see it; the PENDING-only filter + the complete_order idempotency
            # guard (BUG-0248) still prevent any double-dispatch.
            ORDERS_IN_TRANSITION.clear()
            # v7.0: Unified queue scan (all 8 queue types, dependency-aware, escalation-aware)
            all_work = scan_all_queues()
            # BUG-MSO-2026-0226: scan review queue once per tick; used for Eight Bells guard
            # and dispatcher status display so both are consistent within one iteration.
            review_held = scan_review_queue()

            # Check if unified monitor is handling display
            monitor_pid_file = get_workspace_dir() / "monitor.pid"
            monitor_running = False
            if monitor_pid_file.exists():
                try:
                    mpid = int(monitor_pid_file.read_text(encoding='utf-8').strip())
                    monitor_running = is_process_alive(mpid)
                except:
                    pass

            if not monitor_running:
                # No monitor - show status in this console
                active_count = print_dispatcher_status(start_time, max_crews, all_work, review_held)
            else:
                # Monitor is handling display - just count active crews silently
                active_count = 0
                for cn in range(1, 6):
                    pid = ACTIVE_PROCESSES.get(cn) or read_crew_pid(cn)
                    if pid and is_process_alive(pid):
                        active_count += 1

            # Check if we can dispatch more crews
            available_slots = max_crews - active_count

            if available_slots > 0:
                # Check stagger delay
                time_since_last = (datetime.now() - last_dispatch_time).total_seconds()
                if time_since_last < stagger_delay and last_dispatch_time != datetime.min:
                    remaining = int(stagger_delay - time_since_last)
                    print_info(f"Stagger delay: {remaining}s until next dispatch...")
                else:
                    # Get available crew numbers
                    available_crews = get_available_crews(max_crews)

                    if available_crews:
                        # v7.0: Unified priority — all_work is pre-sorted by tier + priority
                        work_item = all_work[0] if all_work else None

                        if work_item:
                            queue_tag = work_item.get("queue", "orders")
                            print_info(f"Picking [{queue_tag}]: {work_item['id']} (priority {work_item.get('priority', '?')})")

                            crew_num = available_crews[0]
                            # v2.0.1: Per-order voyage branch — read from order's voyageId,
                            # fall back to ACTIVE_VOYAGE_BRANCH for backwards compatibility
                            # v2.0.3: Also check inline voyageBranch (set by defect normalization)
                            order_voyage_branch = (
                                work_item.get("data", {}).get("voyageBranch", "")
                                or _get_voyage_branch_for_order(work_item["id"])
                            )
                            effective_voyage_branch = order_voyage_branch or ACTIVE_VOYAGE_BRANCH
                            # BUG-MSO-2026-0285: per-order/per-role timeout override.
                            # The global --timeout is a ceiling; a heavy order (docker,
                            # integration tests, multi-file refactor) can set
                            # timeoutMinutes to avoid being killed mid-work.
                            effective_timeout = resolve_order_timeout(
                                work_item.get("data", {}), timeout_minutes)
                            if effective_timeout != timeout_minutes:
                                write_lifecycle_event(
                                    "DISPATCH",
                                    f"{work_item['id']}: per-order iteration timeout "
                                    f"{effective_timeout}m (override of global {timeout_minutes}m, BUG-0285)"
                                )
                            pid = dispatch_squad(crew_num, work_item,
                                                max_iterations, effective_timeout,
                                                voyage_branch=effective_voyage_branch,
                                                max_turns=max_turns)
                            if pid:
                                last_dispatch_time = datetime.now()
                                save_fleet_state()

            # v8.4: Early completion detection via ralph-state.md
            # Fixes: crew.py subprocess.run() hangs on open pipes (background bash)
            # even after Claude exits. ralph-state shows COMPLETE but state.json
            # still shows RUNNING because crew.py hasn't returned yet.
            for crew_num in list(ACTIVE_PROCESSES.keys()):
                pid = ACTIVE_PROCESSES[crew_num]
                if pid and is_process_alive(pid):
                    ralph_file = get_crew_dir(crew_num) / "ralph-state.md"
                    if ralph_file.exists():
                        try:
                            content = ralph_file.read_text(encoding='utf-8')
                            match = re.search(r'^status:\s*["\']?(\w+)', content, re.MULTILINE)
                            if match:
                                ralph_status = match.group(1)
                                if ralph_status in TERMINAL_STATES:
                                    print_info(f"Crew {crew_num} ralph-state={ralph_status} but process alive (pipe hang) — draining")
                                    write_lifecycle_event("DRAIN_START", f"Crew {crew_num} ralph-state={ralph_status}, pipe-hang detected — entering drain window")
                                    # Update state.json so process_crew_completion reads correct status
                                    state = read_crew_state(crew_num)
                                    if state:
                                        state["status"] = ralph_status
                                        state_file = get_crew_dir(crew_num) / "state.json"
                                        state_file.write_text(json.dumps(state, indent=2), encoding='utf-8')
                                    # Move to draining — process_crew_completion called after drain window
                                    crew_state = read_crew_state(crew_num)
                                    voyage_id = crew_state.get("voyageId", "") if crew_state else ""
                                    DRAINING_PROCESSES[crew_num] = {"pid": pid, "voyage_id": voyage_id, "drained_at": datetime.now()}
                                    del ACTIVE_PROCESSES[crew_num]
                                    # Kill the hung process (stuck on pipes)
                                    try:
                                        os.kill(pid, signal.SIGTERM)
                                    except OSError:
                                        pass
                                    continue
                        except Exception as e:
                            print_warn(f"Crew {crew_num} ralph-state read error: {e}")

            # v7.1: Clean up completed crews - full order lifecycle management
            for crew_num in list(ACTIVE_PROCESSES.keys()):
                pid = ACTIVE_PROCESSES[crew_num]
                if not pid or not is_process_alive(pid):
                    state = read_crew_state(crew_num)
                    status = state.get("status", "") if state else ""
                    if status in TERMINAL_STATES:
                        process_crew_completion(crew_num)
                        del ACTIVE_PROCESSES[crew_num]
                        # Reset to IDLE immediately so the orphaned-state scan below
                        # doesn't re-process this crew in the same dispatcher tick (BUG-MSO-2026-0015)
                        _idle = {"crewNumber": crew_num, "status": "IDLE", "role": "-", "orderId": "-"}
                        (get_crew_dir(crew_num) / "state.json").write_text(json.dumps(_idle, indent=2), encoding='utf-8')
                    elif status and status != "RUNNING":
                        # v7.1 FIX: Dead crew with unrecognized non-RUNNING state
                        # Treat as CRASHED to prevent orphaning orders
                        print_warn(f"Crew {crew_num} dead with unrecognized state '{status}' - treating as CRASHED")
                        write_lifecycle_event("WARN", f"Crew {crew_num} dead with unrecognized state '{status}' - treating as CRASHED")
                        if state:
                            state["status"] = "CRASHED"
                            state_file = get_crew_dir(crew_num) / "state.json"
                        state_file.write_text(json.dumps(state, indent=2), encoding='utf-8')
                        process_crew_completion(crew_num)
                        del ACTIVE_PROCESSES[crew_num]
                        # Reset to IDLE immediately (BUG-MSO-2026-0015)
                        _idle = {"crewNumber": crew_num, "status": "IDLE", "role": "-", "orderId": "-"}
                        (get_crew_dir(crew_num) / "state.json").write_text(json.dumps(_idle, indent=2), encoding='utf-8')

            # v7.1: Clean up orphaned crew states not tracked in ACTIVE_PROCESSES
            # (e.g. from previous dispatcher runs that left stale TIMEOUT/CRASHED states)
            for crew_num in range(1, max_crews + 1):
                if crew_num in ACTIVE_PROCESSES:
                    continue  # Already tracked
                if crew_num in DRAINING_PROCESSES:
                    continue  # In drain window — completion handled by drain-check below
                state = read_crew_state(crew_num)
                if not state:
                    continue
                status = state.get("status", "")
                if status in TERMINAL_STATES or (status and status not in ("RUNNING", "IDLE", "")):
                    pid = state.get("pid")
                    if not pid or not is_process_alive(pid):
                        # Dead crew with terminal/unexpected state - process and reset
                        if status not in TERMINAL_STATES:
                            print_warn(f"Orphaned Crew {crew_num} with unrecognized state '{status}' - treating as CRASHED")
                            write_lifecycle_event("WARN", f"Orphaned Crew {crew_num} state '{status}' - treating as CRASHED")
                            state["status"] = "CRASHED"
                            sf = get_crew_dir(crew_num) / "state.json"
                            sf.write_text(json.dumps(state, indent=2), encoding='utf-8')
                        process_crew_completion(crew_num)
                        # Reset state to IDLE so monitor shows clean
                        state_file = get_crew_dir(crew_num) / "state.json"
                        idle_state = {"crewNumber": crew_num, "status": "IDLE", "role": "-", "orderId": "-"}
                        state_file.write_text(json.dumps(idle_state, indent=2), encoding='utf-8')

            # Drain-check: complete crews that have exited AND waited out the drain window
            drain_window = int(os.environ.get("MAESTRO_SQUAD_DRAIN_SECONDS", "5"))
            _drain_now = datetime.now()
            for crew_num in list(DRAINING_PROCESSES.keys()):
                entry = DRAINING_PROCESSES[crew_num]
                elapsed = (_drain_now - entry["drained_at"]).total_seconds()
                if not is_process_alive(entry["pid"]) and elapsed >= drain_window:
                    write_lifecycle_event("DRAIN_COMPLETE", f"Crew {crew_num} drained after {drain_window}s")
                    process_crew_completion(crew_num)
                    del DRAINING_PROCESSES[crew_num]
                    # Reset to IDLE so orphan scan next tick doesn't re-process (BUG-MSO-2026-0015)
                    _idle = {"crewNumber": crew_num, "status": "IDLE", "role": "-", "orderId": "-"}
                    (get_crew_dir(crew_num) / "state.json").write_text(json.dumps(_idle, indent=2), encoding='utf-8')

            # Post-NAV auto-approve: promote orders that have waited long enough in review
            _tick_nav_review_auto_approve()

            # v8.7: Periodic orphan reset — detect IN_PROGRESS orders with no live crew
            # (Fixes: orders stuck as IN_PROGRESS when crew dies between dispatch and launch)
            reset = reset_orphaned_in_progress_orders()
            if reset > 0:
                write_lifecycle_event("DISPATCH", f"Reset {reset} orphaned IN_PROGRESS order(s) -> PENDING (v8.7 periodic check)")

            # BUG-MSO-2026-0280: Reconciliation pass — self-heal stranded dependents
            # whose auto-queue event did not fire (BLOCKED/STALLED archival, crash, etc.)
            reconcile_stranded_dependents()

            # Check if all work is done (no active crews, no pending items in any queue)
            # BUG-MSO-2026-0024: also require the post-completion grace window to have
            # elapsed, so a freshly-unblocked dependent can be dispatched before we
            # declare the voyage done (closes the COMPLETE->DISPATCH false-fire race).
            # BUG-MSO-2026-0226: also require no orders held in queues/review/
            # (NAV_REVIEW_PENDING) — review-held orders are non-terminal and must
            # block Eight Bells just as PENDING orders do.
            if (not ACTIVE_PROCESSES and not DRAINING_PROCESSES and not ORDERS_IN_TRANSITION
                    and not all_work and not review_held
                    and not voyage_bell_rung and _eight_bells_grace_elapsed()):
                ring_bell()
                write_lifecycle_event("COMPLETE", "All queued work complete - Eight Bells!")
                if WAITING_ON_DEPS:
                    print_info(f"All dispatchable work complete. {len(WAITING_ON_DEPS)} item(s) waiting on dependencies.")
                else:
                    print_info("All work dispatched and completed. Dispatcher idle - watching for new orders...")

                # v2.0.5: Sweep decks — clean stale orders and complete finished voyages
                sweep_decks()

                # v8.6: Post-voyage — refresh requirements matrix from current data
                run_post_voyage_matrix_update()

                # v8.13: Post-voyage — auto-create PRs for repos with completed work
                # v2.0.0: Now a safety net — per-crew PR creation handles most cases
                run_post_voyage_pr_creation()

                # v2.0.0: Reset developer repos back to main
                reset_developer_repos()

                voyage_bell_rung = True
            elif all_work or review_held:
                # New work arrived (or review-held orders remain) — reset bell so it
                # rings again when next batch completes (BUG-MSO-2026-0226).
                voyage_bell_rung = False

            # FTR-MSO-2026-0203: idle-watchdog — track all-crews-idle elapsed time
            _any_active = bool(ACTIVE_PROCESSES) or bool(DRAINING_PROCESSES)
            if _any_active or all_work or review_held:
                _idle_since = None  # reset: there is work or running crews
            else:
                if _idle_since is None:
                    _idle_since = datetime.now()
                elif _watchdog_cfg["enabled"]:
                    _idle_elapsed = (datetime.now() - _idle_since).total_seconds() / 60.0
                    _idle_threshold = _watchdog_cfg["idleMinutes"]
                    if _idle_elapsed >= _idle_threshold:
                        _action = _watchdog_cfg["action"]
                        if _action == "warn":
                            write_lifecycle_event("IDLE_TIMEOUT",
                                f"Dispatcher idle {_idle_elapsed:.1f}m >= {_idle_threshold}m — action=warn")
                            print_warn(f"Idle-watchdog: dispatcher idle {_idle_elapsed:.1f}m (threshold {_idle_threshold}m)")
                            _idle_since = datetime.now()  # reset to avoid repeated warn spam
                        elif _action == "cleanup":
                            write_lifecycle_event("IDLE_REAP",
                                f"Dispatcher idle {_idle_elapsed:.1f}m >= {_idle_threshold}m — reaping (cleanup + exit)")
                            print_info(f"Idle-watchdog: idle {_idle_elapsed:.1f}m >= {_idle_threshold}m — running cleanup and exiting")
                            preflight_kill_rogue_processes()
                            preflight_clear_stale_states()
                            SHUTDOWN_REQUESTED = True
                        # action=="none" or anything else: do nothing

            # BUG-MSO-2026-0243: periodic heartbeat. If the loop ever wedges after a
            # convergence failure (or any blocking call), the ABSENCE of this line in
            # lifecycle.log pinpoints when forward progress stopped — instead of the
            # loop going silently dark with idle crews and pending work.
            _hb_elapsed = (datetime.now() - last_heartbeat).total_seconds()
            if _hb_elapsed >= HEARTBEAT_SECONDS:
                _pending = len(all_work) if all_work else 0
                _busy = len(ACTIVE_PROCESSES) + len(DRAINING_PROCESSES)
                _free = max_crews - _busy
                write_lifecycle_event(
                    "HEARTBEAT",
                    f"dispatcher alive — pending={_pending} held={len(review_held)} "
                    f"crews_busy={_busy} crews_free={_free}"
                )
                last_heartbeat = datetime.now()

                # BUG-MSO-2026-0289: per-voyage finalisation + PR promote, decoupled
                # from the Eight Bells (whole-workspace-idle) gate. A voyage whose
                # own orders are all COMPLETE is finalised and its draft PR promoted
                # here on the heartbeat cadence, even while other voyages / review-
                # held orders keep the fleet busy. Quiet + idempotent.
                try:
                    sweep_decks(quiet=True)
                except Exception as _swx:
                    write_lifecycle_event("WARN", f"heartbeat sweep_decks failed: {_swx}")

            # Sleep before next check
            for _ in range(10):  # 10 second check interval
                if SHUTDOWN_REQUESTED:
                    break
                time.sleep(1)

    except KeyboardInterrupt:
        pass

    cleanup_fleet("dispatcher stopped")
    write_lifecycle_event("DISPATCH", "Dispatcher stopped")
    print(f"\n  {C.GREEN}Dispatcher stopped.{C.RESET}\n")


# =============================================================================
# MAIN FLEET RUNNER
# =============================================================================

# Legacy manifest-mode run_fleet() removed in v2.0.4 — use --dispatch instead


def _find_window_by_title(title: str) -> bool:
    """Check if a window with the given title exists (Windows only)."""
    if os.name != 'nt':
        return False
    try:
        import ctypes
        hwnd = ctypes.windll.user32.FindWindowW(None, title)
        return hwnd != 0
    except Exception:
        return False


def auto_launch_monitor():
    """Launch the unified Maestro Monitor in a visible window.

    Checks monitor.pid AND window title to avoid launching duplicates.
    The monitor handles all status display, so the dispatcher can run silently.
    """
    from maestro import __version__ as _maestro_version
    monitor_title = f"Maestro Monitor v{_maestro_version}"

    # Check 1: PID file — is the monitor process alive?
    monitor_pid_file = get_workspace_dir() / "monitor.pid"
    if monitor_pid_file.exists():
        try:
            mpid = int(monitor_pid_file.read_text(encoding='utf-8').strip())
            if is_process_alive(mpid):
                print_ok("Maestro Monitor already running")
                return
        except:
            pass

    # Check 2: Window title — is there already a visible monitor window?
    if _find_window_by_title(monitor_title):
        print_ok("Maestro Monitor window already exists")
        return

    monitor_py = Path(__file__).resolve().parent / "fleet_monitor.py"
    if not monitor_py.exists():
        monitor_py = get_workspace_dir() / "core" / "fleet_monitor.py"
    if not monitor_py.exists():
        print_warn("fleet_monitor.py not found - skipping monitor launch")
        return

    try:
        print(f"\n  {C.CYAN}Launching {monitor_title}...{C.RESET}")
        if os.name == 'nt':
            # Quote paths to handle spaces (e.g. C:\Program Files\Python313\python.exe)
            py_exe = f'"{sys.executable}"'
            mon_script = f'"{monitor_py}"'
            base = f'"{get_base_dir()}"'
            cmd = f'start "{monitor_title}" cmd /c "cd /d {base} && {py_exe} {mon_script}"'
            _spawn(cmd, identity="fleet_runner", workspace=get_base_dir(), shell=True)
        else:
            _spawn(
                [sys.executable, str(monitor_py)],
                identity="fleet_runner",
                workspace=get_base_dir(),
                start_new_session=True,
            )
        time.sleep(1)
        print_ok("Maestro Monitor launched")
        write_lifecycle_event("MONITOR", f"{monitor_title} launched")
    except Exception as e:
        print_warn(f"Could not launch monitor: {e}")


def build_parser() -> argparse.ArgumentParser:
    """Build the fleet_runner CLI argument parser (extracted from main() for testability — Copilot PR #87)."""
    parser = argparse.ArgumentParser(
        description="Maestro v2.0.5 - Queue-Based Dispatch with Dependency Precedence",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s --dispatch --max-crews 5
  %(prog)s --cleanup
  %(prog)s --archive-completed
        """
    )
    parser.add_argument("--maestro-dir", type=str, default=None,
                       help="Path to .mso directory (auto-detected from cwd if omitted)")
    parser.add_argument("--cleanup", action="store_true",
                       help="Clean up rogue processes and stale states, then exit")
    # v5.2 Auto-Dispatcher arguments
    parser.add_argument("--dispatch", action="store_true",
                       help="Run in auto-dispatch mode - watches queues and dispatches crews automatically")
    parser.add_argument("--max-crews", type=int, default=5,
                       help="Maximum concurrent crews for dispatch mode (default: 5)")
    parser.add_argument("--stagger-delay", type=int, default=30,
                       help="Seconds between crew dispatches (default: 30)")
    parser.add_argument("--max-iterations", type=int, default=25,
                       help="Max iterations per dispatched crew (default: 25)")
    parser.add_argument("--timeout", type=int, default=25,
                       help="Per-iteration timeout in minutes (default: 25)")
    parser.add_argument("--max-turns", type=int, default=25,
                       help="Max Claude turns per crew iteration (default: 25)")
    parser.add_argument("--convergence-timeout", type=int, default=None, metavar="SECS",
                       help="Per-op timeout for convergence git network ops in seconds "
                            "(default: 60; also configurable via workspace.json "
                            "completion.convergenceNetworkTimeout)")
    # v6.0 Lifecycle management
    parser.add_argument("--archive-completed", action="store_true",
                       help="Archive completed/stalled orders from queues to orders/complete/")
    # v2.0.5 Deck sweep + auto-queue
    parser.add_argument("--sweep-decks", action="store_true",
                       help="Sweep decks: remove stale active orders, complete finished voyages")
    parser.add_argument("--auto-queue", action="store_true",
                       help="Auto-queue orders from orders/active/ whose dependencies are satisfied")
    # v8.2 Role sequence validation
    parser.add_argument("--validate-sequences", action="store_true",
                       help="Validate role sequence gates for all active orders (dry-run)")
    # v8.3 Requirements traceability validation
    parser.add_argument("--validate-traceability", action="store_true",
                       help="Run Requirements Scanner gate check (min 80%% coverage)")

    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()

    global _MAESTRO_DIR_OVERRIDE, _CONVERGENCE_TIMEOUT_CLI_OVERRIDE
    if args.maestro_dir:
        _MAESTRO_DIR_OVERRIDE = Path(args.maestro_dir).resolve()
    if getattr(args, "convergence_timeout", None) is not None:
        _CONVERGENCE_TIMEOUT_CLI_OVERRIDE = args.convergence_timeout

    print()
    try:
        from maestro import __version__ as _adm_version
    except ImportError:
        _adm_version = "unknown"
    print(f"  {C.CYAN}{C.BOLD}Maestro v{_adm_version}{C.RESET}")
    print(f"  {C.DIM}Queue-Based Dispatch + Dependency Precedence + Role Gates | {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}{C.RESET}")

    if args.cleanup:
        print_header("CLEANUP MODE")
        killed = preflight_kill_rogue_processes()
        print_ok(f"Killed {killed} rogue process(es)")
        # BUG-MSO-2026-0302: marker-based orphan sweep — catches crew-descended
        # processes no PID file references (GKT: PID 28048 survived every cleanup)
        reaped, survivors = sweep_marked_orphans()
        if reaped:
            print_ok(f"Orphan sweep reaped {len(reaped)} marked process(es): {reaped}")
        if survivors:
            print_warn(f"Orphan sweep: {len(survivors)} process(es) SURVIVED — kill manually: {survivors}")
        # BUG-MSO-2026-0298: salvage-first — preserve any dirty worktree work
        # BEFORE clearing state, so cleanup never destroys in-flight progress.
        try:
            from maestro.core.worktrees import _salvage_worktree_if_dirty
            _salvaged = 0
            _voyages_active = get_workspace_dir() / "voyages" / "active"
            if _voyages_active.exists():
                for _vdir in _voyages_active.iterdir():
                    if not _vdir.is_dir():
                        continue
                    for _wt in _vdir.iterdir():
                        if _wt.is_dir() and _wt.name.startswith(".worktree"):
                            if _salvage_worktree_if_dirty(_wt, _vdir.name, _wt.name) == "salvaged":
                                _salvaged += 1
            if _salvaged:
                print_ok(f"Salvaged {_salvaged} dirty worktree(s) to salvage/ branches")
        except Exception as _salv_exc:
            print_warn(f"Cleanup salvage pass failed: {_salv_exc}")
        cleared = preflight_clear_stale_states()
        print_ok(f"Cleared {cleared} stale state file(s)")
        reset = reset_orphaned_in_progress_orders()
        if reset > 0:
            print_ok(f"Reset {reset} orphaned IN_PROGRESS order(s) -> PENDING")
        else:
            print_ok("No orphaned orders found")
        # v2.0.1: Clean ephemeral crew repo clones (robust Windows removal)
        crew_repos_cleaned = 0
        crew_repos_failed = 0
        for cn in range(1, 6):
            repo_dir = get_crew_dir(cn) / "repo"
            if repo_dir.exists():
                if _robust_rmtree(repo_dir, label=f"Crew {cn}"):
                    crew_repos_cleaned += 1
                else:
                    crew_repos_failed += 1
                    print_warn(f"Crew {cn}: Could not remove {repo_dir} — manual cleanup needed")
        if crew_repos_cleaned > 0:
            print_ok(f"Cleaned {crew_repos_cleaned} ephemeral crew repo clone(s)")
        if crew_repos_failed > 0:
            print_warn(f"{crew_repos_failed} crew repo(s) could not be removed")
        elif crew_repos_cleaned == 0:
            print_ok("No crew repo clones to clean")
        # v8.14: Clean temp working directory
        temp_dir = get_workspace_dir() / "temp"
        if temp_dir.exists():
            temp_cleared = 0
            for sub in ("nuget-local", "build-artifacts", "scratch"):
                sub_dir = temp_dir / sub
                if sub_dir.exists():
                    for item in sub_dir.iterdir():
                        if item.name == ".gitkeep":
                            continue
                        if item.is_dir():
                            import shutil
                            shutil.rmtree(item, ignore_errors=True)
                        else:
                            item.unlink(missing_ok=True)
                        temp_cleared += 1
            if temp_cleared > 0:
                print_ok(f"Cleared {temp_cleared} temp artifact(s) from .mso/temp/")
            else:
                print_ok("Temp directory already clean")
        print(f"\n  {C.GREEN}Cleanup complete.{C.RESET}\n")
        return 0

    # v6.0: Archive completed orders
    if args.archive_completed:
        print_header("ARCHIVE COMPLETED ORDERS")
        archived = archive_all_completed_orders()
        if archived == 0:
            print_info("No completed orders found in queues")
        else:
            print_ok(f"Archived {archived} completed order(s) to orders/complete/")
        print(f"\n  {C.GREEN}Archive complete.{C.RESET}\n")
        return 0

    # v2.0.5: Sweep decks
    if args.sweep_decks:
        print_header("SWEEP DECKS (v2.0.5)")
        result = sweep_decks()
        total = result["stale_orders_removed"] + result["voyages_completed"]
        if total == 0:
            print_info("Decks are clean - nothing to sweep")
        print(f"\n  {C.GREEN}Sweep complete.{C.RESET}\n")
        return 0

    # v2.0.5: Auto-queue unblocked orders
    if args.auto_queue:
        print_header("AUTO-QUEUE UNBLOCKED ORDERS (v2.0.5)")
        auto_queue_unblocked_orders("MANUAL")
        print(f"\n  {C.GREEN}Auto-queue complete.{C.RESET}\n")
        return 0

    # v8.2: Validate role sequences (dry-run)
    if args.validate_sequences:
        print_header("ROLE SEQUENCE VALIDATION (v8.2)")
        load_role_sequences()
        if not ROLE_SEQUENCES:
            print_error("No role sequences loaded from templates")
            return 1
        print_ok(f"Loaded {len(ROLE_SEQUENCES)} role sequence(s): {', '.join(ROLE_SEQUENCES.keys())}")
        for otype, seq in sorted(ROLE_SEQUENCES.items()):
            print_info(f"  {otype}: {' -> '.join(seq)}")
        print()

        voyage_status = build_voyage_role_status()
        if not voyage_status:
            print_info("No voyages found with active orders")
            return 0

        # Scan all active orders and check gates (queues + orders/active)
        gate_failures = 0
        gate_passes = 0
        scan_dirs = []

        # Queue directories
        queues_dir = get_queues_dir()
        for qname in ["explicit", "security", "bugs", "orders", "defects",
                       "breakdown", "high-level"]:
            qpath = queues_dir / qname
            if qpath.exists():
                scan_dirs.append(qpath)

        # orders/active directory
        active_dir = get_workspace_dir() / "orders" / "active"
        if active_dir.exists():
            scan_dirs.append(active_dir)

        for scan_path in scan_dirs:
            for json_file in scan_path.glob("*.json"):
                try:
                    data = json.loads(json_file.read_text(encoding='utf-8'))
                    vid = data.get("voyageId", "")
                    order_id = data.get("id", json_file.stem)
                    target_role, _ = resolve_order_fields(data)
                    if not vid or vid not in voyage_status:
                        continue
                    passed, missing = check_role_sequence_gate(data, voyage_status[vid])
                    if not passed:
                        gate_failures += 1
                        missing_str = ", ".join(missing)
                        print_warn(f"  GATE BLOCK: {order_id} ({target_role}) in {vid}")
                        print_warn(f"    Prior roles not complete: {missing_str}")
                    else:
                        gate_passes += 1
                except Exception:
                    pass

        print()
        if gate_failures == 0:
            print_ok(f"All role sequence gates PASS ({gate_passes} orders checked across {len(voyage_status)} voyages)")
        else:
            print_error(f"{gate_failures} order(s) BLOCKED by role sequence gates ({gate_passes} pass)")
        print()
        return 0

    # v8.3: Validate requirements traceability
    if args.validate_traceability:
        print_header("REQUIREMENTS TRACEABILITY GATE (v8.3)")
        # v2.0.5: Resolve scanner path from project config, fallback to legacy path
        scanner_project = None
        project_info = load_project_config()
        if project_info and "_config" in project_info:
            scanner_rel = project_info["_config"].get("scannerProject")
            if scanner_rel:
                scanner_project = get_workspace_dir().parent / scanner_rel
        if not scanner_project:
            # TODO: Remove legacy fallback once all projects define scannerProject in config
            scanner_project = get_workspace_dir().parent / "Uplifted" / "Tools" / "RequirementsScanner"
        if not scanner_project.exists():
            print_error(f"Scanner project not found: {scanner_project}")
            return 1
        print_info("Running Requirements Scanner gate check (--gate --min-coverage 80)...")
        print()
        try:
            result = subprocess.run(
                ["dotnet", "run", "--project", str(scanner_project), "--", "--gate", "--min-coverage", "80"],
                capture_output=False,
                timeout=300,
                cwd=str(get_workspace_dir().parent)
            )
            print()
            if result.returncode == 0:
                print_ok("Requirements traceability gate: PASS")
            else:
                print_error(f"Requirements traceability gate: FAIL (exit code {result.returncode})")
            return result.returncode
        except subprocess.TimeoutExpired:
            print_error("Scanner timed out after 300 seconds")
            return 1
        except FileNotFoundError:
            print_error("dotnet command not found - ensure .NET SDK is installed")
            return 1

    # v5.2: Auto-Dispatch mode
    if args.dispatch:
        # Light pre-flight for dispatch mode
        print_header("PRE-FLIGHT CHECKS (Dispatch Mode)")
        print_info("Checking for rogue processes...")
        killed = preflight_kill_rogue_processes()
        if killed > 0:
            print_warn(f"Killed {killed} rogue process(es)")
        else:
            print_ok("No rogue processes found")

        print_info("Verifying crew directories...")
        preflight_verify_crew_dirs()
        print_ok("Crew directories ready")

        print_info("Verifying queue directories (v7.0 - all queues)...")
        queues_dir = get_queues_dir()
        for qdir in ["explicit", "high-level", "orders", "bugs", "defects",
                      "security", "breakdown", "escalations",
                      "requests/planning", "requests/investigation",
                      "requests/qa", "requests/documentation"]:
            (queues_dir / qdir).mkdir(parents=True, exist_ok=True)
        print_ok("All queue directories ready (8 types + 4 request subtypes)")

        print_info("Checking for orphaned IN_PROGRESS orders...")
        reset = reset_orphaned_in_progress_orders()
        if reset > 0:
            print_warn(f"Reset {reset} orphaned order(s) -> PENDING")
        else:
            print_ok("No orphaned orders found")

        print_info("Validating repo config (placeholder check)...")
        _repo_cfg_errors = validate_placeholder_repo_config()
        if _repo_cfg_errors:
            print_error("Dispatch aborted — workspace still has placeholder repo config:")
            for _err in _repo_cfg_errors:
                print_error(f"  • {_err}")
            print_info("Fix the values above, then re-run `mso dispatch`.")
            print_info("Or run `mso setup --check` to audit the full workspace.")
            write_lifecycle_event(
                "ERROR",
                "Dispatch aborted: placeholder repo config detected — " + "; ".join(_repo_cfg_errors),
            )
            return 1
        print_ok("Repo config looks real (no placeholder values)")

        print(f"\n  {C.GREEN}{C.BOLD}Pre-flight checks PASSED{C.RESET}\n")
        time.sleep(1)

        # Auto-launch the unified Maestro Monitor
        auto_launch_monitor()

        # Run dispatcher
        try:
            run_dispatcher(
                max_crews=args.max_crews,
                stagger_delay=args.stagger_delay,
                max_iterations=args.max_iterations,
                timeout_minutes=args.timeout,
                max_turns=args.max_turns,
            )
            return 0
        except Exception as e:
            print(f"\n  {C.RED}Dispatcher error: {e}{C.RESET}\n")
            cleanup_fleet("error")
            return 1

    parser.error("Please specify --dispatch, --cleanup, or --archive-completed")


if __name__ == "__main__":
    run_cli(main, command="mso dispatch")


# ---------------------------------------------------------------------------
# Rebrand vocabulary (FTR-MSO-2026-0155) — new canonical names
# ---------------------------------------------------------------------------

class TeamRunner:
    """Namespace sentinel for the fleet-runner dispatch subsystem."""


class Sprint:
    """Namespace sentinel representing a voyage/sprint unit of work."""


class Squad:
    """Namespace sentinel representing a crew/squad unit of work."""


# Legacy aliases — kept through v3.x, removed in v4.0
FleetRunner = TeamRunner  # legacy alias (v3.x); removed v4.0
Voyage = Sprint           # legacy alias (v3.x); removed v4.0
Crew = Squad              # legacy alias (v3.x); removed v4.0
dispatch_crew = dispatch_squad  # legacy alias (v3.x); removed v4.0
