"""Worktree lifecycle primitives for parallel voyage isolation.

Provides prepare/cleanup/prune operations for git worktrees scoped to
voyage working directories under .mso/voyages/active/<voyage_id>/.worktree/.

Per-crew isolation (BUG-MSO-2026-0240)
---------------------------------------
FTR-ADM-2026-0149 introduced a single shared worktree per voyage, which
caused concurrent crews of the same voyage to clobber each other's files
and git index. The fix gives every dispatched crew its OWN worktree on a
per-crew branch:

  .mso/voyages/active/<voyage_id>/.worktree-crew<N>   ← crew N works here
  .mso/voyages/active/<voyage_id>/.worktree            ← voyage admin worktree
                                                          (convergence merges only)

When a crew completes, its crew branch is merged back into the voyage branch
via merge_crew_branch_into_voyage() and the crew worktree is cleaned up.
Cross-voyage parallelism (different voyages → different voyage dirs) is
unaffected.
"""

from __future__ import annotations

import re
import subprocess
import threading
import time
from pathlib import Path
from typing import Optional

from maestro.workspace import resolve_artefact_dir as _resolve_artefact_dir

from maestro.core.fleet_runner import _robust_rmtree

# Module-level lock to serialize concurrent prepare calls for the same worktree
_prepare_lock = threading.Lock()

# Serialize convergence merges to avoid concurrent pushes to the same voyage branch
_merge_lock = threading.Lock()


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class WorktreeError(Exception):
    """Base class for worktree lifecycle errors."""


class WorktreeBranchConflict(WorktreeError):
    """Branch is already checked out in another worktree."""


class WorktreeDirExists(WorktreeError):
    """Worktree directory exists but is not registered with git."""


class WorktreeMissingBranch(WorktreeError):
    """The requested branch does not exist and cannot be created."""


class WorktreeContentConflict(WorktreeError):
    """Merge failed due to a genuine content/add-add conflict (FTR-MSO-2026-0267).

    Raised instead of generic WorktreeError when `git merge` exits non-zero AND
    there are conflicting files (--diff-filter=U).  Distinguished from REF_MISSING
    (crew branch not found) and push failures so the dispatcher can auto-serialize
    the loser order instead of immediately escalating to CONVERGENCE_FAILED.

    Attributes:
        conflict_files: list of relative paths that conflicted.
    """

    def __init__(self, message: str, conflict_files: list):
        super().__init__(message)
        self.conflict_files = conflict_files


class ConvergenceNetworkError(WorktreeError):
    """Convergence failed due to a transient network/timeout condition (BUG-MSO-2026-0268).

    Raised when a git network op (voyage fetch, crew fetch, voyage push) times out
    or fails for a reason that indicates a transient infrastructure problem rather
    than a real content conflict or missing ref.

    Unlike WorktreeContentConflict (real merge conflict — may need operator) or
    REF_MISSING (crew branch absent — work is truly lost), this error class means
    the work is intact and convergence can be retried without re-running the role.
    The dispatcher re-queues the order for a convergence-only retry.
    """


# ---------------------------------------------------------------------------
# Convergence retry config
# ---------------------------------------------------------------------------

# Exponential backoff delays (seconds) for convergence network ops (BUG-MSO-2026-0268).
# 3 attempts: immediate, then 1 s, then 3 s before giving up.
# BUG-MSO-2026-0272: inner x outer retry budget.
# This inner loop (3 attempts) is independent of the outer convergence-retry loop in
# fleet_runner._CONVERGENCE_RETRY_CAP (also 3).  Combined with re-queue-as-PENDING
# between outer attempts, a persistently broken network will attempt each net op up to
# 3 x 3 = 9 times (with 2 full role re-executions between outer retries) before the
# order is marked CONVERGENCE_FAILED.  See fleet_runner._CONVERGENCE_RETRY_CAP.
_CONVERGENCE_RETRY_DELAYS = (0, 1, 3)


def _retry_git_network_op(cmd: list, *, cwd: str, timeout: int) -> subprocess.CompletedProcess:
    """Run a git network command with exponential-backoff retry (BUG-MSO-2026-0268).

    Attempts the command up to len(_CONVERGENCE_RETRY_DELAYS) times. Between
    attempts it sleeps for the delay specified in _CONVERGENCE_RETRY_DELAYS.
    A subprocess.TimeoutExpired on the LAST attempt is re-raised as
    ConvergenceNetworkError so callers can distinguish transient from terminal.

    Returns the CompletedProcess from the first successful attempt (returncode==0).
    Raises ConvergenceNetworkError if all attempts fail or time out.
    """
    last_exc: Optional[Exception] = None
    last_result: Optional[subprocess.CompletedProcess] = None

    for attempt, delay in enumerate(_CONVERGENCE_RETRY_DELAYS):
        if delay > 0:
            time.sleep(delay)
        try:
            result = subprocess.run(cmd, capture_output=True, text=True,
                                    cwd=cwd, timeout=timeout)
            last_result = result
            if result.returncode == 0:
                return result
            # Non-zero return on a network op may be transient (temporary
            # connectivity loss) or permanent (auth failure, missing ref).
            # Re-raise after retries as ConvergenceNetworkError; the caller
            # can inspect stderr to further classify if needed.
            last_exc = None
        except subprocess.TimeoutExpired as exc:
            last_exc = exc
            last_result = None

    # All retries exhausted
    detail = ""
    if last_exc is not None:
        detail = f"timed out after {timeout}s (command: {' '.join(cmd)})"
    elif last_result is not None:
        stderr = (last_result.stderr or "").strip()
        stdout = (last_result.stdout or "").strip()
        detail = f"returncode={last_result.returncode} stderr={stderr!r} stdout={stdout!r}"
    raise ConvergenceNetworkError(
        f"Git network op failed after {len(_CONVERGENCE_RETRY_DELAYS)} attempts: {detail}"
    )


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _repo_root() -> Path:
    """Return the root of the git repository."""
    result = subprocess.run(
        ["git", "rev-parse", "--show-toplevel"],
        capture_output=True, text=True
    )
    if result.returncode != 0:
        raise WorktreeError(f"Not inside a git repository: {result.stderr.strip()}")
    return Path(result.stdout.strip())


def _registered_worktrees() -> set[Path]:
    """Return the set of resolved paths currently registered with git worktree."""
    result = subprocess.run(
        ["git", "worktree", "list", "--porcelain"],
        capture_output=True, text=True
    )
    paths = set()
    for line in result.stdout.splitlines():
        if line.startswith("worktree "):
            raw = line[len("worktree "):].strip()
            # Use Path to normalise slashes; resolve() canonicalises on real FS
            p = Path(raw)
            paths.add(p)
    return paths


def _branch_exists_local(branch: str) -> bool:
    """Check whether ``refs/heads/<branch>`` exists in the local repo."""
    result = subprocess.run(
        ["git", "rev-parse", "--verify", f"refs/heads/{branch}"],
        capture_output=True
    )
    return result.returncode == 0


def _branch_exists_remote(branch: str, remote: str = "origin") -> bool:
    """Check whether ``refs/remotes/<remote>/<branch>`` exists in the local repo.

    Returns True if the remote-tracking ref is present locally. Does not call
    ``git fetch`` — use :func:`_fetch_remote_branch` first if you need to
    refresh the local view of the remote.
    """
    result = subprocess.run(
        ["git", "rev-parse", "--verify", f"refs/remotes/{remote}/{branch}"],
        capture_output=True
    )
    return result.returncode == 0


def _fetch_remote_branch(branch: str, remote: str = "origin") -> bool:
    """Fetch a single branch from *remote* into the matching remote-tracking ref.

    BUG-MSO-2026-0027: the dispatcher creates voyage branches via ``gh api``,
    which only touches the GitHub remote — the local repo has no record of
    the new ref until something fetches. Without this, ``git worktree add``
    fails because ``refs/heads/<branch>`` doesn't exist.
    """
    result = subprocess.run(
        ["git", "fetch", remote, f"{branch}:refs/remotes/{remote}/{branch}"],
        capture_output=True, text=True, timeout=30
    )
    return result.returncode == 0


# Backward-compat alias; new callers should use the explicit local/remote form.
def _branch_exists(branch: str) -> bool:
    return _branch_exists_local(branch)


def _find_worktree_for_branch(branch: str) -> Optional[Path]:
    """Return the worktree path where *branch* is currently checked out, or None."""
    result = subprocess.run(
        ["git", "worktree", "list", "--porcelain"],
        capture_output=True, text=True,
    )
    current_wt: Optional[Path] = None
    for line in result.stdout.splitlines():
        if line.startswith("worktree "):
            current_wt = Path(line[len("worktree "):].strip())
        elif line.startswith("branch ") and line.split()[-1] == f"refs/heads/{branch}":
            return current_wt
    return None


def _primary_worktree_path() -> Optional[Path]:
    """The PRIMARY repo checkout — first entry of `git worktree list --porcelain`."""
    result = subprocess.run(
        ["git", "worktree", "list", "--porcelain"],
        capture_output=True, text=True,
    )
    for line in result.stdout.splitlines():
        if line.startswith("worktree "):
            return Path(line[len("worktree "):].strip())
    return None


def _is_primary_worktree(path) -> bool:
    """True when *path* is the primary repo checkout (the live workspace).

    BUG-MSO-2026-0295: convergence must NEVER run `git reset --hard` /
    `git merge` in the primary checkout — that is where the dispatcher's
    uncommitted `.mso` lifecycle state lives, and resetting it resurrects
    completed orders as PENDING (the PSG VOY-PSG-2026-0344 mechanism).
    """
    primary = _primary_worktree_path()
    if primary is None:
        return False
    try:
        return Path(path).resolve() == primary.resolve()
    except OSError:
        return False


def resolve_convergence_worktree(voyage_id: str, voyage_branch: str):
    """Resolve a worktree for convergence git operations — NEVER the primary checkout.

    Returns ``(worktree_path, on_branch)``:
      - ``on_branch=True``  — the worktree has *voyage_branch* checked out;
        push with ``git push origin <branch>``.
      - ``on_branch=False`` — a DETACHED scratch worktree (the branch is
        checked out in the primary workspace checkout, which is off-limits);
        push with ``git push origin HEAD:refs/heads/<branch>``.

    BUG-MSO-2026-0295: the old fallback (`_find_worktree_for_branch`) could
    hand back the primary checkout, and the caller's `git reset --hard`
    then destroyed live dispatcher state. This resolver makes the primary
    checkout structurally unreachable from convergence code.

    Raises WorktreeError when no safe worktree can be produced.
    """
    try:
        return prepare_voyage_worktree(voyage_id, voyage_branch), True
    except WorktreeBranchConflict:
        existing = _find_worktree_for_branch(voyage_branch)
        if existing is not None and not _is_primary_worktree(existing):
            return existing, True

        # The voyage branch is checked out in the PRIMARY workspace checkout.
        # Use a detached scratch worktree instead of touching it.
        try:
            from maestro.core.fleet_runner import write_lifecycle_event
            write_lifecycle_event(
                "CONVERGENCE_PRIMARY_PROTECTED",
                f"'{voyage_branch}' is checked out in the primary workspace "
                f"checkout — converging via detached scratch worktree instead "
                f"of resetting live state (BUG-0295)"
            )
        except Exception:
            pass

        tmp = _resolve_artefact_dir(_repo_root()) / "temp" / f"convergence-{voyage_id}"
        if tmp.exists():
            subprocess.run(["git", "worktree", "remove", "--force", str(tmp)],
                           capture_output=True, text=True)
            if tmp.exists():
                _robust_rmtree(tmp, label=f"stale convergence worktree {voyage_id}")
            subprocess.run(["git", "worktree", "prune"], capture_output=True)
        tmp.parent.mkdir(parents=True, exist_ok=True)
        add_r = subprocess.run(
            ["git", "worktree", "add", "--detach", str(tmp), voyage_branch],
            capture_output=True, text=True,
        )
        if add_r.returncode != 0:
            raise WorktreeError(
                f"CONVERGENCE_REFUSED_PRIMARY: '{voyage_branch}' is checked out in "
                f"the primary workspace checkout and a detached scratch worktree "
                f"could not be created: {add_r.stderr.strip()}"
            )
        return tmp, False


def safe_ff_primary_checkout(voyage_branch: str) -> bool:
    """Fast-forward a CLEAN primary checkout holding *voyage_branch* to origin.

    BUG-MSO-2026-0295: when convergence merges via the detached scratch
    worktree (the branch is held by the primary checkout), the LOCAL branch
    ref is left behind origin. Crew worktree prep resolves branches
    local-first (BUG-0253), so a stale local ref would hand dependent crews
    an old voyage tip. If the primary tree is clean, `merge --ff-only` is a
    safe catch-up (no reset, no content loss possible — ff refuses anything
    but a strict descendant). A DIRTY primary tree is left untouched: origin
    holds the truth, the next convergence merges both lineages, and we warn.
    """
    wt = _find_worktree_for_branch(voyage_branch)
    if wt is None or not _is_primary_worktree(wt):
        return False
    # Untracked files never block an ff merge (git refuses on its own if one
    # would be overwritten) — only tracked modifications make the tree dirty.
    status_r = subprocess.run(["git", "status", "--porcelain", "--untracked-files=no"],
                              capture_output=True, text=True, cwd=str(wt))
    if status_r.returncode != 0 or status_r.stdout.strip():
        try:
            from maestro.core.fleet_runner import write_lifecycle_event
            write_lifecycle_event(
                "WARN",
                f"primary checkout on '{voyage_branch}' has uncommitted changes — "
                f"local ref left behind origin after scratch-worktree convergence "
                f"(catch up manually with `git pull --ff-only`) (BUG-0295)"
            )
        except Exception:
            pass
        return False
    ff_r = subprocess.run(
        ["git", "merge", "--ff-only", f"origin/{voyage_branch}"],
        capture_output=True, text=True, cwd=str(wt))
    return ff_r.returncode == 0


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def worktree_path_for(voyage_id: str) -> Path:
    """Return the canonical voyage admin worktree path (no I/O).

    This worktree is used exclusively for convergence merges. Crew work
    happens in crew_worktree_path_for() worktrees (BUG-MSO-2026-0240).
    """
    return _resolve_artefact_dir(_repo_root()) / "voyages" / "active" / voyage_id / ".worktree"


def crew_worktree_path_for(voyage_id: str, crew_num: int) -> Path:
    """Return the per-crew worktree path for (voyage_id, crew_num) (no I/O)."""
    return (
        _resolve_artefact_dir(_repo_root())
        / "voyages" / "active" / voyage_id
        / f".worktree-crew{crew_num}"
    )


def crew_branch_name(voyage_id: str, crew_num: int) -> str:
    """Return the per-crew git branch name, e.g. ``crew/VOY-MSO-2026-0056-1``."""
    return f"crew/{voyage_id}-{crew_num}"


def commit_crew_worktree_if_dirty(voyage_id: str, crew_num: int,
                                  order_id: Optional[str] = None) -> bool:
    """BUG-MSO-2026-0284: auto-commit a crew's uncommitted worktree changes.

    Convergence (``merge_crew_branch_into_voyage``) merges the crew BRANCH and
    assumes the crew committed its work. A crew that writes artefacts (e.g. a PLN
    plan) but never runs ``git commit`` would otherwise have its work SILENTLY
    LOST: the dispatcher pre-creates the crew branch, so an empty crew branch
    merges as a no-op and the order advances "success" with nothing persisted.
    (The legacy ``verify_and_push_crew_work`` was meant to cover this but is dead
    code wired to the pre-worktree ``crews/N/repo`` path — see BUG-0284.)

    Call this in finalize BEFORE convergence. It runs as dispatcher code (not via
    Claude's Bash tool), so the branch_guard pretool hook does NOT intercept it —
    hence the explicit branch-safety check: only commit when HEAD is the crew's
    OWN branch, never some other ref (mirrors BUG-MSO-2026-0241's intent).

    Returns True iff a commit was created. Fail-safe: returns False on a clean
    tree, a missing worktree, an unexpected HEAD, or ANY git error — this is a
    best-effort safety net and must never break finalization.
    """
    wt = crew_worktree_path_for(voyage_id, crew_num)
    if not wt.exists():
        return False
    expected_branch = crew_branch_name(voyage_id, crew_num)

    def _git(args, timeout: int = 30) -> subprocess.CompletedProcess:
        return subprocess.run(["git", *args], capture_output=True, text=True,
                              cwd=str(wt), timeout=timeout)

    try:
        status = _git(["status", "--porcelain"])
        if status.returncode != 0 or not status.stdout.strip():
            return False  # clean (or unreadable) — nothing to commit

        head = _git(["rev-parse", "--abbrev-ref", "HEAD"])
        actual = head.stdout.strip() if head.returncode == 0 else ""
        if actual != expected_branch:
            # Safety: never auto-commit onto an unexpected branch (e.g. main /
            # the voyage branch). Caller may log the skip via the return value.
            return False

        if _git(["add", "-A"]).returncode != 0:
            return False
        msg = (f"[fleet] auto-commit uncommitted crew artefacts for "
               f"{order_id or voyage_id} (Crew {crew_num}, BUG-MSO-2026-0284)")
        # Make the commit self-sufficient in headless/dispatcher environments:
        # never sign (no key/agent in automated runs) and supply a fallback
        # committer identity ONLY when none is configured — otherwise the commit
        # fails silently and the safety net is defeated (Copilot review of PR #139).
        commit_cfg = ["-c", "commit.gpgsign=false"]
        if not _git(["config", "user.email"]).stdout.strip():
            commit_cfg += ["-c", "user.email=fleet@maestro.local",
                           "-c", "user.name=Maestro Fleet"]
        return _git([*commit_cfg, "commit", "-m", msg]).returncode == 0
    except Exception:
        return False


def prepare_voyage_worktree(voyage_id: str, voyage_branch: str) -> Path:
    """Create (or reuse) the git worktree for a voyage.

    Idempotent: if the worktree already exists and is registered, returns its path.
    Handles orphaned dirs from crashed PREPARING state by removing and recreating.

    Raises:
        WorktreeBranchConflict: branch is checked out in another worktree.
        WorktreeMissingBranch: branch does not exist.
        WorktreeError: git worktree add failed for another reason.
    """
    with _prepare_lock:
        worktree_path = worktree_path_for(voyage_id)
        registered = _registered_worktrees()

        # Happy path: already ready
        if worktree_path.exists() and worktree_path in registered:
            return worktree_path

        # Orphaned dir (PREPARING crash): remove and recreate
        if worktree_path.exists() and worktree_path not in registered:
            _robust_rmtree(worktree_path, label=f"worktree orphan {voyage_id}")

        # BUG-MSO-2026-0027: the dispatcher creates voyage branches via
        # ``gh api`` (remote-only). Resolve in three tiers:
        #   1. Local branch ref present → standard ``git worktree add <path> <branch>``.
        #   2. Remote-tracking ref already present → fetch is unnecessary; create
        #      the local branch via ``git worktree add -b <branch> <path> origin/<branch>``.
        #   3. Neither present → ``git fetch`` the specific branch from origin
        #      and retry the tracking-branch worktree add.
        # Fail loudly with WorktreeMissingBranch only if all three fail.
        local_branch = _branch_exists_local(voyage_branch)
        if not local_branch:
            if not _branch_exists_remote(voyage_branch):
                _fetch_remote_branch(voyage_branch)
            if not _branch_exists_remote(voyage_branch):
                raise WorktreeMissingBranch(
                    f"Branch '{voyage_branch}' does not exist locally or on origin. "
                    "Create it before calling prepare_voyage_worktree()."
                )

        worktree_path.parent.mkdir(parents=True, exist_ok=True)

        if local_branch:
            cmd = ["git", "worktree", "add", str(worktree_path), voyage_branch]
        else:
            # Create local branch tracking origin/<branch> in the same step.
            cmd = [
                "git", "worktree", "add",
                "-b", voyage_branch,
                str(worktree_path),
                f"origin/{voyage_branch}",
            ]

        result = subprocess.run(cmd, capture_output=True, text=True)

        if result.returncode == 0:
            return worktree_path

        stderr = result.stderr.strip()

        if "already checked out" in stderr or "already used by worktree" in stderr:
            raise WorktreeBranchConflict(
                f"Branch '{voyage_branch}' is already checked out in another worktree. "
                f"git error: {stderr}"
            )

        if "No space left" in stderr or "disk full" in stderr.lower():
            raise WorktreeError(f"Disk full while creating worktree: {stderr}")

        # Already registered (e.g. path comparison miss in concurrent scenario)
        if "already registered" in stderr and worktree_path.exists():
            return worktree_path

        raise WorktreeError(f"git worktree add failed: {stderr}")


def prepare_crew_worktree(voyage_id: str, crew_num: int, voyage_branch: str) -> Path:
    """Create (or reuse) an isolated per-crew git worktree on a per-crew branch.

    Each crew of the same voyage gets its own worktree at
    .mso/voyages/active/<voyage_id>/.worktree-crew<crew_num> on branch
    crew/<voyage_id>-<crew_num>, branched from voyage_branch.

    On re-dispatch (crew timed out and was requeued): if the crew branch already
    exists locally, the worktree is recreated on that same branch so the crew
    can continue from where it left off.

    The MAESTRO_SPRINT_BRANCH injected into the crew process must be the crew
    branch name (from crew_branch_name()) so the branch guard allows mutations
    on the crew branch rather than the voyage branch.

    Raises:
        WorktreeMissingBranch: voyage_branch does not exist locally or on origin.
        WorktreeBranchConflict: crew branch already checked out in another worktree.
        WorktreeError: git worktree add failed for another reason.
    """
    with _prepare_lock:
        wt_path = crew_worktree_path_for(voyage_id, crew_num)
        c_branch = crew_branch_name(voyage_id, crew_num)
        registered = _registered_worktrees()

        # Happy path: already ready (idempotent on re-call)
        if wt_path.exists() and wt_path in registered:
            return wt_path

        # Orphaned dir (PREPARING crash): remove and recreate
        if wt_path.exists() and wt_path not in registered:
            _robust_rmtree(wt_path, label=f"crew worktree orphan {voyage_id}-{crew_num}")

        # Resolve the voyage branch start-point using the same three-tier strategy
        # as prepare_voyage_worktree (BUG-MSO-2026-0027).
        local_voy = _branch_exists_local(voyage_branch)
        if not local_voy:
            if not _branch_exists_remote(voyage_branch):
                _fetch_remote_branch(voyage_branch)
            if not _branch_exists_remote(voyage_branch):
                raise WorktreeMissingBranch(
                    f"Voyage branch '{voyage_branch}' does not exist locally or on origin."
                )
        start_point = voyage_branch if local_voy else f"origin/{voyage_branch}"

        wt_path.parent.mkdir(parents=True, exist_ok=True)

        # Re-dispatch: crew branch already exists — reuse it (don't re-branch from voyage tip)
        if _branch_exists_local(c_branch):
            cmd = ["git", "worktree", "add", str(wt_path), c_branch]
        else:
            # Fresh crew: create crew branch from the current voyage branch tip
            cmd = ["git", "worktree", "add", "-b", c_branch, str(wt_path), start_point]

        result = subprocess.run(cmd, capture_output=True, text=True)

        if result.returncode == 0:
            return wt_path

        stderr = result.stderr.strip()

        if "already checked out" in stderr or "already used by worktree" in stderr:
            raise WorktreeBranchConflict(
                f"Crew branch '{c_branch}' is already checked out in another worktree. "
                f"git error: {stderr}"
            )

        if "already registered" in stderr and wt_path.exists():
            return wt_path

        if "No space left" in stderr or "disk full" in stderr.lower():
            raise WorktreeError(f"Disk full while creating crew worktree: {stderr}")

        raise WorktreeError(f"git worktree add failed for crew {crew_num}: {stderr}")


def merge_crew_branch_into_voyage(voyage_id: str, crew_num: int, voyage_branch: str,
                                  order_id: Optional[str] = None,
                                  convergence_timeout: int = 60) -> bool:
    """Merge a completed crew's branch into the voyage branch (convergence step).

    Uses the voyage admin worktree (.worktree) as a scratch pad:
      1. Sync to origin/<voyage_branch> (reset --hard to handle any prior failed merge)
      2. Fetch origin/<crew_branch>
      3. Merge --no-ff to preserve crew history
      4. Push to origin/<voyage_branch>

    The _merge_lock serializes concurrent convergence merges so two crews
    finishing simultaneously don't produce a push race on the same branch.

    `order_id` (BUG-MSO-2026-0244) is woven into the convergence commit message so
    `git log` on the voyage branch reflects the order actually being merged rather
    than a hardcoded bug id.

    `convergence_timeout` (BUG-MSO-2026-0268) is the per-op timeout in seconds for
    git network operations (voyage fetch, crew fetch, voyage push). Each op is retried
    with exponential backoff before raising ConvergenceNetworkError. Default: 60 s.

    Returns True on clean merge+push.
    Raises ConvergenceNetworkError on transient network/timeout failures (retryable).
    Raises WorktreeError on merge conflict or push failure. On a merge conflict the
    error message lists the conflicting files (BUG-MSO-2026-0244) so finalization can
    record them for recovery.
    """
    c_branch = crew_branch_name(voyage_id, crew_num)

    with _merge_lock:
        # Resolve a worktree on the voyage branch for convergence merges.
        # Preference: voyage admin worktree (.worktree); fall back to another
        # non-primary checkout of the branch. BUG-MSO-2026-0295: NEVER the
        # primary workspace checkout — resetting it destroys live dispatcher
        # state. When the branch is checked out in the primary tree, a
        # detached scratch worktree is used (on_branch=False → push HEAD:ref).
        try:
            admin_wt, on_branch = resolve_convergence_worktree(voyage_id, voyage_branch)
        except WorktreeError:
            raise
        except Exception as exc:
            raise WorktreeError(
                f"Cannot prepare voyage admin worktree for convergence: {exc}"
            ) from exc

        def _run(cmd: list, *, timeout: int = 60) -> subprocess.CompletedProcess:
            return subprocess.run(cmd, capture_output=True, text=True,
                                  cwd=str(admin_wt), timeout=timeout)

        def _run_net(cmd: list, *, timeout: Optional[int] = None) -> subprocess.CompletedProcess:
            """Network op with retry/backoff; raises ConvergenceNetworkError on failure."""
            return _retry_git_network_op(cmd, cwd=str(admin_wt),
                                         timeout=timeout or convergence_timeout)

        def _has_ref(ref: str) -> bool:
            return _run(["git", "rev-parse", "--verify", "--quiet", ref]).returncode == 0

        # Sync origin/<voyage_branch> so the admin worktree has the latest voyage
        # state to merge onto. BUG-MSO-2026-0268: use retry helper (was single-shot,
        # ignoring returncode). ConvergenceNetworkError propagates to the dispatcher
        # as a RETRYABLE failure rather than terminal CONVERGENCE_FAILED.
        _run_net(["git", "fetch", "origin",
                  f"{voyage_branch}:refs/remotes/origin/{voyage_branch}"])

        # BUG-MSO-2026-0253: resolve the crew-branch merge target LOCAL-first.
        # In normal dispatch the crew commits to its branch inside a per-crew worktree
        # and never pushes it to origin; because all worktrees of this repo share one
        # ref store, that branch is visible here as a local ref. The old code merged
        # origin/<c_branch> unconditionally, which failed with "not something we can
        # merge" and stranded EVERY successful build whose crew branch was unpushed
        # (the existing test masked this by manually pushing the crew branch). Prefer
        # the local ref; fall back to origin only for the rare pre-pushed case; raise
        # a clear REF_MISSING error if neither exists.
        if _has_ref(f"refs/heads/{c_branch}"):
            merge_target = c_branch
        else:
            # BUG-MSO-2026-0268: use retry helper for crew-branch fetch too.
            # Raises ConvergenceNetworkError on timeout/transient; swallow and
            # fall through to REF_MISSING check only on "couldn't find remote ref".
            try:
                fetch_r = _run_net(["git", "fetch", "origin",
                                    f"{c_branch}:refs/remotes/origin/{c_branch}"])
            except ConvergenceNetworkError as _net_exc:
                # Distinguish "ref genuinely absent" (REF_MISSING) from transient
                # network failure. _run_net only raises if returncode != 0 on all
                # retries or if every attempt timed out. Check the last result's
                # output for the canonical "couldn't find remote ref" marker.
                # BUG-MSO-2026-0272: match only specific git phrases for a genuinely
                # missing ref.  The bare substring 'remote ref' is too broad — it
                # appears in timeout/command echoes and many transient error messages
                # (auth failures, DNS issues, 5xx) and would misclassify them as
                # REF_MISSING (terminal) instead of retryable.
                _net_msg = str(_net_exc).lower()
                _is_ref_missing = (
                    "couldn't find remote ref" in _net_msg
                    or "remote ref does not exist" in _net_msg
                    or "unknown revision" in _net_msg
                    or bool(re.search(r"refspec .* does not match any", _net_msg))
                )
                if _is_ref_missing:
                    raise WorktreeError(
                        f"Convergence target missing: crew branch '{c_branch}' was not "
                        f"found locally or on origin — the crew's work cannot be located "
                        f"(REF_MISSING). This usually means the crew produced no commit."
                    )
                raise  # propagate as ConvergenceNetworkError (retryable)
            if _has_ref(f"refs/remotes/origin/{c_branch}"):
                merge_target = f"origin/{c_branch}"
            else:
                raise WorktreeError(
                    f"Convergence target missing: crew branch '{c_branch}' was not "
                    f"found locally or on origin — the crew's work cannot be located "
                    f"(REF_MISSING). This usually means the crew produced no commit."
                )

        # Sync admin worktree to latest origin/voyage_branch (handles prior failed pushes)
        reset_r = _run(["git", "reset", "--hard", f"origin/{voyage_branch}"])
        if reset_r.returncode != 0:
            raise WorktreeError(
                f"git reset --hard origin/{voyage_branch} failed: {reset_r.stderr.strip()}"
            )

        # Merge crew branch; --no-ff keeps crew history readable.
        # BUG-MSO-2026-0244: reference the order actually being merged, not a hardcoded bug id.
        _ref = order_id or c_branch
        merge_r = _run([
            "git", "merge", "--no-ff", merge_target,
            "-m",
            f"convergence: merge crew {crew_num} ({c_branch}) into {voyage_branch} ({_ref})",
        ])
        if merge_r.returncode != 0:
            # BUG-MSO-2026-0244: capture the conflicting files BEFORE aborting (abort
            # clears the conflicted index). Conflict detail lands on git's stdout, not
            # stderr, so include both streams in the raised error.
            conflicts_r = _run(["git", "diff", "--name-only", "--diff-filter=U"])
            conflict_files = [f for f in conflicts_r.stdout.splitlines() if f.strip()]
            _run(["git", "merge", "--abort"])
            _detail = (merge_r.stdout.strip() + " " + merge_r.stderr.strip()).strip()
            _files = ", ".join(conflict_files) if conflict_files else "unknown"
            if conflict_files:
                # FTR-MSO-2026-0267: real content/add-add conflict — raise typed exception
                # so the dispatcher can auto-serialize the loser order.
                raise WorktreeContentConflict(
                    f"Merge of {c_branch} into {voyage_branch} failed (content conflict). "
                    f"Conflicting files: {_files}. git: {_detail}",
                    conflict_files=conflict_files,
                )
            raise WorktreeError(
                f"Merge of {c_branch} into {voyage_branch} failed (conflict). "
                f"Conflicting files: {_files}. git: {_detail}"
            )

        # Push merged voyage branch. BUG-MSO-2026-0268: use retry helper.
        # BUG-MSO-2026-0272: pushes upload pack data and need a longer ceiling than
        # fetches; use 2x convergence_timeout to restore pre-PR-122 behaviour.
        # ConvergenceNetworkError propagates to dispatcher as RETRYABLE.
        # BUG-MSO-2026-0295: a detached scratch worktree (branch held by the
        # primary checkout) pushes its merged HEAD to the branch ref directly,
        # then fast-forwards the primary checkout if (and only if) it is clean.
        push_ref = voyage_branch if on_branch else f"HEAD:refs/heads/{voyage_branch}"
        _run_net(["git", "push", "origin", push_ref],
                 timeout=2 * convergence_timeout)
        if not on_branch:
            _run(["git", "fetch", "origin",
                  f"{voyage_branch}:refs/remotes/origin/{voyage_branch}"])
            safe_ff_primary_checkout(voyage_branch)

        return True


def cleanup_crew_worktree(voyage_id: str, crew_num: int) -> bool:
    """Remove the per-crew worktree (and optionally its crew branch).

    Returns True on clean removal, False if the worktree didn't exist.
    """
    wt_path = crew_worktree_path_for(voyage_id, crew_num)
    c_branch = crew_branch_name(voyage_id, crew_num)

    if not wt_path.exists():
        subprocess.run(["git", "worktree", "prune"], capture_output=True)
        return False

    result = subprocess.run(
        ["git", "worktree", "remove", "--force", str(wt_path)],
        capture_output=True, text=True,
    )

    if result.returncode != 0:
        removed = _robust_rmtree(wt_path, label=f"crew worktree cleanup {voyage_id}-{crew_num}")
        subprocess.run(["git", "worktree", "prune"], capture_output=True)
    else:
        if wt_path.exists():
            _robust_rmtree(wt_path, label=f"crew worktree cleanup {voyage_id}-{crew_num}")
        removed = True

    # Delete the ephemeral crew branch (it has been merged; keep remote clean).
    # `git branch -d` is the SAFE delete: it refuses to drop a branch whose commits
    # are not reachable from its upstream/HEAD. So if convergence failed (branch is
    # unmerged) this is a no-op and the stranded work survives — see
    # preserve_failed_crew_branch() for the recovery-preserving path.
    if _branch_exists_local(c_branch):
        subprocess.run(
            ["git", "branch", "-d", c_branch],
            capture_output=True,
        )

    # BUG-MSO-2026-0249: also delete the REMOTE crew branch. The branch name is
    # deterministic per (voyage, crew_num), so a leftover origin/crew/<voyage>-<N>
    # would be re-fetched/merged when the same slot is reused for a later order,
    # leaking the prior order's work onto the new crew branch. Best-effort + only
    # when an 'origin' remote exists; never fail cleanup over it.
    _delete_remote_crew_branch(c_branch)

    return removed


def _delete_remote_crew_branch(c_branch: str) -> None:
    """Best-effort delete of origin/<c_branch> so a reused crew slot can't merge it
    (BUG-MSO-2026-0249). Silent no-op when there's no origin or the ref is gone."""
    try:
        has_origin = subprocess.run(
            ["git", "remote", "get-url", "origin"], capture_output=True, text=True
        ).returncode == 0
        if not has_origin:
            return
        # Check the REAL remote state, not the local remote-tracking ref. A crew
        # typically pushes its branch without the dispatcher's main repo ever
        # fetching it, so refs/remotes/origin/<branch> may not exist locally even
        # though the branch is live on origin (Copilot PR #110). ls-remote queries
        # origin directly.
        ls = subprocess.run(
            ["git", "ls-remote", "--heads", "origin", c_branch],
            capture_output=True, text=True, timeout=60,
        )
        if ls.returncode != 0 or not ls.stdout.strip():
            return  # branch not present on the remote
        subprocess.run(
            ["git", "push", "origin", "--delete", c_branch],
            capture_output=True, text=True, timeout=60,
        )
    except Exception:
        pass


def preserve_failed_crew_branch(voyage_id: str, crew_num: int,
                                order_id: Optional[str] = None) -> Optional[dict]:
    """Preserve a crew branch whose convergence merge FAILED, and free its slot.

    BUG-MSO-2026-0244 / BUG-MSO-2026-0243. When merge_crew_branch_into_voyage()
    raises, the crew's work is stranded on crew/<voyage>-<N>. We must:
      1. Record the stranded commit SHA so it can be cherry-picked during recovery
         even after the crew slot is reused.
      2. Remove the crew worktree dir and RENAME the crew branch out of the way
         (crew/<voyage>-<N> -> salvage/<order>-<sha8>) so the next dispatch of the
         same crew slot starts from a fresh branch off the voyage tip — never
         building on top of the stranded order's work.

    Returns {"salvageBranch": ..., "strandedSha": ...} where salvageBranch is the
    ref that ACTUALLY holds the work (the renamed salvage ref on success, or the
    original crew branch if the rename didn't happen), or None if there was no local
    crew branch to preserve. strandedSha is the durable handle regardless. Best-effort:
    git failures are swallowed so this can never wedge finalization.
    """
    c_branch = crew_branch_name(voyage_id, crew_num)
    if not _branch_exists_local(c_branch):
        return None

    sha = "unknown"
    try:
        sha_r = subprocess.run(["git", "rev-parse", c_branch],
                               capture_output=True, text=True)
        if sha_r.returncode == 0 and sha_r.stdout.strip():
            sha = sha_r.stdout.strip()
    except Exception:
        pass

    sha8 = sha[:8] if sha != "unknown" else "unknown"
    # Sanitize the label into a git-ref-safe token so an unusual order_id can't make
    # `git branch -M` fail (which would otherwise leave the slot occupied).
    raw_label = order_id or c_branch
    label = re.sub(r"[^A-Za-z0-9._-]", "-", raw_label).strip("-") or "crew"
    salvage = f"salvage/{label}-{sha8}"

    # Remove the worktree first — a checked-out branch cannot be renamed.
    try:
        cleanup_crew_worktree(voyage_id, crew_num)
    except Exception:
        pass

    # Rename the (still-unmerged) crew branch out of the slot's namespace so the
    # slot frees for a fresh crew branch on next dispatch. -M forces past an
    # existing salvage ref.
    salvage_ok = False
    if _branch_exists_local(c_branch):
        try:
            r = subprocess.run(["git", "branch", "-M", c_branch, salvage],
                               capture_output=True, text=True)
            salvage_ok = (r.returncode == 0) and _branch_exists_local(salvage)
        except Exception:
            salvage_ok = False

    # Report the ref that actually holds the work — never a salvage name that may
    # not exist. If the rename failed, the work still lives on the crew branch (and
    # the SHA is always a valid handle for recovery).
    if salvage_ok:
        preserved_ref = salvage
    elif _branch_exists_local(c_branch):
        preserved_ref = c_branch
    elif _branch_exists_local(salvage):
        preserved_ref = salvage
    else:
        preserved_ref = None

    return {"salvageBranch": preserved_ref, "strandedSha": sha}


def cleanup_all_crew_worktrees(voyage_id: str) -> int:
    """Remove all per-crew worktrees for a voyage (called from sweep_decks).

    Returns count removed.
    """
    repo_root = _repo_root()
    artefact_dir = _resolve_artefact_dir(repo_root)
    voyage_dir = artefact_dir / "voyages" / "active" / voyage_id
    if not voyage_dir.exists():
        return 0

    removed = 0
    for candidate in voyage_dir.iterdir():
        if candidate.name.startswith(".worktree-crew") and candidate.is_dir():
            result = subprocess.run(
                ["git", "worktree", "remove", "--force", str(candidate)],
                capture_output=True,
            )
            if result.returncode != 0:
                _robust_rmtree(candidate, label=f"crew worktree sweep {voyage_id}")
            else:
                if candidate.exists():
                    _robust_rmtree(candidate, label=f"crew worktree sweep {voyage_id}")
            removed += 1

    if removed:
        subprocess.run(["git", "worktree", "prune"], capture_output=True)

    return removed


def cleanup_voyage_worktree(voyage_id: str) -> bool:
    """Remove the worktree for a voyage.

    Returns True on clean removal, False if removal failed (caller should log).
    No-op (returns False) if the worktree directory does not exist.
    """
    worktree_path = worktree_path_for(voyage_id)

    if not worktree_path.exists():
        # Still prune in case git has stale refs
        subprocess.run(["git", "worktree", "prune"], capture_output=True)
        return False

    result = subprocess.run(
        ["git", "worktree", "remove", "--force", str(worktree_path)],
        capture_output=True, text=True
    )

    if result.returncode != 0:
        # Fall back to manual removal + prune
        removed = _robust_rmtree(worktree_path, label=f"worktree cleanup {voyage_id}")
        subprocess.run(["git", "worktree", "prune"], capture_output=True)
        return removed

    # Belt-and-suspenders: remove any lingering dir
    if worktree_path.exists():
        _robust_rmtree(worktree_path, label=f"worktree cleanup {voyage_id}")

    return True


def prune_stale_worktrees() -> int:
    """Remove worktrees whose voyage has moved to voyages/complete/.

    Also runs `git worktree prune` to clean broken git refs.
    Returns the count of worktrees pruned.
    """
    subprocess.run(["git", "worktree", "prune"], capture_output=True)

    repo_root = _repo_root()
    artefact_dir = _resolve_artefact_dir(repo_root)
    active_dir = artefact_dir / "voyages" / "active"
    complete_dir = artefact_dir / "voyages" / "complete"

    if not active_dir.exists():
        return 0

    completed_voyage_ids = {p.name for p in complete_dir.iterdir()} if complete_dir.exists() else set()

    pruned = 0
    for voyage_dir in active_dir.iterdir():
        if not voyage_dir.is_dir():
            continue
        voyage_id = voyage_dir.name
        if voyage_id not in completed_voyage_ids:
            continue
        # Prune voyage admin worktree
        worktree_path = voyage_dir / ".worktree"
        if worktree_path.exists():
            if _salvage_worktree_if_dirty(worktree_path, voyage_id, "admin") == "failed":
                continue  # BUG-0298: never destroy unsalvaged work — skip, operator inspects
            subprocess.run(
                ["git", "worktree", "remove", "--force", str(worktree_path)],
                capture_output=True
            )
            _robust_rmtree(worktree_path, label=f"prune stale worktree {voyage_id}")
            pruned += 1
        # BUG-MSO-2026-0240: also prune any lingering per-crew worktrees
        for candidate in voyage_dir.iterdir():
            if candidate.name.startswith(".worktree-crew") and candidate.is_dir():
                if _salvage_worktree_if_dirty(candidate, voyage_id, candidate.name) == "failed":
                    continue  # BUG-0298: skip unsalvageable dirty tree
                subprocess.run(
                    ["git", "worktree", "remove", "--force", str(candidate)],
                    capture_output=True,
                )
                _robust_rmtree(candidate, label=f"prune stale crew worktree {voyage_id}")
                pruned += 1

    return pruned


def _salvage_worktree_if_dirty(wt_path, voyage_id: str, label: str) -> str:
    """BUG-MSO-2026-0298 (GKT F4): never force-remove a dirty worktree unsalvaged.

    A voyage can be (falsely or legitimately) archived while a worktree still
    holds uncommitted work — the GKT loss vector was exactly this prune. If the
    tree has tracked modifications, commit them and pin the commit on a
    `salvage/prune-<voyage>-<label>-<sha>` branch before removal.

    Returns "clean" (nothing to save), "salvaged" (branch created), or
    "failed" — and on "failed" the caller must SKIP removal: an unsalvaged
    dirty worktree is never destroyed; the WARN tells the operator where it is.
    """
    try:
        status_r = subprocess.run(
            ["git", "status", "--porcelain", "--untracked-files=no"],
            capture_output=True, text=True, cwd=str(wt_path))
        if status_r.returncode != 0 or not status_r.stdout.strip():
            return "clean"
        subprocess.run(["git", "add", "-A"], capture_output=True, cwd=str(wt_path))
        commit_r = subprocess.run(
            ["git",
             "-c", "user.name=Maestro Salvage",
             "-c", "user.email=salvage@maestro.local",
             "commit", "-m",
             f"salvage: uncommitted work in {label} worktree of {voyage_id} at prune (BUG-0298)"],
            capture_output=True, text=True, cwd=str(wt_path))
        if commit_r.returncode != 0:
            raise RuntimeError(f"salvage commit failed: {commit_r.stderr.strip()[:200]}")
        sha_r = subprocess.run(["git", "rev-parse", "--short", "HEAD"],
                               capture_output=True, text=True, cwd=str(wt_path))
        sha = sha_r.stdout.strip() or "unknown"
        branch = f"salvage/prune-{voyage_id}-{label}-{sha}"
        subprocess.run(["git", "branch", branch, "HEAD"],
                       capture_output=True, cwd=str(wt_path))
        try:
            from maestro.core.fleet_runner import write_lifecycle_event
            write_lifecycle_event(
                "SALVAGE",
                f"{voyage_id}: dirty {label} worktree preserved on {branch} "
                f"before prune (BUG-0298)")
        except Exception:
            pass
        return "salvaged"
    except Exception as exc:
        try:
            from maestro.core.fleet_runner import write_lifecycle_event
            write_lifecycle_event(
                "WARN",
                f"{voyage_id}: prune salvage of {label} worktree FAILED ({exc}) — "
                f"worktree LEFT IN PLACE at {wt_path}; inspect and salvage manually (BUG-0298)")
        except Exception:
            pass
        return "failed"
