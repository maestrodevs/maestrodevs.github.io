"""
maestro/review.py — Human review queue CLI handlers.

Supports: mso review queue | show | approve | revise | reject
Orders sit in .mso/queues/review/ while awaiting human decision.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict

from maestro.cli import find_workspace


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _adm_dir(ws: Path) -> Path:
    from maestro.workspace import resolve_artefact_dir
    return resolve_artefact_dir(ws)


def _review_dir(adm: Path) -> Path:
    return adm / "queues" / "review"


def _orders_dir(adm: Path) -> Path:
    return adm / "queues" / "orders"


def _load_order(review_dir: Path, order_id: str) -> tuple[Path, Dict[str, Any]]:
    path = review_dir / f"{order_id}.json"
    if not path.exists():
        print(f"[review] Order {order_id} not found in queues/review/", file=sys.stderr)
        sys.exit(1)
    data = json.loads(path.read_text(encoding="utf-8"))
    return path, data


def _write_lifecycle(adm: Path, event_type: str, message: str) -> None:
    log_dir = adm / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / "lifecycle.log"
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"{timestamp} | {event_type:<10} | {message}\n"
    try:
        with open(str(log_file), "a", encoding="utf-8") as f:
            f.write(line)
    except OSError:
        pass


def _reviewer() -> str:
    """Best-effort reviewer identity (git user or env fallback)."""
    try:
        result = subprocess.run(
            ["git", "config", "user.email"],
            capture_output=True, text=True, timeout=5,
        )
        email = result.stdout.strip()
        if email:
            return email
    except Exception:
        pass
    return os.environ.get("USER", os.environ.get("USERNAME", "unknown"))


def _age_str(iso_ts: str) -> str:
    try:
        dt = datetime.fromisoformat(iso_ts)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        delta = datetime.now(timezone.utc) - dt
        minutes = int(delta.total_seconds() // 60)
        if minutes < 60:
            return f"{minutes}m"
        hours = minutes // 60
        if hours < 24:
            return f"{hours}h"
        return f"{hours // 24}d"
    except Exception:
        return "?"


# ---------------------------------------------------------------------------
# Command handlers
# ---------------------------------------------------------------------------

def cmd_review_queue(args: Any) -> None:
    """List orders currently awaiting human review."""
    ws = find_workspace(getattr(args, "project", None))
    adm = _adm_dir(ws)
    rev_dir = _review_dir(adm)

    if not rev_dir.exists():
        print("[review] No orders pending review.")
        return

    files = sorted(rev_dir.glob("*.json"))
    if not files:
        print("[review] No orders pending review.")
        return

    header = f"{'ORDER ID':<28} {'TITLE':<40} {'VOYAGE':<22} {'AGE':>5} {'ROLE':<6}"
    print(header)
    print("-" * len(header))
    for f in files:
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
        except Exception:
            continue
        order_id = data.get("id", f.stem)
        title = (data.get("title", "") or "")[:38]
        voyage = data.get("voyageId", "")
        paused_at = data.get("navReviewPausedAt", "")
        age = _age_str(paused_at) if paused_at else "?"
        # BUG-MSO-2026-0205: standalone plan-approval orders have no next role.
        role = "PLAN" if data.get("planApprovalOnly") else data.get("targetRole", "")
        print(f"{order_id:<28} {title:<40} {voyage:<22} {age:>5} {role:<6}")


def cmd_review_show(args: Any) -> None:
    """Open the NAV plan for an order in $EDITOR, or print to stdout."""
    ws = find_workspace(getattr(args, "project", None))
    adm = _adm_dir(ws)
    order_id = args.order_id

    _, data = _load_order(_review_dir(adm), order_id)

    plan_path = adm / "plans" / f"PLAN-{order_id}.md"
    if not plan_path.exists():
        # Fallback: dump order JSON
        print(json.dumps(data, indent=2))
        return

    editor = getattr(args, "editor", None) or os.environ.get("EDITOR", "")
    if editor:
        subprocess.run([editor, str(plan_path)])
    else:
        print(plan_path.read_text(encoding="utf-8"))


def cmd_review_approve(args: Any) -> None:
    """Approve an order paused for human review.

    Two cases:
      * Intra-order (targetRole set): advance to the next role and re-queue to
        queues/orders/ for the dispatcher to pick up.
      * BUG-MSO-2026-0205 plan approval (planApprovalOnly): the standalone planning
        order has no next role — archive it as COMPLETE so its dependent FTR/BLD
        orders unblock (NAV_REVIEW_PENDING is not a satisfying dependency status).
    """
    ws = find_workspace(getattr(args, "project", None))
    adm = _adm_dir(ws)
    order_id = args.order_id

    rev_dir = _review_dir(adm)
    order_path, data = _load_order(rev_dir, order_id)

    now = datetime.now().isoformat()
    reviewer = _reviewer()

    data["reviewedAt"] = now
    data["reviewedBy"] = reviewer
    data.pop("navReviewPausedAt", None)

    if data.get("planApprovalOnly"):
        # Standalone planning order — archive COMPLETE to release dependents.
        data["status"] = "COMPLETE"
        data["completedAt"] = now
        data.pop("planApprovalOnly", None)
        archive_dir = adm / "orders" / "complete"
        archive_dir.mkdir(parents=True, exist_ok=True)
        dest = archive_dir / order_path.name
        dest.write_text(json.dumps(data, indent=2), encoding="utf-8")
        order_path.unlink()
        _write_lifecycle(adm, "NAV_REVIEW_APPROVED", f"{order_id} plan approved by {reviewer} -> COMPLETE (dependents released)")
        print(f"[review] {order_id} plan approved — archived COMPLETE; dependent orders released.")
        return

    # Intra-order: advance to the next role (already set by fleet_runner) and re-queue.
    next_role = data.get("targetRole", "SHP")
    data["status"] = "PENDING"

    orders_dir = _orders_dir(adm)
    orders_dir.mkdir(parents=True, exist_ok=True)
    dest = orders_dir / order_path.name
    dest.write_text(json.dumps(data, indent=2), encoding="utf-8")
    order_path.unlink()

    _write_lifecycle(adm, "NAV_REVIEW_APPROVED", f"{order_id} approved by {reviewer} -> {next_role}")
    print(f"[review] {order_id} approved — advanced to {next_role} and re-queued.")


def cmd_review_revise(args: Any) -> None:
    """Send order back to NAV for revision, appending notes to description."""
    ws = find_workspace(getattr(args, "project", None))
    adm = _adm_dir(ws)
    order_id = args.order_id
    notes = getattr(args, "notes", None)

    if not notes:
        print("[review] --notes is required for revise.", file=sys.stderr)
        sys.exit(1)

    rev_dir = _review_dir(adm)
    order_path, data = _load_order(rev_dir, order_id)

    now = datetime.now().isoformat()
    reviewer = _reviewer()

    existing_desc = data.get("description", "") or ""
    data["description"] = f"{existing_desc}\n\n[Revision requested {now} by {reviewer}]: {notes}".strip()
    data["status"] = "PENDING"
    data["targetRole"] = "NAV"
    data["reviewedAt"] = now
    data["reviewedBy"] = reviewer
    data.pop("navReviewPausedAt", None)

    orders_dir = _orders_dir(adm)
    orders_dir.mkdir(parents=True, exist_ok=True)
    dest = orders_dir / order_path.name
    dest.write_text(json.dumps(data, indent=2), encoding="utf-8")
    order_path.unlink()

    _write_lifecycle(adm, "NAV_REVIEW_REVISED", f"{order_id} revised by {reviewer}: {notes}")
    print(f"[review] {order_id} sent back to NAV for revision.")


def cmd_review_reject(args: Any) -> None:
    """Reject an order: mark it FAILED and archive it."""
    ws = find_workspace(getattr(args, "project", None))
    adm = _adm_dir(ws)
    order_id = args.order_id
    notes = getattr(args, "notes", None)

    if not notes:
        print("[review] --notes is required for reject.", file=sys.stderr)
        sys.exit(1)

    rev_dir = _review_dir(adm)
    order_path, data = _load_order(rev_dir, order_id)

    now = datetime.now().isoformat()
    reviewer = _reviewer()

    data["status"] = "FAILED"
    data["failureReason"] = f"rejected at NAV review: {notes}"
    data["reviewedAt"] = now
    data["reviewedBy"] = reviewer
    data.pop("navReviewPausedAt", None)

    archive_dir = adm / "orders" / "failed"
    archive_dir.mkdir(parents=True, exist_ok=True)
    dest = archive_dir / order_path.name
    dest.write_text(json.dumps(data, indent=2), encoding="utf-8")
    order_path.unlink()

    _write_lifecycle(adm, "NAV_REVIEW_REJECTED", f"{order_id} rejected by {reviewer}: {notes}")
    print(f"[review] {order_id} rejected and archived to orders/failed/.")
