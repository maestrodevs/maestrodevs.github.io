# Maestro CLI Reference

Complete reference for all `maestro` commands.

---

## Contents

- [mso dispatch](#mso-dispatch)
- [mso cleanup](#mso-cleanup)
- [mso status](#mso-status)
- [mso usage](#mso-usage)
- [mso estimate](#mso-estimate)
- [mso approve](#mso-approve)
- [mso reject](#mso-reject)
- [mso pause](#mso-pause)
- [mso resume](#mso-resume)
- [mso crew](#mso-crew)
- [mso verify](#mso-verify)
- [mso replay](#mso-replay)
- [mso export](#mso-export)
- [mso notify](#mso-notify)
- [mso backup](#mso-backup)
- [mso restore](#mso-restore)
- [mso init](#mso-init)
- [mso setup](#mso-setup)
- [mso create-order](#mso-create-order)
- [mso create-voyage](#mso-create-voyage)
- [mso diagnose](#mso-diagnose)
- [mso requirement](#mso-requirement)
- [mso licence](#maestro-licence)
- [mso version](#mso-version)
- [Exit Codes](#exit-codes)
- [Environment Variables](#environment-variables)

---

## mso dispatch

Launch fleet crews from the dispatch queues.

```
mso dispatch [--max-crews N] [--cleanup] [--stagger-delay S] [--timeout M] [--retry-failed N]
```

### Flags

| Flag | Type | Default | Description |
|------|------|---------|-------------|
| `--max-crews N` | integer | `5` | Maximum number of crews to run concurrently. Valid range: 1–5. |
| `--cleanup` | flag | `false` | Run cleanup before dispatching. Stops orphaned processes and resets stale lock files. |
| `--stagger-delay S` | integer | `30` | Seconds to wait between launching successive crew sessions. Reduces API rate pressure. |
| `--timeout M` | integer | `25` | Per-iteration wall-clock cap in minutes. Crews that exceed this are killed and marked TIMEOUT. Both `--timeout` and `--max-turns` are active simultaneously — whichever fires first wins. |
| `--max-turns N` | integer | `25` | Claude Code internal turn cap per iteration. When hit, Claude Code exits with `subtype=error_max_turns` (terminal state: `MAX_TURNS`). Order is requeued with fresh context. Increase for complex orders that need more reasoning steps. |
| `--retry-failed N` | integer | `0` | **planned** — Auto-retry crashed orders up to N times. When 0 (default), crashed orders are retried indefinitely. |

### How dispatch works

1. Scans all queue directories in priority order (see [Queue Priority](#queue-priority) below)
2. Filters out orders with unsatisfied `dependsOn` dependencies
3. Assigns available orders to crew slots (crew1 through crew5)
4. Launches a Claude Code subprocess for each crew with the role, order, and project context injected
5. Monitors each crew through multiple iterations via the stop hook

### Queue priority

| Queue | Priority |
|-------|---------|
| `queues/explicit/` | Highest |
| `queues/security/` | High |
| `queues/bugs/` | High |
| `queues/requests/` | Medium-High |
| `queues/orders/` | Medium |
| `queues/defects/` | Medium-Low |
| `queues/breakdown/` | Low |
| `queues/high-level/` | Lowest |
| `queues/escalations/` | Not dispatched — requires manual review |

### Examples

```bash
# Launch up to 3 crews
mso dispatch --max-crews 3

# Clean stale state first, then dispatch
mso dispatch --cleanup --max-crews 5

# Slower stagger for large crews to reduce rate limiting
mso dispatch --max-crews 5 --stagger-delay 60

# Allow 2 hours per crew for complex orders
mso dispatch --max-crews 3 --timeout 120

# Auto-retry crashed orders up to 2 times before permanently failing them
mso dispatch --max-crews 3 --retry-failed 2
```

---

## mso cleanup

Stop orphaned crew processes and reset stale crew state.

```
mso cleanup
```

### What cleanup does

- Terminates any crew processes whose PID files no longer match a running process
- Removes stale `crew.lock` files
- Resets `state.json` for idle crew slots

Safe to run at any time — does not affect orders that are actively in progress.

### Flags

None.

### Example

```bash
mso cleanup
```

---

## mso status

Display the fleet status dashboard.

```
mso status [--once] [--compact]
```

### Flags

| Flag | Type | Default | Description |
|------|------|---------|-------------|
| `--once` | flag | `false` | Print status once and exit. When omitted, the dashboard refreshes on a loop. |
| `--compact` | flag | `false` | One-line summary per crew instead of full detail panels. |

### Examples

```bash
# Live dashboard (loops, press Ctrl+C to exit)
mso status

# One-shot summary
mso status --once

# One-shot, compact view
mso status --once --compact
```

### Dashboard output

The status dashboard is the Maestro Monitor v4.0. It displays the following sections:

**Header** — Shows the current Maestro version (resolved dynamically from the installed package) and current timestamp.

**APPROVALS — AWAITING CAPTAIN REVIEW** *(v4.0)* — Appears only when there are items requiring Captain sign-off. Shows voyages, plans, and requirements that have been marked with `AWAITING_APPROVAL` status. Displayed in yellow, immediately after the dispatcher block so it is visible without scrolling. Hidden entirely when no items are pending approval.

**DISPATCHER** — Dispatcher process status (ACTIVE/STOPPED), PID, and uptime.

**CREW STATUS** — For each crew slot:
- Crew number and assigned order ID
- Current role (NAV / SHP / BOS / SCR / LKT / COX) and model (Opus / Sonnet / Haiku)
- Status (IDLE / RUNNING / COMPLETE / FAILED / CRASHED)
- Current iteration and maximum
- Recent activity summary and elapsed time (active crews)

**ESCALATIONS** — Shown only when crews have raised blocking issues that require Captain/QM intervention.

**QUEUES** — Count of pending items in each dispatch queue, broken down by type.

**LIFECYCLE LOG** — Recent fleet lifecycle events (crew starts, completions, role transitions).

---

## mso usage

Report token usage and estimated API cost.

```
mso usage [--voyage VOY-ID | --order ORDER-ID | --summary | --report [--output PATH]]
```

### Flags

| Flag | Type | Description |
|------|------|-------------|
| *(none)* | — | Print overall summary across all projects |
| `--summary` | flag | Print overall summary (explicit form) |
| `--voyage VOY-ID` | string | Breakdown by order for a specific voyage |
| `--order ORDER-ID` | string | Token detail for a specific order |
| `--report` | flag | Generate full markdown usage report |
| `--output PATH` | string | File path for `--report` output. Defaults to stdout. |

### Examples

```bash
# Overall summary
mso usage --summary

# Voyage-level breakdown
mso usage --voyage VOY-MYPROJ-2026-0001

# Single order detail
mso usage --order FTR-MYPROJ-2026-0001

# Generate full report to a file
mso usage --report --output .maestro/reports/usage-report.md
```

### Usage data source

Token counts are captured automatically at the end of each crew session by the stop hook. Usage data is stored per-order in `.maestro/usage/orders/{ORDER-ID}.json`.

---

## mso estimate

Estimate API token usage and cost for pending orders before dispatching.

```
mso estimate [--voyage VOY-ID | --order ORDER-ID | --all] [--queue QUEUE-NAME]
```

Uses historical usage data from completed orders and order complexity heuristics to produce a pre-dispatch cost estimate. No crews are launched.

### Flags

| Flag | Type | Description |
|------|------|-------------|
| *(none)* | — | Estimate all orders currently in dispatch queues |
| `--all` | flag | Estimate all queued orders (explicit form) |
| `--voyage VOY-ID` | string | Estimate only orders belonging to this voyage |
| `--order ORDER-ID` | string | Estimate a single specific order |
| `--queue QUEUE-NAME` | string | Estimate orders in a specific queue tier (e.g. `orders`, `bugs`) |

### Examples

```bash
# Estimate cost for all queued orders
mso estimate

# Estimate a specific voyage before dispatching
mso estimate --voyage VOY-MYPROJ-2026-0001

# Estimate a single order
mso estimate --order FTR-MYPROJ-2026-0001

# Estimate only the high-priority bug queue
mso estimate --queue bugs
```

### Example output

```
[Maestro] Usage estimate — queued orders

  FTR-MYPROJ-2026-0001  SHP  ~85k tokens  ~$0.42
  DOC-MYPROJ-2026-0002  SCR  ~30k tokens  ~$0.15
  BUG-MYPROJ-2026-0003  BOS  ~55k tokens  ~$0.27

  Total: 3 orders, ~170k tokens, estimated cost ~$0.84
  Note: Estimates are indicative. Actual usage depends on order complexity and crew iterations.
```

Estimates are derived from:
1. Historical averages for the same role and order type (if prior usage data exists)
2. Order description length and target file count as complexity proxies
3. Current API pricing for the assigned role's model

---

## mso approve

Approve a voyage, plan, or requirement that is awaiting Captain sign-off.

```
mso approve (--voyage VOY-ID | --plan FILE | --requirement FILE) [--note TEXT]
```

Updates the artifact's status from `AWAITING_APPROVAL` to `ACTIVE` in-place. The item disappears from the dashboard APPROVALS panel on the next refresh.

### Flags

| Flag | Type | Required | Description |
|------|------|----------|-------------|
| `--voyage VOY-ID` | string | One required | Voyage ID to approve (e.g. `VOY-MYPROJ-2026-0001`). |
| `--plan FILE` | string | One required | Path to a plan file (relative to workspace root). |
| `--requirement FILE` | string | One required | Path to a requirement file (relative to workspace root). |
| `--note TEXT` | string | No | Optional approval note recorded alongside the status change. |

Exactly one of `--voyage`, `--plan`, or `--requirement` must be supplied.

### Examples

```bash
# Approve a voyage
mso approve --voyage VOY-MYPROJ-2026-0001

# Approve a voyage with a note
mso approve --voyage VOY-MYPROJ-2026-0001 --note "Scope confirmed with stakeholders"

# Approve a plan
mso approve --plan .maestro/plans/NAV-FTR-MYPROJ-2026-0001.md

# Approve a requirement
mso approve --requirement .maestro/requirements/REQ-MYPROJ-2026-0001.md
```

### What approve does

**For voyages:** Sets `"status": "ACTIVE"` in the voyage JSON and records the `--note` (if any) as `"approvalNote"`.

**For plans and requirements:** Sets `status: active` in the YAML frontmatter and removes or updates `approvalNote`.

---

## mso reject

Reject a voyage, plan, or requirement that is awaiting Captain sign-off.

```
mso reject (--voyage VOY-ID | --plan FILE | --requirement FILE) [--reason TEXT]
```

Sets the artifact's status to `BLOCKED` and records the rejection reason. The item moves from the APPROVALS panel to the ESCALATIONS queue so the dispatcher holds all dependent work.

### Flags

| Flag | Type | Required | Description |
|------|------|----------|-------------|
| `--voyage VOY-ID` | string | One required | Voyage ID to reject. |
| `--plan FILE` | string | One required | Path to a plan file (relative to workspace root). |
| `--requirement FILE` | string | One required | Path to a requirement file (relative to workspace root). |
| `--reason TEXT` | string | No | Rejection reason. Written to `approvalNote` and the escalation record. |

Exactly one of `--voyage`, `--plan`, or `--requirement` must be supplied.

### Examples

```bash
# Reject a voyage with a reason
mso reject --voyage VOY-MYPROJ-2026-0001 --reason "Scope too broad — split into two voyages"

# Reject a plan
mso reject --plan .maestro/plans/NAV-FTR-MYPROJ-2026-0001.md --reason "Architecture decision deferred"
```

### What reject does

**For voyages:** Sets `"status": "BLOCKED"` in the voyage JSON and writes the reason to `"approvalNote"`. Creates an escalation entry in `.maestro/queues/escalations/` so the dispatcher halts all orders for the voyage.

**For plans and requirements:** Sets `status: blocked` in the YAML frontmatter and records the rejection reason in `approvalNote`.

---

## mso pause

Gracefully pause a running fleet or specific crew.

```
mso pause [--crew N | --all]
```

Signals the target crew(s) to complete their current iteration and then hold — no new iterations are started. The crew process remains alive; state is preserved. Use `mso resume` to continue.

### Flags

| Flag | Type | Default | Description |
|------|------|---------|-------------|
| `--crew N` | integer | — | Pause a specific crew (1–5). |
| `--all` | flag | — | Pause all currently running crews. |

When called with no flags, pauses the entire fleet (equivalent to `--all`).

### Examples

```bash
# Pause all running crews
mso pause

# Pause a specific crew
mso pause --crew 2

# Pause the full fleet explicitly
mso pause --all
```

### Pause behaviour

- The crew finishes its current tool call or LLM turn before pausing.
- Crew state (`state.json`, `progress.md`) is preserved exactly as-is.
- The dashboard shows paused crews with status `PAUSED`.
- Orders are not moved back to the queue — the crew resumes where it left off.

---

## mso resume

Resume a paused fleet or specific crew.

```
mso resume [--crew N | --all]
```

Re-activates crews that were paused with `mso pause`. The crew picks up from its last saved state and continues iterating until the order is complete or the timeout is reached.

### Flags

| Flag | Type | Default | Description |
|------|------|---------|-------------|
| `--crew N` | integer | — | Resume a specific crew (1–5). |
| `--all` | flag | — | Resume all paused crews. |

When called with no flags, resumes all paused crews (equivalent to `--all`).

### Examples

```bash
# Resume all paused crews
mso resume

# Resume a specific crew
mso resume --crew 2

# Resume all paused crews explicitly
mso resume --all
```

---

## mso crew

Inspect or operate an individual crew.

```
mso crew --crew N [--status | --watch | --cleanup]
```

### Flags

| Flag | Type | Required | Description |
|------|------|----------|-------------|
| `--crew N` | integer | Yes | Crew number. Valid range: 1–5. |
| `--status` | flag | No | Print crew status and last known state. |
| `--watch` | flag | No | Stream crew progress live from `progress.md`. |
| `--cleanup` | flag | No | Stop this specific crew's process and reset its state. |

### Examples

```bash
# Check crew 1 status
mso crew --crew 1 --status

# Watch crew 2 live
mso crew --crew 2 --watch

# Stop and reset crew 3
mso crew --crew 3 --cleanup
```

---

## mso verify

Run post-voyage build and test verification.

```
mso verify [--voyage VOY-ID] [--skip-tests]
```

### Flags

| Flag | Type | Description |
|------|------|-------------|
| `--voyage VOY-ID` | string | Voyage ID to verify. Verifies all orders in the voyage. |
| `--skip-tests` | flag | Skip test execution; reuse existing test results from the build output. |

### Examples

```bash
# Verify a completed voyage
mso verify --voyage VOY-MYPROJ-2026-0001

# Verify but skip test re-run
mso verify --voyage VOY-MYPROJ-2026-0001 --skip-tests
```

### What verify checks

- Runs the configured build command for each project in the voyage
- Runs the configured test command
- Produces a verification report in `.maestro/reports/voyage/`

---

---

## mso replay

Re-queue a failed or completed order for another attempt.

```
mso replay [ORDER_ID] [--voyage VOY-ID] [--failed-only] [--role ROLE]
```

### Flags

| Flag | Type | Description |
|------|------|-------------|
| `ORDER_ID` | positional | Order ID to replay (e.g. `FTR-MYPROJ-2026-0001`). Mutually exclusive with `--voyage`. |
| `--voyage VOY-ID` | string | Replay all orders from this voyage. Combine with `--failed-only` to replay only STALLED/FAILED orders. |
| `--failed-only` | flag | With `--voyage`: replay only stalled or failed orders. Completed orders are left untouched. |
| `--role ROLE` | string | Override the role for the replayed order (e.g. `COX`). Replaces the `role` field in the order JSON. |

### How replay works

1. Locates the order JSON by searching (in priority order): `orders/complete/`, `orders/failed/`, then all queue directories
2. Preserves the original in `.maestro/orders/failed/` before re-queuing
3. Resets the order fields: `status="PENDING"`, removes `completedAt`, `completedBy`, `stalledAt`, `stalledReason`, `stalledBy`, `retryCount`
4. If `--role` is provided, replaces the `role` field
5. Writes the reset order to `.maestro/queues/orders/` for the next dispatch

A `retryCount` field is incremented on each replay so you can track how many times an order has been attempted.

### Examples

```bash
# Re-queue a failed order
mso replay FTR-MYPROJ-2026-0001

# Replay with a different role
mso replay FTR-MYPROJ-2026-0001 --role COX

# Replay all failed/stalled orders from a voyage
mso replay --voyage VOY-MYPROJ-2026-0001 --failed-only

# Replay ALL orders from a voyage (re-run the whole voyage)
mso replay --voyage VOY-MYPROJ-2026-0001
```

### Example output

```
[Maestro] FTR-MYPROJ-2026-0001 re-queued in .maestro/queues/orders/
            (Original preserved in .maestro/orders/failed/)

[Maestro] Replayed 3 order(s) for VOY-MYPROJ-2026-0001
```

---

## mso export

Export orders, voyages, usage, or ROI data to CSV or JSON.

```
mso export <dataset> [--format csv|json] [--output PATH] [--from YYYY-MM-DD] [--to YYYY-MM-DD]
```

### Datasets

| Dataset | Description |
|---------|-------------|
| `orders` | All completed and failed orders with token usage and cost |
| `voyages` | All voyages with aggregated order counts, tokens, and cost |
| `usage` | Per-order token usage detail (one row per usage file) |
| `roi` | Monthly ROI summary for management reporting |

### Shared flags (all datasets)

| Flag | Type | Default | Description |
|------|------|---------|-------------|
| `--format csv\|json` | string | `csv` | Output format. `csv` for spreadsheets/BI tools; `json` for programmatic use. |
| `--output PATH` | string | stdout | File path for output. If omitted, output goes to stdout. |
| `--from YYYY-MM-DD` | date | *(none)* | Start date filter (inclusive) applied to the primary date field. |
| `--to YYYY-MM-DD` | date | *(none)* | End date filter (inclusive). |

### Dataset: orders

```
mso export orders [--format csv|json] [--output PATH] [--from YYYY-MM-DD] [--to YYYY-MM-DD] [--hours-per-order N]
```

**Additional flag:**

| Flag | Type | Default | Description |
|------|------|---------|-------------|
| `--hours-per-order N` | float | *(per-type)* | Override hours-equivalent for all orders (default: type-based heuristic — FTR=4h, BUG=2h, DOC=2h, DEF=1h, other=3h). |

**Output columns:** `orderId, project, type, role, title, status, startedAt, completedAt, tokensInput, tokensOutput, costUSD, hoursEquivalent`

### Dataset: voyages

```
mso export voyages [--format csv|json] [--output PATH] [--from YYYY-MM-DD] [--to YYYY-MM-DD]
```

**Output columns:** `voyageId, project, title, status, ordersTotal, ordersComplete, ordersStalled, startedAt, completedAt, totalTokens, totalCostUSD, hoursEquivalent`

### Dataset: usage

```
mso export usage [--format csv|json] [--output PATH] [--from YYYY-MM-DD] [--to YYYY-MM-DD]
```

Date filter is applied to the usage timestamp date (`YYYY-MM-DD`).

**Output columns:** `date, orderId, crewNumber, totalTokens, tokensInput, tokensOutput, cacheCreationTokens, cacheReadTokens, costUSD`

### Dataset: roi

```
mso export roi [--hourly-rate RATE] [--format csv|json] [--output PATH] [--from YYYY-MM-DD] [--to YYYY-MM-DD] [--hours-per-order N]
```

**Additional flag:**

| Flag | Type | Default | Description |
|------|------|---------|-------------|
| `--hourly-rate RATE` | float | `150.0` | Developer hourly rate in USD used to calculate value saved. |

**Output columns:** `month, ordersCompleted, apiCostUSD, hoursEquivalent, hoursSaved, valueSavedUSD, roiMultiple`

`roiMultiple` = `valueSavedUSD / apiCostUSD`. Returns `0.0` when `apiCostUSD` is zero.

### Examples

```bash
# Export all orders to CSV
mso export orders --format csv --output orders.csv

# Export orders for a specific date range
mso export orders --from 2026-04-01 --to 2026-04-30 --output april-orders.csv

# Export orders as JSON
mso export orders --format json --output orders.json

# Export all voyages
mso export voyages --format csv --output voyages.csv

# Daily token usage breakdown
mso export usage --format csv --output usage.csv

# ROI summary at $150/hr developer rate
mso export roi --hourly-rate 150 --format csv --output roi-summary.csv

# ROI for a specific month
mso export roi --hourly-rate 150 --from 2026-04-01 --to 2026-04-30 --output roi-april.csv

# Print to stdout (no --output)
mso export roi --hourly-rate 150
```

---

## mso notify

Manage webhook notifications for fleet events.

```
mso notify <subcommand> [options]
```

### Subcommands

| Subcommand | Description |
|-----------|-------------|
| `add` | Add or replace a webhook |
| `list` | List all configured webhooks |
| `test` | Send a test payload to a webhook |
| `remove` | Remove a webhook |

### mso notify add

```
mso notify add --name NAME --url URL [--events EVENT,...]
```

| Flag | Type | Required | Description |
|------|------|----------|-------------|
| `--name NAME` | string | Yes | Unique name for this webhook (e.g. `slack-ops`). |
| `--url URL` | string | Yes | Webhook endpoint URL (HTTPS recommended). |
| `--events EVENT,...` | string | No | Comma-separated list of event names to subscribe to. Omit to subscribe to all events. |

### Available events

| Event | Fires when |
|-------|-----------|
| `order-complete` | A crew completes an order successfully |
| `order-failed` | An order is permanently failed or stalled |
| `crew-crash` | A crew process crashes unexpectedly |
| `voyage-complete` | All orders in a voyage are complete |
| `budget-warning` | API usage reaches 80% of the configured budget |
| `budget-exceeded` | API usage reaches 100% of the configured budget |
| `approval-needed` | A plan or voyage is awaiting captain sign-off |
| `dispatch-complete` | All queues are drained and all crews are idle |

### mso notify list

```
mso notify list
```

Lists all configured webhooks with their names and subscribed events.

### mso notify test

```
mso notify test NAME
```

Sends a synthetic test payload to the named webhook to verify connectivity. The payload event type is `"test"`.

### mso notify remove

```
mso notify remove NAME
```

Removes the named webhook from `.maestro/config/webhooks.json`. Exits with code 1 if no webhook with that name exists.

### Webhook payload format

All payloads share a common envelope:

```json
{
  "event": "voyage-complete",
  "timestamp": "2026-04-01T09:15:00Z",
  "maestroVersion": "2.0.0",
  "data": {
    "voyageId": "VOY-MYPROJ-2026-0001",
    "title": "Sprint 1 features",
    "ordersComplete": 5,
    "totalTokens": 450000,
    "totalCostUSD": 3.20,
    "billingMode": "api",
    "totalDurationMinutes": 87
  }
}
```

For Slack, Teams, and Discord URLs, payloads are automatically adapted to include a human-readable summary line in the platform's native format. Generic webhook URLs receive the raw Maestro JSON payload unchanged.

**Per-event `data` fields:**

| Event | `data` fields |
|-------|--------------|
| `order-complete` | `orderId`, `title`, `role`, `totalTokens`, `estimatedCostUSD`, `billingMode`, `durationMinutes` |
| `order-failed` | `orderId`, `title`, `role`, `reason`, `totalTokens`, `billingMode` |
| `crew-crash` | `crewNumber`, `orderId`, `status`, `lastActivity`, `totalTokens`, `billingMode` |
| `voyage-complete` | `voyageId`, `title`, `ordersComplete`, `totalTokens`, `totalCostUSD`, `billingMode`, `totalDurationMinutes` |
| `budget-warning` | `currentUsage`, `budgetLimit`, `billingMode`, `percentUsed` |
| `budget-exceeded` | `currentUsage`, `budgetLimit`, `billingMode`, `percentUsed` |
| `approval-needed` | `orderId`, `title`, `reason`, `path`, `billingMode` |
| `dispatch-complete` | `ordersComplete`, `ordersFailed`, `totalTokens`, `totalCostUSD`, `billingMode` |

### Configuration file

Webhooks are stored in `.maestro/config/webhooks.json`. The file is created automatically on the first `notify add` call.

```json
{
  "webhooks": [
    {
      "name": "slack-ops",
      "url": "https://hooks.slack.com/services/T.../B.../xxx",
      "events": ["voyage-complete", "crew-crash", "budget-warning"]
    },
    {
      "name": "teams-all",
      "url": "https://yourorg.webhook.office.com/webhookb2/...",
      "events": []
    }
  ]
}
```

An empty `events` list means the webhook subscribes to all events.

### Examples

```bash
# Subscribe to all events
mso notify add --name my-hook --url https://hooks.example.com/abc123

# Slack: voyage completions, crashes, and budget warnings only
mso notify add --name slack-ops \
  --url https://hooks.slack.com/services/T.../B.../xxx \
  --events voyage-complete,crew-crash,budget-warning

# Teams: all events
mso notify add --name teams-all \
  --url https://yourorg.webhook.office.com/webhookb2/...

# List webhooks
mso notify list

# Test a webhook
mso notify test slack-ops

# Remove a webhook
mso notify remove slack-ops
```


## mso backup

Create a ZIP archive of workspace project state, or list available backups.

```
mso backup [--project ACRONYM] [--output PATH] [--list]
```

### Flags

| Flag | Type | Default | Description |
|------|------|---------|-------------|
| `--project ACRONYM` | string | all projects | Only include files for this project acronym (e.g. `OTM`). Files for other projects are excluded. |
| `--output PATH` | string | `./maestro-backups/` | Directory to write the backup archive. Created if it does not exist. |
| `--list` | flag | `false` | List available backups in the output directory instead of creating a new one. |

### What gets backed up

The following `\.maestro/` subdirectories are included:

| Directory | Contents |
|-----------|---------|
| `orders/active/`, `orders/complete/`, `orders/failed/` | All order JSON files |
| `voyages/active/`, `voyages/complete/` | All voyage JSON files |
| `prompts/active/` | Active crew prompt files |
| `plans/` | Navigator planning documents |
| `handoffs/` | Inter-role handoff files |
| `requirements/` | Project requirements |
| `reports/` | Generated reports |
| `usage/orders/` | Token usage records |
| `config/` | `workspace.json`, `projects.json`, per-project configs |

Root workspace files also included: `CLAUDE.md`, `.maestro/BACKLOG.md`, `.maestro/VOYAGE-STATUS.md`.

The following directories are **excluded** (runtime/framework state — not project state):

| Excluded | Reason |
|---------|--------|
| `.maestro/core/` | Framework scripts — provided by pip/submodule |
| `.maestro/hooks/` | Framework hooks |
| `.maestro/crews/` | Ephemeral crew runtime state |
| `.maestro/logs/` | Ephemeral logs |
| `.maestro/temp/` | Temp files |
| `.maestro/queues/` | Regenerated by the dispatcher at runtime |

### Backup file format

Backups are ZIP archives named:

```
maestro-backup-{PROJECT_OR_ALL}-{YYYY-MM-DD-HHMMSS}.zip
```

For example: `maestro-backup-all-2026-03-30-143000.zip` or `maestro-backup-OTM-2026-03-30-143000.zip`.

Every archive contains a `manifest.json` at its root:

```json
{
  "version": 1,
  "created_at": "2026-03-30T14:30:00.000000",
  "workspace": "/path/to/workspace",
  "projects_included": ["OTM"],
  "maestro_version": "2.0.0",
  "file_count": 42
}
```

| Field | Description |
|-------|-------------|
| `version` | Backup format version (currently `1`) |
| `created_at` | ISO 8601 local timestamp |
| `workspace` | Absolute path to the workspace root at backup time |
| `projects_included` | List of project acronyms included (uppercase), or `["ALL"]` for a full backup |
| `maestro_version` | Maestro version that created the archive |
| `file_count` | Number of files in the archive (excluding `manifest.json`) |

### Per-project filtering

When `--project ACRONYM` is passed, only files whose names contain `-{ACRONYM}-` or start with `{ACRONYM}.` are included. Workspace-level files (`workspace.json`, `projects.json`, `CLAUDE.md`, etc.) are always included regardless of filter.

This is designed for multi-project workspaces where you want to extract or share the state of a single project without including others.

### Auto-backup before cleanup

`mso cleanup` automatically creates a full workspace backup before removing stale state. The backup path is printed so you know exactly where the snapshot was saved:

```
[Maestro] Auto-backup created: /workspace/maestro-backups/maestro-backup-all-2026-03-30-143000.zip
```

### Examples

```bash
# Full workspace backup (all projects)
mso backup

# Back up only the OTM project files
mso backup --project OTM

# Write backup to a custom directory
mso backup --output /mnt/backups/maestro/

# Back up OTM project to custom directory
mso backup --project OTM --output /mnt/backups/maestro/

# List available backups
mso backup --list

# List backups in a custom directory
mso backup --list --output /mnt/backups/maestro/
```

### Example --list output

```
[Maestro] Backups in /workspace/maestro-backups/:

  maestro-backup-all-2026-03-30-143000.zip
    Created:   2026-03-30T14:30:00+00:00
    Projects:  all
    Version:   2.0.0
    Files:     87

  maestro-backup-OTM-2026-03-29-090000.zip
    Created:   2026-03-29T09:00:00+00:00
    Projects:  OTM
    Version:   2.0.0
    Files:     34
```

---

## mso restore

Restore workspace project state from a backup archive.

```
mso restore BACKUP_FILE [--project ACRONYM] [--force] [--merge] [--dry-run]
```

### Flags

| Flag | Type | Default | Description |
|------|------|---------|-------------|
| `BACKUP_FILE` | positional | *(required)* | Path to the backup ZIP archive to restore from. |
| `--project ACRONYM` | string | all | Only restore files for this project acronym. Applies the same filename filter as `mso backup --project`. |
| `--force` | flag | `false` | Overwrite existing files unconditionally. |
| `--merge` | flag | `false` | Keep whichever copy has the later modification time. Skips the file if the destination is newer. |
| `--dry-run` | flag | `false` | Print what would be written without writing anything. |

### Conflict resolution

When a file from the archive already exists at the destination, the behaviour depends on the flags used:

| Mode | Flag | Behaviour |
|------|------|-----------|
| **Skip** | *(default, no flags)* | Leave the existing file untouched. Print `[SKIP] <file>`. |
| **Force** | `--force` | Overwrite the existing file unconditionally. |
| **Merge** | `--merge` | Compare modification times. Keep whichever copy is newer. Skip if the destination file is newer. |
| **Dry run** | `--dry-run` | Show the action for each file without writing anything. Summary line is prefixed `[DRY RUN]`. |

**Use-case guidance:**

- **Default (skip):** Safe for adding files from an older backup without touching anything already in place. Use when restoring into an active workspace where some state is current.
- **`--force`:** Use when restoring a clean snapshot to a fresh workspace, or when you want the backup to fully replace current state.
- **`--merge`:** Use when merging state from two separate workspaces (e.g. transferring project state to a new machine while keeping locally-modified orders).
- **`--dry-run`:** Always run `--dry-run` first when restoring into a workspace with active work to preview exactly what would change.

### Examples

```bash
# Restore from a backup (skip existing files by default)
mso restore maestro-backup-all-2026-03-30-143000.zip

# Preview what would be restored without writing anything
mso restore maestro-backup-all-2026-03-30-143000.zip --dry-run

# Restore only OTM project files from a full backup
mso restore maestro-backup-all-2026-03-30-143000.zip --project OTM

# Overwrite existing files unconditionally
mso restore maestro-backup-all-2026-03-30-143000.zip --force

# Keep the newer file when conflicts occur
mso restore maestro-backup-all-2026-03-30-143000.zip --merge

# Full path to archive
mso restore /mnt/backups/maestro/maestro-backup-OTM-2026-03-29-090000.zip --project OTM
```

### Example output

```
[Maestro] Restoring from: maestro-backup-all-2026-03-30-143000.zip
  Backup created: 2026-03-30T14:30:00+00:00
  Projects: all
  Maestro version: 2.0.0
  Files in archive: 87

[Maestro] Restore complete — extracted: 85, overwritten: 0, skipped: 2
```

---

## mso init

Scaffold a new Maestro workspace.

```
mso init --project ACRONYM [--directory PATH] [--force]
```

### Flags

| Flag | Type | Required | Default | Description |
|------|------|----------|---------|-------------|
| `--project ACRONYM` | string | Yes | — | Project acronym (2–8 uppercase letters, e.g. `OTM`, `MYPROJ`). |
| `--directory PATH` | string | No | current directory | Target directory for the workspace. Created if it does not exist. |
| `--force` | flag | No | `false` | Overwrite an existing `\.maestro/` directory. Without this flag, init will not run if `\.maestro/` already exists. |

### Examples

```bash
# Scaffold in the current directory
mso init --project MYPROJ

# Scaffold in a specific directory
mso init --project MYPROJ --directory /path/to/my-workspace

# Re-scaffold (overwrite existing config)
mso init --project MYPROJ --force
```

### What init creates

| Path | Purpose |
|------|---------|
| `.maestro/config/workspace.json` | Workspace-level settings |
| `.maestro/config/projects.json` | Project registry |
| `.maestro/config/projects/MYPROJ.json` | Per-project role path configuration |
| `.maestro/orders/active/`, `complete/`, `failed/` | Order lifecycle directories |
| `.maestro/voyages/active/`, `complete/` | Voyage lifecycle directories |
| `.maestro/queues/orders/` and other queue tiers | Dispatch queues |
| `.maestro/crews/crew1/` through `crew5/` | Per-crew working directories |
| `.maestro/plans/`, `.maestro/handoffs/` | Navigator artifacts |
| `CLAUDE.md` | Quartermaster configuration |
| `.gitignore` | Standard exclusions for crew runtime files |

---

## mso setup

Run the interactive setup wizard, or perform a headless prerequisite check.

```
mso setup [--check]
```

The setup wizard runs three phases:

1. **Prerequisites** — Python version, Claude Code CLI, `ANTHROPIC_API_KEY`, Git, network reachability
2. **Project analysis** — scans the registered project for language, structure, CI config, and existing tooling
3. **Tailored suggestions** — prints recommended starting requirements and voyages based on your project

`setup` bypasses the standard auth check so new users can run it before activating a licence.

### Flags

| Flag | Type | Default | Description |
|------|------|---------|-------------|
| `--check` | flag | `false` | Run Phase 1 only. Exits `0` if all checks pass, `1` if any fail. No interactive output. |

### Examples

```bash
# Full interactive wizard
mso setup

# Headless prerequisite check (CI/CD, scripting)
mso setup --check
```

### Phase 1 — Prerequisite checks

| Check | Pass condition |
|-------|---------------|
| Python | 3.9 or later |
| Claude Code | `claude` on PATH and responds to `--version` |
| API key | `ANTHROPIC_API_KEY` set and non-empty |
| Git | `git` on PATH |
| Network | Can reach `api.anthropic.com` (optional — warns if offline) |

---

## mso create-order

Create a new order JSON file and write it to the dispatch queue.

```
mso create-order [--interactive | --template NAME] [flags]
```

### Modes (mutually exclusive, checked in order)

| Mode | Flag | Behaviour |
|------|------|-----------|
| Interactive | `--interactive` | Prompts for each field in turn |
| Template | `--template NAME` | Loads template defaults, then applies any provided flags |
| Flags only | *(none)* | All required fields must be provided via flags |

### Flags

| Flag | Type | Required | Description |
|------|------|----------|-------------|
| `--interactive` | flag | No | Launch interactive prompt mode |
| `--template NAME` | string | No | Use a built-in template (`feature`, `bugfix`, `docs`, `security`) |
| `--project ACRONYM` | string | Yes* | Project acronym (e.g. `MYPROJ`) |
| `--title TEXT` | string | Yes* | Short order title |
| `--type TYPE` | string | No | Order type: `FTR`, `BUG`, `DOC`, `SEC`, `DEF`, `TSK` |
| `--role ROLE` | string | No | Crew role: `NAV`, `SHP`, `BOS`, `SCR`, `LKT`, `COX` |
| `--description TEXT` | string | No | Full order description |
| `--acceptance TEXT` | string (repeatable) | No | Acceptance criterion (repeat for multiple) |
| `--depends-on ORDER-ID` | string (repeatable) | No | Prerequisite order ID |
| `--voyage VOY-ID` | string | No | Assign to an existing voyage |

*Required unless `--interactive` is used.

### Built-in templates

| Template | Type | Role | Use for |
|----------|------|------|---------|
| `feature` | `FTR` | `SHP` | New feature implementation |
| `bugfix` | `BUG` | `SHP` | Bug investigation and fix |
| `docs` | `DOC` | `SCR` | Documentation creation or update |
| `security` | `SEC` | `LKT` | Security audit |

### Examples

```bash
# Interactive
mso create-order --interactive

# From template with title override
mso create-order --template feature --project MYPROJ --title "Add JWT auth"

# Full flags
mso create-order \
  --project MYPROJ \
  --type FTR \
  --role SHP \
  --title "Add JWT auth" \
  --description "Implement POST /auth/login and POST /auth/register." \
  --acceptance "Returns 200 with JWT on valid credentials" \
  --acceptance "Returns 401 on invalid credentials"
```

### Output

```
[Maestro] Order created: FTR-MYPROJ-2026-0001
  Written to: .maestro/queues/orders/FTR-MYPROJ-2026-0001.json
```

---

## mso create-voyage

Create a new voyage JSON file in `.maestro/voyages/active/`.

```
mso create-voyage [--interactive] [flags]
```

### Flags

| Flag | Type | Required | Description |
|------|------|----------|-------------|
| `--interactive` | flag | No | Launch interactive prompt mode |
| `--project ACRONYM` | string | Yes* | Project acronym |
| `--title TEXT` | string | Yes* | Short voyage title |
| `--orders ORDER-ID` | string (repeatable) | No | Order IDs to include in this voyage |
| `--branch BRANCH` | string | No | Branch name. Defaults to `voyage/{voyageId}` |
| `--requirement-id REQ-ID` | string | No | Link this voyage to a requirement |

*Required unless `--interactive` is used.

### Examples

```bash
# Interactive
mso create-voyage --interactive

# From flags
mso create-voyage \
  --project MYPROJ \
  --title "Auth sprint" \
  --orders FTR-MYPROJ-2026-0001 \
  --orders DOC-MYPROJ-2026-0002
```

### Output

```
[Maestro] Voyage created: VOY-MYPROJ-2026-0001
  Written to: .maestro/voyages/active/VOY-MYPROJ-2026-0001.json
  Orders: FTR-MYPROJ-2026-0001, DOC-MYPROJ-2026-0002
```

---

## mso diagnose

Inspect workspace health and print a diagnostic report.

```
mso diagnose
```

`diagnose` is read-only and makes no changes. It bypasses the standard auth check so it can be used to debug setup problems before authentication is configured.

### What diagnose checks

| Area | Checks |
|------|--------|
| **Workspace** | `\.maestro/` directory present, `workspace.json` valid JSON |
| **Projects** | `projects.json` present, at least one project registered, per-project configs found |
| **Queues** | Each queue directory present, count of files in each |
| **Crews** | `crew1/` through `crew5/` present; stale lock files or orphaned PIDs flagged |
| **Auth** | `ANTHROPIC_API_KEY` set; licence status (trial / licence key / GitHub) |
| **Claude Code** | `claude` on PATH and version detected |
| **Python** | Version check |

### Example output

```
[Maestro] Workspace diagnostic

  Workspace:   /path/to/my-workspace/.mso   OK
  Projects:    MYPROJ                              OK
  Queues:      orders=2  bugs=0  security=0        OK
  Crews:       5 slots configured, 0 active        OK
  Auth:        Trial mode (11 days remaining)      OK
  Claude Code: v1.2.3                              OK
  Python:      3.11.4                              OK

  No issues found.
```

When problems are found, each failed check prints a short fix suggestion below the table.

### Flags

None.

### Examples

```bash
mso diagnose
```

---

## mso requirement

Manage the requirement (PRD) lifecycle.

```
mso requirement <subcommand> [flags]
```

Requirements are the recommended entry point to Maestro — describe what needs to happen, and a Navigator crew handles planning and order creation.

**Lifecycle:**

```
create → AWAITING_APPROVAL → approve → APPROVED → plan (Navigator crew)
→ PLANNING → PLANNED → approve plan → IN_PROGRESS → COMPLETE
```

### Subcommands

| Subcommand | Description |
|-----------|-------------|
| `create` | Create a new requirement file |
| `list` | List all requirements and their status |
| `show REQ-ID` | Display a specific requirement |
| `edit REQ-ID` | Update fields on an existing requirement |
| `plan REQ-ID` | Queue a Navigator crew to plan the requirement |
| `status REQ-ID` | Print the current status of a requirement |

---

### mso requirement create

```
mso requirement create [--interactive | --template NAME] [flags]
```

#### Flags

| Flag | Type | Required | Description |
|------|------|----------|-------------|
| `--interactive` | flag | No | Prompt for all fields interactively |
| `--template NAME` | string | No | Use a built-in requirement template |
| `--project ACRONYM` | string | Yes* | Project acronym |
| `--title TEXT` | string | Yes* | Short requirement title |
| `--type TYPE` | string | No | Type: `feature`, `bug`, `security`, `docs`, `performance`, `refactor`, `task` |
| `--priority LEVEL` | string | No | Priority: `critical`, `high`, `medium`, `low` |
| `--description TEXT` | string | No | Full requirement description (appended to template body if both provided) |

*Required unless `--interactive` is used.

#### Built-in templates

| Template | Type | Priority | Use for |
|----------|------|----------|---------|
| `new-feature` | `feature` | `medium` | New feature implementation |
| `project-setup` | `feature` | `high` | CI/CD, linting, baseline project structure |
| `security-review` | `security` | `high` | Security audit |
| `test-coverage` | `task` | `medium` | Increase test coverage |
| `doc-audit` | `docs` | `low` | Documentation review and update |
| `bug-report` | `bug` | `high` | Bug investigation |
| `performance` | `performance` | `medium` | Performance profiling and optimisation |
| `refactor` | `refactor` | `low` | Code quality and restructuring |

#### Examples

```bash
# Interactive
mso requirement create --interactive

# From template
mso requirement create --project MYPROJ --template new-feature --title "Add JWT auth"

# Direct flags
mso requirement create \
  --project MYPROJ \
  --title "Add JWT auth" \
  --type feature \
  --priority high
```

#### Output

```
[Maestro] Requirement created: REQ-MYPROJ-2026-0001
  Written to: .maestro/requirements/REQ-MYPROJ-2026-0001.md
  Status:     AWAITING_APPROVAL

  Next step: mso approve --requirement .maestro/requirements/REQ-MYPROJ-2026-0001.md
```

---

### mso requirement list

```
mso requirement list [--project ACRONYM] [--status STATUS]
```

#### Flags

| Flag | Type | Description |
|------|------|-------------|
| `--project ACRONYM` | string | Filter by project |
| `--status STATUS` | string | Filter by status (e.g. `AWAITING_APPROVAL`, `APPROVED`, `PLANNED`) |

#### Example output

```
[Maestro] Requirements

  REQ-MYPROJ-2026-0001  AWAITING_APPROVAL  Add JWT auth
  REQ-MYPROJ-2026-0002  PLANNED            Improve test coverage
  REQ-MYPROJ-2026-0003  IN_PROGRESS        Security audit of auth module
```

---

### mso requirement show

```
mso requirement show REQ-ID
```

Prints the full requirement file (frontmatter + body) to stdout.

#### Example

```bash
mso requirement show REQ-MYPROJ-2026-0001
```

---

### mso requirement plan

```
mso requirement plan REQ-ID
```

Queues a Navigator order to plan the requirement. The Navigator crew will produce a voyage plan and submit it for Captain approval. Requires the requirement to have status `APPROVED`.

#### Example

```bash
mso requirement plan REQ-MYPROJ-2026-0001
# Creates: .maestro/queues/orders/NAV-REQ-MYPROJ-2026-0001.json
# Run: mso dispatch to execute the Navigator crew
```

---

### mso requirement status

```
mso requirement status REQ-ID
```

Print the current status of a requirement and any linked voyage or plan.

#### Example output

```
[Maestro] REQ-MYPROJ-2026-0001
  Title:    Add JWT auth
  Status:   PLANNED
  Voyage:   VOY-MYPROJ-2026-0001 (ACTIVE)
  Plan:     .maestro/plans/NAV-REQ-MYPROJ-2026-0001.md
  Orders:   3 total (1 COMPLETE, 2 QUEUED)
```

---

## mso licence

Manage the Maestro licence key for this machine.

```
mso licence <subcommand> [KEY]
```

### Subcommands

| Subcommand | Description |
|-----------|-------------|
| `activate <KEY>` | Parse, validate, and save a licence key to `~/.maestro/licence.json`. |
| `status` | Show current licence mode: licence key, GitHub collaborator, or trial. |
| `deactivate` | Remove the stored licence key and free this machine's seat. |

This command is always available regardless of licence state — including after trial expiry.

### mso licence activate

```bash
mso licence activate ADM-TEAM-a1b2c3d4-20270331-x9y8z7
```

Validates the key format and HMAC checksum locally (no server call). On success, saves the key to `~/.maestro/licence.json`. For Team and Enterprise keys, registers this machine as a seat.

**Output (Team tier):**

```
[Maestro] Licence activated.
  Tier:         Team
  Expires:      2027-03-31 (365 days)
  Max crews:    5
  Max projects: Unlimited
  Features:     dispatch, status, usage, backup, estimate, approve, roi-reporting, priority-support
  Seat:         Registered (machine: abc123def456)
```

### mso licence status

```bash
mso licence status
```

**Output (licence key active — Team tier):**

```
[Maestro Licence]
  Mode:           Licence key
  Tier:           Team
  Expires:        2027-03-31 (365 days)
  Max crews:      5
  Max projects:   Unlimited
  Features:       dispatch, status, usage, backup, estimate, approve, roi-reporting, priority-support
  Seat:           Registered (machine: abc123def456, since 2026-04-01)
  Last validated: 2026-04-01
```

**Output (Enterprise tier):** Includes an additional SSO line:

```
  SSO:            Placeholder (contact maestro@tech127.com to configure)
```

**Output (GitHub collaborator):**

```
[Maestro Licence]
  Mode:    GitHub collaborator
  User:    tavisbasing
  Access:  Contributor (unlimited)
  Note:    Licence key recommended for commercial use
```

**Output (trial mode):**

```
[Maestro Trial]
  Days remaining: 11/14
  Max crews:      3
  Max projects:   1
  To upgrade:     https://maestroai.com/pricing
```

### mso licence deactivate

```bash
mso licence deactivate
```

Removes `~/.maestro/licence.json`. The machine will fall back to trial mode (or GitHub auth) on the next command.

**Output:**

```
[Maestro] Licence deactivated. Seat freed.
Machine will enter trial mode (or GitHub auth) on next command.
```

### Key format

Licence keys follow the format:

```
ADM-{TIER}-{ORG_HASH}-{EXPIRY}-{CHECKSUM}
```

| Component | Description |
|-----------|-------------|
| `TIER` | `TRIAL`, `SOLO`, `TEAM`, or `ENT` |
| `ORG_HASH` | 8 hex characters (organisation identifier, or `00000000` for Solo) |
| `EXPIRY` | `YYYYMMDD` — key expiry date |
| `CHECKSUM` | 6 alphanumeric characters (HMAC-SHA256 local validation) |

Example: `ADM-TEAM-a1b2c3d4-20270331-x9y8z7`

Validation is performed locally using an embedded HMAC — no network call is required.

---

## mso version

Print the installed Maestro version.

```
mso version
```

### Example

```bash
mso version
# Maestro Maestro v2.0.0
```

---

## Exit Codes

| Code | Meaning |
|------|---------|
| `0` | Success |
| `1` | General error (configuration missing, invalid arguments, etc.) |
| `2` | Dispatch failed — no orders found or all orders blocked by dependencies |

---

## Environment Variables

These variables are injected by the Fleet Admiral into crew subprocesses. They are documented here for reference when debugging.

| Variable | Description |
|----------|-------------|
| `ANTHROPIC_API_KEY` | Required. Your Anthropic API key. Set in your shell profile. |
| `MAESTRO_LICENCE_KEY` | Licence key override. When set, takes precedence over `~/.maestro/licence.json`. Suitable for CI/CD deployments. |
| `MAESTRO_CREW` | Crew number (1–5). Activates hook behaviour. Must not be set in interactive sessions. |
| `MAESTRO_ORDER` | Current order ID. |
| `MAESTRO_PROJECT` | Project acronym (e.g. `MYPROJ`, `ADM`). |
| `MAESTRO_REPO_PATH` | Managed repo clone path — the crew's working directory. |
| `MAESTRO_TEMP` | Centralized temp directory for crew-generated artifacts. |
| `MAESTRO_VOYAGE_BRANCH` | Voyage branch name used when committing crew output. |
| `MAESTRO_MAX_ITERATIONS` | Maximum stop-hook iterations before a crew is forcefully completed. Default: `25`. |
| `MAESTRO_COMPLETION_PROMISE` | Promise tag pattern the crew uses to signal task completion. |

---

*Maestro Maestro v2.0.0 — For licensing enquiries, contact [tavisbasing](https://github.com/tavisbasing).*
