# Model backends — direct Anthropic or AWS Bedrock

**New in v5.15.0.** Every crew Maestro launches is a Claude Code session, and
that session talks to a **model backend**. Until now there was exactly one: the
direct Anthropic API. A workspace can now be configured to run its crews
against **AWS Bedrock** instead — including through the Bedrock Mantle
endpoint — without changing a single order, plan, role overlay or usage record.

The backend is a property of the **workspace**, not of your machine and not of
your terminal. Two projects on one laptop can run on different backends, which
is the point: a client's work runs on their AWS account, your own work does
not.

| Backend | `providers.model` id | Licence tier | What it is |
|---------|----------------------|--------------|------------|
| Direct Anthropic API | `anthropic` | any (including unlicensed) | The shipped default and what every workspace has always used. |
| AWS Bedrock | `bedrock` | Enterprise | Claude served through your own AWS account, billed by AWS. |

**Omitting the `providers.model` block entirely is identical to `anthropic`.**
A workspace that never configures a backend behaves exactly as it did before
this feature existed — same crew command line, same environment, same usage
records, same cost figures. Nothing about the default path changed.

**One Claude backend, plus optionally one open-weights endpoint.** Beside the
Claude backend above, a workspace may also configure an endpoint that serves an
open-weights model (such as Muse Glimmer through Ollama) under its own key,
`providers.local_model`. The model id picks which one a crew uses. See
[One Claude backend plus one open-weights endpoint](#one-claude-backend-plus-one-open-weights-endpoint).

---

## Contents

1. [Which backend am I on?](#which-backend-am-i-on)
2. [Setting up AWS Bedrock](#setting-up-aws-bedrock)
3. [Signing in to AWS — and what happens when the session expires](#signing-in-to-aws--and-what-happens-when-the-session-expires)
4. [`ccb` / `cca` and why Maestro does not use them](#ccb--cca-and-why-maestro-does-not-use-them)
5. [Configuration reference](#configuration-reference)
6. [Model ids and how they are translated](#model-ids-and-how-they-are-translated)
7. [The Mantle endpoint](#the-mantle-endpoint)
8. [Gateway and proxy headers (`crew.customHeaders`)](#gateway-and-proxy-headers-crewcustomheaders)
9. [What is different on Bedrock](#what-is-different-on-bedrock)
10. [Credentials](#credentials)
11. [Troubleshooting](#troubleshooting)
12. [One Claude backend plus one open-weights endpoint](#one-claude-backend-plus-one-open-weights-endpoint)

---

## Which backend am I on?

```bash
mso providers show model     # the configured entry + what it resolves to, with availability
mso providers test model     # resolve it right now — tier, available, reason
mso providers list           # every capability kind, including model
```

Each crew's own launch line names it too. On the default backend the `Model:`
line in the dispatcher log is unchanged; on any other backend it gains the
backend, the backend-native model id it was translated to, and the resolved
region with its provenance:

```
Model: claude-opus-5 | context: standard | effort: medium (role=PLN) | backend: bedrock | native: au.anthropic.claude-opus-5 | region: ap-southeast-2 (config)
```

---

## Setting up AWS Bedrock

### Before you start

- An **Enterprise licence** (`mso licence status`). Bedrock is Enterprise-gated;
  at every other tier the backend step reports that and offers nothing.
- An AWS account with **Bedrock model access already granted** for the Claude
  models your roles are pinned to. Maestro does not request model access for
  you, and which inference profiles your account carries is an AWS-side
  question — check it in the Bedrock console before assuming a model is
  reachable.
- The **AWS CLI** (optional but recommended). Maestro uses it only to *check*
  your credentials, never to create them. Without it, credential state is
  reported as undeterminable rather than broken — see
  [Troubleshooting](#troubleshooting).

### The guided way — `mso setup`

```bash
mso setup
```

`[STEP 2b] Model backend` offers three choices:

```
  1) Direct Anthropic API — the shipped default
  2) AWS Bedrock
  3) AWS Bedrock via Mantle
```

Choosing a Bedrock option then asks, in order:

| Prompt | Notes |
|--------|-------|
| **AWS region** | Always asked, always written — including when you accept the default. The prompt names where the default came from (`workspace.json`, `AWS_REGION`, a named profile in `~/.aws/config`, or the shipped fallback). |
| **Inference-profile prefix** | Not a free-text prompt — the resolved prefix is printed, and you are asked whether to switch to the global profile only when the resolved one is known to serve fewer models (see the note below). |
| **AWS profile name** | A **profile name**, never a credential. Blank means "use the default AWS credential chain". A pasted access key id is refused with an explanation, and you are re-asked (up to three attempts). |
| **Pin the per-role model defaults** | Default yes. Pins `ANTHROPIC_DEFAULT_*_MODEL` to their Bedrock ids so an unpinned request can never reach for a model this backend does not serve. |
| **Model id overrides** | Optional `canonical=native` pairs, comma-separated. Blank for none. |

**Expect six questions, not five, if you accept every default.** The shipped
fallback region is `ap-southeast-2`, which resolves to the `au.` (Australia)
inference profile, and not every Claude model is served there — so the wizard
prints a caveat and offers you the global inference profile instead. That extra
question is correct behaviour, not a misconfiguration. It defaults to **no**:
`au.` keeps inference inside Australia, and `global.` does not (see
[data residency](#the-inference-profile-prefix)).

The wizard then **probes your credentials before writing anything**, and tells
you which of three answers it got: usable, positively unusable, or
undeterminable. Only a positively unusable result defaults the "write anyway?"
question to no.

Accepting the backend you are already on writes nothing at all — re-running
`mso setup` on a settled workspace leaves `workspace.json` byte-identical.

### The direct way — `mso providers set`

```bash
mso providers set model bedrock \
  --config region=ap-southeast-2 \
  --config awsProfile=corp

mso providers show model          # read it back, with availability
mso providers unset model         # revert to the direct Anthropic API
```

This is the same single write path the wizard and the Maestro Hub use
(`maestro/providers/config.py`) — there is no second way to write the block, so
a change made in one place is visible in all of them.

### `mso init` scaffolds it; `mso update` does not backfill it

A workspace created by `mso init` gets the block already present, at its
default:

```jsonc
{
  "providers": {
    "model": { "id": "anthropic", "config": {} }
  }
}
```

That block resolves identically to an absent one — it is there to be
discoverable and directly editable, since JSON cannot carry a comment.

**Existing workspaces do not acquire the block on upgrade.** `mso update` leaves
them alone, and they keep resolving to the direct Anthropic API exactly as
before. Nothing needs to be done to a workspace that is staying on the default.

---

## Signing in to AWS — and what happens when the session expires

**Maestro never signs you in.** You sign in; Maestro uses the credentials your
AWS credential chain then provides.

```bash
aws sso login --profile <name>     # or `aws login` for Management Console credentials
# -> a browser opens
# -> you authenticate
# -> the session is TIME-BOXED and will need repeating when it expires
```

That is the whole login sequence, and it is a human-at-a-browser activity by
construction. Maestro will not run it for you, and this is a deliberate design
decision rather than a missing feature: a crew is a detached background process
with no window, so there is nobody present to click the link. Attempting it
produces an authentication loop that looks like a hang. What Maestro does
instead is **detect the expiry, hold, and tell you.**

### When the session expires mid-voyage

The dispatcher checks the backend on every tick. When the check comes back
**positively unavailable** — an expired SSO session is the common case:

- `MODEL_BACKEND_UNAVAILABLE` is written to `.mso/logs/lifecycle.log`, **once**,
  naming the backend, the reason in plain words, and the exact command to run
  (typically `aws sso login --profile <name>`).
- **New crews stop being launched.** Crews that are already running are not
  touched, killed or interrupted — they drain normally.
- If a crew launch had already begun and failed for this reason, its order goes
  back to `PENDING` **without spending a retry attempt**, so an order can never
  be archived `STALLED` because of a machine-level fault that no retry of that
  order could ever fix.
- `mso status` shows the hold, and so does the Maestro Hub. Both keep showing
  it **after the dispatcher exits**, because an expired session outlives the
  process that noticed it.

### When you sign back in

Run the login command. On the next tick whose check is fresh and passing:

- `MODEL_BACKEND_RESTORED` is written, once;
- the hold lifts **on that same tick** — no dispatcher restart, no `mso cleanup`,
  no `mso order retry`;
- crews start launching again.

**The honest bound: within 60 seconds, not instantly.** The credential check
shells out to AWS and is cached for 60 seconds, so the hold lifts on the first
tick after the cache refreshes. The lifecycle message says so itself. If you
want it sooner, restarting the dispatcher re-checks immediately — but waiting is
the normal answer.

### The third answer: "could not determine"

If Maestro cannot determine your credential state — the AWS CLI is not on
`PATH`, the check timed out, the machine authenticates by instance role — that
is **not** treated as failure:

- it **never holds** dispatch (otherwise a machine with no AWS CLI could never
  dispatch at all); and
- it **never clears** an existing hold either, because nothing has been proven
  restored. `MODEL_BACKEND_RESTORED` still fires later, on the first check that
  genuinely passes.

Both halves matter. A hold is only ever raised on positive evidence of failure,
and only ever lifted on positive evidence of recovery.

---

## `ccb` / `cca` and why Maestro does not use them

If you run Claude Code interactively against Bedrock, you may have shell aliases
— often called something like `ccb` and `cca` — that export the Bedrock
environment variables and then launch Claude. **Those aliases remain exactly as
useful as they were for your own terminal sessions.** Nothing here replaces or
interferes with them.

They are not, however, how Maestro configures crews, and they cannot be:

- a crew is a **detached subprocess** of the `claude` binary, not an interactive
  shell;
- it runs **no shell profile** — no `.bashrc`, no PowerShell profile — so there
  is no shell in which an alias could run;
- an alias is per-terminal state, which is precisely the state a background
  fleet does not have.

Maestro composes the backend environment itself, per workspace, from the
`providers.model` block, and injects it into every crew process it launches.
That is strictly better than an alias for this purpose: it is per-project rather
than per-terminal, it is recorded in configuration rather than in a dotfile, it
is visible to `mso providers show model`, and it cannot be forgotten.

**Precedence, so it is never a surprise:** the workspace's configured overlay is
applied *after* the dispatcher's own environment is copied, so a value set by
the workspace **wins** over the same variable exported in the shell you started
the dispatcher from. Configuration beats ambience, deliberately — otherwise a
stale exported variable could silently redirect a configured fleet.

---

## Configuration reference

Every key below lives under `providers.model.bedrock.config`. All are optional.

| Config key | Default | Purpose |
|------------|---------|---------|
| `endpoint` | `invoke` | `invoke` (the Bedrock InvokeModel path), `mantle` (the Messages-API endpoint), or `both`. An unrecognised value falls back to `invoke`. |
| `region` | `ap-southeast-2` | The AWS region. Resolution order: this key → `AWS_REGION` → `AWS_DEFAULT_REGION` → the named profile's `region` in `~/.aws/config` → the default. |
| `regionPrefix` | derived from `region` | Pin the inference-profile prefix explicitly. Accepts `global` or `global.` — both spellings work. |
| `awsProfile` | *(unset)* | A **profile name** from `~/.aws/config`. Unset means the default AWS credential chain. Never a credential. |
| `pinRoleDefaults` | `true` | Pin `ANTHROPIC_DEFAULT_OPUS_MODEL` / `..._SONNET_MODEL` / `..._HAIKU_MODEL` to their backend-native ids, so an unpinned request can never resolve to a model this backend does not serve. The Haiku slot is pinned to Haiku 4.5, not Haiku 5.5 — see [the shipped translation table](#the-shipped-translation-table). |
| `modelMap` | shipped table | Per-model id overrides for the `invoke` endpoint. See [below](#model-ids-and-how-they-are-translated). |
| `mantleModelMap` | shipped table | The same, for the `mantle` endpoint. |
| `baseUrl` | *(unset)* | Override the Bedrock endpoint URL. Subject to your workspace's egress allowlist. |
| `mantleBaseUrl` | *(unset)* | The Mantle endpoint URL. Also subject to the egress allowlist. |
| `serviceTier` | *(unset)* | Passed through to Bedrock as the service tier. |
| `mantleSkipSignin` | `false` | Skip the Mantle sign-in step. Only set this if your Mantle deployment documents that you should. |
| `pricingOverrides` | *(unset)* | Your negotiated rates, per model. See [Cost](#cost-is-reported-honestly-or-not-at-all). |

Request headers for a gateway or proxy in front of the API are **not** a backend
key. They are the workspace setting `crew.customHeaders`, which applies on every
Claude backend; see
[Gateway and proxy headers](#gateway-and-proxy-headers-crewcustomheaders).

### The inference-profile prefix

Bedrock's InvokeModel ids carry a region-partition prefix, which Maestro derives
from your region:

| Region starts with | Prefix |
|--------------------|--------|
| `us-gov-` | `us-gov.` |
| `us-` | `us.` |
| `eu-` | `eu.` |
| `ap-southeast-2` (Sydney), `ap-southeast-4` (Melbourne) | `au.` |
| `ap-northeast-1` (Tokyo), `ap-northeast-3` (Osaka) | `jp.` |
| any other `ap-` | `apac.` |
| anything else | `global.` |

Longest match wins, so a GovCloud region is never routed to the commercial
partition, and an Australian or Japanese region is never routed to `apac.` —
which carries only older Claude models, so current models would be refused
there with `model_not_found`. Set `regionPrefix` to override the derivation —
`global` is the usual reason, because the global inference profile serves models
some regional profiles do not.

**Data residency.** A geographic profile (`au.`, `jp.`, `eu.`, `us.`, `apac.`)
routes inference only between regions inside that geography — `au.` keeps your
traffic in Australia. `global.` routes it to any commercial region worldwide. If
residency matters to you, prefer mapping the one model your geographic profile
lacks over switching the whole workspace to `global`.

Which models a profile serves is a fact about **your account**, not about this
table. List them with
`aws bedrock list-inference-profiles --region <your region>` before you map one.

### Both config shapes work

`mso providers set --config` can only produce flat, string-valued keys, so the
nested and flat spellings of a map are both accepted and merged, with the flat
one winning for the same model:

```bash
# flat (what the CLI produces)
mso providers set model bedrock --config modelMap.claude-opus-5=anthropic.claude-opus-5
```

```jsonc
// nested (what a hand-edit, mso setup or the Hub produces)
{ "modelMap": { "claude-opus-5": "anthropic.claude-opus-5" } }
```

---

## Model ids and how they are translated

**Maestro's own model ids never change, on any backend.** `claude-opus-5` is
what you write in an order's `model` field, in `.mso/config/role-models.json`, in
a role overlay, and what appears in usage records, `mso status`, the Hub and
your plans. The backend-native id exists only on the crew's `--model` argument
and in the dispatcher's log line.

That is what makes an order portable: the same order JSON dispatches on a
Bedrock workspace and on a direct-API workspace, unedited.

### The shipped translation table

For the `invoke` endpoint, before the region prefix is applied:

| Model | Maestro id | Bedrock id |
|-------|-----------|------------|
| Opus 5.5 | `claude-opus-5-5` | `anthropic.claude-opus-5-5` |
| Opus 5 | `claude-opus-5` | `anthropic.claude-opus-5` |
| Sonnet 5.5 | `claude-sonnet-5-5` | `anthropic.claude-sonnet-5-5` |
| Sonnet 5 | `claude-sonnet-5` | `anthropic.claude-sonnet-5` |
| Haiku 5.5 | `claude-haiku-5-5` | `anthropic.claude-haiku-5-5` |
| Haiku 4.5 | `claude-haiku-4-5` | `anthropic.claude-haiku-4-5-20251001-v1:0` |
| Fable 5.1 | `claude-fable-5-1` | *not shipped — map it explicitly* |

The resolved prefix is prepended, so on `ap-southeast-2` an Opus 5 crew launches
against `au.anthropic.claude-opus-5`.

Two things in that table are worth reading twice. The Haiku 4.5 entry carries a date
*and* a version suffix while the others — Haiku 5.5 included — carry neither — the shapes genuinely
differ, which is why the table is explicit rather than a rule. And **Fable 5.1
is deliberately absent**: its availability on Bedrock varies by account and
endpoint, and shipping a guess would be worse than shipping a refusal, because a
wrong-but-present mapping fails silently while a refusal names the exact key to
set.

**Sonnet 5.5 is mapped on the same basis as the rest of the table, not by
analogy with Sonnet 5**: `anthropic.claude-sonnet-5-5` is published on the
per-model "Amazon Bedrock ID" row, repeated in the Sonnet 5.5 model page's own
Model-IDs table, and named on the `InvokeModel` page among the ids that are
reachable but not ARN-versioned (which is why it is suffix-free). Checked
2026-10-07. That is exactly the bar the Fable 5.1 and Opus 5.5 notes below set —
the table and the prose agree.

**Haiku 5.5 is mapped the same way, on both endpoints.** `anthropic.claude-haiku-5-5`
is published on the per-model "Amazon Bedrock ID" row (which is also the Mantle
id), repeated in the Haiku 5.5 model page's Model-IDs table, and named on the
`InvokeModel` page among the reachable-but-not-ARN-versioned ids. So the
`invoke` value and the `mantle` value are the same suffix-free id — do **not**
copy Haiku 4.5's dated, versioned shape onto it. Checked 2026-10-19. Three
things differ from Haiku 4.5 on Bedrock, and you should know them before you pin
it:

- **Access is per account.** Bedrock lists Haiku 5.5's access as "See Access" —
  per-model criteria — where Haiku 4.5 is "Open" to every Bedrock customer. The
  shipped mapping does not grant access; if your account lacks it, Bedrock
  rejects the launch (see [Troubleshooting](#troubleshooting)).
- **Structured outputs are not available for Haiku 5.5 on Bedrock.** This only
  matters to your own tooling that requests them.
- **The `ANTHROPIC_DEFAULT_HAIKU_MODEL` slot stays on Haiku 4.5** — with
  `pinRoleDefaults` on, Maestro pins Claude Code's Haiku slot — which Claude Code
  uses for its own background calls on every crew — to Haiku 4.5's native id, not
  Haiku 5.5's. Haiku 4.5 is open to every Bedrock account; moving the slot would
  break crews on any account that has not been granted Haiku 5.5. Pinning a role
  to `claude-haiku-5-5` is unaffected: the role's `--model` is translated through
  the table above as usual.

Haiku 5.5's first-party price depends on prompt length (see
[CONFIG-MODELS.md](CONFIG-MODELS.md#haiku-55-the-current-cheap-option)); on
Bedrock the price is AWS's, and a `pricingOverrides` entry for it is applied
flat — see [Cost](#cost-is-reported-honestly-or-not-at-all).

> **Opus 5.5 was in that second category for its first two releases** and is
> now mapped. It shipped unmapped not because its availability varies but because it
> had no documented Bedrock id at all: the model launched after the table's
> then-current documentation check. A re-check on 2026-10-06 found
> `anthropic.claude-opus-5-5` documented on both the per-model "Amazon Bedrock
> ID" row and the `InvokeModel` page, so the entry rests on a published id
> rather than on one inferred from the Opus 5 row. If your account's inference
> profiles differ, override it — see *Overriding a mapping* below; an explicit
> `modelMap` entry always beats the shipped one.

### An unmapped model refuses — it never substitutes

If a role is pinned to a model with no entry for your endpoint, the crew launch
is **abandoned** with a message naming the model, the backend, the region and
prefix in force, and the config key to set:

```
model 'claude-fable-5-1' is not available on the 'bedrock' backend
(region ap-southeast-2 (prefix 'au.'), endpoint invoke) — map it explicitly with
`mso providers set model bedrock --config modelMap.claude-fable-5-1=<backend-native id>`
```

It will **never** quietly run on a different model. An unattended fleet that
silently downgraded an order from the model it was planned for — with no record
in the usage table — is the failure this refusal exists to prevent.

**Fable 5.1 is the only current model that refuses on a shipped workspace**, and
why it refuses is worth knowing if you are deciding whether to map it: its
availability *varies by account and endpoint*, so Maestro will not guess on your
behalf. No documentation check can settle that — only your own account can — so
the refusal stands until you map it yourself.

Opus 5.5 used to refuse alongside it, for a different reason that has since
expired: it had no documented Bedrock id at all, having launched after the
table's then-current check. It is now mapped against a published id. The general
rule the two cases share is the one worth carrying away: **Maestro maps a model
only against a documented native id, never one inferred by analogy.** Being
newer than Opus 5 would not on its own have made `anthropic.claude-opus-5-5` a
safe guess — an id that does not exist fails at dispatch, and one that exists but
names a different model on your account's inference profiles bills you for that
model instead. If your account serves a model on an id other than the shipped
one, override it with the native id **your** account reports.

### Overriding a mapping

```bash
# a model the shipped table does not carry
mso providers set model bedrock --config modelMap.claude-fable-5-1=anthropic.claude-fable-5-1

# an application inference profile, by ARN — used verbatim, never prefixed
mso providers set model bedrock \
  --config modelMap.claude-opus-5=arn:aws:bedrock:ap-southeast-2:123456789012:application-inference-profile/abcd1234
```

Three values are emitted exactly as written: anything beginning `arn:`, anything
that already carries an inference-profile prefix — `au.`, `jp.`, `global.` or any
other `<geo>.anthropic.` id — (so pasting a fully-qualified id out of the AWS
console does not produce `us.us.anthropic....`), and every Mantle value.

The `[1m]` context-window selector survives translation — a role with
`contextWindow: "1m"` launches against `au.anthropic.claude-opus-5[1m]`. You
never write `[1m]` into a `modelMap` value.

---

## The Mantle endpoint

Mantle is a **mode of the Bedrock backend**, not a separate one. Its ids carry
an `anthropic.` provider prefix, carry no version suffix, and are **never**
region-prefixed — the region lives in the endpoint host rather than in the id.

```bash
mso providers set model bedrock --config endpoint=mantle --config region=ap-southeast-2
mso providers set model bedrock --config mantleBaseUrl=<url>
```

**That second command is required, and `mso setup` deliberately does not ask for
it.** The wizard prints a note pointing at it instead; the URL is outside the
closed set of keys the wizard is allowed to write. Setting the endpoint without
the URL is a two-step flow by design, not a half-finished one.

`endpoint=both` is legitimate: the two endpoints can run together, and requests
are routed by the shape of the model id. Maestro consults the `invoke` map first
and falls back to `mantleModelMap` for an id the first does not carry.

---

## Gateway and proxy headers (`crew.customHeaders`)

If your organisation reaches Claude through a corporate gateway or proxy, in
front of either the direct Anthropic API or Bedrock, that gateway may require
extra HTTP headers on every request: an API key of its own, a tenant id, a cost
centre. `crew.customHeaders` is the workspace setting for them. Every crew that
runs on a Claude model sends them, through Claude Code's
`ANTHROPIC_CUSTOM_HEADERS` variable.

```jsonc
// .mso/config/workspace.json
"crew": {
  "customHeaders": {
    "X-Gateway-Key":    "secret://aws/gateway/api-key",   // a secret store reference (Enterprise)
    "X-Proxy-Tenant":   "env:CORP_TENANT_ID",             // read from the environment at launch
    "X-Request-Source": "maestro"                         // a plain literal (non-credential names only)
  }
}
```

### Setting it

```bash
mso settings set crew.customHeaders '{"X-Gateway-Key":"env:GW_KEY","X-Request-Source":"maestro"}'
mso settings get crew.customHeaders     # shows the references, never a resolved value
mso settings unset crew.customHeaders
```

The value is one JSON object, so setting it replaces the whole map. In the Hub
the setting appears on the Settings screen read-only, with a pointer to the
command above. Because only references and non-credential literals are ever
stored, nothing secret is shown there.

### The three kinds of value

| Value | Allowed for | Resolved |
|---|---|---|
| `env:NAME` | any header | At each crew launch, from the dispatcher's environment. Works on every tier. |
| `secret://<provider>/<namespace>/<key>` | any header | At each crew launch, from the workspace's configured secrets provider (environment, OS keyring, AWS Secrets Manager, Azure Key Vault and the others Maestro supports). Needs Enterprise. |
| a literal string | header names that do **not** look like credentials | As written. |

A header whose name looks like a credential (`Authorization`,
`Proxy-Authorization`, `Cookie`, or any name containing `token`, `secret`,
`password`, `apikey`/`api-key`, `credential`, `auth`, `pat`, `key`,
`signature`, `subscription`, `private`, `bearer` or `session`, so
`Ocp-Apim-Subscription-Key`, `X-Gateway-Key` and `X-Signature` among them)
**must** use `env:` or `secret://`. A literal for it is refused. `workspace.json` is usually
committed, so treat everything in it as readable by everyone with repository
access.

References are resolved fresh at every crew launch, so a rotated secret is
picked up by the next iteration with no restart.

### Which crews send them

| A crew running on… | Sends `crew.customHeaders`? |
|---|---|
| the direct Anthropic API, with `providers.model` unset (the default) | yes |
| `providers.model` = `anthropic` | yes |
| `providers.model` = `bedrock`, any `endpoint` (`invoke`, `mantle`, `both`) | yes |
| an open-weights model on `providers.local_model` | **never** |

An open-weights endpoint is a server you run, not your gateway, so your gateway
credentials are never sent to it. Any `ANTHROPIC_CUSTOM_HEADERS` inherited from
the dispatcher's shell is removed from those crews as well.

**The workspace wins.** When `crew.customHeaders` is set, it replaces any
`ANTHROPIC_CUSTOM_HEADERS` exported in the shell that started the dispatcher.
When it is unset, crews behave exactly as before, and an exported value passes
through unchanged.

### What is refused

The same rules apply when you set the value, when a crew launches, and in
`mso doctor`:

- **Header names** must use HTTP token characters only (letters, digits and
  the punctuation `` !#$%&'*+-.^_`|~ ``), at most 128 characters: no `:`,
  spaces, CR, LF or NUL. Names are case-insensitive, so `X-Tenant` and
  `x-tenant` together are refused.
- **Reserved names** that Claude Code or the HTTP layer sets itself cannot be
  overridden: `Host`, `Content-Length`, `Content-Type`, `Transfer-Encoding`,
  `Connection`, `Upgrade`, `TE`, `Trailer`, `Keep-Alive`, `Proxy-Connection`,
  `x-api-key`, `anthropic-version`, `anthropic-beta`.
- **Values** must be a single line of visible ASCII, spaces or tabs, and not
  empty. A carriage return or line feed is always refused: the variable is
  newline-separated, so a newline would add a header you did not write. This is
  checked again on the **resolved** value, because a secret store can hold one.
- At most 32 headers.

No error message ever repeats a value. Messages name the header and, where it
helps, the reference.

### Kept out of logs

A resolved value never appears in a crew log, `lifecycle.log`, the
model-backend state file or `mso doctor --json` output. Crew logs list the
header **names** sent (`Custom headers (crew.customHeaders): X-Gateway-Key,
X-Request-Source`), and any resolved value that reaches a log line is replaced
with `[REDACTED:custom-header]`. Literal values of 8 characters or more are
replaced too, in case a credential sits under a name the rule above misses.
`mso providers test model --live` applies the same redaction to the error text
a gateway sends back, since some gateways repeat the request headers there.

**The resolved value is in the crew's environment.** Maestro sets
`ANTHROPIC_CUSTOM_HEADERS`, with every reference already resolved, in the
environment of each crew process, because Claude Code reads it from there. The
crew's own tool calls inherit that environment, so a crew that runs `env`,
`printenv` or a script that reads the variable sees every header value in
plain text, in its own session. The same applies to every credential a crew
inherits. Redaction keeps the values out of Maestro's logs, but it does not
hide them from the crew. Send a crew only gateway credentials you would let
that crew use directly.

### When a reference does not resolve

If an `env:` variable is not set, a `secret://` reference cannot be read, or a
resolved value breaks the rules above, the dispatcher **holds new dispatch** with
`MODEL_BACKEND_UNAVAILABLE`, naming the header and the reference. Running crews
are left alone and no retry attempts are spent. Once the reference resolves,
dispatch resumes by itself within about a minute, with `MODEL_BACKEND_RESTORED`;
no restart is needed. A crew launched while the reference is broken refuses to
start rather than run without the headers your gateway expects.

`mso doctor` reports the same problems with the dispatcher stopped, under the
check `model.custom-headers`.

### Requirements and verification

- Claude Code **2.1.227 or later** reads `ANTHROPIC_CUSTOM_HEADERS`.
- Claude Code documents the variable for API requests in general, but does not
  state explicitly that it applies to Bedrock and Mantle requests. **Verify
  against your own gateway** before you rely on it: run the `mso setup`
  preflight (it launches Claude Code with the same environment a crew gets) and
  confirm in the gateway's logs that the headers arrived.

---

## What is different on Bedrock

Two differences are real, operator-visible, and will not be papered over.

### WebSearch is not available

The **WebSearch tool is not served by Amazon Bedrock.** The Planner role's tool
list names both `WebFetch` and `WebSearch`, so a planning crew on a
Bedrock-backed workspace has `WebFetch` and nothing else for external lookups.

This is an announced degradation of the backend, not a misconfiguration, and not
something to work around by switching backend mid-order. Plan around it: cite a
URL that can be fetched directly, or record the question as an explicit open
assumption for the Captain rather than leaving a gap the reader cannot see. The
Planner role's own definition carries the same note, so every planning crew on a
Bedrock workspace is told.

### Cost is reported honestly, or not at all

Bedrock pricing is operated by AWS, varies by region, and differs between
regional and global inference profiles. Maestro's built-in rate table is the
first-party Anthropic one — it is **not** your Bedrock bill.

So on a Bedrock workspace, `mso usage` reports **`unpriced`**, with the reason,
rather than a dollar figure computed from the wrong rate card:

```
costBasis: unpriced
reason: backend 'bedrock' does not bill at first-party list rates; no usable
        pricingOverrides for 'claude-opus-5' -- set
        providers.model.bedrock.config.pricingOverrides.<model>.{input,output,cache_creation,cache_read}
```

**This is a deliberate accuracy choice, not a missing feature.** `mso usage
--report` is read to make spend decisions, and a number wrong by an unknown
margin is worse than an honest blank. Token counts are unaffected — tokens are
tokens, and they are recorded and reported exactly as before.

To get real figures, supply your own rates in **USD per million tokens** — the
same units your AWS bill and Maestro's own table use, so there is no arithmetic
in between:

```bash
mso providers set model bedrock \
  --config pricingOverrides.claude-opus-5.input=5.00 \
  --config pricingOverrides.claude-opus-5.output=25.00 \
  --config pricingOverrides.claude-opus-5.cache_creation=6.25 \
  --config pricingOverrides.claude-opus-5.cache_read=0.50
```

All **four** rate keys are required per model. An entry missing one is not
partially applied — the model stays `unpriced`, and the reason names the key you
left out. Likewise, if any one model in a record is unpriced the whole record is
reported unpriced rather than as a subtotal presented as a total.

**An override is one flat rate card.** Maestro applies the four rates you supply
to every token of that model, whatever the prompt length. First-party Haiku 5.5
pricing has a higher tier for prompts over 100K tokens, but Maestro does not
carry that tier over to an override: partner platforms set their own prices, and
Maestro will not invent a tier on your bill's behalf. If AWS bills Haiku 5.5 in
tiers on your account, choose the rates you supply with that in mind.

A usage record now carries `backend` and `costBasis` fields alongside its token
counts. Records written before this feature existed, and every workspace on the
direct API, read as `first-party-list` — unchanged output, unchanged figures.

### What is *not* different

- **Order JSON, role overlays, `role-models.json`, plans and usage records** all
  keep using Maestro's canonical model ids. A backend-native id never reaches
  any of them.
- **`mso status`, `mso usage` and the Hub** read the same ids they always did.
- **Per-role model, effort and context-window configuration** works exactly as
  documented in [CONFIG-MODELS.md](CONFIG-MODELS.md) — the backend changes where
  the model runs, never how it is chosen.

---

## Credentials

**Maestro never stores an AWS credential, and there is no configuration field
for one.** Not "credentials must be given as a reference" — no access key,
secret key, session token or bearer token field exists in the Bedrock backend's
configuration at all.

Credentials reach a crew the way every other environment variable does: the crew
inherits the dispatcher's environment, so whatever your AWS credential chain
provides (`AWS_ACCESS_KEY_ID`, `AWS_SESSION_TOKEN`, an SSO session cache, an
instance role, `AWS_BEARER_TOKEN_BEDROCK`) is already available to it without
ever passing through `workspace.json`.

`awsProfile` is the only AWS-facing key, and it holds a profile **name** — an
identifier, not a secret.

A gateway or proxy credential that crews send as a request header is the one
exception to "no credential field": it lives in `crew.customHeaders`, and only
as an `env:` or `secret://` reference. See
[Gateway and proxy headers](#gateway-and-proxy-headers-crewcustomheaders).

Two things to know about the surrounding guard:

- `mso providers set` refuses a value for any field whose **name** looks like a
  credential (`token`, `secret`, `password`, `apiKey`, `credential`, `auth`,
  `pat`…) unless it is an `env:NAME` or `secret://…` reference. See
  [PROVIDERS.md § Credentials](PROVIDERS.md#credentials).
- That guard matches on field **names**, so it cannot catch a secret pasted into
  a field whose name does not look credential-shaped. **Do not hand-add config
  keys to hold credentials, and do not paste a key into `awsProfile`** — the
  wizard refuses an obvious access key id there, but the rule to follow is
  simply that `workspace.json` is git-tracked and holds no secrets.

`workspace.json` is committed in most workspaces. Treat everything in it as
public to everyone with repository access.

---

## Troubleshooting

| Symptom | What it means | What to do |
|---------|---------------|------------|
| `MODEL_BACKEND_UNAVAILABLE` naming an expired session | Your AWS SSO session has expired. New crews are held; running ones are untouched. | Run the command the message names (`aws sso login --profile <name>`). The hold lifts within about a minute, with no restart. |
| `MODEL_BACKEND_UNAVAILABLE` naming a licence tier | The workspace is configured for Bedrock but the licence is below Enterprise. | `mso licence status`. Either activate an Enterprise licence or `mso providers unset model`. |
| `mso providers test model` says credential state could not be determined | The AWS CLI is not on `PATH`, the check timed out, or the machine authenticates by instance role. | Nothing is wrong by itself — this never holds dispatch. If crews then fail at launch, install the AWS CLI so the check can give a real answer. |
| A crew refuses with `model '…' is not available on the 'bedrock' backend` | The role's pinned model has no mapping for your endpoint. | Add the mapping the message names, or pin that role to a model the shipped table carries. |
| Bedrock itself rejects a model the mapping produced | The model is not served by your region's inference profile, or your account has not been granted it. | Try `regionPrefix=global`, set a region whose profile serves the model, or request model access in the Bedrock console. Haiku 4.5 in particular is not served by every regional profile. Haiku 5.5 needs per-account access ("See Access"), so request it in the console if Bedrock refuses it. |
| A crew launched on the wrong backend | An environment variable in the dispatcher's shell disagreed with the workspace config — but the workspace wins, so this should not happen. | Check the `backend:` and `region:` fields on the crew's `Model:` line, then `mso providers show model`. |
| `mso usage` reports `unpriced` | Expected on Bedrock. The backend does not bill at first-party rates. | Supply `pricingOverrides` (all four rate keys per model) if you want figures. Token counts are already accurate. |
| `MODEL_BACKEND_UNAVAILABLE` naming `crew.customHeaders['<header>']` | A reference in `crew.customHeaders` does not resolve (the environment variable is not set, or the secret cannot be read), or it resolved to a value with a newline or other refused character. | Export the variable in the dispatcher's environment or fix the secret. The hold lifts within about a minute. `mso doctor` shows the same finding under `model.custom-headers`. |
| The setup wizard did not offer Bedrock | Below Enterprise tier, or the `model` provider is pinned by a signed policy bundle. | `mso licence status`; a locked provider is reported as locked and is an organisation-level decision. |

---

## One Claude backend plus one open-weights endpoint

*Experimental.* Everything above is about **which Claude backend** a workspace
uses: `providers.model`, set to `anthropic` or `bedrock`. A workspace may
**also** configure one open-weights endpoint, a server you run (Ollama,
llama.cpp, vLLM, SGLang, LM Studio) that speaks the Anthropic Messages API:

```jsonc
"providers": {
  "model":       { "id": "anthropic", "config": {} },                                // the Claude backend, unchanged
  "local_model": { "id": "endpoint",  "config": { "baseUrl": "http://127.0.0.1:11434" } }
}
```

**The model id picks between them.** No separate "backend" field exists, so a
model and a backend can never disagree:

| A crew resolves to… | It runs on… |
|---|---|
| a `claude-…` id | `providers.model` (direct Anthropic API or Bedrock), exactly as described above |
| an open-weights catalogue id, e.g. `muse-glimmer-30b` | `providers.local_model` |

Both remain properties of the workspace. The rules on this page carry over:

- **Canonical ids never change.** `muse-glimmer-30b` is what you write and what
  usage records show; the runtime's own name (`muse-glimmer:30b`) appears only
  on the crew's `--model` argument and its `Model:` line
  (`… | backend: local_model/endpoint | native: muse-glimmer:30b`).
- **An unmapped model refuses.** An open-weights id with no endpoint configured,
  or one the endpoint does not serve, refuses the launch with the fix. It is
  never swapped for a Claude model unless you set an explicit `modelFallback`.
- **No credential lives in config.** The endpoint's optional `authToken` is an
  `env:` / `secret://` reference only. Your Anthropic and cloud credentials are
  removed from a crew's environment before it talks to the endpoint, and so are
  your gateway headers: `crew.customHeaders` is
  [never sent to an open-weights endpoint](#which-crews-send-them).
- **Holds are per route.** When the endpoint stops answering,
  `MODEL_BACKEND_UNAVAILABLE backend=local_model/endpoint` holds only the orders
  routed to it. Claude orders keep dispatching, and the reverse is also true.
- **Cost is stated, not guessed.** Runs on a local or private endpoint are
  recorded as cost basis `local` at $0.00; a remote endpoint is `unpriced`
  unless you supply `pricingOverrides`. `mso usage --by-backend` splits usage
  by backend.

The endpoint needs a Pro, Team or Enterprise licence. PLN, SEC and REL are
refused an open-weights model unless you opt them in, and LEAD never runs on
one. Setup, hardware, the role policy and troubleshooting are all in
[LOCAL-MODELS.md](LOCAL-MODELS.md).

---

## See also

- [PROVIDERS.md](PROVIDERS.md) — the provider seam this backend plugs into, and
  how credentials are handled across every provider kind
- [CONFIG-MODELS.md](CONFIG-MODELS.md) — choosing a model per role, per voyage
  or per order, effort, and the 1M context window
- [LOCAL-MODELS.md](LOCAL-MODELS.md) — running open-weights models on your own
  endpoint beside the Claude backend
- [SETTINGS.md](SETTINGS.md) — where `providers.model` is stored and how it
  resolves
- [ENTERPRISE-SETUP.md](ENTERPRISE-SETUP.md) — network requirements, data
  residency and licence management
- [TROUBLESHOOTING.md](TROUBLESHOOTING.md) — general fleet troubleshooting
